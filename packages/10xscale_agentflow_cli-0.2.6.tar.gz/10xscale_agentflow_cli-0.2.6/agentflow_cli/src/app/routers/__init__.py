from .setup_router import init_routes


__all__ = ["init_routes"]
