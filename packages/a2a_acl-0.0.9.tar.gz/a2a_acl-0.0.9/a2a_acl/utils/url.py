def build_url(host: str, port: int) -> str:
    return "http://" + host + ":" + str(port) + "/"
