"""A2A MCP Server - Model Context Protocol server for Agent2Agent protocol."""

__version__ = "0.1.0"
