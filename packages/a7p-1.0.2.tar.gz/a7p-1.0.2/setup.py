from setuptools import setup, find_packages

setup()
# from a7p import __version__, __author__
#
#
# CLASSIFIERS = [
#     'Intended Audience :: Developers',
#     'Natural Language :: English',
#     'Programming Language :: Python',
#     'Topic :: Software Development :: Libraries :: Python Modules'
# ]
#
# KEYWORDS = 'protobuf, archer, a7p'
#
#
# with open('requirements.txt', 'r') as fp:
#     setup_requires = fp.readlines()
#
#
# with open('README.MD', 'r') as fp:
#     long_description = fp.read()
#
#
# package_data = {'a7p': ['requirements.txt', 'a7p/test.a7p']}
#
# setup(
#     name='a7p',
#     version=__version__,
#     python_requires='>=3.9',
#
#     description='Simple python3 wrapper for .a7p files',
#     long_description=long_description,
#     long_description_content_type="text/markdown",
#
#     author=__author__,
#     url='https://github.com/o-murphy/a7p_transfer_example',
#     download_url='https://github.com/o-murphy/a7p_transfer_example',
#
#     classifiers=CLASSIFIERS,
#     keywords=KEYWORDS,
#
#     packages=find_packages(),
#     install_requires=setup_requires,
#     py_modules=['a7p'],
#
#     include_package_data=True,
#     package_data=package_data,
#
#     zip_safe=False,
# )

