"""Initialize the app"""

__version__ = "1.1.8"
__title__ = "Markettracker"
