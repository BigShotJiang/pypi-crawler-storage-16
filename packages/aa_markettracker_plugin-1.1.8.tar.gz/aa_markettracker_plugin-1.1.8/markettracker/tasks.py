import logging
import requests
from celery import shared_task
from django.conf import settings
from django.utils import timezone
from django.utils.dateparse import parse_datetime
from django.db import transaction
from django.db.models import Sum

from esi.models import Token
from esi.errors import TokenInvalidError
from eveuniverse.models import EveRegion

from .models import (
    MarketCharacter,
    MarketTrackingConfig,
    MarketOrderSnapshot,
    TrackedItem,
    TrackedStructure,
    Delivery,
    ContractSnapshot,
    ContractDelivery,
    TrackedContract,
    ContractError,
)
from .discord import send_items_alert, send_contracts_alert, items_restocked_alert, contracts_restocked_alert
from .utils import contract_matches, fetch_contract_items

logger = logging.getLogger(__name__)
ESI_BASE_URL = "https://esi.evetech.net/latest"


# ======= WSPÓLNE =======

def _location_name(config: MarketTrackingConfig) -> str:
    if not config:
        return "Unknown"
    if config.scope == "region":
        try:
            return EveRegion.objects.get(id=config.location_id).name
        except EveRegion.DoesNotExist:
            return str(config.location_id)
    else:
        try:
            return TrackedStructure.objects.get(structure_id=config.location_id).name
        except TrackedStructure.DoesNotExist:
            return str(config.location_id)


# ========== MARKET (ITEMS) ==========

@shared_task
def fetch_market_data_auto():
    mc = MarketCharacter.objects.first()
    if not mc:
        logger.warning("[MarketTracker] No MarketCharacter found for auto refresh.")
        return
    # CharacterOwnership zwykle ma character_id
    fetch_market_data(mc.character.character_id)


@shared_task
def fetch_market_data(character_id):
    import re
    from django.db import connection

    config = MarketTrackingConfig.objects.first()
    if not config:
        logger.warning("[MarketTracker] No MarketTrackingConfig found")
        return

    yellow_threshold = config.yellow_threshold
    red_threshold = config.red_threshold
    changed_statuses = []  # będziemy tu wrzucać (item, old_status, new_status, percent, total, desired)

    # token admina
    try:
        character = MarketCharacter.objects.get(character__character_id=character_id)
        admin_token = character.token
        admin_access_token = admin_token.valid_access_token()
    except MarketCharacter.DoesNotExist:
        logger.warning("[MarketTracker] No MarketCharacter found for character_id=%s", character_id)
        return
    except Exception as e:
        logger.error("[MarketTracker] Token refresh failed: %s", e)
        return

    # === PRZYGOTOWANIE TABELI TYMCZASOWEJ (MariaDB / MySQL) ===
    orig_table = MarketOrderSnapshot._meta.db_table            # np. "markettracker_marketordersnapshot"
    tmp_table = f"{orig_table}_tmp"                            # "markettracker_marketordersnapshot_tmp"
    old_table = f"{orig_table}_old"                            # "markettracker_marketordersnapshot_old"

    with connection.cursor() as cursor:
        try:
            # Sprzątamy ewentualne pozostałości
            cursor.execute(f"DROP TABLE IF EXISTS `{tmp_table}`;")

            # Pobierz pełne CREATE TABLE dla oryginału
            cursor.execute(f"SHOW CREATE TABLE `{orig_table}`;")
            row = cursor.fetchone()
            if not row or len(row) < 2:
                logger.error("[MarketTracker] SHOW CREATE TABLE returned no result for %s", orig_table)
                return

            create_sql = row[1]

            # 1) Zamiana nazwy tabeli na tymczasową
            create_tmp_sql = re.sub(
                r"^CREATE TABLE `[^`]+`",
                f"CREATE TABLE `{tmp_table}`",
                create_sql,
                count=1,
                flags=re.IGNORECASE | re.MULTILINE,
            )

            # 2) Wywalamy wszystkie definicje FOREIGN KEY z CREATE TABLE,
            #    żeby tmp_table w ogóle nie miała FK (unikamy konfliktu nazw).
            lines = create_tmp_sql.splitlines()
            lines_wo_fk = [ln for ln in lines if "FOREIGN KEY" not in ln]
            create_tmp_sql = "\n".join(lines_wo_fk)

            # 3) Jeśli po usunięciu FK został przecinek przed zamykającym nawiasem, usuń go
            create_tmp_sql = re.sub(r",\s*\n\)", "\n)", create_tmp_sql)

            # 4) Tworzymy tabelę tymczasową
            cursor.execute(create_tmp_sql)
            logger.info("[MarketTracker] Temporary table created: %s", tmp_table)

        except Exception as e:
            logger.exception("[MarketTracker] Failed to prepare temporary table %s: %s", tmp_table, e)
            try:
                cursor.execute(f"DROP TABLE IF EXISTS `{tmp_table}`;")
            except Exception:
                pass
            return

    # === PRZEŁĄCZENIE MODELU NA TABELĘ TYMCZASOWĄ ===
    original_db_table = MarketOrderSnapshot._meta.db_table
    MarketOrderSnapshot._meta.db_table = tmp_table

    try:
        # Na wszelki wypadek czyścimy tmp (powinna być pusta po CREATE)
        MarketOrderSnapshot.objects.all().delete()

        # Pobieranie i zapisywanie zamówień -> trafiają do tmp_table
        if config.scope == "region":
            seen_orders = _fetch_region_orders(config.location_id)
        else:
            seen_orders = _fetch_structure_orders(config.location_id, admin_access_token)

        logger.info(
            "[MarketTracker] Orders imported into tmp table %s: %s",
            tmp_table,
            len(seen_orders),
        )

        # === LICZENIE STATUSÓW NA BAZIE DANYCH W TMP TABLE ===
        for item in TrackedItem.objects.all():
            orders = MarketOrderSnapshot.objects.filter(tracked_item=item)
            total_volume = orders.aggregate(Sum("volume_remain"))["volume_remain__sum"] or 0
            desired = item.desired_quantity or 1
            percentage = int((total_volume / desired) * 100) if desired > 0 else 100

            if percentage <= red_threshold:
                new_status = "RED"
            elif percentage <= yellow_threshold:
                new_status = "YELLOW"
            else:
                new_status = "OK"

            old_status = item.last_status

            if new_status != old_status:
                # zapisujemy pełną informację, żeby móc wysłać zarówno alert braków, jak i restock
                changed_statuses.append(
                    (item, old_status, new_status, percentage, total_volume, desired)
                )
                item.last_status = new_status
                item.save(update_fields=["last_status"])

        _update_deliveries(config)

        if changed_statuses:
            logger.info("[MarketTracker] Status changes detected (items): %s", changed_statuses)
            # alert o brakach / niskim stanie
            send_items_alert(changed_statuses, _location_name(config))
            # alert o uzupełnieniu
            items_restocked_alert(changed_statuses, _location_name(config))

        # === ATOMOWY SWAP TABEL (po tymczasowej pracy) ===
        with connection.cursor() as cursor:
            # opcjonalnie: wyrzuć stary backup jeśli został z poprzedniego taska
            cursor.execute(f"DROP TABLE IF EXISTS `{old_table}`;")

            rename_sql = (
                f"RENAME TABLE "
                f"`{orig_table}` TO `{old_table}`, "
                f"`{tmp_table}` TO `{orig_table}`;"
            )
            cursor.execute(rename_sql)
            logger.info(
                "[MarketTracker] Atomic swap done: %s -> %s ; %s -> %s",
                orig_table, old_table, tmp_table, orig_table,
            )

        # od razu sprzątamy backup, jeśli nie chcesz go trzymać
        with connection.cursor() as cursor:
            cursor.execute(f"DROP TABLE IF EXISTS `{old_table}`;")
            logger.info("[MarketTracker] Dropped old snapshot table: %s", old_table)

    except Exception as e:
        logger.exception("[MarketTracker] Error during market data refresh (tmp swap): %s", e)
        # Przy błędzie spróbuj posprzątać tmp
        try:
            with connection.cursor() as cursor:
                cursor.execute(f"DROP TABLE IF EXISTS `{tmp_table}`;")
        except Exception:
            pass
        return

    finally:
        # Przywróć nazwę tabeli w modelu (od tej chwili pokazuje już "nowy" snapshot)
        MarketOrderSnapshot._meta.db_table = original_db_table



def _fetch_region_orders(region_id):
    seen_orders = set()
    for tracked in TrackedItem.objects.all():
        type_id = tracked.item.id
        page = 1
        while True:
            url = f"{ESI_BASE_URL}/markets/{region_id}/orders/"
            params = {"order_type": "sell", "type_id": type_id, "page": page}
            headers = {"User-Agent": getattr(settings, "ESI_USER_AGENT", "MarketTracker/1.0")}
            try:
                resp = requests.get(url, params=params, headers=headers, timeout=10)
                resp.raise_for_status()
            except Exception as e:
                logger.error("[MarketTracker] Region page %s failed for %s: %s", page, tracked.item.name, e)
                break
            data = resp.json()
            pages = int(resp.headers.get("X-Pages", 1))
            seen_orders.update(_save_orders(data, tracked, region_id))
            if page >= pages:
                break
            page += 1
    return seen_orders


def _fetch_structure_orders(structure_id, access_token):
    seen_orders = set()
    for tracked in TrackedItem.objects.all():
        type_id = tracked.item.id
        page = 1
        while True:
            url = f"{ESI_BASE_URL}/markets/structures/{structure_id}/"
            params = {"page": page}
            headers = {
                "User-Agent": getattr(settings, "ESI_USER_AGENT", "MarketTracker/1.0"),
                "Authorization": f"Bearer {access_token}",
            }
            try:
                resp = requests.get(url, params=params, headers=headers, timeout=10)
                resp.raise_for_status()
            except Exception as e:
                logger.error("[MarketTracker] Structure page %s failed for %s: %s", page, tracked.item.name, e)
                break

            data = resp.json()
            pages = int(resp.headers.get("X-Pages", 1))
            filtered = [o for o in data if o.get("type_id") == type_id and not o.get("is_buy_order", False)]
            seen_orders.update(_save_orders(filtered, tracked, structure_id))
            if page >= pages:
                break
            page += 1
    return seen_orders


def _save_orders(orders, tracked_item, location_id):
    from django.utils import timezone as _tz
    seen_ids = set()
    for order in orders:
        if not isinstance(order, dict) or "type_id" not in order or "order_id" not in order:
            continue
        MarketOrderSnapshot.objects.update_or_create(
            order_id=order["order_id"],
            defaults={
                "tracked_item": tracked_item,
                "structure_id": location_id,
                "price": order.get("price", 0),
                "volume_remain": order.get("volume_remain", 0),
                "is_buy_order": order.get("is_buy_order", False),
                "issued": order.get("issued", _tz.now().isoformat()),
            },
        )
        seen_ids.add(order["order_id"])
    return seen_ids


def _update_deliveries(config):
    deliveries = Delivery.objects.filter(status="PENDING")

    # Najpierw wyłuskaj wszystkie tokeny z odpowiednim scopem
    raw_tokens = [
        t for t in Token.objects.select_related("user").all()
        if t.scopes.filter(name="esi-markets.read_character_orders.v1").exists()
    ]

    # Sprawdź które są faktycznie żywe
    valid_tokens = []
    for token in raw_tokens:
        try:
            access_token = token.valid_access_token()
            valid_tokens.append((token, access_token))
        except TokenInvalidError:
            logger.warning(
                "[MarketTracker] Skipping invalid token for char %s (id=%s)",
                token.character_id,
                token.id,
            )
        except Exception:
            logger.exception(
                "[MarketTracker] Token refresh failed for char %s (id=%s)",
                token.character_id,
                token.id,
            )

    if not valid_tokens:
        logger.warning("[MarketTracker] No valid tokens available for deliveries update.")
        return

    # Teraz używamy tylko sprawdzonych tokenów
    for delivery in deliveries:
        total_delivered = 0
        for token, access_token in valid_tokens:
            try:
                orders = _fetch_character_orders(token.character_id, access_token, config)
                filtered = []
                for o in orders:
                    if "issued" not in o or "type_id" not in o:
                        continue
                    issued_dt = parse_datetime(o["issued"])
                    if issued_dt:
                        issued_dt = issued_dt.astimezone(timezone.utc)
                    if (
                        issued_dt
                        and issued_dt >= delivery.created_at
                        and o["type_id"] == delivery.item.id
                        and not o.get("is_buy_order", False)
                    ):
                        filtered.append(o)
                delivered_from_orders = sum(o["volume_remain"] for o in filtered)
                total_delivered += delivered_from_orders
            except Exception:
                logger.exception(
                    "[MarketTracker] Orders fetch failed for char %s", token.character_id
                )

        delivery.delivered_quantity = min(total_delivered, delivery.declared_quantity)
        if delivery.delivered_quantity >= delivery.declared_quantity:
            delivery.status = "FINISHED"
        delivery.save(update_fields=["delivered_quantity", "status"])

def _fetch_character_orders(character_id, access_token, config):
    url = f"{ESI_BASE_URL}/characters/{character_id}/orders/"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "User-Agent": getattr(settings, "ESI_USER_AGENT", "MarketTracker/1.0"),
    }
    resp = requests.get(url, headers=headers, timeout=10)
    resp.raise_for_status()
    orders = resp.json()
    if config.scope == "region":
        return [o for o in orders if o.get("region_id") == config.location_id]
    return [o for o in orders if o.get("location_id") == config.location_id]


# ========== CONTRACTS ==========

@shared_task
def refresh_contracts():
    """
    Atomic snapshot refresh dla kontraktów.
    """
    from django.db import connection

    orig = ContractSnapshot._meta.db_table
    tmp = f"{orig}_tmp"
    old = f"{orig}_old"

    # Utworzenie tymczasowej tabeli
    with connection.cursor() as cursor:
        cursor.execute(f"DROP TABLE IF EXISTS `{tmp}`;")
        cursor.execute(f"CREATE TABLE `{tmp}` LIKE `{orig}`;")
        logger.info("[Contracts] Temporary snapshot table created: %s", tmp)

    # Przełączenie modelu na tmp
    original_name = ContractSnapshot._meta.db_table
    ContractSnapshot._meta.db_table = tmp

    try:
        ContractSnapshot.objects.all().delete()
        logger.info("[Contracts] Purged old snapshots in tmp table")

        mc = list(MarketCharacter.objects.all())
        fetch_contracts_snapshots(ContractSnapshot, mc)

        all_contracts = list(ContractSnapshot.objects.all())

        cfg = MarketTrackingConfig.objects.first()
        yellow = cfg.yellow_threshold if cfg else 50
        red = cfg.red_threshold if cfg else 25

        _recalculate_contract_statuses_and_alert(all_contracts, yellow, red)
        _update_contract_deliveries(all_contracts)

        # Atomic swap
        with connection.cursor() as cursor:
            cursor.execute(f"DROP TABLE IF EXISTS `{old}`;")
            cursor.execute(
                f"RENAME TABLE `{orig}` TO `{old}`, `{tmp}` TO `{orig}`;"
            )
            logger.info("[Contracts] Atomic snapshot swap done")
            cursor.execute(f"DROP TABLE IF EXISTS `{old}`;")

    except Exception as e:
        logger.exception("[Contracts] Error during contracts refresh: %s", e)

    finally:
        ContractSnapshot._meta.db_table = original_name


def fetch_contracts_snapshots(tmp_model, mc):
    """
    Pobiera snapshot kontraktów dla WSZYSTKICH MarketCharacter
    i zapisuje je do tmp_model (tabela tymczasowa).

    Zapisujemy TYLKO kontrakty o statusie OUTSTANDING.
    Items NIE są tu pobierane – ładujemy je leniwie w _recalculate_contract_statuses
    przez utils.load_contract_items().
    """
    import requests
    from django.utils import timezone

    seen = 0

    for char in mc:
        # --- token / character_id ---
        try:
            token = char.token
        except Exception:
            # brak tokenu – pomijamy
            continue

        try:
            access = token.valid_access_token()
            char_id = token.character_id
            if not isinstance(char_id, int) or char_id < 10:
                logger.warning(
                    "[Contracts] Skipped invalid character_id=%s for token %s",
                    char_id,
                    token.pk,
                )
                continue
        except Exception as e:
            logger.warning("[Contracts] Token refresh failed for %s: %s", char, e)
            continue

        page = 1
        while True:
            url = f"{ESI_BASE_URL}/characters/{char_id}/contracts/"
            params = {"page": page}
            headers = {
                "User-Agent": getattr(settings, "ESI_USER_AGENT", "MarketTracker/1.0"),
                "Authorization": f"Bearer {access}",
            }

            try:
                resp = requests.get(url, params=params, headers=headers, timeout=10)
                resp.raise_for_status()
            except Exception as e:
                logger.error(
                    "[Contracts] Fetch failed for char %s page %s: %s",
                    char_id,
                    page,
                    e,
                )
                break

            data = resp.json() or []
            pages = int(resp.headers.get("X-Pages", 1) or 1)

            for c in data:
                # --- filtrujemy tylko outstanding ---
                status = (c.get("status") or "").lower()
                if status != "outstanding":
                    continue

                contract_id = c.get("contract_id")
                if not contract_id:
                    continue

                try:
                    tmp_model.objects.update_or_create(
                        contract_id=contract_id,
                        defaults={
                            "issuer_id": c.get("issuer_id"),
                            "acceptor_id": c.get("acceptor_id"),
                            "title": c.get("title") or "",
                            "price": c.get("price") or 0,
                            "reward": c.get("reward") or 0,
                            "volume": c.get("volume") or 0,
                            "type": c.get("type"),
                            "availability": c.get("availability"),
                            "status": c.get("status"),
                            "date_issued": c.get("date_issued") or timezone.now(),
                            "date_expired": c.get("date_expired"),
                            "date_completed": c.get("date_completed"),
                            "start_location_id": c.get("start_location_id"),
                            "end_location_id": c.get("end_location_id"),
                            "collateral": c.get("collateral") or 0,
                            "for_corporation": c.get("for_corporation") or False,
                            "assignee_id": c.get("assignee_id"),
                            "issuer_corporation_id": c.get("issuer_corporation_id"),
                            "owner_character_id": char_id,
                            # items zostawiamy puste (domyślnie []),
                            # dociągamy je leniwie utils.load_contract_items()
                        },
                    )
                    seen += 1
                except Exception as e:
                    logger.error(
                        "[Contracts] Could not save contract %s: %s",
                        contract_id,
                        e,
                    )

            if page >= pages:
                break
            page += 1

    logger.info("[MarketTracker] Contracts fetched/updated: %s", seen)
    return seen


def _recalculate_contract_statuses_and_alert(all_contracts, yellow, red):
    """
    Przelicza statusy dla TrackedContract i wysyła alerty.
    Dla doktryn:
      - NIE filtrujemy po nazwie statku w tytule (bo tytuł może być pusty),
      - leniwie dociągamy items z ESI przez fetch_contract_items.
    """

    changed = []
    characters = list(MarketCharacter.objects.all())

    # wybierz pierwszy działający token (do ESI)
    def get_access_token():
        for c in characters:
            try:
                return c.token.valid_access_token(), c.character.character_id
            except Exception:
                continue
        return None, None

    access_token, _ = get_access_token()

    for tc in TrackedContract.objects.select_related("fitting").all():
        matched = []

        # === wstępne filtrowanie po tytule (CUSTOM) / typie/statusie (DOCTRINE) ===
        base_contracts = all_contracts

        if tc.mode == TrackedContract.Mode.CUSTOM:
            tf = (tc.title_filter or "").lower()
            if tf:
                base_contracts = [
                    c for c in all_contracts
                    if tf in (c.title or "").lower()
                ]

        elif tc.mode == TrackedContract.Mode.DOCTRINE:
            # dla doktryny NIE filtrujemy po tytule,
            # ale ograniczamy do item_exchange + outstanding
            base_contracts = [
                c for c in all_contracts
                if (c.type or "").lower() == "item_exchange"
                and (c.status or "").lower() == "outstanding"
            ]

        # === pełne dopasowanie kontraktów ===
        for c in base_contracts:
            if tc.mode == TrackedContract.Mode.DOCTRINE and access_token:
                # dociągamy items leniwie – jeśli już są, fetch_contract_items nic nie robi
                owner_id = c.owner_character_id or 0
                fetch_contract_items(c, access_token, owner_id)

            ok, _ = contract_matches(tc, c)
            if ok:
                matched.append(c)

        # === wyznaczanie statusu ===
        current = len(matched)
        desired = tc.desired_quantity or 0

        if desired <= 0:
            percent = 100
            new = "OK"
        else:
            percent = int((current / desired) * 100)
            if percent <= red:
                new = "RED"
            elif percent <= yellow:
                new = "YELLOW"
            else:
                new = "OK"

        old = tc.last_status

        if old != new:
            tc.last_status = new
            tc.save(update_fields=["last_status"])

            # nazwa do raportu
            if tc.mode == TrackedContract.Mode.DOCTRINE and tc.fitting:
                name = tc.fitting.name
            else:
                name = tc.title_filter or "—"

            prices = [float(m.price) for m in matched if getattr(m, "price", None)]
            min_price = min(prices) if prices else None

            changed.append({
                "name": name,
                "status": new,
                "old_status": old,
                "current": current,
                "desired": desired,
                "percent": percent,
                "min_price": min_price,
            })

    if changed:
        send_contracts_alert(changed)
        contracts_restocked_alert(changed)





def _update_contract_deliveries(all_contracts):
    """
    Aktualizuje ContractDelivery na podstawie faktycznie istniejących kontraktów.
    Dla doktryn dociągamy items z ESI (fetch_contract_items).
    """
    deliveries = ContractDelivery.objects.select_related("tracked_contract").filter(
        status="PENDING"
    )

    characters = list(MarketCharacter.objects.all())

    def get_access_token():
        for c in characters:
            try:
                return c.token.valid_access_token(), c.character.character_id
            except Exception:
                continue
        return None, None

    access_token, _ = get_access_token()

    for d in deliveries:
        tc = d.tracked_contract
        matched = 0

        # wstępny filtr
        base = all_contracts

        if tc.mode == TrackedContract.Mode.CUSTOM:
            tf = (tc.title_filter or "").lower()
            if tf:
                base = [c for c in all_contracts if tf in (c.title or "").lower()]

        elif tc.mode == TrackedContract.Mode.DOCTRINE:
            # znowu: nie filtrujemy po tytule, tylko po typie/statusie
            base = [
                c for c in all_contracts
                if (c.type or "").lower() == "item_exchange"
                and (c.status or "").lower() == "outstanding"
            ]

        for c in base:
            # tylko kontrakty wystawione po utworzeniu delivery
            if c.date_issued and c.date_issued < d.created_at:
                continue

            if tc.mode == TrackedContract.Mode.DOCTRINE and access_token:
                owner_id = c.owner_character_id or 0
                fetch_contract_items(c, access_token, owner_id)

            ok, _ = contract_matches(tc, c)
            if ok:
                matched += 1

        d.delivered_quantity = min(matched, d.declared_quantity)
        if d.delivered_quantity >= d.declared_quantity:
            d.status = "FINISHED"
        d.save(update_fields=["delivered_quantity", "status"])


