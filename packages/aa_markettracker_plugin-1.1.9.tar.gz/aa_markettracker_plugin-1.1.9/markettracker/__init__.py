"""Initialize the app"""

__version__ = "1.1.9"
__title__ = "Markettracker"
