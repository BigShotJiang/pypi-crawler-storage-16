"""Initialize the app"""

__version__ = "1.2.0"
__title__ = "Markettracker"
