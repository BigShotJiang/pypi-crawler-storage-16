from aalam_common.config_helper import Config


cfg = Config()
