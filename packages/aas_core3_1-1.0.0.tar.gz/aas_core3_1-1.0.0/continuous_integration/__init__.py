"""Provide scripts for the continuous integration."""
