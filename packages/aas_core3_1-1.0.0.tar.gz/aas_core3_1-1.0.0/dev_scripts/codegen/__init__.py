"""Scripts for working on aas-core3.1-python."""
