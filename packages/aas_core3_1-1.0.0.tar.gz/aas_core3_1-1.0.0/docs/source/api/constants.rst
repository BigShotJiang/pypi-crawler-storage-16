***********************
aas_core3_1.constants
***********************

.. automodule:: aas_core3_1.constants
    :special-members:
    :members:
    :exclude-members: __abstractmethods__, __module__, __annotations__, __dict__, __weakref__
