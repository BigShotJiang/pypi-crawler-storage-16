***
API
***

This is the documentation automatically generated from the source code.

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   common
   constants
   jsonization
   stringification
   types
   verification
   xmlization
