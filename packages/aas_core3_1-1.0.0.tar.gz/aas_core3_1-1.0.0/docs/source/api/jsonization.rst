*************************
aas_core3_1.jsonization
*************************

.. automodule:: aas_core3_1.jsonization
    :special-members:
    :members:
    :exclude-members: __abstractmethods__, __module__, __annotations__, __dict__, __weakref__
