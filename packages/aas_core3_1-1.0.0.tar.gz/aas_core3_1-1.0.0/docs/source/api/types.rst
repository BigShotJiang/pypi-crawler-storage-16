*******************
aas_core3_1.types
*******************

.. automodule:: aas_core3_1.types
    :special-members:
    :members:
    :exclude-members: __abstractmethods__, __module__, __annotations__, __dict__, __weakref__
