************************
aas_core3_1.xmlization
************************

.. automodule:: aas_core3_1.xmlization
    :special-members:
    :members:
    :exclude-members: __abstractmethods__, __module__, __annotations__, __dict__, __weakref__,__subclasshook__,__parameters__
