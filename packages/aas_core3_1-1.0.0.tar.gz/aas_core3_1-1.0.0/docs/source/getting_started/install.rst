************
Installation
************

Activate your virtual environment.

Install the SDK by calling:

.. code-block::

    pip3 install aas-core3.1
