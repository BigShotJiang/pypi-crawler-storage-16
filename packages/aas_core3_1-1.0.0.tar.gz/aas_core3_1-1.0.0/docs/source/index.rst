Welcome to aas-core3.1's documentation!
==================================================

Table of Contents
=================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   introduction
   getting_started/index

.. toctree::
   :maxdepth: 1

   api/index
   design_decisions
   contributing
   changelog

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
