NAME = "abadpour"

ICON = "📜"

DESCRIPTION = f"{ICON} Arash Abadpour's CV."

VERSION = "7.18.1"

REPO_NAME = NAME

MARQUEE = (
    "https://github.com/kamangir/assets/blob/main/abadpour/2020-11-21.jpg?raw=true"
)

ALIAS = NAME


def fullname() -> str:
    return f"{NAME}-{VERSION}"
