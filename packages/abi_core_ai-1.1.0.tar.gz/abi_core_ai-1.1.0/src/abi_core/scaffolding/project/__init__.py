"""
ABI Project Scaffolding Templates
Plantillas para crear nuevos proyectos ABI completos
"""

from pathlib import Path

TEMPLATE_DIR = Path(__file__).parent