
class AbromicsAPIError(Exception):
    pass


class AbromicsUploadError(Exception):
    pass


class AbromicsAuthenticationError(Exception):
    pass




