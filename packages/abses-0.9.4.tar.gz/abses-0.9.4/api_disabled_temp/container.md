---
title: Actors' Container
authors: SongshGeo
date: 2024-03-13
---

:::abses.agents.container._ModelAgentsContainer
    options:
      show_root_heading: false
      heading_level: 1

:::abses.agents.container._CellAgentsContainer
    options:
      show_root_heading: false
      heading_level: 1
