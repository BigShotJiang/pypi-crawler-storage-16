---
title: human
authors: SongshGeo
date: 2023-01-10
---

## Major human module

:::abses.human.human.BaseHuman

## Human submodule

:::abses.human.human.HumanModule
