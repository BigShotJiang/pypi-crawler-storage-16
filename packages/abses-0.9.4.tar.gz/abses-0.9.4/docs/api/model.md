---
title: model
authors: SongshGeo
date: 2023-01-10
---
:::abses.core.model.MainModel
