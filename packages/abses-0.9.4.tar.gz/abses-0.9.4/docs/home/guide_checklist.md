# Find your start point to use `ABSESpy`

## :thinking: Is `ABSESpy` my thing?

For using `ABSESpy`, you'd better to have basic experience with [Python]. Then, choose the best description of your knowledge background:

[:computer: I'm familiar with ABM](../tutorial/tutorial_guide_from_ABM.md){ .md-button }
[:earth_asia: I'm familiar with SES](../tutorial/tutorial_guide_from_SES.md){ .md-button }

:hatching_chick: If you're unfamiliar with ABM or SES, we recommend visiting our [wiki pages] to gain a basic understanding.
