# Reading materials & introductory tutorials

## Agent-based model

- [Introduction to Agent-based Modeling (Wikipedia)](https://en.wikipedia.org/wiki/Agent-based_model)


## Developers

- [Pytest Plugin List (Official Documentation)](https://docs.pytest.org/en/stable/reference/plugin_list.html)
