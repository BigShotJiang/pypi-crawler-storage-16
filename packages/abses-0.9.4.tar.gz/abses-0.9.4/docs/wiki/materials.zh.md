# 阅读材料和入门教程

## 基于智能体的模型

- [基于智能体建模介绍 (Wikipedia)](https://en.wikipedia.org/wiki/Agent-based_model)

## 开发者

- [Pytest 插件列表 (官方文档)](https://docs.pytest.org/en/stable/reference/plugin_list.html)

