*[ABM]: Agent-based model
*[SES]: Socio-ecological system
*[SESs]: Socio-ecological systems
*[CAS]: Complex Adaptive System

[python]: https://www.python.org/
[wiki pages]: ../wiki/wiki.md
[contact the author]: mailto:songshgeo@mail.bnu.edu.cn
