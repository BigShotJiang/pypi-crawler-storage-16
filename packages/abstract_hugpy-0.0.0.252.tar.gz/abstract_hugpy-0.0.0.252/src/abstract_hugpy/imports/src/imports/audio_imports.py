from pydub.silence import detect_nonsilent,split_on_silence
from pydub import AudioSegment
import speech_recognition as sr
import whisper
