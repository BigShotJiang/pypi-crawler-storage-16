from .bigbirdManager import *
##from .flanManager import *
##from .keybertManager import *
##from .summarizerManager import *
##from .whisperManager import *
##from .generation import *
####from .zerosearchManager import *
####from .deepcoderManager import *
##bp_list = [
####    hugpy_zerosearch_bp,
####    hugpy_deepcoder_bp,
##    whisper_bp,
##    summarizer_bp,
##    keybert_bp,
##    flan_summarizer_bp,
##    summarizer_bp,
##           ]
##
