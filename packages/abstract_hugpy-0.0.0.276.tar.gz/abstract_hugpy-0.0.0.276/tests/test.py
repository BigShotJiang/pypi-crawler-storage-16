from imports import *


if __name__ == "__main__":

    url = "https://stackoverflow.com/questions/77230706/using-only-pip-for-installing-spacy-model-en-core-web-sm"
    video_url = "https://www.youtube.com/watch?v=oC1nc0UqXRc"
    input(get_video_id(video_url))
    # Example: pull your raw pipeline dict
    info = get_pipeline_data(url=video_url, key="extract")
    input(info)
    
    print(mapped)
    input("Press Enter to exit...")
