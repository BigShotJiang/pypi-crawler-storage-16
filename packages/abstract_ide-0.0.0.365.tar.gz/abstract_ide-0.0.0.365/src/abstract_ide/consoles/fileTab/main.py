from src import fileCreationConsole
fileCreationConsole()
