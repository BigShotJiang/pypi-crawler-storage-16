from src.abstract_ide import *

from abstract_gui.QT6 import  *
  
startWindowManagerConsole()
