from abstract_gui.QT6.utils.console_utils import startConsole
from .main import *
def startWebPardnerConsole():
    startConsole(webPardnerTab)
