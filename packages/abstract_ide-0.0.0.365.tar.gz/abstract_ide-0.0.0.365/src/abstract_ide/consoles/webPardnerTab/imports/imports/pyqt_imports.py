# ---------- PyQt6 ----------
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLineEdit, QPushButton, QTextEdit, QCheckBox, QComboBox, QLabel,
    QFileDialog, QSpinBox
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
