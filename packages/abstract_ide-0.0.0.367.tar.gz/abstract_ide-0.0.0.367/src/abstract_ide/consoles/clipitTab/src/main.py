from abstract_clipit import clipitTab
