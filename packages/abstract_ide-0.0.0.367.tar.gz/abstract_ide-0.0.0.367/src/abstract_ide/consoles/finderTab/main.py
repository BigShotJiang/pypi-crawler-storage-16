from src import startFinderConsole
startFinderConsole()
