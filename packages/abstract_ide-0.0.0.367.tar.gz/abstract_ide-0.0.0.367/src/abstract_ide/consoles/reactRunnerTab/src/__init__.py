
from .main import reactRunnerTab
from abstract_gui.QT6.utils.console_utils import startConsole
def startReactRunnerConsole():
    startConsole(reactRunnerTab)
