import os

from .main import _FunctionsTab,startFinderConsole


