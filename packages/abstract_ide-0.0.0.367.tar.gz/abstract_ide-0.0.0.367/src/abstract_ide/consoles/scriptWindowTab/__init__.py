
from .main import scriptWindowTab
from abstract_gui.QT6.utils.console_utils import startConsole
def startScriptWindowConsole():
    startConsole(scriptWindowTab)
