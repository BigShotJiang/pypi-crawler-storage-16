from windowManagerTab import *

startWindowManagerConsole()
