from .base_dir import *
DOCUMENTS_MEDIA_DIR = get_media_dir("documents")
DOWNLOADS_MEDIA_DIR = get_media_dir("downloads")
IMAGES_MEDIA_DIR = get_media_dir("images")
ORBITSIMULATOR_MEDIA_DIR = get_media_dir("orbitSimulator")
PDFS_MEDIA_DIR = get_media_dir("pdfs")
THEDAILYDIALECTICS_MEDIA_DIR = get_media_dir("thedailydialectics")
UPLOADS_MEDIA_DIR = get_media_dir("uploads")
USERS_MEDIA_DIR = get_media_dir("users")
VIDEOS_MEDIA_DIR = get_media_dir("videos")
UPLOAD_FOLDER = ABS_UPLOAD_DIR = UPLOADS_MEDIA_DIR
ABS_UPLOAD_ROOT = ABS_UPLOAD_DIR = UPLOADS_MEDIA_DIR
##
