from ...read_write_utils import read_from_file,write_to_file,get_text_or_read
from ...string_utils import eatAll,eatInner,eatElse,clean_line
from ...class_utils import if_none_change,if_none_default,get_true_globals,get_initial_caller_dir,get_caller_path,get_caller_dir,if_none_default
from ...list_utils import make_list
from ...path_utils import get_file_parts
from ...type_utils  import is_number,make_list
from ...file_utils  import collect_filepaths,collect_globs
from ...directory_utils import get_shortest_path,get_common_root
