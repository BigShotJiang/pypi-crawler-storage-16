from PyQt6 import QtWidgets, QtGui, QtCore
from PyQt6.QtGui import QPixmap, QFileSystemModel, QDesktopServices
from PyQt6.QtCore import QUrl, QSize, QRect
