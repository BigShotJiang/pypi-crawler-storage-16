"""Identity and provenance primitives."""

from .fingerprint import ActorFingerprint

__all__ = ["ActorFingerprint"]


