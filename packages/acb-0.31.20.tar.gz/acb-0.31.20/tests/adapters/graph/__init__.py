"""Graph adapter tests."""
