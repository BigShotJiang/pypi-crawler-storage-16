"""Vector adapter tests."""
