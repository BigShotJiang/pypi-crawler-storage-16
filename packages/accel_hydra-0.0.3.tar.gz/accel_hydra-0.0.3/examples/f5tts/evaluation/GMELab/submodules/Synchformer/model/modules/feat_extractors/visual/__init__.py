import sys
sys.path.append('model/modules/feat_extractors/visual')  # nopep8
