python evaluation/path_star.py \
  --gen_audio_dir /hpc_stor03/sjtu_home/yixuan.li/work/x_to_audio_generation/experiments/audiocaps_star_ft_speecht5/inference/direct_speech_to_audio/cfg_5.0/step_20 \
  -c 16
