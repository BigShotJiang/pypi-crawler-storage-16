# Copyright (c) 2025 Xuenan Xu, Yixuan Li, Jiahao Mei. All rights reserved.
#
# Licensed under the MIT License. See LICENSE file for details.

__version__ = "0.0.3"
__license__ = "MIT"

from .trainer import Trainer, MetricMonitor
