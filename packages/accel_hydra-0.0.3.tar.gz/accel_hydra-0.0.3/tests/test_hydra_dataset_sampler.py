from dataclasses import dataclass, field
import json

import hydra
import numpy as np
import torch
import torch.nn as nn
import torchaudio
from omegaconf import OmegaConf
from datasets import Dataset

from examples.f5tts.utils.audio import MelSpec


def fn(a, b, c):
    return a + b + c


@dataclass
class CustomDataset(object):

    length: int


class Sampler:
    def __init__(self, data_source, shuffle=False) -> None:
        self.data_source = data_source
        self.shuffle = shuffle


if __name__ == "__main__":

    dataset = CustomDataset(length=100, )
    OmegaConf.create(dataset)
    sampler = hydra.utils.instantiate(
        {
            "shuffle": True,
            "_target_": "__main__.Sampler"
        },
        data_source=dataset,
        _convert_="all",
    )
    print(sampler)
