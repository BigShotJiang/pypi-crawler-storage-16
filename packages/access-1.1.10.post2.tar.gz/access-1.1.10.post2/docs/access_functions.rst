.. _afunctions:

.. currentmodule:: access

Listing of Internal Access Functions
====================================

.. autosummary::
   :toctree: generated/

    raam.raam
    fca.weighted_catchment
    fca.fca_ratio
    fca.two_stage_fca
    fca.three_stage_fca
    


