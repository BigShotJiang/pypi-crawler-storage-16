.. _access_class:

Access Class API
----------------

.. autoclass:: access.Access
   :members: weighted_catchment, fca_ratio, two_stage_fca, enhanced_two_stage_fca, three_stage_fca, raam, score, create_euclidean_distance, create_euclidean_distance_neighbors, append_user_cost, append_user_cost_neighbors
   
   .. automethod:: __init__


