# ACCESS-CI Djando user admin integrated with ACCESS Allocations User API

This tool is designed to be imported into ACCESS-CI Django apps to query an API for user information then select a result for inclusion in users and social-account tables
