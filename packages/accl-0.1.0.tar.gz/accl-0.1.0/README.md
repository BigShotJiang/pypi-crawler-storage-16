# accl

Curriculum question generation engine.

This is a test release of the `accl` package.
