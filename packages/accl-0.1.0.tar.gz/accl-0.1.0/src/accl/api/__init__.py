# src/api/__init__.py

from .app import app

__all__ = ["app"]
