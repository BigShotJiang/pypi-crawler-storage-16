# RUN_PLAN = {
#     "datatables": ["stat_prob_yr10", "measures_yr10", "patterns_relationships_sequences_yr10"],
#     "charts": ["patterns_relationships_sequences_yr10", "measures_yr10"],
#     "angles": ["measures_yr10"],
# }

RUN_PLAN = {
    "datatables": ["stat_prob_yr10"],
}
