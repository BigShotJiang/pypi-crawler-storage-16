# Contributing

Pull requests are welcome.

But it's best to open an issue to discuss proposed changes, before putting in the work.
That way we're on the same page and your code is more likely to be merged.
