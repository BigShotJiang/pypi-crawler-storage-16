mod accord;
use accord::app::App;

fn main() {
    App::main();
}