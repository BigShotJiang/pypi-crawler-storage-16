"""BBMD Manager - CLI tool for managing BACnet BBMDs and their BDTs."""

__version__ = "0.1.0"
