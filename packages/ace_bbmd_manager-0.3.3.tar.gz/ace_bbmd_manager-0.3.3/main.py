"""Main entry point for BBMD Manager."""

from bbmd_manager.cli import main

if __name__ == "__main__":
    main()
