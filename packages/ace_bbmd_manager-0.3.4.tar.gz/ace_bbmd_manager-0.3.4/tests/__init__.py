"""Tests for BBMD Manager."""
