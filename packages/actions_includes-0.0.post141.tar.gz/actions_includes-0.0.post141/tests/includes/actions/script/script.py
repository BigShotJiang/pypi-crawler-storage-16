print('Hello from Python!')
