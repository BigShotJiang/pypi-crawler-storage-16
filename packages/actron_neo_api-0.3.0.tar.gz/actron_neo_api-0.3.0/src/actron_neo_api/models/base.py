"""Base models and functionality for Actron Air API"""
