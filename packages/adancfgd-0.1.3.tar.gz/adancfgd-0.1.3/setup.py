from setuptools import setup

# This is a simple setup.py file for backward compatibility
# The actual configuration is in pyproject.toml and setup.cfg

if __name__ == "__main__":
    setup()
