## 👥 Authors

The current maintainers of Adaptive are:

- [Bas Nijholt](<http://nijho.lt>) ([@basnijholt](https://github.com/basnijholt))
- [Joseph Weston](<https://joseph.weston.cloud>) ([@jbweston](https://github.com/jbweston))
- [Anton Akhmerov](<https://antonakhmerov.org>) ([@akhmerov](https://github.com/akhmerov))

Other contributors to Adaptive include:

- Andrey E. Antipov ([@aeantipov](https://github.com/aeantipov))
- [Christoph Groth](<http://inac.cea.fr/Pisp/christoph.groth/>)
- Jorn Hoofwijk ([@jhoofwijk](https://github.com/jhoofwijk))
- Philippe Solodov ([@philippeitis](https://github.com/philippeitis))
- Victor Negîrneac ([@caenrigen](https://github.com/caenrigen))
- Thomas A Caswell ([@tacaswell](https://github.com/tacaswell))
- Álvaro Gómez Iñesta ([@AlvaroGI](https://github.com/AlvaroGI))
- Sultan Orazbayev ([@SultanOrazbayev](https://github.com/SultanOrazbayev))
- Thomas Aarholt ([@thomasaarholt](https://github.com/thomasaarholt))
- Andrea Maiani ([@maiani](https://github.com/maiani))
- Juan Daniel Torres ([@juandaanieel](https://github.com/juandaanieel))
- Davide Sandonà ([@juandaanieel](https://github.com/Davide-sd))
- Pieter Eendebak ([@eendebakpt](https://github.com/eendebakpt))
