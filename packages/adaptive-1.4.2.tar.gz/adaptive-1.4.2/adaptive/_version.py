from pathlib import Path

import versioningit

REPO_ROOT = Path(__file__).parent.parent
__version__ = "1.4.2"
