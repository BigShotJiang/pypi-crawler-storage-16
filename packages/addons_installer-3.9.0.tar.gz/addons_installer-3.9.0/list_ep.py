import importlib_metadata as md

print(md.entry_points(group="environ_odoo_config.extension"))
