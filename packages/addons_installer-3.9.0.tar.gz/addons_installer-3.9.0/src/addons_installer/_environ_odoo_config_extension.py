from __future__ import annotations

import logging
from pathlib import Path

from environ_odoo_config.environ import Environ
from environ_odoo_config.odoo_config import OdooConfigExtension, OdooEnvConfig

from addons_installer import addons_installer

_logger = logging.getLogger(__name__)


class AutoFindAddonPathFromInstallerExtension(OdooConfigExtension):
    def apply_extension(self, environ: Environ, odoo_config: "OdooEnvConfig"):
        super().apply_extension(environ, odoo_config)
        addons_path = set()
        results = addons_installer.AddonsFinder.parse_env(env_vars=environ)
        for result in results:
            subs = set(addons_installer.AddonsFinder.parse_submodule([result]))
            addons_path.add(Path(result.addons_path))
            addons_path.update({Path(sub.addons_path) for sub in subs})
        odoo_config.addons_path.addons_path.update(addons_path)
