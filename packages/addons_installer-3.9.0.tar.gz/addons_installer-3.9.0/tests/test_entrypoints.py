import unittest
from pathlib import Path

try:
    from environ_odoo_config import odoo_config
    from addons_installer._environ_odoo_config_extension import AutoFindAddonPathFromInstallerExtension
    import_ok = True
except ImportError:
    import_ok = False

@unittest.skipIf(not import_ok, "Install environ_odoo_config to run this test")
class AutofindAddons(unittest.TestCase):

    def setUp(self):
        self.lib_path = Path(__file__).parent.parent
        self.lib_path_src = self.lib_path / "src"


    def test_extension(self):
        config = odoo_config.OdooEnvConfig({
            "ADDONS_LOCAL": str(self.lib_path_src)
        })
        self.assertFalse(config.addons_path.addons_path)
        config.apply_extension(AutoFindAddonPathFromInstallerExtension)
        expected = {self.lib_path_src}
        found = config.addons_path.addons_path
        self.assertEqual(found, {*found, *expected})

    def test_ep_ok(self):
        self.assertTrue(self.lib_path_src.exists())
        config = odoo_config.OdooEnvConfig({
            "ADDONS_LOCAL": str(self.lib_path_src)
        })
        self.assertFalse(config.addons_path.addons_path)
        config.apply_all_extension()
        expected = {self.lib_path_src}
        found = config.addons_path.addons_path
        self.assertEqual(found, {*found, *expected})
