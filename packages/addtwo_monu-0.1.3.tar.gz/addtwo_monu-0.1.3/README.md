# addtwo

Tiny package to add two numbers.

Usage:

```py
from addtwo import add
print(add(2, 3))  # 5
