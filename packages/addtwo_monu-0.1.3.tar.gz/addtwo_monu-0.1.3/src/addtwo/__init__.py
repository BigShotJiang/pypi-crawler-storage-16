"""addtwo – tiny package to add two numbers."""
from .core import add

__all__ = ["add"]

# package version
__version__ = "0.1.0"

 




