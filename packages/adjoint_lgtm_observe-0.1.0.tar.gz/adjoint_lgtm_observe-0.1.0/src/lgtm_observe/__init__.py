"""
lgtm-observe: Unified CLI for LGTM observability stack.

Query Loki, Tempo, Prometheus, and Kafka from your terminal.
"""

__version__ = "0.1.0"
