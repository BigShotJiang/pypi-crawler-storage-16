"""Tests for lgtm-observe."""
