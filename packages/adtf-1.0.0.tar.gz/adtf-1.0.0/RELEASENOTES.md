# Release Notes

## Version History

### 1.0.0

- Initial release

## Known Issues / Restrictions

- none (initial version)
