'''
Welcome to Advanced Debug.
Licensed with MIT

Change Logs:
	- Hot-fix of 0.1.6
	- Added new type "Notification"
'''

__version__ = '0.1.7'

from datetime import datetime
from enum import Enum

class AdvDBG:
	
	def __init__(self, title='DEBUG', activated=False, notify=False):
		if isinstance(title, str) and isinstance(activated, bool) and isinstance(notify, bool):
			self.title = title
			self.activated = False
			self._defed = False
			self.notify = notify
		else:
			return False, 'Some parameters is not matches with required '
		
	@classmethod
	def define(cls, title='DEBUG', activated=True, notify=False):
		'''Defines your debug category.
		:param title: Title of your category
		:param activated: Toggle availability of category
		:param notify: Toggles notification if category is not activated'''
		inst = cls(title, activated, notify)
		inst.title = title
		inst.activated = True
		inst.notify = notify
		return inst
		
	def info(self, text):
			"""Print debug information
			Type: INFO
		
			:param text: Text to show"""
			if not isinstance(text, str):
				try:
						text = str(text)
				except Exception as e:
						text = f"Cannot convert to string format: {e}"
		
			if self.activated:
				print(f'[\033[90mINFO \033[95m{self.title} at {datetime.now().strftime("%D, %H:%M:%S")}\033[0m] {text} \033[0m')
			elif self.notify:
				print(f'Notification from {self.title}: Tryed to output when disactivated.\n\033[93mTip: \033[0mIf you are did not want to saw these notifications, turn off NOTIFY property with using notify=False\033[0m')
			else:
				return
	def warn(self, text):
			if not isinstance(text, str):
					try:
						text = str(text)
					except Exception as e:
						text = f"Cannot convert to string format: {e}"
			
			if self.activated:
				print(f'[\033[90mWARN \033[33m{self.title} at {datetime.now().strftime('%D, %H:%M:%S')}\033[0m] {text}')
				
			elif self.notify:
				print(f'Notification from {self.title}: Tryed to output when disactivated.\n\033[93mTip: \033[0mIf you are did not want to saw these notifications, turn off NOTIFY property with using notify=False')
			else:
				return
				
	def error(self, text):
			if not isinstance(text, str):
					try:
						text = str(text)
					except Exception as e:
						text = f"Cannot convert to string format: {e}"
						
			if self.activated:
				print(f'[\033[90mERROR \033[31m{self.title} at {datetime.now().strftime('%D, %H:%M:%S')}\033[0m] \033[91m{text}\033[0m')
				
			elif self.notify:
				print(f'Notification from {self.title}: Tryed to output when disactivated.\n\033[93mTip: \033[0mIf you are did not want to saw these notifications, turn off NOTIFY property with using notify=False')
			else:
				return
		
	def notification(self, text):
			if not isinstance(text, str):
					try:
						text = str(text)
					except Exception as e:
						text = f"Cannot convert to string format: {e}"
						
			if self.activated:
				print(f'[\033[94mNOTIFICATION \033[0m{self.title} at {datetime.now().strftime('%D, %H:%M:%S')}\033[0m] \033[94m{text}\033[0m')
				
			elif self.notify:
				print(f'Notification from {self.title}: Tryed to output when disactivated.\n\033[93mTip: \033[0mIf you are did not want to saw these notifications, turn off NOTIFY property with using notify=False')
			else:
				return
		
	def cfg(self, activated=None, title=None, notify=True):
		'''Configure existing category'''
		if activated is not None:
			self.activated = activated
			if self.activated is False:
				self.notify = notify
		elif title is not None:
			self.title = title
		return self
			
	def __call__(self, text):
		if not isinstance(text, str):
					try:
						text = str(text)
					except Exception as e:
						text = f"Cannot convert to string format: {e}"
		self.output(text)
		
DebuGGer = AdvDBG