from . import AEEv8
__version__ = "8.0.0b1"