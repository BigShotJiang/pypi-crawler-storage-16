# Aelion Calc

**Aelion Calc** is a Python library designed for students. It simplifies common calculations in Mathematics, Health, and Computer Science, allowing you to focus on learning rather than writing boilerplate formulas.

## Installation

You can install the library using pip:

```bash
pip install aelion_calc