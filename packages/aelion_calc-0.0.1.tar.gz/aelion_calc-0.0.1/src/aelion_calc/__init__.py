from . import math_tools
from . import health
from . import cs_basics
from . import dal
from .say import say, t, dt
from . import manual          # <--- NEW ADDITION

__version__ = "0.1.6"