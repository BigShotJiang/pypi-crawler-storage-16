import sys
import time

# --- CONSTANTS FOR USERS ---
dt = "TYPE_CHECK_MODE"  # The special object for checking types

# --- ANSI CODES ---
COLORS = {
    'red': '\033[91m',
    'green': '\033[92m',
    'yellow': '\033[93m',
    'blue': '\033[94m',
    'cyan': '\033[96m',
    'magenta': '\033[95m',
    'white': '\033[97m',
    'black': '\033[30m',
    'reset': '\033[0m'
}

STYLES = {
    'bold': '\033[1m',
    'underline': '\033[4m',
    'italic': '\033[3m',
    'reset': '\033[0m'
}

def _get_type_name(obj):
    """Internal helper to get clean type name."""
    t = type(obj).__name__
    if t == 'str': return "STRING"
    if t == 'int': return "INTEGER"
    if t == 'float': return "FLOAT"
    if t == 'bool': return "BOOLEAN"
    if t == 'list': return "LIST"
    if t == 'dict': return "DICTIONARY"
    return t.upper()

def t(*args, **kwargs):
    """
    Short alias for normal styled printing. 
    Usage: t("Hello", color="red")
    """
    say(*args, **kwargs)

def say(*args, sep=' ', end='\n', color=None, style=None, loop=False):
    """
    Advanced Print Function.
    
    Modes:
    1. Normal: say("Hello", color='red')
    2. Type Check: say(my_var, dt)
    3. Sequence: say(start, increment, stop, loop=True)
    """
    
    # --- MODE 1: TYPE CHECKING ---
    # Check if the special 'dt' variable is the second argument
    if len(args) == 2 and args[1] == "TYPE_CHECK_MODE":
        obj = args[0]
        type_name = _get_type_name(obj)
        
        # Print with a default style for types
        formatted_text = f"{COLORS['cyan']}Type: {type_name}{COLORS['reset']}"
        sys.stdout.write(formatted_text + end)
        return

    # --- MODE 2: NUMBER SEQUENCE ---
    # Usage: say(start, inc, stop, loop=True)
    if loop:
        if len(args) != 3:
            raise ValueError("Loop mode requires 3 arguments: say(start, inc, stop, loop=True)")
        
        start, inc, stop = args
        
        # Generate and print the sequence
        current = start
        while current <= stop:
            sys.stdout.write(f"{current}")
            if current + inc <= stop:
                sys.stdout.write(", ")
            current += inc
        sys.stdout.write(end)
        return

    # --- MODE 3: NORMAL STYLED PRINT ---
    # Apply Color
    start_code = ""
    if color and color.lower() in COLORS:
        start_code += COLORS[color.lower()]
    
    # Apply Style
    if style and style.lower() in STYLES:
        start_code += STYLES[style.lower()]
        
    # Build string
    text = sep.join(map(str, args))
    
    # Print logic
    if start_code:
        sys.stdout.write(f"{start_code}{text}{COLORS['reset']}{end}")
    else:
        sys.stdout.write(f"{text}{end}")