"""Format library for af_analysis.format module."""
