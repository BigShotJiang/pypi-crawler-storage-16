from .parser import AffiliationRegexParser
from ._version import __version__  

__all__ = ["AffiliationRegexParser", "__version__"]


