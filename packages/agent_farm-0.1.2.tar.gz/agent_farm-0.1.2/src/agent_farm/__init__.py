def hello() -> str:
    return "Hello from farmer-agent!"
