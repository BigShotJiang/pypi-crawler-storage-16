# Get Started with Microsoft Agent Framework Declarative

Please install this package via pip:

```bash
pip install agent-framework-declarative --pre
```

## Declarative features

The declarative packages provides support for building agents based on a declarative yaml specification.
