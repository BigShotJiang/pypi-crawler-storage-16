# Copyright (c) Microsoft. All rights reserved.

"""Entry point for running the AG-UI examples server as a module."""

from .server.main import main

if __name__ == "__main__":
    main()
