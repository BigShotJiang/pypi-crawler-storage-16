"""
PDF generation tool with automatic image embedding from file storage.

This tool extends the PDF generation capabilities to automatically embed
images from file storage using file IDs, with adaptive sizing support
for optimal PDF rendering.
"""

import logging
import base64
import re
from typing import Callable, Literal, Optional

from .base import AgentTool, ToolDependencyError
from .pdf_image_scaler import PDFImageScaler
from .adaptive_pdf_css import AdaptivePDFCSS
from .sizing_config import ImageSizingConfig

# Optional dependencies
try:
    from weasyprint import HTML

    WEASYPRINT_AVAILABLE = True
    WEASYPRINT_ERROR = None
except (ImportError, OSError) as e:
    WEASYPRINT_AVAILABLE = False
    WEASYPRINT_ERROR = str(e)

# Optional PIL for image processing
try:
    from PIL import Image
    import io

    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

logger = logging.getLogger(__name__)

# Type alias for size preferences
SizePreference = Literal["small", "medium", "large", "full"]


class CreatePDFWithImagesTool(AgentTool):
    """Tool for creating PDF documents from HTML with automatic image embedding.

    This tool supports adaptive image sizing with the following features:
    - Size preferences (small=50%, medium=75%, large/full=100% of page width)
    - Automatic downsampling of large images (>4000px)
    - Centered images with consistent vertical spacing
    - Dimension metadata reading from stored images
    """

    def __init__(self, config: ImageSizingConfig | None = None):
        """Initialize the tool with optional custom configuration.

        Args:
            config: Custom sizing configuration. If None, uses defaults.
        """
        super().__init__()
        self.config = config or ImageSizingConfig()
        self.image_scaler = PDFImageScaler(self.config)
        self.css_generator = AdaptivePDFCSS(self.config)

    def get_tool_function(self) -> Callable:
        """Return the PDF creation function with image support."""

        async def create_pdf_with_images(
            title: str,
            html_content: str,
            author: Optional[str] = None,
            image_size: SizePreference = "large",
        ) -> str:
            """
            Create a PDF document from HTML content with automatic image embedding.

            This tool automatically detects file_id references in img tags and
            replaces them with embedded data URIs. Images are adaptively sized
            based on the image_size parameter.

            Args:
                title: Document title
                html_content: HTML content with special img tags using file_id
                             Format: <img src="file_id:YOUR_FILE_ID" alt="...">
                author: Optional author name
                image_size: Image sizing preference:
                           - "small": 50% of page width
                           - "medium": 75% of page width
                           - "large": 100% of page width (default)
                           - "full": 100% of page width

            Returns:
                Success message with file_id

            Example usage:
                1. Create a chart and get file_id: abc-123
                2. Create HTML with: <img src="file_id:abc-123" alt="Chart">
                3. Call this tool - it will automatically embed the image

            Example HTML:
                <h1>Report</h1>
                <p>Here is the chart:</p>
                <img src="file_id:abc-123" alt="Sales Chart">
                <p>Analysis follows...</p>
            """
            self._ensure_initialized()

            # Check for required dependencies
            if not WEASYPRINT_AVAILABLE:
                error_msg = "Error: WeasyPrint is not available. "
                if WEASYPRINT_ERROR and "libgobject" in WEASYPRINT_ERROR:
                    error_msg += "System dependencies are missing. Install them with:\n"
                    error_msg += "  macOS: brew install pango gdk-pixbuf libffi\n"
                    error_msg += (
                        "  Ubuntu/Debian: sudo apt-get install libpango-1.0-0 libpangoft2-1.0-0\n"
                    )
                else:
                    error_msg += "Install with: uv add weasyprint"
                return error_msg

            # Validate inputs
            if not title or not title.strip():
                return "Error: Title cannot be empty"

            if not html_content or not html_content.strip():
                return "Error: HTML content cannot be empty"

            # Validate image_size parameter (Requirement 6.4 - default to "large")
            valid_sizes = ("small", "medium", "large", "full")
            if image_size not in valid_sizes:
                logger.warning(f"Invalid image_size '{image_size}', defaulting to 'large'")
                image_size = "large"

            # Check file storage availability
            if not self.file_storage:
                raise ToolDependencyError(
                    "File storage is required but was not provided. "
                    "Ensure file_storage is set via set_context()."
                )

            try:
                # Find all file_id references in img tags
                # Pattern: <img src="file_id:SOME-UUID" ...>
                file_id_pattern = r'src="file_id:([a-f0-9\-]+)"'
                matches = re.findall(file_id_pattern, html_content)

                logger.info(f"Found {len(matches)} file_id references in HTML")

                # Replace each file_id with actual data URI
                processed_html = html_content
                for file_id in matches:
                    try:
                        logger.info(f"Retrieving file {file_id} for embedding")

                        # Retrieve file content and metadata
                        content, metadata = await self.file_storage.retrieve_file(file_id)

                        # Read dimension metadata if available (Requirement 8.3)
                        original_width = None
                        original_height = None
                        if hasattr(metadata, "extra") and metadata.extra:
                            original_width = metadata.extra.get("width_px")
                            original_height = metadata.extra.get("height_px")
                            content_type = metadata.extra.get("content_type", "unknown")
                            logger.info(
                                f"Image metadata: {original_width}x{original_height}, "
                                f"type={content_type}"
                            )

                        # Process image: downsample if needed
                        processed_content = self._process_image_for_pdf(
                            content, original_width, original_height
                        )

                        # Encode as base64
                        base64_content = base64.b64encode(processed_content).decode("utf-8")

                        # Get MIME type
                        mime_type = metadata.mime_type or "application/octet-stream"

                        # Create data URI
                        data_uri = f"data:{mime_type};base64,{base64_content}"

                        # Replace in HTML
                        old_src = f'src="file_id:{file_id}"'
                        new_src = f'src="{data_uri}"'
                        processed_html = processed_html.replace(old_src, new_src)

                        logger.info(
                            f"Embedded file {file_id} ({metadata.filename}, "
                            f"{len(base64_content)} base64 chars)"
                        )

                    except Exception as e:
                        logger.error(f"Failed to embed file {file_id}: {e}")
                        return f"Error: Failed to embed image {file_id}: {str(e)}"

                # Wrap in complete HTML document if needed
                if not processed_html.strip().upper().startswith("<!DOCTYPE"):
                    # Generate adaptive CSS
                    adaptive_css = self.css_generator.generate_complete_css(
                        size_preference=image_size,
                        vertical_margin_px=20,
                        include_base_styles=True,
                    )

                    # Add additional base styles
                    additional_css = """
                        code {
                            background-color: #f5f5f5;
                            padding: 2pt 4pt;
                            border-radius: 3pt;
                        }
                        table {
                            border-collapse: collapse;
                            width: 100%;
                            margin: 12pt 0;
                        }
                        th, td {
                            border: 1pt solid #ddd;
                            padding: 8pt;
                            text-align: left;
                        }
                    """

                    processed_html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{title}</title>
    <style>
{adaptive_css}
{additional_css}
    </style>
</head>
<body>
    {processed_html}
</body>
</html>"""

                # Generate PDF
                pdf_bytes = HTML(string=processed_html).write_pdf()

                # Create filename
                safe_title = "".join(
                    c for c in title if c.isalnum() or c in (" ", "-", "_")
                ).strip()
                safe_title = safe_title.replace(" ", "_")
                filename = f"{safe_title}.pdf"

                # Store PDF
                tags = ["pdf", "generated", "html", "with-images"]
                if author:
                    tags.append(f"author:{author}")
                if matches:
                    tags.append(f"embedded-images:{len(matches)}")
                tags.append(f"image-size:{image_size}")

                file_id = await self.file_storage.store_file(
                    content=pdf_bytes,
                    filename=filename,
                    user_id=self.current_user_id,
                    session_id=self.current_session_id,
                    mime_type="application/pdf",
                    tags=tags,
                    is_generated=True,
                )

                logger.info(
                    f"Created PDF with {len(matches)} embedded images: "
                    f"{filename} (file_id: {file_id}, image_size: {image_size})"
                )
                return (
                    f"PDF created successfully with {len(matches)} embedded image(s)! "
                    f"File ID: {file_id}, Filename: {filename}"
                )

            except Exception as e:
                error_msg = f"Failed to create PDF: {str(e)}"
                logger.error(error_msg, exc_info=True)
                return f"Error creating PDF: {str(e)}"

        return create_pdf_with_images

    def _process_image_for_pdf(
        self,
        image_bytes: bytes,
        original_width: int | None,
        original_height: int | None,
    ) -> bytes:
        """Process image for PDF embedding, downsampling if needed.

        Args:
            image_bytes: Original image bytes
            original_width: Original width from metadata (optional)
            original_height: Original height from metadata (optional)

        Returns:
            Processed image bytes (possibly downsampled)
        """
        if not PIL_AVAILABLE:
            logger.debug("PIL not available, skipping image processing")
            return image_bytes

        try:
            # Get actual dimensions from image if not provided in metadata
            img = Image.open(io.BytesIO(image_bytes))
            actual_width, actual_height = img.size

            # Use metadata dimensions if available, otherwise use actual
            width = original_width or actual_width
            height = original_height or actual_height

            logger.info(f"Processing image for PDF: {width}x{height}")

            # Check if downsampling is needed (Requirement 7.1)
            if self.image_scaler.should_downsample(width, height):
                logger.info(
                    f"Image exceeds {self.config.pdf_max_image_dimension}px, downsampling..."
                )
                return self.image_scaler.downsample_image(
                    image_bytes, self.config.pdf_max_image_dimension
                )

            return image_bytes

        except Exception as e:
            logger.warning(f"Failed to process image, using original: {e}")
            return image_bytes


__all__ = ["CreatePDFWithImagesTool"]
