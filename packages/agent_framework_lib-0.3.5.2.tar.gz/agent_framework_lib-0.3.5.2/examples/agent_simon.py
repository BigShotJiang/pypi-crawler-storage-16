import asyncio
import os
from typing import Any, Dict, List, Optional

from agent_framework.implementations import LlamaIndexAgent
from agent_framework.storage.file_system_management import FileStorageFactory
from agent_framework.memory import MemoryConfig

from agent_framework.tools import (
    CreateFileTool,
    ListFilesTool,
    ReadFileTool,
    CreatePDFFromMarkdownTool,
    CreatePDFFromHTMLTool,
    ChartToImageTool,
    GetFilePathTool,
    CreatePDFWithImagesTool,
    MermaidToImageTool,
    TableToImageTool
)


class AgentSimon(LlamaIndexAgent):
    def __init__(self):
        super().__init__(
            agent_id="Agent-simon-v1",
            name="Agent basé sur le schéma slack envoyé par simon",
            description="Agent basé sur le schéma slack envoyé par simon"
        )
        self.current_user_id = "default_user"
        self.current_session_id = None
        self.mcp_tools = []
        self.mcp_clients = {}
        self._mcp_initialized = False
        self.file_storage = None
        self.tools_files_storage = [
            CreateFileTool(),
            ListFilesTool(),
            ReadFileTool(),
            CreatePDFFromMarkdownTool(),
            CreatePDFFromHTMLTool(),
            ChartToImageTool(),
            GetFilePathTool(),
            CreatePDFWithImagesTool(),
            MermaidToImageTool(),
            TableToImageTool()
        ]

    def get_memory_config(self):
        return MemoryConfig.hybrid(
            memori_database_url="sqlite:///hybrid_agent_memory.db",
            graphiti_use_falkordb=True,
            passive_injection=True,
            async_store=True,
            passive_injection_primary_only=True,
        )

    async def _ensure_file_storage(self):
        if self.file_storage is None:
            self.file_storage = await FileStorageFactory.create_storage_manager()

    async def configure_session(self, session_configuration: Dict[str, Any]) -> None:
        self.current_user_id = session_configuration.get('user_id', 'default_user')
        self.current_session_id = session_configuration.get('session_id')
        await self._ensure_file_storage()
        for tool in self.tools_files_storage:
            tool.set_context(
                file_storage=self.file_storage,
                user_id=self.current_user_id,
                session_id=self.current_session_id
            )
        await super().configure_session(session_configuration)

    async def _initialize_mcp_tools(self):
        if self._mcp_initialized:
            return

        try:
            from llama_index.tools.mcp import BasicMCPClient, McpToolSpec
        except ImportError:
            print("⚠️ llama-index-tools-mcp not available. Install with: uv add llama-index-tools-mcp")
            self.mcp_tools = []
            return

        print("🔌 Initializing MCP tools...")
        self.mcp_tools = []

        # 1. Serveurs stdio (command + args)
        stdio_configs = self._get_mcp_server_config() or []
        for mcp_config in stdio_configs:
            server_name = mcp_config.get("name", "unknown")
            try:
                print(f"🔌 Connecting to stdio MCP server: {server_name}...")
                client = BasicMCPClient(
                    mcp_config["command"],
                    args=mcp_config.get("args", []),
                    env=mcp_config.get("env", {})
                )
                self.mcp_clients[server_name] = client

                mcp_tool_spec = McpToolSpec(client=client)
                function_tools = await mcp_tool_spec.to_tool_list_async()

                if function_tools:
                    self.mcp_tools.extend(function_tools)
                    print(f"✅ MCP server '{server_name}': {len(function_tools)} tools loaded")
                else:
                    print(f"⚠️ No tools found from MCP server '{server_name}'")
            except Exception as e:
                print(f"❌ Failed to connect to stdio MCP server '{server_name}': {e}")

        # 2. Serveurs HTTP/SSE
        http_configs = self._get_mcp_http_server_config() or []
        for mcp_config in http_configs:
            server_name = mcp_config.get("name", "unknown")
            try:
                print(f"🔌 Connecting to SSE MCP server: {server_name}...")
                # BasicMCPClient supporte aussi les URLs SSE directement
                client = BasicMCPClient(mcp_config["url"])
                self.mcp_clients[server_name] = client

                mcp_tool_spec = McpToolSpec(client=client)
                function_tools = await mcp_tool_spec.to_tool_list_async()

                if function_tools:
                    self.mcp_tools.extend(function_tools)
                    print(f"✅ SSE MCP server '{server_name}': {len(function_tools)} tools loaded")
                else:
                    print(f"⚠️ No tools found from SSE MCP server '{server_name}'")
            except Exception as e:
                print(f"❌ Failed to connect to SSE MCP server '{server_name}': {e}")

        self._mcp_initialized = True
        print(f"📊 MCP Tools initialized: {len(self.mcp_tools)} tools available")

    def _get_mcp_server_config(self) -> Optional[List[Dict[str, Any]]]:
        """Retourne la config des serveurs MCP stdio uniquement."""
        return [
            {
                "name": "neo4j",
                "command": "uvx",
                "args": ["mcp-neo4j-cypher@0.5.1", "--transport", "stdio"],
                "env": {
                    "NEO4J_URI": "neo4j+s://92c380c6.databases.neo4j.io",
                    "NEO4J_USERNAME": os.getenv("NEO4J_USERNAME", "neo4j"),
                    "NEO4J_PASSWORD": os.getenv("NEO4J_PASSWORD", "Sd6JI1bMVGG6kqFM6uox3FwtZ8dH_Sci4-vUx31-wsI"),
                    "NEO4J_DATABASE": os.getenv("NEO4J_DATABASE", "neo4j")
                }
            },
            {
                "name": "python-runner",
                "command": "uvx",
                "args": ["mcp-run-python"],
            },
        ]

    def _get_mcp_http_server_config(self) -> Optional[List[Dict[str, Any]]]:
        """Retourne la config des serveurs MCP HTTP/SSE."""
        return [
            {
                "name": "github",
                "type": "sse",
                "url": "https://api.githubcopilot.com/mcp/",
            },
            {
                "name": "atlassian",
                "type": "sse",
                "url": "https://mcp.atlassian.com/v1/sse",
            }
        ]

    def get_agent_prompt(self) -> str:
        return "You are an Assistant with multiple capacity. You have to choose the right tools to response the user demands."

    def get_agent_tools(self) -> List[callable]:
        return [tool.get_tool_function() for tool in self.tools_files_storage]

    async def initialize_agent(self, model_name: str, system_prompt: str, tools: List[callable], **kwargs) -> None:
        await self._initialize_mcp_tools()
        all_tools = list(tools) + self.mcp_tools
        await super().initialize_agent(model_name, system_prompt, all_tools, **kwargs)


def main():
    if not os.getenv("OPENAI_API_KEY"):
        print("Error: OPENAI_API_KEY environment variable not set")
        print("Please set it with: export OPENAI_API_KEY=your-key-here")
        return

    from agent_framework import create_basic_agent_server

    port = int(os.getenv("AGENT_PORT", "8200"))

    print("=" * 60)
    print("🚀 Starting MCP multi skills Server")
    print("=" * 60)
    print(f"📊 Model: {os.getenv('DEFAULT_MODEL', 'gpt-5')}")
    print(f"🌐 Server: http://localhost:{port}")
    print(f"🎨 UI: http://localhost:{port}/ui")
    print("=" * 60)

    create_basic_agent_server(
        agent_class=AgentSimon,
        host="0.0.0.0",
        port=port,
        reload=False
    )


if __name__ == "__main__":
    main()
