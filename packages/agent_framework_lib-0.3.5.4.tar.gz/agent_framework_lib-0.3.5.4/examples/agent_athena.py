import asyncio
import os
from typing import Any, Dict, List, Optional

from agent_framework.implementations import LlamaIndexAgent
from agent_framework.storage.file_system_management import FileStorageFactory
from agent_framework.memory import MemoryConfig

from agent_framework.tools import (
    CreateFileTool,
    ListFilesTool,
    ReadFileTool,
    CreatePDFFromMarkdownTool,
    CreatePDFFromHTMLTool,
    ChartToImageTool,
    GetFilePathTool,
    CreatePDFWithImagesTool,
    MermaidToImageTool,
    TableToImageTool
)


class AgentSimon(LlamaIndexAgent):
    def __init__(self):
        super().__init__(
            agent_id="Agent-Athena-v1",
            name="Agent pour requeté une base de donnée Athena",
            description="Agent Permet d'accéder au données d'Athena sur AWS et de les traiters avec itnelligences et pertinence notamment pour générer des documents"
        )
        self.current_user_id = "default_user"
        self.current_session_id = None
        self.mcp_tools = []
        self.mcp_clients = {}
        self._mcp_initialized = False
        self.file_storage = None
        self.tools_files_storage = [
            CreateFileTool(),
            ListFilesTool(),
            ReadFileTool(),
            CreatePDFFromMarkdownTool(),
            CreatePDFFromHTMLTool(),
            ChartToImageTool(),
            GetFilePathTool(),
            CreatePDFWithImagesTool(),
            MermaidToImageTool(),
            TableToImageTool()
        ]

    def get_memory_config(self):
        return MemoryConfig.hybrid(
            memori_database_url="sqlite:///hybrid_agent_memory.db",
            graphiti_use_falkordb=True,
            passive_injection=True,
            async_store=True,
            passive_injection_primary_only=True,
        )

    async def _ensure_file_storage(self):
        if self.file_storage is None:
            self.file_storage = await FileStorageFactory.create_storage_manager()

    async def configure_session(self, session_configuration: Dict[str, Any]) -> None:
        self.current_user_id = session_configuration.get('user_id', 'default_user')
        self.current_session_id = session_configuration.get('session_id')
        await self._ensure_file_storage()
        for tool in self.tools_files_storage:
            tool.set_context(
                file_storage=self.file_storage,
                user_id=self.current_user_id,
                session_id=self.current_session_id
            )
        await super().configure_session(session_configuration)

    async def _initialize_mcp_tools(self):
        """Initialize MCP tools from configured servers."""
        if self._mcp_initialized:
            return
        
        try:
            from llama_index.tools.mcp import BasicMCPClient, McpToolSpec
        except ImportError:
            print("⚠️ llama-index-tools-mcp not available. Install with: uv add llama-index-tools-mcp")
            self.mcp_tools = []
            return
        
        print("🔌 Initializing MCP tools...")
        self.mcp_tools = []
        
        # Get MCP server configuration
        mcp_config = self._get_mcp_server_config()
        if not mcp_config:
            print("ℹ️ No MCP server configured")
            return
        
        try:
            print(f"🔌 Connecting to MCP server...")
            cmd = mcp_config["command"]
            args = mcp_config["args"]
            env = mcp_config.get("env", {})
            
            client = BasicMCPClient(cmd, args=args, env=env)
            self.mcp_clients["mcp_server"] = client
            
            # Use official LlamaIndex MCP approach
            mcp_tool_spec = McpToolSpec(client=client)
            function_tools = await mcp_tool_spec.to_tool_list_async()
            
            if function_tools:
                self.mcp_tools.extend(function_tools)
                print(f"✅ MCP server: {len(function_tools)} tools loaded")
            else:
                print("⚠️ No tools found from MCP server")
        except Exception as e:
            print(f"❌ Failed to connect to MCP server: {e}")
        
        self._mcp_initialized = True
        print(f"📊 MCP Tools initialized: {len(self.mcp_tools)} tools available")
    
    def _get_mcp_server_config(self) -> Optional[Dict[str, Any]]:
        """Get MCP server configuration with environment variables."""
    # This is an example with a mcp server with python 
        
        
        return [{
            "command": "uv",
            "args": [
                "run",
                "python",
                "-m",
                ""
            ],
            "env": {}
        }]

    def get_agent_prompt(self) -> str:
        return "Tu es un agent Athena qui a accès à une base de données et tu es la "

    def get_agent_tools(self) -> List[callable]:
        return [tool.get_tool_function() for tool in self.tools_files_storage]

    async def initialize_agent(self, model_name: str, system_prompt: str, tools: List[callable], **kwargs) -> None:
        await self._initialize_mcp_tools()
        all_tools = list(tools) + self.mcp_tools
        await super().initialize_agent(model_name, system_prompt, all_tools, **kwargs)


def main():
    if not os.getenv("OPENAI_API_KEY"):
        print("Error: OPENAI_API_KEY environment variable not set")
        print("Please set it with: export OPENAI_API_KEY=your-key-here")
        return

    from agent_framework import create_basic_agent_server

    port = int(os.getenv("AGENT_PORT", "8200"))

    print("=" * 60)
    print("🚀 Starting MCP multi skills Server")
    print("=" * 60)
    print(f"📊 Model: {os.getenv('DEFAULT_MODEL', 'gpt-5')}")
    print(f"🌐 Server: http://localhost:{port}")
    print(f"🎨 UI: http://localhost:{port}/ui")
    print("=" * 60)

    create_basic_agent_server(
        agent_class=AgentSimon,
        host="0.0.0.0",
        port=port,
        reload=False
    )


if __name__ == "__main__":
    main()
