"""Redis Agent Memory Server - A memory system for conversational AI."""

__version__ = "0.12.4"
