"""Game implementations for AgentDeck."""

from .examples import FixedDamageGame

__all__ = ["FixedDamageGame"]
