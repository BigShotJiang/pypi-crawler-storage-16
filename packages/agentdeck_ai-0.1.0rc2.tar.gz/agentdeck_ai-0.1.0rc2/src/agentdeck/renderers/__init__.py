"""Renderer implementations for AgentDeck."""

from .text_renderer import TextRenderer

__all__ = [
    "TextRenderer",
]
