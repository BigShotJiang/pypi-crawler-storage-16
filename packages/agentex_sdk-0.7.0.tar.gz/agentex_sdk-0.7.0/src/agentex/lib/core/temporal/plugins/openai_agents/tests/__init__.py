"""
Tests for the StreamingModel implementation in the OpenAI Agents plugin.
"""