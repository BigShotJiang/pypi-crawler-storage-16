from agentex.lib.adk.utils._modules.templating import TemplatingModule

__all__ = ["templating"]

templating = TemplatingModule()
