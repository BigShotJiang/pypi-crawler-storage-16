def test_discovery():
    """Sanity check that pytest can discover tests."""
    assert True