"""Digitalkin Protocol Buffer generated gRPC interfaces."""

from digitalkin_proto.__version__ import __version__

__all__ = ["__version__"]
