"""
Setup script for development installation.
This is a minimal setup.py for compatibility with older tools.
The main configuration is in pyproject.toml.
"""

from setuptools import setup

setup()
