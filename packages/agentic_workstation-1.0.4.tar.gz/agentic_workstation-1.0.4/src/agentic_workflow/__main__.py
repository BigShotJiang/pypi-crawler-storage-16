"""Entry point for: python -m agentic_workflow"""
from agentic_workflow.cli.main import cli

if __name__ == "__main__":
    cli()