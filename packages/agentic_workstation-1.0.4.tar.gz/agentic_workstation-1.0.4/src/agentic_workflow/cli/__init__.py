"""CLI module.

Contains shell script entry points for the workflow system.
These scripts are meant to be called directly from the command line.
"""

__all__ = []
