# -*- coding: utf-8 -*-
"""
@author:XuMing(xuming624@qq.com)
@description: 
"""
from .base import Knowledge
from .langchain_knowledge import LangChainKnowledge
from .llamaindex_knowledge import LlamaIndexKnowledge
