from agentica.model.internlm.chat import InternlmChat
