from agentica.model.vertexai.gemini import Gemini
