from agentify.extensions.prompts.assistant import assistant_prompt

__all__ = ["assistant_prompt"]
