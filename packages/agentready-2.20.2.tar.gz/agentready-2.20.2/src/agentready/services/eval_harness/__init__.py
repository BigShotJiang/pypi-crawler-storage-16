"""Terminal-Bench evaluation harness for assessor effectiveness testing."""
