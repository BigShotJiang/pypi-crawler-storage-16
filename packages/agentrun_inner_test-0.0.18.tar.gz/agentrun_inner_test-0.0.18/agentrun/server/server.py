"""AgentRun HTTP Server / AgentRun HTTP 服务器

基于 Router 的设计 / Router-based design:
- 每个协议提供自己的 Router / Each protocol provides its own Router
- Server 负责挂载 Router 并管理路由前缀 / Server mounts Routers and manages route prefixes
- 支持多协议同时运行 / Supports running multiple protocols simultaneously
"""

from typing import Any, Dict, List, Optional, Sequence

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

from agentrun.utils.log import logger

from .agui_protocol import AGUIProtocolHandler
from .invoker import AgentInvoker
from .openai_protocol import OpenAIProtocolHandler
from .protocol import InvokeAgentHandler, ProtocolHandler


class AgentRunServer:
    """AgentRun HTTP Server / AgentRun HTTP 服务器

    基于 Router 的架构 / Router-based architecture:
    - 每个协议提供完整的 FastAPI Router / Each protocol provides a complete FastAPI Router
    - Server 只负责组装和前缀管理 / Server only handles assembly and prefix management
    - 易于扩展新协议 / Easy to extend with new protocols

    Example (默认协议 / Default protocols - OpenAI + AG-UI):
        >>> def invoke_agent(request: AgentRequest):
        ...     return "Hello, world!"
        >>>
        >>> server = AgentRunServer(invoke_agent=invoke_agent)
        >>> server.start(port=8000)
        # 可访问 / Accessible:
        #   POST http://localhost:8000/openai/v1/chat/completions (OpenAI)
        #   POST http://localhost:8000/agui/v1/run (AG-UI)

    Example (自定义前缀 / Custom prefix):
        >>> server = AgentRunServer(
        ...     invoke_agent=invoke_agent,
        ...     prefix_overrides={"OpenAIProtocolHandler": "/api/v1"}
        ... )
        >>> server.start(port=8000)
        # 可访问 / Accessible: POST http://localhost:8000/api/v1/chat/completions

    Example (仅 OpenAI 协议 / OpenAI only):
        >>> server = AgentRunServer(
        ...     invoke_agent=invoke_agent,
        ...     protocols=[OpenAIProtocolHandler()]
        ... )
        >>> server.start(port=8000)

    Example (多协议 / Multiple protocols):
        >>> server = AgentRunServer(
        ...     invoke_agent=invoke_agent,
        ...     protocols=[
        ...         OpenAIProtocolHandler(),
        ...         AGUIProtocolHandler(),
        ...         CustomProtocolHandler(),
        ...     ]
        ... )
        >>> server.start(port=8000)

    Example (集成到现有 FastAPI 应用 / Integrate with existing FastAPI app):
        >>> from fastapi import FastAPI
        >>>
        >>> app = FastAPI()
        >>> agent_server = AgentRunServer(invoke_agent=invoke_agent)
        >>> app.mount("/agent", agent_server.as_fastapi_app())
        # 可访问 / Accessible: POST http://localhost:8000/agent/v1/chat/completions

    Example (配置 CORS / Configure CORS):
        >>> # 允许所有源（默认）/ Allow all origins (default)
        >>> server = AgentRunServer(invoke_agent=invoke_agent)
        >>>
        >>> # 指定允许的源 / Specify allowed origins
        >>> server = AgentRunServer(
        ...     invoke_agent=invoke_agent,
        ...     cors_origins=["http://localhost:3000", "https://myapp.com"]
        ... )
    """

    def __init__(
        self,
        invoke_agent: InvokeAgentHandler,
        protocols: Optional[List[ProtocolHandler]] = None,
        prefix_overrides: Optional[Dict[str, str]] = None,
        cors_origins: Optional[Sequence[str]] = None,
    ):
        """初始化 AgentRun Server / Initialize AgentRun Server

        Args:
            invoke_agent: Agent 调用回调函数 / Agent invocation callback function
                - 可以是同步或异步函数 / Can be synchronous or asynchronous function
                - 支持返回字符串、AgentResponse 或生成器 / Supports returning string, AgentResponse or generator

            protocols: 协议处理器列表 / List of protocol handlers
                - 默认使用 OpenAI 协议 / Default uses OpenAI protocol
                - 可以添加自定义协议 / Can add custom protocols

            prefix_overrides: 协议前缀覆盖 / Protocol prefix overrides
                - 格式 / Format: {协议类名 / protocol class name: 前缀 / prefix}
                - 例如 / Example: {"OpenAIProtocolHandler": "/api/v1"}

            cors_origins: CORS 允许的源列表 / List of allowed CORS origins
                - 默认允许所有源 ["*"] / Default allows all origins ["*"]
                - 可指定特定源 / Can specify specific origins
                - 例如 / Example: ["http://localhost:3000", "https://example.com"]
        """
        self.app = FastAPI(title="AgentRun Server")
        self.agent_invoker = AgentInvoker(invoke_agent)

        # 配置 CORS / Configure CORS
        self._setup_cors(cors_origins)

        # 默认使用 OpenAI 和 AG-UI 协议
        if protocols is None:
            protocols = [OpenAIProtocolHandler(), AGUIProtocolHandler()]

        self.prefix_overrides = prefix_overrides or {}

        # 挂载所有协议的 Router
        self._mount_protocols(protocols)

    def _setup_cors(self, cors_origins: Optional[Sequence[str]] = None):
        """配置 CORS 中间件 / Configure CORS middleware

        Args:
            cors_origins: 允许的源列表，默认为 ["*"] 允许所有源
        """
        origins = list(cors_origins) if cors_origins else ["*"]

        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=origins,
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
            expose_headers=["*"],
        )

        logger.info(f"✅ CORS 已启用，允许的源: {origins}")

    def _mount_protocols(self, protocols: List[ProtocolHandler]):
        """挂载所有协议的路由

        Args:
            protocols: 协议处理器列表
        """
        for protocol in protocols:
            # 获取协议的 Router
            router = protocol.as_fastapi_router(self.agent_invoker)

            # 确定路由前缀
            prefix = self._get_protocol_prefix(protocol)

            # 挂载到主应用
            self.app.include_router(router, prefix=prefix)

            logger.info(
                f"✅ 已挂载协议: {protocol.__class__.__name__} ->"
                f" {prefix or '(无前缀)'}"
            )

    def _get_protocol_prefix(self, protocol: ProtocolHandler) -> str:
        """获取协议的路由前缀

        优先级:
        1. 用户指定的覆盖前缀
        2. 协议自己的建议前缀
        3. 基于协议类名的默认前缀

        Args:
            protocol: 协议处理器

        Returns:
            str: 路由前缀
        """
        protocol_name = protocol.__class__.__name__

        # 1. 检查用户覆盖
        if protocol_name in self.prefix_overrides:
            return self.prefix_overrides[protocol_name]

        # 2. 使用协议建议
        suggested_prefix = protocol.get_prefix()
        if suggested_prefix:
            return suggested_prefix

        # 3. 默认前缀(基于类名)
        # OpenAIProtocolHandler -> /openai
        name_without_handler = protocol_name.replace(
            "ProtocolHandler", ""
        ).replace("Handler", "")
        return f"/{name_without_handler.lower()}"

    def start(
        self,
        host: str = "0.0.0.0",
        port: int = 9000,
        log_level: str = "info",
        **kwargs: Any,
    ):
        """启动 HTTP 服务器

        Args:
            host: 监听地址,默认 0.0.0.0
            port: 监听端口,默认 9000
            log_level: 日志级别,默认 info
            **kwargs: 传递给 uvicorn.run 的其他参数
        """
        logger.info(f"🚀 启动 AgentRun Server: http://{host}:{port}")

        # 打印路由信息
        # for route in self.app.routes:
        #     if hasattr(route, "methods") and hasattr(route, "path"):
        #         methods = ", ".join(route.methods)  # type: ignore
        # logger.info(f"   {methods:10} {route.path}")  # type: ignore

        uvicorn.run(
            self.app, host=host, port=port, log_level=log_level, **kwargs
        )

    def as_fastapi_app(self) -> FastAPI:
        """导出 FastAPI 应用

        用于集成到现有的 FastAPI 项目中。

        Returns:
            FastAPI: FastAPI 应用实例

        Example:
            >>> from fastapi import FastAPI
            >>>
            >>> app = FastAPI()
            >>> agent_server = AgentRunServer(invoke_agent=invoke_agent)
            >>> app.mount("/agent", agent_server.as_fastapi_app())
        """
        return self.app
