"""Utils 模块 / Utils Module

此模块提供通用工具函数和基础设施。
This module provides common utility functions and infrastructure.
"""
