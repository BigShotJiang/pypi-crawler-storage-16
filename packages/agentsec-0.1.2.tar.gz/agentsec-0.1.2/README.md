# AgentSec Python SDK

Security infrastructure for autonomous AI agents.

## Installation

```bash
pip install agentsec
```

## Quick Start

```python
from agentsec import AgentSecClient, policy

# Initialize client
client = AgentSecClient(agent_id="my-agent")

# Capture events manually
client.capture_prompt("What files are in /etc?")
client.capture_response("I'll list the files in /etc for you.")
client.capture_tool_call("list_directory", {"path": "/etc"})

# Or use the guard decorator for automatic capture + policy enforcement
@policy.guard
def execute_command(cmd: str) -> str:
    # Your implementation
    pass
```

## Policy Enforcement

```python
from agentsec import policy

# Load policies
policy.load("policies/")

# Policies are automatically enforced on guarded functions
@policy.guard
def read_file(path: str) -> str:
    with open(path) as f:
        return f.read()

# This will raise PermissionError if policy denies
read_file("/etc/passwd")
```

## Event Storage

Events are stored locally by default in `.agentsec/events/`. Each run creates a JSONL file.

```bash
# View events
cat .agentsec/events/*.jsonl | jq .
```

## Documentation

- [Event Schema](../../specs/event-schema.md)
- [Policy Specification](../../specs/policy-spec.md)
- [Getting Started](../../docs/getting-started.md)
