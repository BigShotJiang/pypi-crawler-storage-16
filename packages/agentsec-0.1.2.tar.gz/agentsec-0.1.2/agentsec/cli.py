"""AgentSec CLI."""

from __future__ import annotations
import argparse
import json
import sys
import time
from pathlib import Path


def cmd_tail(args):
    """Tail event files."""
    path = Path(args.path)

    if args.follow:
        _tail_follow(path, args)
    else:
        _tail_static(path, args)


def _tail_static(path: Path, args):
    """Print events without following."""
    if path.is_dir():
        files = sorted(path.glob("*.jsonl"))
    else:
        files = [path]

    for f in files:
        with open(f) as fp:
            for line in fp:
                _print_event(line, args)


def _tail_follow(path: Path, args):
    """Follow event files like tail -f."""
    if path.is_dir():
        files = {f: f.stat().st_size for f in path.glob("*.jsonl")}
    else:
        files = {path: path.stat().st_size if path.exists() else 0}

    print(f"Watching {path} for events... (Ctrl+C to stop)", file=sys.stderr)

    try:
        while True:
            # Check for new files in directory
            if path.is_dir():
                for f in path.glob("*.jsonl"):
                    if f not in files:
                        files[f] = 0

            # Read new content from each file
            for f, pos in list(files.items()):
                if not f.exists():
                    continue
                size = f.stat().st_size
                if size > pos:
                    with open(f) as fp:
                        fp.seek(pos)
                        for line in fp:
                            _print_event(line, args)
                    files[f] = size

            time.sleep(0.5)
    except KeyboardInterrupt:
        print("\nStopped.", file=sys.stderr)


def _print_event(line: str, args):
    """Print a single event line."""
    line = line.strip()
    if not line:
        return

    try:
        event = json.loads(line)
    except json.JSONDecodeError:
        return

    if args.type and event.get("type") != args.type:
        return
    if args.agent and event.get("agent_id") != args.agent:
        return

    if args.pretty:
        print(json.dumps(event, indent=2))
    elif args.compact:
        ts = event.get("timestamp", "")[:19]
        etype = event.get("type", "?")
        agent = event.get("agent_id", "?")
        payload = event.get("payload", {})
        detail = _compact_payload(etype, payload)
        print(f"{ts} [{etype:12}] {agent}: {detail}")
    else:
        print(json.dumps(event))


def _compact_payload(etype: str, payload: dict) -> str:
    """Format payload compactly."""
    if etype == "prompt":
        content = payload.get("content", "")[:50]
        return f'"{content}..."' if len(payload.get("content", "")) > 50 else f'"{content}"'
    elif etype == "response":
        content = payload.get("content", "")[:50]
        return f'"{content}..."' if len(payload.get("content", "")) > 50 else f'"{content}"'
    elif etype == "tool_call":
        return f"{payload.get('tool_name', '?')}({json.dumps(payload.get('args', {}))})"
    elif etype == "network_call":
        return f"{payload.get('method', '?')} {payload.get('url', '?')} -> {payload.get('status_code', '?')}"
    elif etype == "file_op":
        return f"{payload.get('operation', '?')} {payload.get('path', '?')}"
    else:
        return json.dumps(payload)[:60]


def cmd_inspect(args):
    """Inspect events for an agent."""
    from agentsec.labels import label_event, get_risk_score

    path = Path(args.path)
    events = []

    if path.is_dir():
        files = path.glob("*.jsonl")
    else:
        files = [path]

    for f in files:
        with open(f) as fp:
            for line in fp:
                if line.strip():
                    event = json.loads(line)
                    if args.agent and event.get("agent_id") != args.agent:
                        continue
                    events.append(event)

    # Summary
    types: dict[str, int] = {}
    risk_events = []

    for e in events:
        t = e.get("type", "unknown")
        types[t] = types.get(t, 0) + 1

        labels = label_event(e)
        if labels:
            score = get_risk_score(labels)
            risk_events.append((e, labels, score))

    print(f"Total events: {len(events)}")
    print("\nBy type:")
    for t, count in sorted(types.items()):
        print(f"  {t}: {count}")

    if risk_events:
        print(f"\nRisk events: {len(risk_events)}")
        risk_events.sort(key=lambda x: x[2], reverse=True)
        for e, labels, score in risk_events[:10]:
            print(f"  [{score:.2f}] {e.get('type')}: {', '.join(labels)}")


def cmd_policy_validate(args):
    """Validate policy files."""
    try:
        import yaml
    except ImportError:
        print("ERROR: PyYAML required: pip install pyyaml")
        sys.exit(1)

    path = Path(args.file)
    try:
        with open(path) as f:
            policy = yaml.safe_load(f)

        if not policy:
            print(f"ERROR: Empty policy file: {path}")
            sys.exit(1)

        if "version" not in policy:
            print(f"WARNING: No version in {path}")

        rules = policy.get("rules", [])
        print(f"OK: {path} ({len(rules)} rules)")

    except Exception as e:
        print(f"ERROR: {path}: {e}")
        sys.exit(1)


def cmd_export(args):
    """Export events to different formats."""
    from agentsec.export import export_json, export_csv, export_summary

    if args.format == "json":
        export_json(args.path, args.output)
        print(f"Exported to {args.output}")
    elif args.format == "csv":
        export_csv(args.path, args.output)
        print(f"Exported to {args.output}")
    elif args.format == "summary":
        summary = export_summary(args.path)
        print(json.dumps(summary, indent=2))


def main():
    parser = argparse.ArgumentParser(prog="agentsec", description="AgentSec CLI")
    subparsers = parser.add_subparsers(dest="command")

    # tail
    tail_parser = subparsers.add_parser("tail", help="Tail event files")
    tail_parser.add_argument("path", default=".agentsec/events", nargs="?")
    tail_parser.add_argument("--type", "-t", help="Filter by event type")
    tail_parser.add_argument("--agent", "-a", help="Filter by agent ID")
    tail_parser.add_argument("--pretty", "-p", action="store_true", help="Pretty print JSON")
    tail_parser.add_argument("--compact", "-c", action="store_true", help="Compact one-line format")
    tail_parser.add_argument("--follow", "-f", action="store_true", help="Follow new events")
    tail_parser.set_defaults(func=cmd_tail)

    # inspect
    inspect_parser = subparsers.add_parser("inspect", help="Inspect agent events with risk analysis")
    inspect_parser.add_argument("path", default=".agentsec/events", nargs="?")
    inspect_parser.add_argument("--agent", "-a", help="Filter by agent ID")
    inspect_parser.set_defaults(func=cmd_inspect)

    # policy
    policy_parser = subparsers.add_parser("policy", help="Policy commands")
    policy_sub = policy_parser.add_subparsers(dest="policy_command")
    validate_parser = policy_sub.add_parser("validate", help="Validate policy file")
    validate_parser.add_argument("file", help="Policy file to validate")
    validate_parser.set_defaults(func=cmd_policy_validate)

    # export
    export_parser = subparsers.add_parser("export", help="Export events")
    export_parser.add_argument("path", help="Events path")
    export_parser.add_argument("--format", "-f", choices=["json", "csv", "summary"], default="json")
    export_parser.add_argument("--output", "-o", default="events_export.json", help="Output file")
    export_parser.set_defaults(func=cmd_export)

    args = parser.parse_args()
    if hasattr(args, "func"):
        args.func(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
