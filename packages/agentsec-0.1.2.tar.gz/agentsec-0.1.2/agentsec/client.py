"""AgentSec client for capturing and enforcing agent behavior."""

from __future__ import annotations
import uuid
from typing import Optional
from agentsec.telemetry import Telemetry
from agentsec.policy import PolicyEngine


class AgentSecClient:
    """Main client for AgentSec SDK."""

    def __init__(
        self,
        agent_id: str,
        run_id: Optional[str] = None,
        storage_path: str = ".agentsec/events",
        policy_path: Optional[str] = None,
        intercept_network: bool = False,
        intercept_files: bool = False,
    ):
        self.agent_id = agent_id
        self.run_id = run_id or str(uuid.uuid4())
        self.telemetry = Telemetry(agent_id, self.run_id, storage_path)
        self.policy = PolicyEngine(policy_path) if policy_path else PolicyEngine()

        if intercept_network or intercept_files:
            from agentsec import interceptors
            interceptors.set_telemetry(self.telemetry)
            if intercept_network:
                interceptors.install_network_interceptors()
            if intercept_files:
                interceptors.install_file_interceptors()

    def capture_prompt(self, content: str, role: str = "user") -> str:
        """Capture an incoming prompt."""
        return self.telemetry.capture_prompt(content, role)

    def capture_response(self, content: str, model: str = "unknown") -> str:
        """Capture an agent response."""
        return self.telemetry.capture_response(content, model)

    def capture_tool_call(self, tool_name: str, args: dict) -> str:
        """Capture a tool invocation."""
        return self.telemetry.capture_tool_call(tool_name, args)

    def capture_tool_result(self, tool_name: str, result, error: Optional[str] = None) -> str:
        """Capture a tool result."""
        return self.telemetry.capture_tool_result(tool_name, result, error)

    def evaluate(self, intent: dict) -> dict:
        """Evaluate an intent against loaded policies."""
        return self.policy.evaluate(intent)

    def guard(self, func):
        """Decorator to guard tool functions with policy checks."""
        return self.policy.guard(func, self.telemetry)
