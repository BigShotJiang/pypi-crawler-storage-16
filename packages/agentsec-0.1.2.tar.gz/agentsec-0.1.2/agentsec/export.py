"""Event export utilities."""

from __future__ import annotations
import csv
import json
from pathlib import Path
from typing import Iterator


def load_events(path: str) -> Iterator[dict]:
    """Load events from JSONL file or directory."""
    p = Path(path)
    files = list(p.glob("*.jsonl")) if p.is_dir() else [p]

    for f in files:
        with open(f) as fp:
            for line in fp:
                if line.strip():
                    yield json.loads(line)


def export_json(events_path: str, output_path: str, indent: int = 2):
    """Export events to JSON array."""
    events = list(load_events(events_path))
    with open(output_path, "w") as f:
        json.dump(events, f, indent=indent)


def export_csv(events_path: str, output_path: str):
    """Export events to CSV."""
    events = list(load_events(events_path))
    if not events:
        return

    # Flatten events for CSV
    rows = []
    for e in events:
        row = {
            "event_id": e.get("event_id"),
            "agent_id": e.get("agent_id"),
            "run_id": e.get("run_id"),
            "timestamp": e.get("timestamp"),
            "type": e.get("type"),
        }
        payload = e.get("payload", {})
        for k, v in payload.items():
            row[f"payload_{k}"] = json.dumps(v) if isinstance(v, (dict, list)) else v
        rows.append(row)

    # Get all columns
    columns = set()
    for row in rows:
        columns.update(row.keys())
    columns = sorted(columns)

    with open(output_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)


def export_summary(events_path: str) -> dict:
    """Generate summary statistics."""
    events = list(load_events(events_path))

    summary = {
        "total_events": len(events),
        "by_type": {},
        "by_agent": {},
        "time_range": {"start": None, "end": None},
    }

    for e in events:
        t = e.get("type", "unknown")
        summary["by_type"][t] = summary["by_type"].get(t, 0) + 1

        a = e.get("agent_id", "unknown")
        summary["by_agent"][a] = summary["by_agent"].get(a, 0) + 1

        ts = e.get("timestamp")
        if ts:
            if not summary["time_range"]["start"] or ts < summary["time_range"]["start"]:
                summary["time_range"]["start"] = ts
            if not summary["time_range"]["end"] or ts > summary["time_range"]["end"]:
                summary["time_range"]["end"] = ts

    return summary
