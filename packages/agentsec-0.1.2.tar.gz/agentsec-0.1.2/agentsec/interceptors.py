"""Network and file operation interceptors."""

from __future__ import annotations
import functools
from typing import Optional, Callable, Any, TYPE_CHECKING

if TYPE_CHECKING:
    from agentsec.telemetry import Telemetry

_telemetry: Optional["Telemetry"] = None
_original_funcs: dict[str, Any] = {}


def set_telemetry(telemetry: "Telemetry"):
    """Set telemetry instance for interceptors."""
    global _telemetry
    _telemetry = telemetry


# --- Network Interception ---

def _wrap_requests():
    """Patch requests library."""
    try:
        import requests
    except ImportError:
        return

    if "requests.get" in _original_funcs:
        return

    _original_funcs["requests.get"] = requests.get
    _original_funcs["requests.post"] = requests.post
    _original_funcs["requests.put"] = requests.put
    _original_funcs["requests.delete"] = requests.delete
    _original_funcs["requests.request"] = requests.request

    def make_wrapper(method: str, original: Callable) -> Callable:
        @functools.wraps(original)
        def wrapper(url: str, *args, **kwargs):
            if _telemetry:
                _telemetry.capture_network_call(method.upper(), url, 0)
            resp = original(url, *args, **kwargs)
            if _telemetry:
                _telemetry.capture_network_call(method.upper(), url, resp.status_code)
            return resp
        return wrapper

    requests.get = make_wrapper("get", _original_funcs["requests.get"])
    requests.post = make_wrapper("post", _original_funcs["requests.post"])
    requests.put = make_wrapper("put", _original_funcs["requests.put"])
    requests.delete = make_wrapper("delete", _original_funcs["requests.delete"])

    original_request = _original_funcs["requests.request"]

    @functools.wraps(original_request)
    def request_wrapper(method: str, url: str, *args, **kwargs):
        if _telemetry:
            _telemetry.capture_network_call(method.upper(), url, 0)
        resp = original_request(method, url, *args, **kwargs)
        if _telemetry:
            _telemetry.capture_network_call(method.upper(), url, resp.status_code)
        return resp

    requests.request = request_wrapper


def _wrap_httpx():
    """Patch httpx library."""
    try:
        import httpx
    except ImportError:
        return

    if "httpx.Client.request" in _original_funcs:
        return

    _original_funcs["httpx.Client.request"] = httpx.Client.request

    original = _original_funcs["httpx.Client.request"]

    @functools.wraps(original)
    def wrapper(self, method: str, url, *args, **kwargs):
        url_str = str(url)
        if _telemetry:
            _telemetry.capture_network_call(method.upper(), url_str, 0)
        resp = original(self, method, url, *args, **kwargs)
        if _telemetry:
            _telemetry.capture_network_call(method.upper(), url_str, resp.status_code)
        return resp

    httpx.Client.request = wrapper


def _wrap_urllib():
    """Patch urllib."""
    try:
        import urllib.request
    except ImportError:
        return

    if "urllib.request.urlopen" in _original_funcs:
        return

    _original_funcs["urllib.request.urlopen"] = urllib.request.urlopen
    original = _original_funcs["urllib.request.urlopen"]

    @functools.wraps(original)
    def wrapper(url, *args, **kwargs):
        url_str = url if isinstance(url, str) else url.full_url
        if _telemetry:
            _telemetry.capture_network_call("GET", url_str, 0)
        resp = original(url, *args, **kwargs)
        if _telemetry:
            _telemetry.capture_network_call("GET", url_str, resp.status)
        return resp

    urllib.request.urlopen = wrapper


# --- File Interception ---

_original_open: Optional[Callable] = None


_in_capture = False  # Prevent recursion


def _wrap_builtins():
    """Patch built-in open."""
    global _original_open
    import builtins

    if _original_open is not None:
        return

    _original_open = builtins.open

    @functools.wraps(_original_open)
    def wrapped_open(file, mode="r", *args, **kwargs):
        global _in_capture
        path = str(file)
        op = "write" if any(m in mode for m in ["w", "a", "x"]) else "read"
        # Avoid recursion when telemetry writes its own events
        if _telemetry and not _in_capture:
            _in_capture = True
            try:
                _telemetry.capture_file_op(op, path)
            finally:
                _in_capture = False
        return _original_open(file, mode, *args, **kwargs)

    builtins.open = wrapped_open


# --- Public API ---

def install_network_interceptors():
    """Install all network interceptors."""
    _wrap_requests()
    _wrap_httpx()
    _wrap_urllib()


def install_file_interceptors():
    """Install file operation interceptors."""
    _wrap_builtins()


def install_all(telemetry: "Telemetry"):
    """Install all interceptors with telemetry."""
    set_telemetry(telemetry)
    install_network_interceptors()
    install_file_interceptors()


def uninstall_all():
    """Restore original functions."""
    global _original_open, _telemetry
    import builtins

    if _original_open:
        builtins.open = _original_open
        _original_open = None

    try:
        import requests
        if "requests.get" in _original_funcs:
            requests.get = _original_funcs["requests.get"]
            requests.post = _original_funcs["requests.post"]
            requests.put = _original_funcs["requests.put"]
            requests.delete = _original_funcs["requests.delete"]
            requests.request = _original_funcs["requests.request"]
    except ImportError:
        pass

    try:
        import httpx
        if "httpx.Client.request" in _original_funcs:
            httpx.Client.request = _original_funcs["httpx.Client.request"]
    except ImportError:
        pass

    try:
        import urllib.request
        if "urllib.request.urlopen" in _original_funcs:
            urllib.request.urlopen = _original_funcs["urllib.request.urlopen"]
    except ImportError:
        pass

    _original_funcs.clear()
    _telemetry = None
