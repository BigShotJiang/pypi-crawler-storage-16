"""Risk labeling heuristics for events."""

from __future__ import annotations
import re
from typing import Optional

# Sensitive file patterns
SENSITIVE_PATHS = [
    r"\.aws/credentials",
    r"\.ssh/",
    r"\.env",
    r"/etc/passwd",
    r"/etc/shadow",
    r"\.git/config",
    r"\.npmrc",
    r"\.pypirc",
    r"id_rsa",
    r"\.pem$",
    r"\.key$",
]

# Suspicious URL patterns
SUSPICIOUS_URLS = [
    r"pastebin\.com",
    r"ngrok\.io",
    r"requestbin",
    r"webhook\.site",
    r"burpcollaborator",
]

# Dangerous tool patterns
DANGEROUS_TOOLS = [
    r"^execute",
    r"^run_",
    r"^shell",
    r"^eval",
    r"^exec",
    r"delete",
    r"remove",
    r"drop",
]


def label_event(event: dict) -> list[str]:
    """Apply risk labels to an event based on heuristics."""
    labels: list[str] = []
    event_type = event.get("type", "")
    payload = event.get("payload", {})

    if event_type == "file_op":
        labels.extend(_label_file_op(payload))
    elif event_type == "network_call":
        labels.extend(_label_network_call(payload))
    elif event_type == "tool_call":
        labels.extend(_label_tool_call(payload))

    return labels


def _label_file_op(payload: dict) -> list[str]:
    """Label file operations."""
    labels = []
    path = payload.get("path", "")
    op = payload.get("operation", "")

    for pattern in SENSITIVE_PATHS:
        if re.search(pattern, path, re.IGNORECASE):
            labels.append("file_read_sensitive" if op == "read" else "credential_access")
            break

    if op == "write":
        if any(p in path for p in ["/etc/", "/usr/", "/bin/", "/sbin/"]):
            labels.append("file_write_persistent")
        if "cron" in path or "systemd" in path or "init.d" in path:
            labels.append("persistence_mechanism")

    if op == "delete":
        labels.append("destructive_command")

    return labels


def _label_network_call(payload: dict) -> list[str]:
    """Label network calls."""
    labels = []
    url = payload.get("url", "")
    method = payload.get("method", "GET")

    # External call detection (simple heuristic)
    if not any(h in url for h in ["localhost", "127.0.0.1", "internal", "10.", "192.168."]):
        if method == "GET":
            labels.append("network_external_get")
        elif method in ["POST", "PUT"]:
            labels.append("network_external_post")

    # Suspicious destinations
    for pattern in SUSPICIOUS_URLS:
        if re.search(pattern, url, re.IGNORECASE):
            labels.append("exfiltration_pattern")
            break

    # Large data transfer (if body_size available)
    body_size = payload.get("body_size", 0)
    if body_size > 100000:  # 100KB
        labels.append("network_data_exfil")

    return labels


def _label_tool_call(payload: dict) -> list[str]:
    """Label tool calls."""
    labels = []
    tool_name = payload.get("tool_name", "")
    args = payload.get("args", {})
    args_str = str(args).lower()

    # Dangerous tool execution
    for pattern in DANGEROUS_TOOLS:
        if re.search(pattern, tool_name, re.IGNORECASE):
            labels.append("code_execution")
            break

    # Check for credential-related args
    if any(k in args_str for k in ["password", "secret", "token", "key", "credential"]):
        labels.append("credential_enumeration")

    # Check for recon patterns
    if any(k in tool_name.lower() for k in ["scan", "enumerate", "list", "discover"]):
        labels.append("recon_scan")

    # Check for sensitive file access via tool args
    path = args.get("path", "")
    for pattern in SENSITIVE_PATHS:
        if re.search(pattern, path, re.IGNORECASE):
            labels.append("credential_access")
            break

    # Check for persistence via write_file
    if tool_name in ["write_file", "write", "save_file"]:
        if any(p in path for p in ["cron", "systemd", "init.d", "rc.local", "profile"]):
            labels.append("persistence_mechanism")
        if any(p in path for p in ["/etc/", "/usr/", "/bin/"]):
            labels.append("file_write_persistent")

    return labels


def get_risk_score(labels: list[str]) -> float:
    """Calculate risk score from labels (0.0 - 1.0)."""
    if not labels:
        return 0.0

    weights = {
        "credential_access": 0.9,
        "credential_enumeration": 0.7,
        "exfiltration_pattern": 0.95,
        "network_data_exfil": 0.8,
        "persistence_mechanism": 0.85,
        "code_execution": 0.6,
        "destructive_command": 0.7,
        "file_read_sensitive": 0.5,
        "file_write_persistent": 0.6,
        "network_external_post": 0.4,
        "network_external_get": 0.2,
        "recon_scan": 0.3,
    }

    scores = [weights.get(label, 0.3) for label in labels]
    return min(1.0, max(scores) + 0.1 * (len(scores) - 1))
