"""Policy engine for agent action enforcement."""

from __future__ import annotations
import fnmatch
import functools
from pathlib import Path
from typing import Optional, Callable, Any, TYPE_CHECKING

if TYPE_CHECKING:
    from agentsec.telemetry import Telemetry
from dataclasses import dataclass

try:
    import yaml
except ImportError:
    yaml = None  # type: ignore


@dataclass
class Decision:
    """Policy decision result."""
    allowed: bool
    decision: str  # allow, deny, escalate
    policy_id: Optional[str] = None
    reason: Optional[str] = None

    @property
    def denied(self) -> bool:
        return self.decision == "deny"


class PolicyEngine:
    """Evaluates intents against loaded policies."""

    def __init__(self, policy_path: Optional[str] = None):
        self.policies: list[dict] = []
        self.default = "allow"
        if policy_path:
            self.load(policy_path)

    def load(self, path: str):
        """Load policies from file or directory."""
        p = Path(path)
        if p.is_dir():
            for f in p.glob("*.yaml"):
                self._load_file(f)
            for f in p.glob("*.yml"):
                self._load_file(f)
        else:
            self._load_file(p)

    def _load_file(self, path: Path):
        """Load a single policy file."""
        if yaml is None:
            raise ImportError("PyYAML required for policy loading: pip install pyyaml")
        with open(path) as f:
            policy = yaml.safe_load(f)
            if policy:
                self.policies.append(policy)
                if "default" in policy:
                    self.default = policy["default"]

    def evaluate(self, intent: dict) -> Decision:
        """Evaluate an intent against all loaded policies."""
        for policy in self.policies:
            for rule in policy.get("rules", []):
                if self._matches(rule.get("match", {}), intent):
                    decision = rule.get("decision", "allow")
                    return Decision(
                        allowed=(decision == "allow"),
                        decision=decision,
                        policy_id=rule.get("id"),
                        reason=rule.get("reason"),
                    )
        return Decision(allowed=(self.default == "allow"), decision=self.default)

    def _matches(self, match: dict, intent: dict) -> bool:
        """Check if intent matches rule conditions."""
        if not match:
            return True

        # Match by type
        if "type" in match and intent.get("type") != match["type"]:
            return False

        # Match by tool_name
        if "tool_name" in match:
            pattern = match["tool_name"]
            tool = intent.get("payload", {}).get("tool_name", "")
            if not self._pattern_match(pattern, tool):
                return False

        # Match by URL
        if "url" in match:
            pattern = match["url"]
            url = intent.get("payload", {}).get("url", "")
            if not self._pattern_match(pattern, url):
                return False

        # Match by path
        if "path" in match:
            pattern = match["path"]
            path = intent.get("payload", {}).get("path", "")
            if not self._pattern_match(pattern, path):
                return False

        # Match by labels
        if "labels" in match:
            required = match["labels"].get("contains", [])
            actual = intent.get("metadata", {}).get("labels", [])
            if not any(label in actual for label in required):
                return False

        return True

    def _pattern_match(self, pattern: str, value: str) -> bool:
        """Match value against pattern (supports glob and negation)."""
        negate = pattern.startswith("!")
        if negate:
            pattern = pattern[1:]
        result = fnmatch.fnmatch(value, pattern)
        return not result if negate else result

    def guard(self, func: Callable = None, telemetry=None):
        """Decorator to guard functions with policy checks."""
        def decorator(fn: Callable) -> Callable:
            @functools.wraps(fn)
            def wrapper(*args, **kwargs):
                intent = {
                    "type": "tool_call",
                    "payload": {"tool_name": fn.__name__, "args": kwargs or args},
                }
                if telemetry:
                    telemetry.capture_tool_call(fn.__name__, kwargs or {"args": args})

                decision = self.evaluate(intent)
                if decision.denied:
                    raise PermissionError(f"Policy denied: {decision.reason}")
                if decision.decision == "escalate":
                    raise PermissionError(f"Escalation required: {decision.reason}")

                result = fn(*args, **kwargs)
                if telemetry:
                    telemetry.capture_tool_result(fn.__name__, result)
                return result
            return wrapper

        if func is not None:
            return decorator(func)
        return decorator


# Module-level instance
_engine = PolicyEngine()


def load(path: str):
    """Load policies into default engine."""
    _engine.load(path)


def evaluate(intent: dict) -> Decision:
    """Evaluate intent against default engine."""
    return _engine.evaluate(intent)


def guard(func: Callable = None):
    """Decorator using default policy engine."""
    return _engine.guard(func)
