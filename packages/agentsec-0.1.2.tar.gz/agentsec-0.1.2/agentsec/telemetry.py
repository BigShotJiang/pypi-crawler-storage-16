"""Telemetry capture for agent events."""

from __future__ import annotations
import json
import uuid
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


class Telemetry:
    """Captures and stores agent events."""

    def __init__(self, agent_id: str, run_id: str, storage_path: str = ".agentsec/events"):
        self.agent_id = agent_id
        self.run_id = run_id
        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(parents=True, exist_ok=True)
        self._event_file = self.storage_path / f"{run_id}.jsonl"

    def _emit(self, event_type: str, payload: dict) -> str:
        """Emit an event to storage."""
        event_id = str(uuid.uuid4())
        event = {
            "event_id": event_id,
            "agent_id": self.agent_id,
            "run_id": self.run_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "type": event_type,
            "payload": payload,
            "metadata": {
                "sdk_version": "0.1.0",
                "runtime": f"python{os.sys.version_info.major}.{os.sys.version_info.minor}",
            },
        }
        with open(self._event_file, "a") as f:
            f.write(json.dumps(event) + "\n")
        return event_id

    def capture_prompt(self, content: str, role: str = "user") -> str:
        """Capture a prompt event."""
        return self._emit("prompt", {"content": content, "role": role})

    def capture_response(self, content: str, model: str = "unknown") -> str:
        """Capture a response event."""
        return self._emit("response", {"content": content, "model": model})

    def capture_tool_call(self, tool_name: str, args: dict) -> str:
        """Capture a tool call event."""
        return self._emit("tool_call", {"tool_name": tool_name, "args": args})

    def capture_tool_result(self, tool_name: str, result: any, error: Optional[str] = None) -> str:
        """Capture a tool result event."""
        return self._emit("tool_result", {"tool_name": tool_name, "result": result, "error": error})

    def capture_network_call(self, method: str, url: str, status_code: int) -> str:
        """Capture a network call event."""
        return self._emit("network_call", {"method": method, "url": url, "status_code": status_code})

    def capture_file_op(self, operation: str, path: str) -> str:
        """Capture a file operation event."""
        return self._emit("file_op", {"operation": operation, "path": path})


# Module-level convenience functions
_default_telemetry: Optional[Telemetry] = None


def init(agent_id: str, run_id: Optional[str] = None):
    """Initialize default telemetry instance."""
    global _default_telemetry
    _default_telemetry = Telemetry(agent_id, run_id or str(uuid.uuid4()))


def capture_prompt(content: str, role: str = "user") -> str:
    if not _default_telemetry:
        raise RuntimeError("Call agentsec.telemetry.init() first")
    return _default_telemetry.capture_prompt(content, role)


def capture_response(content: str, model: str = "unknown") -> str:
    if not _default_telemetry:
        raise RuntimeError("Call agentsec.telemetry.init() first")
    return _default_telemetry.capture_response(content, model)


def capture_tool_call(tool_name: str, args: dict) -> str:
    if not _default_telemetry:
        raise RuntimeError("Call agentsec.telemetry.init() first")
    return _default_telemetry.capture_tool_call(tool_name, args)
