"""Tests for export utilities."""

import json
import tempfile
from pathlib import Path
from agentsec.export import load_events, export_json, export_csv, export_summary


def _create_test_events(tmpdir: str) -> str:
    """Create test event file."""
    events_file = Path(tmpdir) / "test.jsonl"
    events = [
        {"event_id": "1", "agent_id": "a1", "type": "prompt", "timestamp": "2025-01-01T00:00:00Z", "payload": {"content": "hello"}},
        {"event_id": "2", "agent_id": "a1", "type": "response", "timestamp": "2025-01-01T00:01:00Z", "payload": {"content": "hi"}},
        {"event_id": "3", "agent_id": "a2", "type": "tool_call", "timestamp": "2025-01-01T00:02:00Z", "payload": {"tool_name": "search"}},
    ]
    with open(events_file, "w") as f:
        for e in events:
            f.write(json.dumps(e) + "\n")
    return str(events_file)


def test_load_events():
    with tempfile.TemporaryDirectory() as tmpdir:
        path = _create_test_events(tmpdir)
        events = list(load_events(path))
        assert len(events) == 3


def test_export_json():
    with tempfile.TemporaryDirectory() as tmpdir:
        path = _create_test_events(tmpdir)
        output = Path(tmpdir) / "out.json"
        export_json(path, str(output))

        with open(output) as f:
            data = json.load(f)
        assert len(data) == 3


def test_export_csv():
    with tempfile.TemporaryDirectory() as tmpdir:
        path = _create_test_events(tmpdir)
        output = Path(tmpdir) / "out.csv"
        export_csv(path, str(output))

        with open(output) as f:
            lines = f.readlines()
        assert len(lines) == 4  # header + 3 rows


def test_export_summary():
    with tempfile.TemporaryDirectory() as tmpdir:
        path = _create_test_events(tmpdir)
        summary = export_summary(path)

        assert summary["total_events"] == 3
        assert summary["by_type"]["prompt"] == 1
        assert summary["by_type"]["response"] == 1
        assert summary["by_type"]["tool_call"] == 1
        assert summary["by_agent"]["a1"] == 2
        assert summary["by_agent"]["a2"] == 1
