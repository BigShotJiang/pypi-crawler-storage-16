"""Tests for interceptors."""

import tempfile
import json
from pathlib import Path
from agentsec.telemetry import Telemetry
from agentsec import interceptors


def test_file_interceptor():
    with tempfile.TemporaryDirectory() as tmpdir:
        telemetry = Telemetry("test-agent", "test-run", tmpdir)
        interceptors.set_telemetry(telemetry)
        interceptors.install_file_interceptors()

        # Create a test file
        test_file = Path(tmpdir) / "test.txt"
        with open(test_file, "w") as f:
            f.write("hello")

        # Read it back
        with open(test_file, "r") as f:
            content = f.read()

        assert content == "hello"

        # Check events were captured
        events_file = Path(tmpdir) / "test-run.jsonl"
        with open(events_file) as f:
            events = [json.loads(line) for line in f]

        file_ops = [e for e in events if e["type"] == "file_op"]
        assert len(file_ops) >= 2  # write + read

        interceptors.uninstall_all()


def test_interceptor_uninstall():
    interceptors.install_network_interceptors()
    interceptors.install_file_interceptors()
    interceptors.uninstall_all()

    # Should not raise
    import builtins
    assert builtins.open is not None
