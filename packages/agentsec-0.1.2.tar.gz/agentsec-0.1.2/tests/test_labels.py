"""Tests for risk labeling."""

from agentsec.labels import label_event, get_risk_score


def test_label_sensitive_file():
    event = {
        "type": "file_op",
        "payload": {"operation": "read", "path": "/home/user/.aws/credentials"},
    }
    labels = label_event(event)
    assert "file_read_sensitive" in labels or "credential_access" in labels


def test_label_external_network():
    event = {
        "type": "network_call",
        "payload": {"method": "POST", "url": "https://external.com/api"},
    }
    labels = label_event(event)
    assert "network_external_post" in labels


def test_label_dangerous_tool():
    event = {
        "type": "tool_call",
        "payload": {"tool_name": "execute_shell", "args": {"cmd": "ls"}},
    }
    labels = label_event(event)
    assert "code_execution" in labels


def test_label_exfil_pattern():
    event = {
        "type": "network_call",
        "payload": {"method": "POST", "url": "https://pastebin.com/raw"},
    }
    labels = label_event(event)
    assert "exfiltration_pattern" in labels


def test_risk_score():
    labels = ["credential_access", "exfiltration_pattern"]
    score = get_risk_score(labels)
    assert score > 0.9


def test_empty_labels():
    score = get_risk_score([])
    assert score == 0.0
