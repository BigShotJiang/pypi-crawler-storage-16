"""Tests for policy module."""

import tempfile
from pathlib import Path
from agentsec.policy import PolicyEngine


def test_default_allow():
    engine = PolicyEngine()
    decision = engine.evaluate({"type": "tool_call"})
    assert decision.allowed
    assert decision.decision == "allow"


def test_policy_deny():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        f.write("""
version: 1
default: allow
rules:
  - id: block-secrets
    match:
      type: tool_call
      tool_name: "*secret*"
    decision: deny
    reason: "Secrets blocked"
""")
        f.flush()

        engine = PolicyEngine(f.name)
        decision = engine.evaluate({
            "type": "tool_call",
            "payload": {"tool_name": "get_secret"}
        })

        assert decision.denied
        assert decision.reason == "Secrets blocked"


def test_policy_allow():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        f.write("""
version: 1
default: deny
rules:
  - id: allow-search
    match:
      type: tool_call
      tool_name: "search*"
    decision: allow
""")
        f.flush()

        engine = PolicyEngine(f.name)

        # Matching rule
        decision = engine.evaluate({
            "type": "tool_call",
            "payload": {"tool_name": "search_web"}
        })
        assert decision.allowed

        # No matching rule, falls to default
        decision = engine.evaluate({
            "type": "tool_call",
            "payload": {"tool_name": "delete_file"}
        })
        assert decision.denied


def test_guard_decorator():
    engine = PolicyEngine()

    @engine.guard
    def my_tool(x: int) -> int:
        return x * 2

    result = my_tool(5)
    assert result == 10
