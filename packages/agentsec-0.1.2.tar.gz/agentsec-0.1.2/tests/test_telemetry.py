"""Tests for telemetry module."""

import json
import tempfile
from pathlib import Path
from agentsec.telemetry import Telemetry


def test_capture_prompt():
    with tempfile.TemporaryDirectory() as tmpdir:
        t = Telemetry("test-agent", "test-run", tmpdir)
        event_id = t.capture_prompt("Hello", role="user")

        assert event_id is not None

        events = list(Path(tmpdir).glob("*.jsonl"))
        assert len(events) == 1

        with open(events[0]) as f:
            event = json.loads(f.read().strip())

        assert event["type"] == "prompt"
        assert event["payload"]["content"] == "Hello"
        assert event["payload"]["role"] == "user"


def test_capture_tool_call():
    with tempfile.TemporaryDirectory() as tmpdir:
        t = Telemetry("test-agent", "test-run", tmpdir)
        event_id = t.capture_tool_call("search", {"query": "test"})

        assert event_id is not None

        events = list(Path(tmpdir).glob("*.jsonl"))
        with open(events[0]) as f:
            event = json.loads(f.read().strip())

        assert event["type"] == "tool_call"
        assert event["payload"]["tool_name"] == "search"
        assert event["payload"]["args"]["query"] == "test"


def test_multiple_events():
    with tempfile.TemporaryDirectory() as tmpdir:
        t = Telemetry("test-agent", "test-run", tmpdir)
        t.capture_prompt("Hello")
        t.capture_response("Hi there")
        t.capture_tool_call("greet", {})

        events = list(Path(tmpdir).glob("*.jsonl"))
        with open(events[0]) as f:
            lines = f.readlines()

        assert len(lines) == 3
