"""
Core internal components for Agomax.

This module contains internal implementation details and should not be imported
directly by users.
"""
