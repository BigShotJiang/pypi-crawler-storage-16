# ahaat/__init__.py

from .core import generate

def get(prompt: str) -> str:
    return generate(prompt)
