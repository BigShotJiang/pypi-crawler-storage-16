# ahaat/__init__.py

from .core import generate, generate2


def get(prompt: str) -> str:
    """Uses the Groq-based generate()"""
    return generate(prompt)


def get2(prompt: str) -> str:
    """Uses the Mistral-based generate2() — plain text output"""
    return generate2(prompt)
