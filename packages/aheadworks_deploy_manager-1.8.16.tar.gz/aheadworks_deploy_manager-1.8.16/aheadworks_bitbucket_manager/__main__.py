import fire
from aheadworks_bitbucket_manager.console.console import Console


if __name__ != '__main__':
    pass
else:
    fire.Fire(Console)
