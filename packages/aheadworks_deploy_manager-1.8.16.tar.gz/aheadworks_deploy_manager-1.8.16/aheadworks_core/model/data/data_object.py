
class DataObject(object):
    pass
