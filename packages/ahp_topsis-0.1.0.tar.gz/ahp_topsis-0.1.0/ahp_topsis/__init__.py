from .ahp_topsis_library import AHP, TOPSIS

__all__ = ["AHP", "TOPSIS"]
