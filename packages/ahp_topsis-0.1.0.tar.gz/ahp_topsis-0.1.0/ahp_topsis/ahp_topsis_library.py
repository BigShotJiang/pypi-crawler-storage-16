"""
ahp_topsis_library.py

This module provides a clean implementation of the AHP (Analytic Hierarchy Process)
and TOPSIS (Technique for Order Preference by Similarity to Ideal Solution) methods.
It is designed to be easy to read (for educational purposes) while still being suitable
for use in small and medium-scale decision-making applications.

Contents:
- AHP class:
    - Pairwise comparison matrix
    - Weight computation (eigenvector or geometric mean method)
    - Consistency Index (CI) & Consistency Ratio (CR)
- TOPSIS class:
    - Decision matrix
    - Vector normalization
    - Weighted normalization
    - Ideal best / ideal worst solutions
    - Separation measures
    - Closeness coefficient and ranking
- Helper exceptions
- Example usage

Requirements:
- Python 3.8+
- numpy

Note:
For production-level usage, you may consider adding input validation,
logging, extended testing, and CI/CD integration.
"""

from __future__ import annotations

import numpy as np
from typing import List, Optional, Tuple


# ============================================================
#  AHP (Analytic Hierarchy Process)
# ============================================================

class AHPError(Exception):
    """Custom exception type for AHP-specific errors."""
    pass


class AHP:
    """
    Implements the Analytic Hierarchy Process (AHP).

    Features:
    - Accepts an n×n pairwise comparison matrix.
    - Computes criteria weights using:
        * Eigenvector method
        * Geometric mean method
    - Computes Consistency Index (CI) and Consistency Ratio (CR).

    Usage:
        ahp = AHP(pairwise_matrix)
        weights = ahp.weights(method="eigen")   # or "geometric"
        cr = ahp.consistency_ratio()
    """

    # Random Index (RI) values (Saaty scale) for n = 1..15
    RI_TABLE = {
        1: 0.00,
        2: 0.00,
        3: 0.58,
        4: 0.90,
        5: 1.12,
        6: 1.24,
        7: 1.32,
        8: 1.41,
        9: 1.45,
        10: 1.49,
        11: 1.51,
        12: 1.48,
        13: 1.56,
        14: 1.57,
        15: 1.59,
    }

    def __init__(self, pairwise: np.ndarray):
        pairwise = np.asarray(pairwise, dtype=float)

        # Basic validation
        if pairwise.ndim != 2 or pairwise.shape[0] != pairwise.shape[1]:
            raise AHPError("Pairwise matrix must be a square matrix (n×n).")

        self.n = pairwise.shape[0]

        if not np.allclose(np.diag(pairwise), 1.0):
            raise AHPError("Diagonal elements of the pairwise matrix must be equal to 1.")

        if np.any(pairwise <= 0):
            raise AHPError("All elements in the pairwise matrix must be positive.")

        # Expectation: pairwise[i, j] = 1 / pairwise[j, i]
        self.pairwise = pairwise

    # --------------------------------------------------------

    def weights(self, method: str = "eigen") -> np.ndarray:
        """
        Compute criterion weights.

        method:
            "eigen"     – Principal eigenvector method
            "geometric" – Row geometric mean method
        """

        method = method.lower()

        if method == "eigen":
            vals, vecs = np.linalg.eig(self.pairwise)
            idx = np.argmax(vals.real)  # index of largest eigenvalue
            w = np.abs(vecs[:, idx].real)
            return w / np.sum(w)

        elif method == "geometric":
            gm = np.prod(self.pairwise, axis=1) ** (1.0 / self.n)
            return gm / np.sum(gm)

        else:
            raise AHPError("Method must be 'eigen' or 'geometric'.")

    # --------------------------------------------------------

    def _max_eigenvalue(self) -> float:
        """Return the maximum eigenvalue λ_max."""
        vals = np.linalg.eigvals(self.pairwise)
        return max(vals.real)

    def consistency_index(self) -> float:
        """CI = (λ_max - n) / (n - 1)."""
        lam_max = self._max_eigenvalue()
        return (lam_max - self.n) / (self.n - 1)

    def consistency_ratio(self) -> float:
        """CR = CI / RI."""
        ci = self.consistency_index()
        ri = AHP.RI_TABLE.get(self.n)

        if ri is None:
            raise AHPError(f"RI value is not available for n={self.n}.")

        if ri == 0:
            return 0.0

        return ci / ri


# ============================================================
#  TOPSIS (Technique for Order Preference by Similarity to Ideal Solution)
# ============================================================

class TOPSISError(Exception):
    """Custom exception for TOPSIS-related errors."""
    pass


class TOPSIS:
    """
    Implements the TOPSIS multi-criteria decision-making method.

    Steps:
        1. Normalize the decision matrix.
        2. Apply weights.
        3. Determine positive & negative ideal solutions.
        4. Compute separation measures.
        5. Compute closeness coefficient for each alternative.
        6. Rank alternatives (1 = best).

    Parameters:
        decision_matrix : m×n array (alternatives × criteria)
        criteria_types  : Optional list specifying "max" or "min" for each criterion

    Usage:
        topsis = TOPSIS(matrix)
        scores, ranks = topsis.evaluate(weights)
    """

    def __init__(self, decision_matrix: np.ndarray, criteria_types: Optional[List[str]] = None):
        X = np.asarray(decision_matrix, dtype=float)

        if X.ndim != 2:
            raise TOPSISError("Decision matrix must be 2-dimensional (m × n).")

        self.X = X
        self.m, self.n = X.shape

        if criteria_types is None:
            self.criteria_types = ["max"] * self.n
        else:
            if len(criteria_types) != self.n:
                raise TOPSISError("Length of criteria_types must match number of columns.")

            ct = []
            for t in criteria_types:
                t = t.lower()
                if t not in ("max", "min"):
                    raise TOPSISError("criteria_types must contain only 'max' or 'min'.")
                ct.append(t)

            self.criteria_types = ct

    # --------------------------------------------------------

    def _normalize(self) -> np.ndarray:
        """Vector normalization: v_ij = x_ij / sqrt(sum_k x_kj^2)."""
        denom = np.sqrt(np.sum(self.X ** 2, axis=0))

        if np.any(denom == 0):
            raise TOPSISError("A criterion column contains all zeros; cannot normalize.")

        return self.X / denom

    # --------------------------------------------------------

    def evaluate(self, weights: Optional[np.ndarray] = None) -> Tuple[np.ndarray, np.ndarray]:
        """
        Perform the TOPSIS evaluation.

        Parameters:
            weights : Optional array of length n. If None, equal weight is used.

        Returns:
            scores : array of closeness coefficients
            ranks  : ranking (1 = best)
        """
        R = self._normalize()

        if weights is None:
            w = np.ones(self.n) / self.n
        else:
            w = np.asarray(weights, dtype=float).reshape(-1)
            if w.shape[0] != self.n:
                raise TOPSISError("Weight vector length must match number of criteria.")
            if np.any(w < 0):
                raise TOPSISError("Weights cannot be negative.")
            if not np.isclose(np.sum(w), 1.0):
                w = w / np.sum(w)

        V = R * w  # weighted normalized matrix

        # Determine ideal best (PIS) and ideal worst (NIS)
        pis = np.empty(self.n)
        nis = np.empty(self.n)

        for j in range(self.n):
            if self.criteria_types[j] == "max":
                pis[j] = np.max(V[:, j])
                nis[j] = np.min(V[:, j])
            else:
                pis[j] = np.min(V[:, j])
                nis[j] = np.max(V[:, j])

        # Separation from ideal points
        d_plus = np.sqrt(np.sum((V - pis) ** 2, axis=1))
        d_minus = np.sqrt(np.sum((V - nis) ** 2, axis=1))

        # Closeness coefficient
        with np.errstate(divide='ignore', invalid='ignore'):
            scores = d_minus / (d_plus + d_minus)
            scores[np.isnan(scores)] = 0.0

        # Ranking (higher score = better)
        ranks = np.argsort(-scores) + 1

        return scores, ranks


# ============================================================
#  Example Usage (executed only when run as a script)
# ============================================================

if __name__ == "__main__":
    print("--- AHP Example ---")
    pairwise = np.array([
        [1,   3,   1/2],
        [1/3, 1,   1/4],
        [2,   4,   1]
    ])

    ahp = AHP(pairwise)
    w_eig = ahp.weights(method="eigen")
    w_geo = ahp.weights(method="geometric")
    cr = ahp.consistency_ratio()

    print("Eigenvector weights:", np.round(w_eig, 4))
    print("Geometric mean weights:", np.round(w_geo, 4))
    print("Consistency Ratio:", np.round(cr, 4))

    print("\n--- TOPSIS Example ---")
    X = np.array([
        [250, 16, 12],
        [200, 16, 8],
        [300, 32, 16],
        [275, 32, 8]
    ], dtype=float)

    topsis = TOPSIS(X)
    scores, ranks = topsis.evaluate(w_geo)

    print("Scores:", np.round(scores, 4))
    print("Ranks (1 = best):", ranks)
