"""L0 test suite."""
