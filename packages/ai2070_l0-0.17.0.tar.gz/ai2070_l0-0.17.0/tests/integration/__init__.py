"""Integration tests for L0.

These tests require OPENAI_API_KEY to be set in environment or .env file.
"""
