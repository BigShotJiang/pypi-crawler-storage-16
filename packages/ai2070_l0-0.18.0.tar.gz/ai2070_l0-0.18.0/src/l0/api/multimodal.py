"""Multimodal exports."""

from ..multimodal import Multimodal

__all__ = [
    "Multimodal",
]
