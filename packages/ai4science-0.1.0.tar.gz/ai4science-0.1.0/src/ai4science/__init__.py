"""
@Project  : ai4science
@File     : __init__.py.py
@Author   : Shaobo Cui
@Date     : 12.12.2025 11:54
"""

__all__ = ["hello"]
__version__ = "0.1.0"

from .core import hello
