"""
@Project  : ai4science
@File     : core.py
@Author   : Shaobo Cui
@Date     : 12.12.2025 11:55
"""


def hello() -> str:
    return "Hello from ai4science!"
