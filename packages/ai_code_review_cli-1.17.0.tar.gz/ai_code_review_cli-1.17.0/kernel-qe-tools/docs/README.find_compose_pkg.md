# Find Compose Package

## Getting started

This utility will locate and print the full package NVR for a requested
package name within a requested compose.

The following repositories within a compose are searched:

* BaseOS
* AppStream
* RT
* NFV
* HighAvailability
* CRB
* Server
* Server-RT
* RHIVOS

You may supply an exact compose ID, such as 'RHEL-9.2.0-20230414.17', to search
for the requested package name.  If instead a RHEL release identifier is given,
for example 'RHEL-9.2.0', then the compose ID of the released RHEL version will
be used.

An exact compose ID works with any defined compose in CTS (for example RHEL and RHIVOS).

You may supply the `--package` argument multiple times to search the
compose for more than one package name.

The script will exit with the following status codes:

* 0 --> package(s) found in compose
* 1 --> package(s) cannot be found in compose
* 2 --> compose ID cannot be found
* 3 --> any error fetching compose/package info
* 4 --> incorrect usage
* 5 --> invalid local file

## Usage

```bash
usage: find_compose_pkg [-h] [-c COMPOSE] [-p PACKAGES] [-l LOCAL_FILE] [-v]

Find the package NVR for a package name within a RHEL compose

options:
  -h, --help            show this help message and exit
  -c COMPOSE, --compose COMPOSE
                        RHEL compose ID
  -p PACKAGES, --package PACKAGES
                        RHEL package(s), may be provided multiple times
  -l LOCAL_FILE, --local-file LOCAL_FILE
                        Local rpms.json file
  -v, --verbose         Enable verbose printing
```

## Testing

From the repository root, run tox tests:
`podman run --pull newer --rm -it --volume .:/code:Z quay.io/cki/cki-tools:production tox`

## Configuration via environment variables

| Name                 | Type | Secret | Required | Description                |
|----------------------|------|--------|----------|----------------------------|
| `SENTRY_DSN`         | url  | yes    | no       | Sentry DSN                 |
