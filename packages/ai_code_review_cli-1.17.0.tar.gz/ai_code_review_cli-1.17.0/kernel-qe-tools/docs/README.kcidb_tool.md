# kcidb_tool

## Getting started

Parser to transform test results (Beaker or Testing Farm) to kcidb format.

## Usage

Here are some main features:

### Create

Create a kcidb file from a result file, if task has a parameter with field `name` equals to
`MAINTAINERS` and the value can be a list of maintainers for the task. If this parameter is not
provided the default one provided in the CLI will be used.

The format to define maintainers is:

User name <user@emailaddress.com> / gitlab.com_username

Gitlab user is not mandatory and it needs the slash, if you want to multiples maintainers, you only
need to add a comma and define the next one, here is an example

User 1 <user_1@emailaddress.com> / user_1, User 2 <user_2@emailaddress.com> / user_2

Here is the subcommand help

```console
$ kcidb_tool create --help
usage: kcidb_tool create [-h] -c CHECKOUT --contact CONTACT --nvr NVR --source {beaker,testing-farm} [-a NAME=URL [NAME=URL ...]] [--brew-task-id BREW_TASK_ID] [-d] -i
                         INPUT [-o OUTPUT] [--origin ORIGIN] [--checkout-origin CHECKOUT_ORIGIN] [--builds-origin BUILDS_ORIGIN] [--tests-origin TESTS_ORIGIN]
                         [-t TEST_PLAN] [--tests-provisioner-url TESTS_PROVISIONER_URL] [--src-nvr SRC_NVR] [--submitter SUBMITTER] [--report-rules REPORT_RULES]
                         [--arch ARCH] [--distro DISTRO] [--public]

Convert Beaker or TMT results file into kcidb format.

options:
  -h, --help            show this help message and exit
  -c CHECKOUT, --checkout CHECKOUT
                        The checkout name used to generate all the kcidb ids.
  --contact CONTACT     Contact email, "Full Name <username@domain>" and username@domain are accepted, this argument can be used several times.
  --nvr NVR             NVR info.
  --source {beaker,testing-farm}
                        Source of the original result file (beaker or testing-farm)..
  -a NAME=URL [NAME=URL ...], --add-output-files NAME=URL [NAME=URL ...]
                        Add a list of output files to every test, the syntax is name=url (example: job_url=https://jenkins/job/my_job/1)
  --brew-task-id BREW_TASK_ID
                        Id of the Brew task where the package was compiled.
  -d, --debug           Enable it if using kernel debug build. DEPRECATED, kcidb_tool will get the information from the nvr.
  -i INPUT, --input INPUT
                        Path to the original result file.
  -o OUTPUT, --output OUTPUT
                        Path to the KCIDB file (By default kcidb.json).
  --origin ORIGIN       The default origin for all objects (By default kcidb_tool). It can be overwritten with builds-origin, checkout-origin or tests-origin
  --checkout-origin CHECKOUT_ORIGIN
                        The origin for the checkout, if it's not provided will fallback to origin
  --builds-origin BUILDS_ORIGIN
                        The origin for all builds, if it's not provided will fallback to origin
  --tests-origin TESTS_ORIGIN
                        The origin for all tests, if it's not provided will fallback to origin
  -t TEST_PLAN, --test_plan TEST_PLAN
                        (DEPRECATED) Generate only test_plan, please use the subcommand create-test-plan.
  --tests-provisioner-url TESTS_PROVISIONER_URL
                        URL of the tests provisioner, usually jenkins job url.
  --src-nvr SRC_NVR     NVR for the source package, nvr value will be used if it is not provided
  --submitter SUBMITTER
                        Email of the person who submitted the job.
  --report-rules REPORT_RULES
                        An string with the rules to send reports, must be JSON blob and it's used by CKI
  --arch ARCH           The architecture used in the kcidb file, it will overwrite others
  --distro DISTRO       The distro used in the kcidb file,, it will overwrite others
  --public              Set the result as public.
```

## Create Test Plan

Create a test plan from a kcidb file, here is the subcommand help

```console
$ kcidb_tool create-test-plan --help
usage: kcidb_tool create-test-plan [-h] --arch ARCH -c CHECKOUT --nvr NVR [--brew-task-id BREW_TASK_ID] [-d] [-o OUTPUT] [--origin ORIGIN]
                                   [--checkout-origin CHECKOUT_ORIGIN] [--builds-origin BUILDS_ORIGIN] [--src-nvr SRC_NVR] [--distro DISTRO] [--public]
                                   [--tests-provisioner-url TESTS_PROVISIONER_URL]

Create a simple test plan only with the system provision task.

options:
  -h, --help            show this help message and exit
  --arch ARCH           The test plan's architecture.
  -c CHECKOUT, --checkout CHECKOUT
                        The checkout name used to generate all the kcidb ids.
  --nvr NVR             NVR info.
  --brew-task-id BREW_TASK_ID
                        Id of the Brew task where the package was compiled.
  -d, --debug           Enable it if using kernel debug build. DEPRECATED, kcidb_tool will get the information from the nvr.
  -o OUTPUT, --output OUTPUT
                        Path to the KCIDB file (By default kcidb.json).
  --origin ORIGIN       The default origin for all objects (By default kcidb_tool). It can be overwritten with builds-origin, checkout-origin or tests-origin
  --checkout-origin CHECKOUT_ORIGIN
                        The origin for the checkout, if it's not provided will fallback to origin
  --builds-origin BUILDS_ORIGIN
                        The origin for all builds, if it's not provided will fallback to origin
  --src-nvr SRC_NVR     NVR for the source package, nvr value will be used if it is not provided
  --distro DISTRO       The distribution name used as the tree_name.
  --public              Set the test plan as public.
  --tests-provisioner-url TESTS_PROVISIONER_URL
                        URL of the tests provisioner.
```

### Merge

Merge multiple kcidb files, here is the subcommand help

```console
$ kcidb_tool merge --help
usage: kcidb_tool merge [-h] -r RESULT [-o OUTPUT]

Merge multiple kcidb files.

options:
  -h, --help            show this help message and exit
  -r RESULT, --result RESULT
                        Path to a source result (kcidb format).
  -o OUTPUT, --output OUTPUT
                        Path to the merged KCIDB file (By default merge_kcidb.json).
```

### Push2dw

Send a kcidb file to datawarehouse through the API.

```console
$ kcidb_tool push2dw --help
usage: kcidb_tool push2dw [-h] --token TOKEN [-i INPUT] [--url URL]

Send kcidb results to the datawarehouse API.

optional arguments:
  -h, --help            show this help message and exit
  --token TOKEN         Token in Datawarehouse.
  -i INPUT, --input INPUT
                        The path to the kcidb file (By default kcidb.json).
  --url URL             Datawarehouse URL (By default https://datawarehouse.cki-project.org)
```

If authenticating as a user, you must specify `--token "oidc"`, which will
trigger OIDC authentication.  You will need a valid Kerberos ticket to use
this method.  If running the `kernel-qe-tools` container, you can pass auth
this way by first switching to file-based cache for this session:

```console
export KRB5CCNAME=/tmp/krb5cc_$(id -u)
kinit your_username@IPA.REDHAT.COM
```

Then pass the following to your `podman` command:

```console
-v "$KRB5CCNAME:$KRB5CCNAME:Z" -e KRB5CCNAME="$KRB5CCNAME"
```

If authenticating with a bot account, the token can be specified
via `--token`, `DW_TOKEN` in the environment or via a configuration file:

* `/etc/bkr2kcidb/config.ini`
* `~/.config/bkr2kcidb/config.ini`
* `/etc/kcidb_tool/config.ini`
* `~/.config/kcidb_too/config.ini`

```ini
[dw]
token = <your token>
```

## Push2UMB

Set a kcidb file to DataWarehouse via UMB.

```console
kcidb_tool push2umb --help
usage: kcidb_tool push2umb [-h] --certificate CERTIFICATE [-i INPUT]

Send kcidb results through UMB.

options:
  -h, --help            show this help message and exit
  --certificate CERTIFICATE
                        Certificate file (pem) to send messages through UMB. Can also set via UMB_CERTIFICATE environment variable.
  -i INPUT, --input INPUT
                        The path to the kcidb file (By default kcidb.json).
```

Basically a pem file contains the certificate and the key. For example, if you have `.crt` and
`.key` file, you can create the `.pem` file easilly with:

```console
cat file.crt file.key > file.pem
```

## Download Logs

Download log files from test results to a local directory. This utility parses
Beaker or Testing Farm XML result files and downloads all log files referenced
in the XML to preserve the original directory structure locally.

The tool extracts log URLs from XML results files and downloads them while
maintaining the original path structure. It supports retry mechanisms and
timeout configuration for reliable downloads.

### Supported Sources

* **Beaker**: Full support for downloading logs from Beaker XML result files
* **Testing Farm**: Currently not implemented (will be added in future releases)

### Command Line Options

```console
kcidb_tool download-logs --help
usage: kcidb_tool download-logs [-h] --source {beaker,testing-farm} -i INPUT
                                [--external-file EXTERNAL_FILE] [-o OUTPUT]
                                [--retries RETRIES] [--timeout TIMEOUT]

Download logs from test results to a local directory.

options:
  -h, --help            show this help message and exit
  --source {beaker,testing-farm}
                        Source of the original result file (beaker or testing-farm)
  -i INPUT, --input INPUT
                        Path to the original result file
  --external-file EXTERNAL_FILE
                        External file to download, allowed schemas: ftp, https, http.
                        This argument can be used several times.
  -o OUTPUT, --output OUTPUT
                        Local directory to save logs (default: logs)
  --retries RETRIES     Number of retries to download a log (default: 5)
  --timeout TIMEOUT     Request timeout in seconds (default: 30)
```

### Examples

Download logs from a Beaker XML result file:

```console
kcidb_tool download-logs --source beaker --input beaker_results.xml --output my_logs
```

Download with custom retry and timeout settings:

```console
kcidb_tool download-logs --source beaker --input beaker_results.xml --output my_logs --retries 10 --timeout 60
```

### Directory Structure

The tool preserves the original directory structure from the URLs. For example, if the XML contains:

```xml
<log href="https://server.com/recipes/123/logs/console.log" name="console.log"/>
<log href="https://server.com/recipes/123/tasks/456/logs/taskout.log" name="taskout.log"/>
```

The downloaded structure will be:

```text
logs/
├── recipes/
│   └── 123/
│       ├── logs/
│       │   └── console.log
│       └── tasks/
│           └── 456/
│               └── logs/
│                   └── taskout.log
```

### Configuration

* **Default output directory**: `logs/`
* **Default retries**: 5 attempts
* **Default timeout**: 30 seconds
* **Chunk size**: 8192 bytes (internal)

## Change Tests Location

Update log file URLs in a KCIDB file by replacing an old URL prefix with a new one.
This is useful when log files have been moved to a different server or location
and you need to update the references in your KCIDB file.

The tool processes both test-level output files and result-level output files within
each test, replacing URLs that start with the specified old prefix with the new prefix.
Only URLs that begin with the old prefix are modified - other URLs remain unchanged.

```console
kcidb_tool change-tests-location --help
usage: __main__.py change-tests-location [-h] -i INPUT --old OLD --new NEW

Change tests location.

options:
  -h, --help            show this help message and exit
  -i INPUT, --input INPUT
                        Path to the kcidb file.
  --old OLD             Old tests path location
  --new NEW             New tests path location
```

Update log URLs from an old server to a new server:

```console
kcidb_tool change-tests-location --input kcidb_results.json --old https://old-server.com --new https://new-server.com
```

### Important Notes

* Only URLs that **start with** the old prefix will be replaced
* The tool modifies the original file in-place
* URLs that don't match the old prefix remain unchanged
