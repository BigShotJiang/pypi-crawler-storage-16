#/usr/bin/sh
cd /opt/JobSubmitter/
exec ./JobSubmitter.sh "$@"
