#/usr/bin/sh
cd /opt/JobSubmitter/
python3 ./JobSubmitter_git.py "$@"
