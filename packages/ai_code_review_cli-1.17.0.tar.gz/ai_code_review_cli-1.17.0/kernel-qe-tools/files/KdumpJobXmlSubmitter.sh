#/usr/bin/sh
cd /opt/KdumpJobXml
python3 ./bkr_xml_submitter.py "$@"
