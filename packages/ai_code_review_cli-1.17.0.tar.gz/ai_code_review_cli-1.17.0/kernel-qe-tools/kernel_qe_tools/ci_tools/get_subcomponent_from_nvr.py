"""Get subcomponent(s) from a kernel build's changelog.

Given a kernel NVR, this tool parses the build's changelog to extract
JIRA issue IDs, then queries JIRA to get the subcomponent for each issue.

This is useful for determining which kernel subsystems are affected by
a particular build.
"""

import argparse
import json
import logging
import os
import re
from typing import Final

from jira import JIRA
import koji

# JIRA configuration
JIRA_SERVER: Final[str] = os.getenv("JIRA_SERVER", "https://issues.redhat.com")

logger = logging.getLogger(__name__)


def get_jira_token() -> str | None:
    """Get JIRA API token from environment."""
    return os.environ.get("JIRA_TOKEN")


def get_changelog_entries(nvr: str, koji_hub: str | None = None) -> str:
    """Get the changelog entry for a build NVR from Koji/Brew.

    Only returns the first changelog entry (the one for the specific build),
    not the full history.

    Args:
        nvr: The NVR (Name-Version-Release) of the build.
        koji_hub: Optional Koji hub URL. If not provided, uses the default
            from koji configuration (/etc/koji.conf).

    Returns:
        The changelog entry string for the build, or empty string if not found.
    """
    if koji_hub:
        session = koji.ClientSession(koji_hub)
    else:
        # Read default koji profile config from /etc/koji.conf
        config = koji.read_config('koji')
        session = koji.ClientSession(config['server'])

    build = session.getBuild(nvr, strict=False)
    if not build:
        logger.error("Build not found: %s", nvr)
        return ""

    build_id = build["build_id"]
    entries = session.getChangelogEntries(buildID=build_id, strict=False)
    if not entries:
        return ""

    # Only return the first entry (the one for this specific build)
    first_entry = entries[0]
    # The entry is a dict with 'author', 'date', 'text' keys
    if isinstance(first_entry, dict):
        return first_entry.get('text', '')
    return str(first_entry)


def extract_jira_issues(changelog_text: str) -> list[str]:
    """Extract JIRA issue IDs from changelog text.

    Looks for patterns like [RHEL-12345] in the changelog text.

    Args:
        changelog_text: The changelog text to parse.

    Returns:
        Deduplicated list of JIRA issue IDs.
    """
    # Find all individual RHEL-XXXXX patterns
    issues: set[str] = set()
    pattern = r"RHEL-\d{2,}"
    for match in re.finditer(pattern, changelog_text):
        issues.add(match.group())

    return sorted(issues)


def get_subcomponents_from_issues(issues: list[str], jira_token: str) -> list[str]:
    """Query JIRA to get subcomponents for the given issues.

    Args:
        issues: List of JIRA issue IDs.
        jira_token: JIRA API token for authentication.

    Returns:
        Deduplicated list of subcomponent names.
    """
    if not issues:
        return []

    try:
        client = JIRA(server=JIRA_SERVER, token_auth=jira_token)
    except Exception as e:
        logger.error("Failed to connect to JIRA: %s", e)
        return []

    # Query all issues at once
    issue_str = ",".join(issues)
    jql = f"key in ({issue_str})"

    try:
        results = client.search_issues(jql, maxResults=len(issues))
    except Exception as e:
        logger.error("JIRA query failed: %s", e)
        return []

    subcomponents: set[str] = set()
    for issue in results:
        try:
            # The component field contains the subcomponent info
            # Format is typically "Category / Subcategory" or just "Category"
            if issue.fields.components:
                component = issue.fields.components[0].name
                parts = component.split(" / ", 1)
                if len(parts) > 1:
                    # Extract subcomponent (after the slash)
                    subcomponent = parts[1].replace("/", "")
                    subcomponents.add(" ".join(subcomponent.split()))
        except (IndexError, AttributeError):
            # Issue has no components, skip
            continue

    return sorted(subcomponents)


def main(args: list[str] | None = None) -> int:
    """Command line interface for get_subcomponent_from_nvr."""
    description = "Get subcomponent(s) from a kernel build's changelog"

    parser = argparse.ArgumentParser(description=description)
    parser.add_argument(
        "nvr",
        help="The NVR of the kernel build (e.g., kernel-5.14.0-570.61.1.el9_6)",
    )
    parser.add_argument(
        "-v", "--verbose",
        action="count",
        default=0,
        help="Enable verbose output",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output results as JSON",
    )
    parser.add_argument(
        "--koji-hub",
        help="Koji hub URL (default: from /etc/koji.conf)",
    )

    parsed_args = parser.parse_args(args)

    # Configure logging
    log_level = logging.DEBUG if parsed_args.verbose > 1 else logging.INFO
    logging.basicConfig(level=log_level, format="%(levelname)s: %(message)s")

    # Check for JIRA token
    jira_token = get_jira_token()
    if not jira_token:
        logger.error("JIRA_TOKEN environment variable not set")
        return 1

    # Get changelog entries from Koji/Brew
    if parsed_args.verbose:
        print(f"Fetching changelog for {parsed_args.nvr}...")

    changelog_entries = get_changelog_entries(parsed_args.nvr, parsed_args.koji_hub)
    if not changelog_entries:
        logger.error("No changelog entries found for %s", parsed_args.nvr)
        return 1

    # Extract JIRA issues from changelog
    issues = extract_jira_issues(changelog_entries)
    if parsed_args.verbose:
        print(f"Found {len(issues)} JIRA issues in changelog")

    if not issues:
        print("[]")
        return 0

    # Query JIRA for subcomponents
    if parsed_args.verbose:
        print("Querying JIRA for subcomponents...")

    subcomponents = get_subcomponents_from_issues(issues, jira_token)

    # Output results
    if parsed_args.json:
        print(json.dumps(subcomponents))
    else:
        print(subcomponents)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
