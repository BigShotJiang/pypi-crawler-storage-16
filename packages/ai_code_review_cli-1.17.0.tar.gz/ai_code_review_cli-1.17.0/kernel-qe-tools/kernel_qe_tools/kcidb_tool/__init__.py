"""bkr2kcidb module."""
