"""Main entrypoint for kcidb_tool."""

import sys

from . import cli

sys.exit(cli.main())  # pragma: no cover
