"""Subcommand change tests location."""

import pathlib

from cki_lib import logger
from cki_lib import misc
from cki_lib import yaml
from cki_lib.kcidb import KCIDBFile

from . import cmd_misc

LOGGER = logger.get_logger(__name__)


def build(cmds_parser, common_parser):
    """Build the argument parser for the change tests location command."""
    cmd_description = 'Change tests location.'
    cmd_parser, _ = cmd_misc.build(
        cmds_parser,
        common_parser,
        "change-tests-location",
        help_message=cmd_description,
        add_subparser=False,
    )

    cmd_parser.description = cmd_description
    cmd_parser.add_argument('-i', '--input',
                            type=pathlib.Path,
                            required=True,
                            help="Path to the kcidb file.")

    cmd_parser.add_argument('--old',
                            type=str,
                            required=True,
                            help='Old tests path location')

    cmd_parser.add_argument('--new',
                            type=str,
                            required=True,
                            help='New tests path location')


def main(args):
    """Run cli command."""
    if not args.input.is_file():
        LOGGER.error('Input file %s does not exist', str(args.input))
        return 1

    try:
        kcidb_file = KCIDBFile(args.input.resolve())
    except yaml.ValidationError as exc:
        LOGGER.error('Input file %s is not a valid kcidb file', str(args.input))
        LOGGER.error('Validation error: %s', str(exc))
        LOGGER.error('Please check the file and try again.')
        return 1

    for test in kcidb_file.data['tests']:
        test_logs = 0
        test_updated_logs = 0
        results_logs = 0
        results_updated_logs = 0

        # Test logs
        for output_file in test.get('output_files', []):
            test_logs += 1
            if output_file['url'].startswith(args.old):
                output_file['url'] = output_file['url'].replace(args.old, args.new, 1)
                test_updated_logs += 1
        if 'log_url' in test:
            test_logs += 1
            if test['log_url'].startswith(args.old):
                test_updated_logs += 1
                test['log_url'] = test['log_url'].replace(args.old, args.new, 1)

        # Results logs
        for result in misc.get_nested_key(test, 'misc/results', []):
            for output_file in result.get('output_files', []):
                results_logs += 1
                if output_file['url'].startswith(args.old):
                    output_file['url'] = output_file['url'].replace(args.old, args.new, 1)
                    results_updated_logs += 1

        # Update test in kcidb
        kcidb_file.set_test(test['id'], test)

        # Test summary
        LOGGER.info('Test %s updated: '
                    'test logs %d/%d, '
                    'results logs %d/%d',
                    test['id'], test_updated_logs, test_logs,
                    results_updated_logs, results_logs)
    kcidb_file.save()
    LOGGER.info('File %s wrote !!', args.input.name)
    return 0
