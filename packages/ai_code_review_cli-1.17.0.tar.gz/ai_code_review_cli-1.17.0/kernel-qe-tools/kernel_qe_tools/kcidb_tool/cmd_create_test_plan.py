"""Subcommand create."""
import pathlib

from cki_lib import logger
from cki_lib.kcidb import KCIDBFile
from cki_lib.yaml import ValidationError

from . import cmd_misc
from . import utils
from .dataclasses import NVR
from .dataclasses import TestPlanParserArguments
from .test_plan_parser import TestPlanParser

LOGGER = logger.get_logger(__name__)


def build(cmds_parser, common_parser):
    """Build the argument parser for the create command."""
    # pylint: disable=duplicate-code
    cmd_parser, _ = cmd_misc.build(
        cmds_parser,
        common_parser,
        "create-test-plan",
        help_message='Create a simple test plan only with the system provision task.',
        add_subparser=False,
    )

    cmd_parser.description = 'Create a simple test plan only with the system provision task.'

    cmd_parser.add_argument('--arch',
                            type=str,
                            required=True,
                            help="The test plan's architecture.")

    cmd_parser.add_argument('-c', '--checkout',
                            type=str,
                            required=True,
                            help="The checkout name used to generate all the kcidb ids.")

    cmd_parser.add_argument('--nvr',
                            type=str,
                            required=True,
                            help="NVR info.")

    cmd_parser.add_argument('--brew-task-id',
                            type=str,
                            required=False,
                            help="Id of the Brew task where the package was compiled.")

    cmd_parser.add_argument('-d', '--debug',
                            action='store_true',
                            help="Enable it if using kernel debug build."
                            " DEPRECATED, kcidb_tool will get the information from the nvr.")

    cmd_parser.add_argument('-o', '--output',
                            type=str,
                            default='kcidb.json',
                            help="Path to the KCIDB file (By default kcidb.json).")

    cmd_parser.add_argument('--origin',
                            type=str,
                            required=False,
                            default='kcidb_tool',
                            help="The default origin for all objects (By default kcidb_tool)."
                            " It can be overwritten with builds-origin, checkout-origin or"
                            " tests-origin")

    cmd_parser.add_argument('--checkout-origin',
                            type=str,
                            required=False,
                            help="The origin for the checkout, if it's not provided will"
                            " fallback to origin")

    cmd_parser.add_argument('--builds-origin',
                            type=str,
                            required=False,
                            help="The origin for all builds, if it's not provided will"
                            " fallback to origin")

    cmd_parser.add_argument('--src-nvr',
                            type=str,
                            required=False,
                            help="NVR for the source package, nvr value will be used if it is not"
                            " provided"
                            )

    cmd_parser.add_argument('--distro',
                            type=str,
                            required=False,
                            help="The distribution name used as the tree_name.")

    cmd_parser.add_argument('--public',
                            action='store_true',
                            help="Set the test plan as public.")

    cmd_parser.add_argument('--tests-provisioner-url',
                            type=str,
                            required=False,
                            help="URL of the tests provisioner.")


def main(args):
    """Run cli command."""
    # pylint: disable=duplicate-code
    package_name, package_version, package_release = utils.get_nvr(args.nvr)
    if None in [package_name, package_version, package_release]:
        LOGGER.error('Invalid value for nvr: %s', args.nvr)
        return 1

    if args.debug and not package_name.endswith('-debug'):
        package_name += '-debug'

    src_nvr = args.src_nvr or args.nvr
    src_package_name, src_package_version, src_package_release = utils.get_nvr(src_nvr)
    if None in [src_package_name, src_package_version, src_package_release]:
        LOGGER.error('Invalid value for source nvr: %s', src_nvr)
        return 1

    external_arguments = TestPlanParserArguments(
        arch=args.arch,
        brew_task_id=args.brew_task_id,
        builds_origin=args.builds_origin or args.origin,
        checkout=args.checkout,
        checkout_origin=args.checkout_origin or args.origin,
        nvr=NVR(package_name, package_version, package_release),
        src_nvr=NVR(src_package_name, src_package_version, src_package_release),
        distro=args.distro,
        public=args.public,
        tests_provisioner_url=args.tests_provisioner_url,
    )

    parser = TestPlanParser(external_arguments)

    parser.process()

    if pathlib.Path(args.output).is_file():
        LOGGER.warning('File %s already exists and will be merged !!', args.output)
        old_file = KCIDBFile(pathlib.Path(args.output))

        # Adding checkouts
        for kcidb_checkout in parser.report.get('checkouts', []):
            old_file.update_or_create_checkout(kcidb_checkout['id'], kcidb_checkout)
        # Adding builds
        for kcidb_build in parser.report.get('builds', []):
            old_file.update_or_create_build(kcidb_build['id'], kcidb_build)
        # Adding tests
        for kcidb_test in parser.report.get('tests', []):
            old_file.update_or_create_test(kcidb_test['id'], kcidb_test)
        old_file.save()

    else:
        try:
            parser.write(args.output)
        except ValidationError as exc:
            LOGGER.error('Validation error: %s', str(exc))
            return 1

    LOGGER.info('File %s wrote !!', args.output)
    return 0
