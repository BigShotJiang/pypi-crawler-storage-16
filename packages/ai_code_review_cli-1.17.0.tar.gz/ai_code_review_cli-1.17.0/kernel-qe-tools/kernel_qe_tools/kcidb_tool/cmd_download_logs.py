"""Command to download logs from a results file."""

import argparse
import pathlib
from urllib.parse import urlparse
import xml.etree.ElementTree as ET

from cki_lib import logger
from cki_lib.session import get_session
import requests

from . import cmd_misc
from .dataclasses import TestToDownload

# Constants
DEFAULT_CHUNK_SIZE = 8192
DEFAULT_RETRIES = 5
DEFAULT_OUTPUT_DIR = 'logs'
DEFAULT_TIMEOUT = 30  # seconds
ALLOWED_EXTERNAL_FILE_SCHEMES = {'http', 'https', 'ftp'}

LOGGER = logger.get_logger(__name__)


def external_file_type(value: str) -> str:
    """Get if the external file is a valid URL."""
    parsed_url = urlparse(value)
    if parsed_url.scheme not in ALLOWED_EXTERNAL_FILE_SCHEMES:
        raise argparse.ArgumentTypeError(
            f"Invalid URL scheme '{parsed_url.scheme}' for '{value}'. "
            f"Allowed schemes are: {', '.join(ALLOWED_EXTERNAL_FILE_SCHEMES)}"
        )
    return value


def download_logs(tests_to_download: list[TestToDownload], max_retries: int,
                  timeout: int = DEFAULT_TIMEOUT, create_if_not_found: bool = False) -> None:
    """Download logs from a list of TestToDownload objects.

    Args:
        tests_to_download: List of TestToDownload objects containing origin URLs and destinations
        max_retries: Maximum number of retry attempts for failed downloads
        timeout: Request timeout in seconds
        create_if_not_found: If True, create destination file with descriptive message when
            origin doesn't exist

    Raises:
        requests.exceptions.RequestException: If download fails after retries
    """
    session = get_session(
        'kcidb_tool.download_logs',
        raise_for_status=True,
        retry_args={
            'total': max_retries,
            'status_forcelist': [404, 413, 429, 500, 502, 503, 504],
        },
        timeout=timeout
    )

    total_files = len(tests_to_download)
    LOGGER.info("Starting download of %d log files...", total_files)

    for i, test in enumerate(tests_to_download, 1):
        LOGGER.info("Downloading %d/%d: %s", i, total_files, test.origin)

        # Ensure destination directory exists
        if not test.destination.parent.exists():
            test.destination.parent.mkdir(parents=True, exist_ok=True)

        try:
            response = session.get(test.origin, stream=True)
            with open(test.destination, 'wb') as f:
                for chunk in response.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                    if chunk:  # Filter out keep-alive chunks
                        f.write(chunk)

        except requests.exceptions.HTTPError as exc:
            if create_if_not_found and exc.response.status_code == 404:
                # Create destination file with descriptive message for missing files
                error_message = (
                    "ERROR: Original log file not found\n"
                    f"Origin URL: {test.origin}\n"
                    f"HTTP Status: {exc.response.status_code}\n"
                    f"Error: {exc}\n"
                    "This file was created because the original log file was not accessible.\n"
                )

                test.destination.write_text(error_message, encoding='utf-8')

                LOGGER.warning("Created placeholder file for missing origin: %s", test.origin)
            else:
                # Re-raise the exception if we're not handling missing files
                raise


def get_beaker_logs(beaker_results: ET.Element, local_path: pathlib.Path) -> list[TestToDownload]:
    """Extract log URLs from Beaker XML results.

    Args:
        beaker_results: Parsed Beaker XML results element
        local_path: Local directory path where logs will be saved

    Returns:
        List of TestToDownload objects with origin URLs and destination paths
    """
    beaker_logs: list[TestToDownload] = []

    # Extract logs from the beaker results
    for log in beaker_results.findall(".//log[@href]"):
        beaker_logs.append(
            get_test_to_download(log.attrib['href'], local_path)
        )

    return beaker_logs


def is_valid_log_file(url: str) -> bool:
    """Check if the URL points to a valid log file based on its extension.

    Args:
        url: URL of the log file

    Returns:
        True if the URL ends with a valid log file extension, False otherwise
    """
    parsed_url = urlparse(url)
    path = pathlib.Path(parsed_url.path)
    return path.suffix != ''


def get_testing_farm_logs(tf_results: ET.Element, local_path: pathlib.Path) -> list[TestToDownload]:
    """Extract logs URL from Testing Farm XML results.

    Args:
        tf_results: Parsed Testing Farm XML results element
        local_path: Local directory path where logs will be saved

    Returns:
        List of TestToDownload objects with origin URLs and destination paths

    We only get log files with extension because in Testing Farm results XML,
    we can find directories as well, which we don't want to download.
    """
    tf_logs: list[TestToDownload] = []

    for log in tf_results.findall(".//log[@href]"):
        if is_valid_log_file(log.attrib['href']):
            tf_logs.append(
                get_test_to_download(log.attrib['href'], local_path)
            )

    return tf_logs


def get_test_to_download(url: str, local_path: pathlib.Path) -> TestToDownload:
    """Create a TestToDownload object from a URL and local path.

    Args:
        url: URL of the log file to download
        local_path: Local directory path where the log will be saved

    Returns:
        TestToDownload object with origin URL and destination path
    """
    log_path = urlparse(url).path[1:]  # Remove leading slash
    return TestToDownload(
        origin=url,
        destination=pathlib.Path(local_path, str(log_path)),
    )


def build(cmds_parser, common_parser):
    """Build the argument parser for the download-logs command."""
    subcommand_description = 'Download logs from test results to a local directory.'

    cmd_parser, _ = cmd_misc.build(
        cmds_parser,
        common_parser,
        "download-logs",
        help_message=subcommand_description,
        add_subparser=False,
    )

    cmd_parser.description = subcommand_description

    cmd_parser.add_argument(
        '--source',
        type=str,
        choices=['beaker', 'testing-farm'],
        required=True,
        help="Source of the original result file (beaker or testing-farm)"
    )

    cmd_parser.add_argument(
        '-i', '--input',
        type=pathlib.Path,
        required=True,
        help="Path to the original result file"
    )

    cmd_parser.add_argument(
        '--external-file',
        type=external_file_type,
        action='append',
        help='External file to download, allowed schemas: '
             f'{", ".join(ALLOWED_EXTERNAL_FILE_SCHEMES)}. '
             'This argument can be used several times.')

    cmd_parser.add_argument(
        '-o', '--output',
        type=pathlib.Path,
        default=pathlib.Path(DEFAULT_OUTPUT_DIR),
        help=f"Local directory to save logs (default: {DEFAULT_OUTPUT_DIR})"
    )

    cmd_parser.add_argument(
        '--retries',
        type=int,
        default=DEFAULT_RETRIES,
        help=f"Number of retries to download a log (default: {DEFAULT_RETRIES})"
    )

    cmd_parser.add_argument(
        '--timeout',
        type=int,
        default=DEFAULT_TIMEOUT,
        help=f"Request timeout in seconds (default: {DEFAULT_TIMEOUT})"
    )


def main(args):
    """Run cli command."""
    # Output path
    if args.output.is_file():
        LOGGER.error('%s is a file, expected a directory', str(args.output))
        return 1
    if args.output.is_dir():
        LOGGER.info('%s directory exists', str(args.output))
    if not args.output.exists():
        LOGGER.info('Creating output directory %s', str(args.output))
        args.output.mkdir(parents=True, exist_ok=True)

    if not args.input.is_file():
        LOGGER.error('Input file %s does not exist', str(args.input))
        return 1

    external_files = [get_test_to_download(external_file, args.output)
                      for external_file in (args.external_file or [])]

    xml_content = args.input.read_text('utf-8')

    LOGGER.info(
        'Downloading logs from Beaker results file %s to %s',
        str(args.input),
        str(args.output)
    )
    try:
        number_of_logs = 0
        if args.source == 'beaker':
            beaker_results = ET.fromstring(xml_content)
            LOGGER.info('Downloading logs from Beaker results file')
            tests_logs = get_beaker_logs(beaker_results, args.output)
            download_logs(tests_logs, max_retries=args.retries, timeout=args.timeout,
                          create_if_not_found=False)
            number_of_logs += len(tests_logs)
        else:  # Must be 'testing-farm' due to argparse choices
            testing_farm_results = ET.fromstring(xml_content)
            LOGGER.info('Downloading logs from Testing Farm results file')
            tests_logs = get_testing_farm_logs(testing_farm_results, args.output)
            download_logs(tests_logs, max_retries=args.retries, timeout=args.timeout,
                          create_if_not_found=False)
            number_of_logs += len(tests_logs)
        if len(external_files) > 0:
            LOGGER.info('Downloading external files: %d', len(external_files))
            download_logs(external_files, max_retries=args.retries, timeout=args.timeout,
                          create_if_not_found=False)
            number_of_logs += len(external_files)

    except requests.exceptions.HTTPError as exc:
        LOGGER.error('HTTP error occurred: %s', str(exc))
        return 1
    except requests.exceptions.RequestException as exc:
        LOGGER.error('A request error occurred: %s', str(exc))
        return 1
    LOGGER.info('%d log files downloaded successfully to %s', number_of_logs, str(args.output))
    return 0
