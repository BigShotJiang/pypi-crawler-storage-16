"""Subcommand push2umb."""

import json
import os
import pathlib

from cki_lib import stomp
from cki_lib.logger import get_logger
from cki_lib.retrying import retrying_on_exception

from . import cmd_misc

LOGGER = get_logger(__name__)

DATAWAREHOUSE_URL = 'https://datawarehouse.cki-project.org'
UMB_HOST = 'umb.api.redhat.com'
UMB_PORT = 61612
UMB_TOPIC = '/topic/VirtualTopic.eng.cki.results'


def build(cmds_parser, common_parser):
    """Build the argument parser for the create command."""
    cmd_parser, _ = cmd_misc.build(
        cmds_parser,
        common_parser,
        "push2umb",
        help_message='Send kcidb results through UMB.',
        add_subparser=False,
    )

    umb_certificate = os.environ.get('UMB_CERTIFICATE')

    cmd_parser.description = 'Send kcidb results through UMB.'

    cmd_parser.add_argument('-c',
                            '--certificate',
                            type=str,
                            required=True,
                            default=umb_certificate,
                            help="Certificate file (pem) to send messages through UMB. "
                                 "Can also set via UMB_CERTIFICATE environment variable."
                            )

    cmd_parser.add_argument('-i', '--input',
                            type=pathlib.Path,
                            required=False,
                            default=pathlib.Path('kcidb.json'),
                            help="The path to the kcidb file (By default kcidb.json)."
                            )


@retrying_on_exception(stomp.StompException, retries=5, initial_delay=10)
def send_with_stomp(data, certfile: str) -> None:
    """Send message to UMB with retry on exception.

    Decorated with retrying_on_exception to retry on StompException with
    5 attempts and 10s linear backoff increments.  StompException will
    capture both server disconnect and error response events.
    """
    stomp.StompClient(host=UMB_HOST,
                      port=UMB_PORT,
                      certfile=certfile).send_message(data, UMB_TOPIC)


def main(args):
    """Run cli command."""
    if not args.input.is_file():
        LOGGER.error('%s is not a file or does not exist', str(args.input))
        return 1
    if not pathlib.Path(args.certificate).is_file():
        LOGGER.error('%s is not a file or does not exist', args.certificate)
        return 1

    data = json.loads(args.input.read_text(encoding='utf-8'))

    LOGGER.info('Sending KCIDB data through UMB')
    try:
        send_with_stomp(data, args.certificate)
    # pylint: disable=broad-except
    except Exception:
        LOGGER.exception('Unable to send KCIDB data through UMB')
        return 1

    LOGGER.info('KCIDB data sent successfully')
    for checkout in data.get('checkouts'):
        LOGGER.info('DataWarehouse link: %s/kcidb/checkouts/%s', DATAWAREHOUSE_URL, checkout['id'])
    return 0
