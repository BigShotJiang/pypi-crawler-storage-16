"""Dataclasses."""
from dataclasses import dataclass
import pathlib
import typing


@dataclass
class ExternalOutputFile:
    """External OutputFile."""

    name: str
    url: str


@dataclass
class NVR:
    """NVR representation."""

    name: str
    version: str
    release: str


@dataclass
class ParserArguments:
    """Arguments to pass to a bkr2kcidb parser.

    All external arguments should be here
    """

    # pylint: disable=too-many-instance-attributes
    brew_task_id: str
    builds_origin: str
    checkout: str
    checkout_origin: str
    contacts: typing.List[str]
    extra_output_files: typing.List[ExternalOutputFile] | None
    nvr: NVR
    src_nvr: NVR
    test_plan: bool
    tests_origin: str
    tests_provisioner_url: str
    # Set default values until downstream project are updated
    report_rules: str | None = ''
    submitter: str | None = ''
    arch: str | None = None
    distro: str | None = None
    public: bool = False


@dataclass
class TestPlanParserArguments:
    """Argument to pass to the Test Plan Parser."""

    # pylint: disable=too-many-instance-attributes
    __test__ = False

    arch: str
    brew_task_id: str
    builds_origin: str
    checkout: str
    checkout_origin: str
    nvr: NVR
    src_nvr: NVR
    distro: str | None = None
    public: bool = False
    tests_provisioner_url: str | None = None


@dataclass
class TestToDownload:
    """Download test info."""

    __test__ = False

    origin: str
    destination: pathlib.Path
