"""KCIDB Tool Exceptions."""


class KCIDBParserArchNotFoundException(Exception):
    """Exception raised when the KCIDB the arch is not found."""


class KCIDBParserTreeNameNotFoundException(Exception):
    """Exception raised when the KCIDB the tree name is not found."""
