"""Testing Farm parser to kcidb."""

import datetime
import hashlib
import re
import sys

from cki_lib import misc as cki_lib_misc
from cki_lib.logger import get_logger

from . import utils as testing_farm_utils
from .. import utils
from ..exceptions import KCIDBParserArchNotFoundException
from ..exceptions import KCIDBParserTreeNameNotFoundException
from ..parser import KCIDBToolParser

LOGGER = get_logger(__name__)


class TestingFarmParser(KCIDBToolParser):
    """Parser."""

    DEFAULT_TEST_LOG_FILENAME = 'testout.log'
    __test__ = False

    def __init__(self, testing_farm_content, args):
        """Initialize object with the given data."""
        super().__init__(testing_farm_content, args)
        self.test_suite_info = {}
        self.common_logs = ['console log', 'workdir']
        self.start_time = cki_lib_misc.now_tz_utc()
        self.job_url: str | None = None

    def add_checkout(self):
        """Add checkout."""
        self.report['checkout'] = utils.clean_dict({
            'id': self.checkout_id,
            'origin': self.args.checkout_origin or self.args.origin,
            'tree_name': self.tree_name,
            'valid': True,
            'misc': self.add_checkout_misc_info(),
            'start_time': self.start_time.isoformat()
        })

    def add_build(self):
        """Add build if it is not present."""
        if not self.exist_build_by_arch():
            self.report['builds'].append({
                'id': self._get_build_id(),
                'origin': self.args.builds_origin or self.args.origin,
                'checkout_id': self.checkout_id,
                'architecture': self.test_suite_info['arch'],
                'valid': True,
                'misc': self.add_build_misc_info()
            })

    def add_test_misc_info(self, test_case, test):
        """Return misc for a test."""
        misc = {}
        misc["results"] = []
        misc["provenance"] = []

        results = test_case.find('subresults')
        # Only add virtual result to real test cases
        # The virtual result when added is always the first one
        if test_case.get('fake', 'false') != 'True':
            # only add a virtual result, in case the test didn't provided any subresult
            if results is None:
                misc["results"] += [testing_farm_utils.create_virtual_result(test)]

        if results is not None:
            misc['results'] += testing_farm_utils.get_results(test,
                                                              results,
                                                              len(misc['results']) + 1)

        results = test_case.find('checks')
        if results is not None:
            misc['results'] += testing_farm_utils.get_results(test,
                                                              results,
                                                              len(misc['results']) + 1)
        if self.args.tests_provisioner_url:
            misc['provenance'] += [utils.get_provenance_info('provisioner',
                                                             self.args.tests_provisioner_url
                                                             )]
        if self.job_url:
            misc['provenance'] += [utils.get_provenance_info('executor', self.job_url)]

        misc['maintainers'] = testing_farm_utils.get_test_case_maintainers(test_case) \
            or self.default_maintainers

        return utils.clean_dict(misc)

    def add_test(self, test_case, test_case_id):
        """Add test."""
        test = {
            'id': self._get_test_id(test_case_id),
            'origin': self.args.tests_origin or self.args.origin,
            'build_id': self._get_build_id(),
            'comment': test_case.get('name'),
            'path': utils.slugify(test_case.get('name')),
        }
        if not self.args.test_plan:
            test['start_time'] = self.test_suite_info['start_time'].isoformat()
            test['duration'] = int(test_case.get('time', '0'))
            test['output_files'] = utils.get_output_files(test_case.find('logs')) + \
                self.get_extra_output_files() + \
                self.test_suite_info['common_logs']
            test['status'] = testing_farm_utils.get_kcidb_test_status(test_case.get('result'))
            test['misc'] = self.add_test_misc_info(test_case, test)
            # Until this issue is not fixed, we need to re evaluate test overall results
            # https://issues.redhat.com/browse/RHELTEST-1054
            if test['status'] != testing_farm_utils.get_test_status_from_results(test):
                status_mismatch_result = testing_farm_utils.create_status_mismatch_result(
                    test, len(test['misc']["results"]) + 1)
                test['misc']["results"] += [status_mismatch_result]
                LOGGER.error('%s overall test status does not match overall results status',
                             test['id'])

            test['environment'] = utils.clean_dict({
                'comment': testing_farm_utils.get_hostname_from_testcase(test_case)
            })
            # update test suite start time
            self.test_suite_info['start_time'] += datetime.timedelta(seconds=test['duration'])

            test['log_url'] = self.get_default_test_log(test['output_files'])

            testing_farm_utils.remove_duplicated_logs(test)

        self.report['tests'].append(utils.clean_dict(test))

    def set_tree_name(self, element):
        """Get the treename from the parser argument or from a XML element from results."""
        if self.args.distro is not None:
            self.tree_name = self.args.distro
            return
        compose = testing_farm_utils.get_compose_from_xml(element)
        if compose is not None:
            try:
                regxep = re.compile(r'(rhel-\d+\.\d+)')
                re_match = regxep.match(compose.lower())
                if re_match:
                    self.tree_name = re_match[1]
            except AttributeError:
                pass

    def process(self):
        """Iterate through all testsuites to generate the report."""
        self._clean_report()
        # Get tree name from the first testsuite
        self.set_tree_name(self.root.find('testsuite'))
        self.add_checkout()
        start_time = self.start_time
        test_case_id = 1

        # We need something to make the test-id unique for the case of
        # merging multiple results together.  Since the logs are
        # stored in unique directories, making a hash of the "<log
        # href=" values gives us something unique enough.
        uniq = hashlib.sha256()
        for log in self.root.findall(".//log[@href]"):
            uniq.update(log.attrib['href'].encode('utf-8'))
        test_tag = uniq.hexdigest()[0:5]
        for test_suite in self.root.iter('testsuite'):
            test_suite_name = test_suite.get('name', 'UNDEFINED')
            logs = test_suite.find('logs')
            self.job_url = testing_farm_utils.get_job_url(logs)
            # Testing farm provides all testcases in the same testsuite in multihost scenarios
            # so we need to group them by guest, similar to Beaker with recipes.
            group_of_test_cases = testing_farm_utils.group_testcases_by_guest(test_suite)
            # If we don't have test cases, we should add the system provision test case
            # Unless the arch is not defined
            if len(group_of_test_cases) == 0:
                print(f"Test suite {test_suite_name} does not contain test cases",
                      file=sys.stderr)
                if self.args.arch is not None:
                    arch = self.args.arch
                else:
                    arch = testing_farm_utils.get_arch_from_testsuite(test_suite)
                self.set_tree_name(test_suite)
                # Testing Farm ISSUE https://issues.redhat.com/projects/TFT/issues/TFT-2641
                # When the sut can not provisioned testing does not provide any information
                # about arch and compose, this bug is still present in multihost scenarios
                if arch is None:
                    raise KCIDBParserArchNotFoundException(
                        f"Can't get arch from testsuite {test_suite_name}"
                    )
                if self.tree_name is None:
                    raise KCIDBParserTreeNameNotFoundException(
                        f"Can't get tree name from testsuite {test_suite_name}"
                    )
                self.test_suite_info = {
                    'arch': arch,
                    'whiteboard': test_suite_name,
                    'start_time': start_time,
                    'common_logs': utils.get_output_files(logs, self.common_logs)
                }
                self.arch = self.test_suite_info['arch']
                self.add_build()
                # Add the system provision to this test suite
                system_provision = \
                    testing_farm_utils.create_system_provision_test_case(test_suite,
                                                                         [],
                                                                         test_case_id)
                self.add_test(system_provision, f'{test_tag}_{test_case_id}')
                test_case_id += 1

            for test_cases in group_of_test_cases:
                if self.args.arch is not None:
                    arch = self.args.arch
                else:
                    # We will get the arch from the first test case
                    arch = testing_farm_utils.get_arch_from_testcase(test_cases[0])
                self.set_tree_name(test_cases[0])
                self.test_suite_info = {
                    'arch': arch,
                    'whiteboard': test_suite_name,
                    'start_time': start_time,
                    'common_logs': utils.get_output_files(logs, self.common_logs)
                }
                self.arch = self.test_suite_info['arch']
                self.add_build()
                # Add the system provision to this group of test cases
                system_provision = \
                    testing_farm_utils.create_system_provision_test_case(test_suite,
                                                                         test_cases,
                                                                         test_case_id)
                self.add_test(system_provision, f'{test_tag}_{test_case_id}')
                test_case_id += 1
                for test_case in test_cases:
                    self.add_test(test_case, f'{test_tag}_{test_case_id}')
                    test_case_id += 1
                start_time = self.test_suite_info['start_time']
        self.processed = True
