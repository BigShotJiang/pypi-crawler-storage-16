"""Test module."""
from collections import defaultdict
from email.utils import parseaddr
from itertools import chain
import xml.etree.ElementTree as ET

from cki_lib import misc
from cki_lib.kcidb import validate
from cki_lib.logger import get_logger

from .. import utils

LOGGER = get_logger(__name__)


def get_kcidb_test_status(testing_farm_result):
    """
    Return the KCIDB status of a test given a test case result from testing farm.

    According to the official documentation, test case could return those values:
    * undefined
    * error
    * passed
    * failed
    * info
    * not_applicable
    * skipped
    * needs_inspection (new status found at
    https://gitlab.com/redhat/centos-stream/tests/kernel/kernel-qe-tools/-/issues/28)



    Valid KCIDB statuses for a tasks:

    * SKIP
    * DONE
    * PASS
    * MISS
    * ERROR
    * FAIL

    Source:
    Testing Farm:
    https://gitlab.com/testing-farm/gluetool-modules/-/blob/main/gluetool_modules_framework/libs/
    test_schedule.py?ref_type=heads#L148

    KCIDB:
    https://cki-project.org/docs/test-maintainers/status-meaning/
    """
    correlations = {
        'undefined': 'ERROR',
        'error': 'ERROR',
        'passed': 'PASS',
        'failed': 'FAIL',
        'info': 'PASS',
        'not_applicable': 'SKIP',
        'skipped': 'SKIP',
        'needs_inspection': 'ERROR',
        'pending': 'MISS',
    }
    return correlations[testing_farm_result]


def get_kcidb_result_status(check_result):
    """
    Return the status for a KCIDB result start from a check_result.

    We just run the cki method and return it

    Source:
    Testing Farm:
    https://gitlab.com/testing-farm/gluetool-modules/-/blob/main/gluetool_modules_framework/
    testing/test_schedule_tmt.py?ref_type=heads#L139

    KCIDB:
    https://cki-project.org/docs/test-maintainers/status-meaning/
    """
    return validate.sanitize_kcidb_status(check_result.upper())


def get_value_from(xml_element, xml_paths):
    """
    Get the value from a list of elements.

    We have a lot of properties in the XML, and we need to get the value from them.

    The value is in the attribute 'value' of the element.

    We have to return the first element that has the attribute 'value'.

    In normal and multihost tests, the location is different.

    If the element is not found, return None.
    """
    for xml_path in xml_paths:
        prop = xml_element.find(xml_path)
        try:
            return prop.get('value')
        except AttributeError:
            pass
    return None


def get_arch_from_testsuite(testsuite):
    """
    Get the arch from a test suite.

    This function should be removed, this function could return invalid values in multihost tests.
    """
    normal = ".testing-environment[@name='requested']/property[@name='arch']"
    return get_value_from(testsuite, [normal])


def get_arch_from_testcase(testcase):
    """
    Get the arch from a test suite.

    Currently, testing farm tests provides this info in a different way.

    For multihost tests, the arch is in the guest->testing-environment['provisioned'] tag,

    For not multihost tests, the arch is in the testing-environment['provisioned' and 'requested']
    tag.
    """
    # Normal execution provisioned
    normal_provisioned = ".testing-environment[@name='provisioned']/property[@name='arch']"
    # Normal execution not provisioned
    normal_not_provisioned = ".testing-environment[@name='requested']/property[@name='arch']"
    # Multihost execution provisioned
    multihost_provisioned = \
        ".guest/testing-environment[@name='provisioned']/property[@name='arch']"

    return get_value_from(
        testcase,
        [normal_provisioned, normal_not_provisioned, multihost_provisioned]
    )


def get_hostname_from_testcase(testcase):
    """
    Get the hostname from a test suite.

    Currently we only can get this information for non multihost tests.
    """
    normal = ".//property[@name='baseosci.connectable_host']"
    return get_value_from(testcase, [normal])


def get_results(test, results, first_id):
    """Generate results for a test case."""
    all_results = []
    for number, result in enumerate(chain(results.iter('check'), results.iter('subresult')),
                                    first_id):
        name = result.attrib['name']
        _result = result.attrib['result']
        # If we have timeout with fail status, we should overwrite the result to ERROR.
        if name == 'internal/timeout' and _result == 'fail':
            _result = 'error'

        all_results.append(utils.clean_dict({
            'id': f'{test["id"]}.{number}',
            'name': name,
            'comment': name,
            'status': get_kcidb_result_status(_result),
            'output_files': utils.get_output_files(result.find('logs')),
        }))

    return all_results


def create_virtual_result(test):
    """
    Generate a virtual result of every testcase.

    The virtual result will be the first always.

    There are some issues in TMT and in Testing Farm and we need to create it.

    * https://github.com/teemtee/tmt/issues/2826
    * https://issues.redhat.com/browse/TFT-2762
    """
    output_files = [output_file for output_file in test["output_files"]
                    if output_file['name'] == 'testout.log']
    return utils.clean_dict({
        'id': f'{test["id"]}.1',
        'name': test['path'],
        'comment': test['path'],
        'status': test['status'],
        'output_files': output_files
        })


def create_status_mismatch_result(test, test_id):
    """Generate a result to indicate overall status mismatch.

    Related TMT issue:

    * https://github.com/teemtee/tmt/issues/3552
    """
    # Add 1 log file to the result
    output_files = [output_file for output_file in test["output_files"]
                    if output_file['name'] == 'testout.log']
    return utils.clean_dict({
        'id': f'{test["id"]}.{test_id}',
        'name': 'status_mismatch',
        'comment': 'status_mismatch',
        'status': test['status'],
        'output_files': output_files
        })


def create_system_provision_test_case(test_suite, grouped_test_cases, test_id):
    """
    Add a fake provision "testing farm" task to every testsuite.

    Testing farm does not offer to much information about the provision itself.
    There is an issue TFT 2641 that will provide more information.

    Right now, we're going to suppose that information is here.

    We have three scenarios.

    * The installation failed and we don't have any test case, but we have
    (or will have) information about the request. In that case, the status should
    be error

    * The installation succeeded, but there was a problem setting up the environment.
    All tests cases have `result=pending`. In that case, the status should be error.

    * At least 1 test was executed, in that case the status is passed.

    Grouped test cases, represent the list of tests cases executed in the same host.
    """
    test_case = ET.fromstring('<testcase />')

    # Add basic information
    test_case.set('id', str(test_id))
    test_case.set('name', 'system_provision')

    # Add recipe logs
    test_case.append(test_suite.find('logs'))

    # Time -> Testing Farm does not provide information about the provisioning time
    test_case.set('time', '0')

    # Result
    # return error, unless some tests executed
    test_case.set('result', 'error')
    check_case_result = 'error'
    # assume if the test result is not pending the test executed
    if any(test.get('result') != 'pending' for test in grouped_test_cases):
        test_case.set('result', 'passed')
        check_case_result = 'pass'

    # Checks
    checks = ET.fromstring('<checks />')
    check = ET.fromstring('<check />')
    check.set('name', test_case.get('name'))
    check.set('result', check_case_result)
    check.append(test_suite.find('logs'))
    checks.append(check)
    test_case.append(checks)

    # Add extra information
    test_case.set('fake', 'True')  # This is a string not a boolean

    return test_case


def get_job_url(logs) -> str | None:
    """
    Get the job URL from the logs of a test suite.

    The job URL is the URL of the job in the CI/CD system.

    To get this information, we need to look for the log with the name 'workdir', and remove
    the last part of the path.

    Example:
      * Source -> https://${OSCI_URL}/testing-farm/1234/workdir/
      * Result -> https://${OSCI_URL}/testing-farm/1234
    """
    if logs is not None:
        for log in logs.iter('log'):
            if log.get("name", "UNDEFINED") == 'workdir':
                raw_url = log.get('href')
                if raw_url.endswith('/'):
                    return raw_url.rsplit('/', 2)[0]
                return raw_url.rsplit('/', 1)[0]
    return None


def remove_duplicated_logs(test):
    """Remove from root output files, logs that are already in a subtest."""
    for subtest in test['misc'].get('results', []):
        for log in subtest.get('output_files', []):
            # don't delete from the root if it is from the virtual subtest
            if log in test['output_files'] and log['name'] != 'testout.log':
                test['output_files'].remove(log)


def group_testcases_by_guest(testsuite):
    """
    Group test cases by guest.

    Currently, testing farm tests are not grouped by guest.

    This function will group the test cases by guest.

    In not multihost tests, we don't have guest information, and multihost we have.
    But all the tests are under the same testsuite.
    """
    # Use a dictionary to group tests by guest
    # {(guest_name, guest_role): [testcases]}
    guest_groups = defaultdict(list)

    # Iterate over all testcases in the testsuite
    for testcase in testsuite.iter('testcase'):

        guest = testcase.find('guest')
        if guest is not None:
            # Get the guest name and role from the testcase
            guest_name = guest.get('name', 'unnamed')
            guest_role = guest.get('role', 'unroled')

            # Add the testcase to the corresponding guest group
            guest_groups[(guest_name, guest_role)].append(testcase)
        else:
            # If no guest information is available, add the testcase to the default group
            guest_groups[(None, None)].append(testcase)

    return list(guest_groups.values())


def get_compose_from_xml(element):
    """
    Get the compose from a test case or testsuite.

    Currently, testing farm tests provides this info in a different way.

    For multihost tests, the compose is in the guest->testing-environment['provisioned'] tag,

    For not multihost tests, the compose is in the
    testing-environment['provisioned' and 'requested'] tag.
    """
    # Normal execution provisioned
    normal_provisioned = ".testing-environment[@name='provisioned']/property[@name='compose']"
    # Normal execution not provisioned
    normal_not_provisioned = ".testing-environment[@name='requested']/property[@name='compose']"
    # Multihost execution provisioned
    multihost_provisioned = \
        ".guest/testing-environment[@name='provisioned']/property[@name='compose']"

    return get_value_from(
        element,
        [normal_provisioned, normal_not_provisioned, multihost_provisioned]
    )


def get_test_status_from_results(test):
    """Get test status based on the results of the test."""
    status_priority = {status: -idx for idx, status in enumerate(validate.KCIDB_STATUS_CHOICES)}
    status_priority[None] = - 99
    max_results_status = None

    for result in misc.get_nested_key(test, 'misc/results', default=[]):
        status = result.get('status')
        if status_priority[status] > status_priority[max_results_status]:
            max_results_status = status

    return max_results_status


def get_test_case_maintainers(test_case):
    """
    Get the list of maintainers of a test case.

    In a test case, the maintainers are defined under a property.

    <properties>
      <property name="contact" value="User &lt;user@example.com&gt;"/>
    </properties>

    The property can be defined several times.
    """
    maintainers = []

    contacts_xpath = ".properties/property[@name='contact']"
    for contact in test_case.findall(contacts_xpath):
        # Get the value of the contact property
        contact_value = contact.get('value', '')
        user, email = parseaddr(contact_value)
        if user == '' and email != '':
            user = email.split('@', maxsplit=1)[0]  # Fallback to email username
            LOGGER.warning(
                "The contact does not provide a name in %s, getting it from the email: %s",
                test_case.get('name', 'unknown'), email
            )
        # If user or email is not empty, add to maintainers
        if user != '' and email != '':
            maintainers.append(utils.clean_dict({'name': user, 'email': email}))
        else:
            LOGGER.warning(
                "Invalid contact property \"%s\" in test case %s", contact_value,
                test_case.get('name', 'unknown')
            )

    return maintainers
