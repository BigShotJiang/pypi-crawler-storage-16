"""Setup."""
from setuptools import setup

setup()
