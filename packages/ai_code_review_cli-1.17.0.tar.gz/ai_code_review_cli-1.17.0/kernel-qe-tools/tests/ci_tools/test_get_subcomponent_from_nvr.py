"""Test get_subcomponent_from_nvr."""

import io
import unittest
from unittest import mock

from kernel_qe_tools.ci_tools import get_subcomponent_from_nvr


class TestGetJiraToken(unittest.TestCase):
    """Test get_jira_token function."""

    def test_returns_token_when_set(self):
        """Return JIRA token from environment."""
        with mock.patch.dict('os.environ', {'JIRA_TOKEN': 'my-secret-token'}):
            result = get_subcomponent_from_nvr.get_jira_token()
            self.assertEqual(result, 'my-secret-token')

    def test_returns_none_when_not_set(self):
        """Return None when JIRA_TOKEN is not set."""
        with mock.patch.dict('os.environ', {}, clear=True):
            result = get_subcomponent_from_nvr.get_jira_token()
            self.assertIsNone(result)


class TestExtractJiraIssues(unittest.TestCase):
    """Test extract_jira_issues function."""

    def test_extract_single_issue(self):
        """Extract a single JIRA issue from changelog."""
        changelog = "[RHEL-12345] Fix something"
        result = get_subcomponent_from_nvr.extract_jira_issues(changelog)
        self.assertEqual(result, ["RHEL-12345"])

    def test_extract_multiple_issues(self):
        """Extract multiple JIRA issues from changelog."""
        changelog = "[RHEL-12345 RHEL-67890] Fix multiple things"
        result = get_subcomponent_from_nvr.extract_jira_issues(changelog)
        self.assertCountEqual(result, ["RHEL-12345", "RHEL-67890"])

    def test_extract_deduplicates(self):
        """Ensure duplicate issues are removed."""
        changelog = "[RHEL-12345] First mention\n[RHEL-12345] Second mention"
        result = get_subcomponent_from_nvr.extract_jira_issues(changelog)
        self.assertEqual(result, ["RHEL-12345"])

    def test_extract_no_issues(self):
        """Return empty list when no issues found."""
        changelog = "Some changelog without JIRA issues"
        result = get_subcomponent_from_nvr.extract_jira_issues(changelog)
        self.assertEqual(result, [])

    def test_extract_mixed_content(self):
        """Extract issues from mixed content with bugzilla IDs."""
        changelog = "[RHEL-12345 1234567] Mixed JIRA and BZ\n[RHEL-99999] Another fix"
        result = get_subcomponent_from_nvr.extract_jira_issues(changelog)
        self.assertCountEqual(result, ["RHEL-12345", "RHEL-99999"])


class TestGetSubcomponentsFromIssues(unittest.TestCase):
    """Test get_subcomponents_from_issues function."""

    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.JIRA')
    def test_returns_subcomponents(self, mock_jira_class):
        """Extract subcomponents from JIRA issues."""
        # Mock JIRA client and issues
        mock_client = mock.MagicMock()
        mock_jira_class.return_value = mock_client

        # Create mock issues with components
        mock_issue1 = mock.MagicMock()
        mock_issue1.fields.components = [mock.MagicMock(name="Kernel / Networking")]
        mock_issue1.fields.components[0].name = "Kernel / Networking"

        mock_issue2 = mock.MagicMock()
        mock_issue2.fields.components = [mock.MagicMock(name="Kernel / File Systems CephFS")]
        mock_issue2.fields.components[0].name = "Kernel / File Systems CephFS"

        mock_client.search_issues.return_value = [mock_issue1, mock_issue2]

        result = get_subcomponent_from_nvr.get_subcomponents_from_issues(
            ["RHEL-12345", "RHEL-67890"], "fake-token"
        )

        self.assertCountEqual(result, ["Networking", "File Systems CephFS"])

    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.JIRA')
    def test_handles_issue_without_components(self, mock_jira_class):
        """Handle issues without components gracefully."""
        mock_client = mock.MagicMock()
        mock_jira_class.return_value = mock_client

        # Create mock issue without components
        mock_issue = mock.MagicMock()
        mock_issue.fields.components = []

        mock_client.search_issues.return_value = [mock_issue]

        result = get_subcomponent_from_nvr.get_subcomponents_from_issues(
            ["RHEL-12345"], "fake-token"
        )

        self.assertEqual(result, [])

    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.JIRA')
    def test_handles_component_without_subcomponent(self, mock_jira_class):
        """Handle components that don't have a subcomponent (no slash)."""
        mock_client = mock.MagicMock()
        mock_jira_class.return_value = mock_client

        mock_issue = mock.MagicMock()
        mock_issue.fields.components = [mock.MagicMock(name="Kernel")]
        mock_issue.fields.components[0].name = "Kernel"

        mock_client.search_issues.return_value = [mock_issue]

        result = get_subcomponent_from_nvr.get_subcomponents_from_issues(
            ["RHEL-12345"], "fake-token"
        )

        self.assertEqual(result, [])

    def test_empty_issues_list(self):
        """Return empty list for empty issues input."""
        result = get_subcomponent_from_nvr.get_subcomponents_from_issues([], "fake-token")
        self.assertEqual(result, [])

    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.JIRA')
    def test_handles_jira_connection_error(self, mock_jira_class):
        """Handle JIRA connection errors gracefully."""
        mock_jira_class.side_effect = Exception("Connection failed")

        result = get_subcomponent_from_nvr.get_subcomponents_from_issues(
            ["RHEL-12345"], "fake-token"
        )

        self.assertEqual(result, [])

    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.JIRA')
    def test_handles_jira_query_error(self, mock_jira_class):
        """Handle JIRA query errors gracefully."""
        mock_client = mock.MagicMock()
        mock_jira_class.return_value = mock_client
        mock_client.search_issues.side_effect = Exception("Query failed")

        result = get_subcomponent_from_nvr.get_subcomponents_from_issues(
            ["RHEL-12345"], "fake-token"
        )

        self.assertEqual(result, [])

    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.JIRA')
    def test_handles_issue_with_attribute_error(self, mock_jira_class):
        """Handle issues that raise AttributeError when accessing fields."""
        mock_client = mock.MagicMock()
        mock_jira_class.return_value = mock_client

        # Create a mock issue that raises AttributeError on fields access
        mock_issue = mock.MagicMock()
        mock_issue.fields.components[0].name = mock.PropertyMock(
            side_effect=AttributeError("no attribute")
        )

        mock_client.search_issues.return_value = [mock_issue]

        result = get_subcomponent_from_nvr.get_subcomponents_from_issues(
            ["RHEL-12345"], "fake-token"
        )

        self.assertEqual(result, [])


class TestGetChangelogEntries(unittest.TestCase):
    """Test get_changelog_entries function."""

    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.koji.read_config')
    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.koji.ClientSession')
    def test_returns_changelog_with_default_hub(self, mock_client_session, mock_read_config):
        """Get changelog entry using default koji configuration."""
        mock_read_config.return_value = {'server': 'https://default-koji-hub.example.com'}
        mock_session = mock.MagicMock()
        mock_client_session.return_value = mock_session

        mock_session.getBuild.return_value = {"build_id": 12345}
        mock_session.getChangelogEntries.return_value = [
            {"text": "[RHEL-11111] Fix something", "author": "test", "date": "2024-01-01"},
            {"text": "[RHEL-22222] Fix another thing", "author": "test", "date": "2024-01-02"},
        ]

        result = get_subcomponent_from_nvr.get_changelog_entries("kernel-5.14.0-570.el9")

        # Only returns the first entry's text
        self.assertEqual(result, "[RHEL-11111] Fix something")
        mock_read_config.assert_called_once_with('koji')
        mock_client_session.assert_called_once_with("https://default-koji-hub.example.com")
        mock_session.getBuild.assert_called_once_with("kernel-5.14.0-570.el9", strict=False)

    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.koji.ClientSession')
    def test_returns_changelog_with_custom_hub(self, mock_client_session):
        """Get changelog entry using custom koji hub URL."""
        mock_session = mock.MagicMock()
        mock_client_session.return_value = mock_session

        mock_session.getBuild.return_value = {"build_id": 12345}
        mock_session.getChangelogEntries.return_value = [
            {"text": "[RHEL-11111] Fix something", "author": "test", "date": "2024-01-01"},
        ]

        custom_hub = "https://custom-koji-hub.example.com/kojihub"
        result = get_subcomponent_from_nvr.get_changelog_entries(
            "kernel-5.14.0-570.el9", koji_hub=custom_hub
        )

        self.assertEqual(result, "[RHEL-11111] Fix something")
        mock_client_session.assert_called_once_with(custom_hub)
        mock_session.getBuild.assert_called_once_with("kernel-5.14.0-570.el9", strict=False)

    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.koji.ClientSession')
    def test_handles_build_not_found(self, mock_client_session):
        """Handle case when build is not found."""
        mock_session = mock.MagicMock()
        mock_client_session.return_value = mock_session
        mock_session.getBuild.return_value = None

        result = get_subcomponent_from_nvr.get_changelog_entries(
            "nonexistent-1.0.0-1.el9", "https://koji.example.com"
        )

        self.assertEqual(result, "")

    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.koji.ClientSession')
    def test_handles_no_changelog_entries(self, mock_client_session):
        """Handle case when no changelog entries are returned."""
        mock_session = mock.MagicMock()
        mock_client_session.return_value = mock_session
        mock_session.getBuild.return_value = {"build_id": 12345}
        mock_session.getChangelogEntries.return_value = []

        result = get_subcomponent_from_nvr.get_changelog_entries(
            "kernel-5.14.0-570.el9", "https://koji.example.com"
        )

        self.assertEqual(result, "")

    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.koji.ClientSession')
    def test_handles_non_dict_entry(self, mock_client_session):
        """Handle case when changelog entry is not a dict."""
        mock_session = mock.MagicMock()
        mock_client_session.return_value = mock_session
        mock_session.getBuild.return_value = {"build_id": 12345}
        # Some koji instances might return strings instead of dicts
        mock_session.getChangelogEntries.return_value = ["[RHEL-11111] Fix something"]

        result = get_subcomponent_from_nvr.get_changelog_entries(
            "kernel-5.14.0-570.el9", "https://koji.example.com"
        )

        self.assertEqual(result, "[RHEL-11111] Fix something")


class TestMain(unittest.TestCase):
    """Test main CLI function."""

    def test_missing_jira_token(self):
        """Exit with error when JIRA_TOKEN is not set."""
        with mock.patch.dict('os.environ', {}, clear=True):
            with mock.patch.object(
                get_subcomponent_from_nvr, 'get_jira_token', return_value=None
            ):
                result = get_subcomponent_from_nvr.main([
                    "kernel-5.14.0-570.el9", "--koji-hub", "https://koji.example.com"
                ])
                self.assertEqual(result, 1)

    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.get_changelog_entries')
    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.get_jira_token')
    def test_no_changelog_entries(self, mock_get_token, mock_get_changelog):
        """Exit with error when no changelog entries found."""
        mock_get_token.return_value = "fake-token"
        mock_get_changelog.return_value = ""

        result = get_subcomponent_from_nvr.main(["kernel-5.14.0-570.el9"])
        self.assertEqual(result, 1)

    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.get_subcomponents_from_issues')
    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.extract_jira_issues')
    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.get_changelog_entries')
    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.get_jira_token')
    @mock.patch('sys.stdout', new_callable=io.StringIO)
    def test_successful_run(
        self, mock_stdout, mock_get_token, mock_get_changelog,
        mock_extract, mock_get_subcomponents
    ):
        """Successfully get subcomponents from NVR."""
        mock_get_token.return_value = "fake-token"
        mock_get_changelog.return_value = "[RHEL-12345] Fix something"
        mock_extract.return_value = ["RHEL-12345"]
        mock_get_subcomponents.return_value = ["Networking"]

        result = get_subcomponent_from_nvr.main(["kernel-5.14.0-570.el9"])

        self.assertEqual(result, 0)
        self.assertIn("Networking", mock_stdout.getvalue())

    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.get_subcomponents_from_issues')
    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.extract_jira_issues')
    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.get_changelog_entries')
    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.get_jira_token')
    @mock.patch('sys.stdout', new_callable=io.StringIO)
    def test_json_output(
        self, mock_stdout, mock_get_token, mock_get_changelog,
        mock_extract, mock_get_subcomponents
    ):
        """Output results as JSON when --json flag is used."""
        mock_get_token.return_value = "fake-token"
        mock_get_changelog.return_value = "[RHEL-12345] Fix something"
        mock_extract.return_value = ["RHEL-12345"]
        # Return values in sorted order (as the real function does)
        mock_get_subcomponents.return_value = ["File Systems", "Networking"]

        result = get_subcomponent_from_nvr.main(["kernel-5.14.0-570.el9", "--json"])

        self.assertEqual(result, 0)
        output = mock_stdout.getvalue().strip()
        self.assertEqual(output, '["File Systems", "Networking"]')

    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.extract_jira_issues')
    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.get_changelog_entries')
    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.get_jira_token')
    @mock.patch('sys.stdout', new_callable=io.StringIO)
    def test_no_jira_issues_found(
        self, mock_stdout, mock_get_token, mock_get_changelog, mock_extract
    ):
        """Return empty list when no JIRA issues in changelog."""
        mock_get_token.return_value = "fake-token"
        mock_get_changelog.return_value = "Some changelog without JIRA"
        mock_extract.return_value = []

        result = get_subcomponent_from_nvr.main(["kernel-5.14.0-570.el9"])

        self.assertEqual(result, 0)
        self.assertIn("[]", mock_stdout.getvalue())

    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.get_subcomponents_from_issues')
    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.extract_jira_issues')
    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.get_changelog_entries')
    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.get_jira_token')
    @mock.patch('sys.stdout', new_callable=io.StringIO)
    def test_custom_koji_hub(
        self, mock_stdout, mock_get_token, mock_get_changelog,
        mock_extract, mock_get_subcomponents
    ):
        """Pass custom koji hub URL to get_changelog_entries."""
        mock_get_token.return_value = "fake-token"
        mock_get_changelog.return_value = "[RHEL-12345] Fix something"
        mock_extract.return_value = ["RHEL-12345"]
        mock_get_subcomponents.return_value = ["Networking"]

        custom_hub = "https://custom-koji.example.com/kojihub"
        result = get_subcomponent_from_nvr.main([
            "kernel-5.14.0-570.el9", "--koji-hub", custom_hub
        ])

        self.assertEqual(result, 0)
        mock_get_changelog.assert_called_once_with("kernel-5.14.0-570.el9", custom_hub)

    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.get_subcomponents_from_issues')
    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.extract_jira_issues')
    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.get_changelog_entries')
    @mock.patch('kernel_qe_tools.ci_tools.get_subcomponent_from_nvr.get_jira_token')
    @mock.patch('sys.stdout', new_callable=io.StringIO)
    def test_verbose_output(
        self, mock_stdout, mock_get_token, mock_get_changelog,
        mock_extract, mock_get_subcomponents
    ):
        """Test verbose output messages."""
        mock_get_token.return_value = "fake-token"
        mock_get_changelog.return_value = "[RHEL-12345] Fix something"
        mock_extract.return_value = ["RHEL-12345"]
        mock_get_subcomponents.return_value = ["Networking"]

        result = get_subcomponent_from_nvr.main(["kernel-5.14.0-570.el9", "-v"])

        self.assertEqual(result, 0)
        output = mock_stdout.getvalue()
        self.assertIn("Fetching changelog for kernel-5.14.0-570.el9", output)
        self.assertIn("Found 1 JIRA issues in changelog", output)
        self.assertIn("Querying JIRA for subcomponents", output)
