"""Test cases for cmd_change_tests_location module."""

import io
import tempfile
import unittest
from unittest import mock

from cki_lib import misc

from kernel_qe_tools.kcidb_tool import cli
from kernel_qe_tools.kcidb_tool.cmd_change_tests_location import LOGGER

from .. import utils as test_utils


class TestChangeTestsLocation(unittest.TestCase):
    """Test the ChangeTestsLocation sub command."""

    @mock.patch('sys.stderr', new_callable=io.StringIO)
    def test_missing_input_argument(self, stderr_mock):
        """Test command fails when input argument is missing."""
        expected_message = "error: the following arguments are required: -i/--input"

        args = [
            "change-tests-location",
            "--old", "https://old.server.com",
            "--new", "https://new.server.com"
        ]

        with self.assertRaises(SystemExit) as context:
            cli.main(args)

        self.assertEqual('2', str(context.exception))
        self.assertIn(expected_message, stderr_mock.getvalue())

    @mock.patch('sys.stderr', new_callable=io.StringIO)
    def test_missing_old_argument(self, stderr_mock):
        """Test command fails when old argument is missing."""
        expected_message = "error: the following arguments are required: --old"

        with (
            tempfile.NamedTemporaryFile() as input_file,
            self.assertRaises(SystemExit) as context
        ):
            args = [
                "change-tests-location",
                "--input", input_file.name,
                "--new", "https://new.server.com"
            ]

            cli.main(args)

        self.assertEqual('2', str(context.exception))
        self.assertIn(expected_message, stderr_mock.getvalue())

    @mock.patch('sys.stderr', new_callable=io.StringIO)
    def test_missing_new_argument(self, stderr_mock):
        """Test command fails when new argument is missing."""
        expected_message = "error: the following arguments are required: --new"

        with (
            tempfile.NamedTemporaryFile() as input_file,
            self.assertRaises(SystemExit) as context
        ):
            args = [
                "change-tests-location",
                "--input", input_file.name,
                "--old", "https://old.server.com"
            ]

            cli.main(args)

        self.assertEqual('2', str(context.exception))
        self.assertIn(expected_message, stderr_mock.getvalue())

    def test_nonexistent_input_file(self):
        """Test command fails when input file doesn't exist."""
        file = "/dir/some_file.json"
        expected_log = test_utils.get_log_message(
                LOGGER,
                f"Input file {file} does not exist",
                level='ERROR'
        )
        args = [
            "change-tests-location",
            "--input", file,
            "--old", "https://old.server.com",
            "--new", "https://new.server.com"
        ]

        with self.assertLogs(LOGGER, level='ERROR') as log_ctx:
            exit_code = cli.main(args)

        self.assertIn(expected_log, log_ctx.output)
        self.assertEqual(1, exit_code)

    def test_invalid_kcidb_file(self):
        """Test command fails when KCIDB file is invalid."""
        with (
            misc.tempfile_from_string(b'{"invalid": "data"}') as input_file,
            self.assertLogs(LOGGER, level='ERROR') as log_ctx
        ):

            expected_log = test_utils.get_log_message(
                LOGGER,
                f"Input file {input_file} is not a valid kcidb file",
                level='ERROR'
            )
            args = [
                "change-tests-location",
                "--input", input_file,
                "--old", "https://old.server.com",
                "--new", "https://new.server.com"
            ]

            exit_code = cli.main(args)

            self.assertIn(expected_log, log_ctx.output)
            self.assertEqual(1, exit_code)

    def test_valid_case(self):
        """Test valid case."""
        kcidb_data = b"""
        {
            "version": {
                "major": 4,
                "minor": 2
            },
            "tests": [{
                "id": "origin:1234_build.test1",
                "build_id": "origin:1234_build",
                "origin": "origin",
                "status": "PASS",
                "log_url": "https://old.server.com/logs/log_url.log",
                "output_files": [
                    {
                        "url": "https://old.server.com/logs/test1.log",
                        "name": "test1.log"
                    },
                    {
                        "url": "https://other.server.com/logs/test1_other.log",
                        "name": "test1_other.log"
                    },
                    {
                        "url": "https://old.server.com/logs/test1_debug.log",
                        "name": "test1_debug.log"
                    }
                ],
                "misc": {
                    "results": [
                        {
                            "id": "result1",
                            "status": "PASS",
                            "comment": "some comment",
                            "output_files": [
                                {
                                    "url": "https://old.server.com/results/result1.log",
                                    "name": "result1.log"
                                },
                                {
                                    "url": "https://other.server.com/results/result1_other.log",
                                    "name": "result1_other.log"
                                }
                            ]
                        }
                    ]
                }
            }]
        }
        """
        expected_log = test_utils.get_log_message(
            LOGGER,
            'Test origin:1234_build.test1 updated: test logs 3/4, results logs 1/2'
        )
        with (
            misc.tempfile_from_string(kcidb_data) as input_file,
            self.assertLogs(LOGGER, level='INFO') as log_ctx
        ):
            exit_code = cli.main([
                "change-tests-location",
                "--input", input_file,
                "--old", "https://old.server.com",
                "--new", "https://new.server.com"
            ])
        self.assertIn(expected_log, log_ctx.output)
        self.assertEqual(0, exit_code)
