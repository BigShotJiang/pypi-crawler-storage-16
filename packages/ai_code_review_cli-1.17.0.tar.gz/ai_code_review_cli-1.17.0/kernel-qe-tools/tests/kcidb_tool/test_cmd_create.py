"""Test cases for bkr2kcidb cli module."""

from importlib.resources import files
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

from kernel_qe_tools.kcidb_tool import cli
from kernel_qe_tools.kcidb_tool.cmd_create import LOGGER

from .. import utils as test_utils

ASSETS = files(__package__) / 'assets'


class TestCreateSubCommandCommon(unittest.TestCase):
    """Tests for the common part for create."""

    def test_invalid_nvr(self):
        """Check create subcommand with a bad nvr value."""
        nvr = 'kernel-bad'
        expected_log = test_utils.get_log_message(
            LOGGER,
            f'Invalid value for nvr: {nvr}',
            level='ERROR'
        )
        args = [
            "create",
            "--source", "beaker",
            "--input", f"{ASSETS}/beaker.xml",
            "--output", "/tmp/kcidb_all.json",
            "--checkout", "checkout_id",
            "--origin", "bkr2kcidb",
            "--test_plan", "true",
            "--add-output-files", "job_url=https://jenkins/job/my_job/1",
            "--contact", "username@redhat.com",
            "--nvr", f"{nvr}"
        ]
        with self.assertLogs(LOGGER, level='ERROR') as log_ctx:
            exit_code = cli.main(args)
        self.assertIn(expected_log, log_ctx.output)
        self.assertEqual(1, exit_code)

    def test_invalid_src_nvr(self):
        """Check create subcommand with a bad nvr value."""
        src_nvr = 'invalid_src_nvr'
        expected_log = test_utils.get_log_message(
            LOGGER,
            f'Invalid value for source nvr: {src_nvr}',
            level='ERROR'
        )
        args = [
            "create",
            "--source", "beaker",
            "--input", f"{ASSETS}/beaker.xml",
            "--output", "/tmp/kcidb_all.json",
            "--checkout", "checkout_id",
            "--origin", "bkr2kcidb",
            "--test_plan", "true",
            "--nvr", "kernel-5.14.0-300.el9",
            "--add-output-files", "job_url=https://jenkins/job/my_job/1",
            "--contact", "username@redhat.com",
            "--src-nvr", f"{src_nvr}"
        ]
        with self.assertLogs(LOGGER, level='ERROR') as log_ctx:
            exit_code = cli.main(args)
        self.assertIn(expected_log, log_ctx.output)
        self.assertEqual(1, exit_code)

    @mock.patch('sys.stderr', new_callable=io.StringIO)
    def test_without_contact(self, stderr_mock):
        """Check create subcommand without contact."""
        expected_message = 'error: the following arguments are required: --contact'
        args = [
            "create",
            "--source", "beaker",
            "--input", f"{ASSETS}/beaker.xml",
            "--output", "/tmp/kcidb_all.json",
            "--checkout", "checkout_id",
            "--origin", "bkr2kcidb",
            "--test_plan", "true",
            "--add-output-files", "job_url=https://jenkins/job/my_job/1",
            "--nvr", "kernel-5.14.0-300.el9"
        ]
        with self.assertRaises(SystemExit) as context:
            cli.main(args)
        self.assertEqual('2', str(context.exception))
        self.assertIn(expected_message, stderr_mock.getvalue())

    @mock.patch('sys.stderr', new_callable=io.StringIO)
    def test_without_checkout(self, stderr_mock):
        """Check create subcommand without checkout."""
        expected_message = 'error: the following arguments are required: -c/--checkout'
        args = [
            "create",
            "--source", "beaker",
            "--input", f"{ASSETS}/beaker.xml",
            "--output", "/tmp/kcidb_all.json",
            "--origin", "bkr2kcidb",
            "--test_plan", "true",
            "--add-output-files", "job_url=https://jenkins/job/my_job/1",
            "--nvr", "kernel-5.14.0-300.el9",
            "--contact", "username@redhat.com "
        ]
        with self.assertRaises(SystemExit) as context:
            cli.main(args)
        self.assertEqual('2', str(context.exception))
        self.assertIn(expected_message, stderr_mock.getvalue())

    @mock.patch('sys.stderr', new_callable=io.StringIO)
    def test_without_source(self, stderr_mock):
        """Check create subcommand without checkout."""
        expected_message = 'error: the following arguments are required: --source'
        args = [
            "create",
            "--input", f"{ASSETS}/beaker.xml",
            "--output", "/tmp/kcidb_all.json",
            "--checkout", "checkout_id",
            "--origin", "bkr2kcidb",
            "--test_plan", "true",
            "--add-output-files", "job_url=https://jenkins/job/my_job/1",
            "--nvr", "kernel-5.14.0-300.el9",
            "--contact", "username@redhat.com"
        ]
        with self.assertRaises(SystemExit) as context:
            cli.main(args)
        self.assertEqual('2', str(context.exception))
        self.assertIn(expected_message, stderr_mock.getvalue())

    @mock.patch('sys.stderr', new_callable=io.StringIO)
    def test_without_input(self, stderr_mock):
        """Check create subcommand without input."""
        expected_message = 'error: the following arguments are required: -i/--input'
        args = [
            "create",
            "--source", "beaker",
            "--output", "/tmp/kcidb_all.json",
            "--checkout", "checkout_id",
            "--origin", "bkr2kcidb",
            "--test_plan", "true",
            "--add-output-files", "job_url=https://jenkins/job/my_job/1",
            "--nvr", "kernel-5.14.0-300.el9",
            "--contact", "username@redhat.com "
        ]
        with self.assertRaises(SystemExit) as context:
            cli.main(args)
        self.assertEqual('2', str(context.exception))
        self.assertIn(expected_message, stderr_mock.getvalue())

    @mock.patch('sys.stderr', new_callable=io.StringIO)
    def test_with_an_undefined_source(self, stderr_mock):
        """Check create subcommand with an undefined source."""
        expected_message = (
            "error: argument --source: invalid choice: 'undefined' "
            "(choose from beaker, testing-farm)"
        )
        args = [
            "create",
            "--source", "undefined",
            "--input", f"{ASSETS}/beaker.xml",
            "--output", "/tmp/kcidb_all.json",
            "--checkout", "checkout_id",
            "--origin", "bkr2kcidb",
            "--test_plan", "true",
            "--add-output-files", "job_url=https://jenkins/job/my_job/1",
            "--nvr", "kernel-5.14.0-300.el9",
            "--contact", "username@redhat.com"
        ]
        with self.assertRaises(SystemExit) as context:
            cli.main(args)
        self.assertEqual('2', str(context.exception))
        self.assertIn(expected_message, stderr_mock.getvalue())

    def test_test_plan_warning(self):
        """Test when everything works."""
        expected_log = test_utils.get_log_message(
            LOGGER,
            'The --test_plan option is deprecated, '
            'please use the subcommand create-test-plan instead',
            level='WARNING'
        )
        with (
            tempfile.TemporaryDirectory() as tmp_dir,
            self.assertLogs(LOGGER, level='WARNING') as log_ctx
        ):
            kcidb_file = Path(tmp_dir, 'kcidb.json')
            args = [
                "create",
                "--source", "beaker",
                "--input", f"{ASSETS}/beaker.xml",
                "--output", f"{kcidb_file.resolve()}",
                "--checkout", "checkout_id",
                "--builds-origin", "b_build",
                "--checkout-origin", "c_origin",
                "--tests-origin", "t_origin",
                "--test_plan", "true",
                "--add-output-files", "extra_file=https://someserver/url",
                "--nvr", "kernel-5.14.0-300.el9",
                "--brew-task-id", "47919042",
                "--tests-provisioner-url", "https://jenkins/job/my_job/1",
                "--contact", "username@redhat.com"
            ]
            # Run code
            exit_code = cli.main(args)

            self.assertTrue(kcidb_file.is_file())

            # Check STDOUT
            self.assertIn(expected_log, log_ctx.output)

            self.assertEqual(0, exit_code)

    @mock.patch("kernel_qe_tools.kcidb_tool.cmd_create.Bkr2KCIDBParser")
    def test_when_the_parser_did_not_find_any_test(self, mock_parser):
        """Test when the parser does not find any test."""
        mock_parser.return_value.has_tests.return_value = False
        expected_log = test_utils.get_log_message(
            LOGGER,
            'The --test_plan option is deprecated, '
            'please use the subcommand create-test-plan instead',
            level='WARNING'
        )
        with (
            tempfile.TemporaryDirectory() as tmp_dir,
            self.assertLogs(LOGGER, level='WARNING') as log_ctx
        ):
            kcidb_file = Path(tmp_dir, 'kcidb.json')
            args = [
                "create",
                "--source", "beaker",
                "--input", f"{ASSETS}/beaker.xml",
                "--output", f"{kcidb_file.resolve()}",
                "--checkout", "checkout_id",
                "--builds-origin", "b_build",
                "--checkout-origin", "c_origin",
                "--tests-origin", "t_origin",
                "--test_plan", "true",
                "--add-output-files", "extra_file=https://someserver/url",
                "--nvr", "kernel-5.14.0-300.el9",
                "--brew-task-id", "47919042",
                "--tests-provisioner-url", "https://jenkins/job/my_job/1",
                "--contact", "username@redhat.com"
            ]
            # Run code
            exit_code = cli.main(args)

            # Check STDOUT
            self.assertIn(expected_log, log_ctx.output)
            self.assertEqual(1, exit_code)

    @mock.patch('sys.stderr', new_callable=io.StringIO)
    def test_invalid_report_rules(self, stderr_mock):
        """Check create subcommand with a invalid report_rules argument.."""
        expected_message = ('error: argument --report-rules: this_is_not_a_json_blob is not a '
                            'valid JSON, error:'
                            )
        args = [
            "create",
            "--source", "beaker",
            "--input", f"{ASSETS}/beaker.xml",
            "--output", "/tmp/kcidb_all.json",
            "--checkout", "checkout_id",
            "--origin", "bkr2kcidb",
            "--test_plan", "true",
            "--add-output-files", "job_url=https://jenkins/job/my_job/1",
            "--nvr", "kernel-5.14.0-300.el9",
            "--report-rules", "this_is_not_a_json_blob"
        ]
        with self.assertRaises(SystemExit) as context:
            cli.main(args)
        self.assertEqual('2', str(context.exception))
        self.assertIn(expected_message, stderr_mock.getvalue())


class TestCreateSubCommandWithBeaker(unittest.TestCase):
    """Test the specific Beaker part of the create subcommand."""

    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_create.Bkr2KCIDBParser')
    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_create.NVR')
    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_create.ParserArguments')
    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_create.pathlib.Path', mock.Mock())
    def test_parser_parameters(self, mock_parser_args, mock_nvr_class, mock_parser):
        """Test that the parser is called with the right parameters."""
        mock_nvr_instance = mock.MagicMock(name='NVRInstance')
        mock_src_instance = mock.MagicMock(name='SrcNVRInstance')

        mock_nvr_class.side_effect = [mock_nvr_instance, mock_src_instance]

        expected_nvr_call = [
            mock.call('kernel', '5.14.0', '300.el9'),
            mock.call('kernel', '5.14.0', '300.el9')
        ]

        args = [
            "create",
            "--source", "beaker",
            "--input", "/beaker.xml",
            "--output", "/tmp/kcidb_all.json",
            "--checkout", "checkout_id",
            "--builds-origin", "b_build",
            "--checkout-origin", "c_origin",
            "--tests-origin", "t_origin",
            "--add-output-files", "extra_file=https://someserver/url",
            "--nvr", "kernel-5.14.0-300.el9",
            "--brew-task-id", "47919042",
            "--tests-provisioner-url", "https://jenkins/job/my_job/1",
            "--contact", "username@redhat.com"
        ]

        self.assertEqual(0, cli.main(args))

        mock_nvr_class.assert_has_calls(expected_nvr_call, any_order=False)

        mock_parser_args.assert_called_once_with(
            brew_task_id='47919042',
            builds_origin='b_build',
            checkout='checkout_id',
            checkout_origin='c_origin',
            contacts=['username@redhat.com'],
            extra_output_files=[mock.ANY],  # ExternalOutputFile object
            nvr=mock_nvr_instance,
            src_nvr=mock_src_instance,
            test_plan=False,
            tests_origin='t_origin',
            tests_provisioner_url='https://jenkins/job/my_job/1',
            report_rules=None,
            submitter=None,
            arch=None,
            distro=None,
            public=False
        )

        mock_parser.assert_called_once()

    def test_when_everything_works(self):
        """Test when everything works."""
        # Prepare test
        with (
            tempfile.TemporaryDirectory() as tmp_dir,
            self.assertLogs(LOGGER, level='INFO') as log_ctx
        ):
            kcidb_file = Path(tmp_dir, 'kcidb.json')
            expected_log = test_utils.get_log_message(
                LOGGER,
                f'File {kcidb_file.resolve()} wrote !!'
            )
            args = [
                "create",
                "--source", "beaker",
                "--input", f"{ASSETS}/beaker.xml",
                "--output", f"{kcidb_file.resolve()}",
                "--checkout", "checkout_id",
                "--builds-origin", "b_build",
                "--checkout-origin", "c_origin",
                "--tests-origin", "t_origin",
                "--add-output-files", "extra_file=https://someserver/url",
                "--nvr", "kernel-5.14.0-300.el9",
                "--brew-task-id", "47919042",
                "--tests-provisioner-url", "https://jenkins/job/my_job/1",
                "--contact", "username@redhat.com"
            ]
            # Run code
            exit_code = cli.main(args)
            self.assertTrue(kcidb_file.is_file())

            # Check statistics
            report = json.loads(kcidb_file.read_text(encoding='utf-8'))
            self.assertEqual(1, len(report['checkouts']))
            self.assertEqual(1, len(report['builds']))
            self.assertEqual(31, len(report['tests']))

            # Check STDOUT
            self.assertIn(expected_log, log_ctx.output)

            self.assertEqual(0, exit_code)

    def test_when_everything_works_overwritting_arch_and_distro(self):
        """Test when everything works."""
        # Prepare test
        with (
            tempfile.TemporaryDirectory() as tmp_dir,
            self.assertLogs(LOGGER, level='INFO') as log_ctx
        ):
            kcidb_file = Path(tmp_dir, 'kcidb.json')
            expected_log = test_utils.get_log_message(
                LOGGER,
                f'File {kcidb_file.resolve()} wrote !!'
            )
            args = [
                "create",
                "--source", "beaker",
                "--input", f"{ASSETS}/beaker.xml",
                "--output", f"{kcidb_file.resolve()}",
                "--checkout", "checkout_id",
                "--builds-origin", "b_build",
                "--checkout-origin", "c_origin",
                "--tests-origin", "t_origin",
                "--add-output-files", "extra_file=https://someserver/url",
                "--nvr", "kernel-5.14.0-300.el9",
                "--brew-task-id", "47919042",
                "--tests-provisioner-url", "https://jenkins/job/my_job/1",
                "--contact", "username@redhat.com",
                "--arch", "my_arch",
                "--distro", "my_distro"
            ]
            # Run code
            exit_code = cli.main(args)
            self.assertTrue(kcidb_file.is_file())

            # Check statistics
            report = json.loads(kcidb_file.read_text(encoding='utf-8'))
            self.assertEqual(1, len(report['checkouts']))
            self.assertEqual(1, len(report['builds']))
            self.assertEqual(31, len(report['tests']))

            # Check STDOUT
            self.assertIn(expected_log, log_ctx.output)

            self.assertEqual(0, exit_code)


class TestCreateSubCommandWithTestingFarm(unittest.TestCase):
    """Test the specific Testing Farm part of the create subcommand."""

    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_create.TestingFarmParser')
    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_create.NVR')
    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_create.ParserArguments')
    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_create.pathlib.Path', mock.Mock())
    def test_parser_parameters(self, mock_parser_args, mock_nvr_class, mock_parser):
        """Test that the parser is called with the right parameters."""
        mock_nvr_instance = mock.MagicMock(name='NVRInstance')
        mock_src_instance = mock.MagicMock(name='SrcNVRInstance')

        mock_nvr_class.side_effect = [mock_nvr_instance, mock_src_instance]

        expected_nvr_call = [
            mock.call('kernel', '5.14.0', '300.el9'),
            mock.call('kernel', '5.14.0', '300.el9')
        ]

        args = [
            "create",
            "--source", "testing-farm",
            "--input", "testing-farm.xml",
            "--output", "/tmp/kcidb_all.json",
            "--checkout", "checkout_id",
            "--builds-origin", "b_build",
            "--checkout-origin", "c_origin",
            "--tests-origin", "t_origin",
            "--add-output-files", "extra_file=https://someserver/url",
            "--nvr", "kernel-5.14.0-300.el9",
            "--brew-task-id", "47919042",
            "--tests-provisioner-url", "https://jenkins/job/my_job/1",
            "--contact", "username@redhat.com"
        ]

        self.assertEqual(0, cli.main(args))

        mock_nvr_class.assert_has_calls(expected_nvr_call, any_order=False)

        mock_parser_args.assert_called_once_with(
            brew_task_id='47919042',
            builds_origin='b_build',
            checkout='checkout_id',
            checkout_origin='c_origin',
            contacts=['username@redhat.com'],
            extra_output_files=[mock.ANY],  # ExternalOutputFile object
            nvr=mock_nvr_instance,
            src_nvr=mock_src_instance,
            test_plan=False,
            tests_origin='t_origin',
            tests_provisioner_url='https://jenkins/job/my_job/1',
            report_rules=None,
            submitter=None,
            arch=None,
            distro=None,
            public=False
        )

        mock_parser.assert_called_once()

    def test_when_everything_works(self):
        """Test when everything works overwritting arch and distro."""
        # Prepare test
        with (
            tempfile.TemporaryDirectory() as tmp_dir,
            self.assertLogs(LOGGER, level='INFO') as log_ctx
        ):
            kcidb_file = Path(tmp_dir, 'kcidb_testing_farm.json')
            expected_log = test_utils.get_log_message(
                LOGGER,
                f'File {kcidb_file.resolve()} wrote !!'
            )
            args = [
                "create",
                "--source", "testing-farm",
                "--input", f"{ASSETS}/testing_farm.xml",
                "--output", f"{kcidb_file.resolve()}",
                "--checkout", "checkout_id",
                "--builds-origin", "b_build",
                "--checkout-origin", "c_origin",
                "--tests-origin", "t_origin",
                "--add-output-files", "extra_file=https://someserver/url",
                "--nvr", "kernel-5.14.0-300.el9",
                "--brew-task-id", "47919042",
                "--tests-provisioner-url", "https://jenkins/job/my_job/1",
                "--contact", "username@redhat.com"
            ]
            # Run code
            exit_code = cli.main(args)
            self.assertTrue(kcidb_file.is_file())

            # Check statistics
            report = json.loads(kcidb_file.read_text(encoding='utf-8'))
            self.assertEqual(1, len(report['checkouts']))
            self.assertEqual(1, len(report['builds']))
            self.assertEqual(16, len(report['tests']))
            self.assertEqual(6, test_utils.count_system_provision_tests(report))

            # Check STDOUT
            self.assertIn(expected_log, log_ctx.output)

            self.assertEqual(0, exit_code)

    def test_when_everything_works_overwritting_arch_and_distro(self):
        """Test when everything works overwritting arch and distro."""
        # Prepare test
        with (
            tempfile.TemporaryDirectory() as tmp_dir,
            self.assertLogs(LOGGER, level='INFO') as log_ctx
        ):
            kcidb_file = Path(tmp_dir, 'kcidb_testing_farm.json')
            expected_log = test_utils.get_log_message(
                LOGGER,
                f'File {kcidb_file.resolve()} wrote !!'
            )
            args = [
                "create",
                "--source", "testing-farm",
                "--input", f"{ASSETS}/testing_farm.xml",
                "--output", f"{kcidb_file.resolve()}",
                "--checkout", "checkout_id",
                "--builds-origin", "b_build",
                "--checkout-origin", "c_origin",
                "--tests-origin", "t_origin",
                "--add-output-files", "extra_file=https://someserver/url",
                "--nvr", "kernel-5.14.0-300.el9",
                "--brew-task-id", "47919042",
                "--tests-provisioner-url", "https://jenkins/job/my_job/1",
                "--contact", "username@redhat.com",
                "--arch", "my_arch",
                "--distro", "my_distro"
            ]
            # Run code
            exit_code = cli.main(args)
            self.assertTrue(kcidb_file.is_file())

            # Check statistics
            report = json.loads(kcidb_file.read_text(encoding='utf-8'))
            self.assertEqual(1, len(report['checkouts']))
            self.assertEqual(1, len(report['builds']))
            self.assertEqual(16, len(report['tests']))
            self.assertEqual(6, test_utils.count_system_provision_tests(report))

            # Check STDOUT
            self.assertIn(expected_log, log_ctx.output)

            self.assertEqual(0, exit_code)

    def test_when_the_parser_does_not_find_arch(self):
        """Test when the parser is not able to get any arch."""
        # Prepare test
        with (
            tempfile.TemporaryDirectory() as tmp_dir,
            self.assertLogs(LOGGER, level='ERROR') as log_ctx
        ):
            kcidb_file = Path(tmp_dir, 'kcidb_testing_farm.json')
            log_from_exception = test_utils.get_log_message(
                LOGGER,
                "Failed to parse: Can't get arch from testsuite /plans/security/security-internal",
                level='ERROR'
            )
            log_from_cli = test_utils.get_log_message(
                LOGGER,
                "Please provide the architecture using --arch, the parser could not find it",
                level='ERROR'
            )
            args = [
                "create",
                "--source", "testing-farm",
                "--input", f"{ASSETS}/testing_farm_provision_error.xml",
                "--output", f"{kcidb_file.resolve()}",
                "--checkout", "checkout_id",
                "--builds-origin", "b_build",
                "--checkout-origin", "c_origin",
                "--tests-origin", "t_origin",
                "--add-output-files",  "extra_file=https://someserver/url",
                "--nvr", "kernel-5.14.0-300.el9",
                "--brew-task-id", "47919042",
                "--tests-provisioner-url", "https://jenkins/job/my_job/1",
                "--contact", "username@redhat.com",
                "--distro", "my_distro"
            ]
            # Run code
            exit_code = cli.main(args)
            self.assertEqual(1, exit_code)
            self.assertIn(log_from_cli, log_ctx.output)
            self.assertIn(log_from_exception, log_ctx.output)
            self.assertFalse(kcidb_file.is_file())

    def test_when_the_parser_does_not_find_tree_name(self):
        """Test when the parser is not able to get any tree_name."""
        # Prepare test
        with (
            tempfile.TemporaryDirectory() as tmp_dir,
            self.assertLogs(LOGGER, level='ERROR') as log_ctx
        ):
            kcidb_file = Path(tmp_dir, 'kcidb_testing_farm.json')
            log_from_exception = test_utils.get_log_message(
                LOGGER,
                "Failed to parse: Can't get tree name from testsuite "
                "/plans/security/security-internal",
                level='ERROR'
            )
            log_from_cli = test_utils.get_log_message(
                LOGGER,
                "Please provide the distro using --distro, the parser could not find it",
                level='ERROR'
            )
            args = [
                "create",
                "--source", "testing-farm",
                "--input", f"{ASSETS}/testing_farm_provision_error.xml",
                "--output", f"{kcidb_file.resolve()}",
                "--checkout", "checkout_id",
                "--builds-origin", "b_build",
                "--checkout-origin", "c_origin",
                "--tests-origin", "t_origin",
                "--add-output-files",  "extra_file=https://someserver/url",
                "--nvr", "kernel-5.14.0-300.el9",
                "--brew-task-id", "47919042",
                "--tests-provisioner-url", "https://jenkins/job/my_job/1",
                "--contact", "username@redhat.com",
                "--arch", "x86_64"
            ]
            # Run code
            exit_code = cli.main(args)
            self.assertEqual(1, exit_code)
            self.assertIn(log_from_cli, log_ctx.output)
            self.assertIn(log_from_exception, log_ctx.output)

            self.assertFalse(kcidb_file.is_file())

    @mock.patch('sys.stderr', new_callable=io.StringIO)
    def test_when_the_parser_does_not_find_tests(self, stderr_mock):
        """
        Test when the parser does not find tests.

        It will add the system provision task to the kcidb file.

        It will not raise an error and will show a warning.
        """
        # Prepare test
        with tempfile.TemporaryDirectory() as tmp_dir:
            kcidb_file = Path(tmp_dir, 'kcidb_testing_farm.json')
            warning_message = (
                "Test suite /plans/security/security-internal does not contain test cases"
            )
            args = [
                "create",
                "--source", "testing-farm",
                "--input", f"{ASSETS}/testing_farm_provision_error.xml",
                "--output", f"{kcidb_file.resolve()}",
                "--checkout", "checkout_id",
                "--builds-origin", "b_build",
                "--checkout-origin", "c_origin",
                "--tests-origin", "t_origin",
                "--add-output-files",  "extra_file=https://someserver/url",
                "--nvr", "kernel-5.14.0-300.el9",
                "--brew-task-id", "47919042",
                "--tests-provisioner-url", "https://jenkins/job/my_job/1",
                "--contact", "username@redhat.com",
                "--arch", "x86_64",
                "--distro", "my_distro"
            ]
            # Run code
            exit_code = cli.main(args)
            self.assertIn(warning_message, stderr_mock.getvalue())

            self.assertTrue(kcidb_file.is_file())
            self.assertEqual(0, exit_code)
