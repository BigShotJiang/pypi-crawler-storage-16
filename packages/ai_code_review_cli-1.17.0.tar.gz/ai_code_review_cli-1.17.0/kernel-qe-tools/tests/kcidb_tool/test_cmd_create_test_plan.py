"""Test cases for bkr2kcidb cli module."""

import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

from cki_lib import kcidb

from kernel_qe_tools.kcidb_tool import cli
from kernel_qe_tools.kcidb_tool.cmd_create_test_plan import LOGGER

from .. import utils as test_utils


class TestCreateTestPlan(unittest.TestCase):
    """Test to create test plan."""

    def test_when_the_nvr_is_invalid(self):
        """Check when the NVR is invalid."""
        invalid_nvr = 'invalid_nvr'
        expected_logs = test_utils.get_log_message(
            LOGGER,
            f'Invalid value for nvr: {invalid_nvr}',
            level='ERROR'
        )
        with self.assertLogs(LOGGER, level='ERROR') as log_ctx:
            exit_code = cli.main([
                'create-test-plan',
                '--arch', 'x86_64',
                '--nvr', invalid_nvr,
                '--checkout', 'checkout_id',
                '--src-nvr', 'kernel-5.14.0-300.el9',
                '--builds-origin', 'build_origin',
                '--checkout-origin', 'checkout_origin',
                '--distro', 'my_distro'
            ])
        self.assertIn(expected_logs, log_ctx.output)

        self.assertEqual(1, exit_code)

    def test_when_the_src_nvr_is_invalid(self):
        """Check when the SRC NVR is invalid."""
        invalid_src_nvr = 'invalid_src_nvr'
        expected_logs = test_utils.get_log_message(
            LOGGER,
            f'Invalid value for source nvr: {invalid_src_nvr}',
            level='ERROR'
        )
        with self.assertLogs(LOGGER, level='ERROR') as log_ctx:
            exit_code = cli.main([
                'create-test-plan',
                '--arch', 'x86_64',
                '--nvr', 'kernel_rt-5.14.0-300.el9',
                '--checkout', 'checkout_id',
                '--src-nvr', invalid_src_nvr,
                '--builds-origin', 'build_origin',
                '--checkout-origin', 'checkout_origin',
                '--distro', 'my_distro'
            ])
        self.assertIn(expected_logs, log_ctx.output)

        self.assertEqual(1, exit_code)

    def test_valid_execution(self):
        """Check valid execution."""
        with (
            self.assertLogs(LOGGER, level='INFO') as log_ctx,
            tempfile.TemporaryDirectory() as tmp_dir
        ):
            kcidb_file = Path(tmp_dir, 'kcidb_file.json')
            expected_log = test_utils.get_log_message(
                LOGGER,
                f'File {kcidb_file.resolve()} wrote !!'
            )
            args = [
                'create-test-plan',
                '--arch', 'x86_64',
                '--nvr', 'kernel_rt-5.14.0-300.el9',
                '--checkout', 'checkout_id',
                '--output', f'{kcidb_file.resolve()}',
                '--src-nvr', 'kernel-5.14.0-300.el9',
                '--builds-origin', 'build_origin',
                '--checkout-origin', 'checkout_origin',
                '--distro', 'my_distro'
            ]
            # Run code
            exit_code = cli.main(args)
            self.assertTrue(kcidb_file.is_file())

            # Check statistics
            report = json.loads(kcidb_file.read_text(encoding='utf-8'))
            self.assertEqual(1, len(report['checkouts']))
            self.assertEqual(1, len(report['builds']))
            self.assertTrue('tests' not in report)

            # Check STDOUT
            self.assertIn(expected_log, log_ctx.output)
            self.assertEqual(0, exit_code)

    def test_valid_execution_with_an_existing_output_file(self):
        """Check valid execution with an existing output file."""
        checkout_info = {
            'id': 'checkout_origin:checkout_id',
            'origin': 'checkout_origin',
            'misc': {'retrigger': False},
        }
        build_info = {
            'id': 'build_origin:checkout_id_x86_64_kernel_rt',
            'origin': 'build_origin',
            'checkout_id': checkout_info['id'],
            'misc': {'test_plan_missing': False},
        }
        with (
            self.assertLogs(LOGGER, level='INFO') as log_ctx,
            tempfile.TemporaryDirectory() as tmp_dir
        ):
            kcidb_file = Path(tmp_dir, 'kcidb_file.json')

            output_file = kcidb.file.KCIDBFile(kcidb_file)
            output_file.set_checkout(checkout_info['id'], checkout_info)
            output_file.set_build(build_info['id'], build_info)
            output_file.save()

            expected_info_log = test_utils.get_log_message(
                LOGGER,
                f'File {kcidb_file.resolve()} wrote !!'
            )
            expected_warning_log = test_utils.get_log_message(
                LOGGER,
                f'File {kcidb_file} already exists and will be merged !!',
                level='WARNING'
            )
            args = [
                'create-test-plan',
                '--arch', 'x86_64',
                '--nvr', 'kernel_rt-5.14.0-300.el9',
                '--checkout', 'checkout_id',
                '--output', f'{kcidb_file.resolve()}',
                '--src-nvr', 'kernel-5.14.0-300.el9',
                '--builds-origin', 'build_origin',
                '--checkout-origin', 'checkout_origin',
                '--distro', 'my_distro'
            ]
            # Run code
            exit_code = cli.main(args)
            self.assertTrue(kcidb_file.is_file())

            # Check statistics
            report = json.loads(kcidb_file.read_text(encoding='utf-8'))
            self.assertEqual(1, len(report['checkouts']))
            self.assertEqual(1, len(report['builds']))
            self.assertTrue('tests' not in report)

            # Check Logging
            self.assertIn(expected_info_log, log_ctx.output)
            self.assertIn(expected_warning_log, log_ctx.output)
            self.assertEqual(0, exit_code)

            # Check checkout
            self.assertFalse(report['checkouts'][0]['misc']['retrigger'])

            # Check build
            self.assertTrue(report['builds'][0]['misc']['test_plan_missing'])

    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_create_test_plan.NVR')
    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_create_test_plan.TestPlanParser', mock.Mock())
    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_create_test_plan.TestPlanParserArguments')
    def test_parser_parameters(self, mock_parser_args, mock_nvr_class):
        """Check parser parameters."""
        mock_nvr_instance = mock.MagicMock(name='NVRInstance')
        mock_src_instance = mock.MagicMock(name='SrcNVRInstance')

        mock_nvr_class.side_effect = [mock_nvr_instance, mock_src_instance]

        expected_nvr_call = [
            mock.call('kernel_rt', '5.14.0', '300.el9'),
            mock.call('kernel', '5.14.0', '300.el9')
        ]

        args = [
            'create-test-plan',
            '--arch', 'x86_64',
            '--nvr', 'kernel_rt-5.14.0-300.el9',
            '--checkout', 'checkout_id',
            '--output', '/tmp/kcidb_file.json',
            '--src-nvr', 'kernel-5.14.0-300.el9',
            '--builds-origin', 'build_origin',
            '--checkout-origin', 'checkout_origin',
            '--distro', 'my_distro',
            '--public',
            '--tests-provisioner-url', 'http://my_provisioner_url'
        ]

        self.assertEqual(0, cli.main(args))

        mock_nvr_class.assert_has_calls(expected_nvr_call, any_order=False)

        mock_parser_args.assert_called_once_with(
            arch='x86_64',
            brew_task_id=None,
            builds_origin='build_origin',
            checkout='checkout_id',
            checkout_origin='checkout_origin',
            nvr=mock_nvr_instance,
            src_nvr=mock_src_instance,
            distro='my_distro',
            public=True,
            tests_provisioner_url='http://my_provisioner_url',
        )
