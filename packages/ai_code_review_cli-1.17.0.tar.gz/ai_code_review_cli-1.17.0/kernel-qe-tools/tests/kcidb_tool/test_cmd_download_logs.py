"""Test cases for cmd_download_logs module."""

import io
import pathlib
import tempfile
import unittest
from unittest import mock
import xml.etree.ElementTree as ET

from cki_lib import misc
import requests

from kernel_qe_tools.kcidb_tool import cli
from kernel_qe_tools.kcidb_tool import cmd_download_logs
from kernel_qe_tools.kcidb_tool.dataclasses import TestToDownload

from .. import utils as test_utils


class TestGetTestsToDownload(unittest.TestCase):
    """Test functions getting to download."""

    def setUp(self):
        """Set up test fixtures."""
        self.beaker_xml_with_logs = ET.fromstring("""
        <root>
             <recipe id="1">
             <log href="https://server.example.com/recipes/1/logs/console.log"
                  name="console.log"/>
             <log href="https://server.example.com/recipes/1/logs/systemd_journal.log"
                  name="systemd_journal.log"/>
             <task>
                 <log href="https://server.example.com/recipes/1/tasks/2/logs/taskout.log"
                      name="taskout.log"/>
                 <result>
                     <logs>
                         <log name="dmesg.log"
                     href="https://server.example.com/recipes/1/tasks/2/results/3/logs/dmesg.log"/>
                         <log name="avc.log"
                     href="https://server.example.com/recipes/1/tasks/2/results/3/logs/avc.log"/>
                    </logs>
                </result>
            </task>
            </recipe>
        </root>
        """)

        self.beaker_xml_no_logs = ET.fromstring("""
        <root>
            <task>
                <result>
                    <logs>
                    </logs>
                </result>
            </task>
        </root>
        """)

        self.testing_farm_xml_with_logs = ET.fromstring("""
        <root>
            <testsuite>
                <logs>
                    <log href="https://example.com/id/data" name="data"/>
                    <log href="https://example.com/id/data/log1.txt" name="log1.txt"/>
                </logs>
                <testcase>
                    <logs>
                        <log href="https://example.com/id/testcase" name="log_dir"/>
                        <log href="https://example.com/id/testcase/log2.txt" name="log2.txt"/>
                        <log href="https://example.com/id/testcase/log3.txt" name="log3.txt"/>
                        <log href="https://example.com/id/testcase/log4.txt" name="log4.txt"/>
                    </logs>
                </testcase>
            </testsuite>
        </root>
        """)

    def test_is_valid_log_file(self):
        """Test URL validation for external files."""
        cases = (
            ("File", "http://example.com/file.txt", True),
            ("File with params", "http://example.com/file.txt?param=value", True),
            ("Folder", "https://example.com/folder", False),
            ("Folder", "https://example.com/folder/", False),
        )

        for description, url, expected in cases:
            with self.subTest(description=description, url=url):
                self.assertEqual(expected, cmd_download_logs.is_valid_log_file(url))

    def test_get_test_to_download(self):
        """Test helper function."""
        test = cmd_download_logs.get_test_to_download(
            "https://example.com/test_logs/log.txt",
            pathlib.Path("/tmp")
        )

        self.assertIsInstance(test, TestToDownload)
        self.assertEqual(test.origin, "https://example.com/test_logs/log.txt")
        self.assertEqual(test.destination, pathlib.Path("/tmp/test_logs/log.txt"))

    def test_get_beaker_logs(self):
        """Test extracting logs from Beaker XML."""
        output_dir = pathlib.Path("/tmp/test_logs")

        expected_logs = [
            TestToDownload(
                origin="https://server.example.com/recipes/1/logs/console.log",
                destination=pathlib.Path(
                    "/tmp/test_logs/recipes/1/logs/console.log"
                )
            ),
            TestToDownload(
                origin="https://server.example.com/recipes/1/logs/systemd_journal.log",
                destination=pathlib.Path(
                    "/tmp/test_logs/recipes/1/logs/systemd_journal.log"
                )
            ),
            TestToDownload(
                origin="https://server.example.com/recipes/1/tasks/2/logs/taskout.log",
                destination=pathlib.Path(
                    "/tmp/test_logs/recipes/1/tasks/2/logs/taskout.log"
                )
            ),
            TestToDownload(
                origin=(
                    "https://server.example.com/recipes/1/tasks/2/results/"
                    "3/logs/dmesg.log"
                ),
                destination=pathlib.Path(
                    "/tmp/test_logs/recipes/1/tasks/2/results/3/logs/dmesg.log"
                )
            ),
            TestToDownload(
                origin=(
                    "https://server.example.com/recipes/1/tasks/2/results/"
                    "3/logs/avc.log"
                ),
                destination=pathlib.Path(
                    "/tmp/test_logs/recipes/1/tasks/2/results/3/logs/avc.log"
                )
            )
        ]

        result = cmd_download_logs.get_beaker_logs(self.beaker_xml_with_logs, output_dir)

        self.assertEqual(len(result), 5)
        for expected_log in expected_logs:
            self.assertIn(expected_log, result)

    def test_get_testing_farm_logs(self):
        """Test extracting logs from Testing Farm XML."""
        output_dir = pathlib.Path("/tmp/test_logs")

        expected_logs = [
            TestToDownload(
                origin="https://example.com/id/data/log1.txt",
                destination=pathlib.Path(
                    "/tmp/test_logs/id/data/log1.txt"
                )
            ),
            TestToDownload(
                origin="https://example.com/id/testcase/log2.txt",
                destination=pathlib.Path(
                    "/tmp/test_logs/id/testcase/log2.txt"
                )
            ),
            TestToDownload(
                origin="https://example.com/id/testcase/log3.txt",
                destination=pathlib.Path(
                    "/tmp/test_logs/id/testcase/log3.txt"
                )
            ),
            TestToDownload(
                origin=(
                    "https://example.com/id/testcase/log4.txt"
                ),
                destination=pathlib.Path(
                    "/tmp/test_logs/id/testcase/log4.txt"
                )
            )
        ]

        result = cmd_download_logs.get_testing_farm_logs(self.testing_farm_xml_with_logs,
                                                         output_dir)

        self.assertEqual(len(result), 4)
        for expected_log in expected_logs:
            self.assertIn(expected_log, result)


class TestDownloadLogs(unittest.TestCase):
    """Test download_logs function."""

    def setUp(self):
        """Set up test fixtures."""
        self.test_downloads = [
            TestToDownload(
                origin="https://example.com/log1.txt",
                destination=pathlib.Path("/tmp/test_logs/log1.txt")
            ),
            TestToDownload(
                origin="https://example.com/log2.txt",
                destination=pathlib.Path("/tmp/test_logs/subdir/log2.txt")
            )
        ]

    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_download_logs.get_session')
    @mock.patch('builtins.open', new_callable=mock.mock_open)
    @mock.patch('pathlib.Path.mkdir')
    @mock.patch('pathlib.Path.exists')
    def test_download_logs_success(
        self, mock_exists, mock_mkdir, mock_open_file, mock_get_session
    ):
        """Test successful download of logs."""
        # Mock setup
        mock_session = mock.Mock()
        mock_get_session.return_value = mock_session
        mock_response = mock.Mock()
        mock_response.iter_content.return_value = [
            b'log content chunk 1', b'log content chunk 2'
        ]
        mock_session.get.return_value = mock_response
        mock_exists.return_value = False  # Directory doesn't exist

        # Execute
        cmd_download_logs.download_logs(self.test_downloads, max_retries=3, timeout=30)

        # Verify session creation
        mock_get_session.assert_called_once_with(
            'kcidb_tool.download_logs',
            raise_for_status=True,
            retry_args={
                'total': 3,
                'status_forcelist': [404, 413, 429, 500, 502, 503, 504]
            },
            timeout=30
        )

        # Verify downloads
        self.assertEqual(mock_session.get.call_count, 2)
        mock_session.get.assert_any_call("https://example.com/log1.txt", stream=True)
        mock_session.get.assert_any_call("https://example.com/log2.txt", stream=True)

        # Verify directory creation
        self.assertEqual(mock_mkdir.call_count, 2)

        # Verify file writing
        self.assertEqual(mock_open_file.call_count, 2)

    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_download_logs.get_session')
    def test_download_logs_request_exception(self, mock_get_session):
        """Test download_logs with request exception."""
        mock_session = mock.Mock()
        mock_get_session.return_value = mock_session
        mock_session.get.side_effect = requests.exceptions.RequestException("Connection error")

        with self.assertRaises(requests.exceptions.RequestException):
            cmd_download_logs.download_logs(self.test_downloads, max_retries=1, timeout=10)

    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_download_logs.get_session')
    @mock.patch('builtins.open', new_callable=mock.mock_open)
    @mock.patch('pathlib.Path.mkdir')
    @mock.patch('pathlib.Path.exists')
    def test_download_logs_directory_exists(
        self, mock_exists, mock_mkdir, mock_open_file, mock_get_session
    ):
        """Test download when destination directory already exists."""
        # Mock setup - directory exists
        mock_session = mock.Mock()
        mock_get_session.return_value = mock_session
        mock_response = mock.Mock()
        mock_response.iter_content.return_value = [b'log content']
        mock_session.get.return_value = mock_response
        mock_exists.return_value = True  # Directory exists

        # Execute
        cmd_download_logs.download_logs(self.test_downloads, max_retries=2, timeout=15)

        # Verify directory creation is not called when directory exists
        mock_mkdir.assert_not_called()

    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_download_logs.get_session')
    def test_download_logs_progress_messages(self, mock_get_session):
        """Test that progress messages are printed during download."""
        # Mock setup
        mock_session = mock.Mock()
        mock_get_session.return_value = mock_session
        mock_response = mock.Mock()
        mock_response.iter_content.return_value = [b'content']
        mock_session.get.return_value = mock_response

        expected_logs = [
            test_utils.get_log_message(
                cmd_download_logs.LOGGER,
                "Starting download of 2 log files..."
            ),
            test_utils.get_log_message(
                cmd_download_logs.LOGGER,
                "Downloading 1/2: https://example.com/log1.txt"
            ),
            test_utils.get_log_message(
                cmd_download_logs.LOGGER,
                "Downloading 2/2: https://example.com/log2.txt"
            )
        ]

        with (
            mock.patch('builtins.open', mock.mock_open()),
            mock.patch('pathlib.Path.mkdir'),
            mock.patch('pathlib.Path.exists', return_value=True),
            self.assertLogs(cmd_download_logs.LOGGER, level='INFO') as log_ctx
        ):
            cmd_download_logs.download_logs(self.test_downloads, max_retries=1, timeout=5)

        for expected_log in expected_logs:
            self.assertIn(expected_log, log_ctx.output)

    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_download_logs.get_session')
    @mock.patch('pathlib.Path.write_text')
    @mock.patch('pathlib.Path.mkdir')
    @mock.patch('pathlib.Path.exists')
    def test_download_logs_create_if_not_found_404(
        self, mock_exists, mock_mkdir, mock_write_text, mock_get_session
    ):
        """Test create_if_not_found=True creates placeholder file for 404 errors."""
        # Mock setup
        mock_session = mock.Mock()
        mock_get_session.return_value = mock_session

        # Create a mock 404 HTTPError
        mock_response = mock.Mock()
        mock_response.status_code = 404
        http_error = requests.exceptions.HTTPError("404 Not Found")
        http_error.response = mock_response
        mock_session.get.side_effect = http_error
        mock_exists.return_value = False

        # Execute with create_if_not_found=True
        with self.assertLogs(cmd_download_logs.LOGGER, level='WARNING') as log_ctx:
            cmd_download_logs.download_logs(
                self.test_downloads,
                max_retries=1,
                timeout=10,
                create_if_not_found=True
            )

        # Verify directory creation
        self.assertEqual(mock_mkdir.call_count, 2)

        # Verify placeholder files were created
        self.assertEqual(mock_write_text.call_count, 2)

        # Verify the content written to files contains error message
        write_calls = mock_write_text.call_args_list
        self.assertEqual(len(write_calls), 2)

        for call in write_calls:
            error_message = call[0][0]  # First positional argument
            encoding = call[1]['encoding']  # Keyword argument
            self.assertEqual(encoding, 'utf-8')
            self.assertIn("ERROR: Original log file not found", error_message)
            self.assertIn("HTTP Status: 404", error_message)
            expected_message = \
                "This file was created because the original log file was not accessible"
            self.assertIn(expected_message, error_message)

        # Verify warning messages were printed
        expected_warning_1 = test_utils.get_log_message(
            cmd_download_logs.LOGGER,
            "Created placeholder file for missing origin: https://example.com/log1.txt",
            level='WARNING')
        expected_warning_2 = test_utils.get_log_message(
            cmd_download_logs.LOGGER,
            "Created placeholder file for missing origin: https://example.com/log2.txt",
            level='WARNING')
        self.assertIn(expected_warning_1, log_ctx.output)
        self.assertIn(expected_warning_2, log_ctx.output)

    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_download_logs.get_session')
    def test_download_logs_create_if_not_found_true_403_error(self, mock_get_session):
        """Test create_if_not_found=True still re-raises 403 errors (not 404)."""
        # Mock setup
        mock_session = mock.Mock()
        mock_get_session.return_value = mock_session

        # Create a mock 403 HTTPError (forbidden, not file not found)
        mock_response = mock.Mock()
        mock_response.status_code = 403
        http_error = requests.exceptions.HTTPError("403 Forbidden")
        http_error.response = mock_response
        mock_session.get.side_effect = http_error

        # Execute with create_if_not_found=True - should still re-raise 403 errors
        with self.assertRaises(requests.exceptions.HTTPError):
            cmd_download_logs.download_logs(
                [self.test_downloads[0]],
                max_retries=1,
                timeout=10,
                create_if_not_found=True
            )

    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_download_logs.get_session')
    def test_download_logs_create_if_not_found_false_404(self, mock_get_session):
        """Test create_if_not_found=False (default) re-raises 404 errors."""
        # Mock setup
        mock_session = mock.Mock()
        mock_get_session.return_value = mock_session

        # Create a mock 404 HTTPError
        mock_response = mock.Mock()
        mock_response.status_code = 404
        http_error = requests.exceptions.HTTPError("404 Not Found")
        http_error.response = mock_response
        mock_session.get.side_effect = http_error

        # Execute with create_if_not_found=False (default)
        with self.assertRaises(requests.exceptions.HTTPError):
            cmd_download_logs.download_logs(
                [self.test_downloads[0]],
                max_retries=1,
                timeout=10,
                create_if_not_found=False
            )

    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_download_logs.get_session')
    def test_download_logs_create_if_not_found_true_other_errors(self, mock_get_session):
        """Test create_if_not_found=True still re-raises non-404 errors."""
        # Mock setup
        mock_session = mock.Mock()
        mock_get_session.return_value = mock_session

        # Create a mock 500 HTTPError (server error, not file not found)
        mock_response = mock.Mock()
        mock_response.status_code = 500
        http_error = requests.exceptions.HTTPError("500 Internal Server Error")
        http_error.response = mock_response
        mock_session.get.side_effect = http_error

        # Execute with create_if_not_found=True - should still re-raise non-404 errors
        with self.assertRaises(requests.exceptions.HTTPError):
            cmd_download_logs.download_logs(
                [self.test_downloads[0]],
                max_retries=1,
                timeout=10,
                create_if_not_found=True
            )


class TestDownloadLogsCommandLine(unittest.TestCase):
    """Test the download-logs command line interface."""

    def setUp(self):
        """Set up test fixtures."""
        self.beaker_xml_content = b"""
        <root>
            <recipe id="12345">
                <log href="https://server.example.com/recipes/12345/logs/console.log"
                     name="console.log"/>
                <log href="https://server.example.com/recipes/12345/logs/journal.log"
                     name="journal.log"/>
            </recipe>
        </root>
        """

        self.testing_farm_xml_content = b"""
        <root>
            <testsuite>
                <logs>
                    <log href="https://example.com/id/data" name="data"/>
                    <log href="https://example.com/id/data/log1.txt" name="log1.txt"/>
                </logs>
                <testcase>
                    <logs>
                        <log href="https://example.com/id/testcase" name="log_dir"/>
                        <log href="https://example.com/id/testcase/log2.txt" name="log2.txt"/>
                        <log href="https://example.com/id/testcase/log3.txt" name="log3.txt"/>
                        <log href="https://example.com/id/testcase/log4.txt" name="log4.txt"/>
                    </logs>
                </testcase>
            </testsuite>

        </root>
        """

    @mock.patch('sys.stderr', new_callable=io.StringIO)
    def test_missing_source_argument(self, stderr_mock):
        """Test command fails when source argument is missing."""
        expected_message = "error: the following arguments are required: --source"

        args = [
            "download-logs",
            "--input", "/tmp/test_input.xml",
            "--output", "/tmp/test_output"
        ]

        with self.assertRaises(SystemExit) as context:
            cli.main(args)

        self.assertEqual('2', str(context.exception))
        self.assertIn(expected_message, stderr_mock.getvalue())

    @mock.patch('sys.stderr', new_callable=io.StringIO)
    def test_missing_input_argument(self, stderr_mock):
        """Test command fails when input argument is missing."""
        expected_message = "error: the following arguments are required: -i/--input"

        args = [
            "download-logs",
            "--source", "beaker",
            "--output", "/tmp/test_output"
        ]

        with self.assertRaises(SystemExit) as context:
            cli.main(args)

        self.assertEqual('2', str(context.exception))
        self.assertIn(expected_message, stderr_mock.getvalue())

    @mock.patch('sys.stderr', new_callable=io.StringIO)
    def test_invalid_source_argument(self, stderr_mock):
        """Test command fails with invalid source argument."""
        expected_message = "error: argument --source: invalid choice: 'invalid'"

        args = [
            "download-logs",
            "--input", "/tmp/test_input.xml",
            "--source", "invalid",
            "--output", "/tmp/test_output"
        ]

        with self.assertRaises(SystemExit) as context:
            cli.main(args)

        self.assertEqual('2', str(context.exception))
        self.assertIn(expected_message, stderr_mock.getvalue())

    @mock.patch('sys.stderr', new_callable=io.StringIO)
    def test_invalid_external_file_argument(self, stderr_mock):
        """Test command fails with invalid external file argument."""
        allowed_schemes = ", ".join(cmd_download_logs.ALLOWED_EXTERNAL_FILE_SCHEMES)
        expected_message = (
            "error: argument --external-file: Invalid URL scheme 'sip' for 'sip://file.txt'. "
            f"Allowed schemes are: {allowed_schemes}"
        )

        args = [
            "download-logs",
            "--input", "/tmp/test_input.xml",
            "--source", "beaker",
            "--output", "/tmp/test_output",
            "--external-file", "sip://file.txt"
        ]

        with self.assertRaises(SystemExit) as context:
            cli.main(args)

        self.assertEqual('2', str(context.exception))
        self.assertIn(expected_message, stderr_mock.getvalue())

    def test_nonexistent_input_file(self):
        """Test command fails when input file doesn't exist."""
        file = '/nonexistent/file.xml'
        expected_log = test_utils.get_log_message(
            cmd_download_logs.LOGGER,
            f"Input file {file} does not exist",
            level='ERROR'
        )
        args = [
            "download-logs",
            "--source", "beaker",
            "--input", file,
            "--output", "/tmp/test_output"
        ]

        with self.assertLogs(cmd_download_logs.LOGGER, level='ERROR') as log_ctx:
            exit_code = cli.main(args)

        self.assertIn(expected_log, log_ctx.output)
        self.assertEqual(1, exit_code)

    def test_output_is_file_error(self):
        """Test command fails when output path is an existing file."""
        with (
            self.assertLogs(cmd_download_logs.LOGGER, level='ERROR') as log_ctx,
            misc.tempfile_from_string(self.beaker_xml_content) as input_file,
            tempfile.NamedTemporaryFile() as output_file,
        ):
            expected_log = test_utils.get_log_message(
                cmd_download_logs.LOGGER,
                f"{output_file.name} is a file, expected a directory",
                level='ERROR'
            )
            exit_code = cli.main([
                "download-logs",
                "--source", "beaker",
                "--input", input_file,
                "--output", output_file.name
            ])

            self.assertIn(expected_log, log_ctx.output)
        self.assertEqual(1, exit_code)

    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_download_logs.download_logs')
    def test_successful_beaker_download(self, mock_download_logs):
        """Test successful execution with beaker source."""
        with (
            self.assertLogs(cmd_download_logs.LOGGER, level='INFO') as log_ctx,
            misc.tempfile_from_string(self.beaker_xml_content) as input_file,
            tempfile.TemporaryDirectory() as tmp_dir
        ):
            expected_log = test_utils.get_log_message(
                cmd_download_logs.LOGGER,
                f"3 log files downloaded successfully to {tmp_dir}"
            )

            exit_code = cli.main([
                "download-logs",
                "--source", "beaker",
                "--input", input_file,
                "--output", tmp_dir,
                "--retries", "5",
                "--timeout", "60",
                "--external-file", "http://example.com/path/extra.log",
            ])

            # Verify download_logs was called two (test logs + external file)
            self.assertEqual(mock_download_logs.call_count, 2)

            # Get all calls
            call_args_list = mock_download_logs.call_args_list

            # Test logs
            test_call = call_args_list[0]
            test_logs = test_call[0][0]
            self.assertIsInstance(test_logs, list)
            self.assertEqual(len(test_logs), 2)  # 2 regular logs
            for test in test_logs:
                self.assertIsInstance(test, TestToDownload)
            self.assertEqual(test_call.kwargs['max_retries'], 5)
            self.assertEqual(test_call.kwargs['timeout'], 60)
            self.assertEqual(test_call.kwargs['create_if_not_found'], False)

            # External files
            external_call = call_args_list[1]
            external_logs = external_call[0][0]
            self.assertIsInstance(external_logs, list)
            self.assertEqual(len(external_logs), 1)  # 1 external file
            for test in external_logs:
                self.assertIsInstance(test, TestToDownload)
            self.assertEqual(external_call.kwargs['max_retries'], 5)
            self.assertEqual(external_call.kwargs['timeout'], 60)
            self.assertEqual(external_call.kwargs['create_if_not_found'], False)

            # Check success message
            self.assertIn(expected_log, log_ctx.output)

            self.assertEqual(0, exit_code)

    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_download_logs.download_logs')
    def test_successful_testing_farm_download(self, mock_download_logs):
        """Test successful execution with beaker source."""
        with (
            self.assertLogs(cmd_download_logs.LOGGER, level='INFO') as log_ctx,
            misc.tempfile_from_string(self.testing_farm_xml_content) as input_file,
            tempfile.TemporaryDirectory() as tmp_dir
        ):
            expected_log = test_utils.get_log_message(
                cmd_download_logs.LOGGER,
                f"5 log files downloaded successfully to {tmp_dir}"
            )

            exit_code = cli.main([
                "download-logs",
                "--source", "testing-farm",
                "--input", input_file,
                "--output", tmp_dir,
                "--retries", "5",
                "--timeout", "60",
                "--external-file", "http://example.com/path/extra.log",
            ])

            # Verify download_logs was called two (test logs + external file)
            self.assertEqual(mock_download_logs.call_count, 2)

            # Get all calls
            call_args_list = mock_download_logs.call_args_list

            # Test logs
            test_call = call_args_list[0]
            test_logs = test_call[0][0]
            self.assertIsInstance(test_logs, list)
            self.assertEqual(len(test_logs), 4)  # 4 regular logs
            for test in test_logs:
                self.assertIsInstance(test, TestToDownload)
            self.assertEqual(test_call.kwargs['max_retries'], 5)
            self.assertEqual(test_call.kwargs['timeout'], 60)
            self.assertEqual(test_call.kwargs['create_if_not_found'], False)

            # External files
            external_call = call_args_list[1]
            external_logs = external_call[0][0]
            self.assertIsInstance(external_logs, list)
            self.assertEqual(len(external_logs), 1)  # 1 external file
            for test in external_logs:
                self.assertIsInstance(test, TestToDownload)
            self.assertEqual(external_call.kwargs['max_retries'], 5)
            self.assertEqual(external_call.kwargs['timeout'], 60)
            self.assertEqual(external_call.kwargs['create_if_not_found'], False)

            # Check success message
            self.assertIn(expected_log, log_ctx.output)

            self.assertEqual(0, exit_code)

    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_download_logs.download_logs')
    def test_http_error_handling(self, mock_download_logs):
        """Test HTTP error handling during download."""
        mock_download_logs.side_effect = requests.exceptions.HTTPError("404 Not Found")

        expected_log = test_utils.get_log_message(
            cmd_download_logs.LOGGER,
            "HTTP error occurred: 404 Not Found",
            level='ERROR'
        )

        with (
            self.assertLogs(cmd_download_logs.LOGGER, level='ERROR') as log_ctx,
            misc.tempfile_from_string(self.beaker_xml_content) as input_file,
            tempfile.TemporaryDirectory() as tmp_dir,
        ):
            exit_code = cli.main([
                "download-logs",
                "--source", "beaker",
                "--input", input_file,
                "--output", tmp_dir
            ])
        self.assertIn(expected_log, log_ctx.output)
        self.assertEqual(1, exit_code)

    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_download_logs.download_logs')
    def test_request_error_handling(self, mock_download_logs):
        """Test general request error handling during download."""
        mock_download_logs.side_effect = requests.exceptions.RequestException("Connection error")
        expected_log = test_utils.get_log_message(
            cmd_download_logs.LOGGER,
            "A request error occurred: Connection error",
            level='ERROR'
        )

        with (
            self.assertLogs(cmd_download_logs.LOGGER, level='ERROR') as log_ctx,
            misc.tempfile_from_string(self.beaker_xml_content) as input_file,
            tempfile.TemporaryDirectory() as tmp_dir,
        ):
            exit_code = cli.main([
                "download-logs",
                "--source", "beaker",
                "--input", input_file,
                "--output", tmp_dir
            ])

        self.assertIn(expected_log, log_ctx.output)
        self.assertEqual(1, exit_code)

    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_download_logs.download_logs', mock.Mock())
    def test_directory_creation_message(self):
        """Test that directory creation message is printed."""
        with (
            self.assertLogs(cmd_download_logs.LOGGER, level='INFO') as log_ctx,
            misc.tempfile_from_string(self.beaker_xml_content) as input_file,
            tempfile.TemporaryDirectory() as tmp_dir
        ):
            non_existent_dir = f'{tmp_dir}/new_logs_dir'

            expected_log = test_utils.get_log_message(
                cmd_download_logs.LOGGER,
                f"Creating output directory {non_existent_dir}"
            )
            exit_code = cli.main([
                "download-logs",
                "--source", "beaker",
                "--input", input_file,
                "--output", non_existent_dir
            ])

            self.assertIn(expected_log, log_ctx.output)
        self.assertEqual(0, exit_code)

    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_download_logs.download_logs', mock.Mock())
    def test_directory_exists_message(self):
        """Test that directory exists message is printed."""
        with (
            self.assertLogs(cmd_download_logs.LOGGER, level='INFO') as log_ctx,
            misc.tempfile_from_string(self.beaker_xml_content) as input_file,
            tempfile.TemporaryDirectory() as tmp_dir
        ):
            expected_log = test_utils.get_log_message(
                cmd_download_logs.LOGGER,
                f"{tmp_dir} directory exists"
            )
            exit_code = cli.main([
                "download-logs",
                "--source", "beaker",
                "--input", input_file,
                "--output", tmp_dir
            ])
            self.assertIn(expected_log, log_ctx.output)
        self.assertEqual(0, exit_code)

    def test_default_values(self):
        """Test that default values are set correctly."""
        # Test constants
        self.assertEqual(cmd_download_logs.DEFAULT_CHUNK_SIZE, 8192)
        self.assertEqual(cmd_download_logs.DEFAULT_RETRIES, 5)
        self.assertEqual(cmd_download_logs.DEFAULT_OUTPUT_DIR, 'logs')
        self.assertEqual(cmd_download_logs.DEFAULT_TIMEOUT, 30)
        self.assertEqual(cmd_download_logs.ALLOWED_EXTERNAL_FILE_SCHEMES, {'http', 'https', 'ftp'})
