"""Test cases for bkr2kcidb cli module."""

from importlib.resources import files
import json
from pathlib import Path
import tempfile
import unittest

from kernel_qe_tools.kcidb_tool import cli
from kernel_qe_tools.kcidb_tool.cmd_merge import LOGGER

from .. import utils as test_utils

ASSETS = files(__package__) / 'assets'


class TestMergeSubcommand(unittest.TestCase):
    """Tests for the subcommand merge."""

    def test_when_everything_works(self):
        """Test when everything works."""
        # Prepare test
        with (
            tempfile.TemporaryDirectory() as tmp_dir,
            self.assertLogs(LOGGER, level='INFO') as log_ctx
        ):
            kcidb_file = Path(tmp_dir, 'my_merged_kcidb.json')
            expected_log = test_utils.get_log_message(
                LOGGER,
                f'File {kcidb_file.resolve()} wrote !!',
            )
            args = [
                "merge",
                "--result", f"{ASSETS}/kcidb_input/good/kcidb_1.json",
                "--result", f"{ASSETS}/kcidb_input/good/kcidb_2.json",
                "--result", f"{ASSETS}/kcidb_input/good/kcidb_3.json",
                "--output", f"{kcidb_file.resolve()}"
            ]
            # Run code
            exit_code = cli.main(args)
            self.assertTrue(kcidb_file.is_file())

            # Check statistics
            report = json.loads(kcidb_file.read_text(encoding='utf-8'))
            self.assertEqual(2, len(report['checkouts']))
            self.assertEqual(3, len(report['builds']))
            self.assertEqual(6, len(report['tests']))

            # Check STDOUT
            self.assertIn(expected_log, log_ctx.output)

            # Check exit code
            self.assertEqual(0, exit_code)

    def test_detect_duplicate_tests(self):
        """Test that duplicate test ids are found."""
        expected_log = test_utils.get_log_message(
            LOGGER,
            'Test id:kcidb_tool:brew-62562247-info_x86_64_kernel-rt_kcidb_tool_1 already present, '
            'refusing to merge',
            level='ERROR'
        )
        # Prepare test
        with (
            tempfile.TemporaryDirectory() as tmp_dir,
            self.assertLogs(LOGGER, level='ERROR') as log_ctx
        ):
            kcidb_file = Path(tmp_dir, 'my_merged_kcidb.json')
            args = [
                "merge",
                "--result", f"{ASSETS}/kcidb_input/dup_tests/kcidb_1.json",
                "--result", f"{ASSETS}/kcidb_input/dup_tests/kcidb_2.json",
                "--output", f"{kcidb_file.resolve()}"
            ]
            # Run code
            exit_code = cli.main(args)
        self.assertIn(expected_log, log_ctx.output)
        self.assertEqual(1, exit_code)
