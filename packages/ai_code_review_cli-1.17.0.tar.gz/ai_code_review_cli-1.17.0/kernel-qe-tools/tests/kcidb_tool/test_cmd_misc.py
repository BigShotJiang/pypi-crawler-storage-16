"""Test cases for bkr2kcidb cli module."""

import io
import unittest
from unittest import mock

from kernel_qe_tools.kcidb_tool import cli


class TestMisc(unittest.TestCase):
    """Misc tests."""

    @mock.patch('sys.stderr', new_callable=io.StringIO)
    def test_invalid_subcommand(self, stderr_mock):
        """Check invalid subcommand."""
        expected_message = "error: argument command: invalid choice: 'any_subcommand_non_defined'"
        args = [
            "any_subcommand_non_defined"
        ]
        with self.assertRaises(SystemExit) as context:
            cli.main(args)
        self.assertEqual('2', str(context.exception))
        self.assertIn(expected_message, stderr_mock.getvalue())
