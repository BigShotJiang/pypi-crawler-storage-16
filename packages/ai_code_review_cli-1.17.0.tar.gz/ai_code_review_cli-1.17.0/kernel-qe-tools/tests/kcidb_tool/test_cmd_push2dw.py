"""Test cases for bkr2kcidb cli module."""

from importlib.resources import files
import io
import os
import unittest
from unittest import mock

from cki_lib.kcidb import ValidationError

from kernel_qe_tools.kcidb_tool import cli
from kernel_qe_tools.kcidb_tool.cmd_push2dw import LOGGER

from .. import utils as test_utils

ASSETS = files(__package__) / 'assets'


class TestPush2DWSubcommand(unittest.TestCase):
    """Tests for the subcommand push2dw."""

    def test_with_a_non_existing_file(self):
        """Check push2dw when the file does not exist."""
        file_name = 'this_file_should_not_exist.json'
        expected_log = test_utils.get_log_message(
            LOGGER,
            f"{file_name} is not a file or does not exist",
            level="ERROR"
        )
        args = [
            "push2dw",
            "--input", f"{file_name}",
            "--token", "any_token"
        ]
        with self.assertLogs(LOGGER, level="ERROR") as log_ctx:
            exit_code = cli.main(args)
        self.assertIn(expected_log, log_ctx.output)
        self.assertEqual(1, exit_code)

    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_push2dw.validate_extended_kcidb_schema')
    def test_an_error_in_the_kcidb_validation(self, mock_validate_extended_kcidb_schema):
        """Check push2dw when the KCIDB validation fails."""
        file_name = f'{ASSETS}/kcidb_input/good/kcidb_1.json'
        cmd_error_log = test_utils.get_log_message(
            LOGGER,
            f'The file {file_name} is not a valid KCIDB file.',
            level="ERROR"
        )
        exc_error_msg = 'Some error'
        exc_error_log = test_utils.get_log_message(LOGGER, exc_error_msg, level="ERROR")
        args = [
            "push2dw",
            "--input", f"{file_name}",
            "--token", "any_token"
        ]
        mock_validate_extended_kcidb_schema.side_effect = ValidationError(exc_error_msg)
        with self.assertLogs(LOGGER, level="ERROR") as log_ctx:
            exit_code = cli.main(args)
        self.assertEqual(1, exit_code)
        self.assertIn(cmd_error_log, log_ctx.output)
        self.assertIn(exc_error_log, log_ctx.output)

    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_push2dw.validate_extended_kcidb_schema',
                mock.Mock())
    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_push2dw.Datawarehouse')
    def test_an_error_with_datawarehouse(self, mock_dw_api):
        """Check push2dw when we have an error with dw."""
        file_name = f'{ASSETS}/kcidb_input/good/kcidb_1.json'
        dw_url = 'http:/dw.cki.org'
        cmd_error_log = test_utils.get_log_message(
            LOGGER,
            f"Unable to send KCIDB data to {dw_url}",
            level="ERROR"
        )
        exc_error_msg = 'Some error'
        exc_error_log = test_utils.get_log_message(LOGGER, exc_error_msg, level="ERROR")
        args = [
            "push2dw",
            "--input", f"{file_name}",
            "--url", f"{dw_url}",
            "--token", "any_token"
        ]
        mock_dw_api.side_effect = Exception(exc_error_msg)
        with self.assertLogs(LOGGER, level="ERROR") as log_ctx:
            exit_code = cli.main(args)
        self.assertEqual(1, exit_code)
        self.assertIn(cmd_error_log, log_ctx.output[0])
        self.assertIn(exc_error_log, log_ctx.output)

    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_push2dw.validate_extended_kcidb_schema',
                mock.Mock())
    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_push2dw.Datawarehouse', mock.Mock())
    # also testing getting the token from the env
    @mock.patch.dict(os.environ, {"DW_TOKEN": "any_token"})
    def test_when_it_works(self):
        """Check push2dw when everything works."""
        file_name = f'{ASSETS}/kcidb_input/good/kcidb_1.json'
        dw_url = 'http:/dw.cki.org'

        validation_log = test_utils.get_log_message(
            LOGGER,
            f'Validating KCIDB format for {file_name} file'
        )
        sending_log = test_utils.get_log_message(
            LOGGER,
            f'Sending KCIDB data to {dw_url}'
        )
        done_log = test_utils.get_log_message(LOGGER, 'Done!')
        args = [
            "push2dw",
            "--input", f"{file_name}",
            "--url", f"{dw_url}"
        ]
        with self.assertLogs(LOGGER, level="INFO") as log_ctx:
            exit_code = cli.main(args)
        self.assertIn(validation_log, log_ctx.output)
        self.assertIn(sending_log, log_ctx.output)
        self.assertIn(done_log, log_ctx.output)
        self.assertEqual(0, exit_code)

    @mock.patch('sys.stderr', new_callable=io.StringIO)
    def test_missing_token(self, stderr_mock):
        """Check fail with missing token."""
        expected_message = "push2dw: error: the following arguments are required: --token"
        args = [
            "push2dw"
        ]
        with self.assertRaises(SystemExit) as context:
            cli.main(args)
        self.assertEqual('2', str(context.exception))
        self.assertIn(expected_message, stderr_mock.getvalue())
