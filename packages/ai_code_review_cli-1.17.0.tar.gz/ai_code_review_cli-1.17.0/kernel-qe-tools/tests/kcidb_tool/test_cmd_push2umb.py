"""Test cases for bkr2kcidb cli module."""

import unittest
from unittest import mock

from cki_lib import misc
from cki_lib import stomp

from kernel_qe_tools.kcidb_tool import cli
from kernel_qe_tools.kcidb_tool.cmd_push2umb import LOGGER
from kernel_qe_tools.kcidb_tool.cmd_push2umb import UMB_TOPIC

from .. import utils as test_utils


class TestPush2UMBSubcommand(unittest.TestCase):
    """Tests for the subcommand push2umb."""

    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_push2umb.stomp.StompClient')
    def test_when_it_works(self, stomp_mock):
        """Check basic."""
        dw_link = 'https://datawarehouse.cki-project.org/kcidb/checkouts/checkout_id'
        expected_log = test_utils.get_log_message(
            LOGGER,
            f'DataWarehouse link: {dw_link}'
        )

        kcidb_content = b'{"checkouts": [{"id": "checkout_id"}]}'
        with (
            misc.tempfile_from_string(kcidb_content) as kcidb_file,
            misc.tempfile_from_string(b'') as certfile,
            self.assertLogs(LOGGER, level="INFO") as log_ctx,
        ):
            args = [
                'push2umb',
                '--input', f'{kcidb_file}',
                '--certificate', f'{certfile}'
            ]
            exit_code = cli.main(args)
        stomp_mock.return_value.send_message.assert_called_once_with(
            {'checkouts': [{'id': 'checkout_id'}]},
            UMB_TOPIC
        )
        self.assertIn(expected_log, log_ctx.output)
        self.assertEqual(1, stomp_mock.return_value.send_message.call_count)
        self.assertEqual(0, exit_code)

    @mock.patch('time.sleep', mock.Mock())
    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_push2umb.stomp.StompClient')
    def test_when_stomp_return_an_exception(self, stomp_mock):
        """Check a generic exception that will not be retried."""
        generic_error = f"ERROR:{LOGGER.name}:Unable to send KCIDB data through UMB"
        exception_error = 'Some message'
        stomp_mock.return_value.send_message.side_effect = Exception(exception_error)
        kcidb_content = b'{"checkouts": [{"id": "checkout_id"}]}'
        with (
            self.assertLogs(LOGGER, level="ERROR") as log_ctx,
            misc.tempfile_from_string(kcidb_content) as kcidb_file,
            misc.tempfile_from_string(b'') as certfile
        ):
            args = [
                'push2umb',
                '--input', f'{kcidb_file}',
                '--certificate', f'{certfile}'
            ]
            exit_code = cli.main(args)

        self.assertIn(generic_error, "\n".join(log_ctx.output))
        self.assertIn(exception_error, "\n".join(log_ctx.output))
        self.assertEqual(1, stomp_mock.return_value.send_message.call_count)
        self.assertEqual(1, exit_code)

    @mock.patch('time.sleep', mock.Mock())
    @mock.patch('kernel_qe_tools.kcidb_tool.cmd_push2umb.stomp.StompClient')
    def test_retry_on_transient_error(self, stomp_mock):
        """Check retry logic on transient errors."""
        # Fail 2 times, succeed on 3rd attempt
        stomp_mock.return_value.send_message.side_effect = [
            stomp.StompException('Received Status.ERROR response from server'),
            stomp.StompException('Received Status.ERROR response from server'),
            None  # Success
        ]

        kcidb_content = b'{"checkouts": [{"id": "checkout_id"}]}'
        with (
            misc.tempfile_from_string(kcidb_content) as kcidb_file,
            misc.tempfile_from_string(b'') as certfile,
        ):
            args = [
                'push2umb',
                '--input', f'{kcidb_file}',
                '--certificate', f'{certfile}'
            ]
            exit_code = cli.main(args)

        # Verify retries happened with success on 3rd attempt
        self.assertEqual(3, stomp_mock.return_value.send_message.call_count)
        self.assertEqual(0, exit_code)

    def test_when_the_certificate_does_not_exist(self):
        """Check when certificate does not exist."""
        file = 'cert.pem'
        expected_log = test_utils.get_log_message(
            LOGGER,
            f'{file} is not a file or does not exist',
            level='ERROR'
        )
        with (
            misc.tempfile_from_string(b'') as kcidb_file,
            self.assertLogs(LOGGER, level="ERROR") as log_ctx,
        ):
            args = [
                'push2umb',
                '--input', f'{kcidb_file}',
                '--certificate', 'cert.pem'
            ]
            exit_code = cli.main(args)
        self.assertIn(expected_log, log_ctx.output)
        self.assertEqual(1, exit_code)

    def test_when_the_input_file_does_not_exist(self):
        """Check when the input file does not exist."""
        input_file = '/tmp/non_existent_file.json'
        expected_log = test_utils.get_log_message(
            LOGGER,
            f'{input_file} is not a file or does not exist',
            level='ERROR'
        )
        with (
            misc.tempfile_from_string(b'') as certfile,
            self.assertLogs(LOGGER, level="ERROR") as log_ctx,
        ):
            args = [
                'push2umb',
                '--input', f'{input_file}',
                '--certificate', f'{certfile}'
            ]
            exit_code = cli.main(args)
        self.assertIn(expected_log, log_ctx.output)
        self.assertEqual(1, exit_code)
