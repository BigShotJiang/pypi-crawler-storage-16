"""Test testing farm utils."""

from importlib.resources import files
import pathlib
import unittest
from unittest import mock
import xml.etree.ElementTree as ET

from kernel_qe_tools.kcidb_tool.testing_farm import utils

ASSETS = files(__package__) / 'assets'


class TestUtil(unittest.TestCase):
    """Test case for utils."""

    def test_get_kcidb_test_status(self):
        """Ensure get_kcidb_test_status works."""
        cases = (
            ('undefined goes to ERROR', 'undefined', 'ERROR'),
            ('error goes to ERROR', 'error', 'ERROR'),
            ('passed goes to PASS', 'passed', 'PASS'),
            ('failed goes to FAIL', 'failed', 'FAIL'),
            ('info goes to PASS', 'info', 'PASS'),
            ('not_applicable goes to SKIP', 'not_applicable', 'SKIP'),
            ('skipped goes to SKIP', 'skipped', 'SKIP'),
            ('needs_inspection goes to FAIL', 'needs_inspection', 'ERROR'),
            ('pending goes to MISS', 'pending', 'MISS'),
        )
        for description, testing_farm_result, expected in cases:
            with self.subTest(description):
                self.assertEqual(expected, utils.get_kcidb_test_status(testing_farm_result))

    @mock.patch('cki_lib.kcidb.validate.sanitize_kcidb_status', return_value='RESULT')
    def test_get_kcidb_result_status(self, mock_sanitize_kcidb_status):
        """Ensure get_kcidb_result_status works."""
        self.assertEqual('RESULT', utils.get_kcidb_result_status('result'))
        mock_sanitize_kcidb_status.assert_called_once_with('RESULT')

    def test_get_arch_from_suite(self):
        """Ensure get_arch_from_suite works."""
        with_arch = """
        <testsuite>
          <testing-environment name="requested">
            <property name="arch" value="x86_64"/>
          </testing-environment>
        </testsuite>
        """

        without_arch = "<testsuite/>"

        cases = (
            ('With arch', with_arch, 'x86_64'),
            ('Without arch', without_arch, None),
        )

        for description, xml_content, expected in cases:
            with self.subTest(description):
                test_suite = ET.fromstring(xml_content)
                self.assertEqual(expected, utils.get_arch_from_testsuite(test_suite))

    def test_get_arch_from_testcase(self):
        """Ensure get_arch_from_testcase works."""
        arch = "x86_64"
        normal_provisioned_with_arch = """
        <testcase>
          <testing-environment name="requested">
            <property name="arch" value="x86_64"/>
          </testing-environment>
          <testing-environment name="provisioned">
            <property name="arch" value="x86_64"/>
          </testing-environment>
        </testcase>
        """

        normal_not_provisioned_with_arch = """
        <testcase>
          <testing-environment name="requested">
            <property name="arch" value="x86_64"/>
          </testing-environment>
        </testcase>
        """

        multihost_provisioned_with_arch = """
        <testcase>
          <guest name="server" role="server">
            <testing-environment name="provisioned">
              <property name="arch" value="x86_64"/>
            </testing-environment>
          </guest>
        </testcase>
        """

        # Multihost does not have arch in the requested environment
        multihost_not_provisioned_with_arch = """
        <testcase>
          <guest name="server" role="server"/>
        </testcase>
        """

        cases = (
            ('Normal and provisioned', normal_provisioned_with_arch, arch),
            ('Normal and not provisioned', normal_not_provisioned_with_arch, arch),
            ('Multihost and provisioned', multihost_provisioned_with_arch, arch),
            ('Multihost and not provisioned', multihost_not_provisioned_with_arch, None),
        )

        for description, xml_content, expected in cases:
            with self.subTest(description):
                test_case = ET.fromstring(xml_content)
                self.assertEqual(expected, utils.get_arch_from_testcase(test_case))

    def test_get_hostname_from_testcase(self):
        """Ensure get_hostname_from_testcase works."""
        with_hostname = """
        <testcase>
          <properties>
            <property name="baseosci.connectable_host" value="10.31.10.185"/>
          </properties>
        </testcase>
        """

        without_hostname = """
        <testcase>
          <properties>
            <property name="baseosci.arch" value="x86_64"/>
          </properties>
        </testcase>
        """

        cases = (
            ('With hostname', with_hostname, '10.31.10.185'),
            ('Without hostname', without_hostname, None),
        )

        for description, xml_content, expected in cases:
            with self.subTest(description):
                test_case = ET.fromstring(xml_content)
                self.assertEqual(expected, utils.get_hostname_from_testcase(test_case))

    def test_get_results(self):
        """Ensure get_results works."""
        xml_content = """
        <checks checks="1" errors="0" failures="0">
          <check name="dmesg" result="pass" event="before-test">
            <logs>
              <log href="http://artifacts.server/log_file.txt" name="log_file.txt"/>
            </logs>
          </check>
        </checks>
        """
        test = {'id': 'test_id'}
        expected = [{
            'id': 'test_id.2',
            'name': 'dmesg',
            'comment': 'dmesg',
            'status': 'PASS',
            'output_files': [{
                'name': 'log_file.txt',
                'url': 'http://artifacts.server/log_file.txt'
            }]
        }]
        results = ET.fromstring(xml_content)
        self.assertListEqual(expected, utils.get_results(test, results, 2))

    def test_get_results_with_a_timeout_check(self):
        """Ensure get_results change the status to ERROR with an internal timeout."""
        xml_content = """
        <checks checks="1" errors="0" failures="1">
          <check name="internal/timeout" result="ail" event="before-test">
          </check>
        </checks>
        """
        test = {'id': 'test_id'}
        expected = [{
            'id': 'test_id.2',
            'name': 'internal/timeout',
            'comment': 'internal/timeout',
            'status': 'ERROR'
        }]
        results = ET.fromstring(xml_content)
        self.assertListEqual(expected, utils.get_results(test, results, 2))

    def test_create_virtual_result(self):
        """Ensure create_virtual_result works."""
        test = {
            'id': 'test_id',
            'path': 'test_name',
            'status': 'PASS',
            'output_files': [{
                'name': 'testout.log',
                'url': 'http://artifacts.server/output.txt'
            }]
        }
        expected = {
            'id': 'test_id.1',
            'name': 'test_name',
            'comment': 'test_name',
            'output_files': [{
                'name': 'testout.log',
                'url': 'http://artifacts.server/output.txt'
            }],
            'status': 'PASS'
        }
        self.assertDictEqual(expected, utils.create_virtual_result(test))

    def test_create_status_mismatch_result(self):
        """Ensure create_status_mismatch_result works."""
        test = {
            'id': 'test_id',
            'path': 'test_name',
            'status': 'ERROR',
            'output_files': [{
                'name': 'testout.log',
                'url': 'http://artifacts.server/output.txt'
            }]
        }
        expected = {
            'id': 'test_id.1',
            'name': 'status_mismatch',
            'comment': 'status_mismatch',
            'output_files': [{
                'name': 'testout.log',
                'url': 'http://artifacts.server/output.txt'
            }],
            'status': 'ERROR'
        }
        self.assertDictEqual(expected, utils.create_status_mismatch_result(test, 1))

    def test_create_system_provision_testcase_when_testsuite_has_testcases(self):
        """Test when everything is ok."""
        tmt_content = pathlib.Path(ASSETS,
                                   'testing_farm_system_provision.xml').read_text(encoding='utf-8')
        root = ET.fromstring(tmt_content)
        test_suite = root.findall('.//testsuite')[1]

        test_case = utils.create_system_provision_test_case(test_suite,
                                                            list(test_suite.findall('testcase')),
                                                            1)

        checks = test_case.findall('.//check')

        self.assertEqual('system_provision', test_case.get('name'))
        self.assertEqual('1', test_case.get('id'))
        self.assertEqual('0', test_case.get('time'))
        self.assertEqual(10, len(test_case.findall('./logs/log')))
        self.assertEqual(1, len(checks))
        self.assertEqual('system_provision', checks[0].get('name'))
        self.assertEqual('pass', checks[0].get('result'))
        self.assertEqual(10, len(checks[0].findall('.//log')))
        self.assertEqual('passed', test_case.get('result'))
        self.assertEqual('True', test_case.get('fake'))

    def test_create_system_provision_testcase_when_testsuite_does_not_have_testcases(self):
        """Test when provision fails."""
        tmt_content = pathlib.Path(ASSETS,
                                   'testing_farm_system_provision.xml').read_text(encoding='utf-8')
        root = ET.fromstring(tmt_content)
        test_suite = root.findall('.//testsuite')[0]

        test_case = utils.create_system_provision_test_case(test_suite,
                                                            list(test_suite.findall('testcase')),
                                                            1)

        checks = test_case.findall('.//check')

        self.assertEqual('system_provision', test_case.get('name'))
        self.assertEqual('1', test_case.get('id'))
        self.assertEqual('0', test_case.get('time'))
        self.assertEqual(10, len(test_case.findall('./logs/log')))
        self.assertEqual(1, len(checks))
        self.assertEqual('system_provision', checks[0].get('name'))
        self.assertEqual('error', checks[0].get('result'))
        self.assertEqual(10, len(checks[0].findall('.//log')))
        self.assertEqual('error', test_case.get('result'))
        self.assertEqual('True', test_case.get('fake'))

    def test_create_system_provision_testcase_when_testsuite_with_all_testcases_pending(self):
        """Test when provision fails and all tests have result as pending"""
        tmt_content = pathlib.Path(ASSETS,
                                   'testing_farm_system_provision.xml').read_text(encoding='utf-8')
        root = ET.fromstring(tmt_content)
        test_suite = root.findall('.//testsuite')[2]

        test_case = utils.create_system_provision_test_case(test_suite,
                                                            list(test_suite.findall('testcase')),
                                                            1)

        checks = test_case.findall('.//check')

        self.assertEqual('system_provision', test_case.get('name'))
        self.assertEqual('1', test_case.get('id'))
        self.assertEqual('0', test_case.get('time'))
        self.assertEqual(4, len(test_case.findall('./logs/log')))
        self.assertEqual(1, len(checks))
        self.assertEqual('system_provision', checks[0].get('name'))
        self.assertEqual('error', checks[0].get('result'))
        self.assertEqual(4, len(checks[0].findall('.//log')))
        self.assertEqual('error', test_case.get('result'))
        self.assertEqual('True', test_case.get('fake'))

    def test_get_job_url(self):
        """Ensure get_job_url works."""
        canonical_logs = """
        <xml>
          <logs>
            <log href="http://testing-farm.server/job/1234/logs/log.txt" name="log.txt"/>
            <log href="http://testing-farm.server/job/1234" name="workdir"/>
          </logs>
        </xml>
        """
        canonical_logs_ending_with_slash = """
        <xml>
          <logs>
            <log href="http://testing-farm.server/job/1234/logs/log.txt" name="log.txt"/>
            <log href="http://testing-farm.server/job/1234/" name="workdir"/>
          </logs>
        </xml>
        """
        logs_without_workdir = """
        <xml>
          <logs>
            <log href="http://testing-farm.server/job/1234/logs/log.txt" name="log.txt"/>
          </logs>
        </xml>
        """
        logs_without_any_log = """
        <xml>
          <logs/>
        </xml>
        """
        no_logs = """
        <xml/>
        """
        expected = 'http://testing-farm.server/job'
        cases = (
            ('Normal case', canonical_logs, expected),
            ('Canonical logs ending with slash', canonical_logs_ending_with_slash, expected),
            ('Logs without workdir', logs_without_workdir, None),
            ('Logs without any log', logs_without_any_log, None),
            ('No logs', no_logs, None),
        )

        for description, xml_content, expected in cases:
            with self.subTest(description):
                test_suite = ET.fromstring(xml_content)
                self.assertEqual(expected, utils.get_job_url(test_suite.find('logs')))

    def test_group_testcases_by_guest(self):
        """Ensure group_testcases_by_guest works."""
        multihost = """
        <testsuites>
          <testsuite>
            <testcase name="/test_a_server">
              <guest name="server" role="server"/>
            </testcase>
            <testcase name="/test_a_client1">
              <guest name="client1" role="client"/>
            </testcase>
            <testcase name="/test_a_client2">
              <guest name="client2" role="client"/>
            </testcase>
            <testcase name="/test_b_server">
              <guest name="server" role="server"/>
            </testcase>
            <testcase name="/test_b_client1">
              <guest name="client1" role="client"/>
            </testcase>
            <testcase name="/test_b_client2">
              <guest name="client2" role="client"/>
            </testcase>
          </testsuite>
        </testsuites>
        """

        multihost_test_case_names = ['/test_a_server', '/test_a_client1', '/test_a_client2']

        no_multihost = """
        <testsuites>
          <testsuite>
            <testcase name="/test_a"/>
          </testsuite>
        </testsuites>
        """

        no_multihost_test_case_names = ['/test_a']

        cases = (
            ('Multihost should return 3 testcases', multihost, 3, multihost_test_case_names),
            ('No multihost should return 1 testcase', no_multihost, 1,
             no_multihost_test_case_names),
        )
        for description, xml_content, groups_size, test_names in cases:
            with self.subTest(description):
                test_suites = ET.fromstring(xml_content)
                test_cases_group = utils.group_testcases_by_guest(test_suites.find('testsuite'))
                self.assertEqual(len(test_cases_group), groups_size)
                for test_case_group, test_name in zip(test_cases_group, test_names):
                    # Only test the first name in the group
                    self.assertEqual(test_case_group[0].get('name'), test_name)

    def test_get_compose_from_xml(self):
        """Ensure get_compose from a xml works."""
        compose = "compose_info"
        normal_provisioned_with_compose = """
        <element>
          <testing-environment name="requested">
            <property name="compose" value="compose"/>
          </testing-environment>
          <testing-environment name="provisioned">
            <property name="compose" value="compose_info"/>
          </testing-environment>
        </element>
        """

        normal_not_provisioned_with_compose = """
        <element>
          <testing-environment name="requested">
            <property name="compose" value="compose_info"/>
          </testing-environment>
        </element>
        """

        multihost_provisioned_with_compose = """
        <element>
          <guest name="server" role="server">
            <testing-environment name="provisioned">
              <property name="compose" value="compose_info"/>
            </testing-environment>
          </guest>
        </element>
        """

        # Multihost does not have requested environment
        multihost_not_provisioned_with_compose = """
        <element>
          <guest name="server" role="server"/>
        </element>
        """

        cases = (
            ('Normal and provisioned', normal_provisioned_with_compose, compose),
            ('Normal and not provisioned', normal_not_provisioned_with_compose, compose),
            ('Multihost and provisioned', multihost_provisioned_with_compose, compose),
            ('Multihost and not provisioned', multihost_not_provisioned_with_compose, None),
        )

        for description, xml_content, expected in cases:
            with self.subTest(description):
                xml = ET.fromstring(xml_content)
                self.assertEqual(expected, utils.get_compose_from_xml(xml))

    def test_get_test_status_from_results(self):
        """Ensure get_test_status_from_results works."""
        mocked_choices = ['WORST', 'BAD', 'GOOD', 'BEST']
        worst_status = 'BAD'
        test = {
            'misc': {
                'results': [
                    {'status': 'GOOD'},
                    {'status': 'BAD'},
                    {'status': 'BEST'}
                ]
            }
        }
        with mock.patch('cki_lib.kcidb.validate.KCIDB_STATUS_CHOICES', mocked_choices):
            self.assertEqual(worst_status, utils.get_test_status_from_results(test))

    def test_get_test_case_maintainers(self):
        """Ensure get_test_case_maintainers works."""
        test_case_with_a_single_maintainer = """
        <testcase>
          <properties>
            <property name="contact" value="user 1 &lt;user_1@example.com&gt;"/>
          </properties>
        </testcase>
        """

        test_case_with_email_only = """
        <testcase>
          <properties>
            <property name="contact" value="user_1@example.com"/>
          </properties>
        </testcase>
        """
        test_case_with_multiples_maintainer = """
        <testcase>
          <properties>
            <property name="contact" value="user 1 &lt;user_1@example.com&gt;"/>
            <property name="contact" value="user 2 &lt;user_2@example.com&gt;"/>
          </properties>
        </testcase>
        """

        test_case_with_no_maintainers = """
        <testcase>
          <properties/>
        </testcase>
        """

        test_case_with_invalid_email = """
        <testcase>
          <properties>
            <property name="contact" value="user 1 &lt;@example.com&gt;"/>
          </properties>
        </testcase>
        """

        maintainer_1 = {'name': 'user 1', 'email': 'user_1@example.com'}
        maintainer_2 = {'name': 'user 2', 'email': 'user_2@example.com'}
        maintainer_without_name = {'name': 'user_1', 'email': 'user_1@example.com'}

        cases = (
            ('Single maintainer', test_case_with_a_single_maintainer,
             [maintainer_1]),
            ('Email only', test_case_with_email_only,
             [maintainer_without_name]),
            ('Multiple maintainers', test_case_with_multiples_maintainer,
             [maintainer_1, maintainer_2]),
            ('No maintainers', test_case_with_no_maintainers, []),
            ('Invalid email', test_case_with_invalid_email, []),
        )

        for description, test_case_content, expected in cases:
            with self.subTest(description):
                test_case = ET.fromstring(test_case_content)
                self.assertEqual(expected, utils.get_test_case_maintainers(test_case))

    def test_get_test_case_maintainers_with_invalid_info_shows_a_warning(self):
        """Ensure get_test_case_maintainers shows a warning with invalid info."""
        test_case_with_invalid_email = """
        <testcase name="/invalid_contact">
          <properties>
            <property name="contact" value="user 1 &lt;@example.com&gt;"/>
          </properties>
        </testcase>
        """
        test_case = ET.fromstring(test_case_with_invalid_email)
        # Test that a warning is logged for invalid contact information
        with self.assertLogs(utils.LOGGER, level='WARNING') as log_ctx:
            utils.get_test_case_maintainers(test_case)

        # Verify that a warning was logged with the expected message
        self.assertIn(
            "Invalid contact property \"user 1 <@example.com>\" "
            "in test case /invalid_contact", log_ctx.output[0]
        )

    def test_get_test_case_maintainers_without_name_shows_a_warning(self):
        """Ensure get_test_case_maintainers shows a warning without name."""
        test_case_with_no_name = """
        <testcase name="/no_name">
          <properties>
            <property name="contact" value="user_1@example.com"/>
          </properties>
        </testcase>
        """
        test_case = ET.fromstring(test_case_with_no_name)
        # Test that a warning is logged for invalid contact information
        with self.assertLogs(utils.LOGGER, level='WARNING') as log_ctx:
            utils.get_test_case_maintainers(test_case)

        # Verify that a warning was logged with the expected message
        self.assertIn(
            "The contact does not provide a name in /no_name, "
            "getting it from the email: user_1@example.com",
            log_ctx.output[0]
        )
