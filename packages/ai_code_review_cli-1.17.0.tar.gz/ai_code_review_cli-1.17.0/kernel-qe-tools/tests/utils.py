"""Utils module."""
import contextlib
import os
import pathlib
import shutil
import tempfile


@contextlib.contextmanager
def run_in_a_sanbox_directory():
    """Create a sanbox directory."""
    tmpdir = tempfile.mkdtemp()
    origin = pathlib.Path().absolute()
    try:
        os.chdir(tmpdir)
        yield tmpdir
    finally:
        os.chdir(origin)
        shutil.rmtree(tmpdir)


def count_system_provision_tests(report):
    """Count the number of system provision tests."""
    tests = report.get("tests", [])
    return sum(test.get('comment') == 'system_provision' for test in tests)


def get_log_message(logger, message, level='info') -> str:
    """Get a log message."""
    return f"{level.upper()}:{logger.name}:{message}"
