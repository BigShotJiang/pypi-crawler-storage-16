## AI Code Review

### 📋 MR Summary
This MR replaces the external `img2simg` dependency with a native Python `convert_to_simg` utility that leverages `SEEK_HOLE`/`SEEK_DATA` for efficient sparse image creation.

- **Key Changes:**
    - Implemented `convert_to_simg` in `aib/utils.py` supporting Android Sparse Image format (v1.0).
    - Refactored `DiskFormat` in `aib/main.py` to handle conversion logic, distinguishing between containerized tools and local Python execution.
    - Added comprehensive unit tests in `aib/tests/utils_test.py` covering sparse regions, zero-fills, and alignment.
- **Impact:** Removes the runtime dependency on `android-tools`/`img2simg` for SIMG creation; affects image export functionality.
- **Risk Level:** Medium - Core image generation logic is changing; bugs could result in unbootable images, though tests are extensive.

### Detailed Code Review

The implementation correctly adheres to the Android Sparse Image format specification and efficiently detects filesystem holes. The distinction between "holes" (DONT_CARE) and "explicit zeros" (FILL) is handled correctly, ensuring data integrity.

#### 📂 File Reviews

<details>
<summary><strong>📄 `aib/utils.py`</strong> - Native SIMG conversion implementation</summary>

- **[Performance]** In `is_all_zeros`, the loop `for x in data:` is inefficient in pure Python for checking 4KB blocks.
    - **Suggestion:** Use `max(data) == 0` or `data == bytes(len(data))` (if comparing memoryview to bytes) for significantly faster execution in C-speed.
- **[Logic]** The `block_has_data` function correctly uses `os.lseek` with `SEEK_DATA`. The check `off < end` accurately determines if relevant data exists within the specific block boundaries.
- **[Resource Management]** The buffer size `read_chunk_size = 32 * 1024` (blocks) results in ~128MB reads. This is generally acceptable but ensure this fits within the memory constraints of the execution environment (e.g., CI runners).
- **[Safety]** The check `if not hasattr(os, "SEEK_DATA")` provides a necessary guard for OS compatibility.

</details>

<details>
<summary><strong>📄 `aib/main.py`</strong> - Refactoring conversion logic</summary>

- **[Architecture]** Moving `convert_image` into `DiskFormat` encapsulates the logic well.
- **[Security/Correctness]** The removal of `chown` for the `SIMG` case (local Python execution) is correct as per the author's note, while preserving it for containerized conversions (`run_in_container`).

</details>

<details>
<summary><strong>📄 `aib/tests/utils_test.py`</strong> - Testing strategy</summary>

- **[Praise]** The tests are very thorough, specifically `test_convert_to_simg_unaligned_holes` which covers the tricky edge case where data exists but isn't block-aligned.
- **[Best Practice]** Using `shutil.which("simg2img")` to conditionally run validation tests against the reference implementation is a great practice.

</details>

### ✅ Summary

- **Overall Assessment:** High Quality. The implementation is robust, well-tested, and correctly addresses the architectural goal of removing external dependencies.
- **Priority Issues:** None.
- **Minor Suggestions:** Optimize the `is_all_zeros` function in `aib/utils.py` to avoid Python-level iteration over binary data.