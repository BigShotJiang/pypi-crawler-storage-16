"""Node.js debug adapter implementation."""
