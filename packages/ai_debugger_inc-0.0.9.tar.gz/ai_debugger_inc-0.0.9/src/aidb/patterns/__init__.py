"""Core design pattern helpers for aidb core."""

from .base import Obj

__all__ = [
    "Obj",
]
