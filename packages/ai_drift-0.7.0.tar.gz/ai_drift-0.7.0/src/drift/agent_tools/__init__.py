"""Agent implementations for drift analysis."""
