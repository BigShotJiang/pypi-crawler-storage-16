"""Entry point for running drift as a module (python -m drift)."""

from drift.cli.main import main

if __name__ == "__main__":
    main()
