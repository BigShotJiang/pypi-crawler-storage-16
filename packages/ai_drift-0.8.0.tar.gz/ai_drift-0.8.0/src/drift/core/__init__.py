"""Core functionality for drift analysis."""
