from .config import setup_swagger, TAGS_METADATA

__all__ = ['setup_swagger', 'TAGS_METADATA']
