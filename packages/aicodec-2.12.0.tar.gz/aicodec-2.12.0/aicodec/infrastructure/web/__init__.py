# aicodec/infrastructure/web/__init__.py
