__title__ = "aidbox-python-sdk"
__version__ = "0.1.24"
__author__ = "beda.software"
__license__ = "None"
__copyright__ = "Copyright 2024 beda.software"

# Version synonym
VERSION = __version__
