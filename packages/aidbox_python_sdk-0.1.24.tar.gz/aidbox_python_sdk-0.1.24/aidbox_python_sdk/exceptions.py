class AidboxSDKException(Exception):  # noqa: N818
    pass


class AidboxDBException(AidboxSDKException):
    pass
