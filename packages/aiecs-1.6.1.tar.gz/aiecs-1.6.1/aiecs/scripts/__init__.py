"""
Scripts for AIECS post-installation patches and utilities
"""
