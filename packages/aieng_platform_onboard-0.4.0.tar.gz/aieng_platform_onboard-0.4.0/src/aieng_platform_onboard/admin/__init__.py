"""Admin commands for aieng-platform-onboard."""

from aieng_platform_onboard.admin.cli import main as admin_main


__all__ = ["admin_main"]
