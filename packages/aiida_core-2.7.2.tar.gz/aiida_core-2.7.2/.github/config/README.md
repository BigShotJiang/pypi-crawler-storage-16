# AiiDA configuration files

This folder contains configuration files for AiiDA computers, codes etc.

 - `slurm_rsa`: private key that provides access to the `slurm-ssh` container
