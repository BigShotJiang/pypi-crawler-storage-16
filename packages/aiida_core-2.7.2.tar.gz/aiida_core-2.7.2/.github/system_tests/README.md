This folder contains tests that must be run directly in the GitHub Actions container environment.

This is usually because they require an active daemon or have other specific environment requirements.
