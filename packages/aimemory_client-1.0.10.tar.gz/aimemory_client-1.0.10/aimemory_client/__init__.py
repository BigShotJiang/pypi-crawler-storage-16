__version__ = "1.0.10"

from aimemory_client.client import AIMemoryClient

__all__ = [
    "AIMemoryClient",
    # "AsyncAIMemoryClient",
    "__version__",
]
