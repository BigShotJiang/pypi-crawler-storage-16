"""Layer visualization handlers."""
