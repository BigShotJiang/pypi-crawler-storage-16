"""Special analysis handlers for biological image processing."""

