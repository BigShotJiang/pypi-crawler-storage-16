__title__ = "aiochlite"

__author__ = "darkstussy"

__copyright__ = f"Copyright (c) 2025 {__author__}"
