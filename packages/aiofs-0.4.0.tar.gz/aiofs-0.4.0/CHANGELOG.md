## v0.4.0 (2025-12-12)

### Feat

- **cicd**: create pipeline for gitlab
- add expiry to redis fs
- add ls method to file system

### Fix

- **ci**: error verifing docker certificate
- **ci**: error verifing docker certificate
- **ci**: correct test executable
- **ci**: add hostname to pipeline
- **ci**: add docker compose
- **ci**: add docker compose
- **ci**: avoid run rm empty in docker
- **cicd**: ammend test stage
- all the tests have passed
- incorrect filtering of list os files
- apply prefix and sufix to ls
- upload to version ls command

### Refactor

- use test containers to setup infra
- replace match function by fnmatch estandar
