class NotSetType:
    def __repr__(self) -> str:
        return "NOTSET"
