from .func import compiled

__all__ = ("compiled",)
