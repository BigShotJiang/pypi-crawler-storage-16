import logging

webhook = logging.getLogger("aiosend.webhook")
polling = logging.getLogger("aiosend.polling")
client = logging.getLogger("aiosend.client")
