=====
Enums
=====

.. automodule:: aiosend.enums
   :members:
   :undoc-members:
   :show-inheritance: