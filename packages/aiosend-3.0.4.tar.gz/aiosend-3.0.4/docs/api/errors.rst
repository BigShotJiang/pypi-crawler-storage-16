======
Errors
======

.. automodule:: aiosend.exceptions
    :members:
    :show-inheritance: