Polling configuration
---------------------
You can configure your own polling configuration.

.. autoclass:: aiosend.polling.PollingConfig
    :members:

.. literalinclude:: ../../examples/polling_config.py

.. autoclass:: aiosend.polling.PollingManager
    :members: