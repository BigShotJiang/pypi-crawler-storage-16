================
pyTelegramBotAPI
================


Usage example with `pyTelegramBotAPI <https://pytba.readthedocs.io/en/latest/>`_
--------------------------------------------------------------------------------

.. literalinclude:: ../../examples/pytba.py

Preview
-------

.. image:: ../_static/payment_handle_example.png