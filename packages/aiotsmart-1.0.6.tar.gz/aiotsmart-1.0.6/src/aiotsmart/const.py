"""Constants for tsmart."""

MESSAGE_HEADER = "=BBBB"
UDP_PORT = 1337
