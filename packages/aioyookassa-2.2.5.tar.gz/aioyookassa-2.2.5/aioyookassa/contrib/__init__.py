"""
Contrib module with optional utilities.
"""

from aioyookassa.contrib.webhook_server import WebhookServer

__all__ = ["WebhookServer"]
