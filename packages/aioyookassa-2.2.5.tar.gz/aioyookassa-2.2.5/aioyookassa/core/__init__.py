"""
YooKassa core module.

This module contains the main client and API implementations.
"""

from .client import YooKassa

__all__ = ["YooKassa"]
