"""Tests for aipartnerupflow API executor"""

