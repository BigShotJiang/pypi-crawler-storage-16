"""Tests for SSH executor"""

