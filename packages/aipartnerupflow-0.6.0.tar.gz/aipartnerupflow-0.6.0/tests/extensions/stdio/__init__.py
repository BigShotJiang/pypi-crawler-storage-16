"""
Tests for Stdio extension module
"""

