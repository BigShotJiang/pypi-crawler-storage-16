"""CLI package - Typer-based command-line interface for aiprofile."""

from cli.main import app

__all__ = ["app"]
