"""Python-specific profilers."""

from .scalene_profiler import ScaleneProfiler

__all__ = [
    "ScaleneProfiler",
]
