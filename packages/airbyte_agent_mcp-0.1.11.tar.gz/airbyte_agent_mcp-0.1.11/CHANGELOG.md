# Changelog

## [0.1.11] - 2025-12-11
- Updated airbyte-agent-mcp package
- Source commit: 11427ac3
- SDK version: 0.1.0

## [0.1.10] - 2025-12-11
- Updated airbyte-agent-mcp package
- Source commit: bdd5df6d
- SDK version: 0.1.0

## [0.1.9] - 2025-12-11
- Updated airbyte-agent-mcp package
- Source commit: ec3dcc78
- SDK version: 0.1.0

## [0.1.8] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: 334e113b
- SDK version: 0.1.0

## [0.1.7] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: 30c77ce6
- SDK version: 0.1.0

## [0.1.6] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: 92482e66
- SDK version: 0.1.0

## [0.1.5] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: b3c6a176
- SDK version: 0.1.0

## [0.1.4] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: b3c6a176
- SDK version: 0.1.0

## [0.1.3] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: b3c6a176
- SDK version: 0.1.0

## [0.1.2] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: b3c6a176
- SDK version: 0.1.0

## [0.1.1] - 2025-12-10
- Updated airbyte-agent-mcp package
- Source commit: b3c6a176
- SDK version: 0.1.0

## [0.1.0] - 2025-12-09
- Updated airbyte-agent-mcp package
- Source commit: b3c6a176
- SDK version: 0.1.0
