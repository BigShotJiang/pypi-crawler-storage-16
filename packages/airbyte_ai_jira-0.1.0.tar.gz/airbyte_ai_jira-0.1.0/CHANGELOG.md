# Changelog

## [0.1.0] - 2025-12-12
- Updated connector definition (YAML version 1.0.2)
- Source commit: 61d98c0a
- SDK version: 0.1.0
