# Changelog

## [0.1.3] - 2025-12-12
- Updated connector definition (YAML version 1.0.3)
- Source commit: 4d366cb5
- SDK version: 0.1.0

## [0.1.2] - 2025-12-12
- Updated connector definition (YAML version 1.0.2)
- Source commit: dc79dc8b
- SDK version: 0.1.0

## [0.1.1] - 2025-12-12
- Updated connector definition (YAML version 1.0.2)
- Source commit: 244fd1c6
- SDK version: 0.1.0

## [0.1.0] - 2025-12-12
- Updated connector definition (YAML version 1.0.1)
- Source commit: e71241ac
- SDK version: 0.1.0
