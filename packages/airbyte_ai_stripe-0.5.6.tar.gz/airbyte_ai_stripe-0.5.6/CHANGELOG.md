# Changelog

## [0.5.6] - 2025-12-11
- Updated connector definition (YAML version 0.1.0)
- Source commit: 8c06aa10
- SDK version: 0.1.0

## [0.5.5] - 2025-12-11
- Updated connector definition (YAML version 0.1.0)
- Source commit: 11427ac3
- SDK version: 0.1.0

## [0.5.4] - 2025-12-11
- Updated connector definition (YAML version 0.1.0)
- Source commit: bdd5df6d
- SDK version: 0.1.0

## [0.5.3] - 2025-12-11
- Updated connector definition (YAML version 0.1.0)
- Source commit: f2497f71
- SDK version: 0.1.0

## [0.5.2] - 2025-12-11
- Updated connector definition (YAML version 0.1.0)
- Source commit: 7d738be5
- SDK version: 0.1.0

## [0.5.1] - 2025-12-10
- Updated connector definition (YAML version 0.1.0)
- Source commit: 76636830
- SDK version: 0.1.0

## [0.5.0] - 2025-12-08
- Updated connector definition (YAML version 0.1.0)
- Source commit: f2ad5029
- SDK version: 0.1.0

## [0.4.0] - 2025-12-08
- Updated connector definition (YAML version 0.1.0)
- Source commit: 139b0b0d
- SDK version: 0.1.0

## [0.3.0] - 2025-12-05
- Updated connector definition (YAML version 0.1.0)
- Source commit: e96bed3d
- SDK version: 0.1.0

## [0.2.0] - 2025-12-05
- Updated connector definition (YAML version 0.1.0)
- Source commit: ed697b90
- SDK version: 0.1.0

## [0.1.23] - 2025-12-05
- Updated connector definition (YAML version 0.0.1)
- Source commit: 20618410
- SDK version: 0.1.0

## [0.1.22] - 2025-12-04
- Updated connector definition (YAML version 0.0.1)
- Source commit: 4a01e446
- SDK version: 0.1.0

## [0.1.21] - 2025-12-04
- Updated connector definition (YAML version 0.0.1)
- Source commit: 5ec76dde
- SDK version: 0.1.0

## [0.1.20] - 2025-12-04
- Updated connector definition (YAML version 0.0.1)
- Source commit: df32a458
- SDK version: 0.1.0

## [0.1.19] - 2025-12-04
- Updated connector definition (YAML version 0.0.1)
- Source commit: a506b369
- SDK version: 0.1.0

## [0.1.18] - 2025-12-03
- Updated connector definition (YAML version 0.0.1)
- Source commit: 92a39ab5
- SDK version: 0.1.0

## [0.1.17] - 2025-12-03
- Updated connector definition (YAML version 0.0.1)
- Source commit: 0ce38253
- SDK version: 0.1.0

## [0.1.16] - 2025-12-02
- Updated connector definition (YAML version 0.0.1)
- Source commit: c8e326d9
- SDK version: 0.1.0

## [0.1.15] - 2025-12-02
- Updated connector definition (YAML version 0.0.1)
- Source commit: ad0b961b
- SDK version: 0.1.0

## [0.1.14] - 2025-12-02
- Updated connector definition (YAML version 0.0.1)
- Source commit: 7153780a
- SDK version: 0.1.0

## [0.1.13] - 2025-12-02
- Updated connector definition (YAML version 0.0.1)
- Source commit: 01f71cad
- SDK version: 0.1.0

## [0.1.12] - 2025-12-02
- Updated connector definition (YAML version 0.0.4)
- Source commit: 236db7f0
- SDK version: 0.1.0

## [0.1.11] - 2025-12-02
- Updated connector definition (YAML version 0.0.3)
- Source commit: 4c17f060
- SDK version: 0.1.0

## [0.1.10] - 2025-12-02
- Updated connector definition (YAML version 0.0.3)
- Source commit: cd499acd
- SDK version: 0.1.0

## [0.1.9] - 2025-12-02
- Updated connector definition (YAML version 0.0.3)
- Source commit: 64df6a87
- SDK version: 0.1.0

## [0.1.8] - 2025-12-02
- Updated connector definition (YAML version 0.0.1)
- Source commit: f34b246f
- SDK version: 0.1.0

## [0.1.7] - 2025-12-02
- Updated connector definition (YAML version 0.0.1)
- Source commit: b261c3a2
- SDK version: 0.1.0

## [0.1.6] - 2025-11-27
- Updated connector definition (YAML version 0.0.1)
- Source commit: 702fd446
- SDK version: 0.1.0

## [0.1.5] - 2025-11-27
- Updated connector definition (YAML version 0.0.1)
- Source commit: d656a4a2
- SDK version: 0.1.0

## [0.1.4] - 2025-11-27
- Updated connector definition (YAML version 0.0.1)
- Source commit: 9afac212
- SDK version: 0.1.0

## [0.1.3] - 2025-11-27
- Updated connector definition (YAML version 0.0.1)
- Source commit: 9afac212
- SDK version: 0.1.0

## [0.1.2] - 2025-11-27
- Updated connector definition (YAML version 0.0.1)
- Source commit: c1700e5e
- SDK version: 0.1.0
- YAML version: 0.0.1

## [0.1.1] - 2025-11-26
- Updated connector definition (YAML version 0.0.1)
- Source commit: 5a3bf104
- SDK version: 0.1.0
- YAML version: 0.0.1

## [0.1.0] - 2025-11-26
- Updated connector definition (YAML version 0.0.1)
- Source commit: 5a3bf104
- SDK version: 0.1.0
- YAML version: 0.0.1
