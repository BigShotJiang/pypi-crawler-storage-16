# Copyright (c) 2025 Airbyte, Inc., all rights reserved.
"""Live tests module for running connector validation and regression tests.

This module provides tools for testing Airbyte connectors against live data
without using Dagger. It uses Docker SDK directly for container orchestration.
"""

from airbyte_ops_mcp.live_tests.models import (
    Command,
    ConnectorUnderTest,
    ExecutionResult,
    TargetOrControl,
)

__all__ = [
    "Command",
    "ConnectorUnderTest",
    "ExecutionResult",
    "TargetOrControl",
]
