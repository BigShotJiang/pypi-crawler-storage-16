def assure_serialization_compatibility(adapter, x):
    return x