OBSERVATION_COLLECTOR_TAG = 'obs-collector-wk'
OBSERVATION_STORAGE_TAG = 'obs-storage-wk'

DF_EVENT_ATTACHMENT_JOB_TAG = 'df-ev-attachment-wk'
DF_EVENT_ATTACHMENT_DESTINATION_TAG = 'df-attachment-wk'
RT_EVENT_DESTINATION_TAG = 'rt-trigger-wk'
RT_EMBEDDER_DESTINATION_TAG = 'rt-embedding-wk'

ENTITY_RECOGNITION_TAG = 'entity-recognition-wk'
LOG_STORAGE_TAG = 'log-storage-wk'
