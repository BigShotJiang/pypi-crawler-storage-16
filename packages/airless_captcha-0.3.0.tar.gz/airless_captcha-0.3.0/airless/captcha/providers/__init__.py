
from .two_captcha import Solver2CaptchaService

__all__ = [
    'Solver2CaptchaService'
]
