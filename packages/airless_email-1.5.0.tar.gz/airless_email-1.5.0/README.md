# airless-email

[![PyPI version](https://badge.fury.io/py/airless-email.svg)](https://badge.fury.io/py/airless-email)

airless-email were build to work with emails using [Airless](https://github.com/astercapital/airless) module.

Need to set `SECRET_SMTP` and `GCP_PROJECT` to use `GoogleEmailHook`

