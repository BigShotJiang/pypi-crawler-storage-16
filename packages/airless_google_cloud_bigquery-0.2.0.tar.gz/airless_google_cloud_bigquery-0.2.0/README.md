# airless-google-cloud-bigquery

[![PyPI version](https://badge.fury.io/py/airless-google-cloud-bigquery.svg)](https://badge.fury.io/py/airless-google-cloud-bigquery)

airless-google-cloud-bigquery were build to work with google cloud bigquery using [Airless](https://github.com/astercapital/airless) module.
