# airless-google-cloud-core

[![PyPI version](https://badge.fury.io/py/airless-google-cloud-core.svg)](https://badge.fury.io/py/airless-google-cloud-core)

airless-google-cloud-core [Airless](https://github.com/astercapital/airless) package with the main components to use airless in google cloud.
