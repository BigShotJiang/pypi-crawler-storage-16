# airless-google-cloud-secret-manager

[![PyPI version](https://badge.fury.io/py/airless-google-cloud-secret-manager.svg)](https://badge.fury.io/py/airless-google-cloud-secret-manager)

airless-google-cloud-secret-manager was built to work with secrets stored in google secret manager using [Airless](https://github.com/astercapital/airless) module.


Environment variable `GCP_PROJECT` is required