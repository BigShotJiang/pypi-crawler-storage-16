# airless-google-cloud-storage

[![PyPI version](https://badge.fury.io/py/airless-google-cloud-storage.svg)](https://badge.fury.io/py/airless-google-cloud-storage)

airless-google-cloud-storage was built to interact with google cloud storage using [Airless](https://github.com/astercapital/airless) module.
