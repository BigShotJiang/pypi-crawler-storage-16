# airless-google-cloud-vertexai

[![PyPI version](https://badge.fury.io/py/airless-google-cloud-vertexai.svg)](https://badge.fury.io/py/airless-google-cloud-vertexai)

airless-google-cloud-vertexai were build to work with generative models from google vertexai using [Airless](https://github.com/astercapital/airless) module.


Environment variable required:
- `GCP_PROJECT`
- `GCP_REGION`