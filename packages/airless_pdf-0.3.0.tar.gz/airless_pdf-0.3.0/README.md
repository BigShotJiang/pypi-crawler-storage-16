# airless-pdf

[![PyPI version](https://badge.fury.io/py/airless-pdf.svg)](https://badge.fury.io/py/airless-pdf)

airless-pdf were build to work with pdfs using [Airless](https://github.com/astercapital/airless) module.
