# airless-slack

[![PyPI version](https://badge.fury.io/py/airless-slack.svg)](https://badge.fury.io/py/airless-slack)

airless-slack was built to work with slack messages using [Airless](https://github.com/astercapital/airless) module.
