from .slack import (SlackHook)

__all__ = [
    'SlackHook'
]
