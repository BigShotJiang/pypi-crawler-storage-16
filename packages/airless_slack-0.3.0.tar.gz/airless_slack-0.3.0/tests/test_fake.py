
def test_fake():
    assert 1 == 1
