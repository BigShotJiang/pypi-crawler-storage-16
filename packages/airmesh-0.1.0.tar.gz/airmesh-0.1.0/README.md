#  airmesh

**airmesh** is a Python package that generates 3D wind-tunnel or
wind-domain meshes using `pybmesh`.\
It provides a simple, high-level API (`Airmesh`) that wraps your
internal mesh generators (`WindTunnel`, `WindDomainPolygon`) and exports
meshes directly to OpenFOAM format.

------------------------------------------------------------------------

##  Features

-   Simple high-level interface to build wind-tunnel domains\

-   Two mesh generation modes:
	**classical**  
    Uses the *WindTunnel* model: a digital wind tunnel made of **two parts**  
    (central fixed core + rotating outer domain).

	**advanced**  
    Uses *WindDomainPolygon*: a **single-block polygonal wind tunnel**,  
    designed to remain consistent for all wind directions.

-   Supports refinement levels, core region settings, domain extrusion,
    multiple wind directions, etc.

-   Direct export to OpenFOAM:

    ``` python
    mesh.write(path=".")
    ```

-   Built on top of **pybmesh**, **scikit-spatial**, and **gmsh**

------------------------------------------------------------------------

##  Installation

``` bash
pip install airmesh
```

or when developing locally:

``` bash
pip install -e .
```

------------------------------------------------------------------------

##  Usage Example

``` python
from airmesh import Airmesh

mesh = Airmesh(
    D=1200,         # diameter of area of interest
    hc=150,         # max height
    hd=600,         # domain height
    dx=2,           # element size in core
    Lc=400,         # core length
    nwdir=16,       # number of wind directions
    vt=[0, 0, 0],   # translation vector
    refLvls=[2, 2], # refinement schedule: two levels, each coarsening by a factor of 2
    optc=0,         # 0=diamond, 1=square, 2=circle
    optm=1,         # 0=simple extrude, 1=advanced
    type="classical",
)

mesh.compute()
mesh.write(path="output/")
```

This will generate the OpenFOAM `blockMeshDict` and mesh files inside:

    output/Mesh/

------------------------------------------------------------------------

##  Project Layout

    airmesh/
        src/airmesh/
            api.py
            blockmesh.py
            fmesh.py
            ...

------------------------------------------------------------------------

##  Requirements

Installed automatically:
-   `pybmesh`


------------------------------------------------------------------------

##  License

MIT License\
Copyright © 2024
