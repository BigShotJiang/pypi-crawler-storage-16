# src/airmesh/api.py

from .blockmesh import WindTunnel, WindDomainPolygon


class Airmesh:
    """
    High-level wrapper around WindTunnel / WindDomainPolygon.
    """

    def __init__(
        self,
        D,           # diameter of area of interest
        hc,          # maximum height in model
        hd,          # vertical size of the domain
        dx,          # size of element in core area
        Lc,          # core length
        nwdir=16,    # number of wind directions
        vt=None,     # translation vector
        refLvls=None,
        optc=0,      # 0 = diamond, 1 = square, 2 = circle
        optm=1,      # 0 = simple extrude, 1 = advanced
        type="classical",  # "classical" or "advanced"
        **kwargs,    # extra params passed to underlying mesh class if needed
    ):
        if vt is None:
            vt = [0, 0, 0]
        if refLvls is None:
            refLvls = [2, 2]

        self.type = type

        common_args = dict(
            Φd=D,
            Φc=Lc,
            hc=hc,
            Δx=dx,
            hd=hd,
            nwdir=nwdir,
            vt=vt,
            refLvls=refLvls,
            optc=optc,
            optm=optm,
            **kwargs,
        )

        if type == "classical":
            self._mesh = WindTunnel(**common_args)
        else:
            self._mesh = WindDomainPolygon(**common_args)

    def compute(self, **kwargs):
        """
        Simply forwards to the underlying mesh.compute().
        You can keep your existing signature if needed.
        """
        return self._mesh.compute(**kwargs)

    def write(self, path=".", **kwargs):
        """
        Forwards to the underlying mesh.write(path=...).
        """
        return self._mesh.write(path=path, **kwargs)

    @property
    def mesh(self):
        """
        Access to the underlying mesh object if needed.
        """
        return self._mesh
