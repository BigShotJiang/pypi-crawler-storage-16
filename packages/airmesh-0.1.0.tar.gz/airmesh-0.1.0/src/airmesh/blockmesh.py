from pybmesh import *
from .fbmesh import *
from .fmaths import *
from typing import Iterable, Callable, Dict, List, Tuple
from dataclasses import dataclass
import math

class WindDomainPolygon:
    def __init__(self, Φd: float, Φc: float, hc: float, Δx: float,
                     hd: float = 0, nwdir: int = 12, vt: list = [0, 0 ,0 ],
                     refLvls: list = [], 
                     optc: int = 0, optm: int = 0):
    
        self.rext = 0.5*Φd + 6*hc
        self.rint = 0.5*Φc
        self.hc = hc
        self.hd = max(hd, 5*hc)
        self.nwdir = nwdir
        self.refLvls = refLvls
        self.optc = optc
        self.optm = optm
        self.vt   = vt
        self.Δx = Δx
        self.nsides = (4 * self.nwdir) // math.gcd(4, self.nwdir)
        
        self.__compute_adjusted_esize()

    

    def compute(self, show = False):
        print(r"...start meshing")  
        # simple extrude
        if self.optm == 0:
            _mesh = self._build_from_extrusion()
        else:
            _mesh = self._build_advanced()

        print("...>...build boundaries")
        _mesh.translate(*self.vt)
        ground, top, sides = self._boundary(_mesh)
        self.mesh = MeshComponent()
        self.mesh.add_internal(_mesh,'air')
        self.mesh.add_boundary(ground)
        self.mesh.add_boundary(top)
        for i, patch in enumerate(sides):
            self.mesh.add_boundary(patch, f"side{i}")
        self.mesh.compute()

        self.walls_patches  = {"ground":"wall"}
        print(r"...done meshing") 
        print(f"...mesh has {nbEl(_mesh)} 3D elements")
        if show : plot(self.mesh)
        
    def write(self,path='.'):
        path = path+'/Mesh'
        WriteFOAM(self.mesh,  path, self.walls_patches )

    def _as_vtk_dataset(self, obj):
        """
        Return a VTK dataset from either:
          - a VTK object (has GetBounds)
          - a pybmesh Surface with ._ugrid
          - a pybmesh Surface with .get_vtk_unstructured_grid()
        """
        # Already a VTK dataset?
        if hasattr(obj, "GetBounds") and callable(obj.GetBounds):
            return obj
        # pybmesh Surface internals
        if hasattr(obj, "_ugrid") and obj._ugrid is not None:
            ds = obj._ugrid
            if hasattr(ds, "GetBounds"):
                return ds
        if hasattr(obj, "get_vtk_unstructured_grid") and callable(obj.get_vtk_unstructured_grid):
            ds = obj.get_vtk_unstructured_grid()
            if hasattr(ds, "GetBounds"):
                return ds
        raise TypeError("mesh_boundaries must be a VTK dataset or a Surface with ._ugrid / .get_vtk_unstructured_grid().")

    def __compute_adjusted_esize(self):
        self.n = compute_nx_for_polygone(self.rint, self.Δx, self.nsides, self.refLvls)
        self._Δxc = self.rint/self.n
        self._Δzmin = min(line_start_size_from_n(self._Δxc), 0.5)

        print(r"...adjust Δx to meet with design criterions")
        print(f"...new Δx = {self.rint/self.n:0.2f}") 
    

    def _get_z_bounds(self, vtk_ds):
        """Read zmin/zmax from a VTK dataset; falls back to points if needed."""
        if hasattr(vtk_ds, "GetBounds"):
            b = vtk_ds.GetBounds()  # (xmin,xmax, ymin,ymax, zmin,zmax)
            if b and len(b) == 6 and all(math.isfinite(v) for v in b[4:6]):
                return b[4], b[5]
        # Fallback: compute from points
        pts = vtk_ds.GetPoints() if hasattr(vtk_ds, "GetPoints") else None
        if pts is None:
            raise ValueError("Could not get Z bounds: dataset has no bounds and no points.")
        n = pts.GetNumberOfPoints()
        if n == 0:
            raise ValueError("Dataset has no points.")
        zmin = float("inf")
        zmax = float("-inf")
        for i in range(n):
            _, _, z = pts.GetPoint(i)
            if z < zmin: zmin = z
            if z > zmax: zmax = z
        if not (math.isfinite(zmin) and math.isfinite(zmax)):
            raise ValueError("Failed to compute finite Z bounds from points.")
        return zmin, zmax   

    def _build_side_planes_for_extruded_regular_polygon(self,
        mesh_boundaries,                 # vtkUnstructuredGrid or vtkPolyData of the volume boundaries
        n_sides: int,
        rext: float,                     # outer apothem (center-to-edge distance)
        *,
        tol : float = 1e-3,
        theta_deg: float = 0.0,          # CLOCKWISE rotation about +Z
        center: Tuple[float, float, float] = (0.0, 0.0, 0.0),
        edge_span_factor: float = 0.9,   # how far p2 runs along the edge (0..1 of half-edge length)
        pid: int = 10
    ) -> List[Dict]:
        """
        Returns one plane per lateral side. Indexing rules:
          - Side 0 is the side with outward normal +Y (lies on y = ymax) *before rotation*.
          - Sides increase in CLOCKWISE order.
          - theta_deg rotates the polygon CLOCKWISE.
    
        Plane dicts are compatible with pm.extract_point(...):
            {"type":"plane", "p1":Point(...), "p2":Point(...), "p3":Point(...), "distance":1e-3}
        """ 
    
        vtk_ds = self._as_vtk_dataset(mesh_boundaries)
        zmin, zmax = self._get_z_bounds(vtk_ds)
        if abs(zmax - zmin) < 1e-14:
            raise ValueError("Mesh appears to be 2D or has zero thickness in Z.")
    
        cx, cy, _ = center
    
        # Edge length -> to place p2 along the edge direction
        R = rext / math.cos(math.pi / n_sides)
        edge_len = 2.0 * R * math.sin(math.pi / n_sides)
        half_edge = 0.5 * edge_len * edge_span_factor
    
        # Base orientation:
        #   side 0 outward normal = +Y -> phi0 = +pi/2
        #   clockwise indexing -> -2*pi/N per step
        #   clockwise rotation theta -> subtract theta
        phi0 = math.pi * 0.5
        theta_cw = math.radians(theta_deg)
    
        planes: List[Dict] = []
        for k in range(n_sides):
            phi = phi0 - 2.0 * math.pi * k / n_sides - theta_cw
            nx, ny = math.cos(phi), math.sin(phi)       # outward normal (unit)
            tx, ty = ny, -nx                            # clockwise tangent (rotate by -90°)
    
            x_mid = cx + rext * nx
            y_mid = cy + rext * ny
            z0, z1 = zmin, zmax
    
            p1 = Point(x_mid, y_mid, z0)                                    # bottom mid-side
            p2 = Point(x_mid + tx * half_edge, y_mid + ty * half_edge, z0)  # bottom along edge
            p3 = Point(x_mid, y_mid, z1)                                    # top mid-side
    
            plane_def = {
                "type": "plane",
                "p1": p1,
                "p2": p2,
                "p3": p3,
                "distance": tol,
                "pid": pid,
                "side_index": k
            }
            planes.append(plane_def)
    
        return planes   
              
    def _boundary(self, mesh):
        s=getBoundaries(mesh)
        vtk_ds = self._as_vtk_dataset(s)
        zmin, zmax = self._get_z_bounds(vtk_ds)
        #zmin
        PlaneDict1={
            "type": "plane",
            "p1": (self.vt[0]  ,self.vt[1]  ,zmin),
            "p2": (self.vt[0]+1,self.vt[1]  ,zmin),
            "p3": (self.vt[0]  ,self.vt[1]+1,zmin),
            "distance": 1e-5
        }
        zmin_pts = extract_point(s, PlaneDict1, pid = 10)
        zmin = extract_element(s, points=zmin_pts, strict = True)
        
        #zmax
        PlaneDict2={
            "type": "plane",
            "p1": (self.vt[0]  ,self.vt[1]  ,zmax),
            "p2": (self.vt[0]+1,self.vt[1]  ,zmax),
            "p3": (self.vt[0]  ,self.vt[1]+1,zmax),
            "distance": 1e-5
        }
        zmax_pts = extract_point(s, PlaneDict2, pid = 11)
        zmax = extract_element(s, points=zmax_pts, strict = True)
        
        #zmax
        planes = self._build_side_planes_for_extruded_regular_polygon(s,n_sides=self.nsides,rext=self.rext)
        sides = []
        for p in planes : 
            extracted_pts = extract_point(s, p, pid=10)
            sides.append(extract_element(s, points=extracted_pts, strict = True))
        
        return zmin, zmax, sides
    
    def _build_from_extrusion(self):
        print("...>...mesh surfaces")
        surf = build_polygonial_surface(
                rext = self.rext,
                rint = self.rint,
                n    = self.n,
                optc = self.optc,
                nsides = self.nsides,
                refLvls = self.refLvls,
                tol = 1e-4
            )
        
        print("...>...fuse surfaces")
        surfA = rotate(surf, axis="z", angle = 90)
        surf  = fuse(surf,surfA, verbose = False, tol = 1e-3, pid = 1)
        surfA = rotate(surf, axis="z", angle = 180)
        surf  = fuse(surf,surfA, verbose = False, tol = 1e-3, pid = 1)

        
        print("...>...mesh volumes")
        nz0, gradz0, h0, _ = line_grading_info(size_first = self._Δzmin, size_last = self._Δxc, growing_ratio = 1.25, progression = "geometric")
        nz1 = int((self.hc-h0) / self._Δxc)
        nz2, gr2, gradz2 = solve_n_and_ratio(first_size = self._Δxc, length = (self.hd-self.hc), grading_target = 10, 
                                             grmin = 1.1, grmax = 1.3, nmin = 5, progression = "geometric")
        

        L_extr = make_vertical_line(x=0 ,y=0, details = [
                {"z": [0, h0], "n": nz0, "grading": gradz0, "progression": "geometric"},
                {"z": [h0, self.hc],      "n": nz1},
                {"z": [self.hc, self.hd], "n": nz2, "grading": gradz2, "progression": "geometric"},
            ]
            )
        
        Bmesh = extrudeLinear(surf, L_extr, pid = 1)
        Bmesh.correct_orientation()

        return Bmesh
    
    def _build_advanced(self): 
        
        _mesh = build_advanced_polygonial_mesh(
                rext = self.rext,
                rint = self.rint, 
                hc = self.hc, 
                hd = self.hd, 
                n = self.n,
                Δxc = self._Δxc, 
                Δzm = self._Δzmin, 
                optc = self.optc,
                nsides = self.nsides, 
                grz = 1.1,
                refLvls = self.refLvls,
            )

        mA = syme(_mesh,plane='yz')
        mA.reverse_orientation()
        _mesh  = fuse(_mesh,mA, verbose = False, tol = 1e-4, pid = 1)
        mA = syme(_mesh,plane='zx')
        mA.reverse_orientation()
        _mesh  = fuse(_mesh,mA, verbose = False, tol = 1e-4, pid = 1)

        return _mesh

class WindTunnel(WindDomainPolygon):
    def __init__(self, Φd: float, Φc: float, hc: float, Δx: float,
                     hd: float = 0, nwdir: int = 12, vt: list = [0, 0 ,0 ],
                     refLvls: list = [], 
                     optc: int = 0, optm: int = 0):
    
        super().__init__(Φd = Φd, Φc = Φc, hc = hc, Δx = Δx, 
                         hd = hd, nwdir = nwdir, vt = vt,
                         refLvls = refLvls, optc = optc, optm = optm)
        
        self.rext = 0.5*Φd


    
    def compute(self, show = False):
        print(r"...start meshing") 
        print(r".....fixed area") 
        # simple extrude
        if self.optm == 0:
            self._fmesh = self._build_from_extrusion()
        else:
            self._fmesh = self._build_advanced()

        self._fmesh.translate(*self.vt)
        ground1, top1, hole1 = self._boundary_fixed_area()
        
        print(r".....mobile area") 
        self._mmesh = self._build_tunnel()
        self._mmesh.translate(*self.vt)
        ground2, top2, inlet, outlet, front, back, hole2 = self._boundary_mobile_area()
        
        print(r".....make components") 
        self.fmesh = MeshComponent()
        self.fmesh.add_internal(self._fmesh,'fixedZone')
        self.fmesh.add_boundary(ground1)
        self.fmesh.add_boundary(top1)
        self.fmesh.add_boundary(hole1)
        self.walls_fpatches  = {"ground1":"wall"}
        self.fmesh.compute()
    
        self.mmesh = MeshComponent()
        self.mmesh.add_internal(self._mmesh,'mobileZone')
        self.mmesh.add_boundary(ground2)
        self.mmesh.add_boundary(top2)
        self.mmesh.add_boundary(hole2)
        self.mmesh.add_boundary(inlet)
        self.mmesh.add_boundary(outlet)
        self.mmesh.add_boundary(front)
        self.mmesh.add_boundary(back)
        self.walls_mpatches  = {"ground2":"wall"}
        self.mmesh.compute()
        
        if show : plot(self.fmesh, self.mmesh)
 
    def __compute_adjusted_esize(self):
        self.n = compute_nx_for_polygone(self.rint, self.Δx, self.nsides, self.refLvls)
        self._Δxc = self.rint/self.n
        self._Δzmin = min(line_start_size_from_n(self._Δxc), 0.5)

        print(r"...adjust Δx to meet with design criterions")
        print(f"...new Δx = {self.rint/self.n:0.2f}") 
    
    
    def _build_tunnel(self):
        print("...>...build mesh")
        prod = reduce(mul, self.refLvls, 1)
        n = self.n // prod

        surf = build_exterior_surface(
                rint = self.rext,
                rext = self.rext + 6 * self.hc,
                n    = n,
                nsides = self.nsides,
            )

        LDict={
                "type": "line",
                "p1": (self.rext,0,0),
                "p2": (self.rext,0,1),
                "distance": 1e-5
            }
        
        lextr_pts = extract_point(self._fmesh, LDict, pid = 11)
        pts, _ = order_points(lextr_pts.coords)
        L1 = PolyLine(*pts,n=1,pid=5)
        
        Bmesh = extrudeLinear(surf, L1, pid = 2)

        return Bmesh
    
    def _boundary_fixed_area(self):
        print("...>...build boundaries")
        s = getBoundaries(self._fmesh)
        vtk_ds = self._as_vtk_dataset(s)
        zmin, zmax = self._get_z_bounds(vtk_ds)
        #zmin
        PlaneDict1={
            "type": "plane",
            "p1": (self.vt[0]  ,self.vt[1]  ,zmin),
            "p2": (self.vt[0]+1,self.vt[1]  ,zmin),
            "p3": (self.vt[0]  ,self.vt[1]+1,zmin),
            "distance": 1e-5
        }
        zmin_pts = extract_point(s, PlaneDict1, pid = 10)
        zmin = extract_element(s, points=zmin_pts, strict = True)
        
        #zmax
        PlaneDict2={
            "type": "plane",
        
            "p1": (self.vt[0]  ,self.vt[1]  ,zmax),
            "p2": (self.vt[0]+1,self.vt[1]  ,zmax),
            "p3": (self.vt[0]  ,self.vt[1]+1,zmax),
            "distance": 1e-5
        }
        zmax_pts = extract_point(s, PlaneDict2, pid = 11)
        zmax = extract_element(s, points = zmax_pts, strict = True)
        
        hole = remove(s, zmin)
        hole = remove(hole, zmax)
        
        return zmin, zmax, hole
    
    def _boundary_mobile_area(self):
        print("...>...build boundaries")
        s=getBoundaries(self._mmesh)
        vtk_ds = self._as_vtk_dataset(s)
        zmin, zmax = self._get_z_bounds(vtk_ds)
        #zmin
        PlaneDict1={
            "type": "plane",
            "p1": (self.vt[0]  ,self.vt[1]  ,zmin),
            "p2": (self.vt[0]+1,self.vt[1]  ,zmin),
            "p3": (self.vt[0]  ,self.vt[1]+1,zmin),
            "distance": 1e-5
        }
        zmin_pts = extract_point(s, PlaneDict1, pid = 10)
        zmin = extract_element(s, points=zmin_pts, strict = True)
        
        #zmax
        PlaneDict2={
            "type": "plane",
            "p1": (self.vt[0]  ,self.vt[1]  ,zmax),
            "p2": (self.vt[0]+1,self.vt[1]  ,zmax),
            "p3": (self.vt[0]  ,self.vt[1]+1,zmax),
            "distance": 1e-5
        }
        zmax_pts = extract_point(s, PlaneDict2, pid = 11)
        zmax = extract_element(s, points=zmax_pts, strict = True)
        
        #inlet
        PlaneDict3={
            "type": "plane",
            "p1": (self.vt[0]    ,self.vt[1]+self.rext+6*self.hc  ,self.vt[2]),
            "p2": (self.vt[0]+1  ,self.vt[1]+self.rext+6*self.hc  ,self.vt[2]),
            "p3": (self.vt[0]+1  ,self.vt[1]+self.rext+6*self.hc  ,self.vt[2]+1),
            "distance": 1e-5
        }
        inlet_pts = extract_point(s, PlaneDict3, pid = 11)
        inlet = extract_element(s, points=inlet_pts, strict = True)
        
        #outlet
        PlaneDict4={
            "type": "plane",
            "p1": (self.vt[0]    ,self.vt[1]-self.rext-18*self.hc  ,self.vt[2]),
            "p2": (self.vt[0]+1  ,self.vt[1]-self.rext-18*self.hc  ,self.vt[2]),
            "p3": (self.vt[0]+1  ,self.vt[1]-self.rext-18*self.hc  ,self.vt[2]+1),
            "distance": 1e-5
        }
        outlet_pts = extract_point(s, PlaneDict4, pid = 11)
        outlet = extract_element(s, points=outlet_pts, strict = True)
       
        #front
        PlaneDict5={
            "type": "plane",
            "p1": (self.vt[0]-self.rext-6*self.hc  ,self.vt[1]  ,self.vt[2]),
            "p2": (self.vt[0]-self.rext-6*self.hc  ,self.vt[1]+1  ,self.vt[2]),
            "p3": (self.vt[0]-self.rext-6*self.hc  ,self.vt[1]+1  ,self.vt[2]+1),
            "distance": 1e-5
        }
        front_pts = extract_point(s, PlaneDict5, pid = 11)
        front = extract_element(s, points=front_pts, strict = True)

        #back
        PlaneDict6={
            "type": "plane",
            "p1": (self.vt[0]+self.rext+6*self.hc  ,self.vt[1]  ,self.vt[2]),
            "p2": (self.vt[0]+self.rext+6*self.hc  ,self.vt[1]+1  ,self.vt[2]),
            "p3": (self.vt[0]+self.rext+6*self.hc  ,self.vt[1]+1  ,self.vt[2]+1),
            "distance": 1e-5
        }
        back_pts = extract_point(s, PlaneDict6, pid = 11)
        back = extract_element(s, points=back_pts, strict = True)
        
        #hole2
        hole = remove(s, zmin)
        hole = remove(hole, zmax)
        hole = remove(hole, inlet)
        hole = remove(hole, outlet)
        hole = remove(hole, front)
        hole = remove(hole, back)
        
        return zmin, zmax, inlet, outlet, front, back, hole
    
    def write(self,path='.'):
        fixedpath  = path+'/Mesh/02'
        mobilepath = path+'/Mesh/01'
        WriteFOAM(self.mmesh,  mobilepath, self.walls_mpatches )
        WriteFOAM(self.fmesh,  fixedpath, self.walls_fpatches )
