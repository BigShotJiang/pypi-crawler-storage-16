import math
import numpy as np
from functools import reduce
from typing import Iterable, Optional, Callable, Dict, List, Tuple
from dataclasses import dataclass


class RadialGrader:
    """
    Compute radial divisions and geometric grading to match target inner/outer sizes.

    Parameters set on the instance (inner_mode, pad_in, pad_out, search_span) mirror
    the original function's keyword arguments for identical behavior.
    """

    def __init__(
        self,
        inner_mode: str = "cartesian",
        pad_in: float = 1.0,
        pad_out: float = 1.0,
        search_span: int = 6,
    ) -> None:
        self.inner_mode = inner_mode
        self.pad_in = pad_in
        self.pad_out = pad_out
        self.search_span = search_span

    def compute_nr_and_grading(
        self,
        rint: float,
        rext: float,
        nx: int,
        nr: Optional[int] = None,
    ) -> Tuple[int, float, Dict]:
        """
        Choose radial divisions `nr` and geometric grading to match inner/outer target sizes.

        If `nr` is provided, use it directly (returning associated grading and details).
        Otherwise, search around an isometric guess to minimize mismatch at inner/outer rims.

        Returns
        -------
        (nr, grading, details) : tuple[int, float, dict]
        """
        assert rext > rint > 0 and nx >= 1

        s_in, s_out = self.__targets(rint, rext, nx)
        dtheta = math.pi / (4.0 * nx)

        # If user forced `nr`, honor it and compute derived quantities.
        if nr is not None:
            sol = self._eval(nr, rint, rext, s_in, s_out, dtheta)
            return sol["nr"], sol["grading"], sol

        # Seed around "isometric" guess (q ~ 1 + dtheta)
        q_iso = 1.0 + dtheta
        n_star = max(1.0, math.log(rext / rint) / math.log(q_iso))
        seeds = [max(1, int(math.floor(n_star))), max(1, int(math.ceil(n_star)))]

        best: Optional[Dict] = None
        tried: set[int] = set()

        for base in seeds:
            for k in range(-self.search_span, self.search_span + 1):
                N = max(1, base + k)
                if N in tried:
                    continue
                tried.add(N)

                sol = self._eval(N, rint, rext, s_in, s_out, dtheta)

                # Keep the original scoring behavior and penalties
                penalty = (0 if sol["ok_in"] else 1_000) + (0 if sol["ok_out"] else 1_000)
                score = penalty + sol["err"] + 0.1 * abs(sol["iso"] - 1.0)
                sol["score"] = score

                if best is None or score < best["score"]:
                    best = sol

        # mypy/mind: best cannot be None here because seeds & ranges ensure at least one eval
        return best["nr"], best["grading"], best  # type: ignore[index]

    # ---------- Private helpers ----------

    def __targets(self, rint: float, rext: float, nx: int) -> Tuple[float, float]:
        """
        Target edge lengths at inner/outer radii for one quadrant.

        Returns
        -------
        (s_in, s_out) : tuple[float, float]
            Desired chord/segment lengths to compare against radial steps.
        """
        if self.inner_mode == "arc":
            s_in = (math.pi * rint) / (4.0 * nx)  # chord length along inner arc
        else:
            s_in = rint / nx                      # cartesian inner edge
        s_out = (math.pi * rext) / (4.0 * nx)      # chord length along outer arc
        return self.pad_in * s_in, self.pad_out * s_out

    def _eval(
        self,
        N: int,
        rint: float,
        rext: float,
        s_in: float,
        s_out: float,
        dtheta: float,
    ) -> Dict:
        """
        Evaluate one candidate `N` and return the same diagnostic dictionary
        as in the original implementation.
        """
        q = (rext / rint) ** (1.0 / N)          # per-step radial ratio
        dr0 = rint * (q - 1.0)                  # first radial step
        drL = rext * (q - 1.0)                  # last radial step
        grading = q ** (N - 1)                  # total progression across band
        iso = (q - 1.0) / dtheta                # compare against angular spacing

        err = (dr0 / s_in - 1.0) ** 2 + (drL / s_out - 1.0) ** 2
        ok_in = dr0 + 1e-12 >= s_in
        ok_out = drL + 1e-12 >= s_out

        return {
            "nr": N,
            "q": q,
            "grading": grading,
            "dr0": dr0,
            "dr_last": drL,
            "s_in": s_in,
            "s_out": s_out,
            "iso": iso,
            "ok_in": ok_in,
            "ok_out": ok_out,
            "err": err,
        }


                
                    
                    

        

        
