from pybmesh import * 
from pybmesh import syme, fuse, plot
from .fmaths import *
import math
from scipy.optimize import linear_sum_assignment
from numpy.linalg import norm
import numpy as np
import vtk
import sys

class CoreMesh():
    def __init__(self, r: float, n: int = 2, opt: int = 0, nsides: int = 0):
        self.r = r
        self.n = n
        self.opt = opt
        self.nsides = nsides
        
        self.mesh =  self.__build()
        
    def __build(self):
        if self.r <= 0:
            raise ValueError("self.r must be > 0")
        if self.n <= 0:
            raise ValueError("self.n must be > 0")
    
        # Base points (pid=1)
        P1 = Point(0,  self.r, 0, pid=1)   # top
        P3 = Point( self.r, 0, 0, pid=1)   # right
        P5 = Point(0, -self.r, 0, pid=1)   # bottom
        P6 = Point(0,  0, 0, pid=1)   # center
    
        if self.opt == 1:
            P2 = Point(self.r,  self.r, 0, pid=1)
            P4 = Point(self.r, -self.r, 0, pid=1)
        elif self.opt == 2:
            # For circle we still need P2 (quarter point) to define the arc
            c45 = math.cos(math.radians(45.0))
            s45 = math.sin(math.radians(45.0))
            P2 = Point(self.r * c45, self.r * s45, 0, pid=1)
            P4 = Point(self.r * c45, -self.r * s45, 0, pid=1)
        else:
            # default "diamond" (45° corner on the right side)
            c45 = math.cos(math.radians(45.0))
            s45 = math.sin(math.radians(45.0))
            P2 = Point(self.r * c45,  self.r * s45, 0, pid=1)
            P4 = Point(self.r * c45, -self.r * s45, 0, pid=1)
    
        if self.opt != 2:
            # Build rectangular/diamond patch with 3 lines plus center edge
            L1 = Line(P6, P3, n=self.n)
            L2 = Line(P3, P2, n=self.n)
            L3 = Line(P2, P1, n=self.n)
            L4 = Line(P1, P6, n=self.n)
            S1 = Surface(L1, L2, L3, L4, n=1, pid=1)
    
            if self.nsides % 2:  # odd -> mirror across zx and fuse
                S1_bis = syme(S1, plane='zx')
                S1 = fuse(S1, S1_bis, pid=1, verbose=False)
                L_inner = PolyLine(P1, P2, P3, P4, P5, n=self.n, pid=2)
            else:
                L_inner = PolyLine(P1, P2, P3, n=self.n, pid=2)
    
        else:
            # Circular quarter patch
            L1 = Line(P6, P3, n=self.n)
            L2 = Line(P1, P6, n=self.n)
            L_inner = Arc.from_3_points(P3, P2, P1, n=2 * self.n + 1, pid=2)
    
            LC = fuse(L1, L2, verbose=False)
            LC = fuse(LC, L_inner, verbose=False)
            S1 = Surface(LC, n=1, quad=True, pid=1)
    
            if self.nsides % 2:  # odd -> mirror & update L_inner to span half-turn
                S1_bis = syme(S1, plane='zx')
                S1.reverse_orientation()
                S1 = fuse(S1, S1_bis, pid=1, verbose=False)
                L_inner = Arc.from_3_points(P5, P3, P1, n=4 * self.n + 1, pid=2)
    
        return S1
    
class asymCoreMesh():
    def __init__(self, xc: float, zc: float, nx: int = 2, nz: int = 2, z0: float = 0, opt: int = 0):
        self.xc = xc
        self.zc = zc
        self.nx = nx
        self.nz = nz
        self.opt = opt
        self.z0 = z0
        
        self.mesh, self.Lx, self.Lz =  self.__build()
        
    def __build(self):   
        # Base points (pid=1)
        P0 = Point(0,  0, self.z0, pid=1)   # center
        P1 = Point(0,  0, self.zc, pid=1)   # top
        P3 = Point( self.xc, 0, self.z0, pid=1)   # right

        if self.opt == 1:
            P2 = Point(self.xc,  0, self.zc, pid=1)
        else:
            P2 = interpolate_pt_on_ellipse_arc(P0.coords[0], P1.coords[0], P3.coords[0])
            P2 = Point(*P2)
            
        L1 = Line(P0, P1, n=self.nz)
        L4 = Line(P3, P0, n=self.nx)


        L2 = Line(P1, P2, n=self.nx)
        L3 = Line(P2, P3, n=self.nz) 
        # L_inner = fuse(L2, L3,  verbose=False)
        # L_inner.reverse_orientation()
        S1 = Surface(L1, L3, n=self.nx, pid=1)

        return S1, L2, L3
    
class Raccord3D(Volume):
    def __init__(self, l0, l1, l2,  pid = 0):
        
        super().__init__(pid=pid)
        
        self.l0 = l0 # common to s1/s2
        self.l1 = l1 # ext s1 (x+)
        self.l2 = l2 # ext s2 (z+)

        self.lvl = max(nbEl(l0),nbEl(l1))/min(nbEl(l0),nbEl(l1))
        self.li1, self.li2 = self._make_inside_Lines()
        
        
        self._build()
        

        

   
    def _build(self):
       vt0 = self._get_translation(self.l0, self.l2)
       vt1 = self._get_translation(self.l0, self.l1)
       if vt0[2] == 0:
           self.l1, self.l2 = self.l2, self.l1
           self.li1, self.li2 = self.li2, self.li1
           self._vtz = vt1
       else:
           self._vtz = vt0
           
       self.l3 = translate(self.l1, self._vtz)
       if self.lvl == 2:
              self.li3 = self._racc_quad_double(self.l0, self.l3)
       elif self.lvl == 3:
              self.li3 = self._racc_quad_triple(self.l0, self.l3)
           
       ug_list = []
       for i in range(nbEl(self.l3)) :
           ug_list.extend(self._build_cell(i))
    
        
        
       self._ugrid = self.fuse_ugrid(ug_list, verbose = False, merge=False)        

    def _make_hex_ugrid_vtk(points: np.ndarray, conns: list[np.ndarray]) -> vtk.vtkUnstructuredGrid:
        vtk_points = vtk.vtkPoints()
        vtk_points.SetNumberOfPoints(points.shape[0])
        for i, p in enumerate(points):
            vtk_points.SetPoint(i, float(p[0]), float(p[1]), float(p[2]))
    
        ugrid = vtk.vtkUnstructuredGrid()
        ugrid.SetPoints(vtk_points)
    
        for c in conns:
            hex_cell = vtk.vtkHexahedron()
            for k in range(8):
                hex_cell.GetPointIds().SetId(k, int(c[k]))
            ugrid.InsertNextCell(hex_cell.GetCellType(), hex_cell.GetPointIds())
    
        return ugrid
    
    def _build_cell(self, i):
        # Example for lvl=2, even i (your original four cells)
        # Your comment arrays (indices along each line)
        if self.lvl == 2:
            if i % 2 == 0:
                c1_idx = [2*i+2, 2*i+2, 2*i+1, 2*i+1,   i+1,   i+1,     i,     i]   # [li2 li3 li3 li2 l3 l3 l2 l2]
                c2_idx = [2*i+1, 2*i+1,     i,   2*i, 2*i+1, 2*i+1,     i,     i]   # [l0  li1 l1  l0  li2 li3 l3 l2]
                c3_idx = [2*i+2,   i+1,     i, 2*i+1, 2*i+2,   i+1,     i, 2*i+1]   # [li1 l1  l1  li1 li3 l3  l3 li3]
                c4_idx = [2*i+2, 2*i+2, 2*i+1, 2*i+1, 2*i+2, 2*i+2, 2*i+1, 2*i+1]   # [l0  li1 li1 l0  li2 li3 li3 li2]
                
                c1_lines = ['li2','li3','li3','li2','l2','l3','l3','l2']
                c2_lines = ['l0', 'li1','l1','l0', 'li2','li3','l3','l2']
                c3_lines = ['li1','l1','l1','li1','li3','l3','l3','li3']
                c4_lines = ['l0', 'li1','li1','l0', 'li2','li3','li3','li2']
            else:
                c1_idx = [2*i+1, 2*i+1,   2*i, 2*i,     i+1,   i+1,     i,    i ]  # [li2 li3 li3 li2  l3  l3  l2  l2]
                c2_idx = [2*i+1, 2*i+2,   i+1, 2*i+1, 2*i+1,   i+1,   i+1, 2*i+1]   # [l0  l0 l1  li1  li2 l2  l3  li3]
                c3_idx = [2*i+1,   i+1,     i, 2*i,   2*i+1,   i+1,     i, 2*i  ]   # [li1 l1 l1  li1  li3 l3  l3  li3]
                c4_idx = [2*i,   2*i+1, 2*i+1, 2*i,   2*i,   2*i+1, 2*i+1, 2*i  ]   # [l0  l0 li1 li1  li2 li2 li3 li3]           
        # Matching line names for each position (from your square-bracket comments)
                c1_lines = ['li2','li3','li3','li2','l2','l3','l3','l2']
                c2_lines = ['l0', 'l0','l1','li1', 'li2','l2','l3','li3']
                c3_lines = ['li1','l1','l1','li1','li3','l3','l3','li3']
                c4_lines = ['l0', 'l0','li1','li1', 'li2','li2','li3','li3']
    
            c1 = self._cell_from_lines(c1_lines, c1_idx)
            c2 = self._cell_from_lines(c2_lines, c2_idx)
            c3 = self._cell_from_lines(c3_lines, c3_idx)
            c4 = self._cell_from_lines(c4_lines, c4_idx)
            
            ug1 = self._cell_dict_to_vtk_hexa(c1)
            ug2 = self._cell_dict_to_vtk_hexa(c2)
            ug3 = self._cell_dict_to_vtk_hexa(c3)
            ug4 = self._cell_dict_to_vtk_hexa(c4)
            
            return [ug1, ug2, ug3, ug4]
    
        else:
            c1_idx = [3*i+1, 3*i+1, i, 3*i, 3*i+1, 3*i+1, i, i]   
            c2_idx = [3*i+2, i+1, i, 3*i+1, 3*i+2, i+1, i, 3*i+1]  
            c3_idx = [3*i+3, i+1, 3*i+2, 3*i+2, i+1, i+1, 3*i+2, 3*i+2]   
            c4_idx = [3*i+2, 3*i+2, 3*i+1, 3*i+1, i+1, i+1, i, i] 
            c5_idx = [3*i+2, 3*i+2, 3*i+1, 3*i+1, 3*i+2, 3*i+2, 3*i+1, 3*i+1]
            
            c1_lines = ['l0','li1','l1','l0','li2','li3','l3','l2']
            c2_lines = ['li1', 'l1', 'l1', 'li1', 'li3', 'l3', 'l3', 'li3']
            c3_lines = ['l0', 'l1', 'li1', 'l0', 'l2', 'l3', 'li3', 'li2']
            c4_lines = ['li2', 'li3','li3', 'li2', 'l2', 'l3', 'l3', 'l2']    
            c5_lines = ['l0', 'li1', 'li1', 'l0', 'li2', 'li3', 'li3', 'li2']
    
            c1 = self._cell_from_lines(c1_lines, c1_idx)
            c2 = self._cell_from_lines(c2_lines, c2_idx)
            c3 = self._cell_from_lines(c3_lines, c3_idx)
            c4 = self._cell_from_lines(c4_lines, c4_idx)
            c5 = self._cell_from_lines(c5_lines, c5_idx)
            
            ug1 = self._cell_dict_to_vtk_hexa(c1)
            ug2 = self._cell_dict_to_vtk_hexa(c2)
            ug3 = self._cell_dict_to_vtk_hexa(c3)
            ug4 = self._cell_dict_to_vtk_hexa(c4)
            ug5 = self._cell_dict_to_vtk_hexa(c5)
            
            return [ug1, ug2, ug3, ug4, ug5]
        
    def fuse_ugrid(self, mesh_list, merge=True, tol=1e-6, verbose=True):
        """
        Fuse a list of meshes into a single vtkUnstructuredGrid.
    
        Parameters
        ----------
        mesh_list : list
            List of objects each having attribute `. _ugrid` (vtkUnstructuredGrid).
        merge : bool, default True
            If True, merge duplicate points/nodes using the given tolerance.
        tol : float, default 1e-6
            Absolute tolerance used when merging nodes.
        verbose : bool, default True
            If True, prints the number of nodes merged.
    
        Returns
        -------
        vtkUnstructuredGrid
            The fused (and optionally cleaned) unstructured grid.
        """
        if not mesh_list:
            raise ValueError("mesh_list is empty.")
    
        # Append all input unstructured grids
        app = vtk.vtkAppendFilter()
        total_pts_before = 0
    
        for idx, ug in enumerate(mesh_list):
            total_pts_before += ug.GetNumberOfPoints()
            app.AddInputData(ug)
    
        app.Update()
        fused = vtk.vtkUnstructuredGrid()
        fused.DeepCopy(app.GetOutput())
        # Optionally merge duplicate points
        if merge:
            # Prefer vtkStaticCleanUnstructuredGrid if available (faster), else fallback
            try:
                cleaner = vtk.vtkStaticCleanUnstructuredGrid()
            except AttributeError:
                cleaner = vtk.vtkCleanUnstructuredGrid()
    
            cleaner.SetInputData(fused)
            # Use absolute tolerance if supported
            if hasattr(cleaner, "SetToleranceIsAbsolute"):
                cleaner.SetToleranceIsAbsolute(True)
            cleaner.SetTolerance(tol)
            cleaner.Update()
    
            cleaned = vtk.vtkUnstructuredGrid()
            cleaned.DeepCopy(cleaner.GetOutput())
    
            if verbose:
                pts_after = cleaned.GetNumberOfPoints()
                merged = max(0, total_pts_before - pts_after)
                print(f"[fuse_meshes] Nodes before: {total_pts_before}, after: {pts_after} (merged: {merged})")
            return cleaned
        else:
            if verbose:
                pts_after = fused.GetNumberOfPoints()
                merged = max(0, total_pts_before - pts_after)  # typically 0 when not merging
                print(f"[fuse_meshes] Nodes before: {total_pts_before}, after: {pts_after} (merged: {merged})")
            return fused 
        
    def _as_tuple(self, p):  # robust hashing for floats
        return tuple(p.tolist())  # if you need tolerance, round() here
    
    def _cell_from_lines(self, line_names, point_ids):
        """
        line_names: list[str] length 8 (e.g. ['li2','li3','li3','li2','l3','l3','l2','l2'])
        point_ids : list[int]  length 8 (e.g. [2,2,1,1,1,1,0,0])
    
        Returns: {"nodes": [[x,y,z], ...], "connectivity": [i0..i7]}
        """
        nodes = []
        conn = []
        index_of = {}  # maps point tuple -> node index
    
        for ln, pid in zip(line_names, point_ids):
            # get coordinate
            P = np.asarray(getattr(self, ln).get_points()[pid], float)
            key = self._as_tuple(P)
            if key not in index_of:
                index_of[key] = len(nodes)
                nodes.append(P.tolist())
            conn.append(index_of[key])
    
        return {"nodes": nodes, "connectivity": conn}
        
    def _cell_dict_to_vtk_hexa(self, cell):
        """
        Convert a cell dict like:
            {"nodes": [[x,y,z], ...], "connectivity":[i0,..,i7]}
        into a vtkUnstructuredGrid with one VTK_HEXAHEDRON.
    
        Returns: vtk.vtkUnstructuredGrid
        """
        try:
            import vtk
        except Exception as e:
            raise RuntimeError("VTK is required for this function.") from e
    
        pts = np.asarray(cell["nodes"], dtype=float)
        conn = np.asarray(cell["connectivity"], dtype=int)
    
        # Basic checks
        if conn.size != 8:
            raise ValueError(f"Hexa connectivity must have 8 indices (got {conn.size}).")
        if np.unique(conn).size != 8:
            raise ValueError("Hexa connectivity must reference 8 *distinct* nodes.")
    
        if pts.ndim != 2 or pts.shape[1] != 3:
            raise ValueError(f"nodes must be (N,3), got {pts.shape}.")
    
        # VTK hex corner order reminder (match 'conn' order):
        #    7-------6
        #   /|      /|
        #  4-------5 |
        #  | 3-----|-2
        #  |/      |/
        #  0-------1
    
        # Build vtkPoints
        vtk_points = vtk.vtkPoints()
        vtk_points.SetNumberOfPoints(pts.shape[0])
        for i, P in enumerate(pts):
            vtk_points.SetPoint(i, float(P[0]), float(P[1]), float(P[2]))
    
        # Build a vtkHexahedron
        hex_cell = vtk.vtkHexahedron()
        for k in range(8):
            hex_cell.GetPointIds().SetId(k, int(conn[k]))
    
        # Assemble UnstructuredGrid
        ug = vtk.vtkUnstructuredGrid()
        ug.SetPoints(vtk_points)
        ug.InsertNextCell(hex_cell.GetCellType(), hex_cell.GetPointIds())
    
        return ug
        
    def _make_inside_Lines(self):
        if self.lvl == 2:
            li1 = self._racc_quad_double(self.l0, self.l1)
            li2 = self._racc_quad_double(self.l0, self.l2)
        elif self.lvl == 3:
            li1 = self._racc_quad_triple(self.l0, self.l1)
            li2 = self._racc_quad_triple(self.l0, self.l2)
        else :
            raise ValueError(f"lvl must be 2 or 3 (got {self.lvl})")
        return li1, li2
        
    def _get_translation(self, l1, l2):
        p1=l1.get_points()[0]
        p2=l2.get_points()[0]
        return p2-p1
    
    def _racc_quad_double(self, L1, L2):
        if not are_id_oriented(L1, L2):
            L2.reverse_orientation()
    
        n1 = nbEl(L1); n2 = nbEl(L2)
        if n1 > n2:
            L1, L2 = L2, L1
    
        # spine at double resolution, aligned on L1s grading
        l_int = self._interpolate_line(L1, L2, pos=0.5, ratio=2, template='l1')
        return l_int
    
    def _racc_quad_triple(self, L1, L2):
        if not are_id_oriented(L1, L2):
            L2.reverse_orientation()
    
        n1 = nbEl(L1); n2 = nbEl(L2)
        if n1 > n2:
            L1, L2 = L2, L1
    
        # spine at *triple* resolution aligned on L1s grading
        l_int = self._interpolate_line(L1, L2, pos=0.5, ratio=3, template='l1')
        return l_int
    
    def _insert_point(self, pt, pt_id_map, vtk_pts):
        key = tuple(np.round(pt, 8))  # hashable with tolerance
        if key in pt_id_map:
            return pt_id_map[key]
        pid = vtk_pts.InsertNextPoint(pt)
        pt_id_map[key] = pid
        return pid        
    
    def _interpolate_line(self, l1, l2, pos=0.5, ratio=1, template='l1'):
        """
        Build an intermediate curved line between l1 and l2, whose node layout
        is synchronized to a 'template' line's grading. If ratio=r>1, each
        segment of the template is subdivided into r equal parametric parts,
        so that indices multiply by r.
    
        Parameters
        ----------
        l1, l2 : Line
            Boundary lines. If orientations differ, l2 is flipped temporarily.
        pos : float in [0,1]
            Blend factor: 1 -> exactly l1, 0 -> exactly l2.
        ratio : int >= 1
            Subdivisions per *template* segment. 1 keeps the template node count.
            2 doubles, 3 triples, etc.
        template : {'l1','l2'}
            Which boundarys grading/parametrization to follow for node placement.
    
        Returns
        -------
        Line
            A line with (ratio * nbEl(template) + 1) nodes. Nodes at
            indices k*ratio coincide with the templates original nodes.
        """
        # --- helpers ---
        def _arc_param(P):
            P = np.asarray(P, dtype=float)
            if P.shape[0] < 2:
                return P, np.zeros((P.shape[0],), dtype=float)
            d = np.linalg.norm(np.diff(P, axis=0), axis=1)
            cum = np.concatenate(([0.0], np.cumsum(d)))
            L = cum[-1]
            s = cum / L if L > 0 else cum
            return P, s
    
        def _interp_polyline(P, sP, s_query):
            P = np.asarray(P, dtype=float)
            sP = np.asarray(sP, dtype=float)
            s_query = np.asarray(s_query, dtype=float)
            if len(P) == 1 or (len(P) > 1 and np.allclose(P, P[0])):
                return np.repeat(P[:1], len(s_query), axis=0)
            idx = np.searchsorted(sP, s_query, side="right") - 1
            idx = np.clip(idx, 0, len(P) - 2)
            s0 = sP[idx]; s1 = sP[idx + 1]
            denom = np.where(np.abs(s1 - s0) < 1e-15, 1.0, s1 - s0)
            t = (s_query - s0) / denom
            Q = P[idx] * (1.0 - t[:, None]) + P[idx + 1] * t[:, None]
            Q[0]  = P[0]
            Q[-1] = P[-1]
            return Q
    
        # --- body ---
        if ratio < 1 or int(ratio) != ratio:
            raise ValueError("ratio must be a positive integer")
        ratio = int(ratio)
    
        reversed_tmp = False
        try:
            if not are_id_oriented(l1, l2):
                l2.reverse_orientation()
                reversed_tmp = True
    
            P1_raw = np.asarray(l1.get_points(), dtype=float)
            P2_raw = np.asarray(l2.get_points(), dtype=float)
            P1, s1 = _arc_param(P1_raw)
            P2, s2 = _arc_param(P2_raw)
    
            # choose template param grid (use the coarse side for your strips)
            sT = s1 if template == 'l1' else s2
    
            # build s_query by subdividing each template segment into 'ratio' pieces
            # (preserving the templates grading)
            parts = []
            for i in range(len(sT) - 1):
                si, sj = sT[i], sT[i + 1]
                # include left endpoint, exclude right to avoid duplicates, append last later
                parts.append(np.linspace(si, sj, ratio + 1)[:-1])
            s_query = np.concatenate(parts + [np.array([1.0])])
            target_nodes = len(s_query)
    
            # sample both boundaries on s_query and blend
            S1 = _interp_polyline(P1, s1, s_query)
            S2 = _interp_polyline(P2, s2, s_query)
            S  = pos * S1 + (1.0 - pos) * S2
    
            # build a line with the right number of elements, then overwrite coords
            L = Line(Point(*S[0]), Point(*S[-1]), n=target_nodes - 1, grading=1, progression='linear', pid=l1.pid)
            vtk_pts = L.get_vtk_unstructured_grid().GetPoints()
            for i, (x, y, z) in enumerate(S):
                vtk_pts.SetPoint(i, float(x), float(y), float(z))
            vtk_pts.Modified()
            L.get_vtk_unstructured_grid().Modified()
            return L
        finally:
            if reversed_tmp:
                l2.reverse_orientation()
