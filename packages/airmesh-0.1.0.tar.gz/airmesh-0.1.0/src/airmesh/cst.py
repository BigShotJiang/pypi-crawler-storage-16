 
greek_letters_lower = [chr(code) for code in range(945, 970)]
greek_letters_upper = [chr(code) for code in range(913, 938)]