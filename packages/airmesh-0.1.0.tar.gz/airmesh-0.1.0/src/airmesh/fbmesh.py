from pybmesh import *
from .fmaths import *
from .futils import *
from .cmesh import *
from .fmesh import *
from .cmaths import *
from .fmblocks import *

def build_polygonial_surface(
        rext: float,
        rint: float,
        n:    int,
        optc: int,
        nsides: int,
        refLvls: list = [],
        tol: float = 1e-6,
        verbose: bool = False,
        pid:int = 1
    ):
    
    Core = CoreMesh(rint, n, optc, nsides)
    _core = Core.mesh

    Bands = BandInfo(rint, rext, n, refLvls)

    _bands = []
    for i, seg in enumerate(Bands.segments):
        if i ==0:
            L0 = build_core_contour(seg.x0,seg.ny0, optc, nsides)
            L1 = build_core_contour(seg.x1,seg.ny1, optc, nsides)
        else:
            L0 = L1
            L1 = build_polygonal_contour(seg.x1, nsides, seg.ny1)
    
        if seg.refband:
            _bands.append(Raccord2D(L0, L1, pid = 1))
        else:
            _bands.append(Surface(L0, L1, n=seg.nx, pid = 1))


    for i, msh in enumerate(_bands): 
        if i == 0 :
            mesh = fuse(_core, msh, merge=True, tol=tol,verbose=verbose)
        else:
            mesh = fuse(mesh, msh, merge=True, tol=tol,verbose=verbose)
    
    mesh.pid = pid
    
    return mesh
        
def build_multi_polygonial_surface(
        rext: float,
        rint: float,
        n:    int,
        optc: int,
        nsides: int,
        refLvls: list = [],
        tol: float = 1e-6,
        verbose: bool = False,
        pid:int = 1
    ):
    
    Core = CoreMesh(rint, n, optc, nsides)
    _core = Core.mesh

    Bands = BandInfo(rint, rext, n, refLvls)

    _bands = []
    for i, seg in enumerate(Bands.segments):
        if i ==0:
            L0 = build_core_contour(seg.x0,seg.ny0, optc, nsides)
            L1 = build_core_contour(seg.x1,seg.ny1, optc, nsides)
        else:
            L0 = L1
            L1 = build_polygonal_contour(seg.x1, nsides, seg.ny1)
    
        if seg.refband:
            _bands.append(Raccord2D(L0, L1, pid = 1))
        else:
            _bands.append(Surface(L0, L1, n=seg.nx, pid = 1))


    dic = {"type"     : "core",
           "x0"       :  0,
           "x1"       : rint,
           "nx"       : n,
           "ny0"      : n,
           "ny1"      : n,
           "grading"  : 1,
           "mesh"     : _core}
    meshinfo = [dic]
    
    for seg, msh in zip(Bands.segments, _bands):    
        msh.pid = pid
        if seg.refband:
            stype = "refinment"
        else:
            stype = "normal"
            
        dic = {"type"     : stype,
               "x0"       : seg.x0,
               "x1"       : seg.x1,
               "nx"       : seg.nx,
               "ny0"      : seg.ny0,
               "ny1"      : seg.ny1,
               "grading"  : seg.grading,
               "mesh"     : msh}

        meshinfo.append(dic)
        
    return meshinfo

def build_advanced_polygonial_mesh(
        rint: float,
        rext: float,
        hc: float, 
        hd: float, 
        n: int,
        Δxc: float, 
        Δzm: float,
        nsides: int,
        optc: int = 0,
        grz: float = 1.1,
        refLvls: list = []
        ):

    print("...>...prepare data")
    # prepare for extrusion
    _xbands = BandInfo(rint, rext, n, refLvls).segments
    _lp = LinePartitioner(hc, hd, grz, refLvls, Δxc, n)
    _zbands = _lp.build()

    # try : 
    _blocks = BlocksInfo(n, refLvls, _xbands, _zbands, Δzm)
    # except:
    #     _zbands = zbands_to_layers(_zbands, refLvls, grz)  
    #     _blocks = BlocksInfo(n, refLvls, _xbands, _zbands, Δzm)
    
    _blocks = BlocksInfo(n, refLvls, _xbands, _zbands, Δzm)
    _blocks = _blocks.blocks 
    
    rc = _xbands[0].x1

    m0 = len(_blocks)
    n0 = len(_blocks[0]) if m0 > 0 else 0

    M = [[None for _ in range(n0)] for _ in range(m0)]
    print("...>...mesh blocks")
    

    
    for i in range(m0):
        for j in range(n0):
            cell = _blocks[i][j]
            M[i][j] = build_block(cell, rc, nsides, optc)
    
    flat = [M[i][j] for i in range(len(M)) for j in range(len(M[i])) if M[i][j] is not None]
    # plot(*flat)
    # cells_to_plot = [msh for msh in flat] #  if msh.pid == 11
    out = fuse_meshes(flat, merge=True, tol=1e-6, verbose=False) 
    out.correct_orientation()
    out.pid = 1
    
    return out

def build_exterior_surface(
        rint: float,
        rext: float,
        n: int,
        nsides: int) :
    
    dx = (rext-rint) / 6.
    
    # edges left:
    LA = build_polygonal_contour(rint, nsides, n)
    LA.reverse_orientation()
    
    # edges right
    P1 = Point(rint+6*dx, 0, 0)
    P2 = Point(rint+6*dx, rint+6*dx, 0)
    P3 = Point(0, rint+6*dx, 0)
    
    n_tot = nbEl(LA)
    nx = n_tot//2
    ny = n_tot-nx
    
    L1 = Line(P1, P2, n = ny, pid = 2)
    L2 = Line(P2, P3, n = nx, pid = 2)
    LB = fuse(L1, L2, verbose = False)
    
    S  = Surface(LA, LB, n = ny)
    S1 = rotate(S, axis = 'z', angle = -90) 
    S = fuse( S, S1, verbose = False)
    
    P10 =  Point(0, -1*rint-6*dx, 0)
    P11 =  Point(rint+6*dx, -1*rint-6*dx, 0)
    P20 =  Point(0, -1*rint-18*dx, 0)
    P21 =  Point(rint+6*dx, -1*rint-18*dx, 0)
    
    L3 = Line(P10, P11, n = nx, pid = 2)
    L4 = Line(P20, P21, n = nx, pid = 2)

    S2 = Surface(L3, L4, n = ny, progression = 'geometric', grading = 2)
    S = fuse(S, S2, pid = 2, verbose = False)
    S1 = syme(S, plane='yz')
    S.reverse_orientation()
    S = fuse(S, S1, verbose = False)
    
    return S
