from __future__ import annotations

import math
import numpy as np
from .cmaths import *
from operator import mul
from functools import reduce
from typing import List, Tuple, Optional, Sequence

def angle_desc(p):
    # sort key: angle from +x, but we want top(p/2) -> right(0), so sort descending
    x, y = p[0], p[1]
    return math.atan2(y, x)

def lcm(a, b):
    if a == 0 or b == 0:
        return 0
    return abs(a // math.gcd(a, b) * b)

def lcm_list(items):
    return reduce(lcm, items, 1)

def make_divisible(n: int, reflvls) -> int:
    prod = reduce(mul, reflvls, 1)  # cumulative product
    return n if n % prod == 0 else ((n + prod - 1) // prod) * prod

def round_sig(x: float, sig: int = 2) -> float:
    """
    Round x to 'sig' significant digits (base-10).
    Examples (sig=2): 15.2156->15, 0.1254->0.13, 9876->9900, 0.00987->0.0099
    """
    if x == 0 or math.isnan(x) or math.isinf(x):
        return x
    sign = -1.0 if x < 0 else 1.0
    x = abs(x)
    exp = math.floor(math.log10(x))
    factor = 10 ** (exp - sig + 1)
    return sign * round(x / factor) * factor

def _build_modulus(refLvls, nsides):
    """
    Build the minimal modulus M such that any valid n must be a multiple of M,
    given the four constraints in the prompt.
    """
    if not refLvls:
        # If no levels, the only "global" constraints left are from #2 and #4/#3 vacuously drop.
        # We define M = 2*len(refLvls) = 0 -> treat as 1 so 'n' is unchanged.
        return 1

    # sanitize
    refLvls = [abs(int(r)) for r in refLvls]
    nsides = abs(int(nsides))
    if 0 in refLvls or nsides == 0:
        # degenerate: no positive n can satisfy; force M=0 -> caller can decide n=0
        return 0

    # cumulative products P_i (product through level i)
    Ps = []
    p = 1
    for r in refLvls:
        p *= r
        Ps.append(p)

    Pall = Ps[-1]
    L = len(refLvls)

    # Base constraints:
    # 1) n multiple of product of all ref levels  => Pall
    # 2) n multiple of 2*len(refLvls)            => 2*L
    factors = [Pall, 2*L]

    # Coarsening constraints:
    # Let n_i = n / P_i (coarsening by cumulative product through level i)
    # 3) n_i * 4 / nsides is a multiple of refLvls[i]
    #    => (nsides * P_i * refLvls[i]) | (4n)  => factor f3_i = (nsides*P_i*refLvls[i]) / gcd(nsides*P_i*refLvls[i], 4)
    # 4) n_i * 8 / nsides is a multiple of 2
    #    => (nsides * P_i * 2) | (8n)           => factor f4_i = (nsides*P_i*2) / gcd(nsides*P_i*2, 8)
    for P_i, r_i in zip(Ps, refLvls):
        a3 = nsides * P_i * r_i
        f3 = a3 // math.gcd(a3, 4)
        a4 = nsides * P_i * 2
        f4 = a4 // math.gcd(a4, 8)
        factors.extend((f3, f4))

    return lcm_list(factors)

def closest_valid_n(n0, refLvls, nsides, mode="nearest"):
    """
    Snap n0 to a value satisfying all constraints.
    mode: "nearest" (ties round up) or "ceil" (always round up).
    Guarantees: returns 0 only if n0==0 or if modulus M==0 (no solution).
    """
    if n0 is None:
        n0 = 0
    n0 = int(n0)

    M = _build_modulus(refLvls, nsides)

    # If modulus is 0, there is no positive solution; only n=0 is valid.
    if M == 0:
        return 0

    # Always enforce a minimal positive n when we intend a non-empty mesh
    n_min = 2  # or 1 if you truly want to allow 1
    if mode == "ceil":
        n = ((n0 + M - 1) // M) * M
        return max(n, n_min)

    # "nearest" with tie up, but never round to 0 if n0>0
    q, r = divmod(n0, M)
    if q == 0:
        if n0 == 0:
            return 0
        # n0>0 but < M: choose the first positive multiple (upper)
        return max(M, n_min)
    lower = q * M
    upper = (q + 1) * M
    n = upper if (n0 - lower) > (upper - n0) else lower
    return max(n, n_min)

def compute_nx_for_polygone(rint, Δx, nsides, refLvls=None, mode="nearest"):
    """
    Example wrapper mirroring your original:
    - Start from a raw estimate nx0 = max(int(rint/dx), 2) if dx provided else 2
    - Then snap to the closest valid n using the full constraint set.
    """
    nx0 = max(int(rint / Δx), 2) if Δx is not None else 2
    if refLvls:
        nx = closest_valid_n(nx0, refLvls, nsides, mode=mode)
    else:
        nx = nx0  # nothing to enforce if no levels provided
    return nx

def order_points(points: np.ndarray,
                      use_2opt: bool = True,
                      collinear_threshold: float = 0.98
                     ) -> Tuple[np.ndarray, np.ndarray]:
    """
    Robust continuous ordering:
    - If points are ~1D (first PCA component explains most variance), sort by projection.
    - Else, build a path starting from farthest endpoints using NN + optional 2-opt, keep best.

    Returns
    -------
    ordered_points : (N, D) float array
    order_idx      : (N,) int array
    """
    P = np.asarray(points, dtype=float)
    if P.ndim != 2 or P.shape[0] < 2:
        return P.copy(), np.arange(P.shape[0])

    # -------- Branch 1: near-collinear ? sort by PCA projection --------
    # Center
    C = P - P.mean(axis=0, keepdims=True)
    # SVD for PCA (no external deps)
    U, S, Vt = np.linalg.svd(C, full_matrices=False)
    # Explained variance ratios
    var = (S**2) / (S**2).sum()
    if var[0] >= collinear_threshold:
        axis1 = Vt[0]                  # first principal direction
        t = C @ axis1                  # 1D coordinate along the line
        order = np.argsort(t)          # strictly monotonic order
        return P[order], order

    # -------- Branch 2: general case ? NN from farthest endpoints --------
    # Find a good pair of endpoints (approximate diameter)
    # 1) farthest from an arbitrary point
    i0 = 0
    d2 = np.sum((P - P[i0])**2, axis=1)
    i1 = int(np.argmax(d2))
    # 2) farthest from i1
    d2 = np.sum((P - P[i1])**2, axis=1)
    i2 = int(np.argmax(d2))
    # Try both starts, keep best
    order1 = _nn_path(P, start=i1)
    order2 = _nn_path(P, start=i2)
    if use_2opt:
        order1 = _two_opt(P, order1, max_iters=1)
        order2 = _two_opt(P, order2, max_iters=1)
    if _path_length(P, order1) <= _path_length(P, order2):
        return P[order1], order1
    else:
        return P[order2], order2

# # def compute_nx_for_polygone(rint=None, dx=None, nsides=None, refLvls=None, nx=None):
# #     """
# #     Computes the smallest nx_corr >= nx such that for every level i:
# #       n_lvl_i = nx_corr / product(refLvls[0:i]) is
# #         - an integer
# #         - a multiple of refLvls[i]
# #         - a multiple of (nsides/2)
# #     If nx is not provided, it's computed as max(int(rint/dx), 2) when rint and dx are given, else 2.
# #     """
# #     if nsides is None or refLvls is None or len(refLvls) == 0:
# #         raise ValueError("nsides and non-empty refLvls are required.")

# #     if nsides % 2 != 0:
# #         raise ValueError("nsides must be even so that (nsides/2) is integral.")
# #     half_sides = nsides // 2

# #     # Base nx
# #     if nx is None:
# #         nx = max(int(rint / dx), 2) if (rint is not None and dx is not None) else 2

# #     # Build P_i (product of previous refinement levels) and the per-level constraint
# #     P = 1
# #     per_level_requirements = []
# #     for i, L_i in enumerate(refLvls):
# #         # For level i, need nx_corr to be multiple of P_i * lcm(L_i, nsides/2)
# #         need = P * lcm(L_i, half_sides)
# #         per_level_requirements.append(need)
# #         P *= L_i  # update for next level

# #     # Overall period M
# #     M = lcm_list(per_level_requirements)

# #     # Smallest multiple of M that is >= nx
# #     nx_corr = ((nx + M - 1) // M) * M
# #     return nx_corr

# def closest_valid_n(n0, refLvls):
#     # Edge cases that force n = 0
#     if 0 in refLvls or len(refLvls) == 0:
#         return 0

#     # Product of refLvls (absolute value)
#     P = 1
#     for x in refLvls:
#         P *= x
#     P = abs(P)

#     # Combined constraint
#     m = 4 * len(refLvls)
#     L = lcm(lcm(P, 4), m)

#     # If L==0 (paranoia) then only 0 works
#     if L == 0:
#         return 0

#     # Nearest multiple of L; ties go up
#     q, r = divmod(n0, L)
#     lower = q * L
#     upper = (q + 1) * L
#     # choose the closer; if tie, pick upper
#     return upper if (n0 - lower) > (upper - n0) else lower

# def compute_nx_for_polygone(rint, Δx, nsides, refLvls=None):    
#     nx = max(int(rint / Δx), 2) if Δx is not None else 2
#     if refLvls:
#         nx = closest_valid_n(nx, refLvls)

#     return nx


# def compute_nx_for_polygone(rint, Δx, nsides, refLvls=None):    
#     nx = max(int(rint / Δx), 2) if Δx is not None else 2
#     if refLvls:
#         lcm_ref = reduce(lcm, refLvls)
#         key = int(nsides/4) * len(refLvls)
#         nx_k = nx / key
#         nx = int(nx_k / lcm_ref)* lcm_ref * key

#     return nx

def compute_nr_and_grading(
    rint: float,
    rext: float,
    nx: int,
    nr: Optional[int] = None,
    inner_mode: str = "cartesian",
    pad_in: float = 1.0,
    pad_out: float = 1.0,
    search_span: int = 6,
) -> Tuple[int, float, Dict]:
    """
    Backwards-compatible wrapper that preserves the original function signature
    and behavior, now delegating to RadialGrader.
    """
    grader = RadialGrader(inner_mode=inner_mode, pad_in=pad_in, pad_out=pad_out, search_span=search_span)
    return grader.compute_nr_and_grading(rint=rint, rext=rext, nx=nx, nr=nr)

def line_grading_info(size_first: float,
               size_last: float,
               growing_ratio: float,
               progression: str):
    """
    Returns:
      n        : number of elements
      grading  : last_element_size / size_first
      length   : total length (sum of all element sizes)
      last_el  : actual last element size used (<= size_last)
    """
    if size_first <= 0 or size_last <= 0:
        raise ValueError("size_first and size_last must be > 0.")
    if progression not in ("linear", "geometric"):
        raise ValueError("progression must be 'linear' or 'geometric'.")

    if progression == "geometric":
        r = growing_ratio
        if r <= 1.0:
            raise ValueError("For geometric progression, growing_ratio must be > 1.")
        # find max n with s_first * r^(n-1) <= s_last
        if size_first > size_last:
            n = 1
        else:
            n = int(math.floor(math.log(size_last / size_first, r))) + 1
        last_el = size_first * (r ** (n - 1))
        grading = last_el / size_first
        length = size_first * (r ** n - 1.0) / (r - 1.0)

    else:  # linear
        d = growing_ratio  # additive increment
        if d <= 0.0:
            raise ValueError("For linear progression, growing_ratio (increment) must be > 0.")
        if size_first > size_last:
            n = 1
        else:
            # find max n with s_first + (n-1)*d <= s_last
            n = int(math.floor((size_last - size_first) / d)) + 1
        last_el = size_first + (n - 1) * d
        grading = last_el / size_first
        # sum of arithmetic series
        length = n * (2 * size_first + (n - 1) * d) / 2.0

    return n, grading, length, last_el

def line_start_size_from_n(Δxc: float, nmin: int = 5, growing_ratio: float = 1.25, progression: str = "geometric"):
    """
    Compute hzmin so that calling:
      line_grading_info(size_first=hzmin, size_last=dxc, growing_ratio=growing_ratio, progression=progression)
    yields n == nmin.

    Parameters
    ----------
    Δxc : float
        Target last element size (size_last), must be > 0.
    nmin : int
        Desired number of elements, must be >= 1.
    growing_ratio : float
        - If progression == 'geometric': ratio r (>1).
        - If progression == 'linear'   : additive increment d (>0).
    progression : str
        'geometric' or 'linear'.

    Returns
    -------
    hzmin : float
        The size_first to use.
    alpha : float
        hzmin / dxc (for convenience).
    """
    if Δxc <= 0:
        raise ValueError("dxc must be > 0.")
    if nmin < 1:
        raise ValueError("nmin must be >= 1.")

    p = progression.lower()
    if p not in ("geometric", "linear"):
        raise ValueError("progression must be 'geometric' or 'linear'.")

    if p == "geometric":
        r = growing_ratio
        if r <= 1.0:
            raise ValueError("For geometric progression, growing_ratio (r) must be > 1.")
        alpha = r ** (-(nmin - 1))
        hzmin = alpha * Δxc
        return round_sig(hzmin)

    # linear
    d = growing_ratio
    if d <= 0.0:
        raise ValueError("For linear progression, growing_ratio (increment d) must be > 0.")
    hzmin = Δxc - d * (nmin - 1)
    if hzmin <= 0.0:
        raise ValueError(
            "Computed hzmin <= 0 for linear progression. "
            "Increase dxc, decrease d, or reduce nmin."
        )
    alpha = hzmin / Δxc
    return round_sig(hzmin)

def solve_n_and_ratio(
    first_size: float,
    grading_target: float,           # target grading = last/first
    progression: str,               # "linear" or "geometric"
    length: float,                  # maximum total length
    grmin: float,                   # lower bound on growing_ratio
    grmax: float,                   # upper bound on growing_ratio
    nmin: int = 2,                  # minimum number of elements
) -> tuple[int, float, float]:
    """
    Returns (n, growing_ratio, grading_revised)

    - Tries to honor grading_target first.
    - If impossible (length/ratio bounds/nmin), relaxes to a feasible growing_ratio in [grmin, grmax]
      that packs the largest n >= nmin into 'length', then returns the revised grading implied by that ratio.
    """
    if first_size <= 0 or length <= 0:
        raise ValueError("first_size and length must be > 0.")
    if grmin > grmax:
        raise ValueError("grmin must be <= grmax.")
    if progression not in ("linear", "geometric"):
        raise ValueError("progression must be 'linear' or 'geometric'.")
    if nmin < 1:
        nmin = 1

    eps = 1e-12

    # ---------- LINEAR ----------
    if progression == "linear":
        g = grading_target
        if g < 1 - eps:
            raise ValueError("grading_target (last/first) must be >= 1 for linear.")

        # Exact grading attempt
        if abs(g - 1.0) <= eps:
            d = 0.0
            if grmin - eps <= d <= grmax + eps:
                n_max = int(math.floor(length / first_size))
                if n_max >= nmin:
                    return n_max, d, 1.0
            # fall through to relax

        else:
            # L(n) = s1 * (g+1) * n / 2 ; d(n) = s1*(g-1)/(n-1)
            n_len_max = int(math.floor(2.0 * length / (first_size * (g + 1.0))))
            n_start = max(n_len_max, nmin)
            for n in range(n_start, nmin - 1, -1):
                if n == 1:
                    continue
                d = first_size * (g - 1.0) / (n - 1.0)
                if grmin - eps <= d <= grmax + eps:
                    return n, d, g

        # Relax: choose d ? [grmin, grmax] to maximize n
        def d_max_len(n: int) -> float:
            if n <= 1:
                return float("-inf")
            return (2.0 * length / n - 2.0 * first_size) / (n - 1.0)

        # Grow an upper bound until infeasible, then search down
        n_upper = max(nmin, 2)
        while d_max_len(n_upper) >= grmin - eps and n_upper < 10**7:
            n_upper *= 2

        for n in range(n_upper - 1, nmin - 1, -1):
            d_cap = d_max_len(n)
            if d_cap < grmin - eps:
                continue
            d_star = min(grmax, d_cap)
            g_revised = 1.0 + (n - 1.0) * d_star / first_size
            return n, d_star, g_revised

        raise ValueError("No linear solution satisfies length, bounds, and nmin.")

    # ---------- GEOMETRIC ----------
    g = grading_target
    if g < 1 - eps:
        raise ValueError("grading_target (last/first) must be >= 1 for geometric.")

    def geom_length(n: int, r: float) -> float:
        if abs(r - 1.0) <= eps:
            return first_size * n
        return first_size * (r**n - 1.0) / (r - 1.0)

    # Exact grading attempt
    if abs(g - 1.0) <= eps:
        r = 1.0
        if grmin - eps <= r <= grmax + eps:
            n_max = int(math.floor(length / first_size))
            if n_max >= nmin:
                return n_max, r, 1.0
        # else relax below
    else:
        # r(n) = g**(1/(n-1)); need r in [grmin, grmax] and length <= L
        n_upper = max(nmin, 2)
        while True:
            r_n = g ** (1.0 / max(1.0, (n_upper - 1.0)))
            if r_n < grmin - eps or r_n > grmax + eps:
                break
            if geom_length(n_upper, r_n) > length + 1e-12:
                break
            n_upper *= 2
            if n_upper > 10**7:
                break
        for n in range(n_upper - 1, nmin - 1, -1):
            if n == 1:
                continue
            r_n = g ** (1.0 / (n - 1.0))
            if grmin - eps <= r_n <= grmax + eps and geom_length(n, r_n) <= length + 1e-12:
                return n, r_n, g  # exact grading honored

    # Relax: choose r in [grmin, grmax] that maximizes n
    r_try = max(grmin, 1.0 + 1e-12)

    def n_max_for_r(r: float) -> int:
        if r <= 1.0 + eps:
            return int(math.floor(length / first_size))
        # n_max s.t. s1*(r^n - 1)/(r - 1) <= length
        return int(math.floor(math.log(1.0 + (r - 1.0) * length / first_size) / math.log(r)))

    # Prefer the smallest feasible r (packs more elements)
    candidates = sorted({r_try, grmin, grmax})
    for r in candidates:
        if not (grmin - eps <= r <= grmax + eps):
            continue
        n_max = n_max_for_r(r)
        if n_max >= nmin:
            g_revised = r ** (n_max - 1) if n_max >= 2 else 1.0
            return n_max, r, g_revised

    raise ValueError("No geometric solution satisfies length, bounds, and nmin.")

def ellipse_arc_length(a, b, t1, t2, n=1024):
    """
    Composite Simpson's rule for S(t1->t2) on ellipse x=a cos t, z=b sin t.
    n must be even. Works for t1<=t2; if swapped, sign is handled.
    """
    if t1 == t2:
        return 0.0
    if t2 < t1:
        return -_ellipse_arc_length(a, b, t2, t1, n)
    if n % 2:
        n += 1
    h = (t2 - t1) / n

    def f(t):
        return math.hypot(a*math.sin(t), b*math.cos(t))  # sqrt(a^2 sin^2 + b^2 cos^2)

    s = f(t1) + f(t2)
    for k in range(1, n):
        t = t1 + k*h
        s += (4 if k % 2 else 2) * f(t)
    return s * h / 3.0

def interpolate_pt_on_ellipse_arc(P0, P1, P3, tol=1e-12, max_iter=80):
    """
    Inputs: P0, P1, P3 are numpy arrays of shape (3,) -> [x, y, z]
      - P0: 'center' (x0, y0, z0)
      - P1: 'top'    (x0, y0, z0 + zc)
      - P3: 'right'  (x0 + xc, y0, z0)
    Returns: P2 as numpy array shape (3,), lying on the ellipse arc from P1 to P3.
    Constraint: arc(P1->P2)/arc(P2->P3) = ||P0P1||/||P0P3|| = zc/xc
    (Works for xc>0, zc>0; if a==b, falls back to 45° point.)
    """
    P0 = np.asarray(P0, dtype=float)
    P1 = np.asarray(P1, dtype=float)
    P3 = np.asarray(P3, dtype=float)

    # Radii along x and z relative to P0
    a = abs(P3[0] - P0[0])  # xc
    b = abs(P1[2] - P0[2])  # zc

    if not (a > 0 and b > 0):
        raise ValueError("Degenerate ellipse: need xc>0 and zc>0 based on P0,P1,P3.")

    # Special case: circle -> split equally in angle
    if abs(a - b) <= 1e-15 * max(a, b):
        t_star = math.pi / 4.0
        x2 = P0[0] + a * math.cos(t_star)
        z2 = P0[2] + b * math.sin(t_star)
        return np.array([x2, P0[1], z2], dtype=float)

    target = a / b  # ||P0P1||/||P0P3||

    def F(t):
        upper = ellipse_arc_length(a, b, t, math.pi/2)
        lower = ellipse_arc_length(a, b, 0.0, t)
        return upper / lower - target

    # Bisection to solve F(t*) = 0 for t* in (0, pi/2)
    eps = 1e-12
    lo, hi = eps, math.pi/2 - eps
    f_lo, f_hi = F(lo), F(hi)

    if f_lo * f_hi > 0:
        # Try a coarse scan to bracket the root
        steps = 200
        ts = np.linspace(lo, hi, steps + 1)
        Fs = [F(t) for t in ts]
        bracket = None
        for k in range(steps):
            if Fs[k] == 0 or Fs[k]*Fs[k+1] < 0:
                bracket = (ts[k], ts[k+1], Fs[k], Fs[k+1])
                break
        if bracket is None:
            raise RuntimeError("Failed to bracket root for t* on ellipse arc.")
        lo, hi, f_lo, f_hi = bracket

    for _ in range(max_iter):
        mid = 0.5 * (lo + hi)
        f_mid = F(mid)
        if abs(f_mid) < tol or (hi - lo) < tol:
            t_star = mid
            break
        if f_lo * f_mid > 0:
            lo, f_lo = mid, f_mid
        else:
            hi, f_hi = mid, f_mid
    else:
        t_star = 0.5 * (lo + hi)

    # Map parameter to coordinates
    x2 = P0[0] + a * math.cos(t_star)
    z2 = P0[2] + b * math.sin(t_star)
    y2 = P0[1]  # stays on the xz plane
    return np.array([x2, y2, z2], dtype=float)

