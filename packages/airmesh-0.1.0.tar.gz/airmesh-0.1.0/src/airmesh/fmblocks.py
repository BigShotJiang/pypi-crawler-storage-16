from pybmesh import *
from .futils import *
from .fmesh import *
from .cmesh import *


def build_block(cellinfo: CellInfo, rc, nsides, opt: int = 0):
    _mesh = None

    if cellinfo.type_h == 'C':
        if cellinfo.type_v == 'B':
            _mesh = _build_regular_core_block(cellinfo, nsides, opt, pid = 1)
        elif cellinfo.type_v == 'R':
            _mesh = _build_transition_core_block(cellinfo, nsides, opt, pid = 11)
    elif cellinfo.type_h == 'B':
        if cellinfo.type_v == 'B':
            _mesh = _build_regular_band_block(cellinfo,rc, opt, nsides, pid = 2)
        elif cellinfo.type_v == 'R':
            _mesh = _build_transition_band_block(cellinfo,rc, opt, nsides, pid = 12) 
    elif cellinfo.type_h == 'R':
        if cellinfo.type_v == 'B':
            _mesh = _build_regular_refband_block(cellinfo,rc, opt, nsides, pid = 3)
        elif cellinfo.type_v == 'R':
            _mesh = _build_transition_refband_block(cellinfo,rc, opt, nsides, pid = 13)
    return _mesh
                                                                            
def _build_regular_core_block(cellinfo: CellInfo, nsides, opt: int = 0, pid = 1):
    Core = CoreMesh(cellinfo.x1, cellinfo.ny1, opt, nsides)
    _mesh = Core.mesh
    _mesh =  extrudeLinear(_mesh, cellinfo.l_extr, pid = pid)
    _mesh = translate(_mesh, vector=[cellinfo.x0, 0, cellinfo.z0], pid = pid)
    return _mesh

def _build_transition_core_block(cellinfo: CellInfo, nsides, opt: int = 0, pid = 11):
    # Base points (pid=1 to mirror your existing code)
    r = cellinfo.x1
    P0 = Point(0,0,0)
    P1 = Point(0,  r, 0, pid=1)   # top
    P3 = Point( r, 0, 0, pid=1)   # right

    # P2/P4 depend on opt
    if opt == 1:
        P2 = Point(r,  r, 0, pid=1)
    else:
        c45 = math.cos(math.radians(45.0))
        s45 = math.sin(math.radians(45.0))
        P2 = Point(r * c45,  r * s45, 0, pid=1)

    # cstfLvl A
    Core = CoreMesh(cellinfo.x1, cellinfo.ny0, opt, nsides)
    _meshA = Core.mesh
    _meshA = translate(_meshA, [0,0, cellinfo.z0])
    PA = Point(0,0,(cellinfo.z1-cellinfo.z0)/3)
    LA = Line(P0,PA,n=1)
    _meshA = extrudeLinear(_meshA, LA, pid = pid)

    # refLvl A
    L1 = Line(P0, P3, cellinfo.ny0)
    L2 = Line(P0, P3, cellinfo.ny1)
    L2 = translate(L2, [0,0,(cellinfo.z1-cellinfo.z0)/3])
    S1 = Raccord2D(L1, L2)
    S1 = translate(S1, [0,0,cellinfo.z0+((cellinfo.z1-cellinfo.z0)/3)], pid = pid)
    L3 = Line(P1, P2, cellinfo.ny0)
    L4 = Line(P1, P2, cellinfo.ny1)
    L4 = translate(L4, [0,0,(cellinfo.z1-cellinfo.z0)/3])
    S2 = Raccord2D(L3, L4)
    S2 = translate(S2, [0,0,cellinfo.z0+((cellinfo.z1-cellinfo.z0)/3)], pid = pid)

    _meshB = Volume(S1,S2,n=cellinfo.ny0,lexsort = [1,0,2])
    _meshB.reverse_orientation()

    # refLvl B
    L10 = Line(P0, P1, cellinfo.ny0)
    L20 = Line(P0, P1, cellinfo.ny1)
    L20 = translate(L20, [0,0,(cellinfo.z1-cellinfo.z0)/3])
    S10 = Raccord2D(L10, L20)
    S10 = translate(S10, [0,0,cellinfo.z0+(2*(cellinfo.z1-cellinfo.z0)/3)], pid = pid)
    L30 = Line(P3, P2, cellinfo.ny0)
    L40 = Line(P3, P2, cellinfo.ny1)
    L40 = translate(L40, [0,0,(cellinfo.z1-cellinfo.z0)/3])
    S20 = Raccord2D(L30, L40)
    S20 = translate(S20, [0,0,cellinfo.z0+(2*(cellinfo.z1-cellinfo.z0)/3)], pid = pid)
    _meshC = Volume(S10,S20,n=cellinfo.ny1, pid = pid+1, lexsort = [0,1,2])
    _meshC.reverse_orientation()
    
    _mesh = fuse(_meshA, _meshB, merge = True, tol = 1e-5, verbose=False)
    _mesh = fuse(_mesh , _meshC, merge = True, tol = 1e-5, verbose=False)
    _mesh.pid = pid

    return _mesh

def _build_regular_band_block(cellinfo: CellInfo, rc, opt, nsides, pid = 2):
    if cellinfo.x1 == rc:
        L1 = build_core_contour(cellinfo.x0, cellinfo.ny0, opt, nsides)
        L2 = build_core_contour(cellinfo.x1, cellinfo.ny1, opt, nsides)
        
    elif cellinfo.x0 == rc:
        L1 = build_core_contour(cellinfo.x0, cellinfo.ny0, opt, nsides)
        L2 = build_polygonal_contour(cellinfo.x1, nsides, cellinfo.ny1)
        
    else:
        L1 = build_polygonal_contour(cellinfo.x0, nsides, cellinfo.ny0)
        L2 = build_polygonal_contour(cellinfo.x1, nsides, cellinfo.ny1)
        
    _mesh = Surface(L1, L2, n=cellinfo.nx0, grading = cellinfo.gx, progression="geometric", pid = pid)
    _mesh = extrudeLinear(_mesh, cellinfo.l_extr, pid = pid)
    _mesh = translate(_mesh, vector=[0, 0, cellinfo.z0], pid = pid)
    return _mesh

def _build_transition_band_block(cellinfo: CellInfo, rc, opt, nsides, pid = 12):
    # build yz transition mesh
    if cellinfo.x0 < rc:
        L01 = build_core_contour_octant(cellinfo.x0, cellinfo.ny0, opt, nsides, upper = False)
        L02 = build_core_contour_octant(cellinfo.x0, cellinfo.ny1, opt, nsides, upper = False)
        L03 = build_core_contour_octant(cellinfo.x1, cellinfo.ny0, opt, nsides, upper = False)
        L04 = build_core_contour_octant(cellinfo.x1, cellinfo.ny1, opt, nsides, upper = False)
        L05 = build_core_contour_octant(cellinfo.x0, cellinfo.ny0, opt, nsides, upper = False)
        L06 = build_core_contour_octant(cellinfo.x1, cellinfo.ny0, opt, nsides, upper = False)


        L11 = build_core_contour_octant(cellinfo.x0, cellinfo.ny0, opt, nsides, upper = True)
        L12 = build_core_contour_octant(cellinfo.x0, cellinfo.ny1, opt, nsides, upper = True)
        L13 = build_core_contour_octant(cellinfo.x1, cellinfo.ny0, opt, nsides, upper = True)
        L14 = build_core_contour_octant(cellinfo.x1, cellinfo.ny1, opt, nsides, upper = True)    
        L15 = build_core_contour_octant(cellinfo.x0, cellinfo.ny1, opt, nsides, upper = True)
        L16 = build_core_contour_octant(cellinfo.x1, cellinfo.ny1, opt, nsides, upper = True) 

    elif cellinfo.x0 == rc:
        L01 = build_core_contour_octant(cellinfo.x0, cellinfo.ny0, opt, nsides, upper = False)
        L02 = build_core_contour_octant(cellinfo.x0, cellinfo.ny1, opt, nsides, upper = False)
        L03 = build_polygonal_contour_octant(cellinfo.x1, nsides, cellinfo.ny0, pid, upper = False)
        L04 = build_polygonal_contour_octant(cellinfo.x1, nsides, cellinfo.ny1, pid, upper = False)
        L05 = build_core_contour_octant(cellinfo.x0, cellinfo.ny0, opt, nsides, upper = False)
        L06 = build_polygonal_contour_octant(cellinfo.x1, nsides, cellinfo.ny0, pid, upper = False)

        L11 = build_core_contour_octant(cellinfo.x0, cellinfo.ny0, opt, nsides, upper = True)
        L12 = build_core_contour_octant(cellinfo.x0, cellinfo.ny1, opt, nsides, upper = True)
        L13 = build_polygonal_contour_octant(cellinfo.x1, nsides, cellinfo.ny0, pid, upper = True)
        L14 = build_polygonal_contour_octant(cellinfo.x1, nsides, cellinfo.ny1, pid, upper = True)
        L15 = build_core_contour_octant(cellinfo.x0, cellinfo.ny1, opt, nsides, upper = True)
        L16 = build_polygonal_contour_octant(cellinfo.x1, nsides, cellinfo.ny1, pid, upper = True)
        
    else:
        L01 = build_polygonal_contour_octant(cellinfo.x0, nsides, cellinfo.ny0, pid, upper = False)
        L02 = build_polygonal_contour_octant(cellinfo.x0, nsides, cellinfo.ny1, pid, upper = False)
        L03 = build_polygonal_contour_octant(cellinfo.x1, nsides, cellinfo.ny0, pid, upper = False)
        L04 = build_polygonal_contour_octant(cellinfo.x1, nsides, cellinfo.ny1, pid, upper = False)
        L05 = build_polygonal_contour_octant(cellinfo.x0, nsides, cellinfo.ny0, pid, upper = False)
        L06 = build_polygonal_contour_octant(cellinfo.x1, nsides, cellinfo.ny0, pid, upper = False)


        L11 = build_polygonal_contour_octant(cellinfo.x0, nsides, cellinfo.ny0, pid, upper = True)
        L12 = build_polygonal_contour_octant(cellinfo.x0, nsides, cellinfo.ny1, pid, upper = True) 
        L13 = build_polygonal_contour_octant(cellinfo.x1, nsides, cellinfo.ny0, pid, upper = True)
        L14 = build_polygonal_contour_octant(cellinfo.x1, nsides, cellinfo.ny1, pid, upper = True) 
        L15 = build_polygonal_contour_octant(cellinfo.x0, nsides, cellinfo.ny1, pid, upper = True) 
        L16 = build_polygonal_contour_octant(cellinfo.x1, nsides, cellinfo.ny1, pid, upper = True) 
        
    L01 = translate(L01, [0,0,cellinfo.z0+(2*(cellinfo.z1-cellinfo.z0)/3)])
    L02 = translate(L02, [0,0,cellinfo.z1])
    L03 = translate(L03, [0,0,cellinfo.z0+(2*(cellinfo.z1-cellinfo.z0)/3)])
    L04 = translate(L04, [0,0,cellinfo.z1])
    L05 = translate(L05, [0,0,cellinfo.z0+((cellinfo.z1-cellinfo.z0)/3)])
    L06 = translate(L06, [0,0,cellinfo.z0+((cellinfo.z1-cellinfo.z0)/3)])
   
    L11 = translate(L11, [0,0,cellinfo.z0+((cellinfo.z1-cellinfo.z0)/3)])
    L12 = translate(L12, [0,0,cellinfo.z0+(2*(cellinfo.z1-cellinfo.z0)/3)])
    L13 = translate(L13, [0,0,cellinfo.z0+((cellinfo.z1-cellinfo.z0)/3)])
    L14 = translate(L14, [0,0,cellinfo.z0+(2*(cellinfo.z1-cellinfo.z0)/3)])
    L15 = translate(L15, [0,0,cellinfo.z1])
    L16 = translate(L16, [0,0,cellinfo.z1])
    
    S01a = Raccord2D(L01, L02, pid = pid)
    S01b = Surface(L05,L01, n=1, pid = pid)

    S02a = Raccord2D(L03, L04, pid = pid)
    S02b = Surface(L06,L03, n=1, pid = pid)
    S01 = fuse(S01a, S01b, merge = True, tol = 1e-5, verbose=False)
    S02 = fuse(S02a, S02b, merge = True, tol = 1e-5, verbose=False)
    
    S10a = Raccord2D(L11, L12, pid = pid)
    S10b = Surface(L12,L15, n=1, pid = pid)
    S20a = Raccord2D(L13, L14, pid = pid) 
    S20b = Surface(L14,L16, n=1, pid = pid)
    
    S10 = fuse(S10a, S10b, merge = True, tol = 1e-5, verbose=False)
    S20 = fuse(S20a, S20b, merge = True, tol = 1e-5, verbose=False)
    
    V1 = Volume(S01,S02,n=cellinfo.nx1,grading = cellinfo.gx, progression="geometric", pid = pid+1, lexsort = [0,1,2])
    V2 = Volume(S10,S20,n=cellinfo.nx1,grading = cellinfo.gx, progression="geometric", pid = pid+1, lexsort = [1,0,2])

    _mesh = fuse(V1, V2, merge = True, tol = 1e-5, verbose=False)

    # build zx transition mesh
    if cellinfo.nx0 == 1 :
        P0 = Point(0,0,0)
        P1 = Point(0,0,(cellinfo.z1-cellinfo.z0)/3)
        L_extr = Line(P0,P1, n=1)
        if cellinfo.x0 < rc:
            L1 = build_core_contour(cellinfo.x0, cellinfo.ny0, opt, nsides)
            L2 = build_core_contour(cellinfo.x1, cellinfo.ny0, opt, nsides)
            
        elif cellinfo.x0 == rc:
            L1 = build_core_contour(cellinfo.x0, cellinfo.ny0, opt, nsides)
            L2 = build_polygonal_contour(cellinfo.x1, nsides, cellinfo.ny0)
            
        else:
            L1 = build_polygonal_contour(cellinfo.x0, nsides, cellinfo.ny0)
            L2 = build_polygonal_contour(cellinfo.x1, nsides, cellinfo.ny0)
        

        S30 = Surface(L1, L2, n=cellinfo.nx0, pid = pid)
        V3 = extrudeLinear(S30, L_extr, pid = pid)
        V3 = translate(V3, vector=[0, 0, cellinfo.z0], pid = pid)
        _mesh = fuse(_mesh, V3, merge = True, tol = 1e-5, verbose=False)
    else:
        verts1, counts1 = quarter_vertices_and_counts(cellinfo.x1, nsides, cellinfo.ny0)

        if cellinfo.x0 <= rc :
            verts0, counts0, = core_radial_cuts_and_counts(cellinfo.x0, nsides, cellinfo.ny0, opt, counts=counts1)
        else :
            verts0, counts0 = quarter_vertices_and_counts(cellinfo.x0, nsides, cellinfo.ny0)
 
        ptsa = [Point(p[0], p[1], 0, pid = 1) for p in verts0]
        ptsb = [Point(p[0], p[1], 0, pid = 1) for p in verts1]
        surf = []
        for p0, p1 in zip(ptsa,ptsb):
            if cellinfo.gx != 1 :
                l1 = Line(p0,p1, n = cellinfo.nx0, grading = cellinfo.gx, progression="geometric")
                l2 = Line(p0,p1, n = cellinfo.nx1, grading = cellinfo.gx, progression="geometric")
            else :
                l1 = Line(p0,p1, n = cellinfo.nx0)
                l2 = Line(p0,p1, n = cellinfo.nx1)
            l1 = translate(l1, vector=[0, 0, cellinfo.z0], pid = pid)
            l2 = translate(l2, vector=[0, 0, cellinfo.z0+((cellinfo.z1-cellinfo.z0)/3)], pid = pid)
            surf.append(Raccord2D(l1, l2, pid = pid))
        
        for i, nseg in enumerate(counts1):
            s0 = surf[i]
            s1 = surf[i + 1]
            lexsort = [0,1,2] if i >= len(counts1) / 2 else [1,0,2]
            V = Volume(s0, s1, n=nseg, lexsort = lexsort, pid = pid)
            _mesh = fuse(_mesh, V, merge = True, tol = 1e-5, verbose=False)
            
    return _mesh

def _build_regular_refband_block(cellinfo: CellInfo, rc, opt, nsides, pid = 3):
    if cellinfo.x1 == rc:
        L1 = build_core_contour(cellinfo.x0, cellinfo.ny0, opt, nsides)
        L2 = build_core_contour(cellinfo.x1, cellinfo.ny1, opt, nsides)
        
    elif cellinfo.x0 == rc:
        L1 = build_core_contour(cellinfo.x0, cellinfo.ny0, opt, nsides)
        L2 = build_polygonal_contour(cellinfo.x1, nsides, cellinfo.ny1)
        
    else:
        L1 = build_polygonal_contour(cellinfo.x0, nsides, cellinfo.ny0)
        L2 = build_polygonal_contour(cellinfo.x1, nsides, cellinfo.ny1)
    _mesh = Raccord2D(L1, L2, pid = pid)
    _mesh = extrudeLinear(_mesh, cellinfo.l_extr, pid = pid)
    _mesh = translate(_mesh, vector=[0, 0, cellinfo.z0], pid = pid)
    return _mesh

def _build_transition_refband_block(cellinfo: CellInfo, rc, opt, nsides, pid = 13):
    if cellinfo.x1 == rc:
        L01 = build_core_contour_octant(cellinfo.x0, cellinfo.ny0, opt, nsides, upper = False)
        L02 = build_core_contour_octant(cellinfo.x1, cellinfo.ny1, opt, nsides, upper = False)
        L03 = build_core_contour_octant(cellinfo.x0, cellinfo.ny0, opt, nsides, upper = True)
        L04 = build_core_contour_octant(cellinfo.x1, cellinfo.ny1, opt, nsides, upper = True)
        L05 = build_core_contour_octant(cellinfo.x0, cellinfo.ny1, opt, nsides, upper = True)
        L06 = build_core_contour_octant(cellinfo.x1, cellinfo.ny1, opt, nsides, upper = True)
        LA = build_core_contour_octant(cellinfo.x0, cellinfo.ny1, opt, nsides, upper = False)
        LB = build_core_contour_octant(cellinfo.x0, cellinfo.ny1, opt, nsides, upper = True)
        
    elif cellinfo.x0 == rc:
        L01 = build_core_contour_octant(cellinfo.x0, cellinfo.ny0, opt, nsides, upper = False)
        L02 = build_polygonal_contour_octant(cellinfo.x1, nsides, cellinfo.ny1, pid, upper = False)
        L03 = build_core_contour_octant(cellinfo.x0, cellinfo.ny0, opt, nsides, upper = True)
        L04 = build_polygonal_contour_octant(cellinfo.x1, nsides, cellinfo.ny1, pid, upper = True) 
        L05 = build_core_contour_octant(cellinfo.x0, cellinfo.ny1, opt, nsides, upper = True)
        L06 = build_polygonal_contour_octant(cellinfo.x1, nsides, cellinfo.ny1, pid, upper = True)
        
        LA = build_core_contour_octant(cellinfo.x0, cellinfo.ny1, opt, nsides, upper = False)
        LB = build_core_contour_octant(cellinfo.x0, cellinfo.ny1, opt, nsides, upper = True)
        
    else:
        L01 = build_polygonal_contour_octant(cellinfo.x0, nsides, cellinfo.ny0, pid, upper = False)
        L02 = build_polygonal_contour_octant(cellinfo.x1, nsides, cellinfo.ny1, pid, upper = False)
        L03 = build_polygonal_contour_octant(cellinfo.x0, nsides, cellinfo.ny0, pid, upper = True)
        L04 = build_polygonal_contour_octant(cellinfo.x1, nsides, cellinfo.ny1, pid, upper = True)
        L05 = build_polygonal_contour_octant(cellinfo.x0, nsides, cellinfo.ny1, pid, upper = True)
        L06 = build_polygonal_contour_octant(cellinfo.x1, nsides, cellinfo.ny1, pid, upper = True)
        
        LA = build_polygonal_contour_octant(cellinfo.x0, nsides, cellinfo.ny1, pid, upper = False)
        LB = build_polygonal_contour_octant(cellinfo.x0, nsides, cellinfo.ny1, pid, upper = True)
        
    Sref_L_0 = Raccord2D(L01, L02)
    Sref_T_0 = Raccord2D(L03, L04)
    
    Sref_L_0 = translate(Sref_L_0, [0,0,cellinfo.z0])
    Sref_L_2 = translate(Sref_L_0, [0,0,2*(cellinfo.z1-cellinfo.z0)/3])

    Sref_T_0 = translate(Sref_T_0, [0,0,cellinfo.z0])
    Sref_T_1 = translate(Sref_T_0, [0,0,(cellinfo.z1-cellinfo.z0)/3])

    VB_012 = Volume(Sref_L_0, Sref_L_2, 2)
    VT_01  = Volume(Sref_T_0,  Sref_T_1, 1)
  
    # now make special transition element
    l0 = translate(L01, [0,0,cellinfo.z0+2*(cellinfo.z1-cellinfo.z0)/3])
    l1 = translate(L02, [0,0,cellinfo.z0+2*(cellinfo.z1-cellinfo.z0)/3])
    l2 = translate(LA, [0,0,cellinfo.z1])
    VB_23 = Raccord3D(l0, l1, l2)

    l10 = translate(L03, [0,0,cellinfo.z0+(cellinfo.z1-cellinfo.z0)/3]) 
    l11 = translate(L04, [0,0,cellinfo.z0+1*(cellinfo.z1-cellinfo.z0)/3])
    l12 = translate(LB, [0,0,cellinfo.z0+2*(cellinfo.z1-cellinfo.z0)/3])
    VT_12 = Raccord3D(l10, l11, l12)
    
    # Finalise VT last level
    L05 = translate(L05, [0,0,cellinfo.z0+2*(cellinfo.z1-cellinfo.z0)/3])
    L06 = translate(L06, [0,0,cellinfo.z0+2*(cellinfo.z1-cellinfo.z0)/3])
    Sref_T_2 = Surface(L05,L06, n=1)
    Sref_T_3 = translate(Sref_T_2, [0,0,1*(cellinfo.z1-cellinfo.z0)/3])
    VT_23  = Volume(Sref_T_2,  Sref_T_3, 1)

    _mesh = fuse_meshes([VB_012, VT_01, VB_23, VT_12, VT_23], verbose = False)
    _mesh.pid = 13
    
    return _mesh
