from pybmesh import *
from .fmaths import *
from .cmesh import *
from .cmaths import *
from collections import defaultdict
import vtk

def quarter_vertices_and_counts(
    x: float,
    nside: int,
    n: int,
    optc: int = 0,
) -> Tuple[List[Tuple[float, float]], List[int]]:
    
    Lc = build_polygonal_contour(x, nside, n, pid = 0)
    
    angle_ref = 360 / nside
    rot_deg = 180.0 / nside
    split_midside = False
    
    angles = [i * angle_ref for i in range(0, nside // 4 + 1)]
    angles = [angle - rot_deg for angle in angles if angle - rot_deg > 0]
    if not any(math.isclose(a, 45.0, rel_tol=0, abs_tol=1e-9) for a in angles):
        angles.append(45.0)
        split_midside = True
    angles.sort()
    H = x / math.cos(angle_ref * math.pi/360.0)
    verts = [Point(H * math.sin(angle * math.pi/180.0), H * math.cos(angle * math.pi/180.), 0, pid = 1) for angle in angles]

    angles.insert(0, 0)
    angles.append(90)
    verts.insert(0, Point(0, x, 0))
    verts.append(Point(x, 0, 0)) 

    if split_midside:
        idx = angles.index(45.0)
        pt0 = verts[idx-1].coords[0]
        pt1 = verts[idx+1].coords[0]
        pt_mid = (pt0 + pt1)/2.0
        verts[idx] = Point(pt_mid[0], pt_mid[1], pt_mid[2])
   
    counts = []
    
    for i in range(len(angles) - 1):
        angle_init = angles[i]-1e-3
        angle_end  = angles[i + 1]+1e-3

        angle_dict = {
        "type": "angular",
        "p1": (0, 0, 0),
        "p2": (0, 0, 1),
        "angle_init": angle_init,
        "angle_end": angle_end,
        "tol" : 1e-3
        }
        pts = extract_point(Lc, angle_dict, pid = 10)
        counts.append(nbEl(pts)-1)
        

    verts = [p.coords[0] for p in verts]

    return verts, counts

def core_radial_cuts_and_counts(
    r: float,
    nsides: int,
    n: int,
    opt: int,
    counts: list[int],
    *,
    pid: int = 2,
):
    """
    Stitches the quarter core polyline as:
        upper octant (top -> 45°)  +  lower octant (45° -> right)
    ensuring a single shared 45° node, then picks cut nodes at the cumulative counts.
    """
    import math

    EPS = 1e-12
    THETA_45 = math.pi / 4.0

    def theta_xy(p):
        return math.atan2(p[1], p[0])

    def by_angle_desc(pts):
        # strictly order by decreasing angle (top ~ pi/2 down to right ~ 0)
        return sorted(pts, key=theta_xy, reverse=True)

    def find_45_index(pts):
        """Return (idx, exact_point) where idx is the index of the node ON 45°,
        or the index where the crossing occurs after inserting the intersection.
        exact_point is the snapped (m,m)."""
        # 1) exact node on y==x?
        for i, (x, y) in enumerate(pts):
            if abs(y - x) <= EPS:
                m = 0.5 * (x + y)
                pts[i] = (m, m)
                return i, (m, m)

        # 2) crossing between i and i+1?
        for i in range(len(pts) - 1):
            x0, y0 = pts[i]
            x1, y1 = pts[i + 1]
            f0, f1 = (y0 - x0), (y1 - x1)
            if (f0 == 0.0 and f1 == 0.0):
                # segment lies on y=x: collapse to a single (m,m) point at position i
                m = 0.5 * ((x0 + x1 + y0 + y1) / 4.0)
                pts[i] = (m, m)
                del pts[i + 1]
                return i, (m, m)
            if (f0 == 0.0):
                m = 0.5 * (x0 + y0)
                pts[i] = (m, m)
                return i, (m, m)
            if (f1 == 0.0):
                m = 0.5 * (x1 + y1)
                pts[i + 1] = (m, m)
                return i + 1, (m, m)
            if (f0 > 0 and f1 < 0) or (f0 < 0 and f1 > 0):
                # proper crossing: interpolate intersection with y=x
                denom = (x1 - y1) - (x0 - y0)
                if abs(denom) < EPS:
                    # nearly paralleluse segment midpoint as a stable fallback
                    xm = 0.5 * (x0 + x1)
                    ym = 0.5 * (y0 + y1)
                else:
                    t = (y0 - x0) / denom
                    t = max(0.0, min(1.0, t))
                    xm = (1.0 - t) * x0 + t * x1
                    ym = (1.0 - t) * y0 + t * y1
                m = 0.5 * (xm + ym)
                ins = (m, m)
                pts[i + 1:i + 1] = [ins]
                return i + 1, (m, m)

        # Should not happen for a quarter; return closest-to-45 as fallback
        angs = [abs(theta_xy(p) - THETA_45) for p in pts]
        j = min(range(len(pts)), key=lambda k: angs[k])
        x, y = pts[j]
        m = 0.5 * (x + y)
        pts[j] = (m, m)
        return j, (m, m)

    # ---------- 1) Build both octants ----------
    L_lo = build_core_contour_octant(r, n=n, opt=opt, pid=pid, upper=False)  # 45°->right octant
    L_up = build_core_contour_octant(r, n=n, opt=opt, pid=pid, upper=True)   # top->45° octant

    lo = [tuple(p[:2]) for p in L_lo.get_points()]
    up = [tuple(p[:2]) for p in L_up.get_points()]

    # ---------- 2) Angle-normalize each list (top=pi/2 down to right=0) ----------
    lo = by_angle_desc(lo)
    up = by_angle_desc(up)

    # Quick invariants: up should live mostly in [45°, 90°], lo in [0°, 45°]
    def ang_range(pts):
        return theta_xy(pts[0]), theta_xy(pts[-1])

    # If an octant landed on the wrong side due to generator orientation,
    # reverse only that octant to keep monotonic decrease.
    a0, a1 = ang_range(up)
    if a0 < a1:  # angles increasing -> reverse
        up.reverse()
    a0, a1 = ang_range(lo)
    if a0 < a1:
        lo.reverse()

    # ---------- 3) Ensure exactly one 45° node in each, then snap to same (m,m) ----------
    idx_up, p45_up = find_45_index(up)
    idx_lo, p45_lo = find_45_index(lo)
    # Pick a common 45° (average the two if they differ slightly)
    mm = 0.5 * (p45_up[0] + p45_lo[0])
    p45 = (mm, mm)
    up[idx_up] = p45
    lo[idx_lo] = p45

    # ---------- 4) Quarter path: UP (top..45° inclusive) + LO (45°..right exclusive) ----------
    quarter = up[:idx_up + 1] + lo[idx_lo + 1:]

    # Sanity: we expect 2*n + 1 nodes; if off by rounding, lightly dedupe consecutive equal points
    if len(quarter) > 1:
        cleaned = [quarter[0]]
        for q in quarter[1:]:
            if (q[0] - cleaned[-1][0])**2 + (q[1] - cleaned[-1][1])**2 > 1e-24:
                cleaned.append(q)
        quarter = cleaned

    # Final guard on monotonic angle
    angs = [theta_xy(p) for p in quarter]
    if any(angs[i] < angs[i+1] - 1e-13 for i in range(len(angs)-1)):
        # If this ever triggers, do a final sort by angle descending
        quarter = by_angle_desc(quarter)

    # ---------- 5) Cut nodes at cumulative indices from counts ----------
    cum = [0]
    for c in counts:
        cum.append(cum[-1] + c)
    last = len(quarter) - 1
    idxs = [min(max(0, k), last) for k in cum]
    cuts = [(quarter[i][0], quarter[i][1]) for i in idxs]

    return cuts, counts

def make_vertical_line(x=0.0, y=0.0, details=None, pid=1):
    if details is None:
        details = [{"z": [0, 1], "n": 1}]
    L = None
    for idx, d in enumerate(details):
        z0, z1 = d["z"]
        n = max(1, int(d.get("n", 1)))
        grading = d.get("grading", 1)
        progression = d.get("progression", "linear")
        P0 = Point(float(x), float(y), float(z0))
        P1 = Point(float(x), float(y), float(z1))
        seg = Line(P0, P1, n=n, grading=grading, progression=progression, pid=pid)
        L = seg if L is None else fuse(L, seg, verbose=False)
    return L

def build_polygonal_contour(x: float, nside: int, n: int, pid: int = 1):
    """
    Build and return the polygonal contour L for a regular polygon.

    Parameters
    ----------
    x : float       # radius (>0)
    nside : int     # number of sides (>=3)
    n : int         # base element count (>0)
    pid : int       # curve id

    Returns
    -------
    L : fused polyline curve
    """
    # ---- checks ----
    if nside < 3:
        raise ValueError("nside must be >= 3")
    if x <= 0:
        raise ValueError("x must be > 0")
    if n <= 0:
        raise ValueError("n must be > 0")

    # ---- build side points (inline) ----
    angle_ref = 2 * math.pi / nside
    P = []

    if nside % 2 != 0:  # odd
        P = [
            Point(x * math.sin(i * angle_ref), x * math.cos(i * angle_ref), 0)
            for i in range(0, nside // 2 + 1)
        ]
        # extra top point (matches your original)
        P.append(Point(0, x * math.cos((nside // 2) * angle_ref), 0))
    else:  # even
        H = x / math.cos(angle_ref / 2)
        P = [
            Point(H * math.sin(i * angle_ref), H * math.cos(i * angle_ref), 0)
            for i in range(0, nside // 4 + 1)
        ]
        # rotate by 180/nside degrees about z
        rot_deg = 180.0 / nside
        for pt in P:
            pt.rotate((0, 0, 0), "z", rot_deg)
        # enforce endpoints
        P.pop(0)
        P.insert(0, Point(0, x, 0))
        P.append(Point(x, 0, 0))

    # ---- distribute points per segment (inline) ----
    S = len(P) - 1
    if S <= 0:
        raise ValueError("internal: need at least two points")

    target_sum = (n * 4) if (nside % 2) else (n * 2)

    # weights
    if nside % 2:  # odd
        weights = [1.0] * max(S - 1, 0) + [0.5]
    else:
        if nside == 4:
            weights = [1.0, 1.0]
        elif nside % 4 == 0:
            weights = [0.5] + [1.0] * max(S - 2, 0) + [0.5]
        else:
            weights = [0.5] + [1.0] * max(S - 1, 0)

    sum_w = sum(weights)
    ideal = [target_sum * (w / sum_w) for w in weights]
    n_per_seg = [int(math.floor(v)) for v in ideal]

    # leftover by largest fractional parts
    rem = target_sum - sum(n_per_seg)
    if rem > 0:
        fracs = sorted(((ideal[i] - n_per_seg[i], i) for i in range(S)), reverse=True)
        for _, idx in fracs[:rem]:
            n_per_seg[idx] += 1

    # cap last segment close to half
    last_cap = int(math.ceil(ideal[-1]))
    if n_per_seg[-1] > last_cap:
        excess = n_per_seg[-1] - last_cap
        n_per_seg[-1] = last_cap
        if excess > 0:
            fracs_no_last = sorted(((ideal[i] - n_per_seg[i], i) for i in range(S - 1)), reverse=True)
            k = 0
            while excess > 0 and k < len(fracs_no_last):
                j = fracs_no_last[k][1]
                n_per_seg[j] += 1
                excess -= 1
                k += 1
            i = 0
            while excess > 0:
                n_per_seg[i % (S - 1)] += 1
                excess -= 1
                i += 1

    assert sum(n_per_seg) == target_sum, f"Expected {target_sum}, got {sum(n_per_seg)} with {n_per_seg}"

    # ---- build & fuse segments (inline) ----
    L = Line(P[0], P[1], n=n_per_seg[0])
    for i in range(1, S):
        L_tmp = Line(P[i], P[i + 1], n=n_per_seg[i])
        L = fuse(L, L_tmp, verbose=False, pid=pid)

    return L

def build_core_contour(
    r: float,
    n: int = 2,
    opt: int = 0,
    nsides: int = 0,
    pid: int = 2,
) -> "Union[PolyLine, Arc]":
    """
    Return only L_inner given the same parameters your CoreMesh uses.
    Matches the branching in CoreMesh.__build().

    Parameters
    ----------
    r : float
        Radius; must be > 0
    n : int
        Discretization parameter; must be > 0
    opt : int
        0/1 => polygonal (diamond/rect), 2 => circular
    nsides : int
        If odd, L_inner spans half-turn (polygon: P1->...->P5; circle: P5->P3->P1)
    pid : int
        Part/curve id to assign to the returned curve
    """
    if r <= 0:
        raise ValueError("r must be > 0")
    if n <= 0:
        raise ValueError("n must be > 0")

    # Base points (pid=1 to mirror your existing code)
    P1 = Point(0,  r, 0, pid=1)   # top
    P3 = Point( r, 0, 0, pid=1)   # right
    P5 = Point(0, -r, 0, pid=1)   # bottom

    # P2/P4 depend on opt
    if opt == 1:
        P2 = Point(r,  r, 0, pid=1)
        P4 = Point(r, -r, 0, pid=1)
    else:
        c45 = math.cos(math.radians(45.0))
        s45 = math.sin(math.radians(45.0))
        P2 = Point(r * c45,  r * s45, 0, pid=1)
        P4 = Point(r * c45, -r * s45, 0, pid=1)

    # Build L_inner exactly like in __build
    if opt != 2:
        # polygonal case
        if nsides % 2:  # odd -> longer polyline P1..P5
            return PolyLine(P1, P2, P3, P4, P5, n=n, pid=pid)
        else:
            return PolyLine(P1, P2, P3, n=n, pid=pid)
    else:
        # circular case
        if nsides % 2:  # odd -> half-turn arc
            return Arc.from_3_points(P5, P3, P1, n=4 * n + 1, pid=pid)
        else:
            return Arc.from_3_points(P3, P2, P1, n=2 * n + 1, pid=pid)

def build_core_contour_octant(
    r: float,
    n: int = 2,
    opt: int = 0,
    pid: int = 2,
    upper: bool = False,
) -> "PolyLine":
    """
    Return half of the previous quarter contour (i.e., one octant of the mesh).

    Parameters
    ----------
    r : float
        Radius; must be > 0
    n : int
        Discretization parameter; must be > 0
    opt : int
        0 => 45° mid-point (default), 1 => diamond/rect mid-point
        (opt == 2 ignored as requested)
    pid : int
        Part/curve id to assign to the returned curve
    upper : bool
        True  => return upper 1/8 (P1 -> P2)
        False => return lower 1/8 (P2 -> P3)

    Notes
    -----
    - Matches your polygonal branching for opt != 2.
    - Ignores `nsides` and circular handling as requested.
    """

    if r <= 0:
        raise ValueError("r must be > 0")
    if n <= 0:
        raise ValueError("n must be > 0")

    # Base points (pid=1 to mirror your existing code)
    P1 = Point(0,  r, 0, pid=1)   # top
    P3 = Point( r, 0, 0, pid=1)   # right

    # Mid-point P2 depends on opt (polygonal only)
    if opt == 1:
        # diamond/rect corner
        P2 = Point(r, r, 0, pid=1)
    else:
        # 45° point
        c45 = math.cos(math.radians(45.0))
        s45 = math.sin(math.radians(45.0))
        P2 = Point(r * c45, r * s45, 0, pid=1)

    # Return the chosen octant polyline
    if upper:
        # upper 1/8: from P1 (top) to P2 (45°)
        return PolyLine(P1, P2, n=n, pid=pid)
    else:
        # lower 1/8: from P2 (45°) to P3 (right)
        return PolyLine(P2, P3, n=n, pid=pid)

def build_polygonal_contour_octant(x: float, nside: int, n: int, pid: int = 1, upper: bool = False):
    L = build_polygonal_contour(x, nside, n, pid)

    if  upper :
        angle_init = 45
        angle_end = 90
    else : 
        angle_init = 0
        angle_end = 45 
    angle_dict = {
    "type": "angular",
    "p1": (0, 0, 0),
    "p2": (0, 0, 1),
    "angle_init": angle_init,
    "angle_end": angle_end,
    "tol" : 1e-3
    # r_inner=0 (default), r_outer=+inf (default)
    # zmin=-inf (default), zmax=+inf (default)
    }
    pts = extract_point(L, angle_dict, pid = 10)
    L_octant  = extract_element(L, points=pts, strict = True)

    return L_octant

def fuse_meshes(mesh_list, merge=True, tol=1e-6, verbose=True):
    """
    Fuse a list of meshes into a single vtkUnstructuredGrid.

    Parameters
    ----------
    mesh_list : list
        List of objects each having attribute `. _ugrid` (vtkUnstructuredGrid).
    merge : bool, default True
        If True, merge duplicate points/nodes using the given tolerance.
    tol : float, default 1e-6
        Absolute tolerance used when merging nodes.
    verbose : bool, default True
        If True, prints the number of nodes merged.

    Returns
    -------
    vtkUnstructuredGrid
        The fused (and optionally cleaned) unstructured grid.
    """
    if not mesh_list:
        raise ValueError("mesh_list is empty.")

    # Append all input unstructured grids
    app = vtk.vtkAppendFilter()
    total_pts_before = 0

    for idx, m in enumerate(mesh_list):
        if not hasattr(m, "_ugrid") or not isinstance(m._ugrid, vtk.vtkUnstructuredGrid):
            raise TypeError(f"Item {idx} does not have a valid ._ugrid (vtkUnstructuredGrid).")
        ug = m._ugrid
        total_pts_before += ug.GetNumberOfPoints()
        app.AddInputData(ug)

    app.Update()
    fused = vtk.vtkUnstructuredGrid()
    fused.DeepCopy(app.GetOutput())
    out = mesh_list[0].copy()
    # Optionally merge duplicate points
    if merge:
        # Prefer vtkStaticCleanUnstructuredGrid if available (faster), else fallback
        try:
            cleaner = vtk.vtkStaticCleanUnstructuredGrid()
        except AttributeError:
            cleaner = vtk.vtkCleanUnstructuredGrid()

        cleaner.SetInputData(fused)
        # Use absolute tolerance if supported
        if hasattr(cleaner, "SetToleranceIsAbsolute"):
            cleaner.SetToleranceIsAbsolute(True)
        cleaner.SetTolerance(tol)
        cleaner.Update()

        cleaned = vtk.vtkUnstructuredGrid()
        cleaned.DeepCopy(cleaner.GetOutput())

        if verbose:
            pts_after = cleaned.GetNumberOfPoints()
            merged = max(0, total_pts_before - pts_after)
            print(f"[fuse_meshes] Nodes before: {total_pts_before}, after: {pts_after} (merged: {merged})")
        out._ugrid = cleaned
        return out
    else:
        if verbose:
            pts_after = fused.GetNumberOfPoints()
            merged = max(0, total_pts_before - pts_after)  # typically 0 when not merging
            print(f"[fuse_meshes] Nodes before: {total_pts_before}, after: {pts_after} (merged: {merged})")
        out._ugrid = fused
        return out


