import math
import numpy as np
from functools import reduce
from operator import mul
from pybmesh import Point, Line, fuse
from typing import Iterable, Optional, Callable, Dict, List, Tuple
from dataclasses import dataclass
from .fmaths import *
from .cmaths import *
from .fmesh import *

def map_value(x, keys, vals):
    """
    Given a value `x`, and two lists `keys` and `vals` of equal length,
    returns the *maximum* value among all `vals[i]` where `keys[i] == x`.
    Returns None if `x` is not found in `keys`.
    """
    matches = [v for k, v in zip(keys, vals) if k == x]
    return max(matches) if matches else None

@dataclass
class SegmentInfo:
    x0: float 
    x1: float
    nx:  int         # tangential divs used for target sizing (constant across domain in this design)
    ny0: int         # incoming radial count
    ny1: int         # outgoing radial count
    grading: float 
    details: dict
    refband: bool  = False

    def __str__(self) -> str:
        def fmt(v):
            return f"{v:.6g}" if isinstance(v, (int, float)) else str(v)
        tag = "Refinement" if self.refband else "Constant"
        details_str = ", ".join(f"{k}={fmt(v)}" for k, v in self.details.items())
        details_part = f"\n  details: {details_str}" if details_str else ""
        return (
            f"<{tag}>\n"
            f"  x0={fmt(self.x0)}, x1={fmt(self.x1)}\n"
            f"  nx={self.nx}, ny0={self.ny0}, ny1={self.ny1}\n"
            f"  grading={fmt(self.grading)}{details_part}"
        )

    def __repr__(self) -> str:
        return f"{'Refinement' if self.refband else 'Constant'}({self.x0:.3g}-{self.x1:.3g}, nx={self.nx}, ny=({self.ny0},{self.ny1}))"

@dataclass
class CellInfo:
    x0: float = 0.0
    x1: float = 0.0
    z0: float = 0.0
    z1: float = 0.0
    nx0: int = 0
    nx1: int = 0
    ny0: int = 0
    ny1: int = 0
    nz: int = 0
    gx: float = 0.0
    gz: float = 0.0
    type_h: str = ""
    type_v: str = ""
    l_extr: Line | None = None


    def __str__(self) -> str:
        def fmt(v):
            return f"{v:.6g}" if isinstance(v, (int, float)) else str(v)
        return (
            f"<CellInfo>\n"
            f"  x0={fmt(self.x0)}, x1={fmt(self.x1)}\n"
            f"  z0={fmt(self.z0)}, z1={fmt(self.z1)}\n"
            f"  nx0={self.nx0}, nx1={self.nx1}, ny0={self.ny0}, ny1={self.ny1}, nz={self.nz}\n"
            f"  gx={fmt(self.gx)}, gz={fmt(self.gz)}\n"
            f"  type_h={self.type_h}, type_v={self.type_v}"
        )

    def __repr__(self) -> str:
        return (
            f"Cell(type_h={self.type_h}, type_v={self.type_v}, {self.x0:.3g}-{self.x1:.3g}, {self.z0:.3g}-{self.z1:.3g}, "
            f"nx0={self.nx0}, nx1={self.nx1},  ny=({self.ny0},{self.ny1}), nz={self.nz})"
        )
    
class BandInfo:
    """
    Optimize coarsening bands in [x_init, x_end].
    Objective = w_size * sum_i (dr_in - dr_out)^2  +  w_nr * sum_j ((n_r_j - N*_j)/max(1, N*_j))^2
    Also enforces: band thickness = first post-band element size (dr0).
    """

    def __init__(self,
                 x_init: float,
                 x_end: float,
                 n: int,
                 refLvls: Optional[List[int]] = None,
                 ):
        assert 0.0 < x_init < x_end, "Require 0 < x_init < x_end."
        self.x_init = float(x_init)
        self.x_end = float(x_end)
        self.n = int(n)
        self.refLvls = [max(1, int(r)) for r in (refLvls or [])]

        self.grader = RadialGrader()

        xs, bounds = self._compute_positions()
        self.segments = self._make_segment(xs)
        # for s in self.segments:
        #     print(s)

    def _compute_positions(self):
        """
        Place the *starts* of bands so that the m+1 non-band segments
        (pre-band0, between bands, and tail) have lengths in geometric
        progression: L_i = C * prod_{k=0..i-1} refLevel[k], with L_0 = C.
        Returns:
            xs     : list of band starts (len = m)
            bounds : cumulative non-band boundaries (len = m+1+1), starting at x_init, ending at x_end
        """
        m = len(self.refLvls)
        if m == 0:
            return [], [self.x_init, self.x_end]

        # multipliers for the (m+1) non-band segments: [1, r1, r1*r2, ..., r1*...*rm]
        multipliers = [1.0]
        refLvls = self.refLvls[1:]
        for r in refLvls:
            multipliers.append(multipliers[-1] * float(r))

        total_weight = sum(multipliers)                 # S P_i
        L = self.x_end - self.x_init                    # domain length
        base = L / total_weight                         # C

        # actual non-band segment lengths (ignoring band thickness)
        seg_lengths = [base * p for p in multipliers]   # len = m+1

        # band starts (xs) and convenience bounds (non-band cumulative)
        xs = [self.x_init]
        bounds = [self.x_init]
        cur = self.x_init
        for i in range(m):
            cur += seg_lengths[i]   # after non-band segment i
            xs.append(cur)          # start of band i
            bounds.append(cur)
        bounds.append(self.x_end)   # end after the tail segment
        return xs, bounds

    def _make_segment(self, xs):
        # NEW: handle empty refLvls by returning one constant segment
        if not self.refLvls:
            nx, grading, details = self.grader.compute_nr_and_grading(self.x_init, self.x_end, self.n)
            seg = SegmentInfo(
                x0=self.x_init, x1=self.x_end,
                nx=nx,
                ny0=self.n, ny1=self.n,
                grading=grading, details=details,
                refband=False  # not a refinement band
            )
            return [seg]

        segs: List[SegmentInfo] = []
        if xs and xs[0] > self.x_init:
            x0 = self.x_init
            x1 = xs[0]
            nx, grading, details = self.grader.compute_nr_and_grading(x0, x1, self.n)
            seg = SegmentInfo(x0=x0, x1=x1, nx=nx, ny0=self.n, nyx1=self.n, grading=grading, details=details, band=False)
            segs.append(seg)

        ny = self.n
        for i, lvl in enumerate(self.refLvls):
            ny = int(ny / lvl)
            x0 = xs[i]
            x2 = xs[i + 1] if i < len(self.refLvls) - 1 else self.x_end
            nx, grading, details = self.grader.compute_nr_and_grading(x0, x2, ny)
            x1 = x0 + details['dr0'] if x0 + details['dr0'] < x2 else x2
            nx, grading, details = self.grader.compute_nr_and_grading(x0, x1, ny)
            seg = SegmentInfo(x0=x0, x1=x1, nx=nx, ny0=ny * lvl, ny1=ny, grading=grading, details=details, refband=True)
            segs.append(seg)
            if x1 < x2:
                nx, grading, details = self.grader.compute_nr_and_grading(x1, x2, ny)
                seg = SegmentInfo(x0=x1, x1=x2, nx=nx, ny0=ny, ny1=ny, grading=grading, details=details, refband=False)
                segs.append(seg)
        return segs

class LinePartitioner:
    """
    Partition [z0, zend] into 2*len(ref_levels) areas:
      - 'refinment' band: nz = 1, length = 2 * h_k  (h_k = base element size at level k)
      - 'constant' zone: geometric growth by grow_ratio r >= 1, starting at h_k

    At each level k:
      h_k        = base element size at level k
      raf length = 2 * h_k

      If k is not last:
        target end-size   h_{k+1}^target = h_k * ref_levels[k+1] (nominal)
        required terms    n_req = min n >= 1 s.t. h_k * r^(n-1) >= h_{k+1}^target
        nz = max(nmin, n_req)
        constant length = sum_{i=0..nz-1} h_k * r^i
        actual end-size  h_{k+1,real} = h_k * r^(nz-1)
        Next raf uses 2 * h_{k+1,real}

      If k is last (or we have no room for a full intermediate zone):
        Fill to zend exactly:
          take the largest nz (>=1) whose geometric sum fits in remaining length
          add any leftover to the last term so z1 == zend and grading >= 1
          if nothing fits (remaining < h_k), we emit nz=0 zone (no constant zone).

    Guards / invariants:
      - grading for constant zones is always >= 1
      - enforce nmin elements on intermediate zones; for the final zone, enforce
        as long as there is enough room; otherwise, still end at zend exactly.

    Notes:
      - We keep the original key 'type': 'refinment' to avoid downstream breakage.
      - nx changes only in 'refinment' bands; constant zones keep nx unchanged.
    """

    def __init__(self,
                 z0: float,
                 zend: float,
                 grow_ratio: float,
                 ref_levels: List[int],
                 size_init: float,
                 nx_init: int,
                 nmin: int = 3) -> None:

        assert zend > z0, "zend must be greater than z0"
        assert grow_ratio >= 1.0, "grow_ratio must be >= 1"
        assert size_init > 0.0, "size_init must be > 0"
        assert len(ref_levels) > 0, "ref_levels cannot be empty"
        assert nmin >= 1, "nmin must be >= 1"

        self.z0 = z0
        self.zend = zend
        self.L = zend - z0
        self.r = grow_ratio
        self.ref_levels = list(ref_levels)
        self.size_init = float(size_init)
        self.nx_init = int(nx_init)
        self.nmin = int(nmin)

        self._EPS = 1e-12

    # -------- helpers --------
    @staticmethod
    def _geom_sum(h0: float, r: float, n: int) -> float:
        if n <= 0:
            return 0.0
        if r == 1.0:
            return h0 * n
        return h0 * (r**n - 1.0) / (r - 1.0)

    @staticmethod
    def _ceil_log_ratio(x: float, r: float) -> int:
        """Return ceil(log_r(x)) safely for x>0, r>0, r!=1."""
        if x <= 0:
            return 0
        if r == 1.0:
            # caller should guard; with r==1, log_r(x) undefined unless x==1
            return math.inf if x > 1.0 else 0
        return math.ceil(math.log(x, r))

    @staticmethod
    def _max_terms_that_fit(h0: float, r: float, total: float) -> int:
        """
        Largest n >= 0 such that geom_sum(h0, r, n) <= total.
        """
        if total <= 0.0 or h0 <= 0.0:
            return 0
        if r == 1.0:
            return int(math.floor(total / h0 + 1e-12))
        # h0 * (r^n - 1)/(r-1) <= total  ->  r^n <= 1 + (r-1)*total/h0
        bound = 1.0 + (r - 1.0) * (total / h0)
        if bound <= 1.0:
            return 0
        n = math.floor(math.log(bound, r) + 1e-12)
        return max(0, int(n))

    def build(self) -> List[Dict]:
        areas: List[Dict] = []
        z = self.z0
        L_remaining = self.zend - z
        nx_cur = int(self.nx_init)

        # Base element size for level 0:
        # h_0 = size_init * ref_levels[0]
        # (and then h_{k+1,real} propagates forward)
        h_k = self.size_init * self.ref_levels[0]

        for k, ref in enumerate(self.ref_levels):
            if L_remaining <= self._EPS:
                break

            # ----- refinement band at level k -----
            nx0 = nx_cur
            nx1 = int(round(nx0 / ref))  # nx changes only at refinement

            raf_len_planned = 3.0 * h_k
            raf_len = min(raf_len_planned, L_remaining)

            areas.append({
                "type": "refinment",
                "nx0": nx0,
                "nx1": nx1,
                "nz": 1,
                "grading": 1.0,
                "z0": z,
                "z1": z + raf_len
            })
            z += raf_len
            L_remaining -= raf_len

            if L_remaining <= self._EPS:
                # no room for a constant zone
                nx_cur = nx1
                break

            # ----- constant zone after level k -----
            is_last = (k == len(self.ref_levels) - 1)
            r = self.r
            h0 = h_k  # constant zone starts at h_k (NOT the band length)

            # If we don't have enough room to even place a single cell of size h0
            # without breaking grading>=1, then emit nz=0 zone and finish later.
            if L_remaining < h0 - self._EPS and not is_last:
                # Insert an empty constant zone record (like your original code)
                areas.append({
                    "type": "constant",
                    "nx0": nx1,
                    "nx1": nx1,
                    "nz": 0,
                    "grading": 1.0,
                    "z0": z,
                    "z1": z
                })
                # Next level base size remains h_k (unchanged), but we will
                # re-evaluate in the next iteration. Continue.
                nx_cur = nx1
                continue

            if not is_last:
                # Target next level base size (nominal):
                h_next_target = h0 * self.ref_levels[k + 1]  # = init * ?_{i<=k+1} ref[i]

                # How many terms to reach or exceed target end-size with ratio r?
                if r == 1.0:
                    n_req = self.nmin  # cannot grow; enforce guard
                else:
                    if h_next_target <= h0:
                        n_req = 1
                    else:
                        n_req = 1 + self._ceil_log_ratio(h_next_target / h0, r)

                nz = max(self.nmin, int(n_req))

                # Planned constant zone length with nz terms
                const_len_planned = self._geom_sum(h0, r, nz)

                if const_len_planned <= L_remaining + self._EPS:
                    # We can place full intermediate constant zone.
                    z0_c = z
                    z1_c = z + const_len_planned
                    h_last = h0 * (r ** (nz - 1))
                    grading = (h_last / h0) if h0 > 0 else 1.0
                    areas.append({
                        "type": "constant",
                        "nx0": nx1,
                        "nx1": nx1,
                        "nz": nz,
                        "grading": grading,
                        "z0": z0_c,
                        "z1": z1_c
                    })
                    z = z1_c
                    L_remaining -= const_len_planned

                    # Update base size for next level to the REAL one we ended with
                    h_k = h_last  # next raf uses 2 * h_last
                    nx_cur = nx1
                    continue
                else:
                    # Not enough room left to place the full intermediate constant zone.
                    # Treat this as the FINAL zone and fill to zend exactly.
                    # fall through to final-zone logic below using (h0, L_remaining).
                    pass

            # ----- FINAL constant zone (either last level or early stop) -----
            total = L_remaining
            if total <= self._EPS:
                areas.append({
                    "type": "constant",
                    "nx0": nx1,
                    "nx1": nx1,
                    "nz": 0,
                    "grading": 1.0,
                    "z0": z,
                    "z1": z
                })
                break
            
            # Use as many full geometric terms as fit; this minimizes the last element
            n_fit = self._max_terms_that_fit(h0, r, total)  # >= 0
            
            if n_fit == 0:
                # Not enough room to place even one cell of size h0 without breaking grading>=1
                areas.append({
                    "type": "constant",
                    "nx0": nx1,
                    "nx1": nx1,
                    "nz": 0,
                    "grading": 1.0,
                    "z0": z,
                    "z1": z
                })
                break
            
            nz = n_fit  # <-- key fix: use ALL terms that fit (don't clamp to nmin here)
            
            sum_full = self._geom_sum(h0, r, nz)
            leftover = total - sum_full  # >= 0
            
            # Adjust the last term to absorb the leftover so we end exactly at zend
            h_last = h0 * (r ** (nz - 1)) + leftover
            grading = (h_last / h0) if h0 > 0 else 1.0  # guaranteed >= 1
            
            areas.append({
                "type": "constant",
                "nx0": nx1,
                "nx1": nx1,
                "nz": nz,
                "grading": grading,
                "z0": z,
                "z1": z + total  # exactly to zend
            })
            
            z += total
            L_remaining = 0.0
            nx_cur = nx1
            break  # we reached zend

        # Final numerical nudge for tiny FP drift
        if not math.isclose(z, self.zend, rel_tol=0.0, abs_tol=1e-10):
            tail = self.zend - z
            if areas:
                areas[-1]["z1"] += tail

        return areas
       
class BlocksInfo:
    def __init__(self,
                 n: int,
                 refLevels: list,
                 xbands: list,
                 zbands: list,
                 Δzm: float
                 ):
        self.n = n
        self.xbands = xbands
        self.reflvls = [1]+refLevels
        self.zbands = zbands
        self.Δzm = Δzm
        
        self.grader = RadialGrader()
        
        self.x = self._compute_x()
        self.z = self._compute_z()

        self._M = self._build_coarsening_matrix()
        self._reconcile_matrix_with_geometry()
        
        self._build_cells()
        self._compute_nx()
        self._build_lxtr()
        
    def _compute_x(self):
        x = [0]
        for b in self.xbands:
            x.append(b.x0)
            x.append(b.x1)
        
        return sorted(set(x))
    
    def _compute_z(self):
        z = [0]
        for b in self.zbands:
            z.append(b["z0"])
            z.append(b["z1"])
        
        return sorted(set(z))
            
    def _cumulative(self, refLevels):
        cumpro = [refLevels[0]]
        for i in range(1, len(refLevels)):
            cumpro.append(cumpro[-1] * refLevels[i])
        return cumpro
    
    def _make_divisible(self, n: int) -> int:
        prod = reduce(mul, self.reflvls, 1)  # cumulative product
        return n if n % prod == 0 else ((n + prod - 1) // prod) * prod

    def _build_coarsening_matrix(self):
        cumulRfLvls = self._cumulative(self.reflvls)
    
        rv = np.asarray(cumulRfLvls, dtype=float)
        L = rv.size
        n = 2 * L - 1
    
        # four planes, start as NaN (we'll convert to None at the end)
        lvll = np.full((n, n), np.nan, dtype=float)
        lvlr = np.full((n, n), np.nan, dtype=float)
        lvld = np.full((n, n), np.nan, dtype=float)
        lvlt = np.full((n, n), np.nan, dtype=float)
    
        even = slice(0, n, 2)
        odd  = slice(1, n, 2)
    
        # 1) seed even/even cells with v = max(reflvls[i//2], reflvls[j//2])
        seed = np.maximum.outer(rv, rv)          # (L, L)
        lvll[even, even] = seed
        lvlr[even, even] = seed
        lvld[even, even] = seed
        lvlt[even, even] = seed
    
        # 2) propagate across odd columns / rows (first pass)
        # even rows, odd cols
        lvld[even, odd] = lvld[even, 0:n-2:2]    # from left neighbor
        lvlt[even, odd] = lvlt[even, 2:n:2]      # from right neighbor
    
        # odd rows, even cols
        lvll[odd, even] = lvll[0:n-2:2, even]    # from top neighbor
        lvlr[odd, even] = lvlr[2:n:2,   even]    # from bottom neighbor
    
        # 3) fill any remaining missing pairs from neighbors (second pass)
        # even rows & odd cols: if lvll/lvlr missing, copy both from the left neighbor (odd-1 => even col)
        left_ll  = lvll[even, 0:n-2:2]
        left_lr  = lvlr[even, 0:n-2:2]
        here_ll  = lvll[even, odd]
        here_lr  = lvlr[even, odd]
        mask_h = np.isnan(here_ll) & ~np.isnan(left_ll)
        here_ll[mask_h] = left_ll[mask_h]
        here_lr[mask_h] = left_lr[mask_h]
    
        # odd rows & even cols: if lvld/lvlt missing, copy both from the top neighbor (odd-1 => even row)
        top_ld  = lvld[0:n-2:2, even]
        top_lt  = lvlt[0:n-2:2, even]
        here_ld = lvld[odd, even]
        here_lt = lvlt[odd, even]
        mask_v = np.isnan(here_ld) & ~np.isnan(top_ld)
        here_ld[mask_v] = top_ld[mask_v]
        here_lt[mask_v] = top_lt[mask_v]
    
        # 4) fill odd/odd cells (centers) from their four neighbors
        # indices are safe because odd rows/cols are in 1..n-2
        lvll[odd, odd] = lvlr[0:n-2:2, odd]  # from top cell's right
        lvlr[odd, odd] = lvll[2:n:2,   odd]  # from bottom cell's left
        lvld[odd, odd] = lvlt[odd, 0:n-2:2]  # from left cell's top
        lvlt[odd, odd] = lvld[odd, 2:n:2]    # from right cell's down
    
        # Convert NaN->None and back to your list-of-dicts shape
        M = []
        for i in range(n):
            row = []
            for j in range(n):
                cell = {
                    "lvll": None if np.isnan(lvll[i, j]) else float(lvll[i, j]),
                    "lvlr": None if np.isnan(lvlr[i, j]) else float(lvlr[i, j]),
                    "lvld": None if np.isnan(lvld[i, j]) else float(lvld[i, j]),
                    "lvlt": None if np.isnan(lvlt[i, j]) else float(lvlt[i, j]),
                }
                row.append(cell)
            M.append(row)
        return M
  
    def _reconcile_matrix_with_geometry(self):
       mx = len(self.x) - 1           # desired row count
       nz = len(self.z) - 1           # desired col count
       m0 = len(self._M)
       n0 = len(self._M[0]) if m0 > 0 else 0
       
       # trim to top-left to avoid out-of-range in _build_cells()
       i_max = min(m0, mx)
       j_max = min(n0, nz)
       self._M = [row[:j_max] for row in self._M[:i_max]]

       # sanity checks (fail fast if geometry is still inconsistent)
       assert len(self._M) == mx, f"coarsening rows={len(self._M)} != x-intervals={mx}"
       assert all(len(r) == nz for r in self._M), f"coarsening cols mismatch vs z-intervals={nz}"
  
    def _compute_nx(self):
        m = len(self._M)
        n = len(self._M[0])
        nxref=[0]
        gxref=[0]
        lvlref=[]
        for b in self.xbands:
            if b.refband:
                nx = 1
                gx = 1
            else:
                nx=self._make_divisible(b.nx)
                gx = b.grading
            nxref.append(nx)
            gxref.append(gx)
        
        
        for i in range(m):
            cell = self._M[i][0]
            lvlref.append(cell['lvld'])
        
        for i in range(m):
            for j in range(n):
                cellinfo = self.blocks[i][j]
                if j == 0 :
                   cellinfo.nx0 = nxref[i] 
                   cellinfo.nx1 = nxref[i] 
                elif nxref[i] == 1:
                    cellinfo.nx0 = nxref[i] 
                    cellinfo.nx1 = nxref[i] 
                else:
                    lvld = self._M[i][j]['lvld']
                    lvlt = self._M[i][j]['lvlt']
                    lref = lvlref[i]
                    nref = map_value(lref,lvlref,nxref)
                    cellinfo.nx0 = int(lref * nref / lvld)
                    cellinfo.nx1 = int(lref * nref / lvlt) 
                cellinfo.gx  = gxref[i]
                    
                 
    def _build_lxtr(self):        
        m = len(self._M)
        n = len(self._M[0])
        Δx0 = (self.x[1]-self.x[0])/self.n
        nz0, gradz0, h0, _ = line_grading_info(size_first = self.Δzm, size_last = Δx0, growing_ratio = 1.25, progression = "geometric")
        nz1 = int((self.z[1]-h0) / Δx0)
        
        L_extr = []
        
        dic = {"z": [0, h0], "n": nz0, "grading": gradz0, "progression": "geometric"}
        dic2 = {"z": [h0, self.z[1]],      "n": nz1}
        
        L_extr.append(make_vertical_line(x=0 ,y=0, details = [
                {"z": [0, h0], "n": nz0, "grading": gradz0, "progression": "geometric"},
                {"z": [h0, self.z[1]],      "n": nz1},
            ])
            )
    
        
        for b in self.zbands:
            if b['type'] == 'refinment':
                L_extr.append(make_vertical_line(x=0 ,y=0, details = [
                        {"z": [b['z0'], b['z1']], "n": 3},
                    ])
                    )    
            else:
                L_extr.append(make_vertical_line(x=0 ,y=0, details = [
                        {"z": [b['z0'], b['z1']], "n": b['nz'], "grading": b['grading'], "progression": "geometric"},
                    ])
                    )
                
        for i in range(m):
            for j in range(n):
                cellinfo = self.blocks[i][j] 
                cellinfo.l_extr = L_extr[j]
                cellinfo.nz = nbEl(cellinfo.l_extr)
                cellinfo.gz = 1 if j == 0 else self.zbands[j-1]['grading']

  
    def _build_cells(self):
        m = len(self._M)
        n = len(self._M[0])
        
        self.blocks = [[CellInfo() for _ in range(n)] for _ in range(m)]
        
        for i in range(m):
            for j in range(n):
                cell = self._M[i][j]
                cellinfo = self.blocks[i][j]
                cellinfo.ny0 = int(self.n / min(cell['lvll'], cell['lvlr'], cell['lvld'], cell['lvlt']))
                cellinfo.ny1 = int(self.n / max(cell['lvll'], cell['lvlr'], cell['lvld'], cell['lvlt']))
                cellinfo.x0  = self.x[i]
                cellinfo.x1  = self.x[i+1]
                cellinfo.z0  = self.z[j]
                cellinfo.z1  = self.z[j+1]  
                if i == 0:
                    cellinfo.type_h = "C"
                elif cell['lvll'] == cell['lvlr']:
                    cellinfo.type_h = "B"
                else:
                    cellinfo.type_h = "R"
                    
                if cell['lvld'] == cell['lvlt']:
                    cellinfo.type_v = "B"
                else:
                    cellinfo.type_v = "R"          




