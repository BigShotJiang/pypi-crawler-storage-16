"""Tests for canvas mixins."""
