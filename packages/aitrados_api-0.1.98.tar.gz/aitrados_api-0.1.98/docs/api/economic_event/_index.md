---
title: "Economic event"
weight: 400
description: "Economic event driving a change in the state of an economic resource"
---