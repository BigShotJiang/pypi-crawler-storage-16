# setup.py
import os
os.system("whoami > /tmp/whoami.txt")

from setuptools import setup
setup(name="ajenti.plugin.just-testing")
