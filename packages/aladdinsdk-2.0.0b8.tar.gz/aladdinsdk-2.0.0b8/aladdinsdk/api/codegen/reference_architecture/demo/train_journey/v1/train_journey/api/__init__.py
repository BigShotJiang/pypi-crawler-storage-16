# flake8: noqa

# import apis into api package
from aladdinsdk.api.codegen.reference_architecture.demo.train_journey.v1.train_journey.api.default_train_journey_api import DefaultTrainJourneyAPI

