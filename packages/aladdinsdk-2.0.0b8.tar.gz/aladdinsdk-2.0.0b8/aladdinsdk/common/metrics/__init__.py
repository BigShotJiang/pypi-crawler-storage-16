from aladdinsdk.common.metrics.domain import update_domain_sdk_metrics_suffix  # noqa: F401
