::: albert.collections.data_templates.DataTemplateCollection
