::: albert.resources.batch_data
