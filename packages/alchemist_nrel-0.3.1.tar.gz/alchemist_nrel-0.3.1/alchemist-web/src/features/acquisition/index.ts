/**
 * Acquisition feature exports
 */
export { AcquisitionPanel } from './AcquisitionPanel';
