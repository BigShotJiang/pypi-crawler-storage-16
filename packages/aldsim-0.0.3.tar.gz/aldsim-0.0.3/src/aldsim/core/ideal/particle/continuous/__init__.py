from .plugflow import PlugFlowSpatial
from .wellmixed import WellMixedSpatial
