# ALEPH
ALEPH is a bioinformatics tool to generate fragment-based libraries for molecular replacement

ALEPH is a bioinformatics tool to generate customised fold libraries for fragment-based molecular replacement.
It provides several algorithms to interpret and analyse protein structures.

References:

ALEPH: a network-oriented approach for the generation of fragment-based
libraries and for structure interpretation
Medina A, Trivino J, Borges R, Millan C , Uson I and Sammito MD
(2019) Acta Cryst. D Study Weekend
                        
Exploiting tertiary structure through local folds for ab initio phasing
Sammito M, Millan C, Rodriguez DD, M. de Ilarduya I, Meindl K, De Marino I,
Petrillo G, Buey RM, de Pereda JM, Zeth K, Sheldrick GM and Uson I
(2013) Nat Methods. 10, 1099-1101.
                        
Email support: alephbugs@gmail.com
Bug tracking: https://gitlab.com/arcimboldo-team/ALEPH/-/issues
