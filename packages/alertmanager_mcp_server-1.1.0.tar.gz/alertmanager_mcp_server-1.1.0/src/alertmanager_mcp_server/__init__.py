"""Prometheus Alertmanager MCP Server.

A Model Context Protocol (MCP) server that enables AI assistants to query
and integrate with Promeheus Alertmanager.
"""

__version__ = "0.0.1"
