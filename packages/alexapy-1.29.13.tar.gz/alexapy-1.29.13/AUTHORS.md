# Contributions to `alexapy`

## Owners

- Keaton Taylor [GitLab](https://gitlab.com/keatontaylor) [GitHub](https://github.com/keatontaylor)

## Maintainers

- Alan Tse [GitLab](https://gitlab.com/alandtse) [GitHub](https://github.com/alandtse)

## Contributors

- Brian Hanifin [GitLab](https://gitlab.com/brianhanifin) [GitHub](https://github.com/brianhanifin)
- Chris Nussbaum [GitHub](https://github.com/nuttytree)
- Brady Mulhollem [GitHub](https://github.com/blm126)
- Frederic Chastagnol [GitHub](https://github.com/Fredo70) [GitLab](https://gitlab.com/Fredo70)
- Nathan Spencer [GitHub](https://github.com/natekspencer) [GitLab](https://gitlab.com/natekspencer)
