
class GlobalVariables:
    is_stop_monkey = False
    activity = ''
    mem_list = None
    package = None
    is_monkey = False
    is_native = False
