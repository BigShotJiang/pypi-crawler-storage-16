2025-11-25 Version: 2.1.0
- Support API BatchTranslateForHtml.
- Update API SubmitHtmlTranslateTask: add request parameters ext.config.callbackUrl.
- Update API TextTranslate: add request parameters ext.agent.


2025-10-14 Version: 2.0.1
- Update API SubmitDocTranslateTask: add request parameters ext.config.


2025-09-23 Version: 2.0.0
- Update API BatchTranslate: add request parameters appName.
- Update API BatchTranslate: add request parameters ext.config.
- Update API SubmitDocTranslateTask: delete request parameters ext.examples.
- Update API SubmitDocTranslateTask: delete request parameters ext.sensitives.
- Update API SubmitDocTranslateTask: delete request parameters ext.textTransform.
- Update API SubmitHtmlTranslateTask: add request parameters ext.config.
- Update API SubmitLongTextTranslateTask: add request parameters ext.config.
- Update API TextTranslate: add request parameters ext.config.


2025-09-22 Version: 1.2.0
- Support API TermEdit.
- Support API TermQuery.


2025-09-22 Version: 1.1.5
- Generated python 2025-07-07 for AnyTrans.

2025-09-22 Version: 1.1.4
- Generated python 2025-07-07 for AnyTrans.

2025-09-22 Version: 1.1.3
- Generated python 2025-07-07 for AnyTrans.

2025-09-22 Version: 1.1.2
- Generated python 2025-07-07 for AnyTrans.

2025-09-22 Version: 1.1.1
- Generated python 2025-07-07 for AnyTrans.

2025-09-22 Version: 1.1.0
- Support API GetDocTranslateTask.
- Support API SubmitDocTranslateTask.


2025-09-11 Version: 1.0.0
- Generated python 2025-07-07 for AnyTrans.

