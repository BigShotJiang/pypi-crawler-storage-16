2025-11-19 Version: 2.10.0
- Support API CreateSecurityIPGroup.
- Support API DeleteSecurityIPGroup.
- Support API DescribeSecurityIPGroup.
- Support API DescribeSecurityIPGroupRelation.
- Support API ModifySecurityIPGroup.
- Support API ModifySecurityIPGroupRelation.


2025-11-06 Version: 2.9.2
- Generated python 2020-01-16 for DAS.

2025-11-04 Version: 2.9.1
- Generated python 2020-01-16 for DAS.

2025-11-04 Version: 2.9.0
- Support API GetDasAgentSSE.


2025-10-28 Version: 2.8.4
- Update API DescribeSlowLogHistogramAsync: add response parameters Body.Data.Data.TotalCount.
- Update API DescribeSlowLogHistogramAsync: add response parameters Body.Data.Data.Item.$.InsRole.
- Update API DescribeSlowLogHistogramAsync: add response parameters Body.Data.Data.Item.$.TotalCount.
- Update API DescribeSlowLogHistogramAsync: add response parameters Body.Data.Data.Item.$.InsItems.$.TotalCount.


2025-09-23 Version: 2.8.3
- Update API DescribeSlowLogRecords: add response parameters Body.Data.Logs.$.ClientIp.
- Update API DescribeSlowLogRecords: add response parameters Body.Data.Logs.$.Cmd.
- Update API DescribeSlowLogRecords: add response parameters Body.Data.Logs.$.DbId.
- Update API DescribeSlowLogRecords: add response parameters Body.Data.Logs.$.NodeId.
- Update API DescribeSlowLogRecords: add response parameters Body.Data.Logs.$.OriginTime.
- Update API DescribeSlowLogRecords: add response parameters Body.Data.Logs.$.RequestSize.
- Update API DescribeSlowLogRecords: add response parameters Body.Data.Logs.$.ResponseSize.
- Update API DescribeSlowLogRecords: add response parameters Body.Data.Logs.$.Rt.
- Update API DescribeSlowLogStatistic: add response parameters Body.Data.Data.Logs.$.AvgRequestSize.
- Update API DescribeSlowLogStatistic: add response parameters Body.Data.Data.Logs.$.AvgResponseSize.
- Update API DescribeSlowLogStatistic: add response parameters Body.Data.Data.Logs.$.AvgRt.
- Update API DescribeSlowLogStatistic: add response parameters Body.Data.Data.Logs.$.ClientIp.
- Update API DescribeSlowLogStatistic: add response parameters Body.Data.Data.Logs.$.Cmd.
- Update API DescribeSlowLogStatistic: add response parameters Body.Data.Data.Logs.$.DbId.
- Update API DescribeSlowLogStatistic: add response parameters Body.Data.Data.Logs.$.MaxRequestSize.
- Update API DescribeSlowLogStatistic: add response parameters Body.Data.Data.Logs.$.MaxResponseSize.
- Update API DescribeSlowLogStatistic: add response parameters Body.Data.Data.Logs.$.MaxRt.
- Update API DescribeSlowLogStatistic: add response parameters Body.Data.Data.Logs.$.TotalCount.


2025-09-09 Version: 2.8.2
- Update API DescribeSqlLogRecords: add response parameters Body.Data.Items.SQLLogRecord.$.TableName.
- Update API ModifySqlLogConfig: add response parameters Body.Data.SqlLogSource.


2025-08-21 Version: 2.8.1
- Update API DescribeHotBigKeys: add response parameters Body.Data.HighTrafficKeyMsg.
- Update API DescribeHotBigKeys: add response parameters Body.Data.HighTrafficKeys.
- Update API DescribeHotBigKeys: add response parameters Body.Data.HotKeys.$.Size.
- Update API DescribeHotKeys: add response parameters Body.Data.$.Category.
- Update API DescribeHotKeys: add response parameters Body.Data.$.InBytes.
- Update API DescribeHotKeys: add response parameters Body.Data.$.NodeId.
- Update API DescribeHotKeys: add response parameters Body.Data.$.OutBytes.
- Update API DescribeTopHotKeys: add response parameters Body.Data.$.Category.
- Update API DescribeTopHotKeys: add response parameters Body.Data.$.InBytes.
- Update API DescribeTopHotKeys: add response parameters Body.Data.$.OutBytes.


2025-07-24 Version: 2.8.0
- Support API DescribeErrorLogRecords.


2025-07-22 Version: 2.7.4
- Update API GetDasSQLLogHotData: add response parameters Body.Data.List.$.NodeId.


2025-06-25 Version: 2.7.3
- Generated python 2020-01-16 for DAS.

2025-06-24 Version: 2.7.2
- Generated python 2020-01-16 for DAS.

2025-06-24 Version: 2.7.2
- Generated python 2020-01-16 for DAS.

2025-06-05 Version: 2.7.1
- Update API DescribeSqlLogStatistic: add response parameters Body.Data.TotalSqlSize.
- Update API DescribeSqlLogTasks: add response parameters Body.Data.List.$.InnerResult.


2025-05-20 Version: 2.7.0
- Support API DescribeQueryExplain.
- Support API DescribeSlowLogRecords.


2025-04-01 Version: 2.6.3
- Update API DescribeSlowLogStatistic: add response parameters Body.Data.Data.Logs.$.RuleId.
- Update API DescribeSqlLogTask: add response parameters Body.Data.Queries.$.SqlCommand.


2025-02-28 Version: 2.6.1
- Update API ModifySqlLogConfig: add param EnableAudit.


2024-11-29 Version: 2.5.0
- Support API CreateLatestDeadLockAnalysis.
- Support API GetDeadLockDetail.
- Support API GetDeadLockHistory.
- Support API GetDeadlockHistogram.
- Delete API CreateAdamBenchTask.
- Delete API StopCloudBenchTask.
- Delete API SyncHDMAliyunResource.
- Update API GetAsyncErrorRequestStatResult: update response param.


2024-07-23 Version: 2.4.4
- Update API DescribeSqlLogConfig: update response param.


2024-07-03 Version: 2.4.3
- Update API DescribeSqlLogTask: update response param.


2024-06-13 Version: 2.4.2
- Update API DescribeCacheAnalysisJob: update response param.
- Update API DescribeSqlLogRecords: update response param.
- Update API DescribeSqlLogTask: update response param.


2024-05-15 Version: 2.4.1
- Update API GetStorageAnalysisResult: update response param.


2024-04-25 Version: 2.4.0
- Support API CreateSqlLogTask.
- Support API DescribeSqlLogConfig.
- Support API DescribeSqlLogRecords.
- Support API DescribeSqlLogStatistic.
- Support API DescribeSqlLogTask.
- Support API DescribeSqlLogTasks.
- Support API ModifySqlLogConfig.
- Update API GetPfsSqlSample: update param EndTime.
- Update API GetPfsSqlSample: update param InstanceId.
- Update API GetPfsSqlSample: update param StartTime.
- Update API ModifyAutoScalingConfig: update param Bandwidth.
- Update API ModifyAutoScalingConfig: update response param.


2024-02-27 Version: 2.3.2
- Update API GetPfsSqlSample: update param EndTime.
- Update API GetPfsSqlSample: update param InstanceId.
- Update API GetPfsSqlSample: update param StartTime.
- Update API ModifyAutoScalingConfig: update param Bandwidth.
- Update API ModifyAutoScalingConfig: update response param.


2024-02-21 Version: 2.3.1
- Generated python 2020-01-16 for DAS.

2023-12-12 Version: 2.3.0
- Generated python 2020-01-16 for DAS.

2023-12-08 Version: 2.2.0
- Generated python 2020-01-16 for DAS.

2023-11-17 Version: 2.1.2
- Generated python 2020-01-16 for DAS.

2023-08-25 Version: 2.1.1
- Generated python 2020-01-16 for DAS.

2023-08-13 Version: 2.1.0
- Generated python 2020-01-16 for DAS.

2023-07-11 Version: 2.0.39
- Add action DescribeAutoScalingHistory.

2023-05-25 Version: 2.0.38
- Add action GetDasSQLLogHotData.

2023-05-25 Version: 2.0.37
- Add user for the response of GetQueryOptimizeDataStats.

2023-03-10 Version: 2.0.36
- Public CreateKillInstanceSessionTaskWithMaintainUser.

2023-03-09 Version: 2.0.35
- Public GetMySQLAllSessionAsync.

2023-03-06 Version: 2.0.34
- Change CreateKillInstanceSessionTask parameter type.

2023-03-02 Version: 2.0.33
- Public CreateKillInstanceSessionTask and GetKillInstanceSessionTaskResult API.

2023-01-12 Version: 2.0.32
- Public GetEventSubscription API.

2023-01-10 Version: 2.0.31
- Public SetEventSubscription API.

2022-09-19 Version: 2.0.29
- ADD GetRedisSession.

2022-08-17 Version: 2.0.27
- ADD GetFullRequestSampleByInstanceId.

2022-08-01 Version: 2.0.26
- Del GetGeneralAbnormalEventsCount.

2022-07-29 Version: 2.0.25
- Del GetGeneralAbnormalEventsCount.

2022-07-28 Version: 2.0.24
- Add GetGeneralAbnormalEventsCount.

2022-07-14 Version: 2.0.21
- Add UpdateAutoSqlOptimizeStatus API.

2022-07-13 Version: 2.0.20
- Add UpdateAutoSqlOptimizeStatus API.

2022-05-20 Version: 2.0.18
- Dbgateway support delete api.


2022-04-28 Version: 2.0.17
- EventCenter support event name filter.


2022-04-01 Version: 2.0.16
- FIX GetAsyncErrorRequestStatResult PARAM TYPE.


2022-03-18 Version: 2.0.15
- FIX GetRequestDiagnosisPage PARAM TYPE.


2022-02-25 Version: 2.0.10
- FIX GetRequestDiagnosisPage PARAM TYPE.


2022-01-27 Version: 2.0.7
- Supported query optimize open API.

2021-12-28 Version: 2.0.6
- Fixed useless variables.

2021-12-06 Version: 2.0.5
- Fixed useless variables.

2021-11-17 Version: 2.0.4
- Fixed useless variables.

2021-11-04 Version: 2.0.3
- Fixed useless variables.

2021-11-03 Version: 2.0.2
- Fixed useless variables.

2021-11-02 Version: 2.0.1
- Fixed useless variables.

2021-03-31 Version: 2.0.0
- Generated python 2020-01-16 for DAS.

2020-11-30 Version: 1.1.0
- Support new API GetAutonomousNotifyEvents and GetAutonomousNotifyEventDetail.

