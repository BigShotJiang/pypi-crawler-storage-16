2025-11-10 Version: 1.1.0
- Support API ApiMcpServerValidateHcl.
- Support API CreateApiMcpServer.
- Support API DeleteApiMcpServer.
- Support API GenerateCLICommand.
- Support API GetApiDefinition.
- Support API GetApiMcpServer.
- Support API GetProductEndpoints.
- Support API ListApiDefinitions.
- Support API ListApiMcpServerSystemTools.
- Support API ListApiMcpServers.
- Support API UpdateApiMcpServer.


2025-02-08 Version: 1.0.0
- Generated python 2024-11-30 for OpenAPIExplorer.

