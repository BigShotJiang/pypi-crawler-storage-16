# pylint: disable=C0103

""" Internal package state """


nltk_punkt_downloaded = False
