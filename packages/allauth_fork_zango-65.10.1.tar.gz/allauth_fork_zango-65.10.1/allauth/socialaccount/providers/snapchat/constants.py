PROVIDER_ID = "snapchat"


class Scope:
    EXTERNAL_ID = "https://auth.snapchat.com/oauth2/api/user.external_id"
    DISPLAY_NAME = "https://auth.snapchat.com/oauth2/api/user.display_name"
    BITMOJI = "https://auth.snapchat.com/oauth2/api/user.bitmoji.avatar"
