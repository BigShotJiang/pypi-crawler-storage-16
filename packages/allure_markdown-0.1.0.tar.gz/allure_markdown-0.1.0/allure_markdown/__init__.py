__version__ = "0.1.0"

# Import pytest plugin to make it discoverable
from . import pytest_plugin

# Import main modules
from .utils.parser import scan_allure_results, parse_test_results, get_allure_results
from .utils.report_generator import generate_markdown_report
