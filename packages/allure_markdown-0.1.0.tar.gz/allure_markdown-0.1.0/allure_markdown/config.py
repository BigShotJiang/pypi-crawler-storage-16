class _Config:
    title = 'Allure Markdown Report'
    description = "This is a markdown report generated from Allure metadata."
    metadata = "allure-results"
    output = "allure_markdown_report.md"


config = _Config()
