"""Feature extraction modules for scoring candidate peptides."""
