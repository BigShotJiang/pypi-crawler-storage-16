"""Visualization tools for scoring diagnostics."""
