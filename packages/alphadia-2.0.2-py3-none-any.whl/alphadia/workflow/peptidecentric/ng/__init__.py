"""Module for NG (Next Generation) peptide-centric workflow."""
