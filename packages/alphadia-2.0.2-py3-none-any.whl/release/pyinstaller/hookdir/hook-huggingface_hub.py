print("==================================")
print("hook-huggingface_hub.py")
print("==================================")

module_collection_mode = "py"
