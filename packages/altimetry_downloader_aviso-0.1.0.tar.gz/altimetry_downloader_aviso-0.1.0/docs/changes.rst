Changelog
=========


0.1.0 (2025-12-10)
------------------

This version is the first beta version of the downloader. It introduces the three main
features of the CLI and Python interfaces:

* summary
* details
* get

Only SWOT mission datasets can be retrieved in this version. Additionally, the available
filters for selecting granules are limited to product version, temporal extent, and
half-orbit number.
