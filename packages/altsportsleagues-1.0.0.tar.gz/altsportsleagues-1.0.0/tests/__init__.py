"""
Tests for AltSportsLeagues Python SDK
"""
