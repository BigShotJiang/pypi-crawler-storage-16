"""
Module contains a mock AmadeusModel class.
"""

# class MockAmadeusModel:
#    """
#    Class contains a mock AmadeusModel class for testing purposes.
#    """

#    def __init__(self, components, time_interval):
#        self.components = components
#        self.time_interval = time_interval

#    def get_components_with_carbon(self):
#        """
#        Method returns mock energy and carbon emissions data.
#        """

#        self.components[0].energy_consumed = [0.5, 0.5]
#        self.components[0].carbon_emitted = [0.5, 0.5]

#        return self.components
