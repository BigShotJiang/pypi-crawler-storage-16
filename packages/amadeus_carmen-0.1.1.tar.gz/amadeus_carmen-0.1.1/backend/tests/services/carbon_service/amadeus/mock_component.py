"""
Module contains a mock Component class.
"""

# class MockPod:
#    """
#    Class contains a mock Pod class for testing purposes.
#    Acts as a mock for the individual pod classes used in the AmadeusModel class.
#    """
#
#    def __init__(self, time_interval):
#        self.time_interval = time_interval

#    def get_pod_with_carbon(self, pod):
#        """
#        Method returns the pod with the carbon emissions and energy values.
#        """
#        pod.energy_consumed = [10, 40]
#        pod.carbon_emitted = [10, 80]
#        return pod
