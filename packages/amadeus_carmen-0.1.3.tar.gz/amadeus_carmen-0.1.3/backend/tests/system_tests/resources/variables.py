HOST = "https://carbon-measurement-engine.forge.amadeus.net/api"  # Or "http://127.0.0.1:8000/api" to test new versions of the tool before it's gets deployed
APPLICATION = "Carbon-Measurement-Engine"
PAAS = "rnd-ne-ima02a"
NAMESPACE = "carbon-engine-prod"
PYTHONLIBPATH = "../../../../.venv/Lib"
