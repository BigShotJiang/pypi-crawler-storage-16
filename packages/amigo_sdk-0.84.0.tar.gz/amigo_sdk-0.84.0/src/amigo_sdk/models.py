from .generated.model import *  # noqa: F403
