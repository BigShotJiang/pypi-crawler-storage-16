"""Core module for configuration and utilities."""

from .config import ConfigManager

__all__ = ["ConfigManager"]
