# AMSDAL Rest API Server

[![PyPI - Version](https://img.shields.io/pypi/v/amsdal_server.svg)](https://pypi.org/project/amsdal_server)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/amsdal_server.svg)](https://pypi.org/project/amsdal_server)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#AMSDAL-End-User-License-Agreement)

## Installation

```console
pip install amsdal_server
```

## AMSDAL End User License Agreement

**Version:** 1.0

**Last Updated:** October 31, 2023

### PREAMBLE

This Agreement is a legally binding agreement between you and AMSDAL regarding the Library. Read this Agreement carefully before accepting it, or downloading or using the Library.

By downloading, installing, running, executing, or otherwise using the Library, by paying the License Fees, or by explicitly accepting this Agreement, whichever is earlier, you agree to be bound by this Agreement without modifications or reservations.

If you do not agree to be bound by this Agreement, you shall not download, install, run, execute, accept, use or permit others to download, install, run, execute, accept, or otherwise use the Library.

If you are acting for or on behalf of an entity, then you accept this Agreement on behalf of such entity and you hereby represent that you are authorized to accept this Agreement and enter into a binding agreement with us on such entity’s behalf.

1. **INTERPRETATION**

1.1. The following definitions shall apply, unless otherwise expressly stated in this Agreement:


“**Additional Agreement**” means a written agreement executed between you and us that supplements and/or modifies this Agreement by specifically referring hereto.

“**Agreement**” means this AMSDAL End User License Agreement as may be updated or supplemented from time to time.

“**AMSDAL**”, “**we**”, “**us**” means AMSDAL INC., a Delaware corporation having its principal place of business in the State of New York.

“**Communications**” means all and any notices, requests, demands and other communications required or may be given under the terms of this Agreement or in connection herewith.

“**Consumer**” means, unless otherwise defined under the applicable legislation, a person who purchases or uses goods or services for personal, family, or household purposes.

“**Documentation**” means the technical, user, or other documentation, as may be updated from time to time, such as manuals, guidelines, which is related to the Library and provided or distributed by us or on our behalf, if any.

“**Free License Plan**” means the License Plan that is provided free of charge, with no License Fee due.

“**Library**” means the AMSDAL Framework and its components, as may be updated from time to time, including the packages: amsdal_Framework and its dependencies amsdal_models, amsdal_data, amsdal_cli, amsdal_server and amsdal_utils.

“**License Fee**” means the consideration to be paid by you to us for the License as outlined herein.

“**License Plan**” means a predetermined set of functionality, restrictions, or services applicable to the Library.

“**License**” has the meaning outlined in Clause 2.1.

“**Parties**” means AMSDAL and you.

“**Party**” means either AMSDAL or you.

“**Product Page**” means our website page related to the Library, if any.

“**Third-Party Materials**” means the code, software or other content that is distributed by third parties under free or open-source software licenses (such as MIT, Apache 2.0, BSD) that allow for editing, modifying, or reusing such content.

“**Update**” means an update, patch, fix, support release, modification, or limited functional enhancement to the Library, including but not limited to error corrections to the Library, which does not, in our opinion, constitute an upgrade or a new/separate product.

“**U.S. Export Laws**” means the United States Export Administration Act and any other export law, restriction, or regulation.

“**Works**” means separate works, such as software, that are developed using the Library. The Works should not merely be a fork, alternative, copy, or derivative work of the Library or its part.

“**You**” means either you as a single individual or a single entity you represent.

1.2. Unless the context otherwise requires, a reference to one gender shall include a reference to the other genders; words in the singular shall include the plural and in the plural shall include the singular; any words following the terms including, include, in particular, for example, or any similar expression shall be construed as illustrative and shall not limit the sense of the words, description, definition, phrase or term preceding those terms; except where a contrary intention appears, a reference to a Section or Clause is a reference to a Section or Clause of this Agreement; Section and Clause headings do not affect the interpretation of this Agreement.

1.3. Each provision of this Agreement shall be construed as though both Parties participated equally in the drafting of same, and any rule of construction that a document shall be construed against the drafting Party, including without limitation, the doctrine is commonly known as “*contra proferentem*”, shall not apply to the interpretation of this Agreement.

2. **LICENSE, RESTRICTIONS**

2.1. License Grant. Subject to the terms and conditions contained in this Agreement, AMSDAL hereby grants to you a non-exclusive, non-transferable, revocable, limited, worldwide, and non-sublicensable license (the “**License**”) to install, run, and use the Library, as well as to modify and customize the Library to implement it in the Works.

2.2. Restrictions. As per the License, you shall not, except as expressly permitted herein, (i) sell, resell, transfer, assign, pledge, rent, rent out, lease, assign, distribute, copy, or encumber the Library or the rights in the Library, (ii) use the Library other than as expressly authorized in this Agreement, (iii) remove any copyright notice, trademark notice, and/or other proprietary legend or indication of confidentiality set forth on or contained in the Library, if any, (iv) use the Library in any manner that violates the laws of the United States of America or any other applicable law, (v) circumvent any feature, key, or other licensing control mechanism related to the Library that ensures compliance with this Agreement, (vi) reverse engineer, decompile, disassemble, decrypt or otherwise seek to obtain the source code to the Library, (vii) with respect to the Free License Plan, use the Library to provide a service to a third party, and (viii) permit others to do anything from the above.

2.3. Confidentiality. The Library, including any of its elements and components, shall at all times be treated by you as confidential and proprietary. You shall not disclose, transfer, or otherwise share the Library to any third party without our prior written consent. You shall also take all reasonable precautions to prevent any unauthorized disclosure and, in any event, shall use your best efforts to protect the confidentiality of the Library. This Clause does not apply to the information and part of the Library that (i) is generally known to the public at the time of disclosure, (ii) is legally received by you from a third party which rightfully possesses such information, (iii) becomes generally known to the public subsequent to the time of such disclosure, but not as a result of unauthorized disclosure hereunder, (iv) is already in your possession prior to obtaining the Library, or (v) is independently developed by you or on your behalf without use of or reference to the Library.

2.4. Third-Party Materials. By entering into this Agreement, you acknowledge and confirm that the Library includes the Third-Party Materials. The information regarding the Third-Party Materials will be provided to you along with the Library. If and where necessary, you shall comply with the terms and conditions applicable to the Third-Party Materials.

2.5. Title. The Library is protected by law, including without limitation the copyright laws of the United States of America and other countries, and by international treaties. AMSDAL or its licensors reserve all rights not expressly granted to you in this Agreement. You agree that AMSDAL and/or its licensors own all right, title, interest, and intellectual property rights associated with the Library, including related applications, plugins or extensions, and you will not contest such ownership.

2.6. No Sale. The Library provided hereunder is licensed, not sold. Therefore, the Library is exempt from the “first sale” doctrine, as defined in the United States copyright laws or any other applicable law. For purposes of clarification only, you accept, acknowledge and agree that this is a license agreement and not an agreement for sale, and you shall have no ownership rights in any intellectual or tangible property of AMSDAL or its licensors.

2.7. Works. We do not obtain any rights, title or interest in and to the Works. Once and if the Library components lawfully become a part of the Works, you are free to choose the terms governing the Works. If the License is terminated you shall not use the Library within the Works.

2.8. Statistics. You hereby acknowledge and agree that we reserve the right to track and analyze the Library usage statistics and metrics.

3. **LICENSE PLANS**

3.1. Plans. The Library, as well as its functionality and associated services, may be subject to certain restrictions and limitations depending on the License Plan. The License Plan’s description, including any terms, such as term, License Fees, features, etc., are or will be provided by us including via the Product Page.

3.2. Plan Change. The Free License Plan is your default License Plan. You may change your License Plan by following our instructions that may be provided on the Product Page or otherwise. Downgrades are available only after the end of the respective prepaid License Plan.

3.3. Validity. You may have only one valid License Plan at a time. The License Plan is valid when it is fully prepaid by you (except for the Free License Plan which is valid only if and as long as we grant the License to you) and this Agreement is not terminated in accordance with the terms hereof.

3.4. Terms Updates. The License Plan’s terms may be updated by us at our sole discretion with or without prior notice to you. The License Plan updates that worsen terms and conditions of your valid License Plan will only be effective for the immediately following License Plan period, if any.

3.5. Free License Plan. We may from time to time at our discretion with or without notice and without liability to you introduce, update, suspend, or terminate the Free License Plan. The Free License Plan allows you to determine if the Library suits your particular needs. The Library provided under the Free License Plan is not designed to and shall not be used in trade, commercial activities, or your normal course of business.

4. **PAYMENTS**

4.1. License Fees. In consideration for the License provided hereunder, you shall, except for the Free License Plan, pay the License Fee in accordance with the terms of the chosen License Plan or Additional Agreement, if any.

4.2. Updates. We reserve the right at our sole discretion to change any License Fees, as well as to introduce or change any new payments at any time. The changes will not affect the prepaid License Plans; however they will apply starting from the immediately following License Plan period.

4.3. Payment Terms. Unless otherwise agreed in the Additional Agreement, the License Fees are paid fully in advance.

4.4. Precondition. Except for the Free License Plan, payment of the License Fee shall be the precondition for the License. Therefore, if you fail to pay the License Fee in full in accordance with the terms hereof, this Agreement, as well as the License, shall immediately terminate.

4.5. Currency and Fees. Unless expressly provided, prices are quoted in U.S. dollars. All currency conversion fees shall be paid by you. Each Party shall cover its own commissions and fees applicable to the transactions contemplated hereunder.

4.6. Refunds. There shall be no partial or total refunds of the License Fees that were already paid to us, including without limitation if you failed to download or use the Library.

4.7. Taxes. Unless expressly provided, all amounts are exclusive of taxes, including value added tax, sales tax, goods and services tax or other similar tax, each of which, where chargeable by us, shall be payable by you at the rate and in the manner prescribed by law. All other taxes, duties, customs, or similar charges shall be your responsibility.

5. **UPDATES, AVAILABILITY, SUPPORT**

5.1. Updates. Except for the Free License Plan, you are eligible to receive all relevant Updates during the valid License Plan at no additional charge. The Library may be updated at our sole discretion with or without notice to you. However, we shall not be obligated to make any Updates.

5.2. Availability. We do not guarantee that any particular feature or functionality of the Library will be available at any time.

5.3. Support. Unless otherwise decided by us at our sole discretion, we do not provide any support services. There is no representation or warranty that any functionality or Library as such will be supported by us.

5.4. Termination. We reserve the right at our sole discretion to discontinue the Library distribution and support at any time by providing prior notice to you. However, we will continue to maintain the Library until the end of then-current License Plan.

6. **TERM, TERMINATION**

6.1. Term. Unless terminated earlier on the terms outlined herein, this Agreement shall be in force as long as you have a valid License Plan. Once your License Plan expires, this Agreement shall automatically expire.

6.2. Termination Without Cause. You may terminate this Agreement for convenience at any time.

6.3. Termination For Breach. If you are in breach of this Agreement and you fail to promptly, however not later than within ten (10) days, following our notice to cure such breach, we may immediately terminate this Agreement.

6.4. Termination For Material Breach. If you are in material breach of this Agreement, we may immediately terminate this Agreement upon written notice to you.

6.5. Termination of Free License Plan. If you are using the Library under the Free License Plan, this Agreement may be terminated by us at any time with or without notice and without any liability to you.

6.6. Effect of Termination. Once this Agreement is terminated or expired, (i) the License shall terminate or expire, (ii) you shall immediately cease using the Library, (iii) you shall permanently erase the Library and its copies that are in your possession or control, (iv) if technically possible, we will discontinue the Library operation, (v) all our obligations under this Agreement shall cease, and (vi) the License Fees or any other amounts that were paid to us hereunder, if any, shall not be reimbursed.

6.7. Survival. Clauses and Sections 2.2-2.5, 4.6, 4.7, 6.6, 6.7, 7.7, 8, 9.2, 10-12 shall survive any termination or expiration of this Agreement regardless of the reason.

7. **REPRESENTATIONS, WARRANTIES**

7.1. Mutual Representation. Each Party represents that it has the legal power and authority to enter into this Agreement. If you act on behalf of an entity, you hereby represent that you are authorized to accept this Agreement and enter into a binding agreement with us on such entity’s behalf.

7.2. Not a Consumer. You represent that you are not entering into this Agreement as a Consumer and that you do not intend to use the Library as a Consumer. The Library is not intended to be used by Consumers, therefore you shall not enter into this Agreement, and download and use the Library if you act as a Consumer.

7.3. Sanctions and Restrictions. You represent that you are not (i) a citizen or resident of, or person subject to jurisdiction of, Iran, Syria, Venezuela, Cuba, North Korea, or Russia, or (ii) a person subject to any sanctions administered or enforced by the United States Office of Foreign Assets Control or United Nations Security Council.

7.4. IP Warranty. Except for the Free License Plan, we warrant that, to our knowledge, the Library does not violate or infringe any third-party intellectual property rights, including copyright, rights in patents, trade secrets, and/or trademarks, and that to our knowledge no legal action has been taken in relation to the Library for any infringement or violation of any third party intellectual property rights.

7.5. No Harmful Code Warranty. Except for the Free License Plan, we warrant that we will use commercially reasonable efforts to protect the Library from, and the Library shall not knowingly include, malware, viruses, trap doors, back doors, or other means or functions which will detrimentally interfere with or otherwise adversely affect your use of the Library or which will damage or destroy your data or other property. You represent that you will use commercially reasonable efforts and industry standard tools to prevent the introduction of, and you will not knowingly introduce, viruses, malicious code, malware, trap doors, back doors or other means or functions by accessing the Library, the introduction of which may detrimentally interfere with or otherwise adversely affect the Library or which will damage or destroy data or other property.

7.6. Documentation Compliance Warranty. Except for the Free License Plan, we warrant to you that as long as you maintain a valid License Plan the Library shall perform substantially in accordance with the Documentation. Your exclusive remedy, and our sole liability, with respect to any breach of this warranty, will be for us to use commercially reasonable efforts to promptly correct the non-compliance (provided that you promptly notify us in writing and allow us a reasonable cure period).

7.7. Disclaimer of Warranties. Except for the warranties expressly stated above in this Section, the Library is provided “as is”, with all faults and deficiencies. We disclaim all warranties, express or implied, including, but not limited to, warranties of merchantability, fitness for a particular purpose, title, availability, error-free or uninterrupted operation, and any warranties arising from course of dealing, course of performance, or usage of trade to the extent that we may not as a matter of applicable law disclaim any implied warranty, the scope, and duration of such warranty will be the minimum permitted under applicable law.

8. **LIABILITY**

8.1. Limitation of Liability. To the maximum extent permitted by applicable law, in no event shall AMSDAL be liable under any theory of liability for any indirect, incidental, special, or consequential damages of any kind (including, without limitation, any such damages arising from breach of contract or warranty or from negligence or strict liability), including, without limitation, loss of profits, revenue, data, or use, or for interrupted communications or damaged data, even if AMSDAL has been advised or should have known of the possibility of such damages.

8.2. Liability Cap. In any event, our aggregate liability under this Agreement, negligence, strict liability, or other theory, at law or in equity, will be limited to the total License Fees paid by you under this Agreement for the License Plan valid at the time when the relevant event happened.

8.3. Force Majeure. Neither Party shall be held liable for non-performance or undue performance of this Agreement caused by force majeure. Force majeure means an event or set of events, which is unforeseeable, unavoidable, and beyond control of the respective Party, for instance fire, flood, hostilities, declared or undeclared war, military actions, revolutions, act of God, explosion, strike, embargo, introduction of sanctions, act of government, act of terrorism.

8.4. Exceptions. Nothing contained herein limits our liability to you in the event of death, personal injury, gross negligence, willful misconduct, or fraud.

8.5. Remedies. In addition to, and not in lieu of the termination provisions set forth in Section 6 above, you agree that, in the event of a threatened or actual breach of a provision of this Agreement by you, (i) monetary damages alone will be an inadequate remedy, (ii) such breach will cause AMSDAL great, immediate, and irreparable injury and damage, and (iii) AMSDAL shall be entitled to seek and obtain, from any court of competent jurisdiction (without the requirement of the posting of a bond, if applicable), immediate injunctive and other equitable relief in addition to, and not in lieu of, any other rights or remedies that AMSDAL may have under applicable laws.

9. **INDEMNITY**

9.1. Our Indemnity. Except for the Free License Plan users, we will defend, indemnify, and hold you harmless from any claim, suit, or action to you based on our alleged violation of the IP Warranty provided in Clause 7.4 above, provided you (i) notify us in writing promptly upon notice of such claim and (ii) cooperate fully in the defense of such claim, suit, or action. We shall, at our own expense, defend such a claim, suit, or action, and you shall have the right to participate in the defense at your own expense. For the Free License Plan users, you shall use at your own risk and expense, and we have no indemnification obligations.

9.2. Your Indemnity. You will defend, indemnify, and hold us harmless from any claim, suit, or action to us based on your alleged violation of this Agreement, provided we notify you in writing promptly upon notice of such claim, suit, or action. You shall, at your own expense, defend such a claim, suit, or action.

10. **GOVERNING LAW, DISPUTE RESOLUTION**

10.1. Law. This Agreement shall be governed by the laws of the State of New York, USA, without reference to conflicts of laws principles. Provisions of the United Nations Convention on the International Sale of Goods shall not apply to this Agreement.

10.2. Negotiations. The Parties shall seek to solve amicably any disputes, controversies, claims, or demands arising out of or relating to this Agreement, as well as those related to execution, breach, termination, or invalidity hereof. If the Parties do not reach an amicable resolution within thirty (30) days, any dispute, controversy, claim or demand shall be finally settled by the competent court as outlined below.

10.3. Jurisdiction. The Parties agree that the exclusive jurisdiction and venue for any dispute arising out of or related to this Agreement shall be the courts of the State of New York and the courts of the United States of America sitting in the County of New York.

10.4. Class Actions Waiver. The Parties agree that any dispute arising out of or related to this Agreement shall be pursued individually. Neither Party shall act as a plaintiff or class member in any supposed purported class or representative proceeding, including, but not limited to, a federal or state class action lawsuit, against the other Party in relation herewith.

10.5. Costs. In the event of any legal proceeding between the Parties arising out of or related to this Agreement, the prevailing Party shall be entitled to recover, in addition to any other relief awarded or granted, its reasonable costs and expenses (including attorneys’ and expert witness’ fees) incurred in such proceeding.

11. **COMMUNICATION**

11.1. Communication Terms. Any Communications shall be in writing. When sent by ordinary mail, Communication shall be sent by personal delivery, by certified or registered mail, and shall be deemed delivered upon receipt by the recipient. When sent by electronic mail (email), Communication shall be deemed delivered on the day following the day of transmission. Any Communication given by email in accordance with the terms hereof shall be of full legal force and effect.

11.2. Contact Details. Your contact details must be provided by you to us. AMSDAL contact details are as follows: PO Box 940, Bedford, NY 10506; ams@amsdal.com. Either Party shall keep its contact details correct and up to date. Either Party may update its contact details by providing a prior written notice to the other Party in accordance with the terms hereof.

12. **MISCELLANEOUS**

12.1. Export Restrictions. The Library originates from the United States of America and may be subject to the United States export administration regulations. You agree that you will not (i) transfer or export the Library into any country or (ii) use the Library in any manner prohibited by the U.S. Export Laws. You shall comply with the U.S. Export Laws, as well as all applicable international and national laws related to the export or import regulations that apply in relation to your use of the Library.

12.2. Entire Agreement. This Agreement shall constitute the entire agreement between the Parties, supersede and extinguish all previous agreements, promises, assurances, warranties, representations and understandings between them, whether written or oral, relating to its subject matter.

12.3. Additional Agreements. AMSDAL and you are free to enter into any Additional Agreements. In the event of conflict, unless otherwise explicitly stated, the Additional Agreement shall control.

12.4. Modifications. We may modify, supplement or update this Agreement from time to time at our sole and absolute discretion. If we make changes to this Agreement, we will (i) update the “Version” and “Last Updated” date at the top of this Agreement and (ii) notify you in advance before the changes become effective. Your continued use of the Library is deemed acceptance of the amended Agreement. If you do not agree to any part of the amended Agreement, you shall immediately discontinue any use of the Library, which shall be your sole remedy.

12.5. Assignment. You shall not assign or transfer any rights or obligations under this Agreement without our prior written consent. We may upon prior written notice unilaterally transfer or assign this Agreement, including any rights and obligations hereunder at any time and no such transfer or assignment shall require your additional consent or approval.

12.6. Severance. If any provision or part-provision of this Agreement is or becomes invalid, illegal or unenforceable, it shall be deemed modified to the minimum extent necessary to make it valid, legal, and enforceable. If such modification is not possible, the relevant provision or part-provision shall be deemed deleted. If any provision or part-provision of this Agreement is deemed deleted under the previous sentence, AMSDAL will in good faith replace such provision with a new one that, to the greatest extent possible, achieves the intended commercial result of the original provision. Any modification to or deletion of a provision or part-provision under this Clause shall not affect the validity and enforceability of the rest of this Agreement.

12.7. Waiver. No failure or delay by a Party to exercise any right or remedy provided under this Agreement or by law shall constitute a waiver of that or any other right or remedy, nor shall it preclude or restrict the further exercise of that or any other right or remedy.

12.8. No Partnership or Agency. Nothing in this Agreement is intended to, or shall be deemed to, establish any partnership, joint venture or employment relations between the Parties, constitute a Party the agent of another Party, or authorize a Party to make or enter into any commitments for or on behalf of any other Party.
