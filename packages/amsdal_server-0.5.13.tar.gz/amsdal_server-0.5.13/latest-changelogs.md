## [v0.5.13](https://pypi.org/project/amsdal_server/0.5.13/) - 2025-12-11

### Changed

- Unquote filter values
