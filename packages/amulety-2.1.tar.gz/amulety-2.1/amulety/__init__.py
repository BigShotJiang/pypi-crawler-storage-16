from .amulety import embed_airr, translate_airr

__version__ = "2.0"

__all__ = [
    "embed_airr",
    "translate_airr",
]
