'use strict';

class AuthenticationProviderExtension {
    handle401() {
    }

    handle302(resp) {
    }

    handleSuccessLogin() {
    }

    getUserData() {
        return false;
    }

    handleError(response, e, widgetId){
        
    }
}