'use strict';

class PageRenderExtension {
    afterPageRendered() {

    }
}
