from textwrap import dedent
from rich.text import Text
from textual import on
from textual.reactive import reactive
from textual.app import ComposeResult
from textual.containers import (
    Vertical,
    Horizontal,
    Container,
    VerticalScroll)
from textual.widget import Widget
from textual.widgets import Button, Label
from textual.screen import ModalScreen
from analyst_klondike.state.app_state import AppState, get_state, select


class MessageText(Widget):

    markup_text = reactive("")

    def __init__(self, text: str) -> None:
        super().__init__()
        self.markup_text = text

    def render(self) -> Text:
        return Text.from_markup(self.markup_text)


class MessageBoxScreen(ModalScreen[AppState]):

    def __init__(self,
                 name: str | None = None,
                 id: str | None = None,
                 classes: str | None = None,
                 message: str | None = None) -> None:
        super().__init__(name, id, classes)
        self._message = message or ""

    # @staticmethod
    # def message(state: AppState) -> str:
    #     return dedent(state.message_box.message)

    CSS_PATH = "mb_screen.tcss"

    def compose(self) -> ComposeResult:
        yield Container(id="shadow")
        with Vertical(id="dialog"):
            with VerticalScroll():
                yield Label(self._message)
            with Horizontal(id="buttons"):
                yield Button(id="ok_button",
                             label="ОК",
                             variant="success")

    @on(Button.Pressed, "#ok_button")
    def ok_button_click(self) -> None:
        state = get_state()
        self.dismiss(state)
