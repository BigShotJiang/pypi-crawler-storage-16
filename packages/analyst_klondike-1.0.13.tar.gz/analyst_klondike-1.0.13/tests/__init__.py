# SPDX-FileCopyrightText: 2025-present U.N. Owen <vbd1988@yandex.ru>
#
# SPDX-License-Identifier: MIT
