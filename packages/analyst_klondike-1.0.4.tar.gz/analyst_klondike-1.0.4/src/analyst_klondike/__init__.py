# SPDX-FileCopyrightText: 2025-present U.N. Owen <vbd1988@yandex.ru>
#
# SPDX-License-Identifier: MIT
from importlib.metadata import version

__version__ = version(__name__)
