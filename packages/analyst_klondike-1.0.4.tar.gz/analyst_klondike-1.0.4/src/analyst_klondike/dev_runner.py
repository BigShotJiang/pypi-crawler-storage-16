from analyst_klondike.ui.runner_app import get_app


app = get_app()
