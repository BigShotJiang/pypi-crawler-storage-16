# -*- coding: utf-8 -*-
# code: language=python tabSize=4
#
# (C) 2021-2025 Alexei Znamensky
# Licensed under the MIT License. See LICENSES/MIT.txt for details.
# SPDX-FileCopyrightText: 2021-2025 Alexei Znamensky
# SPDX-License-Identifier: MIT

__version__ = "1.9.0"
