# -*- coding: utf-8 -*-
# code: language=python tabSize=4
# (C) 2025 Alexei Znamensky
# Licensed under the MIT License. See LICENSES/MIT.txt for details.
# SPDX-FileCopyrightText: 2025 Alexei Znamensky
# SPDX-License-Identifier: MIT
from andebox.cli import run

if __name__ == "__main__":
    run()
