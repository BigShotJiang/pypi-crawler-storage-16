INTERACTIVE_CLASSES = [
        "android.widget.Button",
        "android.widget.ImageButton",
        "android.widget.EditText",
        "android.widget.CheckBox",
        "android.widget.Switch",
        "android.widget.RadioButton",
        "android.widget.Spinner",
        "android.widget.SeekBar",
    ]

