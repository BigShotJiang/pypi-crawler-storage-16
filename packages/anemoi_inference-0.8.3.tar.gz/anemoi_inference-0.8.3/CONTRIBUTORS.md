## How to Contribute

Please see the [read the docs](https://anemoi.readthedocs.io/en/latest/contributing/contributing.html).


## Contributors

Thank you to all the wonderful people who have contributed to Anemoi. Contributions can come in many forms, including code, documentation, bug reports, feature suggestions, design, and more. A list of code-based contributors can be found [here](https://github.com/ecmwf/anemoi-inference/graphs/contributors).


## Contributing Organisations

Significant contributions have been made by the following organisations: [DMI](https://www.dmi.dk/), [DWD](https://www.dwd.de/), [FMI](https://www.ilmatieteenlaitos.fi/), [KNMI](https://www.knmi.nl), [MET Norway](https://www.met.no/), [MeteoSwiss](https://www.meteoswiss.admin.ch/), [RMI](https://www.meteo.be/), [Met Office](https://www.metoffice.gov.uk/), [Météo-France](https://meteofrance.com/) & [ECMWF](https://www.ecmwf.int/)
