anemoi-inference run checkpoint=mycheckpoint.ckpt date=2020-01-01
