#########
 outputs
#########

.. automodule:: anemoi.inference.output
   :members:
   :no-undoc-members:
   :show-inheritance:

.. include:: ../_api/inference.outputs.rst
