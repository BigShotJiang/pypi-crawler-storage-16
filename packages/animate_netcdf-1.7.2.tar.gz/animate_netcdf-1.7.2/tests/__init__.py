"""Tests for animate-netcdf package."""
