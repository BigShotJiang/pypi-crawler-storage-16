__appname__ = "anipy-api"
__version__ = "3.8.1"
