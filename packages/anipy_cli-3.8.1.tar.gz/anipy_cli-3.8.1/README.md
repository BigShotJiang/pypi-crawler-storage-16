# ANIPY-CLI
**Anime from the comfort of your Terminal**

<p align="center"><img src="https://github.com/sdaqo/anipy-cli/assets/63876564/1dafa5fb-4273-4dc1-a7ab-2664dd668fc9" /> </p>

## What even is this?
A Little tool written in python to watch and download anime from the terminal (the better way to watch anime)
This project's main aim is to create a enjoyable anime watching and downloading experience, directly in the terminal - your favorite place.

Since the version 3 rewrite this project is split into api and frontend this makes it easy to integrate this into your project!

## You are just here for the client?
<a href="https://pypi.org/project/anipy-cli/"><img alt="PyPI - Version" src="https://img.shields.io/pypi/v/anipy-cli?style=for-the-badge&logo=pypi&label=anipy-cli"></a>

As one wise man once said:
> I DONT GIVE A FUCK ABOUT THE FUCKING CODE! i just want to download this stupid fucking application and use it.
>
> WHY IS THERE CODE??? MAKE A FUCKING .EXE FILE AND GIVE IT TO ME. these dumbfucks think that everyone is a developer and understands code. well i am not and i don't understand it. I only know to download and install applications. SO WHY THE FUCK IS THERE CODE? make an EXE file and give it to me. STUPID FUCKING SMELLY NERDS

<sub>Please do not take this seriously this is some stupid copypasta</sub>

We do not have a .exe but we have pipx: `pipx install anipy-cli`

Check out [Getting Started - CLI](https://sdaqo.github.io/anipy-cli/getting-started-cli) for better instructions and advice!

## You want to use the api for your project?
<a href="https://pypi.org/project/anipy-api/"><img alt="PyPI - Version" src="https://img.shields.io/pypi/v/anipy-api?style=for-the-badge&logo=pypi&label=anipy-api"></a>

Feel free to - please check out [Getting Started - API](https://sdaqo.github.io/anipy-cli/getting-started-api) for instructions


## :heart: Credits! 

#### Heavily inspired by https://github.com/pystardust/ani-cli/

#### All contributors for contributing

<a href="https://github.com/sdaqo/anipy-cli/graphs/contributors">
    <img src="https://contrib.rocks/image?repo=sdaqo/anipy-cli" alt="anipy-cli contributors" title="anipy-cli contributors" width="800"/>
</a>

If you want to contribute as well check out this: https://sdaqo.github.io/anipy-cli/contributing
