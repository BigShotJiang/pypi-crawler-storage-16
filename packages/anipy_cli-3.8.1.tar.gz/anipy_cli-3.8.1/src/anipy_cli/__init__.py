__appname__ = "anipy-cli"
__version__ = "3.8.1"
