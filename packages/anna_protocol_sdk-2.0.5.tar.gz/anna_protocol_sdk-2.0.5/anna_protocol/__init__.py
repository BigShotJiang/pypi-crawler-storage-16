"""
ANNA Protocol SDK v2.0.5
Official Python SDK for ANNA Protocol - AI Accountability on Blockchain
Making AI Decisions Accountable

NOVO na v2.0.5:
✅ Filebase/IPFS integration
✅ Client-side encryption (AES-256-GCM)
✅ Public/Private reasoning structure
✅ Backward compatible with v1.x
"""

from .client import (
    # Core client
    ANNAClient,
    
    # v1.x structures (mantidas)
    Reasoning,
    ReasoningStep,
    AttestationResult,
    Metadata,
    Identity,
    
    # v1.x enums
    VerificationTier,
    AttestationStatus,
    
    # v2.0 structures (novas)
    PublicReasoning,
    PrivateReasoning,
    DetailedReasoningStep,
    EncryptedData,
    FullReasoning,
    
    # v2.0 engines (novas)
    FilebaseClient,
    EncryptionEngine,
    
    # Helper functions
    create_reasoning,
    create_metadata,
    calculate_content_hash,
    
    # Exceptions
    ANNAError,
    IdentityNotFoundError,
    AttestationNotFoundError,
    VerificationTimeoutError,
    MetadataValidationError,
)

__version__ = "2.0.5"
__author__ = "Antonio Rufino / ANNA Protocol Team"
__license__ = "MIT"

__all__ = [
    # Core
    "ANNAClient",
    "__version__",
    
    # v1.x (backward compatibility)
    "Reasoning",
    "ReasoningStep",
    "AttestationResult",
    "Metadata",
    "Identity",
    "VerificationTier",
    "AttestationStatus",
    
    # v2.0 (new)
    "PublicReasoning",
    "PrivateReasoning",
    "DetailedReasoningStep",
    "EncryptedData",
    "FullReasoning",
    "FilebaseClient",
    "EncryptionEngine",
    
    # Helpers
    "create_reasoning",
    "create_metadata",
    "calculate_content_hash",
    
    # Exceptions
    "ANNAError",
    "IdentityNotFoundError",
    "AttestationNotFoundError",
    "VerificationTimeoutError",
    "MetadataValidationError",
]