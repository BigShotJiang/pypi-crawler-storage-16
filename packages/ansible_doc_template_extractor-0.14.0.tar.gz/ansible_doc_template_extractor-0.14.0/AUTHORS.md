# Authors of this project

Sorted list of authors derived from git commit history:
```
Andreas Maier <andreas.r.maier@gmx.de>
```
