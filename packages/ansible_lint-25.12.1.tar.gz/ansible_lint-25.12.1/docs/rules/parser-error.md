# parser-error

**AnsibleParserError.**

Ansible parser fails; this usually indicates an invalid file.
