# Starting SLang in batch mode
$OPTISLANG_HOME/slang/bin/slang -b $INPUT_FILE1

# uncomment the following lines to wait for the outputfile
#while [ ! -f $OUTPUT_FILE1 ] ;
#do
#   sleep .1
#done
