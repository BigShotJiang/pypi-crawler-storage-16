const config = {
  plugins: [
    require("autoprefixer"),
    require("postcss-minify"),
    require("postcss-nested"),
  ],
};

module.exports = config;
