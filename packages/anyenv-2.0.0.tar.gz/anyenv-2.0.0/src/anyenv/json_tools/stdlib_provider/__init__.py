"""Standard library provider for JSON serialization and deserialization."""

from anyenv.json_tools.stdlib_provider.provider import StdLibProvider

__all__ = ["StdLibProvider"]
