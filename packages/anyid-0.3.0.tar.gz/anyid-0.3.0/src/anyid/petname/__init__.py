from .generator import petname

__all__ = ["petname"]
