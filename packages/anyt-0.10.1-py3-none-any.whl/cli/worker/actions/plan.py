"""
Plan submission workflow actions.
"""

import logging
import os
from typing import Any, Dict

from sdk.generated.api_config import APIConfig
from sdk.generated.models.SubmitPlanRequest import SubmitPlanRequest
from sdk.generated.services.async_Tasks_service import submitTaskPlan

from cli.commands.console import console
from .base import Action
from ..context import ExecutionContext

logger = logging.getLogger(__name__)


class PlanSubmitAction(Action):
    """Submit an implementation plan for review.

    This action submits a plan to the AnyTask backend for review.
    When auto_approve is True, the plan is immediately approved.
    When auto_approve is False (default), the plan status is 'pending'
    and the workflow should pause for human review.
    """

    async def execute(
        self, params: Dict[str, Any], ctx: ExecutionContext
    ) -> Dict[str, Any]:
        """Submit plan to AnyTask.

        Args:
            params: Action parameters
                - plan (required): Implementation plan content (markdown)
                - auto_approve (optional, default: false): Auto-approve the plan
            ctx: Execution context with task data

        Returns:
            Dict with keys:
                - submitted: bool (True if plan was submitted)
                - plan_status: str ('pending' or 'approved')
                - task_id: int (task ID from response)

        Raises:
            ValueError: If required parameters are missing
        """
        # Get required plan parameter
        plan = params.get("plan")
        if not plan:
            raise ValueError("plan parameter is required")

        # Get optional auto_approve parameter (default: False)
        auto_approve = params.get("auto_approve", False)

        # Get task identifier from context
        task_identifier = ctx.task.get("identifier")
        if not task_identifier:
            raise ValueError("Task identifier not found in context")

        # Get workspace_id from context
        workspace_id = ctx.workspace_id
        if not workspace_id:
            raise ValueError("Workspace ID not found in context")

        # Get API configuration from context or environment
        ctx_env = ctx.env or {}
        api_config = self._get_api_config(ctx_env)

        # Create submit plan request
        request = SubmitPlanRequest(
            implementation_plan=plan,
            auto_approve=auto_approve,
        )

        # Call the API
        try:
            response = await submitTaskPlan(
                api_config_override=api_config,
                workspace_id=workspace_id,
                identifier=task_identifier,
                data=request,
                X_API_Key=self._get_api_key(ctx_env),
            )

            # Determine plan status from response
            # If auto_approve was True, plan is approved; otherwise pending
            plan_status = response.plan_review_status or (
                "approved" if auto_approve else "pending"
            )

            return {
                "submitted": True,
                "plan_status": plan_status,
                "task_id": response.id,
            }
        except Exception as e:
            error_msg = str(e).lower()
            # Handle "Plan already approved" as a success case
            if "already approved" in error_msg or "cannot resubmit" in error_msg:
                logger.info(
                    f"Plan already approved for task {task_identifier}, skipping submission"
                )
                console.print(
                    "  [dim green]✓ Plan already approved, skipping submission[/dim green]"
                )
                return {
                    "submitted": False,
                    "skipped": True,
                    "reason": "Plan already approved",
                    "plan_status": "approved",
                    "task_id": ctx.task.get("id"),
                }
            # Re-raise other errors
            raise

    def _get_api_config(self, ctx_env: Dict[str, str]) -> APIConfig:
        """Get API configuration from context or environment."""
        api_url = (
            ctx_env.get("ANYT_API_URL")
            or os.getenv("ANYT_API_URL")
            or "https://api.anyt.dev"
        )
        return APIConfig(base_path=api_url)

    def _get_api_key(self, ctx_env: Dict[str, str]) -> str | None:
        """Get API key from context or environment."""
        return ctx_env.get("ANYT_API_KEY") or os.getenv("ANYT_API_KEY")
