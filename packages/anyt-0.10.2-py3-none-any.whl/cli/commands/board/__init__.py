"""Summary visualization command.

Use direct imports:
    from cli.commands.board.commands import app, show_summary
"""
