from typing import *
from pydantic import BaseModel, Field

class RequestPlanChangesRequest(BaseModel):
    """
    RequestPlanChangesRequest model
        Request for requesting changes to a plan.
            """
    model_config = {
        "populate_by_name": True,
        "validate_assignment": True
    }
    
    feedback : str = Field(validation_alias="feedback" )
    