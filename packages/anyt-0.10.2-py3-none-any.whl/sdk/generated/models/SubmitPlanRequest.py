from typing import *
from pydantic import BaseModel, Field

class SubmitPlanRequest(BaseModel):
    """
    SubmitPlanRequest model
        Request for submitting a plan for review.
            """
    model_config = {
        "populate_by_name": True,
        "validate_assignment": True
    }
    
    implementation_plan : str = Field(validation_alias="implementation_plan" )
    
    auto_approve : Optional[bool] = Field(validation_alias="auto_approve" , default = None )
    