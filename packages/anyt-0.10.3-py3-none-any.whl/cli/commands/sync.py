"""Sync commands for filesystem-first task management.

This module provides commands to sync tasks between the local filesystem
and the AnyTask API server, enabling any AI tool to work with tasks
by reading local files.
"""

import os
import platform
import subprocess
from datetime import UTC, datetime
from typing import Any, Optional

import typer
from typing_extensions import Annotated

from cli.commands.console import console
from cli.commands.context import CommandContext
from cli.commands.decorators import async_command
from cli.commands.formatters import output_json_data, output_json_list
from cli.commands.services import ServiceRegistry as services
from cli.config import ActiveTaskConfig
from cli.models.common import Priority, Status
from cli.models.local_task import LocalTask, LocalTaskMeta
from cli.models.task import TaskFilters, TaskUpdate
from cli.models.wrappers.task import Task
from cli.services.local_task_service import LocalTaskService
from cli.utils.typer_utils import HelpOnErrorGroup

app = typer.Typer(
    name="sync",
    help="Sync tasks between local filesystem and server",
    cls=HelpOnErrorGroup,
)


def _task_to_local_meta(task: Task) -> LocalTaskMeta:
    """Convert a Task from the API to LocalTaskMeta for local storage.

    Args:
        task: Task object from the API

    Returns:
        LocalTaskMeta ready for local storage
    """
    now = datetime.now(UTC)

    return LocalTaskMeta(
        identifier=task.identifier,
        id=task.id,
        title=task.title,
        status=task.status.value,
        priority=task.priority.value if task.priority else 0,
        labels=[],  # Labels removed from API
        owner_id=task.owner_id,
        project_id=task.project_id,
        workspace_id=task.workspace_id,
        pulled_at=now,
        pushed_at=None,
        server_updated_at=task.updated_at,
    )


def _format_file_size(size_bytes: int) -> str:
    """Format file size in human-readable format.

    Args:
        size_bytes: Size in bytes

    Returns:
        Formatted string (e.g., "1.2 KB")
    """
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    else:
        return f"{size_bytes / (1024 * 1024):.1f} MB"


def _show_diff_summary(
    local_service: LocalTaskService,
    identifier: str,
    new_description: str,
    new_meta: LocalTaskMeta,
) -> bool:
    """Show diff summary between local and server versions.

    Args:
        local_service: LocalTaskService instance
        identifier: Task identifier
        new_description: New description from server
        new_meta: New metadata from server

    Returns:
        True if there were differences, False otherwise
    """
    if not local_service.task_exists(identifier):
        return False

    local_task = local_service.read_task(identifier)
    has_diff = False

    # Check for differences
    diffs: list[str] = []

    if local_task.meta.title != new_meta.title:
        diffs.append(f"  title: '{local_task.meta.title}' → '{new_meta.title}'")
        has_diff = True

    if local_task.meta.status != new_meta.status:
        diffs.append(f"  status: {local_task.meta.status} → {new_meta.status}")
        has_diff = True

    if local_task.meta.priority != new_meta.priority:
        diffs.append(f"  priority: {local_task.meta.priority} → {new_meta.priority}")
        has_diff = True

    if local_task.description != new_description:
        old_len = len(local_task.description)
        new_len = len(new_description)
        diffs.append(f"  description: {old_len} chars → {new_len} chars")
        has_diff = True

    if diffs:
        console.print("[dim]Changes from server:[/dim]")
        for diff in diffs:
            console.print(f"[yellow]{diff}[/yellow]")

    return has_diff


async def _pull_single_task(
    task: Task,
    local_service: LocalTaskService,
    pick: bool,
    show_diff: bool,
    json_output: bool,
) -> dict[str, Any]:
    """Pull a single task to local filesystem.

    Args:
        task: Task to pull
        local_service: LocalTaskService instance
        pick: Whether to set as active task
        show_diff: Whether to show diff summary
        json_output: Whether in JSON mode

    Returns:
        Dictionary with pull result details
    """
    # Convert to local format
    meta = _task_to_local_meta(task)
    description = task.description or ""

    # Check for existing task and show diff if requested
    existed = local_service.task_exists(task.identifier)
    had_diff = False
    if existed and show_diff and not json_output:
        had_diff = _show_diff_summary(local_service, task.identifier, description, meta)

    # Write task to local filesystem
    local_task = local_service.write_task(meta, description)

    # Calculate file sizes
    task_dir = local_task.path
    md_path = task_dir / "task.md"
    meta_path = task_dir / ".meta.json"
    context_dir = task_dir / "context"
    plan_path = task_dir / "plan.md"

    md_size = md_path.stat().st_size if md_path.exists() else 0
    meta_size = meta_path.stat().st_size if meta_path.exists() else 0

    # Write plan.md if task has an implementation plan
    plan_size = 0
    has_plan = False
    gen_task = task.to_generated()
    if gen_task.implementation_plan:
        plan_content = f"# Implementation Plan\n\n{gen_task.implementation_plan}"
        plan_path.write_text(plan_content, encoding="utf-8")
        plan_size = plan_path.stat().st_size
        has_plan = True

    result = {
        "identifier": task.identifier,
        "title": task.title,
        "path": str(task_dir),
        "task_md_size": md_size,
        "meta_json_size": meta_size,
        "plan_md_size": plan_size,
        "has_plan": has_plan,
        "context_created": not existed and context_dir.exists(),
        "overwritten": existed,
        "had_diff": had_diff,
        "picked": False,
    }

    # Set as active task if requested
    if pick:
        active_task = ActiveTaskConfig(
            identifier=task.identifier,
            title=task.title,
            picked_at=datetime.now(UTC).isoformat().replace("+00:00", "Z"),
            workspace_id=task.workspace_id,
            project_id=task.project_id,
        )
        active_task.save()
        result["picked"] = True

    return result


def _display_pull_result(result: dict[str, Any], show_details: bool = True) -> None:
    """Display pull result in human-readable format.

    Args:
        result: Pull result dictionary
        show_details: Whether to show file details
    """
    identifier = result["identifier"]
    path = result["path"]
    overwritten = result["overwritten"]

    action = "Updated" if overwritten else "Pulled"
    console.print(f"[green]✓[/green] {action} [cyan]{identifier}[/cyan] to {path}")

    if show_details:
        md_size = _format_file_size(result["task_md_size"])
        console.print(f"  - task.md ({md_size})")
        console.print("  - .meta.json")
        if result.get("has_plan"):
            plan_size = _format_file_size(result.get("plan_md_size", 0))
            console.print(f"  - plan.md ({plan_size})")
        if result["context_created"]:
            console.print("  - context/ (created)")

    if result["picked"]:
        console.print("  [yellow]→ Set as active task[/yellow]")


@app.command("pull")
@async_command()
async def pull(
    identifier: Annotated[
        Optional[str],
        typer.Argument(
            help="Task identifier (e.g., DEV-01) to pull. Leave empty with --mine to pull assigned tasks."
        ),
    ] = None,
    mine: Annotated[
        bool,
        typer.Option("--mine", help="Pull all tasks assigned to you"),
    ] = False,
    status: Annotated[
        Optional[str],
        typer.Option(
            "--status",
            help="Filter by status (backlog, todo, active, done, etc.). Comma-separated.",
        ),
    ] = None,
    pick: Annotated[
        bool,
        typer.Option("--pick", help="Set the pulled task as active (single task only)"),
    ] = False,
    json_output: Annotated[
        bool,
        typer.Option("--json", help="Output in JSON format"),
    ] = False,
) -> None:
    """Pull tasks from server to local filesystem.

    Downloads task data to .anyt/tasks/{IDENTIFIER}/ directory with:
    - task.md: Task title and description
    - .meta.json: Task metadata (status, priority, labels, etc.)
    - context/: Directory for local AI context files

    Examples:

        # Pull a single task
        anyt pull DEV-01

        # Pull and set as active task
        anyt pull DEV-01 --pick

        # Pull all tasks assigned to you
        anyt pull --mine

        # Pull assigned tasks with specific status
        anyt pull --mine --status active,todo
    """
    with CommandContext(require_auth=True, require_workspace=True) as ctx:
        # Validate arguments
        if not identifier and not mine:
            if json_output:
                console.print_json(
                    data={
                        "success": False,
                        "error": {
                            "code": "MISSING_ARGUMENT",
                            "message": "Provide a task identifier or use --mine",
                        },
                    }
                )
            else:
                console.print(
                    "[red]Error:[/red] Provide a task identifier or use --mine"
                )
                console.print("Examples:")
                console.print("  anyt pull DEV-01")
                console.print("  anyt pull --mine")
            raise typer.Exit(1)

        if pick and mine:
            if json_output:
                console.print_json(
                    data={
                        "success": False,
                        "error": {
                            "code": "INVALID_ARGUMENT",
                            "message": "--pick can only be used with a single task identifier",
                        },
                    }
                )
            else:
                console.print(
                    "[red]Error:[/red] --pick can only be used with a single task identifier"
                )
            raise typer.Exit(1)

        task_service = services.get_task_service()
        local_service = LocalTaskService()

        # Ensure tasks directory exists
        local_service.ensure_tasks_dir()

        if identifier:
            # Pull single task
            try:
                task = await task_service.get_task(identifier)
            except Exception as e:
                error_msg = str(e)
                if "404" in error_msg:
                    if json_output:
                        console.print_json(
                            data={
                                "success": False,
                                "error": {
                                    "code": "NOT_FOUND",
                                    "message": f"Task '{identifier}' not found",
                                },
                            }
                        )
                    else:
                        console.print(
                            f"[red]Error:[/red] Task '{identifier}' not found"
                        )
                    raise typer.Exit(1)
                raise

            result = await _pull_single_task(
                task, local_service, pick, show_diff=True, json_output=json_output
            )

            if json_output:
                output_json_data(result)
            else:
                _display_pull_result(result)

        else:
            # Pull multiple tasks (--mine)
            assert ctx.workspace_config is not None  # Guaranteed by require_workspace

            # Build filters
            status_list = None
            if status:
                status_list = [Status(s.strip()) for s in status.split(",")]

            filters = TaskFilters(
                workspace_id=int(ctx.workspace_config.workspace_id),
                status=status_list,
                owner="me",
            )

            tasks = await task_service.list_tasks(filters)

            if not tasks:
                if json_output:
                    output_json_list([])
                else:
                    console.print("[yellow]No tasks found matching filters[/yellow]")
                    if status:
                        console.print(f"  Status filter: {status}")
                raise typer.Exit(0)

            # Pull each task
            results: list[dict[str, Any]] = []
            for task in tasks:
                result = await _pull_single_task(
                    task,
                    local_service,
                    pick=False,
                    show_diff=False,
                    json_output=json_output,
                )
                results.append(result)

                if not json_output:
                    _display_pull_result(result, show_details=False)

            if json_output:
                output_json_list(results)
            else:
                console.print()
                console.print(
                    f"[green]✓[/green] Pulled {len(results)} task(s) to .anyt/tasks/"
                )


def _parse_task_md(content: str) -> tuple[str, str]:
    """Parse task.md into (title, description).

    The title is extracted from the first line starting with '# '.
    The description is the remaining content after the title.

    Args:
        content: Raw content of task.md file

    Returns:
        Tuple of (title, description)
    """
    lines = content.strip().split("\n")
    title = ""
    desc_start = 0

    for i, line in enumerate(lines):
        if line.startswith("# "):
            title = line[2:].strip()
            desc_start = i + 1
            break

    description = "\n".join(lines[desc_start:]).strip()
    return title, description


def _detect_local_changes(
    local_task: LocalTask, server_task: Task
) -> dict[str, tuple[Any, Any]]:
    """Detect differences between local and server versions.

    Args:
        local_task: Local task from filesystem
        server_task: Task from server

    Returns:
        Dictionary of field names to (local_value, server_value) tuples
    """
    changes: dict[str, tuple[Any, Any]] = {}

    # Parse local task.md
    local_title, local_description = _parse_task_md(local_task.description)

    # Compare title
    if local_title and local_title != server_task.title:
        changes["title"] = (local_title, server_task.title)

    # Compare description
    server_description = server_task.description or ""
    if local_description != server_description:
        changes["description"] = (local_description, server_description)

    # Compare status
    if local_task.meta.status != server_task.status.value:
        changes["status"] = (local_task.meta.status, server_task.status.value)

    # Compare priority
    local_priority = local_task.meta.priority
    server_priority = server_task.priority.value if server_task.priority else 0
    if local_priority != server_priority:
        changes["priority"] = (local_priority, server_priority)

    return changes


def _build_update_from_local(
    local_task: LocalTask,
    status_override: Optional[str] = None,
    done_flag: bool = False,
) -> TaskUpdate:
    """Build TaskUpdate from local task data.

    Args:
        local_task: Local task to push
        status_override: Status to use instead of local status
        done_flag: If True, set status to 'done'

    Returns:
        TaskUpdate with local changes
    """
    # Parse task.md
    title, description = _parse_task_md(local_task.description)

    # Determine status
    status: Optional[Status] = None
    if done_flag:
        status = Status.DONE
    elif status_override:
        status = Status(status_override)
    else:
        status = Status(local_task.meta.status)

    # Map priority int to Priority enum
    priority_map = {
        -2: Priority.LOWEST,
        -1: Priority.LOW,
        0: Priority.NORMAL,
        1: Priority.HIGH,
        2: Priority.HIGHEST,
    }
    priority = priority_map.get(local_task.meta.priority, Priority.NORMAL)

    return TaskUpdate(
        title=title if title else None,
        description=description if description else None,
        status=status,
        priority=priority,
    )


def _parse_plan_md(content: str) -> str:
    """Parse plan.md content, stripping the header if present.

    Args:
        content: Raw content of plan.md file

    Returns:
        Plan content without the "# Implementation Plan" header
    """
    lines = content.strip().split("\n")
    # Skip the header line if present
    start = 0
    for i, line in enumerate(lines):
        if line.strip().lower().startswith("# implementation plan"):
            start = i + 1
            # Skip any empty lines after the header
            while start < len(lines) and not lines[start].strip():
                start += 1
            break
    return "\n".join(lines[start:]).strip()


async def _push_single_task(
    local_task: LocalTask,
    local_service: LocalTaskService,
    status_override: Optional[str],
    done_flag: bool,
    dry_run: bool,
    json_output: bool,
) -> dict[str, Any]:
    """Push a single task to the server.

    Args:
        local_task: Local task to push
        local_service: LocalTaskService instance
        status_override: Status to use instead of local status
        done_flag: If True, set status to 'done'
        dry_run: If True, don't actually push
        json_output: Whether in JSON mode

    Returns:
        Dictionary with push result details
    """
    from cli.models.local_task import get_task_dir

    task_service = services.get_task_service()
    identifier = local_task.meta.identifier

    # Get current server state for comparison
    server_task = await task_service.get_task(identifier)

    # Detect what would change
    changes = _detect_local_changes(local_task, server_task)

    # Check for local plan.md
    task_dir = get_task_dir(identifier, local_service.directory)
    plan_path = task_dir / "plan.md"
    local_plan: Optional[str] = None
    if plan_path.exists():
        local_plan = _parse_plan_md(plan_path.read_text(encoding="utf-8"))
        # Compare with server plan
        gen_task = server_task.to_generated()
        server_plan = gen_task.implementation_plan or ""
        if local_plan != server_plan:
            changes["plan"] = (local_plan, server_plan)

    # Apply overrides to changes
    if done_flag:
        changes["status"] = ("done", server_task.status.value)
    elif status_override:
        changes["status"] = (status_override, server_task.status.value)

    result: dict[str, Any] = {
        "identifier": identifier,
        "title": local_task.meta.title,
        "changes": list(changes.keys()),
        "dry_run": dry_run,
        "pushed": False,
    }

    if not changes:
        result["message"] = "No local changes to push"
        return result

    if dry_run:
        result["would_update"] = {
            field: {"local": local_val, "server": server_val}
            for field, (local_val, server_val) in changes.items()
        }
        return result

    # Build and send update - plan is now included in regular update
    update = _build_update_from_local(local_task, status_override, done_flag)
    # Add implementation plan if changed
    if "plan" in changes and local_plan:
        update.implementation_plan = local_plan
    updated_task = await task_service.update_task(identifier, update)

    # Update local .meta.json with pushed_at timestamp and new server state
    now = datetime.now(UTC)
    local_service.update_task_meta(
        identifier,
        pushed_at=now,
        server_updated_at=updated_task.updated_at,
        status=updated_task.status.value,
        priority=updated_task.priority.value if updated_task.priority else 0,
    )

    result["pushed"] = True
    result["server_updated_at"] = (
        updated_task.updated_at.isoformat() if updated_task.updated_at else None
    )

    return result


def _display_push_result(result: dict[str, Any]) -> None:
    """Display push result in human-readable format.

    Args:
        result: Push result dictionary
    """
    identifier = result["identifier"]

    if result.get("dry_run"):
        if result.get("would_update"):
            console.print(
                f"[yellow]Would push[/yellow] [cyan]{identifier}[/cyan] with changes:"
            )
            for field, values in result["would_update"].items():
                local_val = values["local"]
                server_val = values["server"]
                # Truncate long values
                if isinstance(local_val, str) and len(local_val) > 50:
                    local_val = f"{local_val[:50]}..."
                if isinstance(server_val, str) and len(server_val) > 50:
                    server_val = f"{server_val[:50]}..."
                console.print(
                    f"  {field}: [red]{server_val}[/red] → [green]{local_val}[/green]"
                )
        else:
            console.print(f"[dim]{identifier}: No local changes to push[/dim]")
        return

    if not result.get("changes"):
        console.print(f"[dim]{identifier}: No local changes to push[/dim]")
        return

    if result.get("pushed"):
        changes_str = ", ".join(result["changes"])
        console.print(f"[green]✓[/green] Pushed [cyan]{identifier}[/cyan] to server")
        console.print(f"  Updated: {changes_str}")
        if result.get("server_updated_at"):
            console.print(f"  Server updated_at: {result['server_updated_at']}")


@app.command("push")
@async_command()
async def push(
    identifier: Annotated[
        Optional[str],
        typer.Argument(
            help="Task identifier (e.g., DEV-01) to push. Leave empty to push all modified tasks."
        ),
    ] = None,
    status: Annotated[
        Optional[str],
        typer.Option(
            "--status",
            help="Override local status (backlog, todo, active, done, etc.)",
        ),
    ] = None,
    done: Annotated[
        bool,
        typer.Option("--done", help="Push and mark task as done"),
    ] = False,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="Show what would be pushed without pushing"),
    ] = False,
    json_output: Annotated[
        bool,
        typer.Option("--json", help="Output in JSON format"),
    ] = False,
) -> None:
    """Push local task changes to server.

    Uploads local task.md and .meta.json changes back to the AnyTask server.
    Title is extracted from the first '# ' line in task.md.
    Description is the remaining content.

    Examples:

        # Push a single task
        anyt push DEV-01

        # Push and mark as done
        anyt push DEV-01 --done

        # Push with status override
        anyt push DEV-01 --status active

        # See what would be pushed
        anyt push DEV-01 --dry-run

        # Push all modified local tasks
        anyt push
    """
    with CommandContext(require_auth=True, require_workspace=True):
        local_service = LocalTaskService()

        # Check if tasks directory exists
        if not local_service.tasks_dir.exists():
            if json_output:
                console.print_json(
                    data={
                        "success": False,
                        "error": {
                            "code": "NO_LOCAL_TASKS",
                            "message": "No local tasks directory found. Run 'anyt pull' first.",
                        },
                    }
                )
            else:
                console.print(
                    "[red]Error:[/red] No local tasks directory found. Run 'anyt pull' first."
                )
            raise typer.Exit(1)

        if identifier:
            # Push single task
            if not local_service.task_exists(identifier):
                if json_output:
                    console.print_json(
                        data={
                            "success": False,
                            "error": {
                                "code": "NOT_FOUND",
                                "message": f"Task '{identifier}' not found locally",
                            },
                        }
                    )
                else:
                    console.print(
                        f"[red]Error:[/red] Task '{identifier}' not found locally"
                    )
                    console.print(f"Run 'anyt pull {identifier}' first.")
                raise typer.Exit(1)

            local_task = local_service.read_task(identifier)
            result = await _push_single_task(
                local_task,
                local_service,
                status,
                done,
                dry_run,
                json_output,
            )

            if json_output:
                output_json_data(result)
            else:
                _display_push_result(result)

        else:
            # Push all modified local tasks
            local_tasks = local_service.list_local_tasks()

            if not local_tasks:
                if json_output:
                    output_json_list([])
                else:
                    console.print("[yellow]No local tasks found[/yellow]")
                raise typer.Exit(0)

            results: list[dict[str, Any]] = []
            pushed_count = 0

            for local_task in local_tasks:
                result = await _push_single_task(
                    local_task,
                    local_service,
                    status,
                    done,
                    dry_run,
                    json_output,
                )
                results.append(result)

                if not json_output:
                    _display_push_result(result)

                if result.get("pushed"):
                    pushed_count += 1

            if json_output:
                output_json_list(results)
            else:
                console.print()
                if dry_run:
                    changes_count = sum(1 for r in results if r.get("would_update"))
                    console.print(
                        f"[yellow]Dry run:[/yellow] {changes_count} task(s) would be pushed"
                    )
                else:
                    console.print(
                        f"[green]✓[/green] Pushed {pushed_count} task(s) to server"
                    )


def _get_file_manager_command() -> list[str]:
    """Get the command to open a file/folder in the system file manager.

    Returns:
        Command list for the current platform's file manager
    """
    system = platform.system()
    if system == "Darwin":
        return ["open"]
    elif system == "Linux":
        return ["xdg-open"]
    else:
        # Windows
        return ["explorer"]


def _open_with_command(
    cmd: list[str], target: str, wait: bool = False
) -> subprocess.CompletedProcess[bytes]:
    """Open a file/folder with the specified command.

    Args:
        cmd: Command list (e.g., ["code"], ["open"])
        target: Path to open
        wait: Whether to wait for the process to complete

    Returns:
        CompletedProcess result
    """
    full_cmd = cmd + [target]
    if wait:
        return subprocess.run(full_cmd, capture_output=True)
    else:
        # Don't wait for editor to close
        return subprocess.run(full_cmd, capture_output=True, start_new_session=True)


@app.command("open")
@async_command()
async def open_task(
    identifier: Annotated[
        Optional[str],
        typer.Argument(
            help="Task identifier (e.g., DEV-01) to open. Leave empty for active task."
        ),
    ] = None,
    code: Annotated[
        bool,
        typer.Option("--code", help="Open in VSCode"),
    ] = False,
    finder: Annotated[
        bool,
        typer.Option("--finder", help="Open in file manager (Finder/Explorer)"),
    ] = False,
    file: Annotated[
        Optional[str],
        typer.Option(
            "--file", "-f", help="Open a specific file within the task folder"
        ),
    ] = None,
    json_output: Annotated[
        bool,
        typer.Option("--json", help="Output in JSON format"),
    ] = False,
) -> None:
    """Open a task folder in your preferred editor or file manager.

    Opens the task's local folder in your editor, VSCode, or system file manager.
    If the task isn't available locally, prompts to pull it first.

    Examples:

        # Open task in default $EDITOR
        anyt open DEV-01

        # Open in VSCode
        anyt open DEV-01 --code

        # Open in Finder/Explorer
        anyt open DEV-01 --finder

        # Open a specific file
        anyt open DEV-01 --file task.md

        # Open active task
        anyt open
    """
    with CommandContext(require_auth=True, require_workspace=True):
        local_service = LocalTaskService()

        # Resolve identifier - use active task if not provided
        resolved_identifier = identifier
        if not resolved_identifier:
            active_task = ActiveTaskConfig.load()
            if active_task:
                resolved_identifier = active_task.identifier
            else:
                if json_output:
                    console.print_json(
                        data={
                            "success": False,
                            "error": {
                                "code": "NO_IDENTIFIER",
                                "message": "No task identifier provided and no active task set",
                            },
                        }
                    )
                else:
                    console.print(
                        "[red]Error:[/red] No task identifier provided and no active task set"
                    )
                    console.print("Examples:")
                    console.print("  anyt open DEV-01")
                    console.print("  anyt task pick DEV-01  # then 'anyt open'")
                raise typer.Exit(1)

        # Check if task exists locally
        if not local_service.task_exists(resolved_identifier):
            if json_output:
                console.print_json(
                    data={
                        "success": False,
                        "error": {
                            "code": "NOT_FOUND_LOCALLY",
                            "message": f"Task '{resolved_identifier}' not found locally",
                            "suggestion": f"Run 'anyt pull {resolved_identifier}' first",
                        },
                    }
                )
            else:
                console.print(
                    f"[red]Error:[/red] Task '{resolved_identifier}' not found locally"
                )
                console.print(
                    f"Pull it first with: [cyan]anyt pull {resolved_identifier}[/cyan]"
                )
            raise typer.Exit(1)

        # Get task directory
        from cli.models.local_task import get_task_dir

        task_dir = get_task_dir(resolved_identifier, local_service.directory)

        # Determine target (specific file or directory)
        if file:
            target_path = task_dir / file
            if not target_path.exists():
                if json_output:
                    console.print_json(
                        data={
                            "success": False,
                            "error": {
                                "code": "FILE_NOT_FOUND",
                                "message": f"File '{file}' not found in task folder",
                            },
                        }
                    )
                else:
                    console.print(
                        f"[red]Error:[/red] File '{file}' not found in task folder"
                    )
                    console.print(f"Task folder: {task_dir}")
                raise typer.Exit(1)
        else:
            target_path = task_dir

        target = str(target_path)

        # Determine which opener to use
        result_data = {
            "identifier": resolved_identifier,
            "path": target,
            "opened_with": "",
        }

        try:
            if code:
                # Open in VSCode
                _open_with_command(["code"], target)
                result_data["opened_with"] = "vscode"
                if not json_output:
                    console.print(
                        f"[green]✓[/green] Opening [cyan]{resolved_identifier}[/cyan] in VSCode..."
                    )
            elif finder:
                # Open in system file manager
                cmd = _get_file_manager_command()
                _open_with_command(cmd, target)
                result_data["opened_with"] = "file_manager"
                manager_name = (
                    "Finder" if platform.system() == "Darwin" else "file manager"
                )
                if not json_output:
                    console.print(
                        f"[green]✓[/green] Opening [cyan]{resolved_identifier}[/cyan] in {manager_name}..."
                    )
            else:
                # Open in $EDITOR (default to vim)
                editor = os.environ.get("EDITOR", "vim")
                # Default to opening task.md if opening directory in editor
                editor_target = target
                if target_path.is_dir():
                    editor_target = str(task_dir / "task.md")
                _open_with_command([editor], editor_target)
                result_data["opened_with"] = editor
                if not json_output:
                    console.print(
                        f"[green]✓[/green] Opening [cyan]{resolved_identifier}[/cyan] in {editor}..."
                    )

            if json_output:
                output_json_data(result_data)

        except FileNotFoundError as e:
            if json_output:
                console.print_json(
                    data={
                        "success": False,
                        "error": {
                            "code": "COMMAND_NOT_FOUND",
                            "message": f"Command not found: {e}",
                        },
                    }
                )
            else:
                console.print(f"[red]Error:[/red] Command not found: {e}")
                if code:
                    console.print(
                        "Make sure VSCode is installed and 'code' is in your PATH"
                    )
            raise typer.Exit(1)
