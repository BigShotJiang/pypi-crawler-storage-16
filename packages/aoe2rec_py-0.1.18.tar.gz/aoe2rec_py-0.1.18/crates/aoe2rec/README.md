# aoe2rec

A Rust library for reading and writing Age of Empires 2 recorded game files.

## Usage

Add this to your `Cargo.toml`:

```toml
[dependencies]
aoe2rec = "0.1"
```

## Example

```rust
<TODO>
```

## License

This project is licensed under the [MIT](./LICENSE) license.

## Credits

This project is largely an adaptation of [aoc-mgz](https://github.com/happyleavesaoc/aoc-mgz). Another source of inspiration is the [genie-rs](https://github.com/SiegeEngineers/genie-rs/) project.
Many thanks to [happyleaves](https://github.com/happyleavesaoc) and [simonsan](https://github.com/simonsan), without whom this project would not exist.
