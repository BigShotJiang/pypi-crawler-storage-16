# BulkActionNotOnExistence

Bulk Action to be taken if the entity does not exist.

## Enum

* `FAIL` (value: `'fail'`)

* `SKIP` (value: `'skip'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


