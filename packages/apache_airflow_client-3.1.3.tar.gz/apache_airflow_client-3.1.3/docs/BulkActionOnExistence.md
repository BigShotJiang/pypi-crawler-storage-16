# BulkActionOnExistence

Bulk Action to be taken if the entity already exists or not.

## Enum

* `FAIL` (value: `'fail'`)

* `SKIP` (value: `'skip'`)

* `OVERWRITE` (value: `'overwrite'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


