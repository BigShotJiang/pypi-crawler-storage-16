# ClearTaskInstancesBodyTaskIdsInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from airflow_client.client.models.clear_task_instances_body_task_ids_inner import ClearTaskInstancesBodyTaskIdsInner

# TODO update the JSON string below
json = "{}"
# create an instance of ClearTaskInstancesBodyTaskIdsInner from a JSON string
clear_task_instances_body_task_ids_inner_instance = ClearTaskInstancesBodyTaskIdsInner.from_json(json)
# print the JSON string representation of the object
print(ClearTaskInstancesBodyTaskIdsInner.to_json())

# convert the object into a dict
clear_task_instances_body_task_ids_inner_dict = clear_task_instances_body_task_ids_inner_instance.to_dict()
# create an instance of ClearTaskInstancesBodyTaskIdsInner from a dict
clear_task_instances_body_task_ids_inner_from_dict = ClearTaskInstancesBodyTaskIdsInner.from_dict(clear_task_instances_body_task_ids_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


