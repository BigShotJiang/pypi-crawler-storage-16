# DAGRunPatchStates

Enum for DAG Run states when updating a DAG Run.

## Enum

* `QUEUED` (value: `'queued'`)

* `SUCCESS` (value: `'success'`)

* `FAILED` (value: `'failed'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


