# DagRunType

Class with DagRun types.

## Enum

* `BACKFILL` (value: `'backfill'`)

* `SCHEDULED` (value: `'scheduled'`)

* `MANUAL` (value: `'manual'`)

* `ASSET_TRIGGERED` (value: `'asset_triggered'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


