# DagWarningType

Enum for DAG warning types.  This is the set of allowable values for the ``warning_type`` field in the DagWarning model.

## Enum

* `ASSET_CONFLICT` (value: `'asset conflict'`)

* `NON_MINUS_EXISTENT_POOL` (value: `'non-existent pool'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


