# ReprocessBehavior

Internal enum for setting reprocess behavior in a backfill.  :meta private:

## Enum

* `FAILED` (value: `'failed'`)

* `COMPLETED` (value: `'completed'`)

* `NONE` (value: `'none'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


