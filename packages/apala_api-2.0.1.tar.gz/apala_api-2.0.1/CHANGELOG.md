version 2.0.1
-------------

* Changed our pydantic requirements to match `semantic-kernel` 

version 2.0.0
--------------

* First Version with a CHANGELOG.md
* Removed Zip and Application Reason
