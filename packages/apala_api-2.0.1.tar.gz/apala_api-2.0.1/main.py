# Copyright (c) 2025 Apala Cap. All rights reserved.
# This software is proprietary and confidential.

def main():
    print("Hello from apala-api!")


if __name__ == "__main__":
    main()
