##### Package <em>apb_duckdb_utils</em>

Modules to add functionality (spatial and generic) over `duckdb` 

For all the functionality available requires `GDAL` library version 3.6<=3.10 and instant client Oracle installed.

To install:
```shell
pip install apb_duckdb_utils
```

Documentation here [apb_duckdb_utils](https://serveis.portdebarcelona.cat/generic_python_packages/apb_duckdb_utils.html)
