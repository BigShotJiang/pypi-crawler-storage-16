Managing Delegates
******************

.. click:: ape_safe._cli.delegates:delegates
  :prog: ape safe delegates
  :nested: full
