Local Safe Management
*********************

.. click:: ape_safe._cli.safe_mgmt:add
  :prog: ape safe add
  :nested: full

.. click:: ape_safe._cli.safe_mgmt:_list
  :prog: ape safe list
  :nested: full

.. click:: ape_safe._cli.safe_mgmt:remove
  :prog: ape safe remove
  :nested: full

.. click:: ape_safe._cli.safe_mgmt:all_txns
  :prog: ape safe all-txns
  :nested: full
