```{eval-rst}
.. automodule:: ape_safe.cli
    :members:
```
