# 🔑 PyPI Token Setup Guide

## 📁 Token File Location

**File:** `~/.pypirc`  
**Full Path:** `/root/.pypirc`

---

## 📝 View Current Configuration

```bash
cat ~/.pypirc
```

---

## ✏️ Edit Token File

### Option 1: Using Nano (Easiest)
```bash
nano ~/.pypirc
```

**Save:** Press `Ctrl+O`, then `Enter`  
**Exit:** Press `Ctrl+X`

### Option 2: Using Vim
```bash
vim ~/.pypirc
```

**Edit:** Press `i` to enter insert mode  
**Save & Exit:** Press `Esc`, type `:wq`, press `Enter`

### Option 3: Using Vi
```bash
vi ~/.pypirc
```

---

## 📋 File Structure

### Current (Test PyPI Only)

```ini
[distutils]
index-servers =
  testpypi

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-YOUR_TEST_TOKEN_HERE
```

### Recommended (Both Test & Production)

```ini
[distutils]
index-servers =
  pypi
  testpypi

[pypi]
repository = https://upload.pypi.org/legacy/
username = __token__
password = pypi-YOUR_PRODUCTION_TOKEN_HERE

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-YOUR_TEST_TOKEN_HERE
```

---

## 🎫 Get Your Tokens

### Test PyPI Token
1. Visit: https://test.pypi.org/manage/account/token/
2. Login to your Test PyPI account
3. Click **"Add API token"**
4. Name: `apex-upload-test`
5. Scope: Choose project or entire account
6. Click **"Create token"**
7. **Copy the token immediately!** (Shown only once)
8. Paste into `~/.pypirc` under `[testpypi]` password field

### Production PyPI Token
1. Visit: https://pypi.org/manage/account/token/
2. Login to your PyPI account (or register)
3. Click **"Add API token"**
4. Name: `apex-upload`
5. Scope: Choose project or entire account
6. Click **"Create token"**
7. **Copy the token immediately!** (Shown only once)
8. Paste into `~/.pypirc` under `[pypi]` password field

---

## 🔧 Complete Setup Steps

### Step 1: Create/Edit File
```bash
nano ~/.pypirc
```

### Step 2: Add Configuration

Paste this template:

```ini
[distutils]
index-servers =
  pypi
  testpypi

[pypi]
repository = https://upload.pypi.org/legacy/
username = __token__
password = PASTE_YOUR_PRODUCTION_TOKEN_HERE

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = PASTE_YOUR_TEST_TOKEN_HERE
```

### Step 3: Replace Tokens

Replace:
- `PASTE_YOUR_PRODUCTION_TOKEN_HERE` with your actual production token
- `PASTE_YOUR_TEST_TOKEN_HERE` with your actual test token

### Step 4: Save & Set Permissions
```bash
# Save the file (Ctrl+O, Enter, Ctrl+X in nano)

# Set proper permissions
chmod 600 ~/.pypirc
```

---

## 🚀 Publishing Commands

### To Test PyPI
```bash
cd /root/boiler/Python-boiler-plate
twine upload --repository testpypi dist/*
```

### To Production PyPI
```bash
cd /root/boiler/Python-boiler-plate
twine upload dist/*
```

Or explicitly:
```bash
twine upload --repository pypi dist/*
```

---

## ⚠️ Security Best Practices

### DO:
- ✅ Keep tokens in `~/.pypirc` only
- ✅ Set file permissions: `chmod 600 ~/.pypirc`
- ✅ Copy token immediately when shown
- ✅ Use project-scoped tokens when possible
- ✅ Revoke and recreate if compromised

### DON'T:
- ❌ Never commit `~/.pypirc` to Git
- ❌ Never share tokens publicly
- ❌ Never post tokens in issues/forums
- ❌ Never hardcode tokens in scripts
- ❌ Never use same token across projects

---

## 🔍 Troubleshooting

### Permission Denied
```bash
# Fix permissions
chmod 600 ~/.pypirc
```

### Invalid Token
```bash
# Regenerate token at:
# https://pypi.org/manage/account/token/
# Then update ~/.pypirc
```

### File Not Found
```bash
# Create the file
touch ~/.pypirc
chmod 600 ~/.pypirc
nano ~/.pypirc
```

---

## 📊 Token Format

Tokens always start with `pypi-` and look like:

```
pypi-AgEIcHlwaS5vcmcCJGFiY2RlZmdoLWlqa2wtbW5vcC1xcnN0dXZ3LXh5ejAxMjM0NTY3ODkwAA
```

**Important:** Copy the entire token, including `pypi-` prefix!

---

## 🎯 Quick Reference

| Task | Command |
|------|---------|
| View config | `cat ~/.pypirc` |
| Edit config | `nano ~/.pypirc` |
| Set permissions | `chmod 600 ~/.pypirc` |
| Upload to Test PyPI | `twine upload --repository testpypi dist/*` |
| Upload to PyPI | `twine upload dist/*` |

---

## 📚 Additional Resources

- **PyPI Help:** https://pypi.org/help/
- **Test PyPI Help:** https://test.pypi.org/help/
- **Twine Docs:** https://twine.readthedocs.io/
- **Token Security:** https://pypi.org/help/#apitoken

---

**Remember:** Tokens are like passwords - keep them secret! 🔐

