"""Settings API routes."""

from apex.api.v1.settings.router import router

__all__ = ["router"]

