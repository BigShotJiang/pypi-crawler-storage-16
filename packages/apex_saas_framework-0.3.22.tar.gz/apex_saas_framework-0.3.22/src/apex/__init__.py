"""
Apex - Pure Python Library for SaaS Functionality

A pure Python library - NO APIs provided. You write your own APIs using the features you need.

Key Points:
- No API endpoints - You write your own APIs (FastAPI, Flask, Django, etc.)
- Use only what you need - Pick the features you want
- Your database choice - SQLite, PostgreSQL, MySQL, or any SQLAlchemy-supported database
- Minimal code - Just database URL and you're ready
- MySQL Support - UUIDs stored as CHAR(36), works seamlessly with PostgreSQL UUIDs

Quick Start (LangChain-style):
    from apex import Client, set_default_client, bootstrap
    from apex.auth import signup, login
    from apex.users import create_user, get_user
    from apex.core.base import Base
    
    # Define your models
    class User(Base):
        __tablename__ = "users"
        id = Column(Integer, primary_key=True)
        email = Column(String(255), unique=True)
        password_hash = Column(String(255))
    
    # Initialize client once
    client = Client(database_url="sqlite+aiosqlite:///./mydb.db", user_model=User)
    set_default_client(client)
    
    # Bootstrap database
    bootstrap(models=[User])
    
    # Use functions directly (no await!)
    user = signup(email="user@example.com", password="pass123")
    tokens = login(email="user@example.com", password="pass123")
    user = get_user(user_id=user.id)
"""

__version__ = "0.3.22"

# Main Client (Clerk-style)
from apex.client import Client

# LangChain-style direct function imports
from apex.auth import signup, login, verify_token, refresh_token as refresh_access_token, forgot_password, reset_password, change_password
from apex.users import create_user, get_user, update_user, delete_user
from apex.organizations import create_organization, get_organization, list_organizations
from apex.sync import set_default_client, bootstrap, send_email, send_bulk_email

# Base Models - OPTIONAL helpers (users can use these OR define their own)
from apex.domain.models.user import BaseUser
from apex.domain.models.organization import BaseOrganization, BaseOrganizationLocation
from apex.domain.models.role import BaseRole
from apex.domain.models.permission import BasePermission

# Flexible base classes - for users who want more control
from apex.core.base import (
    Base,
    TimestampMixin,
    IntegerPKMixin,
    StringPKMixin,
    UUIDPKMixin,
    MySQLUUIDMixin,
    FlexibleBaseModel,
    JSONType,
)
from apex.core.flexible_models import FlexibleUser, FlexibleOrganization, FlexibleRole, FlexiblePermission

# Convenience aliases
User = BaseUser
Organization = BaseOrganization
OrganizationLocation = BaseOrganizationLocation
Role = BaseRole
Permission = BasePermission

# Resources (for advanced usage)
from apex.resources.users import Users
from apex.resources.auth import Auth
from apex.resources.organizations import Organizations
from apex.resources.roles import Roles
from apex.resources.permissions import Permissions
from apex.resources.modules import Modules
from apex.resources.settings import Settings
from apex.resources.payments import Payments
from apex.resources.email import Email
from apex.resources.files import Files
# Sync convenience wrappers (optional)
from apex import sync as sync_api

from apex.core.config import Settings, get_settings

__all__ = [
    # Main Client (Primary API)
    "Client",
    
    # LangChain-style direct function imports
    "signup",
    "login",
    "verify_token",
    "refresh_access_token",
    "forgot_password",
    "reset_password",
    "change_password",
    "create_user",
    "get_user",
    "update_user",
    "delete_user",
    "create_organization",
    "get_organization",
    "list_organizations",
    "set_default_client",
    "bootstrap",
    "send_email",
    "send_bulk_email",
    
    # Models (Base names - users extend these OR define their own)
    "BaseUser",
    "BaseOrganization",
    "BaseOrganizationLocation",
    "BaseRole",
    "BasePermission",
    
    # Models (Convenience aliases)
    "User",
    "Organization",
    "OrganizationLocation",
    "Role",
    "Permission",
    
    # Flexible base classes (for users who want complete control)
    "Base",
    "TimestampMixin",
    "IntegerPKMixin",
    "StringPKMixin",
    "UUIDPKMixin",
    "MySQLUUIDMixin",
    "FlexibleBaseModel",
    "JSONType",
    "FlexibleUser",
    "FlexibleOrganization",
    "FlexibleRole",
    "FlexiblePermission",
    
    # Resources (Advanced usage)
    "Users",
    "Auth",
    "Organizations",
    "Roles",
    "Permissions",
    "Modules",
    "Settings",
    "Payments",
    "Email",
    "Files",
    
    # Sync wrappers (optional)
    "sync_api",

    # Settings helpers
    "Settings",
    "get_settings",
    
    # Version
    "__version__",
]

