"""Payments API routes (PayPal)."""

from apex.api.v1.payments.router import router

__all__ = ["router"]

