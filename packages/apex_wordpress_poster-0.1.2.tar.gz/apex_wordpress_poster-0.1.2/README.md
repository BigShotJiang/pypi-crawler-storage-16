# WordPress Poster Package

A simple Python package to post HTML content with images to WordPress via the REST API.

## Features

- ✅ Upload images from URLs or local file paths to WordPress media library
- ✅ Replace image paths/URLs in HTML with WordPress media URLs automatically
- ✅ Post HTML content to WordPress
- ✅ Automatic title extraction from HTML
- ✅ Comprehensive error handling
- ✅ Supports both absolute and relative file paths

## Installation

### From Source

```bash
pip install -e .
```

### Build and Install

```bash
python setup.py sdist bdist_wheel
pip install dist/wordpress_poster-1.0.0.tar.gz
```

## Usage

```python
from wordpress_poster import post_to_wordpress

# Post with images
result = post_to_wordpress(
    wordpress_url="https://yoursite.com",
    wordpress_username="your_username",
    wordpress_password="your_app_password",
    html_content="<h1>My Post</h1><p>Content here</p>",
    image_links=[
        "https://example.com/image1.jpg",
        "https://example.com/image2.png"
    ],
    title="My Blog Post",  # Optional, will extract from HTML if not provided
    status="publish"  # Optional, default is "publish"
)

post_id, post_link, upload_info = result

if post_id:
    print(f"Post created! ID: {post_id}, Link: {post_link}")
    print(f"Uploaded images: {upload_info['uploaded_images']}")
else:
    print("Failed to create post")
```

## Parameters

- `wordpress_url` (str, required): Your WordPress site URL (e.g., "https://yoursite.com")
- `wordpress_username` (str, required): WordPress username
- `wordpress_password` (str, required): WordPress application password (not regular password)
- `html_content` (str, required): HTML content to post (may contain image paths like `<img src="/content/image.png" />`)
- `image_links` (list, optional): List of image URLs (http://, https://) or local file paths (e.g., "/content/image.png"). 
                                  Paths should match what appears in `html_content`.
- `title` (str, optional): Post title (will extract from `<h1>` tag if not provided)
- `status` (str, optional): Post status (default: "publish")

## Returns

Returns a tuple: `(post_id, post_link, upload_info)`

- `post_id`: WordPress post ID (None if failed)
- `post_link`: URL to the published post (None if failed)
- `upload_info`: Dictionary containing:
  - `uploaded_images`: Dict mapping original image paths/URLs to WordPress media URLs
  - `failed_images`: List of image paths/URLs that failed to upload

## WordPress Setup

1. Enable REST API in WordPress (usually enabled by default)
2. Create an Application Password:
   - Go to Users → Your Profile
   - Scroll to "Application Passwords"
   - Create a new application password
   - Use this password (not your regular WordPress password)

## Notes

- The function automatically sets `WP_USE_COOKIE_AUTH="false"` as an environment variable
- Images are processed one by one (downloaded from URLs or read from local paths) and uploaded to WordPress
- Image paths/URLs in HTML are automatically replaced with WordPress media URLs
- Supports both absolute and relative file paths (e.g., "/content/image.png" or "./images/image.png")
- The HTML content is wrapped in `<!-- wp:html -->` blocks to preserve formatting
- For local file paths, the package will search for files relative to the current working directory

## Requirements

- Python 3.7+
- requests >= 2.31.0

