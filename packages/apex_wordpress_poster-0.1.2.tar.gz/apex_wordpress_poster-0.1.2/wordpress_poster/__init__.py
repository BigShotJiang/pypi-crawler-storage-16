"""
WordPress Posting Package

A standalone function to post HTML content with images to WordPress.
This module can be used as a pip package.

Supports both image URLs and local file paths.

Usage with URLs:
    from wordpress_poster import post_to_wordpress
    
    result = post_to_wordpress(
        wordpress_url="https://yoursite.com",
        wordpress_username="your_username",
        wordpress_password="your_app_password",
        html_content="<h1>My Post</h1><img src='https://example.com/image1.jpg' />",
        image_links=["https://example.com/image1.jpg"]
    )

Usage with local file paths:
    html_content = "<h1>Hello!</h1><img src='/content/IMG_2004.png' />"
    result = post_to_wordpress(
        wordpress_url="https://yoursite.com",
        wordpress_username="your_username",
        wordpress_password="your_app_password",
        html_content=html_content,
        image_links=["/content/IMG_2004.png"]
    )
"""
import os
import requests
import base64
import json
import tempfile
from typing import Optional, Tuple, List
from urllib.parse import urlparse


def post_to_wordpress(
    wordpress_url: str,
    wordpress_username: str,
    wordpress_password: str,
    html_content: str,
    image_links: Optional[List[str]] = None,
    title: Optional[str] = None,
    status: str = "publish"
) -> Tuple[Optional[int], Optional[str], dict]:
    """
    Post HTML content with images to WordPress.
    
    This function:
    1. Processes images from URLs or local file paths one by one
    2. Downloads images from URLs or uses local file paths
    3. Uploads each image to WordPress media library
    4. Replaces image paths/URLs in HTML with WordPress media URLs
    5. Posts the HTML content to WordPress
    
    Args:
        wordpress_url: WordPress site URL (e.g., "https://yoursite.com")
        wordpress_username: WordPress username
        wordpress_password: WordPress application password
        html_content: HTML content to post (may contain image paths like <img src="/content/image.png" />)
        image_links: List of image URLs (http://, https://) or local file paths (e.g., "/content/image.png")
                    The paths should match what appears in html_content. (optional)
        title: Post title (optional, will extract from HTML if not provided)
        status: Post status (default: "publish")
        
    Returns:
        Tuple of (post_id, post_link, upload_info) or (None, None, {}) if failed
        upload_info contains: uploaded_images (dict mapping original_path/url to wp_url)
        
    Example:
        html = "<h1>Hello!</h1><img src='/content/IMG_2004.png' />"
        result = post_to_wordpress(
            wordpress_url="https://yoursite.com",
            wordpress_username="user",
            wordpress_password="pass",
            html_content=html,
            image_links=["/content/IMG_2004.png"]
        )
    """
    # Set WP_USE_COOKIE_AUTH to false
    os.environ["WP_USE_COOKIE_AUTH"] = "false"
    
    # Normalize WordPress URL (remove trailing slash)
    wordpress_url = wordpress_url.rstrip('/')
    
    # Initialize upload info
    upload_info = {
        "uploaded_images": {},
        "failed_images": []
    }
    
    # Step 1: Process and upload images one by one
    if image_links:
        print(f"📤 Processing {len(image_links)} image(s)...")
        
        for idx, image_path_or_url in enumerate(image_links, 1):
            if not image_path_or_url or not image_path_or_url.strip():
                continue
            
            image_path_or_url = image_path_or_url.strip()
            print(f"  [{idx}/{len(image_links)}] Processing: {image_path_or_url}")
            
            try:
                # Determine if it's a URL or a local file path
                is_url = image_path_or_url.startswith(('http://', 'https://'))
                tmp_path = None
                filename = None
                
                if is_url:
                    # It's a URL - download it
                    print(f"    📥 Downloading from URL...")
                    response = requests.get(image_path_or_url, timeout=30, stream=True)
                    response.raise_for_status()
                    
                    # Get content type
                    content_type = response.headers.get('Content-Type', 'image/jpeg')
                    if not content_type.startswith('image/'):
                        print(f"    ⚠️  Warning: Content-Type is {content_type}, treating as image")
                        content_type = 'image/jpeg'
                    
                    # Get filename from URL or generate one
                    parsed_url = urlparse(image_path_or_url)
                    filename = os.path.basename(parsed_url.path)
                    if not filename or '.' not in filename:
                        # Generate filename based on content type
                        ext = 'jpg' if 'jpeg' in content_type else 'png' if 'png' in content_type else 'gif'
                        filename = f"image_{idx}.{ext}"
                    
                    # Save to temporary file
                    with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(filename)[1]) as tmp_file:
                        tmp_file.write(response.content)
                        tmp_path = tmp_file.name
                else:
                    # It's a local file path - check if it exists
                    # Handle both absolute and relative paths
                    if os.path.isabs(image_path_or_url):
                        file_path = image_path_or_url
                    else:
                        # Try relative path from current directory
                        file_path = os.path.abspath(image_path_or_url)
                        if not os.path.exists(file_path):
                            # Try with leading slash removed (for paths like "/content/image.png")
                            file_path = os.path.abspath(image_path_or_url.lstrip('/'))
                    
                    if not os.path.exists(file_path):
                        print(f"    ❌ Error: File not found at {file_path}")
                        upload_info["failed_images"].append(image_path_or_url)
                        continue
                    
                    tmp_path = file_path
                    filename = os.path.basename(file_path)
                    print(f"    📁 Found local file: {file_path}")
                
                # Upload to WordPress
                wp_media_id, wp_media_url = _upload_image_to_wordpress(
                    wordpress_url=wordpress_url,
                    wordpress_username=wordpress_username,
                    wordpress_password=wordpress_password,
                    image_path=tmp_path,
                    image_title=filename
                )
                
                # Clean up temp file if it was downloaded (not if it was a local file)
                if is_url and tmp_path and os.path.exists(tmp_path):
                    try:
                        os.unlink(tmp_path)
                    except:
                        pass
                
                if wp_media_id and wp_media_url:
                    upload_info["uploaded_images"][image_path_or_url] = wp_media_url
                    print(f"    ✅ Uploaded successfully! WordPress URL: {wp_media_url}")
                    
                    # Replace image path/URL in HTML content with WordPress media URL
                    # Replace the original path/URL
                    html_content = html_content.replace(image_path_or_url, wp_media_url)
                    
                    # Also replace variations that might appear in HTML:
                    # - Just the filename
                    # - Path with leading slash
                    # - Path without leading slash
                    # - Full path variations
                    if filename:
                        # Replace filename if it appears standalone
                        html_content = html_content.replace(f'"{filename}"', f'"{wp_media_url}"')
                        html_content = html_content.replace(f"'{filename}'", f"'{wp_media_url}'")
                        html_content = html_content.replace(f'={filename}', f'={wp_media_url}')
                    
                    # Replace path variations
                    path_variations = [
                        image_path_or_url,
                        image_path_or_url.lstrip('/'),
                        '/' + image_path_or_url.lstrip('/'),
                        os.path.basename(image_path_or_url),
                    ]
                    
                    for path_var in path_variations:
                        if path_var and path_var in html_content:
                            html_content = html_content.replace(path_var, wp_media_url)
                else:
                    upload_info["failed_images"].append(image_path_or_url)
                    print(f"    ❌ Failed to upload image")
                    
            except Exception as e:
                upload_info["failed_images"].append(image_path_or_url)
                print(f"    ❌ Error processing image: {str(e)}")
                import traceback
                traceback.print_exc()
                continue
    
    # Step 2: Extract title from HTML if not provided
    if not title:
        # Try to extract from <h1> tag
        import re
        h1_match = re.search(r'<h1[^>]*>(.*?)</h1>', html_content, re.IGNORECASE | re.DOTALL)
        if h1_match:
            title = re.sub(r'<[^>]+>', '', h1_match.group(1)).strip()
        else:
            # Fallback: use first 50 characters
            text_content = re.sub(r'<[^>]+>', '', html_content).strip()
            title = text_content[:50] if text_content else "Untitled Post"
    
    # Step 3: Wrap HTML in wp:html block to preserve layout
    wrapped_html = f"<!-- wp:html -->\n{html_content}\n<!-- /wp:html -->"
    
    # Step 4: Create WordPress post
    print(f"\n📝 Creating WordPress post: '{title}'")
    post_id, post_link = _create_wordpress_post(
        wordpress_url=wordpress_url,
        wordpress_username=wordpress_username,
        wordpress_password=wordpress_password,
        title=title,
        html_content=wrapped_html,
        status=status
    )
    
    if post_id:
        print(f"✅ Post created successfully! Post ID: {post_id}, Link: {post_link}")
        return post_id, post_link, upload_info
    else:
        print(f"❌ Failed to create post")
        return None, None, upload_info


def _get_auth_headers(wordpress_username: str, wordpress_password: str) -> dict:
    """Get authentication headers for WordPress API."""
    credentials = f"{wordpress_username}:{wordpress_password}"
    token = base64.b64encode(credentials.encode()).decode("utf-8")
    
    return {
        "Authorization": f"Basic {token}",
        "Accept": "application/json",
    }


def _upload_image_to_wordpress(
    wordpress_url: str,
    wordpress_username: str,
    wordpress_password: str,
    image_path: str,
    image_title: str = "Blog Image"
) -> Tuple[Optional[int], Optional[str]]:
    """
    Upload an image to WordPress media library.
    
    Args:
        wordpress_url: WordPress site URL
        wordpress_username: WordPress username
        wordpress_password: WordPress application password
        image_path: Path to the image file
        image_title: Title for the image
        
    Returns:
        Tuple of (media_id, media_url) or (None, None) if failed
    """
    if not os.path.exists(image_path):
        print(f"    Error: Image file not found at {image_path}")
        return None, None
    
    media_endpoint = f"{wordpress_url}/wp-json/wp/v2/media"
    
    # Determine content type
    file_extension = os.path.splitext(image_path)[1].lower()
    content_type = "application/octet-stream"
    if file_extension in [".jpg", ".jpeg"]:
        content_type = "image/jpeg"
    elif file_extension == ".png":
        content_type = "image/png"
    elif file_extension == ".gif":
        content_type = "image/gif"
    elif file_extension == ".webp":
        content_type = "image/webp"
    
    media_headers = _get_auth_headers(wordpress_username, wordpress_password)
    media_headers["Content-Type"] = content_type
    media_headers["Content-Disposition"] = f"attachment; filename={os.path.basename(image_path)}"
    
    try:
        with open(image_path, "rb") as image_file:
            image_data = image_file.read()
        
        response = requests.post(
            media_endpoint,
            headers=media_headers,
            data=image_data,
            timeout=60
        )
        response.raise_for_status()
        
        media_info = response.json()
        media_id = media_info.get("id")
        media_url = media_info.get("source_url") or media_info.get("guid", {}).get("rendered", "")
        
        return media_id, media_url
        
    except requests.exceptions.RequestException as e:
        print(f"    Error uploading image: {e}")
        if hasattr(e, 'response') and e.response is not None:
            print(f"    Response status: {e.response.status_code}")
            try:
                print(f"    Response body: {e.response.text[:200]}")
            except:
                pass
        return None, None


def _create_wordpress_post(
    wordpress_url: str,
    wordpress_username: str,
    wordpress_password: str,
    title: str,
    html_content: str,
    status: str = "publish",
    featured_media_id: Optional[int] = None,
    categories: Optional[list] = None,
    tags: Optional[list] = None
) -> Tuple[Optional[int], Optional[str]]:
    """
    Create a new WordPress post.
    
    Args:
        wordpress_url: WordPress site URL
        wordpress_username: WordPress username
        wordpress_password: WordPress application password
        title: Post title
        html_content: HTML content of the post
        status: Post status (default: "publish")
        featured_media_id: Optional featured image media ID
        categories: Optional list of category IDs
        tags: Optional list of tag IDs
        
    Returns:
        Tuple of (post_id, post_link) or (None, None) if failed
    """
    posts_endpoint = f"{wordpress_url}/wp-json/wp/v2/posts"
    
    post_data = {
        "title": title,
        "content": html_content,
        "status": status,
        "comment_status": "open",
        "ping_status": "open",
    }
    
    if featured_media_id:
        post_data["featured_media"] = featured_media_id
    
    if categories:
        post_data["categories"] = categories
    
    if tags:
        post_data["tags"] = tags
    
    post_headers = _get_auth_headers(wordpress_username, wordpress_password)
    post_headers["Content-Type"] = "application/json"
    
    try:
        response = requests.post(
            posts_endpoint,
            headers=post_headers,
            data=json.dumps(post_data),
            timeout=60
        )
        response.raise_for_status()
        
        post_info = response.json()
        post_id = post_info.get("id")
        post_link = post_info.get("link", "")
        
        return post_id, post_link
        
    except requests.exceptions.RequestException as e:
        print(f"Error creating post: {e}")
        if hasattr(e, 'response') and e.response is not None:
            print(f"Response status: {e.response.status_code}")
            try:
                print(f"Response body: {e.response.text[:500]}")
            except:
                pass
        return None, None


# Alias for convenience
WP_USE_COOKIE_AUTH = "false"  # This is set as environment variable in the function

