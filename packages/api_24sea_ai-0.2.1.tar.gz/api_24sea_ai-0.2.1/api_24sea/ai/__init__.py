# -*- coding: utf-8 -*-
"""Namespace package for api_24sea.ai, as indicated by PEP 420.

Do not create an `__init__.py` at the top-level `api_24sea/`.
"""

from .version import __version__ as __version__  # noqa: F401
