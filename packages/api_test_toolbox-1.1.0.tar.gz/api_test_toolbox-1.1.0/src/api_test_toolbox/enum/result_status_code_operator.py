from enum import Enum


class ResultStatusCodeOperator(Enum):
    Equal = 1
    Not_Equal = 0
