# Aplicacion de Ventas:

Este paquete proporciona funcionalidades para gestionar ventas,
incluyendo calculos de precios, impuestos y descuentos.

## Instalacion

Puedes Instalar el Paquete usando:

´´´´bash
pip install .
"