"""Command-line interface for systematic macro credit research."""

from .main import cli

__all__ = ["cli"]
