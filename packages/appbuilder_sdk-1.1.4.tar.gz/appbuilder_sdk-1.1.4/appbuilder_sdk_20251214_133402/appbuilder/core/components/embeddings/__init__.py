"""
init
"""

from .component import Embedding
from .base import EmbeddingBaseComponent
