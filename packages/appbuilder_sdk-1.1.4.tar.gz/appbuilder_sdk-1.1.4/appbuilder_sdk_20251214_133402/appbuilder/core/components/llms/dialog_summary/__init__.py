"""DialogSummary"""
from .component import DialogSummary