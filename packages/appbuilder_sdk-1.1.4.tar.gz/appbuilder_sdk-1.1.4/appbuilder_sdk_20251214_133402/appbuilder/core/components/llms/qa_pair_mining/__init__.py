
from .component import QAPairMining
