"""query_rewrite"""
from .component import QueryRewrite
