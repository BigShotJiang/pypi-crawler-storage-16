# Test starting (initializing) apphelpers app with different supported configurations


def test_basic():
    import tests.services.basic  # noqa: F401


def test_session():
    import tests.services.session  # noqa: F401
