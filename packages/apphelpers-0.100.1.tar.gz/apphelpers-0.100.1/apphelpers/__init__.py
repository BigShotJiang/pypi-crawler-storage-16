# -*- coding: utf-8 -*-

"""Top-level package for Common helper libraries for Python Apps."""

__author__ = """Scroll Tech"""
__email__ = "engg@stck.me"
__version__ = "0.100.1"
