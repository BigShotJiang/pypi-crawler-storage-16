from typing import TypeVar

T = TypeVar("T")
T1 = TypeVar("T1")
T2 = TypeVar("T2")
T3 = TypeVar("T3")
NT1 = TypeVar("NT1")
NT2 = TypeVar("NT2")
NT3 = TypeVar("NT3")
