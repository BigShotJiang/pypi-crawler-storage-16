APRSD GPS Extension is developed and maintained by the APRSD community.

For a list of contributors, see the `GitHub contributors page <https://github.com/hemna/aprsd-gps-extension/graphs/contributors>`_.
