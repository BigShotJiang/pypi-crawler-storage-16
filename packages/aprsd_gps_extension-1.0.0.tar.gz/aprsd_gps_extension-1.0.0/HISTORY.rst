For a detailed history of changes, see the `ChangeLog <https://github.com/hemna/aprsd-gps-extension/blob/master/ChangeLog.md>`_.
