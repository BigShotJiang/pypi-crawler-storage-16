# This is how we create and register the GPSStats class with the APRSD collector.
from aprsd_gps_extension import stats  # noqa: F401
from aprsd_gps_extension.cmds import show  # noqa: F401
