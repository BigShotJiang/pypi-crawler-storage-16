aprsd\_gps\_extension.conf package
==================================

Submodules
----------

aprsd\_gps\_extension.conf.main module
--------------------------------------

.. automodule:: aprsd_gps_extension.conf.main
   :members:
   :show-inheritance:
   :undoc-members:

aprsd\_gps\_extension.conf.opts module
--------------------------------------

.. automodule:: aprsd_gps_extension.conf.opts
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: aprsd_gps_extension.conf
   :members:
   :show-inheritance:
   :undoc-members:
