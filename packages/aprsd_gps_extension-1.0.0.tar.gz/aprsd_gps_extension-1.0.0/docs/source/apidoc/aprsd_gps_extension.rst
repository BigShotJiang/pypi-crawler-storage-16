aprsd\_gps\_extension package
=============================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   aprsd_gps_extension.cmds
   aprsd_gps_extension.conf
   aprsd_gps_extension.threads

Submodules
----------

aprsd\_gps\_extension.extension module
--------------------------------------

.. automodule:: aprsd_gps_extension.extension
   :members:
   :show-inheritance:
   :undoc-members:

aprsd\_gps\_extension.gps\_processor module
-------------------------------------------

.. automodule:: aprsd_gps_extension.gps_processor
   :members:
   :show-inheritance:
   :undoc-members:

aprsd\_gps\_extension.stats module
----------------------------------

.. automodule:: aprsd_gps_extension.stats
   :members:
   :show-inheritance:
   :undoc-members:

aprsd\_gps\_extension.utils module
----------------------------------

.. automodule:: aprsd_gps_extension.utils
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: aprsd_gps_extension
   :members:
   :show-inheritance:
   :undoc-members:
