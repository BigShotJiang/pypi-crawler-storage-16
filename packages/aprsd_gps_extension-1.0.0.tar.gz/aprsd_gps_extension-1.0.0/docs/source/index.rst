Welcome to APRSD GPS Extension's documentation!
=================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   readme
   installation
   contributing
   authors
   history
   apidoc/modules

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
