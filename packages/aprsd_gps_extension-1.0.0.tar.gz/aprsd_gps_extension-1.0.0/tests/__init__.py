"""Unit test package for aprsd_gps_extension."""
