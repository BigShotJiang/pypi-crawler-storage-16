"""
Test suite for Aptabase Python SDK.
"""
