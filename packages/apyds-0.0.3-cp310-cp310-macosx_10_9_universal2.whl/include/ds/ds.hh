#ifndef DS_HH
#define DS_HH

#include <ds/item.hh>
#include <ds/list.hh>
#include <ds/rule.hh>
#include <ds/string.hh>
#include <ds/term.hh>
#include <ds/variable.hh>

#endif
