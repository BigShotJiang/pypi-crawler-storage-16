# Generated from /home/runner/work/_temp/setup-uv-cache/sdists-v9/.tmpedKOQq/apyds_bnf-0.0.4/Dsp.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,34,132,2,0,7,0,2,1,7,1,2,2,7,2,1,0,5,0,8,8,0,10,0,12,0,11,9,
        0,1,0,1,0,4,0,15,8,0,11,0,12,0,16,1,0,5,0,20,8,0,10,0,12,0,23,9,
        0,3,0,25,8,0,1,0,5,0,28,8,0,10,0,12,0,31,9,0,1,0,1,0,1,1,1,1,1,1,
        1,1,5,1,39,8,1,10,1,12,1,42,9,1,3,1,44,8,1,1,1,1,1,3,1,48,8,1,1,
        2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,3,2,58,8,2,1,2,1,2,1,2,1,2,1,2,1,2,
        1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,
        1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,
        1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,5,2,107,8,2,10,2,12,2,110,9,
        2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,5,2,119,8,2,10,2,12,2,122,9,2,3,2,
        124,8,2,1,2,5,2,127,8,2,10,2,12,2,130,9,2,1,2,0,1,4,3,0,2,4,0,6,
        1,0,9,14,2,0,14,14,16,17,1,0,11,12,1,0,18,19,1,0,20,23,1,0,24,25,
        157,0,9,1,0,0,0,2,47,1,0,0,0,4,57,1,0,0,0,6,8,5,33,0,0,7,6,1,0,0,
        0,8,11,1,0,0,0,9,7,1,0,0,0,9,10,1,0,0,0,10,24,1,0,0,0,11,9,1,0,0,
        0,12,21,3,2,1,0,13,15,5,33,0,0,14,13,1,0,0,0,15,16,1,0,0,0,16,14,
        1,0,0,0,16,17,1,0,0,0,17,18,1,0,0,0,18,20,3,2,1,0,19,14,1,0,0,0,
        20,23,1,0,0,0,21,19,1,0,0,0,21,22,1,0,0,0,22,25,1,0,0,0,23,21,1,
        0,0,0,24,12,1,0,0,0,24,25,1,0,0,0,25,29,1,0,0,0,26,28,5,33,0,0,27,
        26,1,0,0,0,28,31,1,0,0,0,29,27,1,0,0,0,29,30,1,0,0,0,30,32,1,0,0,
        0,31,29,1,0,0,0,32,33,5,0,0,1,33,1,1,0,0,0,34,48,3,4,2,0,35,40,3,
        4,2,0,36,37,5,1,0,0,37,39,3,4,2,0,38,36,1,0,0,0,39,42,1,0,0,0,40,
        38,1,0,0,0,40,41,1,0,0,0,41,44,1,0,0,0,42,40,1,0,0,0,43,35,1,0,0,
        0,43,44,1,0,0,0,44,45,1,0,0,0,45,46,5,2,0,0,46,48,3,4,2,0,47,34,
        1,0,0,0,47,43,1,0,0,0,48,3,1,0,0,0,49,50,6,2,-1,0,50,58,5,34,0,0,
        51,52,5,3,0,0,52,53,3,4,2,0,53,54,5,4,0,0,54,58,1,0,0,0,55,56,7,
        0,0,0,56,58,3,4,2,13,57,49,1,0,0,0,57,51,1,0,0,0,57,55,1,0,0,0,58,
        128,1,0,0,0,59,60,10,17,0,0,60,61,5,5,0,0,61,127,3,4,2,18,62,63,
        10,16,0,0,63,64,5,6,0,0,64,127,3,4,2,17,65,66,10,12,0,0,66,67,5,
        15,0,0,67,127,3,4,2,13,68,69,10,11,0,0,69,70,7,1,0,0,70,127,3,4,
        2,12,71,72,10,10,0,0,72,73,7,2,0,0,73,127,3,4,2,11,74,75,10,9,0,
        0,75,76,7,3,0,0,76,127,3,4,2,10,77,78,10,8,0,0,78,79,7,4,0,0,79,
        127,3,4,2,9,80,81,10,7,0,0,81,82,7,5,0,0,82,127,3,4,2,8,83,84,10,
        6,0,0,84,85,5,13,0,0,85,127,3,4,2,7,86,87,10,5,0,0,87,88,5,26,0,
        0,88,127,3,4,2,6,89,90,10,4,0,0,90,91,5,27,0,0,91,127,3,4,2,5,92,
        93,10,3,0,0,93,94,5,28,0,0,94,127,3,4,2,4,95,96,10,2,0,0,96,97,5,
        29,0,0,97,127,3,4,2,3,98,99,10,1,0,0,99,100,5,30,0,0,100,127,3,4,
        2,2,101,102,10,15,0,0,102,103,5,7,0,0,103,108,3,4,2,0,104,105,5,
        1,0,0,105,107,3,4,2,0,106,104,1,0,0,0,107,110,1,0,0,0,108,106,1,
        0,0,0,108,109,1,0,0,0,109,111,1,0,0,0,110,108,1,0,0,0,111,112,5,
        8,0,0,112,127,1,0,0,0,113,114,10,14,0,0,114,123,5,3,0,0,115,120,
        3,4,2,0,116,117,5,1,0,0,117,119,3,4,2,0,118,116,1,0,0,0,119,122,
        1,0,0,0,120,118,1,0,0,0,120,121,1,0,0,0,121,124,1,0,0,0,122,120,
        1,0,0,0,123,115,1,0,0,0,123,124,1,0,0,0,124,125,1,0,0,0,125,127,
        5,4,0,0,126,59,1,0,0,0,126,62,1,0,0,0,126,65,1,0,0,0,126,68,1,0,
        0,0,126,71,1,0,0,0,126,74,1,0,0,0,126,77,1,0,0,0,126,80,1,0,0,0,
        126,83,1,0,0,0,126,86,1,0,0,0,126,89,1,0,0,0,126,92,1,0,0,0,126,
        95,1,0,0,0,126,98,1,0,0,0,126,101,1,0,0,0,126,113,1,0,0,0,127,130,
        1,0,0,0,128,126,1,0,0,0,128,129,1,0,0,0,129,5,1,0,0,0,130,128,1,
        0,0,0,14,9,16,21,24,29,40,43,47,57,108,120,123,126,128
    ]

class DspParser ( Parser ):

    grammarFileName = "Dsp.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "','", "'->'", "'('", "')'", "'::'", "'.'", 
                     "'['", "']'", "'~'", "'!'", "'-'", "'+'", "'&'", "'*'", 
                     "'.*'", "'/'", "'%'", "'<<'", "'>>'", "'<'", "'>'", 
                     "'<='", "'>='", "'=='", "'!='", "'^'", "'|'", "'&&'", 
                     "'||'", "'='" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "WHITESPACE", 
                      "COMMENT", "NEWLINE", "SYMBOL" ]

    RULE_rule_pool = 0
    RULE_rule = 1
    RULE_term = 2

    ruleNames =  [ "rule_pool", "rule", "term" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    T__17=18
    T__18=19
    T__19=20
    T__20=21
    T__21=22
    T__22=23
    T__23=24
    T__24=25
    T__25=26
    T__26=27
    T__27=28
    T__28=29
    T__29=30
    WHITESPACE=31
    COMMENT=32
    NEWLINE=33
    SYMBOL=34

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class Rule_poolContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(DspParser.EOF, 0)

        def NEWLINE(self, i:int=None):
            if i is None:
                return self.getTokens(DspParser.NEWLINE)
            else:
                return self.getToken(DspParser.NEWLINE, i)

        def rule_(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(DspParser.RuleContext)
            else:
                return self.getTypedRuleContext(DspParser.RuleContext,i)


        def getRuleIndex(self):
            return DspParser.RULE_rule_pool

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRule_pool" ):
                return visitor.visitRule_pool(self)
            else:
                return visitor.visitChildren(self)




    def rule_pool(self):

        localctx = DspParser.Rule_poolContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_rule_pool)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 9
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,0,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 6
                    self.match(DspParser.NEWLINE) 
                self.state = 11
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,0,self._ctx)

            self.state = 24
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 17179901452) != 0):
                self.state = 12
                self.rule_()
                self.state = 21
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,2,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 14 
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)
                        while True:
                            self.state = 13
                            self.match(DspParser.NEWLINE)
                            self.state = 16 
                            self._errHandler.sync(self)
                            _la = self._input.LA(1)
                            if not (_la==33):
                                break

                        self.state = 18
                        self.rule_() 
                    self.state = 23
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,2,self._ctx)



            self.state = 29
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==33:
                self.state = 26
                self.match(DspParser.NEWLINE)
                self.state = 31
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 32
            self.match(DspParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RuleContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def term(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(DspParser.TermContext)
            else:
                return self.getTypedRuleContext(DspParser.TermContext,i)


        def getRuleIndex(self):
            return DspParser.RULE_rule

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRule" ):
                return visitor.visitRule(self)
            else:
                return visitor.visitChildren(self)




    def rule_(self):

        localctx = DspParser.RuleContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_rule)
        self._la = 0 # Token type
        try:
            self.state = 47
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,7,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 34
                self.term(0)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 43
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & 17179901448) != 0):
                    self.state = 35
                    self.term(0)
                    self.state = 40
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while _la==1:
                        self.state = 36
                        self.match(DspParser.T__0)
                        self.state = 37
                        self.term(0)
                        self.state = 42
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)



                self.state = 45
                self.match(DspParser.T__1)
                self.state = 46
                self.term(0)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TermContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return DspParser.RULE_term

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class SymbolContext(TermContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a DspParser.TermContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def SYMBOL(self):
            return self.getToken(DspParser.SYMBOL, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSymbol" ):
                return visitor.visitSymbol(self)
            else:
                return visitor.visitChildren(self)


    class ParenthesesContext(TermContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a DspParser.TermContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def term(self):
            return self.getTypedRuleContext(DspParser.TermContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParentheses" ):
                return visitor.visitParentheses(self)
            else:
                return visitor.visitChildren(self)


    class SubscriptContext(TermContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a DspParser.TermContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def term(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(DspParser.TermContext)
            else:
                return self.getTypedRuleContext(DspParser.TermContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSubscript" ):
                return visitor.visitSubscript(self)
            else:
                return visitor.visitChildren(self)


    class BinaryContext(TermContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a DspParser.TermContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def term(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(DspParser.TermContext)
            else:
                return self.getTypedRuleContext(DspParser.TermContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBinary" ):
                return visitor.visitBinary(self)
            else:
                return visitor.visitChildren(self)


    class FunctionContext(TermContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a DspParser.TermContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def term(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(DspParser.TermContext)
            else:
                return self.getTypedRuleContext(DspParser.TermContext,i)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFunction" ):
                return visitor.visitFunction(self)
            else:
                return visitor.visitChildren(self)


    class UnaryContext(TermContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a DspParser.TermContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def term(self):
            return self.getTypedRuleContext(DspParser.TermContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnary" ):
                return visitor.visitUnary(self)
            else:
                return visitor.visitChildren(self)



    def term(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = DspParser.TermContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 4
        self.enterRecursionRule(localctx, 4, self.RULE_term, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 57
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [34]:
                localctx = DspParser.SymbolContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 50
                self.match(DspParser.SYMBOL)
                pass
            elif token in [3]:
                localctx = DspParser.ParenthesesContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 51
                self.match(DspParser.T__2)
                self.state = 52
                self.term(0)
                self.state = 53
                self.match(DspParser.T__3)
                pass
            elif token in [9, 10, 11, 12, 13, 14]:
                localctx = DspParser.UnaryContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 55
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 32256) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 56
                self.term(13)
                pass
            else:
                raise NoViableAltException(self)

            self._ctx.stop = self._input.LT(-1)
            self.state = 128
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,13,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 126
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,12,self._ctx)
                    if la_ == 1:
                        localctx = DspParser.BinaryContext(self, DspParser.TermContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_term)
                        self.state = 59
                        if not self.precpred(self._ctx, 17):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 17)")
                        self.state = 60
                        self.match(DspParser.T__4)
                        self.state = 61
                        self.term(18)
                        pass

                    elif la_ == 2:
                        localctx = DspParser.BinaryContext(self, DspParser.TermContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_term)
                        self.state = 62
                        if not self.precpred(self._ctx, 16):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 16)")
                        self.state = 63
                        self.match(DspParser.T__5)
                        self.state = 64
                        self.term(17)
                        pass

                    elif la_ == 3:
                        localctx = DspParser.BinaryContext(self, DspParser.TermContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_term)
                        self.state = 65
                        if not self.precpred(self._ctx, 12):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 12)")
                        self.state = 66
                        self.match(DspParser.T__14)
                        self.state = 67
                        self.term(13)
                        pass

                    elif la_ == 4:
                        localctx = DspParser.BinaryContext(self, DspParser.TermContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_term)
                        self.state = 68
                        if not self.precpred(self._ctx, 11):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 11)")
                        self.state = 69
                        _la = self._input.LA(1)
                        if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 212992) != 0)):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 70
                        self.term(12)
                        pass

                    elif la_ == 5:
                        localctx = DspParser.BinaryContext(self, DspParser.TermContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_term)
                        self.state = 71
                        if not self.precpred(self._ctx, 10):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 10)")
                        self.state = 72
                        _la = self._input.LA(1)
                        if not(_la==11 or _la==12):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 73
                        self.term(11)
                        pass

                    elif la_ == 6:
                        localctx = DspParser.BinaryContext(self, DspParser.TermContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_term)
                        self.state = 74
                        if not self.precpred(self._ctx, 9):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 9)")
                        self.state = 75
                        _la = self._input.LA(1)
                        if not(_la==18 or _la==19):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 76
                        self.term(10)
                        pass

                    elif la_ == 7:
                        localctx = DspParser.BinaryContext(self, DspParser.TermContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_term)
                        self.state = 77
                        if not self.precpred(self._ctx, 8):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 8)")
                        self.state = 78
                        _la = self._input.LA(1)
                        if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 15728640) != 0)):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 79
                        self.term(9)
                        pass

                    elif la_ == 8:
                        localctx = DspParser.BinaryContext(self, DspParser.TermContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_term)
                        self.state = 80
                        if not self.precpred(self._ctx, 7):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 7)")
                        self.state = 81
                        _la = self._input.LA(1)
                        if not(_la==24 or _la==25):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 82
                        self.term(8)
                        pass

                    elif la_ == 9:
                        localctx = DspParser.BinaryContext(self, DspParser.TermContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_term)
                        self.state = 83
                        if not self.precpred(self._ctx, 6):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 6)")
                        self.state = 84
                        self.match(DspParser.T__12)
                        self.state = 85
                        self.term(7)
                        pass

                    elif la_ == 10:
                        localctx = DspParser.BinaryContext(self, DspParser.TermContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_term)
                        self.state = 86
                        if not self.precpred(self._ctx, 5):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 5)")
                        self.state = 87
                        self.match(DspParser.T__25)
                        self.state = 88
                        self.term(6)
                        pass

                    elif la_ == 11:
                        localctx = DspParser.BinaryContext(self, DspParser.TermContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_term)
                        self.state = 89
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 90
                        self.match(DspParser.T__26)
                        self.state = 91
                        self.term(5)
                        pass

                    elif la_ == 12:
                        localctx = DspParser.BinaryContext(self, DspParser.TermContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_term)
                        self.state = 92
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 93
                        self.match(DspParser.T__27)
                        self.state = 94
                        self.term(4)
                        pass

                    elif la_ == 13:
                        localctx = DspParser.BinaryContext(self, DspParser.TermContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_term)
                        self.state = 95
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 96
                        self.match(DspParser.T__28)
                        self.state = 97
                        self.term(3)
                        pass

                    elif la_ == 14:
                        localctx = DspParser.BinaryContext(self, DspParser.TermContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_term)
                        self.state = 98
                        if not self.precpred(self._ctx, 1):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 1)")
                        self.state = 99
                        self.match(DspParser.T__29)
                        self.state = 100
                        self.term(2)
                        pass

                    elif la_ == 15:
                        localctx = DspParser.SubscriptContext(self, DspParser.TermContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_term)
                        self.state = 101
                        if not self.precpred(self._ctx, 15):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 15)")
                        self.state = 102
                        self.match(DspParser.T__6)
                        self.state = 103
                        self.term(0)
                        self.state = 108
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)
                        while _la==1:
                            self.state = 104
                            self.match(DspParser.T__0)
                            self.state = 105
                            self.term(0)
                            self.state = 110
                            self._errHandler.sync(self)
                            _la = self._input.LA(1)

                        self.state = 111
                        self.match(DspParser.T__7)
                        pass

                    elif la_ == 16:
                        localctx = DspParser.FunctionContext(self, DspParser.TermContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_term)
                        self.state = 113
                        if not self.precpred(self._ctx, 14):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 14)")
                        self.state = 114
                        self.match(DspParser.T__2)
                        self.state = 123
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)
                        if (((_la) & ~0x3f) == 0 and ((1 << _la) & 17179901448) != 0):
                            self.state = 115
                            self.term(0)
                            self.state = 120
                            self._errHandler.sync(self)
                            _la = self._input.LA(1)
                            while _la==1:
                                self.state = 116
                                self.match(DspParser.T__0)
                                self.state = 117
                                self.term(0)
                                self.state = 122
                                self._errHandler.sync(self)
                                _la = self._input.LA(1)



                        self.state = 125
                        self.match(DspParser.T__3)
                        pass

             
                self.state = 130
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,13,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[2] = self.term_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def term_sempred(self, localctx:TermContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 17)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 16)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 12)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 11)
         

            if predIndex == 4:
                return self.precpred(self._ctx, 10)
         

            if predIndex == 5:
                return self.precpred(self._ctx, 9)
         

            if predIndex == 6:
                return self.precpred(self._ctx, 8)
         

            if predIndex == 7:
                return self.precpred(self._ctx, 7)
         

            if predIndex == 8:
                return self.precpred(self._ctx, 6)
         

            if predIndex == 9:
                return self.precpred(self._ctx, 5)
         

            if predIndex == 10:
                return self.precpred(self._ctx, 4)
         

            if predIndex == 11:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 12:
                return self.precpred(self._ctx, 2)
         

            if predIndex == 13:
                return self.precpred(self._ctx, 1)
         

            if predIndex == 14:
                return self.precpred(self._ctx, 15)
         

            if predIndex == 15:
                return self.precpred(self._ctx, 14)
         




