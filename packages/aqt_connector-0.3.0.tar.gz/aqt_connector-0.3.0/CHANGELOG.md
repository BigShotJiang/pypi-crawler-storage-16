# Changelog

## unreleased

## aqt-connector 0.3.0
* Increase circuit qubit limit to <=31 #11

## aqt-connector 0.2.0
* Add fetch job state #8
* Add Arnica API schemas and update the models #4

## aqt-connector 0.1.0
* Add license and changelog. Update pyproject.toml #3
* Move py.typed to correct location in package directory #1 
* Initial version