from aqt_connector._application.cli import app

if __name__ == "__main__":
    app()
