"""ARNICA API request body models."""
