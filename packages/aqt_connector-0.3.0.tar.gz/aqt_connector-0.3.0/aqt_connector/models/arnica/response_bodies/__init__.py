"""ARNICA API response body models."""
