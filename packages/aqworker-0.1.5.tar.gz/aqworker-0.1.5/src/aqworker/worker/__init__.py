from aqworker.worker.base import WorkerConfig

__all__ = ["WorkerConfig"]
