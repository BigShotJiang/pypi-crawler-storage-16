### INTENTION and CONTEXT
When I run my application {name or reference to app} implemented in {application script name}My 
then the following error occurs

```
{error cli output | logged information}
```


