
### INTENTION and CONTEXT
My intention is to write the steps for the `{name_of_the_scenario}` scenario of the `{feature_file_name.feature}` feature in the `{name_of_the_steps_file}` file. Use the implementation in the `{name_of_the_soud}` file.

