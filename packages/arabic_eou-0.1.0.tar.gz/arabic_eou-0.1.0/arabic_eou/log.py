import logging

logger = logging.getLogger("arabic_eou")

