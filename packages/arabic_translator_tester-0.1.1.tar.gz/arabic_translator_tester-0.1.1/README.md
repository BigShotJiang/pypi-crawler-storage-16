# Arabic Translator Tester

[![PyPI version](https://badge.fury.io/py/arabic-translator-tester.svg)](https://badge.fury.io/py/arabic-translator-tester)
[![Tests](https://github.com/Taha1501/arabic_translator_tester/actions/workflows/tests.yml/badge.svg)](https://github.com/Taha1501/arabic_translator_tester/actions)

Tests Arabic input by translating to English using [Argos Translate](https://github.com/argosopentech/argos-translate). Validates translation success for Arabic text validation workflows.

## 🚀 Quick Start

