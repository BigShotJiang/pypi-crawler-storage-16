"""API response types for component, style, and component set endpoints."""

from typing_extensions import TypedDict

from arcade_figma.models.api_responses.common import CursorPaginationResponse


class FrameInfoResponse(TypedDict, total=False):
    """Frame info in component/style response."""

    node_id: str
    name: str
    page_id: str
    page_name: str


class UserInfoResponse(TypedDict, total=False):
    """User info in component/style response."""

    id: str
    handle: str
    img_url: str


class ComponentMetaResponse(TypedDict, total=False):
    """Component metadata in components response."""

    key: str
    file_key: str
    node_id: str
    thumbnail_url: str
    name: str
    description: str
    created_at: str
    updated_at: str
    user: UserInfoResponse
    containing_frame: FrameInfoResponse


class ComponentsMetaResponse(TypedDict, total=False):
    """Meta object containing components list and cursor."""

    components: list[ComponentMetaResponse]
    cursor: CursorPaginationResponse


class FileComponentsResponse(TypedDict, total=False):
    """Response from GET /v1/files/:key/components."""

    error: bool
    status: int
    meta: ComponentsMetaResponse


class TeamComponentsResponse(TypedDict, total=False):
    """Response from GET /v1/teams/:id/components."""

    error: bool
    status: int
    meta: ComponentsMetaResponse


class SingleComponentResponse(TypedDict, total=False):
    """Response from GET /v1/components/:key."""

    error: bool
    status: int
    meta: ComponentMetaResponse


class StyleMetaResponse(TypedDict, total=False):
    """Style metadata in styles response."""

    key: str
    file_key: str
    node_id: str
    style_type: str
    thumbnail_url: str
    name: str
    description: str
    created_at: str
    updated_at: str
    sort_position: str
    user: UserInfoResponse


class StylesMetaResponse(TypedDict, total=False):
    """Meta object containing styles list and cursor."""

    styles: list[StyleMetaResponse]
    cursor: CursorPaginationResponse


class FileStylesResponse(TypedDict, total=False):
    """Response from GET /v1/files/:key/styles."""

    error: bool
    status: int
    meta: StylesMetaResponse


class TeamStylesResponse(TypedDict, total=False):
    """Response from GET /v1/teams/:id/styles."""

    error: bool
    status: int
    meta: StylesMetaResponse


class SingleStyleResponse(TypedDict, total=False):
    """Response from GET /v1/styles/:key."""

    error: bool
    status: int
    meta: StyleMetaResponse


class ComponentSetMetaResponse(TypedDict, total=False):
    """Component set metadata in component sets response."""

    key: str
    file_key: str
    node_id: str
    thumbnail_url: str
    name: str
    description: str
    created_at: str
    updated_at: str
    user: UserInfoResponse
    containing_frame: FrameInfoResponse


class ComponentSetsMetaResponse(TypedDict, total=False):
    """Meta object containing component sets list and cursor."""

    component_sets: list[ComponentSetMetaResponse]
    cursor: CursorPaginationResponse


class FileComponentSetsResponse(TypedDict, total=False):
    """Response from GET /v1/files/:key/component_sets."""

    error: bool
    status: int
    meta: ComponentSetsMetaResponse


class TeamComponentSetsResponse(TypedDict, total=False):
    """Response from GET /v1/teams/:id/component_sets."""

    error: bool
    status: int
    meta: ComponentSetsMetaResponse


class SingleComponentSetResponse(TypedDict, total=False):
    """Response from GET /v1/component_sets/:key."""

    error: bool
    status: int
    meta: ComponentSetMetaResponse
