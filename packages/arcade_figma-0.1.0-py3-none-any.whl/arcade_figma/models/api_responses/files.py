"""API response types for file endpoints."""

from typing import Any

from typing_extensions import TypedDict


class NodeResponse(TypedDict, total=False):
    """Node in file structure."""

    id: str
    name: str
    type: str
    children: list["NodeResponse"]


class DocumentResponse(TypedDict, total=False):
    """Document (root) node."""

    id: str
    name: str
    type: str
    children: list[NodeResponse]


class FileMetaResponse(TypedDict, total=False):
    """Response from GET /v1/files/:key."""

    name: str
    lastModified: str
    thumbnailUrl: str
    version: str
    editorType: str
    linkAccess: str
    role: str
    document: DocumentResponse
    components: dict[str, Any]
    styles: dict[str, Any]


class NodeDataResponse(TypedDict, total=False):
    """Individual node data in file nodes response."""

    document: NodeResponse
    components: dict[str, Any]
    styles: dict[str, Any]


class FileNodesResponse(TypedDict, total=False):
    """Response from GET /v1/files/:key/nodes."""

    name: str
    lastModified: str
    thumbnailUrl: str
    version: str
    nodes: dict[str, NodeDataResponse]


class ExportImageResponse(TypedDict, total=False):
    """Response from GET /v1/images/:key."""

    err: str | None
    images: dict[str, str]
