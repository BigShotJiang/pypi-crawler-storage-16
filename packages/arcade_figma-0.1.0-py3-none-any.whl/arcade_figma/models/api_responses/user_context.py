"""API response types for user context endpoints."""

from typing_extensions import TypedDict


class TeamResponse(TypedDict, total=False):
    """Team in /me response."""

    id: str
    name: str


class MeResponse(TypedDict, total=False):
    """Response from GET /v1/me."""

    id: str
    handle: str
    email: str
    img_url: str
    teams: list[TeamResponse]
