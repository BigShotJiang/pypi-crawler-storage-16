"""Tool output types for comment tools."""

from typing_extensions import TypedDict


class CommentAuthor(TypedDict, total=False):
    """Comment author information."""

    id: str
    """Author's user ID."""

    handle: str
    """Author's handle."""

    img_url: str | None
    """Author's avatar URL."""


class CommentPosition(TypedDict, total=False):
    """Comment position on canvas."""

    x: float
    """X coordinate."""

    y: float
    """Y coordinate."""

    node_id: str | None
    """Node the comment is attached to."""


class CommentSummary(TypedDict, total=False):
    """Comment summary."""

    id: str
    """Comment ID."""

    message: str
    """Comment message text."""

    author: CommentAuthor
    """Comment author."""

    created_at: str
    """ISO 8601 timestamp when comment was created."""

    resolved_at: str | None
    """ISO 8601 timestamp when comment was resolved, if resolved."""

    parent_id: str | None
    """Parent comment ID if this is a reply."""

    position: CommentPosition | None
    """Position on canvas."""


class GetCommentsOutput(TypedDict, total=False):
    """Output for get_comments tool."""

    file_key: str
    """File's unique key."""

    comments: list[CommentSummary]
    """List of comments in the current page."""

    items_returned: int
    """Number of comments returned in this response."""

    total_count: int
    """Total number of comments on the file."""

    offset: int
    """Starting offset for pagination."""

    is_last: bool
    """Whether this is the last page of results."""


class AddCommentOutput(TypedDict, total=False):
    """Output for add_comment_or_reply tool."""

    id: str
    """Created comment ID."""

    message: str
    """Comment message."""

    author: CommentAuthor
    """Comment author (authenticated user)."""

    created_at: str
    """ISO 8601 timestamp when comment was created."""

    parent_id: str | None
    """Parent comment ID if this is a reply."""
