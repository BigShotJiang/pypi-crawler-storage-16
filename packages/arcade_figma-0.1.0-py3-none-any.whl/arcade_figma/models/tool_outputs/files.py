"""Tool output types for file tools."""

from typing_extensions import TypedDict


class PageSummary(TypedDict, total=False):
    """Page summary in file."""

    id: str
    """Page node ID."""

    name: str
    """Page name."""

    url: str | None
    """URL to open page in Figma."""


class FrameSummary(TypedDict, total=False):
    """Frame summary in page."""

    id: str
    """Frame node ID."""

    name: str
    """Frame name."""

    type: str
    """Node type (FRAME, COMPONENT, etc.)."""

    url: str | None
    """URL to open frame in Figma."""


class GetFileOutput(TypedDict, total=False):
    """Output for get_file tool."""

    file_key: str
    """File's unique key."""

    name: str
    """File name."""

    url: str
    """URL to open file in Figma."""

    last_modified: str
    """ISO 8601 timestamp of last modification."""

    thumbnail_url: str | None
    """File thumbnail URL."""

    version: str
    """File version."""

    editor_type: str | None
    """Editor type: figma, figjam, or slides."""

    role: str | None
    """User's role on the file: owner, editor, viewer."""

    pages: list[PageSummary]
    """List of pages in the file."""

    total_pages: int
    """Total number of pages."""


class GetPagesOutput(TypedDict, total=False):
    """Output for get_pages tool."""

    file_key: str
    """File's unique key."""

    file_name: str
    """File name."""

    file_url: str
    """URL to open file in Figma."""

    pages: list[PageSummary]
    """List of pages with their frames."""

    total_count: int
    """Total number of pages."""


class ChildNodeData(TypedDict, total=False):
    """Data for a child node (no further nesting)."""

    id: str
    """Node ID."""

    name: str
    """Node name."""

    type: str
    """Node type (FRAME, COMPONENT, TEXT, etc.)."""

    url: str | None
    """URL to open node in Figma."""


class NodeData(TypedDict, total=False):
    """Data for a specific node."""

    id: str
    """Node ID."""

    name: str
    """Node name."""

    type: str
    """Node type (FRAME, COMPONENT, TEXT, etc.)."""

    url: str | None
    """URL to open node in Figma."""

    children: list[ChildNodeData] | None
    """Immediate child nodes (one level deep)."""


class GetFileNodesOutput(TypedDict, total=False):
    """Output for get_file_nodes tool."""

    file_key: str
    """File's unique key."""

    file_name: str
    """File name."""

    file_url: str
    """URL to open file in Figma."""

    editor_type: str | None
    """Editor type: figma, figjam, or slides."""

    role: str | None
    """User's role on the file."""

    nodes: list[NodeData]
    """List of requested nodes with their data."""

    total_count: int
    """Total number of nodes returned."""


class ExportedImage(TypedDict, total=False):
    """Exported image information."""

    node_id: str
    """Node ID that was exported."""

    url: str
    """Temporary URL to download the image (valid ~14 days)."""


class ExportImageOutput(TypedDict, total=False):
    """Output for export_image tool."""

    file_key: str
    """File's unique key."""

    format: str
    """Export format (png, svg, pdf, jpg)."""

    scale: float
    """Export scale."""

    images: list[ExportedImage]
    """List of exported images with their URLs."""

    total_count: int
    """Total number of images exported."""
