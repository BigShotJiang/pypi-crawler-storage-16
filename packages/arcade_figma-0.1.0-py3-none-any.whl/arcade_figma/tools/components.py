"""Component, style, and component set tools for Figma toolkit."""

from typing import Annotated, cast

from arcade_tdk import ToolContext, tool
from arcade_tdk.auth import Figma
from arcade_tdk.errors import FatalToolError

from arcade_figma.client import FigmaClient
from arcade_figma.models.enums import LibrarySource
from arcade_figma.models.tool_outputs import (
    GetComponentOutput,
    GetComponentSetOutput,
    GetComponentSetsOutput,
    GetComponentsOutput,
    GetStyleOutput,
    GetStylesOutput,
)
from arcade_figma.utils import component_utils
from arcade_figma.utils.response_utils import remove_none_values_recursive


# =============================================================================
# get_components
# API Calls: 1
# APIs Used: GET /v1/files/:key/components OR GET /v1/teams/:id/components (REST)
# Response Complexity: MEDIUM - list of components with pagination for team
# -----------------------------------------------------------------------------
# ToolAnnotations:
#   title: "Get Components"
#   readOnlyHint: true       - Only reads component data
#   openWorldHint: true      - Interacts with Figma's external API
# -----------------------------------------------------------------------------
# NOTE: File mode requires library_content:read scope.
#       Team mode requires team_library_content:read scope.
# =============================================================================
@tool(requires_auth=Figma(scopes=["library_content:read", "team_library_content:read"]))
async def get_components(
    context: ToolContext,
    source: Annotated[
        LibrarySource,
        "Source type: 'file' for a specific file, 'team' for team library.",
    ],
    source_id: Annotated[
        str,
        "File key (if source='file') or team ID (if source='team').",
    ],
    page_size: Annotated[
        int,
        "Number of items per page (team mode only, 1-50). Default is 10.",
    ] = 10,
    after_cursor: Annotated[
        int | None,
        "Cursor for next page (team mode only). Default is None.",
    ] = None,
) -> Annotated[GetComponentsOutput, "Published components from file or team library"]:
    """Get published components from a file or team library.

    For file: Returns all published components in the file.
    For team: Returns paginated list of components across team library.
    """
    async with FigmaClient(context.get_auth_token_or_empty()) as client:
        if source == LibrarySource.FILE:
            data = await client.get_file_components(source_id)
        else:
            effective_page_size = min(max(1, page_size), 50)
            data = await client.get_team_components(
                source_id, page_size=effective_page_size, after=after_cursor
            )

    meta = data.get("meta", {})
    components_raw = meta.get("components", [])
    mapped = [component_utils.map_component(c) for c in components_raw if c]

    cursor = None
    if source == LibrarySource.TEAM:
        cursor = component_utils.map_cursor(meta.get("cursor"))

    result: GetComponentsOutput = {
        "source_type": source.value,
        "source_id": source_id,
        "components": mapped,
        "total_count": len(mapped),
        "cursor": cursor,
    }

    return cast(GetComponentsOutput, remove_none_values_recursive(result))


# =============================================================================
# get_component
# API Calls: 1
# APIs Used: GET /v1/components/:key (REST)
# Response Complexity: LOW - single component
# -----------------------------------------------------------------------------
# ToolAnnotations:
#   title: "Get Component"
#   readOnlyHint: true       - Only reads component data
#   openWorldHint: true      - Interacts with Figma's external API
# -----------------------------------------------------------------------------
# NOTE: Requires library_assets:read scope.
# =============================================================================
@tool(requires_auth=Figma(scopes=["library_assets:read"]))
async def get_component(
    context: ToolContext,
    component_key: Annotated[str, "The unique component key."],
) -> Annotated[GetComponentOutput, "Component metadata"]:
    """Get metadata for a specific component by its key."""
    async with FigmaClient(context.get_auth_token_or_empty()) as client:
        data = await client.get_component(component_key)

    meta = data.get("meta", {})
    if not meta:
        raise FatalToolError(f"Component not found: {component_key}")

    result = component_utils.map_component(meta)
    return cast(GetComponentOutput, remove_none_values_recursive(result))


# =============================================================================
# get_styles
# API Calls: 1
# APIs Used: GET /v1/files/:key/styles OR GET /v1/teams/:id/styles (REST)
# Response Complexity: MEDIUM - list of styles with pagination for team
# -----------------------------------------------------------------------------
# ToolAnnotations:
#   title: "Get Styles"
#   readOnlyHint: true       - Only reads style data
#   openWorldHint: true      - Interacts with Figma's external API
# -----------------------------------------------------------------------------
# NOTE: File mode requires library_content:read scope.
#       Team mode requires team_library_content:read scope.
# =============================================================================
@tool(requires_auth=Figma(scopes=["library_content:read", "team_library_content:read"]))
async def get_styles(
    context: ToolContext,
    source: Annotated[
        LibrarySource,
        "Source type: 'file' for a specific file, 'team' for team library.",
    ],
    source_id: Annotated[
        str,
        "File key (if source='file') or team ID (if source='team').",
    ],
    page_size: Annotated[
        int,
        "Number of items per page (team mode only, 1-50). Default is 10.",
    ] = 10,
    after_cursor: Annotated[
        int | None,
        "Cursor for next page (team mode only). Default is None.",
    ] = None,
) -> Annotated[GetStylesOutput, "Published styles from file or team library"]:
    """Get published styles from a file or team library.

    For file: Returns all published styles in the file.
    For team: Returns paginated list of styles across team library.
    """
    async with FigmaClient(context.get_auth_token_or_empty()) as client:
        if source == LibrarySource.FILE:
            data = await client.get_file_styles(source_id)
        else:
            effective_page_size = min(max(1, page_size), 50)
            data = await client.get_team_styles(
                source_id, page_size=effective_page_size, after=after_cursor
            )

    meta = data.get("meta", {})
    styles_raw = meta.get("styles", [])
    mapped = [component_utils.map_style(s) for s in styles_raw if s]

    cursor = None
    if source == LibrarySource.TEAM:
        cursor = component_utils.map_cursor(meta.get("cursor"))

    result: GetStylesOutput = {
        "source_type": source.value,
        "source_id": source_id,
        "styles": mapped,
        "total_count": len(mapped),
        "cursor": cursor,
    }

    return cast(GetStylesOutput, remove_none_values_recursive(result))


# =============================================================================
# get_style
# API Calls: 1
# APIs Used: GET /v1/styles/:key (REST)
# Response Complexity: LOW - single style
# -----------------------------------------------------------------------------
# ToolAnnotations:
#   title: "Get Style"
#   readOnlyHint: true       - Only reads style data
#   openWorldHint: true      - Interacts with Figma's external API
# -----------------------------------------------------------------------------
# NOTE: Requires library_assets:read scope.
# =============================================================================
@tool(requires_auth=Figma(scopes=["library_assets:read"]))
async def get_style(
    context: ToolContext,
    style_key: Annotated[str, "The unique style key."],
) -> Annotated[GetStyleOutput, "Style metadata"]:
    """Get metadata for a specific style by its key."""
    async with FigmaClient(context.get_auth_token_or_empty()) as client:
        data = await client.get_style(style_key)

    meta = data.get("meta", {})
    if not meta:
        raise FatalToolError(f"Style not found: {style_key}")

    result = component_utils.map_style(meta)
    return cast(GetStyleOutput, remove_none_values_recursive(result))


# =============================================================================
# get_component_sets
# API Calls: 1
# APIs Used: GET /v1/files/:key/component_sets OR GET /v1/teams/:id/component_sets
# Response Complexity: MEDIUM - list of component sets with pagination for team
# -----------------------------------------------------------------------------
# ToolAnnotations:
#   title: "Get Component Sets"
#   readOnlyHint: true       - Only reads component set data
#   openWorldHint: true      - Interacts with Figma's external API
# -----------------------------------------------------------------------------
# NOTE: File mode requires library_content:read scope.
#       Team mode requires team_library_content:read scope.
# =============================================================================
@tool(requires_auth=Figma(scopes=["library_content:read", "team_library_content:read"]))
async def get_component_sets(
    context: ToolContext,
    source: Annotated[
        LibrarySource,
        "Source type: 'file' for a specific file, 'team' for team library.",
    ],
    source_id: Annotated[
        str,
        "File key (if source='file') or team ID (if source='team').",
    ],
    page_size: Annotated[
        int,
        "Number of items per page (team mode only, 1-50). Default is 10.",
    ] = 10,
    after_cursor: Annotated[
        int | None,
        "Cursor for next page (team mode only). Default is None.",
    ] = None,
) -> Annotated[GetComponentSetsOutput, "Published component sets from file or team library"]:
    """Get published component sets (groups of component variants) from a file or team library.

    Component sets are groups of related component variants, like a Button
    with states: default, hover, pressed, disabled.

    For file: Returns all published component sets in the file.
    For team: Returns paginated list of component sets across team library.
    """
    async with FigmaClient(context.get_auth_token_or_empty()) as client:
        if source == LibrarySource.FILE:
            data = await client.get_file_component_sets(source_id)
        else:
            effective_page_size = min(max(1, page_size), 50)
            data = await client.get_team_component_sets(
                source_id, page_size=effective_page_size, after=after_cursor
            )

    meta = data.get("meta", {})
    component_sets_raw = meta.get("component_sets", [])
    mapped = [component_utils.map_component_set(cs) for cs in component_sets_raw if cs]

    cursor = None
    if source == LibrarySource.TEAM:
        cursor = component_utils.map_cursor(meta.get("cursor"))

    result: GetComponentSetsOutput = {
        "source_type": source.value,
        "source_id": source_id,
        "component_sets": mapped,
        "total_count": len(mapped),
        "cursor": cursor,
    }

    return cast(GetComponentSetsOutput, remove_none_values_recursive(result))


# =============================================================================
# get_component_set
# API Calls: 1
# APIs Used: GET /v1/component_sets/:key (REST)
# Response Complexity: LOW - single component set
# -----------------------------------------------------------------------------
# ToolAnnotations:
#   title: "Get Component Set"
#   readOnlyHint: true       - Only reads component set data
#   openWorldHint: true      - Interacts with Figma's external API
# -----------------------------------------------------------------------------
# NOTE: Requires library_assets:read scope.
# =============================================================================
@tool(requires_auth=Figma(scopes=["library_assets:read"]))
async def get_component_set(
    context: ToolContext,
    component_set_key: Annotated[str, "The unique component set key."],
) -> Annotated[GetComponentSetOutput, "Component set metadata"]:
    """Get metadata for a specific component set by its key.

    A component set is a group of related component variants.
    """
    async with FigmaClient(context.get_auth_token_or_empty()) as client:
        data = await client.get_component_set(component_set_key)

    meta = data.get("meta", {})
    if not meta:
        raise FatalToolError(f"Component set not found: {component_set_key}")

    result = component_utils.map_component_set(meta)
    return cast(GetComponentSetOutput, remove_none_values_recursive(result))
