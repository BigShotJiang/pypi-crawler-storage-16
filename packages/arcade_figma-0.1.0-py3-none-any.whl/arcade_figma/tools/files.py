"""File access tools for Figma toolkit."""

from typing import Annotated, cast

from arcade_tdk import ToolContext, tool
from arcade_tdk.auth import Figma
from arcade_tdk.errors import FatalToolError

from arcade_figma.client import FigmaClient
from arcade_figma.constants import MAX_IMAGE_SCALE, MIN_IMAGE_SCALE
from arcade_figma.models.enums import ImageFormat
from arcade_figma.models.mappers import (
    map_export_image,
    map_get_file,
    map_get_file_nodes,
    map_get_pages,
)
from arcade_figma.models.tool_outputs import (
    ExportImageOutput,
    GetFileNodesOutput,
    GetFileOutput,
    GetPagesOutput,
)
from arcade_figma.utils.response_utils import remove_none_values_recursive


# =============================================================================
# get_file
# API Calls: 1
# APIs Used: GET /v1/files/:key (REST)
# Response Complexity: MEDIUM - file structure with pages
# -----------------------------------------------------------------------------
# ToolAnnotations:
#   title: "Get File"
#   readOnlyHint: true       - Only reads file data
#   openWorldHint: true      - Interacts with Figma's external API
# =============================================================================
@tool(requires_auth=Figma(scopes=["file_content:read"]))
async def get_file(
    context: ToolContext,
    file_key: Annotated[
        str,
        "File key. Can be found in Figma URL: https://www.figma.com/file/{FILE_KEY}/...",
    ],
    depth: Annotated[
        int | None,
        "How deep to traverse the node tree. Default traverses full depth. "
        "Use 1 for pages only, 2 for pages and top-level frames",
    ] = None,
) -> Annotated[GetFileOutput, "File structure with pages and metadata"]:
    """Get a Figma file's structure including pages and metadata.

    Returns the file name, version, thumbnail, and list of pages.
    Use depth parameter to limit how much of the tree is returned for large files.
    """
    async with FigmaClient(context.get_auth_token_or_empty()) as client:
        file_data = await client.get_file(file_key, depth=depth)

    result = map_get_file(file_key, file_data)
    return cast(GetFileOutput, remove_none_values_recursive(result))


# =============================================================================
# get_pages
# API Calls: 1
# APIs Used: GET /v1/files/:key (REST) with depth=1
# Response Complexity: LOW - pages list only
# -----------------------------------------------------------------------------
# ToolAnnotations:
#   title: "Get Pages"
#   readOnlyHint: true       - Only reads file data
#   openWorldHint: true      - Interacts with Figma's external API
# =============================================================================
@tool(requires_auth=Figma(scopes=["file_content:read"]))
async def get_pages(
    context: ToolContext,
    file_key: Annotated[
        str,
        "File key. Can be found in Figma URL: https://www.figma.com/file/{FILE_KEY}/...",
    ],
) -> Annotated[GetPagesOutput, "List of pages in the file"]:
    """Get a list of pages in a Figma file.

    Returns page IDs and names without the full node tree.
    """
    async with FigmaClient(context.get_auth_token_or_empty()) as client:
        file_data = await client.get_file(file_key, depth=1)

    result = map_get_pages(file_key, file_data)
    return cast(GetPagesOutput, remove_none_values_recursive(result))


# =============================================================================
# get_file_nodes
# API Calls: 1
# APIs Used: GET /v1/files/:key/nodes (REST)
# Response Complexity: MEDIUM - node data with optional children
# -----------------------------------------------------------------------------
# ToolAnnotations:
#   title: "Get File Nodes"
#   readOnlyHint: true       - Only reads file data
#   openWorldHint: true      - Interacts with Figma's external API
# =============================================================================
@tool(requires_auth=Figma(scopes=["file_content:read"]))
async def get_file_nodes(
    context: ToolContext,
    file_key: Annotated[
        str,
        "File key. Can be found in Figma URL: https://www.figma.com/file/{FILE_KEY}/...",
    ],
    node_ids: Annotated[
        list[str],
        "List of node IDs to retrieve. Node IDs can be found in Figma URL "
        "after ?node-id= parameter (URL encoded, e.g., '0:1' or '1-2').",
    ],
    depth: Annotated[
        int | None,
        "How deep to traverse from each node. Use 1 for direct children only. "
        "Default returns all descendants.",
    ] = None,
) -> Annotated[GetFileNodesOutput, "Requested nodes with their data"]:
    """Get specific nodes from a Figma file by their IDs.

    Returns the requested nodes with their properties and optionally their children.
    Use this to fetch specific parts of a file without loading the entire document.
    """
    async with FigmaClient(context.get_auth_token_or_empty()) as client:
        nodes_data = await client.get_file_nodes(file_key, node_ids, depth=depth)

    result = map_get_file_nodes(file_key, nodes_data)
    return cast(GetFileNodesOutput, remove_none_values_recursive(result))


# =============================================================================
# export_image
# API Calls: 1
# APIs Used: GET /v1/images/:key (REST)
# Response Complexity: LOW - URLs to exported images
# -----------------------------------------------------------------------------
# ToolAnnotations:
#   title: "Export Image"
#   readOnlyHint: true       - Only exports, no modifications
#   openWorldHint: true      - Interacts with Figma's external API
# =============================================================================
@tool(requires_auth=Figma(scopes=["file_content:read"]))
async def export_image(
    context: ToolContext,
    file_key: Annotated[
        str,
        "File key. Can be found in Figma URL: https://www.figma.com/file/{FILE_KEY}/...",
    ],
    node_ids: Annotated[
        list[str],
        "List of node IDs to export as images.",
    ],
    image_format: Annotated[
        ImageFormat,
        "Image format. Default is png.",
    ] = ImageFormat.PNG,
    scale: Annotated[
        float | None,
        "Scale factor (0.01 to 4.0). Only applies to PNG/JPG. Default is 1.0.",
    ] = None,
) -> Annotated[ExportImageOutput, "Exported image URLs (temporary, ~14 days)"]:
    """Export Figma frames/nodes as images.

    Returns temporary URLs to download images. URLs valid for approximately 14 days.
    """
    if not node_ids:
        raise FatalToolError(
            message="At least one node_id is required",
            developer_message="node_ids parameter cannot be empty",
        )

    effective_scale = scale
    if image_format in (ImageFormat.PNG, ImageFormat.JPG):
        if effective_scale is not None:
            effective_scale = max(MIN_IMAGE_SCALE, min(effective_scale, MAX_IMAGE_SCALE))
    else:
        effective_scale = None

    async with FigmaClient(context.get_auth_token_or_empty()) as client:
        export_data = await client.export_images(
            file_key,
            node_ids,
            image_format=image_format.value,
            scale=effective_scale,
        )

    result = map_export_image(file_key, image_format.value, effective_scale or 1.0, export_data)
    return cast(ExportImageOutput, remove_none_values_recursive(result))
