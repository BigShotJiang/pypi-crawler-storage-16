"""Navigation tools for Figma toolkit.

FIGMA API LIMITATION:
The Figma REST API does not provide an endpoint to list all teams a user belongs to.
The /me endpoint does not include team information. Users must manually provide team IDs,
which can be extracted from Figma URLs: https://www.figma.com/files/team/{TEAM_ID}/...
"""

from typing import Annotated, cast

from arcade_tdk import ToolContext, tool
from arcade_tdk.auth import Figma

from arcade_figma.client import FigmaClient
from arcade_figma.models.mappers import (
    map_get_project_files,
    map_get_team_projects,
)
from arcade_figma.models.tool_outputs import (
    GetProjectFilesOutput,
    GetTeamProjectsOutput,
)
from arcade_figma.utils.response_utils import remove_none_values_recursive


# =============================================================================
# get_team_projects
# API Calls: 1
# APIs Used: GET /v1/teams/:team_id/projects (REST)
# Response Complexity: LOW - list of projects
# -----------------------------------------------------------------------------
# ToolAnnotations:
#   title: "Get Team Projects"
#   readOnlyHint: true       - Only reads project data
#   openWorldHint: true      - Interacts with Figma's external API
# -----------------------------------------------------------------------------
# NOTE: Requires projects:read scope which is ONLY available for private Figma
# OAuth apps. Public OAuth apps cannot use this scope.
# =============================================================================
@tool(requires_auth=Figma(scopes=["projects:read"]))
async def get_team_projects(
    context: ToolContext,
    team_id: Annotated[
        str,
        "Team ID. Can be found in Figma URL: https://www.figma.com/files/team/{TEAM_ID}/...",
    ],
) -> Annotated[GetTeamProjectsOutput, "Projects in the specified team"]:
    """Get all projects in a Figma team.

    Projects are containers within a team that group related design files.
    """
    async with FigmaClient(context.get_auth_token_or_empty()) as client:
        projects_data = await client.get_team_projects(team_id)

    result = map_get_team_projects(team_id, projects_data)
    return cast(GetTeamProjectsOutput, remove_none_values_recursive(result))


# =============================================================================
# get_project_files
# API Calls: 1
# APIs Used: GET /v1/projects/:project_id/files (REST)
# Response Complexity: LOW - list of files
# -----------------------------------------------------------------------------
# ToolAnnotations:
#   title: "Get Project Files"
#   readOnlyHint: true       - Only reads file data
#   openWorldHint: true      - Interacts with Figma's external API
# -----------------------------------------------------------------------------
# NOTE: Requires projects:read scope which is ONLY available for private Figma
# OAuth apps. Public OAuth apps cannot use this scope.
# =============================================================================
@tool(requires_auth=Figma(scopes=["projects:read"]))
async def get_project_files(
    context: ToolContext,
    project_id: Annotated[str, "Project ID. Can be obtained from get_team_projects."],
) -> Annotated[GetProjectFilesOutput, "Files in the specified project"]:
    """Get all files in a Figma project.

    Files are Figma design documents containing pages and frames.
    """
    async with FigmaClient(context.get_auth_token_or_empty()) as client:
        files_data = await client.get_project_files(project_id)

    result = map_get_project_files(project_id, files_data)
    return cast(GetProjectFilesOutput, remove_none_values_recursive(result))
