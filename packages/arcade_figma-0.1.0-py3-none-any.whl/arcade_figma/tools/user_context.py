"""User context tools for Figma toolkit."""

from typing import Annotated, cast

from arcade_tdk import ToolContext, tool
from arcade_tdk.auth import Figma

from arcade_figma.client import FigmaClient
from arcade_figma.models.mappers import map_who_am_i
from arcade_figma.models.tool_outputs import WhoAmIOutput
from arcade_figma.utils.response_utils import remove_none_values_recursive


# =============================================================================
# who_am_i
# API Calls: 1
# APIs Used: GET /v1/me (REST)
# Response Complexity: LOW - user profile with team list
# -----------------------------------------------------------------------------
# ToolAnnotations:
#   title: "Who Am I"
#   readOnlyHint: true       - Only reads user data, no modifications
#   openWorldHint: true      - Interacts with Figma's external API
# =============================================================================
@tool(requires_auth=Figma(scopes=["current_user:read"]))
async def who_am_i(
    context: ToolContext,
) -> Annotated[WhoAmIOutput, "Authenticated user's profile."]:
    """Get the authenticated user's profile."""
    async with FigmaClient(context.get_auth_token_or_empty()) as client:
        me_data = await client.get_me()

    result = map_who_am_i(me_data)
    return cast(WhoAmIOutput, remove_none_values_recursive(result))
