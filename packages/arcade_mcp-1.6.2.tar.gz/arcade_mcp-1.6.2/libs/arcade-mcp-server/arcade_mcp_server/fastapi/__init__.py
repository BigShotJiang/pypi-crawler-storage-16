"""FastAPI integration for MCP server."""
