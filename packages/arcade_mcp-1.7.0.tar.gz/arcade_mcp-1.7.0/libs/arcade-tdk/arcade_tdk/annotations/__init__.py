from arcade_core.annotations import Inferrable

__all__ = ["Inferrable"]
