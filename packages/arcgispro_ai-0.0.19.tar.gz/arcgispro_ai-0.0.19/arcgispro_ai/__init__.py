"""
ArcGIS Pro AI Tools
"""

__version__ = "0.0.19"
__author__ = "Danny McVey"
__email__ = "dannybmcvey@gmail.com"
__description__ = "AI tools for ArcGIS Pro"
