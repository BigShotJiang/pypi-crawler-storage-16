"""Instance for the Profiler in ArchivePodcast."""

from archivepodcast.utils.profiler import EventLastTime

event_times = EventLastTime(name="/")
