class Config:
    """
    全局配置。
    """

    NODE_SEPARATOR = "."
    DEFAULT_DIR = 7
    DEFAULT_FILE = 6
