"""
See COPYRIGHT.md for copyright information.
"""
from __future__ import annotations

# Add camelCaseOptionName
BETA_FEATURES_AND_DESCRIPTIONS: dict[str, str] = {
}
