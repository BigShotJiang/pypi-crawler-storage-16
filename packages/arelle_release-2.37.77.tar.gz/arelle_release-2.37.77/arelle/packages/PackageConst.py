"""
See COPYRIGHT.md for copyright information.
"""

from __future__ import annotations

META_INF_DIRECTORY = "META-INF"
