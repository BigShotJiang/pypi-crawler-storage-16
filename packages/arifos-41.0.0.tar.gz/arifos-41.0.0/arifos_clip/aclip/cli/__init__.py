"""A CLIP CLI Module - dispatchers and command group initialization."""
# Dispatchers for numeric commands are defined in separate _dispatcherNNN.py modules.
# This __init__.py could set up any shared context if needed (none required for now).
