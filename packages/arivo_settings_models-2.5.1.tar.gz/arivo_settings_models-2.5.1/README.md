# Settings Models

This repo contains model definitions for all Arivo settings (settings stored in RPCServer)


## Changes

Breaking changes are annotated [here](docs/migrations.md).
