import random
from typing import Dict, List


DEFAULT_TIMEOUT: int = 5
DEFAULT_SLEEP: int = 3
DEFAULT_MAX_RETRIES: int = 3

USER_AGENTS: List[str] = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) "
    "Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) "
    "Gecko/20100101 Firefox/132.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
]


def get_headers() -> Dict[str, str]:
    """get request headers with user agent rotation"""
    return {"User-Agent": random.choice(USER_AGENTS)}


def get_headers_by_index(idx: int) -> Dict[str, str]:
    """get request headers with user agent rotation"""
    return {"User-Agent": USER_AGENTS[idx % len(USER_AGENTS)]}
