import logging
from datetime import datetime
from dateutil import parser
from typing import Any, List, Optional


log = logging.getLogger(__name__)


def is_date(self, s: str) -> bool:
    try:
        parser.parse(s)
        return True
    except (ValueError, TypeError):
        return False


def to_type_datetime(date: Any) -> datetime:
    if not date:
        return datetime.now()

    if isinstance(date, datetime):
        return date

    if isinstance(date, str):
        try:
            if date.endswith("Z"):
                return parser.parse(date)
            else:
                return datetime.fromisoformat(date)
        except Exception:
            pass

    return datetime.now()


def to_type_float(s: str) -> float:
    if not s:
        return 0

    try:
        return float(s.replace(",", ""))  # no commas
    except Exception as e:
        logging.warning(f"invalid decimal number format: {s}")
        return 0


def to_type_int(s: str) -> int:
    if not s:
        return 0

    try:
        return int(s.replace(",", ""))  # no commas
    except ValueError:
        logging.warning(f"invalid whole number format: {s}")
        return 0


def to_type_list(value: Any, delimiter: Optional[str] = ",") -> List[Any]:
    if isinstance(value, list):
        return value
    elif isinstance(value, str):
        return [k.strip() for k in value.split(delimiter)]
    else:
        return [value]
