ideally, this inhales a lot of media and regurgitates markdown for a curated, research repository.
