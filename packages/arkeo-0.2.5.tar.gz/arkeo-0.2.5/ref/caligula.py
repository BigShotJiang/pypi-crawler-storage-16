import logging
import re
from typing import Optional

from arkeo.path import PathManager
from utils.access import DriveManager
from utils.json import load_json


log = logging.getLogger(__name__)


RE_DOCNUM = r"(\d{4}-\d{5})"


class Caligula:

    def __init__(self, path_manager: PathManager):
        self.path = path_manager
        self.drive: DriveManager = self.path.drive
        self.expr = re.compile(RE_DOCNUM)
        self.data = {}

        self._load_data()

    @property
    def dir_data(self) -> str:
        return self.path + "executive/"

    def _load_data(self):
        self.data = load_json(self.drive, self.dir_data + "")

    def query_federal_register(self, filepath: str) -> Optional[str]:
        eos = self.drive.read_or_none(filepath)
        eos = eos.split("\n")

        legion = []
        for eo in eos:
            spawn = self.expr.search(eo)
            if spawn:
                legion.append(spawn.group(1))

        if legion:
            return f"{{{','.join(legion)}}}"
