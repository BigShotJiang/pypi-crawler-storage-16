from setuptools import setup, find_packages

with open("requirements.txt") as f:
    requirements = [
        line.strip() for line in f if line.strip() and not line.startswith("#")
    ]

setup(
    name="arkeo",
    version="0.2.5",
    author="arkeosaurus",
    author_email="arkeosaurus@users.noreply.github.com",
    description="markdown archiver betasaurus",
    long_description="Ideally, this inhales a lot of media and regurgitates markdown for a curated, research repository.",
    long_description_content_type="text/plain",
    url="https://github.com/arkeosaurus/arkeo",
    packages=find_packages(),
    py_modules=["main", "manage"],
    package_data={
        "config": ["*.json"],  # Include all JSON files in config/
    },
    include_package_data=True,
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Text Processing",
        "Topic :: Internet :: WWW/HTTP :: Indexing/Search",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    entry_points={
        "console_scripts": [
            "arkeo=main:main",
            "arkeo-manage=manage:main",
        ],
    },
    keywords="document processing, archiving, indexing, markdown, corpus",
)
