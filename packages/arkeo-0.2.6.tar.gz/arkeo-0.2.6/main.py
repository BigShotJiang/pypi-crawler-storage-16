#!/usr/bin/env python3

import argparse
import logging
import time

from arkeo.ingest import Ingester
from utils.init import download_nltk_data, setup_logging, setup_slogging
from utils.url import is_valid_url


setup_logging(level=logging.INFO)
log = logging.getLogger(__name__)


def main() -> None:
    t0 = time.time()

    parser = argparse.ArgumentParser()
    parser.description = "all the noise thats fit to scream"
    parser.add_argument(
        "url", help="provide a nice, safe, agreeable link, please and tyvm"
    )
    args = parser.parse_args()

    if not is_valid_url(args.url):
        log.error(f"invalid url: {args.url}")
        return

    download_nltk_data()

    inge = Ingester()
    setup_slogging(path=inge.path.temp, drive_manager=inge.drive)

    inge.process(args.url)

    tt = time.time()
    log.warning(f"timer: {tt-t0:.2f} s")


if __name__ == "__main__":
    main()
