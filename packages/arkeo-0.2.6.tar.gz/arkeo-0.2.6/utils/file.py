from pathlib import Path


DELIMITER_MAP = {"csv": ",", "psv": "|", "ssv": ";", "tsv": "\t"}


def extract_extension_from_filename(filename: str) -> str:
    return Path(filename).suffix.lstrip(".")


def get_delimiter_from_file_extension(extension: str) -> str:
    return DELIMITER_MAP.get(extension.lower(), "")
