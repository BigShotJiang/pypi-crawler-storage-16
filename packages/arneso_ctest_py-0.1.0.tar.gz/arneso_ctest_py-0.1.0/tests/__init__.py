"""Test suite for the ctest_py package."""
