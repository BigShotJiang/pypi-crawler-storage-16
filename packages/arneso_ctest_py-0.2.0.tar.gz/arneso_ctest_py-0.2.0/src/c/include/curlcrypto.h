#ifndef CURLCRYPTO_H
#define CURLCRYPTO_H

const char *get_curl_version(void);
const char *get_openssl_version(void);

#endif
