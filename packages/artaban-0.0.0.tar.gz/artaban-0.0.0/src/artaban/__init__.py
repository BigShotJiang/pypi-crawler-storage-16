def hello() -> str:
    return "Hello from artaban!"
