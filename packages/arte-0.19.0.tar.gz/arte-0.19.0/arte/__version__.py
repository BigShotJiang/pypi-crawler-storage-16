VERSION = (0, 19, 0)

__version__ = '.'.join(map(str, VERSION))
