VERSION = (0, 20, 0)

__version__ = '.'.join(map(str, VERSION))
