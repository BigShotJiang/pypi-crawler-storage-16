CONTAINER_ENGINE_NOT_FOUND = 1000


class InvalidAPIKey(Exception):
    pass
