from enum import Enum


class BaType(Enum):
    NULL = 1
    NETT = 2
    NREV = 3
    REV = 4
