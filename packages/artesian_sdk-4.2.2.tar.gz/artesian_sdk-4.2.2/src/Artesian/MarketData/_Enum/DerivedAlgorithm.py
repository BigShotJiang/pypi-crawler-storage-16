from enum import Enum


class DerivedAlgorithm(Enum):
    MUV = 0
    Sum = 1
    Coalesce = 2
