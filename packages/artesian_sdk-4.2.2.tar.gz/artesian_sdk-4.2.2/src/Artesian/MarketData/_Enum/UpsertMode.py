from enum import Enum


class UpsertMode(Enum):
    Merge = 0
    Replace = 1
