"""Tests para language_analyzer."""
