# JobState


## Enum

* `QUEUED` (value: `'queued'`)

* `RUNNING` (value: `'running'`)

* `COMPLETED` (value: `'completed'`)

* `FAILED` (value: `'failed'`)

* `CANCELLED` (value: `'cancelled'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


