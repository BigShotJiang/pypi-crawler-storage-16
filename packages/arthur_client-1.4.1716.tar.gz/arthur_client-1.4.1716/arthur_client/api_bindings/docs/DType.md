# DType


## Enum

* `UNDEFINED` (value: `'undefined'`)

* `INT` (value: `'int'`)

* `FLOAT` (value: `'float'`)

* `BOOL` (value: `'bool'`)

* `STR` (value: `'str'`)

* `UUID` (value: `'uuid'`)

* `TIMESTAMP` (value: `'timestamp'`)

* `DATE` (value: `'date'`)

* `JSON` (value: `'json'`)

* `IMAGE` (value: `'image'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


