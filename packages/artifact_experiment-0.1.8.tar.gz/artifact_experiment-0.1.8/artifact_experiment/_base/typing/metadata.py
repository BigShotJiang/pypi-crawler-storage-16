from typing import Any, Mapping

Metadata = Mapping[str, Any]
