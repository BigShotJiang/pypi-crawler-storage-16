import os

APP_NAME = "artificer"

ARTIFICER_PROJECT_HOME = os.getenv("ARTIFICER_PROJECT_HOME", ".artificer")
