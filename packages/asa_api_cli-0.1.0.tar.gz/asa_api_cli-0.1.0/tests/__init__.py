"""Tests for search-ads-cli."""
