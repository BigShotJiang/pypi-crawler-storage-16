"""Unit tests for search-ads-api."""
