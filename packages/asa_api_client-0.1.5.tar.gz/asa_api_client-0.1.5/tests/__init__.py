"""Tests for search-ads-api."""
