# Models Reference

## Campaigns

::: asa_api_client.models.Campaign
    options:
      show_root_heading: true
      show_source: false

::: asa_api_client.models.CampaignCreate
    options:
      show_root_heading: true
      show_source: false

::: asa_api_client.models.CampaignUpdate
    options:
      show_root_heading: true
      show_source: false

## Ad Groups

::: asa_api_client.models.AdGroup
    options:
      show_root_heading: true
      show_source: false

::: asa_api_client.models.AdGroupCreate
    options:
      show_root_heading: true
      show_source: false

## Keywords

::: asa_api_client.models.Keyword
    options:
      show_root_heading: true
      show_source: false

::: asa_api_client.models.KeywordCreate
    options:
      show_root_heading: true
      show_source: false

## Common

::: asa_api_client.models.Money
    options:
      show_root_heading: true
      show_source: false

::: asa_api_client.models.Selector
    options:
      show_root_heading: true
      show_source: false
