from sqlalchemy.orm import DeclarativeBase

class DBEntity(DeclarativeBase):
    pass