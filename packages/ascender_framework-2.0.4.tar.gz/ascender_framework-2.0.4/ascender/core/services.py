class Service:
    pass