Embed ascii diagrams in source code / markdown files.
