Embed ascii diagrams in source code / markdown files.

```shell
asciigram --watch tests/examples/ 
```

(Under Construction)

Checklist for 1.0:
- [ ] Make tests run on the examples/ directory
- [ ] Add examples for d2 and mermaid
- [ ] Better error logging
- [ ] Clean up code
- [ ] Add docs
