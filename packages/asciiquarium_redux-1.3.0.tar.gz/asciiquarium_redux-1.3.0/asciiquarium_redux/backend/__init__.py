"""Backend integration layers for different runtimes (terminal, Tk, web)."""

__all__ = []
