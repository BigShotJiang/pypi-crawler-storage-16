"""Middleware for tracking ASGI reqeusts with Matomo."""

from asgi_matomo.middleware import MatomoMiddleware

__all__ = ["MatomoMiddleware"]
