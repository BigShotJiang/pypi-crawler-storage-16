from docs_src.testing.tutorial001 import test_app


def test_test_app() -> None:
    test_app()
