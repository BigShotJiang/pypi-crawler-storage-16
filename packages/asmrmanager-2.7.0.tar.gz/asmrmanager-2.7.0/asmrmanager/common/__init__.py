MUSIC_SUFFIXES = (".mp3", ".wav", ".m4a", ".flac")
