============
Installation
============

At the command line::

    $ easy_install assert_element

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv assert_element
    $ pip install assert_element
