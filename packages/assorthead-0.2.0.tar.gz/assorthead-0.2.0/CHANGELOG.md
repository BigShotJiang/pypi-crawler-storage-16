# Changelog

## 0.1.4

- Updated headers to match those in the corresponding R package.

## 0.1.3

- Updated headers to match those in the corresponding R package.

## 0.1.2

- Updated headers to match those in the corresponding R package.

## 0.1.1

- Updated headers to match those in the corresponding R package.

## 0.1.0

- Updated headers to match those in the corresponding R package.
