"""Web scraping functionality."""

from .scrape import *  # noqa: F403

__all__ = [
    "Scraper",
    "has_playwright",
]

