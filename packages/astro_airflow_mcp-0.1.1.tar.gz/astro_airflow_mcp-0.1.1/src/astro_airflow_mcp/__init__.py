"""Airflow MCP Server."""

from importlib.metadata import version

__version__ = version("astro-airflow-mcp")
