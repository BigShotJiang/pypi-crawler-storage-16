from .config import (
    jax_debug_nans as jax_debug_nans,
    jax_enable_x64 as jax_enable_x64,
    set_cpu_cores as set_cpu_cores,
    set_jax_platform as set_jax_platform,
)
