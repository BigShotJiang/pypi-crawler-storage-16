"""
Just define the package version in one place
"""

__version__ = "0.5.0"
