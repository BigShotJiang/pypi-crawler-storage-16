# plpy
Data reduction pipelines developed based on drpy.

## Installation
```
pip install astro-plpy
```

## Supported instruments (09/28/2023)
- 2.16-Meter/BFOSC
- Baade/FIRE