"""
Data reduction pipelines for 2.16-m/BFOSC.
"""