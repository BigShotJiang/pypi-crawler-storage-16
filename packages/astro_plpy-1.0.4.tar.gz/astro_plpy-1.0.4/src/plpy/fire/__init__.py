"""
Data reduction pipelines for Magellan/FIRE.
"""