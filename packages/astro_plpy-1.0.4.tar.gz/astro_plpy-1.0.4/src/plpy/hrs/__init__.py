"""
Data reduction pipelines for LJT/HRS.
"""