"""
Data reduction pipeline for mini-Sitian.
"""