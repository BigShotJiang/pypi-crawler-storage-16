"""
Data reduction pipelines for P200/TSPEC.
"""