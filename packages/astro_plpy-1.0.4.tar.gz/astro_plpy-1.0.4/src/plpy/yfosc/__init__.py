"""
Data reduction pipelines for LJT/YFOSC.
"""