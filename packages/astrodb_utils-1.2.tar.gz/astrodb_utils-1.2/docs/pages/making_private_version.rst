Making a Private Version of an Existing Database
================================================
