New Tables
==========

Existing tables can be used as models for new tables.

To add a new table, you will need to :doc:`edit the schema YAML file <yaml>`.


When creating a new table, consider the following:

Long vs Wide tables
~~~~~~~~~~~~~~~~~~~
Think carefully about the structure of your tables.
TODO: Need an example
