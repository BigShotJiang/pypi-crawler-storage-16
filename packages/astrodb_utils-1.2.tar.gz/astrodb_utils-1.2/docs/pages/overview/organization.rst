Repository / package organization
====================================
The below schematic image shows the organization of the repository and the packages.

.. image:: repo_organization.png
