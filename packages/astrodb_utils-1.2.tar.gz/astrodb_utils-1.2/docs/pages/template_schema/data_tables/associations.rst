Association
###########

.. seealso::
    :doc:`../lookup_tables/associationlist`
        Documentation on the Association List table

Table Documentation
===================

.. mdinclude:: ../astrodb-template-db/docs/schema/Associations.md

