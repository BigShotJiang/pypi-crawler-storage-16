Names
#####

.. seealso::
    :py:mod:`ingest_name<astrodb_utils.names.ingest_name>`
        Function to ingest name data


Table Documentation
===================
.. _source:  https://github.com/astrodbtoolkit/astrodb-template-db/blob/main/docs/schema/Names.md

The below table is built directly from the schema and is
included here from the `astrodb-template-db` documentation: `source`_.

.. mdinclude:: ../astrodb-template-db/docs/schema/Names.md

