"""Athena Airflow connection -> dbt profile mappings"""

from .access_key import AthenaAccessKeyProfileMapping

__all__ = ["AthenaAccessKeyProfileMapping"]
