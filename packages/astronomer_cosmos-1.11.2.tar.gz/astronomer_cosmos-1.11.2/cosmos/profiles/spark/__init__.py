"""Spark Airflow connection -> dbt profile mappings"""

from .thrift import SparkThriftProfileMapping

__all__ = ["SparkThriftProfileMapping"]
