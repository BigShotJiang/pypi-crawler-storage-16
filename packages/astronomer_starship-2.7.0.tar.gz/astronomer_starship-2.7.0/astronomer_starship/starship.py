from astronomer_starship.compat import StarshipPlugin

__all__ = [
    "StarshipPlugin",
]
