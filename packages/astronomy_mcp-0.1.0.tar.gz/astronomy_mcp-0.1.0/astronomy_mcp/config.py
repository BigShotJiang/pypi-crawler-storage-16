from typing import Optional
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    # Service Endpoints
    SIMBAD_URL: str = "https://simbad.u-strasbg.fr"
    VIZIER_URL: str = "https://vizier.u-strasbg.fr"
    
    # API Keys
    TNS_API_KEY: Optional[str] = None
    
    # Rate Limits
    SIMBAD_RATE_LIMIT: int = 6
    VIZIER_RATE_LIMIT: int = 10
    
    # Cache Settings
    CACHE_TTL: int = 86400  # Default 24 hours
    
    class Config:
        env_file = ".env"
        case_sensitive = True

settings = Settings()
