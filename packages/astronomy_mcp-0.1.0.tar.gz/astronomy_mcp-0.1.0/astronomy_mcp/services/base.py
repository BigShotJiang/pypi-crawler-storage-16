from abc import ABC, abstractmethod
import httpx
from ..config import settings
from ..utils.rate_limiter import RateLimiter

class BaseService(ABC):
    def __init__(self, rate_limit: int = 5):
        self.client = httpx.AsyncClient(timeout=30.0)
        self.rate_limiter = RateLimiter(rate_limit)

    async def _with_retry(self, func, *args, max_retries: int = 3, **kwargs):
        """
        Execute a function with exponential backoff retry logic.
        """
        import asyncio
        
        last_exception = None
        for attempt in range(max_retries):
            try:
                if asyncio.iscoroutinefunction(func):
                    return await func(*args, **kwargs)
                else:
                    return func(*args, **kwargs)
            except (httpx.NetworkError, httpx.TimeoutException, ConnectionError) as e:
                last_exception = e
                if attempt == max_retries - 1:
                    raise
                
                # Exponential backoff: 1s, 2s, 4s...
                delay = 2 ** attempt
                await asyncio.sleep(delay)
        
        if last_exception:
            raise last_exception

    async def _get(self, url: str, params: dict = None) -> httpx.Response:
        """
        Internal GET request with rate limiting, retry, and error handling wrapper.
        """
        async def _do_request():
            await self.rate_limiter.acquire()
            response = await self.client.get(url, params=params)
            response.raise_for_status()
            return response

        try:
            return await self._with_retry(_do_request)
        except httpx.HTTPError as e:
            # In a real app we might wrap this in a custom ServiceError
            raise e

    async def close(self):
        await self.client.aclose()
        
    @abstractmethod
    async def search(self, query: str):
        """Core search interface to be implemented by services."""
        pass
