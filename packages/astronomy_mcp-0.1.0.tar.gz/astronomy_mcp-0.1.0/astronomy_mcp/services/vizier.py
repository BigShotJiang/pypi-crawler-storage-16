import logging
import asyncio
from typing import List, Dict, Optional, Union
from astropy import coordinates
from astropy import units as u
from astropy.table import Table
import numpy as np
from astroquery.vizier import Vizier

from .base import BaseService
from ..config import settings
from ..utils.cache import cached

logger = logging.getLogger(__name__)

class VizierService(BaseService):
    """
    Service for querying the VizieR catalogue service.
    """
    def __init__(self):
        super().__init__(rate_limit=settings.VIZIER_RATE_LIMIT)
        self.vizier = Vizier()
        # Default row limit to avoid massive payloads
        self.vizier.ROW_LIMIT = 50

    @cached(ttl=settings.CACHE_TTL, key_prefix="vizier_catalog_search")
    async def search_catalogs(self, query: str) -> List[Dict]:
        """
        Search for catalogs in VizieR by keyword.
        """
        await self.rate_limiter.acquire()
        return await asyncio.to_thread(self._search_catalogs_sync, query)

    def _search_catalogs_sync(self, query: str) -> List[Dict]:
        try:
            catalogs = self.vizier.find_catalogs(query)
            
            results = []
            for name, catalog in catalogs.items():
                results.append({
                    'id': name,
                    'description': catalog.description,
                })
            return results
        except Exception as e:
            logger.error(f"VizieR catalog search failed for '{query}': {e}")
            return []

    @cached(ttl=settings.CACHE_TTL, key_prefix="vizier_region_query")
    async def query_region(self, 
                          ra: float, 
                          dec: float, 
                          radius_deg: float, 
                          catalog: Optional[str] = None) -> List[Dict]:
        """
        Query a specific catalog or default catalogs around a region.
        """
        await self.rate_limiter.acquire()
        return await asyncio.to_thread(self._query_region_sync, ra, dec, radius_deg, catalog)

    def _query_region_sync(self, ra: float, dec: float, radius_deg: float, catalog: Optional[str] = None) -> List[Dict]:
        try:
            coord = coordinates.SkyCoord(ra=ra, dec=dec, unit=(u.deg, u.deg), frame='icrs')
            radius = radius_deg * u.deg
            
            if catalog:
                # Query specific catalog
                result = self.vizier.query_region(coord, radius=radius, catalog=catalog)
            else:
                result = self.vizier.query_region(coord, radius=radius)

            if not result or len(result) == 0:
                return []
                
            # Process results. result is a TableList.
            processed_results = []
            
            # Limit to first few tables if multiple
            for val in list(result.values())[:3]: # limit to 3 tables mostly
                 processed_results.extend(self._process_table(val, catalog_name=val.meta.get('name', 'Unknown')))
                 
            return processed_results

        except Exception as e:
            logger.error(f"VizieR region query failed: {e}")
            return []

    def _process_table(self, table: Table, catalog_name: str) -> List[Dict]:
        results = []
        
        # Helper to find column case-insensitively
        def find_col(cols, candidates):
            for cand in candidates:
                for col in cols:
                    if col.lower() == cand.lower():
                        return col
            return None

        # Common column names
        ra_col = find_col(table.colnames, ['RAJ2000', '_RAJ2000', 'RA_ICRS', 'RA'])
        dec_col = find_col(table.colnames, ['DEJ2000', '_DEJ2000', 'DE_ICRS', 'DEC'])
        name_col = find_col(table.colnames, ['Name', 'Source', 'ID', 'Main_ID', 'HIP', 'TYC', 'Gaia'])
        mag_col = find_col(table.colnames, ['Vmag', 'Bmag', 'Gmag', 'Jmag', 'Kmag', 'Mag'])
        
        for row in table:
            try:
                item = {'_catalog': catalog_name}
                
                if ra_col:
                    item['ra'] = float(row[ra_col])
                if dec_col:
                    item['dec'] = float(row[dec_col])
                if name_col:
                    item['name'] = str(row[name_col])
                if mag_col and not np.ma.is_masked(row[mag_col]):
                    item['magnitude'] = float(row[mag_col])
                
                # Add all other columns primarily for detailed view
                for col in row.colnames:
                    if col not in [ra_col, dec_col, name_col, mag_col]:
                        val = row[col]
                        if isinstance(val, (bytes, str)):
                            item[col] = str(val)
                        elif np.issubdtype(type(val), np.number):
                            item[col] = float(val) if not np.ma.is_masked(val) else None
                        
                results.append(item)
            except Exception:
                continue
                
        return results

    # BaseService abstract method implementation
    async def search(self, query: str):
        return await self.search_catalogs(query)

# Singleton
_vizier_service: Optional[VizierService] = None

def get_vizier_service() -> VizierService:
    global _vizier_service
    if _vizier_service is None:
        _vizier_service = VizierService()
    return _vizier_service
