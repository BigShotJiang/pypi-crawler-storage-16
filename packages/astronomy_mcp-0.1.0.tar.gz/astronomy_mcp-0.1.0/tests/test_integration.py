import pytest
from astronomy_mcp.services.simbad import get_simbad_service
from astronomy_mcp.services.vizier import get_vizier_service

@pytest.mark.asyncio
@pytest.mark.integration
async def test_simbad_live_query():
    """
    Live test against SIMBAD.
    Note: Rate limits apply.
    """
    service = get_simbad_service()
    results = await service.search_objects("M42")
    
    assert len(results) > 0
    found = False
    for res in results:
        # Check for M 42 or M42 or Orion Nebula
        name = res['name'].replace(' ', '')
        if "M42" in name or "Orion" in name:
            found = True
            break
    assert found

@pytest.mark.asyncio
@pytest.mark.integration
async def test_vizier_live_search():
    service = get_vizier_service()
    results = await service.search_catalogs("Gaia")
    assert len(results) > 0
    assert any("Gaia" in r['description'] or "Gaia" in r['id'] for r in results)
