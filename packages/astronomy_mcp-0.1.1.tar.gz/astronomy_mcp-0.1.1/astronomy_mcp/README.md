# Astronomy Catalogues MCP Server

This is a Model Context Protocol (MCP) server that exposes astronomical data to LLMs. It integrates with:

- **SIMBAD**: For deep sky objects (stars, galaxies, nebulae).
- **JPL Horizons**: For solar system objects (planets, comets, asteroids).
- **Transient Name Server (TNS)**: For transient events (supernovae).

## Installation

1.  Clone this repository (or move this directory to a new location).
2.  Create a virtual environment:
    ```bash
    python3 -m venv venv
    source venv/bin/activate
    ```
3.  Install dependencies:
    ```bash
    pip install -r requirements.txt
    ```

## Configuration

1.  Copy `.env.example` to `.env`:
    ```bash
    cp .env.example .env
    ```
2.  (Optional) Add your TNS credentials to `.env` if you want to query transient objects.

## Usage

You can run the server directly with Python:

```bash
python server.py
```

### Configuring Claude Desktop

Add the following to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "astronomy": {
      "command": "/path/to/your/venv/bin/python",
      "args": ["/path/to/astronomy_mcp/server.py"]
    }
  }
}
```

## Tools

- `search_simbad_object(query)`: Search for deep sky objects.
- `get_simbad_details(simbad_id)`: Get detailed info for a Simbad object.
- `search_horizons_object(query)`: Search for solar system objects.
- `get_horizons_ephemeris(horizons_id)`: Get current position/motion for a solar system object.
- `search_tns_object(name)`: Search for a transient object.
