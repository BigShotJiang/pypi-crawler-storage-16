import asyncio
import logging
import sys
import os
from dotenv import load_dotenv

from mcp.server.fastmcp import FastMCP

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("astronomy_mcp")

# Import services
from .services.simbad import get_simbad_service
from .services.horizons import get_horizons_service
from .services.vizier import get_vizier_service
# We assume these exist but haven't been refactored yet, so we import normally
# If they are not in the package, this might fail, but based on file listing they are in services/
# We will use relative imports for consistency
try:
    from .services.tns import get_tns_service
    from .services.ned import get_ned_service
    from .services.gaia import get_gaia_service
except ImportError:
    # Fallback or strict failure? 
    # For now, let's assume they exist. If they were valid before, they should be valid now.
    pass

from astropy.coordinates import SkyCoord, EarthLocation, AltAz
from astropy.time import Time
from astropy import units as u


# Initialize FastMCP server
mcp = FastMCP("Astronomy Catalogues")

@mcp.tool()
async def search_simbad_object(query: str) -> str:
    """
    Search for deep sky objects in the SIMBAD database.
    
    Args:
        query: The name or identifier of the object (e.g., "M31", "Crab Nebula").
        
    Returns:
        A string summary of the matching objects.
    """
    try:
        service = get_simbad_service()
        results = await service.search_objects(query)
        
        if not results:
            return f"No objects found in SIMBAD for query: '{query}'"
        
        # Format results as a readable string
        output = [f"Found {len(results)} matches:"]
        for obj in results:
            output.append(
                f"- ID: {obj['simbad_id']}\n"
                f"  Name: {obj['name']}\n"
                f"  Type: {obj['object_type']}\n"
                f"  RA: {obj['ra_deg']:.5f}, Dec: {obj['dec_deg']:.5f}\n"
                f"  Magnitude: {obj['magnitude']}"
            )
        
        return "\n".join(output)
    except Exception as e:
        logger.error(f"Error in search_simbad_object: {e}")
        return f"An error occurred while searching SIMBAD: {str(e)}"

@mcp.tool()
async def get_simbad_details(simbad_id: str) -> str:
    """
    Get detailed information for a specific SIMBAD object by its ID.
    
    Args:
        simbad_id: The unique SIMBAD identifier (e.g., "M 31").
        
    Returns:
        Detailed information about the object.
    """
    try:
        service = get_simbad_service()
        result = await service.get_object_details(simbad_id)
        
        if not result:
            return f"No details found for SIMBAD ID: '{simbad_id}'"
        
        return (
            f"Object Details for {result['name']}:\n"
            f"ID: {result['simbad_id']}\n"
            f"Type: {result['object_type']}\n"
            f"Coordinates: RA {result['ra_deg']}, Dec {result['dec_deg']}\n"
            f"Magnitude: {result['magnitude']}"
        )
    except Exception as e:
        logger.error(f"Error in get_simbad_details: {e}")
        return f"An error occurred while fetching SIMBAD details: {str(e)}"

@mcp.tool()
async def search_horizons_object(query: str) -> str:
    """
    Search for solar system objects in JPL Horizons.
    
    Args:
        query: The name or designation (e.g., "Mars", "433", "C/2023 A3").
        
    Returns:
        A list of matching solar system objects.
    """
    try:
        service = get_horizons_service()
        results = await service.search_objects(query)
        
        if not results:
            return f"No solar system objects found for query: '{query}'"
        
        output = [f"Found {len(results)} matches:"]
        for obj in results:
            output.append(
                f"- ID: {obj['horizons_id']}\n"
                f"  Name: {obj['name']}\n"
                f"  Type: {obj['object_type']}"
            )
        
        return "\n".join(output)
    except Exception as e:
        logger.error(f"Error in search_horizons_object: {e}")
        return f"An error occurred while searching Horizons: {str(e)}"

@mcp.tool()
async def get_horizons_ephemeris(horizons_id: str) -> str:
    """
    Get current ephemeris (position and motion) for a solar system object.
    
    Args:
        horizons_id: The JPL Horizons identifier.
        
    Returns:
        Current position, magnitude, and motion details.
    """
    try:
        service = get_horizons_service()
        # We use the async wrapper if available, or run the sync one in a thread
        # The service has get_ephemeris_async
        result = await service.get_ephemeris_async(horizons_id)
        
        return (
            f"Ephemeris for {result['name']} (ID: {result['horizons_id']}):\n"
            f"Time: {result['observation_time']}\n"
            f"RA: {result['ra_deg']:.5f} deg\n"
            f"Dec: {result['dec_deg']:.5f} deg\n"
            f"Altitude: {result['altitude_deg']} deg\n"
            f"Azimuth: {result['azimuth_deg']} deg\n"
            f"Magnitude: {result['magnitude']}\n"
            f"Motion Rate: {result['motion']['rate']} arcsec/min\n"
            f"Motion Direction: {result['motion']['direction']} deg"
        )
    except Exception as e:
        logger.error(f"Error in get_horizons_ephemeris: {e}")
        return f"Error fetching ephemeris for '{horizons_id}': {str(e)}"

@mcp.tool()
async def search_tns_object(name: str) -> str:
    """
    Search for a transient object (supernova, etc.) in the Transient Name Server (TNS).
    
    Args:
        name: The name of the object (e.g., "2023xyz").
        
    Returns:
        Details about the transient object.
    """
    try:
        # Assuming get_tns_service is available
        from .services.tns import get_tns_service
        service = get_tns_service()
        result = await service.get_object(name)
        
        if not result:
            return f"No transient found in TNS with name: '{name}'"
        
        # TNS returns a complex structure, let's extract key info
        # Note: The structure depends on TNS API response, assuming standard fields
        
        obj_type = result.get("name_prefix", "Unknown")
        ra = result.get("radeg", "N/A")
        dec = result.get("decdeg", "N/A")
        mag = result.get("mag", "N/A")
        filter_name = result.get("filter", "N/A")
        
        return (
            f"TNS Object: {name}\n"
            f"Type: {obj_type}\n"
            f"RA: {ra}, Dec: {dec}\n"
            f"Latest Mag: {mag} ({filter_name})"
        )
    except ImportError:
         return "TNS service is not available."
    except Exception as e:
        return f"Error searching TNS for '{name}': {str(e)}"

@mcp.tool()
async def search_vizier_catalogs(query: str) -> str:
    """
    Search for available catalogs in VizieR.
    
    Args:
        query: Keywords to search for (e.g., "dark matter", "quasars").
    """
    try:
        service = get_vizier_service()
        results = await service.search_catalogs(query)
        
        if not results:
            return f"No catalogs found for: '{query}'"
        
        output = [f"Found {len(results)} catalogs:"]
        for cat in results:
            output.append(f"- {cat['id']}: {cat['description']}")
        return "\n".join(output)
    except Exception as e:
        logger.error(f"Error in search_vizier_catalogs: {e}")
        return f"Error searching VizieR catalogs: {str(e)}"

@mcp.tool()
async def search_ned_object(name: str) -> str:
    """
    Search for an extragalactic object in NED.
    
    Args:
        name: Object name (e.g., "M101", "3C 273").
    """
    try:
        from .services.ned import get_ned_service
        service = get_ned_service()
        result = await service.get_object_details(name)
        
        if not result:
            return f"Object '{name}' not found in NED."
            
        return (
            f"NED Object: {result['name']}\n"
            f"Type: {result['type']}\n"
            f"RA: {result['ra']:.5f}, Dec: {result['dec']:.5f}\n"
            f"Redshift: {result['redshift']}\n"
            f"Velocity: {result['velocity']} km/s\n"
            f"References: {result['references']}"
        )
    except ImportError:
        return "NED service is not available."
    except Exception as e:
        return f"Error searching NED: {str(e)}"

@mcp.tool()
async def cone_search(
    ra: float, 
    dec: float, 
    radius: float, 
    catalog: str = "simbad",
) -> str:
    """
    Search for objects within a cone around coordinates.
    
    Args:
        ra: Right Ascension in degrees.
        dec: Declination in degrees.
        radius: Radius of the cone in degrees.
        catalog: Source to query. Options: "simbad", "ned", "gaia", "vizier" (uses default tables), or specific VizieR ID (e.g., "I/239").
    """
    try:
        output = [f"Cone search at RA={ra}, Dec={dec}, r={radius} deg for '{catalog}':"]
        
        if catalog.lower() == "simbad":
            output.append("Note: For SIMBAD, please search by object name. Using VizieR generic search as fallback if intended.")
            # Fallback to Vizier for now as per previous logic
            return "SIMBAD cone search not yet fully implemented in service. Try catalog='vizier', 'ned', or 'gaia'."

        elif catalog.lower() == "ned":
            from .services.ned import get_ned_service
            service = get_ned_service()
            results = await service.query_region(ra, dec, radius)
            output.append(f"NED found {len(results)} objects:")
            for obj in results[:20]:
                output.append(f"- {obj['name']} ({obj['type']}) at distance {obj.get('dist_arcmin', '?'):.2f} arcmin")
                
        elif catalog.lower() == "gaia":
            from .services.gaia import get_gaia_service
            service = get_gaia_service()
            results = await service.query_cone(ra, dec, radius)
            output.append(f"Gaia found {len(results)} sources:")
            for obj in results[:20]:
                mag = f"Gmag={obj['phot_g_mean_mag']:.2f}" if obj['phot_g_mean_mag'] else "Gmag=?"
                output.append(f"- ID: {obj['source_id']} ({mag}) at {obj.get('dist_arcsec', '?'):.2f}\"")
                
        else:
            # Assume VizieR (common or specific catalog)
            service = get_vizier_service()
            cat_id = None if catalog.lower() == "vizier" else catalog
            results = await service.query_region(ra, dec, radius, catalog=cat_id)
            output.append(f"VizieR ('{catalog}') found {len(results)} objects:")
            for obj in results[:20]:
                name = obj.get('name', 'N/A')
                mag = obj.get('magnitude', '')
                mag_str = f", Mag: {mag}" if mag else ""
                
                ra_val = obj.get('ra')
                dec_val = obj.get('dec')
                ra_str = f"{ra_val:.4f}" if isinstance(ra_val, (int, float)) else str(ra_val or '?')
                dec_str = f"{dec_val:.4f}" if isinstance(dec_val, (int, float)) else str(dec_val or '?')
                
                output.append(f"- {name} (RA:{ra_str}, Dec:{dec_str}){mag_str}")

        return "\n".join(output)
    except Exception as e:
        logger.error(f"Error in cone_search: {e}")
        return f"An error occurred during cone search: {str(e)}"

@mcp.tool()
async def check_visibility(
    object_name: str,
    latitude: float,
    longitude: float,
    observation_time: str = "now",
    min_altitude: float = 30.0
) -> str:
    """
    Check if an object is visible from a specific location and time.
    
    Args:
        object_name: Name of the object (resolved via SIMBAD/NED).
        latitude: Observer latitude in degrees.
        longitude: Observer longitude in degrees.
        observation_time: Time of observation (ISO string e.g. "2023-10-27T22:00:00" or "now").
        min_altitude: Minimum altitude in degrees for the object to be considered visible.
    """
    try:
        # Create Observer
        try:
            location = EarthLocation(lat=latitude*u.deg, lon=longitude*u.deg)
            if observation_time == "now":
                time = Time.now()
            else:
                time = Time(observation_time)
        except Exception as e:
            return f"Error configuring location/time: {e}"

        # Resolve object coordinates
        # Try SIMBAD first
        simbad_service = get_simbad_service()
        simbad_res = await simbad_service.get_object_details(object_name)
        
        ra, dec = None, None
        obj_source = "SIMBAD"
        
        if simbad_res:
            ra = simbad_res['ra_deg']
            dec = simbad_res['dec_deg']
        else:
            # Try NED
            try:
                from .services.ned import get_ned_service
                ned_service = get_ned_service()
                ned_res = await ned_service.get_object_details(object_name)
                if ned_res:
                    ra = ned_res['ra']
                    dec = ned_res['dec']
                    obj_source = "NED"
            except Exception:
                pass
                
        if ra is None:
            return f"Could not resolve object '{object_name}' in SIMBAD or NED."

        # Calculate Alt/Az
        obj_coord = SkyCoord(ra=ra*u.deg, dec=dec*u.deg, frame='icrs')
        altaz = obj_coord.transform_to(AltAz(obstime=time, location=location))
        
        alt = altaz.alt.degree
        az = altaz.az.degree
        
        is_visible = alt >= min_altitude
        
        status = "VISIBLE" if is_visible else "NOT VISIBLE"
        
        return (
            f"Visibility for '{object_name}' ({obj_source}):\n"
            f"Status: {status} (Alt > {min_altitude} deg)\n"
            f"Altitude: {alt:.2f} deg\n"
            f"Azimuth: {az:.2f} deg\n"
            f"Coordinates: RA {ra:.4f}, Dec {dec:.4f}\n"
            f"Observer: {latitude}, {longitude} @ {time.iso}"
        )
            
    except Exception as e:
        logger.error(f"Error in check_visibility: {e}")
        return f"An error occurred in check_visibility: {str(e)}"

# Re-export other tools...

if __name__ == "__main__":
    mcp.run()
