import logging
from datetime import datetime
from typing import Optional, List, Dict
import asyncio
import math
from astroquery.jplhorizons import Horizons

from .base import BaseService
from ..config import settings
from ..utils.cache import cached

logger = logging.getLogger(__name__)

class HorizonsService(BaseService):
    """Service for querying JPL Horizons for solar system object data."""
    
    # Default location (Greenwich) if none provided
    DEFAULT_LOCATION = {
        'lon': 0.0,
        'lat': 51.4769,
        'elevation': 0.0
    }
    
    def __init__(self, location: Optional[dict] = None):
        super().__init__(rate_limit=5) # Default relaxed rate limit
        self.location = location or self.DEFAULT_LOCATION
    
    @cached(ttl=settings.CACHE_TTL, key_prefix="horizons_search")
    async def search_objects(self, query: str) -> List[Dict]:
        """Async cached wrapper for search_objects."""
        # For simple search we might not hit the API if we just parse strings, 
        # but _search_objects_sync actually hits Horizons to verify existence via ephemerides
        await self.rate_limiter.acquire()
        return await asyncio.to_thread(self._search_objects_sync, query)

    def _search_objects_sync(self, query: str) -> List[Dict]:
        """
        Search for solar system objects by name or designation.
        """
        results = []
        
        # Try to resolve the query as different object types
        test_ids = self._generate_search_ids(query)
        
        for test_id, object_type in test_ids:
            try:
                obj = Horizons(
                    id=test_id,
                    location=self.location,
                    epochs=datetime.utcnow().jd if hasattr(datetime.utcnow(), 'jd') else None
                )
                # Try to get ephemeris to verify object exists
                eph = obj.ephemerides()
                if eph is not None and len(eph) > 0:
                    # Extract the target name from the response
                    target_name = eph.meta.get('targetname', query)
                    results.append({
                        'horizons_id': test_id,
                        'name': target_name,
                        'object_type': object_type
                    })
            except Exception as e:
                logger.debug(f"Query '{test_id}' failed: {e}")
                continue
        
        return results
    
    def _generate_search_ids(self, query: str) -> List[tuple[str, str]]:
        """
        Generate potential Horizons IDs from a search query.
        """
        ids = []
        query_lower = query.lower().strip()
        
        # Check for planet names
        planets = {
            'mercury': ('199', 'planet'),
            'venus': ('299', 'planet'),
            'mars': ('499', 'planet'),
            'jupiter': ('599', 'planet'),
            'saturn': ('699', 'planet'),
            'uranus': ('799', 'planet'),
            'neptune': ('899', 'planet'),
        }
        if query_lower in planets:
            ids.append(planets[query_lower])
        
        # Check for comet designation (C/YYYY or P/YYYY)
        if query.startswith(('C/', 'P/', 'D/')):
            ids.append((query, 'comet'))
        
        # Check for numbered asteroid
        if query.isdigit():
            ids.append((query, 'asteroid'))
        
        # Check for named asteroid
        if query_lower not in planets and not query.startswith(('C/', 'P/', 'D/')):
            ids.append((query, 'asteroid'))
            ids.append((f'DES={query}', 'asteroid'))
            if not query.endswith(';'):
                ids.append((f'{query};', 'asteroid'))
        
        return ids
    
    @cached(ttl=60, key_prefix="horizons_ephemeris") # Shorter TTL for ephemeris as it changes with time
    async def get_ephemeris_async(
        self,
        horizons_id: str,
        observation_time: Optional[datetime] = None,
        location: Optional[dict] = None
    ) -> dict:
        """Async wrapper for get_ephemeris."""
        await self.rate_limiter.acquire()
        return await asyncio.to_thread(
            self._get_ephemeris_sync,
            horizons_id,
            observation_time,
            location
        )

    def _get_ephemeris_sync(
        self,
        horizons_id: str,
        observation_time: Optional[datetime] = None,
        location: Optional[dict] = None
    ) -> dict:
        """
        Get ephemeris data for a solar system object.
        """
        if observation_time is None:
            observation_time = datetime.utcnow()
            
        use_location = location or self.location
        
        try:
            # Create a 1-minute range to ensure valid response
            from datetime import timedelta
            stop_time = observation_time + timedelta(minutes=1)
            epochs_arg = {
                'start': observation_time.strftime('%Y-%m-%d %H:%M'),
                'stop': stop_time.strftime('%Y-%m-%d %H:%M'),
                'step': '1m'
            }

            obj = Horizons(
                id=horizons_id,
                location=use_location,
                epochs=epochs_arg
            )
            
            eph = obj.ephemerides()
            
            if eph is None or len(eph) == 0:
                raise Exception(f"No ephemeris data for '{horizons_id}'")
            
        except Exception as e:
            logger.error(f"Horizons query failed for '{horizons_id}': {e}")
            raise Exception(f"Object '{horizons_id}' not found: {e}")
        
        row = eph[0]
        
        # Extract position
        ra_deg = float(row['RA'])
        dec_deg = float(row['DEC'])
        
        # Extract Alt/Az if available
        altitude_deg = None
        azimuth_deg = None
        if 'EL' in row.keys():
            altitude_deg = float(row['EL'])
        if 'AZ' in row.keys():
            azimuth_deg = float(row['AZ'])
        
        # Extract magnitude
        magnitude = None
        for mag_col in ['V', 'Tmag', 'Nmag']:
            if mag_col in eph.colnames:
                try:
                    magnitude = float(row[mag_col])
                    break
                except (ValueError, TypeError):
                    continue
        
        # Calculate motion
        ra_rate = float(row.get('RA_rate', 0))  # arcsec/hour
        dec_rate = float(row.get('DEC_rate', 0))  # arcsec/hour
        
        ra_rate_min = ra_rate / 60.0
        dec_rate_min = dec_rate / 60.0
        
        motion_rate = math.sqrt(ra_rate_min**2 + dec_rate_min**2)
        motion_direction = math.degrees(math.atan2(ra_rate_min, dec_rate_min)) % 360
        
        return {
            'horizons_id': horizons_id,
            'name': eph.meta.get('targetname', horizons_id),
            'ra_deg': ra_deg,
            'dec_deg': dec_deg,
            'altitude_deg': altitude_deg,
            'azimuth_deg': azimuth_deg,
            'magnitude': magnitude,
            'motion': {
                'rate': round(motion_rate, 3),
                'direction': round(motion_direction, 1),
            },
            'observation_time': observation_time,
        }

    # BaseService abstract method implementation
    async def search(self, query: str):
        return await self.search_objects(query)

# Singleton instance
_horizons_service: Optional[HorizonsService] = None

def get_horizons_service() -> HorizonsService:
    global _horizons_service
    if _horizons_service is None:
        _horizons_service = HorizonsService()
    return _horizons_service
