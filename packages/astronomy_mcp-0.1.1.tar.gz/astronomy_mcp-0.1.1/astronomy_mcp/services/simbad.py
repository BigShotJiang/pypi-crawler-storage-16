import logging
import asyncio
from typing import List, Dict, Optional
import numpy as np
from astropy.table import Table
from astroquery.simbad import Simbad

from .base import BaseService
from ..config import settings
from ..utils.cache import cached

logger = logging.getLogger(__name__)

class SimbadService(BaseService):
    """
    Service for querying the SIMBAD astronomical database.
    """
    def __init__(self):
        super().__init__(rate_limit=settings.SIMBAD_RATE_LIMIT)
        # Configure Simbad to retrieve necessary fields
        self.simbad = Simbad()
        self.simbad.add_votable_fields('ra', 'dec', 'V', 'B', 'main_id')
        self.simbad.add_votable_fields('otype')
        # Set timeout to match our settings if possible, otherwise rely on default

    @cached(ttl=settings.CACHE_TTL, key_prefix="simbad_search")
    async def search_objects(self, query: str) -> List[Dict]:
        """
        Search for objects in SIMBAD by name.
        """
        # Acquire rate limit token before hitting the external service
        await self.rate_limiter.acquire()
        return await asyncio.to_thread(self._search_objects_sync, query)

    def _search_objects_sync(self, query: str) -> List[Dict]:
        try:
            table = self.simbad.query_object(query)
            
            if table is None:
                return []
                
            return self._process_table(table)
            
        except Exception as e:
            logger.error(f"SIMBAD search failed for '{query}': {e}")
            return []

    def _process_table(self, table: Table) -> List[Dict]:
        results = []
        if table is None:
            return results
            
        for row in table:
            try:
                # Extract fields
                main_id = str(row['main_id'])
                ra = float(row['ra'])
                dec = float(row['dec'])
                otype = str(row['otype'])
                
                # Magnitude
                mag = None
                if 'V' in row.colnames and not isinstance(row['V'], (np.ma.core.MaskedConstant, type(None))):
                     mag = float(row['V'])
                elif 'B' in row.colnames and not isinstance(row['B'], (np.ma.core.MaskedConstant, type(None))):
                     mag = float(row['B'])
                
                # Handle masked values
                if np.ma.is_masked(mag):
                    mag = None
                    
                results.append({
                    'simbad_id': main_id,
                    'name': main_id,
                    'ra_deg': ra,
                    'dec_deg': dec,
                    'object_type': otype,
                    'magnitude': mag
                })
            except Exception as e:
                logger.warning(f"Error processing SIMBAD row: {e}")
                continue
                
        return results

    @cached(ttl=settings.CACHE_TTL, key_prefix="simbad_details")
    async def get_object_details(self, simbad_id: str) -> Optional[Dict]:
        """
        Get detailed info for a specific SIMBAD ID.
        """
        await self.rate_limiter.acquire()
        return await asyncio.to_thread(self._get_object_details_sync, simbad_id)

    def _get_object_details_sync(self, simbad_id: str) -> Optional[Dict]:
        try:
            table = self.simbad.query_object(simbad_id)
            if table is None or len(table) == 0:
                return None
            
            processed = self._process_table(table)
            if processed:
                return processed[0]
            return None
        except Exception as e:
            logger.error(f"SIMBAD details failed for '{simbad_id}': {e}")
            return None

    # BaseService abstract method implementation
    async def search(self, query: str):
        return await self.search_objects(query)

# Singleton
_simbad_service: Optional[SimbadService] = None

def get_simbad_service() -> SimbadService:
    global _simbad_service
    if _simbad_service is None:
        _simbad_service = SimbadService()
    return _simbad_service
