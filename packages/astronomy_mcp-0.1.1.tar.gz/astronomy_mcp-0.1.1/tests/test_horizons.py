import pytest
from unittest.mock import patch
from astronomy_mcp.services.horizons import HorizonsService

@pytest.mark.asyncio
async def test_search_mars():
    with patch('astronomy_mcp.services.horizons.HorizonsService._search_objects_sync') as mock_sync:
        mock_sync.return_value = [{
            'horizons_id': '499',
            'name': 'Mars',
            'object_type': 'planet'
        }]
        
        service = HorizonsService()
        results = await service.search_objects("Mars")
        
        assert len(results) == 1
        assert results[0]["name"] == "Mars"
        assert results[0]["horizons_id"] == "499"

@pytest.mark.asyncio
async def test_ephemeris_call():
    with patch('astronomy_mcp.services.horizons.HorizonsService._get_ephemeris_sync') as mock_sync:
        mock_sync.return_value = {
            'horizons_id': '499',
            'name': 'Mars',
            'ra_deg': 50.0,
            'dec_deg': 10.0,
            'magnitude': -1.2,
            'motion': {'rate': 0.5, 'direction': 90.0},
            'observation_time': '2023-01-01'
        }
        
        service = HorizonsService()
        eph = await service.get_ephemeris_async("499")
        
        assert eph['name'] == "Mars"
        assert eph['magnitude'] == -1.2
