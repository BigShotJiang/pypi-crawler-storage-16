import pytest
import pytest_asyncio
from unittest.mock import Mock, patch, AsyncMock
from astronomy_mcp.services.simbad import SimbadService

@pytest.mark.asyncio
async def test_search_m31():
    # Mock the internal sync calls to avoid hitting network during simple tests
    with patch('astronomy_mcp.services.simbad.SimbadService._search_objects_sync') as mock_sync:
        mock_sync.return_value = [{
            'simbad_id': 'M 31',
            'name': 'M 31',
            'ra_deg': 10.68,
            'dec_deg': 41.26,
            'object_type': 'Galaxy',
            'magnitude': 3.44
        }]
        
        service = SimbadService()
        results = await service.search_objects("M31")
        
        assert len(results) > 0
        assert results[0]["name"] == "M 31"
        assert results[0]["ra_deg"] == 10.68

@pytest.mark.asyncio
async def test_simbad_handling_error():
    with patch('astronomy_mcp.services.simbad.SimbadService._search_objects_sync') as mock_sync:
        mock_sync.return_value = []
        
        service = SimbadService()
        results = await service.search_objects("InvalidObject123")
        assert len(results) == 0
