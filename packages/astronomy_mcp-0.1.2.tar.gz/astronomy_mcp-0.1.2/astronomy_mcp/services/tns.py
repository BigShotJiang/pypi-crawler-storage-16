import logging
import json
from typing import Optional, Dict

from .base import BaseService
from ..config import settings
from ..utils.cache import cached

logger = logging.getLogger(__name__)

class TNSService(BaseService):
    """
    Service for interacting with the Transient Name Server (TNS) API.
    """
    BASE_URL = "https://www.wis-tns.org/api/get"

    def __init__(self):
        super().__init__(rate_limit=2) # TNS can be strict
        self.api_key = settings.TNS_API_KEY
        self.bot_id = None # TNS typically just needs API key + User Agent marker, but config only has key. 
        # Assuming ID is not strictly required if User-Agent is set correctly or just key is used.
        # But wait, TNS API usually requires both? Or just key in post data?
        # The user provided valid logic before, let's adapt it.
        
        self.headers = {
            "User-Agent": "tns_marker" # Simple marker if ID unknown
        }
        
        if not self.api_key:
            logger.warning("TNS credentials not configured. TNS enrichment will be disabled.")

    @cached(ttl=settings.CACHE_TTL, key_prefix="tns_object")
    async def get_object(self, objname: str) -> Optional[Dict]:
        """
        Get object details from TNS by name (e.g., "2023xyz").
        """
        if not self.api_key:
            return None

        # TNS API expects a JSON payload inside a form parameter named 'data'
        payload = {
            "api_key": self.api_key,
            "data": json.dumps({
                "objname": objname
            })
        }

        # We need to send POST request, but BaseService._get is for GET.
        # We'll use self.client directly but wrap with rate limiter and retry.
        
        async def _do_post():
            await self.rate_limiter.acquire()
            response = await self.client.post(f"{self.BASE_URL}/object", data=payload, headers=self.headers)
            # TNS returns 200 even on API errors sometimes, check content type or logic?
            # It returns 403/429 for issues.
            response.raise_for_status()
            return response

        try:
            response = await self._with_retry(_do_post)
            
            data = await response.json()
            # Check for API-level errors in the response
            if "id_code" in data and data["id_code"] != 200:
                    logger.warning(f"TNS API error for {objname}: {data.get('id_message')}")
                    return None
            
            return data.get("data", {}).get("reply", {})
            
        except Exception as e:
            logger.error(f"Error fetching TNS data for {objname}: {e}")
            return None

    # BaseService abstract implementation
    async def search(self, query: str):
        return await self.get_object(query)

# Singleton instance
_tns_service: Optional[TNSService] = None

def get_tns_service() -> TNSService:
    global _tns_service
    if _tns_service is None:
        _tns_service = TNSService()
    return _tns_service
