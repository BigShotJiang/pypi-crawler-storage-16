import asyncio
import time
from collections import deque

class RateLimiter:
    """
    Token bucket style rate limiter for async calls.
    """
    def __init__(self, requests_per_second: int):
        self.rate = requests_per_second
        self.interval = 1.0  # Window size in seconds
        self._timestamps = deque()

    async def acquire(self):
        """
        Wait until a slot is available.
        """
        while True:
            now = time.time()
            
            # Remove timestamps outside the window
            while self._timestamps and now - self._timestamps[0] > self.interval:
                self._timestamps.popleft()
            
            if len(self._timestamps) < self.rate:
                self._timestamps.append(now)
                return
            
            # Wait for the oldest request to expire from the window
            wait_time = self._timestamps[0] + self.interval - now
            if wait_time > 0:
                await asyncio.sleep(wait_time)
