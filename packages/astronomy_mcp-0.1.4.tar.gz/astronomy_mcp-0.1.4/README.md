# Astronomy MCP

An MCP server bridging LLMs to major astronomy catalogs (SIMBAD, VizieR, Horizons, NED, Gaia, TNS).

## Features

- **Object Resolution**: Resolve astronomical object names to coordinates (M31 -> 00 42 44.3 +41 16 09).
- **Multi-Catalog Search**: 
  - **SIMBAD**: Deep sky objects.
  - **Horizons**: Solar system objects (ephemerides, motion).
  - **NED**: Extragalactic objects (redshift, velocity).
  - **Gaia**: High-precision parallax and photometry.
  - **TNS**: Transient events (supernovae).
  - **VizieR**: Access to thousands of astronomical catalogs.
- **Deep Integrations**:
  - `cone_search`: Find objects around a coordinate across catalogs.
  - `check_visibility`: Check if an object is visible from your location.
  - `crossmatch_object`: Find an object's cross-identifications.
- **Production Ready**: Robust rate limiting, caching, and retry logic.

## Installation

```bash
pip install astronomy-mcp
```

## Quick Start (Claude Desktop)

1. **Install the package**:
   ```bash
   pip install astronomy-mcp
   ```

2. **Configure Claude Desktop**:
   Open or create `~/Library/Application Support/Claude/claude_desktop_config.json` and add:
   ```json
   {
     "mcpServers": {
       "astronomy": {
         "command": "python",
         "args": ["-m", "astronomy_mcp.server"]
       }
     }
   }
   ```
   *Note: Ensure `python` executable path is correct if using a specific environment (e.g. `uv run` or `/path/to/venv/bin/python`).*

3. **Ask Claude**:
   - "What's the current position of Mars?"
   - "Find all galaxies within 30 arcmin of M31 using NED."
   - "What deep sky objects are visible from Denver tonight?"
   - "Get Gaia data for the star Betelgeuse."

## Tool Reference

| Tool | Description | Example Query |
|------|-------------|---------------|
| `search_simbad_object` | Search for deep sky objects | "Search Simbad for 'Crab Nebula'" |
| `get_simbad_details` | Get detailed info for SIMBAD ID | "Get details for 'M 1'" |
| `search_horizons_object` | Search solar system objects | "Find 'C/2023 A3' in Horizons" |
| `get_horizons_ephemeris` | Get current position/motion | "Where is Mars right now?" |
| `search_ned_object` | Search NED (Extragalactic) | "Find info on '3C 273' in NED" |
| `search_tns_object` | Search Transients | "Look up '2023ixf' in TNS" |
| `cone_search` | Find objects in a region | "What is within 0.1 deg of RA=10, Dec=20?" |
| `check_visibility` | Check observability | "Is M31 visible from New York at 10 PM?" |
| `recommend_targets` | Get observation validation | "What should I look at tonight from London?" |

## Development

```bash
# Install dependencies
pip install -e ".[dev]"

# Run tests
pytest
```

## Configuration

Copy `.env.example` to `.env` to configure API keys (if needed for TNS) and tune rate limits.
