"""Astronomy MCP Server - Bridge LLMs to major astronomy catalogs."""
