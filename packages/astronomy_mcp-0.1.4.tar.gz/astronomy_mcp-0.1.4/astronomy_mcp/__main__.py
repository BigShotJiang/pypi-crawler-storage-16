"""Entry point for running the MCP server as a module: python -m astronomy_mcp"""

import sys
import logging

# Configure logging before importing server to suppress noisy JSON parsing errors
# These are expected when stdin is empty or contains invalid input
logging.basicConfig(level=logging.INFO)

# Suppress JSON parsing errors with a filter
class SuppressJSONParseErrors(logging.Filter):
    def filter(self, record):
        if "json_invalid" in str(record.getMessage()).lower():
            return False
        if "eof while parsing" in str(record.getMessage()).lower():
            return False
        return True

for logger_name in ["mcp.server.lowlevel.server", "mcp.server.exception_handler"]:
    mcp_logger = logging.getLogger(logger_name)
    mcp_logger.addFilter(SuppressJSONParseErrors())
    mcp_logger.setLevel(logging.CRITICAL)

from .server import mcp

if __name__ == "__main__":
    # Check if we're running in an interactive terminal
    if sys.stdin.isatty() or sys.stdout.isatty():
        print("MCP Server starting...", file=sys.stderr)
        print("Note: MCP servers communicate via JSON-RPC over stdio.", file=sys.stderr)
        print("This server is designed to be run by an MCP client (e.g., Claude Desktop).", file=sys.stderr)
        print("JSON-RPC messages will be sent to stdout - this is normal.", file=sys.stderr)
        print("Press Ctrl+C to stop.", file=sys.stderr)
    
    try:
        mcp.run()
    except KeyboardInterrupt:
        # Handle Ctrl+C gracefully
        if sys.stdin.isatty() or sys.stdout.isatty():
            print("\nServer stopped.", file=sys.stderr)
        sys.exit(0)
    except Exception as e:
        # Only show unexpected errors, not the expected JSON parsing errors
        if "json_invalid" not in str(e).lower() and "eof" not in str(e).lower():
            logging.error(f"Unexpected error: {e}", exc_info=True)
        sys.exit(1)

