import logging
import asyncio
from typing import List, Dict, Optional
import numpy as np
from astropy import coordinates
from astropy import units as u

from .base import BaseService
from ..config import settings
from ..utils.cache import cached

logger = logging.getLogger(__name__)

class GaiaService(BaseService):
    """
    Service for querying existing Gaia data (defaulting to DR3).
    """
    
    def __init__(self):
        super().__init__(rate_limit=10) # Gaia is robust
        # Lazy import to avoid blocking network call at module import time
        from astroquery.gaia import Gaia
        # Set row limit for synchronous queries to avoid timeouts/heavy loads
        Gaia.ROW_LIMIT = 50

    @cached(ttl=settings.CACHE_TTL, key_prefix="gaia_cone")
    async def query_cone(self, ra: float, dec: float, radius_deg: float) -> List[Dict]:
        """
        Perform a cone search on Gaia DR3.
        """
        await self.rate_limiter.acquire()
        async def _do_query():
            return await asyncio.to_thread(self._query_cone_sync, ra, dec, radius_deg)
            
        return await self._with_retry(_do_query)

    def _query_cone_sync(self, ra: float, dec: float, radius_deg: float) -> List[Dict]:
        try:
            coord = coordinates.SkyCoord(ra=ra, dec=dec, unit=(u.deg, u.deg), frame='icrs')
            radius = radius_deg * u.deg
            
            # Construct ADQL query for cone search
            # 1=CONTAINS(POINT('ICRS', ra, dec), CIRCLE('ICRS', {ra}, {dec}, {radius}))
            query = f"""
            SELECT TOP 20 source_id, ra, dec, parallax, pmra, pmdec, phot_g_mean_mag 
            FROM gaiadr3.gaia_source 
            WHERE 1=CONTAINS(POINT('ICRS', ra, dec), CIRCLE('ICRS', {ra}, {dec}, {radius_deg}))
            """
            
            from astroquery.gaia import Gaia
            job = Gaia.launch_job_async(query)
            result = job.get_results()
            
            processed = []
            for row in result:
                try:
                    # Calculate distance from query center if not provided by query
                    # job.get_results() returns an Astropy Table
                    
                    # Manual distance calculation for response consistency (approximate)
                    # Simple Euclidean for small angles or use astropy separation
                    row_coord = coordinates.SkyCoord(ra=row['ra']*u.deg, dec=row['dec']*u.deg, frame='icrs')
                    center_coord = coordinates.SkyCoord(ra=ra*u.deg, dec=dec*u.deg, frame='icrs')
                    dist_arcsec = row_coord.separation(center_coord).arcsec
                    
                    processed.append({
                        'source_id': str(row['source_id']),
                        'ra': float(row['ra']),
                        'dec': float(row['dec']),
                        'parallax': float(row['parallax']) if not np.ma.is_masked(row['parallax']) else None,
                        'pmra': float(row['pmra']) if not np.ma.is_masked(row['pmra']) else None,
                        'pmdec': float(row['pmdec']) if not np.ma.is_masked(row['pmdec']) else None,
                        'phot_g_mean_mag': float(row['phot_g_mean_mag']) if not np.ma.is_masked(row['phot_g_mean_mag']) else None,
                        'dist_arcsec': float(dist_arcsec)
                    })
                except Exception:
                    continue
            return processed
            
        except Exception as e:
            logger.error(f"Gaia cone search failed: {e}")
            return []
            
    # BaseService abstract implementation
    async def search(self, query: str):
         # Gaia search by name requires resolving name first, usually handled by Simbad.
         # We could implement a direct name search using the 'designation' text if indexed, 
         # but for now we return empty or raise.
         return []

# Singleton
_gaia_service: Optional[GaiaService] = None

def get_gaia_service() -> GaiaService:
    global _gaia_service
    if _gaia_service is None:
        _gaia_service = GaiaService()
    return _gaia_service
