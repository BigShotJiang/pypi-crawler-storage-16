import logging
import asyncio
from typing import List, Dict, Optional
from astroquery.ipac.ned import Ned
from astropy import coordinates
from astropy import units as u
import numpy as np

from .base import BaseService
from ..config import settings
from ..utils.cache import cached

logger = logging.getLogger(__name__)

class NedService(BaseService):
    """
    Service for querying the NASA Extragalactic Database (NED).
    """
    
    def __init__(self):
        super().__init__(rate_limit=10) # NED is relatively relaxed

    @cached(ttl=settings.CACHE_TTL, key_prefix="ned_details")
    async def get_object_details(self, name: str) -> Optional[Dict]:
        """
        Get detailed information for an object from NED.
        """
        await self.rate_limiter.acquire()
        async def _do_search():
             return await asyncio.to_thread(self._get_object_details_sync, name)
        
        return await self._with_retry(_do_search)

    def _get_object_details_sync(self, name: str) -> Optional[Dict]:
        try:
            result_table = Ned.query_object(name)
            if result_table is None or len(result_table) == 0:
                return None
            
            # NED returns a Main table.
            row = result_table[0]
            
            return {
                'name': str(row['Object Name']),
                'ra': float(row['RA']),
                'dec': float(row['DEC']),
                'type': str(row['Type']),
                'redshift': float(row['Redshift']) if not np.ma.is_masked(row['Redshift']) else None,
                'velocity': float(row['Velocity']) if not np.ma.is_masked(row['Velocity']) else None,
                'references': int(row['References']) if 'References' in row.colnames else 0
            }

        except Exception as e:
            logger.warning(f"NED object search failed for '{name}': {e}")
            return None

    @cached(ttl=settings.CACHE_TTL, key_prefix="ned_region")
    async def query_region(self, ra: float, dec: float, radius_deg: float) -> List[Dict]:
        """
        Cone search in NED.
        """
        await self.rate_limiter.acquire()
        async def _do_query():
            return await asyncio.to_thread(self._query_region_sync, ra, dec, radius_deg)
            
        return await self._with_retry(_do_query)

    def _query_region_sync(self, ra: float, dec: float, radius_deg: float) -> List[Dict]:
        try:
            coord = coordinates.SkyCoord(ra=ra, dec=dec, unit=(u.deg, u.deg), frame='icrs')
            radius = radius_deg * u.deg
            
            table = Ned.query_region(coord, radius=radius)
            
            results = []
            if table is None:
                return results

            for row in table:
                try:
                    results.append({
                        'name': str(row['Object Name']),
                        'ra': float(row['RA']),
                        'dec': float(row['DEC']),
                        'type': str(row['Type']),
                        'redshift': float(row['Redshift']) if not np.ma.is_masked(row['Redshift']) else None,
                        'dist_arcmin': float(row['Distance (arcmin)']) if 'Distance (arcmin)' in row.colnames else None
                    })
                except Exception:
                    continue
            
            return results
        except Exception as e:
            logger.error(f"NED region query failed: {e}")
            return []
            
    # BaseService abstract implementation
    async def search(self, query: str):
        # NED has no direct "search" in the same sense, usually object lookup
        return await self.get_object_details(query)

# Singleton
_ned_service: Optional[NedService] = None

def get_ned_service() -> NedService:
    global _ned_service
    if _ned_service is None:
        _ned_service = NedService()
    return _ned_service
