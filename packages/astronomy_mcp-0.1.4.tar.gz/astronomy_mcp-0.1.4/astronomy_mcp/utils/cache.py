import asyncio
import functools
import hashlib
import json
from datetime import datetime, timedelta
from typing import Any, Callable, Dict, Optional

class SimpleCache:
    """
    A simple in-memory cache with TTL support.
    In a real production environment, this would be backed by Redis.
    """
    def __init__(self):
        self._cache: Dict[str, Any] = {}
        self._timestamps: Dict[str, datetime] = {}

    def get(self, key: str) -> Optional[Any]:
        if key not in self._cache:
            return None
        
        # Check TTL
        # Note: We implement lazy expiration here
        return self._cache[key]

    def set(self, key: str, value: Any, ttl: int):
        self._cache[key] = value
        self._timestamps[key] = datetime.now() + timedelta(seconds=ttl)

    def is_expired(self, key: str) -> bool:
        if key not in self._timestamps:
            return True
        return datetime.now() > self._timestamps[key]
        
    def clear_expired(self):
        """Cleanup expired keys"""
        now = datetime.now()
        keys_to_remove = [k for k, t in self._timestamps.items() if now > t]
        for k in keys_to_remove:
            del self._cache[k]
            del self._timestamps[k]

# Global cache instance
_cache = SimpleCache()

def generate_cache_key(prefix: str, *args, **kwargs) -> str:
    """Generate a consistent cache key from arguments."""
    key_str = f"{prefix}:{args}:{json.dumps(kwargs, sort_keys=True)}"
    return hashlib.md5(key_str.encode()).hexdigest()

def cached(ttl: int = 3600, key_prefix: str = "view"):
    """
    Async caching decorator.
    """
    def decorator(func: Callable):
        @functools.wraps(func)
        async def wrapper(self, *args, **kwargs):
            # Generate key
            # We assume 'self' is the service instance and don't include it in key if it's stateless enough
            # or if we want to share cache across instances. Use remaining args.
            cache_key = generate_cache_key(key_prefix, *args, **kwargs)
            
            # Check cache
            if not _cache.is_expired(cache_key):
                val = _cache.get(cache_key)
                if val is not None:
                    return val
            
            # Execute
            result = await func(self, *args, **kwargs)
            
            # Store
            _cache.set(cache_key, result, ttl)
            return result
        return wrapper
    return decorator
