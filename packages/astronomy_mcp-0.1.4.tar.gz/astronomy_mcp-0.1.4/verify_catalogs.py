import asyncio
import sys
import os

# Add path to find modules
sys.path.append(os.path.abspath("astronomy_mcp"))

from astronomy_mcp.server import (
    search_vizier_catalogs,
    search_ned_object,
    cone_search,
    crossmatch_object,
    recommend_targets
)

async def run_tests():
    print("=== Testing VizieR Search ===")
    try:
        res = await search_vizier_catalogs("exoplanet")
        print(res[:500] + "..." if len(res) > 500 else res)
    except Exception as e:
        print(f"FAILED: {e}")

    print("\n=== Testing NED Object Search ===")
    try:
        res = await search_ned_object("M101")
        print(res)
    except Exception as e:
        print(f"FAILED: {e}")

    print("\n=== Testing Cone Search (VizieR) ===")
    try:
        # Crab Nebula approx coords: RA 83.633, Dec 22.014
        res = await cone_search(83.633, 22.014, 0.05, catalog="vizier")
        print(res[:500] + "..." if len(res) > 500 else res)
    except Exception as e:
        print(f"FAILED: {e}")

    print("\n=== Testing Cone Search (Gaia) ===")
    try:
        # Pleiades center approx RA 56.75, Dec 24.11
        res = await cone_search(56.75, 24.11, 0.05, catalog="gaia")
        print(res[:500] + "..." if len(res) > 500 else res)
    except Exception as e:
        print(f"FAILED: {e}")

    print("\n=== Testing Crossmatch ===")
    try:
        res = await crossmatch_object("Crab Nebula")
        print(res)
    except Exception as e:
        print(f"FAILED: {e}")

    print("\n=== Testing Recommend Targets ===")
    try:
        # San Francisco approx lat/lon
        res = await recommend_targets(37.77, -122.41)
        print(res)
    except Exception as e:
        print(f"FAILED: {e}")

if __name__ == "__main__":
    asyncio.run(run_tests())
