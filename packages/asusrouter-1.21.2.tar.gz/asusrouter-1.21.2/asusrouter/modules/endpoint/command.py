"""Command endpoint module."""

from __future__ import annotations

from asusrouter.tools.readers import read_json_content as read

__all__ = ["read"]
