#ifndef GAUSSDB_DEBUG
#define GAUSSDB_DEBUG 0
#endif
