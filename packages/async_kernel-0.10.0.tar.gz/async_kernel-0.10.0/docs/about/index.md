---
title: About
description: Notes about contributing, changelog and development.
icon:
# subtitle: A sub title
---

- **[Contributing](../about/contributing.md#contributing)**
- **[Changelog](../about/changelog.md#changelog)**
- **[License](../about/license.md#license)**
