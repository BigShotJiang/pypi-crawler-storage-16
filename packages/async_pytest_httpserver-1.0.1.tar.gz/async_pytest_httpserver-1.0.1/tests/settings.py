EXTERNAL_SERVICE_URL = "some_url.com/api"
