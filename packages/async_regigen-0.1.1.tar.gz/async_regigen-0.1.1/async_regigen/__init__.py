# async_regigen/__init__.py

from .geometry import AsyncRectangleGenerator

__all__ = ["AsyncRectangleGenerator"]

# 定义包的版本
__version__ = "0.1.0"