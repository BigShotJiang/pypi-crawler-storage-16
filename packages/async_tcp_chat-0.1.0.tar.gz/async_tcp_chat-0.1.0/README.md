# Async TCP Chat

Easy chat module for an async TCP chat server or client


## server-client mode

Run the server calling

$ async_tcp_chat --server

and then connect the clients you like just calling:

$ async_tcp_chat --client



## wx GUI mode

If you prefer, you can run the client in wx GUI mode.

$ async_tcp_chat --gui
