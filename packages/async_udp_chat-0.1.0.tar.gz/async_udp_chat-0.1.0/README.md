# Async UDP Chat

Easy module for an async UDP chat server or client, implemented for didactic purpose.


## server mode

Run the server calling

$ async_udp_chat --server


## client mode (textual)

Run the client calling

$ async_udp_chat --client


## client mode (wx GUI)

If you prefer, you can run the client in wx GUI mode.

$ async_udp_chat --gui
