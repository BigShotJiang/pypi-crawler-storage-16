"""Infrastructure for task execution."""

from .process_pool_manager import ProcessPoolManager

__all__ = [
    "ProcessPoolManager",
]
