"""Integration tests for ORM hooks using real ORMs and PostgreSQL."""
