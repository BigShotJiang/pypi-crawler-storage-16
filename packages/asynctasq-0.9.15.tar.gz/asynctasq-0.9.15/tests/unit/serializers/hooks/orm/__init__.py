"""Unit tests for ORM hooks."""
