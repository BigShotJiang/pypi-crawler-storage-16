"""Core task tests."""
