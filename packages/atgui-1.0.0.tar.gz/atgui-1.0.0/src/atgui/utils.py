import colorama

def color_ret(color: str, type: str):
        if color == "white":
            if type == "fore":
                return colorama.Fore.WHITE
            elif type == "back":
                return colorama.Back.WHITE
            
        if color == "red":
            if type == "fore":
                return colorama.Fore.RED
            elif type == "back":
                return colorama.Back.RED
            
        if color == "yellow":
            if type == "fore":
                return colorama.Fore.YELLOW
            elif type == "back":
                return colorama.Back.YELLOW
            
        if color == "blue":
            if type == "fore":
                return colorama.Fore.BLUE
            elif type == "back":
                return colorama.Back.BLUE
            
        if color == "cyan":
            if type == "fore":
                return colorama.Fore.CYAN
            elif type == "back":
                return colorama.Back.CYAN
                
        return ""