from enum import Enum
 
class CameraRole(Enum):
    MASTER = 1
    SLAVE = 2
