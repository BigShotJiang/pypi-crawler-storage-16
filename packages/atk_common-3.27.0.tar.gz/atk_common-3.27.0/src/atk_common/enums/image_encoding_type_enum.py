from enum import Enum
 
class ImageEncodingType(Enum):
    RAW = 1
    JPEG = 2
    JXL = 3
