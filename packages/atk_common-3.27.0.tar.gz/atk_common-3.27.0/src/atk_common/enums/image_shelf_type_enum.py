from enum import Enum
 
class ImageShelfType(Enum):
    TOP = 1
    BOTTOM = 2
