from enum import Enum
 
class SectionRole(Enum):
    A = 1
    B = 2
