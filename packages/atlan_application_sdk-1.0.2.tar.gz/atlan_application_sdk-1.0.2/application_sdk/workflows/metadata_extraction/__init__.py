from application_sdk.workflows import WorkflowInterface


class MetadataExtractionWorkflow(WorkflowInterface):
    pass
