"""
Version information for the application_sdk package.
"""

__version__ = "1.0.3"
