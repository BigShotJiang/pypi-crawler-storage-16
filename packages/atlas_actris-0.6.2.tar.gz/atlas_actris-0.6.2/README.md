# ATLAS
Automated Lidar Analysis Software (ATLAS). 
A piece of software designed for the analysis of lidar data in an automated fashion and with focus on the following Quality Assurance tests: Rayleigh Fit, Telecover, Polarization Calibration. 
Quicklook generation is also supported.
Please look at the manual for detailed information about the installation and the configuration of the algorithm.
