# Atomic Assembler - CLI tool for assembling atomic projects
