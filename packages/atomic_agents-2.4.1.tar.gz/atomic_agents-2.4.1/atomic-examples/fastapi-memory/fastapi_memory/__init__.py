"""FastAPI Atomic Agents example - Conversational AI with session management."""

__version__ = "1.0.0"
