"""Service layer for the application."""
