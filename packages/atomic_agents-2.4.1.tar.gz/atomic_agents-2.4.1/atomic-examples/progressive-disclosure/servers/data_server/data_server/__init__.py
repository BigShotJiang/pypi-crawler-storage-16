"""Data MCP Server - list/data operations for progressive disclosure demo."""
