"""Math MCP Server - arithmetic operations for progressive disclosure demo."""
