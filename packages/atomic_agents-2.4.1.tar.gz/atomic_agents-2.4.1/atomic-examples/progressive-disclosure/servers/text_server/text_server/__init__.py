"""Text MCP Server - text manipulation operations for progressive disclosure demo."""
