# Utilities

## Tool Message Formatting

```{eval-rst}
.. automodule:: atomic_agents.utils.format_tool_message
   :members:
   :undoc-members:
   :show-inheritance:
```
