# atomicds (shim)

This is a thin compatibility package that depends on the renamed SDK,
`atomscale`. Installing or importing `atomicds` will emit a
`DeprecationWarning` and forward to the `atomscale` package.
