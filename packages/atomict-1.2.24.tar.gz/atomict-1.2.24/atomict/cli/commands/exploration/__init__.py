# import click

# Use a flattened list of commands for now
# @click.group(name='exploration')
# def exploration_group():
#     """Manage exploration tasks"""
#     pass
