

class APIValidationError(Exception):
    pass


class PermissionDenied(Exception):
    pass


class UserTaskAbortException(Exception):
    pass
