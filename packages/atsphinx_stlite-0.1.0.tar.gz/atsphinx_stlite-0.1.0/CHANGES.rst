=================
Recent changelogs
=================

v0.1.0
======

:Date: 2025-12-11 (Asia/Tokyo)

Features
--------

* Add ``stlite`` directive.
* Define ``stlite_default_version``.

v0.0.0
======

:date: 2025-12-09 (Asia/Tokyo)

Initial commit.
