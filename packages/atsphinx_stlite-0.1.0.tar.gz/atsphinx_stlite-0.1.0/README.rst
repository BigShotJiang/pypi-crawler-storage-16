===============
atsphinx-stlite
===============

Embed Stlite frame into Sphinx documentation.

Getting started
===============

.. code:: console

   pip install atsphinx-stlite

.. code:: python

   extensions = [
       ...,  # Your extensions
       "atsphinx.stlite",
   ]
