Test doc for atsphinx-stlite
============================

.. stlite::

   import streamlit as st

   st.title("Hello world")
