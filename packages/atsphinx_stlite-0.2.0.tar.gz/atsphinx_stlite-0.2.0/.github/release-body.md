Release atsphinx-stlite v0.2.0

- Changelog is https://github.com/atsphinx/stlite/blob/v0.2.0/CHANGES.rst
- Diff is https://github.com/atsphinx/stlite/compare/v0.1.0...v0.2.0/
