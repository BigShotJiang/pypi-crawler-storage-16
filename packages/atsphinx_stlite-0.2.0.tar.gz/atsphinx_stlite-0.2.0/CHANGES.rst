=================
Recent changelogs
=================

v0.2.0
======

:Date: 2025-12-12 (Asia/Tokyo)

Features
--------

* ``stlite`` directive is added new features:

  * argument accepts external python file to use as application.
  * ``config`` option to handle settings of Streamlit.
  * ``requirements`` option to declare python projects for applicaton dependencies.

v0.1.0
======

:Date: 2025-12-11 (Asia/Tokyo)

Features
--------

* Add ``stlite`` directive.
* Define ``stlite_default_version``.

v0.0.0
======

:date: 2025-12-09 (Asia/Tokyo)

Initial commit.
