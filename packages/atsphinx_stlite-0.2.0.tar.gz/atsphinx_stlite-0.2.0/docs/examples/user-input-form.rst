User input form
===============

.. raw:: html

   <style>
     .stlite-frame {
       height: 800px;
     }
   </style>

Code
----

.. code-block:: rst

   .. stlite:: ./user-input-form.py


.. literalinclude:: ./user-input-form.py
   :language: python
   :caption: ./user-input-form.py

Application
-----------

.. stlite:: ./user-input-form.py
