# noqa: D100

extensions = [
    "atsphinx.stlite",
]
