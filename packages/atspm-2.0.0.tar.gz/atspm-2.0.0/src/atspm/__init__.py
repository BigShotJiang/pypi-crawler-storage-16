__version__ = "2.0.0"

from .sample_data import sample_data
from .signal_data_processor import SignalDataProcessor
