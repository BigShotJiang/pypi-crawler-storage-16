"""Tests for delete_all_metadata functionality."""
