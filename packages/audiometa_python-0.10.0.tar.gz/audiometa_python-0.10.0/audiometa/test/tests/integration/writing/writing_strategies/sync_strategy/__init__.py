"""SYNC strategy tests organized by file extension."""
