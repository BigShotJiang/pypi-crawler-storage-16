"""Integration tests for ISRC metadata field."""
