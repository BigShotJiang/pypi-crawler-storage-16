audmetric.utils
===============

.. automodule:: audmetric.utils

.. autosummary::
    :toctree:
    :nosignatures:

    infer_labels
