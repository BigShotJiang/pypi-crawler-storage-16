Installation
============

To install :mod:`audmetric` run:

.. code-block:: bash

    $ # Create and activate Python virtual environment, e.g.
    $ # virtualenv --python=python3 ${HOME}/.envs/audmetric
    $ # source ${HOME}/.envs/audmetric/bin/activate
    $ pip install audmetric
