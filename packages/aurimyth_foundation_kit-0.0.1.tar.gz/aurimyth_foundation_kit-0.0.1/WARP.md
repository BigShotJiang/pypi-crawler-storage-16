# WARP.md

This file provides guidance to WARP (warp.dev) when working with code in this repository.

## Development environment & common commands

### Python and tooling
- Target Python version: **3.13+** (see `pyproject.toml`).
- Package backend: **hatchling** (no `setup.py`).
- Dependency managers supported:
  - Standard `pip` with extras.
  - [`uv`](https://github.com/astral-sh/uv`) with `uv.lock` and `[dependency-groups]`.

### Setting up a local dev environment

Using `pip` (works everywhere):
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -e ".[dev]"
```

Using `uv` (preferred if available):
```bash
uv sync --group dev
```

### Linting and static checks

Ruff is the primary linter (configured in `pyproject.toml`):
```bash
ruff check .
```

Type checking via mypy:
```bash
mypy aurimyth/
```

Keep both passing before publishing.

### Running tests

The project is configured to use `pytest` (see optional `dev` dependencies):

- Run the full test suite from the repo root:
  ```bash
  pytest
  ```

- Run a single test module or test case:
  ```bash
  pytest path/to/test_file.py::TestClass::test_case_name
  ```

When adding tests, follow the default `pytest` discovery conventions under a `tests/` package or `test_*.py` modules.

### Building the package

Build using `uv`:
```bash
uv build
```
Artifacts will appear under `dist/`.

### Version management

Versions are managed automatically via Git tags using `hatch-vcs`. The version is derived from:
- Git tags (e.g., `v0.1.0` → version `0.1.0`)
- Commit distance from tag (e.g., `v0.1.0` + 5 commits → `0.1.0.dev5+g<hash>`)
- Dirty state (uncommitted changes add `+dirty` suffix)

To release a new version:
```bash
git tag v0.2.0
git push --tags
./publish.sh
```

### Publishing (for maintainers)

A single publish script using `uv`:
```bash
./publish.sh          # Publish to production PyPI (default)
./publish.sh test     # Publish to test PyPI
./publish.sh --help   # Show help
```

Token configuration (one of):
- Environment variable: `export UV_PUBLISH_TOKEN='pypi-xxx'`
- keyring: `keyring set https://upload.pypi.org/legacy/ __token__`

### Framework CLI entry points (after installing the package)

Once `aurimyth-foundation-kit` is installed (editable or via PyPI), two main CLI tools are available:

- **Application server** (`aurimyth-server`): see `docs/SERVER_COMMANDS.md` for full details.
  - Development server with reload and debug:
    ```bash
    aurimyth-server dev
    ```
  - Production server (multi-process, good defaults):
    ```bash
    aurimyth-server prod
    ```
  - Fully customized run:
    ```bash
    aurimyth-server run --host 0.0.0.0 --port 8000 --workers 4 --reload
    ```

- **Migration tool** (`aurimyth-migrate`): entry point defined in `pyproject.toml`.
  - Typical workflow:
    ```bash
    aurimyth-migrate make -m "add user table"
    aurimyth-migrate up
    aurimyth-migrate status
    aurimyth-migrate down
    aurimyth-migrate show
    ```

## High-level architecture

The core library lives under `aurimyth/foundation_kit/` and follows a strict layered architecture. The most important high-level structure is:

- `aurimyth/foundation_kit/application/`
- `aurimyth/foundation_kit/domain/`
- `aurimyth/foundation_kit/infrastructure/`
- `aurimyth/foundation_kit/common/`
- `aurimyth/foundation_kit/commands/`
- `aurimyth/foundation_kit/testing/`
- `aurimyth/foundation_kit/toolkit/`

There is extensive end-user and architecture documentation under `docs/` and `docs/user_manual/docs/`.

### Layer responsibilities and dependency rules

The project’s **most important rule set** is captured in `.cursor/rules/aurimyth-foundation-kit-rule.mdc`. The key points for Warp are:

- There are four conceptual layers:
  - **application/** – app assembly (API, configuration, middleware, RPC, migrations, server bootstrap).
  - **domain/** – core business abstractions (models, repositories, services, transactions, pagination).
  - **infrastructure/** – concrete technical integrations (database, cache, message queues, scheduler, events, storage, DI container, monitoring).
  - **common/** – foundational utilities (exceptions, logging, i18n) with **no business or HTTP framework dependencies**.

- **Allowed dependencies** (one-way):
  - `application` → may depend on **all** other layers.
  - `domain` → may depend on `infrastructure` and `common`.
  - `infrastructure` → may depend on `common`.
  - `common` → must only depend on the standard library and generic third-party libs.

- **Forbidden dependencies**:
  - `common` must not reference `application`, `domain`, or `infrastructure`, and must not import FastAPI/Starlette or other HTTP frameworks.
  - `domain` must not depend on `application`.
  - `infrastructure` must not depend on `application` or (higher-level) domain application concerns.

When generating or editing code, **do not introduce imports that violate these directions**.

### Application layer (`application/`)

Focus: assembling an app, wiring configuration, middleware, components, RPC, and server/migration integration.

Key subpackages:

- `application/app/`
  - `base.py` – defines `FoundationApp` and the `Component` system used to assemble and manage all infrastructural pieces.
  - `components.py` – built-in components such as database, cache, task queue, scheduler, HTTP request logging, and the automatic migration component.

- `application/config/`
  - `settings.py` – Pydantic-based `BaseConfig` and typed settings objects (database, cache, server, service type, scheduler, etc.), mapping environment variables and `.env` into strongly-typed config used by the rest of the framework.

- `application/constants/`
  - Cross-cutting enums/identifiers (service type, scheduler mode, component names) that the application layer uses to orchestrate lower layers.

- `application/errors/` and `application/interfaces/`
  - HTTP-facing error types, response builders, and request/response models (ingress/egress) that wrap domain/infrastructure concerns into consistent API contracts.

- `application/middleware/`
  - HTTP middleware (e.g., request logging) that must stay at the application layer to keep `common` and `domain` decoupled from HTTP frameworks.

- `application/migrations/`
  - Migration manager wiring for application startup (automatic migrations via `MigrationComponent`).

- `application/rpc/`
  - RPC client abstractions and service discovery (`create_rpc_client`, client base classes) that use HTTPX to talk to other services.

- `application/scheduler/` and `application/server/`
  - Scheduler wiring for embedded/standalone modes.
  - Uvicorn-based `ApplicationServer` + `run_app` convenience functions, plus CLI-facing configuration shared with `aurimyth-server`.

When adding new application-level features, keep them expressed in terms of:
- `FoundationApp` + `Component` for lifecycle-managed infrastructure.
- `BaseConfig`-style configuration that adapts application config down to infrastructure managers.

### Domain layer (`domain/`)

Focus: pure business domain concepts built on top of a chosen ORM (currently SQLAlchemy), repository pattern, services, and transaction semantics.

Key subpackages:

- `domain/models/`
  - `base.py`, `models.py`, `mixins.py` – base ORM models, GUID type, common mixins (timestamps, soft delete, etc.).

- `domain/repository/`
  - `interface.py` – repository interfaces (`IRepository[...]`, query abstractions).
  - `impl.py` – generic `BaseRepository` implementation (CRUD, pagination, soft delete, bulk operations).
  - `query_builder.py`, `interceptors.py` – higher-level query composition and interception hooks.

- `domain/service/`
  - `base.py` – service base classes composed out of repositories and domain models.

- `domain/transaction/`
  - Transaction decorators and helpers (including `requires_transaction`) that now live firmly in the domain layer after refactors noted in `LATEST_UPDATES.md`.

- `domain/pagination/`
  - Shared pagination value objects/params used both by repositories and HTTP interfaces.

In new domain code, prefer:
- Expressing business operations in services that depend on repositories instead of on raw sessions.
- Using `PaginationParams` and repository helpers instead of ad-hoc pagination logic.

### Infrastructure layer (`infrastructure/`)

Focus: concrete technical implementations – database engines, caching backends, scheduler, task system, events, storage, DI, monitoring, etc. These are **implementation details** behind domain/application abstractions.

Key subpackages (non-exhaustive, but important for orientation):

- `infrastructure/database/`
  - `config.py`, `manager.py`, `exceptions.py` – central `DatabaseManager`, connection pooling, session factories, and DB-specific error types.
  - Houses upsert strategies and query tools (moved from older `infrastructure/repository/` paths – see `LATEST_UPDATES.md`).

- `infrastructure/cache/`
  - Unified `CacheManager`, backend selection (memory vs Redis, etc.), decorators for cached functions.

- `infrastructure/tasks/`
  - `TaskManager` + `conditional_task` decorator implementing the dual-mode task queue:
    - API mode: functions act as lightweight producers.
    - Worker mode: same functions are registered as Dramatiq actors.

- `infrastructure/events/`
  - `EventBus` with local and distributed (Kombu-based) event delivery, event models, and middleware.

- `infrastructure/scheduler/`
  - `SchedulerManager` wrapping APScheduler with framework-friendly configuration.

- `infrastructure/storage/`
  - Storage abstractions and concrete S3/local implementations.

- `infrastructure/di/`
  - Lightweight IoC container used where FastAPI’s DI is insufficient or transport-agnostic DI is required.

- `infrastructure/monitoring/`
  - Reserved for observability features (health checks, metrics, tracing hooks). Some of this is currently implemented via logging and will likely expand.

New infrastructure code should:
- Expose managers/factories with clear configuration objects.
- Avoid importing application- or HTTP-specific concepts.

### Common layer (`common/`)

Focus: foundational utilities shared by all layers and completely decoupled from HTTP frameworks and application-specific concerns.

- `common/exceptions/`
  - `FoundationError` is the root of the exception hierarchy. All layer-specific exception types should ultimately derive from this, optionally via intermediate layer-specific base classes.

- `common/logging/`
  - Advanced logging setup utilities used across the framework and documented in `docs/LOGGING_AND_TRACING.md` and the user guide.
  - Provides trace ID propagation helpers and performance/exception decorators used by higher layers.

- `common/i18n/`
  - Translator and helper functions for internationalization; can be used by any layer that needs localized messages without tying to HTTP.

Do **not** introduce FastAPI, Starlette, or other HTTP-related imports here.

### Commands, testing, and toolkit

- `commands/`
  - `migrate/` – Typer-based CLI app implementing `aurimyth-migrate`.
  - `server/` – Typer-based CLI app implementing `aurimyth-server` (dev/prod/run commands).

- `testing/`
  - Reusable testing utilities the framework exposes to applications: `TestCase`, `TestClient`, `Factory`, and related helpers to standardize async tests and DB rollbacks across services.

- `toolkit/http/`
  - Transport-agnostic HTTP utilities (e.g., shared HTTP client helpers) that don’t belong directly to a specific service or layer.

## Project-specific conventions Warp should respect

- **No backward compatibility layer**: the project explicitly prefers clean refactors over maintaining deprecated paths. When editing code, it is acceptable (and often preferred) to remove obsolete APIs rather than keep shims.

- **Constants and configuration**:
  - Application layer owns global enums/identifiers like component names and service types.
  - Infrastructure components define their own internal constants and must not depend on application-layer constant definitions.

- **Exception hierarchy**:
  - All new framework exceptions should ultimately inherit from `FoundationError` (via appropriate layer-specific base types).
  - Name exceptions with an `Error` suffix (e.g., `DatabaseError`, `TransactionRequiredError`).

- **HTTP placement**:
  - All HTTP-specific code (routers, middleware, HTTP error representations) must stay in the `application` layer or in user applications built on top of this kit.
  - `common` and `domain` must remain free of HTTP framework dependencies.

- **Typing and style**:
  - Use modern Python 3.13 type syntax (`list[str]`, `str | None`, etc.).
  - Match the Ruff configuration in `pyproject.toml` (e.g., import ordering, complexity limits, and per-file ignores).

## Documentation to consult before large changes

For non-trivial refactors or new features, Warp should skim these documents first:

- `docs/ARCHITECTURE.md` – primary high-level architecture description (layers, responsibilities, and key patterns).
- `docs/USER_GUIDE.md` – end-user developer guide covering configuration, components, HTTP APIs, tasks, events, scheduler, RPC, WebSocket, storage, i18n, and migration.
- `IMPLEMENTATION_SUMMARY.md` – summary of recent major implementations (server CLI, automatic migrations, Django comparison docs) and where the relevant code lives.
- `LATEST_UPDATES.md` – notes on the latest refactors (e.g., moving transaction helpers to `domain/transaction`, restructuring database tooling).
- `FOUNDATION_KIT_MISSING_FEATURES.md` – analysis of feature gaps versus other frameworks; useful to understand intended roadmap and priorities.

When in doubt about where a new feature belongs, prefer to:
1. Re-check the layering rules and architecture docs.
2. Place new code in the **lowest reasonable layer** that avoids leaking higher-level concerns.
3. Keep infrastructure details behind managers/components that are wired in the application layer.
