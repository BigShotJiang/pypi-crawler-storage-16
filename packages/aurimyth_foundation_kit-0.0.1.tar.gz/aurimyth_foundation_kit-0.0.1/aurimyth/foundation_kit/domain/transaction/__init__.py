"""数据库事务管理工具。

提供多种事务管理方式：
1. @transactional - 通用装饰器，自动从参数中获取session
2. @requires_transaction - Repository 事务检查装饰器
3. transactional_context - 上下文管理器
4. TransactionManager - 手动控制事务
"""

from collections.abc import AsyncGenerator, Callable
from contextlib import asynccontextmanager

# 用于跟踪嵌套事务的上下文变量
import contextvars
from functools import wraps
from inspect import signature

from sqlalchemy.ext.asyncio import AsyncSession

from aurimyth.foundation_kit.common.logging import logger
from aurimyth.foundation_kit.domain.exceptions import TransactionRequiredError

_transaction_depth: contextvars.ContextVar[int] = contextvars.ContextVar("transaction_depth", default=0)


@asynccontextmanager
async def transactional_context(session: AsyncSession, auto_commit: bool = True) -> AsyncGenerator[AsyncSession]:
    """
    事务上下文管理器，自动处理提交和回滚。
    
    Args:
        session: 数据库会话
        auto_commit: 是否自动提交（默认True）
    
    特性:
        - 支持嵌套调用：只有最外层会 commit/rollback
        - 兼容 SQLAlchemy 2.0 autobegin 模式
    
    用法:
        async with transactional_context(session):
            await repo1.create(...)
            await repo2.update(...)
            # 成功自动提交，异常自动回滚
    """
    # 使用 contextvars 跟踪嵌套深度，避免依赖 in_transaction()
    depth = _transaction_depth.get()
    is_outermost = depth == 0
    _transaction_depth.set(depth + 1)
    
    try:
        yield session
        # 只有最外层且 auto_commit=True 时才提交
        if auto_commit and is_outermost:
            await session.commit()
            logger.debug("事务提交成功")
    except Exception as exc:
        # 只有最外层才回滚
        if is_outermost:
            await session.rollback()
            logger.error(f"事务回滚: {exc}")
        raise
    finally:
        _transaction_depth.set(depth)


def transactional[T](func: Callable[..., T]) -> Callable[..., T]:
    """
    通用事务装饰器，自动从函数参数中查找session并管理事务。
    
    支持多种用法：
    1. 参数名为 session 的函数
    2. 参数名为 db 的函数
    3. 类方法中有 self.session 属性
    
    特性：
    - 自动识别session参数
    - 成功时自动提交
    - 异常时自动回滚
    - 支持嵌套（内层事务不会重复提交）
    
    用法示例:
        @transactional
        async def create_user(session: AsyncSession, name: str):
            # 操作会在事务中执行
            user = User(name=name)
            session.add(user)
            await session.flush()
            return user
        
        # 或者在类方法中
        class UserService:
            def __init__(self, session: AsyncSession):
                self.session = session
            
            @transactional
            async def create_with_profile(self, name: str):
                # 自动使用 self.session
                user = await self.create_user(name)
                profile = await self.create_profile(user.id)
                return user, profile
    """

    @wraps(func)
    async def wrapper(*args, **kwargs):
        session: AsyncSession | None = None
        
        # 策略1: 从kwargs中获取session或db
        if "session" in kwargs:
            session = kwargs["session"]
        elif "db" in kwargs:
            session = kwargs["db"]
        else:
            # 策略2: 从args中获取 (检查类型注解)
            sig = signature(func)
            params = list(sig.parameters.keys())
            
            for i, param_name in enumerate(params):
                if i < len(args):
                    param_value = args[i]
                    # 检查是否是AsyncSession类型
                    if isinstance(param_value, AsyncSession):
                        session = param_value
                        break
                    # 检查参数名
                    if param_name in ("session", "db"):
                        session = param_value
                        break
            
            # 策略3: 从self.session获取 (类方法)
            if session is None and args and hasattr(args[0], "session"):
                session = args[0].session

        if session is None:
            raise ValueError(
                f"无法找到session参数。请确保函数 {func.__name__} 有一个名为 'session' 或 'db' 的参数，"
                "或者类有 'session' 属性。"
            )

        # 使用事务上下文管理器，它会自动处理嵌套情况
        logger.debug(f"执行事务 {func.__name__}")
        async with transactional_context(session):
            return await func(*args, **kwargs)

    return wrapper


class TransactionManager:
    """
    事务管理器，提供更细粒度的事务控制。
    
    用法:
        tm = TransactionManager(session)
        
        await tm.begin()
        try:
            await repo1.create(data)
            await repo2.update(data)
            await tm.commit()
        except Exception:
            await tm.rollback()
            raise
    """
    
    def __init__(self, session: AsyncSession):
        self.session = session
        self._transaction = None
    
    async def begin(self):
        """开始事务。"""
        if self._transaction is None:
            self._transaction = await self.session.begin()
            logger.debug("手动开启事务")
    
    async def commit(self):
        """提交事务。"""
        if self._transaction:
            await self.session.commit()
            self._transaction = None
            logger.debug("手动提交事务")
    
    async def rollback(self):
        """回滚事务。"""
        if self._transaction:
            await self.session.rollback()
            self._transaction = None
            logger.debug("手动回滚事务")
    
    async def __aenter__(self):
        await self.begin()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if exc_type is None:
            await self.commit()
        else:
            await self.rollback()


def ensure_transaction(session: AsyncSession) -> bool:
    """
    检查当前会话是否在事务中。
    
    用于在Repository中进行安全检查。
    """
    return session.in_transaction()


def requires_transaction(func: Callable) -> Callable:
    """事务必需装饰器。
    
    确保方法在事务中执行，如果不在事务中则抛出 TransactionRequiredError。
    
    用于 Repository 方法，强制要求在事务中调用。
    
    用法:
        class UserRepository(BaseRepository):
            @requires_transaction
            async def update_user(self, user, data):
                # 此方法必须在事务中执行
                return await self.update(user, data)
    """
    
    @wraps(func)
    async def wrapper(self, *args, **kwargs):
        if not self._session.in_transaction():
            raise TransactionRequiredError(
                f"方法 {func.__name__} 需要在事务中执行，但当前会话不在事务中"
            )
        return await func(self, *args, **kwargs)
    
    return wrapper


__all__ = [
    "TransactionManager",
    "TransactionRequiredError",
    "ensure_transaction",
    "requires_transaction",
    "transactional",
    "transactional_context",
]

