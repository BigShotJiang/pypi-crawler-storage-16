# AuriMyth Foundation Kit - AI 助手使用指南

本文档为 AI 助手（如 Cursor、Copilot、Claude）提供项目使用参考。

## 快速开始

### 创建新项目

```bash
# 1. 创建项目目录
mkdir my-service && cd my-service

# 2. 初始化 uv 项目
uv init . --name my_service --no-package --python 3.13

# 3. 安装 aurimyth-foundation-kit
uv add "aurimyth-foundation-kit[recommended]"

# 4. 初始化脚手架
aum init                         # 交互式模式（默认）

# 5. 安装开发依赖
uv sync --group dev

# 6. 配置环境变量
cp .env.example .env
# 编辑 .env 配置数据库等

# 7. 启动开发服务器
aum server dev
```

其他 init 选项：
```bash
aum init -y                      # 跳过交互，纯默认配置
aum init my_package              # 顶层包结构
aum init --docker                # 同时生成 Docker 配置
```

> **注意**：`init` 会覆盖 `uv init` 创建的默认 `main.py`，这是正常行为。

## CLI 命令参考

### 项目初始化

```bash
# 前置步骤（必须先执行）
uv init . --name my_service --no-package --python 3.13
uv add "aurimyth-foundation-kit[recommended]"

# 初始化脚手架
aum init                         # 交互式模式（默认，推荐）
aum init -y                      # 跳过交互，纯默认配置
aum init my_package              # 使用顶层包结构
aum init -f                      # 强制覆盖已存在的文件
aum init --docker                # 同时生成 Docker 配置
```

**交互式模式（默认）** 会询问：
- 项目结构（平铺 vs 顶层包）
- 数据库类型（PostgreSQL/MySQL/SQLite）
- 缓存类型（内存/Redis）
- 服务模式（API/API+调度器/完整）
- 可选功能（存储/事件/i18n）
- 开发工具
- Docker 配置

### 代码生成

```bash
aum generate crud <name>     # 生成完整 CRUD（model+repo+service+api+schema）
aum generate model <name>    # 生成模型
aum generate repo <name>     # 生成仓库
aum generate service <name>  # 生成服务
aum generate api <name>      # 生成 API 路由
aum generate schema <name>   # 生成 Pydantic 模式
```

### 数据库迁移

```bash
aum migrate make -m "description"  # 创建迁移
aum migrate up                     # 执行迁移
aum migrate down                   # 回滚迁移
aum migrate status                 # 查看状态
aum migrate show                   # 显示迁移历史
```

### 服务器管理

```bash
aum server dev              # 开发模式（热重载）
aum server prod             # 生产模式（多进程）
aum server run --port 9000  # 自定义端口
```

### 调度器和 Worker

```bash
aum scheduler               # 独立运行调度器
aum worker                  # 运行任务队列 Worker
aum worker -c 8             # 8 个并发
aum worker -q high,default  # 指定队列
```

### Docker 配置

```bash
aum docker init             # 生成 Docker 配置
aum docker init -f          # 强制覆盖
```

## 项目结构

### 平铺结构

```
my-service/
├── main.py              # 应用入口
├── config.py            # 配置定义
├── api/                 # API 路由
├── services/            # 业务逻辑
├── models/              # SQLAlchemy 模型
├── repositories/        # 数据访问层
├── schemas/             # Pydantic 模型
├── migrations/          # 数据库迁移
├── tests/               # 测试
├── .env.example         # 环境变量示例
├── alembic.ini          # Alembic 配置
└── pyproject.toml       # 项目配置
```

### 顶层包结构（推荐大型项目）

```
my-service/
├── my_package/          # 顶层包
│   ├── main.py
│   ├── config.py
│   ├── api/
│   ├── services/
│   ├── models/
│   ├── repositories/
│   ├── schemas/
│   └── tests/
├── migrations/
├── .env.example
├── alembic.ini
└── pyproject.toml
```

## 核心概念

### 应用入口 (main.py)

```python
from aurimyth.foundation_kit.application.app.base import FoundationApp
from aurimyth.foundation_kit.application.app.components import (
    DatabaseComponent,
    CacheComponent,
    MigrationComponent,
)

from config import AppConfig

config = AppConfig()

app = FoundationApp(
    title="My Service",
    version="0.1.0",
    config=config,
)

# 注册组件
app.register_component(DatabaseComponent)
app.register_component(CacheComponent)
app.register_component(MigrationComponent)  # 启动时自动迁移

# 注册路由
from api import users
app.include_router(users.router, prefix="/api/users", tags=["Users"])
```

### 配置 (config.py)

```python
from aurimyth.foundation_kit.application.config import BaseConfig

class AppConfig(BaseConfig):
    """继承 BaseConfig 获得所有默认配置项。"""
    
    # 添加自定义配置
    # my_setting: str = Field(default="value")
    pass
```

### 模型 (models/)

```python
from aurimyth.foundation_kit.domain.models import Base, GUIDMixin, TimestampMixin
from sqlalchemy import String
from sqlalchemy.orm import Mapped, mapped_column

class User(Base, GUIDMixin, TimestampMixin):
    __tablename__ = "users"
    
    username: Mapped[str] = mapped_column(String(50), unique=True)
    email: Mapped[str] = mapped_column(String(100), unique=True)
```

### 仓库 (repositories/)

```python
from aurimyth.foundation_kit.domain.repository import BaseRepository
from models.user import User

class UserRepository(BaseRepository[User]):
    model = User
```

### 服务 (services/)

```python
from aurimyth.foundation_kit.domain.service import BaseService
from repositories.user import UserRepository
from models.user import User

class UserService(BaseService[User, UserRepository]):
    repository_class = UserRepository
```

### API 路由 (api/)

```python
from fastapi import APIRouter, Depends
from aurimyth.foundation_kit.application.interfaces.egress import BaseResponse
from services.user import UserService
from schemas.user import UserCreate, UserResponse

router = APIRouter()

@router.post("/", response_model=BaseResponse[UserResponse])
async def create_user(
    data: UserCreate,
    service: UserService = Depends(),
) -> BaseResponse[UserResponse]:
    user = await service.create(data.model_dump())
    return BaseResponse(code=200, message="Created", data=UserResponse.model_validate(user))
```

## 环境变量

常用环境变量（在 `.env` 中配置）：

```bash
# 服务配置
SERVICE_NAME=my-service
SERVICE_TYPE=api  # api, worker

# 服务器
SERVER_HOST=127.0.0.1
SERVER_PORT=8000
SERVER_WORKERS=1
SERVER_RELOAD=true

# 数据库
DATABASE_URL=postgresql+asyncpg://user:pass@localhost:5432/mydb

# 缓存
CACHE_TYPE=memory  # memory, redis
CACHE_REDIS_URL=redis://localhost:6379/0

# 任务队列
TASK_ENABLED=false
TASK_BROKER_URL=redis://localhost:6379/1

# 调度器（内嵌在 API 服务中）
SCHEDULER_ENABLED=true  # 默认 true，设为 false 可禁用

# 日志
LOG_LEVEL=INFO
LOG_DIR=logs
```

**服务运行模式说明**：

- `SERVICE_TYPE=api` + `SCHEDULER_ENABLED=true`（默认）：API 服务 + 内嵌调度器
- `SERVICE_TYPE=api` + `SCHEDULER_ENABLED=false`：纯 API 服务
- `aum scheduler`：独立调度器进程（无需配置）
- `aum worker`：独立 Worker 进程（无需配置）

## 可选依赖

根据需要安装对应的 extras：

```bash
# 推荐（包含常用功能）
uv add "aurimyth-foundation-kit[recommended]"

# 单独安装
uv add "aurimyth-foundation-kit[postgresql]"  # PostgreSQL
uv add "aurimyth-foundation-kit[mysql]"       # MySQL
uv add "aurimyth-foundation-kit[redis]"       # Redis 缓存
uv add "aurimyth-foundation-kit[tasks]"       # 异步任务 (Dramatiq)
uv add "aurimyth-foundation-kit[scheduler]"   # 定时任务 (APScheduler)
uv add "aurimyth-foundation-kit[events]"      # 事件总线
uv add "aurimyth-foundation-kit[storage]"     # 对象存储 (S3)
uv add "aurimyth-foundation-kit[i18n]"        # 国际化
uv add "aurimyth-foundation-kit[dev]"         # 开发工具

# 组合
uv add "aurimyth-foundation-kit[postgresql,redis,dev]"
```

## Docker 部署

生成的 `docker-compose.yml` 包含以下服务：

- `api` - API 服务
- `scheduler` - 定时任务服务
- `worker` - 异步任务工作者
- `postgres` - PostgreSQL 数据库
- `redis` - Redis 缓存/队列

```bash
# 启动所有服务
docker-compose up -d

# 只启动 API
docker-compose up -d api

# 查看日志
docker-compose logs -f api

# 停止服务
docker-compose down
```

## 常见问题

### Q: 如何添加新的 API 端点？

1. 在 `api/` 目录创建新文件
2. 定义路由和处理函数
3. 在 `main.py` 中注册路由

### Q: 如何添加数据库模型？

1. 在 `models/` 目录创建模型文件
2. 运行 `aum migrate make -m "add xxx table"`
3. 运行 `aum migrate up`

### Q: 如何使用缓存？

```python
from aurimyth.foundation_kit.infrastructure.cache import CacheManager

cache = CacheManager.get_instance()
await cache.set("key", "value", ttl=3600)
value = await cache.get("key")
```

### Q: 如何添加定时任务？

```python
from aurimyth.foundation_kit.infrastructure.scheduler import SchedulerManager

scheduler = SchedulerManager.get_instance()

@scheduler.scheduled_job('interval', seconds=60)
async def my_task():
    print("Running every 60 seconds")
```

### Q: 如何使用事件总线？

```python
from aurimyth.foundation_kit.infrastructure.events import EventBus

bus = EventBus.get_instance()

# 发布事件
await bus.publish("user.created", {"user_id": 123})

# 订阅事件
@bus.subscribe("user.created")
async def on_user_created(event):
    print(f"User created: {event.data}")
```
