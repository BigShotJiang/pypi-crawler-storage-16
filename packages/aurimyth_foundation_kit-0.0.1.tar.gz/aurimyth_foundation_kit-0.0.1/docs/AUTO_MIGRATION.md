# 自动数据库迁移组件

AuriMyth Foundation Kit 提供 `MigrationComponent`，能够在应用启动时自动执行数据库迁移。

---

## 📌 功能特性

✅ **自动执行迁移**
- 应用启动时自动检查待处理迁移
- 自动升级数据库到最新版本

✅ **智能依赖管理**
- `MigrationComponent` 依赖 `DatabaseComponent`
- 确保在数据库初始化之后执行迁移

✅ **详细日志输出**
- 显示已执行和待执行迁移数量
- 提供迁移执行进度信息

✅ **灵活配置**
- 可以启用/禁用自动迁移
- 支持自定义 Alembic 配置路径

---

## 🚀 快速开始

### 基本使用

默认情况下，`MigrationComponent` 已包含在应用启动流程中：

```python
from aurimyth.foundation_kit.application import FoundationApp

app = FoundationApp()

# 当应用启动时，MigrationComponent 会自动：
# 1. 检查数据库迁移状态
# 2. 执行待处理的迁移
# 3. 将数据库升级到最新版本

if __name__ == "__main__":
    # 使用 aurimyth-server 或任何 ASGI 服务器
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
```

### 禁用自动迁移

如果想禁用自动迁移（例如在生产环境中手动管理迁移）：

```python
from aurimyth.foundation_kit.application import FoundationApp
from aurimyth.foundation_kit.application.app.components import MigrationComponent

app = FoundationApp()

# 禁用迁移组件
app.remove_component("migration")

# 或者单独禁用
for component in app.items:
    if component.name == "migration":
        component.enabled = False
        break
```

---

## 📊 启动输出示例

当应用启动时，你将看到类似的日志输出：

### 场景 1：需要执行迁移

```
🔄 检查数据库迁移...
📊 数据库迁移状态：
   已执行: 5 个迁移
   待执行: 2 个迁移
⏳ 执行数据库迁移...
✅ 数据库迁移完成
```

### 场景 2：数据库已是最新版本

```
🔄 检查数据库迁移...
✅ 数据库已是最新版本，无需迁移
```

### 场景 3：迁移失败

```
🔄 检查数据库迁移...
📊 数据库迁移状态：
   已执行: 5 个迁移
   待执行: 2 个迁移
⏳ 执行数据库迁移...
❌ 数据库迁移失败: [错误信息]
```

---

## 🔧 组件详解

### 组件属性

| 属性 | 值 | 说明 |
|------|-----|------|
| `name` | `"migration"` | 组件名称 |
| `enabled` | `True` | 默认启用 |
| `depends_on` | `[ComponentName.DATABASE]` | 依赖数据库组件 |

### 启用条件

`MigrationComponent` 只有在以下条件满足时才会启用：

1. ✅ 组件 `enabled` 为 `True`
2. ✅ 配置中设置了 `database.url`

### 执行流程

1. **检查迁移状态**
   ```python
   status = await migration_manager.status()
   pending = status.get("pending", [])
   applied = status.get("applied", [])
   ```

2. **如果有待处理迁移**
   ```python
   await migration_manager.upgrade(revision="head")
   ```

3. **记录执行结果**
   - 成功：显示 `✅ 数据库迁移完成`
   - 失败：记录错误并抛出异常

---

## 💡 最佳实践

### ✅ 推荐做法

1. **开发环境**
   ```python
   # 启用自动迁移，快速开发
   app = FoundationApp()
   # MigrationComponent 自动启用
   ```

2. **测试环境**
   ```python
   # 启用自动迁移，确保数据库最新
   app = FoundationApp()
   # MigrationComponent 自动启用
   ```

3. **生产环境**
   ```python
   # 可选：在部署前手动执行迁移
   # aurimyth-migrate up
   
   # 然后启动应用（如果配置了自动迁移）
   app = FoundationApp()
   ```

### ❌ 避免做法

1. **不要禁用后又忘记手动迁移**
   ```python
   # ❌ 不推荐
   app.remove_component("migration")
   # ... 忘记手动执行迁移
   ```

2. **不要在多个实例上同时启用自动迁移**
   ```python
   # ❌ 可能导致竞态条件
   # 应该在主实例上启用，其他实例禁用
   ```

---

## 🔄 迁移工作流程

### 完整的数据库初始化流程

```
应用启动
  ↓
RequestLoggingComponent ✓
  ↓
CORSComponent ✓
  ↓
DatabaseComponent (初始化数据库连接)
  ↓
MigrationComponent (执行迁移) ← ⭐ 新
  ↓
CacheComponent
  ↓
TaskComponent
  ↓
SchedulerComponent
  ↓
应用就绪
```

### 关键点

1. **DatabaseComponent 必须在 MigrationComponent 之前启动**
   - 数据库连接必须就绪才能执行迁移

2. **迁移是阻塞操作**
   - 如果有待处理迁移，应用会等待迁移完成
   - 这确保了应用启动时数据库已是最新版本

3. **迁移失败会导致应用启动失败**
   - 这是故意的，防止在不一致的数据库上运行

---

## 📋 配置示例

### 基本配置

```python
# config/settings.py
from aurimyth.foundation_kit.application.config import BaseConfig, DatabaseSettings

class ApplicationSettings(BaseConfig):
    database: DatabaseSettings = DatabaseSettings(
        url="postgresql://user:pass@localhost/mydb",
        echo=False,  # 不输出 SQL 日志
    )
```

### 环境变量

```bash
# .env
DATABASE_URL=postgresql://user:pass@localhost/mydb
```

---

## 🎯 常见场景

### 场景 1：本地开发

**需求**：在每次启动时自动更新数据库

**配置**：
```python
# main.py
from aurimyth.foundation_kit.application import FoundationApp

app = FoundationApp()

# 直接启动，MigrationComponent 会自动执行迁移
```

**启动方式**：
```bash
aurimyth-server dev
# 或
python -c "from main import app; import uvicorn; uvicorn.run(app)"
```

### 场景 2：Docker 容器

**需求**：容器启动时自动执行迁移

**Dockerfile**：
```dockerfile
FROM python:3.13

WORKDIR /app
COPY . .
RUN pip install -e .

# MigrationComponent 会在应用启动时自动执行
CMD ["aurimyth-server", "prod"]
```

**或使用入口脚本**：
```dockerfile
COPY entrypoint.sh /app/entrypoint.sh
RUN chmod +x /app/entrypoint.sh
CMD ["/app/entrypoint.sh"]
```

```bash
# entrypoint.sh
#!/bin/bash

# 应用启动，MigrationComponent 自动执行迁移
exec aurimyth-server prod --workers 4
```

### 场景 3：Kubernetes 部署

**需求**：在主副本上执行迁移，其他副本等待

**配置**：
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: api-service
spec:
  replicas: 3
  template:
    spec:
      containers:
      - name: api
        image: myapp:latest
        env:
        - name: ENABLE_AUTO_MIGRATION
          value: "true"  # 所有实例都启用
        # 或者使用 initContainer 执行迁移
```

**或使用 initContainer 方式**：
```yaml
spec:
  initContainers:
  - name: migrate
    image: myapp:latest
    command:
    - /bin/sh
    - -c
    - aurimyth-migrate up
  containers:
  - name: api
    image: myapp:latest
```

---

## 🐛 故障排除

### 问题 1：迁移超时

**症状**：应用启动时卡住，最终超时

**原因**：
- 迁移涉及的操作很耗时（例如大数据表的索引重建）
- 数据库连接问题

**解决方案**：
```python
# 增加数据库连接超时时间
class ApplicationSettings(BaseConfig):
    database: DatabaseSettings = DatabaseSettings(
        url="postgresql://...",
        pool_timeout=60,  # 增加到 60 秒
    )
```

### 问题 2：迁移失败，应用无法启动

**症状**：应用启动失败，显示迁移错误

**原因**：
- Alembic 配置不正确
- 迁移脚本有错误
- 数据库权限不足

**解决方案**：

1. 首先禁用自动迁移，手动调试
   ```python
   app.remove_component("migration")
   ```

2. 手动执行迁移，查看详细错误
   ```bash
   aurimyth-migrate up --verbose
   ```

3. 修复迁移问题后，重新启用

### 问题 3：数据库被锁定

**症状**：迁移失败，显示"数据库被锁定"

**原因**：
- 另一个进程正在执行迁移
- 前一次迁移没有正确完成

**解决方案**：

1. 检查是否有其他实例在运行
   ```bash
   # 检查 Kubernetes Pod
   kubectl get pods
   kubectl logs <pod-name>
   ```

2. 手动解除锁定（小心使用）
   ```python
   # 仅在必要时
   migration_manager = MigrationManager()
   await migration_manager.stamp(revision="head")
   ```

---

## 📚 相关资源

- [数据库迁移指南](./USER_GUIDE.md#数据库迁移)
- [MigrationManager API](./USER_GUIDE.md#迁移管理器)
- [服务器启动命令](./SERVER_COMMANDS.md)
- [Alembic 官方文档](https://alembic.sqlalchemy.org/)

---

## 📝 总结

`MigrationComponent` 提供：

1. ✅ **自动迁移** - 应用启动时自动执行
2. ✅ **智能依赖** - 确保执行顺序正确
3. ✅ **详细日志** - 清晰的执行反馈
4. ✅ **错误处理** - 迁移失败会导致应用启动失败

**推荐在所有环境使用**，特别是：
- 🐳 Docker 容器部署
- ☸️ Kubernetes 编排
- 🔄 CI/CD 流程

通过自动迁移，确保应用启动时数据库始终处于最新状态，简化部署流程，减少人为错误。















