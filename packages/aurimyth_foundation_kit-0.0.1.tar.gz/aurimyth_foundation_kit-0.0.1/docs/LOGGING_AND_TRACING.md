# 日志系统与分布式链路追踪完整指南

## 📋 目录

1. [概述](#概述)
2. [日志系统配置](#日志系统配置)
3. [文件分类与管理](#文件分类与管理)
4. [链路追踪](#链路追踪)
5. [RPC 集成追踪](#rpc-集成追踪)
6. [性能监控](#性能监控)
7. [常见问题](#常见问题)

---

## 概述

框架提供了企业级的日志系统，包含：

✅ **多级别日志** - DEBUG, INFO, WARNING, ERROR, CRITICAL  
✅ **文件分类** - 按模块自动分离日志  
✅ **滚动机制** - 按时间或大小自动轮转  
✅ **链路追踪** - 分布式系统中追踪请求  
✅ **性能监控** - 自动记录执行时间  
✅ **异步写入** - 不阻塞业务流程

---

## 日志系统配置

### 基础配置

```python
from aurimyth.foundation_kit.common.logging import setup_logging

# 在应用启动时调用
setup_logging(
    log_level="INFO",              # 日志级别
    log_dir="log",                 # 日志目录
    enable_file_rotation=True,     # 启用文件轮转
    rotation_time="00:00",         # 每天午夜轮转
    retention_days=7,              # 保留 7 天
    enable_classify=True,          # 按模块分类
    enable_console=True,           # 输出到控制台
    enable_error_file=True,        # 单独保存错误
)
```

### 配置参数详解

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `log_level` | str | "INFO" | DEBUG/INFO/WARNING/ERROR/CRITICAL |
| `log_dir` | str | "log" | 日志文件存储目录 |
| `enable_file_rotation` | bool | True | 是否启用每日轮转 |
| `rotation_time` | str | "00:00" | 轮转时间（HH:MM 格式） |
| `rotation_size` | str | "100 MB" | 基于大小的轮转阈值 |
| `retention_days` | int | 7 | 日志保留天数 |
| `enable_classify` | bool | True | 是否按模块分类存储 |
| `enable_console` | bool | True | 是否输出到控制台 |
| `enable_error_file` | bool | True | 是否单独记录错误 |

### 环境变量配置

通过 `.env` 文件配置：

```bash
# 日志配置
LOG_LEVEL=INFO
LOG_FILE=log/app.log
LOG_ROTATION_TIME=00:00
LOG_RETENTION_DAYS=7
LOG_CLASSIFY=true
```

---

## 文件分类与管理

### 自动分类

日志会自动按**日期**、**级别**和**模块**多维度分离。所有日志都会写入多个文件中：

```
log/
├── 通用日志文件
│   └── app_2024-01-15.log           ✅ 所有日志都写入这里
│
├── 按级别分类（同时写入）
│   ├── debug_2024-01-15.log         ✅ DEBUG 级别 + 所有日志
│   ├── info_2024-01-15.log          ✅ INFO 级别 + 所有日志
│   ├── warning_2024-01-15.log       ✅ WARNING 级别 + 所有日志
│   └── error_2024-01-15.log         ✅ ERROR 级别 + 所有日志
│
├── 按模块分类（enable_classify=True 时）
│   ├── database_2024-01-15.log      ✅ 数据库操作 + 所有日志
│   ├── cache_2024-01-15.log         ✅ 缓存操作 + 所有日志
│   ├── rpc_2024-01-15.log           ✅ RPC 调用 + 所有日志
│   └── http_2024-01-15.log          ✅ HTTP 请求 + 所有日志
```

**多维度写入机制**：
- 每条日志同时写入 `app_*.log`（主文件）
- 同时写入对应级别的文件（快速定位）
- 同时写入对应模块的文件（深度分析）
- 按日期自动轮转，按 retention_days 自动清理

### 各类日志说明

**按级别分类**（每条日志同时写入 `app_*.log`）：

| 日志级别 | 文件名 | 记录内容 | 用途 | 写入位置 |
|---------|--------|--------|------|---------|
| DEBUG | `debug_2024-01-15.log` | 详细信息（方法调用、参数等） | 深度调试 | app_* + debug_* |
| INFO | `info_2024-01-15.log` | 重要信息（启动、完成、状态） | 系统监控 | app_* + info_* |
| WARNING | `warning_2024-01-15.log` | 警告信息（异常情况、过期功能） | 告警提示 | app_* + warning_* |
| ERROR | `error_2024-01-15.log` | 错误信息（异常、失败） | 故障处理 | app_* + error_* |

**按模块分类**（启用 `enable_classify=True` 时，每条日志同时写入 `app_*.log`）：

| 日志类型 | 记录内容 | 用途 | 写入位置 |
|---------|--------|------|---------|
| `database_*.log` | 数据库查询、事务、连接 | 性能调优 | app_* + database_* |
| `cache_*.log` | 缓存命中、失效、TTL | 缓存分析 | app_* + cache_* |
| `rpc_*.log` | 远程调用、重试、链路 | 服务间通信 | app_* + rpc_* |
| `http_*.log` | HTTP 请求/响应、链路 | 接口追踪 | app_* + http_* |

**示例**：
```python
logger.error("数据库连接失败")
# 写入到：app_2024-01-15.log, error_2024-01-15.log, database_2024-01-15.log
# 完整链路追踪，多维度快速定位问题
```

### 日志轮转机制

**基于时间（推荐）**：
```python
setup_logging(
    enable_file_rotation=True,
    rotation_time="00:00",      # 每天午夜轮转
)
```

**基于大小**：
```python
setup_logging(
    enable_file_rotation=False,
    rotation_size="100 MB",     # 每 100MB 轮转一次
)
```

### 日志保留策略

```python
setup_logging(
    retention_days=7,           # 保留 7 天日志
)
# 自动删除 7 天前的文件
```

---

## 链路追踪

### 什么是链路追踪？

在微服务架构中，一个请求可能跨越多个服务。链路追踪使用统一的 **Trace ID** 关联所有相关的日志。

```
客户端请求
    ↓
API 服务 (Trace-ID: 550e8400-e29b-41d4)
    ↓ RPC 调用
用户服务 (Trace-ID: 550e8400-e29b-41d4)
    ↓ RPC 调用
订单服务 (Trace-ID: 550e8400-e29b-41d4)
    
所有日志都包含相同的 Trace-ID，便于追踪完整链路
```

### 自动链路追踪

框架在以下场景自动生成和传递 Trace ID：

#### 1. HTTP 请求

```
请求头支持：
- X-Trace-ID（推荐）
- X-Request-ID（兼容性）

自动处理：
1. 从请求头读取 Trace ID
2. 如果没有则生成新的 UUID
3. 在所有日志中包含 Trace ID
4. 在响应头中返回 Trace ID
```

**示例日志输出**：
```
→ GET /api/users | 客户端: 127.0.0.1 | Trace-ID: 550e8400-e29b-41d4-a716-446655440000
← GET /api/users | 状态: 200 | 耗时: 0.123s | Trace-ID: 550e8400-e29b-41d4-a716-446655440000
```

#### 2. RPC 调用

RPC 客户端自动在所有请求中包含 Trace ID：

```python
from aurimyth.foundation_kit.application.rpc import create_rpc_client

client = create_rpc_client(service_name="user-service")

# 自动添加 X-Trace-ID 和 X-Request-ID 请求头
response = await client.get("/api/v1/users")
```

**对应日志**：
```
RPC调用开始: GET /api/v1/users | Trace-ID: 550e8400-e29b-41d4-a716-446655440000
RPC调用成功: GET /api/v1/users | 状态: 200 | Trace-ID: 550e8400-e29b-41d4-a716-446655440000
```

### 手动管理 Trace ID

```python
from aurimyth.foundation_kit.common.logging import get_trace_id, set_trace_id

# 获取当前 Trace ID
current_trace_id = get_trace_id()
logger.info(f"处理请求，Trace ID: {current_trace_id}")

# 设置新的 Trace ID（通常不需要，框架自动处理）
set_trace_id("custom-trace-id-123")
```

### 链路追踪示例

**场景**：追踪跨服务的用户创建请求

```
1. 客户端发送请求
   POST /api/users?X-Trace-ID=abc-123

2. API 服务接收
   [API] → POST /api/users | Trace-ID: abc-123
   [API] ← POST /api/users | 状态: 200 | Trace-ID: abc-123
   
   日志：创建用户
   [DB] INSERT users | Trace-ID: abc-123

3. API 调用用户服务
   [RPC] GET /users/validate | Trace-ID: abc-123
   [RPC] ← GET /users/validate | Trace-ID: abc-123

4. 用户服务处理
   [User] GET /users/validate | Trace-ID: abc-123
   [Cache] CACHE HIT: user:xyz | Trace-ID: abc-123
   [User] ← GET /users/validate | 状态: 200 | Trace-ID: abc-123

完整链路：所有服务的日志都使用 abc-123
```

---

## RPC 集成追踪

### RPC 客户端自动追踪

```python
from aurimyth.foundation_kit.application.rpc import create_rpc_client

# 创建客户端
client = create_rpc_client(service_name="order-service")

# 调用时自动包含 Trace ID
response = await client.get("/api/v1/orders")
# 自动添加：X-Trace-ID: <当前追踪ID>
```

### 配置 RPC 超时和重试

```python
client = create_rpc_client(
    service_name="order-service",
    timeout=30,         # 超时 30 秒
    retry_times=3,      # 最多重试 3 次
)
```

### 链路追踪日志示例

```
[14:30:45] RPC调用开始: GET /api/v1/orders | Trace-ID: 550e8400
[14:30:45] RPC调用成功: GET /api/v1/orders | 状态: 200 | Trace-ID: 550e8400

# 如果失败
[14:30:45] RPC调用失败: POST /api/v1/orders | 错误: Connection refused | Trace-ID: 550e8400
```

### 跨服务追踪实现

```python
from fastapi import Request
from aurimyth.foundation_kit.common.logging import logger, get_trace_id

@app.get("/api/users/{user_id}")
async def get_user(user_id: str, request: Request):
    # 框架自动设置 Trace ID（从请求头或新生成）
    trace_id = get_trace_id()
    
    logger.info(f"获取用户 {user_id} | Trace-ID: {trace_id}")
    
    # 调用订单服务
    order_client = create_rpc_client(service_name="order-service")
    # Trace ID 自动传递到订单服务
    orders = await order_client.get(f"/api/v1/users/{user_id}/orders")
    
    logger.info(f"获取订单成功，共 {len(orders)} 个 | Trace-ID: {trace_id}")
    
    return {"user_id": user_id, "orders": orders}
```

---

## 性能监控

### 执行时间监控

```python
from aurimyth.foundation_kit.common.logging import log_performance

@log_performance(threshold=0.5)  # 超过 0.5 秒时警告
async def fetch_data():
    await asyncio.sleep(1)

# 输出
# 性能警告: __main__.fetch_data 执行耗时 1.000s (阈值: 0.5s)
```

### 异常捕获

```python
from aurimyth.foundation_kit.common.logging import log_exceptions

@log_exceptions  # 自动记录异常堆栈
async def risky_operation():
    raise ValueError("Something wrong")

# 输出
# 异常捕获: __main__.risky_operation | 异常: ValueError: Something wrong
# 完整堆栈跟踪
```

### 查询性能监控

使用数据库查询装饰器（已集成 Trace ID）：

```python
from aurimyth.foundation_kit.infrastructure.database import monitor_query

@monitor_query(slow_threshold=0.5)
async def list_users():
    return await session.execute(query)

# 输出
# 查询执行: list_users 耗时 0.123s | Trace-ID: 550e8400
# 或（如果超过阈值）
# 慢查询检测: list_users 执行时间 1.234s (阈值: 0.5s) | Trace-ID: 550e8400
```

### 缓存性能监控

```python
from aurimyth.foundation_kit.infrastructure.database import cache_query

@cache_query(ttl=300)
async def get_user_profile(user_id: str):
    return await fetch_from_db(user_id)

# 输出
# 缓存命中: repo:abc123 | Trace-ID: 550e8400
# 或
# 缓存写入: repo:abc123, TTL=300s | Trace-ID: 550e8400
```

---

## 常见问题

### Q: 如何在生产环境禁用控制台输出？

```python
setup_logging(
    enable_console=False,  # 仅输出到文件
    log_level="WARNING",   # 提高日志级别
)
```

### Q: 如何自定义日志格式？

日志格式在 `setup_logging` 中硬编码，如需自定义，可直接修改源码。

现在的格式：
- **控制台**：`[时间] | [级别] | [模块:函数:行] | [TraceID] - [消息]`
- **文件**：同上（无颜色）

### Q: 日志文件太大，如何处理？

启用基于大小的轮转：

```python
setup_logging(
    enable_file_rotation=False,    # 禁用基于时间
    rotation_size="50 MB",         # 50MB 轮转一次
    retention_days=14,             # 保留 14 天
)
```

### Q: 如何追踪异步任务中的请求？

异步任务没有 HTTP 请求上下文，需要手动传递 Trace ID：

```python
@app.get("/api/users")
async def create_user():
    trace_id = get_trace_id()
    
    # 启动异步任务，传递 Trace ID
    task_manager.send_task(
        process_user,
        args=(user_data, trace_id)
    )
    
# Worker 中
@task_manager.task()
async def process_user(user_data, trace_id):
    set_trace_id(trace_id)  # 恢复追踪上下文
    logger.info(f"处理用户 | Trace-ID: {trace_id}")
```

### Q: 如何收集链路追踪到外部系统（Jaeger、Zipkin）？

目前框架提供的是文本日志追踪。要集成 Jaeger/Zipkin，可以：

1. 在 setup_logging 后添加自定义 handler
2. 使用中间件额外捕获链路数据
3. 定期将链路日志导入专业追踪系统

示例（伪代码）：
```python
# 在中间件中收集追踪数据
class TracingMiddleware:
    async def dispatch(self, request, call_next):
        trace_id = get_trace_id()
        start = time.time()
        
        response = await call_next(request)
        duration = time.time() - start
        
        # 发送到 Jaeger
        send_to_jaeger({
            "trace_id": trace_id,
            "span_name": f"{request.method} {request.url.path}",
            "duration": duration,
        })
        
        return response
```

---

## 总结

✅ **强大的日志系统** - 支持分类、轮转、多级别  
✅ **自动链路追踪** - HTTP 和 RPC 自动传递  
✅ **性能监控** - 内置执行时间和异常追踪  
✅ **开箱即用** - 无需额外配置即可使用  
✅ **生产就绪** - 异步写入、自动轮转、存储优化

这个日志系统完全满足微服务架构中的追踪和监控需求！

