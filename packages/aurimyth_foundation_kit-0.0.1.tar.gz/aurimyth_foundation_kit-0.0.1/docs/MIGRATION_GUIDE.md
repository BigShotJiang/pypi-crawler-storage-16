# 迁移管理指南

## 快速开始

### 1. 配置环境变量（可选，有默认值）

```bash
# .env 文件
DATABASE_URL="postgresql://user:password@localhost/mydb"

# 迁移配置（所有都有默认值，可以跳过）
# MIGRATION_CONFIG_PATH="alembic.ini"           # 默认: alembic.ini
# MIGRATION_SCRIPT_LOCATION="alembic"           # 默认: alembic
# MIGRATION_AUTO_CREATE="true"                  # 默认: true
# MIGRATION_MODEL_MODULES='["app.models", ...]' # 默认: ["app.models", "app.**.models"]
```

**默认配置已经足够**，直接运行迁移命令即可！

默认值 `["app.models", "app.**.models"]` 同时支持：
- ✅ 根目录的 `app/models.py`
- ✅ 递归发现所有子模块的 models（如 `app/users/models.py`）

如果你的项目结构不同，才需要自定义：

```bash
# 自定义示例
MIGRATION_MODEL_MODULES='["myapp.models", "plugins.models"]'
```

### 2. 自动创建配置（首次使用）

首次运行迁移命令时，如果 `MIGRATION_AUTO_CREATE=true`（默认为 true），系统会自动创建：
- ✅ `alembic.ini` 配置文件
- ✅ `alembic/` 目录结构
- ✅ `alembic/env.py` 环境配置（包含 `load_all_models` 调用）
- ✅ `alembic/script.py.mako` 模板文件
- ✅ `alembic/versions/` 迁移文件目录

**你什么都不需要做**，只需运行迁移命令即可！

### 3. 基本命令

```bash
# 查看迁移状态
aurimyth-migrate status

# 生成迁移文件（自动检测模型变更）
aurimyth-migrate make -m "描述变更内容"

# 应用迁移到数据库
aurimyth-migrate up

# 查看所有迁移
aurimyth-migrate show

# 回滚迁移
aurimyth-migrate down -1

# 检查迁移文件
aurimyth-migrate check

# 查看迁移历史
aurimyth-migrate history
```

## 模型加载机制

### load_all_models 工作原理

框架提供了 `load_all_models()` 函数，它会：

1. **自动导入**配置的所有模型模块
2. **确保模型注册**到 SQLAlchemy 的 `Base.metadata`
3. **让 Alembic 检测到**所有模型变更

### 配置模型模块

**默认值**：`["app.models", "app.**.models"]`

这个默认值同时支持：
- ✅ `app.models` - 加载根 models 文件
- ✅ `app.**.models` - 递归发现所有子模块中的 models

**开箱即用，无需配置**！大多数项目直接使用默认值即可。

如果需要自定义，支持以下方式：

#### 方式 1：精确模块名（自定义示例）

```bash
# .env
MIGRATION_MODEL_MODULES='["myapp.models", "myapp.users.models"]'
```

#### 方式 2：通配符模式（推荐）

```bash
# 单层通配符 * - 匹配单层任意字符
MIGRATION_MODEL_MODULES='["app.*.models"]'
# 匹配: app.users.models, app.products.models, app.orders.models

# 递归通配符 ** - 递归匹配所有子模块
MIGRATION_MODEL_MODULES='["app.**"]'
# 匹配: app.models, app.users.models, app.products.models, app.products.categories.models 等

# 混合使用
MIGRATION_MODEL_MODULES='["app.**.models"]'
# 递归匹配所有以 models 结尾的模块

# 多个模式组合
MIGRATION_MODEL_MODULES='["app.models", "app.*.models", "extensions.**.models"]'
```

**通配符说明：**
- `*` : 匹配单层任意字符（不包含点）
- `**` : 递归匹配任意层级（包含点）

#### 方式 3：在应用代码中配置

```python
# config.py
from aurimyth.foundation_kit.application.config import BaseConfig

class Config(BaseConfig):
    class Config:
        # 可以在这里硬编码
        pass

# 然后设置环境变量
export MIGRATION_MODEL_MODULES='["app.**.models"]'
```

### 模型组织最佳实践

#### 方式 1：单一 models.py 文件（小项目）

```
app/
├── __init__.py
├── models.py          # 所有模型都在这里
└── main.py
```

配置：
```bash
MIGRATION_MODEL_MODULES='["app.models"]'
```

#### 方式 2：按模块分离 + 通配符（推荐）⭐

```
app/
├── __init__.py
├── users/
│   ├── __init__.py
│   └── models.py      # 用户相关模型
├── products/
│   ├── __init__.py
│   └── models.py      # 产品相关模型
└── orders/
    ├── __init__.py
    └── models.py      # 订单相关模型
```

配置（使用通配符，自动发现）：
```bash
# 方式 A：单层通配符（推荐）
MIGRATION_MODEL_MODULES='["app.*.models"]'

# 方式 B：手动列举（不推荐，维护成本高）
MIGRATION_MODEL_MODULES='["app.users.models", "app.products.models", "app.orders.models"]'
```

**优势**：新增模块时无需修改配置！

#### 方式 3：多层嵌套 + 递归通配符（大项目推荐）⭐⭐

```
app/
├── __init__.py
├── core/
│   └── models.py
├── users/
│   ├── __init__.py
│   ├── models.py
│   └── profiles/
│       └── models.py  # 嵌套的模型
├── products/
│   ├── __init__.py
│   ├── models.py
│   └── categories/
│       └── models.py  # 嵌套的模型
└── orders/
    ├── __init__.py
    └── models.py
```

配置（使用递归通配符）：
```bash
# 方式 A：递归匹配所有 models 模块（推荐）
MIGRATION_MODEL_MODULES='["app.**.models"]'

# 方式 B：递归匹配所有模块（如果模型分散在各处）
MIGRATION_MODEL_MODULES='["app.**"]'
```

**优势**：支持任意层级嵌套，无需关心目录结构！

#### 方式 4：集中导入（传统方式）

创建一个集中导入所有模型的模块：

```python
# app/models/__init__.py
"""集中导入所有模型，方便迁移检测。"""

# 导入所有模型
from app.users.models import User, UserProfile
from app.products.models import Product, Category
from app.orders.models import Order, OrderItem

__all__ = [
    "User",
    "UserProfile",
    "Product",
    "Category",
    "Order",
    "OrderItem",
]
```

配置：
```bash
MIGRATION_MODEL_MODULES='["app.models"]'
```

**劣势**：每次新增模型都要手动添加导入，维护成本高。

## 通配符模式详解

### 模式匹配规则

| 模式 | 说明 | 示例 |
|------|------|------|
| `app.models` | 精确匹配 | 只匹配 `app.models` |
| `app.*.models` | 单层通配符 | 匹配 `app.users.models`, `app.products.models` |
| `app.**` | 递归通配符 | 匹配 `app` 下所有模块（任意层级） |
| `app.**.models` | 递归 + 后缀 | 匹配所有以 `.models` 结尾的模块 |
| `*.models` | ❌ 无效 | 必须指定基础包名 |

### 实际案例

#### 案例 1：Django 风格结构

```
myproject/
├── users/
│   ├── models.py
│   └── views.py
├── products/
│   ├── models.py
│   └── views.py
└── orders/
    ├── models.py
    └── views.py
```

配置：
```bash
MIGRATION_MODEL_MODULES='["myproject.*.models"]'
```

发现的模块：
- ✅ `myproject.users.models`
- ✅ `myproject.products.models`
- ✅ `myproject.orders.models`

#### 案例 2：嵌套结构

```
app/
├── core/
│   └── models.py
├── domains/
│   ├── users/
│   │   ├── models.py
│   │   └── profiles/
│   │       └── models.py
│   └── products/
│       ├── models.py
│       └── categories/
│           └── models.py
```

配置：
```bash
MIGRATION_MODEL_MODULES='["app.**.models"]'
```

发现的模块：
- ✅ `app.core.models`
- ✅ `app.domains.users.models`
- ✅ `app.domains.users.profiles.models`
- ✅ `app.domains.products.models`
- ✅ `app.domains.products.categories.models`

#### 案例 3：多个模式组合

```
app/
├── models.py          # 核心模型
├── users/
│   └── models.py
└── extensions/
    ├── payments/
    │   └── models.py
    └── notifications/
        └── models.py
```

配置：
```bash
# 组合多个模式
MIGRATION_MODEL_MODULES='["app.models", "app.users.models", "app.extensions.**.models"]'
```

发现的模块：
- ✅ `app.models` (精确匹配)
- ✅ `app.users.models` (精确匹配)
- ✅ `app.extensions.payments.models` (递归匹配)
- ✅ `app.extensions.notifications.models` (递归匹配)

## 示例：完整工作流程

### 1. 创建新模型

```python
# app/users/models.py
from aurimyth.foundation_kit.domain.models import Model
from sqlalchemy import String
from sqlalchemy.orm import Mapped, mapped_column

class User(Model):
    """用户模型"""
    __tablename__ = "users"
    
    username: Mapped[str] = mapped_column(String(50), unique=True)
    email: Mapped[str] = mapped_column(String(100), unique=True)
    full_name: Mapped[str] = mapped_column(String(100))
```

### 2. 配置通配符模式（一次配置，永久生效）

```bash
# .env - 使用通配符，自动发现所有 models 模块
MIGRATION_MODEL_MODULES='["app.*.models"]'

# 或更灵活的递归模式
MIGRATION_MODEL_MODULES='["app.**.models"]'
```

**好处**：以后新增 `app.products.models`、`app.orders.models` 等模块时，无需修改配置！

### 3. 生成迁移

```bash
# load_all_models 会自动导入 app.users.models
# Alembic 会检测到新的 User 模型
aurimyth-migrate make -m "Add user model"
```

输出：
```
INFO  [alembic.runtime.migration] Context impl PostgreSQLImpl.
INFO  [alembic.runtime.migration] Will assume transactional DDL.
INFO  [alembic.autogenerate.compare] Detected added table 'users'
  Generating /path/to/alembic/versions/20251201_1320_xxx_add_user_model.py ...  done
✅ 迁移文件已生成
```

### 4. 查看生成的迁移文件

```python
# alembic/versions/20251201_1320_xxx_add_user_model.py
def upgrade() -> None:
    op.create_table('users',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('username', sa.String(length=50), nullable=False),
        sa.Column('email', sa.String(length=100), nullable=False),
        sa.Column('full_name', sa.String(length=100), nullable=False),
        sa.Column('created_at', sa.DateTime(), nullable=False),
        sa.Column('updated_at', sa.DateTime(), nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('username'),
        sa.UniqueConstraint('email')
    )
```

### 5. 应用迁移

```bash
aurimyth-migrate up
```

输出：
```
INFO  [alembic.runtime.migration] Running upgrade  -> xxx, Add user model
✅ 迁移已执行到版本: head
```

### 6. 验证状态

```bash
aurimyth-migrate status
```

输出：
```
📊 迁移状态:
  当前版本: xxx (add_user_model)
  最新版本: xxx (add_user_model)

✅ 所有迁移已执行
```

## 常见问题

### Q1: 为什么需要配置 model_modules？

**A:** Alembic 需要知道哪些模块包含模型，才能检测模型变更。`load_all_models()` 会自动导入这些模块，确保所有模型都注册到 SQLAlchemy 的元数据中。

### Q2: 通配符模式 vs 精确模块名，应该用哪个？

**A:** 

| 场景 | 推荐方式 | 配置示例 |
|------|---------|---------|
| 小项目（1-3个模型文件） | 精确模块名 | `["app.models"]` |
| 中型项目（模块按功能分离） | 单层通配符 ⭐ | `["app.*.models"]` |
| 大型项目（多层嵌套） | 递归通配符 ⭐⭐ | `["app.**.models"]` |
| 混合结构 | 组合模式 | `["app.models", "app.**.models"]` |

**推荐**：优先使用通配符模式，减少维护成本！

### Q3: 忘记配置 model_modules 会怎样？

**A:** 如果没有配置，Alembic 无法检测到模型变更，`autogenerate` 会生成空的迁移文件：

```python
def upgrade() -> None:
    pass  # 没有检测到任何变更

def downgrade() -> None:
    pass
```

### Q4: 如何确认模型已被加载？

**A:** 运行迁移命令时，查看日志：

```bash
aurimyth-migrate make -m "test" --dry-run
```

你应该看到类似的日志：
```
DEBUG [manager] 发现模块: app.users.models
DEBUG [manager] 发现模块: app.products.models
DEBUG [manager] 已加载模型模块: app.users.models
DEBUG [manager] 已加载模型模块: app.products.models
INFO  [manager] 共加载 2 个模型模块
```

### Q5: 通配符会匹配到非模型模块吗？

**A:** 会的。如果你使用 `app.**`，会匹配所有子模块。建议：

- ✅ **推荐**：使用 `app.**.models` 只匹配 models 模块
- ⚠️ **不推荐**：使用 `app.**` 匹配所有模块（可能导入无关模块）

### Q6: 通配符模式性能如何？

**A:** 非常高效！

- 使用 Python 内置的 `pkgutil.walk_packages`
- 只遍历指定的基础包
- 模块发现只在生成迁移时执行一次
- 对于大多数项目（< 100 个模型文件），耗时 < 100ms

### Q4: 可以手动在 env.py 中导入模型吗？

**A:** 可以，但不推荐。如果你修改了自动生成的 `env.py`，下次重新生成时会被覆盖。推荐使用 `MIGRATION_MODEL_MODULES` 配置。

如果确实需要手动导入，可以在 `env.py` 中的 `load_all_models()` 调用后添加：

```python
# alembic/env.py
load_all_models(["app.models"])

# 手动导入特殊模型（可选）
from app.special_models import SpecialModel  # noqa
```

### Q5: Target database is not up to date 错误

**A:** 这表示数据库中已有迁移记录，但还没有应用最新的迁移。解决方法：

```bash
# 查看待执行的迁移
aurimyth-migrate status

# 应用所有待执行的迁移
aurimyth-migrate up

# 然后再生成新迁移
aurimyth-migrate make -m "new migration"
```

## 高级用法

### 自定义 env.py（不推荐）

如果你需要完全自定义 `env.py`，可以关闭自动创建：

```bash
MIGRATION_AUTO_CREATE="false"
```

然后手动创建 `alembic/env.py` 并使用 `load_all_models()`：

```python
# alembic/env.py
from aurimyth.foundation_kit.domain.models import Base
from aurimyth.foundation_kit.application.migrations import load_all_models

# 手动指定模型模块
load_all_models([
    "app.models",
    "app.users.models",
    "app.products.models",
])

target_metadata = Base.metadata
# ... 其他配置
```

### 程序化使用

```python
from aurimyth.foundation_kit.application.migrations import MigrationManager

# 创建管理器
manager = MigrationManager(
    database_url="postgresql://user:pass@localhost/db",
    config_path="alembic.ini",
    script_location="alembic",
    model_modules=["app.models"],
    auto_create=True,
)

# 生成迁移
await manager.make_migrations(message="Add user table")

# 应用迁移
await manager.upgrade()

# 查看状态
status = await manager.status()
print(f"当前版本: {status['current']}")
```

## 总结

1. **配置 `MIGRATION_MODEL_MODULES`** 是使用迁移功能的关键
2. **`load_all_models()`** 自动导入所有模型模块
3. **自动创建功能**让首次使用更简单
4. **遵循最佳实践**组织模型代码
5. **使用集中导入**简化大型项目的配置

