# 迁移故障排查指南

## 问题 1：为什么 autogenerate 检测不到模型变更？

### 症状
运行 `aurimyth-migrate make -m "xxx"` 后，生成的迁移文件为空：

```python
def upgrade() -> None:
    pass  # 没有检测到任何变更
```

### 根本原因

**SQLAlchemy 使用声明式注册表，模型必须被导入才会注册到 `Base.metadata`**

即使你的模型正确定义了 `__tablename__`，如果模型所在的模块没有被导入，SQLAlchemy 就不会在元数据中注册这个表。

```python
# ❌ 错误：模型定义但未导入
class User(Model):
    __tablename__ = "users"
    name: Mapped[str] = mapped_column(String(50))

# Alembic autogenerate 看不到这个表！
# Base.metadata.tables 中没有 users 表
```

```python
# ✅ 正确：导入模型后才会注册
import app.models  # 这行导入会触发模型定义的执行
# 现在 Base.metadata.tables 中有 users 表了
```

### 解决方案

#### 方案 1：确保 `load_all_models()` 正确配置（推荐）

1. **检查 `MIGRATION_MODEL_MODULES` 配置**

```bash
# .env 文件
MIGRATION_MODEL_MODULES='["app.models", "app.**.models"]'
```

2. **查看日志，确认模型加载成功**

```bash
aurimyth-migrate make -m "test" --dry-run
```

日志中应该看到：
```
INFO  [manager] 共加载 2 个模型模块
DEBUG [manager] 已加载模型模块: app.models
DEBUG [manager] 已加载模型模块: app.users.models
```

3. **确保模型定义了 `__tablename__`**

```python
# ✅ 正确
class User(Model):
    __tablename__ = "users"  # 必须有这行
    name: Mapped[str] = mapped_column(String(50))

# ❌ 错误
class User(Model):
    # 没有 __tablename__，SQLAlchemy 会自动生成，但可能不符合预期
    name: Mapped[str] = mapped_column(String(50))
```

#### 方案 2：手动导入模型（临时调试）

如果 `load_all_models()` 不工作，可以在 `alembic/env.py` 中手动添加导入：

```python
# alembic/env.py
from aurimyth.foundation_kit.domain.models import Base
from aurimyth.foundation_kit.application.migrations import load_all_models

# 自动加载
load_all_models(["app.models", "app.**.models"])

# 手动导入（备选，仅用于调试）
import app.models  # noqa: F401
import app.users.models  # noqa: F401

target_metadata = Base.metadata
```

#### 方案 3：检查模型是否真的在被导入

添加调试代码到你的模型文件：

```python
# app/models.py
from aurimyth.foundation_kit.domain.models import Model
from sqlalchemy import String
from sqlalchemy.orm import Mapped, mapped_column

print("✅ app.models 被导入了")  # 调试打印

class User(Model):
    __tablename__ = "users"
    name: Mapped[str] = mapped_column(String(50))
```

运行迁移命令时应该看到这个打印。

---

## 问题 2：模型定义了但表没有生成

### 症状
- ✅ 日志中看到 "已加载模型模块: app.models"
- ❌ 但迁移文件仍然是空的

### 原因分析

1. **模型没有继承正确的基类**

```python
# ❌ 错误：直接继承 Base
class User(Base):
    __tablename__ = "users"
    # 这会工作，但缺少 id 字段

# ✅ 正确：继承预定义模型
from aurimyth.foundation_kit.domain.models import Model

class User(Model):  # 已包含 id 和时间戳
    __tablename__ = "users"
    name: Mapped[str] = mapped_column(String(50))
```

2. **模型是抽象的**

```python
# ❌ 这样的模型不会生成表
class BaseModel(Model):
    __abstract__ = True  # 这会被跳过

# ✅ 只有非抽象模型才会生成表
class User(Model):
    __tablename__ = "users"
    name: Mapped[str] = mapped_column(String(50))
```

### 解决方案

1. **检查模型是否有 `__tablename__`**

```python
from aurimyth.foundation_kit.domain.models import Model

class User(Model):
    __tablename__ = "users"  # 必须有这行
    name: Mapped[str] = mapped_column(String(50))
```

2. **检查模型是否继承自正确的基类**

```python
# ✅ 推荐的基类
from aurimyth.foundation_kit.domain.models import (
    Model,  # 基础
    UUIDModel,  # UUID 主键
    AuditableStateModel,  # 软删除
    FullFeaturedModel,  # 完整功能
)
```

3. **检查 `__abstract__` 标记**

```python
# 只有非抽象类才会生成表
class User(Model):
    __tablename__ = "users"
    # 不要设置 __abstract__ = True
    name: Mapped[str] = mapped_column(String(50))
```

---

## 问题 3：load_all_models 仍然不工作

### 症状
- ❌ 日志中看不到 "已加载模型模块"
- ❌ 日志中有 "无法导入模型模块" 错误

### 故障排查

1. **检查模块名是否正确**

```bash
# 检查模型文件确实存在
find . -name "models.py" | grep app

# 应该看到类似:
# ./app/models.py
# ./app/users/models.py
```

2. **检查 Python 路径**

```bash
# 确保项目根目录在 Python 路径中
export PYTHONPATH=.:$PYTHONPATH

# 然后运行迁移
aurimyth-migrate make -m "test"
```

3. **检查模块导入是否有错误**

```bash
# 尝试手动导入模块
python -c "import app.models; print('成功')"
```

如果这失败了，说明模块本身有问题。

4. **启用调试日志**

```bash
# 运行迁移时查看详细日志
python -m aurimyth.foundation_kit.commands.migrate make -m "test" 2>&1 | grep -i load
```

---

## 问题 4：模型的导出问题

### 症状
模型在 `app/users/models.py` 中定义，但 `app/users/__init__.py` 中没有导出。

### 解决方案

1. **方案 A：直接配置模块路径**（推荐）

```bash
# .env
MIGRATION_MODEL_MODULES='["app.users.models"]'
# 直接导入 app/users/models.py 文件
```

2. **方案 B：在 `__init__.py` 中导出模型**

```python
# app/users/__init__.py
from .models import User, UserProfile

__all__ = ["User", "UserProfile"]
```

然后配置：
```bash
MIGRATION_MODEL_MODULES='["app.users"]'
```

---

## 完整诊断流程

如果遇到问题，按以下流程诊断：

```bash
# 1. 检查配置
echo "MIGRATION_MODEL_MODULES: $MIGRATION_MODEL_MODULES"

# 2. 检查模型文件存在
find . -name "models.py" | grep -v __pycache__

# 3. 尝试手动导入
python -c "import app.models; print('✅ 导入成功')"

# 4. 查看生成的 env.py
cat alembic/env.py

# 5. 运行迁移并查看日志
aurimyth-migrate make -m "test" --dry-run

# 6. 如果仍不工作，手动导入（临时解决）
# 编辑 alembic/env.py 添加:
# import app.models  # noqa: F401
```

---

## 最佳实践

1. **总是定义 `__tablename__`**

```python
class User(Model):
    __tablename__ = "users"  # 必须有
    name: Mapped[str] = mapped_column(String(50))
```

2. **使用预定义模型**

```python
from aurimyth.foundation_kit.domain.models import (
    Model,  # 基础
    FullFeaturedModel,  # 完整功能
)

class User(Model):  # 或 FullFeaturedModel
    __tablename__ = "users"
    name: Mapped[str] = mapped_column(String(50))
```

3. **配置正确的模块列表**

```bash
# 推荐：同时包含根模块和递归模块
MIGRATION_MODEL_MODULES='["app.models", "app.**.models"]'
```

4. **检查日志**

```bash
# 总是查看迁移命令的日志输出
# 确认看到 "共加载 X 个模型模块"
```

5. **模型组织建议**

```
app/
├── models.py            # 核心模型
├── users/
│   ├── __init__.py
│   └── models.py        # 用户模块模型
├── products/
│   ├── __init__.py
│   └── models.py        # 产品模块模型
```

配置：
```bash
MIGRATION_MODEL_MODULES='["app.models", "app.**.models"]'
```

这样会同时加载 `app.models` 和所有子模块的 `models.py`。















