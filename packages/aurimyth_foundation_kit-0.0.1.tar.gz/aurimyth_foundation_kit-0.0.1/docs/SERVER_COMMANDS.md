# 服务器管理命令

`aurimyth-server` 是框架提供的 CLI 工具，用于启动和管理 ASGI 服务器。

## 安装

在项目依赖中已包含，可以直接使用：

```bash
aurimyth-server --help
```

## 命令概览

### 1. `run` - 运行服务器

最通用的服务器启动命令，支持所有配置选项。

**基本用法：**

```bash
aurimyth-server run
```

**常用选项：**

```bash
# 指定监听地址和端口
aurimyth-server run --host 0.0.0.0 --port 8000

# 启用热重载（开发模式）
aurimyth-server run --reload

# 指定热重载监控目录
aurimyth-server run --reload --reload-dir src/ --reload-dir tests/

# 多进程运行
aurimyth-server run --workers 4

# 启用调试模式
aurimyth-server run --debug

# HTTPS
aurimyth-server run --ssl-keyfile key.pem --ssl-certfile cert.pem

# 禁用访问日志
aurimyth-server run --no-access-log
```

**所有选项：**

| 选项 | 环境变量 | 默认值 | 说明 |
|------|---------|--------|------|
| `--host, -h` | `SERVER_HOST` | `127.0.0.1` | 监听地址 |
| `--port, -p` | `SERVER_PORT` | `8000` | 监听端口 |
| `--workers, -w` | `SERVER_WORKERS` | `1` | 工作进程数 |
| `--reload` | `SERVER_RELOAD` | `false` | 启用热重载 |
| `--reload-dir` | - | - | 热重载监控目录（可多次指定） |
| `--debug` | `DEBUG` | `false` | 启用调试模式 |
| `--loop` | - | `auto` | 事件循环实现（auto/asyncio/uvloop） |
| `--http` | - | `auto` | HTTP 协议版本（auto/h11/httptools） |
| `--ssl-keyfile` | - | - | SSL 密钥文件路径 |
| `--ssl-certfile` | - | - | SSL 证书文件路径 |
| `--no-access-log` | - | `false` | 禁用访问日志 |

### 2. `dev` - 开发服务器

快捷命令，等同于 `run --reload --debug`。

**用法：**

```bash
aurimyth-server dev

# 指定端口
aurimyth-server dev --port 9000
```

**选项：**

| 选项 | 默认值 |
|------|--------|
| `--host, -h` | `127.0.0.1` |
| `--port, -p` | `8000` |

### 3. `prod` - 生产服务器

快捷命令，启动多进程服务器。工作进程数默认使用 CPU 核心数。

**用法：**

```bash
aurimyth-server prod

# 指定工作进程数
aurimyth-server prod --workers 8

# 指定监听地址
aurimyth-server prod --host 0.0.0.0
```

**选项：**

| 选项 | 默认值 |
|------|--------|
| `--host, -h` | `0.0.0.0` |
| `--port, -p` | `8000` |
| `--workers, -w` | CPU 核心数（默认） |

## 环境变量

支持通过环境变量配置：

```bash
# 开发环境
export SERVER_HOST=127.0.0.1
export SERVER_PORT=8000
export SERVER_WORKERS=1
export SERVER_RELOAD=true
export DEBUG=true

aurimyth-server run

# 或者生产环境
export SERVER_HOST=0.0.0.0
export SERVER_PORT=8000
export SERVER_WORKERS=4

aurimyth-server run
```

## 完整示例

### 开发环境

```bash
# 方式 1：使用 dev 快捷命令
aurimyth-server dev

# 方式 2：使用 run 命令
aurimyth-server run --reload --debug
```

### 生产环境

```bash
# 方式 1：使用 prod 快捷命令
aurimyth-server prod

# 方式 2：使用 run 命令并指定工作进程数
aurimyth-server run --host 0.0.0.0 --port 8000 --workers 4

# 方式 3：使用 HTTPS
aurimyth-server run \
  --host 0.0.0.0 \
  --port 443 \
  --ssl-keyfile /etc/ssl/private/key.pem \
  --ssl-certfile /etc/ssl/certs/cert.pem \
  --workers 4
```

### Docker 部署

```dockerfile
FROM python:3.13

WORKDIR /app

COPY . .
RUN pip install -e .

# 生产环境启动
CMD ["aurimyth-server", "prod", "--host", "0.0.0.0", "--port", "8000"]
```

### Systemd 服务

```ini
[Unit]
Description=AuriMyth Application
After=network.target

[Service]
Type=notify
User=appuser
WorkingDirectory=/app
Environment="SERVER_HOST=0.0.0.0"
Environment="SERVER_PORT=8000"
Environment="SERVER_WORKERS=4"
ExecStart=/usr/local/bin/aurimyth-server prod
Restart=on-failure
RestartSec=5s

[Install]
WantedBy=multi-user.target
```

## 性能调优

### CPU 核心数配置

```bash
# 查看 CPU 核心数
python -c "import os; print(os.cpu_count())"

# 设置为 CPU 核心数
aurimyth-server run --workers $(python -c "import os; print(os.cpu_count())")
```

### 事件循环选择

- `auto`：自动选择最适合的实现
- `asyncio`：标准库实现
- `uvloop`：性能更好的第三方实现（需要单独安装）

```bash
# 使用 uvloop（需要安装：pip install uvloop）
aurimyth-server run --loop uvloop
```

### HTTP 协议实现

- `auto`：自动选择
- `h11`：纯 Python 实现
- `httptools`：C 扩展实现，性能更好

```bash
# 使用 httptools
aurimyth-server run --http httptools
```

## 故障排除

### 找不到 app 实例

确保在项目根目录有 `main.py` 文件，并定义了 `app` 变量：

```python
# main.py
from aurimyth.foundation_kit.application import FoundationApp

app = FoundationApp()

@app.get("/")
def index():
    return {"message": "Hello"}
```

### 端口被占用

```bash
# macOS/Linux - 查看占用端口的进程
lsof -i :8000

# 使用其他端口
aurimyth-server run --port 8001
```

### 内存占用过高

减少工作进程数或启用 `--no-access-log`：

```bash
aurimyth-server prod --workers 2 --no-access-log
```

## 与 Python API 的集成

也可以在 Python 代码中直接使用服务器：

```python
from aurimyth.foundation_kit.application import FoundationApp, run_app

app = FoundationApp()

@app.get("/")
def index():
    return {"message": "Hello"}

if __name__ == "__main__":
    # 使用便捷函数
    run_app(app, host="0.0.0.0", port=8000, workers=4)
```

或者使用 `ApplicationServer` 类获得更多控制：

```python
from aurimyth.foundation_kit.application import FoundationApp, ApplicationServer

app = FoundationApp()

if __name__ == "__main__":
    server = ApplicationServer(
        app=app,
        host="0.0.0.0",
        port=8000,
        workers=4,
        reload=False,
    )
    server.run()
```

## 相关资源

- [Uvicorn 文档](https://www.uvicorn.org/)
- [FastAPI 部署指南](https://fastapi.tiangolo.com/deployment/)
- [应用配置](./USER_GUIDE.md#2-应用配置)















