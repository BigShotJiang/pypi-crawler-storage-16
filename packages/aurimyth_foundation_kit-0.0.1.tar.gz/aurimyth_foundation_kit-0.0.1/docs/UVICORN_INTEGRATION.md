# Uvicorn 服务器集成完整指南

## 📋 概述

AuriMyth Foundation Kit 提供了完整的 uvicorn 服务器集成，支持：

✅ 多进程/多线程运行  
✅ 热重载（开发模式）  
✅ SSL/TLS 支持  
✅ 自定义日志集成  
✅ 环境变量配置  
✅ 优雅关闭  
✅ 异步运行  

---

## 🚀 快速开始

### 最简单的使用方式

```python
from aurimyth.foundation_kit.application import FoundationApp, run_app

app = FoundationApp(title="My Service", version="1.0.0")

@app.get("/")
async def hello():
    return {"message": "Hello World"}

if __name__ == "__main__":
    # 一行代码启动服务器
    run_app(app)
```

**运行**：
```bash
python main.py
# 输出：
# 服务器启动 | 地址: http://127.0.0.1:8000 | 工作进程: 1 | 热重载: False
```

---

## 🔧 ApplicationServer 类详解

### 基本用法

```python
from aurimyth.foundation_kit.application import FoundationApp, ApplicationServer

app = FoundationApp()

# 创建服务器
server = ApplicationServer(
    app=app,
    host="0.0.0.0",      # 监听所有网络接口
    port=8000,           # 端口
    workers=4,           # 4 个工作进程
)

# 运行
server.run()
```

### 所有参数详解

```python
server = ApplicationServer(
    app=app,
    
    # 网络配置
    host="0.0.0.0",                  # 监听地址
    port=8000,                       # 监听端口
    
    # 进程配置
    workers=1,                       # 工作进程数
    reload=False,                    # 是否热重载
    reload_dirs=["src/"],            # 热重载监控目录
    
    # 性能配置
    loop="auto",                     # 事件循环（auto/asyncio/uvloop）
    http="auto",                     # HTTP 协议（auto/h11/httptools）
    interface="auto",                # ASGI 版本（auto/asgi3/asgi2）
    
    # 调试配置
    debug=False,                     # 调试模式
    access_log=True,                 # 记录访问日志
    use_colors=True,                 # 彩色输出
    
    # 日志配置
    log_config=None,                 # 自定义日志配置
    
    # SSL/TLS 配置
    ssl_keyfile=None,                # SSL 密钥文件
    ssl_certfile=None,               # SSL 证书文件
    ssl_keyfile_password=None,       # SSL 密钥密码
    ssl_version=None,                # SSL 版本
    ssl_cert_reqs=None,              # SSL 证书请求
    ssl_ca_certs=None,               # CA 证书
    ssl_ciphers=None,                # 密码套件
)
```

---

## 📊 配置方式对比

### 方式 1：代码配置（推荐开发）

```python
from aurimyth.foundation_kit.application import ApplicationServer

server = ApplicationServer(
    app=app,
    host="localhost",
    port=8001,
    workers=2,
    reload=True,  # 热重载
    reload_dirs=["src/"],
)
server.run()
```

### 方式 2：环境变量配置（推荐生产）

```bash
# .env 或系统环境变量
export SERVER_HOST=0.0.0.0
export SERVER_PORT=8000
export SERVER_WORKERS=4
export SERVER_RELOAD=false
```

```python
from aurimyth.foundation_kit.application import run_app

# 自动从环境变量读取
run_app(app)
```

### 方式 3：混合配置

```python
from aurimyth.foundation_kit.application import run_app

# 代码参数优先级高于环境变量
run_app(
    app,
    host="0.0.0.0",  # 覆盖 SERVER_HOST
    port=9000,       # 覆盖 SERVER_PORT
)
```

---

## 💻 常见场景

### 场景 1：开发模式（热重载）

```python
server = ApplicationServer(
    app=app,
    host="127.0.0.1",
    port=8000,
    reload=True,              # 启用热重载
    reload_dirs=["src/", "tests/"],
    debug=True,               # 调试模式
    access_log=True,          # 记录访问日志
)
server.run()
```

**特点**：
- 自动重启（代码修改时）
- 调试信息详细
- 适合快速迭代

### 场景 2：生产模式（多进程）

```python
import os
from aurimyth.foundation_kit.application import ApplicationServer

# 工作进程数 = CPU 核心数
workers = os.cpu_count() or 4

server = ApplicationServer(
    app=app,
    host="0.0.0.0",
    port=8000,
    workers=workers,          # 多进程
    reload=False,             # 不热重载
    debug=False,              # 关闭调试
    access_log=True,          # 记录访问日志
)
server.run()
```

**特点**：
- 多进程负载均衡
- 高可用性
- 适合生产环境

### 场景 3：HTTPS/SSL

```python
server = ApplicationServer(
    app=app,
    host="0.0.0.0",
    port=443,
    ssl_keyfile="/path/to/key.pem",
    ssl_certfile="/path/to/cert.pem",
    workers=4,
)
server.run()
```

**生成自签证书**（开发用）：
```bash
openssl req -x509 -newkey rsa:4096 -nodes \
  -out cert.pem -keyout key.pem -days 365
```

### 场景 4：性能优化（uvloop）

```python
server = ApplicationServer(
    app=app,
    loop="uvloop",             # 使用 uvloop（比 asyncio 快）
    http="httptools",          # 使用 httptools（更快的 HTTP 解析）
    workers=4,
)
server.run()
```

**安装依赖**：
```bash
pip install uvloop httptools
```

---

## 🔄 异步运行

### 异步上下文中运行服务器

```python
import asyncio
from aurimyth.foundation_kit.application import ApplicationServer

async def main():
    server = ApplicationServer(
        app=app,
        host="0.0.0.0",
        port=8000,
    )
    
    # 异步运行（不会阻塞）
    await server.run_async()

if __name__ == "__main__":
    asyncio.run(main())
```

### 与其他异步操作并发

```python
import asyncio

async def background_task():
    """后台任务"""
    while True:
        print("后台任务执行中...")
        await asyncio.sleep(60)

async def main():
    server = ApplicationServer(app=app)
    
    # 并发运行服务器和后台任务
    await asyncio.gather(
        server.run_async(),
        background_task(),
    )

asyncio.run(main())
```

---

## 📝 配置示例

### 最小化配置

```python
from aurimyth.foundation_kit.application import run_app

app = FoundationApp()
run_app(app)  # 使用所有默认值
```

### 标准开发配置

```python
server = ApplicationServer(
    app=app,
    host="127.0.0.1",
    port=8000,
    reload=True,
    reload_dirs=["src/"],
    debug=True,
    access_log=True,
)
server.run()
```

### 标准生产配置

```python
import os

server = ApplicationServer(
    app=app,
    host="0.0.0.0",
    port=int(os.getenv("PORT", 8000)),
    workers=int(os.getenv("WORKERS", os.cpu_count() or 4)),
    reload=False,
    debug=False,
    access_log=True,
    loop="uvloop",
    http="httptools",
)
server.run()
```

### Docker 容器配置

```python
# main.py
import os
from aurimyth.foundation_kit.application import run_app

app = FoundationApp()

if __name__ == "__main__":
    run_app(
        app,
        host="0.0.0.0",              # 监听所有接口
        port=int(os.getenv("PORT", 8000)),
        workers=int(os.getenv("WORKERS", 4)),
    )
```

```dockerfile
# Dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .

ENV PYTHONUNBUFFERED=1
ENV PORT=8000
ENV WORKERS=4

CMD ["python", "main.py"]
```

```bash
# Docker 运行
docker run -p 8000:8000 -e WORKERS=4 myapp
```

---

## 📊 工作进程配置建议

| 场景 | 工作进程数 | 说明 |
|------|----------|------|
| 开发 | 1 | 单进程，便于调试 |
| 测试 | 1 | 单进程，避免并发问题 |
| 小服务器 | 2-4 | 2 倍 CPU 核心数 |
| 中等服务器 | N+1 | N = CPU 核心数 |
| 大服务器 | 2N | N = CPU 核心数 |
| I/O 密集 | 3-4 倍 CPU | 更多进程处理等待 |

**查看 CPU 核心数**：
```python
import os
cpu_count = os.cpu_count()
print(f"CPU 核心数: {cpu_count}")
```

---

## 🔍 日志集成

### 查看日志输出

```
2024-01-15 10:30:45 | INFO | uvicorn.server - 服务器启动
2024-01-15 10:30:45 | INFO | uvicorn.access - 127.0.0.1:54321 - "GET / HTTP/1.1" 200
2024-01-15 10:30:46 | DEBUG | app - 处理请求
```

### 自定义日志配置

```python
import logging

custom_log_config = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "default": {
            "format": "%(asctime)s | %(levelname)s | %(name)s - %(message)s",
        },
        "access": {
            "format": "%(asctime)s | %(client_addr)s - %(request_line)s | %(status_code)s",
        },
    },
    "handlers": {
        "default": {
            "formatter": "default",
            "class": "logging.StreamHandler",
            "stream": "ext://sys.stderr",
        },
        "access": {
            "formatter": "access",
            "class": "logging.StreamHandler",
            "stream": "ext://sys.stdout",
        },
    },
    "loggers": {
        "uvicorn": {"handlers": ["default"], "level": "INFO"},
        "uvicorn.access": {"handlers": ["access"], "level": "INFO", "propagate": False},
    },
}

server = ApplicationServer(
    app=app,
    log_config=custom_log_config,
)
server.run()
```

---

## 🎯 最佳实践

### 1. 使用环境变量管理配置

```python
# config.py
import os

class ServerConfig:
    HOST = os.getenv("SERVER_HOST", "127.0.0.1")
    PORT = int(os.getenv("SERVER_PORT", "8000"))
    WORKERS = int(os.getenv("SERVER_WORKERS", "1"))
    RELOAD = os.getenv("SERVER_RELOAD", "false").lower() == "true"
    DEBUG = os.getenv("DEBUG", "false").lower() == "true"
```

### 2. 创建工厂函数

```python
# app_factory.py
def create_app():
    app = FoundationApp(
        title="My Service",
        version="1.0.0",
    )
    
    @app.get("/health")
    async def health_check():
        return {"status": "ok"}
    
    return app

def create_server(app, **kwargs):
    from config import ServerConfig
    
    return ApplicationServer(
        app=app,
        host=kwargs.get("host", ServerConfig.HOST),
        port=kwargs.get("port", ServerConfig.PORT),
        workers=kwargs.get("workers", ServerConfig.WORKERS),
        reload=kwargs.get("reload", ServerConfig.RELOAD),
        debug=kwargs.get("debug", ServerConfig.DEBUG),
    )
```

### 3. 分离开发和生产入口

```python
# main.py
import sys
from app_factory import create_app, create_server

if __name__ == "__main__":
    app = create_app()
    
    if len(sys.argv) > 1 and sys.argv[1] == "dev":
        # 开发模式
        server = create_server(app, reload=True, debug=True)
    else:
        # 生产模式
        server = create_server(app)
    
    server.run()
```

**运行**：
```bash
python main.py dev    # 开发模式（热重载）
python main.py        # 生产模式（多进程）
```

---

## 🐳 Docker Compose 示例

```yaml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "8000:8000"
    environment:
      - SERVER_HOST=0.0.0.0
      - SERVER_PORT=8000
      - SERVER_WORKERS=4
      - DEBUG=false
    volumes:
      - ./src:/app/src  # 仅开发环境
    restart: unless-stopped

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf:ro
    depends_on:
      - app
```

---

## 📈 性能监控

### 检查进程

```bash
# 查看 Python 进程
ps aux | grep python

# 查看占用端口
lsof -i :8000

# 实时监控
watch -n 1 'ps aux | grep python'
```

### 性能指标

```python
import asyncio
from aurimyth.foundation_kit.common.logging import logger

async def log_performance():
    """定期记录性能指标"""
    import psutil
    import os
    
    process = psutil.Process(os.getpid())
    
    while True:
        await asyncio.sleep(60)  # 每分钟
        
        memory = process.memory_info().rss / 1024 / 1024  # MB
        cpu_percent = process.cpu_percent(interval=1)
        
        logger.info(
            f"性能指标 | "
            f"内存: {memory:.1f}MB | "
            f"CPU: {cpu_percent}%"
        )
```

---

## ✅ 常见问题

### Q: 怎样在生产环境中使用？

A: 使用 Gunicorn 或 Systemd：

```bash
# 使用 Gunicorn
gunicorn -w 4 -b 0.0.0.0:8000 main:app

# 或使用 Uvicorn + Gunicorn
gunicorn -k uvicorn.workers.UvicornWorker -w 4 -b 0.0.0.0:8000 main:app
```

### Q: 如何实现优雅重启？

A: 使用信号处理：

```python
import signal

def handle_reload(signum, frame):
    logger.info("收到重载信号，即将优雅重启...")
    # 框架会自动处理

signal.signal(signal.SIGUSR1, handle_reload)
```

### Q: 能监听多个端口吗？

A: 使用多个服务器实例：

```python
async def run_multiple_servers():
    server1 = ApplicationServer(app, port=8000)
    server2 = ApplicationServer(app, port=8001)
    
    await asyncio.gather(
        server1.run_async(),
        server2.run_async(),
    )
```

---

## 总结

✅ **简单高效** - 一行代码启动服务器  
✅ **灵活配置** - 支持代码和环境变量配置  
✅ **生产就绪** - 多进程、SSL、优雅关闭  
✅ **性能优秀** - 支持 uvloop、httptools  
✅ **开发友好** - 热重载、调试模式  
✅ **集成完整** - 与 AuriMyth FK 深度集成  

AuriMyth Foundation Kit 的 uvicorn 集成是**开箱即用的生产级服务器管理**！















