# WebSocket 长连接数据库管理指南

## 问题描述

在 WebSocket 长连接中，**不能使用 `Depends()` 注入数据库连接**，原因是：

1. **长期占用连接池** - WebSocket 连接可能持续数小时，如果用 `Depends()` 注入会一直占用一个连接
2. **连接池耗尽** - 多个并发 WebSocket 连接会快速耗尽连接池，导致新请求无法获取连接
3. **内存泄漏** - 长时间持有连接对象会导致资源泄漏

**✅ 正确的做法**: 每次需要数据库操作时，临时获取会话，操作后立即释放。

---

## 解决方案

### 方案一：按需获取会话（推荐）

在需要数据库操作的时刻，临时获取会话，操作完成后立即释放。

```python
from fastapi import APIRouter, WebSocket
from aurimyth.foundation_kit.infrastructure.database import DatabaseManager

router = APIRouter()

@router.websocket("/ws/chat/{room_id}")
async def websocket_endpoint(websocket: WebSocket, room_id: str):
    await websocket.accept()
    
    db_manager = DatabaseManager.get_instance()
    
    try:
        while True:
            # 1. 接收客户端消息
            data = await websocket.receive_text()
            
            # 2. 需要数据库操作时才获取会话
            async with db_manager.session() as session:
                # 执行数据库操作
                from my_service.app.domain.repository import MessageRepository
                repo = MessageRepository(session)
                
                # 保存消息
                message = await repo.create({
                    "room_id": room_id,
                    "content": data,
                })
            
            # 3. 会话自动关闭，连接返回到连接池
            
            # 4. 发送响应
            await websocket.send_json({
                "status": "ok",
                "message_id": message.id
            })
    
    except Exception as e:
        await websocket.close(code=1011, reason=str(e))
```

**优势**：
- ✅ 连接用完即释放
- ✅ 不会占用连接池
- ✅ 支持长时间连接
- ✅ 代码清晰

---

### 方案二：为长连接预分配专用连接池

如果频繁需要数据库操作，可以为 WebSocket 配置更大的连接池。

```python
# config.py
from aurimyth.foundation_kit.application.config import BaseConfig

class AppConfig(BaseConfig):
    # 根据预期的并发 WebSocket 连接数调整
    database: DatabaseSettings = DatabaseSettings(
        pool_size=50,        # 增加连接池大小
        max_overflow=20,     # 允许溢出连接
        pool_recycle=3600,   # 连接回收时间
    )
```

然后在 WebSocket 中仍然使用**按需获取**的模式：

```python
@router.websocket("/ws/chat/{room_id}")
async def websocket_endpoint(websocket: WebSocket, room_id: str):
    # 即使连接池更大，也要按需获取
    # 不要长时间持有连接
    pass
```

---

### 方案三：使用 create_session() 手动管理（不推荐）

如果确实需要持有长期连接（很少见），可以手动创建和管理：

```python
@router.websocket("/ws/data/stream")
async def websocket_stream(websocket: WebSocket):
    await websocket.accept()
    
    db_manager = DatabaseManager.get_instance()
    
    # ⚠️ 注意：长时间持有连接，必须小心管理
    session = await db_manager.create_session()
    
    try:
        while True:
            data = await websocket.receive_text()
            
            # 使用持有的 session
            result = await session.execute(...)
            
            await websocket.send_json(...)
    
    finally:
        # ⚠️ 务必关闭会话
        await session.close()
```

**注意**：
- ⚠️ 必须在 `finally` 中调用 `await session.close()`
- ⚠️ 只在确实需要时使用（大多数场景不需要）
- ⚠️ 会占用连接池，影响其他请求

---

## 完整示例：群聊应用

```python
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, status
from typing import Set
from aurimyth.foundation_kit.infrastructure.database import DatabaseManager
from my_service.app.domain.repository import ChatRoomRepository, MessageRepository

router = APIRouter()

# 管理活跃的 WebSocket 连接
class ConnectionManager:
    def __init__(self):
        self.active_connections: dict[str, list[WebSocket]] = {}
    
    async def connect(self, room_id: str, websocket: WebSocket):
        await websocket.accept()
        if room_id not in self.active_connections:
            self.active_connections[room_id] = []
        self.active_connections[room_id].append(websocket)
    
    async def disconnect(self, room_id: str, websocket: WebSocket):
        self.active_connections[room_id].remove(websocket)
        if not self.active_connections[room_id]:
            del self.active_connections[room_id]
    
    async def broadcast(self, room_id: str, message: dict):
        if room_id in self.active_connections:
            for connection in self.active_connections[room_id]:
                try:
                    await connection.send_json(message)
                except Exception as e:
                    print(f"广播失败: {e}")

manager = ConnectionManager()

@router.websocket("/ws/chat/{room_id}")
async def websocket_chat(websocket: WebSocket, room_id: str):
    """处理群聊 WebSocket 连接"""
    
    db_manager = DatabaseManager.get_instance()
    
    # 连接
    await manager.connect(room_id, websocket)
    
    try:
        # 1. 验证房间存在
        async with db_manager.session() as session:
            room_repo = ChatRoomRepository(session)
            room = await room_repo.get(room_id)
            if not room:
                await websocket.close(code=status.WS_1008_POLICY_VIOLATION, reason="Room not found")
                return
        
        # 2. 循环处理消息
        while True:
            # 接收消息
            data = await websocket.receive_text()
            
            # 每次操作都临时获取会话
            async with db_manager.session() as session:
                message_repo = MessageRepository(session)
                
                # 保存消息
                message = await message_repo.create({
                    "room_id": room_id,
                    "content": data,
                    "sender_id": getattr(websocket, "user_id", "anonymous"),
                })
                
                # session 自动关闭，连接归还给连接池
            
            # 广播给所有客户端
            await manager.broadcast(room_id, {
                "type": "message",
                "id": message.id,
                "content": data,
                "timestamp": message.created_at.isoformat(),
            })
    
    except WebSocketDisconnect:
        await manager.disconnect(room_id, websocket)
    
    except Exception as e:
        await manager.disconnect(room_id, websocket)
        await websocket.close(code=status.WS_1011_SERVER_ERROR, reason=str(e))
```

---

## 最佳实践总结

| 场景 | 方案 | 适用性 |
|------|------|--------|
| **简单消息处理** | 按需获取会话 | ✅ 推荐 |
| **频繁 DB 操作** | 按需获取 + 调整连接池 | ✅ 推荐 |
| **实时数据流** | 长期持有会话 | ⚠️ 少用 |
| **第三方集成** | 按需获取 + 缓存结果 | ✅ 推荐 |

---

## 关键要点

### ❌ 不要这样做

```python
# ❌ 错误：在路由处理前注入
@router.websocket("/ws/chat/{room_id}")
async def websocket_chat(
    websocket: WebSocket,
    room_id: str,
    session: AsyncSession = Depends(get_session)  # ❌ 会长期占用连接
):
    await websocket.accept()
    # session 会在整个连接期间被占用
```

### ✅ 应该这样做

```python
# ✅ 正确：按需临时获取
@router.websocket("/ws/chat/{room_id}")
async def websocket_chat(websocket: WebSocket, room_id: str):
    await websocket.accept()
    
    db_manager = DatabaseManager.get_instance()
    
    while True:
        data = await websocket.receive_text()
        
        # 只在需要时获取会话
        async with db_manager.session() as session:
            # 使用会话
            pass
        # 会话立即关闭
```

---

## 性能优化建议

### 1. 连接池配置

```python
# 根据预期的并发连接数调整
DatabaseSettings(
    pool_size=20,          # 基础连接数
    max_overflow=10,       # 最多允许溢出的连接
    pool_timeout=30,       # 等待连接的超时时间
    pool_recycle=3600,     # 连接回收时间（1小时）
)
```

### 2. 缓存策略

```python
from aurimyth.foundation_kit.infrastructure.cache import CacheManager

@router.websocket("/ws/feed/{user_id}")
async def websocket_feed(websocket: WebSocket, user_id: str):
    await websocket.accept()
    
    db_manager = DatabaseManager.get_instance()
    cache_manager = CacheManager.get_instance()
    
    while True:
        # 先从缓存读
        cached_data = await cache_manager.get(f"feed:{user_id}")
        if cached_data:
            await websocket.send_json(cached_data)
            continue
        
        # 缓存未命中才查询 DB
        async with db_manager.session() as session:
            data = await fetch_feed(session, user_id)
            await cache_manager.set(f"feed:{user_id}", data, expire=60)
            await websocket.send_json(data)
```

### 3. 连接状态监控

```python
@router.websocket("/ws/monitor")
async def websocket_monitor(websocket: WebSocket):
    await websocket.accept()
    
    db_manager = DatabaseManager.get_instance()
    
    while True:
        try:
            data = await websocket.receive_text()
            
            # 检查连接池状态
            pool_size = db_manager.engine.pool.size()
            checked_out = db_manager.engine.pool.checkedout()
            
            # 如果可用连接少于 3，发送警告
            if pool_size - checked_out < 3:
                await websocket.send_json({
                    "warning": "Connection pool running low"
                })
        
        except WebSocketDisconnect:
            break
```

---

## 相关 API 参考

### DatabaseManager 常用方法

```python
db_manager = DatabaseManager.get_instance()

# 1. 获取会话（推荐）- 自动管理生命周期
async with db_manager.session() as session:
    result = await session.execute(query)

# 2. 手动创建会话（需要自己关闭）
session = await db_manager.create_session()
try:
    result = await session.execute(query)
finally:
    await session.close()

# 3. 健康检查
is_healthy = await db_manager.health_check()

# 4. 获取会话工厂
factory = db_manager.session_factory
session = factory()
```

---

## 常见问题

### Q: WebSocket 连接期间数据库连接断开怎么办？

A: 框架已处理了自动重连：

```python
async with db_manager.session() as session:
    # 会自动检查连接健康状态
    # 如果连接断开，会自动重试（默认 3 次）
    result = await session.execute(query)
```

### Q: 如何限制 WebSocket 连接的最大数量？

A: 使用连接管理器：

```python
class ConnectionManager:
    MAX_CONNECTIONS = 1000
    
    async def connect(self, websocket: WebSocket):
        if len(self.active_connections) >= self.MAX_CONNECTIONS:
            await websocket.close(code=1008, reason="Server is full")
            return False
        # ...
        return True
```

### Q: 多个 WebSocket 共用一个会话可以吗？

A: **不可以**。AsyncSession 不是线程安全的，多个并发任务不能共用一个会话。

### Q: 如何在 WebSocket 中使用 Repository？

A: 与普通 HTTP 请求一样：

```python
from my_service.app.domain.repository import UserRepository

async with db_manager.session() as session:
    repo = UserRepository(session)
    user = await repo.get(user_id)
```

---

## 总结

✅ **推荐做法**：
1. 不使用 `Depends()` 注入数据库连接
2. 在需要操作数据库的时刻，临时获取会话
3. 使用 `async with db_manager.session()` 确保自动关闭
4. 根据需要调整连接池大小

这样可以确保：
- 连接池不会耗尽
- 长连接不会泄漏资源
- 其他 HTTP 请求不会被阻塞
- 支持大量并发连接















