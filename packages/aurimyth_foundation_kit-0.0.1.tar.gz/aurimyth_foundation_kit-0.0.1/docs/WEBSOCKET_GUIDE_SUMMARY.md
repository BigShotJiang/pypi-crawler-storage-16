# WebSocket 连接管理文档总结

## 📝 新增文档

已为框架新增了完整的 WebSocket 长连接数据库管理指南。

### 文件列表

1. **`docs/WEBSOCKET_CONNECTION_MANAGEMENT.md`** - 详细技术指南
2. **`docs/USER_GUIDE.md` 第 15 章** - 用户手册中的 WebSocket 部分

---

## 🎯 核心问题解决

### 问题
在 WebSocket 长连接中，不能使用 `Depends()` 注入数据库连接，因为会：
- 长期占用连接池
- 导致其他请求无连接可用
- 造成资源泄漏

### 解决方案
**按需获取会话** - 在需要数据库操作时临时获取，操作完成后立即释放

```python
# ✅ 正确做法
async with db_manager.session() as session:
    # 使用会话
    result = await session.execute(query)
# 会话自动关闭，连接归还连接池
```

---

## 📚 文档内容概览

### WEBSOCKET_CONNECTION_MANAGEMENT.md

共 **280+ 行**，包含以下部分：

#### 1. 问题描述
- 为什么不能用 `Depends()`
- 长连接的常见问题

#### 2. 三种解决方案
- **方案一**（推荐）: 按需获取会话
- **方案二**: 调整连接池大小
- **方案三**（不推荐）: 长期持有会话

#### 3. 完整示例
- 群聊应用完整代码
- ConnectionManager 类实现
- 广播消息处理

#### 4. 性能优化建议
- 连接池配置
- 缓存策略
- 连接状态监控

#### 5. API 参考
- DatabaseManager 常用方法
- 常见问题解答

### USER_GUIDE.md 第 15 章

包含：
- 基础用法示例
- 连接池配置说明
- 完整的群聊应用示例
- 缓存策略优化
- 指向详细指南的链接

---

## 💡 关键概念

### 1. 连接池占用问题

```
❌ 错误方式（用 Depends）
WebSocket A ────→ 占用连接 A（整个连接期间）
WebSocket B ────→ 占用连接 B（整个连接期间）
WebSocket C ────→ 等待...连接池满了！

✅ 正确方式（按需获取）
WebSocket A ────→ 临时获取 → 操作 → 释放
WebSocket B ────→ 临时获取 → 操作 → 释放
WebSocket C ────→ 临时获取 → 操作 → 释放
```

### 2. 最佳实践

| 做法 | 适用性 | 原因 |
|------|--------|------|
| 按需获取 + 上下文管理器 | ✅ 推荐 | 自动释放，安全可靠 |
| 调整连接池大小 | ✅ 辅助 | 配合按需获取使用 |
| 长期持有会话 | ⚠️ 少用 | 占用资源，难以管理 |
| Depends 注入 | ❌ 禁止 | 导致连接池耗尽 |

### 3. 监控和优化

```python
# 检查连接池状态
pool_size = db_manager.engine.pool.size()
checked_out = db_manager.engine.pool.checkedout()
available = pool_size - checked_out

if available < 3:
    logger.warning("Connection pool running low")
```

---

## 🔧 使用示例对比

### ❌ 不要这样做

```python
@router.websocket("/ws/chat/{room_id}")
async def websocket_chat(
    websocket: WebSocket,
    session: AsyncSession = Depends(get_session)  # ❌ 长期占用
):
    # session 会在整个连接期间被占用
    pass
```

### ✅ 应该这样做

```python
@router.websocket("/ws/chat/{room_id}")
async def websocket_chat(websocket: WebSocket, room_id: str):
    db_manager = DatabaseManager.get_instance()
    
    while True:
        data = await websocket.receive_text()
        
        # 只在需要时获取
        async with db_manager.session() as session:
            result = await session.execute(query)
        # 立即释放
```

---

## 🎯 常见场景解决方案

### 1. 实时聊天

```python
# 按需获取会话，保存消息
async with db_manager.session() as session:
    message = await repo.create({"content": data})
```

### 2. 数据流推送

```python
# 使用缓存减少数据库查询
cached = await cache.get(key)
if not cached:
    async with db_manager.session() as session:
        cached = await fetch_data(session)
```

### 3. 连接状态监控

```python
# 定期检查连接池
pool_status = db_manager.engine.pool.size()
if pool_status > threshold:
    send_alert()
```

### 4. 多客户端同步

```python
# 使用 ConnectionManager 管理连接
manager = ConnectionManager()
await manager.broadcast(room_id, data)
```

---

## 📋 文档指引

### 用户应该先读
1. **USER_GUIDE.md 第 15 章** - 快速了解基本用法
2. **WEBSOCKET_CONNECTION_MANAGEMENT.md** - 深入理解和优化

### 完整阅读顺序
1. 问题描述 - 理解为什么
2. 三种方案 - 知道怎么做
3. 完整示例 - 看真实代码
4. 最佳实践 - 学习优化技巧
5. 常见问题 - 解决遇到的问题

---

## 🔍 框架支持

### DatabaseManager 提供的能力

| 方法 | 用途 | 推荐度 |
|------|------|--------|
| `async with db_manager.session()` | 临时获取会话 | ⭐⭐⭐⭐⭐ |
| `await db_manager.create_session()` | 手动创建会话 | ⭐⭐ |
| `await db_manager.health_check()` | 健康检查 | ⭐⭐⭐ |
| `db_manager.session_factory` | 会话工厂 | ⭐⭐ |

### 配置支持

```python
DatabaseSettings(
    pool_size=50,          # 基础连接数
    max_overflow=20,       # 溢出连接数
    pool_timeout=30,       # 等待超时
    pool_recycle=3600,     # 连接回收时间
    pool_pre_ping=True,    # 连接前 PING
)
```

---

## ✅ 验证清单

- [x] 问题充分说明
- [x] 三种解决方案
- [x] 完整代码示例
- [x] 性能优化建议
- [x] 常见问题解答
- [x] 最佳实践指导
- [x] API 参考文档
- [x] 用户手册集成

---

## 🚀 总结

这份文档完整解决了 WebSocket 长连接中的数据库连接管理问题：

✅ **清晰的问题说明** - 为什么不能用 `Depends()`  
✅ **多个解决方案** - 从基础到高级  
✅ **完整的代码示例** - 可直接使用  
✅ **性能优化建议** - 处理大并发  
✅ **常见问题解答** - 预防踩坑  
✅ **最佳实践指导** - 追求卓越  

用户现在可以**自信地在框架中使用 WebSocket** 🎉















