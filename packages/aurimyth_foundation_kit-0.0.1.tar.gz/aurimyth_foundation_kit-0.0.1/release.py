#!/usr/bin/env python3
"""AuriMyth Foundation Kit - 一键打包并发布到 PyPI

使用方法:
    python release.py [版本号] [test|prod]

参数说明:
    版本号: 要发布的版本号，如 0.0.1 (默认: 0.0.1)
    test:   发布到测试 PyPI (https://test.pypi.org)
    prod:   发布到正式 PyPI (https://pypi.org) - 默认

示例:
    python release.py 0.0.1          # 发布 0.0.1 到正式 PyPI
    python release.py 0.0.1 test     # 发布 0.0.1 到测试 PyPI
    python release.py 0.1.0 prod      # 发布 0.1.0 到正式 PyPI

前置条件:
    1. 已安装 uv: curl -LsSf https://astral.sh/uv/install.sh | sh
    2. 已配置 PyPI Token (见下方说明)

Token 配置 (PyPI 必须使用 API Token):
    方式 1: 环境变量
      export UV_PUBLISH_TOKEN='pypi-xxxx...'
    方式 2: 创建 pypi_key 文件
      echo 'your-token' > pypi_key
    方式 3: keyring
      keyring set https://upload.pypi.org/legacy/ __token__

获取 Token: https://pypi.org/manage/account/token/
"""

import os
import re
import subprocess
import sys
from pathlib import Path

# 颜色输出
class Colors:
    RED = '\033[0;31m'
    GREEN = '\033[0;32m'
    YELLOW = '\033[1;33m'
    BLUE = '\033[0;34m'
    CYAN = '\033[0;36m'
    NC = '\033[0m'  # No Color


def info(msg: str) -> None:
    print(f"{Colors.BLUE}[INFO]{Colors.NC} {msg}")


def success(msg: str) -> None:
    print(f"{Colors.GREEN}[SUCCESS]{Colors.NC} {msg}")


def warning(msg: str) -> None:
    print(f"{Colors.YELLOW}[WARNING]{Colors.NC} {msg}")


def error(msg: str) -> None:
    print(f"{Colors.RED}[ERROR]{Colors.NC} {msg}")
    sys.exit(1)


def validate_version(version: str) -> bool:
    """验证版本号格式"""
    pattern = r'^[0-9]+\.[0-9]+\.[0-9]+(-[a-zA-Z0-9]+)?$'
    if not re.match(pattern, version):
        error(f"无效的版本号格式: {version}\n版本号格式应为: X.Y.Z 或 X.Y.Z-后缀\n示例: 0.0.1, 0.1.0, 1.0.0, 0.0.1-alpha1")
    return True


def check_uv() -> None:
    """检查 uv 是否安装"""
    try:
        result = subprocess.run(['uv', '--version'], capture_output=True, text=True, check=True)
        version = result.stdout.strip().split('\n')[0]
        success(f"uv {version}")
    except (subprocess.CalledProcessError, FileNotFoundError):
        error("未找到 uv，请先安装:\n  curl -LsSf https://astral.sh/uv/install.sh | sh")


def check_git() -> tuple[bool, bool]:
    """检查 Git 状态"""
    info("检查 Git 状态...")
    
    # 检查是否在 Git 仓库中
    try:
        subprocess.run(['git', 'rev-parse', '--git-dir'], 
                      capture_output=True, check=True)
    except subprocess.CalledProcessError:
        error("当前目录不是 Git 仓库")
    
    # 检查是否有未提交的更改
    result = subprocess.run(['git', 'status', '--porcelain'], 
                          capture_output=True, text=True)
    has_changes = bool(result.stdout.strip())
    
    if has_changes:
        warning("存在未提交的更改")
        confirm = input("是否继续? (yes/no): ")
        if confirm != "yes":
            info("已取消")
            sys.exit(0)
    
    # 检查标签是否已存在
    tag = f"v{version}"
    result = subprocess.run(['git', 'rev-parse', tag], 
                          capture_output=True)
    tag_exists = result.returncode == 0
    
    return has_changes, tag_exists


def create_tag(version: str) -> None:
    """创建 Git 标签"""
    tag = f"v{version}"
    info(f"创建 Git 标签 {tag}...")
    
    # 检查标签是否已存在
    result = subprocess.run(['git', 'rev-parse', tag], capture_output=True)
    if result.returncode == 0:
        warning(f"标签 {tag} 已存在")
        confirm = input("是否删除并重新创建? (yes/no): ")
        if confirm == "yes":
            subprocess.run(['git', 'tag', '-d', tag], check=False)
            subprocess.run(['git', 'push', 'origin', f':refs/tags/{tag}'], check=False)
            info("已删除旧标签")
        else:
            info("使用现有标签")
            return
    
    # 创建标签
    try:
        subprocess.run(['git', 'tag', '-a', tag, '-m', f'Release {tag}'], check=True)
        success(f"标签 {tag} 已创建")
    except subprocess.CalledProcessError:
        error("创建标签失败")
    
    # 询问是否推送标签
    push_tag = input("是否推送到远程仓库? (yes/no): ")
    if push_tag == "yes":
        try:
            subprocess.run(['git', 'push', 'origin', tag], check=True)
            success("标签已推送")
        except subprocess.CalledProcessError:
            warning("推送标签失败，但可以继续构建")


def clean() -> None:
    """清理旧的构建文件"""
    info("清理旧的构建文件...")
    dirs_to_remove = ['build', 'dist', '*.egg-info']
    for pattern in dirs_to_remove:
        for path in Path('.').glob(pattern):
            if path.is_dir():
                import shutil
                shutil.rmtree(path, ignore_errors=True)
            else:
                path.unlink(missing_ok=True)
    
    # 清理 aurimyth 下的 egg-info
    for path in Path('aurimyth').glob('*.egg-info'):
        if path.is_dir():
            import shutil
            shutil.rmtree(path, ignore_errors=True)
    
    success("清理完成")


def build() -> None:
    """构建包"""
    info("构建包...")
    try:
        subprocess.run(['uv', 'build'], check=True)
        
        # 显示构建产物
        print()
        info("构建产物:")
        dist_dir = Path('dist')
        if dist_dir.exists():
            for file in dist_dir.iterdir():
                size = file.stat().st_size
                size_mb = size / (1024 * 1024)
                print(f"  - {file.name} ({size_mb:.2f} MB)")
        success("构建完成")
    except subprocess.CalledProcessError:
        error("构建失败")


def check_dist() -> None:
    """检查构建产物"""
    info("检查构建产物...")
    
    dist_dir = Path('dist')
    if not dist_dir.exists() or not any(dist_dir.iterdir()):
        error("dist/ 目录不存在或为空")
    
    # 检查文件
    wheel_files = list(dist_dir.glob('*.whl'))
    sdist_files = list(dist_dir.glob('*.tar.gz'))
    
    if not wheel_files:
        error("未找到 wheel 文件 (.whl)")
    if not sdist_files:
        error("未找到源码分发文件 (.tar.gz)")
    
    # 使用 twine check
    try:
        subprocess.run(['uvx', 'twine', 'check'] + [str(f) for f in dist_dir.iterdir()], 
                     check=True)
        success("检查通过")
    except subprocess.CalledProcessError:
        warning("twine check 发现问题，但可以继续")


def setup_token() -> None:
    """配置 PyPI Token"""
    if 'UV_PUBLISH_TOKEN' not in os.environ:
        # 尝试从 pypi_key 文件读取
        pypi_key_file = Path('pypi_key')
        if pypi_key_file.exists():
            info("从 pypi_key 文件读取 token...")
            os.environ['UV_PUBLISH_TOKEN'] = pypi_key_file.read_text().strip()
        else:
            warning("未设置 UV_PUBLISH_TOKEN 环境变量，也未找到 pypi_key 文件")
            print("Token 配置方式 (PyPI 必须使用 API Token):")
            print("  1. 环境变量: export UV_PUBLISH_TOKEN='pypi-xxxx...'")
            print("  2. 创建 pypi_key 文件: echo 'your-token' > pypi_key")
            print("  3. keyring: keyring set https://upload.pypi.org/legacy/ __token__")
            print()
            info("获取 Token: https://pypi.org/manage/account/token/")
            print()
            confirm = input("是否继续? (yes/no): ")
            if confirm != "yes":
                info("已取消发布")
                sys.exit(0)


def publish(version: str, target: str) -> None:
    """发布到 PyPI"""
    if target == "test":
        pypi_name = "测试 PyPI (test.pypi.org)"
        pypi_url = "https://test.pypi.org/legacy/"
    else:
        pypi_name = "正式 PyPI (pypi.org)"
        pypi_url = ""
    
    print()
    print("=" * 42)
    warning(f"即将发布版本 {Colors.CYAN}v{version}{Colors.NC} 到 {pypi_name}")
    print("=" * 42)
    print()
    info("构建产物:")
    dist_dir = Path('dist')
    for file in dist_dir.iterdir():
        size = file.stat().st_size
        size_mb = size / (1024 * 1024)
        print(f"  - {file.name} ({size_mb:.2f} MB)")
    print()
    
    confirm = input("确认发布? (yes/no): ")
    if confirm != "yes":
        info("已取消发布")
        sys.exit(0)
    
    info("开始上传...")
    try:
        if target == "test":
            subprocess.run(['uv', 'publish', '--publish-url', pypi_url, '--username', '__token__'], 
                         check=True)
        else:
            subprocess.run(['uv', 'publish', '--username', '__token__'], check=True)
        success("发布完成！")
        print()
        if target == "test":
            print("测试安装命令:")
            print(f"  uv add --index-url https://test.pypi.org/simple/ aurimyth-foundation-kit=={version}")
        else:
            print("安装命令:")
            print(f"  uv add aurimyth-foundation-kit=={version}")
    except subprocess.CalledProcessError:
        error("发布失败")


def show_help() -> None:
    """显示帮助信息"""
    print(__doc__)


def main() -> None:
    """主流程"""
    # 解析参数
    version = "0.0.1"
    target = "prod"
    
    if len(sys.argv) > 1:
        if sys.argv[1] in ['-h', '--help']:
            show_help()
            sys.exit(0)
        version = sys.argv[1]
    
    if len(sys.argv) > 2:
        target = sys.argv[2]
    
    # 验证参数
    if target not in ['test', 'prod']:
        error(f"无效的目标参数: {target}\n使用 python release.py --help 查看帮助")
    
    print()
    print("=" * 42)
    print("  AuriMyth Foundation Kit - 发布工具")
    print(f"  版本: {Colors.CYAN}v{version}{Colors.NC}")
    if target == "test":
        print(f"  目标: {Colors.YELLOW}测试 PyPI{Colors.NC}")
    else:
        print(f"  目标: {Colors.GREEN}正式 PyPI{Colors.NC}")
    print("=" * 42)
    print()
    
    # 验证版本号
    validate_version(version)
    print()
    
    # 检查工具
    check_uv()
    print()
    
    # 检查 Git
    has_changes, tag_exists = check_git()
    print()
    
    # 创建标签
    create_tag(version)
    print()
    
    # 清理
    clean()
    print()
    
    # 构建
    build()
    print()
    
    # 检查
    check_dist()
    print()
    
    # 配置 Token
    setup_token()
    print()
    
    # 发布
    publish(version, target)
    
    print()
    success("发布流程完成！")
    print()
    info(f"版本 v{version} 已成功发布到 PyPI")


if __name__ == '__main__':
    main()
