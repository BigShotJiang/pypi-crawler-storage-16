"""服务模块。

提供领域服务基类。
"""

from .base import BaseService

__all__ = [
    "BaseService",
]

