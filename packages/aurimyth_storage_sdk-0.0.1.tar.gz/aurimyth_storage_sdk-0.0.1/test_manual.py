"""手动测试脚本 - 验证 STS 和存储功能。

使用前请填入你的腾讯云配置。
"""

import asyncio
import os
import sys

sys.path.insert(0, ".")

# ============================================================
# 配置区域 - 请填入你的腾讯云配置
# ============================================================
"""

FRONTIS_COS_SECRET_ID=AKIDJVWjvzsjRwGQN9i4ECxUq8E7pLe5Nadc
FRONTIS_COS_SECRET_KEY=rW3QbbUCj4DAuSn7FCxVBlAWtMchdNwI
FRONTIS_COS_REGION=ap-beijing
FRONTIS_COS_BUCKET=xinzhiti-1313914583
"""
# 从环境变量读取，避免硬编码出错
# SECRET_ID = os.getenv("FRONTIS_COS_SECRET_ID", "你的SecretId")
# SECRET_KEY = os.getenv("FRONTIS_COS_SECRET_KEY", "你的SecretKey")
# BUCKET = os.getenv("FRONTIS_COS_BUCKET", "xinzhiti-1313914583")  # 换成你的 bucket，格式: name-appid
# REGION = os.getenv("FRONTIS_COS_REGION", "ap-beijing")
SECRET_ID = "AKIDJVWjvzsjRwGQN9i4ECxUq8E7pLe5Nadc"
SECRET_KEY = "rW3QbbUCj4DAuSn7FCxVBlAWtMchdNwI"
BUCKET = "xinzhiti-1313914583"
REGION = "ap-beijing"
TEST_PATH = "syngent/test/"  # 测试用的路径前缀


# ============================================================
# 测试代码
# ============================================================


async def test_policy_builder():
    """测试 Policy 构建器。"""
    print("\n" + "=" * 60)
    print("测试 Policy 构建器")
    print("=" * 60)

    from aurimyth_storage_sdk.sts.models import ActionType, STSRequest
    from aurimyth_storage_sdk.sts.policy import TencentPolicyBuilder

    builder = TencentPolicyBuilder()
    request = STSRequest(
        bucket=BUCKET,
        region=REGION,
        allow_path=TEST_PATH,
        action_type=ActionType.WRITE,
    )

    policy = builder.build(request)
    print(f"生成的 Policy:\n{policy}")


async def test_tc3_signer():
    """测试 TC3 签名器。"""
    print("\n" + "=" * 60)
    print("测试 TC3 签名器")
    print("=" * 60)

    from aurimyth_storage_sdk.sts.providers.tencent import TencentTC3Signer

    signer = TencentTC3Signer(SECRET_ID, SECRET_KEY)
    headers = signer.sign(
        action="GetFederationToken",
        payload={"Name": "test", "Policy": "{}"},
        timestamp=1702540800,  # 固定时间戳用于测试
    )

    print("生成的请求头:")
    for k, v in headers.items():
        # 截断长值
        display_v = v[:80] + "..." if len(v) > 80 else v
        print(f"  {k}: {display_v}")


async def test_sts_get_credentials():
    """测试获取 STS 临时凭证。"""
    print("\n" + "=" * 60)
    print("测试获取 STS 临时凭证 (GetFederationToken)")
    print("=" * 60)

    from aurimyth_storage_sdk.sts import (
        ActionType,
        ProviderType,
        STSProviderFactory,
        STSRequest,
    )

    provider = STSProviderFactory.create(
        ProviderType.TENCENT,
        secret_id=SECRET_ID,
        secret_key=SECRET_KEY,
    )

    try:
        credentials = await provider.get_credentials(
            STSRequest(
                bucket=BUCKET,
                region=REGION,
                allow_path=TEST_PATH,
                action_type=ActionType.ALL,
                duration_seconds=900,
            )
        )

        print("获取成功！")
        print(f"  AccessKeyId: {credentials.access_key_id[:20]}...")
        print(f"  SecretAccessKey: {credentials.secret_access_key[:20]}...")
        print(f"  SessionToken: {credentials.session_token[:50]}...")
        print(f"  Expiration: {credentials.expiration}")
        print(f"  Region: {credentials.region}")
        print(f"  Endpoint: {credentials.endpoint}")
        print(f"  Bucket: {credentials.bucket}")

        return credentials

    except Exception as e:
        print(f"获取失败: {e}")
        raise


async def test_storage_upload(credentials=None):
    """测试存储上传（需要 aioboto3）。"""
    print("\n" + "=" * 60)
    print("测试存储上传")
    print("=" * 60)

    try:
        from aurimyth_storage_sdk.storage import (
            S3Storage,
            StorageBackend,
            StorageConfig,
            StorageFile,
        )
    except ImportError as e:
        print(f"跳过存储测试，缺少依赖: {e}")
        print("请运行: uv add aioboto3")
        return

    # 如果没有传入凭证，使用长期密钥
    if credentials:
        config = StorageConfig(
            backend=StorageBackend.COS,
            bucket_name=BUCKET,
            region=REGION,
            endpoint=f"https://cos.{REGION}.myqcloud.com",
            access_key_id=credentials.access_key_id,
            access_key_secret=credentials.secret_access_key,
            session_token=credentials.session_token,
        )
    else:
        config = StorageConfig(
            backend=StorageBackend.COS,
            bucket_name=BUCKET,
            region=REGION,
            endpoint=f"https://cos.{REGION}.myqcloud.com",
            access_key_id=SECRET_ID,
            access_key_secret=SECRET_KEY,
        )

    storage = S3Storage(config)

    # 上传测试文件
    test_content = b"Hello from AuriMyth Storage SDK!"
    object_name = f"{TEST_PATH}test_file.txt"

    print(f"上传文件: {object_name}")
    result = await storage.upload_file(
        StorageFile(
            object_name=object_name,
            data=test_content,
            content_type="text/plain",
        )
    )
    print(f"  URL: {result.url}")
    print(f"  ETag: {result.etag}")

    # 检查文件是否存在
    exists = await storage.file_exists(object_name)
    print(f"  文件存在: {exists}")

    # 获取预签名 URL
    presigned_url = await storage.get_file_url(object_name, expires_in=3600)
    print(f"  预签名 URL: {presigned_url[:80]}...")

    # 下载文件
    content = await storage.download_file(object_name)
    print(f"  下载内容: {content.decode()}")

    # 删除文件
    await storage.delete_file(object_name)
    print(f"  已删除文件")


async def test_local_storage():
    """测试本地存储。"""
    print("\n" + "=" * 60)
    print("测试本地存储")
    print("=" * 60)

    from aurimyth_storage_sdk.storage import LocalStorage, StorageFile

    storage = LocalStorage(base_path="./test_storage")

    try:
        # 上传
        result = await storage.upload_file(
            StorageFile(
                object_name="test/hello.txt",
                data=b"Hello, Local Storage!",
            )
        )
        print(f"上传成功: {result.url}")

        # 检查存在
        exists = await storage.file_exists("test/hello.txt")
        print(f"文件存在: {exists}")

        # 下载
        content = await storage.download_file("test/hello.txt")
        print(f"下载内容: {content.decode()}")

        # 删除
        await storage.delete_file("test/hello.txt")
        print("已删除文件")

    finally:
        # 清理测试目录
        import shutil
        shutil.rmtree("./test_storage", ignore_errors=True)


async def main():
    """运行所有测试。"""
    print("=" * 60)
    print("AuriMyth Storage SDK 测试")
    print("=" * 60)

    # 1. 测试 Policy 构建器
    await test_policy_builder()

    # 2. 测试 TC3 签名器
    await test_tc3_signer()

    # 3. 测试本地存储（不需要云配置）
    await test_local_storage()

    # 如果配置了真实的云凭证，继续测试
    if SECRET_ID != "你的SecretId":
        # 4. 测试 STS 获取凭证
        credentials = await test_sts_get_credentials()

        # 5. 测试云存储上传（使用 STS 凭证）
        await test_storage_upload(credentials)
    else:
        print("\n" + "=" * 60)
        print("跳过云服务测试（未配置凭证）")
        print("请在脚本顶部填入你的腾讯云配置后重试")
        print("=" * 60)

    print("\n" + "=" * 60)
    print("测试完成！")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
