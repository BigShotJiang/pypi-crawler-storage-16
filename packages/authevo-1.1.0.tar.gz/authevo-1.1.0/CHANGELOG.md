# Changelog

All notable changes to the Authevo Python SDK will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2024-11-30

### Added
- Initial production release
- Comprehensive exception hierarchy with helpful error messages
- Automatic retry logic with exponential backoff
- Configuration management via environment variables
- Automatic idempotency key generation
- SDK version headers for debugging
- LangChain integration (`VerifiableTool`)
- CrewAI integration (`@verifiable_task` decorator)
- Full async/await support
- Type hints throughout the codebase
- Comprehensive test suite (>90% coverage)

### Features
- Ed25519 cryptographic signatures for all actions
- OPA policy evaluation integration
- Tamper-evident action proofs
- Agent identity management (DID:key format)
- Automatic connection pooling
- Configurable timeouts and retries
- SSL verification control

### Documentation
- Comprehensive README with examples
- API reference documentation
- Framework integration guides
- Basic usage examples
- Error handling examples

[1.0.0]: https://github.com/authevo/authevo-python/releases/tag/v1.0.0
