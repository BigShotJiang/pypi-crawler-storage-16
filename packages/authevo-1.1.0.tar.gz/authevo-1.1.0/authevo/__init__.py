from .agent import AuthevoAgent
from .agent_zk import AuthevoZKAgent, ZKActionResult
"""Authevo Python SDK - Cryptographically verifiable agent actions."""

__version__ = "1.0.0"

from .client import AuthevoClient
from .crypto import KeyPair
from .config import AuthevoConfig
from .local_store import LocalActionStore
from .exceptions import (
    AuthevoError,
    AuthenticationError,
    PolicyDeniedError,
    VerificationError,
    RateLimitError,
    NetworkError,
    IdempotencyError,
    ConfigurationError,
    AgentRevokedError
)

__all__ = [
    # Agents
    "AuthevoAgent",        # Legacy full-payload agent
    "AuthevoZKAgent",      # NEW: Zero-Knowledge agent
    "ZKActionResult",
    # Client & Config
    "AuthevoClient",
    "KeyPair",
    "AuthevoConfig",
    "LocalActionStore",
    # Exceptions
    "AuthevoError",
    "AuthenticationError",
    "PolicyDeniedError",
    "VerificationError",
    "RateLimitError",
    "NetworkError",
    "IdempotencyError",
    "ConfigurationError",
    "AgentRevokedError",
]
