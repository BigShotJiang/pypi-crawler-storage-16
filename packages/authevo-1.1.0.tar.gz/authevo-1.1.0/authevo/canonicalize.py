import canonicaljson
import json

def canonicalize(data: any) -> bytes:
    """
    Canonicalize data to a byte string using RFC 8785 rules.
    Matches json-stable-stringify behavior.
    """
    # canonicaljson.encode_canonical_json returns bytes
    return canonicaljson.encode_canonical_json(data)
