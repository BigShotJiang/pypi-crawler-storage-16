"""
Example: Using Authevo with CrewAI

This example demonstrates how to use Authevo's @verifiable_task decorator with CrewAI.
"""

import asyncio
from authevo import AuthevoAgent
from authevo.crewai import verifiable_task

# Create agent (in practice, this would be shared across tasks)
agent = AuthevoAgent.generate()

@verifiable_task(agent=agent, action="refund")
def process_refund(order_id: str, amount: float):
    """
    Process a refund with Authevo verification.
    
    This function is wrapped with @verifiable_task, which means:
    1. Before executing, it creates a verifiable Authevo action
    2. Policy is evaluated (e.g., refund amount within limits)
    3. Action is signed and submitted to the ledger
    4. Only after verification succeeds does the actual refund logic execute
    """
    print(f"    Executing refund logic for {order_id}: ${amount}")
    
    # Actual refund logic would go here
    # (e.g., call payment provider API)
    
    return {
        "status": "refunded",
        "order_id": order_id,
        "amount": amount
    }

async def main():
    print("=== Authevo + CrewAI Integration Example ===\n")
    
    print(f"[1] Created Agent: {agent.keypair.did}\n")
    
    print("[2] Calling @verifiable_task decorated function...")
    try:
        result = process_refund("order-67890", 75.0)
        print(f"    Result: {result}\n")
        print("✓ CrewAI integration example complete!")
    except Exception as e:
        print(f"    Error: {e}\n")
    finally:
        await agent.close()

if __name__ == "__main__":
    asyncio.run(main())
