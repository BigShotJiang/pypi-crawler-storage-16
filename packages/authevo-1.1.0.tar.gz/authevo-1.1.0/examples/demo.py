import asyncio
import json
from authevo.agent import AuthevoAgent

async def main():
    print("--- Authevo Python SDK Demo ---")
    
    # 1. Generate Agent
    agent = AuthevoAgent.generate()
    print(f"\n[1] Generated Agent")
    print(f"    DID: {agent.keypair.did}")
    print(f"    Public Key: {agent.keypair.public_key_b64}")
    
    # 2. Define Action
    action = "refund"
    payload = {"orderId": "o-123", "amount": 50}
    print(f"\n[2] Preparing Action: {action}")
    print(f"    Payload: {json.dumps(payload)}")
    
    # 3. Sign (Manually for demo, normally execute_action does this)
    # We mock the policy decision for this offline demo
    policy_decision = {
        "decision": "Permit",
        "reason": "Demo policy",
        "policyId": "demo_v1"
    }
    
    timestamp = "2025-01-01T12:00:00Z"
    
    action_obj = {
        "agent": agent.keypair.did,
        "action": action,
        "payload": payload,
        "timestamp": timestamp,
        "policyDecision": policy_decision
    }
    
    from authevo.canonicalize import canonicalize
    canonical_bytes = canonicalize(action_obj)
    signature = agent.keypair.sign(canonical_bytes)
    
    print(f"\n[3] Signed Action")
    print(f"    Canonical bytes: {canonical_bytes}")
    print(f"    Signature: {signature}")
    
    full_proof = {
        **action_obj,
        "proof": {
            "type": "Ed25519Signature2020",
            "verificationMethod": f"{agent.keypair.did}#key-1",
            "signatureValue": signature
        }
    }
    
    print(f"\n[4] Final Proof Object")
    print(json.dumps(full_proof, indent=2))

if __name__ == "__main__":
    asyncio.run(main())
