"""
Example: Using Authevo with LangChain

This example demonstrates how to use Authevo's VerifiableTool with LangChain agents.
"""

import asyncio
from authevo import AuthevoAgent
from authevo.langchain import VerifiableTool

async def main():
    print("=== Authevo + LangChain Integration Example ===\n")
    
    # 1. Create an Authevo agent
    async with AuthevoAgent.generate() as agent:
        print(f"[1] Created Agent: {agent.keypair.did}\n")
        
        # 2. Create a verifiable LangChain tool
        refund_tool = VerifiableTool(
            name="process_refund",
            description="Process a customer refund with policy enforcement and verification",
            authevo_agent=agent,
            action="refund"
        )
        
        print("[2] Created VerifiableTool for LangChain\n")
        
        # 3. Use the tool (this would normally be used by a LangChain agent)
        print("[3] Executing refund action...")
        result = await refund_tool._arun(
            payload={"orderId": "order-12345", "amount": 50.0}
        )
        
        print(f"    Result: {result}\n")
        
        print("✓ LangChain integration example complete!")

if __name__ == "__main__":
    asyncio.run(main())
