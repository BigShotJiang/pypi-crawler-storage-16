import pytest
import json
from authevo.canonicalize import canonicalize

def test_canonicalize_simple():
    data = {"b": 2, "a": 1}
    expected = b'{"a":1,"b":2}'
    assert canonicalize(data) == expected

def test_canonicalize_nested():
    data = {"b": {"y": 2, "x": 1}, "a": [2, 1]}
    # Arrays order should be preserved, keys sorted
    expected = b'{"a":[2,1],"b":{"x":1,"y":2}}'
    assert canonicalize(data) == expected

def test_canonicalize_types():
    data = {"a": True, "b": None, "c": 123}
    expected = b'{"a":true,"b":null,"c":123}'
    assert canonicalize(data) == expected
