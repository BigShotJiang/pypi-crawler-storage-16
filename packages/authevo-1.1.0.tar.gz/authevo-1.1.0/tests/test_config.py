"""
Tests for SDK configuration management.
"""

import os
import pytest
from authevo.config import AuthevoConfig
from authevo.exceptions import ConfigurationError


class TestAuthevoConfig:
    """Test configuration management."""
    
    def test_default_config(self):
        """Test config with default values."""
        config = AuthevoConfig(api_url="https://api.authevo.com")
        
        assert config.api_url == "https://api.authevo.com"
        assert config.api_key is None
        assert config.timeout == 30
        assert config.max_retries == 3
        assert config.verify_ssl is True
    
    def test_custom_config(self):
        """Test config with custom values."""
        config = AuthevoConfig(
            api_url="http://localhost:4000",
            api_key="test_key",
            opa_url="http://localhost:8181",
            timeout=60,
            max_retries=5
        )
        
        assert config.api_url == "http://localhost:4000"
        assert config.api_key == "test_key"
        assert config.opa_url == "http://localhost:8181"
        assert config.timeout == 60
        assert config.max_retries == 5
    
    def test_strips_trailing_slash(self):
        """Test URLs have trailing slashes removed."""
        config = AuthevoConfig(
            api_url="https://api.authevo.com/",
            opa_url="http://opa:8181/"
        )
        
        assert config.api_url == "https://api.authevo.com"
        assert config.opa_url == "http://opa:8181"
    
    def test_invalid_timeout(self):
        """Test error on invalid timeout."""
        with pytest.raises(ConfigurationError):
            AuthevoConfig(api_url="https://test.com", timeout=0)
        
        with pytest.raises(ConfigurationError):
            AuthevoConfig(api_url="https://test.com", timeout=-5)
    
    def test_invalid_max_retries(self):
        """Test error on invalid max_retries."""
        with pytest.raises(ConfigurationError):
            AuthevoConfig(api_url="https://test.com", max_retries=-1)
    
    def test_invalid_api_url(self):
        """Test error on invalid API URL format."""
        with pytest.raises(ConfigurationError):
            AuthevoConfig(api_url="not-a-url")
        
        with pytest.raises(ConfigurationError):
            AuthevoConfig(api_url="ftp://wrong-protocol.com")
    
    def test_from_env_production(self, monkeypatch):
        """Test loading config from environment (production)."""
        monkeypatch.setenv("AUTHEVO_ENV", "production")
        monkeypatch.setenv("AUTHEVO_API_KEY", "prod_key_123")
        monkeypatch.setenv("AUTHEVO_TIMEOUT", "45")
        monkeypatch.setenv("AUTHEVO_MAX_RETRIES", "5")
        
        config = AuthevoConfig.from_env()
        
        assert config.api_url == "https://api.authevo.com"
        assert config.api_key == "prod_key_123"
        assert config.timeout == 45
        assert config.max_retries == 5
    
    def test_from_env_local(self, monkeypatch):
        """Test loading config from environment (local dev)."""
        # Clear production env if set
        monkeypatch.delenv("AUTHEVO_ENV", raising=False)
        
        config = AuthevoConfig.from_env()
        
        # Should default to localhost for dev
        assert "localhost" in config.api_url
    
    def test_from_env_custom_url(self, monkeypatch):
        """Test custom API URL from environment."""
        monkeypatch.setenv("AUTHEVO_API_URL", "https://staging.authevo.com")
        
        config = AuthevoConfig.from_env()
        
        assert config.api_url == "https://staging.authevo.com"
    
    def test_is_production_property(self):
        """Test is_production property."""
        prod_config = AuthevoConfig(api_url="https://api.authevo.com")
        local_config = AuthevoConfig(api_url="http://localhost:4000")
        
        assert prod_config.is_production is True
        assert local_config.is_production is False
    
    def test_is_local_property(self):
        """Test is_local property."""
        local_config = AuthevoConfig(api_url="http://localhost:4000")
        local_config2 = AuthevoConfig(api_url="http://127.0.0.1:4000")
        prod_config = AuthevoConfig(api_url="https://api.authevo.com")
        
        assert local_config.is_local is True
        assert local_config2.is_local is True
        assert prod_config.is_local is False
