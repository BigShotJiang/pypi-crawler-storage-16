import pytest
import base64
from authevo.crypto import KeyPair

def test_keypair_generation():
    kp = KeyPair.generate()
    assert kp.did.startswith("did:key:z")
    assert len(kp.public_key_b64) > 0
    assert len(kp.private_key_b64) > 0

def test_signing():
    kp = KeyPair.generate()
    message = b"hello world"
    signature = kp.sign(message)
    assert len(signature) > 0
    # We could verify with nacl.signing.VerifyKey but let's trust the library for now
    # and just check it produces a valid base64 string
    base64.b64decode(signature)

def test_did_format():
    # Test with a known key if possible, but for now just check structure
    kp = KeyPair.generate()
    # did:key:z...
    parts = kp.did.split(":")
    assert len(parts) == 3
    assert parts[0] == "did"
    assert parts[1] == "key"
    assert parts[2].startswith("z")
