"""
Tests for Authevo exception hierarchy.
"""

import pytest
from authevo.exceptions import (
    AuthevoError,
    AuthenticationError,
    PolicyDeniedError,
    VerificationError,
    RateLimitError,
    NetworkError,
    IdempotencyError,
    ConfigurationError,
    AgentRevokedError
)


def test_base_exception():
    """Test base AuthevoError includes documentation URL."""
    err = AuthevoError("Test error")
    assert "Test error" in str(err)
    assert "docs.authevo.com" in str(err)


def test_authentication_error():
    """Test authentication error has correct message and URL."""
    err = AuthenticationError()
    assert "API key" in str(err)
    assert "authentication" in str(err)


def test_policy_denied_error():
    """Test policy denied error includes reason and policy ID."""
    err = PolicyDeniedError(reason="Amount too high", policy_id="refund_v1")
    assert "refund_v1" in str(err)
    assert "Amount too high" in str(err)
    assert err.reason == "Amount too high"
    assert err.policy_id == "refund_v1"


def test_rate_limit_error():
    """Test rate limit error includes retry_after value."""
    err = RateLimitError(retry_after=120)
    assert err.retry_after == 120
    assert "120" in str(err)


def test_network_error():
    """Test network error with custom message."""
    err = NetworkError("Connection refused")
    assert "Connection refused" in str(err)


def test_agent_revoked_error():
    """Test agent revoked error includes DID."""
    did = "did:key:z6Mktest123"
    err = AgentRevokedError(did)
    assert did in str(err)
    assert err.did == did


def test_exception_inheritance():
    """Test all exceptions inherit from AuthevoError."""
    exceptions = [
        AuthenticationError(),
        PolicyDeniedError("test", "test"),
        VerificationError(),
        RateLimitError(60),
        NetworkError(),
        IdempotencyError(),
        ConfigurationError("test"),
        AgentRevokedError("did:key:test")
    ]
    
    for exc in exceptions:
        assert isinstance(exc, AuthevoError)
        assert isinstance(exc, Exception)
