# auto_classification_generator is now auto_reference_generator

This package has been renamed. Use `pip install auto_reference_generator` instead.

New package: https://pypi.org/project/auto_reference_generator/
