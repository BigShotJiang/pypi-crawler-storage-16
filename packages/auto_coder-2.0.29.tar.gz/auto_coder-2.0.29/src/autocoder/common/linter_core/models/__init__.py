"""
Data models for the linter core module.
"""

from .lint_result import LintResult

__all__ = ['LintResult']
