# autoattn/__init__.py

from .auto import AutoAttention

__all__ = ["AutoAttention"]
