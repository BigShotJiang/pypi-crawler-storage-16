###############################################################################
#
# The MIT License (MIT)
#
# Copyright (c) typedef int GmbH
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
#
###############################################################################

import os

from cffi import FFI

# Try normal import first (works when package is installed or in editable mode)
try:
    from autobahn.nvx._compile_args import get_compile_args
except ImportError:
    # Fallback for CFFI build time (before package installation)
    # CFFI's setuptools integration runs builder modules via execfile() outside
    # of package context, so normal imports fail. Use importlib to dynamically
    # load the module from file path as a workaround.
    import importlib.util
    import sys

    _path = os.path.join(os.path.dirname(__file__), "_compile_args.py")
    spec = importlib.util.spec_from_file_location("autobahn.nvx._compile_args", _path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    get_compile_args = mod.get_compile_args

ffi = FFI()

ffi.cdef(
    """
    void* nvx_utf8vld_new ();

    void nvx_utf8vld_reset (void* utf8vld);

    int nvx_utf8vld_validate (void* utf8vld, const uint8_t* data, size_t length);

    void nvx_utf8vld_free (void* utf8vld);

    int nvx_utf8vld_set_impl(void* utf8vld, int impl);

    int nvx_utf8vld_get_impl(void* utf8vld);

    size_t nvx_utf8vld_get_current_index (void* utf8vld);

    size_t nvx_utf8vld_get_total_index (void* utf8vld);
"""
)

if "AUTOBAHN_USE_NVX" in os.environ and os.environ["AUTOBAHN_USE_NVX"] in ["1", "true"]:
    optional = False  # :noindex:
else:
    optional = True  # :noindex:

# Get appropriate compiler flags for this build context
# See autobahn.nvx._compile_args for details on architecture baseline selection
# and build context detection (wheel distribution vs. local source install)
extra_compile_args = get_compile_args()

with open(os.path.join(os.path.dirname(__file__), "_utf8validator.c")) as fd:
    c_source = fd.read()
    ffi.set_source(
        "_nvx_utf8validator",
        c_source,
        libraries=[],
        extra_compile_args=extra_compile_args,
        optional=optional,
    )


class Utf8Validator:
    """
    :noindex:
    """

    def __init__(self):
        self.ffi = ffi

        from _nvx_utf8validator import lib

        self.lib = lib

        self._vld = self.ffi.gc(self.lib.nvx_utf8vld_new(), self.lib.nvx_utf8vld_free)
        # print(self.lib.nvx_utf8vld_get_impl(self._vld))

    def reset(self):
        self.lib.nvx_utf8vld_reset(self._vld)

    def validate(self, ba):
        res = self.lib.nvx_utf8vld_validate(self._vld, ba, len(ba))
        current_index = self.lib.nvx_utf8vld_get_current_index(self._vld)
        total_index = self.lib.nvx_utf8vld_get_total_index(self._vld)
        return (res >= 0, res == 0, current_index, total_index)


if __name__ == "__main__":
    ffi.compile()
