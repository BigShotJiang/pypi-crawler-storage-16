# Test suite for autocmd
