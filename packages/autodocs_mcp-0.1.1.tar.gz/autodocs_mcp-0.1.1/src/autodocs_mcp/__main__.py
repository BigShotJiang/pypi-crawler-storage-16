"""Entry point for running autodocs-mcp as a module: python -m autodocs_mcp"""

from .cli import main

if __name__ == "__main__":
    main()
