"""MCP server generation and templates."""

from .template import generate_mcp_server

__all__ = ["generate_mcp_server"]


