"""autodocs-mcp: Generate MCP servers from ReadTheDocs documentation."""

__version__ = "0.1.1"
