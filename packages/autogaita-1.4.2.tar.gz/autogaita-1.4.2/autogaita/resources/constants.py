# some constants used throughout autogaita

ISSUES_TXT_FILENAME = "Issues.txt"
CONFIG_JSON_FILENAME = "config.json"
INFO_TEXT_WIDTH = 64
TIME_COL = "Time"
SC_PERCENTAGE_COL = "SC Percentage"
ID_COL = "ID"
