"""Model client module for AI inference."""

from AutoGL_GUI.phone_agent.model.client import ModelClient, ModelConfig

__all__ = ["ModelClient", "ModelConfig"]
