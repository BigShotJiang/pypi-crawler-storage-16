"""Model client module for AI inference."""

from AutoGLM_GUI.phone_agent.model.client import ModelClient, ModelConfig

__all__ = ["ModelClient", "ModelConfig"]
