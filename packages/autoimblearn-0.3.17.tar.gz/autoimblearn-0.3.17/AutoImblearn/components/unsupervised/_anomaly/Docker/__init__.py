# Docker module for anomaly detection models
