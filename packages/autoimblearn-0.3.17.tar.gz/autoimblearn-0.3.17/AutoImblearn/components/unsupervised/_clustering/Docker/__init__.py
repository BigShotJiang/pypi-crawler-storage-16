# Docker module for clustering models
