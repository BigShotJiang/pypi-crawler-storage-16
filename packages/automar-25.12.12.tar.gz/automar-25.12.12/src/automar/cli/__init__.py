"""Command-line interface for Automar."""

from .main import main

__all__ = ["main"]
