"""Configuration management for Automar."""
