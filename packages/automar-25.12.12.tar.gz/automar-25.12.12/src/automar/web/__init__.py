"""Web application for Automar (FastAPI backend + frontend)."""
