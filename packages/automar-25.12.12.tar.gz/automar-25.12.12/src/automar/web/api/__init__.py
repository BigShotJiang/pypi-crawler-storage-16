"""API layer for Automar web application."""
