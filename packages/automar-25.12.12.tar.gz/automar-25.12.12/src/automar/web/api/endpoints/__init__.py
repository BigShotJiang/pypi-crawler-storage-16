"""API endpoints for Automar web application."""
