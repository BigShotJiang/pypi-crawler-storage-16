# -*- coding: utf-8 -*-
"""PCA file operations endpoints."""
from fastapi import APIRouter

router = APIRouter(tags=["files", "pca"])

# Placeholder for future PCA-related endpoints
# Add PCA file operations here when needed
