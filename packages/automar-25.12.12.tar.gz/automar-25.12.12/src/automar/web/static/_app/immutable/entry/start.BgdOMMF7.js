import{l as o,a as r}from"../chunks/CYSscu6h.js";export{o as load_css,r as start};
