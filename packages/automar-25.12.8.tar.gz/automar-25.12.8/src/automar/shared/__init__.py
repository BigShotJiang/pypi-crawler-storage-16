"""Shared infrastructure for Automar (used by CLI and Web)."""
