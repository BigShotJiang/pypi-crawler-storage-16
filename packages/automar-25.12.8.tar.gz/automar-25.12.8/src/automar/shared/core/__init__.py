"""Core business logic for Automar."""
