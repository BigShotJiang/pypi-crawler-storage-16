"""Data storage and persistence for Automar."""
