"""Business logic services for Automar."""
