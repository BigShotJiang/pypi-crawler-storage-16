import{_ as m}from"../chunks/CCvFwjU_.js";export{m as component};
