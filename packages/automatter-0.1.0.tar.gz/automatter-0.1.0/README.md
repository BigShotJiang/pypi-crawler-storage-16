# automatter

A minimal Python package.

## Installation

```bash
pip install automatter
```

## Usage

```python
import automatter

print(automatter.hello())
```
