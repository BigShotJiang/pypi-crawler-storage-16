# from Flask import flask


class Healthcheck:
    def __init__(self):
        self.up = False

    def check(self):
        # TODO: run healthcheck tests
        return False
