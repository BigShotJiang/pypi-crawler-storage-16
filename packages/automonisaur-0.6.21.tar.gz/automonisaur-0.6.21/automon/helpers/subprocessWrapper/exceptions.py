class NotSupportedCommand(Exception):
    pass
