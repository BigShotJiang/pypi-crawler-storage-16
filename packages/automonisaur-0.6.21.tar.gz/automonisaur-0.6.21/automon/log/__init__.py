from automon.helpers.loggingWrapper import *

import warnings

warnings.warn(f'module moved to automon.helpers.loggingWrapper')
