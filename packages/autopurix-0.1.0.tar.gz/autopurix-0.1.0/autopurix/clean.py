import pandas as pd


# <-----remove duplcates------>
def remove_duplicates(df):
    df = df.drop_duplicates()
    return df


# <-----remove null values------>
def remove_null(df):
    return df.dropna(axis=0,how='any')


def remove_sparse_columns(df,max_null_percent:float = 60):
    
    total_rows = len(df)
    if total_rows ==0:
        return
    
    cols_to_drop = []

    for col in df.columns:
        null_percent = (df[col].isnull().sum()/total_rows)*100
        if null_percent >max_null_percent:
          cols_to_drop.append(col)

    df_clean = df.drop(columns=cols_to_drop)

    return df_clean,cols_to_drop



# <-----fill null values as per the method for diffrerent data types------>
def fill_nulls(df,num_strategy='median',cat_strategy='mode'):

    df = df.reset_index(drop=True)

    for col in df.columns:

        #   <-----For categorical data -------->
        if df[col].dtype =='object':

            if cat_strategy=='ffill':
                 df[col] = df[col].ffill()

            elif cat_strategy=='bfill':
               df[col] = df[col].bfill()

            else:
                df[col] = df[col].fillna(df[col].mode()[0])

            if df[col].isnull().any():
        
                df[col] = df[col].fillna(df[col].mode()[0])

      #   <-----For numerical data -------->
        else:
            if num_strategy=='ffill' :
                df[col] =  df[col].ffill()
                

            elif num_strategy=='bfill' :
                 df[col] = df[col].bfill()
                

            elif num_strategy=='mean':
               df[col] = df[col].fillna(df[col].mean())

            else:
                df[col] = df[col].fillna(df[col].median())

            if df[col].isnull().any():
                df[col] = df[col].fillna(df[col].median())
            
    return df

