
import pandas as pd
from .dataLoader import load_data
from .clean import remove_duplicates, fill_nulls, remove_sparse_columns, remove_null as drop_null_rows
from .encode import encoding_training_features, encode_target
from .scale import get_columns_to_scale, scaled_features
from .info import get_detailed_info


def process_data_end_to_end(source: str, 
                            target_column: str=None, 
                            max_null_percent: float = 60, 
                            nan_handling: str = 'fill NaN', 
                            fill_value_tuple: tuple = ('median', 'mode')):

    print("--- 🏁Data Processing Pipeline is Start ---")
    
    df = load_data(source) 
    b_info = get_detailed_info(df)
    df = remove_duplicates(df)
    df, cols_to_drop = remove_sparse_columns(df, max_null_percent=max_null_percent)

    if nan_handling == 'fill NaN' and len(fill_value_tuple) == 2 and all(fill_value_tuple):
        print(f"Fillling Null values using the Methods: {fill_value_tuple}.")
        df = fill_nulls(df, fill_value_tuple[0], fill_value_tuple[1])
    else:
        print(f"Deleting Null values using Dropna.")
        df = drop_null_rows(df)




   # CASE 1: User provided target column
    if target_column is not None:

    # Check if user target_column still exists after cleaning
        if target_column not in df.columns:
            print(f"⚠️ Warning: The target column '{target_column}' was removed during cleaning.")
            
            # Assign last column as new target
            target_column = df.columns[-1]
            print(f"➡️ Automatically assigning new target column: '{target_column}'")
        else:
            print(f"✔ Target column provided by user and valid after cleaning: '{target_column}'")

    # CASE 2: User did NOT provide target column
    else:
        target_column = df.columns[-1]
        print(f"ℹ️ User did not provide target column. Using last column after cleaning: '{target_column}'")
     



    #  target_column = df.columns[-1]
    target_series = df[target_column].reset_index(drop=True)
    df_features = df.drop(columns=[target_column], errors='ignore').reset_index(drop=True)
    
    info = get_detailed_info(df_features)
    training_cols = [col for col in info.get("categorical_columns", []) if col != target_column]

    print("Encoding and Scalling Training Features...")

    processed_features, encoded_dict = encoding_training_features(df_features, training_cols)
    processed_features = processed_features.reset_index(drop=True)

    print(" Encoding target Column...")
    encoded_target_series, le, encoding_info_target = encode_target(target_series)
    encoded_target_series = pd.Series(encoded_target_series).reset_index(drop=True)

    columns_to_scale = get_columns_to_scale(processed_features, encoded_dict, target_column)
    final_features = scaled_features(processed_features, columns_to_scale)
    final_features = final_features.reset_index(drop=True)

    # FINAL SAFE ASSIGNMENT (LENGTH MATCHES)
    final_features[target_column] = encoded_target_series
    a_info = get_detailed_info(final_features)

    print("--- ✅Processing Completed Successfully ✅ ---")

    return final_features, encoded_target_series, b_info,a_info
