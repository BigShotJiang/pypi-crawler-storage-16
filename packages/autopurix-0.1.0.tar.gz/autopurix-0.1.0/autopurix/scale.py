import pandas as pd
from sklearn.preprocessing import StandardScaler

def get_columns_to_scale(df_encoded,encoded_dict,target_col):
    ohe_features = []
    for col,data in encoded_dict.items():
        if data['type'] =='OneHotEncoder':
            ohe_features.extend(data['features_name'])
    
    columns_to_scale = []
    for col in df_encoded.columns:
        if col ==target_col:
            continue
        if col in ohe_features:
            continue

        if pd.api.types.is_numeric_dtype(df_encoded[col]):
            columns_to_scale.append(col)
    return columns_to_scale

def scaled_features(processed_features: pd.DataFrame, columns_to_scale: list):
    """
    केवल निर्दिष्ट (specified) न्यूमेरिकल कॉलम्स पर StandardScaler लागू करता है।
    
    Args:
        processed_features (pd.DataFrame): पूरी DataFrame, जिसमें सभी फीचर्स हैं (9 कॉलम्स)।
        columns_to_scale (list): वे कॉलम जिनके नामों को स्केल करना है (2 नाम)।
        
    Returns:
        pd.DataFrame: स्केल्ड डेटा वापस मूल DataFrame में रखा गया।
    """
    
    # 1. स्केलिंग के लिए आवश्यक डेटा चुनें (2 कॉलम्स)
    df_to_scale = processed_features[columns_to_scale] # ✅ अब यह केवल 2 कॉलम होंगे
    
    scaler = StandardScaler()

    # 2. स्केलिंग लागू करें (NumPy Array में 8 rows, 2 columns होंगी)
    scaled_array = scaler.fit_transform(df_to_scale) 
    
    # 3. स्केल्ड डेटा को DataFrame में वापस लाएं (Columns और Index 2 कॉलम्स के लिए मैच करते हैं)
    scaled_part_df = pd.DataFrame(
        scaled_array, 
        columns=columns_to_scale, 
        index=df_to_scale.index # सही इंडेक्स का उपयोग
    )
    
    # 4. मूल DataFrame की कॉपी लें
    final_df = processed_features.copy() # ✅ पूरे 9 कॉलम्स की कॉपी लें
    
    # 5. केवल स्केल्ड कॉलम्स को बदलें
    final_df[columns_to_scale] = scaled_part_df # ✅ यह केवल 2 कॉलम्स को ओवरराइट करेगा

    return final_df