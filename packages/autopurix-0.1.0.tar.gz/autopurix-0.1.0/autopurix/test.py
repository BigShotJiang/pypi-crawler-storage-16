from dataLoader import load_data
from info import get_detailed_info
from clean import remove_duplicates,remove_null, fill_nulls,remove_sparse_columns
from encode import encoding_training_features,encode_target,encode_test_features
from scale import get_columns_to_scale,scaled_features
from visualize import visualize_distribution,visualize_missing_data
import pandas as pd
import numpy as np




# df = load_data('sample_data.csv')
df = load_data('bottle.csv')
if df is not None:
    # print(df.head())
    info = get_detailed_info(df)
    # print(info)
    # sample_df = df.sample(n=2, random_state=42)
    # visualize_distribution(sample_df)
    print('rows X columns:',info[ "rows"] ,'X',info["columns"])                      # print(info)
                        # print('rows X columns:',info[ "rows"] ,'X',info["columns"]) 
                        # print('Duplicated values before:',info[ "duplicates_count"])
                        # print('null values before:',info["total_nulls"])
                        # SAHI ORDER:

    # visualize_missing_data(df)
    print('dulicated rows:',info["duplicates_count"] ,"total null counts:",info["total_nulls"])
    df = remove_duplicates(df)  # Phir duplicates hataye
    df,cols_to_drop = remove_sparse_columns(df)
    df = fill_nulls(df, num_strategy='bfill', cat_strategy='bfill')  # Pehle nulls fill
    info = get_detailed_info(df)
    print(len(cols_to_drop))
    print('dulicated rows:',info["duplicates_count"] ,"total null counts:",info["total_nulls"])
    print('rows X columns:',info[ "rows"] ,'X',info["columns"]) 
    # sample_cols = df.sample(n=4, axis=1).columns   # 4 random columns only
    # sample_df = df[sample_cols]
    # visualize_distribution(sample_df)
    # info = get_detailed_info(df)


                        # print('rows X columns:',info[ "rows"] ,'X',info["columns"]) 
                        # print('Duplicated values after:',info[ "duplicates_count"])
                        # print('null values after:',info["total_nulls"])
                        # print(df.head())
                        # print(info)
                        # # info = get_basic_info(df)



    # print(df.head())
    # target = 'DIC Quality Comment'  #df[['City']
    # remaining_cols = [col for col in info["categorical_columns"] if col != target]

    # df_encoded,encoded_dict =  encoding_training_features(df,remaining_cols)
    # y_encoded, le, encoding_info =  encode_target( df[target])
    # # df_encoded = pd.concat(objs=[df_encoded,pd.DataFrame(y_encoded,columns=["target"])],axis=1)
    # df_encoded[target] =  pd.DataFrame(y_encoded)
    # print(y_encoded)
    # print(df_encoded )
    # columns_to_scale = get_columns_to_scale(df_encoded,encoded_dict, 'target')
    # print(columns_to_scale)
    # df_encoded[columns_to_scale] = scaled_features(df_encoded[columns_to_scale],columns_to_scale)
    # print(df_encoded )


   

    # python test.py