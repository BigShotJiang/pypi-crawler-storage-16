
from setuptools import setup, find_packages

setup(
    name="autopurix",            # PyPI पर package का नाम
    version="0.1.0",             # initial version
    author="Ajay Rajak",
    author_email="rr9133238@gmail.com.com",
    description="Automatic preprocessing library for ML pipelines",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/autopurix",  # optional
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
    install_requires=[
        'pandas',
        'numpy',
        'scikit-learn',
        'seaborn',
        'matplotlib'
    ],
)
