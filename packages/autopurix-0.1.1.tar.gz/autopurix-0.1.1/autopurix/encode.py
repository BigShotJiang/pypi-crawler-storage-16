from sklearn.preprocessing import LabelEncoder,OneHotEncoder
import pandas as pd
import numpy as np




# Help to Encode training columns

def encoding_training_features(df,categorical_cols):

    df_encoded = df.copy()
    encoded_dict = {}

    for col in categorical_cols:
        n_unique = df[col].nunique()

        if(n_unique ==2):
            le = LabelEncoder()
            df_encoded[col] = le.fit_transform(df_encoded[col])
            encoded_dict[col] = {
                'type':'LabelEncoder',
                'name':le,
                'classes':le.classes_.tolist()
                }
            
        elif 3<=n_unique <=20:
            ohe = OneHotEncoder(sparse_output=False,drop='first',handle_unknown='ignore')
            encoded_array = ohe.fit_transform(df_encoded[[col]])
            features_names = ohe.get_feature_names_out([col])

            encoded_df = pd.DataFrame(encoded_array,columns=features_names)
            df_encoded = df_encoded.drop(columns =[col])
            df_encoded = pd.concat(objs=[df_encoded,encoded_df],axis=1)

            encoded_dict[col] = {
                'type':'OneHotEncoder',
                'name':ohe,
                'features_name':features_names.tolist()
                }
        else:
            freq_map = df[col].value_counts().to_dict()
            df_encoded[col] = df[col].map(freq_map)

            encoded_dict[col] = {
                'type':'FrequencyEncoder',
                'name':freq_map,
                'total_categories':n_unique
                }
    return df_encoded,encoded_dict



# Help to Encode taget column

def encode_target(y):
      
    # Agar already numeric hai
    if pd.api.types.is_numeric_dtype(y):
        print("Target is already numeric, no encoding needed")
        return y.values, None, {'type': 'NoEncoding', 'is_numeric': True}
    
    # Agar categorical hai to LabelEncoder use karo
    print(f"Target has {y.nunique()} unique categories, applying LabelEncoder")
    le = LabelEncoder()
    y_encoded = le.fit_transform(y)
    
    encoding_info = {
        'type': 'LabelEncoder',
        'encoder': le,
        'classes': le.classes_.tolist(),
        'class_mapping': dict(zip(le.classes_, le.transform(le.classes_)))
    }
    
    return y_encoded, le, encoding_info



# Help to Encode test columns

def encode_test_features(df, categorical_columns, encoders_dict):
    """
    Test data ko encode karta hai using training ke saved encoders
    """
    
    df_encoded = df.copy()
    
    for col in categorical_columns:
        if col not in df.columns:
            continue
            
        if col not in encoders_dict:
            print(f"Warning: No encoder found for column '{col}'")
            continue
        
        encoder_info = encoders_dict[col]
        encoder_type = encoder_info['type']
        
        if encoder_type == 'LabelEncoder':
            le = encoder_info['encoder']
            classes = encoder_info['classes']
            
            # Handle unseen labels by mapping to -1
            def safe_encode(x):
                if x in classes:
                    return classes.index(x)
                else:
                    return -1  # Unknown value
            
            df_encoded[col] = df[col].apply(safe_encode)
        
        elif encoder_type == 'OneHotEncoder':
            ohe = encoder_info['encoder']
            
            # Transform test data
            encoded_array = ohe.transform(df_encoded[[col]])
            feature_names = encoder_info['feature_names']
            
            # Create encoded columns
            encoded_df = pd.DataFrame(encoded_array, columns=feature_names)
            
            # Drop original and add encoded columns
            df_encoded = df_encoded.drop(columns=[col])
            df_encoded = pd.concat([df_encoded, encoded_df], axis=1)
        
        elif encoder_type == 'FrequencyEncoder':
            freq_map = encoder_info['mapping']
            fallback = encoder_info['fallback_value']
            
            # Map frequencies, unknown values get fallback value
            df_encoded[col] = df[col].map(freq_map).fillna(fallback)
    
    return df_encoded