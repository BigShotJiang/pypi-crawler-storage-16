import autopurix


final_features,encoded_target_series, b_info,a_info = autopurix.auto_preprocess(source='bottle.csv',
    # target_column='Cst_Cnt',
    # # max_null_percent=70,
    # nan_handling='fill NaN', 
    # fill_value_tuple=('ffill', 'bfill')
    )



print('rows X columns:',b_info[ "rows"] ,'X',b_info["columns"])
print('Duplicated values before:',b_info[ "duplicates_count"])
print('null values before:',b_info["total_nulls"])
print('\n')
print(final_features.tail(10))
print('\n')
print('rows X columns:',a_info[ "rows"] ,'X',a_info["columns"])
print('Duplicated values before:',a_info[ "duplicates_count"])
print('null values before:',a_info["total_nulls"])