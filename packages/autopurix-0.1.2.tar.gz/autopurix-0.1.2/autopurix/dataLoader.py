import pandas as pd
import os
from urllib.parse import urlparse
from io import BytesIO, StringIO

def load_data(source):
    try:
        # If already DataFrame
        if isinstance(source, pd.DataFrame):
            return source

        # If file-like object (Streamlit, Flask, Django)
        if hasattr(source, "read"):
            content = source.read()
            
            # Try CSV
            try:
                return pd.read_csv(StringIO(content.decode("utf-8")))
            except:
                pass

            # Try Excel
            try:
                return pd.read_excel(BytesIO(content))
            except:
                pass

            # Try JSON
            try:
                return pd.read_json(StringIO(content.decode("utf-8")))
            except:
                pass

            raise ValueError("Unsupported uploaded file format")

        # If source is URL
        if isinstance(source, str) and source.lower().startswith(("http://", "https://")):
            path = urlparse(source).path
            ext = os.path.splitext(path)[-1].lower()
        else:
            # File path on disk
            ext = os.path.splitext(str(source))[-1].lower()

        # Handle based on extension
        if ext == ".csv":
            return pd.read_csv(source)
        elif ext == ".json":
            return pd.read_json(source)
        elif ext == ".xlsx":
            return pd.read_excel(source)
        else:
            raise ValueError(f"Unsupported file extension: {ext}")

    except Exception as e:
        print("Error loading data:", e)
        return None
