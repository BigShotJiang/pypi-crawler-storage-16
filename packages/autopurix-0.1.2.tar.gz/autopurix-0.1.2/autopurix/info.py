import pandas as pd
import numpy as np

def get_detailed_info(df):
   
    info = {
        "rows": df.shape[0],
        "columns": df.shape[1],
        "columns_names": df.columns.tolist(),
        "numerical_columns": df.select_dtypes(include='number').columns.tolist(),
        "categorical_columns": df.select_dtypes(exclude='number').columns.tolist(),
        "total_nulls": df.isnull().sum().sum().item(),
        "null_count": df.isnull().sum().to_dict(),
        "duplicates_count": df.duplicated().sum().item(),
        "memory_usage_mb": round(df.memory_usage(deep=True).sum() / (1024 * 1024), 2)
    }
    
    # Categorical columns ki detailed statistics
    categorical_stats = {}
    
    for col in info["categorical_columns"]:
        if col in df.columns:
            null_count = df[col].isnull().sum().item()
            col_stats = {
                "unique_values": df[col].nunique(),
                "value_counts": df[col].value_counts(dropna=False).to_dict(),
                "null_count":null_count,
                "mode": df[col].mode().iloc[0] if not df[col].mode().empty else None,
                "mode_count": df[col].value_counts().iloc[0] if not df[col].value_counts().empty else 0,
                "null_percent":(null_count/len(df))*100 if len(df)>0 else 0.0
            }
            categorical_stats[col] = col_stats
    
    info["categorical_stats"] = categorical_stats
    
    # Numerical columns ki basic statistics
    numerical_stats = {}
    for col in info["numerical_columns"]:
        null_count = df[col].isnull().sum().item()
        if col in df.columns:
            num_stats = {
                "min": float(df[col].min()) if not df[col].empty else None,
                "max": float(df[col].max()) if not df[col].empty else None,
                "mean": float(df[col].mean()) if not df[col].empty else None,
                "median": float(df[col].median()) if not df[col].empty else None,
                "std": float(df[col].std()) if not df[col].empty else None,
                "null_count": null_count,
                "null_percent":(null_count/len(df))*100 if len(df)>0 else 0.0
            }
            numerical_stats[col] = num_stats
    
    info["numerical_stats"] = numerical_stats
    
    return info