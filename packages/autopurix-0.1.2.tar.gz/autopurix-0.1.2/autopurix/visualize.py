import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

def visualize_distribution(df):

    print('starting The visualization...')
    
    numerical_cols = df.select_dtypes(include=['number']).columns.tolist()
    categorical_cols = df.select_dtypes(exclude=['number']).columns.tolist()
    
    plotted_cat_cols_count = len([c for c in categorical_cols if df[c].nunique() < 50])
    
    total_plots = len(numerical_cols) * 2 + plotted_cat_cols_count
    
    nrows_needed = (total_plots + 1) // 2 

    
    FIG_WIDTH = 18 
    HEIGHT_PER_ROW = 8 
    
    fig = plt.figure(figsize=(FIG_WIDTH, nrows_needed * HEIGHT_PER_ROW))

    plot_index = 1

    # Y-अक्ष को नियंत्रित करने के लिए फ़ंक्शन
    def set_y_ticks_interval(ax, interval=1000):
        # ax पर अधिकतम Y-मान प्राप्त करें (अधिकांशतः count)
        y_max = ax.get_ylim()[1]
        
        # 0 से अधिकतम मान तक, दिए गए अंतराल (जैसे 1000) पर टिक मानों की गणना करें
        if y_max > 0:
            tick_values = np.arange(0, y_max, interval)
            # सुनिश्चित करें कि सबसे ऊपरी मान सूची में शामिल हो
            if y_max not in tick_values:
                tick_values = np.append(tick_values, y_max)
            ax.set_yticks(tick_values)
            
    print('visualizing numerical cols...')    
    for col in numerical_cols:
        
        # 1. हिस्टोग्राम
        ax1 = fig.add_subplot(nrows_needed, 2, plot_index)
        sns.histplot(df[col], kde=True, ax=ax1, bins=50)
        ax1.set_title(f'Histogram of {col}')
        # Y-अक्ष टिक सेट करें (जैसे 1000 के अंतराल पर)
        set_y_ticks_interval(ax1, interval=1000)
        plot_index += 1
        
        # 2. बॉक्स प्लॉट
        ax2 = fig.add_subplot(nrows_needed, 2, plot_index)
        valid_values = df[col].dropna()
        if valid_values.nunique() > 1:            # CHECK ADDED
          sns.boxplot(x=valid_values, ax=ax2)
          ax2.set_title(f'Box Plot of {col}')
        else:
         ax2.text(0.5, 0.5, "Not enough variation to plot boxplot",ha='center', va='center', fontsize=12)
        ax2.set_title(f'Box Plot of {col} (Skipped)')
        ax2.set_title(f'Box Plot of {col}')
        plot_index += 1
        
    print('visualization numerical cols completed.')
    print('visualizing categorical cols...')
    for col in categorical_cols:
        
        if df[col].nunique() < 50:
            
            # 3. काउंट प्लॉट
            ax3 = fig.add_subplot(nrows_needed, 2, plot_index)
            sns.countplot(y=df[col], order=df[col].value_counts().index, ax=ax3)
            ax3.set_title(f'Count Plot of {col}')
            
            # X-अक्ष टिक सेट करें (काउंट प्लॉट के लिए X-अक्ष पर ही काउंट होता है)
            set_y_ticks_interval(ax3, interval=1000) 
            
            plot_index += 1
        
        else:
            print(f"Skipping Count Plot for {col}: Too many unique categories ({df[col].nunique()}).")
            
    print('visualization categorical cols completed.')
    
    plt.tight_layout() 
    plt.subplots_adjust(hspace=0.45)
    print('End The visualization...')
    
    plt.show()







def visualize_missing_data(df):
    """
    DataFrame में मिसिंग वैल्यूज़ को विज़ुअलाइज़ करता है।
    
    1. मिसिंग प्रतिशत का बार चार्ट दिखाता है।
    2. मिसिंग पैटर्न का हीटमैप दिखाता है।
    
    Args:
        df (pd.DataFrame): विज़ुअलाइज़ करने के लिए डेटाफ़्रेम।
    """
    
    print("--- ❓ मिसिंग डेटा विज़ुअलाइज़ेशन शुरू ---")
    
    # 1. मिसिंग वैल्यूज़ की गणना और प्रतिशत
    missing_count = df.isnull().sum()
    missing_percent = (missing_count / len(df)) * 100
    
    # केवल उन कॉलम्स को फ़िल्टर करें जहाँ मिसिंग वैल्यूज़ > 0 हैं
    missing_data = pd.DataFrame({
        'Count': missing_count,
        'Percentage': missing_percent
    }).sort_values(by='Percentage', ascending=False)
    
    missing_data = missing_data[missing_data['Percentage'] > 0]
    
    if missing_data.empty:
        print("सभी कॉलम्स में 0 मिसिंग वैल्यूज़ हैं।")
        return
        
    # 2. फ़िगर और सबप्लॉट्स सेट करें
    fig, axes = plt.subplots(nrows=2, ncols=1, figsize=(15, 12))

    # --- प्लॉट 1: मिसिंग प्रतिशत का बार चार्ट ---
    sns.barplot(x=missing_data.index, y='Percentage', data=missing_data, ax=axes[0])
    axes[0].set_title('Percentage of Missing Values per Feature', fontsize=16)
    axes[0].set_ylabel('Missing Percentage (%)')
    axes[0].set_xlabel('Features')
    axes[0].tick_params(axis='x', rotation=45) # X-लेबल घुमाएँ
    
    # --- प्लॉट 2: मिसिंग पैटर्न का हीटमैप ---
    # यहाँ, 1 = Not Missing (उपस्थित), 0 = Missing (अनुपस्थित)
    sns.heatmap(df[missing_data.index].isnull(), cbar=False, cmap='viridis', ax=axes[1])
    axes[1].set_title('Missing Data Pattern Heatmap (Yellow = Missing)', fontsize=16)
    axes[1].set_xlabel('Features')
    axes[1].set_yticklabels('')
    
    plt.tight_layout()
    plt.show()
    
    print("--- विज़ुअलाइज़ेशन समाप्त ---")

# # उपयोग का उदाहरण:
# # visualize_missing_data(your_original_df)