import autosar_data._autosar_data._abstraction._communication
from autosar_data._autosar_data._abstraction._communication import *

__doc__ = autosar_data._autosar_data._abstraction._communication.__doc__
if hasattr(autosar_data._autosar_data._abstraction._communication, "__all__"):
    __all__ = autosar_data._autosar_data._abstraction._communication.__all__
