import autosar_data._autosar_data._abstraction._datatype
from autosar_data._autosar_data._abstraction._datatype import *

__doc__ = autosar_data._autosar_data._abstraction._datatype.__doc__
if hasattr(autosar_data._autosar_data._abstraction._datatype, "__all__"):
    __all__ = autosar_data._autosar_data._abstraction._datatype.__all__
