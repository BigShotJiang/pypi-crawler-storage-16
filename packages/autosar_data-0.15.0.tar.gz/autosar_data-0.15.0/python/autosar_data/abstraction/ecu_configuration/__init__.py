import autosar_data._autosar_data._abstraction._ecu_configuration
from autosar_data._autosar_data._abstraction._ecu_configuration import *

__doc__ = autosar_data._autosar_data._abstraction._ecu_configuration.__doc__
if hasattr(autosar_data._autosar_data._abstraction._ecu_configuration, "__all__"):
    __all__ = autosar_data._autosar_data._abstraction._ecu_configuration.__all__
