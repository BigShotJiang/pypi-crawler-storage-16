import autosar_data._autosar_data._abstraction._software_component
from autosar_data._autosar_data._abstraction._software_component import *

__doc__ = autosar_data._autosar_data._abstraction._software_component.__doc__
if hasattr(autosar_data._autosar_data._abstraction._software_component, "__all__"):
    __all__ = autosar_data._autosar_data._abstraction._software_component.__all__
