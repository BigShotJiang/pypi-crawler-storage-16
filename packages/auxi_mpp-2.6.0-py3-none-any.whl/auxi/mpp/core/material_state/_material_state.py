from auxi.core.objects import Object


class MaterialState(Object):
    """A descriptor of the independent state of a material."""

    ...
