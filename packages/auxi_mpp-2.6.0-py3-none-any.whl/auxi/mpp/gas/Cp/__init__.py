"""Gas constant pressure heat capacity model."""

from ._aly_unary import AlyUnary


__all__ = ["AlyUnary"]
