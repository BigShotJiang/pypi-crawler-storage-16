UNDEFINED_NAME_CODE = "avrae.undefinedName"
MISSING_GVAR_CODE = "avrae.missingGvar"
UNSUPPORTED_IMPORT_CODE = "avrae.unsupportedImport"
