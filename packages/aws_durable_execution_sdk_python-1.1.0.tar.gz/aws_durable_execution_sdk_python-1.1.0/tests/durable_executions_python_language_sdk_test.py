"""Tests for DurableExecutionsPythonLanguageSDK module."""


def test_aws_durable_execution_sdk_python_importable():
    """Test aws_durable_execution_sdk_python is importable."""
    import aws_durable_execution_sdk_python  # noqa: PLC0415, F401
