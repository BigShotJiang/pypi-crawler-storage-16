"""Tests for the amazon-mq-mcp-server."""
