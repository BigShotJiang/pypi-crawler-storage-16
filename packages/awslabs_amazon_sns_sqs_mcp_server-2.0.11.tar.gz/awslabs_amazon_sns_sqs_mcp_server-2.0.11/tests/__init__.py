"""Tests for the amazon-sns-sqs-mcp-server."""
