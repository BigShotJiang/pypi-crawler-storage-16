# Tests for agent scripts functionality
