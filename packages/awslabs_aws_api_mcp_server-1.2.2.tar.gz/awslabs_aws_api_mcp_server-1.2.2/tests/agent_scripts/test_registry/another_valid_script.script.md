---
description: Another valid test script for multiple script testing
---
# Another Valid Script

This is another valid script to test loading multiple scripts.

## Features
- Feature 1
- Feature 2
- Feature 3
