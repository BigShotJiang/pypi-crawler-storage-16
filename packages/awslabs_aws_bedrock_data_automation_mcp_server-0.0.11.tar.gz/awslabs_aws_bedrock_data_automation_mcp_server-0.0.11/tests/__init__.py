"""Tests for the AWS Bedrock Data Automation MCP Server."""
