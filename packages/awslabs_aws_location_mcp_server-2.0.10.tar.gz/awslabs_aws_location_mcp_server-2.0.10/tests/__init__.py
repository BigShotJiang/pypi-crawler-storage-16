"""AWS Location Service MCP Server tests package."""
