"""Tests for the lambda-tool-mcp-server."""
