# uploader.py
# Module to upload runtime scripts to S3 using Terraform S3Object resources

import os
from imports.aws.s3_object import S3Object


class ScriptUploader:
    """
    Uploads all runtime scripts from the scripts/ folder to S3,
    preserving the folder hierarchy.
    """

    def __init__(self, scope, deployment_bucket: str, project_name: str, template_vars: dict = None, bucket_resource=None):
        """
        Initialize the ScriptUploader.

        :param scope: The Terraform scope (typically `self` from the stack)
        :param deployment_bucket: Name of the S3 deployment bucket
        :param project_name: Project name used as prefix in S3 keys
        :param template_vars: Dictionary of variables for template rendering
        :param bucket_resource: Optional S3 bucket resource for dependency management
        """
        self.scope = scope
        self.deployment_bucket = deployment_bucket
        self.project_name = project_name
        self.template_vars = template_vars or {}
        self.bucket_resource = bucket_resource
        self.scripts_dir = os.path.join(os.path.dirname(__file__), "scripts")
        self.uploaded_objects = []

    def upload_all(self) -> list:
        """
        Walk the scripts directory and upload all files to S3.
        
        Returns a list of S3Object resources created.
        """
        if not os.path.exists(self.scripts_dir):
            print(f"[WARNING] Scripts directory not found: {self.scripts_dir}")
            return []

        for root, dirs, files in os.walk(self.scripts_dir):
            for filename in files:
                local_path = os.path.join(root, filename)
                # Get relative path from scripts directory
                relative_path = os.path.relpath(local_path, self.scripts_dir)
                # Build S3 key: <project_name>/<relative_path>
                s3_key = f"{self.project_name}/{relative_path}"
                
                # Create a unique Terraform resource ID
                resource_id = self._make_resource_id(relative_path)
                
                # Read file content
                with open(local_path, "r") as f:
                    content = f.read()
                
                # Apply template rendering if this is a template file
                content = self._render_template(content, relative_path)
                
                # Create S3Object resource
                s3_obj_params = {
                    "bucket": self.deployment_bucket,
                    "key": s3_key,
                    "content": content,
                    "content_type": self._get_content_type(filename)
                }
                
                # Add dependency on bucket if it's managed by Terraform
                if self.bucket_resource is not None:
                    s3_obj_params["depends_on"] = [self.bucket_resource]
                
                s3_obj = S3Object(
                    self.scope,
                    resource_id,
                    **s3_obj_params
                )
                
                self.uploaded_objects.append(s3_obj)
                print(f"[INFO] Registered S3 upload: s3://{self.deployment_bucket}/{s3_key}")

        return self.uploaded_objects

    def _make_resource_id(self, relative_path: str) -> str:
        """
        Create a valid Terraform resource ID from a file path.
        """
        # Replace path separators and dots with underscores
        resource_id = relative_path.replace("/", "_").replace("\\", "_")
        resource_id = resource_id.replace(".", "_").replace("-", "_")
        return f"script_{resource_id}"

    def _get_content_type(self, filename: str) -> str:
        """
        Determine content type based on file extension.
        """
        ext = os.path.splitext(filename)[1].lower()
        content_types = {
            ".sh": "text/x-shellscript",
            ".yml": "text/yaml",
            ".yaml": "text/yaml",
            ".json": "application/json",
            ".service": "text/plain",
            ".timer": "text/plain",
        }
        return content_types.get(ext, "text/plain")
    
    def _render_template(self, content: str, relative_path: str) -> str:
        """
        Render template variables in file content.
        
        :param content: File content
        :param relative_path: Relative path to determine if template rendering is needed
        :return: Rendered content
        """
        # Apply template rendering to all files if template_vars are provided
        if self.template_vars:
            for key, value in self.template_vars.items():
                content = content.replace(f"{{{{{key}}}}}", str(value))
        return content


def upload_runtime_files(scope, deployment_bucket: str, project_name: str, template_vars: dict = None, bucket_resource=None) -> list:
    """
    Convenience function to upload all runtime scripts to S3.
    
    :param scope: The Terraform scope (typically `self` from the stack)
    :param deployment_bucket: Name of the S3 deployment bucket
    :param project_name: Project name used as prefix in S3 keys
    :param template_vars: Dictionary of variables for template rendering
    :param bucket_resource: Optional S3 bucket resource for dependency management
    :returns: List of S3Object resources created
    """
    uploader = ScriptUploader(scope, deployment_bucket, project_name, template_vars, bucket_resource)
    return uploader.upload_all()
