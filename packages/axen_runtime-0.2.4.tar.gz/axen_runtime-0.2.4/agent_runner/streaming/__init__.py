"""Streaming utilities for normalizing and handling generators."""

from .normalizer import normalize_generator

__all__ = ["normalize_generator"]
