# pyremote
A simple and lightweight library for remote function calls

[English](README.md) | [中文](README_CN.md)

## Usage
Here is the most intuitive example

**server.py**

```python
import asyncio
from axirpc import NetworkServer, NetworkConnect


async def on_accept(conn: NetworkConnect):
    say("accept")
    await asyncio.sleep(1)
    conn.disconnect()


server = NetworkServer(("127.0.0.1", 5566), on_accept)


@server.register_func
def say(msg: str):
    print(msg)


async def main():
    await server.run()


asyncio.run(main())
```

**client.py**

```python
import asyncio
from axirpc import NetworkConnect

connect = NetworkConnect(("127.0.0.1", 5566))


@connect.register_func
def say(msg: str):
    print(msg)


async def main():
    await connect.run()


if __name__ == '__main__':
    asyncio.run(main())
```
First run server.py, then run client.py, and "accept" will appear in the client's console before it stops

## Adding Resources
Resources with consistent IDs can be added to both parties using the method above. These resources can then be directly passed as parameters during function calls.

**server.py**
```python
async def on_accept(conn: NetworkConnect):
    say(res)
    await asyncio.sleep(1)
    conn.disconnect()

server = NetworkServer(("127.0.0.1", 5566), on_accept)
res = object()
server.res_man.register(res, uuid.UUID("00000000-0000-0000-0000-000000000000"))

@server.register_func
def say(a):
    print(a)
```

**client.py**
```python
connect = NetworkConnect(("127.0.0.1", 5566))
res = object()
connect.res_man.register(res, uuid.UUID("00000000-0000-0000-0000-000000000000"))

@connect.register_func
def say(a):
    print(a)
```
The running result will now be: `<object object at 0x000001C5AD554F50>`

## Future Tasks
- Add object-oriented support
- More detailed README documentation...
- Add more extension options
- Add logging