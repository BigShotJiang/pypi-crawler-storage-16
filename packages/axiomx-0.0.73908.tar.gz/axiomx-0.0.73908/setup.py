from setuptools import setup, find_packages

setup(
    name="AxiomX",  # rename to your project name
    version="0.0.73908",
    description="A custom Python math library with special functions.",
    author="Eric Joseph",  # change if needed
    packages=find_packages(),
    install_requires=[],
    python_requires=">=3.8",
)
