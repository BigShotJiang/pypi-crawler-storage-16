"""Az-Core CLI module."""

from azcore.cli.main import main

__all__ = ["main"]
