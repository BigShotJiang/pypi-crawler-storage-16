"""
Prompts module for Azcore..

This module will contain prompt templates in markdown format.
Copy your existing prompt files here.
"""

# This module is for prompt template files
# Place your .md prompt files in this directory
