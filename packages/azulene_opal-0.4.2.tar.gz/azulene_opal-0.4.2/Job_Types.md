
# Opal Job Types

This document lists all currently available **Opal job types**, their purpose, required inputs, and example payloads.

You can fetch this list via:

```bash
python -m opal.main jobs get-job-types
```

or in Python:

```python
from opal import jobs
jobs.get_job_types()
```

---

## Overview

| ID                      | Name                                             | Description                                                  |
| ----------------------- | ------------------------------------------------ | ------------------------------------------------------------ |
| `generate_conformers`   | Generate Conformers                              | Generate molecular conformers from SMILES notation           |
| `mp2`                   | MP2 Calculation                                  | Møller–Plesset second-order perturbation theory              |
| `hartree_fock`          | Hartree-Fock Calculation                         | Self-consistent field Hartree–Fock calculation               |
| `ccsd_calculation`      | CCSD Calculation                                 | Coupled Cluster Singles and Doubles                          |
| `xtb_calculation`       | XTB Calculation                                  | Extended tight-binding semi-empirical calculation            |
| `molecular_dynamics`    | Molecular Dynamics                               | Molecular dynamics simulation                                |
| `aqueous_solvation`     | Absolute Aqueous Solvation Free Energy           | Solvation free energy in water                               |
| `relative_fe`           | Relative Free Energy                             | Relative free energy between two molecules in water          |
| `relative_fe_uaa`       | Relative Free Energy for (Unnatural) Amino Acids | Relative FE between two (un)natural amino acid structures    |
| `nonaqueous_solvation`  | Absolute Nonaqueous Solvation Free Energy        | Solvation FE of a solute between two solvents                |
| `reaction_free_energy`  | Aqueous Reaction Free Energy                     | Reaction free energy in aqueous solution                     |
| `deprotonation_fe`      | Deprotonation Free Energy                        | Deprotonation free energy in aqueous solution                |
| `absolute_binding`      | Absolute Binding Free Energy                     | Binding FE of a ligand to a protein in water                 |
| `relative_binding`      | Relative Binding Free Energy                     | Relative binding FE between two ligands                      |
| `relative_binding_uaa`  | Relative Binding FE for (Unnatural) Amino Acids  | Relative binding FE for (un)natural amino acid ligands       |
| `lipid_permeation`      | Lipid Permeation Free Energy                     | FE of permeation through a lipid bilayer                     |
| `pocket_docking`        | Pocket Finding and Ligand Docking                | Pocket finding + docking of a ligand to a protein            |
| `upload_file`           | Upload File                                      | Uploads a file and returns its storage path                  |
| `boltz_prediction`      | Boltz-2 Affinity and Structure Prediction        | Protein–ligand affinity + structure prediction using Boltz-2 |

---

## 1. Generate Conformers (`generate_conformers`)

**Description:** Generate molecular conformers from SMILES notation.

### Input Schema

| Field            | Type   | Required | Default | Description                      |
| ---------------- | ------ | -------- | ------- | -------------------------------- |
| `smiles`         | string | yes      | —       | SMILES of the molecule           |
| `num_conformers` | number | yes      | `5`     | Number of conformers to generate |

### Example Input

```json
{
  "smiles": "CCO",
  "num_conformers": 5
}
```

---

## 2. MP2 Calculation (`mp2`)

**Description:** Møller–Plesset second-order perturbation theory.

### Input Schema

| Field   | Type   | Required | Description                      |
| ------- | ------ | -------- | -------------------------------- |
| `atom`  | string | yes      | Atomic coordinates in XYZ format |
| `basis` | string | yes      | Basis set for the calculation    |

### Example Input

```json
{
  "atom": "H 0 0 0; H 0 0 0.74",
  "basis": "ccpvdz"
}
```

---

## 3. Hartree-Fock Calculation (`hartree_fock`)

**Description:** Self-consistent field Hartree–Fock calculation.

### Input Schema

| Field   | Type   | Required | Description                      |
| ------- | ------ | -------- | -------------------------------- |
| `atom`  | string | yes      | Atomic coordinates in XYZ format |
| `basis` | string | yes      | Basis set for the calculation    |

### Example Input

```json
{
  "atom": "H 0 0 0; F 0 0 1.1",
  "basis": "ccpvdz"
}
```

---

## 4. CCSD Calculation (`ccsd_calculation`)

**Description:** Coupled Cluster Singles and Doubles calculation.

### Input Schema

| Field   | Type   | Required | Description                      |
| ------- | ------ | -------- | -------------------------------- |
| `atom`  | string | yes      | Atomic coordinates in XYZ format |
| `basis` | string | yes      | Basis set for the calculation    |

### Example Input

```json
{
  "atom": "H 0 0 0; H 0 0 0.74",
  "basis": "ccpvdz"
}
```

---

## 5. XTB Calculation (`xtb_calculation`)

**Description:** Extended tight-binding semi-empirical calculation.

### Input Schema

| Field       | Type  | Required | Description                 |
| ----------- | ----- | -------- | --------------------------- |
| `numbers`   | array | yes      | Atomic numbers of the atoms |
| `positions` | array | yes      | 3D coordinates of the atoms |

### Example Input

```json
{
  "numbers": [8, 1, 1],
  "positions": [
    [0, 0, 0],
    [0.96, 0, 0],
    [-0.24, 0.93, 0]
  ]
}
```

---

## 6. Molecular Dynamics (`molecular_dynamics`)

**Description:** Molecular dynamics simulation.

### Input Schema

| Field       | Type  | Required | Description            |
| ----------- | ----- | -------- | ---------------------- |
| `numbers`   | array | yes      | Atomic numbers         |
| `positions` | array | yes      | Initial 3D coordinates |

### Example Input

```json
{
  "numbers": [1, 1],
  "positions": [
    [0, 0, 0],
    [0.74, 0, 0]
  ]
}
```

---

## 7. Absolute Aqueous Solvation Free Energy (`aqueous_solvation`)

**Description:** Absolute solvation free energy of a molecule in water via alchemical transformations.

### Key Input Fields

| Field                  | Type    | Required | Default | Description                                            |
| ---------------------- | ------- | -------- | ------- | ------------------------------------------------------ |
| `smiles`               | string  | yes      | —       | Solute SMILES                                          |
| `protonate`            | boolean | no       | `false` | Protonate at given pH                                  |
| `ph`                   | number  | no       | `7`     | pH for protonation                                     |
| `solvent_equil_length` | number  | no       | `0.08`  | Solvent equilibration length (ns / replica)            |
| `solvent_prod_length`  | number  | no       | `0.4`   | Solvent production length (ns / replica)               |
| `vacuum_equil_length`  | number  | no       | `0.08`  | Vacuum equilibration length (ns / replica)             |
| `vacuum_prod_length`   | number  | no       | `0.4`   | Vacuum production length (ns / replica)                |
| `platform`             | string  | no       | `CUDA`  | OpenMM platform (`CUDA`, `OpenCL`, `CPU`, `Reference`) |
| `protocol_repeats`     | integer | no       | `3`     | # of repeats for uncertainty                           |
| `keep_dirs`            | boolean | no       | `True`  | Keep working directories                               |

### Example Input

```json
{
  "smiles": "CCO"
}
```

---

## 8. Relative Free Energy (`relative_fe`)

**Description:** Relative FE between two molecules in water.

### Key Input Fields

| Field              | Type    | Required | Default | Description                         |
| ------------------ | ------- | -------- | ------- | ----------------------------------- |
| `smiles_a`         | string  | yes      | —       | SMILES of molecule A                |
| `smiles_b`         | string  | yes      | —       | SMILES of molecule B                |
| `protonate`        | boolean | no       | `false` | Protonate at pH                     |
| `ph`               | number  | no       | `7`     | pH value                            |
| `equil_length`     | number  | no       | `0.08`  | Equilibration length (ns / replica) |
| `prod_length`      | number  | no       | `0.4`   | Production length (ns / replica)    |
| `platform`         | string  | no       | `CUDA`  | OpenMM platform                     |
| `protocol_repeats` | integer | no       | `3`     | # of repeats                        |
| `keep_dirs`        | boolean | no       | `True`  | Keep working dirs                   |

### Example Input

```json
{
  "smiles_a": "CCO",
  "smiles_b": "CCC"
}
```

---

## 9. Relative Free Energy for (Unnatural) Amino Acids (`relative_fe_uaa`)

**Description:** Relative FE between two (un)natural amino acid sequences.

### Key Input Fields

| Field              | Type    | Required | Default | Description                                             |
| ------------------ | ------- | -------- | ------- | ------------------------------------------------------- |
| `sequence_a`       | string  | yes      | —       | First peptide sequence (standard codes or UAA notation) |
| `sequence_b`       | string  | yes      | —       | Second peptide sequence                                 |
| `uaa_map`          | object  | no       | —       | Map of placeholders (e.g. `{"x": "pF-Phe"}`)            |
| `protonate`        | boolean | no       | `false` | Protonate at pH                                         |
| `ph`               | number  | no       | `7`     | pH value                                                |
| `equil_length`     | number  | no       | `0.08`  | Equilibration length (ns / replica)                     |
| `prod_length`      | number  | no       | `0.4`   | Production length (ns / replica)                        |
| `platform`         | string  | no       | `CUDA`  | OpenMM platform                                         |
| `protocol_repeats` | integer | no       | `3`     | # of repeats                                            |
| `keep_dirs`        | boolean | no       | `True`  | Keep working dirs                                       |

### Example Input

```json
{
  "sequence_a": "YGH",
  "sequence_b": "<pF-Phe>GH"
}
```

---

## 10. Absolute Nonaqueous Solvation Free Energy (`nonaqueous_solvation`)

**Description:** Solvation FE of a solute between two solvents.

### Key Input Fields

| Field              | Type   | Required | Default | Description                            |
| ------------------ | ------ | -------- | ------- | -------------------------------------- |
| `smiles_solute`    | string | yes      | —       | Solute SMILES                          |
| `smiles_solvent_a` | string | yes      | —       | Solvent A SMILES (`"None"` for vacuum) |
| `smiles_solvent_b` | string | yes      | —       | Solvent B SMILES (`"None"` for vacuum) |
| `equil_length`     | number | no       | `0.08`  | Equilibration length (ns / replica)    |
| `prod_length`      | number | no       | `0.4`   | Production length (ns / replica)       |
| `platform`         | string | no       | `CUDA`  | OpenMM platform                        |

### Example Input

```json
{
  "smiles_solute": "CCO",
  "smiles_solvent_a": "None",
  "smiles_solvent_b": "O"
}
```

---

## 11. Aqueous Reaction Free Energy (`reaction_free_energy`)

**Description:** Reaction free energy in aqueous solution.

### Key Input Fields

| Field                    | Type    | Required | Description                                  |
| ------------------------ | ------- | -------- | -------------------------------------------- |
| `smiles_reactant`        | string  | yes      | Reactants SMILES (comma-separated)           |
| `smiles_product`         | string  | yes      | Products SMILES (comma-separated)            |
| `stoichiometry_reactant` | string  | yes      | Stoichiometry of reactants (comma-separated) |
| `stoichiometry_product`  | string  | yes      | Stoichiometry of products (comma-separated)  |
| `solvent_equil_length`   | number  | no       | Solvent equilibration length                 |
| `solvent_prod_length`    | number  | no       | Solvent production length                    |
| `vacuum_equil_length`    | number  | no       | Vacuum equilibration length                  |
| `vacuum_prod_length`     | number  | no       | Vacuum production length                     |
| `platform`               | string  | no       | OpenMM platform                              |
| `protocol_repeats`       | integer | no       | # of repeats                                 |
| `use_xtb`                | boolean | no       | Use xTB for gas-phase                        |
| `keep_dirs`              | boolean | no       | Keep dirs                                    |

### Example Input

```json
{
  "smiles_reactant": "C(=O)=O,O",
  "smiles_product": "OC(=O)O",
  "stoichiometry_reactant": "1,1",
  "stoichiometry_product": "1",
  "use_xtb": true
}
```

---

## 12. Deprotonation Free Energy (`deprotonation_fe`)

**Description:** Deprotonation free energy in aqueous solution.

### Key Input Fields

| Field                  | Type    | Required | Description                    |
| ---------------------- | ------- | -------- | ------------------------------ |
| `smiles_prot`          | string  | yes      | SMILES of protonated species   |
| `smiles_deprot`        | string  | yes      | SMILES of deprotonated species |
| `solvent_equil_length` | number  | no       | Solvent equilibration          |
| `solvent_prod_length`  | number  | no       | Solvent production             |
| `vacuum_equil_length`  | number  | no       | Vacuum equilibration           |
| `vacuum_prod_length`   | number  | no       | Vacuum production              |
| `platform`             | string  | no       | OpenMM platform                |
| `protocol_repeats`     | integer | no       | # of repeats                   |
| `use_xtb`              | boolean | no       | Use xTB                        |
| `keep_dirs`            | boolean | no       | Keep dirs                      |

### Example Input

```json
{
  "smiles_prot": "C(=O)O",
  "smiles_deprot": "C(=O)[O-]",
  "use_xtb": true
}
```

---

## 13. Absolute Binding Free Energy (`absolute_binding`)

**Description:** Absolute binding FE of a ligand to a protein in water.

### Key Input Fields

| Field                  | Type    | Required | Description                                   |
| ---------------------- | ------- | -------- | --------------------------------------------- |
| `pdb_file`             | file    | yes      | Protein PDB (may optionally contain ligand)   |
| `ligand_sdf_file`      | file    | no       | Ligand SDF file                               |
| `ligand_pdb_file`      | file    | no       | Ligand PDB file                               |
| `ligand_in_pdb_file`   | boolean | no       | Whether ligand is in protein PDB              |
| `ligand_smiles`        | string  | no       | Ligand SMILES (esp. if ligand is only in PDB) |
| `solvent_equil_length` | number  | no       | Ligand solvent equilibration                  |
| `solvent_prod_length`  | number  | no       | Ligand solvent production                     |
| `complex_equil_length` | number  | no       | Complex equilibration                         |
| `complex_prod_length`  | number  | no       | Complex production                            |
| `platform`             | string  | no       | OpenMM platform                               |
| `protocol_repeats`     | integer | no       | # of repeats                                  |
| `keep_dirs`            | boolean | no       | Keep dirs                                     |

### Example Input

```json
{
  "pdb_file": "examples/t4_lysozyme.pdb",
  "ligand_sdf_file": "examples/toluene.sdf"
}
```

---

## 14. Relative Binding Free Energy (`relative_binding`)

**Description:** Relative binding FE between two ligands to the same protein.

### Key Input Fields

| Field                  | Type    | Required | Description                  |
| ---------------------- | ------- | -------- | ---------------------------- |
| `pdb_file`             | file    | yes      | Protein PDB                  |
| `ligand_sdf_file_a`    | file    | no       | First ligand SDF             |
| `ligand_sdf_file_b`    | file    | no       | Second ligand SDF            |
| `ligand_pdb_file_a`    | file    | no       | First ligand PDB             |
| `ligand_pdb_file_b`    | file    | no       | Second ligand PDB            |
| `ligand_in_pdb_file_a` | boolean | no       | First ligand in protein PDB  |
| `ligand_in_pdb_file_b` | boolean | no       | Second ligand in protein PDB |
| `smiles_a`             | string  | no       | SMILES of ligand A           |
| `smiles_b`             | string  | no       | SMILES of ligand B           |
| `protonate`            | boolean | no       | Protonate                    |
| `ph`                   | number  | no       | pH value                     |
| `equil_length`         | number  | no       | Equilibration length         |
| `prod_length`          | number  | no       | Production length            |
| `platform`             | string  | no       | OpenMM platform              |
| `protocol_repeats`     | integer | no       | # of repeats                 |
| `keep_dirs`            | boolean | no       | Keep dirs                    |

### Example Input

```json
{
  "pdb_file": "protein.pdb",
  "ligand_sdf_file_a": "ligandA.sdf",
  "ligand_sdf_file_b": "ligandB.sdf"
}
```

---

## 15. Relative Binding FE for (Unnatural) Amino Acids (`relative_binding_uaa`)

**Description:** Relative binding FE between two (un)natural amino acid ligands.

### Key Input Fields

| Field              | Type    | Required | Description                          |
| ------------------ | ------- | -------- | ------------------------------------ |
| `sequence_a`       | string  | yes      | First peptide sequence               |
| `sequence_b`       | string  | yes      | Second peptide sequence              |
| `pdb_file`         | file    | yes      | PDB file (e.g. from previous job)    |
| `uaa_map`          | object  | no       | Map placeholders to UAA names/SMILES |
| `protonate`        | boolean | no       | Protonate                            |
| `ph`               | number  | no       | pH value                             |
| `equil_length`     | number  | no       | Equilibration                        |
| `prod_length`      | number  | no       | Production                           |
| `platform`         | string  | no       | OpenMM platform                      |
| `protocol_repeats` | integer | no       | # of repeats                         |
| `keep_dirs`        | boolean | no       | Keep dirs                            |

### Example Input

```json
{
  "sequence_a": "YGH",
  "sequence_b": "xGH",
  "pdb_file": "protein.pdb",
  "uaa_map": "{\"x\": \"pF-Phe\"}"
}
```

---

## 16. Lipid Permeation Free Energy (`lipid_permeation`)

**Description:** Free energy of a molecule permeating through a lipid bilayer.

### Key Input Fields

| Field          | Type    | Required | Description                                                         |
| -------------- | ------- | -------- | ------------------------------------------------------------------- |
| `smiles`       | string  | yes      | Solute SMILES                                                       |
| `lipid_type`   | string  | yes      | Lipid type (`DPPC`, `DMPC`, `DOPC`, `DLPE`, `DLPC`, `POPE`, `POPC`) |
| `equil_length` | number  | no       | Equilibration length                                                |
| `prod_length`  | number  | no       | Production length                                                   |
| `platform`     | string  | no       | OpenMM platform                                                     |
| `keep_dirs`    | boolean | no       | Keep dirs                                                           |

### Example Input

```json
{
  "smiles": "O",
  "lipid_type": "POPC"
}
```

---

## 17. Pocket Finding and Ligand Docking (`pocket_docking`)

**Description:** Find the binding pocket and dock a ligand to a protein.

### Key Input Fields

| Field           | Type   | Required | Description           |
| --------------- | ------ | -------- | --------------------- |
| `pdb_file`      | file   | yes      | Protein PDB           |
| `ligand_smiles` | string | yes      | Ligand SMILES         |
| `ph`            | float  | no       | pH value (default: 7) |

### Example Input

```json
{
  "pdb_file": "protein.pdb",
  "ligand_smiles": "CC1=CC=CC=C1"
}
```

---

## 18. Upload File (`upload_file`)

**Description:** Uploads a file and returns its storage path.

### Input Schema

| Field       | Type | Required | Description               |
| ----------- | ---- | -------- | ------------------------- |
| `file_path` | file | yes      | Local file path to upload |

### Example Input

```json
{
  "file_path": "examples/input.txt"
}
```

---

## 19. Boltz-2 Affinity and Structure Prediction (`boltz_prediction`)

**Description:** Boltz-2 based affinity and structure prediction.

### Input Schema

| Field              | Type   | Required | Description                                   |
| ------------------ | ------ | -------- | --------------------------------------------- |
| `protein_sequence` | string | yes      | Protein sequence (one-letter amino acid code) |
| `ligand_smiles`    | string | yes      | Ligand SMILES                                 |

### Example Input

```json
{
  "protein_sequence": "MNIFEMLRIDEGLRLKIYKDTEGYYTIGIGHLLTKSPSLNAAK",
  "ligand_smiles": "CC1=CC=CC=C1"
}
```


---

For live job type info directly on Opal, always refer to:

```bash
python -m opal.main jobs get-job-types
```

or see the [API_Reference.md](API_Reference.md) for usage patterns and CLI/Python examples.



**All Rights Reserved**