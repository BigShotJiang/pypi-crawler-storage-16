"""Signup, signin, refresh, logout, user info."""

import httpx
import typer
import time
from rich import print
from opal import config
from rich import print as rprint

SUPABASE_URL = "https://vdkapdqniiehaweyhhbl.supabase.co"
SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZka2FwZHFuaWllaGF3ZXloaGJsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTE1NzE0MzcsImV4cCI6MjA2NzE0NzQzN30.uKXmjlR4TYQt7jSjzSD2fpgR7a3CW7RcBjYBGhTnAKs"

# ---- CLI Functions ----

# -----------------------------------------
# Login
# -----------------------------------------
def login(email: str, password: str):
    """
    Library function: log in with email + password and save tokens locally.

    Returns:
      {"ok": True, "session": {...}} on success
      {"ok": False, "status_code": int, "error": str} on failure
    """
    url = f"{SUPABASE_URL}/auth/v1/token?grant_type=password"
    headers = {
        "apikey": SUPABASE_ANON_KEY,
        "Content-Type": "application/json",
    }
    payload = {"email": email, "password": password}

    r = httpx.post(url, headers=headers, json=payload)
    if r.status_code == 200:
        session = r.json()
        config.save_tokens(
            access_token=session["access_token"],
            refresh_token=session["refresh_token"],
            expires_in=session["expires_in"],
        )
        return {"ok": True, "message": "Logged in successfully!"}
    else:
        try:
            body = r.json()
            msg = body.get("msg") or body.get("error_description") or r.text
        except Exception:
            msg = r.text
        return {"ok": False, "status_code": r.status_code, "error": msg}


def login_cli(
    email: str = typer.Option(
        None,
        "--email",
        prompt=False,
        hide_input=False,
        help="Your account email (leave out to be prompted securely)",
    ),
    password: str = typer.Option(
        None,
        "--password",
        prompt=False,
        hide_input=True,
        help="Your password (leave out to be prompted securely)",
    ),
):
    """CLI wrapper for login()."""
    if email is None:
        email = typer.prompt("Your email", hide_input=False)

    if password is None:
        # Secure prompt: input is hidden and not shown in the terminal or shell history
        password = typer.prompt("Your password", hide_input=True)

    result = login(email=email, password=password)
    if result.get("ok"):
        rprint("[green]✅ Logged in successfully![/green]")
    else:
        rprint(f"[red]❌ Login failed: {result.get('error')}[/red]")
# -----------------------------------------
# Logout
# -----------------------------------------
def logout():
    """
    Library function: log out by clearing local tokens.

    Returns:
      {"ok": True}
    """
    config.clear_tokens()
    return {"ok": True}


def logout_cli():
    """CLI wrapper for logout()."""
    result = logout()
    if result.get("ok"):
        rprint("[green]👋 Logged out successfully.[/green]")
    else:
        # This "else" almost never happens, but it's here for symmetry
        rprint("[red]❌ Failed to log out.[/red]")

# -----------------------------------------
# Who Am I
# -----------------------------------------
def whoami():
    """Fetch user info from Azulene Opal using the stored access token."""
    try:
        token = config.get_access_token()
    except config.TokenExpiredException:
        # Token expired: try to refresh via your existing helper
        try:
            token = refresh_session()
        except Exception as e:
            return {
                "ok": False,
                "code": "auth_refresh_failed",
                "error": str(e),
            }
    except config.NotLoggedInException:
        return {
            "ok": False,
            "code": "not_logged_in",
            "error": "You are not logged in. Please run `opal login`.",
        }

    url = f"{SUPABASE_URL}/auth/v1/user"
    headers = {
        "Authorization": f"Bearer {token}",
        "apikey": SUPABASE_ANON_KEY,
        "Content-Type": "application/json",
    }

    r = httpx.get(url, headers=headers)
    if r.status_code == 200:
        u = r.json()
        app = u.get("app_metadata") or {}
        meta = u.get("user_metadata") or {}

        slim = {
            "email": u.get("email"),
            "provider": app.get("provider"),
            "approved": app.get("approved", meta.get("approved")),
            "role": app.get("role", meta.get("role")),
            "email_verified": meta.get("email_verified"),
            "phone_verified": meta.get("phone_verified"),
            "confirmed": bool(u.get("confirmed_at")),
            "last_sign_in_at": u.get("last_sign_in_at"),
            "created_at": u.get("created_at"),
        }

        # drop any None values for a cleaner object
        slim = {k: v for k, v in slim.items() if v is not None}

        return {
            "ok": True,
            "user": slim,
        }
    else:
        try:
            body = r.json()
            msg = body.get("msg") or body.get("error_description") or r.text
        except Exception:
            msg = r.text
        return {
            "ok": False,
            "status_code": r.status_code,
            "error": msg,
        }


def whoami_cli():
    """CLI wrapper for whoami()."""
    result = whoami()

    if result.get("ok"):
        rprint("[blue]📄 Logged in as:[/blue]")
        rprint(result["user"])
    else:
        code = result.get("code")
        if code == "not_logged_in":
            rprint(f"[red]❌ {result.get('error')}[/red]")
        elif code == "auth_refresh_failed":
            rprint(f"[red]❌ Failed to refresh session:[/red] {result.get('error')}")
        else:
            rprint(
                f"[red]❌ Failed to fetch user info:[/red] {result.get('error')} "
                f"(status {result.get('status_code')})"
            )

# -----------------------------------------
# Refresh Session
# -----------------------------------------
def refresh_session() -> str:
    """
    Refresh the access token using the refresh token.

    Returns:
        New access token as string

    Raises:
        Exception if refresh fails
    """
    try:
        refresh_token = config.get_refresh_token()
    except Exception as e:
        raise Exception("You are not logged in. Please run `opal login`.") from e

    url = f"{SUPABASE_URL}/auth/v1/token?grant_type=refresh_token"
    headers = {
        "apikey": SUPABASE_ANON_KEY,
        "Content-Type": "application/json"
    }
    payload = {"refresh_token": refresh_token}

    r = httpx.post(url, headers=headers, json=payload)
    if r.status_code == 200:
        session = r.json()
        config.save_tokens(
            access_token=session["access_token"],
            refresh_token=session["refresh_token"],
            expires_in=session["expires_in"]
        )
        print("[green]🔁 Access token refreshed successfully.[/green]")
        return session["access_token"]
    else:
        raise Exception(f"❌ Failed to refresh token: {r.json().get('msg', r.text)}")
    