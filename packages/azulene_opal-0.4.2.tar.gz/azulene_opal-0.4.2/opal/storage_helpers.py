from pathlib import Path
import os, time, secrets, string, mimetypes, httpx
from opal.auth import SUPABASE_ANON_KEY, SUPABASE_URL

def _is_remote_url(s: str) -> bool:
    return s.startswith(("http://", "https://", "file://", "s3://", "gs://"))

def _is_storage_key(s: str) -> bool:
    # leading UUID (36 chars, 4 hyphens) before first '/'
    try:
        first = s.split("/", 1)[0]
        return len(first) == 36 and first.count("-") == 4
    except Exception:
        return False

def _looks_like_local_candidate(s: str) -> bool:
    # has a slash or backslash, not a URL, not a storage key
    return (("\\" in s) or ("/" in s)) and not _is_remote_url(s) and not _is_storage_key(s)

def _exists_local_file(s: str) -> bool:
    try:
        return Path(os.path.expanduser(s)).is_file()
    except Exception:
        return False

def _has_local_files(obj) -> bool:
    """pre-scan: return True if any string in obj is an existing local file."""
    if isinstance(obj, dict):
        return any(_has_local_files(v) for v in obj.values())
    if isinstance(obj, list):
        return any(_has_local_files(v) for v in obj)
    if isinstance(obj, str):
        return _looks_like_local_candidate(obj) and _exists_local_file(obj)
    return False

def _guess_content_type(path: str) -> str:
    ctype, _ = mimetypes.guess_type(path)
    return ctype or "application/octet-stream"

def _build_storage_key(user_id: str, filename: str) -> str:
    return f"{user_id}/{os.path.basename(filename)}"

STORAGE_BUCKET = "job-inputs"

def _upload_local_file_to_storage(local_path: str, token: str, storage_key: str) -> None:
    url = f"{SUPABASE_URL}/storage/v1/object/{STORAGE_BUCKET}/{storage_key}"
    headers = {
        "Authorization": f"Bearer {token}",
        "apikey": SUPABASE_ANON_KEY,
        "Content-Type": _guess_content_type(local_path),
    }
    with open(local_path, "rb") as f:
        r = httpx.put(url, headers=headers, content=f, timeout=120)
    if r.status_code not in (200, 201):
        raise RuntimeError(f"Upload failed ({r.status_code}): {r.text}")
    

def _transform_input_files(obj, *, token: str, user_id: str):
    if isinstance(obj, dict):
        return {k: _transform_input_files(v, token=token, user_id=user_id) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [_transform_input_files(v, token=token, user_id=user_id) for v in obj]
    elif isinstance(obj, str):
        # If it's a local file, upload and replace with storage key; otherwise return as-is
        if _is_storage_key(obj) or _is_remote_url(obj):
            return obj
        if _exists_local_file(obj):
            storage_key = _build_storage_key(user_id, obj)
            _upload_local_file_to_storage(obj, token, storage_key)
            print(f"[cyan]📤 Uploaded file → {STORAGE_BUCKET}/{storage_key}[/cyan]")
            return storage_key
        return obj
    else:
        return obj