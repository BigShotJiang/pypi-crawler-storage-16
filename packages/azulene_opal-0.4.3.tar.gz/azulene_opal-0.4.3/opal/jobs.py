# Submit, cancel, get, poll
import os
import json
import time
import httpx
import typer
from opal import config, auth
from opal.auth import SUPABASE_ANON_KEY, SUPABASE_URL
from opal.storage_helpers import _has_local_files, _transform_input_files, _upload_local_file_to_storage, _build_storage_key
from rich import print as rprint
from typing import Any, Dict, List, Optional, Union
# ---------------------
# Internal
# ---------------------

def _auth_headers():
    try:
        token = config.get_access_token()
    except config.TokenExpiredException:
        # Token expired: try to refresh
        token = auth.refresh_session()
    except config.NotLoggedInException:
        # Not logged in: handle as you wish
        raise Exception("You are not logged in. Please run `opal login`.")

    return {
        "Authorization": f"Bearer {token}",
        "apikey": SUPABASE_ANON_KEY,
        "Content-Type": "application/json"
    }


def _get_token_only() -> str:
    try:
        token = config.get_access_token()
    except config.TokenExpiredException:
        token = auth.refresh_session()
    except config.NotLoggedInException:
        raise Exception("You are not logged in. Please run `opal login`.")
    return token


def _get_user() -> dict:
    url = f"{SUPABASE_URL}/auth/v1/user"
    r = httpx.get(url, headers=_auth_headers())
    if r.status_code == 200:
        return r.json()
    else:
        raise Exception(f"Failed to fetch user info: {r.text}")

# ---------------------
# Python API functions
# ---------------------

def check_health():
    """
    Library function.
    Returns:
      {"ok": True, "data": {...}} on success
      {"ok": False, "status_code": int, "error": str} on failure
    """
    url = f"{SUPABASE_URL}/functions/v1/check-health"
    r = httpx.get(url, headers=_auth_headers())
    if r.status_code == 200:
        return {"ok": True, "data": r.json()}
    else:
        return {"ok": False, "status_code": r.status_code, "error": r.text}


def check_health_cli():
    """CLI wrapper for `check_health`."""
    result = check_health()
    if result.get("ok"):
        rprint("[green]✅ Health check passed[/green]")
        rprint(result["data"])
    else:
        rprint("[red]❌ Health check failed:[/red]", result.get("error"), f"(status {result.get('status_code')})")

def submit(
    job_type: str,
    input_data,
):
    """
    Library function to submit a job.

    Args:
      job_type: e.g. "process_txt"
      input_data: JSON string or dict

    Returns:
      {"ok": True, "data": {...}} on success
      {"ok": False, "status_code": int, "error": str} on HTTP failure
      {"ok": False, "error": str, "stage": "auth" | "file_handling"} on local failures
    """
    submit_url = f"{SUPABASE_URL}/functions/v1/submit-job"

    # Parse JSON string or accept dict
    parsed_input = json.loads(input_data) if isinstance(input_data, str) else input_data

    # First path: if no local files detected, just submit
    if not _has_local_files(parsed_input):
        r = httpx.post(
            submit_url,
            headers=_auth_headers(),
            json={
                "job_type": job_type,
                "input_data": parsed_input,
            },
            timeout=60,
        )
        if r.status_code == 200:
            return {"ok": True, "data": r.json()}
        else:
            return {"ok": False, "status_code": r.status_code, "error": r.text}

    # Second path: we do have local files --> fetch token & user once, upload, then submit
    try:
        token = _get_token_only()   # reuse your existing helper
        user = _get_user()          # calls /auth/v1/user once
        user_id = user.get("id")
    except Exception as e:
        return {"ok": False, "error": str(e), "stage": "auth"}

    try:
        transformed = _transform_input_files(parsed_input, token=token, user_id=user_id)
    except Exception as e:
        return {"ok": False, "error": str(e), "stage": "file_handling"}

    # Build headers without re-fetching token (use the one we already have)
    headers = {
        "Authorization": f"Bearer {token}",
        "apikey": SUPABASE_ANON_KEY,
        "Content-Type": "application/json",
    }

    r = httpx.post(
        submit_url,
        headers=headers,
        json={
            "job_type": job_type,
            "input_data": transformed,
        },
        timeout=60,
    )
    if r.status_code == 200:
        return {"ok": True, "data": r.json()}
    else:
        return {"ok": False, "status_code": r.status_code, "error": r.text}


def submit_cli(
    job_type: str = typer.Option(..., "--job-type", help="e.g., process_txt"),
    input_data: str = typer.Option(..., "--input-data", help='JSON string like \'{"file_url": "C:/path/to.txt"}\''),
):
    """CLI wrapper for `submit`."""
    result = submit(job_type=job_type, input_data=input_data)

    if result.get("ok"):
        rprint("[green]✅ Job submitted successfully[/green]")
        rprint(result["data"])
    else:
        stage = result.get("stage")
        if stage == "auth":
            rprint(f"[red]❌ Auth error during job submission:[/red] {result.get('error')}")
        elif stage == "file_handling":
            rprint(f"[red]❌ File handling failed:[/red] {result.get('error')}")
        else:
            rprint("[red]❌ Job submission failed:[/red]", result.get("error"), f"(status {result.get('status_code')})")


def submit_batch_jobs(
    job_type: str,
    input_data: List[Union[Dict[str, Any], str]],
) -> Dict[str, Any]:
    """
    Submit a batch of jobs for a given job_type.

    Args:
        job_type:
            The job_type to use for every job (e.g. "absolute_solvation_energy_aqueous").
        input_data:
            A list where each element is a single job's input_data.
            Each element is exactly what you'd normally pass into submit(..., input_data=...):
              - a dict (preferred), or
              - a JSON string.

    Returns:
        {"ok": True, "results": [ { "index": i, "input": <input>, "response": <submit_result> }, ... ]}
    """
    results: List[Dict[str, Any]] = []

    for idx, inp in enumerate(input_data):
        try:
            single_result = submit(job_type=job_type, input_data=inp)
        except Exception as e:
            single_result = {"ok": False, "error": f"Exception during submit: {e}"}

        results.append(
            {
                "index": idx,
                "input": inp,
                "response": single_result,
            }
        )

    return {"ok": True, "results": results}


def submit_batch_jobs_cli(
    job_type: str = typer.Option(
        ...,
        "--job-type",
        help='Job type to submit (e.g. "generate_conformers").',
    ),
    input_data: str = typer.Option(
        ...,
        "--input-data",
        help="JSON list of per-job input_data, e.g. "
             '\'[{"smiles": "CCO", "num_conformers": 2}, {"smiles": "CCCO"}, "num_conformers": 5]\'',
    ),
):
    """
    CLI wrapper for submit_batch_jobs.

    Example:

      python -m opal.main jobs submit-batch-jobs \\
        --job-type generate_conformers \\
        --input-data '[{"smiles": "CCO", "num_conformers": 2}, {"smiles": "CCCO"}, "num_conformers": 5]'
    """
    try:
        parsed = json.loads(input_data)
    except Exception as e:
        rprint(f"[red]❌ Failed to parse --input-data JSON:[/red] {e}")
        raise typer.Exit(code=1)

    if not isinstance(parsed, list):
        rprint("[red]❌ --input-data must be a JSON list (array) of per-job inputs.[/red]")
        raise typer.Exit(code=1)

    result = submit_batch_jobs(job_type=job_type, input_data=parsed)

    if not result.get("ok"):
        rprint(f"[red]❌ Batch submission failed:[/red] {result.get('error')}")
        raise typer.Exit(code=1)

    batch_results = result.get("results", [])
    total = len(batch_results)
    successes = sum(1 for r in batch_results if r["response"].get("ok"))
    failures = total - successes

    rprint(
        f"[green]✅ Batch submission complete.[/green] "
        f"Total jobs: {total}, successes: {successes}, failures: {failures} \n"
        # f"Results: \n {batch_results}"
    )

    # print job IDs if present in each response
    for item in batch_results:
        idx = item["index"]
        resp = item["response"]

        if resp.get("ok") and isinstance(resp.get("data"), dict):
            data = resp["data"]
            job_id = data.get("job_id")
            run_call = data.get("run_job_call_id")
            status = data.get("status")
            msg = data.get("message")

            rprint(
                f"  - [{idx}] job_id={job_id} | status={status} | message={msg} "
            )
        else:
            err = resp.get("error", "Unknown error")
            rprint(f"  - [{idx}] [red]FAILED[/red]: {err}")

def get_jobs(
    limit: Optional[int] = None,
    all_jobs: bool = False,
    job_type: Optional[str] = None,
    status: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
):
    """
    Library function to fetch jobs.

    Args:
        limit: Optional[int]
            Max number of jobs to return. If None, the default is 5.
            Ignored if all_jobs is True.
        all_jobs: bool
            If True, request all matching jobs (no limit).
        job_type: Optional[str]
            Filter by job_type (e.g. "generate_conformers").
        status: Optional[str]
            Filter by job status ("completed", "failed", "running")
        start_date: Optional[str]
            Filter by created_at >= start_date (DateTime string).
        end_date: Optional[str]
            Filter by created_at <= end_date (DateTime string).

    Returns:
        {"ok": True, "data": [...]} on success
        {"ok": False, "status_code": int, "error": str} on failure
    """
    url = f"{SUPABASE_URL}/functions/v1/get-jobs"

    params: dict[str, str] = {}

    if all_jobs:
        params["all"] = "true"
    elif limit is not None:
        params["limit"] = str(limit)

    if job_type:
        params["job_type"] = job_type

    if status:
        params["status"] = status

    if start_date:
        params["start_date"] = start_date

    if end_date:
        params["end_date"] = end_date

    r = httpx.get(url, headers=_auth_headers(), params=params or None)
    if r.status_code == 200:
        return {"ok": True, "data": r.json()}
    else:
        return {"ok": False, "status_code": r.status_code, "error": r.text}


def get_jobs_cli(
    limit: Optional[int] = typer.Option(
        None,
        "--limit",
        help="Number of jobs to fetch (default 5). Ignored if --all is set.",
    ),
    all_jobs: bool = typer.Option(
        False,
        "--all",
        help="Fetch all jobs (ignore limit).",
    ),
    job_type: Optional[str] = typer.Option(
        None,
        "--job-type",
        help='Filter by job_type, e.g. "generate_conformers".',
    ),
    status: Optional[str] = typer.Option(
        None,
        "--status",
        help='Filter by job status: "completed", "failed", "running".',
    ),
    start_date: Optional[str] = typer.Option(
        None,
        "--start-date",
        help="Filter by created_at >= this datetime (e.g. 2025-12-01T00:00:00Z).",
    ),
    end_date: Optional[str] = typer.Option(
        None,
        "--end-date",
        help="Filter by created_at <= this datetime (e.g. 2025-12-05T00:00:00Z).",
    ),
):
    """
    CLI wrapper for `get_jobs`.

    Examples:
      opal jobs get-jobs                    ---> last 5 jobs
      opal jobs get-jobs --all              ---> all jobs
      opal jobs get-jobs --limit 10         ---> last 10 jobs
      opal jobs get-jobs --job-type generate_conformers --status completed
      opal jobs get-jobs --start-date 2025-12-01T00:00:00Z --end-date 2025-12-05T00:00:00Z
    """
    result = get_jobs(
        limit=limit,
        all_jobs=all_jobs,
        job_type=job_type,
        status=status,
        start_date=start_date,
        end_date=end_date,
    )

    if result.get("ok"):
        rprint("[blue]📋 Jobs:[/blue]")
        rprint(result["data"])
    else:
        rprint(
            "[red]❌ Failed to fetch jobs:[/red]",
            result.get("error"),
            f"(status {result.get('status_code')})",
        )

def get(job_id: str):
    """
    Library: get a single job by ID.
    """
    url = f"{SUPABASE_URL}/functions/v1/get-job/{job_id}"
    r = httpx.get(url, headers=_auth_headers())
    if r.status_code == 200:
        return {"ok": True, "data": r.json()}
    else:
        return {"ok": False, "status_code": r.status_code, "error": r.text}


def get_cli(
    job_id: str = typer.Option(..., "--job-id", help="Job ID to fetch"),
):
    """CLI wrapper for `get`."""
    result = get(job_id=job_id)
    if result.get("ok"):
        rprint("[blue]📄 Job Info:[/blue]")
        rprint(result["data"])
    else:
        rprint("[red]❌ Failed to fetch job:[/red]", result.get("error"), f"(status {result.get('status_code')})")


def cancel(job_id: str):
    """
    Library: cancel a job by ID.
    """
    url = f"{SUPABASE_URL}/functions/v1/cancel-job/{job_id}"
    r = httpx.delete(url, headers=_auth_headers())
    if r.status_code == 200:
        return {"ok": True, "data": r.json()}
    else:
        return {"ok": False, "status_code": r.status_code, "error": r.text}


def cancel_cli(
    job_id: str = typer.Option(..., "--job-id", help="Job ID to cancel"),
):
    """CLI wrapper for `cancel`."""
    result = cancel(job_id=job_id)
    if result.get("ok"):
        rprint("[yellow]⚠️ Job cancelled[/yellow]")
        rprint(result["data"])
    else:
        rprint("[red]❌ Failed to cancel job:[/red]", result.get("error"), f"(status {result.get('status_code')})")


def check_running_jobs():
    """
    Library: poll running jobs.
    """
    url = f"{SUPABASE_URL}/functions/v1/poll-modal-results"
    r = httpx.post(url, headers=_auth_headers())
    if r.status_code == 200:
        return {"ok": True, "data": r.json()}
    else:
        return {"ok": False, "status_code": r.status_code, "error": r.text}


def check_running_jobs_cli():
    """CLI wrapper for `check_running_jobs`."""
    result = check_running_jobs()
    if result.get("ok"):
        rprint("[green]🔁 Polling complete[/green]")
        rprint(result["data"])
    else:
        rprint("[red]❌ Polling failed:[/red]", result.get("error"), f"(status {result.get('status_code')})")


def get_job_types():
    """
    Library: get available job types.
    """
    url = f"{SUPABASE_URL}/functions/v1/get-job-types2"
    r = httpx.get(url, headers=_auth_headers())
    if r.status_code == 200:
        return {"ok": True, "data": r.json()}
    else:
        return {"ok": False, "status_code": r.status_code, "error": r.text}


def get_job_types_cli():
    """CLI wrapper for `get_job_types`."""
    result = get_job_types()
    if result.get("ok"):
        rprint("[cyan]📦 Available job types (from function constant):[/cyan]")
        rprint(result["data"])
    else:
        rprint("[red]❌ Failed to get job types:[/red]", result.get("error"), f"(status {result.get('status_code')})")
