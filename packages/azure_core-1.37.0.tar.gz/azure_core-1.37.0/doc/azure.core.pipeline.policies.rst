azure.core.pipeline.policies
============================

.. automodule:: azure.core.pipeline.policies
   :members:
   :undoc-members:
   :inherited-members:
