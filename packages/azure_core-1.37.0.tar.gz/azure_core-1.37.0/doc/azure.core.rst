azure-core
==========

.. automodule:: azure.core
   :members:
   :undoc-members:
   :inherited-members:

Subpackages
-----------

.. toctree::

   azure.core.pipeline
   azure.core.polling
   azure.core.tracing

Submodules
----------

azure.core.async\_paging
------------------------

.. automodule:: azure.core.async_paging
   :members:
   :undoc-members:
   :inherited-members:

azure.core.credentials
----------------------

.. automodule:: azure.core.credentials
   :members:
   :undoc-members:
   :inherited-members:

azure.core.credentials_async
----------------------------

.. automodule:: azure.core.credentials_async
   :members:
   :undoc-members:
   :inherited-members:

azure.core.exceptions
---------------------

.. automodule:: azure.core.exceptions
   :members:
   :undoc-members:

azure.core.messaging
--------------------

.. automodule:: azure.core.messaging
   :members:
   :undoc-members:
   :inherited-members:

azure.core.paging
-----------------

.. automodule:: azure.core.paging
   :members:
   :undoc-members:
   :inherited-members:

azure.core.settings
-------------------

.. automodule:: azure.core.settings
   :members:
   :undoc-members:
   :inherited-members:

azure.core.serialization
------------------------

.. automodule:: azure.core.serialization
   :members:
   :undoc-members:
   :inherited-members:

azure.core.rest
---------------

.. automodule:: azure.core.rest
   :members:
   :undoc-members:
   :inherited-members:

azure.core.utils
----------------

.. automodule:: azure.core.utils
   :members:
   :undoc-members:
   :inherited-members:

