#ifndef _MATH_UTILS_
#define _MATH_UTILS_

#include<stdint.h>

#define ceil_u64(value) ((uint64_t)(value) + ((value) != (uint64_t)(value)))

#endif
