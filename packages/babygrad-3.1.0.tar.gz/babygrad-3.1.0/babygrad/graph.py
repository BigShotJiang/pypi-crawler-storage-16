import networkx as nx


class GraphOps:
    def __init__(self, directed=False):
        self.g = nx.DiGraph() if directed else nx.Graph()
        self.directed = directed

    def add(self, u, v):
        self.g.add_edge(u, v)

    def print_adj(self, n):
        """Helper for 11.7.2 / 11.7.1 - Print adjacency list format"""
        for i in range(n):
            nbrs = sorted(list(self.g.neighbors(i))) if i in self.g else []
            if not nbrs:
                print(f"{i}:")
            else:
                print(f"{i}:{' '.join(map(str, nbrs))} ")

    # --- Traversals ---
    def bfs(self, start):
        if start not in self.g: return []
        res, visited, q = [], {start}, [start]
        while q:
            u = q.pop(0)
            res.append(u)
            for v in sorted(list(self.g.neighbors(u))):
                if v not in visited:
                    visited.add(v)
                    q.append(v)
        return res

    def dfs(self, start):
        if start not in self.g: return []
        res, visited, stack = [], set(), [start]
        while stack:
            u = stack.pop()
            if u not in visited:
                visited.add(u)
                res.append(u)
                # Reverse sort for stack to mimic recursive order
                for v in sorted(list(self.g.neighbors(u)), reverse=True):
                    if v not in visited:
                        stack.append(v)
        return res

    # --- Classic Algorithms ---
    def components(self):
        """Returns connected components sorted by size/value."""
        comps = [sorted(list(c)) for c in nx.connected_components(self.g)]
        comps.sort(key=lambda x: x[0])
        return comps

    def topo_sort(self):
        """Returns lexicographical topological sort."""
        try:
            return list(nx.lexicographical_topological_sort(self.g))
        except:
            return "Cycle detected"

    def is_bipartite(self):
        """Check if graph is bipartite."""
        return nx.is_bipartite(self.g)

    # --- Specialized Static Solvers ---
    @staticmethod
    def flood_fill(grid, r, c, new_col):
        """11.8.4 - Franky the Painter (Flood Fill)"""
        rows, cols = len(grid), len(grid[0])
        start_col = grid[r][c]
        if start_col == new_col: return grid
        
        def dfs(x, y):
            if x < 0 or x >= rows or y < 0 or y >= cols or grid[x][y] != start_col:
                return
            grid[x][y] = new_col
            dfs(x+1, y); dfs(x-1, y); dfs(x, y+1); dfs(x, y-1)
        dfs(r, c)
        return grid

    @staticmethod
    def solve_nasa_pairs(n, pairs):
        """11.8.5 - NASA Space Agency Problem"""
        g = nx.Graph()
        g.add_nodes_from(range(n))  # Important: Add ALL nodes, even isolated ones
        g.add_edges_from(pairs)
        
        sizes = [len(c) for c in nx.connected_components(g)]
        rem = sum(sizes)  # This equals N
        ans = 0
        
        for s in sizes:
            rem -= s
            ans += s * rem
        return ans

    @staticmethod
    def min_network_ops(n, conns):
        """11.8.1 - Minimum Network Operations"""
        if len(conns) < n - 1: return -1
        g = nx.Graph()
        g.add_nodes_from(range(n))
        g.add_edges_from(conns)
        return nx.number_connected_components(g) - 1

    @staticmethod
    def job_scheduling(n, edges):
        """11.8.2 - Job Scheduling (Min Time)"""
        g = nx.DiGraph()
        g.add_nodes_from(range(1, n+1))
        g.add_edges_from(edges)
        
        times = {node: 1 for node in range(1, n+1)}
        try:
            order = list(nx.topological_sort(g))
            for u in order:
                for v in g.neighbors(u):
                    times[v] = max(times[v], times[u] + 1)
            return [times[i] for i in range(1, n+1)]
        except:
            return []

    @staticmethod
    def check_prereqs(n, edges):
        """11.8.3 - Check Prerequisites (DAG validation)"""
        g = nx.DiGraph()
        g.add_nodes_from(range(n))
        g.add_edges_from(edges)
        return 1 if nx.is_directed_acyclic_graph(g) else 0

    @staticmethod
    def huffman(chars, freqs):
        """Huffman Encoding"""
        import heapq
        pq = [[w, [s, ""]] for s, w in zip(chars, freqs)]
        heapq.heapify(pq)
        while len(pq) > 1:
            lo = heapq.heappop(pq)
            hi = heapq.heappop(pq)
            for pair in lo[1:]:
                pair[1] = '0' + pair[1]
            for pair in hi[1:]:
                pair[1] = '1' + pair[1]
            heapq.heappush(pq, [lo[0] + hi[0]] + lo[1:] + hi[1:])
        return sorted(heapq.heappop(pq)[1:], key=lambda p: (len(p[1]), p[1]))

    # --- Grid / Island Solvers ---
    @staticmethod
    def grid_to_graph(grid, valid_val='1', diagonals=False):
        """Converts a 2D grid to a NetworkX Graph."""
        g = nx.Graph()
        rows = len(grid)
        cols = len(grid[0]) if rows > 0 else 0
        
        for r in range(rows):
            for c in range(cols):
                if str(grid[r][c]) == str(valid_val):
                    node = (r, c)
                    g.add_node(node)
                    dirs = [(0,1), (1,0)]  # Right, Down
                    if diagonals:
                        dirs += [(1,1), (1,-1)]
                    for dr, dc in dirs:
                        nr, nc = r + dr, c + dc
                        if 0 <= nr < rows and 0 <= nc < cols:
                            if str(grid[nr][nc]) == str(valid_val):
                                g.add_edge(node, (nr, nc))
        return g

    @staticmethod
    def count_islands(grid):
        """The Classic Island Problem Solver."""
        g = GraphOps.grid_to_graph(grid, valid_val='1')
        return nx.number_connected_components(g)

