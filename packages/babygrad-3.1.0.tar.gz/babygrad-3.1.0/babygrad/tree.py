import sys
sys.setrecursionlimit(10**6)


class Node:
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None
        self.height = 1


class TreeOps:
    # --- Builders ---
    @staticmethod
    def bst_insert(root, val):
        """BST Insertion"""
        if not root: return Node(val)
        if val < root.data: root.left = TreeOps.bst_insert(root.left, val)
        elif val > root.data: root.right = TreeOps.bst_insert(root.right, val)
        return root

    @staticmethod
    def insert_bst(root, val):
        """Alias for bst_insert"""
        return TreeOps.bst_insert(root, val)

    @staticmethod
    def from_level_order(arr):
        """Handles ['1', '2', 'null', '3'] or [1, 2, -1, 3] formats."""
        if not arr or (isinstance(arr[0], (int, str)) and str(arr[0]) == '-1'): 
            return None
        nodes = []
        for x in arr:
            if str(x).lower() in ['null', 'n', '-1', 'none']:
                nodes.append(None)
            else:
                nodes.append(Node(int(x)))
        
        if not nodes or nodes[0] is None: return None
        
        root = nodes[0]
        q = [root]
        i = 1
        
        while q and i < len(nodes):
            curr = q.pop(0)
            if i < len(nodes) and nodes[i]:
                curr.left = nodes[i]
                q.append(curr.left)
            i += 1
            if i < len(nodes) and nodes[i]:
                curr.right = nodes[i]
                q.append(curr.right)
            i += 1
        return root

    @staticmethod
    def build_level_order(arr):
        """Alias for from_level_order"""
        return TreeOps.from_level_order(arr)

    @staticmethod
    def build_pre_in(pre_arr, in_arr):
        """Build tree from preorder and inorder traversals"""
        if not pre_arr or not in_arr: return None
        val = pre_arr[0]
        root = Node(val)
        mid = in_arr.index(val)
        root.left = TreeOps.build_pre_in(pre_arr[1:mid+1], in_arr[:mid])
        root.right = TreeOps.build_pre_in(pre_arr[mid+1:], in_arr[mid+1:])
        return root

    # --- Traversals ---
    @staticmethod
    def get_traversals(root):
        """Get all traversals: in, pre, post, level"""
        res = {'in': [], 'pre': [], 'post': [], 'level': []}
        
        def dfs(n):
            if not n: return
            res['pre'].append(n.data)
            dfs(n.left)
            res['in'].append(n.data)
            dfs(n.right)
            res['post'].append(n.data)
        
        dfs(root)
        
        # Level order
        if root:
            q = [root]
            while q:
                c = q.pop(0)
                res['level'].append(c.data)
                if c.left: q.append(c.left)
                if c.right: q.append(c.right)
        return res

    @staticmethod
    def bfs_list(root):
        """Returns list of values level-by-level."""
        if not root: return []
        res = []
        q = [root]
        while q:
            curr = q.pop(0)
            res.append(curr.data)
            if curr.left: q.append(curr.left)
            if curr.right: q.append(curr.right)
        return res

    # --- Solvers ---
    @staticmethod
    def height(root):
        """Calculate tree height"""
        if not root: return 0
        return 1 + max(TreeOps.height(root.left), TreeOps.height(root.right))

    @staticmethod
    def diameter(root):
        """Calculate tree diameter (longest path between any two nodes)"""
        ans = 0
        
        def depth(n):
            nonlocal ans
            if not n: return 0
            L = depth(n.left)
            R = depth(n.right)
            ans = max(ans, L + R)  # Diameter in terms of edges
            return 1 + max(L, R)
        
        depth(root)
        return ans + 1  # Return nodes count (standard definition)

    @staticmethod
    def max_leaf_to_leaf_sum(root):
        """7.9.5 - Highest Achievable Sum (Max leaf-to-leaf path sum)"""
        ans = -float('inf')
        
        def solve(node):
            nonlocal ans
            if not node: return -float('inf')
            if not node.left and not node.right: return node.data
            
            l = solve(node.left)
            r = solve(node.right)
            
            # If both children exist, we can form a leaf-to-leaf path through this node
            if node.left and node.right:
                ans = max(ans, l + r + node.data)
                return max(l, r) + node.data
            
            # If only one child, pass the sum up
            return (l if node.left else r) + node.data
        
        solve(root)
        return ans

    @staticmethod
    def compare(n1, n2, mode='mirror'):
        """Compare two trees. mode: 'mirror' (symmetric) or 'same' (identical)"""
        if not n1 and not n2: return True
        if not n1 or not n2 or n1.data != n2.data: return False
        
        if mode == 'mirror':
            return TreeOps.compare(n1.left, n2.right, 'mirror') and \
                   TreeOps.compare(n1.right, n2.left, 'mirror')
        else:  # same
            return TreeOps.compare(n1.left, n2.left, 'same') and \
                   TreeOps.compare(n1.right, n2.right, 'same')

    @staticmethod
    def lca(root, n1, n2):
        """Lowest Common Ancestor in BST"""
        while root:
            if root.data > n1 and root.data > n2:
                root = root.left
            elif root.data < n1 and root.data < n2:
                root = root.right
            else:
                break
        return root.data if root else None

    @staticmethod
    def check_all(root, predicate):
        """
        Generic validator.
        predicate: function(node) -> bool
        Example: check_all(root, lambda n: n.left is None)
        """
        if not root: return True
        if not predicate(root): return False
        return TreeOps.check_all(root.left, predicate) and TreeOps.check_all(root.right, predicate)

    # --- Problem Helpers ---
    @staticmethod
    def perfect_family(root):
        """
        7.9.1 - Perfect Family of Mr. Code Stark
        Returns True if every non-leaf node has exactly one child; otherwise False.
        """
        return TreeOps.check_all(
            root,
            lambda n: (not n.left and not n.right) or ((n.left is None) != (n.right is None))
        )

    # --- AVL Logic ---
    @staticmethod
    def avl_insert(root, val, callback=None):
        """AVL Tree Insertion with rotation callback"""
        if not root: return Node(val)
        if val < root.data:
            root.left = TreeOps.avl_insert(root.left, val, callback)
        elif val > root.data:
            root.right = TreeOps.avl_insert(root.right, val, callback)
        else:
            return root
        
        root.height = 1 + max(TreeOps.height(root.left), TreeOps.height(root.right))
        b = (TreeOps.height(root.left) - TreeOps.height(root.right))
        
        # Rotations
        if b > 1 and val < root.left.data:
            if callback: callback("LL")
            return TreeOps._rot_r(root)
        if b < -1 and val > root.right.data:
            if callback: callback("RR")
            return TreeOps._rot_l(root)
        if b > 1 and val > root.left.data:
            if callback: callback("LR")
            root.left = TreeOps._rot_l(root.left)
            return TreeOps._rot_r(root)
        if b < -1 and val < root.right.data:
            if callback: callback("RL")
            root.right = TreeOps._rot_r(root.right)
            return TreeOps._rot_l(root)
        return root

    @staticmethod
    def _rot_r(y):
        """Right rotation"""
        x = y.left
        T2 = x.right
        x.right = y
        y.left = T2
        y.height = 1 + max(TreeOps.height(y.left), TreeOps.height(y.right))
        x.height = 1 + max(TreeOps.height(x.left), TreeOps.height(x.right))
        return x

    @staticmethod
    def _rot_l(x):
        """Left rotation"""
        y = x.right
        T2 = y.left
        y.left = x
        x.right = T2
        x.height = 1 + max(TreeOps.height(x.left), TreeOps.height(x.right))
        y.height = 1 + max(TreeOps.height(y.left), TreeOps.height(y.right))
        return y

