import difflib


# The Massive Knowledge Base

_DOCS = {
    # ==============================================================================
    # 7.8 & 7.9 Series: TREES
    # ==============================================================================
    "tree traversals": {
        "baby": """from babygrad3 import scan, TreeOps\nn = scan.int()\nvals = []\nfor _ in range(n):\n    op = scan.int()\n    if op == 1: vals.append(scan.int())\n    else:\n        root = TreeOps.from_level_order(vals)\n        if not root: print("Empty")\n        else:\n            t = TreeOps.get_traversals(root)\n            print(*t['in'] if op==2 else (t['pre'] if op==3 else t['post']))""",
        "python": """import sys\nsys.setrecursionlimit(2000)\n\nclass Node:\n    def __init__(self, v): self.data, self.left, self.right = v, None, None\n\ndef insert_level(arr, i, n):\n    root = None\n    if i < n:\n        root = Node(arr[i])\n        root.left = insert_level(arr, 2*i + 1, n)\n        root.right = insert_level(arr, 2*i + 2, n)\n    return root\n\ndef get_trav(root):\n    res = {'in':[], 'pre':[], 'post':[]}\n    def dfs(n):\n        if not n: return\n        res['pre'].append(n.data)\n        dfs(n.left)\n        res['in'].append(n.data)\n        dfs(n.right)\n        res['post'].append(n.data)\n    dfs(root)\n    return res\n\nops = int(sys.stdin.readline())\nvals = []\nfor _ in range(ops):\n    line = list(map(int, sys.stdin.readline().split()))\n    if line[0] == 1: vals.append(line[1])\n    else:\n        if not vals: print("Empty"); continue\n        root = insert_level(vals, 0, len(vals))\n        t = get_trav(root)\n        k = 'in' if line[0]==2 else ('pre' if line[0]==3 else 'post')\n        print(*(t[k]))"""
    },

    "bst ops": {
        "baby": """from babygrad3 import scan, TreeOps\nn, root = scan.int(), None\nres = []\nfor _ in range(n):\n    op = scan.int()\n    if op == 1: root = TreeOps.bst_insert(root, scan.int())\n    elif op == 2: root = TreeOps.bst_delete(root, scan.int())\n    elif op == 3: res.append("found" if TreeOps.bst_search(root, scan.int()) else "not found")\n    elif op in (4,5,6):\n        if not root: res.append("Empty")\n        else: res.append(" ".join(map(str, TreeOps.get_traversals(root)['in' if op==4 else ('pre' if op==5 else 'post')] )))\nprint(*res, sep='\\n')""",
        "python": """import sys\nclass Node: \n    def __init__(self,d): self.data, self.left, self.right = d, None, None\ndef ins(r,v): \n    if not r: return Node(v)\n    if v<r.data: r.left=ins(r.left,v)\n    elif v>r.data: r.right=ins(r.right,v)\n    return r\ndef dele(r,v):\n    if not r: return r\n    if v<r.data: r.left=dele(r.left,v)\n    elif v>r.data: r.right=dele(r.right,v)\n    else:\n        if not r.left: return r.right\n        if not r.right: return r.left\n        t=r.right\n        while t.left: t=t.left\n        r.data=t.data\n        r.right=dele(r.right,t.data)\n    return r\ndef search(r,v):\n    if not r: return False\n    if r.data==v: return True\n    return search(r.left if v<r.data else r.right, v)\ndef trav(r, res):\n    if not r: return\n    res['pre'].append(r.data); trav(r.left,res); res['in'].append(r.data); trav(r.right,res); res['post'].append(r.data)\n\nroot = None\nlines = sys.stdin.read().split()\ni = 1; n = int(lines[0])\nout = []\nwhile i < len(lines):\n    op = int(lines[i]); i+=1\n    if op == 1: root = ins(root, int(lines[i])); i+=1\n    elif op == 2: root = dele(root, int(lines[i])); i+=1\n    elif op == 3: out.append("found" if search(root, int(lines[i])) else "not found"); i+=1\n    else:\n        if not root: out.append("Empty")\n        else:\n            d={'in':[],'pre':[],'post':[]}; trav(root,d)\n            k='in' if op==4 else ('pre' if op==5 else 'post')\n            out.append(" ".join(map(str, d[k])))\nprint("\\n".join(out))"""
    },

    "huffman": {
        "baby": """from babygrad3 import scan, TreeOps\nchars = scan.str()\nfreqs = scan.list_fixed(len(chars))\nroot = TreeOps.huffman_tree(chars, freqs)\ncodes = []\ndef dfs(n, p):\n    if not n: return\n    if n.data: codes.append(p)\n    dfs(n.left, p+"0"); dfs(n.right, p+"1")\ndfs(root, "")\nprint(*codes)""",
        "python": """import heapq, sys\nclass Node:\n    def __init__(self, c, f, l=None, r=None): self.c, self.f, self.l, self.r = c, f, l, r\n    def __lt__(self, o): return self.f < o.f if self.f != o.f else (self.c < o.c if self.c and o.c else False)\n\nchars = sys.stdin.readline().strip()\nfreqs = list(map(int, sys.stdin.readline().split()))\npq = []\nfor i, (c, f) in enumerate(zip(chars, freqs)): heapq.heappush(pq, (f, i, c, Node(c, f)))\n\nuid = len(chars)\nwhile len(pq) > 1:\n    f1, i1, c1, n1 = heapq.heappop(pq)\n    f2, i2, c2, n2 = heapq.heappop(pq)\n    heapq.heappush(pq, (f1+f2, uid, None, Node(None, f1+f2, n1, n2)))\n    uid += 1\n\nroot = heapq.heappop(pq)[3]\ncodes = []\ndef dfs(n, path):\n    if not n: return\n    if n.c: codes.append(path)\n    dfs(n.l, path+'0'); dfs(n.r, path+'1')\ndfs(root, "")\nprint(*codes)"""
    },

    "avl insert": {
        "baby": """from babygrad3 import scan, TreeOps\nvals = scan.list_fixed(scan.int())\nroot = None\nfor v in vals:\n    rot = []\n    root = TreeOps.avl_insert(root, v, lambda x: rot.append(x))\n    if rot: print(rot[-1])\n    print(*TreeOps.get_traversals(root)['in'])""",
        "python": """import sys\nclass Node:\n    def __init__(self, d): self.data, self.left, self.right, self.h = d, None, None, 1\ndef ht(n): return n.h if n else 0\ndef bal(n): return ht(n.left) - ht(n.right) if n else 0\ndef rotr(y): \n    x=y.left; T=x.right; x.right=y; y.left=T\n    y.h=1+max(ht(y.left),ht(y.right)); x.h=1+max(ht(x.left),ht(x.right)); return x\ndef rotl(x):\n    y=x.right; T=y.left; y.left=x; x.right=T\n    x.h=1+max(ht(x.left),ht(x.right)); y.h=1+max(ht(y.left),ht(y.right)); return y\n\ndef ins(root, v, cb): \n    if not root: return Node(v)\n    if v < root.data: root.left = ins(root.left, v, cb)\n    elif v > root.data: root.right = ins(root.right, v, cb)\n    else: return root\n    root.h = 1 + max(ht(root.left), ht(root.right))\n    b = bal(root)\n    if b > 1 and v < root.left.data: cb("LL"); return rotr(root)\n    if b < -1 and v > root.right.data: cb("RR"); return rotl(root)\n    if b > 1 and v > root.left.data: cb("LR"); root.left = rotl(root.left); return rotr(root)\n    if b < -1 and v < root.right.data: cb("RL"); root.right = rotr(root.right); return rotl(root)\n    return root\n\ndef inorder(n, res): \n    if n: inorder(n.left, res); res.append(n.data); inorder(n.right, res)\n\ndata = sys.stdin.read().split()\nn = int(data[0]); vals = map(int, data[1:])\nroot = None\nfor v in vals:\n    rot = []\n    root = ins(root, v, lambda x: rot.append(x))\n    if rot: print(rot[-1])\n    res = []; inorder(root, res); print(*res)"""
    },

    "tree height": {
        "baby": """from babygrad3 import scan, TreeOps\nscan.int()\nprint(TreeOps.height(TreeOps.from_level_order(scan.list_until())))""",
        "python": """import sys\n# Level order array to Height\narr = sys.stdin.read().split()[1:]\nif not arr: print(0); exit()\ndef solve(idx):\n    if idx >= len(arr) or arr[idx] in ['null', 'n', '-1']: return 0\n    return 1 + max(solve(2*idx+1), solve(2*idx+2))\nprint(solve(0))"""
    },

    "build pre in": {
        "baby": """from babygrad3 import scan, TreeOps\nn = scan.int()\nprint(*TreeOps.get_traversals(TreeOps.build_pre_in(scan.list_fixed(n), scan.list_fixed(n)))['post'])""",
        "python": """import sys\nsys.setrecursionlimit(2000)\ndef build(pre, ino):\n    if not pre: return []\n    val = pre[0]; mid = ino.index(val)\n    left = build(pre[1:mid+1], ino[:mid])\n    right = build(pre[mid+1:], ino[mid+1:])\n    return left + right + [val]\n\nd = sys.stdin.read().split()\nn = int(d[0]); ino = list(map(int, d[1:n+1])); pre = list(map(int, d[n+1:]))\nprint(*build(pre, ino))"""
    },

    "tree diameter": {
        "baby": """from babygrad3 import scan, TreeOps\nprint(TreeOps.diameter(TreeOps.from_level_order(scan.list_until(sentinel=None)), edges=True))""",
        "python": """import sys\nclass Node: \n    def __init__(self,d): self.d,self.l,self.r=d,None,None\ndef build(arr):\n    if not arr: return None\n    nodes = [Node(int(x)) if x not in ['N','null'] else None for x in arr]\n    root = nodes[0]; q = [root]; i = 1\n    while q and i<len(nodes):\n        c = q.pop(0)\n        if i<len(nodes) and nodes[i]: c.l=nodes[i]; q.append(c.l)\n        i+=1\n        if i<len(nodes) and nodes[i]: c.r=nodes[i]; q.append(c.r)\n        i+=1\n    return root\n\nans = 0\ndef diam(n):\n    global ans\n    if not n: return 0\n    L, R = diam(n.l), diam(n.r)\n    ans = max(ans, L+R)\n    return 1 + max(L, R)\n\nvals = sys.stdin.read().split()\nroot = build(vals)\ndiam(root)\nprint(ans)"""
    },

    "bst lca": {
        "baby": """from babygrad3 import scan, TreeOps\nn = scan.int()\nvals = scan.list_fixed(n)\nroot = None\nfor v in vals: root = TreeOps.bst_insert(root, v)\nprint(TreeOps.lca(root, scan.int(), scan.int()))""",
        "python": """import sys\nclass Node: \n    def __init__(self,d): self.d,self.l,self.r=d,None,None\ndef ins(r,v):\n    if not r: return Node(v)\n    if v<r.d: r.l=ins(r.l,v)\n    elif v>r.d: r.r=ins(r.r,v)\n    return r\n\nd = list(map(int, sys.stdin.read().split()))\nn = d[0]; vals = d[1:n+1]; n1, n2 = d[n+1], d[n+2]\nroot = None\nfor v in vals: root = ins(root, v)\n\ncurr = root\nwhile curr:\n    if curr.d > n1 and curr.d > n2: curr = curr.l\n    elif curr.d < n1 and curr.d < n2: curr = curr.r\n    else: print(curr.d); break"""
    },

    "perfect family": {
        "baby": """from babygrad3 import scan, TreeOps\nscan.int()\nroot = None\nfor v in scan.list_until(sentinel=None): root = TreeOps.bst_insert(root, int(v))\nprint(1 if TreeOps.perfect_family(root) else 0)""",
        "python": """import sys\nclass Node: \n    def __init__(self,d): self.d,self.l,self.r=d,None,None\ndef ins(r,v):\n    if not r: return Node(v)\n    if v<r.d: r.l=ins(r.l,v)\n    elif v>r.d: r.r=ins(r.r,v)\n    return r\n\ndef check(n):\n    if not n: return True\n    if not n.l and not n.r: return True\n    if n.l and n.r: return False\n    return check(n.l) and check(n.r)\n\nd = sys.stdin.read().split()\nn = int(d[0]); vals = map(int, d[1:])\nroot = None\nfor v in vals: root = ins(root, v)\nprint(1 if check(root) else 0)"""
    },

    "tree mirror": {
        "baby": """from babygrad3 import scan, TreeOps\nroot = TreeOps.from_level_order(scan.list_until('-1'))\nprint(1 if TreeOps.is_symmetric(root) else 0)""",
        "python": """import sys\nclass Node: \n    def __init__(self,d): self.d,self.l,self.r=d,None,None\narr = sys.stdin.read().split()\nif arr and arr[-1]=='-1': arr.pop()\nnodes = [Node(int(x)) if x not in ['null','-1'] else None for x in arr]\nif not nodes: print(1); exit()\nroot = nodes[0]; q = [root]; i = 1\nwhile q and i<len(nodes):\n    c = q.pop(0)\n    if i<len(nodes) and nodes[i]: c.l=nodes[i]; q.append(c.l)\n    i+=1\n    if i<len(nodes) and nodes[i]: c.r=nodes[i]; q.append(c.r)\n    i+=1\n\ndef mir(a,b):\n    if not a and not b: return True\n    if not a or not b or a.d != b.d: return False\n    return mir(a.l, b.r) and mir(a.r, b.l)\nprint(1 if mir(root.l, root.r) else 0)"""
    },

    "kth smallest": {
        "baby": """from babygrad3 import scan, TreeOps\nvals = scan.list_until('-1')\nprint(TreeOps.kth_smallest(TreeOps.from_level_order(vals), scan.int()))""",
        "python": """import sys\narr = sys.stdin.read().split()\nif '-1' in arr: arr = arr[:arr.index('-1')]\nk = int(arr.pop())\nclass Node: \n    def __init__(self,d): self.d,self.l,self.r=d,None,None\nnodes = [Node(int(x)) if x!='null' else None for x in arr]\nif not nodes: print(0); exit()\nroot = nodes[0]; q = [root]; i = 1\nwhile q and i<len(nodes):\n    c = q.pop(0)\n    if i<len(nodes) and nodes[i]: c.l=nodes[i]; q.append(c.l)\n    i+=1\n    if i<len(nodes) and nodes[i]: c.r=nodes[i]; q.append(c.r)\n    i+=1\n\nstack, curr, cnt = [], root, 0\nwhile stack or curr:\n    while curr: stack.append(curr); curr=curr.l\n    curr = stack.pop(); cnt+=1\n    if cnt==k: print(curr.d); exit()\n    curr = curr.r"""
    },

    "level order": {
        "baby": """from babygrad3 import scan, TreeOps\nscan.int()\nroot = None\nfor v in scan.list_until(sentinel=None): root = TreeOps.bst_insert(root, int(v))\nprint(*TreeOps.bfs_list(root))""",
        "python": """import sys\nclass Node: \n    def __init__(self,d): self.d,self.l,self.r=d,None,None\ndef ins(r,v):\n    if not r: return Node(v)\n    if v<r.d: r.l=ins(r.l,v)\n    elif v>r.d: r.r=ins(r.r,v)\n    return r\nd = sys.stdin.read().split()\nroot = None\nfor v in map(int, d[1:]): root = ins(root, v)\nq, res = [root], []\nwhile q:\n    c = q.pop(0)\n    if c: res.append(c.d); q.append(c.l); q.append(c.r)\nprint(*res)"""
    },

    "max leaf sum": {
        "baby": """from babygrad3 import scan, TreeOps\nprint(TreeOps.max_leaf_to_leaf_sum(TreeOps.from_level_order(scan.list_until('-1'))))""",
        "python": """import sys\narr = sys.stdin.read().split()\nif '-1' in arr: arr.pop()\nclass Node: \n    def __init__(self,d): self.d,self.l,self.r=d,None,None\nnodes = [Node(int(x)) if x not in ['null','-1'] else None for x in arr]\nif not nodes or not nodes[0]: print(0); exit()\nroot = nodes[0]; q = [root]; i = 1\nwhile q and i<len(nodes):\n    c = q.pop(0)\n    if i<len(nodes) and nodes[i]: c.l=nodes[i]; q.append(c.l)\n    i+=1\n    if i<len(nodes) and nodes[i]: c.r=nodes[i]; q.append(c.r)\n    i+=1\n\nans = -float('inf')\ndef solve(n):\n    global ans\n    if not n: return -float('inf')\n    if not n.l and not n.r: return n.d\n    l, r = solve(n.l), solve(n.r)\n    if n.l and n.r: ans = max(ans, l+r+n.d); return max(l,r)+n.d\n    return (l if n.l else r) + n.d\nsolve(root)\nprint(ans)"""
    },

    # ==============================================================================
    # 11.7 & 14.4 & 14.5 Series: GRAPHS
    # ==============================================================================

    "graph matrix ops": {
        "baby": """from babygrad3 import scan, GraphOps\nops = scan.int()\ng = GraphOps()\nverts = set()\nfor _ in range(ops):\n    cmd = scan.int()\n    if cmd == 1: verts.add(scan.int())\n    elif cmd == 2: \n        v = scan.int()\n        if v in verts: \n            verts.remove(v)\n            if v in g.g: g.g.remove_node(v)\n    elif cmd == 3: g.add(scan.int(), scan.int())\n    elif cmd == 4: \n        u, v = scan.int(), scan.int()\n        if g.g.has_edge(u, v): g.g.remove_edge(u, v)\n    elif cmd == 5: \n        print("Yes" if g.g.has_edge(scan.int(), scan.int()) else "No")\n\ns_verts = sorted(list(verts))\nfor i in s_verts: print(*[1 if g.g.has_edge(i, j) else 0 for j in s_verts])""",
        "python": """import sys\nn = int(sys.stdin.readline())\nadj = {}\nverts = set()\nfor _ in range(n):\n    line = list(map(int, sys.stdin.readline().split()))\n    op = line[0]\n    if op == 1: verts.add(line[1])\n    elif op == 2: verts.discard(line[1])\n    elif op == 3: \n        if line[1] in verts and line[2] in verts: \n            adj.setdefault(line[1], set()).add(line[2])\n            adj.setdefault(line[2], set()).add(line[1])\n    elif op == 4:\n        if line[1] in adj and line[2] in adj[line[1]]: adj[line[1]].remove(line[2])\n        if line[2] in adj and line[1] in adj[line[2]]: adj[line[2]].remove(line[1])\n    elif op == 5:\n        print("Yes" if line[1] in adj and line[2] in adj[line[1]] else "No")\ns = sorted(list(verts))\nfor i in s:\n    print(*[1 if (i in adj and j in adj[i]) else 0 for j in s])"""
    },

    "graph adj list": {
        "baby": """from babygrad3 import scan, GraphOps\nn, ops = scan.int(), scan.int()\ng = GraphOps()\nfor _ in range(ops):\n    cmd = scan.str()\n    if cmd == 'ADD': g.add(scan.int(), scan.int())\n    elif cmd == 'DEL': \n        u, v = scan.int(), scan.int()\n        if g.g.has_edge(u, v): g.g.remove_edge(u, v)\n    elif cmd == 'NEIGHBORS':\n        u = scan.int()\n        nbrs = sorted(list(g.g.neighbors(u))) if u in g.g else []\n        print(*(nbrs if nbrs else [-1]))\ng.print_adj_list(n)""",
        "python": """import sys\nfrom collections import defaultdict\nlines = sys.stdin.read().split()\nn = int(lines[0]); ops = int(lines[1])\nadj = defaultdict(set)\nidx = 2\nfor _ in range(ops):\n    cmd = lines[idx]; idx+=1\n    if cmd == 'ADD':\n        u, v = int(lines[idx]), int(lines[idx+1]); idx+=2\n        adj[u].add(v); adj[v].add(u)\n    elif cmd == 'DEL':\n        u, v = int(lines[idx]), int(lines[idx+1]); idx+=2\n        if v in adj[u]: adj[u].remove(v)\n        if u in adj[v]: adj[v].remove(u)\n    elif cmd == 'NEIGHBORS':\n        u = int(lines[idx]); idx+=1\n        res = sorted(list(adj[u]))\n        print(*(res if res else [-1]))\nfor i in range(n):\n    print(f"{i}:{' '.join(map(str, sorted(list(adj[i]))))} " if adj[i] else f"{i}:")"""
    },

    "dfs traversal": {
        "baby": """from babygrad3 import scan, GraphOps\nv, e = scan.int(), scan.int()\ng = GraphOps()\nfor _ in range(e): g.add(scan.int(), scan.int())\nprint(*g.dfs(scan.int()))""",
        "python": """import sys\nfrom collections import defaultdict\nd = list(map(int, sys.stdin.read().split()))\nv, e = d[0], d[1]\nadj = defaultdict(list)\nidx = 2\nfor _ in range(e):\n    adj[d[idx]].append(d[idx+1]); adj[d[idx+1]].append(d[idx]); idx+=2\nstart = d[idx]\nres, vis, stack = [], set(), [start]\nwhile stack:\n    u = stack.pop()\n    if u not in vis:\n        vis.add(u); res.append(u)\n        for v in sorted(adj[u], reverse=True): \n            if v not in vis: stack.append(v)\nprint(*res)"""
    },

    "bfs traversal": {
        "baby": """from babygrad3 import scan, GraphOps\nv, e = scan.int(), scan.int()\ng = GraphOps()\nfor _ in range(e): g.add(scan.int(), scan.int())\nres = g.bfs(scan.int())\n# Strict level printing if required:\nq = [res[0]]; vis = {res[0]}\nwhile q:\n    print(*q)\n    new_q = []\n    for u in q:\n        for v in sorted(g.g.neighbors(u)): \n            if v not in vis: vis.add(v); new_q.append(v)\n    q = new_q""",
        "python": """import sys\nfrom collections import defaultdict, deque\nd = list(map(int, sys.stdin.read().split()))\nv, e = d[0], d[1]\nadj = defaultdict(list)\nidx = 2\nfor _ in range(e):\n    adj[d[idx]].append(d[idx+1]); adj[d[idx+1]].append(d[idx]); idx+=2\nstart = d[idx]\nq = [start]; vis = {start}\nwhile q:\n    print(*q)\n    nq = []\n    for u in q:\n        for v in sorted(adj[u]):\n            if v not in vis: vis.add(v); nq.append(v)\n    q = nq"""
    },

    "connected components": {
        "baby": """from babygrad3 import scan, GraphOps\nv, e = scan.int(), scan.int()\ng = GraphOps()\ng.g.add_nodes_from(range(v))\nfor _ in range(e): g.add(scan.int(), scan.int())\nfor c in g.components(): print(*c)""",
        "python": """import sys\nfrom collections import defaultdict\nd = list(map(int, sys.stdin.read().split()))\nv, e = d[0], d[1]\nadj = defaultdict(list)\nidx = 2\nfor _ in range(e):\n    adj[d[idx]].append(d[idx+1]); adj[d[idx+1]].append(d[idx]); idx+=2\nvis = set()\ncomps = []\nfor i in range(v):\n    if i not in vis:\n        q = [i]; vis.add(i); comp = []\n        while q:\n            u = q.pop(0); comp.append(u)\n            for nbr in adj[u]:\n                if nbr not in vis: vis.add(nbr); q.append(nbr)\n        comps.append(sorted(comp))\nfor c in sorted(comps, key=lambda x: x[0]): print(*c)"""
    },

    "topo kahn": {
        "baby": """from babygrad3 import scan, GraphOps\nv, e = scan.int(), scan.int()\ng = GraphOps(directed=True)\ng.g.add_nodes_from(range(v))\nfor _ in range(e): g.add(scan.int(), scan.int())\nt = g.topo_sort()\nprint(*t if t else ["Cycle detected"])""",
        "python": """import sys, heapq\nfrom collections import defaultdict\nd = list(map(int, sys.stdin.read().split()))\nv, e = d[0], d[1]\nadj = defaultdict(list); indeg = {i:0 for i in range(v)}\nidx = 2\nfor _ in range(e):\n    adj[d[idx]].append(d[idx+1]); indeg[d[idx+1]] += 1; idx+=2\npq = [i for i in range(v) if indeg[i] == 0]; heapq.heapify(pq)\nres = []\nwhile pq:\n    u = heapq.heappop(pq); res.append(u)\n    for v_node in adj[u]:\n        indeg[v_node] -= 1\n        if indeg[v_node] == 0: heapq.heappush(pq, v_node)\nprint(*res if len(res)==v else ["Cycle detected"])"""
    },

    "topo matrix": {
        "baby": """from babygrad3 import scan, GraphOps\nn = scan.int()\nmat = scan.matrix(n, n)\ng = GraphOps.from_matrix(mat, directed=True)\nt = g.topo_sort()\nprint(*t)""",
        "python": """import sys, heapq\nn = int(sys.stdin.readline())\nindeg = {i:0 for i in range(n)}\nadj = {i:[] for i in range(n)}\nfor r in range(n):\n    row = list(map(int, sys.stdin.readline().split()))\n    for c in range(n):\n        if row[c] == 1: adj[r].append(c); indeg[c] += 1\npq = [i for i in range(n) if indeg[i]==0]; heapq.heapify(pq)\nres = []\nwhile pq:\n    u = heapq.heappop(pq); res.append(u)\n    for v in adj[u]:\n        indeg[v] -= 1\n        if indeg[v] == 0: heapq.heappush(pq, v)\nprint(*res)"""
    },

    "is bipartite": {
        "baby": """from babygrad3 import scan, GraphOps\nn = scan.int()\nmat = scan.matrix(n, n)\ng = GraphOps.from_matrix(mat)\nscan.int() # source ignored\nprint("Yes" if g.is_bipartite() else "No")""",
        "python": """import sys\nn = int(sys.stdin.readline())\nadj = {i:[] for i in range(n)}\nfor r in range(n):\n    row = list(map(int, sys.stdin.readline().split()))\n    for c in range(n): \n        if row[c]: adj[r].append(c)\ncolor = {}; possible = True\nfor i in range(n):\n    if i not in color:\n        color[i] = 0; q = [i]\n        while q:\n            u = q.pop(0)\n            for v in adj[u]:\n                if v not in color: color[v] = 1 - color[u]; q.append(v)\n                elif color[v] == color[u]: possible = False\nprint("Yes" if possible else "No")"""
    },

    "count islands": {
        "baby": """from babygrad3 import scan, GraphOps\nr, c = scan.int(), scan.int()\ngrid = scan.matrix(r, c)\nprint(GraphOps.count_islands(grid))""",
        "python": """import sys\nsys.setrecursionlimit(5000)\nlines = sys.stdin.read().split()\nr, c = int(lines[0]), int(lines[1])\ngrid = []; idx = 2\nfor _ in range(r): grid.append(lines[idx:idx+c]); idx+=c\nvis = set(); cnt = 0\ndef dfs(x,y):\n    if not (0<=x<r and 0<=y<c) or (x,y) in vis or grid[x][y] == '0': return\n    vis.add((x,y))\n    for dx,dy in [(0,1),(1,0),(0,-1),(-1,0)]: dfs(x+dx, y+dy)\nfor i in range(r):\n    for j in range(c):\n        if grid[i][j] == '1' and (i,j) not in vis: dfs(i,j); cnt+=1\nprint(cnt)"""
    },

    "min network ops": {
        "baby": """from babygrad3 import scan, GraphOps\nn = scan.int()\nconns = []\nwhile True: \n    u = scan.int()\n    if u == -1: break\n    conns.append((u, scan.int()))\nif len(conns) < n - 1: print(-1)\nelse:\n    g = GraphOps()\n    g.g.add_nodes_from(range(n))\n    g.g.add_edges_from(conns)\n    print(len(g.components()) - 1)""",
        "python": """import sys\nd = list(map(int, sys.stdin.read().split()))\nn = d[0]; idx = 1; edges = []\nwhile idx < len(d):\n    if d[idx] == -1: break\n    edges.append((d[idx], d[idx+1])); idx+=2\nif len(edges) < n-1: print(-1)\nelse:\n    p = list(range(n))\n    def find(x): \n        if p[x]!=x: p[x]=find(p[x])\n        return p[x]\n    def union(a,b): p[find(a)] = find(b)\n    for u,v in edges: union(u,v)\n    print(len(set(find(i) for i in range(n))) - 1)"""
    },

    "job scheduling": {
        "baby": """from babygrad3 import scan, GraphOps\nv, e = scan.int(), scan.int()\ng = GraphOps(directed=True)\ng.g.add_nodes_from(range(1, v+1))\nfor _ in range(e): g.add(scan.int(), scan.int())\ntimes = {n: 1 for n in range(1, v+1)}\nfor u in g.topo_sort():\n    for v in g.g.neighbors(u):\n        times[v] = max(times[v], times[u] + 1)\nprint(*[times[i] for i in range(1, v+1)])""",
        "python": """import sys\nfrom collections import defaultdict, deque\nd = list(map(int, sys.stdin.read().split()))\nn, e = d[0], d[1]\nadj = defaultdict(list); indeg = {i:0 for i in range(1, n+1)}\nidx = 2\nfor _ in range(e): \n    adj[d[idx]].append(d[idx+1]); indeg[d[idx+1]]+=1; idx+=2\nq = deque([i for i in range(1, n+1) if indeg[i]==0])\ntime = {i:1 for i in range(1, n+1)}\norder = []\nwhile q:\n    u = q.popleft(); order.append(u)\n    for v in adj[u]:\n        indeg[v]-=1\n        if indeg[v]==0: q.append(v)\nfor u in order:\n    for v in adj[u]: time[v] = max(time[v], time[u] + 1)\nprint(*[time[i] for i in range(1, n+1)])"""
    },

    "prerequisites": {
        "baby": """from babygrad3 import scan, GraphOps\nn, e = scan.int(), scan.int()\ng = GraphOps(directed=True)\nfor _ in range(e): g.add(scan.int(), scan.int())\nprint(1 if g.topo_sort() else 0)""",
        "python": """import sys\nfrom collections import defaultdict\nd = list(map(int, sys.stdin.read().split()))\nn, e = d[0], d[1]\nadj = defaultdict(list); indeg = {i:0 for i in range(n)}\nidx = 2\nfor _ in range(e):\n    u,v = d[idx], d[idx+1]; adj[u].append(v); indeg[v]+=1; idx+=2\nq = [i for i in range(n) if indeg[i]==0]; cnt=0\nwhile q:\n    u=q.pop(0); cnt+=1\n    for v in adj[u]:\n        indeg[v]-=1\n        if indeg[v]==0: q.append(v)\nprint(1 if cnt==n else 0)"""
    },

    "flood fill": {
        "baby": """from babygrad3 import scan, GraphOps\nr, c = scan.int(), scan.int()\ngrid = scan.matrix(r, c)\nx, y, col = scan.int(), scan.int(), scan.int()\nres = GraphOps.flood_fill(grid, x, y, col)\nfor row in res: print(*row)""",
        "python": """import sys\nsys.setrecursionlimit(5000)\nlines = sys.stdin.read().split()\nr, c = int(lines[0]), int(lines[1])\ngrid = []; idx = 2\nfor _ in range(r): grid.append([int(x) for x in lines[idx:idx+c]]); idx+=c\nx, y, new_c = int(lines[idx]), int(lines[idx+1]), int(lines[idx+2])\nold = grid[x][y]\nif old != new_c:\n    def dfs(i, j):\n        if 0<=i<r and 0<=j<c and grid[i][j]==old:\n            grid[i][j] = new_c\n            dfs(i+1,j); dfs(i-1,j); dfs(i,j+1); dfs(i,j-1)\n    dfs(x, y)\nfor row in grid: print(*row)"""
    },

    "nasa pairs": {
        "baby": """from babygrad3 import scan, GraphOps\nn, p = scan.int(), scan.int()\ng = GraphOps()\ng.g.add_nodes_from(range(n))\nfor _ in range(p): g.add(scan.int(), scan.int())\nsizes = [len(c) for c in g.components()]\nrem = sum(sizes); ans = 0\nfor s in sizes: rem -= s; ans += s * rem\nprint(ans)""",
        "python": """import sys\nd = list(map(int, sys.stdin.read().split()))\nn, p = d[0], d[1]\nparent = list(range(n))\ndef find(x): \n    if parent[x]!=x: parent[x]=find(parent[x])\n    return parent[x]\ndef union(a,b): parent[find(a)] = find(b)\nidx=2\nfor _ in range(p): union(d[idx], d[idx+1]); idx+=2\ncounts = {}; \nfor i in range(n): r = find(i); counts[r] = counts.get(r, 0) + 1\nsizes = list(counts.values())\nans = 0; rem = n\nfor s in sizes: rem -= s; ans += s * rem\nprint(ans)"""
    },

    "create graph": {
        "baby": """from babygrad3 import scan, GraphOps\nv = scan.int()\nif not (1 <= v <= 10): print("-1")\nelse:\n    mat = scan.matrix(v, v, transformer=lambda x: int(x))\n    for row in mat: print(*row)""",
        "python": """import sys\nlines = sys.stdin.read().split()\nv = int(lines[0])\nif not (1 <= v <= 10): print("-1")\nelse:\n    idx=1\n    for i in range(v):\n        print(*lines[idx:idx+v]); idx+=v"""
    },

    "dfs reachable": {
        "baby": """from babygrad3 import scan, GraphOps\nn = scan.int()\nmat = scan.matrix(n, n)\ng = GraphOps.from_matrix(mat, directed=True)\nstart = scan.int()\nprint(f"Reachable nodes from {start}:", *g.dfs(start))""",
        "python": """import sys\nlines = sys.stdin.read().split()\nn = int(lines[0])\nidx=1; adj={i:[] for i in range(n)}\nfor r in range(n):\n    for c in range(n):\n        if lines[idx]=='1': adj[r].append(c)\n        idx+=1\nstart = int(lines[idx])\nvis = set(); res = []; stack=[start]\nwhile stack:\n    u = stack.pop()\n    if u not in vis:\n        vis.add(u); res.append(u)\n        for v in sorted(adj[u], reverse=True): \n            if v not in vis: stack.append(v)\nprint(f"Reachable nodes from {start}:", *res)"""
    },

    "dfs adj list": {
        "baby": """from babygrad3 import scan, GraphOps\nv, e = scan.int(), scan.int()\ng = GraphOps(directed=True)\nfor _ in range(e): g.add(scan.int(), scan.int())\nprint(*g.dfs(scan.int()))""",
        "python": """import sys\nfrom collections import defaultdict\nd=list(map(int, sys.stdin.read().split()))\nv,e = d[0], d[1]\nadj = defaultdict(list); idx=2\nfor _ in range(e): adj[d[idx]].append(d[idx+1]); idx+=2\nstart=d[idx]; stack=[start]; vis=set(); res=[]\nwhile stack:\n    u=stack.pop()\n    if u not in vis:\n        vis.add(u); res.append(u)\n        for v in sorted(adj[u], reverse=True):\n            if v not in vis: stack.append(v)\nprint(*res)"""
    },

    "is connected": {
        "baby": """from babygrad3 import scan, GraphOps\nv = scan.int()\nmat = scan.matrix(v, v)\ng = GraphOps.from_matrix(mat)\nu, v = scan.int(), scan.int()\nprint(nx.has_path(g.g, u, v))""",
        "python": """import sys\nlines=sys.stdin.read().split()\nv=int(lines[0]); idx=1; adj={i:[] for i in range(v)}\nfor r in range(v):\n    for c in range(v):\n        if lines[idx]=='1': adj[r].append(c)\n        idx+=1\ns, d = int(lines[idx]), int(lines[idx+1])\nq=[s]; vis={s}\nfound=False\nwhile q:\n    u=q.pop(0)\n    if u==d: found=True; break\n    for nbr in adj[u]:\n        if nbr not in vis: vis.add(nbr); q.append(nbr)\nprint(found)"""
    },

    "biconnected": {
        "baby": """from babygrad3 import scan, GraphOps\nv, e = scan.int(), scan.int()\ng = GraphOps()\nfor _ in range(e): g.add(scan.int(), scan.int())\nprint(g.biconnected_count())""",
        "python": """import sys\nsys.setrecursionlimit(2000)\nd=list(map(int, sys.stdin.read().split()))\nv,e = d[0], d[1]\nadj={i:[] for i in range(v)}; idx=2\nfor _ in range(e): \n    if idx+1 < len(d): adj[d[idx]].append(d[idx+1]); adj[d[idx+1]].append(d[idx]); idx+=2\ntime=0; disc=[-1]*v; low=[-1]*v; stack=[]; count=0\ndef dfs(u, p=-1):\n    global time, count\n    disc[u]=low[u]=time; time+=1; children=0\n    for v in adj[u]:\n        if v==p: continue\n        if disc[v]!=-1: low[u]=min(low[u], disc[v]); stack.append((u,v))\n        else:\n            stack.append((u,v)); children+=1; dfs(v, u); low[u]=min(low[u], low[v])\n            if (p!=-1 and low[v]>=disc[u]) or (p==-1 and children>1):\n                count+=1\n                while stack[-1]!=(u,v): stack.pop()\n                stack.pop()\n    return\nfor i in range(v): \n    if disc[i]==-1: \n        dfs(i); \n        if stack: count+=1; stack=[]\nprint(count)"""
    },

    "cycle detect": {
        "baby": """from babygrad3 import scan, GraphOps\nv, e = scan.int(), scan.int()\ng = GraphOps()\nfor _ in range(e): g.add(scan.int(), scan.int())\ntry: \n    nx.find_cycle(g.g)\n    print("Yes")\nexcept: print("No")""",
        "python": """import sys\nsys.setrecursionlimit(2000)\nd=list(map(int, sys.stdin.read().split()))\nv,e = d[0], d[1]\nadj={i:[] for i in range(v)}; idx=2\nfor _ in range(e): adj[d[idx]].append(d[idx+1]); adj[d[idx+1]].append(d[idx]); idx+=2\nvis=set(); cycle=False\ndef dfs(u, p):\n    vis.add(u)\n    for nbr in adj[u]:\n        if nbr == p: continue\n        if nbr in vis: return True\n        if dfs(nbr, u): return True\n    return False\nfor i in range(v):\n    if i not in vis: \n        if dfs(i, -1): cycle=True; break\nprint("Yes" if cycle else "No")"""
    },

    "all paths": {
        "baby": """from babygrad3 import scan, GraphOps\nv, e = scan.int(), scan.int()\ng = GraphOps(directed=True)\nfor _ in range(e): g.add(scan.int(), scan.int())\nsrc, dst = scan.int(), scan.int()\npaths = g.all_paths(src, dst)\nfor p in paths: print(*p)""",
        "python": """import sys\nd=list(map(int, sys.stdin.read().split()))\nv,e=d[0], d[1]; adj={i:[] for i in range(v)}; idx=2\nfor _ in range(e): adj[d[idx]].append(d[idx+1]); idx+=2\nsrc, dst = d[idx], d[idx+1]\ndef dfs(u, path):\n    if u==dst: print(*path); return\n    for nbr in sorted(adj[u]):\n        if nbr not in path: dfs(nbr, path+[nbr])\ndfs(src, [src])"""
    },

    "graph symmetric": {
        "baby": """from babygrad3 import scan, GraphOps\nv = scan.int()\nmat = scan.matrix(v, v)\nprint("The graph is symmetric" if GraphOps.is_symmetric(mat) else "The graph is not symmetric")""",
        "python": """import sys\nlines=sys.stdin.read().split()\nv=int(lines[0]); mat=[]; idx=1\nfor r in range(v): mat.append(lines[idx:idx+v]); idx+=v\nsym=True\nfor r in range(v):\n    for c in range(v):\n        if mat[r][c] != mat[c][r]: sym=False; break\nprint("The graph is symmetric" if sym else "The graph is not symmetric")"""
    },

    "mother vertex": {
        "baby": """from babygrad3 import scan, GraphOps\nn, e = scan.int(), scan.int()\ng = GraphOps(directed=True)\ng.g.add_nodes_from(range(n))\nfor _ in range(e): g.add(scan.int(), scan.int())\nprint(g.mother_vertex(n))""",
        "python": """import sys\nsys.setrecursionlimit(5000)\nd=list(map(int, sys.stdin.read().split()))\nn,e=d[0], d[1]; adj={i:[] for i in range(n)}; idx=2\nfor _ in range(e): adj[d[idx]].append(d[idx+1]); idx+=2\nvis=set(); last=0\ndef dfs(u): \n    vis.add(u)\n    for v in adj[u]: \n        if v not in vis: dfs(v)\nfor i in range(n): \n    if i not in vis: dfs(i); last=i\nvis=set(); dfs(last)\nprint(last if len(vis)==n else -1)"""
    },

    "path exists": {
        "baby": """from babygrad3 import scan, GraphOps\nn = scan.int()\ne = scan.int()\ng = GraphOps()\nfor _ in range(e): g.add(scan.int(), scan.int())\nsrc, dst = scan.int(), scan.int()\nprint("true" if nx.has_path(g.g, src, dst) else "false")""",
        "python": """import sys\nd=list(map(int, sys.stdin.read().split()))\nn,e=d[0],d[1]; adj={i:[] for i in range(n)}; idx=2\nfor _ in range(e): adj[d[idx]].append(d[idx+1]); adj[d[idx+1]].append(d[idx]); idx+=2\ns, t = d[idx], d[idx+1]\nq=[s]; vis={s}; found=False\nwhile q:\n    u=q.pop(0)\n    if u==t: found=True; break\n    for v in adj[u]:\n        if v not in vis: vis.add(v); q.append(v)\nprint("true" if found else "false")"""
    },

    "grid path 123": {
        "baby": """from babygrad3 import scan, GraphOps\nn = scan.int()\ngrid = scan.matrix(n, n)\nprint(1 if GraphOps.grid_path(grid, 1, 2, {3}) else 0)""",
        "python": """import sys\nlines=sys.stdin.read().split()\nn=int(lines[0]); grid=[]; idx=1\nstart=None\nfor r in range(n): \n    row=[int(x) for x in lines[idx:idx+n]]; grid.append(row); idx+=n\n    if 1 in row: start=(r, row.index(1))\nq=[start]; vis={start}; found=False\nwhile q:\n    r,c=q.pop(0)\n    if grid[r][c]==2: found=True; break\n    for dr,dc in [(0,1),(0,-1),(1,0),(-1,0)]:\n        nr,nc=r+dr,c+dc\n        if 0<=nr<n and 0<=nc<n and (nr,nc) not in vis and grid[nr][nc] in [2,3]:\n            vis.add((nr,nc)); q.append((nr,nc))\nprint(1 if found else 0)"""
    },

    "transpose matrix": {
        "baby": """from babygrad3 import scan, GraphOps\nv = scan.int()\nmat = scan.matrix(v, v)\nres = GraphOps.transpose_matrix(mat)\nfor row in res: print(*row)""",
        "python": """import sys\nlines=sys.stdin.read().split()\nv=int(lines[0]); idx=1\nmat=[lines[idx+i*v : idx+(i+1)*v] for i in range(v)]\nt = [[mat[j][i] for j in range(v)] for i in range(v)]\nfor row in t: print(*row)"""
    },

    "island strike": {
        "baby": """from babygrad3 import scan, GraphOps\nn, m = scan.int(), scan.int()\ngrid = [list(scan.str()) for _ in range(n)]\nprint(GraphOps.count_islands(grid))""",
        "python": """import sys\nsys.setrecursionlimit(5000)\nlines=sys.stdin.read().split()\nn,m=int(lines[0]), int(lines[1]); idx=2\ngrid=[list(lines[i]) for i in range(2, 2+n)]\nvis=set(); cnt=0\ndef dfs(x,y):\n    if not (0<=x<n and 0<=y<m) or (x,y) in vis or grid[x][y]=='0': return\n    vis.add((x,y))\n    for dx,dy in [(0,1),(0,-1),(1,0),(-1,0)]: dfs(x+dx, y+dy)\nfor i in range(n):\n    for j in range(m):\n        if grid[i][j]=='1' and (i,j) not in vis: dfs(i,j); cnt+=1\nprint(cnt)"""
    },

    "degrees": {
        "baby": """from babygrad3 import scan, GraphOps\nv = scan.int()\ne = scan.int()\ng = GraphOps(directed=True)\ng.g.add_nodes_from(range(v))\nfor _ in range(e): g.add(scan.int(), scan.int())\ng.print_degrees(v)""",
        "python": """import sys\nd=list(map(int, sys.stdin.read().split()))\nv,e=d[0],d[1]; idx=2\nind={i:0 for i in range(v)}; outd={i:0 for i in range(v)}\nfor _ in range(e):\n    u,v_node=d[idx], d[idx+1]; idx+=2\n    outd[u]+=1; ind[v_node]+=1\nfor i in range(v): print(f"Vertex {i}: In-degree = {ind[i]}, Out-degree = {outd[i]}")"""
    }
}


def doc(key: str = None, language="baby"):
    """
    Prints solution code or lists all available problems.
    Args:
        key: The problem key (e.g., 'huffman', 'flood fill'). 
             If None, empty string, 'list', 'all', or 'help', shows all available problems.
        language: 'baby' for babygrad library code, 'python' for pure standard python.
    """
    # Show all available programs
    if not key or key.lower().strip() in ['list', 'all', 'help', 'ls']:
        print("# Available problems:")
        print("# " + "=" * 60)
        keys = sorted(_DOCS.keys())
        for i, k in enumerate(keys, 1):
            print(f"# {i:2d}. {k}")
        print("# " + "=" * 60)
        print(f"# Total: {len(keys)} problems")
        print("# Usage: doc('problem_name') or doc('problem_name', 'python')")
        return
    
    # Normalize key (strip spaces, lowercase)
    k = key.lower().strip()
    
    # Fuzzy matching helper
    matches = difflib.get_close_matches(k, _DOCS.keys(), n=1, cutoff=0.6)
    
    if k in _DOCS:
        print(_DOCS[k].get(language, "# Language not found"))
    elif matches:
        # If user made a typo (e.g. "flood filll"), suggest the closest match
        print(f"# Did you mean '{matches[0]}'?\n")
        print(_DOCS[matches[0]].get(language, "# Language not found"))
    else:
        # Sort keys for readable error message
        print(f"# No docs found for '{key}'. Available:\n# " + "\n# ".join(sorted(_DOCS.keys())))
