"""Configuration management for Backcraft CLI"""
from pathlib import Path

# Server URL - uses remote API
SERVER_URL = "http://65.108.59.188:8000"


class Config:
    """Manage Backcraft CLI configuration"""

    def __init__(self):
        pass

    @property
    def server_url(self) -> str:
        """Get server URL"""
        return SERVER_URL


# Singleton instance
config = Config()
