# 🔥 Backcraft CLI

Client CLI pour Backcraft - Générateur de projets Python alimenté par l'IA.

## Installation

```bash
pip install backcraft_cli
```

Ou depuis les sources:
```bash
git clone https://github.com/julesc31/pyforge-2.0-clean.git
cd pyforge-2.0-clean/cli-client
pip install -e .
```

## Commandes disponibles

### 💬 Mode interactif (recommandé)

Le mode interactif vous guide avec des questions personnalisées pour comprendre votre projet:

```bash
backcraft create MonProjet --interactive
```

L'IA vous guide à travers 3 étapes :
1. **Choix de la langue** (FR, EN, DE, ES, IT, PT)
2. **Niveau technique** (Débutant ou Professionnel)  
3. **Questions personnalisées** adaptées à vos réponses

**🌍 Langues supportées:**
- 🇫🇷 Français
- 🇬🇧 English
- 🇩🇪 Deutsch
- 🇪🇸 Español
- 🇮🇹 Italiano
- 🇵🇹 Português

**🎯 Niveaux techniques:**
- **👶 Débutant** - Questions en langage simple, sans jargon technique
  - Exemple: "Les utilisateurs devront-ils se connecter ?"
  - Exemple: "Allez-vous accepter des paiements ?"
- **🚀 Professionnel** - Questions techniques pour développeurs
  - Exemple: "JWT ou OAuth2 pour l'authentification ?"
  - Exemple: "Redis ou Memcached pour le cache ?"

**🔄 Fonctionnalités avancées:**
- **Contexte pour chaque question** : Comprend pourquoi chaque question est posée
- **Reformulation** : Tapez `?` si une question n'est pas claire
- **Récapitulatif final** : Validez toutes vos réponses avant génération
- **Modification** : Corrigez une réponse en tapant son numéro

**Exemple de conversation:**

```
🌍 Choose your language / Choisissez votre langue

  1. 🇫🇷 Français
  2. 🇬🇧 English
  3. 🇩🇪 Deutsch
  4. 🇪🇸 Español
  5. 🇮🇹 Italiano
  6. 🇵🇹 Português

→ 1

🎯 Choisissez votre niveau technique

  1. 👶 Débutant (langage simple)
  2. 🚀 Professionnel (langage technique)

→ 1

💬 Interactive Project Generation

Project: BiblioAPI

I'll ask you a few questions to better understand your needs.
This helps me generate exactly what you want!

💡 Décrivez votre projet: API REST pour gérer une bibliothèque

🔍 Analyzing your idea...

🤖 Analyse interactive — Questions ciblées

Je vais vous poser quelques questions pour affiner la génération.

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ Question 1/6                                 ┃
┃                                              ┃
┃ Les utilisateurs devront-ils se connecter ? ┃
┃                                              ┃
┃ 💡 This helps determine: le système          ┃
┃    d'authentification et de permissions      ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
Examples: oui avec rôles, non accès public

💬 Tapez votre réponse (ou '?' pour reformuler la question)
→ oui, bibliothécaires et lecteurs

[... 5 autres questions ...]

============================================================

📋 Récapitulatif de vos réponses

┏━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━┓
┃ #  ┃ Question                 ┃ Your Answer          ┃
┡━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━┩
│ 1  │ Connexion requise ?      │ oui, 2 rôles         │
│ 2  │ Gestion stock ?          │ oui avec réserv.     │
│ 3  │ Notifications ?          │ email + SMS          │
│ 4  │ Paiements ?              │ non                  │
│ 5  │ Nombre utilisateurs ?    │ ~500                 │
│ 6  │ API externe ?            │ ISBN lookup          │
└────┴──────────────────────────┴──────────────────────┘

Ces informations sont-elles correctes ?
Tapez le numéro de la question à modifier, ou 'ok' pour continuer

→ ok

✓ Génération de la compréhension finale...

✓ Extracted 18 features
auth, rbac, books, loans, reservations, notifications, isbn-lookup...

🚀 Starting generation...

[Génération en cours...]

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ ✅ Project generated successfully!          ┃
┃                                              ┃
┃ Files: 24                                    ┃
┃ Generation time: 45.3s                       ┃
┃ Run ID: abc-123-def                          ┃
┃                                              ┃
┃ Project saved to: ./BiblioAPI                ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

📦 Installer: ./BiblioAPI-installer.py
Run: python ./BiblioAPI-installer.py
```

### 🚀 Mode rapide

Pour une génération directe sans questions interactives:

```bash
backcraft create MonProjet --idea "API REST pour gérer une bibliothèque avec auth JWT et emprunts"
```

Options:
- `--output` / `-o`: Répertoire de sortie (défaut: répertoire actuel)
- `--type` / `-t`: Type de projet (api, web, cli, library)

### ⚙️ Voir la configuration

```bash
backcraft info
```

Affiche:
- Version du CLI
- Mode (Remote API)
- URL du serveur
- État de connexion

## Workflow complet

### Mode interactif (recommandé)

```bash
# 1. Créer le projet en mode interactif
backcraft create BiblioAPI --interactive --output ./projects

# 2. Installer le projet généré
cd projects
python BiblioAPI-installer.py

# 3. Lancer le projet
cd BiblioAPI
docker-compose up
```

### Mode rapide

```bash
# 1. Créer un projet directement
backcraft create BiblioAPI \
  --idea "API REST pour gérer une bibliothèque avec authentification JWT, gestion des emprunts et réservations" \
  --output ./projects

# 2. Installer et lancer
cd projects && python BiblioAPI-installer.py
cd BiblioAPI && docker-compose up
```

## Architecture

Le CLI est un **client léger** qui communique avec le serveur Backcraft centralisé :

```
┌─────────────────┐          ┌─────────────────┐          ┌─────────────────┐
│   Votre CLI     │─────────▶│  Serveur        │─────────▶│   Anthropic     │
│   (local)       │          │  Backcraft      │          │   Claude API    │
│                 │          │                 │          │                 │
│  Pas de clé     │◀─────────│  Orchestration  │◀─────────│  (clé serveur)  │
│  API requise    │          │  8 agents IA    │          │                 │
└─────────────────┘          └─────────────────┘          └─────────────────┘
```

**Avantages:**
- ✅ Pas besoin de clé API Anthropic
- ✅ Infrastructure cloud optimisée
- ✅ Mises à jour automatiques côté serveur
- ✅ Questions intelligentes adaptées à votre langue/niveau

## Ce qui est généré

Chaque projet inclut :

- **Backend FastAPI** complet (async/await natif)
- **SQLAlchemy 2.0** (modèles + relations)
- **PostgreSQL + Redis** (docker-compose)
- **JWT + RBAC** (authentification production-ready)
- **Tests Pytest** (unitaires + intégration)
- **Docker Compose** complet (app, db, redis)
- **CI/CD GitHub Actions**
- **Documentation API** automatique (OpenAPI/Swagger)

**Fonctionnalités avancées détectées automatiquement:**
- WebSockets (temps réel)
- File uploads (S3-ready)
- Caching (Redis)
- Rate limiting
- Monitoring (Prometheus ready)
- Background tasks (Celery ready)

## FAQ

**Q: Ai-je besoin d'une clé API ?**  
R: Non ! Le CLI se connecte au serveur Backcraft qui gère l'infrastructure IA.

**Q: Combien coûte une génération ?**  
R: Contactez le serveur Backcraft pour les tarifs actuels.

**Q: Puis-je utiliser le CLI hors ligne ?**  
R: Non, le CLI nécessite une connexion au serveur Backcraft.

**Q: Les générations sont-elles instantanées ?**  
R: Une génération prend environ 30-60 secondes selon la complexité.

**Q: Puis-je modifier les réponses avant la génération ?**  
R: Oui ! Le récapitulatif final vous permet de corriger toute réponse.

**Q: Que se passe-t-il si je ne comprends pas une question ?**  
R: Tapez `?` et l'IA reformulera la question plus simplement.

## Support

- **Issues** : https://github.com/julesc31/pyforge-2.0-clean/issues
- **Documentation** : https://docs.backcraft.io

## License

MIT
