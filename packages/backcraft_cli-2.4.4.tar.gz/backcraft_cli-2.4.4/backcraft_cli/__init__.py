"""Backcraft CLI - AI-powered Python project generator"""
import time

import click
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from rich.table import Table

from .api import BackcraftAPI, BackcraftAPIError
from .config import config

console = Console()

__version__ = "2.4.3"


@click.group(invoke_without_command=True)
@click.pass_context
@click.version_option(__version__)
def cli(ctx):
    """🔥 Backcraft CLI - Generate Python projects with AI"""
    if ctx.invoked_subcommand is None:
        console.print(
            f"\n[bold cyan]🔥 Welcome to Backcraft CLI v{__version__}[/bold cyan]\n")
        console.print(
            "[white]Generate production-ready Python backends in minutes.[/white]\n")

        console.print(Panel(
            "[bold green]Remote Mode - Powered by cloud infrastructure[/bold green]\n"
            "Fast, scalable project generation via remote API.",
            border_style="green",
            padding=(0, 2)
        ))
        console.print()

        console.print("[bold yellow]💬 Recommended mode:[/bold yellow]")
        console.print(
            "  [cyan]backcraft create my-project --interactive[/cyan]")
        console.print(
            "  [dim]AI guides you with tailored questions (6 languages available)[/dim]\n")

        console.print("[bold yellow]⚡ Quick mode:[/bold yellow]")
        console.print(
            "  [cyan]backcraft create my-api --idea \"REST API for...\"[/cyan]\n")

        console.print("[bold yellow]📚 Other commands:[/bold yellow]")
        console.print(
            "  [cyan]backcraft info[/cyan]      Show current configuration")
        console.print(
            "  [cyan]backcraft --help[/cyan]    Complete help and all commands\n")


@cli.command()
@click.argument('name')
@click.option('--idea', help='Project description in natural language')
@click.option('--interactive', '-i', is_flag=True, help='Interactive mode with questions')
@click.option('--output', '-o', default='.', help='Output directory')
@click.option('--type', '-t', type=click.Choice(['api', 'web', 'cli', 'library']), default='api')
def create(name: str, idea: str, interactive: bool, output: str, type: str):
    """Create a new project"""

    if not idea and not interactive:
        console.print(
            "[red]❌ Error: Either --idea or --interactive is required[/red]")
        console.print("[cyan]Examples:[/cyan]")
        console.print(
            "  backcraft create my-project --idea \"REST API for e-commerce\"")
        console.print("  backcraft create my-project --interactive")
        return

    if idea and interactive:
        console.print(
            "[yellow]⚠️  Both --idea and --interactive provided, using interactive mode[/yellow]\n")

    console.print(f"\n[bold cyan]🚀 Creating project: {name}[/bold cyan]\n")

    if idea and not interactive:
        console.print(f"[dim]Idea: {idea}[/dim]\n")

    try:
        api = BackcraftAPI()

        if interactive:
            _run_interactive_mode(api, name, idea, output, type)
        else:
            _run_quick_mode(api, name, idea, output, type)

    except BackcraftAPIError as e:
        console.print(f"[red]❌ Error: {e}[/red]")
    except Exception as e:
        console.print(f"[red]❌ Unexpected error: {e}[/red]")


def _run_interactive_mode(api: BackcraftAPI, name: str, idea: str, output: str, project_type: str):
    """Run interactive conversation mode with server"""

    # Step 1: Choose language
    console.print(
        "[bold]🌍 Choose your language / Choisissez votre langue[/bold]\n")
    console.print("  1. 🇫🇷 Français")
    console.print("  2. 🇬🇧 English")
    console.print("  3. 🇩🇪 Deutsch")
    console.print("  4. 🇪🇸 Español")
    console.print("  5. 🇮🇹 Italiano")
    console.print("  6. 🇵🇹 Português\n")

    language_choice = Prompt.ask(
        "→", choices=["1", "2", "3", "4", "5", "6"], default="2", show_choices=False)

    language_map = {"1": "fr", "2": "en",
                    "3": "de", "4": "es", "5": "it", "6": "pt"}
    language = language_map[language_choice]

    # Step 2: Choose technical level
    if language == "fr":
        console.print("\n🎯 Choisissez votre niveau technique\n")
        console.print("  1. 👶 Débutant (langage simple)")
        console.print("  2. 🚀 Professionnel (langage technique)\n")
    else:
        console.print("\n🎯 Choose your technical level\n")
        console.print("  1. 👶 Beginner (simple wording)")
        console.print("  2. 🚀 Professional (technical language)\n")

    level_choice = Prompt.ask(
        "→", choices=["1", "2"], default="2", show_choices=False)
    technical_level = "beginner" if level_choice == "1" else "professional"

    # Step 3: Get project idea if not provided
    if not idea:
        console.print(Panel(
            f"💬 Interactive Project Generation\n\n"
            f"Project: {name}\n\n"
            f"I'll ask you a few questions to better understand your needs.\n"
            f"This helps me generate exactly what you want!",
            title="🤖 Let's Chat",
            border_style="cyan"
        ))

        if language == "fr":
            idea = Prompt.ask("\n💡 Décrivez votre projet")
        else:
            idea = Prompt.ask("\n💡 Describe your project")

        if not idea or not idea.strip():
            console.print("[red]❌ Project idea is required[/red]")
            return

    console.print("\n[cyan]🔍 Analyzing your idea...[/cyan]")

    # Start conversation with server
    with console.status("[bold cyan]Thinking...", spinner="dots"):
        response = api._post("/api/chat/start", {
            "name": name,
            "idea": idea,
            "language": language,
            "technical_level": technical_level
        }, timeout=120)  # 2 minutes for LLM analysis

    session_id = response["session_id"]

    # Show initial understanding
    if response.get("understanding"):
        u = response["understanding"]
        console.print("\n[bold green]✓ Here's what I understood:[/bold green]")
        table = Table(show_header=False, box=None, padding=(0, 2))
        table.add_row(
            "📌 Domain:", f"[yellow]{u.get('domain', 'N/A')}[/yellow]")
        table.add_row(
            "🎯 Purpose:", f"[white]{u.get('purpose', 'N/A')}[/white]")
        table.add_row("👥 Target Users:",
                      f"[white]{u.get('target_users', 'N/A')}[/white]")
        console.print(table)

    console.print(
        "\n[bold yellow]💭 Now, let me ask you a few questions...[/bold yellow]\n")
    time.sleep(0.5)

    # Question loop
    while not response.get("done"):
        question_num = response.get("question_num", 0)
        total = response.get("total_questions", 6)
        question = response.get("question")
        why = response.get("why")

        if not question:
            break

        # Display question with context
        console.print(Panel(
            f"[bold white]Question {question_num}/{total}[/bold white]\n\n"
            f"[bold cyan]{question}[/bold cyan]\n\n"
            f"[dim]💡 This helps determine: {why}[/dim]",
            border_style="cyan",
            padding=(1, 2)
        ))

        # Get answer (allow reformulation with '?')
        answer = Prompt.ask(
            "\n[bold green]Your answer[/bold green] [dim](or '?' to rephrase)[/dim]")

        if not answer or not answer.strip():
            console.print("  [yellow]Please provide an answer[/yellow]\n")
            continue

        console.print()

        # Send answer and get next question
        with console.status("[bold cyan]Processing...", spinner="dots"):
            response = api._post(
                f"/api/chat/{session_id}/answer", {"answer": answer}, timeout=120)

    # Done with questions
    console.print(
        "[bold green]✅ Perfect! I have all the information I need.[/bold green]\n")

    # Get final understanding
    with console.status("[bold cyan]Building project understanding...", spinner="dots"):
        understanding = api._get(
            f"/api/chat/{session_id}/understanding", timeout=120)

    stats = understanding.get('stats', {})
    features = understanding.get('features', [])

    # Display final understanding
    console.print(Panel(
        f"[bold]Domain:[/bold] {understanding.get('domain')}\n"
        f"[bold]Purpose:[/bold] {understanding.get('purpose')}\n"
        f"[bold]Target Users:[/bold] {understanding.get('target_users')}\n"
        f"[bold]Key Entities:[/bold] {', '.join(understanding.get('entities', {}).keys())}\n\n"
        f"[bold cyan]📊 Statistics:[/bold cyan]\n"
        f"[bold]Number of models:[/bold] {stats.get('num_models', 0)}\n"
        f"[bold]Number of features:[/bold] {stats.get('num_features', 0)}\n"
        f"[bold]Complexity:[/bold] {stats.get('complexity', 'medium').upper()}",
        title="🎯 Final Understanding",
        border_style="green"
    ))

    # Show detected features
    console.print("\n[bold cyan]Detected features:[/bold cyan]")
    for i, feature in enumerate(features[:10], 1):
        console.print(f"  {i}. {feature}")
    if len(features) > 10:
        console.print(f"  [dim]... and {len(features) - 10} more[/dim]")

    # Ask to proceed
    console.print()
    proceed = Prompt.ask("[bold cyan]Ready to generate?[/bold cyan]",
                         choices=["yes", "no"], default="yes", show_choices=False)

    if proceed.lower() != "yes":
        console.print("[yellow]👋 Generation cancelled[/yellow]")
        return

    # Start generation
    console.print("\n[bold cyan]🚀 Starting generation...[/bold cyan]")

    gen_response = api._post(
        f"/api/chat/{session_id}/generate", {"project_type": project_type})
    generation_id = gen_response["generation_id"]

    console.print(f"[green]✓ Generation started (ID: {generation_id})[/green]")
    console.print(
        f"[dim]Features: {', '.join(features[:5])}{'...' if len(features) > 5 else ''}[/dim]\n")

    # Wait for completion
    result = api.wait_for_completion(generation_id)

    # Download installer
    console.print("\n[cyan]📥 Downloading project...[/cyan]")
    output_file = f"{output}/{name}-installer.py"
    api.download_generation(generation_id, output_file)

    # Success
    console.print(Panel(
        f"[bold green]✅ Project generated successfully![/bold green]\n\n"
        f"Files: {result.get('files_count', 'N/A')}\n"
        f"Time: {result.get('generation_time', 'N/A')}s\n"
        f"Features: {len(features)}\n\n"
        f"[cyan]Installer saved to: {output_file}[/cyan]\n"
        f"[dim]Run: python {output_file}[/dim]",
        title="🎉 Success",
        border_style="green"
    ))


def _run_quick_mode(api: BackcraftAPI, name: str, idea: str, output: str, project_type: str):
    """Quick mode - analyze and generate without questions"""
    console.print("[cyan]📤 Sending request to server...[/cyan]")

    # Use /api/generate endpoint
    gen_response = api._post("/api/generate", {
        "name": name,
        "idea": idea,
        "project_type": project_type
    })

    generation_id = gen_response["generation_id"]
    features = gen_response.get("features", [])

    console.print(f"[green]✓ Generation started (ID: {generation_id})[/green]")
    console.print(
        f"[dim]Features: {', '.join(features[:5])}{'...' if len(features) > 5 else ''}[/dim]\n")

    # Wait for completion
    result = api.wait_for_completion(generation_id)

    # Download installer
    console.print("\n[cyan]📥 Downloading project...[/cyan]")
    output_file = f"{output}/{name}-installer.py"
    api.download_generation(generation_id, output_file)

    # Success
    console.print(Panel(
        f"[bold green]✅ Project generated successfully![/bold green]\n\n"
        f"Files: {result.get('files_count', 'N/A')}\n"
        f"Time: {result.get('generation_time', 'N/A')}s\n"
        f"Features: {len(features)}\n\n"
        f"[cyan]Installer saved to: {output_file}[/cyan]\n"
        f"[dim]Run: python {output_file}[/dim]",
        title="Success",
        border_style="green"
    ))


@cli.command()
def info():
    """Show current configuration"""
    console.print("\n[bold cyan]Backcraft CLI Configuration[/bold cyan]\n")

    console.print(f"[bold]Version:[/bold] {__version__}")
    console.print("[bold]Mode:[/bold] Remote API")
    console.print(f"[bold]Server:[/bold] {config.server_url}")
    console.print("\n[green]✓ Ready to generate projects![/green]\n")


def main():
    """Entry point"""
    cli()


if __name__ == "__main__":
    main()
