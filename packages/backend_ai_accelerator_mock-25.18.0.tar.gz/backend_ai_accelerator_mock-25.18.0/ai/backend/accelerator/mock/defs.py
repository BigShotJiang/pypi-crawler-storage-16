import enum


class AllocationModes(enum.StrEnum):
    DISCRETE = "discrete"
    FRACTIONAL = "fractional"
