from typing import Final

BACKENDAI_APP_NAME: Final[str] = "backend.ai"
