"""empty message

Revision ID: c1409ad0e8da
Revises: 22e52d03fc61, 9a91532c8534
Create Date: 2019-07-29 20:18:52.291350

"""

# revision identifiers, used by Alembic.
revision = "c1409ad0e8da"
down_revision = ("22e52d03fc61", "9a91532c8534")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
