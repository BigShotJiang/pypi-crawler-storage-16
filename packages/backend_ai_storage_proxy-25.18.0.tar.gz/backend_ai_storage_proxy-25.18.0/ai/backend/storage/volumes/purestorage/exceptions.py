from aiohttp import web

from ai.backend.common.exception import (
    BackendAIError,
    ErrorCode,
    ErrorDetail,
    ErrorDomain,
    ErrorOperation,
)


class UnauthorizedPurityClient(BackendAIError, web.HTTPInternalServerError):
    error_type = "https://api.backend.ai/probs/purity-unauthorized-client"
    error_title = "Unauthorized Purity Client"

    def error_code(self) -> ErrorCode:
        return ErrorCode(
            domain=ErrorDomain.STORAGE,
            operation=ErrorOperation.ACCESS,
            error_detail=ErrorDetail.UNAUTHORIZED,
        )
