#!/usr/bin/env python3
#
# Author:
#  Tamas Jos (@skelsec)
#

import logging

logger = logging.getLogger('badauth')
