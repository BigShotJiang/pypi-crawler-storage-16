
__version__ = "0.1.5"
__banner__ = \
"""
# badauth %s 
# Author: Tamas Jos @skelsec (info@skelsecprojects.com)
# Current Maintainer: Baptiste Crépin (baptiste@cravaterouge.com)
""" % __version__
