import logging

logger = logging.getLogger('badauth.kerberos')