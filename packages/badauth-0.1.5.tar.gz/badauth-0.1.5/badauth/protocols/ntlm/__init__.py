import logging

logger = logging.getLogger('badauth.ntlm')