TMP_FOLDER_TYPES = {
    "data": "data",
    "model": "models",
    "log": "logs",
    "user_info": "user_info",
    "question": "questions",
}
