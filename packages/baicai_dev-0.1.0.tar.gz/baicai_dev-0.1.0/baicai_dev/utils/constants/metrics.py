CLASSIFICATION_METRICS = "accuracy, precision, recall, f1-score, and confusion matrix."
REGRESSION_METRICS = "mean absolute error, mean squared error, root mean squared error and r2_score."
