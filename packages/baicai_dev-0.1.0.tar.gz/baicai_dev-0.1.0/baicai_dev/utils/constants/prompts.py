DATA_ALREADY_LOADED = """
NOTE: The training and test data (X_train, y_train, X_test, y_test) have already been loaded into memory.
No additional data loading code is needed - please proceed with the analysis/modeling using these existing variables.
"""
