﻿balance
=======

.. automodule:: balance
   :members:




.. autosummary::
   :toctree:
   :recursive:

   balance.adjustment
   balance.balancedf_class
   balance.cli
   balance.sample_class
   balance.stats_and_plots
   balance.testutil
   balance.typing
   balance.util
   balance.weighting_methods

