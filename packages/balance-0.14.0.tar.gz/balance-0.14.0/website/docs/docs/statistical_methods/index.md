---
id: index
title: Statistical Methods
sidebar_position: 3
---
This section descirbes the statistical methodologies used in balance for weighting:
1. [Inverse propensity score weighting](ipw.md)
2. [Covariate balancing proponsity score](cbps.md)
3. [Post-stratification](poststratify.md)
4. [Raking](rake.md)
