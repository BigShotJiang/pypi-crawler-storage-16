"""Integration tests for Nano Banana MCP Server."""
