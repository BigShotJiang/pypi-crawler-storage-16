"""Unit tests for Nano Banana MCP Server."""
