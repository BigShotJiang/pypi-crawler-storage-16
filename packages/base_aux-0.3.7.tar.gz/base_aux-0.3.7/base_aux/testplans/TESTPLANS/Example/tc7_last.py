from base_aux.testplans.tp_manager import Base_TestCase
from base_aux.valid import *


# =====================================================================================================================
class TestCase(Base_TestCase):
    ASYNC = True
    DESCRIPTION = "LAST"


# =====================================================================================================================
