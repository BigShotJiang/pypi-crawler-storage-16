# from pathlib import Path
#
#
# for file in Path(__file__).glob("*.py"):
#     for name in dir(file):
#         value = getattr()
#         if isinstance()