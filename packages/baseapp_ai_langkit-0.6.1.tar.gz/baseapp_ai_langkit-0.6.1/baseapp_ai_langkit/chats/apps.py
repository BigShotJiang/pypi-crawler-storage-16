from django.apps import AppConfig


class BaseappAILangkitChatsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "baseapp_ai_langkit.chats"
    label = "baseapp_ai_langkit_chats"
