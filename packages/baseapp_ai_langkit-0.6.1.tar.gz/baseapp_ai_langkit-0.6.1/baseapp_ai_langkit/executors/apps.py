from django.apps import AppConfig


class BaseappAILangkitExecutorsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "baseapp_ai_langkit.executors"
    label = "baseapp_ai_langkit_executors"
