"""Integration tests for MCP server."""
