



PRE_a = ord("a") - 1
PRE_A = ord("A") - 1
