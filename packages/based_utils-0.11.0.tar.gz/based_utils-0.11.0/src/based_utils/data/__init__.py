from .conversion import get_class_vars, try_convert

PRE_a = ord("a") - 1
PRE_A = ord("A") - 1

__all__ = ["PRE_A", "PRE_a", "get_class_vars", "try_convert"]
