import math

HALF_CIRCLE = math.pi
FULL_CIRCLE = math.pi * 2
RADIANS_TO_DEGREES = 180 / HALF_CIRCLE
