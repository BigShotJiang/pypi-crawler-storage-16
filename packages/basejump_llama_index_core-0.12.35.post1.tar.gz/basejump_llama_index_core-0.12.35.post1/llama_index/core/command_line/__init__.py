# Deprecated. CLI is now its own package llama-index-cli
