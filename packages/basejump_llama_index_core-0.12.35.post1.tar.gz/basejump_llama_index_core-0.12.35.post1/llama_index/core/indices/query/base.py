# for backwards compatibility
from llama_index.core.base.base_query_engine import BaseQueryEngine

__all__ = [
    "BaseQueryEngine",
]
