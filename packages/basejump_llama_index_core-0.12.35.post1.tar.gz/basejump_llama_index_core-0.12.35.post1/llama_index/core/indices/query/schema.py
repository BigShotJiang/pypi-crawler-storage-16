# for backwards compatibility
from llama_index.core.schema import QueryBundle, QueryType

__all__ = ["QueryBundle", "QueryType"]
