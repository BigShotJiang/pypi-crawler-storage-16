# backward compatibility
from llama_index.core.text_splitter import *
