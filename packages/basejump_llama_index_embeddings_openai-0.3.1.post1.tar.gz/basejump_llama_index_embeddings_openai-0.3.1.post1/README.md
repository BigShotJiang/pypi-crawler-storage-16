# LlamaIndex Embeddings Integration: Openai
