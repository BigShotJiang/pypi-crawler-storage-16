from .main import BasicReturn, DataAndMsgReturn

__author__: str = 'tutosrive'
__org__: str = 'Dev2Forge'
__version__: str = '0.1.2'
__web_page__: str = 'https://pypi.org/project/BasicReturns'
__doc__: str = 'All functions ever return the same models with particulars properties'
__all__: list[str] = ['BasicReturn', 'DataAndMsgReturn']