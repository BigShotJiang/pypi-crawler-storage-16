__all__ = ("__version__", "BetaShape")

from importlib import metadata

from bayescoin.core import BetaShape

__version__ = metadata.version(__name__)
