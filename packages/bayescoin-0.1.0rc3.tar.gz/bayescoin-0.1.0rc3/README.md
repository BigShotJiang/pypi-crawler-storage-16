<div align="center">

# bayescoin

[![GitHub](https://img.shields.io/badge/github-code-blue?label=GitHub)](https://github.com/oyghen/bayescoin)
[![PyPI](https://img.shields.io/pypi/v/bayescoin?label=PyPI)](https://pypi.org/project/bayescoin)
[![License](https://img.shields.io/badge/License-BSD%203--Clause-blue.svg)](https://github.com/oyghen/bayescoin/blob/main/LICENSE)
[![CI](https://github.com/oyghen/bayescoin/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/oyghen/bayescoin/actions/workflows/ci.yml)

</div>

```shell
pip install bayescoin
```
