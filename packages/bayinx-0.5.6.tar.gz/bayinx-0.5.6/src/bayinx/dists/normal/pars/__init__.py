from .mean_prec import MeanPrecisionNormal as MeanPrecisionNormal
from .mean_scale import MeanScaleNormal as MeanScaleNormal
from .mean_var import MeanVarNormal as MeanVarNormal
