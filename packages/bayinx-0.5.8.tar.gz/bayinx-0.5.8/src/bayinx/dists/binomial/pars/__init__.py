from .prob_failure import ProbFailureBinomial as ProbFailureBinomial
from .prob_success import ProbSuccessBinomial as ProbSuccessBinomial
