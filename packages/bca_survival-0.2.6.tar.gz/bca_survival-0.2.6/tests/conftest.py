import matplotlib

# Use a non-interactive backend for tests
# This must be done before importing pyplot
matplotlib.use("Agg")
