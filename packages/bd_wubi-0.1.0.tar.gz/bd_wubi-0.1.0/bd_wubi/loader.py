"""数据集加载器的实现将在此补充。"""

from __future__ import annotations


def load_dataset(path: str) -> None:
    """在官方 bd-wubi 数据集就绪后加载该数据。"""
    raise NotImplementedError("数据集读取流程尚未实现")
