"""Tests for beacon-tv-downloader."""
