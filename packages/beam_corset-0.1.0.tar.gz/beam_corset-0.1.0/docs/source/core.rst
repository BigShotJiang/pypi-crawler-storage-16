:mod:`corset.core`
==================

.. automodule:: corset.core
    :members: