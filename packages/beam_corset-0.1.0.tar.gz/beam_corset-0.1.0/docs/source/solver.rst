:mod:`corset.solver`
====================

.. automodule:: corset.solver
    :members: