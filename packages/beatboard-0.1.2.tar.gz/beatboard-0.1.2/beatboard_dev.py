from src.beatboard import main

main()
