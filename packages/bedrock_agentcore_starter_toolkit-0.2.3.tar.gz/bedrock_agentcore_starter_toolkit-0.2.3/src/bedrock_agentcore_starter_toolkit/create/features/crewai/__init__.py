"""CrewAI Templates."""
