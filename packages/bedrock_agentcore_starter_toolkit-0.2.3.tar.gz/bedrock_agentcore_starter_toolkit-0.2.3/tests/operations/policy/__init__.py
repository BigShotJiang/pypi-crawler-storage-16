"""Tests for Bedrock AgentCore Policy operations."""
