"""CDK Templates."""
