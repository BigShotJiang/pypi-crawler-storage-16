"""Tests for CLI evaluation commands."""
