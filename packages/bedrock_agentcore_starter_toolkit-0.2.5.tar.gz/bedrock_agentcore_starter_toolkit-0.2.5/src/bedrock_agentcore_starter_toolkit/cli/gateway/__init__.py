"""BedrockAgentCore Gateway Starter Toolkit cli gateway package."""
