"""Tests for client interfaces."""
