def hello_plt() -> None:
    print(
        "Hi Bedrock engineer! bedrock_ge.plot is a placeholder module for Geotechnical Engineering plots."
    )
