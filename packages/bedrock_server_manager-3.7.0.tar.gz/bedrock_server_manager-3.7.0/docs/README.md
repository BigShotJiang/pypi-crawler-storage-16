# Bedrock Server Manager - Docs

Documentation moved to: https://bedrock-server-manager.readthedocs.io/en/latest/