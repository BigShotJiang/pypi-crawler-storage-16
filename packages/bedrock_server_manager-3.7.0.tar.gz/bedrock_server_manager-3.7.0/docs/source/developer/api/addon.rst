.. Bedrock Server Manager Addon API documentation file

Addon API Documentation
=======================

.. automodule:: bedrock_server_manager.api.addon
   :members:
   :undoc-members:
   :show-inheritance:
   :member-order: bysource