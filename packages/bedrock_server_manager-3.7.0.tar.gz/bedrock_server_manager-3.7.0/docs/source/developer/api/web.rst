.. Bedrock Server Manager Web API documentation file

Web API Documentation
=====================

.. automodule:: bedrock_server_manager.api.web
   :members:
   :undoc-members:
   :show-inheritance:
   :member-order: bysource