.. Bedrock Server Manager Settings Core documentation file

Settings Core Documentation
===========================

.. autoclass:: bedrock_server_manager.Settings
   :members:
   :undoc-members:
   :show-inheritance:
   :member-order: bysource

   .. automethod:: __init__