.. Bedrock Server Manager Error Class documentation file

Error Class Documentation
=========================

.. automodule:: bedrock_server_manager.error
   :members:
   :undoc-members:
   :show-inheritance:
   :exclude-members: UserExitError
   :member-order: bysource

   All custom exceptions inherit from :class:`~bedrock_server_manager.error.BSMError`.