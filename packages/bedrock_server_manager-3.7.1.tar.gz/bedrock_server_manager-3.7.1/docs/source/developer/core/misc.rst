.. Bedrock Server Manager Miscellaneous Core documentation file

Miscellaneous Core Documentation
================================

.. autofunction:: bedrock_server_manager.core.downloader.prune_old_downloads