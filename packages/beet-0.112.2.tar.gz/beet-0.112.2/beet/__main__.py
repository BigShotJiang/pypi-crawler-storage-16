from beet.toolchain.cli import main

main()
