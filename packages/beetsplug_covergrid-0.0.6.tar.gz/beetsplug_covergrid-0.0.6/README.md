# beetsplug-covergrid

[![PyPI - Version](https://img.shields.io/pypi/v/beetsplug-covergrid.svg)](https://pypi.org/project/beetsplug-covergrid)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/beetsplug-covergrid.svg)](https://pypi.org/project/beetsplug-covergrid)

## What Is This

A very (very) basic cover art browser for the `beets` music tagger.
It shows your album art in an attractive grid in a web browser:

![A screenshot of the cover grid interface. It shows about 25 album covers arranged in a grid that's 5 wide. Some of the album covers are just plain text, indicating the art is not available. There is a scroll bar on the right side.](./screenshot.jpeg "This is what covergrid looks like.")

-----

## Table of Contents

- [Installation](#installation)
- [Usage](#usage)
- [License](#license)

## Installation

If you installed `beets` with `pipx` like the
[instructions recommend](https://docs.beets.io/en/latest/guides/installation.html):

```console
pipx inject beets beetsplug-covergrid
```

If you installed `beets` with `pip`, I _think_ you can just do:

``` console
pip install beetsplug-covergrid
```

If not: I'm not sure! There are about as many ways to install things in Python
as there are people using Python.

## Usage

Add `covergrid` to the `plugins` section of your `beets` config.
If needed, configure it with the options described in the docs
for the `beets` [web plugin](https://docs.beets.io/en/latest/plugins/web.html#configuration).

Then start the server with

``` console
beet covergrid
```

and navigate to the URL it gives you in a web browser.

When you're done, terminate the server with ctrl-c.

Currently this is in "MVP" (minimum viable product) state, as follows:
* There is no interactivity besides scrolling.
* Albums are shown in random order and this cannot be changed.

This is a personal project and I've done the minimum to meet my needs at this time,
but I may expand the feature set as I get the urge.
See the Issues tab for things I'm thinking about doing, if any.

## Other Things

If you enjoy `beetsplug-covergrid` and are on a Mac,
you may find my other weird music tool
[alfred-mpd](https://github.com/valrus/alfred-mpd)
interesting.

I also make music, under the name "walrus promenade." Find it on
[bandcamp](https://walruspromenade.bandcamp.com/).

## License

`beetsplug-covergrid` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.

This plugin is based on the [web plugin](https://docs.beets.io/en/latest/plugins/web.html) included with `beets`.
