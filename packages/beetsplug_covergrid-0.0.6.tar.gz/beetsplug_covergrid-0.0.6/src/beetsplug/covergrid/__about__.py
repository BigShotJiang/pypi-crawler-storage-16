# SPDX-FileCopyrightText: 2025-present valrus <ian@mccowan.space>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.6"
