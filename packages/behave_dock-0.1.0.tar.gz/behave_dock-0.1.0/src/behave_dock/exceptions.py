class InvalidStateError(Exception):
    pass
