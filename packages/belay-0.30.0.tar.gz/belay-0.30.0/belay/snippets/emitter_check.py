@micropython.native
def __belay_emitter_test(a, b): return a + b
@micropython.viper
def __belay_emitter_test(a, b): return a + b
