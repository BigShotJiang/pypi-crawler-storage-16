# EvalRAG

Lightweight evaluation toolkit for Retrieval-Augmented Generation (RAG) systems.

## Install

```bash
pip install evalrag
