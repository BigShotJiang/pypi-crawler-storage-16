from peewee import SqliteDatabase

database = SqliteDatabase("./data/bsn.db")
