# better-todo-mcp

Python 库，用于按照 `example/task.md` 规范管理任务文件，提供：

- 解析/渲染：`mcp_tasks.parser`
- 任务操作：`mcp_tasks.ops`
- 文件处理与自动重命名：`mcp_tasks.storage`
- CLI：`better-todo-cli`
- MCP HTTP 服务器：`better-todo-mcp`

## 安装

```bash
pip install -e .
```

## CLI

- 列表：`better-todo-cli --file task.md list`
- 开始：`better-todo-cli --file task.md start "主任务/子任务"`
- 完成：`better-todo-cli --file task.md finish "主任务/子任务"`（返回下一任务，若全完成自动重命名）
- 添加：`better-todo-cli --file task.md add "新任务" --parent 主任务 --desc 描述`
- 删除：`better-todo-cli --file task.md delete "主任务/子任务"`

## MCP 服务器

启动：
```bash
better-todo-mcp --file task.md --host 0.0.0.0 --port 8008
```

接口示例：
- `GET /tasks` → 列表（包含状态、层级）
- `POST /tasks/start` `{path:"主任务/子任务"}`
- `POST /tasks/finish` `{path:"主任务/子任务"}`（返回下一任务；若全完成自动重命名）
- `POST /tasks/add` `{title:"新任务",parent:"可选父任务",desc:["行1","行2"]}`
- `DELETE /tasks` `{path:"主任务/子任务"}`
- `GET /tasks/next` → 返回当前优先任务（先 RUNNING 再 TODO）

## 开发

```bash
pip install -e ".[dev]"
pytest
```

