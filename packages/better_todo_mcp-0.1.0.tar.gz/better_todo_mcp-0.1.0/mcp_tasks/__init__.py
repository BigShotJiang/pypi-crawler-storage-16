"""
MCP task manager package.

Exposes high-level helpers for task operations and CLI entry.
"""

from .models import TaskNode, TaskStatus, TaskDocument
from .parser import parse_markdown, render_markdown
from .ops import (
    InvalidTransition,
    TaskNotFound,
    add_task,
    delete_task,
    finish_task,
    list_titles,
    render_node,
    select_next_task,
    start_task,
)
from .storage import load_document, save_document, maybe_rename_completed

__all__ = [
    "TaskNode",
    "TaskStatus",
    "TaskDocument",
    "parse_markdown",
    "render_markdown",
    "list_titles",
    "start_task",
    "finish_task",
    "add_task",
    "delete_task",
    "select_next_task",
    "TaskNotFound",
    "InvalidTransition",
    "render_node",
    "load_document",
    "save_document",
    "maybe_rename_completed",
]

