from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import List

from . import (
    add_task,
    delete_task,
    finish_task,
    list_titles,
    load_document,
    maybe_rename_completed,
    render_node,
    save_document,
    select_next_task,
    start_task,
)
from .models import TaskDocument


def _parse_path(path_str: str) -> List[str]:
    return [p for p in path_str.split("/") if p]


def _echo_next(next_task) -> None:
    if next_task is None:
        print("已无未完成任务。")
    else:
        print("下一个任务:")
        print(render_node(next_task, as_main=False))


def cmd_list(doc: TaskDocument) -> None:
    for line in list_titles(doc):
        print(line)


def cmd_start(doc: TaskDocument, path: List[str], file_path: Path) -> None:
    updated = start_task(doc, path)
    save_document(updated, file_path)
    node, _ = _get_node(updated, path)
    print(render_node(node, as_main=len(path) == 1))


def cmd_finish(doc: TaskDocument, path: List[str], file_path: Path) -> None:
    updated, _ = finish_task(doc, path)
    save_document(updated, file_path)
    renamed = maybe_rename_completed(updated, file_path)
    if renamed:
        print(f"全部完成，文件已重命名为: {renamed.name}")
    next_task = select_next_task(updated)
    _echo_next(next_task)


def cmd_add(doc: TaskDocument, title: str, parent: str, file_path: Path, desc: List[str]) -> None:
    updated = add_task(doc, title=title, description=desc, parent_title=parent or None)
    save_document(updated, file_path)
    print(f"已添加任务: {title}")


def cmd_delete(doc: TaskDocument, path: List[str], file_path: Path) -> None:
    updated = delete_task(doc, path)
    save_document(updated, file_path)
    print(f"已删除任务: {'/'.join(path)}")


def _get_node(doc: TaskDocument, path: List[str]):
    from .ops import _find_task  # local import to avoid export

    return _find_task(doc, path)


def main(argv=None) -> int:
    argv = argv or sys.argv[1:]
    parser = argparse.ArgumentParser(description="task.md MCP helper")
    parser.add_argument("--file", default="task.md", help="task markdown path")

    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("list", help="列出任务标题和状态")

    p_start = subparsers.add_parser("start", help="开始任务")
    p_start.add_argument("path", help="路径，格式：主任务/子任务")

    p_finish = subparsers.add_parser("finish", help="完成任务")
    p_finish.add_argument("path", help="路径，格式：主任务/子任务")

    p_add = subparsers.add_parser("add", help="添加任务(默认主任务)")
    p_add.add_argument("title", help="任务标题")
    p_add.add_argument("--parent", help="父任务标题（可选，指定则添加子任务）")
    p_add.add_argument("--desc", nargs="*", default=[], help="描述行，可多行")

    p_delete = subparsers.add_parser("delete", help="删除任务")
    p_delete.add_argument("path", help="路径，格式：主任务/子任务")

    args = parser.parse_args(argv)
    file_path = Path(args.file)
    doc = load_document(file_path)

    try:
        if args.command == "list":
            cmd_list(doc)
        elif args.command == "start":
            cmd_start(doc, _parse_path(args.path), file_path)
        elif args.command == "finish":
            cmd_finish(doc, _parse_path(args.path), file_path)
        elif args.command == "add":
            cmd_add(doc, args.title, args.parent, file_path, args.desc)
        elif args.command == "delete":
            cmd_delete(doc, _parse_path(args.path), file_path)
    except Exception as exc:  # pragma: no cover - user feedback
        print(f"错误: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

