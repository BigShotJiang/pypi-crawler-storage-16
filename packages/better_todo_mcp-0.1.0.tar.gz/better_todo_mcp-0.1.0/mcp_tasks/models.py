from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional


class TaskStatus(str, Enum):
    TODO = "[]"
    RUNNING = "[-]"
    DONE = "[X]"

    @classmethod
    def from_brackets(cls, text: str) -> "TaskStatus":
        text = text.strip()
        mapping = {
            "[]": cls.TODO,
            "[-]": cls.RUNNING,
            "[X]": cls.DONE,
        }
        if text not in mapping:
            raise ValueError(f"Unknown status marker: {text!r}")
        return mapping[text]


@dataclass
class TaskNode:
    title: str
    status: TaskStatus
    description: List[str] = field(default_factory=list)
    children: List["TaskNode"] = field(default_factory=list)

    def clone(self) -> "TaskNode":
        return TaskNode(
            title=self.title,
            status=self.status,
            description=list(self.description),
            children=[child.clone() for child in self.children],
        )

    def all_children(self) -> List["TaskNode"]:
        items: List[TaskNode] = []
        for child in self.children:
            items.append(child)
            items.extend(child.all_children())
        return items

    def is_done(self) -> bool:
        return self.status == TaskStatus.DONE and all(
            child.is_done() for child in self.children
        )


@dataclass
class TaskDocument:
    """Represents one task markdown document."""

    preamble: List[str]
    tasks: List[TaskNode]
    trailer: List[str] = field(default_factory=list)

    def clone(self) -> "TaskDocument":
        return TaskDocument(
            preamble=list(self.preamble),
            tasks=[t.clone() for t in self.tasks],
            trailer=list(self.trailer),
        )

    def all_nodes(self) -> List[TaskNode]:
        nodes: List[TaskNode] = []
        for task in self.tasks:
            nodes.append(task)
            nodes.extend(task.all_children())
        return nodes

    def is_all_done(self) -> bool:
        return len(self.tasks) > 0 and all(t.is_done() for t in self.tasks)

