from __future__ import annotations

from typing import Iterable, List, Optional, Tuple

from .models import TaskDocument, TaskNode, TaskStatus
from .parser import render_markdown


class TaskNotFound(Exception):
    pass


class InvalidTransition(Exception):
    pass


def list_titles(doc: TaskDocument) -> List[str]:
    lines: List[str] = []
    for task in doc.tasks:
        lines.append(f"{task.status.value} {task.title}")
        for child in task.children:
            lines.append(f"  {child.status.value} {child.title}")
    return lines


def _find_task(doc: TaskDocument, path: Iterable[str]) -> Tuple[TaskNode, Optional[TaskNode]]:
    """Return (target, parent) where parent is None for top-level."""
    titles = list(path)
    if not titles:
        raise TaskNotFound("Empty path")
    main_title = titles[0]
    target: Optional[TaskNode] = None
    parent: Optional[TaskNode] = None
    for main in doc.tasks:
        if main.title == main_title:
            if len(titles) == 1:
                target = main
                parent = None
                break
            sub_title = titles[1]
            for child in main.children:
                if child.title == sub_title:
                    target = child
                    parent = main
                    break
    if target is None:
        raise TaskNotFound(f"Task not found: {' / '.join(titles)}")
    return target, parent


def start_task(doc: TaskDocument, path: Iterable[str]) -> TaskDocument:
    new_doc = doc.clone()
    node, _ = _find_task(new_doc, path)
    if node.status != TaskStatus.TODO:
        raise InvalidTransition("Only TODO can be started")
    node.status = TaskStatus.RUNNING
    return new_doc


def finish_task(doc: TaskDocument, path: Iterable[str]) -> Tuple[TaskDocument, Optional[TaskNode]]:
    new_doc = doc.clone()
    node, _ = _find_task(new_doc, path)
    if node.status != TaskStatus.RUNNING:
        raise InvalidTransition("Only RUNNING can be finished")
    node.status = TaskStatus.DONE
    next_task = select_next_task(new_doc)
    return new_doc, next_task


def add_task(
    doc: TaskDocument,
    title: str,
    description: Optional[List[str]] = None,
    parent_title: Optional[str] = None,
    status: TaskStatus = TaskStatus.TODO,
) -> TaskDocument:
    new_doc = doc.clone()
    desc = description or []
    if parent_title is None:
        new_doc.tasks.append(TaskNode(title=title, status=status, description=desc, children=[]))
        return new_doc

    for main in new_doc.tasks:
        if main.title == parent_title:
            main.children.append(TaskNode(title=title, status=status, description=desc, children=[]))
            return new_doc
    raise TaskNotFound(f"Parent task not found: {parent_title}")


def delete_task(doc: TaskDocument, path: Iterable[str]) -> TaskDocument:
    new_doc = doc.clone()
    titles = list(path)
    if not titles:
        raise TaskNotFound("Empty path")
    main_title = titles[0]
    if len(titles) == 1:
        new_doc.tasks = [t for t in new_doc.tasks if t.title != main_title]
        return new_doc

    sub_title = titles[1]
    for main in new_doc.tasks:
        if main.title == main_title:
            before = len(main.children)
            main.children = [c for c in main.children if c.title != sub_title]
            if len(main.children) == before:
                raise TaskNotFound(f"Sub task not found: {sub_title}")
            return new_doc
    raise TaskNotFound(f"Task not found: {main_title}")


def select_next_task(doc: TaskDocument) -> Optional[TaskNode]:
    """Prefer running tasks, otherwise first TODO in order."""
    for node in _walk(doc.tasks):
        if node.status == TaskStatus.RUNNING:
            return node
    for node in _walk(doc.tasks):
        if node.status == TaskStatus.TODO:
            return node
    return None


def _walk(tasks: List[TaskNode]) -> Iterable[TaskNode]:
    for task in tasks:
        yield task
        for child in task.children:
            yield child


def render_node(node: TaskNode, as_main: bool = True) -> str:
    """Render a single node subtree for echoing."""
    lines = [f"# {node.status.value}{node.title}"] if as_main else [f"- {node.status.value}{node.title}"]
    lines.extend(node.description)
    for child in node.children:
        lines.append(f"- {child.status.value}{child.title}")
        for line in child.description:
            lines.append(line if line.strip() == "" else f"    {line.lstrip()}")
    return "\n".join(lines)

