from __future__ import annotations

import re
from typing import List, Tuple

from .models import TaskDocument, TaskNode, TaskStatus

HeadingPattern = re.compile(r"^#\s+\[(.*?)\]\s*(.+)$")
BulletPattern = re.compile(r"^-\s+\[(.*?)\]\s*(.+)$")


def _consume_description(lines: List[str], start: int) -> Tuple[List[str], int]:
    """Collect description lines until a heading/bullet or EOF."""
    desc: List[str] = []
    i = start
    while i < len(lines):
        line = lines[i]
        if HeadingPattern.match(line) or BulletPattern.match(line):
            break
        desc.append(line)
        i += 1
    return desc, i


def parse_markdown(text: str) -> TaskDocument:
    lines = text.splitlines()
    tasks: List[TaskNode] = []

    # Preamble: everything before the first heading
    i = 0
    while i < len(lines) and not HeadingPattern.match(lines[i]):
        i += 1
    preamble = lines[:i]

    while i < len(lines):
        heading_match = HeadingPattern.match(lines[i])
        if not heading_match:
            # Skip unexpected lines
            i += 1
            continue
        status_text, title = heading_match.groups()
        status = TaskStatus.from_brackets(f"[{status_text}]")
        i += 1

        desc, i = _consume_description(lines, i)

        children: List[TaskNode] = []
        while i < len(lines):
            # Stop if we reached next main heading
            if HeadingPattern.match(lines[i]):
                break
            bullet_match = BulletPattern.match(lines[i])
            if not bullet_match:
                # Non-bullet under a main task; treat as extra description
                desc.append(lines[i])
                i += 1
                continue

            sub_status_text, sub_title = bullet_match.groups()
            sub_status = TaskStatus.from_brackets(f"[{sub_status_text}]")
            i += 1
            sub_desc, i = _consume_description(lines, i)
            children.append(
                TaskNode(
                    title=sub_title,
                    status=sub_status,
                    description=sub_desc,
                    children=[],
                )
            )

        tasks.append(TaskNode(title=title, status=status, description=desc, children=children))

    trailer: List[str] = []
    return TaskDocument(preamble=preamble, tasks=tasks, trailer=trailer)


def _render_desc(desc: List[str]) -> List[str]:
    return desc


def render_markdown(doc: TaskDocument) -> str:
    out_lines: List[str] = []
    out_lines.extend(doc.preamble)
    if doc.preamble and (len(doc.tasks) > 0):
        # ensure a blank line separation
        if doc.preamble[-1].strip() != "":
            out_lines.append("")

    for idx, task in enumerate(doc.tasks):
        if idx > 0:
            # keep a blank line between main tasks
            if out_lines and out_lines[-1].strip() != "":
                out_lines.append("")
        out_lines.append(f"# {task.status.value}{task.title}")
        out_lines.extend(_render_desc(task.description))
        for child in task.children:
            out_lines.append(f"- {child.status.value}{child.title}")
            # indent descriptions to keep structure readable
            for line in _render_desc(child.description):
                out_lines.append(line if line.strip() == "" else f"    {line.lstrip()}")

    out_lines.extend(doc.trailer)
    return "\n".join(out_lines).rstrip() + "\n"

