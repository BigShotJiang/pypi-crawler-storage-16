from __future__ import annotations

from pathlib import Path
from typing import List, Optional

import uvicorn
from fastapi import Body, FastAPI, HTTPException, Query
from pydantic import BaseModel, Field

from .models import TaskDocument, TaskNode, TaskStatus
from .ops import (
    InvalidTransition,
    TaskNotFound,
    add_task,
    delete_task,
    finish_task,
    list_titles,
    render_node,
    select_next_task,
    start_task,
)
from .storage import load_document, maybe_rename_completed, save_document

app = FastAPI(title="Better Todo MCP", version="0.1.0")


def _parse_path(path: str) -> List[str]:
    parts = [p for p in path.split("/") if p]
    if not parts:
        raise HTTPException(status_code=400, detail="path 不能为空")
    return parts


def _doc(file: str) -> TaskDocument:
    file_path = Path(file)
    if not file_path.exists():
        raise HTTPException(status_code=404, detail=f"未找到文件 {file_path}")
    return load_document(file_path)


def _task_items(doc: TaskDocument) -> List[dict]:
    items: List[dict] = []
    for task in doc.tasks:
        items.append(
            {
                "path": task.title,
                "title": task.title,
                "status": task.status.value,
                "level": 0,
            }
        )
        for child in task.children:
            items.append(
                {
                    "path": f"{task.title}/{child.title}",
                    "title": child.title,
                    "status": child.status.value,
                    "level": 1,
                }
            )
    return items


def _node_info(node: TaskNode, parent_title: Optional[str]) -> dict:
    return {
        "path": node.title if parent_title is None else f"{parent_title}/{node.title}",
        "title": node.title,
        "status": node.status.value,
        "description": node.description,
        "is_main": parent_title is None,
        "text": render_node(node, as_main=parent_title is None),
    }


class PathRequest(BaseModel):
    path: str = Field(..., description="路径，格式：主任务/子任务")


class AddRequest(BaseModel):
    title: str
    parent: Optional[str] = Field(None, description="父任务标题，可为空代表主任务")
    desc: List[str] = Field(default_factory=list, description="描述行")


class FinishResponse(BaseModel):
    renamed_to: Optional[str] = Field(None, description="全部完成后重命名的新文件名")
    next_task: Optional[dict] = Field(None, description="下一任务信息，优先进行中")


@app.get("/tasks", summary="列出任务标题和状态")
def list_tasks(file: str = Query("task.md")) -> List[dict]:
    doc = _doc(file)
    return _task_items(doc)


@app.get("/tasks/next", summary="返回下一任务（先 RUNNING 后 TODO）")
def get_next_task(file: str = Query("task.md")) -> Optional[dict]:
    doc = _doc(file)
    next_task = select_next_task(doc)
    if not next_task:
        return None
    parent_title = None
    # Find parent if child
    for main in doc.tasks:
        if next_task is main:
            parent_title = None
            break
        if next_task in main.children:
            parent_title = main.title
            break
    return _node_info(next_task, parent_title)


@app.post("/tasks/start", summary="开始任务，将 [] -> [-]")
def start(PathReq: PathRequest = Body(...), file: str = Query("task.md")) -> dict:
    file_path = Path(file)
    doc = _doc(file)
    try:
        updated = start_task(doc, _parse_path(PathReq.path))
    except (TaskNotFound, InvalidTransition) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    save_document(updated, file_path)
    node, parent = _get_node(updated, _parse_path(PathReq.path))
    parent_title = None if parent is None else parent.title
    return _node_info(node, parent_title)


@app.post("/tasks/finish", summary="完成任务，将 [-] -> [X]，并返回下一任务")
def finish(PathReq: PathRequest = Body(...), file: str = Query("task.md")) -> FinishResponse:
    file_path = Path(file)
    doc = _doc(file)
    try:
        updated, _ = finish_task(doc, _parse_path(PathReq.path))
    except (TaskNotFound, InvalidTransition) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    save_document(updated, file_path)
    renamed = maybe_rename_completed(updated, file_path)
    next_task = select_next_task(updated)
    parent_title = None
    if next_task:
        for main in updated.tasks:
            if next_task is main:
                parent_title = None
                break
            if next_task in main.children:
                parent_title = main.title
                break
    return FinishResponse(
        renamed_to=renamed.name if renamed else None,
        next_task=_node_info(next_task, parent_title) if next_task else None,
    )


@app.post("/tasks/add", summary="添加任务，默认添加到主任务末尾")
def add(req: AddRequest = Body(...), file: str = Query("task.md")) -> dict:
    file_path = Path(file)
    doc = _doc(file)
    try:
        updated = add_task(
            doc,
            title=req.title,
            description=req.desc,
            parent_title=req.parent,
            status=TaskStatus.TODO,
        )
    except TaskNotFound as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    save_document(updated, file_path)
    return {"message": "ok"}


@app.delete("/tasks", summary="删除任务")
def delete(PathReq: PathRequest = Body(...), file: str = Query("task.md")) -> dict:
    file_path = Path(file)
    doc = _doc(file)
    try:
        updated = delete_task(doc, _parse_path(PathReq.path))
    except TaskNotFound as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    save_document(updated, file_path)
    return {"message": "ok"}


def _get_node(doc: TaskDocument, path: List[str]):
    from .ops import _find_task  # local import to avoid exporting private

    return _find_task(doc, path)


def main(argv: Optional[List[str]] = None) -> int:
    import argparse

    parser = argparse.ArgumentParser(description="Better Todo MCP server")
    parser.add_argument("--file", default="task.md", help="任务文件路径")
    parser.add_argument("--host", default="0.0.0.0", help="监听地址")
    parser.add_argument("--port", type=int, default=8008, help="监听端口")
    args = parser.parse_args(argv)

    uvicorn.run(
        "mcp_tasks.server:app",
        host=args.host,
        port=args.port,
        reload=False,
        factory=False,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

