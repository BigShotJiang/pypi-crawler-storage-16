from __future__ import annotations

import datetime as _dt
from pathlib import Path
from typing import Optional

from .models import TaskDocument
from .parser import parse_markdown, render_markdown


def load_document(path: Path) -> TaskDocument:
    text = path.read_text(encoding="utf-8")
    return parse_markdown(text)


def save_document(doc: TaskDocument, path: Path) -> None:
    content = render_markdown(doc)
    path.write_text(content, encoding="utf-8")


def maybe_rename_completed(doc: TaskDocument, path: Path) -> Optional[Path]:
    if not doc.is_all_done():
        return None
    date_str = _dt.date.today().strftime("%Y%m%d")
    target = path.with_name(f"task-{date_str}{path.suffix}")
    if target.exists():
        # Avoid clobbering existing completed file
        target = path.with_name(f"task-{date_str}-1{path.suffix}")
    path.rename(target)
    return target

