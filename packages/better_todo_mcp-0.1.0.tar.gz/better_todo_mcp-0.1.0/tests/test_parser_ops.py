from pathlib import Path

from mcp_tasks import (
    TaskStatus,
    add_task,
    finish_task,
    load_document,
    maybe_rename_completed,
    parse_markdown,
    render_markdown,
    save_document,
    select_next_task,
    start_task,
)


SAMPLE = """---
[]表示还未开始
---
# []主任务1
主任务1描述
- []子任务1
    - 子任务1描述

# [-]主任务2
- []子任务2
    - 子任务2描述
"""


def test_parse_roundtrip():
    doc = parse_markdown(SAMPLE)
    assert len(doc.tasks) == 2
    assert doc.tasks[0].title == "主任务1"
    assert doc.tasks[0].children[0].title == "子任务1"
    text = render_markdown(doc)
    doc2 = parse_markdown(text)
    assert doc2.tasks[0].status == TaskStatus.TODO
    assert doc2.tasks[1].status == TaskStatus.RUNNING


def test_start_finish_next_prefers_running():
    doc = parse_markdown(SAMPLE)
    doc = start_task(doc, ["主任务1", "子任务1"])
    updated, next_task = finish_task(doc, ["主任务1", "子任务1"])
    # 应优先已有进行中的任务（主任务2）
    assert next_task is not None
    assert next_task.title == "主任务2"
    assert next_task.status == TaskStatus.RUNNING


def test_add_and_rename(tmp_path: Path):
    doc = parse_markdown(SAMPLE)
    doc = add_task(doc, title="新增主任务", description=["说明"])
    file_path = tmp_path / "task.md"
    save_document(doc, file_path)

    loaded = load_document(file_path)
    # 标记全部完成后应重命名
    for node in loaded.tasks:
        node.status = TaskStatus.DONE
        for child in node.children:
            child.status = TaskStatus.DONE

    save_document(loaded, file_path)
    renamed = maybe_rename_completed(loaded, file_path)
    assert renamed is not None
    assert renamed.exists()
    assert not file_path.exists()

