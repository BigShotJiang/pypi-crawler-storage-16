from __future__ import annotations

from typing import TYPE_CHECKING

from pydantic import TypeAdapter

from bfabric.entities.core.entity import Entity
from bfabric.entities.core.has_one import HasOne
from bfabric.utils.path_safe_name import PathSafeStr

if TYPE_CHECKING:
    from bfabric.entities.executable import Executable
    from bfabric.entities.storage import Storage


class Application(Entity):
    ENDPOINT = "application"

    storage: HasOne[Storage] = HasOne(bfabric_field="storage")
    executable: HasOne[Executable] = HasOne(bfabric_field="executable")

    @property
    def technology_folder_name(self) -> PathSafeStr:
        """Returns the technology which is used e.g. for output registration."""
        technology = self.data_dict["technology"]
        if isinstance(technology, list):
            # TODO certainly this can be improved, also in the future it may always be a list (right now it is not
            #      rolled out yet)
            technology = sorted(technology)[0]
        return TypeAdapter(PathSafeStr).validate_python(technology)
