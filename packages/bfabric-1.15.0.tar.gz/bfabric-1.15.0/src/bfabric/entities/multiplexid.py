from __future__ import annotations

from bfabric.entities.core.entity import Entity


class MultiplexId(Entity):
    ENDPOINT = "multiplexid"
