"""Dispatch module for the BFB delivery system."""
