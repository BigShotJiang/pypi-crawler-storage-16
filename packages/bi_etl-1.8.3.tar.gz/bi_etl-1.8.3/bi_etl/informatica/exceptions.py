"""
Created on May 4, 2015

@author: Derek Wood
"""


class NoObjects(Exception):
    pass
