"""
Created on Apr 23, 2015

@author: Derek Wood
"""


class ParameterError(Exception):
    pass
