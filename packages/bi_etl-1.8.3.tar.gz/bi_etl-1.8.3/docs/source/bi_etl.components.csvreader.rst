bi\_etl.components.csvreader module
===================================

.. autoclass:: bi_etl.components.csvreader.CSVReader
   :members:
   :undoc-members:
   :show-inheritance:
   :noindex:
