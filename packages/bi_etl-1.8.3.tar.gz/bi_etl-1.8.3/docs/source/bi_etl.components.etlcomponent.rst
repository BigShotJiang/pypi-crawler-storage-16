bi\_etl.components.etlcomponent module
======================================

.. automodule:: bi_etl.components.etlcomponent
   :members:
   :undoc-members:
   :show-inheritance:
