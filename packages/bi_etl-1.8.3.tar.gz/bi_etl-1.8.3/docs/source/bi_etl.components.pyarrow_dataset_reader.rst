bi\_etl.components.pyarrow\_dataset\_reader module
==================================================

.. automodule:: bi_etl.components.pyarrow_dataset_reader
   :members:
   :undoc-members:
   :show-inheritance:
