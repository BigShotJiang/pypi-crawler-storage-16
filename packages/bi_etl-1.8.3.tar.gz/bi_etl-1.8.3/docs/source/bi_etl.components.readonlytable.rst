bi\_etl.components.readonlytable module
=======================================

.. automodule:: bi_etl.components.readonlytable
   :members:
   :undoc-members:
   :show-inheritance:
