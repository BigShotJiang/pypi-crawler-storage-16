bi\_etl.components.row.cached\_frozenset module
===============================================

.. automodule:: bi_etl.components.row.cached_frozenset
   :members:
   :undoc-members:
   :show-inheritance:
