bi\_etl.components.row.column\_difference module
================================================

.. automodule:: bi_etl.components.row.column_difference
   :members:
   :undoc-members:
   :show-inheritance:
