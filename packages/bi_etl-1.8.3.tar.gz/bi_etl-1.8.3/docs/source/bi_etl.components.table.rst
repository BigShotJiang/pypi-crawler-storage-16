bi\_etl.components.table module
===============================

.. automodule:: bi_etl.components.table
   :members:
   :undoc-members:
   :show-inheritance:
