bi\_etl.components.w3c\_reader module
=====================================

.. automodule:: bi_etl.components.w3c_reader
   :members:
   :undoc-members:
   :show-inheritance:
