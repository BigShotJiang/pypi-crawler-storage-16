bi\_etl.components.xlsx\_reader module
======================================

.. automodule:: bi_etl.components.xlsx_reader
   :members:
   :undoc-members:
   :show-inheritance:
