bi\_etl.components.xlsx\_writer module
======================================

.. automodule:: bi_etl.components.xlsx_writer
   :members:
   :undoc-members:
   :show-inheritance:
