bi\_etl.config.bi\_etl\_config\_base module
===========================================

.. automodule:: bi_etl.config.bi_etl_config_base
   :members:
   :undoc-members:
   :show-inheritance:
