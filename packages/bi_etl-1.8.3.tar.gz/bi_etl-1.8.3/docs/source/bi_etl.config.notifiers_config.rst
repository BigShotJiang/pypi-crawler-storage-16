bi\_etl.config.notifiers\_config module
=======================================

.. automodule:: bi_etl.config.notifiers_config
   :members:
   :undoc-members:
   :show-inheritance:
