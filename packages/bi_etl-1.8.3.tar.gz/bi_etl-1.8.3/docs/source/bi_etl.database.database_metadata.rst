bi\_etl.database.database\_metadata module
==========================================

.. automodule:: bi_etl.database.database_metadata
   :members:
   :undoc-members:
   :show-inheritance:
