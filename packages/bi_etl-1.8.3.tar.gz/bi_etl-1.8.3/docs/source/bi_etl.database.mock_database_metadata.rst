bi\_etl.database.mock\_database\_metadata module
================================================

.. automodule:: bi_etl.database.mock_database_metadata
   :members:
   :undoc-members:
   :show-inheritance:
