bi\_etl.informatica.exceptions module
=====================================

.. automodule:: bi_etl.informatica.exceptions
   :members:
   :undoc-members:
   :show-inheritance:
