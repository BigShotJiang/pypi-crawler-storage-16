bi\_etl.informatica.pm\_config module
=====================================

.. automodule:: bi_etl.informatica.pm_config
   :members:
   :undoc-members:
   :show-inheritance:
