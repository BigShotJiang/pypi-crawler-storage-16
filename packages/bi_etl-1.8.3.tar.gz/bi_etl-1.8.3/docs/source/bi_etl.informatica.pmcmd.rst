bi\_etl.informatica.pmcmd module
================================

.. automodule:: bi_etl.informatica.pmcmd
   :members:
   :undoc-members:
   :show-inheritance:
