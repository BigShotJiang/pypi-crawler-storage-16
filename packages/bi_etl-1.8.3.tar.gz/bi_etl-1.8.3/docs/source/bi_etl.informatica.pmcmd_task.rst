bi\_etl.informatica.pmcmd\_task module
======================================

.. automodule:: bi_etl.informatica.pmcmd_task
   :members:
   :undoc-members:
   :show-inheritance:
