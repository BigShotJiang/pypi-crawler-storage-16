bi\_etl.informatica.pmrep module
================================

.. automodule:: bi_etl.informatica.pmrep
   :members:
   :undoc-members:
   :show-inheritance:
