bi\_etl.lookups.range\_lookup module
====================================

.. automodule:: bi_etl.lookups.range_lookup
   :members:
   :undoc-members:
   :show-inheritance:
