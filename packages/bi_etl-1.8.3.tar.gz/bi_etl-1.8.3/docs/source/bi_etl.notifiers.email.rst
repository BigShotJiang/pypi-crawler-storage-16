bi\_etl.notifiers.email module
==============================

.. automodule:: bi_etl.notifiers.email
   :members:
   :undoc-members:
   :show-inheritance:
