bi\_etl.notifiers.jira module
=============================

.. automodule:: bi_etl.notifiers.jira
   :members:
   :undoc-members:
   :show-inheritance:
