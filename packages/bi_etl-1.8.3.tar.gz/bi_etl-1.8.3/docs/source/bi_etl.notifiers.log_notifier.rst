bi\_etl.notifiers.log\_notifier module
======================================

.. automodule:: bi_etl.notifiers.log_notifier
   :members:
   :undoc-members:
   :show-inheritance:
