bi\_etl.notifiers.notifier\_base module
=======================================

.. automodule:: bi_etl.notifiers.notifier_base
   :members:
   :undoc-members:
   :show-inheritance:
