bi\_etl.notifiers package
=========================

.. toctree::
   :maxdepth: 1

   bi_etl.notifiers.email
   bi_etl.notifiers.jira
   bi_etl.notifiers.log_notifier
   bi_etl.notifiers.notifier_base
   bi_etl.notifiers.slack

.. automodule:: bi_etl.notifiers
   :members:
   :undoc-members:
   :show-inheritance:
