bi\_etl.notifiers.slack module
==============================

.. automodule:: bi_etl.notifiers.slack
   :members:
   :undoc-members:
   :show-inheritance:
