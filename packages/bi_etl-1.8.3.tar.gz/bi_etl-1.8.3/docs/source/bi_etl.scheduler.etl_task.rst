bi\_etl.scheduler.task module
=============================

.. automodule:: bi_etl.scheduler.etl_task
   :members:
   :undoc-members:
   :show-inheritance:
