bi\_etl.statement\_queue module
===============================

.. automodule:: bi_etl.statement_queue
   :members:
   :undoc-members:
   :show-inheritance:
