bi\_etl.statistics module
=========================

.. automodule:: bi_etl.statistics
   :members:
   :undoc-members:
   :show-inheritance:
