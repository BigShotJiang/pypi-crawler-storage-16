bi\_etl.utility.case\_insentive\_set module
===========================================

.. automodule:: bi_etl.utility.case_insentive_set
   :members:
   :undoc-members:
   :show-inheritance:
