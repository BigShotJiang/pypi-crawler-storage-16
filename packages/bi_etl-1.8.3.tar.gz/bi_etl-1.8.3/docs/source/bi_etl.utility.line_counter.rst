bi\_etl.utility.line\_counter module
====================================

.. automodule:: bi_etl.utility.line_counter
   :members:
   :undoc-members:
   :show-inheritance:
