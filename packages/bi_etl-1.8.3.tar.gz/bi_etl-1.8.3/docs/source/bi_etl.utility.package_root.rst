bi\_etl.utility.package\_root module
====================================

.. automodule:: bi_etl.utility.package_root
   :members:
   :undoc-members:
   :show-inheritance:
