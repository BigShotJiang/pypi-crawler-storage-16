bi\_etl.utility.run\_sql\_script module
=======================================

.. automodule:: bi_etl.utility.run_sql_script
   :members:
   :undoc-members:
   :show-inheritance:
