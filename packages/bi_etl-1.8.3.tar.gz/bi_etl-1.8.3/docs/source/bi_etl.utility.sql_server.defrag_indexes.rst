bi\_etl.utility.sql\_server.defrag\_indexes module
==================================================

.. automodule:: bi_etl.utility.sql_server.defrag_indexes
   :members:
   :undoc-members:
   :show-inheritance:
