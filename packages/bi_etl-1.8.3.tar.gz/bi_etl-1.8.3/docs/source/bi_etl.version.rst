bi\_etl.version module
======================

.. automodule:: bi_etl.version
   :members:
   :undoc-members:
   :show-inheritance:
