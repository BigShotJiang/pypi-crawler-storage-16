#!/bin/bash
ssh derekiw@bietl.dev "ls upload"
