SELECT *
from information_schema.tables