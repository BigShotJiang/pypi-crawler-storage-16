"""
BiaPy data package.

This package provides modules and utilities for data loading, normalization,
pre-processing, and manipulation for deep learning workflows in BiaPy.
"""