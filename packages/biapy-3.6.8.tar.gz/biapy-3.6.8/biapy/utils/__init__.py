"""
BiaPy utils package.

This package contains general-purpose utility modules used across BiaPy, including:

- callbacks
- misc
- util
"""
