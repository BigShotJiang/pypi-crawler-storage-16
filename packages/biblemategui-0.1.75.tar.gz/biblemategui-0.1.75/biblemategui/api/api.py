from typing import Optional

def get_api_content(query: str, token: Optional[str] = None):
    return f"Processing bible query: '{query}"