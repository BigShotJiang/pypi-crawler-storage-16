from biblemategui import getBibleVersionList
from agentmake.plugins.uba.lib.BibleParser import BibleVerseParser

def get_bible_chapter(version: str, book: int, chapter: int):
    return f"{version} {book}:{chapter}"

def get_tool_content(tool: str, query: str):
    return f"{tool} {query}"

def get_api_content(query: str, language: str = 'eng'):
    bibles = getBibleVersionList()
    parser = BibleVerseParser(False, language=language)
    refs = parser.extractAllReferences(query)
    if query.lower().startswith("bible:::") and refs:
        query = query[8:]
        b,c,*_ = refs[0]
        if ":::" in query and query.split(":::", 1)[0].strip() in bibles:
            version, query = query.split(":::", 1)
            version = version.strip()
        else:
            version = "NET"
        return get_bible_chapter(version=version, book=b, chapter=c)
    elif ":::" in query and query.split(":::", 1)[0].strip().lower() in ["audio", "verses", "commentary"]:
        tool, query = query.split(":::", 1)
        tool = tool.strip()
        return get_tool_content(tool, query)
    return ""