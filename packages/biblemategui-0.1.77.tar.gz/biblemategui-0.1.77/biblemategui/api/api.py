from biblemategui import getBibleVersionList
from biblemategui.fx.bible import getBiblePath, getBibleChapterVerses
from agentmake.plugins.uba.lib.BibleParser import BibleVerseParser

def get_tool_content(tool: str, query: str, custom: bool = False):
    return f"{tool} {query}"

def get_api_content(query: str, language: str = 'eng', custom: bool = False):
    bibles = getBibleVersionList(custom)
    parser = BibleVerseParser(False, language=language)
    refs = parser.extractAllReferences(query)
    if query.lower().startswith("bible:::") and refs:
        query = query[8:]
        b,c,*_ = refs[0]
        if ":::" in query and query.split(":::", 1)[0].strip() in bibles:
            version, query = query.split(":::", 1)
            version = version.strip()
        else:
            version = "NET"
        db = getBiblePath(version)
        verses = getBibleChapterVerses(db, b, c)
        chapter = f"# {parser.bcvToVerseReference(b,c,1)}[:-2]\n\n"
        if verses:
            verses = [f"[{v}] {verse_text}" for *_, v, verse_text in verses]
            chapter += "\n".join(verses)
        return chapter
    elif ":::" in query and query.split(":::", 1)[0].strip().lower() in ["audio", "verses", "commentary"]:
        tool, query = query.split(":::", 1)
        tool = tool.strip()
        return get_tool_content(tool, query, custom)
    return ""