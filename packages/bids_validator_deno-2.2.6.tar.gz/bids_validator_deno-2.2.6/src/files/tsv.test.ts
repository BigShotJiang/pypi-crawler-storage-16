import {
  assert,
  assertEquals,
  assertNotStrictEquals,
  assertObjectMatch,
  assertStrictEquals,
} from '@std/assert'
import { pathToFile } from './filetree.test.ts'
import { BIDSFileDeno } from './deno.ts'
import { loadTSV, loadTSVGZ } from './tsv.ts'
import { ColumnsMap } from '../types/columns.ts'
import { testAsyncFileAccess } from './access.test.ts'
import { CompressedStringOpener, StringOpener } from './openers.test.ts'

Deno.test('TSV loading', async (t) => {
  await t.step('Empty file produces empty map', async () => {
    const file = pathToFile('/empty.tsv')
    file.opener = new StringOpener('')

    const map = await loadTSV(file)
    // map.size looks for a column called map, so work around it
    assertEquals(Object.keys(map).length, 0)
  })

  await t.step('Single row file produces header-only map', async () => {
    const file = pathToFile('/single_row.tsv')
    file.opener = new StringOpener('a\tb\tc\n')

    const map = await loadTSV(file)
    assertEquals(map.a, [])
    assertEquals(map.b, [])
    assertEquals(map.c, [])
  })

  await t.step('Single column file produces single column map', async () => {
    const file = pathToFile('/single_column.tsv')
    file.opener = new StringOpener('a\n1\n2\n3\n')

    const map = await loadTSV(file)
    assertEquals(map.a, ['1', '2', '3'])
  })

  await t.step('Missing final newline is ignored', async () => {
    const file = pathToFile('/missing_newline.tsv')
    file.opener = new StringOpener('a\n1\n2\n3')

    const map = await loadTSV(file)
    assertEquals(map.a, ['1', '2', '3'])
  })

  await t.step('Empty row throws issue', async () => {
    const file = pathToFile('/empty_row.tsv')
    file.opener = new StringOpener('a\tb\tc\n1\t2\t3\n\n4\t5\t6\n')

    try {
      await loadTSV(file)
    } catch (e: any) {
      assertObjectMatch(e, { code: 'TSV_EMPTY_LINE', line: 3 })
    }
  })

  await t.step('Mismatched row length throws issue', async () => {
    const file = pathToFile('/mismatched_row.tsv')
    file.opener = new StringOpener('a\tb\tc\n1\t2\t3\n4\t5\n')

    try {
      await loadTSV(file)
    } catch (e: any) {
      assertObjectMatch(e, { code: 'TSV_EQUAL_ROWS', line: 3 })
    }
  })

  await t.step('maxRows limits the number of rows read', async () => {
    const file = pathToFile('/long.tsv')
    // Use 1500 to avoid overlap with default initial capacity
    const text = 'a\tb\tc\n' + '1\t2\t3\n'.repeat(1500)
    file.opener = new StringOpener(text)

    let map = await loadTSV(file, 0)
    assertEquals(map.a, [])
    assertEquals(map.b, [])
    assertEquals(map.c, [])

    // Do not assume that caching respects maxRows in this test
    loadTSV.cache.clear()
    map = await loadTSV(file, 1)
    assertEquals(map.a, ['1'])
    assertEquals(map.b, ['2'])
    assertEquals(map.c, ['3'])

    loadTSV.cache.clear()
    map = await loadTSV(file, 2)
    assertEquals(map.a, ['1', '1'])
    assertEquals(map.b, ['2', '2'])
    assertEquals(map.c, ['3', '3'])

    loadTSV.cache.clear()
    map = await loadTSV(file, -1)
    assertEquals(map.a, Array(1500).fill('1'))
    assertEquals(map.b, Array(1500).fill('2'))
    assertEquals(map.c, Array(1500).fill('3'))

    loadTSV.cache.clear()
    // Check that maxRows does not truncate shorter files
    file.opener = new StringOpener('a\tb\tc\n1\t2\t3\n4\t5\t6\n7\t8\t9\n')
    map = await loadTSV(file, 4)
    assertEquals(map.a, ['1', '4', '7'])
    assertEquals(map.b, ['2', '5', '8'])
    assertEquals(map.c, ['3', '6', '9'])
  })

  await t.step('caching avoids multiple reads', async () => {
    loadTSV.cache.clear()
    const file = pathToFile('/long.tsv')
    // Use 1500 to avoid overlap with default initial capacity
    const text = 'a\tb\tc\n' + '1\t2\t3\n'.repeat(1500)
    file.opener = new StringOpener(text)

    let map = await loadTSV(file, 2)
    assertEquals(map.a, ['1', '1'])
    assertEquals(map.b, ['2', '2'])
    assertEquals(map.c, ['3', '3'])

    // Replace stream to ensure cache does not depend on deep object equality
    let repeatMap = await loadTSV(file, 2)
    assertStrictEquals(map, repeatMap)

    loadTSV.cache.clear()
    // DO NOT replace stream so the next read verifies the previous stream wasn't read
    repeatMap = await loadTSV(file, 2)
    assertEquals(repeatMap.a, ['1', '1'])
    assertEquals(repeatMap.b, ['2', '2'])
    assertEquals(repeatMap.c, ['3', '3'])
    // Same contents, different objects
    assertNotStrictEquals(map, repeatMap)
  })

  await t.step('caching is keyed on maxRows', async () => {
    const file = pathToFile('/long.tsv')
    // Use 1500 to avoid overlap with default initial capacity
    const text = 'a\tb\tc\n' + '1\t2\t3\n'.repeat(1500)
    file.opener = new StringOpener(text)

    let map = await loadTSV(file, 2)
    assertEquals(map.a, ['1', '1'])
    assertEquals(map.b, ['2', '2'])
    assertEquals(map.c, ['3', '3'])

    let repeatMap = await loadTSV(file, 3)
    assertNotStrictEquals(map, repeatMap)
    assertEquals(repeatMap.a, ['1', '1', '1'])
    assertEquals(repeatMap.b, ['2', '2', '2'])
    assertEquals(repeatMap.c, ['3', '3', '3'])

    repeatMap = await loadTSV(file, 2)
    assertStrictEquals(map, repeatMap)
    assertEquals(repeatMap.a, ['1', '1'])
    assertEquals(repeatMap.b, ['2', '2'])
    assertEquals(repeatMap.c, ['3', '3'])
  })

  await t.step('Raises issue on duplicate header', async () => {
    const file = pathToFile('/duplicate_header.tsv')
    file.opener = new StringOpener('a\ta\n1\t2\n')

    try {
      await loadTSV(file)
      assert(false, 'Expected error')
    } catch (e: any) {
      assertObjectMatch(e, { code: 'TSV_COLUMN_HEADER_DUPLICATE', issueMessage: 'a, a' })
    }
  })

  await t.step('Raises issue on non utf-8', async () => {
    const file = new BIDSFileDeno('', './tests/data/iso8859.tsv')

    try {
      await loadTSV(file)
      assert(false, 'Expected error')
    } catch (e: any) {
      assertObjectMatch(e, { code: 'INVALID_FILE_ENCODING' })
    }
  })

  // Tests will have populated the memoization cache
  loadTSV.cache.clear()
})

Deno.test('TSVGZ loading', async (t) => {
  await t.step('No header and empty file produces empty map', async () => {
    const file = pathToFile('/empty.tsv.gz')
    file.opener = new CompressedStringOpener('')

    const map = await loadTSVGZ(file, [])
    // map.size looks for a column called map, so work around it
    assertEquals(Object.keys(map).length, 0)
  })

  await t.step('Empty file produces header-only map', async () => {
    const file = pathToFile('/empty.tsv.gz')
    file.opener = new CompressedStringOpener('')

    const map = await loadTSVGZ(file, ['a', 'b', 'c'])
    assertEquals(map.a, [])
    assertEquals(map.b, [])
    assertEquals(map.c, [])
  })

  await t.step('Single column file produces single column maps', async () => {
    const file = pathToFile('/single_column.tsv')
    file.opener = new CompressedStringOpener('1\n2\n3\n')

    const map = await loadTSVGZ(file, ['a'])
    assertEquals(map.a, ['1', '2', '3'])
  })

  await t.step('Mismatched header length throws issue', async () => {
    const file = pathToFile('/single_column.tsv.gz')
    file.opener = new CompressedStringOpener('1\n2\n3\n')

    try {
      await loadTSVGZ(file, ['a', 'b'])
    } catch (e: any) {
      assertObjectMatch(e, { code: 'TSV_EQUAL_ROWS', line: 1 })
    }
  })

  await t.step('Missing final newline is ignored', async () => {
    const file = pathToFile('/missing_newline.tsv.gz')
    file.opener = new CompressedStringOpener('1\n2\n3')

    const map = await loadTSVGZ(file, ['a'])
    assertEquals(map.a, ['1', '2', '3'])
  })

  await t.step('Empty row throws issue', async () => {
    const file = pathToFile('/empty_row.tsv.gz')
    file.opener = new CompressedStringOpener('1\t2\t3\n\n4\t5\t6\n')

    try {
      await loadTSVGZ(file, ['a', 'b', 'c'])
    } catch (e: any) {
      assertObjectMatch(e, { code: 'TSV_EMPTY_LINE', line: 2 })
    }
  })

  await t.step('Mislabeled TSV throws issue', async () => {
    const file = pathToFile('/mismatched_row.tsv.gz')
    file.opener = new StringOpener('a\tb\tc\n1\t2\t3\n4\t5\n')

    try {
      await loadTSVGZ(file, ['a', 'b', 'c'])
    } catch (e: any) {
      assertObjectMatch(e, { code: 'INVALID_GZIP' })
    }
  })

  await t.step('maxRows limits the number of rows read', async () => {
    const file = pathToFile('/long.tsv.gz')
    // Use 1500 to avoid overlap with default initial capacity
    const headers = ['a', 'b', 'c']
    const text = '1\t2\t3\n'.repeat(1500)
    file.opener = new CompressedStringOpener(text)

    let map = await loadTSVGZ(file, headers, 0)
    assertEquals(map.a, [])
    assertEquals(map.b, [])
    assertEquals(map.c, [])

    map = await loadTSVGZ(file, headers, 1)
    assertEquals(map.a, ['1'])
    assertEquals(map.b, ['2'])
    assertEquals(map.c, ['3'])

    map = await loadTSVGZ(file, headers, 2)
    assertEquals(map.a, ['1', '1'])
    assertEquals(map.b, ['2', '2'])
    assertEquals(map.c, ['3', '3'])

    map = await loadTSVGZ(file, headers, -1)
    assertEquals(map.a, Array(1500).fill('1'))
    assertEquals(map.b, Array(1500).fill('2'))
    assertEquals(map.c, Array(1500).fill('3'))

    // Check that maxRows does not truncate shorter files
    file.opener = new CompressedStringOpener('1\t2\t3\n4\t5\t6\n7\t8\t9\n')
    map = await loadTSVGZ(file, headers, 4)
    assertEquals(map.a, ['1', '4', '7'])
    assertEquals(map.b, ['2', '5', '8'])
    assertEquals(map.c, ['3', '6', '9'])
  })
})

testAsyncFileAccess('Test file access errors for loadTSV', loadTSV)
