from importlib.metadata import version
version: str = version('bigeye-sdk')
