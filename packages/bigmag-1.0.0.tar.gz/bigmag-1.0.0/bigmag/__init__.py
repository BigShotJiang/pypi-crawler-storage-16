"""BIgMAG - Board InteGrating Metagenome-Assembled Genomes"""

__version__ = "1.0.0"
__author__ = "Jeferyd Yepes García, Laurent Falquet"
__email__ = "jeferyd.yepes@unibe.ch"

__all__ = ["__version__", "__author__", "__email__"]
