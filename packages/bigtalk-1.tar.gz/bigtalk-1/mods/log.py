# This file is placed in the Public Domain.


import time


from bigtalk.locater import Locater
from bigtalk.objects import Object
from bigtalk.persist import Disk
from bigtalk.utility import Utils


class Log(Object):

    def __init__(self):
        super().__init__()
        self.txt = ''


def log(event):
    if not event.rest:
        nmr = 0
        for fnm, obj in Locater.find('log', event.gets):
            lap = Utils.elapsed(time.time() - Locater.fntime(fnm))
            event.reply(f'{nmr} {obj.txt} {lap}')
            nmr += 1
        if not nmr:
            event.reply('no log')
        return
    obj = Log()
    obj.txt = event.rest
    Disk.write(obj)
    event.reply("ok")
