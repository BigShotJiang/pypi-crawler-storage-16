```{include} ../../README.md
:start-after: </p>
```

## Contents

```{toctree}
:maxdepth: 2

intro/concepts
intro/basic
intro/coupling
intro/continuous
intro/flowjax
intro/fourier
intro/lie
intro/cg

tutorials
api
```
