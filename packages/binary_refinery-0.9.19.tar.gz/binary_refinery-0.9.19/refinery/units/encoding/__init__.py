"""
Encoding and decoding of various formats.
"""
