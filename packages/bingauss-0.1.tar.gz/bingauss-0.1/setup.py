from setuptools import setup

setup(name="bingauss",
 version="0.1",
 description="Gaussian and Binomial distributions, Single Inheritance",
 packages=['bingauss'],
 author='Kevin Howard',
 author_email='howardkc@alumni.purdue.edu',
 zip_safe=False)