# Dependencies

from pybinwalk.dependencies.manager import Manager
