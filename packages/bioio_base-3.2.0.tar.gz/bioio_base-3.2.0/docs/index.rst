Welcome to bioio-base's documentation!
======================================

.. toctree::
   :hidden:
   :maxdepth: 1
   :caption: Contents:

   Overview <self>
   installation
   Package modules <modules>
   contributing

.. mdinclude:: ../README.md
