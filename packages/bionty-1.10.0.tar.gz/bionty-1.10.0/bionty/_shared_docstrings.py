doc_from_source = """\
    source: Optional Source record to use
            mute: Whether to suppress logging
"""
