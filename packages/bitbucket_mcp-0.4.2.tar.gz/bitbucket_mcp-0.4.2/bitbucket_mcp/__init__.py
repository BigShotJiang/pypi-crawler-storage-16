"""Bitbucket MCP Server - Manage Pull Requests on Bitbucket Cloud."""

from .server import main

__all__ = ["main"]
