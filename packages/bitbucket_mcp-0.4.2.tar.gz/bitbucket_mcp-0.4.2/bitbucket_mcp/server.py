#!/usr/bin/env python3
"""
Bitbucket MCP Server - Manage Pull Requests on Bitbucket Cloud

Tools:
Configuration:
- setup_bitbucket: Configure Bitbucket credentials
- get_config_status: Check configuration status

Workspace & Repository:
- list_workspace_members: List workspace members (for finding reviewers)
- list_repositories: List repositories in a workspace
- get_repository: Get detailed repository information
- list_branches: List branches in a repository
- get_default_reviewers: Get default reviewers for a repository

Pull Requests:
- create_pull_request: Create a new PR (with default reviewers support)
- list_pull_requests: List PRs for a repository
- get_pull_request: View details of a specific PR
- update_pull_request: Edit an existing PR (including reviewers)
- merge_pull_request: Merge a PR (supports merge commit, squash, fast-forward)
- decline_pull_request: Decline/close a PR without merging

Reviews:
- approve_pull_request: Approve a PR
- unapprove_pull_request: Remove approval from a PR
- request_changes_pull_request: Request changes on a PR
- add_reviewer: Add a reviewer to a PR
- remove_reviewer: Remove a reviewer from a PR

Comments:
- add_pull_request_comment: Add a comment to a PR
- get_pull_request_comments: Get comments from a PR
- reply_to_comment: Reply to a specific comment
- add_inline_comment: Add an inline comment on a specific line of code
- delete_comment: Delete a comment

Code Review:
- get_pull_request_diffstat: Get summary of files changed in a PR
- get_pull_request_diff: Get the code diff for a PR (full or per-file)
- get_file_contents: Get file contents from a branch/commit
- get_pull_request_commits: List commits in a PR
- get_pull_request_activity: Get PR activity/timeline
- get_pull_request_merge_status: Check if PR can be merged
"""

import json
import os
import stat
from pathlib import Path
from typing import Optional

import httpx
from fastmcp import FastMCP

# Initialize FastMCP server
mcp = FastMCP("bitbucket")

# Config file location
CONFIG_DIR = Path.home() / ".bitbucket-mcp"
CONFIG_FILE = CONFIG_DIR / "config.json"

# Bitbucket API base URL
BITBUCKET_API = "https://api.bitbucket.org/2.0"


def load_config() -> dict:
    """Load configuration from file."""
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, "r") as f:
            return json.load(f)
    return {}


def save_config(config: dict) -> None:
    """Save configuration to file with secure permissions."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)

    # Set file permissions to 600 (owner read/write only)
    os.chmod(CONFIG_FILE, stat.S_IRUSR | stat.S_IWUSR)


def get_auth(token: Optional[str] = None, username: Optional[str] = None) -> httpx.BasicAuth:
    """Get Basic Auth for Bitbucket API (Atlassian API Token)."""
    config = load_config()
    auth_token = token or config.get("token") or os.environ.get("BITBUCKET_API_TOKEN")
    auth_user = username or config.get("username") or os.environ.get("BITBUCKET_USERNAME")

    if not auth_token or not auth_user:
        raise ValueError("No Bitbucket credentials configured. Please run setup_bitbucket first.")

    return httpx.BasicAuth(auth_user, auth_token)


def get_workspace(workspace: Optional[str] = None) -> str:
    """Get workspace from parameter, config, or environment."""
    config = load_config()
    ws = workspace or config.get("workspace") or os.environ.get("BITBUCKET_WORKSPACE")

    if not ws:
        raise ValueError("No workspace specified. Please provide workspace parameter or run setup_bitbucket.")

    return ws


@mcp.tool()
def setup_bitbucket(workspace: str, username: str, api_token: str) -> str:
    """
    Configure Bitbucket credentials for the MCP server.

    Args:
        workspace: Bitbucket workspace slug (e.g., "myworkspace")
        username: Your Atlassian account email (e.g., "user@example.com")
        api_token: Atlassian API Token from https://id.atlassian.com/manage-profile/security/api-tokens

    Returns:
        Success or error message
    """
    try:
        # Validate credentials by making a test API call with Basic Auth
        auth = httpx.BasicAuth(username, api_token)

        with httpx.Client() as client:
            # First try to get user info to validate token
            user_response = client.get(
                f"{BITBUCKET_API}/user",
                auth=auth,
                timeout=30.0
            )

            if user_response.status_code == 401:
                return "Error: Invalid credentials. Please check your email and API token."

            # Then validate workspace access
            ws_response = client.get(
                f"{BITBUCKET_API}/workspaces/{workspace}",
                auth=auth,
                timeout=30.0
            )

        if ws_response.status_code == 404:
            return f"Error: Workspace '{workspace}' not found or you don't have access to it."
        elif ws_response.status_code == 403:
            return f"Error: No permission to access workspace '{workspace}'."
        elif ws_response.status_code != 200:
            return f"Error: Failed to validate workspace. Status: {ws_response.status_code} - {ws_response.text}"

        # Save configuration
        config = {
            "workspace": workspace,
            "username": username,
            "token": api_token
        }
        save_config(config)

        return f"Successfully configured Bitbucket for workspace '{workspace}'. Configuration saved to {CONFIG_FILE}"

    except httpx.RequestError as e:
        return f"Error: Failed to connect to Bitbucket API: {str(e)}"
    except Exception as e:
        return f"Error: {str(e)}"


@mcp.tool()
def get_config_status() -> dict:
    """
    Check if Bitbucket is configured and return current status.

    Returns:
        Configuration status with workspace info
    """
    config = load_config()
    env_token = os.environ.get("BITBUCKET_API_TOKEN")
    env_workspace = os.environ.get("BITBUCKET_WORKSPACE")
    env_username = os.environ.get("BITBUCKET_USERNAME")

    has_token = bool(config.get("token") or env_token)
    has_username = bool(config.get("username") or env_username)
    configured = has_token and has_username
    workspace = config.get("workspace") or env_workspace
    username = config.get("username") or env_username

    return {
        "configured": configured,
        "workspace": workspace,
        "username": username,
        "config_file": str(CONFIG_FILE),
        "source": "config_file" if config.get("token") else ("environment" if env_token else None)
    }


@mcp.tool()
def list_workspace_members(
    workspace: Optional[str] = None,
    page: int = 1,
    pagelen: int = 50
) -> dict:
    """
    List members of a Bitbucket workspace. Use this to find users who can be added as reviewers.

    Args:
        workspace: Bitbucket workspace (optional if configured)
        page: Page number for pagination (default: 1)
        pagelen: Number of results per page, max 100 (default: 50)

    Returns:
        List of workspace members with their UUIDs and display names
    """
    try:
        ws = get_workspace(workspace)
        auth = get_auth()

        params = {
            "page": page,
            "pagelen": min(pagelen, 100)
        }

        with httpx.Client() as client:
            response = client.get(
                f"{BITBUCKET_API}/workspaces/{ws}/members",
                auth=auth,
                params=params,
                timeout=30.0
            )

        if response.status_code == 200:
            data = response.json()
            members = []
            for member in data.get("values", []):
                user = member.get("user", {})
                members.append({
                    "uuid": user.get("uuid"),
                    "account_id": user.get("account_id"),
                    "display_name": user.get("display_name"),
                    "nickname": user.get("nickname")
                })
            return {
                "success": True,
                "members": members,
                "total": data.get("size", len(members)),
                "page": data.get("page", page),
                "pagelen": data.get("pagelen", pagelen)
            }
        elif response.status_code == 401:
            return {"success": False, "error": "Authentication failed. Please reconfigure with setup_bitbucket."}
        elif response.status_code == 404:
            return {"success": False, "error": f"Workspace '{ws}' not found."}
        else:
            return {"success": False, "error": f"API error: {response.status_code} - {response.text}"}

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except httpx.RequestError as e:
        return {"success": False, "error": f"Connection error: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


@mcp.tool()
def get_default_reviewers(
    repo_slug: str,
    workspace: Optional[str] = None
) -> dict:
    """
    Get the default reviewers configured for a repository.

    Args:
        repo_slug: Repository slug (name)
        workspace: Bitbucket workspace (optional if configured)

    Returns:
        List of default reviewers with their UUIDs and display names
    """
    try:
        ws = get_workspace(workspace)
        auth = get_auth()

        with httpx.Client() as client:
            response = client.get(
                f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/default-reviewers",
                auth=auth,
                timeout=30.0
            )

        if response.status_code == 200:
            data = response.json()
            reviewers = []
            for reviewer in data.get("values", []):
                reviewers.append({
                    "uuid": reviewer.get("uuid"),
                    "account_id": reviewer.get("account_id"),
                    "display_name": reviewer.get("display_name"),
                    "nickname": reviewer.get("nickname")
                })
            return {
                "success": True,
                "default_reviewers": reviewers,
                "count": len(reviewers)
            }
        elif response.status_code == 401:
            return {"success": False, "error": "Authentication failed. Please reconfigure with setup_bitbucket."}
        elif response.status_code == 404:
            return {"success": False, "error": f"Repository '{ws}/{repo_slug}' not found."}
        else:
            return {"success": False, "error": f"API error: {response.status_code} - {response.text}"}

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except httpx.RequestError as e:
        return {"success": False, "error": f"Connection error: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


@mcp.tool()
def create_pull_request(
    repo_slug: str,
    title: str,
    source_branch: str,
    destination_branch: str = "main",
    description: str = "",
    reviewers: Optional[list[str]] = None,
    use_default_reviewers: bool = True,
    workspace: Optional[str] = None
) -> dict:
    """
    Create a Pull Request on Bitbucket Cloud.

    Args:
        repo_slug: Repository slug (name)
        title: PR title
        source_branch: Branch to merge from
        destination_branch: Branch to merge into (default: main)
        description: PR description (optional)
        reviewers: List of reviewer UUIDs or account_ids (optional).
                   These are added in addition to default reviewers.
        use_default_reviewers: Whether to include default reviewers (default: True)
        workspace: Bitbucket workspace (optional if configured)

    Returns:
        PR details including URL and ID, or error message
    """
    try:
        ws = get_workspace(workspace)
        auth = get_auth()

        payload = {
            "title": title,
            "source": {
                "branch": {
                    "name": source_branch
                }
            },
            "destination": {
                "branch": {
                    "name": destination_branch
                }
            }
        }

        if description:
            payload["description"] = description

        # Collect reviewers
        reviewer_list = []

        # Add default reviewers if requested
        if use_default_reviewers:
            with httpx.Client() as client:
                default_response = client.get(
                    f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/default-reviewers",
                    auth=auth,
                    timeout=30.0
                )
            if default_response.status_code == 200:
                default_data = default_response.json()
                for reviewer in default_data.get("values", []):
                    reviewer_list.append({"uuid": reviewer.get("uuid")})

        # Add explicitly specified reviewers
        if reviewers:
            for r in reviewers:
                if r.startswith("{"):
                    reviewer_list.append({"uuid": r})
                else:
                    reviewer_list.append({"account_id": r})

        # Remove duplicates by uuid
        seen_uuids = set()
        unique_reviewers = []
        for r in reviewer_list:
            uuid = r.get("uuid") or r.get("account_id")
            if uuid and uuid not in seen_uuids:
                seen_uuids.add(uuid)
                unique_reviewers.append(r)

        if unique_reviewers:
            payload["reviewers"] = unique_reviewers

        with httpx.Client() as client:
            response = client.post(
                f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/pullrequests",
                auth=auth,
                json=payload,
                timeout=30.0
            )

        if response.status_code == 201:
            data = response.json()
            pr_reviewers = [
                {"display_name": r.get("display_name"), "uuid": r.get("uuid")}
                for r in data.get("reviewers", [])
            ]
            return {
                "success": True,
                "id": data.get("id"),
                "title": data.get("title"),
                "url": data.get("links", {}).get("html", {}).get("href"),
                "state": data.get("state"),
                "source_branch": source_branch,
                "destination_branch": destination_branch,
                "reviewers": pr_reviewers
            }
        elif response.status_code == 400:
            error_data = response.json()
            error_msg = error_data.get("error", {}).get("message", "Bad request")
            return {"success": False, "error": error_msg}
        elif response.status_code == 401:
            return {"success": False, "error": "Authentication failed. Please reconfigure with setup_bitbucket."}
        elif response.status_code == 404:
            return {"success": False, "error": f"Repository '{ws}/{repo_slug}' not found."}
        else:
            return {"success": False, "error": f"API error: {response.status_code} - {response.text}"}

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except httpx.RequestError as e:
        return {"success": False, "error": f"Connection error: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


@mcp.tool()
def list_pull_requests(
    repo_slug: str,
    state: str = "OPEN",
    workspace: Optional[str] = None,
    page: int = 1,
    pagelen: int = 25
) -> dict:
    """
    List Pull Requests for a repository on Bitbucket Cloud.

    Args:
        repo_slug: Repository slug (name)
        state: PR state filter - OPEN, MERGED, DECLINED, SUPERSEDED, or ALL (default: OPEN)
        workspace: Bitbucket workspace (optional if configured)
        page: Page number for pagination (default: 1)
        pagelen: Number of results per page, max 50 (default: 25)

    Returns:
        List of PRs with their details
    """
    try:
        ws = get_workspace(workspace)
        auth = get_auth()

        params = {
            "page": page,
            "pagelen": min(pagelen, 50)
        }

        if state.upper() != "ALL":
            params["state"] = state.upper()

        with httpx.Client() as client:
            response = client.get(
                f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/pullrequests",
                auth=auth,
                params=params,
                timeout=30.0
            )

        if response.status_code == 200:
            data = response.json()
            prs = []
            for pr in data.get("values", []):
                prs.append({
                    "id": pr.get("id"),
                    "title": pr.get("title"),
                    "state": pr.get("state"),
                    "author": pr.get("author", {}).get("display_name"),
                    "source_branch": pr.get("source", {}).get("branch", {}).get("name"),
                    "destination_branch": pr.get("destination", {}).get("branch", {}).get("name"),
                    "url": pr.get("links", {}).get("html", {}).get("href"),
                    "created_on": pr.get("created_on"),
                    "updated_on": pr.get("updated_on")
                })
            return {
                "success": True,
                "pull_requests": prs,
                "total": data.get("size", len(prs)),
                "page": data.get("page", page),
                "pagelen": data.get("pagelen", pagelen)
            }
        elif response.status_code == 401:
            return {"success": False, "error": "Authentication failed. Please reconfigure with setup_bitbucket."}
        elif response.status_code == 404:
            return {"success": False, "error": f"Repository '{ws}/{repo_slug}' not found."}
        else:
            return {"success": False, "error": f"API error: {response.status_code} - {response.text}"}

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except httpx.RequestError as e:
        return {"success": False, "error": f"Connection error: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


@mcp.tool()
def get_pull_request(
    repo_slug: str,
    pr_id: int,
    workspace: Optional[str] = None
) -> dict:
    """
    Get details of a specific Pull Request on Bitbucket Cloud.

    Args:
        repo_slug: Repository slug (name)
        pr_id: Pull Request ID
        workspace: Bitbucket workspace (optional if configured)

    Returns:
        Detailed PR information including description, reviewers, and comments count
    """
    try:
        ws = get_workspace(workspace)
        auth = get_auth()

        with httpx.Client() as client:
            response = client.get(
                f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/pullrequests/{pr_id}",
                auth=auth,
                timeout=30.0
            )

        if response.status_code == 200:
            pr = response.json()
            reviewers = []
            for reviewer in pr.get("reviewers", []):
                reviewers.append({
                    "display_name": reviewer.get("display_name"),
                    "uuid": reviewer.get("uuid"),
                    "approved": reviewer.get("approved", False)
                })

            participants = []
            for participant in pr.get("participants", []):
                participants.append({
                    "display_name": participant.get("user", {}).get("display_name"),
                    "role": participant.get("role"),
                    "approved": participant.get("approved", False),
                    "state": participant.get("state")
                })

            return {
                "success": True,
                "id": pr.get("id"),
                "title": pr.get("title"),
                "description": pr.get("description", ""),
                "state": pr.get("state"),
                "author": pr.get("author", {}).get("display_name"),
                "source_branch": pr.get("source", {}).get("branch", {}).get("name"),
                "destination_branch": pr.get("destination", {}).get("branch", {}).get("name"),
                "url": pr.get("links", {}).get("html", {}).get("href"),
                "created_on": pr.get("created_on"),
                "updated_on": pr.get("updated_on"),
                "close_source_branch": pr.get("close_source_branch", False),
                "comment_count": pr.get("comment_count", 0),
                "task_count": pr.get("task_count", 0),
                "reviewers": reviewers,
                "participants": participants,
                "merge_commit": pr.get("merge_commit", {}).get("hash") if pr.get("merge_commit") else None
            }
        elif response.status_code == 401:
            return {"success": False, "error": "Authentication failed. Please reconfigure with setup_bitbucket."}
        elif response.status_code == 404:
            return {"success": False, "error": f"Pull request #{pr_id} not found in '{ws}/{repo_slug}'."}
        else:
            return {"success": False, "error": f"API error: {response.status_code} - {response.text}"}

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except httpx.RequestError as e:
        return {"success": False, "error": f"Connection error: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


@mcp.tool()
def update_pull_request(
    repo_slug: str,
    pr_id: int,
    title: Optional[str] = None,
    description: Optional[str] = None,
    destination_branch: Optional[str] = None,
    reviewers: Optional[list[str]] = None,
    close_source_branch: Optional[bool] = None,
    workspace: Optional[str] = None
) -> dict:
    """
    Update/edit an existing Pull Request on Bitbucket Cloud.

    Args:
        repo_slug: Repository slug (name)
        pr_id: Pull Request ID to update
        title: New PR title (optional)
        description: New PR description (optional)
        destination_branch: New destination branch (optional)
        reviewers: List of reviewer UUIDs or account_ids to set as reviewers (optional).
                   Pass empty list [] to remove all reviewers.
        close_source_branch: Whether to close source branch on merge (optional)
        workspace: Bitbucket workspace (optional if configured)

    Returns:
        Updated PR details or error message
    """
    try:
        ws = get_workspace(workspace)
        auth = get_auth()

        # Build payload with only provided fields
        payload = {}
        if title is not None:
            payload["title"] = title
        if description is not None:
            payload["description"] = description
        if destination_branch is not None:
            payload["destination"] = {"branch": {"name": destination_branch}}
        if reviewers is not None:
            payload["reviewers"] = [{"uuid": r} if r.startswith("{") else {"account_id": r} for r in reviewers]
        if close_source_branch is not None:
            payload["close_source_branch"] = close_source_branch

        if not payload:
            return {"success": False, "error": "No update fields provided. Specify at least one of: title, description, destination_branch, reviewers, close_source_branch"}

        with httpx.Client() as client:
            response = client.put(
                f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/pullrequests/{pr_id}",
                auth=auth,
                json=payload,
                timeout=30.0
            )

        if response.status_code == 200:
            pr = response.json()
            reviewer_list = [
                {"display_name": r.get("display_name"), "uuid": r.get("uuid")}
                for r in pr.get("reviewers", [])
            ]
            return {
                "success": True,
                "id": pr.get("id"),
                "title": pr.get("title"),
                "description": pr.get("description", ""),
                "state": pr.get("state"),
                "source_branch": pr.get("source", {}).get("branch", {}).get("name"),
                "destination_branch": pr.get("destination", {}).get("branch", {}).get("name"),
                "url": pr.get("links", {}).get("html", {}).get("href"),
                "close_source_branch": pr.get("close_source_branch", False),
                "reviewers": reviewer_list,
                "updated_on": pr.get("updated_on")
            }
        elif response.status_code == 400:
            error_data = response.json()
            error_msg = error_data.get("error", {}).get("message", "Bad request")
            return {"success": False, "error": error_msg}
        elif response.status_code == 401:
            return {"success": False, "error": "Authentication failed. Please reconfigure with setup_bitbucket."}
        elif response.status_code == 404:
            return {"success": False, "error": f"Pull request #{pr_id} not found in '{ws}/{repo_slug}'."}
        elif response.status_code == 403:
            return {"success": False, "error": "Permission denied. You may not have write access to this PR."}
        else:
            return {"success": False, "error": f"API error: {response.status_code} - {response.text}"}

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except httpx.RequestError as e:
        return {"success": False, "error": f"Connection error: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


@mcp.tool()
def approve_pull_request(
    repo_slug: str,
    pr_id: int,
    workspace: Optional[str] = None
) -> dict:
    """
    Approve a Pull Request on Bitbucket Cloud.

    Args:
        repo_slug: Repository slug (name)
        pr_id: Pull Request ID to approve
        workspace: Bitbucket workspace (optional if configured)

    Returns:
        Approval confirmation or error message
    """
    try:
        ws = get_workspace(workspace)
        auth = get_auth()

        with httpx.Client() as client:
            response = client.post(
                f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/pullrequests/{pr_id}/approve",
                auth=auth,
                timeout=30.0
            )

        if response.status_code in (200, 201):
            data = response.json()
            return {
                "success": True,
                "message": f"Pull request #{pr_id} approved successfully",
                "approved": data.get("approved", True),
                "user": data.get("user", {}).get("display_name")
            }
        elif response.status_code == 401:
            return {"success": False, "error": "Authentication failed. Please reconfigure with setup_bitbucket."}
        elif response.status_code == 404:
            return {"success": False, "error": f"Pull request #{pr_id} not found in '{ws}/{repo_slug}'."}
        elif response.status_code == 409:
            return {"success": False, "error": "You have already approved this pull request."}
        else:
            return {"success": False, "error": f"API error: {response.status_code} - {response.text}"}

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except httpx.RequestError as e:
        return {"success": False, "error": f"Connection error: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


@mcp.tool()
def unapprove_pull_request(
    repo_slug: str,
    pr_id: int,
    workspace: Optional[str] = None
) -> dict:
    """
    Remove approval from a Pull Request on Bitbucket Cloud.

    Args:
        repo_slug: Repository slug (name)
        pr_id: Pull Request ID to unapprove
        workspace: Bitbucket workspace (optional if configured)

    Returns:
        Confirmation or error message
    """
    try:
        ws = get_workspace(workspace)
        auth = get_auth()

        with httpx.Client() as client:
            response = client.delete(
                f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/pullrequests/{pr_id}/approve",
                auth=auth,
                timeout=30.0
            )

        if response.status_code in (200, 204):
            return {
                "success": True,
                "message": f"Approval removed from pull request #{pr_id}"
            }
        elif response.status_code == 401:
            return {"success": False, "error": "Authentication failed. Please reconfigure with setup_bitbucket."}
        elif response.status_code == 404:
            return {"success": False, "error": f"Pull request #{pr_id} not found or not previously approved."}
        else:
            return {"success": False, "error": f"API error: {response.status_code} - {response.text}"}

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except httpx.RequestError as e:
        return {"success": False, "error": f"Connection error: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


@mcp.tool()
def request_changes_pull_request(
    repo_slug: str,
    pr_id: int,
    workspace: Optional[str] = None
) -> dict:
    """
    Request changes on a Pull Request on Bitbucket Cloud.

    Args:
        repo_slug: Repository slug (name)
        pr_id: Pull Request ID
        workspace: Bitbucket workspace (optional if configured)

    Returns:
        Confirmation or error message
    """
    try:
        ws = get_workspace(workspace)
        auth = get_auth()

        with httpx.Client() as client:
            response = client.post(
                f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/pullrequests/{pr_id}/request-changes",
                auth=auth,
                timeout=30.0
            )

        if response.status_code in (200, 201):
            data = response.json()
            return {
                "success": True,
                "message": f"Changes requested on pull request #{pr_id}",
                "user": data.get("user", {}).get("display_name")
            }
        elif response.status_code == 401:
            return {"success": False, "error": "Authentication failed. Please reconfigure with setup_bitbucket."}
        elif response.status_code == 404:
            return {"success": False, "error": f"Pull request #{pr_id} not found in '{ws}/{repo_slug}'."}
        elif response.status_code == 409:
            return {"success": False, "error": "You have already requested changes on this pull request."}
        else:
            return {"success": False, "error": f"API error: {response.status_code} - {response.text}"}

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except httpx.RequestError as e:
        return {"success": False, "error": f"Connection error: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


@mcp.tool()
def add_pull_request_comment(
    repo_slug: str,
    pr_id: int,
    comment: str,
    workspace: Optional[str] = None
) -> dict:
    """
    Add a comment to a Pull Request on Bitbucket Cloud.

    Args:
        repo_slug: Repository slug (name)
        pr_id: Pull Request ID
        comment: Comment text (supports markdown)
        workspace: Bitbucket workspace (optional if configured)

    Returns:
        Comment details or error message
    """
    try:
        ws = get_workspace(workspace)
        auth = get_auth()

        payload = {
            "content": {
                "raw": comment
            }
        }

        with httpx.Client() as client:
            response = client.post(
                f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/pullrequests/{pr_id}/comments",
                auth=auth,
                json=payload,
                timeout=30.0
            )

        if response.status_code in (200, 201):
            data = response.json()
            return {
                "success": True,
                "id": data.get("id"),
                "message": f"Comment added to pull request #{pr_id}",
                "content": data.get("content", {}).get("raw"),
                "user": data.get("user", {}).get("display_name"),
                "created_on": data.get("created_on")
            }
        elif response.status_code == 401:
            return {"success": False, "error": "Authentication failed. Please reconfigure with setup_bitbucket."}
        elif response.status_code == 404:
            return {"success": False, "error": f"Pull request #{pr_id} not found in '{ws}/{repo_slug}'."}
        else:
            return {"success": False, "error": f"API error: {response.status_code} - {response.text}"}

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except httpx.RequestError as e:
        return {"success": False, "error": f"Connection error: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


@mcp.tool()
def get_pull_request_comments(
    repo_slug: str,
    pr_id: int,
    workspace: Optional[str] = None,
    page: int = 1,
    pagelen: int = 50
) -> dict:
    """
    Get comments from a Pull Request on Bitbucket Cloud.

    Args:
        repo_slug: Repository slug (name)
        pr_id: Pull Request ID
        workspace: Bitbucket workspace (optional if configured)
        page: Page number for pagination (default: 1)
        pagelen: Number of results per page, max 100 (default: 50)

    Returns:
        List of comments with their details including content, author, and timestamps
    """
    try:
        ws = get_workspace(workspace)
        auth = get_auth()

        params = {
            "page": page,
            "pagelen": min(pagelen, 100)
        }

        with httpx.Client() as client:
            response = client.get(
                f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/pullrequests/{pr_id}/comments",
                auth=auth,
                params=params,
                timeout=30.0
            )

        if response.status_code == 200:
            data = response.json()
            comments = []
            for comment in data.get("values", []):
                # Handle inline comments (code comments)
                inline = comment.get("inline")
                inline_info = None
                if inline:
                    inline_info = {
                        "path": inline.get("path"),
                        "from_line": inline.get("from"),
                        "to_line": inline.get("to")
                    }

                # Handle parent comment (for replies)
                parent = comment.get("parent")
                parent_id = parent.get("id") if parent else None

                comments.append({
                    "id": comment.get("id"),
                    "content": comment.get("content", {}).get("raw", ""),
                    "content_html": comment.get("content", {}).get("html", ""),
                    "author": comment.get("user", {}).get("display_name"),
                    "author_uuid": comment.get("user", {}).get("uuid"),
                    "created_on": comment.get("created_on"),
                    "updated_on": comment.get("updated_on"),
                    "deleted": comment.get("deleted", False),
                    "inline": inline_info,
                    "parent_id": parent_id
                })

            return {
                "success": True,
                "comments": comments,
                "total": data.get("size", len(comments)),
                "page": data.get("page", page),
                "pagelen": data.get("pagelen", pagelen)
            }
        elif response.status_code == 401:
            return {"success": False, "error": "Authentication failed. Please reconfigure with setup_bitbucket."}
        elif response.status_code == 404:
            return {"success": False, "error": f"Pull request #{pr_id} not found in '{ws}/{repo_slug}'."}
        else:
            return {"success": False, "error": f"API error: {response.status_code} - {response.text}"}

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except httpx.RequestError as e:
        return {"success": False, "error": f"Connection error: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


@mcp.tool()
def get_pull_request_diffstat(
    repo_slug: str,
    pr_id: int,
    workspace: Optional[str] = None
) -> dict:
    """
    Get a summary of files changed in a Pull Request with line counts.

    Args:
        repo_slug: Repository slug (name)
        pr_id: Pull Request ID
        workspace: Bitbucket workspace (optional if configured)

    Returns:
        List of files with lines added/removed counts
    """
    try:
        ws = get_workspace(workspace)
        auth = get_auth()

        files = []
        next_url = f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/pullrequests/{pr_id}/diffstat"

        with httpx.Client(follow_redirects=True) as client:
            while next_url:
                response = client.get(
                    next_url,
                    auth=auth,
                    timeout=30.0
                )

                if response.status_code == 200:
                    data = response.json()
                    for file_stat in data.get("values", []):
                        old_path = file_stat.get("old", {}).get("path") if file_stat.get("old") else None
                        new_path = file_stat.get("new", {}).get("path") if file_stat.get("new") else None

                        files.append({
                            "path": new_path or old_path,
                            "old_path": old_path if old_path != new_path else None,
                            "status": file_stat.get("status"),
                            "lines_added": file_stat.get("lines_added", 0),
                            "lines_removed": file_stat.get("lines_removed", 0)
                        })

                    # Handle pagination
                    next_url = data.get("next")
                elif response.status_code == 401:
                    return {"success": False, "error": "Authentication failed. Please reconfigure with setup_bitbucket."}
                elif response.status_code == 404:
                    return {"success": False, "error": f"Pull request #{pr_id} not found in '{ws}/{repo_slug}'."}
                else:
                    return {"success": False, "error": f"API error: {response.status_code} - {response.text}"}

        total_added = sum(f["lines_added"] for f in files)
        total_removed = sum(f["lines_removed"] for f in files)

        return {
            "success": True,
            "files": files,
            "total_files": len(files),
            "total_lines_added": total_added,
            "total_lines_removed": total_removed
        }

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except httpx.RequestError as e:
        return {"success": False, "error": f"Connection error: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


@mcp.tool()
def get_pull_request_diff(
    repo_slug: str,
    pr_id: int,
    file_path: Optional[str] = None,
    context_lines: int = 3,
    workspace: Optional[str] = None
) -> dict:
    """
    Get the diff (code changes) for a Pull Request.

    Args:
        repo_slug: Repository slug (name)
        pr_id: Pull Request ID
        file_path: Optional specific file path to get diff for (recommended for large PRs)
        context_lines: Number of context lines around changes (default: 3)
        workspace: Bitbucket workspace (optional if configured)

    Returns:
        The diff content as text
    """
    try:
        ws = get_workspace(workspace)
        auth = get_auth()

        # Build URL with optional path filter
        url = f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/pullrequests/{pr_id}/diff"
        if file_path:
            url = f"{url}/{file_path}"

        with httpx.Client(follow_redirects=True) as client:
            response = client.get(
                url,
                auth=auth,
                headers={"Accept": "text/plain"},
                timeout=60.0  # Longer timeout for large diffs
            )

        if response.status_code == 200:
            diff_content = response.text

            # Truncate if too large (> 100KB)
            max_size = 100 * 1024
            truncated = False
            if len(diff_content) > max_size:
                diff_content = diff_content[:max_size]
                truncated = True

            return {
                "success": True,
                "diff": diff_content,
                "file_path": file_path,
                "truncated": truncated,
                "size_bytes": len(response.text)
            }
        elif response.status_code == 401:
            return {"success": False, "error": "Authentication failed. Please reconfigure with setup_bitbucket."}
        elif response.status_code == 404:
            if file_path:
                return {"success": False, "error": f"File '{file_path}' not found in PR #{pr_id}."}
            return {"success": False, "error": f"Pull request #{pr_id} not found in '{ws}/{repo_slug}'."}
        else:
            return {"success": False, "error": f"API error: {response.status_code} - {response.text}"}

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except httpx.RequestError as e:
        return {"success": False, "error": f"Connection error: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


@mcp.tool()
def get_file_contents(
    repo_slug: str,
    file_path: str,
    ref: str = "main",
    workspace: Optional[str] = None
) -> dict:
    """
    Get the contents of a file from a repository at a specific branch/commit.

    Args:
        repo_slug: Repository slug (name)
        file_path: Path to the file in the repository
        ref: Branch name, tag, or commit hash (default: main)
        workspace: Bitbucket workspace (optional if configured)

    Returns:
        File contents as text
    """
    try:
        ws = get_workspace(workspace)
        auth = get_auth()

        with httpx.Client() as client:
            response = client.get(
                f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/src/{ref}/{file_path}",
                auth=auth,
                timeout=30.0
            )

        if response.status_code == 200:
            content = response.text

            # Truncate if too large (> 100KB)
            max_size = 100 * 1024
            truncated = False
            if len(content) > max_size:
                content = content[:max_size]
                truncated = True

            return {
                "success": True,
                "content": content,
                "file_path": file_path,
                "ref": ref,
                "truncated": truncated,
                "size_bytes": len(response.text)
            }
        elif response.status_code == 401:
            return {"success": False, "error": "Authentication failed. Please reconfigure with setup_bitbucket."}
        elif response.status_code == 404:
            return {"success": False, "error": f"File '{file_path}' not found at ref '{ref}' in '{ws}/{repo_slug}'."}
        else:
            return {"success": False, "error": f"API error: {response.status_code} - {response.text}"}

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except httpx.RequestError as e:
        return {"success": False, "error": f"Connection error: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


@mcp.tool()
def merge_pull_request(
    repo_slug: str,
    pr_id: int,
    merge_strategy: str = "merge_commit",
    close_source_branch: bool = False,
    message: Optional[str] = None,
    workspace: Optional[str] = None
) -> dict:
    """
    Merge a Pull Request on Bitbucket Cloud.

    Args:
        repo_slug: Repository slug (name)
        pr_id: Pull Request ID to merge
        merge_strategy: Merge strategy - "merge_commit", "squash", or "fast_forward" (default: merge_commit)
        close_source_branch: Whether to close the source branch after merge (default: False)
        message: Custom merge commit message (optional)
        workspace: Bitbucket workspace (optional if configured)

    Returns:
        Merge result with commit details or error message
    """
    try:
        ws = get_workspace(workspace)
        auth = get_auth()

        # Map strategy names to Bitbucket API values
        strategy_map = {
            "merge_commit": "merge_commit",
            "squash": "squash",
            "fast_forward": "fast_forward"
        }

        if merge_strategy not in strategy_map:
            return {"success": False, "error": f"Invalid merge strategy. Use: merge_commit, squash, or fast_forward"}

        payload = {
            "type": strategy_map[merge_strategy],
            "close_source_branch": close_source_branch
        }

        if message:
            payload["message"] = message

        with httpx.Client() as client:
            response = client.post(
                f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/pullrequests/{pr_id}/merge",
                auth=auth,
                json=payload,
                timeout=60.0
            )

        if response.status_code == 200:
            data = response.json()
            return {
                "success": True,
                "message": f"Pull request #{pr_id} merged successfully",
                "merge_commit": data.get("merge_commit", {}).get("hash"),
                "state": data.get("state"),
                "closed_source_branch": close_source_branch
            }
        elif response.status_code == 401:
            return {"success": False, "error": "Authentication failed. Please reconfigure with setup_bitbucket."}
        elif response.status_code == 404:
            return {"success": False, "error": f"Pull request #{pr_id} not found in '{ws}/{repo_slug}'."}
        elif response.status_code == 409:
            error_data = response.json()
            error_msg = error_data.get("error", {}).get("message", "Merge conflict or PR cannot be merged")
            return {"success": False, "error": error_msg}
        else:
            return {"success": False, "error": f"API error: {response.status_code} - {response.text}"}

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except httpx.RequestError as e:
        return {"success": False, "error": f"Connection error: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


@mcp.tool()
def decline_pull_request(
    repo_slug: str,
    pr_id: int,
    reason: Optional[str] = None,
    workspace: Optional[str] = None
) -> dict:
    """
    Decline/close a Pull Request on Bitbucket Cloud without merging.

    Args:
        repo_slug: Repository slug (name)
        pr_id: Pull Request ID to decline
        reason: Optional reason for declining (will be added as a comment)
        workspace: Bitbucket workspace (optional if configured)

    Returns:
        Confirmation or error message
    """
    try:
        ws = get_workspace(workspace)
        auth = get_auth()

        # If reason provided, add it as a comment first
        if reason:
            comment_payload = {
                "content": {
                    "raw": f"**PR Declined:** {reason}"
                }
            }
            with httpx.Client() as client:
                client.post(
                    f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/pullrequests/{pr_id}/comments",
                    auth=auth,
                    json=comment_payload,
                    timeout=30.0
                )

        with httpx.Client() as client:
            response = client.post(
                f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/pullrequests/{pr_id}/decline",
                auth=auth,
                timeout=30.0
            )

        if response.status_code == 200:
            data = response.json()
            return {
                "success": True,
                "message": f"Pull request #{pr_id} declined",
                "state": data.get("state"),
                "reason": reason
            }
        elif response.status_code == 401:
            return {"success": False, "error": "Authentication failed. Please reconfigure with setup_bitbucket."}
        elif response.status_code == 404:
            return {"success": False, "error": f"Pull request #{pr_id} not found in '{ws}/{repo_slug}'."}
        elif response.status_code == 409:
            return {"success": False, "error": "PR is already merged or declined."}
        else:
            return {"success": False, "error": f"API error: {response.status_code} - {response.text}"}

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except httpx.RequestError as e:
        return {"success": False, "error": f"Connection error: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


@mcp.tool()
def reply_to_comment(
    repo_slug: str,
    pr_id: int,
    comment_id: int,
    content: str,
    workspace: Optional[str] = None
) -> dict:
    """
    Reply to a specific comment on a Pull Request.

    Args:
        repo_slug: Repository slug (name)
        pr_id: Pull Request ID
        comment_id: ID of the comment to reply to
        content: Reply text (supports markdown)
        workspace: Bitbucket workspace (optional if configured)

    Returns:
        Reply details or error message
    """
    try:
        ws = get_workspace(workspace)
        auth = get_auth()

        payload = {
            "content": {
                "raw": content
            },
            "parent": {
                "id": comment_id
            }
        }

        with httpx.Client() as client:
            response = client.post(
                f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/pullrequests/{pr_id}/comments",
                auth=auth,
                json=payload,
                timeout=30.0
            )

        if response.status_code in (200, 201):
            data = response.json()
            return {
                "success": True,
                "id": data.get("id"),
                "message": f"Reply added to comment #{comment_id}",
                "content": data.get("content", {}).get("raw"),
                "user": data.get("user", {}).get("display_name"),
                "created_on": data.get("created_on"),
                "parent_id": comment_id
            }
        elif response.status_code == 401:
            return {"success": False, "error": "Authentication failed. Please reconfigure with setup_bitbucket."}
        elif response.status_code == 404:
            return {"success": False, "error": f"Pull request #{pr_id} or comment #{comment_id} not found."}
        else:
            return {"success": False, "error": f"API error: {response.status_code} - {response.text}"}

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except httpx.RequestError as e:
        return {"success": False, "error": f"Connection error: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


@mcp.tool()
def add_inline_comment(
    repo_slug: str,
    pr_id: int,
    file_path: str,
    line: int,
    content: str,
    workspace: Optional[str] = None
) -> dict:
    """
    Add an inline comment on a specific line of code in a Pull Request.

    Args:
        repo_slug: Repository slug (name)
        pr_id: Pull Request ID
        file_path: Path to the file to comment on
        line: Line number to comment on
        content: Comment text (supports markdown)
        workspace: Bitbucket workspace (optional if configured)

    Returns:
        Comment details or error message
    """
    try:
        ws = get_workspace(workspace)
        auth = get_auth()

        payload = {
            "content": {
                "raw": content
            },
            "inline": {
                "path": file_path,
                "to": line
            }
        }

        with httpx.Client() as client:
            response = client.post(
                f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/pullrequests/{pr_id}/comments",
                auth=auth,
                json=payload,
                timeout=30.0
            )

        if response.status_code in (200, 201):
            data = response.json()
            return {
                "success": True,
                "id": data.get("id"),
                "message": f"Inline comment added to {file_path}:{line}",
                "content": data.get("content", {}).get("raw"),
                "user": data.get("user", {}).get("display_name"),
                "created_on": data.get("created_on"),
                "file_path": file_path,
                "line": line
            }
        elif response.status_code == 401:
            return {"success": False, "error": "Authentication failed. Please reconfigure with setup_bitbucket."}
        elif response.status_code == 404:
            return {"success": False, "error": f"Pull request #{pr_id} or file '{file_path}' not found."}
        else:
            return {"success": False, "error": f"API error: {response.status_code} - {response.text}"}

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except httpx.RequestError as e:
        return {"success": False, "error": f"Connection error: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


@mcp.tool()
def delete_comment(
    repo_slug: str,
    pr_id: int,
    comment_id: int,
    workspace: Optional[str] = None
) -> dict:
    """
    Delete a comment from a Pull Request.

    Args:
        repo_slug: Repository slug (name)
        pr_id: Pull Request ID
        comment_id: ID of the comment to delete
        workspace: Bitbucket workspace (optional if configured)

    Returns:
        Confirmation or error message
    """
    try:
        ws = get_workspace(workspace)
        auth = get_auth()

        with httpx.Client() as client:
            response = client.delete(
                f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/pullrequests/{pr_id}/comments/{comment_id}",
                auth=auth,
                timeout=30.0
            )

        if response.status_code in (200, 204):
            return {
                "success": True,
                "message": f"Comment #{comment_id} deleted from PR #{pr_id}"
            }
        elif response.status_code == 401:
            return {"success": False, "error": "Authentication failed. Please reconfigure with setup_bitbucket."}
        elif response.status_code == 403:
            return {"success": False, "error": "Permission denied. You can only delete your own comments."}
        elif response.status_code == 404:
            return {"success": False, "error": f"Comment #{comment_id} not found in PR #{pr_id}."}
        else:
            return {"success": False, "error": f"API error: {response.status_code} - {response.text}"}

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except httpx.RequestError as e:
        return {"success": False, "error": f"Connection error: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


@mcp.tool()
def list_repositories(
    workspace: Optional[str] = None,
    page: int = 1,
    pagelen: int = 25,
    query: Optional[str] = None
) -> dict:
    """
    List repositories in a Bitbucket workspace.

    Args:
        workspace: Bitbucket workspace (optional if configured)
        page: Page number for pagination (default: 1)
        pagelen: Number of results per page, max 100 (default: 25)
        query: Optional search query to filter repositories by name

    Returns:
        List of repositories with their details
    """
    try:
        ws = get_workspace(workspace)
        auth = get_auth()

        params = {
            "page": page,
            "pagelen": min(pagelen, 100)
        }

        if query:
            params["q"] = f'name ~ "{query}"'

        with httpx.Client() as client:
            response = client.get(
                f"{BITBUCKET_API}/repositories/{ws}",
                auth=auth,
                params=params,
                timeout=30.0
            )

        if response.status_code == 200:
            data = response.json()
            repos = []
            for repo in data.get("values", []):
                repos.append({
                    "slug": repo.get("slug"),
                    "name": repo.get("name"),
                    "full_name": repo.get("full_name"),
                    "description": repo.get("description"),
                    "is_private": repo.get("is_private"),
                    "created_on": repo.get("created_on"),
                    "updated_on": repo.get("updated_on"),
                    "size": repo.get("size"),
                    "language": repo.get("language"),
                    "default_branch": repo.get("mainbranch", {}).get("name") if repo.get("mainbranch") else None,
                    "url": repo.get("links", {}).get("html", {}).get("href")
                })
            return {
                "success": True,
                "repositories": repos,
                "total": data.get("size", len(repos)),
                "page": data.get("page", page),
                "pagelen": data.get("pagelen", pagelen)
            }
        elif response.status_code == 401:
            return {"success": False, "error": "Authentication failed. Please reconfigure with setup_bitbucket."}
        elif response.status_code == 404:
            return {"success": False, "error": f"Workspace '{ws}' not found."}
        else:
            return {"success": False, "error": f"API error: {response.status_code} - {response.text}"}

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except httpx.RequestError as e:
        return {"success": False, "error": f"Connection error: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


@mcp.tool()
def get_repository(
    repo_slug: str,
    workspace: Optional[str] = None
) -> dict:
    """
    Get detailed information about a specific repository.

    Args:
        repo_slug: Repository slug (name)
        workspace: Bitbucket workspace (optional if configured)

    Returns:
        Repository details including settings, branches, and statistics
    """
    try:
        ws = get_workspace(workspace)
        auth = get_auth()

        with httpx.Client() as client:
            response = client.get(
                f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}",
                auth=auth,
                timeout=30.0
            )

        if response.status_code == 200:
            repo = response.json()
            return {
                "success": True,
                "slug": repo.get("slug"),
                "name": repo.get("name"),
                "full_name": repo.get("full_name"),
                "description": repo.get("description"),
                "is_private": repo.get("is_private"),
                "fork_policy": repo.get("fork_policy"),
                "created_on": repo.get("created_on"),
                "updated_on": repo.get("updated_on"),
                "size": repo.get("size"),
                "language": repo.get("language"),
                "default_branch": repo.get("mainbranch", {}).get("name") if repo.get("mainbranch") else None,
                "has_issues": repo.get("has_issues"),
                "has_wiki": repo.get("has_wiki"),
                "owner": repo.get("owner", {}).get("display_name"),
                "project": repo.get("project", {}).get("name") if repo.get("project") else None,
                "url": repo.get("links", {}).get("html", {}).get("href"),
                "clone_ssh": next((link.get("href") for link in repo.get("links", {}).get("clone", []) if link.get("name") == "ssh"), None),
                "clone_https": next((link.get("href") for link in repo.get("links", {}).get("clone", []) if link.get("name") == "https"), None)
            }
        elif response.status_code == 401:
            return {"success": False, "error": "Authentication failed. Please reconfigure with setup_bitbucket."}
        elif response.status_code == 404:
            return {"success": False, "error": f"Repository '{ws}/{repo_slug}' not found."}
        else:
            return {"success": False, "error": f"API error: {response.status_code} - {response.text}"}

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except httpx.RequestError as e:
        return {"success": False, "error": f"Connection error: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


@mcp.tool()
def list_branches(
    repo_slug: str,
    workspace: Optional[str] = None,
    page: int = 1,
    pagelen: int = 25,
    query: Optional[str] = None
) -> dict:
    """
    List branches in a repository.

    Args:
        repo_slug: Repository slug (name)
        workspace: Bitbucket workspace (optional if configured)
        page: Page number for pagination (default: 1)
        pagelen: Number of results per page, max 100 (default: 25)
        query: Optional search query to filter branches by name

    Returns:
        List of branches with their details
    """
    try:
        ws = get_workspace(workspace)
        auth = get_auth()

        params = {
            "page": page,
            "pagelen": min(pagelen, 100)
        }

        if query:
            params["q"] = f'name ~ "{query}"'

        with httpx.Client() as client:
            response = client.get(
                f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/refs/branches",
                auth=auth,
                params=params,
                timeout=30.0
            )

        if response.status_code == 200:
            data = response.json()
            branches = []
            for branch in data.get("values", []):
                target = branch.get("target", {})
                branches.append({
                    "name": branch.get("name"),
                    "commit_hash": target.get("hash"),
                    "commit_message": target.get("message", "").split("\n")[0] if target.get("message") else None,
                    "commit_author": target.get("author", {}).get("user", {}).get("display_name") if target.get("author") else None,
                    "commit_date": target.get("date"),
                    "default": branch.get("name") == data.get("mainbranch", {}).get("name") if data.get("mainbranch") else False
                })
            return {
                "success": True,
                "branches": branches,
                "total": data.get("size", len(branches)),
                "page": data.get("page", page),
                "pagelen": data.get("pagelen", pagelen)
            }
        elif response.status_code == 401:
            return {"success": False, "error": "Authentication failed. Please reconfigure with setup_bitbucket."}
        elif response.status_code == 404:
            return {"success": False, "error": f"Repository '{ws}/{repo_slug}' not found."}
        else:
            return {"success": False, "error": f"API error: {response.status_code} - {response.text}"}

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except httpx.RequestError as e:
        return {"success": False, "error": f"Connection error: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


@mcp.tool()
def get_pull_request_activity(
    repo_slug: str,
    pr_id: int,
    workspace: Optional[str] = None,
    page: int = 1,
    pagelen: int = 50
) -> dict:
    """
    Get the activity/timeline of a Pull Request including comments, approvals, and updates.

    Args:
        repo_slug: Repository slug (name)
        pr_id: Pull Request ID
        workspace: Bitbucket workspace (optional if configured)
        page: Page number for pagination (default: 1)
        pagelen: Number of results per page, max 100 (default: 50)

    Returns:
        List of activity events on the PR
    """
    try:
        ws = get_workspace(workspace)
        auth = get_auth()

        params = {
            "page": page,
            "pagelen": min(pagelen, 100)
        }

        with httpx.Client() as client:
            response = client.get(
                f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/pullrequests/{pr_id}/activity",
                auth=auth,
                params=params,
                timeout=30.0
            )

        if response.status_code == 200:
            data = response.json()
            activities = []
            for activity in data.get("values", []):
                activity_item = {}

                if "approval" in activity:
                    approval = activity["approval"]
                    activity_item = {
                        "type": "approval",
                        "user": approval.get("user", {}).get("display_name"),
                        "date": approval.get("date")
                    }
                elif "update" in activity:
                    update = activity["update"]
                    activity_item = {
                        "type": "update",
                        "author": update.get("author", {}).get("display_name"),
                        "date": update.get("date"),
                        "state": update.get("state"),
                        "title": update.get("title"),
                        "description": update.get("description"),
                        "changes": update.get("changes")
                    }
                elif "comment" in activity:
                    comment = activity["comment"]
                    activity_item = {
                        "type": "comment",
                        "id": comment.get("id"),
                        "user": comment.get("user", {}).get("display_name"),
                        "content": comment.get("content", {}).get("raw"),
                        "created_on": comment.get("created_on"),
                        "inline": comment.get("inline")
                    }

                if activity_item:
                    activities.append(activity_item)

            return {
                "success": True,
                "activities": activities,
                "total": data.get("size", len(activities)),
                "page": data.get("page", page),
                "pagelen": data.get("pagelen", pagelen)
            }
        elif response.status_code == 401:
            return {"success": False, "error": "Authentication failed. Please reconfigure with setup_bitbucket."}
        elif response.status_code == 404:
            return {"success": False, "error": f"Pull request #{pr_id} not found in '{ws}/{repo_slug}'."}
        else:
            return {"success": False, "error": f"API error: {response.status_code} - {response.text}"}

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except httpx.RequestError as e:
        return {"success": False, "error": f"Connection error: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


@mcp.tool()
def get_pull_request_commits(
    repo_slug: str,
    pr_id: int,
    workspace: Optional[str] = None,
    page: int = 1,
    pagelen: int = 50
) -> dict:
    """
    Get the list of commits in a Pull Request.

    Args:
        repo_slug: Repository slug (name)
        pr_id: Pull Request ID
        workspace: Bitbucket workspace (optional if configured)
        page: Page number for pagination (default: 1)
        pagelen: Number of results per page, max 100 (default: 50)

    Returns:
        List of commits in the PR
    """
    try:
        ws = get_workspace(workspace)
        auth = get_auth()

        params = {
            "page": page,
            "pagelen": min(pagelen, 100)
        }

        with httpx.Client() as client:
            response = client.get(
                f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/pullrequests/{pr_id}/commits",
                auth=auth,
                params=params,
                timeout=30.0
            )

        if response.status_code == 200:
            data = response.json()
            commits = []
            for commit in data.get("values", []):
                commits.append({
                    "hash": commit.get("hash"),
                    "hash_short": commit.get("hash", "")[:7],
                    "message": commit.get("message"),
                    "message_summary": commit.get("message", "").split("\n")[0] if commit.get("message") else None,
                    "author": commit.get("author", {}).get("user", {}).get("display_name") if commit.get("author", {}).get("user") else commit.get("author", {}).get("raw"),
                    "date": commit.get("date"),
                    "url": commit.get("links", {}).get("html", {}).get("href")
                })
            return {
                "success": True,
                "commits": commits,
                "total": data.get("size", len(commits)),
                "page": data.get("page", page),
                "pagelen": data.get("pagelen", pagelen)
            }
        elif response.status_code == 401:
            return {"success": False, "error": "Authentication failed. Please reconfigure with setup_bitbucket."}
        elif response.status_code == 404:
            return {"success": False, "error": f"Pull request #{pr_id} not found in '{ws}/{repo_slug}'."}
        else:
            return {"success": False, "error": f"API error: {response.status_code} - {response.text}"}

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except httpx.RequestError as e:
        return {"success": False, "error": f"Connection error: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


@mcp.tool()
def add_reviewer(
    repo_slug: str,
    pr_id: int,
    reviewer: str,
    workspace: Optional[str] = None
) -> dict:
    """
    Add a reviewer to a Pull Request without removing existing reviewers.

    Args:
        repo_slug: Repository slug (name)
        pr_id: Pull Request ID
        reviewer: UUID or account_id of the reviewer to add
        workspace: Bitbucket workspace (optional if configured)

    Returns:
        Updated reviewer list or error message
    """
    try:
        ws = get_workspace(workspace)
        auth = get_auth()

        # First get current PR to get existing reviewers
        with httpx.Client() as client:
            get_response = client.get(
                f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/pullrequests/{pr_id}",
                auth=auth,
                timeout=30.0
            )

        if get_response.status_code != 200:
            return {"success": False, "error": f"Failed to get PR: {get_response.status_code}"}

        pr_data = get_response.json()
        current_reviewers = pr_data.get("reviewers", [])

        # Build new reviewer list
        reviewer_list = [{"uuid": r.get("uuid")} for r in current_reviewers]

        # Add new reviewer
        if reviewer.startswith("{"):
            new_reviewer = {"uuid": reviewer}
        else:
            new_reviewer = {"account_id": reviewer}

        # Check if already a reviewer
        existing_uuids = {r.get("uuid") for r in reviewer_list}
        if reviewer in existing_uuids:
            return {"success": False, "error": "User is already a reviewer on this PR."}

        reviewer_list.append(new_reviewer)

        # Update PR with new reviewer list
        with httpx.Client() as client:
            response = client.put(
                f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/pullrequests/{pr_id}",
                auth=auth,
                json={"reviewers": reviewer_list},
                timeout=30.0
            )

        if response.status_code == 200:
            pr = response.json()
            reviewers = [
                {"display_name": r.get("display_name"), "uuid": r.get("uuid")}
                for r in pr.get("reviewers", [])
            ]
            return {
                "success": True,
                "message": f"Reviewer added to PR #{pr_id}",
                "reviewers": reviewers
            }
        elif response.status_code == 400:
            error_data = response.json()
            error_msg = error_data.get("error", {}).get("message", "Bad request")
            return {"success": False, "error": error_msg}
        elif response.status_code == 401:
            return {"success": False, "error": "Authentication failed. Please reconfigure with setup_bitbucket."}
        elif response.status_code == 404:
            return {"success": False, "error": f"Pull request #{pr_id} not found."}
        else:
            return {"success": False, "error": f"API error: {response.status_code} - {response.text}"}

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except httpx.RequestError as e:
        return {"success": False, "error": f"Connection error: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


@mcp.tool()
def remove_reviewer(
    repo_slug: str,
    pr_id: int,
    reviewer: str,
    workspace: Optional[str] = None
) -> dict:
    """
    Remove a reviewer from a Pull Request.

    Args:
        repo_slug: Repository slug (name)
        pr_id: Pull Request ID
        reviewer: UUID or account_id of the reviewer to remove
        workspace: Bitbucket workspace (optional if configured)

    Returns:
        Updated reviewer list or error message
    """
    try:
        ws = get_workspace(workspace)
        auth = get_auth()

        # First get current PR to get existing reviewers
        with httpx.Client() as client:
            get_response = client.get(
                f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/pullrequests/{pr_id}",
                auth=auth,
                timeout=30.0
            )

        if get_response.status_code != 200:
            return {"success": False, "error": f"Failed to get PR: {get_response.status_code}"}

        pr_data = get_response.json()
        current_reviewers = pr_data.get("reviewers", [])

        # Filter out the reviewer to remove
        reviewer_list = []
        found = False
        for r in current_reviewers:
            if r.get("uuid") == reviewer or r.get("account_id") == reviewer:
                found = True
            else:
                reviewer_list.append({"uuid": r.get("uuid")})

        if not found:
            return {"success": False, "error": "User is not a reviewer on this PR."}

        # Update PR with new reviewer list
        with httpx.Client() as client:
            response = client.put(
                f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/pullrequests/{pr_id}",
                auth=auth,
                json={"reviewers": reviewer_list},
                timeout=30.0
            )

        if response.status_code == 200:
            pr = response.json()
            reviewers = [
                {"display_name": r.get("display_name"), "uuid": r.get("uuid")}
                for r in pr.get("reviewers", [])
            ]
            return {
                "success": True,
                "message": f"Reviewer removed from PR #{pr_id}",
                "reviewers": reviewers
            }
        elif response.status_code == 400:
            error_data = response.json()
            error_msg = error_data.get("error", {}).get("message", "Bad request")
            return {"success": False, "error": error_msg}
        elif response.status_code == 401:
            return {"success": False, "error": "Authentication failed. Please reconfigure with setup_bitbucket."}
        elif response.status_code == 404:
            return {"success": False, "error": f"Pull request #{pr_id} not found."}
        else:
            return {"success": False, "error": f"API error: {response.status_code} - {response.text}"}

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except httpx.RequestError as e:
        return {"success": False, "error": f"Connection error: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


@mcp.tool()
def get_pull_request_merge_status(
    repo_slug: str,
    pr_id: int,
    workspace: Optional[str] = None
) -> dict:
    """
    Check if a Pull Request can be merged and get merge status details.

    Args:
        repo_slug: Repository slug (name)
        pr_id: Pull Request ID
        workspace: Bitbucket workspace (optional if configured)

    Returns:
        Merge status including conflicts, required approvals, and blockers
    """
    try:
        ws = get_workspace(workspace)
        auth = get_auth()

        # Get PR details to check state and approvals
        with httpx.Client() as client:
            pr_response = client.get(
                f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/pullrequests/{pr_id}",
                auth=auth,
                timeout=30.0
            )

        if pr_response.status_code != 200:
            if pr_response.status_code == 401:
                return {"success": False, "error": "Authentication failed. Please reconfigure with setup_bitbucket."}
            elif pr_response.status_code == 404:
                return {"success": False, "error": f"Pull request #{pr_id} not found in '{ws}/{repo_slug}'."}
            return {"success": False, "error": f"API error: {pr_response.status_code} - {pr_response.text}"}

        pr_data = pr_response.json()

        # Get diffstat to check for conflicts
        with httpx.Client() as client:
            diff_response = client.get(
                f"{BITBUCKET_API}/repositories/{ws}/{repo_slug}/pullrequests/{pr_id}/diffstat",
                auth=auth,
                timeout=30.0
            )

        has_conflicts = False
        conflict_files = []
        if diff_response.status_code == 200:
            diff_data = diff_response.json()
            for file_stat in diff_data.get("values", []):
                if file_stat.get("status") == "merge conflict":
                    has_conflicts = True
                    conflict_files.append(file_stat.get("new", {}).get("path") or file_stat.get("old", {}).get("path"))

        # Analyze participants for approvals
        participants = pr_data.get("participants", [])
        approvals = []
        changes_requested = []
        for p in participants:
            user_name = p.get("user", {}).get("display_name")
            if p.get("approved"):
                approvals.append(user_name)
            if p.get("state") == "changes_requested":
                changes_requested.append(user_name)

        # Determine if mergeable
        state = pr_data.get("state")
        is_open = state == "OPEN"
        blockers = []

        if not is_open:
            blockers.append(f"PR is {state}, not OPEN")
        if has_conflicts:
            blockers.append("Has merge conflicts")
        if changes_requested:
            blockers.append(f"Changes requested by: {', '.join(changes_requested)}")

        can_merge = is_open and not has_conflicts and not changes_requested

        return {
            "success": True,
            "can_merge": can_merge,
            "state": state,
            "has_conflicts": has_conflicts,
            "conflict_files": conflict_files if conflict_files else None,
            "approvals": approvals,
            "approval_count": len(approvals),
            "changes_requested_by": changes_requested if changes_requested else None,
            "blockers": blockers if blockers else None,
            "source_branch": pr_data.get("source", {}).get("branch", {}).get("name"),
            "destination_branch": pr_data.get("destination", {}).get("branch", {}).get("name")
        }

    except ValueError as e:
        return {"success": False, "error": str(e)}
    except httpx.RequestError as e:
        return {"success": False, "error": f"Connection error: {str(e)}"}
    except Exception as e:
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


def main():
    """Entry point for the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
