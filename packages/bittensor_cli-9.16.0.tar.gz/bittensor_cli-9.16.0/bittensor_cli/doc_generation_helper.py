from bittensor_cli.cli import CLIManager

cli_manager = CLIManager()
app = cli_manager.app
