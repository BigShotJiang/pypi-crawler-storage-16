"""
Internal implementation of sentinel.

This project uses ApiVer, and as such, all imports should be done from v* submodules.
"""
