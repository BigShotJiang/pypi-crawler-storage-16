from enum import Enum

class BizkaibusLanguages(Enum):
    ES = 'es'
    EU = 'eu'