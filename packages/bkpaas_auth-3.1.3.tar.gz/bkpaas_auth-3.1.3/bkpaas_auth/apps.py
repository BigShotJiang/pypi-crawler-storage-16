from __future__ import unicode_literals

from django.apps import AppConfig


class BkpaasAuthConfig(AppConfig):
    name = 'bkpaas_auth'
    # TODO: patch get_user function when app is ready
