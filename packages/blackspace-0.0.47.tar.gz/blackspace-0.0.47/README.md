# BlackSpace

BlackSpace is a programming language that compiles to WhiteSpace, an esoteric programming language
that uses only spaces, tabs, and linefeeds as syntax. BlackSpace is designed to make it easier
to write and read WhiteSpace programs by providing a higher-level syntax.

Currently the parser is not implemented, and only the compiler from an AST to WhiteSpace
is available.
