from abc import ABC


class AstNode(ABC):
    pass
