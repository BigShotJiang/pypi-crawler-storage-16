def main() -> None:
    pass


if __name__ == "__main__":
    main()
