from enum import Enum


class IssueLevel(Enum):
    WARNING = "warning"
    ERROR = "error"
