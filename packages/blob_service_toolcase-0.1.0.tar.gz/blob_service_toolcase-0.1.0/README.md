# blob-service-toolcase

A lightweight and developer-friendly utility for loading text data from Azure Blob Storage.

---

## Installation

```bash
pip install blob-service-toolcase
```

## Usage

```python
from blob_service_toolcase import BlobLoader

loader = BlobLoader("AZURE_STORAGE_CONNECTION_STRING")

content = loader.load_text(
    container="my-container",
    blob="config.json"
)

print(content)
```