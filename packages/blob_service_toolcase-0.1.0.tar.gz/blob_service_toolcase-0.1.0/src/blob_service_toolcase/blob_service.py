import logging
from azure.storage.blob import BlobServiceClient


class BlobLoader:
    """
    Utility service for loading text content from Azure Blob Storage.
    """

    def __init__(self, connection_string: str):
        if not connection_string:
            raise ValueError("Azure Blob connection string is required.")

        logging.info("Initializing Azure BlobServiceClient")
        self.client = BlobServiceClient.from_connection_string(connection_string)


    def load_text(self, container: str, blob: str) -> str:
        """
        Load a text blob from Azure Blob Storage.

        :param container: Blob container name
        :param blob: Blob file name
        :return: Text content as string
        """
        logging.info(f"Loading blob '{blob}' from container '{container}'")

        try:
            blob_client = self.client.get_blob_client(container=container, blob=blob)
            data = blob_client.download_blob().readall()
            return data.decode("utf-8")

        except Exception as e:
            raise RuntimeError(f"Failed to load blob '{blob}' from '{container}': {e}")
