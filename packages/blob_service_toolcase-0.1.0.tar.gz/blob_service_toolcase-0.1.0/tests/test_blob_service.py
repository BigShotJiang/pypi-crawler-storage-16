import pytest
from unittest.mock import patch, MagicMock
from blob_service_toolcase import BlobLoader

@patch("blob_service_toolcase.blob_service.BlobServiceClient")
def test_load_text_success(mock_blob_service):
    # Set up mock download result
    mock_client = MagicMock()
    mock_blob = MagicMock()
    mock_blob.download_blob.return_value.readall.return_value = b"hello world"

    mock_client.get_blob_client.return_value = mock_blob
    mock_blob_service.from_connection_string.return_value = mock_client

    loader = BlobLoader("fake-connection-string")
    result = loader.load_text("container", "file.txt")

    assert result == "hello world"


def test_missing_connection_string():
    with pytest.raises(ValueError):
        BlobLoader("")
