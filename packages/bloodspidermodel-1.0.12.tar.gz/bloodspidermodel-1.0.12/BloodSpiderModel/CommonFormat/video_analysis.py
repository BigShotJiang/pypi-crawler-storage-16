class VideoAnalysis:
    """
    视频解析类
    """
    
    def video_analysis(self):
        return {
            "video_play_url": ""
        }