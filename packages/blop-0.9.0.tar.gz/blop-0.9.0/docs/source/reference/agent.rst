Agent
=====

.. autoclass:: blop.ax.Agent
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :no-index:
