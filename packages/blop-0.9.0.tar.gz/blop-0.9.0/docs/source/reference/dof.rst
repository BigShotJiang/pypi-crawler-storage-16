Degree of Freedom (DOF)
=======================

DOF
---

.. autoclass:: blop.ax.dof.DOF
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :no-index:

RangeDOF
--------

.. autoclass:: blop.ax.dof.RangeDOF
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :no-index:

ChoiceDOF
---------

.. autoclass:: blop.ax.dof.ChoiceDOF
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :no-index:
