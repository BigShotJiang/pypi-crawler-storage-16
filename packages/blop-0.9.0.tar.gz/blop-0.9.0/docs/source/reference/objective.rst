Objectives
==========

Objective
---------

.. autoclass:: blop.ax.objective.Objective
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :no-index:


Scalarized Objective
--------------------

.. autoclass:: blop.ax.objective.ScalarizedObjective
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :no-index:
