Outcome Constraint
==================

.. autoclass:: blop.ax.objective.OutcomeConstraint
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :no-index:
