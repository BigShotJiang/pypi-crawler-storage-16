Plans
=====

.. autofunction:: blop.plans.optimize

.. autofunction:: blop.plans.optimize_step

.. autofunction:: blop.plans.default_acquire
