import warnings

warnings.warn("The de module is deprecated and will be removed in Blop v1.0.0.", DeprecationWarning, stacklevel=2)
