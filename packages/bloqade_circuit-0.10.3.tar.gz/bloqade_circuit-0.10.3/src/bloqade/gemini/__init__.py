from .dialects import logical as logical
