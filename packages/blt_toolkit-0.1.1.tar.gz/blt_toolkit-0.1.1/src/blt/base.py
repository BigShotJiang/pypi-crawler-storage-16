"""Model-agnostic music generation interface."""

if __name__ == "__main__":
    pass
