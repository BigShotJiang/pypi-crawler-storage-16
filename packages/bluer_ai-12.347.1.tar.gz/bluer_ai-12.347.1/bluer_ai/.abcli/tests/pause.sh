#! /usr/bin/env bash

function test_bluer_ai_pause() {
    bluer_ai_pause dryrun
}
