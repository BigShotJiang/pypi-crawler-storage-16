docs = [
    {"path": "../docs/tracker"},
    {"path": "../docs/tracker/camshift.md"},
    {"path": "../docs/tracker/meanshift.md"},
]
