NAME = "bluer_algo"

ICON = "🪄"

DESCRIPTION = f"{ICON} AI Algo."

VERSION = "4.614.1"

REPO_NAME = "bluer-algo"

MARQUEE = "https://github.com/kamangir/assets/raw/main/swallow-model-2025-07-11-15-04-03-2glcch/evaluation.png?raw=true"

ALIAS = "@algo"


def fullname() -> str:
    return f"{NAME}-{VERSION}"
