docs = [
    {
        "path": f"../docs/aliases/{item}.md",
    }
    for item in [
        "camera",
        "hardware",
        "rpi",
        "sbc",
    ]
]
