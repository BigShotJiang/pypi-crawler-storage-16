from bluer_ugv.README.swallow.digital import algo, design

docs = (
    [
        {
            "path": "../docs/swallow/digital",
        }
    ]
    + design.docs
    + algo.docs
)
