from bluer_ugv.README.swallow.digital import algo, design

docs = (
    [
        {
            "path": "../docs/swallow/digital",
        },
        {
            "path": "../docs/swallow/digital/manual.md",
        },
    ]
    + design.docs
    + algo.docs
)
