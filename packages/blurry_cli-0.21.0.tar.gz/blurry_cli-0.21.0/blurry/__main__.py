from blurry import main

main()
