bmdrc
=====

**bmdrc** is a Python library for fitting benchmark dose curves to dichotomous data and light photomotor response data