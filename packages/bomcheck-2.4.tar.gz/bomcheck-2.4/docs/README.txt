bomcheck.cfg is a file you can alter to to suit your needs.  Let the bomcheck
program know where the altered file is located via the command line, or if
you're using bomcheckgui, set the location in the settings menu.

bomcheck.cfg can be edited with a text editor program like notepad.
