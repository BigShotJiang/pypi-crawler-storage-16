In this folder are example BOMs that the bomcheck program is able to work with.
If the structure of your BOMs are different and fails to run correctly, see
the file bc_config.py.  Perhaps it can help.

See the README.txt file that is in the folder "mydata" about running the
bomcheck program using this data. 