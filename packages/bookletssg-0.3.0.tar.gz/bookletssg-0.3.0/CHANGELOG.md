# 0.3.0

- new markdown engine: mistune
- added minification: minify_html
- new default template!! :D
