rm -rf dist/ booklet.json articles/
