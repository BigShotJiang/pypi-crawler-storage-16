import os
import json
import mistune
import requests
import minify_html


# TODO: optimize this absurd CSS and HTML
THEME_DEFAULT = """
:root{
  --bg:#f8f6f5;
  --fg:#2a2a2a;
  --accent:#d8895b;
  --accent-soft:rgba(216,137,91,0.12);
  --card-bg:rgba(255,255,255,0.6);
  --card-border:rgba(0,0,0,0.07);
  --radius:12px;
  font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
  box-sizing:border-box;
}

@media (prefers-color-scheme: dark){
  :root{
    --bg:#161513;
    --fg:#e8e4df;
    --accent:#f0a476;
    --accent-soft:rgba(240,164,118,0.16);
    --card-bg:rgba(255,255,255,0.06);
    --card-border:rgba(255,255,255,0.12);
  }
}

*,*::before,*::after{ box-sizing:inherit }

html,body{
  margin:0;
  background:var(--bg);
  color:var(--fg);
}

body{
  max-width:720px;
  margin:0 auto;
  padding:2rem 1.25rem;
}

header h1{
  margin:0;
  font-size:1.9rem;
  letter-spacing:-0.03em;
}

header p{
  margin:.4rem 0 1.2rem;
  color:rgba(0,0,0,0.6);
}

@media (prefers-color-scheme: dark){
  header p{ color:rgba(255,255,255,0.55); }
}

body > ul{
  list-style:none;
  padding:0;
  margin:1.5rem 0;
  display:flex;
  flex-direction:column;
  gap:1rem;
}

body > ul > li{
  background:var(--card-bg);
  border:1px solid var(--card-border);
  border-radius:var(--radius);
  backdrop-filter:blur(10px) saturate(130%);
  transition:0.25s;
  overflow:hidden;
}

body > ul > li:hover{
  border-color:var(--accent);
}


body > ul > li > a{
  display:flex;
  flex-direction:row;
  align-items:center;
  gap:.9rem;
  padding:1rem 1.2rem;
  color:inherit;
  text-decoration:none;
  font-weight:600;
  font-size:1rem;
}

@media (max-width:520px){
  body > ul > li > a{
    flex-direction:column;
    align-items:flex-start;
    gap:.4rem;
  }
}

body > a:first-of-type{
  display:inline-flex;
  align-items:center;
  gap:.4rem;
  padding:.4rem .75rem;
  background:var(--card-bg);
  border:1px solid var(--card-border);
  border-radius:var(--radius);
  backdrop-filter:blur(10px) saturate(130%);
   var(--shadow);
  text-decoration:none;
  color:var(--fg);
  font-size:.95rem;
  transition:0.25s;
  margin-bottom:1.5rem;
}

body > a:first-of-type::before{
  content:"←";
  font-size:1rem;
  opacity:.85;
}

body > a:first-of-type:hover{
  border-color:var(--accent);
}


pre {
    background-color: var(--card-bg);
    border-radius: var(--radius);
    border: 1px solid var(--card-border);
    padding: 1rem;
    overflow-x: auto;
    margin: 1rem 0; 
}

pre code {
    font-family: "Menlo", "Cascadia Code", "DejaVu Sans Mono", monospace;
    font-size: 0.9rem;
    margin: 0;
    background: none;
    padding: 0;
}


"""

TEMPLATE_ARTICLE = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>{title}</title>
    <style>{theme}</style>
</head>
<body>
    <a href="/">{site}</a>
    <article>
        <h1>{title}</h1>
        {content}
    </article>
</body>
</html>

"""

TEMPLATE_INDEX = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>{site}</title>
    <style>{theme}</style>
</head>
<body>
    <header>
        <h1>{site}</h1>
        <p><i>by {author}</i></p>
    </header>
    <ul>
        {articles}
    </ul>
</body>
</html>

</html>
"""


def render_markdown_file(path):
    with open(path, "r", encoding="utf-8") as f:
        return mistune.html(f.read())


def init():
    name = input("name: ").strip()
    author = input("author: ").strip()
    os.makedirs("articles", exist_ok=True)
    os.makedirs("dist", exist_ok=True)

    cfg = {"name": name, "author": author, "theme": "default"}
    with open("booklet.json", "w") as f:
        json.dump(cfg, f, indent=2)


def build():
    with open("booklet.json") as f:
        cfg = json.load(f)

    if cfg["theme"] == "default":
        theme_css = THEME_DEFAULT
    else:
        try:
            theme_css = requests.get(cfg["theme"]).text
        except Exception:
            theme_css = THEME_DEFAULT

    os.makedirs("dist", exist_ok=True)

    links = []
    for fname in os.listdir("articles"):
        fpath = os.path.join("articles", fname)
        if not os.path.isfile(fpath):
            continue

        title, _ = os.path.splitext(fname)
        content = render_markdown_file(fpath)

        html = TEMPLATE_ARTICLE.format(
            theme=theme_css, title=title, author=cfg["author"], content=content, site=cfg["name"]
        )

        html = minify_html.minify(html, minify_css=True)

        with open(os.path.join("dist", f"{title}.html"), "w", encoding="utf-8") as f:
            f.write(html)

        links.append(f'<li><a href="{title}.html">{title}</a></li>')

    index_html = TEMPLATE_INDEX.format(
        theme=theme_css, site=cfg["name"], author=cfg["author"], articles="\n".join(links)
    )

    index_html = minify_html.minify(index_html, minify_css=True)

    with open(os.path.join("dist", "index.html"), "w", encoding="utf-8") as f:
        f.write(index_html)


def version():
    print("0.3.0")


def main():
    import sys

    cmds = {"init": init, "build": build, "version": version}
    cmds.get(sys.argv[1], lambda: print("init | build | version"))()


if __name__ == "__main__":
    main()
