from collections import OrderedDict
import os
import sys
from typing import List, Dict, Optional
import pandas as pd
import numpy as np
import requests
from datetime import datetime, timedelta
from selenium import webdriver
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import StaleElementReferenceException, TimeoutException
import logging
from bs4 import BeautifulSoup
import time
import random
import concurrent.futures
import psutil
import re
import glob
import yaml
import json
import datetime as dt
from chameli.interactions import readRDS, saveRDS, get_session_or_driver
from .config import get_config


# Import bootlick_logger lazily to avoid circular import
def get_bootlick_logger():
    """Get bootlick_logger instance to avoid circular imports."""
    from . import bootlick_logger

    return bootlick_logger


def get_dynamic_config():
    return get_config()


headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.5993.70 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
    "Accept-Encoding": "gzip, deflate, br",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "Pragma": "no-cache",
    "Cache-Control": "no-cache",
}

# COACode - Standard Character Code for Ledger Name
# EndDate - End Date for the period if PnL/CF Item, else date of snapshot
# FiscalYear - Fiscal Year for the EndDate
# FiscalPeriodNumber - Period Number between 1-4, but it could be 5 too if there is a change in reporting period midyear
# PeriodType - Type of period - Annual if corresponding to Annual (12 mth or equiv reporting) else Interim
# PeriodLength - No of months in period if item is from PnL/CF
# Symbol - Company Name


def handle_cash_flows_section(driver):
    if driver is None:
        error_msg = "Driver is None, cannot handle cash flows section"
        get_bootlick_logger().log_error(error_msg, None, {"function": "handle_cash_flows_section"})
        return
    try:
        # Locate the Cash Flows section
        cash_flows_section = WebDriverWait(driver, 15).until(
            EC.presence_of_element_located(
                (By.XPATH, "//div[@class='responsive-holder fill-card-width'][@data-result-table]")
            )
        )
        # Find all buttons inside the section
        cash_flows_buttons = cash_flows_section.find_elements(By.XPATH, ".//tr[contains(@class, 'expandable')]//button")

        if not cash_flows_buttons:
            get_bootlick_logger().log_error(
                "No Cash Flows buttons found.", None, {"function": "handle_cash_flows_section"}
            )
            return

        for index, button in enumerate(cash_flows_buttons):
            # Check driver health before each button
            if not is_driver_alive(driver):
                get_bootlick_logger().log_warning(
                    f"Driver died during cash flows button clicking at index {index}",
                    {"button_index": index, "function": "handle_cash_flows_section"}
                )
                break
            
            retries = 0
            while retries < 3:
                try:
                    if not is_driver_alive(driver):
                        break
                    
                    # Scroll the button into view
                    driver.execute_script("arguments[0].scrollIntoView(true);", button)

                    # Use JavaScript click as a fallback if regular click doesn't work
                    driver.execute_script("arguments[0].click();", button)
                    # Longer delay for cash flow buttons as they trigger API calls to schedules endpoint
                    # This helps avoid 429 rate limit errors
                    delay = random.uniform(3, 6)
                    get_bootlick_logger().log_debug(
                        f"Waiting {delay:.2f}s after clicking cash flow button {index + 1}",
                        {"button_index": index + 1, "delay": delay, "function": "handle_cash_flows_section"}
                    )
                    time.sleep(delay)

                    # Check if the section expanded
                    if is_section_expanded(button):
                        get_bootlick_logger().log_debug(
                            f"Successfully clicked and expanded Cash Flows button {index + 1}",
                            {"button_index": index + 1, "function": "handle_cash_flows_section"},
                        )
                        break
                    else:
                        get_bootlick_logger().log_debug(
                            f"Cash Flows button {index + 1} did not expand. Retrying...",
                            {"button_index": index + 1, "function": "handle_cash_flows_section"},
                        )
                        retries += 1

                except (StaleElementReferenceException, TimeoutException) as e:
                    get_bootlick_logger().log_debug(
                        f"Retry {retries + 1}: Failed to click Cash Flows button {index + 1} due to {e}",
                        {
                            "retry_count": retries + 1,
                            "button_index": index + 1,
                            "error_type": type(e).__name__,
                            "function": "handle_cash_flows_section",
                        },
                    )
                    retries += 1
                except Exception as e:
                    get_bootlick_logger().log_debug(
                        f"Failed to click Cash Flows button {index + 1}: {e}",
                        {
                            "button_index": index + 1,
                            "error_type": type(e).__name__,
                            "function": "handle_cash_flows_section",
                        },
                    )
                    retries += 1

    except Exception as e:
        get_bootlick_logger().log_debug(
            f"Error handling Cash Flows section: {e}",
            {"error_type": type(e).__name__, "function": "handle_cash_flows_section"},
        )


def is_section_expanded(button):
    try:
        # Check if the row below the button is now visible
        parent_row = button.find_element(By.XPATH, "../..")
        expanded_row = parent_row.find_element(By.XPATH, "following-sibling::tr[contains(@class, 'child-row')]")
        return expanded_row.is_displayed()
    except Exception:
        return False


def is_driver_alive(driver):
    """
    Check if WebDriver is still alive and responsive.
    
    Args:
        driver: Selenium WebDriver instance
        
    Returns:
        bool: True if driver is alive, False otherwise
    """
    if driver is None:
        return False
    try:
        # Quick check - try to get current URL (lightweight operation)
        _ = driver.current_url
        return True
    except Exception:
        return False


def get_page_source_safe(driver, symbol: str, max_retries: int = 2):
    """
    Safely get page source with driver health checks and retries.
    
    Args:
        driver: Selenium WebDriver instance
        symbol: Symbol being processed (for logging)
        max_retries: Maximum number of retries if driver is dead
        
    Returns:
        str: Page source HTML
        
    Raises:
        ValueError: If driver is dead and cannot be recovered
    """
    if not is_driver_alive(driver):
        error_msg = f"Driver is dead when trying to get page source for {symbol}"
        get_bootlick_logger().log_error(error_msg, None, {"symbol": symbol, "function": "get_page_source_safe"})
        raise ValueError(error_msg)
    
    for attempt in range(max_retries):
        try:
            page_source = driver.page_source
            if page_source and len(page_source) > 100:  # Basic validation
                return page_source
            else:
                get_bootlick_logger().log_warning(
                    f"Page source too short or empty for {symbol}, attempt {attempt + 1}",
                    {"symbol": symbol, "attempt": attempt + 1, "page_source_length": len(page_source) if page_source else 0, "function": "get_page_source_safe"}
                )
                if attempt < max_retries - 1:
                    time.sleep(1)
                    continue
        except Exception as e:
            if not is_driver_alive(driver):
                error_msg = f"Driver died while getting page source for {symbol}"
                get_bootlick_logger().log_error(error_msg, e, {"symbol": symbol, "attempt": attempt + 1, "function": "get_page_source_safe"})
                raise ValueError(error_msg)
            
            if attempt < max_retries - 1:
                get_bootlick_logger().log_warning(
                    f"Error getting page source for {symbol}, retrying...",
                    {"symbol": symbol, "attempt": attempt + 1, "error": str(e), "function": "get_page_source_safe"}
                )
                time.sleep(0.5)
                continue
            else:
                raise
    
    error_msg = f"Failed to get valid page source for {symbol} after {max_retries} attempts"
    get_bootlick_logger().log_error(error_msg, None, {"symbol": symbol, "function": "get_page_source_safe"})
    raise ValueError(error_msg)


def wait_for_ajax_complete(driver, timeout=10):
    """
    Wait for AJAX/jQuery requests to complete.
    This ensures dynamic content loaded via JavaScript is fully rendered.
    """
    if driver is None or not is_driver_alive(driver):
        return
    
    try:
        # Wait for jQuery to finish (if present)
        def check_jquery():
            if not is_driver_alive(driver):
                return True
            try:
                return driver.execute_script("return typeof jQuery === 'undefined' || jQuery.active === 0")
            except Exception:
                return True  # Assume done if jQuery check fails
        
        WebDriverWait(driver, timeout).until(check_jquery)
        
        # Wait for fetch/XHR requests to complete
        def check_network_idle():
            if not is_driver_alive(driver):
                return True
            try:
                # Check if there are any pending network requests
                pending = driver.execute_script("""
                    if (typeof window.fetch !== 'undefined') {
                        return window.fetch.pending === 0 || window.fetch.pending === undefined;
                    }
                    return true;
                """)
                return pending
            except Exception:
                return True  # Assume done if check fails
        
        WebDriverWait(driver, timeout).until(check_network_idle)
        
    except Exception as e:
        get_bootlick_logger().log_debug(
            f"Error waiting for AJAX completion: {e}",
            {"error": str(e), "function": "wait_for_ajax_complete"}
        )
        # Don't fail - just continue


def wait_for_tables_rendered(driver, symbol: str, timeout=15):
    """
    Wait for financial tables to be rendered with actual data.
    This ensures we don't parse empty or partially loaded tables.
    """
    if driver is None or not is_driver_alive(driver):
        return False
    
    try:
        # Wait for at least one table with data rows to be present
        def check_tables_rendered(d):
            if not is_driver_alive(d):
                return False
            try:
                # Check if tables exist and have data rows (not just headers)
                script = """
                    var tables = document.querySelectorAll('table');
                    for (var i = 0; i < tables.length; i++) {
                        var rows = tables[i].querySelectorAll('tbody tr, tr');
                        if (rows.length > 1) {  // At least header + 1 data row
                            return true;
                        }
                    }
                    return false;
                """
                return d.execute_script(script)
            except Exception:
                return False
        
        WebDriverWait(driver, timeout).until(check_tables_rendered)
        get_bootlick_logger().log_debug(
            f"Financial tables rendered for {symbol}",
            {"symbol": symbol, "function": "wait_for_tables_rendered"}
        )
        return True
    except Exception as e:
        get_bootlick_logger().log_warning(
            f"Timeout waiting for tables to render for {symbol}",
            {"symbol": symbol, "error": str(e), "function": "wait_for_tables_rendered"}
        )
        return False


def wait_for_complete_load(driver, timeout=30):
    """Wait until the page is fully loaded, network is idle, and status bar is clear."""
    if driver is None:
        error_msg = "Driver is None, cannot wait for page load"
        get_bootlick_logger().log_error(error_msg, None, {"function": "wait_for_complete_load"})
        raise ValueError(error_msg)
    
    if not is_driver_alive(driver):
        error_msg = "Driver is dead, cannot wait for page load"
        get_bootlick_logger().log_error(error_msg, None, {"function": "wait_for_complete_load"})
        raise ValueError(error_msg)
    
    get_bootlick_logger().log_debug("Waiting for page load to complete...", {"function": "wait_for_complete_load"})

    try:
        # Wait for document readyState to be 'complete' with health checks
        def check_ready_state(d):
            if not is_driver_alive(d):
                return False
            try:
                return d.execute_script("return document.readyState") == "complete"
            except Exception:
                return False
        
        WebDriverWait(driver, timeout).until(check_ready_state)
        get_bootlick_logger().log_debug("Document is fully loaded.", {"function": "wait_for_complete_load"})
        
        if not is_driver_alive(driver):
            error_msg = "Driver died after document load"
            get_bootlick_logger().log_error(error_msg, None, {"function": "wait_for_complete_load"})
            raise ValueError(error_msg)

        # Wait for AJAX/network requests to complete
        wait_for_ajax_complete(driver, timeout=10)

        # Wait for the status bar message to clear with health checks
        def check_status_bar(d):
            if not is_driver_alive(d):
                return True  # Return True to stop waiting if driver is dead
            try:
                status = d.execute_script("return window.status || '';")
                return "transferring data" not in status
            except Exception:
                return True  # Assume done if we can't check
        
        WebDriverWait(driver, timeout).until(check_status_bar)
        get_bootlick_logger().log_debug("Status bar is clear.", {"function": "wait_for_complete_load"})
        
        # Final health check
        if not is_driver_alive(driver):
            error_msg = "Driver died after status bar check"
            get_bootlick_logger().log_error(error_msg, None, {"function": "wait_for_complete_load"})
            raise ValueError(error_msg)
            
    except Exception as e:
        if not is_driver_alive(driver):
            error_msg = f"Driver died during wait_for_complete_load: {str(e)}"
            get_bootlick_logger().log_error(error_msg, e, {"function": "wait_for_complete_load"})
            raise ValueError(error_msg)
        raise


def fetch_json_from_rawdata_tab(driver, symbol: str, consolidated: bool) -> Optional[Dict]:
    """
    NOTE: This function is currently not functional.
    
    Investigation revealed that screener.in does not expose a rawdata-tab.
    The rawdata-tab reference in nse_company_info.py is for NSE data, not screener.in.
    
    This function is kept for potential future use if screener.in adds JSON API access.
    Currently, HTML parsing is the only available method for screener.in data extraction.
    
    Args:
        driver: Selenium WebDriver instance
        symbol: Company symbol
        consolidated: Whether to fetch consolidated data
        
    Returns:
        Always returns None - rawdata-tab doesn't exist on screener.in
    """
    # Screener.in doesn't have rawdata-tab - confirmed through testing
    # Always return None to fallback to HTML parsing
    return None


def parse_json_to_sections(json_data: Dict, symbol: str, company_name: str) -> Dict[str, pd.DataFrame]:
    """
    Parse JSON data from rawdata-tab into section DataFrames.
    
    This function attempts to extract the same sections (Balance Sheet, P&L, etc.)
    from JSON format. The JSON structure may vary, so this is a best-effort conversion.
    
    Args:
        json_data: JSON dictionary from rawdata-tab
        symbol: Company symbol
        company_name: Company name
        
    Returns:
        Dictionary mapping section names to DataFrames
    """
    sections = {
        "Balance Sheet": pd.DataFrame(),
        "Profit & Loss": pd.DataFrame(),
        "Quarterly Results": pd.DataFrame(),
        "Cash Flows": pd.DataFrame(),
        "Shareholding Pattern": pd.DataFrame(),
    }
    
    try:
        # Map JSON keys to section names (structure may vary)
        # Common keys in screener.in JSON: balance_sheet, profit_loss, cash_flow, etc.
        section_mapping = {
            "balance_sheet": "Balance Sheet",
            "balanceSheet": "Balance Sheet",
            "profit_loss": "Profit & Loss",
            "profitLoss": "Profit & Loss",
            "pnl": "Profit & Loss",
            "cash_flow": "Cash Flows",
            "cashFlow": "Cash Flows",
            "quarterly": "Quarterly Results",
            "quarterlyResults": "Quarterly Results",
            "shareholding": "Shareholding Pattern",
            "shareholdingPattern": "Shareholding Pattern",
        }
        
        # Try to extract sections from JSON
        for json_key, section_name in section_mapping.items():
            if json_key in json_data:
                try:
                    section_data = json_data[json_key]
                    # Convert to DataFrame format matching HTML parsing output
                    df = _convert_json_section_to_dataframe(section_data, symbol, company_name, section_name)
                    if not df.empty:
                        sections[section_name] = df
                        get_bootlick_logger().log_debug(
                            f"Extracted {section_name} from JSON for {symbol}",
                            {"symbol": symbol, "section": section_name, "rows": len(df), "function": "parse_json_to_sections"}
                        )
                except Exception as e:
                    get_bootlick_logger().log_warning(
                        f"Failed to parse {section_name} from JSON for {symbol}",
                        {"symbol": symbol, "section": section_name, "error": str(e), "function": "parse_json_to_sections"}
                    )
        
        # If JSON structure is different, try to find sections in nested structure
        if all(df.empty for df in sections.values()):
            # Try alternative JSON structure - look for common patterns
            for key, value in json_data.items():
                if isinstance(value, dict):
                    # Recursively search for section data
                    _extract_sections_from_nested_json(value, sections, symbol, company_name, section_mapping)
        
    except Exception as e:
        get_bootlick_logger().log_error(
            f"Error parsing JSON to sections for {symbol}",
            e,
            {"symbol": symbol, "function": "parse_json_to_sections"}
        )
    
    return sections


def _convert_json_section_to_dataframe(section_data: Dict, symbol: str, company_name: str, section_name: str) -> pd.DataFrame:
    """
    Convert a JSON section to DataFrame format matching HTML parsing output.
    
    Args:
        section_data: Section data from JSON
        symbol: Company symbol
        company_name: Company name
        section_name: Name of the section
        
    Returns:
        DataFrame with columns: Symbol, Company, Description, [date columns...]
    """
    rows_data = []
    
    try:
        # Handle different JSON structures
        if isinstance(section_data, list):
            # List of items
            for item in section_data:
                if isinstance(item, dict):
                    row = _extract_row_from_json_item(item, symbol, company_name)
                    if row:
                        rows_data.append(row)
        elif isinstance(section_data, dict):
            # Dictionary structure - could be keyed by description or date
            for key, value in section_data.items():
                if isinstance(value, dict):
                    # Value is a dict with dates/values
                    row = [symbol, company_name, key]
                    # Add date columns (assuming value dict has date keys)
                    for date_key, date_value in sorted(value.items()):
                        try:
                            if isinstance(date_value, (int, float)):
                                row.append(float(date_value))
                            else:
                                row.append(float("nan"))
                        except (ValueError, TypeError):
                            row.append(float("nan"))
                    rows_data.append(row)
                elif isinstance(value, (int, float)):
                    # Simple key-value pair
                    row = [symbol, company_name, key, float(value)]
                    rows_data.append(row)
        
        if rows_data:
            # Determine date columns from all rows
            max_cols = max(len(row) for row in rows_data) if rows_data else 3
            date_columns = []
            if max_cols > 3:
                # Generate date column names (this is a placeholder - actual dates should come from JSON)
                date_columns = [f"Col{i}" for i in range(3, max_cols)]
            
            df = pd.DataFrame(rows_data, columns=["Symbol", "Company", "Description"] + date_columns)
            return df
        
    except Exception as e:
        get_bootlick_logger().log_debug(
            f"Error converting JSON section to DataFrame",
            {"section": section_name, "error": str(e), "function": "_convert_json_section_to_dataframe"}
        )
    
    return pd.DataFrame()


def _extract_row_from_json_item(item: Dict, symbol: str, company_name: str) -> Optional[List]:
    """Extract a row from a JSON item dictionary."""
    try:
        description = item.get("description", item.get("name", item.get("label", "")))
        if not description:
            return None
        
        row = [symbol, company_name, description]
        
        # Extract date/value pairs
        for key, value in sorted(item.items()):
            if key not in ["description", "name", "label", "code"]:
                try:
                    if isinstance(value, (int, float)):
                        row.append(float(value))
                    else:
                        row.append(float("nan"))
                except (ValueError, TypeError):
                    row.append(float("nan"))
        
        return row if len(row) > 3 else None
    except Exception:
        return None


def _extract_sections_from_nested_json(data: Dict, sections: Dict, symbol: str, company_name: str, section_mapping: Dict):
    """Recursively extract sections from nested JSON structure."""
    for key, value in data.items():
        if key.lower() in section_mapping:
            section_name = section_mapping[key.lower()]
            if isinstance(value, (dict, list)):
                df = _convert_json_section_to_dataframe(value, symbol, company_name, section_name)
                if not df.empty:
                    sections[section_name] = df


# Robust `parse_symbol` function with proxy handling and retries
def parse_symbol(symbol, driver, consolidated, lenient_log_path=None):
    if driver is None:
        error_msg = f"Driver is None, cannot parse symbol {symbol}"
        get_bootlick_logger().log_error(error_msg, None, {"symbol": symbol, "function": "parse_symbol"})
        raise ValueError(error_msg)
    complete = True
    lenient_consolidated_used = False
    cash_flows_buttons_to_wait_for = [
        "//button[contains(@onclick, \"Company.showSchedule('Cash from Operating Activity', 'cash-flow', this)\")]",
        "//button[contains(@onclick, \"Company.showSchedule('Cash from Investing Activity', 'cash-flow', this)\")]",
        "//button[contains(@onclick, \"Company.showSchedule('Cash from Financing Activity', 'cash-flow', this)\")]",
    ]
    if consolidated:
        url = f"https://www.screener.in/company/{symbol}/consolidated/"
    else:
        url = f"https://www.screener.in/company/{symbol}/"
    try:
        # Note: JSON parsing not available - screener.in doesn't expose rawdata-tab
        # Proceeding directly with HTML parsing
        json_data = None
        if False:  # Disabled - rawdata-tab doesn't exist on screener.in
            json_data = fetch_json_from_rawdata_tab(driver, symbol, consolidated)
        if json_data:
            # Extract company name from JSON or page
            try:
                company_name = json_data.get("company_name", json_data.get("name", symbol))
                if not company_name or company_name == symbol:
                    # Fallback: get from page
                    driver.get(url)
                    wait_for_complete_load(driver)
                    page_source = get_page_source_safe(driver, symbol)
                    soup = BeautifulSoup(page_source, "html.parser")
                    company_name = soup.find("h1", class_="margin-0")
                    company_name = company_name.text.strip() if company_name else symbol
            except Exception:
                company_name = symbol
            
            # Parse JSON to sections
            sections = parse_json_to_sections(json_data, symbol, company_name)
            
            # Validate sections - check if we got meaningful data
            complete = True
            for section_name, df in sections.items():
                if df.empty:
                    get_bootlick_logger().log_debug(
                        f"Section {section_name} is empty from JSON for {symbol}, will try HTML parsing",
                        {"symbol": symbol, "section": section_name, "function": "parse_symbol"}
                    )
                    complete = False
                    break
                else:
                    # Apply COACode mapping and validation (same as HTML parsing)
                    df["COACode"] = df["Description"].map(get_dynamic_config().get(section_name, {}))
                    if section_name != "Shareholding Pattern":
                        df = df[df["COACode"].str.strip() != ""]
                    df["COACode"] = df["COACode"].fillna("").astype(str)
                    if (
                        not save_eligible(section_name, df)
                        or df.Description.str.endswith("+ -").any()
                        or df.Description.str.endswith("+").any()
                    ):
                        get_bootlick_logger().log_info(
                            f"Missing data for {symbol}:{section_name} from JSON. Will try HTML parsing",
                            {"symbol": symbol, "section": section_name, "function": "parse_symbol"},
                        )
                        complete = False
                        break
                    sections[section_name] = df
            
            if complete:
                get_bootlick_logger().log_info(
                    f"Successfully parsed {symbol} using JSON from rawdata-tab",
                    {"symbol": symbol, "function": "parse_symbol"}
                )
                return sections
            else:
                get_bootlick_logger().log_info(
                    f"JSON parsing incomplete for {symbol}, falling back to HTML parsing",
                    {"symbol": symbol, "function": "parse_symbol"}
                )
                # Continue to HTML parsing fallback
        
        # Fallback to HTML parsing (original method)
        get_bootlick_logger().log_debug(
            f"Using HTML parsing for {symbol}",
            {"symbol": symbol, "function": "parse_symbol"}
        )
        
        # Open the URL
        driver.get(url)
        wait_for_complete_load(driver)
        # Check driver health after page load
        if not is_driver_alive(driver):
            error_msg = f"Driver died after loading page for {symbol}"
            get_bootlick_logger().log_error(error_msg, None, {"symbol": symbol, "function": "parse_symbol"})
            raise ValueError(error_msg)
        scroll_to_bottom_multiple_times(driver)
        # Wait for the page to load with health checks
        if not is_driver_alive(driver):
            error_msg = f"Driver died before waiting for buttons for {symbol}"
            get_bootlick_logger().log_error(error_msg, None, {"symbol": symbol, "function": "parse_symbol"})
            raise ValueError(error_msg)
        
        try:
            WebDriverWait(driver, 10).until(
                lambda d: is_driver_alive(d) and EC.presence_of_element_located((By.XPATH, "//button[contains(@onclick, 'Company.showSchedule')]"))(d)
            )
        except Exception as e:
            if not is_driver_alive(driver):
                error_msg = f"Driver died while waiting for buttons for {symbol}"
                get_bootlick_logger().log_error(error_msg, e, {"symbol": symbol, "function": "parse_symbol"})
                raise ValueError(error_msg)
            raise
        
        for button_xpath in cash_flows_buttons_to_wait_for:
            try:
                if not is_driver_alive(driver):
                    break
                button = WebDriverWait(driver, 15).until(EC.presence_of_element_located((By.XPATH, button_xpath)))
            except Exception as button_error:
                if not is_driver_alive(driver):
                    error_msg = f"Driver died while waiting for cash flow button for {symbol}"
                    get_bootlick_logger().log_error(error_msg, button_error, {"symbol": symbol, "button_xpath": button_xpath, "function": "parse_symbol"})
                    raise ValueError(error_msg)
                get_bootlick_logger().log_debug(
                    f"Failed to load button for {symbol}: {button_xpath}",
                    {"symbol": symbol, "button_xpath": button_xpath, "function": "parse_symbol"},
                )

        # Click on all expandable rows using button elements with specific onclick attributes
        # Add delays between clicks to avoid rate limiting
        expandable_buttons = driver.find_elements(By.XPATH, "//button[contains(@onclick, 'Company.showSchedule')]")
        for idx, button in enumerate(expandable_buttons):
            try:
                WebDriverWait(driver, 10).until(EC.element_to_be_clickable(button)).click()
                # Add delay after clicking, especially for cash flow buttons that trigger API calls
                # Check if this is a cash flow button by checking onclick attribute
                onclick = button.get_attribute("onclick") or ""
                if "cash-flow" in onclick.lower():
                    delay = random.uniform(3, 6)  # Longer delay for cash flow API calls
                else:
                    delay = random.uniform(1, 3)  # Shorter delay for other buttons
                time.sleep(delay)
            except Exception as e:
                get_bootlick_logger().log_debug(
                    f"Failed to click button: {e}", {"error_type": type(e).__name__, "function": "parse_symbol"}
                )

        wait_for_complete_load(driver)
        if not is_driver_alive(driver):
            error_msg = f"Driver died after first round of button clicks for {symbol}"
            get_bootlick_logger().log_error(error_msg, None, {"symbol": symbol, "function": "parse_symbol"})
            raise ValueError(error_msg)
        
        # Wait for AJAX to complete after button clicks (buttons trigger API calls)
        wait_for_ajax_complete(driver, timeout=10)
        
        scroll_to_bottom_multiple_times(driver)
        if not is_driver_alive(driver):
            error_msg = f"Driver died after scrolling for {symbol}"
            get_bootlick_logger().log_error(error_msg, None, {"symbol": symbol, "function": "parse_symbol"})
            raise ValueError(error_msg)
        
        expandable_buttons = driver.find_elements(By.XPATH, "//button[contains(@onclick, 'Company.showSchedule')]")
        for idx, button in enumerate(expandable_buttons):
            try:
                if not is_driver_alive(driver):
                    error_msg = f"Driver died during second round of button clicking for {symbol} at index {idx}"
                    get_bootlick_logger().log_error(error_msg, None, {"symbol": symbol, "button_index": idx, "function": "parse_symbol"})
                    raise ValueError(error_msg)
                
                WebDriverWait(driver, 10).until(EC.element_to_be_clickable(button)).click()
                # Optimized delays - reduced for speed
                onclick = button.get_attribute("onclick") or ""
                if "cash-flow" in onclick.lower():
                    delay = random.uniform(2, 4)  # Reduced delay for cash flow API calls
                else:
                    delay = random.uniform(0.5, 2)  # Reduced delay for other buttons
                time.sleep(delay)
            except Exception as e:
                get_bootlick_logger().log_debug(
                    f"Failed to click button: {e}", {"error_type": type(e).__name__, "function": "parse_symbol"}
                )

        # Click on Shareholding Pattern expandable buttons specifically
        try:
            if not is_driver_alive(driver):
                error_msg = f"Driver died before shareholding section for {symbol}"
                get_bootlick_logger().log_error(error_msg, None, {"symbol": symbol, "function": "parse_symbol"})
                raise ValueError(error_msg)
            
            shareholding_section = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, "quarterly-shp"))
            )
            shareholding_buttons = shareholding_section.find_elements(
                By.XPATH, ".//button[contains(@onclick, 'Company.showShareholders')]"
            )
            for button in shareholding_buttons:
                if not is_driver_alive(driver):
                    error_msg = f"Driver died during shareholding button clicking for {symbol}"
                    get_bootlick_logger().log_error(error_msg, None, {"symbol": symbol, "function": "parse_symbol"})
                    raise ValueError(error_msg)
                WebDriverWait(driver, 10).until(EC.element_to_be_clickable(button)).click()
                # Optimized delay - reduced from 1-3s to 0.5-1.5s
                delay = random.uniform(0.5, 1.5)
                time.sleep(delay)
            wait_for_complete_load(driver)
            if not is_driver_alive(driver):
                error_msg = f"Driver died after shareholding wait_for_complete_load for {symbol}"
                get_bootlick_logger().log_error(error_msg, None, {"symbol": symbol, "function": "parse_symbol"})
                raise ValueError(error_msg)
            
            # Wait for AJAX to complete after shareholding button clicks
            wait_for_ajax_complete(driver, timeout=10)
            
            scroll_to_bottom_multiple_times(driver)
            shareholding_buttons = shareholding_section.find_elements(
                By.XPATH, ".//button[contains(@onclick, 'Company.showShareholders')]"
            )
            for button in shareholding_buttons:
                if not is_driver_alive(driver):
                    error_msg = f"Driver died during second shareholding button clicking for {symbol}"
                    get_bootlick_logger().log_error(error_msg, None, {"symbol": symbol, "function": "parse_symbol"})
                    raise ValueError(error_msg)
                WebDriverWait(driver, 10).until(EC.element_to_be_clickable(button)).click()
                # Optimized delay - reduced from 1-3s to 0.5-1.5s
                delay = random.uniform(0.5, 1.5)
                time.sleep(delay)
        except Exception as e:
            get_bootlick_logger().log_debug(
                f"Failed to click Shareholding Pattern button: {e}",
                {"error_type": type(e).__name__, "function": "parse_symbol"},
            )

        # Final wait to ensure all dynamic content is fully rendered before parsing
        # This is critical - HTML parsing will fail if done while content is still loading
        get_bootlick_logger().log_debug(
            f"Waiting for all dynamic content to finish rendering before parsing",
            {"symbol": symbol, "function": "parse_symbol"}
        )
        
        # Wait for AJAX/network to be idle
        wait_for_ajax_complete(driver, timeout=15)
        
        # Wait for tables to be rendered with actual data
        if not wait_for_tables_rendered(driver, symbol, timeout=20):
            get_bootlick_logger().log_warning(
                f"Tables may not be fully rendered for {symbol}, proceeding anyway",
                {"symbol": symbol, "function": "parse_symbol"}
            )
        
        # Additional wait to ensure any final rendering completes
        time.sleep(2)  # Give a final moment for any last-minute rendering
        
        # Final health check before parsing
        if not is_driver_alive(driver):
            error_msg = f"Driver died before parsing HTML for {symbol}"
            get_bootlick_logger().log_error(error_msg, None, {"symbol": symbol, "function": "parse_symbol"})
            raise ValueError(error_msg)
        
        # Get page source and parse it with BeautifulSoup
        get_bootlick_logger().log_debug(
            f"Parsing page HTML with BeautifulSoup",
            {"symbol": symbol, "function": "parse_symbol"}
        )
        # Use safe page source retrieval with health checks
        page_source = get_page_source_safe(driver, symbol)
        soup = BeautifulSoup(page_source, "html.parser")

        # Extract company name with multiple fallback strategies
        company_name = symbol  # Default fallback
        try:
            company_name_elem = soup.find("h1", class_="margin-0")
            if company_name_elem:
                company_name = company_name_elem.text.strip()
                get_bootlick_logger().log_debug(
                    f"Extracted company name: {company_name}",
                    {"symbol": symbol, "company_name": company_name, "function": "parse_symbol"}
                )
            else:
                # Try alternative selectors
                company_name_elem = soup.find("h1")
                if company_name_elem:
                    company_name = company_name_elem.text.strip()
                    get_bootlick_logger().log_debug(
                        f"Extracted company name using alternative selector: {company_name}",
                        {"symbol": symbol, "company_name": company_name, "function": "parse_symbol"}
                    )
                else:
                    get_bootlick_logger().log_warning(
                        f"Could not extract company name for {symbol}, using symbol as fallback",
                        {"symbol": symbol, "function": "parse_symbol"}
                    )
        except Exception as e:
            get_bootlick_logger().log_warning(
                f"Error extracting company name for {symbol}",
                {"symbol": symbol, "error": str(e), "function": "parse_symbol"}
            )
        
        # Check for consolidated data mismatch
        try:
            consolidated_found = soup.body.find_all(string=lambda text: text and "consolidated" in text.lower())
            if not consolidated and consolidated_found:
                consolidated_lenient = bool(get_dynamic_config().get("consolidated_mismatch_lenient", True))
                if consolidated_lenient:
                    lenient_consolidated_used = True
                    get_bootlick_logger().log_warning(
                        f"Consolidated data found while attempting to parse unconsolidated {symbol} (lenient allow)",
                        {
                            "symbol": symbol,
                            "consolidated_found": len(consolidated_found),
                            "function": "parse_symbol",
                            "lenient_consolidated": consolidated_lenient,
                        },
                    )
                else:
                    get_bootlick_logger().log_error(
                        f"Consolidated data found while attempting to parse unconsolidated {symbol}",
                        None,
                        {"symbol": symbol, "consolidated_found": len(consolidated_found), "function": "parse_symbol"},
                    )
                    return {}
        except Exception as e:
            get_bootlick_logger().log_debug(
                f"Could not check for consolidated data mismatch",
                {"symbol": symbol, "error": str(e), "function": "parse_symbol"}
            )

        # Function to extract table data with child rows - improved with error handling
        def extract_table_data(table, section_name: str):
            try:
                headers = [th.text.strip() for th in table.find_all("th")]
                if not headers:
                    get_bootlick_logger().log_warning(
                        f"No headers found in table for {section_name}",
                        {"symbol": symbol, "section": section_name, "function": "extract_table_data"}
                    )
                    return pd.DataFrame()
                
                get_bootlick_logger().log_debug(
                    f"Extracting table data: {len(headers)} headers, {len(table.find_all('tr'))} rows",
                    {"symbol": symbol, "section": section_name, "header_count": len(headers), "row_count": len(table.find_all("tr")), "function": "extract_table_data"}
                )
                
                rows_data = []
                rows_processed = 0
                rows_skipped = 0
                child_rows_processed = 0
                
                for row_idx, row in enumerate(table.find_all("tr")[1:], start=1):  # Skip header row
                    try:
                        row_data = [td.text.strip() for td in row.find_all("td")]
                        if not row_data:
                            rows_skipped += 1
                            continue
                        
                        # Validate row has minimum expected columns
                        if len(row_data) < 2:
                            get_bootlick_logger().log_debug(
                                f"Row {row_idx} has insufficient columns, skipping",
                                {"symbol": symbol, "section": section_name, "row_index": row_idx, "column_count": len(row_data), "function": "extract_table_data"}
                            )
                            rows_skipped += 1
                            continue
                        
                        row_data.insert(0, company_name)
                        # Clean description (index 1 after inserting company_name)
                        if len(row_data) > 1:
                            row_data[1] = row_data[1].replace("\xa0", " ").strip()
                            # Add " -" suffix if needed (for parent rows)
                            if (
                                len(row_data) > 1
                                and not any("padding-left" in td.get("style", "") for td in row.find_all("td"))
                                and not row_data[1].endswith("-")
                            ):
                                row_data[1] += " -"
                        row_data.insert(0, symbol)
                        
                        # Convert numeric columns
                        for i in range(3, len(row_data)):
                            try:
                                cleaned_value = row_data[i].replace(",", "").replace("%", "").strip()
                                if cleaned_value:
                                    row_data[i] = float(cleaned_value)
                                else:
                                    row_data[i] = float("nan")
                            except (ValueError, AttributeError):
                                row_data[i] = float("nan")
                        
                        rows_data.append(row_data)
                        rows_processed += 1
                        
                        # Check if the row has child rows
                        child_rows = row.find_next("tr", class_="child-row")
                        while child_rows:
                            try:
                                child_data = [td.text.strip() for td in child_rows.find_all("td")]
                                if child_data:
                                    child_data.insert(0, company_name)
                                    child_data.insert(0, symbol)
                                    for i in range(3, len(child_data)):
                                        try:
                                            cleaned_value = child_data[i].replace(",", "").strip()
                                            if cleaned_value:
                                                child_data[i] = float(cleaned_value)
                                            else:
                                                child_data[i] = float("nan")
                                        except (ValueError, AttributeError):
                                            child_data[i] = float("nan")
                                    rows_data.append(child_data)
                                    child_rows_processed += 1
                            except Exception as e:
                                get_bootlick_logger().log_debug(
                                    f"Error processing child row",
                                    {"symbol": symbol, "section": section_name, "row_index": row_idx, "error": str(e), "function": "extract_table_data"}
                                )
                            
                            child_rows = child_rows.find_next_sibling("tr", class_="child-row")
                            
                    except Exception as e:
                        rows_skipped += 1
                        get_bootlick_logger().log_debug(
                            f"Error processing row {row_idx}",
                            {"symbol": symbol, "section": section_name, "row_index": row_idx, "error": str(e), "function": "extract_table_data"}
                        )
                        continue
                
                if not rows_data:
                    get_bootlick_logger().log_warning(
                        f"No data rows extracted from table",
                        {"symbol": symbol, "section": section_name, "rows_processed": rows_processed, "rows_skipped": rows_skipped, "function": "extract_table_data"}
                    )
                    return pd.DataFrame()
                
                # Create DataFrame
                try:
                    df = pd.DataFrame(rows_data, columns=["Symbol", "Company", "Description"] + headers[1:])
                    get_bootlick_logger().log_info(
                        f"Extracted table data successfully",
                        {
                            "symbol": symbol,
                            "section": section_name,
                            "rows": len(df),
                            "columns": len(df.columns),
                            "parent_rows": rows_processed,
                            "child_rows": child_rows_processed,
                            "skipped": rows_skipped,
                            "function": "extract_table_data"
                        }
                    )
                    return df
                except Exception as e:
                    get_bootlick_logger().log_error(
                        f"Failed to create DataFrame from extracted data",
                        e,
                        {"symbol": symbol, "section": section_name, "rows_count": len(rows_data), "headers_count": len(headers), "function": "extract_table_data"}
                    )
                    return pd.DataFrame()
                    
            except Exception as e:
                get_bootlick_logger().log_error(
                    f"Error in extract_table_data",
                    e,
                    {"symbol": symbol, "section": section_name, "function": "extract_table_data"}
                )
                return pd.DataFrame()

        def extract_shareholding_table(table, section_name: str):
            try:
                headers = [th.text.strip() for th in table.find_all("th")]
                if not headers:
                    get_bootlick_logger().log_warning(
                        f"No headers found in shareholding table",
                        {"symbol": symbol, "section": section_name, "function": "extract_shareholding_table"}
                    )
                    return pd.DataFrame()
                
                get_bootlick_logger().log_debug(
                    f"Extracting shareholding table: {len(headers)} headers, {len(table.find_all('tr'))} rows",
                    {"symbol": symbol, "section": section_name, "header_count": len(headers), "row_count": len(table.find_all("tr")), "function": "extract_shareholding_table"}
                )
                
                rows_data = []
                parent_category = None  # To track the current parent category
                rows_processed = 0
                rows_skipped = 0

                for row_idx, row in enumerate(table.find_all("tr")[1:], start=1):
                    try:
                        row_data = [td.text.strip() for td in row.find_all("td")]
                        if not row_data:
                            rows_skipped += 1
                            continue
                        
                        # Check if it's a parent row with a button (expandable)
                        button = row.find("button")
                        if button:
                            parent_category = button.text.replace("\xa0", " ").strip().rstrip("-").strip()
                            description = parent_category
                        else:
                            # For sub-rows, prepend the parent category to the description
                            description = row_data[0].strip().replace("\xa0", " ").strip().rstrip("-").strip()
                            if parent_category:
                                description = f"{parent_category}: {description}"
                        
                        row_data.insert(0, symbol)
                        row_data.insert(1, company_name)
                        if len(row_data) > 2:
                            row_data[2] = description
                        
                        # Convert numeric columns
                        for i in range(3, len(row_data)):
                            try:
                                cleaned_value = row_data[i].replace(",", "").replace("%", "").strip()
                                if cleaned_value:
                                    row_data[i] = float(cleaned_value)
                                else:
                                    row_data[i] = float("nan")
                            except (ValueError, AttributeError):
                                row_data[i] = float("nan")
                        
                        rows_data.append(row_data)
                        rows_processed += 1
                        
                    except Exception as e:
                        rows_skipped += 1
                        get_bootlick_logger().log_debug(
                            f"Error processing shareholding row {row_idx}",
                            {"symbol": symbol, "section": section_name, "row_index": row_idx, "error": str(e), "function": "extract_shareholding_table"}
                        )
                        continue
                
                if not rows_data:
                    get_bootlick_logger().log_warning(
                        f"No data rows extracted from shareholding table",
                        {"symbol": symbol, "section": section_name, "rows_processed": rows_processed, "rows_skipped": rows_skipped, "function": "extract_shareholding_table"}
                    )
                    return pd.DataFrame()
                
                # Sort headers by date
                try:
                    sorted_headers = sorted(headers[1:], key=lambda x: datetime.strptime(x, "%b %Y"))
                except Exception as e:
                    get_bootlick_logger().log_warning(
                        f"Error sorting headers by date, using original order",
                        {"symbol": symbol, "section": section_name, "error": str(e), "function": "extract_shareholding_table"}
                    )
                    sorted_headers = headers[1:]
                
                # Create DataFrame
                try:
                    df = pd.DataFrame(rows_data, columns=["Symbol", "Company", "Description"] + sorted_headers)
                    # Handle duplicate descriptions by summing values
                    df = df.groupby(["Symbol", "Company", "Description"], as_index=False).sum(numeric_only=True)
                    
                    get_bootlick_logger().log_info(
                        f"Extracted shareholding table data successfully",
                        {
                            "symbol": symbol,
                            "section": section_name,
                            "rows": len(df),
                            "columns": len(df.columns),
                            "rows_processed": rows_processed,
                            "skipped": rows_skipped,
                            "function": "extract_shareholding_table"
                        }
                    )
                    return df
                except Exception as e:
                    get_bootlick_logger().log_error(
                        f"Failed to create DataFrame from shareholding data",
                        e,
                        {"symbol": symbol, "section": section_name, "rows_count": len(rows_data), "function": "extract_shareholding_table"}
                    )
                    return pd.DataFrame()
                    
            except Exception as e:
                get_bootlick_logger().log_error(
                    f"Error in extract_shareholding_table",
                    e,
                    {"symbol": symbol, "section": section_name, "function": "extract_shareholding_table"}
                )
                return pd.DataFrame()

        # Extract balance sheet, P&L, cash flows, shareholding pattern, and quarterly results sections
        sections = {
            "Balance Sheet": pd.DataFrame(),
            "Profit & Loss": pd.DataFrame(),
            "Quarterly Results": pd.DataFrame(),
            "Cash Flows": pd.DataFrame(),
            "Shareholding Pattern": pd.DataFrame(),
        }

        get_bootlick_logger().log_info(
            f"Extracting financial sections from HTML",
            {"symbol": symbol, "sections_to_find": list(sections.keys()), "function": "parse_symbol"}
        )
        
        for section_name, df in sections.items():
            get_bootlick_logger().log_debug(
                f"Processing section: {section_name}",
                {"symbol": symbol, "section": section_name, "function": "parse_symbol"}
            )
            
            # Try multiple ways to find section header
            section = None
            section_selectors = [
                ("h2", {"text": section_name}),
                ("h2", {"string": section_name}),
                ("h2", {}),  # Find any h2 and check text
            ]
            
            for tag, attrs in section_selectors:
                try:
                    if "text" in attrs or "string" in attrs:
                        section = soup.find(tag, attrs)
                    else:
                        # Find all h2 and check text
                        for h2 in soup.find_all(tag):
                            if h2.text.strip() == section_name:
                                section = h2
                                break
                    if section:
                        break
                except Exception as e:
                    get_bootlick_logger().log_debug(
                        f"Error with selector {tag}/{attrs}",
                        {"symbol": symbol, "section": section_name, "error": str(e), "function": "parse_symbol"}
                    )
                    continue
            
            if section:
                get_bootlick_logger().log_debug(
                    f"Found section header for {section_name}",
                    {"symbol": symbol, "section": section_name, "function": "parse_symbol"}
                )
                
                # Try to find table - try multiple strategies
                table = None
                table_selectors = [
                    lambda s: s.find_next("table"),
                    lambda s: s.find_next_sibling("table"),
                    lambda s: s.parent.find("table") if s.parent else None,
                ]
                
                for selector in table_selectors:
                    try:
                        table = selector(section)
                        if table:
                            break
                    except:
                        continue
                
                if table:
                    get_bootlick_logger().log_debug(
                        f"Found table for {section_name}",
                        {"symbol": symbol, "section": section_name, "function": "parse_symbol"}
                    )
                    
                    try:
                        if section_name != "Shareholding Pattern":
                            extracted_df = extract_table_data(table, section_name)
                        else:
                            extracted_df = extract_shareholding_table(table, section_name)
                        
                        if extracted_df.empty:
                            get_bootlick_logger().log_warning(
                                f"Extracted DataFrame is empty for {section_name}",
                                {"symbol": symbol, "section": section_name, "function": "parse_symbol"}
                            )
                            complete = False
                            continue
                        
                        # Apply COACode mapping
                        extracted_df["COACode"] = extracted_df["Description"].map(
                            get_dynamic_config().get(section_name, {})
                        )
                        
                        if section_name != "Shareholding Pattern":
                            before_filter = len(extracted_df)
                            extracted_df = extracted_df[extracted_df["COACode"].str.strip() != ""]
                            after_filter = len(extracted_df)
                            if before_filter != after_filter:
                                get_bootlick_logger().log_debug(
                                    f"Filtered rows without COACode",
                                    {"symbol": symbol, "section": section_name, "before": before_filter, "after": after_filter, "function": "parse_symbol"}
                                )
                        
                        extracted_df["COACode"] = extracted_df["COACode"].fillna("").astype(str)
                        
                        # Validate extracted data
                        has_incomplete_markers = (
                            extracted_df.Description.str.endswith("+ -").any()
                            or extracted_df.Description.str.endswith("+").any()
                        )
                        is_save_eligible = save_eligible(section_name, extracted_df)
                        
                        if not is_save_eligible or has_incomplete_markers:
                            get_bootlick_logger().log_info(
                                f"Data validation failed for {section_name}",
                                {
                                    "symbol": symbol,
                                    "section": section_name,
                                    "rows": len(extracted_df),
                                    "save_eligible": is_save_eligible,
                                    "has_incomplete_markers": has_incomplete_markers,
                                    "function": "parse_symbol"
                                },
                            )
                            complete = False
                        else:
                            if complete:
                                sections[section_name] = pd.concat([df, extracted_df], ignore_index=True)
                                get_bootlick_logger().log_info(
                                    f"Successfully extracted {section_name}",
                                    {
                                        "symbol": symbol,
                                        "section": section_name,
                                        "rows": len(sections[section_name]),
                                        "columns": len(sections[section_name].columns),
                                        "function": "parse_symbol"
                                    }
                                )
                    except Exception as e:
                        get_bootlick_logger().log_error(
                            f"Error extracting data from {section_name} table",
                            e,
                            {"symbol": symbol, "section": section_name, "function": "parse_symbol"}
                        )
                        complete = False
                else:
                    get_bootlick_logger().log_warning(
                        f"Section header found but no table found for {section_name}",
                        {"symbol": symbol, "section": section_name, "function": "parse_symbol"},
                    )
                    complete = False
            else:
                get_bootlick_logger().log_warning(
                    f"Section header not found for {section_name}",
                    {"symbol": symbol, "section": section_name, "function": "parse_symbol"},
                )
                complete = False
        # Summary of extracted sections
        extracted_sections = {name: df for name, df in sections.items() if not df.empty}
        missing_sections = [name for name, df in sections.items() if df.empty]
        
        if complete:
            get_bootlick_logger().log_info(
                f"Successfully completed parsing all sections for {symbol}",
                {
                    "symbol": symbol,
                    "sections_extracted": list(extracted_sections.keys()),
                    "total_rows": sum(len(df) for df in extracted_sections.values()),
                    "function": "parse_symbol"
                }
            )
            if lenient_consolidated_used:
                log_path = (
                    lenient_log_path
                    or os.path.expanduser(
                        get_dynamic_config().get("consolidated_lenient_log", "~/logs/consolidated_lenient.txt")
                    )
                )
                try:
                    os.makedirs(os.path.dirname(log_path), exist_ok=True)
                    with open(log_path, "a") as f:
                        f.write(f"{symbol}\n")
                    get_bootlick_logger().log_info(
                        f"Recorded lenient consolidated save for {symbol}",
                        {"symbol": symbol, "log_file": log_path, "function": "parse_symbol"},
                    )
                except Exception as e:
                    get_bootlick_logger().log_warning(
                        f"Failed to append lenient consolidated symbol to log file for {symbol}",
                        {"symbol": symbol, "log_file": log_path, "error": str(e), "function": "parse_symbol"},
                    )
            return sections
        else:
            get_bootlick_logger().log_warning(
                f"Incomplete parsing for {symbol} - some sections missing or invalid",
                {
                    "symbol": symbol,
                    "sections_extracted": list(extracted_sections.keys()),
                    "sections_missing": missing_sections,
                    "total_rows": sum(len(df) for df in extracted_sections.values()),
                    "function": "parse_symbol"
                }
            )
            return {}

    except Exception as e:
        # Check if driver is still alive before trying to access it
        driver_alive = is_driver_alive(driver)
        get_bootlick_logger().log_error(
            f"Failed to parse {symbol}",
            e,
            {"symbol": symbol, "driver_alive": driver_alive, "function": "parse_symbol"}
        )
        if driver and driver_alive:
            try:
                driver.quit()
            except Exception:
                pass  # Driver might have died during quit
        raise


def scroll_to_bottom_multiple_times(driver, max_scrolls=5):
    """Scroll to the bottom of the page multiple times."""
    if driver is None:
        error_msg = "Driver is None, cannot scroll to bottom"
        get_bootlick_logger().log_error(error_msg, None, {"function": "scroll_to_bottom_multiple_times"})
        raise ValueError(error_msg)
    for i in range(max_scrolls):
        get_bootlick_logger().log_debug(
            f"Scrolling attempt {i + 1}...", {"scroll_attempt": i + 1, "function": "scroll_to_bottom_multiple_times"}
        )
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(5)  # Allow time for content to load

        # Check if more content has loaded
        new_height = driver.execute_script("return document.body.scrollHeight;")
        if new_height == driver.execute_script("return window.pageYOffset + window.innerHeight;"):
            get_bootlick_logger().log_debug(
                "Reached the bottom of the page.", {"function": "scroll_to_bottom_multiple_times"}
            )
            break


# Function to attempt parsing with timeout and proxy retry
def parse_with_timeout(symbol, driver, consolidated, timeout=120, lenient_log_path=None):
    """
    Parse symbol with timeout protection.
    
    Args:
        symbol: Symbol to parse
        driver: WebDriver instance
        consolidated: Whether to fetch consolidated data
        timeout: Timeout in seconds (increased to 120s to accommodate rendering waits)
    """
    if driver is None:
        error_msg = f"Driver is None, cannot parse symbol {symbol} with timeout"
        get_bootlick_logger().log_error(error_msg, None, {"symbol": symbol, "function": "parse_with_timeout"})
        raise ValueError(error_msg)
    
    # Check driver health before starting
    if not is_driver_alive(driver):
        error_msg = f"Driver is dead before parsing {symbol}"
        get_bootlick_logger().log_error(error_msg, None, {"symbol": symbol, "function": "parse_with_timeout"})
        raise ValueError(error_msg)
    
    with concurrent.futures.ThreadPoolExecutor() as executor:
        future = executor.submit(parse_symbol, symbol, driver, consolidated, lenient_log_path)
        try:
            result = future.result(timeout=timeout)  # Increased timeout to 90 seconds
            # Check driver health after parsing completes
            if not is_driver_alive(driver):
                get_bootlick_logger().log_warning(
                    f"Driver died during parsing of {symbol}, but parsing completed",
                    {"symbol": symbol, "function": "parse_with_timeout"}
                )
            return result  # If parsing is successful, move to next symbol
        except concurrent.futures.TimeoutError:
            # Check if driver is still alive when timeout occurs
            driver_alive = is_driver_alive(driver)
            get_bootlick_logger().log_debug(
                f"Timeout reached for {symbol} after {timeout}s. Driver may be hung. Driver alive: {driver_alive}", 
                {"symbol": symbol, "timeout": timeout, "driver_alive": driver_alive, "function": "parse_with_timeout"}
            )
            if driver is not None and driver_alive:
                try:
                    driver.quit()
                except Exception:
                    pass
            kill_firefox_processes()
            raise
        except Exception as e:
            # Check driver health on any exception
            driver_alive = is_driver_alive(driver)
            if not driver_alive:
                get_bootlick_logger().log_error(
                    f"Driver died during parsing of {symbol}",
                    e,
                    {"symbol": symbol, "function": "parse_with_timeout"}
                )
            raise


def kill_firefox_processes():
    for process in psutil.process_iter():
        try:
            if process.name().lower() in ["firefox", "geckodriver"]:
                process.kill()
        except psutil.NoSuchProcess:
            continue


def symbol_exists(symbol: str, data_folder: str):
    """
    Check if a file for the given symbol exists in the specified data folder.

    Args:
        symbol (str): The symbol to check.
        data_folder (str): The folder where the data files are stored.

    Returns:
        bool
    """
    filename = f"Cash Flows_{symbol}.rds"
    file_path = os.path.join(data_folder, filename)
    return os.path.exists(file_path)


# Initialize a global set to track unique resource URLs and a cumulative total
cumulative_data_consumed = 0
seen_resources = set()


def log_data_consumed(driver):
    """
    Logs the total data consumed during the current WebDriver session across all page loads.

    Args:
        driver: The Selenium WebDriver instance.

    Returns:
        int: Total data consumed in bytes during the session.
    """
    global cumulative_data_consumed, seen_resources
    if driver is None:
        get_bootlick_logger().log_warning("Driver is None, cannot log data consumed", {"function": "log_data_consumed"})
        return 0
    try:
        # Get the performance entries for the current page
        performance_data = driver.execute_script("return performance.getEntriesByType('resource');")

        # Calculate the data consumed for new resources only
        session_data_consumed = 0
        for entry in performance_data:
            resource_url = entry.get("name", "")
            transfer_size = entry.get("transferSize", 0)
            if resource_url not in seen_resources:
                seen_resources.add(resource_url)
                session_data_consumed += transfer_size

        # Add the session data to the cumulative total
        cumulative_data_consumed += session_data_consumed

        # Log the data consumed for the current session and cumulative total
        get_bootlick_logger().log_info(
            f"Data consumed in this session: {session_data_consumed / 1024:.2f} KB",
            {"session_data_consumed_kb": session_data_consumed / 1024, "function": "log_data_consumed"},
        )
        get_bootlick_logger().log_info(
            f"Cumulative data consumed so far: {cumulative_data_consumed / 1024:.2f} KB",
            {"cumulative_data_consumed_kb": cumulative_data_consumed / 1024, "function": "log_data_consumed"},
        )

        return session_data_consumed
    except Exception as e:
        get_bootlick_logger().log_error("Failed to log data consumed", e, {"function": "log_data_consumed"})
        return 0


# Main function to process symbols with retry logic and intermediate saving
def _remove_symbol_from_incomplete_file(incomplete_file_path: Optional[str], symbol: str) -> None:
    """
    Remove a successfully processed symbol from the incomplete symbols file.
    
    Args:
        incomplete_file_path: Path to the incomplete symbols file, or None to skip.
        symbol: Symbol to remove from the file.
    """
    if not incomplete_file_path:
        return
    
    try:
        file_path = os.path.expanduser(incomplete_file_path)
        if not os.path.exists(file_path):
            return
        
        # Read all symbols
        with open(file_path, "r") as file:
            remaining_symbols = [line.strip() for line in file.readlines() if line.strip()]
        
        # Remove the processed symbol
        if symbol in remaining_symbols:
            remaining_symbols.remove(symbol)
            
            # Write back the remaining symbols
            with open(file_path, "w") as file:
                for sym in remaining_symbols:
                    file.write(f"{sym}\n")
            
            get_bootlick_logger().log_debug(
                f"Removed {symbol} from incomplete symbols file",
                {"symbol": symbol, "remaining_count": len(remaining_symbols), "function": "_remove_symbol_from_incomplete_file"}
            )
    except Exception as e:
        # Don't fail the main process if file update fails
        get_bootlick_logger().log_warning(
            f"Failed to update incomplete symbols file for {symbol}",
            e,
            {"symbol": symbol, "file_path": incomplete_file_path, "function": "_remove_symbol_from_incomplete_file"}
        )


def process_symbols(
    proxy_source, proxy_user, proxy_pass, api_key, driver_path, symbols, data_folder, refresh, incomplete_check, incomplete_file_path=None
) -> List[str]:
    driver = None
    unsuccessul_symbols = []
    saved_files = []  # Track files saved during this execution
    try:
        driver = get_session_or_driver(
            url_to_test="https://screener.in",
            get_session=False,
            headless=False,
            proxy_source=proxy_source,
            api_key=api_key,
            proxy_user=proxy_user,
            proxy_password=proxy_pass,
            webdriver_path=driver_path,
        )
        if driver is None:
            error_msg = "Failed to initialize driver. get_session_or_driver returned None."
            get_bootlick_logger().log_error(error_msg, None, {"function": "process_symbols"})
            raise RuntimeError(error_msg)
        os.makedirs(data_folder, exist_ok=True)

        # Track symbols processed with current driver for periodic recreation
        symbols_processed_with_driver = 0
        DRIVER_RECREATE_INTERVAL = 50  # Recreate driver every 50 symbols to prevent crashes
        
        for symbol in symbols:
            if not refresh and symbol_exists(symbol, data_folder):
                if (not incomplete_check) or (
                    incomplete_check
                    and not (
                        readRDS(f"{data_folder}/Balance Sheet_{symbol}.rds").iloc[:, -2].isna().any()
                        or readRDS(f"{data_folder}/Cash Flows_{symbol}.rds").iloc[:, -2].isna().any()
                    )
                ):
                    get_bootlick_logger().log_debug(
                        f"Skipping already processed symbol: {symbol}",
                        {"symbol": symbol, "function": "process_symbols"},
                    )
                    # Remove from incomplete file since it's already processed
                    _remove_symbol_from_incomplete_file(incomplete_file_path, symbol)
                    continue
            
            # Periodic driver recreation to prevent crashes from accumulating
            if symbols_processed_with_driver >= DRIVER_RECREATE_INTERVAL:
                get_bootlick_logger().log_info(
                    f"Recreating driver after {symbols_processed_with_driver} symbols to prevent crashes",
                    {"symbols_processed": symbols_processed_with_driver, "function": "process_symbols"}
                )
                if driver:
                    try:
                        driver.quit()
                    except Exception:
                        pass
                driver = get_session_or_driver(
                    url_to_test="https://screener.in",
                    get_session=False,
                    headless=False,
                    proxy_source=proxy_source,
                    api_key=api_key,
                    proxy_user=proxy_user,
                    proxy_password=proxy_pass,
                    webdriver_path=driver_path,
                )
                if driver is None:
                    error_msg = "Failed to recreate driver. get_session_or_driver returned None."
                    get_bootlick_logger().log_error(error_msg, None, {"function": "process_symbols"})
                    raise RuntimeError(error_msg)
                symbols_processed_with_driver = 0
            
            # Check driver health before processing
            if not is_driver_alive(driver):
                get_bootlick_logger().log_warning(
                    f"Driver is dead, recreating before processing {symbol}",
                    {"symbol": symbol, "function": "process_symbols"}
                )
                driver = get_session_or_driver(
                    url_to_test="https://screener.in",
                    get_session=False,
                    headless=False,
                    proxy_source=proxy_source,
                    api_key=api_key,
                    proxy_user=proxy_user,
                    proxy_password=proxy_pass,
                    webdriver_path=driver_path,
                )
                if driver is None:
                    error_msg = f"Failed to recreate driver for {symbol}. get_session_or_driver returned None."
                    get_bootlick_logger().log_error(error_msg, None, {"symbol": symbol, "function": "process_symbols"})
                    unsuccessul_symbols.append(symbol)
                    continue
                symbols_processed_with_driver = 0
            
            symbol_index = symbols.index(symbol)
            current_number = symbol_index + 1  # 1-indexed for clarity
            total_symbols = len(symbols)
            percentage = (current_number / total_symbols) * 100
            get_bootlick_logger().log_info(
                f"Loading: {symbol} ({current_number}/{total_symbols} - {percentage:.1f}% complete)",
                {
                    "symbol": symbol,
                    "current_number": current_number,
                    "total_symbols": total_symbols,
                    "percentage_complete": round(percentage, 1),
                    "progress": f"{current_number}/{total_symbols}",
                    "function": "process_symbols",
                },
            )
            # Optimized delay - reduced from 5-10s to 3-7s for better speed while still avoiding rate limits
            base_delay = random.uniform(3, 7)
            delay = base_delay
            get_bootlick_logger().log_info(
                f"Waiting for {delay:.2f} seconds before processing symbol...", 
                {"delay_seconds": delay, "function": "process_symbols"}
            )
            time.sleep(delay)
            
            # Check driver health after delay and before parsing
            if not is_driver_alive(driver):
                get_bootlick_logger().log_warning(
                    f"Driver died during delay for {symbol}, recreating...",
                    {"symbol": symbol, "function": "process_symbols"}
                )
                if driver:
                    try:
                        driver.quit()
                    except Exception:
                        pass
                driver = get_session_or_driver(
                    url_to_test="https://screener.in",
                    get_session=False,
                    headless=False,
                    proxy_source=proxy_source,
                    api_key=api_key,
                    proxy_user=proxy_user,
                    proxy_password=proxy_pass,
                    webdriver_path=driver_path,
                )
                if driver is None:
                    error_msg = f"Failed to recreate driver for {symbol}"
                    get_bootlick_logger().log_error(error_msg, None, {"symbol": symbol, "function": "process_symbols"})
                    unsuccessul_symbols.append(symbol)
                    continue
                symbols_processed_with_driver = 0
            
            retries = 2
            consolidated = True
            while retries > 0:
                try:
                    # Check driver health before each parse attempt
                    if not is_driver_alive(driver):
                        get_bootlick_logger().log_warning(
                            f"Driver is dead before parse attempt for {symbol}, recreating...",
                            {"symbol": symbol, "retry": 2 - retries, "function": "process_symbols"}
                        )
                        if driver:
                            try:
                                driver.quit()
                            except Exception:
                                pass
                        driver = get_session_or_driver(
                            url_to_test="https://screener.in",
                            get_session=False,
                            headless=False,
                            proxy_source=proxy_source,
                            api_key=api_key,
                            proxy_user=proxy_user,
                            proxy_password=proxy_pass,
                            webdriver_path=driver_path,
                        )
                        if driver is None:
                            error_msg = f"Failed to recreate driver for {symbol}"
                            get_bootlick_logger().log_error(error_msg, None, {"symbol": symbol, "function": "process_symbols"})
                            unsuccessul_symbols.append(symbol)
                            break
                        symbols_processed_with_driver = 0
                    
                    if retries == 1:
                        consolidated = False
                    lenient_log_path = os.path.join(os.path.dirname(incomplete_file_path or data_folder), "consolidated_lenient.txt")
                    sections = parse_with_timeout(symbol, driver, consolidated, lenient_log_path=lenient_log_path)
                    if sections and isinstance(sections, dict):
                        for section, df in sections.items():
                            temp_file = os.path.join(data_folder, f"{section}_{symbol}.rds")
                            log_data_consumed(driver)
                            saveRDS(df, temp_file)
                            saved_files.append(os.path.basename(temp_file))  # Track saved file
                        symbols_processed_with_driver += 1
                        # Remove from incomplete file since processing was successful
                        _remove_symbol_from_incomplete_file(incomplete_file_path, symbol)
                        break  # Exit loop on success
                    else:
                        get_bootlick_logger().log_warning(
                            f"No valid sections returned for symbol {symbol}. Retrying...",
                            {"symbol": symbol, "function": "process_symbols"},
                        )
                        log_data_consumed(driver)
                        retries -= 1
                        if retries == 0:
                            unsuccessul_symbols.append(symbol)
                        else:
                            # Exponential backoff on retry
                            backoff_delay = base_delay * (2 ** (2 - retries))
                            get_bootlick_logger().log_info(
                                f"Waiting {backoff_delay:.2f}s before retry (exponential backoff)",
                                {"backoff_delay": backoff_delay, "retries_remaining": retries, "function": "process_symbols"}
                            )
                            time.sleep(backoff_delay)
                except Exception as e:
                    get_bootlick_logger().log_error(
                        f"Error processing symbol {symbol} on retry {2 - retries}",
                        e,
                        {"symbol": symbol, "retry_count": 2 - retries, "function": "process_symbols"},
                    )
                    retries -= 1
                    if retries > 0:
                        # Exponential backoff before retrying with new proxy
                        backoff_delay = base_delay * (2 ** (2 - retries))
                        get_bootlick_logger().log_warning(
                            f"Retrying {symbol} with a new proxy after {backoff_delay:.2f}s backoff...", 
                            {"symbol": symbol, "backoff_delay": backoff_delay, "function": "process_symbols"}
                        )
                        time.sleep(backoff_delay)
                    if driver:
                        driver.quit()
                    driver = get_session_or_driver(
                        url_to_test="https://screener.in",
                        get_session=False,
                        headless=False,
                        proxy_source=proxy_source,
                        api_key=api_key,
                        proxy_user=proxy_user,
                        proxy_password=proxy_pass,
                        webdriver_path=driver_path,
                    )
                    if driver is None:
                        error_msg = f"Failed to reinitialize driver for symbol {symbol}. get_session_or_driver returned None."
                        get_bootlick_logger().log_error(error_msg, None, {"symbol": symbol, "function": "process_symbols"})
                        unsuccessul_symbols.append(symbol)
                        break  # Exit retry loop if driver cannot be initialized
    finally:
        if driver:
            driver.quit()
        get_bootlick_logger().log_info(
            f"Total data consumed across all sessions: {cumulative_data_consumed / 1024:.2f} KB",
            {"cumulative_data_consumed_kb": cumulative_data_consumed / 1024, "function": "process_symbols"},
        )
        # Log batch summary of saved RDS files (only files saved in this execution)
        if saved_files:
            get_bootlick_logger().log_info(
                f"RDS files saved to folder: {data_folder}",
                {
                    "folder": data_folder,
                    "file_count": len(saved_files),
                    "filenames": sorted(saved_files),
                    "function": "process_symbols"
                }
            )
        return unsuccessul_symbols


def consolidate_section_data(section, temp_folder, existing_data, output_path):
    """Consolidate all temp files for a section and merge with existing data."""
    temp_files = glob.glob(os.path.join(temp_folder, f"{section}_*.rds"))

    # Load and concatenate all temp files
    df = pd.concat([readRDS(file) for file in temp_files], ignore_index=True)
    df = df.copy()

    # Normalize and deduplicate new data
    df["Normalized_Description"] = df["Description"].str.rstrip("+ -").str.strip()

    # Clean and normalize column names
    df.columns = [
        re.search(r"[A-Za-z]{3} \d{4}", col).group() if re.search(r"[A-Za-z]{3} \d{4}", col) else col
        for col in df.columns
    ]

    # Identify date columns
    date_columns = [col for col in df.columns if re.match(r"^[A-Za-z]{3} \d{4}$", col)]

    # Melt the date columns into rows to create an "EndDate" column
    df = df.melt(
        id_vars=["Symbol", "Company", "Description", "Normalized_Description"],
        value_vars=date_columns,
        var_name="EndDate",
        value_name="Value",
    )

    # Drop rows with NaN values in the "Value" column
    df = df.dropna(subset=["Value"])

    # Normalize and deduplicate existing data
    existing_data[section]["Normalized_Description"] = (
        existing_data[section]["Description"].str.rstrip("+ -").str.strip()
    )

    # Melt existing_data[section] to create an "EndDate" column
    existing_date_columns = [col for col in existing_data[section].columns if re.match(r"^[A-Za-z]{3} \d{4}$", col)]
    existing_data_long = existing_data[section].melt(
        id_vars=["Symbol", "Company", "Description", "Normalized_Description"],
        value_vars=existing_date_columns,
        var_name="EndDate",
        value_name="Value",
    )

    # Drop rows with NaN values in the "Value" column for existing data
    existing_data_long = existing_data_long.dropna(subset=["Value"])

    # Merge existing data with new data
    merged_data = pd.concat([existing_data_long, df], ignore_index=True)

    # Overwrite rows in `merged_data` with data from `df` for matching (Symbol, Normalized_Description, EndDate)
    merged_data = (
        merged_data.sort_values(by=["Symbol", "Normalized_Description", "EndDate"], ascending=[True, True, False])
        .drop_duplicates(subset=["Symbol", "Normalized_Description", "EndDate"], keep="first")
        .reset_index(drop=True)
    )
    merged_data["COACode"] = merged_data["Description"].map(get_dynamic_config().get(section, {}))
    # Pivot the data back to wide format
    merged_data = merged_data.pivot(
        index=["Symbol", "Company", "Description", "Normalized_Description", "COACode"],
        columns="EndDate",
        values="Value",
    ).reset_index()
    # Sort and reorder columns
    fixed_columns = ["Symbol", "Company", "Description", "COACode"]
    date_columns = [
        col for col in merged_data.columns if col not in fixed_columns and re.match(r"^[A-Za-z]{3} \d{4}$", col)
    ]
    sorted_date_columns = sorted(date_columns, key=lambda x: datetime.strptime(x, "%b %Y"))
    merged_data = merged_data[fixed_columns + sorted_date_columns]

    # Map COACode for the section
    merged_data["COACode"] = merged_data["Description"].map(get_dynamic_config().get(section, {}))

    # Save consolidated data
    saveRDS(merged_data, output_path)
    get_bootlick_logger().log_info(
        f"Section '{section}' saved with updated data.", {"section": section, "function": "consolidate_section_data"}
    )


def save_eligible(section, df):
    non_numeric_columns = ["Symbol", "Company", "Description", "COACode"]

    # Only drop columns that exist in the DataFrame
    financial_columns = df.drop(columns=[col for col in non_numeric_columns if col in df.columns], errors="ignore")

    # Check if all values in the remaining columns are NaN
    if financial_columns.isna().all().all():
        get_bootlick_logger().log_info(
            f"All values for {section} are NaNs. Skipping save.",
            {"section": section, "function": "consolidate_section_data"},
        )
        return False

    return True


def save_section_data(section, df):
    global existing_data

    # Skip if all values in df are NaN
    if not save_eligible(section, df):
        return

    # Filter existing_data[section] for only relevant symbols from df
    relevant_existing_rows = existing_data[section][existing_data[section]["Symbol"].isin(df["Symbol"])].copy()

    # Normalize descriptions in both DataFrames
    relevant_existing_rows["Normalized_Description"] = (
        relevant_existing_rows["Description"].str.rstrip("+ -").str.rstrip("-").str.strip()
    )
    relevant_existing_rows = relevant_existing_rows.drop_duplicates(
        subset=["Symbol", "Normalized_Description"], keep="last"
    )
    df["Normalized_Description"] = df["Description"].str.rstrip("+ -").str.rstrip("-").str.strip()

    # Set index for efficient updates
    relevant_existing_rows = relevant_existing_rows.set_index(["Symbol", "Normalized_Description"])

    # Update existing rows with new data
    relevant_existing_rows.update(df.set_index(["Symbol", "Normalized_Description"]))

    # Reset the index to restore the original structure
    relevant_existing_rows = relevant_existing_rows.reset_index()

    # Step 3: Merge df with relevant_existing_rows
    merged_data = pd.concat([relevant_existing_rows, df]).drop_duplicates(
        subset=["Symbol", "Normalized_Description"], keep="last"
    )

    # Step 1: Create combined description order using OrderedDict
    combined_order = OrderedDict()

    # Add descriptions from df to combined_order
    for desc in df["Normalized_Description"]:
        combined_order[desc] = None

    # Add descriptions from relevant_existing_rows that are not in df
    for desc in relevant_existing_rows["Normalized_Description"]:
        if desc not in combined_order:
            combined_order[desc] = None

    # Step 2: Assign sort order based on the combined_order
    description_order = {desc: idx for idx, desc in enumerate(combined_order.keys())}
    # Step 3: Merge df with relevant_existing_rows
    merged_data = pd.concat([relevant_existing_rows, df]).drop_duplicates(
        subset=["Symbol", "Normalized_Description"], keep="last"
    )
    # Step 4: Sort the merged data using the custom order
    merged_data["sort_order"] = merged_data["Normalized_Description"].map(description_order)
    merged_data = merged_data.sort_values(by=["Symbol", "sort_order"]).drop(
        columns=["sort_order", "Normalized_Description"]
    )

    # Step 6: Remove old rows for the symbols being updated
    symbols_to_update = df["Symbol"].unique()
    existing_data[section] = existing_data[section][~existing_data[section]["Symbol"].isin(symbols_to_update)]

    # Step 7: Append the merged data back to existing_data[section]
    existing_data[section] = pd.concat([existing_data[section], merged_data], ignore_index=True)

    # Step 8: Reindex columns and fill missing values with NaN
    existing_data[section] = existing_data[section].reindex(
        columns=["Symbol", "Company", "Description", "COACode"]
        + sorted(set(merged_data.columns) - {"Symbol", "Company", "Description", "COACode"}),
        fill_value=pd.NA,
    )
    fixed_columns = ["Symbol", "Company", "Description", "COACode"]
    date_columns = [
        col
        for col in existing_data[section].columns
        if col not in fixed_columns and re.match(r"^[A-Za-z]{3} \d{4}$", col)
    ]
    # Sort the date columns in ascending order by date
    sorted_date_columns = sorted(date_columns, key=lambda x: datetime.strptime(x, "%b %Y"))

    # Reorder the columns
    existing_data[section] = existing_data[section][fixed_columns + sorted_date_columns]

    # Step 9: Save the updated section to file
    sections = ["Balance Sheet", "Profit & Loss", "Quarterly Results", "Cash Flows", "Shareholding Pattern"]
    section_files = {
        section: f"{get_dynamic_config().get('datapath')}/{section.lower().replace(' ', '_')}.rds"
        for section in sections
    }
    file_path = section_files[section]
    saveRDS(existing_data[section], os.path.expanduser(file_path))

    get_bootlick_logger().log_debug(
        f"Section '{section}' saved with updated data for symbols: {symbols_to_update}",
        {"section": section, "symbols_to_update": symbols_to_update, "function": "save_section_data"},
    )


def _fetch_symbols_from_url(driver, base_url, url_description):
    """
    Helper function to fetch symbols from a given base URL by paginating through all pages.
    
    Args:
        driver: Selenium WebDriver instance
        base_url: Base URL to fetch symbols from
        url_description: Description for logging purposes
        
    Returns:
        List of unique symbols
    """
    symbols = []
    p = 0
    
    try:
        while True:
            # Check driver health before each page
            if not is_driver_alive(driver):
                error_msg = f"Driver died during symbol list fetching at page {p} for {url_description}"
                get_bootlick_logger().log_error(error_msg, None, {"page": p, "url_description": url_description, "function": "_fetch_symbols_from_url"})
                break
            
            log_data_consumed(driver)  # Logs data consumed internally
            p = p + 1
            driver.get(f"{base_url}&p={p}")
            time.sleep(5)  # Wait for the page to load
            
            if not is_driver_alive(driver):
                error_msg = f"Driver died after loading page {p} for {url_description}"
                get_bootlick_logger().log_error(error_msg, None, {"page": p, "url_description": url_description, "function": "_fetch_symbols_from_url"})
                break
            
            if driver.current_url == "https://www.screener.in/results/latest/":
                get_bootlick_logger().log_info(
                    f"Reached the base page after exhausting all pages for {url_description}. Stopping pagination.",
                    {"url_description": url_description, "function": "_fetch_symbols_from_url"},
                )
                break
            
            # Wait for the page to fully load
            try:
                WebDriverWait(driver, 30).until(
                    lambda d: is_driver_alive(d) and d.execute_script("return document.readyState") == "complete"
                )
            except Exception as e:
                if not is_driver_alive(driver):
                    error_msg = f"Driver died while waiting for page {p} to load for {url_description}"
                    get_bootlick_logger().log_error(error_msg, e, {"page": p, "url_description": url_description, "function": "_fetch_symbols_from_url"})
                    break
                raise
            
            get_bootlick_logger().log_info(
                f"Page fully loaded for {url_description}. {base_url}&p={p}",
                {"base_url": base_url, "page": p, "url_description": url_description, "function": "_fetch_symbols_from_url"},
            )
            
            # Use safe page source retrieval
            page_source = get_page_source_safe(driver, f"page_{p}_{url_description}")
            soup = BeautifulSoup(page_source, "html.parser")
            company_links = soup.find_all("a", href=lambda href: href and "/company/" in href)
            for link in company_links:
                href = link["href"]
                # Extract the symbol (e.g., "VIJIFIN") from the href
                symbol = href.split("/")[2]  # The symbol is the third part of the href
                symbols.append(symbol)
    except Exception as e:
        get_bootlick_logger().log_error(
            f"Error while fetching symbols on page {p} for {url_description}",
            e,
            {"page": p, "url_description": url_description, "function": "_fetch_symbols_from_url"}
        )
    
    # Remove duplicates and return
    return list(set(symbols))


def get_symbol_list(proxy_source, proxy_user, proxy_pass, api_key, driver_path):
    driver = get_session_or_driver(
        url_to_test="https://screener.in",
        get_session=False,
        headless=False,
        proxy_source=proxy_source,
        api_key=api_key,
        proxy_user=proxy_user,
        proxy_password=proxy_pass,
        webdriver_path=driver_path,
    )
    
    if driver is None:
        error_msg = "Failed to initialize driver for get_symbol_list. get_session_or_driver returned None."
        get_bootlick_logger().log_error(error_msg, None, {"function": "get_symbol_list"})
        raise RuntimeError(error_msg)
    
    try:
        # Open Screener.in login page
        driver.get("https://www.screener.in/login/")

        # Wait for the login form to load
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.NAME, "username")))

        # Enter username
        username_field = driver.find_element(By.NAME, "username")
        username_field.send_keys(get_dynamic_config()["credentials"]["username"])
        time.sleep(5)
        # Enter password
        password_field = driver.find_element(By.NAME, "password")
        password_field.send_keys(get_dynamic_config()["credentials"]["password"])
        time.sleep(4)
        # Submit the login form
        password_field.send_keys(Keys.RETURN)

        # Wait for the login to complete
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CLASS_NAME, "top-navigation")))

        get_bootlick_logger().log_info("Login successful!", {"function": "get_symbol_list"})

        # Perform further actions after login
        time.sleep(2)
        
        # Step 1: Fetch all NSE symbols (includes both main board and SME)
        get_bootlick_logger().log_info(
            "Fetching all NSE symbols (main board + SME)...",
            {"function": "get_symbol_list"}
        )
        nse_base_url = "https://www.screener.in/results/latest/?sme=nse"
        all_nse_symbols = _fetch_symbols_from_url(driver, nse_base_url, "all NSE symbols")
        get_bootlick_logger().log_info(
            f"Fetched {len(all_nse_symbols)} total NSE symbols",
            {"count": len(all_nse_symbols), "function": "get_symbol_list"}
        )
        
        # Step 2: Fetch only SME symbols
        get_bootlick_logger().log_info(
            "Fetching SME symbols to exclude...",
            {"function": "get_symbol_list"}
        )
        sme_base_url = "https://www.screener.in/results/latest/?sme=sme"
        sme_symbols = _fetch_symbols_from_url(driver, sme_base_url, "SME symbols")
        get_bootlick_logger().log_info(
            f"Fetched {len(sme_symbols)} SME symbols",
            {"count": len(sme_symbols), "function": "get_symbol_list"}
        )
        
        # Step 3: Exclude SME symbols from NSE symbols to get only main board NSE
        sme_symbols_set = set(sme_symbols)
        main_board_nse_symbols = [symbol for symbol in all_nse_symbols if symbol not in sme_symbols_set]
        
        get_bootlick_logger().log_info(
            f"Filtered to {len(main_board_nse_symbols)} main board NSE symbols (excluded {len(sme_symbols_set)} SME symbols)",
            {
                "main_board_count": len(main_board_nse_symbols),
                "sme_count": len(sme_symbols_set),
                "total_nse_count": len(all_nse_symbols),
                "function": "get_symbol_list"
            }
        )
        
        return main_board_nse_symbols

    finally:
        # Close the browser
        if driver is not None:
            try:
                driver.quit()
            except Exception as e:
                get_bootlick_logger().log_warning(
                    f"Error closing driver in get_symbol_list: {e}",
                    {"error": str(e), "function": "get_symbol_list"}
                )


def get_fiscal_period(symbol, end_date):
    fiscal_exception = FiscalYearException.get(symbol, {})
    for date, month in sorted(fiscal_exception.items(), reverse=True):
        if end_date >= date:
            fiscal_month = month
            break
    else:
        fiscal_month = "March"

    if fiscal_month == "March":
        next_fiscal_year_end = dt.datetime(end_date.year, 3, 31)
        if end_date > next_fiscal_year_end:
            next_fiscal_year_end = dt.datetime(end_date.year + 1, 3, 31)
    elif fiscal_month == "January":
        next_fiscal_year_end = dt.datetime(end_date.year, 1, 31)
        if end_date > next_fiscal_year_end:
            next_fiscal_year_end = dt.datetime(end_date.year + 1, 1, 31)
    elif fiscal_month == "June":
        next_fiscal_year_end = dt.datetime(end_date.year, 6, 30)
        if end_date > next_fiscal_year_end:
            next_fiscal_year_end = dt.datetime(end_date.year + 1, 6, 30)
    elif fiscal_month == "September":
        next_fiscal_year_end = dt.datetime(end_date.year, 9, 30)
        if end_date > next_fiscal_year_end:
            next_fiscal_year_end = dt.datetime(end_date.year + 1, 9, 30)
    elif fiscal_month == "December":
        next_fiscal_year_end = dt.datetime(end_date.year, 12, 31)
        if end_date > next_fiscal_year_end:
            next_fiscal_year_end = dt.datetime(end_date.year + 1, 12, 31)

    prior_fiscal_year_end = next_fiscal_year_end - dt.timedelta(days=365)

    return prior_fiscal_year_end, next_fiscal_year_end


# Function to get the last calendar date of a month
def get_last_day_of_month(date):
    next_month = date.replace(day=28) + dt.timedelta(days=4)  # this will never fail
    return next_month - dt.timedelta(days=next_month.day)


def reformat_balance_sheet(df):
    columns_to_process = df.columns[4:]

    # Precompute end dates for all columns
    end_dates = [get_last_day_of_month(dt.datetime.strptime(column, "%b %Y")) for column in columns_to_process]

    # Precompute fiscal periods and other metadata for all rows
    fiscal_data = [get_fiscal_period(symbol, end_date) for symbol in df["Symbol"] for end_date in end_dates]
    period_types = [
        "Annual" if end_date.month == next_fiscal.month else "Interim"
        for (_, next_fiscal), end_date in zip(fiscal_data, end_dates * len(df))
    ]
    period_lengths = [
        (end_date - prior_fiscal).days // 30 for (prior_fiscal, _), end_date in zip(fiscal_data, end_dates * len(df))
    ]
    fiscal_period_numbers = [
        float("nan") if period_type == "Annual" else period_length // 3
        for period_type, period_length in zip(period_types, period_lengths)
    ]

    # Assign metadata directly to the rows of the DataFrame
    metadata = {
        "EndDate": np.tile(end_dates, len(df)),
        "FiscalYear": [next_fiscal.year for _, next_fiscal in fiscal_data],
        "FiscalPeriodNumber": fiscal_period_numbers,
        "PeriodType": period_types,
        "PeriodLength": period_lengths,
        "StatementType": ["BAL"] * len(fiscal_data),
    }

    # Repeat original data for each column to process
    repeated_data = pd.DataFrame(
        {
            "Symbol": df["Symbol"].repeat(len(columns_to_process)).values,
            "Description": df["Description"].repeat(len(columns_to_process)).values,
            "COACode": df["COACode"].repeat(len(columns_to_process)).values,
            "Value": df[columns_to_process].values.flatten(),
        }
    )

    # Combine repeated data and metadata
    reformatted_data = pd.concat([repeated_data.reset_index(drop=True), pd.DataFrame(metadata)], axis=1)
    reformatted_data = reformatted_data.sort_values(by="EndDate", ascending=True).reset_index(drop=True)
    reformatted_data = reformatted_data.dropna(subset=["Value"])
    return reformatted_data


def reformat_pnl(df, statement_type):
    columns_to_process = df.columns[4:]

    # Precompute end dates and fiscal years for all columns
    end_dates = []
    for column in columns_to_process:
        match = re.search(r"[A-Za-z]{3} \d{4}", column)
        if match:
            end_dates.append(get_last_day_of_month(dt.datetime.strptime(match.group(), "%b %Y")))
        else:
            get_bootlick_logger().log_warning(
                f"Invalid column format: {column}", {"column": column, "function": "reformat_balance_sheet"}
            )
    fiscal_years = [get_fiscal_period(symbol, end_date)[1].year for symbol in df["Symbol"] for end_date in end_dates]

    # Assign metadata directly to the rows of the DataFrame
    metadata = {
        "EndDate": np.tile(end_dates, len(df)),
        "FiscalYear": fiscal_years,
        "FiscalPeriodNumber": [float("nan")] * len(fiscal_years),
        "PeriodType": ["Annual"] * len(fiscal_years),
        "PeriodLength": [12] * len(fiscal_years),
        "StatementType": [statement_type] * len(fiscal_years),
    }

    # Repeat original data for each column to process
    repeated_data = pd.DataFrame(
        {
            "Symbol": df["Symbol"].repeat(len(columns_to_process)).values,
            "Description": df["Description"].repeat(len(columns_to_process)).values,
            "COACode": df["COACode"].repeat(len(columns_to_process)).values,
            "Value": df[columns_to_process].values.flatten(),
        }
    )

    # Combine repeated data and metadata
    reformatted_data = pd.concat([repeated_data.reset_index(drop=True), pd.DataFrame(metadata)], axis=1)
    reformatted_data = reformatted_data.sort_values(by="EndDate", ascending=True).reset_index(drop=True)
    reformatted_data = reformatted_data.dropna(subset=["Value"])

    return reformatted_data


def reformat_quarterly_pnl(df):
    columns_to_process = df.columns[4:]

    # Precompute end dates, fiscal periods, and other metadata for all columns
    end_dates = [get_last_day_of_month(dt.datetime.strptime(column, "%b %Y")) for column in columns_to_process]
    fiscal_data = [get_fiscal_period(symbol, end_date) for symbol in df["Symbol"] for end_date in end_dates]
    period_lengths = [
        (end_date - prior_fiscal).days // 30 for (prior_fiscal, _), end_date in zip(fiscal_data, end_dates * len(df))
    ]
    fiscal_period_numbers = [period_length // 3 for period_length in period_lengths]

    # Assign metadata directly to the rows of the DataFrame
    metadata = {
        "EndDate": np.tile(end_dates, len(df)),
        "FiscalYear": [next_fiscal.year for _, next_fiscal in fiscal_data],
        "FiscalPeriodNumber": fiscal_period_numbers,
        "PeriodType": ["Interim"] * len(fiscal_data),
        "PeriodLength": 3,
        "StatementType": ["INC"] * len(fiscal_data),
    }

    # Repeat original data for each column to process
    repeated_data = pd.DataFrame(
        {
            "Symbol": df["Symbol"].repeat(len(columns_to_process)).values,
            "Description": df["Description"].repeat(len(columns_to_process)).values,
            "COACode": df["COACode"].repeat(len(columns_to_process)).values,
            "Value": df[columns_to_process].values.flatten(),
        }
    )

    # Combine repeated data and metadata
    reformatted_data = pd.concat([repeated_data.reset_index(drop=True), pd.DataFrame(metadata)], axis=1)
    reformatted_data = reformatted_data.sort_values(by="EndDate", ascending=True).reset_index(drop=True)
    reformatted_data = reformatted_data.dropna(subset=["Value"])

    return reformatted_data


def reformat_cash_flows(df):
    return reformat_pnl(df, "CAS")


def reformat_shareholding(df):
    columns_to_process = df.columns[4:]

    # Precompute end dates for all columns
    end_dates = [get_last_day_of_month(dt.datetime.strptime(column, "%b %Y")) for column in columns_to_process]

    # Precompute fiscal periods and other metadata for all rows
    period_lengths = [12] * len(end_dates)  # Assuming shareholding data is annual
    fiscal_period_numbers = [float("nan")] * len(end_dates)  # No fiscal period numbers for shareholding
    period_types = ["Annual"] * len(end_dates)  # Assuming shareholding data is annual

    # Assign metadata directly to the rows of the DataFrame
    metadata = {
        "EndDate": np.tile(end_dates, len(df)),
        "FiscalYear": [end_date.year for end_date in end_dates] * len(df),
        "FiscalPeriodNumber": fiscal_period_numbers * len(df),
        "PeriodType": period_types * len(df),
        "PeriodLength": period_lengths * len(df),
        "StatementType": ["HLD"] * len(end_dates) * len(df),
    }

    # Repeat original data for each column to process
    repeated_data = pd.DataFrame(
        {
            "Symbol": df["Symbol"].repeat(len(columns_to_process)).values,
            "Description": df["Description"].repeat(len(columns_to_process)).values,
            "COACode": [""] * len(df) * len(columns_to_process),  # COACode is empty for shareholding
            "Value": df[columns_to_process].values.flatten(),
        }
    )

    # Combine repeated data and metadata
    reformatted_data = pd.concat([repeated_data.reset_index(drop=True), pd.DataFrame(metadata)], axis=1)
    reformatted_data = reformatted_data.sort_values(by="EndDate", ascending=True).reset_index(drop=True)

    # Drop rows where the 'Value' column is NaN
    reformatted_data = reformatted_data.dropna(subset=["Value"])

    return reformatted_data


# Load fiscal year exceptions
fiscal_year_exceptions = get_dynamic_config().get("fiscal_year_exceptions", {})
FiscalYearException = {
    symbol: {dt.datetime.strptime(date, "%Y-%m-%d"): month for date, month in dates.items()}
    for symbol, dates in fiscal_year_exceptions.items()
}
