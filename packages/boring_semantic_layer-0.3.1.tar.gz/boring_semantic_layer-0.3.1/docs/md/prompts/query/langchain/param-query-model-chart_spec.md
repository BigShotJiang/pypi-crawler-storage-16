Optional chart customization dict. Common: `{"chart_type": "bar"}` or `"line"`, `"scatter"`.

For detailed options → `get_documentation("charting")`
