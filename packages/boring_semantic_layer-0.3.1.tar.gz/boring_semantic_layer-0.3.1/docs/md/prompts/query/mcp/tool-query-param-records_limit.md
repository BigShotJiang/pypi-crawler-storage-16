Max records returned to LLM context (default: None = all). Use to limit token usage for large result sets. For example, set to 50 to cap the data sent to your context window.
