import BSLMarkdownPage from './BSLMarkdownPage'

export default function ComposeModels() {
  return <BSLMarkdownPage pageSlug="compose" />
}
