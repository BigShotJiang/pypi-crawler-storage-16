import BSLMarkdownPage from './BSLMarkdownPage'

export default function NestedSubtotals() {
  return <BSLMarkdownPage pageSlug="nested-subtotals" />
}
