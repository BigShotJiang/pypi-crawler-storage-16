import BSLMarkdownPage from './BSLMarkdownPage'

export default function QueryAgentOverview() {
  return <BSLMarkdownPage pageSlug="query-agent" />
}
