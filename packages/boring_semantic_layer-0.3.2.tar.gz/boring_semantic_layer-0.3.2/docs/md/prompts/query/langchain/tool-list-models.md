List all semantic models, including their dimensions and measures.
