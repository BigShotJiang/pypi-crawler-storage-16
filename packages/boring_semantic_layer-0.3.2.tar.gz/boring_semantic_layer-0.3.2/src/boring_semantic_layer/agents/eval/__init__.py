"""Evaluation suite for BSL agents."""
