DEFAULT_API_BASE_URL = "https://api.botads.app"
DEFAULT_DIRECT_LINK_BASE_URL = "https://botads.me"

EVENT_DIRECT_LINK = "direct_link"
EVENT_REWARDED = "rewarded"
