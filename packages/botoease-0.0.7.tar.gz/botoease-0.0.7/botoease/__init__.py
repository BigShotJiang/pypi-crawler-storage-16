__version__ = "0.0.7"


from .storage import Storage
