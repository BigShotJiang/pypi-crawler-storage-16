def get_benchmark():
    return {"hello": "world"}
