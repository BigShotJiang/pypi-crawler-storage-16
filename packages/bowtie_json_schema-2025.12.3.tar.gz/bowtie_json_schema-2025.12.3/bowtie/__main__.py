"""
The CLI for Bowtie, a meta-validator for the JSON Schema specification.
"""

from bowtie import _cli

_cli.main()
