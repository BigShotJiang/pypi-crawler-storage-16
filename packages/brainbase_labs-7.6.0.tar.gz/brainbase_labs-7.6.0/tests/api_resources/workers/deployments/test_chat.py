# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tests.utils import assert_matches_type
from brainbase_labs import BrainbaseLabs, AsyncBrainbaseLabs
from brainbase_labs.types.workers.deployments import (
    ChatListResponse,
    ChatCreateResponse,
    ChatUpdateResponse,
    ChatRetrieveResponse,
    ChatRetrieveAgentResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestChat:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create(self, client: BrainbaseLabs) -> None:
        chat = client.workers.deployments.chat.create(
            worker_id="workerId",
            allowed_users=["string"],
            extractions={
                "foo": {
                    "description": "description",
                    "required": True,
                    "type": "string",
                }
            },
            flow_id="flowId",
            model_config={"foo": "string"},
            name="name",
        )
        assert_matches_type(ChatCreateResponse, chat, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: BrainbaseLabs) -> None:
        chat = client.workers.deployments.chat.create(
            worker_id="workerId",
            allowed_users=["string"],
            extractions={
                "foo": {
                    "description": "description",
                    "required": True,
                    "type": "string",
                }
            },
            flow_id="flowId",
            model_config={"foo": "string"},
            name="name",
            llm_model="llmModel",
            success_criteria=[
                {
                    "items": [
                        {
                            "description": "description",
                            "threshold": 0,
                            "title": "title",
                            "type": "BINARY",
                        }
                    ],
                    "title": "title",
                    "description": "description",
                }
            ],
            welcome_message="welcomeMessage",
        )
        assert_matches_type(ChatCreateResponse, chat, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: BrainbaseLabs) -> None:
        response = client.workers.deployments.chat.with_raw_response.create(
            worker_id="workerId",
            allowed_users=["string"],
            extractions={
                "foo": {
                    "description": "description",
                    "required": True,
                    "type": "string",
                }
            },
            flow_id="flowId",
            model_config={"foo": "string"},
            name="name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        chat = response.parse()
        assert_matches_type(ChatCreateResponse, chat, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: BrainbaseLabs) -> None:
        with client.workers.deployments.chat.with_streaming_response.create(
            worker_id="workerId",
            allowed_users=["string"],
            extractions={
                "foo": {
                    "description": "description",
                    "required": True,
                    "type": "string",
                }
            },
            flow_id="flowId",
            model_config={"foo": "string"},
            name="name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            chat = response.parse()
            assert_matches_type(ChatCreateResponse, chat, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_create(self, client: BrainbaseLabs) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `worker_id` but received ''"):
            client.workers.deployments.chat.with_raw_response.create(
                worker_id="",
                allowed_users=["string"],
                extractions={
                    "foo": {
                        "description": "description",
                        "required": True,
                        "type": "string",
                    }
                },
                flow_id="flowId",
                model_config={"foo": "string"},
                name="name",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_retrieve(self, client: BrainbaseLabs) -> None:
        chat = client.workers.deployments.chat.retrieve(
            deployment_id="deploymentId",
            worker_id="workerId",
        )
        assert_matches_type(ChatRetrieveResponse, chat, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_retrieve(self, client: BrainbaseLabs) -> None:
        response = client.workers.deployments.chat.with_raw_response.retrieve(
            deployment_id="deploymentId",
            worker_id="workerId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        chat = response.parse()
        assert_matches_type(ChatRetrieveResponse, chat, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_retrieve(self, client: BrainbaseLabs) -> None:
        with client.workers.deployments.chat.with_streaming_response.retrieve(
            deployment_id="deploymentId",
            worker_id="workerId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            chat = response.parse()
            assert_matches_type(ChatRetrieveResponse, chat, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_retrieve(self, client: BrainbaseLabs) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `worker_id` but received ''"):
            client.workers.deployments.chat.with_raw_response.retrieve(
                deployment_id="deploymentId",
                worker_id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `deployment_id` but received ''"):
            client.workers.deployments.chat.with_raw_response.retrieve(
                deployment_id="",
                worker_id="workerId",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_update(self, client: BrainbaseLabs) -> None:
        chat = client.workers.deployments.chat.update(
            deployment_id="deploymentId",
            worker_id="workerId",
            extractions={
                "foo": {
                    "description": "description",
                    "required": True,
                    "type": "string",
                }
            },
        )
        assert_matches_type(ChatUpdateResponse, chat, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_update_with_all_params(self, client: BrainbaseLabs) -> None:
        chat = client.workers.deployments.chat.update(
            deployment_id="deploymentId",
            worker_id="workerId",
            extractions={
                "foo": {
                    "description": "description",
                    "required": True,
                    "type": "string",
                }
            },
            allowed_users=["string"],
            flow_id="flowId",
            llm_model="llmModel",
            model_config={"foo": "string"},
            name="name",
            success_criteria=[
                {
                    "items": [
                        {
                            "description": "description",
                            "threshold": 0,
                            "title": "title",
                            "type": "BINARY",
                        }
                    ],
                    "title": "title",
                    "description": "description",
                }
            ],
            welcome_message="welcomeMessage",
        )
        assert_matches_type(ChatUpdateResponse, chat, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_update(self, client: BrainbaseLabs) -> None:
        response = client.workers.deployments.chat.with_raw_response.update(
            deployment_id="deploymentId",
            worker_id="workerId",
            extractions={
                "foo": {
                    "description": "description",
                    "required": True,
                    "type": "string",
                }
            },
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        chat = response.parse()
        assert_matches_type(ChatUpdateResponse, chat, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_update(self, client: BrainbaseLabs) -> None:
        with client.workers.deployments.chat.with_streaming_response.update(
            deployment_id="deploymentId",
            worker_id="workerId",
            extractions={
                "foo": {
                    "description": "description",
                    "required": True,
                    "type": "string",
                }
            },
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            chat = response.parse()
            assert_matches_type(ChatUpdateResponse, chat, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_update(self, client: BrainbaseLabs) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `worker_id` but received ''"):
            client.workers.deployments.chat.with_raw_response.update(
                deployment_id="deploymentId",
                worker_id="",
                extractions={
                    "foo": {
                        "description": "description",
                        "required": True,
                        "type": "string",
                    }
                },
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `deployment_id` but received ''"):
            client.workers.deployments.chat.with_raw_response.update(
                deployment_id="",
                worker_id="workerId",
                extractions={
                    "foo": {
                        "description": "description",
                        "required": True,
                        "type": "string",
                    }
                },
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list(self, client: BrainbaseLabs) -> None:
        chat = client.workers.deployments.chat.list(
            "workerId",
        )
        assert_matches_type(ChatListResponse, chat, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: BrainbaseLabs) -> None:
        response = client.workers.deployments.chat.with_raw_response.list(
            "workerId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        chat = response.parse()
        assert_matches_type(ChatListResponse, chat, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: BrainbaseLabs) -> None:
        with client.workers.deployments.chat.with_streaming_response.list(
            "workerId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            chat = response.parse()
            assert_matches_type(ChatListResponse, chat, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_list(self, client: BrainbaseLabs) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `worker_id` but received ''"):
            client.workers.deployments.chat.with_raw_response.list(
                "",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_delete(self, client: BrainbaseLabs) -> None:
        chat = client.workers.deployments.chat.delete(
            deployment_id="deploymentId",
            worker_id="workerId",
        )
        assert chat is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_delete(self, client: BrainbaseLabs) -> None:
        response = client.workers.deployments.chat.with_raw_response.delete(
            deployment_id="deploymentId",
            worker_id="workerId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        chat = response.parse()
        assert chat is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_delete(self, client: BrainbaseLabs) -> None:
        with client.workers.deployments.chat.with_streaming_response.delete(
            deployment_id="deploymentId",
            worker_id="workerId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            chat = response.parse()
            assert chat is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_delete(self, client: BrainbaseLabs) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `worker_id` but received ''"):
            client.workers.deployments.chat.with_raw_response.delete(
                deployment_id="deploymentId",
                worker_id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `deployment_id` but received ''"):
            client.workers.deployments.chat.with_raw_response.delete(
                deployment_id="",
                worker_id="workerId",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_retrieve_agent(self, client: BrainbaseLabs) -> None:
        chat = client.workers.deployments.chat.retrieve_agent(
            chat_agent_id="chatAgentId",
            worker_id="workerId",
        )
        assert_matches_type(ChatRetrieveAgentResponse, chat, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_retrieve_agent(self, client: BrainbaseLabs) -> None:
        response = client.workers.deployments.chat.with_raw_response.retrieve_agent(
            chat_agent_id="chatAgentId",
            worker_id="workerId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        chat = response.parse()
        assert_matches_type(ChatRetrieveAgentResponse, chat, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_retrieve_agent(self, client: BrainbaseLabs) -> None:
        with client.workers.deployments.chat.with_streaming_response.retrieve_agent(
            chat_agent_id="chatAgentId",
            worker_id="workerId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            chat = response.parse()
            assert_matches_type(ChatRetrieveAgentResponse, chat, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_retrieve_agent(self, client: BrainbaseLabs) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `worker_id` but received ''"):
            client.workers.deployments.chat.with_raw_response.retrieve_agent(
                chat_agent_id="chatAgentId",
                worker_id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `chat_agent_id` but received ''"):
            client.workers.deployments.chat.with_raw_response.retrieve_agent(
                chat_agent_id="",
                worker_id="workerId",
            )


class TestAsyncChat:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncBrainbaseLabs) -> None:
        chat = await async_client.workers.deployments.chat.create(
            worker_id="workerId",
            allowed_users=["string"],
            extractions={
                "foo": {
                    "description": "description",
                    "required": True,
                    "type": "string",
                }
            },
            flow_id="flowId",
            model_config={"foo": "string"},
            name="name",
        )
        assert_matches_type(ChatCreateResponse, chat, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncBrainbaseLabs) -> None:
        chat = await async_client.workers.deployments.chat.create(
            worker_id="workerId",
            allowed_users=["string"],
            extractions={
                "foo": {
                    "description": "description",
                    "required": True,
                    "type": "string",
                }
            },
            flow_id="flowId",
            model_config={"foo": "string"},
            name="name",
            llm_model="llmModel",
            success_criteria=[
                {
                    "items": [
                        {
                            "description": "description",
                            "threshold": 0,
                            "title": "title",
                            "type": "BINARY",
                        }
                    ],
                    "title": "title",
                    "description": "description",
                }
            ],
            welcome_message="welcomeMessage",
        )
        assert_matches_type(ChatCreateResponse, chat, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncBrainbaseLabs) -> None:
        response = await async_client.workers.deployments.chat.with_raw_response.create(
            worker_id="workerId",
            allowed_users=["string"],
            extractions={
                "foo": {
                    "description": "description",
                    "required": True,
                    "type": "string",
                }
            },
            flow_id="flowId",
            model_config={"foo": "string"},
            name="name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        chat = await response.parse()
        assert_matches_type(ChatCreateResponse, chat, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncBrainbaseLabs) -> None:
        async with async_client.workers.deployments.chat.with_streaming_response.create(
            worker_id="workerId",
            allowed_users=["string"],
            extractions={
                "foo": {
                    "description": "description",
                    "required": True,
                    "type": "string",
                }
            },
            flow_id="flowId",
            model_config={"foo": "string"},
            name="name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            chat = await response.parse()
            assert_matches_type(ChatCreateResponse, chat, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_create(self, async_client: AsyncBrainbaseLabs) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `worker_id` but received ''"):
            await async_client.workers.deployments.chat.with_raw_response.create(
                worker_id="",
                allowed_users=["string"],
                extractions={
                    "foo": {
                        "description": "description",
                        "required": True,
                        "type": "string",
                    }
                },
                flow_id="flowId",
                model_config={"foo": "string"},
                name="name",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_retrieve(self, async_client: AsyncBrainbaseLabs) -> None:
        chat = await async_client.workers.deployments.chat.retrieve(
            deployment_id="deploymentId",
            worker_id="workerId",
        )
        assert_matches_type(ChatRetrieveResponse, chat, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncBrainbaseLabs) -> None:
        response = await async_client.workers.deployments.chat.with_raw_response.retrieve(
            deployment_id="deploymentId",
            worker_id="workerId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        chat = await response.parse()
        assert_matches_type(ChatRetrieveResponse, chat, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncBrainbaseLabs) -> None:
        async with async_client.workers.deployments.chat.with_streaming_response.retrieve(
            deployment_id="deploymentId",
            worker_id="workerId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            chat = await response.parse()
            assert_matches_type(ChatRetrieveResponse, chat, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncBrainbaseLabs) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `worker_id` but received ''"):
            await async_client.workers.deployments.chat.with_raw_response.retrieve(
                deployment_id="deploymentId",
                worker_id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `deployment_id` but received ''"):
            await async_client.workers.deployments.chat.with_raw_response.retrieve(
                deployment_id="",
                worker_id="workerId",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_update(self, async_client: AsyncBrainbaseLabs) -> None:
        chat = await async_client.workers.deployments.chat.update(
            deployment_id="deploymentId",
            worker_id="workerId",
            extractions={
                "foo": {
                    "description": "description",
                    "required": True,
                    "type": "string",
                }
            },
        )
        assert_matches_type(ChatUpdateResponse, chat, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncBrainbaseLabs) -> None:
        chat = await async_client.workers.deployments.chat.update(
            deployment_id="deploymentId",
            worker_id="workerId",
            extractions={
                "foo": {
                    "description": "description",
                    "required": True,
                    "type": "string",
                }
            },
            allowed_users=["string"],
            flow_id="flowId",
            llm_model="llmModel",
            model_config={"foo": "string"},
            name="name",
            success_criteria=[
                {
                    "items": [
                        {
                            "description": "description",
                            "threshold": 0,
                            "title": "title",
                            "type": "BINARY",
                        }
                    ],
                    "title": "title",
                    "description": "description",
                }
            ],
            welcome_message="welcomeMessage",
        )
        assert_matches_type(ChatUpdateResponse, chat, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_update(self, async_client: AsyncBrainbaseLabs) -> None:
        response = await async_client.workers.deployments.chat.with_raw_response.update(
            deployment_id="deploymentId",
            worker_id="workerId",
            extractions={
                "foo": {
                    "description": "description",
                    "required": True,
                    "type": "string",
                }
            },
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        chat = await response.parse()
        assert_matches_type(ChatUpdateResponse, chat, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncBrainbaseLabs) -> None:
        async with async_client.workers.deployments.chat.with_streaming_response.update(
            deployment_id="deploymentId",
            worker_id="workerId",
            extractions={
                "foo": {
                    "description": "description",
                    "required": True,
                    "type": "string",
                }
            },
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            chat = await response.parse()
            assert_matches_type(ChatUpdateResponse, chat, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_update(self, async_client: AsyncBrainbaseLabs) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `worker_id` but received ''"):
            await async_client.workers.deployments.chat.with_raw_response.update(
                deployment_id="deploymentId",
                worker_id="",
                extractions={
                    "foo": {
                        "description": "description",
                        "required": True,
                        "type": "string",
                    }
                },
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `deployment_id` but received ''"):
            await async_client.workers.deployments.chat.with_raw_response.update(
                deployment_id="",
                worker_id="workerId",
                extractions={
                    "foo": {
                        "description": "description",
                        "required": True,
                        "type": "string",
                    }
                },
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncBrainbaseLabs) -> None:
        chat = await async_client.workers.deployments.chat.list(
            "workerId",
        )
        assert_matches_type(ChatListResponse, chat, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncBrainbaseLabs) -> None:
        response = await async_client.workers.deployments.chat.with_raw_response.list(
            "workerId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        chat = await response.parse()
        assert_matches_type(ChatListResponse, chat, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncBrainbaseLabs) -> None:
        async with async_client.workers.deployments.chat.with_streaming_response.list(
            "workerId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            chat = await response.parse()
            assert_matches_type(ChatListResponse, chat, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_list(self, async_client: AsyncBrainbaseLabs) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `worker_id` but received ''"):
            await async_client.workers.deployments.chat.with_raw_response.list(
                "",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_delete(self, async_client: AsyncBrainbaseLabs) -> None:
        chat = await async_client.workers.deployments.chat.delete(
            deployment_id="deploymentId",
            worker_id="workerId",
        )
        assert chat is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncBrainbaseLabs) -> None:
        response = await async_client.workers.deployments.chat.with_raw_response.delete(
            deployment_id="deploymentId",
            worker_id="workerId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        chat = await response.parse()
        assert chat is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncBrainbaseLabs) -> None:
        async with async_client.workers.deployments.chat.with_streaming_response.delete(
            deployment_id="deploymentId",
            worker_id="workerId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            chat = await response.parse()
            assert chat is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_delete(self, async_client: AsyncBrainbaseLabs) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `worker_id` but received ''"):
            await async_client.workers.deployments.chat.with_raw_response.delete(
                deployment_id="deploymentId",
                worker_id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `deployment_id` but received ''"):
            await async_client.workers.deployments.chat.with_raw_response.delete(
                deployment_id="",
                worker_id="workerId",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_retrieve_agent(self, async_client: AsyncBrainbaseLabs) -> None:
        chat = await async_client.workers.deployments.chat.retrieve_agent(
            chat_agent_id="chatAgentId",
            worker_id="workerId",
        )
        assert_matches_type(ChatRetrieveAgentResponse, chat, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_retrieve_agent(self, async_client: AsyncBrainbaseLabs) -> None:
        response = await async_client.workers.deployments.chat.with_raw_response.retrieve_agent(
            chat_agent_id="chatAgentId",
            worker_id="workerId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        chat = await response.parse()
        assert_matches_type(ChatRetrieveAgentResponse, chat, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve_agent(self, async_client: AsyncBrainbaseLabs) -> None:
        async with async_client.workers.deployments.chat.with_streaming_response.retrieve_agent(
            chat_agent_id="chatAgentId",
            worker_id="workerId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            chat = await response.parse()
            assert_matches_type(ChatRetrieveAgentResponse, chat, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_retrieve_agent(self, async_client: AsyncBrainbaseLabs) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `worker_id` but received ''"):
            await async_client.workers.deployments.chat.with_raw_response.retrieve_agent(
                chat_agent_id="chatAgentId",
                worker_id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `chat_agent_id` but received ''"):
            await async_client.workers.deployments.chat.with_raw_response.retrieve_agent(
                chat_agent_id="",
                worker_id="workerId",
            )
