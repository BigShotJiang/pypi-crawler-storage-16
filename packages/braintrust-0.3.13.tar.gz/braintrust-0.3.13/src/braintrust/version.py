VERSION = "0.3.13"

# this will be templated during the build
GIT_COMMIT = "cef88a007fa60f4cd873f1d891a54ce5e173f3aa"
