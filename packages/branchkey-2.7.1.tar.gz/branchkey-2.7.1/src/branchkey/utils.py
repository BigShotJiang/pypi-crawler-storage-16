AGGREGATED_OUTPUT_DIR = "./aggregated_output"

RBMQ_aggregation_status = "aggregation_status"
RBMQ_run_status = "run_status"

FILE_METADATA = "{'key1':'value1', 'key2':'value2'}"
