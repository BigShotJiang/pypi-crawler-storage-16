# brickbed

Python client for [Brickbed](https://brickbed.com) - the document database built for distributed edge apps.

## Coming Soon

Brickbed is currently on waitlist. Visit [brickbed.com](https://brickbed.com) to get notified when it's ready.

## Installation

```bash
pip install brickbed
# or
uv add brickbed
```

## Usage

```python
from brickbed import createClient

db = createClient(
    endpoint=os.environ["BRICKBED_ENDPOINT"],
    api_key=os.environ["BRICKBED_API_KEY"],
)

# Insert a document
post = await db.collection("posts").insert({
    "title": "Hello World",
    "content": "My first post",
})

# Get a document
fetched = await db.collection("posts").get(post["_id"])

# List documents
result = await db.collection("posts").list(limit=10)
```

## License

MIT
