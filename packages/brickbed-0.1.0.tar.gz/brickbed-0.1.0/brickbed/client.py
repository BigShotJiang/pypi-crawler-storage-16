from brickbed.collection import Collection


class BrickbedClient:
    def __init__(self, endpoint: str, api_key: str):
        self._endpoint = endpoint.rstrip("/")
        self._api_key = api_key

    def collection(self, name: str) -> Collection:
        return Collection(self._endpoint, name, self._api_key)


def createClient(endpoint: str, api_key: str) -> BrickbedClient:
    return BrickbedClient(endpoint, api_key)
