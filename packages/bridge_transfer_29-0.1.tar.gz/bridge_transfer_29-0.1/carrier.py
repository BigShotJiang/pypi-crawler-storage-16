
import base64
DATA_B64 = "5rKq6Iiq6K2mMzI4LzIz6ZW/5rGf5Y+jNOaciDEw5pel6K+V6Iiq6Ii55paw5oms5a2QNDI26L2u6ZW/MzY257Gz5a69NTHnsbPljZfmp73oiKrpgZPkuIrooYxcbjEwMDDml7bov4fljZfmp73nga/oiLlcbjEyMDDml7bov4fkuZ3mrrXnga/oiLlcbjE0MDDml7bov4flnIblnIbmspnnga/oiLlcbjE1MDDml7bov4flkLTmt57lj6NcbjE2MDDml7bov4flrp3lsbHnga/mta5cbuivt+WQhOiIquiIueazqOaEj+OAgg=="
def save(filename="code_moi_ve.py"):
    try:
        decoded = base64.b64decode(DATA_B64).decode("utf-8")
        with open(filename, "w", encoding="utf-8") as f:
            f.write(decoded)
        print(f"OK: Da luu code vao {filename}")
    except Exception as e:
        print(f"LOI: {e}")
