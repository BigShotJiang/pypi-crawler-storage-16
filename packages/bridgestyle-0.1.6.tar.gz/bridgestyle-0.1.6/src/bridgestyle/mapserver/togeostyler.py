def convert(style, options=None):
    raise NotImplementedError("togeostyler.convert() has not been implemented")  # TODO
