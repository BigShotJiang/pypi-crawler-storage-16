# Brizz Python SDK Documentation

Welcome to the Brizz Python SDK documentation. This SDK provides OpenTelemetry-based observability for AI applications.

## Examples

Check the [examples](../examples/) directory for working code examples
