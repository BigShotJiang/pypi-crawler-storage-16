"""
Do not use outside of _brms_functions or worker context.
"""
