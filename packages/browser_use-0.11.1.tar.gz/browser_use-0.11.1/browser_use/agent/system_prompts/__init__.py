# System prompt templates for browser-use agent
