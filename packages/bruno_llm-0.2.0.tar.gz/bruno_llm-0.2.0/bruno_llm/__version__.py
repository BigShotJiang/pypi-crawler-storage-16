"""Version information for bruno-llm."""

__version__ = "0.2.0"
__author__ = "Meggy AI"
__email__ = "contact@meggy.ai"
__license__ = "MIT"
__description__ = "LLM and embedding provider implementations for bruno-core framework"
