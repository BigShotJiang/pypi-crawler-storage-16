"""
PostgreSQL backend for bruno-memory.
"""

from .backend import PostgreSQLMemoryBackend

__all__ = ["PostgreSQLMemoryBackend"]
