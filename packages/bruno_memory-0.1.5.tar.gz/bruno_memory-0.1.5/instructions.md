This repo is part of meggy-ai platform which contains following components:
GitHub Organization: "bruno-ai"
├── Repository: bruno-core
├── Repository: bruno-llm  
├── Repository: bruno-memory
├── Repository: bruno-abilities
└── Repository: bruno-pa

I have completed bruno-core and bruno-llm and their repos are at following links : 
https://github.com/meggy-ai/bruno-core
https://github.com/meggy-ai/bruno-llm

I have also finished code for bruno-memory for this repo,
we need to work on next steps,
last time when we developed features for this library
some of the tests failed because we dont have redis and postgres
running, i would like to set up docker for different environments
so that we can run those test and test our library completely,
create docker compose files so that we can have the environment 
ready and then run the test so that we can check the library
throughly


1.0 You need to create a plan first with parent tasks and children tasks
2.0 Create a progress tracker in the plan so that we will keep track of the 
    implementation phase by phase, in case you will doing a particular task
    we will know where we left off and what to do next
3.0 After creating plan we will start implementation one by one
4.0 create an md file for the plan 
