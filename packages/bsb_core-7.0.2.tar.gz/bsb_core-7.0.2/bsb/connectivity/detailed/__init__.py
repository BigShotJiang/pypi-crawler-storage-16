# ruff: noqa: F401
# This barrel file contains intentional import shortcuts
from .voxel_intersection import VoxelIntersection
