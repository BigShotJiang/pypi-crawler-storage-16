from .models import BsddClass  # stub module for PyInstaller
