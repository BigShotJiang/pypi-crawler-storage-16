from .models import BsddClassProperty  # stub module for PyInstaller
