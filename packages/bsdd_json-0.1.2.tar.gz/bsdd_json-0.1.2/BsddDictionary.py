from .models import BsddDictionary  # stub module for PyInstaller
