from .models import BsddProperty  # stub module for PyInstaller
