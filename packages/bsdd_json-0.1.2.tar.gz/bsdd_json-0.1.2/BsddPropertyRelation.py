from .models import BsddPropertyRelation  # stub module for PyInstaller
