# bseqgen

Library for generating binary sequences.
(IN PROGRESS)
