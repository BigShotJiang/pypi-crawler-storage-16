from django.apps import AppConfig


class SignManagerConfig(AppConfig):
    name = 'sign_manager'
    verbose_name = 'Подписи'

