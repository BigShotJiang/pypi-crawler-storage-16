from budgetbuddy.ui.main import BudgetBuddyApp, run
