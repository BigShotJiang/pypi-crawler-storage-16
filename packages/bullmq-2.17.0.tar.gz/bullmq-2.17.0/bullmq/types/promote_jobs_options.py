
from typing import TypedDict


class PromoteJobsOptions(TypedDict, total=False):
    count: int
