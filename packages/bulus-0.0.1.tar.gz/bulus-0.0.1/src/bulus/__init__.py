"""bulus package initialization."""

from .core import IceLedger

__version__ = "0.0.1"

__all__ = ["IceLedger", "__version__"]
