"""Main entrypoint for module."""

from bumpversion.cli import cli

cli()
