"""Module for managing Versions and their internal parts."""
