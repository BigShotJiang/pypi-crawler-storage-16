# CLI Reference

::: mkdocs-click
    :module: bumpversion.cli
    :command: cli
    :prog_name: bump-my-version
    :style: table
    :list_subcommands: true
