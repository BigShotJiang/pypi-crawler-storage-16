# DO NOT CHANGE ANY CODE BELOW
# This file is generated automatically by `generate_api_schema.py` and will be overwritten
# Instead, change functions / models by subclassing them in the `./overwrites/` folder. They will be used instead.


from bungio.models.base import BaseEnum


class DropStateEnum(BaseEnum):
    """
    _No description given by bungie._
    """

    CLAIMED = 0
    """_No description given by bungie._ """
    APPLIED = 1
    """_No description given by bungie._ """
    FULFILLED = 2
    """_No description given by bungie._ """
