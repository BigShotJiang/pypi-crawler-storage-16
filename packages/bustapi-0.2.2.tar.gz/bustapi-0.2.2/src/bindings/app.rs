//! PyO3 bindings with Actix-web integration
//! Optimized for Python 3.13 free-threaded mode (no GIL bottleneck)

use pyo3::prelude::*;
use std::sync::Arc;
use tokio::runtime::Runtime;

use crate::server::{start_server, AppState, FastRouteHandler, ServerConfig};

/// Python wrapper for the BustAPI application
#[pyclass]
pub struct PyBustApp {
    state: Arc<AppState>,
    runtime: Runtime,
}

#[pymethods]
impl PyBustApp {
    #[new]
    pub fn new() -> PyResult<Self> {
        // Create an optimized Tokio runtime for high performance
        let cpu_count = num_cpus::get();
        let runtime = tokio::runtime::Builder::new_multi_thread()
            .enable_all()
            .worker_threads(cpu_count)
            .max_blocking_threads(cpu_count * 4)
            .thread_name("bustapi-worker")
            .build()
            .map_err(|e| {
                pyo3::exceptions::PyRuntimeError::new_err(format!(
                    "Failed to create async runtime: {}",
                    e
                ))
            })?;

        Ok(Self {
            state: Arc::new(AppState::new()),
            runtime,
        })
    }

    /// Add a route with a Python handler
    pub fn add_route(&self, method: &str, path: &str, handler: PyObject) -> PyResult<()> {
        let py_handler = crate::bindings::handlers::PyRouteHandler::new(handler);

        // Use blocking task to add route
        let state = self.state.clone();
        let method_enum = std::str::FromStr::from_str(method)
            .map_err(|_| pyo3::exceptions::PyValueError::new_err("Invalid HTTP method"))?;
        let path = path.to_string();

        self.runtime.block_on(async {
            let mut routes = state.routes.write().await;
            routes.add_route(method_enum, path, py_handler);
        });

        Ok(())
    }

    /// Add an async route with a Python handler
    pub fn add_async_route(&self, method: &str, path: &str, handler: PyObject) -> PyResult<()> {
        let py_handler = crate::bindings::handlers::PyAsyncRouteHandler::new(handler);

        let state = self.state.clone();
        let method_enum = std::str::FromStr::from_str(method)
            .map_err(|_| pyo3::exceptions::PyValueError::new_err("Invalid HTTP method"))?;
        let path = path.to_string();

        self.runtime.block_on(async {
            let mut routes = state.routes.write().await;
            routes.add_route(method_enum, path, py_handler);
        });

        Ok(())
    }

    /// Add a fast Rust-only route (maximum performance, no Python)
    pub fn add_fast_route(&self, method: &str, path: &str, response_body: String) -> PyResult<()> {
        let fast_handler = FastRouteHandler::new(response_body);

        let state = self.state.clone();
        let method_enum = std::str::FromStr::from_str(method)
            .map_err(|_| pyo3::exceptions::PyValueError::new_err("Invalid HTTP method"))?;
        let path = path.to_string();

        self.runtime.block_on(async {
            let mut routes = state.routes.write().await;
            routes.add_route(method_enum, path, fast_handler);
        });

        Ok(())
    }

    /// Run the server
    pub fn run(&self, host: String, port: u16, workers: usize, debug: bool) -> PyResult<()> {
        let state = self.state.clone();
        let config = ServerConfig {
            host,
            port,
            debug,
            workers,
        };

        // Initialize logging if debug is on and not already initialized
        if debug {
            let _ = tracing_subscriber::fmt()
                .with_max_level(tracing::Level::DEBUG)
                .try_init();
        } else {
            let _ = tracing_subscriber::fmt()
                .with_max_level(tracing::Level::INFO)
                .try_init();
        }

        // In Python 3.13 free-threaded, we can release GIL and run full parallel!
        Python::with_gil(|py| {
            py.allow_threads(|| {
                let sys = actix_rt::System::new();
                sys.block_on(start_server(config, state)).unwrap();
            })
        });

        Ok(())
    }
}
