# CHANGELOG


## v0.0.2 (2025-12-10)

### Bug Fixes

- Trigger update flow
  ([`bfe3c09`](https://github.com/buster-so/python-sdk/commit/bfe3c09290fbcc382f585a578a17cdec2cd07c8d))


## v0.0.1 (2025-12-10)

### Bug Fixes

- Missing version tags
  ([`a3220f5`](https://github.com/buster-so/python-sdk/commit/a3220f574e533552beb8a4b9de53110ef65b149e))

- Update build command
  ([`a75842d`](https://github.com/buster-so/python-sdk/commit/a75842dc81c9c7082c6666c07bed8844c4c819d7))

- Update release pipeline
  ([`ed1729c`](https://github.com/buster-so/python-sdk/commit/ed1729c7abb9979a77f382e37e16490d27ebcbcf))

### Chores

- Add gh tokens for release
  ([`9f650f6`](https://github.com/buster-so/python-sdk/commit/9f650f6f5090c958bf7f617f015a350fe37f986c))

- Configure pypi release
  ([`f31c654`](https://github.com/buster-so/python-sdk/commit/f31c654746bf54f7c25fae554f3756eabcdd5c5d))

- Fix broken tests
  ([`1cf4ebd`](https://github.com/buster-so/python-sdk/commit/1cf4ebd199930ac8b2645fff682b56260c359e23))

- Linting
  ([`f88aa6d`](https://github.com/buster-so/python-sdk/commit/f88aa6dbbf57d8d9da5760bfbdb515348047d1c1))

- Linting and abstract code
  ([`ecd4d69`](https://github.com/buster-so/python-sdk/commit/ecd4d6914e4cdb88b38240a5d2db2b9e003ece31))

- Move api version to client
  ([`af43249`](https://github.com/buster-so/python-sdk/commit/af4324923dc15f2cb85377683ad1055e2930d3bc))

- Pass end on client
  ([`781669f`](https://github.com/buster-so/python-sdk/commit/781669f15a7620a66fb33155998de318430de9d5))

- Update the docs
  ([`7800acd`](https://github.com/buster-so/python-sdk/commit/7800acdfe7f755eb85eb0d762a420edef4b21ca7))

- Update token
  ([`747553b`](https://github.com/buster-so/python-sdk/commit/747553b5be43a61712a61050a757f9d4df34400b))
