class NotValidKafkaMessageException(Exception):
    None
