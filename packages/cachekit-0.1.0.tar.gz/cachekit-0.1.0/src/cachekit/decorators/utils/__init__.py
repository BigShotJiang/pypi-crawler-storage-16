"""Utility functions for cachekit decorators."""

__all__: list[str] = []
