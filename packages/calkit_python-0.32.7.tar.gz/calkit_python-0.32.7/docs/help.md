# Help and support

If you notice a bug or have suggestion for a new feature,
use the [issue tracker](https://github.com/calkit/calkit/issues).

To get in touch with the community,
check out the
[discussion forum](https://github.com/orgs/calkit/discussions)
or the
[Discord server](https://discord.gg/ryDkGarc).

If you want to get in touch directly,
feel free to
[send an email](mailto:help@calkit.io).
