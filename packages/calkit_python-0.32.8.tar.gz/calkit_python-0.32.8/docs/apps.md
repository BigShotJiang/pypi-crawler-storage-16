# Apps

A project can define an app to enable users to interact with
and/or make predictions from the results.

See [this project](https://calkit.io/petebachant/nacafoil-openfoam/app)
for an example,
which creates an app with [marimo](https://marimo.io)
and embeds it from [HF Spaces](https://huggingface.co/spaces).
