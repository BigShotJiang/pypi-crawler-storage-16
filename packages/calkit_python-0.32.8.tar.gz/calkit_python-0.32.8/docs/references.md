# References

Each project can contain one or more reference collections.
These are typically stored as `.bib` files,
and listed in the `references` section of the
[`calkit.yaml` file](calkit-yaml.md).
