"""Example domain models for Talos."""
