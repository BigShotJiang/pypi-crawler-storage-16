"""Graph and node management for Talos."""
