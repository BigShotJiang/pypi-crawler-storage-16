"""Security System sensor types and classes."""

from __future__ import annotations

from enum import Enum, IntEnum
from typing import Protocol, runtime_checkable

from .base import Sensor, SensorLike
from .types import SensorCategory, SensorType


class SecuritySystemState(IntEnum):
    """Security System state values (HomeKit compatible)."""

    StayArm = 0  # Home/Stay armed
    AwayArm = 1  # Away armed
    NightArm = 2  # Night armed
    Disarmed = 3  # Disarmed
    AlarmTriggered = 4  # Alarm triggered (CurrentState only)


class SecuritySystemProperty(str, Enum):
    """Security System property keys."""

    CurrentState = "currentState"  # Read-only (0-4)
    TargetState = "targetState"  # Read/Write (0-3)


@runtime_checkable
class SecuritySystemLike(SensorLike, Protocol):
    """Protocol for security system type checking."""

    @property
    def currentState(self) -> SecuritySystemState:
        """Current security system state (read-only)."""
        ...

    @property
    def targetState(self) -> SecuritySystemState:
        """Target security system state."""
        ...

    def arm(self, mode: SecuritySystemState) -> None:
        """Arm the security system."""
        ...

    def disarm(self) -> None:
        """Disarm the security system."""
        ...

    def triggerAlarm(self) -> None:
        """Trigger the alarm."""
        ...

    def resetAlarm(self) -> None:
        """Reset the alarm to target state."""
        ...


class SecuritySystem(Sensor[dict[str, object], dict[str, object], str]):
    """
    Security System Control.

    Bidirectional control for security/alarm systems.
    Compatible with HomeKit SecuritySystem service.

    Properties:
        currentState: Read-only, reflects actual system state (0-4)
        targetState: Read/write, what user wants (0-3, no ALARM_TRIGGERED)
    """

    _requires_frames = False

    def __init__(self, name: str = "Security System") -> None:
        super().__init__(name)
        # Initialize defaults - disarmed
        self._setProperty(SecuritySystemProperty.CurrentState, SecuritySystemState.Disarmed)
        self._setProperty(SecuritySystemProperty.TargetState, SecuritySystemState.Disarmed)

    @property
    def type(self) -> SensorType:
        return SensorType.SecuritySystem

    @property
    def category(self) -> SensorCategory:
        return SensorCategory.Control

    @property
    def currentState(self) -> SecuritySystemState:
        """Current security system state (read-only from external perspective)."""
        value = self.getPropertyValue(SecuritySystemProperty.CurrentState)
        return SecuritySystemState(value) if value is not None else SecuritySystemState.Disarmed

    @currentState.setter
    def currentState(self, value: SecuritySystemState) -> None:
        """Set current state (for plugin use - e.g., when alarm is triggered)."""
        self._setProperty(SecuritySystemProperty.CurrentState, int(value))

    @property
    def targetState(self) -> SecuritySystemState:
        """Target security system state."""
        value = self.getPropertyValue(SecuritySystemProperty.TargetState)
        return SecuritySystemState(value) if value is not None else SecuritySystemState.Disarmed

    @targetState.setter
    def targetState(self, value: SecuritySystemState) -> None:
        """Set target state (user request)."""
        # Target state cannot be ALARM_TRIGGERED
        if value == SecuritySystemState.AlarmTriggered:
            return
        self._setProperty(SecuritySystemProperty.TargetState, int(value))

    # Convenience methods

    def arm(self, mode: SecuritySystemState = SecuritySystemState.AwayArm) -> None:
        """
        Arm the security system.

        Args:
            mode: Arm mode (StayArm, AwayArm, NightArm). Default: AwayArm
        """
        if mode == SecuritySystemState.AlarmTriggered or mode == SecuritySystemState.Disarmed:
            return
        self.targetState = mode
        self.currentState = mode

    def disarm(self) -> None:
        """Disarm the security system."""
        self.targetState = SecuritySystemState.Disarmed
        self.currentState = SecuritySystemState.Disarmed

    def triggerAlarm(self) -> None:
        """Trigger the alarm (sets currentState to AlarmTriggered)."""
        self.currentState = SecuritySystemState.AlarmTriggered

    def resetAlarm(self) -> None:
        """Reset the alarm - returns currentState to targetState."""
        self.currentState = self.targetState

    def armStay(self) -> None:
        """Arm in Stay/Home mode."""
        self.arm(SecuritySystemState.StayArm)

    def armAway(self) -> None:
        """Arm in Away mode."""
        self.arm(SecuritySystemState.AwayArm)

    def armNight(self) -> None:
        """Arm in Night mode."""
        self.arm(SecuritySystemState.NightArm)
