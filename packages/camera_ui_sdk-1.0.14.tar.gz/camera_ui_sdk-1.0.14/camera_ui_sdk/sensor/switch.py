"""Switch control sensor types and classes."""

from __future__ import annotations

from enum import Enum
from typing import Protocol, runtime_checkable

from .base import Sensor, SensorLike
from .types import SensorCategory, SensorType


class SwitchProperty(str, Enum):
    """Switch control properties."""

    On = "on"


@runtime_checkable
class SwitchControlLike(SensorLike, Protocol):
    """Protocol for switch control type checking."""

    @property
    def on(self) -> bool:
        """Whether switch is on."""
        ...

    def turnOn(self) -> None:
        """Turn switch on."""
        ...

    def turnOff(self) -> None:
        """Turn switch off."""
        ...

    def toggle(self) -> None:
        """Toggle switch state."""
        ...


class SwitchControl(Sensor[dict[str, object], dict[str, object], str]):
    """
    Switch Control.

    Simple on/off control for smart plugs, relays, and generic switches.
    Properties can be set directly: `switch.on = True`
    """

    _requires_frames = False

    def __init__(self, name: str = "Switch") -> None:
        super().__init__(name)
        # Initialize defaults
        self._setProperty(SwitchProperty.On, False)

    @property
    def type(self) -> SensorType:
        return SensorType.Switch

    @property
    def category(self) -> SensorCategory:
        return SensorCategory.Control

    @property
    def on(self) -> bool:
        """Whether switch is on."""
        return self.getPropertyValue(SwitchProperty.On) or False

    @on.setter
    def on(self, value: bool) -> None:
        self._setProperty(SwitchProperty.On, value)

    # RPC methods (camelCase for compatibility)

    def turnOn(self) -> None:
        """Turn switch on."""
        self.on = True

    def turnOff(self) -> None:
        """Turn switch off."""
        self.on = False

    def toggle(self) -> None:
        """Toggle switch state."""
        self.on = not self.on
