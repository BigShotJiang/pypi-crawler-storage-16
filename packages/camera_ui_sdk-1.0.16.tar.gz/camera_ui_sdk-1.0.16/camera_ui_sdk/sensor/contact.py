"""Contact sensor types and classes."""

from __future__ import annotations

from abc import ABC
from enum import Enum
from typing import Protocol, runtime_checkable

from .base import Sensor, SensorLike
from .types import SensorCategory, SensorType


class ContactProperty(str, Enum):
    """Contact sensor properties."""

    Detected = "detected"


@runtime_checkable
class ContactSensorLike(SensorLike, Protocol):
    """Protocol for contact sensor type checking."""

    @property
    def detected(self) -> bool:
        """Whether contact is detected (door/window open)."""
        ...


class ContactSensor(Sensor[dict[str, object], dict[str, object], str], ABC):
    """
    Contact sensor for door/window open/closed detection.

    Use this class for door/window sensors.
    """

    _requires_frames = False

    def __init__(self, name: str = "Contact Sensor") -> None:
        """
        Create a new contact sensor instance.

        Args:
            name: Stable name for the sensor (used as storage key)
        """
        super().__init__(name)

        # Initialize defaults (directly in store to avoid triggering RPC before init)
        self._properties_store[ContactProperty.Detected] = False

    @property
    def type(self) -> SensorType:
        return SensorType.Contact

    @property
    def category(self) -> SensorCategory:
        return SensorCategory.Sensor

    @property
    def detected(self) -> bool:
        """Whether contact is detected (door/window open)."""
        return self.rawProps.get(ContactProperty.Detected) or False

    @detected.setter
    def detected(self, value: bool) -> None:
        self.props.detected = value
