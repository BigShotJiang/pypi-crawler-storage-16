"""Motion sensor types and classes."""

from __future__ import annotations

from abc import ABC, abstractmethod
from enum import Enum
from typing import TYPE_CHECKING, Protocol, runtime_checkable

from .base import Sensor, SensorLike
from .types import Detection, SensorCategory, SensorType

if TYPE_CHECKING:
    from ..plugin.interfaces import MotionResult, VideoFrameData, VideoInputProperties


class MotionProperty(str, Enum):
    """Motion sensor properties."""

    Detected = "detected"
    Detections = "detections"
    Blocked = "blocked"


@runtime_checkable
class MotionSensorLike(SensorLike, Protocol):
    """Protocol for motion sensor type checking."""

    @property
    def detected(self) -> bool:
        """Whether motion is currently detected."""
        ...

    @property
    def detections(self) -> list[Detection]:
        """Current motion detections."""
        ...

    @property
    def blocked(self) -> bool:
        """Whether the sensor is blocked (read-only, managed by backend)."""
        ...

    def setMotion(self, detected: bool, detections: list[Detection] | None = None) -> None:
        """Set motion state (ignored if blocked)."""
        ...

    def clearMotion(self) -> None:
        """Clear motion state (ignored if blocked)."""
        ...


@runtime_checkable
class MotionDetectorSensorLike(MotionSensorLike, Protocol):
    """Protocol for frame-based motion detector sensor."""

    @property
    def inputProperties(self) -> VideoInputProperties:
        """Required input frame properties."""
        ...

    async def detectMotion(self, frame: VideoFrameData) -> MotionResult:
        """Detect motion in a frame."""
        ...


class MotionSensor(Sensor[dict[str, object], dict[str, object], str], ABC):
    """
    Base motion sensor for external triggers (Ring, ONVIF, SMTP).

    Use this class when motion detection is provided by an external source
    (e.g., camera firmware, cloud service, or SMTP notifications).
    """

    _requires_frames = False

    def __init__(self, name: str = "Motion Sensor") -> None:
        """
        Create a new motion sensor instance.

        Args:
            name: Stable name for the sensor (used as storage key)
        """
        super().__init__(name)

        # Initialize defaults (directly in store to avoid triggering RPC before init)
        self._properties_store[MotionProperty.Detected] = False
        self._properties_store[MotionProperty.Detections] = []
        self._properties_store[MotionProperty.Blocked] = False

    @property
    def type(self) -> SensorType:
        return SensorType.Motion

    @property
    def category(self) -> SensorCategory:
        return SensorCategory.Sensor

    @property
    def detected(self) -> bool:
        """Whether motion is currently detected."""
        return self.rawProps.get(MotionProperty.Detected) or False

    @detected.setter
    def detected(self, value: bool) -> None:
        """Set motion detected state (ignored if sensor is blocked)."""
        if self.rawProps.get(MotionProperty.Blocked):
            return
        self.props.detected = value

    @property
    def detections(self) -> list[Detection]:
        """Current motion detections."""
        return self.rawProps.get(MotionProperty.Detections) or []

    @detections.setter
    def detections(self, value: list[Detection]) -> None:
        """Set motion detections (ignored if sensor is blocked)."""
        if self.rawProps.get(MotionProperty.Blocked):
            return
        self.props.detections = value

    @property
    def blocked(self) -> bool:
        """
        Whether the sensor is currently blocked (read-only).

        When blocked, state changes are ignored by the backend during dwell time.
        This is managed by the backend - plugins cannot set this.
        """
        return self.rawProps.get(MotionProperty.Blocked) or False

    # RPC methods (camelCase for compatibility)

    def setMotion(self, detected: bool, detections: list[Detection] | None = None) -> None:
        """
        Set motion state (ignored if sensor is blocked).

        Args:
            detected: Whether motion is detected
            detections: Optional list of detection regions
        """
        if self.rawProps.get(MotionProperty.Blocked):
            return
        self.props.detected = detected
        if detections is not None:
            self.props.detections = detections

    def clearMotion(self) -> None:
        """Clear motion state (ignored if sensor is blocked)."""
        if self.rawProps.get(MotionProperty.Blocked):
            return
        self.props.detected = False
        self.props.detections = []


class MotionDetectorSensor(MotionSensor):
    """
    Frame-based motion detector (rust-motion, OpenCV, etc.).

    Use this class when implementing a motion detection plugin that
    processes video frames to detect motion.

    Subclasses must implement:
        - inputProperties: Define required frame format
        - detectMotion: Process frame and return detection result
    """

    _requires_frames = True

    @property
    @abstractmethod
    def inputProperties(self) -> VideoInputProperties:
        """
        Define required frame format.

        Returns:
            VideoInputProperties with width, height, and format
        """
        ...

    @abstractmethod
    async def detectMotion(self, frame: VideoFrameData) -> MotionResult:
        """
        Process frame and return detection result.

        Args:
            frame: Video frame data

        Returns:
            MotionResult with detected flag and detection regions
        """
        ...
