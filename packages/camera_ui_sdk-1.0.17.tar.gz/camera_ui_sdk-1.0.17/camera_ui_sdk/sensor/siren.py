"""Siren control sensor types and classes."""

from __future__ import annotations

import asyncio
from abc import ABC
from enum import Enum
from typing import Protocol, runtime_checkable

from .base import Sensor, SensorLike
from .types import SensorCategory, SensorType


class SirenCapability(str, Enum):
    """Siren capabilities - describes what features this siren supports."""

    Volume = "volume"


class SirenProperty(str, Enum):
    """Siren control properties."""

    Active = "active"
    Volume = "volume"


@runtime_checkable
class SirenControlLike(SensorLike, Protocol):
    """Protocol for siren control type checking."""

    @property
    def active(self) -> bool:
        """Whether siren is active."""
        ...

    @property
    def volume(self) -> int:
        """Volume level (0-100)."""
        ...

    def activate(self) -> None:
        """Activate siren."""
        ...

    def deactivate(self) -> None:
        """Deactivate siren."""
        ...

    async def soundFor(self, durationMs: int) -> None:
        """Sound siren for a duration."""
        ...


class SirenControl(Sensor[dict[str, object], dict[str, object], SirenCapability], ABC):
    """
    Siren Control.

    Bidirectional control for camera siren/alarm.
    Properties can be set directly: `siren.active = True`
    """

    _requires_frames = False

    def __init__(self, name: str = "Siren") -> None:
        super().__init__(name)

        # Initialize defaults (directly in store to avoid triggering RPC before init)
        self._properties_store[SirenProperty.Active] = False
        self._properties_store[SirenProperty.Volume] = 100

    @property
    def type(self) -> SensorType:
        return SensorType.Siren

    @property
    def category(self) -> SensorCategory:
        return SensorCategory.Control

    @property
    def active(self) -> bool:
        """Whether siren is active."""
        return self.rawProps.get(SirenProperty.Active) or False

    @active.setter
    def active(self, value: bool) -> None:
        self.props.active = value

    @property
    def volume(self) -> int:
        """Volume level (0-100)."""
        return self.rawProps.get(SirenProperty.Volume) or 100

    @volume.setter
    def volume(self, value: int) -> None:
        self.props.volume = max(0, min(100, value))

    # RPC methods (camelCase for compatibility)

    def activate(self) -> None:
        """Activate siren."""
        self.active = True

    def deactivate(self) -> None:
        """Deactivate siren."""
        self.active = False

    async def soundFor(self, durationMs: int) -> None:
        """
        Sound siren for a duration.

        Args:
            durationMs: Duration to sound siren in milliseconds
        """
        self.activate()
        await asyncio.sleep(durationMs / 1000)
        self.deactivate()
