

from setuptools import setup, find_packages

setup(
  name = 'cannondesign',
  packages = ['CannonDesign'],
  version = '0.0.2',
  license= 'Proprietary License',
  description = 'This is python package was developed by NeuMod Labs for CannonDesign.',
  author = 'Sagar Rao',
  author_email = 'sagar.rao@neumodlabs.com',      # Type in your E-Mail
  url = '',
  download_url = '',
  keywords = ['CannonDesign','Building Performance Modeling', 'Trace 3D',
              'EnergyPlus', 'Building Energy Modeling', 'Workflow Automation'],
  install_requires=[
          '',
          '',
      ],
  classifiers=[
    'Development Status :: 3 - Alpha',      # Chose either "3 - Alpha", "4 - Beta" or "5 - Production/Stable" as the current state of your package
    'Intended Audience :: Developers',      # Define that your audience are developers
    'Intended Audience :: Science/Research',
    'Topic :: Software Development :: Build Tools',
    'License :: Other/Proprietary License',
    'Programming Language :: Python :: 3',      #Specify which pyhton versions that you want to support
    'Programming Language :: Python :: 3.5',
    'Programming Language :: Python :: 3.6',
    'Programming Language :: Python :: 3.7',
    'Programming Language :: Python :: 3.8',
    'Programming Language :: Python :: 3.9',
    'Programming Language :: Python :: 3.10',
  ],
)