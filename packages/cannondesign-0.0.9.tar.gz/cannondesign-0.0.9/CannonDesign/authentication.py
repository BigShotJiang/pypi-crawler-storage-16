# -*- coding: utf-8 -*-
"""
Created on Fri Aug 15 05:45:19 2025

@author: sagar
"""

import socket

def get_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    ip = ''
    try:
        s.connect(('10.255.255.255', 1))
        ip = s.getsockname()[0]
    except:
        ip = '127.0.0.1'
    finally:
        s.close()
    return ip


def authenticate(email, api_key):
    auth_dict = {}
    credentials = {}
    credentials['email'] = email
    credentials['api_key'] = api_key
    credentials['device_name'] = socket.gethostname()
    credentials['device_ip'] = get_ip()
    auth_dict['Authentication'] = credentials
    return auth_dict
        
