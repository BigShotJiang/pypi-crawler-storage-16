import datetime
import pandas as pd
from. import utilities as util

class AtomizingHumidifier():
    def __init__(self):
        pass

    
    def package_ah_inputs(self, ah_params, energy_model_outputs):
        api_response = {}
        api_response['status_code'] = 102
        api_response['data'] = {}
        api_response['data']['message'] = '' 
        api_response['data']['file'] = energy_model_outputs
        api_response['data']['calculation_inputs'] = {}
        api_response['data']['calculation_settings'] = ah_params
        api_response['data']['calculation_outputs'] = {}
        calculation_inputs = {}
        calculation_inputs_dict = {}


        if util.check_file(energy_model_outputs) == 0:
            return api_response

        try:
            print('\nExtracting energy modeling outputs to for exceptional calculations...')

            systems = list(ah_params.keys())
            df = (pd.read_excel(
                    energy_model_outputs,
                    sheet_name=0,
                    header=[0, 1, 2],
                    dtype={
                        ('Unnamed: 0_level_0', 'Unnamed: 0_level_1', 'Timestamp'): str
                    },
                    parse_dates=False,
                )
                .fillna("")
            )

            df.columns = [' | '.join(map(str, col)).strip() for col in df.columns.values]
            cols = df.columns
            col_set = set(cols)  # O(1) membership tests

            expected_variables = [
                'Airflow | Airflow [lb/hr]',
                'Heating Coil Inlet | Dry Bulb Temperature [F]',
                'Heating Coil Inlet | Humidity Ratio [lb/lb]',
                'Heating Coil Outlet | Dry Bulb Temperature [F]',
                'Heating Coil Outlet | Humidity Ratio [lb/lb]',
                'Humidifier Outlet | Dry Bulb Temperature [F]',
                'Humidifier Outlet | Humidity Ratio [lb/lb]',
            ]

            calculation_inputs_dict = {}
            missing = []

            timestamp_col = next((c for c in cols if 'Timestamp' in c), None)
            if timestamp_col is not None:
                calculation_inputs_dict['Timestamp'] = df[timestamp_col].tolist()
            else:
                missing.append('Timestamp')

            for system in systems:
                for var in expected_variables:
                    expected_col = f'{system} | {var}'
                    if expected_col in col_set:
                        calculation_inputs_dict[expected_col] = df[expected_col].tolist()
                    else:
                        missing.append(expected_col)

            if not missing:
                api_response['status_code'] = 101
                api_response['data']['calculation_inputs'] = calculation_inputs_dict
            else:
                api_response['status_code'] = 104
                api_response['data']['missing_columns'] = missing

                api_response['data']['message'] = (
                    'Input file schema does not meet requirements. '
                    'Check system names and ensure all column headers are included: '
                    'a timestamp column, and inlet/outlet dry-bulb temperature and '
                    'humidity ratio for the heating coil and steam humidifier for each system. '
                    'The following expected columns are missing:'
                    + str(missing)
                )

            return api_response

        except:
            api_response['status_code'] = 103
            api_response['data']['message'] = 'Unable to read excel file. Make sure you are using the right input spreadhseet.'
            return api_response


    def make_file_timestamp(self):
        timestamp = datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0).isoformat().replace('+00:00','Z')
        day, time = timestamp.replace('-','').replace(':','').split('T')
        timestamp = day+time[:-1]
        return timestamp


    def write_outputs(self, api_response):
        try:

            print('Writing hourly outputs to Excel file...')

            output_file = api_response['data']['file']
            output_file = output_file.replace('ah.xlsx', self.make_file_timestamp() + '.xlsx')

            hourly_values = api_response['data']['calculation_outputs']

            df = pd.DataFrame.from_dict(hourly_values, orient='index').T
            df = df.where(pd.notna(df), '')
            with pd.ExcelWriter(output_file, engine='xlsxwriter') as writer:
                df.to_excel(writer, sheet_name='Sheet1', index=False)
                worksheet = writer.sheets['Sheet1']
                worksheet.set_column(0, len(df.columns) - 1, 14)           

        except:
            raise Exception('Unable to write exceptional calculations to local system.')


    def add_atomizing_humidifier(self, auth_dict, ah_params, energy_model_outputs):

        '''
        api_response = {
            'status_code': '',
            'data': {
                'message': '',
                'file': '',
                'calculation_inputs': {
                    '': [],
                'calculation_settings': ah_params,
                'calculation_outputs': {
                    '': []                
                    }
            }
        }

        status - 
        101: data packaging successful
        102: excel file does not exist
        103: incompatible excel file
        104: file does not meet schema requirements
        122: exceptional calculations failed        
        '''

        api_response = {}
        api_response['status_code'] = ''
        api_response['data'] = {} 
        api_response['data']['message'] = '' 
        api_response['data']['file'] = '' 
        api_response['data']['calculation_inputs'] = {} 
        api_response['data']['calculation_settings'] = ah_params
        api_response['data']['calculation_outputs'] = {}

        api_response = self.package_ah_inputs(ah_params, energy_model_outputs)

        if api_response['status_code'] == 101:
            action = 'add_atomizing_humidifier'
            params = [api_response]
            print('Calling NeuMod Labs API...')
            api_response = util.neumodlabs(auth_dict, action, params)

            print('Exception calculation complete...')
            self.write_outputs(api_response)
            print('Results for atomizing humidifer were written to file: ' + api_response['data']['file'])

        elif api_response['status_code'] == 102:
            raise FileNotFoundError(api_response['data']['file'])

        elif api_response['status_code'] == 103:
            raise Exception(api_response['data']['message'])

        elif api_response['status_code'] == 104:
            raise Exception(api_response['data']['message'])

        elif api_response['status_code'] == 122:
            raise Exception('Exceptional calculations could not be performed. Check input values and try again.')
