# -*- coding: utf-8 -*-
"""
Created on Fri Aug 15 05:45:19 2025

@author: sagar
"""

from. import utilities as util

class TeamManagement():
    def __init__(self):
        pass

    def create_new_user(self, auth_dict, first_name, last_name, email):
        action = 'create_new_user'
        params = [first_name, last_name, email]
        api_response = util.neumodlabs(auth_dict, action, params)
        util.print_formatted_json_utf8(api_response['data'])
    
    def make_admin(self, auth_dict, email):
        action = 'make_user_admin'
        params = [email]
        api_response = util.neumodlabs(auth_dict, action, params)
        util.print_formatted_json_utf8(api_response['data'])

    def deactivate_user(self, auth_dict, email):
        action = 'deactivate_user'
        params = [email]
        api_response = util.neumodlabs(auth_dict, action, params)
        util.print_formatted_json_utf8(api_response['data'])

    def reactivate_user(self, auth_dict, email):
        action = 'reactivate_user'
        params = [email]
        api_response = util.neumodlabs(auth_dict, action, params)
        util.print_formatted_json_utf8(api_response['data'])
        
    def reset_api_key(self, auth_dict, master_key, email):
        action = 'reset_api_key'
        params = [master_key, email]
        api_response = util.neumodlabs(auth_dict, action, params)
        util.print_formatted_json_utf8(api_response['data'])
