import os 
import json 
import requests


def read_json_utf8(file):
    try:
        with open(file, encoding='utf-8', errors='ignore') as json_file:
            return json.load(json_file)
    except:
        return 0, 'unable to read file - ' + file


def write_json_utf8(json_output_file, output_dict):
    try:
        with open(json_output_file, 'w+', encoding='utf-8') as json_file:
            json.dump(output_dict, json_file, sort_keys=False, ensure_ascii=False)
        return 1
    except:
        return 0, 'unable to write file - ' + json_output_file


def print_formatted_json_utf8(json_dict):
    try:
        print(json.dumps(json_dict, ensure_ascii=False, indent=2))
    except:
        return 0, 'unable to print dict'


def check_file(file):
    file_exists = 0
    if os.path.isfile(file) == True:
        file_exists = 1
    return file_exists


def neumodlabs(data_package, action, params):
    api_dict = {}
    api_dict['action'] = action
    api_dict['params'] = params
    data_package['API'] = api_dict

    #Call NML API
    nml_api_url = 'http://api.neumodlabs.com/cannondesign/'

    #Test URL
    # nml_api_url = 'http://127.0.0.1:8000/cannondesign/'

    server_response = requests.post(nml_api_url, json = data_package).json()
    return server_response   