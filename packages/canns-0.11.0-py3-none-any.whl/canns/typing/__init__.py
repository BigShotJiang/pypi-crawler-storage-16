from collections.abc import Sequence

Iext_type = float
Iext_pair_type = Sequence[Iext_type]  # For 2D coordinates like [x, y] or (x, y)

time_type = float
