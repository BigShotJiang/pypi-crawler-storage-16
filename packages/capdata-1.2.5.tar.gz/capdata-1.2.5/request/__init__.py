#! /usr/bin/env python
# coding=utf-8

PATH = "https://www.capdata.pro"

# PATH = "http://192.168.3.22"
