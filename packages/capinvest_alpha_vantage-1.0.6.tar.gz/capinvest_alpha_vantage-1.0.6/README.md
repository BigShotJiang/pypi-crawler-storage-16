# CapInvest Alpha Vantage Provider

This extension integrates the [Alpha Vantage](https://www.alphavantage.co/) data provider into the CapInvest Platform.

 