# CapInvest Benzinga Provider

This extension integrates the [Benzinga](https://www.benzinga.com/) data provider into the CapInvest Platform.
 
