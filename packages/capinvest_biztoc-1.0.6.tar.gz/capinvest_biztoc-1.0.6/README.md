# CapInvest Biztoc Provider

This extension integrates the Biztoc data provider
into the CapInvest Platform.

 
