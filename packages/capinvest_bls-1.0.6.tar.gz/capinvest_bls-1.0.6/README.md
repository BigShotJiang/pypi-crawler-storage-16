# BLS Provider Extension

This extension integrates the BLS data provider into the CapInvest Platform.

 
