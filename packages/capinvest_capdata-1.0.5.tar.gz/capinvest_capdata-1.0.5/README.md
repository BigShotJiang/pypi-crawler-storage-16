# CapInvest CapData Provider

This extension integrates the CapData data provider
into the CapInvest Platform.

## Installation

To install the extension, run the following command in this folder:

```bash
pip install capinvest-capdata
```

## 例如新添加一个provider（capdata）

1. 在capinvest_capdata下的_init_.py中添加Provider,特别注意fetcher_dict,这个对应对应的路由
2. 在capinvest_platform下的dev_install.py中添加capinvest-capdata = { path = "./providers/capdata", develop = true }
3. 在capinvest_platform下的pyproject.toml添加对应的依赖,修改三处地方
4. 如果只是在现有的路由中添加一个新的路由，只需要在第一步中修改特别注意fetcher_dict，并编写对应的models
5. 在当前目录下执行pip install .  (poetry lock 命令用于生成poetry.lock文件)
6. 在capinvest_platform下运行python dev_install.py
7. 启动capinvest-api 或者在capinvest_platform/core/capinvest_core/api下执行 python rest_api.py