"""capdata Provider Module."""
from capinvest_core.provider.abstract.provider import Provider
from capinvest_capdata.models.equity_historical import CapdataEquityHistoricalFetcher
from capinvest_capdata.models.etf_historical import CapdataEtfHistoricalFetcher
from capinvest_capdata.models.futures_historical import CapdataFuturesHistoricalFetcher
from capinvest_capdata.models.index_historical import CapdataIndexHistoricalFetcher
from capinvest_capdata.models.yield_curve import CapdataYieldCurveFetcher

capdata_provider = Provider(
    name="capdata",
    website="https://www.caprisktech.com/",
    description="通过获取及时和全面的市场数据和深度业务分析数据，在讯息万变的金融市场中做出基于风险的投资与交易决策。CapData提供为您定制的市场数据、模型数据和合成数据等",
    credentials=["api_key"],  # api_key OR (user_name@_@user_pwd,针对使用用户名和密码的使用@_@分割)
    fetcher_dict={
        "EquityHistorical": CapdataEquityHistoricalFetcher,
        "FuturesHistorical": CapdataFuturesHistoricalFetcher,
        "EtfHistorical": CapdataEtfHistoricalFetcher,
        "YieldCurve": CapdataYieldCurveFetcher,
        "IndexHistorical": CapdataIndexHistoricalFetcher,
    },
    repr_name="CapData Public Data API",
    instructions="Sign up for a free API key here: https://www.caprisktech.com/#/documents/http-documentation",
)
