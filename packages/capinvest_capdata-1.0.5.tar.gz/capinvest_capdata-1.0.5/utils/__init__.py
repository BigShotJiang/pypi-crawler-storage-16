"""CapData."""
