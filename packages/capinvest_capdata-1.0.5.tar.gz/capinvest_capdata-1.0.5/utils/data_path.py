# capdata 认证路径
auth_url = "https://www.capdata.pro/capdata/auth"
# 历史行情路径
history_url = "https://www.capdata.pro/capdata/get/hist/mkt"
# 债券收益率曲线数据路径
bond_yield_curve_url = "https://www.capdata.pro/capdata/get/bond/curve"
# 利率收益率曲线数据路径
ir_yield_curve_url = "https://www.capdata.pro/capdata/get/ir/curve"
