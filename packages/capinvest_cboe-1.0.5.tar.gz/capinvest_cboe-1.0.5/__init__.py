"""Cboe provider module."""

from capinvest_cboe.models.available_indices import CboeAvailableIndicesFetcher
from capinvest_cboe.models.equity_historical import CboeEquityHistoricalFetcher
from capinvest_cboe.models.equity_quote import CboeEquityQuoteFetcher
from capinvest_cboe.models.equity_search import CboeEquitySearchFetcher
from capinvest_cboe.models.futures_curve import CboeFuturesCurveFetcher
from capinvest_cboe.models.index_constituents import (
    CboeIndexConstituentsFetcher,
)
from capinvest_cboe.models.index_historical import (
    CboeIndexHistoricalFetcher,
)
from capinvest_cboe.models.index_search import CboeIndexSearchFetcher
from capinvest_cboe.models.index_snapshots import CboeIndexSnapshotsFetcher
from capinvest_cboe.models.options_chains import CboeOptionsChainsFetcher
from capinvest_core.provider.abstract.provider import Provider

cboe_provider = Provider(
    name="cboe",
    website="https://www.cboe.com",
    description="""Cboe is the world's go-to derivatives and exchange network,
delivering cutting-edge trading, clearing and investment solutions to people
around the world.""",
    credentials=None,
    fetcher_dict={
        "AvailableIndices": CboeAvailableIndicesFetcher,
        "EquityHistorical": CboeEquityHistoricalFetcher,
        "EquityQuote": CboeEquityQuoteFetcher,
        "EquitySearch": CboeEquitySearchFetcher,
        "EtfHistorical": CboeEquityHistoricalFetcher,
        "IndexConstituents": CboeIndexConstituentsFetcher,
        "FuturesCurve": CboeFuturesCurveFetcher,
        "IndexHistorical": CboeIndexHistoricalFetcher,
        "IndexSearch": CboeIndexSearchFetcher,
        "IndexSnapshots": CboeIndexSnapshotsFetcher,
        "OptionsChains": CboeOptionsChainsFetcher,
    },
    repr_name="Chicago Board Options Exchange (CBOE)",
)
