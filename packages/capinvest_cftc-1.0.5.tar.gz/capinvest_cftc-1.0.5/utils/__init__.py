"""CFTC provider extension utilities."""
