"""CapInvest Charting utils."""
