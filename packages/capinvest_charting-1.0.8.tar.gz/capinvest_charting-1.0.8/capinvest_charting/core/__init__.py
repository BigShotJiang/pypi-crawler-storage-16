"""CapInvest Charting core."""
