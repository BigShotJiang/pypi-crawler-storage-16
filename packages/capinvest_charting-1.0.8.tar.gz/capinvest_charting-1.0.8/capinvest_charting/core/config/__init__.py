"""CapInvest Charting core configuration."""
