"""Plotly TA core package."""
