"""Plotly TA Plugins."""
