"""Charting Extension Styles"""
