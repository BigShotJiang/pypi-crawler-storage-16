# Congress.gov Provider

This provider integrates with the Congress.gov API to provide access to U.S. legislative data and text.

 