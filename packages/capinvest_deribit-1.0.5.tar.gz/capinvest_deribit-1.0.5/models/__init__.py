"""Deribit Data Models."""
