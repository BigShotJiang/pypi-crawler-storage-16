"""Deribit Utility Functions."""
