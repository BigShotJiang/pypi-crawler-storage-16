"""ECB Provider Models."""
