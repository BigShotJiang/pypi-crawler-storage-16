"""ECB utils module."""
