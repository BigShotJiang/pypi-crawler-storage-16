# CapInvest EconDB Provider

This extension integrates the [EconDB](https://econdb.com/) data provider into the CapInvest Platform.

 
