"""EconDB Models."""
