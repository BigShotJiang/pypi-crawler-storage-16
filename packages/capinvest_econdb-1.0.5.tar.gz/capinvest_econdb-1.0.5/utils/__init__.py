"""EconDB Utilities."""
