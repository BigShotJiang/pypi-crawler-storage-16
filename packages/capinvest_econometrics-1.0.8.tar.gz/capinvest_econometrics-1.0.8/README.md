# Econometrics extension for CapInvest Platform

This extension provides a set of econometrics tools.

 
