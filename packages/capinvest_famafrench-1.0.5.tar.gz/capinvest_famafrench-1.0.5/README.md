# CapInvest Fama-French Extension

This extension implements the Ken French data library (Source: https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/data_library.html)
as an CapInvest Platform Provider and Router extension.

 