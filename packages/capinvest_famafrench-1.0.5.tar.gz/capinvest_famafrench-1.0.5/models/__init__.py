"""CapInvest Fama-French Models."""
