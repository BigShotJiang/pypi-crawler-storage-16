# CapInvest Federal Reserve Provider

This extension integrates the [Federal Reserve](https://www.federalreserve.gov/data.htm) data provider into the CapInvest Platform.

 
