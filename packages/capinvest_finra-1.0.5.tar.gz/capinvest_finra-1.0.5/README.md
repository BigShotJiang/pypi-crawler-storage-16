# CapInvest FINRA Provider

This extension integrates the [FINRA](https://finra.org/) data provider into the CapInvest Platform.

 
