"""Finviz provider module."""

from capinvest_core.provider.abstract.provider import Provider
from capinvest_finviz.models.compare_groups import FinvizCompareGroupsFetcher
from capinvest_finviz.models.equity_profile import FinvizEquityProfileFetcher
from capinvest_finviz.models.equity_screener import FinvizEquityScreenerFetcher
from capinvest_finviz.models.key_metrics import FinvizKeyMetricsFetcher
from capinvest_finviz.models.price_performance import FinvizPricePerformanceFetcher
from capinvest_finviz.models.price_target import FinvizPriceTargetFetcher

finviz_provider = Provider(
    name="finviz",
    website="https://finviz.com",
    description="Unofficial Finviz API - https://github.com/lit26/finvizfinance/releases",
    credentials=None,
    fetcher_dict={
        "CompareGroups": FinvizCompareGroupsFetcher,
        "EtfPricePerformance": FinvizPricePerformanceFetcher,
        "EquityInfo": FinvizEquityProfileFetcher,
        "EquityScreener": FinvizEquityScreenerFetcher,
        "KeyMetrics": FinvizKeyMetricsFetcher,
        "PricePerformance": FinvizPricePerformanceFetcher,
        "PriceTarget": FinvizPriceTargetFetcher,
    },
    repr_name="FinViz",
)
