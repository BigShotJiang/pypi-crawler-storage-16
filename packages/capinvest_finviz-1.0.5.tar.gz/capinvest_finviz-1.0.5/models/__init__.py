"""Finviz Provider models."""
