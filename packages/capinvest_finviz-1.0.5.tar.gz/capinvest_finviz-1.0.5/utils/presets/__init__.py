"""Finviz Screener Presets."""
