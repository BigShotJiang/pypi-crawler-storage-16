# CapInvest Financial Modeling Prep Provider

This extension integrates the [Financial Modeling Prep](https://site.financialmodelingprep.com/) data provider into the CapInvest Platform.

 
