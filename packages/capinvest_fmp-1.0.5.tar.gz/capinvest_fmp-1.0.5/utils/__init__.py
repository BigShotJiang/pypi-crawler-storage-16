"""FMP utils."""
