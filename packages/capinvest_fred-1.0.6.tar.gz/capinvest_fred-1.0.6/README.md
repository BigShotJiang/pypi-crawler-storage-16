# CapInvest FRED Provider

This extension integrates the [FRED](https://fred.stlouisfed.org/docs/api/fred/) data provider into the CapInvest Platform.

 
