# CapInvest Government US Provider

This extension integrates the [US Government](https://data.gov) data provider into the CapInvest Platform.

 
