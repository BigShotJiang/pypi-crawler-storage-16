"""CIRO Data models."""
