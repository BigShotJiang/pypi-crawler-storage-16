# CapInvest IMF Provider Extension

This package adds the `capinvest-imf` provider extension to the CapInvest Platform.

 