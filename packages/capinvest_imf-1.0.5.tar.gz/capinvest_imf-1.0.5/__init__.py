"""CapInvest IMF Provider Module."""

from capinvest_core.provider.abstract.provider import Provider
from capinvest_imf.models.available_indicators import ImfAvailableIndicatorsFetcher
from capinvest_imf.models.direction_of_trade import ImfDirectionOfTradeFetcher
from capinvest_imf.models.economic_indicators import ImfEconomicIndicatorsFetcher
from capinvest_imf.models.maritime_chokepoint_info import ImfMaritimeChokePointInfoFetcher
from capinvest_imf.models.maritime_chokepoint_volume import (
    ImfMaritimeChokePointVolumeFetcher,
)
from capinvest_imf.models.port_info import ImfPortInfoFetcher
from capinvest_imf.models.port_volume import ImfPortVolumeFetcher

imf_provider = Provider(
    name="imf",
    website="https://datahelp.imf.org/knowledgebase/articles/667681-using-json-restful-web-service",
    description="Access International Monetary Fund (IMF) data APIs.",
    fetcher_dict={
        "AvailableIndicators": ImfAvailableIndicatorsFetcher,
        "DirectionOfTrade": ImfDirectionOfTradeFetcher,
        "EconomicIndicators": ImfEconomicIndicatorsFetcher,
        "MaritimeChokePointInfo": ImfMaritimeChokePointInfoFetcher,
        "MaritimeChokePointVolume": ImfMaritimeChokePointVolumeFetcher,
        "PortInfo": ImfPortInfoFetcher,
        "PortVolume": ImfPortVolumeFetcher,
    },
    repr_name="International Monetary Fund (IMF) Data APIs",
)
