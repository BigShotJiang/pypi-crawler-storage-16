"""CapInvest IMF Provider Models."""
