# CapInvest Intrinio Provider

This extension integrates the [Intrinio](https://intrinio.com/) data provider into the CapInvest Platform.
 
