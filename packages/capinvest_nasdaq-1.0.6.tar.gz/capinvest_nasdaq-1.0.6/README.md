# CapInvest Nasdaq Provider

This extension integrates the [Nasdaq](https://www.nasdaq.com) data provider into the CapInvest Platform.

 
