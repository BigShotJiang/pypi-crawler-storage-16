"""NASDAQ provider data models."""
