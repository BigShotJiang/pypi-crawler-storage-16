"""NASDAQ provider utils."""
