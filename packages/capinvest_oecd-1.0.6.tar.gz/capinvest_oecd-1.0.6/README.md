# CapInvest OECD Provider

This extension integrates the [OECD](https://stats.oecd.org) data provider into the CapInvest Platform.

 
