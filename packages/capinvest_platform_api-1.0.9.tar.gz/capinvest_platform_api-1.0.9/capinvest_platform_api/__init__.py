"""CapInvest Platform API Meta Package."""
