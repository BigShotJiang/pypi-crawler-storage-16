# CapInvest Polygon Provider

This extension integrates the [Polygon](https://polygon.io/) data provider into the CapInvest Platform.

 
