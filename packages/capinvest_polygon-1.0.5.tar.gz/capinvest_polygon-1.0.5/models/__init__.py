"""CapInvest Polygon provider data models."""
