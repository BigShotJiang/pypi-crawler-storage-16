# CapInvest SEC Provider

This extension integrates the [SEC](https://www.sec.gov/edgar) data provider into the CapInvest Platform.

 
