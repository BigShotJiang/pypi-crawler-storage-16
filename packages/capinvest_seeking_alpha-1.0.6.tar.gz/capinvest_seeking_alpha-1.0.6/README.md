# CapInvest Seeking Alpha Provider

This extension integrates the [Seeking Alpha](https://seekingalpha.com) data provider into the CapInvest Platform.

 
