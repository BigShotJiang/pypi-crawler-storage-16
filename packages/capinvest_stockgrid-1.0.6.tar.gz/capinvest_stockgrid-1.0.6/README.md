# CapInvest Stockgrid Provider

This extension integrates the [Stockgrid](https://Stockgrid.io/) data provider into the CapInvest Platform.
 
