# CapInvest Tiingo Provider

This extension integrates the [Tiingo](https://www.tiingo.com/) data provider into the CapInvest Platform.

 
