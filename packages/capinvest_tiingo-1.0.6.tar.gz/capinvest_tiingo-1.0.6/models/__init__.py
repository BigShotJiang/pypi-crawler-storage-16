"""Tiingo models."""
