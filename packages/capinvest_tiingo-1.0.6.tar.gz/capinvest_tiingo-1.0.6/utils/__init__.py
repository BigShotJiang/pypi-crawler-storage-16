"""Tiingo helpers."""
