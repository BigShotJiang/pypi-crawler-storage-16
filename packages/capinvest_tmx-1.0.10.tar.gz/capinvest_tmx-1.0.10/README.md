# CapInvest TMX Provider

This extension integrates the [TMX](https://www.tmx.com) data provider into the CapInvest Platform.

 