"""TMX Provider Module."""

from capinvest_core.provider.abstract.provider import Provider
from capinvest_tmx.models.available_indices import TmxAvailableIndicesFetcher
from capinvest_tmx.models.bond_prices import TmxBondPricesFetcher
from capinvest_tmx.models.calendar_earnings import TmxCalendarEarningsFetcher
from capinvest_tmx.models.company_filings import TmxCompanyFilingsFetcher
from capinvest_tmx.models.company_news import TmxCompanyNewsFetcher
from capinvest_tmx.models.equity_historical import TmxEquityHistoricalFetcher
from capinvest_tmx.models.equity_profile import TmxEquityProfileFetcher
from capinvest_tmx.models.equity_quote import TmxEquityQuoteFetcher
from capinvest_tmx.models.equity_search import TmxEquitySearchFetcher
from capinvest_tmx.models.etf_countries import TmxEtfCountriesFetcher
from capinvest_tmx.models.etf_holdings import TmxEtfHoldingsFetcher
from capinvest_tmx.models.etf_info import TmxEtfInfoFetcher
from capinvest_tmx.models.etf_search import TmxEtfSearchFetcher
from capinvest_tmx.models.etf_sectors import TmxEtfSectorsFetcher
from capinvest_tmx.models.gainers import TmxGainersFetcher
from capinvest_tmx.models.historical_dividends import TmxHistoricalDividendsFetcher
from capinvest_tmx.models.index_constituents import TmxIndexConstituentsFetcher
from capinvest_tmx.models.index_sectors import TmxIndexSectorsFetcher
from capinvest_tmx.models.index_snapshots import TmxIndexSnapshotsFetcher
from capinvest_tmx.models.insider_trading import TmxInsiderTradingFetcher
from capinvest_tmx.models.options_chains import TmxOptionsChainsFetcher
from capinvest_tmx.models.price_target_consensus import TmxPriceTargetConsensusFetcher
from capinvest_tmx.models.treasury_prices import TmxTreasuryPricesFetcher

tmx_provider = Provider(
    name="tmx",
    website="https://www.tmx.com",
    description="""Unofficial TMX Data Provider Extension
    TMX Group Companies
        - Toronto Stock Exchange
        - TSX Venture Exchange
        - TSX Trust
        - Montréal Exchange
        - TSX Alpha Exchange
        - Shorcan
        - CDCC
        - CDS
        - TMX Datalinx
        - Trayport
    """,
    fetcher_dict={
        "AvailableIndices": TmxAvailableIndicesFetcher,
        "BondPrices": TmxBondPricesFetcher,
        "CalendarEarnings": TmxCalendarEarningsFetcher,
        "CompanyFilings": TmxCompanyFilingsFetcher,
        "CompanyNews": TmxCompanyNewsFetcher,
        "EquityHistorical": TmxEquityHistoricalFetcher,
        "EquityInfo": TmxEquityProfileFetcher,
        "EquityQuote": TmxEquityQuoteFetcher,
        "EquitySearch": TmxEquitySearchFetcher,
        "EtfSearch": TmxEtfSearchFetcher,
        "EtfHoldings": TmxEtfHoldingsFetcher,
        "EtfSectors": TmxEtfSectorsFetcher,
        "EtfCountries": TmxEtfCountriesFetcher,
        "EtfHistorical": TmxEquityHistoricalFetcher,
        "EtfInfo": TmxEtfInfoFetcher,
        "EquityGainers": TmxGainersFetcher,
        "HistoricalDividends": TmxHistoricalDividendsFetcher,
        "IndexConstituents": TmxIndexConstituentsFetcher,
        "IndexSectors": TmxIndexSectorsFetcher,
        "IndexSnapshots": TmxIndexSnapshotsFetcher,
        "InsiderTrading": TmxInsiderTradingFetcher,
        "OptionsChains": TmxOptionsChainsFetcher,
        "PriceTargetConsensus": TmxPriceTargetConsensusFetcher,
        "TreasuryPrices": TmxTreasuryPricesFetcher,
    },
    repr_name="TMX",
)
