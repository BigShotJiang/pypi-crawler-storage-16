# CapInvest Tradier Provider

This extension integrates the [Tradier](https://tradier.com) data provider into the CapInvest Platform.

 
