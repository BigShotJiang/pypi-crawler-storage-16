# CapInvest Trading Economics Provider

This extension integrates the [Trading Economics](https://docs.tradingeconomics.com/) data provider into the CapInvest SDK.

 
