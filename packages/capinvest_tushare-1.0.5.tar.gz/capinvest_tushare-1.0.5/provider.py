"""capinvest_tushare capinvest Platform Provider."""

from capinvest_core.provider.abstract.provider import Provider
from capinvest_tushare.models.available_indices import TushareAvailableIndicesFetcher
from capinvest_tushare.models.balance_sheet import TushareBalanceSheetFetcher
from capinvest_tushare.models.cash_flow import TushareCashFlowStatementFetcher
from capinvest_tushare.models.equity_historical import TushareEquityHistoricalFetcher
from capinvest_tushare.models.equity_profile import TushareEquityProfileFetcher
from capinvest_tushare.models.equity_quote import TushareEquityQuoteFetcher
from capinvest_tushare.models.equity_search import TushareEquitySearchFetcher
from capinvest_tushare.models.historical_dividends import TushareHistoricalDividendsFetcher
from capinvest_tushare.models.income_statement import TushareIncomeStatementFetcher

# mypy: disable-error-code="list-item"

provider = Provider(
    name="tushare",
    description="Data provider for capinvest_tushare.",
    credentials=["api_key"],
    website="https://www.caprisktech.com/",
    # Here, we list out the fetchers showing what our provider can get.
    # The dictionary key is the fetcher's name, used in the `router.py`.
    fetcher_dict={
        "AvailableIndices": TushareAvailableIndicesFetcher,
        "BalanceSheet": TushareBalanceSheetFetcher,
        "CashFlowStatement": TushareCashFlowStatementFetcher,
        "EquityHistorical": TushareEquityHistoricalFetcher,
        "EquityInfo": TushareEquityProfileFetcher,
        "EquityQuote": TushareEquityQuoteFetcher,
        "EquitySearch": TushareEquitySearchFetcher,
        "HistoricalDividends": TushareHistoricalDividendsFetcher,
        "IncomeStatement": TushareIncomeStatementFetcher,
    }
)
