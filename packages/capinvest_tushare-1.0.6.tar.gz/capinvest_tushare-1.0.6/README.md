# CapInvest CapData Provider

This extension integrates the tushare data provider
into the CapInvest Platform.
 