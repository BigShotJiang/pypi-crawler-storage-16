"""CapInvest EIA Provider Module Tests."""
