# CapInvest EIA Provider Extension

This module integrates the [EIA](https://eia.gov) data provider into the CapInvest Platform.

 