# CapInvest Wall St Journal Provider

This extension integrates the [WSJ](https://wsj.com/) data provider into the CapInvest Platform.

 
