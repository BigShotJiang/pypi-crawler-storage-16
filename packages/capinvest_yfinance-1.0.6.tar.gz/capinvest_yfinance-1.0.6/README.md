# CapInvest Yahoo!Finance Provider

This extension integrates the [Yahoo!Finance](https://finance.yahoo.com/) data provider into the CapInvest Platform.

 
