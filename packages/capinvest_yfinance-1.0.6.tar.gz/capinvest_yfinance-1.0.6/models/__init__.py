"""Yahoo Finance models directory."""
