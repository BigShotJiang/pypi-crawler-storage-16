# capnpy

[![ci status badge](https://github.com/antocuni/capnpy/actions/workflows/test.yml/badge.svg)](https://github.com/antocuni/capnpy/actions/workflows/test.yml)

A very fast implementation of `Cap’n Proto`_ for CPython and PyPy.

## Links

- [Cap’n Proto](https://capnproto.org/)
- [online docs](http://capnpy.readthedocs.io/)
