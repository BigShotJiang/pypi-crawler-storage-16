inthash = hash
longhash = hash
__tuplehash_for_tests = hash

def strhash(s, start, size):
    return hash(s[start:start+size])




