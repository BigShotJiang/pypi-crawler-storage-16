# this package exists only as a "placeholder" where to load the cython
# extension modules loaded on the fly by compiler.load_schema
