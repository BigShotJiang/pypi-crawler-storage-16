"""Initial placeholder implementation for capychino."""

__version__ = "0.0.1"

def placeholder() -> str:
    return "This package is under active development."
