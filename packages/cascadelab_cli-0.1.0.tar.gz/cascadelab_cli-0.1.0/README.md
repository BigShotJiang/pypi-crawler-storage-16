screentime = C09KC2WTTE1

https://api.slack.com/apps/A0A3Y9V6NP2/oauth?success=1

uv run lab-cli C09KC2WTTE1