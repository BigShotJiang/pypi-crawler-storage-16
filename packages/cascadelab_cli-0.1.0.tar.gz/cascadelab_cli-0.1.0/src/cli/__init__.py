import typer
from slack_sdk import WebClient
from .slack_utils import get_links_from_channel

app = typer.Typer(help="Lab CLI toolkit")

@app.command("list-scopes")
def list_scopes(
    slack_token: str = typer.Option(
        ...,
        envvar="SLACK_TOKEN",
        help="Slack Bot Token (or set SLACK_TOKEN env var)",
    )
):
    """
    List the Slack bot token's scopes and permissions.
    """
    if not slack_token:
        typer.echo("❌ SLACK_TOKEN is not set.")
        raise typer.Exit(code=1)

    client = WebClient(token=slack_token)

    typer.echo("🔍 Checking Slack scopes...\n")

    # Check token identity
    try:
        auth_info = client.auth_test()
        typer.echo(f"Authenticated as: {auth_info.get('user')} ({auth_info.get('user_id')})")
        typer.echo(f"Workspace: {auth_info.get('team')} ({auth_info.get('team_id')})\n")
    except Exception as e:
        typer.echo(f"❌ Token authentication failed: {e}")
        raise typer.Exit(code=1)

    # Get permission details
    try:
        perm_info = client.apps_permissions_info()
        scopes = perm_info.get("info", {}).get("scopes", {})
        bot_scopes = scopes.get("bot", [])
        user_scopes = scopes.get("user", [])

        typer.echo("🔐 Bot Token Scopes:")
        for s in bot_scopes:
            typer.echo(f" - {s}")

        typer.echo("\n🙋 User Token Scopes:")
        for s in user_scopes:
            typer.echo(f" - {s}")

    except Exception as e:
        typer.echo(f"❌ Could not retrieve permissions: {e}")
        raise typer.Exit(code=1)

    typer.echo("\n✅ Done.")


@app.command("check-connection")
def check_connection(
    slack_token: str = typer.Option(
        ...,
        envvar="SLACK_TOKEN",
        help="Slack Bot Token (or set SLACK_TOKEN env var)",
    )
):
    """
    Check whether the Slack token is valid and the API connection works.
    """

    if not slack_token:
        typer.echo("❌ SLACK_TOKEN not set. Export it or pass --slack-token.")
        raise typer.Exit(code=1)

    client = WebClient(token=slack_token)

    try:
        resp = client.auth_test()
        team = resp.get("team")
        user = resp.get("user")
        typer.echo(f"✅ Connected to Slack workspace: {team} (as {user})")
    except Exception as e:
        typer.echo("❌ Failed to connect to Slack.")
        typer.echo(f"Error: {e}")
        raise typer.Exit(code=1)


@app.command("list-channels")
def list_channels(
    slack_token: str = typer.Option(
        ...,
        envvar="SLACK_TOKEN",
        help="Slack Bot Token (or set SLACK_TOKEN env var)",
    ),
    include_private: bool = typer.Option(
        False,
        "--private",
        "-p",
        help="Include private channels",
    ),
):
    """
    List all channels your Slack bot can access.
    Use --private to include private channels.
    """
    if not slack_token:
        typer.echo("❌ SLACK_TOKEN not set.")
        raise typer.Exit(code=1)

    client = WebClient(token=slack_token)
    cursor = None
    channels = []

    while True:
        resp = client.conversations_list(
            cursor=cursor,
            limit=200,
            types="public_channel" if not include_private else "public_channel,private_channel",
        )
        channels.extend(resp.get("channels", []))

        cursor = resp.get("response_metadata", {}).get("next_cursor")
        if not cursor:
            break

    if not channels:
        typer.echo("No channels found.")
        return

    typer.echo("📡 Channels:\n")
    for ch in channels:
        typer.echo(f"- {ch['name']}  ({ch['id']})")


@app.command("get-links")
def get_links(
    slack_token: str = typer.Option(
        ...,
        envvar="SLACK_TOKEN",
        help="Slack Bot Token (or set SLACK_TOKEN env var)",
    ),
    channel_id: str = typer.Argument(..., help="Slack Channel ID"),
):
    """
    Get all links from a Slack channel.

    Example:
        lab-cli get-links C0123456789
    """
    links = get_links_from_channel(slack_token, channel_id)
    
    if not slack_token:
        typer.echo("Error: SLACK_TOKEN is not set. Export it or pass --slack-token.")
        raise typer.Exit(code=1)

    if not links:
        typer.echo("No links found.")
        raise typer.Exit(0)

    typer.echo("Links found:\n")
    for link in links:
        typer.echo(link)


if __name__ == "__main__":
    app()
