import re
from slack_sdk import WebClient

url_pattern = re.compile(r"https?://\S+")


def get_links_from_channel(slack_token: str, channel_id: str):
    """
    Retrieve all URLs from a Slack channel by scanning message history.
    """
    client = WebClient(token=slack_token)

    all_links = []
    cursor = None

    while True:
        resp = client.conversations_history(
            channel=channel_id,
            cursor=cursor,
            limit=200,
        )

        for msg in resp.get("messages", []):
            text = msg.get("text", "")
            found_urls = url_pattern.findall(text)
            all_links.extend(found_urls)

        cursor = resp.get("response_metadata", {}).get("next_cursor")
        if not cursor:
            break

    return all_links
