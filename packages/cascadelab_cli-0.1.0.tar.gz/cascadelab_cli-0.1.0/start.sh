#!/usr/bin/env bash

set -e

if [ -z "$1" ]; then
    echo "Usage: $0 <project_name>"
    exit 1
fi

PROJECT=$1

echo "📦 Creating flat-layout uv project: $PROJECT"

# Create project folder manually
mkdir -p "$PROJECT"
cd "$PROJECT"

# Initialize pyproject + README only
uv init .

# Create a flat src directory
mkdir -p src
touch src/__init__.py

echo "🧹 Cleaning nested folder created by uv…"
# uv init may create src/<project>/ — remove it
if [ -d "src/$PROJECT" ]; then
    rm -rf "src/$PROJECT"
fi

echo "✅ Flat project created!"

echo "
Structure:

$PROJECT/
  pyproject.toml
  README.md
  src/
    __init__.py
"

echo "Next steps:
  cd $PROJECT
  uv sync
"
