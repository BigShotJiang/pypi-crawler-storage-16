"""Entry point for the MCP module - redirects to dev server."""

from __future__ import annotations

from .dev import main

if __name__ == "__main__":
    main()
