"""Metadata linking semantic meaning of Census PEP FIPS codes spreadsheet columns across years."""
