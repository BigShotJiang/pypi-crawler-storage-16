"""Metadata linking semantic meaning of EIA 191 CSV file columns across years."""
