"""A module of python helper functions and sql files for creating SQL views."""
