"""Metadata linking semantic meaning of EIA 757a CSV file columns across years."""
