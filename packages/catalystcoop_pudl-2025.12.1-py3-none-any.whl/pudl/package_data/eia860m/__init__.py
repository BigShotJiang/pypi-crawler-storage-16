"""Excel spreadsheet extraction maps for EIA 860M."""
