"""Metadata required for extracting data from the FERC Form 1."""
