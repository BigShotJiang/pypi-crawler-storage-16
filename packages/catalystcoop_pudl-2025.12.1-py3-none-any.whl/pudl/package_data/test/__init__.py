"""Excel spreadsheet extraction maps for testing."""
