"""Model metadata and data files."""
