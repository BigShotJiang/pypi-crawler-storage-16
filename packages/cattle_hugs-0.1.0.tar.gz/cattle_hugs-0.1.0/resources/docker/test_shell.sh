#!/bin/sh

pip install  --upgrade \
    hypercorn pytest \
    almabtrieb behave_auto_docstring \
    muck_out


/bin/sh
