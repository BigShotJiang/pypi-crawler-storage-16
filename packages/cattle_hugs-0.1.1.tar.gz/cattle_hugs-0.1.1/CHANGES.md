# Changes

## 0.1.1

* Add actor information to interactions response [hugs#6](https://codeberg.org/bovine/cattle_hugs/issues/6)
* Add better handling for reprocessing [hugs#9](https://codeberg.org/bovine/cattle_hugs/issues/9)
* Add docs [hugs#4](https://codeberg.org/bovine/cattle_hugs/issues/4)
* Add `with_collections` to exports [hugs#8](https://codeberg.org/bovine/cattle_hugs/issues/8)
* Cleanup compose setup

## 0.1.0

* Initial version