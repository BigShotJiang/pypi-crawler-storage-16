# cattle_hugs

cattle_hugs provides tracking of

- Actors
- Replies
- Likes
- Shares

to cattle_grid based applications.
