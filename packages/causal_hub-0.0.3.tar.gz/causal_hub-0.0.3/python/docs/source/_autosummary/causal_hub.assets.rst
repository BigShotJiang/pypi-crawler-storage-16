﻿causal\_hub.assets
==================

.. automodule:: causal_hub.assets

   
   .. rubric:: Functions

   .. autosummary::
   
      load_alarm
      load_andes
      load_arth150
      load_asia
      load_barley
      load_cancer
      load_child
      load_diabetes
      load_earthquake
      load_eating
      load_ecoli70
      load_hailfinder
      load_hepar2
      load_insurance
      load_link
      load_magic_irri
      load_magic_niab
      load_mildew
      load_munin1
      load_pathfinder
      load_pigs
      load_sachs
      load_survey
      load_water
      load_win95pts
   