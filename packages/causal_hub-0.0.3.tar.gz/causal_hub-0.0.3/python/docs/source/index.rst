causal-hub documentation
========================

.. toctree::
   :maxdepth: 2

   autosummary.rst
