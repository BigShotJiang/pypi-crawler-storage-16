# CLI Reference

This page provides auto-generated documentation for the `cc-liquid` CLI tool.

::: mkdocs-click
    :module: cc_liquid.cli
    :command: cli
    :prog_name: cc-liquid
    :depth: 1