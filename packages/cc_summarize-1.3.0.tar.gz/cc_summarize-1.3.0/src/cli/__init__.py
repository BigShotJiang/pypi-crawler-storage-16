"""CLI module for cc-summarize."""
