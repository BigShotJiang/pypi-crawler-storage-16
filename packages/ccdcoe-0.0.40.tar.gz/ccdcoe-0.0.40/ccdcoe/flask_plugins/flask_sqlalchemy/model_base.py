# noinspection PyUnusedImports
from ccdcoe.custom_types.sqlalchemy.model_base import ModelBase
