"""Tests for ccontext-mcp."""
