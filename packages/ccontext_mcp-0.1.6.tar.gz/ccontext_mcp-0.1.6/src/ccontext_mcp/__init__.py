"""ccontext-mcp: MCP server for AI agents to manage project execution context."""

__version__ = "0.1.0"
