from ccxt.base.types import Entry


class ImplicitAPI:
    public_get_get_all_rate = publicGetGetAllRate = Entry('get-all-rate', 'public', 'GET', {'cost': 1})
