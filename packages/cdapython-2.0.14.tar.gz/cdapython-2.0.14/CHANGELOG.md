2025-12-09: 2.0.14: add sort postproc to POC disease\_slims return column

2025-12-09: 2.0.13: add POC `include\_disease\_slims` Boolean flag to get\_data()

2025-10-31: 2.0.12: standardize debug-layer SQL echo; adjust column\_values() to handle known pathologies

2025-10-27: 2.0.11: _cough_ bugfix for previous

2025-10-27: 2.0.10: integrate column\_values() parameter validation with shared validation library; expand support for column\_values( data\_source ) to accept list values in addition to single strings

2025-10-22: 2.0.9: parametrize data\_source check in column\_values()

2025-10-20: 2.0.8: rename CDS to GC throughout

2025-10-08: 2.0.7: fix malformed column metadata selector inside `collate=True` provenance management in get\_data()

2025-09-17: 2.0.6: update ternary numeric comparison handling for latest API ternary operator syntax support

2025-08-18: 2.0.2: update PyYAML build dependency

2025-08-18: 2.0.1: update default API URL

2025-08-18: 2.0.0: initial public release to PyPI
