ADAM_PRODUCTS = [
    "adamig",
    "adam-adae",
    "adam-md",
    "adam-nca",
    "adam-occds",
    "adam-tte",
    "adam-poppk",
]
