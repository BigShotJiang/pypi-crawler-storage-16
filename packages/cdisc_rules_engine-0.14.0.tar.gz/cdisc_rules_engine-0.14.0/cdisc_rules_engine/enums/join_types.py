from cdisc_rules_engine.enums.base_enum import BaseEnum


class JoinTypes(BaseEnum):
    INNER = "inner"
    LEFT = "left"
