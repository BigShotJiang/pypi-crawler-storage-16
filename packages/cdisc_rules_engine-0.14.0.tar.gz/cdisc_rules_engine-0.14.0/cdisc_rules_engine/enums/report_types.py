from cdisc_rules_engine.enums.base_enum import BaseEnum


class ReportTypes(BaseEnum):
    XLSX = "XLSX"
    JSON = "JSON"
