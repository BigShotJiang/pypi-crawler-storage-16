r'''
# `hcp_vault_radar_secret_manager_vault_dedicated`

Refer to the Terraform Registry for docs: [`hcp_vault_radar_secret_manager_vault_dedicated`](https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktf as _cdktf_9a9027ec
import constructs as _constructs_77d1e7e8


class VaultRadarSecretManagerVaultDedicated(
    _cdktf_9a9027ec.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-hcp.vaultRadarSecretManagerVaultDedicated.VaultRadarSecretManagerVaultDedicated",
):
    '''Represents a {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated hcp_vault_radar_secret_manager_vault_dedicated}.'''

    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id: builtins.str,
        *,
        vault_url: builtins.str,
        access_read_write: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
        approle_push: typing.Optional[typing.Union["VaultRadarSecretManagerVaultDedicatedApprolePush", typing.Dict[builtins.str, typing.Any]]] = None,
        kubernetes: typing.Optional[typing.Union["VaultRadarSecretManagerVaultDedicatedKubernetes", typing.Dict[builtins.str, typing.Any]]] = None,
        project_id: typing.Optional[builtins.str] = None,
        token: typing.Optional[typing.Union["VaultRadarSecretManagerVaultDedicatedToken", typing.Dict[builtins.str, typing.Any]]] = None,
        connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated hcp_vault_radar_secret_manager_vault_dedicated} Resource.

        :param scope: The scope in which to define this construct.
        :param id: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param vault_url: Specify the URL of the Vault instance without protocol. Example: 'acme-public-vault-abc.def.z1.hashicorp.cloud:8200'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#vault_url VaultRadarSecretManagerVaultDedicated#vault_url}
        :param access_read_write: Indicates if the auth method has read and write access to the secrets engine. Defaults to false. Set this to true if you want to copy secrets to this secret manager as part of remediation process. (see https://developer.hashicorp.com/hcp/docs/vault-radar/remediate-secrets/copy-secrets) Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#access_read_write VaultRadarSecretManagerVaultDedicated#access_read_write}
        :param approle_push: Configuration for AppRole Push-based authentication. Only one authentication method may be configured. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#approle_push VaultRadarSecretManagerVaultDedicated#approle_push}
        :param kubernetes: Configuration for Kubernetes-based authentication. Only one authentication method may be configured. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#kubernetes VaultRadarSecretManagerVaultDedicated#kubernetes}
        :param project_id: The ID of the HCP project where Vault Radar is located. If not specified, the project specified in the HCP Provider config block will be used, if configured. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#project_id VaultRadarSecretManagerVaultDedicated#project_id}
        :param token: Configuration for token-based authentication. Only one authentication method may be configured. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#token VaultRadarSecretManagerVaultDedicated#token}
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__35ce44f700fb4a1db9e0e086c3a7a769942f26f70ba9db2c1e8b37ae31a69880)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        config = VaultRadarSecretManagerVaultDedicatedConfig(
            vault_url=vault_url,
            access_read_write=access_read_write,
            approle_push=approle_push,
            kubernetes=kubernetes,
            project_id=project_id,
            token=token,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id, config])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: _constructs_77d1e7e8.Construct,
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
    ) -> _cdktf_9a9027ec.ImportableResource:
        '''Generates CDKTF code for importing a VaultRadarSecretManagerVaultDedicated resource upon running "cdktf plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the VaultRadarSecretManagerVaultDedicated to import.
        :param import_from_id: The id of the existing VaultRadarSecretManagerVaultDedicated that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the VaultRadarSecretManagerVaultDedicated to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d15fa2282b2c73c0a8cf31207a6b0747a4a9e6e716213220a29af208a6747a50)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast(_cdktf_9a9027ec.ImportableResource, jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="putApprolePush")
    def put_approle_push(
        self,
        *,
        mount_path: builtins.str,
        role_id_env_var: builtins.str,
        secret_id_env_var: builtins.str,
    ) -> None:
        '''
        :param mount_path: Mount path of the AppRole auth method in Vault. Example 'approle'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#mount_path VaultRadarSecretManagerVaultDedicated#mount_path}
        :param role_id_env_var: Environment variable containing the AppRole role ID. Example: 'VAULT_APPROLE_ROLE_ID'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#role_id_env_var VaultRadarSecretManagerVaultDedicated#role_id_env_var}
        :param secret_id_env_var: Environment variable containing the AppRole secret ID. Example: 'VAULT_APPROLE_SECRET_ID'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#secret_id_env_var VaultRadarSecretManagerVaultDedicated#secret_id_env_var}
        '''
        value = VaultRadarSecretManagerVaultDedicatedApprolePush(
            mount_path=mount_path,
            role_id_env_var=role_id_env_var,
            secret_id_env_var=secret_id_env_var,
        )

        return typing.cast(None, jsii.invoke(self, "putApprolePush", [value]))

    @jsii.member(jsii_name="putKubernetes")
    def put_kubernetes(
        self,
        *,
        mount_path: builtins.str,
        role_name: builtins.str,
    ) -> None:
        '''
        :param mount_path: Mount path where the Kubernetes auth method is enabled in Vault. Example 'kubernetes'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#mount_path VaultRadarSecretManagerVaultDedicated#mount_path}
        :param role_name: Kubernetes authentication role configured in Vault. Example 'vault-radar-role'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#role_name VaultRadarSecretManagerVaultDedicated#role_name}
        '''
        value = VaultRadarSecretManagerVaultDedicatedKubernetes(
            mount_path=mount_path, role_name=role_name
        )

        return typing.cast(None, jsii.invoke(self, "putKubernetes", [value]))

    @jsii.member(jsii_name="putToken")
    def put_token(self, *, token_env_var: builtins.str) -> None:
        '''
        :param token_env_var: Environment variable name containing the Vault token. Example: 'VAULT_TOKEN'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#token_env_var VaultRadarSecretManagerVaultDedicated#token_env_var}
        '''
        value = VaultRadarSecretManagerVaultDedicatedToken(token_env_var=token_env_var)

        return typing.cast(None, jsii.invoke(self, "putToken", [value]))

    @jsii.member(jsii_name="resetAccessReadWrite")
    def reset_access_read_write(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAccessReadWrite", []))

    @jsii.member(jsii_name="resetApprolePush")
    def reset_approle_push(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetApprolePush", []))

    @jsii.member(jsii_name="resetKubernetes")
    def reset_kubernetes(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetKubernetes", []))

    @jsii.member(jsii_name="resetProjectId")
    def reset_project_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetProjectId", []))

    @jsii.member(jsii_name="resetToken")
    def reset_token(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetToken", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="approlePush")
    def approle_push(
        self,
    ) -> "VaultRadarSecretManagerVaultDedicatedApprolePushOutputReference":
        return typing.cast("VaultRadarSecretManagerVaultDedicatedApprolePushOutputReference", jsii.get(self, "approlePush"))

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @builtins.property
    @jsii.member(jsii_name="kubernetes")
    def kubernetes(
        self,
    ) -> "VaultRadarSecretManagerVaultDedicatedKubernetesOutputReference":
        return typing.cast("VaultRadarSecretManagerVaultDedicatedKubernetesOutputReference", jsii.get(self, "kubernetes"))

    @builtins.property
    @jsii.member(jsii_name="token")
    def token(self) -> "VaultRadarSecretManagerVaultDedicatedTokenOutputReference":
        return typing.cast("VaultRadarSecretManagerVaultDedicatedTokenOutputReference", jsii.get(self, "token"))

    @builtins.property
    @jsii.member(jsii_name="accessReadWriteInput")
    def access_read_write_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]], jsii.get(self, "accessReadWriteInput"))

    @builtins.property
    @jsii.member(jsii_name="approlePushInput")
    def approle_push_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "VaultRadarSecretManagerVaultDedicatedApprolePush"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "VaultRadarSecretManagerVaultDedicatedApprolePush"]], jsii.get(self, "approlePushInput"))

    @builtins.property
    @jsii.member(jsii_name="kubernetesInput")
    def kubernetes_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "VaultRadarSecretManagerVaultDedicatedKubernetes"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "VaultRadarSecretManagerVaultDedicatedKubernetes"]], jsii.get(self, "kubernetesInput"))

    @builtins.property
    @jsii.member(jsii_name="projectIdInput")
    def project_id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "projectIdInput"))

    @builtins.property
    @jsii.member(jsii_name="tokenInput")
    def token_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "VaultRadarSecretManagerVaultDedicatedToken"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, "VaultRadarSecretManagerVaultDedicatedToken"]], jsii.get(self, "tokenInput"))

    @builtins.property
    @jsii.member(jsii_name="vaultUrlInput")
    def vault_url_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "vaultUrlInput"))

    @builtins.property
    @jsii.member(jsii_name="accessReadWrite")
    def access_read_write(
        self,
    ) -> typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable], jsii.get(self, "accessReadWrite"))

    @access_read_write.setter
    def access_read_write(
        self,
        value: typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fa7204f072c659d633d6f8de2e8f395839054bd0fd951d7031583bfb8d3230ad)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "accessReadWrite", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="projectId")
    def project_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "projectId"))

    @project_id.setter
    def project_id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__53ae998d8c56d9073e8f6cf7fc8ede81a5ae883212bb33eda0b65fbd25012dad)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "projectId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="vaultUrl")
    def vault_url(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "vaultUrl"))

    @vault_url.setter
    def vault_url(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1faf2e8da6f9bca7ed7091ac507bea1e5a609e3345a938c4c336edb4554e0f90)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "vaultUrl", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktf/provider-hcp.vaultRadarSecretManagerVaultDedicated.VaultRadarSecretManagerVaultDedicatedApprolePush",
    jsii_struct_bases=[],
    name_mapping={
        "mount_path": "mountPath",
        "role_id_env_var": "roleIdEnvVar",
        "secret_id_env_var": "secretIdEnvVar",
    },
)
class VaultRadarSecretManagerVaultDedicatedApprolePush:
    def __init__(
        self,
        *,
        mount_path: builtins.str,
        role_id_env_var: builtins.str,
        secret_id_env_var: builtins.str,
    ) -> None:
        '''
        :param mount_path: Mount path of the AppRole auth method in Vault. Example 'approle'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#mount_path VaultRadarSecretManagerVaultDedicated#mount_path}
        :param role_id_env_var: Environment variable containing the AppRole role ID. Example: 'VAULT_APPROLE_ROLE_ID'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#role_id_env_var VaultRadarSecretManagerVaultDedicated#role_id_env_var}
        :param secret_id_env_var: Environment variable containing the AppRole secret ID. Example: 'VAULT_APPROLE_SECRET_ID'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#secret_id_env_var VaultRadarSecretManagerVaultDedicated#secret_id_env_var}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b40efeeee11b5343ff7f5cd784a55b2f8d64a2c17248be3ef63861c34d9d5fe7)
            check_type(argname="argument mount_path", value=mount_path, expected_type=type_hints["mount_path"])
            check_type(argname="argument role_id_env_var", value=role_id_env_var, expected_type=type_hints["role_id_env_var"])
            check_type(argname="argument secret_id_env_var", value=secret_id_env_var, expected_type=type_hints["secret_id_env_var"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "mount_path": mount_path,
            "role_id_env_var": role_id_env_var,
            "secret_id_env_var": secret_id_env_var,
        }

    @builtins.property
    def mount_path(self) -> builtins.str:
        '''Mount path of the AppRole auth method in Vault. Example 'approle'.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#mount_path VaultRadarSecretManagerVaultDedicated#mount_path}
        '''
        result = self._values.get("mount_path")
        assert result is not None, "Required property 'mount_path' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def role_id_env_var(self) -> builtins.str:
        '''Environment variable containing the AppRole role ID. Example: 'VAULT_APPROLE_ROLE_ID'.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#role_id_env_var VaultRadarSecretManagerVaultDedicated#role_id_env_var}
        '''
        result = self._values.get("role_id_env_var")
        assert result is not None, "Required property 'role_id_env_var' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def secret_id_env_var(self) -> builtins.str:
        '''Environment variable containing the AppRole secret ID. Example: 'VAULT_APPROLE_SECRET_ID'.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#secret_id_env_var VaultRadarSecretManagerVaultDedicated#secret_id_env_var}
        '''
        result = self._values.get("secret_id_env_var")
        assert result is not None, "Required property 'secret_id_env_var' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "VaultRadarSecretManagerVaultDedicatedApprolePush(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class VaultRadarSecretManagerVaultDedicatedApprolePushOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-hcp.vaultRadarSecretManagerVaultDedicated.VaultRadarSecretManagerVaultDedicatedApprolePushOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5a2bf1ce36b6d2959e325a3939dba35fbca2f15888c8e643546248443b6e77a0)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="mountPathInput")
    def mount_path_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "mountPathInput"))

    @builtins.property
    @jsii.member(jsii_name="roleIdEnvVarInput")
    def role_id_env_var_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "roleIdEnvVarInput"))

    @builtins.property
    @jsii.member(jsii_name="secretIdEnvVarInput")
    def secret_id_env_var_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "secretIdEnvVarInput"))

    @builtins.property
    @jsii.member(jsii_name="mountPath")
    def mount_path(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "mountPath"))

    @mount_path.setter
    def mount_path(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b34c48b23894baec786cae63cf1ad8bc16dca970f555e0d5663b7a7ff9d91892)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "mountPath", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="roleIdEnvVar")
    def role_id_env_var(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "roleIdEnvVar"))

    @role_id_env_var.setter
    def role_id_env_var(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fef0f9673ae0cbca28dc5a8849dbfbfd8000359f88af800d1666c1fb0db5228e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "roleIdEnvVar", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="secretIdEnvVar")
    def secret_id_env_var(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "secretIdEnvVar"))

    @secret_id_env_var.setter
    def secret_id_env_var(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4e499c547ab2e3be0235cd2bcacb0ec2080d46fbfdbfd72c8a0a011768cd99ad)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "secretIdEnvVar", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, VaultRadarSecretManagerVaultDedicatedApprolePush]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, VaultRadarSecretManagerVaultDedicatedApprolePush]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, VaultRadarSecretManagerVaultDedicatedApprolePush]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b76629fbbcced2cf7afdf3c3ef533662b7b95c3f675a523a7fcb84ed8ee687ae)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktf/provider-hcp.vaultRadarSecretManagerVaultDedicated.VaultRadarSecretManagerVaultDedicatedConfig",
    jsii_struct_bases=[_cdktf_9a9027ec.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "vault_url": "vaultUrl",
        "access_read_write": "accessReadWrite",
        "approle_push": "approlePush",
        "kubernetes": "kubernetes",
        "project_id": "projectId",
        "token": "token",
    },
)
class VaultRadarSecretManagerVaultDedicatedConfig(
    _cdktf_9a9027ec.TerraformMetaArguments,
):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
        vault_url: builtins.str,
        access_read_write: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
        approle_push: typing.Optional[typing.Union[VaultRadarSecretManagerVaultDedicatedApprolePush, typing.Dict[builtins.str, typing.Any]]] = None,
        kubernetes: typing.Optional[typing.Union["VaultRadarSecretManagerVaultDedicatedKubernetes", typing.Dict[builtins.str, typing.Any]]] = None,
        project_id: typing.Optional[builtins.str] = None,
        token: typing.Optional[typing.Union["VaultRadarSecretManagerVaultDedicatedToken", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param vault_url: Specify the URL of the Vault instance without protocol. Example: 'acme-public-vault-abc.def.z1.hashicorp.cloud:8200'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#vault_url VaultRadarSecretManagerVaultDedicated#vault_url}
        :param access_read_write: Indicates if the auth method has read and write access to the secrets engine. Defaults to false. Set this to true if you want to copy secrets to this secret manager as part of remediation process. (see https://developer.hashicorp.com/hcp/docs/vault-radar/remediate-secrets/copy-secrets) Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#access_read_write VaultRadarSecretManagerVaultDedicated#access_read_write}
        :param approle_push: Configuration for AppRole Push-based authentication. Only one authentication method may be configured. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#approle_push VaultRadarSecretManagerVaultDedicated#approle_push}
        :param kubernetes: Configuration for Kubernetes-based authentication. Only one authentication method may be configured. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#kubernetes VaultRadarSecretManagerVaultDedicated#kubernetes}
        :param project_id: The ID of the HCP project where Vault Radar is located. If not specified, the project specified in the HCP Provider config block will be used, if configured. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#project_id VaultRadarSecretManagerVaultDedicated#project_id}
        :param token: Configuration for token-based authentication. Only one authentication method may be configured. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#token VaultRadarSecretManagerVaultDedicated#token}
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktf_9a9027ec.TerraformResourceLifecycle(**lifecycle)
        if isinstance(approle_push, dict):
            approle_push = VaultRadarSecretManagerVaultDedicatedApprolePush(**approle_push)
        if isinstance(kubernetes, dict):
            kubernetes = VaultRadarSecretManagerVaultDedicatedKubernetes(**kubernetes)
        if isinstance(token, dict):
            token = VaultRadarSecretManagerVaultDedicatedToken(**token)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b70a2e8eeb8872c8380accc6e9a5fdc7fb10d6e696e657eb7f6f9c48cfd41ca3)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument vault_url", value=vault_url, expected_type=type_hints["vault_url"])
            check_type(argname="argument access_read_write", value=access_read_write, expected_type=type_hints["access_read_write"])
            check_type(argname="argument approle_push", value=approle_push, expected_type=type_hints["approle_push"])
            check_type(argname="argument kubernetes", value=kubernetes, expected_type=type_hints["kubernetes"])
            check_type(argname="argument project_id", value=project_id, expected_type=type_hints["project_id"])
            check_type(argname="argument token", value=token, expected_type=type_hints["token"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "vault_url": vault_url,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if access_read_write is not None:
            self._values["access_read_write"] = access_read_write
        if approle_push is not None:
            self._values["approle_push"] = approle_push
        if kubernetes is not None:
            self._values["kubernetes"] = kubernetes
        if project_id is not None:
            self._values["project_id"] = project_id
        if token is not None:
            self._values["token"] = token

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, _cdktf_9a9027ec.WinrmProvisionerConnection]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, _cdktf_9a9027ec.WinrmProvisionerConnection]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List[_cdktf_9a9027ec.ITerraformDependable]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List[_cdktf_9a9027ec.ITerraformDependable]], result)

    @builtins.property
    def for_each(self) -> typing.Optional[_cdktf_9a9027ec.ITerraformIterator]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional[_cdktf_9a9027ec.ITerraformIterator], result)

    @builtins.property
    def lifecycle(self) -> typing.Optional[_cdktf_9a9027ec.TerraformResourceLifecycle]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional[_cdktf_9a9027ec.TerraformResourceLifecycle], result)

    @builtins.property
    def provider(self) -> typing.Optional[_cdktf_9a9027ec.TerraformProvider]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional[_cdktf_9a9027ec.TerraformProvider], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union[_cdktf_9a9027ec.FileProvisioner, _cdktf_9a9027ec.LocalExecProvisioner, _cdktf_9a9027ec.RemoteExecProvisioner]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union[_cdktf_9a9027ec.FileProvisioner, _cdktf_9a9027ec.LocalExecProvisioner, _cdktf_9a9027ec.RemoteExecProvisioner]]], result)

    @builtins.property
    def vault_url(self) -> builtins.str:
        '''Specify the URL of the Vault instance without protocol. Example: 'acme-public-vault-abc.def.z1.hashicorp.cloud:8200'.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#vault_url VaultRadarSecretManagerVaultDedicated#vault_url}
        '''
        result = self._values.get("vault_url")
        assert result is not None, "Required property 'vault_url' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def access_read_write(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]]:
        '''Indicates if the auth method has read and write access to the secrets engine.

        Defaults to false. Set this to true if you want to copy secrets to this secret manager as part of remediation process. (see https://developer.hashicorp.com/hcp/docs/vault-radar/remediate-secrets/copy-secrets)

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#access_read_write VaultRadarSecretManagerVaultDedicated#access_read_write}
        '''
        result = self._values.get("access_read_write")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]], result)

    @builtins.property
    def approle_push(
        self,
    ) -> typing.Optional[VaultRadarSecretManagerVaultDedicatedApprolePush]:
        '''Configuration for AppRole Push-based authentication. Only one authentication method may be configured.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#approle_push VaultRadarSecretManagerVaultDedicated#approle_push}
        '''
        result = self._values.get("approle_push")
        return typing.cast(typing.Optional[VaultRadarSecretManagerVaultDedicatedApprolePush], result)

    @builtins.property
    def kubernetes(
        self,
    ) -> typing.Optional["VaultRadarSecretManagerVaultDedicatedKubernetes"]:
        '''Configuration for Kubernetes-based authentication. Only one authentication method may be configured.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#kubernetes VaultRadarSecretManagerVaultDedicated#kubernetes}
        '''
        result = self._values.get("kubernetes")
        return typing.cast(typing.Optional["VaultRadarSecretManagerVaultDedicatedKubernetes"], result)

    @builtins.property
    def project_id(self) -> typing.Optional[builtins.str]:
        '''The ID of the HCP project where Vault Radar is located.

        If not specified, the project specified in the HCP Provider config block will be used, if configured.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#project_id VaultRadarSecretManagerVaultDedicated#project_id}
        '''
        result = self._values.get("project_id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def token(self) -> typing.Optional["VaultRadarSecretManagerVaultDedicatedToken"]:
        '''Configuration for token-based authentication. Only one authentication method may be configured.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#token VaultRadarSecretManagerVaultDedicated#token}
        '''
        result = self._values.get("token")
        return typing.cast(typing.Optional["VaultRadarSecretManagerVaultDedicatedToken"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "VaultRadarSecretManagerVaultDedicatedConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktf/provider-hcp.vaultRadarSecretManagerVaultDedicated.VaultRadarSecretManagerVaultDedicatedKubernetes",
    jsii_struct_bases=[],
    name_mapping={"mount_path": "mountPath", "role_name": "roleName"},
)
class VaultRadarSecretManagerVaultDedicatedKubernetes:
    def __init__(self, *, mount_path: builtins.str, role_name: builtins.str) -> None:
        '''
        :param mount_path: Mount path where the Kubernetes auth method is enabled in Vault. Example 'kubernetes'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#mount_path VaultRadarSecretManagerVaultDedicated#mount_path}
        :param role_name: Kubernetes authentication role configured in Vault. Example 'vault-radar-role'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#role_name VaultRadarSecretManagerVaultDedicated#role_name}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4bdcb06d543f1d6112c5c5de857af658f4d0b87dadd4d307432a33036c48f246)
            check_type(argname="argument mount_path", value=mount_path, expected_type=type_hints["mount_path"])
            check_type(argname="argument role_name", value=role_name, expected_type=type_hints["role_name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "mount_path": mount_path,
            "role_name": role_name,
        }

    @builtins.property
    def mount_path(self) -> builtins.str:
        '''Mount path where the Kubernetes auth method is enabled in Vault. Example 'kubernetes'.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#mount_path VaultRadarSecretManagerVaultDedicated#mount_path}
        '''
        result = self._values.get("mount_path")
        assert result is not None, "Required property 'mount_path' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def role_name(self) -> builtins.str:
        '''Kubernetes authentication role configured in Vault.  Example 'vault-radar-role'.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#role_name VaultRadarSecretManagerVaultDedicated#role_name}
        '''
        result = self._values.get("role_name")
        assert result is not None, "Required property 'role_name' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "VaultRadarSecretManagerVaultDedicatedKubernetes(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class VaultRadarSecretManagerVaultDedicatedKubernetesOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-hcp.vaultRadarSecretManagerVaultDedicated.VaultRadarSecretManagerVaultDedicatedKubernetesOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9999dd674b71f3fb7a6b8f86441dd7a816e8af0125a38ccd13a8e6946271bd3c)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="mountPathInput")
    def mount_path_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "mountPathInput"))

    @builtins.property
    @jsii.member(jsii_name="roleNameInput")
    def role_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "roleNameInput"))

    @builtins.property
    @jsii.member(jsii_name="mountPath")
    def mount_path(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "mountPath"))

    @mount_path.setter
    def mount_path(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5a4f336d7a408e60b3ba7680b8b31dd542b6c616467bd28645bbd39b234f2211)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "mountPath", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="roleName")
    def role_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "roleName"))

    @role_name.setter
    def role_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__93245e2233e05a370ab89bb4879a54e73afa11722c5cc0093a72a33b9495a10e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "roleName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, VaultRadarSecretManagerVaultDedicatedKubernetes]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, VaultRadarSecretManagerVaultDedicatedKubernetes]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, VaultRadarSecretManagerVaultDedicatedKubernetes]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8accdf5b71da1bac3e2bd07a65c0c339e143a154ce46f8e55f550f019b6aef3e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktf/provider-hcp.vaultRadarSecretManagerVaultDedicated.VaultRadarSecretManagerVaultDedicatedToken",
    jsii_struct_bases=[],
    name_mapping={"token_env_var": "tokenEnvVar"},
)
class VaultRadarSecretManagerVaultDedicatedToken:
    def __init__(self, *, token_env_var: builtins.str) -> None:
        '''
        :param token_env_var: Environment variable name containing the Vault token. Example: 'VAULT_TOKEN'. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#token_env_var VaultRadarSecretManagerVaultDedicated#token_env_var}
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a594f1c77f01f388ddff5ad01e9c890b1123694d67a13d7ef9ecc6af86de18a7)
            check_type(argname="argument token_env_var", value=token_env_var, expected_type=type_hints["token_env_var"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "token_env_var": token_env_var,
        }

    @builtins.property
    def token_env_var(self) -> builtins.str:
        '''Environment variable name containing the Vault token. Example: 'VAULT_TOKEN'.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/hcp/0.111.0/docs/resources/vault_radar_secret_manager_vault_dedicated#token_env_var VaultRadarSecretManagerVaultDedicated#token_env_var}
        '''
        result = self._values.get("token_env_var")
        assert result is not None, "Required property 'token_env_var' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "VaultRadarSecretManagerVaultDedicatedToken(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class VaultRadarSecretManagerVaultDedicatedTokenOutputReference(
    _cdktf_9a9027ec.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktf/provider-hcp.vaultRadarSecretManagerVaultDedicated.VaultRadarSecretManagerVaultDedicatedTokenOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8a669c8da8150df1fa4b577221222ed4aed98f455900fe1c5e4a514038b69a53)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="tokenEnvVarInput")
    def token_env_var_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "tokenEnvVarInput"))

    @builtins.property
    @jsii.member(jsii_name="tokenEnvVar")
    def token_env_var(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "tokenEnvVar"))

    @token_env_var.setter
    def token_env_var(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c237ae4b13e43ec3f03b9b6ac79137d853c8d0056bc9722c330415fffe402f12)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "tokenEnvVar", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, VaultRadarSecretManagerVaultDedicatedToken]]:
        return typing.cast(typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, VaultRadarSecretManagerVaultDedicatedToken]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, VaultRadarSecretManagerVaultDedicatedToken]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2c1aeff41fbf52df15288d20d18bf41c1c8a855ffdd7ee83294c17da6abf9097)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


__all__ = [
    "VaultRadarSecretManagerVaultDedicated",
    "VaultRadarSecretManagerVaultDedicatedApprolePush",
    "VaultRadarSecretManagerVaultDedicatedApprolePushOutputReference",
    "VaultRadarSecretManagerVaultDedicatedConfig",
    "VaultRadarSecretManagerVaultDedicatedKubernetes",
    "VaultRadarSecretManagerVaultDedicatedKubernetesOutputReference",
    "VaultRadarSecretManagerVaultDedicatedToken",
    "VaultRadarSecretManagerVaultDedicatedTokenOutputReference",
]

publication.publish()

def _typecheckingstub__35ce44f700fb4a1db9e0e086c3a7a769942f26f70ba9db2c1e8b37ae31a69880(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    vault_url: builtins.str,
    access_read_write: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
    approle_push: typing.Optional[typing.Union[VaultRadarSecretManagerVaultDedicatedApprolePush, typing.Dict[builtins.str, typing.Any]]] = None,
    kubernetes: typing.Optional[typing.Union[VaultRadarSecretManagerVaultDedicatedKubernetes, typing.Dict[builtins.str, typing.Any]]] = None,
    project_id: typing.Optional[builtins.str] = None,
    token: typing.Optional[typing.Union[VaultRadarSecretManagerVaultDedicatedToken, typing.Dict[builtins.str, typing.Any]]] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d15fa2282b2c73c0a8cf31207a6b0747a4a9e6e716213220a29af208a6747a50(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fa7204f072c659d633d6f8de2e8f395839054bd0fd951d7031583bfb8d3230ad(
    value: typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__53ae998d8c56d9073e8f6cf7fc8ede81a5ae883212bb33eda0b65fbd25012dad(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1faf2e8da6f9bca7ed7091ac507bea1e5a609e3345a938c4c336edb4554e0f90(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b40efeeee11b5343ff7f5cd784a55b2f8d64a2c17248be3ef63861c34d9d5fe7(
    *,
    mount_path: builtins.str,
    role_id_env_var: builtins.str,
    secret_id_env_var: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5a2bf1ce36b6d2959e325a3939dba35fbca2f15888c8e643546248443b6e77a0(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b34c48b23894baec786cae63cf1ad8bc16dca970f555e0d5663b7a7ff9d91892(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fef0f9673ae0cbca28dc5a8849dbfbfd8000359f88af800d1666c1fb0db5228e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4e499c547ab2e3be0235cd2bcacb0ec2080d46fbfdbfd72c8a0a011768cd99ad(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b76629fbbcced2cf7afdf3c3ef533662b7b95c3f675a523a7fcb84ed8ee687ae(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, VaultRadarSecretManagerVaultDedicatedApprolePush]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b70a2e8eeb8872c8380accc6e9a5fdc7fb10d6e696e657eb7f6f9c48cfd41ca3(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktf_9a9027ec.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktf_9a9027ec.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktf_9a9027ec.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktf_9a9027ec.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktf_9a9027ec.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktf_9a9027ec.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktf_9a9027ec.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktf_9a9027ec.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    vault_url: builtins.str,
    access_read_write: typing.Optional[typing.Union[builtins.bool, _cdktf_9a9027ec.IResolvable]] = None,
    approle_push: typing.Optional[typing.Union[VaultRadarSecretManagerVaultDedicatedApprolePush, typing.Dict[builtins.str, typing.Any]]] = None,
    kubernetes: typing.Optional[typing.Union[VaultRadarSecretManagerVaultDedicatedKubernetes, typing.Dict[builtins.str, typing.Any]]] = None,
    project_id: typing.Optional[builtins.str] = None,
    token: typing.Optional[typing.Union[VaultRadarSecretManagerVaultDedicatedToken, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4bdcb06d543f1d6112c5c5de857af658f4d0b87dadd4d307432a33036c48f246(
    *,
    mount_path: builtins.str,
    role_name: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9999dd674b71f3fb7a6b8f86441dd7a816e8af0125a38ccd13a8e6946271bd3c(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5a4f336d7a408e60b3ba7680b8b31dd542b6c616467bd28645bbd39b234f2211(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__93245e2233e05a370ab89bb4879a54e73afa11722c5cc0093a72a33b9495a10e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8accdf5b71da1bac3e2bd07a65c0c339e143a154ce46f8e55f550f019b6aef3e(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, VaultRadarSecretManagerVaultDedicatedKubernetes]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a594f1c77f01f388ddff5ad01e9c890b1123694d67a13d7ef9ecc6af86de18a7(
    *,
    token_env_var: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8a669c8da8150df1fa4b577221222ed4aed98f455900fe1c5e4a514038b69a53(
    terraform_resource: _cdktf_9a9027ec.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c237ae4b13e43ec3f03b9b6ac79137d853c8d0056bc9722c330415fffe402f12(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2c1aeff41fbf52df15288d20d18bf41c1c8a855ffdd7ee83294c17da6abf9097(
    value: typing.Optional[typing.Union[_cdktf_9a9027ec.IResolvable, VaultRadarSecretManagerVaultDedicatedToken]],
) -> None:
    """Type checking stubs"""
    pass
