from .methods import GetDomains
from .types import Domain

__all__ = [
    Domain,
    GetDomains,
]
