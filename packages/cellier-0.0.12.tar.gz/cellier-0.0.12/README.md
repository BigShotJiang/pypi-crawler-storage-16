# cellier

[![License](https://img.shields.io/pypi/l/cellier.svg?color=green)](https://github.com/kevinyamauchi/cellier/raw/main/LICENSE)
[![PyPI](https://img.shields.io/pypi/v/cellier.svg?color=green)](https://pypi.org/project/cellier)
[![Python Version](https://img.shields.io/pypi/pyversions/cellier.svg?color=green)](https://python.org)
[![CI](https://github.com/kevinyamauchi/cellier/actions/workflows/ci.yml/badge.svg)](https://github.com/kevinyamauchi/cellier/actions/workflows/ci.yml)
[![codecov](https://codecov.io/gh/kevinyamauchi/cellier/branch/main/graph/badge.svg)](https://codecov.io/gh/kevinyamauchi/cellier)

🚧 Note: this repo is experimental and not meant to be used (i.e., nothing is working) - please come back later!

A workshop for rendering cellular models.
