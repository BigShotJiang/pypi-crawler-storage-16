"""Convenience module for making Qt GUIs."""
