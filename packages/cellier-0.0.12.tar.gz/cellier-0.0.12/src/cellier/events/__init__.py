"""Infrastructure for the events system."""

from cellier.events._event_bus import EventBus

__all__ = ["EventBus"]
