"""Infrastructure to manage slicing of the data for viewing."""
