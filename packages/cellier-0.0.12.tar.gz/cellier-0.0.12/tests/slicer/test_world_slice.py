def test_axis_aligned_slice():
    pass
