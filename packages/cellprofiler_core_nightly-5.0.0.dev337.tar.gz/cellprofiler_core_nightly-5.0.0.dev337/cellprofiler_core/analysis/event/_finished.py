class Finished:
    def __init__(self, measurements, cancelled):
        self.measurements = measurements
        self.cancelled = cancelled
