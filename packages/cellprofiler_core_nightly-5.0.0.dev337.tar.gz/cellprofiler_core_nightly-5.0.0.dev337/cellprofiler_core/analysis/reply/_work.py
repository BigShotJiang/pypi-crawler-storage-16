from ...utilities.zmq.communicable.reply import Reply


class Work(Reply):
    pass
