from ...utilities.zmq.communicable.request import AnalysisRequest


class InitialMeasurements(AnalysisRequest):
    pass
