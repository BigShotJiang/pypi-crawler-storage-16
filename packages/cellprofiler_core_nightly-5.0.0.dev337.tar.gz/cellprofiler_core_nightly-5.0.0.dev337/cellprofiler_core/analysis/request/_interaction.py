from ...utilities.zmq.communicable.request import AnalysisRequest


class Interaction(AnalysisRequest):
    pass
