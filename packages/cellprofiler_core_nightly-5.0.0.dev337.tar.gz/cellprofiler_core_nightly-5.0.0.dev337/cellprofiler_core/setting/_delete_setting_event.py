class DeleteSettingEvent:
    def __init__(self):
        pass
