from ._crop_image_name import CropImageName
from ._external_image_name import ExternalImageName
from ._file_image_name import FileImageName
from ._image_name import ImageName
from ._outline_image_name import OutlineImageName
