from ._float import Float
from ._number import Number
from .integer import Integer
from .integer import OddInteger
