class PollTimeoutException(Exception):
    """Exception issued by a timeout from polling """

    pass
