from ._reply import Reply


class UpstreamExit(Reply):
    pass
