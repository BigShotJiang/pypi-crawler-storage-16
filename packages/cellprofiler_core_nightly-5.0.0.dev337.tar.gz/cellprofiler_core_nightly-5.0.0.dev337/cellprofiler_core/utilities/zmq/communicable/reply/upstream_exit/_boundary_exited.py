from cellprofiler_core.utilities.zmq.communicable.reply.upstream_exit._upstream_exit import (
    UpstreamExit,
)


class BoundaryExited(UpstreamExit):
    pass
