class DispositionChangedEvent:
    def __init__(self, disposition):
        self.disposition = disposition
