from ..functions.image_processing import median_filter

def medianfilter(image, window_size, mode):
    return median_filter(image, window_size, mode)
