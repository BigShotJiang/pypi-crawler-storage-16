# セットアップ

```
npm install -g mint
```

または

```
yarn global add mint
```

# プレビュー

```
mint dev
```
