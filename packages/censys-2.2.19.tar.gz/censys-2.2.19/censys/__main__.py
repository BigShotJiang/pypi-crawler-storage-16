"""Main function for when executed with python -m censys."""

from .cli import main

main()
