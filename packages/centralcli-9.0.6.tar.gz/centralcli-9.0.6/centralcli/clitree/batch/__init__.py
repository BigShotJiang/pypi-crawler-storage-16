from centralcli.strings import ImportExamples

examples = ImportExamples()