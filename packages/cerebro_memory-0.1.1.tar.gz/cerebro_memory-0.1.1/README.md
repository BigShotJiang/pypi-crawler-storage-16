# Cerebro

A pluggable memory framework for AI applications. Build persistent, intelligent memory for your AI agents and applications.

## Features

- **Pluggable Architecture**: Bring your own storage, vector DB, embeddings, and LLM
- **Two-Tier Caching**: Redis L1 cache (fixed) + pluggable L2 storage
- **Smart Retrieval**: Hybrid scoring combining semantic similarity, recency, and importance
- **Automatic Extraction**: Extract facts from conversations using LLM
- **Deduplication**: Prevent duplicate memories with similarity-based dedup

## Installation

```bash
# Core package
pip install cerebro-memory

# With specific providers
pip install cerebro-memory[openai,chroma,sqlite,redis]

# All providers
pip install cerebro-memory[all]
```

## Quick Start

```python
from cerebro import Memory

# Initialize with defaults (SQLite + Chroma + OpenAI)
memory = Memory()

# Add memories from conversation
result = memory.add(
    messages="Hi, I'm John. I love Python and hate JavaScript.",
    user_id="user_123"
)
# Extracts: ["Name is John", "Loves Python", "Hates JavaScript"]

# Search memories
results = memory.search(
    query="What programming languages does the user like?",
    user_id="user_123"
)

# Get all memories
all_memories = memory.get_all(user_id="user_123")
```

## Configuration

```python
from cerebro import Memory

config = {
    # L1 Cache (Redis - fixed)
    "cache": {
        "redis_url": "redis://localhost:6379",
        "ttl_seconds": 3600,
        "enabled": True,
    },
    
    # L2 Storage (pluggable)
    "storage": {
        "provider": "postgres",  # or "mongodb", "sqlite"
        "config": {
            "host": "localhost",
            "port": 5432,
            "database": "cerebro",
            "user": "postgres",
            "password": "password",
        }
    },
    
    # Vector Store (pluggable)
    "vector_store": {
        "provider": "qdrant",  # or "pinecone", "chroma", "pgvector"
        "config": {
            "url": "http://localhost:6333",
            "collection_name": "memories",
        }
    },
    
    # Embeddings (pluggable)
    "embedder": {
        "provider": "openai",  # or "cohere", "ollama", "huggingface"
        "config": {
            "model": "text-embedding-3-small",
        }
    },
    
    # LLM (pluggable)
    "llm": {
        "provider": "openai",  # or "anthropic", "ollama"
        "config": {
            "model": "gpt-4o-mini",
        }
    },
}

memory = Memory(config)
```

## Async Usage

```python
from cerebro import AsyncMemory
import asyncio

async def main():
    memory = AsyncMemory()
    
    await memory.add(
        messages="I prefer dark mode in all my apps",
        user_id="user_123"
    )
    
    results = await memory.search(
        query="user preferences",
        user_id="user_123"
    )
    
    await memory.close()

asyncio.run(main())
```

## Supported Providers

### Storage (L2)
- SQLite (default, local)
- PostgreSQL
- MongoDB

### Vector Stores
- Chroma (default, local)
- Pinecone
- Qdrant
- pgvector

### Embeddings
- OpenAI (default)
- Cohere
- Ollama (local)
- HuggingFace (local)

### LLMs
- OpenAI (default)
- Anthropic
- Ollama (local)

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     Cerebro Memory                           │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────────────────────────────────────────────────┐│
│  │                  Core Algorithms                         ││
│  │  • Importance Scoring    • Fact Extraction              ││
│  │  • Hybrid Retrieval      • Deduplication                ││
│  └─────────────────────────────────────────────────────────┘│
│                                                              │
│  ┌───────────┐  ┌───────────────┐  ┌───────────────────┐   │
│  │ L1 Cache  │  │  L2 Storage   │  │   Vector Store    │   │
│  │  (Redis)  │  │  (Pluggable)  │  │   (Pluggable)     │   │
│  │  FIXED    │  │               │  │                   │   │
│  └───────────┘  └───────────────┘  └───────────────────┘   │
│                                                              │
│  ┌─────────────────────────────────────────────────────────┐│
│  │              Embedding + LLM Providers                   ││
│  │                    (Pluggable)                           ││
│  └─────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────┘
```

## License

Apache 2.0
