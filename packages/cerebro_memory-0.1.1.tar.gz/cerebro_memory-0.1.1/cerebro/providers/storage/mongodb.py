"""
MongoDB storage provider implementation.
"""

from typing import Any
from datetime import datetime

from cerebro.models import Memory


class MongoStorage:
    """
    MongoDB implementation of L2StorageProvider.
    
    Requires: motor
    """
    
    def __init__(
        self, 
        connection_string: str, 
        database: str = "cerebro",
        collection: str = "memories"
    ):
        self.connection_string = connection_string
        self.database_name = database
        self.collection_name = collection
        self._client = None
        self._db = None
        self._collection = None
    
    async def _get_collection(self):
        if self._collection is None:
            from motor.motor_asyncio import AsyncIOMotorClient
            self._client = AsyncIOMotorClient(self.connection_string)
            self._db = self._client[self.database_name]
            self._collection = self._db[self.collection_name]
        return self._collection
    
    async def initialize(self) -> None:
        """Create indexes."""
        collection = await self._get_collection()
        await collection.create_index("user_id")
        await collection.create_index("importance")
        await collection.create_index([("user_id", 1), ("importance", -1)])
    
    async def save(self, memories: list[Memory]) -> None:
        collection = await self._get_collection()
        
        from pymongo import UpdateOne
        operations = [
            UpdateOne(
                {"_id": memory.id},
                {"$set": self._memory_to_doc(memory)},
                upsert=True
            )
            for memory in memories
        ]
        
        if operations:
            await collection.bulk_write(operations)
    
    async def get(self, ids: list[str]) -> list[Memory]:
        if not ids:
            return []
        
        collection = await self._get_collection()
        cursor = collection.find({"_id": {"$in": ids