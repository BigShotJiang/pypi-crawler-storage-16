"""Storage providers for Cerebro."""

from cerebro.storage.base import StorageBase

__all__ = ["StorageBase"]
