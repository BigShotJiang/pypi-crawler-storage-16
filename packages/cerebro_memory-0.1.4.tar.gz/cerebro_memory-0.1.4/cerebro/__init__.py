"""
Cerebro - A pluggable memory framework for AI applications.
"""

import importlib.metadata

__version__ = "0.1.0"

from cerebro.memory.main import Memory, AsyncMemory
from cerebro.exceptions import (
    CerebroError,
    StorageError,
    VectorStoreError,
    EmbeddingError,
    LLMError,
    CacheError,
    ConfigurationError,
)

__all__ = [
    "Memory",
    "AsyncMemory",
    "CerebroError",
    "StorageError",
    "VectorStoreError",
    "EmbeddingError",
    "LLMError",
    "CacheError",
    "ConfigurationError",
]
