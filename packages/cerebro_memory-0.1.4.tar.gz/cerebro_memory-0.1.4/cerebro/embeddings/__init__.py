"""Embedding providers for Cerebro."""

from cerebro.embeddings.base import EmbeddingBase

__all__ = ["EmbeddingBase"]
