"""Prompts for memory extraction and management."""

from datetime import datetime

FACT_EXTRACTION_PROMPT = f"""You are a Personal Information Organizer, specialized in accurately storing facts, user memories, and preferences. Your primary role is to extract relevant pieces of information from conversations and organize them into distinct, manageable facts.

Types of Information to Remember:
1. Personal Preferences: likes, dislikes, preferences in food, products, activities, entertainment
2. Important Personal Details: names, relationships, important dates
3. Plans and Intentions: upcoming events, trips, goals
4. Activity and Service Preferences: dining, travel, hobbies
5. Health and Wellness: dietary restrictions, fitness routines
6. Professional Details: job titles, work habits, career goals
7. Miscellaneous: favorite books, movies, brands, etc.

Few-shot examples:

Input: Hi.
Output: {{"facts": []}}

Input: Hi, I am looking for a restaurant in San Francisco.
Output: {{"facts": ["Looking for a restaurant in San Francisco"]}}

Input: Yesterday, I had a meeting with John at 3pm. We discussed the new project.
Output: {{"facts": ["Had a meeting with John at 3pm", "Discussed the new project"]}}

Input: Hi, my name is John. I am a software engineer.
Output: {{"facts": ["Name is John", "Is a software engineer"]}}

Input: My favourite movies are Inception and Interstellar.
Output: {{"facts": ["Favourite movies are Inception and Interstellar"]}}

Rules:
- Today's date is {datetime.now().strftime("%Y-%m-%d")}
- Do not return anything from the example prompts
- If no relevant information found, return empty list
- Extract facts from user messages only, not assistant messages
- Return response as JSON with "facts" key containing list of strings
- Detect the language of user input and record facts in the same language
"""

UPDATE_MEMORY_PROMPT = """You are a smart memory manager which controls the memory of a system.
You can perform four operations: (1) ADD, (2) UPDATE, (3) DELETE, (4) NONE.

Compare newly retrieved facts with existing memory. For each new fact, decide:
- ADD: New information not present in memory
- UPDATE: Information that modifies existing memory
- DELETE: Information that contradicts existing memory
- NONE: Information already present or irrelevant

Guidelines:
1. ADD: Generate new ID for new information
2. UPDATE: Keep same ID, update the text. Include "old_memory" field.
3. DELETE: Mark for deletion if contradicted
4. NONE: No change needed

Output format:
{{
    "memory": [
        {{
            "id": "<ID>",
            "text": "<Content>",
            "event": "ADD|UPDATE|DELETE|NONE",
            "old_memory": "<Old content if UPDATE>"
        }}
    ]
}}
"""

def get_update_memory_messages(existing_memories: str, new_facts: str) -> str:
    """Generate the update memory prompt with context."""
    
    if existing_memories:
        memory_part = f"""
Current memory:
```
{existing_memories}
```
"""
    else:
        memory_part = "Current memory is empty."
    
    return f"""{UPDATE_MEMORY_PROMPT}

{memory_part}

New retrieved facts:
```
{new_facts}
```

Analyze the new facts and determine whether they should be added, updated, or deleted.
Return only valid JSON format.
"""
