# Configuration

Automatically generated documentation for configuration classes.

## LlmConfig

::: ceylonai_next.LlmConfig
    options:
      show_root_heading: true
      show_source: true
      members_order: source
      heading_level: 3

## ReActConfig

::: ceylonai_next.ReActConfig
    options:
      show_root_heading: true
      show_source: true
      members_order: source
      heading_level: 3

## ReActResult

::: ceylonai_next.ReActResult
    options:
      show_root_heading: true
      show_source: true
      members_order: source
      heading_level: 3

## ReActStep

::: ceylonai_next.ReActStep
    options:
      show_root_heading: true
      show_source: true
      members_order: source
      heading_level: 3
