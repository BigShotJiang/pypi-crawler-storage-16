##############################################################################
#
#                        Crossbar.io Database
#     Copyright (c) typedef int GmbH. Licensed under MIT.
#
##############################################################################

__all__ = ("InvalidConfigException",)


class InvalidConfigException(Exception):
    pass
