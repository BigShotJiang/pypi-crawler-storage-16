##############################################################################
#
#                        Crossbar.io Database
#     Copyright (c) typedef int GmbH. Licensed under MIT.
#
##############################################################################


class UserMrealmRoleFbs(object):
    """
    Database class for CFC user roles on a management realm using Flatbuffers.
    """

    def __init__(self):
        raise NotImplementedError("not yet implemented")
