"""Chad - AI Code Assistant Installer.

A tool to install and configure OpenAI Codex and Anthropic Claude Code on user systems.
"""

__version__ = "0.1.0"
