// SOCIAL
export const GITHUB_REPO_NAME = "chainless";
export const GITHUB_REPO_USERNAME = "onurartan";
export const GITHUB_REPO_URL = `https://www.github.com/${GITHUB_REPO_USERNAME}/${GITHUB_REPO_NAME}`;

export const TRYMAGIC_URL = "https://www.trymagic.xyz";
