import { EnvVars } from "@/types/envx";
import { getEnvx } from "typenvx";

export const envx = getEnvx<EnvVars>()
