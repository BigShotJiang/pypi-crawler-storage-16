# ---------- Metadata ---------- #
__app_name__ = "chainless"
__description__ = "Chainless is a lightweight, modular framework to build task-oriented AI agents and orchestrate them in intelligent flows."
__version__ = "0.2.0" 
# ---------- THE END ---------- #

