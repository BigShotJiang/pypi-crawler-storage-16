from setuptools import setup

# All package metadata, including dependencies, is specified in
# the pyproject.toml file

setup()
