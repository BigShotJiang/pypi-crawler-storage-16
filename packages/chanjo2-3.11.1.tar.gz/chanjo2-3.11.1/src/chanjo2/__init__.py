from dotenv import load_dotenv

__version__ = "3.11.1"
load_dotenv()
