"""Entry point for running chapkit.cli as a module."""

from chapkit.cli.cli import main

if __name__ == "__main__":
    main()
