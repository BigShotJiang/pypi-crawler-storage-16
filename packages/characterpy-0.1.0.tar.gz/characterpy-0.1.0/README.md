# characterpy
Python in-house 5E compatible character creator and manager

