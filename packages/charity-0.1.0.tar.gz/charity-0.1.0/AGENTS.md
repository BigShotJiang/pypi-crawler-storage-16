* Always talk to me in the language I'm talking to you
* Always write to project files in English