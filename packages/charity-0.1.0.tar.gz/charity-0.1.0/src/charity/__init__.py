"""charity package entry point definitions."""
