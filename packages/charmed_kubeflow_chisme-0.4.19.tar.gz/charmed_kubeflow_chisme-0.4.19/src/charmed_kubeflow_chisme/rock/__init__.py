# Copyright 2022 Canonical Ltd.
# See LICENSE file for licensing details.

"""Class for Handling Rocks in Charms and Tests."""

from ._check_rock import CheckRock

__all__ = [CheckRock]
