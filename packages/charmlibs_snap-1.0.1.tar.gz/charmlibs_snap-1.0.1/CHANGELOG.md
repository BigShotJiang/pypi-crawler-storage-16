# 1.0.1 - 4 November 2025

Update the type annotation of `log`'s `num_lines` parameter to indicate that `'all'` is accepted.

# 1.0.0.post0 - 14 October 2025

Update project URLs.

# 1.0.0 - 23 September 2025

Initial release of migrated `operator_libs_linux.v2.snap` library (patch version 14).
