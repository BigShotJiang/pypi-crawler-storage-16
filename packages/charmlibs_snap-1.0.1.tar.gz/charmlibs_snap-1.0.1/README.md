# charmlibs-snap

The `snap` library.

To install, add `charmlibs-snap` to your Python dependencies. Then in your Python code, import as:

```py
from charmlibs import snap
```

See the [reference documentation](https://documentation.ubuntu.com/charmlibs/reference/charmlibs/snap) for more.
