<p align="center">
  <img src="assets/banner.png" alt="Charm Banner" width="100%" />
</p>

<p align="center">
  <a href="https://charmos.io/">Homepage</a> ·
  <a href="https://github.com/CharmAIOS/Charm/tree/main/docs">Documentation</a> ·
  <a href="https://github.com/CharmAIOS/Charm/blob/main/CONTRIBUTING.md">Contributing</a> ·
  <a href="https://discord.gg/gdakynHUEb">Discord</a>
</p>

# Charm: The Unified Platform for Agentic Intelligence

> **Current Status: v0.2.0 (Developer Preview)**
>
> We are building the **Universal Interface Protocol**.
> v0.2.0 focuses on the **Development Layer**, providing the **Unified Agent Contract (UAC)** and **Wrapper SDK** to turn existing agents into Universal Charm Agents.

**Charm** is a **Unified System Layer** that governs the development, execution, and distribution of AI agents.

It provides a standardized architecture that enables agents to assemble, interoperate, and scale across heterogeneous ecosystems, turning them into real, commercial-ready applications.

---

## Why Charm?
Before you dive deeper, we’d like you to take a moment to read this [blog post](https://charmos.io/blog/1) to understand our insights and perspective.

## Getting started
To explore Charm’s core concepts and code in more detail, check out our [documentation](https://github.com/CharmAIOS/Charm/tree/main/docs).
### Installation
Charm is not published to PyPI yet.  
To try the current demo from source:

1. Clone the repository
   ```bash
   git clone https://github.com/CharmAIOS/Charm.git
   cd Charm
2. Create and activate a virtual environment
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
3. Install Charm in editable mode
   ```bash 
   pip install -e .
4. Run the working demo
   ```bash 
   python src/charm/demo/demo_mock.py  # python -m charm.demo.demo_mock

## Contributing
To learn how to contribute to Charm, please read the contribution guide [here](https://github.com/CharmAIOS/Charm/blob/main/CONTRIBUTING.md).

## Contact
- Support and Questions: [Community](https://discord.gg/gdakynHUEb) / [Email](mailto:team@charmos.io)
- Join the Charm team: [Chat with us](mailto:uc@charmos.io)

## Changelog
Check our [updates](https://charmos.io/changelog)

## License
Charm is licensed under the [GNU Affero General Public License v3.0](https://github.com/CharmAIOS/CharmOS/blob/main/LICENSE)
