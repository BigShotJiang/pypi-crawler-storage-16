"""Support for python -m check_msdefender."""

from check_msdefender.cli import main

if __name__ == "__main__":
    main()
