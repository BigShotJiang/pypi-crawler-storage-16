"""Main entry point for check_msdefender Nagios plugin."""

from check_msdefender.cli import main

if __name__ == "__main__":
    main()
