"""Check Microsoft Defender API endpoints and check values - Nagios plugin."""
__version__ = "1.1.16"
__author__ = "ldvchosal"
__email__ = "ldvchosa@github.com"
