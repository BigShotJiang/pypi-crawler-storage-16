"""
CLI entry point for check_netscaler
"""

import sys

from check_netscaler.cli import main

if __name__ == "__main__":
    sys.exit(main())
