from .xml_results import get_xml_results, get_xml_results_as_dict
