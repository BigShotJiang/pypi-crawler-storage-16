
# Cheez SDK

## Installation

```bash
pip install cheez_semg_pico
```

## Quick Start

```python
from cheez_semg_pico import CheezPico   
import asyncio  

async def main():  
    sEMG = CheezPico()  
    device = None   
    device = sEMG.connect()                     # 连接设备   

    await sEMG.set_device_id(2)                 # 设置设备ID:0~255   
    # 配置采样率:100 Hz, 200 Hz, 500 Hz, 1000 Hz
    await sEMG.set_sampling_rate(200)     
    await sEMG.set_wear_detection(enable=False) # 设置是否开启佩戴检测  
    await sEMG.set_filter_state(enable=True)    # 设置是否开启滤波  
 
    while True:  
        data = await device.read_data()         # 读取设备  
        print(f"data:{data},sps({device.get_packet_rate()})")
 

if __name__ == "__main__":  
    asyncio.run(main())   

```

## Features

- Easy device port discovery
- Simple serial connection management
- Async data reading
- Configurable logging
- Error handling and validation
 