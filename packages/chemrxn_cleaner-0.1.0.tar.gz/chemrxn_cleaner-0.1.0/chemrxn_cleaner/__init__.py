# chemrxn_cleaner/__init__.py

__version__ = "0.1.0"

import logging

from .cleaner import (
    clean_and_canonicalize,
    clean_reactions,
    clean_reactions_with_report,
)
from .filters import (
    ElementFilterRule,
    ReactionFilter,
    all_molecules_valid,
    default_filters,
    element_filter,
    has_product,
    max_smiles_length,
    meta_filter,
)
from .io import (
    export_reaction_records,
    get_input_format,
    load_reactions,
    register_input_format,
)
from .ml import ForwardReactionDataset, records_to_dataframe, train_valid_test_split
from .parser import canonicalize_reaction, parse_reaction_smiles
from .reporter import CleaningStats, FilterStats
from .types import ReactionRecord
from .utils import similarity_filter

# Avoid "No handler found" warnings if the host app has not configured logging.
logging.getLogger(__name__).addHandler(logging.NullHandler())

__all__ = [
    # types
    "ReactionRecord",
    # parser
    "parse_reaction_smiles",
    "canonicalize_reaction",
    # reporting
    "CleaningStats",
    "FilterStats",
    # filters
    "ReactionFilter",
    "ElementFilterRule",
    "has_product",
    "all_molecules_valid",
    "max_smiles_length",
    "element_filter",
    "meta_filter",
    "default_filters",
    "similarity_filter",
    # cleaner
    "clean_reactions",
    "clean_reactions_with_report",
    "clean_and_canonicalize",
    # io
    "register_input_format",
    "get_input_format",
    "load_reactions",
    "export_reaction_records",
    # ml
    "ForwardReactionDataset",
    "records_to_dataframe",
    "train_valid_test_split",
]
