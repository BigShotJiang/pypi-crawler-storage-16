"""
ORCA job settings implementation.

This module contains the settings classes for configuring ORCA quantum chemistry
calculations, including general settings and specialized settings for transition
state and IRC calculations.
"""

import copy
import logging
import os
import re

from chemsmart.io.orca import ORCA_ALL_SOLVENT_MODELS
from chemsmart.jobs.settings import MolecularJobSettings
from chemsmart.utils.utils import (
    get_prepend_string_list_from_modred_free_format,
)

logger = logging.getLogger(__name__)


class ORCAJobSettings(MolecularJobSettings):
    """
    Settings for ORCA quantum chemistry jobs.

    This class handles the configuration of ORCA calculations including
    method selection, basis sets, solvation, convergence criteria, and
    various calculation types.

    Attributes:
        ab_initio (str | None): Ab initio method (e.g., 'HF', 'MP2').
        functional (str | None): DFT functional (e.g., 'B3LYP', 'PBE0').
        dispersion (str | None): Dispersion correction (e.g., 'D3BJ').
        basis (str | None): Orbital basis set (e.g., 'def2-TZVP').
        aux_basis (str | None): Auxiliary basis set for RI/DF methods.
        extrapolation_basis (str | None): Basis for extrapolation schemes.
        defgrid (str | None): Grid quality keyword (e.g., 'defgrid2').
        scf_tol (str | float | None): SCF convergence tolerance.
        scf_algorithm (str | None): SCF algorithm.
        scf_maxiter (int | None): Maximum SCF iterations.
        scf_convergence (str | None): SCF convergence criteria.
        charge (int | None): Molecular charge.
        multiplicity (int | None): Spin multiplicity.
        gbw (bool): Write GBW file.
        freq (bool): Perform vibrational frequency calculation.
        numfreq (bool): Use numerical frequencies.
        dipole (bool): Compute dipole moment.
        quadrupole (bool): Compute quadrupole moment.
        mdci_cutoff (float | None): MDCI cutoff.
        mdci_density (float | None): MDCI density.
        job_type (str | None): Calculation type (e.g., 'opt', 'sp').
        title (str | None): Job title string.
        solvent_model (str | None): Solvation model identifier.
        solvent_id (str | None): Solvent identifier.
        additional_route_parameters (str | None): Extra route parameters.
        route_to_be_written (str | None): Custom route string to write.
        modred (list | dict | None): Modredundant coordinates specification.
        gen_genecp_file (str | None): Path to gen/genecp file to include.
        heavy_elements (list | None): Heavy elements list for genecp.
        heavy_elements_basis (str | None): Basis for heavy elements.
        light_elements_basis (str | None): Basis for light elements.
        custom_solvent (str | None): Custom solvent parameters block.
        forces (bool): Calculate forces.
        input_string (str | None): Predefined input content to write directly.
        invert_constraints (bool): Invert modred constraints if True.
    """

    def __init__(
        self,
        ab_initio=None,
        functional=None,
        dispersion=None,
        basis=None,
        aux_basis=None,
        extrapolation_basis=None,
        defgrid=None,
        scf_tol=None,
        scf_algorithm=None,
        scf_maxiter=None,
        scf_convergence=None,
        charge=None,
        multiplicity=None,
        gbw=True,
        freq=False,
        numfreq=False,
        dipole=False,
        quadrupole=False,
        mdci_cutoff=None,
        mdci_density=None,
        job_type=None,
        title=None,
        solvent_model=None,
        solvent_id=None,
        additional_route_parameters=None,
        route_to_be_written=None,
        modred=None,
        gen_genecp_file=None,
        heavy_elements=None,
        heavy_elements_basis=None,
        light_elements_basis=None,
        custom_solvent=None,
        forces=False,
        input_string=None,
        invert_constraints=False,
        **kwargs,
    ):
        """
        Initialize ORCA job settings.

        Args:
            ab_initio: Ab initio method (e.g., 'HF', 'MP2')
            functional: DFT functional (e.g., 'B3LYP', 'PBE0')
            dispersion: Dispersion correction (e.g., 'D3BJ')
            basis: Basis set (e.g., 'def2-TZVP')
            aux_basis: Auxiliary basis set
            extrapolation_basis: Extrapolation basis set
            defgrid: Grid quality (e.g., 'defgrid2')
            scf_tol: SCF convergence tolerance
            scf_algorithm: SCF algorithm
            scf_maxiter: Maximum SCF iterations
            scf_convergence: SCF convergence criteria
            charge: Molecular charge
            multiplicity: Spin multiplicity
            gbw: Whether to write GBW file
            freq: Whether to calculate frequencies
            numfreq: Whether to use numerical frequencies
            dipole: Whether to calculate dipole moment
            quadrupole: Whether to calculate quadrupole moment
            mdci_cutoff: MDCI cutoff
            mdci_density: MDCI density
            job_type: Type of calculation
            title: Job title
            solvent_model: Solvation model
            solvent_id: Solvent identifier
            additional_route_parameters: Additional route parameters
            route_to_be_written: Custom route string
            modred: Modified redundant coordinates
            gen_genecp_file: General ECP file
            heavy_elements: Heavy elements list
            heavy_elements_basis: Basis for heavy elements
            light_elements_basis: Basis for light elements
            custom_solvent: Custom solvent parameters
            forces: Whether to calculate forces
            input_string: Custom input string
            invert_constraints: Whether to invert constraints
            **kwargs: Additional keyword arguments
        """
        super().__init__(
            ab_initio=ab_initio,
            functional=functional,
            dispersion=dispersion,
            basis=basis,
            defgrid=defgrid,
            charge=charge,
            multiplicity=multiplicity,
            freq=freq,
            numfreq=numfreq,
            job_type=job_type,
            title=title,
            solvent_model=solvent_model,
            solvent_id=solvent_id,
            additional_route_parameters=additional_route_parameters,
            route_to_be_written=route_to_be_written,
            modred=modred,
            gen_genecp_file=gen_genecp_file,
            heavy_elements=heavy_elements,
            heavy_elements_basis=heavy_elements_basis,
            light_elements_basis=light_elements_basis,
            custom_solvent=custom_solvent,
            forces=forces,
            input_string=input_string,
            **kwargs,
        )

        # ORCA-specific parameters
        self.aux_basis = aux_basis
        self.extrapolation_basis = extrapolation_basis
        self.scf_tol = scf_tol
        self.scf_algorithm = scf_algorithm
        self.scf_maxiter = scf_maxiter
        self.scf_convergence = scf_convergence
        self.gbw = gbw
        self.mdci_cutoff = mdci_cutoff
        self.mdci_density = mdci_density
        self.dipole = dipole
        self.quadrupole = quadrupole
        self.invert_constraints = invert_constraints

        # Validate frequency and force settings
        if forces is True and (freq is True or numfreq is True):
            raise ValueError(
                "Frequency and Force calculations cannot be performed by "
                "Orca at the same time!\n"
                'Such an input file will give "Illegal IType or MSType '
                'generated by parse." error.'
            )

    def merge(
        self, other, keywords=("charge", "multiplicity"), merge_all=False
    ):
        """
        Merge this settings object with another.

        Args:
            other: Settings object or dictionary to merge with
            keywords: Specific keywords to merge if merge_all is False
            merge_all: Whether to merge all attributes

        Returns:
            ORCAJobSettings: New merged settings object
        """

        other_dict = other if isinstance(other, dict) else other.__dict__

        if merge_all:
            # Update self with other for all
            merged_dict = self.__dict__.copy()
            merged_dict.update(other_dict)
            return type(self)(**merged_dict)

        if keywords is not None:
            other_dict = {
                k: other_dict[k] for k in keywords if k in other_dict
            }
        # Update self with other
        merged_dict = self.__dict__.copy()
        merged_dict.update(other_dict)
        return type(self)(**merged_dict)

    def copy(self):
        """
        Create a deep copy of the settings object.

        Returns:
            ORCAJobSettings: Deep copy of this settings object
        """
        return copy.deepcopy(self)

    def __getitem__(self, key):
        """
        Get settings attribute by key.

        Args:
            key: Attribute name to retrieve

        Returns:
            Value of the specified attribute
        """
        return self.__dict__[key]

    def __eq__(self, other):
        """
        Check equality with another settings object.

        Args:
            other: Another settings object to compare

        Returns:
            bool: True if settings are equal, False otherwise
        """
        if type(self) is not type(other):
            return NotImplemented

        # Exclude append_additional_info from the comparison
        self_dict = self.__dict__
        self_dict.pop("append_additional_info")

        other_dict = other.__dict__
        other_dict.pop("append_additional_info")

        return self_dict == other_dict

    @classmethod
    def from_comfile(cls, com_path):
        """
        Create ORCA job settings from a Gaussian .com file.

        Args:
            com_path: Path to the Gaussian .com file

        Returns:
            ORCAJobSettings: Settings object from Gaussian file
        """
        com_path = os.path.abspath(com_path)
        from chemsmart.io.gaussian.input import Gaussian16Input

        logger.info(f"Return Settings object from {com_path}")
        gaussian_settings_from_comfile = Gaussian16Input(
            filename=com_path
        ).read_settings()
        orca_default_settings = cls.default()
        return orca_default_settings.merge(
            gaussian_settings_from_comfile, merge_all=True
        )

    @classmethod
    def from_logfile(cls, log_path, **kwargs):
        """
        Create ORCA settings from Gaussian output .log file.

        Args:
            log_path: Path to the .log file
            **kwargs: Additional arguments for Gaussian16Output class

        Returns:
            ORCAJobSetting: Settings object from log file
        """
        log_path = os.path.abspath(log_path)
        from chemsmart.io.gaussian.output import Gaussian16Output

        logger.info(f"Return Settings object from {log_path}")
        gaussian_settings_from_logfile = Gaussian16Output(
            log_path
        ).read_settings()
        orca_default_settings = cls.default()
        orca_settings_from_logfile = orca_default_settings.merge(
            gaussian_settings_from_logfile, merge_all=True
        )
        # Convert def2 basis set naming
        if (
            "def2" in orca_settings_from_logfile.basis
            and "def2-" not in orca_settings_from_logfile.basis
        ):
            orca_settings_from_logfile.basis = (
                orca_settings_from_logfile.basis.replace("def2", "def2-")
            )
        return orca_settings_from_logfile

    @classmethod
    def from_inpfile(cls, inp_path):
        """
        Create ORCA job settings from ORCA .inp file.

        Args:
            inp_path: Path to the ORCA .inp file

        Returns:
            ORCAJobSettings: Settings object from input file
        """
        inp_path = os.path.abspath(inp_path)
        from chemsmart.io.orca.input import ORCAInput

        logger.info(f"Return settings object from {inp_path}")
        orca_settings_from_inpfile = ORCAInput(
            filename=inp_path
        ).read_settings()
        logger.info(f"with settings: {orca_settings_from_inpfile.__dict__}")
        return orca_settings_from_inpfile

    @classmethod
    def from_outfile(cls, out_path):
        """
        Create ORCA job settings from ORCA .out file.

        Args:
            out_path: Path to the ORCA .out file

        Returns:
            ORCAJobSettings: Settings object from output file
        """
        out_path = os.path.abspath(out_path)
        from chemsmart.io.orca.output import ORCAOutput

        logger.info(f"Return Settings object from {out_path}")
        return ORCAOutput(filename=out_path).read_settings()

    @classmethod
    def from_xyzfile(cls):
        """
        Create default ORCA job settings for .xyz file input.

        Returns:
            ORCAJobSettings: Default ORCA settings for xyz input
        """
        return ORCAJobSettings.default()

    @classmethod
    def from_filepath(cls, filepath, **kwargs):
        """
        Create settings from any supported file type.

        Args:
            filepath: Path to the input file
            **kwargs: Additional keyword arguments

        Returns:
            ORCAJobSettings or None: Settings object if file type supported
        """

        if ".com" in filepath or ".gjf" in filepath:
            return cls.from_comfile(filepath)

        if ".log" in filepath:
            return cls.from_logfile(filepath)

        if ".inp" in filepath:
            return cls.from_inpfile(filepath)

        if ".out" in filepath:
            return cls.from_outfile(filepath)

        if ".xyz" in filepath:
            return cls.from_xyzfile()

        return None

    @classmethod
    def default(cls):
        """
        Create default ORCA job settings.

        Returns:
            ORCAJobSettings: Default settings object
        """
        return cls(
            ab_initio=None,
            functional=None,
            dispersion=None,
            basis=None,
            aux_basis=None,
            extrapolation_basis=None,
            defgrid=None,
            scf_tol=None,
            scf_algorithm=None,
            scf_maxiter=None,
            scf_convergence=None,
            charge=None,
            multiplicity=None,
            gbw=True,
            freq=True,
            numfreq=False,
            mdci_cutoff=None,
            mdci_density=None,
            job_type=None,
            title=None,
            solvent_model=None,
            solvent_id=None,
            additional_route_parameters=None,
            route_to_be_written=None,
            modred=None,
            gen_genecp_file=None,
            heavy_elements=None,
            heavy_elements_basis=None,
            light_elements_basis=None,
            custom_solvent=None,
            forces=False,
            input_string=None,
            invert_constraints=False,
        )

    @property
    def route_string(self):
        """
        Get the ORCA route string for the job.

        Returns:
            str: ORCA route string based on job settings
        """
        if self.route_to_be_written is not None:
            route_string = self._get_route_string_from_user_input()
        else:
            route_string = self._get_route_string_from_jobtype()
        logger.debug(f"Route for settings {self}: {route_string}")
        return route_string

    def _get_route_string_from_user_input(self):
        """
        Get route string from user-provided input.

        Returns:
            str: User-specified route string with '!' prefix if needed
        """
        route_string = self.route_to_be_written
        if not route_string.startswith("!"):
            route_string = f"! {route_string}"
        return route_string

    def _get_route_string_from_jobtype(self):
        """
        Generate ORCA route string based on job type and settings.

        Returns:
            str: Generated ORCA route string

        Raises:
            ValueError: If invalid combination of settings is specified
        """
        route_string = ""
        if not route_string.startswith("!"):
            route_string += "! "

        # route string depends on job type
        # determine if route string requires 'opt' keyword
        if self.job_type in ("opt", "modred", "scan"):
            route_string += "Opt"
        elif self.job_type == "ts":
            route_string += (
                "OptTS"  # Orca keyword for transition state optimization
            )
        elif self.job_type == "irc":
            route_string += "IRC"
        elif self.job_type == "sp":
            route_string += ""

        # add frequency calculation
        # not okay if both freq and numfreq are True
        if self.freq and self.numfreq:
            raise ValueError("Cannot specify both freq and numfreq!")

        if self.freq:
            route_string += " Freq"
        elif self.numfreq:
            route_string += " NumFreq"  # requires numerical frequency,
            # e.g., in SMD model where analytic Hessian is not available

        # write level of theory
        level_of_theory = self._get_level_of_theory()
        route_string += f" {level_of_theory}"

        # write grid information
        if self.defgrid is not None:
            route_string += (
                f" {self.defgrid}"  # default is 'defgrid2', if not specified
            )

        # write convergence criteria in simple input/route
        if self.scf_tol is not None:
            if not self.scf_tol.lower().endswith("scf"):
                self.scf_tol += "SCF"
            route_string += f" {self.scf_tol}"

        # write convergence algorithm if not default
        if self.scf_algorithm is not None:
            route_string += f" {self.scf_algorithm}"

        # write solvent if solvation is turned on
        if self.solvent_model is not None and self.solvent_id is not None:
            route_string += f" {self.solvent_model}({self.solvent_id})"
        elif self.solvent_model is not None and self.solvent_id is None:
            raise ValueError(
                "Warning: Solvent model is specified but solvent identity "
                "is missing!"
            )
        elif self.solvent_model is None and self.solvent_id is not None:
            logger.warning(
                "Warning: Solvent identity is specified but solvent model "
                "is missing!\nDefaulting to CPCM model."
            )
            route_string += f" CPCM({self.solvent_id})"
        else:
            pass

        return route_string

    def _get_level_of_theory(self):
        """
        Get the level of theory string.

        Returns:
            str: Level of theory specification

        Raises:
            ValueError: If invalid method combination or missing parameters
        """
        level_of_theory = ""

        if self.ab_initio is not None and self.functional is not None:
            raise ValueError(
                "Warning: both ab initio and DFT are specified!\n"
                "Please specify only one method!"
            )

        if self.ab_initio is None and self.functional is None:
            raise ValueError(
                "Warning: neither ab initio nor DFT is specified!\n"
                "Please specify one method!"
            )

        if self.ab_initio is not None:
            level_of_theory += f"{self.ab_initio}"
        elif self.functional is not None:
            level_of_theory += f"{self.functional}"

        if self.basis is not None:
            level_of_theory += f" {self.basis}"
        elif self.basis is None:
            raise ValueError("Warning: basis is missing!")

        if self.aux_basis is not None:
            level_of_theory += f" {self.aux_basis}"

        if self.extrapolation_basis is not None:
            level_of_theory += f" {self.extrapolation_basis}"
        return level_of_theory

    def _write_geometry(self, f, atoms):
        """
        Write molecular geometry to input file.

        Args:
            f: File object to write to
            atoms: Atoms object containing molecular geometry

        Raises:
            AssertionError: If charge, multiplicity, or geometry is missing
        """
        # check that both charge and multiplicity are specified
        assert self.charge is not None, "No charge found!"
        assert self.multiplicity is not None, "No multiplicity found!"
        f.write(f"* xyz {self.charge} {self.multiplicity}\n")

        # check that a molecular geometry is given
        assert atoms is not None, "No molecular geometry found!"
        logger.info(f"Molecule given is: {atoms}")

        coordinates = ""
        for _i, (s, (x, y, z)) in enumerate(
            zip(atoms.symbols, atoms.positions, strict=False)
        ):
            string = f"{s:5} {float(x):15.10f} {float(y):15.10f} {float(z):15.10f}\n"
            coordinates += string
        f.write(coordinates)
        f.write("*\n")

    def _check_solvent(self, solvent_model):
        """
        Validate solvent model specification.

        Args:
            solvent_model: Solvent model name to validate

        Raises:
            ValueError: If solvent model is not supported
        """
        if solvent_model.lower() not in ORCA_ALL_SOLVENT_MODELS:
            raise ValueError(
                f"The specified solvent model {solvent_model} is not in \n"
                f"the available solvent models: {ORCA_ALL_SOLVENT_MODELS}"
            )


class ORCATSJobSettings(ORCAJobSettings):
    """
    Settings for ORCA transition state calculations.

    This class extends ORCAJobSettings with specialized options for
    transition state searches and optimizations.

    Attributes:
        inhess (bool): Read initial Hessian if True.
        inhess_filename (str | None): Path to initial Hessian file (used when inhess=True).
        hybrid_hess (bool): Use hybrid Hessian scheme.
        hybrid_hess_atoms (list[int] | None): 1‑based atom indices for hybrid Hessian region.
        numhess (bool): Use numerical Hessian.
        recalc_hess (int): Frequency (in cycles) to recalculate Hessian.
        trust_radius (float | None): Trust radius for optimization.
        tssearch_type (str): TS search method ('optts' or 'scants').
        scants_modred (list | dict | None): Modredundant coordinates for ScanTS.
        full_scan (bool): If True, do not abort ScanTS after highest point.
    """

    def __init__(
        self,
        inhess=False,
        inhess_filename=None,
        hybrid_hess=False,
        hybrid_hess_atoms=None,
        numhess=False,
        recalc_hess=5,
        trust_radius=None,
        tssearch_type="optts",
        scants_modred=None,
        full_scan=False,
        **kwargs,
    ):
        """
        Initialize ORCA transition state job settings.

        Args:
            inhess: Whether to read initial Hessian
            inhess_filename: Filename for initial Hessian
            hybrid_hess: Whether to use hybrid Hessian
            hybrid_hess_atoms: Atoms for hybrid Hessian (1-indexed)
            numhess: Whether to use numerical Hessian
            recalc_hess: Frequency for Hessian recalculation
            trust_radius: Trust radius for optimization
            tssearch_type: Type of TS search ('optts' or 'scants')
            scants_modred: Modified coordinates for ScanTS
            full_scan: Whether to do full scan or abort after highest point
            **kwargs: Additional keyword arguments
        """
        super().__init__(**kwargs)
        self.inhess = inhess
        self.inhess_filename = inhess_filename
        self.hybrid_hess = hybrid_hess
        self.hybrid_hess_atoms = (
            hybrid_hess_atoms  # supplied a list; 1-indexed as per user
        )
        self.numhess = numhess
        self.recalc_hess = recalc_hess
        self.trust_radius = trust_radius
        self.tssearch_type = (
            tssearch_type  # methods for TS search: OptTS, ScanTS
        )
        self.scants_modred = (
            scants_modred  # modred for scanTS (as in a scan job)
        )
        self.full_scan = full_scan  # full scan or not;  do or not abort scan after highest point is reached

    @property
    def route_string(self):
        """
        Get ORCA route string for transition state job.

        Overrides parent property to handle TS-specific keywords.

        Returns:
            str: ORCA route string for TS calculation
        """
        self.job_type = "ts"
        route_string = self._get_route_string_from_jobtype()
        if self.tssearch_type.lower() == "scants":
            route_string = route_string.replace("OptTS", "ScanTS")
        return route_string


class ORCAIRCJobSettings(ORCAJobSettings):
    """
    Settings for ORCA intrinsic reaction coordinate calculations.

    This class extends ORCAJobSettings with specialized options for
    IRC path following calculations.

    Attributes:
        maxiter (int | None): Maximum number of IRC iterations.
        printlevel (int | None): Verbosity level for IRC output.
        direction (str | None): IRC direction ('both', 'forward', 'backward', 'down').
        inithess (str | None): Initial Hessian specification ('read', 'calc_anfreq', 'calc_numfreq').
        hess_filename (str | None): Hessian filename when inithess='read'.
        hessmode (int | None): Hessian mode index used for initial displacement.
        init_displ (str | None): Initial displacement type ('DE' or 'length').
        scale_init_displ (float | None): Step size for initial displacement.
        de_init_displ (float | None): Target energy difference for initial displacement (Eh or mEh as per ORCA).
        follow_coordtype (str | None): Coordinate type to follow (typically 'cartesian').
        scale_displ_sd (float | None): Scaling factor for the first SD step.
        adapt_scale_displ (bool | None): Adapt SD step scaling dynamically.
        sd_parabolicfit (bool | None): Use parabolic fit to optimize SD step length.
        interpolate_only (bool | None): Restrict parabolic fit to interpolation only.
        do_sd_corr (bool | None): Apply correction to the first SD step.
        scale_displ_sd_corr (float | None): Scaling factor for SD correction step.
        sd_corr_parabolicfit (bool | None): Use parabolic fit for the correction step.
        tolrmsg (float | None): RMS gradient tolerance (a.u.).
        tolmaxg (float | None): Max gradient element tolerance (a.u.).
        monitor_internals (bool | None): Print selected internal coordinates during IRC.
        internal_modred (list | dict | None): Internal coordinates (B/A/D/I) to monitor when monitor_internals=True.
    """

    def __init__(
        self,
        maxiter=None,
        printlevel=None,
        direction=None,
        inithess=None,
        hess_filename=None,
        hessmode=None,
        init_displ=None,
        scale_init_displ=None,
        de_init_displ=None,
        follow_coordtype=None,
        scale_displ_sd=None,
        adapt_scale_displ=None,
        sd_parabolicfit=None,
        interpolate_only=None,
        do_sd_corr=None,
        scale_displ_sd_corr=None,
        sd_corr_parabolicfit=None,
        tolrmsg=None,
        tolmaxg=None,
        monitor_internals=None,
        internal_modred=None,
        **kwargs,
    ):
        """
        Initialize ORCA IRC job settings.

        Args:
            maxiter: Maximum number of IRC iterations
            printlevel: Level of output detail
            direction: IRC direction ('both', 'forward', 'backward', 'down')
            inithess: Initial Hessian specification
            hess_filename: Filename for Hessian file
            hessmode: Hessian mode for initial displacement
            init_displ: Initial displacement type
            scale_init_displ: Scaling for initial displacement
            de_init_displ: Energy difference for initial displacement
            follow_coordtype: Coordinate type to follow
            scale_displ_sd: Scaling for steepest descent displacement
            adapt_scale_displ: Whether to adapt displacement scaling
            sd_parabolicfit: Whether to use parabolic fit for SD step
            interpolate_only: Whether to only allow interpolation
            do_sd_corr: Whether to apply SD correction
            scale_displ_sd_corr: Scaling for SD correction
            sd_corr_parabolicfit: Whether to use parabolic fit for correction
            tolrmsg: RMS gradient tolerance
            tolmaxg: Maximum gradient tolerance
            monitor_internals: Whether to monitor internal coordinates
            internal_modred: Internal coordinates to monitor
            **kwargs: Additional keyword arguments
        """
        super().__init__(**kwargs)
        self.maxiter = maxiter
        self.printlevel = printlevel
        self.direction = direction
        self.inithess = inithess
        self.hess_filename = hess_filename
        self.hessmode = hessmode
        self.init_displ = init_displ
        self.scale_init_displ = scale_init_displ
        self.de_init_displ = de_init_displ
        self.follow_coordtype = follow_coordtype
        self.scale_displ_sd = scale_displ_sd
        self.adapt_scale_displ = adapt_scale_displ
        self.sd_parabolicfit = sd_parabolicfit
        self.interpolate_only = interpolate_only
        self.do_sd_corr = do_sd_corr
        self.scale_displ_sd_corr = scale_displ_sd_corr
        self.sd_corr_parabolicfit = sd_corr_parabolicfit
        self.tolrmsg = tolrmsg
        self.tolmaxg = tolmaxg
        self.monitor_internals = monitor_internals
        self.internal_modred = internal_modred

    @property
    def route_string(self):
        """
        Get ORCA route string for IRC job.

        Overrides parent property, removes frequency calculation
        as it's not compatible with IRC.

        Returns:
            str: ORCA route string for IRC calculation
        """
        self.job_type = "irc"
        route_string = self._get_route_string_from_jobtype()
        if "freq" in route_string.lower():
            route_string = re.sub(
                r"freq", "", route_string, flags=re.IGNORECASE
            )
        return route_string

    def _write_irc_block(self, f):
        """Writes the IRC block options.

        IRC block input example below:
        ! IRC
        %irc
            MaxIter    20
            PrintLevel 1
            Direction  both # both - default
                            # forward
                            # backward
                            # down
        # Initial displacement
            InitHess   read # by default ORCA uses the Hessian from AnFreq or NumFreq, or computes a new one
                            # read    - reads the Hessian that is defined via Hess_Filename
                            # calc_anfreq  - computes the analytic Hessian
                            # calc_numfreq - computes the numeric Hessian
            Hess_Filename "h2o.hess"  # Hessian for initial displacement, must be used together with InitHess = read
            hessMode   0  # Hessian mode that is used for the initial displacement. Default 0
            Init_Displ DE      # DE (default) - energy difference
                               # length       - step size
            Scale_Init_Displ 0.1 # step size for initial displacement from TS. Default 0.1 a.u.
            DE_Init_Displ    2.0 # energy difference that is expected for initial displacement
                                 #  based on provided Hessian (Default: 2 mEh)
        # Steps
            Follow_CoordType cartesian # default and only option
            Scale_Displ_SD    0.15  # Scaling factor for scaling the 1st SD step
            Adapt_Scale_Displ true  # modify Scale_Displ_SD when the step size becomes smaller or larger
            SD_ParabolicFit   true  # Do a parabolic fit for finding an optimal SD step length
            Interpolate_only  true  # Only allow interpolation for parabolic fit, not extrapolation
            Do_SD_Corr        true  # Apply a correction to the 1st SD step
            Scale_Displ_SD_Corr  0.333 # Scaling factor for scaling the correction step to the SD step.
                                       # It is multiplied by the length of the final 1st SD step
            SD_Corr_ParabolicFit true  # Do a parabolic fit for finding an optimal correction
                                       # step length
        # Convergence thresholds - similar to LooseOpt
            TolRMSG   5.e-4      # RMS gradient (a.u.)
            TolMaxG   2.e-3      # Max. element of gradient (a.u.)
        # Output options
            Monitor_Internals   # Up to three internal coordinates can be defined
                {B 0 1}         # for which the values are printed during the IRC run.
                {B 1 5}         # Possible are (B)onds, (A)ngles, (D)ihedrals and (I)mpropers
            end
        end.
        """
        irc_settings_keys = ORCAIRCJobSettings().__dict__.keys()
        parent_settings_keys = ORCAJobSettings().__dict__.keys()
        irc_specific_keys = set(irc_settings_keys) - set(parent_settings_keys)

        if not any(
            getattr(self, key) is not None for key in irc_specific_keys
        ):
            return

        # write irc block if any option value is not None:
        f.write("%irc\n")
        for key in irc_specific_keys:
            value = getattr(self, key)
            if value is None:
                continue  # ignore the rest of the code and go to next in the for loop
            # only write into IRC input if the value is not None
            if key == "internal_modred":
                pass  # internal_modred is not an option in ORCA IRC file
            elif key == "inithess":
                f.write(f"  {key} {value}\n")
                if value.lower() == "read":  # if initial hessian is to be read
                    assert (
                        self.hess_filename is not None
                    ), "No Hessian file is given!"
                    assert os.path.exists(
                        self.hess_filename
                    ), f"Hessian file {self.hess_filename} is not found!"
                    f.write(
                        f'  Hess_Filename "{self.hess_filename}"  # Hessian file\n'
                    )
            elif (
                key == "hess_filename"
            ):  # already used/written, if initial hessian is to be read
                pass
            elif key == "monitor_internals":
                if str(value).lower() == "true":
                    f.write(f"  {key}\n")
                    assert (
                        self.internal_modred is not None
                    ), 'No internal modred is specified for IRC job "monitor_intervals" option!'
                    prepend_string_list = (
                        get_prepend_string_list_from_modred_free_format(
                            self.internal_modred, program="orca"
                        )
                    )
                    for prepend_string in prepend_string_list:
                        f.write(f"  {{ {prepend_string} }}\n")
                    f.write("  end\n")
                else:  # monitor_internals has other value (false), then don't write it in input
                    pass
            else:  # all other keys with given values
                f.write(f"  {key} {value}\n")
        f.write("end\n")
