from chemsmart.utils.periodictable import PeriodicTable

p = PeriodicTable()


class TestPeriodicTable:
    def test_get_elements(self):
        pass
