
# Copyright (c) 2025 ChipIQ. All rights reserved.

import sys

from dotenv import load_dotenv
load_dotenv()

from chipiq.utils import is_dev_mode
def _custom_excepthook(exc_type, exc_value, exc_traceback):
    """Custom exception hook that suppresses stack trace."""
    print(f"{exc_type.__name__}: {exc_value}", file=sys.stderr)
    
    # Set custom exception hook to suppress stack traces in production mode
    if not is_dev_mode():
        sys.excepthook = _custom_excepthook

from importlib.metadata import version, PackageNotFoundError
try:
    __version__ = version("chipiq")
except PackageNotFoundError:
    __version__ = "-.-.-"

from chipiq.run_chipiq_exe import run_chipiq_exe
from chipiq.__main__ import chipiq_main as chipiq

__all__ = [
    "__version__", 
    "chipiq"
]
