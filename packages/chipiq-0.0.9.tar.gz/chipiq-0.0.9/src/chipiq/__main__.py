
# Copyright (c) 2025 ChipIQ. All rights reserved.

import sys

from chipiq.utils import parse_argv, is_dev_mode
from chipiq import run_chipiq_exe

def chipiq_main(*args, **kwargs) -> str:  
    """
    Platform-independent entry point for 'chipiq'.
    Runs the ChipIQ executable based on the platform.
    Can be called as a Python function or through a shell CLI command.
    This is the main function for MCP-servers to call.
    """
    try:
        # Parse CLI arguments if needed
        if not args and not kwargs:
            _, args, kwargs = parse_argv(sys.argv)

        # Invoke the chipiq executable for Mac, Linux or Windows
        return run_chipiq_exe(*args, **kwargs)

    except BrokenPipeError:
        # Handle broken pipe gracefully (e.g., when piping to head/tail)
        # Occurs when downstream process closes pipe before we finish writing
        sys.stderr.close()  # Prevent additional BrokenPipeError on stderr
        return ""

    except Exception as e:
        if is_dev_mode():
            raise
        return f"ChipIQ: Runtime Exception: {e}"


if __name__ == "__main__":
    """Entry point for 'chipiq' shell CLI command"""
    result = chipiq_main()
    print(result)
