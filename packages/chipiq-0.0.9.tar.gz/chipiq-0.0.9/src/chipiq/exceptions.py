# Copyright (c) 2025 ChipIQ. All rights reserved.

"""Custom ChipIQ exceptions."""

class ChipIQError(Exception):
    """Base exception for ChipIQ errors."""
    pass

class VCDError(ChipIQError):
    """VCD file parsing error."""
    pass
