
# simiq: User Manual

## Overview

Function `simiq()` analyzes VCD (Value Change Dump) waveform files from digital simulations.

- Show comprehensive reports with modules, signals, value changes, and more
- Inspect design hierarchies and module structures
- List signal properties including width, type, and scope
- Display file metadata and statistics
- Report signal value changes over time
- Use wildcard patterns for signal filtering (`*`, `**`)
- Select timestamp ranges and event limits
- Group results by time or signal name

## Function Signature

```python
def simiq(
    report: str = "",       # Report type (docs, modules, signals, info, vcd, license)
    file: str = "",         # File-path or URI to the VCD file
    first: int = -1,        # First timestamp for report (default: from start)
    include: list = [],     # By default match names at top-level (root) only
    exclude: list = [],     # Do not exclude anything
    n: int = 10,            # Max number of timestamps to report on
    group_by: str = "time"  # View signal value changes by "time" or by "name"
) -> str
""" 
Analyze a simulation waveforms (VCD "dump") file. 
Use simiq() or simiq(report="docs") for detailed usage information. 
Returns a comprehensive, formatted report.
"""
```

## Parameters

### `report` (str)
Type of report to generate. Available options:

- `"docs"` - This help documentation
- `"modules"` - List all module hierarchies in the design
- `"signals"` - List all signals with their properties
- `"info"` - Display file metadata and statistics
- `"vcd"` - Parse and display signal value changes
- `"license"` - Display license properties and status

**Default:** `"docs"` when no file provided, `"vcd"` when file is provided

### `file` (str)
File path or URI for the VCD waveform file to analyze.

- **Example:** `"path/to/waveform.vcd"`
- **Example:** `https://www.example.com/vcd/waveform.vcd`

### `first` (int)
Starting timestamp for reporting signal changes (used with `report="vcd"`).

**Default:** `-1` - start from first available timestamp in file.

### `include` (list)
List of signal name patterns to filter which signals to include.
Pattern matching uses `*` and `**` wildcards:

- `*` matches any characters within a segment (does not cross hierarchy dots)
- `**` matches zero or more complete hierarchy segments
- Patterns WITHOUT leading `.` match anywhere in hierarchy (shorthand for prepending `**`)
- Patterns WITH leading `.` match at root level only

**Pattern Examples (Shorthand):**
| Pattern | Description | Matches |
|---------|-------------|---------|
| `data` | Any leaf named "data" (signal or module) | `.data`, `.dut.data`, `.cpu.alu.data` |
| `data*` | Any leaf name starting with "data" | `.data_in`, `.dut.data_valid` |
| `data**` | Names starting with "data" with descendants | `.data.clk`, `.tb.data_in.reset` |
| `.data` | Names equal to "data" at root only | `.data` |
| `.data*` | Names starting with "data" at root only | `.data`, `.data_in` |
| `*data*` | Leaf names containing "data" | `.raw_data`, `.dut.input_data` |
| `**data**` | Any names containing "data" anywhere | `.raw_data`, `.dut.input_data` |
| `data.*` | "data" with direct children anywhere | `.data.clk`, `.tb.data.reset` |
| `data.**` | "data" with descendants anywhere | `.data.clk`, `.data.result.out`, `.tb.data.reset` |

**By Level:**
| Pattern | Description | Matches |
|---------|-------------|---------|
| `.*` | Any top-level leaf name (default) | `.clk`, `.reset` |
| `.*.*.*` | Exactly 3 levels deep from root | `.cpu.alu.add`, `.cpu.alu.mult` |
| `**` | Match anything at all levels | |

**Explicit Form:**
| Pattern | Description | Matches |
|---------|-------------|---------|
| `**.data` | Explicit form for: `data` | `.data`, `.dut.data`, `.cpu.alu.data` |
| `**.data*` | Explicit form for: `data*` | `.data`, `.data_in`, `.dut.data_valid` |
| `**.data**` | Explicit form for: `data**` | `.data.clk`, `.tb.data_in.reset` |
| `**.data.*` | Explicit form for: `data.*` | `.data.clk`, `.tb.data.reset` |
| `**.data.**` | Explicit form for: `data.**` | `.data.clk`, `.data.result.out`, `.tb.data.reset` |

**Default:** `include = [".*"]` - match anything at the top-level (root)

**Note:** Pattern matching is case-sensitive

### `exclude` (list)
List of signal name patterns to exclude. Signals matching these patterns will be
filtered out even if they match `include`.
Pattern matching follows the same rules as `include`.

**Examples:**
- `**clk**` - Exclude any name containing "clk" anywhere in the hierarchy
- `**.debug.**` - Exclude "debug" module with descendants at any level
- `["**rst**", "**clk**"]` - Exclude anything containing "rst" or "clk" anywhere

**Default:** `exclude = []` - do not exclude anything

**Note:** `exclude` takes precedence over `include`

### `n` (int)
Maximum number of timestamps to report on (used with `report="vcd"`).

**Default:** `n = 10`

### `group_by` (str)
View signal value changes by time or by name (used with `report="vcd"`).

- `"time"` - Group by timestamp, showing all signal changes at each time (default)
- `"name"` - Group by signal name, showing all timestamp changes for each signal

**Default:** `group_by = "time"`

## Usage Examples

### Example 1: View this user manual
```python
from exe.simiq import simiq

report = simiq(report="docs")
print(report)
```

### Example 2: List all modules
```python
report = simiq(
    report="modules",
    file="dump.vcd",
    include=["**"]  # Match all signals at all levels
)
```

### Example 3: Find signals containing "data" anywhere
```python
report = simiq(
    report="signals",
    file="dump.vcd",
    include=["*data*"]  # Anything with "data" anywhere in hierarchy
)
```

### Example 4: List a module and all its descendant signals
```python
report = simiq(
    report="signals",
    file="dump.vcd",
    include=["**.cpu.**"]  # cpu and all descendants anywhere
)
```

### Example 5: Find leaf named "data" anywhere in hierarchy
```python
report = simiq(
    report="signals",
    file="dump.vcd",
    include=["data"]  # Leaf "data" at any level
)
```

### Example 6: Exclude specific signals
```python
report = simiq(
    report="signals",
    file="dump.vcd",
    include=["**"],  # All signals
    exclude=["*clk*", "*rst*"]  # Exclude clock and reset
)
```

### Example 7: View file information
```python
report = simiq(
    report="info"
    file="dump.vcd",
)
```

### Example 8: Show signal value changes with exclusions
```python
report = simiq(
    report="vcd",
    file="dump.vcd",
    first=1000,  # Start from timestamp 1000
    include=["**"],  # All signals
    exclude=["*debug*"],  # Except for debug signals
    n=20  # Show maximum 20 signal changes
)
```

### Example 9: Group value changes by timestamp (default)
```python
report = simiq(
    report="vcd",
    file="dump.vcd",
    group_by="time",  # Group by timestamp
)
```

### Example 10: Group value changes by signal name
```python
report = simiq(
    report="vcd",
    file="dump.vcd",
    group_by="name",  # Group by signal name
)
```

### Example 11: View license information
```python
report = simiq(report="license")
```
