# Copyright (c) 2025 ChipIQ. All rights reserved.

import platform
import subprocess

from pathlib import Path

from chipiq.utils import build_argv


def run_chipiq_exe(*args, **kwargs) -> str:
    """ 
    Detect the runtime platform and run the appropriate ChipIQ executable.
    
    Args:
        *args: Positional arguments passed directly as strings
        **kwargs: Keyword arguments passed as "--key value" strings
    
    Returns:
        dict with keys 'stdout', 'stderr', and 'returncode'
    """
    # Find the executable path relative to this file based on platform
    # This file is at src/chipiq/call_chipiq_exe.py, executables are at 
    # dist_exe/chipiq_*.exe
    current_file = Path(__file__)
    project_root = current_file.parent.parent.parent
    
    # Determine which executable to use based on platform
    system = platform.system()
    if system == "Darwin":
        # macOS - check if ARM processor
        machine = platform.machine()
        if machine != "arm64":
            raise RuntimeError(
                f"ChipIQ: Executable requires Apple Silicon (ARM). "
                f"Your Mac is running on {machine} architecture.")
        exe_name = "chipiq_macos.exe"
    elif system == "Windows":
        exe_name = "chipiq_windows.exe"
    elif system == "Linux":
        exe_name = "chipiq_linux.exe"
    else:
        raise RuntimeError(f"ChipIQ: Unsupported platform: {system}")
    
    # List of possible executable paths to check
    search_paths = [
        project_root / "site-packages"/ "chipiq" / exe_name,
        project_root / "dist_exe" / exe_name,
    ]
    
    # Find the first existing executable
    exe_path = None
    for path in search_paths:
        if path.exists():
            exe_path = path
            break
    
    if exe_path is None:
        paths_str = "\n  ".join(str(p) for p in search_paths)
        raise RuntimeError(
            f"ChipIQ: Executable not found in any of these locations:\n"
            f"  {paths_str}")
    
    # Build the command line arguments
    cmd = build_argv(str(exe_path), *args, **kwargs)
    
    # Execute the command and capture output
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            check=False  # Don't raise exception on non-zero exit
        )

        out = result.stdout.strip() + "\n" if result.stdout else ""
        err = result.stderr.strip() + "\n" if result.stderr else ""
        code = result.returncode
        if code != 0 and not err:
            err = f"Process exited with error code {code}.\n"
            
        return out + err
        
    except Exception as e:
        cmd_str = " ".join(cmd)
        raise RuntimeError(f"ChipIQ: Error executing {cmd_str}: {str(e)}")
