# Copyright (c) 2025 ChipIQ. All rights reserved.

from os import PathLike


def _get_collection_type_str(collection, collection_name: str) -> str:
    """
    Helper function to determine the type string for a list or tuple.
    
    Args:
        collection: The list or tuple to analyze
        collection_name: "list" or "tuple"
    
    Returns:
        Type string like "list[int]", "tuple[str]", "list", "tuple", etc.
    """
    if len(collection) == 0:
        return f"{collection_name}[str]"  # Default for empty collections
    
    # Check if all elements are the same type
    first_item = collection[0]
    if isinstance(first_item, bool):
        element_type = "bool"
        check_func = lambda x: isinstance(x, bool)
    elif isinstance(first_item, int):
        element_type = "int"
        check_func = lambda x: isinstance(x, int) and not isinstance(x, bool)
    elif isinstance(first_item, float):
        element_type = "float"
        check_func = lambda x: isinstance(x, float)
    else:
        element_type = "str"
        check_func = lambda x: not isinstance(x, (bool, int, float))
    
    # Check if all elements match the first element's type
    if all(check_func(item) for item in collection):
        return f"{collection_name}[{element_type}]"
    else:
        return collection_name  # Mixed types


def _get_type_str(value) -> str:
    """
    Get the type string for a value to use in _type metadata.
    
    Args:
        value: The value to get the type string for
    
    Returns:
        Type string like "str", "int", "float", "bool", "list[str]", 
        "list[int]", "list[float]", "list[bool]", "tuple[str]", "tuple[int]", 
        "tuple[float]", "tuple[bool]", "list", "tuple", "None"
    """
    if value is None:
        return "None"
    elif isinstance(value, bool):
        return "bool"
    elif isinstance(value, int):
        return "int"
    elif isinstance(value, float):
        return "float"
    elif isinstance(value, tuple):
        return _get_collection_type_str(value, "tuple")
    elif isinstance(value, list):
        return _get_collection_type_str(value, "list")
    else:
        return "str"


def build_argv(
    _script_name: str | PathLike, 
    *args, 
    **kwargs
) -> list[str]:
    """
    Build a command-line argument list from a script name and arguments.
    
    Args:
        - _script_name: 
            - The path or name of the script/executable to run
        - *args: Positional arguments (strings, ints, floats, etc.)
            - Empty strings are preserved
            - None values become empty strings
            - Type information is preserved via _type metadata
        - **kwargs: Keyword arguments passed as "--key value" strings
            - Underscores in keys become hyphens (out_file -> --out-file)
            - True values add only the flag (no value)
            - False or None values are skipped
            - Empty string values are passed as --key ""
            - List values are space-separated: --key val1 val2 val3
            - Empty lists are skipped
            - Type information is preserved via _type metadata
            - Skipped values are tracked in _type metadata
    
    Returns:
        list[str]: Command-line argument list suitable for subprocess.run()
    
    The function always emits _type metadata that encodes type information 
    for all arguments, allowing parse_argv to reconstruct the correct types.
    
    Type metadata format: _type=key1:type1,key2:type2,0:type,1:type
    - Keys are kwarg names (with underscores, before hyphen conversion)
    - Positional args use numeric indices: 0, 1, 2, etc.
    - Types: str, bool, int, float, list[str], list[int], list[float], 
      list[bool], tuple[str], tuple[int], tuple[float], tuple[bool], list, 
      tuple, None
    - Mixed-type collections use generic "list" or "tuple" without brackets
    
    Known Limitations:
    - Mixed-type collections: When a list or tuple contains elements of 
      different types, it's marked as generic "list" or "tuple", and all 
      elements become strings on parse.
      Example: [1, "hello", 3.14] -> ["1", "hello", "3.14"]
    - None in collections: None values inside lists/tuples are converted to 
      the string "None" and cannot be distinguished from the actual string 
      "None" after serialization.
      Example: [None, "value"] -> ["None", "value"]
    - Homogeneous collections work perfectly: [1, 2, 3] -> [1, 2, 3] 
      (types preserved)
    
    Examples:
        >>> build_argv("python", "script.py", verbose=True, 
            output_file="file.txt")
        ['python', '_type=0:str,verbose:bool,output_file:str', 'script.py', 
        '--verbose', '--output-file', 'file.txt']
        
        >>> build_argv("cmd", files=["a.txt", "b.txt"], debug=False)
        ['cmd', '_type=files:list[str]', '--files', 'a.txt', 'b.txt']
        
        >>> build_argv("cmd", "arg1", "arg2", count=5)
        ['cmd', '_type=0:str,1:str,count:int', 'arg1', 'arg2', '--count', '5']
        
        >>> build_argv("cmd", files=["single.txt"])
        ['cmd', '_type=files:list[str]', '--files', 'single.txt']

    Note: using str.join() on the result is unsafe. Use the list directly with 
    subprocess.run(), or to safely create a shell command line string use:
        import shlex
        cmd_list = build_argv(...)
        cmd_str = ' '.join(shlex.quote(arg) for arg in cmd_list)
    """
    cmd = [str(_script_name)]
    
    # Build type metadata for all arguments
    type_entries = []
    
    # Add type info for positional arguments (including None)
    for idx, arg in enumerate(args):
        type_entries.append(f"{idx}:{_get_type_str(arg)}")
    
    # Add type info for keyword arguments (excluding False, but including 
    # None for metadata)
    # Note: None values won't appear in output, but we track them in metadata
    # Empty lists/tuples also get metadata although they're skipped in output
    for key, value in kwargs.items():
        if value is not False:
            type_entries.append(f"{key}:{_get_type_str(value)}")
    
    # Add _type metadata if we have any type entries
    if type_entries:
        cmd.append(f"_type={','.join(type_entries)}")
    
    # Add all positional arguments (including empty strings)
    # Convert None to empty string to preserve positions
    for arg in args:
        cmd.append("" if arg is None else str(arg))
    
    # Add all keyword arguments as --key value pairs
    # Convert underscores to hyphens in key names
    # List and tuple values are space-separated
    for key, value in kwargs.items():
        # Convert underscores to hyphens for CLI convention
        flag_key = key.replace("_", "-")
        
        if value is None or value is False:
            continue  # Skip None and False values
        elif value is True:
            cmd.append(f"--{flag_key}")  # Flag only, no value
        elif isinstance(value, (list, tuple)):
            if len(value) == 0:
                continue  # Skip empty lists/tuples
            
            # Space-separated: --key val1 val2 val3
            cmd.append(f"--{flag_key}")
            for item in value:
                cmd.append(str(item))
        else:
            # Regular value (including empty strings)
            cmd.append(f"--{flag_key}")
            cmd.append(str(value))
    
    return cmd
