# Copyright (c) 2025 ChipIQ. All rights reserved.

import os


def is_dev_mode() -> bool:
    """
    Check if the application is running in development mode.
    
    Returns True if in development mode, False if in production mode.
    """
    env_value = os.environ.get('CHIPIQ_ENV', '').strip().lower()
    
    return env_value in ('dev', 'development')
