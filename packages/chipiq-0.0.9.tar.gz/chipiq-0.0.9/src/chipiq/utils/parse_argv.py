# Copyright (c) 2025 ChipIQ. All rights reserved.

def _is_metadata_arg(arg: str) -> bool:
    """
    Check if an argument is a metadata argument (starts with _ and contains =).
    
    Args:
        arg: The argument string to check
    
    Returns:
        True if the argument is metadata, False otherwise
    """
    return arg.startswith('_') and '=' in arg


def _convert_value(value_str: str, type_name: str):
    """
    Convert a string value to the appropriate type based on type_name.
    
    Args:
        value_str: The string value to convert
        type_name: The type to convert to ("int", "float", "bool", "None", or "str")
    
    Returns:
        The converted value
    """
    if type_name == "None":
        return None
    elif type_name == "int":
        return int(value_str)
    elif type_name == "float":
        return float(value_str)
    elif type_name == "bool":
        return value_str.lower() in ("true", "1", "yes")
    else:
        return value_str


def parse_argv(
    argv: list[str]
) -> tuple[str, list[str | int | float | bool | None], dict[str, str | bool | int | float | list[str] | list[int] | list[float] | list[bool] | tuple | None]]:
    """
    Parse a command-line argument list back into script name, args, and kwargs.
    
    This is the inverse of build_argv(). It takes an argv list and extracts:
    - exe_path: The first element (script/executable path)
    - args: Positional arguments (non-flag arguments)
    - kwargs: Keyword arguments from --key value pairs
    
    The function reads the _type metadata to reconstruct the correct types for all arguments.
    Type metadata format: _type=key1:type1,key2:type2,0:type,1:type
    - Keys are kwarg names (with underscores)
    - Positional args use numeric indices: 0, 1, 2, etc.
    - Supported types: str, bool, int, float, list[str], list[int], list[float], list[bool],
      tuple[str], tuple[int], tuple[float], tuple[bool], list, tuple, None
    - Mixed-type collections use generic "list" or "tuple" without brackets
    
    Without _type metadata: When _type is not provided in argv, the function falls back to 
    basic string parsing with minimal type inference:
    - All positional arguments remain as strings (no numeric conversion)
    - Keyword argument values with a single value remain as strings (no numeric conversion)
    - Keyword arguments followed by multiple values automatically become a list of strings
    - Flags without values still become True (bool)
    - No None values or empty collections are reconstructed
    
    Without type metadata, the function infers types from the structure:
    - Flags without values become True (bool)
    - Multiple consecutive values become a list
    - Single values remain as strings
    
    Known Limitations:
        - Mixed-type collections: Generic "list" or "tuple" types mean all elements are
          parsed as strings, losing original type information.
          Example: ["1", "hello", "3.14"] all remain strings
        - None in collections: None values inside lists/tuples are serialized as the string
          "None" and cannot be reconstructed as actual None values.
          Example: ["None", "value"] - first element is the string "None", not None
        - Homogeneous collections preserve types correctly when typed (e.g., list[int])
    
    Notes:
        - Arguments starting with underscore (_) are considered metadata and excluded from output
        - Flags without values (e.g., --verbose) become True in kwargs
        - Multiple values after a flag become lists in kwargs
        - Hyphens in flag names are converted to underscores for Python compatibility
        - Type metadata (_type) is excluded from kwargs output
    
    Args:
        argv: Command-line argument list (e.g., from sys.argv)
    
    Returns:
        tuple containing:
            - exe_path (str): The script/executable path
            - args (list): Positional arguments with correct types
            - kwargs (dict): Keyword arguments with correct types
    
    Examples:
        >>> parse_argv(['python', '_type=0:str,verbose:bool,output_file:str', 'script.py', '--verbose', '--output-file', 'file.txt'])
        ('python', ['script.py'], {'verbose': True, 'output_file': 'file.txt'})
        
        >>> parse_argv(['cmd', '_type=files:list[str]', '--files', 'a.txt', 'b.txt'])
        ('cmd', [], {'files': ['a.txt', 'b.txt']})
        
        >>> parse_argv(['cmd', '_type=count:int', '--count', '42'])
        ('cmd', [], {'count': 42})
        
        >>> parse_argv(['cmd', '_type=files:list[str]', '--files', 'single.txt'])
        ('cmd', [], {'files': ['single.txt']})
        
        >>> parse_argv(['cmd', '_type=0:int,1:float', '42', '3.14'])
        ('cmd', [42, 3.14], {})
    """
    if not argv:
        raise RuntimeError("argv must contain at least a script name")
    
    exe_path = argv[0]
    args = []
    kwargs = {}
    type_map = {}  # Maps keys and indices to their types
    
    # First pass: extract type metadata
    i = 1
    while i < len(argv):
        arg = argv[i]
        if arg.startswith('_type='):
            # Parse type metadata: _type=key1:type1,key2:type2,0:type,1:type
            type_str = arg[6:]  # Remove '_type=' prefix
            if type_str:
                for entry in type_str.split(','):
                    if ':' in entry:
                        key, type_name = entry.split(':', 1)
                        type_map[key] = type_name
            i += 1
        elif _is_metadata_arg(arg):
            # Skip other metadata
            i += 1
        else:
            # Stop looking once we hit non-metadata
            break
    
    # Second pass: parse arguments
    i = 1
    positional_idx = 0
    while i < len(argv):
        arg = argv[i]
        
        # Skip metadata arguments
        if _is_metadata_arg(arg):
            i += 1
            continue
        
        # Check if this is a flag (starts with --)
        if arg.startswith('--'):
            flag_key = arg[2:]  # Remove '--' prefix
            # Convert hyphens to underscores for Python compatibility
            key = flag_key.replace('-', '_')
            
            # Check if there's a value following this flag
            if i + 1 < len(argv) and not argv[i + 1].startswith('--') and not _is_metadata_arg(argv[i + 1]):
                # Get the type for this key
                type_name = type_map.get(key, "str")
                
                # Count how many consecutive non-flag values follow this flag
                value_count = 0
                j = i + 1
                while j < len(argv) and not argv[j].startswith('--') and not _is_metadata_arg(argv[j]):
                    value_count += 1
                    j += 1
                
                # Determine if we should treat this as a list
                # If _type is provided and specifies list/tuple, always collect multiple values
                # If _type is NOT provided (defaults to "str") and there are multiple values, make it a list
                is_explicit_collection = type_name.startswith("list[") or type_name.startswith("tuple[") or type_name in ("list", "tuple")
                should_be_list = is_explicit_collection or (type_name == "str" and value_count > 1)
                
                if should_be_list:
                    # This is a list/tuple type - collect all following non-flag values
                    if type_name == "tuple" or type_name == "list":
                        inner_type = "str"  # Generic type defaults to string
                    elif type_name.startswith("tuple["):
                        inner_type = type_name[6:-1]  # Extract "str" from "tuple[str]"
                    elif type_name.startswith("list["):
                        inner_type = type_name[5:-1]  # Extract "str" from "list[str]"
                    else:  # type_name == "str" and multiple values
                        inner_type = "str"
                    
                    values = []
                    j = i + 1
                    while j < len(argv) and not argv[j].startswith('--') and not _is_metadata_arg(argv[j]):
                        # Convert the value to the inner type
                        values.append(_convert_value(argv[j], inner_type))
                        j += 1
                    # Convert to tuple if needed
                    kwargs[key] = tuple(values) if type_name.startswith("tuple") or type_name == "tuple" else values
                    i = j  # Move to next unprocessed item
                else:
                    # Single value - convert to the appropriate type
                    kwargs[key] = _convert_value(argv[i + 1], type_name)
                    i += 2  # Move past flag and its value
            else:
                # Flag without value (boolean flag)
                kwargs[key] = True
                i += 1
        else:
            # Positional argument
            # Get the type for this positional index
            type_name = type_map.get(str(positional_idx), "str")
            args.append(_convert_value(arg, type_name))
            positional_idx += 1
            i += 1
    
    # Reconstruct None and empty collection kwargs from metadata
    # These were skipped in output but should be restored for perfect round-trips
    for key, type_name in type_map.items():
        # Skip positional args (numeric keys)
        if key.isdigit():
            continue
        
        # If the key isn't in kwargs yet, check if it should be reconstructed
        if key not in kwargs:
            if type_name == "None":
                kwargs[key] = None
            elif type_name == "tuple" or type_name.startswith("tuple["):
                kwargs[key] = ()
            elif type_name == "list" or type_name.startswith("list["):
                kwargs[key] = []
    
    return exe_path, args, kwargs
