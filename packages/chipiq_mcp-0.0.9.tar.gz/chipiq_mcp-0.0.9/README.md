# chipiq-mcp

## Note: May need to use `uv cache clean` to ensure the latest `chipiq` package is picked up when starting the MCP-server.

## To configure the server using the PyPi chipiq-mcp package, use:
```
{
	"inputs": [],
	"servers": {
		"chipiq-mcp-server": {
			"type": "stdio",
			"command": "uvx",
			"args": [
				"chipiq-mcp==0.0.1"
			]
		}
	}
}
```

## To configure the server using a local development chipiq-mcp package, use:
```
{
	"inputs": [],
	"servers": {
		"chipiq-mcp-server": {
			"type": "stdio",
			"command": "uv",
			"args": [
				"tool",
				"run",
				"~/workspace/chipiq-mcp"
			]
		}
	}
}
```
