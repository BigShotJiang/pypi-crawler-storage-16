mod statistics;

pub use statistics::{CounterFunctionFactory, StatisticsFunctionExecutor};
