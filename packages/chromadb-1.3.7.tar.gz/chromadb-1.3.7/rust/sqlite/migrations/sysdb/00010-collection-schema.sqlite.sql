-- Stores collection schema as stringified json
ALTER TABLE collections ADD COLUMN schema_str TEXT;
