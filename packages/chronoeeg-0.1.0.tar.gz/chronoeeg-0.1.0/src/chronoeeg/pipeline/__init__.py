"""High-level analysis pipelines."""

from chronoeeg.pipeline.pipeline import EEGAnalysisPipeline

__all__ = ["EEGAnalysisPipeline"]
