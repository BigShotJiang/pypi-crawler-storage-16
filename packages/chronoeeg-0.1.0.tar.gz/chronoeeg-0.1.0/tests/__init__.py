"""
ChronoEEG Test Suite

This module contains unit and integration tests for the ChronoEEG library.
"""
