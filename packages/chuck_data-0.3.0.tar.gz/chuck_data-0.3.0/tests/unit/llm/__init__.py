"""Tests for LLM provider abstraction."""
