"""ChukTerm - A terminal library with CLI interface."""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    pass

__all__ = [
    "__version__",
    "__author__",
    "__email__",
]
