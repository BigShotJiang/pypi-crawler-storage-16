"""Core functionality for CI Guardian."""
