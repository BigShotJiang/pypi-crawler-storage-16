"""Git hooks templates and installers."""
