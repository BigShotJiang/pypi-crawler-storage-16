/* ANSI-C code produced by gperf version 3.1 */
/* Command-line: /usr/bin/gperf ../hash/atom.gperf  */
/* Computed positions: -k'1,3-8' */

#if !((' ' == 32) && ('!' == 33) && ('"' == 34) && ('#' == 35) \
      && ('%' == 37) && ('&' == 38) && ('\'' == 39) && ('(' == 40) \
      && (')' == 41) && ('*' == 42) && ('+' == 43) && (',' == 44) \
      && ('-' == 45) && ('.' == 46) && ('/' == 47) && ('0' == 48) \
      && ('1' == 49) && ('2' == 50) && ('3' == 51) && ('4' == 52) \
      && ('5' == 53) && ('6' == 54) && ('7' == 55) && ('8' == 56) \
      && ('9' == 57) && (':' == 58) && (';' == 59) && ('<' == 60) \
      && ('=' == 61) && ('>' == 62) && ('?' == 63) && ('A' == 65) \
      && ('B' == 66) && ('C' == 67) && ('D' == 68) && ('E' == 69) \
      && ('F' == 70) && ('G' == 71) && ('H' == 72) && ('I' == 73) \
      && ('J' == 74) && ('K' == 75) && ('L' == 76) && ('M' == 77) \
      && ('N' == 78) && ('O' == 79) && ('P' == 80) && ('Q' == 81) \
      && ('R' == 82) && ('S' == 83) && ('T' == 84) && ('U' == 85) \
      && ('V' == 86) && ('W' == 87) && ('X' == 88) && ('Y' == 89) \
      && ('Z' == 90) && ('[' == 91) && ('\\' == 92) && (']' == 93) \
      && ('^' == 94) && ('_' == 95) && ('a' == 97) && ('b' == 98) \
      && ('c' == 99) && ('d' == 100) && ('e' == 101) && ('f' == 102) \
      && ('g' == 103) && ('h' == 104) && ('i' == 105) && ('j' == 106) \
      && ('k' == 107) && ('l' == 108) && ('m' == 109) && ('n' == 110) \
      && ('o' == 111) && ('p' == 112) && ('q' == 113) && ('r' == 114) \
      && ('s' == 115) && ('t' == 116) && ('u' == 117) && ('v' == 118) \
      && ('w' == 119) && ('x' == 120) && ('y' == 121) && ('z' == 122) \
      && ('{' == 123) && ('|' == 124) && ('}' == 125) && ('~' == 126))
/* The character set is not based on ISO-646.  */
#error "gperf generated tables don't work with this execution character set. Please report a bug to <bug-gperf@gnu.org>."
#endif

#line 5 "../hash/atom.gperf"

#include "../codegen/lookup.h"
#line 8 "../hash/atom.gperf"
struct _LOOKUP;

#define ATOMTOTAL_KEYWORDS 269
#define ATOMMIN_WORD_LENGTH 3
#define ATOMMAX_WORD_LENGTH 8
#define ATOMMIN_HASH_VALUE 9
#define ATOMMAX_HASH_VALUE 1199
/* maximum key range = 1191, duplicates = 0 */

#ifdef __GNUC__
__inline
#else
#ifdef __cplusplus
inline
#endif
#endif
static unsigned int
_hash_atom (register const char *str, register size_t len)
{
  static unsigned short asso_values[] =
    {
      1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200,
      1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200,
      1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200,
      1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200,    5,
       180, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200,  505,
        85,  155,  335,  225,    0,   15,  115,   10, 1200, 1200,
      1200, 1200, 1200, 1200, 1200,  465,   20,    5,   25, 1200,
      1200,   15,    0, 1200, 1200, 1200, 1200, 1200,  225,   30,
        30,    0, 1200, 1200, 1200,  275, 1200, 1200, 1200, 1200,
      1200, 1200, 1200, 1200, 1200,   20, 1200, 1200, 1200, 1200,
      1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200,
      1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200,
      1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200,
      1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200,
      1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200,
      1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200,
      1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200,
      1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200,
      1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200,
      1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200,
      1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200,
      1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200,
      1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200,
      1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200,
      1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200,
      1200, 1200, 1200, 1200, 1200, 1200, 1200
    };
  register unsigned int hval = len;

  switch (hval)
    {
      default:
        hval += asso_values[(unsigned char)str[7]];
      /*FALLTHROUGH*/
      case 7:
        hval += asso_values[(unsigned char)str[6]+1];
      /*FALLTHROUGH*/
      case 6:
        hval += asso_values[(unsigned char)str[5]];
      /*FALLTHROUGH*/
      case 5:
        hval += asso_values[(unsigned char)str[4]];
      /*FALLTHROUGH*/
      case 4:
        hval += asso_values[(unsigned char)str[3]];
      /*FALLTHROUGH*/
      case 3:
        hval += asso_values[(unsigned char)str[2]];
      /*FALLTHROUGH*/
      case 2:
      case 1:
        hval += asso_values[(unsigned char)str[0]];
        break;
    }
  return hval;
}

struct _LOOKUP *
_lookup_atom (register const char *str, register size_t len)
{
  static struct _LOOKUP wordlist[] =
    {
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 83 "../hash/atom.gperf"
      {"C_H6", 72},
      {""}, {""}, {""}, {""},
#line 68 "../hash/atom.gperf"
      {"C_C6", 58},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 101 "../hash/atom.gperf"
      {"G_C6", 90},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 241 "../hash/atom.gperf"
      {"CCC_H6", 232},
      {""},
#line 49 "../hash/atom.gperf"
      {"C_P", 39},
      {""}, {""},
#line 228 "../hash/atom.gperf"
      {"CCC_C6", 219},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 85 "../hash/atom.gperf"
      {"G_P", 74},
#line 102 "../hash/atom.gperf"
      {"G_O6", 91},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 258 "../hash/atom.gperf"
      {"GNG_C6", 249},
      {""}, {""}, {""},
#line 208 "../hash/atom.gperf"
      {"CCC_P", 199},
      {""}, {""}, {""}, {""}, {""},
#line 205 "../hash/atom.gperf"
      {"CCC_PC", 196},
      {""}, {""}, {""}, {""},
#line 183 "../hash/atom.gperf"
      {"GTP_C6", 174},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 242 "../hash/atom.gperf"
      {"GNG_P", 233},
#line 259 "../hash/atom.gperf"
      {"GNG_O6", 250},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 62 "../hash/atom.gperf"
      {"C_C2", 52},
#line 76 "../hash/atom.gperf"
      {"C_H2'", 66},
#line 184 "../hash/atom.gperf"
      {"GTP_O6", 175},
      {""}, {""}, {""},
#line 58 "../hash/atom.gperf"
      {"C_C2'", 48},
      {""}, {""}, {""},
#line 104 "../hash/atom.gperf"
      {"G_C2", 93},
#line 115 "../hash/atom.gperf"
      {"G_H2'", 104},
      {""}, {""}, {""}, {""},
#line 94 "../hash/atom.gperf"
      {"G_C2'", 83},
#line 158 "../hash/atom.gperf"
      {"GTP_PG", 149},
      {""}, {""}, {""}, {""},
#line 163 "../hash/atom.gperf"
      {"GTP_PB", 154},
      {""}, {""},
#line 63 "../hash/atom.gperf"
      {"C_O2", 53},
      {""},
#line 222 "../hash/atom.gperf"
      {"CCC_C2", 213},
      {""}, {""}, {""},
#line 59 "../hash/atom.gperf"
      {"C_O2'", 49},
#line 77 "../hash/atom.gperf"
      {"C_HO2'", 67},
      {""}, {""},
#line 119 "../hash/atom.gperf"
      {"G_H8", 107},
      {""}, {""}, {""}, {""},
#line 98 "../hash/atom.gperf"
      {"G_C8", 87},
#line 95 "../hash/atom.gperf"
      {"G_O2'", 84},
#line 116 "../hash/atom.gperf"
      {"G_HO2'", 105},
      {""}, {""}, {""}, {""},
#line 261 "../hash/atom.gperf"
      {"GNG_C2", 252},
      {""}, {""}, {""}, {""},
#line 223 "../hash/atom.gperf"
      {"CCC_O2", 214},
      {""},
#line 230 "../hash/atom.gperf"
      {"CCC_HOP2", 221},
      {""},
#line 51 "../hash/atom.gperf"
      {"C_OP2", 41},
#line 70 "../hash/atom.gperf"
      {"C_HOP2", 60},
      {""}, {""}, {""}, {""},
#line 186 "../hash/atom.gperf"
      {"GTP_C2", 177},
      {""}, {""}, {""},
#line 87 "../hash/atom.gperf"
      {"G_OP2", 76},
#line 109 "../hash/atom.gperf"
      {"G_HOP2", 98},
      {""}, {""}, {""},
#line 74 "../hash/atom.gperf"
      {"C_H3'", 64},
#line 275 "../hash/atom.gperf"
      {"GNG_H8", 266},
      {""},
#line 265 "../hash/atom.gperf"
      {"GNG_HOP2", 256},
      {""},
#line 56 "../hash/atom.gperf"
      {"C_C3'", 46},
#line 255 "../hash/atom.gperf"
      {"GNG_C8", 246},
#line 207 "../hash/atom.gperf"
      {"CCC_O2C", 198},
#line 229 "../hash/atom.gperf"
      {"CCC_HOC2", 220},
      {""},
#line 113 "../hash/atom.gperf"
      {"G_H3'", 102},
      {""},
#line 209 "../hash/atom.gperf"
      {"CCC_OP1", 200},
      {""}, {""},
#line 92 "../hash/atom.gperf"
      {"G_C3'", 81},
#line 201 "../hash/atom.gperf"
      {"GTP_H8", 192},
#line 160 "../hash/atom.gperf"
      {"GTP_O2G", 151},
#line 190 "../hash/atom.gperf"
      {"GTP_HOG2", 181},
      {""},
#line 122 "../hash/atom.gperf"
      {"G_H22", 110},
#line 180 "../hash/atom.gperf"
      {"GTP_C8", 171},
#line 165 "../hash/atom.gperf"
      {"GTP_O2B", 156},
#line 192 "../hash/atom.gperf"
      {"GTP_HOB2", 183},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 57 "../hash/atom.gperf"
      {"C_O3'", 47},
#line 75 "../hash/atom.gperf"
      {"C_HO3'", 65},
#line 243 "../hash/atom.gperf"
      {"GNG_OP1", 234},
      {""}, {""}, {""}, {""},
#line 169 "../hash/atom.gperf"
      {"GTP_O2A", 160},
      {""}, {""},
#line 93 "../hash/atom.gperf"
      {"G_O3'", 82},
#line 114 "../hash/atom.gperf"
      {"G_HO3'", 103},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 231 "../hash/atom.gperf"
      {"CCC_HOP3", 222},
      {""},
#line 48 "../hash/atom.gperf"
      {"C_OP3", 38},
#line 69 "../hash/atom.gperf"
      {"C_HOP3", 59},
#line 277 "../hash/atom.gperf"
      {"GNG_H21", 268},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 82 "../hash/atom.gperf"
      {"C_H5", 71},
#line 84 "../hash/atom.gperf"
      {"G_OP3", 73},
#line 108 "../hash/atom.gperf"
      {"G_HOP3", 97},
      {""}, {""},
#line 67 "../hash/atom.gperf"
      {"C_C5", 57},
#line 71 "../hash/atom.gperf"
      {"C_H5'", 61},
      {""},
#line 203 "../hash/atom.gperf"
      {"GTP_H21", 194},
#line 266 "../hash/atom.gperf"
      {"GNG_HOP3", 257},
      {""},
#line 53 "../hash/atom.gperf"
      {"C_C5'", 43},
#line 72 "../hash/atom.gperf"
      {"C_H5''", 62},
      {""}, {""},
#line 100 "../hash/atom.gperf"
      {"G_C5", 89},
#line 111 "../hash/atom.gperf"
      {"G_H5'", 100},
      {""},
#line 210 "../hash/atom.gperf"
      {"CCC_OP2", 201},
      {""},
#line 97 "../hash/atom.gperf"
      {"G_N9", 86},
#line 89 "../hash/atom.gperf"
      {"G_C5'", 78},
#line 110 "../hash/atom.gperf"
      {"G_H5''", 99},
#line 161 "../hash/atom.gperf"
      {"GTP_O3G", 152},
#line 191 "../hash/atom.gperf"
      {"GTP_HOG3", 182},
#line 99 "../hash/atom.gperf"
      {"G_N7", 88},
      {""},
#line 240 "../hash/atom.gperf"
      {"CCC_H5", 231},
#line 162 "../hash/atom.gperf"
      {"GTP_O3B", 153},
#line 199 "../hash/atom.gperf"
      {"GTP_HO2'", 190},
      {""}, {""},
#line 227 "../hash/atom.gperf"
      {"CCC_C5", 218},
      {""}, {""}, {""},
#line 52 "../hash/atom.gperf"
      {"C_O5'", 42},
#line 78 "../hash/atom.gperf"
      {"C_HO5'", 145},
#line 244 "../hash/atom.gperf"
      {"GNG_OP2", 235},
      {""}, {""}, {""}, {""},
#line 166 "../hash/atom.gperf"
      {"GTP_O3A", 157},
      {""},
#line 157 "../hash/atom.gperf"
      {"U_H6", 144},
#line 88 "../hash/atom.gperf"
      {"G_O5'", 77},
#line 117 "../hash/atom.gperf"
      {"G_HO5'", 146},
      {""}, {""},
#line 143 "../hash/atom.gperf"
      {"U_C6", 131},
      {""},
#line 257 "../hash/atom.gperf"
      {"GNG_C5", 248},
      {""}, {""}, {""}, {""},
#line 254 "../hash/atom.gperf"
      {"GNG_N9", 245},
      {""}, {""}, {""}, {""},
#line 256 "../hash/atom.gperf"
      {"GNG_N7", 247},
#line 278 "../hash/atom.gperf"
      {"GNG_H22", 269},
      {""}, {""}, {""},
#line 182 "../hash/atom.gperf"
      {"GTP_C5", 173},
#line 236 "../hash/atom.gperf"
      {"CCC_H2'", 227},
      {""}, {""}, {""},
#line 179 "../hash/atom.gperf"
      {"GTP_N9", 170},
#line 218 "../hash/atom.gperf"
      {"CCC_C2'", 209},
#line 124 "../hash/atom.gperf"
      {"U_P", 112},
      {""}, {""},
#line 181 "../hash/atom.gperf"
      {"GTP_N7", 172},
#line 204 "../hash/atom.gperf"
      {"GTP_H22", 195},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 272 "../hash/atom.gperf"
      {"GNG_H2'", 263},
      {""}, {""}, {""}, {""},
#line 252 "../hash/atom.gperf"
      {"GNG_C2'", 243},
#line 273 "../hash/atom.gperf"
      {"GNG_H2''", 264},
#line 105 "../hash/atom.gperf"
      {"G_N2", 94},
      {""}, {""},
#line 219 "../hash/atom.gperf"
      {"CCC_O2'", 210},
      {""}, {""}, {""}, {""},
#line 198 "../hash/atom.gperf"
      {"GTP_H2'", 189},
      {""}, {""}, {""}, {""},
#line 176 "../hash/atom.gperf"
      {"GTP_C2'", 167},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 65 "../hash/atom.gperf"
      {"C_C4", 55},
#line 73 "../hash/atom.gperf"
      {"C_H4'", 63},
      {""}, {""}, {""}, {""},
#line 54 "../hash/atom.gperf"
      {"C_C4'", 44},
      {""}, {""}, {""},
#line 107 "../hash/atom.gperf"
      {"G_C4", 96},
#line 112 "../hash/atom.gperf"
      {"G_H4'", 101},
      {""}, {""}, {""}, {""},
#line 90 "../hash/atom.gperf"
      {"G_C4'", 79},
#line 262 "../hash/atom.gperf"
      {"GNG_N2", 253},
#line 177 "../hash/atom.gperf"
      {"GTP_O2'", 168},
      {""},
#line 137 "../hash/atom.gperf"
      {"U_C2", 125},
#line 151 "../hash/atom.gperf"
      {"U_H2'", 139},
      {""},
#line 235 "../hash/atom.gperf"
      {"CCC_H3'", 226},
      {""}, {""},
#line 133 "../hash/atom.gperf"
      {"U_C2'", 121},
#line 225 "../hash/atom.gperf"
      {"CCC_C4", 216},
#line 216 "../hash/atom.gperf"
      {"CCC_C3'", 207},
      {""}, {""},
#line 55 "../hash/atom.gperf"
      {"C_O4'", 45},
#line 187 "../hash/atom.gperf"
      {"GTP_N2", 178},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 64 "../hash/atom.gperf"
      {"C_N3", 54},
#line 91 "../hash/atom.gperf"
      {"G_O4'", 80},
      {""},
#line 270 "../hash/atom.gperf"
      {"GNG_H3'", 261},
      {""},
#line 138 "../hash/atom.gperf"
      {"U_O2", 126},
      {""},
#line 264 "../hash/atom.gperf"
      {"GNG_C4", 255},
#line 250 "../hash/atom.gperf"
      {"GNG_C3'", 241},
      {""},
#line 106 "../hash/atom.gperf"
      {"G_N3", 95},
#line 134 "../hash/atom.gperf"
      {"U_O2'", 122},
#line 152 "../hash/atom.gperf"
      {"U_HO2'", 140},
#line 217 "../hash/atom.gperf"
      {"CCC_O3'", 208},
      {""}, {""}, {""}, {""},
#line 196 "../hash/atom.gperf"
      {"GTP_H3'", 187},
      {""}, {""}, {""},
#line 189 "../hash/atom.gperf"
      {"GTP_C4", 180},
#line 174 "../hash/atom.gperf"
      {"GTP_C3'", 165},
      {""}, {""}, {""},
#line 224 "../hash/atom.gperf"
      {"CCC_N3", 215},
      {""}, {""}, {""}, {""}, {""},
#line 251 "../hash/atom.gperf"
      {"GNG_O3'", 242},
      {""}, {""},
#line 126 "../hash/atom.gperf"
      {"U_OP2", 114},
#line 145 "../hash/atom.gperf"
      {"U_HOP2", 133},
      {""},
#line 271 "../hash/atom.gperf"
      {"GNG_HO3'", 262},
      {""},
#line 81 "../hash/atom.gperf"
      {"C_H42", 70},
      {""},
#line 211 "../hash/atom.gperf"
      {"CCC_OP3", 202},
      {""},
#line 155 "../hash/atom.gperf"
      {"U_H3", 142},
      {""},
#line 263 "../hash/atom.gperf"
      {"GNG_N3", 254},
#line 175 "../hash/atom.gperf"
      {"GTP_O3'", 166},
      {""}, {""},
#line 149 "../hash/atom.gperf"
      {"U_H3'", 137},
      {""},
#line 232 "../hash/atom.gperf"
      {"CCC_H5'", 223},
#line 197 "../hash/atom.gperf"
      {"GTP_HO3'", 188},
      {""},
#line 131 "../hash/atom.gperf"
      {"U_C3'", 119},
      {""},
#line 213 "../hash/atom.gperf"
      {"CCC_C5'", 204},
#line 233 "../hash/atom.gperf"
      {"CCC_H5''", 224},
      {""}, {""},
#line 188 "../hash/atom.gperf"
      {"GTP_N3", 179},
#line 245 "../hash/atom.gperf"
      {"GNG_OP3", 236},
      {""}, {""}, {""}, {""},
#line 238 "../hash/atom.gperf"
      {"CCC_H41", 229},
      {""}, {""}, {""}, {""},
#line 267 "../hash/atom.gperf"
      {"GNG_H5'", 258},
      {""}, {""}, {""}, {""},
#line 247 "../hash/atom.gperf"
      {"GNG_C5'", 238},
#line 268 "../hash/atom.gperf"
      {"GNG_H5''", 259},
      {""},
#line 132 "../hash/atom.gperf"
      {"U_O3'", 120},
#line 150 "../hash/atom.gperf"
      {"U_HO3'", 138},
#line 212 "../hash/atom.gperf"
      {"CCC_O5'", 203},
      {""},
#line 27 "../hash/atom.gperf"
      {"A_C6", 18},
      {""}, {""},
#line 193 "../hash/atom.gperf"
      {"GTP_H5'", 184},
      {""}, {""}, {""}, {""},
#line 171 "../hash/atom.gperf"
      {"GTP_C5'", 162},
#line 194 "../hash/atom.gperf"
      {"GTP_H5''", 185},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 246 "../hash/atom.gperf"
      {"GNG_O5'", 237},
      {""}, {""},
#line 123 "../hash/atom.gperf"
      {"U_OP3", 111},
#line 144 "../hash/atom.gperf"
      {"U_HOP3", 132},
      {""},
#line 11 "../hash/atom.gperf"
      {"A_P", 2},
      {""}, {""}, {""}, {""}, {""},
#line 156 "../hash/atom.gperf"
      {"U_H5", 143},
      {""}, {""},
#line 170 "../hash/atom.gperf"
      {"GTP_O5'", 161},
      {""},
#line 142 "../hash/atom.gperf"
      {"U_C5", 130},
#line 146 "../hash/atom.gperf"
      {"U_H5'", 134},
      {""}, {""}, {""}, {""},
#line 128 "../hash/atom.gperf"
      {"U_C5'", 116},
#line 147 "../hash/atom.gperf"
      {"U_H5''", 135},
      {""}, {""}, {""},
#line 79 "../hash/atom.gperf"
      {"C_H1'", 68},
      {""}, {""}, {""},
#line 120 "../hash/atom.gperf"
      {"G_H1", 108},
#line 60 "../hash/atom.gperf"
      {"C_C1'", 50},
      {""},
#line 239 "../hash/atom.gperf"
      {"CCC_H42", 230},
      {""}, {""},
#line 118 "../hash/atom.gperf"
      {"G_H1'", 106},
      {""}, {""}, {""}, {""},
#line 96 "../hash/atom.gperf"
      {"G_C1'", 85},
      {""}, {""}, {""}, {""},
#line 127 "../hash/atom.gperf"
      {"U_O5'", 115},
#line 153 "../hash/atom.gperf"
      {"U_HO5'", 147},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 234 "../hash/atom.gperf"
      {"CCC_H4'", 225},
      {""},
#line 47 "../hash/atom.gperf"
      {"A_H2", 37},
#line 46 "../hash/atom.gperf"
      {"A_H62", 36},
      {""},
#line 214 "../hash/atom.gperf"
      {"CCC_C4'", 205},
      {""},
#line 30 "../hash/atom.gperf"
      {"A_C2", 21},
#line 40 "../hash/atom.gperf"
      {"A_H2'", 31},
#line 276 "../hash/atom.gperf"
      {"GNG_H1", 267},
      {""}, {""}, {""},
#line 20 "../hash/atom.gperf"
      {"A_C2'", 11},
#line 167 "../hash/atom.gperf"
      {"GTP_PA", 158},
      {""}, {""},
#line 66 "../hash/atom.gperf"
      {"C_N4", 56},
      {""}, {""},
#line 269 "../hash/atom.gperf"
      {"GNG_H4'", 260},
      {""}, {""},
#line 50 "../hash/atom.gperf"
      {"C_OP1", 40},
#line 202 "../hash/atom.gperf"
      {"GTP_H1", 193},
#line 248 "../hash/atom.gperf"
      {"GNG_C4'", 239},
      {""}, {""}, {""}, {""},
#line 215 "../hash/atom.gperf"
      {"CCC_O4'", 206},
      {""},
#line 44 "../hash/atom.gperf"
      {"A_H8", 34},
#line 86 "../hash/atom.gperf"
      {"G_OP1", 75},
      {""},
#line 195 "../hash/atom.gperf"
      {"GTP_H4'", 186},
      {""},
#line 24 "../hash/atom.gperf"
      {"A_C8", 15},
#line 21 "../hash/atom.gperf"
      {"A_O2'", 12},
#line 41 "../hash/atom.gperf"
      {"A_HO2'", 32},
#line 172 "../hash/atom.gperf"
      {"GTP_C4'", 163},
      {""}, {""}, {""},
#line 226 "../hash/atom.gperf"
      {"CCC_N4", 217},
#line 206 "../hash/atom.gperf"
      {"CCC_O1C", 197},
      {""}, {""}, {""}, {""},
#line 249 "../hash/atom.gperf"
      {"GNG_O4'", 240},
      {""}, {""}, {""}, {""},
#line 159 "../hash/atom.gperf"
      {"GTP_O1G", 150},
      {""}, {""},
#line 121 "../hash/atom.gperf"
      {"G_H21", 109},
      {""},
#line 164 "../hash/atom.gperf"
      {"GTP_O1B", 155},
      {""}, {""},
#line 13 "../hash/atom.gperf"
      {"A_OP2", 4},
#line 34 "../hash/atom.gperf"
      {"A_HOP2", 25},
#line 173 "../hash/atom.gperf"
      {"GTP_O4'", 164},
      {""},
#line 140 "../hash/atom.gperf"
      {"U_C4", 128},
#line 148 "../hash/atom.gperf"
      {"U_H4'", 136},
      {""}, {""}, {""}, {""},
#line 129 "../hash/atom.gperf"
      {"U_C4'", 117},
      {""},
#line 168 "../hash/atom.gperf"
      {"GTP_O1A", 159},
      {""}, {""},
#line 38 "../hash/atom.gperf"
      {"A_H3'", 29},
      {""}, {""}, {""}, {""},
#line 18 "../hash/atom.gperf"
      {"A_C3'", 9},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 141 "../hash/atom.gperf"
      {"U_O4", 129},
      {""}, {""}, {""}, {""}, {""},
#line 130 "../hash/atom.gperf"
      {"U_O4'", 118},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 139 "../hash/atom.gperf"
      {"U_N3", 127},
#line 19 "../hash/atom.gperf"
      {"A_O3'", 10},
#line 39 "../hash/atom.gperf"
      {"A_HO3'", 30},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 10 "../hash/atom.gperf"
      {"A_OP3", 1},
#line 33 "../hash/atom.gperf"
      {"A_HOP3", 24},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 28 "../hash/atom.gperf"
      {"A_N6", 19},
      {""}, {""}, {""}, {""},
#line 26 "../hash/atom.gperf"
      {"A_C5", 17},
#line 35 "../hash/atom.gperf"
      {"A_H5'", 26},
      {""}, {""}, {""},
#line 23 "../hash/atom.gperf"
      {"A_N9", 14},
#line 15 "../hash/atom.gperf"
      {"A_C5'", 6},
#line 36 "../hash/atom.gperf"
      {"A_H5''", 27},
      {""}, {""},
#line 25 "../hash/atom.gperf"
      {"A_N7", 16},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 237 "../hash/atom.gperf"
      {"CCC_H1'", 228},
      {""}, {""}, {""}, {""},
#line 220 "../hash/atom.gperf"
      {"CCC_C1'", 211},
      {""}, {""},
#line 14 "../hash/atom.gperf"
      {"A_O5'", 5},
#line 42 "../hash/atom.gperf"
      {"A_HO5'", 148},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 61 "../hash/atom.gperf"
      {"C_N1", 51},
      {""}, {""},
#line 274 "../hash/atom.gperf"
      {"GNG_H1'", 265},
      {""}, {""}, {""}, {""},
#line 253 "../hash/atom.gperf"
      {"GNG_C1'", 244},
      {""},
#line 103 "../hash/atom.gperf"
      {"G_N1", 92},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 200 "../hash/atom.gperf"
      {"GTP_H1'", 191},
      {""}, {""}, {""}, {""},
#line 178 "../hash/atom.gperf"
      {"GTP_C1'", 169},
      {""}, {""}, {""},
#line 221 "../hash/atom.gperf"
      {"CCC_N1", 212},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 260 "../hash/atom.gperf"
      {"GNG_N1", 251},
      {""}, {""}, {""},
#line 154 "../hash/atom.gperf"
      {"U_H1'", 141},
      {""}, {""}, {""}, {""},
#line 135 "../hash/atom.gperf"
      {"U_C1'", 123},
      {""}, {""}, {""}, {""}, {""},
#line 185 "../hash/atom.gperf"
      {"GTP_N1", 176},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 32 "../hash/atom.gperf"
      {"A_C4", 23},
#line 37 "../hash/atom.gperf"
      {"A_H4'", 28},
      {""}, {""}, {""}, {""},
#line 16 "../hash/atom.gperf"
      {"A_C4'", 7},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 17 "../hash/atom.gperf"
      {"A_O4'", 8},
      {""}, {""}, {""}, {""},
#line 125 "../hash/atom.gperf"
      {"U_OP1", 113},
      {""}, {""}, {""},
#line 31 "../hash/atom.gperf"
      {"A_N3", 22},
#line 80 "../hash/atom.gperf"
      {"C_H41", 69},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 45 "../hash/atom.gperf"
      {"A_H61", 35},
      {""}, {""}, {""}, {""},
#line 43 "../hash/atom.gperf"
      {"A_H1'", 33},
      {""}, {""}, {""}, {""},
#line 22 "../hash/atom.gperf"
      {"A_C1'", 13},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 136 "../hash/atom.gperf"
      {"U_N1", 124},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 12 "../hash/atom.gperf"
      {"A_OP1", 3},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 29 "../hash/atom.gperf"
      {"A_N1", 20}
    };

  if (len <= ATOMMAX_WORD_LENGTH && len >= ATOMMIN_WORD_LENGTH)
    {
      register unsigned int key = _hash_atom (str, len);

      if (key <= ATOMMAX_HASH_VALUE)
        {
          register const char *s = wordlist[key].name;

          if (*str == *s && !strcmp (str + 1, s + 1))
            return &wordlist[key];
        }
    }
  return 0;
}
