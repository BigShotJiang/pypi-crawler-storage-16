/* ANSI-C code produced by gperf version 3.1 */
/* Command-line: /usr/bin/gperf /home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf  */
/* Computed positions: -k'1-8' */

#if !((' ' == 32) && ('!' == 33) && ('"' == 34) && ('#' == 35) \
      && ('%' == 37) && ('&' == 38) && ('\'' == 39) && ('(' == 40) \
      && (')' == 41) && ('*' == 42) && ('+' == 43) && (',' == 44) \
      && ('-' == 45) && ('.' == 46) && ('/' == 47) && ('0' == 48) \
      && ('1' == 49) && ('2' == 50) && ('3' == 51) && ('4' == 52) \
      && ('5' == 53) && ('6' == 54) && ('7' == 55) && ('8' == 56) \
      && ('9' == 57) && (':' == 58) && (';' == 59) && ('<' == 60) \
      && ('=' == 61) && ('>' == 62) && ('?' == 63) && ('A' == 65) \
      && ('B' == 66) && ('C' == 67) && ('D' == 68) && ('E' == 69) \
      && ('F' == 70) && ('G' == 71) && ('H' == 72) && ('I' == 73) \
      && ('J' == 74) && ('K' == 75) && ('L' == 76) && ('M' == 77) \
      && ('N' == 78) && ('O' == 79) && ('P' == 80) && ('Q' == 81) \
      && ('R' == 82) && ('S' == 83) && ('T' == 84) && ('U' == 85) \
      && ('V' == 86) && ('W' == 87) && ('X' == 88) && ('Y' == 89) \
      && ('Z' == 90) && ('[' == 91) && ('\\' == 92) && (']' == 93) \
      && ('^' == 94) && ('_' == 95) && ('a' == 97) && ('b' == 98) \
      && ('c' == 99) && ('d' == 100) && ('e' == 101) && ('f' == 102) \
      && ('g' == 103) && ('h' == 104) && ('i' == 105) && ('j' == 106) \
      && ('k' == 107) && ('l' == 108) && ('m' == 109) && ('n' == 110) \
      && ('o' == 111) && ('p' == 112) && ('q' == 113) && ('r' == 114) \
      && ('s' == 115) && ('t' == 116) && ('u' == 117) && ('v' == 118) \
      && ('w' == 119) && ('x' == 120) && ('y' == 121) && ('z' == 122) \
      && ('{' == 123) && ('|' == 124) && ('}' == 125) && ('~' == 126))
/* The character set is not based on ISO-646.  */
#error "gperf generated tables don't work with this execution character set. Please report a bug to <bug-gperf@gnu.org>."
#endif

#line 5 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"

#include "../codegen/lookup.h"
#line 8 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
struct _LOOKUP;

#define ATOMTOTAL_KEYWORDS 1901
#define ATOMMIN_WORD_LENGTH 3
#define ATOMMAX_WORD_LENGTH 8
#define ATOMMIN_HASH_VALUE 373
#define ATOMMAX_HASH_VALUE 17428
/* maximum key range = 17056, duplicates = 0 */

#ifdef __GNUC__
__inline
#else
#ifdef __cplusplus
inline
#endif
#endif
static unsigned int
_hash_atom (register const char *str, register size_t len)
{
  static unsigned short asso_values[] =
    {
      17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429,
      17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429,
      17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429,
      17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429,  1200,
       2748, 17429, 17429, 17429, 17429, 17429, 17429, 17429,   930,    15,
          0,    30,  1695,  3233,  3891,  3973,  2798,   822,   459,  3463,
       1505,  2020,  1108,  1215,  4746,  1882,  3737,     0,   615,  3703,
        710,    20,     5,  1800,  1440,  1402,   805,  2438,    50,    10,
         30,   340,   100,   250,   570,   105,  3838,   460,  4636,  1855,
         30, 17429, 17429,     5, 17429,   435,     0, 17429,  4801, 17429,
        665, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429,
      17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429,
      17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429,
      17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429,
      17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429,
      17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429,
      17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429,
      17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429,
      17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429,
      17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429,
      17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429,
      17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429,
      17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429,
      17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429,
      17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429,
      17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429, 17429,
      17429, 17429, 17429, 17429, 17429, 17429
    };
  register unsigned int hval = len;

  switch (hval)
    {
      default:
        hval += asso_values[(unsigned char)str[7]+1];
      /*FALLTHROUGH*/
      case 7:
        hval += asso_values[(unsigned char)str[6]];
      /*FALLTHROUGH*/
      case 6:
        hval += asso_values[(unsigned char)str[5]+10];
      /*FALLTHROUGH*/
      case 5:
        hval += asso_values[(unsigned char)str[4]];
      /*FALLTHROUGH*/
      case 4:
        hval += asso_values[(unsigned char)str[3]];
      /*FALLTHROUGH*/
      case 3:
        hval += asso_values[(unsigned char)str[2]];
      /*FALLTHROUGH*/
      case 2:
        hval += asso_values[(unsigned char)str[1]+1];
      /*FALLTHROUGH*/
      case 1:
        hval += asso_values[(unsigned char)str[0]+3];
        break;
    }
  return hval;
}

struct _LOOKUP *
_lookup_atom (register const char *str, register size_t len)
{
  static struct _LOOKUP wordlist[] =
    {
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 316 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_P", 307},
      {""}, {""},
#line 336 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_HO2'", 327},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 318 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_OP2", 309},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 317 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_OP1", 308},
      {""}, {""}, {""}, {""}, {""},
#line 334 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_HO3'", 325},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 315 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_OP3", 306},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 926 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C2", 917},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 917 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C2'", 908},
      {""}, {""}, {""},
#line 941 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H1", 932},
#line 937 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H2'", 928},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 908 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_P", 899},
      {""},
#line 918 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C1'", 909},
      {""}, {""}, {""}, {""},
#line 939 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H1'", 930},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 915 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C3'", 906},
#line 931 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_HOP2", 922},
      {""}, {""},
#line 927 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_N2", 918},
#line 935 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H3'", 926},
      {""}, {""}, {""}, {""},
#line 916 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_O3'", 907},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 925 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_N1", 916},
      {""}, {""}, {""}, {""},
#line 1615 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ZN_ZN", 1606},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 930 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_HOP3", 921},
      {""}, {""},
#line 928 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_N3", 919},
      {""}, {""}, {""}, {""},
#line 271 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_P", 262},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 273 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_OP2", 264},
      {""}, {""},
#line 957 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C2", 948},
      {""}, {""}, {""}, {""}, {""},
#line 284 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_N9", 275},
      {""}, {""}, {""},
#line 958 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_O2", 949},
      {""},
#line 272 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_OP1", 263},
      {""}, {""}, {""},
#line 954 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C2'", 945},
      {""}, {""}, {""}, {""},
#line 972 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H2'", 963},
      {""}, {""}, {""}, {""}, {""},
#line 274 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_OP3", 265},
      {""},
#line 945 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_P", 936},
      {""},
#line 955 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C1'", 946},
      {""}, {""}, {""},
#line 975 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H3", 966},
#line 974 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H1'", 965},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 952 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C3'", 943},
#line 966 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_HOP2", 957},
      {""}, {""}, {""},
#line 970 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H3'", 961},
      {""}, {""},
#line 30 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C2", 21},
#line 357 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_P", 348},
#line 953 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_O3'", 944},
      {""}, {""},
#line 46 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H2", 37},
      {""}, {""}, {""}, {""}, {""},
#line 956 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_N1", 947},
      {""},
#line 359 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_OP2", 350},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 377 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_P", 368},
      {""},
#line 965 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_HOP3", 956},
      {""}, {""},
#line 959 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_N3", 950},
      {""},
#line 358 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_OP1", 349},
#line 11 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_P", 2},
      {""}, {""},
#line 41 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_HO2'", 32},
#line 379 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_OP2", 370},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 13 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_OP2", 4},
#line 391 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_N9", 382},
#line 360 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_OP3", 351},
      {""}, {""}, {""}, {""},
#line 378 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_OP1", 369},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 12 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_OP1", 3},
      {""}, {""}, {""}, {""}, {""},
#line 39 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_HO3'", 30},
#line 380 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_OP3", 371},
      {""},
#line 29 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_N1", 20},
      {""}, {""}, {""}, {""}, {""},
#line 10 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_OP3", 1},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 31 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_N3", 22},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 61 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_C2", 52},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 62 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_O2", 53},
#line 436 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_P", 427},
      {""}, {""}, {""}, {""},
#line 1216 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_C", 1207},
      {""}, {""}, {""}, {""},
#line 1224 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_H", 1215},
      {""},
#line 438 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_OP2", 429},
      {""}, {""},
#line 1217 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_O", 1208},
#line 1221 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_CE", 1212},
      {""},
#line 48 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_P", 39},
      {""}, {""},
#line 76 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_HO2'", 67},
#line 1233 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HE2", 1224},
      {""}, {""}, {""}, {""},
#line 437 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_OP1", 428},
      {""}, {""},
#line 50 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_OP2", 41},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 439 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_OP3", 430},
      {""}, {""},
#line 49 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_OP1", 40},
      {""}, {""}, {""}, {""}, {""},
#line 74 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_HO3'", 65},
#line 1234 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HE3", 1225},
      {""},
#line 60 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_N1", 51},
#line 1214 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_N", 1205},
#line 1220 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_CD", 1211},
      {""}, {""}, {""},
#line 47 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_OP3", 38},
      {""},
#line 1231 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HD2", 1222},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 63 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_N3", 54},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 255 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C2", 246},
      {""}, {""}, {""}, {""},
#line 270 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_H2", 261},
      {""}, {""},
#line 1232 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HD3", 1223},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 269 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_H1", 260},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 236 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_P", 227},
      {""}, {""},
#line 266 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_HO2'", 257},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 238 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_OP2", 229},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 237 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_OP1", 228},
      {""}, {""}, {""}, {""}, {""},
#line 264 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_HO3'", 255},
      {""}, {""},
#line 254 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_N1", 245},
      {""}, {""}, {""}, {""}, {""},
#line 235 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_OP3", 226},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 256 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_N3", 247},
      {""}, {""}, {""}, {""}, {""},
#line 1396 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_C", 1387},
      {""}, {""}, {""}, {""},
#line 1411 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_H", 1402},
      {""}, {""}, {""}, {""},
#line 1397 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_O", 1388},
      {""},
#line 1404 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_CE2", 1395},
      {""}, {""}, {""}, {""},
#line 1420 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HE2", 1411},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1403 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_CE1", 1394},
      {""}, {""},
#line 1407 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_P", 1398},
      {""},
#line 1419 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HE1", 1410},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1394 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_N", 1385},
      {""},
#line 1402 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_CD2", 1393},
      {""}, {""},
#line 1379 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_C", 1370},
      {""},
#line 1418 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HD2", 1409},
      {""}, {""},
#line 1385 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_H", 1376},
      {""}, {""}, {""}, {""},
#line 1380 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_O", 1371},
      {""},
#line 1401 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_CD1", 1392},
      {""}, {""}, {""}, {""},
#line 1417 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HD1", 1408},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 296 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_CM2", 287},
      {""}, {""}, {""}, {""}, {""},
#line 312 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HM21", 303},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 295 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_CM1", 286},
      {""},
#line 794 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_P", 785},
#line 1377 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_N", 1368},
#line 1383 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_CD", 1374},
      {""},
#line 309 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HM11", 300},
      {""}, {""},
#line 1406 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_OH", 1397},
#line 1391 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_HD2", 1382},
      {""}, {""}, {""},
#line 796 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_OP2", 787},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 313 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HM22", 304},
      {""},
#line 807 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_N9", 798},
      {""}, {""}, {""}, {""}, {""},
#line 795 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_OP1", 786},
      {""}, {""}, {""},
#line 1524 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_C", 1515},
      {""}, {""},
#line 310 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HM12", 301},
      {""},
#line 1535 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_H", 1526},
      {""},
#line 1392 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_HD3", 1383},
      {""}, {""},
#line 1525 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_O", 1516},
#line 797 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_OP3", 788},
#line 1531 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_CE2", 1522},
      {""}, {""}, {""}, {""},
#line 1543 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_HE2", 1534},
      {""}, {""}, {""}, {""},
#line 350 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_CM2", 341},
      {""}, {""}, {""}, {""},
#line 1530 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_CE1", 1521},
#line 367 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_HM21", 358},
      {""}, {""}, {""},
#line 1542 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_HE1", 1533},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1219 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_CG", 1210},
#line 389 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_CM2", 380},
      {""}, {""},
#line 886 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_C2", 877},
      {""},
#line 1229 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HG2", 1220},
#line 410 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_HM21", 401},
      {""},
#line 1522 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_N", 1513},
      {""},
#line 1529 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_CD2", 1520},
      {""}, {""},
#line 887 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_O2", 878},
      {""},
#line 1541 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_HD2", 1532},
#line 368 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_HM22", 359},
      {""}, {""},
#line 883 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_C2'", 874},
      {""}, {""}, {""}, {""},
#line 900 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H2'", 891},
#line 1528 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_CD1", 1519},
      {""}, {""}, {""}, {""},
#line 1540 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_HD1", 1531},
      {""},
#line 874 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_P", 865},
      {""},
#line 884 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_C1'", 875},
#line 1230 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HG3", 1221},
#line 411 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_HM22", 402},
      {""}, {""},
#line 902 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H1'", 893},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 881 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_C3'", 872},
#line 894 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_HOP2", 885},
      {""}, {""}, {""},
#line 898 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H3'", 889},
      {""}, {""}, {""}, {""},
#line 882 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_O3'", 873},
      {""}, {""}, {""}, {""},
#line 1544 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_HH", 1535},
      {""}, {""}, {""},
#line 885 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_N1", 876},
#line 1533 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_OH", 1524},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 893 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_HOP3", 884},
      {""}, {""},
#line 888 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_N3", 879},
      {""},
#line 429 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_CM2", 420},
      {""}, {""}, {""}, {""}, {""},
#line 445 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_HM21", 436},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1497 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_C", 1488},
      {""}, {""}, {""}, {""},
#line 1510 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_H", 1501},
      {""}, {""}, {""}, {""},
#line 1498 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_O", 1489},
      {""},
#line 1504 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CE2", 1495},
#line 446 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_HM22", 437},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1516 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HE1", 1507},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1505 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CE3", 1496},
      {""}, {""}, {""}, {""},
#line 1517 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HE3", 1508},
      {""}, {""},
#line 1495 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_N", 1486},
      {""},
#line 1502 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CD2", 1493},
      {""}, {""}, {""},
#line 1400 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_CG", 1391},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1501 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CD1", 1492},
      {""}, {""},
#line 1482 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_C", 1473},
      {""},
#line 1515 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HD1", 1506},
      {""}, {""},
#line 1485 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_H", 1476},
      {""},
#line 1503 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_NE1", 1494},
      {""}, {""},
#line 1483 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_O", 1474},
      {""}, {""}, {""}, {""},
#line 1194 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_C", 1185},
      {""}, {""}, {""}, {""},
#line 1201 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_H", 1192},
      {""}, {""}, {""}, {""},
#line 1195 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_O", 1186},
      {""}, {""}, {""}, {""},
#line 1478 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_P", 1469},
      {""},
#line 1508 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CH2", 1499},
      {""}, {""}, {""}, {""},
#line 1520 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HH2", 1511},
      {""}, {""}, {""},
#line 1382 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_CG", 1373},
      {""}, {""}, {""}, {""}, {""},
#line 1389 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_HG2", 1380},
      {""}, {""},
#line 1473 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_N", 1464},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1822 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H9", 1813},
#line 1905 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H92", 1896},
#line 1192 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_N", 1183},
      {""},
#line 1199 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_CD2", 1190},
      {""}, {""}, {""}, {""}, {""},
#line 1210 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HD21", 1201},
      {""},
#line 995 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_C", 986},
      {""},
#line 1390 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_HG3", 1381},
      {""},
#line 1903 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H91", 1894},
#line 1005 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_H", 996},
      {""},
#line 1198 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_CD1", 1189},
      {""}, {""},
#line 996 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_O", 987},
      {""},
#line 919 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_N9", 910},
#line 1207 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HD11", 1198},
      {""}, {""},
#line 1014 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HE", 1005},
      {""},
#line 764 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C9", 755},
#line 1908 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H93", 1899},
      {""}, {""}, {""},
#line 793 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H9", 784},
      {""},
#line 782 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H9C1", 773},
      {""}, {""},
#line 1211 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HD22", 1202},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1208 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HD12", 1199},
      {""}, {""},
#line 1527 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_CG", 1518},
#line 776 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_P", 767},
      {""}, {""},
#line 993 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_N", 984},
#line 999 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_CD", 990},
      {""}, {""}, {""},
#line 783 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H9C2", 774},
      {""},
#line 1012 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HD2", 1003},
      {""}, {""}, {""},
#line 1000 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_NE", 991},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 759 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_N9", 750},
      {""},
#line 472 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_P", 463},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1236 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HZ2", 1227},
      {""}, {""}, {""}, {""},
#line 474 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_OP2", 465},
      {""}, {""}, {""}, {""},
#line 1013 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HD3", 1004},
      {""}, {""}, {""}, {""},
#line 1235 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HZ1", 1226},
      {""}, {""}, {""}, {""},
#line 473 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_OP1", 464},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1070 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_C", 1061},
      {""},
#line 1237 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HZ3", 1228},
#line 1017 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HH21", 1008},
      {""},
#line 1075 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_H", 1066},
      {""},
#line 475 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_OP3", 466},
      {""}, {""},
#line 1071 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_O", 1062},
      {""}, {""}, {""},
#line 139 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C2", 130},
      {""},
#line 1222 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_NZ", 1213},
      {""},
#line 1015 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HH11", 1006},
      {""},
#line 156 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H22", 147},
      {""}, {""}, {""}, {""},
#line 1612 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"K_K", 1603},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1018 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HH22", 1009},
#line 154 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H1", 145},
#line 155 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H21", 146},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 120 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_P", 111},
      {""}, {""},
#line 151 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_HO2'", 142},
#line 1003 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_NH2", 994},
#line 1016 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HH12", 1007},
      {""},
#line 1068 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_N", 1059},
      {""}, {""}, {""}, {""},
#line 122 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_OP2", 113},
      {""}, {""}, {""}, {""}, {""},
#line 23 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_N9", 14},
#line 1002 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_NH1", 993},
      {""},
#line 140 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_N2", 131},
      {""}, {""}, {""}, {""}, {""},
#line 121 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_OP1", 112},
      {""}, {""}, {""}, {""}, {""},
#line 149 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_HO3'", 140},
      {""}, {""},
#line 138 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_N1", 129},
      {""}, {""}, {""}, {""}, {""},
#line 119 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_OP3", 110},
      {""}, {""}, {""}, {""},
#line 1247 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_C", 1238},
#line 1500 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CG", 1491},
      {""}, {""},
#line 141 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_N3", 132},
#line 1250 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_H", 1241},
      {""}, {""}, {""}, {""},
#line 1248 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_O", 1239},
#line 1246 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_CE", 1237},
      {""}, {""}, {""}, {""},
#line 1218 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_CB", 1209},
#line 1259 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HE2", 1250},
#line 1257 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HE21", 1248},
      {""}, {""}, {""},
#line 1227 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HB2", 1218},
      {""}, {""},
#line 325 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_C2'", 316},
      {""}, {""}, {""}, {""},
#line 335 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_H2'", 326},
      {""},
#line 1258 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HE1", 1249},
      {""}, {""},
#line 326 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_O2'", 317},
      {""},
#line 1244 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_OE1", 1235},
      {""}, {""},
#line 327 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_C1'", 318},
#line 1405 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_CZ", 1396},
      {""}, {""}, {""},
#line 337 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_H1'", 328},
      {""},
#line 1260 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HE3", 1251},
      {""}, {""},
#line 1239 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_N", 1230},
#line 1243 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_CD", 1234},
#line 1228 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HB3", 1219},
      {""}, {""},
#line 323 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_C3'", 314},
      {""}, {""}, {""}, {""},
#line 333 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_H3'", 324},
      {""},
#line 1245 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_NE2", 1236},
      {""}, {""},
#line 324 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_O3'", 315},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1476 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_CG2", 1467},
      {""}, {""}, {""}, {""}, {""},
#line 1489 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_HG21", 1480},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1197 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_CG", 1188},
      {""}, {""}, {""}, {""},
#line 1206 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HG", 1197},
      {""}, {""}, {""}, {""}, {""},
#line 1477 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_OG1", 1468},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1490 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_HG22", 1481},
#line 294 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C4", 285},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1039 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_C", 1030},
      {""}, {""}, {""}, {""},
#line 1046 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_H", 1037},
      {""}, {""}, {""}, {""},
#line 1040 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_O", 1031},
#line 998 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_CG", 989},
      {""}, {""}, {""}, {""}, {""},
#line 1010 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HG2", 1001},
      {""}, {""},
#line 1022 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_C", 1013},
      {""}, {""}, {""}, {""},
#line 1029 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_H", 1020},
#line 248 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_N9", 239},
      {""}, {""}, {""},
#line 1023 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_O", 1014},
      {""},
#line 938 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H2''", 929},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1532 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_CZ", 1523},
      {""}, {""},
#line 342 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_C4", 333},
      {""},
#line 1399 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_CB", 1390},
#line 1011 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HG3", 1002},
      {""}, {""},
#line 1037 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_N", 1028},
      {""},
#line 1415 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HB2", 1406},
      {""}, {""}, {""}, {""},
#line 1051 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_HD2", 1042},
      {""}, {""}, {""}, {""},
#line 1044 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_OD2", 1035},
      {""},
#line 401 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C4", 392},
      {""}, {""}, {""}, {""}, {""},
#line 1020 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_N", 1011},
      {""}, {""}, {""}, {""},
#line 1057 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_C", 1048},
      {""},
#line 1043 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_OD1", 1034},
#line 1034 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_HD21", 1025},
      {""},
#line 1061 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_H", 1052},
#line 287 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C5", 278},
#line 1416 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HB3", 1407},
      {""}, {""},
#line 1058 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_O", 1049},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 346 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_N4", 337},
#line 1264 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_C", 1255},
      {""},
#line 1026 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_OD1", 1017},
      {""}, {""},
#line 1271 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_H", 1262},
#line 1381 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_CB", 1372},
      {""}, {""}, {""},
#line 1265 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_O", 1256},
#line 1269 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_CE", 1260},
#line 1387 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_HB2", 1378},
#line 1035 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_HD22", 1026},
      {""}, {""}, {""},
#line 1279 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_HE2", 1270},
#line 1710 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C02", 1701},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1080 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_HG", 1071},
#line 1027 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_ND2", 1018},
      {""}, {""},
#line 1053 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_N", 1044},
      {""},
#line 1278 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_HE1", 1269},
#line 1708 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C01", 1699},
      {""}, {""},
#line 1067 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_HD", 1058},
#line 973 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H2''", 964},
      {""}, {""}, {""},
#line 1060 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_OD", 1051},
#line 1388 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_HB3", 1379},
#line 1709 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O01", 1700},
      {""},
#line 85 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_P", 76},
      {""},
#line 1280 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_HE3", 1271},
#line 1712 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C03", 1703},
      {""},
#line 1262 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_N", 1253},
      {""}, {""}, {""},
#line 421 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_C4", 412},
      {""},
#line 343 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_C5", 334},
#line 87 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_OP2", 78},
#line 1713 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O03", 1704},
      {""}, {""},
#line 361 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_H5", 352},
      {""}, {""},
#line 425 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_O4", 416},
      {""}, {""}, {""}, {""}, {""},
#line 20 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C2'", 11},
      {""},
#line 86 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_OP1", 77},
      {""}, {""},
#line 40 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H2'", 31},
#line 394 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C5", 385},
      {""}, {""}, {""},
#line 21 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_O2'", 12},
      {""}, {""}, {""}, {""},
#line 22 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C1'", 13},
#line 1526 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_CB", 1517},
#line 88 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_OP3", 79},
      {""}, {""},
#line 42 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H1'", 33},
      {""},
#line 1538 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_HB2", 1529},
      {""}, {""}, {""}, {""},
#line 1506 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CZ2", 1497},
      {""}, {""},
#line 18 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C3'", 9},
      {""},
#line 1518 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HZ2", 1509},
      {""}, {""},
#line 38 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H3'", 29},
      {""}, {""}, {""}, {""},
#line 19 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_O3'", 10},
#line 1242 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_CG", 1233},
      {""}, {""}, {""}, {""}, {""},
#line 1255 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HG2", 1246},
      {""}, {""}, {""}, {""},
#line 1539 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_HB3", 1530},
      {""}, {""}, {""}, {""},
#line 1507 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CZ3", 1498},
      {""}, {""}, {""}, {""},
#line 1519 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HZ3", 1510},
      {""}, {""}, {""}, {""},
#line 1608 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HOH_O", 1599},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 329 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_HOP2", 320},
#line 1256 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HG3", 1247},
      {""}, {""}, {""}, {""},
#line 1154 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_C", 1145},
      {""}, {""}, {""}, {""},
#line 1161 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_H", 1152},
      {""}, {""}, {""},
#line 422 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_C5", 413},
#line 1155 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_O", 1146},
      {""}, {""},
#line 57 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_C2'", 48},
#line 441 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_H5", 432},
      {""}, {""}, {""},
#line 75 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H2'", 66},
      {""}, {""}, {""}, {""},
#line 58 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_O2'", 49},
      {""}, {""}, {""}, {""},
#line 59 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_C1'", 50},
      {""}, {""}, {""}, {""},
#line 77 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H1'", 68},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 55 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_C3'", 46},
      {""}, {""}, {""}, {""},
#line 73 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H3'", 64},
      {""},
#line 1152 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_N", 1143},
#line 1158 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_CD", 1149},
      {""},
#line 56 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_O3'", 47},
      {""}, {""}, {""}, {""}, {""},
#line 1628 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_N9", 1619},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1611 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CS_CS", 1602},
      {""}, {""}, {""},
#line 1168 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_HD1", 1159},
      {""},
#line 943 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H22", 934},
      {""}, {""},
#line 1159 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_OD1", 1150},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1499 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CB", 1490},
      {""}, {""}, {""},
#line 1166 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_HD22", 1157},
#line 1001 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_CZ", 992},
#line 1513 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HB2", 1504},
      {""}, {""}, {""},
#line 1042 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_CG", 1033},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 199 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_P", 190},
      {""}, {""},
#line 245 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C2'", 236},
#line 910 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_OP2", 901},
      {""}, {""}, {""},
#line 265 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_H2'", 256},
#line 1025 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_CG", 1016},
      {""}, {""},
#line 201 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_OP2", 192},
#line 246 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_O2'", 237},
#line 1073 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_SG", 1064},
#line 1514 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HB3", 1505},
      {""}, {""},
#line 247 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C1'", 238},
#line 291 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C2", 282},
      {""}, {""}, {""},
#line 267 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_H1'", 258},
      {""}, {""}, {""},
#line 200 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_OP1", 191},
      {""}, {""}, {""}, {""}, {""},
#line 243 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C3'", 234},
      {""}, {""}, {""}, {""},
#line 263 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_H3'", 254},
      {""}, {""}, {""},
#line 202 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_OP3", 193},
#line 244 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_O3'", 235},
#line 1268 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_SD", 1259},
      {""}, {""}, {""}, {""},
#line 1475 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_CB", 1466},
      {""}, {""}, {""}, {""},
#line 1488 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_HB", 1479},
      {""}, {""}, {""}, {""},
#line 1676 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_N9", 1667},
      {""}, {""}, {""}, {""},
#line 1196 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_CB", 1187},
      {""}, {""}, {""}, {""},
#line 292 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_N2", 283},
#line 1204 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HB2", 1195},
#line 817 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C4", 808},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1267 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_CG", 1258},
      {""}, {""}, {""}, {""},
#line 340 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_C2", 331},
#line 1276 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_HG2", 1267},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 345 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_O2", 336},
#line 1205 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HB3", 1196},
      {""}, {""}, {""},
#line 947 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_OP2", 938},
      {""}, {""}, {""}, {""},
#line 398 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C2", 389},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1277 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_HG3", 1268},
      {""}, {""}, {""},
#line 997 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_CB", 988},
      {""},
#line 1215 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_CA", 1206},
      {""}, {""}, {""},
#line 1008 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HB2", 999},
#line 1226 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HA", 1217},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 790 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_HB", 781},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 929 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C4", 920},
      {""}, {""}, {""}, {""}, {""},
#line 399 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_N2", 390},
#line 1009 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HB3", 1000},
      {""}, {""}, {""},
#line 34 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_HOP2", 25},
      {""}, {""}, {""}, {""},
#line 913 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C4'", 904},
      {""}, {""}, {""}, {""},
#line 934 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H4'", 925},
      {""}, {""}, {""},
#line 810 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C5", 801},
#line 914 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_O4'", 905},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 419 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_C2", 410},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 424 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_O2", 415},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 523 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_P", 514},
#line 1072 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_CB", 1063},
      {""}, {""}, {""},
#line 1616 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ACT_C", 1607},
#line 1225 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_H2", 1216},
#line 1078 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_HB2", 1069},
#line 1157 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_CG", 1148},
#line 1901 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H90", 1892},
      {""}, {""},
#line 525 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_OP2", 516},
#line 1165 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_HG", 1156},
      {""},
#line 1617 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ACT_O", 1608},
      {""}, {""}, {""}, {""}, {""},
#line 536 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_N9", 527},
      {""}, {""}, {""},
#line 960 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C4", 951},
      {""},
#line 524 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_OP1", 515},
      {""}, {""}, {""},
#line 69 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_HOP2", 60},
      {""}, {""}, {""},
#line 961 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_O4", 952},
      {""},
#line 1079 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_HB3", 1070},
      {""}, {""}, {""},
#line 950 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C4'", 941},
#line 526 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_OP3", 517},
      {""}, {""}, {""},
#line 969 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H4'", 960},
      {""}, {""}, {""}, {""},
#line 951 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_O4'", 942},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 901 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H2''", 892},
#line 1395 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_CA", 1386},
      {""}, {""}, {""}, {""},
#line 1413 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HA", 1404},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 32 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C4", 23},
      {""},
#line 132 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_N9", 123},
      {""}, {""}, {""}, {""},
#line 1056 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_SG", 1047},
      {""}, {""}, {""}, {""},
#line 1241 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_CB", 1232},
      {""}, {""}, {""}, {""}, {""},
#line 1253 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HB2", 1244},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1378 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_CA", 1369},
      {""}, {""}, {""}, {""},
#line 1386 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_HA", 1377},
      {""}, {""},
#line 259 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_HOP2", 250},
#line 1254 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HB3", 1245},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1619 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ACT_CH3", 1610},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1655 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_PG", 1646},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1412 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_H2", 1403},
      {""}, {""},
#line 64 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_C4", 55},
      {""},
#line 328 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_HOP3", 319},
      {""}, {""}, {""},
#line 79 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H42", 70},
      {""},
#line 1767 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C42", 1758},
      {""}, {""}, {""},
#line 1817 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H4", 1808},
#line 1855 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H42", 1846},
      {""}, {""}, {""}, {""},
#line 1768 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O42", 1759},
      {""}, {""},
#line 78 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H41", 69},
      {""},
#line 1766 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C41", 1757},
#line 1523 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_CA", 1514},
      {""}, {""}, {""},
#line 1854 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H41", 1845},
#line 1537 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_HA", 1528},
      {""}, {""}, {""},
#line 1409 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_O2P", 1400},
#line 297 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HOP2", 288},
      {""}, {""}, {""},
#line 1769 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C43", 1760},
      {""}, {""}, {""},
#line 755 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C4", 746},
#line 1856 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H43", 1847},
#line 286 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_N7", 277},
      {""}, {""}, {""}, {""}, {""},
#line 65 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_N4", 56},
      {""},
#line 1041 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_CB", 1032},
      {""}, {""}, {""}, {""}, {""},
#line 1049 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_HB2", 1040},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 458 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_C4", 449},
#line 814 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C2", 805},
      {""}, {""}, {""}, {""}, {""},
#line 1024 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_CB", 1015},
      {""}, {""},
#line 462 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_O4", 453},
      {""}, {""},
#line 1032 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_HB2", 1023},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1050 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_HB3", 1041},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 257 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C4", 248},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 375 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_HOP2", 366},
      {""}, {""}, {""},
#line 1033 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_HB3", 1024},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1785 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C52", 1776},
#line 815 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_N2", 806},
#line 907 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_OP3", 898},
      {""},
#line 1818 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H5", 1809},
#line 1865 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H52", 1856},
      {""}, {""}, {""},
#line 402 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_HOP2", 393},
#line 1786 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O52", 1777},
      {""},
#line 1055 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_CB", 1046},
      {""}, {""},
#line 1783 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C51", 1774},
      {""},
#line 1536 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_H2", 1527},
#line 1064 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_HB2", 1055},
#line 393 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_N7", 384},
#line 1864 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H51", 1855},
      {""}, {""}, {""}, {""},
#line 1784 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O51", 1775},
      {""}, {""}, {""}, {""},
#line 1787 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C53", 1778},
      {""},
#line 1266 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_CB", 1257},
      {""},
#line 756 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C5", 747},
#line 1866 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H53", 1857},
      {""}, {""},
#line 1274 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_HB2", 1265},
      {""},
#line 1788 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O53", 1779},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1065 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_HB3", 1056},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 459 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_C5", 450},
      {""},
#line 1496 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CA", 1487},
      {""}, {""}, {""}, {""},
#line 1512 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HA", 1503},
      {""},
#line 1720 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C09", 1711},
#line 293 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_N3", 284},
#line 1275 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_HB3", 1266},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1721 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O09", 1712},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 453 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_HOP2", 444},
      {""}, {""},
#line 876 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_OP2", 867},
      {""}, {""}, {""}, {""},
#line 944 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_OP3", 935},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 129 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C2'", 120},
      {""}, {""}, {""}, {""},
#line 150 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H2'", 141},
      {""}, {""},
#line 1474 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_CA", 1465},
      {""},
#line 130 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_O2'", 121},
      {""}, {""},
#line 1487 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_HA", 1478},
      {""},
#line 131 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C1'", 122},
#line 341 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_N3", 332},
      {""}, {""}, {""},
#line 152 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H1'", 143},
      {""}, {""},
#line 1193 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_CA", 1184},
      {""}, {""}, {""}, {""},
#line 1203 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HA", 1194},
      {""},
#line 127 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C3'", 118},
      {""}, {""}, {""}, {""},
#line 148 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H3'", 139},
#line 400 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_N3", 391},
#line 543 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_CM1", 534},
#line 314 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HM23", 305},
      {""},
#line 128 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_O3'", 119},
#line 33 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_HOP3", 24},
      {""},
#line 559 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_HM11", 550},
      {""}, {""},
#line 1511 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_H2", 1502},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 311 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HM13", 302},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1156 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_CB", 1147},
      {""}, {""}, {""}, {""}, {""},
#line 1163 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_HB2", 1154},
      {""}, {""}, {""},
#line 560 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_HM12", 551},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 994 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_CA", 985},
      {""}, {""}, {""}, {""},
#line 1007 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HA", 998},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1164 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_HB3", 1155},
      {""}, {""}, {""}, {""}, {""},
#line 789 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_HA", 780},
      {""}, {""},
#line 369 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_HM23", 360},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1486 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_H2", 1477},
      {""}, {""}, {""}, {""},
#line 420 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_N3", 411},
      {""}, {""}, {""},
#line 889 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_C4", 880},
      {""}, {""},
#line 412 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_HM23", 403},
      {""}, {""},
#line 1202 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_H2", 1193},
      {""}, {""}, {""}, {""},
#line 68 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_HOP3", 59},
      {""}, {""}, {""}, {""},
#line 879 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_C4'", 870},
      {""}, {""}, {""}, {""},
#line 897 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H4'", 888},
      {""}, {""}, {""}, {""},
#line 880 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_O4'", 871},
#line 1480 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_O2P", 1471},
      {""}, {""},
#line 1458 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_C", 1449},
      {""}, {""}, {""}, {""},
#line 1464 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_H", 1455},
      {""}, {""}, {""}, {""},
#line 1459 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_O", 1450},
      {""}, {""}, {""},
#line 1735 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C22", 1726},
      {""}, {""}, {""},
#line 1815 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H2", 1806},
#line 1835 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H22", 1826},
#line 890 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_N4", 881},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1734 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C21", 1725},
#line 277 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C4'", 268},
      {""}, {""},
#line 1069 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_CA", 1060},
#line 1834 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H21", 1825},
#line 301 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_H4'", 292},
#line 1006 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_H2", 997},
      {""},
#line 1077 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_HA", 1068},
      {""},
#line 278 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_O4'", 269},
      {""}, {""}, {""},
#line 1736 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C23", 1727},
      {""}, {""}, {""},
#line 754 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C2", 745},
#line 1836 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H23", 1827},
#line 1456 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_N", 1447},
#line 1660 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_PB", 1651},
      {""},
#line 778 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H2", 769},
#line 1737 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O23", 1728},
      {""}, {""}, {""},
#line 447 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_HM23", 438},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 456 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_C2", 447},
      {""}, {""},
#line 102 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_C4", 93},
      {""},
#line 258 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_HOP3", 249},
      {""}, {""}, {""},
#line 116 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H42", 107},
#line 461 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_O2", 452},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 758 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_O2P", 749},
      {""}, {""},
#line 819 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HOP2", 810},
      {""}, {""},
#line 115 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H41", 106},
      {""}, {""}, {""}, {""},
#line 352 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_C4'", 343},
      {""},
#line 809 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_N7", 800},
      {""}, {""},
#line 371 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_H4'", 362},
      {""}, {""}, {""}, {""},
#line 353 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_O4'", 344},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 383 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C4'", 374},
      {""}, {""},
#line 1240 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_CA", 1231},
#line 103 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_N4", 94},
#line 406 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_H4'", 397},
      {""}, {""},
#line 1252 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HA", 1243},
      {""},
#line 384 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_O4'", 375},
      {""}, {""},
#line 1613 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MG_MG", 1604},
      {""}, {""}, {""},
#line 276 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C5'", 267},
      {""}, {""}, {""},
#line 1076 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_H2", 1067},
#line 299 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_H5'", 290},
      {""}, {""}, {""}, {""},
#line 275 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_O5'", 266},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1410 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_O3P", 1401},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 104 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_C5", 95},
      {""}, {""}, {""}, {""},
#line 117 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H5", 108},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 144 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_HOP2", 135},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 431 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_C4'", 422},
      {""},
#line 355 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_C5'", 346},
      {""},
#line 1906 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H94", 1897},
#line 449 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_H4'", 440},
      {""},
#line 373 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_H5'", 364},
      {""}, {""},
#line 433 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_O4'", 424},
      {""},
#line 356 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_O5'", 347},
#line 1212 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HD23", 1203},
#line 1632 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C4", 1623},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 382 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C5'", 373},
      {""}, {""}, {""},
#line 1251 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_H2", 1242},
#line 404 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_H5'", 395},
#line 1209 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HD13", 1200},
      {""}, {""}, {""},
#line 381 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_O5'", 372},
      {""}, {""},
#line 816 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_N3", 807},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1038 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_CA", 1029},
      {""}, {""}, {""}, {""},
#line 1048 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_HA", 1039},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 338 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_H1'2", 329},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1021 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_CA", 1012},
      {""}, {""}, {""}, {""},
#line 1031 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_HA", 1022},
      {""}, {""},
#line 216 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_C4", 207},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 217 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_O4", 208},
      {""},
#line 1421 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HO2P", 1412},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 434 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_C5'", 425},
      {""}, {""}, {""}, {""},
#line 451 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_H5'", 442},
      {""}, {""}, {""}, {""},
#line 435 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_O5'", 426},
      {""},
#line 1686 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C4", 1677},
      {""},
#line 1631 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C5", 1622},
      {""},
#line 1422 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HO3P", 1413},
      {""}, {""}, {""}, {""},
#line 1054 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_CA", 1045},
      {""}, {""},
#line 873 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_OP3", 864},
      {""},
#line 1063 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_HA", 1054},
#line 142 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C4", 133},
      {""}, {""},
#line 1462 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_CG2", 1453},
      {""}, {""}, {""}, {""}, {""},
#line 1469 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_HG21", 1460},
      {""}, {""}, {""}, {""},
#line 1263 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_CA", 1254},
      {""}, {""}, {""}, {""},
#line 1273 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_HA", 1264},
      {""}, {""}, {""},
#line 1468 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_HG1", 1459},
      {""}, {""}, {""},
#line 1047 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_H2", 1038},
#line 1461 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_OG1", 1452},
      {""}, {""}, {""}, {""}, {""},
#line 1492 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_HOP2", 1483},
      {""}, {""}, {""}, {""},
#line 1470 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_HG22", 1461},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1030 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_H2", 1021},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 218 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_C5", 209},
      {""},
#line 1820 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H7", 1811},
#line 1885 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H72", 1876},
      {""}, {""},
#line 232 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H52", 223},
      {""},
#line 1806 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O72", 1797},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1884 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H71", 1875},
      {""}, {""},
#line 231 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H51", 222},
      {""},
#line 1805 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O71", 1796},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1886 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H73", 1877},
#line 281 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C2'", 272},
      {""}, {""}, {""},
#line 1679 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C5", 1670},
#line 304 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_H2'", 295},
      {""}, {""}, {""}, {""},
#line 282 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_O2'", 273},
      {""},
#line 1780 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C49", 1771},
#line 321 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_C4'", 312},
#line 1062 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_H2", 1053},
      {""}, {""},
#line 1862 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H49", 1853},
#line 332 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_H4'", 323},
      {""}, {""}, {""}, {""},
#line 322 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_O4'", 313},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1272 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_H2", 1263},
      {""},
#line 920 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C8", 911},
      {""}, {""}, {""}, {""},
#line 940 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H8", 931},
      {""}, {""},
#line 99 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_C2", 90},
      {""}, {""}, {""},
#line 765 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_N7", 756},
      {""}, {""}, {""},
#line 800 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C4'", 791},
      {""},
#line 100 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_O2", 91},
#line 84 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_O2C", 75},
      {""},
#line 823 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_H4'", 814},
      {""}, {""}, {""},
#line 487 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_HOP2", 478},
#line 801 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_O4'", 792},
      {""}, {""}, {""},
#line 1491 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_HG23", 1482},
      {""}, {""}, {""},
#line 348 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_C2'", 339},
      {""}, {""}, {""}, {""},
#line 366 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_H2'", 357},
      {""}, {""},
#line 1153 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_CA", 1144},
      {""},
#line 349 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_O2'", 340},
      {""}, {""},
#line 1162 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_HA", 1153},
      {""},
#line 1481 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_O3P", 1472},
      {""},
#line 547 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C4", 538},
      {""}, {""},
#line 387 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C2'", 378},
#line 679 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_P", 670},
      {""}, {""}, {""},
#line 409 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_H2'", 400},
      {""}, {""}, {""}, {""},
#line 388 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_O2'", 379},
      {""},
#line 1751 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C32", 1742},
#line 681 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_OP2", 672},
      {""}, {""},
#line 1816 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H3", 1807},
#line 1845 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H32", 1836},
      {""}, {""}, {""}, {""},
#line 1752 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O32", 1743},
      {""}, {""}, {""}, {""},
#line 1749 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C31", 1740},
#line 680 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_OP1", 671},
#line 1796 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C59", 1787},
#line 1764 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C40", 1755},
      {""},
#line 1844 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H31", 1835},
      {""},
#line 1872 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H59", 1863},
#line 1853 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H40", 1844},
      {""},
#line 1750 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O31", 1741},
      {""},
#line 1797 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O59", 1788},
#line 1765 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O40", 1756},
      {""},
#line 1753 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C33", 1744},
#line 682 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_OP3", 673},
      {""}, {""}, {""},
#line 1846 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H33", 1837},
      {""}, {""}, {""}, {""},
#line 1754 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O33", 1745},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 799 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C5'", 790},
      {""},
#line 1610 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HOH_H2", 1601},
      {""}, {""},
#line 821 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_H5'", 812},
      {""}, {""}, {""}, {""},
#line 798 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_O5'", 789},
      {""}, {""},
#line 791 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H3P", 782},
      {""}, {""},
#line 427 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_C2'", 418},
      {""},
#line 777 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_O3P", 768},
      {""}, {""},
#line 444 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_H2'", 435},
      {""}, {""}, {""}, {""},
#line 428 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_O2'", 419},
#line 760 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_N3", 751},
      {""}, {""},
#line 1634 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C2", 1625},
#line 24 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C8", 15},
      {""}, {""}, {""},
#line 539 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C5", 530},
#line 43 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H8", 34},
#line 735 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_P", 726},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 737 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_OP2", 728},
#line 457 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_N3", 448},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1664 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_PA", 1655},
      {""},
#line 736 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_OP1", 727},
      {""}, {""}, {""},
#line 1781 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C50", 1772},
      {""}, {""}, {""}, {""},
#line 1863 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H50", 1854},
      {""}, {""}, {""},
#line 1714 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C04", 1705},
#line 1782 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O50", 1773},
#line 738 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_OP3", 729},
#line 1638 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_N2", 1629},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 213 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_C2", 204},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 214 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_O2", 205},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 143 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_HOP3", 134},
      {""}, {""}, {""},
#line 16 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C4'", 7},
      {""}, {""}, {""}, {""},
#line 37 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H4'", 28},
#line 1683 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C2", 1674},
      {""}, {""}, {""},
#line 17 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_O4'", 8},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1133 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_C", 1124},
      {""}, {""}, {""}, {""},
#line 1142 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_H", 1133},
      {""}, {""}, {""}, {""},
#line 1134 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_O", 1125},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1150 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_HE2", 1141},
      {""}, {""},
#line 1657 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O2G", 1648},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1139 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_CE1", 1130},
      {""}, {""}, {""}, {""},
#line 1149 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_HE1", 1140},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1684 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_N2", 1675},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1131 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_N", 1122},
      {""},
#line 1138 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_CD2", 1129},
      {""}, {""}, {""}, {""},
#line 1148 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_HD2", 1139},
      {""}, {""}, {""}, {""},
#line 1140 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_NE2", 1131},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1147 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_HD1", 1138},
      {""},
#line 1460 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_CB", 1451},
#line 249 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C8", 240},
      {""}, {""},
#line 53 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_C4'", 44},
#line 1467 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_HB", 1458},
#line 268 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_H8", 259},
      {""}, {""},
#line 72 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H4'", 63},
      {""}, {""}, {""}, {""},
#line 54 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_O4'", 45},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1746 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C29", 1737},
      {""}, {""}, {""}, {""},
#line 1842 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H29", 1833},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1137 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_ND1", 1128},
      {""}, {""},
#line 769 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C4'", 760},
      {""}, {""},
#line 1167 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_HD23", 1158},
      {""},
#line 786 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H4'", 777},
#line 106 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_HOC2", 97},
      {""}, {""}, {""},
#line 770 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_O4'", 761},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 467 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_C4'", 458},
#line 804 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C2'", 795},
      {""}, {""}, {""},
#line 483 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_H4'", 474},
#line 826 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_H2'", 817},
      {""}, {""}, {""},
#line 469 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_O4'", 460},
#line 805 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_O2'", 796},
      {""},
#line 107 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_HOP2", 98},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 922 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C5", 913},
      {""}, {""}, {""},
#line 936 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_HO3'", 927},
      {""}, {""},
#line 241 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C4'", 232},
      {""}, {""}, {""}, {""},
#line 262 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_H4'", 253},
#line 544 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C2", 535},
      {""}, {""},
#line 912 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C5'", 903},
#line 242 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_O4'", 233},
      {""}, {""}, {""},
#line 932 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H5'", 923},
      {""}, {""}, {""}, {""},
#line 911 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_O5'", 902},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 279 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C3'", 270},
      {""},
#line 1732 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C20", 1723},
      {""}, {""},
#line 302 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_H3'", 293},
      {""},
#line 1833 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H20", 1824},
      {""},
#line 1621 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ACT_H2", 1612},
#line 280 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_O3'", 271},
      {""},
#line 1733 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O20", 1724},
      {""}, {""}, {""}, {""},
#line 768 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C5'", 759},
      {""},
#line 545 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_N2", 536},
      {""}, {""}, {""},
#line 784 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H5'1", 775},
      {""}, {""}, {""},
#line 767 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_O5'", 758},
      {""}, {""}, {""},
#line 604 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_P", 595},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 470 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_C5'", 461},
      {""}, {""},
#line 606 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_OP2", 597},
      {""},
#line 485 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_H5'", 476},
      {""}, {""}, {""}, {""},
#line 471 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_O5'", 462},
      {""},
#line 617 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_N9", 608},
#line 785 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H5'2", 776},
      {""}, {""},
#line 962 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C5", 953},
      {""},
#line 605 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_OP1", 596},
      {""},
#line 971 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_HO3'", 962},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 351 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_C3'", 342},
      {""},
#line 949 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C5'", 940},
#line 607 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_OP3", 598},
      {""},
#line 370 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_H3'", 361},
      {""},
#line 967 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H5'", 958},
      {""}, {""},
#line 354 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_O3'", 345},
      {""},
#line 948 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_O5'", 939},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 385 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C3'", 376},
      {""}, {""}, {""},
#line 101 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_N3", 92},
#line 407 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_H3'", 398},
      {""}, {""}, {""}, {""},
#line 386 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_O3'", 377},
#line 1630 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_N7", 1621},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 26 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C5", 17},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1136 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_CG", 1127},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 220 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_HOP2", 211},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 430 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_C3'", 421},
      {""}, {""}, {""}, {""},
#line 448 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_H3'", 439},
      {""}, {""}, {""}, {""},
#line 432 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_O3'", 423},
#line 1687 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_HOG2", 1678},
      {""}, {""}, {""}, {""}, {""},
#line 942 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H21", 933},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 66 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_C5", 57},
#line 1678 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_N7", 1669},
      {""}, {""}, {""},
#line 80 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H5", 71},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 909 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_OP1", 900},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1633 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_N3", 1624},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1892 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H79", 1883},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 290 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_N1", 281},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 251 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C5", 242},
      {""}, {""}, {""}, {""}, {""},
#line 215 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_N3", 206},
#line 772 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C2'", 763},
      {""}, {""}, {""}, {""},
#line 788 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H2'", 779},
      {""}, {""}, {""}, {""},
#line 773 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_O2'", 764},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1658 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O3G", 1649},
      {""},
#line 946 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_OP1", 937},
      {""}, {""},
#line 464 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_C2'", 455},
      {""}, {""},
#line 91 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_C4'", 82},
      {""},
#line 480 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_H2'", 471},
      {""}, {""},
#line 111 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H4'", 102},
      {""},
#line 465 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_O2'", 456},
      {""}, {""},
#line 92 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_O4'", 83},
#line 1685 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_N3", 1676},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 339 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_N1", 330},
      {""}, {""}, {""},
#line 298 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HOP3", 289},
      {""}, {""}, {""},
#line 1770 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C44", 1761},
      {""}, {""}, {""}, {""},
#line 1857 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H44", 1848},
      {""}, {""}, {""},
#line 1813 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C70", 1804},
#line 1771 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O44", 1762},
      {""},
#line 397 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_N1", 388},
      {""},
#line 1883 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H70", 1874},
      {""},
#line 548 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_HOP2", 539},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 538 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_N7", 529},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1762 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C39", 1753},
      {""}, {""}, {""}, {""},
#line 1852 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H39", 1843},
      {""}, {""}, {""}, {""},
#line 1763 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O39", 1754},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 376 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_HOP3", 367},
      {""}, {""}, {""},
#line 90 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_C5'", 81},
      {""}, {""}, {""}, {""},
#line 109 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H5'", 100},
      {""}, {""}, {""},
#line 802 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C3'", 793},
#line 89 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_O5'", 80},
      {""}, {""}, {""},
#line 824 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_H3'", 815},
#line 856 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C2", 847},
#line 403 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_HOP3", 394},
      {""}, {""},
#line 803 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_O3'", 794},
#line 872 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H2", 863},
#line 1457 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_CA", 1448},
      {""},
#line 626 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_CM2", 617},
      {""}, {""},
#line 1466 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_HA", 1457},
#line 418 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_N1", 409},
      {""},
#line 642 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_HM21", 633},
      {""},
#line 847 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C2'", 838},
      {""}, {""}, {""}, {""},
#line 866 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H2'", 857},
#line 1789 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C54", 1780},
#line 1625 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C4'", 1616},
      {""}, {""}, {""},
#line 1867 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H54", 1858},
#line 1645 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H4'", 1636},
#line 838 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_P", 829},
      {""},
#line 848 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C1'", 839},
      {""},
#line 1626 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_O4'", 1617},
      {""}, {""},
#line 868 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H1'", 859},
#line 82 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_PC", 73},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 643 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_HM22", 634},
#line 133 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C8", 124},
#line 845 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C3'", 836},
#line 860 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_HOP2", 851},
      {""}, {""},
#line 153 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H8", 144},
#line 864 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H3'", 855},
      {""}, {""}, {""}, {""},
#line 846 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_O3'", 837},
      {""}, {""}, {""}, {""},
#line 285 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C8", 276},
#line 1747 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C30", 1738},
      {""}, {""},
#line 855 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_N1", 846},
#line 307 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_H8", 298},
#line 1843 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H30", 1834},
      {""},
#line 1622 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ACT_H3", 1613},
      {""}, {""},
#line 1748 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O30", 1739},
      {""}, {""}, {""}, {""},
#line 859 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_HOP3", 850},
      {""},
#line 546 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_N3", 537},
#line 857 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_N3", 848},
      {""}, {""}, {""},
#line 904 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H42", 895},
      {""},
#line 454 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_HOP3", 445},
      {""}, {""}, {""},
#line 205 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_C4'", 196},
      {""}, {""}, {""}, {""},
#line 224 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H4'", 215},
      {""}, {""}, {""}, {""},
#line 206 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_O4'", 197},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 891 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_C5", 882},
      {""}, {""},
#line 1465 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_H2", 1456},
#line 899 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_HO3'", 890},
#line 905 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H5", 896},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 878 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_C5'", 869},
#line 1669 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C4'", 1660},
      {""},
#line 1624 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C5'", 1615},
      {""},
#line 895 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H5'", 886},
#line 1693 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_H4'", 1684},
      {""},
#line 1642 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H5'", 1633},
#line 1643 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H5'1", 1634},
#line 877 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_O5'", 868},
#line 1670 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O4'", 1661},
      {""},
#line 1623 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_O5'", 1614},
#line 1135 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_CB", 1126},
      {""},
#line 125 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C4'", 116},
      {""}, {""}, {""},
#line 1145 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_HB2", 1136},
#line 147 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H4'", 138},
      {""}, {""},
#line 392 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C8", 383},
      {""},
#line 126 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_O4'", 117},
      {""}, {""},
#line 414 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_H8", 405},
      {""}, {""},
#line 923 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C6", 914},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1644 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H5'2", 1635},
      {""}, {""},
#line 924 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_O6", 915},
      {""},
#line 1084 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_C", 1075},
      {""}, {""}, {""}, {""},
#line 1092 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_H", 1083},
#line 1146 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_HB3", 1137},
      {""}, {""}, {""},
#line 1085 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_O", 1076},
      {""}, {""}, {""}, {""},
#line 561 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_HM13", 552},
      {""}, {""},
#line 1099 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_HE21", 1090},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 204 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_C5'", 195},
      {""}, {""},
#line 696 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_C4", 687},
      {""},
#line 222 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H5'", 213},
#line 1408 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_O1P", 1399},
      {""}, {""}, {""},
#line 203 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_O5'", 194},
#line 1089 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_OE1", 1080},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1100 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_HE22", 1091},
      {""},
#line 1082 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_N", 1073},
#line 1088 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_CD", 1079},
      {""}, {""}, {""},
#line 1104 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_C", 1095},
      {""}, {""}, {""}, {""},
#line 1112 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_H", 1103},
      {""},
#line 1090 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_NE2", 1081},
      {""},
#line 1668 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C5'", 1659},
#line 1105 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_O", 1096},
      {""}, {""}, {""},
#line 1691 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_H5'", 1682},
      {""}, {""},
#line 1119 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_HE2", 1110},
      {""},
#line 1667 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O5'", 1658},
      {""}, {""},
#line 1110 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_OE2", 1101},
      {""},
#line 697 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_N4", 688},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 964 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C6", 955},
      {""}, {""}, {""},
#line 1109 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_OE1", 1100},
#line 979 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H6", 970},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 95 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_C2'", 86},
#line 1102 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_N", 1093},
#line 1108 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_CD", 1099},
      {""}, {""},
#line 113 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H2'", 104},
      {""}, {""}, {""}, {""},
#line 96 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_O2'", 87},
#line 813 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_N1", 804},
      {""}, {""}, {""}, {""},
#line 921 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_N7", 912},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 720 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C4", 711},
      {""},
#line 698 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_C5", 689},
      {""}, {""}, {""}, {""},
#line 1738 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C24", 1729},
#line 27 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C6", 18},
      {""},
#line 725 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_O4", 716},
      {""},
#line 1837 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H24", 1828},
#line 529 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C4'", 520},
#line 45 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H62", 36},
      {""}, {""},
#line 1739 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O24", 1730},
#line 552 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_H4'", 543},
      {""}, {""}, {""}, {""},
#line 530 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_O4'", 521},
      {""}, {""}, {""}, {""}, {""},
#line 44 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H61", 35},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 963 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C7", 954},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1907 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H95", 1898},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 820 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HOP3", 811},
      {""}, {""},
#line 28 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_N6", 19},
      {""}, {""}, {""},
#line 774 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C3'", 765},
      {""},
#line 1719 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C08", 1710},
      {""}, {""},
#line 787 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H3'", 778},
      {""}, {""}, {""}, {""},
#line 775 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_O3'", 766},
      {""}, {""}, {""}, {""},
#line 875 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_OP1", 866},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 466 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_C3'", 457},
      {""}, {""}, {""}, {""},
#line 482 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_H3'", 473},
      {""}, {""}, {""}, {""},
#line 468 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_O3'", 459},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 67 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_C6", 58},
      {""}, {""}, {""},
#line 721 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C5", 712},
#line 81 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H6", 72},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1639 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C2'", 1630},
      {""}, {""}, {""}, {""},
#line 528 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C5'", 519},
#line 1651 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H2'1", 1642},
      {""}, {""}, {""},
#line 550 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_H5'", 541},
      {""}, {""}, {""}, {""},
#line 527 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_O5'", 518},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 503 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_C2", 494},
      {""},
#line 25 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_N7", 16},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 504 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_O2", 495},
      {""}, {""},
#line 1652 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H2'2", 1643},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 490 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_P", 481},
      {""}, {""},
#line 518 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_HO2'", 509},
      {""}, {""},
#line 520 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_H3", 511},
      {""},
#line 135 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C5", 126},
      {""}, {""}, {""},
#line 492 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_OP2", 483},
      {""}, {""},
#line 210 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_C2'", 201},
      {""}, {""}, {""}, {""},
#line 228 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H2'", 219},
      {""}, {""}, {""}, {""},
#line 211 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_O2'", 202},
      {""},
#line 491 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_OP1", 482},
      {""}, {""}, {""},
#line 252 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C6", 243},
      {""},
#line 516 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_HO3'", 507},
      {""}, {""},
#line 502 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_N1", 493},
      {""},
#line 808 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C8", 799},
      {""},
#line 1087 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_CG", 1078},
#line 253 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_O6", 244},
#line 489 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_OP3", 480},
      {""},
#line 830 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_H82", 821},
      {""},
#line 1097 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_HG2", 1088},
      {""}, {""}, {""}, {""},
#line 505 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_N3", 496},
      {""},
#line 1673 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C2'", 1664},
      {""}, {""}, {""}, {""},
#line 1696 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_H2'", 1687},
#line 829 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_H81", 820},
      {""}, {""}, {""},
#line 1674 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O2'", 1665},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1336 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_C", 1327},
      {""},
#line 1098 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_HG3", 1089},
      {""}, {""},
#line 1343 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_H", 1334},
      {""}, {""}, {""}, {""},
#line 1337 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_O", 1328},
#line 1342 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_CE", 1333},
#line 1479 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_O1P", 1470},
      {""}, {""}, {""}, {""},
#line 1352 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_HE2", 1343},
      {""}, {""},
#line 1291 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_C", 1282},
#line 1107 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_CG", 1098},
      {""}, {""}, {""},
#line 1294 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_H", 1285},
      {""},
#line 1117 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_HG2", 1108},
      {""},
#line 1706 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C12", 1697},
#line 1292 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_O", 1283},
#line 1287 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_CE", 1278},
#line 1351 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_HE1", 1342},
#line 1814 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H1", 1805},
#line 1825 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H12", 1816},
#line 320 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_C5'", 311},
      {""},
#line 1303 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HE2", 1294},
      {""},
#line 1722 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O12", 1713},
#line 330 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_H5'", 321},
      {""}, {""}, {""},
#line 1704 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C11", 1695},
#line 319 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_O5'", 310},
      {""},
#line 1353 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_HE3", 1344},
      {""},
#line 1824 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H11", 1815},
#line 1334 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_N", 1325},
#line 693 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_C2", 684},
      {""}, {""}, {""}, {""},
#line 331 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_H5''", 322},
#line 1118 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_HG3", 1109},
      {""},
#line 1707 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C13", 1698},
      {""},
#line 694 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_O2", 685},
      {""}, {""},
#line 1826 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H13", 1817},
      {""}, {""},
#line 1304 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HE3", 1295},
      {""},
#line 1723 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O13", 1714},
#line 1282 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_N", 1273},
#line 1286 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_CD", 1277},
      {""}, {""}, {""}, {""}, {""},
#line 1301 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HD2", 1292},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 250 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_N7", 241},
      {""}, {""}, {""}, {""}, {""},
#line 1493 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_HOP3", 1484},
      {""}, {""}, {""},
#line 779 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H1P", 770},
#line 1471 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_HG23", 1462},
      {""}, {""}, {""},
#line 757 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_O1P", 748},
      {""}, {""},
#line 1302 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HD3", 1293},
      {""},
#line 628 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C4", 619},
      {""}, {""}, {""},
#line 761 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_N1", 752},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1290 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_CH2", 1281},
      {""}, {""}, {""}, {""}, {""},
#line 1308 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HH21", 1299},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 455 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_N1", 446},
#line 1289 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_CH1", 1280},
      {""}, {""}, {""}, {""}, {""},
#line 1305 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HH11", 1296},
      {""}, {""}, {""}, {""},
#line 1887 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H74", 1878},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 718 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C2", 709},
      {""},
#line 1309 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HH22", 1300},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 724 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_O2", 715},
      {""}, {""},
#line 533 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C2'", 524},
      {""}, {""}, {""},
#line 1306 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HH12", 1297},
#line 555 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_H2'", 546},
      {""}, {""},
#line 933 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H5''", 924},
      {""},
#line 534 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_O2'", 525},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1313 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_C", 1304},
      {""}, {""}, {""},
#line 1132 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_CA", 1123},
#line 1329 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_H", 1320},
#line 1327 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_H9", 1318},
      {""}, {""},
#line 1144 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_HA", 1135},
      {""},
#line 1317 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_CE", 1308},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 488 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_HOP3", 479},
      {""}, {""}, {""}, {""}, {""},
#line 620 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C5", 611},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 892 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_C6", 883},
      {""}, {""}, {""}, {""},
#line 906 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H6", 897},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1318 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_N", 1309},
      {""}, {""}, {""}, {""}, {""},
#line 93 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_C3'", 84},
      {""}, {""}, {""}, {""},
#line 112 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H3'", 103},
      {""}, {""}, {""}, {""},
#line 94 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_O3'", 85},
      {""}, {""}, {""},
#line 1715 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C05", 1706},
      {""}, {""},
#line 1341 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_SE", 1332},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1427 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_C", 1418},
      {""},
#line 968 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H5''", 959},
      {""}, {""},
#line 1434 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_H", 1425},
#line 1755 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C34", 1746},
      {""}, {""}, {""},
#line 1428 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_O", 1419},
#line 1847 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H34", 1838},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1143 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_H2", 1134},
      {""}, {""}, {""}, {""},
#line 1430 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_P", 1421},
      {""},
#line 1821 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H8", 1812},
#line 1895 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H82", 1886},
      {""},
#line 15 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C5'", 6},
      {""}, {""}, {""}, {""},
#line 35 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H5'", 26},
      {""}, {""}, {""}, {""},
#line 14 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_O5'", 5},
      {""}, {""},
#line 1894 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H81", 1885},
      {""},
#line 1423 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_N", 1414},
#line 849 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_N9", 840},
      {""}, {""}, {""}, {""},
#line 36 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H5''", 27},
      {""}, {""}, {""}, {""}, {""},
#line 766 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C8", 757},
#line 1896 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H83", 1887},
      {""}, {""},
#line 1340 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_CG", 1331},
#line 780 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H8", 771},
      {""}, {""},
#line 1444 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_C", 1435},
      {""},
#line 1349 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_HG2", 1340},
      {""}, {""},
#line 1449 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_H", 1440},
      {""}, {""}, {""}, {""},
#line 1445 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_O", 1436},
      {""}, {""}, {""}, {""}, {""},
#line 1285 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_CG", 1276},
      {""}, {""}, {""}, {""}, {""},
#line 1299 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HG2", 1290},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 662 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_P", 653},
      {""},
#line 1350 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_HG3", 1341},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 664 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_OP2", 655},
#line 305 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HO2'", 296},
#line 1640 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C3'", 1631},
      {""}, {""}, {""}, {""},
#line 1653 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H3'", 1644},
#line 1442 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_N", 1433},
      {""},
#line 1300 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HG3", 1291},
      {""},
#line 1641 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_O3'", 1632},
      {""}, {""},
#line 663 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_OP1", 654},
      {""},
#line 1717 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_CL2", 1708},
#line 52 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_C5'", 43},
      {""}, {""}, {""}, {""},
#line 70 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H5'", 61},
      {""}, {""}, {""}, {""},
#line 51 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_O5'", 42},
      {""},
#line 665 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_OP3", 656},
#line 303 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HO3'", 294},
#line 1711 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_CL1", 1702},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 71 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H5''", 62},
      {""}, {""}, {""}, {""},
#line 1086 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_CB", 1077},
      {""}, {""}, {""},
#line 308 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HN1", 299},
      {""},
#line 1095 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_HB2", 1086},
#line 1319 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_S", 1310},
      {""}, {""}, {""},
#line 283 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C1'", 274},
      {""}, {""}, {""}, {""},
#line 306 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_H1'", 297},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 207 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_C3'", 198},
      {""}, {""}, {""}, {""},
#line 225 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H3'", 216},
#line 1909 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H96", 1900},
      {""}, {""}, {""},
#line 208 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_O3'", 199},
#line 1096 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_HB3", 1087},
#line 701 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_HOP2", 692},
      {""}, {""}, {""},
#line 1778 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C48", 1769},
      {""}, {""}, {""}, {""},
#line 1861 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H48", 1852},
      {""}, {""}, {""}, {""},
#line 1779 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O48", 1770},
      {""}, {""}, {""},
#line 1106 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_CB", 1097},
      {""},
#line 372 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_HO3'", 363},
#line 1316 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_SD", 1307},
      {""}, {""},
#line 1115 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_HB2", 1106},
      {""},
#line 1671 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C3'", 1662},
      {""}, {""},
#line 83 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_O1C", 74},
      {""},
#line 1694 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_H3'", 1685},
#line 240 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C5'", 231},
      {""}, {""}, {""},
#line 1672 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O3'", 1663},
#line 260 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_H5'", 251},
#line 624 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C2", 615},
      {""},
#line 408 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_HO3'", 399},
      {""},
#line 239 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_O5'", 230},
#line 416 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_HN21", 407},
#line 347 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_C1'", 338},
      {""}, {""}, {""}, {""},
#line 365 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_H1'", 356},
      {""}, {""}, {""},
#line 261 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_H5''", 252},
#line 1116 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_HB3", 1107},
      {""},
#line 288 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C6", 279},
#line 415 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_HN1", 406},
      {""}, {""}, {""},
#line 1315 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_CG", 1306},
      {""}, {""},
#line 390 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C1'", 381},
      {""},
#line 289 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_O6", 280},
      {""},
#line 98 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_N1", 89},
#line 413 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_H1'", 404},
      {""},
#line 741 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H72", 732},
      {""},
#line 417 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_HN22", 408},
      {""}, {""},
#line 1910 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H97", 1901},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 740 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H71", 731},
      {""},
#line 625 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_N2", 616},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 742 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H73", 733},
      {""}, {""}, {""},
#line 752 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_HOP2", 743},
      {""}, {""}, {""}, {""}, {""},
#line 1795 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C58", 1786},
      {""}, {""}, {""}, {""},
#line 1871 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H58", 1862},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 136 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C6", 127},
#line 450 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_HO3'", 441},
#line 344 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_C6", 335},
      {""}, {""}, {""}, {""},
#line 362 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_H6", 353},
      {""}, {""},
#line 137 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_O6", 128},
#line 1609 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HOH_H1", 1600},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 108 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_HOP3", 99},
      {""}, {""}, {""},
#line 395 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C6", 386},
      {""},
#line 695 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_N3", 686},
#line 426 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_C1'", 417},
      {""}, {""}, {""}, {""},
#line 443 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_H1'", 434},
      {""},
#line 396 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_O6", 387},
#line 440 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_HN3", 431},
#line 1426 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_OG", 1417},
      {""}, {""}, {""}, {""}, {""},
#line 982 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_C", 973},
      {""}, {""}, {""},
#line 1654 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H1", 1645},
#line 986 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_H", 977},
      {""}, {""}, {""}, {""},
#line 983 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_O", 974},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 818 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_CM7", 809},
      {""}, {""}, {""}, {""}, {""},
#line 834 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HM71", 825},
      {""}, {""}, {""},
#line 1666 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O2A", 1657},
      {""}, {""}, {""}, {""},
#line 867 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H2''", 858},
      {""}, {""}, {""}, {""},
#line 1635 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_N1", 1626},
#line 980 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_N", 971},
      {""},
#line 531 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C3'", 522},
      {""}, {""}, {""}, {""},
#line 553 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_H3'", 544},
      {""},
#line 1454 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_HG", 1445},
      {""}, {""},
#line 532 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_O3'", 523},
      {""},
#line 1447 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_OG", 1438},
#line 835 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HM72", 826},
      {""},
#line 423 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_C6", 414},
      {""}, {""}, {""}, {""},
#line 442 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_H6", 433},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 719 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_N3", 710},
      {""}, {""},
#line 134 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_N7", 125},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1288 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_NZ", 1279},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 212 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_N1", 203},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1656 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O1G", 1647},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1682 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_N1", 1673},
#line 896 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H5''", 887},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1339 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_CB", 1330},
      {""}, {""}, {""}, {""}, {""},
#line 1347 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_HB2", 1338},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 221 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_HOP3", 212},
      {""}, {""}, {""},
#line 1284 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_CB", 1275},
      {""}, {""}, {""}, {""}, {""},
#line 1297 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HB2", 1288},
      {""}, {""}, {""}, {""},
#line 827 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HO2'", 818},
      {""}, {""}, {""}, {""},
#line 1348 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_HB3", 1339},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1688 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_HOG3", 1679},
#line 1730 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C19", 1721},
      {""}, {""}, {""},
#line 685 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_C4'", 676},
#line 1832 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H19", 1823},
      {""}, {""}, {""},
#line 705 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_H4'", 696},
#line 1731 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O19", 1722},
#line 1298 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HB3", 1289},
      {""}, {""},
#line 686 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_O4'", 677},
      {""},
#line 825 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HO3'", 816},
      {""},
#line 1745 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C28", 1736},
#line 832 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HN21", 823},
      {""}, {""}, {""},
#line 1841 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H28", 1832},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 831 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HN1", 822},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 806 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C1'", 797},
#line 564 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_P", 555},
      {""}, {""}, {""},
#line 828 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_H1'", 819},
      {""}, {""}, {""},
#line 833 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HN22", 824},
      {""}, {""}, {""},
#line 566 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_OP2", 557},
#line 1629 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C8", 1620},
      {""},
#line 1772 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C45", 1763},
      {""}, {""},
#line 1647 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H8", 1638},
      {""},
#line 1858 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H45", 1849},
#line 577 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_N9", 568},
      {""}, {""},
#line 1716 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C06", 1707},
#line 1773 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O45", 1764},
      {""},
#line 565 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_OP1", 556},
      {""}, {""}, {""},
#line 629 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_HOP2", 620},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 619 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_N7", 610},
#line 567 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_OP3", 558},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 300 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_H5''", 291},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1705 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C10", 1696},
#line 730 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C4'", 721},
      {""},
#line 684 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_C5'", 675},
      {""},
#line 1823 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H10", 1814},
#line 748 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H4'", 739},
#line 1620 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ACT_H1", 1611},
#line 703 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_H5'", 694},
      {""}, {""},
#line 732 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_O4'", 723},
      {""},
#line 683 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_O5'", 674},
#line 811 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C6", 802},
      {""}, {""},
#line 542 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_N1", 533},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 812 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_O6", 803},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1314 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_CB", 1305},
      {""}, {""}, {""},
#line 1718 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C07", 1709},
      {""},
#line 840 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_OP2", 831},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1677 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C8", 1668},
      {""}, {""}, {""},
#line 1790 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C55", 1781},
#line 1699 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_H8", 1690},
      {""}, {""},
#line 374 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_H5''", 365},
#line 1868 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H55", 1859},
      {""}, {""}, {""}, {""},
#line 1791 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O55", 1782},
      {""}, {""}, {""},
#line 1083 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_CA", 1074},
      {""}, {""}, {""}, {""},
#line 1094 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_HA", 1085},
      {""}, {""}, {""}, {""},
#line 405 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_H5''", 396},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1690 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_HOA2", 1681},
      {""}, {""},
#line 549 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_HOP3", 540},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 733 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C5'", 724},
      {""}, {""}, {""},
#line 627 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_N3", 618},
#line 750 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H5'", 741},
      {""}, {""}, {""}, {""},
#line 734 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_O5'", 725},
      {""}, {""}, {""},
#line 1425 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_CB", 1416},
      {""},
#line 1103 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_CA", 1094},
      {""}, {""}, {""},
#line 1437 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_HB2", 1428},
#line 1114 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_HA", 1105},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 499 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_C2'", 490},
      {""}, {""}, {""}, {""},
#line 517 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_H2'", 508},
      {""}, {""}, {""}, {""},
#line 500 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_O2'", 491},
      {""}, {""}, {""}, {""},
#line 501 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_C1'", 492},
      {""}, {""}, {""},
#line 1438 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_HB3", 1429},
#line 519 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_H1'", 510},
      {""}, {""}, {""}, {""},
#line 452 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_H5''", 443},
      {""}, {""}, {""}, {""},
#line 497 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_C3'", 488},
      {""},
#line 1904 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H89", 1895},
      {""}, {""},
#line 515 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_H3'", 506},
      {""},
#line 124 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C5'", 115},
#line 1093 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_H2", 1084},
      {""},
#line 498 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_O3'", 489},
      {""},
#line 145 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H5'", 136},
      {""}, {""}, {""}, {""},
#line 123 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_O5'", 114},
      {""}, {""}, {""},
#line 858 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C4", 849},
      {""},
#line 1446 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_CB", 1437},
      {""}, {""}, {""}, {""},
#line 146 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H5''", 137},
#line 1452 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_HB2", 1443},
      {""}, {""}, {""}, {""}, {""},
#line 644 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_HM23", 635},
      {""},
#line 843 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C4'", 834},
      {""}, {""}, {""}, {""},
#line 863 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H4'", 854},
      {""}, {""}, {""}, {""},
#line 844 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_O4'", 835},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1663 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O3A", 1654},
#line 1453 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_HB3", 1444},
      {""}, {""}, {""},
#line 1113 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_H2", 1104},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 537 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C8", 528},
      {""}, {""}, {""}, {""},
#line 558 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_H8", 549},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 481 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_HO2'", 472},
      {""}, {""}, {""}, {""},
#line 1893 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H80", 1884},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1891 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H78", 1882},
#line 689 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_C2'", 680},
      {""}, {""}, {""}, {""},
#line 708 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_H2'", 699},
      {""}, {""}, {""}, {""},
#line 690 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_O2'", 681},
#line 484 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_HO3'", 475},
#line 771 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C1'", 762},
      {""}, {""}, {""}, {""},
#line 781 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H1'", 772},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 476 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_HN1", 467},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 463 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_C1'", 454},
      {""}, {""}, {""}, {""},
#line 479 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_H1'", 470},
      {""}, {""},
#line 477 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_HN3", 468},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1322 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_H4", 1313},
      {""},
#line 1740 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C25", 1731},
      {""},
#line 977 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H72", 968},
      {""}, {""},
#line 1838 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H25", 1829},
#line 610 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C4'", 601},
      {""},
#line 1800 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C62", 1791},
      {""},
#line 1741 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O25", 1732},
#line 633 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_H4'", 624},
#line 1819 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H6", 1810},
#line 1875 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H62", 1866},
      {""}, {""},
#line 611 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_O4'", 602},
      {""}, {""}, {""},
#line 585 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_CM2", 576},
      {""}, {""},
#line 1799 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C61", 1790},
      {""}, {""},
#line 600 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_HM21", 591},
      {""},
#line 1874 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H61", 1865},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1801 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C63", 1792},
      {""}, {""}, {""},
#line 762 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C6", 753},
#line 1876 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H63", 1867},
      {""}, {""}, {""},
#line 792 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H6", 783},
      {""}, {""}, {""}, {""}, {""},
#line 727 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C2'", 718},
      {""}, {""},
#line 601 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_HM22", 592},
      {""},
#line 745 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H2'", 736},
      {""}, {""},
#line 1238 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HXT", 1229},
      {""},
#line 728 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_O2'", 719},
      {""},
#line 460 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_C6", 451},
#line 1223 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_OXT", 1214},
      {""}, {""}, {""},
#line 478 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_H6", 469},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1760 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C38", 1751},
      {""}, {""}, {""}, {""},
#line 1851 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H38", 1842},
      {""}, {""}, {""}, {""},
#line 1761 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O38", 1752},
      {""},
#line 763 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_N6", 754},
#line 822 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_H5''", 813},
      {""}, {""}, {""}, {""}, {""},
#line 1335 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_CA", 1326},
      {""}, {""}, {""}, {""},
#line 1345 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_HA", 1336},
#line 1323 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_H5", 1314},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 609 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C5'", 600},
      {""}, {""}, {""}, {""},
#line 631 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_H5'", 622},
#line 1283 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_CA", 1274},
      {""}, {""}, {""},
#line 608 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_O5'", 599},
#line 1296 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HA", 1287},
      {""},
#line 1123 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_C", 1114},
      {""}, {""}, {""}, {""},
#line 1126 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_H", 1117},
      {""}, {""},
#line 984 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_CB", 975},
      {""},
#line 1124 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_O", 1115},
      {""}, {""}, {""},
#line 990 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_HB2", 981},
      {""}, {""}, {""}, {""},
#line 511 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_HOP2", 502},
#line 1356 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_C", 1347},
      {""}, {""}, {""},
#line 648 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_C4", 639},
#line 1366 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_H", 1357},
      {""}, {""}, {""},
#line 989 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_HB1", 980},
#line 1357 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_O", 1348},
      {""},
#line 1363 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_CE2", 1354},
      {""}, {""}, {""}, {""},
#line 1374 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_HE2", 1365},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 991 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_HB3", 982},
      {""}, {""},
#line 1362 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_CE1", 1353},
      {""}, {""},
#line 1121 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_N", 1112},
      {""},
#line 1373 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_HE1", 1364},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 903 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H41", 894},
      {""}, {""}, {""},
#line 1354 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_N", 1345},
      {""},
#line 1361 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_CD2", 1352},
      {""}, {""}, {""}, {""},
#line 1372 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_HD2", 1363},
      {""}, {""}, {""},
#line 1344 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_H2", 1335},
      {""}, {""}, {""},
#line 837 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_OP3", 828},
      {""},
#line 1360 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_CD1", 1351},
      {""}, {""}, {""}, {""},
#line 1371 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_HD1", 1362},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1414 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HXT", 1405},
#line 1295 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_H2", 1286},
      {""}, {""}, {""},
#line 1398 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_OXT", 1389},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 649 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_C5", 640},
      {""}, {""}, {""},
#line 1774 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C46", 1765},
#line 667 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_H5", 658},
      {""}, {""}, {""},
#line 1859 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H46", 1850},
      {""}, {""}, {""}, {""},
#line 1775 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O46", 1766},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1393 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_HXT", 1384},
      {""}, {""}, {""}, {""},
#line 1384 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_OXT", 1375},
#line 1312 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_CA", 1303},
#line 506 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_C4", 497},
      {""}, {""}, {""},
#line 1320 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_HA", 1311},
      {""}, {""}, {""}, {""}, {""},
#line 507 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_O4", 498},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1776 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C47", 1767},
      {""}, {""}, {""}, {""},
#line 1860 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H47", 1851},
      {""}, {""}, {""}, {""},
#line 1777 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O47", 1768},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1545 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_HXT", 1536},
      {""}, {""}, {""}, {""},
#line 1534 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_OXT", 1525},
      {""},
#line 1792 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C56", 1783},
      {""}, {""}, {""}, {""},
#line 1869 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H56", 1860},
#line 1424 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_CA", 1415},
      {""}, {""}, {""}, {""},
#line 1436 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_HA", 1427},
      {""}, {""},
#line 1888 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H75", 1879},
#line 97 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_C1'", 88},
      {""}, {""}, {""}, {""},
#line 114 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H1'", 105},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1330 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_H2", 1321},
      {""}, {""}, {""}, {""},
#line 652 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_S4", 643},
      {""},
#line 1614 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"NA_NA", 1605},
#line 614 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C2'", 605},
      {""}, {""}, {""}, {""},
#line 636 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_H2'", 627},
      {""}, {""}, {""}, {""},
#line 615 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_O2'", 606},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1703 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C14", 1694},
      {""}, {""}, {""}, {""},
#line 1827 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H14", 1818},
      {""}, {""}, {""}, {""},
#line 1724 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O14", 1715},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1548 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_C", 1539},
      {""}, {""},
#line 1443 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_CA", 1434},
      {""},
#line 1553 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_H", 1544},
      {""}, {""},
#line 1451 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_HA", 1442},
#line 1793 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C57", 1784},
#line 1549 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_O", 1540},
      {""}, {""}, {""},
#line 1870 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H57", 1861},
      {""}, {""}, {""}, {""},
#line 1794 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O57", 1785},
      {""}, {""},
#line 687 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_C3'", 678},
      {""},
#line 105 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_C6", 96},
      {""}, {""},
#line 706 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_H3'", 697},
      {""},
#line 118 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H6", 109},
      {""}, {""},
#line 688 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_O3'", 679},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1435 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_H2", 1426},
      {""}, {""}, {""}, {""},
#line 1359 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_CG", 1350},
      {""},
#line 486 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_H5''", 477},
      {""},
#line 1546 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_N", 1537},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1649 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_HN21", 1640},
      {""}, {""}, {""},
#line 1521 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HXT", 1512},
      {""}, {""}, {""},
#line 1756 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C35", 1747},
#line 1509 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_OXT", 1500},
#line 978 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H73", 969},
#line 1432 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_O2P", 1423},
#line 1310 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HH23", 1301},
#line 1848 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H35", 1839},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1627 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C1'", 1618},
      {""}, {""}, {""}, {""},
#line 1646 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H1'", 1637},
#line 1307 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HH13", 1298},
      {""},
#line 1648 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_HN3", 1639},
#line 1650 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_HN22", 1641},
      {""}, {""}, {""},
#line 229 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_HO2'", 220},
      {""}, {""}, {""}, {""}, {""},
#line 646 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_C2", 637},
      {""}, {""}, {""}, {""},
#line 1450 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_H2", 1441},
      {""}, {""}, {""}, {""},
#line 651 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_O2", 642},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 729 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C3'", 720},
      {""}, {""},
#line 226 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_HO3'", 217},
      {""},
#line 747 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H3'", 738},
      {""}, {""}, {""}, {""},
#line 731 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_O3'", 722},
#line 1697 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_HO2'", 1688},
      {""},
#line 1494 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_HXT", 1485},
      {""}, {""}, {""}, {""},
#line 1484 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_OXT", 1475},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 209 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_C1'", 200},
#line 1213 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HXT", 1204},
      {""}, {""}, {""},
#line 227 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H1'", 218},
#line 1200 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_OXT", 1191},
      {""},
#line 230 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_HN3", 221},
      {""}, {""}, {""}, {""}, {""},
#line 1695 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_HO3'", 1686},
#line 1636 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C6", 1627},
      {""},
#line 1701 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_HN21", 1692},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1637 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_O6", 1628},
      {""}, {""}, {""}, {""}, {""},
#line 1700 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_HN1", 1691},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1675 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C1'", 1666},
      {""}, {""}, {""}, {""},
#line 1698 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_H1'", 1689},
      {""}, {""}, {""},
#line 1702 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_HN22", 1693},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1019 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HXT", 1010},
      {""},
#line 1742 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C26", 1733},
      {""},
#line 510 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_HOP3", 501},
#line 1004 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_OXT", 995},
      {""},
#line 1839 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H26", 1830},
      {""}, {""}, {""},
#line 587 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C4", 578},
#line 1743 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O26", 1734},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 219 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_C6", 210},
      {""}, {""}, {""}, {""}, {""},
#line 234 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H62", 225},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 233 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H61", 224},
#line 1897 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H84", 1888},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1680 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C6", 1671},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1681 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O6", 1672},
      {""}, {""}, {""}, {""}, {""},
#line 981 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_CA", 972},
      {""}, {""}, {""}, {""},
#line 988 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_HA", 979},
      {""}, {""}, {""},
#line 1744 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C27", 1735},
      {""}, {""}, {""}, {""},
#line 1840 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H27", 1831},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 692 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_N1", 683},
      {""}, {""}, {""}, {""}, {""},
#line 1081 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_HXT", 1072},
      {""}, {""}, {""}, {""},
#line 1074 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_OXT", 1065},
      {""}, {""},
#line 556 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_HO2'", 547},
      {""}, {""},
#line 1325 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_H7", 1316},
      {""},
#line 580 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C5", 571},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1551 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_CG", 1542},
      {""}, {""}, {""}, {""}, {""},
#line 1559 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_HG2", 1550},
      {""},
#line 1564 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_C", 1555},
      {""}, {""}, {""}, {""},
#line 1570 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_H", 1561},
      {""}, {""}, {""},
#line 554 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_HO3'", 545},
#line 1565 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_O", 1556},
      {""},
#line 562 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_HN21", 553},
#line 1558 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_HG1", 1549},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1364 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_CZ", 1355},
      {""}, {""}, {""}, {""},
#line 1375 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_HZ", 1366},
#line 1560 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_HG3", 1551},
      {""}, {""}, {""}, {""},
#line 535 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C1'", 526},
      {""}, {""}, {""}, {""},
#line 557 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_H1'", 548},
#line 702 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_HOP3", 693},
#line 1812 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C69", 1803},
      {""},
#line 563 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_HN22", 554},
      {""}, {""},
#line 1882 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H69", 1873},
      {""}, {""}, {""},
#line 987 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_H2", 978},
#line 1562 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_N", 1553},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1261 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HXT", 1252},
      {""}, {""}, {""}, {""},
#line 1249 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_OXT", 1240},
      {""}, {""}, {""},
#line 717 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_N1", 708},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 363 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_HN41", 354},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 110 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H5''", 101},
      {""}, {""}, {""}, {""},
#line 1440 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_HOP2", 1431},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 540 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C6", 531},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 364 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_HN42", 355},
      {""}, {""},
#line 541 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_O6", 532},
      {""}, {""},
#line 612 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C3'", 603},
      {""}, {""}, {""}, {""},
#line 634 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_H3'", 625},
      {""}, {""}, {""}, {""},
#line 613 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_O3'", 604},
      {""}, {""}, {""}, {""}, {""},
#line 753 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_HOP3", 744},
      {""},
#line 700 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_CM5", 691},
      {""},
#line 1798 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C60", 1789},
      {""}, {""}, {""},
#line 714 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_HM51", 705},
#line 1873 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H60", 1864},
      {""}, {""}, {""}, {""},
#line 850 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C8", 841},
      {""}, {""}, {""},
#line 1358 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_CB", 1349},
#line 869 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H8", 860},
      {""}, {""}, {""}, {""},
#line 1369 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_HB2", 1360},
      {""}, {""}, {""}, {""}, {""},
#line 677 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_HOP2", 668},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 715 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_HM52", 706},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1052 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_HXT", 1043},
      {""},
#line 1370 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_HB3", 1361},
      {""}, {""},
#line 1045 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_OXT", 1036},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 722 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C5M", 713},
      {""}, {""}, {""}, {""},
#line 1036 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_HXT", 1027},
      {""}, {""}, {""}, {""},
#line 1028 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_OXT", 1019},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1433 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_O3P", 1424},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1889 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H76", 1880},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 836 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HM73", 827},
      {""}, {""},
#line 1066 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_HXT", 1057},
      {""}, {""},
#line 584 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C2", 575},
      {""},
#line 1059 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_OXT", 1050},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1281 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_HXT", 1272},
      {""}, {""}, {""}, {""},
#line 1270 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_OXT", 1261},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 158 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_P", 149},
      {""},
#line 223 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H5''", 214},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 160 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_OP2", 151},
#line 647 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_N3", 638},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 170 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_N9", 161},
      {""},
#line 1890 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H77", 1881},
      {""}, {""}, {""},
#line 159 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_OP1", 150},
      {""}, {""}, {""}, {""}, {""},
#line 1568 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_CG2", 1559},
      {""}, {""}, {""}, {""}, {""},
#line 1577 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_HG21", 1568},
#line 1692 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_H5''", 1683},
      {""},
#line 157 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_OP3", 148},
      {""}, {""}, {""}, {""}, {""},
#line 1567 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_CG1", 1558},
      {""}, {""}, {""}, {""}, {""},
#line 1574 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_HG11", 1565},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1578 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_HG22", 1569},
      {""}, {""}, {""}, {""},
#line 1757 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C36", 1748},
      {""}, {""}, {""}, {""},
#line 1849 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H36", 1840},
      {""}, {""}, {""}, {""},
#line 1575 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_HG12", 1566},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 623 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_N1", 614},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1662 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O2B", 1653},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1169 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_HXT", 1160},
      {""}, {""}, {""}, {""},
#line 1160 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_OXT", 1151},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1550 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_CB", 1541},
      {""}, {""}, {""}, {""}, {""},
#line 1557 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_HB2", 1548},
      {""},
#line 1758 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C37", 1749},
      {""}, {""}, {""}, {""},
#line 1850 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H37", 1841},
      {""}, {""}, {""}, {""},
#line 1759 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O37", 1750},
      {""}, {""},
#line 1556 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_HB1", 1547},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 630 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_HOP3", 621},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1665 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O1A", 1656},
      {""}, {""}, {""},
#line 551 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_H5''", 542},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1172 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_C", 1163},
      {""}, {""}, {""}, {""},
#line 1179 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_H", 1170},
      {""}, {""}, {""}, {""},
#line 1173 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_O", 1164},
      {""},
#line 657 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_C4'", 648},
      {""}, {""}, {""}, {""},
#line 673 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_H4'", 664},
      {""}, {""}, {""}, {""},
#line 659 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_O4'", 650},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 852 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C5", 843},
      {""}, {""}, {""},
#line 865 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_HO3'", 856},
      {""},
#line 1170 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_N", 1161},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 842 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C5'", 833},
      {""}, {""}, {""}, {""},
#line 861 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H5'", 852},
      {""},
#line 1177 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_CD1", 1168},
      {""}, {""},
#line 841 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_O5'", 832},
      {""}, {""},
#line 1188 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HD11", 1179},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 618 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C8", 609},
      {""}, {""}, {""}, {""},
#line 639 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_H8", 630},
      {""}, {""},
#line 1189 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HD12", 1180},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 660 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_C5'", 651},
      {""}, {""}, {""}, {""},
#line 675 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_H5'", 666},
      {""}, {""}, {""}, {""},
#line 661 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_O5'", 652},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 588 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_HOP2", 579},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 495 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_C4'", 486},
      {""},
#line 579 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_N7", 570},
      {""}, {""},
#line 514 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_H4'", 505},
      {""}, {""}, {""}, {""},
#line 496 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_O4'", 487},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1728 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C18", 1719},
      {""}, {""}, {""}, {""},
#line 1831 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H18", 1822},
#line 1122 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_CA", 1113},
      {""}, {""}, {""},
#line 1729 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O18", 1720},
      {""},
#line 1128 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_HA2", 1119},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1355 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_CA", 1346},
      {""}, {""}, {""}, {""},
#line 1368 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_HA", 1359},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1129 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_HA3", 1120},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1618 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ACT_OXT", 1609},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1566 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_CB", 1557},
      {""},
#line 1689 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_HOB2", 1680},
      {""}, {""},
#line 1573 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_HB", 1564},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 586 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_N3", 577},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1127 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_H2", 1118},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 839 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_OP1", 830},
      {""}, {""},
#line 1367 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_H2", 1358},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1176 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_CG2", 1167},
      {""}, {""}, {""}, {""}, {""},
#line 1185 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HG21", 1176},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1175 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_CG1", 1166},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1802 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C64", 1793},
      {""}, {""}, {""}, {""},
#line 1877 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H64", 1868},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1186 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HG22", 1177},
      {""}, {""}, {""},
#line 602 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_HM23", 593},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1183 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HG12", 1174},
      {""}, {""}, {""}, {""},
#line 1659 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O3B", 1650},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 654 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_C2'", 645},
      {""}, {""}, {""}, {""},
#line 670 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_H2'", 661},
      {""}, {""}, {""}, {""},
#line 655 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_O2'", 646},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1900 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H88", 1891},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 508 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_C5", 499},
      {""}, {""}, {""}, {""},
#line 521 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_H5", 512},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1547 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_CA", 1538},
      {""}, {""}, {""}, {""},
#line 1555 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_HA", 1546},
      {""}, {""},
#line 709 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_HO2'", 700},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 570 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C4'", 561},
      {""}, {""}, {""}, {""},
#line 592 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_H4'", 583},
      {""}, {""}, {""}, {""},
#line 571 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_O4'", 562},
      {""}, {""}, {""},
#line 707 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_HO3'", 698},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 691 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_C1'", 682},
      {""}, {""}, {""}, {""},
#line 710 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_H1'", 701},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1554 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_H2", 1545},
      {""}, {""}, {""}, {""},
#line 746 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_HO2'", 737},
#line 1725 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C15", 1716},
      {""},
#line 976 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H71", 967},
      {""}, {""},
#line 1828 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H15", 1819},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 569 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C5'", 560},
      {""}, {""}, {""}, {""},
#line 590 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_H5'", 581},
      {""}, {""}, {""}, {""},
#line 568 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_O5'", 559},
      {""},
#line 749 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_HO3'", 740},
#line 699 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_C6", 690},
      {""}, {""}, {""}, {""},
#line 713 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_H6", 704},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 726 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C1'", 717},
      {""}, {""}, {""}, {""},
#line 744 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H1'", 735},
      {""}, {""},
#line 739 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_HN3", 730},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 853 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C6", 844},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 854 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_N6", 845},
      {""},
#line 723 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C6", 714},
      {""}, {""}, {""}, {""},
#line 743 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H6", 734},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1472 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_HXT", 1463},
      {""}, {""}, {""}, {""},
#line 1463 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_OXT", 1454},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1174 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_CB", 1165},
      {""}, {""}, {""}, {""},
#line 1182 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HB", 1173},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 851 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_N7", 842},
      {""}, {""}, {""}, {""},
#line 181 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C4", 172},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1563 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_CA", 1554},
      {""}, {""}, {""}, {""},
#line 1572 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_HA", 1563},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1899 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H85", 1890},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 656 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_C3'", 647},
      {""},
#line 574 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C2'", 565},
      {""}, {""},
#line 672 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_H3'", 663},
      {""},
#line 595 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_H2'", 586},
      {""}, {""},
#line 658 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_O3'", 649},
      {""},
#line 575 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_O2'", 566},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 174 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C5", 165},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1571 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_H2", 1562},
      {""}, {""}, {""}, {""}, {""},
#line 637 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_HO2'", 628},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 635 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_HO3'", 626},
      {""},
#line 641 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_HN2", 632},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1321 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_H1", 1312},
#line 640 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_HN1", 631},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 616 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C1'", 607},
      {""}, {""}, {""}, {""},
#line 638 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_H1'", 629},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 704 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_H5''", 695},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 621 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C6", 612},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 622 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_O6", 613},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1431 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_O1P", 1422},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 509 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_C6", 500},
      {""}, {""}, {""}, {""},
#line 522 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_H6", 513},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 751 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H5''", 742},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 645 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_N1", 636},
      {""}, {""}, {""},
#line 1441 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_HOP3", 1432},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 178 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C2", 169},
      {""}, {""}, {""}, {""}, {""},
#line 198 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H22", 189},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 197 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H21", 188},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 862 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H5''", 853},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1726 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C16", 1717},
      {""}, {""}, {""}, {""},
#line 1829 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H16", 1820},
      {""}, {""}, {""},
#line 179 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_N2", 170},
      {""},
#line 1326 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_H8", 1317},
      {""},
#line 678 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_HOP3", 669},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 716 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_HM53", 707},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1727 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C17", 1718},
      {""}, {""}, {""}, {""},
#line 1830 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H17", 1821},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1171 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_CA", 1162},
      {""}, {""}, {""}, {""},
#line 1181 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HA", 1172},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 572 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C3'", 563},
      {""}, {""}, {""}, {""},
#line 593 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_H3'", 584},
      {""}, {""}, {""}, {""},
#line 573 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_O3'", 564},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1811 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C68", 1802},
      {""}, {""}, {""}, {""},
#line 1881 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H68", 1872},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1579 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_HG23", 1570},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1576 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_HG13", 1567},
      {""},
#line 1180 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_H2", 1171},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1151 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_HXT", 1142},
      {""}, {""}, {""},
#line 632 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_H5''", 623},
#line 1141 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_OXT", 1132},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1898 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H86", 1889},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1902 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H87", 1893},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 183 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_HOP2", 174},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 172 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_N7", 163},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 494 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_C5'", 485},
      {""}, {""}, {""}, {""},
#line 512 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_H5'", 503},
      {""}, {""}, {""}, {""},
#line 493 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_O5'", 484},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 513 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_H5''", 504},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 583 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_N1", 574},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1190 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HD13", 1181},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 180 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_N3", 171},
      {""}, {""}, {""}, {""}, {""},
#line 589 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_HOP3", 580},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1661 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O1B", 1652},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1803 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C65", 1794},
      {""}, {""}, {""}, {""},
#line 1878 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H65", 1869},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1328 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_H10", 1319},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1804 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_N65", 1795},
      {""}, {""}, {""}, {""},
#line 578 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C8", 569},
      {""}, {""}, {""}, {""},
#line 598 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_H8", 589},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 163 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C4'", 154},
      {""}, {""},
#line 1187 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HG23", 1178},
      {""},
#line 186 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H4'", 177},
      {""}, {""}, {""}, {""},
#line 164 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_O4'", 155},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1184 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HG13", 1175},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 162 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C5'", 153},
      {""}, {""}, {""}, {""},
#line 184 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H5'", 175},
      {""}, {""}, {""}, {""},
#line 161 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_O5'", 152},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 871 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H62", 862},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 711 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_HN41", 702},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 712 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_HN42", 703},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1324 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_H6", 1315},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 671 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_HO2'", 662},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 674 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_HO3'", 665},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1101 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_HXT", 1092},
      {""}, {""}, {""}, {""},
#line 1091 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_OXT", 1082},
      {""},
#line 653 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_C1'", 644},
      {""}, {""}, {""}, {""},
#line 669 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_H1'", 660},
      {""}, {""},
#line 666 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_HN3", 657},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1120 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_HXT", 1111},
      {""}, {""}, {""}, {""},
#line 1111 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_OXT", 1102},
      {""}, {""}, {""}, {""},
#line 1581 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_C", 1572},
      {""}, {""}, {""}, {""},
#line 1596 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H", 1587},
#line 1601 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H9", 1592},
      {""}, {""}, {""},
#line 1582 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_O", 1573},
      {""},
#line 167 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C2'", 158},
      {""}, {""}, {""}, {""},
#line 189 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H2'", 180},
      {""}, {""}, {""}, {""},
#line 168 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_O2'", 159},
      {""},
#line 650 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_C6", 641},
      {""}, {""}, {""}, {""},
#line 668 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_H6", 659},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1584 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_N", 1575},
#line 1588 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_CD", 1579},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1589 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_NE", 1580},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1807 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C66", 1798},
      {""}, {""}, {""}, {""},
#line 1879 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H66", 1870},
      {""}, {""}, {""}, {""},
#line 1808 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O66", 1799},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1591 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_NH2", 1582},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1592 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_NH1", 1583},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1809 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C67", 1800},
      {""}, {""}, {""}, {""},
#line 1880 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H67", 1871},
      {""}, {""}, {""}, {""},
#line 1810 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O67", 1801},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1331 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_H14", 1322},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1346 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_HXT", 1337},
      {""}, {""}, {""}, {""},
#line 1338 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_OXT", 1329},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1311 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HXT", 1302},
      {""}, {""}, {""}, {""},
#line 1293 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_OXT", 1284},
      {""}, {""}, {""}, {""}, {""},
#line 1587 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_CG", 1578},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 596 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_HO2'", 587},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 594 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_HO3'", 585},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 676 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_H5''", 667},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 576 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C1'", 567},
      {""}, {""}, {""}, {""},
#line 597 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_H1'", 588},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1333 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_HXT", 1324},
      {""}, {""}, {""}, {""},
#line 1332 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_OXT", 1323},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 165 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C3'", 156},
      {""}, {""}, {""}, {""},
#line 187 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H3'", 178},
      {""}, {""}, {""}, {""},
#line 166 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_O3'", 157},
      {""}, {""}, {""},
#line 581 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C6", 572},
      {""}, {""}, {""}, {""}, {""},
#line 599 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_H62", 590},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 603 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_H61", 594},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1439 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_HXT", 1430},
      {""}, {""}, {""}, {""},
#line 1429 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_OXT", 1420},
#line 582 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_N6", 573},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1455 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_HXT", 1446},
      {""}, {""}, {""}, {""},
#line 1448 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_OXT", 1439},
      {""}, {""}, {""}, {""}, {""},
#line 1590 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_CZ", 1581},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 196 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H1", 187},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1585 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_CB", 1576},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1586 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_OB", 1577},
      {""}, {""},
#line 177 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_N1", 168},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 182 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_HOP3", 173},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 992 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_HXT", 983},
      {""}, {""}, {""}, {""},
#line 985 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_OXT", 976},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 591 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_H5''", 582},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 171 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C8", 162},
      {""}, {""}, {""}, {""},
#line 192 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H8", 183},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1597 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H5", 1588},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1583 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_CA", 1574},
      {""}, {""}, {""}, {""},
#line 1594 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_HA", 1585},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1595 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H2", 1586},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1130 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_HXT", 1121},
      {""}, {""}, {""}, {""},
#line 1125 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_OXT", 1116},
#line 870 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H61", 861},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1376 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_HXT", 1367},
      {""}, {""}, {""}, {""},
#line 1365 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_OXT", 1356},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1599 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H7", 1590},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 190 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_HO2'", 181},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 188 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_HO3'", 179},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 169 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C1'", 160},
      {""}, {""}, {""}, {""},
#line 191 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H1'", 182},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 175 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C6", 166},
      {""}, {""},
#line 1561 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_HXT", 1552},
      {""}, {""}, {""}, {""},
#line 1552 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_OXT", 1543},
      {""},
#line 176 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_O6", 167},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1580 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_HXT", 1571},
      {""}, {""}, {""}, {""},
#line 1569 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_OXT", 1560},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 185 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H5''", 176},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1191 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HXT", 1182},
      {""}, {""}, {""}, {""},
#line 1178 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_OXT", 1169},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1604 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H12", 1595},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1603 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H11", 1594},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1600 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H8", 1591},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1602 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H10", 1593},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1598 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H6", 1589},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1605 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H14", 1596},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1607 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_HXT", 1598},
      {""}, {""}, {""}, {""},
#line 1593 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_OXT", 1584},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 173 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_CN7", 164},
      {""}, {""}, {""}, {""}, {""},
#line 193 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_HN71", 184},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 194 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_HN72", 185},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1606 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H15", 1597},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 195 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_HN73", 186}
    };

  if (len <= ATOMMAX_WORD_LENGTH && len >= ATOMMIN_WORD_LENGTH)
    {
      register unsigned int key = _hash_atom (str, len);

      if (key <= ATOMMAX_HASH_VALUE)
        {
          register const char *s = wordlist[key].name;

          if (*str == *s && !strcmp (str + 1, s + 1))
            return &wordlist[key];
        }
    }
  return 0;
}
