/* ANSI-C code produced by gperf version 3.1 */
/* Command-line: /usr/bin/gperf /home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf  */
/* Computed positions: -k'1-8' */

#if !((' ' == 32) && ('!' == 33) && ('"' == 34) && ('#' == 35) \
      && ('%' == 37) && ('&' == 38) && ('\'' == 39) && ('(' == 40) \
      && (')' == 41) && ('*' == 42) && ('+' == 43) && (',' == 44) \
      && ('-' == 45) && ('.' == 46) && ('/' == 47) && ('0' == 48) \
      && ('1' == 49) && ('2' == 50) && ('3' == 51) && ('4' == 52) \
      && ('5' == 53) && ('6' == 54) && ('7' == 55) && ('8' == 56) \
      && ('9' == 57) && (':' == 58) && (';' == 59) && ('<' == 60) \
      && ('=' == 61) && ('>' == 62) && ('?' == 63) && ('A' == 65) \
      && ('B' == 66) && ('C' == 67) && ('D' == 68) && ('E' == 69) \
      && ('F' == 70) && ('G' == 71) && ('H' == 72) && ('I' == 73) \
      && ('J' == 74) && ('K' == 75) && ('L' == 76) && ('M' == 77) \
      && ('N' == 78) && ('O' == 79) && ('P' == 80) && ('Q' == 81) \
      && ('R' == 82) && ('S' == 83) && ('T' == 84) && ('U' == 85) \
      && ('V' == 86) && ('W' == 87) && ('X' == 88) && ('Y' == 89) \
      && ('Z' == 90) && ('[' == 91) && ('\\' == 92) && (']' == 93) \
      && ('^' == 94) && ('_' == 95) && ('a' == 97) && ('b' == 98) \
      && ('c' == 99) && ('d' == 100) && ('e' == 101) && ('f' == 102) \
      && ('g' == 103) && ('h' == 104) && ('i' == 105) && ('j' == 106) \
      && ('k' == 107) && ('l' == 108) && ('m' == 109) && ('n' == 110) \
      && ('o' == 111) && ('p' == 112) && ('q' == 113) && ('r' == 114) \
      && ('s' == 115) && ('t' == 116) && ('u' == 117) && ('v' == 118) \
      && ('w' == 119) && ('x' == 120) && ('y' == 121) && ('z' == 122) \
      && ('{' == 123) && ('|' == 124) && ('}' == 125) && ('~' == 126))
/* The character set is not based on ISO-646.  */
#error "gperf generated tables don't work with this execution character set. Please report a bug to <bug-gperf@gnu.org>."
#endif

#line 5 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"

#include "../codegen/lookup.h"
#line 8 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
struct _LOOKUP;

#define ATOMTOTAL_KEYWORDS 2023
#define ATOMMIN_WORD_LENGTH 3
#define ATOMMAX_WORD_LENGTH 8
#define ATOMMIN_HASH_VALUE 65
#define ATOMMAX_HASH_VALUE 17460
/* maximum key range = 17396, duplicates = 0 */

#ifdef __GNUC__
__inline
#else
#ifdef __cplusplus
inline
#endif
#endif
static unsigned int
_hash_atom (register const char *str, register size_t len)
{
  static unsigned short asso_values[] =
    {
      17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461,
      17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461,
      17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461,
      17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461,  1990,
        865, 17461, 17461, 17461, 17461, 17461, 17461, 17461,   935,    15,
          0,    30,  1777,  2118,  6526,  3907,  2382,  1427,  3886,  2883,
        345,  1885,  1833,  1940,  5416,  3577,  4776,     0,   960,  2758,
       1190,   265,     5,  3877,  1727,  1415,  1310,  3053,    50,    10,
        400,    70,   135,    25,   385,   115,  1439,   460,  4561,  3053,
        430, 17461, 17461,     0, 17461,     0,    85, 17461,   186, 17461,
        315, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461,
      17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461,
      17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461,
      17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461,
      17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461,
      17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461,
      17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461,
      17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461,
      17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461,
      17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461,
      17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461,
      17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461,
      17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461,
      17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461,
      17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461,
      17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461, 17461,
      17461, 17461, 17461, 17461, 17461, 17461
    };
  register unsigned int hval = len;

  switch (hval)
    {
      default:
        hval += asso_values[(unsigned char)str[7]+1];
      /*FALLTHROUGH*/
      case 7:
        hval += asso_values[(unsigned char)str[6]];
      /*FALLTHROUGH*/
      case 6:
        hval += asso_values[(unsigned char)str[5]+10];
      /*FALLTHROUGH*/
      case 5:
        hval += asso_values[(unsigned char)str[4]];
      /*FALLTHROUGH*/
      case 4:
        hval += asso_values[(unsigned char)str[3]];
      /*FALLTHROUGH*/
      case 3:
        hval += asso_values[(unsigned char)str[2]];
      /*FALLTHROUGH*/
      case 2:
        hval += asso_values[(unsigned char)str[1]+1];
      /*FALLTHROUGH*/
      case 1:
        hval += asso_values[(unsigned char)str[0]+3];
        break;
    }
  return hval;
}

struct _LOOKUP *
_lookup_atom (register const char *str, register size_t len)
{
  static struct _LOOKUP wordlist[] =
    {
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1501 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_C", 1492},
      {""}, {""}, {""}, {""},
#line 1507 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_H", 1498},
      {""}, {""}, {""}, {""},
#line 1502 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_O", 1493},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1499 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_N", 1490},
#line 1505 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_CD", 1496},
      {""}, {""}, {""}, {""}, {""},
#line 1513 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_HD2", 1504},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1504 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_CG", 1495},
      {""}, {""}, {""}, {""}, {""},
#line 1511 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_HG2", 1502},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1514 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_HD3", 1505},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1512 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_HG3", 1503},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 373 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_HO2'", 364},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 498 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_C", 489},
#line 524 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_C9", 515},
      {""}, {""}, {""}, {""},
#line 371 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_HO3'", 362},
#line 554 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H92", 545},
      {""}, {""},
#line 499 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_O", 490},
      {""},
#line 505 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_CE2", 496},
      {""}, {""}, {""}, {""},
#line 540 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HE2", 531},
      {""}, {""}, {""}, {""},
#line 553 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H91", 544},
      {""}, {""}, {""}, {""},
#line 504 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_CE1", 495},
      {""}, {""}, {""}, {""},
#line 539 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HE1", 530},
      {""}, {""}, {""}, {""},
#line 555 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H93", 546},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 496 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_N", 487},
#line 518 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_N9", 509},
#line 503 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_CD2", 494},
      {""}, {""}, {""}, {""},
#line 538 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HD2", 529},
      {""}, {""},
#line 1031 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C2", 1022},
      {""}, {""}, {""}, {""},
#line 1518 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_C", 1509},
      {""},
#line 502 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_CD1", 493},
      {""}, {""},
#line 1533 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_H", 1524},
#line 501 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_CG", 492},
#line 537 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HD1", 528},
      {""}, {""},
#line 1519 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_O", 1510},
#line 1022 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C2'", 1013},
#line 1526 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_CE2", 1517},
      {""}, {""},
#line 1046 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H1", 1037},
#line 1042 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H2'", 1033},
#line 1542 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HE2", 1533},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1023 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C1'", 1014},
#line 1525 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_CE1", 1516},
      {""}, {""}, {""},
#line 1044 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H1'", 1035},
#line 1541 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HE1", 1532},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1020 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C3'", 1011},
      {""}, {""}, {""},
#line 1032 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_N2", 1023},
#line 1040 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H3'", 1031},
      {""}, {""}, {""},
#line 1516 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_N", 1507},
#line 1021 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_O3'", 1012},
#line 1524 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_CD2", 1515},
      {""}, {""}, {""}, {""},
#line 1540 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HD2", 1531},
      {""}, {""},
#line 1030 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_N1", 1021},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1523 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_CD1", 1514},
      {""}, {""}, {""},
#line 1522 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_CG", 1513},
#line 1539 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HD1", 1530},
      {""}, {""},
#line 1033 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_N3", 1024},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1062 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C2", 1053},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1063 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_O2", 1054},
      {""}, {""}, {""}, {""}, {""},
#line 1059 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C2'", 1050},
      {""}, {""}, {""}, {""},
#line 1077 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H2'", 1068},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1060 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C1'", 1051},
      {""}, {""}, {""},
#line 1080 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H3", 1071},
#line 1079 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H1'", 1070},
      {""}, {""}, {""}, {""},
#line 1528 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_OH", 1519},
      {""}, {""}, {""}, {""},
#line 1057 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C3'", 1048},
      {""}, {""}, {""}, {""},
#line 1075 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H3'", 1066},
      {""}, {""}, {""}, {""},
#line 1058 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_O3'", 1049},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1061 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_N1", 1052},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1064 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_N3", 1055},
      {""}, {""}, {""}, {""},
#line 1321 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_C", 1312},
      {""}, {""}, {""}, {""},
#line 1329 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_H", 1320},
      {""}, {""}, {""}, {""},
#line 1322 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_O", 1313},
#line 1326 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_CE", 1317},
      {""}, {""}, {""}, {""}, {""},
#line 1338 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HE2", 1329},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1737 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ZN_ZN", 1728},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 428 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_N9", 419},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1339 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HE3", 1330},
      {""}, {""},
#line 1319 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_N", 1310},
#line 1325 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_CD", 1316},
      {""}, {""}, {""}, {""}, {""},
#line 1336 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HD2", 1327},
      {""}, {""}, {""},
#line 506 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_CZ", 497},
      {""}, {""}, {""}, {""},
#line 377 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_C2", 368},
      {""}, {""}, {""}, {""},
#line 1324 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_CG", 1315},
      {""}, {""}, {""},
#line 1604 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_C", 1595},
#line 382 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_O2", 373},
#line 1334 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HG2", 1325},
      {""}, {""},
#line 1607 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_H", 1598},
      {""}, {""}, {""}, {""},
#line 1605 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_O", 1596},
      {""},
#line 1337 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HD3", 1328},
#line 353 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_P", 344},
      {""}, {""},
#line 527 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_C2", 518},
      {""}, {""}, {""}, {""},
#line 559 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H2", 550},
      {""}, {""}, {""},
#line 355 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_OP2", 346},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1335 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HG3", 1326},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 354 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_OP1", 345},
      {""}, {""}, {""}, {""},
#line 394 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_P", 385},
      {""}, {""}, {""}, {""},
#line 1595 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_N", 1586},
#line 1527 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_CZ", 1518},
      {""}, {""}, {""},
#line 352 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_OP3", 343},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 492 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_P", 483},
      {""},
#line 1598 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_CG2", 1589},
      {""}, {""}, {""}, {""}, {""},
#line 1611 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_HG21", 1602},
      {""}, {""},
#line 1048 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H22", 1039},
      {""}, {""}, {""}, {""},
#line 1534 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_H2", 1525},
#line 396 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_OP2", 387},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1599 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_OG1", 1590},
#line 1515 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_HXT", 1506},
      {""}, {""}, {""},
#line 395 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_OP1", 386},
#line 1506 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_OXT", 1497},
      {""}, {""},
#line 456 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_C2", 447},
#line 387 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_CM2", 378},
#line 1612 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_HG22", 1603},
      {""}, {""}, {""},
#line 494 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_OP2", 485},
#line 404 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_HM21", 395},
      {""}, {""},
#line 461 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_O2", 452},
#line 397 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_OP3", 388},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 493 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_OP1", 484},
      {""},
#line 1013 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_P", 1004},
      {""},
#line 508 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_CM", 499},
      {""}, {""}, {""},
#line 1529 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_P", 1520},
      {""},
#line 542 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HM2", 533},
      {""}, {""}, {""}, {""},
#line 495 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_OP3", 486},
#line 405 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_HM22", 396},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 541 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HM1", 532},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 473 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_P", 464},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 543 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HM3", 534},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1036 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_HOP2", 1027},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 475 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_OP2", 466},
      {""}, {""}, {""},
#line 321 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_N9", 312},
#line 1035 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_HOP3", 1026},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 474 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_OP1", 465},
      {""}, {""}, {""}, {""},
#line 466 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_CM2", 457},
      {""}, {""}, {""}, {""}, {""},
#line 482 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_HM21", 473},
      {""}, {""}, {""},
#line 476 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_OP3", 467},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1050 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_P", 1041},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1341 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HZ2", 1332},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 435 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C2", 426},
      {""},
#line 483 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_HM22", 474},
      {""}, {""}, {""},
#line 1340 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HZ1", 1331},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1330 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_H2", 1321},
#line 1342 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HZ3", 1333},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1071 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_HOP2", 1062},
      {""}, {""}, {""},
#line 1327 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_NZ", 1318},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 436 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_N2", 427},
      {""}, {""}, {""},
#line 414 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_P", 405},
      {""}, {""},
#line 1536 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HXT", 1527},
      {""}, {""}, {""},
#line 1070 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_HOP3", 1061},
#line 1520 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_OXT", 1511},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 561 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_C2", 552},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 566 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_O2", 557},
      {""}, {""}, {""},
#line 1619 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_C", 1610},
      {""}, {""}, {""}, {""},
#line 1632 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_H", 1623},
#line 1608 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_H2", 1599},
#line 416 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_OP2", 407},
      {""}, {""},
#line 1620 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_O", 1611},
      {""},
#line 1626 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CE2", 1617},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 415 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_OP1", 406},
      {""}, {""}, {""}, {""},
#line 426 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_CM2", 417},
      {""}, {""}, {""},
#line 366 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_HOP2", 357},
#line 1638 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HE1", 1629},
#line 447 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_HM21", 438},
      {""}, {""}, {""},
#line 417 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_OP3", 408},
      {""}, {""},
#line 577 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_P", 568},
      {""},
#line 1627 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CE3", 1618},
      {""}, {""}, {""}, {""},
#line 1639 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HE3", 1630},
      {""}, {""},
#line 1617 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_N", 1608},
      {""},
#line 1624 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CD2", 1615},
      {""}, {""},
#line 1600 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_P", 1591},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 448 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_HM22", 439},
      {""}, {""}, {""},
#line 1623 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CD1", 1614},
      {""}, {""}, {""},
#line 1622 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CG", 1613},
#line 1637 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HD1", 1628},
      {""}, {""}, {""}, {""},
#line 1625 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_NE1", 1616},
      {""}, {""}, {""}, {""},
#line 579 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_OP2", 570},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 578 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_OP1", 569},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 580 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_OP3", 571},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1630 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CH2", 1621},
      {""}, {""},
#line 1646 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_C", 1637},
#line 1015 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_OP2", 1006},
#line 1642 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HH2", 1633},
      {""}, {""},
#line 1657 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_H", 1648},
      {""},
#line 1531 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_O2P", 1522},
      {""}, {""},
#line 1647 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_O", 1638},
      {""},
#line 1653 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_CE2", 1644},
      {""}, {""}, {""},
#line 328 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C2", 319},
#line 1665 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_HE2", 1656},
#line 1343 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HXT", 1334},
#line 30 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C2", 21},
      {""}, {""}, {""},
#line 1328 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_OXT", 1319},
#line 46 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H2", 37},
      {""}, {""},
#line 1652 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_CE1", 1643},
      {""}, {""}, {""}, {""},
#line 1664 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_HE1", 1655},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1644 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_N", 1635},
#line 41 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_HO2'", 32},
#line 1651 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_CD2", 1642},
      {""}, {""}, {""}, {""},
#line 1663 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_HD2", 1654},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 329 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_N2", 320},
#line 1650 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_CD1", 1641},
      {""}, {""},
#line 308 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_P", 299},
#line 1649 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_CG", 1640},
#line 1662 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_HD1", 1653},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 39 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_HO3'", 30},
      {""}, {""},
#line 29 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_N1", 20},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1616 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_HXT", 1607},
      {""},
#line 1463 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_C", 1454},
      {""}, {""},
#line 1606 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_OXT", 1597},
#line 31 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_N3", 22},
#line 1469 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_H", 1460},
      {""}, {""}, {""}, {""},
#line 1464 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_O", 1455},
      {""}, {""}, {""}, {""}, {""},
#line 1052 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_OP2", 1043},
#line 310 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_OP2", 301},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 309 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_OP1", 300},
      {""}, {""}, {""}, {""},
#line 333 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_CM2", 324},
      {""}, {""}, {""}, {""}, {""},
#line 349 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HM21", 340},
      {""}, {""},
#line 1666 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_HH", 1657},
#line 311 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_OP3", 302},
      {""}, {""},
#line 1459 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_N", 1450},
#line 1655 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_OH", 1646},
#line 332 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_CM1", 323},
      {""}, {""}, {""}, {""},
#line 1475 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_HD2", 1466},
#line 346 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HM11", 337},
      {""}, {""}, {""},
#line 1467 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_OD2", 1458},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 350 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HM22", 341},
      {""}, {""}, {""},
#line 1466 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_OD1", 1457},
      {""}, {""}, {""}, {""},
#line 1628 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CZ2", 1619},
      {""}, {""}, {""}, {""},
#line 1640 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HZ2", 1631},
#line 347 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HM12", 338},
      {""}, {""}, {""},
#line 1468 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_OD3", 1459},
      {""}, {""}, {""},
#line 1462 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_SG", 1453},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 991 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_C2", 982},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1629 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CZ3", 1620},
      {""}, {""},
#line 992 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_O2", 983},
#line 1633 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_H2", 1624},
#line 1641 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HZ3", 1632},
      {""}, {""}, {""},
#line 988 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_C2'", 979},
      {""}, {""}, {""}, {""},
#line 1005 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H2'", 996},
      {""}, {""}, {""},
#line 1100 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_C", 1091},
      {""}, {""}, {""}, {""},
#line 1110 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_H", 1101},
#line 989 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_C1'", 980},
      {""}, {""}, {""},
#line 1101 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_O", 1092},
#line 1007 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H1'", 998},
      {""}, {""}, {""}, {""},
#line 1119 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HE", 1110},
      {""}, {""}, {""}, {""},
#line 986 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_C3'", 977},
      {""}, {""},
#line 61 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_C2", 52},
      {""},
#line 1003 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H3'", 994},
      {""}, {""}, {""}, {""},
#line 987 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_O3'", 978},
      {""}, {""},
#line 62 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_O2", 53},
      {""}, {""}, {""}, {""}, {""},
#line 990 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_N1", 981},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1602 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_O2P", 1593},
      {""}, {""},
#line 1098 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_N", 1089},
#line 1104 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_CD", 1095},
      {""}, {""}, {""},
#line 993 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_N3", 984},
#line 76 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_HO2'", 67},
#line 1117 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HD2", 1108},
      {""}, {""}, {""},
#line 1105 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_NE", 1096},
      {""}, {""}, {""},
#line 1299 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_C", 1290},
      {""}, {""}, {""}, {""},
#line 1306 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_H", 1297},
#line 1103 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_CG", 1094},
      {""}, {""}, {""},
#line 1300 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_O", 1291},
      {""},
#line 1115 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HG2", 1106},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 74 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_HO3'", 65},
#line 1118 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HD3", 1109},
      {""},
#line 60 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_N1", 51},
      {""},
#line 1654 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_CZ", 1645},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 63 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_N3", 54},
      {""}, {""},
#line 1116 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HG3", 1107},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1297 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_N", 1288},
      {""},
#line 1304 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_CD2", 1295},
      {""}, {""}, {""},
#line 1503 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_CB", 1494},
      {""},
#line 1315 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HD21", 1306},
      {""}, {""},
#line 1658 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_H2", 1649},
#line 1509 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_HB2", 1500},
      {""}, {""}, {""}, {""},
#line 1303 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_CD1", 1294},
      {""}, {""}, {""},
#line 1302 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_CG", 1293},
      {""},
#line 1312 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HD11", 1303},
      {""}, {""},
#line 1311 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HG", 1302},
      {""},
#line 1122 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HH21", 1113},
#line 292 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C2", 283},
#line 1127 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_C", 1118},
      {""}, {""}, {""},
#line 307 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_H2", 298},
#line 1134 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_H", 1125},
      {""}, {""},
#line 1316 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HD22", 1307},
      {""},
#line 1128 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_O", 1119},
      {""},
#line 1510 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_HB3", 1501},
#line 1120 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HH11", 1111},
      {""}, {""}, {""}, {""}, {""},
#line 306 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_H1", 297},
      {""}, {""}, {""},
#line 1313 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HD12", 1304},
      {""}, {""}, {""}, {""},
#line 1123 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HH22", 1114},
      {""}, {""},
#line 303 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_HO2'", 294},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1108 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_NH2", 1099},
#line 1121 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HH12", 1112},
      {""}, {""}, {""}, {""},
#line 11 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_P", 2},
      {""},
#line 1125 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_N", 1116},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1107 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_NH1", 1098},
#line 1139 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_HD21", 1130},
      {""},
#line 13 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_OP2", 4},
#line 301 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_HO3'", 292},
      {""}, {""},
#line 291 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_N1", 282},
      {""}, {""}, {""},
#line 1643 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HXT", 1634},
      {""}, {""},
#line 1130 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_CG", 1121},
      {""},
#line 1631 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_OXT", 1622},
      {""},
#line 12 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_OP1", 3},
#line 1470 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_H2", 1461},
#line 1131 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_OD1", 1122},
      {""},
#line 293 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_N3", 284},
      {""},
#line 1500 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_CA", 1491},
      {""}, {""}, {""}, {""},
#line 1508 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PRO_HA", 1499},
      {""},
#line 1140 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_HD22", 1131},
      {""},
#line 10 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_OP3", 1},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1132 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_ND2", 1123},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 500 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_CB", 491},
      {""}, {""}, {""}, {""}, {""},
#line 536 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HB2", 527},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 535 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HB1", 526},
      {""}, {""}, {""}, {""}, {""},
#line 1734 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"K_K", 1725},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1106 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_CZ", 1097},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1162 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_C", 1153},
#line 1521 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_CB", 1512},
      {""}, {""}, {""},
#line 1166 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_H", 1157},
      {""},
#line 1537 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HB2", 1528},
      {""}, {""},
#line 1163 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_O", 1154},
      {""}, {""}, {""}, {""},
#line 1733 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CS_CS", 1724},
#line 1111 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_H2", 1102},
      {""},
#line 1667 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_HXT", 1658},
      {""}, {""}, {""}, {""},
#line 1656 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_OXT", 1647},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1538 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HB3", 1529},
      {""},
#line 979 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_P", 970},
      {""},
#line 497 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_CA", 488},
      {""}, {""}, {""}, {""},
#line 534 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HA", 525},
      {""}, {""}, {""},
#line 1158 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_N", 1149},
      {""}, {""}, {""}, {""}, {""},
#line 1172 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_HD", 1163},
      {""}, {""}, {""},
#line 1175 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_C", 1166},
#line 1165 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_OD", 1156},
      {""}, {""}, {""},
#line 1180 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_H", 1171},
      {""}, {""}, {""}, {""},
#line 1176 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_O", 1167},
      {""}, {""}, {""}, {""},
#line 1352 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_C", 1343},
      {""}, {""}, {""}, {""},
#line 1355 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_H", 1346},
#line 1307 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_H2", 1298},
      {""}, {""}, {""},
#line 1353 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_O", 1344},
#line 1351 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_CE", 1342},
#line 999 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_HOP2", 990},
#line 48 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_P", 39},
      {""}, {""}, {""},
#line 1364 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HE2", 1355},
#line 1362 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HE21", 1353},
      {""}, {""},
#line 1161 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_SG", 1152},
      {""}, {""}, {""},
#line 50 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_OP2", 41},
      {""}, {""}, {""}, {""}, {""},
#line 1517 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_CA", 1508},
#line 1363 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HE1", 1354},
      {""}, {""},
#line 1173 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_N", 1164},
#line 1535 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HA", 1526},
#line 1349 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_OE1", 1340},
#line 1474 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_HXT", 1465},
      {""},
#line 49 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_OP1", 40},
      {""},
#line 998 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_HOP3", 989},
#line 1465 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_OXT", 1456},
      {""}, {""}, {""},
#line 1365 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HE3", 1356},
      {""}, {""},
#line 1344 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_N", 1335},
#line 1348 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_CD", 1339},
      {""}, {""}, {""},
#line 47 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_OP3", 38},
      {""}, {""}, {""}, {""}, {""},
#line 1185 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_HG", 1176},
#line 1350 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_NE2", 1341},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1347 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_CG", 1338},
      {""}, {""}, {""}, {""}, {""},
#line 1360 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HG2", 1351},
      {""}, {""}, {""},
#line 1178 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_SG", 1169},
      {""}, {""}, {""},
#line 1144 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_C", 1135},
#line 1135 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_H2", 1126},
#line 1024 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_N9", 1015},
      {""}, {""},
#line 1151 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_H", 1142},
      {""}, {""}, {""}, {""},
#line 1145 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_O", 1136},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1361 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HG3", 1352},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1323 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_CB", 1314},
      {""}, {""}, {""}, {""}, {""},
#line 1332 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HB2", 1323},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 273 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_P", 264},
      {""},
#line 1142 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_N", 1133},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1156 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_HD2", 1147},
      {""}, {""},
#line 275 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_OP2", 266},
#line 34 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_HOP2", 25},
#line 1149 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_OD2", 1140},
      {""}, {""}, {""},
#line 176 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C2", 167},
#line 1333 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HB3", 1324},
      {""}, {""}, {""},
#line 1147 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_CG", 1138},
#line 193 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H22", 184},
      {""}, {""},
#line 274 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_OP1", 265},
      {""},
#line 1148 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_OD1", 1139},
      {""}, {""}, {""}, {""}, {""},
#line 1124 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HXT", 1115},
      {""},
#line 1730 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HOH_O", 1721},
#line 191 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H1", 182},
#line 192 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H21", 183},
#line 1109 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_OXT", 1100},
      {""},
#line 272 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_OP3", 263},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 188 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_HO2'", 179},
      {""}, {""}, {""}, {""},
#line 1944 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H9", 1935},
#line 2027 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H92", 2018},
      {""},
#line 1597 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_CB", 1588},
      {""}, {""}, {""}, {""},
#line 1610 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_HB", 1601},
      {""}, {""}, {""}, {""},
#line 177 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_N2", 168},
      {""}, {""},
#line 2025 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H91", 2016},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 186 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_HO3'", 177},
      {""}, {""},
#line 175 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_N1", 166},
      {""}, {""},
#line 2030 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H93", 2021},
      {""},
#line 1320 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_CA", 1311},
      {""}, {""}, {""}, {""},
#line 1331 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LYS_HA", 1322},
      {""}, {""}, {""}, {""},
#line 178 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_N3", 169},
      {""},
#line 1318 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HXT", 1309},
      {""}, {""}, {""}, {""},
#line 1305 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_OXT", 1296},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 250 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_C2", 241},
      {""},
#line 869 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C9", 860},
      {""}, {""}, {""}, {""},
#line 898 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H9", 889},
      {""},
#line 887 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H9C1", 878},
#line 251 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_O2", 242},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1167 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_H2", 1158},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 888 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H9C2", 879},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1596 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_CA", 1587},
      {""},
#line 864 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_N9", 855},
      {""},
#line 236 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_P", 227},
#line 1609 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_HA", 1600},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1141 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_HXT", 1132},
      {""},
#line 1369 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_C", 1360},
      {""}, {""},
#line 1133 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_OXT", 1124},
      {""},
#line 1376 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_H", 1367},
#line 981 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_OP2", 972},
      {""}, {""}, {""},
#line 1370 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_O", 1361},
#line 1374 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_CE", 1365},
      {""}, {""}, {""}, {""}, {""},
#line 1384 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_HE2", 1375},
      {""}, {""}, {""},
#line 1181 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_H2", 1172},
      {""}, {""}, {""}, {""}, {""},
#line 238 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_OP2", 229},
      {""}, {""}, {""}, {""},
#line 1383 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_HE1", 1374},
      {""}, {""}, {""},
#line 1356 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_H2", 1347},
      {""}, {""}, {""}, {""}, {""},
#line 237 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_OP1", 228},
      {""},
#line 379 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_C4", 370},
      {""}, {""},
#line 1385 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_HE3", 1376},
      {""}, {""},
#line 1367 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_N", 1358},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 239 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_OP3", 230},
      {""}, {""}, {""},
#line 69 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_HOP2", 60},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 528 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_C4", 519},
      {""},
#line 1372 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_CG", 1363},
#line 1034 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C4", 1025},
      {""}, {""}, {""},
#line 1373 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_SD", 1364},
#line 1381 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_HG2", 1372},
#line 1750 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_N9", 1741},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1018 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C4'", 1009},
      {""}, {""}, {""}, {""},
#line 1039 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H4'", 1030},
#line 383 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_N4", 374},
      {""}, {""}, {""},
#line 1019 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_O4'", 1010},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1382 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_HG3", 1373},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1152 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_H2", 1143},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 378 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_N3", 369},
      {""}, {""}, {""}, {""},
#line 380 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_C5", 371},
      {""}, {""}, {""}, {""},
#line 398 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_H5", 389},
      {""}, {""},
#line 458 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_C4", 449},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 641 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_N9", 632},
#line 462 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_O4", 453},
#line 362 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_C2'", 353},
#line 529 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_N3", 520},
      {""}, {""}, {""},
#line 372 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_H2'", 363},
#line 521 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_C5", 512},
      {""}, {""}, {""},
#line 363 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_O2'", 354},
#line 296 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_HOP2", 287},
#line 1065 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C4", 1056},
      {""}, {""},
#line 364 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_C1'", 355},
      {""}, {""},
#line 1171 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_HXT", 1162},
      {""},
#line 374 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_H1'", 365},
      {""},
#line 1066 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_O4", 1057},
#line 1164 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_OXT", 1155},
      {""}, {""},
#line 1732 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HOH_H2", 1723},
      {""},
#line 1055 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C4'", 1046},
      {""},
#line 360 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_C3'", 351},
      {""}, {""},
#line 1074 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H4'", 1065},
      {""},
#line 370 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_H3'", 361},
      {""}, {""},
#line 1056 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_O4'", 1047},
      {""},
#line 361 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_O3'", 352},
      {""}, {""}, {""},
#line 1857 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C22", 1848},
      {""}, {""}, {""},
#line 1937 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H2", 1928},
#line 1957 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H22", 1948},
      {""},
#line 1621 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CB", 1612},
      {""}, {""}, {""}, {""}, {""},
#line 1635 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HB2", 1626},
      {""},
#line 1856 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C21", 1847},
      {""}, {""}, {""}, {""},
#line 1956 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H21", 1947},
#line 157 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_P", 148},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1858 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C23", 1849},
      {""}, {""},
#line 159 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_OP2", 150},
#line 1186 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_HXT", 1177},
#line 1958 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H23", 1949},
      {""}, {""}, {""},
#line 1179 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_OXT", 1170},
#line 1859 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O23", 1850},
      {""}, {""},
#line 1636 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HB3", 1627},
      {""}, {""}, {""},
#line 457 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_N3", 448},
#line 158 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_OP1", 149},
#line 1366 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HXT", 1357},
      {""}, {""},
#line 459 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_C5", 450},
      {""},
#line 1354 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_OXT", 1345},
      {""},
#line 1259 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_C", 1250},
#line 478 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_H5", 469},
      {""}, {""}, {""},
#line 1266 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_H", 1257},
      {""},
#line 156 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_OP3", 147},
#line 859 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C2", 850},
      {""},
#line 1260 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_O", 1251},
      {""}, {""},
#line 883 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H2", 874},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1043 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H2''", 1034},
      {""},
#line 438 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C4", 429},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1798 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_N9", 1789},
      {""},
#line 1257 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_N", 1248},
#line 1263 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_CD", 1254},
      {""}, {""}, {""}, {""},
#line 1618 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_CA", 1609},
      {""}, {""}, {""},
#line 1738 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ACT_C", 1729},
#line 1634 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TRP_HA", 1625},
#line 881 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_P", 872},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1739 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ACT_O", 1730},
#line 1262 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_CG", 1253},
#line 1273 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_HD1", 1264},
      {""}, {""}, {""},
#line 1270 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_HG", 1261},
#line 1264 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_OD1", 1255},
#line 1157 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_HXT", 1148},
      {""}, {""},
#line 1377 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_H2", 1368},
      {""},
#line 1150 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_OXT", 1141},
      {""}, {""}, {""}, {""},
#line 1271 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_HD22", 1262},
      {""}, {""},
#line 1648 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_CB", 1639},
      {""}, {""}, {""}, {""}, {""},
#line 1660 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_HB2", 1651},
      {""}, {""}, {""}, {""}, {""},
#line 1756 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C2", 1747},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 563 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_C4", 554},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 567 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_O4", 558},
      {""}, {""},
#line 1661 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_HB3", 1652},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 437 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_N3", 428},
      {""},
#line 1027 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C5", 1018},
      {""}, {""},
#line 431 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C5", 422},
#line 1078 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H2''", 1069},
      {""}, {""},
#line 1613 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_HG23", 1604},
      {""}, {""},
#line 1760 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_N2", 1751},
      {""}, {""}, {""}, {""}, {""},
#line 1017 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C5'", 1008},
      {""}, {""}, {""}, {""},
#line 1037 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H5'", 1028},
      {""}, {""}, {""}, {""},
#line 1016 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_O5'", 1007},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 406 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_HM23", 397},
#line 1461 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_CB", 1452},
      {""}, {""}, {""}, {""}, {""},
#line 1472 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_HB2", 1463},
#line 649 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C2", 640},
      {""}, {""},
#line 1645 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_CA", 1636},
      {""}, {""}, {""}, {""},
#line 1659 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TYR_HA", 1650},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 365 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_HOP3", 356},
      {""}, {""}, {""}, {""},
#line 562 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_N3", 553},
      {""}, {""}, {""}, {""},
#line 564 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_C5", 555},
#line 1473 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_HB3", 1464},
      {""}, {""}, {""}, {""},
#line 1741 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ACT_CH3", 1732},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 722 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_N9", 713},
      {""}, {""}, {""},
#line 650 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_N2", 641},
      {""}, {""}, {""},
#line 628 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_P", 619},
      {""}, {""}, {""},
#line 99 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_C2", 90},
      {""},
#line 1067 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C5", 1058},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 100 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_O2", 91},
#line 84 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_O2C", 75},
      {""}, {""}, {""},
#line 375 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_H1'2", 366},
      {""}, {""},
#line 1054 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C5'", 1045},
      {""}, {""}, {""}, {""},
#line 1072 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H5'", 1063},
      {""},
#line 23 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_N9", 14},
#line 385 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_C2'", 376},
      {""},
#line 1053 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_O5'", 1044},
      {""}, {""},
#line 403 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_H2'", 394},
      {""},
#line 331 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C4", 322},
      {""}, {""},
#line 386 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_O2'", 377},
      {""},
#line 630 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_OP2", 621},
      {""},
#line 1460 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_CA", 1451},
      {""}, {""}, {""}, {""},
#line 1471 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OCS_HA", 1462},
      {""}, {""}, {""},
#line 484 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_HM23", 475},
      {""},
#line 515 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_C2'", 506},
      {""},
#line 629 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_OP1", 620},
#line 85 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_P", 76},
      {""},
#line 549 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H2'", 540},
#line 1386 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_HXT", 1377},
      {""}, {""}, {""},
#line 516 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_O2'", 507},
#line 1375 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_OXT", 1366},
      {""}, {""},
#line 1102 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_CB", 1093},
      {""}, {""},
#line 631 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_OP3", 622},
      {""},
#line 1012 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_OP3", 1003},
#line 1113 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HB2", 1104},
      {""},
#line 648 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_CM1", 639},
      {""}, {""},
#line 1532 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_O3P", 1523},
#line 181 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_HOP2", 172},
      {""},
#line 664 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_HM11", 655},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1805 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C2", 1796},
      {""}, {""}, {""},
#line 87 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_OP2", 78},
      {""}, {""}, {""}, {""},
#line 1114 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HB3", 1105},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 665 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_HM12", 656},
      {""},
#line 86 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_OP1", 77},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 88 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_OP3", 79},
      {""}, {""}, {""},
#line 1301 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_CB", 1292},
      {""}, {""}, {""}, {""},
#line 330 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_N3", 321},
#line 1309 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HB2", 1300},
      {""}, {""}, {""},
#line 324 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C5", 315},
#line 464 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_C2'", 455},
#line 1806 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_N2", 1797},
      {""}, {""}, {""},
#line 481 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_H2'", 472},
      {""}, {""}, {""}, {""},
#line 465 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_O2'", 456},
      {""}, {""}, {""}, {""},
#line 1025 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C8", 1016},
      {""}, {""}, {""},
#line 1743 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ACT_H2", 1734},
#line 1045 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H8", 1036},
      {""}, {""}, {""}, {""},
#line 1310 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HB3", 1301},
      {""},
#line 863 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_O2P", 854},
      {""},
#line 1099 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_CA", 1090},
      {""}, {""}, {""}, {""},
#line 1112 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ARG_HA", 1103},
      {""}, {""}, {""}, {""},
#line 1049 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_OP3", 1040},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 449 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_HM23", 440},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1129 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_CB", 1120},
      {""}, {""}, {""}, {""}, {""},
#line 1137 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_HB2", 1128},
#line 1777 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_PG", 1768},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1298 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_CA", 1289},
      {""}, {""}, {""}, {""},
#line 1308 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HA", 1299},
      {""}, {""}, {""}, {""}, {""},
#line 1138 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_HB3", 1129},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1566 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_C", 1557},
      {""}, {""}, {""}, {""},
#line 1571 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_H", 1562},
      {""}, {""}, {""}, {""},
#line 1567 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_O", 1558},
      {""}, {""}, {""},
#line 798 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_C2", 789},
#line 729 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C2", 720},
      {""}, {""}, {""}, {""},
#line 2023 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H90", 2014},
      {""}, {""},
#line 424 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C2'", 415},
#line 799 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_O2", 790},
      {""}, {""}, {""},
#line 446 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_H2'", 437},
      {""}, {""}, {""}, {""},
#line 425 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_O2'", 416},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1126 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_CA", 1117},
      {""}, {""},
#line 1564 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_N", 1555},
      {""},
#line 1136 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASN_HA", 1127},
      {""}, {""}, {""}, {""},
#line 32 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C4", 23},
      {""},
#line 1274 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_HXT", 1265},
      {""}, {""}, {""}, {""},
#line 1265 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_OXT", 1256},
#line 730 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_N2", 721},
      {""}, {""},
#line 784 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_P", 775},
#line 709 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_P", 700},
      {""}, {""}, {""},
#line 1603 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_O3P", 1594},
      {""}, {""},
#line 1576 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_HG", 1567},
      {""}, {""}, {""}, {""},
#line 1569 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_OG", 1560},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 569 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_C2'", 560},
      {""},
#line 1779 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O2G", 1770},
      {""}, {""},
#line 585 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_H2'", 576},
      {""}, {""}, {""},
#line 285 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_N9", 276},
#line 570 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_O2'", 561},
      {""},
#line 786 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_OP2", 777},
#line 711 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_OP2", 702},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1740 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ACT_OXT", 1731},
#line 785 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_OP1", 776},
#line 710 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_OP1", 701},
      {""}, {""},
#line 823 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C2", 814},
      {""},
#line 731 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_CM2", 722},
#line 1160 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_CB", 1151},
      {""}, {""}, {""}, {""},
#line 747 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_HM21", 738},
#line 1169 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_HB2", 1160},
#line 829 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_O2", 820},
#line 787 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_OP3", 778},
#line 712 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_OP3", 703},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 748 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_HM22", 739},
#line 1170 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_HB3", 1161},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 351 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HM23", 342},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 840 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_P", 831},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 348 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HM13", 339},
#line 1177 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_CB", 1168},
      {""}, {""}, {""}, {""}, {""},
#line 1183 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_HB2", 1174},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1346 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_CB", 1337},
      {""}, {""}, {""}, {""}, {""},
#line 1358 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HB2", 1349},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 842 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_OP2", 833},
      {""}, {""},
#line 1184 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_HB3", 1175},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1159 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_CA", 1150},
#line 994 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_C4", 985},
      {""},
#line 841 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_OP1", 832},
      {""},
#line 1168 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CSO_HA", 1159},
#line 1359 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HB3", 1350},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 984 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_C4'", 975},
#line 843 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_OP3", 834},
      {""}, {""}, {""},
#line 1002 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H4'", 993},
      {""}, {""}, {""}, {""},
#line 985 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_O4'", 976},
#line 1549 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_C", 1540},
      {""}, {""},
#line 318 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C2'", 309},
      {""},
#line 1556 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_H", 1547},
#line 20 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C2'", 11},
      {""},
#line 341 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_H2'", 332},
      {""},
#line 1550 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_O", 1541},
#line 40 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H2'", 31},
      {""},
#line 319 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_O2'", 310},
      {""}, {""},
#line 21 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_O2'", 12},
      {""}, {""}, {""}, {""},
#line 22 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C1'", 13},
#line 64 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_C4", 55},
#line 995 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_N4", 986},
      {""}, {""},
#line 42 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H1'", 33},
#line 1146 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_CB", 1137},
#line 79 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H42", 70},
      {""}, {""}, {""},
#line 1174 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_CA", 1165},
#line 1154 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_HB2", 1145},
      {""}, {""},
#line 18 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C3'", 9},
#line 1182 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CYS_HA", 1173},
      {""}, {""}, {""},
#line 38 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H3'", 29},
      {""},
#line 78 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H41", 69},
      {""}, {""},
#line 19 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_O3'", 10},
#line 1345 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_CA", 1336},
      {""}, {""},
#line 1545 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_N", 1536},
      {""},
#line 1357 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MEQ_HA", 1348},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1155 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_HB3", 1146},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 65 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_N4", 56},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1548 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_OG", 1539},
      {""}, {""}, {""}, {""},
#line 1572 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_H2", 1563},
      {""}, {""}, {""},
#line 376 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_N1", 367},
      {""}, {""}, {""}, {""},
#line 1854 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C20", 1845},
      {""}, {""}, {""}, {""},
#line 1955 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H20", 1946},
      {""}, {""}, {""}, {""},
#line 1855 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O20", 1846},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 526 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_N1", 517},
      {""}, {""}, {""}, {""}, {""},
#line 1317 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HD23", 1308},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1047 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H21", 1038},
      {""},
#line 1143 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_CA", 1134},
#line 26 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C5", 17},
      {""}, {""},
#line 1314 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"LEU_HD13", 1305},
#line 1153 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ASP_HA", 1144},
#line 1238 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_C", 1229},
      {""}, {""}, {""},
#line 294 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C4", 285},
#line 1247 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_H", 1238},
      {""}, {""}, {""}, {""},
#line 1239 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_O", 1230},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1255 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_HE2", 1246},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1244 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_CE1", 1235},
      {""}, {""}, {""}, {""},
#line 1254 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_HE1", 1245},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1236 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_N", 1227},
      {""},
#line 1243 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_CD2", 1234},
      {""}, {""}, {""},
#line 895 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_HB", 886},
#line 1253 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_HD2", 1244},
      {""}, {""}, {""}, {""},
#line 1245 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_NE2", 1236},
      {""}, {""}, {""}, {""},
#line 455 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_N1", 446},
      {""}, {""},
#line 1006 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H2''", 997},
#line 1241 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_CG", 1232},
#line 1252 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_HD1", 1243},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 57 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_C2'", 48},
      {""}, {""}, {""}, {""},
#line 75 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H2'", 66},
      {""}, {""}, {""},
#line 507 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_OC", 498},
#line 58 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_O2'", 49},
      {""}, {""}, {""}, {""},
#line 59 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_C1'", 50},
      {""}, {""},
#line 1839 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_CL2", 1830},
#line 1242 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_ND1", 1233},
#line 77 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H1'", 68},
#line 1371 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_CB", 1362},
      {""},
#line 169 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_N9", 160},
      {""}, {""}, {""},
#line 1379 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_HB2", 1370},
      {""}, {""},
#line 55 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_C3'", 46},
      {""}, {""},
#line 1833 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_CL1", 1824},
      {""},
#line 73 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H3'", 64},
      {""}, {""}, {""}, {""},
#line 56 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_O3'", 47},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1380 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_HB3", 1371},
      {""}, {""}, {""}, {""}, {""},
#line 894 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_HA", 885},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1577 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_HXT", 1568},
#line 996 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_C5", 987},
      {""}, {""},
#line 33 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_HOP3", 24},
#line 1570 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_OXT", 1561},
#line 1010 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H5", 1001},
      {""}, {""}, {""}, {""},
#line 1009 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H42", 1000},
      {""}, {""}, {""}, {""}, {""},
#line 983 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_C5'", 974},
      {""}, {""}, {""}, {""},
#line 1000 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H5'", 991},
      {""}, {""}, {""}, {""},
#line 982 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_O5'", 973},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1557 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_H2", 1548},
      {""}, {""}, {""},
#line 434 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_N1", 425},
#line 282 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C2'", 273},
      {""}, {""}, {""}, {""},
#line 302 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_H2'", 293},
#line 1368 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_CA", 1359},
#line 66 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_C5", 57},
      {""},
#line 253 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_C4", 244},
#line 283 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_O2'", 274},
#line 1378 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MET_HA", 1369},
#line 80 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H5", 71},
      {""}, {""},
#line 284 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C1'", 275},
      {""}, {""}, {""},
#line 254 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_O4", 245},
#line 304 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_H1'", 295},
#line 1543 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HO2P", 1534},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 280 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C3'", 271},
      {""}, {""}, {""}, {""},
#line 300 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_H3'", 291},
      {""}, {""}, {""}, {""},
#line 281 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_O3'", 272},
#line 24 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C8", 15},
      {""}, {""},
#line 1552 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_P", 1543},
      {""},
#line 43 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H8", 34},
      {""}, {""}, {""}, {""},
#line 1544 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_HO3P", 1535},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 560 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_N1", 551},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 252 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_N3", 243},
      {""}, {""}, {""}, {""},
#line 255 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_C5", 246},
      {""}, {""}, {""}, {""}, {""},
#line 269 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H52", 260},
      {""}, {""}, {""}, {""},
#line 288 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C5", 279},
      {""}, {""}, {""}, {""}, {""},
#line 1248 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_H2", 1239},
      {""}, {""},
#line 978 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_OP3", 969},
#line 268 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H51", 259},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1441 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_C", 1432},
      {""}, {""}, {""}, {""},
#line 1448 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_H", 1439},
      {""}, {""}, {""}, {""},
#line 1442 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_O", 1433},
#line 1447 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_CE", 1438},
      {""},
#line 1261 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_CB", 1252},
      {""}, {""}, {""},
#line 1457 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_HE2", 1448},
      {""},
#line 1268 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_HB2", 1259},
      {""},
#line 1014 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_OP1", 1005},
      {""}, {""}, {""}, {""}, {""},
#line 1530 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PTR_O1P", 1521},
      {""}, {""}, {""}, {""},
#line 1456 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_HE1", 1447},
#line 68 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_HOP3", 59},
      {""}, {""},
#line 1446 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_SE", 1437},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 179 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C4", 170},
      {""},
#line 1458 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_HE3", 1449},
      {""},
#line 1269 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_HB3", 1260},
#line 1439 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_N", 1430},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1561 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_HXT", 1552},
      {""}, {""}, {""}, {""},
#line 1551 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_OXT", 1542},
      {""},
#line 1445 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_CG", 1436},
      {""},
#line 1868 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C29", 1859},
      {""}, {""}, {""},
#line 1454 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_HG2", 1445},
#line 1964 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H29", 1955},
      {""}, {""}, {""}, {""},
#line 2028 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H94", 2019},
      {""}, {""},
#line 327 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_N1", 318},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1455 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_HG3", 1446},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1258 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_CA", 1249},
      {""}, {""}, {""}, {""},
#line 1267 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_HA", 1258},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1051 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_OP1", 1042},
      {""},
#line 412 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_HOP2", 403},
#line 1889 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C42", 1880},
      {""}, {""}, {""},
#line 1939 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H4", 1930},
#line 1977 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H42", 1968},
      {""}, {""}, {""}, {""},
#line 1890 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O42", 1881},
      {""}, {""}, {""}, {""},
#line 1888 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C41", 1879},
      {""}, {""}, {""},
#line 295 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_HOP3", 286},
#line 1976 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H41", 1967},
      {""}, {""}, {""},
#line 530 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HOP2", 521},
      {""}, {""}, {""}, {""}, {""},
#line 1891 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C43", 1882},
      {""}, {""}, {""}, {""},
#line 1978 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H43", 1969},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1735 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MG_MG", 1726},
      {""}, {""}, {""}, {""}, {""},
#line 1873 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C32", 1864},
      {""}, {""}, {""},
#line 1938 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H3", 1929},
#line 1967 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H32", 1958},
      {""}, {""}, {""}, {""},
#line 1874 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O32", 1865},
      {""},
#line 860 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C4", 851},
      {""}, {""},
#line 1871 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C31", 1862},
#line 1256 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_HXT", 1247},
      {""}, {""}, {""},
#line 1966 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H31", 1957},
#line 1246 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_OXT", 1237},
      {""}, {""}, {""},
#line 1872 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O31", 1863},
      {""}, {""}, {""}, {""},
#line 1875 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C33", 1866},
      {""}, {""}, {""}, {""},
#line 1968 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H33", 1959},
      {""}, {""}, {""}, {""},
#line 1876 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O33", 1867},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 286 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C8", 277},
      {""}, {""}, {""}, {""},
#line 305 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_H8", 296},
      {""}, {""},
#line 1907 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C52", 1898},
      {""},
#line 1554 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_O2P", 1545},
      {""},
#line 1940 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H5", 1931},
#line 1987 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H52", 1978},
      {""},
#line 490 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_HOP2", 481},
      {""}, {""},
#line 1908 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O52", 1899},
      {""}, {""}, {""}, {""},
#line 1905 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C51", 1896},
      {""}, {""},
#line 166 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C2'", 157},
      {""},
#line 1986 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H51", 1977},
      {""}, {""},
#line 187 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H2'", 178},
      {""},
#line 1906 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O51", 1897},
      {""}, {""},
#line 167 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_O2'", 158},
      {""},
#line 1909 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C53", 1900},
      {""}, {""},
#line 168 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C1'", 159},
      {""},
#line 1988 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H53", 1979},
      {""}, {""},
#line 189 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H1'", 180},
      {""},
#line 1910 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O53", 1901},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 164 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C3'", 155},
      {""}, {""},
#line 1601 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_O1P", 1592},
#line 1754 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C4", 1745},
#line 185 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H3'", 176},
#line 520 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_N7", 511},
      {""}, {""}, {""},
#line 165 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_O3'", 156},
#line 865 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_N3", 856},
      {""}, {""}, {""}, {""},
#line 861 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C5", 852},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1449 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_H2", 1440},
      {""}, {""},
#line 247 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_C2'", 238},
      {""}, {""}, {""}, {""},
#line 265 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H2'", 256},
      {""}, {""}, {""}, {""},
#line 248 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_O2'", 239},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 358 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_C4'", 349},
      {""}, {""}, {""},
#line 652 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C4", 643},
#line 369 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_H4'", 360},
      {""},
#line 172 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C5", 163},
      {""}, {""},
#line 359 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_O4'", 350},
      {""}, {""}, {""}, {""}, {""},
#line 1755 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_N3", 1746},
      {""}, {""},
#line 439 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_HOP2", 430},
      {""},
#line 1753 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C5", 1744},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1782 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_PB", 1773},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1860 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C24", 1851},
#line 2029 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H95", 2020},
      {""}, {""}, {""},
#line 1959 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H24", 1950},
      {""}, {""}, {""}, {""},
#line 1861 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O24", 1852},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 102 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_C4", 93},
      {""}, {""}, {""}, {""}, {""},
#line 116 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H42", 107},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 115 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H41", 106},
      {""}, {""}, {""}, {""},
#line 389 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_C4'", 380},
      {""}, {""}, {""}, {""},
#line 408 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_H4'", 399},
#line 592 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_HOP2", 583},
      {""}, {""}, {""},
#line 390 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_O4'", 381},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 651 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_N3", 642},
      {""},
#line 525 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_C10", 516},
#line 1614 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_HOP2", 1605},
      {""},
#line 644 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C5", 635},
#line 103 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_N4", 94},
#line 511 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_C4'", 502},
#line 556 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H101", 547},
      {""}, {""}, {""},
#line 546 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H4'", 537},
      {""}, {""}, {""}, {""},
#line 512 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_O4'", 503},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1786 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_PA", 1777},
      {""}, {""}, {""},
#line 388 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_C3'", 379},
      {""}, {""}, {""},
#line 557 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H102", 548},
#line 407 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_H3'", 398},
      {""}, {""}, {""}, {""},
#line 391 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_O3'", 382},
      {""}, {""},
#line 1568 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_CB", 1559},
#line 1808 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C4", 1799},
      {""},
#line 430 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_N7", 421},
      {""},
#line 1272 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HYP_HD23", 1263},
#line 1574 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_HB2", 1565},
      {""}, {""}, {""}, {""},
#line 101 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_N3", 92},
#line 513 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_C3'", 504},
      {""}, {""}, {""},
#line 104 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_C5", 95},
#line 547 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H3'", 538},
      {""}, {""}, {""},
#line 117 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H5", 108},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1575 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_HB3", 1566},
      {""},
#line 180 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_HOP3", 171},
      {""}, {""}, {""},
#line 392 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_C5'", 383},
      {""}, {""}, {""},
#line 1451 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_HXT", 1442},
#line 410 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_H5'", 401},
      {""}, {""},
#line 468 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_C4'", 459},
#line 1443 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_OXT", 1434},
#line 393 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_O5'", 384},
      {""}, {""},
#line 486 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_H4'", 477},
      {""}, {""}, {""}, {""},
#line 470 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_O4'", 461},
#line 550 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HO2'", 541},
#line 514 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_N3'", 505},
      {""}, {""}, {""},
#line 409 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_HO3'", 400},
#line 510 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_C5'", 501},
      {""}, {""}, {""}, {""},
#line 544 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H5'", 535},
      {""}, {""}, {""}, {""},
#line 509 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_O5'", 500},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1041 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_HO3'", 1032},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 467 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_C3'", 458},
#line 1807 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_N3", 1798},
      {""},
#line 1565 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_CA", 1556},
      {""},
#line 485 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_H3'", 476},
#line 1801 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C5", 1792},
      {""},
#line 1573 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SER_HA", 1564},
#line 334 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HOP2", 325},
#line 469 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_O3'", 460},
      {""}, {""}, {""}, {""}, {""},
#line 170 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C8", 161},
      {""}, {""},
#line 1744 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ACT_H3", 1735},
      {""},
#line 190 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H8", 181},
#line 896 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H3P", 887},
      {""}, {""}, {""}, {""},
#line 882 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_O3P", 873},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1026 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_N7", 1017},
      {""}, {""}, {""}, {""},
#line 471 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_C5'", 462},
      {""}, {""}, {""}, {""},
#line 488 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_H5'", 479},
      {""}, {""}, {""}, {""},
#line 472 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_O5'", 463},
      {""},
#line 877 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C2'", 868},
      {""}, {""}, {""}, {""},
#line 893 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H2'", 884},
      {""}, {""},
#line 912 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_N9", 903},
      {""},
#line 878 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_O2'", 869},
      {""},
#line 487 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_HO3'", 478},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 357 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_C5'", 348},
      {""}, {""},
#line 801 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_C4", 792},
#line 733 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C4", 724},
#line 367 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_H5'", 358},
      {""}, {""}, {""},
#line 1076 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_HO3'", 1067},
#line 356 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_O5'", 347},
      {""},
#line 420 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C4'", 411},
      {""}, {""}, {""}, {""},
#line 443 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_H4'", 434},
      {""}, {""}, {""},
#line 368 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"N_H5''", 359},
#line 421 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_O4'", 412},
      {""},
#line 1068 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C7", 1059},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1862 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C25", 1853},
      {""}, {""}, {""}, {""},
#line 1960 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H25", 1951},
      {""}, {""}, {""},
#line 802 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_N4", 793},
#line 1863 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O25", 1854},
      {""}, {""}, {""}, {""}, {""},
#line 323 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_N7", 314},
      {""}, {""}, {""},
#line 422 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C3'", 413},
      {""}, {""}, {""}, {""},
#line 444 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_H3'", 435},
      {""}, {""}, {""}, {""},
#line 423 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_O3'", 414},
      {""},
#line 1761 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C2'", 1752},
#line 1547 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_CB", 1538},
      {""}, {""}, {""}, {""},
#line 1773 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H2'1", 1764},
#line 1559 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_HB2", 1550},
      {""}, {""}, {""},
#line 572 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_C4'", 563},
      {""},
#line 666 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_HM13", 657},
      {""}, {""},
#line 588 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_H4'", 579},
      {""}, {""}, {""}, {""},
#line 574 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_O4'", 565},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 800 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_N3", 791},
#line 732 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_N3", 723},
      {""}, {""}, {""},
#line 803 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_C5", 794},
#line 725 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C5", 716},
#line 1774 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H2'2", 1765},
#line 1560 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_HB3", 1551},
      {""}, {""}, {""}, {""},
#line 825 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C4", 816},
#line 419 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C5'", 410},
      {""}, {""}, {""}, {""},
#line 441 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_H5'", 432},
      {""}, {""}, {""},
#line 830 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_O4", 821},
#line 418 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_O5'", 409},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1038 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_H5''", 1029},
      {""},
#line 571 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_C3'", 562},
      {""},
#line 1780 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O3G", 1771},
      {""},
#line 445 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_HO3'", 436},
#line 587 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_H3'", 578},
      {""}, {""}, {""}, {""},
#line 573 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_O3'", 564},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 638 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C2'", 629},
      {""}, {""}, {""}, {""},
#line 660 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_H2'", 651},
      {""}, {""}, {""}, {""},
#line 639 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_O2'", 630},
      {""}, {""}, {""}, {""}, {""},
#line 1546 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_CA", 1537},
      {""}, {""}, {""}, {""},
#line 1558 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_HA", 1549},
#line 586 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_HO2'", 577},
      {""}, {""}, {""}, {""}, {""},
#line 575 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_C5'", 566},
      {""}, {""}, {""}, {""},
#line 590 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_H5'", 581},
      {""}, {""}, {""}, {""},
#line 576 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_O5'", 567},
      {""}, {""}, {""}, {""},
#line 1580 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_C", 1571},
      {""}, {""}, {""}, {""},
#line 1586 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_H", 1577},
#line 1240 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_CB", 1231},
      {""}, {""},
#line 589 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_HO3'", 580},
#line 1581 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_O", 1572},
#line 824 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_N3", 815},
#line 1250 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_HB2", 1241},
      {""}, {""},
#line 95 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_C2'", 86},
#line 826 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C5", 817},
      {""}, {""}, {""},
#line 113 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H2'", 104},
      {""},
#line 249 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_N1", 240},
      {""}, {""},
#line 96 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_O2'", 87},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1073 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H5''", 1064},
      {""}, {""}, {""},
#line 1251 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_HB3", 1242},
      {""}, {""}, {""}, {""},
#line 980 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_OP1", 971},
#line 314 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C4'", 305},
      {""},
#line 1578 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_N", 1569},
      {""}, {""},
#line 338 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_H4'", 329},
      {""}, {""}, {""}, {""},
#line 315 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_O4'", 306},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1584 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_CG2", 1575},
      {""}, {""},
#line 919 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C2", 910},
      {""}, {""},
#line 1591 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_HG21", 1582},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1590 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_HG1", 1581},
      {""}, {""}, {""}, {""},
#line 1583 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_OG1", 1574},
      {""},
#line 1867 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C28", 1858},
#line 316 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C3'", 307},
      {""}, {""}, {""},
#line 1963 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H28", 1954},
#line 339 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_H3'", 330},
      {""},
#line 1795 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C2'", 1786},
#line 1592 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_HG22", 1583},
      {""},
#line 317 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_O3'", 308},
#line 1237 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_CA", 1228},
#line 1818 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_H2'", 1809},
      {""}, {""}, {""},
#line 1249 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HIS_HA", 1240},
#line 1796 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O2'", 1787},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 920 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_N2", 911},
      {""}, {""}, {""},
#line 899 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_P", 890},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1886 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C40", 1877},
      {""}, {""}, {""}, {""},
#line 1975 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H40", 1966},
      {""}, {""}, {""},
#line 342 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HO2'", 333},
#line 1887 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O40", 1878},
      {""}, {""}, {""}, {""},
#line 313 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C5'", 304},
      {""}, {""}, {""}, {""},
#line 336 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_H5'", 327},
      {""}, {""}, {""}, {""},
#line 312 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_O5'", 303},
#line 1082 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H72", 1073},
      {""}, {""}, {""}, {""},
#line 901 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_OP2", 892},
      {""},
#line 608 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_C2", 599},
      {""}, {""}, {""}, {""}, {""},
#line 340 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HO3'", 331},
      {""}, {""}, {""},
#line 609 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_O2", 600},
      {""}, {""},
#line 900 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_OP1", 891},
      {""}, {""}, {""}, {""}, {""},
#line 1869 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C30", 1860},
      {""}, {""}, {""}, {""},
#line 1965 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H30", 1956},
      {""}, {""}, {""},
#line 902 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_OP3", 893},
#line 1870 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O30", 1861},
      {""}, {""},
#line 623 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_HO2'", 614},
#line 749 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_HM23", 740},
      {""},
#line 625 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_H3", 616},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 621 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_HO3'", 612},
      {""},
#line 1731 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"HOH_H1", 1722},
#line 607 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_N1", 598},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1903 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C50", 1894},
      {""}, {""}, {""}, {""},
#line 1985 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H50", 1976},
#line 610 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_N3", 601},
      {""},
#line 1828 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C12", 1819},
      {""},
#line 1904 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O50", 1895},
      {""},
#line 1936 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H1", 1927},
#line 1947 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H12", 1938},
      {""}, {""}, {""}, {""},
#line 1844 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O12", 1835},
      {""}, {""}, {""}, {""},
#line 1826 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C11", 1817},
      {""}, {""}, {""}, {""},
#line 1946 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H11", 1937},
      {""}, {""}, {""}, {""}, {""},
#line 751 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_C2", 742},
      {""}, {""}, {""},
#line 1829 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C13", 1820},
      {""}, {""}, {""}, {""},
#line 1948 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H13", 1939},
#line 756 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_O2", 747},
      {""}, {""}, {""},
#line 1845 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O13", 1836},
      {""},
#line 794 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_C2'", 785},
#line 719 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C2'", 710},
      {""}, {""}, {""},
#line 813 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_H2'", 804},
#line 741 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_H2'", 732},
      {""}, {""},
#line 533 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HN2", 524},
#line 795 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_O2'", 786},
#line 720 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_O2'", 711},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 532 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HN1", 523},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 767 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_P", 758},
      {""}, {""}, {""}, {""},
#line 16 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C4'", 7},
      {""}, {""}, {""}, {""},
#line 37 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H4'", 28},
      {""}, {""}, {""}, {""},
#line 17 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_O4'", 8},
#line 1587 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_H2", 1578},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1189 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_C", 1180},
      {""}, {""}, {""}, {""},
#line 1197 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_H", 1188},
      {""}, {""}, {""}, {""},
#line 1190 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_O", 1181},
#line 866 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_N1", 857},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1204 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_HE21", 1195},
#line 769 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_OP2", 760},
      {""}, {""}, {""}, {""},
#line 1444 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_CB", 1435},
      {""}, {""}, {""}, {""}, {""},
#line 1452 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_HB2", 1443},
      {""}, {""}, {""},
#line 768 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_OP1", 759},
      {""}, {""},
#line 1194 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_OE1", 1185},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1205 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_HE22", 1196},
#line 770 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_OP3", 761},
#line 1187 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_N", 1178},
#line 1193 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_CD", 1184},
      {""}, {""},
#line 832 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C2'", 823},
      {""}, {""}, {""}, {""},
#line 850 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H2'", 841},
#line 1453 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_HB3", 1444},
#line 1776 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H1", 1767},
#line 1195 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_NE2", 1186},
      {""},
#line 833 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_O2'", 824},
#line 1209 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_C", 1200},
      {""}, {""},
#line 477 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_HN3", 468},
      {""},
#line 1217 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_H", 1208},
#line 1192 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_CG", 1183},
      {""}, {""}, {""},
#line 1210 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_O", 1201},
      {""},
#line 1202 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_HG2", 1193},
      {""}, {""}, {""}, {""},
#line 1224 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_HE2", 1215},
      {""}, {""}, {""}, {""},
#line 1215 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_OE2", 1206},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1214 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_OE1", 1205},
      {""}, {""}, {""},
#line 1757 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_N1", 1748},
#line 1203 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_HG3", 1194},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1207 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_N", 1198},
#line 1213 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_CD", 1204},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1440 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_CA", 1431},
      {""}, {""}, {""}, {""},
#line 1450 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MSE_HA", 1441},
      {""},
#line 1212 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_CG", 1203},
      {""}, {""}, {""}, {""}, {""},
#line 1222 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_HG2", 1213},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 519 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_C8", 510},
#line 411 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_H5''", 402},
      {""}, {""}, {""},
#line 552 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H8", 543},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 25 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_N7", 16},
#line 1223 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_HG3", 1214},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 805 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_CM5", 796},
#line 545 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H5''", 536},
      {""}, {""}, {""}, {""},
#line 819 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_HM51", 810},
#line 453 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_HN21", 444},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 647 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_N1", 638},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 452 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_HN1", 443},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 961 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C2", 952},
#line 53 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_C4'", 44},
      {""},
#line 595 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_P", 586},
#line 83 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_O1C", 74},
#line 977 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H2", 968},
#line 72 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H4'", 63},
#line 820 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_HM52", 811},
#line 454 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_HN22", 445},
#line 1594 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_HXT", 1585},
#line 257 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_HOP2", 248},
#line 54 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_O4'", 45},
      {""}, {""},
#line 1585 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_OXT", 1576},
#line 597 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_OP2", 588},
#line 952 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C2'", 943},
      {""}, {""},
#line 384 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_C1'", 375},
      {""},
#line 971 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H2'", 962},
      {""}, {""},
#line 402 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_H1'", 393},
      {""}, {""}, {""}, {""}, {""},
#line 596 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_OP1", 587},
#line 953 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C1'", 944},
      {""}, {""}, {""}, {""},
#line 973 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H1'", 964},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 98 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_N1", 89},
#line 517 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_C1'", 508},
#line 594 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_OP3", 585},
#line 950 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C3'", 941},
      {""}, {""},
#line 551 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H1'", 542},
      {""},
#line 969 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H3'", 960},
      {""}, {""}, {""}, {""},
#line 951 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_O3'", 942},
      {""}, {""}, {""}, {""}, {""},
#line 489 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_H5''", 480},
#line 1902 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C49", 1893},
      {""},
#line 960 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_N1", 951},
      {""},
#line 581 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_HN1", 572},
#line 1984 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H49", 1975},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1004 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_HO3'", 995},
      {""}, {""}, {""},
#line 962 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_N3", 953},
      {""},
#line 582 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_HN3", 573},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 15 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C5'", 6},
      {""}, {""},
#line 1884 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C39", 1875},
      {""},
#line 35 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H5'", 26},
      {""}, {""},
#line 1974 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H39", 1965},
#line 278 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C4'", 269},
#line 14 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_O5'", 5},
      {""}, {""},
#line 1885 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O39", 1876},
#line 299 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_H4'", 290},
      {""}, {""}, {""}, {""},
#line 279 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_O4'", 270},
      {""},
#line 36 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H5''", 27},
#line 463 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_C1'", 454},
#line 1804 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_N1", 1795},
      {""}, {""}, {""},
#line 480 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_H1'", 471},
#line 1198 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_H2", 1189},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1742 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ACT_H1", 1733},
      {""}, {""},
#line 884 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H1P", 875},
      {""}, {""}, {""}, {""},
#line 862 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_O1P", 853},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1918 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C59", 1909},
      {""}, {""}, {""}, {""},
#line 1994 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H59", 1985},
      {""}, {""}, {""}, {""},
#line 1919 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O59", 1910},
      {""}, {""}, {""}, {""}, {""},
#line 429 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C8", 420},
      {""}, {""}, {""}, {""},
#line 451 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_H8", 442},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 106 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_HOC2", 97},
      {""}, {""}, {""}, {""},
#line 1218 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_H2", 1209},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 442 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_H5''", 433},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 345 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HN1", 336},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 427 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C1'", 418},
#line 1555 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_O3P", 1546},
      {""},
#line 591 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_H5''", 582},
      {""},
#line 450 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_H1'", 441},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 287 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_N7", 278},
      {""}, {""}, {""},
#line 1001 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H5''", 992},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 797 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_N1", 788},
#line 728 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_N1", 719},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 52 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_C5'", 43},
      {""},
#line 242 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_C4'", 233},
      {""}, {""},
#line 70 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H5'", 61},
      {""},
#line 261 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H4'", 252},
      {""}, {""},
#line 51 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_O5'", 42},
      {""},
#line 243 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_O4'", 234},
      {""}, {""}, {""}, {""},
#line 568 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_C1'", 559},
      {""},
#line 1778 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O1G", 1769},
      {""},
#line 71 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H5''", 62},
#line 584 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_H1'", 575},
      {""},
#line 616 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_HOP2", 607},
#line 1206 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_HXT", 1197},
      {""}, {""}, {""}, {""},
#line 1196 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_OXT", 1187},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 413 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_HOP3", 404},
      {""},
#line 1942 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H7", 1933},
#line 2007 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H72", 1998},
      {""}, {""}, {""}, {""},
#line 1928 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O72", 1919},
      {""}, {""}, {""}, {""}, {""},
#line 244 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_C3'", 235},
      {""}, {""},
#line 943 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_P", 934},
#line 2006 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H71", 1997},
#line 262 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H3'", 253},
      {""}, {""}, {""},
#line 1927 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O71", 1918},
#line 245 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_O3'", 236},
#line 531 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HOP3", 522},
      {""}, {""}, {""}, {""}, {""},
#line 1892 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C44", 1883},
      {""},
#line 2008 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H73", 1999},
      {""}, {""},
#line 1979 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H44", 1970},
      {""}, {""}, {""}, {""},
#line 1893 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O44", 1884},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 322 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C8", 313},
#line 1225 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_HXT", 1216},
      {""}, {""}, {""},
#line 344 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_H8", 335},
#line 1216 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_OXT", 1207},
      {""}, {""},
#line 822 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_N1", 813},
      {""}, {""}, {""}, {""},
#line 266 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_HO2'", 257},
      {""},
#line 965 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_HOP2", 956},
      {""}, {""}, {""},
#line 241 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_C5'", 232},
      {""}, {""}, {""}, {""},
#line 259 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H5'", 250},
#line 337 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_H5''", 328},
      {""}, {""}, {""},
#line 240 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_O5'", 231},
#line 277 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C5'", 268},
      {""}, {""},
#line 1877 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C34", 1868},
      {""},
#line 297 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_H5'", 288},
      {""}, {""},
#line 1969 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H34", 1960},
      {""},
#line 276 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_O5'", 267},
      {""}, {""},
#line 263 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_HO3'", 254},
      {""},
#line 964 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_HOP3", 955},
      {""}, {""}, {""}, {""}, {""},
#line 298 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_H5''", 289},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 870 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_N7", 861},
      {""}, {""},
#line 491 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_HOP3", 482},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1911 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C54", 1902},
      {""}, {""}, {""}, {""},
#line 1989 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H54", 1980},
      {""}, {""}, {""},
#line 320 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C1'", 311},
      {""}, {""}, {""}, {""},
#line 343 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_H1'", 334},
      {""}, {""}, {""},
#line 162 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C4'", 153},
      {""}, {""}, {""},
#line 653 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_HOP2", 644},
#line 184 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H4'", 175},
      {""}, {""}, {""}, {""},
#line 163 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_O4'", 154},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1809 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_HOG2", 1800},
      {""}, {""}, {""},
#line 381 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_C6", 372},
      {""},
#line 82 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_PC", 73},
      {""}, {""},
#line 399 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_H6", 390},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 522 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_C6", 513},
      {""}, {""},
#line 1752 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_N7", 1743},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 107 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_HOP2", 98},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1827 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C10", 1818},
      {""}, {""}, {""}, {""},
#line 1945 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H10", 1936},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 523 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_N6", 514},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 440 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_HOP3", 431},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 460 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_C6", 451},
      {""}, {""},
#line 643 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_N7", 634},
      {""},
#line 479 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMU_H6", 470},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1832 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C02", 1823},
      {""},
#line 874 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C4'", 865},
      {""}, {""}, {""}, {""},
#line 891 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H4'", 882},
      {""}, {""}, {""}, {""},
#line 875 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_O4'", 866},
      {""}, {""},
#line 1830 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C01", 1821},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1831 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O01", 1822},
#line 2032 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H97", 2023},
      {""}, {""}, {""},
#line 1834 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C03", 1825},
      {""}, {""},
#line 593 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_HOP3", 584},
      {""}, {""}, {""}, {""},
#line 171 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_N7", 162},
      {""},
#line 1835 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O03", 1826},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1615 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"TPO_HOP3", 1606},
      {""}, {""}, {""}, {""},
#line 1582 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_CB", 1573},
#line 879 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C3'", 870},
      {""}, {""}, {""},
#line 1589 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_HB", 1580},
#line 892 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H3'", 883},
      {""}, {""}, {""}, {""},
#line 880 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_O3'", 871},
#line 1894 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C45", 1885},
#line 682 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_N9", 673},
#line 945 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_OP2", 936},
      {""}, {""},
#line 1980 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H45", 1971},
      {""}, {""}, {""}, {""},
#line 1895 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O45", 1886},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 558 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_H103", 549},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1747 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C4'", 1738},
      {""}, {""}, {""}, {""},
#line 1767 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H4'", 1758},
      {""}, {""}, {""}, {""},
#line 1748 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_O4'", 1739},
      {""},
#line 873 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C5'", 864},
      {""}, {""}, {""}, {""}, {""},
#line 889 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H5'1", 880},
      {""},
#line 1878 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C35", 1869},
      {""},
#line 872 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_O5'", 863},
      {""}, {""},
#line 1970 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H35", 1961},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 432 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_C6", 423},
      {""}, {""},
#line 1800 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_N7", 1791},
      {""}, {""}, {""}, {""},
#line 890 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H5'2", 881},
      {""},
#line 433 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMG_O6", 424},
      {""},
#line 1762 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C3'", 1753},
      {""}, {""}, {""}, {""},
#line 1775 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H3'", 1766},
      {""}, {""}, {""},
#line 1579 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_CA", 1570},
#line 1763 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_O3'", 1754},
      {""},
#line 1008 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H41", 999},
      {""},
#line 1588 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_HA", 1579},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1912 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C55", 1903},
      {""}, {""}, {""}, {""},
#line 1990 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H55", 1981},
      {""}, {""}, {""}, {""},
#line 1913 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O55", 1904},
      {""}, {""}, {""}, {""},
#line 634 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C4'", 625},
      {""}, {""},
#line 161 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C5'", 152},
      {""},
#line 657 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_H4'", 648},
#line 806 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_HOP2", 797},
#line 734 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_HOP2", 725},
#line 182 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H5'", 173},
      {""},
#line 635 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_O4'", 626},
      {""}, {""},
#line 160 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_O5'", 151},
      {""}, {""},
#line 335 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_HOP3", 326},
#line 1746 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C5'", 1737},
      {""}, {""}, {""}, {""},
#line 1764 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H5'", 1755},
#line 1765 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H5'1", 1756},
#line 183 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_H5''", 174},
#line 565 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_C6", 556},
      {""},
#line 1745 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_O5'", 1736},
      {""}, {""},
#line 583 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PSU_H6", 574},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 636 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C3'", 627},
#line 1766 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H5'2", 1757},
      {""}, {""}, {""},
#line 658 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_H3'", 649},
#line 91 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_C4'", 82},
      {""}, {""}, {""},
#line 637 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_O3'", 628},
#line 111 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H4'", 102},
      {""}, {""}, {""}, {""},
#line 92 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_O4'", 83},
#line 1670 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_C", 1661},
      {""}, {""}, {""}, {""},
#line 1675 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_H", 1666},
      {""}, {""}, {""}, {""},
#line 1671 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_O", 1662},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 661 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_HO2'", 652},
      {""}, {""}, {""}, {""}, {""},
#line 633 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C5'", 624},
      {""}, {""},
#line 93 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_C3'", 84},
      {""},
#line 655 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_H5'", 646},
      {""}, {""},
#line 112 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H3'", 103},
      {""},
#line 632 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_O5'", 623},
#line 922 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C4", 913},
#line 1668 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_N", 1659},
#line 94 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_O3'", 85},
#line 857 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_HOP2", 848},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 659 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_HO3'", 650},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1673 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_CG", 1664},
      {""},
#line 1900 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C48", 1891},
      {""},
#line 724 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_N7", 715},
      {""},
#line 1681 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_HG2", 1672},
#line 1983 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H48", 1974},
      {""}, {""},
#line 1791 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C4'", 1782},
      {""},
#line 1901 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O48", 1892},
      {""}, {""},
#line 1815 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_H4'", 1806},
      {""}, {""}, {""}, {""},
#line 1792 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O4'", 1783},
#line 1680 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_HG1", 1671},
      {""}, {""}, {""},
#line 90 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_C5'", 81},
      {""}, {""}, {""}, {""},
#line 109 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H5'", 100},
      {""}, {""}, {""},
#line 689 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C2", 680},
#line 89 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_O5'", 80},
#line 1682 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_HG3", 1673},
      {""}, {""},
#line 1866 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C27", 1857},
      {""}, {""}, {""}, {""},
#line 1962 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H27", 1953},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1882 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C38", 1873},
#line 325 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_C6", 316},
      {""}, {""}, {""},
#line 1973 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H38", 1964},
      {""}, {""},
#line 1793 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C3'", 1784},
      {""},
#line 1883 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O38", 1874},
#line 326 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"M2G_O6", 317},
      {""},
#line 1816 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_H3'", 1807},
      {""}, {""}, {""}, {""},
#line 1794 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O3'", 1785},
      {""},
#line 846 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H72", 837},
      {""}, {""}, {""}, {""}, {""},
#line 921 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_N3", 912},
      {""}, {""}, {""},
#line 1191 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_CB", 1182},
#line 915 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C5", 906},
      {""}, {""},
#line 669 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_P", 660},
#line 845 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H71", 836},
#line 1200 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_HB2", 1191},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1852 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C19", 1843},
      {""}, {""}, {""},
#line 267 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_HN3", 258},
#line 1954 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H19", 1945},
      {""},
#line 847 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H73", 838},
      {""}, {""},
#line 1853 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O19", 1844},
      {""},
#line 1917 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C58", 1908},
      {""},
#line 1819 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_HO2'", 1810},
      {""}, {""},
#line 1993 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H58", 1984},
      {""}, {""},
#line 1790 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C5'", 1781},
      {""},
#line 1788 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O2A", 1779},
#line 1201 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_HB3", 1192},
#line 1083 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H73", 1074},
#line 1813 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_H5'", 1804},
      {""}, {""}, {""}, {""},
#line 1789 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O5'", 1780},
      {""}, {""},
#line 671 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_OP2", 662},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1817 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_HO3'", 1808},
      {""}, {""}, {""},
#line 670 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_OP1", 661},
      {""}, {""}, {""},
#line 1211 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_CB", 1202},
#line 690 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_CM2", 681},
      {""}, {""}, {""}, {""},
#line 1220 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_HB2", 1211},
#line 705 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_HM21", 696},
      {""}, {""}, {""},
#line 672 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_OP3", 663},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 753 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_C4", 744},
#line 1221 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_HB3", 1212},
#line 706 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_HM22", 697},
      {""}, {""},
#line 1188 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_CA", 1179},
      {""}, {""}, {""}, {""},
#line 1199 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLN_HA", 1190},
      {""}, {""}, {""}, {""}, {""},
#line 790 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_C4'", 781},
#line 715 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C4'", 706},
      {""}, {""}, {""},
#line 810 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_H4'", 801},
#line 738 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_H4'", 729},
      {""}, {""},
#line 757 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_S4", 748},
#line 791 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_O4'", 782},
#line 716 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_O4'", 707},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 792 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_C3'", 783},
#line 717 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C3'", 708},
#line 1208 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_CA", 1199},
      {""}, {""},
#line 811 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_H3'", 802},
#line 739 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_H3'", 730},
#line 1219 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLU_HA", 1210},
      {""}, {""},
#line 793 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_O3'", 784},
#line 718 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_O3'", 709},
      {""}, {""}, {""},
#line 1553 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_O1P", 1544},
      {""}, {""},
#line 1593 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"THR_HG23", 1584},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1676 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_H2", 1667},
      {""}, {""}, {""}, {""}, {""},
#line 752 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_N3", 743},
      {""}, {""}, {""}, {""},
#line 754 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_C5", 745},
      {""}, {""}, {""}, {""},
#line 772 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_H5", 763},
      {""}, {""},
#line 1935 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C70", 1926},
      {""},
#line 814 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_HO2'", 805},
#line 742 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_HO2'", 733},
      {""},
#line 2005 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H70", 1996},
      {""},
#line 260 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H5''", 251},
#line 789 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_C5'", 780},
#line 714 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C5'", 705},
      {""}, {""}, {""},
#line 808 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_H5'", 799},
#line 736 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_H5'", 727},
      {""},
#line 835 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C4'", 826},
      {""},
#line 788 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_O5'", 779},
#line 713 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_O5'", 704},
      {""},
#line 853 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H4'", 844},
      {""}, {""}, {""}, {""},
#line 837 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_O4'", 828},
      {""}, {""}, {""}, {""}, {""},
#line 812 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_HO3'", 803},
#line 740 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_HO3'", 731},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 611 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_C4", 602},
      {""},
#line 834 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C3'", 825},
      {""}, {""}, {""}, {""},
#line 852 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H3'", 843},
      {""}, {""},
#line 612 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_O4", 603},
      {""},
#line 836 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_O3'", 827},
#line 246 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_C1'", 237},
      {""}, {""}, {""}, {""},
#line 264 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H1'", 255},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 851 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_HO2'", 842},
      {""}, {""}, {""}, {""}, {""},
#line 838 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C5'", 829},
      {""}, {""}, {""}, {""},
#line 855 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H5'", 846},
      {""}, {""}, {""}, {""},
#line 839 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_O5'", 830},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 854 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_HO3'", 845},
#line 1825 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C14", 1816},
      {""},
#line 1396 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_C", 1387},
      {""}, {""},
#line 1949 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H14", 1940},
      {""},
#line 1399 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_H", 1390},
      {""}, {""},
#line 1846 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O14", 1837},
      {""},
#line 1397 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_O", 1388},
#line 1392 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_CE", 1383},
#line 954 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_N9", 945},
      {""},
#line 1562 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_HOP2", 1553},
      {""}, {""},
#line 1408 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HE2", 1399},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 400 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_HN41", 391},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 909 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C2'", 900},
      {""}, {""}, {""}, {""},
#line 931 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_H2'", 922},
      {""}, {""}, {""}, {""},
#line 910 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_O2'", 901},
      {""}, {""}, {""}, {""},
#line 1409 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HE3", 1400},
      {""}, {""},
#line 1387 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_N", 1378},
#line 1391 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_CD", 1382},
      {""}, {""}, {""},
#line 401 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"OMC_HN42", 392},
      {""},
#line 1406 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HD2", 1397},
#line 1683 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_HXT", 1674},
      {""}, {""}, {""}, {""},
#line 1674 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_OXT", 1665},
      {""},
#line 1771 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_HN21", 1762},
      {""}, {""}, {""}, {""}, {""},
#line 1390 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_CG", 1381},
      {""}, {""}, {""}, {""}, {""},
#line 1404 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HG2", 1395},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1407 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HD3", 1398},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1770 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_HN3", 1761},
#line 1772 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_HN22", 1763},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1405 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HG3", 1396},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1943 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H8", 1934},
#line 2017 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H82", 2008},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 604 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_C2'", 595},
      {""}, {""}, {""},
#line 2016 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H81", 2007},
#line 622 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_H2'", 613},
      {""},
#line 1395 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_CH2", 1386},
      {""}, {""},
#line 605 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_O2'", 596},
      {""}, {""},
#line 1413 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HH21", 1404},
      {""},
#line 606 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_C1'", 597},
      {""}, {""}, {""},
#line 2018 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H83", 2009},
#line 624 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_H1'", 615},
      {""},
#line 1394 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_CH1", 1385},
      {""},
#line 1478 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_C", 1469},
#line 667 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_HN21", 658},
      {""}, {""},
#line 1410 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HH11", 1401},
#line 1488 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_H", 1479},
#line 602 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_C3'", 593},
      {""}, {""}, {""},
#line 1479 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_O", 1470},
#line 620 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_H3'", 611},
#line 1485 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_CE2", 1476},
      {""}, {""}, {""},
#line 603 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_O3'", 594},
#line 1496 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_HE2", 1487},
      {""},
#line 1414 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HH22", 1405},
      {""}, {""}, {""}, {""},
#line 871 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C8", 862},
      {""}, {""},
#line 1484 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_CE1", 1475},
      {""},
#line 885 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H8", 876},
      {""},
#line 668 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_HN22", 659},
#line 1495 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_HE1", 1486},
      {""},
#line 1411 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HH12", 1402},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1476 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_N", 1467},
      {""},
#line 1483 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_CD2", 1474},
      {""}, {""}, {""}, {""},
#line 1494 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_HD2", 1485},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1482 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_CD1", 1473},
      {""}, {""}, {""},
#line 1481 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_CG", 1472},
#line 1493 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_HD1", 1484},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 759 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_C2'", 750},
      {""}, {""}, {""}, {""},
#line 775 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_H2'", 766},
      {""}, {""}, {""}, {""},
#line 760 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_O2'", 751},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 613 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_C5", 604},
      {""}, {""}, {""}, {""},
#line 626 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_H5", 617},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1751 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C8", 1742},
      {""}, {""},
#line 876 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C1'", 867},
      {""},
#line 1769 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H8", 1760},
      {""}, {""},
#line 886 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H1'", 877},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 821 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_HM53", 812},
#line 1028 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_C6", 1019},
      {""},
#line 258 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_HOP3", 249},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1029 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DG_O6", 1020},
      {""}, {""}, {""}, {""},
#line 1823 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_HN21", 1814},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 963 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C4", 954},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1822 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_HN1", 1813},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 948 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C4'", 939},
      {""}, {""}, {""}, {""},
#line 968 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H4'", 959},
      {""},
#line 1824 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_HN22", 1815},
      {""}, {""},
#line 949 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_O4'", 940},
#line 1847 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C15", 1838},
      {""}, {""}, {""}, {""},
#line 1950 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H15", 1941},
      {""}, {""},
#line 2014 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H79", 2005},
      {""}, {""}, {""},
#line 1400 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_H2", 1391},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 642 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C8", 633},
      {""}, {""},
#line 1393 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_NZ", 1384},
      {""},
#line 663 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_H8", 654},
      {""}, {""},
#line 1749 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C1'", 1740},
      {""}, {""}, {""}, {""},
#line 1768 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_H1'", 1759},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 656 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_H5''", 647},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1069 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_C6", 1060},
      {""}, {""}, {""}, {""},
#line 1084 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H6", 1075},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 615 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_HOP3", 606},
      {""}, {""}, {""}, {""}, {""},
#line 110 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H5''", 101},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 640 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C1'", 631},
      {""}, {""}, {""}, {""},
#line 662 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_H1'", 653},
      {""}, {""}, {""},
#line 1486 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_CZ", 1477},
#line 256 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_C6", 247},
      {""}, {""}, {""},
#line 1497 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_HZ", 1488},
      {""},
#line 271 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H62", 262},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 270 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"H2U_H61", 261},
      {""}, {""},
#line 746 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_HN2", 737},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1489 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_H2", 1480},
      {""}, {""}, {""}, {""},
#line 745 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_HN1", 736},
      {""}, {""},
#line 1799 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C8", 1790},
      {""}, {""}, {""}, {""},
#line 1821 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_H8", 1812},
#line 97 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_C1'", 88},
      {""}, {""}, {""}, {""},
#line 114 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H1'", 105},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1814 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_H5''", 1805},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 972 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H2''", 963},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1416 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HXT", 1407},
      {""}, {""}, {""}, {""},
#line 1398 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_OXT", 1389},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1850 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C18", 1841},
      {""}, {""}, {""}, {""},
#line 1953 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H18", 1944},
      {""}, {""},
#line 1797 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C1'", 1788},
      {""},
#line 1851 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O18", 1842},
      {""},
#line 1277 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_C", 1268},
#line 1820 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_H1'", 1811},
      {""}, {""}, {""},
#line 1284 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_H", 1275},
      {""}, {""}, {""}, {""},
#line 1278 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_O", 1269},
      {""}, {""}, {""},
#line 918 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_N1", 909},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 844 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_HN3", 835},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1842 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C09", 1833},
      {""},
#line 957 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C5", 948},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1843 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O09", 1834},
      {""}, {""}, {""},
#line 1275 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_N", 1266},
      {""}, {""}, {""},
#line 947 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C5'", 938},
#line 1081 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DT_H71", 1072},
      {""}, {""}, {""},
#line 966 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H5'", 957},
      {""}, {""}, {""}, {""},
#line 946 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_O5'", 937},
      {""}, {""},
#line 1282 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_CD1", 1273},
      {""}, {""}, {""}, {""},
#line 1281 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_CG2", 1272},
#line 1293 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HD11", 1284},
      {""}, {""}, {""}, {""},
#line 1290 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HG21", 1281},
      {""}, {""}, {""},
#line 2009 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H74", 2000},
      {""}, {""}, {""}, {""},
#line 1280 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_CG1", 1271},
      {""},
#line 723 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C8", 714},
      {""}, {""},
#line 207 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_N9", 198},
      {""},
#line 744 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_H8", 735},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1294 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HD12", 1285},
      {""}, {""}, {""}, {""},
#line 1291 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HG22", 1282},
      {""}, {""}, {""}, {""}, {""},
#line 809 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_H5''", 800},
#line 737 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_H5''", 728},
      {""},
#line 1498 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_HXT", 1489},
      {""}, {""}, {""}, {""},
#line 1487 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_OXT", 1478},
#line 1288 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HG12", 1279},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1922 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C62", 1913},
      {""}, {""}, {""},
#line 1941 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H6", 1932},
#line 1997 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H62", 1988},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1921 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C61", 1912},
      {""}, {""}, {""}, {""},
#line 1996 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H61", 1987},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1923 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C63", 1914},
      {""}, {""}, {""}, {""},
#line 1998 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H63", 1989},
      {""},
#line 1672 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_CB", 1663},
      {""}, {""}, {""}, {""}, {""},
#line 1679 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_HB2", 1670},
      {""}, {""}, {""},
#line 796 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_C1'", 787},
#line 721 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C1'", 712},
      {""}, {""},
#line 1418 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_C", 1409},
#line 815 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_H1'", 806},
#line 743 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_H1'", 734},
      {""}, {""},
#line 1434 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_H", 1425},
#line 1432 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_H9", 1423},
#line 1678 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_HB1", 1669},
      {""}, {""}, {""},
#line 1422 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_CE", 1413},
      {""},
#line 867 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_C6", 858},
      {""}, {""}, {""}, {""},
#line 897 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_H6", 888},
#line 654 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_HOP3", 645},
      {""}, {""}, {""}, {""}, {""},
#line 1424 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_S", 1415},
#line 942 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_OP3", 933},
      {""}, {""}, {""},
#line 750 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_N1", 741},
      {""}, {""}, {""},
#line 1810 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_HOG3", 1801},
      {""}, {""}, {""}, {""},
#line 856 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H5''", 847},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1423 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_N", 1414},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 868 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6MZ_N6", 859},
#line 1784 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O2B", 1775},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1420 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_CG", 1411},
      {""}, {""}, {""}, {""},
#line 1421 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_SD", 1412},
#line 108 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_HOP3", 99},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1669 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_CA", 1660},
      {""}, {""}, {""}, {""},
#line 1677 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"UNK_HA", 1668},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1758 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_C6", 1749},
      {""}, {""},
#line 831 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C1'", 822},
#line 955 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C8", 946},
      {""}, {""}, {""},
#line 849 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H1'", 840},
#line 974 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H8", 965},
#line 1759 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GNG_O6", 1750},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1285 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_H2", 1276},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1836 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C04", 1827},
#line 215 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C2", 206},
#line 645 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_C6", 636},
      {""}, {""}, {""}, {""},
#line 235 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H22", 226},
      {""}, {""}, {""}, {""},
#line 646 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"1MG_O6", 637},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 234 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H21", 225},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 827 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C5M", 818},
      {""},
#line 2010 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H75", 2001},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 216 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_N2", 207},
      {""},
#line 2015 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H80", 2006},
      {""},
#line 195 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_P", 186},
      {""}, {""}, {""}, {""},
#line 105 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_C6", 96},
      {""}, {""},
#line 27 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_C6", 18},
      {""},
#line 118 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"CCC_H6", 109},
      {""}, {""}, {""},
#line 45 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H62", 36},
      {""}, {""},
#line 692 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C4", 683},
      {""}, {""}, {""}, {""},
#line 1898 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C47", 1889},
      {""}, {""}, {""}, {""},
#line 1982 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H47", 1973},
#line 1087 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_C", 1078},
#line 44 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_H61", 35},
      {""}, {""},
#line 1899 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O47", 1890},
#line 1091 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_H", 1082},
      {""}, {""}, {""}, {""},
#line 1088 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_O", 1079},
      {""}, {""}, {""},
#line 197 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_OP2", 188},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 196 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_OP1", 187},
#line 28 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"A_N6", 19},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 194 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_OP3", 185},
      {""},
#line 1880 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C37", 1871},
      {""}, {""}, {""},
#line 1085 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_N", 1076},
#line 1972 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H37", 1963},
      {""}, {""}, {""}, {""},
#line 1881 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O37", 1872},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1802 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_C6", 1793},
      {""}, {""},
#line 1435 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_H2", 1426},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1803 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O6", 1794},
#line 807 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_HOP3", 798},
#line 735 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_HOP3", 726},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 691 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_N3", 682},
      {""}, {""}, {""}, {""},
#line 685 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C5", 676},
      {""}, {""}, {""}, {""},
#line 1915 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C57", 1906},
#line 924 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HOP2", 915},
      {""}, {""}, {""},
#line 1992 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H57", 1983},
      {""}, {""},
#line 1296 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HXT", 1287},
      {""},
#line 1916 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O57", 1907},
      {""}, {""},
#line 1283 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_OXT", 1274},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1785 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O3A", 1776},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 997 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_C6", 988},
      {""}, {""}, {""}, {""},
#line 1011 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DC_H6", 1002},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 858 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_HOP3", 849},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 67 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_C6", 58},
      {""}, {""}, {""}, {""},
#line 81 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"C_H6", 72},
      {""}, {""},
#line 2013 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H78", 2004},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1389 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_CB", 1380},
      {""}, {""}, {""}, {""}, {""},
#line 1402 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HB2", 1393},
      {""}, {""}, {""}, {""}, {""},
#line 914 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_N7", 905},
      {""}, {""}, {""},
#line 1228 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_C", 1219},
      {""}, {""}, {""}, {""},
#line 1231 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_H", 1222},
      {""}, {""}, {""}, {""},
#line 1229 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_O", 1220},
      {""}, {""}, {""}, {""},
#line 1837 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C05", 1828},
#line 804 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_C6", 795},
#line 726 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_C6", 717},
      {""}, {""},
#line 1403 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HB3", 1394},
#line 818 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_H6", 809},
      {""}, {""}, {""}, {""}, {""},
#line 727 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MG_O6", 718},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1226 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_N", 1217},
      {""}, {""}, {""}, {""}, {""},
#line 1438 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_HXT", 1429},
      {""}, {""}, {""}, {""},
#line 1437 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_OXT", 1428},
      {""}, {""}, {""},
#line 782 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_HOP2", 773},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 289 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_C6", 280},
      {""},
#line 1388 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_CA", 1379},
      {""}, {""}, {""}, {""},
#line 1401 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HA", 1392},
      {""}, {""},
#line 290 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"I_O6", 281},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1092 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_H2", 1083},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 828 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_C6", 819},
      {""}, {""}, {""}, {""},
#line 848 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MU_H6", 839},
      {""},
#line 1480 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_CB", 1471},
      {""}, {""}, {""}, {""}, {""},
#line 1491 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_HB2", 1482},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 707 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_HM23", 698},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1492 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_HB3", 1483},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 905 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C4'", 896},
      {""}, {""}, {""}, {""},
#line 928 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_H4'", 919},
      {""}, {""}, {""}, {""},
#line 906 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_O4'", 897},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 2026 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H89", 2017},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1477 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_CA", 1468},
      {""},
#line 907 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C3'", 898},
      {""}, {""},
#line 1490 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PHE_HA", 1481},
#line 679 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C2'", 670},
#line 929 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_H3'", 920},
      {""}, {""}, {""},
#line 700 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_H2'", 691},
#line 908 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_O3'", 899},
      {""}, {""}, {""},
#line 680 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_O2'", 671},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1841 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C08", 1832},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 932 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HO2'", 923},
      {""}, {""}, {""}, {""}, {""},
#line 904 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C5'", 895},
      {""}, {""}, {""}, {""},
#line 926 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_H5'", 917},
      {""}, {""}, {""}, {""},
#line 903 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_O5'", 894},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 930 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HO3'", 921},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1097 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_HXT", 1088},
      {""}, {""}, {""}, {""},
#line 1090 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_OXT", 1081},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1232 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_H2", 1223},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1920 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C60", 1911},
      {""}, {""}, {""}, {""},
#line 1995 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H60", 1986},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 120 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_C2", 111},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 125 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_O2", 116},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 762 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_C4'", 753},
      {""}, {""}, {""}, {""},
#line 778 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_H4'", 769},
      {""}, {""}, {""}, {""},
#line 764 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_O4'", 755},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1563 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"SEP_HOP3", 1554},
      {""},
#line 136 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_P", 127},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 761 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_C3'", 752},
      {""}, {""}, {""}, {""},
#line 777 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_H3'", 768},
      {""}, {""}, {""}, {""},
#line 763 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_O3'", 754},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 138 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_OP2", 129},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 137 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_OP1", 128},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 776 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_HO2'", 767},
      {""},
#line 944 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_OP1", 935},
      {""},
#line 173 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_C6", 164},
      {""},
#line 765 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_C5'", 756},
      {""},
#line 139 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_OP3", 130},
      {""}, {""},
#line 780 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_H5'", 771},
      {""}, {""},
#line 174 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G_O6", 165},
      {""},
#line 766 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_O5'", 757},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 779 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_HO3'", 770},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 2031 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H96", 2022},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 2019 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H84", 2010},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1235 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_HXT", 1226},
      {""},
#line 600 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_C4'", 591},
      {""}, {""},
#line 1230 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_OXT", 1221},
      {""},
#line 619 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_H4'", 610},
      {""}, {""}, {""}, {""},
#line 601 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_O4'", 592},
      {""}, {""},
#line 1415 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HH23", 1406},
      {""}, {""}, {""}, {""}, {""},
#line 1279 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_CB", 1270},
      {""}, {""}, {""}, {""},
#line 1287 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HB", 1278},
      {""}, {""}, {""},
#line 1412 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MLY_HH13", 1403},
#line 1703 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_C", 1694},
      {""}, {""}, {""}, {""},
#line 1718 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H", 1709},
#line 1723 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H9", 1714},
      {""}, {""}, {""},
#line 1704 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_O", 1695},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1736 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"NA_NA", 1727},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1706 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_N", 1697},
#line 1710 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_CD", 1701},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1711 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_NE", 1702},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1709 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_CG", 1700},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1276 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_CA", 1267},
      {""}, {""}, {""}, {""},
#line 1286 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HA", 1277},
      {""}, {""}, {""},
#line 548 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"PPU_HN'3", 539},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 923 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_CM7", 914},
      {""}, {""}, {""}, {""}, {""},
#line 939 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HM71", 930},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 940 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HM72", 931},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1419 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_CB", 1410},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1713 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_NH2", 1704},
      {""}, {""}, {""}, {""},
#line 1849 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C17", 1840},
      {""}, {""}, {""}, {""},
#line 1952 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H17", 1943},
      {""}, {""}, {""}, {""},
#line 1714 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_NH1", 1705},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 688 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_N1", 679},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1934 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C69", 1925},
      {""}, {""}, {""}, {""},
#line 2004 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H69", 1995},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1787 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O1A", 1778},
#line 1864 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C26", 1855},
      {""}, {""}, {""}, {""},
#line 1961 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H26", 1952},
      {""}, {""}, {""}, {""},
#line 1865 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O26", 1856},
      {""},
#line 1417 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_CA", 1408},
      {""}, {""}, {""}, {""},
#line 1425 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_HA", 1416},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 2021 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H85", 2012},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 599 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_C5'", 590},
      {""}, {""}, {""},
#line 1712 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_CZ", 1703},
#line 617 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_H5'", 608},
      {""}, {""}, {""}, {""},
#line 598 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_O5'", 589},
      {""}, {""}, {""}, {""}, {""},
#line 937 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HN21", 928},
      {""}, {""}, {""}, {""},
#line 618 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_H5''", 609},
      {""}, {""},
#line 816 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_HN41", 807},
      {""}, {""}, {""}, {""}, {""},
#line 936 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HN1", 927},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1717 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H2", 1708},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 938 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HN22", 929},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 817 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"5MC_HN42", 808},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1089 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_CB", 1080},
      {""}, {""}, {""}, {""}, {""},
#line 1095 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_HB2", 1086},
      {""}, {""},
#line 1812 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_HOA2", 1803},
      {""}, {""}, {""}, {""},
#line 1781 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O3B", 1772},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1094 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_HB1", 1085},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 970 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_HO3'", 961},
      {""}, {""}, {""},
#line 1096 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_HB3", 1087},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1295 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HD13", 1286},
      {""}, {""}, {""}, {""},
#line 1292 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HG23", 1283},
      {""},
#line 913 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C8", 904},
      {""}, {""}, {""}, {""}, {""},
#line 935 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_H82", 926},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1289 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ILE_HG13", 1280},
      {""}, {""}, {""}, {""},
#line 218 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C4", 209},
      {""},
#line 956 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_N7", 947},
#line 934 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_H81", 925},
      {""}, {""}, {""}, {""},
#line 927 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_H5''", 918},
#line 771 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_HN3", 762},
#line 1086 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_CA", 1077},
#line 2022 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H88", 2013},
      {""}, {""}, {""},
#line 1093 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"ALA_HA", 1084},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1729 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_HXT", 1720},
      {""}, {""}, {""}, {""},
#line 1715 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_OXT", 1706},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1924 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C64", 1915},
      {""}, {""}, {""}, {""},
#line 1999 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H64", 1990},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 911 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C1'", 902},
      {""}, {""}, {""}, {""},
#line 933 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_H1'", 924},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 217 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_N3", 208},
      {""}, {""}, {""}, {""},
#line 211 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C5", 202},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1686 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_C", 1677},
      {""}, {""}, {""}, {""},
#line 1692 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_H", 1683},
      {""}, {""}, {""}, {""},
#line 1687 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_O", 1678},
#line 1427 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_H4", 1418},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 967 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H5''", 958},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1684 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_N", 1675},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 781 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_H5''", 772},
#line 1690 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_CG2", 1681},
      {""}, {""}, {""}, {""}, {""},
#line 1699 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_HG21", 1690},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1689 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_CG1", 1680},
      {""}, {""}, {""}, {""}, {""},
#line 1696 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_HG11", 1687},
      {""}, {""}, {""},
#line 693 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_HOP2", 684},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1700 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_HG22", 1691},
      {""},
#line 1227 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_CA", 1218},
      {""}, {""}, {""}, {""}, {""},
#line 1233 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_HA2", 1224},
      {""},
#line 1428 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_H5", 1419},
      {""}, {""}, {""}, {""},
#line 1697 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_HG12", 1688},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 758 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_C1'", 749},
      {""}, {""},
#line 1234 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GLY_HA3", 1225},
      {""},
#line 774 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_H1'", 765},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 2012 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H77", 2003},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 684 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_N7", 675},
      {""}, {""}, {""}, {""},
#line 1925 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C65", 1916},
      {""}, {""}, {""}, {""},
#line 2000 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H65", 1991},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1926 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_N65", 1917},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 925 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HOP3", 916},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1693 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_H2", 1684},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 204 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C2'", 195},
      {""}, {""}, {""}, {""},
#line 226 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H2'", 217},
      {""}, {""}, {""}, {""},
#line 205 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_O2'", 196},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 675 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C4'", 666},
      {""}, {""}, {""}, {""},
#line 697 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_H4'", 688},
      {""}, {""}, {""}, {""},
#line 676 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_O4'", 667},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 916 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_C6", 907},
      {""}, {""}, {""},
#line 677 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C3'", 668},
      {""}, {""}, {""}, {""},
#line 698 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_H3'", 689},
#line 917 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_O6", 908},
      {""}, {""}, {""},
#line 678 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_O3'", 669},
      {""}, {""}, {""}, {""},
#line 1840 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C07", 1831},
      {""}, {""}, {""}, {""},
#line 1933 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C68", 1924},
      {""}, {""},
#line 783 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_HOP3", 774},
      {""},
#line 2003 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H68", 1994},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 701 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_HO2'", 692},
      {""}, {""}, {""}, {""}, {""},
#line 674 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C5'", 665},
      {""}, {""}, {""}, {""},
#line 695 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_H5'", 686},
      {""}, {""}, {""}, {""},
#line 673 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_O5'", 664},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 699 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_HO3'", 690},
      {""},
#line 122 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_C4", 113},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 126 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_O4", 117},
      {""}, {""}, {""},
#line 1702 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_HXT", 1693},
      {""}, {""}, {""}, {""},
#line 1691 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_OXT", 1682},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1707 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_CB", 1698},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1708 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_OB", 1699},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 121 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_N3", 112},
      {""}, {""}, {""}, {""},
#line 123 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_C5", 114},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 755 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_C6", 746},
      {""}, {""}, {""}, {""},
#line 773 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4SU_H6", 764},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1705 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_CA", 1696},
      {""}, {""}, {""}, {""},
#line 1716 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_HA", 1707},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1783 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_O1B", 1774},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 233 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H1", 224},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 214 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_N1", 205},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1811 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"GTP_HOB2", 1802},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1426 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_H1", 1417},
      {""}, {""},
#line 1896 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C46", 1887},
      {""}, {""},
#line 128 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_C2'", 119},
      {""},
#line 1981 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H46", 1972},
      {""}, {""},
#line 146 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_H2'", 137},
      {""},
#line 1897 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O46", 1888},
      {""}, {""},
#line 129 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_O2'", 120},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1879 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C36", 1870},
      {""}, {""}, {""}, {""},
#line 1971 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H36", 1962},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1914 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C56", 1905},
      {""}, {""}, {""}, {""},
#line 1991 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H56", 1982},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 941 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"7MG_HM73", 932},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1719 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H5", 1710},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1688 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_CB", 1679},
      {""}, {""}, {""}, {""},
#line 1695 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_HB", 1686},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 683 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C8", 674},
      {""}, {""}, {""}, {""},
#line 703 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_H8", 694},
      {""}, {""}, {""}, {""},
#line 2024 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H87", 2015},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 696 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_H5''", 687},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1685 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_CA", 1676},
      {""}, {""}, {""}, {""},
#line 1694 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_HA", 1685},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 681 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C1'", 672},
      {""}, {""}, {""}, {""},
#line 702 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_H1'", 693},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 220 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_HOP2", 211},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 209 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_N7", 200},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 119 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_N1", 110},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1430 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_H7", 1421},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 694 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_HOP3", 685},
      {""}, {""}, {""},
#line 200 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C4'", 191},
      {""}, {""}, {""}, {""},
#line 223 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H4'", 214},
      {""},
#line 1701 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_HG23", 1692},
      {""}, {""},
#line 201 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_O4'", 192},
      {""}, {""},
#line 140 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_F5", 131},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1698 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"VAL_HG13", 1689},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 202 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C3'", 193},
      {""}, {""}, {""}, {""},
#line 224 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H3'", 215},
      {""}, {""}, {""}, {""},
#line 203 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_O3'", 194},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 227 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_HO2'", 218},
      {""}, {""}, {""}, {""}, {""},
#line 199 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C5'", 190},
      {""}, {""}, {""}, {""},
#line 221 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H5'", 212},
      {""}, {""}, {""}, {""},
#line 198 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_O5'", 189},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 225 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_HO3'", 216},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1433 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_H10", 1424},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 686 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_C6", 677},
      {""}, {""}, {""}, {""},
#line 1931 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C67", 1922},
#line 704 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_H62", 695},
      {""}, {""},
#line 614 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_C6", 605},
#line 2002 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H67", 1993},
      {""}, {""}, {""},
#line 627 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"U_H6", 618},
#line 1932 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O67", 1923},
      {""}, {""}, {""}, {""}, {""},
#line 708 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_H61", 699},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 687 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"2MA_N6", 678},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1848 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C16", 1839},
      {""}, {""}, {""}, {""},
#line 1951 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H16", 1942},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1726 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H12", 1717},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1725 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H11", 1716},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 153 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_HOP2", 144},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 958 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_C6", 949},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 959 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_N6", 950},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 131 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_C4'", 122},
      {""}, {""}, {""}, {""},
#line 149 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_H4'", 140},
      {""}, {""}, {""}, {""},
#line 133 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_O4'", 124},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 130 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_C3'", 121},
      {""}, {""}, {""}, {""},
#line 148 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_H3'", 139},
      {""}, {""}, {""}, {""},
#line 132 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_O3'", 123},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 147 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_HO2'", 138},
      {""}, {""}, {""}, {""}, {""},
#line 134 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_C5'", 125},
      {""}, {""}, {""}, {""},
#line 151 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_H5'", 142},
      {""}, {""}, {""}, {""},
#line 135 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_O5'", 126},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 150 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_HO3'", 141},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 976 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H62", 967},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 208 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C8", 199},
      {""}, {""}, {""}, {""},
#line 229 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H8", 220},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 2011 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H76", 2002},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 222 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H5''", 213},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 1436 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_H14", 1427},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1721 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H7", 1712},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 206 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C1'", 197},
      {""}, {""}, {""}, {""},
#line 228 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_H1'", 219},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 1431 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_H8", 1422},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1838 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C06", 1829},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 1724 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H10", 1715},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 219 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_HOP3", 210},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 142 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_HN1", 133},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 143 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_HN3", 134},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 212 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_C6", 203},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 213 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_O6", 204},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 152 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_H5''", 143},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 1429 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"MS6_H6", 1420},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
#line 127 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_C1'", 118},
      {""}, {""}, {""}, {""},
#line 145 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_H1'", 136},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 154 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_HOP3", 145},
      {""},
#line 1727 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H14", 1718},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 2020 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H86", 2011},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1722 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H8", 1713},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 124 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_C6", 115},
      {""}, {""}, {""}, {""},
#line 144 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_H6", 135},
      {""}, {""}, {""}, {""},
#line 141 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_O6", 132},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 1728 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H15", 1719},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 1929 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_C66", 1920},
      {""}, {""}, {""}, {""},
#line 2001 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_H66", 1992},
      {""}, {""}, {""}, {""},
#line 1930 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"6O1_O66", 1921},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
#line 1720 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"4D4_H6", 1711},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
#line 975 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"DA_H61", 966},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
#line 210 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_CN7", 201},
      {""}, {""}, {""}, {""}, {""},
#line 230 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_HN71", 221},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
#line 231 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_HN72", 222},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
#line 232 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"G7M_HN73", 223},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
#line 155 "/home/runner/work/ciffy/ciffy/ciffy/src/hash/atom.gperf"
      {"FHU_HO6", 146}
    };

  if (len <= ATOMMAX_WORD_LENGTH && len >= ATOMMIN_WORD_LENGTH)
    {
      register unsigned int key = _hash_atom (str, len);

      if (key <= ATOMMAX_HASH_VALUE)
        {
          register const char *s = wordlist[key].name;

          if (*str == *s && !strcmp (str + 1, s + 1))
            return &wordlist[key];
        }
    }
  return 0;
}
