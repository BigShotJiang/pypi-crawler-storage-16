'''These methods are imported and is therfore identical to what is provided in
the QHA distribution.
'''

from qha.basic_io.out import save_x_tp, save_x_pt, save_x_vt, save_x_tv

__all__ = [
    "save_x_tp", "save_x_pt", "save_x_vt", "save_x_tv"
]