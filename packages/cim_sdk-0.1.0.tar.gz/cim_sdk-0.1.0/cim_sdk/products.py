from typing import Any, Dict

from .subapi import CimSubAPI


class ProductsAPI(CimSubAPI):
    """
    产品相关接口（预留，将来你有 /product/... 之类的接口再慢慢加）
    """

    # 示例：将来可以加
    # def get_product(self, item_no: str) -> Dict[str, Any]:
    #     return self._request("GET", f"/product/detail/{item_no}")
