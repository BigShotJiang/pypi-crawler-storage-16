Type mapper
===========


.. automodule:: cimsparql.type_mapper
   :members:
   :undoc-members:
   :show-inheritance:
