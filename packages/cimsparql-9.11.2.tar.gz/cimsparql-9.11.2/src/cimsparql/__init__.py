"""Library for CIM sparql queries."""

__version__ = "0.0.0"
