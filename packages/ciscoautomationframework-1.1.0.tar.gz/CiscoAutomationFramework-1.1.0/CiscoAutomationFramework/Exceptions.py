
class EnablePasswordError(Exception):
    pass


class ParserError(Exception):
    pass


class AuthenticationException(Exception):
    pass

class ForbiddenError(Exception):
    pass