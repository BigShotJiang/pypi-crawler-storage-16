from ipaddress import ip_address, IPv4Network, AddressValueError
from collections import OrderedDict


def abbreviate_interface(interface_string, max_chars=2):
    """
    Takes an Interface name ex. GigabitEthernet1/0/4 and abbreviates it ex Gi1/0/4

    :param interface_string: Interface String ex. GigabitEthernet1/0/4
    :type interface_string: str
    :param
    :return: Abbreviated interface string
    :rtype: str
    """
    return interface_string[:max_chars] + ''.join([char for char in interface_string if not char.isalpha()])


def is_ipv4(addr):
    '''
    Checks if the IP address provided is an IPv4 Address.

    :param addr: IP address to check
    :type addr: str
    :return: True/False
    :rtype: bool
    '''
    try:
        _ = ip_address(addr)
        return True
    except:
        return False


def is_ipv4_subnet(string):
    '''
    Checks if a string that you pass in is a representation of an IPv4 Subnet ex. 192.168.10.0/24, 10.0.0.0/8, 0.0.0.0/0.

    :param string: String to check
    :type string: str
    :return: True/False
    :rtype: bool
    '''
    try:
        IPv4Network(string)
        return True
    except AddressValueError:
        return False


def column_print(data, spaces_between_columns=2, separator_char=None):
    """
    Print in nice even columns where each column is only the width it needs to be, not the width of the
    widest column in the list. This will give output in a table format similar to much Windows/Linux
    CLI output.
    Based off of code from https://stackoverflow.com/questions/9989334/create-nice-column-output-in-python

    :param data: List of List/Tuples of equal length, the first list being the header, all the rest being the data.
    :type data: list[Union[list, tuple]]
    :param spaces_between_columns: Number of spaces to be between each column (default 2)
    :type spaces_between_columns: int
    :param separator_char: Character to place in a row between the header and data, default to nothing
    :type separator_char: str
    :return: Nothing. This function executes the print
    """
    # Get the max width of each column
    column_widths = []
    for index, _ in enumerate(data[0]):
        column_widths.append(max(len(str(row[index])) for row in data) + spaces_between_columns)

    # reconstruct list if a separator character is specified to be placed between the header and data
    if separator_char and type(separator_char) is str and len(separator_char) == 1:
        separator_line = [[separator_char * (x - spaces_between_columns) for x in column_widths]]
        first_line = data[:1]
        rest = data[1:]
        data = first_line + separator_line + rest


    # construct a string where each column is its own max width and print the line out when completed.
    for row in data:
        print_string = ''
        for index, word in enumerate(row):
            print_string += str(word).ljust(column_widths[index])
        print(print_string)

def chunker(list, size):
    """
    Splits 1 large list into a list sub lists, where the sub lists can be any specific size
    """
    # looping till length l
    end_list = []
    for i in range(0, len(list), size):
        end_list.append(list[i:i + size])
    return end_list


def matches_search_terms(key, search_terms, case_sensitive, full_match):
    """Checks if the key matches any search term based on given options."""
    if not case_sensitive:
        key = key.lower()
        search_terms_lower = [term.lower() for term in search_terms]
    else:
        search_terms_lower = search_terms

    for term in search_terms_lower:

        if full_match:
            if key == term:  # Exact match
                return True
        else:
            if term in key:  # Partial match
                return True
    return False


def indented_text_to_tree(config):
    """
    Takes in a string/list that is formatted in a heiarchy by indents similar to below
    line one
     line two
     line three
      line four
    line five

    And parses it based on the indents, Can be arbitrary

    This is used to parse the running/startup config. Also useful for parsing things like "show interfaces" output.
    """
    if type(config) == str:
        config = config.splitlines()

    tree = OrderedDict()
    stack = [(0, tree)]  # (indent_level, node)

    for line in config:
        if not line.strip():
            continue  # skip empty lines

        text = line.lstrip()
        indent = len(line) - len(text)

        current_node = OrderedDict()

        # If indent is 0, reset to root
        if indent == 0:
            parent = tree
            stack = [(0, tree)]
        else:
            # Walk back up until we find a parent with less indent
            while stack and stack[-1][0] >= indent:
                stack.pop()

            if not stack:
                raise ValueError(f"Invalid indentation or format at line: {line}")

            parent = stack[-1][1]

        parent[text.strip()] = current_node
        stack.append((indent, current_node))

    return tree


def convert_config_tree_to_list(tree, indent=0, indent_step=0):
    """
    Converts a tree representation of the configuration into a list that can be pasted
    into a device

    :param tree: Tree representation of a configuration file
    :type tree: dict
    :param indent: number of spaces to indent root with
    :type indent: int
    :param indent_step: number of indent spaces to increment when going from a root to a branch (default 0, no indent)

    :return: List representation of config tree
    :rtype: list
    """
    data = []
    for key, subtree in tree.items():
        data.append(f'{" " * (indent * indent_step)}{key}')
        if isinstance(subtree, dict) and subtree:
            data.extend(convert_config_tree_to_list(subtree, indent + 1, indent_step))
    return data

def search_and_modify_config_tree(tree, search_terms, case_sensitive=True, full_match=False, min_search_depth=0,
                                  max_search_depth=0, prepend_text='', append_text='',
                                  replace_tuple=('', ''), modifier_callback=None, prematch_extend_callback=None,
                                  postmatch_extend_callback=None, _depth=0):
    """
    Searches the config tree for a set of search terms, and if specified will run each line that matches
    a search term through a modification algorithm to prepend, append, and find/replace specified text on that line.

    Modification will ONLY occur to lines that CONTAIN a match! if you search for "description example" it will
    also return in the tree the interface name ex. interface GigabitEthernet1/0/1, however that line will NOT
    be eligible for the string modification because it does not contain "description example".

    Additionally using that same interface example, the interface will likely have other config besides the
    description, but if you search for the description, all other commands in that layer of the tree will
    not be returned, just the path up to the root which in this case is the interface name.

    You may also specify if you want your search to be case sensitive, and you may also specify if you want
    a full or partial match. For example if I do a full match for "description" but the line of configuration
    is "description example" it will NOT match. Also if I do a partial match (by setting full match to false) for
    "descrip", and the line is "description example" it WILL match.

    If the integrated prepend, append, or replace functionality does not provide enough flexibility
    in terms of modification, you can pass in a modifier_callback function and implement your own modification
    algorthm. One thing to note is the function you pass in MUST accept a single argument as the line which
    matches your search term will be passed in. Keep in mind the prepend, append, and modify will still run after
    your modifier_callback runs. Your modifier callback will overwrite all lines that are passed into it so make
    sure that you take into account that every match will be run through your modifier_callback and will be
    overwritten with whatever your modifier_callback returns

    If you need to add additional lines to the configuration before and/or after the match line you also have
    the ability to pass in a "pre_extend_callback" to extend a single or multiple lines before the match line
    and a "post_extend_callback" function to extend a single or multiple lines after the match line.
    Both of these user defined functions MUST accept a single argument which will be the matched line, and
    you may return a single string, list of strings, and tuple of strings to extend the config.
    Unlike the modifier_callback, the integrated prepend, append, and find/replace features of this function
    will NOT be applied to what is returned by the pre/post_extend_callback functions.

    These functions are especially useful when generating change configuration where you need to "no" the
    command and re apply it with different paramaters

    Keep in mind when using the postmatch_extend_callback, if your match line has nested configuration under
    it such as the following example matching "router bgp":
    router bgp 65000
     nested config1
     nested config2
      nested config3
    and your post match callback returns "Post Match Line" it would come after the last line of nested config
    on the same level as your match line such as below:

    router bgp 65000
     nested config1
     nested config2
      nested config3
    Post Match Line

    :param search_terms: List of search terms to search for.
    :type search_terms: list
    :param case_sensitive: Whether the search is case-sensitive.
    :type case_sensitive: bool
    :default case_sensitive: True
    :param full_match: If True, matches the whole word exactly; else, allows partial matches.
    :type full_match: bool
    :default full_match: False
    :param prepend_text: Text to prepend to matches.
    :type prepend_text: str
    :default prepend_text: ""
    :param append_text: Text to append to matches.
    :type append_text: str
    :default append_text: ""
    :param replace_tuple: A tuple (old_text, new_text) for replacing matches.
    :type replace_tuple: tuple or None
    :default replace_tuple: None
    :param modifier_callback: User defined function to call whenever a line matches search terms, MUST accept a single argument as the matching line of config will be passed in.
    :type modifier_callback: function
    :default modifier_callback: None
    :param prematch_extend_callback: User defined function to insert a line or multiple lines before the match line. User defined function may return string, list, or tuple.
    :type prematch_extend_callback: function
    :param postmatch_extend_callback: User defined function to insert a line or multiple lines after the match line. User defined function may return string, list, or tuple.
    :type postmatch_extend_callback: function
    :param tree: The configuration tree to search. Do not specify this, its only used for recursion
    :type tree: dict or None
    :default tree: None

    :return: A dictionary containing matched and modified results.
    :rtype: dict
    """

    if not any([isinstance(search_terms, x) for x in (list, tuple)]):
        search_terms = [search_terms]
        # raise TypeError('search_terms MUST be a list or tuple')

    data = OrderedDict()
    for key, sub_tree in tree.items():
        if matches_search_terms(key, search_terms, case_sensitive, full_match):
            if _depth >= min_search_depth and (max_search_depth == 0 or _depth < max_search_depth):

                # Handle pre extend callback
                before_lines = []
                if prematch_extend_callback:
                    result = prematch_extend_callback(key)

                    if isinstance(result, str):
                        before_lines.append(result)

                    elif isinstance(result, list):
                        before_lines.extend(result)

                    elif isinstance(result, tuple):
                        before_lines.extend(result)

                    elif result is not None:
                        raise TypeError("pre_extend_callback must return a string, list, or None")

                # Handle modifier callback if defined
                modified_line = key
                if modifier_callback:
                    result = modifier_callback(key)

                    if not isinstance(result, str):
                        raise TypeError("modifier_callback MUST return a single string")

                    modified_line = result

                # Handle post extend callback if defined
                after_lines = []
                if postmatch_extend_callback:
                    result = postmatch_extend_callback(key)

                    if isinstance(result, str):
                        after_lines.append(result)

                    elif isinstance(result, list):
                        after_lines.extend(result)

                    elif isinstance(result, tuple):
                        after_lines.extend(result)

                    elif result is not None:
                        raise TypeError("post_extend_callback must return a string, list, or None")

                # Construct config
                for entry in before_lines:
                    data[entry] = OrderedDict()

                # Apply built-in modifications ONLY to the modified line
                main_entry = f"{prepend_text}{modified_line.replace(*replace_tuple)}{append_text}"
                data[main_entry] = sub_tree

                for entry in after_lines:
                    data[entry] = OrderedDict()

        elif isinstance(sub_tree, dict) and sub_tree:
            path = search_and_modify_config_tree(sub_tree, search_terms, case_sensitive, full_match, min_search_depth,
                                                 max_search_depth, prepend_text, append_text, replace_tuple,
                                                 modifier_callback, prematch_extend_callback, postmatch_extend_callback,
                                                 _depth + 1)
            if path:
                data[key] = path
    return data


def search_config_tree(tree, search_terms, case_sensitive=True, full_match=False, min_search_depth=0, max_search_depth=0, _depth=0):
    """

    Searches the config tree for a set of search terms and returns the path to root for that match and any sub
    branchs under the match. Note: if a match is found, and there are other branches in that same level that dont
    match, it will not return any of the other branches. For example if you search for an IP address and it is found
    in an interface, it wont also return the description if there is one, but it will return the "interface x".

    You may also specify if you want your search to be case sensitive, and you may also specify if you want
    a full or partial match. For example if I do a full match for "description" but the line of configuration
    is "description example" it will NOT match. Also if I do a partial match (by setting full match to false) for
    "descrip", and the line is "description example" it WILL match.

    You can also specify the minimum depth to search the tree, for example using the config below searching for
    "router bgp" will not yield any results, searching "vrf MYVRF" will yield results, but searching "vrf MYVRF"
    with a nest_level of 1 will NOT because it is nested once, and you specified to not return any matches at or
    below index 1:
    router bgp 65000
     ipv4 vrf MYVRF
      network 10.0.0.0

    You can also


    :param tree: The configuration tree to search.
    :type tree: dict or None
    :param search_terms: List of search terms to search for.
    :type search_terms: list
    :param min_search_depth: Minimum depth at which to return search results if matches are found (0 returns anything, 1 excludes root, 2 excludes root and 1st nest level)
    :type min_search_depth: int
    :param max_search_depth: Maximum depth at which to return search results if matches are found (0 infinite [default], only includes root, 2 excludes root and 1st nest level).
    :type max_search_depth: int
    :default max_search_depth: 0
    :param case_sensitive: Whether the search is case-sensitive.
    :type case_sensitive: bool
    :default case_sensitive: True
    :param full_match: If True, matches the whole word exactly; else, allows partial matches.
    :type full_match: bool

    :return: A dictionary containing matched and modified results.
    :rtype: dict
    """
    if not any([isinstance(search_terms, x) for x in (list, tuple)]):
        search_terms = [search_terms]
        # raise TypeError('search_terms MUST be a list or tuple')

    data = {}
    for key, sub_tree in tree.items():
        if matches_search_terms(key, search_terms, case_sensitive, full_match):
            # only capture results that are between the min/max search depth variables, 0 max is infinite
            if _depth >= min_search_depth and (max_search_depth == 0 or _depth < max_search_depth):
                data[key] = sub_tree
        elif isinstance(sub_tree, dict) and sub_tree:
            path = search_config_tree(sub_tree, search_terms, case_sensitive, full_match, min_search_depth, max_search_depth, _depth+1)
            if path:
                data[key] = path
    return data

def modify_config_tree_inline(tree, search_terms, case_sensitive=True, full_match=False, min_search_depth=0,
                              max_search_depth=0, prepend_text='', append_text='',
                              replace_tuple=('', ''), modifier_callback=None,
                              prematch_extend_callback=None, postmatch_extend_callback=None,
                              _depth=0):
    """
    Searches the config tree for a set of search terms, and any match will be eligible for modification.
    Any line that DOES not match the search terms will still be returned, but not eligible to be modified by
    the modification arguments that are passed in. THis allows you to modify only certain config but return the
    entire config tree that was passed in.

    This function is very similar to search_and_modify_config_tree but instead of only returning the matches
    and the outdened path to the root, it will return everything that was passed in, but still only allowing
    modification of lines that contain the search_terms matches

    Modification will ONLY occur to lines that CONTAIN a match! if you search for "description example" it will
    also return in the tree the interface name ex. interface GigabitEthernet1/0/1, however that line will NOT
    be eligible for the string modification because it does not contain "description example".

    Additionally using that same interface example, the interface will likely have other config besides the
    description, but if you search for the description, all other commands in that layer of the tree will
    not be returned, just the path up to the root which in this case is the interface name.

    You may also specify if you want your search to be case sensitive, and you may also specify if you want
    a full or partial match. For example if I do a full match for "description" but the line of configuration
    is "description example" it will NOT match. Also if I do a partial match (by setting full match to false) for
    "descrip", and the line is "description example" it WILL match.

    If the integrated prepend, append, or replace functionality does not provide enough flexibility
    in terms of modification, you can pass in a modifier_callback function and implement your own modification
    algorthm. One thing to note is the function you pass in MUST accept a single argument as the line which
    matches your search term will be passed in. Keep in mind the prepend, append, and modify will still run after
    your modifier_callback runs. Your modifier callback will overwrite all lines that are passed into it so make
    sure that you take into account that every match will be run through your modifier_callback and will be
    overwritten with whatever your modifier_callback returns

    If you need to add additional lines to the configuration before and/or after the match line you also have
    the ability to pass in a "pre_extend_callback" to extend a single or multiple lines before the match line
    and a "post_extend_callback" function to extend a single or multiple lines after the match line.
    Both of these user defined functions MUST accept a single argument which will be the matched line, and
    you may return a single string, list of strings, and tuple of strings to extend the config.
    Unlike the modifier_callback, the integrated prepend, append, and find/replace features of this function
    will NOT be applied to what is returned by the pre/post_extend_callback functions.

    These functions are especially useful when generating change configuration where you need to "no" the
    command and re apply it with different paramaters

    Keep in mind when using the postmatch_extend_callback, if your match line has nested configuration under
    it such as the following example matching "router bgp":
    router bgp 65000
     nested config1
     nested config2
      nested config3
    and your post match callback returns "Post Match Line" it would come after the last line of nested config
    on the same level as your match line such as below:

    router bgp 65000
     nested config1
     nested config2
      nested config3
    Post Match Line


    :param search_terms: List of search terms to search for.
    :type search_terms: list
    :param case_sensitive: Whether the search is case-sensitive.
    :type case_sensitive: bool
    :default case_sensitive: True
    :param full_match: If True, matches the whole word exactly; else, allows partial matches.
    :type full_match: bool
    :default full_match: False
    :param prepend_text: Text to prepend to matches.
    :type prepend_text: str
    :default prepend_text: ""
    :param append_text: Text to append to matches.
    :type append_text: str
    :default append_text: ""
    :param replace_tuple: A tuple (old_text, new_text) for replacing matches.
    :type replace_tuple: tuple or None
    :default replace_tuple: None
    :param modifier_callback: User defined function to call whenever a line matches search terms, MUST accept a single argument as the matching line of config will be passed in.
    :type modifier_callback: function
    :param prematch_extend_callback: User defined function to insert a line or multiple lines before the match line. User defined function may return string, list, or tuple.
    :type prematch_extend_callback: function
    :param postmatch_extend_callback: User defined function to insert a line or multiple lines after the match line. User defined function may return string, list, or tuple.
    :type postmatch_extend_callback: function
    :default modifier_callback: None
    :param tree: The configuration tree to search. Do not specify this, its only used for recursion
    :type tree: dict or None
    :default tree: None

    :return: A dictionary containing matched and modified results.
    :rtype: dict
    """

    if not any([isinstance(search_terms, x) for x in (list, tuple)]):
        search_terms = [search_terms]

    data = OrderedDict()
    for key, sub_tree in tree.items():

        if matches_search_terms(key, search_terms, case_sensitive, full_match) \
           and (_depth >= min_search_depth and (max_search_depth == 0 or _depth < max_search_depth)):

            #handle pre extend if it is passed in
            before_lines = []
            if prematch_extend_callback:
                result = prematch_extend_callback(key)
                if isinstance(result, str):
                    before_lines.append(result)
                elif isinstance(result, (list, tuple)):
                    before_lines.extend(result)
                elif result is not None:
                    raise TypeError("prematch_extend_callback must return string, list, tuple, or None")

            # handle modifier if passed in
            modified_line = key
            if modifier_callback:
                new_val = modifier_callback(key)
                if not isinstance(new_val, str):
                    raise TypeError("modifier_callback MUST return a string")
                modified_line = new_val

            # Apply built-in modifications ONLY to main modified line
            main_entry = f"{prepend_text}{modified_line.replace(*replace_tuple)}{append_text}"

            # handle post extend if it is passed in
            after_lines = []
            if postmatch_extend_callback:
                result = postmatch_extend_callback(key)
                if isinstance(result, str):
                    after_lines.append(result)
                elif isinstance(result, (list, tuple)):
                    after_lines.extend(result)
                elif result is not None:
                    raise TypeError("postmatch_extend_callback must return string, list, tuple, or None")

            # Order the lines correctly
            for entry in before_lines:
                data[entry] = OrderedDict()

            data[main_entry] = sub_tree

            for entry in after_lines:
                data[entry] = OrderedDict()

        else:
            # Non-matching line — return as-is
            data[key] = sub_tree

            # Recurse downward if needed
            if isinstance(sub_tree, dict) and sub_tree:
                data[key] = modify_config_tree_inline(
                    sub_tree, search_terms, case_sensitive, full_match,
                    min_search_depth, max_search_depth,
                    prepend_text, append_text, replace_tuple,
                    modifier_callback, prematch_extend_callback,
                    postmatch_extend_callback, _depth + 1
                )

    return data

def get_config_sections(tree, search_terms, case_sensitive=True, full_match=False, min_search_depth=0, max_search_depth=0, _depth=0):
    """
    Searches the configuration tree for section headers that match the given
    search terms and returns the full path to root and the complete nested
    section(s) under those matches. This works very similar to search_config_tree with the
    exception that it will not only return the full path to root for any matches, but the
    full nested path.


    :param tree: Configuration tree to search
    :type tree: dict
    :param search_terms: Search term(s) (string, list, or tuple)
    :type search_terms: str | list | tuple
    :param case_sensitive: Whether the search is case-sensitive
    :type case_sensitive: bool
    :param full_match: If True, requires exact match; if False, allows partial matches
    :type full_match: bool
    :param min_search_depth: Minimum nesting level to include matches (0 = no restriction)
    :type min_search_depth: int
    :param max_search_depth: Maximum nesting level to include matches (0 = infinite)
    :type max_search_depth: int
    :param _depth: Internal recursion tracker (do not pass manually)
    :type _depth: int

    :return: Dictionary containing the full path to root and complete matched sections
    :rtype: dict
    """
    if not isinstance(search_terms, (list, tuple)):
        search_terms = [search_terms]

    results = {}

    for key, sub_tree in tree.items():
        # If the key matches our search term(s)
        if matches_search_terms(key, search_terms, case_sensitive, full_match):
            if _depth >= min_search_depth and (max_search_depth == 0 or _depth < max_search_depth):
                # Return this full subtree
                results[key] = sub_tree
                # Skip recursion — entire subtree is already captured
                continue

        # Recurse into children if this is a nested dict
        if isinstance(sub_tree, dict) and sub_tree:
            nested = get_config_sections(
                sub_tree,
                search_terms,
                case_sensitive=case_sensitive,
                full_match=full_match,
                min_search_depth=min_search_depth,
                max_search_depth=max_search_depth,
                _depth=_depth + 1
            )
            if nested:
                # Preserve full path to root
                results[key] = nested

    return results


def extract_line_from_tree(tree, search_term, case_sensitive=True, full_match=False, find_all=True):
    """
    Extracts the first (or all) occurances of "search_term" from "tree". Can specify case sensitive, and full
    match in the search
    """
    matches = []

    for key, sub_tree in tree.items():
        if matches_search_terms(key, [search_term], case_sensitive, full_match):
            if not find_all:
                return key
            matches.append(key)
        if isinstance(sub_tree, dict) and sub_tree:
            result = extract_line_from_tree(sub_tree, search_term, case_sensitive, full_match, find_all)
            if find_all:
                if result:
                    matches.extend(result if isinstance(result, list) else [result])
            elif result:
                return result

    return matches if find_all else None

def tree_is_subset(subset: dict, reference: dict) -> bool:
    for key, sub_val in subset.items():
        if key not in reference:
            return False
        ref_val = reference[key]
        if isinstance(sub_val, dict):
            if not isinstance(ref_val, dict):
                return False
            if not tree_is_subset(sub_val, ref_val):
                return False
        elif sub_val != ref_val:
            return False
    return True

def trees_are_equal(tree1: dict, tree2: dict, exclude_keys=[]) -> bool:
    """Will check if 2 trees are equal or not. Can specify to exclude certain text
    NOTE this will check recursively and symmetrically so you cant have extra config in either tree and match"""
    def worker(tree1, tree2, exclude_keys=[]):
        tracker = []
        for config, sub_tree in tree1.items():
            if any(x in config for x in exclude_keys):
                pass
            else:
                # do the comparison
                tracker.append(config in tree2.keys())
            if sub_tree:
                tracker.append(worker(sub_tree, tree2.get(config, {}), exclude_keys))

        return all(tracker)

    return all([worker(tree1, tree2, exclude_keys), worker(tree2, tree1, exclude_keys)])