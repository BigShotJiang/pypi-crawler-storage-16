// crates/cep-core/src/relationship/mod.rs
pub mod generated;
pub mod manual;

pub use manual::*;
