// crates/cep-domains/src/campaign_finance/candidate/mod.rs

pub mod generated;
pub mod manual;

pub use generated::*;
