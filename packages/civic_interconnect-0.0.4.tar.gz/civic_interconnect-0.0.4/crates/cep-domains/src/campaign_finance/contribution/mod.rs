// crates/cep-domains/src/campaign_finance/contribution/mod.rs

pub mod generated;
pub mod manual;

pub use generated::*;
