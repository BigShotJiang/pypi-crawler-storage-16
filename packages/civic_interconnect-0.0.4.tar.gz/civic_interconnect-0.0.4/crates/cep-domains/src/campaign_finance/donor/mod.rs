// crates/cep-domains/src/campaign_finance/donor/mod.rs

pub mod generated;
pub mod manual;

pub use generated::*;
