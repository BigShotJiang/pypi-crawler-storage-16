// crates/cep-domains/src/campaign_finance/expenditure/mod.rs

pub mod generated;
pub mod manual;

pub use generated::*;
