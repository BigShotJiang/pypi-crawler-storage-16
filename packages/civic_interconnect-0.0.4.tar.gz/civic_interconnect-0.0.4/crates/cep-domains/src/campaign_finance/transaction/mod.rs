// crates/cep-domains/src/campaign_finance/transaction/mod.rs

pub mod generated;
pub mod manual;

pub use generated::*;
