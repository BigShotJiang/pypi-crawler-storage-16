// crates/cep-domains/src/environment/facility/mod.rs

pub mod generated;
pub mod manual;

pub use generated::*;
