// crates/cep-domains/src/environment/inspection/mod.rs

pub mod generated;
pub mod manual;

pub use generated::*;
