// crates/cep-domains/src/public_procurement/award/mod.rs

pub mod generated;
pub mod manual;

pub use generated::*;
