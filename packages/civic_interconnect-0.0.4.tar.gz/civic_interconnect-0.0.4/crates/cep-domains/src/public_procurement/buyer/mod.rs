// crates/cep-domains/src/public_procurement/buyer/mod.rs

pub mod generated;
pub mod manual;

pub use generated::*;
