# Profiles

Profiles described here:

- CEP-Core (required minimal spec)
- CEP-AI-Constrained (non-destructive AI, audit logging)
- CEP-Legacy-Import (looser onboarding, revision classification)
- CEP-Privacy-Extended (stricter CTag limits)
- CEP-AuditMax (mandatory checkpoints, full verification)

## CEP-Core (Required, Minimal)

## CEP-AI-Constrained (non-destructive AI, audit logging)

## CEP-Legacy-Import (looser onboarding, revision classification)

## CEP-Privacy-Extended (stricter CTag limits)

## CEP-AuditMax (mandatory checkpoints, full verification)
