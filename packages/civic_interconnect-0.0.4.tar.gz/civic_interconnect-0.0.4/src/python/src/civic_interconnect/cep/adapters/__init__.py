"""Adapters package for civic-interconnect CEP.

This package contains adapter implementations for external integrations.
"""
