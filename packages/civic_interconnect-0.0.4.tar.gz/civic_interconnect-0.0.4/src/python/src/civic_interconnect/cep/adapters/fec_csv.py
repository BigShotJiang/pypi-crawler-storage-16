"""FEC CSV adapter for the Civic Engagement Platform.

This module provides adapters for reading and processing Federal Election Commission
(FEC) CSV data files.
"""
