"""State portal example adapter for the CEP system.

This module provides an example adapter implementation for connecting to
state portals and retrieving civic engagement data.
"""
