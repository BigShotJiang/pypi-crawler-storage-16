"""CEP version constants."""

__version__ = "0.1.0"

SCHEMA_VERSION = "1.0.0"
