"""Entity module for civic-interconnect CEP.

This module contains entity classes and related functionality.
"""
