// crates/cep-core/src/exchange/mod.rs
pub mod generated;
pub mod manual;

pub use manual::*;
