// crates/cep-domains/src/campaign_finance/committee/mod.rs

pub mod generated;
pub mod manual;

pub use generated::*;
