// crates/cep-domains/src/education/institution/mod.rs

pub mod generated;
pub mod manual;

pub use generated::*;
