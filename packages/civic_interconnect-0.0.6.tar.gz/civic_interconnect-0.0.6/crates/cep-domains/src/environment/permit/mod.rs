// crates/cep-domains/src/environment/permit/mod.rs

pub mod generated;
pub mod manual;

pub use generated::*;
