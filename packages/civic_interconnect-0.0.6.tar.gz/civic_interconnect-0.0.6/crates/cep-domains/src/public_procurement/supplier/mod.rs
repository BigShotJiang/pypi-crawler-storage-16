// crates/cep-domains/src/public_procurement/supplier/mod.rs

pub mod generated;
pub mod manual;

pub use generated::*;
