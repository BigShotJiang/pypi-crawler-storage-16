"""Procurement SME adapter manifest."""
