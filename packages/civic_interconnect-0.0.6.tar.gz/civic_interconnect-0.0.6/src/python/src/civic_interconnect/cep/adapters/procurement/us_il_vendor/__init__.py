from .adapter import UsIlVendorAdapter

__all__ = ["UsIlVendorAdapter"]
