"""US Illinois vendor adapter manifest."""
