"""Vocabulary module for civic-interconnect CEP.

This module provides vocabulary-related functionality.
"""
