from ckan import plugins as p


class ToolbeltPlugin(p.SingletonPlugin):
    pass
