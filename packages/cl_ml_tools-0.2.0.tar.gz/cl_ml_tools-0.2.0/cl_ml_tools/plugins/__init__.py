"""Plugins module - auto-discovered compute task plugins."""
