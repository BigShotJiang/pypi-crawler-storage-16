"""Test configuration and fixtures."""

import pytest
