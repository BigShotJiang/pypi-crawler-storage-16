"""Allow running as: python -m cl_wrangler"""

from cl_wrangler import main

if __name__ == "__main__":
    main()
