# Changelog

## 0.2.0 (2025-12-14)

- Drop support for Python 3.8 and 3.9.
- Add support for Python 3.13 and 3.14.
- Switch to Ruff.
- Use importlib.metadata for the `clamd.__version__` attribute.
- Some tweaks to type hints.s

## 0.1.0.post1 (2024-01-06)

- Added a license entry in the `pyproject.toml`

## 0.1.0 (2023-10-22)

- Initial release
