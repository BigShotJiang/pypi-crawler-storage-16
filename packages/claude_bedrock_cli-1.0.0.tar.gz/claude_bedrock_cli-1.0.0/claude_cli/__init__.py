"""Claude Bedrock CLI - A Claude Code clone using AWS Bedrock"""

__version__ = "0.1.0"
