"""
Setup script for claude-bedrock-cli

This file exists for backward compatibility.
Configuration is now in pyproject.toml
"""

from setuptools import setup

# Configuration is in pyproject.toml
setup()
