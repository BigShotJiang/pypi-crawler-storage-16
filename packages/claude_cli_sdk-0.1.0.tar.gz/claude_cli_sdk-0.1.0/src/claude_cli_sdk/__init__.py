"""
Claude CLI SDK
==============

Claude CLI를 subprocess로 감싸서 Python SDK처럼 사용하는 라이브러리.
공식 SDK 없이도 Skills, Hooks, Slash Commands, Agents 등 모든 기능 사용 가능.

사용 예시
--------
>>> from claude_cli_sdk import Claude, ClaudeSync
>>>
>>> # Async 사용
>>> async with Claude() as claude:
...     result = await claude.run("Hello!")
...     print(result.text)
>>>
>>> # Sync 사용
>>> claude = ClaudeSync()
>>> result = claude.run("Hello!")
>>> print(result.text)

Skills 호출
----------
>>> result = await claude.skill("frontend-design", "Create a button")

Agent 호출
---------
>>> result = await claude.agent("Explore", "Find Python files")

Slash Command
------------
>>> result = await claude.command("code-review")
"""

__version__ = "0.1.0"
__author__ = "Claude CLI SDK Contributors"

from .config import ClaudeConfig, PermissionMode, OutputFormat
from .models import StreamEvent, ClaudeResult, Message
from .client import Claude, ClaudeSync
from .utils import quick_run, quick_skill, quick_agent, quick_run_sync

__all__ = [
    # Main classes
    "Claude",
    "ClaudeSync",
    # Config
    "ClaudeConfig",
    "PermissionMode",
    "OutputFormat",
    # Models
    "StreamEvent",
    "ClaudeResult",
    "Message",
    # Utils
    "quick_run",
    "quick_skill",
    "quick_agent",
    "quick_run_sync",
]
