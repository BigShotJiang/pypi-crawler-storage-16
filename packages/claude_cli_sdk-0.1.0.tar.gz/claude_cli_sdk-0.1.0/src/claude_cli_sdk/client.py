"""Claude CLI SDK 클라이언트"""

import json
import asyncio
from asyncio.subprocess import Process
from typing import Optional, Callable, AsyncIterator, Any

from .config import ClaudeConfig, OutputFormat
from .models import StreamEvent, ClaudeResult


class Claude:
    """비동기 Claude CLI SDK 클라이언트

    Claude CLI를 subprocess로 감싸서 Python에서 사용하는 비동기 클라이언트.
    Skills, Hooks, Slash Commands, Agents 등 모든 기능 지원.

    사용 예시:
        >>> async with Claude() as claude:
        ...     result = await claude.run("Hello!")
        ...     print(result.text)

        >>> claude = Claude(ClaudeConfig(model="sonnet"))
        >>> result = await claude.run("Explain this code")
    """

    def __init__(self, config: Optional[ClaudeConfig] = None):
        """Claude 클라이언트 초기화

        Args:
            config: Claude 설정. None이면 기본값 사용
        """
        self.config = config or ClaudeConfig()
        self._process: Optional[Process] = None
        self._session_id: Optional[str] = None

        # 이벤트 핸들러
        self.on_message: Optional[Callable[[StreamEvent], None]] = None
        self.on_tool_use: Optional[Callable[[dict], None]] = None
        self.on_error: Optional[Callable[[str], None]] = None
        self.on_result: Optional[Callable[[dict], None]] = None

    async def __aenter__(self) -> "Claude":
        """컨텍스트 매니저 진입"""
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """컨텍스트 매니저 종료"""
        await self.close()

    def _build_args(
        self,
        prompt: Optional[str] = None,
        resume: Optional[str] = None,
        continue_session: bool = False
    ) -> list[str]:
        """CLI 인자 빌드

        Args:
            prompt: 실행할 프롬프트
            resume: 재개할 세션 ID
            continue_session: 현재 세션 계속 여부

        Returns:
            CLI 인자 리스트
        """
        args = [self.config.claude_path]

        # 프롬프트 모드 (-p)
        if prompt:
            args.extend(["-p", prompt])

        # 세션 재개
        if resume:
            args.extend(["--resume", resume])
        elif continue_session and self._session_id:
            args.extend(["--resume", self._session_id])

        # 모델
        if self.config.model:
            args.extend(["--model", self.config.model])

        # 권한 모드
        args.extend(["--permission-mode", self.config.permission_mode.value])

        # 출력 포맷
        args.extend(["--output-format", self.config.output_format.value])

        # stream-json + print 모드(-p)는 --verbose 필수
        if self.config.output_format == OutputFormat.STREAM_JSON and prompt:
            args.append("--verbose")

        # 입력 포맷 (양방향 통신)
        args.extend(["--input-format", self.config.input_format])

        # Setting sources (skills, CLAUDE.md, subagents)
        if self.config.setting_sources:
            args.extend(["--setting-sources", ",".join(self.config.setting_sources)])

        # 허용 도구
        if self.config.allowed_tools:
            args.extend(["--allowed-tools", ",".join(self.config.allowed_tools)])

        # 비허용 도구
        if self.config.disallowed_tools:
            args.extend(["--disallowed-tools", ",".join(self.config.disallowed_tools)])

        # MCP 설정
        if self.config.mcp_config:
            args.extend(["--mcp-config", self.config.mcp_config])

        # 최대 턴
        if self.config.max_turns:
            args.extend(["--max-turns", str(self.config.max_turns)])

        # 시스템 프롬프트
        if self.config.system_prompt:
            args.extend(["--system-prompt", self.config.system_prompt])

        return args

    async def start_session(self) -> None:
        """세션 시작 (양방향 통신용)

        지속적인 대화가 필요한 경우 사용.
        send_message()와 read_stream()으로 통신.
        """
        args = self._build_args()

        self._process = await asyncio.create_subprocess_exec(
            *args,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=self.config.cwd
        )

    async def send_message(self, message: str) -> None:
        """메시지 전송 (양방향 통신)

        Args:
            message: 전송할 메시지

        Raises:
            RuntimeError: 세션이 시작되지 않은 경우
        """
        if not self._process or not self._process.stdin:
            raise RuntimeError("세션이 시작되지 않았습니다. start_session()을 먼저 호출하세요.")

        # stream-json 포맷으로 전송
        msg = json.dumps({
            "type": "user_message",
            "content": message
        }) + "\n"

        self._process.stdin.write(msg.encode())
        await self._process.stdin.drain()

    async def read_stream(self) -> AsyncIterator[StreamEvent]:
        """스트림 읽기

        Yields:
            StreamEvent: 수신된 이벤트

        Raises:
            RuntimeError: 세션이 시작되지 않은 경우
        """
        if not self._process or not self._process.stdout:
            raise RuntimeError("세션이 시작되지 않았습니다. start_session()을 먼저 호출하세요.")

        while True:
            line = await self._process.stdout.readline()
            if not line:
                break

            try:
                data = json.loads(line.decode())
                event = StreamEvent(
                    type=data.get("type", "unknown"),
                    data=data,
                    raw=line.decode()
                )

                # 세션 ID 저장
                if event.type == "system" and "session_id" in data:
                    self._session_id = data["session_id"]

                # 이벤트 핸들러 호출
                if self.on_message:
                    self.on_message(event)
                if self.on_tool_use and event.type == "tool_use":
                    self.on_tool_use(data)
                if self.on_result and event.type == "result":
                    self.on_result(data)

                yield event

            except json.JSONDecodeError:
                # JSON이 아닌 출력 (에러 등)
                if self.on_error:
                    self.on_error(line.decode())

    async def run(self, prompt: str) -> ClaudeResult:
        """단일 프롬프트 실행

        Args:
            prompt: 실행할 프롬프트

        Returns:
            ClaudeResult: 실행 결과
        """
        args = self._build_args(prompt)

        process = await asyncio.create_subprocess_exec(
            *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=self.config.cwd
        )

        stdout, stderr = await process.communicate()

        # stream-json 파싱
        events: list[dict] = []
        result: Optional[dict] = None

        for line in stdout.decode().strip().split("\n"):
            if line:
                try:
                    data = json.loads(line)
                    events.append(data)

                    if data.get("type") == "result":
                        result = data

                    # 세션 ID 저장
                    if data.get("type") == "system" and "session_id" in data:
                        self._session_id = data["session_id"]

                except json.JSONDecodeError:
                    pass

        return ClaudeResult(
            events=events,
            result=result,
            session_id=self._session_id,
            stderr=stderr.decode() if stderr else None,
            success=process.returncode == 0
        )

    async def skill(self, skill_name: str, prompt: str) -> ClaudeResult:
        """스킬 사용하여 실행

        Args:
            skill_name: 스킬 이름 (예: "frontend-design")
            prompt: 스킬에 전달할 프롬프트

        Returns:
            ClaudeResult: 실행 결과
        """
        # Skill 도구를 허용 목록에 추가
        original_tools = self.config.allowed_tools
        if self.config.allowed_tools:
            if "Skill" not in self.config.allowed_tools:
                self.config.allowed_tools = self.config.allowed_tools + ["Skill"]
        else:
            self.config.allowed_tools = ["Skill", "Read", "Write", "Edit", "Bash", "Glob", "Grep"]

        # 스킬 호출 프롬프트
        full_prompt = f'Use the "{skill_name}" skill to: {prompt}'

        try:
            result = await self.run(full_prompt)
        finally:
            # 원래 도구 설정 복원
            self.config.allowed_tools = original_tools

        return result

    async def command(self, command: str, args: str = "") -> ClaudeResult:
        """슬래시 커맨드 실행

        Args:
            command: 커맨드 이름 (슬래시 없이, 예: "code-review")
            args: 커맨드 인자

        Returns:
            ClaudeResult: 실행 결과
        """
        # SlashCommand 도구 사용
        original_tools = self.config.allowed_tools
        if self.config.allowed_tools:
            if "SlashCommand" not in self.config.allowed_tools:
                self.config.allowed_tools = self.config.allowed_tools + ["SlashCommand"]

        full_prompt = f'Execute the slash command: /{command} {args}'

        try:
            result = await self.run(full_prompt)
        finally:
            self.config.allowed_tools = original_tools

        return result

    async def agent(self, agent_type: str, task: str) -> ClaudeResult:
        """에이전트(Task tool) 사용

        Args:
            agent_type: 에이전트 타입 (예: "Explore", "Plan")
            task: 에이전트에 전달할 작업

        Returns:
            ClaudeResult: 실행 결과
        """
        original_tools = self.config.allowed_tools
        if self.config.allowed_tools:
            if "Task" not in self.config.allowed_tools:
                self.config.allowed_tools = self.config.allowed_tools + ["Task"]

        full_prompt = f'Use the Task tool with subagent_type="{agent_type}" to: {task}'

        try:
            result = await self.run(full_prompt)
        finally:
            self.config.allowed_tools = original_tools

        return result

    async def close(self) -> None:
        """세션 종료"""
        if self._process:
            self._process.terminate()
            await self._process.wait()
            self._process = None

    @property
    def session_id(self) -> Optional[str]:
        """현재 세션 ID"""
        return self._session_id


class ClaudeSync:
    """동기 Claude CLI SDK 클라이언트

    asyncio 없이 사용 가능한 동기 버전.

    사용 예시:
        >>> claude = ClaudeSync()
        >>> result = claude.run("Hello!")
        >>> print(result.text)
    """

    def __init__(self, config: Optional[ClaudeConfig] = None):
        """ClaudeSync 클라이언트 초기화

        Args:
            config: Claude 설정. None이면 기본값 사용
        """
        self.config = config or ClaudeConfig()
        self._session_id: Optional[str] = None

    def __enter__(self) -> "ClaudeSync":
        """컨텍스트 매니저 진입"""
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """컨텍스트 매니저 종료"""
        pass

    def _build_args(self, prompt: str) -> list[str]:
        """CLI 인자 빌드"""
        args = [self.config.claude_path, "-p", prompt]

        if self.config.model:
            args.extend(["--model", self.config.model])

        args.extend(["--permission-mode", self.config.permission_mode.value])
        args.extend(["--output-format", self.config.output_format.value])

        # stream-json은 --verbose 필수
        if self.config.output_format == OutputFormat.STREAM_JSON:
            args.append("--verbose")

        if self.config.setting_sources:
            args.extend(["--setting-sources", ",".join(self.config.setting_sources)])

        if self.config.allowed_tools:
            args.extend(["--allowed-tools", ",".join(self.config.allowed_tools)])

        if self.config.disallowed_tools:
            args.extend(["--disallowed-tools", ",".join(self.config.disallowed_tools)])

        if self.config.mcp_config:
            args.extend(["--mcp-config", self.config.mcp_config])

        if self.config.max_turns:
            args.extend(["--max-turns", str(self.config.max_turns)])

        if self.config.system_prompt:
            args.extend(["--system-prompt", self.config.system_prompt])

        return args

    def run(self, prompt: str) -> ClaudeResult:
        """동기 실행

        Args:
            prompt: 실행할 프롬프트

        Returns:
            ClaudeResult: 실행 결과
        """
        import subprocess

        args = self._build_args(prompt)

        result = subprocess.run(
            args,
            capture_output=True,
            text=True,
            cwd=self.config.cwd
        )

        events: list[dict] = []
        final_result: Optional[dict] = None

        for line in result.stdout.strip().split("\n"):
            if line:
                try:
                    data = json.loads(line)
                    events.append(data)
                    if data.get("type") == "result":
                        final_result = data
                    if data.get("type") == "system" and "session_id" in data:
                        self._session_id = data["session_id"]
                except json.JSONDecodeError:
                    pass

        return ClaudeResult(
            events=events,
            result=final_result,
            session_id=self._session_id,
            stderr=result.stderr,
            success=result.returncode == 0
        )

    def skill(self, skill_name: str, prompt: str) -> ClaudeResult:
        """스킬 사용하여 실행"""
        original_tools = self.config.allowed_tools
        if self.config.allowed_tools:
            if "Skill" not in self.config.allowed_tools:
                self.config.allowed_tools = self.config.allowed_tools + ["Skill"]
        else:
            self.config.allowed_tools = ["Skill", "Read", "Write", "Edit", "Bash", "Glob", "Grep"]

        full_prompt = f'Use the "{skill_name}" skill to: {prompt}'

        try:
            result = self.run(full_prompt)
        finally:
            self.config.allowed_tools = original_tools

        return result

    def command(self, command: str, args: str = "") -> ClaudeResult:
        """슬래시 커맨드 실행"""
        original_tools = self.config.allowed_tools
        if self.config.allowed_tools:
            if "SlashCommand" not in self.config.allowed_tools:
                self.config.allowed_tools = self.config.allowed_tools + ["SlashCommand"]

        full_prompt = f'Execute the slash command: /{command} {args}'

        try:
            result = self.run(full_prompt)
        finally:
            self.config.allowed_tools = original_tools

        return result

    def agent(self, agent_type: str, task: str) -> ClaudeResult:
        """에이전트(Task tool) 사용"""
        original_tools = self.config.allowed_tools
        if self.config.allowed_tools:
            if "Task" not in self.config.allowed_tools:
                self.config.allowed_tools = self.config.allowed_tools + ["Task"]

        full_prompt = f'Use the Task tool with subagent_type="{agent_type}" to: {task}'

        try:
            result = self.run(full_prompt)
        finally:
            self.config.allowed_tools = original_tools

        return result

    @property
    def session_id(self) -> Optional[str]:
        """현재 세션 ID"""
        return self._session_id
