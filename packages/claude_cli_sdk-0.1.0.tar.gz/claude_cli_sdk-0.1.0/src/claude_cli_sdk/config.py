"""설정 및 Enum 정의"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class PermissionMode(Enum):
    """권한 모드

    Attributes:
        DEFAULT: 기본 모드 (사용자 확인 필요)
        ACCEPT_EDITS: 파일 편집 자동 승인
        BYPASS_PERMISSIONS: 모든 권한 우회 (주의!)
    """
    DEFAULT = "default"
    ACCEPT_EDITS = "acceptEdits"
    BYPASS_PERMISSIONS = "bypassPermissions"


class OutputFormat(Enum):
    """출력 포맷

    Attributes:
        TEXT: 일반 텍스트 출력
        JSON: JSON 출력
        STREAM_JSON: JSON 라인 스트림 (SDK 기본값)
    """
    TEXT = "text"
    JSON = "json"
    STREAM_JSON = "stream-json"


@dataclass
class ClaudeConfig:
    """Claude CLI 설정

    Attributes:
        model: 사용할 모델 (예: "claude-3-opus", "claude-3-sonnet")
        permission_mode: 권한 모드
        output_format: 출력 포맷
        setting_sources: 설정 소스 (Skills, Hooks, CLAUDE.md 로드용)
        allowed_tools: 허용할 도구 목록
        disallowed_tools: 비허용 도구 목록
        mcp_config: MCP 설정 파일 경로
        cwd: 작업 디렉토리
        input_format: 입력 포맷 (양방향 통신용)
        max_turns: 최대 턴 수
        system_prompt: 시스템 프롬프트
        claude_path: Claude CLI 경로 (기본: "claude")
        timeout: 타임아웃 (초)

    Example:
        >>> config = ClaudeConfig(
        ...     model="claude-3-sonnet",
        ...     permission_mode=PermissionMode.ACCEPT_EDITS,
        ...     allowed_tools=["Bash", "Read", "Write"],
        ...     max_turns=5
        ... )
    """
    # 기본 설정
    model: Optional[str] = None
    permission_mode: PermissionMode = PermissionMode.ACCEPT_EDITS
    output_format: OutputFormat = OutputFormat.STREAM_JSON

    # Settings sources (skills, CLAUDE.md, subagents 로드용)
    setting_sources: list[str] = field(default_factory=lambda: ["user", "project"])

    # 도구 허용
    allowed_tools: Optional[list[str]] = None
    disallowed_tools: Optional[list[str]] = None

    # MCP 설정
    mcp_config: Optional[str] = None

    # 작업 디렉토리
    cwd: Optional[str] = None

    # 양방향 통신
    input_format: str = "stream-json"

    # 기타
    max_turns: Optional[int] = None
    system_prompt: Optional[str] = None

    # CLI 경로
    claude_path: str = "claude"

    # 타임아웃
    timeout: Optional[float] = None
