"""데이터 모델 정의"""

from dataclasses import dataclass, field
from typing import Optional, Any


@dataclass
class Message:
    """메시지 구조

    Attributes:
        role: 역할 ("user" 또는 "assistant")
        content: 메시지 내용
        tool_use: 도구 사용 정보 (있는 경우)
        tool_result: 도구 실행 결과 (있는 경우)
    """
    role: str
    content: str
    tool_use: Optional[dict] = None
    tool_result: Optional[dict] = None


@dataclass
class StreamEvent:
    """스트림 이벤트

    Attributes:
        type: 이벤트 타입 (system, assistant, tool_use, tool_result, result)
        data: 이벤트 데이터
        raw: 원본 JSON 문자열
    """
    type: str
    data: dict
    raw: str

    @property
    def session_id(self) -> Optional[str]:
        """세션 ID (system 이벤트인 경우)"""
        if self.type == "system":
            return self.data.get("session_id")
        return None

    @property
    def message(self) -> Optional[dict]:
        """메시지 (assistant 이벤트인 경우)"""
        if self.type == "assistant":
            return self.data.get("message")
        return None

    @property
    def result_text(self) -> Optional[str]:
        """결과 텍스트 (result 이벤트인 경우)"""
        if self.type == "result":
            return self.data.get("result")
        return None


@dataclass
class ClaudeResult:
    """Claude 실행 결과

    Attributes:
        events: 모든 이벤트 목록
        result: 최종 결과 이벤트
        session_id: 세션 ID
        stderr: 표준 에러 출력
        success: 성공 여부

    Properties:
        text: 결과 텍스트
        tools_used: 사용된 도구 목록
    """
    events: list[dict] = field(default_factory=list)
    result: Optional[dict] = None
    session_id: Optional[str] = None
    stderr: Optional[str] = None
    success: bool = True

    @property
    def text(self) -> str:
        """결과 텍스트 반환"""
        if self.result:
            return self.result.get("result", "")
        return ""

    @property
    def tools_used(self) -> list[str]:
        """사용된 도구 목록"""
        tools = []
        for event in self.events:
            if event.get("type") == "assistant":
                content = event.get("message", {}).get("content", [])
                for item in content:
                    if isinstance(item, dict) and item.get("type") == "tool_use":
                        tool_name = item.get("name")
                        if tool_name and tool_name not in tools:
                            tools.append(tool_name)
        return tools

    def get_tool_results(self, tool_name: Optional[str] = None) -> list[dict]:
        """특정 도구의 결과 반환"""
        results = []
        for event in self.events:
            if event.get("type") == "tool_result":
                if tool_name is None or event.get("name") == tool_name:
                    results.append(event)
        return results

    def __repr__(self) -> str:
        text_preview = self.text[:50] + "..." if len(self.text) > 50 else self.text
        return f"ClaudeResult(success={self.success}, text='{text_preview}')"
