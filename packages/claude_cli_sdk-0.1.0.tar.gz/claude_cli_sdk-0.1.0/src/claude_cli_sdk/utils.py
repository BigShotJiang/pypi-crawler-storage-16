"""편의 함수들"""

from typing import Any

from .config import ClaudeConfig
from .models import ClaudeResult


async def quick_run(prompt: str, **kwargs: Any) -> ClaudeResult:
    """빠른 비동기 실행

    일회성 프롬프트 실행에 적합.

    Args:
        prompt: 실행할 프롬프트
        **kwargs: ClaudeConfig에 전달할 인자

    Returns:
        ClaudeResult: 실행 결과

    사용 예시:
        >>> result = await quick_run("Hello!")
        >>> print(result.text)

        >>> result = await quick_run("Explain this", model="opus")
    """
    from .client import Claude

    config = ClaudeConfig(**kwargs)
    async with Claude(config) as claude:
        return await claude.run(prompt)


async def quick_skill(skill_name: str, prompt: str, **kwargs: Any) -> ClaudeResult:
    """스킬 빠른 실행

    Args:
        skill_name: 스킬 이름
        prompt: 스킬에 전달할 프롬프트
        **kwargs: ClaudeConfig에 전달할 인자

    Returns:
        ClaudeResult: 실행 결과

    사용 예시:
        >>> result = await quick_skill("frontend-design", "Create a button")
    """
    from .client import Claude

    config = ClaudeConfig(**kwargs)
    async with Claude(config) as claude:
        return await claude.skill(skill_name, prompt)


async def quick_agent(agent_type: str, task: str, **kwargs: Any) -> ClaudeResult:
    """에이전트 빠른 실행

    Args:
        agent_type: 에이전트 타입 (예: "Explore", "Plan")
        task: 에이전트에 전달할 작업
        **kwargs: ClaudeConfig에 전달할 인자

    Returns:
        ClaudeResult: 실행 결과

    사용 예시:
        >>> result = await quick_agent("Explore", "Find Python files")
    """
    from .client import Claude

    config = ClaudeConfig(**kwargs)
    async with Claude(config) as claude:
        return await claude.agent(agent_type, task)


def quick_run_sync(prompt: str, **kwargs: Any) -> ClaudeResult:
    """빠른 동기 실행

    Args:
        prompt: 실행할 프롬프트
        **kwargs: ClaudeConfig에 전달할 인자

    Returns:
        ClaudeResult: 실행 결과

    사용 예시:
        >>> result = quick_run_sync("Hello!")
        >>> print(result.text)
    """
    from .client import ClaudeSync

    config = ClaudeConfig(**kwargs)
    with ClaudeSync(config) as claude:
        return claude.run(prompt)
