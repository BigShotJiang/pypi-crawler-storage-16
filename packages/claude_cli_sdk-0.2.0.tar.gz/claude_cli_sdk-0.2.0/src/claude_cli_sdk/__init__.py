"""
Claude CLI SDK
==============

A Python library that wraps Claude CLI as a subprocess, providing SDK-like usage.
Use all Claude CLI features including Skills, Hooks, Slash Commands, and Agents
without requiring an official SDK.

Basic Usage
-----------
>>> from claude_cli_sdk import Claude, ClaudeSync
>>>
>>> # Async usage
>>> async with Claude() as claude:
...     result = await claude.run("Hello!")
...     print(result.text)
>>>
>>> # Sync usage
>>> claude = ClaudeSync()
>>> result = claude.run("Hello!")
>>> print(result.text)

Skills
------
>>> result = await claude.skill("frontend-design", "Create a button")

Agents
------
>>> result = await claude.agent("Explore", "Find Python files")

Slash Commands
--------------
>>> result = await claude.command("code-review")
"""

__version__ = "0.2.0"
__author__ = "Claude CLI SDK Contributors"

from .config import ClaudeConfig, PermissionMode, OutputFormat
from .models import StreamEvent, ClaudeResult, Message
from .client import Claude, ClaudeSync, CancellationToken
from .hooks import (
    Hook,
    HookType,
    HookConfig,
    HookManager,
    create_bash_validator,
    create_file_logger,
    create_edit_backup,
    quick_hook_setup,
)
from .utils import (
    quick_run,
    quick_skill,
    quick_agent,
    quick_run_sync,
    quick_run_with_files,
    quick_run_with_files_sync,
    quick_command,
    quick_command_sync,
    quick_streaming,
    quick_skill_sync,
    quick_agent_sync,
)

__all__ = [
    # Main classes
    "Claude",
    "ClaudeSync",
    "CancellationToken",
    # Config
    "ClaudeConfig",
    "PermissionMode",
    "OutputFormat",
    # Models
    "StreamEvent",
    "ClaudeResult",
    "Message",
    # Hooks
    "Hook",
    "HookType",
    "HookConfig",
    "HookManager",
    "create_bash_validator",
    "create_file_logger",
    "create_edit_backup",
    "quick_hook_setup",
    # Utils - Async
    "quick_run",
    "quick_skill",
    "quick_agent",
    "quick_command",
    "quick_run_with_files",
    "quick_streaming",
    # Utils - Sync
    "quick_run_sync",
    "quick_skill_sync",
    "quick_agent_sync",
    "quick_command_sync",
    "quick_run_with_files_sync",
]
