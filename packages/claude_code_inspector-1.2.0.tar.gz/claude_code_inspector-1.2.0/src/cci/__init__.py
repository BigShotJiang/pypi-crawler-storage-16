"""
Claude-Code-Inspector (CCI)

A MITM proxy tool to intercept, analyze and log AI coding assistant
communications with LLM APIs.
"""

__version__ = "1.1.0"
__author__ = "Claude-Code-Inspector Team"

