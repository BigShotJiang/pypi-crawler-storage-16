"""Version information for claude-code-scheduler.

This file is automatically updated by the build pipeline.
Do not edit manually.

Note: This code was generated with assistance from AI coding tools
and has been reviewed and tested by a human.
"""

__version__ = "0.3.0"
