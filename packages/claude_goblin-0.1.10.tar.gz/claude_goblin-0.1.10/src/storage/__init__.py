"""Storage layer for historical usage snapshots."""
