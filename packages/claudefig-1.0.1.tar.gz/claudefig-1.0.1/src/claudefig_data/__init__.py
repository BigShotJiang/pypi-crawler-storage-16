"""Default components and templates bundled with claudefig."""
