"""Templates package for claudefig."""
