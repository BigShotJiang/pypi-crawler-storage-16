"""Test suite for claudefig."""
