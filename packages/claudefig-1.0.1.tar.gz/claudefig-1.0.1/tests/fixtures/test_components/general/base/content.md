# Base Component

This is a base component that other components depend on.
