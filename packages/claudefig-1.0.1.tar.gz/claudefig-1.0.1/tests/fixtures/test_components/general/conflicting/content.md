# Conflicting Component

This component conflicts with the with_conflicts component. They cannot be used together.
