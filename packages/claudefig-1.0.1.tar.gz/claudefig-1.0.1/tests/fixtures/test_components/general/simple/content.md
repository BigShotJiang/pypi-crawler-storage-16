# Simple Component

This is a simple test component with no dependencies.

## Features
- No dependencies
- Basic markdown content
- Used for testing component loading
