# Component With Conflicts

This component conflicts with the conflicting component.
