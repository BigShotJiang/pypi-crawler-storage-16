# Component With Dependencies

This component requires the base component to function.
