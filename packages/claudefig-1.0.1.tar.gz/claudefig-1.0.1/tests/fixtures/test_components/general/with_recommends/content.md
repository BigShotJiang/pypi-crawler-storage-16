# Component With Recommends

This component recommends (but doesn't require) the simple component.
