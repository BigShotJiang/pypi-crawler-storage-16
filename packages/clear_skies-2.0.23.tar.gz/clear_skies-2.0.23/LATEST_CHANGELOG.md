## [2.0.23] - 2025-12-09

### Changed
- Final query by @cmancone in [#43](https://github.com/clearskies-py/clearskies/pull/43)

