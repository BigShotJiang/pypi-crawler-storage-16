from .string import String


class Datetime(String):
    _format = "date-time"
