## [2.0.24] - 2025-12-09

### Added
- Add logger by @tnijboer in [#42](https://github.com/clearskies-py/clearskies/pull/42)

