## [2.0.25] - 2025-12-10

### Fixed
- Don't overwrite the table name when there is a sort by @cmancone in [#44](https://github.com/clearskies-py/clearskies/pull/44)
- Don't overwrite the table name when there is a sort

