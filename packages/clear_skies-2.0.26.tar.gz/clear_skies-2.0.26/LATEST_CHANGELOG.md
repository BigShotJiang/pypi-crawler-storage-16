## [2.0.26] - 2025-12-11

### Fixed
- Let value be none for none type, do not stringify it in [#46](https://github.com/clearskies-py/clearskies/pull/46)
- We need the query not the model it self
- Correty field for join is join_type not type
- Swap case for query params too by @cmancone in [#45](https://github.com/clearskies-py/clearskies/pull/45)
- Swap case for query params too

