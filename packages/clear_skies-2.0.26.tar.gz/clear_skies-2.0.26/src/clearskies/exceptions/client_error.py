class ClientError(Exception):
    pass
