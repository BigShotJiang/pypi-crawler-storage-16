import logging

logger = logging.getLogger("kafka_service")
