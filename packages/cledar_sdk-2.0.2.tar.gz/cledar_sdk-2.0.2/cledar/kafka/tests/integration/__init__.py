"""Integration tests for kafka_service."""
