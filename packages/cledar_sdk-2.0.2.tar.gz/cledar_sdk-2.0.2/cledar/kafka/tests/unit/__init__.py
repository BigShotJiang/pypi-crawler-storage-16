"""Unit tests for kafka_service."""
