from .utils import get_input_topic

__all__ = ["get_input_topic"]
