import logging

logger = logging.getLogger("redis_service")
