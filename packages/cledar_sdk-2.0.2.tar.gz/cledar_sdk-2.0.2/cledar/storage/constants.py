S3_PATH_PREFIX = "s3://"
ABFS_PATH_PREFIX = "abfs://"
ABFSS_PATH_PREFIX = "abfss://"
