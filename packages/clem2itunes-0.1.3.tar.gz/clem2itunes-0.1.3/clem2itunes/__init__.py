"""clem2itunes."""
from __future__ import annotations

from .utils import create_library

__all__ = ('create_library',)
__version__ = '0.1.3'
