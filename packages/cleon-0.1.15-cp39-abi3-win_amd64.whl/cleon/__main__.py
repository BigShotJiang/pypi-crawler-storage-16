"""Entry point for python -m cleon."""

from cleon.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
