"""Add a completion subcommand to Click CLI applications."""

__version__ = "0.0.0"
