"""
Climate Diagnostics Package

This file exists for backwards compatibility with tools that don't yet
support pyproject.toml. The actual build configuration is in pyproject.toml.
"""

import setuptools

if __name__ == "__main__":
    setuptools.setup()