"""Unit test package for climdata."""
