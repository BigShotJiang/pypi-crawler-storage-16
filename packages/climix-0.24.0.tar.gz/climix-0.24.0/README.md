# Climix—a climate index package

[![Documentation Status](https://readthedocs.org/projects/climix/badge/?version=latest)](https://climix.readthedocs.io/en/latest/?badge=latest)
 [![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
 ![PyPI](https://img.shields.io/pypi/v/climix)
 ![Conda (channel only)](https://img.shields.io/conda/vn/conda-forge/climix)

 For documentation, see the https://climix.readthedocs.io.
