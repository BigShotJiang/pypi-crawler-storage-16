# Welcome to Climix's documentation!

```{toctree}
:maxdepth: 3
:caption: Contents

User guide <user/index>
```


<!--
# Indices and tables

* {ref}`genindex`
* {ref}`modindex`
* {ref}`search`
-->
