"""Version information for clippy-code."""

__version__ = "4.18.0"
