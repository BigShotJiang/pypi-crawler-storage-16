"""Tests for the edit_file tool - error cases."""
