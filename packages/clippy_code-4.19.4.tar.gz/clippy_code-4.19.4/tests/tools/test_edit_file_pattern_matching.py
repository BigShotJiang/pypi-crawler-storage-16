"""Tests for edit_file tool - pattern matching edge cases."""
