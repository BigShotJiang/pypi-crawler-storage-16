-- SQLite rollback: Remove cron_schedules table

DROP TABLE IF EXISTS cron_schedules;
