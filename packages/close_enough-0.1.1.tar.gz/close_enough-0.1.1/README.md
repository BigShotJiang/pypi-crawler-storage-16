# close_enough

A cursed Python decorator that generates function implementations using LLMs.

## Installation

```bash
uv add close_enough
```

## Usage

```python
import close_enough

@close_enough
def calculate_fibonacci(n: int) -> int:
    """Calculate the nth Fibonacci number."""
    ...

result = calculate_fibonacci(10)  # 55
```

The decorator generates a function implementation based on the signature and docstring. 
The implementation is generated from a LLM's output lazily on first call and cached for subsequent calls.

Do not use in production code.

## Configuration

The default model is `github_copilot/gpt-4`. To use a different model:

```python
import close_enough
close_enough.MODEL_NAME = "your-model-name"
```


## License

MIT
