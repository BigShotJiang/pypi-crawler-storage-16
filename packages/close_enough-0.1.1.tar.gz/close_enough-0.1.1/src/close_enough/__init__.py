"""
close_enough: LLM-powered function implementation generator

Use the @close_enough decorator to let an LLM generate function implementations
based on the function signature and docstring.

Example:
    import close_enough

    @close_enough
    def calculate_median(numbers: list[int]) -> float:
        '''Calculate the median of a list of integers.'''
        pass

    result = calculate_median([1, 2, 3, 4, 5])
"""

import inspect
import textwrap
from functools import wraps
from typing import Callable, Any
import sys

import litellm

__version__ = "0.1.0"
__all__ = ["close_enough"]


# Make the module itself callable as a decorator
class _CloseEnoughModule:
    """Module wrapper that makes the module itself usable as a decorator."""

    def __init__(self, module):
        self._module = module

    def __call__(self, fn: Callable) -> Callable:
        """Allow using the module as a decorator directly."""
        return close_enough(fn)

    def __getattr__(self, name):
        """Delegate attribute access to the actual module."""
        return getattr(self._module, name)


MODEL_NAME = "github_copilot/gpt-4"


def _build_prompt(fn: Callable) -> str:
    """Build the prompt for the LLM to generate function implementation."""
    sig = inspect.signature(fn)
    doc = inspect.getdoc(fn) or ""
    name = fn.__name__
    return textwrap.dedent(
        f"""
        You are an expert Python programmer.
        Write the body of a Python function with the following:
        - Name: {name}
        - Signature: {name}{sig}
        - Docstring (triple-quoted):
        \"\"\"{doc}\"\"\"
        Requirements:
        - Return only valid Python code, with a full function definition.
        - Use the exact function name and signature specified above.
        - Do NOT include any explanation, comments, or markdown, only raw Python code.
        - The function must be self-contained and not rely on undeclared globals.
        """
    ).strip()


def _generate_function_impl(fn: Callable) -> Callable:
    """Generate function implementation using LLM."""
    prompt = _build_prompt(fn)
    messages = [
        {
            "role": "system",
            "content": "You are an expert Python programmer.",
        },
        {"role": "user", "content": prompt},
    ]
    response = litellm.completion(
        model=MODEL_NAME,
        messages=messages,
        temperature=0.0,
        extra_headers={
            "editor-version": "vscode/1.85.1",
            "Copilot-Integration-Id": "vscode-chat",
        },
    )
    code = response.choices[0].message["content"].strip()

    # Clean up markdown code blocks if present
    if code.startswith("```"):
        code = code.strip("`")
        if code.lower().startswith("python\n"):
            code = code.split("\n", 1)[1]

    # Execute the generated code
    namespace: dict[str, Any] = {}
    exec(code, namespace, namespace)

    new_fn = namespace.get(fn.__name__)
    if not callable(new_fn):
        raise RuntimeError(
            f"Generated code did not define a callable named {fn.__name__}.\n\nCode:\n{code}"
        )

    # Attach raw generated source so the user can retrieve it later
    new_fn.__generated_source__ = code  # type: ignore

    return new_fn


def close_enough(fn: Callable) -> Callable:
    """
    Decorator that generates function implementation using an LLM.

    The function body is generated based on the function's signature and docstring.
    The implementation is generated lazily on first call and cached for subsequent calls.

    Args:
        fn: Function with signature and docstring, but empty/stub body

    Returns:
        Wrapped function that generates and executes LLM implementation

    Example:
        @close_enough
        def fibonacci(n: int) -> int:
            '''Return the nth Fibonacci number.'''
            pass

        # Access generated source code
        print(fibonacci._generated_impl().__generated_source__)
    """
    generated_impl: Callable | None = None

    @wraps(fn)
    def wrapper(*args, **kwargs):
        nonlocal generated_impl
        if generated_impl is None:
            generated_impl = _generate_function_impl(fn)
        return generated_impl(*args, **kwargs)

    # Expose the underlying generated function
    wrapper._generated_impl = lambda: generated_impl  # type: ignore

    return wrapper


sys.modules[__name__] = _CloseEnoughModule(sys.modules[__name__])  # type: ignore
