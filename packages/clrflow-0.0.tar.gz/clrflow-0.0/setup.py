from setuptools import setup

setup(
    name="clrflow",
    version="0.0",
    packages=["clrflow"],
    author="rver",
    author_email="rverflow@gmail.com",
    description="placeholder for clrflow"
)