"""clserve - CLI tool for serving LLM models on SLURM clusters."""

__version__ = "0.1.0"
