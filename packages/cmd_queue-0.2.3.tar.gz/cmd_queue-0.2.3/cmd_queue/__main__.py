from . import main as main_mod

main = main_mod.main

if __name__ == '__main__':
    """
    CommandLine:
        python ~/code/cmd_queue/cmd_queue/__main__.py
    """
    main()
