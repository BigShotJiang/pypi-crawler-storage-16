def test_import():
    import cmd_queue
    print(f'cmd_queue={cmd_queue}')
