if __name__ == "__main__":
    from cmdbox.app import app
    exit_code = app.main()
    exit(exit_code)
