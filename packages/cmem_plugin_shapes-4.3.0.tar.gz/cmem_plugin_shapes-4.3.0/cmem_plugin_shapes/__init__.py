"""cmem-plugin-shapes"""
