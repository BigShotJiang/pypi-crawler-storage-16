# cMeta (Common Meta Framework)

cMeta – a common meta-framework for unifying and interconnecting code, data, and knowledge.

## Copyright

Copyright (C) 2025 [Grigori Fursin](https://cKnowledge.org/gfursin) and [cTuning Labs](https://cTuningLabs.com).

This project may include minor functionality reused from [MLCommons CK](https://github.com/mlcommons/ck), 
developed by the same author and licensed under the same Apache 2.0 terms.

## License

Apache 2.0

## Status

*Under active development.*
