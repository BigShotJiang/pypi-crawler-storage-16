"""
CMeta common repo functions

cMeta author and developer: (C) 2025 Grigori Fursin

See the cMeta COPYRIGHT and LICENSE files in the project root for details.
"""

# Mainly testing that relative imports works inside cMeta categories
