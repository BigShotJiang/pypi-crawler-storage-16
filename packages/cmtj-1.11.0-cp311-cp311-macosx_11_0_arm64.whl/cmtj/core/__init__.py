# Type stubs for core C++ module
