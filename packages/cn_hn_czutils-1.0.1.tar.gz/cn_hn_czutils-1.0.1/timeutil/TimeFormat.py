#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
xxxxxx.py
描述这个模块的功能
作者: CAOZUZHEN
创建日期: 2025/12/12 23:26
"""

FORMAT_DATE = 'yyyy-mm-dd'
FORMAT_TIME = 'HH:MM:ss'

