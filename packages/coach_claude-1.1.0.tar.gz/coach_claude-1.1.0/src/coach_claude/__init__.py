"""Coach Claude MCP Server - Health and wellness tracking for developers."""

__version__ = "1.0.0"
