pub mod shared;

pub mod amazon_s3;
pub mod azure_blob;
pub mod google_drive;
pub mod local_file;
pub mod postgres;
