"""
Code Similarity Engine - Find semantic code patterns for abstraction opportunities.

Uses embeddings to find code regions that do similar things but look different,
helping identify refactoring opportunities that syntactic tools miss.

No telemetry. Models cached locally after first download.
"""

__version__ = "0.1.0"

from .indexer import index_codebase
from .embedder import embed_chunks
from .clusterer import cluster_vectors
from .reporter import report_clusters
from .analyzer import analyze_cluster, analyze_clusters

__all__ = [
    "__version__",
    "index_codebase",
    "embed_chunks",
    "cluster_vectors",
    "report_clusters",
    "analyze_cluster",
    "analyze_clusters",
]
