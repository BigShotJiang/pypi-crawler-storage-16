"""
LLM-based cluster analyzer - explains similarities and suggests abstractions.

Uses llama-cpp-python with Qwen3-0.6B GGUF for fully offline inference.
"""

from typing import List, Optional
from pathlib import Path
from dataclasses import dataclass
import json


@dataclass
class ClusterAnalysis:
    """Analysis results for a code cluster."""
    commonality: str          # What the regions share
    abstraction: str          # How to refactor
    suggested_name: str       # Name for extracted function/utility
    complexity: str           # low/medium/high effort to refactor


# Default model paths (legacy, prefer model_manager)
DEFAULT_MODEL_PATHS = [
    Path.home() / ".cache" / "cse" / "models" / "Qwen3-0.6B-Q4_K_M.gguf",
    Path("/Volumes/APPLE-STORAGE/Tether/Tether/Resources/ML Models/Qwen3-0.6B-Q4_K_M.gguf"),
]


def _get_llm_model_from_manager() -> Optional[Path]:
    """Try to get LLM model path from model_manager."""
    try:
        from .model_manager import get_model_path
        return get_model_path("llm")
    except ImportError:
        return None


def analyze_cluster(
    cluster: "Cluster",
    model_path: Optional[Path] = None,
    verbose: bool = False,
) -> Optional[ClusterAnalysis]:
    """
    Analyze a cluster using a local LLM.

    Args:
        cluster: Cluster object with similar code chunks
        model_path: Path to GGUF model file
        verbose: Print progress

    Returns:
        ClusterAnalysis object or None if model unavailable
    """
    from .models import Cluster

    # Find model
    model_file = _find_model(model_path)
    if not model_file:
        if verbose:
            print("   ⚠️  No LLM model found - skipping analysis")
            print("   💡 Download with: cse --download-model")
        return None

    try:
        from llama_cpp import Llama
    except ImportError:
        if verbose:
            print("   ⚠️  llama-cpp-python not installed")
        return None

    # Load model (lazy singleton would be better for multiple clusters)
    if verbose:
        print(f"   Loading LLM: {model_file.name}")

    llm = Llama(
        model_path=str(model_file),
        n_ctx=8192,       # Larger context for detailed prompts
        n_threads=4,
        n_gpu_layers=-1,  # Use GPU if available
        verbose=False,
    )

    # Build prompt
    prompt = _build_analysis_prompt(cluster)

    # Generate - allow longer responses for paragraph-length explanations
    response = llm(
        prompt,
        max_tokens=800,
        temperature=0.3,
        stop=["```\n", "\n\n\n"],
    )

    output = response["choices"][0]["text"].strip()

    # Parse response
    return _parse_analysis(output)


def analyze_clusters(
    clusters: List["Cluster"],
    model_path: Optional[Path] = None,
    max_clusters: int = 20,
    verbose: bool = False,
) -> dict[int, ClusterAnalysis]:
    """
    Analyze multiple clusters.

    Args:
        clusters: List of Cluster objects
        model_path: Path to GGUF model
        max_clusters: Maximum clusters to analyze (LLM is slow)
        verbose: Print progress

    Returns:
        Dict mapping cluster ID to analysis
    """
    from .models import Cluster

    model_file = _find_model(model_path)
    if not model_file:
        if verbose:
            print("   ⚠️  No LLM model found - skipping analysis")
        return {}

    try:
        from llama_cpp import Llama
    except ImportError:
        if verbose:
            print("   ⚠️  llama-cpp-python not installed")
        return {}

    # Load model once
    if verbose:
        print(f"   Loading LLM: {model_file.name}")

    llm = Llama(
        model_path=str(model_file),
        n_ctx=8192,       # Larger context for detailed prompts
        n_threads=4,
        n_gpu_layers=-1,  # Use GPU if available
        verbose=False,
    )

    results = {}
    clusters_to_analyze = clusters[:max_clusters]

    for i, cluster in enumerate(clusters_to_analyze):
        if verbose:
            print(f"   Analyzing cluster {i+1}/{len(clusters_to_analyze)}...")

        prompt = _build_analysis_prompt(cluster)

        try:
            # Allow longer responses for paragraph-length explanations
            response = llm(
                prompt,
                max_tokens=800,
                temperature=0.3,
                stop=["```\n", "\n\n\n"],
            )

            output = response["choices"][0]["text"].strip()
            analysis = _parse_analysis(output)

            if analysis:
                results[cluster.id] = analysis

        except Exception as e:
            if verbose:
                print(f"   ⚠️  Failed to analyze cluster {cluster.id}: {e}")

    return results


def _find_model(model_path: Optional[Path]) -> Optional[Path]:
    """Find a valid model file."""
    if model_path and model_path.exists():
        return model_path

    # Try model_manager first (preferred)
    manager_path = _get_llm_model_from_manager()
    if manager_path:
        return manager_path

    # Fallback to legacy paths
    for path in DEFAULT_MODEL_PATHS:
        if path.exists():
            return path

    return None


def _build_analysis_prompt(cluster: "Cluster") -> str:
    """Build the analysis prompt for a cluster."""
    # System prompt - explain the tool's purpose and the LLM's role
    system_prompt = """You are the analysis layer in a code similarity tool. This tool finds regions of code that have similar functionality and could potentially be abstracted into shared utilities.

Your task:
1. Identify WHAT the code regions have in common (the shared functionality)
2. Explain HOW an abstraction could be created (describe the approach, do not write actual code)
3. Suggest a NAME for the extracted function or utility
4. Rate the COMPLEXITY of performing this refactor (low/medium/high)

Output your analysis as JSON with these exact keys:
- "commonality": What the regions share - explain thoroughly in roughly one paragraph
- "abstraction": How to refactor - explain your approach in one to two paragraphs, no code
- "suggested_name": A descriptive camelCase function name
- "complexity": "low" | "medium" | "high" based on refactoring effort"""

    # Build user message with multiple code regions
    user_parts = [f"Found {cluster.size} similar code regions:\n"]

    # Show up to 3 regions from the cluster
    regions_to_show = min(3, len(cluster.chunks))
    for i, chunk in enumerate(cluster.chunks[:regions_to_show]):
        user_parts.append(f"Region {i+1} ({chunk.file_path}:{chunk.start_line}-{chunk.end_line}):")
        user_parts.append(f"```{chunk.language}")
        # Show up to 500 chars of each region, preserving formatting
        content = chunk.content[:500]
        if len(chunk.content) > 500:
            content += "\n# ... (truncated)"
        user_parts.append(content)
        user_parts.append("```\n")

    if cluster.size > regions_to_show:
        user_parts.append(f"(+ {cluster.size - regions_to_show} more similar regions)\n")

    user_parts.append("Analyze what these regions have in common and how they could be abstracted into a shared utility.")

    user_message = "\n".join(user_parts)

    # Build full prompt with ChatML format
    prompt = (
        f"<|im_start|>system\n{system_prompt}\n<|im_end|>\n"
        f"<|im_start|>user\n{user_message}\n<|im_end|>\n"
        "<|im_start|>assistant\n"
        '{"commonality":"'
    )
    return prompt


def _parse_analysis(output: str) -> Optional[ClusterAnalysis]:
    """Parse LLM output into ClusterAnalysis."""
    try:
        raw = output.strip()

        # Handle Qwen3 /think mode - extract content after </think>
        if "</think>" in raw:
            raw = raw.split("</think>")[-1].strip()

        # Handle markdown code fences
        if "```json" in raw:
            start = raw.index("```json") + 7
            end = raw.index("```", start) if "```" in raw[start:] else len(raw)
            raw = raw[start:end].strip()
        elif "```" in raw:
            # Generic code fence
            start = raw.index("```") + 3
            end = raw.index("```", start) if "```" in raw[start:] else len(raw)
            raw = raw[start:end].strip()

        # If we primed with {"commonality":" and model continued, prepend it
        if not raw.startswith("{"):
            raw = '{"commonality":"' + raw

        # Find the JSON object
        if "{" in raw:
            start = raw.index("{")
            # Find matching closing brace
            depth = 0
            end = start
            for i, c in enumerate(raw[start:], start):
                if c == "{":
                    depth += 1
                elif c == "}":
                    depth -= 1
                    if depth == 0:
                        end = i + 1
                        break
            raw = raw[start:end]

        data = json.loads(raw)

        return ClusterAnalysis(
            commonality=data.get("commonality", "Similar code patterns"),
            abstraction=data.get("abstraction", "Consider extracting to shared utility"),
            suggested_name=data.get("suggested_name", "sharedUtility"),
            complexity=data.get("complexity", "medium"),
        )

    except (json.JSONDecodeError, ValueError, IndexError) as e:
        # Debug: uncomment to see parsing failures
        # print(f"Failed to parse: {output[:300]}... Error: {e}")
        return None


def download_model(
    model_name: str = "Qwen/Qwen3-0.6B-GGUF",
    quantization: str = "q4_k_m",
    cache_dir: Optional[Path] = None,
    verbose: bool = False,
) -> Optional[Path]:
    """
    Download a GGUF model from HuggingFace.

    Args:
        model_name: HuggingFace model repo
        quantization: Quantization level (q4_k_m, q8_0, etc.)
        cache_dir: Where to save
        verbose: Print progress

    Returns:
        Path to downloaded model or None
    """
    try:
        from huggingface_hub import hf_hub_download
    except ImportError:
        if verbose:
            print("huggingface_hub not installed")
        return None

    cache_path = cache_dir or (Path.home() / ".cache" / "cse")
    cache_path.mkdir(parents=True, exist_ok=True)

    filename = f"qwen3-0.6b-{quantization}.gguf"

    if verbose:
        print(f"Downloading {filename}...")

    try:
        path = hf_hub_download(
            repo_id=model_name,
            filename=filename,
            local_dir=cache_path,
            local_dir_use_symlinks=False,
        )
        return Path(path)
    except Exception as e:
        if verbose:
            print(f"Failed to download: {e}")
        return None
