"""
CLI entry point for code-similarity-engine.

Usage:
    cse <path> [options]
    cse --download-models
    cse --model-status
    cse --help
"""

import click
from pathlib import Path
from typing import Optional
import sys
import os

from . import __version__
from .indexer import index_codebase
from .embedder import embed_chunks, find_embedding_model
from .clusterer import cluster_vectors
from .reporter import report_clusters, OutputFormat
from .model_manager import (
    ensure_models,
    download_all_models,
    print_model_status,
    get_model_path,
    download_model,
)


@click.command()
@click.argument("path", type=click.Path(exists=True, file_okay=False, dir_okay=True), required=False)
@click.option(
    "-t", "--threshold",
    type=float,
    default=0.80,
    help="Similarity threshold 0.0-1.0 (default: 0.80)"
)
@click.option(
    "-m", "--min-cluster",
    type=int,
    default=2,
    help="Minimum chunks per cluster (default: 2)"
)
@click.option(
    "-o", "--output",
    type=click.Choice(["text", "markdown", "json"]),
    default="text",
    help="Output format (default: text)"
)
@click.option(
    "-e", "--exclude",
    multiple=True,
    help="Glob patterns to exclude (repeatable)"
)
@click.option(
    "-f", "--focus",
    multiple=True,
    help="Only analyze matching paths (repeatable)"
)
@click.option(
    "-l", "--lang",
    type=str,
    default=None,
    help="Force language detection"
)
@click.option(
    "-v", "--verbose",
    is_flag=True,
    help="Show progress for all stages"
)
@click.option(
    "--max-chunks",
    type=int,
    default=10000,
    help="Maximum chunks to process (default: 10000)"
)
@click.option(
    "--batch-size",
    type=int,
    default=32,
    help="Embedding batch size (default: 32)"
)
@click.option(
    "--min-lines",
    type=int,
    default=5,
    help="Minimum lines per chunk (default: 5)"
)
@click.option(
    "--max-lines",
    type=int,
    default=100,
    help="Maximum lines per chunk (default: 100)"
)
@click.option(
    "--analyze/--no-analyze",
    default=False,
    help="Use LLM to explain clusters and suggest abstractions"
)
@click.option(
    "--llm-model",
    type=click.Path(exists=True),
    default=None,
    help="Path to LLM GGUF model (auto-detected)"
)
@click.option(
    "--max-analyze",
    type=int,
    default=20,
    help="Max clusters to analyze with LLM (default: 20)"
)
@click.option(
    "--rerank/--no-rerank",
    default=False,
    help="Use reranker to improve cluster quality"
)
@click.option(
    "--rerank-model",
    type=click.Path(exists=True),
    default=None,
    help="Path to reranker GGUF model (auto-detected)"
)
@click.option(
    "--rerank-threshold",
    type=float,
    default=0.5,
    help="Minimum reranker score to keep (default: 0.5)"
)
@click.option(
    "--clear-cache",
    is_flag=True,
    help="Clear embedding cache before running"
)
@click.option(
    "--download-models",
    is_flag=True,
    help="Download all required models and exit"
)
@click.option(
    "--model-status",
    is_flag=True,
    help="Show status of all models and exit"
)
@click.version_option(version=__version__)
def main(
    path: Optional[str],
    threshold: float,
    min_cluster: int,
    output: str,
    exclude: tuple,
    focus: tuple,
    lang: Optional[str],
    verbose: bool,
    max_chunks: int,
    batch_size: int,
    min_lines: int,
    max_lines: int,
    analyze: bool,
    llm_model: Optional[str],
    max_analyze: int,
    rerank: bool,
    rerank_model: Optional[str],
    rerank_threshold: float,
    clear_cache: bool,
    download_models: bool,
    model_status: bool,
):
    """
    Find semantic code similarities for abstraction opportunities.

    PATH is the root directory to analyze.

    Examples:

      # Basic analysis
      cse ./src

      # Analyze Swift project with LLM explanations
      cse ./MyApp --focus "*.swift" --analyze

      # High-precision search
      cse ./src --threshold 0.90 --min-cluster 3

      # Generate markdown report
      cse ./lib -o markdown > similarities.md

      # Download models first
      cse --download-models
    """
    # Handle model management commands (don't require path)
    if model_status:
        print_model_status()
        sys.exit(0)

    if download_models:
        click.echo("📦 Downloading all models for code-similarity-engine...")
        results = download_all_models(verbose=True)
        failed = [k for k, v in results.items() if v is None]
        if failed:
            click.echo(f"\n❌ Failed to download: {', '.join(failed)}", err=True)
            sys.exit(1)
        click.echo("\n✅ All models downloaded successfully!")
        sys.exit(0)

    # Path is required for analysis
    if path is None:
        click.echo("❌ Error: PATH is required for analysis.", err=True)
        click.echo("   Use --help for usage information.", err=True)
        click.echo("   Use --download-models to download models.", err=True)
        click.echo("   Use --model-status to check model status.", err=True)
        sys.exit(1)

    root_path = Path(path).resolve()

    # Handle --clear-cache
    if clear_cache:
        from .cache import clear_cache as do_clear_cache
        if do_clear_cache(root_path):
            if verbose:
                click.echo("🗑️  Cleared embedding cache")
        else:
            if verbose:
                click.echo("   No cache to clear")

    if verbose:
        click.echo(f"🔍 Analyzing: {root_path}")
        click.echo(f"   Threshold: {threshold}")
        click.echo(f"   Min cluster size: {min_cluster}")
        click.echo(f"   Output format: {output}")
        if analyze:
            click.echo(f"   LLM analysis: enabled")
        if rerank:
            click.echo(f"   Reranking: enabled")

    # Stage 1: Index
    if verbose:
        click.echo("\n📂 Stage 1/4: Indexing codebase...")

    chunks = index_codebase(
        root_path=root_path,
        exclude_patterns=list(exclude),
        focus_patterns=list(focus),
        forced_language=lang,
        min_lines=min_lines,
        max_lines=max_lines,
        max_chunks=max_chunks,
        verbose=verbose,
    )

    if not chunks:
        click.echo("❌ No code chunks found. Check your path and filters.", err=True)
        sys.exit(1)

    if verbose:
        click.echo(f"   Found {len(chunks)} chunks")

    # Stage 2: Embed
    if verbose:
        click.echo("\n🧠 Stage 2/4: Generating embeddings...")

    # Ensure embedding model is available
    if not find_embedding_model():
        if verbose:
            click.echo("   No embedding model found, downloading...")
        downloaded = download_model("embedding", verbose=verbose)
        if not downloaded:
            click.echo("❌ Failed to download embedding model.", err=True)
            click.echo("   Run: cse --download-models", err=True)
            sys.exit(1)

    try:
        vectors = embed_chunks(
            chunks=chunks,
            batch_size=batch_size,
            verbose=verbose,
        )
    except (ImportError, FileNotFoundError) as e:
        click.echo(f"❌ Embedding failed: {e}", err=True)
        sys.exit(1)

    # Stage 3: Cluster
    if verbose:
        click.echo("\n🔗 Stage 3/4: Clustering similar regions...")

    clusters = cluster_vectors(
        vectors=vectors,
        chunks=chunks,
        threshold=threshold,
        min_cluster_size=min_cluster,
        verbose=verbose,
    )

    if not clusters:
        click.echo("✨ No similar regions found above threshold. Your code is unique!")
        sys.exit(0)

    if verbose:
        click.echo(f"   Found {len(clusters)} clusters")

    # Stage 3.5: Rerank (optional)
    if rerank and clusters:
        if verbose:
            click.echo("\n📊 Stage 3.5: Reranking clusters...")

        # Ensure reranker model is available
        if rerank_model is None and not get_model_path("reranker"):
            if verbose:
                click.echo("   No reranker model found, downloading...")
            download_model("reranker", verbose=verbose)

        from .reranker import rerank_clusters as do_rerank

        try:
            reranked = do_rerank(
                clusters=clusters,
                model_path=Path(rerank_model) if rerank_model else None,
                threshold=rerank_threshold,
                verbose=verbose,
            )
            # Extract refined clusters
            clusters = [c for c, _ in reranked]
            # Filter out empty clusters
            clusters = [c for c in clusters if len(c.chunks) >= min_cluster]

            if verbose:
                click.echo(f"   After reranking: {len(clusters)} clusters")
        except (ImportError, FileNotFoundError) as e:
            if verbose:
                click.echo(f"   ⚠️  Reranking skipped: {e}")

    # Stage 4: Analyze (optional LLM)
    analyses = {}
    if analyze:
        if verbose:
            click.echo("\n🤖 Stage 4/5: LLM analysis...")

        # Ensure LLM model is available
        if llm_model is None and not get_model_path("llm"):
            if verbose:
                click.echo("   No LLM model found, downloading...")
            download_model("llm", verbose=verbose)

        from .analyzer import analyze_clusters

        analyses = analyze_clusters(
            clusters=clusters,
            model_path=Path(llm_model) if llm_model else None,
            max_clusters=max_analyze,
            verbose=verbose,
        )

        if verbose:
            click.echo(f"   Analyzed {len(analyses)} clusters")

    # Stage 5: Report
    stage_num = "5/5" if analyze else "4/4"
    if verbose:
        click.echo(f"\n📝 Stage {stage_num}: Generating report...")

    output_format = OutputFormat(output)
    report = report_clusters(
        clusters=clusters,
        root_path=root_path,
        threshold=threshold,
        output_format=output_format,
        analyses=analyses,
    )

    click.echo(report)


# Entry point alias for pyproject.toml
cli = main


if __name__ == "__main__":
    main()
