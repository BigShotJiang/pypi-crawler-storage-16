"""
Report generator - formats cluster results for output.

Supports text, markdown, and json output formats.
Includes optional LLM analysis when available.
"""

from typing import List, Optional, Dict
from pathlib import Path
from enum import Enum
import json
from datetime import datetime

from .models import Cluster, CodeChunk


class OutputFormat(Enum):
    TEXT = "text"
    MARKDOWN = "markdown"
    JSON = "json"


def report_clusters(
    clusters: List[Cluster],
    root_path: Path,
    threshold: float,
    output_format: OutputFormat = OutputFormat.TEXT,
    analyses: Optional[Dict[int, "ClusterAnalysis"]] = None,
) -> str:
    """
    Generate a report of similar code clusters.

    Args:
        clusters: List of Cluster objects
        root_path: Root path (for display)
        threshold: Similarity threshold used
        output_format: Desired output format
        analyses: Optional dict of cluster_id -> ClusterAnalysis

    Returns:
        Formatted report string
    """
    analyses = analyses or {}

    if output_format == OutputFormat.TEXT:
        return _format_text(clusters, root_path, threshold, analyses)
    elif output_format == OutputFormat.MARKDOWN:
        return _format_markdown(clusters, root_path, threshold, analyses)
    elif output_format == OutputFormat.JSON:
        return _format_json(clusters, root_path, threshold, analyses)
    else:
        raise ValueError(f"Unknown format: {output_format}")


def _format_text(
    clusters: List[Cluster],
    root_path: Path,
    threshold: float,
    analyses: Dict[int, "ClusterAnalysis"],
) -> str:
    """Plain text format with unicode decorations."""
    lines = []

    # Header
    total_lines = sum(c.total_lines() for c in clusters)
    lines.append(f"🔍 Found {len(clusters)} similarity clusters in {root_path}")
    lines.append(f"   Threshold: {threshold:.0%} | Total duplicated lines: ~{total_lines}")
    if analyses:
        lines.append(f"   LLM analysis: {len(analyses)} clusters analyzed")
    lines.append("")

    for cluster in clusters:
        lines.append("━" * 70)
        lines.append(f"Cluster #{cluster.id}: Similarity {cluster.similarity_score:.0%}")
        lines.append(f"Files: {cluster.file_count} | Regions: {cluster.size} | Lines: ~{cluster.total_lines()}")
        lines.append("━" * 70)
        lines.append("")

        # List regions
        lines.append("📍 Similar Regions:")
        for chunk in cluster.chunks:
            preview = chunk.preview(50)
            lines.append(f"   • {chunk.location}")
            if chunk.name:
                lines.append(f"     └─ {chunk.chunk_type}: {chunk.name}")
            lines.append(f"     └─ {preview}")
        lines.append("")

        # LLM Analysis (if available)
        if cluster.id in analyses:
            analysis = analyses[cluster.id]
            lines.append("🤖 LLM Analysis:")
            lines.append(f"   📝 Commonality: {analysis.commonality}")
            lines.append(f"   💡 Suggestion: {analysis.abstraction}")
            lines.append(f"   🏷️  Suggested name: {analysis.suggested_name}")
            lines.append(f"   ⚡ Complexity: {analysis.complexity}")
            lines.append("")

        # Show representative code
        rep = cluster.representative
        lines.append("📝 Representative Code:")
        lines.append(f"   {rep.location}")
        lines.append("")

        # Indent and truncate code
        code_lines = rep.content.split("\n")[:15]  # Max 15 lines
        for code_line in code_lines:
            lines.append(f"   │ {code_line}")
        if len(rep.content.split("\n")) > 15:
            lines.append("   │ ...")
        lines.append("")

    return "\n".join(lines)


def _format_markdown(
    clusters: List[Cluster],
    root_path: Path,
    threshold: float,
    analyses: Dict[int, "ClusterAnalysis"],
) -> str:
    """Markdown format for documentation."""
    lines = []

    # Header
    total_lines = sum(c.total_lines() for c in clusters)
    lines.append("# Code Similarity Report")
    lines.append("")
    lines.append(f"**Path:** `{root_path}`  ")
    lines.append(f"**Threshold:** {threshold:.0%}  ")
    lines.append(f"**Clusters Found:** {len(clusters)}  ")
    lines.append(f"**Total Duplicated Lines:** ~{total_lines}")
    if analyses:
        lines.append(f"**LLM Analyzed:** {len(analyses)} clusters")
    lines.append("")
    lines.append("---")
    lines.append("")

    for cluster in clusters:
        lines.append(f"## Cluster {cluster.id}: {cluster.similarity_score:.0%} Similarity")
        lines.append("")
        lines.append(f"**{cluster.size} regions** across **{cluster.file_count} files** (~{cluster.total_lines()} lines)")
        lines.append("")

        # LLM Analysis (if available)
        if cluster.id in analyses:
            analysis = analyses[cluster.id]
            lines.append("### 🤖 Analysis")
            lines.append("")
            lines.append(f"**Commonality:** {analysis.commonality}")
            lines.append("")
            lines.append(f"**Suggested Refactor:** {analysis.abstraction}")
            lines.append("")
            lines.append(f"- **Suggested Name:** `{analysis.suggested_name}`")
            lines.append(f"- **Complexity:** {analysis.complexity}")
            lines.append("")

        # Table of regions
        lines.append("### Regions")
        lines.append("")
        lines.append("| File | Lines | Type | Name |")
        lines.append("|------|-------|------|------|")
        for chunk in cluster.chunks:
            name = chunk.name or "-"
            lines.append(f"| `{chunk.file_path}` | {chunk.start_line}-{chunk.end_line} | {chunk.chunk_type} | {name} |")
        lines.append("")

        # Code sample
        rep = cluster.representative
        lang = rep.language
        lines.append("### Representative Code")
        lines.append("")
        lines.append(f"From `{rep.location}`:")
        lines.append("")
        lines.append(f"```{lang}")

        # Truncate code for markdown
        code_lines = rep.content.split("\n")[:20]
        lines.append("\n".join(code_lines))
        if len(rep.content.split("\n")) > 20:
            lines.append("// ... (truncated)")

        lines.append("```")
        lines.append("")
        lines.append("---")
        lines.append("")

    return "\n".join(lines)


def _format_json(
    clusters: List[Cluster],
    root_path: Path,
    threshold: float,
    analyses: Dict[int, "ClusterAnalysis"],
) -> str:
    """JSON format for programmatic use."""
    data = {
        "meta": {
            "path": str(root_path),
            "threshold": threshold,
            "cluster_count": len(clusters),
            "total_duplicated_lines": sum(c.total_lines() for c in clusters),
            "llm_analyzed_count": len(analyses),
            "timestamp": datetime.now().isoformat(),
        },
        "clusters": [],
    }

    for cluster in clusters:
        cluster_data = {
            "id": cluster.id,
            "similarity": round(cluster.similarity_score, 4),
            "file_count": cluster.file_count,
            "region_count": cluster.size,
            "total_lines": cluster.total_lines(),
            "regions": [
                {
                    "file": str(chunk.file_path),
                    "start_line": chunk.start_line,
                    "end_line": chunk.end_line,
                    "chunk_type": chunk.chunk_type,
                    "name": chunk.name,
                    "preview": chunk.preview(80),
                }
                for chunk in cluster.chunks
            ],
            "representative": {
                "file": str(cluster.representative.file_path),
                "start_line": cluster.representative.start_line,
                "end_line": cluster.representative.end_line,
                "content": cluster.representative.content,
            },
        }

        # Add LLM analysis if available
        if cluster.id in analyses:
            analysis = analyses[cluster.id]
            cluster_data["analysis"] = {
                "commonality": analysis.commonality,
                "abstraction": analysis.abstraction,
                "suggested_name": analysis.suggested_name,
                "complexity": analysis.complexity,
            }

        data["clusters"].append(cluster_data)

    return json.dumps(data, indent=2)
