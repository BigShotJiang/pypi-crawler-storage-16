"""
Code embedder - converts code chunks into semantic vectors.

Uses Qwen3-Embedding via llama-cpp-python for fully offline operation.
"""

from typing import List, Optional
from pathlib import Path
import numpy as np


def _get_embedding_model_from_manager() -> Optional[Path]:
    """Get embedding model path from model_manager."""
    try:
        from .model_manager import get_model_path
        return get_model_path("embedding")
    except ImportError:
        return None


def find_embedding_model(model_path: Optional[Path] = None) -> Optional[Path]:
    """
    Find GGUF embedding model file.

    Args:
        model_path: Explicit path to model file

    Returns:
        Path to model file or None if not found
    """
    if model_path and Path(model_path).exists():
        return Path(model_path)

    # Use model_manager
    return _get_embedding_model_from_manager()


def embed_chunks(
    chunks: List["CodeChunk"],
    model_path: Optional[Path] = None,
    batch_size: int = 32,
    verbose: bool = False,
    quiet: bool = False,
) -> np.ndarray:
    """
    Embed code chunks using Qwen3-Embedding GGUF model.

    Args:
        chunks: List of CodeChunk objects
        model_path: Path to GGUF embedding model (auto-detected if None)
        batch_size: Chunks per progress update
        verbose: Print progress
        quiet: Suppress model loading messages

    Returns:
        NumPy array of shape (n_chunks, embedding_dim)

    Raises:
        ImportError: If llama-cpp-python is not installed
        FileNotFoundError: If no GGUF model found
    """
    from .models import CodeChunk

    # Find model
    model_file = find_embedding_model(model_path)
    if not model_file:
        raise FileNotFoundError(
            "No embedding model found. Download with:\n"
            "  cse --download-models"
        )

    try:
        from llama_cpp import Llama
    except ImportError:
        raise ImportError(
            "llama-cpp-python not installed. Install with:\n"
            "  pip install 'code-similarity-engine[llm]'"
        )

    if verbose and not quiet:
        print(f"   Loading embedding model: {model_file.name}")

    # Load model in embedding mode
    llm = Llama(
        model_path=str(model_file),
        embedding=True,      # Enable embedding extraction
        n_ctx=512,           # Context size for embeddings
        n_threads=4,         # CPU threads
        n_gpu_layers=-1,     # Use GPU if available (Metal on Mac)
        verbose=False,       # Suppress llama.cpp output
    )

    if verbose and not quiet:
        print(f"   Model loaded successfully")

    # Prepare texts
    texts = [_prepare_chunk_text(chunk) for chunk in chunks]

    # Embed all chunks
    all_embeddings = []

    for i, text in enumerate(texts):
        # Get embedding - llama.cpp returns list of floats
        embedding = llm.embed(text)
        all_embeddings.append(embedding)

        # Progress reporting
        if verbose and (i + 1) % batch_size == 0:
            print(f"   Embedded {i + 1}/{len(texts)} chunks...")

    if verbose and len(texts) % batch_size != 0:
        print(f"   Embedded {len(texts)}/{len(texts)} chunks")

    # Stack and normalize
    embeddings = np.array(all_embeddings, dtype=np.float32)

    # L2 normalize for cosine similarity
    norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
    norms = np.maximum(norms, 1e-9)  # Avoid division by zero
    embeddings = embeddings / norms

    return embeddings


def _prepare_chunk_text(chunk: "CodeChunk") -> str:
    """
    Prepare a code chunk for embedding.

    Include metadata prefix to help the model understand context.
    """
    parts = []

    # Context hint
    if chunk.name:
        parts.append(f"# {chunk.language} {chunk.chunk_type}: {chunk.name}")
    else:
        parts.append(f"# {chunk.language} {chunk.chunk_type}")

    # Normalized code
    code = _normalize_code(chunk.content)
    parts.append(code)

    return "\n".join(parts)


def _normalize_code(code: str) -> str:
    """Normalize code for better embedding quality."""
    lines = code.split("\n")

    # Strip trailing whitespace
    lines = [line.rstrip() for line in lines]

    # Collapse runs of blank lines
    normalized = []
    prev_blank = False
    for line in lines:
        is_blank = len(line.strip()) == 0
        if is_blank and prev_blank:
            continue
        normalized.append(line)
        prev_blank = is_blank

    result = "\n".join(normalized)

    # Truncate if too long
    max_chars = 512 * 4  # ~512 tokens
    if len(result) > max_chars:
        result = result[:max_chars] + "\n# ... (truncated)"

    return result
