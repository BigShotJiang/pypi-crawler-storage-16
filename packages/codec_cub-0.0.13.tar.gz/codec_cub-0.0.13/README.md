
# Codec Cub

[![pypi version](https://img.shields.io/pypi/v/codec-cub.svg)](https://pypi.org/project/codec-cub/)

Parsing shit and shit

## Installation

```bash
pip install codec-cub
```

With [`uv`](https://docs.astral.sh/uv/):

```bash
uv tool install codec-cub
```