# A set of codecs for various data formats


* Create a generalized parser for codecs that can handle multiple formats with similar structures. (pyparser?)

Add Support For:
* NIX Files
* Python Files (As a Database! hehehehe, this is ILLEGAL but fun to think about and I WILL DO IT!)
* NOT CSV, INI, or other stupid formats that suck.
