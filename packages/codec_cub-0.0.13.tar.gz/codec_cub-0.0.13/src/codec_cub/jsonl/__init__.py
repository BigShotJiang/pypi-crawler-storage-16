"""JSONL file handler and related utilities."""
