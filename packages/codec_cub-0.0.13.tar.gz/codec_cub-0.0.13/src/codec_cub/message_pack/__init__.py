"""A message packing and unpacking module using MessagePack format."""
