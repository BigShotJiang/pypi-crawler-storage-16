"""A set of common utilities for CodecCub."""

from typing import Any, Self

from funcy_bear.constants.characters import SPACE
from funcy_bear.constants.escaping import COMMA_SPACE


def first(obj: Any) -> Any:
    """Return the first item of a sequence or the object itself if not a sequence.

    Args:
        obj: The object to get the first item from.

    Returns:
        The first item of the sequence or the object itself.
    """
    try:
        return obj[0]
    except (TypeError, IndexError):
        return obj


def spaced(s: str) -> str:
    """Return the string with a leading and trailing space.

    Args:
        s: The string to space.

    Returns:
        The spaced string.
    """
    return f"{SPACE}{s}{SPACE}"


def comma_sep(items: list[str]) -> str:
    """Return a comma-separated string from a list of strings.

    Args:
        items: The list of strings.

    Returns:
        The comma-separated string.
    """
    return COMMA_SPACE.join(items)


def piped(*segs: object) -> str:
    """Join segments with pipe character.

    Args:
        *segs: The segments to join.

    Returns:
        The joined string.
    """
    return " | ".join(str(seg) for seg in segs)


class Wrapper:
    """A simple string wrapper with customizable delimiters and separator."""

    def __init__(self, c1: str, c2: str, sep: str) -> None:
        """Initialize the Wrapper with delimiters and separator."""
        self.char1: str = c1
        self.char2: str = c2
        self.sep: str = sep
        self.buffer: list[str] = []
        self.append(self.char1)

    def append(self, s: str, pre: str = "", suf: str = "") -> Self:
        """Append a string with optional prefix and suffix.

        Args:
            s: The string to append.
            pre: The prefix to add before the string.
            suf: The suffix to add after the string.

        Returns:
            Self: The Wrapper instance.
        """
        self.buffer.append(f"{pre}{s}{suf}")
        return self

    def render(self, sep: str | None = None, pre: str = "", suf: str = "") -> str:
        """Generate the final wrapped string.

        Args:
            sep: The separator to use between elements. If None, uses the instance's separator.
            pre: The prefix to add before the closing character.
            suf: The suffix to add after the closing character.

        Returns:
            The final wrapped string.
        """
        self.append(self.char2, pre, suf)
        output: str = sep.join(self.buffer) if sep is not None else self.sep.join(self.buffer)
        self.buffer.pop()  # Remove the closing character for potential further appends
        return output


__all__ = ["COMMA_SPACE", "Wrapper", "comma_sep", "first", "piped", "spaced"]
