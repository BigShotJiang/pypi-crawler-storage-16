"""A set of helpful scripts for various tasks."""
