"""A codec for Nix files."""

from .file_handler import NixFileHandler

__all__ = ["NixFileHandler"]
