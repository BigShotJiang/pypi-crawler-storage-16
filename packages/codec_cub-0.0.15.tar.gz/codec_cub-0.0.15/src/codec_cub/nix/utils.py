"""A set of utility functions for CodecCub."""
