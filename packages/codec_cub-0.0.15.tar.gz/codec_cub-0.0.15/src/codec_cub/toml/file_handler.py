"""TOML file handler for Bear Dereth."""

from __future__ import annotations

import tomllib
from typing import IO, TYPE_CHECKING, Any, Self

import tomlkit

from codec_cub.general.base_file_handler import BaseFileHandler
from codec_cub.general.file_lock import LockExclusive, LockShared

if TYPE_CHECKING:
    from pathlib import Path

TomlData = dict[str, Any]


class TomlFileHandler(BaseFileHandler[TomlData]):
    """TOML file handler with caching and utilities."""

    def __init__(self, file: Path | str, touch: bool = False) -> None:
        """Initialize the handler with a file path.

        Args:
            path: Path to the TOML file
        """
        super().__init__(file, mode="r+", encoding="utf-8", touch=touch)

    def read(self, **kwargs) -> TomlData | None:
        """Read the entire file (or up to n chars) as text with a shared lock."""
        handle: IO[Any] | None = self.handle()
        if handle is None:
            raise ValueError("File handle is not available.")
        with LockShared(handle):
            handle.seek(0)
            data: str = handle.read(kwargs.pop("n", -1))
            convert_none: bool = kwargs.get("convert_none", False)
            return self.to_dict(data, convert_none=convert_none) if data else None

    def write(self, data: TomlData, **kwargs) -> None:
        """Replace file contents with text using an exclusive lock.

        Args:
            data: Data to write to the TOML file
            **kwargs: Additional keyword arguments like 'sort_keys' (bool), 'exclude_none' (bool), 'convert_none' (bool)

        Raises:
            ValueError: If file cannot be written
        """
        handle: IO[Any] | None = self.handle()
        if handle is None:
            raise ValueError("File handle is not available.")
        with LockExclusive(handle):
            handle.seek(0)
            handle.truncate(0)
            sort_keys: bool = kwargs.get("sort_keys", False)
            exclude_none: bool = kwargs.get("exclude_none", False)
            convert_none: bool = kwargs.get("convert_none", False)
            output: str = (
                self.to_string(data, sort_keys=sort_keys, exclude_none=exclude_none, convert_none=convert_none)
                if isinstance(data, dict)
                else data
            )
            handle.write(output)
            handle.flush()

    def to_dict(self, s: str, convert_none: bool = False) -> dict[str, Any]:
        """Parse a TOML string into a dictionary.

        Args:
            s: TOML string to parse
            convert_none: Whether to convert "null" strings to None

        Returns:
            Parsed TOML data as dictionary

        Raises:
            tomllib.TOMLDecodeError: If file contains invalid TOML
            ValueError: If file cannot be read
        """
        try:
            parsed = tomllib.loads(s)
            if convert_none:
                parsed: dict[str, Any | None] = self.null_to_none(parsed)
            return parsed
        except tomllib.TOMLDecodeError as e:
            raise ValueError(f"Invalid TOML in {self.file}: {e}") from e
        except Exception as e:
            raise ValueError(f"Error reading TOML file {self.file}: {e}") from e

    def to_string(
        self,
        data: TomlData,
        *,
        sort_keys: bool = False,
        exclude_none: bool = False,
        convert_none: bool = False,
    ) -> str:
        """Convert data to TOML string.

        Args:
            data: Data to serialize
            sort_keys: Whether to sort keys in output
            exclude_none: Whether to exclude None values
            convert_none: Whether to convert None to "null"

        Returns:
            TOML formatted string

        Raises:
            ValueError: If data cannot be serialized
        """
        if convert_none and exclude_none:
            raise ValueError("Cannot use both convert_none and exclude_none options together.")
        try:
            if convert_none:
                data = self.none_to_null(data)
            if exclude_none:
                data = {k: v for k, v in data.items() if v is not None}
            return tomlkit.dumps(data, sort_keys=sort_keys)
        except Exception as e:
            raise ValueError(f"Cannot serialize data to TOML: {e}") from e

    def null_to_none(self, data: TomlData) -> TomlData:
        """Convert "null" strings in the dictionary to None.

        Args:
            data: Data dictionary to convert
        Returns:
            Converted data dictionary
        """
        for k, v in data.items():
            if v == "null":
                data[k] = None
            if isinstance(v, dict):
                data[k] = self.null_to_none(v)
        return data

    def none_to_null(self, data: TomlData) -> TomlData:
        """Convert None values in the dictionary to "null" strings.

        Args:
            data: Data dictionary to convert
        Returns:
            Converted data dictionary
        """
        for k, v in data.items():
            if v is None:
                data[k] = "null"
            if isinstance(v, dict):
                data[k] = self.none_to_null(v)
        return data

    def get_section(
        self,
        data: TomlData | None,
        section: str,
        default: TomlData | None = None,
    ) -> dict[str, Any] | None:
        """Get a specific section from TOML data.

        Args:
            data: TOML data to search
            section: Section name (supports dot notation like 'tool.poetry')
            default: Default value if section not found

        Returns:
            Section data or default
        """
        current: TomlData | None = data or self.read()
        if current is None or not isinstance(current, dict):
            return default
        for key in section.split("."):
            if not isinstance(current, dict) or key not in current:
                return default
            if isinstance(current, dict) and key in current:
                current = current[key]
        return current if isinstance(current, dict) else default

    def __enter__(self) -> Self:
        """Enter context manager."""
        self.read()
        return self

    def __exit__(self, exc_type: object, exc_value: object, traceback: object) -> None:
        """Exit context manager."""


__all__ = ["TomlData", "TomlFileHandler"]
