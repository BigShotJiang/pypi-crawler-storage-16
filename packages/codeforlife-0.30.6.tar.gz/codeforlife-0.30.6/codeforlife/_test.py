"""
© Ocado Group
Created on 12/04/2024 at 14:31:10(+01:00).
"""


def test_import():
    """Basic test to ensure importing the package does not raise an error."""
    # pylint: disable-next=unused-import,import-outside-toplevel
    import codeforlife
