"""
© Ocado Group
Created on 20/02/2024 at 09:30:01(+00:00).
"""

from .. import USER_DIR

FIXTURES_DIR = USER_DIR.joinpath("fixtures")
TEMPLATES_DIR = USER_DIR.joinpath("templates")
