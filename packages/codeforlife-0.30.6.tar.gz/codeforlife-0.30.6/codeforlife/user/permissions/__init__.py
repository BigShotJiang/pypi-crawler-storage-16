"""
© Ocado Group
Created on 14/12/2023 at 14:05:06(+00:00).
"""

from .is_independent import IsIndependent
from .is_student import IsStudent
from .is_teacher import IsTeacher
from .synced_with_google import SyncedWithGoogle
