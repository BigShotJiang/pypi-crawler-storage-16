INVALID_LOGIN_MESSAGE = "Something is wrong! Please check that you typed your details correctly and that you have verified your account via email."
