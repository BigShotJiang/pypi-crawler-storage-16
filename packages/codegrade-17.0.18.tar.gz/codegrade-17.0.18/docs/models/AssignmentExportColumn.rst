AssignmentExportColumn
======================

.. currentmodule:: codegrade.models.assignment_export_column

.. class:: AssignmentExportColumn

**Options**

* ``id``
* ``username``
* ``name``
* ``grade``
* ``created_at``
* ``assigned_to``
* ``general_feedback``
* ``line_feedback``
