AssignmentMaxPointsEnabledSetting
=================================

.. currentmodule:: codegrade.models.assignment_max_points_enabled_setting

.. autoclass:: AssignmentMaxPointsEnabledSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
