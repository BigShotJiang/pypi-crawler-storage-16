AutoTestResultState
===================

.. currentmodule:: codegrade.models.auto_test_result_state

.. class:: AutoTestResultState

**Options**

* ``not_started``
* ``setting_up``
* ``running_setup``
* ``running``
* ``passed``
* ``failed``
* ``timed_out``
* ``skipped``
