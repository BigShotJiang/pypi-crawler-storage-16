AutoTestRunnerState
===================

.. currentmodule:: codegrade.models.auto_test_runner_state

.. class:: AutoTestRunnerState

**Options**

* ``starting``
* ``waiting_for_image``
* ``running_setup``
* ``uploading_image``
* ``restoring_image``
* ``running``
* ``finished``
