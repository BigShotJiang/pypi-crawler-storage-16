AutoTestSet
===========

.. currentmodule:: codegrade.models.auto_test_set

.. autoclass:: AutoTestSet
   :members: id, suites, stop_points
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
