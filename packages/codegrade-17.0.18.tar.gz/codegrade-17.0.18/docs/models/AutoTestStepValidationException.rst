AutoTestStepValidationException
===============================

.. currentmodule:: codegrade.models.auto_test_step_validation_exception

.. autoclass:: AutoTestStepValidationException
   :members: step_idx
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
