AutomaticLtiRoleEnabledSetting
==============================

.. currentmodule:: codegrade.models.automatic_lti_role_enabled_setting

.. autoclass:: AutomaticLtiRoleEnabledSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
