BaseAbout
=========

.. currentmodule:: codegrade.models.base_about

.. autoclass:: BaseAbout
   :members: commit, settings, release, current_time
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
