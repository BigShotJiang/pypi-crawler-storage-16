BaseCommentBaseWithNormalReplies
================================

.. currentmodule:: codegrade.models.base_comment_base_with_normal_replies

.. autoclass:: BaseCommentBaseWithNormalReplies
   :members: replies
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
