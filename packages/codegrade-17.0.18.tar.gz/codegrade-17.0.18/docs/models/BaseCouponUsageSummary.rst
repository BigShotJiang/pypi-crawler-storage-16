BaseCouponUsageSummary
======================

.. currentmodule:: codegrade.models.base_coupon_usage_summary

.. autoclass:: BaseCouponUsageSummary
   :members: id, success_at
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
