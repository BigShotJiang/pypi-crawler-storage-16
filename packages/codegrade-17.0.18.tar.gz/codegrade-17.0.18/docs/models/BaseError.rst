BaseError
=========

.. currentmodule:: codegrade.models.base_error

.. autoclass:: BaseError
   :members: message, description, code, request_id
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
