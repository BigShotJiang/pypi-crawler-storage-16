BasePrice
=========

.. currentmodule:: codegrade.models.base_price

.. autoclass:: BasePrice
   :members: id, currency, amount, refund_period, tax_behavior
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
