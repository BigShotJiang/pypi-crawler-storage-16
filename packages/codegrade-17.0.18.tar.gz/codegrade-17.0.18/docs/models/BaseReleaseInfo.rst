BaseReleaseInfo
===============

.. currentmodule:: codegrade.models.base_release_info

.. autoclass:: BaseReleaseInfo
   :members: commit
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
