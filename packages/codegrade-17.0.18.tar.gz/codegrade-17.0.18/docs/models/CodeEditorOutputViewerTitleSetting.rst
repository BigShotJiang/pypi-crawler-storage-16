CodeEditorOutputViewerTitleSetting
==================================

.. currentmodule:: codegrade.models.code_editor_output_viewer_title_setting

.. autoclass:: CodeEditorOutputViewerTitleSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
