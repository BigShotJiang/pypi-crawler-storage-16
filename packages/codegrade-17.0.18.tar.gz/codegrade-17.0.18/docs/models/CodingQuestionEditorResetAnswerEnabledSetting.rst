CodingQuestionEditorResetAnswerEnabledSetting
=============================================

.. currentmodule:: codegrade.models.coding_question_editor_reset_answer_enabled_setting

.. autoclass:: CodingQuestionEditorResetAnswerEnabledSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
