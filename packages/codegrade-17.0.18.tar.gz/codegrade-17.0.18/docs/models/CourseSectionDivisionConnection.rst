CourseSectionDivisionConnection
===============================

.. currentmodule:: codegrade.models.course_section_division_connection

.. autoclass:: CourseSectionDivisionConnection
   :members: id, username, name
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
