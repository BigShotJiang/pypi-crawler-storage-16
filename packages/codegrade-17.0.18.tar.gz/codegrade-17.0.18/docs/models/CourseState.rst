CourseState
===========

.. currentmodule:: codegrade.models.course_state

.. class:: CourseState

**Options**

* ``visible``
* ``archived``
* ``deleted``
