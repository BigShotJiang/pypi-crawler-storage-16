CreateDivisionSectionData
=========================

.. currentmodule:: codegrade.models.create_division_section_data

.. autoclass:: CreateDivisionSectionData
   :members: users
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
