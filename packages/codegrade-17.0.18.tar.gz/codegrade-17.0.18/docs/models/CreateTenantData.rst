CreateTenantData
================

.. currentmodule:: codegrade.models.create_tenant_data

.. autoclass:: CreateTenantData
   :members: json, logo_default, logo_dark
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
