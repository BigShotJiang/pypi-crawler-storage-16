CustomOutputExtra
=================

.. currentmodule:: codegrade.models.custom_output_extra

.. autoclass:: CustomOutputExtra
   :members: type, data
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
