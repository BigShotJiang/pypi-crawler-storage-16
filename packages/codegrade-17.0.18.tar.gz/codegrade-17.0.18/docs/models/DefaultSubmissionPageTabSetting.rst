DefaultSubmissionPageTabSetting
===============================

.. currentmodule:: codegrade.models.default_submission_page_tab_setting

.. autoclass:: DefaultSubmissionPageTabSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
