ExtendedGroup
=============

.. currentmodule:: codegrade.models.extended_group

.. autoclass:: ExtendedGroup
   :members: virtual_user
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
