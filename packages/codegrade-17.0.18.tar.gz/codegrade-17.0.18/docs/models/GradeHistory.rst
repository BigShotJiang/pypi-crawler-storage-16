GradeHistory
============

.. currentmodule:: codegrade.models.grade_history

.. autoclass:: GradeHistory
   :members: changed_at, is_rubric, grade, passed_back, origin, user
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
