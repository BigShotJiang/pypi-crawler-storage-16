HideCodeEditorOutputViewerWithOnlyQuizStepsSetting
==================================================

.. currentmodule:: codegrade.models.hide_code_editor_output_viewer_with_only_quiz_steps_setting

.. autoclass:: HideCodeEditorOutputViewerWithOnlyQuizStepsSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
