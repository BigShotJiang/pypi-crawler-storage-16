IgnoredFilesException
=====================

.. currentmodule:: codegrade.models.ignored_files_exception

.. autoclass:: IgnoredFilesException
   :members: removed_files, invalid_files, original_tree, filter_version, filter_name, missing_files
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
