InlineRubricViewerEnabledSetting
================================

.. currentmodule:: codegrade.models.inline_rubric_viewer_enabled_setting

.. autoclass:: InlineRubricViewerEnabledSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
