InvalidOptionsException
=======================

.. currentmodule:: codegrade.models.invalid_options_exception

.. autoclass:: InvalidOptionsException
   :members: invalid_options
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
