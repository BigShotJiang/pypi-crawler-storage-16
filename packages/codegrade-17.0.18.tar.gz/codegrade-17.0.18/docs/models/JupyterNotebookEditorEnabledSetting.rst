JupyterNotebookEditorEnabledSetting
===================================

.. currentmodule:: codegrade.models.jupyter_notebook_editor_enabled_setting

.. autoclass:: JupyterNotebookEditorEnabledSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
