LtiUnsetDeadlineLockDateEnabledSetting
======================================

.. currentmodule:: codegrade.models.lti_unset_deadline_lock_date_enabled_setting

.. autoclass:: LtiUnsetDeadlineLockDateEnabledSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
