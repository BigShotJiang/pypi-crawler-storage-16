MissingCookieError
==================

.. currentmodule:: codegrade.models.missing_cookie_error

.. autoclass:: MissingCookieError
   :members: lms_capabilities
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
