NewAutoTestMaxDynamodbSizeSetting
=================================

.. currentmodule:: codegrade.models.new_auto_test_max_dynamodb_size_setting

.. autoclass:: NewAutoTestMaxDynamodbSizeSetting
   :members: name, value
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
