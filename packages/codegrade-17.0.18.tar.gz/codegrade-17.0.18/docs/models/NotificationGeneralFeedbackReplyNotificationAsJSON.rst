NotificationGeneralFeedbackReplyNotificationAsJSON
==================================================

.. currentmodule:: codegrade.models.notification_general_feedback_reply_notification_as_json

.. autoclass:: NotificationGeneralFeedbackReplyNotificationAsJSON
   :members: type
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
