PaymentRequired
===============

.. currentmodule:: codegrade.models.payment_required

.. autoclass:: PaymentRequired
   :members: tag, payment_options, last_transaction_failure
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
