PutEnrollLinkCourseData
=======================

.. currentmodule:: codegrade.models.put_enroll_link_course_data

.. autoclass:: PutEnrollLinkCourseData
   :members: role_id, expiration_date, id, allow_register
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
