PutTenantWidePriceTenantData
============================

.. currentmodule:: codegrade.models.put_tenant_wide_price_tenant_data

.. autoclass:: PutTenantWidePriceTenantData
   :members: currency, amount, refund_period, tax_behavior
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
