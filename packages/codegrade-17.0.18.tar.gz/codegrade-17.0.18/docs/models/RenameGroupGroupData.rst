RenameGroupGroupData
====================

.. currentmodule:: codegrade.models.rename_group_group_data

.. autoclass:: RenameGroupGroupData
   :members: name
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
