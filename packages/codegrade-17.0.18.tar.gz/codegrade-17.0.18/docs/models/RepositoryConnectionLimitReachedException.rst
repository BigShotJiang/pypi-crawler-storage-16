RepositoryConnectionLimitReachedException
=========================================

.. currentmodule:: codegrade.models.repository_connection_limit_reached_exception

.. autoclass:: RepositoryConnectionLimitReachedException
   :members: webhook_id
   :inherited-members:
   :exclude-members: raw_data, data_parser, to_dict, from_dict, __init__, __new__
