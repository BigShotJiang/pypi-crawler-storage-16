RubricDescriptionType
=====================

.. currentmodule:: codegrade.models.rubric_description_type

.. class:: RubricDescriptionType

**Options**

* ``plain_text``
* ``markdown``
