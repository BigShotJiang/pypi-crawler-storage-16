# Auth package – placeholder for authentication utilities
