# Data package – placeholder for data adapters (MongoDB, Spanner, SQL, BigQuery, GCS)
