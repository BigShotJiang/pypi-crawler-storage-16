"""
This agent allows one to call the IPL checker on IPL code. \
This is useful as a subagent when generating IPL from some other source language.
"""
