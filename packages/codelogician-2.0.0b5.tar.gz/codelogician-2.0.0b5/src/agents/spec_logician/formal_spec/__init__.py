"""
This agent allows one to translate natural language Cucumber scenarios
to Formal Spec scenarios.
"""
