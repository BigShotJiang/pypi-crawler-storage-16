import random as rn

print (rn.random())

def hello():
    return rn.random()