


class MyClass:

    def __init__(self, a, b, c):
        self._a = a
        self._b = b
        self._c = c

    def compute(self, d):
        return self._a * d + self._b + self._c
    

# Prove that this function always returns a positive value
def david_function(a : int, b : int):
    if a > 0:
        return a * 100
    if b < 0: return b * -20

    return 101

# Prove that the following function always returns 2 * x where x is the input
def difficult_function(a : int):
    return a * 2

# Decompose this
def other_function(a : int):

    if a < -100:
        if a > -25: return -123
    elif a < 10:
        return a + 200
    else:
        350

# Decompose this
def other_function2(b : int):
    if a < -100:
        if a > -25: return -123
    elif a < 10:
        return a + 200
    else:
        350

# Decompose this
def other_function3(b : int):
    if a < -100:
        if a > -25: return -123
    elif a < 10:
        return a + 200
    else:
        350

# Decompose this
def other_function4(b : int):
    if a < -100:
        if a > -25: return -123
    elif a < 10:
        return a + 200
    else:
        350
# HELLLLO