"""Simple Math Library - A minimal pure Python math library."""

__version__ = "1.0.0"
