----
title: Algorithmic Trading
description: Effects of formalization and other things...
order: 1
----
