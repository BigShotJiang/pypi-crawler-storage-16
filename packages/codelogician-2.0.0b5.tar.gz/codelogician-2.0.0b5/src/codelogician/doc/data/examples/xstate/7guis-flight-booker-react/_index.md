----
title: XState xample – 7guis-flight-booker-react
description: XState Flight Booker example and IML model
order: 5
----