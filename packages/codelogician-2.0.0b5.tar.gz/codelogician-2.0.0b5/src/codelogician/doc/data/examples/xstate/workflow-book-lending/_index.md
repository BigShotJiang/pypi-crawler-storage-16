----
title: XState example - Book Lending
description: XState Book Lending example and IML model
order: 3
----