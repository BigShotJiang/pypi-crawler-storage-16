---
title: Examples
description: Region decomposition code examples
order: 10
---
