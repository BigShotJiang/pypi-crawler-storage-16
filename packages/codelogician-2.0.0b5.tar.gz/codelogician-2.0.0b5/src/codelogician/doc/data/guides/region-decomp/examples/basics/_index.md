---
title: Basic Examples
description: Basic region decomposition examples
order: 1
---
