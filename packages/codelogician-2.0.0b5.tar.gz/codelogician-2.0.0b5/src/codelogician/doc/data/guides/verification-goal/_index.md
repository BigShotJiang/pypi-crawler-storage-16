---
title: Verification Goals
description: Guides on using verification goals to prove properties
order: 11
---
