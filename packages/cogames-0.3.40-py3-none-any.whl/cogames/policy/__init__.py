"""Policy-related helpers."""

from mettagrid.policy.policy import MultiAgentPolicy

__all__ = ["MultiAgentPolicy"]
