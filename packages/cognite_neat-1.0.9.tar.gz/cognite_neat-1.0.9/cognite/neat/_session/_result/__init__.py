from ._result import Result

__all__ = ["Result"]
