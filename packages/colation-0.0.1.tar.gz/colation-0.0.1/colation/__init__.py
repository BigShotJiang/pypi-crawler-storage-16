"""
:Colation - minimal placeholder package for namespace reservation.

This version 0.0.1 only secures the 'colation' name on PyPI.
Actual functionality will be added in later releases.
"""

__all__ = []
__version__ = "0.0.1"
