Changelog
=========


1.0.4 (2025-12-11)
------------------

- Remove not needed form_data customization and set right label for form fields.
  [cekk]


1.0.3 (2025-03-07)
------------------

- collective.volto.formsupport new versions compatibility (>= 3.2.3).
  [folix-01]


1.0.2 (2025-02-25)
------------------

- collective.volto.formsupport new versions compatibility.
  [folix-01]


1.0.1 (2025-01-10)
------------------

- Fix counter value persistence problem.
  [folix-01]


1.0.0 (2025-01-09)
------------------

- Alignments with collective.volto.formsupport.
  [folix-01]


1.0.0rc4 (2024-11-22)
---------------------

- Label translated
  [mamico]


1.0.0rc3 (2024-11-19)
---------------------

- Fix counter
  [mamico]


1.0.0rc2 (2024-11-15)
---------------------

- Fix manifest
  [mamico]


1.0.0rc1 (2024-11-13)
---------------------

- Initial release.
  [RedTurtle]
