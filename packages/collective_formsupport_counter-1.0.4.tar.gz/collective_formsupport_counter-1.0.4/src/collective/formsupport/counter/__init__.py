"""Init and utils."""

from zope.i18nmessageid import MessageFactory

import logging


_ = MessageFactory("collective.formsupport.counter")
logger = logging.getLogger(__name__)
