COUNTER_ANNOTATIONS_NAME = "collective.formsupport.counter.form_counter"
COUNTER_ENABLED_FORM_FLAG_NAME = "counter_enabled"
COUNTER_BLOCKS_FIELD_ID = "form_counter"
