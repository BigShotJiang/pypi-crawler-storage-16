from collective.ftwslacker.slack_notifier import notify_slack  # noqa: F401
