"""collective.monkeypatcher"""
