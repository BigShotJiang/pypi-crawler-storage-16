"""Testing collective.monkeypatcher"""
