selector_to_html = {"a[href=\"#module-collective.transmute.cli\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\"><code class=\"docutils literal notranslate\"><span class=\"pre\">collective.transmute.cli</span></code><a class=\"headerlink\" href=\"#module-collective.transmute.cli\" title=\"Link to this heading\">#</a></h1><p>CLI entry point for <code class=\"docutils literal notranslate\"><span class=\"pre\">collective.transmute</span></code>.</p><p>This module provides the Typer-based command-line interface for converting\ndata from <code class=\"docutils literal notranslate\"><span class=\"pre\">collective.exportimport</span></code> to <code class=\"docutils literal notranslate\"><span class=\"pre\">plone.exportimport</span></code>.</p>", "a[href=\"#collective.transmute.cli.main\"]": "<dt class=\"sig sig-object py\" id=\"collective.transmute.cli.main\">\n<span class=\"sig-prename descclassname\"><span class=\"pre\">collective.transmute.cli.</span></span><span class=\"sig-name descname\"><span class=\"pre\">main</span></span><span class=\"sig-paren\">(</span><em class=\"sig-param\"><span class=\"n\"><span class=\"pre\">ctx</span></span><span class=\"p\"><span class=\"pre\">:</span></span><span class=\"w\"> </span><span class=\"n\"><span class=\"pre\">Context</span></span></em><span class=\"sig-paren\">)</span> <span class=\"sig-return\"><span class=\"sig-return-icon\">\u2192</span> <span class=\"sig-return-typehint\"><a class=\"reference external\" href=\"https://docs.python.org/3/library/constants.html#None\" title=\"(in Python v3.14)\"><span class=\"pre\">None</span></a></span></span><a class=\"reference internal\" href=\"../_modules/collective/transmute/cli.html#main\"><span class=\"viewcode-link\"><span class=\"pre\">[source]</span></span></a></dt><dd><p>Welcome to transmute, the utility to transform data from\n<code class=\"docutils literal notranslate\"><span class=\"pre\">collective.exportimport</span></code> to <code class=\"docutils literal notranslate\"><span class=\"pre\">plone.exportimport</span></code>.</p></dd>"}
skip_classes = ["headerlink", "sd-stretched-link"]

window.onload = function () {
    for (const [select, tip_html] of Object.entries(selector_to_html)) {
        const links = document.querySelectorAll(`article.bd-article ${select}`);
        for (const link of links) {
            if (skip_classes.some(c => link.classList.contains(c))) {
                continue;
            }

            tippy(link, {
                content: tip_html,
                allowHTML: true,
                arrow: true,
                placement: 'auto-end', maxWidth: 500, interactive: true,

            });
        };
    };
    console.log("tippy tips loaded!");
};
