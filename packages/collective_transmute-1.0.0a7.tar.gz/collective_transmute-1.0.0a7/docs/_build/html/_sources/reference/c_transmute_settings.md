---
myst:
  html_meta:
    "description": "collective.transmute Reference"
    "property=og:description": "collective.transmute Reference"
    "property=og:title": "collective.transmute Reference"
    "keywords": "Plone, collective.transmute, reference"
---

# `collective.transmute.settings`

```{eval-rst}
.. automodule:: collective.transmute.settings
    :members:
    :private-members:
```

## `collective.transmute.settings.parse`

```{eval-rst}
.. automodule:: collective.transmute.settings.parse
    :members:
    :private-members:
```
