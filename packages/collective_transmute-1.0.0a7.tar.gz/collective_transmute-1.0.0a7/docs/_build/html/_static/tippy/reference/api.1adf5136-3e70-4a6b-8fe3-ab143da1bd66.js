selector_to_html = {"a[href=\"#api\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\">API<a class=\"headerlink\" href=\"#api\" title=\"Link to this heading\">#</a></h1>", "a[href=\"c_transmute_steps.html\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\"><code class=\"docutils literal notranslate\"><span class=\"pre\">collective.transmute.steps</span></code><a class=\"headerlink\" href=\"#module-collective.transmute.steps\" title=\"Link to this heading\">#</a></h1><h2><code class=\"docutils literal notranslate\"><span class=\"pre\">collective.transmute.steps.basic_metadata</span></code><a class=\"headerlink\" href=\"#module-collective.transmute.steps.basic_metadata\" title=\"Link to this heading\">#</a></h2><p>Pipeline steps for basic metadata normalization in <code class=\"docutils literal notranslate\"><span class=\"pre\">collective.transmute</span></code>.</p><p>This module provides async generator functions for cleaning and setting metadata fields\nsuch as title and description. These steps are used in the transformation pipeline and\nare documented for Sphinx autodoc.</p>", "a[href=\"c_transmute_utils.html\"]": "<h1 class=\"tippy-header\" style=\"margin-top: 0;\"><code class=\"docutils literal notranslate\"><span class=\"pre\">collective.transmute.utils</span></code><a class=\"headerlink\" href=\"#collective-transmute-utils\" title=\"Link to this heading\">#</a></h1><h2><code class=\"docutils literal notranslate\"><span class=\"pre\">collective.transmute.utils.data</span></code><a class=\"headerlink\" href=\"#module-collective.transmute.utils.data\" title=\"Link to this heading\">#</a></h2><p>Data utilities for <code class=\"docutils literal notranslate\"><span class=\"pre\">collective.transmute</span></code>.</p><p>This module provides helper functions for sorting and manipulating data structures\nused in the transformation pipeline. Functions here are designed to be reusable\nacross steps and reporting.</p>"}
skip_classes = ["headerlink", "sd-stretched-link"]

window.onload = function () {
    for (const [select, tip_html] of Object.entries(selector_to_html)) {
        const links = document.querySelectorAll(`article.bd-article ${select}`);
        for (const link of links) {
            if (skip_classes.some(c => link.classList.contains(c))) {
                continue;
            }

            tippy(link, {
                content: tip_html,
                allowHTML: true,
                arrow: true,
                placement: 'auto-end', maxWidth: 500, interactive: true,

            });
        };
    };
    console.log("tippy tips loaded!");
};
