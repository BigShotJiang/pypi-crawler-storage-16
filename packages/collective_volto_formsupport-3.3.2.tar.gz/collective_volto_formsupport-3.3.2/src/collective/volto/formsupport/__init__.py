"""Init and utils."""

from zope.i18nmessageid import MessageFactory

import logging


logger = logging.getLogger(__name__)
_ = MessageFactory("collective.volto.formsupport")
