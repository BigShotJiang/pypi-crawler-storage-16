"""ColossalHQ - Coming soon."""

__version__ = "0.0.1"


def hello() -> str:
    """Return a greeting."""
    return "Hello from ColossalHQ! 🚀"
