"""
Prerequisites:
- AWS credentials configured
"""

import argparse
import boto3
import tempfile
import time
import os

from comet_ml import API, Optimizer
from comet_ml.exceptions import Unauthorized, NotFound
from comet_ml.config import get_config, get_optimizer_address
from .copy_utils import upload_single_offline_experiment
from .admin_optimizer_report import fetch_dashboard_data

def get_parser_arguments(parser):
    parser.add_argument(
        "optimizer-id",
        help="The Comet Optimizer ID",
        type=str,
    )
    parser.add_argument(
        "--bucket-name",
        help="The name of S3 bucket, if experiments are in S3",
        type=str,
    )
    parser.add_argument(
        "--object-key",
        help="The S3 object key, if experiments are in S3",
        type=str,
        default="",
    )
    parser.add_argument(
        "--path",
        help="The path to offline experiments, if not using S3",
        type=str,
        default="./cometml-runs"
    )
    parser.add_argument(
        "--debug",
        help=("Show debugging information"),
        type=bool,
        default=False,
    )
    parser.add_argument(
        "--parallel",
        "-j",
        help=("How many parallel experiments to upload"),
        type=int,
        default=20,
    )

class Uploader():
    def __init__(self, args):
        self.optimizer = Optimizer(args.optimizer_id)
        self.bucket_name = args.bucket_name
        self.object_key = args.object_key
        self.path = args.path
        self.debug = args.debug
        self.max_threads = args.parallel
        self.s3_client = None
        self.api = API()
        self.config = get_config()
        self.api_key = self.config["comet.api_key"]
        self.optimizer_url = get_optimizer_address(self.config)
        
    def download_from_s3(self, experiment_id):
        """
        Download file from S3 to temporary location.

        Args:
            experiment_id: experiment key

        Returns:
            filename of downloaded file
        """
        if self.s3_client is None:
            self.s3_client = boto3.client('s3')
            
        s3_uri = f"s3://{self.bucket_name}/{self.object_key}/{experiment_id}.zip"

        with tempfile.NamedTemporaryFile(delete=False, suffix='.zip') as tmp_file:
            tmp_file_path = tmp_file.name

        self.s3_client.download_file(self.bucket_name, self.object_key, tmp_file_path)

        return tmp_file_path

    def upload_experiment(self, filename):
        url = upload_single_offline_experiment(
            offline_archive_path=filename,
            settings=self.api.config,
            force_upload=True,
        )
        base_url, uploaded_key = url.rsplit("/", 1)
        return (url, uploaded_key)

    def get_processing_status(self, key):
        params = {"experimentKey": key}
        endpoint = "experiment/processing/status"
        try:
            results = self.api._client.get_from_endpoint(
                endpoint,
                params
            )
        except Unauthorized:
            print(f"You are not authorized to access this experiment key: {key}")
            return None
        except NotFound:
            print(f"Your Comet ML backend does not support this endpoint: {endpoint}")
            return None

        return results.get("processing")

    def upload_from_optimizer(self):
        while True:
            data, error = fetch_dashboard_data(
                self.optimizer_id,
                self.api_key,
                self.optimizer_url,
                status_filter=["completed"],
                page=1,
                page_size=self.max_threads,
            )
            for item in data:
                breakpoint()
                experiment_key = item["experiment_key"]
                if self.bucket_name is not None and self.object_key is not None:
                    filename = self.download_from_s3(experiment_key)
                else:
                    filename = os.path.join(self.path, experiment_key, ".zip")
                (url, uploaded_key) = self.upload_experiment(filename)
                # update optimizer status and metadata
            time.sleep(30)
        
        
def main(args):
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    get_parser_arguments(parser)
    parsed_args = parser.parse_args(args)
    uploader = Uploader(parsed_args)
    uploader.upload_from_optimizer()

if __name__ == "__main__":
    # Called via `python -m cometx.cli.upload_optimizer_experiments ...`
    main(sys.argv[1:])
