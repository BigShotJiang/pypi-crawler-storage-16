
## 🎁 Features

✅ 新增 `元数据记录` 功能，例如 `.czb` 的 `ComicInfo.xml`，具体看 [`配置 > 元数据类型`](https://doc.comicguispider.nyc.mn/config/#%E4%BB%A3%E7%90%86-proxies)  
✅ 简化处理发布页域名相关流程  
✨ `rvTool > 显示记录` 记录窗口新增 `搜索选中行` 按钮  
✨ 匹配记录提示，菜单操作增强

<img src="https://img.comicguispider.nyc.mn/file/1765701939059_feat-2.7.1-beta.2.png" alt="tag" width="400">

## 🐞 Fix

✅ 修复代理状态时拷贝流程仍然出错，具体看 [`faq > 拷贝访问相关`](https://doc.comicguispider.nyc.mn/faq/#_2-%E7%88%AC%E8%99%AB)  
✨ 修复 jm 域名获取（保底简化处理流程保留）  
✨ 子进度条修复，大部分转用内置浏览器  
