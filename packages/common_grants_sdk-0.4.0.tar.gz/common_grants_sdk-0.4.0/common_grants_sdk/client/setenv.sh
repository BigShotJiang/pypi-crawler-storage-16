##################################################
# Common Grants API Client Environment Variables #
##################################################

export CG_API_BASE_URL="http://localhost:8080"
export CG_API_KEY=None
export CG_API_TIMEOUT=10.0
export CG_API_PAGE_SIZE=100
