"""
Integration test package for Composio SDK.

This package contains comprehensive integration tests for various Composio features,
including experimental MCP functionality.
"""

__all__ = []
