"""
Implementations for the provided safeguard combinators.
"""
