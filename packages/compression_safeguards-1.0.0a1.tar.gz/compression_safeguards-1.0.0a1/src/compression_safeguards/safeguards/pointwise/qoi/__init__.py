"""
Implementations for the provided pointwise quantity of interest (QoI) safeguards.
"""
