"""
Implementations for the provided stencil quantity of interest (QoI) safeguards.
"""
