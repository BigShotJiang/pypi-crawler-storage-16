"""
Helper modules for implementing safeguards.
"""
