// simple main function
int main()
{
  return 0;
}
