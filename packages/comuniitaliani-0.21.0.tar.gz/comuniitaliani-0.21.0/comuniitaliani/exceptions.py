class ComuneNotFoundError(Exception):
    """Eccezione personalizzata per comuni non trovati."""
    pass
