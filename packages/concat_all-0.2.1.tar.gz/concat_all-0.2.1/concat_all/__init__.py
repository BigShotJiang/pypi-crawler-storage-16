from concat_all.concat_all import concat_files, main

__all__ = ['concat_files', 'main'] 