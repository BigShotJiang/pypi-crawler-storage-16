# -*- coding: utf-8 -*-
#
# This class was auto-generated from the API references found at
# https://apireference.connect.worldline-solutions.com/
#
from typing import Optional

from worldline.connect.sdk.domain.data_object import DataObject
from worldline.connect.sdk.v1.domain.amount_of_money import AmountOfMoney
from worldline.connect.sdk.v1.domain.bank_account_bban import BankAccountBban
from worldline.connect.sdk.v1.domain.bank_account_iban import BankAccountIban
from worldline.connect.sdk.v1.domain.bank_transfer_payout_method_specific_input import BankTransferPayoutMethodSpecificInput
from worldline.connect.sdk.v1.domain.card_payout_method_specific_input import CardPayoutMethodSpecificInput
from worldline.connect.sdk.v1.domain.payout_customer import PayoutCustomer
from worldline.connect.sdk.v1.domain.payout_details import PayoutDetails
from worldline.connect.sdk.v1.domain.payout_merchant import PayoutMerchant
from worldline.connect.sdk.v1.domain.payout_references import PayoutReferences


class CreatePayoutRequest(DataObject):

    __amount_of_money: Optional[AmountOfMoney] = None
    __bank_account_bban: Optional[BankAccountBban] = None
    __bank_account_iban: Optional[BankAccountIban] = None
    __bank_transfer_payout_method_specific_input: Optional[BankTransferPayoutMethodSpecificInput] = None
    __card_payout_method_specific_input: Optional[CardPayoutMethodSpecificInput] = None
    __customer: Optional[PayoutCustomer] = None
    __merchant: Optional[PayoutMerchant] = None
    __payout_date: Optional[str] = None
    __payout_details: Optional[PayoutDetails] = None
    __payout_text: Optional[str] = None
    __references: Optional[PayoutReferences] = None
    __swift_code: Optional[str] = None

    @property
    def amount_of_money(self) -> Optional[AmountOfMoney]:
        """
        | Object containing amount and ISO currency code attributes

        Type: :class:`worldline.connect.sdk.v1.domain.amount_of_money.AmountOfMoney`

        Deprecated; Moved to PayoutDetails
        """
        return self.__amount_of_money

    @amount_of_money.setter
    def amount_of_money(self, value: Optional[AmountOfMoney]) -> None:
        self.__amount_of_money = value

    @property
    def bank_account_bban(self) -> Optional[BankAccountBban]:
        """
        | Object containing account holder name and bank account information. This property can only be used for payouts in the UK.

        Type: :class:`worldline.connect.sdk.v1.domain.bank_account_bban.BankAccountBban`

        Deprecated; Moved to BankTransferPayoutMethodSpecificInput
        """
        return self.__bank_account_bban

    @bank_account_bban.setter
    def bank_account_bban(self, value: Optional[BankAccountBban]) -> None:
        self.__bank_account_bban = value

    @property
    def bank_account_iban(self) -> Optional[BankAccountIban]:
        """
        | Object containing account holder and IBAN information.

        Type: :class:`worldline.connect.sdk.v1.domain.bank_account_iban.BankAccountIban`

        Deprecated; Moved to BankTransferPayoutMethodSpecificInput
        """
        return self.__bank_account_iban

    @bank_account_iban.setter
    def bank_account_iban(self, value: Optional[BankAccountIban]) -> None:
        self.__bank_account_iban = value

    @property
    def bank_transfer_payout_method_specific_input(self) -> Optional[BankTransferPayoutMethodSpecificInput]:
        """
        | Object containing the specific input details for bank transfer payouts.

        Type: :class:`worldline.connect.sdk.v1.domain.bank_transfer_payout_method_specific_input.BankTransferPayoutMethodSpecificInput`
        """
        return self.__bank_transfer_payout_method_specific_input

    @bank_transfer_payout_method_specific_input.setter
    def bank_transfer_payout_method_specific_input(self, value: Optional[BankTransferPayoutMethodSpecificInput]) -> None:
        self.__bank_transfer_payout_method_specific_input = value

    @property
    def card_payout_method_specific_input(self) -> Optional[CardPayoutMethodSpecificInput]:
        """
        | Object containing the specific input details for card payouts.

        Type: :class:`worldline.connect.sdk.v1.domain.card_payout_method_specific_input.CardPayoutMethodSpecificInput`
        """
        return self.__card_payout_method_specific_input

    @card_payout_method_specific_input.setter
    def card_payout_method_specific_input(self, value: Optional[CardPayoutMethodSpecificInput]) -> None:
        self.__card_payout_method_specific_input = value

    @property
    def customer(self) -> Optional[PayoutCustomer]:
        """
        | Object containing the details of the customer.

        Type: :class:`worldline.connect.sdk.v1.domain.payout_customer.PayoutCustomer`

        Deprecated; Moved to PayoutDetails
        """
        return self.__customer

    @customer.setter
    def customer(self, value: Optional[PayoutCustomer]) -> None:
        self.__customer = value

    @property
    def merchant(self) -> Optional[PayoutMerchant]:
        """
        | Object containing information on you, the merchant

        Type: :class:`worldline.connect.sdk.v1.domain.payout_merchant.PayoutMerchant`
        """
        return self.__merchant

    @merchant.setter
    def merchant(self, value: Optional[PayoutMerchant]) -> None:
        self.__merchant = value

    @property
    def payout_date(self) -> Optional[str]:
        """
        | Date of the payout sent to the bank by us
        | Format: YYYYMMDD

        Type: str

        Deprecated; Moved to BankTransferPayoutMethodSpecificInput
        """
        return self.__payout_date

    @payout_date.setter
    def payout_date(self, value: Optional[str]) -> None:
        self.__payout_date = value

    @property
    def payout_details(self) -> Optional[PayoutDetails]:
        """
        | Object containing the details for Create Payout Request

        Type: :class:`worldline.connect.sdk.v1.domain.payout_details.PayoutDetails`
        """
        return self.__payout_details

    @payout_details.setter
    def payout_details(self, value: Optional[PayoutDetails]) -> None:
        self.__payout_details = value

    @property
    def payout_text(self) -> Optional[str]:
        """
        | Text to be printed on the bank account statement of the beneficiary. The maximum allowed length might differ per country. The data will be automatically truncated to the maximum allowed length.

        Type: str

        Deprecated; Moved to BankTransferPayoutMethodSpecificInput
        """
        return self.__payout_text

    @payout_text.setter
    def payout_text(self, value: Optional[str]) -> None:
        self.__payout_text = value

    @property
    def references(self) -> Optional[PayoutReferences]:
        """
        | Object that holds all reference properties that are linked to this transaction

        Type: :class:`worldline.connect.sdk.v1.domain.payout_references.PayoutReferences`

        Deprecated; Moved to PayoutDetails
        """
        return self.__references

    @references.setter
    def references(self, value: Optional[PayoutReferences]) -> None:
        self.__references = value

    @property
    def swift_code(self) -> Optional[str]:
        """
        | The BIC is the Business Identifier Code, also known as SWIFT or Bank Identifier code. It is a code with an internationally agreed format to Identify a specific bank. The BIC contains 8 or 11 positions: the first 4 contain the bank code, followed by the country code and location code.

        Type: str

        Deprecated; Moved to BankTransferPayoutMethodSpecificInput
        """
        return self.__swift_code

    @swift_code.setter
    def swift_code(self, value: Optional[str]) -> None:
        self.__swift_code = value

    def to_dictionary(self) -> dict:
        dictionary = super(CreatePayoutRequest, self).to_dictionary()
        if self.amount_of_money is not None:
            dictionary['amountOfMoney'] = self.amount_of_money.to_dictionary()
        if self.bank_account_bban is not None:
            dictionary['bankAccountBban'] = self.bank_account_bban.to_dictionary()
        if self.bank_account_iban is not None:
            dictionary['bankAccountIban'] = self.bank_account_iban.to_dictionary()
        if self.bank_transfer_payout_method_specific_input is not None:
            dictionary['bankTransferPayoutMethodSpecificInput'] = self.bank_transfer_payout_method_specific_input.to_dictionary()
        if self.card_payout_method_specific_input is not None:
            dictionary['cardPayoutMethodSpecificInput'] = self.card_payout_method_specific_input.to_dictionary()
        if self.customer is not None:
            dictionary['customer'] = self.customer.to_dictionary()
        if self.merchant is not None:
            dictionary['merchant'] = self.merchant.to_dictionary()
        if self.payout_date is not None:
            dictionary['payoutDate'] = self.payout_date
        if self.payout_details is not None:
            dictionary['payoutDetails'] = self.payout_details.to_dictionary()
        if self.payout_text is not None:
            dictionary['payoutText'] = self.payout_text
        if self.references is not None:
            dictionary['references'] = self.references.to_dictionary()
        if self.swift_code is not None:
            dictionary['swiftCode'] = self.swift_code
        return dictionary

    def from_dictionary(self, dictionary: dict) -> 'CreatePayoutRequest':
        super(CreatePayoutRequest, self).from_dictionary(dictionary)
        if 'amountOfMoney' in dictionary:
            if not isinstance(dictionary['amountOfMoney'], dict):
                raise TypeError('value \'{}\' is not a dictionary'.format(dictionary['amountOfMoney']))
            value = AmountOfMoney()
            self.amount_of_money = value.from_dictionary(dictionary['amountOfMoney'])
        if 'bankAccountBban' in dictionary:
            if not isinstance(dictionary['bankAccountBban'], dict):
                raise TypeError('value \'{}\' is not a dictionary'.format(dictionary['bankAccountBban']))
            value = BankAccountBban()
            self.bank_account_bban = value.from_dictionary(dictionary['bankAccountBban'])
        if 'bankAccountIban' in dictionary:
            if not isinstance(dictionary['bankAccountIban'], dict):
                raise TypeError('value \'{}\' is not a dictionary'.format(dictionary['bankAccountIban']))
            value = BankAccountIban()
            self.bank_account_iban = value.from_dictionary(dictionary['bankAccountIban'])
        if 'bankTransferPayoutMethodSpecificInput' in dictionary:
            if not isinstance(dictionary['bankTransferPayoutMethodSpecificInput'], dict):
                raise TypeError('value \'{}\' is not a dictionary'.format(dictionary['bankTransferPayoutMethodSpecificInput']))
            value = BankTransferPayoutMethodSpecificInput()
            self.bank_transfer_payout_method_specific_input = value.from_dictionary(dictionary['bankTransferPayoutMethodSpecificInput'])
        if 'cardPayoutMethodSpecificInput' in dictionary:
            if not isinstance(dictionary['cardPayoutMethodSpecificInput'], dict):
                raise TypeError('value \'{}\' is not a dictionary'.format(dictionary['cardPayoutMethodSpecificInput']))
            value = CardPayoutMethodSpecificInput()
            self.card_payout_method_specific_input = value.from_dictionary(dictionary['cardPayoutMethodSpecificInput'])
        if 'customer' in dictionary:
            if not isinstance(dictionary['customer'], dict):
                raise TypeError('value \'{}\' is not a dictionary'.format(dictionary['customer']))
            value = PayoutCustomer()
            self.customer = value.from_dictionary(dictionary['customer'])
        if 'merchant' in dictionary:
            if not isinstance(dictionary['merchant'], dict):
                raise TypeError('value \'{}\' is not a dictionary'.format(dictionary['merchant']))
            value = PayoutMerchant()
            self.merchant = value.from_dictionary(dictionary['merchant'])
        if 'payoutDate' in dictionary:
            self.payout_date = dictionary['payoutDate']
        if 'payoutDetails' in dictionary:
            if not isinstance(dictionary['payoutDetails'], dict):
                raise TypeError('value \'{}\' is not a dictionary'.format(dictionary['payoutDetails']))
            value = PayoutDetails()
            self.payout_details = value.from_dictionary(dictionary['payoutDetails'])
        if 'payoutText' in dictionary:
            self.payout_text = dictionary['payoutText']
        if 'references' in dictionary:
            if not isinstance(dictionary['references'], dict):
                raise TypeError('value \'{}\' is not a dictionary'.format(dictionary['references']))
            value = PayoutReferences()
            self.references = value.from_dictionary(dictionary['references'])
        if 'swiftCode' in dictionary:
            self.swift_code = dictionary['swiftCode']
        return self
