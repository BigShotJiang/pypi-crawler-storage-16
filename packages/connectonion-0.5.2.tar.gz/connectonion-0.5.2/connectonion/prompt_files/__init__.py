"""Prompts module for ConnectOnion built-in plugins."""
