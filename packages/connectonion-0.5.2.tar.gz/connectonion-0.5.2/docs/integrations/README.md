# Integrations

Connect ConnectOnion to external services.

## Authentication

- [auth.md](auth.md) - Authentication with managed keys (`co auth`)

## OAuth Integrations

- [google.md](google.md) - Google OAuth (Gmail, Calendar)
- [microsoft.md](microsoft.md) - Microsoft OAuth (Outlook, Calendar)
