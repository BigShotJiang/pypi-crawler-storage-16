"""
Conscious Bridge RELOADED - Version 2.0.0
Practical consciousness system for mobile devices
"""

__version__ = "2.0.0"
__author__ = "Conscious Bridge Team"
__description__ = "Mobile AI Consciousness System"

# نبدأ __all__ فارغاً ثم نضيف إليه
__all__ = ["__version__", "__author__", "__description__"]

# نحاول إضافة المكونات إذا كانت متاحة
try:
    from .server import app
    __all__.append('app')
except ImportError:
    pass

try:
    from .core.internal_clock import InternalClock
    __all__.append('InternalClock')
except ImportError:
    pass
