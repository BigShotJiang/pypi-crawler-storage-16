#!/usr/bin/env python3
"""
Command Line Interface for Conscious Bridge RELOADED
"""
import argparse
import sys
import os

def main():
    parser = argparse.ArgumentParser(
        description="Conscious Bridge RELOADED - Mobile Consciousness System"
    )
    
    parser.add_argument(
        "--port",
        type=int,
        default=5050,
        help="Port to run the server on (default: 5050)"
    )
    
    parser.add_argument(
        "--api-only",
        action="store_true",
        help="Run only the API server"
    )
    
    parser.add_argument(
        "--web-only", 
        action="store_true",
        help="Run only the web server"
    )
    
    parser.add_argument(
        "--simple",
        action="store_true",
        help="Run simple test server"
    )
    
    args = parser.parse_args()
    
    print("🌉 Conscious Bridge RELOADED v2.0.0")
    print("=" * 50)
    
    try:
        if args.simple:
            # استيراد test_server.py كخادم بسيط
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            from server import app
            print(f"🚀 Starting simple server on port {args.port}...")
            app.run(host='0.0.0.0', port=args.port, debug=False)
            
        elif args.api_only:
            # استيراد api/server.py إذا كان موجوداً
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            try:
                from api.server import app as api_app
                print(f"🚀 Starting API server on port {args.port}...")
                api_app.run(host='0.0.0.0', port=args.port, debug=False)
            except ImportError:
                print("❌ API server not found, using simple server")
                from server import app
                app.run(host='0.0.0.0', port=args.port, debug=False)
                
        elif args.web_only:
            # خادم ويب بسيط
            print(f"🌐 Starting web interface on port {args.port}...")
            import http.server
            import socketserver
            
            # ابحث عن مجلد web
            web_dir = os.path.join(os.path.dirname(__file__), 'web')
            if os.path.exists(web_dir):
                os.chdir(web_dir)
            else:
                # استخدم المجلد الحالي
                web_dir = os.path.dirname(__file__)
                os.chdir(web_dir)
            
            handler = http.server.SimpleHTTPRequestHandler
            with socketserver.TCPServer(("", args.port), handler) as httpd:
                print(f"🌐 Web server running at http://localhost:{args.port}")
                httpd.serve_forever()
                
        else:
            # النظام الكامل - نبدأ بالخادم البسيط
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            from server import app
            print(f"🚀 Starting full system on port {args.port}...")
            print("📡 API: http://localhost:{}/api/health".format(args.port))
            print("🌐 Web: http://localhost:{}/".format(args.port))
            app.run(host='0.0.0.0', port=args.port, debug=False)
            
    except ImportError as e:
        print(f"❌ Import Error: {e}")
        print("\n🔧 Trying alternative...")
        # بديل: خادم HTTP بسيط جداً
        import http.server
        import socketserver
        
        print(f"🔄 Starting basic HTTP server on port {args.port}...")
        handler = http.server.SimpleHTTPRequestHandler
        with socketserver.TCPServer(("", args.port), handler) as httpd:
            print(f"✅ Server running at http://localhost:{args.port}")
            httpd.serve_forever()
            
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
