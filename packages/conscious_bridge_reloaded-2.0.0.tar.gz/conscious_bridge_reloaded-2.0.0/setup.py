from setuptools import setup

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="conscious-bridge-reloaded",
    version="2.0.0",
    author="Conscious Bridge Team",
    author_email="riteofrenaissance@proton.me",
    description="Mobile AI Consciousness System for Android/Termux",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Conscious-Bridge-Law/conscious-bridge-reloaded",
    
    # الترخيص كتعبير SPDX
    license="MIT",
    
    packages=[
        'conscious_bridge_reloaded_pkg',
        'conscious_bridge_reloaded_pkg.api',
        'conscious_bridge_reloaded_pkg.core', 
        'conscious_bridge_reloaded_pkg.storage',
    ],
    package_dir={
        'conscious_bridge_reloaded_pkg': 'conscious_bridge_reloaded_pkg',
    },
    
    # التصنيفات المعدلة
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: Android",
        "Operating System :: POSIX :: Linux",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Internet :: WWW/HTTP :: HTTP Servers",
    ],
    python_requires=">=3.7",
    install_requires=[
        "flask>=2.0.0",
    ],
    entry_points={
        "console_scripts": [
            "cb-reloaded=conscious_bridge_reloaded_pkg.cli:main",
            "conscious-bridge-reloaded=conscious_bridge_reloaded_pkg.cli:main",
        ],
    },
)
