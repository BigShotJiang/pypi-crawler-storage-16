"""
API module for Conscious Bridge Reloaded
"""

__version__ = '2.0.0-reloaded'