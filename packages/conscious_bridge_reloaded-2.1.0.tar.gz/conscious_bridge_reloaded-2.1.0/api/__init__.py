"""
API module for Conscious Bridge Reloaded
"""

__version__ = '2.1.0'