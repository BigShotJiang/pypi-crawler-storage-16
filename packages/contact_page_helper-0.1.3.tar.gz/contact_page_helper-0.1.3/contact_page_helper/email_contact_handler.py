import yagmail
import csv
import traceback
import os

class EmailContactHandler:
    def __init__(self, url, receiver_email, sender_email, app_password, 
                 message, subject, company_name):
        """
        Initialize the EmailContactHandler with email details.
        
        Args:
            url: The URL associated with this contact attempt
            receiver_email: Recipient's email address
            sender_email: Sender's email address (for SMTP login)
            app_password: Gmail App Password for authentication
            message: Email body/content
            subject: Email subject line
            company_name: Display name for the sender
        """
        self.url = url
        self.receiver_email = receiver_email
        self.sender_email = sender_email
        self.app_password = app_password
        self.message = message
        self.subject = subject
        self.company_name = company_name
        self.success_file = "success.csv"
        self.failed_file = "failed.csv"
    
    def _log_success(self):
        """Log successful email sending to CSV (only URL)."""
        try:
            with open(self.success_file, 'a', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow([self.url])
            print(f"Success logged for: {self.url}")
        except Exception as e:
            print(f"Error logging success: {e}")
    
    def _log_failure(self, error_message):
        """Log failed email attempt to CSV (only URL and reason)."""
        try:
            with open(self.failed_file, 'a', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow([self.url, error_message])
            print(f"Failure logged for: {self.url}")
        except Exception as e:
            print(f"Error logging failure: {e}")
    
    def send_email(self):
        """
        Attempt to send the email and log the result.
        
        Returns:
            bool: True if email was sent successfully, False otherwise
        """
        print(f"Attempting to send email to {self.receiver_email}...")
        
        try:
            # Initialize yagmail SMTP connection
            yag = yagmail.SMTP(self.sender_email, self.app_password)
            
            # Send email with company name as sender display name
            yag.send(
                to=self.receiver_email,
                subject=self.subject,
                contents=self.message,
                headers={
                    "From": f"{self.company_name} <{self.sender_email}>"
                }
            )
            
            # Log success (only URL)
            self._log_success()
            print(f"Email sent successfully to {self.receiver_email}")
            return True
            
        except Exception as e:
            # Extract error message
            error_message = str(e)
            
            # Log failure (only URL and reason)
            self._log_failure(error_message)
            print(f"Failed to send email to {self.receiver_email}: {error_message}")
            return False
    
    def get_stats(self):
        """Get statistics of successful and failed attempts."""
        try:
            success_count = 0
            failed_count = 0
            
            # Count successful attempts
            if os.path.exists(self.success_file):
                with open(self.success_file, 'r', newline='', encoding='utf-8') as f:
                    reader = csv.reader(f)
                    success_count = sum(1 for row in reader)
            
            # Count failed attempts
            if os.path.exists(self.failed_file):
                with open(self.failed_file, 'r', newline='', encoding='utf-8') as f:
                    reader = csv.reader(f)
                    failed_count = sum(1 for row in reader)
            
            return {
                'successful': success_count,
                'failed': failed_count,
                'total': success_count + failed_count
            }
        except Exception as e:
            print(f"Error getting stats: {e}")
            return {'successful': 0, 'failed': 0, 'total': 0}
    
    def get_successful_urls(self):
        """Get list of all successfully processed URLs."""
        urls = []
        try:
            if os.path.exists(self.success_file):
                with open(self.success_file, 'r', newline='', encoding='utf-8') as f:
                    reader = csv.reader(f)
                    for row in reader:
                        if row:  # Check if row is not empty
                            urls.append(row[0])
            return urls
        except Exception as e:
            print(f"Error reading successful URLs: {e}")
            return []
    
    def get_failed_urls(self):
        """Get list of all failed URLs with reasons."""
        failed = []
        try:
            if os.path.exists(self.failed_file):
                with open(self.failed_file, 'r', newline='', encoding='utf-8') as f:
                    reader = csv.reader(f)
                    for row in reader:
                        if len(row) >= 2:  # Check if row has at least URL and reason
                            failed.append({
                                'url': row[0],
                                'reason': row[1]
                            })
                        elif row:  # If only URL exists
                            failed.append({
                                'url': row[0],
                                'reason': 'Unknown error'
                            })
            return failed
        except Exception as e:
            print(f"Error reading failed URLs: {e}")
            return []


# # Example usage
# if __name__ == "__main__":
#     # Example configuration
#     handler = EmailContactHandler(
#         url="https://example.com/contact",
#         receiver_email="recipient@example.com",
#         sender_email="chinedujosiahstu@gmail.com",  # Your Gmail address
#         app_password="npdi nfyt ztai guho",  # Your 16-char Gmail App Password
#         message="Hello, this is a test email from our system.",
#         subject="Test Email",
#         company_name="Your Company Name"
#     )
    
#     # Send the email
#     success = handler.send_email()
    
#     # Check stats
#     stats = handler.get_stats()
#     print(f"Email sending stats: {stats}")
    
#     # Get lists of URLs
#     if success:
#         print(f"Successful URLs: {handler.get_successful_urls()}")
#     else:
#         print(f"Failed URLs: {handler.get_failed_urls()}")