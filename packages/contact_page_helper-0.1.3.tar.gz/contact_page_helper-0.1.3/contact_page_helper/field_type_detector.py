# data/field_type_detector.py
import re
from typing import Dict, List, Optional
from .field_extractor import FormField
import logging

logger = logging.getLogger(__name__)

class FieldTypeDetector:
    """Detects field types based on multiple identifiers"""
    
    def __init__(self):
        self.patterns = self._compile_patterns()
    
    def detect(self, field: FormField) -> str:
        """Detect the type of data a field expects"""
        identifiers = self._collect_identifiers(field)
        
        # Try to match against patterns
        for field_type, patterns in self.patterns.items():
            if self._matches_patterns(identifiers, patterns):
                logger.debug(f"Field '{field.name}' detected as '{field_type}'")
                return field_type
        
        # Fallback to HTML input type
        logger.debug(f"Field '{field.name}' using default type: {field.field_type}")
        return field.field_type
    
    def _collect_identifiers(self, field: FormField) -> List[str]:
        """Collect all text identifiers from a field"""
        identifiers = []
        
        # Add all available text
        if field.name:
            identifiers.append(field.name.lower())
        if field.id:
            identifiers.append(field.id.lower())
        if field.placeholder:
            identifiers.append(field.placeholder.lower())
        if field.label:
            identifiers.append(field.label.lower())
        
        # Add attribute patterns
        for attr_name, attr_value in field.attributes.items():
            if isinstance(attr_value, str):
                identifiers.append(attr_value.lower())
        
        return identifiers
    
    def _matches_patterns(self, identifiers: List[str], patterns: List[re.Pattern]) -> bool:
        """Check if any identifier matches any pattern"""
        for identifier in identifiers:
            for pattern in patterns:
                if pattern.search(identifier):
                    return True
        return False
    
    def _compile_patterns(self) -> Dict[str, List[re.Pattern]]:
        """Compile regex patterns for field detection"""
        patterns = {
            'first_name': [
                r'first.?name', r'fname', r'given.?name', r'first', r'f.?name',
                r'name.*first', r'your.*first', r'firstname', r'first_name',
                r'givenname', r'given_name', r'forename'
            ],
            'last_name': [
                r'last.?name', r'lname', r'surname', r'family.?name', r'last',
                r'name.*last', r'your.*last', r'lastname', r'last_name',
                r'familyname', r'family_name'
            ],
            'full_name': [
                r'full.?name', r'your.?name', r'name', r'contact.*name',
                r'complete.*name', r'customer.*name', r'fullname', r'full_name',
                r'display.?name'
            ],
            'email': [
                r'email', r'e.?mail', r'mail', r'contact.*email', r'your.*email',
                r'email.*address', r'e.?mail.*address', r'electronic.?mail'
            ],
            'phone': [
                r'phone', r'mobile', r'tel', r'contact.*number', r'telephone',
                r'cell', r'phone.*number', r'mobile.*number', r'telephone.*number'
            ],
            'company': [
                r'company', r'organization', r'business', r'firm', r'org',
                r'corporate', r'company.*name', r'business.*name', r'employer'
            ],
            'job_title': [
                r'job.?title', r'position', r'role', r'designation', r'title',
                r'your.*title', r'job.*position', r'work.*title', r'occupation'
            ],
            'website': [
                r'website', r'url', r'site', r'web.*address', r'web.*site',
                r'your.*website', r'company.*website', r'business.*website'
            ],
            'address': [
                r'address', r'street', r'location', r'physical.*address',
                r'mailing.*address', r'your.*address', r'business.*address'
            ],
            'city': [
                r'city', r'town', r'location', r'your.*city', r'municipality',
                r'locality', r'city.*name', r'town.*name'
            ],
            'country': [
                r'country', r'nation', r'your.*country', r'nationality',
                r'residence.*country', r'country.*name', r'nation.*name'
            ],
            'subject': [
                r'subject', r'topic', r'regarding', r'about', r'reason',
                r'message.*subject', r'inquiry.*subject', r'purpose'
            ],
            'message': [
                r'message', r'comment', r'enquiry', r'description', r'query',
                r'details', r'help', r'your.*message', r'requirements', r'notes'
            ],
            'zip': [
                r'zip', r'zip.?code', r'postal.*code', r'postcode', r'postal',
                r'zip.*code', r'postal.*number', r'pincode'
            ],
            'state': [
                r'state', r'province', r'region', r'county', r'territory',
                r'state.*province', r'province.*state'
            ],
            'username': [
                r'user.?name', r'login', r'user', r'userid', r'user.*id',
                r'account.*name', r'login.*name'
            ],
            'password': [
                r'password', r'pass', r'pwd', r'secret', r'pass.*word',
                r'login.*password', r'user.*password'
            ]
        }
        
        # Compile all patterns
        compiled = {}
        for field_type, pattern_list in patterns.items():
            compiled[field_type] = [
                re.compile(pattern, re.IGNORECASE) for pattern in pattern_list
            ]
        
        return compiled