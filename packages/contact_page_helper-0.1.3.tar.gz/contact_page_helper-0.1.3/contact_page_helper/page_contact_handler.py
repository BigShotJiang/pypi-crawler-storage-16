# page_contact_handler.py
"""
Page Contact Handler Module
Main orchestrator for detecting, filling, and submitting contact forms on a page
"""

import time
import logging
import csv
import os
from typing import Dict, Any, Optional, Tuple
from datetime import datetime
from urllib.parse import urlparse

from .form_detector import FormDetector
from .field_extractor import FieldExtractor, FormField
from .form_filler import FormFiller
from .form_submitter import FormSubmitter
from .success_detector import SuccessDetector
from .screenshot_manager import ScreenshotManager
from .result_logger import ResultLogger
from .value_generator import ValueGenerator
from .field_type_detector import FieldTypeDetector
from .config import AppConfig
from selenium.webdriver.common.by import By

logger = logging.getLogger(__name__)


class PageContactHandler:
    """Main handler for contact form submission on a single page"""
     # Captcha indicators
    CAPTCHA_INDICATORS = [
        'captcha', 'recaptcha', 'hcaptcha', 'turnstile', 'security-code',
        'g-recaptcha', 'data-sitekey', 'cf-turnstile', 'h-captcha',
        'captcha-container', 'captcha-wrapper', 'captcha-response',
        'recaptcha-response', 'grecaptcha', 'captcha-token',
        'cf_captcha', 'captcha_input', 'captcha-code'
    ]
    def __init__(self, driver, data, config: Optional[AppConfig] = None):
        """
        Initialize the page contact handler
        
        Args:
            driver: Selenium WebDriver instance
            config: Application configuration (optional)
        """
        self.driver = driver
        self.data = data
        self.config = config or AppConfig.default()
        
        # Initialize components
        self.form_detector = FormDetector()
        self.field_extractor = FieldExtractor()
        self.form_filler = FormFiller(self.data, delay_range=self.config.submission.delay_between_fields,)
        self.form_submitter = FormSubmitter()
        self.success_detector = SuccessDetector()
        self.value_generator = ValueGenerator()
        self.field_type_detector = FieldTypeDetector()
        
        # Initialize utilities
        self.screenshot_manager = ScreenshotManager(
            self.config.storage.screenshot_dir
        )
        self.result_logger = ResultLogger(self.config.storage)
        
        # CSV files
        self.success_csv = "success.csv"
        self.failed_csv = "failed.csv"
        self._init_csv_files()
        
        # State
        self.original_url = None
        self.form_element = None
        self.form_fields = []
        self.filled_details = {}
        self.result = {}
        
    def _init_csv_files(self):
        """Initialize CSV files with headers if they don't exist"""
        # Success CSV
        if not os.path.exists(self.success_csv):
            with open(self.success_csv, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'url', 'initial_url', 'final_url', 
                    'page_title', 'form_found', 'form_submitted',
                    'filled_fields', 'success_reason'
                ])
        
        # Failed CSV
        if not os.path.exists(self.failed_csv):
            with open(self.failed_csv, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'url', 'initial_url', 'final_url',
                    'page_title', 'form_found', 'form_submitted',
                    'filled_fields', 'error', 'failure_reason'
                ])
    

    def _save_to_csv(self, csv_file: str, data: Dict[str, Any]):
        """
        Save result to CSV file

        success.csv → url
        failed.csv  → url, error
        """
        try:
            with open(csv_file, "a", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)

                # ✅ SUCCESS: only URL
                if csv_file == self.success_csv:
                    writer.writerow([
                        data.get("url", "")
                    ])

                # ✅ FAILED: URL + error
                else:
                    writer.writerow([
                        data.get("url", ""),
                        data.get("error", "")
                    ])

            logger.info(f"Result saved to {csv_file}")

        except Exception as e:
            logger.error(f"Error saving to {csv_file}: {e}")

    
    def process_page(self, data) -> Dict[str, Any]:
        """
        Process the current page or navigate to URL and process
        
        Args:
            data: URL to navigate to (if provided)
            
        Returns:
            Dictionary with processing results
        """
        try:
            # Initialize result structure
            self.result = self._create_result_template()
            
            # Get current URL if not provided
            if not self.result.get('url'):
                self.result['url'] = self.driver.current_url
            
            self.original_url = self.driver.current_url
            self.result['initial_url'] = self.original_url
            self.result['page_title'] = self.driver.title
            
            # Take before screenshot
            self.result['screenshot_before'] = self._take_screenshot('before')
            
            # Step 1: Detect form
            if not self._detect_form():
                self.result['error'] = "Form not found on page"
                self.result['success'] = False
                return False, "no form"
            
            # Step 2: Bot detector present?
            if self._has_captcha_in_form():
                return False, "form bot detected"

            # Step 3: Extract form fields
            self.result['form_found'] = True
            if not self._extract_form_fields():
                self.result['error'] = "No form fields found"
                self.result['success'] = False
                self._save_to_csv(self.failed_csv, self.result)
                return self.result
            
            # Step 4: Fill form fields
            if not self._fill_form():
                self.result['error'] = "Failed to fill form fields"
                self.result['success'] = False
                self._save_to_csv(self.failed_csv, self.result)
                return self.result
            
            self.result['form_filled'] = True
            
            # Step 5: Submit form
            if not self._submit_form():
                self.result['error'] = "Form submission failed"
                self.result['success'] = False
                return False, "submit failed"
            
            self.result['form_submitted'] = True
            
            # Step 6: Detect success
            self._detect_submission_success()
            
            # Step 6: Take after screenshot
            self.result['screenshot_after'] = self._take_screenshot('after', self.result['success'])
            
            # Step 7: Save to appropriate CSV
            if self.result['success']:
                self._save_to_csv(self.success_csv, self.result)
            else:
                self._save_to_csv(self.failed_csv, self.result)
            
            # Step 8: Log result (original logging)
            self._log_result()
            
            logger.info(f"Page processing completed: {'SUCCESS' if self.result['success'] else 'FAILED'}")
            
            return True, "valid"
            
        except Exception as e:
            logger.error(f"Error processing page: {e}", exc_info=True)
            self.result['error'] = str(e)
            self.result['success'] = False
            # Save to failed CSV even on exception
            self._save_to_csv(self.failed_csv, self.result)
            self.result_logger.log_submission(self.result)
            return self.result
    def _has_captcha_in_form(self) -> bool:
        """
        Check if form has captcha.
        
        Args:
            form_element: Selenium WebElement of the form
            
        Returns:
            True if captcha detected, False otherwise
        """
        try:
            # Get form HTML
            form_html = self.form_element.get_attribute('outerHTML').lower()
            
            # Check for captcha indicators in HTML
            for indicator in self.CAPTCHA_INDICATORS:
                if indicator in form_html:
                    return True
            
            # Check for captcha elements
            captcha_selectors = [
                ".g-recaptcha", "[data-sitekey]", ".h-captcha",
                ".cf-turnstile", "iframe[src*='recaptcha']",
                "iframe[src*='hcaptcha']", "iframe[src*='turnstile']"
            ]
            
            for selector in captcha_selectors:
                try:
                    elements = self.form_element.find_elements(By.CSS_SELECTOR, selector)
                    if elements:
                        return True
                except:
                    continue
            
            return False
            
        except Exception as e:
            return False
    def _create_result_template(self) -> Dict[str, Any]:
        """Create result template dictionary"""
        return {
            'url': '',
            'timestamp': datetime.now().isoformat(),
            'success': False,
            'form_found': False,
            'form_filled': False,
            'form_submitted': False,
            'submission_success': False,
            'success_reason': '',
            'error': None,
            'screenshot_before': None,
            'screenshot_after': None,
            'initial_url': None,
            'final_url': None,
            'page_title': None,
            'filled_fields': 0,
            'filled_details': {},
            'form_summary': {}
        }
    
    
    def _detect_form(self) -> bool:
        """Detect form on the page"""
        try:
            logger.info("Detecting form on page...")
            self.form_element = self.form_detector.find_form(self.driver)
            
            if self.form_element:
                logger.info(f"Form found: {self.form_element.tag_name}")
                
                # Add form summary to result
                self.result['form_summary']['tag_name'] = self.form_element.tag_name
                self.result['form_summary']['id'] = self.form_element.get_attribute('id')
                self.result['form_summary']['class'] = self.form_element.get_attribute('class')
                self.result['form_summary']['action'] = self.form_element.get_attribute('action')
                
                return True
            else:
                logger.warning("No form detected on page")
                return False
                
        except Exception as e:
            logger.error(f"Error detecting form: {e}")
            return False
    
    def _extract_form_fields(self) -> bool:
        """Extract all fields from the form"""
        try:
            logger.info("Extracting form fields...")
            self.form_fields = self.field_extractor.extract_fields(self.form_element)
            
            if not self.form_fields:
                logger.warning("No form fields extracted")
                return False
            
            logger.info(f"Extracted {len(self.form_fields)} form fields")
            
            # Add field summary to result
            self.result['form_summary']['total_fields'] = len(self.form_fields)
            self.result['form_summary']['field_types'] = {}
            
            for field in self.form_fields:
                field_type = field.field_type
                self.result['form_summary']['field_types'][field_type] = \
                    self.result['form_summary']['field_types'].get(field_type, 0) + 1
            
            return True
            
        except Exception as e:
            logger.error(f"Error extracting form fields: {e}")
            return False
    
    def _fill_form(self) -> bool:
        """Fill all form fields with generated values"""
        try:
            logger.info("Filling form fields...")
            
            # Fill the form
            self.filled_details = self.form_filler.fill_form(self.form_fields)
            
            if not self.filled_details:
                logger.warning("No fields were filled")
                return False
            
            # Update result
            self.result['filled_fields'] = len(self.filled_details)
            self.result['filled_details'] = self.filled_details
            
            logger.info(f"Filled {self.result['filled_fields']} fields")
            
            # Log what was filled
            for field_name, details in self.filled_details.items():
                value_preview = str(details['value'])[:50] + "..." if len(str(details['value'])) > 50 else str(details['value'])
                logger.debug(f"  {field_name} ({details['type']}): {value_preview}")
            
            return True
            
        except Exception as e:
            logger.error(f"Error filling form: {e}")
            return False
    
    def _submit_form(self) -> bool:
        """Submit the form"""
        try:
            logger.info("Submitting form...")
            
            success = self.form_submitter.submit(self.form_element)
            
            if success:
                logger.info("Form submitted successfully")
                
                # Wait for submission to process
                time.sleep(self.config.submission.success_detection_timeout)
                
                # Get final URL
                self.result['final_url'] = self.driver.current_url
                
                return True
            else:
                logger.warning("Form submission failed")
                return False
                
        except Exception as e:
            logger.error(f"Error submitting form: {e}")
            return False
    
    def _detect_submission_success(self):
        """Detect if form submission was successful"""
        try:
            logger.info("Detecting submission success...")
            
            success, reason = self.success_detector.detect(
                self.driver, 
                self.original_url,
                self.config.submission.success_detection_timeout
            )
            
            self.result['submission_success'] = success
            self.result['success_reason'] = reason
            self.result['success'] = success
            
            logger.info(f"Submission {'successful' if success else 'failed'}: {reason}")
            
        except Exception as e:
            logger.error(f"Error detecting submission success: {e}")
            self.result['success'] = False
            self.result['error'] = f"Success detection failed: {e}"
    
    def _take_screenshot(self, stage: str, success: bool = None) -> Optional[str]:
        """Take screenshot of current page"""
        try:
            # Generate filename
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            url_part = urlparse(self.result['url']).netloc.replace('.', '_')[:50] if self.result['url'] else 'unknown'
            
            if success is not None:
                status = 'success' if success else 'failure'
                filename = f"{url_part}_{stage}_{status}_{timestamp}.png"
            else:
                filename = f"{url_part}_{stage}_{timestamp}.png"
            
            # Take screenshot
            return self.screenshot_manager.take_full_page_screenshot(self.driver, filename)
            
        except Exception as e:
            logger.warning(f"Failed to take {stage} screenshot: {e}")
            return None
    
    def _log_result(self):
        """Log the processing result"""
        try:
            self.result_logger.log_submission(self.result)
            logger.debug(f"Result logged: {self.result['url']}")
        except Exception as e:
            logger.error(f"Error logging result: {e}")
    
    def get_form_analysis(self) -> Dict[str, Any]:
        """
        Analyze form without filling/submitting
        
        Returns:
            Dictionary with form analysis
        """
        try:
            analysis = {
                'url': self.driver.current_url,
                'form_detected': False,
                'fields_count': 0,
                'field_types': {},
                'form_info': {},
                'recommended_actions': []
            }
            
            # Detect form
            form = self.form_detector.find_form(self.driver)
            if not form:
                analysis['recommended_actions'].append("No form detected on page")
                return analysis
            
            analysis['form_detected'] = True
            analysis['form_info'] = {
                'tag_name': form.tag_name,
                'id': form.get_attribute('id'),
                'class': form.get_attribute('class'),
                'action': form.get_attribute('action')
            }
            
            # Extract fields
            fields = self.field_extractor.extract_fields(form)
            analysis['fields_count'] = len(fields)
            
            # Analyze field types
            for field in fields:
                field_type = field.field_type
                analysis['field_types'][field_type] = analysis['field_types'].get(field_type, 0) + 1
            
            # Generate recommendations
            if analysis['fields_count'] == 0:
                analysis['recommended_actions'].append("No fillable fields found in form")
            else:
                analysis['recommended_actions'].append(f"Found {analysis['fields_count']} fields to fill")
                analysis['recommended_actions'].append(f"Field types: {', '.join([f'{k}({v})' for k, v in analysis['field_types'].items()])}")
            
            return analysis
            
        except Exception as e:
            logger.error(f"Error analyzing form: {e}")
            return {
                'error': str(e),
                'recommended_actions': [f"Error analyzing form: {e}"]
            }
    
    def quick_submit(self, url: str = None) -> bool:
        """
        Quick submit without extensive logging or screenshots
        
        Args:
            url: URL to process (optional)
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Navigate if URL provided
            if url:
                self.driver.get(url)
                time.sleep(2)
            
            # Detect form
            form = self.form_detector.find_form(self.driver)
            if not form:
                logger.warning("No form found for quick submit")
                return False
            
            # Extract fields
            fields = self.field_extractor.extract_fields(form)
            if not fields:
                logger.warning("No fields found for quick submit")
                return False
            
            # Fill form (quickly)
            filler = FormFiller(delay_range=(0.01, 0.03))
            filler.fill_form(fields)
            
            # Submit
            submitter = FormSubmitter()
            if not submitter.submit(form):
                return False
            
            # Quick success check
            time.sleep(2)
            success, _ = self.success_detector.detect(self.driver, self.driver.current_url, 2)
            
            # Save to CSV
            result_data = {
                'timestamp': datetime.now().isoformat(),
                'url': self.driver.current_url,
                'success': success,
                'filled_fields': len(fields) if fields else 0
            }
            
            if success:
                self._save_to_csv(self.success_csv, result_data)
            else:
                self._save_to_csv(self.failed_csv, result_data)
            
            return success
            
        except Exception as e:
            logger.error(f"Quick submit failed: {e}")
            # Save failed result
            result_data = {
                'timestamp': datetime.now().isoformat(),
                'url': url or self.driver.current_url,
                'success': False,
                'error': str(e)
            }
            self._save_to_csv(self.failed_csv, result_data)
            return False
    
    def cleanup(self):
        """Cleanup resources"""
        # Nothing specific to cleanup here since driver is managed externally
        pass