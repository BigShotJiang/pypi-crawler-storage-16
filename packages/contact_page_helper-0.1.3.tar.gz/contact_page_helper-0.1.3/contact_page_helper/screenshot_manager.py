# utils/screenshot_manager.py
from pathlib import Path
from selenium.webdriver.remote.webdriver import WebDriver
import time
import logging
from typing import Optional
from datetime import datetime

logger = logging.getLogger(__name__)

class ScreenshotManager:
    """Manages taking and organizing screenshots"""
    
    def __init__(self, screenshot_dir: Path):
        self.screenshot_dir = screenshot_dir
        self.screenshot_dir.mkdir(parents=True, exist_ok=True)
    
    def take_full_page_screenshot(self, driver: WebDriver, filename: str) -> Optional[str]:
        """Take full page screenshot"""
        try:
            # Store original size
            original_size = driver.get_window_size()
            
            # Get total page height
            total_height = driver.execute_script("""
                return Math.max(
                    document.body.scrollHeight,
                    document.body.offsetHeight,
                    document.documentElement.clientHeight,
                    document.documentElement.scrollHeight,
                    document.documentElement.offsetHeight
                );
            """)
            
            if total_height == 0:
                total_height = original_size['height']
            
            # Cap height
            total_height = min(total_height, 10000)
            
            # Resize for full page
            driver.set_window_size(1920, total_height)
            time.sleep(1)  # Wait for resize
            
            # Take screenshot
            filepath = self.screenshot_dir / filename
            driver.save_screenshot(str(filepath))
            
            # Restore original size
            driver.set_window_size(original_size['width'], original_size['height'])
            
            logger.info(f"Screenshot saved: {filepath}")
            return str(filepath)
            
        except Exception as e:
            logger.error(f"Error taking full page screenshot: {e}")
            return self.take_viewport_screenshot(driver, f"fallback_{filename}")
    
    def take_viewport_screenshot(self, driver: WebDriver, filename: str) -> Optional[str]:
        """Take viewport screenshot (fallback)"""
        try:
            filepath = self.screenshot_dir / filename
            driver.save_screenshot(str(filepath))
            logger.info(f"Viewport screenshot saved: {filepath}")
            return str(filepath)
        except Exception as e:
            logger.error(f"Error taking viewport screenshot: {e}")
            return None
    
    def generate_filename(self, url: str, stage: str, thread_id: int = 0) -> str:
        """Generate screenshot filename"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Create safe filename from URL
        from urllib.parse import urlparse
        parsed = urlparse(url)
        domain = parsed.netloc.replace('.', '_')[:50] if parsed.netloc else 'unknown'
        
        return f"{domain}_{stage}_{thread_id}_{timestamp}.png"