import re
import json
import csv
import os
import time
from pathlib import Path
from typing import Optional, Dict, List
from urllib.parse import urlparse, urljoin
from bs4 import BeautifulSoup
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.remote.webdriver import WebDriver
from .form_detector import FormDetector 
from .page_contact_handler import PageContactHandler
import logging
import sys
from .email_contact_handler import EmailContactHandler

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('contact_automation.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)
class ContactPageAnalyzer:
    """Analyzes contact pages using Selenium WebDriver and FormDetector."""
    
   
    
    def __init__(self, driver, contact_url, data, verbose: bool = False, output_dir: str = "grade"):
        """
        Initialize the analyzer.
        
        Args:
            driver: Selenium WebDriver instance
            contact_url: The contact page URL
            verbose: verbose logging
            output_dir: Directory to save JSON files
        """
        self.driver = driver
        self.data = data
        self.contact_url = contact_url
        self.verbose = verbose
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        self.form_detector = FormDetector()
    
    def _scroll_page(self):
        """Scroll page to trigger lazy-loaded forms"""
        try:
            self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(1.2)
            self.driver.execute_script("window.scrollTo(0, 0);")
            time.sleep(0.5)
        except Exception as e:
            pass
    
    
    def _extract_email_addresses(self) -> List[str]:
        """Extract email addresses from page using multiple methods."""
        emails = set()
        
        try:
            # Get page source
            page_source = self.driver.page_source
            soup = BeautifulSoup(page_source, 'html.parser')
            
            # Method 1: Find mailto links
            mailto_links = soup.find_all('a', href=re.compile(r'^mailto:', re.I))
            for link in mailto_links:
                href = link.get('href', '')
                # Extract email from mailto link
                email_match = re.search(r'mailto:([^\?&]+)', href, re.I)
                if email_match:
                    email = email_match.group(1).strip()
                    # Clean up email (remove spaces, decode URL encoding)
                    email = email.replace(' ', '')
                    if re.match(r'^[a-zA-Z0-9._%+-]+@[A-Za-z0-9.-]+\.[a-zA-Z]{2,}$', email):
                        emails.add(email)
            
            # Method 2: Find email addresses in text
            text = soup.get_text()
            email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
            found_emails = re.findall(email_pattern, text, re.IGNORECASE)
            for email in found_emails:
                email = email.strip()
                email = email.replace(' ', '')
                emails.add(email)
            
            # Method 3: Try to find email elements with JavaScript
            script = """
                var emails = [];
                var emailRegex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}/g;
                
                // Check text nodes
                var textNodes = document.evaluate('//text()[contains(., "@")]', document, null, XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE, null);
                for (var i = 0; i < textNodes.snapshotLength; i++) {
                    var text = textNodes.snapshotItem(i).textContent;
                    var matches = text.match(emailRegex);
                    if (matches) {
                        emails.push(...matches);
                    }
                }
                
                // Check mailto links
                var mailtoLinks = document.querySelectorAll('a[href^="mailto:"]');
                mailtoLinks.forEach(function(link) {
                    var href = link.getAttribute('href');
                    var match = href.match(/mailto:([^\\?&]+)/i);
                    if (match) {
                        emails.push(match[1]);
                    }
                });
                
                return [...new Set(emails)];
            """
            
            js_emails = self.driver.execute_script(script)
            if js_emails:
                for email in js_emails:
                    email = email.strip()
                    email = email.replace(' ', '')
                    emails.add(email)
                    
        except Exception as e:
            pass
        
        return list(emails)
    
    def analyze_with_driver(self):
        """
        Analyze contact page using FormDetector and email extraction.
        
        Returns:
            - If valid form without captcha: returns it submits
            - If email contact: returns dict with contact info
            - If captcha or no contact: returns None
        """
        try:

            # ==================================================
            # STAGE 2A: LOCATE FORM AND SUBMIT IF PRESENT
            # ==================================================
            #  Route to PageContactHandler: analysis_result = driver
            handler = PageContactHandler(self.driver, self.data)
            success, message = handler.process_page()
            if success:
                return True
            if message == "form bot detected":
                print("Form found but bot detected")





            # ==================================================
            # STAGE 2B: TRY EMAIL
            # =================================================
            email_addresses = self._extract_email_addresses()
            if email_addresses:
                #Route to EmailContactHandler; analysis_result = dict
                handler = EmailContactHandler(self.data, email_addresses[0])
                success = handler.send_email()
                if success:
                    return True
            
            return False
            
        except Exception as e:
            return False
    
    def _save_to_json(self, category: str, url: str, data: Dict):
        """Save analysis results to appropriate JSON file."""
        filename = self.json_files[category]
        
        try:
            # Load existing data
            if os.path.exists(filename):
                with open(filename, 'r', encoding='utf-8') as f:
                    existing_data = json.load(f)
                    if not isinstance(existing_data, list):
                        existing_data = []
            else:
                existing_data = []
            
            # Check if URL already exists
            url_exists = any(item.get('url') == url for item in existing_data)
            
            if not url_exists:
                existing_data.append(data)
                
                # Save back to file
                with open(filename, 'w', encoding='utf-8') as f:
                    json.dump(existing_data, f, indent=2, default=str)
                
                if self.verbose:
                    print(f"[Saved] {url} to {filename.name}")
            
        except Exception as e:
            if self.verbose:
                print(f"[Save Error] Failed to save to {filename}: {e}")
    
    def _add_to_failed_csv(self, url: str):
        """Add URL to failed.csv."""
        try:
            # Check if URL already exists in CSV
            url_exists = False
            if os.path.exists(self.failed_csv):
                with open(self.failed_csv, 'r', newline='') as f:
                    reader = csv.reader(f)
                    for row in reader:
                        if row and row[0] == url:
                            url_exists = True
                            break
            
            if not url_exists:
                with open(self.failed_csv, 'a', newline='') as f:
                    writer = csv.writer(f)
                    writer.writerow([url])
                
                if self.verbose:
                    print(f"[CSV] Added {url} to {self.failed_csv}")
                    
        except Exception as e:
            if self.verbose:
                print(f"[CSV Error] {e}")
