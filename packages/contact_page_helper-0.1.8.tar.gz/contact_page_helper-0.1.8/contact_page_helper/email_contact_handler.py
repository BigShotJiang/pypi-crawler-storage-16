import yagmail
import csv
import traceback
import os
import logging

logger = logging.getLogger(__name__)

class EmailContactHandler:
    def __init__(self, data, receiver_email=None):
        """
        Initialize the EmailContactHandler with user data.
        
        Args:
            data: User data dictionary containing all business information
            receiver_email: Recipient's email address (can be None if extracted from page)
        """
        self.data = data
        self.receiver_email = receiver_email
        self.sender_email = self.data.get('email', 'default@gmail.com')
        self.app_password = self.data.get('app_password_clean', '')
        if not self.app_password and 'app_password' in self.data:
            self.app_password = self.data['app_password'].replace(' ', '')
        self.message = self.data.get('message', 'Hello, I am interested in discussing potential business opportunities and partnerships with your company. Please contact me at your earliest convenience.')
        self.subject = self.data.get('subject', 'Business Partnership Inquiry')
        self.company_name = self.data.get('companyName', 'Your Company')
        self.full_name = self.data.get('fullName', 'John Doe')
        
    
    def _log_success(self, receiver_email):
        """Log successful email sending to CSV."""
        try:
            from datetime import datetime
            timestamp = datetime.now().isoformat()
            
            with open(self.success_file, 'a', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow([timestamp, receiver_email, self.subject, 'sent'])
            logger.info(f"Email sent successfully to {receiver_email}")
            return True
        except Exception as e:
            logger.error(f"Error logging success: {e}")
            return False
    
    def _log_failure(self, receiver_email, error_message):
        """Log failed email attempt to CSV."""
        try:
            from datetime import datetime
            timestamp = datetime.now().isoformat()
            
            with open(self.failed_file, 'a', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow([timestamp, receiver_email, self.subject, error_message])
            logger.error(f"Email failed to {receiver_email}: {error_message}")
            return True
        except Exception as e:
            logger.error(f"Error logging failure: {e}")
            return False
    
    def send_email(self, receiver_email=None):
        """
        Attempt to send the email and log the result.
        
        Args:
            receiver_email: Optional receiver email (overrides the one from init)
            
        Returns:
            bool: True if email was sent successfully, False otherwise
        """
        # Use provided receiver email or the one from initialization
        target_email = receiver_email or self.receiver_email
        
        if not target_email:
            logger.error("No receiver email provided")
            return False
        
        if not self.app_password:
            error_msg = "App password not configured"
            logger.error(error_msg)
            self._log_failure(target_email, error_msg)
            return False
        
        logger.info(f"Attempting to send email to {target_email}...")
        
        try:
            # Initialize yagmail SMTP connection
            yag = yagmail.SMTP(self.sender_email, self.app_password)
            
            # Create email content
            email_content = f"""
            Dear {self.company_name} Team,
            
            {self.message}
            
            Best regards,
            {self.full_name}
            {self.company_name}
            
            Contact Information:
            Email: {self.sender_email}
            Phone: {self.data.get('phone', 'N/A')}
            Website: {self.data.get('website', 'N/A')}
            """
            
            # Send email with company name as sender display name
            yag.send(
                to=target_email,
                subject=self.subject,
                contents=email_content,
                headers={
                    "From": f"{self.full_name} <{self.sender_email}>"
                }
            )
            
            # Log success
            self._log_success(target_email)
            logger.info(f"Email sent successfully to {target_email}")
            return True
            
        except Exception as e:
            # Extract error message
            error_message = str(e)
            
            # Log failure
            self._log_failure(target_email, error_message)
            logger.error(f"Failed to send email to {target_email}: {error_message}")
            return False
    
    