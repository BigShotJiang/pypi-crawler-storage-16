# form/form_submitter.py
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.remote.webelement import WebElement
from selenium.common.exceptions import ElementClickInterceptedException
import time
import random
import logging
from typing import Optional

logger = logging.getLogger(__name__)

class FormSubmitter:
    """Handles form submission using multiple strategies"""
    
    def __init__(self):
        self.submit_selectors = [
            "input[type='submit']",
            "button[type='submit']",
            "input[value*='Submit']",
            "input[value*='Send']",
            ".submit-btn",
            ".submit-button",
            "#submit",
            "[type='submit']"
        ]
    
    def submit(self, form: WebElement) -> bool:
        """Submit a form using multiple strategies"""
        strategies = [
            self._submit_via_button,
            self._submit_via_javascript,
            self._submit_via_enter,
        ]
        
        for strategy in strategies:
            if strategy(form):
                return True
        
        logger.warning("Could not submit form using any method")
        return False
    
    def _submit_via_button(self, form: WebElement) -> bool:
        """Submit by clicking submit button"""
        submit_button = self._find_submit_button(form)
        if submit_button:
            try:
                # Scroll to button
                form.parent.execute_script(
                    "arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});",
                    submit_button
                )
                time.sleep(0.5)
                
                # Click button
                submit_button.click()
                logger.info("Form submitted via submit button")
                return True
                
            except ElementClickInterceptedException:
                # Try JavaScript click
                try:
                    form.parent.execute_script("arguments[0].click();", submit_button)
                    logger.info("Form submitted via JavaScript click")
                    return True
                except:
                    pass
        
        return False
    
    def _submit_via_javascript(self, form: WebElement) -> bool:
        """Submit using JavaScript"""
        try:
            form.parent.execute_script("arguments[0].submit();", form)
            logger.info("Form submitted via JavaScript submit()")
            return True
        except:
            return False
    
    def _submit_via_enter(self, form: WebElement) -> bool:
        """Submit by pressing Enter"""
        try:
            form.send_keys(Keys.RETURN)
            logger.info("Form submitted via Enter key")
            time.sleep(1)
            return True
        except:
            return False
    
    def _find_submit_button(self, form: WebElement) -> Optional[WebElement]:
        """Find submit button in form"""
        for selector in self.submit_selectors:
            try:
                if ':contains' in selector:
                    # Handle text contains
                    text = selector.split("'")[1]
                    xpath = f".//*[contains(text(), '{text}')]"
                    elements = form.find_elements(By.XPATH, xpath)
                else:
                    elements = form.find_elements(By.CSS_SELECTOR, selector)
                
                for element in elements:
                    if element.is_displayed() and element.is_enabled():
                        return element
            except:
                continue
        
        # Try any button in form
        try:
            buttons = form.find_elements(By.TAG_NAME, 'button')
            for button in buttons:
                if button.is_displayed() and button.is_enabled():
                    return button
        except:
            pass
        
        return None