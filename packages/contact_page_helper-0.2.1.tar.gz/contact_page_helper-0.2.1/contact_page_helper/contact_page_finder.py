import requests
from bs4 import BeautifulSoup, NavigableString, Tag
from urllib.parse import urljoin, urlparse
import re
import time

# Optional import for JS rendering. We import lazily inside methods to avoid hard dependency.
PLAYWRIGHT_AVAILABLE = False
try:
    # don't import at top-level to avoid hard failure when not installed;
    # we will import in method if user requests rendering
    import importlib
    if importlib.util.find_spec("playwright") is not None:
        PLAYWRIGHT_AVAILABLE = True
except Exception:
    PLAYWRIGHT_AVAILABLE = False


class ContactPageFinder:
    """
    Implements the PHES (Progressive Heuristic + Evidence Scoring) algorithm.

    Public API:
        finder = ContactPageFinder(render_js=False)
        result = finder.find("example.com")
        # result -> dict: { "contact_url": str|None, "confidence": float, "reason": str, "candidates": [...] }
    """

    # language-aware keywords (lowercase). Add more as needed.
    CONTACT_KEYWORDS = {
        "en": ["contact", "contact-us", "contactus", "get-in-touch", "reach-us", "contacto", "support", "getintouch", "connect"],
        "es": ["contacto", "contactar", "contáctenos", "contáctanos"],
        "fr": ["contact", "contactez", "nous-contacter"],
        "pt": ["contato", "contacte"],
        "it": ["contatti", "contattaci"],
        "de": ["kontakt", "kontaktieren"],
        "zh": ["联系我们", "联系"],
        "ja": ["お問い合わせ", "連絡"],
        "ru": ["контакт", "связаться"],
        # generic tokens across languages
    }
    # flatten unique set
    CONTACT_KEYWORDS_FLAT = sorted({k for arr in CONTACT_KEYWORDS.values() for k in arr}, key=len, reverse=True)

    # Negative keywords to reject false positives
    NEGATIVE_KEYWORDS = [
        "login", "signin", "sign-in", "signup", "sign-up", "register", "careers", "jobs",
        "blog", "press", "news", "terms", "privacy", "faq", "help-center", "cookie", "subscribe",
        "newsletter"
    ]

    COMMON_PATHS = [
        "/contact", "/contact-us", "/contactus", "/get-in-touch", "/support", "/help", "/about/contact",
        "/about-us/contact", "/kontakt", "/contato", "/contatto", "/contato", "/wp-contact", "/contact.html"

            # "contact", "contact/", "contact-us", "contact-us/", "contact.html", "contact-us.html",
            # "connect", "sales", "quotes", "about/contact-us", "contacts.php", "contact.cfm", "contactus", "contactus/", "get-in-touch",
            # "reach-us", "support", "help", "contact-form", "contact-us.php",
            # "contact-us.aspx", "contact-us.asp", "contact-us.cfm", "contactus.html",
            # "contactus.php", "contactus.aspx", "contactus.asp", "contactus.cfm",
            # "getintouch", "contactusnow", "request-quote", "get-a-quote",
            # "request-demo", "schedule-demo", "contact-sales", "support-request",
            # "customer-service", "help-center", "contact-page", "contact-us-form",
            # "write-to-us", "message-us", "collaborate", "partnership", "business-inquiry",
            # "contacto", "kontakt", "reach", "connect", "talk-to-us", "inquiry",
            # "customer-support", "helpdesk", "feedback", "request-info", "get-started"
    ]

    # scoring weights (configurable)
    SCORES = {
        "text_keyword": 5,
        "href_keyword": 5,
        "in_nav": 4,
        "in_footer": 4,
        "visible": 3,
        "position_edge": 2,     # near top or bottom
        "language_match": 3,
        "mailto": 6,            # mailto attracts high score if found alone
        "path_probe_success": 7
    }

    HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; ContactFinder/1.0)"}

    def __init__(self, timeout=10, render_js=False, verbose=False, probe_timeout=5):
        """
        :param timeout: requests timeout for fetching pages
        :param render_js: if True, attempt to render JS using Playwright (if installed)
        :param verbose: verbose logging
        :param probe_timeout: timeout for probing common paths and HEAD requests
        """
        self.timeout = timeout
        self.render_js = render_js and PLAYWRIGHT_AVAILABLE
        self.verbose = verbose
        self.probe_timeout = probe_timeout

    # ----------------- Public method -----------------
    def find(self, url):
        """
        Executes the PHES algorithm and returns:
        - contact_url
        - final confidence
        - reason
        - per-algorithm step confidence telemetry
        """

        steps = self._new_steps()
        url = self._normalize_url(url)

        # ==================================================
        # 1️⃣ URL HEURISTIC
        # ==================================================
        steps["url_heuristic"]["used"] = True

        if self._contains_contact_keyword(url):
            steps["url_heuristic"]["success"] = True
            steps["url_heuristic"]["confidence"] = 95
            steps["url_heuristic"]["detail"] = "contact keyword in input URL"

            return url

        # ==================================================
        # 2️⃣ STATIC DOM SCORING
        # ==================================================
        html = self._fetch_html(url)
        soup = None
        candidates = []

        steps["dom_scoring"]["used"] = True

        if html:
            soup = BeautifulSoup(html, "lxml")
            candidates = self._scan_and_score(soup, base_url=url)

            if candidates:
                best = max(candidates, key=lambda c: c["score"])
                max_score = self._max_possible_score()
                confidence = min(100.0, (best["score"] / max_score) * 100)

                steps["dom_scoring"]["success"] = True
                steps["dom_scoring"]["confidence"] = confidence
                steps["dom_scoring"]["detail"] = "highest scored anchor from DOM"

                return best["url"]

        # ==================================================
        # 3️⃣ MAILTO FALLBACK
        # ==================================================
        steps["mailto_fallback"]["used"] = True

        if soup:
            mailto = self._find_mailto(soup)
            if mailto:
                steps["mailto_fallback"]["success"] = True
                steps["mailto_fallback"]["confidence"] = 60
                steps["mailto_fallback"]["detail"] = "mailto link present in DOM"

                return url

        # ==================================================
        # 4️⃣ PATH PROBING
        # ==================================================
        steps["path_probe"]["used"] = True

        probed = self._probe_common_paths(url)
        if probed:
            steps["path_probe"]["success"] = True
            steps["path_probe"]["confidence"] = 75
            steps["path_probe"]["detail"] = "common contact path accessible"

            return probed

        # ==================================================
        # 5️⃣ SPA / JS RENDERING (OPTIONAL)
        # ==================================================
        steps["js_render"]["used"] = True

        if self.render_js:
            rendered = self._render_page(url)
            if rendered:
                soup_js = BeautifulSoup(rendered, "lxml")
                js_candidates = self._scan_and_score(soup_js, base_url=url)

                if js_candidates:
                    best = max(js_candidates, key=lambda c: c["score"])
                    max_score = self._max_possible_score()
                    confidence = min(100.0, (best["score"] / max_score) * 100)

                    steps["js_render"]["success"] = True
                    steps["js_render"]["confidence"] = confidence
                    steps["js_render"]["detail"] = "JS-rendered DOM candidate"

                    return best["url"]

                mailto_js = self._find_mailto(soup_js)
                if mailto_js:
                    steps["js_render"]["success"] = True
                    steps["js_render"]["confidence"] = 60
                    steps["js_render"]["detail"] = "mailto in rendered DOM"

                    return url

        # ==================================================
        # ❌ FINAL FALLBACK
        # ==================================================
        return url


    # ----------------- Internal helpers -----------------
    def _wrap_result(self, contact_url, confidence, reason, candidates=None):
        return {
            "contact_url": contact_url,
            "confidence": float(confidence),
            "reason": reason,
            "candidates": candidates or []
        }

    def _normalize_url(self, url):
        url = url.strip()
        parsed = urlparse(url)
        if not parsed.scheme:
            url = "https://" + url
        # remove trailing slash for normalization (we'll add when needed)
        return url.rstrip("/")

    def _contains_contact_keyword(self, url):
        low = url.lower()
        for kw in self.CONTACT_KEYWORDS_FLAT:
            if kw in low:
                # ensure it's meaningful (not part of longer unrelated token)
                return True
        return False

    def _fetch_html(self, url):
        try:
            r = requests.get(url, headers=self.HEADERS, timeout=self.timeout)
            if r.status_code == 200 and "text/html" in r.headers.get("Content-Type", ""):
                if self.verbose:
                    print(f"[fetch] GET {url} -> 200 HTML")
                return r.text
            else:
                if self.verbose:
                    print(f"[fetch] GET {url} -> status {r.status_code} content-type {r.headers.get('Content-Type')}")
        except requests.RequestException as e:
            if self.verbose:
                print("[fetch] Exception fetching HTML:", e)
        return None

    def _render_page(self, url, wait_for=1.0, timeout=20):
        """
        Render the page with Playwright (synchronous). Lazy import to avoid hard dependency.
        Returns rendered HTML or None.
        """
        if not PLAYWRIGHT_AVAILABLE:
            if self.verbose:
                print("[render] Playwright not available on this environment.")
            return None

        try:
            from playwright.sync_api import sync_playwright
        except Exception as e:
            if self.verbose:
                print("[render] Error importing Playwright:", e)
            return None

        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True)
                context = browser.new_context(user_agent=self.HEADERS.get("User-Agent"))
                page = context.new_page()
                page.set_default_timeout(timeout * 1000)
                page.goto(url, wait_until="networkidle")
                time.sleep(wait_for)  # give SPA a moment to render extra bits
                content = page.content()
                browser.close()
                return content
        except Exception as e:
            if self.verbose:
                print("[render] Playwright rendering error:", e)
            return None

    # ---------------- Link extraction + scoring ----------------
    def _scan_and_score(self, soup, base_url):
        """
        Prioritized scan: nav, footer, header -> whole page. Score each <a href>.
        Returns list of candidate dicts: { "url":..., "score":..., "evidence":[...] }
        """
        candidates = []

        # priority sections
        sections = []
        nav = soup.find("nav")
        if nav:
            sections.append(("nav", nav))
        footer = soup.find("footer")
        if footer:
            sections.append(("footer", footer))
        header = soup.find("header")
        if header:
            sections.append(("header", header))
        # whole doc last
        sections.append(("document", soup))

        # gather all anchors we've seen (avoid duplicates)
        seen = set()

        for section_name, container in sections:
            anchors = container.find_all("a", href=True)
            for a in anchors:
                href_raw = a.get("href").strip()
                if not href_raw:
                    continue
                href_joined = urljoin(base_url, href_raw.split("#")[0])
                # dedup by normalized url
                norm = self._normalize_url(href_joined)
                if norm in seen:
                    continue
                seen.add(norm)

                # skip javascript pseudo links
                if href_raw.lower().startswith("javascript:"):
                    continue

                # compute score
                score, evidence = self._score_anchor(a, section_name, base_url)
                # apply rejection rules
                if self._is_rejectable_anchor(a):
                    if self.verbose:
                        pass
                        # print("[scan] rejected anchor:", href_raw, "text:", a.get_text(strip=True))
                    continue

                # only consider anchors with some positive score (we can tune threshold)
                if score > 0:
                    candidates.append({"url": norm, "score": score, "evidence": evidence})

        # sort candidates by score descending
        candidates.sort(key=lambda c: c["score"], reverse=True)
        if self.verbose:
            pass
            # print(f"[scan] Found {len(candidates)} candidate(s).")
            # for c in candidates[:10]:
            #     print(f"  - {c['url']} (score {c['score']}) evidence: {c['evidence']}")
        return candidates

    def _score_anchor(self, a_tag: Tag, section_name: str, base_url: str):
        """
        Score a single anchor by multiple signals.
        Returns (score:int, evidence:list[str]).
        """
        score = 0
        evidence = []
        text = (a_tag.get_text(separator=" ", strip=True) or "").lower()
        href = (a_tag.get("href") or "").lower()

        # text contains contact keyword
        for kw in self.CONTACT_KEYWORDS_FLAT:
            if kw in text:
                score += self.SCORES["text_keyword"]
                evidence.append(f"text_keyword:{kw}")
                break

        # href contains contact keyword
        for kw in self.CONTACT_KEYWORDS_FLAT:
            if kw in href:
                score += self.SCORES["href_keyword"]
                evidence.append(f"href_keyword:{kw}")
                break

        # location-based signal
        if section_name == "nav":
            score += self.SCORES["in_nav"]
            evidence.append("in_nav")
        elif section_name == "footer":
            score += self.SCORES["in_footer"]
            evidence.append("in_footer")
        elif section_name == "header":
            score += 1
            evidence.append("in_header")

        # visible: best-effort - check for common hiding attributes
        if self._is_visible(a_tag):
            score += self.SCORES["visible"]
            evidence.append("visible")

        # position edge: near top or bottom of document (heuristic: presence inside header/footer or index position)
        try:
            parent = a_tag.parent
            # if parent is header/footer we've already boosted; else check approximate index among siblings
            idx = 0
            if parent:
                siblings = [c for c in parent.find_all(["a"], recursive=False)]
                if siblings:
                    idx = siblings.index(a_tag) if a_tag in siblings else 0
                    if idx <= 1 or idx >= max(0, len(siblings) - 2):
                        score += self.SCORES["position_edge"]
                        evidence.append("position_edge")
        except Exception:
            pass

        # language match (if link text contains non-ASCII contact words)
        for kw in self.CONTACT_KEYWORDS_FLAT:
            if kw in text and not re.match(r'^[\x00-\x7F]+$', kw):  # non-ascii keyword detection (rudimentary)
                score += self.SCORES["language_match"]
                evidence.append("language_match")
                break

        # ensure we give some score to mailto
        if href.startswith("mailto:"):
            score += self.SCORES["mailto"]
            evidence.append("mailto")

        return score, evidence

    def _is_visible(self, element: Tag):
        """
        Best-effort visibility: check inline style and attributes.
        Note: Without a renderer, we cannot perfectly determine visibility.
        """
        # if any ancestor has style display:none or visibility:hidden or aria-hidden=true
        cur = element
        while cur and isinstance(cur, Tag):
            style = (cur.get("style") or "").lower()
            if "display:none" in style or "visibility:hidden" in style or "opacity:0" in style:
                return False
            if cur.get("aria-hidden", "").lower() == "true":
                return False
            cur = cur.parent
        # dimensions unknown without rendering; assume visible otherwise
        return True

    def _is_rejectable_anchor(self, a_tag: Tag):
        """
        Reject anchors that clearly point to non-contact pages based on href or text.
        """
        text = (a_tag.get_text(separator=" ", strip=True) or "").lower()
        href = (a_tag.get("href") or "").lower()
        for neg in self.NEGATIVE_KEYWORDS:
            if neg in text or neg in href:
                return True
        return False

    def _find_mailto(self, soup):
        for a in soup.find_all("a", href=True):
            href = a.get("href", "").strip()
            if href.lower().startswith("mailto:"):
                return href
        return None

    def _probe_common_paths(self, base_url, extra=False):
        """
        Try HEAD/GET on common contact paths. If extra=True, try additional guessed endpoints.
        Returns first reachable URL or None.
        """
        paths = list(self.COMMON_PATHS)
        if extra:
            # broader guesses
            paths += ["/support/contact", "/help/contact", "/contact-us.html", "/customer-service/contact"]
        for path in paths:
            test_url = base_url + path
            try:
                # prefer HEAD to save bandwidth
                r = requests.head(test_url, headers=self.HEADERS, timeout=self.probe_timeout, allow_redirects=True)
                if r.status_code < 400 and "text/html" in r.headers.get("Content-Type", ""):
                    return r.url.rstrip("/")
                # some servers reject HEAD; try GET fallback
                if r.status_code >= 400:
                    rg = requests.get(test_url, headers=self.HEADERS, timeout=self.probe_timeout, allow_redirects=True)
                    if rg.status_code < 400 and "text/html" in rg.headers.get("Content-Type", ""):
                        return rg.url.rstrip("/")
            except requests.RequestException:
                continue
        return None

    def _looks_like_spa(self, soup):
        """
        Rudimentary SPA detection:
            - Many <script> tags with type="module" or large inline JS
            - Presence of router-link-like attributes
            - Page with very few anchors
        """
        if soup is None:
            return True  # absent DOM -> likely blocked or JS heavy
        scripts = soup.find_all("script")
        # count module scripts
        module_count = sum(1 for s in scripts if s.get("type") == "module")
        inline_js_len = sum(len((s.string or "")) for s in scripts if s.string)
        anchors = soup.find_all("a")
        if module_count >= 1 or inline_js_len > 2000 or len(anchors) < 5:
            if self.verbose:
                print("[spa] module_count", module_count, "inline_js_len", inline_js_len, "anchors", len(anchors))
            return True
        return False

    def _max_possible_score(self):
        # rough upper bound: sum of top weights
        s = 0
        for k in ["text_keyword", "href_keyword", "in_nav", "in_footer", "visible", "position_edge", "language_match", "mailto"]:
            s += self.SCORES.get(k, 0)
        return s
    def _new_steps(self):
        return {
            "url_heuristic": {"used": False, "success": False, "confidence": 0, "detail": ""},
            "dom_scoring": {"used": False, "success": False, "confidence": 0, "detail": ""},
            "mailto_fallback": {"used": False, "success": False, "confidence": 0, "detail": ""},
            "path_probe": {"used": False, "success": False, "confidence": 0, "detail": ""},
            "js_render": {"used": False, "success": False, "confidence": 0, "detail": ""},
        }


# # ----------------------------- Example Usage -----------------------------
# if __name__ == "__main__":
#     # quick demo: change URLs to test different sites
#     test_sites = [
#         "https://www.interactiveavenues.com/index.html",
#         "https://sbwhitecpa.com/",
#         "https://embeemedialab.com/",
#         "https://www.interactiveavenues.com/index.html",
#         "https://ninjapromo.io/",
#         "https://coalitiontechnologies.com/",
#         "https://echovme.in/",
#         "https://www.interactiveavenues.com/index.html",
#         "https://www.aumcore.com/",
#         "https://coalitiontechnologies.com/",
#         "https://www.1o8.agency/",
#         "https://www.socialbeat.in/",
#         "https://www.adglobal360.com/",
#     ]

#     finder = ContactPageFinder(render_js=False, verbose=True, timeout=10)

#     for s in test_sites:
#         print("\n=== Finding contact for:", s)
#         result = finder.find(s)
#         print("Result:", result)

































































# Notes & Explanation (short)

# The class tries the URL heuristic first (fast).

# Then it fetches the homepage, parses anchors, and scores them using the exact scoring system described. It prioritizes nav/footer/header sections.

# It rejects obvious non-contact pages using negative keywords.

# If nothing useful appears in static HTML, it probes common contact paths (HEAD then GET).

# It includes SPA detection. If render_js=True and Playwright is installed, it will attempt a JS-rendered fetch and re-run the scoring on the rendered DOM.

# Output includes confidence (simple mapping of score to percent), reason (why the result was returned), and a list of candidates with evidence to explain the decision.