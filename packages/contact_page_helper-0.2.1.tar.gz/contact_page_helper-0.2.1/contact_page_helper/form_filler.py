# form/form_filler.py
import time
import random
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from typing import Tuple, Dict, Any, List
import logging
from .field_extractor import FormField
from .value_generator import ValueGenerator  # Adjusted import path

logger = logging.getLogger(__name__)


class FormFiller:
    """Fills form fields with generated values efficiently"""
    
    def __init__(self, user_data: Dict[str, Any], delay_range: Tuple[float, float] = (0.05, 0.1)):
        self.value_generator = ValueGenerator(user_data=user_data)  # Pass user_data to ValueGenerator
        self.delay_range = delay_range
        self.filled_values = {}
        self.user_data = user_data
    
    def fill_form(self, fields: List[FormField]) -> Dict[str, Any]:
        """Fill all fields in a form efficiently"""
        filled_count = 0
        filled_details = {}
        
        # Group radio buttons by name
        radio_groups = {}
        for field in fields:
            if field.field_type == 'radio' and field.name:
                if field.name not in radio_groups:
                    radio_groups[field.name] = []
                radio_groups[field.name].append(field)
        
        for field in fields:
            try:
                # Skip if it's a radio button and we'll handle it separately
                if field.field_type == 'radio' and field.name in radio_groups:
                    continue
                
                success, value = self._fill_field(field)
                if success:
                    filled_count += 1
                    
                    # Store filled value
                    field_name = field.name or field.id or f"field_{filled_count}"
                    filled_details[field_name] = {
                        'value': value,
                        'type': field.field_type,
                        'tag': field.tag_name
                    }
                    
                    # Very short delay between fields
                    time.sleep(random.uniform(*self.delay_range))
                    
            except Exception as e:
                logger.warning(f"Error filling field {field.name or field.id}: {e}")
        
        # Handle radio button groups
        for group_name, radio_fields in radio_groups.items():
            if radio_fields:
                success = self._fill_radio_group(radio_fields)
                if success:
                    filled_count += 1
                    field_name = group_name or f"radio_group_{len(filled_details)}"
                    filled_details[field_name] = {
                        'value': True,
                        'type': 'radio',
                        'tag': 'input'
                    }
                    time.sleep(random.uniform(*self.delay_range))
        
        logger.info(f"Filled {filled_count} out of {len(fields)} fields")
        return filled_details
    
    def _fill_field(self, field: FormField) -> Tuple[bool, Any]:
        """Fill a single field efficiently"""
        try:
            # Generate value using ValueGenerator (which uses user data when available)
            value = self.value_generator.generate(field)
            
            # Fill based on tag type
            if field.tag_name == 'input':
                success = self._fill_input(field.element, field.field_type, value)
            elif field.tag_name == 'textarea':
                success = self._fill_textarea(field.element, value)
            elif field.tag_name == 'select':
                success = self._fill_select(field, value)
            else:
                logger.warning(f"Unsupported tag type: {field.tag_name}")
                return False, None
            
            if success:
                logger.debug(f"Filled {field.name or field.id} with: {str(value)[:50]}...")
                return True, value
            
            return False, None
            
        except Exception as e:
            logger.error(f"Error filling field {field.name or field.id}: {e}")
            return False, None
    
    def _fill_input(self, element: WebElement, input_type: str, value: Any) -> bool:
        """Fill input field efficiently"""
        try:
            # Skip certain input types
            if input_type in ['hidden', 'submit', 'button', 'reset', 'file']:
                return False
            
            # Clear field first
            self._clear_field(element)
            
            # Handle special input types
            if input_type == 'checkbox':
                if bool(value) != element.is_selected():
                    element.click()
                return True
            
            elif input_type == 'radio':
                # Radio buttons are handled separately in _fill_radio_group
                return False
            
            elif input_type in ['date', 'datetime-local', 'month', 'week', 'time']:
                # Set value directly for date/time inputs
                element.send_keys(str(value))
                return True
            
            else:
                # Set value directly for text inputs
                self._set_value_directly(element, str(value))
                return True
                
        except Exception as e:
            logger.error(f"Error filling input: {e}")
            return False
    
    def _fill_textarea(self, element: WebElement, value: str) -> bool:
        """Fill textarea field efficiently"""
        try:
            self._clear_field(element)
            self._set_value_directly(element, str(value))
            return True
        except Exception as e:
            logger.error(f"Error filling textarea: {e}")
            return False
    
    def _fill_select(self, field: FormField, value: Any) -> bool:
        """Fill select/dropdown field efficiently - SIMPLIFIED VERSION"""
        try:
            element = field.element
            
            # Create Select object
            select = Select(element)
            
            # Get all options
            options = select.options
            if not options:
                logger.warning(f"No options in select: {field.name or field.id}")
                return False
            
            # Convert value to string for comparison
            value_str = str(value)
            
            # Strategy 1: Try to select by value attribute
            try:
                select.select_by_value(value_str)
                logger.debug(f"Selected by value: {value_str}")
                return True
            except Exception as e:
                logger.debug(f"Failed to select by value {value_str}: {e}")
            
            # Strategy 2: Try to select by visible text (exact match)
            try:
                select.select_by_visible_text(value_str)
                logger.debug(f"Selected by exact text: {value_str}")
                return True
            except Exception as e:
                logger.debug(f"Failed to select by exact text {value_str}: {e}")
            
            # Strategy 3: Try to select by partial text match (case-insensitive)
            for option in options:
                if option.is_enabled() and option.text and value_str.lower() in option.text.lower():
                    try:
                        select.select_by_visible_text(option.text)
                        logger.debug(f"Selected by partial text: {option.text}")
                        return True
                    except:
                        continue
            
            # Strategy 4: If we have field.options from extraction, try to match with those
            if field.options:
                for option_text in field.options:
                    if option_text and value_str.lower() in option_text.lower():
                        try:
                            select.select_by_visible_text(option_text)
                            logger.debug(f"Selected from extracted options: {option_text}")
                            return True
                        except:
                            continue
            
            # Strategy 5: Select first non-empty, enabled option (skip placeholders)
            for option in options:
                if option.is_enabled() and option.text.strip() and option.text.strip().lower() not in ['choose one', 'select', 'please select', '']:
                    try:
                        select.select_by_visible_text(option.text)
                        logger.debug(f"Selected first non-empty option: {option.text}")
                        return True
                    except:
                        continue
            
            # Strategy 6: Select first option as last resort
            if options:
                try:
                    select.select_by_index(0)
                    logger.debug("Selected first option as last resort")
                    return True
                except Exception as e:
                    logger.debug(f"Failed to select first option: {e}")
            
            return False
            
        except Exception as e:
            logger.error(f"Error filling select {field.name or field.id}: {e}")
            return False
    
    def _fill_radio_group(self, radio_fields: List[FormField]) -> bool:
        """Handle radio button group selection efficiently"""
        try:
            # Filter to enabled and visible radio buttons
            enabled_radios = []
            for field in radio_fields:
                try:
                    if field.element.is_enabled() and field.element.is_displayed():
                        enabled_radios.append(field)
                except:
                    continue
            
            if not enabled_radios:
                return False
            
            # Select a random enabled radio button
            selected_field = random.choice(enabled_radios)
            selected_field.element.click()
            
            logger.debug(f"Selected radio button: {selected_field.name or selected_field.id}")
            return True
            
        except Exception as e:
            logger.error(f"Error filling radio group: {e}")
            return False
    
    def _clear_field(self, element: WebElement):
        """Clear a field efficiently"""
        try:
            # Try standard clear first
            element.clear()
            
            # Quick JavaScript fallback if field still has value
            if element.get_attribute('value'):
                driver = element.parent
                js = "arguments[0].value = '';"
                driver.execute_script(js, element)
                
        except Exception as e:
            logger.debug(f"Error clearing field: {e}")
    
    def _set_value_directly(self, element: WebElement, value: str):
        """Set value directly without typing simulation"""
        try:
            # Method 1: Direct send_keys
            element.send_keys(value)
            
        except Exception as e:
            logger.debug(f"Direct send_keys failed, trying JavaScript: {e}")
            try:
                # Method 2: JavaScript
                driver = element.parent
                js = """
                var element = arguments[0];
                var value = arguments[1];
                element.value = value;
                element.dispatchEvent(new Event('input', { bubbles: true }));
                element.dispatchEvent(new Event('change', { bubbles: true }));
                """
                driver.execute_script(js, element, value)
                
            except Exception as e2:
                logger.error(f"All value setting methods failed: {e2}")