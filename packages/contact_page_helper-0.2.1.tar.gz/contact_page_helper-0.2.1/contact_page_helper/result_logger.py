# results/result_logger.py
import json
from pathlib import Path
from typing import Dict, Any, List
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

class ResultLogger:
    """Logs submission results"""
    
    def __init__(self, storage_config):
        self.storage = storage_config
        self._ensure_directories()
    
    def _ensure_directories(self):
        """Ensure all required directories exist"""
        self.storage.screenshot_dir.mkdir(parents=True, exist_ok=True)
        self.storage.log_dir.mkdir(parents=True, exist_ok=True)
    
    def log_submission(self, result: Dict[str, Any]):
        """Log a submission result"""
        # Add timestamp if not present
        if 'timestamp' not in result:
            result['timestamp'] = datetime.now().isoformat()
        
        # Determine which file to save to
        if result.get('success'):
            self._append_to_file(self.storage.passed_file, result)
        else:
            self._append_to_file(self.storage.failed_file, result)
    
    def _append_to_file(self, filepath: Path, result: Dict[str, Any]):
        """Append result to JSON file"""
        try:
            # Load existing data
            if filepath.exists():
                with open(filepath, 'r', encoding='utf-8') as f:
                    data = json.load(f)
            else:
                data = []
            
            # Add new result
            data.append(result)
            
            # Save back
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            
            logger.debug(f"Result saved to {filepath}")
            
        except Exception as e:
            logger.error(f"Error saving result to {filepath}: {e}")
    
    def save_batch_results(self, results: List[Dict[str, Any]], filename: str = None):
        """Save batch results to file"""
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"batch_results_{timestamp}.json"
        
        filepath = self.storage.log_dir / filename
        
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(results, f, indent=2, ensure_ascii=False, default=str)
            
            logger.info(f"Batch results saved to {filepath}")
            return filepath
            
        except Exception as e:
            logger.error(f"Error saving batch results: {e}")
            return None