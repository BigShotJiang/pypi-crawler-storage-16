# detection/success_detector.py
import re
import time
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.common.by import By
from typing import Tuple, List
import logging

logger = logging.getLogger(__name__)

class SuccessDetector:
    """Detects if form submission was successful"""
    
    def __init__(self):
        self.success_indicators = self._compile_indicators()
        self.error_indicators = self._compile_error_indicators()
    
    def detect(self, driver: WebDriver, original_url: str, wait_time: int = 3) -> Tuple[bool, str]:
        """Detect submission success"""
        time.sleep(wait_time)  # Wait for page to update
        
        # Check URL change
        current_url = driver.current_url
        if current_url != original_url:
            return True, f"URL changed to: {current_url}"
        
        # Check page content
        page_text = driver.page_source.lower()
        
        # Look for success indicators
        for indicator in self.success_indicators:
            if indicator.search(page_text):
                return True, f"Found success indicator: '{indicator.pattern}'"
        
        # Check for success elements
        if self._find_success_elements(driver):
            return True, "Found success element on page"
        
        # Check for error indicators
        error_count = self._count_error_indicators(page_text)
        if error_count > 2:
            return False, f"Found {error_count} error indicators"
        
        return False, "No clear success indicators found"
    
    def _compile_indicators(self) -> List[re.Pattern]:
        """Compile success indicator patterns"""
        indicators = [
            r'thank\s*you',
            r'thank\s*u',
            r'thanks',
            r'success',
            r'successful',
            r'form\s*submitted',
            r'message\s*sent',
            r'received\s*your\s*message',
            r'we\'ll\s*contact\s*you',
            r'we\s*will\s*contact\s*you',
            r'your\s*message\s*has\s*been\s*sent',
            r'confirmation',
            r'sent\s*successfully',
            r'submission\s*successful',
            r'form\s*successfully',
            r'email\s*sent',
            r'query\s*received',
            r'inquiry\s*submitted'
        ]
        
        return [re.compile(pattern, re.IGNORECASE) for pattern in indicators]
    
    def _compile_error_indicators(self) -> List[re.Pattern]:
        """Compile error indicator patterns"""
        indicators = [
            r'error',
            r'failed',
            r'invalid',
            r'required',
            r'missing',
            r'please\s*enter',
            r'try\s*again',
            r'incorrect',
            r'problem',
            r'issue'
        ]
        
        return [re.compile(pattern, re.IGNORECASE) for pattern in indicators]
    
    def _find_success_elements(self, driver: WebDriver) -> bool:
        """Find success elements on page"""
        success_selectors = [
            ".success",
            ".success-message",
            ".alert-success",
            ".wpcf7-mail-sent-ok",
            ".thank-you",
            ".confirmation",
            "[class*='success']",
            "[class*='thank']"
        ]
        
        for selector in success_selectors:
            try:
                elements = driver.find_elements(By.CSS_SELECTOR, selector)
                for element in elements:
                    if element.is_displayed():
                        return True
            except:
                continue
        
        return False
    
    def _count_error_indicators(self, page_text: str) -> int:
        """Count error indicators in page text"""
        count = 0
        for indicator in self.error_indicators:
            if indicator.search(page_text):
                count += 1
        return count   