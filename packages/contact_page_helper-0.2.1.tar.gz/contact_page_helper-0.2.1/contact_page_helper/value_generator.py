# data/value_generator.py
import random
import string
from datetime import datetime
from typing import Any, Dict, Optional, Union
import logging
from .field_extractor import FormField
from .field_type_detector import FieldTypeDetector

logger = logging.getLogger(__name__)

# Try to import Faker for better fake data generation
try:
    from faker import Faker
    FAKE_AVAILABLE = True
except ImportError:
    FAKE_AVAILABLE = False
    logger.warning("Faker library not available. Using basic random data generation.")

class ValueGenerator:
    """Generates appropriate values for form fields using user data when available"""
    
    def __init__(self, user_data: Optional[Dict[str, Any]] = None):
        self.field_detector = FieldTypeDetector()
        self.user_data = user_data or {}
        self.default_values = self._create_default_values()
        self.common_values = self._create_common_values()
        
        # Initialize Faker if available
        if FAKE_AVAILABLE:
            self.faker = Faker()
        else:
            self.faker = None
    
    def generate(self, field: FormField) -> Any:
        """Generate an appropriate value for a field using user data if available"""
        field_type = self.field_detector.detect(field)
        
        # First, try to get value from user data
        user_value = self._get_user_value_for_field(field_type, field)
        if user_value is not None:
            logger.debug(f"Using user-provided value for '{field.name}' ({field_type}): {str(user_value)[:50]}...")
            return user_value
        
        # If no user data, try to use default values
        if field_type in self.default_values:
            value = self.default_values[field_type]
            if callable(value):
                return value(field)
            return value
        
        # Generate based on HTML input type
        return self._generate_by_input_type(field)
    
    def _get_user_value_for_field(self, field_type: str, field: FormField) -> Any:
        """Get user value for a specific field type"""
        # Map of field_type to possible user data keys
        field_to_user_key = {
            'first_name': ['firstName', 'first_name', 'first', 'fname'],
            'last_name': ['lastName', 'last_name', 'last', 'lname', 'surname'],
            'full_name': ['fullName', 'full_name', 'Full-Name', 'name', 'contact_name'],
            'email': ['email', 'e-mail', 'mail'],
            'phone': ['phone', 'telephone', 'Telephone-Number', 'mobile', 'cell'],
            'company': ['companyName', 'company', 'company-name', 'business', 'organization'],
            'job_title': ['jobTitle', 'job_title', 'job-title', 'position', 'title'],
            'website': ['website', 'url', 'site'],
            'address': ['address', 'street', 'location'],
            'city': ['city', 'town'],
            'country': ['country', 'nation'],
            'subject': ['subject', 'topic', 'title'],
            'message': ['message', 'Message', 'help', 'comment', 'description'],
            'zip': ['zip', 'postalCode', 'postcode'],
            'state': ['state', 'province', 'region'],
            'username': ['username', 'userName', 'login'],
            'password': ['password', 'pass', 'app_password', 'app_password_clean']
        }
        
        # Check for direct field_type match first
        if field_type in self.user_data and self.user_data[field_type]:
            return self.user_data[field_type]
        
        # Check for mapped user keys
        if field_type in field_to_user_key:
            for key in field_to_user_key[field_type]:
                if key in self.user_data and self.user_data[key]:
                    return self.user_data[key]
        
        # Special case: full_name from first_name + last_name
        if field_type == 'full_name' and 'firstName' in self.user_data and 'lastName' in self.user_data:
            return f"{self.user_data['firstName']} {self.user_data['lastName']}"
        
        return None
    
    def _create_default_values(self) -> Dict[str, Any]:
        """Create default values for common field types"""
        default_values = {
            'first_name': self._generate_first_name,
            'last_name': self._generate_last_name,
            'full_name': self._generate_full_name,
            'email': self._generate_email,
            'phone': self._generate_phone,
            'company': self._generate_company,
            'job_title': self._generate_job_title,
            'website': self._generate_website,
            'address': self._generate_address,
            'city': self._generate_city,
            'country': self._generate_country,
            'subject': 'Business Partnership Inquiry',
            'message': self._generate_message,
            'zip': self._generate_zip,
            'state': self._generate_state,
            'username': self._generate_username,
            'password': self._generate_password,
        }
        return default_values
    
    def _create_common_values(self) -> Dict[str, list]:
        """Create common values for various fields"""
        return {
            'cities': ['New York', 'London', 'Tokyo', 'Sydney', 'Berlin'],
            'countries': ['United States', 'Canada', 'UK', 'Australia', 'Germany'],
            'states': ['CA', 'NY', 'TX', 'FL', 'IL'],
            'domains': ['gmail.com', 'yahoo.com', 'outlook.com', 'icloud.com'],
            'companies': ['Tech Solutions Inc.', 'Global Innovations', 'Digital Ventures', 
                         'Creative Solutions', 'Business Partners LLC'],
            'job_titles': ['Business Development Manager', 'Sales Director', 'Marketing Manager',
                          'Project Coordinator', 'Account Executive'],
        }
    
    # Generation methods using Faker when available, fallback to basic generation
    def _generate_first_name(self, field: Optional[FormField] = None) -> str:
        if self.faker:
            return self.faker.first_name()
        return random.choice(['John', 'Jane', 'Robert', 'Emily', 'Michael', 'Sarah', 'David', 'Lisa'])
    
    def _generate_last_name(self, field: Optional[FormField] = None) -> str:
        if self.faker:
            return self.faker.last_name()
        return random.choice(['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Miller', 'Davis', 'Wilson'])
    
    def _generate_full_name(self, field: Optional[FormField] = None) -> str:
        return f"{self._generate_first_name()} {self._generate_last_name()}"
    
    def _generate_email(self, field: Optional[FormField] = None) -> str:
        if self.faker:
            return self.faker.email()
        
        first = self._generate_first_name().lower()
        last = self._generate_last_name().lower()
        domain = random.choice(self.common_values['domains'])
        random_num = random.randint(100, 999)
        return f"{first}.{last}{random_num}@{domain}"
    
    def _generate_phone(self, field: Optional[FormField] = None) -> str:
        """Generate phone number (11 digits starting with 0)"""
        # Generate exactly 11 digits, starting with 0
        area_code = random.choice(['080', '070', '081', '090', '091'])
        remaining = ''.join([str(random.randint(0, 9)) for _ in range(8)])
        return f"{area_code}{remaining}"
    
    def _generate_password(self, field: Optional[FormField] = None) -> str:
        """Generate password"""
        length = 12
        chars = string.ascii_letters + string.digits + '!@#$%^&*'
        return ''.join(random.choice(chars) for _ in range(length))
    
    def _generate_message(self, field: Optional[FormField] = None) -> str:
        """Generate message text"""
        messages = [
            "Hello, I'm interested in learning more about your services. Please contact me with additional information.",
            "Could you please send me more details about your products and pricing? Thank you!",
            "I would like to request a quote for your services. Please let me know what information you need from me.",
            "I'm reaching out to explore potential collaboration opportunities with your company.",
            "Please provide information about your services and pricing structure. Looking forward to your response.",
        ]
        return random.choice(messages)
    
    def _generate_company(self, field: Optional[FormField] = None) -> str:
        if self.faker:
            return self.faker.company()
        return random.choice(self.common_values['companies'])
    
    def _generate_job_title(self, field: Optional[FormField] = None) -> str:
        if self.faker:
            return self.faker.job()
        return random.choice(self.common_values['job_titles'])
    
    def _generate_website(self, field: Optional[FormField] = None) -> str:
        if self.faker:
            return self.faker.url()
        company = self._generate_company().lower().replace(' ', '').replace('.', '').replace(',', '')
        return f"https://www.{company}.com"
    
    def _generate_address(self, field: Optional[FormField] = None) -> str:
        if self.faker:
            return self.faker.address().replace('\n', ', ')
        return f"{random.randint(100, 999)} {random.choice(['Main', 'Broadway', 'Park', 'Market'])} Street"
    
    def _generate_city(self, field: Optional[FormField] = None) -> str:
        if self.faker:
            return self.faker.city()
        return random.choice(self.common_values['cities'])
    
    def _generate_country(self, field: Optional[FormField] = None) -> str:
        if self.faker:
            return self.faker.country()
        return random.choice(self.common_values['countries'])
    
    def _generate_zip(self, field: Optional[FormField] = None) -> str:
        if self.faker:
            return self.faker.postcode()
        return f"{random.randint(10000, 99999)}"
    
    def _generate_state(self, field: Optional[FormField] = None) -> str:
        if self.faker:
            return self.faker.state_abbr()
        return random.choice(self.common_values['states'])
    
    def _generate_username(self, field: Optional[FormField] = None) -> str:
        first = self._generate_first_name().lower()
        last = self._generate_last_name().lower()
        return f"{first}.{last}{random.randint(1, 99)}"
    
    def _generate_by_input_type(self, field: FormField) -> Any:
        """Generate value based on HTML input type"""
        input_type = field.field_type
        
        # First check if user provided value for this field by name/id
        if field.name and field.name in self.user_data:
            return self.user_data[field.name]
        if field.id and field.id in self.user_data:
            return self.user_data[field.id]
        
        generators = {
            'email': self._generate_email,
            'tel': self._generate_phone,
            'url': self._generate_website,
            'number': lambda f: str(random.randint(1, 100)),
            'date': lambda f: datetime.now().strftime('%Y-%m-%d'),
            'time': lambda f: datetime.now().strftime('%H:%M'),
            'datetime-local': lambda f: datetime.now().strftime('%Y-%m-%dT%H:%M'),
            'month': lambda f: datetime.now().strftime('%Y-%m'),
            'week': lambda f: datetime.now().strftime('%Y-W%W'),
            'color': lambda f: f'#{random.randint(0, 255):02x}{random.randint(0, 255):02x}{random.randint(0, 255):02x}',
            'range': lambda f: str(random.randint(0, 100)),
            'checkbox': lambda f: True,
            'radio': lambda f: True,
            'textarea': self._generate_message,
        }
        
        if input_type in generators:
            return generators[input_type](field)
        
        # Default for text input - try to detect type first
        detected_type = self.field_detector.detect(field)
        if detected_type != 'text' and detected_type in self.default_values:
            value = self.default_values[detected_type]
            if callable(value):
                return value(field)
            return value
        
        # If all else fails, generate generic text
        if self.faker:
            return self.faker.text(max_nb_chars=50)
        return f"Sample value for {field.name or 'field'}"