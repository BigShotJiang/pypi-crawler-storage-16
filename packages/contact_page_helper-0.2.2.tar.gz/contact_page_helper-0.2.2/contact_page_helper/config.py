# config.py
from dataclasses import dataclass
from typing import Optional, Tuple, List, Dict, Any
from pathlib import Path

    
@dataclass
class SubmissionConfig:
    """Form submission configuration"""
    delay_between_requests: int = 3
    delay_between_fields: Tuple[float, float] = (0.1, 0.3)
    max_workers: int = 3
    browser_pool_size: int = 3
    success_detection_timeout: int = 3
    
@dataclass
class StorageConfig:
    """Storage configuration"""
    screenshot_dir: Path = Path("screenshots")
    log_dir: Path = Path("submission_logs")
    passed_file: Path = Path("submission_logs/passed.json")
    failed_file: Path = Path("submission_logs/failed.json")
    results_file: Path = Path("submission_logs/results.json")
    
@dataclass
class FieldDetectionConfig:
    """Field detection configuration"""
    use_form_data_handler: bool = True
    fallback_enabled: bool = True
    
@dataclass
class AppConfig:
    """Main application configuration"""
    submission: SubmissionConfig
    storage: StorageConfig
    field_detection: FieldDetectionConfig
    
    @classmethod
    def default(cls):
        """Create default configuration"""
        return cls(
            submission=SubmissionConfig(),
            storage=StorageConfig(),
            field_detection=FieldDetectionConfig()
        )