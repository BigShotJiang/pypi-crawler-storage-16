# form/field_extractor.py
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.ui import Select
from typing import List, Dict, Any
import logging
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger(__name__)

@dataclass
class FormField:
    """Represents a form field with all its properties"""
    element: WebElement
    tag_name: str
    field_type: str
    name: str
    id: str
    placeholder: str
    label: str
    value: str
    required: bool
    options: List[str]
    attributes: Dict[str, str]
    select_element: Any = None

class FieldExtractor:
    """Extracts all fields from a form"""
    
    def __init__(self):
        self.field_selectors = [
            "input:not([type='hidden']):not([type='submit']):not([type='button']):not([type='reset'])",
            "textarea",
            "select"
        ]
    
    def extract_fields(self, form: WebElement) -> List[FormField]:
        """Extract all fields from a form"""
        fields = []
        
        for selector in self.field_selectors:
            try:
                elements = form.find_elements(By.CSS_SELECTOR, selector)
                for element in elements:
                    if element.is_displayed() and element.is_enabled():
                        field = self._extract_field_info(element)
                        if field:
                            fields.append(field)
            except Exception as e:
                logger.warning(f"Error extracting fields with selector {selector}: {e}")
        
        # Also extract radio buttons
        try:
            radio_elements = form.find_elements(By.CSS_SELECTOR, "input[type='radio']")
            for element in radio_elements:
                if element.is_displayed() and element.is_enabled():
                    field = self._extract_field_info(element)
                    if field:
                        fields.append(field)
        except Exception as e:
            logger.warning(f"Error extracting radio buttons: {e}")
        
        logger.info(f"Extracted {len(fields)} form fields")
        return fields
    
    def _extract_field_info(self, element: WebElement) -> Optional[FormField]:
        """Extract information from a form element"""
        try:
            tag_name = element.tag_name.lower()
            field_type = element.get_attribute('type') or tag_name
            
            # Get basic attributes
            name = element.get_attribute('name') or ''
            field_id = element.get_attribute('id') or ''
            placeholder = element.get_attribute('placeholder') or ''
            value = element.get_attribute('value') or ''
            required = element.get_attribute('required') is not None
            
            # Get label text
            label_text = self._get_label_text(element, field_id, name)
            
            # Get options for select elements
            options = []
            select_element = None
            
            if tag_name == 'select':
                try:
                    select_element = Select(element)
                    options = [
                        option.text.strip()
                        for option in select_element.options
                        if option.text.strip()
                    ]
                except:
                    pass
            
            # Get all attributes
            attributes = {}
            try:
                outer_html = element.get_attribute('outerHTML')
                # Simple attribute parsing
                import re
                attr_pattern = r'(\w+)="([^"]*)"'
                attributes = dict(re.findall(attr_pattern, outer_html))
            except:
                pass
            
            return FormField(
                element=element,
                tag_name=tag_name,
                field_type=field_type,
                name=name,
                id=field_id,
                placeholder=placeholder,
                label=label_text,
                value=value,
                required=required,
                options=options,
                attributes=attributes,
                select_element=select_element
            )
            
        except Exception as e:
            logger.warning(f"Error extracting field info: {e}")
            return None
    
    def _get_label_text(self, element: WebElement, element_id: str, element_name: str) -> str:
        """Get label text associated with a form element"""
        try:
            # Try by ID
            if element_id:
                try:
                    label = element.find_element(By.XPATH, f"//label[@for='{element_id}']")
                    if label:
                        return label.text.strip()
                except:
                    pass
            
            # Try by name
            if element_name:
                try:
                    label = element.find_element(By.XPATH, f"//label[@for='{element_name}']")
                    if label:
                        return label.text.strip()
                except:
                    pass
            
            # Try parent label
            try:
                parent = element.find_element(By.XPATH, "..")
                if parent.tag_name == 'label':
                    return parent.text.strip()
            except:
                pass
            
            # Try preceding label
            try:
                label = element.find_element(By.XPATH, "preceding-sibling::label[1]")
                if label:
                    return label.text.strip()
            except:
                pass
            
        except Exception as e:
            logger.debug(f"Error getting label text: {e}")
        
        return ""