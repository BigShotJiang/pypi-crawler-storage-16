# form/form_detector.py
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement
from typing import Optional
import logging
import time

logger = logging.getLogger(__name__)

class FormDetector:
    """Detects forms on a web page using multiple strategies"""

    def __init__(self):
        self.strategies = [
            self._by_id,
            self._by_class,
            self._by_action,
            self._by_field_presence,
            self._by_tag,
        ]

    # -----------------------------------------------------

    def find_form(self, driver: WebDriver) -> Optional[WebElement]:
        logger.info("Searching for contact form...")

        # ✅ CRITICAL: ensure lazy-loaded forms are rendered
        self._scroll_page(driver)

        for strategy in self.strategies:
            form = strategy(driver)
            if form:
                logger.info(f"Form found using strategy: {strategy.__name__}")
                return form

        logger.warning("No form found on page")
        return None

    # -----------------------------------------------------

    def _scroll_page(self, driver: WebDriver):
        """Scroll page to trigger lazy-loaded forms"""
        try:
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(1.2)
            driver.execute_script("window.scrollTo(0, 0);")
            time.sleep(0.5)
        except Exception as e:
            logger.debug(f"Scroll failed: {e}")

    # -----------------------------------------------------

    def _by_id(self, driver: WebDriver) -> Optional[WebElement]:
        identifiers = [
            'contact-form', 'contactForm', 'contact_form',
            'contact', 'feedback', 'enquiry', 'inquiry',
            'message-form', 'support-form', 'quote-form'
        ]

        for identifier in identifiers:
            try:
                el = driver.find_element(By.ID, identifier)
                if self._is_valid_form(el):
                    return el
            except:
                continue
        return None

    def _by_class(self, driver: WebDriver) -> Optional[WebElement]:
        classes = [
            'contact-form', 'contact_form', 'wpcf7-form',
            'gravity-form', 'ninja-form', 'formidable-form'
        ]

        for cls in classes:
            try:
                for el in driver.find_elements(By.CLASS_NAME, cls):
                    if self._is_valid_form(el):
                        return el
            except:
                continue
        return None

    def _by_action(self, driver: WebDriver) -> Optional[WebElement]:
        for keyword in ["contact", "mail", "send", "submit"]:
            try:
                forms = driver.find_elements(
                    By.CSS_SELECTOR, f'form[action*="{keyword}"]'
                )
                for f in forms:
                    if self._is_valid_form(f):
                        return f
            except:
                continue
        return None

    def _by_field_presence(self, driver: WebDriver) -> Optional[WebElement]:
        try:
            forms = driver.find_elements(By.TAG_NAME, "form")
            for form in forms:
                fields = 0
                fields += len(form.find_elements(By.CSS_SELECTOR, "textarea"))
                fields += len(form.find_elements(By.CSS_SELECTOR, "input[type='email']"))
                fields += len(form.find_elements(By.CSS_SELECTOR, "input[name*='name']"))
                fields += len(form.find_elements(By.CSS_SELECTOR, "input[type='submit'],button"))

                if fields >= 3 and self._is_valid_form(form):
                    return form
        except:
            pass
        return None

    def _by_tag(self, driver: WebDriver) -> Optional[WebElement]:
        try:
            for form in driver.find_elements(By.TAG_NAME, "form"):
                if self._is_valid_form(form):
                    return form
        except:
            pass
        return None

    # -----------------------------------------------------

    def _is_valid_form(self, element: WebElement) -> bool:
        try:
            if element.tag_name.lower() != "form":
                parent = element.find_element(By.XPATH, "ancestor::form")
                return parent.is_displayed()
            return element.is_displayed()
        except:
            return False
