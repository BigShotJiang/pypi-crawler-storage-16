#!/usr/bin/env python3
"""
Main Contact Automation Workflow

Workflow:
1. Read URLs from websites.csv
2. For each URL:
   a. Open Chrome driver
   b. Use ContactPageFinder to find contact page
   c. Use ContactPageAnalyzer to categorize contact method
   d. Route to appropriate handler:
      - EmailContactHandler for email contacts
      - PageContactHandler for form contacts
      - Log failed contacts
3. Save results and statistics
"""

import csv
from dotenv import load_dotenv; load_dotenv()
import os
import time
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any
import sys

from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
# Selenium imports
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait

# Import our modules
from .contact_page_finder import ContactPageFinder
from .contact_page_analyzer import ContactPageAnalyzer

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('contact_automation.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)


class ContactAutomationManager:
    """Main manager class that orchestrates the entire workflow."""
    
    def __init__(self, data, headless: bool = False, delay_between_sites: int = 3):
        """
        Initialize the automation manager.
        
        Args:
            headless: Run browser in headless mode
            delay_between_sites: Delay between processing sites (seconds)
        """
        self.headless = headless
        self.delay_between_sites = delay_between_sites
        
        # Results tracking
        self.data = data
        self.results = []
        self.statistics = {
            'total': 0,
            'successful': 0,
            'failed': 0,
            'email_contacts': 0,
            'form_contacts': 0,
            'captcha_contacts': 0,
            'no_contacts': 0
        }
        
        # Output directories
        self.output_dir = Path("results")
        self.output_dir.mkdir(exist_ok=True)
        
        # Timestamp for this run
        self.timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    def create_driver(self):
        """Create and configure Chrome driver."""
        chrome_options = Options()
        
        
        if self.headless:
            chrome_options.add_argument("--headless")
        
        # Basic anti-detection
        chrome_options.add_argument("--disable-blink-features=AutomationControlled")
        chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
        chrome_options.add_experimental_option('useAutomationExtension', False)
        
        # Performance settings
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-gpu")
        
        # Window size
        chrome_options.add_argument("--window-size=1920,1080")
        
        # User agent
        chrome_options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
        
        # Additional options
        chrome_options.add_argument("--disable-notifications")
        chrome_options.add_argument("--disable-popup-blocking")
        
        # Create driver
        CHROMEDRIVER_PATH = os.environ["CHROMEDRIVER_PATH"]
        if CHROMEDRIVER_PATH == "null" or not CHROMEDRIVER_PATH:
            return webdriver.Chrome(service=Service(ChromeDriverManager().install()),options=chrome_options)
        return webdriver.Chrome(service=Service(CHROMEDRIVER_PATH), options=chrome_options)
    
    def read_websites_from_csv(self, csv_file="websites.csv") -> List[str]:
        """
        Read URLs from CSV file.
        
        Args:
            csv_file: Path to CSV file containing URLs
            
        Returns:
            List of website URLs
        """
        websites = []
        
        try:
            with open(csv_file, 'r', newline='', encoding='utf-8') as f:
                reader = csv.reader(f)
                for row in reader:
                    if row:  # Skip empty rows
                        url = row[0].strip()
                        if url and not url.startswith('#'):  # Skip comments
                            websites.append(url)
            
            logger.info(f"Read {len(websites)} websites from {csv_file}")
            return websites
            
        except FileNotFoundError:
            logger.error(f"CSV file not found: {csv_file}")
            print(f"\nERROR: {csv_file} not found.")
            print("Please create a websites.csv file with one URL per line.")
            sys.exit(1)
        except Exception as e:
            logger.error(f"Error reading {csv_file}: {e}")
            return []
    
    def process_single_website(self, url: str, driver = None) -> Dict[str, Any]:
        """
        Process a single website through the complete workflow.
        
        Args:
            url: Website URL to process
            driver: Existing driver instance (optional)
            
        Returns:
            Dictionary with processing results
        """
        result = {
            'url': url,
            'timestamp': datetime.now().isoformat(),
            'contact_found': False,
            'contact_type': None,
            'contact_url': None,
            'processing_stage': None,
            'success': False,
            'error': None,
            'details': {}
        }
        try:
            # ==================================================
            # STAGE 1: Find Contact Page
            # ==================================================
            logger.info(f"Stage 1 - Finding contact page for: {url}")
            result['processing_stage'] = 'finding_contact'
            
            contact_page_finder = ContactPageFinder()
            contact_url = contact_page_finder.find(url)
            print(contact_url)
            driver.get(contact_url)
            
            if driver is None or contact_url is None:
                result['error'] = "No contact page found"
                result['contact_found'] = False
                logger.warning(f"No contact page found for {url}")
                return result
            
            result['contact_found'] = True
            result['contact_url'] = contact_url
            logger.info(f"Found contact page: {contact_url}")
            
            # ==================================================
            # STAGE 2: Analyze Contact Page
            # ==================================================
            logger.info(f"Stage 2 - Analyzing contact page: {contact_url}")
            result['processing_stage'] = 'analyzing_contact'
            analysis = ContactPageAnalyzer(driver, contact_url, self.data)
            success = analysis.analyze_with_driver()
            if success:
                return True
            return False
        except Exception as e:
            return False
            
    
    def run_batch_processing(self, websites: List[str]):
        """
        Process a batch of websites.
        
        Args:
            websites: List of website URLs to process
        """
        total = len(websites)
        self.statistics['total'] = total
        
        print(f"\n{'='*60}")
        print("CONTACT AUTOMATION WORKFLOW")
        print(f"{'='*60}")
        print(f"Total websites to process: {total}")
        print(f"Headless mode: {self.headless}")
        print(f"Delay between sites: {self.delay_between_sites}s")
        print(f"{'='*60}\n")
        driver = self.create_driver()
        for i, website in enumerate(websites, 1):
            print(f"\n[{i}/{total}] Processing: {website}")
            success = self.process_single_website(website, driver)
            
            # Print result summary
            if success:
                print(f"  ✓ SUCCESS - {website}")
            else:
                print(f"  ✗ FAILED - {website}")
    
    def save_results(self):
        """Save results to files."""
        # Save detailed results
        results_file = self.output_dir / f"results_{self.timestamp}.json"
        with open(results_file, 'w', encoding='utf-8') as f:
            json.dump({
                'timestamp': self.timestamp,
                'statistics': self.statistics,
                'results': self.results
            }, f, indent=2, default=str)
        
        # Save summary CSV
        summary_file = self.output_dir / f"summary_{self.timestamp}.csv"
        with open(summary_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['URL', 'Contact Found', 'Contact Type', 'Contact URL', 'Success', 'Error'])
            
            for result in self.results:
                writer.writerow([
                    result['url'],
                    result['contact_found'],
                    result.get('contact_type', ''),
                    result.get('contact_url', ''),
                    result['success'],
                    result.get('error', '')[:200]  # Limit error length
                ])
        
        logger.info(f"Results saved to {results_file}")
        logger.info(f"Summary saved to {summary_file}")
        
        return results_file, summary_file
    
    def print_statistics(self):
        """Print processing statistics."""
        print(f"\n{'='*60}")
        print("PROCESSING STATISTICS")
        print(f"{'='*60}")
        
        total = self.statistics['total']
        successful = self.statistics['successful']
        
        print(f"Total websites processed: {total}")
        print(f"Successfully processed: {successful}")
        print(f"Failed: {self.statistics['failed']}")
        
        if total > 0:
            success_rate = (successful / total) * 100
            print(f"Success rate: {success_rate:.1f}%")
        
        print(f"\nContact Types Found:")
        print(f"  Email contacts: {self.statistics['email_contacts']}")
        print(f"  Form contacts: {self.statistics['form_contacts']}")
        print(f"  Captcha/no contact: {self.statistics['no_contacts']}")
        
        # Calculate percentages
        if successful > 0:
            print(f"\nDistribution of successful contacts:")
            if self.statistics['email_contacts'] > 0:
                email_pct = (self.statistics['email_contacts'] / successful) * 100
                print(f"  Email: {email_pct:.1f}%")
            if self.statistics['form_contacts'] > 0:
                form_pct = (self.statistics['form_contacts'] / successful) * 100
                print(f"  Form: {form_pct:.1f}%")
    
    def run(self):
        """Main run method."""
        # Read websites from CSV
        websites = self.read_websites_from_csv()
        
        if not websites:
            logger.error("No websites to process")
            return
        
        # Process websites
        self.run_batch_processing(websites)
        
        # Save results
        self.save_results()
        
        # Print statistics
        self.print_statistics()


def main():
    """Main entry point."""
    try:
        # Configuration
        headless = False  # Set to False to see browser windows
        delay_between_sites = 3  # Seconds
        test_data = {
            'fullName': 'John Doe',
            'email': 'test@example.com',
            'companyName': 'Test Company',
            'message': 'Test message'
        }
        
        # Create and run manager
        manager = ContactAutomationManager(
            data = test_data,
            headless=headless,
            delay_between_sites=delay_between_sites
        )
        
        # Run the workflow
        manager.run()
        
        print(f"\n{'='*60}")
        print("PROCESSING COMPLETE")
        print(f"{'='*60}")
        
    except KeyboardInterrupt:
        print("\n\nProcess interrupted by user.")
        sys.exit(0)
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        print(f"\nFatal error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()