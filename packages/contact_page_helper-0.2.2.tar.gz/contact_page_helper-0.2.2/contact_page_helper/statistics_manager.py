# results/statistics_manager.py
"""
Statistics Manager Module
Manages and tracks submission statistics
"""

import json
from pathlib import Path
from typing import Dict, Any, List, Optional
import logging
from datetime import datetime

logger = logging.getLogger(__name__)


class StatisticsManager:
    """Manages submission statistics"""
    
    def __init__(self, passed_file: Path, failed_file: Path):
        """
        Initialize statistics manager
        
        Args:
            passed_file: Path to passed submissions file
            failed_file: Path to failed submissions file
        """
        self.passed_file = passed_file
        self.failed_file = failed_file
        
        # Ensure directories exist
        self.passed_file.parent.mkdir(parents=True, exist_ok=True)
        self.failed_file.parent.mkdir(parents=True, exist_ok=True)
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        Get comprehensive statistics
        
        Returns:
            Dictionary with statistics
        """
        try:
            passed = self._load_results(self.passed_file)
            failed = self._load_results(self.failed_file)
            
            total = len(passed) + len(failed)
            success_rate = (len(passed) / total * 100) if total > 0 else 0
            
            # Calculate field statistics
            field_stats = self._calculate_field_statistics(passed + failed)
            
            return {
                'total_submissions': total,
                'successful': len(passed),
                'failed': len(failed),
                'success_rate': round(success_rate, 2),
                'last_success': self._get_last_result(passed),
                'last_failure': self._get_last_result(failed),
                'field_statistics': field_stats,
                'generated_at': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error getting statistics: {e}")
            return {}
    
    def _load_results(self, filepath: Path) -> List[Dict[str, Any]]:
        """Load results from file"""
        try:
            if filepath.exists():
                with open(filepath, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if isinstance(data, list):
                        return data
        except Exception as e:
            logger.warning(f"Error loading {filepath}: {e}")
        
        return []
    
    def _get_last_result(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Get last result from list"""
        if results:
            last = results[-1]
            return {
                'url': last.get('url', 'Unknown'),
                'timestamp': last.get('timestamp', 'Unknown'),
                'reason': last.get('success_reason', last.get('error', 'Unknown'))
            }
        return {}
    
    def _calculate_field_statistics(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Calculate field filling statistics"""
        field_stats = {
            'total_fields_filled': 0,
            'average_fields_per_submission': 0,
            'field_type_counts': {},
            'most_common_fields': []
        }
        
        if not results:
            return field_stats
        
        total_fields = 0
        field_type_counts = {}
        
        for result in results:
            fields_filled = result.get('filled_fields', 0)
            total_fields += fields_filled
            
            # Count field types
            details = result.get('filled_details', {})
            for field_info in details.values():
                field_type = field_info.get('type', 'unknown')
                field_type_counts[field_type] = field_type_counts.get(field_type, 0) + 1
        
        # Calculate statistics
        field_stats['total_fields_filled'] = total_fields
        field_stats['average_fields_per_submission'] = total_fields / len(results) if results else 0
        field_stats['field_type_counts'] = field_type_counts
        
        # Get most common fields
        sorted_fields = sorted(field_type_counts.items(), key=lambda x: x[1], reverse=True)
        field_stats['most_common_fields'] = sorted_fields[:5]
        
        return field_stats
    
    def print_statistics(self):
        """Print statistics to console"""
        stats = self.get_statistics()
        
        if not stats:
            print("No statistics available.")
            return
        
        print(f"\nStatistics:")
        print(f"  Total submissions: {stats['total_submissions']}")
        print(f"  Successful: {stats['successful']}")
        print(f"  Failed: {stats['failed']}")
        print(f"  Success rate: {stats['success_rate']}%")
        
        # Field statistics
        field_stats = stats.get('field_statistics', {})
        if field_stats:
            print(f"\nField Statistics:")
            print(f"  Total fields filled: {field_stats['total_fields_filled']}")
            print(f"  Average per submission: {field_stats['average_fields_per_submission']:.1f}")
            
            print(f"\nMost common field types:")
            for field_type, count in field_stats.get('most_common_fields', []):
                print(f"  {field_type}: {count}")
        
        # Recent submissions
        if stats['last_success']:
            print(f"\nLast successful submission:")
            print(f"  URL: {stats['last_success']['url'][:80]}...")
            print(f"  Time: {stats['last_success']['timestamp']}")
        
        if stats['last_failure']:
            print(f"\nLast failed submission:")
            print(f"  URL: {stats['last_failure']['url'][:80]}...")
            print(f"  Reason: {stats['last_failure']['reason'][:80]}...")
    
    def export_statistics(self, output_file: Path = None) -> Path:
        """
        Export statistics to JSON file
        
        Args:
            output_file: Output file path (optional)
            
        Returns:
            Path to exported file
        """
        if output_file is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_file = self.passed_file.parent / f"statistics_{timestamp}.json"
        
        stats = self.get_statistics()
        
        try:
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(stats, f, indent=2, ensure_ascii=False)
            
            logger.info(f"Statistics exported to {output_file}")
            return output_file
            
        except Exception as e:
            logger.error(f"Error exporting statistics: {e}")
            return None