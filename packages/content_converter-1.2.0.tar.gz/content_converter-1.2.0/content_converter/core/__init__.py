"""
Core module
----------

Content-Converterのコア機能を提供するモジュール
"""
