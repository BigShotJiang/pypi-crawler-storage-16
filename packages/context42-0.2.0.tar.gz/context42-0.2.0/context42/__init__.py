"""
MCP RAG Server - Document chunking with compression
"""

__version__ = "0.1.0"
