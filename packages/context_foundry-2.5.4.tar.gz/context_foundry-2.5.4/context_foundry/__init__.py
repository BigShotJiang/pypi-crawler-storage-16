"""
Context Foundry - Autonomous build orchestration system
"""

__version__ = "2.5.4"
