#!/usr/bin/env python3
"""
Comprehensive tests for tools/version.py
Tests version management, parsing, and error handling.
"""

import pytest
from pathlib import Path
from unittest.mock import patch

# Import module to test
from tools import version


class TestGetVersion:
    """Test get_version() function."""

    def test_get_version_returns_string(self):
        """Test that get_version returns a string."""
        result = version.get_version()
        assert isinstance(result, str)
        assert len(result) > 0

    def test_get_version_format(self):
        """Test that version follows expected format."""
        v = version.get_version()
        # Should be either "unknown" or semantic version like "2.1.0"
        if v != "unknown":
            parts = v.split(".")
            assert len(parts) >= 1  # At least major version

    @patch("tools.version.VERSION_FILE")
    def test_get_version_with_mock_file(self, mock_version_file):
        """Test get_version with mocked VERSION file."""
        mock_version_file.read_text.return_value = "  3.2.1  \n"

        result = version.get_version()

        assert result == "3.2.1"  # Should be stripped
        mock_version_file.read_text.assert_called_once()

    @patch("tools.version.VERSION_FILE")
    def test_get_version_file_not_found(self, mock_version_file):
        """Test get_version when VERSION file is missing."""
        mock_version_file.read_text.side_effect = FileNotFoundError()

        result = version.get_version()

        assert result == "unknown"

    @patch("tools.version.VERSION_FILE")
    def test_get_version_strips_whitespace(self, mock_version_file):
        """Test that get_version strips whitespace."""
        mock_version_file.read_text.return_value = "\n  2.5.7  \n\n"

        result = version.get_version()

        assert result == "2.5.7"
        assert not result.startswith(" ")
        assert not result.endswith(" ")

    @patch("tools.version.VERSION_FILE")
    def test_get_version_empty_file(self, mock_version_file):
        """Test handling of empty VERSION file."""
        mock_version_file.read_text.return_value = ""

        result = version.get_version()

        assert result == ""  # Returns empty string when stripped


class TestGetVersionInfo:
    """Test get_version_info() function."""

    @patch("tools.version.get_version")
    def test_get_version_info_structure(self, mock_get_version):
        """Test that version info has expected structure."""
        mock_get_version.return_value = "2.1.0"

        info = version.get_version_info()

        assert "version" in info
        assert "major" in info
        assert "minor" in info
        assert "patch" in info
        assert "version_string" in info
        assert "display_name" in info

    @patch("tools.version.get_version")
    def test_get_version_info_parsing(self, mock_get_version):
        """Test version info parsing."""
        mock_get_version.return_value = "3.14.159"

        info = version.get_version_info()

        assert info["version"] == "3.14.159"
        assert info["major"] == 3
        assert info["minor"] == 14
        assert info["patch"] == 159
        assert info["version_string"] == "v3.14.159"
        assert info["display_name"] == "Context Foundry v3.14.159"

    @patch("tools.version.get_version")
    def test_get_version_info_major_only(self, mock_get_version):
        """Test version info with only major version."""
        mock_get_version.return_value = "5"

        info = version.get_version_info()

        assert info["major"] == 5
        assert info["minor"] == 0  # Defaults to 0
        assert info["patch"] == 0  # Defaults to 0

    @patch("tools.version.get_version")
    def test_get_version_info_major_minor(self, mock_get_version):
        """Test version info with major.minor."""
        mock_get_version.return_value = "2.7"

        info = version.get_version_info()

        assert info["major"] == 2
        assert info["minor"] == 7
        assert info["patch"] == 0  # Defaults to 0

    @patch("tools.version.get_version")
    def test_get_version_info_unknown(self, mock_get_version):
        """Test version info when version is unknown."""
        mock_get_version.return_value = "unknown"

        # This will raise ValueError in current implementation
        # Test documents actual behavior
        with pytest.raises(ValueError):
            info = version.get_version_info()

    @patch("tools.version.get_version")
    def test_get_version_info_invalid_format(self, mock_get_version):
        """Test version info with invalid version format."""
        mock_get_version.return_value = "not-a-version"

        # This will raise ValueError in current implementation
        # Test documents actual behavior
        with pytest.raises(ValueError):
            info = version.get_version_info()

    @patch("tools.version.get_version")
    def test_get_version_info_empty_version(self, mock_get_version):
        """Test version info with empty version."""
        mock_get_version.return_value = ""

        # This will raise ValueError when trying to parse empty string as int
        # Test documents actual behavior
        with pytest.raises(ValueError):
            info = version.get_version_info()


class TestModuleConstants:
    """Test module-level constants."""

    def test_version_constant_exists(self):
        """Test that __version__ constant exists."""
        assert hasattr(version, "__version__")
        assert isinstance(version.__version__, str)

    def test_version_constant_matches_function(self):
        """Test that VERSION constant matches get_version()."""
        assert hasattr(version, "VERSION")
        # Note: Can't directly compare due to module-level initialization
        # but we can verify it's a string
        assert isinstance(version.VERSION, str)

    def test_version_info_constant_exists(self):
        """Test that VERSION_INFO constant exists."""
        assert hasattr(version, "VERSION_INFO")
        assert isinstance(version.VERSION_INFO, dict)

    def test_version_info_constant_structure(self):
        """Test VERSION_INFO has expected keys."""
        info = version.VERSION_INFO
        required_keys = [
            "version",
            "major",
            "minor",
            "patch",
            "version_string",
            "display_name",
        ]
        for key in required_keys:
            assert key in info, f"Missing key: {key}"


class TestVersionFile:
    """Test VERSION file handling."""

    def test_version_file_path_exists(self):
        """Test that VERSION_FILE path is defined."""
        assert hasattr(version, "VERSION_FILE")
        assert isinstance(version.VERSION_FILE, Path)

    def test_version_file_location(self):
        """Test VERSION file is in expected location."""
        # Should be in parent directory of tools/
        expected_parent = Path(__file__).parent.parent
        assert version.VERSION_FILE.parent == expected_parent

    def test_version_file_name(self):
        """Test VERSION file has correct name."""
        assert version.VERSION_FILE.name == "VERSION"


class TestEdgeCases:
    """Test edge cases and error conditions."""

    @patch("tools.version.get_version")
    def test_version_with_leading_v(self, mock_get_version):
        """Test handling of version with leading 'v'."""
        mock_get_version.return_value = "v2.1.0"

        # Current implementation doesn't handle 'v' prefix
        # Will raise ValueError
        with pytest.raises(ValueError):
            info = version.get_version_info()

    @patch("tools.version.get_version")
    def test_version_with_extra_parts(self, mock_get_version):
        """Test version with more than 3 parts."""
        mock_get_version.return_value = "2.1.0.beta.1"

        info = version.get_version_info()

        # Should parse first 3 parts
        assert info["major"] == 2
        assert info["minor"] == 1
        assert info["patch"] == 0

    @patch("tools.version.get_version")
    def test_version_with_non_numeric_parts(self, mock_get_version):
        """Test version with non-numeric parts."""
        mock_get_version.return_value = "2.x.0"

        # Current implementation will crash with ValueError
        # Test documents actual behavior
        with pytest.raises(ValueError):
            info = version.get_version_info()

    @patch("tools.version.VERSION_FILE")
    def test_version_file_permission_error(self, mock_version_file):
        """Test handling of permission error reading VERSION file."""
        mock_version_file.read_text.side_effect = PermissionError()

        # Should raise PermissionError (not handled like FileNotFoundError)
        with pytest.raises(PermissionError):
            version.get_version()

    @patch("tools.version.get_version")
    def test_very_long_version_string(self, mock_get_version):
        """Test handling of unusually long version string."""
        mock_get_version.return_value = "1.2.3" + ".4" * 100

        info = version.get_version_info()

        # Should still parse first 3 parts correctly
        assert info["major"] == 1
        assert info["minor"] == 2
        assert info["patch"] == 3


class TestMainExecution:
    """Test running version.py as main module."""

    @patch("tools.version.get_version_info")
    @patch("builtins.print")
    def test_main_prints_version_info(self, mock_print, mock_get_version_info):
        """Test that running as main prints version info."""
        mock_get_version_info.return_value = {
            "version": "2.1.0",
            "version_string": "v2.1.0",
            "major": 2,
            "minor": 1,
            "patch": 0,
            "display_name": "Context Foundry v2.1.0",
        }

        # Simulate running as main

        # Note: Can't easily test __main__ execution in pytest
        # This is a placeholder to document the expected behavior


class TestIntegration:
    """Integration tests with actual file system."""

    def test_actual_version_file_exists(self):
        """Test that VERSION file actually exists in the repo."""
        # This test may fail in test environment if VERSION file is missing
        # but it's useful for catching accidental deletions
        version_file = Path(__file__).parent.parent / "VERSION"

        # If file exists, should be readable
        if version_file.exists():
            content = version_file.read_text()
            assert len(content.strip()) > 0

    def test_get_version_returns_valid_format(self):
        """Test that actual get_version() returns valid format."""
        v = version.get_version()

        # Should either be "unknown" or have at least one part
        if v != "unknown":
            parts = v.split(".")
            assert len(parts) >= 1

            # If numeric, first part should be >= 0
            try:
                major = int(parts[0])
                assert major >= 0
            except ValueError:
                # Non-numeric version is also acceptable
                pass

    def test_version_info_consistency(self):
        """Test that version info is internally consistent."""
        info = version.get_version_info()

        # version_string should contain version
        if info["version"] != "unknown":
            assert info["version"] in info["version_string"]

        # display_name should contain version_string
        assert info["version_string"] in info["display_name"]

        # All numeric fields should be integers
        assert isinstance(info["major"], int)
        assert isinstance(info["minor"], int)
        assert isinstance(info["patch"], int)


class TestVersionComparison:
    """Test version comparison scenarios."""

    @patch("tools.version.get_version")
    def test_version_parts_are_integers(self, mock_get_version):
        """Test that version parts can be used for comparison."""
        mock_get_version.return_value = "2.5.1"

        info = version.get_version_info()

        # Should be able to compare versions
        assert info["major"] > 1
        assert info["minor"] >= 5
        assert info["patch"] < 10

    @patch("tools.version.get_version")
    def test_semantic_version_compatibility(self, mock_get_version):
        """Test compatibility with semantic versioning."""
        mock_get_version.return_value = "1.0.0"

        info = version.get_version_info()

        # Semantic version rules
        if info["major"] == 0:
            # 0.x.y means in development
            assert info["major"] == 0
        else:
            # 1.0.0+ means stable
            assert info["major"] >= 1
