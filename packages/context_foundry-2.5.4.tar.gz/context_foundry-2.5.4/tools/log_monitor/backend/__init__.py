"""
MCP Log Monitor Backend
Real-time log monitoring dashboard for MCP servers
"""

__version__ = "1.0.0"
