"""Lightweight knowledge base (stateful) with optional embedded Postgres.

Falls back to SQLite if embedded Postgres is unavailable.
"""


