def main():
    print("Hello from convax!")


if __name__ == "__main__":
    main()
