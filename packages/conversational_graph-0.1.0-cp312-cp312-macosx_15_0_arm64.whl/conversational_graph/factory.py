from abc import ABC
from typing import Literal, Optional, List, Callable, Dict, Any, Union,final
from pydantic import BaseModel
from ._internal.factory import ConversationGraphEngine
from ._internal.tools import PreDefinedToolEngine

class ConversationGraph(ABC):
    """
    Public interface for the Conversation Graph Workflow.
    """
    
    def __new__(cls, name: str, DataModel: BaseModel = None, off_topic_threshold: int = 5, workflow_type: Literal["STRICT", "FLUID"] = "STRICT"):
        if workflow_type == "STRICT":
            return ConversationGraphEngine(name, DataModel, off_topic_threshold, workflow_type)
        else:
            raise NotImplementedError(f"Workflow type {workflow_type} is not implemented yet.")



class PreDefinedTool(ABC):
    """
    Public interface for PreDefined Tools in the Conversation Graph Workflow.
    """
    
    def __new__(cls):
        return PreDefinedToolEngine()