"""
COOLBOOY - Multi-Provider AI Assistant
Entry point for running as a module: python -m COOLBOOY
"""

from .cli.main import main

if __name__ == "__main__":
    main()
