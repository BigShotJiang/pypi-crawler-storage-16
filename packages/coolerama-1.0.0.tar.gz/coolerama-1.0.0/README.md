
# Coolerama 🎨

Lightweight Python library for **colored and gradient terminal text** using RGB ANSI codes.

## Features

* **Static colors:** red, green, blue, yellow, cyan, magenta, white, black, gray, light_red, light_green, light_blue, orange, pink, purple
* **Gradients:** blackwhite, purplepink, greenblue, pinkred, purpleblue, water, fire, brazil, sunrise, ocean, lava, lime
* **Random colors** per character
* **Inline coloring** using `Coolerama` class



## Installation

```bash
pip install coolerama
```

*(or include the script in your project directly)*


## Quick Usage

### Static Colors

```python
import coolerama

print(red("Error"))
print(green("Success"))
print(blue("Info"))
```

### Gradients

```python
import coolerama

text = """Hello
World"""
print(purplepink(text))
print(fire(text))
```

### Random Colors

```python
import coolerama

print(random("This text is rainbow!"))
```

### Inline Coloring

```python
import coolerama

print(f"{coolerama.yellow}Warning: {coolerama.red}Failed{coolerama.reset}")
```


## Color & Gradient Reference

### Static Colors

| Color       | Function        |
| ----------- | --------------- |
| Red         | `red()`         |
| Green       | `green()`       |
| Blue        | `blue()`        |
| Yellow      | `yellow()`      |
| Cyan        | `cyan()`        |
| Magenta     | `magenta()`     |
| White       | `white()`       |
| Black       | `black()`       |
| Gray        | `gray()`        |
| Light Red   | `light_red()`   |
| Light Green | `light_green()` |
| Light Blue  | `light_blue()`  |
| Orange      | `orange()`      |
| Pink        | `pink()`        |
| Purple      | `purple()`      |

### Gradients

| Gradient     | Description                         |
| ------------ | ----------------------------------- |
| `blackwhite` | Black → White                       |
| `purplepink` | Purple → Pink                       |
| `greenblue`  | Green → Blue                        |
| `pinkred`    | Pink → Red                          |
| `purpleblue` | Purple → Blue                       |
| `water`      | Light blue/green gradient           |
| `fire`       | Red → Orange → Yellow               |
| `brazil`     | Green → Yellow (Brazil flag colors) |
| `sunrise`    | Soft orange/pink gradient           |
| `ocean`      | Blue/Teal gradient                  |
| `lava`       | Red/Orange gradient                 |
| `lime`       | Green gradient                      |
| `random`     | Random color per character          |


## Notes

* Designed for terminals supporting **24-bit RGB ANSI codes**.
* Gradients are applied **line by line** for multi-line strings.
* `random()` applies **per-character color randomness**.