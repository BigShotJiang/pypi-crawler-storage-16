from random import randint
from os import system

system("")

def _color(r, g, b, text):
    return f"\033[38;2;{r};{g};{b}m{text}\033[0m"

def _apply_gradient(text, generator):
    faded = ""
    for i, line in enumerate(text.splitlines()):
        r, g, b = generator(i)
        faded += _color(r, g, b, line) + "\n"
    return faded

def blackwhite(text):
    def gen(i):
        val = min(255, i * 20)
        return val, val, val
    return _apply_gradient(text, gen)

def purplepink(text):
    def gen(i):
        red = min(255, 40 + i * 15)
        return red, 0, 220
    return _apply_gradient(text, gen)

def greenblue(text):
    def gen(i):
        blue = min(255, 100 + i * 15)
        return 0, 255, blue
    return _apply_gradient(text, gen)

def pinkred(text):
    def gen(i):
        blue = max(0, 255 - i * 20)
        return 255, 0, blue
    return _apply_gradient(text, gen)

def purpleblue(text):
    def gen(i):
        red = max(0, 110 - i * 15)
        return red, 0, 255
    return _apply_gradient(text, gen)

def water(text):
    def gen(i):
        green = min(255, 10 + i * 15)
        return 0, green, 255
    return _apply_gradient(text, gen)

def fire(text):
    def gen(i):
        green = max(0, 250 - i * 25)
        return 255, green, 0
    return _apply_gradient(text, gen)

def brazil(text):
    def gen(i):
        red = min(200, i * 30)
        return red, 255, 0
    return _apply_gradient(text, gen)

def random(text):
    faded = ""
    for line in text.splitlines():
        for char in line:
            r, g, b = randint(0, 255), randint(0, 255), randint(0, 255)
            faded += _color(r, g, b, char)
        faded += "\n"
    return faded

def sunrise(text):
    def gen(i):
        return min(255, 255 - i * 5), min(255, 100 + i * 10), max(0, 0 + i * 5)
    return _apply_gradient(text, gen)

def ocean(text):
    def gen(i):
        return 0, min(255, i * 8), min(255, 150 + i * 10)
    return _apply_gradient(text, gen)

def lava(text):
    def gen(i):
        return 255, max(0, 100 - i * 10), 0
    return _apply_gradient(text, gen)

def lime(text):
    def gen(i):
        return min(255, i * 10), 255, min(255, i * 10)
    return _apply_gradient(text, gen)

def red(text):
    return _color(255, 0, 0, text)

def green(text):
    return _color(0, 255, 0, text)

def blue(text):
    return _color(0, 0, 255, text)

def yellow(text):
    return _color(255, 255, 0, text)

def cyan(text):
    return _color(0, 255, 255, text)

def magenta(text):
    return _color(255, 0, 255, text)

def white(text):
    return _color(255, 255, 255, text)

def black(text):
    return _color(0, 0, 0, text)

def gray(text):
    return _color(128, 128, 128, text)

def light_red(text):
    return _color(255, 102, 102, text)

def light_green(text):
    return _color(102, 255, 102, text)

def light_blue(text):
    return _color(102, 102, 255, text)

def orange(text):
    return _color(255, 165, 0, text)

def pink(text):
    return _color(255, 192, 203, text)

def purple(text):
    return _color(128, 0, 128, text)

class Coolerama:
    reset = "\033[0m"
    @property
    def red(self): return "\033[38;2;255;0;0m"
    @property
    def green(self): return "\033[38;2;0;255;0m"
    @property
    def blue(self): return "\033[38;2;0;0;255m"
    @property
    def yellow(self): return "\033[38;2;255;255;0m"
    @property
    def cyan(self): return "\033[38;2;0;255;255m"
    @property
    def magenta(self): return "\033[38;2;255;0;255m"
    @property
    def white(self): return "\033[38;2;255;255;255m"
    @property
    def black(self): return "\033[38;2;0;0;0m"
    @property
    def gray(self): return "\033[38;2;128;128;128m"
    @property
    def light_red(self): return "\033[38;2;255;102;102m"
    @property
    def light_green(self): return "\033[38;2;102;255;102m"
    @property
    def light_blue(self): return "\033[38;2;102;102;255m"
    @property
    def orange(self): return "\033[38;2;255;165;0m"
    @property
    def pink(self): return "\033[38;2;255;192;203m"
    @property
    def purple(self): return "\033[38;2;128;0;128m"
    @property
    def fire(self): return "\033[38;2;255;250;0m"
    @property
    def water(self): return "\033[38;2;0;10;255m"
    @property
    def brazil(self): return "\033[38;2;200;255;0m"
    @property
    def sunrise(self): return "\033[38;2;255;100;0m"
    @property
    def ocean(self): return "\033[38;2;0;255;255m"
    @property
    def lava(self): return "\033[38;2;255;100;0m"
    @property
    def lime(self): return "\033[38;2;100;255;100m"

coolerama = Coolerama()
