from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="coolerama",
    version="1.0.0",
    author="Monokuma",
    author_email="virtus@qjrt.xyz",
    description="Colorful text gradients and ANSI color functions for Python",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/concurrentfutures/coolerama",  
    packages=find_packages(),
    python_requires=">=3.7",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
