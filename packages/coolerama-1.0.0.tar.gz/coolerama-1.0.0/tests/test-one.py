import coolerama

print(red("Error"))
print(green("Success"))
print(blue("Info"))