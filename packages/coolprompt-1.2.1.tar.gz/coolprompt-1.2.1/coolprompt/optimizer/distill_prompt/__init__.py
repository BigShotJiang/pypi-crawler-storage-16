from coolprompt.optimizer.distill_prompt.run import distillprompt

__all__ = [
    'distillprompt'
]
