# cooptools
 package for generic tooling across projects
