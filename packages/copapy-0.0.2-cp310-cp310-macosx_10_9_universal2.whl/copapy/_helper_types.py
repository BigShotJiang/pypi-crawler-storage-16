from typing import TypeVar

TNum = TypeVar("TNum", int, float)
U = TypeVar("U", int, float)
