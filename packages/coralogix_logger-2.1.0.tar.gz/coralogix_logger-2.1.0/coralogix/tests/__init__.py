#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
Coralogix Logger test suit
Author: Coralogix Ltd.
Email: info@coralogix.com
"""
