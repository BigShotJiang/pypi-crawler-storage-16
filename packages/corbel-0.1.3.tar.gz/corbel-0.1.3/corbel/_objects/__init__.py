from __future__ import annotations

from ._property import CorbelProperty

__all__ = ("CorbelProperty",)
