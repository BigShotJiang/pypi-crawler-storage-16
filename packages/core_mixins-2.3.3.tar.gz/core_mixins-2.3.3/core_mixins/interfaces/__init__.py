# -*- coding: utf-8 -*-

"""Interface definitions for factory and task patterns."""

from .factory import IFactory
from .task import ITask, TaskException, TaskStatus


__all__ = [
    "IFactory",
    "ITask",
    "TaskException",
    "TaskStatus",
]
