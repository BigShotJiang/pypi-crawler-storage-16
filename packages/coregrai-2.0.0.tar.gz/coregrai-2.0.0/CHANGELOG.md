# Changelog

All notable changes to GRAi CLI will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2025-01-30

### Added
- Initial release of GRAi CLI
- Interactive chat command for Q&A
- Quiz command with board-style questions
- Lesson browsing and reading
- User authentication (login/logout)
- Progress tracking and statistics
- Lesson export to markdown
- Configuration management
- Rich terminal UI with syntax highlighting
- Support for multiple LLM models
- Adaptive difficulty for quizzes
- Source citation support

### Features
- 572+ pre-generated comprehensive lessons
- Multiple quiz topics and difficulties
- Session-based learning
- Offline lesson export
- Beautiful terminal interface

### Technical
- Built with Click framework
- Rich library for terminal UI
- Requests for API communication
- Config storage in ~/.grai/
- Support for Python 3.8+

## [Unreleased]

### Planned Features
- Offline mode with cached content
- Image viewing in terminal
- Study session scheduling
- Flashcard mode
- Spaced repetition system
- Performance analytics dashboard
- Integration with Anki
- Custom quiz creation
- Peer comparison features
- Study group collaboration
