"""
GRAi CLI - Command-line interface for Diagnostic Radiology AI Assistant

A powerful command-line tool for radiology residents preparing for the ACR Core Exam.
Features include AI-powered chat, practice quizzes, comprehensive lessons, and
differential diagnosis generation.
"""

__version__ = "2.0.0"
__author__ = "GRAi Team"
__email__ = "support@coregrai.com"
__description__ = "AI-powered study assistant for the ACR Core Exam and diagnostic radiology"


def __getattr__(name):
    """Lazy import for public API."""
    if name == "main":
        from .cli import main
        return main
    elif name == "cli":
        from .cli import cli
        return cli
    elif name == "GraiClient":
        from .client import GraiClient
        return GraiClient
    elif name == "Config":
        from .config import Config
        return Config
    elif name == "authenticate":
        from .auth import authenticate
        return authenticate
    elif name == "logout":
        from .auth import logout
        return logout
    elif name == "check_auth":
        from .auth import check_auth
        return check_auth
    elif name == "get_current_user":
        from .auth import get_current_user
        return get_current_user
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "main",
    "cli",
    "GraiClient",
    "Config",
    "authenticate",
    "logout",
    "check_auth",
    "get_current_user",
    "__version__",
]
