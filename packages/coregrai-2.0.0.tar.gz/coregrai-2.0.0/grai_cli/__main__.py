#!/usr/bin/env python3
"""
GRAi CLI entry point

Allows running with: python -m grai_cli
"""

from grai_cli.cli import main

if __name__ == '__main__':
    main()
