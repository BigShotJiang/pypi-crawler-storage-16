"""
Authentication handling for GRAi CLI
"""

import requests
from typing import Tuple


def authenticate(config, email: str, password: str) -> Tuple[bool, str]:
    """
    Authenticate user with email and password

    Args:
        config: Configuration object
        email: User email
        password: User password

    Returns:
        Tuple of (success, message)
    """
    server_url = config.get('server_url', 'https://coregrai.com')
    url = f"{server_url}/api/auth/login"

    try:
        response = requests.post(url, json={
            'email': email,
            'password': password
        })

        if response.status_code == 200:
            data = response.json()
            if data.get('success'):
                token = data.get('token')
                user = data.get('user', {})

                # Save credentials
                config.set('auth_token', token)
                config.set('user_email', user.get('email'))
                config.set('user_name', user.get('username'))

                return True, "Login successful"

        # Login failed
        error_data = response.json() if response.headers.get('content-type', '').startswith('application/json') else {}
        error_msg = error_data.get('error', 'Invalid credentials')
        return False, error_msg

    except requests.exceptions.ConnectionError:
        return False, "Could not connect to server"
    except Exception as e:
        return False, f"Authentication error: {str(e)}"


def logout(config) -> None:
    """
    Log out user by clearing credentials

    Args:
        config: Configuration object
    """
    config.delete('auth_token')
    config.delete('user_email')
    config.delete('user_name')


def check_auth(config) -> bool:
    """
    Check if user is authenticated

    Args:
        config: Configuration object

    Returns:
        True if authenticated, False otherwise
    """
    return config.get('auth_token') is not None


def get_current_user(config) -> dict:
    """
    Get current authenticated user info

    Args:
        config: Configuration object

    Returns:
        User info dictionary
    """
    return {
        'email': config.get('user_email'),
        'name': config.get('user_name'),
        'token': config.get('auth_token')
    }
