#!/usr/bin/env python3
"""
Main CLI entry point for GRAi
"""

import click
import os
import sys
from pathlib import Path
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Prompt, Confirm
from rich import print as rprint

from .client import GraiClient
from .config import Config
from .auth import authenticate, logout, check_auth

console = Console()


@click.group()
@click.version_option(version="2.0.0")
@click.pass_context
def cli(ctx):
    """
    GRAi - AI-powered study assistant for diagnostic radiology

    Prepare for the ACR Core Exam with AI-assisted learning,
    practice questions, and comprehensive study materials.
    """
    ctx.ensure_object(dict)
    ctx.obj['config'] = Config()
    ctx.obj['client'] = GraiClient(ctx.obj['config'])


@cli.command()
@click.option('--email', prompt='Email', help='Your email address')
@click.option('--password', prompt='Password', hide_input=True, help='Your password')
@click.pass_context
def login(ctx, email, password):
    """Authenticate with GRAi"""
    config = ctx.obj['config']

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console
    ) as progress:
        task = progress.add_task("Authenticating...", total=None)

        success, message = authenticate(config, email, password)

        if success:
            console.print("[green]✓ Login successful![/green]")
            console.print(f"\nWelcome back! You can now use all GRAi commands.")
            console.print("\nTry these commands:")
            console.print("  [cyan]grai chat 'your question'[/cyan]")
            console.print("  [cyan]grai quiz[/cyan]")
            console.print("  [cyan]grai lesson --list[/cyan]")
        else:
            console.print(f"\n[red]✗ Login failed:[/red] {message}")
            console.print("\nPlease check your credentials and try again.")
            console.print("Don't have an account? Register at https://coregrai.com")
            sys.exit(1)


@cli.command()
@click.pass_context
def logout_cmd(ctx):
    """Log out of GRAi"""
    config = ctx.obj['config']
    logout(config)
    console.print("[green]Logged out successfully[/green]")


@cli.command()
@click.argument('query', nargs=-1, required=False)
@click.option('--interactive', '-i', is_flag=True, help='Start interactive chat session')
@click.option('--model', '-m', help='Specify LLM model (deepseek/gemini/cerebras)')
@click.option('--sources', '-s', is_flag=True, help='Show source references')
@click.pass_context
def chat(ctx, query, interactive, model, sources):
    """
    Ask questions about radiology topics

    Examples:
      grai chat "What are the CT findings in pulmonary embolism?"
      grai chat -i  # Start interactive session
      grai chat --model gemini "Explain MRI sequences"
    """
    client = ctx.obj['client']

    # Check authentication
    if not check_auth(ctx.obj['config']):
        console.print("[red]Error:[/red] You are not logged in.")
        console.print("Please run [cyan]grai login[/cyan] first.")
        sys.exit(1)

    if interactive:
        # Interactive chat mode
        console.print(Panel.fit(
            "[bold cyan]GRAi Interactive Chat[/bold cyan]\n"
            "Type your questions, or 'exit' to quit",
            border_style="cyan"
        ))

        while True:
            try:
                user_input = Prompt.ask("\n[bold green]You[/bold green]")

                if user_input.lower() in ['exit', 'quit', 'q']:
                    console.print("[yellow]Goodbye![/yellow]")
                    break

                if not user_input.strip():
                    continue

                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=console
                ) as progress:
                    task = progress.add_task("Thinking...", total=None)
                    try:
                        response = client.chat(user_input, model=model, include_sources=sources)
                    except Exception as e:
                        console.print(f"[red]Error:[/red] {str(e)}")
                        if "401" in str(e) or "Unauthorized" in str(e):
                            console.print("[yellow]Your session may have expired. Please run 'grai login' again.[/yellow]")
                        continue

                # Display response
                console.print("\n[bold cyan]GRAi:[/bold cyan]")
                console.print(Markdown(response['answer']))

                if sources and response.get('sources'):
                    console.print("\n[dim]Sources:[/dim]")
                    for i, source in enumerate(response['sources'][:3], 1):
                        console.print(f"  {i}. {source.get('title', 'Unknown')}")

            except KeyboardInterrupt:
                console.print("\n[yellow]Goodbye![/yellow]")
                break
            except Exception as e:
                console.print(f"[red]Error:[/red] {str(e)}")

    elif query:
        # Single query mode
        query_text = ' '.join(query)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:
            task = progress.add_task("Thinking...", total=None)
            try:
                response = client.chat(query_text, model=model, include_sources=sources)
            except Exception as e:
                console.print(f"[red]Error:[/red] {str(e)}")
                if "401" in str(e) or "Unauthorized" in str(e):
                    console.print("[yellow]Your session may have expired. Please run 'grai login' again.[/yellow]")
                sys.exit(1)

        # Display response
        console.print(Markdown(response['answer']))

        if sources and response.get('sources'):
            console.print("\n[dim]Sources:[/dim]")
            for i, source in enumerate(response['sources'][:3], 1):
                console.print(f"  {i}. {source.get('title', 'Unknown')}")

    else:
        console.print("[yellow]Please provide a query or use --interactive mode[/yellow]")
        console.print("Example: grai chat 'What is the protocol for chest CT?'")


@cli.command()
@click.option('--topic', '-t', help='Quiz topic (e.g., chest-xray, neuro-ct)')
@click.option('--difficulty', '-d', type=click.Choice(['easy', 'medium', 'hard']), help='Question difficulty')
@click.option('--count', '-n', type=int, default=5, help='Number of questions')
@click.option('--adaptive', '-a', is_flag=True, help='Use adaptive difficulty')
@click.pass_context
def quiz(ctx, topic, difficulty, count, adaptive):
    """
    Practice with board-style questions

    Examples:
      grai quiz --topic chest-ct --count 10
      grai quiz --adaptive  # Personalized difficulty
    """
    client = ctx.obj['client']

    if not check_auth(ctx.obj['config']):
        console.print("[red]Error:[/red] You are not logged in.")
        console.print("Please run [cyan]grai login[/cyan] first.")
        sys.exit(1)

    console.print(Panel.fit(
        f"[bold cyan]GRAi Quiz Session[/bold cyan]\n"
        f"Topic: {topic or 'Random'} | Questions: {count}",
        border_style="cyan"
    ))

    # Generate quiz
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console
    ) as progress:
        task = progress.add_task("Generating questions...", total=None)
        questions = client.generate_quiz(topic=topic, difficulty=difficulty, count=count, adaptive=adaptive)

    # Quiz loop
    score = 0
    for i, question in enumerate(questions, 1):
        console.print(f"\n[bold]Question {i}/{count}:[/bold]")
        console.print(question['question'])
        console.print()

        # Display options
        for j, option in enumerate(question['options'], 1):
            console.print(f"  {j}. {option}")

        # Get user answer
        while True:
            try:
                answer = Prompt.ask("\nYour answer (1-4)", choices=['1', '2', '3', '4'])
                answer_idx = int(answer) - 1
                break
            except (ValueError, IndexError):
                console.print("[red]Invalid choice. Please enter 1-4[/red]")

        # Check answer
        correct_idx = question['correct_answer']
        if answer_idx == correct_idx:
            console.print("[green]Correct![/green]")
            score += 1
        else:
            console.print(f"[red]Incorrect.[/red] The correct answer was: {correct_idx + 1}")

        # Show explanation
        if question.get('explanation'):
            console.print(f"\n[dim]{question['explanation']}[/dim]")

        if i < count:
            if not Confirm.ask("\nContinue to next question?", default=True):
                break

    # Final score
    percentage = (score / len(questions)) * 100 if questions else 0
    console.print(Panel.fit(
        f"[bold]Quiz Complete![/bold]\n"
        f"Score: {score}/{len(questions)} ({percentage:.1f}%)",
        border_style="green" if percentage >= 70 else "yellow"
    ))


@cli.command()
@click.argument('topic', required=False)
@click.option('--list', '-l', is_flag=True, help='List available lessons')
@click.option('--search', '-s', help='Search lessons by keyword')
@click.option('--category', '-c', help='Filter by category')
@click.pass_context
def lesson(ctx, topic, list, search, category):
    """
    Access comprehensive study lessons

    Examples:
      grai lesson --list
      grai lesson --search "cardiac"
      grai lesson chest-radiography-basics
    """
    client = ctx.obj['client']

    if not check_auth(ctx.obj['config']):
        console.print("[red]Error:[/red] You are not logged in.")
        console.print("Please run [cyan]grai login[/cyan] first.")
        sys.exit(1)

    if list or search or category:
        # List/search lessons
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:
            task = progress.add_task("Fetching lessons...", total=None)
            lessons = client.list_lessons(search=search, category=category)

        if not lessons:
            console.print("[yellow]No lessons found[/yellow]")
            return

        # Display as table
        table = Table(title="Available Lessons")
        table.add_column("ID", style="cyan")
        table.add_column("Title", style="white")
        table.add_column("Category", style="green")
        table.add_column("Difficulty", style="yellow")

        for lesson_item in lessons[:20]:  # Limit to 20
            table.add_row(
                lesson_item.get('id', ''),
                lesson_item.get('title', ''),
                lesson_item.get('category', ''),
                lesson_item.get('difficulty', '')
            )

        console.print(table)

        if len(lessons) > 20:
            console.print(f"\n[dim]Showing 20 of {len(lessons)} lessons. Use --search to narrow results.[/dim]")

    elif topic:
        # Display specific lesson
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:
            task = progress.add_task("Loading lesson...", total=None)
            lesson_data = client.get_lesson(topic)

        if not lesson_data:
            console.print(f"[red]Lesson '{topic}' not found[/red]")
            return

        # Display lesson
        console.print(Panel.fit(
            f"[bold cyan]{lesson_data.get('title', 'Lesson')}[/bold cyan]\n"
            f"Category: {lesson_data.get('category', 'General')} | "
            f"Difficulty: {lesson_data.get('difficulty', 'Medium')}",
            border_style="cyan"
        ))

        console.print(Markdown(lesson_data.get('content', 'No content available')))

        # Show key points
        if lesson_data.get('key_points'):
            console.print("\n[bold]Key Points:[/bold]")
            for point in lesson_data['key_points']:
                console.print(f"  - {point}")

    else:
        console.print("[yellow]Please specify a topic or use --list to see available lessons[/yellow]")
        console.print("Example: grai lesson chest-radiography-basics")


@cli.command()
@click.pass_context
def stats(ctx):
    """View your study statistics and progress"""
    client = ctx.obj['client']

    if not check_auth(ctx.obj['config']):
        console.print("[red]Error:[/red] You are not logged in.")
        console.print("Please run [cyan]grai login[/cyan] first.")
        sys.exit(1)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console
    ) as progress:
        task = progress.add_task("Loading statistics...", total=None)
        stats_data = client.get_stats()

    # Create stats display
    table = Table(title="Your Study Statistics", show_header=False)
    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="white")

    table.add_row("Questions Answered", str(stats_data.get('questions_answered', 0)))
    table.add_row("Lessons Completed", str(stats_data.get('lessons_completed', 0)))
    table.add_row("Study Streak", f"{stats_data.get('streak_days', 0)} days")
    table.add_row("Average Score", f"{stats_data.get('average_score', 0):.1f}%")
    table.add_row("Total Study Time", stats_data.get('total_time', '0h'))

    console.print(table)

    # Show weak areas if available
    if stats_data.get('weak_areas'):
        console.print("\n[bold]Areas to Focus On:[/bold]")
        for area in stats_data['weak_areas'][:5]:
            console.print(f"  - {area}")


@cli.command()
@click.option('--modality', '-m', type=click.Choice([
    'CT', 'MRI', 'XR', 'US', 'NM', 'PET', 'Fluoro', 'Mammo'
]), help='Imaging modality')
@click.option('--region', '-r', help='Body region (e.g., chest, abdomen, brain)')
@click.option('--history', '-h', help='Clinical history')
@click.pass_context
def ddx(ctx, modality, region, history):
    """
    Generate differential diagnosis from imaging findings

    Enter imaging findings and get a ranked differential diagnosis
    with supporting evidence and next steps.

    Examples:
      grai ddx --modality CT --region chest
      grai ddx -m MRI -r brain -h "headache for 2 weeks"
    """
    client = ctx.obj['client']

    if not check_auth(ctx.obj['config']):
        console.print("[red]Error:[/red] You are not logged in.")
        console.print("Please run [cyan]grai login[/cyan] first.")
        sys.exit(1)

    console.print(Panel.fit(
        "[bold cyan]Differential Diagnosis Generator[/bold cyan]\n"
        "Enter imaging findings to get a ranked differential",
        border_style="cyan"
    ))

    # Get modality if not provided
    if not modality:
        modality = Prompt.ask(
            "Modality",
            choices=['CT', 'MRI', 'XR', 'US', 'NM', 'PET', 'Fluoro', 'Mammo'],
            default='CT'
        )

    # Get body region if not provided
    if not region:
        regions = ['Head/Brain', 'Neck', 'Chest', 'Abdomen', 'Pelvis',
                   'Spine', 'Upper Extremity', 'Lower Extremity', 'Other']
        console.print("\n[bold]Select body region:[/bold]")
        for i, r in enumerate(regions, 1):
            console.print(f"  {i}. {r}")
        region_idx = Prompt.ask("Region", default="3")
        try:
            region = regions[int(region_idx) - 1]
        except (ValueError, IndexError):
            region = "Chest"

    # Get clinical history if not provided
    if not history:
        history = Prompt.ask("\nClinical history (optional, press Enter to skip)", default="")

    # Get findings
    console.print("\n[bold]Enter imaging findings[/bold] (press Enter twice when done):")
    console.print("[dim]Describe what you see on the images...[/dim]\n")

    lines = []
    empty_count = 0
    while empty_count < 1:
        try:
            line = input("  ")
            if not line:
                empty_count += 1
            else:
                empty_count = 0
                lines.append(line)
        except (KeyboardInterrupt, EOFError):
            console.print()
            break

    findings = '\n'.join(lines)

    if not findings.strip():
        console.print("[yellow]No findings entered.[/yellow]")
        return

    # Generate DDX
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console
    ) as progress:
        task = progress.add_task("Generating differential diagnosis...", total=None)
        try:
            response = client.generate_ddx(
                findings=findings,
                modality=modality,
                body_region=region,
                clinical_history=history if history else None
            )
        except Exception as e:
            console.print(f"[red]Error:[/red] {str(e)}")
            sys.exit(1)

    # Display result
    console.print(Panel.fit(
        f"[bold cyan]Differential Diagnosis[/bold cyan]\n"
        f"Modality: {modality} | Region: {region}",
        border_style="cyan"
    ))

    console.print(Markdown(response.get('differential', response.get('answer', ''))))

    # Show recommendations if available
    if response.get('recommendations'):
        console.print("\n[bold]Recommended Next Steps:[/bold]")
        for rec in response['recommendations']:
            console.print(f"  - {rec}")


@cli.command()
@click.option('--server', help='Custom server URL')
@click.option('--show', is_flag=True, help='Show current configuration')
@click.pass_context
def config(ctx, server, show):
    """Configure GRAi settings"""
    config_obj = ctx.obj['config']

    if show:
        console.print(Panel.fit(
            f"[bold]Current Configuration[/bold]\n\n"
            f"Server: {config_obj.get('server_url', 'https://coregrai.com')}\n"
            f"Logged in: {'Yes' if config_obj.get('auth_token') else 'No'}\n"
            f"Model: {config_obj.get('default_model', 'deepseek')}",
            border_style="cyan"
        ))
    elif server:
        config_obj.set('server_url', server)
        console.print(f"[green]Server URL updated to:[/green] {server}")
    else:
        console.print("[yellow]Use --show to view configuration or --server to change server URL[/yellow]")


@cli.command()
@click.argument('lesson_id')
@click.option('--output', '-o', type=click.Path(), help='Save to file')
@click.pass_context
def export(ctx, lesson_id, output):
    """Export lesson content to file"""
    client = ctx.obj['client']

    if not check_auth(ctx.obj['config']):
        console.print("[red]Error:[/red] You are not logged in.")
        console.print("Please run [cyan]grai login[/cyan] first.")
        sys.exit(1)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console
    ) as progress:
        task = progress.add_task("Exporting lesson...", total=None)
        lesson_data = client.get_lesson(lesson_id)

    if not lesson_data:
        console.print(f"[red]Lesson '{lesson_id}' not found[/red]")
        return

    # Generate output filename if not provided
    if not output:
        output = f"{lesson_id}.md"

    # Write to file
    content = f"# {lesson_data.get('title', 'Lesson')}\n\n"
    content += f"**Category:** {lesson_data.get('category', 'General')}\n\n"
    content += lesson_data.get('content', '')

    with open(output, 'w', encoding='utf-8') as f:
        f.write(content)

    console.print(f"[green]Lesson exported to:[/green] {output}")


def main():
    """Main entry point"""
    try:
        cli(obj={})
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted by user[/yellow]")
        sys.exit(0)
    except Exception as e:
        console.print(f"[red]Error:[/red] {str(e)}")
        sys.exit(1)


if __name__ == '__main__':
    main()
