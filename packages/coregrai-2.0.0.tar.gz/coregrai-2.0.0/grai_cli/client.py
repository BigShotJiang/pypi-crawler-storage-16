"""
API Client for GRAi backend
"""

import requests
from typing import Dict, List, Optional
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


class GraiClient:
    """Client for communicating with GRAi backend API"""

    def __init__(self, config):
        self.config = config
        self.base_url = config.get('server_url', 'https://coregrai.com')
        self.session = self._create_session()

    def _create_session(self):
        """Create requests session with retry logic"""
        session = requests.Session()

        # Configure retries
        retry = Retry(
            total=3,
            backoff_factor=0.3,
            status_forcelist=[500, 502, 503, 504]
        )
        adapter = HTTPAdapter(max_retries=retry)
        session.mount('http://', adapter)
        session.mount('https://', adapter)

        return session

    def _get_headers(self) -> Dict[str, str]:
        """Get request headers with auth token"""
        headers = {
            'Content-Type': 'application/json'
        }

        token = self.config.get('auth_token')
        if token:
            headers['Authorization'] = f'Bearer {token}'

        return headers

    def chat(self, query: str, model: Optional[str] = None, include_sources: bool = False) -> Dict:
        """
        Send a chat query to the AI

        Args:
            query: User question
            model: Optional model override (deepseek/gemini/cerebras)
            include_sources: Include source references

        Returns:
            Response with answer and optional sources
        """
        url = f"{self.base_url}/api/chat"
        payload = {
            'message': query,
            'include_sources': include_sources
        }

        if model:
            payload['model'] = model

        response = self.session.post(url, json=payload, headers=self._get_headers())
        response.raise_for_status()

        return response.json()

    def generate_quiz(
        self,
        topic: Optional[str] = None,
        difficulty: Optional[str] = None,
        count: int = 5,
        adaptive: bool = False
    ) -> List[Dict]:
        """
        Generate quiz questions

        Args:
            topic: Topic filter (e.g., 'chest-ct', 'neuro-mri')
            difficulty: Difficulty level (easy/medium/hard)
            count: Number of questions
            adaptive: Use adaptive difficulty based on performance

        Returns:
            List of quiz questions
        """
        url = f"{self.base_url}/api/quiz/generate"
        payload = {
            'count': count
        }

        if topic:
            payload['topic'] = topic
        if difficulty:
            payload['difficulty'] = difficulty
        if adaptive:
            payload['adaptive'] = True

        response = self.session.post(url, json=payload, headers=self._get_headers())
        response.raise_for_status()

        data = response.json()
        return data.get('questions', [])

    def list_lessons(self, search: Optional[str] = None, category: Optional[str] = None) -> List[Dict]:
        """
        List available lessons

        Args:
            search: Search keyword
            category: Category filter

        Returns:
            List of lessons
        """
        url = f"{self.base_url}/api/comprehensive-lessons/catalog"
        params = {}

        if search:
            params['search'] = search
        if category:
            params['category'] = category

        response = self.session.get(url, params=params, headers=self._get_headers())
        response.raise_for_status()

        data = response.json()
        return data.get('lessons', [])

    def get_lesson(self, lesson_id: str) -> Optional[Dict]:
        """
        Get a specific lesson

        Args:
            lesson_id: Lesson identifier

        Returns:
            Lesson data or None if not found
        """
        url = f"{self.base_url}/api/comprehensive-lessons/lesson/{lesson_id}"

        try:
            response = self.session.get(url, headers=self._get_headers())
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 404:
                return None
            raise

    def get_stats(self) -> Dict:
        """
        Get user statistics

        Returns:
            Statistics dictionary
        """
        url = f"{self.base_url}/api/progress/stats"

        response = self.session.get(url, headers=self._get_headers())
        response.raise_for_status()

        return response.json()

    def submit_quiz_answer(self, question_id: str, answer: int, correct: bool) -> None:
        """
        Submit quiz answer for tracking

        Args:
            question_id: Question identifier
            answer: User's answer index
            correct: Whether answer was correct
        """
        url = f"{self.base_url}/api/quiz/submit"
        payload = {
            'question_id': question_id,
            'answer': answer,
            'correct': correct
        }

        response = self.session.post(url, json=payload, headers=self._get_headers())
        response.raise_for_status()

    def get_recommendations(self) -> List[Dict]:
        """
        Get personalized study recommendations

        Returns:
            List of recommended topics/lessons
        """
        url = f"{self.base_url}/api/adaptive/recommendations"

        response = self.session.get(url, headers=self._get_headers())
        response.raise_for_status()

        data = response.json()
        return data.get('recommendations', [])

    def generate_ddx(
        self,
        findings: str,
        modality: Optional[str] = None,
        body_region: Optional[str] = None,
        clinical_history: Optional[str] = None
    ) -> Dict:
        """
        Generate differential diagnosis from imaging findings

        Args:
            findings: Description of imaging findings
            modality: Imaging modality (CT, MRI, XR, etc.)
            body_region: Body region being imaged
            clinical_history: Optional clinical history

        Returns:
            Differential diagnosis with ranked possibilities
        """
        url = f"{self.base_url}/api/chat"

        # Build the DDX prompt
        prompt_parts = ["Based on the following imaging study, provide a differential diagnosis:"]

        if modality:
            prompt_parts.append(f"\nModality: {modality}")
        if body_region:
            prompt_parts.append(f"Body Region: {body_region}")
        if clinical_history:
            prompt_parts.append(f"Clinical History: {clinical_history}")

        prompt_parts.append(f"\nIMAGING FINDINGS:\n{findings}")
        prompt_parts.append("""
Please provide:
1. Most likely diagnosis with supporting findings
2. Differential diagnoses ranked by likelihood
3. Key distinguishing features for each
4. Recommended next steps or additional imaging if needed

Use professional radiology terminology and format as a structured report.""")

        payload = {
            'message': '\n'.join(prompt_parts),
            'context_type': 'ddx'
        }

        response = self.session.post(url, json=payload, headers=self._get_headers(), timeout=120)
        response.raise_for_status()

        data = response.json()
        # Normalize the response format
        return {
            'differential': data.get('answer', data.get('response', '')),
            'sources': data.get('sources', []),
            'recommendations': data.get('recommendations', [])
        }
