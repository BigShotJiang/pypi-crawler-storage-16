"""
Configuration management for GRAi CLI
"""

import json
import os
from pathlib import Path
from typing import Any, Optional


class Config:
    """Manages CLI configuration and settings"""

    def __init__(self):
        self.config_dir = Path.home() / '.grai'
        self.config_file = self.config_dir / 'config.json'
        self._data = self._load_config()

    def _load_config(self) -> dict:
        """Load configuration from file"""
        if not self.config_file.exists():
            return self._get_default_config()

        try:
            with open(self.config_file, 'r') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return self._get_default_config()

    def _get_default_config(self) -> dict:
        """Get default configuration"""
        return {
            'server_url': 'https://coregrai.com',
            'default_model': 'deepseek',
            'show_sources': False,
            'color_output': True,
            'auth_token': None,
            'user_email': None
        }

    def _save_config(self) -> None:
        """Save configuration to file"""
        # Create config directory if it doesn't exist
        self.config_dir.mkdir(parents=True, exist_ok=True)

        with open(self.config_file, 'w') as f:
            json.dump(self._data, f, indent=2)

    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value"""
        return self._data.get(key, default)

    def set(self, key: str, value: Any) -> None:
        """Set configuration value"""
        self._data[key] = value
        self._save_config()

    def delete(self, key: str) -> None:
        """Delete configuration value"""
        if key in self._data:
            del self._data[key]
            self._save_config()

    def clear(self) -> None:
        """Clear all configuration"""
        self._data = self._get_default_config()
        self._save_config()
