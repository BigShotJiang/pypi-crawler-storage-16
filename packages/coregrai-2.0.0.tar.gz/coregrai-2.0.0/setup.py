#!/usr/bin/env python3
"""
Setup configuration for GRAi CLI

This file is maintained for backward compatibility with older pip versions.
The primary configuration is in pyproject.toml.
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read long description from README
this_directory = Path(__file__).parent
long_description = ""
readme_path = this_directory / "README.md"
if readme_path.exists():
    long_description = readme_path.read_text(encoding='utf-8')

setup(
    name='coregrai',
    version='2.0.0',
    author='GRAi Team',
    author_email='support@coregrai.com',
    description='AI-powered study assistant for the ACR Core Exam and diagnostic radiology',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://coregrai.com',
    packages=find_packages(),
    classifiers=[
        'Development Status :: 4 - Beta',
        'Environment :: Console',
        'Intended Audience :: Healthcare Industry',
        'Intended Audience :: Education',
        'Topic :: Education',
        'Topic :: Scientific/Engineering :: Medical Science Apps.',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Operating System :: OS Independent',
    ],
    license='MIT',
    python_requires='>=3.8',
    install_requires=[
        'click>=8.0.0',
        'requests>=2.28.0',
        'rich>=13.0.0',
    ],
    extras_require={
        'secure': ['keyring>=23.0.0'],
        'dev': [
            'pytest>=7.0.0',
            'pytest-cov>=4.0.0',
            'black>=23.0.0',
            'flake8>=6.0.0',
            'mypy>=1.0.0',
            'build>=1.0.0',
            'twine>=4.0.0',
        ],
    },
    entry_points={
        'console_scripts': [
            'grai=grai_cli.cli:main',
        ],
    },
    keywords='radiology medical education ACR exam study AI assistant differential-diagnosis',
    project_urls={
        'Homepage': 'https://coregrai.com',
        'Bug Reports': 'https://github.com/coregrai/grai-cli/issues',
        'Documentation': 'https://docs.coregrai.com',
        'Source': 'https://github.com/coregrai/grai-cli',
    },
)
