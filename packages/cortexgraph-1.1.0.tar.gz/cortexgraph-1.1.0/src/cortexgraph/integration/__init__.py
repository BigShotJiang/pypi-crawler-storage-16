"""Integration layer for external systems."""

from .cortex_memory import BasicMemoryIntegration

__all__ = ["BasicMemoryIntegration"]
