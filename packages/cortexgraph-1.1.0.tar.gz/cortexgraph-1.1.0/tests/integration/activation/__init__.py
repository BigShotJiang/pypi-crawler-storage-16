"""Integration tests for activation module."""
