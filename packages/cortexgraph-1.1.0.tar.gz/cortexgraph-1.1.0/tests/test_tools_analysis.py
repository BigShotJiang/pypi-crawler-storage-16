"""
Tests for tools related to memory analysis.

This test suite covers the following tools:
- `search_memory`
- `cluster_memories`
- `consolidate_memories`
"""
