# corva-sdk

**corva-sdk** is a framework for building
[Corva DevCenter](https://app.corva.ai/dev-center/docs)
Python apps.

## Help

See
[documentation](https://corva-ai.github.io/python-sdk/)
for more details.

## Install

Install using `pip install corva-sdk`.

## Contributing

For guidance on setting up a development environment see
[Development - Contributing](https://corva-ai.github.io/python-sdk/#_development_contributing).
