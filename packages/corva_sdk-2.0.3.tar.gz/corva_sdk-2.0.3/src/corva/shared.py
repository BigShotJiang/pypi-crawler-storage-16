from typing import Dict

SECRETS: Dict[str, str] = {}
