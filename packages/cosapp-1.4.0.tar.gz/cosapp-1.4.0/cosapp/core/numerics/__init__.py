"""
This module override some scipy routine to be able to use them with uncertainties
"""