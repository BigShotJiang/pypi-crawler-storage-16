Configuration
================================

.. jsonschema:: cosmos_rl.policy.config.COSMOS_CONFIG_SCHEMA
    :lift_title: false