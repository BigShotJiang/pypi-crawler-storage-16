vLLM
====

Cosmos-RL supports `vLLM <https://github.com/vllm-project/vllm>`_ as the backend of rollout generation.

All of the features of Cosmos-RL are mainly developed based on rollout that uses vLLM as the backend. 

We recommend using vLLM as the backend for fully utilizing the features of Cosmos-RL.


Enable vLLM
-----------

vLLM is enabled by default.