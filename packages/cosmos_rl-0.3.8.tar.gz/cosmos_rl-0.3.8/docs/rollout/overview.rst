Cosmos-RL supports `vLLM <https://github.com/vllm-project/vllm>`_ as the backend of rollout generaton.

And recently, we have added an experimental support for `TensorRT-LLM <https://github.com/NVIDIA/TensorRT-LLM>`_ as the backend of rollout generation.