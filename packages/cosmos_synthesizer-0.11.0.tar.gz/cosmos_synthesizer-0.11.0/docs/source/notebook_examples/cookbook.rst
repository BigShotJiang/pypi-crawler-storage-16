Cookbook
========

In this section we provide a series of specific examples that demonstrate how to use synthesizer to generate synthetic observations of galaxies.

.. toctree::
    :maxdepth: 2
    
    generate_active_galaxy
    generate_composite_galaxy
