Examples
========

Below is a gallery of examples, demonstrating various ways of using synthesizer.
