Particle galaxy examples
------------------------
