# Copyright 2025 Cotality
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""CLIP Output Service - Manage customer clip output data with CLIP API responses."""

from __future__ import annotations

from .....core.interfaces.database import DatabaseClient
from .....core.interfaces.database_types import ColumnDefinition, DataTypeEnum
from .....core.interfaces.table import Table
from ...typing import CLIP_COLUMNS_GROUP, COTALITY_APP_ROLE, INPUT_COLUMNS_GROUP, PRIMARY_KEY_GROUP, ClipSummaryMetrics
from .typing import CLIP_METRICS_KEYS_TO_CLIP_OUTPUT_COLUMNS, ClipOutput, Columns


class ClipOutputTable(Table):
    """CLIP Output Table extending the base Table class.

    This class provides a pre-configured Table for CLIP output data
    combining customer input with CLIP API responses. The table name is dynamic
    and provided by the customer.
    """

    def __init__(self, database_client: DatabaseClient, database_name: str, schema_name: str, table_name: str):
        """Initialize the ClipOutputTable.

        Args:
            database_client (DatabaseClient): Database client instance
            database_name (str): Name of the database
            schema_name (str): Name of the schema
            table_name (str): Dynamic table name provided by customer
        """
        super().__init__(
            database_client=database_client,
            dataclass_type=ClipOutput,
            database_name=database_name,
            schema_name=schema_name,
            table_name=table_name,
            columns=_SCHEMA.copy(),  # Copy to prevent external modification
            description="CLIP output data table combining customer input with CLIP API responses",
            app_role=COTALITY_APP_ROLE,
        )

    def aggregate_clip_metric(self, table_name: str) -> ClipSummaryMetrics:
        """Aggregate property match score from the Clip output table.
        Args:
            table_name (str): Name of the table
        Returns:
            ClipSummaryMetrics: Aggregated property match score
        """
        table_name = self.get_table_name(table_name)
        clip_summary_metric = ClipSummaryMetrics()
        for key in clip_summary_metric.to_dict().keys():
            clip_output_column_name = CLIP_METRICS_KEYS_TO_CLIP_OUTPUT_COLUMNS[key]
            sql = f"""
                SELECT {clip_output_column_name} AS score, COUNT(*) AS count
                FROM {table_name}
                GROUP BY {clip_output_column_name}
                ORDER BY score DESC
            """
            aggr_result = self._database_client.query_to_dict(sql)
            clip_summary_metric.__dict__[key] = {
                result.get("score"): result.get("count") for result in aggr_result if result.get("score") is not None
            }

        return clip_summary_metric


# ============ Private Schema Definition ============
_SCHEMA = [
    # Customer input fields
    ColumnDefinition(
        name=Columns.REFERENCE_ID.value,
        data_type=DataTypeEnum.TEXT,
        description="Unique reference identifier for the input record",
        nullable=False,
        primary_key=True,
        group=PRIMARY_KEY_GROUP,
    ),
    ColumnDefinition(
        name=Columns.STREET_ADDRESS.value,
        data_type=DataTypeEnum.TEXT,
        description="Street address of the property",
        nullable=True,
        group=INPUT_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CITY.value,
        data_type=DataTypeEnum.TEXT,
        description="City name",
        nullable=True,
        group=INPUT_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.STATE.value,
        data_type=DataTypeEnum.TEXT,
        description="State abbreviation",
        nullable=True,
        group=INPUT_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.ZIP_CODE.value,
        data_type=DataTypeEnum.TEXT,
        description="ZIP code",
        nullable=True,
        group=INPUT_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.FULL_ADDRESS.value,
        data_type=DataTypeEnum.TEXT,
        description="Complete formatted address",
        nullable=True,
        group=INPUT_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.APN.value,
        data_type=DataTypeEnum.TEXT,
        description="Assessor's Parcel Number",
        nullable=True,
        group=INPUT_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.FIPS_CODE.value,
        data_type=DataTypeEnum.TEXT,
        description="Federal Information Processing Standards code",
        nullable=True,
    ),
    ColumnDefinition(
        name=Columns.OWNER_NAME_1.value,
        data_type=DataTypeEnum.TEXT,
        description="Primary owner name",
        nullable=True,
        group=INPUT_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.OWNER_NAME_2.value,
        data_type=DataTypeEnum.TEXT,
        description="Secondary owner name",
        nullable=True,
        group=INPUT_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.LATITUDE.value,
        data_type=DataTypeEnum.FLOAT64,
        description="Geographic latitude coordinate",
        nullable=True,
        group=INPUT_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.LONGITUDE.value,
        data_type=DataTypeEnum.FLOAT64,
        description="Geographic longitude coordinate",
        nullable=True,
        group=INPUT_COLUMNS_GROUP,
    ),
    # CLIP API response fields
    ColumnDefinition(
        name=Columns.CLIP_ID.value,
        alias="clip_clip",
        data_type=DataTypeEnum.TEXT,
        description="CLIP identifier",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_CLIP_STATUS_CODE.value,
        alias="clip_clipStatus",
        data_type=DataTypeEnum.TEXT,
        description="CLIP processing status",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_APN_SEQUENCE_NUMBER.value,
        alias="clip_apnSequenceNumber",
        data_type=DataTypeEnum.INT64,
        description="APN sequence number",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_UNIVERSAL_PARCEL_ID.value,
        alias="clip_universalParcelId",
        data_type=DataTypeEnum.INT64,
        description="Universal parcel identifier",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_COUNTY_CODE.value,
        alias="clip_countyCode",
        data_type=DataTypeEnum.TEXT,
        description="County code",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_LATITUDE.value,
        alias="clip_latitude",
        data_type=DataTypeEnum.FLOAT64,
        description="CLIP latitude coordinate",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_LONGITUDE.value,
        alias="clip_longitude",
        data_type=DataTypeEnum.FLOAT64,
        description="CLIP longitude coordinate",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_APN_UNFORMATTED.value,
        alias="clip_apnUnformatted",
        data_type=DataTypeEnum.TEXT,
        description="Unformatted APN",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_APN_FORMATTED.value,
        alias="clip_apnFormatted",
        data_type=DataTypeEnum.TEXT,
        description="Formatted APN",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_PREVIOUS_APN_UNFORMATTED.value,
        alias="clip_previousApnUnformatted",
        data_type=DataTypeEnum.TEXT,
        description="Previous unformatted APN",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_FULL_ADDRESS.value,
        alias="clip_fullAddress",
        data_type=DataTypeEnum.TEXT,
        description="CLIP full address",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_LINE.value,
        alias="clip_addressLine",
        data_type=DataTypeEnum.TEXT,
        description="CLIP address line",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_HOUSE_NUMBER.value,
        alias="clip_houseNumber",
        data_type=DataTypeEnum.TEXT,
        description="House number",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_UNIT_NUMBER.value,
        alias="clip_unitNumber",
        data_type=DataTypeEnum.TEXT,
        description="Unit number",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_UNIT_TYPE.value,
        alias="clip_unitType",
        data_type=DataTypeEnum.TEXT,
        description="Unit type",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_STREET_NAME.value,
        alias="clip_streetName",
        data_type=DataTypeEnum.TEXT,
        description="Street name",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_STREET_NAME_FULL.value,
        alias="clip_streetNameFull",
        data_type=DataTypeEnum.TEXT,
        description="Full street name",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_STREET_NAME_SUFFIX.value,
        alias="clip_streetNameSuffix",
        data_type=DataTypeEnum.TEXT,
        description="Street name suffix",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_STREET_NAME_PREFIX.value,
        alias="clip_streetNamePrefix",
        data_type=DataTypeEnum.TEXT,
        description="Street name prefix",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_STREET_NAME_PREFIX_DIRECTION.value,
        alias="clip_streetNamePrefixDirection",
        data_type=DataTypeEnum.TEXT,
        description="Street name prefix direction",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_CITY_LINE.value,
        alias="clip_cityLine",
        data_type=DataTypeEnum.TEXT,
        description="City line",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_CITY.value,
        alias="clip_city",
        data_type=DataTypeEnum.TEXT,
        description="CLIP city",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_STATE.value,
        alias="clip_state",
        data_type=DataTypeEnum.TEXT,
        description="CLIP state",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ZIP_CODE.value,
        alias="clip_zipCode",
        data_type=DataTypeEnum.TEXT,
        description="CLIP ZIP code",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_COUNTY.value,
        alias="clip_county",
        data_type=DataTypeEnum.TEXT,
        description="CLIP county",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_COUNTRY_CODE.value,
        alias="clip_countryCode",
        data_type=DataTypeEnum.TEXT,
        description="CLIP country code",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ZIP_PLUS4.value,
        alias="clip_zipPlus4",
        data_type=DataTypeEnum.TEXT,
        description="CLIP ZIP+4",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_MATCH_CODE.value,
        alias="clip_matchCode",
        data_type=DataTypeEnum.TEXT,
        description="Match code",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_PROPERTY_MATCH_SCORE.value,
        alias="clip_propertyMatchScore",
        data_type=DataTypeEnum.INT64,
        description="Property match score",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_STREET_SIDE.value,
        alias="clip_streetSide",
        data_type=DataTypeEnum.TEXT,
        description="Street side",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_STREET_NAME_BASE.value,
        alias="clip_streetNameBase",
        data_type=DataTypeEnum.TEXT,
        description="Street name base",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_STREET_NAME_SUFFIX_DIRECTION.value,
        alias="clip_streetNameSuffixDirection",
        data_type=DataTypeEnum.TEXT,
        description="Street name suffix direction",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_UNIT_RANGE_HIGH.value,
        alias="clip_unitRangeHigh",
        data_type=DataTypeEnum.TEXT,
        description="Unit range high",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_UNIT_RANGE_LOW.value,
        alias="clip_unitRangeLow",
        data_type=DataTypeEnum.TEXT,
        description="Unit range low",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_OWNER1_NAME.value,
        alias="clip_owner1Name",
        data_type=DataTypeEnum.TEXT,
        description="CLIP owner 1 name",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_OWNER2_NAME.value,
        alias="clip_owner2Name",
        data_type=DataTypeEnum.TEXT,
        description="CLIP owner 2 name",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ID.value,
        alias="clip_addressId",
        data_type=DataTypeEnum.INT64,
        description="Address ID",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_USPS_RECOMMENDED_CITY.value,
        alias="clip_uspsRecommendedCity",
        data_type=DataTypeEnum.TEXT,
        description="USPS recommended city",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    # CLIP Address Attributes
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_ADDRESS_ID.value,
        alias="clip_addressAttributes_addressId",
        data_type=DataTypeEnum.INT64,
        description="Address attributes address ID",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_ADDRESS_TYPE.value,
        alias="clip_addressAttributes_addressType",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes address type",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_FULL_ADDRESS.value,
        alias="clip_addressAttributes_fullAddress",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes full address",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_ADDRESS_LINE.value,
        alias="clip_addressAttributes_addressLine",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes address line",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_HOUSE_NUMBER.value,
        alias="clip_addressAttributes_houseNumber",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes house number",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_UNIT_NUMBER.value,
        alias="clip_addressAttributes_unitNumber",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes unit number",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_UNIT_TYPE.value,
        alias="clip_addressAttributes_unitType",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes unit type",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_STREET_NAME.value,
        alias="clip_addressAttributes_streetName",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes street name",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_STREET_NAME_SUFFIX.value,
        alias="clip_addressAttributes_streetNameSuffix",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes street name suffix",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_CITY_LINE.value,
        alias="clip_addressAttributes_cityLine",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes city line",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_CITY.value,
        alias="clip_addressAttributes_city",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes city",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_STATE.value,
        alias="clip_addressAttributes_state",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes state",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_ZIP_CODE.value,
        alias="clip_addressAttributes_zipCode",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes ZIP code",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_COUNTRY_CODE.value,
        alias="clip_addressAttributes_countryCode",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes country code",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_LATITUDE.value,
        alias="clip_addressAttributes_latitude",
        data_type=DataTypeEnum.FLOAT64,
        description="Address attributes latitude",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_LONGITUDE.value,
        alias="clip_addressAttributes_longitude",
        data_type=DataTypeEnum.FLOAT64,
        description="Address attributes longitude",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_ZIP_PLUS4.value,
        alias="clip_addressAttributes_zipPlus4",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes ZIP+4",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_STREET_SIDE.value,
        alias="clip_addressAttributes_streetSide",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes street side",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_STREET_NAME_PREFIX.value,
        alias="clip_addressAttributes_streetNamePrefix",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes street name prefix",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_STREET_NAME_PREFIX_DIRECTION.value,
        alias="clip_addressAttributes_streetNamePrefixDirection",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes street name prefix direction",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_STREET_NAME_BASE.value,
        alias="clip_addressAttributes_streetNameBase",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes street name base",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_STREET_NAME_SUFFIX_DIRECTION.value,
        alias="clip_addressAttributes_streetNameSuffixDirection",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes street name suffix direction",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_STREET_NAME_FULL.value,
        alias="clip_addressAttributes_streetNameFull",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes street name full",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_UNIT_RANGE_HIGH.value,
        alias="clip_addressAttributes_unitRangeHigh",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes unit range high",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_UNIT_RANGE_LOW.value,
        alias="clip_addressAttributes_unitRangeLow",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes unit range low",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_GEOCODE_DATA_SET.value,
        alias="clip_addressAttributes_geocodeDataSet",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes geocode data set",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_GEOCODE_VENDOR.value,
        alias="clip_addressAttributes_geocodeVendor",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes geocode vendor",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_ADDRESS_MATCH_CODE.value,
        alias="clip_addressAttributes_addressMatchCode",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes address match code",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_ADDRESS_MATCH_DESCRIPTION.value,
        alias="clip_addressAttributes_addressMatchDescription",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes address match description",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_ADDRESS_MATCH_RECORD.value,
        alias="clip_addressAttributes_addressMatchRecord",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes address match record",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_USPS_RECOMMENDED_CITY.value,
        alias="clip_addressAttributes_uspsRecommendedCity",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes USPS recommended city",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_ADMIN1.value,
        alias="clip_addressAttributes_admin1",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes admin level 1",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_ADMIN2.value,
        alias="clip_addressAttributes_admin2",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes admin level 2",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_ADMIN3.value,
        alias="clip_addressAttributes_admin3",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes admin level 3",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_ADMIN4.value,
        alias="clip_addressAttributes_admin4",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes admin level 4",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_ADMIN5.value,
        alias="clip_addressAttributes_admin5",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes admin level 5",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_ADMIN6.value,
        alias="clip_addressAttributes_admin6",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes admin level 6",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_ADDRESS_ATTRIBUTES_ADMIN7.value,
        alias="clip_addressAttributes_admin7",
        data_type=DataTypeEnum.TEXT,
        description="Address attributes admin level 7",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    # Final status and pagination columns
    ColumnDefinition(
        name=Columns.CLIP_RESPONSE_STATUS.value,
        alias="clip_status",
        data_type=DataTypeEnum.INT64,
        description="CLIP HTTP response status code",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_RESULT_CODE.value,
        alias="clip_resultCode",
        data_type=DataTypeEnum.TEXT,
        description="CLIP result code",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_PAGE_SIZE.value,
        alias="clip_pageSize",
        data_type=DataTypeEnum.INT64,
        description="Page size",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_TOTAL_RECORDS.value,
        alias="clip_totalRecords",
        data_type=DataTypeEnum.INT64,
        description="Total records",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_TOTAL_PAGES.value,
        alias="clip_totalPages",
        data_type=DataTypeEnum.INT64,
        description="Total pages",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
    ColumnDefinition(
        name=Columns.CLIP_PAGE_NUMBER.value,
        alias="clip_pageNumber",
        data_type=DataTypeEnum.INT64,
        description="Current page number",
        nullable=True,
        group=CLIP_COLUMNS_GROUP,
    ),
]

# ============ Usage Examples ============
#
# # Create database client and table instance with dynamic table name
# db_client = SnowflakeClient(config)
# output_table = ClipOutputTable(
#     database_client=db_client,
#     database_name="customer_db",
#     schema_name="clip_output",
#     table_name="customer_properties_with_clip_2024"  # Dynamic name from customer
# )
#
# # Create the table in database
# output_table.create()
#
# # Insert a new record combining customer input with CLIP response
# clip_output = ClipOutput(
#     reference_id="REF_001",
#     street_address="123 Main St",
#     city="Los Angeles",
#     state="CA",
#     zip_code="90001",
#     full_address="123 Main St, Los Angeles, CA 90001",
#     apn="1234-567-890",
#     fips_code="06037",
#     owner_name_1="John Doe",
#     owner_name_2="Jane Doe",
#     latitude=34.0522,
#     longitude=-118.2437,
#     # CLIP API response fields
#     clip_id="CLIP_12345",
#     clip_clip_status="MATCHED",
#     clip_full_address="123 MAIN ST LOS ANGELES CA 90001",
#     clip_city="LOS ANGELES",
#     clip_state="CA",
#     clip_zip_code="90001",
#     clip_latitude=34.0522,
#     clip_longitude=-118.2437,
#     clip_match_code="A1",
#     clip_property_match_score=95.5,
#     clip_status=200,
#     clip_result_code="SUCCESS"
# )
# output_table.insert(clip_output)
#
# # Get a record by primary key
# record = output_table.get("REF_001")
# print(f"CLIP Address: {record.clip_full_address}")
# print(f"Match Score: {record.clip_property_match_score}")
#
# # Select records with filtering
# matched_records = output_table.select("clip_clip_status = ?", ["MATCHED"])
#
# # Update a record with additional CLIP data
# record.clip_owner1_name = "JOHN DOE"
# record.clip_address_attributes_city = "LOS ANGELES"
# output_table.update(record)
#
# # Batch insert with duplicate checking
# new_records = [
#     ClipOutput(reference_id="REF_002", clip_id="CLIP_67890", ...),
#     ClipOutput(reference_id="REF_003", clip_id="CLIP_11111", ...),
# ]
# output_table.insert(new_records, if_not_exists=True)
#
# # Access column names via enum
# ref_col = output_table.columns.REFERENCE_ID  # Returns "reference_id"
# clip_status_col = output_table.columns.CLIP_CLIP_STATUS  # Returns "clip_clip_status"
# match_score_col = output_table.columns.CLIP_PROPERTY_MATCH_SCORE  # Returns "clip_property_match_score"
#
# # Query with complex filters
# high_confidence_matches = output_table.select(
#     "clip_property_match_score > ? AND clip_clip_status = ?",
#     [90.0, "MATCHED"]
# )
#
# # Get column information for dynamic queries
# primary_columns = output_table.get_column_names(primary_only=True)
# # Returns: ['reference_id']
#
# all_columns = output_table.get_column_names()
# # Returns: ['reference_id', 'street_address', 'city', ...]
