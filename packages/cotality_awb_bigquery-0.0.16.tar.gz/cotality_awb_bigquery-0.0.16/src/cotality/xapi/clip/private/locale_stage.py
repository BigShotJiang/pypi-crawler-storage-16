# Copyright 2025 Cotality
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Clip Output"""

from __future__ import annotations

from logging import getLogger

from ....core.clgxtyping import AppSchemaID, Country
from ....core.error_codes import CommonErrorCodes
from ....core.exception import ClgxException
from ....core.platform import Platform
from .clip_us.stage import ClipStageTable as ClipStageTableUS

logger = getLogger(__name__)


class ClipStageTable:
    """Base class for Clip Stage Table"""

    def __init__(self, platform: Platform):
        """Initialize the ClipStageTable instance.

        Args:
            platform (Platform): Platform instance
        """
        self._platform = platform
        self._database_client = platform.database_client

        self._database_name, self._schema_name = platform.get_schema(AppSchemaID.CLIP_OUTPUT)
        contry_code = platform.config.locale.country_code
        match contry_code:
            case Country.US:
                self._table = ClipStageTableUS(
                    database_client=platform.database_client,
                    database_name=self._database_name,
                    schema_name=self._schema_name,
                    table_name="stage_temp",
                )
            case _:
                raise ClgxException(
                    CommonErrorCodes.CLIP_APP_CONFIG,
                    message=f"ClipOutputTable is not implemented for country code: {contry_code}",
                )

    @property
    def table(self) -> ClipStageTableUS:
        """Get the Clip output table.

        Returns:
            ClipOutputTableUS: Clip output table instance
        """
        return self._table

    def get_temp_table(self, input_table_name: str, return_full_name: bool = True) -> str:
        """Get temporary table created by the Clip stage table.

        Returns:
            str: stage_table_name
        """

        stage_table_name = f"{input_table_name}_stage_temp"
        if return_full_name:
            stage_table_name = self._database_client.full_table_name(
                database=self._database_name, schema=self._schema_name, table=stage_table_name
            )
        return stage_table_name

    def create_temp_table(self, table_name: str) -> None:
        """Create a temporary table with the same schema as the Clip output table.

        Args:
            table_name (str): Name of the temporary table to create
        """
        stage_table_name = self.get_temp_table(table_name)
        self._table.drop(table_name=stage_table_name)
        self._table.create(table_name=stage_table_name, if_not_exists=True)
