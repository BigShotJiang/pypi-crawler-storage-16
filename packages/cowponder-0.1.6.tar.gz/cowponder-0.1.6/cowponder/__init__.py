"""
cowponder

A simple command that displays randomly selected philosophical thoughts from a cow
"""
from cowponder.ponder import ponder, cowponder, add_thoughts, update_thoughtbook, print_info, VERSION
from cowponder.ponder import main as ponder_main
from cowponder.cowponder import main as cowponder_main
