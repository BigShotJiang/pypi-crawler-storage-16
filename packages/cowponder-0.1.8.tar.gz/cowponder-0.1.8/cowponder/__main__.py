from cowponder.cowponder import main as cowponder_main
if __name__ == "__main__":
    cowponder_main()
