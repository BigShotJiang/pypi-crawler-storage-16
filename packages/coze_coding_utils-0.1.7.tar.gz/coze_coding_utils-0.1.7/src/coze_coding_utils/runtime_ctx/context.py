import os
import uuid
from dataclasses import dataclass
from typing import Optional, Dict, Mapping

# Header keys
HEADER_X_TT_LOGID = "x-tt-logid"
HEADER_X_TT_ENV = "x-tt-env"
HEADER_X_USE_PPE = "x-use-ppe"
HEADER_X_TT_ENV_FE = "x-tt-env-fe"
HEADER_RPC_PERSIST_REC_REC_BIZ_SCENE = "rpc-persist-rec-rec-biz-scene"
HEADER_RPC_PERSIST_COZE_RECORD_ROOT_ID = "rpc-persist-coze-record-root-id" # root_id，串联一次完整请求，通常标识一次完整对话
HEADER_RPC_PERSIST_REC_ROOT_ENTITY_TYPE = "rpc-persist-rec-rec-root-entity-type" # 对应最顶层实体类型，用于标识资源消耗的来源归属实体
HEADER_RPC_PERSIST_REC_ROOT_ENTITY_ID = "rpc-persist-rec-rec-root-entity-id" #对应最顶层实体ID

# Environment variable keys
ENV_SPACE_ID = "COZE_PROJECT_SPACE_ID"
ENV_PROJECT_ID = "COZE_PROJECT_ID"


@dataclass(slots=True)
class Context:
    """运行时上下文，封装请求关联的标识与环境信息。"""
    run_id: str
    space_id: str
    project_id: str
    logid: str = ""
    method: str = ""
    x_tt_env: Optional[str] = None
    x_use_ppe: Optional[str] = None
    x_tt_env_fe: Optional[str] = None

    rpc_persist_rec_rec_biz_scene: Optional[str] = None
    rpc_persist_coze_record_root_id: Optional[str] = None
    rpc_persist_rec_root_entity_type: Optional[str] = None
    rpc_persist_rec_root_entity_id: Optional[str] = None


def new_context(method: str, headers: Optional[Mapping[str, str]] = None) -> Context:
    """创建上下文对象，读取必要环境变量并可从请求头补充可选字段。"""
    ctx = Context(
        run_id=str(uuid.uuid4()),
        space_id=os.getenv(ENV_SPACE_ID, ""),
        project_id=os.getenv(ENV_PROJECT_ID, ""),
        method=method,
    )
    if headers:
        if HEADER_X_TT_LOGID in headers:
            ctx.logid = headers[HEADER_X_TT_LOGID]
        if HEADER_X_TT_ENV in headers:
            ctx.x_tt_env = headers[HEADER_X_TT_ENV]
        if HEADER_X_USE_PPE in headers:
            ctx.x_use_ppe = headers[HEADER_X_USE_PPE]
        if HEADER_X_TT_ENV_FE in headers:
            ctx.x_tt_env_fe = headers[HEADER_X_TT_ENV_FE]
        if HEADER_RPC_PERSIST_REC_REC_BIZ_SCENE in headers:
            ctx.rpc_persist_rec_rec_biz_scene = headers[HEADER_RPC_PERSIST_REC_REC_BIZ_SCENE]
        if HEADER_RPC_PERSIST_COZE_RECORD_ROOT_ID in headers:
            ctx.rpc_persist_coze_record_root_id = headers[HEADER_RPC_PERSIST_COZE_RECORD_ROOT_ID]
        if HEADER_RPC_PERSIST_REC_ROOT_ENTITY_TYPE in headers:
            ctx.rpc_persist_rec_root_entity_type = headers[HEADER_RPC_PERSIST_REC_ROOT_ENTITY_TYPE]
        if HEADER_RPC_PERSIST_REC_ROOT_ENTITY_ID in headers:
            ctx.rpc_persist_rec_root_entity_id = headers[HEADER_RPC_PERSIST_REC_ROOT_ENTITY_ID]
    return ctx


def default_headers(ctx: Context | None) -> Dict[str, str]:
    """从上下文生成请求头字典，仅包含已设置的字段。"""
    if not ctx:
        return {}
    headers: Dict[str, str] = {}
    if ctx.logid:
        headers[HEADER_X_TT_LOGID] = ctx.logid
    if ctx.x_tt_env:
        headers[HEADER_X_TT_ENV] = ctx.x_tt_env
    if ctx.x_use_ppe:
        headers[HEADER_X_USE_PPE] = ctx.x_use_ppe
    if ctx.x_tt_env_fe:
        headers[HEADER_X_TT_ENV_FE] = ctx.x_tt_env_fe
    if ctx.rpc_persist_rec_rec_biz_scene:
        headers[HEADER_RPC_PERSIST_REC_REC_BIZ_SCENE] = ctx.rpc_persist_rec_rec_biz_scene
    if ctx.rpc_persist_coze_record_root_id:
        headers[HEADER_RPC_PERSIST_COZE_RECORD_ROOT_ID] = ctx.rpc_persist_coze_record_root_id
    if ctx.rpc_persist_rec_root_entity_type:
        headers[HEADER_RPC_PERSIST_REC_ROOT_ENTITY_TYPE] = ctx.rpc_persist_rec_root_entity_type
    if ctx.rpc_persist_rec_root_entity_id:
        headers[HEADER_RPC_PERSIST_REC_ROOT_ENTITY_ID] = ctx.rpc_persist_rec_root_entity_id
    return headers

__all__ = [
    "Context",
    "new_context",
]
