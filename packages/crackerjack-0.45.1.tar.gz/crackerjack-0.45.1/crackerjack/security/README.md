> Crackerjack Docs: [Main](<../../README.md>) | [Crackerjack Package](<../README.md>) | [Security](<./README.md>)

# Security

Security checks, validators, and related utilities.

## Related

- [Crackerjack Package](<../README.md>) - Parent package
- [Agents](<../agents/README.md>) - SecurityAgent for automated security fixes
- [Services](<../services/README.md>) - Security service implementations
