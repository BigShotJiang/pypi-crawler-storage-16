> Crackerjack Docs: [Main](<../../../README.md>) | [Crackerjack Package](<../../README.md>) | [UI](<../README.md>) | [Templates](<./README.md>)

# UI Templates

Templates used by UI components.

## Related

- [UI](<../README.md>) - Parent UI package
- [Crackerjack Package](<../../README.md>) - Root package
- [Data](<../../data/README.md>) - Static data and assets
