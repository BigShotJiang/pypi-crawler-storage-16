from pydantic import BaseModel, Field


class AssemblyFeature(BaseModel):
    ranges: dict[str, list[tuple[int, int]]] = Field(description="The ranges of the feature, keyed by polymer name")
    metadata: dict[str, str | int | float | bool] | None = Field(
        default=None, description="Optional metadata for the feature"
    )
