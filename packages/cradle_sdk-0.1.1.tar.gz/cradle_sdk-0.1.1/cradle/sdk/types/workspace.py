from enum import StrEnum

from pydantic import BaseModel, Field

from .common import ArchivableResourceMixin, BaseListResponse, ErrorResponseMixin, ResourceResponse


class WorkspaceState(StrEnum):
    PROVISIONING = "PROVISIONING"
    DELETING = "DELETING"
    READY = "READY"
    DELETED = "DELETED"
    FAILED = "FAILED"


class WorkspaceResponse(ResourceResponse, ErrorResponseMixin):
    name: str
    display_name: str
    state: WorkspaceState
    picture_file_id: int | None = Field(default=None)


class ProjectResponse(ResourceResponse, ArchivableResourceMixin):
    name: str


class ListProjectResponse(BaseListResponse):
    items: list[ProjectResponse]


class ProjectCreate(BaseModel):
    name: str


class RoundResponse(ResourceResponse, ArchivableResourceMixin):
    project_id: int
    name: str
    description: str | None


class ListRoundResponse(BaseListResponse):
    items: list[RoundResponse]


class RoundCreate(BaseModel):
    project_id: int = Field(description="The project to which the round belongs")
    name: str = Field(description="The name of the round")
    description: str | None = Field(default=None)
