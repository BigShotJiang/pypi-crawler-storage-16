# coding: utf-8

deprecated_actuators = {'CM_drive': 'SchneiderMDrive23',
                        'Fake_motor': 'FakeDCMotor',
                        'Motorkit_pump': 'DCMotorHat',
                        'Oriental': 'OrientalARDK',
                        'Pololu_tic': 'PololuTic',
                        'Servostar': 'ServoStar300',
                        'Tra6ppd': 'NewportTRA6PPD'}
