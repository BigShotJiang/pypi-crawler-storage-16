# coding: utf-8

deprecated_cameras = {'Bispectral': 'BiSpectral',
                      'Cl_camera': 'BaslerIronmanCameraLink',
                      'Fake_camera': 'FakeCamera',
                      'File_reader': 'FileReader',
                      'Camera_gstreamer': 'CameraGstreamer',
                      'Jai8': 'JaiGO5000CPMCL8Bits',
                      'Jai': 'JaiGO5000CPMCL',
                      'Camera_opencv': 'CameraOpencv',
                      'Picamera': 'RaspberryPiCamera',
                      'Seek_thermal_pro': 'SeekThermalPro',
                      'Xiapi': 'XiAPI'}
