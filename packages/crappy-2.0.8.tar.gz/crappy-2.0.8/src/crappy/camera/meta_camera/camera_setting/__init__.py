# coding: utf-8

from .camera_bool_setting import CameraBoolSetting
from .camera_choice_setting import CameraChoiceSetting
from .camera_scale_setting import CameraScaleSetting
from .camera_setting import CameraSetting
