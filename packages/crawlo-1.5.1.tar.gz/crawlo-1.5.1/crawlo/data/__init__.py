#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Crawlo 数据模块
包含用户代理、字典等数据文件
"""