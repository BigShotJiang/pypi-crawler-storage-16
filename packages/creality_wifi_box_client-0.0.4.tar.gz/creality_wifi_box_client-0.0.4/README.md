API for the Creality Wifi box.
