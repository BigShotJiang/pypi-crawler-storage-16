"""Init file for the creality wifi box client."""
