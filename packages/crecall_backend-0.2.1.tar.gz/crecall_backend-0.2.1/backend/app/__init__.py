"""
crecall Backend API

FastAPI application for session management, memory system, and clip-based recovery.
"""

__version__ = "0.1.0"
