# BASICS  
### Github Organization  
:white_check_mark: Github Organization exists  
:white_check_mark: Github Organization assigned  

---
  
### NewsAPI  
:white_check_mark: NewsAPI key exists  
:white_check_mark: NewsAPI respone fine  
:white_check_mark: NewsAPI status fine  
:white_check_mark: NewsAPI results found  

---
  
### GeonamesAPI  
:white_check_mark: Geonames key exists  
:white_check_mark: Geonames respone fine  
:white_check_mark: Geonames result fine  
:white_check_mark: Geonames results found  

---
  
### RapidAPI  
:white_check_mark: RapidAPI key exists  

---
  
# TRANSLATE  

---
  
### RapidAPI: Microsoft-Translator-3  
:no_entry: Microsoft-Translator-3 respone **failed**  
Maybe retry later...?  

---
  
### RapidAPI: Text-Translator-2  
:white_check_mark: Text-Translator-2 respone fine  
:white_check_mark: Text-Translator-2 status fine  
:white_check_mark: Text-Translator-2 results found  

---
  
### RapidAPI: Free-Google-Translator  
:white_check_mark: Free-Google-Translator respone fine  
:white_check_mark: Free-Google-Translator status fine  
:white_check_mark: Free-Google-Translator results found  

---
  
### RapidAPI: Multi-Traduction-Translate  
:white_check_mark: Multi-Traduction-Translate respone fine  
:white_check_mark: Multi-Traduction-Translate status fine  
:white_check_mark: Multi-Traduction-Translate results found  

---
  
### RapidAPI: Deepl-Translator-4  
:white_check_mark: Deepl-Translator-4 respone fine  
:no_entry: **Not** subscribed to Deepl-Translator-4  
Subscribe to Deepl-Translator-4 API:  
1. Login and 'Subscribe to Test' at https://rapidapi.com/sibaridev/api/rapid-translate-multi-traduction  
2. Make sure to enter 'Start Free Plan' and press 'Subscribe' - **don't** enter credit card data!  
   
