# CreLanguageTranslate
Translation Adapter

https://pypi.org/project/CreLanguageTranslate/

https://test.pypi.org/project/CreLanguageTranslate/


pip install CreLanguageTranslate





