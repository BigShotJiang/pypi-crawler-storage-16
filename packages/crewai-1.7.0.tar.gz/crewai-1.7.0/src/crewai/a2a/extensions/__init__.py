"""A2A Protocol Extensions for CrewAI.

This module contains extensions to the A2A (Agent-to-Agent) protocol.
"""
