from .tool import {{class_name}}

__all__ = ["{{class_name}}"]
