"""Core abstract base classes and protocols for RAG  systems."""
