"""Embedding components for RAG infrastructure."""
