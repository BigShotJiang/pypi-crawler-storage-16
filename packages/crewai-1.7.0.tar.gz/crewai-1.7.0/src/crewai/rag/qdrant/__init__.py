"""Qdrant vector database client implementation."""
