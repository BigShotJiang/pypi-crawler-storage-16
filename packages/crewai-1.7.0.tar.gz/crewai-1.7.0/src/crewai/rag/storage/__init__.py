"""Storage components for RAG infrastructure."""
