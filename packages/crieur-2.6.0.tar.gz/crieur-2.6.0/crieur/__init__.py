from pathlib import Path

VERSION = "2.6.0"
ROOT_DIR = Path(__file__).parent
