# Roadmap

- 0.2: variant-aware off-targets (VCF input), configurable nucleases/PAMs.
- 0.3: bulges, pruning heuristics, multi-GPU support.
- 0.4+: wheels for all major platforms, richer scoring plug-ins.
