#pragma once

#define CRISPR_GPU_VERSION "0.2.0"

namespace crispr_gpu {
const char* version();
}
