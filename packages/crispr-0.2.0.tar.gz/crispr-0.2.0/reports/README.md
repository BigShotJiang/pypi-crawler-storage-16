# Reports

- `reports/sample/`: checked-in example output from `scripts/artifact_run.py --quick --redact`.
- `reports/latest/`: ignored by git; intended for local runs.

