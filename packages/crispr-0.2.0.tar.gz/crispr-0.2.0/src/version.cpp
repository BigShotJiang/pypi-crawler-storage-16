#include "crispr_gpu/version.hpp"

namespace crispr_gpu {
const char* version() { return CRISPR_GPU_VERSION; }
}
