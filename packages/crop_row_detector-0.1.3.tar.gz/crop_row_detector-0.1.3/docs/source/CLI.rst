CLI
***

.. argparse::
   :module: crop_row_detector.__main__
   :func: _get_parser
   :prog: Crop Row Detector
