Reference Manual
================

.. currentmodule:: crop_row_detector

.. autosummary::
    :toctree: ./reference

    crop_row_detector
    orthomosaic_tiler
