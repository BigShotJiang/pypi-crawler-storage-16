# cropengine


[![image](https://img.shields.io/pypi/v/cropengine.svg)](https://pypi.python.org/pypi/cropengine)
[![image](https://img.shields.io/conda/vn/conda-forge/cropengine.svg)](https://anaconda.org/conda-forge/cropengine)


**cropengine is a Python package that streamlines running process-based crop models by automating data preparation, simulation workflows, and result analysis.**


-   Free software: MIT License
-   Documentation: https://geonextgis.github.io/cropengine


## Features

-   TODO
