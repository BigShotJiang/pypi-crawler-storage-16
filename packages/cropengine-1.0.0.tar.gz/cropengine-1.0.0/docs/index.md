# Welcome to cropengine


[![image](https://img.shields.io/pypi/v/cropengine.svg)](https://pypi.python.org/pypi/cropengine)


**cropengine is a Python package that streamlines running process-based crop models by automating data preparation, simulation workflows, and result analysis.**


-   Free software: MIT License
-   Documentation: <https://geonextgis.github.io/cropengine>


## Features

-   TODO
