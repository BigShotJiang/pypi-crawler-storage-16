# Usage

To use cropengine in a project:

```
import cropengine
```
