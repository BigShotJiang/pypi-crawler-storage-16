#!/usr/bin/env python

"""Tests for `cropengine` package."""


import unittest

from cropengine import cropengine


class TestCropengine(unittest.TestCase):
    """Tests for `cropengine` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
