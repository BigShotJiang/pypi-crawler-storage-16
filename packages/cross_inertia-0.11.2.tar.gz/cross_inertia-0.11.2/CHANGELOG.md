

0.11.2 - 2025-12-11
-------------------

Remove unused `back()` method from documentation

- Remove `back()` method section from API reference docs
- Update forms documentation to use `render()` with `errors` parameter instead of `back()`
