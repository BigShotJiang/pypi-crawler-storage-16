---
release type: patch
---

Remove unused `back()` method from documentation

- Remove `back()` method section from API reference docs
- Update forms documentation to use `render()` with `errors` parameter instead of `back()`
