# crosshair: analysis_kind=deal
