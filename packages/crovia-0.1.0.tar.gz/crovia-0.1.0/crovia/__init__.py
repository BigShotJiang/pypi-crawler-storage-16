"""
CroviaTrust – Open-core evidence & payout engine.

This package exposes:
- semantic DSSE engine (crovia.semantic.*)
- command-line interface (crovia.cli)
- open-core scripts for receipts, payouts, trust bundles, hashchains.
"""

from . import semantic  # keep existing semantic subpackage

__all__ = ["__version__", "semantic"]
__version__ = "0.1.0"
