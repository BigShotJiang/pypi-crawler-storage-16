# CrowdStrike AIDR Python SDK

Python SDK for CrowdStrike AIDR.
