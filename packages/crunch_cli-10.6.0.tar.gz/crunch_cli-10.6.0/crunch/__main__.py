from crunch.cli import cli

cli()
