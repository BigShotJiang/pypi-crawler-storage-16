# -*- coding: utf-8 -*-
"""
Module for command-line argument parsing and option management.
"""

from .options import add  # noqa: F401

__all__ = ["add"]
