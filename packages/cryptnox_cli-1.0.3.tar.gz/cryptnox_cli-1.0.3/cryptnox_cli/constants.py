"""
Centralized constants for the Cryptnox CLI.
"""

MAX_PASSPHRASE_LENGTH = 100
