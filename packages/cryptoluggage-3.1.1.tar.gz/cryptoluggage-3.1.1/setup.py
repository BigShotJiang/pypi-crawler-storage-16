"""Setup script for cryptoluggage
"""

from setuptools import setup

setup()
