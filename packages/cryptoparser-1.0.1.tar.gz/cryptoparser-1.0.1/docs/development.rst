-----------
Development
-----------

If you want to setup a development environment, you are in need of `pipenv <https://docs.pipenv.org/>`__.

.. code:: shell

   $ cd cryptoparser
   $ pipenv install --dev
   $ pipenv shell
