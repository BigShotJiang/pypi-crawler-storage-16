#!/bin/bash

python -m pytest
