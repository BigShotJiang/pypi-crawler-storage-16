"""
Unit tests for cs_binding_generator
"""
