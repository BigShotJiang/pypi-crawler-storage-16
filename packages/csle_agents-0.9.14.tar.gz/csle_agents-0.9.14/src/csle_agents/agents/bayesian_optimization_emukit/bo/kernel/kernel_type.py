from enum import IntEnum


class KernelType(IntEnum):
    """
    Enum representing different kernels
    """
    RBF = 0
