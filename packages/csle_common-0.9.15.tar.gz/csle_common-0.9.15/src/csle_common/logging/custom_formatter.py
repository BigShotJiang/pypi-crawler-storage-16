import logging


class CustomFormatter(logging.Formatter):
    """
    Custom formatter for DEBUG-logging.

    Custom Formatter does these 2 things:
    1. Overrides 'funcName' with the value of 'func_name_override', if it exists.
    2. Overrides 'filename' with the value of 'file_name_override', if it exists.
    """
    def format(self, record) -> str:
        """
        Formats a given record

        :param record: the record to format
        :return: the formatted string
        """
        if hasattr(record, 'func_name_override'):
            record.funcName = record.func_name_override
        if hasattr(record, 'file_name_override'):
            record.filename = record.file_name_override
        return super(CustomFormatter, self).format(record)
