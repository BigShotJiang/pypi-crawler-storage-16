"""csvpeek - A snappy CSV viewer TUI."""

__version__ = "0.1.0"
