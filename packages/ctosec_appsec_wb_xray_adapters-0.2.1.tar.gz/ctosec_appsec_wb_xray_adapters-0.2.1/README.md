# XRAY Adapter

A quick package for checking and setting proxy information.