"""认证模块"""

from auth.signature import CTYUNAuth

__all__ = ['CTYUNAuth']