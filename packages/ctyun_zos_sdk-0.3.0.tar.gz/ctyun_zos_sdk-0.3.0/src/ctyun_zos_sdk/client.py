"""Main client for CTyun ZOS SDK."""

import hashlib
import json
import os
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from typing import Optional, Dict, Any, Union, BinaryIO, Generator, List
from urllib.parse import urlparse
from threading import Thread, Lock
from queue import Queue
import time
import httpx
from botocore.awsrequest import AWSRequest
from botocore.auth import SigV4Auth
from botocore.credentials import Credentials

from .exceptions import ZOSError, ZOSClientError, ZOSServerError

class AtomicInteger:
    def __init__(self, value=0):
        self.value = value
        self.lock = Lock()
    
    def increment_and_get(self):
        with self.lock:
            self.value += 1
            return self.value
        
    def get(self):
        with self.lock:
            return self.value

class ZOSClient:
    """Client for interacting with CTyun Object Storage (ZOS)."""

    def __init__(
        self,
        access_key: str,
        secret_key: str,
        region: str,
        endpoint: str,
        verify_ssl: bool = True,
        timeout: float = 30.0,
        **kwargs
    ):
        """Initialize the ZOS client.
        
        Args:
            access_key: Access key ID for authentication
            secret_key: Secret access key for authentication
            region: AWS region name (used for signing)
            endpoint: ZOS service endpoint URL
            verify_ssl: Whether to verify SSL certificates
            timeout: Request timeout in seconds
            **kwargs: Additional configuration options
        """
        self.access_key = access_key
        self.secret_key = secret_key
        self.region = region
        self.endpoint = endpoint.rstrip('/')
        self.verify_ssl = verify_ssl
        self.timeout = timeout
        
        # Create credentials and auth objects
        self.credentials = Credentials(access_key, secret_key)
        self.auth = SigV4Auth(self.credentials, "s3", region)
        
        # Create httpx client
        self.http_client = httpx.Client(
            verify=verify_ssl,
            timeout=timeout,
            **kwargs
        )

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()

    def close(self):
        """Close the HTTP client."""
        if hasattr(self, 'http_client'):
            self.http_client.close()

    def _build_url(self, bucket: str, key: str) -> str:
        """Build the full URL for an S3 operation.
        
        Args:
            bucket: Bucket name
            key: Object key
            
        Returns:
            Full URL for the operation
        """
        return f"{self.endpoint}/{bucket}/{key}"

    def _get_headers(self, method: str, content: Optional[bytes] = None, **kwargs) -> Dict[str, str]:
        """Generate headers for an S3 request.
        
        Args:
            method: HTTP method
            content: Request content for calculating SHA256
            **kwargs: Additional headers
            
        Returns:
            Dictionary of headers
        """
        headers = {
            "x-amz-date": datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ"),
            **kwargs
        }
        
        if content:
            # Calculate SHA256 hash for signed payloads
            sha256_hash = hashlib.sha256(content).hexdigest()
            headers["x-amz-content-sha256"] = sha256_hash
        else:
            # Use UNSIGNED-PAYLOAD for requests without body (like GET)
            headers["x-amz-content-sha256"] = "UNSIGNED-PAYLOAD"
            
        return headers

    def _sign_request(self, method: str, url: str, headers: Dict[str, str], data: Optional[bytes] = None) -> Dict[str, str]:
        """Sign the request using AWS SigV4.
        
        Args:
            method: HTTP method
            url: Request URL
            headers: Request headers
            data: Request data
            
        Returns:
            Signed headers
        """
        request = AWSRequest(
            method=method,
            url=url,
            data=data,
            headers=headers
        )
        
        self.auth.add_auth(request)
        return dict(request.headers)

    def get_object(self, Bucket: str, Key: str, **kwargs) -> Dict[str, Any]:
        """Get an object from S3.
        
        Args:
            Bucket: Bucket name
            Key: Object key
            **kwargs: Additional parameters
            
        Returns:
            Response dictionary containing the object data
            
        Raises:
            ZOSError: If the request fails
        """
        url = self._build_url(Bucket, Key)
        headers = self._get_headers("GET")
        if "Range" in kwargs:
            headers["Range"] = kwargs["Range"]
        signed_headers = self._sign_request("GET", url, headers)
        
        try:
            response = self.http_client.get(url, headers=signed_headers)
            response.raise_for_status()
            
            result = {
                "Body": response.content,
                "ContentLength": len(response.content),
                "ContentType": response.headers.get("content-type"),
                "ETag": response.headers.get("etag"),
                "LastModified": response.headers.get("last-modified"),
                "Metadata": self._parse_metadata(response.headers),
                "ResponseMetadata": {
                    "HTTPStatusCode": response.status_code,
                    "HTTPHeaders": dict(response.headers)
                }
            }
            if "Range" in kwargs:
                result["ContentLength"] = int(result.get("content-length", result.get("Content-Length")))
            return result
        except httpx.HTTPStatusError as e:
            if e.response.status_code >= 500:
                raise ZOSServerError(f"Server error: {e.response.status_code}") from e
            else:
                raise ZOSClientError(f"Client error: {e.response.status_code}") from e
        except Exception as e:
            raise ZOSError(f"Request failed: {str(e)}") from e

            
    def head_object(self, Bucket: str, Key: str, **kwargs) -> Dict[str, Any]:
        """Get an object Header from S3 asynchronously.
        
        Args:
            Bucket: Bucket name
            Key: Object key
            **kwargs: Additional parameters
        """
        url = self._build_url(Bucket, Key)
        headers = self._get_headers("HEAD")
        if "Range" in kwargs:
            headers["Range"] = kwargs["Range"]
        signed_headers = self._sign_request("HEAD", url, headers)
        response = self.http_client.head(url, headers=signed_headers)
        return response.headers

    def put_object(self, Bucket: str, Key: str, Body: Union[str, bytes, BinaryIO], **kwargs) -> Dict[str, Any]:
        """Put an object to S3.
        
        Args:
            Bucket: Bucket name
            Key: Object key
            Body: Object content
            **kwargs: Additional parameters (ContentType, Metadata, etc.)
            
        Returns:
            Response dictionary
            
        Raises:
            ZOSError: If the request fails
        """
        url = self._build_url(Bucket, Key)
        
        # Convert body to bytes
        if isinstance(Body, str):
            body_bytes = Body.encode('utf-8')
        elif isinstance(Body, bytes):
            body_bytes = Body
        elif hasattr(Body, 'read'):
            body_bytes = Body.read()
        else:
            body_bytes = str(Body).encode('utf-8')
        
        # Prepare headers
        headers = self._get_headers("PUT", body_bytes)
        if "ContentType" in kwargs:
            headers["Content-Type"] = kwargs["ContentType"]
        
        # Add metadata headers
        metadata = kwargs.get("Metadata", {})
        for key, value in metadata.items():
            headers[f"x-amz-meta-{key.lower()}"] = value
        
        signed_headers = self._sign_request("PUT", url, headers, body_bytes)
        
        try:
            response = self.http_client.put(url, content=body_bytes, headers=signed_headers)
            response.raise_for_status()
            
            return {
                "ETag": response.headers.get("etag"),
                "ResponseMetadata": {
                    "HTTPStatusCode": response.status_code,
                    "HTTPHeaders": dict(response.headers)
                }
            }
        except httpx.HTTPStatusError as e:
            if e.response.status_code >= 500:
                raise ZOSServerError(f"Server error: {e.response.status_code}") from e
            else:
                raise ZOSClientError(f"Client error: {e.response.status_code}") from e
        except Exception as e:
            raise ZOSError(f"Request failed: {str(e)}") from e


    def create_multipart_upload(self, Bucket: str, Key: str, **kwargs) -> Dict[str, Any]:
        """Initiate a multipart upload (boto3 compatible signature).

        Args:
            Bucket: Bucket name
            Key: Object key
            **kwargs: Additional parameters (ContentType, Metadata)
        """
        url = f"{self._build_url(Bucket, Key)}?uploads"
        headers = self._get_headers("POST")
        if "ContentType" in kwargs and kwargs["ContentType"] is not None:
            headers["Content-Type"] = kwargs["ContentType"]
        metadata = kwargs.get("Metadata", {})
        for key, value in metadata.items():
            headers[f"x-amz-meta-{key.lower()}"] = value

        signed_headers = self._sign_request("POST", url, headers)

        try:
            response = self.http_client.post(url, headers=signed_headers)
            response.raise_for_status()
            upload_id = self._parse_xml_value(response.text, "UploadId")
            if not upload_id:
                raise ZOSError("UploadId missing in create_multipart_upload response")
            return {
                "UploadId": upload_id,
                "ResponseMetadata": {
                    "HTTPStatusCode": response.status_code,
                    "HTTPHeaders": dict(response.headers),
                },
            }
        except httpx.HTTPStatusError as e:
            if e.response.status_code >= 500:
                raise ZOSServerError(f"Server error: {e.response.status_code}") from e
            else:
                raise ZOSClientError(f"Client error: {e.response.status_code}") from e
        except Exception as e:
            raise ZOSError(f"Request failed: {str(e)}") from e


    def upload_part(
        self,
        Bucket: str,
        Key: str,
        PartNumber: int,
        UploadId: str,
        Body: Union[str, bytes, BinaryIO],
        **kwargs,
    ) -> Dict[str, Any]:
        """Upload a single part for a multipart upload."""
        url = f"{self._build_url(Bucket, Key)}?partNumber={PartNumber}&uploadId={UploadId}"

        if isinstance(Body, str):
            body_bytes = Body.encode("utf-8")
        elif isinstance(Body, bytes):
            body_bytes = Body
        elif hasattr(Body, "read"):
            body_bytes = Body.read()
        else:
            body_bytes = str(Body).encode("utf-8")

        headers = self._get_headers("PUT", body_bytes)
        if "ContentLength" in kwargs:
            headers["Content-Length"] = str(kwargs["ContentLength"])

        signed_headers = self._sign_request("PUT", url, headers, body_bytes)

        try:
            response = self.http_client.put(url, content=body_bytes, headers=signed_headers)
            response.raise_for_status()
            return {
                "ETag": response.headers.get("etag"),
                "ResponseMetadata": {
                    "HTTPStatusCode": response.status_code,
                    "HTTPHeaders": dict(response.headers),
                },
            }
        except httpx.HTTPStatusError as e:
            if e.response.status_code >= 500:
                raise ZOSServerError(f"Server error: {e.response.status_code}") from e
            else:
                raise ZOSClientError(f"Client error: {e.response.status_code}") from e
        except Exception as e:
            raise ZOSError(f"Request failed: {str(e)}") from e


    def complete_multipart_upload(
        self,
        Bucket: str,
        Key: str,
        UploadId: str,
        MultipartUpload: Dict[str, List[Dict[str, Union[str, int]]]],
        **kwargs,
    ) -> Dict[str, Any]:
        """Complete a multipart upload by sending the assembled parts list."""
        url = f"{self._build_url(Bucket, Key)}?uploadId={UploadId}"
        parts = MultipartUpload.get("Parts", [])

        # Sort parts by PartNumber to satisfy S3 ordering requirements
        parts_sorted = sorted(parts, key=lambda p: int(p["PartNumber"]))
        parts_xml_fragments = [
            f"<Part><PartNumber>{p['PartNumber']}</PartNumber><ETag>{p['ETag']}</ETag></Part>"
            for p in parts_sorted
        ]
        body_str = f"<CompleteMultipartUpload>{''.join(parts_xml_fragments)}</CompleteMultipartUpload>"
        body_bytes = body_str.encode("utf-8")

        headers = self._get_headers("POST", body_bytes)
        signed_headers = self._sign_request("POST", url, headers, body_bytes)

        try:
            response = self.http_client.post(url, content=body_bytes, headers=signed_headers)
            response.raise_for_status()
            parsed = {
                "Location": self._parse_xml_value(response.text, "Location"),
                "Bucket": self._parse_xml_value(response.text, "Bucket"),
                "Key": self._parse_xml_value(response.text, "Key"),
                "ETag": self._parse_xml_value(response.text, "ETag"),
                "ResponseMetadata": {
                    "HTTPStatusCode": response.status_code,
                    "HTTPHeaders": dict(response.headers),
                },
            }
            return parsed
        except httpx.HTTPStatusError as e:
            if e.response.status_code >= 500:
                raise ZOSServerError(f"Server error: {e.response.status_code}") from e
            else:
                raise ZOSClientError(f"Client error: {e.response.status_code}") from e
        except Exception as e:
            raise ZOSError(f"Request failed: {str(e)}") from e


    def list_parts(
        self,
        Bucket: str,
        Key: str,
        UploadId: str,
        PartNumberMarker: Optional[int] = None,
        MaxParts: Optional[int] = None,
        **kwargs,
    ) -> Dict[str, Any]:
        """List uploaded parts for an in-progress multipart upload."""
        query_params = [f"uploadId={UploadId}"]
        if PartNumberMarker is not None:
            query_params.append(f"part-number-marker={PartNumberMarker}")
        if MaxParts is not None:
            query_params.append(f"max-parts={MaxParts}")
        query = "&".join(query_params)
        url = f"{self._build_url(Bucket, Key)}?{query}"

        headers = self._get_headers("GET")
        signed_headers = self._sign_request("GET", url, headers)

        try:
            response = self.http_client.get(url, headers=signed_headers)
            response.raise_for_status()
            parts: List[Dict[str, Any]] = []
            root = ET.fromstring(response.text)
            for part_el in root.findall(".//{*}Part"):
                part_number = self._parse_xml_value(ET.tostring(part_el, encoding="unicode"), "PartNumber")
                etag = self._parse_xml_value(ET.tostring(part_el, encoding="unicode"), "ETag")
                size = self._parse_xml_value(ET.tostring(part_el, encoding="unicode"), "Size")
                last_modified = self._parse_xml_value(ET.tostring(part_el, encoding="unicode"), "LastModified")
                parts.append(
                    {
                        "PartNumber": int(part_number) if part_number else None,
                        "ETag": etag,
                        "Size": int(size) if size else None,
                        "LastModified": last_modified,
                    }
                )
            return {
                "Parts": parts,
                "IsTruncated": self._parse_xml_value(response.text, "IsTruncated") == "true",
                "NextPartNumberMarker": self._parse_xml_value(response.text, "NextPartNumberMarker"),
                "ResponseMetadata": {
                    "HTTPStatusCode": response.status_code,
                    "HTTPHeaders": dict(response.headers),
                },
            }
        except httpx.HTTPStatusError as e:
            if e.response.status_code >= 500:
                raise ZOSServerError(f"Server error: {e.response.status_code}") from e
            else:
                raise ZOSClientError(f"Client error: {e.response.status_code}") from e
        except Exception as e:
            raise ZOSError(f"Request failed: {str(e)}") from e


    def abort_multipart_upload(self, Bucket: str, Key: str, UploadId: str, **kwargs) -> Dict[str, Any]:
        """Abort an in-progress multipart upload."""
        url = f"{self._build_url(Bucket, Key)}?uploadId={UploadId}"
        headers = self._get_headers("DELETE")
        signed_headers = self._sign_request("DELETE", url, headers)
        try:
            response = self.http_client.delete(url, headers=signed_headers)
            response.raise_for_status()
            return {
                "ResponseMetadata": {
                    "HTTPStatusCode": response.status_code,
                    "HTTPHeaders": dict(response.headers),
                }
            }
        except httpx.HTTPStatusError as e:
            if e.response.status_code >= 500:
                raise ZOSServerError(f"Server error: {e.response.status_code}") from e
            else:
                raise ZOSClientError(f"Client error: {e.response.status_code}") from e
        except Exception as e:
            raise ZOSError(f"Request failed: {str(e)}") from e


    def list_multipart_uploads(
        self,
        Bucket: str,
        Prefix: str = "",
        Delimiter: str = "",
        KeyMarker: Optional[str] = None,
        UploadIdMarker: Optional[str] = None,
        MaxUploads: Optional[int] = None,
        **kwargs,
    ) -> Dict[str, Any]:
        """List ongoing multipart uploads in a bucket (boto3-compatible shape)."""
        params = ["uploads"]
        if Prefix:
            params.append(f"prefix={Prefix}")
        if Delimiter:
            params.append(f"delimiter={Delimiter}")
        if KeyMarker:
            params.append(f"key-marker={KeyMarker}")
        if UploadIdMarker:
            params.append(f"upload-id-marker={UploadIdMarker}")
        if MaxUploads is not None:
            params.append(f"max-uploads={MaxUploads}")

        query = "&".join(params)
        url = f"{self.endpoint}/{Bucket}?{query}"

        headers = self._get_headers("GET")
        signed_headers = self._sign_request("GET", url, headers)

        try:
            response = self.http_client.get(url, headers=signed_headers)
            response.raise_for_status()
            root = ET.fromstring(response.text)
            uploads: List[Dict[str, Any]] = []
            for upload_el in root.findall(".//{*}Upload"):
                key_text = self._parse_xml_value(ET.tostring(upload_el, encoding="unicode"), "Key")
                upload_id = self._parse_xml_value(ET.tostring(upload_el, encoding="unicode"), "UploadId")
                initiated = self._parse_xml_value(ET.tostring(upload_el, encoding="unicode"), "Initiated")
                storage_class = self._parse_xml_value(ET.tostring(upload_el, encoding="unicode"), "StorageClass")
                uploads.append(
                    {
                        "Key": key_text,
                        "UploadId": upload_id,
                        "Initiated": initiated,
                        "StorageClass": storage_class,
                    }
                )
            return {
                "Uploads": uploads,
                "IsTruncated": self._parse_xml_value(response.text, "IsTruncated") == "true",
                "KeyMarker": self._parse_xml_value(response.text, "KeyMarker"),
                "NextKeyMarker": self._parse_xml_value(response.text, "NextKeyMarker"),
                "UploadIdMarker": self._parse_xml_value(response.text, "UploadIdMarker"),
                "NextUploadIdMarker": self._parse_xml_value(response.text, "NextUploadIdMarker"),
                "ResponseMetadata": {
                    "HTTPStatusCode": response.status_code,
                    "HTTPHeaders": dict(response.headers),
                },
            }
        except httpx.HTTPStatusError as e:
            if e.response.status_code >= 500:
                raise ZOSServerError(f"Server error: {e.response.status_code}") from e
            else:
                raise ZOSClientError(f"Client error: {e.response.status_code}") from e
        except Exception as e:
            raise ZOSError(f"Request failed: {str(e)}") from e

    def upload_part_task(self, Bucket: str, Key: str, UploadId: str, data_queue: Queue, parts_queue: Queue, part_number: AtomicInteger, kwargs) -> Dict[str, Any]:
        while True:
            chunk = data_queue.get()
            if chunk is None:
                break
            number = part_number.increment_and_get()
            part_resp = self.upload_part(
                Bucket=Bucket,
                Key=Key,
                PartNumber=number,
                UploadId=UploadId,
                Body=chunk,
                ContentLength=len(chunk),
                **kwargs
            )
            etag = part_resp.get("ETag")
            if not etag:
                raise ZOSError(f"Missing ETag for part {number}")
            parts_queue.put({"ETag": etag, "PartNumber": number})
            time.sleep(0.001)
            data_queue.task_done()


    def upload_file(
        self,
        Filename: str,
        Bucket: str,
        Key: str,
        multipart_threshold: int = 8 * 1024 * 1024,
        multipart_chunksize: int = 8 * 1024 * 1024,
        **kwargs,
    ) -> Dict[str, Any]:
        """Upload a local file. Falls back to multipart when over threshold."""
        file_size = os.path.getsize(Filename)

        mu_kwargs = {}
        if "ContentType" in kwargs:
            mu_kwargs["ContentType"] = kwargs["ContentType"]
        if "Metadata" in kwargs:
            mu_kwargs["Metadata"] = kwargs["Metadata"]


        if file_size <= multipart_threshold:
            with open(Filename, "rb") as f:
                return self.put_object(Bucket=Bucket, Key=Key, Body=f.read(), **mu_kwargs)

        

        # Multipart path
        init_resp = self.create_multipart_upload(Bucket=Bucket, Key=Key, **mu_kwargs)
        upload_id = init_resp["UploadId"]
        parts: List[Dict[str, Union[str, int]]] = []

        if "max_concurrency" in kwargs and kwargs["max_concurrency"] > 1:
            max_concurrency = kwargs["max_concurrency"]
            data_queue = Queue()
            parts_queue = Queue()
            part_number = AtomicInteger(1)
            threads = []
            for i in range(max_concurrency):
                thread = Thread(target=self.upload_part_task, args=(Bucket, Key, upload_id, data_queue, parts_queue, part_number, kwargs))
                thread.start()
                threads.append(thread)
        else:
            max_concurrency = 1

        try:
            with open(Filename, "rb") as f:
                part_number = 1
                while True:
                    chunk = f.read(multipart_chunksize)
                    if not chunk:
                        break
                    if max_concurrency > 1:
                        data_queue.put(chunk)
                    else:
                        part_resp = self.upload_part(
                            Bucket=Bucket,
                            Key=Key,
                            PartNumber=part_number,
                            UploadId=upload_id,
                            Body=chunk,
                            ContentLength=len(chunk),
                        )
                        etag = part_resp.get("ETag")
                        if not etag:
                            raise ZOSError(f"Missing ETag for part {part_number}")
                        parts.append({"ETag": etag, "PartNumber": part_number})
                        part_number += 1


            if max_concurrency > 1:
                # Send stop signals to all threads
                for i in range(max_concurrency):
                    data_queue.put(None)
                # Wait for all threads to complete
                for thread in threads:
                    thread.join()
                # Collect all parts after threads complete
                while not parts_queue.empty():
                    part = parts_queue.get()
                    parts.append(part)

            return self.complete_multipart_upload(
                Bucket=Bucket,
                Key=Key,
                UploadId=upload_id,
                MultipartUpload={"Parts": parts},
            )
        except Exception as e:
            raise


    def delete_object(self, Bucket: str, Key: str, **kwargs) -> Dict[str, Any]:
        """Delete an object from S3.
        
        Args:
            Bucket: Bucket name
            Key: Object key
            **kwargs: Additional parameters
            
        Returns:
            Response dictionary
            
        Raises:
            ZOSError: If the request fails
        """
        url = self._build_url(Bucket, Key)
        headers = self._get_headers("DELETE")
        signed_headers = self._sign_request("DELETE", url, headers)
        
        try:
            response = self.http_client.delete(url, headers=signed_headers)
            response.raise_for_status()
            
            return {
                "ResponseMetadata": {
                    "HTTPStatusCode": response.status_code,
                    "HTTPHeaders": dict(response.headers)
                }
            }
        except httpx.HTTPStatusError as e:
            if e.response.status_code >= 500:
                raise ZOSServerError(f"Server error: {e.response.status_code}") from e
            else:
                raise ZOSClientError(f"Client error: {e.response.status_code}") from e
        except Exception as e:
            raise ZOSError(f"Request failed: {str(e)}") from e

    def list_objects_v2(self, Bucket: str, Prefix: str = "", **kwargs) -> Dict[str, Any]:
        """List objects in a bucket.
        
        Args:
            Bucket: Bucket name
            Prefix: Object key prefix
            **kwargs: Additional parameters
            
        Returns:
            Response dictionary containing object list
            
        Raises:
            ZOSError: If the request fails
        """
        # Build query parameters
        params = {}
        if Prefix:
            params["prefix"] = Prefix
        if "MaxKeys" in kwargs:
            params["max-keys"] = str(kwargs["MaxKeys"])
        if "ContinuationToken" in kwargs:
            params["continuation-token"] = kwargs["ContinuationToken"]
        
        # Build URL with query parameters
        base_url = f"{self.endpoint}/{Bucket}"
        if params:
            query_string = "&".join([f"{k}={v}" for k, v in params.items()])
            url = f"{base_url}?{query_string}"
        else:
            url = base_url
        
        headers = self._get_headers("GET")
        signed_headers = self._sign_request("GET", url, headers)
        
        try:
            response = self.http_client.get(url, headers=signed_headers)
            response.raise_for_status()
            
            # Parse XML response (simplified)
            content = response.text
            # In a real implementation, you'd parse the XML properly
            # For now, return a basic structure
            
            return {
                "Contents": [],  # Would contain parsed object info
                "ResponseMetadata": {
                    "HTTPStatusCode": response.status_code,
                    "HTTPHeaders": dict(response.headers)
                }
            }
        except httpx.HTTPStatusError as e:
            if e.response.status_code >= 500:
                raise ZOSServerError(f"Server error: {e.response.status_code}") from e
            else:
                raise ZOSClientError(f"Client error: {e.response.status_code}") from e
        except Exception as e:
            raise ZOSError(f"Request failed: {str(e)}") from e

    def _parse_metadata(self, headers: Dict[str, str]) -> Dict[str, str]:
        """Parse metadata from response headers.
        
        Args:
            headers: Response headers
            
        Returns:
            Dictionary of metadata
        """
        metadata = {}
        for key, value in headers.items():
            if key.lower().startswith("x-amz-meta-"):
                metadata_key = key[11:]  # Remove "x-amz-meta-" prefix
                metadata[metadata_key] = value
        return metadata

    def _parse_xml_value(self, xml_content: str, target_tag: str) -> Optional[str]:
        """Extract the text of the first XML element whose tag endswith target_tag."""
        try:
            root = ET.fromstring(xml_content)
            for element in root.iter():
                if element.tag.endswith(target_tag):
                    return element.text
        except ET.ParseError:
            return None
        return None

    def put_access_policy(self, Bucket: str, key: str, Policy: str, **kwargs) -> Dict[str, Any]:
        """Set object ACL synchronously.

        Supports both canned ACLs via the ``x-amz-acl`` header and full ACL
        policies by sending the ACL XML in the request body.

        Args:
            Bucket: Bucket name
            key: Object key
            Policy: Either a canned ACL name (e.g. "private", "public-read")
                or a full ACL XML string per S3 ``PutObjectAcl``.
            **kwargs: Additional parameters
        """
        # Target the ACL subresource
        url = f"{self._build_url(Bucket, key)}?acl"

        # Determine whether this is a canned ACL or a full ACL XML
        canned_acls = {
            "private",
            "public-read",
            "public-read-write",
            "authenticated-read",
            "bucket-owner-read",
            "bucket-owner-full-control",
            "log-delivery-write",
        }

        is_canned = Policy in canned_acls
        body_bytes = None if is_canned else Policy.encode("utf-8")

        # Prepare headers; attach x-amz-acl for canned ACL
        headers = self._get_headers("PUT", body_bytes)
        if is_canned:
            headers["x-amz-acl"] = Policy

        signed_headers = self._sign_request("PUT", url, headers, body_bytes)

        try:
            response = self.http_client.put(
                url,
                headers=signed_headers,
                content=b"" if body_bytes is None else body_bytes,
            )
            response.raise_for_status()
            return {
                "ResponseMetadata": {
                    "HTTPStatusCode": response.status_code,
                    "HTTPHeaders": dict(response.headers),
                }
            }
        except httpx.HTTPStatusError as e:
            if e.response.status_code >= 500:
                raise ZOSServerError(f"Server error: {e.response.status_code}") from e
            else:
                raise ZOSClientError(f"Client error: {e.response.status_code}") from e
        except Exception as e:
            raise ZOSError(f"Request failed: {str(e)}") from e

    def get_access_policy(self, Bucket: str, key: str, **kwargs) -> Dict[str, Any]:
        """Get object ACL (``?acl``) synchronously.

        Returns the raw ACL XML in ``Body`` along with response metadata.

        Args:
            Bucket: Bucket name
            key: Object key
            **kwargs: Additional parameters
        """
        url = f"{self._build_url(Bucket, key)}?acl"
        headers = self._get_headers("GET")
        signed_headers = self._sign_request("GET", url, headers)
        try:
            response = self.http_client.get(url, headers=signed_headers)
            response.raise_for_status()
            return {
                "Body": response.text,
                "ResponseMetadata": {
                    "HTTPStatusCode": response.status_code,
                    "HTTPHeaders": dict(response.headers),
                }
            }
        except httpx.HTTPStatusError as e:
            if e.response.status_code >= 500:
                raise ZOSServerError(f"Server error: {e.response.status_code}") from e
            else:
                raise ZOSClientError(f"Client error: {e.response.status_code}") from e
        except Exception as e:
            raise ZOSError(f"Request failed: {str(e)}") from e