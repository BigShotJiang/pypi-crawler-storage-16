import argparse
import os
import sys
from typing import List, Dict, Union

from ctyun_zos_sdk.async_client import AsyncZOSClient
from ctyun_zos_sdk.exceptions import ZOSError


async def multipart_upload(
    client: AsyncZOSClient,
    bucket: str,
    key: str,
    filename: str,
    chunk_size: int = 8 * 1024 * 1024,
    max_concurrency: int = 1,
) -> Dict[str, Union[str, Dict]]:
    """Upload a file using multipart APIs."""
    init_resp = await client.create_multipart_upload(Bucket=bucket, Key=key)
    upload_id = init_resp["UploadId"]
    parts: List[Dict[str, Union[int, str]]] = []

    with open(filename, "rb") as fh:
        part_no = 1
        while True:
            chunk = fh.read(chunk_size)
            if not chunk:
                break
            part_resp = await client.upload_part(
                Bucket=bucket,
                Key=key,
                PartNumber=part_no,
                UploadId=upload_id,
                Body=chunk,
                ContentLength=len(chunk),
            )
            etag = part_resp.get("ETag")
            if not etag:
                raise ZOSError(f"Missing ETag for part {part_no}")
            parts.append({"PartNumber": part_no, "ETag": etag})
            part_no += 1

    return await client.complete_multipart_upload(
        Bucket=bucket,
        Key=key,
        UploadId=upload_id,
        MultipartUpload={"Parts": parts},
    )


async def upload_file(
    client: AsyncZOSClient,
    bucket: str,
    key: str,
    filename: str,
    chunk_size: int = 8 * 1024 * 1024,
    max_concurrency: int = 1,
) -> Dict[str, Union[str, Dict]]:
    """Upload a file."""
    return await client.upload_file(
        Filename=filename,
        Bucket=bucket,
        Key=key,
        multipart_chunksize=chunk_size,
        max_concurrency=max_concurrency,
    )

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Multipart upload test for CTyun ZOS.")
    parser.add_argument("--file", required=True, help="Local file path to upload.")
    parser.add_argument("--key", required=True, help="Object key to use in bucket.")
    parser.add_argument("--concurrency", '-c', type=int, default=1, help="Maximum concurrency for multipart upload.")
    parser.add_argument(
        "--chunk-size",
        type=int,
        default=8 * 1024 * 1024,
        help="Chunk size in bytes (default 8MB).",
    )
    return parser.parse_args()


async def main() -> None:
    args = parse_args()

    access_key = os.getenv("ZOS_AK")
    secret_key = os.getenv("ZOS_SK")
    bucket = os.getenv("ZOS_BUCKET")
    endpoint = os.getenv("ZOS_ENDPOINT")

    missing = [name for name, val in [("ZOS_AK", access_key), ("ZOS_SK", secret_key), ("ZOS_BUCKET", bucket), ("ZOS_ENDPOINT", endpoint)] if not val]
    if missing:
        sys.stderr.write(f"Missing environment variables: {', '.join(missing)}\n")
        sys.exit(1)

    client = AsyncZOSClient(
        access_key=access_key,
        secret_key=secret_key,
        region="cn",  # region used only for signing; adjust if needed
        endpoint=endpoint,
    )

    resp = await upload_file(
        client=client,
        bucket=bucket,
        key=args.key,
        filename=args.file,
        chunk_size=args.chunk_size,
        max_concurrency=args.concurrency,
    )
    print("Upload complete:", resp)


if __name__ == "__main__":
    import asyncio
    
    asyncio.run(main()) 

