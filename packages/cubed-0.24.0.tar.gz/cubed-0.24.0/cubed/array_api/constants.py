from cubed.backend_array_api import namespace as nxp

e = nxp.e
inf = nxp.inf
nan = nxp.nan
newaxis = nxp.newaxis
pi = nxp.pi
