# SPDX-FileCopyrightText: Copyright (c) 2018-2021, NVIDIA CORPORATION.
# SPDX-License-Identifier: Apache-2.0
