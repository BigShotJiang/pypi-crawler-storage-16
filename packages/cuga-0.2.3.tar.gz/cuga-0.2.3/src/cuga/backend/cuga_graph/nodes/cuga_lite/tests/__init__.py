"""Tests for CUGA Lite mode."""
