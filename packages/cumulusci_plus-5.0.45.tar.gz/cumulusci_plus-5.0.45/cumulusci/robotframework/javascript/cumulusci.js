// This structure will be filled in when SalesforcePlaywright.py is
// loaded by the robot task
module.exports = { project_config: {}, org: {} };
exports.__esModule = true;
