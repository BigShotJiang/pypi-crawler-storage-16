from ._array import CUQIarray
