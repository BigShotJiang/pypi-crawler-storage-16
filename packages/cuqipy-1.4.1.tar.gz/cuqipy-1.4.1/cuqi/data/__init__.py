from ._data import (
    satellite,
    astronaut,
    camera,
    cat,
    cookie,
    grains,
    shepp_logan,
    threephases,
    p_power,
    rgb2gray,
    imresize,
)
