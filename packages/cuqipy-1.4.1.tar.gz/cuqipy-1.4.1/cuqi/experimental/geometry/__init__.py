from ._productgeometry import _ProductGeometry
