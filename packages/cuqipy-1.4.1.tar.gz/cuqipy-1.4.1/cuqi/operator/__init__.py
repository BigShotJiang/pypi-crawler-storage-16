from ._operator import (
    Operator,
    FirstOrderFiniteDifference,
    SecondOrderFiniteDifference,
    PrecisionFiniteDifference
)
