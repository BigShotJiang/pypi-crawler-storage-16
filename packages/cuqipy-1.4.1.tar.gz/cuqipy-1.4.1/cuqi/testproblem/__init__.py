from ._testproblem import (
    _Deblur,
    Deconvolution1D,
    Deconvolution2D,
    Poisson1D,
    Heat1D,
    Abel1D,
    _Deconv_1D,
    WangCubic,
    _getCirculantMatrix,
    _getExactSolution
)
