"""DEPRECATED: Use curllm_core.dom instead"""
from curllm_core.dom import *
