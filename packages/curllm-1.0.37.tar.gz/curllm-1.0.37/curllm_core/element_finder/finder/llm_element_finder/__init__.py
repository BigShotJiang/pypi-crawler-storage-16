"""
Atomized access to llm_element_finder
"""

from .llm_element_finder import LLMElementFinder

__all__ = ['LLMElementFinder']
