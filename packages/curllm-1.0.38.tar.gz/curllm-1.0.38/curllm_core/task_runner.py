"""DEPRECATED: Use curllm_core.running instead"""
from curllm_core.running.runner import run_task, _planner_cycle
__all__ = ['run_task', '_planner_cycle']
