"""
Atomized access to task_validator
"""

from .task_validator import TaskValidator

__all__ = ['TaskValidator']
