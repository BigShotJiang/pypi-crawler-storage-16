"""Specs extraction functions."""
