"""
Deprecated modules - scheduled for removal.

These modules are no longer actively used and have been
archived here for reference.

DO NOT import from this package in new code.
"""
