"""DEPRECATED: Use curllm_core.detection instead"""
from curllm_core.detection import DOMNode, DynamicPatternDetector, GenericFieldExtractor, dynamic_extract
__all__ = ['DOMNode', 'DynamicPatternDetector', 'GenericFieldExtractor', 'dynamic_extract']
