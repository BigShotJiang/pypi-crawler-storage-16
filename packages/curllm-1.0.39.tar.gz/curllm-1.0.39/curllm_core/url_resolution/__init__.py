"""
URL Resolution module - Smart URL validation and navigation
"""

from curllm_core.url_resolution.resolver import UrlResolver

__all__ = ['UrlResolver']
