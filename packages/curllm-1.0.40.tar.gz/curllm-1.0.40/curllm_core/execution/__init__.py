"""
Execution module - Main browser automation executor with LLM support
"""

from curllm_core.execution.executor import CurllmExecutor

__all__ = ['CurllmExecutor']
