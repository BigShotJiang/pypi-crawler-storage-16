"""DEPRECATED: Use curllm_core.extraction package instead"""
from curllm_core.extraction import *
