"""DEPRECATED: Use curllm_core.result_validation instead"""
from curllm_core.result_validation import ValidationLevel, ValidationResult, ResultValidator, validate_form_result, validate_strict
__all__ = ['ValidationLevel', 'ValidationResult', 'ResultValidator', 'validate_form_result', 'validate_strict']
