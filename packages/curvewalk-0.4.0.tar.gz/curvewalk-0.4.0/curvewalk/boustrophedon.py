from .lawnmower import lawnmower as boustrophedon  # noqa: F401
from .lawnmower import inverse_lawnmower as inverse_boustrophedon  # noqa: F401
