"""
This package implements various JDFTx Jobs and Error Handlers.
Used Cp2kJob developed by Nick Winner as a template.
"""
