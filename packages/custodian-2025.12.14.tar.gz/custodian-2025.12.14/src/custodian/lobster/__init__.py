"""This package implements Lobster Jobs and Error Handlers."""

__author__ = "Janine George, Guido Petretto"
__version__ = "0.1"
__maintainer__ = "Janine George, Guido Petretto"
__email__ = "janine.george@uclouvain.be"
__status__ = "Production"
__date__ = "27/4/20"
