# -- coding: utf-8 --
# @Time : 2022/11/15
# @Author : ykk648
# @Project : https://github.com/ykk648/cv2box
from .cv_encrypt import CVEncrypt
