"""Tests for CV Resume Builder MCP."""
