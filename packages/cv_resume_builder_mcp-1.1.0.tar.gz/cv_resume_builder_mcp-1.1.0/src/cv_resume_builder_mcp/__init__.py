"""CV Resume Builder MCP - AI-powered CV and resume builder using Model Context Protocol."""

__version__ = "1.0.0"
