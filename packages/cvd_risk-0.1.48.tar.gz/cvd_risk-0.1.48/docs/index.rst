CVD Risk Calculator Documentation
==================================

Welcome to the CVD Risk Calculator documentation.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installation
   quickstart
   api/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

