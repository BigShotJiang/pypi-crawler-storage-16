"""ASCVD risk prediction model."""

from .ascvd import ASCVD

__all__ = ["ASCVD"]
