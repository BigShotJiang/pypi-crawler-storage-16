"""ASSIGN risk prediction model."""

from .assign import ASSIGN

__all__ = ["ASSIGN"]
