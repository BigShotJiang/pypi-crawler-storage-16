from .cambridge import Cambridge

__all__ = ["Cambridge"]
