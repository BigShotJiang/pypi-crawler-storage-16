from .cha2ds2_vasc import CHA2DS2_VASc

__all__ = ["CHA2DS2_VASc"]
