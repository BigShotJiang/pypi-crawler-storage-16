"""DIAL2 risk prediction model."""

from .dial2 import DIAL2

__all__ = ["DIAL2"]
