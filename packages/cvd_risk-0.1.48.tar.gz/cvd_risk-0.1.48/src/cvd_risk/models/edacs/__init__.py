"""EDACS risk prediction model."""

from .edacs import EDACS

__all__ = ["EDACS"]
