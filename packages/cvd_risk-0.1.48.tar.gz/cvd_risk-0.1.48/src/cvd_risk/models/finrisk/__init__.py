from .finrisk import FINRISK

__all__ = ["FINRISK"]
