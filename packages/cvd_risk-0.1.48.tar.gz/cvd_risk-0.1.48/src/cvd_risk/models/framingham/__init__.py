"""Framingham risk prediction model."""

from .framingham import Framingham

__all__ = ["Framingham"]
