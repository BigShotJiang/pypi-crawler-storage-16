"""Globorisk risk prediction model."""

from .globorisk import Globorisk

__all__ = ["Globorisk"]
