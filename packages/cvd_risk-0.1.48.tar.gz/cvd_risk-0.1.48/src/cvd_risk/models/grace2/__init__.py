"""GRACE2 risk prediction model."""

from .grace2 import GRACE2

__all__ = ["GRACE2"]
