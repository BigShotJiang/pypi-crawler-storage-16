"""HEART risk prediction model."""

from .heart import HEART

__all__ = ["HEART"]
