"""LifeCVD2 cardiovascular risk model package."""

from .lifecvd2 import LifeCVD2

__all__ = ["LifeCVD2"]

