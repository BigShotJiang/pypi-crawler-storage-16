from .malaysian_cvd import Malaysian_CVD

__all__ = ["Malaysian_CVD"]
