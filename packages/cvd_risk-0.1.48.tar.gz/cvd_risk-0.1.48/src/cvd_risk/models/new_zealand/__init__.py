from .new_zealand import NewZealand

__all__ = ["NewZealand"]
