from .predict import PREDICT

__all__ = ["PREDICT"]
