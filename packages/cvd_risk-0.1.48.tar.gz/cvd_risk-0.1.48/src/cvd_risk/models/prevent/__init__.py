"""PREVENT cardiovascular risk model package."""

from .prevent import Prevent

__all__ = ["Prevent"]

