"""QRISK2 cardiovascular risk model package."""

from .qrisk2 import QRISK2

__all__ = ["QRISK2"]

