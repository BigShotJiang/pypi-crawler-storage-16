"""QRISK3 risk prediction model."""

from .qrisk3 import QRISK3

__all__ = ["QRISK3"]
