"""SCORE cardiovascular risk model package."""

from .score import SCORE

__all__ = ["SCORE"]

