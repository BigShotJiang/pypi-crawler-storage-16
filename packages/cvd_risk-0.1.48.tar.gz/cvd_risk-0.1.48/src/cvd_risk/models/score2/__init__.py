"""SCORE2 risk prediction model."""

from .score2 import SCORE2

__all__ = ["SCORE2"]
