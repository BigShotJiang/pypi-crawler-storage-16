"""SCORE2-Asia CKD risk prediction model."""

from .score2asia import SCORE2AsiaCKD

__all__ = ["SCORE2AsiaCKD"]
