"""SCORE2-CKD cardiovascular risk model package."""

from .score2ckd import SCORE2CKD

__all__ = ["SCORE2CKD"]

