"""SCORE2-DM cardiovascular risk model package."""

from .score2dm import SCORE2DM

__all__ = ["SCORE2DM"]

