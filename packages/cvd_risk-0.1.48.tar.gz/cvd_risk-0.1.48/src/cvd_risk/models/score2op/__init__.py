"""SCORE2-OP cardiovascular risk model package."""

from .score2op import SCORE2OP

__all__ = ["SCORE2OP"]

