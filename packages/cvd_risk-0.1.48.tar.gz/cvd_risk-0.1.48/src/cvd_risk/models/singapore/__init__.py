from .singapore import Singapore

__all__ = ["Singapore"]
