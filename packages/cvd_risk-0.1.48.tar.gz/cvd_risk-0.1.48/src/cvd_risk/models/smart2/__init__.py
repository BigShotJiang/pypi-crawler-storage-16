"""SMART2 risk prediction model."""

from .smart2 import SMART2

__all__ = ["SMART2"]
