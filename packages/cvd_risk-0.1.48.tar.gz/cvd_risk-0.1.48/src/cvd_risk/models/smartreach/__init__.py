"""SMART-REACH cardiovascular risk model package."""

from .smartreach import SMART_REACH

__all__ = ["SMART_REACH"]

