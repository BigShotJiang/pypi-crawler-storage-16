"""TIMI risk prediction model."""

from .timi import TIMI

__all__ = ["TIMI"]
