"""WHO risk prediction model."""

from .who import WHO

__all__ = ["WHO"]
