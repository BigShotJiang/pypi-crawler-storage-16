"""Utility functions for CVD risk calculator."""

