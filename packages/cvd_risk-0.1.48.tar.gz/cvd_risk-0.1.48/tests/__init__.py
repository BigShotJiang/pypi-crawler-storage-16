"""Test suite for CVD risk calculator."""

