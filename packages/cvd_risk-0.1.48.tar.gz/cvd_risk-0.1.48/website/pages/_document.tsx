import { Html, Head, Main, NextScript } from 'next/document'

export default function Document() {
  return (
    <Html lang="en">
      <Head>
        <meta name="description" content="Production-grade Python package for cardiovascular disease risk calculation" />
        <meta name="keywords" content="cardiovascular, risk assessment, epidemiology, clinical decision support" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <body>
        <Main />
        <NextScript />
      </body>
    </Html>
  )
}

