"""
Report package initializer.
"""

