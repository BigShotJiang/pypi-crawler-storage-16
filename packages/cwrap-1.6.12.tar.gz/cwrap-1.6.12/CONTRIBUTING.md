# Contributing
_cwrap_ is deprecated and will not see any new features. However, issues and critical bug fixed are accepted still.

We require a unit tests for bug fix pull-requests.
