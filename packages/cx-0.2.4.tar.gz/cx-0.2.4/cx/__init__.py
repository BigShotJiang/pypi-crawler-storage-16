"""
Compute nearest neighbor distances along the coast with a view angle.
"""

__version__ = "0.2.4"
