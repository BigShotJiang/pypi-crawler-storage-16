def say_hello():
    print("Hello from my_package!")
def say_hello2():
    print("Hello from my_package!")

if __name__ == '__main__':
    say_hello()