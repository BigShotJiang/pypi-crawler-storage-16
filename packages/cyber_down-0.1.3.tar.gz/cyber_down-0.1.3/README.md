# cyber_down
A tool that uses parallel segmented downloading to speed up downloads.
