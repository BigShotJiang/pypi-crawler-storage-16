#!/usr/bin/env python3

import sys

from Cython.Debugger import Cygdb as cygdb

if __name__ == '__main__':
    cygdb.main()
