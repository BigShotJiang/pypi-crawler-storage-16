# __init__.py
# version of the czitools package
__version__ = "0.11.1"
