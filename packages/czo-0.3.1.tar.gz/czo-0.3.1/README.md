# 测试工具库

```shell
pip install czo
```

```python
from czo import *
```
