"""
Daemons Engine - A modern MUD engine.

Headless game engine for real-time, text-based multiplayer worlds.
"""

__version__ = "0.1.15"
__all__ = ["__version__"]
