"""
Social commands module - Groups, Tells, Follows, Yells (Phase 10.1)
"""
