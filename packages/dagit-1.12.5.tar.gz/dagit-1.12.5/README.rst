============
Dagster UI
============

Usage
~~~~~
Eg in dagster_examples

.. code-block:: sh

  dagit -p 3333

Running dev ui:

.. code-block:: sh
  NEXT_PUBLIC_BACKEND_ORIGIN="http://localhost:3333" yarn start

