from .repository import cereal_repository as cereal_repository
