# dagster-dask

The docs for `dagster-dask` can be found
[here](https://docs.dagster.io/api/python-api/libraries/dagster-dask).
