"""Claude Code SDK integration subsystem for branch scaffolding."""
