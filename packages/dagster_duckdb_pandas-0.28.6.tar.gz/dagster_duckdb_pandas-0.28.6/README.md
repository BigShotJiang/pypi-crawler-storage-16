# dagster-duckdb-pandas

The docs for `dagster-duckdb-pandas` can be found
[here](https://docs.dagster.io/api/python-api/libraries/dagster-duckdb).
