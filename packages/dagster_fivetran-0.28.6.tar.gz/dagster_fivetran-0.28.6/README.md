# dagster-fivetran

The docs for `dagster-fivetran` can be found
[here](https://docs.dagster.io/api/python-api/libraries/dagster-fivetran).
