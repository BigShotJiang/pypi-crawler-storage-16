# dagster-shared

The docs for `dagster-shared ` can be found
[here](https://docs.dagster.io/_apidocs/libraries/dagster-shared).
