from .discreate_finite_automaton import *
from .turing_machine import *
