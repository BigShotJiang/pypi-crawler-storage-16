from .encoding import *
from .lossy import *
from .lossless import *