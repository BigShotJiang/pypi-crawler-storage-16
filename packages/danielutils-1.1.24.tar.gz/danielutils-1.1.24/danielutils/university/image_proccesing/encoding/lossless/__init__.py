from .lossless_encoding import *
from .run_length import *
from .huffman import *
from .lzw import *
