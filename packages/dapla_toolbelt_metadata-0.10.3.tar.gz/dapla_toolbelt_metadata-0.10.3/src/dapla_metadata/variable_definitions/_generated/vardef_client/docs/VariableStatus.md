# VariableStatus

Life cycle status of a variable definition.

## Enum

* `DRAFT` (value: `'DRAFT'`)

* `PUBLISHED_INTERNAL` (value: `'PUBLISHED_INTERNAL'`)

* `PUBLISHED_EXTERNAL` (value: `'PUBLISHED_EXTERNAL'`)

* `DEPRECATED` (value: `'DEPRECATED'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


