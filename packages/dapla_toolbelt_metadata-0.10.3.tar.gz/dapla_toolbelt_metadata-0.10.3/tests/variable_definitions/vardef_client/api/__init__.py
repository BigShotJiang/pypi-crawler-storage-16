"""Test suite for generated vardef_client api."""
