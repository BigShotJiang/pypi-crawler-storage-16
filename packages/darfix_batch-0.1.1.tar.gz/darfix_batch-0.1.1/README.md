# darfix_batch

_darfix_batch_ is a GUI application to help users with [darfix](https://gitlab.esrf.fr/XRD/darfix) batch processing. 

## Getting started

See https://xrd.gitlab-pages.esrf.fr/darfix_batch/