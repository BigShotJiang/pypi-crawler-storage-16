from typing import Any, Dict

UnknownType = Any  # type:ignore

KeyValuePairDict = Dict[str, UnknownType]
