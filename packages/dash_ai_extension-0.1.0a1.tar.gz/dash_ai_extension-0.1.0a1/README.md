# Dash AI Chat

AI-powered chat assistant for Dash development - an integrated dev tools extension.

## Overview

Dash AI Chat provides an LLM-powered assistant directly within your Dash development environment. It can:

- **Read files**: View any project file content with intelligent filtering for large files
- **Edit files**: Stage and apply file changes with full review before committing
- **Run commands**: Execute shell commands in your project directory
- **View logs**: Access backend and frontend logs from your running Dash app
- **Search files**: Find patterns across your codebase
- **List structure**: Explore project directory structure

## Installation

```bash
pip install dash-ai-extension
```

Or install from source:

```bash
pip install -e .
```

With [uv](https://docs.astral.sh/uv/):

```bash
uv add dash-ai-extension
```

After some changes you may need to run `npm run build` in the dash_ai_chat_component folder and `uv sync --reinstall-package dash-ai-extension` in the folder where you added the chat extension to start with.

## Usage

Once installed, the extension automatically integrates with Dash dev tools when running your Dash application in development mode:

```python
import dash
from dash import html

app = dash.Dash(__name__)
app.layout = html.Div("Hello, Dash!")

if __name__ == "__main__":
    app.run(debug=True)  # Dev tools enabled
```

Look for the "Dash Chat" button in the dev tools sidebar.

### Authentication

On first use, you'll be prompted to authenticate via OAuth device flow:
1. Click "Sign In" in the chat modal
2. A browser window opens to complete authentication
3. Once authenticated, your session is saved locally

### Staged Changes Workflow

The assistant stages file edits for your review before applying them:

1. Ask the assistant to make changes to your code
2. Review staged changes in the yellow panel below the chat
3. Expand individual changes to see the diff
4. Click "Apply All" to write changes to disk, or "Clear" to discard
5. Use the revert button on individual changes if needed

Changes are never written automatically - you always have control.

## Features

### Real-time Streaming

Watch the assistant's progress in real-time:
- See tool calls as they happen (file reads, edits, commands)
- View tool results immediately
- Final assistant messages appear after processing completes

### State Persistence

Your chat session is automatically saved and restored:
- Conversation history persists across app restarts
- Staged changes are preserved
- State saved to `.dash-chat-state.json` in your project directory

### Intelligent File Handling

For large files, the assistant uses a two-stage approach:
1. Fast pre-filtering identifies relevant sections
2. Only relevant content is processed by the main model
3. Targeted find-and-replace for edits (not full file rewrites)

## Development

### Building the Frontend

```bash
cd dash_ai_chat_component
npm install
npm run build
```

For development with hot reload:

```bash
npm run dev
```

After making Python changes, reinstall the package:

```bash
# With pip
pip install -e .

# With uv
uv sync --reinstall-package dash-ai-chat
```

### Running Tests

```bash
pytest
```

### Code Quality

```bash
# Lint Python
ruff check .

# Format Python
ruff format .

# Type check Python
pyright

# Type check TypeScript
cd dash_ai_chat_component && npm run typecheck

# Format TypeScript
cd dash_ai_chat_component && npm run format
```

## Architecture

### Backend (Python)

- `_chat_agent.py`: Core agent with file/command tools, Haiku pre-filtering
- `_chat_rpc.py`: RPC handler with SSE streaming support
- `_llm_client.py`: Async LLM API client with prompt caching
- `_oauth.py`: OAuth device authorization flow
- `_devtool_hooks.py`: Dash hooks for dev tools integration

### Frontend (TypeScript/React)

- `Chat.tsx`: Main orchestration component with streaming state
- `ChatMessages.tsx`: Message history with ephemeral streaming display
- `ChatInput.tsx`: User input with auto-resize
- `StagedChangesPanel.tsx`: File change review UI with diff view
- `chatClient.ts`: RPC client with SSE streaming support

### Communication

- Standard RPC via POST to `/_dash_ai_chat`
- SSE streaming via POST to `/_dash_ai_chat_stream` for real-time updates
- Events match conversation history format for consistency

## Security

- **Path validation**: All file operations are restricted to the project directory
- **Command filtering**: Dangerous shell commands are blocked
- **Secure credentials**: OAuth tokens stored with restricted file permissions
- **Token refresh**: Automatic token refresh on 401 responses
- **Directory filtering**: Skips node_modules, .git, __pycache__, etc.

## Releasing

To create a new release:

1. **Update version in `pyproject.toml`:**
   ```toml
   version = "1.0.0"
   ```

2. **Create and push a version tag after merging the update to `pyproject.toml`:**
   ```bash
   git tag v1.0.0
   git push origin v1.0.0
   ```

3. **Draft release created automatically:** The `draft-release` workflow builds the package and creates a draft GitHub release with artifacts.

4. **Edit and publish:** Go to [GitHub Releases](https://github.com/plotly/dash-ai-extension/releases), edit the draft release notes, and click "Publish release".

5. **PyPI publish automatic:** Once published, the `publish-pypi` workflow automatically publishes the package to PyPI using trusted publishing.

