"""Cloud environment configuration management for Dash AI Chat."""


class CloudConfig:
    """Manages cloud configuration for Dash AI Chat."""

    def get_oauth_client_id(self) -> str:
        """Get OAuth client ID."""
        return "client_01JBHED1ZCBXX7811MDKFJ74SG"

    def get_api_base_url(self) -> str:
        """Get API base URL."""
        return "cloud.plotly.com"

    def get_amplitude_api_key(self) -> str:
        """Get Amplitude API key for analytics."""
        return "b0e75156e6441fc86ef59b13f1e1d091"

    def validate(self) -> bool:
        """Validate cloud configuration setup."""
        return True


# Global instance
cloud_config = CloudConfig()
