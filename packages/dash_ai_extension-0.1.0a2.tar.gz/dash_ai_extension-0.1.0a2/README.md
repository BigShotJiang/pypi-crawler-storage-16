# Dash AI Chat

AI-powered chat assistant for Dash development - an integrated dev tools extension.

## Overview

Dash AI Chat brings an intelligent AI assistant directly into your Dash development environment. Chat with an AI that can read your code, make changes, run commands, and help you build faster.

### Key Capabilities

- **Code Understanding**: Ask questions about your codebase and get intelligent answers
- **File Editing**: Request changes and review them before applying
- **Command Execution**: Run shell commands through the assistant
- **Log Access**: View backend and frontend logs from your running app
- **Code Search**: Find patterns and navigate your project structure

## Installation

Install via pip:

```bash
pip install dash-ai-extension
```

Or with [uv](https://docs.astral.sh/uv/):

```bash
uv add dash-ai-extension
```

## Quick Start

Once installed, the extension automatically integrates with Dash dev tools:

```python
import dash
from dash import html

app = dash.Dash(__name__)
app.layout = html.Div("Hello, Dash!")

if __name__ == "__main__":
    app.run(debug=True)  # Dev tools enabled
```

Look for the "Dash Chat" button in the dev tools sidebar.

### First-Time Setup

On first use, you'll authenticate via Plotly Cloud:
1. Click "Sign In" in the chat modal
2. Complete authentication in the browser window
3. Your session is saved locally for future use

## How It Works

### Safe Code Changes

The assistant never writes files automatically. Instead:

1. Ask the assistant to make changes to your code
2. Review staged changes in the panel below the chat
3. Expand individual changes to see the diff
4. Click "Apply All" to write changes, or "Clear" to discard
5. Revert individual changes if needed

You're always in control.

### Real-Time Feedback

Watch the assistant work in real-time:
- See file reads, edits, and commands as they happen
- View results immediately
- Understand the assistant's reasoning

### Session Persistence

Your chat history and staged changes are automatically saved to `.dash-chat-state.json` in your project directory. Everything persists across app restarts.

## Features

- **Intelligent file handling**: Large files are pre-filtered to relevant sections for faster responses
- **Targeted edits**: Uses find-and-replace instead of full file rewrites
- **Security built-in**: Path validation, command filtering, and restricted file operations
- **SSE streaming**: Real-time updates as the assistant works

## License

Copyright (c) 2025 Plotly, Inc. All rights reserved.

This software is proprietary and confidential. See [LICENSE](LICENSE) for details.

