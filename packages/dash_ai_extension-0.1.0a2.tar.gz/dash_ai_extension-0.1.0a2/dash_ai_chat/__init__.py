"""Dash AI Chat - AI-powered chat assistant for Dash development."""

__version__ = "0.1.0"

from .exceptions import (
    AgentError,
    APIError,
    AuthenticationError,
    ChatError,
    CloudConfigError,
    ConfigurationError,
    CredentialError,
    DashAIChatError,
    EnvironmentError,
    LLMError,
    NetworkError,
    OAuthClientError,
    TimeoutError,
    TokenError,
)

__all__ = [
    "__version__",
    "DashAIChatError",
    "AuthenticationError",
    "ConfigurationError",
    "OAuthClientError",
    "TokenError",
    "CredentialError",
    "CloudConfigError",
    "EnvironmentError",
    "APIError",
    "NetworkError",
    "TimeoutError",
    "ChatError",
    "LLMError",
    "AgentError",
]
