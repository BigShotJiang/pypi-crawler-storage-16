# Copyright (c) Alibaba, Inc. and its affiliates.

from .application import Application

__all__ = [Application]
