# Copyright (c) Alibaba, Inc. and its affiliates.

__version__ = '1.25.3'
