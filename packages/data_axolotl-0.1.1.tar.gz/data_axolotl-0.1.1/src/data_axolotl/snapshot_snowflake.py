import snowflake.connector

## class TableSnapshot

#def scan_database(cur: snowflake.connector.cursor, options: SnowflakeOptions):
    #cur.execute(f'SHOW TERSE tables;')
    #results = cur.fetchall()
    #for r in results: 
        #print(f'{r}')

