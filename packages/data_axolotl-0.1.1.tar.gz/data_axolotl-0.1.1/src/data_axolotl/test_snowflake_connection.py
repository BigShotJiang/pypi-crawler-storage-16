import pytest

class TestSnowflakeConn:
    pass

    def test_generate_queries(self):
        pass



"""
todolist
## low hanging fruit
- move utils to utils

## snowflakeConn

1. mock conn
2. patch that into SnowflakeConn,  
3. tests




"""