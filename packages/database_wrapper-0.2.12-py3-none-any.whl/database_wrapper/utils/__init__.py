from .dataclass_addons import ignore_unknown_kwargs

__all__ = [
    "ignore_unknown_kwargs",
]
