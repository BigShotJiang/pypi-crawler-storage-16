# The name used in the model_type argument
MODEL_TYPE = "databricks-agent"
