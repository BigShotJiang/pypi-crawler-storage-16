# Update this when publishing a new version
VERSION = "1.9.0"
