if __name__ == "__main__":
    import sys

    from .cli import main

    sys.exit(main())
