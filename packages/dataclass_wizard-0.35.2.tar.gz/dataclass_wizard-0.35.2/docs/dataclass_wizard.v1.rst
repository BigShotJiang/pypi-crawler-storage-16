dataclass\_wizard.v1 package
============================

Submodules
----------

dataclass\_wizard.v1.decorators module
--------------------------------------

.. automodule:: dataclass_wizard.v1.decorators
   :members:
   :undoc-members:
   :show-inheritance:

dataclass\_wizard.v1.enums module
---------------------------------

.. automodule:: dataclass_wizard.v1.enums
   :members:
   :undoc-members:
   :show-inheritance:

dataclass\_wizard.v1.loaders module
-----------------------------------

.. automodule:: dataclass_wizard.v1.loaders
   :members:
   :undoc-members:
   :show-inheritance:

dataclass\_wizard.v1.models module
----------------------------------

.. automodule:: dataclass_wizard.v1.models
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: dataclass_wizard.v1
   :members:
   :undoc-members:
   :show-inheritance:
