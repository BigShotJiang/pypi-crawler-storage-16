dataclass\_wizard.utils package
===============================

Submodules
----------

dataclass\_wizard.utils.dataclass\_compat module
------------------------------------------------

.. automodule:: dataclass_wizard.utils.dataclass_compat
   :members:
   :undoc-members:
   :show-inheritance:

dataclass\_wizard.utils.dict\_helper module
-------------------------------------------

.. automodule:: dataclass_wizard.utils.dict_helper
   :members:
   :undoc-members:
   :show-inheritance:

dataclass\_wizard.utils.function\_builder module
------------------------------------------------

.. automodule:: dataclass_wizard.utils.function_builder
   :members:
   :undoc-members:
   :show-inheritance:

dataclass\_wizard.utils.json\_util module
-----------------------------------------

.. automodule:: dataclass_wizard.utils.json_util
   :members:
   :undoc-members:
   :show-inheritance:

dataclass\_wizard.utils.lazy\_loader module
-------------------------------------------

.. automodule:: dataclass_wizard.utils.lazy_loader
   :members:
   :undoc-members:
   :show-inheritance:

dataclass\_wizard.utils.object\_path module
-------------------------------------------

.. automodule:: dataclass_wizard.utils.object_path
   :members:
   :undoc-members:
   :show-inheritance:

dataclass\_wizard.utils.string\_conv module
-------------------------------------------

.. automodule:: dataclass_wizard.utils.string_conv
   :members:
   :undoc-members:
   :show-inheritance:

dataclass\_wizard.utils.type\_conv module
-----------------------------------------

.. automodule:: dataclass_wizard.utils.type_conv
   :members:
   :undoc-members:
   :show-inheritance:

dataclass\_wizard.utils.typing\_compat module
---------------------------------------------

.. automodule:: dataclass_wizard.utils.typing_compat
   :members:
   :undoc-members:
   :show-inheritance:

dataclass\_wizard.utils.wrappers module
---------------------------------------

.. automodule:: dataclass_wizard.utils.wrappers
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: dataclass_wizard.utils
   :members:
   :undoc-members:
   :show-inheritance:
