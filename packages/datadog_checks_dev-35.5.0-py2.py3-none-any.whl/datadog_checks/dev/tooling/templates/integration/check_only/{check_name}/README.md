# {integration_name}

## Overview
This check monitors [integration name] through the Datadog Agent. 
To learn more, visit https://docs.datadoghq.com/integrations/{integration_name}/

## Setup
Visit our documentation to learn more. 

## Support
Need help? Contact Datadog support.
