# Event Integration

Choose this type of integration if your integration primarily sends events to Datadog.

This template is for integrations that focus on event collection.

There is no Python package for this type of integration, only a manifest is essential.

