# Tile-only Integration

Choose this type of integration if you host the logic in a different repository, and publish only the tile and assets in integrations-core.

Examples of integrations of this type include checks installed on the Agent or crawlers that run on Datadog internal infrastructure.
