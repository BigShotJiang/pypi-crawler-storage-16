#!/usr/bin/env python3
"""Command-line interface for Dataform Inventory Exporter"""

import argparse
import sys
from .exporter import DataformInventoryExporter


def main():
    """CLI entry point"""
    parser = argparse.ArgumentParser(
        description='Export Dataform .sqlx files inventory to Excel deployment checklist',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s /path/to/repo
  %(prog)s /path/to/repo -v v1.01.00
  %(prog)s /path/to/repo -o /output/path -n MyRepo -v v2.00.00
        """
    )
    
    parser.add_argument(
        'repository_path',
        help='Path to the Dataform repository root directory'
    )
    parser.add_argument(
        '-o', '--output-path',
        help='Output directory for Excel file (default: repository root)',
        default=None
    )
    parser.add_argument(
        '-n', '--repository-name',
        help='Repository name for filename (default: auto-detected)',
        default=None
    )
    parser.add_argument(
        '-v', '--version',
        help='Version number for filename (default: v1.00.00)',
        default='v1.00.00'
    )
    
    args = parser.parse_args()
    
    # Create and run exporter
    try:
        exporter = DataformInventoryExporter(
            repository_path=args.repository_path,
            output_path=args.output_path,
            repository_name=args.repository_name,
            version=args.version
        )
        
        exporter.run()
    except KeyboardInterrupt:
        print("\n\nOperation cancelled by user.")
        sys.exit(1)
    except Exception as e:
        print(f"\n\nError: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
