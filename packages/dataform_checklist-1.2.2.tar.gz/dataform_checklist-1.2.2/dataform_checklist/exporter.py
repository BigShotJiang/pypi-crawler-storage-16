#!/usr/bin/env python3
"""
Export Dataform Inventory to Excel
Generates deployment checklist from Dataform repository .sqlx files
"""

import os
import sys
import re
from pathlib import Path
from typing import List, Dict, Optional
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font, Alignment
from openpyxl.utils.dataframe import dataframe_to_rows
import shutil


class DataformInventoryExporter:
    """Export Dataform .sqlx files inventory to Excel with status tracking"""
    
    def __init__(self, repository_path: str, output_path: Optional[str] = None, 
                 repository_name: Optional[str] = None, version: Optional[str] = None):
        self.repository_path = Path(repository_path)
        self.output_path = Path(output_path) if output_path else self.repository_path
        self.repository_name = repository_name or self.repository_path.name
        
        # Search for existing file by repository name
        self.excel_path = self._find_or_create_excel_path(version)
        self.version = version or self._extract_version_from_filename()
        self.excel_filename = self.excel_path.name
        
        # Find template file
        self.template_path = self._find_template()
    
    def _find_or_create_excel_path(self, version: Optional[str]) -> Path:
        """Find existing Excel file by repository name or create new path"""
        # If version is explicitly provided, create new file with that version
        if version:
            filename = f"PTTEP_Dataform_Deployment_Checklist_{self.repository_name}_{version}.xlsx"
            filepath = self.output_path / filename
            if filepath.exists():
                print(f"Found existing file: {filename}")
            else:
                print(f"Will create new file: {filename}")
            return filepath
        
        # Otherwise, search for existing files matching PTTEP_Dataform_Deployment_Checklist_{repository_name}_*.xlsx
        pattern = f"PTTEP_Dataform_Deployment_Checklist_{self.repository_name}_*.xlsx"
        existing_files = list(self.output_path.glob(pattern))
        
        # Filter out temporary Excel files (starting with ~$)
        existing_files = [f for f in existing_files if not f.name.startswith('~$')]
        
        if existing_files:
            # Use the most recently modified file
            existing_file = max(existing_files, key=lambda f: f.stat().st_mtime)
            print(f"Found existing file: {existing_file.name}")
            return existing_file
        else:
            # Create new filename with default version
            filename = f"PTTEP_Dataform_Deployment_Checklist_{self.repository_name}_v1.00.00.xlsx"
            print(f"No existing file found. Will create: {filename}")
            return self.output_path / filename
    
    def _extract_version_from_filename(self) -> str:
        """Extract version from existing filename or return default"""
        if self.excel_path.exists():
            # Extract version from filename pattern: PTTEP_Dataform_Deployment_Checklist_{name}_{version}.xlsx
            name_parts = self.excel_path.stem.split('_')
            if len(name_parts) >= 4:
                # Last part should be the version
                return name_parts[-1]
        return "v1.00.00"
        
    def _find_template(self) -> Path:
        """Find the template Excel file"""
        # Check in package directory (where this file is located)
        package_dir = Path(__file__).parent
        template_dir = package_dir / "template"
        
        if template_dir.exists():
            templates = list(template_dir.glob("*.xlsx"))
            templates = [t for t in templates if not t.name.startswith('~$')]
            if templates:
                return templates[0]
        
        # Check in current directory (for development)
        local_template_dir = Path("dataform_checklist/template")
        if local_template_dir.exists():
            templates = list(local_template_dir.glob("*.xlsx"))
            templates = [t for t in templates if not t.name.startswith('~$')]
            if templates:
                return templates[0]
        
        raise FileNotFoundError("Template Excel file not found. Expected in 'dataform_checklist/template/' directory")
    
    def _extract_sources_from_js(self, js_file_path: Path) -> str:
        """Extract sources array from JavaScript dependencies.js file"""
        try:
            content = js_file_path.read_text(encoding='utf-8')
            # Match: var sources = ["item1", "item2", ...] or var sources = ['item1', 'item2', ...]
            pattern = r'var\s+sources\s*=\s*\[([^\]]+)\]'
            match = re.search(pattern, content, re.DOTALL)
            if match:
                sources_str = match.group(1)
                # Extract quoted strings
                sources = re.findall(r'["\']([^"\']+)["\']', sources_str)
                # Join with comma and newline for better readability in Excel
                return ',\n'.join(sources)
            return ''
        except Exception as e:
            print(f"Warning: Could not parse {js_file_path}: {e}")
            return ''
        
    def scan_sqlx_files(self) -> List[Dict[str, str]]:
        """Scan repository for all .sqlx and dependencies.js files"""
        print(f"Scanning for .sqlx and dependencies.js files in: {self.repository_path}")
        
        sqlx_files = []
        
        # Scan for .sqlx files
        for sqlx_file in self.repository_path.rglob("*.sqlx"):
            # Get relative path from repository root
            relative_dir = sqlx_file.parent.relative_to(self.repository_path)
            
            # Find 'definitions' in the path and start from there
            path_parts = relative_dir.parts
            if 'definitions' in path_parts:
                # Start from 'definitions' folder
                definitions_idx = path_parts.index('definitions')
                directory = str(Path(*path_parts[definitions_idx:]))
            else:
                # If no 'definitions' folder, use the full relative path
                directory = str(relative_dir)
            
            sqlx_files.append({
                'full_path': str(sqlx_file),
                'directory': directory,
                'filename': sqlx_file.name,
                'remark': ''  # Empty for .sqlx files
            })
        
        # Scan for dependencies.js files
        for js_file in self.repository_path.rglob("dependencies.js"):
            # Get relative path from repository root
            relative_dir = js_file.parent.relative_to(self.repository_path)
            
            # Find 'definitions' in the path and start from there
            path_parts = relative_dir.parts
            if 'definitions' in path_parts:
                # Start from 'definitions' folder
                definitions_idx = path_parts.index('definitions')
                directory = str(Path(*path_parts[definitions_idx:]))
            else:
                # If no 'definitions' folder, use the full relative path
                directory = str(relative_dir)
            
            # Extract sources from the JavaScript file
            sources = self._extract_sources_from_js(js_file)
            
            sqlx_files.append({
                'full_path': str(js_file),
                'directory': directory,
                'filename': js_file.name,
                'remark': sources
            })
        
        sqlx_files.sort(key=lambda x: x['full_path'])
        print(f"Found {len(sqlx_files)} files (.sqlx and dependencies.js)")
        
        return sqlx_files
    
    def create_new_inventory(self, files: List[Dict[str, str]]) -> pd.DataFrame:
        """Create new inventory DataFrame from files"""
        data = []
        
        for idx, file in enumerate(files, start=1):
            data.append({
                'Index': idx,
                'Path/Folder/Directory': file['directory'],
                'file_name': file['filename'],
                'remark': file.get('remark', ''),
                'status': 'New'
            })
        
        return pd.DataFrame(data)
    
    def load_existing_inventory(self) -> Optional[pd.DataFrame]:
        """Load existing Excel inventory if it exists"""
        if not self.excel_path.exists():
            print("No existing file found. Creating new inventory.")
            return None
        
        try:
            print(f"Loading existing inventory from: {self.excel_path}")
            
            # Find the DataForm sheet with our data
            workbook = load_workbook(self.excel_path)
            target_sheet = None
            for sheet_name in workbook.sheetnames:
                if sheet_name.startswith('DataForm') or sheet_name.startswith('Dataform'):
                    target_sheet = sheet_name
                    break
            
            if not target_sheet:
                print("No DataForm sheet found in existing file. Creating new inventory.")
                return None
            
            # Read from the specific sheet, starting from row 8 (header row)
            existing_df = pd.read_excel(self.excel_path, sheet_name=target_sheet, 
                                       header=7)  # 0-indexed, so row 8 is index 7
            
            # Rename columns to match our internal names
            column_mapping = {
                '#': 'Index',
                'Job/Script Name': 'file_name',
                'Remark': 'remark',
                'status': 'status'
            }
            existing_df = existing_df.rename(columns=column_mapping)
            
            # Filter out empty rows and ensure we have the required columns
            if existing_df.empty or 'Path/Folder/Directory' not in existing_df.columns:
                print("No valid existing inventory found. Creating new inventory.")
                return None
            
            # Remove rows where all values are NaN
            existing_df = existing_df.dropna(how='all')
            
            # Keep only our columns
            required_cols = ['Index', 'Path/Folder/Directory', 'file_name', 'remark', 'status']
            existing_cols = [col for col in required_cols if col in existing_df.columns]
            existing_df = existing_df[existing_cols]
            
            # Add remark column if it doesn't exist (for backward compatibility)
            if 'remark' not in existing_df.columns:
                existing_df['remark'] = ''
            
            print(f"Loaded {len(existing_df)} existing records")
            return existing_df
        except Exception as e:
            print(f"Warning: Could not load existing file: {e}")
            return None
    
    def merge_inventories(self, new_inventory: pd.DataFrame, 
                         existing_inventory: Optional[pd.DataFrame]) -> pd.DataFrame:
        """Merge new and existing inventories with status tracking"""
        if existing_inventory is None or len(existing_inventory) == 0:
            print("No existing inventory to merge. All files marked as 'New'")
            return new_inventory
        
        print("Merging inventories...")
        
        # Create unique keys for comparison
        new_inventory['_key'] = (new_inventory['Path/Folder/Directory'] + '|' + 
                                 new_inventory['file_name'])
        existing_inventory['_key'] = (existing_inventory['Path/Folder/Directory'] + '|' + 
                                      existing_inventory['file_name'])
        
        existing_keys = set(existing_inventory['_key'])
        new_keys = set(new_inventory['_key'])
        
        # Update status for new inventory
        new_count = 0
        existed_count = 0
        
        for idx, row in new_inventory.iterrows():
            if row['_key'] in existing_keys:
                new_inventory.at[idx, 'status'] = 'Existed'
                existed_count += 1
            else:
                new_inventory.at[idx, 'status'] = 'New'
                new_count += 1
        
        # Find deleted files
        deleted_files = []
        deleted_count = 0
        
        for idx, row in existing_inventory.iterrows():
            if row['_key'] not in new_keys:
                deleted_files.append({
                    'Index': 0,  # Will be renumbered
                    'Path/Folder/Directory': row['Path/Folder/Directory'],
                    'file_name': row['file_name'],
                    'remark': row.get('remark', ''),
                    'status': 'Deleted',
                    '_key': row['_key']
                })
                deleted_count += 1
        
        # Combine current files with deleted files
        merged = pd.concat([
            new_inventory,
            pd.DataFrame(deleted_files)
        ], ignore_index=True)
        
        # Renumber indices
        merged['Index'] = range(1, len(merged) + 1)
        
        # Remove temporary key column
        merged = merged.drop(columns=['_key'])
        
        print(f"Merge complete:")
        print(f"  - New files: {new_count}")
        print(f"  - Existed files: {existed_count}")
        print(f"  - Deleted files: {deleted_count}")
        
        return merged
    
    def export_to_excel(self, inventory: pd.DataFrame):
        """Export inventory to Excel with formatting using template"""
        print(f"Using template: {self.template_path}")
        print(f"Exporting to Excel: {self.excel_path}")
        
        # Copy template to output location
        shutil.copy2(self.template_path, self.excel_path)
        
        # Load the workbook
        workbook = load_workbook(self.excel_path)
        
        # Find sheet that starts with "DataForm"
        target_sheet = None
        for sheet_name in workbook.sheetnames:
            if sheet_name.startswith('DataForm') or sheet_name.startswith('Dataform'):
                target_sheet = sheet_name
                break
        
        if not target_sheet:
            # Create new sheet if no DataForm sheet exists
            target_sheet = f'DataForm {self.version}'
            workbook.create_sheet(target_sheet)
        
        worksheet = workbook[target_sheet]
        
        # Write data starting from A9 (template has headers at row 7-8)
        start_row = 9
        start_col = 1
        
        # Write data rows directly (no headers, template already has them)
        for row_idx, row_data in enumerate(inventory.itertuples(index=False), start=start_row):
            for col_idx, value in enumerate(row_data, start=start_col):
                worksheet.cell(row=row_idx, column=col_idx, value=value)
        
        # Apply formatting
        self._apply_formatting(worksheet, inventory, start_row)
        
        # Save workbook
        workbook.save(self.excel_path)
        
        print("Export completed successfully!")
        print(f"File saved to: {self.excel_path}")
    
    def _apply_formatting(self, worksheet, inventory: pd.DataFrame, start_row: int = 9):
        """Apply Excel formatting and conditional styling"""
        # Define colors
        colors = {
            'New': PatternFill(start_color='90EE90', end_color='90EE90', fill_type='solid'),  # LightGreen
            'Existed': PatternFill(start_color='ADD8E6', end_color='ADD8E6', fill_type='solid'),  # LightBlue
            'Deleted': PatternFill(start_color='F08080', end_color='F08080', fill_type='solid')  # LightCoral
        }
        
        # Apply conditional formatting to status column (column E, now that remark is D)
        status_col = 5
        remark_col = 4
        path_col = 2
        filename_col = 3
        
        # Start from start_row (not start_row + 1) since we don't have a header row
        for idx, row in enumerate(inventory.itertuples(), start=start_row):
            status = row.status
            if status in colors:
                worksheet.cell(row=idx, column=status_col).fill = colors[status]
            
            # Enable text wrapping and top alignment for remark column
            remark_cell = worksheet.cell(row=idx, column=remark_col)
            remark_cell.alignment = Alignment(wrap_text=True, vertical='top')
            
            # Set top alignment for path, filename, and status columns
            worksheet.cell(row=idx, column=path_col).alignment = Alignment(vertical='top')
            worksheet.cell(row=idx, column=filename_col).alignment = Alignment(vertical='top')
            worksheet.cell(row=idx, column=status_col).alignment = Alignment(vertical='top')
        
        # Auto-adjust column widths for data columns
        for col_idx in range(1, 6):  # Columns A-E
            max_length = 0
            column_letter = worksheet.cell(row=start_row, column=col_idx).column_letter
            
            for row_idx in range(start_row, start_row + len(inventory) + 1):
                cell = worksheet.cell(row=row_idx, column=col_idx)
                try:
                    if cell.value and len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            
            adjusted_width = min(max_length + 2, 50)
            if adjusted_width > 10:  # Only adjust if meaningful
                worksheet.column_dimensions[column_letter].width = adjusted_width
    
    def run(self):
        """Main execution method"""
        print("\n========================================")
        print("  Dataform Deployment Checklist Export")
        print("========================================\n")
        
        # Validate repository path
        if not self.repository_path.exists():
            print(f"Error: Repository path not found: {self.repository_path}")
            sys.exit(1)
        
        # Ensure output directory exists
        self.output_path.mkdir(parents=True, exist_ok=True)
        
        # Scan for .sqlx files
        sqlx_files = self.scan_sqlx_files()
        
        if not sqlx_files:
            print("Warning: No .sqlx files found in the repository!")
            return
        
        # Create new inventory
        new_inventory = self.create_new_inventory(sqlx_files)
        
        # Load existing inventory
        existing_inventory = self.load_existing_inventory()
        
        # Merge inventories with status tracking
        final_inventory = self.merge_inventories(new_inventory, existing_inventory)
        
        # Export to Excel
        self.export_to_excel(final_inventory)
        
        print("\n========================================")
        print("Summary:")
        print(f"  Total files: {len(final_inventory)}")
        print(f"  Output file: {self.excel_filename}")
        print(f"  Location: {self.output_path}")
        print("========================================\n")
