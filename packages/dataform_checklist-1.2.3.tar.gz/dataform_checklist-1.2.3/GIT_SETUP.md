# Git Setup Guide: Push Package to New Repository

## Step 1: Create New Repository on GitHub/GitLab/Bitbucket

### GitHub:
1. Go to https://github.com/new
2. Repository name: `dataform-deployment-checklist`
3. Description: "Python package for generating Excel deployment checklists from Dataform repositories"
4. Choose: **Private** (recommended for internal tools)
5. **DO NOT** initialize with README (we already have one)
6. Click "Create repository"

### Copy the repository URL:
```
https://github.com/your-org/dataform-deployment-checklist.git
```

## Step 2: Prepare Package Directory

```powershell
# Navigate to scripts directory
cd "C:\Users\thamo\Dataform Respository\wwim\scripts"

# Initialize git (if not already)
git init

# Create .gitignore for Python package
# (See .gitignore file created)
```

## Step 3: Configure Git (First Time Only)

```powershell
# Set your name and email
git config user.name "Your Name"
git config user.email "your.email@pttep.com"

# Or set globally for all projects
git config --global user.name "Your Name"
git config --global user.email "your.email@pttep.com"
```

## Step 4: Add and Commit Files

```powershell
# Add all package files
git add .

# Commit with message
git commit -m "Initial commit: Dataform deployment checklist package v1.0.0"
```

## Step 5: Push to Remote Repository

```powershell
# Add remote repository (replace with your URL)
git remote add origin https://github.com/your-org/dataform-deployment-checklist.git

# Push to main branch
git branch -M main
git push -u origin main
```

## Step 6: Verify Upload

Visit your repository URL to confirm all files are uploaded.

## Alternative: Push to Existing Repository as Subdirectory

If you want to add this to an existing repository:

```powershell
# Navigate to main repository
cd "C:\Users\thamo\Dataform Respository\wwim"

# Add scripts directory
git add scripts/

# Commit
git commit -m "Add deployment checklist package"

# Push
git push
```

---

## Quick Commands (Copy-Paste)

```powershell
# Navigate to scripts
cd "C:\Users\thamo\Dataform Respository\wwim\scripts"

# Initialize and commit
git init
git add .
git commit -m "Initial commit: Dataform deployment checklist package v1.0.0"

# Add remote (REPLACE WITH YOUR REPO URL)
git remote add origin https://github.com/your-org/dataform-deployment-checklist.git

# Push
git branch -M main
git push -u origin main
```

## Recommended: Add Release Tag

```powershell
# Tag the release
git tag -a v1.0.0 -m "Release version 1.0.0"

# Push tags
git push origin v1.0.0
```

## Share with Team

After pushing, team members can:

### Option 1: Clone and Install
```powershell
git clone https://github.com/your-org/dataform-deployment-checklist.git
cd dataform-deployment-checklist
pip install dist/dataform_checklist-1.0.0-py3-none-any.whl
```

### Option 2: Direct Install (if wheel is in releases)
```powershell
pip install https://github.com/your-org/dataform-deployment-checklist/releases/download/v1.0.0/dataform_checklist-1.0.0-py3-none-any.whl
```

### Option 3: Install from Git (Development Mode)
```powershell
pip install git+https://github.com/your-org/dataform-deployment-checklist.git
```
