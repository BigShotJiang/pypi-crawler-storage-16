===============
Data Generation
===============

.. currentmodule:: dataframely
.. autosummary::
    :toctree: _gen/

    Collection.create_empty
    Collection.sample
