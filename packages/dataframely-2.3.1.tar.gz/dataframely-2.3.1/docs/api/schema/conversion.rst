==========
Conversion
==========

.. currentmodule:: dataframely
.. autosummary::
    :toctree: _gen/

    Schema.to_sqlalchemy_columns
    Schema.to_pyarrow_schema
    Schema.to_polars_schema
