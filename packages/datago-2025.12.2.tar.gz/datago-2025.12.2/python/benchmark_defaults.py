IMAGE_CONFIG = {
    "crop_and_resize": True,
    "default_image_size": 1024,
    "downsampling_ratio": 32,
    "min_aspect_ratio": 0.5,
    "max_aspect_ratio": 2.0,
    "pre_encode_images": False,
}
