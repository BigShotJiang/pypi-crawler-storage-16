"""Tests for dataknobs-bots package."""
