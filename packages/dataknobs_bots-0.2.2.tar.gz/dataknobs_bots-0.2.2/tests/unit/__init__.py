"""Unit tests for dataknobs-bots."""
