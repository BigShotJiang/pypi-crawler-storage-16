"""Additional CLI command definitions and utilities.

This module is reserved for extending the FSM CLI with additional commands
and command utilities. Main CLI commands are defined in cli/main.py.
"""
