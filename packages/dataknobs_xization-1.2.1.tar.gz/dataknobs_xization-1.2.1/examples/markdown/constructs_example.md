# Code Example

Here's how to use it:

```python
def chunk_text(text):
    # This code block could get split
    # in the middle, breaking it
    return chunks
```

## Lists

Important points:
- Item 1
- Item 2
- Item 3

## Table

| Column 1 | Column 2 |
|----------|----------|
| Data 1   | Data 2   |

---

Horizontal rule above.
