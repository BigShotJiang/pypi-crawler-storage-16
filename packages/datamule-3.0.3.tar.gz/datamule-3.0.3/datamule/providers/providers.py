# TODO
# make it easy for people to bring their own cloud

SEC_LOOKUP_DB_ENDPOINT = ""
SEC_FILINGS_SGML_BUCKET_ENDPOINT = "https://sec-library.datamule.xyz/" 
SEC_FILINGS_TAR_BUCKET_ENDPOINT = "https://sec-library.tar.datamule.xyz/"
MAIN_API_ENDPOINT = "https://api.datamule.xyz/"