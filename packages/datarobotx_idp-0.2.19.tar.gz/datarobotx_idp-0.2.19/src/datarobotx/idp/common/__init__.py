"""Idempotent utilities."""
