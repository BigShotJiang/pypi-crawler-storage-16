"""
Data Science Practicals and Utilities
Author: Jyoti Rahate
"""

__version__ = "0.2.0"
__author__ = "Jyoti Rahate"
