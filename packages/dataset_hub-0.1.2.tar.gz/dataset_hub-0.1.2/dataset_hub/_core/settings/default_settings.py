DEFAULT_SETTINGS = {"verbose": True, "data_path": "/data", "save_local": True}
