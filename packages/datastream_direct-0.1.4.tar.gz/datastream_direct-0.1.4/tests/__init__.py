"""Test package for datastream_direct."""
