Installation
============

It is recommended to install ``DataVizML`` using pip:

.. code-block:: bash

   pip install datavizml