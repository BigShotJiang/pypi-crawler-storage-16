#special methods config

#_fsm

fsm_def = {
	"search_by": "all"
}

BUFFER_SIZE = 4096