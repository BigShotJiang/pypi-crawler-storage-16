"""
Setup script para compatibilidade com versões antigas do pip
"""
from setuptools import setup

# A configuração agora está no pyproject.toml
# Este arquivo existe apenas para compatibilidade com pip < 21.3
setup()
