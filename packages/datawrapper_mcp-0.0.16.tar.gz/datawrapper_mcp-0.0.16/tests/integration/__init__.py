"""Integration tests for datawrapper-mcp server."""
