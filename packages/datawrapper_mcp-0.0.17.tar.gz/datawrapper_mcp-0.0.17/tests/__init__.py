"""Tests for datawrapper-mcp."""
