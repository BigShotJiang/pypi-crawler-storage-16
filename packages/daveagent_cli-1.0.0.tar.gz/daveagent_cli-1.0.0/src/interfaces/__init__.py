"""
Interfaces de usuario - CLI, etc.
"""
from src.interfaces.cli_interface import CLIInterface

__all__ = ["CLIInterface"]
