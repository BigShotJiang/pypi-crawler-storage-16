import requests
from typing import Generator
import json


def stream_sse(response: requests.Response) -> Generator[dict, None, None]:
    return (json.loads(line[5:].decode()) for line in response.iter_lines() if line)
