
from unittest import TestCase

from dax import assessor_wrapper

# TODO BenM/assessor_of_assessor/pick this up later; it isn't required for the
# initial working solution
class AssessorWrapperUnitTests(TestCase):

    def test_fn(self):
        pass