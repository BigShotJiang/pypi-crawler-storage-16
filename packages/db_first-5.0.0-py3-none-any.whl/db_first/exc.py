class DBFirstError(Exception):
    """Common exception for errors."""
