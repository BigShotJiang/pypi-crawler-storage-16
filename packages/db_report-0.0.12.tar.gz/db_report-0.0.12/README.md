# reporter
Simple SQL report generator.  
  
After install:

$ pip install git+git://github.com/oleglpts/reporter.git
  
see directory ~/db_report and https://pypi.org/project/xls-report/
    
**Requirements:** xls-report>=0.0.3, bottle>=0.12.17, pyodbc==4.0.26, pycurl>=7.43.0.3  
    
**TODO: documentation**
