#!/bin/bash

rm -rf ~/.db_report/report.log ~/.db_report/*.csv ~/.db_report/*.xls ~/.db_report/test_json.json ~/.db_report/*.tab
