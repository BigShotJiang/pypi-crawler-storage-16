import sys
from sqlalchemy import Column, Integer, String, text
from database import DatabaseManager, Base
from config import settings

# --- 1. 定义一个测试用的模型 ---
class TestUser(Base):
    __tablename__ = "test_users"  # 数据库中的表名

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, nullable=False)
    email = Column(String, nullable=True)

    def __repr__(self):
        return f"<TestUser(id={self.id}, username='{self.username}')>"

def run_test():
    print(f"🚀 开始测试连接: {settings.DB_URL}")

    # 初始化数据库管理器
    # echo=False 表示不打印繁琐的 SQL 语句，如果报错想看细节可以改为 True
    db = DatabaseManager(settings.DB_URL, echo=True)

    # --- 2. 测试连接 ---
    try:
        with db.session() as s:
            s.execute(text("SELECT 1"))
        print("✅ 数据库物理连接成功！")
    except Exception as e:
        print(f"❌ 连接失败，请检查 .env 文件配置。错误信息:\n{e}")
        sys.exit(1)

    # --- 3. 重置表结构 (慎用 drop_all，这里仅用于测试) ---
    print("🔄 正在初始化表结构...")
    try:
        # 先删除旧表（如果有），再创建新表，保证环境干净
        # 注意：在生产环境千万不要随便用 drop_all
        db.drop_tables() 
        db.create_tables()
        print("✅ 表 `test_users` 创建成功！")
    except Exception as e:
        print(f"❌ 建表失败: {e}")
        sys.exit(1)

    # --- 4. 测试写入数据 (Create) ---
    print("📝 正在写入测试数据...")
    try:
        with db.session() as session:
            user1 = TestUser(username="batman", email="bruce@wayne.com")
            user2 = TestUser(username="superman", email="clark@dailyplanet.com")
            session.add_all([user1, user2])
            # 退出 with 块时会自动 commit
        print("✅ 数据写入成功！")
    except Exception as e:
        print(f"❌ 写入失败: {e}")

    # --- 5. 测试查询数据 (Read) ---
    print("🔍 正在查询数据...")
    with db.session() as session:
        # 查询所有
        users = session.query(TestUser).all()
        print(f"   -> 查到了 {len(users)} 个用户:")
        for u in users:
            print(f"      - {u.id}: {u.username} ({u.email})")
        
        # 条件查询
        hero = session.query(TestUser).filter_by(username="batman").first()
        if hero:
            print(f"   -> 精确查询测试通过，找到了: {hero.username}")
        else:
            print("❌ 精确查询失败")

    # --- 6. 测试修改数据 (Update) ---
    print("✏️ 正在修改数据...")
    with db.session() as session:
        hero = session.query(TestUser).filter_by(username="batman").first()
        if hero:
            hero.email = "darkknight@gotham.city"
            # 自动 commit
    
    # 验证修改
    with db.session() as session:
        updated_hero = session.query(TestUser).filter_by(username="batman").first()
        print(f"   -> 修改后的邮箱: {updated_hero.email}")

    # --- 7. 测试删除数据 (Delete) ---
    print("🗑️ 正在删除数据...")
    with db.session() as session:
        hero = session.query(TestUser).filter_by(username="superman").first()
        if hero:
            session.delete(hero)
            print("   -> Superman 已删除")
    
    # 最终验证
    with db.session() as session:
        count = session.query(TestUser).count()
        print(f"🏁 测试结束。数据库中剩余用户数量: {count} (预期为 1)")

if __name__ == "__main__":
    run_test()