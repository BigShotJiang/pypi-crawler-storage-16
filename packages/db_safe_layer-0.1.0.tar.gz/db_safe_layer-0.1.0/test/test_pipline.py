from db_safe_layer import safe_exec, rollback_to

safe_exec("DELETE FROM person WHERE person_id = 3")
rollback_to()
