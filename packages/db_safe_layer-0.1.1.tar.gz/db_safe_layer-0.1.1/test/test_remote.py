from sqlalchemy import text
from database import DatabaseManager
from config import settings

def test_remote_connection():
    print(f"🌍 正在连接远程数据库: {settings.DB_URL}")
    
    # 1. 初始化管理器
    db = DatabaseManager(settings.DB_URL, echo=True) # echo=True 会打印 SQL 日志，方便调试

    try:
        with db.session() as session:
            # 2. 执行一个简单的 SQL 查询 (不需要定义模型)
            # 查询数据库的当前时间，确保连接是活的
            result = session.execute(text("SELECT NOW() as current_time, version()"))
            row = result.fetchone()
            
            print("-" * 30)
            print("✅ 远程连接成功！")
            print(f"🕒 服务器时间: {row.current_time}")
            print(f"📦 数据库版本: {row[1]}") # version()
            print("-" * 30)

            # 3. 如果你想查具体的表（比如 users 表），可以解开下面的注释
            # 注意：前提是你的数据库里真的有 users 表
          
            print("🔍 尝试查询 users 表前 5 条数据...")
            users = session.execute(text("SELECT * FROM chapter LIMIT 5"))
            for u in users:
                print(u)
         

    except Exception as e:
        print("❌ 连接或查询失败")
        print(f"错误信息: {e}")

if __name__ == "__main__":
    test_remote_connection()