from dbt.tests.adapter.empty.test_empty import BaseTestEmpty, BaseTestEmptyInlineSourceRef


class TestAthenaEmpty(BaseTestEmpty):
    pass


class TestAthenaEmptyInlineSourceRef(BaseTestEmptyInlineSourceRef):
    pass
