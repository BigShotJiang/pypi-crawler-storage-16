# this is a shell package that allows us to publish dbt-athena as dbt-athena-community
