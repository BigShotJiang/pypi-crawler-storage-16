def output_package_name():
    print("====== Package Name =======")