{{ config(
    pre_hook="select 1", 
    post_hook="select 2"
) }}