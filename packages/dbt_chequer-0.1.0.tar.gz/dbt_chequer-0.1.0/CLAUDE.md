# CLAUDE.md - dbt-chequer Development Guide

## Project Overview

dbt-chequer is a Python CLI tool that consolidates multiple dbt quality checks into a single, easy-to-use package. Instead of configuring SQLFluff, dbt-bouncer, dbt-coverage, pre-commit, and dbt-checkpoint separately, users install one package and run an interactive wizard.

### Core Value Proposition

- One install, generates tool-specific config files (.sqlfluff, dbt-bouncer.yml, etc.)
- Interactive wizard for setup (dbt-chequer init)
- Unified check runner with rich console output
- GitHub Actions templates with sticky PR comments
- Auto-detection of existing config files
- Category-based reporting (Formatting, Documentation, Coverage, Governance, Data Quality)

## Project Structure

```
dbt-chequer/
├── src/dbt_chequer/
│   ├── __init__.py           # Package exports, version
│   ├── branding.py           # ASCII art, icons, branding
│   ├── categories.py         # Category definitions and mappings
│   ├── cli.py                # Typer CLI commands
│   ├── config.py             # Config detection helpers
│   ├── doctor.py             # Setup diagnostics
│   ├── registry.py           # Check registry and metadata
│   ├── status.py             # Status command implementation
│   ├── checks/
│   │   ├── __init__.py       # Check info and exports
│   │   ├── base.py           # BaseCheck, CheckResult, Violation
│   │   ├── runner.py         # Orchestrates all checks
│   │   ├── sqlfluff.py       # SQLFluff wrapper
│   │   ├── dbt_bouncer.py    # dbt-bouncer wrapper
│   │   ├── dbt_coverage.py   # dbt-coverage wrapper
│   │   └── prek.py           # prek (pre-commit) wrapper
│   ├── reporter/
│   │   ├── __init__.py
│   │   ├── console.py        # Rich terminal output with categories
│   │   └── github.py         # Sticky PR comments + check annotations
│   ├── wizard/
│   │   ├── __init__.py
│   │   ├── core.py           # Interactive setup wizard
│   │   ├── categories.py     # Category configuration prompts
│   │   ├── detection.py      # Auto-detect dbt project/warehouse
│   │   ├── generators.py     # Config file generators
│   │   ├── sqlfluff_config.py # SQLFluff style configuration
│   │   └── templates.py      # Legacy template generators
│   └── templates/
│       ├── __init__.py       # Jinja2 environment
│       ├── dbt_bouncer.yml.j2
│       ├── pre_commit.yaml.j2
│       ├── sqlfluff.j2
│       └── github_actions/
│           ├── pr_check.yml.j2
│           ├── merge.yml.j2
│           └── daily.yml.j2
├── pyproject.toml
├── README.md
└── CLAUDE.md
```

## Tech Stack

- **Python 3.12+** - Modern Python with type hints
- **Typer** - CLI framework (built on Click with type hints)
- **Rich** - Terminal formatting, tables, panels, spinners
- **Questionary** - Interactive prompts
- **Jinja2** - Template rendering for config files
- **PyYAML** - YAML parsing
- **httpx** - HTTP client for GitHub API
- **uv** - Package manager and build tool
- **ruff** - Linting and formatting
- **ty** - Type checking (Astral's type checker)

## Architecture

### Tool-Specific Config Files

dbt-chequer generates standard config files instead of a unified configuration:

- `.sqlfluff` - SQLFluff configuration
- `dbt-bouncer.yml` - dbt-bouncer governance rules
- `.pre-commit-config.yaml` - Pre-commit hooks
- `.github/workflows/dbt-quality.yml` - GitHub Actions

Each check auto-detects its config file. The wizard generates these files directly using Jinja2 templates.

### Check Auto-Detection

Checks are automatically enabled based on config file presence:

```python
# SQLFluff is enabled if .sqlfluff exists or models/ directory exists
def is_enabled(self) -> bool:
    return self.config_path is not None or Path("models").exists()

# dbt-bouncer is enabled if dbt-bouncer.yml exists
def is_enabled(self) -> bool:
    return self.config_path is not None

# prek is enabled if .pre-commit-config.yaml exists
def is_enabled(self) -> bool:
    return self.config_path is not None
```

### Category-Based Reporting

The reporter groups violations by quality category rather than by tool:

```python
class Category(Enum):
    FORMATTING = "formatting"
    DOCUMENTATION = "documentation"
    COVERAGE = "coverage"
    GOVERNANCE = "governance"
    DATA_QUALITY = "data_quality"
```

Each violation is mapped to a category via `category_mapper.categorize(tool, rule)`.

## CLI Commands

```bash
dbt-chequer init [--force]                    # Interactive wizard
dbt-chequer check [-k CHECK...] [--fix]       # Run checks
dbt-chequer status                            # Show enabled checks
dbt-chequer doctor                            # Diagnose setup
dbt-chequer checks [--category CATEGORY]      # List available checks
```

## Adding a New Check

1. Create `src/dbt_chequer/checks/new_check.py`:

```python
from dbt_chequer.checks.base import BaseCheck, CheckResult, Violation
from dbt_chequer.config import detect_new_check_config

class NewCheck(BaseCheck):
    name = "new_check"
    description = "Description of what this check does"

    def __init__(self):
        self.config_path = detect_new_check_config()

    def is_enabled(self) -> bool:
        return self.config_path is not None

    def run(self, fix: bool = False, changed_only: bool = False) -> CheckResult:
        # Implementation here
        return CheckResult(
            name=self.name,
            status="passed",  # or "failed", "warning", "skipped"
            summary="Check completed",
            violations=[],
            extra={"fix_attempted": fix},  # Track if --fix was used
        )
```

2. Add detection function to `config.py`:

```python
def detect_new_check_config() -> Path | None:
    """Detect new-check config file."""
    path = Path("new-check.yml")
    return path if path.exists() else None
```

3. Register in `checks/runner.py`:

```python
from dbt_chequer.checks.new_check import NewCheck

checks = {
    # ... existing checks ...
    "new_check": NewCheck(),
}
```

4. Add check definitions to `registry.py`:

```python
CheckDefinition(
    id="new_check_rule",
    name="New Check Rule",
    description="What this rule checks",
    category=Category.FORMATTING,  # Or appropriate category
    tool=Tool.NEW_TOOL,
    preset_standard=True,
    config_key="new-check-rule-id",
)
```

5. Add category mapping in `categories.py`:

```python
# In CategoryMapper class
NEW_CHECK_CATEGORY_MAP = {
    "rule-name": Category.FORMATTING,
    # ... more mappings
}
```

## Check Result Flow

1. **Runner** (`checks/runner.py`) creates check instances
2. Each check runs via **subprocess** and parses output
3. Violations are created with **category assignment**
4. **ConsoleReporter** groups violations by category
5. Results displayed with category summaries and fix hints

## Console Reporter Features

### Context-Aware Fix Hints

The reporter provides different hints based on context:

```python
# When --fix was attempted, show different hints
if category == Category.FORMATTING and fix_attempted:
    hints = [
        "Remaining issues require manual fixes (auto-fix already attempted)",
        "Review SQLFluff rules: AM06 (ambiguous columns), RF02 (unqualified references)",
    ]
```

### Check Failure Tracking

When checks fail without producing violations (e.g., tool crashes), the reporter marks affected categories as "Warning" instead of "Pass":

```python
# Track which categories had checks fail
failed_checks_by_category = self._get_failed_checks_by_category(results)

if count == 0 and failed_checks:
    status = "⚠ Warn"
    summary = f"Check(s) failed to run: {', '.join(failed_checks)}"
```

## Wizard Architecture

The wizard is split into two approaches:

1. **Preset-based** (`wizard/core.py`): Relaxed, Standard, Strict presets
2. **Custom** (`wizard/categories.py`): Interactive per-category configuration

### Custom Configuration Flow

1. User selects categories to configure
2. For each category, run category-specific wizard:
   - `_configure_sqlfluff()` - Formatting options
   - `_configure_documentation()` - Documentation level
   - `_configure_coverage()` - Test coverage requirements
   - `_configure_governance()` - Naming and structure rules
   - `_configure_data_quality()` - Freshness and quality checks

3. Generate config files from templates via `ConfigGenerator`

### Config Generator

The `ConfigGenerator` class generates tool-specific configs:

```python
def generate_sqlfluff_config(config: CustomConfig) -> str:
    # Uses SQLFluffConfigGenerator for detailed rules
    return SQLFluffConfigGenerator.generate(config.sqlfluff)

def generate_dbt_bouncer_config(config: CustomConfig) -> str:
    # Generates manifest_checks and catalog_checks
    # Based on enabled categories and their settings

def _generate_precommit_from_config(config: CustomConfig) -> str:
    # Generates hooks for dbt-checkpoint
    # Includes model name contract hooks if governance enabled
```

## GitHub Actions Patterns

### Sticky Comments

Use `marocchino/sticky-pull-request-comment@v2` with unique headers:

```yaml
- name: Comment on PR
  uses: marocchino/sticky-pull-request-comment@v2
  with:
    header: sqlfluff  # Unique per tool
    message: |
      ## SQLFluff Results
      ...
```

### Generated Workflow Structure

```yaml
name: dbt Quality Checks
on:
  pull_request:
    paths: ['models/**', 'macros/**', '**.yml']

jobs:
  sqlfluff:
    # Linting with auto-fix

  dbt-bouncer:
    # Governance validation

  dbt-coverage:
    # Coverage reporting

  summary:
    # Aggregate results
    needs: [sqlfluff, dbt-bouncer, dbt-coverage]
```

## Pre-commit Hooks Configuration

### Model Name Contract Hooks

The wizard now generates `check-model-name-contract` hooks per directory:

```yaml
- id: check-model-name-contract
  name: Check staging models use stg_ prefix
  args: [--pattern, '^stg_.*']
  files: models/staging/

- id: check-model-name-contract
  name: Check intermediate models use int_ prefix
  args: [--pattern, '^int_.*']
  files: models/intermediate/

- id: check-model-name-contract
  name: Check mart models use fct_/dim_ prefix
  args: [--pattern, '^(fct_|dim_).*']
  files: models/marts/
```

These are only generated when `governance.enforce_naming_convention` is enabled.

## Development Commands

```bash
# Install dependencies
uv sync

# Run the CLI
uv run dbt-chequer --help

# Type checking
uv run ty check src/dbt_chequer

# Linting and formatting
uv run ruff check --fix src/dbt_chequer
uv run ruff format src/dbt_chequer

# Run in development mode (editable install)
uv pip install -e .
```

## Code Quality Setup

### Type Checking with ty

All code is type-checked with Astral's ty:

```bash
uv run ty check src/dbt_chequer
```

Use `TYPE_CHECKING` for forward references:

```python
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from rich.panel import Panel

def get_check_info(check_name: str) -> "Panel | None":
    from rich.panel import Panel
    # ...
```

### Linting with ruff

Configuration in `pyproject.toml`:

```toml
[tool.ruff.lint]
select = ["E", "F", "I", "N", "W", "UP", "B", "C4", "SIM", "RUF"]
ignore = [
    "E501",    # Line too long
    "RUF001",  # Ambiguous unicode (emoji icons)
    "RUF012",  # Mutable class attributes (constant dicts)
    "SIM102",  # Nested if simplification
    "SIM105",  # Use contextlib.suppress
]
```

## Key Design Decisions

1. **Tool-specific configs** - Use standard config files each tool understands
2. **Typer for CLI** - Modern type-hint based CLI with Rich integration
3. **Subprocess for checks** - Wraps existing CLI tools rather than reimplementing
4. **Auto-detection** - Checks enabled based on config file presence
5. **Category-based reporting** - Group by quality category, not tool
6. **Jinja2 templates** - Flexible config generation from templates
7. **Context-aware hints** - Fix suggestions adapt based on what was attempted
8. **No emojis in code** - Clean, professional output

## Testing Strategy

### Manual Testing Workflow

1. Test in a sample dbt project:
   ```bash
   cd /path/to/test-dbt-project
   uv run --directory /path/to/dbt-chequer dbt-chequer init --force
   uv run --directory /path/to/dbt-chequer dbt-chequer check
   ```

2. Verify generated files:
   - `.sqlfluff` has correct dialect and rules
   - `dbt-bouncer.yml` has expected checks
   - `.pre-commit-config.yaml` has all hooks
   - `.github/workflows/dbt-quality.yml` has jobs

3. Test check execution:
   ```bash
   dbt-chequer check          # All checks
   dbt-chequer check --fix    # Auto-fix
   dbt-chequer status         # Verify detection
   dbt-chequer doctor         # Check diagnostics
   ```

### Future: Automated Tests

Add pytest tests for:
- Config generation from templates
- Check detection logic
- Violation parsing
- Category mapping
- Reporter output

## TODO / Future Features

- Add comprehensive pytest test suite
- Add dbt-checkpoint check wrapper (currently through prek)
- Add recce integration for data validation
- GitLab CI templates
- Azure DevOps templates
- Coverage trending and badge generation
- Slack/Teams notifications for daily run failures
- JSON output mode for programmatic usage
- Config validation and schema
- Check result caching
- Parallel check execution
