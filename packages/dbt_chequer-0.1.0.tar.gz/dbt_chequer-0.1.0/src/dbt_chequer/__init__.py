"""dbt-chequer - Setup wizard for dbt quality checks."""

__version__ = "0.1.0"

from dbt_chequer.cli import app

__all__ = ["__version__", "app"]
