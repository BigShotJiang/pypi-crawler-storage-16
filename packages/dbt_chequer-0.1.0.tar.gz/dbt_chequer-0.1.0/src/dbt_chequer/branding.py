"""Branding and visual elements for dbt-chequer."""

from rich.align import Align
from rich.console import Console, Group
from rich.panel import Panel
from rich.text import Text

# Checkerboard pattern using block characters (widely supported)
CHECKER_FULL = "█"  # U+2588 FULL BLOCK
CHECKER_LIGHT = "░"  # U+2591 LIGHT SHADE


def get_checker_line(length: int = 9, color: str = "red") -> Text:
    """Generate a checkerboard pattern line."""
    line = Text()
    for i in range(length):
        char = CHECKER_FULL if i % 2 == 0 else CHECKER_LIGHT
        line.append(char, style=color)
    return line


# Category icons - ASCII/Unicode alternatives to emojis
ICONS = {
    "formatting": "◈",  # Was 🎨
    "documentation": "≡",  # Was 📝
    "coverage": "▦",  # Was 📊
    "governance": "⬡",  # Was 📋
    "data_quality": "◎",  # Was 🔍
    "check": "✓",  # Checkmark
    "cross": "✗",  # X mark
    "warning": "⚠",  # Warning
    "info": "ℹ",  # Info
    "arrow": "»",  # Arrow/pointer
}

# Category colors
CATEGORY_COLORS = {
    "formatting": "magenta",
    "documentation": "cyan",
    "coverage": "yellow",
    "governance": "blue",
    "data_quality": "green",
}


def get_header(subtitle: str = "") -> Panel:
    """Get the branded header panel with nested boxes."""
    # Inner content - the title
    title_text = Text()
    title_text.append("dbt-chequer", style="bold white")

    title_panel = Panel(
        Align.center(title_text),
        border_style="white",
        padding=(0, 2),
    )

    # Build the checkerboard decoration
    checker_line = get_checker_line(9, "red")

    # Combine elements
    if subtitle:
        subtitle_text = Text(subtitle, style="dim")
        content = Group(
            Align.center(checker_line),
            title_panel,
            Align.center(subtitle_text),
        )
    else:
        content = Group(
            Align.center(checker_line),
            title_panel,
        )

    return Panel(
        content,
        border_style="red",
        padding=(0, 1),
    )


def get_category_icon(category: str) -> str:
    """Get the icon for a category."""
    return ICONS.get(category, "•")


def get_category_color(category: str) -> str:
    """Get the color for a category."""
    return CATEGORY_COLORS.get(category, "white")


def print_banner(console: Console, subtitle: str = "") -> None:
    """Print the branded banner."""
    console.print()
    console.print(get_header(subtitle))
    console.print()


def format_check_status(enabled: bool, name: str, tool: str = "") -> str:
    """Format a check status line."""
    icon = ICONS["check"] if enabled else ICONS["cross"]
    color = "green" if enabled else "dim"

    if enabled and tool:
        return f"[{color}]{icon}[/{color}] {name}  [{color}]{tool}[/{color}]"
    elif enabled:
        return f"[{color}]{icon}[/{color}] {name}"
    else:
        return f"[{color}]{icon} {name}[/{color}]"
