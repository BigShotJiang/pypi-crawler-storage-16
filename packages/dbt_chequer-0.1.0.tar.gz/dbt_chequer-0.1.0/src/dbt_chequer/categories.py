"""Category definitions and mapping for dbt-chequer checks."""

from dataclasses import dataclass, field
from enum import Enum


class Category(Enum):
    """Check categories for grouping violations by purpose."""

    FORMATTING = "formatting"
    DOCUMENTATION = "documentation"
    COVERAGE = "coverage"
    GOVERNANCE = "governance"
    DATA_QUALITY = "data_quality"


@dataclass
class CategoryInfo:
    """Display information for a category."""

    name: str
    icon: str
    description: str
    color: str = "white"  # Rich color for the category
    fix_hints: list[str] = field(default_factory=list)


# Category display information
CATEGORY_INFO: dict[Category, CategoryInfo] = {
    Category.FORMATTING: CategoryInfo(
        name="Formatting",
        icon="🎨",
        description="Code style and formatting issues",
        color="magenta",
        fix_hints=[
            "Run `dbt-chequer check --fix` to auto-format SQL files",
            "SQLFluff will fix indentation, spacing, and line length issues",
        ],
    ),
    Category.DOCUMENTATION: CategoryInfo(
        name="Documentation",
        icon="📝",
        description="Missing or incomplete documentation",
        color="cyan",
        fix_hints=[
            "Add descriptions to models in schema.yml files",
            "Use `dbt-checkpoint generate-model-properties-file` to scaffold",
            "Ensure all columns have descriptions in the properties file",
        ],
    ),
    Category.COVERAGE: CategoryInfo(
        name="Coverage",
        icon="📊",
        description="Test and documentation coverage metrics",
        color="yellow",
        fix_hints=[
            "Add tests for models in schema.yml using `tests:` block",
            "Run `dbt-coverage compute` to see detailed coverage report",
        ],
    ),
    Category.GOVERNANCE: CategoryInfo(
        name="Governance",
        icon="📋",
        description="Naming conventions, structure, and best practices",
        color="blue",
        fix_hints=[
            "Follow naming conventions: stg_*, int_*, fct_*, dim_*, rpt_*",
            "See: https://docs.getdbt.com/guides/best-practices",
        ],
    ),
    Category.DATA_QUALITY: CategoryInfo(
        name="Data Quality",
        icon="🔍",
        description="Source freshness, test types, and data contracts",
        color="green",
        fix_hints=[
            "Add freshness configuration to sources in schema.yml",
            "Ensure required test types (unique, not_null) are defined",
        ],
    ),
}


class CategoryMapper:
    """Maps tool rules to categories and provides fix hints."""

    # SQLFluff rule prefixes and their categories
    # Most SQLFluff rules are formatting-related
    SQLFLUFF_FORMATTING_PREFIXES = (
        "LT",  # Layout
        "AM",  # Ambiguous
        "CP",  # Capitalisation
        "CV",  # Convention
        "JJ",  # Jinja
        "RF",  # References
        "ST",  # Structure
        "AL",  # Aliasing
        "PRS",  # Parsing
    )

    # prek/pre-commit hooks and their categories
    PREK_CATEGORY_MAP = {
        # Formatting hooks
        "trailing-whitespace": Category.FORMATTING,
        "end-of-file-fixer": Category.FORMATTING,
        "check-yaml": Category.FORMATTING,
        "prettier": Category.FORMATTING,
        "sqlfluff-lint": Category.FORMATTING,
        "sqlfluff-fix": Category.FORMATTING,
        "fix end of files": Category.FORMATTING,
        "trim trailing whitespace": Category.FORMATTING,
        # Documentation hooks
        "check-model-has-description": Category.DOCUMENTATION,
        "check-model-columns-have-desc": Category.DOCUMENTATION,
        "check-model-has-properties-file": Category.DOCUMENTATION,
        "check-macro-has-description": Category.DOCUMENTATION,
        "check-macro-arguments-have-desc": Category.DOCUMENTATION,
        "check-column-desc-are-same": Category.DOCUMENTATION,
        "check-source-table-has-description": Category.DOCUMENTATION,
        "check-source-columns-have-desc": Category.DOCUMENTATION,
        # Governance hooks
        "check-model-name-contract": Category.GOVERNANCE,
        "check-model-has-tests": Category.GOVERNANCE,
        "check-model-has-tests-by-name": Category.GOVERNANCE,
        "check-model-has-tests-by-type": Category.GOVERNANCE,
        "check-model-has-meta-keys": Category.GOVERNANCE,
        # Data quality hooks
        "check-source-has-freshness": Category.DATA_QUALITY,
        "check-source-has-meta-keys": Category.DATA_QUALITY,
    }

    # dbt-bouncer rules and their categories
    DBT_BOUNCER_CATEGORY_MAP = {
        # Documentation rules
        "check_model_description_populated": Category.DOCUMENTATION,
        "check_column_description_populated": Category.DOCUMENTATION,
        "check_source_description_populated": Category.DOCUMENTATION,
        "check_macro_description_populated": Category.DOCUMENTATION,
        "check_columns_are_documented": Category.DOCUMENTATION,
        # Governance rules
        "check_model_names": Category.GOVERNANCE,
        "check_column_name_complies_to_column_type": Category.GOVERNANCE,
        "check_model_has_unique_test": Category.GOVERNANCE,
        "check_model_has_no_upstream_dependencies": Category.GOVERNANCE,
        "check_lineage": Category.GOVERNANCE,
        "check_model_max_fanout": Category.GOVERNANCE,
        "check_model_max_upstream_dependencies": Category.GOVERNANCE,
        # Data quality rules
        "check_source_freshness": Category.DATA_QUALITY,
        "check_source_has_freshness": Category.DATA_QUALITY,
    }

    # Rule-specific fix hints
    FIX_HINTS = {
        # Formatting
        "LT01": "Fix whitespace around operators and keywords",
        "LT02": "Fix indentation (use 4 spaces)",
        "LT05": "Reduce line length to under 100 characters",
        "LT15": "Remove extra blank lines",
        "RF02": "Qualify column references with table alias",
        # Documentation
        "check-model-has-description": "Add a description field in schema.yml",
        "check_model_description_populated": "Add a description to the model in schema.yml",
        "check-model-columns-have-desc": "Add descriptions to all columns in schema.yml",
        "check-model-has-properties-file": "Create a schema.yml file for this model",
        # Governance
        "check_model_names": "Rename model to follow convention: stg_*, int_*, fct_*, dim_*",
        "check-model-has-tests": "Add at least one test to the model in schema.yml",
        # Data quality
        "check-source-has-freshness": "Add freshness config to source in schema.yml",
    }

    def categorize(self, tool: str, rule: str) -> tuple[Category, str | None]:
        """Return (category, fix_hint) for a rule.

        Args:
            tool: The tool name (sqlfluff, prek, dbt_bouncer, dbt_coverage)
            rule: The rule/check name

        Returns:
            Tuple of (Category, optional fix hint)
        """
        category = self._get_category(tool, rule)
        fix_hint = self.FIX_HINTS.get(rule)
        return category, fix_hint

    def _get_category(self, tool: str, rule: str) -> Category:
        """Determine category for a tool/rule combination."""
        if tool == "sqlfluff":
            # SQLFluff rules are formatting by default
            return Category.FORMATTING

        if tool == "prek":
            # Look up in prek mapping, default to formatting
            return self.PREK_CATEGORY_MAP.get(rule, Category.FORMATTING)

        if tool == "dbt_bouncer":
            # Look up in bouncer mapping
            # Try exact match first
            if rule in self.DBT_BOUNCER_CATEGORY_MAP:
                return self.DBT_BOUNCER_CATEGORY_MAP[rule]
            # Try prefix match (e.g., check_model_description_populated:0:model_name)
            for key, cat in self.DBT_BOUNCER_CATEGORY_MAP.items():
                if rule.startswith(key):
                    return cat
            # Default to governance for unknown bouncer rules
            return Category.GOVERNANCE

        if tool == "dbt_coverage":
            return Category.COVERAGE

        # Default to formatting for unknown tools
        return Category.FORMATTING

    def get_category_info(self, category: Category) -> CategoryInfo:
        """Get display info for a category."""
        return CATEGORY_INFO[category]


# Singleton instance
category_mapper = CategoryMapper()
