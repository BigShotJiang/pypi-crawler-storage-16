"""Check runners for dbt-chequer."""

from typing import TYPE_CHECKING

from dbt_chequer.checks.base import CheckResult
from dbt_chequer.checks.runner import run_all_checks

if TYPE_CHECKING:
    from rich.panel import Panel

AVAILABLE_CHECKS = {
    "sqlfluff": "SQLFluff SQL linting and formatting",
    "dbt_bouncer": "dbt-bouncer governance and convention rules",
    "dbt_coverage": "dbt-coverage test and documentation coverage",
}


def get_check_info(check_name: str) -> "Panel | None":
    """Get information about a specific check."""
    from rich.markdown import Markdown
    from rich.panel import Panel

    info = {
        "sqlfluff": """
# SQLFluff

SQLFluff is a SQL linter and formatter that supports dbt templating.

## Features
- Linting with 50+ configurable rules
- Auto-fixing common issues
- dbt Jinja templating support

## Configuration
Configure in `.sqlfluff`:
```ini
[sqlfluff]
dialect = bigquery
templater = dbt
max_line_length = 100

[sqlfluff:rules:capitalisation.keywords]
capitalisation_policy = upper
```

Run `dbt-chequer init` to generate a `.sqlfluff` config.

## Links
- [SQLFluff Documentation](https://docs.sqlfluff.com/)
        """,
        "dbt_bouncer": """
# dbt-bouncer

dbt-bouncer enforces conventions and governance rules on your dbt project.

## Features
- Model naming conventions
- Required documentation
- Materialization policies
- Source freshness requirements

## Configuration
Configure in `dbt-bouncer.yml`:
```yaml
manifest_path: target/manifest.json

checks:
  - name: check_model_names
    model_name_pattern: ^(stg_|int_|fct_|dim_)
  - name: check_model_has_description
```

Run `dbt-chequer init` to generate a `dbt-bouncer.yml` config.

## Links
- [dbt-bouncer GitHub](https://github.com/godatadriven/dbt-bouncer)
        """,
        "dbt_coverage": """
# dbt-coverage

dbt-coverage measures test and documentation coverage for your dbt models.

## Features
- Test coverage reporting
- Documentation coverage reporting
- Threshold enforcement

## Usage
dbt-coverage automatically detects your manifest at `target/manifest.json`.
Run `dbt compile` first to generate the manifest.

## Links
- [dbt-coverage GitHub](https://github.com/slidoapp/dbt-coverage)
        """,
    }

    if check_name not in info:
        return None

    return Panel(Markdown(info[check_name]), title=f"Check: {check_name}")


__all__ = ["AVAILABLE_CHECKS", "CheckResult", "get_check_info", "run_all_checks"]
