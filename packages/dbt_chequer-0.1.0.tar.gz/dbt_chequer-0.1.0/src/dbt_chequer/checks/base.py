"""Base classes for check runners."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from dbt_chequer.categories import Category


@dataclass
class Violation:
    """A single violation from a check."""

    file: str
    line: int | None
    column: int | None
    rule: str
    message: str
    severity: Literal["error", "warning", "info"] = "error"
    category: "Category | None" = None
    fix_hint: str | None = None


@dataclass
class CheckResult:
    """Result from running a check."""

    name: str
    status: Literal["passed", "failed", "warning", "skipped"]
    summary: str
    violations: list[Violation] = field(default_factory=list)
    duration_ms: int = 0
    extra: dict = field(default_factory=dict)

    @property
    def passed(self) -> bool:
        return self.status == "passed"

    @property
    def failed(self) -> bool:
        return self.status == "failed"


class BaseCheck(ABC):
    """Base class for all checks.

    Each check auto-detects its own config file rather than relying on
    a unified configuration.
    """

    name: str = "base"
    description: str = "Base check"

    @abstractmethod
    def is_enabled(self) -> bool:
        """Check if this check can run (config file exists, tool available, etc.)."""
        pass

    @abstractmethod
    def run(self, fix: bool = False, changed_only: bool = False) -> CheckResult:
        """Run the check and return results."""
        pass

    def get_changed_files(self) -> list[str]:
        """Get list of changed files from git."""
        import subprocess

        try:
            # Get the merge base with main/master
            result = subprocess.run(
                ["git", "merge-base", "HEAD", "origin/main"],
                capture_output=True,
                text=True,
            )
            if result.returncode != 0:
                # Try master
                result = subprocess.run(
                    ["git", "merge-base", "HEAD", "origin/master"],
                    capture_output=True,
                    text=True,
                )

            if result.returncode != 0:
                return []

            base = result.stdout.strip()

            # Get changed files
            result = subprocess.run(
                ["git", "diff", "--name-only", base, "HEAD"],
                capture_output=True,
                text=True,
            )

            if result.returncode == 0:
                return [f for f in result.stdout.strip().split("\n") if f]

        except Exception:
            pass

        return []
