"""dbt-bouncer check implementation."""

import subprocess

from dbt_chequer.categories import category_mapper
from dbt_chequer.checks.base import BaseCheck, CheckResult, Violation
from dbt_chequer.config import detect_dbt_bouncer_config, detect_manifest


class DbtBouncerCheck(BaseCheck):
    """dbt-bouncer governance check.

    Auto-detects dbt-bouncer.yml config file in the project.
    """

    name = "dbt_bouncer"
    description = "dbt governance and convention rules"

    def __init__(self):
        self.config_path = detect_dbt_bouncer_config()
        self.manifest_path = detect_manifest()

    def is_enabled(self) -> bool:
        """dbt-bouncer is enabled if config file exists."""
        return self.config_path is not None

    def run(self, fix: bool = False, changed_only: bool = False) -> CheckResult:
        """Run dbt-bouncer checks."""
        # Check for manifest (dbt-bouncer expects it at target/manifest.json)
        if not self.manifest_path:
            return CheckResult(
                name=self.name,
                status="skipped",
                summary="Manifest not found. Run dbt compile first.",
            )

        if not self.config_path:
            return CheckResult(
                name=self.name,
                status="skipped",
                summary="No dbt-bouncer.yml config file found.",
            )

        # Build command - dbt-bouncer reads manifest from default location
        cmd = ["dbt-bouncer", "--config-file", str(self.config_path)]

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=120,
            )

            violations = self._parse_output(result.stdout + result.stderr)

            # dbt-bouncer returns 0 on success, non-zero on failure
            if result.returncode == 0:
                return CheckResult(
                    name=self.name,
                    status="passed",
                    summary="All governance rules passed",
                    violations=[],
                )
            else:
                if violations:
                    return CheckResult(
                        name=self.name,
                        status="failed",
                        summary=f"{len(violations)} rule(s) violated",
                        violations=violations,
                    )
                else:
                    # Non-zero exit but no parsed violations
                    error_msg = result.stderr.strip() or result.stdout.strip()
                    if error_msg:
                        if len(error_msg) > 200:
                            error_msg = error_msg[:200] + "..."
                        return CheckResult(
                            name=self.name,
                            status="failed",
                            summary=f"Error: {error_msg}",
                        )
                    else:
                        return CheckResult(
                            name=self.name,
                            status="failed",
                            summary="dbt-bouncer failed (unknown error)",
                        )

        except FileNotFoundError:
            return CheckResult(
                name=self.name,
                status="failed",
                summary="dbt-bouncer not installed. Run: pip install dbt-bouncer",
            )
        except subprocess.TimeoutExpired:
            return CheckResult(
                name=self.name,
                status="failed",
                summary="dbt-bouncer timed out",
            )

    def _parse_output(self, output: str) -> list[Violation]:
        """Parse dbt-bouncer output into violations."""
        violations = []

        # Parse the table format output from dbt-bouncer
        # Look for lines that contain "error" severity
        in_table = False
        for line in output.split("\n"):
            line = line.strip()

            # Detect table start (header separator)
            if line.startswith("|--") or line.startswith("|-"):
                in_table = True
                continue

            # Parse table rows
            if in_table and line.startswith("|") and "error" in line.lower():
                parts = [p.strip() for p in line.split("|") if p.strip()]
                if len(parts) >= 3:
                    check_name = parts[0]
                    severity = parts[1]
                    message = parts[2] if len(parts) > 2 else ""

                    category, fix_hint = category_mapper.categorize("dbt_bouncer", check_name)

                    violations.append(
                        Violation(
                            file="",
                            line=None,
                            column=None,
                            rule=check_name,
                            message=message,
                            severity="error" if severity.lower() == "error" else "warning",
                            category=category,
                            fix_hint=fix_hint,
                        )
                    )

        return violations
