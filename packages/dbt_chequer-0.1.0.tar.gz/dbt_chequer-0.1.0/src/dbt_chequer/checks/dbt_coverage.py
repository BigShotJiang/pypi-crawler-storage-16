"""dbt-coverage check implementation."""

import subprocess
from pathlib import Path

from dbt_chequer.categories import category_mapper
from dbt_chequer.checks.base import BaseCheck, CheckResult, Violation
from dbt_chequer.config import detect_manifest


class DbtCoverageCheck(BaseCheck):
    """dbt-coverage test and documentation coverage check.

    Auto-detects manifest and catalog files.
    """

    name = "dbt_coverage"
    description = "Test and documentation coverage for dbt models"

    def __init__(self, min_coverage: int = 80, fail_under: bool = True):
        self.manifest_path = detect_manifest()
        self.catalog_path = (
            Path("target/catalog.json") if Path("target/catalog.json").exists() else None
        )
        self.min_coverage = min_coverage
        self.fail_under = fail_under

    def is_enabled(self) -> bool:
        """dbt-coverage is enabled if manifest exists."""
        return self.manifest_path is not None

    def run(self, fix: bool = False, changed_only: bool = False) -> CheckResult:
        """Run dbt-coverage checks."""
        if not self.manifest_path:
            return CheckResult(
                name=self.name,
                status="skipped",
                summary="Manifest not found. Run dbt compile first.",
            )

        violations = []
        test_coverage = None
        doc_coverage = None

        # Run test coverage
        test_result = self._run_coverage("test", self.manifest_path)
        if test_result:
            test_coverage = test_result.get("coverage", 0)
            violations.extend(test_result.get("violations", []))

        # Run doc coverage
        if self.catalog_path:
            doc_result = self._run_coverage("doc", self.manifest_path, self.catalog_path)
            if doc_result:
                doc_coverage = doc_result.get("coverage", 0)
                violations.extend(doc_result.get("violations", []))

        # Determine overall coverage
        coverages = [c for c in [test_coverage, doc_coverage] if c is not None]
        avg_coverage = sum(coverages) / len(coverages) if coverages else 0

        # Build summary
        summary_parts = []
        if test_coverage is not None:
            summary_parts.append(f"Test: {test_coverage:.0f}%")
        if doc_coverage is not None:
            summary_parts.append(f"Doc: {doc_coverage:.0f}%")

        summary = ", ".join(summary_parts) if summary_parts else "No coverage data"

        # Determine status
        if avg_coverage >= self.min_coverage:
            status = "passed"
        elif self.fail_under:
            status = "failed"
            summary += f" (below {self.min_coverage}% threshold)"
        else:
            status = "warning"
            summary += f" (below {self.min_coverage}% threshold)"

        return CheckResult(
            name=self.name,
            status=status,
            summary=summary,
            violations=violations,
            extra={
                "test_coverage": test_coverage,
                "doc_coverage": doc_coverage,
            },
        )

    def _run_coverage(
        self,
        coverage_type: str,
        manifest_path: Path,
        catalog_path: Path | None = None,
    ) -> dict | None:
        """Run dbt-coverage for a specific type."""
        cmd = ["dbt-coverage", "compute", coverage_type]
        cmd.extend(["--manifest-path", str(manifest_path)])

        if catalog_path and coverage_type == "doc":
            cmd.extend(["--catalog-path", str(catalog_path)])

        cmd.append("--cov-report")

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=60,
            )

            return self._parse_coverage_output(result.stdout, coverage_type)

        except FileNotFoundError:
            return None
        except subprocess.TimeoutExpired:
            return None

    def _parse_coverage_output(self, output: str, coverage_type: str) -> dict:
        """Parse dbt-coverage output."""
        coverage = 0.0
        violations = []

        for line in output.split("\n"):
            # Look for coverage percentage
            if "Coverage:" in line or "coverage:" in line:
                try:
                    # Extract percentage from line like "Coverage: 85.0%"
                    parts = line.split(":")
                    if len(parts) >= 2:
                        pct_str = parts[1].strip().replace("%", "")
                        coverage = float(pct_str)
                except (ValueError, IndexError):
                    pass

            # Look for missing coverage entries
            if "missing" in line.lower() or "uncovered" in line.lower():
                rule = f"{coverage_type}_coverage"
                category, fix_hint = category_mapper.categorize("dbt_coverage", rule)

                violations.append(
                    Violation(
                        file="",
                        line=None,
                        column=None,
                        rule=rule,
                        message=line.strip(),
                        severity="warning",
                        category=category,
                        fix_hint=fix_hint,
                    )
                )

        return {
            "coverage": coverage,
            "violations": violations,
        }
