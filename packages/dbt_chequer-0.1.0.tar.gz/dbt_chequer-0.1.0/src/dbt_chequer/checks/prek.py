"""Prek (pre-commit) check implementation."""

import re
import shutil
import subprocess

from dbt_chequer.categories import category_mapper
from dbt_chequer.checks.base import BaseCheck, CheckResult, Violation
from dbt_chequer.config import detect_prek_config


class PrekCheck(BaseCheck):
    """Prek git hooks check.

    Runs prek (pre-commit compatible) hooks against the project.
    Auto-detects .pre-commit-config.yaml config file.
    """

    name = "prek"
    description = "Git hooks via prek"

    def __init__(self):
        self.config_path = detect_prek_config()

    def is_enabled(self) -> bool:
        """Prek is enabled if .pre-commit-config.yaml exists."""
        return self.config_path is not None

    def run(self, fix: bool = False, changed_only: bool = False) -> CheckResult:
        """Run prek hooks."""
        # Check if prek is installed
        if not shutil.which("prek"):
            return CheckResult(
                name=self.name,
                status="failed",
                summary="prek not installed. Run: brew install j178/tap/prek",
            )

        # Build command
        cmd = ["prek", "run"]
        if not changed_only:
            cmd.append("--all-files")

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300,  # 5 minute timeout
            )

            # Parse output for violations
            violations = self._parse_output(result.stdout + result.stderr)

            if result.returncode == 0:
                # Count hooks that passed
                passed_hooks = self._count_passed_hooks(result.stdout)
                return CheckResult(
                    name=self.name,
                    status="passed",
                    summary=f"All hooks passed ({passed_hooks} hooks)",
                    violations=[],
                )
            else:
                # Hooks failed
                failed_hooks = self._get_failed_hooks(result.stdout + result.stderr)
                return CheckResult(
                    name=self.name,
                    status="failed",
                    summary=f"{len(failed_hooks)} hook(s) failed: {', '.join(failed_hooks[:3])}",
                    violations=violations,
                )

        except FileNotFoundError:
            return CheckResult(
                name=self.name,
                status="failed",
                summary="prek not installed. Run: brew install j178/tap/prek",
            )
        except subprocess.TimeoutExpired:
            return CheckResult(
                name=self.name,
                status="failed",
                summary="prek timed out after 5 minutes",
            )

    def _parse_output(self, output: str) -> list[Violation]:
        """Parse prek output into violations."""
        violations = []
        current_hook = None

        for line in output.split("\n"):
            # Track current hook from "- hook id: xxx" lines
            hook_match = re.match(r"^- hook id:\s*(.+)$", line)
            if hook_match:
                current_hook = hook_match.group(1).strip()
                continue

            # Skip empty lines, status lines, and tracebacks
            stripped = line.strip()
            if not stripped:
                continue
            if stripped.startswith("check ") or stripped.startswith("fix "):
                continue
            if "..." in line and ("Passed" in line or "Failed" in line):
                continue
            if stripped.startswith("Traceback") or stripped.startswith("File "):
                continue
            if stripped.startswith("- exit code:") or stripped.startswith("- hook id:"):
                continue

            rule = current_hook or "prek"
            category, fix_hint = category_mapper.categorize("prek", rule)

            # Parse file:line:col: message format (SQLFluff, etc.)
            match = re.match(r"^\s*([^:]+\.(sql|py|yml|yaml)):(\d+):(\d+)?:?\s*(.+)$", line)
            if match:
                violations.append(
                    Violation(
                        file=match.group(1).strip(),
                        line=int(match.group(3)),
                        column=int(match.group(4)) if match.group(4) else None,
                        rule=rule,
                        message=match.group(5),
                        severity="error",
                        category=category,
                        fix_hint=fix_hint,
                    )
                )
                continue

            # Parse "file.sql: message" format (dbt-checkpoint style)
            match = re.match(r"^\s*([^:]+\.(sql|py|yml|yaml)):\s*(.+)$", line)
            if match:
                violations.append(
                    Violation(
                        file=match.group(1).strip(),
                        line=None,
                        column=None,
                        rule=rule,
                        message=match.group(3),
                        severity="error",
                        category=category,
                        fix_hint=fix_hint,
                    )
                )
                continue

            # Parse error messages that reference models (dbt-checkpoint)
            if "does not have" in stripped or "is missing" in stripped:
                # Try to extract model name
                model_match = re.search(r"(models/[^\s:]+\.sql)", stripped)
                if model_match:
                    violations.append(
                        Violation(
                            file=model_match.group(1),
                            line=None,
                            column=None,
                            rule=rule,
                            message=stripped,
                            severity="error",
                            category=category,
                            fix_hint=fix_hint,
                        )
                    )

        return violations

    def _count_passed_hooks(self, output: str) -> int:
        """Count number of passed hooks from output."""
        # Look for "Passed" or checkmark patterns
        passed = 0
        for line in output.split("\n"):
            if "Passed" in line or "✓" in line or line.strip().endswith("...Passed"):
                passed += 1
        return max(passed, 1)  # At least 1 if we got here

    def _get_failed_hooks(self, output: str) -> list[str]:
        """Extract names of failed hooks from output."""
        failed = []
        for line in output.split("\n"):
            # Look for "Failed" patterns
            if "Failed" in line or "✗" in line:
                # Try to extract hook name
                match = re.match(r"^([^.]+?)\.+\s*Failed", line)
                if match:
                    failed.append(match.group(1).strip())
                else:
                    # Just use the line itself
                    parts = line.split("...")
                    if parts:
                        failed.append(parts[0].strip())
        return failed if failed else ["unknown"]
