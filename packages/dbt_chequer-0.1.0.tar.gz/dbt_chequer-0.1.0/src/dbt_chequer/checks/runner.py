"""Main runner that coordinates all checks."""

import time

from rich.console import Console

from dbt_chequer.checks.base import CheckResult
from dbt_chequer.checks.dbt_bouncer import DbtBouncerCheck
from dbt_chequer.checks.dbt_coverage import DbtCoverageCheck
from dbt_chequer.checks.prek import PrekCheck
from dbt_chequer.checks.sqlfluff import SQLFluffCheck

# Check metadata for display
CHECK_INFO = {
    "sqlfluff": {
        "name": "SQLFluff",
        "description": "SQL linting and formatting",
        "icon": "🔍",
    },
    "dbt_bouncer": {
        "name": "dbt-bouncer",
        "description": "Governance and convention rules",
        "icon": "📋",
    },
    "dbt_coverage": {
        "name": "dbt-coverage",
        "description": "Test and documentation coverage",
        "icon": "📊",
    },
    "prek": {
        "name": "prek",
        "description": "Git hooks via prek",
        "icon": "🪝",
    },
}


def run_all_checks(
    only_checks: list[str] | None = None,
    fix: bool = False,
    changed_only: bool = False,
) -> list[CheckResult]:
    """Run all enabled checks and return results.

    Each check auto-detects its configuration from the project.
    """
    results: list[CheckResult] = []

    # Create check instances - they auto-detect their configs
    checks = {
        "sqlfluff": SQLFluffCheck(),
        "dbt_bouncer": DbtBouncerCheck(),
        "dbt_coverage": DbtCoverageCheck(),
        "prek": PrekCheck(),
    }

    for check_name, check in checks.items():
        # Skip if not in the only_checks filter
        if only_checks and check_name not in only_checks:
            continue

        # Skip if not enabled (config not found)
        if not check.is_enabled():
            results.append(
                CheckResult(
                    name=check_name,
                    status="skipped",
                    summary="Check not configured (config file not found)",
                )
            )
            continue

        # Run the check
        start_time = time.monotonic()
        try:
            result = check.run(fix=fix, changed_only=changed_only)
            result.duration_ms = int((time.monotonic() - start_time) * 1000)
            results.append(result)
        except Exception as e:
            results.append(
                CheckResult(
                    name=check_name,
                    status="failed",
                    summary=f"Check failed with error: {e}",
                    duration_ms=int((time.monotonic() - start_time) * 1000),
                )
            )

    return results


def run_all_checks_with_progress(
    console: Console,
    only_checks: list[str] | None = None,
    fix: bool = False,
    changed_only: bool = False,
) -> list[CheckResult]:
    """Run all enabled checks with spinner progress indicators.

    Each check auto-detects its configuration from the project.
    """
    results: list[CheckResult] = []

    # Create check instances - they auto-detect their configs
    checks = {
        "sqlfluff": SQLFluffCheck(),
        "dbt_bouncer": DbtBouncerCheck(),
        "dbt_coverage": DbtCoverageCheck(),
        "prek": PrekCheck(),
    }

    console.print()  # Add spacing

    for check_name, check in checks.items():
        info = CHECK_INFO.get(check_name, {"name": check_name, "description": "", "icon": "🔧"})

        # Skip if not in the only_checks filter
        if only_checks and check_name not in only_checks:
            continue

        # Skip if not enabled (config not found)
        if not check.is_enabled():
            console.print(f"  [dim]○[/dim] {info['name']}: [dim]skipped (not configured)[/dim]")
            results.append(
                CheckResult(
                    name=check_name,
                    status="skipped",
                    summary="Check not configured (config file not found)",
                )
            )
            continue

        # Run the check with spinner
        start_time = time.monotonic()
        with console.status(
            f"[bold blue]{info['icon']} Running {info['name']}...[/bold blue]", spinner="dots"
        ):
            try:
                result = check.run(fix=fix, changed_only=changed_only)
                result.duration_ms = int((time.monotonic() - start_time) * 1000)
                results.append(result)

                # Show result
                duration_str = f"[dim]({result.duration_ms}ms)[/dim]"
                if result.status == "passed":
                    console.print(
                        f"  [green]✓[/green] {info['name']}: [green]{result.summary}[/green] {duration_str}"
                    )
                elif result.status == "failed":
                    console.print(
                        f"  [red]✗[/red] {info['name']}: [red]{result.summary}[/red] {duration_str}"
                    )
                elif result.status == "warning":
                    console.print(
                        f"  [yellow]![/yellow] {info['name']}: [yellow]{result.summary}[/yellow] {duration_str}"
                    )
                else:
                    console.print(
                        f"  [dim]○[/dim] {info['name']}: [dim]{result.summary}[/dim] {duration_str}"
                    )

            except Exception as e:
                duration_ms = int((time.monotonic() - start_time) * 1000)
                results.append(
                    CheckResult(
                        name=check_name,
                        status="failed",
                        summary=f"Check failed with error: {e}",
                        duration_ms=duration_ms,
                    )
                )
                console.print(
                    f"  [red]✗[/red] {info['name']}: [red]Error: {e}[/red] [dim]({duration_ms}ms)[/dim]"
                )

    console.print()  # Add spacing
    return results
