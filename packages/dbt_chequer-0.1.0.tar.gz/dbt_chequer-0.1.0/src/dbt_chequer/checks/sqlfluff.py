"""SQLFluff check implementation."""

import subprocess
from pathlib import Path

from dbt_chequer.categories import category_mapper
from dbt_chequer.checks.base import BaseCheck, CheckResult, Violation
from dbt_chequer.config import detect_sqlfluff_config


class SQLFluffCheck(BaseCheck):
    """SQLFluff linting check.

    Auto-detects .sqlfluff config file in the project.
    """

    name = "sqlfluff"
    description = "SQL linting with SQLFluff"

    def __init__(self):
        self.config_path = detect_sqlfluff_config()

    def is_enabled(self) -> bool:
        """SQLFluff is enabled if .sqlfluff config exists or models/ directory exists."""
        return self.config_path is not None or Path("models").exists()

    def run(self, fix: bool = False, changed_only: bool = False) -> CheckResult:
        """Run SQLFluff linting."""
        # Determine files to check
        if changed_only:
            files = [f for f in self.get_changed_files() if f.endswith(".sql")]
            if not files:
                return CheckResult(
                    name=self.name,
                    status="passed",
                    summary="No SQL files changed",
                )
        else:
            # Check models directory by default
            files = ["models/"]
            if not Path("models").exists():
                return CheckResult(
                    name=self.name,
                    status="skipped",
                    summary="No models directory found",
                )

        # Build command - SQLFluff auto-detects .sqlfluff config
        if fix:
            # Run fix first, then lint to get remaining issues
            fix_cmd = ["sqlfluff", "fix", "--force"]
            fix_cmd.extend(files)

            try:
                subprocess.run(
                    fix_cmd,
                    capture_output=True,
                    text=True,
                    timeout=300,
                )
            except Exception:
                pass  # Continue to lint even if fix fails

        # Run lint to get violations (with JSON output)
        cmd = ["sqlfluff", "lint", "--format", "json"]
        cmd.extend(files)

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300,  # 5 minute timeout
            )

            # Parse JSON output
            violations = self._parse_output(result.stdout)

            if result.returncode == 0:
                summary = "All issues fixed" if fix else f"No issues found in {len(files)} file(s)"
                return CheckResult(
                    name=self.name,
                    status="passed",
                    summary=summary,
                    violations=[],
                    extra={"fix_attempted": fix},
                )
            elif result.returncode == 1:
                # Linting violations found
                error_count = len([v for v in violations if v.severity == "error"])
                warning_count = len([v for v in violations if v.severity == "warning"])

                summary = f"{error_count} errors, {warning_count} warnings"
                if fix:
                    summary += " (after fix)"

                return CheckResult(
                    name=self.name,
                    status="failed" if error_count > 0 else "warning",
                    summary=summary,
                    violations=violations,
                    extra={"fix_attempted": fix},
                )
            else:
                return CheckResult(
                    name=self.name,
                    status="failed",
                    summary=f"SQLFluff error: {result.stderr}",
                )

        except FileNotFoundError:
            return CheckResult(
                name=self.name,
                status="failed",
                summary="SQLFluff not installed. Run: pip install sqlfluff",
            )
        except subprocess.TimeoutExpired:
            return CheckResult(
                name=self.name,
                status="failed",
                summary="SQLFluff timed out after 5 minutes",
            )

    def _parse_output(self, output: str) -> list[Violation]:
        """Parse SQLFluff JSON output into violations."""
        import json

        violations = []

        if not output.strip():
            return violations

        try:
            data = json.loads(output)

            for file_result in data:
                filepath = file_result.get("filepath", "unknown")

                for violation in file_result.get("violations", []):
                    rule = violation.get("code", "unknown")
                    category, fix_hint = category_mapper.categorize("sqlfluff", rule)

                    violations.append(
                        Violation(
                            file=filepath,
                            line=violation.get("start_line_no"),
                            column=violation.get("start_line_pos"),
                            rule=rule,
                            message=violation.get("description", ""),
                            severity="error",  # SQLFluff doesn't distinguish
                            category=category,
                            fix_hint=fix_hint,
                        )
                    )

        except json.JSONDecodeError:
            pass

        return violations
