"""CLI for dbt-chequer - Setup wizard for dbt quality checks."""

from typing import Annotated

import typer
from rich.console import Console

app = typer.Typer(
    name="dbt-chequer",
    help="Setup wizard for dbt quality checks - configure SQLFluff, dbt-bouncer, and pre-commit hooks.",
    no_args_is_help=True,
)

console = Console()


def version_callback(value: bool) -> None:
    if value:
        console.print("dbt-chequer version 0.1.0")
        raise typer.Exit()


@app.callback()
def main(
    version: Annotated[
        bool | None,
        typer.Option(
            "--version", "-v", callback=version_callback, is_eager=True, help="Show version"
        ),
    ] = None,
) -> None:
    """Setup wizard for dbt quality checks."""
    pass


@app.command()
def init(
    force: Annotated[
        bool, typer.Option("--force", "-f", help="Overwrite existing configuration files")
    ] = False,
) -> None:
    """Initialize quality checks with an interactive wizard.

    Guides you through setting up SQLFluff, dbt-bouncer, dbt-checkpoint,
    and pre-commit hooks with sensible defaults.
    """
    from dbt_chequer.wizard import run_wizard

    run_wizard(force=force)


@app.command()
def status() -> None:
    """Show currently enabled quality gates.

    Displays which checks are configured in your project,
    grouped by category (formatting, documentation, etc).
    """
    from dbt_chequer.status import show_status

    show_status(console)


@app.command()
def checks(
    category: Annotated[
        str | None,
        typer.Argument(
            help="Filter by category (formatting, documentation, coverage, governance, data_quality)"
        ),
    ] = None,
) -> None:
    """List all available checks.

    Browse the catalog of checks from SQLFluff, dbt-bouncer,
    and dbt-checkpoint that can be enabled.
    """
    from dbt_chequer.status import list_checks

    list_checks(console, category)


@app.command()
def check(
    fix: Annotated[
        bool, typer.Option("--fix", help="Automatically fix issues where possible")
    ] = False,
    changed_only: Annotated[
        bool, typer.Option("--changed-only", help="Only check files changed since base branch")
    ] = False,
) -> None:
    """Run quality checks (delegates to underlying tools).

    This is a convenience command that runs the configured checks.
    For more control, run the individual tools directly:
      - sqlfluff lint models/
      - dbt-bouncer --config-file dbt-bouncer.yml
      - prek run --all-files
    """
    from dbt_chequer.checks.runner import run_all_checks_with_progress
    from dbt_chequer.reporter.console import ConsoleReporter

    reporter = ConsoleReporter(console)

    results = run_all_checks_with_progress(
        console=console,
        only_checks=None,
        fix=fix,
        changed_only=changed_only,
    )

    reporter.report(results)

    # Exit with error code if any check failed
    if any(r.status == "failed" for r in results):
        raise typer.Exit(1)


@app.command()
def doctor() -> None:
    """Diagnose your setup and check for common issues.

    Checks that required tools are installed and configuration
    files are valid.
    """
    from dbt_chequer.doctor import run_diagnostics

    run_diagnostics(console)


if __name__ == "__main__":
    app()
