"""Configuration detection for dbt-chequer.

Instead of a unified config file, dbt-chequer detects and uses existing
tool-specific config files directly.
"""

from pathlib import Path


def detect_sqlfluff_config() -> Path | None:
    """Detect SQLFluff config file."""
    for path in [".sqlfluff", "setup.cfg", "tox.ini", "pep8.ini"]:
        if Path(path).exists():
            return Path(path)
    return None


def detect_dbt_bouncer_config() -> Path | None:
    """Detect dbt-bouncer config file."""
    for path in ["dbt-bouncer.yml", "dbt_bouncer.yml"]:
        if Path(path).exists():
            return Path(path)
    return None


def detect_prek_config() -> Path | None:
    """Detect prek config file (.pre-commit-config.yaml format)."""
    path = Path(".pre-commit-config.yaml")
    return path if path.exists() else None


def detect_dbt_project() -> Path | None:
    """Detect dbt project file."""
    path = Path("dbt_project.yml")
    return path if path.exists() else None


def detect_manifest() -> Path | None:
    """Detect dbt manifest file."""
    path = Path("target/manifest.json")
    return path if path.exists() else None


def detect_all_configs() -> dict[str, Path | None]:
    """Detect all tool-specific config files."""
    return {
        "sqlfluff": detect_sqlfluff_config(),
        "dbt_bouncer": detect_dbt_bouncer_config(),
        "prek": detect_prek_config(),
        "dbt_project": detect_dbt_project(),
        "manifest": detect_manifest(),
    }
