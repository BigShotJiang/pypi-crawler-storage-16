"""Diagnostic tool for dbt-chequer setup."""

import shutil
import subprocess
from pathlib import Path

from rich.console import Console
from rich.table import Table


def run_diagnostics(console: Console) -> None:
    """Run diagnostics and report issues."""
    console.print("\n[bold]dbt-chequer Doctor[/bold]")
    console.print("Checking your setup...\n")

    checks = [
        ("dbt project detected", _check_dbt_project),
        ("dbt installed", _check_dbt_installed),
        (".sqlfluff config", _check_sqlfluff_config),
        ("SQLFluff installed", _check_sqlfluff_installed),
        ("dbt-bouncer.yml config", _check_bouncer_config),
        ("dbt-bouncer installed", _check_bouncer_installed),
        ("dbt-coverage installed", _check_coverage_installed),
        ("prek config", _check_prek_config),
        ("prek installed", _check_prek_installed),
        ("Git repository", _check_git_repo),
        ("manifest.json exists", _check_manifest),
    ]

    table = Table(show_header=True, header_style="bold")
    table.add_column("Check")
    table.add_column("Status")
    table.add_column("Details")

    issues = []

    for name, check_fn in checks:
        try:
            passed, details = check_fn()
            status = "[green]✓[/green]" if passed else "[red]✗[/red]"
            table.add_row(name, status, details)
            if not passed:
                issues.append((name, details))
        except Exception as e:
            table.add_row(name, "[yellow]?[/yellow]", str(e))

    console.print(table)

    if issues:
        console.print("\n[bold yellow]Issues found:[/bold yellow]")
        for name, details in issues:
            console.print(f"  • {name}: {details}")

        console.print("\n[bold]Suggested fixes:[/bold]")
        for name, _details in issues:
            fix = _get_fix_suggestion(name)
            if fix:
                console.print(f"  • {fix}")
    else:
        console.print("\n[bold green]All checks passed![/bold green]")


def _check_dbt_project() -> tuple[bool, str]:
    """Check if dbt project exists."""
    if Path("dbt_project.yml").exists():
        return True, "Found dbt_project.yml"
    # Check common subdirectories
    for subdir in ["dbt", "transform", "analytics"]:
        if Path(subdir, "dbt_project.yml").exists():
            return True, f"Found in {subdir}/"
    return False, "No dbt_project.yml found"


def _check_dbt_installed() -> tuple[bool, str]:
    """Check if dbt is installed."""
    if shutil.which("dbt"):
        try:
            result = subprocess.run(
                ["dbt", "--version"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            # Extract version from output
            for line in result.stdout.split("\n"):
                if "core" in line.lower():
                    return True, line.strip()
            return True, "Installed"
        except Exception:
            return True, "Installed"
    return False, "pip install dbt-core"


def _check_sqlfluff_config() -> tuple[bool, str]:
    """Check if .sqlfluff config exists."""
    if Path(".sqlfluff").exists():
        return True, "Found .sqlfluff"
    return False, "Run: dbt-chequer init"


def _check_sqlfluff_installed() -> tuple[bool, str]:
    """Check if SQLFluff is installed."""
    if shutil.which("sqlfluff"):
        try:
            result = subprocess.run(
                ["sqlfluff", "version"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            return True, f"v{result.stdout.strip()}"
        except Exception:
            return True, "Installed"
    return False, "pip install sqlfluff"


def _check_bouncer_config() -> tuple[bool, str]:
    """Check if dbt-bouncer.yml config exists."""
    for path in ["dbt-bouncer.yml", "dbt_bouncer.yml"]:
        if Path(path).exists():
            return True, f"Found {path}"
    return False, "Run: dbt-chequer init"


def _check_bouncer_installed() -> tuple[bool, str]:
    """Check if dbt-bouncer is installed."""
    if shutil.which("dbt-bouncer"):
        return True, "Installed"
    return False, "pip install dbt-bouncer"


def _check_coverage_installed() -> tuple[bool, str]:
    """Check if dbt-coverage is installed."""
    if shutil.which("dbt-coverage"):
        return True, "Installed"
    return False, "pip install dbt-coverage"


def _check_prek_config() -> tuple[bool, str]:
    """Check if .pre-commit-config.yaml exists (used by prek)."""
    if Path(".pre-commit-config.yaml").exists():
        return True, "Found .pre-commit-config.yaml"
    return False, "Run: dbt-chequer init"


def _check_prek_installed() -> tuple[bool, str]:
    """Check if prek is installed."""
    if shutil.which("prek"):
        # Check if hooks are installed
        if Path(".git/hooks/pre-commit").exists():
            return True, "Installed & hooks active"
        return True, "Installed (hooks not active)"
    return False, "brew install j178/tap/prek"


def _check_git_repo() -> tuple[bool, str]:
    """Check if we're in a git repository."""
    if Path(".git").is_dir():
        return True, "Git repository"
    return False, "Not a git repository"


def _check_manifest() -> tuple[bool, str]:
    """Check if dbt manifest exists."""
    manifest = Path("target/manifest.json")
    if manifest.exists():
        # Get file size
        size_kb = manifest.stat().st_size / 1024
        return True, f"Found ({size_kb:.0f} KB)"
    return False, "Run: dbt compile"


def _get_fix_suggestion(check_name: str) -> str | None:
    """Get fix suggestion for a failed check."""
    suggestions = {
        ".sqlfluff config": "Run: dbt-chequer init",
        "dbt-bouncer.yml config": "Run: dbt-chequer init",
        "prek config": "Run: dbt-chequer init",
        "dbt installed": "Run: pip install dbt-core dbt-<adapter>",
        "SQLFluff installed": "Run: pip install sqlfluff",
        "dbt-bouncer installed": "Run: pip install dbt-bouncer",
        "dbt-coverage installed": "Run: pip install dbt-coverage",
        "prek installed": "Run: brew install j178/tap/prek && prek install",
        "manifest.json exists": "Run: dbt compile",
    }
    return suggestions.get(check_name)
