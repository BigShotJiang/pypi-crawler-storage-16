"""Check Registry - Comprehensive catalog of all available checks."""

from dataclasses import dataclass
from enum import Enum


class Category(Enum):
    """Check categories for grouping by purpose."""

    FORMATTING = "formatting"
    DOCUMENTATION = "documentation"
    COVERAGE = "coverage"
    GOVERNANCE = "governance"
    DATA_QUALITY = "data_quality"


class Tool(Enum):
    """Tools that provide checks."""

    SQLFLUFF = "sqlfluff"
    DBT_BOUNCER = "dbt-bouncer"
    DBT_CHECKPOINT = "dbt-checkpoint"
    PRE_COMMIT = "pre-commit"


@dataclass
class CheckDefinition:
    """Definition of a single check."""

    id: str
    name: str
    description: str
    category: Category
    tool: Tool
    severity: str = "error"  # "error" | "warning"
    default_enabled: bool = False
    preset_relaxed: bool = False
    preset_standard: bool = False
    preset_strict: bool = True
    config_key: str = ""  # Key used in config files
    docs_url: str | None = None


@dataclass
class CategoryInfo:
    """Display information for a category."""

    name: str
    icon: str
    description: str
    color: str


CATEGORY_INFO: dict[Category, CategoryInfo] = {
    Category.FORMATTING: CategoryInfo(
        name="Formatting",
        icon="◈",
        description="SQL style, whitespace, indentation",
        color="magenta",
    ),
    Category.DOCUMENTATION: CategoryInfo(
        name="Documentation",
        icon="≡",
        description="Model, column, and macro descriptions",
        color="cyan",
    ),
    Category.COVERAGE: CategoryInfo(
        name="Coverage",
        icon="▦",
        description="Test coverage thresholds",
        color="yellow",
    ),
    Category.GOVERNANCE: CategoryInfo(
        name="Governance",
        icon="⬡",
        description="Naming conventions, lineage rules",
        color="blue",
    ),
    Category.DATA_QUALITY: CategoryInfo(
        name="Data Quality",
        icon="◎",
        description="Source freshness, contracts",
        color="green",
    ),
}


# =============================================================================
# CHECK REGISTRY - All available checks from all tools
# =============================================================================

CHECKS: list[CheckDefinition] = [
    # =========================================================================
    # FORMATTING - SQLFluff rules
    # =========================================================================
    CheckDefinition(
        id="sqlfluff_indentation",
        name="SQL indentation",
        description="Enforce consistent indentation (4 spaces)",
        category=Category.FORMATTING,
        tool=Tool.SQLFLUFF,
        preset_relaxed=True,
        preset_standard=True,
        config_key="LT02",
    ),
    CheckDefinition(
        id="sqlfluff_keyword_case",
        name="SQL keyword capitalization",
        description="Keywords should be UPPERCASE (SELECT, FROM, WHERE)",
        category=Category.FORMATTING,
        tool=Tool.SQLFLUFF,
        preset_relaxed=True,
        preset_standard=True,
        config_key="CP01",
    ),
    CheckDefinition(
        id="sqlfluff_trailing_commas",
        name="Trailing commas",
        description="Use trailing commas in SELECT lists",
        category=Category.FORMATTING,
        tool=Tool.SQLFLUFF,
        preset_standard=True,
        config_key="LT04",
    ),
    CheckDefinition(
        id="sqlfluff_line_length",
        name="Line length limit",
        description="Lines should not exceed 100 characters",
        category=Category.FORMATTING,
        tool=Tool.SQLFLUFF,
        preset_standard=True,
        config_key="LT05",
    ),
    CheckDefinition(
        id="sqlfluff_qualified_references",
        name="Qualified column references",
        description="Columns should be qualified with table alias in JOINs",
        category=Category.FORMATTING,
        tool=Tool.SQLFLUFF,
        preset_strict=True,
        config_key="RF02",
    ),
    CheckDefinition(
        id="sqlfluff_consistent_aliases",
        name="Consistent table aliases",
        description="Table aliases should be consistent and explicit",
        category=Category.FORMATTING,
        tool=Tool.SQLFLUFF,
        preset_strict=True,
        config_key="AL05",
    ),
    # =========================================================================
    # FORMATTING - Pre-commit hooks
    # =========================================================================
    CheckDefinition(
        id="trailing_whitespace",
        name="Trailing whitespace",
        description="Remove trailing whitespace from all files",
        category=Category.FORMATTING,
        tool=Tool.PRE_COMMIT,
        preset_relaxed=True,
        preset_standard=True,
        config_key="trailing-whitespace",
    ),
    CheckDefinition(
        id="end_of_file",
        name="End of file newline",
        description="Ensure files end with a newline",
        category=Category.FORMATTING,
        tool=Tool.PRE_COMMIT,
        preset_relaxed=True,
        preset_standard=True,
        config_key="end-of-file-fixer",
    ),
    CheckDefinition(
        id="check_yaml",
        name="YAML syntax",
        description="Validate YAML file syntax",
        category=Category.FORMATTING,
        tool=Tool.PRE_COMMIT,
        preset_relaxed=True,
        preset_standard=True,
        config_key="check-yaml",
    ),
    # =========================================================================
    # DOCUMENTATION - dbt-checkpoint hooks
    # =========================================================================
    CheckDefinition(
        id="model_has_description",
        name="Models have descriptions",
        description="Every model must have a description in schema.yml",
        category=Category.DOCUMENTATION,
        tool=Tool.DBT_CHECKPOINT,
        preset_standard=True,
        config_key="check-model-has-description",
    ),
    CheckDefinition(
        id="model_columns_have_desc",
        name="Columns have descriptions",
        description="All columns in schema.yml must have descriptions",
        category=Category.DOCUMENTATION,
        tool=Tool.DBT_CHECKPOINT,
        preset_strict=True,
        config_key="check-model-columns-have-desc",
    ),
    CheckDefinition(
        id="model_has_properties_file",
        name="Models have properties file",
        description="Every model must have a corresponding schema.yml entry",
        category=Category.DOCUMENTATION,
        tool=Tool.DBT_CHECKPOINT,
        preset_strict=True,
        config_key="check-model-has-properties-file",
    ),
    CheckDefinition(
        id="macro_has_description",
        name="Macros have descriptions",
        description="Every macro must have a description",
        category=Category.DOCUMENTATION,
        tool=Tool.DBT_CHECKPOINT,
        preset_strict=True,
        config_key="check-macro-has-description",
    ),
    CheckDefinition(
        id="macro_arguments_have_desc",
        name="Macro arguments have descriptions",
        description="All macro arguments must be documented",
        category=Category.DOCUMENTATION,
        tool=Tool.DBT_CHECKPOINT,
        preset_strict=True,
        config_key="check-macro-arguments-have-desc",
    ),
    # =========================================================================
    # DOCUMENTATION - dbt-bouncer checks
    # =========================================================================
    CheckDefinition(
        id="bouncer_model_description",
        name="Model description populated",
        description="Model descriptions must not be empty",
        category=Category.DOCUMENTATION,
        tool=Tool.DBT_BOUNCER,
        preset_standard=True,
        config_key="check_model_description_populated",
    ),
    CheckDefinition(
        id="bouncer_column_description",
        name="Column description populated",
        description="Column descriptions must not be empty",
        category=Category.DOCUMENTATION,
        tool=Tool.DBT_BOUNCER,
        preset_strict=True,
        config_key="check_column_description_populated",
    ),
    # =========================================================================
    # COVERAGE - dbt-checkpoint hooks
    # =========================================================================
    CheckDefinition(
        id="model_has_tests",
        name="Models have tests",
        description="Every model must have at least one test",
        category=Category.COVERAGE,
        tool=Tool.DBT_CHECKPOINT,
        preset_standard=True,
        config_key="check-model-has-tests",
    ),
    CheckDefinition(
        id="model_has_tests_by_name",
        name="Models have specific tests",
        description="Models must have specific named tests (unique, not_null)",
        category=Category.COVERAGE,
        tool=Tool.DBT_CHECKPOINT,
        preset_strict=True,
        config_key="check-model-has-tests-by-name",
    ),
    CheckDefinition(
        id="source_has_freshness",
        name="Sources have freshness",
        description="All sources must have freshness checks configured",
        category=Category.COVERAGE,
        tool=Tool.DBT_CHECKPOINT,
        preset_strict=True,
        config_key="check-source-has-freshness",
    ),
    # =========================================================================
    # GOVERNANCE - dbt-bouncer checks
    # =========================================================================
    CheckDefinition(
        id="bouncer_model_names",
        name="Model naming convention",
        description="Models must follow naming pattern (stg_, int_, fct_, dim_)",
        category=Category.GOVERNANCE,
        tool=Tool.DBT_BOUNCER,
        preset_standard=True,
        config_key="check_model_names",
        docs_url="https://godatadriven.github.io/dbt-bouncer/checks/manifest/check_model_names/",
    ),
    CheckDefinition(
        id="bouncer_model_directories",
        name="Model directory structure",
        description="Models must be in correct directories (staging/, marts/)",
        category=Category.GOVERNANCE,
        tool=Tool.DBT_BOUNCER,
        preset_strict=True,
        config_key="check_model_directories",
    ),
    CheckDefinition(
        id="bouncer_no_upstream_dependencies",
        name="Staging models have no dependencies",
        description="Staging models should only reference sources",
        category=Category.GOVERNANCE,
        tool=Tool.DBT_BOUNCER,
        preset_strict=True,
        config_key="check_model_has_no_upstream_dependencies",
    ),
    # =========================================================================
    # GOVERNANCE - dbt-checkpoint hooks
    # =========================================================================
    CheckDefinition(
        id="model_name_contract",
        name="Model name contract",
        description="Model names must match a defined pattern",
        category=Category.GOVERNANCE,
        tool=Tool.DBT_CHECKPOINT,
        preset_strict=True,
        config_key="check-model-name-contract",
    ),
    CheckDefinition(
        id="script_ref_and_source",
        name="Use ref() and source()",
        description="Models must use ref() and source() macros, not direct references",
        category=Category.GOVERNANCE,
        tool=Tool.DBT_CHECKPOINT,
        preset_standard=True,
        config_key="check-script-ref-and-source",
    ),
    CheckDefinition(
        id="script_semicolon",
        name="No trailing semicolons",
        description="SQL files should not end with semicolons",
        category=Category.GOVERNANCE,
        tool=Tool.DBT_CHECKPOINT,
        preset_standard=True,
        config_key="check-script-semicolon",
    ),
    # =========================================================================
    # DATA QUALITY - dbt-bouncer checks
    # =========================================================================
    CheckDefinition(
        id="bouncer_source_freshness",
        name="Source freshness configured",
        description="All sources must have freshness configuration",
        category=Category.DATA_QUALITY,
        tool=Tool.DBT_BOUNCER,
        preset_strict=True,
        config_key="check_source_has_freshness",
    ),
    CheckDefinition(
        id="bouncer_unique_test",
        name="Models have unique test",
        description="All models should have a unique/primary key test",
        category=Category.DATA_QUALITY,
        tool=Tool.DBT_BOUNCER,
        preset_strict=True,
        config_key="check_model_has_unique_test",
    ),
]


class CheckRegistry:
    """Registry for browsing and filtering checks."""

    def __init__(self):
        self.checks = CHECKS

    def get_all(self) -> list[CheckDefinition]:
        """Get all registered checks."""
        return self.checks

    def get_by_category(self, category: Category) -> list[CheckDefinition]:
        """Get checks for a specific category."""
        return [c for c in self.checks if c.category == category]

    def get_by_tool(self, tool: Tool) -> list[CheckDefinition]:
        """Get checks provided by a specific tool."""
        return [c for c in self.checks if c.tool == tool]

    def get_by_preset(self, preset: str) -> list[CheckDefinition]:
        """Get checks enabled in a preset (relaxed, standard, strict)."""
        if preset == "relaxed":
            return [c for c in self.checks if c.preset_relaxed]
        elif preset == "standard":
            return [c for c in self.checks if c.preset_standard]
        elif preset == "strict":
            return [c for c in self.checks if c.preset_strict]
        return []

    def get_by_id(self, check_id: str) -> CheckDefinition | None:
        """Get a specific check by ID."""
        for c in self.checks:
            if c.id == check_id:
                return c
        return None

    def get_categories_summary(self, preset: str) -> dict[Category, int]:
        """Get count of checks per category for a preset."""
        checks = self.get_by_preset(preset)
        summary = {}
        for category in Category:
            count = len([c for c in checks if c.category == category])
            summary[category] = count
        return summary


# Singleton instance
registry = CheckRegistry()
