"""Console reporter with rich formatting."""

from collections import defaultdict

from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from dbt_chequer.categories import CATEGORY_INFO, Category
from dbt_chequer.checks.base import CheckResult, Violation


class ConsoleReporter:
    """Rich console reporter for check results."""

    def __init__(self, console: Console | None = None):
        self.console = console or Console()

    # Maps checks to the categories they cover
    CHECK_CATEGORY_COVERAGE = {
        "sqlfluff": [Category.FORMATTING],
        "dbt_bouncer": [Category.DOCUMENTATION, Category.GOVERNANCE, Category.DATA_QUALITY],
        "dbt_coverage": [Category.COVERAGE],
        "prek": [
            Category.FORMATTING,
            Category.DOCUMENTATION,
            Category.GOVERNANCE,
            Category.DATA_QUALITY,
        ],
    }

    def report(self, results: list[CheckResult]) -> None:
        """Report check results to console, grouped by category."""
        self.console.print()
        self.console.print(
            Panel.fit(
                "[bold blue]dbt-chequer[/bold blue] Results",
                subtitle=f"{len(results)} checks",
            )
        )
        self.console.print()

        # Collect all violations from all results
        all_violations = []
        for result in results:
            all_violations.extend(result.violations)

        # Group violations by category
        by_category = self._group_by_category(all_violations)

        # Track which categories had checks that failed without violations
        failed_checks_by_category = self._get_failed_checks_by_category(results)

        # Build category summary table
        table = Table(show_header=True, header_style="bold")
        table.add_column("Category", style="cyan")
        table.add_column("Status")
        table.add_column("Summary")
        table.add_column("Issues", justify="right")

        category_results = {}
        for category in Category:
            info = CATEGORY_INFO[category]
            violations = by_category.get(category, [])
            count = len(violations)
            failed_checks = failed_checks_by_category.get(category, [])

            # If checks failed without producing violations, mark as uncertain
            if count == 0 and failed_checks:
                status = "[yellow]⚠ Warn[/yellow]"
                summary = f"Check(s) failed to run: {', '.join(failed_checks)}"
                result_status = "warning"
            elif count == 0:
                status = "[green]✓ Pass[/green]"
                summary = "All checks passed"
                result_status = "passed"
            else:
                status = "[red]✗ Fail[/red]"
                summary = self._get_category_summary(category, violations)
                result_status = "failed"

            category_results[category] = {
                "status": result_status,
                "count": count,
            }

            table.add_row(
                f"{info.icon} {info.name}",
                status,
                summary,
                str(count) if count > 0 else "-",
            )

        self.console.print(table)
        self.console.print()

        # Show violations grouped by category
        self._print_violations_by_category(by_category)

        # Show fix suggestions at the end
        self._print_fix_suggestions(by_category, results)

        # Final summary
        passed = sum(1 for r in category_results.values() if r["status"] == "passed")
        failed = sum(1 for r in category_results.values() if r["status"] == "failed")
        warnings = sum(1 for r in category_results.values() if r["status"] == "warning")

        self.console.print("─" * 50)
        summary_parts = []
        if passed:
            summary_parts.append(f"[green]{passed} passed[/green]")
        if warnings:
            summary_parts.append(f"[yellow]{warnings} warning[/yellow]")
        if failed:
            summary_parts.append(f"[red]{failed} failed[/red]")

        self.console.print(f"Summary: {', '.join(summary_parts)}")
        self.console.print()

    def _group_by_category(self, violations: list[Violation]) -> dict[Category, list[Violation]]:
        """Group violations by their category."""
        by_category: dict[Category, list[Violation]] = defaultdict(list)

        for v in violations:
            # Use the violation's category, or default to FORMATTING
            category = v.category or Category.FORMATTING
            by_category[category].append(v)

        return by_category

    def _get_failed_checks_by_category(
        self, results: list[CheckResult]
    ) -> dict[Category, list[str]]:
        """Track which checks failed without producing violations.

        Returns a dict mapping categories to list of check names that failed.
        """
        failed_by_category: dict[Category, list[str]] = defaultdict(list)

        for result in results:
            # Only track checks that failed but produced no violations
            if result.status == "failed" and len(result.violations) == 0:
                # Get categories this check covers
                categories = self.CHECK_CATEGORY_COVERAGE.get(result.name, [])
                check_display_name = result.name.replace("_", "-")

                for category in categories:
                    failed_by_category[category].append(check_display_name)

        return failed_by_category

    def _get_category_summary(self, category: Category, violations: list[Violation]) -> str:
        """Get a summary description for a category's violations."""
        count = len(violations)

        if category == Category.FORMATTING:
            return f"{count} formatting issue(s)"
        elif category == Category.DOCUMENTATION:
            return f"{count} missing documentation"
        elif category == Category.COVERAGE:
            return f"{count} coverage gap(s)"
        elif category == Category.GOVERNANCE:
            return f"{count} convention violation(s)"
        elif category == Category.DATA_QUALITY:
            return f"{count} data quality issue(s)"
        else:
            return f"{count} issue(s)"

    def _print_violations_by_category(self, by_category: dict[Category, list[Violation]]) -> None:
        """Print violations grouped by category in colored panels."""
        for category in Category:
            violations = by_category.get(category, [])
            if not violations:
                continue

            info = CATEGORY_INFO[category]

            # Group by file within category
            by_file: dict[str, list[Violation]] = defaultdict(list)
            for v in violations[:20]:  # Limit to 20 per category
                key = v.file or "(no file)"
                by_file[key].append(v)

            # Build panel content
            lines = []
            for filepath, file_violations in by_file.items():
                lines.append(f"[bold]{filepath}[/bold]")
                for v in file_violations:
                    loc = f":{v.line}" if v.line else ""
                    severity_color = "red" if v.severity == "error" else "yellow"
                    lines.append(
                        f"  [{severity_color}]{v.rule}[/{severity_color}]{loc}: {v.message}"
                    )
                lines.append("")  # Add spacing between files

            if len(violations) > 20:
                remaining = len(violations) - 20
                lines.append(f"[dim]... and {remaining} more issues[/dim]")

            # Remove trailing empty line
            if lines and lines[-1] == "":
                lines.pop()

            content = "\n".join(lines)

            # Create panel with category color
            panel = Panel(
                content,
                title=f"{info.icon} {info.name}",
                subtitle=f"{len(violations)} issue(s)",
                border_style=info.color,
                padding=(1, 2),
            )
            self.console.print()
            self.console.print(panel)

    def _print_fix_suggestions(
        self, by_category: dict[Category, list[Violation]], results: list[CheckResult]
    ) -> None:
        """Print fix suggestions grouped by category in a panel."""
        # Only show fix suggestions for categories with violations
        categories_with_violations = [c for c in Category if by_category.get(c)]

        if not categories_with_violations:
            return

        # Check if --fix was attempted for formatting checks
        fix_attempted = any(
            r.name == "sqlfluff" and r.extra.get("fix_attempted", False) for r in results
        )

        lines = []
        for category in categories_with_violations:
            info = CATEGORY_INFO[category]

            # Print category name with color
            lines.append(f"[{info.color}]{info.icon} {info.name}[/{info.color}]")

            # Provide context-aware hints
            if category == Category.FORMATTING and fix_attempted:
                # Remaining issues are not auto-fixable
                lines.append(
                    "  [dim]•[/dim] Remaining issues require manual fixes (auto-fix already attempted)"
                )
                lines.append(
                    "  [dim]•[/dim] Review SQLFluff rules: AM06 (ambiguous columns), RF02 (unqualified references)"
                )
            else:
                # Use default hints from category info
                for hint in info.fix_hints:
                    lines.append(f"  [dim]•[/dim] {hint}")

            lines.append("")  # Spacing between categories

        # Remove trailing empty line
        if lines and lines[-1] == "":
            lines.pop()

        content = "\n".join(lines)

        panel = Panel(
            content,
            title="How to fix",
            border_style="bright_white",
            padding=(1, 2),
        )
        self.console.print()
        self.console.print(panel)

    def _get_status_icon(self, status: str) -> str:
        """Get status icon for display."""
        icons = {
            "passed": "[green]✓ Pass[/green]",
            "failed": "[red]✗ Fail[/red]",
            "warning": "[yellow]⚠ Warn[/yellow]",
            "skipped": "[dim]○ Skip[/dim]",
        }
        return icons.get(status, status)

    def progress(self) -> Progress:
        """Get a progress bar for running checks."""
        return Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=self.console,
        )
