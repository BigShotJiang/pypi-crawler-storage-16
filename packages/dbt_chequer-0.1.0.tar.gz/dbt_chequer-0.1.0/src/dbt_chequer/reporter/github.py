"""GitHub reporter for PR comments and check annotations."""

import os
from datetime import UTC, datetime

import httpx

from dbt_chequer.checks.base import CheckResult
from dbt_chequer.templates import render_pr_comment


class GitHubReporter:
    """Reporter that creates/updates GitHub PR comments."""

    COMMENT_MARKER = "<!-- dbt-chequer-report -->"

    def __init__(self, token: str | None = None):
        self.token = token or os.environ.get("GITHUB_TOKEN")
        self.repo = os.environ.get("GITHUB_REPOSITORY")
        self.pr_number = self._get_pr_number()

    def _get_pr_number(self) -> int | None:
        """Get PR number from GitHub Actions context."""
        # From GITHUB_REF like refs/pull/123/merge
        ref = os.environ.get("GITHUB_REF", "")
        if "/pull/" in ref:
            try:
                return int(ref.split("/pull/")[1].split("/")[0])
            except (IndexError, ValueError):
                pass

        # From event payload
        event_path = os.environ.get("GITHUB_EVENT_PATH")
        if event_path:
            import json
            from pathlib import Path

            try:
                event = json.loads(Path(event_path).read_text())
                return event.get("pull_request", {}).get("number")
            except Exception:
                pass

        return None

    def report(self, results: list[CheckResult], config: dict | None = None) -> bool:
        """Create or update PR comment with results."""
        if not all([self.token, self.repo, self.pr_number]):
            return False

        # Build results dict for template
        results_dict = {
            "checks": [
                {
                    "name": r.name,
                    "status": r.status,
                    "summary": r.summary,
                }
                for r in results
            ],
            "timestamp": datetime.now(UTC).strftime("%Y-%m-%d %H:%M UTC"),
        }

        # Add detailed info
        for r in results:
            if r.name == "sqlfluff" and r.violations:
                results_dict["sqlfluff"] = {
                    "violations": [
                        {
                            "file": v.file,
                            "line": v.line,
                            "rule": v.rule,
                            "description": v.message,
                        }
                        for v in r.violations
                    ]
                }
            elif r.name == "dbt_coverage" and r.extra:
                results_dict["coverage"] = {
                    "test_coverage": r.extra.get("test_coverage"),
                    "doc_coverage": r.extra.get("doc_coverage"),
                    "missing_tests": [{"name": v.message, "reason": v.rule} for v in r.violations],
                }
            elif r.name == "dbt_bouncer" and r.violations:
                results_dict["bouncer"] = {
                    "violations": [{"rule": v.rule, "message": v.message} for v in r.violations]
                }

        # Render comment body
        body = render_pr_comment(results)
        body = f"{self.COMMENT_MARKER}\n{body}"

        # Find existing comment
        existing_comment_id = self._find_existing_comment()

        if existing_comment_id:
            return self._update_comment(existing_comment_id, body)
        else:
            return self._create_comment(body)

    def _find_existing_comment(self) -> int | None:
        """Find existing dbt-chequer comment on PR."""
        url = f"https://api.github.com/repos/{self.repo}/issues/{self.pr_number}/comments"

        try:
            response = httpx.get(
                url,
                headers={
                    "Authorization": f"Bearer {self.token}",
                    "Accept": "application/vnd.github+json",
                },
                timeout=30,
            )
            response.raise_for_status()

            for comment in response.json():
                if self.COMMENT_MARKER in comment.get("body", ""):
                    return comment["id"]

        except Exception:
            pass

        return None

    def _create_comment(self, body: str) -> bool:
        """Create a new PR comment."""
        url = f"https://api.github.com/repos/{self.repo}/issues/{self.pr_number}/comments"

        try:
            response = httpx.post(
                url,
                headers={
                    "Authorization": f"Bearer {self.token}",
                    "Accept": "application/vnd.github+json",
                },
                json={"body": body},
                timeout=30,
            )
            response.raise_for_status()
            return True

        except Exception:
            return False

    def _update_comment(self, comment_id: int, body: str) -> bool:
        """Update an existing PR comment."""
        url = f"https://api.github.com/repos/{self.repo}/issues/comments/{comment_id}"

        try:
            response = httpx.patch(
                url,
                headers={
                    "Authorization": f"Bearer {self.token}",
                    "Accept": "application/vnd.github+json",
                },
                json={"body": body},
                timeout=30,
            )
            response.raise_for_status()
            return True

        except Exception:
            return False

    def create_check_run_annotations(self, results: list[CheckResult]) -> bool:
        """Create GitHub check run annotations for violations."""
        if not all([self.token, self.repo]):
            return False

        sha = os.environ.get("GITHUB_SHA")
        if not sha:
            return False

        # Collect all annotations
        annotations = []
        for result in results:
            for v in result.violations[:50]:  # GitHub limits to 50
                if v.file and v.line:
                    annotations.append(
                        {
                            "path": v.file,
                            "start_line": v.line,
                            "end_line": v.line,
                            "annotation_level": ("failure" if v.severity == "error" else "warning"),
                            "message": f"[{v.rule}] {v.message}",
                        }
                    )

        if not annotations:
            return True

        # Create check run
        url = f"https://api.github.com/repos/{self.repo}/check-runs"

        try:
            response = httpx.post(
                url,
                headers={
                    "Authorization": f"Bearer {self.token}",
                    "Accept": "application/vnd.github+json",
                },
                json={
                    "name": "dbt-chequer",
                    "head_sha": sha,
                    "status": "completed",
                    "conclusion": "neutral",
                    "output": {
                        "title": "dbt-chequer Results",
                        "summary": f"Found {len(annotations)} issues",
                        "annotations": annotations,
                    },
                },
                timeout=30,
            )
            response.raise_for_status()
            return True

        except Exception:
            return False
