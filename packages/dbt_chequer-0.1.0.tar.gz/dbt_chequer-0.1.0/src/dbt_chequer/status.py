"""Status command - show currently enabled quality gates."""

from pathlib import Path

import yaml
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from dbt_chequer.branding import print_banner
from dbt_chequer.registry import (
    CATEGORY_INFO,
    Category,
    CheckDefinition,
    Tool,
    registry,
)


def show_status(console: Console) -> None:
    """Show the current status of quality gates."""
    from rich import box
    from rich.align import Align
    from rich.console import Group
    from rich.text import Text

    # Checkerboard pattern (2 lines)
    checker_line1 = Text("██░░██░░██░░██░░", style="red")
    checker_line2 = Text("░░██░░██░░██░░██", style="red")

    # Detect what's configured
    enabled_checks = _detect_enabled_checks()

    # Group by category
    by_category: dict[Category, list[CheckDefinition]] = {}
    for check in enabled_checks:
        if check.category not in by_category:
            by_category[check.category] = []
        by_category[check.category].append(check)

    # Build category panels
    category_panels = []
    for category in Category:
        info = CATEGORY_INFO[category]
        category_checks = by_category.get(category, [])
        all_category_checks = registry.get_by_category(category)

        # Build content for this category
        lines = []
        for check in all_category_checks:
            if check in enabled_checks:
                lines.append(f"[green]✓[/green] {check.name}  [dim]{check.tool.value}[/dim]")
            else:
                lines.append(f"[dim]✗ {check.name}[/dim]")

        if not lines:
            lines.append("[dim]No checks available[/dim]")

        # Count enabled
        enabled_count = len(category_checks)
        total_count = len(all_category_checks)

        panel = Panel(
            "\n".join(lines),
            title=f"{info.icon} {info.name}",
            subtitle=f"{enabled_count}/{total_count} enabled",
            border_style=info.color if enabled_count > 0 else "dim",
            padding=(0, 1),
        )
        category_panels.append(panel)

    # Stack panels vertically
    panels_group = Group(*category_panels)

    title_text = Text("dbt-chequer", style="bold white")
    subtitle_text = Text("Quality gates configured for this project", style="dim")

    # Combine everything into one outer panel
    inner_content = Group(
        Align.center(checker_line1),
        Align.center(checker_line2),
        "",
        Align.center(title_text),
        Align.center(subtitle_text),
        "",
        panels_group,
        "",
        Align.center(checker_line1),
        Align.center(checker_line2),
    )

    outer_panel = Panel(
        inner_content,
        border_style="red",
        box=box.ROUNDED,
        padding=(0, 1),
    )

    console.print()
    console.print(outer_panel)

    # Show config files detected
    console.print("[bold]Configuration files:[/bold]")
    config_files = [
        (".sqlfluff", "SQLFluff"),
        ("dbt-bouncer.yml", "dbt-bouncer"),
        (".pre-commit-config.yaml", "prek/pre-commit"),
        (".github/workflows/dbt-quality.yml", "GitHub Actions"),
    ]
    for path, name in config_files:
        if Path(path).exists():
            console.print(f"  [green]✓[/green] {name}: {path}")
        else:
            console.print(f"  [dim]✗ {name}: not configured[/dim]")

    console.print()
    console.print("[dim]Run 'dbt-chequer init' to configure more checks[/dim]")
    console.print()


def _detect_enabled_checks() -> list[CheckDefinition]:
    """Detect which checks are currently enabled by parsing config files."""
    enabled = []

    # Check SQLFluff config
    if Path(".sqlfluff").exists():
        # If sqlfluff config exists, all SQLFluff formatting checks are enabled
        # (the generated config includes all standard formatting rules)
        for check in registry.get_by_tool(Tool.SQLFLUFF):
            enabled.append(check)

    # Check dbt-bouncer config
    bouncer_path = Path("dbt-bouncer.yml")
    if bouncer_path.exists():
        try:
            with open(bouncer_path) as f:
                config = yaml.safe_load(f)

            if config:
                # Check manifest_checks
                manifest_checks = config.get("manifest_checks", [])
                for check_config in manifest_checks:
                    check_name = check_config.get("name", "")
                    for check in registry.get_by_tool(Tool.DBT_BOUNCER):
                        if check.config_key == check_name:
                            enabled.append(check)

                # Check catalog_checks (for column-level checks)
                catalog_checks = config.get("catalog_checks", [])
                for check_config in catalog_checks:
                    check_name = check_config.get("name", "")
                    for check in registry.get_by_tool(Tool.DBT_BOUNCER):
                        if check.config_key == check_name:
                            enabled.append(check)
        except Exception:
            pass

    # Check pre-commit config
    precommit_path = Path(".pre-commit-config.yaml")
    if precommit_path.exists():
        try:
            with open(precommit_path) as f:
                config = yaml.safe_load(f)

            if config and "repos" in config:
                for repo in config["repos"]:
                    hooks = repo.get("hooks", [])
                    for hook in hooks:
                        hook_id = hook.get("id", "")
                        # Match pre-commit hooks
                        for check in registry.get_by_tool(Tool.PRE_COMMIT):
                            if check.config_key == hook_id:
                                enabled.append(check)
                        # Match dbt-checkpoint hooks
                        for check in registry.get_by_tool(Tool.DBT_CHECKPOINT):
                            if check.config_key == hook_id:
                                enabled.append(check)
        except Exception:
            pass

    return enabled


def list_checks(console: Console, category: str | None = None) -> None:
    """List all available checks."""
    print_banner(console, "All checks that can be enabled")

    # Filter by category if specified
    if category:
        try:
            cat = Category(category.lower())
            categories = [cat]
        except ValueError:
            console.print(f"[red]Unknown category: {category}[/red]")
            console.print("Valid categories: " + ", ".join(c.value for c in Category))
            return
    else:
        categories = list(Category)

    for cat in categories:
        info = CATEGORY_INFO[cat]
        checks = registry.get_by_category(cat)

        table = Table(
            title=f"{info.icon} {info.name}",
            border_style=info.color,
            show_header=True,
            header_style="bold",
        )
        table.add_column("Check", style="white")
        table.add_column("Description", style="dim")
        table.add_column("Tool", style="cyan")
        table.add_column("Preset", style="yellow")

        for check in checks:
            # Determine which presets include this check
            presets = []
            if check.preset_relaxed:
                presets.append("R")
            if check.preset_standard:
                presets.append("S")
            if check.preset_strict:
                presets.append("*")

            table.add_row(
                check.name,
                check.description[:50] + "..."
                if len(check.description) > 50
                else check.description,
                check.tool.value,
                " ".join(presets),
            )

        console.print(table)
        console.print()

    console.print("[dim]Presets: R=Relaxed, S=Standard, *=Strict[/dim]")
    console.print()
