"""Template utilities for dbt-chequer."""

from jinja2 import Environment, PackageLoader, select_autoescape

# Set up Jinja2 environment for PR comment templates
env = Environment(
    loader=PackageLoader("dbt_chequer", "templates"),
    autoescape=select_autoescape(),
    trim_blocks=True,
    lstrip_blocks=True,
)


def render_pr_comment(results: list) -> str:
    """Render a PR comment from check results."""
    template = env.get_template("pr_comments/report.md.j2")
    return template.render(results=results)
