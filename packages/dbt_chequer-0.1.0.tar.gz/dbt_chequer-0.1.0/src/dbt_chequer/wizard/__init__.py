"""Interactive wizard for dbt-chequer setup."""

from dbt_chequer.wizard.core import run_wizard
from dbt_chequer.wizard.sqlfluff_config import configure_sqlfluff_rules

__all__ = ["configure_sqlfluff_rules", "run_wizard"]
