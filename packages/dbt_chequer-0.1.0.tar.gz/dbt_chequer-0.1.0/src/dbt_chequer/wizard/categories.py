"""Category-specific wizard questions for custom setup."""

from dataclasses import dataclass, field

import questionary
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

console = Console()


def _section_header(title: str, color: str = "cyan") -> Panel:
    """Create a consistent section header."""
    content = Text()
    content.append("▓░ ", style=f"bold {color}")
    content.append(title, style=f"bold {color}")
    content.append(" ░▓", style=f"bold {color}")
    return Panel(content, border_style=color, padding=(0, 1))


@dataclass
class SQLFluffConfig:
    """SQLFluff configuration options."""

    dialect: str = "duckdb"
    # Opinionated choices (user picks)
    keyword_case: str = "upper"  # upper, lower, capitalise
    comma_position: str = "trailing"  # trailing, leading
    # Sensible defaults (always applied)
    indent_spaces: int = 4
    max_line_length: int = 100
    explicit_aliasing: bool = True
    min_alias_length: int = 3
    cte_newline: bool = True
    use_left_join: bool = True
    not_equal_style: str = "!="  # != or <>


@dataclass
class DocumentationConfig:
    """Documentation configuration options."""

    require_model_descriptions: bool = True
    require_column_descriptions: bool = True
    require_model_properties_file: bool = True
    require_macro_descriptions: bool = True
    require_macro_arg_descriptions: bool = True


@dataclass
class CoverageConfig:
    """Test coverage configuration options."""

    require_model_tests: bool = True
    require_unique_tests: bool = False
    require_not_null_tests: bool = False


@dataclass
class GovernanceConfig:
    """Governance configuration options."""

    enforce_naming_convention: bool = True
    naming_pattern: str = "^(stg_|int_|fct_|dim_|rpt_)"
    enforce_directory_structure: bool = True
    enforce_staging_no_upstream: bool = True
    enforce_ref_source: bool = True
    no_trailing_semicolons: bool = True


@dataclass
class DataQualityConfig:
    """Data quality configuration options."""

    require_source_freshness: bool = True
    require_primary_key_tests: bool = True


@dataclass
class CustomConfig:
    """Complete custom configuration."""

    sqlfluff: SQLFluffConfig = field(default_factory=SQLFluffConfig)
    documentation: DocumentationConfig = field(default_factory=DocumentationConfig)
    coverage: CoverageConfig = field(default_factory=CoverageConfig)
    governance: GovernanceConfig = field(default_factory=GovernanceConfig)
    data_quality: DataQualityConfig = field(default_factory=DataQualityConfig)
    # Track which categories are enabled
    enabled_categories: list[str] = field(default_factory=list)


def run_custom_wizard(dialect: str = "duckdb") -> CustomConfig:
    """Run the interactive custom wizard for each category."""
    config = CustomConfig()
    config.sqlfluff.dialect = dialect

    # First, ask which categories to configure
    console.print()
    categories = questionary.checkbox(
        "Which categories do you want to configure?",
        choices=[
            questionary.Choice("Formatting (SQLFluff)", value="formatting", checked=True),
            questionary.Choice("Documentation", value="documentation", checked=True),
            questionary.Choice("Test Coverage", value="coverage", checked=True),
            questionary.Choice("Governance (naming, refs)", value="governance", checked=True),
            questionary.Choice(
                "Data Quality (freshness, contracts)", value="data_quality", checked=False
            ),
        ],
    ).ask()

    if categories is None:
        raise SystemExit(1)

    config.enabled_categories = categories

    # Run wizard for each selected category
    if "formatting" in categories:
        config.sqlfluff = _configure_sqlfluff(dialect)

    if "documentation" in categories:
        config.documentation = _configure_documentation()

    if "coverage" in categories:
        config.coverage = _configure_coverage()

    if "governance" in categories:
        config.governance = _configure_governance()

    if "data_quality" in categories:
        config.data_quality = _configure_data_quality()

    return config


def _configure_sqlfluff(dialect: str) -> SQLFluffConfig:
    """Configure SQLFluff with opinionated questions."""
    console.print()
    console.print(_section_header("SQLFluff Configuration", "magenta"))
    console.print()
    console.print(
        "[dim]Configure SQL formatting. Pick your preferences, then sensible defaults apply.[/dim]"
    )
    console.print()

    config = SQLFluffConfig(dialect=dialect)

    # Keyword capitalization
    keyword_case = questionary.select(
        "SQL keyword capitalization (SELECT, FROM, WHERE):",
        choices=[
            questionary.Choice("UPPERCASE (recommended)", value="upper"),
            questionary.Choice("lowercase", value="lower"),
            questionary.Choice("Capitalise", value="capitalise"),
        ],
        default="upper",
    ).ask()
    if keyword_case:
        config.keyword_case = keyword_case

    # Comma position
    comma_position = questionary.select(
        "Comma position in SELECT lists:",
        choices=[
            questionary.Choice("Trailing commas (recommended)", value="trailing"),
            questionary.Choice("Leading commas", value="leading"),
        ],
        default="trailing",
    ).ask()
    if comma_position:
        config.comma_position = comma_position

    # Show what sensible defaults will be applied
    console.print()
    console.print("[dim]Sensible defaults that will be applied:[/dim]")
    console.print("  - 4-space indentation")
    console.print("  - 100 character line length")
    console.print("  - Explicit table/column aliasing")
    console.print("  - Minimum 3-character alias names")
    console.print("  - Newlines between CTEs")
    console.print("  - LEFT JOIN instead of RIGHT JOIN")
    console.print("  - != instead of <> for not-equal")
    console.print("  - GROUP BY/ORDER BY with column numbers")
    console.print()

    return config


def _configure_documentation() -> DocumentationConfig:
    """Configure documentation requirements."""
    console.print()
    console.print(_section_header("Documentation Configuration", "cyan"))
    console.print()
    console.print("[dim]Configure what needs to be documented in your dbt project.[/dim]")
    console.print()

    config = DocumentationConfig()

    # Ask about documentation level
    doc_level = questionary.select(
        "Documentation coverage level:",
        choices=[
            questionary.Choice(
                "Full coverage (models + columns + macros) - recommended",
                value="full",
            ),
            questionary.Choice(
                "Models only (descriptions for all models)",
                value="models",
            ),
            questionary.Choice(
                "Minimal (no documentation requirements)",
                value="minimal",
            ),
        ],
        default="full",
    ).ask()

    if doc_level == "full":
        config.require_model_descriptions = True
        config.require_column_descriptions = True
        config.require_model_properties_file = True
        config.require_macro_descriptions = True
        config.require_macro_arg_descriptions = True
    elif doc_level == "models":
        config.require_model_descriptions = True
        config.require_column_descriptions = False
        config.require_model_properties_file = True
        config.require_macro_descriptions = False
        config.require_macro_arg_descriptions = False
    else:  # minimal
        config.require_model_descriptions = False
        config.require_column_descriptions = False
        config.require_model_properties_file = False
        config.require_macro_descriptions = False
        config.require_macro_arg_descriptions = False

    if doc_level != "minimal":
        console.print()
        console.print("[dim]This will ensure your project stays well-documented.[/dim]")

    return config


def _configure_coverage() -> CoverageConfig:
    """Configure test coverage requirements."""
    console.print()
    console.print(_section_header("Test Coverage Configuration", "yellow"))
    console.print()
    console.print("[dim]Configure testing requirements for your models.[/dim]")
    console.print()

    config = CoverageConfig()

    # Ask about test requirements
    test_level = questionary.select(
        "Test coverage level:",
        choices=[
            questionary.Choice(
                "Basic (every model has at least one test) - recommended",
                value="basic",
            ),
            questionary.Choice(
                "Strict (unique + not_null on primary keys)",
                value="strict",
            ),
            questionary.Choice(
                "None (no test requirements)",
                value="none",
            ),
        ],
        default="basic",
    ).ask()

    if test_level == "basic":
        config.require_model_tests = True
        config.require_unique_tests = False
        config.require_not_null_tests = False
    elif test_level == "strict":
        config.require_model_tests = True
        config.require_unique_tests = True
        config.require_not_null_tests = True
    else:  # none
        config.require_model_tests = False
        config.require_unique_tests = False
        config.require_not_null_tests = False

    return config


def _configure_governance() -> GovernanceConfig:
    """Configure governance rules."""
    console.print()
    console.print(_section_header("Governance Configuration", "blue"))
    console.print()
    console.print("[dim]Configure naming conventions and best practices.[/dim]")
    console.print()

    config = GovernanceConfig()

    # Governance level
    gov_level = questionary.select(
        "Governance strictness level:",
        choices=[
            questionary.Choice(
                "Full (naming + directories + staging isolation) - recommended",
                value="full",
            ),
            questionary.Choice(
                "Basic (naming conventions only)",
                value="basic",
            ),
            questionary.Choice(
                "Minimal (just ref/source and semicolons)",
                value="minimal",
            ),
        ],
        default="full",
    ).ask()

    if gov_level == "full":
        config.enforce_naming_convention = True
        config.enforce_directory_structure = True
        config.enforce_staging_no_upstream = True
        config.enforce_ref_source = True
        config.no_trailing_semicolons = True
    elif gov_level == "basic":
        config.enforce_naming_convention = True
        config.enforce_directory_structure = False
        config.enforce_staging_no_upstream = False
        config.enforce_ref_source = True
        config.no_trailing_semicolons = True
    else:  # minimal
        config.enforce_naming_convention = False
        config.enforce_directory_structure = False
        config.enforce_staging_no_upstream = False
        config.enforce_ref_source = True
        config.no_trailing_semicolons = True

    return config


def _configure_data_quality() -> DataQualityConfig:
    """Configure data quality checks."""
    console.print()
    console.print(_section_header("Data Quality Configuration", "green"))
    console.print()
    console.print("[dim]Configure data quality and freshness checks.[/dim]")
    console.print()

    config = DataQualityConfig()

    # Source freshness
    freshness = questionary.confirm(
        "Require freshness checks on all sources?",
        default=True,
    ).ask()
    config.require_source_freshness = freshness if freshness is not None else True

    # Primary key tests
    pk_tests = questionary.confirm(
        "Require unique/primary key tests on all models?",
        default=True,
    ).ask()
    config.require_primary_key_tests = pk_tests if pk_tests is not None else True

    return config
