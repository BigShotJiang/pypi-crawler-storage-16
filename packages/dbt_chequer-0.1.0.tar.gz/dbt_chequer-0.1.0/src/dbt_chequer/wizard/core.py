"""Core wizard logic for interactive setup."""

from pathlib import Path

import questionary
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from dbt_chequer.branding import print_banner
from dbt_chequer.registry import (
    CATEGORY_INFO,
    Category,
    registry,
)
from dbt_chequer.wizard.categories import run_custom_wizard
from dbt_chequer.wizard.detection import detect_dbt_project, detect_warehouse, get_sqlfluff_dialect
from dbt_chequer.wizard.generators import ConfigGenerator

console = Console()


def run_wizard(force: bool = False) -> None:
    """Run the interactive setup wizard."""
    print_banner(console, "Set up quality gates for your dbt project")

    # Detect dbt project
    console.print("\n[bold]Detecting your project...[/bold]")
    dbt_info = detect_dbt_project()

    if dbt_info:
        console.print(
            f"  [green]✓[/green] Found dbt_project.yml (dbt {dbt_info.get('version', 'unknown')})"
        )
    else:
        console.print("  [yellow]![/yellow] No dbt_project.yml found - setting up anyway")

    # Detect warehouse/adapter
    warehouse = detect_warehouse()
    dialect = get_sqlfluff_dialect(warehouse)
    if warehouse:
        console.print(f"  [green]✓[/green] Detected adapter: {warehouse}")
    else:
        console.print(f"  [dim]○[/dim] Could not detect adapter, using default dialect: {dialect}")

    console.print()

    # Select preset
    preset = _select_preset()

    if preset == "custom":
        # Run the detailed custom wizard
        custom_config = run_custom_wizard(dialect=dialect)

        # Show custom configuration summary
        _show_custom_configuration_summary(custom_config)

        # Check for existing files and warn
        existing_files = _check_existing_config_files(custom_config.enabled_categories)
        if existing_files:
            console.print()
            console.print(
                Panel(
                    "[yellow]The following files will be overwritten:[/yellow]\n"
                    + "\n".join(f"  • {f}" for f in existing_files),
                    border_style="yellow",
                )
            )

        # Confirm
        if not questionary.confirm("Generate configuration files?", default=True).ask():
            console.print("[dim]Cancelled[/dim]")
            raise SystemExit(0)

        # Generate configs from custom config (always overwrite in custom mode)
        generator = ConfigGenerator(dialect=dialect)
        generated_files = generator.generate_from_custom_config(custom_config, force=True)
    else:
        selected_checks = registry.get_by_preset(preset)

        # Show what will be configured
        _show_configuration_summary(preset, selected_checks)

        # Check for existing files and warn
        existing_files = _check_existing_config_files_for_preset()
        if existing_files:
            console.print()
            console.print(
                Panel(
                    "[yellow]The following files will be overwritten:[/yellow]\n"
                    + "\n".join(f"  • {f}" for f in existing_files),
                    border_style="yellow",
                )
            )

        # Confirm
        if not questionary.confirm("Generate configuration files?", default=True).ask():
            console.print("[dim]Cancelled[/dim]")
            raise SystemExit(0)

        # Generate configs (always overwrite)
        generator = ConfigGenerator(dialect=dialect)
        generated_files = generator.generate_all(selected_checks, force=True)

    # Show results
    console.print()
    console.print(
        Panel(
            "\n".join([f"[green]✓[/green] {f}" for f in generated_files]),
            title="Generated Files",
            border_style="green",
        )
    )

    # Next steps
    console.print()
    console.print("[bold]Next steps:[/bold]")
    console.print("  1. Review the generated configuration files")
    console.print("  2. Run [cyan]prek install[/cyan] to enable git hooks")
    console.print("  3. Run [cyan]dbt-chequer status[/cyan] to see your quality gates")
    console.print()


def _check_existing_config_files(enabled_categories: list[str]) -> list[str]:
    """Check which config files already exist for custom mode."""
    existing = []

    if "formatting" in enabled_categories:
        if Path(".sqlfluff").exists():
            existing.append(".sqlfluff")
        if Path(".sqlfluffignore").exists():
            existing.append(".sqlfluffignore")

    if any(cat in enabled_categories for cat in ["governance", "data_quality", "documentation"]):
        if Path("dbt-bouncer.yml").exists():
            existing.append("dbt-bouncer.yml")

    if Path(".pre-commit-config.yaml").exists():
        existing.append(".pre-commit-config.yaml")

    if Path(".github/workflows/dbt-quality.yml").exists():
        existing.append(".github/workflows/dbt-quality.yml")

    return existing


def _check_existing_config_files_for_preset() -> list[str]:
    """Check which config files already exist for preset mode."""
    existing = []

    if Path(".sqlfluff").exists():
        existing.append(".sqlfluff")

    if Path(".sqlfluffignore").exists():
        existing.append(".sqlfluffignore")

    if Path("dbt-bouncer.yml").exists():
        existing.append("dbt-bouncer.yml")

    if Path(".pre-commit-config.yaml").exists():
        existing.append(".pre-commit-config.yaml")

    if Path(".github/workflows/dbt-quality.yml").exists():
        existing.append(".github/workflows/dbt-quality.yml")

    return existing


def _select_preset() -> str:
    """Let user select a preset level."""
    console.print(
        Panel(
            "[bold]Presets[/bold] define how strict your quality gates are.\n\n"
            "• [cyan]Relaxed[/cyan] - Basic formatting only (good for existing projects)\n"
            "• [cyan]Standard[/cyan] - Formatting + documentation (recommended)\n"
            "• [cyan]Strict[/cyan] - All checks enabled (for new projects)\n"
            "• [cyan]Custom[/cyan] - Pick individual categories",
            border_style="dim",
        )
    )

    preset = questionary.select(
        "Select a preset:",
        choices=[
            questionary.Choice("Relaxed - Basic formatting only", value="relaxed"),
            questionary.Choice(
                "Standard - Formatting + documentation (recommended)", value="standard"
            ),
            questionary.Choice("Strict - All checks enabled", value="strict"),
            questionary.Choice("Custom - Pick categories", value="custom"),
        ],
        default="standard",
    ).ask()

    if preset is None:
        raise SystemExit(1)

    return preset


def _select_categories() -> list[Category]:
    """Let user select which categories to enable."""
    choices = []
    for category in Category:
        info = CATEGORY_INFO[category]
        choices.append(
            questionary.Choice(
                f"{info.icon} {info.name} - {info.description}",
                value=category,
                checked=category in [Category.FORMATTING, Category.DOCUMENTATION],
            )
        )

    selected = questionary.checkbox(
        "Select categories to enable:",
        choices=choices,
    ).ask()

    if selected is None:
        raise SystemExit(1)

    return selected


def _get_checks_for_categories(categories: list[Category]) -> list:
    """Get all checks for selected categories (standard preset level)."""
    checks = []
    for category in categories:
        category_checks = registry.get_by_category(category)
        # Use standard preset checks for each category
        for check in category_checks:
            if check.preset_standard:
                checks.append(check)
    return checks


def _show_configuration_summary(preset: str, checks: list) -> None:
    """Show what will be configured."""
    console.print()

    # Group checks by category
    by_category: dict[Category, list] = {}
    for check in checks:
        if check.category not in by_category:
            by_category[check.category] = []
        by_category[check.category].append(check)

    # Build table
    table = Table(title=f"Configuration Summary ({preset.title()} preset)", border_style="dim")
    table.add_column("Category", style="cyan")
    table.add_column("Checks", style="white")
    table.add_column("Tool", style="dim")

    for category in Category:
        info = CATEGORY_INFO[category]
        category_checks = by_category.get(category, [])

        if category_checks:
            for i, check in enumerate(category_checks):
                cat_display = f"{info.icon} {info.name}" if i == 0 else ""
                table.add_row(cat_display, check.name, check.tool.value)
        else:
            table.add_row(f"{info.icon} {info.name}", "[dim]none[/dim]", "")

    console.print(table)


def _show_custom_configuration_summary(config) -> None:
    """Show custom configuration summary."""

    console.print()

    # Build summary table
    table = Table(title="Custom Configuration Summary", border_style="dim")
    table.add_column("Category", style="cyan")
    table.add_column("Setting", style="white")
    table.add_column("Value", style="green")

    # Formatting
    if "formatting" in config.enabled_categories:
        c = config.sqlfluff
        table.add_row("Formatting", "Keyword case", c.keyword_case.upper())
        table.add_row("", "Comma position", c.comma_position)
        table.add_row("", "Indentation", f"{c.indent_spaces} spaces")
        table.add_row("", "Max line length", str(c.max_line_length))
        table.add_row("", "Explicit aliasing", "Yes" if c.explicit_aliasing else "No")
    else:
        table.add_row("Formatting", "[dim]disabled[/dim]", "")

    # Documentation
    if "documentation" in config.enabled_categories:
        d = config.documentation
        table.add_row(
            "Documentation",
            "Model descriptions",
            "Required" if d.require_model_descriptions else "Optional",
        )
        table.add_row(
            "", "Column descriptions", "Required" if d.require_column_descriptions else "Optional"
        )
        table.add_row(
            "", "Properties file", "Required" if d.require_model_properties_file else "Optional"
        )
        table.add_row(
            "", "Macro descriptions", "Required" if d.require_macro_descriptions else "Optional"
        )
    else:
        table.add_row("Documentation", "[dim]disabled[/dim]", "")

    # Coverage
    if "coverage" in config.enabled_categories:
        c = config.coverage
        table.add_row(
            "Coverage", "Model tests", "Required" if c.require_model_tests else "Optional"
        )
        table.add_row("", "Unique tests", "Required" if c.require_unique_tests else "Optional")
    else:
        table.add_row("Coverage", "[dim]disabled[/dim]", "")

    # Governance
    if "governance" in config.enabled_categories:
        g = config.governance
        table.add_row(
            "Governance",
            "Naming convention",
            "Enforced" if g.enforce_naming_convention else "Not enforced",
        )
        table.add_row(
            "",
            "Directory structure",
            "Enforced" if g.enforce_directory_structure else "Not enforced",
        )
        table.add_row(
            "", "Staging isolation", "Enforced" if g.enforce_staging_no_upstream else "Not enforced"
        )
        table.add_row("", "ref()/source() required", "Yes" if g.enforce_ref_source else "No")
        table.add_row("", "No trailing semicolons", "Yes" if g.no_trailing_semicolons else "No")
    else:
        table.add_row("Governance", "[dim]disabled[/dim]", "")

    # Data Quality
    if "data_quality" in config.enabled_categories:
        q = config.data_quality
        table.add_row(
            "Data Quality",
            "Source freshness",
            "Required" if q.require_source_freshness else "Optional",
        )
        table.add_row(
            "", "Primary key tests", "Required" if q.require_primary_key_tests else "Optional"
        )
    else:
        table.add_row("Data Quality", "[dim]disabled[/dim]", "")

    console.print(table)
