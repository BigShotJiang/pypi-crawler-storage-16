"""Detection utilities for dbt project analysis."""

from pathlib import Path

import yaml


def detect_dbt_project() -> dict | None:
    """Detect dbt project and return project info."""
    dbt_project_path = Path("dbt_project.yml")

    if not dbt_project_path.exists():
        # Try common subdirectories
        for subdir in ["dbt", "transform", "analytics"]:
            alt_path = Path(subdir) / "dbt_project.yml"
            if alt_path.exists():
                dbt_project_path = alt_path
                break
        else:
            return None

    try:
        with open(dbt_project_path) as f:
            project = yaml.safe_load(f) or {}

        return {
            "name": project.get("name", "unknown"),
            "version": project.get("version", "unknown"),
            "config_version": project.get("config-version", 2),
            "path": str(dbt_project_path.parent),
        }
    except Exception:
        return None


def detect_warehouse() -> str | None:
    """Detect the data warehouse from profiles or environment."""
    # Check profiles.yml
    profiles_paths = [
        Path("profiles.yml"),
        Path.home() / ".dbt" / "profiles.yml",
    ]

    for profiles_path in profiles_paths:
        if profiles_path.exists():
            try:
                with open(profiles_path) as f:
                    profiles = yaml.safe_load(f) or {}

                # Find the first profile with a target
                for _profile_name, profile_data in profiles.items():
                    if isinstance(profile_data, dict) and "outputs" in profile_data:
                        outputs = profile_data["outputs"]
                        if isinstance(outputs, dict):
                            for _output_name, output_data in outputs.items():
                                if isinstance(output_data, dict) and "type" in output_data:
                                    return output_data["type"]
            except Exception:
                continue

    # Check for common adapter packages in requirements or pyproject
    requirements_files = ["requirements.txt", "requirements-dbt.txt"]
    for req_file in requirements_files:
        if Path(req_file).exists():
            with open(req_file) as f:
                content = f.read().lower()
                if "dbt-duckdb" in content:
                    return "duckdb"
                if "dbt-snowflake" in content:
                    return "snowflake"
                if "dbt-bigquery" in content:
                    return "bigquery"
                if "dbt-redshift" in content:
                    return "redshift"
                if "dbt-postgres" in content:
                    return "postgres"
                if "dbt-databricks" in content:
                    return "databricks"

    return None


# Map dbt adapter types to SQLFluff dialects
ADAPTER_TO_SQLFLUFF_DIALECT = {
    "duckdb": "duckdb",
    "bigquery": "bigquery",
    "snowflake": "snowflake",
    "redshift": "redshift",
    "postgres": "postgres",
    "databricks": "databricks",
    "spark": "sparksql",
}


def get_sqlfluff_dialect(adapter: str | None) -> str:
    """Get the SQLFluff dialect for a dbt adapter."""
    if adapter is None:
        return "ansi"  # Safe default
    return ADAPTER_TO_SQLFLUFF_DIALECT.get(adapter, "ansi")


def detect_existing_tools() -> dict[str, bool]:
    """Detect which dbt quality tools are already configured."""
    return {
        "sqlfluff": Path(".sqlfluff").exists() or Path("pyproject.toml").exists(),
        "pre_commit": Path(".pre-commit-config.yaml").exists(),
        "dbt_bouncer": Path("dbt_bouncer.yml").exists() or Path("dbt-bouncer.yml").exists(),
    }


def detect_ci_provider() -> str | None:
    """Detect the CI/CD provider from existing configuration."""
    if Path(".github/workflows").exists():
        return "github"
    if Path(".gitlab-ci.yml").exists():
        return "gitlab"
    if Path("azure-pipelines.yml").exists():
        return "azure"
    return None
