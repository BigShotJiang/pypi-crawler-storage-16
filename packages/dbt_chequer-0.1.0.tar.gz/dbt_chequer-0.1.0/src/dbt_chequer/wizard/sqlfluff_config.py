"""SQLFluff configuration wizard."""

import questionary
from rich.console import Console

console = Console()


def configure_sqlfluff_rules(dialect: str = "duckdb") -> dict:
    """Interactive wizard to configure SQLFluff rules and return config dict."""
    console.print("\n[bold]SQLFluff Style Configuration[/bold]")
    console.print(f"[dim]Configure your SQL style preferences (dialect: {dialect})[/dim]\n")

    # Capitalization
    keyword_case = questionary.select(
        "SQL keyword capitalization (SELECT, FROM, WHERE):",
        choices=[
            questionary.Choice("UPPERCASE", value="upper"),
            questionary.Choice("lowercase", value="lower"),
        ],
        default="upper",
    ).ask()

    function_case = questionary.select(
        "Function capitalization (COUNT, SUM, COALESCE):",
        choices=[
            questionary.Choice("UPPERCASE", value="upper"),
            questionary.Choice("lowercase", value="lower"),
        ],
        default="upper",
    ).ask()

    literal_case = questionary.select(
        "Literal capitalization (NULL, TRUE, FALSE):",
        choices=[
            questionary.Choice("UPPERCASE", value="upper"),
            questionary.Choice("lowercase", value="lower"),
        ],
        default="upper",
    ).ask()

    identifier_case = questionary.select(
        "Identifier style (column/table names):",
        choices=[
            questionary.Choice("snake_case (recommended for dbt)", value="lower"),
            questionary.Choice("UPPER_CASE", value="upper"),
            questionary.Choice("No preference", value="consistent"),
        ],
        default="lower",
    ).ask()

    # Commas
    comma_style = questionary.select(
        "Comma placement:",
        choices=[
            questionary.Choice("Trailing commas (col1,)", value="trailing"),
            questionary.Choice("Leading commas (,col1)", value="leading"),
        ],
        default="trailing",
    ).ask()

    # Indentation
    indent_size = questionary.select(
        "Indentation size:",
        choices=[
            questionary.Choice("2 spaces", value="2"),
            questionary.Choice("4 spaces", value="4"),
        ],
        default="4",
    ).ask()

    # Line length
    line_length = questionary.select(
        "Maximum line length:",
        choices=[
            questionary.Choice("80 characters", value="80"),
            questionary.Choice("100 characters", value="100"),
            questionary.Choice("120 characters", value="120"),
        ],
        default="100",
    ).ask()

    # Aliasing
    alias_style = questionary.select(
        "Table aliasing style:",
        choices=[
            questionary.Choice("Explicit AS keyword (table AS t)", value="explicit"),
            questionary.Choice("Implicit (table t)", value="implicit"),
        ],
        default="explicit",
    ).ask()

    # Comparison operators
    not_equal_style = questionary.select(
        "Not equal operator:",
        choices=[
            questionary.Choice("!= (C-style)", value="c_style"),
            questionary.Choice("<> (ANSI)", value="ansi"),
        ],
        default="c_style",
    ).ask()

    # Join preference
    join_preference = questionary.confirm(
        "Prefer LEFT JOIN over RIGHT JOIN?",
        default=True,
    ).ask()

    return build_sqlfluff_config(
        dialect=dialect,
        keyword_case=keyword_case or "upper",
        function_case=function_case or "upper",
        literal_case=literal_case or "upper",
        identifier_case=identifier_case or "lower",
        comma_style=comma_style or "trailing",
        indent_size=int(indent_size or "4"),
        line_length=int(line_length or "100"),
        alias_style=alias_style or "explicit",
        not_equal_style=not_equal_style or "c_style",
        prefer_left_join=join_preference if join_preference is not None else True,
    )


def build_sqlfluff_config(
    dialect: str = "duckdb",
    keyword_case: str = "upper",
    function_case: str = "upper",
    literal_case: str = "upper",
    identifier_case: str = "lower",
    comma_style: str = "trailing",
    indent_size: int = 4,
    line_length: int = 100,
    alias_style: str = "explicit",
    not_equal_style: str = "c_style",
    prefer_left_join: bool = True,
) -> dict:
    """Build SQLFluff config dictionary from preferences."""
    return {
        "dialect": dialect,
        "templater": "dbt",
        "max_line_length": line_length,
        "indentation": {
            "indent_unit": "space",
            "tab_space_size": indent_size,
            "indented_joins": False,
            "indented_ctes": False,
            "indented_using_on": True,
            "indented_on_contents": True,
        },
        "layout": {
            "type": {
                "comma": {
                    "spacing_before": "touch",
                    "line_position": comma_style,
                },
            },
        },
        "rules": {
            "capitalisation.keywords": {
                "capitalisation_policy": keyword_case,
            },
            "capitalisation.functions": {
                "capitalisation_policy": function_case,
            },
            "capitalisation.literals": {
                "capitalisation_policy": literal_case,
            },
            "capitalisation.identifiers": {
                "capitalisation_policy": identifier_case,
            },
            "capitalisation.types": {
                "capitalisation_policy": keyword_case,  # Match keywords
            },
            "aliasing.table": {
                "aliasing": alias_style,
            },
            "aliasing.column": {
                "aliasing": alias_style,
            },
            "aliasing.length": {
                "min_alias_length": 3,
            },
            "convention.not_equal": {
                "preferred_not_equal_style": not_equal_style,
            },
            "convention.coalesce": {
                "preferred_coalesce_style": "coalesce",
            },
            "convention.is_null": {
                # Prefer IS NULL over = NULL
            },
            "convention.left_join": {
                "force_enable": prefer_left_join,
            },
        },
    }


def generate_sqlfluff_file(config: dict) -> str:
    """Generate .sqlfluff file content from config dict."""
    lines = [
        "# Generated by dbt-chequer",
        "# SQLFluff configuration for dbt projects",
        "",
        "[sqlfluff]",
        f"dialect = {config['dialect']}",
        f"templater = {config['templater']}",
        f"max_line_length = {config['max_line_length']}",
        "",
        "# Indentation",
        "[sqlfluff:indentation]",
        f"indent_unit = {config['indentation']['indent_unit']}",
        f"tab_space_size = {config['indentation']['tab_space_size']}",
        f"indented_joins = {str(config['indentation']['indented_joins']).lower()}",
        f"indented_ctes = {str(config['indentation']['indented_ctes']).lower()}",
        f"indented_using_on = {str(config['indentation']['indented_using_on']).lower()}",
        f"indented_on_contents = {str(config['indentation']['indented_on_contents']).lower()}",
        "",
        "# Comma layout",
        "[sqlfluff:layout:type:comma]",
        f"spacing_before = {config['layout']['type']['comma']['spacing_before']}",
        f"line_position = {config['layout']['type']['comma']['line_position']}",
        "",
        "# Capitalisation rules",
        "[sqlfluff:rules:capitalisation.keywords]",
        f"capitalisation_policy = {config['rules']['capitalisation.keywords']['capitalisation_policy']}",
        "",
        "[sqlfluff:rules:capitalisation.functions]",
        f"capitalisation_policy = {config['rules']['capitalisation.functions']['capitalisation_policy']}",
        "",
        "[sqlfluff:rules:capitalisation.literals]",
        f"capitalisation_policy = {config['rules']['capitalisation.literals']['capitalisation_policy']}",
        "",
        "[sqlfluff:rules:capitalisation.identifiers]",
        f"capitalisation_policy = {config['rules']['capitalisation.identifiers']['capitalisation_policy']}",
        "",
        "[sqlfluff:rules:capitalisation.types]",
        f"capitalisation_policy = {config['rules']['capitalisation.types']['capitalisation_policy']}",
        "",
        "# Aliasing rules",
        "[sqlfluff:rules:aliasing.table]",
        f"aliasing = {config['rules']['aliasing.table']['aliasing']}",
        "",
        "[sqlfluff:rules:aliasing.column]",
        f"aliasing = {config['rules']['aliasing.column']['aliasing']}",
        "",
        "[sqlfluff:rules:aliasing.length]",
        f"min_alias_length = {config['rules']['aliasing.length']['min_alias_length']}",
        "",
        "# Convention rules",
        "[sqlfluff:rules:convention.not_equal]",
        f"preferred_not_equal_style = {config['rules']['convention.not_equal']['preferred_not_equal_style']}",
        "",
        "[sqlfluff:rules:convention.coalesce]",
        f"preferred_coalesce_style = {config['rules']['convention.coalesce']['preferred_coalesce_style']}",
        "",
        "# dbt templater settings",
        "[sqlfluff:templater:dbt]",
        "project_dir = ./",
        "profiles_dir = ./",
        "profile = default",
        "target = dev",
    ]

    return "\n".join(lines) + "\n"


def get_default_config(dialect: str = "duckdb") -> dict:
    """Get sensible defaults for quick setup (matches pyne-dbt-internal style)."""
    return build_sqlfluff_config(
        dialect=dialect,
        keyword_case="upper",
        function_case="upper",
        literal_case="upper",
        identifier_case="lower",
        comma_style="trailing",
        indent_size=4,
        line_length=100,
        alias_style="explicit",
        not_equal_style="c_style",
        prefer_left_join=True,
    )


# Backwards compatibility - default to duckdb
DEFAULT_CONFIG = get_default_config("duckdb")
