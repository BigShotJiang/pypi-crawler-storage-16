def main() -> None:
    print("Hello from dbt-fusion-package-tools!")
