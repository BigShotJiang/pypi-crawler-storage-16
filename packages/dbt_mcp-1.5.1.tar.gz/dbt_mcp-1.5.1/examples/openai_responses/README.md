# OpenAI Responses

An example of using remote dbt-mcp with OpenAI's Responses API

## Usage

`uv run main.py`
