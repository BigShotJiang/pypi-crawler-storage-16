# Functional tests focus on the business requirements of an application. They
# only verify the output of an action and do not check the intermediate states
# of the system when performing that action.
