from dbt.tests.adapter.column_types.test_column_types import BasePostgresColumnTypes


class TestPostgresColumnTypes(BasePostgresColumnTypes):
    pass
