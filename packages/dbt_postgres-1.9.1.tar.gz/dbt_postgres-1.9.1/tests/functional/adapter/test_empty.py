from dbt.tests.adapter.empty.test_empty import BaseTestEmpty


class TestEmpty(BaseTestEmpty):
    pass
