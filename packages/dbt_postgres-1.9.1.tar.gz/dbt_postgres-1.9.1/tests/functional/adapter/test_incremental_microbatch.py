from dbt.tests.adapter.incremental.test_incremental_microbatch import (
    BaseMicrobatch,
)


class TestPostgresMicrobatch(BaseMicrobatch):
    pass
