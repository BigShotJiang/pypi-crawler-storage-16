from dbt.tests.adapter.store_test_failures_tests.test_store_test_failures import (
    BaseStoreTestFailures,
    BaseStoreTestFailuresLimit,
)


class TestStoreTestFailures(BaseStoreTestFailures):
    pass


class TestStoreTestFailuresLimit(BaseStoreTestFailuresLimit):
    pass
