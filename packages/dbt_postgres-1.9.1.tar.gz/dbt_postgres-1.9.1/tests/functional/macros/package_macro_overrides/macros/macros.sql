{% macro get_columns_in_relation(relation) %}
	{{ return('a string') }}
{% endmacro %}
