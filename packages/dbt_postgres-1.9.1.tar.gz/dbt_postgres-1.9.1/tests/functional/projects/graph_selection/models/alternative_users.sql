{# Same as ´users´ model, but with dots in the model name #}
{{ config(
    materialized = 'table',
    tags=['dots']
) }}

select * from {{ ref('base_users') }}
