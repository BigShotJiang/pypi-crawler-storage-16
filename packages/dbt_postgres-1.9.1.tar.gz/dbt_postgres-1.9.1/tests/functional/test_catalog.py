from dbt.tests.adapter.catalog.relation_types import CatalogRelationTypes


class TestCatalogRelationTypes(CatalogRelationTypes):
    pass
