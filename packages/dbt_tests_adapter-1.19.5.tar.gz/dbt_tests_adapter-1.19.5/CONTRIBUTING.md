# Contributing to `dbt-tests-adapter`

This document covers the incremental content beyond what is contained in the repository's [CONTRIBUTING.md](/CONTRIBUTING.md).
You are strongly encouraged to start there first if you are reading this for the first time.

# Testing

`dbt-tests-adapter` differs from most other packages in this repository.
Since `dbt-tests-adapter` is purely a test suite, it contains no unit nor integration tests.
