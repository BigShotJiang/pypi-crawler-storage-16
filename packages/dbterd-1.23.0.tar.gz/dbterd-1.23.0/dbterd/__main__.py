from dbterd import main


main.main()
