"""Builder module for ERD content construction."""
