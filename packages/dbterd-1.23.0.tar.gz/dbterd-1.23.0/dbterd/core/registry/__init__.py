"""Plugin registry for dbterd adapters."""
