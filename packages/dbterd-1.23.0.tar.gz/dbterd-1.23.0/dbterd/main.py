from dbterd.cli import main as cli


def main():
    """Dbterd entrypoint."""
    cli.dbterd()
