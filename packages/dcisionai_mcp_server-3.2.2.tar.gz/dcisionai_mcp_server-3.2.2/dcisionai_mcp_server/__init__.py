"""
DcisionAI MCP Server 2.0

Next-generation MCP server that directly integrates with dcisionai_graph,
serving as the primary interface for all clients (React UI, Salesforce, IDEs).
"""

__version__ = "2.0.0"

