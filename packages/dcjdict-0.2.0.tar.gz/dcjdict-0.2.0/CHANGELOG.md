## v0.2.0 (2025-12-10)

### Feat

- add commitizen as dev tool
- added pipeline

### Fix

- fetch main when publish
- correct cz command
- avoid comments in pipeline
- pipeline with publish stage
- add gitlab token
- add gitlab token
- correct link to uv
- added pipeline corrections
