# Dataclass Jsonable Dict parsing

Dataclass in Python is a excelent way to implement Data Transfer Objects, but lacks of a good integrated encoding system to transfer between applications.

One of the most used encoding is json. The standard library `json` only need a jsonable dictionary to dump to bytes or be loaded from them.

This library contains two easy functions to load/convert to dataclases from jsonable dictionaries:

1. `to_jdict(value: DataclassInstance, ommit_defaults: bool = True, enum_as_string: bool = True) -> JsonableDict`:
    1. `ommit_defaults` sets if values with default will be generated as fields in the dict
    2. `enum_as_string`: sets the enum fields as its name instead its value.
2. `from_jdict(value: dict , cls: DataclassType, validate_types: bool = True )-> DataclassInstance`
   1. `validate`: checks that the json fields has correct or compatible type for constructing the dataclass. 


