uv run pytest \
    -W ignore::DeprecationWarning \
    --cov=dcjdict \
    --cov-report=xml \
    --cov-report=term \
    --cov-report=html \
    --junitxml=test-results.xml  tests

    # -W error::UserWarning \
    # --cov-config=.coveragerc \
