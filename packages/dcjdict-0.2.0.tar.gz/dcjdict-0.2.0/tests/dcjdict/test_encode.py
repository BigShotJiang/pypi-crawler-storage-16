import pytest

from dcjdict.encode import to_jdict
from dcjdict.core import JsonableDict

from .cases import *


class A_ConversionToJsonablDict:

    def should_map_a_dataclass_to_jsonable_dict(self):
        for case in CASES:
            assert to_jdict(case.value) == JsonableDict(**case.jdict), case.name

    def should_map_only_dataclasses(self):
        with pytest.raises(TypeError):
            to_jdict(NoDataclass())
