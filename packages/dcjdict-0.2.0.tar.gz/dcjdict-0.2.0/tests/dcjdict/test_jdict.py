import pytest
from dcjdict.core import JsonableDict


class A_JsonableDict:
    def should_validate_possible_fields(self):
        d = JsonableDict(
            {
                "name": "Alice",
                "age": 30,
                "active": True,
                "tags": ["user", "premium"],
                "metadata": JsonableDict({"theme": "dark"}),
                "score": None,
            }
        )
        d["new_list"] = [1, "test", None, [1, 2]]
        d["nested"] = {"a": 1, "b": {"c": True}}

    def should_avoid_non_string_keys(self):
        with pytest.raises(TypeError):
            JsonableDict({1: "wrong-field-key"})

        d = JsonableDict()
        with pytest.raises(TypeError):
            d[12] = "wrong-field-key"

    def should_avoid_add_wrong_type_value(self):
        with pytest.raises(TypeError):
            JsonableDict(object())

        d = JsonableDict()
        with pytest.raises(TypeError):
            d["no-allowed"] = object()
