# Руководство пользователя DDDGuard Visualizer

Модуль Visualizer — это инструмент для построения графических диаграмм архитектуры проекта. Он анализирует граф зависимостей, созданный Сканером, и визуализирует связи между контекстами и слоями в формате Draw.io (XML).

COMMAND: draw
--------------------------------------------------------------------------------
Описание:
Генерирует архитектурную карту всего проекта на основе `config.yaml`.

Использование:
  dddguard draw

Поведение:
1. Загружает конфигурацию проекта.
2. Открывает интерактивное меню (HUD) для подтверждения параметров генерации.

ИНТЕРФЕЙС: Visualizer HUD
--------------------------------------------------------------------------------

Визуализация интерфейса:

╭────────────────────────────  ARCHITECTURE MAPPER  ───────────────────────────╮
│                                                                              │
│                  Visualization Target: dddguard/src/dddguard                 │
│                                                                              │
│                               Format:  Draw.io XML                           │
│                               Engine:  NetworkX + Rich                       │
│                          Output File:  architecture.drawio                   │
│                                                                              │
╰──────────────────────────────────────── Arrows to Navigate • Enter to Select ─╯
 (Use arrow keys, Ctrl+C to cancel) 
   SETTINGS 
     💾 Output File (architecture.drawio)
   ---------------
❯ >>> GENERATE DIAGRAM <<<
     Exit / Cancel

Меню SETTINGS:

* 💾 Output File
  Позволяет изменить имя выходного файла. По умолчанию: `architecture.drawio`.

Меню ACTIONS:

* >>> GENERATE DIAGRAM <<<
  Запускает процесс генерации.
  
  Результат:
  ✅ Diagram saved: architecture.drawio
  ℹ️  Open in https://app.diagrams.net/

COMMAND: drawdir
--------------------------------------------------------------------------------
Описание:
Генерирует диаграмму для конкретной выбранной директории. Полезно для визуализации связей внутри одного модуля или если конфиг отсутствует.

Использование:
  dddguard drawdir

Поведение:
1. Запускает выбор папки.
   🔍 Select directory to visualize (In: /projects/dddguard)
   ❯ ✅ SELECT CURRENT: dddguard/
     📂 src
     📂 tests
2. Открывает HUD с выбранной целью.