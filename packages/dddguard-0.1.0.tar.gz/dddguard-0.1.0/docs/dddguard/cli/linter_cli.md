# Руководство пользователя DDDGuard Linter

Модуль Linter — это инструмент статического анализа, который проверяет соответствие архитектуры проекта строгим правилам Domain-Driven Design (DDD). Он гарантирует, что слои (Domain, App, Adapters) взаимодействуют только разрешенным образом, и предотвращает архитектурную эрозию.

Ниже описаны доступные команды, интерфейс управления и справочные экраны.

COMMAND: lint
--------------------------------------------------------------------------------
Описание:
Запускает проверку архитектуры для всего проекта, используя настройки из config.yaml.
Это основной способ запуска при работе в CI/CD или при проверке всего монолита.

Использование:
  dddguard lint

Поведение:
1. Загружает конфигурацию.
2. Определяет Source Directory.
3. Открывает интерактивное меню (HUD) с готовым к проверке путем.

COMMAND: lintdir
--------------------------------------------------------------------------------
Описание:
Позволяет выбрать конкретную директорию для проверки вручную. Полезно для точечной проверки отдельных модулей или если конфигурационный файл отсутствует.

Использование:
  dddguard lintdir

Поведение:
1. Запускает интерактивный фаззи-поиск для выбора папки.
2. После выбора открывает главное меню Linter HUD.

Пример выбора директории:
🔍 Select directory to lint (In: /home/user/projects/dddguard)
(Type to filter • Enter to navigate) 
Filter:  
❯ ✅ SELECT CURRENT: dddguard/
  🔙 .. (Go Up)
  📂 docs
  📂 src
  📂 tests


ИНТЕРФЕЙС: Linter HUD (Панель Управления)
--------------------------------------------------------------------------------
Главное меню линтера позволяет ознакомиться с правилами перед запуском или изменить параметры проверки.

Визуализация интерфейса:

╭─────────────────────────────  ARCHITECTURE GUARD  ─────────────────────────────╮
│                                                                                │
│                       Linting Target: dddguard/src/dddguard                    │
│                                                                                │
╰───────────────────────────────────────── Arrows to Navigate • Enter to Select ─╯
 (Use arrow keys, Ctrl+C to cancel) 
   REFERENCE 
     📖 View Rules (Summary)
     🔢 View Rules (Matrix)
   ---------------
❯ >>> RUN VALIDATION <<<
     Exit / Cancel

Меню REFERENCE (Справочная информация):

1. 📖 View Rules (Summary)
   Открывает экран с кратким графическим описанием слоев. Показывает основные принципы: какой слой за что отвечает.

  Результат выполнения (Summary):

╭─────────────────────────── 🧱 LAYER ISOLATION RULES ───────────────────────────╮
│                                                                                │
│   Layer                          Rules & Restrictions                          │
│  ────────────────────────────────────────────────────────────────────────────  │
│   🔵 DOMAIN                      • Must be PURE.                               │
│                                  • Can ONLY import SHARED KERNEL and itself.   │
│   🟣 APP                         • Imports DOMAIN & SHARED.                    │
│                                  • ⛔ NO DTOs (Pure Domain Language).          │
│                                  • ⛔ NO INFRASTRUCTURE (Adapters/Ports).      │
│   🔌 ADAPTERS                    🟢 DRIVING (Controllers):                     │
│                                    • Calls APP UseCases.                       │
│                                    • ⛔ NO PORTS (No DB/Config).               │
│                                                                                │
│                                  🟠 DRIVEN (Repositories/ACL):                 │
│                                    • Implements APP Interfaces.                │
│                                    • ✅ USES DRIVEN PORTS (DB Sessions).       │
│                                    • ✅ CROSS-CONTEXT (Calls other contexts).  │
│   📄 DTOs                        • Dumb Data Contracts.                        │
│                                  • ⛔ NO LOGIC DEPS (No App/Adapters).         │
│   ⚙️ PORTS                       🟢 DRIVING (Frameworks): Imports Adapters.    │
│                                  🟠 DRIVEN (Drivers): Low-level tools.         │
│                                                                                │
╰────────────────────────────────────────────────────────────────────────────────╯

1. 🔢 View Rules (Matrix)
   Открывает детальную матрицу доступа (Access Matrix). Это таблица "все со всеми", где точно указано, какие импорты разрешены (Green), а какие запрещены (Red) для каждого слоя.

   Пример экрана матрицы:
   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
   │ Architectural Rules & Constraints                                           │
   └─────────────────────── Domain-Driven Design Guidelines ─────────────────────┘
                          🛑 Internal Layer Boundaries (Intra-Context)           
   ╭──────────────────┬─────────────────────────────┬────────────────────────────╮
   │ Source Layer     │ Can Import (Allowed)        │ Cannot Import (Forbidden)  │
   ├──────────────────┼─────────────────────────────┼────────────────────────────┤
   │ DOMAIN           │ domain                      │ driving_adapters, app...   │
   │ APP              │ app, domain                 │ driving_ports, driven...   │
   │ DRIVING_ADAPTERS │ app, domain, driving_dto    │ driven_ports, driven...    │
   │ DRIVEN_ADAPTERS  │ domain, app, driven_ports   │ driving_ports, driving...  │
   ╰──────────────────┴─────────────────────────────┴────────────────────────────╯
   
   🌐 Cross-Context Policies
   ╭───────── 🔓 Public Layers ──────────╮  ╭─────── 📡 Outbound Initiators ───────╮
   │ • driving_adapters                  │  │ • driven_adapters                    │
   │ • driving_dto                       │  │                                      │
   ╰── (Accessible from other Contexts) ─╯  ╰──── (Can call other Contexts) ───────╯

Меню ACTIONS (Действия):

1. >>> RUN VALIDATION <<<
   Запускает процесс анализа. Проверяются все импорты в Python-файлах указанной директории на соответствие правилам матрицы.

2. Exit / Cancel
   Выход из программы.

ОТЧЕТ О НАРУШЕНИЯХ (Результат)
--------------------------------------------------------------------------------
После завершения валидации линтер выводит отчет.

Если нарушений нет:
Отображается зеленая панель "✅ No violations found. Architecture is Clean!".

Если найдены нарушения:
Выводится таблица с детализацией ошибок: правило (Rule ID), контекст и точное место нарушения (какой модуль импортировал запрещенный модуль).

Пример отчета с ошибками:


╭─ ❌ Architectural Violations Found ─╮
│       Files Scanned:  79            │
│          Violations:  5             │
│              Status:  FAILED        │
╰─────────────────────────────────────╯

                                                                                                                                                  
  Rule        Context            Violation Details                                                                                                
 ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────── 
  R100        scaffolder         Layer violation: 'driving_ports' cannot import 'app'                                                             
                                 Loc: scaffolder.ports.driving.cli → scaffolder.app.use_cases.init_project_use_case                               
  R100        scaffolder         Layer violation: 'driving_ports' cannot import 'app'                                                             
                                 Loc: scaffolder.ports.driving.cli → scaffolder.app.use_cases.create_config_use_case                              
  R100        scaffolder         Layer violation: 'driving_ports' cannot import 'app'                                                             
                                 Loc: scaffolder.ports.driving.cli → scaffolder.app.use_cases.create_component_use_case                           
  R100        scaffolder         Layer violation: 'driving_ports' cannot import 'app'                                                             
                                 Loc: scaffolder.ports.driving.cli → scaffolder.app.use_cases.list_templates_use_case                             
  R100        scaffolder         Layer violation: 'driving_ports' cannot import 'app'                                                             
                                 Loc: scaffolder.ports.driving.cli → scaffolder.app.errors                                                        
                                                                                                
╰─────────┴─────────────┴────────────────────────────────────────────────────────╯