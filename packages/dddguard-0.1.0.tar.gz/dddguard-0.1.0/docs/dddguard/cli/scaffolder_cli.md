# Руководство пользователя DDDGuard Scaffolder

Модуль Scaffolder — это генератор кода, который помогает быстро создавать новые компоненты (Bounded Contexts, Shared Utilities) в соответствии с правилами архитектуры DDD. Он автоматизирует создание шаблонного кода (boilerplate), гарантируя правильную структуру папок и файлов.

Ниже описаны доступные команды и интерфейс управления.

COMMAND: create
--------------------------------------------------------------------------------
Описание:
Запускает интерактивный мастер создания компонентов.
Если в проекте есть `config.yaml`, мастер автоматически определяет корневую папку проекта. Если конфига нет, предлагается его создать или работать в Ad-Hoc режиме.

Использование:
  dddguard create

Поведение:
1. Загружает список доступных шаблонов из реестра.
2. Открывает интерактивное меню (HUD).
3. Позволяет выбрать категорию и конкретный шаблон.
4. Генерирует файлы в папку `templates/` в корне проекта (безопасный режим).

ИНТЕРФЕЙС: Scaffolder HUD (Панель Управления)
--------------------------------------------------------------------------------
Главный экран скаффолдера.

Визуализация интерфейса:

╭───────────────────────────  COMPONENT SCAFFOLDER  ───────────────────────────╮
│                                                                              │
│                               Project: dddguard                              │
│                               Config:  ✅ Loaded                             │
│                                                                              │
│                     Root:  /home/user/projects/dddguard                      │
│               Target Dir:  ./templates                                       │
│                                                                              │
╰───────────────── Generates boilerplate code into /templates ─────────────────╯
 (Use arrow keys, Ctrl+C to cancel) 
   ACTIONS 
❯    📚 Browse Template Registry
     🧩 Generate New Component
   ---------------
     Exit

Меню ACTIONS (Действия):

1. 📚 Browse Template Registry
   Открывает режим просмотра. Показывает дерево всех доступных шаблонов с их описанием, сгруппированных по категориям. Никаких файлов не создается.

   Пример экрана реестра:
   ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
   │ Template Registry                                                         │
   └───────────────────────────────────────────────────────────────────────────┘
   📦 Available Components
   ├── 📂 Bounded Context Blueprints
   │   ├── ctx_business_logic - Rich Domain Model: Aggregates, Services...
   │   └── ctx_simple_base - Base Context with Pydantic settings...
   └── 📂 Shared Utilities & Infrastructure
       ├── utils_generators - Mock data generators (Faker).
       └── utils_loguru - Loguru Setup for Shared Kernel.

2. 🧩 Generate New Component
   Запускает пошаговый процесс выбора и генерации шаблона.

   Шаг 1: Выбор категории
   Select Category (Use arrow keys, Ctrl+C to cancel) 
   ❯ 📂 ctx_base (Bounded Context Blueprints)
     📂 utils (Shared Utilities & Infrastructure)
     ---------------
     🔙 .. (Back)

   Шаг 2: Выбор шаблона
   Select ctx_base Template (Use arrow keys, Ctrl+C to cancel) 
   ❯ 📄 ctx_business_logic - Rich Domain Model...
     📄 ctx_simple_base - Base Context...
     ---------------
     🔙 .. (Back)

   Результат:
   После выбора шаблона, Scaffolder создает его копию в папке `./templates/<template_name>`.
   Вы увидите сообщение об успехе:
   
╭──────────────── 🧩 Component Constructed ─────────────────╮
│                                                           │
│  Template:  ctx_business_logic                            │
│  Location:  /home/e.mesheryakou/other/dddguard/templates  │
│                                                           │
│    Status:  Generated Successfully                        │
│                                                           │
│  📂 templates                                             │
│  ├── 📂 src                                               │
│  │   ├── 📂 delivery_context                              │
│  │   │   ├── 📂 app                                       │
│  │   │   │   ├── 📂 handlers                              │
│  │   │   │   │   ├── 📄 __init__.py                       │
│  │   │   │   │   └── 📄 on_order_created_handler.py       │
│  │   │   │   ├── 📂 interfaces                            │
│  │   │   │   │   ├── 📄 __init__.py                       │
│  │   │   │   │   ├── 📄 i_logistics_repository.py         │
│  │   │   │   │   └── 📄 i_notification_gateway.py         │
│  │   │   │   ├── 📂 queries                               │
│  │   │   │   │   ├── 📄 __init__.py                       │
│  │   │   │   │   └── 📄 get_delivery_status_query.py      │
│  │   │   │   ├── 📂 use_cases                             │
│  │   │   │   │   ├── 📄 __init__.py                       │
│  │   │   │   │   ├── 📄 add_order_item_use_case.py        │
│  │   │   │   │   ├── 📄 assemble_order_use_case.py        │
│  │   │   │   │   ├── 📄 create_order_use_case.py          │
│  │   │   │   │   └── 📄 match_orders_use_case.py          │
│  │   │   │   ├── 📂 workflows                             │
│  │   │   │   │   ├── 📄 __init__.py                       │
│  │   │   │   │   └── 📄 fulfillment_workflow.py           │
│  │   │   │   └── ... (and more)                           │
│  │   │   ├── 📂 domain                                    │
│  │   │   │   ├── 📂 aggregates                            │
│  │   │   │   │   └── 📄 delivery_aggregate.py             │
│  │   │   │   ├── 📂 entities                              │
│  │   │   │   │   ├── 📄 __init__.py                       │
│  │   │   │   │   ├── 📄 courier_entity.py                 │
│  │   │   │   │   └── 📄 order_ent.py                      │
│  │   │   │   ├── 📂 errors                                │
│  │   │   │   │   └── 📄 logistics_errors.py               │
│  │   │   │   ├── 📂 events                                │
│  │   │   │   │   └── 📄 delivery_events.py                │
│  │   │   │   ├── 📂 services                              │
│  │   │   │   │   ├── 📄 assignment_policy.py              │
│  │   │   │   │   ├── 📄 order_matching_service.py         │
│  │   │   │   │   └── 📄 pricing_service.py                │
│  │   │   │   └── ... (and more)                           │
│  │   │   ├── 📄 __init__.py                               │
│  │   │   ├── 📄 composition.py                            │
│  │   │   ├── 📄 config.py                                 │
│  │   │   └── ... (and more)                               │
│  │   ├── 📂 root                                          │
│  │   │   ├── 📄 composition.py                            │
│  │   │   ├── 📄 config.py                                 │
│  │   │   └── 📄 logger.py                                 │
│  │   └── 📂 shared                                        │
│  │       ├── 📂 utils                                     │
│  │       │   └── 📄 logging_setup.py                      │
│  │       └── 📄 __init__.py                               │
│  ├── 📂 tests                                             │
│  │   └── 📂 delivery_context                              │
│  │       └── 📂 unit                                      │
│  │           ├── 📂 app                                   │
│  │           │   ├── 📄 conftest.py                       │
│  │           │   ├── 📄 test_fulfillment_workflow.py      │
│  │           │   ├── 📄 test_match_orders_use_case.py     │
│  │           │   └── 📄 test_order_use_cases.py           │
│  │           └── 📂 domain                                │
│  │               ├── 📄 conftest.py                       │
│  │               ├── 📄 test_delivery_aggregate.py        │
│  │               ├── 📄 test_matching_service.py          │
│  │               └── 📄 test_order_entity.py              │
│  └── 📄 requirements.txt                                  │
│                                                           │
│          👉 Move these files to src/ when ready.          │
│                                                           │
╰───────────────────────────────────────────────────────────╯

1. ⚙️ Initialize Configuration (Если конфиг отсутствует)
   Если `config.yaml` не найден, вместо генерации компонентов будет предложено создать базовую конфигурацию проекта. Это рекомендуется сделать перед началом работы.

COMMAND: init
--------------------------------------------------------------------------------
Описание:
Инициализирует пустую структуру нового DDD-проекта в текущей директории. Создает базовые папки (`src`, `tests`, `docs`) и файл конфигурации.

Использование:
  dddguard init

  # С указанием имени проекта
  dddguard init --name "MyPaymentService"

COMMAND: config
--------------------------------------------------------------------------------
Описание:
Генерирует только файл `config.yaml` с дефолтными настройками. Полезно, если вы хотите добавить DDDGuard в уже существующий проект.

Использование:
  dddguard config