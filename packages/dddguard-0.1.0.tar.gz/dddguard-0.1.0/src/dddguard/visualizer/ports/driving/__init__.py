from .cli import register_commands

__all__ = ["register_commands"]
