# Copyright (c) 2025 Dedalus Labs, Inc. and its contributors
# SPDX-License-Identifier: MIT

"""Ping utility types."""

from mcp.types import PingRequest

__all__ = ["PingRequest"]
