# Copyright (c) 2025 Dedalus Labs, Inc. and its contributors
# SPDX-License-Identifier: MIT

"""Dedalus MCP authentication primitives.

This module provides the core credential and connection types for MCP servers.

Usage:
    from dedalus_mcp.auth import Connection, Credentials, Binding, Credential

    # Define what credentials a connection needs
    github = Connection(
        'github',
        credentials=Credentials(token='GITHUB_TOKEN'),
        base_url='https://api.github.com',
    )

    # At runtime, bind actual credential values
    cred = Credential(github, token='ghp_xxx')
"""

from __future__ import annotations

# Re-export from server.connectors (canonical location)
from ..server.connectors import (
    Binding,
    Connection,
    Credential,
    Credentials,
)

__all__ = [
    "Binding",
    "Connection",
    "Credential",
    "Credentials",
]
