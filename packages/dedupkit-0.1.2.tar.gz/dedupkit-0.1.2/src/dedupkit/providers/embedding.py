from dataclasses import dataclass

@dataclass
class EmbeddingModel:
    name: str
    dimensions: int