

def test_print_argument(model_type,model_dir):
    print ("Displaying model_type: %s" % model_type)
    print ("Displaying model_dir: %s" % model_dir)