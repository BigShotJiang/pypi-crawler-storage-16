# SPDX-License-Identifier: LGPL-3.0-or-later
from typing import (
    Any,
    Callable,
    Optional,
    Union,
)

import torch
import torch.nn as nn
import torch.nn.functional as torch_func

from deepmd.dpmodel.utils.seed import (
    child_seed,
)
from deepmd.pt.model.descriptor.descriptor import (
    DescriptorBlock,
)
from deepmd.pt.model.descriptor.env_mat import (
    prod_env_mat,
)
from deepmd.pt.model.network.layernorm import (
    LayerNorm,
)
from deepmd.pt.model.network.mlp import (
    EmbeddingNet,
    MLPLayer,
    NetworkCollection,
)
from deepmd.pt.model.network.network import (
    TypeEmbedNet,
)
from deepmd.pt.utils import (
    env,
)
from deepmd.pt.utils.env import (
    DEFAULT_PRECISION,
    PRECISION_DICT,
)
from deepmd.pt.utils.env_mat_stat import (
    EnvMatStatSe,
)
from deepmd.pt.utils.exclude_mask import (
    PairExcludeMask,
)
from deepmd.utils.env_mat_stat import (
    StatItem,
)
from deepmd.utils.path import (
    DPPath,
)
from deepmd.utils.version import (
    check_version_compatibility,
)

if not hasattr(torch.ops.deepmd, "tabulate_fusion_se_atten"):

    def tabulate_fusion_se_atten(
        argument0: torch.Tensor,
        argument1: torch.Tensor,
        argument2: torch.Tensor,
        argument3: torch.Tensor,
        argument4: torch.Tensor,
        argument5: int,
        argument6: bool,
    ) -> list[torch.Tensor]:
        raise NotImplementedError(
            "tabulate_fusion_se_atten is not available since customized PyTorch OP library is not built when freezing the model. "
            "See documentation for model compression for details."
        )

    # Note: this hack cannot actually save a model that can be runned using LAMMPS.
    torch.ops.deepmd.tabulate_fusion_se_atten = tabulate_fusion_se_atten


@DescriptorBlock.register("se_atten")
class DescrptBlockSeAtten(DescriptorBlock):
    def __init__(
        self,
        rcut: float,
        rcut_smth: float,
        sel: Union[list[int], int],
        ntypes: int,
        neuron: list = [25, 50, 100],
        axis_neuron: int = 16,
        tebd_dim: int = 8,
        tebd_input_mode: str = "concat",
        set_davg_zero: bool = True,
        attn: int = 128,
        attn_layer: int = 2,
        attn_dotr: bool = True,
        attn_mask: bool = False,
        activation_function: str = "tanh",
        precision: str = "float64",
        resnet_dt: bool = False,
        scaling_factor: float = 1.0,
        normalize: bool = True,
        temperature: Optional[float] = None,
        smooth: bool = True,
        type_one_side: bool = False,
        exclude_types: list[tuple[int, int]] = [],
        env_protection: float = 0.0,
        trainable_ln: bool = True,
        ln_eps: Optional[float] = 1e-5,
        seed: Optional[Union[int, list[int]]] = None,
        type: Optional[str] = None,
        trainable: bool = True,
    ) -> None:
        r"""Construct an embedding net of type `se_atten`.

        Parameters
        ----------
        rcut : float
            The cut-off radius :math:`r_c`
        rcut_smth : float
            From where the environment matrix should be smoothed :math:`r_s`
        sel : list[int], int
            list[int]: sel[i] specifies the maxmum number of type i atoms in the cut-off radius
            int: the total maxmum number of atoms in the cut-off radius
        ntypes : int
            Number of element types
        neuron : list[int]
            Number of neurons in each hidden layers of the embedding net :math:`\mathcal{N}`
        axis_neuron : int
            Number of the axis neuron :math:`M_2` (number of columns of the sub-matrix of the embedding matrix)
        tebd_dim : int
            Dimension of the type embedding
        tebd_input_mode : str
            The input mode of the type embedding. Supported modes are ["concat", "strip"].
            - "concat": Concatenate the type embedding with the smoothed radial information as the union input for the embedding network.
            - "strip": Use a separated embedding network for the type embedding and combine the output with the radial embedding network output.
        resnet_dt : bool
            Time-step `dt` in the resnet construction:
            y = x + dt * \phi (Wx + b)
        trainable_ln : bool
            Whether to use trainable shift and scale weights in layer normalization.
        ln_eps : float, Optional
            The epsilon value for layer normalization.
        type_one_side : bool
            If 'False', type embeddings of both neighbor and central atoms are considered.
            If 'True', only type embeddings of neighbor atoms are considered.
            Default is 'False'.
        attn : int
            Hidden dimension of the attention vectors
        attn_layer : int
            Number of attention layers
        attn_dotr : bool
            If dot the angular gate to the attention weights
        attn_mask : bool
            (Only support False to keep consistent with other backend references.)
            (Not used in this version.)
            If mask the diagonal of attention weights
        exclude_types : list[list[int]]
            The excluded pairs of types which have no interaction with each other.
            For example, `[[0, 1]]` means no interaction between type 0 and type 1.
        env_protection : float
            Protection parameter to prevent division by zero errors during environment matrix calculations.
        set_davg_zero : bool
            Set the shift of embedding net input to zero.
        activation_function : str
            The activation function in the embedding net. Supported options are |ACTIVATION_FN|
        precision : str
            The precision of the embedding net parameters. Supported options are |PRECISION|
        scaling_factor : float
            The scaling factor of normalization in calculations of attention weights.
            If `temperature` is None, the scaling of attention weights is (N_dim * scaling_factor)**0.5
        normalize : bool
            Whether to normalize the hidden vectors in attention weights calculation.
        temperature : float
            If not None, the scaling of attention weights is `temperature` itself.
        seed : int, Optional
            Random seed for parameter initialization.
        trainable : bool, default: True
            Whether this block is trainable
        """
        super().__init__()
        del type
        self.rcut = float(rcut)
        self.rcut_smth = float(rcut_smth)
        self.neuron = neuron
        self.filter_neuron = self.neuron
        self.axis_neuron = axis_neuron
        self.tebd_dim = tebd_dim
        self.tebd_input_mode = tebd_input_mode
        self.set_davg_zero = set_davg_zero
        self.attn_dim = attn
        self.attn_layer = attn_layer
        self.attn_dotr = attn_dotr
        self.attn_mask = attn_mask
        self.activation_function = activation_function
        self.precision = precision
        self.prec = PRECISION_DICT[self.precision]
        self.resnet_dt = resnet_dt
        self.scaling_factor = scaling_factor
        self.normalize = normalize
        self.temperature = temperature
        self.smooth = smooth
        self.type_one_side = type_one_side
        self.env_protection = env_protection
        self.trainable_ln = trainable_ln
        self.seed = seed
        #  to keep consistent with default value in this backends
        if ln_eps is None:
            ln_eps = 1e-5
        self.ln_eps = ln_eps

        if isinstance(sel, int):
            sel = [sel]

        self.ntypes = ntypes
        self.sel = sel
        self.sec = self.sel
        self.split_sel = self.sel
        self.nnei = sum(sel)
        self.ndescrpt = self.nnei * 4
        # order matters, placed after the assignment of self.ntypes
        self.reinit_exclude(exclude_types)

        self.dpa1_attention = NeighborGatedAttention(
            self.attn_layer,
            self.nnei,
            self.filter_neuron[-1],
            self.attn_dim,
            dotr=self.attn_dotr,
            do_mask=self.attn_mask,
            scaling_factor=self.scaling_factor,
            normalize=self.normalize,
            temperature=self.temperature,
            trainable_ln=self.trainable_ln,
            ln_eps=self.ln_eps,
            smooth=self.smooth,
            precision=self.precision,
            seed=child_seed(self.seed, 0),
            trainable=trainable,
        )

        wanted_shape = (self.ntypes, self.nnei, 4)
        mean = torch.zeros(wanted_shape, dtype=self.prec, device=env.DEVICE)
        stddev = torch.ones(wanted_shape, dtype=self.prec, device=env.DEVICE)
        self.register_buffer("mean", mean)
        self.register_buffer("stddev", stddev)
        self.tebd_dim_input = self.tebd_dim if self.type_one_side else self.tebd_dim * 2
        if self.tebd_input_mode in ["concat"]:
            self.embd_input_dim = 1 + self.tebd_dim_input
        else:
            self.embd_input_dim = 1

        self.filter_layers_strip = None
        filter_layers = NetworkCollection(
            ndim=0, ntypes=self.ntypes, network_type="embedding_network"
        )
        filter_layers[0] = EmbeddingNet(
            self.embd_input_dim,
            self.filter_neuron,
            activation_function=self.activation_function,
            precision=self.precision,
            resnet_dt=self.resnet_dt,
            seed=child_seed(self.seed, 1),
            trainable=trainable,
        )
        self.filter_layers = filter_layers
        if self.tebd_input_mode in ["strip"]:
            filter_layers_strip = NetworkCollection(
                ndim=0, ntypes=self.ntypes, network_type="embedding_network"
            )
            filter_layers_strip[0] = EmbeddingNet(
                self.tebd_dim_input,
                self.filter_neuron,
                activation_function=self.activation_function,
                precision=self.precision,
                resnet_dt=self.resnet_dt,
                seed=child_seed(self.seed, 2),
                trainable=trainable,
            )
            self.filter_layers_strip = filter_layers_strip
        self.stats = None

        self.tebd_compress = False
        self.geo_compress = False
        self.is_sorted = False
        # For geometric compression
        self.compress_info = nn.ParameterList(
            [nn.Parameter(torch.zeros(0, dtype=self.prec, device="cpu"))]
        )
        self.compress_data = nn.ParameterList(
            [nn.Parameter(torch.zeros(0, dtype=self.prec, device=env.DEVICE))]
        )
        # For type embedding compression
        self.register_buffer(
            "type_embd_data", torch.zeros(0, dtype=self.prec, device=env.DEVICE)
        )

    def get_rcut(self) -> float:
        """Returns the cut-off radius."""
        return self.rcut

    def get_rcut_smth(self) -> float:
        """Returns the radius where the neighbor information starts to smoothly decay to 0."""
        return self.rcut_smth

    def get_nsel(self) -> int:
        """Returns the number of selected atoms in the cut-off radius."""
        return sum(self.sel)

    def get_sel(self) -> list[int]:
        """Returns the number of selected atoms for each type."""
        return self.sel

    def get_ntypes(self) -> int:
        """Returns the number of element types."""
        return self.ntypes

    def get_dim_in(self) -> int:
        """Returns the input dimension."""
        return self.dim_in

    def get_dim_out(self) -> int:
        """Returns the output dimension."""
        return self.dim_out

    def get_dim_rot_mat_1(self) -> int:
        """Returns the first dimension of the rotation matrix. The rotation is of shape dim_1 x 3."""
        return self.filter_neuron[-1]

    def get_dim_emb(self) -> int:
        """Returns the output dimension of embedding."""
        return self.filter_neuron[-1]

    def __setitem__(self, key: str, value: Any) -> None:
        if key in ("avg", "data_avg", "davg"):
            self.mean = value
        elif key in ("std", "data_std", "dstd"):
            self.stddev = value
        else:
            raise KeyError(key)

    def __getitem__(self, key: str) -> Any:
        if key in ("avg", "data_avg", "davg"):
            return self.mean
        elif key in ("std", "data_std", "dstd"):
            return self.stddev
        else:
            raise KeyError(key)

    def mixed_types(self) -> bool:
        """If true, the descriptor
        1. assumes total number of atoms aligned across frames;
        2. requires a neighbor list that does not distinguish different atomic types.

        If false, the descriptor
        1. assumes total number of atoms of each atom type aligned across frames;
        2. requires a neighbor list that distinguishes different atomic types.

        """
        return True

    def get_env_protection(self) -> float:
        """Returns the protection of building environment matrix."""
        return self.env_protection

    @property
    def dim_out(self) -> int:
        """Returns the output dimension of this descriptor."""
        return self.filter_neuron[-1] * self.axis_neuron

    @property
    def dim_in(self) -> int:
        """Returns the atomic input dimension of this descriptor."""
        return self.tebd_dim

    @property
    def dim_emb(self) -> int:
        """Returns the output dimension of embedding."""
        return self.get_dim_emb()

    def compute_input_stats(
        self,
        merged: Union[Callable[[], list[dict]], list[dict]],
        path: Optional[DPPath] = None,
    ) -> None:
        """
        Compute the input statistics (e.g. mean and stddev) for the descriptors from packed data.

        Parameters
        ----------
        merged : Union[Callable[[], list[dict]], list[dict]]
            - list[dict]: A list of data samples from various data systems.
                Each element, `merged[i]`, is a data dictionary containing `keys`: `torch.Tensor`
                originating from the `i`-th data system.
            - Callable[[], list[dict]]: A lazy function that returns data samples in the above format
                only when needed. Since the sampling process can be slow and memory-intensive,
                the lazy function helps by only sampling once.
        path : Optional[DPPath]
            The path to the stat file.

        """
        env_mat_stat = EnvMatStatSe(self)
        if path is not None:
            path = path / env_mat_stat.get_hash()
        if path is None or not path.is_dir():
            if callable(merged):
                # only get data for once
                sampled = merged()
            else:
                sampled = merged
        else:
            sampled = []
        env_mat_stat.load_or_compute_stats(sampled, path)
        self.stats = env_mat_stat.stats
        mean, stddev = env_mat_stat()
        if not self.set_davg_zero:
            self.mean.copy_(
                torch.tensor(mean, device=env.DEVICE, dtype=self.mean.dtype)
            )
        self.stddev.copy_(
            torch.tensor(stddev, device=env.DEVICE, dtype=self.stddev.dtype)
        )

    def get_stats(self) -> dict[str, StatItem]:
        """Get the statistics of the descriptor."""
        if self.stats is None:
            raise RuntimeError(
                "The statistics of the descriptor has not been computed."
            )
        return self.stats

    def reinit_exclude(
        self,
        exclude_types: list[tuple[int, int]] = [],
    ) -> None:
        self.exclude_types = exclude_types
        self.is_sorted = len(self.exclude_types) == 0
        self.emask = PairExcludeMask(self.ntypes, exclude_types=exclude_types)

    def enable_compression(
        self,
        table_data: dict,
        table_config: dict,
        lower: dict,
        upper: dict,
    ) -> None:
        net = "filter_net"
        self.compress_info[0] = torch.as_tensor(
            [
                lower[net],
                upper[net],
                upper[net] * table_config[0],
                table_config[1],
                table_config[2],
                table_config[3],
            ],
            dtype=self.prec,
            device="cpu",
        )
        self.compress_data[0] = table_data[net].to(device=env.DEVICE, dtype=self.prec)
        self.geo_compress = True

    def type_embedding_compression(self, type_embedding_net: TypeEmbedNet) -> None:
        """Enable type embedding compression for strip mode.

        Precomputes embedding network outputs for all type combinations:
        - One-side: (ntypes+1) combinations (neighbor types only)
        - Two-side: (ntypes+1)² combinations (neighbor x center type pairs)

        Parameters
        ----------
        type_embedding_net : TypeEmbedNet
            The type embedding network that provides get_full_embedding() method
        """
        if self.tebd_input_mode != "strip":
            raise RuntimeError("Type embedding compression only works in strip mode")
        if self.filter_layers_strip is None:
            raise RuntimeError(
                "filter_layers_strip must be initialized for type embedding compression"
            )

        with torch.no_grad():
            # Get full type embedding: (ntypes+1) x tebd_dim
            full_embd = type_embedding_net.get_full_embedding(env.DEVICE)
            nt, t_dim = full_embd.shape

            if self.type_one_side:
                # One-side: only neighbor types, much simpler!
                # Precompute for all (ntypes+1) neighbor types
                embd_tensor = self.filter_layers_strip.networks[0](full_embd).detach()
                if hasattr(self, "type_embd_data"):
                    del self.type_embd_data
                self.register_buffer("type_embd_data", embd_tensor)
            else:
                # Two-side: all (ntypes+1)² type pair combinations
                # Create [neighbor, center] combinations
                # for a fixed row i, all columns j have different neighbor types
                embd_nei = full_embd.view(1, nt, t_dim).expand(nt, nt, t_dim)
                # for a fixed row i, all columns j share the same center type i
                embd_center = full_embd.view(nt, 1, t_dim).expand(nt, nt, t_dim)
                two_side_embd = torch.cat([embd_nei, embd_center], dim=-1).reshape(
                    -1, t_dim * 2
                )
                # Precompute for all type pairs
                # Index formula: idx = center_type * nt + neighbor_type
                embd_tensor = self.filter_layers_strip.networks[0](
                    two_side_embd
                ).detach()
                if hasattr(self, "type_embd_data"):
                    del self.type_embd_data
                self.register_buffer("type_embd_data", embd_tensor)

        self.tebd_compress = True

    def forward(
        self,
        nlist: torch.Tensor,
        extended_coord: torch.Tensor,
        extended_atype: torch.Tensor,
        extended_atype_embd: Optional[torch.Tensor] = None,
        mapping: Optional[torch.Tensor] = None,
        type_embedding: Optional[torch.Tensor] = None,
    ) -> tuple[
        torch.Tensor,
        Optional[torch.Tensor],
        Optional[torch.Tensor],
        Optional[torch.Tensor],
        Optional[torch.Tensor],
    ]:
        """Compute the descriptor.

        Parameters
        ----------
        nlist
            The neighbor list. shape: nf x nloc x nnei
        extended_coord
            The extended coordinates of atoms. shape: nf x (nallx3)
        extended_atype
            The extended aotm types. shape: nf x nall x nt
        extended_atype_embd
            The extended type embedding of atoms. shape: nf x nall
        mapping
            The index mapping, not required by this descriptor.
        type_embedding
            Full type embeddings. shape: (ntypes+1) x nt
            Required for stripped type embeddings.

        Returns
        -------
        result
            The descriptor. shape: nf x nloc x (ng x axis_neuron)
        g2
            The rotationally invariant pair-partical representation.
            shape: nf x nloc x nnei x ng
        h2
            The rotationally equivariant pair-partical representation.
            shape: nf x nloc x nnei x 3
        gr
            The rotationally equivariant and permutationally invariant single particle
            representation. shape: nf x nloc x ng x 3
        sw
            The smooth switch function. shape: nf x nloc x nnei

        """
        del mapping
        assert extended_atype_embd is not None
        nframes, nloc, nnei = nlist.shape
        atype = extended_atype[:, :nloc]
        nb = nframes
        nall = extended_coord.view(nb, -1, 3).shape[1]
        dmatrix, diff, sw = prod_env_mat(
            extended_coord,
            nlist,
            atype,
            self.mean,
            self.stddev,
            self.rcut,
            self.rcut_smth,
            protection=self.env_protection,
        )
        # nb x nloc x nnei
        exclude_mask = self.emask(nlist, extended_atype)
        nlist = torch.where(exclude_mask != 0, nlist, -1)
        nlist_mask = nlist != -1
        nlist = torch.where(nlist == -1, 0, nlist)
        sw = torch.squeeze(sw, -1)
        # nf x nall x nt
        nt = extended_atype_embd.shape[-1]
        # beyond the cutoff sw should be 0.0
        sw = sw.masked_fill(~nlist_mask, 0.0)
        # (nb x nloc) x nnei
        exclude_mask = exclude_mask.view(nb * nloc, nnei)
        # nfnl x nnei x 4
        dmatrix = dmatrix.view(-1, self.nnei, 4)
        nfnl = dmatrix.shape[0]
        # nfnl x nnei x 4
        rr = dmatrix
        rr = rr * exclude_mask[:, :, None]
        ss = rr[:, :, :1]
        if self.tebd_input_mode in ["concat"]:
            atype_tebd_ext = extended_atype_embd
            # nb x (nloc x nnei) x nt
            index = nlist.reshape(nb, nloc * nnei).unsqueeze(-1).expand(-1, -1, nt)
            # nb x (nloc x nnei) x nt
            atype_tebd_nlist = torch.gather(atype_tebd_ext, dim=1, index=index)  # j
            # nb x nloc x nnei x nt
            atype_tebd_nlist = atype_tebd_nlist.view(nb, nloc, nnei, nt)

            # nf x nloc x nt -> nf x nloc x nnei x nt
            atype_tebd = extended_atype_embd[:, :nloc, :]
            atype_tebd_nnei = atype_tebd.unsqueeze(2).expand(-1, -1, self.nnei, -1)  # i

            nlist_tebd = atype_tebd_nlist.reshape(nfnl, nnei, self.tebd_dim)
            atype_tebd = atype_tebd_nnei.reshape(nfnl, nnei, self.tebd_dim)
            if not self.type_one_side:
                # nfnl x nnei x (1 + tebd_dim * 2)
                ss = torch.concat([ss, nlist_tebd, atype_tebd], dim=2)
            else:
                # nfnl x nnei x (1 + tebd_dim)
                ss = torch.concat([ss, nlist_tebd], dim=2)
            # nfnl x nnei x ng
            gg = self.filter_layers.networks[0](ss)
            input_r = torch.nn.functional.normalize(
                rr.reshape(-1, self.nnei, 4)[:, :, 1:4], dim=-1
            )
            gg = self.dpa1_attention(
                gg, nlist_mask, input_r=input_r, sw=sw
            )  # shape is [nframes*nloc, self.neei, out_size]
            # nfnl x 4 x ng
            xyz_scatter = torch.matmul(rr.permute(0, 2, 1), gg)
        elif self.tebd_input_mode in ["strip"]:
            assert self.filter_layers_strip is not None
            assert type_embedding is not None
            ng = self.filter_neuron[-1]
            ntypes_with_padding = type_embedding.shape[0]
            # nf x (nl x nnei)
            nlist_index = nlist.reshape(nb, nloc * nnei)
            # nf x (nl x nnei)
            nei_type = torch.gather(extended_atype, dim=1, index=nlist_index)
            if self.type_one_side:
                if self.tebd_compress:
                    tt_full = self.type_embd_data
                else:
                    # (ntypes+1, tebd_dim) -> (ntypes+1, ng)
                    tt_full = self.filter_layers_strip.networks[0](type_embedding)
                # (nf*nl*nnei,) -> (nf*nl*nnei, ng)
                gg_t = tt_full[nei_type.view(-1).type(torch.long)]
            else:
                idx_i = torch.tile(
                    atype.reshape(-1, 1) * ntypes_with_padding, [1, nnei]
                ).view(-1)
                idx_j = nei_type.view(-1)
                # (nf x nl x nnei)
                idx = (idx_i + idx_j).to(torch.long)
                if self.tebd_compress:
                    # ((ntypes+1)^2, ng)
                    tt_full = self.type_embd_data
                else:
                    # ((ntypes+1)^2) * (ntypes+1)^2 * nt
                    type_embedding_nei = torch.tile(
                        type_embedding.view(1, ntypes_with_padding, nt),
                        [ntypes_with_padding, 1, 1],
                    )
                    # (ntypes+1)^2 * ((ntypes+1)^2) * nt
                    type_embedding_center = torch.tile(
                        type_embedding.view(ntypes_with_padding, 1, nt),
                        [1, ntypes_with_padding, 1],
                    )
                    # ((ntypes+1)^2 * (ntypes+1)^2) * (nt+nt)
                    two_side_type_embedding = torch.cat(
                        [type_embedding_nei, type_embedding_center], -1
                    ).reshape(-1, nt * 2)
                    tt_full = self.filter_layers_strip.networks[0](
                        two_side_type_embedding
                    )
                # (nf x nl x nnei) x ng
                gg_t = tt_full[idx]
            # (nf x nl) x nnei x ng
            gg_t = gg_t.reshape(nfnl, nnei, ng)
            if self.smooth:
                gg_t = gg_t * sw.reshape(-1, self.nnei, 1)
            if self.geo_compress:
                ss = ss.reshape(-1, 1)
                gg_t = gg_t.reshape(-1, gg_t.size(-1))
                xyz_scatter = torch.ops.deepmd.tabulate_fusion_se_atten(
                    self.compress_data[0].contiguous(),
                    self.compress_info[0].cpu().contiguous(),
                    ss.contiguous(),
                    rr.contiguous(),
                    gg_t.contiguous(),
                    self.filter_neuron[-1],
                    self.is_sorted,
                )[0]
                # to make torchscript happy
                gg = torch.empty(
                    nframes,
                    nloc,
                    self.nnei,
                    self.filter_neuron[-1],
                    dtype=gg_t.dtype,
                    device=gg_t.device,
                )
            else:
                # nfnl x nnei x ng
                gg_s = self.filter_layers.networks[0](ss)
                # nfnl x nnei x ng
                gg = gg_s * gg_t + gg_s
                input_r = torch.nn.functional.normalize(
                    rr.reshape(-1, self.nnei, 4)[:, :, 1:4], dim=-1
                )
                gg = self.dpa1_attention(
                    gg, nlist_mask, input_r=input_r, sw=sw
                )  # shape is [nframes*nloc, self.neei, out_size]
                # nfnl x 4 x ng
                xyz_scatter = torch.matmul(rr.permute(0, 2, 1), gg)
        else:
            raise NotImplementedError

        xyz_scatter = xyz_scatter / self.nnei
        xyz_scatter_1 = xyz_scatter.permute(0, 2, 1)
        rot_mat = xyz_scatter_1[:, :, 1:4]
        xyz_scatter_2 = xyz_scatter[:, :, 0 : self.axis_neuron]
        result = torch.matmul(
            xyz_scatter_1, xyz_scatter_2
        )  # shape is [nframes*nloc, self.filter_neuron[-1], self.axis_neuron]

        return (
            result.view(nframes, nloc, self.filter_neuron[-1] * self.axis_neuron),
            gg.view(nframes, nloc, self.nnei, self.filter_neuron[-1])
            if not self.geo_compress
            else None,
            dmatrix.view(nframes, nloc, self.nnei, 4)[..., 1:],
            rot_mat.view(nframes, nloc, self.filter_neuron[-1], 3),
            sw,
        )

    def has_message_passing(self) -> bool:
        """Returns whether the descriptor block has message passing."""
        return False

    def need_sorted_nlist_for_lower(self) -> bool:
        """Returns whether the descriptor block needs sorted nlist when using `forward_lower`."""
        return False


class NeighborGatedAttention(nn.Module):
    def __init__(
        self,
        layer_num: int,
        nnei: int,
        embed_dim: int,
        hidden_dim: int,
        dotr: bool = False,
        do_mask: bool = False,
        scaling_factor: float = 1.0,
        normalize: bool = True,
        temperature: Optional[float] = None,
        trainable_ln: bool = True,
        ln_eps: float = 1e-5,
        smooth: bool = True,
        precision: str = DEFAULT_PRECISION,
        seed: Optional[Union[int, list[int]]] = None,
        trainable: bool = True,
    ) -> None:
        """Construct a neighbor-wise attention net."""
        super().__init__()
        self.layer_num = layer_num
        self.nnei = nnei
        self.embed_dim = embed_dim
        self.hidden_dim = hidden_dim
        self.dotr = dotr
        self.do_mask = do_mask
        self.scaling_factor = scaling_factor
        self.normalize = normalize
        self.temperature = temperature
        self.trainable_ln = trainable_ln
        self.ln_eps = ln_eps
        self.smooth = smooth
        self.precision = precision
        self.seed = seed
        self.network_type = NeighborGatedAttentionLayer
        attention_layers = []
        for i in range(self.layer_num):
            attention_layers.append(
                NeighborGatedAttentionLayer(
                    nnei,
                    embed_dim,
                    hidden_dim,
                    dotr=dotr,
                    do_mask=do_mask,
                    scaling_factor=scaling_factor,
                    normalize=normalize,
                    temperature=temperature,
                    trainable_ln=trainable_ln,
                    ln_eps=ln_eps,
                    smooth=smooth,
                    precision=precision,
                    seed=child_seed(seed, i),
                    trainable=trainable,
                )
            )
        self.attention_layers = nn.ModuleList(attention_layers)

    def forward(
        self,
        input_G: torch.Tensor,
        nei_mask: torch.Tensor,
        input_r: Optional[torch.Tensor] = None,
        sw: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Compute the multi-layer gated self-attention.

        Parameters
        ----------
        input_G
            inputs with shape: (nf x nloc) x nnei x embed_dim.
        nei_mask
            neighbor mask, with paddings being 0. shape: (nf x nloc) x nnei.
        input_r
            normalized radial. shape: (nf x nloc) x nnei x 3.
        sw
            The smooth switch function. shape: nf x nloc x nnei
        """
        out = input_G
        # https://github.com/pytorch/pytorch/issues/39165#issuecomment-635472592
        for layer in self.attention_layers:
            out = layer(out, nei_mask, input_r=input_r, sw=sw)
        return out

    def __getitem__(self, key: int) -> Any:
        if isinstance(key, int):
            return self.attention_layers[key]
        else:
            raise TypeError(key)

    def __setitem__(self, key: int, value: Any) -> None:
        if not isinstance(key, int):
            raise TypeError(key)
        if isinstance(value, self.network_type):
            pass
        elif isinstance(value, dict):
            value = self.network_type.deserialize(value)
        else:
            raise TypeError(value)
        self.attention_layers[key] = value

    def serialize(self) -> dict:
        """Serialize the networks to a dict.

        Returns
        -------
        dict
            The serialized networks.
        """
        return {
            "@class": "NeighborGatedAttention",
            "@version": 1,
            "layer_num": self.layer_num,
            "nnei": self.nnei,
            "embed_dim": self.embed_dim,
            "hidden_dim": self.hidden_dim,
            "dotr": self.dotr,
            "do_mask": self.do_mask,
            "scaling_factor": self.scaling_factor,
            "normalize": self.normalize,
            "temperature": self.temperature,
            "trainable_ln": self.trainable_ln,
            "ln_eps": self.ln_eps,
            "precision": self.precision,
            "attention_layers": [layer.serialize() for layer in self.attention_layers],
        }

    @classmethod
    def deserialize(cls, data: dict) -> "NeighborGatedAttention":
        """Deserialize the networks from a dict.

        Parameters
        ----------
        data : dict
            The dict to deserialize from.
        """
        data = data.copy()
        check_version_compatibility(data.pop("@version"), 1, 1)
        data.pop("@class")
        attention_layers = data.pop("attention_layers")
        obj = cls(**data)
        for ii, network in enumerate(attention_layers):
            obj[ii] = network
        return obj


class NeighborGatedAttentionLayer(nn.Module):
    def __init__(
        self,
        nnei: int,
        embed_dim: int,
        hidden_dim: int,
        dotr: bool = False,
        do_mask: bool = False,
        scaling_factor: float = 1.0,
        normalize: bool = True,
        temperature: Optional[float] = None,
        smooth: bool = True,
        trainable_ln: bool = True,
        ln_eps: float = 1e-5,
        precision: str = DEFAULT_PRECISION,
        seed: Optional[Union[int, list[int]]] = None,
        trainable: bool = True,
    ) -> None:
        """Construct a neighbor-wise attention layer."""
        super().__init__()
        self.nnei = nnei
        self.embed_dim = embed_dim
        self.hidden_dim = hidden_dim
        self.dotr = dotr
        self.do_mask = do_mask
        self.scaling_factor = scaling_factor
        self.normalize = normalize
        self.temperature = temperature
        self.precision = precision
        self.trainable_ln = trainable_ln
        self.ln_eps = ln_eps
        self.seed = seed
        self.attention_layer = GatedAttentionLayer(
            nnei,
            embed_dim,
            hidden_dim,
            dotr=dotr,
            do_mask=do_mask,
            scaling_factor=scaling_factor,
            normalize=normalize,
            temperature=temperature,
            smooth=smooth,
            precision=precision,
            seed=child_seed(seed, 0),
            trainable=trainable,
        )
        self.attn_layer_norm = LayerNorm(
            self.embed_dim,
            eps=ln_eps,
            trainable=trainable_ln,
            precision=precision,
            seed=child_seed(seed, 1),
        )

    def forward(
        self,
        x: torch.Tensor,
        nei_mask: torch.Tensor,
        input_r: Optional[torch.Tensor] = None,
        sw: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        residual = x
        x, _ = self.attention_layer(x, nei_mask, input_r=input_r, sw=sw)
        x = residual + x
        x = self.attn_layer_norm(x)
        return x

    def serialize(self) -> dict:
        """Serialize the networks to a dict.

        Returns
        -------
        dict
            The serialized networks.
        """
        return {
            "nnei": self.nnei,
            "embed_dim": self.embed_dim,
            "hidden_dim": self.hidden_dim,
            "dotr": self.dotr,
            "do_mask": self.do_mask,
            "scaling_factor": self.scaling_factor,
            "normalize": self.normalize,
            "temperature": self.temperature,
            "trainable_ln": self.trainable_ln,
            "ln_eps": self.ln_eps,
            "precision": self.precision,
            "attention_layer": self.attention_layer.serialize(),
            "attn_layer_norm": self.attn_layer_norm.serialize(),
        }

    @classmethod
    def deserialize(cls, data: dict) -> "NeighborGatedAttentionLayer":
        """Deserialize the networks from a dict.

        Parameters
        ----------
        data : dict
            The dict to deserialize from.
        """
        data = data.copy()
        attention_layer = data.pop("attention_layer")
        attn_layer_norm = data.pop("attn_layer_norm")
        obj = cls(**data)
        obj.attention_layer = GatedAttentionLayer.deserialize(attention_layer)
        obj.attn_layer_norm = LayerNorm.deserialize(attn_layer_norm)
        return obj


class GatedAttentionLayer(nn.Module):
    def __init__(
        self,
        nnei: int,
        embed_dim: int,
        hidden_dim: int,
        num_heads: int = 1,
        dotr: bool = False,
        do_mask: bool = False,
        scaling_factor: float = 1.0,
        normalize: bool = True,
        temperature: Optional[float] = None,
        bias: bool = True,
        smooth: bool = True,
        precision: str = DEFAULT_PRECISION,
        seed: Optional[Union[int, list[int]]] = None,
        trainable: bool = True,
    ) -> None:
        """Construct a multi-head neighbor-wise attention net."""
        super().__init__()
        assert hidden_dim % num_heads == 0, "hidden_dim must be divisible by num_heads"
        self.nnei = nnei
        self.embed_dim = embed_dim
        self.hidden_dim = hidden_dim
        self.num_heads = num_heads
        self.head_dim = hidden_dim // num_heads
        self.dotr = dotr
        self.do_mask = do_mask
        self.bias = bias
        self.smooth = smooth
        self.scaling_factor = scaling_factor
        self.temperature = temperature
        self.precision = precision
        self.seed = seed
        self.scaling = (
            (self.head_dim * scaling_factor) ** -0.5
            if temperature is None
            else temperature
        )
        self.normalize = normalize
        self.in_proj = MLPLayer(
            embed_dim,
            hidden_dim * 3,
            bias=bias,
            use_timestep=False,
            bavg=0.0,
            stddev=1.0,
            precision=precision,
            seed=child_seed(seed, 0),
            trainable=trainable,
        )
        self.out_proj = MLPLayer(
            hidden_dim,
            embed_dim,
            bias=bias,
            use_timestep=False,
            bavg=0.0,
            stddev=1.0,
            precision=precision,
            seed=child_seed(seed, 1),
            trainable=trainable,
        )

    def forward(
        self,
        query: torch.Tensor,
        nei_mask: torch.Tensor,
        input_r: Optional[torch.Tensor] = None,
        sw: Optional[torch.Tensor] = None,
        attnw_shift: float = 20.0,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Compute the multi-head gated self-attention.

        Parameters
        ----------
        query
            inputs with shape: (nf x nloc) x nnei x embed_dim.
        nei_mask
            neighbor mask, with paddings being 0. shape: (nf x nloc) x nnei.
        input_r
            normalized radial. shape: (nf x nloc) x nnei x 3.
        sw
            The smooth switch function. shape: (nf x nloc) x nnei
        attnw_shift : float
            The attention weight shift to preserve smoothness when doing padding before softmax.
        """
        q, k, v = self.in_proj(query).chunk(3, dim=-1)

        # Reshape for multi-head attention: (nf x nloc) x num_heads x nnei x head_dim
        q = q.view(-1, self.nnei, self.num_heads, self.head_dim).transpose(1, 2)
        k = k.view(-1, self.nnei, self.num_heads, self.head_dim).transpose(1, 2)
        v = v.view(-1, self.nnei, self.num_heads, self.head_dim).transpose(1, 2)

        if self.normalize:
            q = torch_func.normalize(q, dim=-1)
            k = torch_func.normalize(k, dim=-1)
            v = torch_func.normalize(v, dim=-1)

        q = q * self.scaling
        # (nf x nloc) x num_heads x head_dim x nnei
        k = k.transpose(-2, -1)

        # Compute attention scores
        # (nf x nloc) x num_heads x nnei x nnei
        attn_weights = torch.matmul(q, k)
        # (nf x nloc) x nnei
        nei_mask = nei_mask.view(-1, self.nnei)

        if self.smooth:
            assert sw is not None
            # (nf x nloc) x 1 x nnei
            sw = sw.view(-1, 1, self.nnei)
            attn_weights = (attn_weights + attnw_shift) * sw[:, :, :, None] * sw[
                :, :, None, :
            ] - attnw_shift
        else:
            # (nf x nloc) x 1 x 1 x nnei
            attn_weights = attn_weights.masked_fill(
                ~nei_mask.unsqueeze(1).unsqueeze(1), float("-inf")
            )

        attn_weights = torch_func.softmax(attn_weights, dim=-1)
        attn_weights = attn_weights.masked_fill(
            ~nei_mask.unsqueeze(1).unsqueeze(-1), 0.0
        )
        if self.smooth:
            assert sw is not None
            attn_weights = attn_weights * sw[:, :, :, None] * sw[:, :, None, :]

        if self.dotr:
            # (nf x nloc) x nnei x 3
            assert input_r is not None, "input_r must be provided when dotr is True!"
            # (nf x nloc) x 1 x nnei x nnei
            angular_weight = torch.matmul(input_r, input_r.transpose(-2, -1)).view(
                -1, 1, self.nnei, self.nnei
            )
            attn_weights = attn_weights * angular_weight

        # Apply attention to values
        # (nf x nloc) x nnei x (num_heads x head_dim)
        o = (
            torch.matmul(attn_weights, v)
            .transpose(1, 2)
            .reshape(-1, self.nnei, self.hidden_dim)
        )
        output = self.out_proj(o)
        return output, attn_weights

    def serialize(self) -> dict:
        """Serialize the networks to a dict.

        Returns
        -------
        dict
            The serialized networks.
        """
        return {
            "nnei": self.nnei,
            "embed_dim": self.embed_dim,
            "hidden_dim": self.hidden_dim,
            "num_heads": self.num_heads,
            "dotr": self.dotr,
            "do_mask": self.do_mask,
            "scaling_factor": self.scaling_factor,
            "normalize": self.normalize,
            "temperature": self.temperature,
            "bias": self.bias,
            "smooth": self.smooth,
            "precision": self.precision,
            "in_proj": self.in_proj.serialize(),
            "out_proj": self.out_proj.serialize(),
        }

    @classmethod
    def deserialize(cls, data: dict) -> "GatedAttentionLayer":
        """Deserialize the networks from a dict.

        Parameters
        ----------
        data : dict
            The dict to deserialize from.
        """
        data = data.copy()
        in_proj = data.pop("in_proj")
        out_proj = data.pop("out_proj")
        obj = cls(**data)
        obj.in_proj = MLPLayer.deserialize(in_proj)
        obj.out_proj = MLPLayer.deserialize(out_proj)
        return obj
