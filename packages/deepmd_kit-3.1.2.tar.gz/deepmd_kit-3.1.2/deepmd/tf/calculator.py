# SPDX-License-Identifier: LGPL-3.0-or-later
from deepmd.calculator import (
    DP,
)

__all__ = [
    "DP",
]
