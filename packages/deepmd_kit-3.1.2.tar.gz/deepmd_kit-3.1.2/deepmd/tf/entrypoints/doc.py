# SPDX-License-Identifier: LGPL-3.0-or-later
from deepmd.entrypoints.doc import (
    doc_train_input,
)

__all__ = ["doc_train_input"]
