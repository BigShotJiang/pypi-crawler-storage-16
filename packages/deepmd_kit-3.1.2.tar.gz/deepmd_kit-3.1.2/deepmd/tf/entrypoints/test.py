# SPDX-License-Identifier: LGPL-3.0-or-later
from deepmd.entrypoints.test import (
    test,
)

__all__ = ["test"]
