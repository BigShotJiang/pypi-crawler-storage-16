# SPDX-License-Identifier: LGPL-3.0-or-later
from deepmd.infer.deep_dos import (
    DeepDOS,
)

__all__ = [
    "DeepDOS",
]
