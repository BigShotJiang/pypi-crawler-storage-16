# SPDX-License-Identifier: LGPL-3.0-or-later
"""nvnmd.se_a
==========.

Provides
    1. building descriptor with continuous embedding network
    2. building descriptor with quantized embedding network

"""
