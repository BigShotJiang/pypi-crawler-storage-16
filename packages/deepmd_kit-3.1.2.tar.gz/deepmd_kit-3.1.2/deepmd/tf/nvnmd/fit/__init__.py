# SPDX-License-Identifier: LGPL-3.0-or-later
"""nvnmd.fit
=========.

Provides
    1. continuous fitting network
    2. quantized fitting network

"""
