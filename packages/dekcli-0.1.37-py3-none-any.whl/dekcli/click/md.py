import typer
from typing_extensions import Annotated
from dektools.file import read_text, write_file
from ..core.markdown.dataurl import native_image_embed

app = typer.Typer(add_completion=False)


@app.command()
def dataurl(src, dst: Annotated[str, typer.Argument()] = "", path: Annotated[str, typer.Argument()] = ""):
    s = read_text(src)
    if not dst:
        dst = src
        write_file(src + '.bak', s=s)
    if not path:
        path = src + '.images'
    write_file(dst, native_image_embed(s, path))


@app.callback()
def callback():
    pass
