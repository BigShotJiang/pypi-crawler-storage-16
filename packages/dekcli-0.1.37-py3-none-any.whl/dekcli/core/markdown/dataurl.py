import os
import marko
from marko.md_renderer import MarkdownRenderer
from dektools.web.url import Url
from dektools.fetch import download_content, DownloadException
from dektools.file import write_file, normal_path


class NativeImageEmbedder(MarkdownRenderer):
    def __init__(self, path):
        super().__init__()
        self.path = normal_path(path)

    def render_image(self, element):
        url = element.dest
        if url.startswith('http://') or url.startswith('https://'):
            try:
                content = download_content(url)
            except DownloadException:
                pass
            else:
                paths = [x for x in Url.new(url).path.split('/')]
                write_file(os.path.join(self.path, *paths), b=content)
                element.dest = './' + '/'.join([os.path.basename(self.path), *paths])
        return super().render_image(element)


def native_image_embed(s, path):
    return NativeImageEmbedder(path).render(marko.parse(s))
