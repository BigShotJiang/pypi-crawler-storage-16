# Deker Server Adapters

This repository contains [Deker](https://github.com/openweathermap/deker) engine storage adapter
plugin package that provides support for accessing data remotely stored on
[OpenWeather](https://openweathermap.org) managed Deker server infrastructure.

Please refer to Deker [documentation](https://docs.deker.io) for more details.
