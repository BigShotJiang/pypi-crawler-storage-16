def get_api_version() -> str:
    """Get API Version."""
    return "v1"
