"""Parsers package.

Language-specific code and config parsers are registered from here.
"""

# Ecosystem registration must tolerate arbitrary import failures for resilience.


import logging

from depanalyzer.parsers.registry import register_ecosystem
from depanalyzer.runtime.ecosystem_config_registry import EcosystemConfigRegistry

logger = logging.getLogger("depanalyzer.parsers")

# Track registration status
_registered_ecosystems = []
_failed_ecosystems = []

# Import Maven ecosystem components
try:
    from depanalyzer.parsers.maven.detector import MavenDetector
    from depanalyzer.parsers.maven.config_parser import MavenParser
    from depanalyzer.parsers.maven.dep_fetcher import MavenDepFetcher
    from depanalyzer.parsers.maven.code_parser import MavenCodeParser
    from depanalyzer.parsers.maven.linker import MavenLinker

    _MAVEN_AVAILABLE = True
    logger.debug("✓ Maven ecosystem components imported successfully")
except ImportError as e:
    logger.error("❌ Maven ecosystem imports failed: %s", e, exc_info=True)
    _MAVEN_AVAILABLE = False
    _failed_ecosystems.append(("maven", str(e)))

# Import CPP ecosystem components
try:
    from depanalyzer.parsers.cpp.cmake.detector import CMakeDetector
    from depanalyzer.parsers.cpp.config_parser import CMakeParser
    from depanalyzer.parsers.cpp.dep_fetcher import CppDepFetcher
    from depanalyzer.parsers.cpp.code_parser import CppCodeParser
    from depanalyzer.parsers.cpp.linker import CppLinker

    _CPP_AVAILABLE = True
    logger.debug("✓ CPP ecosystem components imported successfully")
except ImportError as e:
    logger.error("❌ CPP ecosystem imports failed: %s", e, exc_info=True)
    logger.error(
        "CPP ecosystem will not be available. "
        "Please ensure all dependencies are installed (tree-sitter, tree-sitter-cmake, etc.)"
    )
    _CPP_AVAILABLE = False
    _failed_ecosystems.append(("cpp", str(e)))

# Import Hvigor ecosystem components
try:
    from depanalyzer.parsers.hvigor.detector import HvigorDetector
    from depanalyzer.parsers.hvigor.config_parser import HvigorParser
    from depanalyzer.parsers.hvigor.dep_fetcher import HvigorDepFetcher
    from depanalyzer.parsers.hvigor.code_parser import HvigorCodeParser
    from depanalyzer.parsers.hvigor.linker import HvigorLinker

    _HVIGOR_AVAILABLE = True
    logger.debug("✓ Hvigor ecosystem components imported successfully")
except ImportError as e:
    logger.error("❌ Hvigor ecosystem imports failed: %s", e, exc_info=True)
    logger.error(
        "Hvigor ecosystem will not be available. "
        "Please ensure all dependencies are installed (json5, requests, packaging, etc.)"
    )
    _HVIGOR_AVAILABLE = False
    _failed_ecosystems.append(("hvigor", str(e)))

# Import NPM ecosystem components
try:
    from depanalyzer.parsers.npm.detector import NpmDetector
    from depanalyzer.parsers.npm.config_parser import NpmParser
    from depanalyzer.parsers.npm.dep_fetcher import NpmDepFetcher
    from depanalyzer.parsers.npm.code_parser import NpmCodeParser
    from depanalyzer.parsers.npm.linker import NpmLinker

    _NPM_AVAILABLE = True
    logger.debug("✓ NPM ecosystem components imported successfully")
except ImportError as e:
    logger.error("❌ NPM ecosystem imports failed: %s", e, exc_info=True)
    logger.error(
        "NPM ecosystem will not be available. "
        "Please ensure all dependencies are installed (tree-sitter-javascript, requests, etc.)"
    )
    _NPM_AVAILABLE = False
    _failed_ecosystems.append(("npm", str(e)))


# Register CPP ecosystem (CMake-based)
if _CPP_AVAILABLE:
    try:
        from depanalyzer.parsers.cpp.config_model import CppEcosystemConfig

        register_ecosystem(
            ecosystem="cpp",
            detector_class=CMakeDetector,
            parser_class=CMakeParser,
            fetcher_class=CppDepFetcher,
            code_parser_class=CppCodeParser,
            linker_class=CppLinker,
        )
        # Register ecosystem configuration factory so that user-provided
        # TOML/JSON config under [ecosystems.cpp.*] can be parsed into
        # a strongly-typed configuration object.
        EcosystemConfigRegistry.register_config_factory(
            "cpp", CppEcosystemConfig.from_dict
        )
        logger.info("✓ Successfully registered CPP ecosystem (CMake-based)")
        _registered_ecosystems.append("cpp")
    except Exception as e:
        logger.error("Failed to register CPP ecosystem: %s", e, exc_info=True)
        _failed_ecosystems.append(("cpp", f"Registration failed: {e}"))

# Register Hvigor ecosystem (OpenHarmony)
if _HVIGOR_AVAILABLE:
    try:
        from depanalyzer.parsers.hvigor.config_model import HvigorEcosystemConfig

        register_ecosystem(
            ecosystem="hvigor",
            detector_class=HvigorDetector,
            parser_class=HvigorParser,
            fetcher_class=HvigorDepFetcher,
            code_parser_class=HvigorCodeParser,
            linker_class=HvigorLinker,
        )
        EcosystemConfigRegistry.register_config_factory(
            "hvigor", HvigorEcosystemConfig.from_dict
        )
        logger.info("✓ Successfully registered Hvigor ecosystem (OpenHarmony)")
        _registered_ecosystems.append("hvigor")
    except Exception as e:
        logger.error("Failed to register Hvigor ecosystem: %s", e, exc_info=True)
        _failed_ecosystems.append(("hvigor", f"Registration failed: {e}"))

# Register Maven ecosystem
if _MAVEN_AVAILABLE:
    try:
        from depanalyzer.parsers.maven.config_model import MavenEcosystemConfig

        register_ecosystem(
            ecosystem="maven",
            detector_class=MavenDetector,
            parser_class=MavenParser,
            fetcher_class=MavenDepFetcher,
            code_parser_class=MavenCodeParser,
            linker_class=MavenLinker,
        )
        EcosystemConfigRegistry.register_config_factory(
            "maven", MavenEcosystemConfig.from_dict
        )
        logger.info("✓ Successfully registered Maven ecosystem")
        _registered_ecosystems.append("maven")
    except Exception as e:
        logger.error("Failed to register Maven ecosystem: %s", e, exc_info=True)
        _failed_ecosystems.append(("maven", f"Registration failed: {e}"))

# Register NPM ecosystem (Node.js)
if _NPM_AVAILABLE:
    try:
        from depanalyzer.parsers.npm.config_model import NpmEcosystemConfig

        register_ecosystem(
            ecosystem="npm",
            detector_class=NpmDetector,
            parser_class=NpmParser,
            fetcher_class=NpmDepFetcher,
            code_parser_class=NpmCodeParser,
            linker_class=NpmLinker,
        )
        EcosystemConfigRegistry.register_config_factory(
            "npm", NpmEcosystemConfig.from_dict
        )
        logger.info("✓ Successfully registered NPM ecosystem (Node.js)")
        _registered_ecosystems.append("npm")
    except Exception as e:
        logger.error("Failed to register NPM ecosystem: %s", e, exc_info=True)
        _failed_ecosystems.append(("npm", f"Registration failed: {e}"))

# Summary logging
if _registered_ecosystems:
    logger.info(
        "Ecosystem registration complete: %d ecosystem(s) available: %s",
        len(_registered_ecosystems),
        ", ".join(_registered_ecosystems),
    )
else:
    logger.error(
        "⚠ WARNING: No ecosystems registered! Scanning will not work. "
        "Please check the error messages above and install required dependencies."
    )

if _failed_ecosystems:
    logger.warning(
        "Failed to register %d ecosystem(s): %s",
        len(_failed_ecosystems),
        ", ".join(f"{name} ({reason})" for name, reason in _failed_ecosystems),
    )


def get_registered_ecosystems():
    """Get list of successfully registered ecosystems.

    Returns:
        list: List of ecosystem names that were successfully registered.
    """
    return _registered_ecosystems.copy()


def get_failed_ecosystems():
    """Get list of ecosystems that failed to register.

    Returns:
        list: List of tuples (ecosystem_name, error_message).
    """
    return _failed_ecosystems.copy()


__all__ = [
    "register_ecosystem",
    "get_registered_ecosystems",
    "get_failed_ecosystems",
]

if _CPP_AVAILABLE:
    __all__.extend(
        [
            "CMakeDetector",
            "CMakeParser",
            "CppDepFetcher",
            "CppCodeParser",
        ]
    )

if _HVIGOR_AVAILABLE:
    __all__.extend(
        [
            "HvigorDetector",
            "HvigorParser",
            "HvigorDepFetcher",
            "HvigorCodeParser",
            "HvigorLinker",
        ]
    )

if _MAVEN_AVAILABLE:
    __all__.extend(
        [
            "MavenDetector",
            "MavenParser",
            "MavenDepFetcher",
            "MavenCodeParser",
            "MavenLinker",
        ]
    )

if _NPM_AVAILABLE:
    __all__.extend(
        [
            "NpmDetector",
            "NpmParser",
            "NpmDepFetcher",
            "NpmCodeParser",
            "NpmLinker",
        ]
    )
