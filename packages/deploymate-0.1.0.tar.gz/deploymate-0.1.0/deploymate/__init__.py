"""DeployMate - A deployment automation tool."""

__version__ = "0.1.0"
