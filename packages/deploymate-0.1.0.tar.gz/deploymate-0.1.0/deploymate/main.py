def main():
    print("Hello from deploymate!")


if __name__ == "__main__":
    main()
