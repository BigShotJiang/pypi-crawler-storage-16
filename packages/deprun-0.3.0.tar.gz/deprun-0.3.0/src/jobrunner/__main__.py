"""Entry point for python -m jobrunner."""

from jobrunner.cli import main

if __name__ == "__main__":
    main()
