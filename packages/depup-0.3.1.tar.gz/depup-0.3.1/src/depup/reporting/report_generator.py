"""
Module: report_generator
Generates Markdown or HTML reports summarizing upgrade results.
"""
