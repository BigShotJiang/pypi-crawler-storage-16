"""
Module: code_scanner
Handles post-upgrade code scanning for deprecated/removed APIs.
"""
