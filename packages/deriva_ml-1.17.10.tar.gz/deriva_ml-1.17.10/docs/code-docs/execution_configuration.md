# ExecutionConfiguration class

::: deriva_ml.execution.execution_configuration
    handler: python
