# Changelog

All notable changes to this project will be documented in this file.

This changelog should be updated with every pull request with some information about what has been changed. These changes can be added under a temporary title 'pre-release'.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).
Each release can have sections: "Added", "Changed", "Deprecated", "Removed", "Fixed" and "Security".

## [0.2.1] - 10-12-2025

# added

- CD to publish to PyPI

# changed

- changed repository visibility to public
- remove unnecessary dependencies and classifiers from pyproject.toml

## [0.2.0] - 10-12-2025

## added

- test authentication in CI

## security

- prompt for credentials ONLY
- dependabot to check vulenrabilities
- detect secrets in pre-commit

## removed

- API parameters username, password

## [0.1.0] - 10-12-2025

### added

- Generate access tokens for DESP using CLI or the function "get_tokens"
- Github actions workflow to install, check linter errors, run tests on pull request
