def main():
    print("Hello from booger!")


if __name__ == "__main__":
    main()
