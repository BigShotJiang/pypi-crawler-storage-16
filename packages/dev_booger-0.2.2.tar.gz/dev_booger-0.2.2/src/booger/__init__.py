"""Booger: Multi-port log aggregator with MCP integration."""

__version__ = "0.1.0"
