import asyncio
import os
from pathlib import Path
from typing import Optional, Literal
import argparse
import importlib.resources
from fastmcp import FastMCP

# Initialize a standalone MCP server for development tools
mcp = FastMCP("Dev Tools")

def get_script_path():
    with importlib.resources.files("tools") as tools_path:
        return str(tools_path / "ai-tracker.sh")

async def _run_ai_tracker_impl(
    force: bool = False,
    version_bump: Literal["major", "minor", "patch", "none"] = "patch",
    commit_hash: Optional[str] = None,
) -> str:
    """
    Core implementation for running the ai-tracker.sh script.
    """
    tools_script_path = get_script_path()
    # Construct command arguments
    args = [tools_script_path]

    if force:
        args.append("force")

    if commit_hash:
        args.extend(["-r", commit_hash])

    if version_bump:
        args.extend(["-v", version_bump])

    try:
        # Check if script exists and is executable
        if not os.path.exists(tools_script_path):
            return f"Error: Script not found at {tools_script_path}"

        if not os.access(tools_script_path, os.X_OK):
            # Try to make it executable
            try:
                os.chmod(tools_script_path, 0o755)
            except Exception as e:
                return f"Error: Script is not executable and chmod failed: {e}"

        # Prepare environment with /opt/homebrew/bin in PATH
        env = os.environ.copy()
        current_path = env.get("PATH", "")
        if "/opt/homebrew/bin" not in current_path:
            env["PATH"] = f"/opt/homebrew/bin:{current_path}"

        # Execute the script
        # We need to run this in the project root
        process = await asyncio.create_subprocess_exec(
            *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=Path.cwd(),
            env=env,
        )

        stdout, stderr = await process.communicate()

        output = ""
        if stdout:
            output += f"STDOUT:\n{stdout.decode()}\n"
        if stderr:
            output += f"STDERR:\n{stderr.decode()}\n"

        if process.returncode != 0:
            return f"Command failed with return code {process.returncode}:\n{output}"

        return f"Success:\n{output}"

    except Exception as e:
        return f"Error running ai-tracker: {str(e)}"


@mcp.tool()
async def run_ai_tracker(
    force: bool = False,
    version_bump: Literal["major", "minor", "patch", "none"] = "patch",
    commit_hash: Optional[str] = None,
) -> str:
    """
    Run the ai-tracker.sh script to track changes, generate AI summaries, and commit.

    Args:
        force: Ignore AI-detected errors and proceed with commit (default: False).
        version_bump: How to bump the version (default: "patch").
        commit_hash: Optional commit hash to generate diff from.
    """
    return await _run_ai_tracker_impl(
        force=force, version_bump=version_bump, commit_hash=commit_hash
    )


def main():
    """Run the ai-tracker tool from the command line."""
    parser = argparse.ArgumentParser(description="Run the ai-tracker script.")
    parser.add_argument(
        "-f",
        "--force",
        action="store_true",
        help="Ignore AI-detected errors and proceed with commit.",
    )
    parser.add_argument(
        "-b",
        "--version-bump",
        nargs="?",
        default="minor",
        const="minor",
        choices=["major", "minor", "patch", "none"],
        help="How to bump the version (default: minor).",
    )
    parser.add_argument(
        "-c",
        "--commit-hash",
        help="Optional commit hash to generate diff from.",
    )
    args = parser.parse_args()

    result = asyncio.run(
        _run_ai_tracker_impl(
            force=args.force,
            version_bump=args.version_bump,
            commit_hash=args.commit_hash,
        )
    )
    print(result)
