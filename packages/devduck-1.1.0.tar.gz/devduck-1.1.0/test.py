import devduck

devduck("list your tools")
