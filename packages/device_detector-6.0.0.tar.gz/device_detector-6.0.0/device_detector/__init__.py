__version__ = '6.0.0'
from .settings import *
from .parser import *
from .device_detector import *
