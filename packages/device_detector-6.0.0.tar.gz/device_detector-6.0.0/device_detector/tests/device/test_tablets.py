from ..base import DetectorBaseTest


class TestDetectTablet(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/tablet.yml',
    ]


class TestDetectTablet1(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/tablet-1.yml',
    ]


class TestDetectTablet2(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/tablet-2.yml',
    ]


class TestDetectTablet3(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/tablet-3.yml',
    ]


class TestDetectTablet4(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/tablet-4.yml',
    ]


class TestDetectTablet5(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/tablet-5.yml',
    ]


class TestDetectTablet6(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/tablet-6.yml',
    ]


class TestDetectTablet7(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/tablet-7.yml',
    ]


class TestDetectTablet8(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/tablet-8.yml',
    ]


class TestDetectTablet9(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/tablet-9.yml',
    ]


class TestDetectTablet10(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/tablet-10.yml',
    ]


class TestDetectTablet11(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/tablet-11.yml',
    ]


class TestDetectTablet12(DetectorBaseTest):

    fixture_files = [
        'tests/fixtures/upstream/tablet-12.yml',
    ]
