"""Shared utilities for devs package ecosystem."""

__version__ = "0.1.0"