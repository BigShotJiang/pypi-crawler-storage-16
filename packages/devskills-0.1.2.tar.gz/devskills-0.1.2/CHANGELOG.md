# Changelog

All notable changes to this project will be documented in this file.

## [0.1.0] - 2025-01-XX

Initial release.

### Features

- MCP server exposing skills as tools for AI coding agents
- CLI with `devskills init` and `devskills init-skill` commands
- Support for custom skill directories via `--skills-path`
- Three bundled skills: `skill-creator`, `mcp-builder`
- Works with Claude Code, GitHub Copilot, and Cursor
