"""DevSkills - MCP server exposing reusable skills for AI coding agents."""

__version__ = "0.1.0"
