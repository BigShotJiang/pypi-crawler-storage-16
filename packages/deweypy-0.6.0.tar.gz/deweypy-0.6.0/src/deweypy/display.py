from __future__ import annotations

from typing import Final

ELLIPSIS_CHAR: Final = "…"
