from .timer import Timer, TimerEntry
from .decorator import exec_time

__all__ = [
    "Timer",
    "TimerEntry",
    "exec_time",
]


# ======= Пример использования ========
if __name__ == '__main__':
    t = Timer(desc="main")
    t.start(name="timerA", desc="Process step 1")
    # ... code ...
    t.stop(name="timerA", format_='s')

    @exec_time
    def foo():
        print('foo')

    @exec_time(format_='h', print_=True, desc='Test bar')
    def bar(str_):
        from time import sleep
        sleep(2)
        print(str_)

    @exec_time(format_='mm:ss', print_=True, desc='Test bar2')
    def bar2(str_):
        from time import sleep
        sleep(3)
        print(str_)

    foo()
    bar('var')
    bar2('var2')
