from functools import wraps
from typing import Optional, Callable

from .timer import Timer


def exec_time(_func: Optional[Callable] = None, *, format_: Optional[str] = None, print_: bool = True, desc: Optional[str] = None, logger = None):
    """
    Декоратор для измерения времени выполнения функции.
    :param format_: None, 's', 'm', 'h' или форматы вида "HH:MM:SS"
    :param print_: выводить print или log.info
    :param desc: описание/метка
    """
    def decorator(func):
        timer = Timer(logger=logger, desc=desc)
        @wraps(func)
        def wrapper(*args, **kwargs):
            tname = desc or func.__name__
            timer.start(name=tname, desc=desc)
            result = func(*args, **kwargs)
            timer.stop(tname, format_=format_, print_=print_)
            return result
        return wrapper
    # Позволяет как с параметрами, так и без параметров использовать декоратор
    if _func is not None:
        return decorator(_func)
    return decorator
