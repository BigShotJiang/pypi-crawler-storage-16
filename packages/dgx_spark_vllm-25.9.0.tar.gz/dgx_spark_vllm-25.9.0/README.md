# DGX Spark vLLM

Pre-built vLLM environment for **NVIDIA DGX Spark (GB10, sm_121)**.

## Requirements

- NVIDIA DGX Spark (GB10 chip, sm_121)
- Ubuntu with CUDA 13.0 installed
- Python 3.12
- aarch64 (ARM64) architecture

## Installation

```bash
pip install dgx-spark-vllm
sudo dgx-spark-vllm-install
```

Then restart your shell or run:
```bash
source /etc/profile.d/nvidia-venv.sh
```

## Included Versions

| Package | Version |
|---------|---------|
| PyTorch | 2.9.0a0+50eac811a6.nv25.09 |
| vLLM | 0.10.1.1+381074ae.nv25.09 |
| CUDA | 13.0 |
| Triton | 3.4.0 |
| FlashAttention | 2.7.4 |
| cuDNN | 9.13.0 |
| NCCL | 2.27.7 |

## Usage

```python
import torch
print(torch.__version__)  # 2.9.0a0+50eac811a6.nv25.09
print(torch.cuda.get_device_name(0))  # NVIDIA GB10

import vllm
print(vllm.__version__)  # 0.10.1.1+381074ae.nv25.09
```

Run vLLM server:
```bash
python3 -m vllm.entrypoints.openai.api_server --model <model_name>
```

## What's Installed

- `/home/srpost/shared/nvidia-venv/` - Python packages
- `/opt/hpcx/` - HPC-X libraries (UCX, UCC, OpenMPI)
- `/usr/lib/aarch64-linux-gnu/libcudnn*` - cuDNN
- `/usr/lib/aarch64-linux-gnu/libnccl*` - NCCL
- `/usr/local/lib/libnvpl*` - NVPL (NVIDIA Performance Libraries)
- `/etc/ld.so.conf.d/00-hpcx.conf` - Library path config
- `/etc/profile.d/nvidia-venv.sh` - PYTHONPATH config

## License

The installer is Apache 2.0. The installed packages retain their original licenses (PyTorch BSD, vLLM Apache 2.0, NVIDIA components under NVIDIA license).
