"""DGX Spark vLLM environment installer"""
__version__ = "25.09.0"
