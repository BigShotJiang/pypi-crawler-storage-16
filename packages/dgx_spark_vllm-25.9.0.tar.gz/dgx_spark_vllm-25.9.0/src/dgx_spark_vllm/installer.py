#!/usr/bin/env python3
"""
DGX Spark vLLM Environment Installer

Downloads and installs pre-built vLLM environment for NVIDIA DGX Spark (GB10, sm_121)
"""
import os
import sys
import subprocess
import tempfile
from pathlib import Path

REPO_ID = "YakuzaNeko/dgx-spark-vllm"
FILENAME = "dgx-spark-vllm-25.09.tar.gz"


def check_platform():
    """Check if running on compatible platform"""
    import platform
    if platform.machine() != "aarch64":
        print("Error: This package is only for aarch64 (ARM64) platforms")
        print(f"Your platform: {platform.machine()}")
        sys.exit(1)


def check_sudo():
    """Check if we have sudo access"""
    if os.geteuid() != 0:
        print("Error: This installer requires root privileges")
        print("Run with: sudo dgx-spark-vllm-install")
        sys.exit(1)


def download_package():
    """Download package from HuggingFace"""
    from huggingface_hub import hf_hub_download

    print(f"Downloading {FILENAME} from HuggingFace...")
    print("This may take a while (~4GB)")

    local_path = hf_hub_download(
        repo_id=REPO_ID,
        filename=FILENAME,
        repo_type="model"
    )
    return local_path


def install_package(tar_path: str):
    """Extract and install the package"""
    print(f"Installing from {tar_path}...")

    # Extract to root
    result = subprocess.run(
        ["tar", "xzf", tar_path, "-C", "/"],
        capture_output=True,
        text=True
    )

    if result.returncode != 0:
        print(f"Error extracting: {result.stderr}")
        sys.exit(1)

    # Run ldconfig
    print("Running ldconfig...")
    subprocess.run(["ldconfig"], check=True)

    print("Installation complete!")


def print_usage():
    """Print usage instructions"""
    print("""
=== DGX Spark vLLM Environment Installed ===

Usage:
  python3 -c "import torch; print(torch.__version__)"
  python3 -c "import vllm; print(vllm.__version__)"

To run vLLM:
  python3 -m vllm.entrypoints.openai.api_server --model <model_name>

Included versions:
  - PyTorch: 2.9.0a0+50eac811a6.nv25.09
  - vLLM: 0.10.1.1+381074ae.nv25.09
  - CUDA: 13.0
  - Triton: 3.4.0
  - FlashAttention: 2.7.4

Note: PYTHONPATH is set in /etc/profile.d/nvidia-venv.sh
      You may need to restart your shell or run: source /etc/profile.d/nvidia-venv.sh
""")


def main():
    """Main installer entry point"""
    print("=== DGX Spark vLLM Installer ===")
    print("For NVIDIA DGX Spark (GB10, sm_121)")
    print()

    check_platform()
    check_sudo()

    tar_path = download_package()
    install_package(tar_path)
    print_usage()


if __name__ == "__main__":
    main()
