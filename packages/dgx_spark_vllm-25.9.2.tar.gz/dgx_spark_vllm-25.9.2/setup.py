from setuptools import setup
from setuptools.command.install import install
import sys

class PostInstallCommand(install):
    def run(self):
        install.run(self)
        print("""
╔══════════════════════════════════════════════════════════════════╗
║                    DGX Spark vLLM Installer                      ║
╠══════════════════════════════════════════════════════════════════╣
║                                                                  ║
║  ⚠️  IMPORTANT: Run this command to complete installation:       ║
║                                                                  ║
║      sudo dgx-spark-vllm-install                                 ║
║                                                                  ║
║  This will download ~4GB from HuggingFace and install:           ║
║    • PyTorch 2.9.0 (NVIDIA build for sm_121)                     ║
║    • vLLM 0.10.1.1 (NVIDIA build)                                ║
║    • cuDNN, NCCL, HPC-X libraries                                ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════════╝
""")

setup(
    cmdclass={
        'install': PostInstallCommand,
    },
)
