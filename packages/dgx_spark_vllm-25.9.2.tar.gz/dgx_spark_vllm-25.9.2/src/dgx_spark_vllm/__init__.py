"""DGX Spark vLLM environment installer"""
__version__ = "25.09.2"

# Show install instructions when imported
import sys
if "dgx_spark_vllm" in sys.modules and sys.argv and "pip" not in sys.argv[0]:
    print("""
╔══════════════════════════════════════════════════════════════════╗
║                    DGX Spark vLLM Installer                      ║
╠══════════════════════════════════════════════════════════════════╣
║  To install vLLM environment, run:                               ║
║                                                                  ║
║    sudo dgx-spark-vllm-install                                   ║
║                                                                  ║
║  This will download ~4GB from HuggingFace and install:           ║
║    - PyTorch 2.9.0 (NVIDIA build)                                ║
║    - vLLM 0.10.1.1 (NVIDIA build)                                ║
║    - cuDNN, NCCL, HPC-X libraries                                ║
╚══════════════════════════════════════════════════════════════════╝
""")
