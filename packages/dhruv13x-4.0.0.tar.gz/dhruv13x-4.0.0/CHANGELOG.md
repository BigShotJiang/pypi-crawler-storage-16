# Changelog

## [4.0.0] - 2025-12-10
### Other Changes
- update

## [3.0.1] - 2025-12-10
### Other Changes
- update
- update

## [3.0.0] - 2025-12-07
### Other Changes
- Increased test coverage to meet requirements

## [2.0.0] - 2025-12-07
### Features
- add restore command to cli (#3)
### Other Changes
- dhruv13x/dhruv13x
