Please see http://docs.plone.org/develop/coredev/docs/guidelines.html
