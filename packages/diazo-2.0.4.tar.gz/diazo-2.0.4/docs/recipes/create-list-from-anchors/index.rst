Create an unordered list from a series of elements
==================================================

This recipe demonstrates how you can create an unordered list from a
series of elements.

Rules
-----

.. literalinclude:: rules.xml
   :language: xml

Theme
-----

.. literalinclude:: theme.html
   :language: html

Content
-------

.. literalinclude:: content.html
   :language: html

Output
------

.. literalinclude:: output.html
   :language: html
