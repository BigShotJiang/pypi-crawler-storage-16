Allow curly brackets inside attributes
======================================

Use <copy> to copy the content while preserving the attribute of a
node in the HTML making sure that curly braces are accepted.

