# dichvusale-pyc
Small package to allow importing `.pyc` files as modules (fallback when `.py` is missing) and to compile `.py` files to `.pyc`.

Copyright (c) 2025 dichvusale.io.vn
