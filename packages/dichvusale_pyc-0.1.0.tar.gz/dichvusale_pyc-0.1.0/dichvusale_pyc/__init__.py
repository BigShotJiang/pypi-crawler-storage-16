"""
dichvusale_pyc — .pyc importer + compile utilities
Copyright (c) 2025 dichvusale.io.vn
License: MIT
"""
from .loader import install as _install_hook
from .util import compile_file, compile_directory

# auto-install hook on import for convenience
try:
    _install_hook()
except Exception:
    pass

__all__ = ["install", "compile_file", "compile_directory"]
def install():
    _install_hook()
