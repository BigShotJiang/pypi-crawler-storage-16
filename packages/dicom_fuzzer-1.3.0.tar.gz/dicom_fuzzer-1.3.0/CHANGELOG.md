# Changelog

All notable changes to DICOM-Fuzzer will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.3.0] - 2025-12-09 - Synthetic DICOM & Directory Support

### Added - Synthetic DICOM Generation

- **Synthetic Generator** (`synthetic.py`): Generate valid DICOM files with fabricated data
  - Support for 10 modalities: CT, MR, US, CR, DX, PT, NM, XA, RF, SC
  - Realistic pixel data patterns per modality (anatomical structures, gradients)
  - Series generation with consistent patient/study/series UIDs
  - No PHI concerns - all data is completely synthetic

- **Samples Subcommand** (`samples.py`): CLI for synthetic data and sample sources
  - `dicom-fuzzer samples --generate`: Generate synthetic test files
  - `dicom-fuzzer samples --list-sources`: List public DICOM sample sources
  - Options: `-m MODALITY`, `-c COUNT`, `--series`, `--rows`, `--columns`, `--seed`

### Added - Directory Input Support

- **Directory Scanning**: Accept directories as fuzzing input (not just single files)
  - `--recursive` / `-r` flag for recursive subdirectory scanning
  - Automatic DICOM detection by extension (.dcm, .dicom, .dic) and magic bytes
  - Progress tracking for batch processing with tqdm
  - Per-file mutation count with total estimation

### Added - Dashboard & Distributed Fuzzing

- **Dashboard Module** (`dicom_fuzzer/dashboard/`): Real-time monitoring
  - FastAPI WebSocket server with embedded HTML UI
  - Prometheus metrics exporter for monitoring integration
  - REST API endpoints for stats and crash information

- **Distributed Fuzzing Module** (`dicom_fuzzer/distributed/`): Scalable fuzzing
  - Redis-backed task queue with priority support and in-memory fallback
  - Master coordinator for campaign management
  - Worker nodes for distributed task execution
  - Local worker pool for single-machine parallel fuzzing

### Changed

- Remove emojis from documentation for professional formatting
- Update test coverage: network_fuzzer (97%), gui_monitor (69%)

## [1.2.0] - 2025-12-09 - PyPI Release

This release marks the first public PyPI release of DICOM-Fuzzer with comprehensive documentation, crash intelligence features, performance optimizations, and 5,400+ tests.

### Highlights

- First public PyPI release with modern packaging (Hatchling + Trusted Publishing)
- Crash intelligence with automated triage, test minimization, and stability tracking
- 3D fuzzing with performance optimizations (lazy loading, LRU caching, parallel processing)
- Comprehensive documentation (CONTRIBUTING, QUICKSTART, EXAMPLES, SECURITY, ARCHITECTURE)
- 5,403 tests with 83% coverage

### Added - Crash Intelligence

- **Crash Triaging** (`crash_triage.py`): Automated crash analysis and prioritization
  - 5 severity levels: CRITICAL, HIGH, MEDIUM, LOW, INFO
  - 4 exploitability ratings with priority scoring (0-100)
  - Automatic indicator extraction (heap corruption, use-after-free, buffer overflows)
- **Test Case Minimization** (`test_minimizer.py`): Delta debugging for crash reduction
  - DDMIN algorithm with 4 minimization strategies
  - Reduces crashing inputs to smallest reproducible form
- **Stability Tracking** (`stability_tracker.py`): AFL++-style stability metrics
  - Execution consistency tracking and non-deterministic behavior detection

### Added - Performance Optimizations

- **Lazy Loading** (`lazy_loader.py`): 10-100x faster metadata-only loading
- **LRU Caching** (`series_cache.py`): 250x faster cache hits with O(1) operations
- **Parallel Processing** (`parallel_mutator.py`): 3-4x faster mutations using ProcessPoolExecutor
- **Benchmarking Infrastructure**: Performance profiling and baseline metrics (157.62 ops/sec)

### Added - Documentation

- `CONTRIBUTING.md`: Development setup, testing guidelines, code style standards
- `docs/QUICKSTART.md`: 5-minute quick start guide
- `docs/EXAMPLES.md`: 14 comprehensive examples with runnable code
- `SECURITY.md`: Vulnerability reporting and compliance guidance (HIPAA, GDPR, FDA)
- `docs/ARCHITECTURE.md`: System design and technical architecture (600+ lines)
- `docs/PERFORMANCE_3D.md`: Complete performance optimization guide

### Added - Production Tools

- Seed corpus management (import_seed_corpus.py, download_public_seeds.py)
- Docker infrastructure with DCMTK + Orthanc containers
- Target configurations for dcmdump and Orthanc API
- Enhanced HTML reports with crash triage data

### Changed

- **Repository Structure**: 19 folders reduced to 9 (53% complexity reduction)
- **CI/CD**: GitHub Actions with Trusted Publishing (OIDC) for PyPI
- **Test Suite**: Expanded from 930 to 5,403 tests with comprehensive coverage
- **Python Support**: Full compatibility with Python 3.11, 3.12, 3.13, 3.14

### Fixed

- Flaky tests resolved with proper test isolation
- All Ruff and MyPy linting errors fixed
- Deprecated pydicom API calls updated
- Windows path handling in tests

## [1.1.0] - 2025-01-17 - Stability Release

### Added

- **Resource Management** (`resource_manager.py`): Memory, CPU, and disk space limits
- **Enhanced Target Runner** (`target_runner.py`): Retry logic and circuit breaker pattern
- **Error Recovery** (`error_recovery.py`): Checkpoint/resume for long-running campaigns
- **Configuration Validation** (`config_validator.py`): Pre-flight checks

### Changed

- CLI resource limits: `--max-memory`, `--max-cpu-time`, `--min-disk-space`
- Core exports expanded with stability features

### Fixed

- Resource exhaustion in long-running campaigns
- Lost progress on campaign interruption

### Documentation

- `docs/STABILITY.md`: Resource management best practices
- `docs/TROUBLESHOOTING.md`: Complete troubleshooting reference

## [1.0.0] - 2025-01-11 - Initial Release

### Added

- Core fuzzing engine with mutation-based fuzzing
- DICOM parser and generator
- Crash analysis and deduplication
- Coverage tracking capabilities
- Comprehensive test suite (930+ tests, 69% coverage)
- HTML and JSON reporting
- CLI tools for fuzzing operations

### Changed

- **BREAKING**: Major project restructure for modern Python standards
  - Consolidated modules into `dicom_fuzzer` package
  - Updated all imports to use `dicom_fuzzer.` prefix

---

## Planned Features

- Enhanced coverage-guided fuzzing with AFL-style feedback
- Network fuzzing support (DICOM C-STORE, C-FIND protocols)
- Distributed fuzzing across multiple machines
- Grammar-based and protocol-aware mutation strategies

---

**Migration Guide for v1.0.0:**

If upgrading from pre-1.0 versions:

```python
# Old imports:
from core.parser import DicomParser

# New imports:
from dicom_fuzzer.core.parser import DicomParser
# Or use package-level:
from dicom_fuzzer import DicomParser
```

**Output locations:**

- Old: `output/`, `crashes/`, `fuzzed_dicoms/`
- New: `artifacts/crashes/`, `artifacts/fuzzed/`, `artifacts/corpus/`
