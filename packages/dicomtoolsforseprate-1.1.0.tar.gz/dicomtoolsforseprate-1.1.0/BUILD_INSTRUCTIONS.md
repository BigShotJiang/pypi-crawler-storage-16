# 项目打包说明

## 打包结果

项目已成功打包，生成的文件位于 `dist/` 目录：

- **`dicomtoolsforseprate-1.1.0-py3-none-any.whl`** - Wheel 格式分发包（推荐使用）
- **`dicomtoolsforseprate-1.1.0.tar.gz`** - 源码分发包

## 安装方式

### 方式1：从本地 Wheel 文件安装（推荐）

```bash
pip install dist/dicomtoolsforseprate-1.1.0-py3-none-any.whl
```

### 方式2：从本地源码包安装

```bash
pip install dist/dicomtoolsforseprate-1.1.0.tar.gz
```

### 方式3：从当前目录安装（开发模式）

```bash
pip install -e .
```

## 验证安装

安装完成后，可以通过以下命令验证：

```bash
# 检查包是否已安装
pip show dicomtoolsforseprate

# 运行命令行工具（如果配置了）
dicomtoolsforseprate
```

## 上传到 PyPI（可选）

如果要上传到 PyPI，需要先安装 twine：

```bash
pip install twine
```

然后上传：

```bash
# 上传到测试 PyPI
twine upload --repository testpypi dist/*

# 上传到正式 PyPI
twine upload dist/*
```

## 项目信息

- **包名**: `dicomtoolsforseprate`
- **版本**: `1.1.0`
- **Python 版本要求**: `>=3.10`
- **主要依赖**: 
  - mcp>=0.9.0
  - pydicom>=2.4.0
  - requests>=2.31.0
  - pydantic>=2.0.0
  - tqdm>=4.66.0
  - pyorthanc
  - sympy

## 打包配置

项目使用 `hatchling` 作为构建后端，配置文件为 `pyproject.toml`。

包含的包：
- `dicom_tools` - DICOM 工具包
- `src` - 源代码包（包含 api, cookie, core, function, models, utils）

包含的根文件：
- `main.py` - MCP 服务器主文件
- `setup.py` - MCP 工具函数包装模块

## 重新打包

如果需要重新打包（例如修改版本号后），运行：

```bash
python -m build
```

打包前确保：
1. 已更新 `pyproject.toml` 中的版本号
2. 已更新 `README.md`（如果需要）
3. 已清理 `dist/` 目录（可选）

