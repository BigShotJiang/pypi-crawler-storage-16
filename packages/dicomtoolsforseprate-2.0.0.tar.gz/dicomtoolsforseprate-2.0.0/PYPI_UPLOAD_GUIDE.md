# PyPI 上传指南

## 前置要求

1. **PyPI 账户**
   - 如果没有账户，请访问 https://pypi.org/account/register/ 注册

2. **API Token（推荐）**
   - 登录 PyPI 后，访问 https://pypi.org/manage/account/token/
   - 创建新的 API token（scope: Entire account 或仅限项目）
   - 保存 token（只显示一次）

3. **配置认证方式**

### 方式1：使用 API Token（推荐）

创建或编辑 `~/.pypirc` 文件（Windows: `%USERPROFILE%\.pypirc`）：

```ini
[pypi]
username = __token__
password = pypi-你的API_TOKEN
```

### 方式2：使用用户名和密码

```ini
[pypi]
username = 你的用户名
password = 你的密码
```

### 方式3：命令行输入

直接运行上传命令，会提示输入用户名和密码。

## 上传步骤

### 1. 测试上传到 TestPyPI（推荐先测试）

```bash
twine upload --repository testpypi dist/*
```

测试安装：
```bash
pip install --index-url https://test.pypi.org/simple/ dicomtoolsforseprate
```

### 2. 上传到正式 PyPI

```bash
twine upload dist/*
```

## 验证上传

上传成功后，访问：
- 测试 PyPI: https://test.pypi.org/project/dicomtoolsforseprate/
- 正式 PyPI: https://pypi.org/project/dicomtoolsforseprate/

## 安装已上传的包

```bash
# 从正式 PyPI 安装
pip install dicomtoolsforseprate

# 从测试 PyPI 安装
pip install --index-url https://test.pypi.org/simple/ dicomtoolsforseprate
```

## 注意事项

1. **版本号**：每次上传必须使用新的版本号
2. **包名唯一性**：确保包名 `dicomtoolsforseprate` 在 PyPI 上可用
3. **测试优先**：建议先上传到 TestPyPI 测试
4. **API Token**：使用 API Token 更安全，避免密码泄露



