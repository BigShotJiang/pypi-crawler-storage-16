"""
任务管理器 - 用于管理长时间运行的后台任务
"""
import json
import time
import uuid
import threading
from pathlib import Path
from typing import Dict, Optional
from concurrent.futures import ThreadPoolExecutor

from ..cookie.getcookie import logger

# 全局线程池，用于执行长时间运行的任务
_task_executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="dicom_task")


def _get_task_status_file(task_id: str, task_dir: str) -> Path:
    """
    获取任务状态文件路径
    
    Args:
        task_id: 任务ID
        task_dir: 任务目录路径（任务状态文件将保存在此目录）
        
    Returns:
        任务状态文件路径
    """
    task_dir_path = Path(task_dir)
    task_dir_path.mkdir(parents=True, exist_ok=True)
    return task_dir_path / f"task_{task_id}.json"


def _update_task_status(
    task_id: str,
    task_dir: str,
    status: str,
    progress: float = 0.0,
    message: str = "",
    result: Optional[Dict] = None,
    error: Optional[str] = None
):
    """
    更新任务状态
    
    Args:
        task_id: 任务ID
        task_dir: 任务目录路径
        status: 任务状态 ("running", "completed", "failed")
        progress: 进度 (0.0 - 1.0)
        message: 状态消息
        result: 任务结果（当status为completed时）
        error: 错误信息（当status为failed时）
    """
    status_file = _get_task_status_file(task_id, task_dir)
    status_data = {
        "task_id": task_id,
        "task_dir": task_dir,
        "status": status,
        "progress": progress,
        "message": message,
        "updated_at": time.time(),
        "result": result,
        "error": error
    }
    try:
        with open(status_file, 'w', encoding='utf-8') as f:
            json.dump(status_data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"更新任务状态失败: {e}")


def get_task_status(task_id: str, task_dir: str) -> Optional[Dict]:
    """
    获取任务状态
    
    Args:
        task_id: 任务ID
        task_dir: 任务目录路径
        
    Returns:
        任务状态字典，如果任务不存在则返回None
    """
    status_file = _get_task_status_file(task_id, task_dir)
    if not status_file.exists():
        return None
    try:
        with open(status_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"读取任务状态失败: {e}")
        return None


def run_task_in_background(task_func, task_dir: str, *args, **kwargs) -> str:
    """
    在后台线程中执行任务
    
    Args:
        task_func: 要执行的函数
        task_dir: 任务目录路径（任务状态文件将保存在此目录）
        *args: 函数的位置参数
        **kwargs: 函数的关键字参数
        
    Returns:
        任务ID
    """
    task_id = str(uuid.uuid4())
    
    def _run_task():
        try:
            _update_task_status(task_id, task_dir, "running", 0.0, "任务已启动...")
            result = task_func(*args, **kwargs)
            _update_task_status(
                task_id,
                task_dir,
                "completed",
                1.0,
                "任务完成",
                result=result
            )
        except Exception as e:
            import traceback
            error_msg = f"任务执行失败: {str(e)}\n{traceback.format_exc()}"
            logger.error(error_msg)
            _update_task_status(
                task_id,
                task_dir,
                "failed",
                0.0,
                "任务失败",
                error=error_msg
            )
    
    # 在线程池中执行任务
    _task_executor.submit(_run_task)
    
    return task_id

