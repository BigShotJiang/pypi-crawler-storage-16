import json
import sys
from typing import Dict, Any

try:
    from .getcookie import CookieManager
    from .getcrpit import encrypt
except ImportError:
    # 直接运行时使用绝对导入
    from src.cookie.getcookie import CookieManager
    from src.cookie.getcrpit import encrypt


def get_config():
    """输入用户名和密码修改config.json"""
    DEFAULT_CONFIG: Dict[str, Any] = {
        "max_workers": 10,
        "max_retries": 3,
        "DEFAULT_CONNECT_TIMEOUT": 3,
        "DEFAULT_READ_TIMEOUT": 5,
        "DEFAULT_RETRY_DELAY": 5,
        "DEFAULT_BATCH_SIZE": 6
    }

    import os
    from pathlib import Path
    from dotenv import load_dotenv
    
    # 尝试从多个位置加载 .env 文件
    # 1. 当前工作目录
    # 2. 项目根目录（相对于此文件）
    current_dir = Path.cwd()
    project_root = Path(__file__).parent.parent.parent
    
    env_loaded = False
    for env_path in [current_dir / '.env', project_root / '.env', Path('.env')]:
        if env_path.exists():
            load_dotenv(dotenv_path=env_path, override=True)
            env_loaded = True
            print(f"已加载环境变量文件: {env_path}", file=sys.stderr)
            break
    
    if not env_loaded:
        # 如果找不到 .env 文件，尝试从当前目录加载（默认行为）
        load_dotenv(override=True)
        print("警告: 未找到 .env 文件，尝试从环境变量读取", file=sys.stderr)
    
    # 支持大小写不敏感的环境变量读取
    name = os.getenv("name") or os.getenv("NAME")
    password = os.getenv("password") or os.getenv("PASSWORD")
    tel = os.getenv("tel") or os.getenv("TEL") or os.getenv("phoneNumber") or os.getenv("PHONENUMBER")
    base_url = os.getenv("base_url") or os.getenv("BASE_URL")
    
    # 验证必要的环境变量
    if not base_url:
        raise ValueError(
            "环境变量 'base_url' 未设置。请确保：\n"
            "1. .env 文件存在于项目根目录或当前工作目录\n"
            "2. .env 文件中包含 base_url=你的URL\n"
            "3. 或者设置系统环境变量 base_url"
        )
    
    if not name or not password:
        raise ValueError(
            "环境变量 'name' 或 'password' 未设置。请检查 .env 文件。"
        )
    
    print(f"从环境变量读取 base_url: {base_url}", file=sys.stderr)
    
    payload = {"username": name, "password": password, "phoneNumber": tel}
    plain = json.dumps(payload, ensure_ascii=False)
    cipher = encrypt(plain)
    cookie_manager = CookieManager(base_url, cipher)
    cookie = cookie_manager.get_cookie()
    if cookie:
        DEFAULT_CONFIG["cookie"]=cookie
        DEFAULT_CONFIG["base_url"]=base_url
        print(f":配置详情{DEFAULT_CONFIG}", file=sys.stderr)

    return DEFAULT_CONFIG