#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试启动脚本 - 启动服务器并在3秒后自动关闭，以便查看启动信息
"""
import asyncio
import sys
import signal
from main import main

async def test_startup():
    """启动服务器并在3秒后自动关闭"""
    print("=" * 60, file=sys.stderr)
    print("📋 这是一个测试启动脚本", file=sys.stderr)
    print("服务器将启动并在 3 秒后自动关闭", file=sys.stderr)
    print("=" * 60, file=sys.stderr)
    print("", file=sys.stderr)
    
    # 创建服务器任务
    server_task = asyncio.create_task(main())
    
    # 等待3秒
    await asyncio.sleep(3)
    
    # 取消服务器任务
    print("\n⏰ 3秒已过，正在关闭服务器...", file=sys.stderr)
    server_task.cancel()
    
    try:
        await server_task
    except asyncio.CancelledError:
        print("✅ 测试完成！服务器启动信息已显示", file=sys.stderr)

if __name__ == "__main__":
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
    
    try:
        asyncio.run(test_startup())
    except KeyboardInterrupt:
        print("\n测试被中断", file=sys.stderr)

