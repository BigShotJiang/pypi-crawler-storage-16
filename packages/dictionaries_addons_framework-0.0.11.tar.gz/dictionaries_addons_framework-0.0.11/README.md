# Dictionaries Addons Framework

![PyPI version](https://img.shields.io/pypi/v/dictionaries-addons-framework.svg)

A framework to let you build addons for Dictionaries.

* PyPI package: https://pypi.org/project/dictionaries-addons-framework/
* Free software: MIT License

## Features

* TODO

## Credits

This package was created with [Cookiecutter](https://github.com/audreyfeldroy/cookiecutter) and the [audreyfeldroy/cookiecutter-pypackage](https://github.com/audreyfeldroy/cookiecutter-pypackage) project template.