# Usage

To use Dictionaries Addons Framework in a project:

```python
import dictionaries_addons_framework
```
