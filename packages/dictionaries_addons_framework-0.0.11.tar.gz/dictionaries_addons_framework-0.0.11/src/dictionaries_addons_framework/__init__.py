"""Top-level package for Dictionaries Addons Framework."""

__author__ = """Caleb"""
__email__ = 'calebh101dev@icloud.com'
