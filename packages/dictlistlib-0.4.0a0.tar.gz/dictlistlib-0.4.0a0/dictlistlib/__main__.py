
from dictlistlib.main import Cli

console = Cli()
console.run()
