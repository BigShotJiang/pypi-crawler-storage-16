# Diff Coverage
## Diff: origin/main...HEAD, staged and unstaged changes

- test_src&#46;txt (50.0%): Missing lines 2,4,6,8,10

## Summary

- **Total**: 10 lines
- **Missing**: 5 lines
- **Coverage**: 50%



## test_src&#46;txt

```
   1 test 1
!  2 test 2
   3 test 3
!  4 test 4
   5 test 5
!  6 test 6
   7 test 7
!  8 test 8
   9 test 9
! 10 test 10
```


---


