# Diff Coverage
## Diff: main

- file1&#46;py (66.7%): Missing lines 10-11
- subdir/file2&#46;py (66.7%): Missing lines 10-11

## Summary

- **Total**: 12 lines
- **Missing**: 4 lines
- **Coverage**: 66%



## file1&#46;py

Lines 1-1

```
Snippet with ስ 芒 unicode
```

---



## subdir/file2&#46;py

Lines 1-1

```
Snippet with ስ 芒 unicode
```

---
