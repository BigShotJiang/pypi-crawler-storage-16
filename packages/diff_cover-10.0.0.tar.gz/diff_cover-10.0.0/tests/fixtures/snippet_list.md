Lines 6-17

```python
   6 Line 6
   7 Line 7
   8 Line 8
   9 Line 9
! 10 Line 10
  11 Line 11
! 12 Line 12
! 13 Line 13
  14 Line 14
  15 Line 15
  16 Line 16
  17 Line 17
```


Lines 46-61

```python
  46 Line 46
  47 Line 47
  48 Line 48
  49 Line 49
! 50 Line 50
! 51 Line 51
  52 Line 52
  53 Line 53
! 54 Line 54
! 55 Line 55
  56 Line 56
! 57 Line 57
  58 Line 58
  59 Line 59
  60 Line 60
  61 Line 61
```
