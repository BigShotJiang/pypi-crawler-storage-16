# diffopt

[![Paper](https://joss.theoj.org/papers/10.21105/joss.07522/status.svg)](https://doi.org/10.21105/joss.07522)

Parallelization and optimization of differentiable and many-parameter models

## Author
- Alan Pearl

## Documentation
Online documentation is available at [diffopt.readthedocs.io](https://diffopt.readthedocs.io/en/latest).
