diffsync.diff
=============

.. automodule:: diffsync.diff
   :members:
   :undoc-members:
   :show-inheritance:
