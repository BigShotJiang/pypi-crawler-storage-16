diffsync.enum
=============

.. automodule:: diffsync.enum
   :members:
   :undoc-members:
   :show-inheritance:
