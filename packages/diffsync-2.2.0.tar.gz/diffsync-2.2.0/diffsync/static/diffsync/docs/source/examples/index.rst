############
Examples
############

For each example, the complete source code is `available in Github <https://github.com/networktocode/diffsync/tree/main/examples>`_ in the `examples` directory

.. mdinclude:: ../../../examples/01-multiple-data-sources/README.md
.. mdinclude:: ../../../examples/02-callback-function/README.md
.. mdinclude:: ../../../examples/03-remote-system/README.md
.. mdinclude:: ../../../examples/04-get-update-instantiate/README.md
.. mdinclude:: ../../../examples/05-nautobot-peeringdb/README.md
.. mdinclude:: ../../../examples/06-ip-prefixes/README.md
