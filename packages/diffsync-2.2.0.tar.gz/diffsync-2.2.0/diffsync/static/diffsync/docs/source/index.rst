Welcome to DiffSync's documentation!
====================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   overview/index
   getting_started/index
   core_engine/index
   examples/index
   upgrading/index
   api/diffsync
   license/index



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
