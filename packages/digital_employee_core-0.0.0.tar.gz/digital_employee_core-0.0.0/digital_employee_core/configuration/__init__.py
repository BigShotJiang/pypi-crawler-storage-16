"""Configuration management module for digital employee."""

from .configuration import DigitalEmployeeConfiguration

__all__ = [
    "DigitalEmployeeConfiguration",
]
