Practical Guide to Persistent Homology
======================================

.. toctree::
   :maxdepth: 2

   basics
   filtrations
   persistence
   plotting
   diagnostics

