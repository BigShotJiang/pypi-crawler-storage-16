Persistence
-----------

.. toctree::
   :maxdepth: 2

   omni-field
   cohomology
   zigzags
   fast-zigzag-apex


