"""Celery + dioxide example application."""
