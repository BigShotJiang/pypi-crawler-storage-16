"""Tests for the Celery + dioxide example."""
