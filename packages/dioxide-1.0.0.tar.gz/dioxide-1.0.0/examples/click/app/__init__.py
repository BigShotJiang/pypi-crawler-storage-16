"""Click CLI application demonstrating dioxide dependency injection.

This package provides a CLI tool for user management that demonstrates
hexagonal architecture with dioxide.
"""
