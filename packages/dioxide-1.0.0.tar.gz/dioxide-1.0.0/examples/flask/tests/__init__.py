"""Tests for Flask + dioxide example application."""
