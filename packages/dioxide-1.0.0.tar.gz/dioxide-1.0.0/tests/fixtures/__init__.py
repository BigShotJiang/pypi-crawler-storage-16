"""Test fixtures for package scanning tests."""
