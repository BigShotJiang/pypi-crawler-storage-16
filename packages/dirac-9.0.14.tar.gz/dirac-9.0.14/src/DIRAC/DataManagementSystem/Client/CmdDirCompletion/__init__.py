#!/usr/bin/env python
# author: lintao

"""
This module is a helper module for command line interface.

It can help you auto complete the directory name.

The code is a part of

  https://github.com/mirguest/CmdDirectoryCompletion

"""
