""" DIRAC File Catalog components
"""
