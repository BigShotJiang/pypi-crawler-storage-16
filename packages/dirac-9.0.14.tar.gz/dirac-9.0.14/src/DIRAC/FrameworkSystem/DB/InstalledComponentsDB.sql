# Everything is created by the DB object upon instantiatiation if it does not exists.
use InstalledComponentsDB;
