"""
DIRACCommon.ConfigurationSystem.Client.Helpers - Configuration system helper functions
"""
