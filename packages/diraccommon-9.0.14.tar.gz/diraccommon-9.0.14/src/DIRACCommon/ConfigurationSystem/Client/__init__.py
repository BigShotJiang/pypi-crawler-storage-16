"""
DIRACCommon.ConfigurationSystem.Client - Configuration system client components
"""
