"""dirdotenv - Load environment variables from .env and .envrc files."""

from .__version__ import __version__
