__version__ = "2.2.1"

__title__ = "discoger"
__author__ = "Beudbeud"
__author_email__ = "beudbeud@gmail.com"
__github_username__ = "beudbeud"
__copyright__ = "Copyright © 2021 - my name"
__license__ = "GNU General Public License v3 (GPLv3)"
__description__ = "Get notification from Discogs"
__keywords__ = ["discogs", "telegram", "bot"]
