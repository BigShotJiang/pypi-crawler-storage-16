from .asyncio import adispatcher_service
from .subprocess import dispatcher_service

__all__ = ['adispatcher_service', 'dispatcher_service']
