class DispatcherCancel(Exception):
    pass
