Dask is a community maintained project. We welcome contributions in the form of bug reports, documentation, code, design proposals, and more.

Please see https://distributed.dask.org/en/latest/develop.html for more information.

Also for general information on how to contribute see https://docs.dask.org/en/latest/develop.html.
