"""DistributeX SDK - FIXED"""
import os, json, time, requests, inspect, hashlib, base64
from typing import Any, Callable, Optional
from dataclasses import dataclass

__version__ = "1.0.5"

@dataclass
class Task:
    id: str
    status: str
    progress: float = 0.0
    error: Optional[str] = None

class DistributeX:
    def __init__(self, api_key=None, base_url="https://distributex.cloud"):
        self.api_key = api_key or os.getenv("DISTRIBUTEX_API_KEY")
        if not self.api_key:
            raise ValueError("API key required")
        self.base_url = base_url.rstrip('/')
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        })
        print(f"🌐 SDK v{__version__} - Embedded Script Mode")
    
    def run(self, func, args=(), kwargs=None, workers=1, cpu_per_worker=2, 
            ram_per_worker=2048, gpu=False, cuda=False, timeout=3600, wait=True):
        kwargs = kwargs or {}
        print(f"🚀 Submitting: {func.__name__}")
        
        # Create script
        try:
            src = inspect.getsource(func)
        except:
            src = f"# {func.__name__}\n"
        
        script = f'''#!/usr/bin/env python3
import json, sys
{src}
args = {json.dumps(args)}
kwargs = {json.dumps(kwargs)}
try:
    result = {func.__name__}(*args, **kwargs)
    with open('result.json', 'w') as f:
        json.dump({{"success": True, "result": result}}, f)
    print(f"Result: {{result}}")
except Exception as e:
    with open('result.json', 'w') as f:
        json.dump({{"success": False, "error": str(e)}}, f)
    import traceback
    traceback.print_exc()
    sys.exit(1)
'''
        
        script_b64 = base64.b64encode(script.encode()).decode()
        script_hash = hashlib.sha256(script.encode()).hexdigest()
        
        print(f"✓ Script: {len(script)} bytes, hash: {script_hash[:8]}...")
        
        # Submit
        data = {
            'name': f'Function: {func.__name__}',
            'taskType': 'script_execution',
            'runtime': 'python',
            'executionScript': script_b64,
            'scriptHash': script_hash,
            'workers': workers,
            'cpuPerWorker': cpu_per_worker,
            'ramPerWorker': ram_per_worker,
            'gpuRequired': gpu,
            'requiresCuda': cuda,
            'timeout': timeout,
            'priority': 5
        }
        
        resp = self.session.post(f"{self.base_url}/api/tasks/execute", json=data)
        resp.raise_for_status()
        result = resp.json()
        task = Task(id=result['id'], status=result.get('status', 'pending'))
        
        if not wait:
            return task
        
        print("⏳ Waiting...")
        while True:
            t = self.get_task(task.id)
            if t.status == 'completed':
                return self.get_result(task.id)
            if t.status == 'failed':
                raise RuntimeError(t.error or "Failed")
            time.sleep(5)
    
    def get_task(self, task_id):
        r = self.session.get(f"{self.base_url}/api/tasks/{task_id}")
        r.raise_for_status()
        d = r.json()
        return Task(id=d['id'], status=d['status'], progress=d.get('progressPercent', 0), error=d.get('errorMessage'))
    
    def get_result(self, task_id):
        r = self.session.get(f"{self.base_url}/api/tasks/{task_id}/result")
        if r.status_code == 302:
            r = self.session.get(r.headers.get('Location'))
        r.raise_for_status()
        if 'json' in r.headers.get('content-type', ''):
            return r.json().get('result')
        return r.text
    
    def network_stats(self):
        r = self.session.get(f"{self.base_url}/api/stats/network")
        r.raise_for_status()
        return r.json()
