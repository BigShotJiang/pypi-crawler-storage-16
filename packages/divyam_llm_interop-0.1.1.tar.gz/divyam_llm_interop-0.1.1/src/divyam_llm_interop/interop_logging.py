# Copyright 2025 Divyam.ai
# SPDX-License-Identifier: Apache-2.0

import logging

logger = logging.getLogger("divyam_llm_interop")
