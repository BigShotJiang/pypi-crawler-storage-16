
```python
# settings.py

INSTALLED_APPS = [
    # ...
    'libsv1.global_system_log.apps.ModuleAppConfig',
    # ...
]

MIDDLEWARE = [
    # ...
    'libsv1.global_system_log.middleware.GlobalSystemLogMiddleware',
    # ...
]
```
