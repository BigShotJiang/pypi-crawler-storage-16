
```python
# settings.py
MIDDLEWARE = [
    # ...
    'update_request.UpdateRequestMiddleware',
    # ...
]
```
