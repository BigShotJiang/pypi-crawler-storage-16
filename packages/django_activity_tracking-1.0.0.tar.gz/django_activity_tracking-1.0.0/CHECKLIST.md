# Pre-Publishing Checklist

## Before You Publish

### 1. Update Package Information

- [ ] Edit `setup.py`:
  - Change `author="Your Name"` to your name
  - Change `author_email="your.email@example.com"` to your email
  - Change `url="https://github.com/yourusername/django-activity-tracking"` to your repo

- [ ] Edit `pyproject.toml`:
  - Change author name and email
  - Change URLs

- [ ] Edit `LICENSE`:
  - Replace `[Your Name]` with your name

### 2. Create Accounts

- [ ] Create PyPI account: https://pypi.org/account/register/
- [ ] Create TestPyPI account: https://test.pypi.org/account/register/
- [ ] Verify both email addresses

### 3. Check Package Name

- [ ] Search PyPI to ensure name isn't taken: https://pypi.org/search/?q=django-activity-tracking
- [ ] If taken, change name in `setup.py` and `pyproject.toml`

### 4. Test Locally

- [ ] Run: `python manage.py check`
- [ ] Test the app works in your project
- [ ] Verify all imports work

### 5. Build & Check

- [ ] Install tools: `pip install build twine`
- [ ] Build: `python -m build`
- [ ] Check: `twine check dist/*`

### 6. Test on TestPyPI

- [ ] Upload: `twine upload --repository testpypi dist/*`
- [ ] Install: `pip install --index-url https://test.pypi.org/simple/ django-activity-tracking`
- [ ] Test in a fresh Django project

### 7. Publish to PyPI

- [ ] Upload: `twine upload dist/*`
- [ ] Verify: https://pypi.org/project/django-activity-tracking/
- [ ] Test install: `pip install django-activity-tracking`

### 8. Post-Publishing

- [ ] Create GitHub repository
- [ ] Push code to GitHub
- [ ] Add badges to README
- [ ] Share on social media
- [ ] Post on Reddit r/django

## Quick Commands

```bash
# Install tools
pip install build twine

# Build
python -m build

# Check
twine check dist/*

# Test upload
twine upload --repository testpypi dist/*

# Live upload
twine upload dist/*
```

## Using the Helper Script

Windows users can use `publish.bat`:

```bash
publish.bat
```

Then follow the menu options!
