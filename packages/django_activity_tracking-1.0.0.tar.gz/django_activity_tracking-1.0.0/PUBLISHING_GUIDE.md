# Publishing to PyPI Guide

## Prerequisites

1. **Create PyPI Account**
   - Go to https://pypi.org/account/register/
   - Verify your email

2. **Create TestPyPI Account** (for testing)
   - Go to https://test.pypi.org/account/register/
   - Verify your email

3. **Install Required Tools**
   ```bash
   pip install build twine
   ```

## Step-by-Step Publishing

### 1. Update Package Information

Edit `setup.py` and `pyproject.toml`:
- Change `author` and `author_email`
- Update `url` to your GitHub repository
- Verify version number

### 2. Build the Package

```bash
cd django-activity-tracking
python -m build
```

This creates:
- `dist/django-activity-tracking-1.0.0.tar.gz`
- `dist/django_activity_tracking-1.0.0-py3-none-any.whl`

### 3. Test on TestPyPI (Recommended)

```bash
# Upload to TestPyPI
twine upload --repository testpypi dist/*

# Test installation
pip install --index-url https://test.pypi.org/simple/ django-activity-tracking
```

### 4. Publish to PyPI

```bash
twine upload dist/*
```

You'll be prompted for:
- Username: Your PyPI username
- Password: Your PyPI password (or API token)

### 5. Verify Installation

```bash
pip install django-activity-tracking
```

## Using API Tokens (Recommended)

1. **Generate API Token**
   - Go to https://pypi.org/manage/account/token/
   - Create a new token
   - Copy the token (starts with `pypi-`)

2. **Create `.pypirc` file**

Windows: `%USERPROFILE%\.pypirc`
```ini
[pypi]
username = __token__
password = pypi-YOUR-TOKEN-HERE
```

3. **Upload with Token**
```bash
twine upload dist/*
```

## Updating the Package

1. **Update version** in `setup.py` and `pyproject.toml`
2. **Rebuild**:
   ```bash
   rm -rf dist build *.egg-info
   python -m build
   ```
3. **Upload**:
   ```bash
   twine upload dist/*
   ```

## Quick Commands

```bash
# Clean previous builds
rm -rf dist build *.egg-info

# Build
python -m build

# Check package
twine check dist/*

# Upload to TestPyPI
twine upload --repository testpypi dist/*

# Upload to PyPI
twine upload dist/*
```

## Troubleshooting

### "File already exists"
- You can't re-upload the same version
- Increment version number and rebuild

### "Invalid credentials"
- Check username/password
- Use API token instead

### "Package name already taken"
- Choose a different name in `setup.py`
- Try: `django-activity-tracker`, `dj-activity-tracking`, etc.

## After Publishing

1. **Create GitHub Repository**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/yourusername/django-activity-tracking.git
   git push -u origin main
   ```

2. **Add Badge to README**
   ```markdown
   ![PyPI](https://img.shields.io/pypi/v/django-activity-tracking)
   ![Python](https://img.shields.io/pypi/pyversions/django-activity-tracking)
   ![Django](https://img.shields.io/pypi/djversions/django-activity-tracking)
   ```

3. **Share**
   - Tweet about it
   - Post on Reddit r/django
   - Add to Django Packages

## Resources

- PyPI: https://pypi.org/
- TestPyPI: https://test.pypi.org/
- Packaging Guide: https://packaging.python.org/
- Twine Docs: https://twine.readthedocs.io/
