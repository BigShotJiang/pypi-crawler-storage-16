# Quick Publish to PyPI

## 1. Install Tools

```bash
pip install build twine
```

## 2. Update Your Info

Edit these files:
- `setup.py` - Change author, email, url
- `pyproject.toml` - Change author, email, url
- `LICENSE` - Add your name

## 3. Build Package

```bash
cd django-activity-tracking
python -m build
```

## 4. Test on TestPyPI (Optional but Recommended)

```bash
# Upload to test
twine upload --repository testpypi dist/*

# Test install
pip install --index-url https://test.pypi.org/simple/ django-activity-tracking
```

## 5. Publish to PyPI

```bash
twine upload dist/*
```

Enter your PyPI username and password when prompted.

## 6. Verify

```bash
pip install django-activity-tracking
```

## Done! 🎉

Your package is now live at: https://pypi.org/project/django-activity-tracking/

## Update Version

To publish updates:

1. Change version in `setup.py` and `pyproject.toml`
2. Delete old builds: `rm -rf dist build *.egg-info`
3. Rebuild: `python -m build`
4. Upload: `twine upload dist/*`
