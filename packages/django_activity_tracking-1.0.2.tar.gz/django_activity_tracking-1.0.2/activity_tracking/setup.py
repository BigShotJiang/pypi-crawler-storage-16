# This file is deprecated. Use pyproject.toml instead.
# Kept for backwards compatibility only.

from setuptools import setup

setup(
    name="django-activity-tracking",
    version="1.0.1",
)
