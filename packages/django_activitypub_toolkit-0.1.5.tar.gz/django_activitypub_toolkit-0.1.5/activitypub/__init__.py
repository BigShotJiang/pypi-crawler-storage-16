# This file makes activitypub a regular Python package, not a namespace package
