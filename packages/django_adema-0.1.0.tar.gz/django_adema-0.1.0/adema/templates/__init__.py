# ADEMA Templates
# ===============
# This directory contains the scaffolding templates used by django-adema
# to generate new projects and apps.
#
# - project_template/: Template for new Django projects
# - app_template/: Template for new Django apps with vertical slicing
