"""
Database Migrations for {{ app_name }}
=======================================

This package contains database migrations.
Generated automatically by Django.

To create migrations:
    python manage.py makemigrations {{ app_name }}

To apply migrations:
    python manage.py migrate {{ app_name }}
"""
