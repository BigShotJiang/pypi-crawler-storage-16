"""
ADEMA UI Module
===============

Web Wizard interface for interactive project generation.
"""

from adema.ui.server import start_server

__all__ = ['start_server']
