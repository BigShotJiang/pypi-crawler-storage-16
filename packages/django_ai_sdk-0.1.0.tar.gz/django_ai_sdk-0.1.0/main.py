def main():
    print("Hello from django-ai-sdk!")


if __name__ == "__main__":
    main()
