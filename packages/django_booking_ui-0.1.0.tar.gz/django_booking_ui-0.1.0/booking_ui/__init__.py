"""
django-booking-ui reusable app.

Provides public booking pages and a lightweight customer portal.
"""

default_app_config = "booking_ui.apps.BookingUIConfig"
