from django.apps import AppConfig


class BookingUIConfig(AppConfig):
    name = "booking_ui"
    verbose_name = "Booking UI"
