from django.urls import path

app_name = "brickastley"

urlpatterns = [
    # Add your URL patterns here
]
