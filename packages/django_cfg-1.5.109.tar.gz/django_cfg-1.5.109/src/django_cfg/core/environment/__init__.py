"""
Environment detection utilities for django_cfg.
"""

from .detector import EnvironmentDetector

__all__ = [
    "EnvironmentDetector",
]
