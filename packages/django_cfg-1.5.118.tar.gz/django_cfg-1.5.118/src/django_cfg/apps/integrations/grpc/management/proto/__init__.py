"""
Proto utilities for django-cfg gRPC integration.
"""
