"""
Debug utilities for Django-CFG.
"""

from .warnings_helper import setup_warnings_debug

__all__ = ['setup_warnings_debug']
