"""
Django CFG CLI Commands

Collection of CLI commands for project management and utilities.
"""
