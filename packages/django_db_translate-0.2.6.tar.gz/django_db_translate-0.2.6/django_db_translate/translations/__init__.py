from .loader import TranslationRegistry

registry = TranslationRegistry()
