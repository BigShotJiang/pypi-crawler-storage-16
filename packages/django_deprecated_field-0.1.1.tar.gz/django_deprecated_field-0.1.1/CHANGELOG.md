# Changelog

## [0.1.1](https://github.com/kolonialno/django-deprecated-field/compare/v0.1.0...v0.1.1) (2025-12-09)


### Bug Fixes

* Allow django 6 ([1a9983b](https://github.com/kolonialno/django-deprecated-field/commit/1a9983b17b20a7474e9bbc09d14ba3f436fa3be5))
* Allow django 6 ([7bff7b6](https://github.com/kolonialno/django-deprecated-field/commit/7bff7b6ecc02e46febcbabecc219cce577649696))

## 0.1.0 (2025-04-23)


### Bug Fixes

* get started releasing ([2c2ca5f](https://github.com/kolonialno/django-deprecated-field/commit/2c2ca5ff825005929ae1e6a138504f27a1494fb7))
