def test_basic_service():
    assert True
