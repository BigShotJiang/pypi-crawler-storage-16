default_app_config = "jbank.apps.JbankConfig"
