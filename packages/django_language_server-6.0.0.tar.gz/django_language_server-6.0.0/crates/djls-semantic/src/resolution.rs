mod templates;

pub use templates::find_references_to_template;
pub use templates::resolve_template;
pub use templates::ResolveResult;
pub use templates::TemplateReference;
