"""Django authentication via login URLs, no passwords required."""

from . import _version

__version__ = _version.version
VERSION = _version.version_tuple
