"""Progress display components for the Learn plugin."""


class ProgressDisplay:
    """Progress tracking and display component."""

    pass
