"""Quiz UI components for the Learn plugin."""


class QuizInterface:
    """Interactive quiz interface component."""

    pass
