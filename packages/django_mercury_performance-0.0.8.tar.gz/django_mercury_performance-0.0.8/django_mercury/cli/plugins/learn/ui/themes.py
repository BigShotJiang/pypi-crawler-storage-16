"""Themes and styling for the Learn plugin."""


class QuizTheme:
    """Quiz theme configuration."""

    pass


def get_theme(name="default"):
    """Get a theme by name."""
    return QuizTheme()
