"""
Utility modules for Mercury-Test CLI

Shared functionality used by plugins and core.
"""
