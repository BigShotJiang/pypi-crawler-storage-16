"""Django Mercury - Performance testing for Django apps.

Fresh start with clean architecture.
"""

from .monitor import MonitorResult, monitor

__version__ = "0.1.0"

__all__ = ["__version__", "monitor", "MonitorResult"]
