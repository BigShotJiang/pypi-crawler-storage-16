"""Tests for django-mercury-performance."""
