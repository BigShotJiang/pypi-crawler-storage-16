"""Django management commands for Mercury."""
