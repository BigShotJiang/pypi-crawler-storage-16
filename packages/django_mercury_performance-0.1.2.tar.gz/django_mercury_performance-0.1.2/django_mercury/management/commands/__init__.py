"""Mercury management commands."""
