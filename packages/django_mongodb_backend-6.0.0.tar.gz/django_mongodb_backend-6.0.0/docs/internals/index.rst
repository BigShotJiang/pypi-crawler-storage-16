=================
Project internals
=================

Documentation for people working on Django MongoDB Backend itself. This is the
place to go if you'd like to help improve Django MongoDB Backend or learn about
how the project is managed.

.. toctree::
    :maxdepth: 2

    bugs-and-features
    contributing/index
    security
    release-process
    deprecation
