=================
Security policies
=================

.. _reporting-security-issues:

Reporting security issues
=========================

If you identify a security vulnerability in this project or in any other
MongoDB project, please report it according to the instructions found at
:doc:`manual:tutorial/create-a-vulnerability-report`.
