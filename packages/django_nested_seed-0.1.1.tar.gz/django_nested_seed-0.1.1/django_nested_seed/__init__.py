"""Django Nested Seed - Load nested seed data with relationships via YAML."""

__version__ = "0.1.0"
