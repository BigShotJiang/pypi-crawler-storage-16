"""Configuration management for django-nested-seed.

This package handles seed data configuration including:
- SeedConfig: Configuration for mapping collections to model classes
"""
