from django.apps import AppConfig


class NinjaJwtConfig(AppConfig):
    name = "ninja_simple_jwt"
