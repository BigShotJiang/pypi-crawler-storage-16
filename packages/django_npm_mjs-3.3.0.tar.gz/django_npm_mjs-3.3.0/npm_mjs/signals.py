from django.dispatch import Signal

post_npm_install = Signal()
post_transpile = Signal()
