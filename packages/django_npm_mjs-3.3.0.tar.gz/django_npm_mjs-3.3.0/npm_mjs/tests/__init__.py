"""
Test suite for django-npm-mjs package.
"""
