from plans.management.commands.autorenew_accounts import Command as BaseCommand


class Command(BaseCommand):
    pass
