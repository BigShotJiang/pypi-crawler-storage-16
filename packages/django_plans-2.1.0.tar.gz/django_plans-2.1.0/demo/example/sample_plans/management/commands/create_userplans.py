from plans.management.commands.create_userplans import Command as BaseCommand


class Command(BaseCommand):
    pass
