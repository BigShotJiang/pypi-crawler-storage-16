from plans.management.commands.expire_accounts import Command as BaseCommand


class Command(BaseCommand):
    pass
