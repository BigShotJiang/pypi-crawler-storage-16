from djpsa.halo.callbacks import HaloCallbacksHandler


callback_handler = HaloCallbacksHandler
