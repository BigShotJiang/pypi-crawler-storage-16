"""Django resume development entrypoints."""
