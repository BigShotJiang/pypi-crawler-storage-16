``manage_manually``
    .. include:: /_include/create-revision-manage-manually.rst

``using``
    .. include:: /_include/create-revision-using.rst

``atomic``
    .. include:: /_include/create-revision-atomic.rst
