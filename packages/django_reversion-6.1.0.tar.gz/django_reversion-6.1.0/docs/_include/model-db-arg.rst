``model_db``
    The database where the model is saved. Defaults to the default database for the model.
