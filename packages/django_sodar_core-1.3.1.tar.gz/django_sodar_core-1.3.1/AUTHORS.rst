Credits
=======

* Mikko Nieminen <mikko.nieminen@bih-charite.de>
* Manuel Holtgrewe <manuel.holtgrewe@bih-charite.de>
* Oliver Stolpe <oliver.stolpe@bih-charite.de>
* Dzmitry Hramyka <dzmitry.hramyka@bih-charite.de>
* Franziska Schumann <franziska.schumann@fu-berlin.de>
* Hendrik Bomhardt <hendrik.bomhardt@student.hpi.de>
* Tim Garrels <tim.garrels@student.hpi.uni-potsdam.de>
* Raunak Agarwal
