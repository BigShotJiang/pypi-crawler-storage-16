"""Application configuration for bgjobs app"""

from django.apps import AppConfig


class BgjobsConfig(AppConfig):
    name = 'bgjobs'
