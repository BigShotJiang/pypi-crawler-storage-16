from django.apps import AppConfig


class TokensConfig(AppConfig):
    name = 'tokens'
