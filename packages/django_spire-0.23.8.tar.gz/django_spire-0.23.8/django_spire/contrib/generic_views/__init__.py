from django_spire.contrib.generic_views.modal_views import dispatch_modal_delete_form_content
from django_spire.contrib.generic_views.portal_views import template_view

__all__ = [
    'dispatch_modal_delete_form_content',
    'template_view',
]