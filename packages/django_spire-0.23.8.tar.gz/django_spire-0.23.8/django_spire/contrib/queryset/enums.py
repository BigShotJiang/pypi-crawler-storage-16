from __future__ import annotations

from enum import StrEnum


class SessionFilterActionEnum(StrEnum):
    CLEAR = 'Clear'
    FILTER = 'Filter'
