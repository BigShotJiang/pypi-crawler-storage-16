from __future__ import annotations

from django_spire.exceptions import DjangoSpireError


class ServiceError(DjangoSpireError):
    pass
