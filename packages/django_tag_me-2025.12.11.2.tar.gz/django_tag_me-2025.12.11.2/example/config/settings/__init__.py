"""Django settings __init__ for example project"""
