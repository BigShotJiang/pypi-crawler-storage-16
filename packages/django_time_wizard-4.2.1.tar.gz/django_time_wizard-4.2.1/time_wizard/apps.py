from django.apps import AppConfig


class TimeWizardConfig(AppConfig):
    name = 'time_wizard'
    default_auto_field = "django.db.models.AutoField"
