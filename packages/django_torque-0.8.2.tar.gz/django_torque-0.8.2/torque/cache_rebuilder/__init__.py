default_app_config = "torque.cache_rebuilder.apps.CacheRebuilderConfig"
