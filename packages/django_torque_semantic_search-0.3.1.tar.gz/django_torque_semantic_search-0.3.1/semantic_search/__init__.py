default_app_config = "torque.semantic_search.apps.SemanticSearchConfig"
