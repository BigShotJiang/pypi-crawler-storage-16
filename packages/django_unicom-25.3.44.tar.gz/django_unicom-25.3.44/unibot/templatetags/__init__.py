# Needed for Django to discover custom template filters
