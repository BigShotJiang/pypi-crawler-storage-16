"""Tests for blog.indexes"""
