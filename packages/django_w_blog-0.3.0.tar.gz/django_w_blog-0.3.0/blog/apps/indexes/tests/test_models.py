"""Tests for blog.indexes.models"""

from django.test import TestCase


# Create your tests here.
class BlogIndexTests(TestCase):
    """blogIndex model tests"""

    def setUp(self) -> None:
        """Setup before tests"""

        return super().setUp()
