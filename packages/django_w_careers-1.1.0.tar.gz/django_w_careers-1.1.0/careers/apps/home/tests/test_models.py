"""Tests for careers.home.models"""

from django.test import TestCase


# Create your tests here.
class HomeTests(TestCase):
    """Home model tests"""

    def setUp(self) -> None:
        """Setup before tests"""

        return super().setUp()
