"""Django Docs: A reusable documentation app powered by Python, Django, DRF, Wagtail CMS, TailwindCSS and DaisyUI."""
