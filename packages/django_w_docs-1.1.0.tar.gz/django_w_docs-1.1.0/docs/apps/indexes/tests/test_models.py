"""Tests for docs.indexes.models"""

from django.test import TestCase


# Create your tests here.
class DocsIndexTests(TestCase):
    """DocsIndex model tests"""

    def setUp(self) -> None:
        """Setup before tests"""

        return super().setUp()
