"""Tests for docs.pages"""
