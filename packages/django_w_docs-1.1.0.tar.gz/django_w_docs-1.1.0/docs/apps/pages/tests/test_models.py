"""Tests for docs.pages.models"""

from django.test import TestCase


# Create your tests here.
class DocsPageTests(TestCase):
    """DocsPage model tests"""

    def setUp(self) -> None:
        """Setup before tests"""

        return super().setUp()
