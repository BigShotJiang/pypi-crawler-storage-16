"""
djb editable-djb CLI - Install/uninstall djb in editable mode.
"""

from __future__ import annotations

import subprocess
from pathlib import Path

import click


def find_djb_dir(repo_root: Path | None = None) -> Path | None:
    """Find the djb directory relative to repo_root or cwd."""
    if repo_root is None:
        repo_root = Path.cwd()

    # Check if djb/ exists in the directory
    if (repo_root / "djb" / "pyproject.toml").exists():
        return repo_root / "djb"

    # Check if we're inside the djb directory
    if (repo_root / "pyproject.toml").exists():
        content = (repo_root / "pyproject.toml").read_text()
        if 'name = "djb"' in content:
            return repo_root

    return None


def is_djb_editable(repo_root: Path | None = None) -> bool:
    """Check if djb is currently installed in editable mode."""
    if repo_root is None:
        repo_root = Path.cwd()
    pyproject_path = repo_root / "pyproject.toml"
    if not pyproject_path.exists():
        return False
    content = pyproject_path.read_text()
    return "[tool.uv.sources]" in content and "djb" in content


def uninstall_editable_djb(repo_root: Path | None = None, quiet: bool = False) -> bool:
    """Uninstall editable djb and reinstall from PyPI.

    Args:
        repo_root: Project root directory (default: cwd)
        quiet: If True, suppress output messages

    Returns:
        True on success, False on failure
    """
    if repo_root is None:
        repo_root = Path.cwd()

    if not quiet:
        click.echo("Removing editable djb...")

    result = subprocess.run(
        ["uv", "remove", "djb"],
        cwd=repo_root,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        if not quiet:
            click.secho(f"Failed to remove djb: {result.stderr}", fg="red")
        return False

    if not quiet:
        click.echo("Re-adding djb from PyPI...")

    result = subprocess.run(
        ["uv", "add", "djb"],
        cwd=repo_root,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        if not quiet:
            click.secho(f"Failed to add djb from PyPI: {result.stderr}", fg="red")
        return False

    if not quiet:
        click.secho("Switched to PyPI version of djb", fg="green")
    return True


def install_editable_djb(repo_root: Path | None = None, quiet: bool = False) -> bool:
    """Install djb in editable mode from local directory.

    Args:
        repo_root: Project root directory (default: cwd)
        quiet: If True, suppress output messages

    Returns:
        True on success, False on failure
    """
    if repo_root is None:
        repo_root = Path.cwd()

    djb_dir = find_djb_dir(repo_root)
    if not djb_dir:
        if not quiet:
            click.secho(
                "Could not find djb directory. Run from a project containing djb/ "
                "or from inside the djb directory.",
                fg="red",
            )
        return False

    if not quiet:
        click.echo(f"Installing djb in editable mode from {djb_dir}...")

    result = subprocess.run(
        ["uv", "add", "--editable", str(djb_dir)],
        cwd=repo_root,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        if not quiet:
            click.secho(f"Failed to add editable djb: {result.stderr}", fg="red")
        return False

    if not quiet:
        click.secho(f"djb installed in editable mode from {djb_dir}", fg="green")
    return True


@click.command("editable-djb")
@click.option(
    "--uninstall",
    is_flag=True,
    help="Uninstall editable djb and use PyPI version instead.",
)
def editable_djb(uninstall: bool):
    """Install or uninstall djb in editable mode.

    Adds djb as an editable dependency using `uv add --editable`.
    When uninstalling, removes and re-adds djb from PyPI.

    \b
    Examples:
        djb editable-djb              # Install editable djb
        djb editable-djb --uninstall  # Switch back to PyPI version
    """
    if uninstall:
        if not uninstall_editable_djb():
            raise click.ClickException("Failed to uninstall editable djb")
    else:
        if not install_editable_djb():
            raise click.ClickException("Failed to install editable djb")
