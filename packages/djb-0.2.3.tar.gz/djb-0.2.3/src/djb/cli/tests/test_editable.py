"""Tests for djb editable-djb module."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import Mock, patch

import pytest
from click.testing import CliRunner

from djb.cli.djb import djb_cli
from djb.cli.editable import (
    find_djb_dir,
    install_editable_djb,
    is_djb_editable,
    uninstall_editable_djb,
)


@pytest.fixture
def runner():
    """Click CLI test runner."""
    return CliRunner()


@pytest.fixture
def mock_subprocess_run():
    """Mock subprocess.run to avoid actual command execution."""
    with patch("djb.cli.editable.subprocess.run") as mock:
        mock.return_value = Mock(returncode=0, stdout="", stderr="")
        yield mock


class TestFindDjbDir:
    """Tests for find_djb_dir function."""

    def test_finds_djb_in_subdirectory(self, tmp_path):
        """Test finding djb/ subdirectory with pyproject.toml."""
        djb_dir = tmp_path / "djb"
        djb_dir.mkdir()
        (djb_dir / "pyproject.toml").write_text('name = "djb"')

        result = find_djb_dir(tmp_path)
        assert result == djb_dir

    def test_finds_djb_when_inside_djb_directory(self, tmp_path):
        """Test finding djb when cwd is inside djb directory."""
        (tmp_path / "pyproject.toml").write_text('name = "djb"\nversion = "0.1.0"')

        result = find_djb_dir(tmp_path)
        assert result == tmp_path

    def test_returns_none_when_not_found(self, tmp_path):
        """Test returns None when djb directory not found."""
        result = find_djb_dir(tmp_path)
        assert result is None

    def test_returns_none_for_non_djb_pyproject(self, tmp_path):
        """Test returns None when pyproject.toml exists but is not djb."""
        (tmp_path / "pyproject.toml").write_text('name = "other-project"')

        result = find_djb_dir(tmp_path)
        assert result is None

    def test_uses_cwd_when_repo_root_is_none(self, tmp_path):
        """Test uses current working directory when repo_root is None."""
        djb_dir = tmp_path / "djb"
        djb_dir.mkdir()
        (djb_dir / "pyproject.toml").write_text('name = "djb"')

        with patch("djb.cli.editable.Path.cwd", return_value=tmp_path):
            result = find_djb_dir(None)
            assert result == djb_dir


class TestIsDjbEditable:
    """Tests for is_djb_editable function."""

    def test_returns_true_when_editable(self, tmp_path):
        """Test returns True when djb is in uv.sources."""
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text(
            """
[project]
name = "myproject"

[tool.uv.sources]
djb = { path = "../djb", editable = true }
"""
        )

        result = is_djb_editable(tmp_path)
        assert result is True

    def test_returns_false_when_not_editable(self, tmp_path):
        """Test returns False when djb is not in uv.sources."""
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text(
            """
[project]
name = "myproject"

[project.dependencies]
djb = "^0.1.0"
"""
        )

        result = is_djb_editable(tmp_path)
        assert result is False

    def test_returns_false_when_pyproject_missing(self, tmp_path):
        """Test returns False when pyproject.toml doesn't exist."""
        result = is_djb_editable(tmp_path)
        assert result is False

    def test_returns_false_when_sources_exists_but_no_djb(self, tmp_path):
        """Test returns False when uv.sources exists but djb not in it."""
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text(
            """
[project]
name = "myproject"

[tool.uv.sources]
other-package = { path = "../other" }
"""
        )

        result = is_djb_editable(tmp_path)
        assert result is False


class TestUninstallEditableDjb:
    """Tests for uninstall_editable_djb function."""

    def test_successful_uninstall(self, tmp_path, mock_subprocess_run):
        """Test successful uninstall and reinstall from PyPI."""
        result = uninstall_editable_djb(tmp_path)

        assert result is True
        assert mock_subprocess_run.call_count == 2

        # First call: uv remove djb
        first_call = mock_subprocess_run.call_args_list[0]
        assert first_call[0][0] == ["uv", "remove", "djb"]

        # Second call: uv add djb
        second_call = mock_subprocess_run.call_args_list[1]
        assert second_call[0][0] == ["uv", "add", "djb"]

    def test_failure_on_remove(self, tmp_path, mock_subprocess_run):
        """Test returns False when uv remove fails."""
        mock_subprocess_run.return_value = Mock(returncode=1, stderr="error")

        result = uninstall_editable_djb(tmp_path)

        assert result is False
        assert mock_subprocess_run.call_count == 1

    def test_failure_on_add(self, tmp_path, mock_subprocess_run):
        """Test returns False when uv add fails after successful remove."""

        def side_effect(cmd, *args, **kwargs):
            if cmd == ["uv", "remove", "djb"]:
                return Mock(returncode=0)
            return Mock(returncode=1, stderr="error")

        mock_subprocess_run.side_effect = side_effect

        result = uninstall_editable_djb(tmp_path)

        assert result is False
        assert mock_subprocess_run.call_count == 2

    def test_quiet_mode_suppresses_output(self, tmp_path, mock_subprocess_run, capsys):
        """Test quiet=True suppresses click.echo output."""
        uninstall_editable_djb(tmp_path, quiet=True)

        captured = capsys.readouterr()
        assert "Removing" not in captured.out
        assert "Re-adding" not in captured.out


class TestInstallEditableDjb:
    """Tests for install_editable_djb function."""

    def test_successful_install(self, tmp_path, mock_subprocess_run):
        """Test successful editable install."""
        # Create djb directory
        djb_dir = tmp_path / "djb"
        djb_dir.mkdir()
        (djb_dir / "pyproject.toml").write_text('name = "djb"')

        result = install_editable_djb(tmp_path)

        assert result is True
        mock_subprocess_run.assert_called_once()
        call_args = mock_subprocess_run.call_args[0][0]
        assert call_args == ["uv", "add", "--editable", str(djb_dir)]

    def test_returns_false_when_djb_not_found(self, tmp_path, mock_subprocess_run):
        """Test returns False when djb directory not found."""
        result = install_editable_djb(tmp_path)

        assert result is False
        mock_subprocess_run.assert_not_called()

    def test_failure_on_uv_add(self, tmp_path, mock_subprocess_run):
        """Test returns False when uv add --editable fails."""
        djb_dir = tmp_path / "djb"
        djb_dir.mkdir()
        (djb_dir / "pyproject.toml").write_text('name = "djb"')

        mock_subprocess_run.return_value = Mock(returncode=1, stderr="error")

        result = install_editable_djb(tmp_path)

        assert result is False

    def test_quiet_mode_suppresses_output(self, tmp_path, mock_subprocess_run, capsys):
        """Test quiet=True suppresses click.echo output."""
        djb_dir = tmp_path / "djb"
        djb_dir.mkdir()
        (djb_dir / "pyproject.toml").write_text('name = "djb"')

        install_editable_djb(tmp_path, quiet=True)

        captured = capsys.readouterr()
        assert "Installing" not in captured.out


class TestEditableDjbCommand:
    """Tests for editable-djb CLI command."""

    def test_help(self, runner):
        """Test that editable-djb --help works."""
        result = runner.invoke(djb_cli, ["editable-djb", "--help"])
        assert result.exit_code == 0
        assert "Install or uninstall djb in editable mode" in result.output
        assert "--uninstall" in result.output

    def test_install_success(self, runner, tmp_path):
        """Test successful install via CLI."""
        djb_dir = tmp_path / "djb"
        djb_dir.mkdir()
        (djb_dir / "pyproject.toml").write_text('name = "djb"')

        with patch("djb.cli.editable.subprocess.run") as mock_run:
            mock_run.return_value = Mock(returncode=0, stdout="", stderr="")
            with patch("djb.cli.editable.Path.cwd", return_value=tmp_path):
                result = runner.invoke(djb_cli, ["editable-djb"])

        assert result.exit_code == 0
        assert "editable mode" in result.output

    def test_install_failure(self, runner, tmp_path):
        """Test install failure via CLI."""
        # No djb directory - should fail
        with patch("djb.cli.editable.Path.cwd", return_value=tmp_path):
            result = runner.invoke(djb_cli, ["editable-djb"])

        assert result.exit_code == 1
        assert "Failed to install" in result.output or "Could not find" in result.output

    def test_uninstall_success(self, runner, tmp_path):
        """Test successful uninstall via CLI."""
        with patch("djb.cli.editable.subprocess.run") as mock_run:
            mock_run.return_value = Mock(returncode=0, stdout="", stderr="")
            with patch("djb.cli.editable.Path.cwd", return_value=tmp_path):
                result = runner.invoke(djb_cli, ["editable-djb", "--uninstall"])

        assert result.exit_code == 0
        assert "PyPI" in result.output

    def test_uninstall_failure(self, runner, tmp_path):
        """Test uninstall failure via CLI."""
        with patch("djb.cli.editable.subprocess.run") as mock_run:
            mock_run.return_value = Mock(returncode=1, stderr="error")
            with patch("djb.cli.editable.Path.cwd", return_value=tmp_path):
                result = runner.invoke(djb_cli, ["editable-djb", "--uninstall"])

        assert result.exit_code == 1
        assert "Failed to uninstall" in result.output or "Failed to remove" in result.output
