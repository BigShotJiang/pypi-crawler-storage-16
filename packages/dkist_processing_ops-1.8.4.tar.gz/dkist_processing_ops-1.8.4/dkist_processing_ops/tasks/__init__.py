"""Import of tasks is directly from package by convention"""

from dkist_processing_ops.tasks.wait import *
