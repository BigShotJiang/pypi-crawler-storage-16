def hello():
    print("Hello from dlr_ifc_parser!")

def time():
    import datetime
    return datetime.datetime.now()
