"""Public package API for dlr_ifc_parser.

Exports the Parser class (recommended) and a compatibility `ifc_parser`
object that matches earlier usage patterns in example code.
"""

from .main import Parser

__all__ = ["Parser"]


