from ifcopenshell.geom import create_shape
import ifcopenshell, ifcopenshell.geom
import numpy as np
from ifcopenshell.util import placement, element
from collections import defaultdict
from collections.abc import Mapping

# class read ifc
settings = ifcopenshell.geom.settings()
settings.set(settings.USE_WORLD_COORDS, True)   # world coordinates


class Level:
    """
    Represents a single building storey with convenient helpers.

    - level['IfcWall'] -> list of IfcWall elements
    - level.all_ifc_types -> set of all IFC types present
    - level.all_elements -> flat list of all elements
    - level.count() -> {ifc_type: count}
    - level.features -> basic feature dict (you can extend this)
    - level.elevation -> elevation value from the storey (if available)
    """

    def __init__(self, name, all_elements_Id, elementsId_by_type, levels_properties, elevation=None):
        self.name = name
        self._all_elements_Id = all_elements_Id
        self._elementsId_by_type = elementsId_by_type  # dict: ifc_type -> [elements]
        self._levels_properties = levels_properties
        self._elevation = elevation

    # --- Access by IFC type -------------------------------------------------

    def __getitem__(self, ifc_type: str):
        """Allow level['IfcWall'] to return all IfcWall elements."""
        return self._elementsId_by_type.get(ifc_type, [])

    # --- Summary properties -------------------------------------------------

    @property
    def all_ifc_types(self):
        """Set of all IFC types present on this level."""
        return set(self._elementsId_by_type.keys())

    @property
    def all_elements_Id(self):
        """list of all elements id on this level."""
        return self._all_elements_Id

    @property
    def levels_properties(self):
        """
        Basic feature dictionary for this level.
        You can add more things here later (area, room count, etc.).
        """
        return self._levels_properties
    
    @property
    def levels_features(self):
        """
        Basic feature dictionary for this level.
        You can add more things here later (area, room count, etc.).
        """
        return {
            "name": self.name,
            "num_elements": len(self.all_elements_Id),
            "num_ifc_types": len(self.all_ifc_types),
            "elevation": self._elevation,
        }

class Room:
    """
    Represents a single room (IfcSpace) with convenient helpers.

    - room.features -> basic feature dict (you can extend this)
    - room.id -> IfcSpace GlobalId
    - room.name -> IfcSpace Name
    """

    def __init__(self, name, prod, all_elements_Id, elementsId_by_type, rooms_properties):
        self.name = name
        self.prod = prod
        self._all_elements_Id = all_elements_Id
        self._elementsId_by_type = elementsId_by_type  # dict: ifc_type -> [elements]
        self._rooms_properties = rooms_properties

        try:
            self.shape = ifcopenshell.geom.create_shape(settings, prod)
        except RuntimeError as exc:
            # Representation is NULL, or other geom issue
            raise GeometryError(
                f"Failed to create geometry for space='{name}': {exc}"
            )
        
        self.shape = ifcopenshell.geom.create_shape(settings, prod)
    
    def __getitem__(self, ifc_type: str):
        """Allow level['IfcWall'] to return all IfcWall elements."""
        return self._elementsId_by_type.get(ifc_type, [])

    # --- Summary properties -------------------------------------------------

    @property
    def all_ifc_types(self):
        """Set of all IFC types present on this level."""
        return set(self._elementsId_by_type.keys())

    @property
    def all_elements_Id(self):
        """list of all elements id on this level."""
        return self._all_elements_Id
    
    @property
    def verts(self):
        """list of all elements id on this level."""
        return tuple(v * 3.280839895013123 for v in self.shape.geometry.verts)
    
    @property
    def faces(self):
        """list of all elements id on this level."""
        return self.shape.geometry.faces
    
    @property
    def edges(self):
        """list of all elements id on this level."""
        return self.shape.geometry.edges
    
    @property
    def rooms_properties(self):
        """
        Basic feature dictionary for this level.
        You can add more things here later (area, room count, etc.).
        """
        return self._rooms_properties
    
    # @property
    # def rooms_features(self):
    #     """
    #     Basic feature dictionary for this room.
    #     You can add more things here later (area, volume, etc.).
    #     """
    #     return {
    #         "id": self.id,
    #         "name": self.name,
    #     }

class GeometryError(Exception):
    """Raised when a Family cannot create geometry from an IFC product."""
    pass

class FamilyInstance:
    """
    One concrete IFC element (one object) with geometry helpers.
    """

    def __init__(self, prod):
        self.prod = prod
        self.tag = getattr(prod, "Tag", None)
        self.ifc_type = prod.is_a()

        self._shape = None
        self._mn = None
        self._mx = None

    def _ensure_geom(self):
        if self._shape is not None:
            return

        self._shape = ifcopenshell.geom.create_shape(settings, self.prod)
        T_shape = np.asarray(self._shape.transformation.matrix, float).reshape(4, 4)
        V = np.array(self._shape.geometry.verts, dtype=float).reshape(-1, 3)

        V_world_meter = (V @ T_shape[:3, :3].T) + T_shape[:3, 3]
        V_world_ft = V_world_meter * 3.280839895013123

        self._mn = V_world_ft.min(axis=0)
        self._mx = V_world_ft.max(axis=0)


    # --- geometry-like properties -----------------------------------------
    @property
    def length(self):
        self._ensure_geom()
        return abs(self._mx[0] - self._mn[0])

    @property
    def width(self):
        self._ensure_geom()
        return abs(self._mx[1] - self._mn[1])

    @property
    def height(self):
        self._ensure_geom()
        return abs(self._mx[2] - self._mn[2])

    @property
    def center_point(self):
        self._ensure_geom()
        return (self._mn + self._mx) / 2

    @property
    def bbox(self):
        self._ensure_geom()
        xmin, xmax = sorted([self._mn[0], self._mx[0]])
        ymin, ymax = sorted([self._mn[1], self._mx[1]])
        zmin, zmax = sorted([self._mn[2], self._mx[2]])

        vertices = [
            (float(xmin), float(ymin), float(zmin)),  # 0
            (float(xmax), float(ymin), float(zmin)),  # 1
            (float(xmax), float(ymax), float(zmin)),  # 2
            (float(xmin), float(ymax), float(zmin)),  # 3
            (float(xmin), float(ymin), float(zmax)),  # 4
            (float(xmax), float(ymin), float(zmax)),  # 5
            (float(xmax), float(ymax), float(zmax)),  # 6
            (float(xmin), float(ymax), float(zmax)),  # 7
        ]
        return vertices
    
    @property
    def verts(self):
        self._ensure_geom()
        return tuple(v * 3.280839895013123 for v in self._shape.geometry.verts)
    
    @property
    def faces(self):
        self._ensure_geom()
        return self._shape.geometry.faces
    
    @property
    def edges(self):
        self._ensure_geom()
        return self._shape.geometry.edges

class Families(Mapping):
    """
    Lazy dict-like container:

      families = parser.families
      - keys() / iteration -> Tag values
      - families['TAG']    -> Family (group of all elements with that Tag)
    """

    def __init__(self, index, element_list):
        self._index = index              # tag -> representative IfcElement
        self._element_list = element_list  # tag -> [IfcElement]
        self._cache = {}

    def __getitem__(self, tag):
        if tag in self._cache:
            return self._cache[tag]

        prod = self._index[tag]

        family_properties = element.get_psets(prod)
        family_properties["element_info"] = prod.get_info()

        fam = Family(
            prod=prod,
            tag=tag,
            element_list=self._element_list,
            family_properties=family_properties,
        )
        self._cache[tag] = fam
        return fam

    def __iter__(self):
        return iter(self._index)

    def __len__(self):
        return len(self._index)

    def __repr__(self):
        return f"Families(tags={list(self._index.keys())})"


class Family:
    """
    Represents *all* elements that share the same Tag.

    - family.tag -> the Tag value (e.g. '5128500')
    - family.element_list -> raw IfcElement objects for this Tag
    - family.instances -> list[FamilyInstance]
    - family.ifctypes -> dict[ifc_type: str, list[FamilyInstance]]

    - family.center_point / bbox / length / width / height:
        computed from the union of all instances (group bbox).
    """

    def __init__(self, prod, tag, element_list=None, family_properties=None):
        self.prod = prod            # representative ifc product (first with this Tag)
        self.tag = tag
        self._element_list = element_list or {}  # tag -> [IfcElement]
        self._family_properties = family_properties or {}

        # All IfcElement objects that share this Tag
        self._raw_instances = self._element_list.get(self.tag, [self.prod])

        # Wrap them in FamilyInstance, lazily
        self._instances_cache = None

        # Precompute group-level bbox from all instances
        self._compute_group_bbox()

    # ------------------------------------------------------------------    
    @property
    def element_list(self):
        """List of raw IfcElement objects with this Tag."""
        return self._raw_instances

    @property
    def instances(self):
        """List of FamilyInstance objects, one per IFC element with this Tag."""
        if self._instances_cache is None:
            self._instances_cache = [FamilyInstance(prod) for prod in self._raw_instances]
        return self._instances_cache

    @property
    def ifctypes(self):
        """
        Dict: { 'IfcWindow': [FamilyInstance, ...], 'IfcOpeningElement': [...], ... }
        """
        from collections import defaultdict
        buckets = defaultdict(list)
        for inst in self.instances:
            buckets[inst.ifc_type].append(inst)
        return dict(buckets)

    def __getitem__(self, key):
        """
        Allow:
            fam['IfcWindow'] -> list[FamilyInstance]
            fam[0]           -> first FamilyInstance
        """
        if isinstance(key, str):
            # interpret as IFC type
            return self.ifctypes.get(key, [])
        elif isinstance(key, int):
            return self.instances[key]
        raise KeyError(f"Unsupported key type for Family.__getitem__: {key!r}")

    # ------------------------------------------------------------------    
    def _compute_group_bbox(self):
        """
        Compute a bounding box that contains ALL instances with this Tag.
        This keeps your existing group-level properties working.
        """

        mn = np.array([np.inf, np.inf, np.inf])
        mx = np.array([-np.inf, -np.inf, -np.inf])

        for prod in self._raw_instances:
            try:
                shape = ifcopenshell.geom.create_shape(settings, prod)
            except RuntimeError:
                continue  # skip elements without geometry

            T_shape = np.asarray(shape.transformation.matrix, float).reshape(4, 4)
            V = np.array(shape.geometry.verts, dtype=float).reshape(-1, 3)
            V_world_meter = (V @ T_shape[:3, :3].T) + T_shape[:3, 3]
            V_world_ft = V_world_meter * 3.280839895013123

            mn = np.minimum(mn, V_world_ft.min(axis=0))
            mx = np.maximum(mx, V_world_ft.max(axis=0))

        self.shape = shape  
        self.mn, self.mx = mn, mx

    # --- Summary properties (group-level) ---------------------------------
    @property
    def length(self):
        return abs(self.mx[0] - self.mn[0])

    @property
    def width(self):
        return abs(self.mx[1] - self.mn[1])

    @property
    def height(self):
        return abs(self.mx[2] - self.mn[2])

    @property
    def center_point(self):
        return (self.mn + self.mx) / 2

    @property
    def bbox(self):
        xmin, xmax = sorted([self.mn[0], self.mx[0]])
        ymin, ymax = sorted([self.mn[1], self.mx[1]])
        zmin, zmax = sorted([self.mn[2], self.mx[2]])

        vertices = [
            (float(xmin), float(ymin), float(zmin)),  # 0
            (float(xmax), float(ymin), float(zmin)),  # 1
            (float(xmax), float(ymax), float(zmin)),  # 2
            (float(xmin), float(ymax), float(zmin)),  # 3
            (float(xmin), float(ymin), float(zmax)),  # 4
            (float(xmax), float(ymin), float(zmax)),  # 5
            (float(xmax), float(ymax), float(zmax)),  # 6
            (float(xmin), float(ymax), float(zmax)),  # 7
        ]
        return vertices

    @property
    def verts(self):
        """list of all elements id on this level."""
        return tuple(v * 3.280839895013123 for v in self.shape.geometry.verts)
    
    @property
    def faces(self):
        """list of all elements id on this level."""
        return self.shape.geometry.faces
    
    @property
    def edges(self):
        """list of all elements id on this level."""
        return self.shape.geometry.edges
    
    @property
    def family_properties(self):
        return self._family_properties


class Parser:
    def __init__(self, ifc_file: str):
        if ifcopenshell is None or element is None:
            raise ImportError(
                "ifcopenshell and ifcopenshell.util.element are required for IFC parsing. "
                "Install with: pip install ifcopenshell"
            )

        self.ifc_file = ifc_file

        try:
            self.ifc_model = ifcopenshell.open(ifc_file)
        except Exception as exc:
            raise RuntimeError(f"Failed to open IFC file '{ifc_file}': {exc}")

        # Will be lazy-built on first access
        self._levels = None
        self._rooms = None
        self._families = None

    # ----------------------------------------------------------------------
    # Levels
    # ----------------------------------------------------------------------

    @property
    def levels(self):
        """
        Returns a dict:
            { 'Level 01': Level(...), 'Level 02': Level(...), ... }

        Usage:
            parser = Parser(path)
            levels = parser.levels
            level1 = levels['Level 01']
        """
        if self._levels is not None:
            return self._levels

        levels = {}
        name_typeId = set()
        for storey in self.ifc_model.by_type("IfcBuildingStorey"):
            storey_name = element.get_pset(storey, 'Identity Data')['Name']
            storey_typeid = element.get_pset(storey, 'Other')['Type Id']
            name_typeId.add((storey_name, storey_typeid))

            levels_properties = element.get_psets(storey)
            levels_properties['level_info'] = storey.get_info()

            elementsId_by_type = defaultdict(list)
            all_elements_Id = []
            # get all elements contained in this storey
            for ele in element.get_contained(storey):
                elementsId_by_type[ele.is_a()].append(ele.Tag)
                all_elements_Id.append(ele.Tag)

            # Elevation is optional; use getattr to avoid errors
            elevation = getattr(storey, "Elevation", None)

            levels[storey.Name] = Level(
                name=storey.Name,
                all_elements_Id=all_elements_Id,
                elementsId_by_type=elementsId_by_type,
                levels_properties=levels_properties,
                elevation=elevation,
            )

        self._levels = levels
        self.name_typeId = name_typeId
        return self._levels

    def levels_name_list(self):
        """Return a list of all level names."""
        return list(self.levels.keys())

    def levels_name_typeId_pair(self):
        """Return a list of all level names."""
        return self.name_typeId

    # ----------------------------------------------------------------------
    # Rooms
    # ----------------------------------------------------------------------

    @property
    def rooms(self):
        """Return a dict of rooms {room.GlobalId: Room(...)}."""

        if self._rooms is not None:
            return self._rooms
    
        rooms = {}
        for space in self.ifc_model.by_type("IfcSpace"):

            rooms_properties = element.get_psets(space)
            rooms_properties['space_info'] = space.get_info()

            elementsId_by_type = defaultdict(list)
            all_elements_Id = []
            # get all elements contained in this storey
            for ele in element.get_contained(space):
                elementsId_by_type[ele.is_a()].append(ele.Tag)
                all_elements_Id.append(ele.Tag)
            
            if all_elements_Id:
                rooms[space.Name] = Room(
                    name=space.Name,
                    prod=space,
                    all_elements_Id=all_elements_Id,
                    elementsId_by_type=elementsId_by_type,
                    rooms_properties=rooms_properties,
                )

        self._rooms = rooms
        return self._rooms

    def rooms_name_list(self):
        """Return a list of all level names."""
        return list(self.rooms.keys())
    
    # ----------------------------------------------------------------------
    # Family
    # ----------------------------------------------------------------------

    @property
    def families(self):
        """
        Returns a lazy, dict-like object:
            families = parser.families
            list(families) or families.keys() -> list of tags
            families['TAG'] -> Family (geometry built on demand)
        """
        if self._families is not None:
            return self._families

        index = {}  # tag -> prod
        element_list = defaultdict(list)
        elementsId_by_type = defaultdict(list)
        for ele in self.ifc_model.by_type("IfcElement"):
            tag = getattr(ele, "Tag", None)
            if not tag:
                # skip elements without a Tag, or you can use prod.GlobalId as fallback
                continue
            
            # keep the first element we see for this tag as representative
            if tag not in index:
                index[tag] = ele

            elementsId_by_type[ele.is_a()].append(ele.Tag)
            element_list[tag].append(ele)

        # print(element_list['4272033'])
        self._families = Families(index, element_list)
        self.elementsId_by_type = elementsId_by_type
        return self._families

    @property
    def all_ElementId(self):
        """Return list of all tags."""
        return list(self.families.keys())
    
    @property
    def all_ifctypes_ElementId(self):
        """Return list of all tags."""
        return self.elementsId_by_type
    
    @property
    def all_ifctypes(self):
        """Return list of all tags."""
        return list(self.elementsId_by_type.keys())