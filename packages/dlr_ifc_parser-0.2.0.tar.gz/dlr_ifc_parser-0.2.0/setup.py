from setuptools import setup, find_packages

setup(
    name="dlr_ifc_parser",
    version="0.2.0",    #PEP 440
    description="A parser for IFC files developed by DLR Group.",
    packages=find_packages(),
    install_requires=['ifcopenshell']
)

