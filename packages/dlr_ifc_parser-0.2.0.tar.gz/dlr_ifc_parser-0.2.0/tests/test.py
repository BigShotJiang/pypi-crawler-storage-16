import dlr_ifc_parser 


ifc_path = "tests/13-23141-01_Hawthorne Elementary School_AR_2022.ifc"
parser = dlr_ifc_parser.Parser(ifc_path)

# print(parser.levels_name_list())    # list: level name 
# print(parser.levels_name_typeId_pair())  # {('LEVEL 01', '338392'), ('Level 02', '338392'), ('Level 00', '338392'), ('Level 03', '338392'), ('Level 01', '338392')}

levels = parser.levels     
# level1_ifc_type = levels['Level 01'].all_ifc_types  # set of all ifc types in Level 01

# wall_ele = levels['Level 01']['IfcWall']  # list of IfcWall id in Level 01

# all_ele = levels['Level 01'].all_elements_Id # list of all elements id in Level 01
# print(levels['Level 01'].levels_properties)  # dict of ifc types and their counts in Level 01
# print(levels['Level 01'].levels_features)  # dict of features in Level 01
# ----------------------------------------------------------------------------------------------

# space = parser.rooms    
# print(parser.rooms_name_list())    # list of room names
# print(space['A107'].all_ifc_types)  # set of all ifc types in room A107

# wall_ele = space['A107']['IfcFurniture']  # list of IfcFurniture in room A107

# all_ele = space['A107'].all_elements_Id # list of all elements id in room A107

# print(space['A107'].verts)  # tuple of all verts in the space geometry

# print(space['A107'].rooms_properties)  # dict of room features in room A107

# ----------------------------------------------------------------------------------------------

all_element_id = parser.all_ElementId  # list of all tags
ifc_type = parser.all_ifctypes # list of all ifc types
ifc_tag_dic = parser.all_ifctypes_ElementId    # dic: {ifc type: list of element Id}
all_door_id = ifc_tag_dic['IfcDoor']  # list of all IfcDoor element Ids

elements = parser.families  

# print(elements['5128500'].center_point)
# print(elements['5128500'].length)
# print(elements['5128500'].width)
# print(elements['5128500'].height)
# print(elements['5128500'].bbox)
# print(elements['5128500'].family_properties)
# print(elements['5128500'].verts)
# print(elements['5128500'].faces)
# print(elements['5128500'].edges)

# ----------------------------------------------------------------------------------------------
# print(elements['4183653'].center_point)
print(elements['4183653'].ifctypes)   
# elements['4272033'].ifctypes  # ['IfcWindow', 'IfcOpeningElement']
print(elements['4183653']['IfcSlab'][0].verts)
# raise an error if window/opening do window

# tags = familyinstance table 'ElementId' column
# x and y might be opposite and +- would be different


# ----------------------------------------------------------------------------------------------






