# Reference

Technical reference material including APIs and release notes.

```{toctree}
:maxdepth: 1
:glob:

reference/*
genindex
Release Notes <https://github.com/DiamondLightSource/dodal/releases>
```
