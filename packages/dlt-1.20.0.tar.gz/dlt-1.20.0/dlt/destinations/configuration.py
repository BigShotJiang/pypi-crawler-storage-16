# TODO: kept for backward compat with dlt+ and delete after next release
from dlt.common.storages.configuration import WithLocalFiles

__all__ = ["WithLocalFiles"]
