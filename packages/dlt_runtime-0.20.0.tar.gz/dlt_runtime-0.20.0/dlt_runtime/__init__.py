from dlt_runtime.version import __version__
