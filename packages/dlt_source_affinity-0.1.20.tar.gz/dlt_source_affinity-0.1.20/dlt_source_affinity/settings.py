"""Affinity source settings and constants"""

API_BASE = "https://api.affinity.co"
V2_PREFIX = "/v2"
