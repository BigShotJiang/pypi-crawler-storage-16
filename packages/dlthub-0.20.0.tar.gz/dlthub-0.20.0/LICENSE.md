# dltHub Software EULA
License Notice – External License Reference

This software package (the “Software”) is licensed solely under the dltHub Software End User License Agreement (the “License”). The complete and current text of the License is maintained at the following canonical location:

    https://dlthub.com/docs/plus/EULA

By downloading, installing, accessing, or using the Software, you acknowledge that you have read, understood, and agree to be bound by the License. If you do not agree to the License, do not download, install, access, or use the Software.

Copyright 2025 Scalevector