# LaTeX LIB

This is a library with a few functions for creating LaTeX documents

Check it out on [PyPI](https://pypi.org/project/dmitritsiu-latex-lib)!