from .funcs import generate_image, generate_table, create_document
