"""
CarterPerez-dev | 2025
__init__.py
"""

__version__ = "0.1.1"
__author__ = "CarterPerez-dev"
