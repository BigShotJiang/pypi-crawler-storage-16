"""
CarterPerez-dev | 2025
__main__.py

Entry point for python -m dnslookup
"""

from dnslookup.cli import app

if __name__ == "__main__":
    app()
