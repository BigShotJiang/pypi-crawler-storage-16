"""
CarterPerez-dev | 2025
__init__.py
Test suite for DNS Lookup CLI
"""
