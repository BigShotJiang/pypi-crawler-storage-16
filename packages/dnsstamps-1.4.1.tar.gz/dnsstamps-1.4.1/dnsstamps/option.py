from enum import Enum


class Option(Enum):
    DNSSEC = 1
    NO_LOGS = 2
    NO_FILTERS = 3
