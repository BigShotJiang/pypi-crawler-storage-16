"""
do-not-install-this-package

Never install this package. This package is used for research purposes only.
"""

__version__ = "0.1.0"

from .main import main

__all__ = ["main"]
