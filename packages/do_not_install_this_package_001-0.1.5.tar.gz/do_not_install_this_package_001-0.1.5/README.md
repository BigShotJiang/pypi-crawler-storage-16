# do-not-install-this-package

Never install this package. This package is used for research purposes (my bachleor thesis).
