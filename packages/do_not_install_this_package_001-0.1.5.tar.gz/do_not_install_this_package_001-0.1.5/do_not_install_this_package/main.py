def main():
    print("Hello from do-not-install-this-package!")


if __name__ == "__main__":
    main()
