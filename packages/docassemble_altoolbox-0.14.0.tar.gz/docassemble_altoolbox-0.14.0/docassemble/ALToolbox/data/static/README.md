# Static file directory

If you want to make files available in the web app, put them in
this directory.
