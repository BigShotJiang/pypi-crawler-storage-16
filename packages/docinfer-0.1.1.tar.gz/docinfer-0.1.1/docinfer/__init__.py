"""docinfer - Extract and infer metadata from PDF documents using AI."""

__version__ = "0.1.0"
__author__ = "Tino Kanngiesser"
__email__ = "tinokanngiesser@gmail.com"
__license__ = "MIT"

__all__ = [
    "version",
]
