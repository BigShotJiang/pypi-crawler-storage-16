def say_hello_world():
    print("Hello, World!")
    return "Hello, World!"
