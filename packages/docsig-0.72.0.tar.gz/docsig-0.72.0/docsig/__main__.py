"""
docsig.__main__
===============

Module entry point.
"""

import sys as _sys

from docsig import main

if __name__ == "__main__":
    _sys.exit(main())
