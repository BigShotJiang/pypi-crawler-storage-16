def main() -> None:
    print("Hello from doctest-ai!")
