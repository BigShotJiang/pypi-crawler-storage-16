def some_function(name: str = "World"):
    print(f"Hello {name}")
