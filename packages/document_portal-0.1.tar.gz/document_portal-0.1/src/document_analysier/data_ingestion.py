import os
import fitz
import uuid
from datetime import datetime, timezone

from ai_common.logger.custom_logger import logger, get_logger
from ai_common.logger.logger_utils import add_context
from ai_common.exception.custom_exception import AppException


class DocumentHandler:
    """
    DocumentHandler class for handling document ingestion
    """
    def __init__(self, data_dir: str = None, session_id: str = None) -> None:
        try:
            self.logger = get_logger(__name__)
            self.data_dir = data_dir or os.getenv(
                "DATA_STORAGE_PATH",
                os.path.join(os.getcwd(), "data", "document_analysis")
            )
            self.session_id = session_id or (
                f"session_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"
            )

            self.session_path = os.path.join(self.data_dir, self.session_id)
            if not os.path.exists(self.session_path):
                os.makedirs(self.session_path)
            
            self.logger = add_context(self.logger, session_id=self.session_id)
            self.logger.info(f"DocumentHandler initialized with session_id: {self.session_id}")
        except Exception as e:
            self.logger.error(f"Failed to initialize DocumentHandler: {str(e)}")
            raise AppException(f"Failed to initialize DocumentHandler: {str(e)}")
    
    def save_pdf(self, file_obj) -> str:
        """Save a PDF file-like object to the session directory.

        The method now accepts an object with a ``path`` attribute (the source file path)
        and a ``getbuffer()`` method returning the file's bytes. This matches the ``DummyFile``
        used in the ``__main__`` block and allows callers to pass any compatible file‑like
        object.
        """
        try:
            if not hasattr(file_obj, "path") or not hasattr(file_obj, "getbuffer"):
                raise AppException("Provided file object must have 'path' and 'getbuffer' attributes")

            if not os.path.exists(file_obj.path):
                raise AppException(f"PDF file not found at path: {file_obj.path}")

            pdf_name = os.path.basename(file_obj.path)
            dest_path = os.path.join(self.session_path, pdf_name)
            with open(dest_path, "wb") as f:
                f.write(file_obj.getbuffer())
            self.logger.info(f"PDF saved to: {dest_path}")
            return dest_path
        except Exception as e:
            self.logger.error(f"Failed to save PDF: {str(e)}")
            raise AppException(f"Failed to save PDF: {str(e)}")

    def read_pdf(self, pdf_path: str) -> list[str]:
        try:
            text_chunks = []
            with fitz.open(pdf_path) as pdf:
                for page_num, page in enumerate(pdf, start=1):
                    text = page.get_text("text")
                    text_chunks.append(f"\n--- Page {page_num}  ---\n{text}")
            text = "\n".join(text_chunks)
            return text
        except Exception as e:
            self.logger.error(f"Failed to read PDF: {str(e)}")
            raise AppException(f"Failed to read PDF: {str(e)}")


if __name__ == "__main__":
    from pathlib import Path
    from io import BytesIO
    document_handler = DocumentHandler(session_id='test_session')

    pdf_path = Path("/home/aignishant/Documents/genaiproject/dp/document_portal/data/document_analysis/NIPS-2017-attention-is-all-you-need-Paper.pdf")
    
    class DummyFile:
        def __init__(self, path):
            self.name = Path(path).name
            self.path = path
        
        def getbuffer(self):
            with open(self.path, "rb") as f:
                return f.read()

    try:
        document_handler.save_pdf(DummyFile(pdf_path))
        document_handler.logger.info(f"PDF saved to: {pdf_path}")
    except Exception as e:
        document_handler.logger.error(f"Failed to save PDF: {str(e)}")
        raise AppException(f"Failed to save PDF: {str(e)}")
    text = document_handler.read_pdf(pdf_path)
    document_handler.logger.info(f"PDF read from: {pdf_path}")
    document_handler.logger.info(f"PDF text: {text}")
