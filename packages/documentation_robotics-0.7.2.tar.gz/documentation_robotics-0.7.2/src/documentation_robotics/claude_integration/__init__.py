"""
Claude Code integration package.

Provides reference sheets, slash commands, and agent definitions
for integrating Documentation Robotics with Claude Code.
"""

__version__ = "0.6.5"
