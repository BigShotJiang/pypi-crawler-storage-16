"""Bundled documentation robotics viewer."""

__version__ = "0.1.0"
