import json
from typing import List, Dict, Union

import pymilvus

from docuverse.engines.search_queries import SearchQueries
from docuverse.utils import get_param


class SearchResult:
    """
    Represents the list of relevant text units (documents or paraphaphs) returned from a seqrch query.
    It's meant to be a soft wrapper around a list of dictionaries.
    """

    class SearchDatum:
        def __init__(self, data: Dict[str,str], **kwargs):
            self.__dict__.update(data)
            self.__dict__.update(kwargs)
            for k, v in self.__dict__.items():
                # Milvus will convert deep json trees into strings,
                # so we're # undoing that here
                if isinstance(v, str):
                    try:
                        r = json.loads(v)
                        setattr(self, k, r)
                    except ValueError as e:
                        pass
        def __getitem__(self, key, default=None):
            if key in self.__dict__:
                return self.__dict__[key]
            else:
                return default
        
        def get_text(self):
            if '_text' in self.__dict__:
                return self._text
            elif 'text' in self.__dict__:
                return self.text
            elif '_source' in self.__dict__:
                return self._source['text']
            else:
                raise Exception("TODO: Pending implementation")
        
        def __str__(self) -> str:
            datum_str = ""
            for key, value in self.__dict__.items():
                datum_str = f"{datum_str}Key: {key}\tValue: {value}\n"
            return datum_str

        def as_dict(self):
            return self.__dict__

        def get(self, item, default=None):
            return getattr(self, item, default)

    def __init__(self, question, data, **kwargs):
        self.retrieved_passages = []
        self.rouge_scorer = None
        self.question = question
        self.read_data(data)

    def __len__(self):
        return len(self.retrieved_passages)

    def __add__(self, other):
        return self.append(other)

    def __getitem__(self, i: int) -> SearchDatum:
        return self.retrieved_passages[i]

    def __iter__(self):
        return iter(self.retrieved_passages)

    def __str__(self):
        return self.as_json()

    def append(self, data: Union[Dict[str, str], SearchDatum], **kwargs) -> 'SearchResult':
        if isinstance(data, SearchResult.SearchDatum):
            self.retrieved_passages.append(data)
        else:
            self.retrieved_passages.append(SearchResult.SearchDatum(data, **kwargs))
        return self

    def remove_duplicates(self, duplicate_removal: str = "none",
                          rouge_duplicate_threshold: float = -1.0) -> None:
        """Remove duplicate passages based on specified criteria."""
        if not self._should_remove_duplicates(duplicate_removal):
            return

        if duplicate_removal == "exact":
            self._remove_exact_duplicates()
        elif duplicate_removal == "rouge":
            self._remove_rouge_duplicates(rouge_duplicate_threshold)
        elif duplicate_removal.startswith("key:"):
            self._remove_key_duplicates(duplicate_removal)

    def _should_remove_duplicates(self, duplicate_removal: str) -> bool:
        """Check if duplicate removal should be performed."""
        return not (duplicate_removal is None or
                    duplicate_removal == "none" or
                    not self.retrieved_passages)

    def _remove_exact_duplicates(self) -> None:
        """Remove passages with exact text matches."""
        if not self.retrieved_passages:
            return

        keep_passages = [self.retrieved_passages[0]]
        seen = {self.retrieved_passages[0].get_text(): 1}

        for passage in self.retrieved_passages[1:]:
            text = passage.get_text()
            if text not in seen:
                seen[text] = 1
                keep_passages.append(passage)

        self.retrieved_passages = keep_passages

    def _remove_rouge_duplicates(self, threshold: float) -> None:
        """Remove passages that are similar based on ROUGE score."""
        if not self.retrieved_passages:
            return
        from rouge_score.rouge_scorer import RougeScorer

        if self.rouge_scorer is None:
            self.rouge_scorer = RougeScorer(['rouge1'], use_stemmer=True)

        keep_passages = [self.retrieved_passages[0]]

        for passage in self.retrieved_passages[1:]:
            if not self._is_similar_to_any(passage, keep_passages, threshold):
                keep_passages.append(passage)

        self.retrieved_passages = keep_passages

    def _is_similar_to_any(self, passage: SearchDatum, passages: List[SearchDatum],
                           threshold: float) -> bool:
        """Check if a passage is similar to any passage in the given list."""
        text = passage.get_text()
        for existing_passage in passages:
            score = self.rouge_scorer.score(existing_passage.get_text(), text)
            if score['rouge1'].fmeasure >= threshold:
                return True
        return False

    def _remove_key_duplicates(self, duplicate_removal: str) -> None:
        """Remove passages with duplicate values for a specific key."""
        key = duplicate_removal.replace("key:", "")
        seen = set()
        keep_passages = []

        for passage in self.retrieved_passages:
            try:
                val = get_param(passage, key, None)
                if val is None or val not in seen:
                    if val is not None:
                        seen.add(val)
                    keep_passages.append(passage)
            except Exception as e:
                print(f"Error on {getattr(passage, 'metadata', 'unknown')}: {e}")

        self.retrieved_passages = keep_passages

    def top_k(self, k: int):
        return self.retrieved_passages[:k] if k>0 else self.retrieved_passages

    def read_data(self, data):
        if isinstance(data, dict):
            self._read_elastic_output(data)
        elif isinstance(data, list):
            self._read_list(data)
        else: # Need to deal with other structures.
            self._raise_not_implemented("Unknown data format")

    def _read_list(self, data):
        if len(data) == 0:
            return
        elif isinstance(data[0], dict) or isinstance(data[0], pymilvus.client.search_result.Hit):
            if 'entity' in data[0]:
                data = sorted(data, key=lambda k: (k['distance'], k['entity']['id']), reverse=True)
                for r in data:
                    self.retrieved_passages.append(SearchResult.SearchDatum(r['entity'], score=r['distance']))
            else:
                for i, r in enumerate(data):
                    self.retrieved_passages.append(SearchResult.SearchDatum(r, rank=i))
        elif isinstance(data[0], SearchResult.SearchDatum):
            self.retrieved_passages.extend(data)
        else:  # Need to deal with other structures.
            self._raise_not_implemented("Unknown list item format")

    def _read_elastic_output(self, data):
        if SearchResult.is_elastic_data(data):  # Looks like Elasticsearch results
            for i, d in enumerate(data['hits']['hits']):
                r = SearchResult.SearchDatum(d, rank=i)
                self.retrieved_passages.append(r)
        else:
            self._raise_not_implemented("Unknown dictionary format")

    def _raise_not_implemented(self, message: str = "") -> None:
        """Raise a standardized exception for unimplemented features."""
        raise NotImplementedError(f"Feature not implemented: {message}")

    def as_dict(self):
        return {"question": self.question.as_dict(), "retrieved_passages": [r.as_dict() for r in self.retrieved_passages]}

    def as_json(self, **kwargs):
        return json.dumps(self.as_dict(), **kwargs)

    @staticmethod
    def is_elastic_data(data):
        return 'hits' in data and 'hits' in data['hits']
