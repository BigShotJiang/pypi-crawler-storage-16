import csv

import argparse

# Create the parser
parser = argparse.ArgumentParser(description="Process input file and handle output flag.")

# Add the arguments
parser.add_argument('-o', '--output',
                    type=str,
                    help='The output flag')

parser.add_argument('input',
                    type=str,
                    help='The input file')

# Parse the arguments
args = parser.parse_args()


def join_fields(a, b):
    a = a.replace('[', '').replace(']', '').replace("\n", ' ')
    b = b.replace('[', '').replace(']', '').replace("\n", ' ')
    aa = a.split(' ')
    bb = b.split(' ')
    for b in bb:
        if b not in aa:
            aa.append(b)
    return f"[{' '.join(aa)}]"


with open(args.input, 'r') as f, open(args.output, 'w') as out:
    reader = csv.reader(f, delimiter=',')
    writer = csv.writer(out, delimiter=',', quotechar='"')
    queries = []
    for row in reader:
        queries.append(row)
    queries = sorted(queries, key=lambda x: x[0])

    prev = [""]
    for q in queries:
        q[3] = q[3].replace("\n", ' ')
        q[0] = q[0].replace('\n', '\\n')
        if q[0] != prev[0]:
            if prev != [""]:
                writer.writerow(prev)
            prev = q
        else:
            field3 = join_fields(prev[3], q[3])
            prev = [prev[0],
                    f"{prev[1]},{q[1]}",
                    prev[2] if prev[2] == q[2] else f"{prev[2]},{q[2]}",
                    field3
                    ]
    if prev != "":
        writer.writerow(prev)
