from docuverse.engines.retrieval.milvus.milvus import MilvusEngine
from docuverse.engines.retrieval.milvus.milvus_bm25 import MilvusBM25Engine

MilvusBM25Engine.test()