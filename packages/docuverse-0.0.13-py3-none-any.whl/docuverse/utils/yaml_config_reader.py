import os

import yaml


def read_yaml_config(config_path: str, allowed_env_vars: list = None) -> dict:
    """Read YAML configuration file with secure Jinja2 variable substitution.

    Security features:
    - Sandboxed Jinja2 environment prevents code execution
    - Whitelist-based environment variable access
    - Path traversal protection
    - Input validation and sanitization

    Args:
        config_path: Path to YAML configuration file
        allowed_env_vars: List of environment variables that can be accessed.
                         If None, defaults to safe common variables.

    Example:
        base_path: /home/user/data
        model_name: bert-base-uncased
        model_path: {{ base_path }}/models/{{ model_name }}
        output_dir: {{ base_path }}/output
        home_dir: "{{ env.HOME }}"  # Only if HOME is in allowed_env_vars
    """
    import re
    from jinja2 import Environment, FileSystemLoader, select_autoescape, StrictUndefined, UndefinedError

    # Try to import SandboxedEnvironment with version compatibility
    try:
        from jinja2.sandbox import SandboxedEnvironment
    except ImportError:
        try:
            from jinja2 import SandboxedEnvironment
        except ImportError:
            # Fallback: Use regular Environment with strict settings if SandboxedEnvironment is not available
            print("Warning: SandboxedEnvironment not available, using restricted Environment")
            SandboxedEnvironment = None

    # Validate and normalize the config path
    config_path = os.path.abspath(config_path)
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"Configuration file not found: {config_path}")

    # Security check: ensure file is readable and within reasonable bounds
    try:
        file_stat = os.stat(config_path)
        # Prevent extremely large files (potential DoS)
        if file_stat.st_size > 10 * 1024 * 1024:  # 10MB limit
            raise ValueError(f"Configuration file too large: {file_stat.st_size} bytes")
    except OSError as e:
        raise ValueError(f"Cannot access configuration file: {e}")

    # Define safe environment variables whitelist
    if allowed_env_vars is None:
        allowed_env_vars = [
            'HOME', 'USER', 'PATH', 'LANG', 'LC_ALL', 'TZ',
            'TMPDIR', 'TEMP', 'TMP', 'PWD', 'SHELL'
        ]

    # Create safe environment variables dict
    safe_env = {}
    for var in allowed_env_vars:
        if var in os.environ:
            # Sanitize environment variable values
            value = os.environ[var]
            # Remove null bytes and control characters for safety
            value = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', value)
            safe_env[var] = value

    try:
        template_dir = os.path.dirname(config_path)
        template_name = os.path.basename(config_path)
    
        # Create the most secure environment available
        if SandboxedEnvironment is not None:
            # Use SandboxedEnvironment if available
            env = SandboxedEnvironment(
                loader=FileSystemLoader(template_dir, followlinks=False),  # Prevent symlink attacks
                autoescape=select_autoescape(['html', 'xml']),  # Auto-escape when appropriate
                trim_blocks=True,
                lstrip_blocks=True,
                undefined=StrictUndefined,  # Strict undefined variable handling
                finalize=lambda x: x if x is not None else '',  # Handle None values safely
            )
        else:
            # Fallback to regular Environment with strict settings
            env = Environment(
                loader=FileSystemLoader(template_dir, followlinks=False),
                autoescape=select_autoescape(['html', 'xml']),
                trim_blocks=True,
                lstrip_blocks=True,
                undefined=StrictUndefined,
                finalize=lambda x: x if x is not None else '',
            )
    
        # Remove potentially dangerous globals and filters
        env.globals = {
            # Keep only essential, safe globals
            'range': range,
            'len': len,
            'str': str,
            'int': int,
            'float': float,
            'bool': bool,
        }
    
        # Keep only safe filters
        safe_filters = {
            'upper': str.upper,
            'lower': str.lower,
            'strip': str.strip,
            'replace': lambda s, old, new: str(s).replace(str(old), str(new)),
            'split': lambda s, sep=' ': str(s).split(str(sep)),
            'join': lambda seq, sep: str(sep).join(str(x) for x in seq),
            'length': len,
            'default': lambda value, default_value='': value if value is not None else default_value,
        }
        env.filters = safe_filters
    
        # Load template
        template = env.get_template(template_name)
    
        # Create restricted context with common default variables
        context = {
            'env': safe_env,  # Only whitelisted environment variables
            'corpus': '',  # Default empty value for corpus
        }

        # Multi-pass rendering to resolve self-referential variables
        max_iterations = 10
        rendered_content = None
    
        for iteration in range(max_iterations):
            try:
                # Render with current context
                rendered_content = template.render(**context)
            
                # Validate rendered content size
                if len(rendered_content) > 50 * 1024 * 1024:  # 50MB limit
                    raise ValueError("Rendered configuration too large")
            
                # Parse rendered YAML
                parsed_config = yaml.safe_load(rendered_content)
            
                if isinstance(parsed_config, dict):
                    # Create a flattened context for template variables
                    flattened_context = _create_flattened_context(parsed_config)
                
                    # Check if we need another iteration
                    old_context_keys = set(context.keys()) - {'env', 'corpus'}
                    new_context_keys = set(flattened_context.keys())
                
                    # Update context with flattened variables
                    context.update(flattened_context)
                
                    # If no new variables were added, we're done
                    if old_context_keys == new_context_keys:
                        return parsed_config
                    
                    # Try rendering again with updated context
                    new_rendered = template.render(**context)
                
                    # If content didn't change, we're done
                    if new_rendered == rendered_content:
                        return parsed_config
                    
                    rendered_content = new_rendered
                else:
                    # Not a dict, return as-is
                    return parsed_config
                
            except UndefinedError as e:
                # Extract variable name from error message
                undefined_var_match = re.search(r"'(\w+)' is undefined", str(e))
                if undefined_var_match and iteration < max_iterations - 1:
                    undefined_var = undefined_var_match.group(1)
                    # Add undefined variable with empty string default
                    context[undefined_var] = ''
                    continue
                else:
                    raise ValueError(f"Undefined variable in YAML template: {e}")
            except Exception as e:
                if "is undefined" in str(e) and iteration < max_iterations - 1:
                    # Try to continue with partial context
                    continue
                else:
                    raise e
    
        # Final parse after max iterations
        return yaml.safe_load(rendered_content)
            
    except Exception as e:
        if "is undefined" in str(e):
            raise ValueError(f"Undefined variable in YAML template: {e}")
        elif isinstance(e, yaml.YAMLError):
            raise ValueError(f"Error parsing YAML configuration: {e}")
        else:
            raise ValueError(f"Error processing YAML template: {e}")


def _create_flattened_context(config_dict: dict, parent_key: str = '') -> dict:
    """Create a flattened context that makes nested variables accessible.

    Args:
        config_dict: The configuration dictionary
        parent_key: The parent key for nested structures

    Returns:
        A flattened dictionary where nested values are accessible
    """
    import re

    flattened = {}

    for key, value in config_dict.items():
        # Sanitize key
        if not isinstance(key, str):
            key = str(key)

        # Make key safe for Jinja2
        safe_key = re.sub(r'[^a-zA-Z0-9_]', '_', key)
        if not safe_key or not safe_key[0].isalpha():
            safe_key = f"var_{safe_key}" if safe_key else f"var_{len(flattened)}"

        # Create full key with parent context
        full_key = f"{parent_key}_{safe_key}" if parent_key else safe_key

        if isinstance(value, str):
            # Remove potentially dangerous characters
            sanitized_value = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', value)
            # Limit string length
            if len(sanitized_value) <= 10000:
                flattened[safe_key] = sanitized_value
                flattened[full_key] = sanitized_value

        elif isinstance(value, (int, float, bool)):
            flattened[safe_key] = value
            flattened[full_key] = value

        elif isinstance(value, dict):
            # Recursively flatten nested dictionaries
            nested_flat = _create_flattened_context(value, full_key)
            flattened.update(nested_flat)
            # Also make the nested values available without prefix within their context
            for nested_key, nested_value in nested_flat.items():
                if nested_key.startswith(f"{full_key}_"):
                    short_key = nested_key[len(f"{full_key}_"):]
                    if short_key not in flattened:  # Don't override existing keys
                        flattened[short_key] = nested_value

        elif isinstance(value, list):
            # Only include simple list values
            sanitized_list = []
            for item in value[:100]:  # Limit list size
                if isinstance(item, (str, int, float, bool)):
                    if isinstance(item, str):
                        item = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', item)
                        if len(item) <= 1000:
                            sanitized_list.append(item)
                    else:
                        sanitized_list.append(item)
            flattened[safe_key] = sanitized_list
            flattened[full_key] = sanitized_list

        elif value is None:
            flattened[safe_key] = None
            flattened[full_key] = None

    return flattened
