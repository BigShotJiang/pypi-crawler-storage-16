# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal, TypeAlias

__all__ = ["TaxCategory"]

TaxCategory: TypeAlias = Literal["digital_products", "saas", "e_book", "edtech"]
