from .solar import interpolate_irradiance
from .temperature import interpolate_temperature
from .wind import interpolate_wind_components
