"""
MCP Prompts Package

Contains pre-built prompts for common Domo operations.
"""

from . import operations

__all__ = ["operations"]
