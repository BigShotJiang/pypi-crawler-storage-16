"""Routes package

This package organizes route modules by domain.
"""
