"""Compatibility helpers for route-level utilities."""

from . import logging

__all__ = ["logging"]
