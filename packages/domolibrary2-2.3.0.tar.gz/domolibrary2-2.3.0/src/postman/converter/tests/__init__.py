"""Test suite for Postman converter.

This package contains tests for both the multi-agent framework
and the legacy converter.
"""
