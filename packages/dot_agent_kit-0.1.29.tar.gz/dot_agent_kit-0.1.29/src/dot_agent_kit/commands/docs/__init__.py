"""Agent documentation command group."""
