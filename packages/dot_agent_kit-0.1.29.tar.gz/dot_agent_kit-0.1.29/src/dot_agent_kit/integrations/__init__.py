"""Integration layer for external dependencies (GitHub CLI, etc.)."""
