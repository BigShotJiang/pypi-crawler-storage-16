"""Kit source resolution.

Import from submodules:
- bundled: BundledKitSource
- resolver: KitResolver, KitSource, ResolvedKit
- standalone: StandalonePackageSource
"""
