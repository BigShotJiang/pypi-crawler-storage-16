"""Test fakes for dot-agent-kit.

Import from submodules:
- fake_artifact_repository: FakeArtifactRepository
"""
