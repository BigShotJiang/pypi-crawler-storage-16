"""Unit tests for fake implementations."""
