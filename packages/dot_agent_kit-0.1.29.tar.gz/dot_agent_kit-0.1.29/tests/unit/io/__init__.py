"""Tests for I/O operations."""
