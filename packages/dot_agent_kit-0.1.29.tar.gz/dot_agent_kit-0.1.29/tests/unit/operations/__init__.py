"""Tests for operations module."""
