# dotzen/cli.py
from dotzen import __version__
def main():
    print(f"dotzen version: {__version__}")
