machine learning third-party library made by ycsyrc

Download method: pip install draft-basic

Up to now, you can use this library to build a multi layer perceptron with one hidden layer, a perceptron, a knn model, a kmeans model, a SOM model and a NaiveBayes model.

Apart from that, it can also be used to draw linechart and confusion matrix.

This library is mainly used for education and entertainment.
