# -*- coding: UTF-8 -*-
'''
@Author  ：ycsyrc
@Description     ：
'''

from setuptools import setup  # 这个包没有的可以pip一下

setup()