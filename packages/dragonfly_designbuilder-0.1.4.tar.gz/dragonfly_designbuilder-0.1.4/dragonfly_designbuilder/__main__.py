from dragonfly_designbuilder.cli import designbuilder

if __name__ == '__main__':
    designbuilder()
