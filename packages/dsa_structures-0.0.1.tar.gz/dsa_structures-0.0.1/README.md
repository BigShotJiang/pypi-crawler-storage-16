# dsa-structures

This package provides simple and student-friendly implementations of basic Data Structures in Python.

Included structures:
- Linked List
- Doubly Linked List
- Stack
- Queue

## Installation

Install the package from PyPI:

pip install dsa-structures

## Usage Example

from dsa_structures import LinkedList

ll = LinkedList()
ll.append(10)
ll.append(20)
ll.append(30)

print(ll.display())  # Output: [10, 20, 30]
