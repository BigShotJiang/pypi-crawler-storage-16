class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


class LinkedList:
    def __init__(self):
        self.head = None

    def append(self, data):
        new_node = Node(data)
        if not self.head:
            self.head = new_node
            return
        curr = self.head
        while curr.next:
            curr = curr.next
        curr.next = new_node

    def insert(self, index, data):
        new_node = Node(data)
        if index == 0:
            new_node.next = self.head
            self.head = new_node
            return

        curr = self.head
        for _ in range(index - 1):
            if curr is None:
                raise IndexError("Index out of range")
            curr = curr.next

        new_node.next = curr.next
        curr.next = new_node

    def delete(self, data):
        curr = self.head
        if curr and curr.data == data:
            self.head = curr.next
            return

        prev = None
        while curr and curr.data != data:
            prev = curr
            curr = curr.next

        if curr:
            prev.next = curr.next

    def search(self, data):
        curr = self.head
        pos = 0
        while curr:
            if curr.data == data:
                return pos
            pos += 1
            curr = curr.next
        return -1

    def display(self):
        elems = []
        curr = self.head
        while curr:
            elems.append(curr.data)
            curr = curr.next
        return elems
