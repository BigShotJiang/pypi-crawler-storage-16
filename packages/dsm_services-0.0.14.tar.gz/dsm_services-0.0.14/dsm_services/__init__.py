__title__ = 'DigitalStoreMesh Services'
__version__ = '0.0.14'
__author__ = 'DigitalStoreMesh Co.,Ltd'
__license__ = 'MIT'

VERSION = __version__
