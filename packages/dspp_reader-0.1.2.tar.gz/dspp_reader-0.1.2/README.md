# Dark Sky Protection Photometers Reader

[![Upload Python Package](https://github.com/dark-sky-protection/dspp_reader/actions/workflows/python-publish.yml/badge.svg)](https://github.com/dark-sky-protection/dspp_reader/actions/workflows/python-publish.yml)
[![Documentation Status](https://readthedocs.org/projects/dspp-reader/badge/?version=latest)](https://dspp-reader.readthedocs.io/en/latest/?badge=latest)
