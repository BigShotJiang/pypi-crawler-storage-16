"""Integration tests for dspydantic."""

