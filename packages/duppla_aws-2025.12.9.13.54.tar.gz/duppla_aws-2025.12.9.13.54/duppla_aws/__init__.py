from duppla_aws.service.public import AmazonWebServices as AmazonWebServices
