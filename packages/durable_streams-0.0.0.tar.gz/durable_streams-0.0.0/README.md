# durable-streams

This is a **placeholder** release published to PyPI while the real implementation is in progress.

- Repo: https://github.com/durable-streams/durable-streams
- Issues: https://github.com/durable-streams/durable-streams/issues

Install:

```bash
pip install durable-streams
```