"""DUTVulnScanner - Cross-platform vulnerability scanning tool."""

__version__ = "0.1.7"
__author__ = "Phan Văn Tài, Trần Đình Mạnh, Mai Xuân Trường"
__description__ = "A comprehensive vulnerability scanning framework"
__authors__ = [
    {"name": "Phan Văn Tài", "email": "taiphanvan2403@gmail.com"},
    {"name": "Trần Đình Mạnh", "email": "trandinhmanh301103@gmail.com"},
    {"name": "Mai Xuân Trường", "email": "mxtruongqb656@gmail.com"},
]

