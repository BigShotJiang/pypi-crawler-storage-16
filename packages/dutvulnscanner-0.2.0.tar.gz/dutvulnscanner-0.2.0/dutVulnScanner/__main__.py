"""Main entry point for DUTVulnScanner CLI."""
from dutVulnScanner.cli.main import app

if __name__ == "__main__":
    app()
