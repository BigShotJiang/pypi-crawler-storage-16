"""CLI module for DUTVulnScanner."""
from .main import app

__all__ = ["app"]
