"""Scan commands for DUTVulnScanner CLI."""

import typer
import subprocess
import sys
import os
import json
from typing import List, Optional
from pathlib import Path
from datetime import datetime
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from dutVulnScanner.core.orchestrator import ScanOrchestrator
from dutVulnScanner.core.config import load_config

app = typer.Typer()
console = Console()

# Directory to store background scan metadata
SCAN_TRACKING_DIR = Path.home() / ".dutvulnscanner" / "background_scans"
SCAN_TRACKING_DIR.mkdir(parents=True, exist_ok=True)


@app.command()
def run(
    target: str = typer.Argument(..., help="Target host or IP address"),
    profile: str = typer.Option("web", "--profile", "-p", help="Scan profile to use"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output file path for final report"),
    output_dir: Optional[Path] = typer.Option(
        None, "--output-dir", "-d", help="Directory to save individual tool outputs"
    ),
    tools: Optional[List[str]] = typer.Option(None, "--tool", "-t", help="Specific tools to use"),
    daemon: bool = typer.Option(False, "--daemon", help="Run scan in background daemon mode"),
):
    """
    Run a vulnerability scan against a target.

    Example:
        dutVulnScanner scan run example.com --profile web --output results.json
        dutVulnScanner scan run example.com --profile quick --output-dir ./scan_results
        dutVulnScanner scan run example.com --profile quick --daemon
    """
    if daemon:
        # Run in background daemon mode
        console.print(f"[bold blue]Starting background scan against:[/bold blue] {target}")
        console.print(f"[dim]Profile: {profile} | Runner: local[/dim]")

        try:
            # Prepare command to run in background
            cmd = [sys.executable, "-m", "dutVulnScanner"]

            # Add arguments
            cmd.extend(["scan", "run", target])
            cmd.extend(["--profile", profile])
            if output:
                cmd.extend(["--output", str(output)])
            if output_dir:
                cmd.extend(["--output-dir", str(output_dir)])
            if tools:
                for tool in tools:
                    cmd.extend(["--tool", tool])

            # Remove daemon flag to avoid infinite recursion
            # cmd is already prepared without --daemon

            console.print(f"[dim]Starting daemon process...[/dim]")
            console.print(f"[dim]Command: {' '.join(cmd)}[/dim]")

            # Start process in background
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
                start_new_session=True,
            )

            console.print(f"[bold green]✓[/bold green] Scan started in background!")
            console.print(f"[dim]Process ID: {process.pid}[/dim]")

            # Save process metadata for tracking
            scan_metadata = {
                "pid": process.pid,
                "target": target,
                "profile": profile,
                "output": str(output) if output else None,
                "output_dir": str(output_dir) if output_dir else None,
                "tools": tools or [],
                "start_time": datetime.now().isoformat(),
                "status": "running",
                "command": " ".join(cmd),
            }

            metadata_file = SCAN_TRACKING_DIR / f"scan_{process.pid}.json"
            with open(metadata_file, "w") as f:
                json.dump(scan_metadata, f, indent=2)

            console.print(f"[dim]Scan tracked at: {metadata_file}[/dim]")
            console.print(f"[dim]Use 'dutVulnScanner scan status' to check progress[/dim]")
            console.print(f"[dim]Results will be saved to: {output_dir or output or 'scan_results/'}[/dim]")

            # Wait a moment and check if process is still running
            import time

            time.sleep(1)
            if process.poll() is None:
                console.print(f"[dim]Process {process.pid} is running[/dim]")
            else:
                console.print(f"[yellow]Warning: Process {process.pid} exited with code {process.returncode}[/yellow]")

        except Exception as e:
            console.print(f"[bold red]Error starting daemon:[/bold red] {str(e)}")
            raise typer.Exit(1)

    else:
        # Run in foreground mode (original behavior)
        console.print(f"[bold blue]Starting scan against:[/bold blue] {target}")
        console.print(f"[dim]Profile: {profile} | Runner: local[/dim]")

        try:
            config = load_config()
            orchestrator = ScanOrchestrator(config)

            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                task = progress.add_task("Preparing scan...", total=None)

                def update_progress(tool_name: str, status: str):
                    """Update progress display."""
                    if status == "running":
                        progress.update(task, description=f"[cyan]Running {tool_name}...[/cyan]")
                    elif status == "completed":
                        progress.update(task, description=f"[green]✓ {tool_name} completed[/green]")
                    elif status == "failed":
                        progress.update(task, description=f"[red]✗ {tool_name} failed[/red]")

                results = orchestrator.run_scan(
                    target=target,
                    profile=profile,
                    runner="local",
                    tools=tools,
                    runner_config=None,
                    progress_callback=update_progress,
                    output_dir=output_dir,  # Pass output_dir to save individual tool outputs
                )

                progress.update(task, description="[green]✓ Scan completed[/green]", completed=True)

            console.print(f"[bold green]✓[/bold green] Scan completed!")
            console.print(f"Found {len(results.get('vulnerabilities', []))} vulnerabilities")

            # Show output directory if used
            if results.get("output_directory"):
                console.print(f"[dim]Individual tool outputs saved to: {results['output_directory']}[/dim]")

            if output:
                orchestrator.save_results(results, output)
                console.print(f"[dim]Final report saved to: {output}[/dim]")
            elif not results.get("output_directory"):
                # If no output file and no output_dir, suggest using one
                console.print(f"[yellow]Tip: Use --output or --output-dir to save results[/yellow]")

        except Exception as e:
            console.print(f"[bold red]Error:[/bold red] {str(e)}")
            raise typer.Exit(1)


@app.command()
def list_tools():
    """List all available scanning tools."""
    from dutVulnScanner.plugins import AVAILABLE_ADAPTERS

    console.print("[bold]Available Scanning Tools:[/bold]")
    for name, adapter in AVAILABLE_ADAPTERS.items():
        console.print(f"  • {name}: {adapter.description}")


@app.command()
def status():
    """Check status of background scan processes."""
    console.print("[bold]Background Scan Status[/bold]\n")

    try:
        # Get all tracked scans
        scan_files = list(SCAN_TRACKING_DIR.glob("scan_*.json"))

        if not scan_files:
            console.print("[dim]No background scans found[/dim]")
            console.print(f"[dim]Tracking directory: {SCAN_TRACKING_DIR}[/dim]")
            return

        from rich.table import Table
        import psutil

        table = Table(show_header=True, title=f"Found {len(scan_files)} tracked scan(s)")
        table.add_column("PID", style="cyan", width=8)
        table.add_column("Target", style="green", width=25)
        table.add_column("Profile", style="yellow", width=12)
        table.add_column("Status", style="magenta", width=12)
        table.add_column("Started", style="blue", width=20)
        table.add_column("Output", style="white", width=30)

        active_count = 0
        for scan_file in sorted(scan_files, key=lambda f: f.stat().st_mtime, reverse=True):
            try:
                with open(scan_file) as f:
                    metadata = json.load(f)

                pid = metadata["pid"]
                target = metadata["target"]
                profile = metadata["profile"]
                start_time = metadata["start_time"]
                output_location = metadata.get("output_dir") or metadata.get("output") or "N/A"

                # Check if process is still running
                try:
                    proc = psutil.Process(pid)
                    if proc.is_running():
                        status = "[green]●[/green] Running"
                        active_count += 1
                    else:
                        status = "[red]●[/red] Stopped"
                        # Update metadata
                        metadata["status"] = "stopped"
                        with open(scan_file, "w") as f:
                            json.dump(metadata, f, indent=2)
                except psutil.NoSuchProcess:
                    status = "[yellow]●[/yellow] Completed"
                    # Update metadata
                    metadata["status"] = "completed"
                    with open(scan_file, "w") as f:
                        json.dump(metadata, f, indent=2)

                # Format start time
                try:
                    dt = datetime.fromisoformat(start_time)
                    time_str = dt.strftime("%Y-%m-%d %H:%M:%S")
                except:
                    time_str = start_time[:19]

                # Truncate long paths
                if len(output_location) > 28:
                    output_location = "..." + output_location[-25:]

                table.add_row(
                    str(pid),
                    target[:23] + "..." if len(target) > 25 else target,
                    profile,
                    status,
                    time_str,
                    output_location,
                )

            except Exception as e:
                console.print(f"[dim]Error reading {scan_file.name}: {e}[/dim]")
                continue

        console.print(table)
        console.print(f"\n[dim]Active scans: {active_count} | Total tracked: {len(scan_files)}[/dim]")
        console.print(f"[dim]Tracking directory: {SCAN_TRACKING_DIR}[/dim]")

        # Suggest cleanup if there are completed scans
        completed = len(scan_files) - active_count
        if completed > 0:
            console.print(f"\n[yellow]Tip: Use 'dutVulnScanner scan cleanup' to remove completed scan records[/yellow]")

    except ImportError:
        console.print("[red]psutil not available. Install with: pip install psutil[/red]")
    except Exception as e:
        console.print(f"[red]Error checking status: {e}[/red]")
        import traceback

        console.print(f"[dim]{traceback.format_exc()}[/dim]")


@app.command()
def cleanup(
    all: bool = typer.Option(False, "--all", "-a", help="Remove all scan records including running ones"),
):
    """Clean up completed background scan records."""
    try:
        scan_files = list(SCAN_TRACKING_DIR.glob("scan_*.json"))

        if not scan_files:
            console.print("[dim]No scan records to clean up[/dim]")
            return

        import psutil

        removed_count = 0
        kept_count = 0

        for scan_file in scan_files:
            try:
                with open(scan_file) as f:
                    metadata = json.load(f)

                pid = metadata["pid"]

                # Check if process is still running
                try:
                    proc = psutil.Process(pid)
                    is_running = proc.is_running()
                except psutil.NoSuchProcess:
                    is_running = False

                # Remove if completed or if --all flag is set
                if not is_running or all:
                    scan_file.unlink()
                    removed_count += 1
                    status = "running" if is_running else "completed"
                    console.print(f"[dim]Removed {status} scan: PID {pid} - {metadata['target']}[/dim]")
                else:
                    kept_count += 1

            except Exception as e:
                console.print(f"[yellow]Warning: Could not process {scan_file.name}: {e}[/yellow]")
                continue

        console.print(f"\n[green]✓[/green] Cleaned up {removed_count} scan record(s)")
        if kept_count > 0:
            console.print(f"[dim]Kept {kept_count} active scan(s). Use --all to remove all records.[/dim]")

    except ImportError:
        console.print("[red]psutil not available. Install with: pip install psutil[/red]")
    except Exception as e:
        console.print(f"[red]Error during cleanup: {e}[/red]")


@app.command()
def kill(
    pid: int = typer.Argument(..., help="Process ID of the scan to kill"),
):
    """Kill a running background scan by PID."""
    try:
        import psutil

        # Find the scan metadata file
        metadata_file = SCAN_TRACKING_DIR / f"scan_{pid}.json"

        if not metadata_file.exists():
            console.print(f"[yellow]No tracked scan found with PID {pid}[/yellow]")
            console.print(f"[dim]Use 'dutVulnScanner scan status' to see tracked scans[/dim]")
            return

        # Load metadata
        with open(metadata_file) as f:
            metadata = json.load(f)

        # Try to kill the process
        try:
            proc = psutil.Process(pid)
            proc.terminate()  # Send SIGTERM

            # Wait for process to terminate
            import time

            time.sleep(1)

            if proc.is_running():
                console.print(f"[yellow]Process {pid} did not terminate, forcing kill...[/yellow]")
                proc.kill()  # Send SIGKILL
                time.sleep(0.5)

            console.print(f"[green]✓[/green] Killed scan: {metadata['target']} (PID {pid})")

            # Update metadata
            metadata["status"] = "killed"
            metadata["killed_time"] = datetime.now().isoformat()
            with open(metadata_file, "w") as f:
                json.dump(metadata, f, indent=2)

        except psutil.NoSuchProcess:
            console.print(f"[yellow]Process {pid} is not running (already completed)[/yellow]")
            # Update metadata
            metadata["status"] = "completed"
            with open(metadata_file, "w") as f:
                json.dump(metadata, f, indent=2)

    except ImportError:
        console.print("[red]psutil not available. Install with: pip install psutil[/red]")
    except Exception as e:
        console.print(f"[red]Error killing process: {e}[/red]")


@app.command()
def validate(
    profile: str = typer.Argument(..., help="Profile name to validate"),
):
    """Validate a scan profile configuration."""
    from dutVulnScanner.core.schema import validate_profile

    try:
        is_valid, errors = validate_profile(profile)
        if is_valid:
            console.print(f"[bold green]✓[/bold green] Profile '{profile}' is valid")
        else:
            console.print(f"[bold red]✗[/bold red] Profile '{profile}' has errors:")
            for error in errors:
                console.print(f"  • {error}")
            raise typer.Exit(1)
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {str(e)}")
        raise typer.Exit(1)
