"""Core module for DUTVulnScanner."""
