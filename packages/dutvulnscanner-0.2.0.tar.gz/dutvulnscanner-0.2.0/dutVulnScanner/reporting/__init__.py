"""Reporting module for generating scan reports."""
