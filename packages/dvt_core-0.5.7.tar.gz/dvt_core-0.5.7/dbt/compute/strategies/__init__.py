"""
Spark Connection Strategies

This module provides different strategies for connecting to Spark clusters.
Uses the strategy pattern for flexible platform support.
"""

from dbt.compute.strategies.base import BaseConnectionStrategy
from dbt.compute.strategies.local import LocalStrategy

# DatabricksStrategy is imported lazily to avoid import errors when
# databricks-connect is not installed or incompatible with PySpark version


def get_databricks_strategy():
    """
    Lazily import and return DatabricksStrategy.

    This function allows importing DatabricksStrategy only when needed,
    avoiding import errors when databricks-connect is not installed or
    is incompatible with the installed PySpark version.
    """
    from dbt.compute.strategies.databricks import DatabricksStrategy
    return DatabricksStrategy


__all__ = ["BaseConnectionStrategy", "LocalStrategy", "get_databricks_strategy"]
