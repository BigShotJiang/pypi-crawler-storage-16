"""
Compute Cluster Registry

Manages external compute cluster configurations for DVT.

v0.5.6: Computes are stored internally in ~/.dvt/.data/computes.json
        Managed exclusively via `dvt compute` CLI commands.
        No user-visible YAML configuration files.
"""

import json
import os
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

from dbt.clients.yaml_helper import load_yaml_text
from dbt_common.exceptions import DbtRuntimeError


def get_dvt_dir() -> Path:
    """Get the DVT config directory (~/.dvt/)."""
    # Check DVT_PROFILES_DIR env var first (same as profiles)
    profiles_dir = os.environ.get("DVT_PROFILES_DIR")
    if profiles_dir:
        return Path(profiles_dir)
    # Fall back to ~/.dvt/
    return Path.home() / ".dvt"


def get_internal_data_dir() -> Path:
    """Get the DVT internal data directory (~/.dvt/.data/)."""
    return get_dvt_dir() / ".data"


class SparkPlatform(Enum):
    """Spark platform types for connection strategies."""

    LOCAL = "local"
    DATABRICKS = "databricks"
    EMR = "emr"  # Future
    DATAPROC = "dataproc"  # Future
    EXTERNAL = "external"  # Generic external cluster


# Default out-of-box compute engine configuration (parsed from YAML for readability)
DEFAULT_COMPUTES_YAML = """
# Default compute engine for federated queries
target_compute: spark-local

# Available compute engines
computes:
  spark-local:
    type: spark
    description: "Local Spark for federation (Spark 4.0.1 with enhanced performance)"
    config:
      master: "local[2]"
      spark.driver.memory: "2g"
      spark.executor.memory: "2g"
      spark.jars.packages: "net.snowflake:snowflake-jdbc:3.16.1,net.snowflake:spark-snowflake_2.12:3.0.2-spark_3.5,org.postgresql:postgresql:42.7.4,com.mysql:mysql-connector-j:9.1.0,com.microsoft.sqlserver:mssql-jdbc:12.8.1.jre11,com.oracle.database.jdbc:ojdbc11:23.6.0.24.10,com.amazon.redshift:redshift-jdbc42:2.1.0.32,com.google.cloud.spark:spark-bigquery-with-dependencies_2.12:0.42.0,com.databricks:databricks-jdbc:2.6.36,io.trino:trino-jdbc:443,io.prestosql:presto-jdbc:0.286,com.simba.athena:athena-jdbc42:2.1.6.0,com.teradata.jdbc:terajdbc:20.00.00.20,com.ibm.db2:jcc:11.5.9.0,com.clickhouse:clickhouse-jdbc:0.6.5,com.exasol:exasol-jdbc:24.2.0,com.vertica.jdbc:vertica-jdbc:24.3.0,org.mariadb.jdbc:mariadb-java-client:3.4.1,com.singlestore:singlestore-jdbc-client:1.3.4,org.neo4j.driver:neo4j-java-driver:5.25.0,com.starrocks:starrocks-spark-connector-3.3_2.12:1.1.2,org.apache.doris:spark-doris-connector-3.3_2.12:1.3.1,com.firebolt:firebolt-jdbc:5.0.1,io.questdb:questdb:8.2.1,org.apache.hive:hive-jdbc:3.1.3,org.apache.impala:impala-jdbc:2.6.30"
      spark.sql.legacy.postgres.datetimeMapping.enabled: "true"
      spark.sql.legacy.mysql.timestampNTZMapping.enabled: "true"
      spark.sql.legacy.oracle.timestampMapping.enabled: "true"
      spark.sql.legacy.mssqlserver.numericMapping.enabled: "true"
      spark.ui.enabled: "false"
      spark.ui.showConsoleProgress: "false"
      spark.eventLog.enabled: "false"
      spark.driver.bindAddress: "127.0.0.1"
      spark.driver.host: "localhost"
      spark.sql.shuffle.partitions: "8"
      spark.sql.execution.arrow.pyspark.enabled: "true"
      spark.sql.execution.arrow.pyspark.fallback.enabled: "true"
      spark.sql.execution.arrow.maxRecordsPerBatch: "10000"
      spark.sql.adaptive.enabled: "true"
      spark.sql.adaptive.coalescePartitions.enabled: "true"
      spark.sql.adaptive.skewJoin.enabled: "true"
      spark.sql.optimizer.dynamicPartitionPruning.enabled: "true"
"""


@dataclass
class ComputeCluster:
    """Configuration for an external compute cluster."""

    name: str  # Cluster identifier
    type: str  # 'spark' (currently only Spark supported for external)
    config: Dict[str, Any] = field(default_factory=dict)  # Cluster-specific config
    description: Optional[str] = None
    cost_per_hour: Optional[float] = None  # Estimated cost per hour (USD)

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        result = {
            "name": self.name,
            "type": self.type,
            "config": self.config,
        }
        if self.description:
            result["description"] = self.description
        if self.cost_per_hour is not None:
            result["cost_per_hour"] = self.cost_per_hour
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ComputeCluster":
        """Deserialize from dictionary."""
        return cls(
            name=data["name"],
            type=data["type"],
            config=data.get("config", {}),
            description=data.get("description"),
            cost_per_hour=data.get("cost_per_hour"),
        )

    def detect_platform(self) -> SparkPlatform:
        """
        Detect Spark platform from configuration keys.

        :returns: SparkPlatform enum value
        """
        if self.type != "spark":
            return SparkPlatform.EXTERNAL

        config_keys = set(self.config.keys())

        # Databricks: has host and token
        if "host" in config_keys and "token" in config_keys:
            return SparkPlatform.DATABRICKS

        # External: has master but not local
        if "master" in config_keys:
            master = self.config["master"]
            if master.startswith("local"):
                return SparkPlatform.LOCAL
            else:
                return SparkPlatform.EXTERNAL

        # Default to local
        return SparkPlatform.LOCAL


class ComputeRegistry:
    """
    Registry for managing external compute clusters.

    v0.5.6: Clusters are stored internally in ~/.dvt/.data/computes.json
            Managed exclusively via `dvt compute` CLI commands.
    """

    def __init__(self, project_dir: Optional[str] = None):
        """
        Initialize compute registry.

        :param project_dir: Path to project root directory (for JDBC jars)
        """
        self.project_dir = project_dir or os.getcwd()
        self.data_dir = get_internal_data_dir()
        self.compute_file = self.data_dir / "computes.json"
        # JDBC jars stay at project level
        self.jdbc_jars_dir = os.path.join(self.project_dir, ".dvt", "jdbc_jars")
        self._clusters: Dict[str, ComputeCluster] = {}
        self._target_compute: Optional[str] = None
        self._load()

    def _load(self) -> None:
        """Load clusters from internal storage."""
        if not self.compute_file.exists():
            # No internal storage - use defaults
            self._load_defaults()
            return

        try:
            with open(self.compute_file, "r") as f:
                data = json.load(f)

            if not data:
                self._load_defaults()
                return

            # Parse target_compute (default compute engine)
            self._target_compute = data.get("target_compute", "spark-local")

            # Parse computes
            computes_data = data.get("computes", {})
            for name, cluster_data in computes_data.items():
                cluster_data["name"] = name  # Add name to data
                cluster = ComputeCluster.from_dict(cluster_data)
                self._clusters[cluster.name] = cluster

            # If no computes defined, use defaults
            if not self._clusters:
                self._load_defaults()

        except Exception as e:
            raise DbtRuntimeError(f"Failed to load compute registry: {str(e)}") from e

    def _load_defaults(self) -> None:
        """Load default out-of-box compute engines."""
        yaml_content = load_yaml_text(DEFAULT_COMPUTES_YAML)

        self._target_compute = yaml_content.get("target_compute", "spark-local")

        computes_data = yaml_content.get("computes", {})
        for name, cluster_data in computes_data.items():
            cluster_data["name"] = name
            cluster = ComputeCluster.from_dict(cluster_data)
            self._clusters[cluster.name] = cluster

    def _save(self) -> None:
        """Save clusters to internal storage."""
        # Ensure data directory exists
        os.makedirs(self.data_dir, exist_ok=True)

        # Build computes dict
        computes_dict = {}
        for cluster in self._clusters.values():
            cluster_dict = cluster.to_dict()
            cluster_dict.pop("name")  # Don't duplicate name in value
            computes_dict[cluster.name] = cluster_dict

        data = {
            "target_compute": self._target_compute or "spark-local",
            "computes": computes_dict,
        }

        # Write to internal JSON file
        with open(self.compute_file, "w") as f:
            json.dump(data, f, indent=2)

    @property
    def target_compute(self) -> str:
        """Get the default target compute engine."""
        return self._target_compute or "spark-local"

    @target_compute.setter
    def target_compute(self, value: str) -> None:
        """Set the default target compute engine."""
        if value not in self._clusters:
            raise DbtRuntimeError(
                f"Cannot set target_compute to '{value}': compute engine not found. "
                f"Available engines: {', '.join(self._clusters.keys())}"
            )
        self._target_compute = value
        self._save()

    def register(
        self,
        name: str,
        cluster_type: str,
        config: Dict[str, Any],
        description: Optional[str] = None,
        replace: bool = False,
    ) -> None:
        """
        Register a new compute cluster.

        :param name: Cluster name (must be unique)
        :param cluster_type: Type of cluster ('spark')
        :param config: Cluster configuration dict
        :param description: Optional cluster description
        :param replace: If True, replace existing cluster with same name
        :raises DbtRuntimeError: If cluster exists and replace=False
        """
        if name in self._clusters and not replace:
            raise DbtRuntimeError(
                f"Compute cluster '{name}' already exists. Use replace=True to overwrite."
            )

        if cluster_type not in ("spark",):
            raise DbtRuntimeError(
                f"Unsupported cluster type '{cluster_type}'. Supported types: spark"
            )

        cluster = ComputeCluster(
            name=name, type=cluster_type, config=config, description=description
        )

        self._clusters[name] = cluster
        self._save()

    def remove(self, name: str) -> None:
        """
        Remove a compute cluster.

        :param name: Cluster name
        :raises DbtRuntimeError: If cluster not found
        """
        if name not in self._clusters:
            raise DbtRuntimeError(f"Compute cluster '{name}' not found")

        del self._clusters[name]
        self._save()

    def get(self, name: str) -> Optional[ComputeCluster]:
        """
        Get a compute cluster by name.

        :param name: Cluster name
        :returns: ComputeCluster or None if not found
        """
        return self._clusters.get(name)

    def list(self) -> List[ComputeCluster]:
        """
        List all registered clusters.

        :returns: List of ComputeCluster objects
        """
        return list(self._clusters.values())

    def exists(self, name: str) -> bool:
        """
        Check if a cluster exists.

        :param name: Cluster name
        :returns: True if cluster exists
        """
        return name in self._clusters

    @staticmethod
    def ensure_jdbc_jars_dir(project_dir: str) -> None:
        """
        Ensure the project-level .dvt/jdbc_jars/ directory exists.

        :param project_dir: Path to project root directory
        """
        jdbc_jars_dir = os.path.join(project_dir, ".dvt", "jdbc_jars")
        os.makedirs(jdbc_jars_dir, exist_ok=True)
