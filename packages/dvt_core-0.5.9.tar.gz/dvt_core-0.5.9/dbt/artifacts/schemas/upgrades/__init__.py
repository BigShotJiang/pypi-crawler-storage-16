from dbt.artifacts.schemas.upgrades.upgrade_manifest import upgrade_manifest_json
from dbt.artifacts.schemas.upgrades.upgrade_manifest_dbt_version import (
    upgrade_manifest_json_dbt_version,
)
