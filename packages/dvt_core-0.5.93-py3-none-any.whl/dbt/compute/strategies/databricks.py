"""
Databricks Spark Connection Strategy

Provides connection to Databricks clusters via databricks-connect.
Supports both interactive clusters and SQL warehouses.
"""

from typing import Any, Dict, Optional

from dbt.compute.strategies.base import BaseConnectionStrategy
from dbt_common.exceptions import DbtRuntimeError

try:
    from pyspark.sql import SparkSession

    PYSPARK_AVAILABLE = True
except ImportError:
    PYSPARK_AVAILABLE = False
    SparkSession = None

try:
    from databricks.connect import DatabricksSession

    DATABRICKS_CONNECT_AVAILABLE = True
except ImportError:
    DATABRICKS_CONNECT_AVAILABLE = False
    DatabricksSession = None


class DatabricksStrategy(BaseConnectionStrategy):
    """
    Databricks cluster connection strategy.

    Connects to Databricks clusters using databricks-connect library.
    Supports two connection modes:

    1. Interactive Cluster (via cluster_id):
    {
        "host": "https://dbc-xxxxx.cloud.databricks.com",
        "token": "dapi...",
        "cluster_id": "1234-567890-abcde123"
    }

    2. SQL Warehouse (via http_path):
    {
        "host": "https://dbc-xxxxx.cloud.databricks.com",
        "token": "dapi...",
        "http_path": "/sql/1.0/warehouses/abc123def456"
    }

    Cost Estimation:
    - All-purpose compute: $0.55/DBU (typical: 4 DBU/hr = $2.20/hr)
    - SQL warehouses: $0.22/DBU (typical: 2 DBU/hr = $0.44/hr)
    """

    def validate_config(self) -> None:
        """
        Validate Databricks strategy configuration.

        Required fields:
        - host: Databricks workspace URL
        - token: Personal access token or service principal token

        Required (one of):
        - cluster_id: Interactive cluster ID
        - http_path: SQL Warehouse HTTP path

        :raises DbtRuntimeError: If configuration is invalid
        """
        if not isinstance(self.config, dict):
            raise DbtRuntimeError(
                f"Databricks config must be a dictionary, got {type(self.config)}"
            )

        # Check required fields
        required_fields = ["host", "token"]
        missing = [f for f in required_fields if f not in self.config]
        if missing:
            raise DbtRuntimeError(
                f"Databricks config missing required fields: {', '.join(missing)}"
            )

        # Check that at least one of cluster_id or http_path is provided
        has_cluster = "cluster_id" in self.config
        has_warehouse = "http_path" in self.config

        if not has_cluster and not has_warehouse:
            raise DbtRuntimeError(
                "Databricks config must include either 'cluster_id' (for interactive cluster) "
                "or 'http_path' (for SQL Warehouse)"
            )

        # Validate host format
        host = self.config["host"]
        if not host.startswith("https://"):
            raise DbtRuntimeError(f"Databricks host must start with 'https://', got: {host}")

        # Validate token format (basic check)
        token = self.config["token"]
        if not token or len(token) < 10:
            raise DbtRuntimeError("Databricks token appears invalid (too short or empty)")

    def get_spark_session(self) -> SparkSession:
        """
        Create Databricks Spark session.

        Uses databricks-connect to connect to remote Databricks cluster.

        :returns: Initialized SparkSession connected to Databricks
        :raises DbtRuntimeError: If session creation fails
        """
        if not PYSPARK_AVAILABLE:
            raise DbtRuntimeError("PySpark is not available. Install it with: pip install pyspark")

        if not DATABRICKS_CONNECT_AVAILABLE:
            raise DbtRuntimeError(
                "databricks-connect is not available. "
                "Install it with: pip install 'dvt-core[databricks]' "
                "or: pip install databricks-connect>=13.0.0"
            )

        try:
            # Build Databricks connection config
            builder = DatabricksSession.builder

            # Required: host and token
            builder = builder.host(self.config["host"])
            builder = builder.token(self.config["token"])

            # Optional: cluster_id or http_path
            if "cluster_id" in self.config:
                builder = builder.clusterId(self.config["cluster_id"])
            elif "http_path" in self.config:
                builder = builder.httpPath(self.config["http_path"])

            # Set app name
            builder = builder.appName(self.app_name)

            # Apply additional Spark configs (user-provided)
            for key, value in self.config.items():
                if key not in ("host", "token", "cluster_id", "http_path"):
                    builder = builder.config(key, value)

            # Create session
            spark = builder.getOrCreate()

            # Set log level to WARN to reduce noise
            spark.sparkContext.setLogLevel("WARN")

            return spark

        except Exception as e:
            # Provide helpful error messages for common issues
            error_msg = str(e).lower()

            if "unauthorized" in error_msg or "authentication" in error_msg:
                raise DbtRuntimeError(
                    f"Failed to authenticate with Databricks. Check your token. "
                    f"Error: {str(e)}"
                ) from e
            elif "cluster" in error_msg and "not found" in error_msg:
                raise DbtRuntimeError(
                    f"Databricks cluster not found. Check your cluster_id or http_path. "
                    f"Error: {str(e)}"
                ) from e
            elif "timeout" in error_msg:
                raise DbtRuntimeError(
                    f"Timeout connecting to Databricks. Check your network and cluster status. "
                    f"Error: {str(e)}"
                ) from e
            else:
                raise DbtRuntimeError(
                    f"Failed to create Databricks Spark session: {str(e)}"
                ) from e

    def close(self, spark: Optional[SparkSession]) -> None:
        """
        Clean up Databricks Spark session.

        For Databricks, we don't stop the remote cluster (it keeps running).
        Just clean up the local session reference.

        :param spark: SparkSession to clean up
        """
        # Don't stop the remote cluster - just clean up local reference
        # The cluster continues running for other users/queries
        if spark:
            try:
                # Just clear the local reference - don't call stop()
                pass
            except Exception:
                pass  # Best effort cleanup

    def estimate_cost(self, duration_minutes: float) -> float:
        """
        Estimate cost for Databricks execution.

        Cost varies by cluster type:
        - All-purpose compute: ~$2.20/hour (4 DBU @ $0.55/DBU)
        - SQL warehouses: ~$0.44/hour (2 DBU @ $0.22/DBU)

        :param duration_minutes: Estimated query duration in minutes
        :returns: Estimated cost in USD
        """
        # Detect cluster type
        is_sql_warehouse = "http_path" in self.config

        if is_sql_warehouse:
            # SQL Warehouse: cheaper, optimized for SQL
            dbu_per_hour = 2.0  # Typical SQL Warehouse size
            cost_per_dbu = 0.22  # SQL Warehouse pricing
        else:
            # Interactive cluster: more expensive, more flexible
            dbu_per_hour = 4.0  # Typical all-purpose cluster size
            cost_per_dbu = 0.55  # All-purpose compute pricing

        # Calculate cost
        hours = duration_minutes / 60.0
        total_dbu = dbu_per_hour * hours
        cost_usd = total_dbu * cost_per_dbu

        return round(cost_usd, 2)

    def get_platform_name(self) -> str:
        """Get platform name."""
        return "databricks"

    def get_cluster_info(self) -> Dict[str, Any]:
        """
        Get information about the connected cluster.

        :returns: Dictionary with cluster metadata
        """
        info = {
            "platform": "databricks",
            "host": self.config.get("host", "unknown"),
        }

        if "cluster_id" in self.config:
            info["cluster_id"] = self.config["cluster_id"]
            info["cluster_type"] = "interactive"
        elif "http_path" in self.config:
            info["http_path"] = self.config["http_path"]
            info["cluster_type"] = "sql_warehouse"

        return info
