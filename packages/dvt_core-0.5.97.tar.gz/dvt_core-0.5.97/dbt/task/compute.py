"""
Compute Task

Handles DVT compute engine management commands:
- test: List all compute engines with connection status
- edit: Open computes.yml in user's editor
- validate: Validate compute engine configurations

v0.5.97: Simplified CLI - removed register/remove (use dvt compute edit instead)
         computes.yml with comprehensive samples replaces interactive registration.
"""

import os
import subprocess
import sys
from pathlib import Path
from typing import Optional

from dbt.config.compute import ComputeRegistry, SparkPlatform, DEFAULT_COMPUTES_YAML
from dbt_common.exceptions import DbtRuntimeError


class ComputeTask:
    """Task for managing DVT compute engines."""

    def __init__(self, project_dir: Optional[str] = None):
        """
        Initialize ComputeTask.

        :param project_dir: Path to project root directory (defaults to current directory)
        """
        self.project_dir = project_dir or str(Path.cwd())
        self.registry = ComputeRegistry(self.project_dir)

    def test_computes(self) -> bool:
        """
        Test all compute engines and show status with rich symbols.

        Lists all registered compute engines with:
        - ✅ Connected/Available
        - ❌ Not connected/Error
        - ⚠️  Warning (e.g., missing optional dependency)

        :returns: True if all tests pass, False otherwise
        """
        clusters = self.registry.list()

        if not clusters:
            print("No compute engines configured.")
            print("\nRun 'dvt compute edit' to configure compute engines.")
            return True

        print("\n" + "=" * 70)
        print("DVT Compute Engines")
        print("=" * 70)
        print(f"\nConfig: {self.registry.get_config_path()}")
        print(f"Default: {self.registry.target_compute}")
        print("\n" + "-" * 70)

        all_passed = True

        for cluster in clusters:
            # Show cluster header
            default_marker = " (default)" if cluster.name == self.registry.target_compute else ""
            platform = cluster.detect_platform()

            print(f"\n{cluster.name}{default_marker}")
            print(f"  Type: {cluster.type}")
            print(f"  Platform: {platform.value}")
            if cluster.description:
                print(f"  Description: {cluster.description}")

            # Test the cluster
            status, message = self._test_single_cluster(cluster)

            if status == "ok":
                print(f"  Status: ✅ {message}")
            elif status == "warning":
                print(f"  Status: ⚠️  {message}")
            elif status == "error":
                print(f"  Status: ❌ {message}")
                all_passed = False

        print("\n" + "-" * 70)

        # Summary
        if all_passed:
            print("✅ All compute engines validated successfully")
        else:
            print("❌ Some compute engines have issues")

        print("\nCommands:")
        print("  dvt compute edit      Open computes.yml in editor")
        print("  dvt compute validate  Validate YAML syntax")
        print("  dvt compute test      Show this status (current command)")

        return all_passed

    def _test_single_cluster(self, cluster) -> tuple:
        """
        Test a single cluster and return status.

        :param cluster: ComputeCluster to test
        :returns: Tuple of (status, message) where status is 'ok', 'warning', or 'error'
        """
        platform = cluster.detect_platform()

        if cluster.type == "spark":
            if platform == SparkPlatform.DATABRICKS:
                # Check Databricks config
                required = ["host", "token"]
                missing = [k for k in required if k not in cluster.config]
                if missing:
                    return ("error", f"Missing config: {', '.join(missing)}")

                # Check for cluster_id OR http_path
                if "cluster_id" not in cluster.config and "http_path" not in cluster.config:
                    return ("error", "Missing config: cluster_id or http_path")

                # Check databricks-connect availability
                try:
                    import databricks.connect  # noqa: F401
                    return ("ok", "Databricks Connect available")
                except ImportError:
                    return ("warning", "databricks-connect not installed (pip install 'dvt-core[databricks]')")

            elif platform == SparkPlatform.LOCAL:
                # Check PySpark availability
                try:
                    import pyspark  # noqa: F401
                    version = pyspark.__version__
                    return ("ok", f"PySpark {version} available")
                except ImportError:
                    return ("error", "PySpark not installed")

            elif platform == SparkPlatform.EMR:
                required = ["master"]
                missing = [k for k in required if k not in cluster.config]
                if missing:
                    return ("error", f"Missing config: {', '.join(missing)}")
                return ("ok", "EMR configuration valid")

            elif platform == SparkPlatform.DATAPROC:
                required = ["project", "region", "cluster"]
                missing = [k for k in required if k not in cluster.config]
                if missing:
                    return ("error", f"Missing config: {', '.join(missing)}")
                return ("ok", "Dataproc configuration valid")

            else:
                # External/generic Spark cluster
                if "master" in cluster.config:
                    return ("ok", f"External cluster at {cluster.config['master']}")
                return ("ok", "Configuration valid")

        return ("ok", "Configuration valid")

    def edit_config(self) -> bool:
        """
        Open computes.yml in user's preferred editor.

        Uses EDITOR environment variable, falls back to common editors.

        :returns: True if editor launched successfully
        """
        # Ensure config exists with full template
        config_path = self.registry.ensure_config_exists()

        # If file doesn't have full samples, write the template
        with open(config_path, "r") as f:
            content = f.read()
        if "DATABRICKS" not in content:
            # Write full template to get all the samples
            with open(config_path, "w") as f:
                f.write(DEFAULT_COMPUTES_YAML)

        print(f"Opening: {config_path}")
        print("")
        print("After editing, run 'dvt compute validate' to check syntax.")
        print("")

        # Get editor from environment or use defaults
        editor = os.environ.get("EDITOR")
        if not editor:
            editor = os.environ.get("VISUAL")
        if not editor:
            # Try common editors
            for ed in ["code", "nano", "vim", "vi", "notepad"]:
                try:
                    subprocess.run(["which", ed], capture_output=True, check=True)
                    editor = ed
                    break
                except (subprocess.CalledProcessError, FileNotFoundError):
                    continue

        if not editor:
            print(f"No editor found. Please open manually: {config_path}")
            return False

        try:
            # Handle VS Code specially (--wait flag)
            if editor in ("code", "code-insiders"):
                subprocess.run([editor, "--wait", str(config_path)])
            else:
                subprocess.run([editor, str(config_path)])

            # Reload and validate after edit
            print("\nValidating changes...")
            return self.validate_config()

        except Exception as e:
            print(f"Error opening editor: {e}", file=sys.stderr)
            print(f"Please open manually: {config_path}")
            return False

    def validate_config(self) -> bool:
        """
        Validate computes.yml syntax and configuration.

        :returns: True if configuration is valid
        """
        config_path = self.registry.get_config_path()

        if not config_path.exists():
            print(f"✗ Config file not found: {config_path}")
            print("\nRun 'dvt compute edit' to create one.")
            return False

        print(f"Validating: {config_path}")
        print("")

        try:
            # Try to load the YAML
            import yaml
            with open(config_path, "r") as f:
                data = yaml.safe_load(f)

            if not data:
                print("✗ Config file is empty")
                return False

            errors = []
            warnings = []

            # Check target_compute
            target = data.get("target_compute")
            if not target:
                errors.append("Missing 'target_compute' field")

            # Check computes section
            computes = data.get("computes", {})
            if not computes:
                errors.append("No compute engines defined in 'computes' section")
            else:
                # Validate each compute
                for name, config in computes.items():
                    if config is None:
                        continue  # Skip commented-out entries

                    if not isinstance(config, dict):
                        errors.append(f"Compute '{name}': invalid configuration (expected dict)")
                        continue

                    # Check type
                    compute_type = config.get("type")
                    if not compute_type:
                        errors.append(f"Compute '{name}': missing 'type' field")
                    elif compute_type not in ("spark",):
                        warnings.append(f"Compute '{name}': unknown type '{compute_type}' (only 'spark' supported)")

                    # Check config section
                    if "config" not in config:
                        warnings.append(f"Compute '{name}': no 'config' section (will use defaults)")

                # Check target_compute references valid engine
                if target and target not in computes:
                    errors.append(f"target_compute '{target}' not found in computes section")

            # Print results
            if errors:
                print("Errors:")
                for err in errors:
                    print(f"  ✗ {err}")
                print("")

            if warnings:
                print("Warnings:")
                for warn in warnings:
                    print(f"  ⚠ {warn}")
                print("")

            if not errors and not warnings:
                print("✓ Configuration is valid")
                print(f"  Target compute: {target}")
                print(f"  Engines defined: {len([c for c in computes.values() if c])}")
                return True

            if not errors:
                print("✓ Configuration is valid (with warnings)")
                return True

            return False

        except yaml.YAMLError as e:
            print(f"✗ YAML syntax error:")
            print(f"  {e}")
            return False

        except Exception as e:
            print(f"✗ Validation failed: {e}")
            return False
