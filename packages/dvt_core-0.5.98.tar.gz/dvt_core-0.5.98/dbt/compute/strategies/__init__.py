"""
Spark Connection Strategies

This module provides different strategies for connecting to Spark clusters.
Uses the strategy pattern for flexible platform support.

v0.5.98: Added EMRStrategy, DataprocStrategy, and StandaloneStrategy.
"""

from dbt.compute.strategies.base import BaseConnectionStrategy
from dbt.compute.strategies.local import LocalStrategy

# Strategies are imported lazily to avoid import errors when
# optional dependencies are not installed


def get_databricks_strategy():
    """
    Lazily import and return DatabricksStrategy.

    This function allows importing DatabricksStrategy only when needed,
    avoiding import errors when databricks-connect is not installed or
    is incompatible with the installed PySpark version.
    """
    from dbt.compute.strategies.databricks import DatabricksStrategy
    return DatabricksStrategy


def get_emr_strategy():
    """
    Lazily import and return EMRStrategy.

    :returns: EMRStrategy class
    """
    from dbt.compute.strategies.emr import EMRStrategy
    return EMRStrategy


def get_dataproc_strategy():
    """
    Lazily import and return DataprocStrategy.

    :returns: DataprocStrategy class
    """
    from dbt.compute.strategies.dataproc import DataprocStrategy
    return DataprocStrategy


def get_standalone_strategy():
    """
    Lazily import and return StandaloneStrategy.

    :returns: StandaloneStrategy class
    """
    from dbt.compute.strategies.standalone import StandaloneStrategy
    return StandaloneStrategy


__all__ = [
    "BaseConnectionStrategy",
    "LocalStrategy",
    "get_databricks_strategy",
    "get_emr_strategy",
    "get_dataproc_strategy",
    "get_standalone_strategy",
]
