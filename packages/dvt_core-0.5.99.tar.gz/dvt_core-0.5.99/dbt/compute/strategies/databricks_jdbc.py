"""
Databricks JDBC Connection Strategy

Provides connection to Databricks SQL Warehouses via JDBC using local PySpark.
This is the recommended approach for SQL Warehouses - no extra packages needed!

v0.5.99: Created for SQL Warehouse support using JDBC.
         - Uses local PySpark with Databricks JDBC driver (Maven)
         - Works with Java 17+ (uses driver 2.6.32, avoids Arrow bug in 2.6.36)
         - No need for databricks-connect or databricks-sql-connector
"""

from typing import Any, Dict, Optional, Set, Tuple

from dbt.compute.strategies.base import BaseConnectionStrategy
from dbt_common.exceptions import DbtRuntimeError

try:
    from pyspark.sql import SparkSession

    PYSPARK_AVAILABLE = True
except ImportError:
    PYSPARK_AVAILABLE = False
    SparkSession = None


# Databricks JDBC driver version - 2.6.32 works with Java 17+/24
# Version 2.6.36 has Arrow deserialization bug with Java 24
DATABRICKS_JDBC_VERSION = "2.6.32"


class DatabricksJDBCStrategy(BaseConnectionStrategy):
    """
    Databricks SQL Warehouse connection strategy using JDBC.

    Uses local PySpark with Databricks JDBC driver for reliable SQL Warehouse connectivity.
    No additional packages needed - just PySpark!

    Configuration:
    {
        "host": "https://dbc-xxxxx.cloud.databricks.com",  # or without https://
        "token": "dapi...",
        "http_path": "/sql/1.0/warehouses/abc123def456"
    }

    Cost Estimation:
    - SQL warehouses: $0.22/DBU (typical: 2 DBU/hr = $0.44/hr)
    """

    def __init__(self, config: Dict[str, Any], app_name: str = "DVT"):
        """
        Initialize DatabricksJDBCStrategy.

        :param config: Configuration dictionary with host, token, http_path
        :param app_name: Application name for Spark session
        """
        super().__init__(config, app_name)
        self._spark = None

    def validate_config(self) -> None:
        """
        Validate SQL Warehouse JDBC configuration.

        Required fields:
        - host: Databricks workspace URL
        - token: Personal access token
        - http_path: SQL Warehouse HTTP path

        :raises DbtRuntimeError: If configuration is invalid
        """
        if not isinstance(self.config, dict):
            raise DbtRuntimeError(
                f"Databricks config must be a dictionary, got {type(self.config)}"
            )

        required_fields = ["host", "token", "http_path"]
        missing = [f for f in required_fields if f not in self.config]
        if missing:
            raise DbtRuntimeError(
                f"Databricks SQL Warehouse config missing required fields: {', '.join(missing)}"
            )

        # Validate http_path format
        http_path = self.config["http_path"]
        if not http_path.startswith("/sql/"):
            raise DbtRuntimeError(
                f"http_path must start with '/sql/', got: {http_path}"
            )

    def _get_hostname(self) -> str:
        """Extract hostname from host config (remove https:// if present)."""
        host = self.config["host"]
        if host.startswith("https://"):
            host = host[8:]
        if host.startswith("http://"):
            host = host[7:]
        return host.rstrip("/")

    def _get_jdbc_url(self) -> str:
        """Build JDBC URL for Databricks SQL Warehouse."""
        hostname = self._get_hostname()
        http_path = self.config["http_path"]

        # JDBC URL format for Databricks SQL Warehouse
        # EnableArrow=0 avoids Java 24 Arrow deserialization bug
        return (
            f"jdbc:databricks://{hostname}:443/default;"
            f"transportMode=http;ssl=1;httpPath={http_path};EnableArrow=0"
        )

    def get_spark_session(self, adapter_types: Optional[Set[str]] = None) -> SparkSession:
        """
        Get or create a local Spark session with Databricks JDBC driver.

        v0.5.99: Now includes JDBC drivers for source adapters (not just Databricks).

        :param adapter_types: Set of source adapter types that need JDBC drivers
        :returns: SparkSession with all required JDBC drivers loaded
        :raises DbtRuntimeError: If Spark is not available
        """
        if not PYSPARK_AVAILABLE:
            raise DbtRuntimeError(
                "PySpark is not available. Install it with: pip install pyspark"
            )

        if self._spark is None:
            try:
                # Build list of JDBC packages: Databricks driver + source adapters
                packages = [f"com.databricks:databricks-jdbc:{DATABRICKS_JDBC_VERSION}"]

                # Add JDBC drivers for source adapter types
                if adapter_types:
                    from dbt.compute.jar_provisioning import RemoteJARProvisioning
                    provisioning = RemoteJARProvisioning()
                    source_packages = provisioning.get_maven_coordinates(adapter_types)
                    packages.extend(source_packages)

                self._spark = (
                    SparkSession.builder
                    .appName(f"{self.app_name}-Databricks-JDBC")
                    .config("spark.jars.packages", ",".join(packages))
                    .config("spark.driver.memory", "2g")
                    .config("spark.ui.enabled", "false")
                    .master("local[*]")
                    .getOrCreate()
                )
            except Exception as e:
                raise DbtRuntimeError(
                    f"Failed to create Spark session: {e}"
                ) from e

        return self._spark

    def read_table(self, table: str) -> "DataFrame":
        """
        Read a table from Databricks SQL Warehouse via JDBC.

        :param table: Table name or subquery like "(SELECT * FROM foo) t"
        :returns: Spark DataFrame with results
        :raises DbtRuntimeError: If query fails
        """
        spark = self.get_spark_session()

        try:
            df = (
                spark.read
                .format("jdbc")
                .option("url", self._get_jdbc_url())
                .option("dbtable", table)
                .option("user", "token")
                .option("password", self.config["token"])
                .option("driver", "com.databricks.client.jdbc.Driver")
                .load()
            )
            return df

        except Exception as e:
            raise DbtRuntimeError(
                f"Failed to read from Databricks SQL Warehouse: {e}"
            ) from e

    def close(self, spark: Optional[SparkSession] = None) -> None:
        """
        Clean up Spark session.

        :param spark: SparkSession to close (optional)
        """
        if self._spark:
            try:
                self._spark.stop()
            except Exception:
                pass
            self._spark = None

    def test_connectivity(self) -> Tuple[bool, str]:
        """
        Test connectivity to Databricks SQL Warehouse via JDBC.

        :returns: Tuple of (success, message)
        """
        if not PYSPARK_AVAILABLE:
            return (False, "PySpark not installed")

        try:
            spark = self.get_spark_session()

            # Test query via JDBC
            df = (
                spark.read
                .format("jdbc")
                .option("url", self._get_jdbc_url())
                .option("dbtable", "(SELECT 1 AS test) t")
                .option("user", "token")
                .option("password", self.config["token"])
                .option("driver", "com.databricks.client.jdbc.Driver")
                .load()
            )

            result = df.collect()
            if result and result[0][0] == 1:
                return (True, "SQL Warehouse JDBC connection successful")
            return (False, "Query returned unexpected result")

        except Exception as e:
            error_msg = str(e).lower()
            if "unauthorized" in error_msg or "authentication" in error_msg:
                return (False, f"Authentication failed: {e}")
            elif "timeout" in error_msg:
                return (False, f"Connection timeout: {e}")
            else:
                return (False, f"JDBC connection failed: {e}")

    def estimate_cost(self, duration_minutes: float) -> float:
        """
        Estimate cost for SQL Warehouse execution.

        SQL Warehouses: ~$0.44/hour (2 DBU @ $0.22/DBU)

        :param duration_minutes: Estimated query duration in minutes
        :returns: Estimated cost in USD
        """
        dbu_per_hour = 2.0  # Typical SQL Warehouse
        cost_per_dbu = 0.22  # SQL Warehouse pricing

        hours = duration_minutes / 60.0
        total_dbu = dbu_per_hour * hours
        cost_usd = total_dbu * cost_per_dbu

        return round(cost_usd, 2)

    def get_platform_name(self) -> str:
        """Get platform name."""
        return "databricks-sql-warehouse"

    def get_cluster_info(self) -> Dict[str, Any]:
        """Get information about the SQL Warehouse."""
        return {
            "platform": "databricks-sql-warehouse",
            "host": self._get_hostname(),
            "http_path": self.config.get("http_path", ""),
            "cluster_type": "sql_warehouse",
            "connection_method": "jdbc",
        }
