import sys


assert sys.version_info >= (3, 10), "Use Python 3.10 or newer"
