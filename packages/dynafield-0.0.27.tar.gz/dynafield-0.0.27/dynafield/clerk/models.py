from pydantic import BaseModel

class TokenUser(BaseModel):
    id: str | None = None
    tenantId: str | None = None
    tenantRole: str | None = None
    firstName: str | None = None
    lastName: str | None = None
    email: str | None = None
    database: str | None = None
