import logging
from typing import Optional, Any, Dict, cast

from fastapi import Request, HTTPException

from dynafield import config
from dynafield.clerk.models import TokenUser
from dynafield.clerk.production_auth import get_current_user_from_request

logger = logging.getLogger(__name__)


_default_service_user = {
    'id': config.DEFAULT_TENANT_ID,
    'tenantId': config.DEFAULT_TENANT_ID,
    'database': config.DEFAULT_TENANT_DATABASE_ID
}

def get_user_from_context(context: Dict[str, Any], tenant_required: bool = True) -> TokenUser:
    user_data: Optional[Dict[str, Any]] = context.get("user", None)
    if user_data is None:
        raise HTTPException(status_code=401, detail="Unauthorized: Not valid user")

    user = TokenUser(
        **{
            'id': user_data.get('id'),
            'tenantId': user_data.get('tenantId'),
            'tenantRole': user_data.get('tenantRole'),
            'firstName': user_data.get('firstName'),
            'lastName': user_data.get('lastName'),
            'email': user_data.get('email'),
            'database': config.DEFAULT_TENANT_DATABASE_ID
        }
    )
    if user.id is None:
        raise HTTPException(status_code=401, detail="Unauthorized: Not valid user")

    if tenant_required and (user.tenantId is None):
        raise HTTPException(status_code=401, detail="Unauthorized: No tenant context")

    return user


async def playground_or_introspection(request: Request) -> bool:
    # Allow access to playground without auth
    if request.method in ["GET"]:
        return True

    if request.method == "POST":
        try:
            body = await request.json()
            operation_name = body.get("operationName", "")
            if operation_name == "IntrospectionQuery":
                return True
        except Exception as e:
            logger.debug(e)
            pass  # Ignore JSON parsing errors for auth purposes

    return False

async def get_auth_context(request: Request) -> Dict[str, Any]:
    """
    Lightweight dependency that only returns tenancy context
    """
    is_playground = await playground_or_introspection(request)
    if is_playground:
        return {"user": None}  # Allow playground access

    user_data = await get_current_user_from_request(request)

    if config.AUTH_DISABLED and user_data is None:
        # If auth is disabled and no user data, return a default user
        return {
            "user": {
                "id": config.DEFAULT_TENANT_ID,
                "tenantId": config.DEFAULT_TENANT_ID,
                "database": config.DEFAULT_TENANT_DATABASE_ID,
            }
        }

    if user_data is None:
        raise HTTPException(status_code=401, detail="Unauthorized: No valid user data")

    user_context = {"user": user_data}
    return cast(Dict[str, Any], user_context)