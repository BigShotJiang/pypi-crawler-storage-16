import logging
from typing import Optional, Any, Dict, cast

from clerk_backend_api import AuthenticateRequestOptions
from clerk_backend_api import authenticate_request
from clerk_backend_api.security import AuthStatus
from fastapi import Request, HTTPException
from pydantic import BaseModel

from dynafield import config

logger = logging.getLogger(__name__)


class TokenUser(BaseModel):
    id: str | None = None
    tenantId: str | None = None
    tenantRole: str | None = None
    firstName: str | None = None
    lastName: str | None = None
    email: str | None = None
    database: str | None = config.DEFAULT_TENANT_DATABASE_ID


_default_service_user = {
    'id': config.DEFAULT_TENANT_ID,
    'tenantId': config.DEFAULT_TENANT_ID,
    'database': config.DEFAULT_TENANT_DATABASE_ID
}


def get_user_from_context(context: Dict[str, Any], tenant_required: bool = True) -> TokenUser:
    user_data: Optional[Dict[str, Any]] = context.get("user", None)
    if user_data is None:
        raise HTTPException(status_code=401, detail="Unauthorized: Not valid user")

    user = TokenUser(
        **{
            'id': user_data.get('id'),
            'tenantId': user_data.get('tenantId'),
            'tenantRole': user_data.get('tenantRole'),
            'firstName': user_data.get('firstName'),
            'lastName': user_data.get('lastName'),
            'email': user_data.get('email'),
            'database': config.DEFAULT_TENANT_DATABASE_ID
        }
    )
    if user.id is None:
        raise HTTPException(status_code=401, detail="Unauthorized: Not valid user")

    if tenant_required and (user.tenantId is None):
        raise HTTPException(status_code=401, detail="Unauthorized: No tenant context")

    return user


async def playground_or_introspection(request: Request) -> bool:
    # Allow access to playground without auth
    if request.method in ["GET"]:
        return True

    if request.method == "POST":
        try:
            body = await request.json()
            operation_name = body.get("operationName", "")
            if operation_name == "IntrospectionQuery":
                return True
        except Exception as e:
            logger.debug(e)
            pass  # Ignore JSON parsing errors for auth purposes

    return False

async def get_auth_context(request: Request) -> Dict[str, Any]:
    """
    Lightweight dependency that only returns tenancy context
    """
    is_playground = await playground_or_introspection(request)
    if is_playground:
        return {"user": None}  # Allow playground access

    if config.AUTH_DISABLED:
        # If auth is disabled return a default user
        return { "user": _default_service_user }

    options = AuthenticateRequestOptions(
        secret_key=config.CLERK_SECRET_KEY,
        jwt_key=config.CLERK_JWKS_PUBLIC_KEY
    )
    request_state = authenticate_request(request, options)
    if request_state.status != AuthStatus.SIGNED_IN:
        raise HTTPException(status_code=401, detail=request_state.reason.value)

    user = get_token_user_from_decoded_token(request_state.payload)
    if user is None:
        raise HTTPException(status_code=401, detail="Unauthorized: No valid user data")

    user_context = {"user": user.model_dump(mode='json')}
    return cast(Dict[str, Any], user_context)


def get_token_user_from_decoded_token(payload: Dict[str, Any]) -> TokenUser:
    user_id = payload.get("sub")
    org_id = payload.get("org_id")
    org_role: str | None = payload.get("org_role", None)
    if org_role is not None:
        org_role = org_role.replace('org:', '')
    email = payload.get("email")

    user_data = {
        "id": user_id,
        "tenantId": org_id,
        "tenantRole": org_role,
        "email": email,
        "firstName": payload.get("first_name", ""),
        "lastName": payload.get("last_name", ""),
        "username": payload.get("username", ""),
        "token_issued_at": payload.get("iat"),
        "token_expires_at": payload.get("exp"),
    }
    return TokenUser(**user_data)
