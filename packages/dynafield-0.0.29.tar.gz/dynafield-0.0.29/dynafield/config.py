import os

from dotenv import load_dotenv

if os.path.isfile("private.env"):
    load_dotenv("private.env")
if os.path.isfile(".env"):
    load_dotenv(".env")

PRODUCT_ID = os.environ.get("PRODUCT_ID", "dynafield")
DEFAULT_TENANT_ID = os.environ.get("DEFAULT_TENANT_ID", PRODUCT_ID)
DEFAULT_TENANT_DATABASE_ID = os.environ.get("DEFAULT_TENANT_DATABASE_ID", f"tenant-{PRODUCT_ID}-{DEFAULT_TENANT_ID}")

# Auth settings
AUTH_DISABLED = bool(os.environ.get("AUTH_DISABLED", False))
CLERK_SECRET_KEY = os.environ.get("CLERK_SECRET_KEY", "")
CLERK_JWKS_PUBLIC_KEY = os.environ.get("CLERK_JWKS_URL", "jwks_cache")

# Database Settings
DATABASE_TABLE_OWNER_USER = os.environ.get("DATABASE_TABLE_OWNER_USER", "admin")
DATABASE_TABLE_OWNER_PASSWORD = os.environ.get("DATABASE_TABLE_OWNER_PASSWORD", "admin")
DATABASE_SCHEMA_USER = os.environ.get("DATABASE_SCHEMA_USER", "admin")
DATABASE_SCHEMA_USER_PASSWORD = os.environ.get("DATABASE_SCHEMA_USER_PASSWORD", "admin")
DATABASE_HOST = os.getenv('DATABASE_HOST', 'localhost')
DATABASE_PORT = int(os.getenv('DATABASE_PORT', '5433'))
DATABASE_SCHEMA = os.environ.get("DATABASE_SCHEMA", "user_service")  # Default to service name
