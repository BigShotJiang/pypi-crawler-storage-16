import base64

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.backends import default_backend


def generate_keypair(service_name: str):
    """Generate RSA keypair for a service"""
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=3072,
        backend=default_backend()
    )

    public_key = private_key.public_key()

    # Serialize private key
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    ).decode()

    # Serialize public key
    public_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    ).decode()

    # Save to files
    with open(f"{service_name}-private.pem", "w+") as f:
        f.write(private_pem)

    with open(f"{service_name}-public.pem", "w+") as f:
        f.write(public_pem)

    print(f"Generated keys for {service_name}")
    print(public_pem)

    return private_pem, public_pem


def generate_key_pair_and_encode(service_name: str):
    private_pem, public_pem = generate_keypair(service_name)
    private_b64 = base64.b64encode(private_pem.encode()).decode()
    public_b64 = base64.b64encode(public_pem.encode()).decode()

    print(f"\n=== {service_name.upper()} ===")
    print(f"\nPRIVATE_KEY (base64):")
    print(private_b64)

    print(f"\nPUBLIC_KEY (base64):")
    print(public_b64)

    # Also show how to use in .env file
    print(f"\n.env/.env.example entry:")
    print(f"{service_name.upper()}_PRIVATE_KEY={private_b64}")
    print(f"{service_name.upper()}_PUBLIC_KEY={public_b64}")


if __name__ == "__main__":
    generate_key_pair_and_encode("service_A")