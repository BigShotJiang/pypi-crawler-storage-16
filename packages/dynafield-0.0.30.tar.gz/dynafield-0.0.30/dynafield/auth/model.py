from pydantic import BaseModel

from dynafield import config


class TokenUser(BaseModel):
    id: str | None = None
    tenantId: str | None = None
    tenantRole: str | None = None
    firstName: str | None = None
    lastName: str | None = None
    email: str | None = None
    database: str | None = config.DEFAULT_TENANT_DATABASE_ID


default_service_user = {
    'id': config.DEFAULT_TENANT_ID,
    'tenantId': config.DEFAULT_TENANT_ID,
    'database': config.DEFAULT_TENANT_DATABASE_ID
}