import base64
import os
import time
from typing import Dict, Any, Optional

import jwt
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend

from fastapi import Request, HTTPException

from dynafield import config
from dynafield.auth.model import TokenUser


class ServiceAuth:
    def __init__(self) -> None:
        self.service_id = config.INTERNAL_SERVICE_ID

        b64_private = config.RSA_PRIVATE_KEY
        if not b64_private:
            raise ValueError("RSA_PRIVATE_KEY environment variable required")
        try:
            pem_private = base64.b64decode(b64_private).decode()
        except:
                raise ValueError("Invalid base64 private key")

        self.private_key = serialization.load_pem_private_key(
            pem_private.encode(),
            password=None,
            backend=default_backend()
        )

        # Cache for other services' public keys
        self._public_keys = {}

    def create_token(
            self,
            audience: str = None,
            ttl: int = 300,
            custom_claims: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Create a self-signed token for calling other services.
        No API call needed - just sign with our own private key.
        """
        payload = {
            "iss": self.service_id,  # Who created it (us)
            "sub": self.service_id,  # Who it's for (us)
            "aud": audience or "*",  # Who should accept it
            "iat": int(time.time()),  # Issued now
            "exp": int(time.time()) + ttl,  # Expires in ttl seconds
            "jti": os.urandom(8).hex(),  # Unique ID
        }

        if custom_claims:
            for key in custom_claims:
                if key in ["iss", "sub", "aud", "exp", "iat", "nbf", "jti"]:
                    raise ValueError(f"Cannot override standard claim: {key}")
            payload.update(custom_claims)

        # Sign with OUR private key
        return jwt.encode(
            payload,
            self.private_key,
            algorithm="RS256",
            headers={"kid": self.service_id}
        )

    def validate_internal_request(self, request: Request) -> TokenUser:
        # Get auth header
        auth_header = request.headers.get("Authorization")
        if not auth_header:
            raise HTTPException(status_code=401, detail="Missing authorization")
        try:
            if auth_header.startswith("Bearer "):
                token = auth_header[7:]
                claims = self.verify_token(token)
                user_data = {
                    "id": claims["iss"],
                    "tenantId": claims.get("org_id", None),
                    "tenantRole": claims.get("org_role", None),
                    "username": claims["iss"],
                    "token_issued_at": claims.get("iat"),
                    "token_expires_at": claims.get("exp"),
                }
                return TokenUser(**user_data)
            else:
                raise HTTPException(status_code=401, detail="Unauthorized")

        except Exception as e:
            raise HTTPException(status_code=401, detail=f"Authentication failed: {str(e)}")


    def verify_token(self, token: str, expected_issuer: str = None) -> dict:
        """
        Verify a token from another service.
        Uses the issuer's public key from our config.
        """
        try:
            # First, decode without verification to get issuer
            unverified = jwt.decode(
                token,
                options={"verify_signature": False}
            )

            issuer = unverified.get("iss")
            if not issuer:
                raise ValueError("Token has no issuer")

            # If we expect a specific issuer, verify
            if expected_issuer and issuer != expected_issuer:
                raise ValueError(f"Expected issuer {expected_issuer}, got {issuer}")

            # Get public key for this issuer
            public_key = self._get_public_key(issuer)
            if not public_key:
                raise ValueError(f"Unknown service: {issuer}")

            # Verify signature with issuer's public key
            return jwt.decode(
                token,
                public_key,
                algorithms=["RS256"],
                audience=["*", self.service_id],  # Accept tokens for us or any
                issuer=issuer
            )

        except jwt.ExpiredSignatureError:
            raise ValueError("Token expired")
        except jwt.InvalidTokenError as e:
            raise ValueError(f"Invalid token: {str(e)}")

    def _get_public_key(self, service_id: str):
        """Get public key for a service"""
        if service_id in self._public_keys:
            return self._public_keys[service_id]

        env_vars_to_try = [
            f"{service_id.upper().replace('-', '_')}_PUBLIC_KEY",
            f"{service_id.upper()}_PUBLIC_KEY",
        ]

        b64_public = None
        for env_var in env_vars_to_try:
            b64_public = os.getenv(env_var)
            if b64_public:
                break

        if not b64_public:
            return None

        try:
            pem_public = base64.b64decode(b64_public).decode()
        except:
            return None

        # Parse and cache
        try:
            public_key = serialization.load_pem_public_key(
                pem_public.encode(),
                backend=default_backend()
            )
            self._public_keys[service_id] = public_key
            return public_key
        except:
            return None

    def get_public_key_pem(self) -> str:
        """Get our public key in PEM format (to share with others)"""
        return self.private_key.public_key().public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        ).decode()