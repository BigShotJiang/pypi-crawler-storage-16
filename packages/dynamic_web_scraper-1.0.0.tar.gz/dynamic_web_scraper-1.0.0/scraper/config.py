# Copyright 2024 Yüksel Coşgun
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json
import os
import sqlite3

import requests

# Get the project root directory (parent of scraper directory)
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_FILE = os.path.join(PROJECT_ROOT, "config.json")
DB_FILE = os.path.join(PROJECT_ROOT, "scraper_data.db")


def load_config():
    """
    Konfigürasyon ayarlarını dosyadan okur.

    Returns:
        dict: Konfigürasyon ayarlarını içeren sözlük.
    """
    if not os.path.exists(CONFIG_FILE):
        raise FileNotFoundError(f"Config dosyası bulunamadı: {CONFIG_FILE}")

    with open(CONFIG_FILE, "r") as f:
        config = json.load(f)

    # Debug logging
    print(f"Loaded config with {len(config.get('user_agents', []))} user agents")
    print(
        f"User agents: {config.get('user_agents', [])[:2] if config.get('user_agents') else 'None'}"
    )

    # Proxy kullanımı ayarını kontrol et
    if "use_proxy" in config and config["use_proxy"]:
        if not config.get("proxies"):
            raise ValueError("Proxy kullanımı seçildi ancak proxy listesi boş!")

    return config


def save_config(config):
    """
    Güncellenmiş konfigürasyonu dosyaya kaydeder.

    Args:
        config (dict): Güncellenmiş konfigürasyon sözlüğü.
    """
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=4)


def save_data_to_db(data):
    """
    Veriyi SQLite veritabanına kaydeder.

    Args:
        data (list): Kaydedilecek ürün verileri.
    """
    try:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()

        # Eğer tablo yoksa oluştur
        cursor.execute(
            """CREATE TABLE IF NOT EXISTS products
                          (id INTEGER PRIMARY KEY, name TEXT, price TEXT)"""
        )

        for item in data:
            cursor.execute(
                "INSERT INTO products (name, price) VALUES (?, ?)",
                (item["name"], item["price"]),
            )

        conn.commit()
    except sqlite3.Error as e:
        print(f"Veritabanı hatası: {e}")
    finally:
        conn.close()


def send_data_to_api(data, api_endpoint):
    """
    Veriyi API'ye gönderir.

    Args:
        data (list): Gönderilecek ürün verileri.
        api_endpoint (str): API'nin URL'si.
    """
    try:
        response = requests.post(api_endpoint, json=data)
        response.raise_for_status()  # Hata oluşursa bir HTTPError fırlatır
        print("Veri başarıyla API'ye gönderildi.")
    except requests.exceptions.RequestException as e:
        print(f"API isteği başarısız oldu: {e}")
