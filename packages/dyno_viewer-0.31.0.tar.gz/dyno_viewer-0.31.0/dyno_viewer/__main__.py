from dyno_viewer.app import run

__all__ = ["run"]

run()
