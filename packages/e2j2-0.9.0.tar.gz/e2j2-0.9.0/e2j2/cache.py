"""Cache"""
config = {}
last_log_line = ""
log_repeat_log_msg_counter = 1
print_at = 5
increment = 5
