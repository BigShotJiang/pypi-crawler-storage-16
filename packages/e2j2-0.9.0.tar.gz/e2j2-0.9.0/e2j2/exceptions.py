"""Custom exceptions"""


class E2j2Exception(Exception):
    pass
