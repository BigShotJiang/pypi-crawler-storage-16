def parse(value):
    return value
