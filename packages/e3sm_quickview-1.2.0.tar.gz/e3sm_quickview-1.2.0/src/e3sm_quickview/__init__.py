"""QuickView: Visual Analysis for E3SM Atmosphere Data."""

__version__ = "1.2.0"
__author__ = "Kitware Inc."
__license__ = "Apache-2.0"
