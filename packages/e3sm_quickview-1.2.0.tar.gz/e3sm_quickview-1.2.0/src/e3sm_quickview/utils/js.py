def is_active(name):
    return f"active_tools.includes('{name}')"
