class ProfileDoesNotExistError(KeyError):
    """
    The named profile does not exist
    """
