# assert

## Syntax:
`assert {condition}`
## Examples:
`assert Value is 5`
## Description:
Tests the condition and throws an exception if it is not true.

Next: [begin](begin.md)  
Prev: [append](append.md)

[Back](../../README.md)
