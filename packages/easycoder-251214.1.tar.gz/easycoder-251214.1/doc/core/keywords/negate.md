# negate

## Syntax:
`negate {variable}`
## Examples:
`negate N`
## Description:
Negates a numeric variable (multiplies its value by -1).

Next: [on](on.md)  
Prev: [multiply](multiply.md)

[Back](../../README.md)
