# args

## Syntax:
`[the] args`

## Examples:
`print the args`

## Description:
Gets the command-line arguments as a JSON-formatted array. 

Next: [cos](cos.md)  
Prev: [arg](arg.md)

[Back](../../README.md)
