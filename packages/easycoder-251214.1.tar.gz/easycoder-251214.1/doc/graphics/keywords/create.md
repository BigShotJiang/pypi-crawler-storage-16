## create

## Syntax:
`create window {parameters}`

## Examples:
``create window title `Demo` at 300 300 size 640 480 fill color 255 255 200` ``

## Description:
Creates a window with the given parameters. There can only be one of these in a program.


Next: [dialog](dialog.md)  
Prev: [combobox](combobox.md)

[Back](../../README.md)
