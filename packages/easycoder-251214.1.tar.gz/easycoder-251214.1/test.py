#!/bin/python3

from easycoder import Program

Program('scripts/tests.ecs').start()
