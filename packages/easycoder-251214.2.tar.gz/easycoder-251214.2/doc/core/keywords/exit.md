# exit

## Syntax:
`exit`

## Examples:
`exit`

## Description:
Terminate the program.

Next: [file](file.md)  
Prev: [download](download.md)

[Back](../../README.md)
