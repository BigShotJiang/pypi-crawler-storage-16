# has property

## Syntax:
`{value} has property {property}`

## Examples:
``if Users has property `Andrew` stop` ``

## Description:
Tests if the value - usually a variable - has the named property as one of its attributes.

Next: [includes](includes.md)  
Prev: [greater](greater.md)

[Back](../../README.md)
