# toggle

## Syntax:
`toggle {variable}`

## Example:
`toggle Flag`

## Description:
Toggle - change from `true` to `false` or vice versa - a variable that has been [set](set.md) or [clear](clear.md)ed.

Next: [trim](trim.md)  
Prev: [take](take.md)

[Back](../../README.md)
