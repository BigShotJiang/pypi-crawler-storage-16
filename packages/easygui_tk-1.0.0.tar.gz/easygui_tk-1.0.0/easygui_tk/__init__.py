# easygui_tk/__init__.py

from .core import args
from .core import window
from .core import add_theme
from .core import default_size as default

__version__ = "1.0.0"
