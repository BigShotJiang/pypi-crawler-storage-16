#!/usr/bin/env python
# coding: utf-8
import easypv

def run_apps():
    pass
