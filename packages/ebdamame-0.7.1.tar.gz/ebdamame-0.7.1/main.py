"""
the script to convert EBDs from .docx to SVGs visualizations using both the ebdamame and rebdhuhn libraries
was relocated to https://github.com/Hochfrequenz/ebd_toolchain
"""
