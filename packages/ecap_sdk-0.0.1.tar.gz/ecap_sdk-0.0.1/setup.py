from setuptools import setup, find_packages

setup(
    name="ecap-sdk",
    version="0.0.1",
    author="JamOne-DE",
    author_email="hallo@jamone.de",
    description="Official SDK for the Ethical Crawler Agreement Protocol (ECAP)",
    long_description="This is the placeholder for the upcoming ECAP SDK. Visit https://ecap-protocol.com for more info.",
    long_description_content_type="text/markdown",
    url="https://github.com/jamone-de/ecap",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)