"""EchoGraph CLI - Context Engineering for Claude Code."""

from importlib.metadata import version

__version__ = version("echograph")
