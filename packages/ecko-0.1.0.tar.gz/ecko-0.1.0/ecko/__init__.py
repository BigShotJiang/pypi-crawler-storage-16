"""Ecko - A modern Python web framework.

Flask's simplicity with 2025 expectations.
"""

from .app import Ecko
from .context import context
from .exceptions import (
    BadRequest,
    Forbidden,
    HTTPException,
    InternalServerError,
    MethodNotAllowed,
    NotFound,
    Unauthorized,
    ValidationError,
)
from .openapi import setup_openapi
from .params import Body, Header, Path, Query
from .request import Request
from .response import HTMLResponse, JSONResponse, RedirectResponse, Response
from .websocket import WebSocket, WebSocketDisconnect

__version__ = "0.1.0"

__all__ = [
    # Core
    "Ecko",
    "Request",
    "WebSocket",
    "WebSocketDisconnect",
    "context",
    # Parameter markers
    "Query",
    "Path",
    "Body",
    "Header",
    # Responses
    "Response",
    "JSONResponse",
    "HTMLResponse",
    "RedirectResponse",
    # OpenAPI
    "setup_openapi",
    # Exceptions
    "HTTPException",
    "BadRequest",
    "Unauthorized",
    "Forbidden",
    "NotFound",
    "MethodNotAllowed",
    "ValidationError",
    "InternalServerError",
]
