"""Main application class."""

from __future__ import annotations

import asyncio
import inspect
from typing import Any, Awaitable, Callable

from .context import context
from .exceptions import HTTPException, MethodNotAllowed, NotFound
from .params import extract_params
from .request import Request
from .response import JSONResponse, Response, make_response
from .routing import Router
from .websocket import WebSocket, WebSocketDisconnect


# Type aliases
LifespanHandler = Callable[[], Awaitable[None] | None]
BeforeRequestHandler = Callable[[], Awaitable[Any] | Any]
AfterRequestHandler = Callable[[Response], Awaitable[Response] | Response]
ExceptionHandler = Callable[[Exception], Awaitable[Response] | Response]
Middleware = Callable[[Request, Callable[[], Awaitable[Response]]], Awaitable[Response]]
WebSocketHandler = Callable[[WebSocket], Awaitable[None]]


class Ecko:
    """The main application class.

    Usage:
        app = Ecko()

        @app.get("/")
        def home():
            return {"message": "Hello, World!"}

        @app.websocket("/ws")
        async def websocket_handler(ws: WebSocket):
            await ws.accept()
            async for message in ws:
                await ws.send_text(f"Echo: {message}")

        # Run with: uvicorn app:app
    """

    def __init__(self) -> None:
        self._router = Router()
        self._before_request_handlers: list[BeforeRequestHandler] = []
        self._after_request_handlers: list[AfterRequestHandler] = []
        self._startup_handlers: list[LifespanHandler] = []
        self._shutdown_handlers: list[LifespanHandler] = []
        self._exception_handlers: dict[type[Exception], ExceptionHandler] = {}
        self._middleware: list[Middleware] = []

    # -------------------------------------------------------------------------
    # Route registration decorators
    # -------------------------------------------------------------------------

    def route(
        self, path: str, methods: list[str] | None = None
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        """Register a route for one or more HTTP methods."""
        methods = methods or ["GET"]

        def decorator(handler: Callable[..., Any]) -> Callable[..., Any]:
            for method in methods:
                self._router.add_route(path, method, handler)
            return handler

        return decorator

    def get(self, path: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        """Register a GET route."""
        return self.route(path, ["GET"])

    def post(self, path: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        """Register a POST route."""
        return self.route(path, ["POST"])

    def put(self, path: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        """Register a PUT route."""
        return self.route(path, ["PUT"])

    def patch(self, path: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        """Register a PATCH route."""
        return self.route(path, ["PATCH"])

    def delete(self, path: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        """Register a DELETE route."""
        return self.route(path, ["DELETE"])

    def websocket(self, path: str) -> Callable[[WebSocketHandler], WebSocketHandler]:
        """Register a WebSocket route.

        Usage:
            @app.websocket("/ws")
            async def handle_ws(ws: WebSocket):
                await ws.accept()
                async for message in ws:
                    await ws.send_text(f"Echo: {message}")
        """

        def decorator(handler: WebSocketHandler) -> WebSocketHandler:
            self._router.add_route(path, "WEBSOCKET", handler)
            return handler

        return decorator

    # -------------------------------------------------------------------------
    # Lifecycle hooks
    # -------------------------------------------------------------------------

    def before_request(self, handler: BeforeRequestHandler) -> BeforeRequestHandler:
        """Register a function to run before each request.

        Usage:
            @app.before_request
            async def load_user():
                context.user = await get_user()

        If a before_request handler returns a Response, the request is
        short-circuited and that response is returned immediately.
        """
        self._before_request_handlers.append(handler)
        return handler

    def after_request(self, handler: AfterRequestHandler) -> AfterRequestHandler:
        """Register a function to run after each request.

        Usage:
            @app.after_request
            def add_headers(response):
                response._headers["X-Custom"] = "value"
                return response

        The handler receives the response and must return a response.
        """
        self._after_request_handlers.append(handler)
        return handler

    def on_startup(self, handler: LifespanHandler) -> LifespanHandler:
        """Register a function to run on application startup.

        Usage:
            @app.on_startup
            async def init_db():
                await database.connect()
        """
        self._startup_handlers.append(handler)
        return handler

    def on_shutdown(self, handler: LifespanHandler) -> LifespanHandler:
        """Register a function to run on application shutdown.

        Usage:
            @app.on_shutdown
            async def close_db():
                await database.disconnect()
        """
        self._shutdown_handlers.append(handler)
        return handler

    # -------------------------------------------------------------------------
    # Exception handlers
    # -------------------------------------------------------------------------

    def exception_handler(
        self, exc_class: type[Exception]
    ) -> Callable[[ExceptionHandler], ExceptionHandler]:
        """Register a custom exception handler.

        Usage:
            @app.exception_handler(ValueError)
            def handle_value_error(exc):
                return {"error": str(exc)}, 400
        """

        def decorator(handler: ExceptionHandler) -> ExceptionHandler:
            self._exception_handlers[exc_class] = handler
            return handler

        return decorator

    # -------------------------------------------------------------------------
    # Middleware
    # -------------------------------------------------------------------------

    def use(self, middleware: Middleware) -> None:
        """Add middleware to the application.

        Middleware is a function that receives (request, call_next) and returns a response.

        Usage:
            async def timing_middleware(request, call_next):
                start = time.time()
                response = await call_next()
                response._headers["X-Time"] = str(time.time() - start)
                return response

            app.use(timing_middleware)
        """
        self._middleware.append(middleware)

    # -------------------------------------------------------------------------
    # Request handling
    # -------------------------------------------------------------------------

    async def _run_handler(
        self, handler: Callable[..., Any], *args: Any, **kwargs: Any
    ) -> Any:
        """Run a handler, handling sync vs async."""
        if inspect.iscoroutinefunction(handler):
            return await handler(*args, **kwargs)
        else:
            return await asyncio.to_thread(handler, *args, **kwargs)

    async def _handle_request(
        self, request: Request, path_params: dict[str, str], handler: Callable[..., Any]
    ) -> Response:
        """Call a handler with extracted parameters and convert result to Response."""
        # Extract parameters based on handler signature (async to support body parsing)
        kwargs = await extract_params(handler, request, path_params)

        # Call handler - handle sync vs async
        if inspect.iscoroutinefunction(handler):
            result = await handler(**kwargs)
        else:
            # Run sync handlers in threadpool to avoid blocking
            result = await asyncio.to_thread(handler, **kwargs)

        return make_response(result)

    async def _handle_exception(self, exc: Exception) -> Response:
        """Handle an exception, using custom handlers if registered."""
        # Check for exact match first, then base classes
        for exc_class in type(exc).__mro__:
            if exc_class in self._exception_handlers:
                handler = self._exception_handlers[exc_class]
                result = await self._run_handler(handler, exc)
                return make_response(result)

        # Default handling for HTTPException
        if isinstance(exc, HTTPException):
            return JSONResponse(exc.to_dict(), status=exc.status, headers=exc.headers)

        # Unknown exception - return 500
        return JSONResponse(
            {"error": "Internal Server Error", "detail": str(exc)},
            status=500,
        )

    async def _process_request(self, request: Request) -> Response:
        """Process a request through the full pipeline."""
        # Run before_request handlers
        for handler in self._before_request_handlers:
            result = await self._run_handler(handler)
            if result is not None:
                # Short-circuit: return early response
                return make_response(result)

        # Find and call route handler
        path = request.path
        method = request.method

        match = self._router.find(path, method)

        if match is None:
            # Check if path exists with different method
            for m in ["GET", "POST", "PUT", "PATCH", "DELETE"]:
                if self._router.find(path, m):
                    raise MethodNotAllowed()
            raise NotFound()

        route, path_params = match
        response = await self._handle_request(request, path_params, route.handler)

        # Run after_request handlers
        for handler in self._after_request_handlers:
            response = await self._run_handler(handler, response)

        return response

    # -------------------------------------------------------------------------
    # ASGI interface
    # -------------------------------------------------------------------------

    async def __call__(self, scope: dict[str, Any], receive: Any, send: Any) -> None:
        """ASGI application interface."""
        if scope["type"] == "lifespan":
            await self._handle_lifespan(scope, receive, send)
            return

        if scope["type"] == "websocket":
            await self._handle_websocket(scope, receive, send)
            return

        if scope["type"] != "http":
            return

        await self._handle_http(scope, receive, send)

    async def _handle_lifespan(
        self, scope: dict[str, Any], receive: Any, send: Any
    ) -> None:
        """Handle ASGI lifespan events."""
        while True:
            message = await receive()
            if message["type"] == "lifespan.startup":
                try:
                    for handler in self._startup_handlers:
                        await self._run_handler(handler)
                    await send({"type": "lifespan.startup.complete"})
                except Exception as exc:
                    await send({"type": "lifespan.startup.failed", "message": str(exc)})
                    return

            elif message["type"] == "lifespan.shutdown":
                try:
                    for handler in self._shutdown_handlers:
                        await self._run_handler(handler)
                except Exception:
                    pass  # Best effort cleanup
                await send({"type": "lifespan.shutdown.complete"})
                return

    async def _handle_websocket(
        self, scope: dict[str, Any], receive: Any, send: Any
    ) -> None:
        """Handle a WebSocket connection."""
        path = scope["path"]

        # Find matching WebSocket route
        match = self._router.find(path, "WEBSOCKET")

        if match is None:
            # No WebSocket handler for this path - close connection
            await send({"type": "websocket.close", "code": 4004})
            return

        route, path_params = match

        # Wait for client to initiate connection
        message = await receive()
        if message["type"] != "websocket.connect":
            return

        # Create WebSocket instance
        scope["path_params"] = path_params
        ws = WebSocket(scope, receive, send)

        try:
            # Call the handler
            await route.handler(ws)
        except WebSocketDisconnect:
            pass  # Normal disconnection
        except Exception as exc:
            # Try to close with error code
            try:
                await ws.close(code=1011, reason=str(exc)[:123])
            except Exception:
                pass

    async def _handle_http(
        self, scope: dict[str, Any], receive: Any, send: Any
    ) -> None:
        """Handle an HTTP request."""
        request = Request(scope, receive)

        # Initialize request context
        token = context._init(request)

        try:
            # Build middleware chain
            async def call_next() -> Response:
                return await self._process_request(request)

            handler = call_next

            # Wrap with middleware (in reverse order so first added runs first)
            for middleware in reversed(self._middleware):
                # Capture current handler in closure
                prev_handler = handler

                async def make_handler(
                    mw: Middleware, prev: Callable[[], Awaitable[Response]]
                ) -> Response:
                    return await mw(request, prev)

                handler = lambda mw=middleware, prev=prev_handler: make_handler(
                    mw, prev
                )

            response = await handler()

        except Exception as exc:
            response = await self._handle_exception(exc)

        finally:
            # Clean up context
            context._cleanup(token)

        await response.send(send)
