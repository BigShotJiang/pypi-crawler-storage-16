"""Ecko CLI - Command line interface for the Ecko framework.

Usage:
    ecko run app:app              # Run with auto-reload
    ecko run app:app --prod       # Run in production mode
    ecko new myproject            # Create new project
    ecko routes app:app           # List all routes
"""

from __future__ import annotations

import argparse
import importlib
import sys
from pathlib import Path


def main() -> int:
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="ecko",
        description="Ecko - A modern Python web framework",
    )
    parser.add_argument(
        "--version",
        action="store_true",
        help="Show version and exit",
    )

    subparsers = parser.add_subparsers(dest="command", help="Commands")

    # Run command
    run_parser = subparsers.add_parser("run", help="Run the application")
    run_parser.add_argument(
        "app",
        help="Application to run (e.g., app:app or mymodule:application)",
    )
    run_parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Host to bind to (default: 127.0.0.1)",
    )
    run_parser.add_argument(
        "--port",
        type=int,
        default=8000,
        help="Port to bind to (default: 8000)",
    )
    run_parser.add_argument(
        "--prod",
        action="store_true",
        help="Run in production mode (no reload)",
    )
    run_parser.add_argument(
        "--workers",
        type=int,
        default=1,
        help="Number of workers (production mode only)",
    )

    # New project command
    new_parser = subparsers.add_parser("new", help="Create a new project")
    new_parser.add_argument("name", help="Project name")
    new_parser.add_argument(
        "--dir",
        default=".",
        help="Directory to create project in",
    )

    # Routes command
    routes_parser = subparsers.add_parser("routes", help="List all routes")
    routes_parser.add_argument(
        "app",
        help="Application to inspect (e.g., app:app)",
    )

    args = parser.parse_args()

    if args.version:
        from ecko import __version__

        print(f"ecko {__version__}")
        return 0

    if args.command == "run":
        return cmd_run(args)
    elif args.command == "new":
        return cmd_new(args)
    elif args.command == "routes":
        return cmd_routes(args)
    else:
        parser.print_help()
        return 0


def cmd_run(args: argparse.Namespace) -> int:
    """Run the application."""
    try:
        import uvicorn
    except ImportError:
        print("Error: uvicorn is required. Install with: pip install uvicorn[standard]")
        return 1

    # Parse app string (module:attribute)
    if ":" not in args.app:
        print(f"Error: Invalid app format '{args.app}'. Use format: module:app")
        return 1

    module_path, app_name = args.app.rsplit(":", 1)

    # Add current directory to path
    if "." not in sys.path:
        sys.path.insert(0, ".")

    reload = not args.prod

    print(
        f"\n  {'🚀' if args.prod else '🔧'} Ecko {'production' if args.prod else 'development'} server"
    )
    print(f"  Running on http://{args.host}:{args.port}")
    if reload:
        print("  Auto-reload enabled")
    print()

    uvicorn.run(
        args.app,
        host=args.host,
        port=args.port,
        reload=reload,
        workers=args.workers if args.prod else 1,
        log_level="info",
    )

    return 0


def cmd_new(args: argparse.Namespace) -> int:
    """Create a new project."""
    project_name = args.name
    base_dir = Path(args.dir).resolve()
    project_dir = base_dir / project_name

    if project_dir.exists():
        print(f"Error: Directory '{project_dir}' already exists")
        return 1

    print(f"Creating new Ecko project: {project_name}")

    # Create project structure
    project_dir.mkdir(parents=True)
    (project_dir / "static").mkdir()
    (project_dir / "templates").mkdir()

    # Create main app file
    app_content = '''"""${project_name} - An Ecko application."""

from ecko import Ecko, context
from ecko.middleware import cors, sessions

app = Ecko()

# Middleware
app.use(cors())
# app.use(sessions(secret="change-me-in-production"))


@app.on_startup
async def startup():
    print("Application starting...")


@app.on_shutdown
async def shutdown():
    print("Application shutting down...")


@app.get("/")
def home():
    return {
        "message": "Welcome to ${project_name}!",
        "docs": "/docs",
    }


@app.get("/health")
def health():
    return {"status": "ok"}


# Add your routes here...


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000, reload=True)
'''.replace(
        "${project_name}", project_name
    )

    (project_dir / "app.py").write_text(app_content)

    # Create pyproject.toml
    pyproject_content = f"""[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "{project_name}"
version = "0.1.0"
description = "An Ecko web application"
requires-python = ">=3.11"
dependencies = [
    "ecko>=0.1.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=8.0",
    "httpx>=0.27",
]
"""

    (project_dir / "pyproject.toml").write_text(pyproject_content)

    # Create .gitignore
    gitignore_content = """__pycache__/
*.py[cod]
*$py.class
.env
.venv/
venv/
*.egg-info/
dist/
build/
.pytest_cache/
"""

    (project_dir / ".gitignore").write_text(gitignore_content)

    # Create README
    readme_content = f"""# {project_name}

A web application built with [Ecko](https://ecko.sh).

## Quick Start

```bash
# Install dependencies
pip install -e .

# Run development server
ecko run app:app

# Or directly with Python
python app.py
```

## Project Structure

```
{project_name}/
├── app.py           # Main application
├── static/          # Static files
├── templates/       # HTML templates (if needed)
└── pyproject.toml   # Project configuration
```

## API Endpoints

- `GET /` - Welcome message
- `GET /health` - Health check
- `GET /docs` - API documentation (if enabled)
"""

    (project_dir / "README.md").write_text(readme_content)

    print(f"✓ Created {project_dir}")
    print()
    print("Next steps:")
    print(f"  cd {project_name}")
    print("  pip install -e .")
    print("  ecko run app:app")
    print()

    return 0


def cmd_routes(args: argparse.Namespace) -> int:
    """List all routes."""
    if ":" not in args.app:
        print(f"Error: Invalid app format '{args.app}'. Use format: module:app")
        return 1

    module_path, app_name = args.app.rsplit(":", 1)

    # Add current directory to path
    if "." not in sys.path:
        sys.path.insert(0, ".")

    try:
        module = importlib.import_module(module_path)
        app = getattr(module, app_name)
    except (ImportError, AttributeError) as e:
        print(f"Error: Could not load '{args.app}': {e}")
        return 1

    print(f"\nRoutes for {args.app}:\n")
    print(f"{'Method':<8} {'Path':<30} {'Handler'}")
    print("-" * 60)

    for route in app._router.routes():
        handler_name = route.handler.__name__
        module_name = route.handler.__module__
        print(f"{route.method:<8} {route.path:<30} {module_name}.{handler_name}")

    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())
