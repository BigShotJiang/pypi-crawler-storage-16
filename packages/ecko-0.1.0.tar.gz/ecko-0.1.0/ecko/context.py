"""Request context using contextvars.

Provides a Flask-like `g` object that's async-safe. Each request gets its own
isolated context that can be accessed from anywhere without passing it around.

Usage:
    from ecko import context

    @app.before_request
    async def load_user():
        context.user = await get_user_from_token(context.request)

    @app.get("/profile")
    def profile():
        return {"name": context.user.name}
"""

from __future__ import annotations

from contextvars import ContextVar, Token
from typing import Any

from .request import Request


class _Context:
    """Request-scoped context object.

    Attributes can be set and accessed freely. Each request gets isolated state.
    Special attributes:
        - request: The current Request object (set automatically)
    """

    __slots__ = ("_data",)

    # ContextVar to hold per-request data
    _context_data: ContextVar[dict[str, Any]] = ContextVar("ecko_context", default=None)

    def __init__(self) -> None:
        # This is a singleton - actual data lives in contextvar
        object.__setattr__(self, "_data", None)

    def _get_data(self) -> dict[str, Any]:
        """Get the current request's context data."""
        data = self._context_data.get()
        if data is None:
            raise RuntimeError(
                "Context accessed outside of request. "
                "Make sure you're accessing context within a request handler."
            )
        return data

    def __getattr__(self, name: str) -> Any:
        data = self._get_data()
        try:
            return data[name]
        except KeyError:
            raise AttributeError(f"Context has no attribute '{name}'")

    def __setattr__(self, name: str, value: Any) -> None:
        if name == "_data":
            object.__setattr__(self, name, value)
            return
        data = self._get_data()
        data[name] = value

    def __delattr__(self, name: str) -> None:
        data = self._get_data()
        try:
            del data[name]
        except KeyError:
            raise AttributeError(f"Context has no attribute '{name}'")

    def __contains__(self, name: str) -> bool:
        data = self._context_data.get()
        if data is None:
            return False
        return name in data

    def get(self, name: str, default: Any = None) -> Any:
        """Get a context value with a default."""
        data = self._context_data.get()
        if data is None:
            return default
        return data.get(name, default)

    def set(self, name: str, value: Any) -> None:
        """Set a context value."""
        setattr(self, name, value)

    def clear(self) -> None:
        """Clear all context data except request."""
        data = self._get_data()
        request = data.get("request")
        data.clear()
        if request is not None:
            data["request"] = request

    @property
    def request(self) -> Request:
        """Get the current request."""
        return self._get_data()["request"]

    def _init(self, request: Request) -> Token[dict[str, Any] | None]:
        """Initialize context for a new request. Returns token for cleanup."""
        return self._context_data.set({"request": request})

    def _cleanup(self, token: Token[dict[str, Any] | None]) -> None:
        """Clean up context after request completes."""
        self._context_data.reset(token)


# Global context instance - import this
context = _Context()
