"""HTTP exceptions with automatic error responses."""

from __future__ import annotations


class HTTPException(Exception):
    """Base HTTP exception that converts to an error response."""

    def __init__(
        self,
        status: int,
        detail: str | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        self.status = status
        self.detail = detail or self._default_detail()
        self.headers = headers or {}
        super().__init__(self.detail)

    def _default_detail(self) -> str:
        return HTTP_STATUS_PHRASES.get(self.status, "Error")

    def to_dict(self) -> dict[str, object]:
        return {"error": self.detail, "status": self.status}


class BadRequest(HTTPException):
    def __init__(
        self, detail: str = "Bad Request", headers: dict[str, str] | None = None
    ):
        super().__init__(400, detail, headers)


class Unauthorized(HTTPException):
    def __init__(
        self, detail: str = "Unauthorized", headers: dict[str, str] | None = None
    ):
        super().__init__(401, detail, headers)


class Forbidden(HTTPException):
    def __init__(
        self, detail: str = "Forbidden", headers: dict[str, str] | None = None
    ):
        super().__init__(403, detail, headers)


class NotFound(HTTPException):
    def __init__(
        self, detail: str = "Not Found", headers: dict[str, str] | None = None
    ):
        super().__init__(404, detail, headers)


class MethodNotAllowed(HTTPException):
    def __init__(
        self, detail: str = "Method Not Allowed", headers: dict[str, str] | None = None
    ):
        super().__init__(405, detail, headers)


class ValidationError(HTTPException):
    """Raised when parameter validation fails."""

    def __init__(self, detail: str, headers: dict[str, str] | None = None):
        super().__init__(422, detail, headers)


class InternalServerError(HTTPException):
    def __init__(
        self,
        detail: str = "Internal Server Error",
        headers: dict[str, str] | None = None,
    ):
        super().__init__(500, detail, headers)


HTTP_STATUS_PHRASES = {
    200: "OK",
    201: "Created",
    204: "No Content",
    301: "Moved Permanently",
    302: "Found",
    304: "Not Modified",
    307: "Temporary Redirect",
    308: "Permanent Redirect",
    400: "Bad Request",
    401: "Unauthorized",
    403: "Forbidden",
    404: "Not Found",
    405: "Method Not Allowed",
    409: "Conflict",
    422: "Unprocessable Entity",
    429: "Too Many Requests",
    500: "Internal Server Error",
    502: "Bad Gateway",
    503: "Service Unavailable",
    504: "Gateway Timeout",
}
