"""CORS (Cross-Origin Resource Sharing) middleware.

Usage:
    from verb.middleware import cors

    # Allow all origins (development)
    app.use(cors())

    # Specific origins (production)
    app.use(cors(
        origins=["https://example.com", "https://app.example.com"],
        methods=["GET", "POST", "PUT", "DELETE"],
        allow_headers=["Authorization", "Content-Type"],
        expose_headers=["X-Custom-Header"],
        allow_credentials=True,
        max_age=3600,
    ))
"""

from __future__ import annotations

from typing import Awaitable, Callable

from ..request import Request
from ..response import Response


def cors(
    origins: list[str] | str = "*",
    methods: list[str] | str = "*",
    allow_headers: list[str] | str = "*",
    expose_headers: list[str] | None = None,
    allow_credentials: bool = False,
    max_age: int | None = None,
) -> Callable[[Request, Callable[[], Awaitable[Response]]], Awaitable[Response]]:
    """Create a CORS middleware.

    Args:
        origins: Allowed origins. "*" for all, or list of specific origins.
        methods: Allowed HTTP methods.
        allow_headers: Headers the client can send.
        expose_headers: Headers the client can read from response.
        allow_credentials: Whether to allow credentials (cookies, auth).
        max_age: How long to cache preflight response (seconds).

    Returns:
        Middleware function.
    """
    # Normalize to strings for headers
    if isinstance(origins, list):
        origins_set = set(origins)
        origins_str = ", ".join(origins)
    else:
        origins_set = None
        origins_str = origins

    if isinstance(methods, list):
        methods_str = ", ".join(methods)
    else:
        methods_str = methods

    if isinstance(allow_headers, list):
        allow_headers_str = ", ".join(allow_headers)
    else:
        allow_headers_str = allow_headers

    expose_headers_str = ", ".join(expose_headers) if expose_headers else None

    async def cors_middleware(
        request: Request,
        call_next: Callable[[], Awaitable[Response]],
    ) -> Response:
        origin = request.headers.get("origin")

        # No origin header = same-origin request, skip CORS
        if not origin:
            return await call_next()

        # Check if origin is allowed
        if origins_set is not None and origin not in origins_set:
            # Origin not allowed - still process request but don't add CORS headers
            return await call_next()

        # Handle preflight (OPTIONS) request
        if request.method == "OPTIONS":
            response = Response(b"", status=204)
        else:
            response = await call_next()

        # Add CORS headers
        # Use specific origin if we're checking a list, otherwise use the header value
        if origins_str == "*" and not allow_credentials:
            response._headers["Access-Control-Allow-Origin"] = "*"
        else:
            response._headers["Access-Control-Allow-Origin"] = origin

        response._headers["Access-Control-Allow-Methods"] = methods_str
        response._headers["Access-Control-Allow-Headers"] = allow_headers_str

        if allow_credentials:
            response._headers["Access-Control-Allow-Credentials"] = "true"

        if expose_headers_str:
            response._headers["Access-Control-Expose-Headers"] = expose_headers_str

        if max_age is not None:
            response._headers["Access-Control-Max-Age"] = str(max_age)

        return response

    return cors_middleware
