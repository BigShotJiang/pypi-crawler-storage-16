"""Cookie-based session middleware with signing.

Usage:
    from verb.middleware import sessions
    from verb import context

    app.use(sessions(secret="your-secret-key"))

    @app.get("/login")
    def login():
        context.session["user_id"] = 123
        return {"logged_in": True}

    @app.get("/profile")
    def profile():
        user_id = context.session.get("user_id")
        if not user_id:
            return {"error": "Not logged in"}, 401
        return {"user_id": user_id}
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import time
from typing import Any, Awaitable, Callable

import msgspec

from ..context import context
from ..request import Request
from ..response import Response


class Session(dict[str, Any]):
    """Session dict that tracks modifications."""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._modified = False

    def __setitem__(self, key: str, value: Any) -> None:
        self._modified = True
        super().__setitem__(key, value)

    def __delitem__(self, key: str) -> None:
        self._modified = True
        super().__delitem__(key)

    def clear(self) -> None:
        self._modified = True
        super().clear()

    def pop(self, key: str, *args: Any) -> Any:
        self._modified = True
        return super().pop(key, *args)

    def update(self, *args: Any, **kwargs: Any) -> None:
        self._modified = True
        super().update(*args, **kwargs)

    @property
    def modified(self) -> bool:
        return self._modified


def _sign(data: bytes, secret: str) -> bytes:
    """Sign data with HMAC-SHA256."""
    signature = hmac.new(secret.encode(), data, hashlib.sha256).digest()
    return base64.urlsafe_b64encode(data + signature)


def _verify(signed_data: bytes, secret: str) -> bytes | None:
    """Verify signed data. Returns original data or None if invalid."""
    try:
        decoded = base64.urlsafe_b64decode(signed_data)
        data = decoded[:-32]
        signature = decoded[-32:]
        expected = hmac.new(secret.encode(), data, hashlib.sha256).digest()
        if hmac.compare_digest(signature, expected):
            return data
        return None
    except Exception:
        return None


def sessions(
    secret: str,
    cookie_name: str = "session",
    max_age: int = 86400 * 14,  # 2 weeks
    path: str = "/",
    domain: str | None = None,
    secure: bool = False,
    httponly: bool = True,
    samesite: str = "lax",
) -> Callable[[Request, Callable[[], Awaitable[Response]]], Awaitable[Response]]:
    """Create a session middleware.

    Args:
        secret: Secret key for signing cookies. Keep this secure!
        cookie_name: Name of the session cookie.
        max_age: Cookie lifetime in seconds.
        path: Cookie path.
        domain: Cookie domain.
        secure: Only send cookie over HTTPS.
        httponly: Prevent JavaScript access to cookie.
        samesite: SameSite policy ("strict", "lax", or "none").

    Returns:
        Middleware function.
    """
    if len(secret) < 32:
        import warnings

        warnings.warn(
            "Session secret should be at least 32 characters for security",
            stacklevel=2,
        )

    async def session_middleware(
        request: Request,
        call_next: Callable[[], Awaitable[Response]],
    ) -> Response:
        # Load session from cookie
        session = Session()
        cookies = _parse_cookies(request.headers.get("cookie", ""))

        if cookie_name in cookies:
            cookie_value = cookies[cookie_name]
            data = _verify(cookie_value.encode(), secret)
            if data:
                try:
                    loaded = msgspec.json.decode(data)
                    if isinstance(loaded, dict):
                        # Check expiration
                        if loaded.get("_exp", 0) > time.time():
                            session.update(loaded.get("_data", {}))
                except Exception:
                    pass  # Invalid session data, start fresh

        # Make session available via context
        context.session = session

        # Process request
        response = await call_next()

        # Save session if modified
        if session.modified or session:
            session_data = {
                "_data": dict(session),
                "_exp": int(time.time()) + max_age,
            }
            encoded = msgspec.json.encode(session_data)
            signed = _sign(encoded, secret)

            # Build cookie
            cookie_parts = [f"{cookie_name}={signed.decode()}"]
            cookie_parts.append(f"Max-Age={max_age}")
            cookie_parts.append(f"Path={path}")
            if domain:
                cookie_parts.append(f"Domain={domain}")
            if secure:
                cookie_parts.append("Secure")
            if httponly:
                cookie_parts.append("HttpOnly")
            cookie_parts.append(f"SameSite={samesite.capitalize()}")

            response._headers["Set-Cookie"] = "; ".join(cookie_parts)

        return response

    return session_middleware


def _parse_cookies(cookie_header: str) -> dict[str, str]:
    """Parse a Cookie header into a dict."""
    cookies: dict[str, str] = {}
    if not cookie_header:
        return cookies

    for part in cookie_header.split(";"):
        part = part.strip()
        if "=" in part:
            key, value = part.split("=", 1)
            cookies[key.strip()] = value.strip()

    return cookies
