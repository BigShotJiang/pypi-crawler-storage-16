"""OpenAPI schema generation.

Automatically generates OpenAPI 3.1 schemas from Ecko routes by inspecting
handler signatures and type hints.

Usage:
    from ecko import Ecko
    from ecko.openapi import setup_openapi

    app = Ecko()
    setup_openapi(app, title="My API", version="1.0.0")

    # Now /openapi.json and /docs are available
"""

from __future__ import annotations

import inspect
from typing import Any, Union, get_args, get_origin, get_type_hints
from types import NoneType, UnionType

import msgspec

from .params import Body, Header, Path, Query, ParamMeta
from .request import Request
from .response import HTMLResponse, JSONResponse


# Swagger UI HTML template
SWAGGER_UI_HTML = """<!DOCTYPE html>
<html>
<head>
    <title>{title} - API Documentation</title>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="https://unpkg.com/swagger-ui-dist@5/swagger-ui.css">
    <style>
        body {{ margin: 0; padding: 0; }}
        .swagger-ui .topbar {{ display: none; }}
    </style>
</head>
<body>
    <div id="swagger-ui"></div>
    <script src="https://unpkg.com/swagger-ui-dist@5/swagger-ui-bundle.js"></script>
    <script>
        window.onload = function() {{
            SwaggerUIBundle({{
                url: "{openapi_url}",
                dom_id: '#swagger-ui',
                presets: [
                    SwaggerUIBundle.presets.apis,
                    SwaggerUIBundle.SwaggerUIStandalonePreset
                ],
                layout: "BaseLayout",
                deepLinking: true,
                showExtensions: true,
                showCommonExtensions: true,
            }});
        }};
    </script>
</body>
</html>"""


def python_type_to_openapi(hint: Any) -> dict[str, Any]:
    """Convert a Python type hint to OpenAPI schema."""
    # Handle None
    if hint is None or hint is NoneType:
        return {"type": "null"}

    # Handle basic types
    if hint is str:
        return {"type": "string"}
    if hint is int:
        return {"type": "integer"}
    if hint is float:
        return {"type": "number"}
    if hint is bool:
        return {"type": "boolean"}
    if hint is bytes:
        return {"type": "string", "format": "binary"}

    # Handle dict
    if hint is dict:
        return {"type": "object"}

    origin = get_origin(hint)

    # Handle dict[K, V]
    if origin is dict:
        return {"type": "object"}

    # Handle list[X]
    if origin is list:
        args = get_args(hint)
        if args:
            return {"type": "array", "items": python_type_to_openapi(args[0])}
        return {"type": "array"}

    # Handle Optional[X] / X | None
    if origin is Union or isinstance(hint, UnionType):
        args = get_args(hint)
        non_none = [a for a in args if a is not NoneType]
        if len(non_none) == 1:
            # Optional[X]
            schema = python_type_to_openapi(non_none[0])
            schema["nullable"] = True
            return schema
        # Union of multiple types
        return {"oneOf": [python_type_to_openapi(a) for a in args if a is not NoneType]}

    # Handle msgspec Struct
    try:
        if isinstance(hint, type) and issubclass(hint, msgspec.Struct):
            return struct_to_openapi(hint)
    except TypeError:
        pass

    # Fallback
    return {"type": "object"}


def struct_to_openapi(struct_cls: type[msgspec.Struct]) -> dict[str, Any]:
    """Convert a msgspec Struct to OpenAPI schema."""
    properties: dict[str, Any] = {}
    required: list[str] = []

    try:
        hints = get_type_hints(struct_cls)
    except Exception:
        hints = {}

    for field in struct_cls.__struct_fields__:
        field_type = hints.get(field, str)
        properties[field] = python_type_to_openapi(field_type)

        # Check if field has a default
        defaults = getattr(struct_cls, "__struct_defaults__", {})
        if field not in defaults:
            required.append(field)

    schema: dict[str, Any] = {
        "type": "object",
        "properties": properties,
    }
    if required:
        schema["required"] = required

    return schema


def generate_openapi(
    app: Any,
    title: str = "API",
    version: str = "1.0.0",
    description: str | None = None,
    servers: list[dict[str, str]] | None = None,
) -> dict[str, Any]:
    """Generate OpenAPI schema from an Ecko app."""
    openapi: dict[str, Any] = {
        "openapi": "3.1.0",
        "info": {
            "title": title,
            "version": version,
        },
        "paths": {},
    }

    if description:
        openapi["info"]["description"] = description

    if servers:
        openapi["servers"] = servers

    # Group routes by path
    paths: dict[str, dict[str, Any]] = {}

    for route in app._router.routes():
        if route.path not in paths:
            paths[route.path] = {}

        operation = generate_operation(route)
        paths[route.path][route.method.lower()] = operation

    openapi["paths"] = paths
    return openapi


def generate_operation(route: Any) -> dict[str, Any]:
    """Generate OpenAPI operation from a route."""
    handler = route.handler
    operation: dict[str, Any] = {}

    # Summary from function name
    operation["summary"] = handler.__name__.replace("_", " ").title()

    # Description from docstring
    if handler.__doc__:
        operation["description"] = handler.__doc__.strip()

    # Tags from module name
    module = handler.__module__
    if module != "__main__":
        operation["tags"] = [module.split(".")[-1]]

    # Parameters
    parameters: list[dict[str, Any]] = []
    request_body: dict[str, Any] | None = None

    sig = inspect.signature(handler)
    try:
        hints = get_type_hints(handler)
    except Exception:
        hints = {}

    for name, param in sig.parameters.items():
        hint = hints.get(name, str)
        default = param.default

        # Skip Request type
        if hint is Request or (isinstance(hint, type) and issubclass(hint, Request)):
            continue

        # Check for explicit markers
        marker: ParamMeta | None = None
        if isinstance(default, ParamMeta):
            marker = default
            default = marker.default

        # Determine parameter location
        is_path_param = name in route.param_names
        is_body_param = False

        if isinstance(marker, Path) or is_path_param:
            location = "path"
        elif isinstance(marker, Header):
            location = "header"
            name = marker.alias or name.replace("_", "-")
        elif isinstance(marker, Query):
            location = "query"
        elif isinstance(marker, Body):
            is_body_param = True
        elif _is_body_type(hint):
            # Auto-detect body types
            if route.method in ("POST", "PUT", "PATCH"):
                is_body_param = True
            else:
                location = "query"
        else:
            location = "query"

        if is_body_param:
            # Request body
            request_body = {
                "required": True,
                "content": {
                    "application/json": {
                        "schema": python_type_to_openapi(hint),
                    }
                },
            }
        else:
            # URL parameter
            param_schema = python_type_to_openapi(_unwrap_optional(hint)[0])
            _, is_optional = _unwrap_optional(hint)

            param_obj: dict[str, Any] = {
                "name": name,
                "in": location,
                "schema": param_schema,
            }

            # Required if path param or no default
            if location == "path":
                param_obj["required"] = True
            elif not is_optional and default is inspect.Parameter.empty:
                param_obj["required"] = True

            if isinstance(marker, ParamMeta) and marker.description:
                param_obj["description"] = marker.description

            parameters.append(param_obj)

    if parameters:
        operation["parameters"] = parameters

    if request_body:
        operation["requestBody"] = request_body

    # Responses
    operation["responses"] = {
        "200": {
            "description": "Successful response",
            "content": {
                "application/json": {
                    "schema": {"type": "object"},
                }
            },
        },
        "422": {
            "description": "Validation error",
        },
    }

    return operation


def _is_body_type(hint: Any) -> bool:
    """Check if a type hint indicates a body parameter."""
    if hint is dict:
        return True
    if get_origin(hint) is dict:
        return True
    try:
        if isinstance(hint, type) and issubclass(hint, msgspec.Struct):
            return True
    except TypeError:
        pass
    return False


def _unwrap_optional(hint: Any) -> tuple[Any, bool]:
    """Unwrap Optional[X] to (X, is_optional)."""
    origin = get_origin(hint)
    if origin is Union or isinstance(hint, UnionType):
        args = get_args(hint)
        non_none = [a for a in args if a is not NoneType]
        if len(non_none) == 1 and len(args) == 2:
            return non_none[0], True
    return hint, False


def setup_openapi(
    app: Any,
    title: str = "API",
    version: str = "1.0.0",
    description: str | None = None,
    docs_url: str = "/docs",
    openapi_url: str = "/openapi.json",
    servers: list[dict[str, str]] | None = None,
) -> None:
    """Set up OpenAPI documentation endpoints.

    Args:
        app: The Ecko application.
        title: API title.
        version: API version.
        description: API description.
        docs_url: URL for Swagger UI.
        openapi_url: URL for OpenAPI JSON schema.
        servers: List of server URLs.
    """
    # Cache the generated schema
    _schema_cache: dict[str, Any] = {}

    @app.get(openapi_url)
    def get_openapi_schema():
        if "schema" not in _schema_cache:
            _schema_cache["schema"] = generate_openapi(
                app,
                title=title,
                version=version,
                description=description,
                servers=servers,
            )
        return _schema_cache["schema"]

    @app.get(docs_url)
    def get_swagger_ui():
        html = SWAGGER_UI_HTML.format(
            title=title,
            openapi_url=openapi_url,
        )
        return HTMLResponse(html)
