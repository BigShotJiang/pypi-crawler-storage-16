"""Parameter extraction from type hints.

Convention over configuration:
- If param name matches a path param: extract from path
- If param type is Request: inject the request object
- If param type is dict/Struct and method has body: parse JSON body
- Otherwise: extract from query string
- Apply type coercion based on type hints

Explicit markers (Query, Path, Body, Header) available for edge cases.
"""

from __future__ import annotations

import inspect
from dataclasses import dataclass
from typing import Any, Callable, Union, get_args, get_origin, get_type_hints
from types import NoneType, UnionType

import msgspec

from .exceptions import ValidationError
from .request import Request


# -----------------------------------------------------------------------------
# Explicit parameter markers
# -----------------------------------------------------------------------------


@dataclass
class ParamMeta:
    """Base class for parameter markers."""

    default: Any = inspect.Parameter.empty
    description: str | None = None


@dataclass
class Query(ParamMeta):
    """Mark a parameter as coming from query string.

    Usage:
        def handler(page: int = Query(1, description="Page number")):
            ...
    """

    pass


@dataclass
class Path(ParamMeta):
    """Mark a parameter as coming from path.

    Usage:
        def handler(id: int = Path(description="User ID")):
            ...
    """

    pass


@dataclass
class Header(ParamMeta):
    """Mark a parameter as coming from headers.

    Usage:
        def handler(auth: str = Header(alias="Authorization")):
            ...
    """

    alias: str | None = None  # Header name if different from param name


@dataclass
class Body(ParamMeta):
    """Mark a parameter as the request body.

    Usage:
        def handler(data: dict = Body()):
            ...
    """

    pass


# -----------------------------------------------------------------------------
# Type introspection utilities
# -----------------------------------------------------------------------------


def unwrap_optional(hint: Any) -> tuple[Any, bool]:
    """Unwrap Optional[X] or X | None to (X, is_optional).

    Returns (inner_type, True) if optional, (hint, False) otherwise.
    """
    origin = get_origin(hint)

    # Handle Union types (including X | None via UnionType)
    if origin is Union or isinstance(hint, UnionType):
        args = get_args(hint)
        non_none = [a for a in args if a is not NoneType]
        if len(non_none) == 1 and len(args) == 2:
            # This is Optional[X] or X | None
            return non_none[0], True
        # More complex union - return as-is
        return hint, False

    return hint, False


def get_list_inner_type(hint: Any) -> type | None:
    """If hint is list[X], return X. Otherwise return None."""
    origin = get_origin(hint)
    if origin is list:
        args = get_args(hint)
        if args:
            return args[0]
        return str  # list without type arg defaults to str
    return None


def is_body_type(hint: Any) -> bool:
    """Check if a type hint indicates a body parameter."""
    # dict is a body type
    if hint is dict:
        return True

    # dict[K, V] is a body type
    if get_origin(hint) is dict:
        return True

    # msgspec Struct subclasses are body types
    try:
        if isinstance(hint, type) and issubclass(hint, msgspec.Struct):
            return True
    except TypeError:
        pass

    return False


# -----------------------------------------------------------------------------
# Coercion
# -----------------------------------------------------------------------------


def coerce_value(value: str, target_type: type, param_name: str = "value") -> Any:
    """Coerce a string value to the target type."""
    if target_type is str:
        return value

    if target_type is int:
        try:
            return int(value)
        except ValueError:
            raise ValidationError(
                f"Parameter '{param_name}': expected integer, got '{value}'"
            )

    if target_type is float:
        try:
            return float(value)
        except ValueError:
            raise ValidationError(
                f"Parameter '{param_name}': expected number, got '{value}'"
            )

    if target_type is bool:
        if value.lower() in ("true", "1", "yes", "on"):
            return True
        if value.lower() in ("false", "0", "no", "off", ""):
            return False
        raise ValidationError(
            f"Parameter '{param_name}': expected boolean, got '{value}'"
        )

    # For unknown types, return as string
    return value


def coerce_list(
    values: list[str], inner_type: type, param_name: str = "value"
) -> list[Any]:
    """Coerce a list of string values to a list of the target type."""
    return [coerce_value(v, inner_type, param_name) for v in values]


async def parse_body(
    request: Request, target_type: type, param_name: str = "body"
) -> Any:
    """Parse request body into the target type."""
    body = await request.body()

    if not body:
        raise ValidationError(f"Parameter '{param_name}': request body is empty")

    # For dict types, just decode JSON
    if target_type is dict or get_origin(target_type) is dict:
        try:
            return msgspec.json.decode(body)
        except msgspec.DecodeError as e:
            raise ValidationError(f"Parameter '{param_name}': invalid JSON - {e}")

    # For msgspec Struct, decode into the type
    try:
        if isinstance(target_type, type) and issubclass(target_type, msgspec.Struct):
            return msgspec.json.decode(body, type=target_type)
    except TypeError:
        pass
    except msgspec.DecodeError as e:
        raise ValidationError(f"Parameter '{param_name}': {e}")

    # Fallback to raw JSON decode
    try:
        return msgspec.json.decode(body)
    except msgspec.DecodeError as e:
        raise ValidationError(f"Parameter '{param_name}': invalid JSON - {e}")


# -----------------------------------------------------------------------------
# Main extraction
# -----------------------------------------------------------------------------


async def extract_params(
    handler: Callable[..., Any],
    request: Request,
    path_params: dict[str, str],
) -> dict[str, Any]:
    """Extract parameters for a handler based on its signature and type hints.

    Rules (in order):
    1. If default is a marker (Query, Path, Body, Header) → use that source
    2. If param type is Request → inject the request object
    3. If param name is in path_params → use path value
    4. If param type is dict/Struct → parse request body
    5. Otherwise → look in query params

    Type coercion is applied automatically. Optional types allow missing values.
    """
    sig = inspect.signature(handler)
    try:
        hints = get_type_hints(handler)
    except Exception:
        hints = {}

    result: dict[str, Any] = {}
    body_consumed = False

    for name, param in sig.parameters.items():
        hint = hints.get(name, str)
        default = param.default
        marker: ParamMeta | None = None

        # Check if default is a marker
        if isinstance(default, ParamMeta):
            marker = default
            default = marker.default

        # Unwrap Optional[X] to get inner type and optionality
        inner_hint, is_optional = unwrap_optional(hint)

        # Rule 1: Explicit markers
        if isinstance(marker, Body):
            if body_consumed:
                raise ValidationError(
                    f"Parameter '{name}': only one body parameter allowed"
                )
            result[name] = await parse_body(request, inner_hint, name)
            body_consumed = True
            continue

        if isinstance(marker, Header):
            header_name = marker.alias or name.replace("_", "-")
            if header_name in request.headers:
                result[name] = coerce_value(
                    request.headers[header_name], inner_hint, name
                )
            elif is_optional:
                result[name] = None
            elif default is not inspect.Parameter.empty:
                result[name] = default
            else:
                raise ValidationError(f"Missing required header: '{header_name}'")
            continue

        if isinstance(marker, Path):
            if name in path_params:
                result[name] = coerce_value(path_params[name], inner_hint, name)
            elif is_optional:
                result[name] = None
            elif default is not inspect.Parameter.empty:
                result[name] = default
            else:
                raise ValidationError(f"Missing required path parameter: '{name}'")
            continue

        if isinstance(marker, Query):
            list_inner = get_list_inner_type(inner_hint)
            if list_inner:
                # List query param
                values = request.query_params_list.get(name, [])
                result[name] = coerce_list(values, list_inner, name)
            elif name in request.query_params:
                result[name] = coerce_value(
                    request.query_params[name], inner_hint, name
                )
            elif is_optional:
                result[name] = None
            elif default is not inspect.Parameter.empty:
                result[name] = default
            else:
                raise ValidationError(f"Missing required query parameter: '{name}'")
            continue

        # Rule 2: Inject Request object
        if inner_hint is Request or (
            isinstance(inner_hint, type) and issubclass(inner_hint, Request)
        ):
            result[name] = request
            continue

        # Rule 3: Path parameter (by name match)
        if name in path_params:
            result[name] = coerce_value(path_params[name], inner_hint, name)
            continue

        # Rule 4: Body type (dict or Struct)
        if is_body_type(inner_hint) and not body_consumed:
            # Only parse body for POST/PUT/PATCH
            if request.method in ("POST", "PUT", "PATCH"):
                result[name] = await parse_body(request, inner_hint, name)
                body_consumed = True
                continue

        # Rule 5: Query parameter
        list_inner = get_list_inner_type(inner_hint)
        if list_inner:
            # List query param: ?tags=a&tags=b
            values = request.query_params_list.get(name, [])
            if values:
                result[name] = coerce_list(values, list_inner, name)
            elif is_optional:
                result[name] = None
            elif default is not inspect.Parameter.empty:
                result[name] = default
            else:
                result[name] = []  # Empty list for missing list params
            continue

        if name in request.query_params:
            result[name] = coerce_value(request.query_params[name], inner_hint, name)
            continue

        # Check for default value or optional
        if is_optional:
            result[name] = None
            continue

        if default is not inspect.Parameter.empty:
            result[name] = default
            continue

        # Missing required parameter
        raise ValidationError(f"Missing required parameter: '{name}'")

    return result
