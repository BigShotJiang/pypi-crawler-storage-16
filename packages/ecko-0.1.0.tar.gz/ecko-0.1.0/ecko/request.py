"""Request wrapper with lazy parsing."""

from __future__ import annotations

from typing import Any
from urllib.parse import parse_qs

import msgspec


class Request:
    """ASGI request wrapper with lazy parsing of body, query params, etc."""

    __slots__ = (
        "_scope",
        "_receive",
        "_body",
        "_json",
        "_form",
        "_query_parsed",
        "_headers",
        "_path_params",
    )

    def __init__(
        self,
        scope: dict[str, Any],
        receive: Any,
        path_params: dict[str, Any] | None = None,
    ) -> None:
        self._scope = scope
        self._receive = receive
        self._body: bytes | None = None
        self._json: Any = None
        self._form: dict[str, Any] | None = None
        self._query_parsed: dict[str, list[str]] | None = None
        self._headers: dict[str, str] | None = None
        self._path_params = path_params or {}

    @property
    def method(self) -> str:
        return self._scope["method"]

    @property
    def path(self) -> str:
        return self._scope["path"]

    @property
    def query_string(self) -> bytes:
        return self._scope.get("query_string", b"")

    def _parse_query(self) -> dict[str, list[str]]:
        """Parse query string into multi-value dict."""
        if self._query_parsed is None:
            qs = self.query_string.decode("utf-8")
            self._query_parsed = parse_qs(qs, keep_blank_values=True)
        return self._query_parsed

    @property
    def query_params(self) -> dict[str, str]:
        """Parse query string, returning first value for each key."""
        parsed = self._parse_query()
        return {k: v[0] for k, v in parsed.items()}

    @property
    def query_params_list(self) -> dict[str, list[str]]:
        """Parse query string, returning all values for each key.

        Useful for multi-value params like ?tags=a&tags=b
        """
        return self._parse_query()

    @property
    def headers(self) -> dict[str, str]:
        """Headers as a dict (lowercase keys)."""
        if self._headers is None:
            self._headers = {
                k.decode("latin-1"): v.decode("latin-1")
                for k, v in self._scope.get("headers", [])
            }
        return self._headers

    @property
    def path_params(self) -> dict[str, Any]:
        """Path parameters extracted from route matching."""
        return self._path_params

    @property
    def content_type(self) -> str | None:
        return self.headers.get("content-type")

    async def body(self) -> bytes:
        """Read and cache the request body."""
        if self._body is None:
            chunks: list[bytes] = []
            while True:
                message = await self._receive()
                body = message.get("body", b"")
                if body:
                    chunks.append(body)
                if not message.get("more_body", False):
                    break
            self._body = b"".join(chunks)
        return self._body

    async def json(self) -> Any:
        """Parse body as JSON using msgspec."""
        if self._json is None:
            body = await self.body()
            self._json = msgspec.json.decode(body)
        return self._json

    async def form(self) -> dict[str, str]:
        """Parse body as form data (application/x-www-form-urlencoded).

        Returns first value for each key. For multi-value, use form_list().
        """
        if self._form is None:
            body = await self.body()
            parsed = parse_qs(body.decode("utf-8"), keep_blank_values=True)
            self._form = parsed
        return {k: v[0] for k, v in self._form.items()}

    async def form_list(self) -> dict[str, list[str]]:
        """Parse body as form data, returning all values for each key."""
        if self._form is None:
            body = await self.body()
            self._form = parse_qs(body.decode("utf-8"), keep_blank_values=True)
        return self._form

    def __repr__(self) -> str:
        return f"<Request {self.method} {self.path}>"
