"""Response classes for different content types."""

from __future__ import annotations

from typing import Any

import msgspec


class Response:
    """Base response class."""

    def __init__(
        self,
        content: str | bytes = b"",
        status: int = 200,
        headers: dict[str, str] | None = None,
        content_type: str = "text/plain; charset=utf-8",
    ) -> None:
        self.status = status
        self._headers = headers or {}
        self.content_type = content_type

        if isinstance(content, str):
            self.body = content.encode("utf-8")
        else:
            self.body = content

    @property
    def headers(self) -> list[tuple[bytes, bytes]]:
        """Return headers as ASGI-compatible list of byte tuples."""
        result = [
            (b"content-type", self.content_type.encode("latin-1")),
            (b"content-length", str(len(self.body)).encode("latin-1")),
        ]
        for key, value in self._headers.items():
            result.append((key.encode("latin-1"), value.encode("latin-1")))
        return result

    async def send(self, send: Any) -> None:
        """Send the response via ASGI."""
        await send(
            {
                "type": "http.response.start",
                "status": self.status,
                "headers": self.headers,
            }
        )
        await send(
            {
                "type": "http.response.body",
                "body": self.body,
            }
        )


class JSONResponse(Response):
    """JSON response using msgspec for fast encoding."""

    def __init__(
        self,
        data: Any,
        status: int = 200,
        headers: dict[str, str] | None = None,
    ) -> None:
        body = msgspec.json.encode(data)
        super().__init__(
            content=body,
            status=status,
            headers=headers,
            content_type="application/json",
        )


class HTMLResponse(Response):
    """HTML response."""

    def __init__(
        self,
        content: str,
        status: int = 200,
        headers: dict[str, str] | None = None,
    ) -> None:
        super().__init__(
            content=content,
            status=status,
            headers=headers,
            content_type="text/html; charset=utf-8",
        )


class RedirectResponse(Response):
    """HTTP redirect response."""

    def __init__(
        self,
        url: str,
        status: int = 307,
        headers: dict[str, str] | None = None,
    ) -> None:
        headers = headers or {}
        headers["location"] = url
        super().__init__(
            content=b"",
            status=status,
            headers=headers,
            content_type="text/plain",
        )


def make_response(
    result: Any,
    status: int = 200,
    headers: dict[str, str] | None = None,
) -> Response:
    """Convert a handler return value into a Response object.

    Supports Flask-style flexible returns:
        return {"data": "json"}                    # → 200 JSON
        return {"data": "json"}, 201               # → 201 JSON
        return {"data": "json"}, 201, {"X-Foo": "bar"}  # → with headers
        return Response(...)                       # Pass through
    """
    if isinstance(result, Response):
        return result

    # Handle tuple returns: (body,), (body, status), (body, status, headers)
    if isinstance(result, tuple):
        if len(result) == 1:
            result = result[0]
        elif len(result) == 2:
            result, status = result
        elif len(result) >= 3:
            result, status, headers = result[0], result[1], result[2]

    # Now convert the body to a response
    if isinstance(result, Response):
        return result
    elif isinstance(result, (dict, list)):
        return JSONResponse(result, status=status, headers=headers)
    elif isinstance(result, str):
        return Response(
            result,
            status=status,
            headers=headers,
            content_type="text/plain; charset=utf-8",
        )
    elif isinstance(result, bytes):
        return Response(
            result,
            status=status,
            headers=headers,
            content_type="application/octet-stream",
        )
    elif result is None:
        return Response(b"", status=status or 204, headers=headers)
    else:
        # Try to JSON encode anything else
        return JSONResponse(result, status=status, headers=headers)
