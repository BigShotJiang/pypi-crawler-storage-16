"""Routing system with path parameter extraction."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Callable


# Pattern to match {param_name} in route paths
PARAM_PATTERN = re.compile(r"\{(\w+)\}")


@dataclass
class Route:
    """A registered route."""

    path: str
    method: str
    handler: Callable[..., Any]
    pattern: re.Pattern[str]
    param_names: list[str]

    def match(self, path: str) -> dict[str, str] | None:
        """Match a path and extract parameters. Returns None if no match."""
        m = self.pattern.match(path)
        if m:
            return {name: m.group(name) for name in self.param_names}
        return None


class Router:
    """Route registration and matching."""

    def __init__(self) -> None:
        self._routes: list[Route] = []

    def add_route(
        self,
        path: str,
        method: str,
        handler: Callable[..., Any],
    ) -> Route:
        """Register a route."""
        # Convert {param} to named regex groups
        param_names: list[str] = PARAM_PATTERN.findall(path)

        # Build regex pattern
        # Escape the path first, then replace escaped \{param\} with capture groups
        escaped = re.escape(path)
        pattern_str = escaped
        for name in param_names:
            # Replace \{name\} with a named capture group
            pattern_str = pattern_str.replace(f"\\{{{name}\\}}", f"(?P<{name}>[^/]+)")

        pattern = re.compile(f"^{pattern_str}$")

        route = Route(
            path=path,
            method=method.upper(),
            handler=handler,
            pattern=pattern,
            param_names=param_names,
        )
        self._routes.append(route)
        return route

    def find(self, path: str, method: str) -> tuple[Route, dict[str, str]] | None:
        """Find a matching route for a path and method.

        Returns (route, path_params) or None if not found.
        """
        method = method.upper()
        for route in self._routes:
            if route.method != method:
                continue
            params = route.match(path)
            if params is not None:
                return (route, params)
        return None

    def routes(self) -> list[Route]:
        """Return all registered routes."""
        return list(self._routes)
