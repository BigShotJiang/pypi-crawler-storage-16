"""WebSocket support for Ecko.

Usage:
    from ecko import Ecko, WebSocket

    app = Ecko()

    @app.websocket("/chat")
    async def chat(ws: WebSocket):
        await ws.accept()
        while True:
            message = await ws.receive_text()
            await ws.send_text(f"Echo: {message}")
"""

from __future__ import annotations

from typing import Any

import msgspec


class WebSocketDisconnect(Exception):
    """Raised when a WebSocket client disconnects."""

    def __init__(self, code: int = 1000):
        self.code = code
        super().__init__(f"WebSocket disconnected with code {code}")


class WebSocket:
    """WebSocket connection wrapper.

    Provides a clean interface for WebSocket communication.
    """

    def __init__(self, scope: dict[str, Any], receive: Any, send: Any) -> None:
        self._scope = scope
        self._receive = receive
        self._send = send
        self._accepted = False
        self._closed = False

    @property
    def path(self) -> str:
        return self._scope["path"]

    @property
    def query_string(self) -> bytes:
        return self._scope.get("query_string", b"")

    @property
    def headers(self) -> dict[str, str]:
        return {
            k.decode("latin-1"): v.decode("latin-1")
            for k, v in self._scope.get("headers", [])
        }

    @property
    def path_params(self) -> dict[str, Any]:
        return self._scope.get("path_params", {})

    async def accept(
        self,
        subprotocol: str | None = None,
        headers: list[tuple[bytes, bytes]] | None = None,
    ) -> None:
        """Accept the WebSocket connection.

        Must be called before sending or receiving messages.
        """
        if self._accepted:
            return

        message: dict[str, Any] = {"type": "websocket.accept"}
        if subprotocol:
            message["subprotocol"] = subprotocol
        if headers:
            message["headers"] = headers

        await self._send(message)
        self._accepted = True

    async def close(self, code: int = 1000, reason: str = "") -> None:
        """Close the WebSocket connection."""
        if self._closed:
            return

        await self._send(
            {
                "type": "websocket.close",
                "code": code,
                "reason": reason,
            }
        )
        self._closed = True

    async def receive(self) -> dict[str, Any]:
        """Receive a raw WebSocket message.

        Returns the full ASGI message dict.
        Raises WebSocketDisconnect if the client disconnects.
        """
        message = await self._receive()

        if message["type"] == "websocket.disconnect":
            self._closed = True
            raise WebSocketDisconnect(code=message.get("code", 1000))

        return message

    async def receive_text(self) -> str:
        """Receive a text message."""
        message = await self.receive()
        return message.get("text", "")

    async def receive_bytes(self) -> bytes:
        """Receive a binary message."""
        message = await self.receive()
        return message.get("bytes", b"")

    async def receive_json(self) -> Any:
        """Receive a JSON message."""
        text = await self.receive_text()
        return msgspec.json.decode(text)

    async def send(self, message: dict[str, Any]) -> None:
        """Send a raw WebSocket message."""
        await self._send(message)

    async def send_text(self, data: str) -> None:
        """Send a text message."""
        await self._send(
            {
                "type": "websocket.send",
                "text": data,
            }
        )

    async def send_bytes(self, data: bytes) -> None:
        """Send a binary message."""
        await self._send(
            {
                "type": "websocket.send",
                "bytes": data,
            }
        )

    async def send_json(self, data: Any) -> None:
        """Send a JSON message."""
        text = msgspec.json.encode(data).decode("utf-8")
        await self.send_text(text)

    async def __aiter__(self):
        """Iterate over incoming messages.

        Usage:
            async for message in ws:
                print(message)
        """
        try:
            while True:
                yield await self.receive_text()
        except WebSocketDisconnect:
            pass

    def __repr__(self) -> str:
        return f"<WebSocket {self.path}>"
