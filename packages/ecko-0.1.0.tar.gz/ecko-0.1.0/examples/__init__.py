"""Example applications for Verb framework."""
