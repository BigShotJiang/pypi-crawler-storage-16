"""Example Ecko application showcasing all features."""

import time

import msgspec

from ecko import Ecko, Request, Query, Header, context, NotFound, setup_openapi
from ecko.middleware import cors, sessions


# Define a msgspec Struct for typed body parsing
class CreateUser(msgspec.Struct):
    """User creation payload."""

    name: str
    email: str
    age: int | None = None


class LoginRequest(msgspec.Struct):
    """Login request payload."""

    username: str
    user_id: int = 1


app = Ecko()


# -----------------------------------------------------------------------------
# OpenAPI Documentation
# -----------------------------------------------------------------------------

setup_openapi(
    app,
    title="Ecko Example API",
    version="0.1.0",
    description="A demonstration of all Ecko framework features.",
)


# -----------------------------------------------------------------------------
# Middleware
# -----------------------------------------------------------------------------


# CORS - allow all origins for development
app.use(cors())

# Sessions with signed cookies
app.use(sessions(secret="change-this-to-a-real-secret-in-production!"))


# Custom timing middleware
async def timing_middleware(request: Request, call_next):
    start = time.perf_counter()
    response = await call_next()
    elapsed = (time.perf_counter() - start) * 1000
    response._headers["X-Response-Time"] = f"{elapsed:.2f}ms"
    return response


app.use(timing_middleware)


# -----------------------------------------------------------------------------
# Lifecycle hooks
# -----------------------------------------------------------------------------


@app.on_startup
async def startup():
    print("Application starting up...")


@app.on_shutdown
async def shutdown():
    print("Application shutting down...")


# -----------------------------------------------------------------------------
# Before/After request hooks
# -----------------------------------------------------------------------------


@app.before_request
def add_request_id():
    """Add a unique request ID to context."""
    import uuid

    context.request_id = str(uuid.uuid4())[:8]


@app.after_request
def add_request_id_header(response):
    """Add request ID to response headers."""
    response._headers["X-Request-ID"] = context.request_id
    return response


# -----------------------------------------------------------------------------
# Exception handlers
# -----------------------------------------------------------------------------


class RateLimitExceeded(Exception):
    pass


@app.exception_handler(RateLimitExceeded)
def handle_rate_limit(exc):
    return {"error": "Rate limit exceeded", "retry_after": 60}, 429


@app.exception_handler(ValueError)
def handle_value_error(exc):
    return {"error": "Invalid value", "detail": str(exc)}, 400


# -----------------------------------------------------------------------------
# Routes
# -----------------------------------------------------------------------------


@app.get("/")
def home():
    """Welcome endpoint with API info."""
    return {
        "message": "Welcome to the Ecko Example API!",
        "version": "0.1.0",
        "docs": "/docs",
        "request_id": context.request_id,
    }


@app.get("/health")
def health():
    """Health check endpoint."""
    return {"status": "ok"}


# Path and query parameters
@app.get("/users/{user_id}")
def get_user(user_id: int, include_posts: bool = False):
    """Get a user by ID with optional posts."""
    return {
        "id": user_id,
        "name": f"User {user_id}",
        "include_posts": include_posts,
    }


@app.get("/search")
def search(
    q: str, page: int = 1, limit: int = Query(20, description="Results per page")
):
    """Search with pagination."""
    return {
        "query": q,
        "page": page,
        "limit": limit,
        "results": [f"Result {i}" for i in range(1, min(limit, 5) + 1)],
    }


# List query parameters
@app.get("/filter")
def filter_items(
    tags: list[str] = [], status: list[str] = Query([], description="Filter by status")
):
    """Filter items by multiple tags and statuses."""
    return {"tags": tags, "status": status}


# Body parsing
@app.post("/users")
def create_user_dict(data: dict):
    """Create a user from JSON body (dict)."""
    return {"created": data}, 201


@app.post("/users/typed")
def create_user_typed(user: CreateUser):
    """Create a user from typed JSON body (msgspec Struct)."""
    return {
        "created": {
            "name": user.name,
            "email": user.email,
            "age": user.age,
        }
    }, 201


# Sessions
@app.post("/login")
def login(data: LoginRequest):
    """Login and create a session."""
    context.session["user_id"] = data.user_id
    context.session["username"] = data.username
    return {"logged_in": True, "username": context.session["username"]}


@app.get("/profile")
def profile():
    """Get current user profile from session."""
    user_id = context.session.get("user_id")
    username = context.session.get("username")
    if not user_id:
        return {"error": "Not logged in"}, 401
    return {"user_id": user_id, "username": username}


@app.post("/logout")
def logout():
    """Clear the session."""
    context.session.clear()
    return {"logged_out": True}


# Headers
@app.get("/headers")
def headers_demo(
    user_agent: str | None = Header(
        alias="user-agent", description="Browser user agent"
    ),
    accept: str | None = Header(alias="accept", description="Accepted content types"),
):
    """Inspect request headers."""
    return {"user_agent": user_agent, "accept": accept}


# Error demonstrations
@app.get("/error/not-found")
def not_found_demo():
    """Trigger a 404 error."""
    raise NotFound("This resource doesn't exist")


@app.get("/error/rate-limit")
def rate_limit_demo():
    """Trigger a rate limit error."""
    raise RateLimitExceeded()


@app.get("/error/value")
def value_error_demo():
    """Trigger a value error."""
    raise ValueError("Something went wrong")


# Async handlers
@app.get("/async")
async def async_endpoint():
    """Async handler demonstration."""
    import asyncio

    await asyncio.sleep(0.01)
    return {"async": True}


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------


if __name__ == "__main__":
    import uvicorn

    print()
    print("  Ecko Example API")
    print("  =================")
    print()
    print("  Endpoints:")
    print("    GET  /              - Welcome + API info")
    print("    GET  /docs          - Swagger UI documentation")
    print("    GET  /openapi.json  - OpenAPI schema")
    print("    GET  /users/{id}    - Get user by ID")
    print("    POST /users         - Create user")
    print("    POST /login         - Create session")
    print("    GET  /profile       - Get profile from session")
    print()
    uvicorn.run(app, host="127.0.0.1", port=8000)
