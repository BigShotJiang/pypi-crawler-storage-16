"""WebSocket chat example for Ecko.

Run with:
    ecko run examples.websocket_chat:app

Then open http://127.0.0.1:8000 in multiple browser tabs to chat.
"""

from ecko import Ecko, WebSocket, WebSocketDisconnect

app = Ecko()

# Store connected clients
clients: set[WebSocket] = set()


@app.get("/")
def home():
    """Serve a simple chat HTML page."""
    from ecko import HTMLResponse

    return HTMLResponse(
        """
<!DOCTYPE html>
<html>
<head>
    <title>Ecko WebSocket Chat</title>
    <style>
        body { font-family: system-ui, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
        #messages { border: 1px solid #ccc; height: 300px; overflow-y: scroll; padding: 10px; margin-bottom: 10px; }
        #input { width: calc(100% - 80px); padding: 8px; }
        button { width: 70px; padding: 8px; }
        .system { color: #888; font-style: italic; }
    </style>
</head>
<body>
    <h1>Ecko WebSocket Chat</h1>
    <div id="messages"></div>
    <input type="text" id="input" placeholder="Type a message..." onkeypress="if(event.key==='Enter')send()">
    <button onclick="send()">Send</button>

    <script>
        const messages = document.getElementById('messages');
        const input = document.getElementById('input');

        const ws = new WebSocket(`ws://${location.host}/ws`);

        ws.onopen = () => addMessage('Connected!', 'system');
        ws.onclose = () => addMessage('Disconnected', 'system');
        ws.onmessage = (e) => addMessage(e.data);

        function addMessage(text, className) {
            const div = document.createElement('div');
            div.textContent = text;
            if (className) div.className = className;
            messages.appendChild(div);
            messages.scrollTop = messages.scrollHeight;
        }

        function send() {
            if (input.value.trim()) {
                ws.send(input.value);
                input.value = '';
            }
        }
    </script>
</body>
</html>
"""
    )


@app.websocket("/ws")
async def chat(ws: WebSocket):
    """Handle WebSocket chat connections."""
    await ws.accept()
    clients.add(ws)

    # Notify others
    await broadcast(f"User joined (total: {len(clients)})")

    try:
        async for message in ws:
            # Broadcast message to all clients
            await broadcast(f"User: {message}")
    except WebSocketDisconnect:
        pass
    finally:
        clients.discard(ws)
        await broadcast(f"User left (total: {len(clients)})")


async def broadcast(message: str):
    """Send a message to all connected clients."""
    disconnected = set()
    for client in clients:
        try:
            await client.send_text(message)
        except Exception:
            disconnected.add(client)

    # Clean up disconnected clients
    clients.difference_update(disconnected)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="127.0.0.1", port=8000)
