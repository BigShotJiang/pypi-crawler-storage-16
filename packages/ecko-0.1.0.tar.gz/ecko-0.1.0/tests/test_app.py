"""Basic tests for Ecko framework."""

import pytest
from ecko import Ecko


class TestEckoApp:
    """Test Ecko application basics."""

    def test_create_app(self):
        """Test that an Ecko app can be instantiated."""
        app = Ecko()
        assert app is not None

    def test_register_route(self):
        """Test that routes can be registered."""
        app = Ecko()

        @app.get("/hello")
        def hello():
            return {"message": "Hello, World!"}

        # Verify route was registered
        assert any(
            route.path == "/hello" and route.method == "GET"
            for route in app._router._routes
        )

    def test_multiple_routes(self):
        """Test registering multiple routes."""
        app = Ecko()

        @app.get("/")
        def home():
            return {"page": "home"}

        @app.post("/users")
        def create_user():
            return {"created": True}

        @app.get("/users/{user_id}")
        def get_user(user_id: int):
            return {"id": user_id}

        assert len(app._router._routes) == 3