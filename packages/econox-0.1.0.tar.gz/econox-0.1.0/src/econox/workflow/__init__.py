# src/econox/workflow/__init__.py
"""Workflow module for the Econox framework."""

from .estimator import Estimator

__all__ = ["Estimator"]