# EcoScape Utilities

This package is simply a collection of utilities that are useful for running 
Colab notebooks and other code.  
These are not packages distributed with pip.  To install on Colab, simply do: 

    !pip install git+https://github.com/ecoscape-earth/ecoscape-utilities.git

## Authors

* Luca de Alfaro (luca@ucsc.edu)
* Natalia Ocampo-Peñuela (nocampop@ucsc.edu)
* Coen Adler (ctadler@ucsc.edu)
* Artie Nazarov (anazarov@ucsc.edu)
* Natalie Valett (nvalett@ucsc.edu)
* Jasmine Tai (cjtai@ucsc.edu)

