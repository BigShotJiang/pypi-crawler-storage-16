import os
import sys
import re
import netrc
import logging
import requests
import json
import pprint
import traceback

#~ class NotFoundError(Exception):    
	#~ def __init__(self, message):
		#~ super().__init__(message)

#~ class InvalidArgumentError(Exception):    
	#~ def __init__(self, message):
		#~ super().__init__(message)
		
#~ class ArgumentNotFoundError(Exception):    
	#~ def __init__(self, message):
		#~ super().__init__(message)
	
#~ class InternalServerError(Exception):    
	#~ def __init__(self, message):
		#~ super().__init__(message)

#~ class PermissionDeniedError(Exception):    
	#~ def __init__(self, message):
		#~ super().__init__(message)

class API:
	
	' init logger '
	logger = logging.getLogger(__qualname__)	
	logger.propagate = False  
	if not logger.handlers:
		handler = logging.StreamHandler()
		formatter = logging.Formatter(
			"%(asctime)s %(levelname)s [%(filename)s:%(lineno)d] %(message)s",datefmt='%Y-%m-%d %H:%M:%S',
		)
		handler.setFormatter(formatter)
		logger.addHandler(handler)
				
	api_url = "https://edc.dgfi.tum.de/api/v3/"
	
	def __init__(self, **kwargs,):
		
		log_level = kwargs.get('log_level',logging.INFO)
		debug = kwargs.get('debug',0)	
		self.username = None
		self.api_key = kwargs.get('api_key',None)
		
		' set log level '
		self.logger.setLevel(log_level)
		
		if debug == 1:
			self.api_url = "https://edc.dgfi.tum.de:8001/api/v3/"
			self.logger.warning("Debug-API enabled ("+str(self.api_url)+")!")
				
		if self.api_key == None:
			' read credential from ~/.netrc '		
			n = netrc.netrc()
			credentials = n.authenticators('edc.dgfi.tum.de')
			if credentials == None:
				self.logger.error('No credentials found in ~/.netrc')
				sys.exit(0)
			
			self.username = credentials[0]
			self.api_key = credentials[2]
			
		self.logger.info('Username: '+str(self.username))
		self.logger.info('API-Key: '+str(self.api_key))

		#~ ' authenicate user '		
		#~ response = self.send_api_request(
			#~ self.api_url+'auth/',
			#~ {			
				#~ 'api_key' :  self.api_key
			#~ }
		#~ )		
		#~ if response.status_code == 200:
			#~ self.logger.info('Authentication successful!')		
		
	def send_api_request(self, url, args):
		
		
		response = requests.post(url, json=args)							
		if response.status_code == 400:	
			json_response = json.loads(response.text)			
			self.logger.error('400 - OpenADB-API url not found!')
			raise ArgumentNotFoundError(json_response['message'])
		elif response.status_code == 403:	
			json_response = json.loads(response.text)
			self.logger.error('403 - Permission denied!')
			raise PermissionDeniedError(json_response['message'])
		elif response.status_code == 471:	
			json_response = json.loads(response.text)
			self.logger.error('471 - Invalid Argument')
			raise InvalidArgumentError(json_response['message'])
		elif response.status_code == 500:
			json_response = json.loads(response.text)
			self.logger.error('500 - Internal Server Error')			
			raise InternalServerError(json_response['message'])	
					
		return response
	
	
	def upload(self, file_path):
		
		self.logger.info('Uploading `'+file_path+'` ...')
		
		if not os.path.isfile:
			print (file_path,'does not exist!')
			sys.exit(0)
		
		headers = {
			"Authorization": f"ApiKey {self.api_key}",			
		}

		files = {
		    "file": open(file_path, "rb"),
		}
		s = requests.Session()
		s.trust_env = False
		response = s.post(self.api_url+"upload/", headers=headers, files=files)

		print("Status:", response.status_code)
		print("Response:", response.text)

		return response
	