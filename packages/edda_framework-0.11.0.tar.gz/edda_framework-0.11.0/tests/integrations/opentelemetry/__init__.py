"""Tests for Edda OpenTelemetry integration."""
