from grasp_gen.utils.logging_config import setup_logging

# Set up logging when the package is imported
setup_logging()

# Version info
__version__ = "0.1.4"
