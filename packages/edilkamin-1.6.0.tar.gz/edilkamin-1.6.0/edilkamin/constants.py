# Legacy AWS Gateway API (deprecated, for backwards compatibility)
OLD_API_URL = "https://fxtj7xkgc6.execute-api.eu-central-1.amazonaws.com/prod/"
# New Edilkamin API (default)
NEW_API_URL = "https://the-mind-api.edilkamin.com/"
# Default to new API (kept for backwards compatibility with existing code)
API_URL = NEW_API_URL

USER_POOL_ID = "eu-central-1_BYmQ2VBlo"
CLIENT_ID = "7sc1qltkqobo3ddqsk4542dg2h"
