"""Prompt 模块"""

from edurag.prompt.teacher_profile import TeacherProfile

__all__ = ["TeacherProfile"]

