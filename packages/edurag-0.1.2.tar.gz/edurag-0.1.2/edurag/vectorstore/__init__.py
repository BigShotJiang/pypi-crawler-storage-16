"""向量存储模块"""

from edurag.vectorstore.faiss_store import FAISSVectorStore

__all__ = ["FAISSVectorStore"]

