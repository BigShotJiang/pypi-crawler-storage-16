Overview
========
eea.api.versions is a revolutionary plone package that redefines Plone Add-ons.

  * See more: http://github.com/eea/eea.api.versions


Installation
============
  * Go to admin > Site Setup > Add-ons
  * Activate eea.api.versions


Authors
=======
  "European Environment Agency", mailto:eea-edw-a-team-alerts@googlegroups.com
