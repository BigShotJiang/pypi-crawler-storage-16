Overview
========
eea.banner is a revolutionary plone package that redefines Plone Add-ons.

  * See more: http://github.com/eea/eea.banner


Installation
============
  * Go to admin > Site Setup > Add-ons
  * Activate eea.banner


Authors
=======
  "European Environment Agency", mailto:eea-edw-a-team-alerts@googlegroups.com
