Overview
========
eea.dexterity.themes is a revolutionary plone package that redefines Plone Add-ons.

  * See more: http://github.com/eea/eea.dexterity.themes


Installation
============
  * Go to admin > Site Setup > Add-ons
  * Activate eea.dexterity.themes


Authors
=======
  "European Environment Agency", mailto:eea-edw-a-team-alerts@googlegroups.com
