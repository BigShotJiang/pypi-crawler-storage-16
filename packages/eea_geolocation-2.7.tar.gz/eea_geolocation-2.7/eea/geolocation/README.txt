Overview
========
eea.geolocation is a revolutionary plone package that redefines Plone Add-ons.

  * See more: http://github.com/eea/eea.geolocation


Installation
============
  * Go to admin > Site Setup > Add-ons
  * Activate eea.geolocation


Authors
=======
  "European Environment Agency", mailto:eea-edw-a-team-alerts@googlegroups.com
