Overview
========
eea.progress.editing is a revolutionary plone package that redefines Plone Add-ons.

  * See more: http://github.com/eea/eea.progress.editing


Installation
============
  * Go to admin > Site Setup > Add-ons
  * Activate eea.progress.editing


Authors
=======
  "European Environment Agency", mailto:eea-edw-a-team-alerts@googlegroups.com
