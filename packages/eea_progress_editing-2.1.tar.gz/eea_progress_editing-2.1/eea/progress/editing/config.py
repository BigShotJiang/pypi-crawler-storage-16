"""Variables"""

from zope.i18nmessageid.message import MessageFactory

EEAMessageFactory = MessageFactory("eea")
