Overview
========
eea.progress.workflow is a revolutionary plone package that redefines Plone Add-ons.

  * See more: http://github.com/eea/eea.progress.workflow


Installation
============
  * Go to admin > Site Setup > Add-ons
  * Activate eea.progress.workflow


Authors
=======
  "European Environment Agency", mailto:eea-edw-a-team-alerts@googlegroups.com
