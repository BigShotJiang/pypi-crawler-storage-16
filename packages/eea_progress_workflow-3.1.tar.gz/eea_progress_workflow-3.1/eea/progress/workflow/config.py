"""Variables"""

from zope.i18nmessageid.message import MessageFactory

EEAMessageFactory = MessageFactory("eea")
PROGRESSFILE = "workflows.progress.xml"
