Overview
========
eea.stringinterp is a revolutionary plone package that redefines Plone Add-ons.

  * See more: http://github.com/eea/eea.stringinterp


Installation
============
  * Go to admin > Site Setup > Add-ons
  * Activate eea.stringinterp


Authors
=======
  "European Environment Agency", mailto:eea-edw-a-team-alerts@googlegroups.com
