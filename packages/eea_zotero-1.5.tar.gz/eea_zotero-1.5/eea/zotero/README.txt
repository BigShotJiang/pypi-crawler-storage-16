Overview
========
eea.zotero is a revolutionary plone package that redefines Plone Add-ons.

  * See more: http://github.com/eea/eea.zotero


Installation
============
  * Go to admin > Site Setup > Add-ons
  * Activate eea.zotero


Authors
=======
  "European Environment Agency", mailto:eea-edw-a-team-alerts@googlegroups.com
