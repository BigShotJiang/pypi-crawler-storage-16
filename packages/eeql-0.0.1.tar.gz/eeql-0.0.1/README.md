# eeql
Entity-Event Query Language (EEQL) - a DSL and Python interface for querying event data.
