def main():
    print("Hello from eeql!")


if __name__ == "__main__":
    main()
