"""
EEQL (Event-Entity Query Language), pronounced "equal".

This is a placeholder initial release.
"""

__version__ = "0.0.1"


def ping() -> str:
    return "eeql is alive"
