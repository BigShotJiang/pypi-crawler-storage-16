"""Entrypoint module for the application."""

from .cli import main

if __name__ == "__main__":
    main()
