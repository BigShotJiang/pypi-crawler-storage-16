#ifndef EGEOMETRY_MODULE_HPP
#define EGEOMETRY_MODULE_HPP

#define PY_SSIZE_T_CLEAN
#include <Python.h>

static PyObject *get_module();

#endif
