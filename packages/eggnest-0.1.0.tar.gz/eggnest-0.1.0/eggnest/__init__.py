"""FinSim API - Retirement and financial planning simulation."""

__version__ = "0.1.0"
