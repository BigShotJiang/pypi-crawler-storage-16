"""Tests for FinSim API."""
