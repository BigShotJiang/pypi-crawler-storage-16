# ruff: noqa: F401
from ._names import APP_NAME, APP_BRAND_NAME
