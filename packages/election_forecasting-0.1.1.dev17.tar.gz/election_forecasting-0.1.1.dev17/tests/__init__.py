"""Test suite for election forecasting models"""
