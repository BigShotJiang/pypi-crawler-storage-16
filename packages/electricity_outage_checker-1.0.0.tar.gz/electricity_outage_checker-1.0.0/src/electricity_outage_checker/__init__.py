"""Electricity Outage Checker - CLI tool to check electricity outage schedules."""

__version__ = "1.0.0"
