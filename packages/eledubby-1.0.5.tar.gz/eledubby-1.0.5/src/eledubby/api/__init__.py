# this_file: api/__init__.py
"""API integration module for adamdubpy."""

from .elevenlabs_client import ElevenLabsClient

__all__ = ["ElevenLabsClient"]
