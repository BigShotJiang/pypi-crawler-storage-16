from elm.elm import cli

def main():
    """Entry point for the ELM tool."""
    cli()

if __name__ == '__main__':
    main()
