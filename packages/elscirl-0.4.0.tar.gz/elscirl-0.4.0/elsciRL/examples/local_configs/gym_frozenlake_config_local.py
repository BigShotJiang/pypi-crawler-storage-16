LocalConfigData ={
    "adapter_select": ["Default", "Language"],
    "training_action_cap": 100,
    "testing_action_cap":100,
    "reward_signal": [1,-0.01,-0.1],
    "sub_goal": "None"
    }