import aiohttp
from fastapi import HTTPException
from token_service_tool import TokenService


class EmailService:
    """
    Async email service that sends emails via Microsoft Graph API.
    Automatically initializes TokenService internally.
    """

    def __init__(
        self,
        client_id: str,
        client_secret: str,
        tenant_id: str,
        scope: str,
        sender_email: str,
        graph_base_url: str,
        default_timeout: int = 15,
        grant_type: str = "client_credentials",
        token_url: str | None = None,
    ):
        """
        EmailService will automatically build TokenService using provided values.
        Users do NOT need to create TokenService themselves.

        :param client_id: Azure AD Application (client) ID
        :param client_secret: Azure AD client secret
        :param tenant_id: Azure tenant ID
        :param scope: Request scope (e.g., https://graph.microsoft.com/.default)
        :param sender_email: Email address used as the sender
        :param graph_base_url: Base Graph API URL
        :param default_timeout: Timeout for HTTP requests
        :param grant_type: OAuth2 grant type (default: client_credentials)
        :param token_url: Optional override; otherwise auto-generated
        """

        # Auto-generate default token endpoint if user does not provide
        self.token_url = token_url or f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"

        # Automatically construct TokenService internally
        self.token_service = TokenService(
            client_id=client_id,
            client_secret=client_secret,
            tenant_id=tenant_id,
            scope=scope,
            token_url=self.token_url,
            grant_type=grant_type,
        )

        self.sender_email = sender_email
        self.graph_base_url = graph_base_url
        self.default_timeout = default_timeout

    # ---------------------------------------------------------------

    async def send_email(
        self,
        to_emails: list[str],
        subject: str,
        html_body: str,
        cc_emails: list[str] = None,
        bcc_emails: list[str] = None,
        attachments: list[dict] = None,
        timeout_seconds: int | None = None,
        api_url: str | None = None
    ):
        """
        Sends an email using Microsoft Graph API.
        Automatically uses created TokenService to fetch tokens.
        """

        if not to_emails:
            return {"status": "failed", "reason": "No recipients provided"}

        message = {
            "subject": subject,
            "body": {"contentType": "HTML", "content": html_body},
            "toRecipients": [{"emailAddress": {"address": e}} for e in to_emails],
        }

        if cc_emails:
            message["ccRecipients"] = [{"emailAddress": {"address": e}} for e in cc_emails]
        if bcc_emails:
            message["bccRecipients"] = [{"emailAddress": {"address": e}} for e in bcc_emails]
        if attachments:
            message["attachments"] = attachments

        payload = {"message": message, "saveToSentItems": True}

        try:
            # Fetch OAuth2 access token
            token = self.token_service.get_access_token()

            # Determine endpoint to call
            if not api_url:
                raise ValueError("api_url must be provided for sending the email.")

            timeout = aiohttp.ClientTimeout(total=timeout_seconds or self.default_timeout)

            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(
                    api_url,
                    headers={
                        "Authorization": f"Bearer {token}",
                        "Content-Type": "application/json",
                    },
                    json=payload,
                ) as response:

                    if response.status == 202:
                        return {"status": "success"}

                    text = await response.text()
                    return {
                        "status": "failed",
                        "response_code": response.status,
                        "response_text": text,
                    }

        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
