# email-service-tool

`email-service-toolcase` is an async email sending utility powered by Microsoft Graph API.

It automatically uses `token-service-toolcase` to fetch OAuth2 access tokens with the Client Credentials flow.

---

## Installation

```bash
pip install email-service-toolcase
```

## Usage

```python
from email_service_toolcase import EmailService

email_service = EmailService(
    client_id="YOUR_CLIENT_ID",
    client_secret="YOUR_CLIENT_SECRET",
    tenant_id="YOUR_TENANT_ID",
    scope="https://graph.microsoft.com/.default",
    sender_email="no-reply@yourdomain.com",
    graph_base_url="https://graph.microsoft.com/v1.0",
)

result = await email_service.send_email(
    to_emails=["user@example.com"],
    subject="Hello!",
    html_body="<h1>Welcome</h1>",
    api_url="https://graph.microsoft.com/v1.0/users/YOUR_SENDER_ID/sendMail"
)
```