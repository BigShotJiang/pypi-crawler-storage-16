from .email_service import EmailService

__all__ = ["EmailService"]
