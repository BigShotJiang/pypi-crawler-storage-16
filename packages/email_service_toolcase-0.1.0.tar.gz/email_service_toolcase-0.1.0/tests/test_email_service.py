import pytest
from unittest.mock import patch, MagicMock
from email_service_toolcase import EmailService


@pytest.mark.asyncio
@patch("token_service_toolcase.token_service.requests.post")
@patch("aiohttp.ClientSession.post")
async def test_send_email_success(mock_post, mock_token_post):
    # Mock token service response
    mock_token_resp = MagicMock()
    mock_token_resp.status_code = 200
    mock_token_resp.json.return_value = {"access_token": "fake-token"}
    mock_token_post.return_value = mock_token_resp

    # Mock email API response
    mock_resp = MagicMock()
    mock_resp.status = 202
    mock_resp.text = MagicMock(return_value="Accepted")
    mock_post.return_value.__aenter__.return_value = mock_resp

    email_service = EmailService(
        client_id="id",
        client_secret="secret",
        tenant_id="tenant",
        scope="scope",
        sender_email="test@domain.com",
        graph_base_url="https://graph.microsoft.com/v1.0",
    )

    response = await email_service.send_email(
        to_emails=["user@example.com"],
        subject="Test Email",
        html_body="<p>Hello!</p>",
        api_url="https://graph.microsoft.com/v1.0/users/x/sendMail"
    )

    assert response["status"] == "success"
