
#ifndef E_MATH_MODULE_HPP
#define E_MATH_MODULE_HPP

// python
#define PY_SSIZE_T_CLEAN
#include <Python.h>

static PyObject *get_module();

#endif
