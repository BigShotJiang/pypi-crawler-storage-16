"""
Authentication system for embed-client.

This module provides comprehensive authentication management for the embed-client,
supporting all security modes and authentication methods. Uses only mcp_security_framework.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import base64
import logging
from typing import Any, Dict, List, Optional

# Import mcp_security_framework components - REQUIRED
try:
    from mcp_security_framework import (
        AuthManager,
        AuthConfig,
        PermissionConfig,
        PermissionManager,
        SecurityManager,
        SecurityConfig,
    )
    from mcp_security_framework.schemas.models import AuthStatus, AuthResult as FrameworkAuthResult
except ImportError as e:
    raise ImportError(
        "mcp_security_framework is required but not available. " "Please install it: pip install mcp-security-framework"
    ) from e


class AuthenticationError(Exception):
    """Raised when authentication fails."""

    def __init__(self, message: str, error_code: int = 401):
        self.message = message
        self.error_code = error_code
        super().__init__(self.message)


class AuthResult:
    """Authentication result container."""

    def __init__(
        self,
        success: bool,
        user_id: Optional[str] = None,
        roles: Optional[List[str]] = None,
        error: Optional[str] = None,
    ):
        self.success = success
        self.user_id = user_id
        self.roles = roles or []
        self.error = error


class ClientAuthManager:
    """
    Client Authentication Manager.

    This class provides authentication management for the embed-client,
    using only mcp_security_framework.
    """

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize authentication manager.

        Args:
            config: Authentication configuration dictionary

        Raises:
            ImportError: If mcp_security_framework is not available
        """
        self.config = config
        self.logger = logging.getLogger(__name__)

        # Initialize security framework components - REQUIRED
        self.auth_manager = None
        self.permission_manager = None
        self.security_manager = None

        self._initialize_security_framework()

    def _initialize_security_framework(self) -> None:
        """Initialize mcp_security_framework components."""
        try:
            # Create auth config
            auth_config = AuthConfig(
                enabled=self.config.get("auth", {}).get("enabled", True),
                methods=self.config.get("auth", {}).get("methods", ["api_key"]),
                api_keys=self.config.get("auth", {}).get("api_keys", {}),
                jwt_secret=self.config.get("auth", {}).get("jwt", {}).get("secret", ""),
                jwt_algorithm="HS256",
                jwt_expiry_hours=self.config.get("auth", {}).get("jwt", {}).get("expiry_hours", 24),
            )

            # Create permission config
            permission_config = PermissionConfig(
                enabled=self.config.get("security", {}).get("roles_enabled", False),
                roles_file=self.config.get("security", {}).get("roles_file") or "configs/roles.json",
            )

            # Create security config
            security_config = SecurityConfig(auth=auth_config, permissions=permission_config)

            # Initialize managers
            self.security_manager = SecurityManager(security_config)
            self.auth_manager = self.security_manager.auth_manager
            self.permission_manager = self.security_manager.permission_manager

            self.logger.info("Security framework initialized successfully")

        except Exception as e:
            self.logger.error(f"Failed to initialize security framework: {e}")
            raise AuthenticationError(f"Failed to initialize security framework: {e}") from e

    def authenticate_api_key(self, api_key: str, header_name: str = "X-API-Key") -> AuthResult:
        """
        Authenticate using API key.

        Args:
            api_key: API key to authenticate
            header_name: Header name for API key

        Returns:
            AuthResult with authentication status
        """
        if not self.auth_manager:
            raise AuthenticationError("Security framework not initialized")

        try:
            result = self.auth_manager.authenticate_api_key(api_key)
            if result.is_valid and result.status == AuthStatus.SUCCESS:
                return AuthResult(success=True, user_id=result.user_id or result.username, roles=result.roles or [])
            else:
                return AuthResult(success=False, error=result.error_message or "Authentication failed")

        except Exception as e:
            self.logger.error(f"API key authentication failed: {e}")
            return AuthResult(success=False, error=str(e))

    def authenticate_jwt(self, token: str) -> AuthResult:
        """
        Authenticate using JWT token.

        Args:
            token: JWT token to authenticate

        Returns:
            AuthResult with authentication status
        """
        if not self.auth_manager:
            raise AuthenticationError("Security framework not initialized")

        try:
            result = self.auth_manager.validate_jwt_token(token)
            if result.is_valid and result.status == AuthStatus.SUCCESS:
                return AuthResult(success=True, user_id=result.user_id or result.username, roles=result.roles or [])
            else:
                return AuthResult(success=False, error=result.error_message or "JWT validation failed")

        except Exception as e:
            self.logger.error(f"JWT authentication failed: {e}")
            return AuthResult(success=False, error=str(e))

    def authenticate_basic(self, username: str, password: str) -> AuthResult:
        """
        Authenticate using basic authentication.

        Note: Basic authentication is handled by mcp_proxy_adapter JsonRpcClient.
        This method is provided for compatibility but actual authentication
        happens at the transport level.

        Args:
            username: Username
            password: Password

        Returns:
            AuthResult with authentication status
        """
        # Basic auth is handled by adapter at transport level
        # Return success for compatibility - actual auth happens in adapter
        return AuthResult(success=True, user_id=username, roles=[])

    def authenticate_certificate(self, cert_file: str, key_file: str) -> AuthResult:
        """
        Authenticate using client certificate.

        Args:
            cert_file: Path to client certificate file
            key_file: Path to client private key file

        Returns:
            AuthResult with authentication status
        """
        if not self.auth_manager:
            raise AuthenticationError("Security framework not initialized")

        try:
            result = self.auth_manager.authenticate_certificate(cert_file, key_file)
            if result.is_valid and result.status == AuthStatus.SUCCESS:
                return AuthResult(success=True, user_id=result.user_id or result.username, roles=result.roles or [])
            else:
                return AuthResult(success=False, error=result.error_message or "Certificate authentication failed")

        except Exception as e:
            self.logger.error(f"Certificate authentication failed: {e}")
            return AuthResult(success=False, error=str(e))

    def create_jwt_token(
        self,
        user_id: str,
        roles: Optional[List[str]] = None,
        expiry_hours: Optional[int] = None,
    ) -> str:
        """
        Create JWT token for user.

        Args:
            user_id: User identifier
            roles: List of user roles
            expiry_hours: Token expiry in hours

        Returns:
            JWT token string

        Raises:
            AuthenticationError: If security framework is not initialized
        """
        if not self.auth_manager:
            raise AuthenticationError("Security framework not initialized")

        try:
            return self.auth_manager.create_jwt_token(user_id, roles, expiry_hours)
        except Exception as e:
            self.logger.error(f"JWT token creation failed: {e}")
            raise AuthenticationError(f"Failed to create JWT token: {e}") from e

    def get_auth_headers(self, auth_method: str, **kwargs) -> Dict[str, str]:
        """
        Get authentication headers for requests.

        Args:
            auth_method: Authentication method
            **kwargs: Additional authentication parameters

        Returns:
            Dictionary of headers
        """
        headers = {}

        if auth_method == "api_key":
            api_key = kwargs.get("api_key")
            header_name = kwargs.get("header", "X-API-Key")
            if api_key:
                headers[header_name] = api_key

        elif auth_method == "jwt":
            token = kwargs.get("token")
            if token:
                headers["Authorization"] = f"Bearer {token}"

        elif auth_method == "basic":
            username = kwargs.get("username")
            password = kwargs.get("password")
            if username and password:
                credentials = base64.b64encode(f"{username}:{password}".encode()).decode()
                headers["Authorization"] = f"Basic {credentials}"

        elif auth_method == "certificate":
            # Certificate authentication is handled at SSL level
            pass

        return headers

    def validate_auth_config(self) -> List[str]:
        """
        Validate authentication configuration.

        Returns:
            List of validation errors
        """
        errors = []
        auth_config = self.config.get("auth", {})
        auth_method = auth_config.get("method", "none")

        if auth_method == "api_key":
            api_keys = auth_config.get("api_keys", {})
            if not api_keys:
                errors.append("API keys not configured for api_key authentication")

        elif auth_method == "jwt":
            jwt_config = auth_config.get("jwt", {})
            if not jwt_config.get("secret"):
                errors.append("JWT secret not configured")
            if not jwt_config.get("username"):
                errors.append("JWT username not configured")
            if not jwt_config.get("password"):
                errors.append("JWT password not configured")

        elif auth_method == "certificate":
            cert_config = auth_config.get("certificate", {})
            if not cert_config.get("cert_file"):
                errors.append("Certificate file not configured")
            if not cert_config.get("key_file"):
                errors.append("Key file not configured")

        elif auth_method == "basic":
            basic_config = auth_config.get("basic", {})
            if not basic_config.get("username"):
                errors.append("Basic auth username not configured")
            if not basic_config.get("password"):
                errors.append("Basic auth password not configured")

        return errors

    def is_auth_enabled(self) -> bool:
        """Check if authentication is enabled."""
        return self.config.get("auth", {}).get("method", "none") != "none"

    def get_auth_method(self) -> str:
        """Get current authentication method."""
        return self.config.get("auth", {}).get("method", "none")

    def get_supported_methods(self) -> List[str]:
        """Get list of supported authentication methods."""
        return ["api_key", "jwt", "certificate", "basic"]


def create_auth_manager(config: Dict[str, Any]) -> ClientAuthManager:
    """
    Create authentication manager from configuration.

    Args:
        config: Configuration dictionary

    Returns:
        ClientAuthManager instance

    Raises:
        ImportError: If mcp_security_framework is not available
    """
    return ClientAuthManager(config)


def create_auth_headers(auth_method: str, **kwargs) -> Dict[str, str]:
    """
    Create authentication headers for requests.

    Args:
        auth_method: Authentication method
        **kwargs: Authentication parameters

    Returns:
        Dictionary of headers
    """
    # Create temporary auth manager for header generation
    temp_config = {"auth": {"method": auth_method}}
    auth_manager = ClientAuthManager(temp_config)
    return auth_manager.get_auth_headers(auth_method, **kwargs)
