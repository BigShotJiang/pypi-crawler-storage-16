"""
SSL/TLS Manager for embed-client.

This module provides SSL/TLS configuration management for the embed-client.
All actual SSL/TLS operations are handled by mcp_proxy_adapter JsonRpcClient.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import logging
import os
from typing import Any, Dict, List, Optional

# Import mcp_security_framework components - REQUIRED for validation
try:
    from mcp_security_framework import SSLConfig, SecurityManager, SecurityConfig, PermissionConfig
except ImportError as e:
    raise ImportError(
        "mcp_security_framework is required but not available. " "Please install it: pip install mcp-security-framework"
    ) from e


class SSLManagerError(Exception):
    """Raised when SSL/TLS operations fail."""

    def __init__(self, message: str, error_code: int = -32002):
        self.message = message
        self.error_code = error_code
        super().__init__(self.message)


class ClientSSLManager:
    """
    Client SSL/TLS Manager.

    This class provides SSL/TLS configuration management for the embed-client.
    All actual SSL/TLS operations are handled by mcp_proxy_adapter JsonRpcClient.
    This class is used only for configuration validation and diagnostics.
    """

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize SSL/TLS manager.

        Args:
            config: SSL/TLS configuration dictionary

        Raises:
            ImportError: If mcp_security_framework is not available
        """
        self.config = config
        self.logger = logging.getLogger(__name__)

        # Initialize security framework for validation only
        self.security_manager = None
        self._initialize_security_framework()

    def _initialize_security_framework(self) -> None:
        """Initialize mcp_security_framework components for validation."""
        try:
            ssl_config_dict = self.config.get("ssl", {})

            # Only initialize if SSL is enabled and we have certificates (for validation)
            # For HTTPS without mTLS, SSL is handled by adapter, no need for SecurityManager
            if not ssl_config_dict.get("enabled", False):
                self.security_manager = None
                return

            cert_file = (
                ssl_config_dict.get("cert_file")
                if ssl_config_dict.get("cert_file") and os.path.exists(ssl_config_dict.get("cert_file"))
                else None
            )
            key_file = (
                ssl_config_dict.get("key_file")
                if ssl_config_dict.get("key_file") and os.path.exists(ssl_config_dict.get("key_file"))
                else None
            )

            # Only initialize SecurityManager if we have certificates (mTLS case)
            # For HTTPS without mTLS, adapter handles SSL, no validation needed
            if not (cert_file and key_file):
                self.security_manager = None
                self.logger.info("SSL enabled but no certificates - validation handled by adapter")
                return

            # Initialize SecurityManager only for mTLS (when we have cert/key)
            verify_mode = ssl_config_dict.get("verify_mode", "CERT_REQUIRED")
            if ssl_config_dict.get("verify", True) == False:
                verify_mode = "CERT_NONE"

            ssl_config = SSLConfig(
                enabled=True,
                cert_file=cert_file,
                key_file=key_file,
                ca_cert_file=(
                    ssl_config_dict.get("ca_cert_file")
                    if ssl_config_dict.get("ca_cert_file") and os.path.exists(ssl_config_dict.get("ca_cert_file"))
                    else None
                ),
                client_cert_file=cert_file,
                client_key_file=key_file,
                verify_mode=verify_mode,
                check_hostname=ssl_config_dict.get("check_hostname", True),
                check_expiry=ssl_config_dict.get("check_expiry", True),
            )

            permission_config = PermissionConfig(enabled=False, roles_file="configs/roles.json")
            security_config = SecurityConfig(ssl=ssl_config, permissions=permission_config)

            self.security_manager = SecurityManager(security_config)
            self.logger.info("Security framework initialized for validation")

        except Exception as e:
            self.logger.error(f"Failed to initialize security framework: {e}")
            raise SSLManagerError(f"Failed to initialize security framework: {e}") from e

    def get_ssl_config(self) -> Dict[str, Any]:
        """
        Get current SSL configuration.

        Returns:
            Dictionary with SSL configuration
        """
        return self.config.get("ssl", {})

    def is_ssl_enabled(self) -> bool:
        """
        Check if SSL/TLS is enabled.

        Returns:
            True if SSL/TLS is enabled, False otherwise
        """
        return self.config.get("ssl", {}).get("enabled", False)

    def is_mtls_enabled(self) -> bool:
        """
        Check if mTLS (mutual TLS) is enabled.

        Returns:
            True if mTLS is enabled, False otherwise
        """
        ssl_config = self.config.get("ssl", {})
        return (
            ssl_config.get("enabled", False) and bool(ssl_config.get("cert_file")) and bool(ssl_config.get("key_file"))
        )

    def validate_ssl_config(self) -> List[str]:
        """
        Validate SSL configuration.

        Returns:
            List of validation errors
        """
        errors = []
        ssl_config = self.config.get("ssl", {})

        if not ssl_config.get("enabled", False):
            return errors  # SSL disabled, no validation needed

        # Check certificate files if mTLS is configured
        cert_file = ssl_config.get("cert_file")
        key_file = ssl_config.get("key_file")

        if cert_file and not os.path.exists(cert_file):
            errors.append(f"Certificate file not found: {cert_file}")

        if key_file and not os.path.exists(key_file):
            errors.append(f"Key file not found: {key_file}")

        # Check CA certificate if provided
        ca_cert_file = ssl_config.get("ca_cert_file")
        if ca_cert_file and not os.path.exists(ca_cert_file):
            errors.append(f"CA certificate file not found: {ca_cert_file}")

        # Validate certificate using security framework if available
        if cert_file and os.path.exists(cert_file) and self.security_manager:
            try:
                # Use security framework for validation if it has validate_certificate method
                if hasattr(self.security_manager, "validate_certificate"):
                    validation_result = self.security_manager.validate_certificate(cert_file)
                    if not validation_result.get("valid", False):
                        errors.append(
                            f"Certificate validation failed: {validation_result.get('error', 'Unknown error')}"
                        )
            except Exception as e:
                errors.append(f"Certificate validation error: {e}")

        return errors

    def get_supported_protocols(self) -> List[str]:
        """
        Get list of supported SSL/TLS protocols.

        Returns:
            List of supported protocol names
        """
        # Protocols are handled by adapter, return standard list
        return ["TLSv1.2", "TLSv1.3"]


def create_ssl_manager(config: Dict[str, Any]) -> ClientSSLManager:
    """
    Create SSL/TLS manager from configuration.

    Args:
        config: Configuration dictionary

    Returns:
        ClientSSLManager instance

    Raises:
        ImportError: If mcp_security_framework is not available
    """
    return ClientSSLManager(config)
