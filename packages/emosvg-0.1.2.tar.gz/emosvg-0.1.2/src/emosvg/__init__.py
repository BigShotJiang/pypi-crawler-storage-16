from .core import text

__all__ = ["text"]
