## TUM EMT Data Loader

Technical University of Munich  
TUM School of Engineering and Design  
Professorship of Energy Management Technologies  

> More information will be available soon.
