## TUM EMT Data Loader

Technical University of Munich  
TUM School of Engineering and Design  
Professorship of Energy Management Technologies  

> More information will be available soon.

Authors:  
[Linus Sander](mailto:linus.sander@tum.de)  
[Lennart Morlock](mailto:lennart.morlock@tum.de)  
[Manuel Katholnigg](mailto:manuel.katholnigg@tum.de)  
[Christoph Goebel](mailto:christoph.goebel@tum.de)  
