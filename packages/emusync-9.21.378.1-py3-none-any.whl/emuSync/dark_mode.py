
bDarkModeEnabled = None

def is_dark_mode():
    global bDarkModeEnabled
    if bDarkModeEnabled is None:
        bDarkModeEnabled = __get_dark_mode()
    return bDarkModeEnabled

def __get_dark_mode():
    import platform
    system = platform.system()

    # Windows
    if system == "Windows":
        try:
            import winreg
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                r'SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize')
            value, _ = winreg.QueryValueEx(key, "AppsUseLightTheme")
            return value == 0  # 0 = dark mode
        except Exception:
            return False

    # macOS
    elif system == "Darwin":
        try:
            import subprocess
            result = subprocess.run(
                ["defaults", "read", "-g", "AppleInterfaceStyle"],
                capture_output=True, text=True
            )
            return "Dark" in result.stdout
        except Exception:
            return False

    # Linux (GNOME-based)
    elif system == "Linux":
        try:
            import subprocess
            theme = subprocess.run(
                ["gsettings", "get", "org.gnome.desktop.interface", "color-scheme"],
                capture_output=True, text=True
            ).stdout.strip().lower()
            return "dark" in theme
        except Exception:
            return False

    return False


