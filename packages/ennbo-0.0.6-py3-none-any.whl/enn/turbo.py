from __future__ import annotations

from .turbo_mode import TurboMode
from .turbo_optimizer import TurboOptimizer

Turbo = TurboOptimizer

__all__ = [
    "TurboMode",
    "Turbo",
]
