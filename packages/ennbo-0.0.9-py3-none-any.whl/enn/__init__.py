from __future__ import annotations

from .enn import EpistemicNearestNeighbors
from .enn_fit import enn_fit


def __getattr__(name: str):
    if name in ("TurboMode", "TurboOptimizer", "Turbo", "Telemetry"):
        from . import turbo

        if name == "TurboMode":
            return turbo.TurboMode
        if name == "TurboOptimizer":
            return turbo.TurboOptimizer
        if name == "Turbo":
            return turbo.Turbo
        if name == "Telemetry":
            return turbo.Telemetry
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__: list[str] = [
    "EpistemicNearestNeighbors",
    "TurboMode",
    "TurboOptimizer",
    "Turbo",
    "Telemetry",
    "enn_fit",
]

