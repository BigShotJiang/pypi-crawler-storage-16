"""Ensue CLI - Command line interface for the Ensue Memory Network."""

__version__ = "0.1.0"
