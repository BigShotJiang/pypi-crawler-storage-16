"""Version information for entity-linker-client."""

__version__ = "1.2.0"
__version_info__ = (1, 2, 0)
