from .derczynski import DERCZYNSKI

__all__ = [
    "DERCZYNSKI",
]
