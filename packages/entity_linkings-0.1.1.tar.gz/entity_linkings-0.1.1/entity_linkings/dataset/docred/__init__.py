from .docred import DOCRED

__all__ = ["DOCRED"]
