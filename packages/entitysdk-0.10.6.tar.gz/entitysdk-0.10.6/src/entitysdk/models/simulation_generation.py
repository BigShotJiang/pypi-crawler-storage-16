"""Simulation generation model."""

from entitysdk.models.activity import Activity


class SimulationGeneration(Activity):
    """Simulation generation activity class."""

    pass
