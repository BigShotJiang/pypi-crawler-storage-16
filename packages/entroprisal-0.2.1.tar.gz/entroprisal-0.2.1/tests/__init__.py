"""Tests for entroprisal package."""
