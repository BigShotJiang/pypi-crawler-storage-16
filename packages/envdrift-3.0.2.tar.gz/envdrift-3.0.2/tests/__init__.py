"""Tests for envdrift."""
