# -*- coding: utf8 -*-
import unittest




# class TestOdooConfig(unittest.TestCase):
#     def test_register_mapper(self):
#         number_of_mapper = 1
#         self.assertEqual(number_of_mapper, len(mapper.load_mappers()))
#
#     def test_register_mapper_extension(self):
#         number_of_section = 2
#         self.assertEqual(number_of_section, len(mapper_extension.load_mappers_extension()))
#
#     def test_register_converter(self):
#         number_of_section = 16
#         self.assertEqual(number_of_section, len(converter.load_converter()))
#
#     def test_register_converter_extension(self):
#         number_of_section = 1
#         self.assertEqual(number_of_section, len(converter_extension.load_converter_extensions()))
