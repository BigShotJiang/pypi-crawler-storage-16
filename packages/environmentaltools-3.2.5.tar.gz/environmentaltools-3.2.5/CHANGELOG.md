# Changelog

All relevant project updates are documented here:

## [3.2.5] - 2025-12-09
### Added
- bug in temporal simulations transforming into degrees circular variables (mcobosb)
- bug creating the output directory for simulations (mcobosb)

## [3.2.0] - 2025-11-27
### Added
- added func for raster indicators (mcobosb)
- added example for presence_boundary (mcobosb)
- added example for influence_extent (mcobosb)
- added example for directional_influence (mcobosb)
- added draft for contributors.md (mcobosb)

## [3.1.2] - 2025-11-14
### Added
- version structure to versem (mcobosb)

## [v2026.3.1.1] - 2025-11-14
### Added
- clarifying version structure (mcobosb)
- rotation 90 heatmap (mcobosb)
- spatiotemporal funct (mcobosb)

## [v2026.3.0] - 2025-11-13
### Added
- added func for raster indicators (mcobosb)

## [v2026.2.5] - 2025-11-12
### Changed
- configuration of package installation (mcobosb)
- handling cartopy import known errors (mcobosb)
- update TODO list (mcobosb)
- added indicator plot (mcobosb)
- remove internal config load (mcobosb)

## [v2026.2.4] - 2025-11-11
### Changed
- update version 2026.2.4 (mcobosb)
- update docs in test-pypi (mcobosb)
- add packages to remove RTD error (mcobosb)
- suppress toc warning (mcobosb)
- update version 2026.2.0 (mcobosb)
- update TODO list (mcobosb)
- udpate examples (mcobosb)
- update functionality (mcobosb)
- update docs and requirements (mcobosb)
- update functions for downloading and drone missions (mcobosb)
- update remove author version at ini file (mcobosb)
- update functions, download and drone examples (mcobosb)
- update downloaded datasets (mcobosb)

## [v2026.2.0] - 2025-11-10
### Changed
- update TODO (mcobosb)
- update drone docs and nb (mcobosb)
- update data for drone examples (mcobosb)
- update alphabetic for dependencies (mcobosb)
- update dron examples (mcobosb)
- update dron functionality (mcobosb)

## [v2026.1.0] - 2025-11-05
### Changed
- update documentation (mcobosb)
- update links to doc in toml file (mcobosb)
- update publish-to-test (mcobosb)
- update raster (mcobosb)
- update todos (mcobosb)
- update to publish (mcobosb)
- update publish-to-test.pypi (mcobosb)
- update for documentation (mcobosb)
- update for documentation (mcobosb)
- update publish test-pypi and conf file ofr RTD (mcobosb)
- update for documentation in RTD (mcobosb)
- update for documentation in RTD (mcobosb)
- update docs file RTD (mcobosb)
- update toml and readme (mcobosb)
- update test-pypi.yml (mcobosb)
- update spatiotemporal functions (mcobosb)
- update docs spatiotemporal (mcobosb)
- update loguru (mcobosb)
- update gitignore (mcobosb)
- update logging to loguru (mcobosb)

## [v2026.0.0] - 2025-11-04
### Changed
- updated bug importing function (mcobosb)
- remove examples in docs and some functions (mcobosb)
- update check for circular variables (mcobosb)

## [v2025.2.0] - 2025-11-03
### Added
- update pyproject.toml (mcobosb)
- updated spatiotemporal functions (mcobosb)
- updated documentation of spatiotemporal (mcobosb)
- Create first battery of examples (mcobosb)
- upload first battery of tests (mcobosb)
- upload temporal package (mcobosb)
- upload spectral package (mcobosb)
- upload spatiotemporal package (mcobosb)
- upload spatial package (mcobosb)
- upload processes package (mcobosb)
- upload graphics package (mcobosb)
- upload download package (mcobosb)
- upload common package (mcobosb)
- include the first battery of test (mcobosb)

## [v2025.1.0] - 2025-10-31
### Changed
- update TODO (mcobosb)
- udpate dependencies (mcobosb)
- added readthedocs file (mcobosb)
- added sphinx documentation (mcobosb)
- update dependencies (mcobosb)
- ignore models folder (mcobosb)
- update modules and latex support for graphics (mcobosb)
- Add ignore to build_ doc files (mcobosb)
- update readme file (mcobosb)
- update readme file (mcobosb)
- update readme file (mcobosb)
- update readme file (mcobosb)
- update configuration and TODO files (mcobosb)
- update configuration and readme files (mcobosb)

## [v2025.0.0] - 2025-10-27
### Added
- Initial commit (Manuel Cobos)