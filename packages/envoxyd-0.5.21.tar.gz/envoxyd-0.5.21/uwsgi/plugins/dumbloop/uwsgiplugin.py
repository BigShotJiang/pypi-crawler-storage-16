NAME='dumbloop'
CFLAGS = []
LDFLAGS = []
LIBS = []

GCC_LIST = ['dumb']
