NAME='msgpack'
CFLAGS=[]
LDFLAGS=[]
LIBS=[]
GCC_LIST = ['msgpack']
