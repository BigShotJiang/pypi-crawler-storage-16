NAME='pam'

CFLAGS = []
LDFLAGS = []
LIBS = ['-lpam']
GCC_LIST = ['pam']
