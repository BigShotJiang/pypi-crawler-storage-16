NAME='router_redirect'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['router_redirect']
