"""Enyal test suite."""
