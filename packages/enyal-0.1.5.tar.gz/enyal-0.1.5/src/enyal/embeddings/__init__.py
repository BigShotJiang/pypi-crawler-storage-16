"""Local embedding generation."""

from enyal.embeddings.engine import EmbeddingEngine

__all__ = ["EmbeddingEngine"]
