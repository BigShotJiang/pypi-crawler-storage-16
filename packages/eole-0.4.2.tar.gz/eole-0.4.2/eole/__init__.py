import os

__version__ = "0.4.2"
ROOT_DIR = os.path.abspath(os.path.dirname(__file__))
