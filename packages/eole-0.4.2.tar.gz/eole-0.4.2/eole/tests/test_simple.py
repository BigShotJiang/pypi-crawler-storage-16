import eole


def test_load():
    eole
    pass
