from .__main__ import app

__all__ = ["app"]