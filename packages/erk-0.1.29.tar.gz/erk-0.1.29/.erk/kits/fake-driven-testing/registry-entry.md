### fake-driven-testing (v0.1.0)

**Purpose**: Defense-in-depth testing architecture for Python with fake implementations and automatic suggestion hook

**Artifacts**:

- skill: skills/fake-driven-testing/SKILL.md

**Usage**:

- Load `fake-driven-testing` skill
