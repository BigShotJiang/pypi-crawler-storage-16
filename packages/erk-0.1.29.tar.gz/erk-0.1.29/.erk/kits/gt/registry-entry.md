### gt (v0.1.0)

**Purpose**: Graphite stack management with landing and submission commands

**Artifacts**:

- command: commands/gt/pr-submit.md
- skill: skills/gt-graphite/SKILL.md, skills/gt-graphite/references/gt-reference.md

**Usage**:

- Run `/gt` command
- Load `gt-graphite` skill
