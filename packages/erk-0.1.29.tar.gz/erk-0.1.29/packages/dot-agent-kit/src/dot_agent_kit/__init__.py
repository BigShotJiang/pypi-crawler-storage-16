"""dot-agent-kit: Kit management for Claude Code.

Import from submodules:
- version: __version__
"""

from dot_agent_kit.version import __version__ as __version__
