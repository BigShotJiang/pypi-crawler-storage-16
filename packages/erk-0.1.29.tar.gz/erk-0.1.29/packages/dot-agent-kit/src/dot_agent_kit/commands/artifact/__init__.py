"""Artifact inspection commands.

Import from submodules:
- group: artifact_group
"""
