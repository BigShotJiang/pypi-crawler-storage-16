# Kit Documentation Registry

<!-- AUTO-GENERATED: This file is managed by erk kit commands -->
<!-- DO NOT EDIT: Changes will be overwritten. Use 'erk kit sync' -->

<!-- REGISTRY_VERSION: 1 -->

<!-- BEGIN_ENTRIES -->

<!-- ENTRY_START kit_id="devrun" version="0.2.3" source="bundled" -->

@.erk/kits/devrun/registry-entry.md

<!-- ENTRY_END -->

<!-- ENTRY_START kit_id="dignified-python" version="0.2.3" source="bundled" -->

@.erk/kits/dignified-python/registry-entry.md

<!-- ENTRY_END -->

<!-- ENTRY_START kit_id="erk" version="0.2.4" source="bundled" -->

@.erk/kits/erk/registry-entry.md

<!-- ENTRY_END -->

<!-- ENTRY_START kit_id="fake-driven-testing" version="0.2.3" source="bundled" -->

@.erk/kits/fake-driven-testing/registry-entry.md

<!-- ENTRY_END -->

<!-- ENTRY_START kit_id="git" version="0.2.3" source="bundled" -->

@.erk/kits/git/registry-entry.md

<!-- ENTRY_END -->

<!-- ENTRY_START kit_id="gt" version="0.2.3" source="bundled" -->

@.erk/kits/gt/registry-entry.md

<!-- ENTRY_END -->

<!-- END_ENTRIES -->
