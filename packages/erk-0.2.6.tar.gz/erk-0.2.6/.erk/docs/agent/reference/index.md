# Reference Documentation

- **[claude-cli-stream-json.md](claude-cli-stream-json.md)** — parsing claude cli output, extracting metadata from stream-json, working with session_id, implementing stream-json parser
