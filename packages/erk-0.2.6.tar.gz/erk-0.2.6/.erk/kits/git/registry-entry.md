### git (v0.2.3)

**Purpose**: Git-only branch submission workflow using standard git + GitHub CLI

**Artifacts**:

- command: commands/git/pr-push.md
- agent: agents/git/git-branch-submitter.md

**Usage**:

- Use Task tool with subagent_type="git"
- Run `/git` command
