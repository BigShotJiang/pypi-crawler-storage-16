# Post-Implementation CI

Run CI validation after plan implementation using `make fast-ci`.

@.claude/docs/ci-iteration.md
