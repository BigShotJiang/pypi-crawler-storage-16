# erk-kits

Bundled kit data package for erk.

This is a minimal, pure-data package that provides paths to bundled kit data files. It has no runtime dependencies.
