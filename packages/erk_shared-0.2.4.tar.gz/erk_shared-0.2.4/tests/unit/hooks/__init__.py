"""Tests for hook logging functionality."""
