"""Unit tests for plan_store module."""
