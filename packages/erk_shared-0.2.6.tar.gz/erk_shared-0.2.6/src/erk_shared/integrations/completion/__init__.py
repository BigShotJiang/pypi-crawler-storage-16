"""Shell completion script generation operations."""

from erk_shared.integrations.completion.abc import Completion as Completion
from erk_shared.integrations.completion.fake import FakeCompletion as FakeCompletion
from erk_shared.integrations.completion.real import RealCompletion as RealCompletion
