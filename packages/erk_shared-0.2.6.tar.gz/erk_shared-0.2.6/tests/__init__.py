"""Tests for erk-shared package."""
