from erlab.interactive.explorer import data_explorer

if __name__ == "__main__":  # pragma: no cover
    data_explorer()
