from .apertium import Apertium
from .argos import Argos
