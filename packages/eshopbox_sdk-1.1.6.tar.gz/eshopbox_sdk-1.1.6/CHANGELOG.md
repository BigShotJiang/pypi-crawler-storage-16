# Changelog

All notable changes to this project will be documented in this file.

## [1.1.6] - 2025-12-03

### Added
- Initial release
- Order management API
- Shipment tracking API
- Product management API
- Inventory management API
- Webhook integration
