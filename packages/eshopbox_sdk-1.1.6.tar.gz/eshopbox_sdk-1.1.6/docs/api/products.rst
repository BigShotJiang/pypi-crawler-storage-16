Products API
============

.. module:: eshopbox.api.products

Overview
--------

The ``ProductsAPI`` module manages product operations such as retrieving product
information or updating product attributes.

.. autoclass:: eshopbox.api.products.ProductsAPI
   :members:
   :undoc-members:
   :show-inheritance:
