"""Version information for EShopBox SDK"""

__version__ = '1.1.6'
__author__ = 'Sakib Mailk'
__email__ = 'sakibwis.wis@gmail.com'
__license__ = 'MIT'
__description__ = 'Python SDK for EShopBox Shipping APIs'
__url__ = 'https://github.com/sakib-wis/eshopbox-sdk'
