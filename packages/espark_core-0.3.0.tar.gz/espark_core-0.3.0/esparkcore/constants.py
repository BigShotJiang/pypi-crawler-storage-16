ENV_DATABASE_URL : str = 'DATABASE_URL'
ENV_MQTT_HOST    : str = 'MQTT_HOST'
ENV_MQTT_PORT    : str = 'MQTT_PORT'

TOPIC_DEVICE       : str = 'espark/device'
TOPIC_REGISTRATION : str = 'espark/registration'
TOPIC_TELEMETRY    : str = 'espark/telemetry'
TOPIC_ACTION       : str = 'espark/action'
TOPIC_CRASH        : str = 'espark/crash'
