from .device_router import DeviceRouter
from .telemetry_router import TelemetryRouter
from .version_router import AppVersionRouter
