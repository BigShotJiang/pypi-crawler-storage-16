"""
Custom exceptions for the ETLForge library.
"""


class ETLForgeError(Exception):
    """Base exception for all ETLForge errors."""

    pass
