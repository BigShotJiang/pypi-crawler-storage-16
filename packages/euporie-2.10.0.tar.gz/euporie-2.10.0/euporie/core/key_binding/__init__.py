"""Define key-bindings for the application."""
