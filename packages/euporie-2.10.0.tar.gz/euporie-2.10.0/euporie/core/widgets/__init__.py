"""Contain various widgets used in euporie.core."""
