"""Define euporie's application classes."""
