# eval_lib/tracing/tracer.py
import uuid
from typing import Optional, Dict, Any
from contextlib import contextmanager
from .types import TraceSpan, SpanType
from .config import TracingConfig
from .context import (
    get_trace_id, set_trace_id,
    get_parent_span_id, set_current_span_id,
    clear_context
)
from .sender import TraceSender


class AgentTracer:
    """Singleton tracer for managing traces and spans"""

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return

        self.enabled = TracingConfig.is_enabled()
        self.sender = TraceSender() if self.enabled else None
        self._initialized = True

    def start_trace(self, name: str = "agent_trace") -> str:
        """Start a new trace and return its ID"""
        if not self.enabled:
            return ""

        trace_id = str(uuid.uuid4())
        set_trace_id(trace_id)
        return trace_id

    def end_trace(self):
        """End the current trace"""
        if self.enabled:
            clear_context()

    def start_span(
        self,
        name: str,
        span_type: SpanType,
        input_data: Optional[Any] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> TraceSpan:
        """Start a new span within the current trace"""
        if not self.enabled:
            return TraceSpan(name=name, span_type=span_type)

        trace_id = get_trace_id()
        if not trace_id:
            # Automatically create a trace if none exists
            trace_id = self.start_trace()

        span = TraceSpan(
            trace_id=trace_id,
            parent_span_id=get_parent_span_id(),
            name=name,
            span_type=span_type,
            input=input_data,
            metadata=metadata or {}
        )

        # Set the current span as the parent for the next spans
        set_current_span_id(span.span_id)

        return span

    def end_span(
        self,
        span: TraceSpan,
        output: Optional[Any] = None,
        error: Optional[Exception] = None
    ):
        """Finish the span and send it to the server"""
        if not self.enabled:
            return

        span.finish(output=output, error=error)

        if self.sender:
            self.sender.add_span(span)

        # Restore the parent span
        if span.parent_span_id:
            set_current_span_id(span.parent_span_id)

    @contextmanager
    def trace(
        self,
        name: str,
        span_type: SpanType = SpanType.AGENT_STEP,
        input_data: Optional[Any] = None,
        metadata: Optional[Dict[str, Any]] = None
    ):
        """Context manager for tracing a block of code"""
        span = self.start_span(name, span_type, input_data, metadata)
        try:
            yield span
            self.end_span(span)
        except Exception as e:
            self.end_span(span, error=e)
            raise

    def flush(self):
        """Force sending all accumulated spans"""
        if self.sender:
            self.sender.flush()


# Global singleton
tracer = AgentTracer()
