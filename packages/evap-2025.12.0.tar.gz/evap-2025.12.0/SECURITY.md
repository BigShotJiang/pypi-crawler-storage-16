# Security Policy

Please do not open GitHub issues for anything you think might have a security implication.

Security issues and bugs should be reported privately by emailing any of the [organization members](https://github.com/orgs/e-valuation/people).

We will try to acknowledge your messages within 48 hours.
If for some reason you do not receive an acknowledgement, please follow up to ensure we received your original message.
