from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ("evaluation", "0018_unique_degrees"),
        ("evaluation", "0014_rename_lecturer"),
    ]
