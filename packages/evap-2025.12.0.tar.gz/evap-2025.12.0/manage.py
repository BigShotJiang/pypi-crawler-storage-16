#!/usr/bin/env python3

import runpy

if __name__ == "__main__":
    runpy.run_module("evap", run_name="__main__")
