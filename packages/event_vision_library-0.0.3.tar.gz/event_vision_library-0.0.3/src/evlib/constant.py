import os

LIBRARY_DIR = os.path.dirname(os.path.abspath(__file__))
ARTIFACTORY_DIR = os.path.join(LIBRARY_DIR, '../../artifacts')
