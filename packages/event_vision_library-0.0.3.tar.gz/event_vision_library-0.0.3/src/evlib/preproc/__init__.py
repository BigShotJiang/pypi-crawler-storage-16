"""Pre-processing of event data, such as filters.
"""
