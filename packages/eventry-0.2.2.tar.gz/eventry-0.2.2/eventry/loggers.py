from __future__ import annotations

from logging import getLogger


router_logger = getLogger('eventry.router')
dispatcher_logger = getLogger('eventry.dispatcher')
