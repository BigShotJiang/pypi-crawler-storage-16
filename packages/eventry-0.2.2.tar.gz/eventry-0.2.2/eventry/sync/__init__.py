from __future__ import annotations


raise NotImplementedError('Synchronous eventry is not implemented yet.')
