from __future__ import annotations


__all__ = ['Event', 'ExtendedEvent']


from eventry.event import Event, ExtendedEvent
