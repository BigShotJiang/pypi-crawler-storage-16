"""Integration tests for event bus implementations."""
