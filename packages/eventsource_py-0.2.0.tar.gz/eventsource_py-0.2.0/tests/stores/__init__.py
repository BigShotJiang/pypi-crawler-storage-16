"""Store-level tests for eventsource."""
