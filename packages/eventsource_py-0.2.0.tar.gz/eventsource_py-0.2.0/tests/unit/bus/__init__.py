"""Unit tests for event bus components."""
