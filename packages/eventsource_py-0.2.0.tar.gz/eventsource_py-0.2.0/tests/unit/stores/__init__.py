"""Unit tests for eventsource stores."""
