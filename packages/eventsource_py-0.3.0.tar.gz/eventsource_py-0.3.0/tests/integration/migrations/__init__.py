"""Integration tests for migration schemas."""
