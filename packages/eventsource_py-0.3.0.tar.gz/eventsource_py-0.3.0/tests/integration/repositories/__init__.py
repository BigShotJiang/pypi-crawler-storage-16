"""Integration tests for repository infrastructure (checkpoints, DLQ, outbox)."""
