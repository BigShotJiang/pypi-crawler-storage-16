"""Unit tests for observability utilities."""
