"""Unit tests for the eventsource.snapshots module."""
