"""Configuration dataclasses for the eventsource library.

This module will contain configuration classes for various components.
Placeholder for future tasks.
"""

# Configuration dataclasses will be added as needed by various tasks
