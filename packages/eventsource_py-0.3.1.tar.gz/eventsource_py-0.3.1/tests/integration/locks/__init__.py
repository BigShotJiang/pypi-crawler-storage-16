"""Integration tests for the eventsource.locks module."""
