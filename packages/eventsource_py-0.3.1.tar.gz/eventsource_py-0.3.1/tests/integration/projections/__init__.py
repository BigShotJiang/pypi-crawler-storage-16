"""Integration tests for projection system."""
