"""
Integration tests for read model repositories.

Tests run against all three backends (InMemory, PostgreSQL, SQLite) to ensure
identical behavior across implementations.
"""
