"""Integration tests for event store implementations."""
