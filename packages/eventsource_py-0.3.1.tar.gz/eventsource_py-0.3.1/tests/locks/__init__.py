"""Tests for the eventsource.locks module."""
