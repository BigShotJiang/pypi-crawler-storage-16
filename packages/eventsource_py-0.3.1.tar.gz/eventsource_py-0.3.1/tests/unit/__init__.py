"""Unit tests for the eventsource library."""
