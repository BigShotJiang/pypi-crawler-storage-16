"""Tests for database migration schemas."""
