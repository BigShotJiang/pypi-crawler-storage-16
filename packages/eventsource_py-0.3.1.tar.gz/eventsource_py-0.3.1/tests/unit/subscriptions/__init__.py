"""Unit tests for subscription module."""
