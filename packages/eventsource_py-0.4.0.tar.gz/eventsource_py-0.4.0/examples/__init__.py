"""
eventsource examples package.

Run examples with:
    python -m eventsource.examples.basic_usage
    python -m eventsource.examples.aggregate_example
    python -m eventsource.examples.projection_example
"""
