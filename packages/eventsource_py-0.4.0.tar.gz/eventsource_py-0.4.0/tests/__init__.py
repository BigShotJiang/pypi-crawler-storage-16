"""Tests for the eventsource library."""
