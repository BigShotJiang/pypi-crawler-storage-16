"""End-to-end integration tests for complete event sourcing workflows."""
