"""Repository-level tests for eventsource."""
