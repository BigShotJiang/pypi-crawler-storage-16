"""Unit tests for aggregate snapshot functionality."""
