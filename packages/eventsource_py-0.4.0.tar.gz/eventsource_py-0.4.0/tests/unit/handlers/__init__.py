"""Unit tests for handlers module."""
