"""Unit tests for the migration module."""
