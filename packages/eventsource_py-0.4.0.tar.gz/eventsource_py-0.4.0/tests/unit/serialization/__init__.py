"""Unit tests for the serialization module."""
