from .django_moduler.evo_router import get_router

__all__ = ["get_router"]
