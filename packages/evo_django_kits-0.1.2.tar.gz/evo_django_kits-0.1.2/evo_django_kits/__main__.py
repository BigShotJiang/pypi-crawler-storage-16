"""Entry point for evo_django_kits."""

from .cli import main  # pragma: no cover

if __name__ == "__main__":  # pragma: no cover
    main()
