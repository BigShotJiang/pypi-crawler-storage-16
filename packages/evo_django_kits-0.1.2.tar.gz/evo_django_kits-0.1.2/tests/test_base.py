from evo_django_kits.base import NAME


def test_base():
    assert NAME == "evo_django_kits"
