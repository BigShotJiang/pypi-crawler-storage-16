

export type TypedArray = Int8Array | Uint8Array | Int16Array | Uint16Array | Int32Array | Uint32Array | Uint8ClampedArray | Float32Array | Float64Array;
interface PyProxy {
	[x: string]: any;
}
declare class PyProxy {
	static [Symbol.hasInstance](obj: any): obj is PyProxy;
	constructor();
	get type(): string;
	toString(): string;
	destroy(options?: {
		message?: string;
		destroyRoundtrip?: boolean;
	}): void;
	copy(): PyProxy;
	toJs({ depth, pyproxies, create_pyproxies, dict_converter, default_converter, eager_converter, }?: {
		pyproxies?: PyProxy[];
		create_pyproxies?: boolean;
		dict_converter?: (array: Iterable<[
			key: string,
			value: any
		]>) => any;
		default_converter?: (obj: PyProxy, convert: (obj: PyProxy) => any, cacheConversion: (obj: PyProxy, result: any) => void) => any;
		eager_converter?: (obj: PyProxy, convert: (obj: PyProxy) => any, cacheConversion: (obj: PyProxy, result: any) => void) => any;
	}): any;
}
declare class PyProxyWithLength extends PyProxy {
	get length(): number;
}
declare class PyProxyWithGet extends PyProxy {
	get(key: any): any;
	asJsJson(): PyProxy & {};
}
declare class PyProxyWithSet extends PyProxy {
	set(key: any, value: any): void;
	delete(key: any): void;
}
declare class PyProxyWithHas extends PyProxy {
	has(key: any): boolean;
}
declare class PyIterable extends PyProxy {
	[Symbol.iterator](): Iterator<any, any, any>;
}
declare class PyAsyncIterable extends PyProxy {
	[Symbol.asyncIterator](): AsyncIterator<any, any, any>;
}
declare class PyIterator extends PyProxy {
	[Symbol.iterator](): this;
	next(arg?: any): IteratorResult<any, any>;
}
declare class PyGenerator extends PyProxy {
	throw(exc: any): IteratorResult<any, any>;
	return(v: any): IteratorResult<any, any>;
}
declare class PyAsyncIterator extends PyProxy {
	[Symbol.asyncIterator](): this;
	next(arg?: any): Promise<IteratorResult<any, any>>;
}
declare class PyAsyncGenerator extends PyProxy {
	throw(exc: any): Promise<IteratorResult<any, any>>;
	return(v: any): Promise<IteratorResult<any, any>>;
}
declare class PySequence extends PyProxy {
	get [Symbol.isConcatSpreadable](): boolean;
	join(separator?: string): string;
	slice(start?: number, stop?: number): any;
	lastIndexOf(elt: any, fromIndex?: number): number;
	indexOf(elt: any, fromIndex?: number): number;
	forEach(callbackfn: (elt: any) => void, thisArg?: any): void;
	map<U>(callbackfn: (elt: any, index: number, array: any) => U, thisArg?: any): U[];
	filter(predicate: (elt: any, index: number, array: any) => boolean, thisArg?: any): any[];
	some(predicate: (value: any, index: number, array: any[]) => unknown, thisArg?: any): boolean;
	every(predicate: (value: any, index: number, array: any[]) => unknown, thisArg?: any): boolean;
	reduce(callbackfn: (previousValue: any, currentValue: any, currentIndex: number, array: any) => any, initialValue?: any): any;
	reduceRight(callbackfn: (previousValue: any, currentValue: any, currentIndex: number, array: any) => any, initialValue: any): any;
	at(index: number): any;
	concat(...rest: ConcatArray<any>[]): any[];
	includes(elt: any): any;
	entries(): IterableIterator<[
		number,
		any
	]>;
	keys(): IterableIterator<number>;
	values(): IterableIterator<any>;
	find(predicate: (value: any, index: number, obj: any[]) => any, thisArg?: any): any;
	findIndex(predicate: (value: any, index: number, obj: any[]) => any, thisArg?: any): number;
	toJSON(this: any): unknown[];
	asJsJson(): PyProxy & {};
}
declare class PyMutableSequence extends PyProxy {
	reverse(): PyMutableSequence;
	sort(compareFn?: (a: any, b: any) => number): PyMutableSequence;
	splice(start: number, deleteCount?: number, ...items: any[]): any[];
	push(...elts: any[]): any;
	pop(): any;
	shift(): any;
	unshift(...elts: any[]): any;
	copyWithin(target: number, start?: number, end?: number): any;
	fill(value: any, start?: number, end?: number): any;
}
declare class PyAwaitable extends PyProxy {
declare class PyCallable extends PyProxy {
	apply(thisArg: any, jsargs: any): any;
	call(thisArg: any, ...jsargs: any): any;
	callWithOptions({ relaxed, kwargs, promising, }: {
		relaxed?: boolean;
		kwargs?: boolean;
		promising?: boolean;
	}, ...jsargs: any): any;
	callKwargs(...jsargs: any): any;
	callRelaxed(...jsargs: any): any;
	callKwargsRelaxed(...jsargs: any): any;
	callPromising(...jsargs: any): Promise<any>;
	callPromisingKwargs(...jsargs: any): Promise<any>;
	bind(thisArg: any, ...jsargs: any): PyProxy;
	captureThis(): PyProxy;
}
declare class PyBuffer extends PyProxy {
	getBuffer(type?: string): PyBufferView;
}
declare class PyDict extends PyProxy {
declare class PyBufferView {
	offset: number;
	readonly: boolean;
	format: string;
	itemsize: number;
	ndim: number;
	nbytes: number;
	shape: number[];
	strides: number[];
	data: TypedArray;
	c_contiguous: boolean;
	f_contiguous: boolean;
	_released: boolean;
	_view_ptr: number;
	release(): void;
}
declare class PythonError extends Error {
	__error_address: number;
	type: string;
	constructor(type: string, message: string, error_address: number);
}
declare const ffi: {
	PyProxy: typeof PyProxy;
	PyProxyWithLength: typeof PyProxyWithLength;
	PyProxyWithGet: typeof PyProxyWithGet;
	PyProxyWithSet: typeof PyProxyWithSet;
	PyProxyWithHas: typeof PyProxyWithHas;
	PyDict: typeof PyDict;
	PyIterable: typeof PyIterable;
	PyAsyncIterable: typeof PyAsyncIterable;
	PyIterator: typeof PyIterator;
	PyAsyncIterator: typeof PyAsyncIterator;
	PyGenerator: typeof PyGenerator;
	PyAsyncGenerator: typeof PyAsyncGenerator;
	PyAwaitable: typeof PyAwaitable;
	PyCallable: typeof PyCallable;
	PyBuffer: typeof PyBuffer;
	PyBufferView: typeof PyBufferView;
	PythonError: typeof PythonError;
	PySequence: typeof PySequence;
	PyMutableSequence: typeof PyMutableSequence;
};

export type {};
export type {PyAsyncGenerator, PyAsyncIterable, PyAsyncIterator, PyAwaitable, PyBuffer, PyBufferView, PyCallable, PyDict, PyGenerator, PyIterable, PyIterator, PyMutableSequence, PyProxy, PyProxyWithGet, PyProxyWithHas, PyProxyWithLength, PyProxyWithSet, PySequence, PythonError};
