

interface CanvasInterface {
	setCanvas2D(canvas: HTMLCanvasElement): void;
	getCanvas2D(): HTMLCanvasElement | undefined;
	setCanvas3D(canvas: HTMLCanvasElement): void;
	getCanvas3D(): HTMLCanvasElement | undefined;
}
type InFuncType = () => null | undefined | string | ArrayBuffer | Uint8Array | number;
declare function setStdin(options?: {
	stdin?: InFuncType;
	read?: (buffer: Uint8Array) => number;
	error?: boolean;
	isatty?: boolean;
	autoEOF?: boolean;
}): void;
declare function setStdout(options?: {
	batched?: (output: string) => void;
	raw?: (charCode: number) => void;
	write?: (buffer: Uint8Array) => number;
	isatty?: boolean;
}): void;
declare function setStderr(options?: {
	batched?: (output: string) => void;
	raw?: (charCode: number) => void;
	write?: (buffer: Uint8Array) => number;
	isatty?: boolean;
}): void;
interface PyodideFSType {
	filesystems: any;
	registerDevice<T>(dev: number, ops: FSStreamOpsGen<T>): void;
}
type FSType = typeof FS & PyodideFSType;
interface LockfileInfo {
	arch: "wasm32";
	abi_version: string;
	platform: string;
	version: string;
	python: string;
}
interface LockfilePackage {
	name: string;
	version: string;
	file_name: string;
	package_type: PackageType;
	install_dir: "site" | "dynlib";
	sha256: string;
	imports: string[];
	depends: string[];
}
interface Lockfile {
	info: LockfileInfo;
	packages: Record<string, LockfilePackage>;
}
type PackageType = "package" | "cpython_module" | "shared_library" | "static_library";
interface PackageData {
	name: string;
	version: string;
	fileName: string;
interface PyProxy {
	[x: string]: any;
}
declare class PyProxy {
	static [Symbol.hasInstance](obj: any): obj is PyProxy;
	constructor();
	get type(): string;
	toString(): string;
	destroy(options?: {
		message?: string;
		destroyRoundtrip?: boolean;
	}): void;
	copy(): PyProxy;
	toJs({ depth, pyproxies, create_pyproxies, dict_converter, default_converter, eager_converter, }?: {
		pyproxies?: PyProxy[];
		create_pyproxies?: boolean;
		dict_converter?: (array: Iterable<[
			key: string,
			value: any
		]>) => any;
		default_converter?: (obj: PyProxy, convert: (obj: PyProxy) => any, cacheConversion: (obj: PyProxy, result: any) => void) => any;
		eager_converter?: (obj: PyProxy, convert: (obj: PyProxy) => any, cacheConversion: (obj: PyProxy, result: any) => void) => any;
	}): any;
}
declare class PyProxyWithLength extends PyProxy {
interface PyProxyWithLength extends PyLengthMethods {
}
declare class PyLengthMethods {
	get length(): number;
}
declare class PyProxyWithGet extends PyProxy {
interface PyProxyWithGet extends PyGetItemMethods {
}
declare class PyGetItemMethods {
	get(key: any): any;
	asJsJson(): PyProxy & {};
}
declare class PyProxyWithSet extends PyProxy {
interface PyProxyWithSet extends PySetItemMethods {
}
declare class PySetItemMethods {
	set(key: any, value: any): void;
	delete(key: any): void;
}
declare class PyProxyWithHas extends PyProxy {
interface PyProxyWithHas extends PyContainsMethods {
}
declare class PyContainsMethods {
	has(key: any): boolean;
}
declare class PyIterable extends PyProxy {
interface PyIterable extends PyIterableMethods {
}
declare class PyIterableMethods {
	[Symbol.iterator](): Iterator<any, any, any>;
}
declare class PyAsyncIterable extends PyProxy {
interface PyAsyncIterable extends PyAsyncIterableMethods {
}
declare class PyAsyncIterableMethods {
	[Symbol.asyncIterator](): AsyncIterator<any, any, any>;
}
declare class PyIterator extends PyProxy {
interface PyIterator extends PyIteratorMethods {
}
declare class PyIteratorMethods {
	next(arg?: any): IteratorResult<any, any>;
}
declare class PyGenerator extends PyProxy {
interface PyGenerator extends PyGeneratorMethods {
}
declare class PyGeneratorMethods {
	throw(exc: any): IteratorResult<any, any>;
	return(v: any): IteratorResult<any, any>;
}
declare class PyAsyncIterator extends PyProxy {
interface PyAsyncIterator extends PyAsyncIteratorMethods {
}
declare class PyAsyncIteratorMethods {
	next(arg?: any): Promise<IteratorResult<any, any>>;
}
declare class PyAsyncGenerator extends PyProxy {
interface PyAsyncGenerator extends PyAsyncGeneratorMethods {
}
declare class PyAsyncGeneratorMethods {
	throw(exc: any): Promise<IteratorResult<any, any>>;
	return(v: any): Promise<IteratorResult<any, any>>;
}
declare class PySequence extends PyProxy {
interface PySequence extends PySequenceMethods {
}
declare class PySequenceMethods {
	join(separator?: string): string;
	slice(start?: number, stop?: number): any;
	lastIndexOf(elt: any, fromIndex?: number): number;
	indexOf(elt: any, fromIndex?: number): number;
	forEach(callbackfn: (elt: any) => void, thisArg?: any): void;
	map<U>(callbackfn: (elt: any, index: number, array: any) => U, thisArg?: any): U[];
	filter(predicate: (elt: any, index: number, array: any) => boolean, thisArg?: any): any[];
	some(predicate: (value: any, index: number, array: any[]) => unknown, thisArg?: any): boolean;
	every(predicate: (value: any, index: number, array: any[]) => unknown, thisArg?: any): boolean;
	reduce(callbackfn: (previousValue: any, currentValue: any, currentIndex: number, array: any) => any, initialValue?: any): any;
	reduceRight(callbackfn: (previousValue: any, currentValue: any, currentIndex: number, array: any) => any, initialValue: any): any;
	at(index: number): any;
	concat(...rest: ConcatArray<any>[]): any[];
	includes(elt: any): any;
	entries(): IterableIterator<[
		number,
		any
	]>;
	keys(): IterableIterator<number>;
	values(): IterableIterator<any>;
	find(predicate: (value: any, index: number, obj: any[]) => any, thisArg?: any): any;
	findIndex(predicate: (value: any, index: number, obj: any[]) => any, thisArg?: any): number;
	toJSON(this: any): unknown[];
	asJsJson(): PyProxy & {};
}
declare class PyMutableSequence extends PyProxy {
interface PyMutableSequence extends PyMutableSequenceMethods {
}
declare class PyMutableSequenceMethods {
	reverse(): PyMutableSequence;
	sort(compareFn?: (a: any, b: any) => number): PyMutableSequence;
	splice(start: number, deleteCount?: number, ...items: any[]): any[];
	push(...elts: any[]): any;
	pop(): any;
	shift(): any;
	unshift(...elts: any[]): any;
	copyWithin(target: number, start?: number, end?: number): any;
	fill(value: any, start?: number, end?: number): any;
}
declare class PyAwaitable extends PyProxy {
interface PyAwaitable extends Promise<any> {
}
declare class PyCallable extends PyProxy {
interface PyCallable extends PyCallableMethods {
	(...args: any[]): any;
}
declare class PyCallableMethods {
	apply(thisArg: any, jsargs: any): any;
	call(thisArg: any, ...jsargs: any): any;
	callWithOptions({ relaxed, kwargs, promising, }: {
		relaxed?: boolean;
		kwargs?: boolean;
		promising?: boolean;
	}, ...jsargs: any): any;
	callKwargs(...jsargs: any): any;
	callRelaxed(...jsargs: any): any;
	callKwargsRelaxed(...jsargs: any): any;
	callPromising(...jsargs: any): Promise<any>;
	callPromisingKwargs(...jsargs: any): Promise<any>;
	bind(thisArg: any, ...jsargs: any): PyProxy;
	captureThis(): PyProxy;
}
declare class PyBuffer extends PyProxy {
interface PyBuffer extends PyBufferMethods {
}
declare class PyBufferMethods {
	getBuffer(type?: string): PyBufferView;
}
declare class PyDict extends PyProxy {
interface PyDict extends PyProxyWithGet, PyProxyWithSet, PyProxyWithHas, PyProxyWithLength, PyIterable {
}
	offset: number;
	readonly: boolean;
	format: string;
	itemsize: number;
	ndim: number;
	nbytes: number;
	shape: number[];
	strides: number[];
	data: TypedArray;
	c_contiguous: boolean;
	f_contiguous: boolean;
	_released: boolean;
	_view_ptr: number;
	release(): void;
}
declare class PythonError extends Error {
	__error_address: number;
	type: string;
	constructor(type: string, message: string, error_address: number);
}
type NativeFS = {
	syncfs: () => Promise<void>;
};
declare class PyodideAPI_ {
	static loadPackage: (names: string | PyProxy | Array<string>, options?: {
		messageCallback?: (message: string) => void;
		errorCallback?: (message: string) => void;
		checkIntegrity?: boolean;
	}) => Promise<PackageData[]>;
	static ffi: {
		PyProxy: typeof PyProxy;
		PyProxyWithLength: typeof PyProxyWithLength;
		PyProxyWithGet: typeof PyProxyWithGet;
		PyProxyWithSet: typeof PyProxyWithSet;
		PyProxyWithHas: typeof PyProxyWithHas;
		PyDict: typeof PyDict;
		PyIterable: typeof PyIterable;
		PyAsyncIterable: typeof PyAsyncIterable;
		PyIterator: typeof PyIterator;
		PyAsyncIterator: typeof PyAsyncIterator;
		PyGenerator: typeof PyGenerator;
		PyAsyncGenerator: typeof PyAsyncGenerator;
		PyAwaitable: typeof PyAwaitable;
		PyCallable: typeof PyCallable;
		PyBuffer: typeof PyBuffer;
		PyBufferView: typeof PyBufferView;
		PythonError: typeof PythonError;
		PySequence: typeof PySequence;
		PyMutableSequence: typeof PyMutableSequence;
	};
	static setStdout: typeof setStdout;
	static globals: PyProxy;
	static FS: FSType;
	static PATH: any;
	static canvas: CanvasInterface;
	static ERRNO_CODES: {
		[code: string]: number;
	};
	static pyodide_py: PyProxy;
	static loadPackagesFromImports(code: string, options?: {
		messageCallback?: (message: string) => void;
		errorCallback?: (message: string) => void;
		checkIntegrity?: boolean;
	}): Promise<Array<PackageData>>;
	static runPython(code: string, options?: {
		globals?: PyProxy;
		locals?: PyProxy;
		filename?: string;
	}): any;
	static runPythonAsync(code: string, options?: {
		globals?: PyProxy;
		locals?: PyProxy;
		filename?: string;
	}): Promise<any>;
	static registerJsModule(name: string, module: object): void;
	static unregisterJsModule(name: string): void;
	static toPy(obj: any, { depth, defaultConverter, }?: {
		depth: number;
		defaultConverter?: (value: any, converter: (value: any) => any, cacheConversion: (input: any, output: any) => void) => any;
	}): any;
	static pyimport(mod_name: string): any;
	static unpackArchive(buffer: TypedArray | ArrayBuffer, format: string, options?: {
		extractDir?: string;
	}): void;
	static mountNativeFS(path: string, fileSystemHandle: FileSystemDirectoryHandle): Promise<NativeFS>;
	static mountNodeFS(emscriptenPath: string, hostPath: string): void;
	static registerComlink(Comlink: any): void;
	static setInterruptBuffer(interrupt_buffer: TypedArray): void;
	static checkInterrupt(): void;
	static setDebug(debug: boolean): boolean;
	static makeMemorySnapshot({ serializer, }?: {
		serializer?: (obj: any) => any;
	}): Uint8Array;
	static get lockfile(): Lockfile;
	static get lockfileBaseUrl(): string | undefined;
}
export type PyodideAPI = typeof PyodideAPI_;
export declare const version: string;
	indexURL?: string;
	packageCacheDir?: string;
	lockFileURL?: string;
	lockFileContents?: Lockfile | string | Promise<Lockfile | string>;
	packageBaseUrl?: string;
	fullStdLib?: boolean;
	stdLibURL?: string;
	stdin?: () => string | null;
	stdout?: (msg: string) => void;
	stderr?: (msg: string) => void;
	jsglobals?: object;
	args?: string[];
	env?: {
		[key: string]: string;
	};
	packages?: string[];
	enableRunUntilComplete?: boolean;
	checkAPIVersion?: boolean;
	fsInit?: (FS: FSType, info: {
		sitePackages: string;
	}) => Promise<void>;
	pyproxyToStringRepr?: boolean;
	convertNullToNone?: boolean;
	toJsLiteralMap?: boolean;
	_sysExecutable?: string;
	_loadSnapshot?: Uint8Array | ArrayBuffer | PromiseLike<Uint8Array | ArrayBuffer>;
	BUILD_ID?: string;
export type PyodideConfigWithDefaults = Required<PyodideConfig>;
export declare function loadPyodide(options?: PyodideConfig): Promise<PyodideAPI>;

export type {
	PyodideAPI as PyodideInterface,
};

export type {};
export type {Lockfile, LockfileInfo, LockfilePackage, PackageData, PyodideConfig};
