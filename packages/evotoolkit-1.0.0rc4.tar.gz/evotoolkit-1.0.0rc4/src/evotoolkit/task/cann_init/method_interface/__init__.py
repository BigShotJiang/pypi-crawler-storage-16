# Copyright (c) 2025 Ping Guo
# Licensed under the MIT License

"""CANNInit task method interfaces"""

from .cann_initer_interface import CANNIniterInterface

__all__ = ["CANNIniterInterface"]
