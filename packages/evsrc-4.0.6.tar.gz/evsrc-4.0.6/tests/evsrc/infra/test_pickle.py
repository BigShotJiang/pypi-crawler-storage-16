"""Persist event sourcing objects into binary pickle"""
