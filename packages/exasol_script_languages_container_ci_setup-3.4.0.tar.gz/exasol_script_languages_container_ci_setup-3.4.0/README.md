
# Overview

This project is used to deploy the CI scripts for Exasol's Script-Languages-Container.

## Github

Provides an CLI to install the Github workflow files to a Script-Languages-Container repository.

## Links

* [User Guide](./user_guide/user_guide.md)
