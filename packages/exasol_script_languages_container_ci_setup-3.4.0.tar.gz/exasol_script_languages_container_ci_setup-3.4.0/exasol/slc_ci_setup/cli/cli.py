import click


@click.group()
def cli():
    pass
