class MissingArgumentError(ValueError):
    pass
