#! /usr/bin/env python3

import exasol.slc.tool.commands
from exasol.slc.tool.cli import cli


def main():
    cli()


if __name__ == "__main__":
    main()
