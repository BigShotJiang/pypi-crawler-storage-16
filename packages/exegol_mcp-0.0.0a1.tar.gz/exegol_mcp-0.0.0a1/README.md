# Exegol-MCP

![banner](https://docs.exegol.com/external/banner.png)

Exegol MCP server
