#pragma once

#include <ATen/Tensor.h>

void had_paley
(
    at::Tensor h
);

void had_paley2
(
    at::Tensor h
);