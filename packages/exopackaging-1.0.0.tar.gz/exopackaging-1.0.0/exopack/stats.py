def mean(values):
    """Blablabalbala devrait apparaitraitre dans help"""
    return sum(values) / len(values)

def variance(values):
    m = mean(values)
    return sum((x - m) ** 2 for x in values) / len(values)
