import matplotlib.pyplot as plt

def simple_plot(values):
    """ docstrinng balbalbal help"""
    plt.plot(values)
    plt.title("Simple Plot")
    plt.xlabel("Index")
    plt.ylabel("Value")
    plt.show()