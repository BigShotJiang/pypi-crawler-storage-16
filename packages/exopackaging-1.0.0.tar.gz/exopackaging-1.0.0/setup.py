from setuptools import setup, find_packages

setup(
    name='exopackaging',
    version='1.0.0',
    packages=find_packages(),
    description='package pour s entrainer à créer des packages',
    author='Naomi',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
    install_requires=[],
)
