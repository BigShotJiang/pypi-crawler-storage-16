# Expand

Types:

```python
from expandai.types import FetchResponse
```

Methods:

- <code title="post /v1/fetch">client.<a href="./src/expandai/_client.py">fetch</a>(\*\*<a href="src/expandai/types/client_fetch_params.py">params</a>) -> <a href="./src/expandai/types/fetch_response.py">FetchResponse</a></code>
