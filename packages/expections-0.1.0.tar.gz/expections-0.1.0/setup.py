from setuptools import setup, find_packages

setup(
    name="expections",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[],
    python_requires=">=3.8",
    license="MIT",
    author="wirnty",
    author_email="skedovichusjdj@gmail.com",
    description="Helper functions that raise Python exceptions",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
)