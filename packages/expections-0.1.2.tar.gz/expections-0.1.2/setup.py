from setuptools import setup, find_packages

setup(
    name="expections",
    version="0.1.2",  # increment version if needed
    description="Custom Python exceptions helper",
    author="wirnty",
    author_email="skedovichusjdj@gmail.com",
    packages=find_packages(),
    python_requires=">=3.7",
    include_package_data=True,
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)