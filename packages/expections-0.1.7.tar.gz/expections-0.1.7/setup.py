from setuptools import setup, find_packages

setup(
    name="expections",
    version="0.1.7",  # increment for PyPI
    description="Custom Python exceptions helper",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="wirnty",
    author_email="skedovichusjdj@gmail.com",
    packages=find_packages(),
    python_requires=">=3.7",
    include_package_data=True,
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)