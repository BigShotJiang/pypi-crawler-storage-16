# expections

A small Python package that provides helper functions to raise built-in Python exceptions in a simple and consistent way.

## Installation

```bash
pip install expections -y