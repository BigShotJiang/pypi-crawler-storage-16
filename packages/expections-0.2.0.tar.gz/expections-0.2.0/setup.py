from setuptools import setup, find_packages

setup(
    name="expections",
    version="0.2.0",  # increment version
    packages=find_packages(),
    python_requires=">=3.6",
    include_package_data=True,
    zip_safe=False,
    author="wirnty",
    author_email="skedovichusjdj@gmail.com",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
)