from setuptools import setup, find_packages

setup(
    name="expections",
    version="0.2.4",  # increment on PyPI if needed
    description="Custom exception utilities",
    packages=find_packages(),  # <- THIS IS CORRECT
    python_requires=">=3.9",
)