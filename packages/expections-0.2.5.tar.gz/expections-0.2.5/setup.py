from setuptools import setup

setup(
    name="expections",
    version="0.2.5",       # increment for PyPI
    py_modules=["expections"],  # single file module
    python_requires=">=3.9",
)