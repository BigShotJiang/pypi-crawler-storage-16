#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Author : bGZo
@Date : 2025-12-06
@Links : https://github.com/bGZo
"""

V2EX_FAV = "https://www.v2ex.com/my/topics"

V2EX_API_TOPICS = "https://www.v2ex.com/api/v2/topics/{topic_id}"