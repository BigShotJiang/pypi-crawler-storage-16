#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Author : bGZo
@Date : 2025-12-06
@Links : https://github.com/bGZo
"""

FAV_URL = "https://www.zhihu.com/api/v4/collections/{collection_id}/items"
