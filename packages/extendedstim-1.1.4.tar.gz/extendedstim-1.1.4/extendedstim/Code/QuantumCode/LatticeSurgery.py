import copy
import galois
import networkx as nx
import numpy as np
from extendedstim.Code.QuantumCode.MajoranaCSSCode import MajoranaCSSCode
from extendedstim.Code.QuantumCode.MajoranaCode import MajoranaCode
from extendedstim.Code.QuantumCode.SubsystemCode import SubsystemCode
from extendedstim.Physics.MajoranaOperator import MajoranaOperator


class MajoranaLatticeSurgery:
    def __init__(self,code_A:MajoranaCSSCode,code_B:MajoranaCSSCode,index_A:int,index_B:int):
        ##  原始数据
        if code_A.logical_operators_x[index_A].weight>code_B.logical_operators_x[index_B].weight:
            self.code_A=code_A
            self.code_B=code_B
            self.index_A=index_A
            self.index_B=index_B
        else:
            self.code_A=code_B
            self.code_B=code_A
            self.index_A=index_B
            self.index_B=index_A

        self.observable=None
        self.fixed_stabilizers_A=[]
        self.fixed_stabilizers_B=[]
        self.irrelevant_stabilizers_A=[]
        self.irrelevant_stabilizers_B=[]
        self.unfixed_stabilizers_A=[]
        self.unfixed_stabilizers_B=[]
        self.prime_stabilizers_A=[]
        self.prime_stabilizers_B=[]
        self.gauge_stabilizers=[]
        self.measurement_stabilizers=[]

        self.graph=None
        self.ancilla_number=0
        self._MajoranaLatticeSurgery()
        self.physical_number=code_A.physical_number+code_B.physical_number+self.ancilla_number
        self.ancilla_stabilizers=[MajoranaOperator([code_A.physical_number+code_B.physical_number+temp],[code_A.physical_number+code_B.physical_number+temp],1j) for temp in range(self.ancilla_number)]
        self.code=MajoranaCode(self.irrelevant_stabilizers_A+self.irrelevant_stabilizers_B+self.prime_stabilizers_A+self.prime_stabilizers_B+
                                     self.fixed_stabilizers_A+self.fixed_stabilizers_B+self.gauge_stabilizers,
                                     code_A.physical_number+code_B.physical_number+self.ancilla_number)
        subsystem_code_temp=SubsystemCode(self.code,self.ancilla_stabilizers+self.measurement_stabilizers+self.unfixed_stabilizers_A+self.unfixed_stabilizers_B)
        anticommute=None
        for i in range(len(subsystem_code_temp.logical_operators)):
            if not MajoranaOperator.commute(self.observable,subsystem_code_temp.logical_operators[i]):
                anticommute=subsystem_code_temp.logical_operators[i]
        if anticommute is None:
            raise ValueError("The observable does not commute with any stabilizer.")
        self.subsystem_code=SubsystemCode(self.code,self.ancilla_stabilizers+self.measurement_stabilizers+self.unfixed_stabilizers_A+self.unfixed_stabilizers_B+[anticommute])

    # %%  CHAPTER：实现fermionic lattice surgery, method 1
    def _MajoranaLatticeSurgery(self):
        code_A:MajoranaCSSCode=self.code_A.copy()
        code_B:MajoranaCSSCode=self.code_B.copy()
        assert isinstance(code_A, MajoranaCSSCode)
        assert isinstance(code_B, MajoranaCSSCode)
        assert isinstance(self.index_A, int)
        assert isinstance(self.index_B, int)

        # %%  SECTION：----数据预处理----
        majorana_number_A=code_A.physical_number
        majorana_number_B=code_B.physical_number
        logical_operator_A=code_A.logical_operators_x[self.index_A]
        logical_operator_B=code_B.logical_operators_x[self.index_B]
        logical_operator_B.occupy_x=logical_operator_B.occupy_x+majorana_number_A
        self.observable=1j*logical_operator_A@logical_operator_B
        code_A.index_map(np.arange(majorana_number_A),majorana_number_A+majorana_number_B)
        code_B.index_map(np.arange(majorana_number_A, majorana_number_A+majorana_number_B),majorana_number_A+majorana_number_B)

        unfixed_stabilizers_A= [temp for temp in code_A.generators if len(set(temp.occupy_x) & set(logical_operator_A.occupy_x)) > 0]
        unfixed_stabilizers_B= [temp for temp in code_B.generators if len(set(temp.occupy_x) & set(logical_operator_B.occupy_x)) > 0]
        self.unfixed_stabilizers_A=copy.deepcopy(unfixed_stabilizers_A)
        self.unfixed_stabilizers_B=copy.deepcopy(unfixed_stabilizers_B)
        irrelevant_stabilizers_A= [temp for temp in code_A.generators if len(set(temp.occupy_x) & set(logical_operator_A.occupy_x)) == 0 and len(temp.occupy_x)>0]
        irrelevant_stabilizers_B= [temp for temp in code_B.generators if len(set(temp.occupy_x) & set(logical_operator_B.occupy_x)) == 0 and len(temp.occupy_x)>0]
        prime_stabilizers_A= [temp for temp in code_A.generators if len(temp.occupy_x)==0]
        prime_stabilizers_B= [temp for temp in code_B.generators if len(temp.occupy_x)==0]
        self.irrelevant_stabilizers_A=irrelevant_stabilizers_A
        self.irrelevant_stabilizers_B=irrelevant_stabilizers_B
        self.prime_stabilizers_A=prime_stabilizers_A
        self.prime_stabilizers_B=prime_stabilizers_B
        ancilla_mode_number=0

        ##  为待修改的stabilizers增加ancilla及其索引
        for i in range(len(unfixed_stabilizers_A)):

            ##  当前stabilizer需要增加的ancilla sites数目
            result_temp = [ancilla_mode_number+temp for temp in range(len(set(unfixed_stabilizers_A[i].occupy_x)&set(logical_operator_A.occupy_x)))]
            self.fixed_stabilizers_A.append((unfixed_stabilizers_A[i].copy(), result_temp))
            ancilla_mode_number+=len(result_temp)

        for i in range(len(unfixed_stabilizers_B)):

            ##  当前stabilizer需要增加的ancilla sites数目
            result_temp=[ancilla_mode_number+temp for temp in range(len(set(unfixed_stabilizers_B[i].occupy_x)&set(logical_operator_B.occupy_x)))]
            self.fixed_stabilizers_B.append((unfixed_stabilizers_B[i].copy(), result_temp))
            ancilla_mode_number+=len(result_temp)

        # %%  SECTION：加入测量稳定子，总是假设左边更长
        ##  先将两边对齐的部分连起来
        for i in range(len(logical_operator_B.occupy_x)):
            self.measurement_stabilizers.append(([logical_operator_A.occupy_x[i],logical_operator_B.occupy_x[i]],[]))
        for i in range((len(logical_operator_A.occupy_x)-len(logical_operator_B.occupy_x))//2):
            self.measurement_stabilizers.append(([logical_operator_A.occupy_x[2*i+len(logical_operator_B.occupy_x)],logical_operator_A.occupy_x[2*i+len(logical_operator_B.occupy_x)+1]],[]))

        ##  分析fixed stabilizers与measurement的交叉情况加入ancilla
        for i in range(len(self.fixed_stabilizers_A)):
            flag_temp=0
            for j in range(len(self.measurement_stabilizers)):
                number=len(set(self.fixed_stabilizers_A[i][0].occupy_x)&set(self.measurement_stabilizers[j][0]))
                for k in range(number):
                    self.measurement_stabilizers[j][1].append(self.fixed_stabilizers_A[i][1][flag_temp+k])
                flag_temp+=number

        for i in range(len(self.fixed_stabilizers_B)):
            flag_temp=0
            for j in range(len(self.measurement_stabilizers)):
                number=len(set(self.fixed_stabilizers_B[i][0].occupy_x)&set(self.measurement_stabilizers[j][0]))
                for k in range(number):
                    self.measurement_stabilizers[j][1].append(self.fixed_stabilizers_B[i][1][flag_temp+k])
                flag_temp+=number

        ##  处理odd-weight measurement stabilizers
        for i in range(len(self.measurement_stabilizers)):
            if len(self.measurement_stabilizers[i][1])%2!=0:
                self.measurement_stabilizers[i][1].append(ancilla_mode_number)
                ancilla_mode_number+=1

        # %%  SECTION：图论计算规范稳定子
        mode_vertices=['Mode'+str(temp) for temp in range(ancilla_mode_number)]
        fix_A_vertices=[]
        fix_B_vertices=[]
        measurement_vertices=[]
        edges=[]
        for i in range(len(self.fixed_stabilizers_A)):
            fix_A_vertices.append('FixA'+str(i))
            for j in range(len(self.fixed_stabilizers_A[i][1])):
                edges.append(('FixA'+str(i), 'Mode'+str(self.fixed_stabilizers_A[i][1][j])))
        for i in range(len(self.fixed_stabilizers_B)):
            fix_B_vertices.append('FixB'+str(i))
            for j in range(len(self.fixed_stabilizers_B[i][1])):
                edges.append(('FixB'+str(i), 'Mode'+str(self.fixed_stabilizers_B[i][1][j])))
        for i in range(len(self.measurement_stabilizers)):
            measurement_vertices.append('Measure'+str(i))
            for j in range(len(self.measurement_stabilizers[i][1])):
                edges.append(('Measure'+str(i), 'Mode'+str(self.measurement_stabilizers[i][1][j])))

        graph = nx.Graph()
        graph.add_nodes_from(mode_vertices)
        graph.add_nodes_from(fix_A_vertices)
        graph.add_nodes_from(fix_B_vertices)
        graph.add_nodes_from(measurement_vertices)
        graph.add_edges_from(edges)
        qubit_list=[]
        check_list=[]
        for index, value in enumerate(graph.nodes()):
            if 'FixA' in value or 'FixB' in value or 'Measure' in value:
                check_list.append(value)
            else:
                qubit_list.append(value)
        matrix=np.zeros((len(check_list), len(qubit_list)), dtype=int)
        for index0, check in enumerate(check_list):
            for index1, qubit in enumerate(qubit_list):
                if (qubit, check) in graph.edges():
                    matrix[index0, index1]=1
        GF=galois.GF(2**1)
        matrix=GF(matrix)
        result=matrix.null_space()
        check_gauge_list=[]
        for i in range(len(result)):
            index_list=np.where(result[i]!=0)[0]
            check_gauge_list.append(index_list)

        temp_list=[]
        for i in range(len(self.fixed_stabilizers_A)):
            occupy_x_temp=self.fixed_stabilizers_A[i][0].occupy_x.tolist()+[temp//2+majorana_number_A+majorana_number_B for temp in self.fixed_stabilizers_A[i][1] if temp%2==0]
            occupy_z_temp=self.fixed_stabilizers_A[i][0].occupy_z.tolist()+[(temp-1)//2+majorana_number_A+majorana_number_B for temp in self.fixed_stabilizers_A[i][1] if temp%2==1]
            temp_list.append(MajoranaOperator.HermitianOperatorFromOccupy(occupy_x_temp,occupy_z_temp))
        self.fixed_stabilizers_A=temp_list
        temp_list=[]
        for i in range(len(self.fixed_stabilizers_B)):
            occupy_x_temp=self.fixed_stabilizers_B[i][0].occupy_x.tolist()+[temp//2+majorana_number_A+majorana_number_B for temp in self.fixed_stabilizers_B[i][1] if temp%2==0]
            occupy_z_temp=self.fixed_stabilizers_B[i][0].occupy_z.tolist()+[(temp-1)//2+majorana_number_A+majorana_number_B for temp in self.fixed_stabilizers_B[i][1] if temp%2==1]
            temp_list.append(MajoranaOperator.HermitianOperatorFromOccupy(occupy_x_temp,occupy_z_temp))
        self.fixed_stabilizers_B=temp_list
        temp_list=[]
        for i in range(len(self.measurement_stabilizers)):
            occupy_x_temp=self.measurement_stabilizers[i][0]+[temp//2+majorana_number_A+majorana_number_B for temp in self.measurement_stabilizers[i][1] if temp%2==0]
            occupy_z_temp=[(temp-1)//2+majorana_number_A+majorana_number_B for temp in self.measurement_stabilizers[i][1] if temp%2==1]
            temp_list.append(MajoranaOperator.HermitianOperatorFromOccupy(occupy_x_temp,occupy_z_temp))
        self.measurement_stabilizers=temp_list
        temp_list=[]
        for i in range(len(check_gauge_list)):
            occupy_x_temp=[temp//2+majorana_number_A+majorana_number_B for temp in check_gauge_list[i] if temp%2==0]
            occupy_z_temp=[(temp-1)//2+majorana_number_A+majorana_number_B for temp in check_gauge_list[i] if temp%2==1]
            temp_list.append(MajoranaOperator.HermitianOperatorFromOccupy(occupy_x_temp,occupy_z_temp))
        self.gauge_stabilizers=temp_list
        self.graph=graph
        self.ancilla_number=ancilla_mode_number//2

# def ZechuanLatticeSurgery(code_ldpc, index)->MajoranaCode:
#
#     #%%  SECTION：数据标准化
#     code_ldpc=code_ldpc.copy()
#     assert isinstance(code_ldpc, MajoranaCSSCode)
#     assert isinstance(index, int)
#
#
#     #%%  SECTION：数据预处理
#     number_qubit_ldpc=code_ldpc.number_qubit
#     logical_operator_ldpc=code_ldpc.logical_operator_list_x[index]
#     support_index_vector_ldpc = np.array(logical_operator_ldpc.x_vector, dtype=int)
#     code_color=MajoranaCode.ColorCode(len(support_index_vector_ldpc))
#     number_qubit_color=code_color.number_qubit
#     logical_operator_color = code_color.logical_operator_list_x[0]
#     code_color.index_map(number_qubit_ldpc+number_qubit_color,np.arange(number_qubit_color)+number_qubit_ldpc)
#     code_ldpc.index_map(number_qubit_ldpc+number_qubit_color,np.arange(number_qubit_ldpc))
#     support_index_vector_color=np.array(logical_operator_color.x_vector,dtype=int)
#     support_index_vector_color=support_index_vector_color.tolist()
#     support_index_vector_ldpc=support_index_vector_ldpc.tolist()
#
#     ##  提取与这些费米子相关联的校验子
#     check_list_x_fix_ldpc=[]
#     check_list_x_unfix_ldpc=[]
#     check_list_z_ldpc=[]
#     check_list_x_fixed_ldpc=[]
#     check_list_x_fix_color=[]
#     check_list_x_unfix_color=[]
#     check_list_z_color=[]
#     check_list_x_fixed_color=[]
#
#     for i in range(len(code_ldpc.check_list)):
#         if len(code_ldpc.check_list[i].x_vector)>0:
#             if len(set(code_ldpc.check_list[i].x_vector)&set(support_index_vector_ldpc))>0:
#                 check_list_x_fix_ldpc.append(code_ldpc.check_list[i].copy())
#             else:
#                 check_list_x_unfix_ldpc.append(code_ldpc.check_list[i].copy())
#         else:
#             check_list_z_ldpc.append(code_ldpc.check_list[i].copy())
#
#     for i in range(len(code_color.check_list)):
#         if len(code_color.check_list[i].x_vector)>0:
#             if len(set(code_color.check_list[i].x_vector)&set(support_index_vector_color))>0:
#                 check_list_x_fix_color.append(code_color.check_list[i].copy())
#             else:
#                 check_list_x_unfix_color.append(code_color.check_list[i].copy())
#         else:
#             check_list_z_color.append(code_color.check_list[i].copy())
#
#     code=MajoranaCode()
#     code.define_qubit(number_qubit_ldpc+number_qubit_color)
#     code.check_origin_list=check_list_x_fix_color+check_list_x_fix_ldpc
#     ##  记录与support关联的ancilla的索引
#     ancilla_dict_ldpc={}
#     ancilla_dict_color={}
#     for i in range(len(support_index_vector_ldpc)):
#         ancilla_dict_ldpc[support_index_vector_ldpc[i]]=[]
#         ancilla_dict_color[support_index_vector_color[i]]=[]
#
#     ##  对color code索引
#     check_index_color=code_color.logical_plaqutte=[1,0,2,3]
#     single_plaqutte=[0,1,2,3]
#     def find_plaqutte(index_0,index_1):
#         op_0=check_list_x_fix_color[0]
#         op_1=check_list_x_fix_color[1]
#         op_2=check_list_x_fix_color[2]
#         op_3=check_list_x_fix_color[3]
#         if index_0==0 and index_1==1:
#             return op_1,[1],None
#         elif index_0==0 and index_1==2:
#             return op_1.mul(op_0,code.number_qubit),[0,1],None
#         elif index_0==0 and index_1==3:
#             return op_1.mul(op_2,code.number_qubit),[1,2],[support_index_vector_color[1],support_index_vector_color[2]]
#         elif index_0==0 and index_1==4:
#             return op_1.mul(op_3,code.number_qubit),[1,3],[support_index_vector_color[1],support_index_vector_color[3]]
#         elif index_0==1 and index_1==2:
#             return op_0,[0],None
#         elif index_0==1 and index_1==3:
#             return op_0.mul(op_2,code.number_qubit),[0,2],None
#         elif index_0==1 and index_1==4:
#             return op_0.mul(op_3,code.number_qubit),[0,3],[support_index_vector_color[2],support_index_vector_color[3]]
#         elif index_0==2 and index_1==3:
#             return op_2,[2],None
#         elif index_0==2 and index_1==4:
#             return op_2.mul(op_3,code.number_qubit),[2,3],None
#         elif index_0==3 and index_1==4:
#             return op_3,[3],None
#
#     check_list_gauge=[]
#     ##  对support组队
#     couple_list=[]
#     for i in range(len(check_list_x_fix_ldpc)):
#         temp=set(check_list_x_fix_ldpc[i].x_vector) & set(support_index_vector_ldpc)
#         temp=list(temp)
#         couple_list.append([])
#         for j in range(len(temp)//2):
#             couple_list[i].append((temp[2*j],temp[2*j+1]))
#
#     ##  修改LDPC code的check
#     for i in range(len(check_list_x_fix_ldpc)):
#         for j in range(len(couple_list[i])):
#             x_vector_temp=check_list_x_fix_ldpc[i].x_vector.copy()
#             z_vector_temp=check_list_x_fix_ldpc[i].z_vector.copy()
#             code.push_qubit(1)
#             ancilla_dict_ldpc[couple_list[i][j][0]].append((code.qubit_list[-1],'x'))
#             ancilla_dict_ldpc[couple_list[i][j][1]].append((code.qubit_list[-1],'z'))
#             x_vector_temp=np.append(x_vector_temp,code.qubit_list[-1])
#             z_vector_temp=np.append(z_vector_temp,code.qubit_list[-1])
#             check_list_x_fix_ldpc[i]=MajoranaOperator(x_vector_temp, z_vector_temp,1)
#             index_0=couple_list[i][j][0]
#             index_1=couple_list[i][j][1]
#             index_min=support_index_vector_ldpc.index(index_0)
#             index_max=support_index_vector_ldpc.index(index_1)
#             if index_min>index_max:
#                 temp=index_min
#                 index_min=index_max
#                 index_max=temp
#             operator_color_temp,index_list,associate_list=find_plaqutte(index_min,index_max)
#             x_vector_temp = operator_color_temp.x_vector.copy()
#             z_vector_temp = operator_color_temp.z_vector.copy()
#             for i in range(len(index_list)):
#                 single_plaqutte[index_list[i]]=None
#             if associate_list is not None:
#                 index_temp_0=associate_list[0]
#                 index_temp_1=associate_list[1]
#                 code.push_qubit(2)
#
#                 ancilla_dict_color[index_temp_0].append((code.qubit_list[-1],'x'))
#                 ancilla_dict_color[index_temp_0].append((code.qubit_list[-2],'x'))
#                 ancilla_dict_color[index_temp_1].append((code.qubit_list[-1],'z'))
#                 ancilla_dict_color[index_temp_1].append((code.qubit_list[-2],'z'))
#                 x_vector_temp_gauge=[code.qubit_list[-2],code.qubit_list[-1]]
#                 z_vector_temp_gauge=[code.qubit_list[-2],code.qubit_list[-1]]
#                 check_list_gauge.append(MajoranaOperator(x_vector_temp_gauge, z_vector_temp_gauge, 1))
#                 x_vector_temp=np.append(x_vector_temp,code.qubit_list[-2])
#                 z_vector_temp=np.append(z_vector_temp,code.qubit_list[-2])
#             index_0_color = support_index_vector_color[support_index_vector_ldpc.index(index_0)]
#             index_1_color = support_index_vector_color[support_index_vector_ldpc.index(index_1)]
#             code.push_qubit(1)
#             x_vector_temp=np.append(x_vector_temp,code.qubit_list[-1])
#             z_vector_temp=np.append(z_vector_temp,code.qubit_list[-1])
#             ancilla_dict_color[index_0_color].append((code.qubit_list[-1],'x'))
#             ancilla_dict_color[index_1_color].append((code.qubit_list[-1],'z'))
#             check_list_x_fixed_color.append(MajoranaOperator(x_vector_temp, z_vector_temp,1))
#             if associate_list is not None:
#                 x_vector_temp=[code.qubit_list[-4],code.qubit_list[-1]]
#                 z_vector_temp=[code.qubit_list[-4],code.qubit_list[-1]]
#             else:
#                 x_vector_temp=[code.qubit_list[-2],code.qubit_list[-1]]
#                 z_vector_temp=[code.qubit_list[-2],code.qubit_list[-1]]
#             check_list_gauge.append(MajoranaOperator(x_vector_temp, z_vector_temp,1))
#
#     for i in range(len(single_plaqutte)):
#         if single_plaqutte[i] is not None:
#             operator_color_temp=check_list_x_fix_color[single_plaqutte[i]]
#             overlap=list(set(operator_color_temp.x_vector)&set(support_index_vector_color))
#             x_vector_temp = operator_color_temp.x_vector.copy()
#             z_vector_temp = operator_color_temp.z_vector.copy()
#             code.push_qubit(2)
#             ancilla_dict_color[overlap[0]].append((code.qubit_list[-1], 'x'))
#             ancilla_dict_color[overlap[0]].append((code.qubit_list[-2], 'x'))
#             ancilla_dict_color[overlap[1]].append((code.qubit_list[-1], 'z'))
#             ancilla_dict_color[overlap[1]].append((code.qubit_list[-2], 'z'))
#             x_vector_temp=np.append(x_vector_temp,code.qubit_list[-2])
#             z_vector_temp=np.append(z_vector_temp,code.qubit_list[-2])
#             check_list_x_fixed_color.append(MajoranaOperator(x_vector_temp, z_vector_temp, 1))
#             x_vector_temp = [code.qubit_list[-2], code.qubit_list[-1]]
#             z_vector_temp = [code.qubit_list[-2], code.qubit_list[-1]]
#             check_list_gauge.append(MajoranaOperator(x_vector_temp, z_vector_temp, 1))
#     check_list_measurement = []
#     for i in range(len(support_index_vector_ldpc)):
#         x_vector_temp=[support_index_vector_ldpc[i],support_index_vector_color[i]]
#         z_vector_temp=[]
#         for j in range(len(ancilla_dict_ldpc[support_index_vector_ldpc[i]])):
#             if ancilla_dict_ldpc[support_index_vector_ldpc[i]][j][1]=='x':
#                 x_vector_temp=np.append(x_vector_temp,ancilla_dict_ldpc[support_index_vector_ldpc[i]][j][0])
#             else:
#                 z_vector_temp = np.append(z_vector_temp, ancilla_dict_ldpc[support_index_vector_ldpc[i]][j][0])
#         for j in range(len(ancilla_dict_color[support_index_vector_color[i]])):
#             if ancilla_dict_color[support_index_vector_color[i]][j][1]=='x':
#                 x_vector_temp=np.append(x_vector_temp,ancilla_dict_color[support_index_vector_color[i]][j][0])
#             else:
#                 z_vector_temp = np.append(z_vector_temp, ancilla_dict_color[support_index_vector_color[i]][j][0])
#         check_list_measurement.append(MajoranaOperator(x_vector_temp, z_vector_temp, 1))
#     check_list_x_fixed_ldpc=check_list_x_fix_ldpc
#     code.check_list=check_list_x_unfix_ldpc+check_list_x_unfix_color
#     code.check_stable_list=check_list_x_unfix_ldpc+check_list_x_unfix_color+check_list_z_ldpc+check_list_z_color
#     code.check_list+=check_list_z_ldpc+check_list_z_color
#     code.check_list+=check_list_x_fixed_color+check_list_x_fixed_ldpc
#     code.check_fixed_list=check_list_x_fixed_color+check_list_x_fixed_ldpc
#     code.check_gauge_list=check_list_gauge
#     code.check_list+=check_list_gauge
#     code.ancilla_list=[]
#     code.stop=len(code.check_list)
#     code.check_list+=check_list_measurement
#     code.check_measure_list=check_list_measurement
#     for i in range(number_qubit_ldpc+number_qubit_color,code.number_qubit):
#         temp=MajoranaOperator([i],[i],1)
#         code.ancilla_list.append(temp)
#     code.number_checker=len(code.check_list)
#
#     #%%  SECTION：返回结果
#
#     assert code.commute_judge()  # 检查对易性
#     return code
