from extendedstim.Code.QuantumCode.MajoranaCode import MajoranaCode
from extendedstim.Code.QuantumCode.PauliCode import PauliCode
from extendedstim.Physics.MajoranaOperator import MajoranaOperator
from extendedstim.Physics.PauliOperator import PauliOperator
from extendedstim.tools.GaloisTools import minus, distance


class SubsystemCode:
    def __init__(self,code:MajoranaCode|PauliCode,gauges):
        self.code=code
        self.gauges=gauges
        if isinstance(code,MajoranaCode):
            self.code_type=MajoranaCode
            self.operator_type=MajoranaOperator
        elif isinstance(code,PauliCode):
            self.code_type=PauliCode
            self.operator_type=PauliOperator
        else:
            raise ValueError("code must be MajoranaCode or PauliCode")

    @property
    def logical_operators(self):
        result=self.code.logical_operators
        result=self.operator_type.get_matrix(result,self.code.physical_number)
        result=minus(result,self.operator_type.get_matrix(self.gauges,self.code.physical_number))
        results=[]
        for i in range(len(result)):
            results.append(self.operator_type.HermitianOperatorFromVector(result[i]))
        return results

    def get_distance(self,method):
        if method=='random':
            return distance(self.code.check_matrix,self.operator_type.get_matrix(self.gauges,self.code.physical_number))
        elif method=='mip':
            return distance(self.code.check_matrix,self.operator_type.get_matrix(self.gauges,self.code.physical_number),'mip')
        else:
            raise ValueError("method must be random or mip")
