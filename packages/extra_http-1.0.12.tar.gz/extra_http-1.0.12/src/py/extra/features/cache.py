# SEE: http://stackoverflow.com/questions/16386148/why-browser-do-not-follow-redirects-using-xmlhttprequest-and-cors/20854800#20854800


# TODO:
# @post
# def cache(
# ) -> HTTPResponse:
#     """Sets cache control parameters."""
#     def wrapper
#     request: HTTPRequest, response: HTTPResponse, cache: None = None
#     response.setHeader("Cache-Control", "None")
#     return response


# EOF
