from extremecloudiq.paths.account_external.get import ApiForget


class AccountExternal(
    ApiForget,
):
    pass
