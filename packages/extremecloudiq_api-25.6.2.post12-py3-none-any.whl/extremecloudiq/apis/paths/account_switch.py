from extremecloudiq.paths.account_switch.post import ApiForpost


class AccountSwitch(
    ApiForpost,
):
    pass
