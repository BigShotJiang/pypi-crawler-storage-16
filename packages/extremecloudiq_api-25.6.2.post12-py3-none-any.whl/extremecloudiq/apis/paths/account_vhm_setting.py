from extremecloudiq.paths.account_vhm_setting.get import ApiForget


class AccountVhmSetting(
    ApiForget,
):
    pass
