from extremecloudiq.paths.account_viq_default_device_password.get import ApiForget
from extremecloudiq.paths.account_viq_default_device_password.put import ApiForput


class AccountViqDefaultDevicePassword(
    ApiForget,
    ApiForput,
):
    pass
