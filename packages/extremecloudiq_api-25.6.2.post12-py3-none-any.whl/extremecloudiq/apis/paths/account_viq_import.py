from extremecloudiq.paths.account_viq_import.post import ApiForpost


class AccountViqImport(
    ApiForpost,
):
    pass
