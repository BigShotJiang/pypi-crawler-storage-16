from extremecloudiq.paths.acct_api_token.get import ApiForget
from extremecloudiq.paths.acct_api_token.post import ApiForpost


class AcctApiToken(
    ApiForget,
    ApiForpost,
):
    pass
