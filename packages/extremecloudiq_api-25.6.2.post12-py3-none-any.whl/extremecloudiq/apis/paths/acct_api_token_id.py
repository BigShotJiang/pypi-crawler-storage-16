from extremecloudiq.paths.acct_api_token_id.delete import ApiFordelete
from extremecloudiq.paths.acct_api_token_id.patch import ApiForpatch


class AcctApiTokenId(
    ApiFordelete,
    ApiForpatch,
):
    pass
