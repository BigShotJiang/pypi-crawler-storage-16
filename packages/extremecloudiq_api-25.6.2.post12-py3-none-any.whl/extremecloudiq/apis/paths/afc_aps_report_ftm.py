from extremecloudiq.paths.afc_aps_report_ftm.post import ApiForpost


class AfcApsReportFtm(
    ApiForpost,
):
    pass
