from extremecloudiq.paths.afc_export.post import ApiForpost


class AfcExport(
    ApiForpost,
):
    pass
