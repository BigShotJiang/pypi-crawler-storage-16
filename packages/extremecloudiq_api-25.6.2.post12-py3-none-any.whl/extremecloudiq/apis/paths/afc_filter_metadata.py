from extremecloudiq.paths.afc_filter_metadata.post import ApiForpost


class AfcFilterMetadata(
    ApiForpost,
):
    pass
