from extremecloudiq.paths.afc_reports_id.get import ApiForget


class AfcReportsId(
    ApiForget,
):
    pass
