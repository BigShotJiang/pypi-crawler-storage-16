from extremecloudiq.paths.afc_rm_devices_page.post import ApiForpost


class AfcRmDevicesPage(
    ApiForpost,
):
    pass
