from extremecloudiq.paths.afcserver_statistics_server_id.get import ApiForget


class AfcserverStatisticsServerId(
    ApiForget,
):
    pass
