from extremecloudiq.paths.airrm_ap_radio_info_.post import ApiForpost


class AirrmApRadioInfo(
    ApiForpost,
):
    pass
