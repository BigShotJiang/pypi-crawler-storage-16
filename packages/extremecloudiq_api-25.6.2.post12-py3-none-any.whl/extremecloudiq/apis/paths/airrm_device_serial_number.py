from extremecloudiq.paths.airrm_device_serial_number.get import ApiForget


class AirrmDeviceSerialNumber(
    ApiForget,
):
    pass
