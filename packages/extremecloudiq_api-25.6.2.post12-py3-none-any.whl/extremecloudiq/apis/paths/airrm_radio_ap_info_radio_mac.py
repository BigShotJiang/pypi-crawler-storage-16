from extremecloudiq.paths.airrm_radio_ap_info_radio_mac.get import ApiForget


class AirrmRadioApInfoRadioMac(
    ApiForget,
):
    pass
