from extremecloudiq.paths.airrm_site_airrm_id.get import ApiForget


class AirrmSiteAirrmId(
    ApiForget,
):
    pass
