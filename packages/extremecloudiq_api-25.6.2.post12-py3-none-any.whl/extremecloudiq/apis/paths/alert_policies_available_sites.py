from extremecloudiq.paths.alert_policies_available_sites.get import ApiForget


class AlertPoliciesAvailableSites(
    ApiForget,
):
    pass
