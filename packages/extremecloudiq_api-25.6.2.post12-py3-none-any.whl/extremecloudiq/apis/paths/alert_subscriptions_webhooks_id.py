from extremecloudiq.paths.alert_subscriptions_webhooks_id.get import ApiForget
from extremecloudiq.paths.alert_subscriptions_webhooks_id.put import ApiForput
from extremecloudiq.paths.alert_subscriptions_webhooks_id.delete import ApiFordelete


class AlertSubscriptionsWebhooksId(
    ApiForget,
    ApiForput,
    ApiFordelete,
):
    pass
