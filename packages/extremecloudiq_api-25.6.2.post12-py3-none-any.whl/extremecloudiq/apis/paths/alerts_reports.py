from extremecloudiq.paths.alerts_reports.post import ApiForpost


class AlertsReports(
    ApiForpost,
):
    pass
