from extremecloudiq.paths.ap_afc_diagnostics_id.get import ApiForget


class ApAfcDiagnosticsId(
    ApiForget,
):
    pass
