from extremecloudiq.paths.ap_afc_floor_report_device_id.get import ApiForget


class ApAfcFloorReportDeviceId(
    ApiForget,
):
    pass
