from extremecloudiq.paths.ap_afc_interface_details_sn.get import ApiForget


class ApAfcInterfaceDetailsSn(
    ApiForget,
):
    pass
