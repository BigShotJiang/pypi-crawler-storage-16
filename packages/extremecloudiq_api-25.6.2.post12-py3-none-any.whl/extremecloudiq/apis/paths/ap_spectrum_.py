from extremecloudiq.paths.ap_spectrum_.post import ApiForpost


class ApSpectrum(
    ApiForpost,
):
    pass
