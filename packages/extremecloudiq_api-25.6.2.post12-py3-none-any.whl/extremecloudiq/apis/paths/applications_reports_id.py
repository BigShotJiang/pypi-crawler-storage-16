from extremecloudiq.paths.applications_reports_id.get import ApiForget


class ApplicationsReportsId(
    ApiForget,
):
    pass
