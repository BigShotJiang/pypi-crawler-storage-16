from extremecloudiq.paths.applications_topn.get import ApiForget


class ApplicationsTopn(
    ApiForget,
):
    pass
