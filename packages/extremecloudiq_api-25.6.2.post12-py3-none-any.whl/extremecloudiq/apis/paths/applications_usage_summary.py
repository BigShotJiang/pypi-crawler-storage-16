from extremecloudiq.paths.applications_usage_summary.post import ApiForpost


class ApplicationsUsageSummary(
    ApiForpost,
):
    pass
