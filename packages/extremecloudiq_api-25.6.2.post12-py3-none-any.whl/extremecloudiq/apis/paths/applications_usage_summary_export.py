from extremecloudiq.paths.applications_usage_summary_export.post import ApiForpost


class ApplicationsUsageSummaryExport(
    ApiForpost,
):
    pass
