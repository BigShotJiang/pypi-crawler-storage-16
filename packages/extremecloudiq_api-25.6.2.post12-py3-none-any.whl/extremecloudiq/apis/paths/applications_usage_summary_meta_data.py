from extremecloudiq.paths.applications_usage_summary_meta_data.get import ApiForget


class ApplicationsUsageSummaryMetaData(
    ApiForget,
):
    pass
