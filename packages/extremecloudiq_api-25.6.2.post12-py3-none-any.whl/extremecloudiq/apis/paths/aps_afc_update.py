from extremecloudiq.paths.aps_afc_update.post import ApiForpost


class ApsAfcUpdate(
    ApiForpost,
):
    pass
