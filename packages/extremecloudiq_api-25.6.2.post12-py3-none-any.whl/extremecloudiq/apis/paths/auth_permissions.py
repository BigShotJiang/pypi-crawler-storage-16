from extremecloudiq.paths.auth_permissions.get import ApiForget


class AuthPermissions(
    ApiForget,
):
    pass
