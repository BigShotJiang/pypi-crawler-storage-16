from extremecloudiq.paths.backup_history_grid.get import ApiForget


class BackupHistoryGrid(
    ApiForget,
):
    pass
