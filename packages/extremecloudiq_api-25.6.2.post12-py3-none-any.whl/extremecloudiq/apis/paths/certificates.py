from extremecloudiq.paths.certificates.get import ApiForget


class Certificates(
    ApiForget,
):
    pass
