from extremecloudiq.paths.certificates_id.delete import ApiFordelete


class CertificatesId(
    ApiFordelete,
):
    pass
