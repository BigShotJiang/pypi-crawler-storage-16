from extremecloudiq.paths.certificates_import.post import ApiForpost


class CertificatesImport(
    ApiForpost,
):
    pass
