from extremecloudiq.paths.client_details_client_trail_roaming_trail_grid_client_id.get import ApiForget


class ClientDetailsClientTrailRoamingTrailGridClientId(
    ApiForget,
):
    pass
