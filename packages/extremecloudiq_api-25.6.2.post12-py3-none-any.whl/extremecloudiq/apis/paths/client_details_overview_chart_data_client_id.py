from extremecloudiq.paths.client_details_overview_chart_data_client_id.get import ApiForget


class ClientDetailsOverviewChartDataClientId(
    ApiForget,
):
    pass
