from extremecloudiq.paths.client_details_overview_info_client_id.get import ApiForget


class ClientDetailsOverviewInfoClientId(
    ApiForget,
):
    pass
