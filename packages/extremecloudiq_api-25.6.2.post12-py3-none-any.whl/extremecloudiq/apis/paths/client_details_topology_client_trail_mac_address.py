from extremecloudiq.paths.client_details_topology_client_trail_mac_address.get import ApiForget


class ClientDetailsTopologyClientTrailMacAddress(
    ApiForget,
):
    pass
