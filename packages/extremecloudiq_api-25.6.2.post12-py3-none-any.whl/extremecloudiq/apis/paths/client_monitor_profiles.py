from extremecloudiq.paths.client_monitor_profiles.get import ApiForget
from extremecloudiq.paths.client_monitor_profiles.post import ApiForpost


class ClientMonitorProfiles(
    ApiForget,
    ApiForpost,
):
    pass
