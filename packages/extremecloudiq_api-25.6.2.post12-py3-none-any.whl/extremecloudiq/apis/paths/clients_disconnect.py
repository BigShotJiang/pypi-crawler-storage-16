from extremecloudiq.paths.clients_disconnect.post import ApiForpost


class ClientsDisconnect(
    ApiForpost,
):
    pass
