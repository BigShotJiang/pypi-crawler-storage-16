from extremecloudiq.paths.copilot_anomalies_adverse_traffic_packet_counts.get import ApiForget


class CopilotAnomaliesAdverseTrafficPacketCounts(
    ApiForget,
):
    pass
