from extremecloudiq.paths.copilot_anomalies_devices_by_location.get import ApiForget


class CopilotAnomaliesDevicesByLocation(
    ApiForget,
):
    pass
