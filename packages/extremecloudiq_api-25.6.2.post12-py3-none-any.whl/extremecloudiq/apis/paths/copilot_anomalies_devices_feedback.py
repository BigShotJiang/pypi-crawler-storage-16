from extremecloudiq.paths.copilot_anomalies_devices_feedback.put import ApiForput


class CopilotAnomaliesDevicesFeedback(
    ApiForput,
):
    pass
