from extremecloudiq.paths.copilot_anomalies_missing_vlan_count.get import ApiForget


class CopilotAnomaliesMissingVlanCount(
    ApiForget,
):
    pass
