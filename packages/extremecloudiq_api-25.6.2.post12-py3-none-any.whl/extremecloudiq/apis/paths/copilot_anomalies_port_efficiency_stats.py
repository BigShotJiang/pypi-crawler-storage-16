from extremecloudiq.paths.copilot_anomalies_port_efficiency_stats.get import ApiForget


class CopilotAnomaliesPortEfficiencyStats(
    ApiForget,
):
    pass
