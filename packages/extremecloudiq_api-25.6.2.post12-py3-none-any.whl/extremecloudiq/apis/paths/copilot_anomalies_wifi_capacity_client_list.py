from extremecloudiq.paths.copilot_anomalies_wifi_capacity_client_list.get import ApiForget


class CopilotAnomaliesWifiCapacityClientList(
    ApiForget,
):
    pass
