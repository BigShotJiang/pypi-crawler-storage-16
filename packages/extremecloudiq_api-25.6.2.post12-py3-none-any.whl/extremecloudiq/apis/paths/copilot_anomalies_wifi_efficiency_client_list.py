from extremecloudiq.paths.copilot_anomalies_wifi_efficiency_client_list.get import ApiForget


class CopilotAnomaliesWifiEfficiencyClientList(
    ApiForget,
):
    pass
