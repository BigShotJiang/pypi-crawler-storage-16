from extremecloudiq.paths.copilot_connectivity_client_type.get import ApiForget


class CopilotConnectivityClientType(
    ApiForget,
):
    pass
