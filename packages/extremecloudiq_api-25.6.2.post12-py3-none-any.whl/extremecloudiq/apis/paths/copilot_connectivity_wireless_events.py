from extremecloudiq.paths.copilot_connectivity_wireless_events.get import ApiForget


class CopilotConnectivityWirelessEvents(
    ApiForget,
):
    pass
