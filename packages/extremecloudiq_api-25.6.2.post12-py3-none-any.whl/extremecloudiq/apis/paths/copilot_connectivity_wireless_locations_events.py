from extremecloudiq.paths.copilot_connectivity_wireless_locations_events.get import ApiForget


class CopilotConnectivityWirelessLocationsEvents(
    ApiForget,
):
    pass
