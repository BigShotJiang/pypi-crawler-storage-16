from extremecloudiq.paths.copilot_connectivity_wireless_locations_time_to_connect.get import ApiForget


class CopilotConnectivityWirelessLocationsTimeToConnect(
    ApiForget,
):
    pass
