from extremecloudiq.paths.copilot_connectivity_wireless_time_to_connect.get import ApiForget


class CopilotConnectivityWirelessTimeToConnect(
    ApiForget,
):
    pass
