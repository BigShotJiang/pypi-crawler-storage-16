from extremecloudiq.paths.copilot_connectivity_wireless_views.get import ApiForget


class CopilotConnectivityWirelessViews(
    ApiForget,
):
    pass
