from extremecloudiq.paths.countries.get import ApiForget


class Countries(
    ApiForget,
):
    pass
