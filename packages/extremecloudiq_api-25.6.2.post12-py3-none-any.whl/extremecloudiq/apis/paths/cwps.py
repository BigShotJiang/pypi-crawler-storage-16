from extremecloudiq.paths.cwps.get import ApiForget


class Cwps(
    ApiForget,
):
    pass
