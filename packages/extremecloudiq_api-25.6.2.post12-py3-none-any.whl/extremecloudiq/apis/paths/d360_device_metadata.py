from extremecloudiq.paths.d360_device_metadata.get import ApiForget


class D360DeviceMetadata(
    ApiForget,
):
    pass
