from extremecloudiq.paths.d360_event_graph.get import ApiForget


class D360EventGraph(
    ApiForget,
):
    pass
