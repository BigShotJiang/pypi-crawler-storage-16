from extremecloudiq.paths.d360_overview_devices_summary.get import ApiForget


class D360OverviewDevicesSummary(
    ApiForget,
):
    pass
