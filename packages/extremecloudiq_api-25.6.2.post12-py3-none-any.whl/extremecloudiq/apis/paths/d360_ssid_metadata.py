from extremecloudiq.paths.d360_ssid_metadata.get import ApiForget


class D360SsidMetadata(
    ApiForget,
):
    pass
