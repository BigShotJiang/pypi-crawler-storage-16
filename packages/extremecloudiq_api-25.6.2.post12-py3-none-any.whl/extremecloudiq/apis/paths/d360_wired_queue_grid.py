from extremecloudiq.paths.d360_wired_queue_grid.get import ApiForget


class D360WiredQueueGrid(
    ApiForget,
):
    pass
