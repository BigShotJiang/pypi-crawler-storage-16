from extremecloudiq.paths.d360_wireless_interfaces_stats.get import ApiForget


class D360WirelessInterfacesStats(
    ApiForget,
):
    pass
