from extremecloudiq.paths.dashboard_wired_client_health_grid.post import ApiForpost


class DashboardWiredClientHealthGrid(
    ApiForpost,
):
    pass
