from extremecloudiq.paths.dashboard_wired_device_health_fan_issues.post import ApiForpost


class DashboardWiredDeviceHealthFanIssues(
    ApiForpost,
):
    pass
