from extremecloudiq.paths.dashboard_wired_device_health_fan_status.post import ApiForpost


class DashboardWiredDeviceHealthFanStatus(
    ApiForpost,
):
    pass
