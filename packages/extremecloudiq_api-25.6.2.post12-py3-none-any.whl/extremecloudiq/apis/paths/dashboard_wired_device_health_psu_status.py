from extremecloudiq.paths.dashboard_wired_device_health_psu_status.post import ApiForpost


class DashboardWiredDeviceHealthPsuStatus(
    ApiForpost,
):
    pass
