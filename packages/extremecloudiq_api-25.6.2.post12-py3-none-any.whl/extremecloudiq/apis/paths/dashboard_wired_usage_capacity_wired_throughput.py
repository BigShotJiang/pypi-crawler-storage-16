from extremecloudiq.paths.dashboard_wired_usage_capacity_wired_throughput.post import ApiForpost


class DashboardWiredUsageCapacityWiredThroughput(
    ApiForpost,
):
    pass
