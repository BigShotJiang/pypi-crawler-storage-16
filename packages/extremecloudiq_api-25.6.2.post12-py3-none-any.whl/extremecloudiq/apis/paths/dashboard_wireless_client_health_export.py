from extremecloudiq.paths.dashboard_wireless_client_health_export.post import ApiForpost


class DashboardWirelessClientHealthExport(
    ApiForpost,
):
    pass
