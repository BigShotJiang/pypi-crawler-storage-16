from extremecloudiq.paths.dashboard_wireless_client_health_filter_metadata.post import ApiForpost


class DashboardWirelessClientHealthFilterMetadata(
    ApiForpost,
):
    pass
