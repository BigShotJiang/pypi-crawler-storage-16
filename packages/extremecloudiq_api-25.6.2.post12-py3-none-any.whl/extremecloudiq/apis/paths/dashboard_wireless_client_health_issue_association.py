from extremecloudiq.paths.dashboard_wireless_client_health_issue_association.post import ApiForpost


class DashboardWirelessClientHealthIssueAssociation(
    ApiForpost,
):
    pass
