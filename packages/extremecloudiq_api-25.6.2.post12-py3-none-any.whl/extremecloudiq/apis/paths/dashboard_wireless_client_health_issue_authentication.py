from extremecloudiq.paths.dashboard_wireless_client_health_issue_authentication.post import ApiForpost


class DashboardWirelessClientHealthIssueAuthentication(
    ApiForpost,
):
    pass
