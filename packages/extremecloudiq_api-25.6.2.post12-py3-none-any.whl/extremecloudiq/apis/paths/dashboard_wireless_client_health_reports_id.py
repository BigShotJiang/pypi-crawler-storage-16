from extremecloudiq.paths.dashboard_wireless_client_health_reports_id.get import ApiForget


class DashboardWirelessClientHealthReportsId(
    ApiForget,
):
    pass
