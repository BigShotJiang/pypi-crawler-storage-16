from extremecloudiq.paths.dashboard_wireless_device_health_grid.post import ApiForpost


class DashboardWirelessDeviceHealthGrid(
    ApiForpost,
):
    pass
