from extremecloudiq.paths.dashboard_wireless_device_health_issues_cpu_usage_issues.post import ApiForpost


class DashboardWirelessDeviceHealthIssuesCpuUsageIssues(
    ApiForpost,
):
    pass
