from extremecloudiq.paths.dashboard_wireless_device_health_summary.post import ApiForpost


class DashboardWirelessDeviceHealthSummary(
    ApiForpost,
):
    pass
