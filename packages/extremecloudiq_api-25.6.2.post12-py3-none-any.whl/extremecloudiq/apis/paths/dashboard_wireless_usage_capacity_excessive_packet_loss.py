from extremecloudiq.paths.dashboard_wireless_usage_capacity_excessive_packet_loss.post import ApiForpost


class DashboardWirelessUsageCapacityExcessivePacketLoss(
    ApiForpost,
):
    pass
