from extremecloudiq.paths.deployments.get import ApiForget
from extremecloudiq.paths.deployments.post import ApiForpost


class Deployments(
    ApiForget,
    ApiForpost,
):
    pass
