from extremecloudiq.paths.deployments_firmware_metadatas.post import ApiForpost


class DeploymentsFirmwareMetadatas(
    ApiForpost,
):
    pass
