from extremecloudiq.paths.deployments_overview.get import ApiForget


class DeploymentsOverview(
    ApiForget,
):
    pass
