from extremecloudiq.paths.devices.get import ApiForget


class Devices(
    ApiForget,
):
    pass
