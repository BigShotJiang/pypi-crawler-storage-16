from extremecloudiq.paths.devices_advanced_onboard.post import ApiForpost


class DevicesAdvancedOnboard(
    ApiForpost,
):
    pass
