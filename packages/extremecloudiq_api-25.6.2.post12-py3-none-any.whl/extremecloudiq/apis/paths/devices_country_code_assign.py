from extremecloudiq.paths.devices_country_code_assign.post import ApiForpost


class DevicesCountryCodeAssign(
    ApiForpost,
):
    pass
