from extremecloudiq.paths.devices_id_alarms.get import ApiForget


class DevicesIdAlarms(
    ApiForget,
):
    pass
