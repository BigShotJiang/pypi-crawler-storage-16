from extremecloudiq.paths.devices_id_cli.post import ApiForpost


class DevicesIdCli(
    ApiForpost,
):
    pass
