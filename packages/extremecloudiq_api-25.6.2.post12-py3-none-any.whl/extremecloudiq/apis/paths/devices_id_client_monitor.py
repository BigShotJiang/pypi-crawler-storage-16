from extremecloudiq.paths.devices_id_client_monitor.get import ApiForget
from extremecloudiq.paths.devices_id_client_monitor.put import ApiForput
from extremecloudiq.paths.devices_id_client_monitor.delete import ApiFordelete


class DevicesIdClientMonitor(
    ApiForget,
    ApiForput,
    ApiFordelete,
):
    pass
