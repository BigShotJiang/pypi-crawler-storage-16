from extremecloudiq.paths.devices_id_installation_report.get import ApiForget


class DevicesIdInstallationReport(
    ApiForget,
):
    pass
