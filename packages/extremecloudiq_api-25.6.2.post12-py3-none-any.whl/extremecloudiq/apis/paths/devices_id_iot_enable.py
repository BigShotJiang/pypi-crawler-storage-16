from extremecloudiq.paths.devices_id_iot_enable.post import ApiForpost


class DevicesIdIotEnable(
    ApiForpost,
):
    pass
