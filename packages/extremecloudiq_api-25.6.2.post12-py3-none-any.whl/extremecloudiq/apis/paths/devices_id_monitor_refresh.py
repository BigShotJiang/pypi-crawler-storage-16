from extremecloudiq.paths.devices_id_monitor_refresh.post import ApiForpost


class DevicesIdMonitorRefresh(
    ApiForpost,
):
    pass
