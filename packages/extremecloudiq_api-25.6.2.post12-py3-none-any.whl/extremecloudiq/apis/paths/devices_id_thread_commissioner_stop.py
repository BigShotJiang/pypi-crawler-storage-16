from extremecloudiq.paths.devices_id_thread_commissioner_stop.post import ApiForpost


class DevicesIdThreadCommissionerStop(
    ApiForpost,
):
    pass
