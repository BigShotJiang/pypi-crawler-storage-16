from extremecloudiq.paths.devices_location_assign.post import ApiForpost


class DevicesLocationAssign(
    ApiForpost,
):
    pass
