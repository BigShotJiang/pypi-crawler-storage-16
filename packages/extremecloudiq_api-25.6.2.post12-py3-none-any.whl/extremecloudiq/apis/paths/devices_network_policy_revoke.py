from extremecloudiq.paths.devices_network_policy_revoke.post import ApiForpost


class DevicesNetworkPolicyRevoke(
    ApiForpost,
):
    pass
