from extremecloudiq.paths.devices_ssh_active_sessions.post import ApiForpost


class DevicesSshActiveSessions(
    ApiForpost,
):
    pass
