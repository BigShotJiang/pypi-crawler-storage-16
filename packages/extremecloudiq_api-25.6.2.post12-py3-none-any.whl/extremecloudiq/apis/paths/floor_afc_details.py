from extremecloudiq.paths.floor_afc_details.get import ApiForget
from extremecloudiq.paths.floor_afc_details.put import ApiForput
from extremecloudiq.paths.floor_afc_details.post import ApiForpost


class FloorAfcDetails(
    ApiForget,
    ApiForput,
    ApiForpost,
):
    pass
