from extremecloudiq.paths.geo_view.get import ApiForget


class GeoView(
    ApiForget,
):
    pass
