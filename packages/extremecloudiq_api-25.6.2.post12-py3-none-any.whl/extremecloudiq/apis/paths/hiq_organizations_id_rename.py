from extremecloudiq.paths.hiq_organizations_id_rename.post import ApiForpost


class HiqOrganizationsIdRename(
    ApiForpost,
):
    pass
