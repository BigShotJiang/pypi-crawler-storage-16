from extremecloudiq.paths.hotspot_profiles.get import ApiForget
from extremecloudiq.paths.hotspot_profiles.post import ApiForpost


class HotspotProfiles(
    ApiForget,
    ApiForpost,
):
    pass
