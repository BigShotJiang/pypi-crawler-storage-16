from extremecloudiq.paths.hotspot_profiles_id.get import ApiForget
from extremecloudiq.paths.hotspot_profiles_id.put import ApiForput
from extremecloudiq.paths.hotspot_profiles_id.delete import ApiFordelete


class HotspotProfilesId(
    ApiForget,
    ApiForput,
    ApiFordelete,
):
    pass
