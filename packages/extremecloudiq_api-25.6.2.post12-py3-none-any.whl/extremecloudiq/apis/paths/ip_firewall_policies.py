from extremecloudiq.paths.ip_firewall_policies.get import ApiForget
from extremecloudiq.paths.ip_firewall_policies.post import ApiForpost


class IpFirewallPolicies(
    ApiForget,
    ApiForpost,
):
    pass
