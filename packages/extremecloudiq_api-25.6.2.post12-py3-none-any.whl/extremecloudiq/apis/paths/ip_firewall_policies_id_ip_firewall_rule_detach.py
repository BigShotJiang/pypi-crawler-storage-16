from extremecloudiq.paths.ip_firewall_policies_id_ip_firewall_rule_detach.post import ApiForpost


class IpFirewallPoliciesIdIpFirewallRuleDetach(
    ApiForpost,
):
    pass
