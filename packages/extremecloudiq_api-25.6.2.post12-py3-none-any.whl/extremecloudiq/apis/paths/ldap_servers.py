from extremecloudiq.paths.ldap_servers.get import ApiForget
from extremecloudiq.paths.ldap_servers.post import ApiForpost


class LdapServers(
    ApiForget,
    ApiForpost,
):
    pass
