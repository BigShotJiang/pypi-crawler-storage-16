from extremecloudiq.paths.locations_site.get import ApiForget
from extremecloudiq.paths.locations_site.post import ApiForpost


class LocationsSite(
    ApiForget,
    ApiForpost,
):
    pass
