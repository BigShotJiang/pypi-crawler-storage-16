from extremecloudiq.paths.locations_wall_type_id.put import ApiForput
from extremecloudiq.paths.locations_wall_type_id.delete import ApiFordelete


class LocationsWallTypeId(
    ApiForput,
    ApiFordelete,
):
    pass
