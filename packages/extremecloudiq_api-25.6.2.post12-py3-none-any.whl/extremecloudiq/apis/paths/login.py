from extremecloudiq.paths.login.post import ApiForpost


class Login(
    ApiForpost,
):
    pass
