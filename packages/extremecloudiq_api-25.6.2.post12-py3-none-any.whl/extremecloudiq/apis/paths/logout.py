from extremecloudiq.paths.logout.post import ApiForpost


class Logout(
    ApiForpost,
):
    pass
