from extremecloudiq.paths.logs_audit_reports.post import ApiForpost


class LogsAuditReports(
    ApiForpost,
):
    pass
