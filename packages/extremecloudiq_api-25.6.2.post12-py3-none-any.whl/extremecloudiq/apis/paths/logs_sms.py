from extremecloudiq.paths.logs_sms.get import ApiForget


class LogsSms(
    ApiForget,
):
    pass
