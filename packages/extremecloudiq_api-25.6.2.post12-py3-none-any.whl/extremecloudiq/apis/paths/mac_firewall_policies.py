from extremecloudiq.paths.mac_firewall_policies.get import ApiForget
from extremecloudiq.paths.mac_firewall_policies.post import ApiForpost


class MacFirewallPolicies(
    ApiForget,
    ApiForpost,
):
    pass
