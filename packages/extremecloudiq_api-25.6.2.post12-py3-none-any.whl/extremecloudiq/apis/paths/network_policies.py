from extremecloudiq.paths.network_policies.get import ApiForget
from extremecloudiq.paths.network_policies.post import ApiForpost


class NetworkPolicies(
    ApiForget,
    ApiForpost,
):
    pass
