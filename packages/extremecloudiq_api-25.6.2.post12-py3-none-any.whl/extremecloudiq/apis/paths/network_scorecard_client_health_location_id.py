from extremecloudiq.paths.network_scorecard_client_health_location_id.get import ApiForget


class NetworkScorecardClientHealthLocationId(
    ApiForget,
):
    pass
