from extremecloudiq.paths.ng_reports_download_reports_id.get import ApiForget


class NgReportsDownloadReportsId(
    ApiForget,
):
    pass
