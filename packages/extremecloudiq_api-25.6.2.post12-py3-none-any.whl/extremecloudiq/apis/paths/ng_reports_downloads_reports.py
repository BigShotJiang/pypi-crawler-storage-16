from extremecloudiq.paths.ng_reports_downloads_reports.post import ApiForpost


class NgReportsDownloadsReports(
    ApiForpost,
):
    pass
