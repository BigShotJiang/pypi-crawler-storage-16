from extremecloudiq.paths.ng_reports_information_.get import ApiForget


class NgReportsInformation(
    ApiForget,
):
    pass
