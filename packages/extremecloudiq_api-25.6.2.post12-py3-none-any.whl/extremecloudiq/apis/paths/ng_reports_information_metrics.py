from extremecloudiq.paths.ng_reports_information_metrics.get import ApiForget


class NgReportsInformationMetrics(
    ApiForget,
):
    pass
