from extremecloudiq.paths.ng_reports_metadata_application.post import ApiForpost


class NgReportsMetadataApplication(
    ApiForpost,
):
    pass
