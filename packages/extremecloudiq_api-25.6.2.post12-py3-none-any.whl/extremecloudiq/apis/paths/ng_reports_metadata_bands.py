from extremecloudiq.paths.ng_reports_metadata_bands.post import ApiForpost


class NgReportsMetadataBands(
    ApiForpost,
):
    pass
