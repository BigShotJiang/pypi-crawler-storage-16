from extremecloudiq.paths.ng_reports_metadata_channel.post import ApiForpost


class NgReportsMetadataChannel(
    ApiForpost,
):
    pass
