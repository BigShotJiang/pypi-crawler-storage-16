from extremecloudiq.paths.ng_reports_metadata_client.post import ApiForpost


class NgReportsMetadataClient(
    ApiForpost,
):
    pass
