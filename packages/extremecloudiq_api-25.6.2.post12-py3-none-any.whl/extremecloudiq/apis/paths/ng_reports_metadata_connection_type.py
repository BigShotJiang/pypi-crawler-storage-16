from extremecloudiq.paths.ng_reports_metadata_connection_type.post import ApiForpost


class NgReportsMetadataConnectionType(
    ApiForpost,
):
    pass
