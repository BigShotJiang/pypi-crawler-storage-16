from extremecloudiq.paths.ng_reports_metadata_device.post import ApiForpost


class NgReportsMetadataDevice(
    ApiForpost,
):
    pass
