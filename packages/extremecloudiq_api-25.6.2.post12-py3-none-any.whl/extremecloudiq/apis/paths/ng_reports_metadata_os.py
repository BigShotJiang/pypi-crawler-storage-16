from extremecloudiq.paths.ng_reports_metadata_os.post import ApiForpost


class NgReportsMetadataOs(
    ApiForpost,
):
    pass
