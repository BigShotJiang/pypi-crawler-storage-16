from extremecloudiq.paths.ng_reports_metadata_ssids.post import ApiForpost


class NgReportsMetadataSsids(
    ApiForpost,
):
    pass
