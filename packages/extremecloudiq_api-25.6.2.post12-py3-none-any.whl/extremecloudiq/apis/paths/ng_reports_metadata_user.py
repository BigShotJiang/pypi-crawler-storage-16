from extremecloudiq.paths.ng_reports_metadata_user.post import ApiForpost


class NgReportsMetadataUser(
    ApiForpost,
):
    pass
