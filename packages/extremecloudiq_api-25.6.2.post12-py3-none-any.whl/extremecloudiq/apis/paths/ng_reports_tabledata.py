from extremecloudiq.paths.ng_reports_tabledata.post import ApiForpost


class NgReportsTabledata(
    ApiForpost,
):
    pass
