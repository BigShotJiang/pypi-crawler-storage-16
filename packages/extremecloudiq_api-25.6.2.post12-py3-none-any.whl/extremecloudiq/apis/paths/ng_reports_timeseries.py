from extremecloudiq.paths.ng_reports_timeseries.post import ApiForpost


class NgReportsTimeseries(
    ApiForpost,
):
    pass
