from extremecloudiq.paths.radio_profiles.get import ApiForget
from extremecloudiq.paths.radio_profiles.post import ApiForpost


class RadioProfiles(
    ApiForget,
    ApiForpost,
):
    pass
