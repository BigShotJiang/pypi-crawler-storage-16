from extremecloudiq.paths.radio_profiles_miscellaneous_id.get import ApiForget
from extremecloudiq.paths.radio_profiles_miscellaneous_id.put import ApiForput


class RadioProfilesMiscellaneousId(
    ApiForget,
    ApiForput,
):
    pass
