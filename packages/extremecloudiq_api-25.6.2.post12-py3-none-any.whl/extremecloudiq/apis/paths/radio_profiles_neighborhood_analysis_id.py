from extremecloudiq.paths.radio_profiles_neighborhood_analysis_id.get import ApiForget
from extremecloudiq.paths.radio_profiles_neighborhood_analysis_id.put import ApiForput


class RadioProfilesNeighborhoodAnalysisId(
    ApiForget,
    ApiForput,
):
    pass
