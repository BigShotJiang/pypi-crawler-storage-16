from extremecloudiq.paths.radio_profiles_sensor_scan_id.get import ApiForget
from extremecloudiq.paths.radio_profiles_sensor_scan_id.put import ApiForput


class RadioProfilesSensorScanId(
    ApiForget,
    ApiForput,
):
    pass
