from extremecloudiq.paths.radius_servers_external.get import ApiForget
from extremecloudiq.paths.radius_servers_external.post import ApiForpost


class RadiusServersExternal(
    ApiForget,
    ApiForpost,
):
    pass
