from extremecloudiq.paths.radsec_proxies.get import ApiForget
from extremecloudiq.paths.radsec_proxies.post import ApiForpost


class RadsecProxies(
    ApiForget,
    ApiForpost,
):
    pass
