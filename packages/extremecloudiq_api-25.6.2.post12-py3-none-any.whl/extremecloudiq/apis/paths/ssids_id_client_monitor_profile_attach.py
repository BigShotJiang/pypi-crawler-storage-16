from extremecloudiq.paths.ssids_id_client_monitor_profile_attach.post import ApiForpost


class SsidsIdClientMonitorProfileAttach(
    ApiForpost,
):
    pass
