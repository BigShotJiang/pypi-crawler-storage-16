from extremecloudiq.paths.ssids_id_cwp_attach.post import ApiForpost


class SsidsIdCwpAttach(
    ApiForpost,
):
    pass
