from extremecloudiq.paths.ssids_id_radius_client_profile_attach.post import ApiForpost


class SsidsIdRadiusClientProfileAttach(
    ApiForpost,
):
    pass
