from extremecloudiq.paths.switch_inspector_diagnostics.post import ApiForpost


class SwitchInspectorDiagnostics(
    ApiForpost,
):
    pass
