from extremecloudiq.paths.ucp_id_engines_installed.get import ApiForget


class UcpIdEnginesInstalled(
    ApiForget,
):
    pass
