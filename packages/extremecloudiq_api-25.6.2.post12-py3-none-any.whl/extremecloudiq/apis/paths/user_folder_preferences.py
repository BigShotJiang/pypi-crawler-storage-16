from extremecloudiq.paths.user_folder_preferences.get import ApiForget


class UserFolderPreferences(
    ApiForget,
):
    pass
