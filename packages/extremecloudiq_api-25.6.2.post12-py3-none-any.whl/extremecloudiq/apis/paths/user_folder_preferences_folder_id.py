from extremecloudiq.paths.user_folder_preferences_folder_id.post import ApiForpost


class UserFolderPreferencesFolderId(
    ApiForpost,
):
    pass
