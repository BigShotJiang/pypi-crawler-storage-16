from extremecloudiq.paths.users_data_usage.post import ApiForpost


class UsersDataUsage(
    ApiForpost,
):
    pass
