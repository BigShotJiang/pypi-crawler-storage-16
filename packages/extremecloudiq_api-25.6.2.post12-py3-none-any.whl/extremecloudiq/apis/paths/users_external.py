from extremecloudiq.paths.users_external.get import ApiForget
from extremecloudiq.paths.users_external.post import ApiForpost


class UsersExternal(
    ApiForget,
    ApiForpost,
):
    pass
