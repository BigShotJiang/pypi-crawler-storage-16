from extremecloudiq.paths.users_filter_metadata.post import ApiForpost


class UsersFilterMetadata(
    ApiForpost,
):
    pass
