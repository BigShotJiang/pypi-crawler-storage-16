from extremecloudiq.paths.users_grid.post import ApiForpost


class UsersGrid(
    ApiForpost,
):
    pass
