from extremecloudiq.paths.users_grid_export.post import ApiForpost


class UsersGridExport(
    ApiForpost,
):
    pass
