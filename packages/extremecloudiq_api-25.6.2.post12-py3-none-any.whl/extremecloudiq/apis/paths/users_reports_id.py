from extremecloudiq.paths.users_reports_id.get import ApiForget


class UsersReportsId(
    ApiForget,
):
    pass
