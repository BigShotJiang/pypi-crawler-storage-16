from extremecloudiq.paths.users_type_distribution.post import ApiForpost


class UsersTypeDistribution(
    ApiForpost,
):
    pass
