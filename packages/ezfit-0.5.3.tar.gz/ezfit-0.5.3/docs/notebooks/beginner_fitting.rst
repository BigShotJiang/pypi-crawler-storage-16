Beginner Fitting Tutorial
==========================

This tutorial introduces the basics of fitting experimental data using ezfit.

.. note::

   This tutorial is also available as a Jupyter notebook: :download:`01_beginner_fitting.ipynb <../../notebooks/01_beginner_fitting.ipynb>`

.. raw:: html
   :file: ../../notebooks/01_beginner_fitting.ipynb
