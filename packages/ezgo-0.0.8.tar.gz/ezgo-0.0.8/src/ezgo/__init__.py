#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ezgo - 宇树Go2机器狗Python控制库

这是一个用于控制宇树Go2机器狗的Python库，提供了简单易用的API接口。
支持运动控制、视频流获取、UI界面等功能。
"""

__version__ = "0.0.8"
__author__ = "ezgo"
__email__ = ""
__license__ = "MIT"

# 导入主要类
try:
    from .go2 import Go2
    from .camera import Camera
    from .ui import APP
    from .go2_camera import Go2Camera
    from .go2_vui import Go2VUI
except ImportError as e:
    print(f"警告: 无法导入部分模块: {e}")
    print("请确保已安装所有依赖包")
    Go2 = None
    Camera = None
    APP = None
    Go2Camera = None
    Go2VUI = None

# 定义公开的API
__all__ = [
    "Go2",
    "Camera", 
    "APP",
    "Go2Camera",
    "Go2VUI",
    "__version__"
]

