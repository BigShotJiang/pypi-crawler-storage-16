How to implement an adaptive transformer?
#########################################

(under construction)
