How to efficiently chain multiple processors?
#############################################

(under construction)
