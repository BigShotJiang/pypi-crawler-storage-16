How to use processors standalone (outside ezmsg)?
#################################################

(under construction)
