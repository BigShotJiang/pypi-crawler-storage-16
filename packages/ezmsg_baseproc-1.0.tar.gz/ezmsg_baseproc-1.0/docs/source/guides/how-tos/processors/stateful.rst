How to implement a stateful processor?
######################################

(under construction)
