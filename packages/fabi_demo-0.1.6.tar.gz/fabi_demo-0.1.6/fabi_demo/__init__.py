from . import cli
from .version import __version__
from .fabi_demo import DEMO

__all__ = (
    "__version__",
    "DEMO",
)
