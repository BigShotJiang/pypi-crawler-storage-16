"""
Fabra: Craft ML Features.
"""

__version__ = "2.0.2"
