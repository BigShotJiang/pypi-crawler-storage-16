"""
Fabra: Context infrastructure for AI applications.
"""

__version__ = "2.1.1"
