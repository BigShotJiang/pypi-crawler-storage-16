from setuptools import setup

# Configuration is defined in pyproject.toml
if __name__ == "__main__":
    setup()
