"""Capabilities defined in fabricatio-agent."""
