"""Capabilities defined in fabricatio-capabilities."""
