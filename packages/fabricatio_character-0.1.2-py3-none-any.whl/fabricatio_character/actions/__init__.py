"""Actions defined in fabricatio-character."""
