"""Actions defined in fabricatio-checkpoint."""
