"""Capabilities defined in fabricatio-checkpoint."""
