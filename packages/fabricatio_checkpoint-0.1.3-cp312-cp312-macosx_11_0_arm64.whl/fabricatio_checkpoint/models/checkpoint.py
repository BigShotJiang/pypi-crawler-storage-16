"""This module contains the models for the checkpoint."""
