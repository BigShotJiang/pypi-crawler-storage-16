"""Models defined in fabricatio-checkpoint."""
