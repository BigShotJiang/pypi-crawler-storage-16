"""Models defined in fabricatio-digest."""
