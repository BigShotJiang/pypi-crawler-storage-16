"""Workflows defined in fabricatio-digest."""
