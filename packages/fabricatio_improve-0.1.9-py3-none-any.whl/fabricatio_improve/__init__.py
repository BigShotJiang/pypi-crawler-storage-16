"""Fabricatio is a Python library for building llm app using event-based agent structure."""
