"""Capabilities defined in fabricatio-improve."""
