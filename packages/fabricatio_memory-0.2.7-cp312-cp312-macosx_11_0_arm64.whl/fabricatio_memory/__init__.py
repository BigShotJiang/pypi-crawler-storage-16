"""An Extension of fabricatio aiming to extend the context llm could handle.."""
