"""An extension of fabricatio, which provides mocks and other test utils.."""
