"""Capabilities defined in fabricatio-plot."""
