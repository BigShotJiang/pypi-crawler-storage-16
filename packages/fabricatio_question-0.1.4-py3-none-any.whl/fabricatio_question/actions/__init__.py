"""Actions defined in fabricatio-question."""
