"""Actions defined in fabricatio-rag."""
