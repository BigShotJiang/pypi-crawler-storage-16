"""Models defined in fabricatio-rag."""
