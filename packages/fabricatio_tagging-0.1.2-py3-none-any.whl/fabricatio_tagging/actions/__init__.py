"""Actions defined in fabricatio-tagging."""
