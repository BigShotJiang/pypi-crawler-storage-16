"""Capabilities defined in fabricatio-translate."""
