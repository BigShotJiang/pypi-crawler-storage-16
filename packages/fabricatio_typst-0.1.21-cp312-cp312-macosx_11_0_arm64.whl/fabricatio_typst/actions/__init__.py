"""A module containing some builtin actins."""

from fabricatio_core.utils import cfg

cfg(feats=["actions"])
