"""Actions defined in fabricatio-yue."""
