# Pyarmor 9.2.2 (pro), 007930, 2025-12-13T13:47:05.575597
from .pyarmor_runtime import __pyarmor__
