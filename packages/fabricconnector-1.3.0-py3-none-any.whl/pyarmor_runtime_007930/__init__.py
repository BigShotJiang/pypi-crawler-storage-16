# Pyarmor 9.2.2 (pro), 007930, 2025-12-14T14:06:15.113630
from .pyarmor_runtime import __pyarmor__
