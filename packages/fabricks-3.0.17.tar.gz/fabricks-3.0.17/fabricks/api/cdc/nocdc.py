from fabricks.cdc.nocdc import NoCDC

__all__ = ["NoCDC"]
