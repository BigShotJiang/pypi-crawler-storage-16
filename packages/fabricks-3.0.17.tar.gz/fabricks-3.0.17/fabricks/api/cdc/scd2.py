from fabricks.cdc.scd2 import SCD2

__all__ = ["SCD2"]
