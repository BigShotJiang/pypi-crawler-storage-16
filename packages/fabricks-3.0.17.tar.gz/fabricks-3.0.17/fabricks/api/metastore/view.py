from fabricks.metastore import View

create_or_replace_view = View.create_or_replace


__all__ = ["View", "create_or_replace_view"]
