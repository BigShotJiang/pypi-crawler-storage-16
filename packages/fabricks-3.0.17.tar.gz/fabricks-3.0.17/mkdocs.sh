uv run mkdocs gh-deploy
