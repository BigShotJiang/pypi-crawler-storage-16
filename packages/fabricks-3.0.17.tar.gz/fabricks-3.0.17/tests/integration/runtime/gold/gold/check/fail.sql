select 1 as dummy
