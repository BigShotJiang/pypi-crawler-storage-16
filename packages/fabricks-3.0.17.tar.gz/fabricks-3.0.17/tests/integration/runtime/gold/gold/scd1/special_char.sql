select `__key`, `Näàme`, `@Id`, `double Field!` from silver.prince_special_char__current s
