# fair_rec/__init__.py
from .model import TrustAwareBERT
from .loss import TrustWeightedLoss
from .trainer import Trainer
from .dataset import FashionReviewDataset