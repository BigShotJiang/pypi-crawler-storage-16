import torch
import numpy as np
import random
import os

def set_seed(seed=42):
    """실험 재현성을 위한 시드 고정 함수"""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    torch.backends.cudnn.deterministic = True

def calculate_trust_score_from_coeff(rating, text_len, coeffs):
    """
    Study 1의 회귀계수를 기반으로 Trust Score 계산
    (사용자가 데이터 전처리할 때 이 함수를 호출해서 쓰도록 함)
    """
    base_score = 1.0
    rating_score = coeffs.get(rating, 0.0)
    len_score = np.log1p(text_len) * 0.01
    return base_score + rating_score + len_score