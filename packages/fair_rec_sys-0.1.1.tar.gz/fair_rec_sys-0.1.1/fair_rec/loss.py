import torch
import torch.nn as nn

class TrustWeightedLoss(nn.Module):
    def __init__(self):
        super(TrustWeightedLoss, self).__init__()
        self.mse = nn.MSELoss(reduction='none') # 평균 내지 않고 개별 오차 계산

    def forward(self, predictions, targets, trust_weights):
        """
        predictions: 모델 예측값
        targets: 실제 평점
        trust_weights: 신뢰도 점수 (Study 1 결과)
        """
        loss = self.mse(predictions, targets)
        # 오차에 신뢰도 가중치를 곱함 (신뢰도 높은 리뷰 틀리면 벌칙 강화)
        weighted_loss = (loss * trust_weights).mean()
        return weighted_loss