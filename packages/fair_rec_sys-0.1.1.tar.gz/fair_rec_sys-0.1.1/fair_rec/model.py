import torch.nn as nn
from transformers import BertModel

class TrustAwareBERT(nn.Module):
    def __init__(self, pretrained_model='bert-base-uncased', dropout=0.3):
        super(TrustAwareBERT, self).__init__()
        self.bert = BertModel.from_pretrained(pretrained_model)
        self.drop = nn.Dropout(p=dropout)
        self.out = nn.Linear(self.bert.config.hidden_size, 1)

    def forward(self, input_ids, attention_mask):
        output = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        pooled_output = output.pooler_output
        output = self.drop(pooled_output)
        return self.out(output)