from setuptools import setup, find_packages

setup(
    name="fair-rec-sys",                    # 패키지 이름 (PyPI 검색어)
    version="0.1.1",                        # 버전
    author="Habin Kim",                     # 연구자 이름
    description="Trust-Aware Recommender System based on TBL & Fairness",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/your-id/fair-rec-sys", # 깃허브 주소
    packages=find_packages(),
    install_requires=[
        "torch>=1.10.0",
        "transformers>=4.0.0",
        "pandas",
        "numpy",
        "tqdm"
    ],
    python_requires='>=3.8',
)