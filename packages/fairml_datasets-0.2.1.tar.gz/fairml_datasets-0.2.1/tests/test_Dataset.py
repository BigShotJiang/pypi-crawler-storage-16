import json
import pytest
import warnings
from pathlib import Path
from unittest.mock import patch
import pandas as pd
from aif360.datasets import BinaryLabelDataset
from fairml_datasets import Dataset


@pytest.fixture
def make_info():
    """Factory fixture to build dataset annotation Series with sensible defaults."""

    base = {
        "dataset_name": "test_dataset",
        "filename_raw": None,
        "download_url": "http://example.com/data.csv",
        "is_zip": False,
        "format": "csv",
        "colnames": None,
        "custom_download": False,
        "typical_col_sensitive": json.dumps({"sensitive_col": "sensitive_value"}),
        "typical_col_features": "-",
        "typical_col_target": "target_col",
        "target_lvl_good": "awesome",
        "default_scenario_sensitive_cols": "sensitive_col",
        "license": "MIT License",
    }

    def _make(**overrides):
        data = {**base, **overrides}
        dataset_id = overrides.get("dataset_id", data["dataset_name"])
        return pd.Series(data, name=dataset_id)

    return _make


@pytest.fixture
def mock_info_valid(make_info):
    return make_info()


@pytest.fixture
def mock_info_with_warning(make_info):
    """Dataset info with a warning message."""
    return make_info(
        dataset_id="test_dataset_warning",
        dataset_name="test_dataset_warning",
        warning="This dataset has known issues and should be used with caution.",
        license="CC BY 4.0",
    )


@pytest.fixture
def mock_info_no_license(make_info):
    """Dataset info with missing license information."""
    return make_info(
        dataset_id="test_dataset_no_license",
        dataset_name="test_dataset_no_license",
        license=None,
    )


@pytest.fixture
def mock_info_empty_license(make_info):
    """Dataset info with empty license string."""
    return make_info(
        dataset_id="test_dataset_empty_license",
        dataset_name="test_dataset_empty_license",
        license="not found",
    )


@pytest.fixture
def mock_df():
    return pd.DataFrame(
        {
            "col1": [1, None, 3],
            "sensitive_col": ["a", "b", "a"],
            "target_col": ["awesome", "horrible", "horrible"],
            "categorical_col": ["cat1", "cat2", "cat1"],
        }
    )


@pytest.fixture
def mock_info_metadata_error(make_info):
    return make_info(
        typical_col_target="col1",
        target_lvl_good="1",
        typical_col_sensitive=json.dumps({"non_existent_col": "sensitive_value"}),
        typical_col_features="-",
        default_scenario_sensitive_cols="non_existent_col",
        dataset_id="test_dataset_metadata_error",
        dataset_name="test_dataset",
    )


@pytest.fixture
def mock_df_for_split(size=30):
    """Provides a DataFrame with sufficient samples for stratified splitting.
    Contains at least 2 samples for each combination of sensitive_col and target_col.

    Args:
        size: Number of rows to generate in the DataFrame (default: 30)
    """
    # Original patterns to repeat
    sensitive_pattern = [
        "a",
        "b",
        "a",
        "b",
        "a",
        "b",
        "a",
        "b",
    ]
    target_pattern = [
        "awesome",
        "awesome",
        "horrible",
        "horrible",
        "awesome",
        "awesome",
        "horrible",
        "horrible",
    ]
    categorical_pattern = [
        "cat1",
        "cat2",
        "cat1",
        "cat2",
        "cat1",
        "cat2",
        "cat1",
        "cat2",
    ]

    return pd.DataFrame(
        {
            "col1": list(range(1, size + 1)),
            "sensitive_col": [
                sensitive_pattern[i % len(sensitive_pattern)] for i in range(size)
            ],
            "target_col": [
                target_pattern[i % len(target_pattern)] for i in range(size)
            ],
            "categorical_col": [
                categorical_pattern[i % len(categorical_pattern)] for i in range(size)
            ],
        }
    )


@patch.object(Dataset, "load")
def test_generate_metadata_valid(mock_load, mock_info_valid):
    # Mock the load method to return a valid DataFrame
    mock_load.return_value = pd.DataFrame(
        {
            "col1": [1, 2, 3],
            "sensitive_col": ["a", "b", "c"],
            "target_col": ["awesome", "horrible", "horrible"],
        }
    )

    dataset = Dataset(info=mock_info_valid)
    metadata = dataset.generate_metadata()

    assert metadata["debug_meta_status"] == "OK"
    assert metadata["meta_n_rows"] == 3
    assert metadata["meta_n_cols"] == 3


@patch.object(Dataset, "load")
def test_generate_metadata_metadata_error(mock_load, mock_info_metadata_error):
    # Mock the load method to return a DataFrame missing the sensitive column
    mock_load.return_value = pd.DataFrame({"col1": [1, 2, 3]})

    dataset = Dataset(info=mock_info_metadata_error)
    metadata = dataset.generate_metadata()

    assert "debug_meta_error_message" in metadata
    assert (
        "Sensitive columns not found in dataset" in metadata["debug_meta_error_message"]
    )


@patch.object(Dataset, "load")
def test_preprocess_default(mock_load, mock_info_valid, mock_df):
    mock_load.return_value = mock_df

    dataset = Dataset(info=mock_info_valid)
    preprocessed_df, info = dataset.binarize(
        dataset.load(),
    )
    sensitive_columns = info.sensitive_columns

    assert "sensitive_intersection" in preprocessed_df.columns
    assert "target_col" in preprocessed_df.columns
    assert "categorical_col_cat1" in preprocessed_df.columns
    assert "categorical_col_cat2" in preprocessed_df.columns
    assert preprocessed_df["target_col"].tolist() == [1, 0, 0]
    assert "sensitive_intersection" in sensitive_columns


@patch.object(Dataset, "load")
def test_preprocess_impute_median(mock_load, mock_info_valid, mock_df):
    mock_load.return_value = mock_df

    dataset = Dataset(info=mock_info_valid)
    preprocessed_df, info = dataset.binarize(
        dataset.load(), transform_na_numerical="impute_median"
    )
    sensitive_columns = info.sensitive_columns

    assert "sensitive_intersection" in preprocessed_df.columns
    assert "target_col" in preprocessed_df.columns
    assert "col1" in preprocessed_df.columns
    assert preprocessed_df["col1"].tolist() == [1, 2, 3]
    assert "sensitive_intersection" in sensitive_columns


@patch.object(Dataset, "load")
def test_preprocess_drop_rows(mock_load, mock_info_valid, mock_df):
    mock_load.return_value = mock_df

    dataset = Dataset(info=mock_info_valid)
    preprocessed_df, info = dataset.binarize(
        dataset.load(),
        transform_na_numerical="drop_rows",
        transform_na_character="drop_rows",
    )
    sensitive_columns = info.sensitive_columns

    assert len(preprocessed_df) == 2
    assert "sensitive_intersection" in preprocessed_df.columns
    assert "target_col" in preprocessed_df.columns
    assert "sensitive_intersection" in sensitive_columns


@patch.object(Dataset, "load")
def test_preprocess_target_majority_minority(mock_load, mock_info_valid, mock_df):
    mock_load.return_value = mock_df

    dataset = Dataset(info=mock_info_valid)
    preprocessed_df, info = dataset.binarize(
        dataset.load(), transform_target="majority_minority"
    )
    sensitive_columns = info.sensitive_columns

    assert "sensitive_intersection" in preprocessed_df.columns
    assert "target_col" in preprocessed_df.columns
    assert preprocessed_df["target_col"].tolist() == [0, 1, 1]
    assert "sensitive_intersection" in sensitive_columns


@patch.object(Dataset, "load")
def test_preprocess_unknown_na_transform(mock_load, mock_info_valid, mock_df):
    mock_load.return_value = mock_df

    dataset = Dataset(info=mock_info_valid)
    with pytest.raises(ValueError, match="Unknown NA transformation"):
        dataset.transform(dataset.load(), transform_na_character="unknown")


@patch.object(Dataset, "load")
def test_preprocess_unknown_target_transform(mock_load, mock_info_valid, mock_df):
    mock_load.return_value = mock_df

    dataset = Dataset(info=mock_info_valid)
    with pytest.raises(ValueError, match="Unknown label transformation"):
        dataset.transform(dataset.load(), transform_target="unknown")


@patch.object(Dataset, "load")
def test_preprocess_unknown_sensitive_transform(mock_load, mock_info_valid, mock_df):
    mock_load.return_value = mock_df

    dataset = Dataset(info=mock_info_valid)
    with pytest.raises(ValueError, match="Unknown sensitive transformation"):
        dataset.transform(dataset.load(), transform_sensitive_columns="unknown")


@patch.object(Dataset, "load")
def test_preprocess_unknown_categorical_transform(mock_load, mock_info_valid, mock_df):
    mock_load.return_value = mock_df

    dataset = Dataset(info=mock_info_valid)
    with pytest.raises(ValueError, match="Unknown categorical transformation"):
        dataset.transform(dataset.load(), transform_categorical="unknown")


def test_generate_sensitive_combinations(make_info):
    info = make_info(
        dataset_id="test_dataset",
        dataset_name="test_dataset",
        typical_col_sensitive=json.dumps({"gender": "Gender", "race": "Race"}),
        typical_col_target="outcome",
        target_lvl_good="1",
        default_scenario_sensitive_cols="gender;race",
    )
    dataset = Dataset(info=info)
    expected_combinations = [["gender"], ["race"], ["gender", "race"]]
    assert dataset.generate_sensitive_intersections() == expected_combinations


def test_generate_sensitive_combinations_three_attributes(make_info):
    info = make_info(
        dataset_id="test_dataset",
        dataset_name="test_dataset",
        typical_col_sensitive=json.dumps({"A": "A", "B": "B", "C": "C"}),
        typical_col_target="outcome",
        target_lvl_good="1",
        default_scenario_sensitive_cols="A;B;C",
    )
    dataset = Dataset(info=info)
    expected_combinations = [
        ["A"],
        ["B"],
        ["C"],
        ["A", "B"],
        ["A", "C"],
        ["B", "C"],
        ["A", "B", "C"],
    ]
    assert dataset.generate_sensitive_intersections() == expected_combinations


def test_generate_sensitive_combinations_no_sensitive_columns(make_info):
    info = make_info(
        dataset_id="test_dataset",
        dataset_name="test_dataset",
        typical_col_sensitive=None,
        typical_col_target="outcome",
        target_lvl_good="1",
    )
    dataset = Dataset(info=info)
    assert dataset.generate_sensitive_intersections() == []


@patch.object(Dataset, "load")
def test_split_dataset(mock_load, mock_info_valid, mock_df_for_split):
    mock_load.return_value = mock_df_for_split

    dataset = Dataset(info=mock_info_valid)

    # Basic split test
    splits = (0.6, 0.4)
    df_split = dataset.split_dataset(
        mock_df_for_split, splits=splits, seed=42, stratify=False
    )

    assert len(df_split) == 2
    assert len(df_split[0]) == 18
    assert len(df_split[1]) == 12

    # Test with stratification
    splits = (0.6, 0.4)
    df_split_stratified = dataset.split_dataset(
        mock_df_for_split, splits=splits, seed=42, stratify=True
    )

    assert len(df_split_stratified) == 2
    assert len(df_split_stratified[0]) == 18
    assert len(df_split_stratified[1]) == 12

    # Test with manual stratification column
    splits = (0.6, 0.4)
    df_split_manual = dataset.split_dataset(
        mock_df_for_split,
        splits=splits,
        seed=42,
        stratify=True,
        stratify_manual="categorical_col",
    )

    assert len(df_split_manual) == 2

    # Test with 3-way split
    splits = (0.4, 0.3, 0.3)
    df_split_three = dataset.split_dataset(
        mock_df_for_split, splits=splits, seed=42, stratify=True
    )

    assert len(df_split_three) == 3
    assert sum(len(split) for split in df_split_three) == len(mock_df_for_split)


@patch.object(Dataset, "load")
def test_split_dataset_validation(mock_load, mock_info_valid, mock_df_for_split):
    mock_load.return_value = mock_df_for_split
    dataset = Dataset(info=mock_info_valid)

    # Test with invalid splits (don't sum to 1)
    with pytest.raises(ValueError, match="Split values must sum to 1.0"):
        dataset.split_dataset(mock_df_for_split, splits=(0.3, 0.3))

    # Test with invalid stratify_manual column
    with pytest.raises(ValueError, match="Stratify column nonexistent not found"):
        dataset.split_dataset(
            mock_df_for_split,
            splits=(0.5, 0.5),
            stratify=True,
            stratify_manual="nonexistent",
        )


@patch.object(Dataset, "load")
def test_train_test_split(mock_load, mock_info_valid, mock_df_for_split):
    mock_load.return_value = mock_df_for_split
    dataset = Dataset(info=mock_info_valid)

    # Basic train-test split
    train, test = dataset.train_test_split(
        mock_df_for_split, test_size=0.4, seed=42, stratify=True
    )

    assert isinstance(train, pd.DataFrame)
    assert isinstance(test, pd.DataFrame)
    assert len(train) + len(test) == len(mock_df_for_split)
    assert len(test) == 12


@patch.object(Dataset, "load")
def test_train_test_val_split(mock_load, mock_info_valid, mock_df_for_split):
    mock_load.return_value = mock_df_for_split
    dataset = Dataset(info=mock_info_valid)

    # Basic train-val-test split with stratification
    train, val, test = dataset.train_test_val_split(
        mock_df_for_split, test_size=0.25, val_size=0.25, seed=42, stratify=True
    )

    assert isinstance(train, pd.DataFrame)
    assert isinstance(val, pd.DataFrame)
    assert isinstance(test, pd.DataFrame)
    assert len(train) + len(val) + len(test) == len(mock_df_for_split)
    assert len(train) == 15
    assert len(val) == 7
    assert len(test) == 8  # Slightly larger as it was the last rest


@patch.object(Dataset, "load")
def test_split_with_aif360_dataset(mock_load, mock_info_valid, mock_df_for_split):
    mock_load.return_value = mock_df_for_split

    # Create a mock for BinaryLabelDataset that will pass isinstance check
    dataset = Dataset(info=mock_info_valid)
    df_aif360 = dataset.to_aif360_BinaryLabelDataset()

    # Test the method with a real instance that isinstance can check correctly
    splits = dataset.split_dataset(
        df_aif360, splits=(0.6, 0.4), seed=42, stratify=False
    )

    assert len(splits) == 2
    assert isinstance(splits[0], BinaryLabelDataset)
    assert isinstance(splits[1], BinaryLabelDataset)
    assert splits[0].features.shape[0] == 18
    assert splits[1].features.shape[0] == 12


@patch.object(Dataset, "load")
def test_train_test_split_reproducibility(
    mock_load, mock_info_valid, mock_df_for_split
):
    mock_load.return_value = mock_df_for_split
    dataset = Dataset(info=mock_info_valid)

    # First split with seed 42
    train1, test1 = dataset.train_test_split(
        mock_df_for_split, test_size=0.4, seed=42, stratify=True
    )

    # Second split with the same seed should be identical
    train2, test2 = dataset.train_test_split(
        mock_df_for_split, test_size=0.4, seed=42, stratify=True
    )

    # Verify splits are identical
    pd.testing.assert_frame_equal(train1, train2)
    pd.testing.assert_frame_equal(test1, test2)

    # Split with a different seed
    train3, test3 = dataset.train_test_split(
        mock_df_for_split, test_size=0.4, seed=24, stratify=True
    )

    # Verify splits are different
    assert not train1.equals(train3)
    assert not test1.equals(test3)


def test_realworld_synth_dataset_load():
    dataset = Dataset.from_id("synth")
    df = dataset.load()

    assert isinstance(df, pd.DataFrame)
    assert not df.empty


def test_realworld_synth_example_split():
    # Get the dataset
    dataset = Dataset.from_id("synth")

    # Load as pandas DataFrame
    df = dataset.load()  # or df = dataset.to_pandas()
    print(f"Dataset shape: {df.shape}")

    # Get the target column
    target_column = dataset.get_target_column()
    print(f"Target column: {target_column}")

    # Get sensitive attributes (before transformation)
    sensitive_columns_org = dataset.sensitive_columns

    # Transform to e.g. impute missing data
    df_transformed, transformation_info = dataset.transform(df)
    # Sensitive columns may change due to transformation
    sensitive_columns = transformation_info.sensitive_columns

    # Split into train and test sets
    train_df, test_df = dataset.train_test_split(df, test_size=0.3)

    # Assertions to verify the operations work correctly
    assert isinstance(df, pd.DataFrame)
    assert not df.empty
    assert target_column is not None
    assert isinstance(sensitive_columns_org, list)
    assert isinstance(df_transformed, pd.DataFrame)
    assert transformation_info is not None
    assert isinstance(sensitive_columns, list)
    assert isinstance(train_df, pd.DataFrame)
    assert isinstance(test_df, pd.DataFrame)
    assert len(train_df) + len(test_df) == len(df)
    assert (len(test_df) - int(len(df) * 0.3)) in (-1, 0, 1)


def test_realworld_synth_dataset_train_test_val_split():
    dataset = Dataset.from_id("synth")

    # Load the dataset
    df = dataset.load()

    # Check sensitive attributes
    print(f"Sensitive columns: {dataset.sensitive_columns}")

    # Transform the dataset
    df_transformed, info = dataset.transform(df)

    # Create train/test/validation split
    df_train, df_test, df_val = dataset.train_test_val_split(df_transformed)

    # Assertions to verify the operations work correctly
    assert isinstance(df, pd.DataFrame)
    assert not df.empty
    assert isinstance(dataset.sensitive_columns, list)
    assert isinstance(df_transformed, pd.DataFrame)
    assert info is not None
    assert isinstance(df_train, pd.DataFrame)
    assert isinstance(df_test, pd.DataFrame)
    assert isinstance(df_val, pd.DataFrame)
    assert len(df_train) + len(df_test) + len(df_val) == len(df_transformed)
    # Verify that each split is non-empty
    assert len(df_train) > 0
    assert len(df_test) > 0
    assert len(df_val) > 0
    # Verify that all splits have the same columns
    assert list(df_train.columns) == list(df_transformed.columns)
    assert list(df_test.columns) == list(df_transformed.columns)
    assert list(df_val.columns) == list(df_transformed.columns)


def test_display_warnings_no_license_none(mock_info_no_license):
    """Warn when license is None."""
    dataset = Dataset(info=mock_info_no_license)

    with pytest.warns(UserWarning, match="does not provide a license") as record:
        dataset.display_warnings()

    assert len(record) == 1
    assert "test_dataset_no_license" in str(record[0].message)


def test_display_warnings_no_license_not_found(mock_info_empty_license):
    """Warn when license is marked as not found/empty."""
    dataset = Dataset(info=mock_info_empty_license)

    with pytest.warns(UserWarning, match="does not provide a license") as record:
        dataset.display_warnings()

    assert len(record) == 1
    assert "test_dataset_empty_license" in str(record[0].message)


def test_display_warnings_with_license(make_info):
    """No license warning when license exists."""
    dataset = Dataset(info=make_info(license="MIT License"))

    with warnings.catch_warnings():
        warnings.simplefilter("error")
        dataset.display_warnings()


def test_display_warnings_both_warning_and_no_license(make_info):
    """Both explicit warning and license warning are emitted."""
    dataset = Dataset(
        info=make_info(
            dataset_id="test_dataset_both",
            dataset_name="test_dataset_both",
            warning="This dataset has issues.",
            license=None,
        )
    )

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        dataset.display_warnings()

    messages = [str(item.message) for item in w]
    assert any("This dataset has issues" in msg for msg in messages)
    assert any("does not provide a license" in msg for msg in messages)


def test_load_displays_license_warning(mock_info_no_license):
    """load() should emit license warning via display_warnings."""
    dataset = Dataset(info=mock_info_no_license)

    with pytest.warns(UserWarning, match="does not provide a license"):
        # Call display_warnings directly to avoid network calls; load delegates to it
        dataset.display_warnings()


def test_display_warnings_with_warning(mock_info_with_warning):
    """Test that display_warnings issues a UserWarning when warning field is present."""
    dataset = Dataset(info=mock_info_with_warning)

    with pytest.warns(UserWarning, match="This dataset has known issues"):
        dataset.display_warnings()


def test_display_warnings_without_warning(mock_info_valid):
    """Test that display_warnings does not issue a warning when warning field is absent."""
    dataset = Dataset(info=mock_info_valid)

    # Should not raise any warnings
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        dataset.display_warnings()


def test_display_warnings_includes_dataset_id(mock_info_with_warning):
    """Test that the warning message includes the dataset ID."""
    dataset = Dataset(info=mock_info_with_warning)

    with pytest.warns(UserWarning) as record:
        dataset.display_warnings()

    assert len(record) == 1
    assert "test_dataset_warning" in str(record[0].message)
    assert "This dataset has known issues" in str(record[0].message)


@patch.object(Dataset, "load", return_value=pd.DataFrame({"col": [1, 2, 3]}))
def test_load_displays_warning(mock_load, mock_info_with_warning):
    """Test that load() method calls display_warnings()."""
    dataset = Dataset(info=mock_info_with_warning)

    # The warning should be displayed when display_warnings is called
    with pytest.warns(UserWarning, match="This dataset has known issues"):
        dataset.display_warnings()


@patch.object(Dataset, "load", return_value=pd.DataFrame({"col": [1, 2, 3]}))
def test_load_no_warning_without_warning_field(mock_load, mock_info_valid):
    """Test that load() method does not raise warnings when warning field is absent."""
    dataset = Dataset(info=mock_info_valid)

    with warnings.catch_warnings():
        warnings.simplefilter("error", UserWarning)
        # This should not raise any warnings from dataset warnings
        dataset.display_warnings()


@patch(
    "fairml_datasets.file_handling.DATASET_CACHE_DIR", Path("tests/mock_cache/datasets")
)
@patch("fairml_datasets.dataset.DATASET_CACHE_DIR", Path("tests/mock_cache/datasets"))
def test_realworld_folktables_acsincome_small_dataset_train_test_val_split():
    dataset = Dataset.from_id("folktables_acsincome_small")

    # Load the dataset
    df = dataset.load()

    # Transform the dataset
    df_transformed, info = dataset.transform(df)

    # Create train/test/validation split
    df_train, df_test, df_val = dataset.train_test_val_split(df_transformed)

    # Assertions to verify the operations work correctly
    assert isinstance(df, pd.DataFrame)
    assert not df.empty
    assert isinstance(dataset.sensitive_columns, list)
    assert isinstance(df_transformed, pd.DataFrame)
    assert info is not None
    assert isinstance(df_train, pd.DataFrame)
    assert isinstance(df_test, pd.DataFrame)
    assert isinstance(df_val, pd.DataFrame)
    assert len(df_train) + len(df_test) + len(df_val) == len(df_transformed)
    # Verify that each split is non-empty
    assert len(df_train) > 0
    assert len(df_test) > 0
    assert len(df_val) > 0
    # Verify that all splits have the same columns
    assert list(df_train.columns) == list(df_transformed.columns)
    assert list(df_test.columns) == list(df_transformed.columns)
    assert list(df_val.columns) == list(df_transformed.columns)
