from __future__ import annotations

from fal.toolkit.utils.download_utils import *  # noqa: F403
from fal.toolkit.utils.setup_utils import patch_onnx_runtime  # noqa: F401
