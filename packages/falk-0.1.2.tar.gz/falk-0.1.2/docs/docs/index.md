# falk

[![PyPI - Version](https://img.shields.io/pypi/v/falk)](https://pypi.org/project/falk)
[![PyPI - License](https://img.shields.io/pypi/l/falk)](https://github.com/fscherf/falk/blob/master/LICENSE.txt)
