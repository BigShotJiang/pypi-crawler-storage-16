"""Tests for fast-axolotl."""
