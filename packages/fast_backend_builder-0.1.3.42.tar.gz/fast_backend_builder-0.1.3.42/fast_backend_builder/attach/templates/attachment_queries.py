@strawberry.field
async def get_attachments():
    pass

@strawberry.field
def download_attachment():
    pass
