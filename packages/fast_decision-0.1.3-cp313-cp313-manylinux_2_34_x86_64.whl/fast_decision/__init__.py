from .fast_decision import *

__doc__ = fast_decision.__doc__
if hasattr(fast_decision, "__all__"):
    __all__ = fast_decision.__all__