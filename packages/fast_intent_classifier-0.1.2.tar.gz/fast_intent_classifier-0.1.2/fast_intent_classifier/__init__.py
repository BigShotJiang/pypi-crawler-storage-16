"""Fast Intent Classifier package."""

from .classifier import FastIntentClassifier

__version__ = "0.1.2"
__all__ = ["FastIntentClassifier"]
