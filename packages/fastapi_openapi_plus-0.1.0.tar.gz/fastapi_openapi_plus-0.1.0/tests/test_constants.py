"""Тесты для constants.py.

TODO: Реализовать тесты для:
- Всех pre-built констант
- Проверка наличия description и example
- Правильность типов
"""

