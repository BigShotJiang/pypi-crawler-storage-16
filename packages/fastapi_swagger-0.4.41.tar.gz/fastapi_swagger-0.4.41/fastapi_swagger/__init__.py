__all__ = ["patch_fastapi"]

from .main import patch_fastapi
