# Demo project

This is a demo project for the `fastapi-zitadel-auth` package.

See the [documentation](https://cleanenergyexchange.github.io/fastapi-zitadel-auth/demo-project/) for more information.