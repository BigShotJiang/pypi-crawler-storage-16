"""
fastapi-zitadel-auth demo project
"""
