# Installation


```bash
pip install fastapi-zitadel-auth
```

!!! tip "Pin the version"
    This library is in active development, so breaking changes can occur.
    We recommend **pinning the version** until a stable release is available.
    The latest PyPI version is [![PyPI version](https://img.shields.io/pypi/v/fastapi-zitadel-auth.svg?logo=pypi&logoColor=white&label=pypi)](https://pypi.org/pypi/fastapi-zitadel-auth).
