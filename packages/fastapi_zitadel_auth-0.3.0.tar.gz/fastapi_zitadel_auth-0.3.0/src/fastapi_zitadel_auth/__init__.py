"""
FastAPI Zitadel Auth
"""

from fastapi_zitadel_auth.auth import ZitadelAuth

__version__ = "0.3.0"  # remember to update also in pyproject.toml

__all__ = ["ZitadelAuth", "__version__"]
