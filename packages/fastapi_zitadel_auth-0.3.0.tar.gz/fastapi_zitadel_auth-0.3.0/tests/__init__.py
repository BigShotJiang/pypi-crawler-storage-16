"""
Test suite for fastapi-zitadel-auth.
"""
