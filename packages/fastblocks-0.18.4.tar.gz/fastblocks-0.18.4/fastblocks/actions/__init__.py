"""FastBlocks actions package."""

from . import gather

__all__ = ["gather"]
