"""Tests for FastBlocks MCP foundation."""
