from .client import FastFameClient

__all__ = ["FastFameClient"]
