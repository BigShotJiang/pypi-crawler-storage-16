from fastgenerateapi.utils.str_util import alias_to_camel
