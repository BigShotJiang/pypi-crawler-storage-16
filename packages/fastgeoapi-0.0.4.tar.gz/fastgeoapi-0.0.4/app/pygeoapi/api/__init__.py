"""API package for patched pygeoapi."""
