"""Processes patched module."""


def patch_response(response):
    """Patch pygeoapi response."""
    return response
