from fastkit_core.services.base_crud_service import BaseCrudService

__all__ = [
    'BaseCrudService'
]