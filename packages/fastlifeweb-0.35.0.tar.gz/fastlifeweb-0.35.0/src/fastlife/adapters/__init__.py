"""
Adapters are implementations of abstract classed defined in {mod}`fastlife.service`.
"""
