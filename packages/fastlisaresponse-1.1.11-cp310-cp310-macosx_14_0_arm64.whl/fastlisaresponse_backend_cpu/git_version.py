"""Metadata deduced from git at build time."""

id: str
short_id: str

id = "e256440dcc7d70175009f5b8f4dc1176d38ca337"
short_id = "e256440"
