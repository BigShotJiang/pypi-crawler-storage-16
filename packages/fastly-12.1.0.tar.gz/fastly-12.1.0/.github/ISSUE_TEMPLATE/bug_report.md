---
name: Bug report
about: Tell us about a bug to help us improve
title: ''
labels: bug
assignees: ''

---

**Version**

Please provide the version of `fastly` that you're using.

**What happened**

Please describe what you did, what you expected to happen, and what happened instead.
