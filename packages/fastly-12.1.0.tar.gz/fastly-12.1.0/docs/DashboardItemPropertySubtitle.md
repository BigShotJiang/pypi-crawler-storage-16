# DashboardItemPropertySubtitle

A human-readable subtitle for the dashboard item. Often a description of the visualization.

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** | A human-readable subtitle for the dashboard item. Often a description of the visualization. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


