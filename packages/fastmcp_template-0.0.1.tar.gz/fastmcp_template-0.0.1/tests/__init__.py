"""Tests for fastmcp-template MCP server."""
