"""Fastplate - FastAPI + Tailwind CSS project generator."""

__version__ = "0.1.0"

