# Hello Button Example

Minimal example showing FastStrap Button component.

## Run

```bash
python app.py
```

Visit http://localhost:5001
```