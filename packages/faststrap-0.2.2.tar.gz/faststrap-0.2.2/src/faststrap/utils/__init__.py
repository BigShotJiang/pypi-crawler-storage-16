"""Utility functions for FastStrap."""

__all__ = []
