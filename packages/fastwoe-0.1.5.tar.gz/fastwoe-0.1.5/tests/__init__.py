"""Test package for FastWoe library."""
