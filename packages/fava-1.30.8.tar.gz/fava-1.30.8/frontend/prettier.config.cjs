/** @type {import("prettier").Options} */
const config = {
  plugins: [require.resolve("prettier-plugin-svelte")],
};

module.exports = config;
