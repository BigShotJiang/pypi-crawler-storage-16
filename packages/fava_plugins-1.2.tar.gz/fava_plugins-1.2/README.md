# fava-plugins

a collection of Beancount plugins. Install with `pip install fava-plugins`.

- [`split_income`](https://github.com/beancount/fava-plugins/blob/main/fava_plugins/split_income.py): Split income transactions into pre-tax and post-tax postings.
- [`todo_as_error`](https://github.com/beancount/fava-plugins/blob/main/fava_plugins/todo_as_error.py): Display 'todo'-metadata-entries as errors.
