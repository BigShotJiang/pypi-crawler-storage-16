# fbdfile/__init__.py

from .fbdfile import *
from .fbdfile import __all__, __doc__, __version__

# constants are repeated for documentation

__version__ = __version__
"""Fbdfile version string."""
