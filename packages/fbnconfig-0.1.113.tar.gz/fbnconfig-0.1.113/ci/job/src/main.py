
print("Hi from test image")
