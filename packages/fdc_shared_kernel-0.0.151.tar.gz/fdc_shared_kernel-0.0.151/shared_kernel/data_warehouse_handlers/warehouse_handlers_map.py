"""Factory map for warehouse handlers based on connection engine type."""

from shared_kernel.data_warehouse_handlers.mssql_handler import MSSQLWarehouseHandler
from shared_kernel.data_warehouse_handlers.redshift_handler import RedshiftWarehouseHandler
from shared_kernel.enums.connection_engine import ConnectionEngine


warehouse_handlers = {
    ConnectionEngine.REDSHIFT.value: RedshiftWarehouseHandler,
    ConnectionEngine.MSSQL.value: MSSQLWarehouseHandler
}
