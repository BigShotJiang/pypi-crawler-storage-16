"""
auto-behave: Run behave feature files from VS Code's active tab
"""

__version__ = "0.1.0"
