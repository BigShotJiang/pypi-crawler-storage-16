from .fast_processor import FastProcessor

__all__ = ["FastProcessor"]