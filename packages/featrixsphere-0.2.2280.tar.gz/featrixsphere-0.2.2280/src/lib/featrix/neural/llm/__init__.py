"""
LLM integration module for Featrix Neural.

Handles all interactions with cache.featrix.com LLM API endpoints.
"""

