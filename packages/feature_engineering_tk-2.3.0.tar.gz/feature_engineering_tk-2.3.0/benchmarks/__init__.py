"""
Benchmark suite for Feature Engineering Toolkit performance testing.
"""
