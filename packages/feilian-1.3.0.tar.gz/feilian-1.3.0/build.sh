#!/usr/bin/env bash

python -m pip install --upgrade pip
python -m pip install --upgrade build wheel
python -m build
