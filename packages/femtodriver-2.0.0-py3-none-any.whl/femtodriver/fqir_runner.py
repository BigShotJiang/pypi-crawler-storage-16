"""FemtoRunner runtimes for FQIR"""

import logging
import copy
from femtorun import FemtoRunner, IOSpec
from typing import Optional, Union

logger = logging.getLogger(__name__)


class FQIRArithRunner(FemtoRunner):
    """Runs the FQIR arithmetic subgraph runtime

    Args:
        fqir : (:obj:`FQIR`) : main FQIR graph object

    High-level (numpy) interface:
        These implement the base class FemtoRunner interfaces, as required. These interfaces work
        on numpy data, and are meant to be runnable side-by-side with other FemtoRunners.

        * :func:`step`: run one timestep, takes numpy, returns numpy
        * :func:`run`: call step over multiple time steps,
          takes numpy arrays with a time dimension
        * :func:`reset`: initialize simulation
        * :func:`finish`: exit the simulator cleanly
    """

    @staticmethod
    def find_latched_inputs(iospec: IOSpec) -> dict:
        latched_inputs = {}
        if iospec is None:
            return latched_inputs
        latched_inputs = {key: None for key in iospec.latched_input_names()}
        return latched_inputs

    def __init__(self, fqir, io_spec: Optional[Union[str, IOSpec]] = None, plus_k=0):
        self.fqir = fqir
        self.fqir_state = None
        self.plus_k = plus_k
        self.io_spec = io_spec
        self.latched_inputs: dict = self.find_latched_inputs(io_spec)
        super().__init__(None, None, io_spec=io_spec)

    def reset(self):
        # get initial state for the fqir runtime
        if "INIT" in self.fqir.subgraphs:
            __, self.fqir_state = self.fqir.subgraphs["INIT"].run(return_objs=True)
            # XXX do something for FMIR?
            # FQIR init seems to always clear to zero right now, so by coincidence we don't
        else:
            self.fqir_state = {}

    def finish(self):
        pass

    def step(self, inputs):
        # invoke fqir runtime at single time-step, carrying state over
        # no padding/unpadding for FQIR

        # First pass update latched input values
        for input, value in inputs.items():
            if input in self.latched_inputs:
                self.latched_inputs[input] = value

        # If the inputs are a subset of the latched inputs, don't run the graph
        if set(inputs) <= set(self.latched_inputs):
            return {}, None

        # input_t = list(inputs.values())

        this_step_inputs = {
            k.name: inputs[k.name] if k.name in inputs else self.latched_inputs[k.name]
            for k in self.fqir.subgraphs["ARITH"].inputs
        }

        input_t = list(this_step_inputs.values())
        output_t, self.fqir_state = self.fqir.subgraphs["ARITH"].run(
            *input_t, return_dict=True, return_objs=True, state=self.fqir_state
        )

        for k, v in output_t.items():
            output_t[k] = v + self.plus_k

        return output_t, copy.copy(self.fqir_state)
