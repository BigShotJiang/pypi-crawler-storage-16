#  Copyright Femtosense 2025
#
#  By using this software package, you agree to abide by the terms and conditions
#  in the license agreement found at https://femtosense.ai/legal/eula/
#
from typing import Any

from enum import IntEnum, unique

from typing_extensions import Self, override


@unique
class SpuPartNumber(IntEnum):
    """Supported SPU part numbers"""

    SPU001 = 1
    SPU150 = 2
    UNKNOWN = 255

    @classmethod
    def has_value(cls, value: int):
        return value in cls._value2member_map_

    @override
    @classmethod
    def _missing_(cls, value: object):
        return cls.UNKNOWN

    @override
    def __str__(self) -> str:
        if not self.has_value(self.value):
            return "SPU part number unknown"
        return self.name

    @classmethod
    def to_pn(cls, pn: str | Self):
        if isinstance(pn, SpuPartNumber):
            return pn
        match pn.upper():
            case "SPU001":
                return cls.SPU001
            case "SPU150":
                return cls.SPU150
            case _:
                return cls.UNKNOWN


class SpuPart:
    def __init__(self, **kwargs):
        for key, value in kwargs.items():
            object.__setattr__(self, key, value)

    def __setattr__(self, name: str, value: Any) -> None:
        raise AttributeError(f"Cannot modify read-only object attribute '{name}'")

    def __delattr__(self, name: str) -> None:
        raise AttributeError(f"Cannot delete read-only object attribute '{name}'")

    def __repr__(self) -> str:
        attrs = {k: v for k, v in self.__dict__.items() if k != "_frozen"}
        return f"SpuPart({', '.join(f'{k}={v!r}' for k, v in attrs.items())})"


SPU_BANK_OFFSET: dict[SpuPartNumber, int] = {
    SpuPartNumber.SPU001: 0x00010000,
    SpuPartNumber.SPU150: 0x00010000,
}
SPU_CORE_OFFSET: dict[SpuPartNumber, int] = {
    SpuPartNumber.SPU001: 0x00100000,
    SpuPartNumber.SPU150: 0x00200000,
}
SPU_CORE_MASK: dict[SpuPartNumber, int] = {
    SpuPartNumber.SPU001: 0x000FFFFF,
    SpuPartNumber.SPU150: 0x000FFFFF,
}
SPU_MEMORY_START_ADDR: dict[SpuPartNumber, int] = {
    SpuPartNumber.SPU001: 0x00100000,
    # Use this SPU-150 offset for hardware deployment
    SpuPartNumber.SPU150: 0x20300000,
    # Use this SPU-150 offset for simulation
    # SpuPartNumber.SPU150: 0x00300000,
}
SPU_MAX_FREQ: dict[SpuPartNumber, int] = {
    SpuPartNumber.SPU001: 150,
    SpuPartNumber.SPU150: 250,
}
SPU_CORE_COUNT: dict[SpuPartNumber, int] = {
    SpuPartNumber.SPU001: 2,
    SpuPartNumber.SPU150: 4,
}
SPU_BANK_COUNT: dict[SpuPartNumber, dict[str, int]] = {
    SpuPartNumber.SPU001: {
        "DM": 8,
        "TM": 4,
        "SB": 1,
        "RQ": 1,
        "PB": 1,
        "IM": 1,
    },
    SpuPartNumber.SPU150: {
        "DM": 1,
        "TM": 1,
        "SB": 1,
        "RQ": 1,
        "PB": 1,
        "IM": 1,
    },
}
SPU_BANK_CAPACITY: dict[SpuPartNumber, dict[str, dict[str, int]]] = {
    SpuPartNumber.SPU001: {
        "u8": {
            "DM": 0x10000,
            "TM": 0x4000,
            "SB": 0x0200,
            "RQ": 0x0200,
            "PB": 0x0200,
            "IM": 0x8000,
        },
        "u64": {
            "DM": 8192,
            "TM": 2048,
            "SB": 64,
            "RQ": 64,
            "PB": 64,
            "IM": 4096,
        },
    },
    SpuPartNumber.SPU150: {
        "u8": {
            "DM": 0x40000,
            "TM": 0x10000,
            "SB": 0x00200,
            "RQ": 0x00200,
            "PB": 0x00200,
            "IM": 0x10000,
        },
        "u64": {"DM": 32768, "TM": 8192, "SB": 64, "RQ": 64, "PB": 64, "IM": 8192},
    },
}
SPU_BANK_START_ADDR: dict[SpuPartNumber, dict[str, int]] = {
    SpuPartNumber.SPU001: {
        "DM": 0x00000000,
        "TM": 0x00080000,
        "SB": 0x000C0000,
        "RQ": 0x000D0000,
        "PB": 0x000E0000,
        "IM": 0x000F0000,
    },
    SpuPartNumber.SPU150: {
        "DM": 0x00000000,
        "TM": 0x00040000,
        "IM": 0x00080000,
        "SB": 0x00090000,
        "RQ": 0x000A0000,
        "PB": 0x000B0000,
    },
}
SPU_ENCRYPTION_KEY_COUNT: int = 32

SPU_HW_DEFS: dict[SpuPartNumber, SpuPart] = {
    SpuPartNumber.SPU001: SpuPart(
        max_freq=SPU_MAX_FREQ[SpuPartNumber.SPU001],
        core_count=SPU_CORE_COUNT[SpuPartNumber.SPU001],
        core_offset=SPU_CORE_OFFSET[SpuPartNumber.SPU001],
        core_mask=SPU_CORE_MASK[SpuPartNumber.SPU001],
        memory_start_addr=SPU_MEMORY_START_ADDR[SpuPartNumber.SPU001],
        bank_count=SPU_BANK_COUNT[SpuPartNumber.SPU001],
        bank_offset=SPU_BANK_OFFSET[SpuPartNumber.SPU001],
        bank_capacity=SPU_BANK_CAPACITY[SpuPartNumber.SPU001],
        bank_start_addr=SPU_BANK_START_ADDR[SpuPartNumber.SPU001],
        encryption_key_count=SPU_ENCRYPTION_KEY_COUNT,
    ),
    SpuPartNumber.SPU150: SpuPart(
        max_freq=SPU_MAX_FREQ[SpuPartNumber.SPU150],
        core_count=SPU_CORE_COUNT[SpuPartNumber.SPU150],
        core_offset=SPU_CORE_OFFSET[SpuPartNumber.SPU150],
        core_mask=SPU_CORE_MASK[SpuPartNumber.SPU150],
        memory_start_addr=SPU_MEMORY_START_ADDR[SpuPartNumber.SPU150],
        bank_count=SPU_BANK_COUNT[SpuPartNumber.SPU150],
        bank_offset=SPU_BANK_OFFSET[SpuPartNumber.SPU150],
        bank_capacity=SPU_BANK_CAPACITY[SpuPartNumber.SPU150],
        bank_start_addr=SPU_BANK_START_ADDR[SpuPartNumber.SPU150],
        encryption_key_count=SPU_ENCRYPTION_KEY_COUNT,
    ),
}
