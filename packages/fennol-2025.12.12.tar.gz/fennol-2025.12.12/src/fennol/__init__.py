"""
.. include:: ../../README.md

"""

from .models import FENNIX,register_fennix_module,get_modules_documentation, available_fennix_modules

load = FENNIX.load