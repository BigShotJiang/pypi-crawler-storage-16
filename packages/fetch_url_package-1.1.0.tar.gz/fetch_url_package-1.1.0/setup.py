from setuptools import setup, find_packages

# Minimal setup.py for compatibility with older tools
# Main configuration is in pyproject.toml

setup(
    name="fetch-url-package",
    version="1.1.0",
    packages=find_packages(),
)
