# Contributors

* [Bartosz Magiera](https://github.com/bartosz121)
