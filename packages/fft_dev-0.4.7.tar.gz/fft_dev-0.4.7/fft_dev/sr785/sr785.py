# -*- coding: utf-8 -*-

"""package fft_dev
brief     Base class to handle SR785 device.
author    Benoit Dubois
copyright FEMTO Engineering, 2022
licence   GPL 3.0+
"""

import logging
import serial
import numpy as np
from iopy.prologix import PrologixGpibEth

# GPIB-ethernet attributes
PORT = 1234  # Port of GPIB-Ethernet adapter
DEFAULT_GPIB_ADDR = 10

# Serial attributes
DEFAULT_BAUDRATE = 9600
DEFAULT_DATA_BITS = serial.EIGHTBITS
DEFAULT_STOP_BIT = serial.STOPBITS_ONE
DEFAULT_ODD_PARITY = serial.PARITY_NONE
DEFAULT_SERIAL_TIMEOUT = 1.0  # 0 is non-blocking mode


# =============================================================================
class Sr785():
    """Base class to handle Lakeshore SR785 device.
    """

    def connect(self):
        """Abstract protocol connect process. Derived classes must implement
        the connect process dedicated to the specific protocol used.
        :returns: None
        """
        raise NotImplementedError("Method not implemented by derived class")

    def close(self):
        """Abstract protocol closing process. Derived classes must implement
        the closing process dedicated to the specific protocol used.
        :returns: None
        """
        raise NotImplementedError("Method not implemented by derived class")

    def _write(self, data):
        """Abstract protocol write process. Derived classes must implement
        the write process dedicated to the specific protocol used.
        :param data: data writes to device (str)
        :returns: None
        """
        raise NotImplementedError("Method not implemented by derived class")

    def _read(self, length):
        """Abstract protocol read process. Derived classes must implement
        the read process dedicated to the specific protocol used.
        :param length: length of message to read (int)
        :returns: Message reads from device (str)
        """
        raise NotImplementedError("Method not implemented by derived class")

    def read(self, length=None):
        """A basic read method: read a message from device.
        :param length: length of message to read (int)
        :returns: Message reads from device (str)
        """
        try:
            retval = self._read(length)
        except Exception as ex:
            logging.error("Read error: %r", ex)
            return ''
        logging.debug("read: %r", retval)
        return retval

    def write(self, data):
        """A basic write method: writes "data" to device.
        :param data: data writes to device (str)
        :returns: None
        """
        try:
            nb_bytes = self._write(data)
        except Exception as ex:
            logging.error("Write error: %r", ex)
            return 0
        logging.debug("write: %r", data)
        return nb_bytes

    def query(self, data, length=1024):
        """Write than read procedure.
        :param data: data writes to device (str)
        :returns: Message returned by device (str)
        """
        self.write(data)
        return self.read(length)

    def local(self):
        """Set device in local mode.
        :returns: None
        """
        self.write("LOCL 0")

    def remote(self, lock=False):
        """Set device in remote mode. If lock is True, device is in remote mode
        with local lockout (All front pannel is locked out, including
        [Help/Local] Key).
        :param lock: if True, remote with local lockout (bool)
        :returns: None
        """
        if lock is True:
            self.write("LOCL 2")
        else:
            self.write("LOCL 1")

    @property
    def idn(self):
        """Returns identification string of device.
        :returns: identification string of device (str)
        """
        idn = self.query("*IDN?")
        return idn

    def reset(self):
        """Reset device.
        :returns: None
        """
        self.write("*RST")
        time.sleep(12.0)  # see manual 5-117

    def clear_output_buffer(self):
        """Sometime after a problem during remote communication, the output
        buffer of the SR785 contains outdated data. This method repeats read
        request until the buffer is empty.
        :returns: None
        """
        logging.info("Clear SR785 output buffer")
        try:
            while True:  # Read until all data transfered
                self.read(1024)
        except Exception:
            pass
        logging.info("==> done")

    def get_trace_unit(self, trace_number):
        """Get trace unit.
        :param trace_number: display trace number (0 or 1) (int)
        :returns: unit used for trace (str)
        """
        return self.query("UNIT? {}".format(trace_number))

    def dump_trace_display(self, trace_number):
        """Acquires data trace displayed on FFT analyzer. Data are transfered
        from device in ASCII format.
        :param trace_number: display trace number (0 or 1) (int)
        :returns: Data representing active trace on analyzer display (str)
        """
        self.write("DSPN? {}".format(trace_number))
        data_length = int(self.read(64))
        logging.info("Dump data trace %d", trace_number)
        xtrace = []
        ytrace = []
        for i in range(data_length):
            self.write("DBIN? {},{}".format(trace_number, i))
            xtrace.append(float(self.read(64)))
            self.write("DSPY? {},{}".format(trace_number, i))
            ytrace.append(float(self.read(64)))
        logging.info("===> Done")
        return np.column_stack((np.array(xtrace), np.array(ytrace)))


# =============================================================================
class Sr785Prologix(Sr785):
    """3562A_prologix class, handle FFT device through Prologix GPIB-Ethernet
    adapter or serial interface.
    """

    def __init__(self, ip='', gpib_addr=DEFAULT_GPIB_ADDR):
        """'Constructor'.
        :param ip: GPIB-Ethernet adapter IP address (str)
        :param gpib_addr: GPIB address of device (int)
        :param port: GPIB-Ethernet adapter port (int)
        :returns: None
        """
        self.ip = ip
        self.gpib_addr = gpib_addr
        self._gpib_eth = None

    def connect(self):
        """Open connection with device.
        :returns: True if connection succeed False elsewhere (bool)
        """
        self._gpib_eth = PrologixGpibEth(self.ip,
                                         PORT,
                                         self.gpib_addr)
        try:
            if not self._gpib_eth.init():
                return False
        except ValueError as ex:
            logging.error("Wrong connection parameters: %r", ex)
            return False
        except Exception as ex:
            logging.error("Connection to device failed: %r", ex)
            return False
        logging.info("Connected to SR785")
        self.write("OUTX 0")  # Needed (see manual 5-100)
        return True

    def close(self):
        """Close connection with device.
        :returns: None
        """
        if self._gpib_eth is None:
            return
        self._gpib_eth.close()
        self._gpib_eth = None
        logging.info("Connection to SR785 closed")

    def _write(self, data):
        self._gpib_eth.write(data)

    def _read(self, length):
        return self._gpib_eth.read()


# =============================================================================
class Sr785Serial(Sr785):
    """3562A_prologix class, handle FFT device through Prologix GPIB-Ethernet
    adapter or serial interface.
    """

    def __init__(self, sport='', timeout=DEFAULT_SERIAL_TIMEOUT):
        """'Constructor'.
        :param sport: serial port name (str)
        :param timeout: serial port timeout (float)
        :returns: None
        """
        self.sport = sport
        self._timeout = timeout
        self._ser = None

    def connect(self):
        """Connect to the remote host.
        :returns: True if connection succeeded, False otherwise (bool)
        """
        self._ser = serial.Serial(self.sport,
                                  baudrate=DEFAULT_BAUDRATE,
                                  bytesize=DEFAULT_DATA_BITS,
                                  parity=DEFAULT_ODD_PARITY,
                                  stopbits=DEFAULT_STOP_BIT,
                                  timeout=self._timeout)
        if self._ser.isOpen() is False:
            try:
                self._ser.open()
            except ValueError as ex:
                logging.error("Wrong connection parameters: %r", ex)
                return False
        logging.info("Connected to SR785")
        self.write("OUTX 1")  # Needed (see manual 5-100)
        return True

    def close(self):
        """Closes the underlying serial connection
        """
        if self._ser is not None:
            try:
                self._ser.close()
            except Exception as ex:
                logging.error("Error when closing USB connection: %r", ex)
        self._ser = None
        logging.info("Connection to SR785 closed")

    def _write(self, data):
        return self._ser.write((data + '\n').encode('utf-8'))

    def _read(self, length):
        return self._ser.read_until(size=length).decode('utf-8').strip('\n')

    @property
    def timeout(self):
        """Gets timeout on socket operations.
        :returns: timeout value in second (float)
        """
        if self._ser is None:
            return self._timeout
        return self._ser.timeout

    @timeout.setter
    def timeout(self, timeout):
        """Sets timeout on socket operations.
        :param timeout: timeout value in second (float)
        :returns: None
        """
        self._timeout = timeout
        if self._ser is None:
            return
        self._ser.timeout = timeout
