# FFTekWFM

Tektronix [Waveform file format](https://download.tek.com/manual/Waveform-File-Format-Manual-077022011.pdf) reader.

Features :
+ Support WFM file format version 1, 2 and 3
+ Support FastFrame
+ Support memory mapping
+ Support loading frames with or without pre- and post-charge data

Header reader structure inspired by [TekWFM2](https://github.com/vongostev/tekwfm2).

## Notice
Note this package works for *my* use-case but is not properly tested. Consider using [TekWFM2](https://github.com/vongostev/tekwfm2) for a more established solution.

## Installation
`pip install git+https://gitlab.in2p3.fr/himagnetos/tekwfm.git`

## Usage

Read a file with memory mapping and plot some time series from fast frames, unscaled :
```python
import matplotlib.pyplot as plt
from fftekwfm import TekWFM

filename = "/path/to/tekfile.wfm"
tek = TekWFM(filename).load_frames().get_time_frame()
plt.figure()
plt.plot(tek.time_frame, tek.frames[:, [0, 8000, 15000]])
plt.xlabel("time (s)")
plt.ylabel("signal (a.u.)")
```

Load every frames in-memory and do some calculation :
```python
import matplotlib.pyplot as plt
import numpy as np
from fftekwfm import TekWFM

filename = "/path/to/tekfile.wfm"
tek = TekWFM(filename).load_frames(mmap=False)
Sn = np.abs(np.fft.rfft(tek.frames, axis=0))
f = np.fft.rfftfreq(sig.shape[0], d=tek.tscale)  # tscale is the time between two samples
plt.figure()
plt.plot(f, S_mag)
plt.xlabel("frequency (Hz)")
plt.ylabel("magnitude")
```