"""
Initialize class to set its attributes types.
"""


class tTekWFM:
    byte_order: str
    version: bytes
    bps: int
    curve_offset: int
    nframes: int
    fastframe: int
    imp_dim_count: int
    exp_dim_count: int
    vscale: float
    voffset: float
    vunits: bytes
    type_code: int
    dformat: str
    tscale: float
    toffset: float
    tunits: bytes
    npoints: int
    tsfrac: float
    tsunix: int
    pre_start_offset: int
    data_start_offset: int
    post_start_offset: int
    post_stop_offset: int
