# FFTVM

This projects aims to bring fastflow power to python!

The project is in the setup phase, so for the moment there will be no description provided!

if you are interested contact me: marco.morozzi2002@gmail.com