# fhirschemapy


Generated using https://www.health-samurai.io/articles/type-schema-python-sdk-for-fhir
Then the folder was renamed to R4B to match fhir.resources structure.

