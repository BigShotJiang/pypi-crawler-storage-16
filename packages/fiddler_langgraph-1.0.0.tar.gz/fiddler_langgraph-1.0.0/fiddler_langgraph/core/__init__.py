"""Core functionality for Fiddler SDK."""
