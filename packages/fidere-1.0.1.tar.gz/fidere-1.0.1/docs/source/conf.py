import importlib
import os
import sys

package_name = "fidere"

sys.path.insert(0, os.path.abspath(".."))
sys.path.insert(0, os.path.abspath("./_ext"))

# Import the package and extract the version
pkg = importlib.import_module(package_name)
release = getattr(pkg, "__version__", "0.0.0")
version = ".".join(release.split(".")[:2])

project = "FiDERe"
copyright = "2025, ICE-1, Forschungszentrum Juelich GmbH"
author = "ICE-1, Forschungszentrum Juelich GmbH"

# -- General configuration ---------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#general-configuration

extensions = [
    "sphinx.ext.duration",
    "sphinx.ext.doctest",
    "sphinx.ext.autodoc",
    "sphinx.ext.napoleon",
    "sphinx_autodoc_typehints",
    "sphinx.ext.autosummary",
    "sphinx_rtd_theme",
    "sphinxcontrib.autodoc_pydantic",
    "myst_parser",
]

autodoc_default_options = {
    "members": True,
    "undoc-members": True,
    "show-inheritance": True,
    "exclude-members": "__init__, __weakref__",
}
# Do not inline constructor signatures after the class name
autodoc_class_signature = "separated"
autodoc_inherit_docstrings = False
# Optional but useful
autodoc_member_order = "bysource"

napoleon_google_docstring = True
napoleon_numpy_docstring = True
napoleon_include_init_with_doc = (
    True  # Include docstrings for __init__ methods
)
napoleon_include_private_with_doc = (
    False  # Exclude private members with docstrings
)

source_suffix = [".rst", ".md"]

templates_path = ["_templates"]
exclude_patterns = []

# -- Options for HTML output -------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#options-for-html-output

html_theme = "sphinx_rtd_theme"
html_static_path = ["_static"]
html_css_files = ["css/custom.css", "css/fzj-color-scheme.css"]
html_js_files = ["js/custom.js"]
html_logo = (
    "https://jugit.fz-juelich.de/uploads/-/system/group/avatar/14896/"
    "_ICT-Platform_Logo_icon_small.png?width=120"
)
html_favicon = (
    "https://jugit.fz-juelich.de/uploads/-/system/group/avatar/"
    "14896/_ICT-Platform_Logo_icon_small.png?width=32"
)

# Optional but recommended
html_theme_options = {
    "logo_only": True,
    "prev_next_buttons_location": "bottom",
    "style_external_links": False,
    "vcs_pageview_mode": "",
    "style_nav_header_background": "white",
    "flyout_display": "hidden",
    "version_selector": True,
    "language_selector": True,
    # Toc options
    "collapse_navigation": True,
    "sticky_navigation": True,
    "navigation_depth": 4,
    "includehidden": True,
    "titles_only": False,
}
