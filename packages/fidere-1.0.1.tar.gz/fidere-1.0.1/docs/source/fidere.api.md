# API Documentation
```{toctree}
:maxdepth: 2

fidere.api.parser
fidere.api.models
fidere.api.normalized_model
fidere.api.utils
fidere.api.meta
```