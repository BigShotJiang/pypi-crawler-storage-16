# Meta Information

```{eval-rst}
.. automodule:: fidere.meta
   :members:
   :undoc-members:
```