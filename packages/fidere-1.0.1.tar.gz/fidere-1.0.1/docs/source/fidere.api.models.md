# FiDERe Data Models (Basics)

##  Base Datamodel

```{eval-rst}
.. autoclass:: fidere.models.base.DataModel
   :members:
   :show-inheritance:
   :undoc-members:
```

## Identifiers

```{eval-rst}
.. autoclass:: fidere.models.base.Identifier
   :members:
   :undoc-members:
   :no-show-inheritance:
```