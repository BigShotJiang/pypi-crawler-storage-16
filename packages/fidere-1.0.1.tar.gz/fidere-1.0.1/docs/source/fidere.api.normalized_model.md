# Normalized Data Model

```{eval-rst}
.. autoclass:: fidere.models.normalized.NormalizedModel
   :members:
   :show-inheritance:
   :undoc-members:
```