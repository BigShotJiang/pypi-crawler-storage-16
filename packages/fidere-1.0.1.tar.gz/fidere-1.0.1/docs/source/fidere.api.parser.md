##  JsonSchemaParser

The heart of the library

```{eval-rst}
.. autoclass:: fidere.JsonSchemaParser
   :members:
   :show-inheritance:
   :undoc-members:
```