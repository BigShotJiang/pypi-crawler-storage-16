# Utility Functions

```{eval-rst}
.. automodule:: fidere.util
   :members:
   :undoc-members:
```