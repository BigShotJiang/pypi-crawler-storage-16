# Welcome to FiDERe documentation!

Welcome to the documentation of **FiDERe**

As a first step it is recommended to take a look at the nomenclature that 
is used around this library.

## Contents 
```{toctree}
:maxdepth: 2

fidere.nomenclature
fidere.normalized_model
fidere.api
```

```{note}
This project is under active development
```