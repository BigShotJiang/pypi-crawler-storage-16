import json
import logging

from fidere import JsonSchemaParser
from fidere.models import NormalizedModel

_logger = logging.getLogger(__name__)
# Might want to increase logging level to warning or error
logging.basicConfig(level=logging.INFO)

# Creating an instance of the parser, with and without a context manager
_ = JsonSchemaParser()

with JsonSchemaParser() as parser:
    id_ = parser.parse_schema(
        schema="normalized/schema.json", model_class=NormalizedModel
    )
    # we need the returned identifier to later use this specific model
    # for instancing
    print(f"Schema was parsed with id: {id_}")

    # Entity operations
    with open("instances/entity_instance.json") as file:
        entity_json = json.load(file)
    entity = parser.create_context_entity(entity_json, id_)
    # Throws an ValidationError if anything is not up to the schema
    parser.validate_entity(entity, identifier=id_)

    # Device operations
    with open("instances/device_instance.json") as file:
        device_json = json.load(file)
    device = parser.create_device(device_json, id_)
    # Throws an ValidationError if anything is not up to the schema
    # entity_name, entity_type and static attributes are validated for
    # devices
    parser.validate_device(device, identifier=id_)
