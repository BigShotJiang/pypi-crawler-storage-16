import logging

from fidere import Identifier, JsonSchemaParser
from fidere.models import NormalizedModel

_logger = logging.getLogger(__name__)
# Might want to increase logging level to warning or error
logging.basicConfig(level=logging.INFO)

with JsonSchemaParser() as parser:
    # parsing a schema using the minimal amount of arguments. The parse
    # function will always return one someway or another
    # Since no identifier was specified the "$id" field of the schema is used
    id_1 = parser.parse_schema(
        schema="normalized/schema.json", model_class=NormalizedModel
    )
    print(f"Schema was parsed with id: {id_1}")

    # Specifying an identifier yourself is very simple. An identifier can be
    # anything that hashable (e.g. a string)
    id_2 = parser.parse_schema(
        schema="normalized/schema.json",
        model_class=NormalizedModel,
        identifier="this-is-an-identifier",
    )

    # using an identifier that is already in use will produce an error
    try:
        id_2 = parser.parse_schema(
            schema="normalized/schema.json",
            model_class=NormalizedModel,
            identifier="this-is-an-identifier",
        )
    except ValueError:
        pass

    # if you want to update a model (use the same identifier again) just
    # set update = True when parsing
    id_2 = parser.parse_schema(
        schema="normalized/schema.json",
        model_class=NormalizedModel,
        identifier="this-is-an-identifier",
        update=True,
    )

    # There is an Identifier class, allowing to quickly generate identifiers
    # using the following classmethods

    # generates a random uuid-4
    id_3 = Identifier.from_uuid()
    # generates a random string from `string.ascii_letters`
    id_4 = Identifier.from_ascii(length=20)  # length is optional
