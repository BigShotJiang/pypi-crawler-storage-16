import json
import logging

from fidere import JsonSchemaParser
from fidere.models import NormalizedModel

_logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

with JsonSchemaParser() as parser:
    id_ = parser.parse_schema(
        schema="normalized/schema.json", model_class=NormalizedModel
    )
    # In contrast to the Context Broker and Entities the IoT-Agent and Devices
    # support different kinds of attributes. There are two ways of defining
    # if an Attribute is a DeviceAttribute, a StaticDeviceAttribute or a
    # DeviceCommand. This is done either in the JSON-schema by defining a
    # field iotAttributeType in the metadata for the according attribute.
    # A different way is to define this using a dict.
    attr_types = {
        "openingState": "DeviceAttribute",
        # different from what iotAttributeType defined
        "material": "DeviceAttribute",
        "lockDoor": "DeviceCommand",
        "refLocation": "StaticDeviceAttribute",
    }
    with open("instances/device_instance.json") as file:
        device_json = json.load(file)
        device = parser.create_device(
            instance=device_json, identifier=id_, attr_types=attr_types
        )
    print(type(device.get_attribute("material")))

    # the "normal" way via the schema
    device = parser.create_device(instance=device_json, identifier=id_)
    print(type(device.get_attribute("material")))
