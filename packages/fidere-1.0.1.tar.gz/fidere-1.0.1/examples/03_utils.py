import json

from fidere.util import entity_instance_to_device_instance

# since quite a lot of the fields for devices are shared between multiple
# physical devices, it is quite alot of overhead to define these for every
# instance again and again. So you can just create an instance resembling
# an entity and use a single devices settings dict to do the according
# conversion from entity to device!
device_settings = {
    "apikey": "apikey-iot",
    "service": "iot",
    "subservice": "/demonstration",
}
with open("../instances/entity_instance.json") as file:
    entity_json = json.load(file)
device_instance = entity_instance_to_device_instance(instance=entity_json)
