from enum import Enum

import filip.models.base
import filip.models.ngsi_v2.context
import filip.models.ngsi_v2.iot

# All fields of an entity that are key-value pairs and not structured
# data like attributes
KEYVALUE_ENITITY_FIELDS = ["id", "type"]

# All fields of a device that are key-value pairs and not structured
# data like attributes
KEYVALUE_DEVICE_FIELDS = [
    "apikey",
    "device_id",
    "endpoint",
    "entity_name",
    "entity_type",
    "expressionLanguage",
    "explicitAttrs",
    "ngsiVersion",
    "protocol",
    "service",
    "service_path",
    "timezone",
    "timestamp",
    "transport",
]

KEYVALUE_SERVICE_GROUP_FIELDS = [
    "apikey",
    "autoprovision",
    "cbHost",
    "defaultEntityNameConjunction",
    "entity_type",
    "explicitAttrs",
    "expressionLanguage",
    "ngsiVersion",
    "resource",
    "service",
    "subservice",
    "timestamp",
    "trust",
]

MANDATORY_ENTITY_FIELDS = ["id", "type"]
MANDATORY_DEVICE_FIELDS = ["device_id", "entity_name", "entity_type"]
MADATORY_SERVICE_GROUP_FIELDS = ["resource", "apikey"]

DataType = filip.models.base.DataType


class SupportedObjects(Enum):
    DEVICE = filip.models.ngsi_v2.iot.Device
    ENTITY = filip.models.ngsi_v2.context.ContextEntity
    SERVICE_GROUP = filip.models.ngsi_v2.iot.ServiceGroup


class DeviceAttributeType(str, Enum):
    ATTRIBUTE = "DeviceAttribute"
    COMMAND = "DeviceCommand"
    LAZY = "LazyDeviceAttribute"
    STATIC = "StaticDeviceAttribute"


class InvalidSchema(Exception):
    """A simple exception to indicate an invalid JsonSchema"""

    pass
