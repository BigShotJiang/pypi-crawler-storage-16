import os

import pytest

from fidere import Identifier, JsonSchemaParser
from fidere.models import NormalizedModel


@pytest.fixture
def entity_instance() -> dict:
    return {
        "id": "Thing:001",
        "type": "Thing",
        "attr": None,
        "statAttr": "value123",
        "command": None,
    }


@pytest.fixture
def device_instance() -> dict:
    return {
        "device_id": "Thing002",
        "entity_name": "Thing:002",
        "entity_type": "Thing",
        "attr": None,
        "statAttr": "value123",
        "command": None,
    }


@pytest.fixture
def service_groud_config() -> dict:
    return {
        "service": "openiot",
        "subservice": "/iot_service",
        "apikey": "apikey-123456",
        "resource": "/iot/json",
    }


@pytest.fixture
def path_schema() -> str:
    path = "inputs/schema_normalized.json"
    if os.getcwd().endswith("tests"):
        return path
    return "/".join(["tests", path])


@pytest.fixture
def path_schema_enum() -> str:
    path = "inputs/schema_type_enum.json"
    if os.getcwd().endswith("tests"):
        return path
    return "/".join(["tests", path])


@pytest.fixture
def filled_parser(path_schema) -> tuple[Identifier, JsonSchemaParser]:
    parser = JsonSchemaParser()
    id_ = parser.parse_schema(path_schema, model_class=NormalizedModel)
    return id_, parser


@pytest.fixture
def schema_identifier(filled_parser) -> Identifier:
    return filled_parser[0]


@pytest.fixture
def parser(filled_parser) -> JsonSchemaParser:
    return filled_parser[1]
