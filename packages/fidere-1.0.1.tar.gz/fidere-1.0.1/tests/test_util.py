from pathlib import Path

import pytest

from fidere.util import entity_instance_to_device_instance, parse_with_dmcg


@pytest.fixture(scope="module")
def extra_fields() -> dict:
    return {
        "apikey": "apikey-iot",
        "service": "iot",
        "subservice": "/demonstration",
    }


def test_instance_conversion(entity_instance):
    """Test if the conversion makes the correct fields equal"""
    device_instance = entity_instance_to_device_instance(entity_instance)
    assert device_instance["device_id"] == entity_instance["id"]
    assert device_instance["entity_name"] == entity_instance["id"]
    assert device_instance["entity_type"] == entity_instance["type"]


def test_instance_conversion_with_extra_fields(entity_instance, extra_fields):
    """Test if add fields are added correctly"""
    device_instance = entity_instance_to_device_instance(
        entity_instance, extra_fields
    )
    for k, v in extra_fields.items():
        assert k in device_instance
        assert device_instance[k] == v


class TestDMCGParsing(object):
    def test_parse_with_local_file(self, path_schema):
        """Test successful parsing and module generation."""
        # Arrange
        input_ = Path(path_schema)
        parse_with_dmcg(input_, name="TestClass")

    def test_parse_with_nonexistent_file(self):
        """Test a nonexistent path"""
        input_ = Path("this/does/not/exist")
        with pytest.raises(FileNotFoundError):
            parse_with_dmcg(input_, name="TestClass2")
