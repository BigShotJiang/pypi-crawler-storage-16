## Fides Code of Conduct

The Fides project, which includes Fideslang, adheres to the following [Code of Conduct](https://ethyca.github.io/fides/community/code_of_conduct/).

The Fides core team welcomes any contributions and suggestions to help make the community a better place 🤝
