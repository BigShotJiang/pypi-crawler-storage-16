## Fides Contribution Guidelines

The Fides project, which includes Fideslang, adheres to the following [Contribution Guidelines](https://ethyca.github.io/fides/development/overview/).

The Fides core team welcomes any contributions and suggestions to help make the community a better place 🤝
