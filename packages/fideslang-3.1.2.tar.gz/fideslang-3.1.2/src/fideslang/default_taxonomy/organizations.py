from fideslang.models import Organization

DEFAULT_ORGANIZATIONS = [Organization(fides_key="default_organization")]
