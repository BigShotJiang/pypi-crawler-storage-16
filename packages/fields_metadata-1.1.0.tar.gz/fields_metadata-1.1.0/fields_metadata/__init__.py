"""fields-metadata: A Python library for extracting field metadata from dataclasses and Pydantic models."""

from fields_metadata.annotations import (
    HumanReadableId,
    InternationalURNAnnotation,
    Multiline,
    SemanticClassification,
    URNAnnotation,
)
from fields_metadata.exceptions import (
    FieldMetadataError,
    InvalidTypeUnionError,
    NoneTypeFieldError,
)
from fields_metadata.extractor import MetadataExtractor
from fields_metadata.metadata import FieldMetadata
from fields_metadata.path import FieldsMetadataMap, FieldsPath

__version__ = "1.1.0"

__all__ = [
    "MetadataExtractor",
    "FieldMetadata",
    "FieldsPath",
    "FieldsMetadataMap",
    "Multiline",
    "HumanReadableId",
    "SemanticClassification",
    "URNAnnotation",
    "InternationalURNAnnotation",
    "FieldMetadataError",
    "InvalidTypeUnionError",
    "NoneTypeFieldError",
    "__version__",
]
