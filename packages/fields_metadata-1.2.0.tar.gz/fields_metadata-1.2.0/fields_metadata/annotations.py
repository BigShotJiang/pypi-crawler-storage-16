"""Custom annotation types for field metadata."""

from dataclasses import dataclass


@dataclass(frozen=True)
class Multiline:
    """Annotation to mark a string field as multiline text."""


@dataclass(frozen=True)
class HumanReadableId:
    """Annotation to mark a field as a human-readable identifier."""


@dataclass(frozen=True)
class SemanticClassification:
    """
    Annotation for semantic classification of a field.

    :param classification: The semantic classification value
    """

    classification: str


@dataclass(frozen=True)
class URNAnnotation:
    """Annotation to mark a field as a URN."""


@dataclass(frozen=True)
class InternationalURNAnnotation(URNAnnotation):
    """Annotation to mark a field as an international URN."""


@dataclass(frozen=True)
class NonCategorical:
    """Annotation to mark a field as non-categorical."""


__all__ = [
    "Multiline",
    "HumanReadableId",
    "SemanticClassification",
    "URNAnnotation",
    "InternationalURNAnnotation",
    "NonCategorical",
]
