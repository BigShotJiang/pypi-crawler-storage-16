from typing import Literal

intervals_type = Literal["1m", "5m", "30m", "1h", "1d", "1w"]
