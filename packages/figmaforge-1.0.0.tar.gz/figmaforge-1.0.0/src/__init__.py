"""
Figma to Angular Component Generator
=====================================

A production-grade tool for generating high-fidelity Angular UI components from Figma designs.
"""

__version__ = "1.0.0"
