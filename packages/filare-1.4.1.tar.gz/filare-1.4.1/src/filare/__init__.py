# -*- coding: utf-8 -*-
# Please don't import anything in this file to avoid issues when it is imported in setup.py

__version__ = "0.1"

CMD_NAME = "filare"  # Lower case command and module name for branded CLI
APP_NAME = "Filare"  # Application name in texts meant to be human readable
APP_URL = "https://github.com/laurierloi/Filare"
