"""
Universal Document Processor for LLM Processing

Extracts text, tables, numeric data, and metadata from PDF, DOCX, XLSX, CSV, 
images, HTML, JSON, Markdown, and text files with advanced OCR, intelligent 
table detection, and numeric extraction.
"""

__version__ = "0.1.0"
__author__ = "Bajirao S. Sali"
__email__ = ""

from .processor import UniversalDocumentProcessor
from .models import (
    ProcessedDocument,
    TableData,
    DocumentMetadata,
    NumericData
)

__all__ = [
    "UniversalDocumentProcessor",
    "ProcessedDocument",
    "TableData",
    "DocumentMetadata",
    "NumericData",
]

