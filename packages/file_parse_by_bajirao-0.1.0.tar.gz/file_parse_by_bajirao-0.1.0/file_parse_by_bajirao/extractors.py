"""Table and numeric data extractors"""

import re
import logging
import pandas as pd
import numpy as np
from typing import List, Dict, Any
import fitz  # PyMuPDF

from .models import TableData

# Optional dependencies with graceful fallback
try:
    import pdfplumber
    PDFPLUMBER_AVAILABLE = True
except ImportError:
    PDFPLUMBER_AVAILABLE = False

try:
    import camelot
    CAMELOT_AVAILABLE = True
except ImportError:
    CAMELOT_AVAILABLE = False

try:
    import tabula
    TABULA_AVAILABLE = True
except ImportError:
    TABULA_AVAILABLE = False

logger = logging.getLogger(__name__)


class TableExtractor:
    """Multi-method table extraction"""
    
    def extract_from_pdf(self, filepath: str, pdf_bytes: bytes = None) -> List[TableData]:
        """Extract using all available methods"""
        tables = []
        
        # PyMuPDF
        tables.extend(self._extract_pymupdf(pdf_bytes or filepath))
        
        # pdfplumber
        if PDFPLUMBER_AVAILABLE:
            tables.extend(self._extract_pdfplumber(filepath))
        
        # Camelot
        if CAMELOT_AVAILABLE:
            tables.extend(self._extract_camelot(filepath))
        
        # Tabula
        if TABULA_AVAILABLE:
            tables.extend(self._extract_tabula(filepath))
        
        return self._deduplicate(tables)
    
    def _extract_pymupdf(self, source) -> List[TableData]:
        """PyMuPDF extraction"""
        tables = []
        try:
            doc = fitz.open(stream=source, filetype="pdf") if isinstance(source, bytes) else fitz.open(source)
            
            for pg_num, page in enumerate(doc):
                for tbl_num, table in enumerate(page.find_tables()):
                    data = table.extract()
                    if data and len(data) > 1:
                        tables.append(TableData(
                            table_id=f"pymupdf_p{pg_num+1}_t{tbl_num+1}",
                            page_number=pg_num + 1,
                            headers=data[0],
                            rows=data[1:],
                            confidence=0.85,
                            extraction_method="pymupdf"
                        ))
            doc.close()
        except Exception as e:
            logger.warning(f"PyMuPDF table extraction failed: {e}")
        return tables
    
    def _extract_pdfplumber(self, filepath: str) -> List[TableData]:
        """pdfplumber extraction"""
        tables = []
        try:
            with pdfplumber.open(filepath) as pdf:
                for pg_num, page in enumerate(pdf.pages):
                    for tbl_num, data in enumerate(page.extract_tables()):
                        if data and len(data) > 1:
                            tables.append(TableData(
                                table_id=f"pdfplumber_p{pg_num+1}_t{tbl_num+1}",
                                page_number=pg_num + 1,
                                headers=data[0],
                                rows=data[1:],
                                confidence=0.80,
                                extraction_method="pdfplumber"
                            ))
        except Exception as e:
            logger.warning(f"pdfplumber failed: {e}")
        return tables
    
    def _extract_camelot(self, filepath: str) -> List[TableData]:
        """Camelot extraction"""
        tables = []
        for flavor in ['lattice', 'stream']:
            try:
                camelot_tables = camelot.read_pdf(filepath, pages='all', flavor=flavor)
                for i, tbl in enumerate(camelot_tables):
                    if tbl.accuracy > 60:
                        df = tbl.df
                        tables.append(TableData(
                            table_id=f"camelot_{flavor}_{i+1}",
                            page_number=tbl.page,
                            headers=df.columns.tolist(),
                            rows=df.values.tolist(),
                            confidence=tbl.accuracy / 100,
                            extraction_method=f"camelot_{flavor}"
                        ))
            except Exception as e:
                logger.warning(f"Camelot {flavor} failed: {e}")
        return tables
    
    def _extract_tabula(self, filepath: str) -> List[TableData]:
        """Tabula extraction"""
        tables = []
        try:
            for i, df in enumerate(tabula.read_pdf(filepath, pages='all', multiple_tables=True)):
                if not df.empty:
                    tables.append(TableData(
                        table_id=f"tabula_{i+1}",
                        page_number=1,
                        headers=df.columns.tolist(),
                        rows=df.values.tolist(),
                        confidence=0.75,
                        extraction_method="tabula"
                    ))
        except Exception as e:
            logger.warning(f"Tabula failed: {e}")
        return tables
    
    def _deduplicate(self, tables: List[TableData]) -> List[TableData]:
        """Remove duplicate tables"""
        if len(tables) <= 1:
            return tables
        
        unique = []
        seen = set()
        
        for tbl in tables:
            sig = f"{tbl.page_number}_{len(tbl.rows)}_{len(tbl.headers)}"
            if sig not in seen:
                seen.add(sig)
                unique.append(tbl)
        
        return unique


class NumericExtractor:
    """Extract and analyze numeric data from text and tables"""
    
    @staticmethod
    def extract_from_text(text: str) -> Dict[str, float]:
        """Extract key numeric metrics from text using regex"""
        metrics = {}
        # Example patterns: revenues, totals, percentages
        patterns = {
            r'revenue[s]?\s*[:\-]?\s*\$?([\d,]+\.?\d*)': 'total_revenue',
            r'total[s]?\s*[:\-]?\s*\$?([\d,]+\.?\d*)': 'total_amount',
            r'(\d+\.?\d*)%\s*(growth|increase)': 'growth_rate'
        }
        for pattern, key in patterns.items():
            matches = re.findall(pattern, text, re.IGNORECASE)
            if matches:
                try:
                    value = float(re.sub(r'[,\s]', '', matches[-1]))  # Take last match
                    metrics[key] = value
                except ValueError:
                    pass
        return metrics
    
    @staticmethod
    def analyze_tables(tables: List[TableData]) -> Dict[str, Any]:
        """Analyze tables for numeric stats"""
        stats = {'sum': 0, 'mean': 0, 'count': 0}
        numeric_tables = []
        for table in tables:
            try:
                df = pd.DataFrame(table.rows, columns=table.headers)
                # Select numeric columns
                numeric_df = df.select_dtypes(include=[np.number])
                if not numeric_df.empty:
                    numeric_tables.append(numeric_df)
                    stats['sum'] += numeric_df.sum().sum()
                    stats['mean'] = stats['sum'] / (len(numeric_df) * len(numeric_df.columns)) if stats['sum'] > 0 else 0
                    stats['count'] += len(numeric_df)
            except Exception:
                pass
        return {'statistics': stats, 'numeric_tables': numeric_tables}

