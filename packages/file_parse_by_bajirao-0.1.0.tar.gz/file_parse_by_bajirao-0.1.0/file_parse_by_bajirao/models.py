"""Data models for document processing results"""

import json
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
import pandas as pd


@dataclass
class NumericData:
    """Extracted numeric data and statistics"""
    key_metrics: Dict[str, float]  # e.g., {'total_revenue': 1234.5}
    statistics: Dict[str, Any]     # e.g., {'sum': 1000, 'mean': 50.0}
    numeric_tables: List[pd.DataFrame]  # Numeric-only tables
    extraction_method: str


@dataclass
class TableData:
    """Extracted table structure"""
    table_id: str
    page_number: int
    headers: List[str]
    rows: List[List[str]]
    confidence: float
    extraction_method: str
    
    def to_dict(self) -> Dict:
        return asdict(self)
    
    def to_markdown(self) -> str:
        """Convert to markdown table"""
        if not self.rows:
            return ""
        
        md = f"\n**Table {self.table_id}** (Page {self.page_number}, Confidence: {self.confidence:.0%})\n\n"
        
        if self.headers:
            md += "| " + " | ".join(str(h) for h in self.headers) + " |\n"
            md += "|" + "|".join(["---" for _ in self.headers]) + "|\n"
        
        for row in self.rows[:50]:  # Limit to 50 rows
            md += "| " + " | ".join(str(cell) for cell in row) + " |\n"
        
        if len(self.rows) > 50:
            md += f"\n*({len(self.rows) - 50} more rows omitted)*\n"
        
        return md


@dataclass
class DocumentMetadata:
    """Document metadata"""
    file_type: str
    file_size: int
    page_count: int
    text_length: int
    word_count: int
    has_tables: bool
    table_count: int
    has_numeric: bool
    numeric_count: int
    extraction_methods: List[str]
    processing_time: float
    confidence_score: float


@dataclass
class ProcessedDocument:
    """Complete processed document"""
    text: str
    tables: List[TableData]
    numeric_data: Optional[NumericData]
    metadata: DocumentMetadata
    errors: List[str]
    warnings: List[str]
    
    def to_dict(self) -> Dict:
        """Convert to dictionary"""
        return {
            'text': self.text,
            'tables': [t.to_dict() for t in self.tables],
            'numeric_data': asdict(self.numeric_data) if self.numeric_data else None,
            'metadata': asdict(self.metadata),
            'errors': self.errors,
            'warnings': self.warnings
        }
    
    def to_json(self, filepath: Optional[str] = None) -> str:
        """Export as JSON"""
        data = self.to_dict()
        json_str = json.dumps(data, indent=2, ensure_ascii=False)
        
        if filepath:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(json_str)
        
        return json_str
    
    def to_llm_context(self,
                       include_tables: bool = True,
                       include_metadata: bool = True,
                       include_numeric: bool = True,
                       max_length: Optional[int] = None) -> str:
        """
        Format for LLM consumption
        
        Args:
            include_tables: Include extracted tables
            include_metadata: Include document metadata
            include_numeric: Include numeric data summary
            max_length: Maximum character length (truncates if exceeded)
        """
        context = ""
        
        if include_metadata:
            context += f"# Document Analysis Report\n\n"
            context += f"**Type:** {self.metadata.file_type.upper()}\n"
            context += f"**Pages:** {self.metadata.page_count}\n"
            context += f"**Words:** {self.metadata.word_count:,}\n"
            context += f"**Tables:** {self.metadata.table_count}\n"
            context += f"**Numeric Items:** {self.metadata.numeric_count}\n"
            context += f"**Confidence:** {self.metadata.confidence_score:.0%}\n\n"
        
        context += "## Document Content\n\n"
        context += self.text
        
        if include_tables and self.tables:
            context += "\n\n## Extracted Tables\n"
            for table in self.tables:
                context += table.to_markdown()
        
        if include_numeric and self.numeric_data:
            context += "\n\n## Numeric Data Summary\n"
            context += f"**Key Metrics:** {json.dumps(self.numeric_data.key_metrics, indent=2)}\n"
            context += f"**Statistics:** {json.dumps(self.numeric_data.statistics, indent=2)}\n"
            if self.numeric_data.numeric_tables:
                context += "\n**Numeric Tables:** (DataFrames available in raw output)\n"
        
        if max_length and len(context) > max_length:
            context = context[:max_length] + f"\n\n*[Content truncated at {max_length} characters]*"
        
        return context

