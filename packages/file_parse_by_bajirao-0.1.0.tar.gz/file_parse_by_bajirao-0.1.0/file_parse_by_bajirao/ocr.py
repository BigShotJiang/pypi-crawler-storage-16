"""OCR engines and image enhancement"""

import logging
import numpy as np
from typing import Dict, Any, Union, List
from PIL import Image, ImageEnhance, ImageOps
import pytesseract
import cv2

# Optional dependencies with graceful fallback
try:
    import easyocr
    EASYOCR_AVAILABLE = True
except ImportError:
    EASYOCR_AVAILABLE = False

try:
    from paddleocr import PaddleOCR
    PADDLEOCR_AVAILABLE = True
except ImportError:
    PADDLEOCR_AVAILABLE = False

logger = logging.getLogger(__name__)


class MultiOCREngine:
    """Multi-engine OCR with automatic fallback"""
    
    def __init__(self):
        self.engines = self._initialize_engines()
    
    def _initialize_engines(self):
        """Initialize available OCR engines"""
        engines = {'tesseract': True}  # Always available
        
        if EASYOCR_AVAILABLE:
            try:
                engines['easyocr'] = easyocr.Reader(['en'], gpu=False, verbose=False)
                logger.info("✓ EasyOCR initialized")
            except Exception as e:
                logger.warning(f"EasyOCR init failed: {e}")
        
        if PADDLEOCR_AVAILABLE:
            try:
                engines['paddleocr'] = PaddleOCR(use_angle_cls=True, lang='en',
                                                show_log=False, use_gpu=False)
                logger.info("✓ PaddleOCR initialized")
            except Exception as e:
                logger.warning(f"PaddleOCR init failed: {e}")
        
        return engines
    
    def extract_text(self, image: Union[Image.Image, np.ndarray]) -> Dict[str, Any]:
        """Extract text using best available engine"""
        img_array = np.array(image) if isinstance(image, Image.Image) else image
        results = {}
        
        # Tesseract
        try:
            text = pytesseract.image_to_string(image, config='--psm 6 --oem 3')
            data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT)
            conf = np.mean([c for c in data['conf'] if c > 0]) if data['conf'] else 0
            results['tesseract'] = {'text': text, 'confidence': conf}
        except Exception as e:
            logger.warning(f"Tesseract failed: {e}")
        
        # EasyOCR
        if isinstance(self.engines.get('easyocr'), easyocr.Reader):
            try:
                result = self.engines['easyocr'].readtext(img_array)
                text = ' '.join([item[1] for item in result])
                conf = np.mean([item[2] for item in result]) * 100 if result else 0
                results['easyocr'] = {'text': text, 'confidence': conf}
            except Exception as e:
                logger.warning(f"EasyOCR failed: {e}")
        
        # PaddleOCR
        if isinstance(self.engines.get('paddleocr'), PaddleOCR):
            try:
                result = self.engines['paddleocr'].ocr(img_array, cls=True)
                if result and result[0]:
                    text = ' '.join([item[1][0] for item in result[0]])
                    conf = np.mean([item[1][1] for item in result[0]]) * 100
                    results['paddleocr'] = {'text': text, 'confidence': conf}
            except Exception as e:
                logger.warning(f"PaddleOCR failed: {e}")
        
        # Return best result
        if not results:
            return {'text': '', 'confidence': 0, 'engine': 'none'}
        
        best = max(results.items(), key=lambda x: x[1]['confidence'])
        return {**best[1], 'engine': best[0], 'all_results': results}


class ImageEnhancer:
    """Image preprocessing for OCR"""
    
    @staticmethod
    def enhance(image: Image.Image) -> List[Image.Image]:
        """Apply multiple enhancements"""
        enhanced = [image]
        
        # Grayscale
        gray = ImageOps.grayscale(image) if image.mode != 'L' else image
        enhanced.append(gray)
        
        # High contrast
        enhanced.append(ImageEnhance.Contrast(gray).enhance(2.0))
        
        # Sharpened
        enhanced.append(ImageEnhance.Sharpness(gray).enhance(1.5))
        
        # OpenCV enhancements
        try:
            arr = np.array(gray)
            
            # Bilateral filter
            enhanced.append(Image.fromarray(cv2.bilateralFilter(arr, 9, 75, 75)))
            
            # Adaptive threshold
            thresh = cv2.adaptiveThreshold(arr, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                          cv2.THRESH_BINARY, 11, 2)
            enhanced.append(Image.fromarray(thresh))
        except Exception as e:
            logger.warning(f"OpenCV enhancement failed: {e}")
        
        return enhanced

