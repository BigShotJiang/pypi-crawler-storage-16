"""Main document processor"""

import os
import re
import io
import time
import logging
import requests
from typing import Dict, List, Optional, Union, Any

import fitz  # PyMuPDF
import docx
from PIL import Image
from pdf2image import convert_from_bytes
import pandas as pd
import numpy as np
from bs4 import BeautifulSoup

from .models import ProcessedDocument, TableData, DocumentMetadata, NumericData
from .ocr import MultiOCREngine, ImageEnhancer
from .extractors import TableExtractor, NumericExtractor, PDFPLUMBER_AVAILABLE, CAMELOT_AVAILABLE, TABULA_AVAILABLE

# Optional dependencies
try:
    import openpyxl
    OPENPYXL_AVAILABLE = True
except ImportError:
    OPENPYXL_AVAILABLE = False

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class UniversalDocumentProcessor:
    """Main document processor"""
    
    def __init__(self):
        self.ocr = MultiOCREngine()
        self.table_extractor = TableExtractor()
        self.image_enhancer = ImageEnhancer()
        self.numeric_extractor = NumericExtractor()
        
        logger.info(f"Initialized with OCR engines: {list(self.ocr.engines.keys())}")
        logger.info(f"Table extraction methods: pymupdf" +
                   (", pdfplumber" if PDFPLUMBER_AVAILABLE else "") +
                   (", camelot" if CAMELOT_AVAILABLE else "") +
                   (", tabula" if TABULA_AVAILABLE else ""))
    
    def process(self, source: Union[str, bytes, io.BytesIO]) -> ProcessedDocument:
        """Process any supported document from file path, bytes, or URL"""
        start = time.time()
        is_url = isinstance(source, str) and source.startswith(('http://', 'https://'))
        is_bytes = isinstance(source, (bytes, io.BytesIO))
        
        if is_url:
            try:
                response = requests.get(source, timeout=30)
                response.raise_for_status()
                content = response.content
                # Determine type from URL or content-type
                file_type = self._get_file_type_from_url(source) or self._get_file_type_from_bytes(content)
                filepath = None  # Temp file if needed
            except Exception as e:
                raise ValueError(f"Failed to fetch URL: {e}")
        else:
            if isinstance(source, str):
                if not os.path.exists(source):
                    raise FileNotFoundError(f"File not found: {source}")
                content = open(source, 'rb').read()
                file_type = self._get_file_type(source)
                filepath = source
            else:
                content = source.read() if isinstance(source, io.BytesIO) else source
                file_type = self._get_file_type_from_bytes(content)
                filepath = None
        
        logger.info(f"Processing {file_type}: {'URL' if is_url else os.path.basename(filepath) if filepath else 'bytes'}")
        
        try:
            if file_type == 'pdf':
                result = self._process_pdf(content, filepath)
            elif file_type == 'docx':
                result = self._process_docx(content, filepath)
            elif file_type == 'xlsx':
                result = self._process_xlsx(content, filepath)
            elif file_type == 'csv':
                result = self._process_csv(content, filepath)
            elif file_type == 'html':
                result = self._process_html(content.decode('utf-8'))
            elif file_type == 'json':
                result = self._process_json(content.decode('utf-8'))
            elif file_type == 'md':
                result = self._process_text(content.decode('utf-8'), file_type='md')
            elif file_type == 'image':
                result = self._process_image(content)
            elif file_type == 'text':
                result = self._process_text(content.decode('utf-8'), file_type='text')
            else:
                raise ValueError(f"Unsupported file type: {file_type}")
            
            # Extract numeric data
            key_metrics = self.numeric_extractor.extract_from_text(result['text'])
            table_analysis = self.numeric_extractor.analyze_tables(result['tables'])
            numeric_data = NumericData(
                key_metrics=key_metrics,
                statistics=table_analysis['statistics'],
                numeric_tables=table_analysis['numeric_tables'],
                extraction_method='regex_pd'
            ) if key_metrics or table_analysis['numeric_tables'] else None
            
            metadata = DocumentMetadata(
                file_type=file_type,
                file_size=len(content),
                page_count=result.get('page_count', 1),
                text_length=len(result['text']),
                word_count=len(result['text'].split()),
                has_tables=len(result['tables']) > 0,
                table_count=len(result['tables']),
                has_numeric=bool(numeric_data),
                numeric_count=len(key_metrics) + len(table_analysis['numeric_tables']),
                extraction_methods=result.get('methods', []),
                processing_time=time.time() - start,
                confidence_score=result.get('confidence', 0.8)
            )
            
            doc = ProcessedDocument(
                text=result['text'],
                tables=result['tables'],
                numeric_data=numeric_data,
                metadata=metadata,
                errors=result.get('errors', []),
                warnings=result.get('warnings', [])
            )
            
            logger.info(f"✓ Processed in {metadata.processing_time:.2f}s - "
                       f"{metadata.word_count} words, {metadata.table_count} tables, {metadata.numeric_count} numerics")
            
            return doc
            
        except Exception as e:
            logger.error(f"Processing failed: {e}")
            raise
    
    def _process_pdf(self, pdf_bytes: bytes, filepath: Optional[str] = None) -> Dict:
        """Process PDF"""
        text = ""
        methods = []
        errors = []
        
        # Extract text
        try:
            doc = fitz.open(stream=pdf_bytes, filetype="pdf")
            page_count = len(doc)
            
            for i, page in enumerate(doc):
                text += f"\n--- Page {i+1} ---\n{page.get_text('text')}\n"
            
            doc.close()
            methods.append('pymupdf_text')
        except Exception as e:
            logger.error(f"PyMuPDF failed: {e}")
            errors.append(str(e))
            page_count = 0
        
        # OCR if needed (scanned document)
        if len(text.strip()) < 100:
            logger.info("Text sparse, applying OCR...")
            try:
                for i, img in enumerate(convert_from_bytes(pdf_bytes, dpi=300)):
                    best = max([self.ocr.extract_text(e) for e in self.image_enhancer.enhance(img)],
                               key=lambda x: x['confidence'])
                    text += f"\n--- OCR Page {i+1} ---\n{best['text']}\n"
                methods.append('ocr_scanned')
            except Exception as e:
                logger.error(f"OCR failed: {e}")
                errors.append(str(e))
        
        # Extract tables
        tables = self.table_extractor.extract_from_pdf(filepath or '', pdf_bytes) if filepath else []
        
        return {
            'text': text,
            'tables': tables,
            'page_count': page_count,
            'methods': methods,
            'confidence': 0.9 if len(text) > 100 else 0.6,
            'errors': errors
        }
    
    def _process_docx(self, content: bytes, filepath: Optional[str] = None) -> Dict:
        """Process DOCX"""
        try:
            doc = docx.Document(io.BytesIO(content))
            
            # Extract text
            text = "\n".join([p.text for p in doc.paragraphs if p.text.strip()])
            
            # Extract tables
            tables = []
            for i, tbl in enumerate(doc.tables):
                data = [[cell.text.strip() for cell in row.cells] for row in tbl.rows]
                if data and len(data) > 1:
                    tables.append(TableData(
                        table_id=f"word_t{i+1}",
                        page_number=1,
                        headers=data[0],
                        rows=data[1:],
                        confidence=0.95,
                        extraction_method="docx"
                    ))
            
            return {
                'text': text,
                'tables': tables,
                'methods': ['docx_native'],
                'confidence': 0.95
            }
        except Exception as e:
            raise ValueError(f"DOCX processing failed: {e}")
    
    def _process_xlsx(self, content: bytes, filepath: Optional[str] = None) -> Dict:
        """Process XLSX (tabular/numeric focus)"""
        if not OPENPYXL_AVAILABLE:
            raise ValueError("openpyxl is required for XLSX processing. Install with: pip install openpyxl")
        
        try:
            wb = openpyxl.load_workbook(io.BytesIO(content))
            text = ""
            tables = []
            for sheet_name in wb.sheetnames:
                ws = wb[sheet_name]
                data = [[cell.value for cell in row] if row else [] for row in ws.iter_rows(values_only=True)]
                if data and len(data) > 1:
                    tables.append(TableData(
                        table_id=f"excel_{sheet_name}",
                        page_number=1,
                        headers=[str(h) for h in data[0]],
                        rows=[[str(c) for c in r] for r in data[1:]],
                        confidence=0.98,
                        extraction_method="xlsx"
                    ))
                text += f"\n--- Sheet: {sheet_name} ---\n" + "\n".join(str(row) for row in data[:10])  # Preview
            return {
                'text': text,
                'tables': tables,
                'methods': ['xlsx_native'],
                'confidence': 0.98
            }
        except Exception as e:
            raise ValueError(f"XLSX processing failed: {e}")
    
    def _process_csv(self, content: bytes, filepath: Optional[str] = None) -> Dict:
        """Process CSV (tabular/numeric focus)"""
        try:
            df = pd.read_csv(io.BytesIO(content))
            text = df.to_string(index=False)[:1000]  # Preview
            tables = [TableData(
                table_id="csv_main",
                page_number=1,
                headers=df.columns.tolist(),
                rows=df.values.tolist()[:50],  # Limit rows
                confidence=0.99,
                extraction_method="csv"
            )]
            return {
                'text': text,
                'tables': tables,
                'methods': ['csv_pd'],
                'confidence': 0.99
            }
        except Exception as e:
            raise ValueError(f"CSV processing failed: {e}")
    
    def _process_html(self, html_text: str) -> Dict:
        """Process HTML"""
        soup = BeautifulSoup(html_text, 'lxml')
        text = soup.get_text()
        tables = []
        for i, table in enumerate(soup.find_all('table')):
            rows = []
            for row in table.find_all('tr'):
                cells = [cell.get_text().strip() for cell in row.find_all(['td', 'th'])]
                if cells:
                    rows.append(cells)
            if rows and len(rows) > 1:
                tables.append(TableData(
                    table_id=f"html_t{i+1}",
                    page_number=1,
                    headers=rows[0],
                    rows=rows[1:],
                    confidence=0.90,
                    extraction_method="html_bs4"
                ))
        return {
            'text': text,
            'tables': tables,
            'methods': ['html_bs4'],
            'confidence': 0.90
        }
    
    def _process_json(self, json_text: str) -> Dict:
        """Process JSON (structured text/numeric)"""
        import json
        try:
            data = json.loads(json_text)
            text = json.dumps(data, indent=2)[:2000]  # Preview
            # Convert arrays/objects to tables if possible
            tables = []
            if isinstance(data, list) and len(data) > 1 and isinstance(data[0], dict):
                headers = list(data[0].keys())
                rows = [[str(item.get(h, '')) for h in headers] for item in data[1:]]
                tables.append(TableData(
                    table_id="json_array",
                    page_number=1,
                    headers=headers,
                    rows=rows,
                    confidence=0.95,
                    extraction_method="json"
                ))
            return {
                'text': text,
                'tables': tables,
                'methods': ['json_native'],
                'confidence': 0.95
            }
        except Exception as e:
            raise ValueError(f"JSON processing failed: {e}")
    
    def _process_image(self, content: bytes) -> Dict:
        """Process image (OCR focus)"""
        img = Image.open(io.BytesIO(content))
        
        # Try multiple enhancements
        results = [self.ocr.extract_text(e) for e in self.image_enhancer.enhance(img)]
        best = max(results, key=lambda x: x['confidence'])
        
        return {
            'text': best['text'],
            'tables': [],
            'methods': [f"ocr_image_{best['engine']}"],
            'confidence': best['confidence'] / 100
        }
    
    def _process_text(self, text_content: str, file_type: str = 'text') -> Dict:
        """Process text file or Markdown"""
        if file_type == 'md':
            # Extract headers/tables from Markdown
            lines = text_content.split('\n')
            in_table = False
            table_rows = []
            for line in lines:
                if re.match(r'^[|]+', line.strip()):
                    in_table = True
                    table_rows.append([cell.strip() for cell in line.split('|')[1:-1]])
                elif in_table and table_rows:
                    in_table = False
                    if len(table_rows) > 1:
                        headers = table_rows[0]
                        rows = table_rows[1:]
                        tables = [TableData(
                            table_id="md_table",
                            page_number=1,
                            headers=headers,
                            rows=rows,
                            confidence=0.85,
                            extraction_method="markdown"
                        )]
                        return {'text': text_content, 'tables': tables, 'methods': ['md'], 'confidence': 0.85}
            tables = []
        else:
            tables = []
        return {
            'text': text_content,
            'tables': tables,
            'methods': [f'{file_type}_native'],
            'confidence': 1.0
        }
    
    def _get_file_type(self, filepath: str) -> str:
        """Determine file type from path"""
        ext = os.path.splitext(filepath)[1].lower()
        
        if ext == '.pdf':
            return 'pdf'
        elif ext in ['.docx', '.doc']:
            return 'docx'
        elif ext == '.xlsx':
            return 'xlsx'
        elif ext == '.csv':
            return 'csv'
        elif ext == '.html':
            return 'html'
        elif ext == '.json':
            return 'json'
        elif ext == '.md':
            return 'md'
        elif ext in ['.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.gif', '.webp']:
            return 'image'
        elif ext == '.txt':
            return 'text'
        else:
            return 'unknown'
    
    def _get_file_type_from_bytes(self, content: bytes) -> str:
        """Determine file type from bytes"""
        header = content[:8]
        if header.startswith(b'%PDF'):
            return 'pdf'
        elif header.startswith(b'PK\x03\x04'):  # ZIP (DOCX, XLSX)
            # More precise check needed, but for simplicity assume docx/xlsx based on common
            return 'docx'  # Default; can enhance with magic numbers
        elif re.match(br'<\?xml|<html', content[:20]):
            return 'html'
        elif content.startswith(b'{') or content.startswith(b'['):
            return 'json'
        elif b',' in content[:100] and b'\n' in content[:100]:  # Rough CSV
            return 'csv'
        # For images
        try:
            Image.open(io.BytesIO(content))
            return 'image'
        except:
            pass
        return 'text'
    
    def _get_file_type_from_url(self, url: str) -> Optional[str]:
        """Determine file type from URL"""
        ext = os.path.splitext(url)[1].lower()
        if ext:
            return self._get_file_type(url)
        # Fetch headers if needed
        try:
            head = requests.head(url, allow_redirects=True)
            ct = head.headers.get('content-type', '').lower()
            if 'pdf' in ct:
                return 'pdf'
            elif 'spreadsheet' in ct or 'excel' in ct:
                return 'xlsx'
            # etc.
        except:
            pass
        return None

