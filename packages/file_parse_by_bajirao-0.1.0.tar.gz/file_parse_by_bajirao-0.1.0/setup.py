"""Setup configuration for file_parse_by_bajirao"""

from setuptools import setup, find_packages
from pathlib import Path

# Read the README file
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text(encoding="utf-8") if readme_file.exists() else ""

# Read version from package
version_file = Path(__file__).parent / "file_parse_by_bajirao" / "__init__.py"
version = "0.1.0"
if version_file.exists():
    for line in version_file.read_text().splitlines():
        if line.startswith("__version__"):
            version = line.split("=")[1].strip().strip('"').strip("'")
            break

setup(
    name="file_parse_by_bajirao",
    version=version,
    author="Bajirao S. Sali",
    author_email="",
    description="Universal Document Processor for LLM Processing - extracts text, tables, numeric data, and metadata from multiple file formats",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/bajirao/universal-document-processor",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Text Processing :: Markup",
        "Topic :: Office/Business",
        "License :: OSI Approved :: Apache Software License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.7",
    install_requires=[
        "PyMuPDF>=1.23.0",
        "python-docx>=1.0.0",
        "Pillow>=10.0.0",
        "pytesseract>=0.3.10",
        "pdf2image>=1.16.0",
        "pandas>=1.5.0",
        "numpy>=1.24.0",
        "opencv-python>=4.8.0",
        "openpyxl>=3.1.0",
        "beautifulsoup4>=4.12.0",
        "lxml>=4.9.0",
        "requests>=2.31.0",
    ],
    extras_require={
        "ocr": [
            "easyocr>=1.7.0",
            "paddleocr>=2.7.0",
        ],
        "tables": [
            "pdfplumber>=0.10.0",
            "camelot-py[cv]>=0.11.0",
            "tabula-py>=2.5.0",
        ],
        "all": [
            "easyocr>=1.7.0",
            "paddleocr>=2.7.0",
            "pdfplumber>=0.10.0",
            "camelot-py[cv]>=0.11.0",
            "tabula-py>=2.5.0",
        ],
    },
    keywords="document processing, pdf, docx, xlsx, csv, ocr, table extraction, llm, text extraction",
    project_urls={
        "Bug Reports": "https://github.com/bajirao/universal-document-processor/issues",
        "Source": "https://github.com/bajirao/universal-document-processor",
    },
)

