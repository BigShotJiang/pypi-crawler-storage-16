API
===

.. autosummary::
    :toctree:

    fcollections.core
    fcollections.time
    fcollections.geometry
    fcollections.missions
    fcollections.utilities
    fcollections.sad
    fcollections.implementations
    fcollections.implementations.optional
