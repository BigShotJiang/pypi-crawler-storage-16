Implementations
===============

Summary
-------

.. csv-table::
   :file: implementations.csv
   :header-rows: 1

Details
-------

.. toctree::

   swot
