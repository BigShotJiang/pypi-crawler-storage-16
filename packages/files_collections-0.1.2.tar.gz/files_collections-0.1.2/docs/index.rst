FCollections
============

.. toctree::
    :caption: Files Collection

    fcollections/getting_started
    fcollections/custom
    fcollections/implementations/index

.. toctree::
    :caption: Utilities

    auxiliary

.. toctree::
    :caption: Advanced
    :maxdepth: 1

    api
