# FilterGenius

Smart filters to detect:
- Email / Gmail  
- Phone numbers  
- Emojis  
- Integer / Float / Boolean  
- Alphanumeric  
- URL  
- Whitespace  
- Special characters  

## Install
pip install filtergenius

## Usage
```python
import filtergenius as fg

fg.is_email("abc@test.com")
fg.is_gmail("xyz@gmail.com")
fg.is_phone("+1 555 234 5678")
fg.has_emoji("Hi 😊")
fg.is_int("123")
fg.is_float("12.5")
fg.is_bool("true")
fg.is_alphanumeric("abc123")
fg.is_url("https://google.com")
fg.is_whitespace("   ")
fg.has_special_char("hi@")
