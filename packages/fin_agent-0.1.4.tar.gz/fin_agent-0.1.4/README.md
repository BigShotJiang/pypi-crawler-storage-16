# Fin-Agent

Fin-Agent 是一个基于 DeepSeek 大模型和 Tushare 金融数据的全自动金融领域数据分析及股票推荐 Agent。它是一个 CLI（命令行）工具，能够根据用户输入的自然语言需求，自动规划任务、调用工具获取数据并生成分析结果。

## 特性

*   **智能规划**: 基于 DeepSeek V3 (兼容 OpenAI 接口) 进行任务拆解和工具调用。
*   **丰富数据**: 集成 Tushare Pro 接口，支持获取股票基本信息、日线行情等数据。
*   **CLI 交互**: 简洁的命令行交互界面。

## 快速开始

### 前置要求

*   Python 3.8+
*   [Tushare Pro](https://tushare.pro/) 账号及 Token
*   [DeepSeek](https://www.deepseek.com/) API Key

### 安装

1.  克隆项目或进入项目目录：
    ```bash
    cd fin-agent
    ```

2.  安装依赖：
    ```bash
    pip install -r requirements.txt
    ```

3.  配置环境变量：
    复制 `.env.example` 为 `.env`，并填入你的 API Key：
    ```bash
    cp .env.example .env
    # 编辑 .env 文件
    ```
    
    `.env` 文件内容示例：
    ```ini
    TUSHARE_TOKEN=your_tushare_token_here
    DEEPSEEK_API_KEY=your_deepseek_api_key_here
    DEEPSEEK_BASE_URL=https://api.deepseek.com
    DEEPSEEK_MODEL=deepseek-chat
    ```

### 运行

启动 Agent：

```bash
python main.py
```

### 使用示例

在命令行提示符下输入你的需求：

*   "查一下平安银行最近一个月的股价走势"
*   "分析一下万科A的基本面"
*   "推荐几只最近涨势比较好的银行股" (Agent 会尝试通过数据分析给出建议)

## 项目结构

*   `main.py`: 程序入口。
*   `agent/`: Agent 核心逻辑 (Planning & Execution)。
*   `llm/`: 大模型接口封装 (DeepSeek)。
*   `tools/`: 工具集封装 (Tushare)。
*   `config.py`: 配置管理。

