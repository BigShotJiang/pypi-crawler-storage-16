"""
Goals scaffold templates package.

Contains Jinja2 templates for generating Goal persistence code.
"""
