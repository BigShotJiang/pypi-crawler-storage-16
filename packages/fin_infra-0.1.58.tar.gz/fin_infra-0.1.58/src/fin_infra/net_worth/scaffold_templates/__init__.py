"""
Net Worth Snapshot scaffold templates package.

Contains Jinja2 templates for generating NetWorthSnapshot persistence code.
"""
