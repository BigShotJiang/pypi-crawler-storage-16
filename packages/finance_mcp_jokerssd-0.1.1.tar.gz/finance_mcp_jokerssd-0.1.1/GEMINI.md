# finance_mcp Development Guidelines

Auto-generated from all feature plans. Last updated: 2025-12-01

## Active Technologies

- Python 3.11 + pydantic_ai, SQLModel, FastAPI, Gemini API (001-financial-mcp-server)

## Project Structure

```text
src/
tests/
```

## Commands

cd src [ONLY COMMANDS FOR ACTIVE TECHNOLOGIES][ONLY COMMANDS FOR ACTIVE TECHNOLOGIES] pytest [ONLY COMMANDS FOR ACTIVE TECHNOLOGIES][ONLY COMMANDS FOR ACTIVE TECHNOLOGIES] ruff check . [ONLY COMMANDS FOR ACTIVE TECHNOLOGIES][ONLY COMMANDS FOR ACTIVE TECHNOLOGIES] ruff check .

To run the MCP server:
uvicorn src.main_mcp:mcp_server --reload



## Code Style

Python 3.11: Follow standard conventions

## Recent Changes

- 001-financial-mcp-server: Added Python 3.11 + pydantic_ai, SQLModel, FastAPI, Gemini API

<!-- MANUAL ADDITIONS START -->
<!-- MANUAL ADDITIONS END -->
