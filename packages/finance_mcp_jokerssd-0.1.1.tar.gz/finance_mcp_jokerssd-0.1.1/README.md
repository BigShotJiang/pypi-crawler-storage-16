# finance_mcp

This project is a financial data analysis tool.

## Constitution

This project adheres to a strict set of principles outlined in the [project constitution](/.specify/memory/constitution.md). All contributors are expected to be familiar with and follow these principles.
