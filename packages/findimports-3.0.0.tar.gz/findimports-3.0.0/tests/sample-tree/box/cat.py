import gc
from box import yarn
import decoy  # ha!  3rd-party module

yarn.play()
