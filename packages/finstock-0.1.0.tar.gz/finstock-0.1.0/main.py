def main():
    print("Hello from finstock!")


if __name__ == "__main__":
    main()
