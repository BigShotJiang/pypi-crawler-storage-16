from finter.ai.gpt.mx_finter import MxFinter
