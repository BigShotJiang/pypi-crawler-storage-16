#!/usr/bin/env python3
"""
Unit tests for vendor abstraction layer
Tests vendor registry, adapters, and client interfaces
"""
import unittest
from unittest.mock import Mock, patch, MagicMock


class TestVendorRegistry(unittest.TestCase):
    """Test vendor registry functionality"""

    def test_registry_has_palo_alto(self):
        """Test that Palo Alto is registered by default"""
        from firelens.vendors import is_vendor_supported
        self.assertTrue(is_vendor_supported('palo_alto'))

    def test_registry_has_fortinet(self):
        """Test that Fortinet is registered"""
        from firelens.vendors import is_vendor_supported
        self.assertTrue(is_vendor_supported('fortinet'))

    def test_registry_has_cisco_firepower(self):
        """Test that Cisco Firepower is registered"""
        from firelens.vendors import is_vendor_supported
        self.assertTrue(is_vendor_supported('cisco_firepower'))

    def test_unknown_vendor_not_supported(self):
        """Test that unknown vendor types are not supported"""
        from firelens.vendors import is_vendor_supported
        self.assertFalse(is_vendor_supported('unknown_vendor'))
        self.assertFalse(is_vendor_supported('juniper'))  # Not implemented

    def test_get_available_vendors(self):
        """Test getting list of available vendors"""
        from firelens.vendors import get_available_vendors
        vendors = get_available_vendors()

        self.assertIn('palo_alto', vendors)
        self.assertEqual(vendors['palo_alto'], 'Palo Alto Networks')

        self.assertIn('fortinet', vendors)
        self.assertEqual(vendors['fortinet'], 'Fortinet FortiGate')

        self.assertIn('cisco_firepower', vendors)
        self.assertEqual(vendors['cisco_firepower'], 'Cisco Firepower')

    def test_get_vendor_adapter_palo_alto(self):
        """Test getting Palo Alto adapter"""
        from firelens.vendors import get_vendor_adapter
        adapter = get_vendor_adapter('palo_alto')

        self.assertEqual(adapter.vendor_type, 'palo_alto')
        self.assertEqual(adapter.vendor_name, 'Palo Alto Networks')

    def test_get_vendor_adapter_fortinet(self):
        """Test getting Fortinet adapter"""
        from firelens.vendors import get_vendor_adapter
        adapter = get_vendor_adapter('fortinet')

        self.assertEqual(adapter.vendor_type, 'fortinet')
        self.assertEqual(adapter.vendor_name, 'Fortinet FortiGate')

    def test_get_vendor_adapter_cisco(self):
        """Test getting Cisco Firepower adapter"""
        from firelens.vendors import get_vendor_adapter
        adapter = get_vendor_adapter('cisco_firepower')

        self.assertEqual(adapter.vendor_type, 'cisco_firepower')
        self.assertEqual(adapter.vendor_name, 'Cisco Firepower')

    def test_get_unknown_vendor_raises(self):
        """Test that unknown vendor type raises ValueError"""
        from firelens.vendors import get_vendor_adapter

        with self.assertRaises(ValueError) as ctx:
            get_vendor_adapter('unknown_vendor')

        self.assertIn('Unknown vendor type', str(ctx.exception))
        self.assertIn('unknown_vendor', str(ctx.exception))


class TestVendorBaseClasses(unittest.TestCase):
    """Test vendor base class data structures"""

    def test_interface_sample_creation(self):
        """Test InterfaceSample dataclass"""
        from datetime import datetime, timezone
        from firelens.vendors.base import InterfaceSample

        sample = InterfaceSample(
            timestamp=datetime.now(timezone.utc),
            interface_name='ethernet1/1',
            rx_bytes=1000,
            tx_bytes=2000,
            rx_packets=100,
            tx_packets=200,
            rx_errors=0,
            tx_errors=0,
            success=True
        )

        self.assertEqual(sample.interface_name, 'ethernet1/1')
        self.assertEqual(sample.rx_bytes, 1000)
        self.assertEqual(sample.tx_bytes, 2000)
        self.assertTrue(sample.success)

    def test_session_stats_creation(self):
        """Test SessionStats dataclass"""
        from datetime import datetime, timezone
        from firelens.vendors.base import SessionStats

        stats = SessionStats(
            timestamp=datetime.now(timezone.utc),
            active_sessions=5000,
            max_sessions=100000,
            tcp_sessions=4000,
            udp_sessions=800,
            icmp_sessions=200,
            session_rate=50.5
        )

        self.assertEqual(stats.active_sessions, 5000)
        self.assertEqual(stats.max_sessions, 100000)
        self.assertEqual(stats.tcp_sessions, 4000)
        self.assertAlmostEqual(stats.session_rate, 50.5)

    def test_hardware_info_creation(self):
        """Test HardwareInfo dataclass"""
        from firelens.vendors.base import HardwareInfo

        info = HardwareInfo(
            vendor='Palo Alto Networks',
            model='PA-3260',
            serial='001234567890',
            hostname='datacenter-fw',
            sw_version='10.2.3',
            vendor_specific={'family': 'PA-3200 Series'}
        )

        self.assertEqual(info.vendor, 'Palo Alto Networks')
        self.assertEqual(info.model, 'PA-3260')
        self.assertEqual(info.vendor_specific['family'], 'PA-3200 Series')

    def test_hardware_info_default_vendor_specific(self):
        """Test HardwareInfo initializes vendor_specific to empty dict"""
        from firelens.vendors.base import HardwareInfo

        info = HardwareInfo(
            vendor='Test',
            model='Test-100',
            serial='123',
            hostname='test',
            sw_version='1.0'
        )

        self.assertIsNotNone(info.vendor_specific)
        self.assertEqual(info.vendor_specific, {})

    def test_system_metrics_creation(self):
        """Test SystemMetrics dataclass"""
        from datetime import datetime, timezone
        from firelens.vendors.base import SystemMetrics

        metrics = SystemMetrics(
            timestamp=datetime.now(timezone.utc),
            cpu_usage=45.5,
            memory_usage=60.0,
            vendor_metrics={'mgmt_cpu': 30.0, 'data_plane_cpu': 50.0}
        )

        self.assertAlmostEqual(metrics.cpu_usage, 45.5)
        self.assertAlmostEqual(metrics.memory_usage, 60.0)
        self.assertEqual(metrics.vendor_metrics['mgmt_cpu'], 30.0)


class TestPaloAltoAdapter(unittest.TestCase):
    """Test Palo Alto vendor adapter"""

    def test_adapter_properties(self):
        """Test Palo Alto adapter properties"""
        from vendors.palo_alto import PaloAltoAdapter

        adapter = PaloAltoAdapter()
        self.assertEqual(adapter.vendor_type, 'palo_alto')
        self.assertEqual(adapter.vendor_name, 'Palo Alto Networks')

    def test_supported_metrics(self):
        """Test Palo Alto supported metrics list"""
        from vendors.palo_alto import PaloAltoAdapter

        adapter = PaloAltoAdapter()
        metrics = adapter.get_supported_metrics()

        self.assertIn('cpu_usage', metrics)
        self.assertIn('mgmt_cpu', metrics)
        self.assertIn('data_plane_cpu', metrics)
        self.assertIn('pbuf_util_percent', metrics)
        self.assertIn('active_sessions', metrics)

    def test_hardware_fields(self):
        """Test Palo Alto hardware fields list"""
        from vendors.palo_alto import PaloAltoAdapter

        adapter = PaloAltoAdapter()
        fields = adapter.get_hardware_fields()

        self.assertIn('model', fields)
        self.assertIn('serial', fields)
        self.assertIn('hostname', fields)
        self.assertIn('sw_version', fields)

    def test_default_exclude_interfaces(self):
        """Test Palo Alto default interface exclusions"""
        from vendors.palo_alto import PaloAltoAdapter

        adapter = PaloAltoAdapter()
        excludes = adapter.get_default_exclude_interfaces()

        self.assertIn('mgmt', excludes)
        self.assertIn('loopback', excludes)
        self.assertIn('ha1', excludes)
        self.assertIn('tunnel', excludes)


class TestFortinetAdapter(unittest.TestCase):
    """Test Fortinet vendor adapter"""

    def test_adapter_properties(self):
        """Test Fortinet adapter properties"""
        from vendors.fortinet import FortinetAdapter

        adapter = FortinetAdapter()
        self.assertEqual(adapter.vendor_type, 'fortinet')
        self.assertEqual(adapter.vendor_name, 'Fortinet FortiGate')

    def test_supported_metrics(self):
        """Test Fortinet supported metrics list"""
        from vendors.fortinet import FortinetAdapter

        adapter = FortinetAdapter()
        metrics = adapter.get_supported_metrics()

        self.assertIn('cpu_usage', metrics)
        self.assertIn('memory_usage', metrics)
        self.assertIn('active_sessions', metrics)

    def test_client_raises_not_implemented(self):
        """Test Fortinet client methods raise NotImplementedError"""
        from vendors.fortinet import FortinetClient

        client = FortinetClient('https://192.168.1.1', verify_ssl=False)

        with self.assertRaises(NotImplementedError):
            client.authenticate('admin', 'token')

        with self.assertRaises(NotImplementedError):
            client.collect_system_metrics()

        with self.assertRaises(NotImplementedError):
            client.collect_interface_stats()

        with self.assertRaises(NotImplementedError):
            client.collect_session_stats()

        with self.assertRaises(NotImplementedError):
            client.discover_interfaces()

    def test_default_exclude_interfaces(self):
        """Test Fortinet default interface exclusions"""
        from vendors.fortinet import FortinetAdapter

        adapter = FortinetAdapter()
        excludes = adapter.get_default_exclude_interfaces()

        self.assertIn('mgmt', excludes)
        self.assertIn('fortilink', excludes)
        self.assertIn('ha1', excludes)
        self.assertIn('ssl.root', excludes)


class TestCiscoFirepowerAdapter(unittest.TestCase):
    """Test Cisco Firepower vendor adapter"""

    def test_adapter_properties(self):
        """Test Cisco Firepower adapter properties"""
        from vendors.cisco_firepower import CiscoFirepowerAdapter

        adapter = CiscoFirepowerAdapter()
        self.assertEqual(adapter.vendor_type, 'cisco_firepower')
        self.assertEqual(adapter.vendor_name, 'Cisco Firepower')

    def test_supported_metrics(self):
        """Test Cisco Firepower supported metrics list"""
        from vendors.cisco_firepower import CiscoFirepowerAdapter

        adapter = CiscoFirepowerAdapter()
        metrics = adapter.get_supported_metrics()

        self.assertIn('cpu_usage', metrics)
        self.assertIn('memory_usage', metrics)
        self.assertIn('active_connections', metrics)

    def test_client_raises_not_implemented(self):
        """Test Cisco Firepower client methods raise NotImplementedError"""
        from vendors.cisco_firepower import CiscoFirepowerClient

        client = CiscoFirepowerClient('https://192.168.1.1', verify_ssl=False)

        with self.assertRaises(NotImplementedError):
            client.authenticate('admin', 'password')

        with self.assertRaises(NotImplementedError):
            client.collect_system_metrics()

        with self.assertRaises(NotImplementedError):
            client.collect_interface_stats()

        with self.assertRaises(NotImplementedError):
            client.collect_session_stats()

        with self.assertRaises(NotImplementedError):
            client.discover_interfaces()

    def test_default_exclude_interfaces(self):
        """Test Cisco Firepower default interface exclusions"""
        from vendors.cisco_firepower import CiscoFirepowerAdapter

        adapter = CiscoFirepowerAdapter()
        excludes = adapter.get_default_exclude_interfaces()

        self.assertIn('Management', excludes)
        self.assertIn('Diagnostic', excludes)
        self.assertIn('nlp_int_tap', excludes)


class TestConfigVendorType(unittest.TestCase):
    """Test vendor type field in configuration"""

    def test_config_has_type_field(self):
        """Test that EnhancedFirewallConfig has type field"""
        from config import EnhancedFirewallConfig

        config = EnhancedFirewallConfig(
            name='test_fw',
            host='https://192.168.1.1',
            username='admin',
            password='password',
            type='palo_alto'
        )

        self.assertEqual(config.type, 'palo_alto')

    def test_config_default_type_is_palo_alto(self):
        """Test that default vendor type is palo_alto"""
        from config import EnhancedFirewallConfig

        config = EnhancedFirewallConfig(
            name='test_fw',
            host='https://192.168.1.1',
            username='admin',
            password='password'
        )

        self.assertEqual(config.type, 'palo_alto')

    def test_config_validation_rejects_invalid_type(self):
        """Test that validation rejects invalid vendor types"""
        from config import EnhancedConfigManager, EnhancedFirewallConfig

        manager = EnhancedConfigManager.__new__(EnhancedConfigManager)
        manager.global_config = type('GlobalConfig', (), {
            'web_port': 8080,
            'output_type': 'CSV'
        })()
        manager.firewalls = {
            'test_fw': EnhancedFirewallConfig(
                name='test_fw',
                host='https://192.168.1.1',
                username='admin',
                password='password',
                type='invalid_vendor'
            )
        }

        errors = manager.validate_enhanced_config()
        self.assertTrue(any('invalid_vendor' in e for e in errors))
        self.assertTrue(any('unsupported vendor type' in e for e in errors))

    def test_supported_vendor_types_constant(self):
        """Test SUPPORTED_VENDOR_TYPES constant"""
        from config import SUPPORTED_VENDOR_TYPES

        self.assertIn('palo_alto', SUPPORTED_VENDOR_TYPES)
        self.assertIn('fortinet', SUPPORTED_VENDOR_TYPES)
        self.assertIn('cisco_firepower', SUPPORTED_VENDOR_TYPES)


if __name__ == '__main__':
    unittest.main()
