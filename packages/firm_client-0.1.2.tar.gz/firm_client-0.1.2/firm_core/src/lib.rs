#![cfg_attr(not(feature = "default"), no_std)]
extern crate alloc;

pub mod crc;
pub mod data_parser;
pub mod command_sender;
