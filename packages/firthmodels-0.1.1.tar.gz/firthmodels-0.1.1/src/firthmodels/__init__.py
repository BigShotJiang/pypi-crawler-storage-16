from firthmodels.logistic import FirthLogisticRegression

__all__ = [
    "FirthLogisticRegression",
]
