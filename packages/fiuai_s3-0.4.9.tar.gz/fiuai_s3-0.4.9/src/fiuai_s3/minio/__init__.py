# -- coding: utf-8 --
# Project: fiuai-s3
# Created Date: 2025-05-01
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

from .minio_storage import MinioStorage

__all__ = ["MinioStorage"] 