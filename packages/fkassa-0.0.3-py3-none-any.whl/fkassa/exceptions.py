class PaymentSystemUnavaliableError(Exception):
    pass


class FreeKassaAuthError(Exception):
    pass


class FreeKassaError(Exception):
    pass
