"""Setup file for backward compatibility with older pip versions."""
from setuptools import setup

# Configuration is in pyproject.toml
setup()
