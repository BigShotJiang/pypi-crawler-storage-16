"""Report generation module."""

from .text_reporter import TextReporter
 
__all__ = ["TextReporter"]
