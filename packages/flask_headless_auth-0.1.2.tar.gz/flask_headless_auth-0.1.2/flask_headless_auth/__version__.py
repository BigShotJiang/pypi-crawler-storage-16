"""Version information for flask-headless-auth."""

__version__ = "0.1.2"

