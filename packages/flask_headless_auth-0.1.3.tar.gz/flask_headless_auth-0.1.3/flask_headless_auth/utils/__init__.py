"""
flask_headless_auth.utils
~~~~~~~~~~~~~~~~~~~

Utility functions and decorators.
"""

# Placeholder for future utilities
__all__ = []

