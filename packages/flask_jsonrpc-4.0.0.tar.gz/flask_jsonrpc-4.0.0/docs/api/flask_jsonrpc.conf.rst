flask\_jsonrpc.conf package
===========================

Submodules
----------

flask\_jsonrpc.conf.global\_settings module
-------------------------------------------

.. automodule:: flask_jsonrpc.conf.global_settings
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: flask_jsonrpc.conf
   :members:
   :undoc-members:
   :show-inheritance:
