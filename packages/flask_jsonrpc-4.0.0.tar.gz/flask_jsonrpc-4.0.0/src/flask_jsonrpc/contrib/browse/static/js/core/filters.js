(function(App) {
	'use strict';

	angular.module('core.filter', []);

})(window.App);
