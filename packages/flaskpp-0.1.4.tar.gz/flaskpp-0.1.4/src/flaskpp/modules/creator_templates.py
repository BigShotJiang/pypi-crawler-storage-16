
extensions = [
    "sqlalchemy",
    "socket",
    "babel",
    "fst",
    "authlib",
    "mailing",
    "cache",
    "api",
    "jwt_extended"
]

module_init = """
from flask import Blueprint
from pathlib import Path
import json

from flaskpp import FlaskPP
from flaskpp.modules import require_extensions, ManifestError
from .data import init_models

NAME = __name__.split(".")[-1]
bp = Blueprint(NAME, NAME, template_folder="templates", static_folder="static")

manifest = Path(__file__).parent / "manifest.json"
module_data = {{}}


@bp.context_processor
def context_processor():
    return dict(
        NAME=NAME
    )

{requirements}
def register_module(app: FlaskPP, home: bool):
    if home:
        bp.static_url_path = f"/{{NAME}}/static"
    else:
        bp.url_prefix = f"/{{NAME}}"

    from .routes import init_routes
    init_routes(bp)

    app.register_blueprint(bp)
    init_models()


def version() -> str:
    version_str = module_data.get("version", "").lower().strip()
    if not version_str:
        raise ManifestError("Module version not defined.")

    if " " in version_str and not (version_str.endswith("alpha") or version_str.endswith("beta")):
        raise ManifestError("Invalid version string format.")

    if version_str.startswith("v"):
        version_str = version_str[1:]

    try:
        v_numbers = version_str.split(" ")[0].split(".")
        if len(v_numbers) > 3:
            raise ManifestError("Too many version numbers.")

        for v_number in v_numbers:
            int(v_number)
    except ValueError:
        raise ManifestError("Invalid version numbers.")

    return version_str


def _load_manifest():
    global module_data

    if not manifest.exists():
        raise FileNotFoundError(f"Manifest file for {{NAME}} not found.")

    try:
        module_data = json.loads(manifest.read_text())
    except json.decoder.JSONDecodeError:
        raise ManifestError(f"Invalid format for manifest of {{NAME}}.")

    if not "name" in module_data:
        module_data["name"] = NAME

    if not "description" in module_data:
        RuntimeWarning(f"Missing description of {{module_data['name']}}.")

    if not "version" in module_data:
        raise ManifestError("Module version not defined.")

    if not "author" in module_data:
        RuntimeWarning(f"Author of {{module_data['name']}} not defined.")


def __repr__():
    return f"<{{module_data['name']}} {{version()}}> {{module_data.get('description', '')}}"


_load_manifest()

"""

module_requirements = """
from flaskpp.modules import require_extensions
@require_extensions(
    {extensions}
)
"""

module_routes = """
from flask import Blueprint

from .utils import render_template


def init_routes(bp: Blueprint):
    @bp.route("/")
    def index():
        return render_template("index.html")

"""

module_utils = """
from flask import render_template as _render_template

from . import NAME


def render_template(template: str, **context) -> str:
    return _render_template(f"{NAME}/{template}", **context)

"""

module_index = """
{% extends "base_example.html" %}
{# The base template is natively provided by Flask++. #}

{% block title %}{{ _('My Module') }}{% endblock %}
{% block content %}
    <div class="wrapped-center">
        <h2>{{ _('Welcome!') }}</h2>
        <p>{{ _('This is my wonderful new module.') }}</p>
    </div>
{% endblock %}
"""

module_data_init = """
from pathlib import Path
from importlib import import_module

_package = Path(__file__).parent


def init_models():
    from .. import NAME
    for file in _package.rglob("*.py"):
        if file.stem == "__init__":
            continue
        import_module(f"modules.{NAME}.data.{file.stem}")

"""

module_manifest = """
{{
  "name": "{name}",
  "description": "{description}",
  "version": "{version}",
  "author": "{author}"
}}
"""
