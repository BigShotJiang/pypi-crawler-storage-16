# fleandr-test-package

A simple test package for testing PyPI cleanup utility.

This package is created solely for testing purposes.

