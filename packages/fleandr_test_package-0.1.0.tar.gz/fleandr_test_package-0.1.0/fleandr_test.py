#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""A simple test package for PyPI cleanup testing."""

__version__ = "0.1.0"


def hello():
    """Return a greeting."""
    return "Hello from fleandr-test-package!"


if __name__ == "__main__":
    print(hello())

