"""Init for fleet_composition subpackage.

This is an internal experiment module - not part of the public API.
"""

# Internal experiment code - no public exports
__all__ = []
