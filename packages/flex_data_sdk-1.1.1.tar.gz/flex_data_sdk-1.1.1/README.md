# Flexitricity Data Tool Kit 🛠️

![coverage](https://img.shields.io/badge/coverage-100-green)
![pylint-score](https://img.shields.io/badge/pylint-10-green)

Handy tools for data access within Flexitricity.

[Full documentation is available](https://flex-data-docs.azurewebsites.net/flexdata/data.html)

Note that for easier distribution this project is open source, although it's unlikely that functions within here would be of use as packaged, outside of the company context.
