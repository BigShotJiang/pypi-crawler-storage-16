"""Custom types used in Flex data library"""


class NoDataError(AssertionError):
    """Assertion Error subtype, raised when no data is present (and expected)"""

    ...
