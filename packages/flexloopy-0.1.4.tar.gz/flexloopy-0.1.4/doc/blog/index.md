# 博客

```{button-link} ./archive.html
:color: primary
阅读博文
```

```{postlist}
:list-style: circle
:date: "%Y-%m-%d"
:format: "{title} - {date}"
:excerpts:
```
