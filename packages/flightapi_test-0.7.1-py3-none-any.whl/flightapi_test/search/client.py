"""HTTP client implementation with impersonation, rate limiting and retry functionality.

This module provides a robust HTTP client that handles:
- User agent impersonation (to mimic a browser)
- Rate limiting (10 requests per second)
- Automatic retries with exponential backoff
- Session management
- Error handling
"""

import asyncio
import time
from typing import Any

import httpx

client = None


class RateLimiter:
    """Token bucket rate limiter allowing N requests per period."""

    def __init__(self, rate: int, per: float):
        self.rate = rate
        self.per = per
        self.allowance = rate
        self.last_check = time.monotonic()

    async def wait(self):
        """Wait until a request can proceed."""
        now = time.monotonic()
        elapsed = now - self.last_check
        self.last_check = now

        self.allowance += elapsed * (self.rate / self.per)
        if self.allowance > self.rate:
            self.allowance = self.rate

        if self.allowance < 1:
            # need to wait
            sleep_for = (1 - self.allowance) * (self.per / self.rate)
            await asyncio.sleep(sleep_for)
            self.allowance = 0
        else:
            self.allowance -= 1


class Client:
    DEFAULT_HEADERS = {
        "content-type": "application/x-www-form-urlencoded;charset=UTF-8",
        "user-agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0 Safari/537.36"
        ),
    }

    def __init__(self):
        self._client = httpx.AsyncClient(headers=self.DEFAULT_HEADERS)
        self._rate_limiter = RateLimiter(rate=10, per=1)

    async def _request_with_retry(self, method: str, url: str, **kwargs: Any):
        """Handle retries with exponential backoff."""
        max_attempts = 3
        delay = 0.5

        for attempt in range(max_attempts):
            await self._rate_limiter.wait()

            try:
                response = await self._client.request(method, url, **kwargs)
                response.raise_for_status()
                return response

            except Exception as e:
                if attempt == max_attempts - 1:
                    raise Exception(f"{method.upper()} request failed: {str(e)}")
                await asyncio.sleep(delay)
                delay *= 2  # exponential backoff

    async def get(self, url: str, **kwargs: Any):
        return await self._request_with_retry("get", url, **kwargs)

    async def post(self, url: str, **kwargs: Any):
        return await self._request_with_retry("post", url, **kwargs)

    async def aclose(self):
        await self._client.aclose()


def get_client() -> Client:
    global client
    if client is None:
        client = Client()
    return client
