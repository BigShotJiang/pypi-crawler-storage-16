"""CLI module for the fli package."""

from flightapi_test.cli.main import cli

__all__ = ["cli"]
