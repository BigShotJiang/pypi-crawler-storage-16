"""Command functions for the CLI."""

from flightapi_test.cli.commands.cheap import cheap
from flightapi_test.cli.commands.search import search

__all__ = ["search", "cheap"]
