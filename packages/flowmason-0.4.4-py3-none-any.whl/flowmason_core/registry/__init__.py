"""
FlowMason Universal Component Registry

Provides dynamic loading and management of FlowMason components from packages.
"""

from flowmason_core.registry.registry import ComponentRegistry
from flowmason_core.registry.loader import PackageLoader
from flowmason_core.registry.extractor import MetadataExtractor
from flowmason_core.registry.types import (
    ComponentInfo,
    PackageInfo,
    RegistryError,
    ComponentNotFoundError,
    PackageLoadError,
)

__all__ = [
    "ComponentRegistry",
    "PackageLoader",
    "MetadataExtractor",
    "ComponentInfo",
    "PackageInfo",
    "RegistryError",
    "ComponentNotFoundError",
    "PackageLoadError",
]
