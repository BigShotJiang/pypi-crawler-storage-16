"""
FlowMason Core Operators.

These are foundation utility components maintained by the FlowMason team:
- HTTP Request: Make API calls
- JSON Transform: Reshape data
- Filter: Conditional logic
- Loop: Iterate over collections
- Schema Validate: Validate against JSON schema
- Variable Set: Set context variables
- Logger: Emit logs
"""
