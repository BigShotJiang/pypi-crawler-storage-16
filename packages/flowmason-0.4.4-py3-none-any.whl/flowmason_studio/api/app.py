"""
FlowMason Studio FastAPI Application.

Main entry point for the Studio API server.
"""

from contextlib import asynccontextmanager
from typing import Optional
from pathlib import Path

from fastapi import FastAPI, WebSocket
from fastapi.middleware.cors import CORSMiddleware

from flowmason_core.registry import ComponentRegistry

from flowmason_studio.api.routes import registry, pipelines, execution, providers, settings, logs, templates, tests, auth, saml
from flowmason_studio.api.routes.registry import set_registry
from flowmason_studio.services.storage import (
    set_pipeline_storage,
    set_run_storage,
    PipelineStorage,
    RunStorage,
)
from flowmason_studio.services.logging_service import get_logging_service, log_info, LogCategory
from flowmason_core.config.installation import get_installation_config
from flowmason_studio.api.websocket import get_connection_manager, websocket_handler


# Application metadata
API_TITLE = "FlowMason Studio API"
API_DESCRIPTION = """
FlowMason Studio provides an HTTP API for managing AI workflow pipelines.

## Features

- **Component Registry**: Browse and manage available components
- **Pipeline Management**: Create, edit, and version pipelines
- **Execution**: Run pipelines and monitor execution
- **Observability**: View execution traces and metrics
"""
API_VERSION = "0.1.0"


def create_app(
    component_registry: Optional[ComponentRegistry] = None,
    package_dirs: Optional[list[Path]] = None,
    enable_cors: bool = True,
    cors_origins: list[str] = None,
) -> FastAPI:
    """
    Create and configure the FastAPI application.

    Args:
        component_registry: Pre-configured registry (creates new if None)
        package_dirs: Directories to scan for .fmpkg packages
        enable_cors: Whether to enable CORS middleware
        cors_origins: Allowed CORS origins (defaults to ["*"])

    Returns:
        Configured FastAPI application
    """

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        """Application lifespan handler for startup/shutdown."""
        # Startup
        nonlocal component_registry

        # Create registry if not provided
        if component_registry is None:
            component_registry = ComponentRegistry()

            # Scan package directories if provided
            if package_dirs:
                for pkg_dir in package_dirs:
                    if pkg_dir.exists():
                        component_registry.scan_packages(pkg_dir)

        # Set global registry
        set_registry(component_registry)

        # Initialize database and storage (SQLite for dev, can switch to PostgreSQL)
        from flowmason_studio.services.database import get_connection, close_connection
        get_connection()  # This initializes the database schema
        set_pipeline_storage(PipelineStorage())
        set_run_storage(RunStorage())

        # Initialize logging service
        get_logging_service()
        log_info(LogCategory.SYSTEM, f"FlowMason Studio API v{API_VERSION} started")

        # Initialize auth service (creates tables)
        from flowmason_studio.auth import get_auth_service
        get_auth_service()
        log_info(LogCategory.SYSTEM, "Authentication service initialized")

        # Register installation state (port/host from env vars if available)
        import os
        install_config = get_installation_config()
        install_config.register_installation(version=API_VERSION)
        install_config.update_studio_state(
            running=True,
            port=int(os.environ.get("FLOWMASON_PORT", 8999)),
            host=os.environ.get("FLOWMASON_HOST", "127.0.0.1"),
        )
        log_info(LogCategory.SYSTEM, "Installation state registered")

        yield

        # Shutdown - clear server state and cleanup database connection
        install_config.update_studio_state(running=False)
        close_connection()

    # Create app
    app = FastAPI(
        title=API_TITLE,
        description=API_DESCRIPTION,
        version=API_VERSION,
        lifespan=lifespan,
    )

    # Add CORS middleware
    if enable_cors:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=cors_origins or ["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

    # Include routers
    app.include_router(auth.router, prefix="/api/v1")  # Auth first for bootstrap
    app.include_router(saml.router, prefix="/api/v1")  # SAML/SSO authentication
    app.include_router(registry.router, prefix="/api/v1")
    app.include_router(pipelines.router, prefix="/api/v1")
    app.include_router(execution.router, prefix="/api/v1")
    app.include_router(providers.router, prefix="/api/v1")
    app.include_router(settings.router, prefix="/api/v1")
    app.include_router(logs.router, prefix="/api/v1")
    app.include_router(templates.router, prefix="/api/v1")
    app.include_router(tests.router, prefix="/api/v1")

    # Health check endpoint
    @app.get("/health", tags=["health"])
    async def health_check():
        """Health check endpoint."""
        return {"status": "healthy", "version": API_VERSION}

    # WebSocket endpoint for real-time execution updates
    @app.websocket("/api/v1/ws/runs")
    async def websocket_runs_endpoint(websocket: WebSocket):
        """
        WebSocket endpoint for real-time execution updates.

        Protocol:
        - Send {"type": "subscribe", "run_id": "..."} to subscribe to run updates
        - Send {"type": "unsubscribe", "run_id": "..."} to unsubscribe
        - Send {"type": "ping"} for keepalive (receives pong response)
        - Send {"type": "pause", "run_id": "..."} to pause execution
        - Send {"type": "resume", "run_id": "..."} to resume execution
        - Send {"type": "step", "run_id": "..."} to step to next stage

        Events received:
        - connected: Connection established with client_id
        - subscribed: Successfully subscribed to a run
        - run_started: Pipeline execution started
        - stage_started: Stage execution started
        - stage_completed: Stage execution completed
        - stage_failed: Stage execution failed
        - execution_paused: Execution paused at breakpoint or by command
        - run_completed: Pipeline execution completed
        - run_failed: Pipeline execution failed
        """
        manager = get_connection_manager()
        await websocket_handler(websocket, manager)

    # Root redirect to docs
    @app.get("/", include_in_schema=False)
    async def root():
        """Redirect root to API documentation."""
        from fastapi.responses import RedirectResponse
        return RedirectResponse(url="/docs")

    return app


# Default app instance for uvicorn
app = create_app()


def run_server(
    host: str = "127.0.0.1",
    port: int = 8999,
    reload: bool = False,
    package_dirs: Optional[list[Path]] = None,
):
    """
    Run the Studio API server.

    Args:
        host: Host to bind to
        port: Port to listen on
        reload: Enable auto-reload for development
        package_dirs: Directories to scan for packages
    """
    import os
    import uvicorn

    # Set environment variables for the lifespan handler to pick up
    os.environ["FLOWMASON_HOST"] = host
    os.environ["FLOWMASON_PORT"] = str(port)

    # Note: When using reload, we can't pass custom app instance
    # Package dirs would need to be configured via environment
    uvicorn.run(
        "flowmason_studio.api.app:app",
        host=host,
        port=port,
        reload=reload,
    )


if __name__ == "__main__":
    import os
    host = os.environ.get("FLOWMASON_HOST", "127.0.0.1")
    port = int(os.environ.get("FLOWMASON_PORT", "8999"))
    run_server(host=host, port=port)
