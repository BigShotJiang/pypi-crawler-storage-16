"""
Execution API Routes.

Endpoints for executing pipelines and tracking runs:
- Execute pipelines with input data
- Get run status and results
- Get execution traces
- Cancel running executions
"""

import asyncio
import os
import logging
from typing import Optional, Dict, Any
from datetime import datetime
from fastapi import APIRouter, HTTPException, Query, Depends, BackgroundTasks

from flowmason_core.registry import ComponentRegistry
from flowmason_core.execution import DAGExecutor, ExecutionError
from flowmason_core.config import PipelineConfig as CorePipelineConfig, ComponentConfig, ExecutionContext
from flowmason_core.providers import (
    list_providers,
    get_provider,
    ProviderConfig,
    create_provider,
)

logger = logging.getLogger(__name__)

from flowmason_studio.models.api import (
    ExecutePipelineRequest,
    DebugRunRequest,
    RunDetail,
    RunSummary,
    RunListResponse,
    StageResult,
    APIError,
)
from flowmason_studio.services.storage import (
    PipelineStorage,
    RunStorage,
    get_pipeline_storage,
    get_run_storage,
)
from flowmason_studio.api.routes.registry import get_registry
from flowmason_studio.services.execution_controller import (
    ExecutionController,
    create_controller,
    get_controller,
    remove_controller,
)
from flowmason_studio.models.debug import (
    DebugMode,
    DebugCommandRequest,
    DebugCommandResponse,
    SetBreakpointsRequest,
    SetExceptionBreakpointsRequest,
    ExceptionInfo,
    ExceptionBreakpointFilter,
)
from flowmason_studio.auth import AuthContext, optional_auth, get_auth_service


router = APIRouter(tags=["execution"])

# Mapping of provider names to their environment variable names
PROVIDER_ENV_VARS = {
    "anthropic": "ANTHROPIC_API_KEY",
    "openai": "OPENAI_API_KEY",
    "google": "GOOGLE_API_KEY",
    "groq": "GROQ_API_KEY",
}


def _initialize_providers() -> Dict[str, Any]:
    """
    Initialize all available providers from environment variables.

    Returns dict of provider_name -> provider_instance for providers
    that have valid API keys configured.
    """
    providers = {}

    for provider_name in list_providers():
        env_var = PROVIDER_ENV_VARS.get(provider_name)
        if not env_var:
            continue

        # Check if API key is set
        api_key = os.environ.get(env_var)
        if not api_key:
            logger.debug(f"Provider '{provider_name}' not configured (missing {env_var})")
            continue

        try:
            # Get provider class and instantiate
            ProviderClass = get_provider(provider_name)
            if ProviderClass:
                providers[provider_name] = ProviderClass(api_key=api_key)
                logger.info(f"Initialized provider: {provider_name}")
        except Exception as e:
            logger.warning(f"Failed to initialize provider '{provider_name}': {e}")

    return providers


def _convert_to_core_config(pipeline_detail) -> CorePipelineConfig:
    """Convert Studio pipeline model to Core pipeline config."""
    stages = []
    for stage in pipeline_detail.stages:
        stages.append(ComponentConfig(
            id=stage.id,
            type=stage.component_type,
            config=stage.config or {},
            input_mapping=stage.input_mapping or {},
            depends_on=stage.depends_on or [],
        ))

    # Convert input/output schemas from Pydantic models to dicts if needed
    input_schema = pipeline_detail.input_schema
    if hasattr(input_schema, 'model_dump'):
        input_schema = input_schema.model_dump()
    elif not isinstance(input_schema, dict):
        input_schema = {}

    output_schema = pipeline_detail.output_schema
    if hasattr(output_schema, 'model_dump'):
        output_schema = output_schema.model_dump()
    elif not isinstance(output_schema, dict):
        output_schema = {}

    return CorePipelineConfig(
        id=pipeline_detail.id,
        name=pipeline_detail.name,
        version=pipeline_detail.version,
        description=pipeline_detail.description or "",
        stages=stages,
        output_stage_id=pipeline_detail.output_stage_id,
    )


async def _execute_pipeline_task(
    run_id: str,
    pipeline_detail,
    inputs: Dict[str, Any],
    registry: ComponentRegistry,
    run_storage: RunStorage,
    breakpoints: Optional[list] = None,
    org_id: Optional[str] = None,
):
    """Background task to execute a pipeline."""
    controller: Optional[ExecutionController] = None

    try:
        # Mark as running
        run_storage.update_status(run_id, "running", org_id=org_id)
        logger.info(f"[{run_id}] Starting pipeline execution for {pipeline_detail.name}")

        # Convert to core config
        core_config = _convert_to_core_config(pipeline_detail)
        logger.info(f"[{run_id}] Converted config with {len(core_config.stages)} stages")

        # Initialize providers from environment
        providers = _initialize_providers()
        logger.info(f"[{run_id}] Initialized providers: {list(providers.keys())}")
        for name, prov in providers.items():
            logger.info(f"[{run_id}]   Provider '{name}': {type(prov).__name__} at {id(prov)}")
        if not providers:
            logger.warning("No LLM providers configured. Nodes requiring LLM will fail.")

        # Create execution context with providers
        context = ExecutionContext(
            run_id=run_id,
            pipeline_id=pipeline_detail.id,
            pipeline_version=pipeline_detail.version,
            pipeline_input=inputs,
            providers=providers,
        )

        # Determine default provider (prefer anthropic if available)
        default_provider = None
        if "anthropic" in providers:
            default_provider = "anthropic"
        elif providers:
            default_provider = next(iter(providers.keys()))

        # Create execution controller for debugging/real-time updates
        controller = await create_controller(
            run_id=run_id,
            breakpoints=breakpoints,
        )

        # Create executor WITH providers, context, and hooks
        executor = DAGExecutor(
            registry=registry,
            context=context,
            providers=providers,
            default_provider=default_provider,
            hooks=controller,  # Pass controller as hooks
        )
        logger.info(f"[{run_id}] Created DAGExecutor")
        logger.info(f"[{run_id}]   executor.context.llm: {executor.context.llm}")
        if executor.context.llm:
            logger.info(f"[{run_id}]   executor.context.llm._provider: {executor.context.llm._provider}")
            logger.info(f"[{run_id}]   executor.context.llm._provider type: {type(executor.context.llm._provider)}")

        # Execute the pipeline stages
        logger.info(f"[{run_id}] Starting DAG execution...")
        stage_results_raw = await executor.execute(
            stages=core_config.stages,
            pipeline_input=inputs,
        )
        logger.info(f"[{run_id}] DAG execution completed with {len(stage_results_raw)} results")

        # Convert ComponentResult objects to StageResult for storage
        stage_results = {}
        final_output = None

        for stage_id, comp_result in stage_results_raw.items():
            stage_results[stage_id] = StageResult(
                stage_id=stage_id,
                status=comp_result.status,
                output=comp_result.output,
                started_at=comp_result.started_at,
                completed_at=comp_result.completed_at,
                duration_ms=int((comp_result.completed_at - comp_result.started_at).total_seconds() * 1000) if comp_result.completed_at and comp_result.started_at else None,
                error=None,
            )

        # Get final output from the output stage
        if core_config.output_stage_id and core_config.output_stage_id in stage_results_raw:
            final_output = stage_results_raw[core_config.output_stage_id].output
        elif stage_results_raw:
            # Use the last stage's output as fallback
            last_stage_id = list(stage_results_raw.keys())[-1]
            final_output = stage_results_raw[last_stage_id].output

        # Update run with success
        run_storage.complete_run(
            run_id=run_id,
            status="completed",
            output=final_output,
            stage_results=stage_results,
            org_id=org_id,
        )

    except ExecutionError as e:
        # Update run with failure
        import traceback
        import sys
        print(f"[{run_id}] ExecutionError: {e}", file=sys.stderr, flush=True)
        print(f"[{run_id}] Traceback:\n{traceback.format_exc()}", file=sys.stderr, flush=True)
        run_storage.complete_run(
            run_id=run_id,
            status="failed",
            error=str(e),
            org_id=org_id,
        )
    except Exception as e:
        # Update run with unexpected error
        import traceback
        import sys
        print(f"[{run_id}] Unexpected error: {e}", file=sys.stderr, flush=True)
        print(f"[{run_id}] Traceback:\n{traceback.format_exc()}", file=sys.stderr, flush=True)
        run_storage.complete_run(
            run_id=run_id,
            status="failed",
            error=f"Unexpected error: {str(e)}",
            org_id=org_id,
        )
    finally:
        # Clean up controller
        if controller:
            await remove_controller(run_id)


@router.post(
    "/pipelines/{pipeline_id}/run",
    response_model=RunDetail,
    status_code=202,
    summary="Execute a pipeline",
    description="Start execution of a pipeline with provided inputs.",
    responses={404: {"model": APIError}}
)
async def execute_pipeline(
    pipeline_id: str,
    request: ExecutePipelineRequest,
    background_tasks: BackgroundTasks,
    pipeline_storage: PipelineStorage = Depends(get_pipeline_storage),
    run_storage: RunStorage = Depends(get_run_storage),
    registry: ComponentRegistry = Depends(get_registry),
    auth: Optional[AuthContext] = Depends(optional_auth),
) -> RunDetail:
    """Execute a pipeline."""
    # Pass org_id from auth context for multi-tenancy
    org_id = auth.org.id if auth else None

    # Get pipeline
    pipeline = pipeline_storage.get(pipeline_id, org_id=org_id)
    if not pipeline:
        raise HTTPException(
            status_code=404,
            detail=f"Pipeline '{pipeline_id}' not found"
        )

    # Create run record
    run = run_storage.create(
        pipeline_id=pipeline_id,
        inputs=request.inputs,
        org_id=org_id,
    )

    # Schedule background execution
    background_tasks.add_task(
        _execute_pipeline_task,
        run.id,
        pipeline,
        request.inputs,
        registry,
        run_storage,
        None,  # breakpoints
        org_id,
    )

    # Audit log if authenticated
    if auth:
        auth_service = get_auth_service()
        auth_service.log_action(
            org_id=auth.org.id,
            action="run.execute",
            resource_type="run",
            resource_id=run.id,
            api_key_id=auth.api_key.id if auth.api_key else None,
            user_id=auth.user.id if auth.user else None,
            details={"pipeline_id": pipeline_id, "pipeline_name": pipeline.name},
            ip_address=auth.ip_address,
            user_agent=auth.user_agent,
        )

    return run


@router.post(
    "/debug/run",
    response_model=RunDetail,
    status_code=202,
    summary="Start a debug run from pipeline definition",
    description="Execute a pipeline from inline definition (for VSCode debugging).",
)
async def debug_run(
    request: DebugRunRequest,
    background_tasks: BackgroundTasks,
    run_storage: RunStorage = Depends(get_run_storage),
    registry: ComponentRegistry = Depends(get_registry),
    auth: Optional[AuthContext] = Depends(optional_auth),
) -> RunDetail:
    """Start a debug run from inline pipeline definition."""
    from flowmason_studio.models.api import PipelineStage, PipelineDetail

    org_id = auth.org.id if auth else None
    pipeline_data = request.pipeline

    # Convert inline pipeline to PipelineDetail
    stages = []
    for stage_data in pipeline_data.get("stages", []):
        stages.append(PipelineStage(
            id=stage_data.get("id"),
            name=stage_data.get("name", stage_data.get("id")),
            component_type=stage_data.get("component_type") or stage_data.get("component"),
            config=stage_data.get("config", {}),
            input_mapping=stage_data.get("input_mapping", {}),
            depends_on=stage_data.get("depends_on", []),
        ))

    now = datetime.now()
    pipeline = PipelineDetail(
        id=f"debug-{now.strftime('%Y%m%d%H%M%S')}",
        name=pipeline_data.get("name", "Debug Pipeline"),
        version=pipeline_data.get("version", "1.0.0"),
        description=pipeline_data.get("description", "Debug run from VSCode"),
        category=pipeline_data.get("category"),
        tags=pipeline_data.get("tags", []),
        status="draft",
        stages=stages,
        input_schema=pipeline_data.get("input_schema", {}),
        output_schema=pipeline_data.get("output_schema", {}),
        output_stage_id=pipeline_data.get("output_stage_id"),
        llm_settings=pipeline_data.get("llm_settings"),
        created_at=now,
        updated_at=now,
    )

    # Create run record
    run = run_storage.create(
        pipeline_id=pipeline.id,
        inputs=request.inputs,
        org_id=org_id,
    )

    # Schedule background execution with breakpoints
    background_tasks.add_task(
        _execute_pipeline_task,
        run.id,
        pipeline,
        request.inputs,
        registry,
        run_storage,
        request.breakpoints if request.breakpoints else None,
        org_id,
    )

    return run


@router.get(
    "/runs",
    response_model=RunListResponse,
    summary="List runs",
    description="List all pipeline runs with optional filtering."
)
async def list_runs(
    pipeline_id: Optional[str] = Query(None, description="Filter by pipeline ID"),
    status: Optional[str] = Query(None, description="Filter by status"),
    limit: int = Query(100, ge=1, le=1000, description="Maximum results"),
    offset: int = Query(0, ge=0, description="Offset for pagination"),
    run_storage: RunStorage = Depends(get_run_storage),
    auth: Optional[AuthContext] = Depends(optional_auth),
) -> RunListResponse:
    """List all runs."""
    # Pass org_id from auth context for multi-tenancy
    org_id = auth.org.id if auth else None

    runs, total = run_storage.list(
        pipeline_id=pipeline_id,
        status=status,
        limit=limit,
        offset=offset,
        org_id=org_id,
    )

    return RunListResponse(
        runs=runs,
        total=total,
    )


@router.get(
    "/runs/{run_id}",
    response_model=RunDetail,
    summary="Get run details",
    description="Get detailed information about a specific run.",
    responses={404: {"model": APIError}}
)
async def get_run(
    run_id: str,
    run_storage: RunStorage = Depends(get_run_storage),
    auth: Optional[AuthContext] = Depends(optional_auth),
) -> RunDetail:
    """Get a run by ID."""
    # Pass org_id from auth context for multi-tenancy
    org_id = auth.org.id if auth else None

    run = run_storage.get(run_id, org_id=org_id)
    if not run:
        raise HTTPException(
            status_code=404,
            detail=f"Run '{run_id}' not found"
        )
    return run


@router.get(
    "/runs/{run_id}/trace",
    summary="Get run trace",
    description="Get detailed execution trace for a run.",
    responses={404: {"model": APIError}}
)
async def get_run_trace(
    run_id: str,
    run_storage: RunStorage = Depends(get_run_storage),
    auth: Optional[AuthContext] = Depends(optional_auth),
) -> dict:
    """Get execution trace for a run."""
    # Pass org_id from auth context for multi-tenancy
    org_id = auth.org.id if auth else None

    run = run_storage.get(run_id, org_id=org_id)
    if not run:
        raise HTTPException(
            status_code=404,
            detail=f"Run '{run_id}' not found"
        )

    # Return trace information
    return {
        "run_id": run.id,
        "pipeline_id": run.pipeline_id,
        "status": run.status,
        "started_at": run.started_at,
        "completed_at": run.completed_at,
        "duration_ms": run.duration_ms,
        "stages": {
            stage_id: {
                "status": result.status,
                "started_at": result.started_at,
                "completed_at": result.completed_at,
                "duration_ms": result.duration_ms,
                "output": result.output,
                "error": result.error,
            }
            for stage_id, result in (run.stage_results or {}).items()
        },
        "error": run.error,
    }


@router.post(
    "/runs/{run_id}/cancel",
    summary="Cancel a run",
    description="Attempt to cancel a running pipeline execution.",
    responses={404: {"model": APIError}, 400: {"model": APIError}}
)
async def cancel_run(
    run_id: str,
    run_storage: RunStorage = Depends(get_run_storage),
    auth: Optional[AuthContext] = Depends(optional_auth),
) -> dict:
    """Cancel a running pipeline."""
    # Pass org_id from auth context for multi-tenancy
    org_id = auth.org.id if auth else None

    run = run_storage.get(run_id, org_id=org_id)
    if not run:
        raise HTTPException(
            status_code=404,
            detail=f"Run '{run_id}' not found"
        )

    if run.status not in ["pending", "running"]:
        raise HTTPException(
            status_code=400,
            detail=f"Cannot cancel run with status '{run.status}'"
        )

    # Note: Actual cancellation of async task requires more infrastructure
    # For now, just mark as cancelled
    run_storage.update_status(run_id, "cancelled", org_id=org_id)

    # Audit log if authenticated
    if auth:
        auth_service = get_auth_service()
        auth_service.log_action(
            org_id=auth.org.id,
            action="run.cancel",
            resource_type="run",
            resource_id=run_id,
            api_key_id=auth.api_key.id if auth.api_key else None,
            user_id=auth.user.id if auth.user else None,
            details={"pipeline_id": run.pipeline_id},
            ip_address=auth.ip_address,
            user_agent=auth.user_agent,
        )

    return {
        "run_id": run_id,
        "status": "cancelled",
        "message": "Run cancellation requested"
    }


@router.delete(
    "/runs/{run_id}",
    status_code=204,
    summary="Delete a run",
    description="Delete a run record.",
    responses={404: {"model": APIError}}
)
async def delete_run(
    run_id: str,
    run_storage: RunStorage = Depends(get_run_storage),
    auth: Optional[AuthContext] = Depends(optional_auth),
) -> None:
    """Delete a run."""
    # Pass org_id from auth context for multi-tenancy
    org_id = auth.org.id if auth else None

    # Get run info for audit log before deletion
    run = run_storage.get(run_id, org_id=org_id) if auth else None

    success = run_storage.delete(run_id, org_id=org_id)
    if not success:
        raise HTTPException(
            status_code=404,
            detail=f"Run '{run_id}' not found"
        )

    # Audit log if authenticated
    if auth:
        auth_service = get_auth_service()
        auth_service.log_action(
            org_id=auth.org.id,
            action="run.delete",
            resource_type="run",
            resource_id=run_id,
            api_key_id=auth.api_key.id if auth.api_key else None,
            user_id=auth.user.id if auth.user else None,
            details={"pipeline_id": run.pipeline_id if run else None},
            ip_address=auth.ip_address,
            user_agent=auth.user_agent,
        )


# =============================================================================
# Debug Control Endpoints
# =============================================================================

@router.post(
    "/runs/{run_id}/debug/pause",
    response_model=DebugCommandResponse,
    summary="Pause execution",
    description="Pause a running pipeline execution.",
    responses={404: {"model": APIError}, 400: {"model": APIError}}
)
async def pause_run(
    run_id: str,
    run_storage: RunStorage = Depends(get_run_storage),
    auth: Optional[AuthContext] = Depends(optional_auth),
) -> DebugCommandResponse:
    """Pause a running pipeline."""
    # Pass org_id from auth context for multi-tenancy
    org_id = auth.org.id if auth else None

    run = run_storage.get(run_id, org_id=org_id)
    if not run:
        raise HTTPException(status_code=404, detail=f"Run '{run_id}' not found")

    if run.status != "running":
        raise HTTPException(
            status_code=400,
            detail=f"Cannot pause run with status '{run.status}'"
        )

    controller = await get_controller(run_id)
    if not controller:
        raise HTTPException(
            status_code=400,
            detail="No active execution controller for this run"
        )

    success = await controller.pause()
    state = controller.get_state()

    return DebugCommandResponse(
        run_id=run_id,
        success=success,
        mode=state.mode,
        message="Execution paused" if success else "Already paused",
        current_stage_id=state.current_stage_id,
        breakpoints=state.breakpoints,
    )


@router.post(
    "/runs/{run_id}/debug/resume",
    response_model=DebugCommandResponse,
    summary="Resume execution",
    description="Resume a paused pipeline execution.",
    responses={404: {"model": APIError}, 400: {"model": APIError}}
)
async def resume_run(
    run_id: str,
    run_storage: RunStorage = Depends(get_run_storage),
    auth: Optional[AuthContext] = Depends(optional_auth),
) -> DebugCommandResponse:
    """Resume a paused pipeline."""
    # Pass org_id from auth context for multi-tenancy
    org_id = auth.org.id if auth else None

    run = run_storage.get(run_id, org_id=org_id)
    if not run:
        raise HTTPException(status_code=404, detail=f"Run '{run_id}' not found")

    controller = await get_controller(run_id)
    if not controller:
        raise HTTPException(
            status_code=400,
            detail="No active execution controller for this run"
        )

    success = await controller.resume()
    state = controller.get_state()

    return DebugCommandResponse(
        run_id=run_id,
        success=success,
        mode=state.mode,
        message="Execution resumed" if success else "Not paused",
        current_stage_id=state.current_stage_id,
        breakpoints=state.breakpoints,
    )


@router.post(
    "/runs/{run_id}/debug/step",
    response_model=DebugCommandResponse,
    summary="Step execution",
    description="Execute one stage and then pause.",
    responses={404: {"model": APIError}, 400: {"model": APIError}}
)
async def step_run(
    run_id: str,
    run_storage: RunStorage = Depends(get_run_storage),
    auth: Optional[AuthContext] = Depends(optional_auth),
) -> DebugCommandResponse:
    """Step through one stage of a pipeline."""
    # Pass org_id from auth context for multi-tenancy
    org_id = auth.org.id if auth else None

    run = run_storage.get(run_id, org_id=org_id)
    if not run:
        raise HTTPException(status_code=404, detail=f"Run '{run_id}' not found")

    controller = await get_controller(run_id)
    if not controller:
        raise HTTPException(
            status_code=400,
            detail="No active execution controller for this run"
        )

    success = await controller.step()
    state = controller.get_state()

    return DebugCommandResponse(
        run_id=run_id,
        success=success,
        mode=state.mode,
        message="Step mode enabled",
        current_stage_id=state.current_stage_id,
        breakpoints=state.breakpoints,
    )


@router.post(
    "/runs/{run_id}/debug/stop",
    response_model=DebugCommandResponse,
    summary="Stop execution",
    description="Stop pipeline execution entirely.",
    responses={404: {"model": APIError}, 400: {"model": APIError}}
)
async def stop_run(
    run_id: str,
    run_storage: RunStorage = Depends(get_run_storage),
    auth: Optional[AuthContext] = Depends(optional_auth),
) -> DebugCommandResponse:
    """Stop a running pipeline."""
    # Pass org_id from auth context for multi-tenancy
    org_id = auth.org.id if auth else None

    run = run_storage.get(run_id, org_id=org_id)
    if not run:
        raise HTTPException(status_code=404, detail=f"Run '{run_id}' not found")

    controller = await get_controller(run_id)
    if not controller:
        # If no controller, just update status
        run_storage.update_status(run_id, "cancelled", org_id=org_id)
        return DebugCommandResponse(
            run_id=run_id,
            success=True,
            mode=DebugMode.STOPPED,
            message="Execution stopped",
            breakpoints=[],
        )

    success = await controller.stop()
    state = controller.get_state()

    return DebugCommandResponse(
        run_id=run_id,
        success=success,
        mode=state.mode,
        message="Execution stopped" if success else "Already stopped",
        current_stage_id=state.current_stage_id,
        breakpoints=state.breakpoints,
    )


@router.put(
    "/runs/{run_id}/debug/breakpoints",
    response_model=DebugCommandResponse,
    summary="Set breakpoints",
    description="Set breakpoints for a run. Replaces all existing breakpoints.",
    responses={404: {"model": APIError}, 400: {"model": APIError}}
)
async def set_breakpoints(
    run_id: str,
    request: SetBreakpointsRequest,
    run_storage: RunStorage = Depends(get_run_storage),
    auth: Optional[AuthContext] = Depends(optional_auth),
) -> DebugCommandResponse:
    """Set breakpoints for a run."""
    # Pass org_id from auth context for multi-tenancy
    org_id = auth.org.id if auth else None

    run = run_storage.get(run_id, org_id=org_id)
    if not run:
        raise HTTPException(status_code=404, detail=f"Run '{run_id}' not found")

    controller = await get_controller(run_id)
    if not controller:
        raise HTTPException(
            status_code=400,
            detail="No active execution controller for this run"
        )

    await controller.set_breakpoints(request.stage_ids)
    state = controller.get_state()

    return DebugCommandResponse(
        run_id=run_id,
        success=True,
        mode=state.mode,
        message=f"Set {len(request.stage_ids)} breakpoint(s)",
        current_stage_id=state.current_stage_id,
        breakpoints=state.breakpoints,
    )


@router.put(
    "/runs/{run_id}/debug/exception-breakpoints",
    response_model=DebugCommandResponse,
    summary="Set exception breakpoints",
    description="Set exception breakpoints for a run. Configure which exceptions pause execution.",
    responses={404: {"model": APIError}, 400: {"model": APIError}}
)
async def set_exception_breakpoints(
    run_id: str,
    request: SetExceptionBreakpointsRequest,
    run_storage: RunStorage = Depends(get_run_storage),
    auth: Optional[AuthContext] = Depends(optional_auth),
) -> DebugCommandResponse:
    """
    Set exception breakpoints for a run.

    Available filters:
    - 'all': Pause on all errors
    - 'uncaught': Pause on uncaught errors
    - 'error': Pause on ERROR severity
    - 'warning': Pause on WARNING severity
    - 'timeout': Pause on timeout errors
    - 'validation': Pause on validation errors
    - 'connectivity': Pause on connectivity errors
    """
    # Pass org_id from auth context for multi-tenancy
    org_id = auth.org.id if auth else None

    run = run_storage.get(run_id, org_id=org_id)
    if not run:
        raise HTTPException(status_code=404, detail=f"Run '{run_id}' not found")

    controller = await get_controller(run_id)
    if not controller:
        raise HTTPException(
            status_code=400,
            detail="No active execution controller for this run"
        )

    # Validate filters
    valid_filters = {f.value for f in ExceptionBreakpointFilter}
    invalid_filters = [f for f in request.filters if f not in valid_filters]
    if invalid_filters:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid exception filters: {invalid_filters}. Valid filters: {list(valid_filters)}"
        )

    await controller.set_exception_breakpoints(request.filters)
    state = controller.get_state()

    return DebugCommandResponse(
        run_id=run_id,
        success=True,
        mode=state.mode,
        message=f"Set {len(request.filters)} exception breakpoint filter(s)",
        current_stage_id=state.current_stage_id,
        breakpoints=state.breakpoints,
    )


@router.get(
    "/runs/{run_id}/debug/exception-info",
    summary="Get exception info",
    description="Get information about the current exception (if paused due to exception).",
    responses={404: {"model": APIError}}
)
async def get_exception_info(
    run_id: str,
    run_storage: RunStorage = Depends(get_run_storage),
    auth: Optional[AuthContext] = Depends(optional_auth),
) -> dict:
    """Get information about the current exception."""
    # Pass org_id from auth context for multi-tenancy
    org_id = auth.org.id if auth else None

    run = run_storage.get(run_id, org_id=org_id)
    if not run:
        raise HTTPException(status_code=404, detail=f"Run '{run_id}' not found")

    controller = await get_controller(run_id)
    if not controller:
        return {
            "run_id": run_id,
            "has_exception": False,
            "exception": None,
        }

    exception_info = controller.get_exception_info()

    if exception_info:
        return {
            "run_id": run_id,
            "has_exception": True,
            "exception": exception_info.model_dump(mode='json'),
        }
    else:
        return {
            "run_id": run_id,
            "has_exception": False,
            "exception": None,
        }


@router.get(
    "/runs/{run_id}/debug/state",
    response_model=DebugCommandResponse,
    summary="Get debug state",
    description="Get current debug state for a run.",
    responses={404: {"model": APIError}}
)
async def get_debug_state(
    run_id: str,
    run_storage: RunStorage = Depends(get_run_storage),
    auth: Optional[AuthContext] = Depends(optional_auth),
) -> DebugCommandResponse:
    """Get debug state for a run."""
    # Pass org_id from auth context for multi-tenancy
    org_id = auth.org.id if auth else None

    run = run_storage.get(run_id, org_id=org_id)
    if not run:
        raise HTTPException(status_code=404, detail=f"Run '{run_id}' not found")

    controller = await get_controller(run_id)
    if not controller:
        # Return default state if no controller
        return DebugCommandResponse(
            run_id=run_id,
            success=True,
            mode=DebugMode.RUNNING if run.status == "running" else DebugMode.STOPPED,
            message="No active debug session",
            breakpoints=[],
        )

    state = controller.get_state()

    return DebugCommandResponse(
        run_id=run_id,
        success=True,
        mode=state.mode,
        message="Debug state retrieved",
        current_stage_id=state.current_stage_id,
        breakpoints=state.breakpoints,
    )


@router.get(
    "/runs/{run_id}/debug/stage/{stage_id}/prompt",
    summary="Get stage prompt info",
    description="Get prompt information for an LLM stage.",
    responses={404: {"model": APIError}, 400: {"model": APIError}}
)
async def get_stage_prompt(
    run_id: str,
    stage_id: str,
    run_storage: RunStorage = Depends(get_run_storage),
    auth: Optional[AuthContext] = Depends(optional_auth),
) -> dict:
    """Get prompt information for a stage."""
    # Pass org_id from auth context for multi-tenancy
    org_id = auth.org.id if auth else None

    run = run_storage.get(run_id, org_id=org_id)
    if not run:
        raise HTTPException(status_code=404, detail=f"Run '{run_id}' not found")

    controller = await get_controller(run_id)
    if not controller:
        raise HTTPException(
            status_code=400,
            detail="No active execution controller for this run"
        )

    # Get stage info from controller
    stage_info = controller.get_stage_info(stage_id)
    if not stage_info:
        raise HTTPException(status_code=404, detail=f"Stage '{stage_id}' not found")

    # Return prompt info
    return {
        "run_id": run_id,
        "stage_id": stage_id,
        "stage_name": stage_info.get("name", stage_id),
        "component_type": stage_info.get("component_type", "unknown"),
        "system_prompt": stage_info.get("system_prompt", ""),
        "user_prompt": stage_info.get("user_prompt", ""),
        "variables": stage_info.get("variables", {}),
        "input": stage_info.get("input", {}),
        "output": stage_info.get("output"),
    }


@router.post(
    "/runs/{run_id}/debug/stage/{stage_id}/rerun",
    summary="Re-run a stage with modified prompt",
    description="Re-execute a single stage with modified prompts.",
    responses={404: {"model": APIError}, 400: {"model": APIError}}
)
async def rerun_stage(
    run_id: str,
    stage_id: str,
    request: dict,
    run_storage: RunStorage = Depends(get_run_storage),
    registry: ComponentRegistry = Depends(get_registry),
    auth: Optional[AuthContext] = Depends(optional_auth),
) -> dict:
    """Re-run a stage with modified prompts."""
    # Pass org_id from auth context for multi-tenancy
    org_id = auth.org.id if auth else None

    run = run_storage.get(run_id, org_id=org_id)
    if not run:
        raise HTTPException(status_code=404, detail=f"Run '{run_id}' not found")

    controller = await get_controller(run_id)
    if not controller:
        raise HTTPException(
            status_code=400,
            detail="No active execution controller for this run"
        )

    # Get the modified prompts from request
    system_prompt = request.get("system_prompt")
    user_prompt = request.get("user_prompt")

    try:
        # Re-execute the stage with modified prompts
        result = await controller.rerun_stage(
            stage_id=stage_id,
            registry=registry,
            system_prompt=system_prompt,
            user_prompt=user_prompt,
        )

        return {
            "run_id": run_id,
            "stage_id": stage_id,
            "success": True,
            "output": result.get("output"),
            "tokens": result.get("tokens"),
            "duration_ms": result.get("duration_ms"),
        }

    except Exception as e:
        logger.error(f"Failed to re-run stage {stage_id}: {e}")
        return {
            "run_id": run_id,
            "stage_id": stage_id,
            "success": False,
            "error": str(e),
        }
