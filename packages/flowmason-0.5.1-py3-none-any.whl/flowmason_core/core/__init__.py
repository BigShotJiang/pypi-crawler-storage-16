"""Core types and decorators for FlowMason components."""

from flowmason_core.core.types import (
    # Node types
    NodeInput,
    NodeOutput,
    # Operator types
    OperatorInput,
    OperatorOutput,
    # Control flow types
    ControlFlowInput,
    ControlFlowOutput,
    ControlFlowDirective,
    ControlFlowResult,
    ControlFlowType,
    # Field helper
    Field,
)
from flowmason_core.core.decorators import (
    node,
    operator,
    control_flow,
    is_flowmason_component,
    is_control_flow_component,
    get_component_type,
    get_control_flow_type,
)

__all__ = [
    # Node types
    "NodeInput",
    "NodeOutput",
    # Operator types
    "OperatorInput",
    "OperatorOutput",
    # Control flow types
    "ControlFlowInput",
    "ControlFlowOutput",
    "ControlFlowDirective",
    "ControlFlowResult",
    "ControlFlowType",
    # Field helper
    "Field",
    # Decorators
    "node",
    "operator",
    "control_flow",
    # Utilities
    "is_flowmason_component",
    "is_control_flow_component",
    "get_component_type",
    "get_control_flow_type",
]
