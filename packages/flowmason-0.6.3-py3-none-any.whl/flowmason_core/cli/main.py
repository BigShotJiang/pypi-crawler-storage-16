"""
FlowMason CLI main entry point.

This is the entry point for the `flowmason` command.
"""

import typer
from typing import Optional
from rich.console import Console
from rich.panel import Panel

# Create main app
app = typer.Typer(
    name="flowmason",
    help="FlowMason - AI Pipeline Orchestration Platform",
    no_args_is_help=True,
    rich_markup_mode="rich",
)

console = Console()


def version_callback(value: bool):
    """Show version and exit."""
    if value:
        from flowmason_core import __version__
        console.print(f"FlowMason CLI v{__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: Optional[bool] = typer.Option(
        None,
        "--version",
        "-v",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit",
    ),
):
    """
    FlowMason - AI Pipeline Orchestration Platform.

    Build, debug, and deploy intelligent workflows.

    Use --help on any command for more information.
    """
    pass


# Import and register command groups
from flowmason_core.cli.commands import run, validate, studio, init, org, deploy, pull, pack, install, auth

# Register command groups (sub-commands)
app.add_typer(studio.app, name="studio", help="Manage FlowMason Studio backend")
app.add_typer(org.app, name="org", help="Manage FlowMason org connections")
app.add_typer(auth.app, name="auth", help="Manage authentication and API keys")

# Register top-level commands
app.command(name="run")(run.run_pipeline)
app.command(name="validate")(validate.validate_pipeline)
app.command(name="init")(init.init_project)
app.command(name="deploy")(deploy.deploy)
app.command(name="pull")(pull.pull)
app.command(name="pack")(pack.pack)
app.command(name="install")(install.install)
app.command(name="uninstall")(install.uninstall)
app.command(name="list")(install.list_packages)


def cli():
    """Entry point for the CLI."""
    app()


if __name__ == "__main__":
    cli()
