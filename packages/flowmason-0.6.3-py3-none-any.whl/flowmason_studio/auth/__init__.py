"""
FlowMason Authentication Module

Provides API key and SAML authentication for FlowMason Studio.
"""

from .models import User, Organization, APIKey, APIKeyScope, Role
from .middleware import AuthContext, get_current_user, require_auth, optional_auth, require_scope
from .service import AuthService, get_auth_service
from .saml import (
    SAMLConfig,
    SAMLProvider,
    SAMLService,
    SAMLConfigService,
    get_saml_service,
    get_saml_config_service,
)

__all__ = [
    # Models
    "User",
    "Organization",
    "APIKey",
    "APIKeyScope",
    "Role",
    # Auth context
    "AuthContext",
    "get_current_user",
    "require_auth",
    "optional_auth",
    "require_scope",
    # Auth service
    "AuthService",
    "get_auth_service",
    # SAML
    "SAMLConfig",
    "SAMLProvider",
    "SAMLService",
    "SAMLConfigService",
    "get_saml_service",
    "get_saml_config_service",
]
