"""
FlowMason Authentication Middleware

FastAPI dependencies for API authentication.
"""

from typing import Optional, Tuple
from dataclasses import dataclass

from fastapi import Header, HTTPException, Depends, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

from .models import APIKey, Organization, User, APIKeyScope
from .service import get_auth_service


# HTTP Bearer scheme for API key auth
bearer_scheme = HTTPBearer(auto_error=False)


@dataclass
class AuthContext:
    """
    Authentication context passed to route handlers.

    Contains information about the authenticated entity.
    """
    org: Organization
    api_key: Optional[APIKey] = None
    user: Optional[User] = None

    # Request metadata
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None

    def has_scope(self, scope: APIKeyScope) -> bool:
        """Check if the current auth context has a specific scope"""
        if self.api_key is None:
            return True  # User auth has full scope
        return self.api_key.has_scope(scope)


async def get_api_key_from_header(
    authorization: Optional[HTTPAuthorizationCredentials] = Depends(bearer_scheme),
    x_api_key: Optional[str] = Header(None, alias="X-API-Key"),
) -> Optional[str]:
    """
    Extract API key from request headers.

    Supports two formats:
    - Authorization: Bearer <api_key>
    - X-API-Key: <api_key>
    """
    if authorization:
        return authorization.credentials
    return x_api_key


async def get_current_user(
    request: Request,
    api_key: Optional[str] = Depends(get_api_key_from_header),
) -> Optional[AuthContext]:
    """
    Get the current authenticated user/org from the API key.

    Returns None if no valid authentication is provided.
    Does not raise an exception - use require_auth for protected routes.
    """
    if not api_key:
        return None

    auth_service = get_auth_service()
    result = auth_service.verify_api_key(api_key)

    if not result:
        return None

    key, org = result

    # Get user if key is tied to one
    user = None
    if key.user_id:
        user = auth_service.get_user(key.user_id)

    return AuthContext(
        org=org,
        api_key=key,
        user=user,
        ip_address=request.client.host if request.client else None,
        user_agent=request.headers.get("user-agent"),
    )


async def require_auth(
    auth: Optional[AuthContext] = Depends(get_current_user),
) -> AuthContext:
    """
    Require authentication for a route.

    Raises 401 if no valid authentication is provided.

    Usage:
        @router.get("/protected")
        async def protected_route(auth: AuthContext = Depends(require_auth)):
            return {"org": auth.org.name}
    """
    if not auth:
        raise HTTPException(
            status_code=401,
            detail="Invalid or missing API key",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return auth


async def optional_auth(
    auth: Optional[AuthContext] = Depends(get_current_user),
) -> Optional[AuthContext]:
    """
    Optional authentication for a route.

    Returns None if no authentication is provided (doesn't raise).

    Usage:
        @router.get("/public")
        async def public_route(auth: Optional[AuthContext] = Depends(optional_auth)):
            if auth:
                return {"org": auth.org.name}
            return {"message": "Anonymous access"}
    """
    return auth


def require_scope(scope: APIKeyScope):
    """
    Decorator factory for requiring a specific API key scope.

    Usage:
        @router.post("/pipelines")
        async def create_pipeline(
            auth: AuthContext = Depends(require_scope(APIKeyScope.FULL))
        ):
            ...
    """
    async def scope_checker(
        auth: AuthContext = Depends(require_auth),
    ) -> AuthContext:
        if not auth.has_scope(scope):
            raise HTTPException(
                status_code=403,
                detail=f"API key does not have required scope: {scope.value}",
            )
        return auth

    return scope_checker


def require_org_role(min_role: str):
    """
    Require minimum organization role for user-based auth.

    Roles in order: viewer < developer < admin < owner

    Usage:
        @router.delete("/pipelines/{id}")
        async def delete_pipeline(
            auth: AuthContext = Depends(require_org_role("admin"))
        ):
            ...
    """
    from .models import Role

    role_hierarchy = {
        Role.VIEWER: 0,
        Role.DEVELOPER: 1,
        Role.ADMIN: 2,
        Role.OWNER: 3,
    }

    required_level = role_hierarchy.get(Role(min_role), 0)

    async def role_checker(
        auth: AuthContext = Depends(require_auth),
    ) -> AuthContext:
        if not auth.user:
            # API key auth - check scopes instead
            if min_role in ("admin", "owner"):
                if not auth.has_scope(APIKeyScope.FULL):
                    raise HTTPException(
                        status_code=403,
                        detail=f"API key does not have admin scope",
                    )
            return auth

        # User auth - check role
        auth_service = get_auth_service()
        role = auth_service.get_user_role_in_org(auth.user.id, auth.org.id)

        if not role or role_hierarchy.get(role, 0) < required_level:
            raise HTTPException(
                status_code=403,
                detail=f"Insufficient permissions. Required role: {min_role}",
            )

        return auth

    return role_checker


class RateLimiter:
    """
    Simple in-memory rate limiter.

    For production, use Redis or similar.
    """

    def __init__(self):
        self._requests: dict[str, list[float]] = {}

    def check(self, key: str, limit: int, window_seconds: int = 3600) -> bool:
        """
        Check if request is within rate limit.

        Args:
            key: Identifier (e.g., API key ID)
            limit: Maximum requests per window
            window_seconds: Window size in seconds (default: 1 hour)

        Returns:
            True if within limit, False if exceeded
        """
        import time

        now = time.time()
        window_start = now - window_seconds

        # Get requests in window
        if key not in self._requests:
            self._requests[key] = []

        # Clean old requests
        self._requests[key] = [
            t for t in self._requests[key]
            if t > window_start
        ]

        # Check limit
        if len(self._requests[key]) >= limit:
            return False

        # Add this request
        self._requests[key].append(now)
        return True


# Global rate limiter instance
_rate_limiter = RateLimiter()


async def check_rate_limit(
    auth: AuthContext = Depends(require_auth),
) -> AuthContext:
    """
    Check rate limit for the authenticated entity.

    Raises 429 if rate limit is exceeded.
    """
    if auth.api_key:
        key_id = auth.api_key.id
        limit = auth.api_key.rate_limit
    else:
        # User auth - use org-level limit
        key_id = f"user_{auth.user.id if auth.user else 'unknown'}"
        limit = 1000  # Default limit

    if not _rate_limiter.check(key_id, limit):
        raise HTTPException(
            status_code=429,
            detail="Rate limit exceeded. Try again later.",
            headers={"Retry-After": "3600"},
        )

    return auth
