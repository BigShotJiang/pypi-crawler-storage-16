"""Data models for FlowMason Studio."""
