"""
TransformRows.

TransformRows allow making column transformation over a Pandas Dataframe.
"""

from .TransformRows import TransformRows

__all__ = ["TransformRows"]
