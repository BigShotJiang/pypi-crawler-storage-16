"""
Generic type handler for Workday RaaS (Reports as a Service) custom reports.

This handler can execute ANY Workday custom report without requiring
specific type implementations. It uses dynamic parameter passing and
automatic DataFrame generation from XML responses with dynamic parsing.
"""
from typing import Optional, Dict, Any, List
import pandas as pd
from urllib.parse import urlencode
import xmltodict

from .base import WorkdayTypeBase
from ..utils import safe_serialize
from ....interfaces.http import HTTPService


class CustomReportType(WorkdayTypeBase):
    """
    Generic handler for ANY Workday RaaS custom report.

    This type can execute any Workday custom report by accepting:
    - report_name: The name of the report in Workday
    - report_owner: The email/ID of the report owner (optional, uses default)
    - **query_params: Any report-specific parameters

    The handler automatically:
    - Builds the correct RaaS URL
    - Authenticates with Basic Auth
    - Converts XML response to DataFrame with dynamic parsing
    - Handles nested structures and arrays appropriately

    Example usage:
        # Time blocks report
        df = await custom_report.execute(
            report_name="Extract_Time_Blocks_-_Navigator",
            Start_Date="2025-11-17",
            End_Date="2025-11-17",
            Worker="12345"
        )

        # Different report with different parameters
        df = await custom_report.execute(
            report_name="Absence_Calendar_Report",
            Year="2025",
            Month="11"
        )
    """

    def __init__(self, component):
        super().__init__(component)
        # Initialize HTTP client for REST API access
        self._http_client = None

    def _strip_namespace_prefix(self, obj: Any) -> Any:
        """
        Recursively strip namespace prefixes from XML dict keys.

        Converts keys like 'wd:Report_Entry' to 'Report_Entry'
        """
        if isinstance(obj, dict):
            new = {}
            for k, v in obj.items():
                # Remove namespace prefix (e.g., "wd:" -> "")
                key = k.split(":")[-1] if ":" in k else k
                new[key] = self._strip_namespace_prefix(v)
            return new
        if isinstance(obj, list):
            return [self._strip_namespace_prefix(i) for i in obj]
        return obj

    def _parse_xml_to_entries(self, xml_bytes: bytes) -> List[Dict[str, Any]]:
        """
        Parse XML response from Workday RaaS and extract report entries.

        Args:
            xml_bytes: Raw XML response as bytes

        Returns:
            List of dictionaries representing report entries
        """
        try:
            # Parse XML using xmltodict
            parsed_xml = xmltodict.parse(
                xml_bytes,
                process_namespaces=False,
                attr_prefix="",
                cdata_key="_value",
            )

            # Strip namespace prefixes from all keys
            parsed_xml = self._strip_namespace_prefix(parsed_xml)

            # Try to find report data in multiple possible locations
            # Workday may wrap in SOAP envelope or return directly
            report_data = (
                parsed_xml.get("Envelope", {}).get("Body", {}).get("Report_Data") or
                parsed_xml.get("Report_Data") or
                parsed_xml.get("Report") or
                parsed_xml
            )

            # Extract Report_Entry elements
            entries = []
            if isinstance(report_data, dict):
                entries = report_data.get("Report_Entry", [])
            elif isinstance(report_data, list):
                entries = report_data

            # Ensure entries is a list
            if entries and not isinstance(entries, list):
                entries = [entries]

            return entries

        except Exception as e:
            self._logger.error(f"Error parsing XML response: {e}")
            raise

    def _build_raas_url(
        self,
        report_name: str,
        report_owner: Optional[str] = None,
        query_params: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Build the RaaS (Reports as a Service) REST API URL.

        URL pattern:
        https://<workday-url>/ccx/service/customreport2/<tenant>/<owner>/<report_name>?<params>

        Args:
            report_name: Name of the report (e.g., "Extract_Time_Blocks_-_Navigator")
            report_owner: Email of report owner (defaults to configured owner)
            query_params: Dictionary of query parameters for the report

        Returns:
            Full URL for the RaaS REST API request
        """
        # Get configuration from component
        tenant = getattr(self.component, 'tenant', 'troc')
        owner = report_owner or getattr(
            self.component,
            'report_owner',
            'jleon@trocglobal.com'
        )
        workday_url = getattr(
            self.component,
            'workday_url',
            'https://services1.wd501.myworkday.com'
        )

        # Construct base URL
        # RaaS endpoint pattern: /ccx/service/customreport2/<tenant>/<owner>/<report_name>
        url = f"{workday_url}/ccx/service/customreport2/{tenant}/{owner}/{report_name}"

        # Add query parameters if provided
        if query_params:
            query_string = urlencode(query_params, safe='@')
            url = f"{url}?{query_string}"

        return url

    async def execute(
        self,
        report_name: str,
        report_owner: Optional[str] = None,
        **query_params
    ) -> pd.DataFrame:
        """
        Execute any Workday RaaS custom report.

        This method accepts the report name and any report-specific parameters.
        It automatically handles authentication, request execution, and
        DataFrame conversion.

        Args:
            report_name: Name of the report in Workday (required)
            report_owner: Email/ID of report owner (optional, uses default from config)
            **query_params: Any report-specific parameters (e.g., Start_Date, Worker, etc.)

        Returns:
            DataFrame with automatic column detection from JSON response

        Example:
            df = await custom_report.execute(
                report_name="Extract_Time_Blocks_-_Navigator",
                Start_Date="2025-11-17",
                End_Date="2025-11-17",
                Worker="12345"
            )
        """
        # Filter out internal parameters that shouldn't be sent to Workday
        internal_params = {
            'use_basic_auth', 'report_owner', 'report_username', 'report_password',
            'auth_type', 'wsdl_path', 'client_id', 'client_secret', 'token_url',
            'refresh_token', 'tenant', 'workday_url'
        }

        # Only pass Workday-specific parameters to the RaaS URL
        filtered_params = {
            k: v for k, v in query_params.items()
            if k not in internal_params
        }

        # Build the RaaS URL with filtered parameters
        url = self._build_raas_url(report_name, report_owner, filtered_params)

        self._logger.info(f"Executing custom report: {report_name}")
        self._logger.debug(f"RaaS URL: {url}")

        # Initialize HTTP client if needed
        if self._http_client is None:
            # Get credentials from component
            username = getattr(
                self.component,
                'report_username',
                None
            )
            password = getattr(
                self.component,
                'report_password',
                None
            )

            if not username or not password:
                raise ValueError(
                    "Custom report credentials not configured. "
                    "Set WORKDAY_REPORT_USERNAME and WORKDAY_REPORT_PASSWORD"
                )

            # Create HTTP client with Basic Auth
            self._http_client = HTTPService(
                credentials={
                    "username": username,
                    "password": password
                },
                auth_type="basic",
                accept="application/xml",
                timeout=120
            )
            # Set logger for HTTP client
            self._http_client._logger = self._logger

        # Execute the REST API request
        try:
            result, error = await self._http_client.async_request(
                url=url,
                method="GET",
                accept="application/xml"
            )

            if error:
                self._logger.error(f"Error fetching custom report: {error}")
                raise Exception(f"Failed to fetch custom report: {error}")

            if not result:
                self._logger.warning("Empty response from custom report")
                return pd.DataFrame()

        except Exception as exc:
            self._logger.error(f"Error executing custom report via REST: {exc}")
            raise

        # Parse the XML response
        # Convert to bytes for xmltodict
        xml_bytes = result if isinstance(result, (bytes, bytearray)) else str(result).encode()

        # Parse XML to list of dicts
        raw_response = self._parse_xml_to_entries(xml_bytes)

        if not raw_response:
            self._logger.warning("No report entries found in XML response")
            return pd.DataFrame()

        # Convert parsed XML (now as list of dicts) to DataFrame
        # Use json_normalize to automatically flatten nested structures
        df = pd.json_normalize(
            raw_response,
            sep='_',
            max_level=None  # Flatten all levels
        )

        # Handle array fields that couldn't be flattened
        # These will be serialized to JSON strings for DataFrame compatibility
        for col in df.columns:
            if df[col].dtype == 'object':
                # Check if column contains lists of dicts (complex nested structures)
                non_null = df[col].dropna()
                sample = non_null.iloc[0] if not non_null.empty else None
                if isinstance(sample, list):
                    # Serialize arrays to JSON strings
                    df[col] = df[col].apply(
                        lambda x: safe_serialize(x) if isinstance(x, list) else x
                    )

        self._logger.info(
            f"Retrieved {len(df)} entries from custom report '{report_name}' "
            f"with {len(df.columns)} columns"
        )

        return df
