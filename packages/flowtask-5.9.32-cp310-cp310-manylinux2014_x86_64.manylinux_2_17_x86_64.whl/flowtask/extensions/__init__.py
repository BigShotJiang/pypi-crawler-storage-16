from .abstract import BaseExtension

__all__ = ("BaseExtension",)
