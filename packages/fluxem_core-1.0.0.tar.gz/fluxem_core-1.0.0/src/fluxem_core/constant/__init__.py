"""
Constantes para el motor de búsqueda.
"""
from .search_constants import SearchConstants

__all__ = ["SearchConstants"]
