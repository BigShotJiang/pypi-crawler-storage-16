__all__ = ["Elastic"]

from flyteplugins.pytorch.task import Elastic
