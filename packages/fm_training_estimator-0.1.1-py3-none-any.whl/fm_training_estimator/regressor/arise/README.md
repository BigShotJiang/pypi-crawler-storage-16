# Arise Regressor

Train the regressor:
```
python -m fm_training_estimator.regressor.arise.train
```
