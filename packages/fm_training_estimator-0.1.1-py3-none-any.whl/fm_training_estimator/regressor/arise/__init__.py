# Local
from .arise import AriseRegressor

__all__ = ["AriseRegressor"]
