# Local
from .linear import LinearRegressor

__all__ = ["LinearRegressor"]
