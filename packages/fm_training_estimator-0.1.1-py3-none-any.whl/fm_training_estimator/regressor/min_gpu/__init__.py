from .recommender import MinGpuRecommenderCaller

__all__ = ["MinGpuRecommenderCaller"]