class TokenEstimator:
    def get_total_tokens(self):
        pass

    def get_estimated_batch_width(self, batch_size: int):
        pass

    def get_num_samples(self):
        pass

    def get_max_sample_length(self):
        pass
