# Local
from .xgboost import XGBoostRegressor

__all__ = ["XGBoostRegressor"]
