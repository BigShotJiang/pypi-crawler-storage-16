# SDK

To use the estimator directly, refer to the `../ui` folder.

This SDK is meant to be used from other Python programs to get estimates. Refer to examples in the `examples/` folder to learn more.
