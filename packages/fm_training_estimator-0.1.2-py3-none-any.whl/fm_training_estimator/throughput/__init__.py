# Local
from .hybrid import HybridSpeedEstimator
from .mock import MockSpeedEstimator
