# Local
from .time import get_total_time
