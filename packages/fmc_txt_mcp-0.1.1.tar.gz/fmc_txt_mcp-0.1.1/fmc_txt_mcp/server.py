import os
from mcp.server import Server

def main():
    # Read file path from environment variable
    file_path = os.environ.get("FMC_FILE", "fmc_output.txt")

    server = Server("fmc_txt_mcp")

    @server.resource("fmc_raw")
    def get_raw():
        try:
            with open(file_path, "r") as f:
                return f.read()
        except FileNotFoundError:
            return f"Error: File not found at {file_path}"
        except Exception as e:
            return f"Error reading file: {e}"

    server.run()