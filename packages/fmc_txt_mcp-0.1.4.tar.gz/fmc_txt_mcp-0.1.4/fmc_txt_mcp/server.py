import os
from mcp.server import Server

server = Server("fmc_txt_mcp")

def main():
    # Get the FMC file path from environment
    fmc_file = os.environ.get("FMC_FILE")
    if not fmc_file:
        print("Error: FMC_FILE environment variable not set")
        return

    # Load the file contents
    if os.path.exists(fmc_file):
        with open(fmc_file, "r", encoding="utf-8") as f:
            content = f.read()
        # Register the raw file as a resource
        server.add_resource(
            uri="fmc_raw",
            name="FMC Raw Output",
            description="Raw FMC text output file",
            mimeType="text/plain",
            content=content,
        )
    else:
        print(f"Error: FMC file not found at {fmc_file}")
        return

    # Start the stdio loop
    server.run()