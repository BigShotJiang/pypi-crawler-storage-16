"""FMC MCP Server - Dynamic MCP server for Cisco Firepower Management Center."""

from fmcmcp.__version__ import __version__

__all__ = ["__version__"]
