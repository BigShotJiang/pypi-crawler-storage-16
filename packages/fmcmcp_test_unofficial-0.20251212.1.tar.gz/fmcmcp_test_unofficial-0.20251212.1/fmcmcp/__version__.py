"""Version information for fmcmcp."""

__version__ = "0.20250126.0"
