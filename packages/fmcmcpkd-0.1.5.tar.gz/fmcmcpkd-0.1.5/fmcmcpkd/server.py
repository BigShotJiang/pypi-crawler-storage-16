import os
from mcp.server.fastmcp import FastMCP
from mcp.types import Resource

# Create an MCP server
mcp = FastMCP("fmcmcpkd", json_response=True)

# Expose the FMC file as a resource
@mcp.resource("file://fmc_raw")
def fmc_raw() -> Resource:
    """Raw FMC text output file"""
    fmc_file = os.environ.get("FMC_FILE")
    if not fmc_file or not os.path.exists(fmc_file):
        raise FileNotFoundError("FMC_FILE not set or file missing")

    with open(fmc_file, "r", encoding="utf-8") as f:
        content = f.read()

    return Resource(
        uri="file://fmc_raw",   # ✅ valid URI format
        name="FMC Raw Output",
        description="Raw FMC text output file",
        mimeType="text/plain",
        data=content,
    )

def main():
    """Entrypoint for fmcmcpkd"""
    mcp.run(transport="stdio")
