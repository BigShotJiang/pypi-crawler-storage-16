import os
import re
from mcp.server.fastmcp import FastMCP
from mcp.types import Resource

# Create an MCP server
mcp = FastMCP("fmcmcpkd", json_response=True)

def _read_fmc_file() -> str:
    """Read the entire FMC file"""
    fmc_file = os.environ.get("FMC_FILE")
    if not fmc_file or not os.path.exists(fmc_file):
        raise FileNotFoundError("FMC_FILE not set or file missing")
    with open(fmc_file, "r", encoding="utf-8") as f:
        return f.read()

def _read_fmc_sections() -> dict:
    """Read FMC file and split into sections by headers"""
    content = _read_fmc_file()
    # Split by section headers === Section Name ===
    sections = re.split(r"=== (.*?) ===", content)
    parsed = {}
    for i in range(1, len(sections), 2):
        header = sections[i].strip()
        body = sections[i+1].strip()
        parsed[header] = body
    return parsed

# Resource: full FMC file
@mcp.resource("file://fmc_raw")
def fmc_raw() -> Resource:
    """Return the full FMC file as plain text"""
    return Resource(
        uri="file://fmc_raw",
        name="FMC Raw Output",
        description="Full FMC text output file",
        mimeType="text/plain",
        data=_read_fmc_file(),
    )

# Tools for each section
@mcp.tool()
def get_server_version() -> str:
    """Return FMC Server Version section"""
    return _read_fmc_sections().get("FMC Server Version", "Section not found")

@mcp.tool()
def get_prefilter_policies() -> str:
    """Return Prefilter Policies section"""
    return _read_fmc_sections().get("Prefilter Policies", "Section not found")

@mcp.tool()
def get_access_policies() -> str:
    """Return Access Policies section"""
    return _read_fmc_sections().get("Access Policies", "Section not found")

@mcp.tool()
def get_nat_policies() -> str:
    """Return NAT Policies section"""
    return _read_fmc_sections().get("NAT Polices", "Section not found")

@mcp.tool()
def get_network_objects() -> str:
    """Return FMC Network Objects section"""
    return _read_fmc_sections().get("FMC Network Objects", "Section not found")

# Optional: generic tool
@mcp.tool()
def get_section(name: str) -> str:
    """Return any FMC section by name"""
    return _read_fmc_sections().get(name, f"Section '{name}' not found")

def main():
    """Entrypoint for fmcmcpkd"""
    mcp.run(transport="stdio")

if __name__ == "__main__":
    main()