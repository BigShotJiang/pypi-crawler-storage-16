import av

av = av

open = av.open
AudioResampler = av.AudioResampler
AudioFrame = av.AudioFrame
