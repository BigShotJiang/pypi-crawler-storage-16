"""Contains resources used in this package.

Some resources contained here may also be used
outside this package.
"""
