# fmu-sumo

[![Documentation Status](https://readthedocs.org/projects/fmu-sumo/badge/?version=latest)](https://fmu-sumo.readthedocs.io/en/latest/?badge=latest)


## Documentation and guidelines
:link: [fmu-sumo documentation](https://fmu-sumo.readthedocs.io/en/latest/)


## Contribute
[Contribution guidelines](./CONTRIBUTING.md)
