"""
folder2md4llms - Enhanced tool to concatenate folder contents into markdown format for LLM consumption.
"""

from .__version__ import __version__

__author__ = "Ricardo Henriques"
__email__ = "ricardo@henriqueslab.org"
