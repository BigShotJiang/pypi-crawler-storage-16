"""Main entry point for python -m folder2md4llms."""

from .cli import main

if __name__ == "__main__":
    main()
