"""Folios - A document management server for LLM contexts."""

from importlib.metadata import version

__version__ = version("folios")
