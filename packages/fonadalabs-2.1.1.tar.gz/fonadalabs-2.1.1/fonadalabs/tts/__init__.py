"""
FonadaLabs TTS (Text-to-Speech) Module
"""

from .client import TTSClient, TTSError

__all__ = ["TTSClient", "TTSError"]


