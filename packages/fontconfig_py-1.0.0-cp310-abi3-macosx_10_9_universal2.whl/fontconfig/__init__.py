"""fontconfig package"""

from .fontconfig import *  # noqa: F401,F403

__version__ = "1.0.0"
