# foodeo-core
Proyecto de librería de clase de dominio de foodeo
