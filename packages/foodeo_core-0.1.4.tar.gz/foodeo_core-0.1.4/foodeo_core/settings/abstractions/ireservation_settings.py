from abc import ABC, abstractmethod

from domains.settings.models.reservation_settings import ReservationSettings


class IReservationSettings(ABC):

    @abstractmethod
    def get_settings(self) -> ReservationSettings:
        pass
