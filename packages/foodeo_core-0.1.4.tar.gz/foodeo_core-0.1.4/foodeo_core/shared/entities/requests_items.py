from typing import Optional

from core.misc.enums import PRODUCT_TYPE_NAME
from domains.shared.entities.irequests import IProductsRequest, IModifierRequest



class ProductInRequest(IProductsRequest):
    request_item: Optional[int] = None
    order: Optional[int] = None

    def get_type_name(self) -> PRODUCT_TYPE_NAME:
        return PRODUCT_TYPE_NAME.REQUEST_ITEM

    def get_id(self) -> int:
        return self.request_item
