from pydantic import Field

from core.base.core_model import CoreModel


class Dataphone(CoreModel):
    def is_valid(self, raise_exception: bool = True):
        pass

    name: str = Field(..., description="")
    key: str = Field(..., description="")
