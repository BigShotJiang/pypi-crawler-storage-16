"""
NOTE (swapnil) - This file is deprecated and should be removed once forcen_bonappetit is updated 
with a proper websocket based server/client implementation

---

Motivation:
- Communication to Server is done over the wire, so data is sent through JSON packets
- All commands have corresponding (different) arguments
- Strong typing is useful, so we want to only use JSON for transport, and switch back to strong
    types on both sides immediately

Strategy:
- Send all commands with a Tag (enum) and Payload (variant of many types)
- The Tag indicates the type to expect from the Payload
    - NOTE (swapnil) - should we combine this into a single `isinstance` check?
- Since args are variadic, they all need to be wrapped in a single type
    IE, the server side gets a json which contains:
        - Command Type (enum)
        - Command Args (variadic)
    And can parse the Command Args into a concrete dataclass based on the Command Type

    - This is why there are basic dataclasses that wrap single args
"""

from enum import Enum, auto, IntEnum
from typing import Optional, Dict, Any, List, Union, Tuple


import json
import dataclasses
from dataclasses_json import dataclass_json, Undefined, DataClassJsonMixin
from dataclasses import dataclass, field
from typing import Type
from typing_extensions import Self

class JsonBase:
    def to_json(self) -> str:
        return json.dumps(dataclasses.asdict(self))

    @classmethod
    def from_json(cls, json_str: str) -> Self:
        return cls.from_dict(json.loads(json_str))
        
    @classmethod
    def from_dict(cls, kwargs: Dict[str, Any]) -> Self:
        if not isinstance(cls, JsonBase):
            return cls(**kwargs)  # type: ignore
        raise NotImplementedError("JsonBase needs to be derived to be used")


# Note: This list is likely bloated. Users should just verify 
# against SUCCESS and treat the rest as failure for now
class Result(Enum):
    SUCCESS = 0
    FAILURE = 1
    WARNING = 2
    CRITICAL = 3
    UNSUPPORTED = 4
    EXCEPTION = 5
    DEBUG = 6
    INFO = 7

@dataclass
class DetailedResult(JsonBase):
    result: Result
    message: str

class Command(IntEnum):
    CONNECT_TO_DEVICE = auto()
    DISCONNECT_FROM_DEVICE = auto()
    CLEAR_DEVICE_BUFFER = auto()
    DETECT_DEVICE_INFO = auto()
    GET_DEVICE_INFO = auto()
    ENABLE_CONTINUOUS_CONVERSION_MODE = auto()
    DISABLE_CONTINUOUS_CONVERSION_MODE = auto()
    ENABLE_BOOT_MODE = auto()
    DISABLE_BOOT_MODE = auto()
    PASSTHROUGH = auto()
    SET_DEVICE_MODE = auto()
    CALIBRATE_DEVICE = auto()
    RESET_CALIBRATION = auto()
    PROGRAM_BIN_FILE = auto()

class DeviceMode(IntEnum):
    BOOT = auto()
    CONTINUOUS_CONVERSION_DISABLED = auto()
    CONTINUOUS_CONVERSION_ENABLED = auto()

class PacketType(str, Enum):
    TYP_RTD_PCKT = "t"
    TYP_RES_PCKT = "r"
    TYP_EMC_PCKT = "e"
    TYP_ACK_PCKT = "a"
    TYP_ALL_PCKT = "ALL"
    
    @staticmethod
    def default_type():
        return PacketType.TYP_RTD_PCKT

    def id(self) -> str:
        if self.value == PacketType.TYP_RTD_PCKT: return "t"
        if self.value == PacketType.TYP_RES_PCKT: return "r"
        if self.value == PacketType.TYP_EMC_PCKT: return "e"
        if self.value == PacketType.TYP_ACK_PCKT: return "a"
        if self.value == PacketType.TYP_ALL_PCKT: return "ALL"
        raise ValueError(f"invalid packet type: {self.value}")
        


class QueueType(IntEnum):
    ALL_DATA_QUEUE = 0
    RTD_DATA_QUEUE = 1
    NON_RTD_DATA_QUEUE = 2
    EMCY_DATA_QUEUE = 3
    RESP_DATA_QUEUE = 4

class LinkType(IntEnum):
    SERIAL_PORT = 1
    UDP_PORT = 2


@dataclasses.dataclass
class EnableContinuousConversionModeArgs(JsonBase):
    force: bool

@dataclasses.dataclass
class DisableContinuousConversionModeArgs(JsonBase):
    force: bool

@dataclasses.dataclass
class GetRawDataArgs(JsonBase):
    packet_type: PacketType
    read_all: bool

@dataclasses.dataclass
class EnableBootModeArgs(JsonBase):
    force: bool

@dataclasses.dataclass
class SetDeviceModeArgs(JsonBase):
    mode: DeviceMode
    force: bool

@dataclasses.dataclass
class CalibrateDeviceArgs(JsonBase):
    time: Optional[float] = None

@dataclasses.dataclass
class PassThroughArgs(JsonBase):
    msg: str

@dataclasses.dataclass
class ProgramBinPathArgs(JsonBase):
    file_path: str
    device_path: str

@dataclasses.dataclass
class StartLoggingArgs(JsonBase):
    header: Optional[str] = None
    rawD: Optional[str] = None # this needs a better name, but i don't know what it's supposed to be
    processD: Optional[str] = None # this needs a better name, but i don't know what it's supposed to be
    folder: Optional[str] = None
    duration: Optional[float] = None


@dataclasses.dataclass
class ConnectToDeviceArgs(JsonBase):
    port: Optional[str] = None
    timeout: Optional[float] = None
    link_type: Optional[LinkType] = None

@dataclasses.dataclass
class ForceData(JsonBase):
    timestamp: float
    raw: List[float]
    processed: Optional[List[float]]

@dataclasses.dataclass
class ForceValueNamed:
    name: str
    value: float

@dataclasses.dataclass
class ForceDataNamed:
    timestamp: float
    raw: List[ForceValueNamed]

@dataclasses.dataclass
class DeviceCache(JsonBase):
    buffer_size: Optional[int] = None
    uid: Optional[str] = None
    firmware_version: Optional[str] = None
    num_channels: Optional[int] = None
    is_connected: bool = False
    latest_channel_values: Optional[List[float]] = None
    calibration_offsets: Optional[List[float]] = None
    calibration_data: Optional[List[List[float]]] = None


@dataclasses.dataclass
class DeviceInfo(JsonBase):
    """NOTE: (swapnil) OBSOLETE, ONLY FOR BACKWARDS COMPATIBILITY"""
    buffer_size: Optional[int] = None
    uid: Optional[str] = None
    firmware_version: Optional[str] = None
    num_channels: Optional[int] = None
    port: Optional[str] = None
    is_connected: bool = False

@dataclasses.dataclass
class NoArgs(JsonBase):
    pass

CommandArgs = Union[
    EnableContinuousConversionModeArgs,
    DisableContinuousConversionModeArgs,
    EnableBootModeArgs,
    CalibrateDeviceArgs, 
    PassThroughArgs, 
    ProgramBinPathArgs,
    StartLoggingArgs, 
    ConnectToDeviceArgs,
    PassThroughArgs, 
    SetDeviceModeArgs,
    NoArgs
]

@dataclasses.dataclass
class DetailedCommand(JsonBase):
    cmd: Command
    args: CommandArgs = NoArgs()



@dataclass
class Reply(JsonBase):
    """
    [deprecated]
    # NOTE (swapnil) - Replace all usages of this with Checked
    """
    result: Result
    message: str
    data: Optional[Any] = None



if __name__=="__main__":
    DetailedCommand(Command.CONNECT_TO_DEVICE, ConnectToDeviceArgs()).to_json()