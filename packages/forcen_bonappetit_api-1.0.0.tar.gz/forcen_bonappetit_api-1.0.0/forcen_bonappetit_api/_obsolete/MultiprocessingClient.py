"""
NOTE (swapnil) - This file is deprecated and should be removed once forcen_bonappetit is updated 
with a proper websocket based server/client implementation
"""

from typing import Optional
from queue import Empty
from pathlib import Path
import json
import time

from multiprocessing.managers import SyncManager

from typing import Optional, Dict, Any, List, cast

from forcen_bonappetit_api.models.simple_linear import SimpleLinear
from forcen_bonappetit_api.DeviceMessages import (
    DetailedCommand,
    Reply,
    ForceData,
    EnableContinuousConversionModeArgs,
    SetDeviceModeArgs,
    DisableContinuousConversionModeArgs,
    Result,
    ConnectToDeviceArgs,
    Command,
    CommandArgs,  # pyright: ignore[reportUnusedImport]
    PassThroughArgs,
    DeviceInfo,
)

_DEFAULT_PORT = 5656
_LOCAL_HOST = "127.0.0.1"


class MultiprocessingServerManager(SyncManager):
    pass


MultiprocessingServerManager.register("get_pipe")
MultiprocessingServerManager.register("get_queue")


class MultiprocessingClient:
    def __init__(
        self,
        address: Optional[str] = None,
        port: Optional[int] = None,
    ):
        self._port = _DEFAULT_PORT if port is None else port
        self._addr = _LOCAL_HOST if address is None else address

        self._manager = MultiprocessingServerManager(
            address=(self._addr, self._port), authkey=b"forcen"
        )
        self._manager.connect()

        self._pipe = self._manager.get_pipe()  # type: ignore
        self._pipe.claim()

        self._queue = self._manager.get_queue()  # type: ignore
        self._queue.setFlag()

        self._config = None
        self._model = None

        self.passthrough(PassThroughArgs(msg="<SMD3>"))

    def __enter__(self):
        return self

    def __exit__(self, exception_type, exception_value, exception_traceback):
        self.shutdown()

    def _send_and_recv(self, detailed_cmd: DetailedCommand, timeout: float = 5):
        self._pipe.send(detailed_cmd.to_json())
        return self._recv_with_timeout(timeout)

    def _recv_with_timeout(self, timeout: float = 5) -> Reply:
        try:
            if not self._pipe.poll(timeout):
                return Reply(Result.FAILURE, f"Server didn't respond within {timeout} seconds")
            reply = self._pipe.recv()
            reply = Reply.from_json(reply)
            reply.result = Result(reply.result)
            return reply
        except (EOFError, BrokenPipeError) as e:
            print(f"Got end of file error: {e}")
            print(f"The server was likely shutdown")
            return Reply(
                result=Result.FAILURE,
                message=f"Got connection error, server was likely shutdown or crashed",
            )
        except Exception as e:
            print(f"unknown exception: {e}")
            return Reply(result=Result.FAILURE, message=f"Got unexcepted exception, {e}")

    def shutdown(self):
        # Must notify server side that we're exiting
        self._pipe.release()
        self._queue.releaseFlag()

    def get_raw_data(self) -> Reply:
        f = []
        try:
            ret = self._queue.getAll()
            if isinstance(ret, tuple):
                return Reply(result=Result.FAILURE, message=f"{ret[1]}")
            list_of_force_data = ret
            for force_data in list_of_force_data:
                f.append(ForceData.from_json(force_data))
            return Reply(result=Result.SUCCESS, message="", data=f)
        except Empty as e:
            return Reply(result=Result.SUCCESS, message="", data=f)
        except (EOFError, BrokenPipeError) as e:
            print(f"Got end of file error: {e}")
            print(f"The server was likely shutdown")
            return Reply(
                result=Result.FAILURE,
                message=f"Got connection error, server was likely shutdown or crashed",
            )
        except Exception as e:
            print(f"unknown exception: {e}")
            return Reply(result=Result.FAILURE, message=f"Got unexcepted exception, {e}")

    def set_process_func(self, config_file) -> Reply:
        self._config = config_file
        self._model = SimpleLinear(self._config["processing_model"]["model_data"])

        return Reply(Result.SUCCESS, "")

    def get_processed_data(self, timeout: float = 1.0) -> Reply:
        timeout_time = time.time() + timeout
        if self._model is None:
            return Reply(
                Result.FAILURE, f"set_process_func was never called, no model to process with"
            )

        while True:
            while True:
                reply = self.get_raw_data()
                if reply.result != Result.SUCCESS:
                    return reply
                force_data_list = cast(List[ForceData], reply.data)
                if len(force_data_list) != 0:
                    break

                if time.time() > timeout_time:
                    return Reply(Result.FAILURE, f"Timed out waiting for raw data")
                time.sleep(0.001)

            ret = self._model.process(force_data_list[-1])
            if ret is not None:
                return Reply(Result.SUCCESS, "", data=ret)

            if time.time() > timeout_time:
                return Reply(Result.FAILURE, f"Timed out waiting for processed data")
            time.sleep(0.001)

    def enable_continuous_conversion_mode(self, args: EnableContinuousConversionModeArgs) -> Reply:
        return self._send_and_recv(DetailedCommand(Command.ENABLE_CONTINUOUS_CONVERSION_MODE, args))

    def disable_continuous_conversion_mode(
        self, args: DisableContinuousConversionModeArgs
    ) -> Reply:
        return self._send_and_recv(
            DetailedCommand(Command.DISABLE_CONTINUOUS_CONVERSION_MODE, args)
        )

    def connect_to_device(self, args: ConnectToDeviceArgs) -> Reply:
        return self._send_and_recv(DetailedCommand(Command.CONNECT_TO_DEVICE, args), 60)

    def disconnect_from_device(self) -> Reply:
        return self._send_and_recv(DetailedCommand(Command.DISCONNECT_FROM_DEVICE))

    def passthrough(self, args: PassThroughArgs) -> Reply:
        return self._send_and_recv(DetailedCommand(Command.PASSTHROUGH, args))

    def set_device_mode(self, args: SetDeviceModeArgs) -> Reply:
        return self._send_and_recv(DetailedCommand(Command.SET_DEVICE_MODE, args))

    def clear_device_buffer(self) -> Reply:
        return self._send_and_recv(DetailedCommand(Command.CLEAR_DEVICE_BUFFER))

    def get_device_info(self) -> Reply:
        reply = self._send_and_recv(DetailedCommand(Command.GET_DEVICE_INFO))
        if reply.result == Result.SUCCESS:
            print(reply.data)
            reply.data = DeviceInfo.from_dict(cast(Dict[str, Any], reply.data))
        return reply

    def detect_device_info(self) -> Reply:
        return self._send_and_recv(DetailedCommand(Command.DETECT_DEVICE_INFO))

    def calibrate_device(self) -> Reply:
        return self._send_and_recv(DetailedCommand(Command.CALIBRATE_DEVICE))


if __name__ == "__main__":
    # Match the address and port with the server
    import sys
    import time

    port = None if len(sys.argv) < 2 else int(sys.argv[1])
    addr = None if len(sys.argv) < 3 else str(sys.argv[2])

    # Always instantiate Client in with block (or ensure that `.shutdown()` will be called)
    with MultiprocessingClient(addr, port) as cli:
        # avoid using this and connect thru Bonnechere instead
        # in the future, we'll allow this to run headless
        # print(cli.connect_to_device(args=ConnectToDeviceArgs(port='/dev/ttyACM0')))

        # get device info to make sure you're taking to the same one you see in Bonnechere
        print(cli.get_device_info())

        # if you haven't done this in Bonnechere, you need to enable continuous readings
        # to start getting data
        print(
            cli.enable_continuous_conversion_mode(
                args=EnableContinuousConversionModeArgs(force=False)
            )
        )

        try:
            while True:
                reply: Reply = cli.get_raw_data()
                if reply.result == Result.SUCCESS:
                    list_of_force_data = cast(List[ForceData], reply.data)
                    for force_data_obj in list_of_force_data:
                        # currently, processed field will return garbage
                        print(
                            f"time: {force_data_obj.timestamp}, raw: {force_data_obj.raw}, processed: {force_data_obj.processed}"
                        )

                # if you poll faster than data is produced, you'll still get a `Reply` object
                # reply.result should still be Result.SUCCESS
                # Inside, the `.data` field will still be `ForceDataList`
                # `reply.data.data` (ie type List[ForceData]) will just be an empty list
                time.sleep(0.1)

        except KeyboardInterrupt:
            # if not using Bonnechere, you can turn off continuous readings
            print(
                cli.disable_continuous_conversion_mode(
                    args=DisableContinuousConversionModeArgs(force=False)
                )
            )

        # avoid disconnecting thru this API, disconnect thru Bonnechere instead
        # in the future, we'll allow this to run headless
        # print(cli.disconnect_from_device())
