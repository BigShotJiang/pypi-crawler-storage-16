"""
NOTE (swapnil) - This is legacy code from forcen_demo
For now, its required for former forcen_demo stuff to work. This is deprecated and should be 
removed after multiprocessing is removed from forcen_bonappetit and websocket is properly 
implemented 
"""

import time
from typing import Dict

from forcen_math.exp_filter import ExpFilter
from forcen_bonappetit_api.DeviceMessages import ForceData, ForceDataNamed, ForceValueNamed


class SimpleLinear:
    def __init__(self, config):
        model_data = config
        self.channels = model_data["channels"]
        self.slopes: Dict[str, float] = model_data[
            "slope"
        ]  # {name: v for name, v in model_data['slope'].items()}
        self.filter_freq = model_data["filter_freq"]
        self.offset_filters = {name: ExpFilter(name, 5, 10000) for name in self.channels}
        self.values = {name: ExpFilter(name, 10, 0.0) for name in self.channels}
        self.filtered_values = {
            name: ExpFilter(name, self.filter_freq[name], 0.0) for name in self.channels
        }
        self.process = self.setup_process
        self.start_time = time.time()
        self._use_processed_channel = config["use_processed_channel"] if "use_processed_channel" in config else False

    def setup_process(self, data: ForceData) -> None:
        for name in self.channels:
            if self._use_processed_channel:
                assert data.processed is not None
                self.offset_filters[name].update(data.processed[int(self.channels[name])])
            else:
                self.offset_filters[name].update(data.raw[int(self.channels[name])])
        self.offsets = {name: v.value() for name, v in self.offset_filters.items()}

        if time.time() > self.start_time + 10:
            self.process = self.regular_process
        return None

    def _to_newtons(self, data: ForceData, name: str) -> float:
        if self._use_processed_channel:
            assert data.processed is not None
            return (
                self.slopes[name]
                * (data.processed[int(self.channels[name])] - self.offsets[name])
                / 1000.0
            )

        return (
            self.slopes[name]
            * (data.raw[int(self.channels[name])] - self.offsets[name])
            / 1000.0
        )
        # return self.slopes[name] * (data.raw[int(self.channels[name])] - self.offsets[name])

    def _update_value(self, data: ForceData, name: str) -> float:
        return self.values[name].update(self._to_newtons(data, name))

    def _update_filtered_value(self, data: ForceData, name: str) -> float:
        return self.filtered_values[name].update(self._to_newtons(data, name))

    def regular_process(self, data: ForceData) -> ForceDataNamed:
        row = [
            ForceValueNamed(name, self._update_value(data, name)) for name in self.channels.keys()
        ]
        # filtered_row = [ForceValueNamed(name + "_filtered", self._update_filtered_value(data, name)) for name in self.channels.keys()]
        # filtered_row = []
        # row = row + filtered_row
        return ForceDataNamed(data.timestamp, row)
