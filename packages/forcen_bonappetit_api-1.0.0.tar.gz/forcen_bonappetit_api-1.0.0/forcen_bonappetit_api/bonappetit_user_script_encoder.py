import base64
from Crypto.Cipher import AES
from Crypto.Hash import HMAC, SHA256
from Crypto.Protocol.KDF import PBKDF2
from Crypto import Random
import dataclasses
import dataclasses_json
import json
from typing import Optional


import forcen_public_utils.checked as ch
from forcen_bonappetit_api.common.error_types import BonAppetitChecked, BonAppetitCode
from forcen_bonappetit_api.bonappetit_user_script_interface import (
    BonappetitUserScriptJsonWithMetadata,
)

# Encryption related constants
ITERATIONS = 1000
CYPHER_TXT_KEY = "VV"
SALT_KEY = "WW"
IV_KEY = "W"
H_MAC_KEY = "V"

# Configuration directory related constants
CFG_FILE_EXTENSION = ".settings"
CFG_LEVEL_DEPTH = 5
CFG_LEVEL = ["__level_{}".format(i) for i in range(CFG_LEVEL_DEPTH)]

# Max/Max readable ascii characters
MAX_ASCII = 126
MIN_ASCII = 32


@dataclasses.dataclass
class BonappetitUserScriptEncoderResultNoPassword(dataclasses_json.DataClassJsonMixin):
    name: str
    level: str
    cypher_text: str
    salt: str
    iv: str
    h_mac: str


@dataclasses.dataclass
class BonappetitUserScriptEncoderResult(dataclasses_json.DataClassJsonMixin):
    name: str
    password: str
    level: str
    cypher_text: str
    salt: str
    iv: str
    h_mac: str

    def without_password(self) -> BonappetitUserScriptEncoderResultNoPassword:
        return BonappetitUserScriptEncoderResultNoPassword(
            name=self.name,
            level=self.level,
            cypher_text=self.cypher_text,
            salt=self.salt,
            iv=self.iv,
            h_mac=self.h_mac,
        )


@dataclasses.dataclass
class _CypherResult:
    cypher: bytes
    iv: bytes


@dataclasses.dataclass
class _MakeKeysResult:
    aes_key: bytes
    hmac_key: bytes
    salt: bytes
    iterations: int


def _modify_password(name: str, password: str, level: str) -> str:
    ogp = str(password)
    # Find the updated password
    up = ""
    for i, c in enumerate(ogp):
        append = ord(c) + i + 1
        if append > MAX_ASCII:
            append = MAX_ASCII
        elif append < MIN_ASCII:
            append = MIN_ASCII
        up += "{}{}".format(c, chr(append))

    return f"{up}|{name}|{level}"


def _make_keys(password: str, salt: Optional[bytes] = None) -> _MakeKeysResult:
    """Generates two 128-bit keys from the given password using PBKDF2-SHA256"""
    if salt is None:
        # Generate a random 16-byte salt
        salt = Random.new().read(16)

    key = PBKDF2(
        password=password,
        salt=salt,
        dkLen=32,
        count=ITERATIONS,
        hmac_hash_module=SHA256,
    )
    # Split the key into two 16-byte (128-bit) keys
    return _MakeKeysResult(aes_key=key[:16], hmac_key=key[16:], salt=salt, iterations=ITERATIONS)


# Function Name: makeHMAC
# Arguments: message (The message to create an hMAC of), key (The key to use for the hMAC at least 16 bytes)
# Returns: A hex string of the hMAC
# Description: Creates an hMAC from the given message, using the given key. Uses hMAC-MD5.
def _make_hmac(message_to_hash: bytes, key: bytes):
    """Creates an hMAC from the given message, using the given key. Uses hMAC-MD5."""
    h = HMAC.new(key)
    h.update(message_to_hash)
    return h.hexdigest()


def _make_cypher(message_to_encrypt: bytes, key: bytes) -> _CypherResult:
    """Encrypts a given message with the given key, using AES-CFB"""
    # Generate a random IV
    iv: bytes = Random.new().read(AES.block_size)
    # Generate a cipher object using the key and IV
    cipher = AES.new(key, AES.MODE_CFB, iv)
    # Encrypt the provided message using the cipher
    cipherText: bytes = cipher.encrypt(message_to_encrypt)
    # Return the encrypted message with the random IV
    return _CypherResult(cypher=cipherText, iv=iv)


def _decrypt_cypher(cypher_text: bytes, aes_key: bytes, iv: bytes):
    # Generate a cipher object using the key and IV
    cipher = AES.new(aes_key, AES.MODE_CFB, iv)
    # Attempt to decrypt the cipher text with the cipher
    msg = cipher.decrypt(cypher_text)
    return msg


def encrypt_bonappetit_user_script(
    name: str,
    password: str,
    level: str,
    script_with_metadata: BonappetitUserScriptJsonWithMetadata,
) -> BonAppetitChecked[BonappetitUserScriptEncoderResult]:
    try:
        serialized_output = script_with_metadata.to_json().encode("utf-8")
    except UnicodeEncodeError:
        return ch.bad(
            BonAppetitCode.USER_ERROR,
            message=f"Failed to encode dictionary to json, there may be invalid characters in the script",
        )

    # Generate keys using the password
    modified_password = _modify_password(name=name, password=password, level=level)
    keys_result = _make_keys(modified_password)
    cypher_result = _make_cypher(serialized_output, keys_result.aes_key)
    hmac = _make_hmac(cypher_result.cypher, keys_result.hmac_key)

    return ch.ok(
        BonappetitUserScriptEncoderResult(
            name=name,
            password=password,
            level=level,
            cypher_text=base64.b64encode(cypher_result.cypher).decode("utf-8"),
            iv=base64.b64encode(cypher_result.iv).decode("utf-8"),
            salt=base64.b64encode(keys_result.salt).decode("utf-8"),
            h_mac=hmac,
        )
    )


def decrypt_bonappetit_user_script(
    encoded_script: BonappetitUserScriptEncoderResult,
) -> BonAppetitChecked[BonappetitUserScriptJsonWithMetadata]:
    cypher_text = base64.b64decode(encoded_script.cypher_text)
    iv = base64.b64decode(encoded_script.iv)
    salt = base64.b64decode(encoded_script.salt)
    hMac_e = encoded_script.h_mac

    # Get the AES key and hMac key from the file data using the password
    modified_password = _modify_password(
        name=encoded_script.name, password=encoded_script.password, level=encoded_script.level
    )
    keys_result = _make_keys(modified_password, salt)
    hMac = _make_hmac(cypher_text, keys_result.hmac_key)

    # Compare the hash macs
    if hMac != hMac_e:
        return ch.bad(
            BonAppetitCode.USER_ERROR,
            message="Match Error - Password may be wrong or data is altered",
        )

    # Decrypt the data using the calculated keys
    serialized_json = _decrypt_cypher(cypher_text, keys_result.aes_key, iv)

    # Decode the data into a python dictionary
    try:
        return ch.ok(BonappetitUserScriptJsonWithMetadata.from_json(serialized_json))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        return ch.bad(
            BonAppetitCode.USER_ERROR,
            message=f"Failed to parse encrypted data into json. Data may be corrupted. Got\n\n{e}",
        )
