import dataclasses
import dataclasses_json
import enum
from typing import List, Dict, Any, Union
import datetime

from forcen_public_utils.version import Version
from forcen_public_utils.json_dataclasses_enum import patch_json_dataclass_enum_encoder


@patch_json_dataclass_enum_encoder
class BonappetitUserScriptConstantValueType(enum.Enum):
    BOOL = enum.auto()
    INT = enum.auto()
    FLOAT = enum.auto()
    STR = enum.auto()


@dataclasses.dataclass
class BonappetitUserScriptConstant(dataclasses_json.DataClassJsonMixin):
    name: str
    value: Union[str, int, float, bool]
    units: str
    value_type: BonappetitUserScriptConstantValueType


@dataclasses.dataclass
class BonappetitUserScriptJsonWithMetadata(dataclasses_json.DataClassJsonMixin):
    name: str
    created_on: datetime.datetime
    created_by: str
    last_edit_on: datetime.datetime
    last_edit_by: str
    base: Dict[str, Any]
    version: Version
    description: str
    libraries: List[str]
    constants: List[BonappetitUserScriptConstant]
    script_raw: List[str]


class BonappetitUserScriptCalibrationState(enum.Enum):
    DONE = enum.auto()
    RUNNING = enum.auto()
    CHECKPOINT = enum.auto()
    WARNING = enum.auto()
    ERROR = enum.auto()


@dataclasses.dataclass
class BonappetitUserScriptCalibrateResponse:
    state: BonappetitUserScriptCalibrationState
    message: str
    user_input_required: bool


# NOTE (swapnil): It'd be nice to have something like this interface in the future. It'd make it
# easier to enforce the interface on the client side and allow a more plugin-like architecture
# It requires:
# - being able to import things with importlib
# - overwrite the same module as its updated
# - not consume more and more ram as the same module is imported again and again
# For now, we're skipping this to avoid changing too many interfaces at once

# class BonappetitUserScriptInterface(Protocol):
#     def clean(self): ...

#     def calibrate(
#         self,
#         device_data: Dict[str, Any],
#         checkpoint_user_input: Optional[Dict[str, Any]],
#     ) -> BonappetitUserScriptCalibrateResponse: ...

#     def step(
#         self,
#         sensor_data: List[int],
#         calibration_data: Dict[str, Any],
#     ) -> List[int]: ...


# def create_bonappetit_script_interface(
#     user_script_data: BonappetitUserScriptJsonWithMetadata,
# ) -> Optional[BonappetitUserScriptInterface]:
#     import tempfile
#     file = tempfile.NamedTemporaryFile("w")
#     file.writelines(user_script_data.script_raw)

#     import importlib.util
#     mod_spec = importlib.util.spec_from_file_location("user_script_module", file.name)
#     assert mod_spec is not None
#     module = importlib.util.module_from_spec(mod_spec)

#     assert mod_spec.loader is not None
#     mod_spec.loader.exec_module(module)
