"""The main websocket client for connecting to a Forcen device through a bonappetit websocket server."""

import dataclasses
import threading
import time
from typing import Callable, List, Optional, Set, Tuple, Dict, Any

import websockets.sync.client as ws_cli

from forcen_bonappetit_api.bonappetit_user_script_encoder import (
    BonappetitUserScriptEncoderResultNoPassword,
)
import forcen_bonappetit_api.protocol.protocol_data_types as pdt
import forcen_public_utils.checked as ch
from forcen_bonappetit_api.bonappetit_websocket_client_rtd_sensor_data_loop import (
    BonappetitWebsocketClientRTDSensorDataLoop,
)

# from forcen_bonappetit_api.bonappetit_websocket_client_sensor_data_loop import (
#     BonappetitWebsocketClientSensorDataLoop,
# )

from forcen_bonappetit_api.bonappetit_websocket_client_loop import BonappetitWebsocketClientLoop
from forcen_bonappetit_api.bonappetit_websocket_helpers import (
    send_and_recv_data,
    send_and_recv_empty_data,
)
from forcen_bonappetit_api.bonappetit_websocket_server_messages import (
    ADCDigipotValue,
    AddUdpSensorDataConnCommandArgs,
    AddUdpSensorDataConnResponseData,
    CalibConstantValue,
    GetADCCalibrationConstantCommandArgs,
    GetADCCalibrationConstantResponseData,
    GetADCDigipotCommandArgs,
    GetADCDigipotResponseData,
    GetADCDownsampleFactorResponseData,
    GetADCEnabledChannelsResponseData,
    GetADCGainResponseData,
    GetADCOversamplingRatioResponseData,
    GetADCSensorOutputModelResponseData,
    GetCANBaudRateReponseData,
    GetCANNodeIDResponseData,
    GetDataRateResponseData,
    GetEEPROMWriteCountResponseData,
    GetFirmwareVersionResponseData,
    GetGatewayResponseData,
    GetHardwareErrorResponseData,
    GetImuDataStyleResponseData,
    GetIPAddressResponseData,
    GetIsTemperatureCompensationEnabledResponseData,
    GetLedDataResponseData,
    GetMacAddressResponseData,
    GetModeResponseData,
    GetNetmaskResponseData,
    GetPeripheralTypeResponseData,
    GetRuntimeDeviceErrorCommandArgs,
    GetRuntimeDeviceErrorResponseData,
    GetSelectedOutputDataStreamResponseData,
    GetSerialNumberResponseData,
    GetTareStatusResponseData,
    GetTemperatureResponseData,
    GetTransportConnInfoResponseData,
    GetUartBaudRateResponseData,
    GetUartParityResponseData,
    GetUartStopbitsResponseData,
    GetUSBOnBootDelayResponseData,
    GetUserConstantCommandArgs,
    GetUserConstantResponseData,
    GetWSServerVersionResponseData,
    SendRawPacketUncheckedUnsafeCommandArgs,
    SendRawPacketUncheckedUnsafeResponseData,
    SetAccessLockCommandArgs,
    SetADCCalibConstantCommandArgs,
    SetADCDigipotCommandArgs,
    SetADCDownsampleFactorCommandArgs,
    SetADCEnabledChannelsCommandArgs,
    SetADCGainCommandArgs,
    SetADCSensorOutputModelCommandArgs,
    SetCANBaudRateCommandArgs,
    SetCANNodeIDCommandArgs,
    SetDataRateCommandArgs,
    SetGatewayCommandArgs,
    SetImuDataStyleCommandArgs,
    SetIPAddressCommandArgs,
    SetIsTemperatureCompensationEnabledCommandArgs,
    SetLedBrightnessCommandArgs,
    SetMacAddressCommandArgs,
    SetModeCommandArgs,
    SetNetmaskCommandArgs,
    SetPeripheralTypeCommandArgs,
    SetSelectedOutputDataStreamCommandArgs,
    SetUartBaudRateCommandArgs,
    SetUartParityCommandArgs,
    SetUartStopbitsCommandArgs,
    SetUSBOnBootDelayCommandArgs,
    SetUserConstantCommandArgs,
    SetUserScriptUncheckedUnsafeCommandArgs,
    UserConstantValue,
    WSServerCommand,
    WSServerError,
    SensorDataList,
    ReplyData,
)
from forcen_bonappetit_api.common.error_types import (
    BonAppetitCode,  # pyright: ignore[reportUnusedImport]
)
from forcen_bonappetit_api.common.error_types import BonAppetitChecked
from forcen_bonappetit_api.driver.protocol_driver_interface import (
    MixedCallbackT,
    MixedQueueT,
    ProtocolDriverInterface,
    ReplyCallbackT,
    ReplyQueueT,
    RTDCallbackT,
    RTDQueueT,
    RTDPacketStamped,
    ErrorQueueT,
    ErrorCallbackT,
)
from forcen_bonappetit_api.protocol.protocol_transport_types import (
    PacketStamped,
    ReplyPacketStamped,
)
from forcen_bonappetit_api.transport.transport_types import (
    SendTransportPacket,
    TransportConnectionInfo,
)
from forcen_bonappetit_api.bonappetit_websocket_helpers import make_client
from forcen_public_utils.atomic import NullableAtomic
from forcen_public_utils.ip_address import IPv4, MacAddr48
from forcen_public_utils.loggers.console_logger import ConsoleLogger
from forcen_public_utils.math_types import UInt8, UInt32
from forcen_public_utils.rate import Rate
from forcen_public_utils.websocket_uri import make_websocket_uri
from forcen_public_utils.sync_queue import SyncQueueStopped


@dataclasses.dataclass
class BufferAndPackets:
    buffer: bytearray
    packet: Optional[bytes] = None


class BonAppetitClient(ProtocolDriverInterface):
    """A driver object implementing the `forcen_bonappetit_api.driver.protocol_driver_interface.ProtocolDriverInterface`,
    which communicates with a Forcen device via a `forcen_bonappetit.server.bonappetit_websocket_server.BonAppetitServer`
    using the Websocket protocol.

    This client connects to a server and sends / receives control messages via Websocket.
    It can also create a UDP channel to receive realtime or batched sensor data pushed from the server.

    Usage:
    ```python
    with BonAppetitClient(server_ip_address, server_port, server_publisher_port) as client:
        # Route commands through the server by calling them from here, e.g.:
        firmware_version = client.get_firmware_verison().value()
        # etc ...
    ```
    """

    def __init__(
        self,
        server_ip_address: str,
        server_command_port: int,
        server_data_pub_port: int,
        server_error_pub_port: int,
        server_replies_pub_port: int,
        default_timeout: float = 10,
    ):
        self._default_timeout = default_timeout
        self._rtd_callbacks: List[RTDCallbackT] = []
        self._sensor_callbacks: List[RTDCallbackT] = []
        self._reply_callbacks: List[ReplyCallbackT] = []
        self._everything_callbacks: List[MixedCallbackT] = []
        self._error_callbacks: List[ErrorCallbackT] = []

        self._subscription_lock = threading.Lock()

        self.server_ip_address = server_ip_address
        self.server_command_port = server_command_port
        self.server_data_pub_port = server_data_pub_port
        self.server_error_sub_port = server_error_pub_port
        self.server_replies_pub_port = server_replies_pub_port

        self._client = make_client(
            ip_address=server_ip_address,
            port=server_command_port,
            timeout=default_timeout,
            name="bonappetit command server",
        )

        ws_server_version = send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_WS_SERVER_VERSION,
            response_type=GetWSServerVersionResponseData,
            parse_func=lambda data: pdt.ForcenWSServerVersion.from_str(data.version).value(),
        )

        if ws_server_version.has_error():
            raise RuntimeError(
                f"Failed to parse websocket server version after connecting to server. {ws_server_version}"
            )

        self._ws_server_version = ws_server_version.value()

        def _dispatch_error_callbacks_wrapper(raw_error: Dict[str, Any]):
            ws_server_error = WSServerError.from_dict(raw_error)
            self._dispatch_error_callbacks(ch.FullError(
                ws_server_error.code, ws_server_error.msg
            ))

        self._error_sub = BonappetitWebsocketClientLoop(
            server_name="bonappetit error subscriber",
            ip_address=server_ip_address,
            port=server_error_pub_port,
            default_timeout=default_timeout,
            error_callback=self._dispatch_error_callbacks,
            data_callback=_dispatch_error_callbacks_wrapper,
        )

        self._replies_sub = BonappetitWebsocketClientLoop(
            server_name="bonappetit replies subscriber",
            ip_address=server_ip_address,
            port=server_replies_pub_port,
            default_timeout=default_timeout,
            error_callback=self._dispatch_error_callbacks,
            data_callback=self._dispatch_replies_callbacks,
        )

        # TODO (swapnil): we shouldn't connect to the publisher right away and instead only connect
        # when the first subscribe or attach callback function is called for sensor data
        self._sensor_data_sub: Optional[BonappetitWebsocketClientLoop] = None

        # NOTE (swapnil) - we may want to only initiate a socket if we plan to have a realtime
        # connection. This class will be simpler if we always instantiate, but it may be a waste of
        # resources and spawns an extra thread for no reason if its not used
        self._udp_server_socket_addr = NullableAtomic[Tuple[str, int]](None)
        self._udp_listener_thread = self._start_udp_subscriber()

    def __enter__(self):
        return self

    def __exit__(self, exception_type, exception_value, exception_traceback):
        self.stop()

    def stop(self) -> None:
        """Close all UDP subscriptions to sensor data and disconnect from the server."""
        if self._sensor_data_sub is not None:
            ConsoleLogger.get().info("BonAppetitClient - closing the subscriber")
            self._sensor_data_sub.stop()

        self._error_sub.stop()
        self._replies_sub.stop()

        ConsoleLogger.get().info("BonAppetitClient - closing the server client")
        self._client.close()

        ConsoleLogger.get().info("BonAppetitClient - ending the udp listener thread")
        self._udp_listener_thread.stop()

    def _dispatch_error_callbacks(self, err: ch.FullError[BonAppetitCode]):
        with self._subscription_lock:
            cb_to_remove = []
            for cb in self._error_callbacks:
                try:
                    cb(err)
                except SyncQueueStopped:
                    ConsoleLogger.get().debug("SyncQueueStopped is raised in client error callback")
                    cb_to_remove.append(cb)

            for cb in cb_to_remove:
                self._error_callbacks.remove(cb)

    def _dispatch_replies_callbacks(self, reply_data: Dict[str, Any]):
        reply = ReplyData.from_dict(reply_data).reply
        with self._subscription_lock:
            cb_to_remove = []
            for cb in self._reply_callbacks:
                try:
                    cb(reply)
                except SyncQueueStopped:
                    cb_to_remove.append(cb)
            for cb in cb_to_remove:
                self._reply_callbacks.remove(cb)

    def _start_udp_subscriber(self) -> BonappetitWebsocketClientRTDSensorDataLoop:
        def _rtd_cb(packet: List[RTDPacketStamped]):
            with self._subscription_lock:
                cb_to_remove = []
                for cb in self._rtd_callbacks:
                    try:
                        cb(packet)
                    except SyncQueueStopped:
                        ConsoleLogger.get().debug("SyncQueueStopped Is Raised")
                        cb_to_remove.append(cb)

                for cb in cb_to_remove:
                    self._rtd_callbacks.remove(cb)


        return BonappetitWebsocketClientRTDSensorDataLoop(
            peer_address=self._udp_server_socket_addr,
            error_callback=self._dispatch_error_callbacks,
            rtd_packet_callback=_rtd_cb,
        )

    def _start_websocket_subscriber(self) -> BonAppetitChecked[None]:
        if self._sensor_data_sub is not None:
            return ch.ok()

        def _rtd_cb(err: Dict[str, Any]):
            sensor_data = SensorDataList.from_dict(err)
            with self._subscription_lock:
                cb_to_remove = []
                for cb in self._sensor_callbacks:
                    try:
                        cb(
                            [
                                RTDPacketStamped(tuple(frame.data), frame.timestamp)
                                for frame in sensor_data.frames
                            ]
                        )
                    except SyncQueueStopped:
                        cb_to_remove.append(cb)

                for cb in cb_to_remove:
                    self._sensor_callbacks.remove(cb)

        try:
            self._sensor_data_sub = BonappetitWebsocketClientLoop(
                server_name="bonappetit_client_sensor_data_subscriber",
                default_timeout=self._default_timeout,
                ip_address=self.server_ip_address,
                port=self.server_data_pub_port,
                error_callback=self._dispatch_error_callbacks,
                data_callback=_rtd_cb,
            )
        except RuntimeError as e:
            return ch.bad(BonAppetitCode.SERVER_TIMEOUT, message=f"{e}")

        return ch.ok()

    def subscribe_to_sensor_packets(
        self, max_buffer_size: int, realtime_stream: bool = False
    ) -> BonAppetitChecked[RTDQueueT]:
        """Open a new websocket connection with the server to receive sensor packets, which will
        automatically fill up a RTDQueue.

        If the realtime flag is set to True, sensor packets will be pushed by the server as soon
        as they arrive; otherwise, that data will be batched and pushed to the RTDQueue in chunks.

        It is only recommended to use realtime streams when it is absolutely needed, as opening
        too many of these will reduce the throughput of sensor data across the network and
        will substantially increase the demand on the server.

        Args:
            max_buffer_size (int): how much data to store in the queue at once.
            realtime_stream (bool, optional): whether to receive data in realtime or not. Defaults to False.

        Returns:
            BonAppetitChecked[RTDQueueT]
        """
        q = RTDQueueT(max_buffer_size)

        def push_to_queue(packets: List[RTDPacketStamped]):
            for packet in packets:
                q.push(packet)

        res = self.attach_sensor_data_callback(push_to_queue, realtime_stream=realtime_stream)
        if res.has_error():
            return ch.fwd_err(res)
        return ch.ok(q)

    def subscribe_to_reply_packets(self, max_buffer_size: int) -> BonAppetitChecked[ReplyQueueT]:
        """Create a Queue which will fill up any time the server receives a non-sensor-data packet
        from the Forcen device to which it is connected.

        Args:
            max_buffer_size (int): the maximum number of packets to store in the queue.

        Returns:
            BonAppetitChecked[ReplyQueueT]
        """
        q = ReplyQueueT(max_buffer_size)

        def push_to_queue(reply_packets: List[ReplyPacketStamped]) -> None:
            for reply_packet in reply_packets:
                q.push(reply_packet)

        with self._subscription_lock:
            self._reply_callbacks.append(push_to_queue)
            return ch.ok(q)

    def subscribe_to_all_packets(self, max_buffer_size: int) -> BonAppetitChecked[MixedQueueT]:
        """Create a Queue which fills up any time the server receives a packet of any type.

        Args:
            max_buffer_size (int): the size of the queue.

        Returns:
            BonAppetitChecked[MixedQueueT]
        """
        q = MixedQueueT(max_buffer_size)

        def push_to_queue(packet: PacketStamped) -> None:
            q.push(packet)

        with self._subscription_lock:
            self._everything_callbacks.append(push_to_queue)
            return ch.ok(q)

    def subscribe_to_errors(self, max_buffer_size: int) -> BonAppetitChecked[ErrorQueueT]:
        """Create a Queue which will fill up any time the server receives a non-sensor-data packet
        from the Forcen device to which it is connected.

        Args:
            max_buffer_size (int): the maximum number of packets to store in the queue.

        Returns:
            BonAppetitChecked[ReplyQueueT]
        """
        q = ErrorQueueT(max_buffer_size)

        def push_to_queue(error: ch.FullError[BonAppetitCode]) -> None:
            q.push(error)

        with self._subscription_lock:
            self._error_callbacks.append(push_to_queue)
            return ch.ok(q)

    def attach_sensor_data_callback(
        self,
        callback: RTDCallbackT,
        realtime_stream: bool = False,
    ) -> BonAppetitChecked[None]:
        """Open a separate websocket connection with the server, which will execute a given
        callback function any time sensor data is received from the Forcen device to which
        the server is connected.

        If the realtime flag is set to True, sensor packets will be pushed to the callback as soon
        as the server sees them; otherwise, that data will be batched and pushed to the callback
        in chunks.

        It is only recommended to use realtime streams when it is absolutely needed, as opening
        too many of these will reduce the throughput of sensor data across the network and
        will substantially increase the demand on the server.

        Args:
            callback (RTDCallbackT): the function handle which runs whenever sensor data is received.
            realtime_stream (bool, optional): whether to run this in real time or not. Defaults to False.

        Returns:
            BonAppetitChecked[None]
        """
        if not realtime_stream:
            ws_res = self._start_websocket_subscriber()
            if ws_res.has_error():
                return ch.fwd_err(ws_res)

            with self._subscription_lock:
                self._sensor_callbacks.append(callback)
            return ch.ok()

        else:
            self_addr = self._udp_listener_thread.get_address()
            if self_addr is None:
                self._udp_listener_thread.stop()
                self._udp_listener_thread = self._start_udp_subscriber()
                self_addr = self._udp_listener_thread.get_address()
                if self_addr is None:
                    return ch.bad(
                        BonAppetitCode.SENSOR_DATA_SOCKET_FATAL,
                        message=f"Failed to start udp sensor data stream subscriber",
                    )

            with self._subscription_lock:
                if len(self._rtd_callbacks) == 0:
                    res = send_and_recv_data(
                        self._client,
                        command=WSServerCommand.ADD_UDP_SENSOR_DATA_CONN,
                        args=AddUdpSensorDataConnCommandArgs(self_addr[0], self_addr[1]),
                        response_type=AddUdpSensorDataConnResponseData,
                    )
                    if res.has_error():
                        return ch.fwd_err(res)

                    self._udp_server_socket_addr.set((res.value().ip_address, res.value().port))
                    ConsoleLogger.get().info(
                        f"udp socket for sensor data server address: {self._udp_server_socket_addr.get_copy()}"
                    )
                self._rtd_callbacks.append(callback)
            return ch.ok()

    def attach_reply_callback(self, callback: ReplyCallbackT) -> BonAppetitChecked[None]:
        """Run a callback any time the server receives a non-sensor-data packet
        from the Forcen device to which it is connected.

        Args:
            callback (ReplyCallbackT): the function handle which will be run when packets arrive.

        Returns:
            BonAppetitChecked[None]
        """
        with self._subscription_lock:
            self._reply_callbacks.append(callback)
        return ch.ok()

    def attach_callback_for_everything(self, callback: MixedCallbackT) -> BonAppetitChecked[None]:
        """Run a callback any time the server receives packets of any type from the Forcen device
        to which it is connected.

        Args:
            callback (MixedCallbackT): the function handle which will be run when packets arrive.

        Returns:
            BonAppetitChecked[None]
        """
        with self._subscription_lock:
            self._everything_callbacks.append(callback)
        return ch.ok()

    def attach_error_callback(
        self, callback: Callable[[ch.FullError[BonAppetitCode]], None]
    ) -> BonAppetitChecked[None]:
        """Run a callback any time the server receives a packet with an error.

        Args:
            callback (Callable[[BonAppetitChecked[None]], None]): the function handle to run,
                where the BonAppetitChecked[None] input contains some error code.

        Returns:
            BonAppetitChecked[None]
        """
        with self._subscription_lock:
            self._error_callbacks.append(callback)
        return ch.ok()

    def continue_calibration(self) -> BonAppetitChecked[None]:
        """Command the Forcen device to continue calibration.

        TODO: This is NOT implemented.
        """
        raise NotImplementedError()

    def calibration_set_num_samples(self, num_samples: UInt32) -> BonAppetitChecked[None]:
        """Change the number of calibration samples in the Forcen device.

        TODO: This is NOT implemented.
        """
        raise NotImplementedError()

    def get_calibration_num_samples(self) -> BonAppetitChecked[UInt32]:
        """Request the number of calibration samples currently used by the Forcen device.

        TODO: This is NOT implemented.
        """
        raise NotImplementedError()

    def get_ws_server_version(self) -> pdt.ForcenWSServerVersion:
        return self._ws_server_version

    def get_firmware_version(self) -> BonAppetitChecked[pdt.ForcenProtocolVersion]:
        """Request the Forcen device's firmware version

        Returns:
            BonAppetitChecked[pdt.ForcenProtocolVersion]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_FIMRWARE_VERSION,
            response_type=GetFirmwareVersionResponseData,
            parse_func=lambda data: pdt.ForcenProtocolVersion.from_str(
                data.firmware_version
            ).value(),
        )

    def get_serial_number(self) -> BonAppetitChecked[str]:
        """Request the Forcen device's serial number.

        Returns:
            BonAppetitChecked[str]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_SERIAL_NUMBER,
            response_type=GetSerialNumberResponseData,
            parse_func=lambda data: data.serial_number,
        )

    def get_eeprom_write_count(self) -> BonAppetitChecked[int]:
        """Get the number of times configurations have been saved to the Forcen device's EEPROM.

        Returns:
            BonAppetitChecked[int]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_EEPROM_WRITE_COUNT,
            response_type=GetEEPROMWriteCountResponseData,
            parse_func=lambda data: data.eeprom_write_count,
        )

    def get_transport_connection_info(self) -> BonAppetitChecked[TransportConnectionInfo]:
        """Request information about the Forcen device's connection type, such as whether it's a Serial link,
        TCP, UDP, etc., along with additional information like the ip address or port on which the
        device is connected.

        Returns:
            BonAppetitChecked[TransportConnectionInfo]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_TRANSPORT_CONNECTION_INFO,
            response_type=GetTransportConnInfoResponseData,
            parse_func=lambda data: TransportConnectionInfo(data.transport_type, data.conn_info),
        )

    def get_temperature(self) -> BonAppetitChecked[float]:
        """Request the value of the Forcen device's thermometer, if it has one.

        Returns:
            BonAppetitChecked[float]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_TEMPERATURE,
            response_type=GetTemperatureResponseData,
            parse_func=lambda data: data.temperature,
        )

    def get_adc_oversampling_ratio(self) -> BonAppetitChecked[pdt.ADCOverSamplingRatio]:
        """Request the Forcen device's ADC Oversampling Ratio register, if it has one.

        Returns:
            BonAppetitChecked[pdt.ADCOverSamplingRatio]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_ADC_OVERSAMPLE_RATIO,
            response_type=GetADCOversamplingRatioResponseData,
            parse_func=lambda data: data.adc_oversampling_ratio,
        )

    def get_adc_gain(self) -> BonAppetitChecked[pdt.ADCGain]:
        """Request the gain used by the Forcen device's analogue to digital converter.

        Returns:
            BonAppetitChecked[pdt.ADCGain]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_ADC_GAIN,
            response_type=GetADCGainResponseData,
            parse_func=lambda data: data.adc_gain,
        )

    def set_adc_gain(self, adc_gain: pdt.ADCGain) -> BonAppetitChecked[None]:
        """Change the gain used by the Forcen device's analogue to digital converter.

        Args:
            adc_gain (pdt.ADCGain): the new gain.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.SET_ADC_GAIN,
            args=SetADCGainCommandArgs(adc_gain),
        )

    def get_enabled_adc_channels(self) -> BonAppetitChecked[Set[pdt.ADCChannel]]:
        """Get a list of currently running ADC channels on the Forcen device, if the firmware
        version supports that.

        Returns:
            BonAppetitChecked[Set[pdt.ADCChannel]]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_ADC_ENABLED_CHANNELS,
            response_type=GetADCEnabledChannelsResponseData,
            parse_func=lambda data: set(data.adc_enabled_channels),
        )

    def set_enabled_adc_channels(
        self, adc_channels: Set[pdt.ADCChannel]
    ) -> BonAppetitChecked[None]:
        """Change the enabled ADC channels, if the Forcen device's firmware version supports that.

        Args:
            adc_channels (Set[pdt.ADCChannel]): the channels to enable. All other channels will be disabled.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.SET_ADC_ENABLED_CHANNELS,
            args=SetADCEnabledChannelsCommandArgs(list(adc_channels)),
        )

    def get_adc_digipot(self, channel: int) -> BonAppetitChecked[UInt8]:
        """Request the value of the digipot in the Forcen device's ADC.

        Args:
            channel (int): the channel id on which to retrieve the digipot value.

        Returns:
            BonAppetitChecked[UInt8]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_ADC_DIGIPOT,
            args=GetADCDigipotCommandArgs(channel),
            response_type=GetADCDigipotResponseData,
            parse_func=lambda data: UInt8(int(data.adc_digipot.value)),
        )

    def set_adc_digipot(self, channel: int, value: UInt8) -> BonAppetitChecked[None]:
        """Change the value of a digipot on the Forcen device, if that functionality is supported.

        Args:
            channel (int): the adc channel on which to change the digipot.
            value (UInt8): the new value of the digipot.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.SET_ADC_DIGIPOT,
            args=SetADCDigipotCommandArgs(ADCDigipotValue(index=channel, value=value.v)),
        )

    def get_adc_calibration_constant(
        self, constant: pdt.CalibrationConstant
    ) -> BonAppetitChecked[float]:
        """Request the value of a calibration constant register on the Forcen device.

        Args:
            constant (pdt.CalibrationConstant): the constant whose value to retrieve.

        Returns:
            BonAppetitChecked[float]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_ADC_CALIBRATION_CONSTANT,
            args=GetADCCalibrationConstantCommandArgs(constant),
            response_type=GetADCCalibrationConstantResponseData,
            parse_func=lambda data: float(data.calibration_constant.float_value),
        )

    def set_adc_calibration_constant(
        self, constant: pdt.CalibrationConstant, float_value: str
    ) -> BonAppetitChecked[None]:
        """Change the value of a calibration constant on the Forcen device's ADC.

        Args:
            constant (pdt.CalibrationConstant): the calibration constant whose value to change.
            float_value (str): the new value of that constant, expressed in string format.
                You must provide a string which is parseable into a float, and provide the number
                of decimal places required for the precision you need.

        Returns:
            BonAppetitChecked[None]: _description_
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.SET_ADC_CALIBRATION_CONSTANT,
            args=SetADCCalibConstantCommandArgs(CalibConstantValue(constant, float_value)),
        )

    def save_all_from_ram_to_rom(self) -> BonAppetitChecked[None]:
        """Save the current register values to EEPROM.

        Note that this updates the EEPROM count.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client, command=WSServerCommand.SAVE_ADC_CALIBRATION_CONSTANTS
        )

    def get_adc_sensor_output_model(self) -> BonAppetitChecked[pdt.SensorOutputModel]:
        """Get the Forcen device's data output model.

        Returns:
            BonAppetitChecked[pdt.SensorOutputModel]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_ADC_SENSOR_OUTPUT_MODEL,
            response_type=GetADCSensorOutputModelResponseData,
            parse_func=lambda data: data.adc_sensor_output_model,
        )

    def set_adc_sensor_output_model(
        self, sensor_output_model: pdt.SensorOutputModel
    ) -> BonAppetitChecked[None]:
        """Change the sensor output model on the Forcen device.

        Args:
            sensor_output_model (pdt.SensorOutputModel): the new model.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.SET_ADC_SENSOR_OUTPUT_MODEL,
            args=SetADCSensorOutputModelCommandArgs(adc_sensor_output_model=sensor_output_model),
        )

    def unlock_restricted_functions(self) -> BonAppetitChecked[None]:
        """Send a command to open the Forcen device's extended access lock, for enabling restricted functions.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client, command=WSServerCommand.UNLOCK_RESTRICTED_FUNCTIONS
        )

    def set_access_lock(self, value_as_hex: str) -> BonAppetitChecked[None]:
        """Set the extended access lock to a given value.

        Args:
            value_as_hex (str): a string representation of the new access lock value, e.g. "0xABCDEF"

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.SET_ACCESS_LOCK,
            args=SetAccessLockCommandArgs(access_lock_value_as_hex=value_as_hex),
        )

    def reset_access_lock(self) -> BonAppetitChecked[None]:
        """Disable the extended access lock to remove access to restricted functionality.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(self._client, command=WSServerCommand.RESET_ACCESS_LOCK)

    def get_mode(self) -> BonAppetitChecked[pdt.DeviceMode]:
        """Get the current device mode of the Forcen device.

        Returns:
            BonAppetitChecked[pdt.DeviceMode]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_MODE,
            response_type=GetModeResponseData,
            parse_func=lambda data: data.device_mode,
        )

    def set_mode(self, device_mode: pdt.DeviceMode) -> BonAppetitChecked[None]:
        """Set the Forcen device to a new mode, such as SLEEP or RUNNING.

        Note that not all modes are supported by all firmware versions.

        Args:
            device_mode (pdt.DeviceMode): the new mode to execute on the device.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.SET_MODE,
            args=SetModeCommandArgs(device_mode=device_mode),
        )

    def get_peripheral_type(self) -> BonAppetitChecked[pdt.PeripheralType]:
        """Request information on the peripheral used by the Forcen device, if it has peripherals.

        Returns:
            BonAppetitChecked[pdt.PeripheralType]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_PERIPHERAL_TYPE,
            response_type=GetPeripheralTypeResponseData,
            parse_func=lambda data: data.peripheral_type,
        )

    def set_peripheral_type(self, peripheral_type: pdt.PeripheralType) -> BonAppetitChecked[None]:
        """Change the peripheral used by the Forcen device, if that functionality is supported.

        Args:
            peripheral_type (pdt.PeripheralType): the peripheral to switch to.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.SET_PERIPHERAL_TYPE,
            args=SetPeripheralTypeCommandArgs(peripheral_type=peripheral_type),
        )

    def get_usb_on_boot_delay(self) -> BonAppetitChecked[int]:
        """For Forcen devices which support USB_ON_BOOT, request the boot delay before USB is enabled.

        Returns:
            BonAppetitChecked[int]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_USB_ON_BOOT_DELAY,
            response_type=GetUSBOnBootDelayResponseData,
            parse_func=lambda data: data.usb_on_boot_delay_in_ms,
        )

    def set_usb_on_boot_delay(self, delay_in_ms: UInt32) -> BonAppetitChecked[None]:
        """For Forcen devices which support USB_ON_BOOT, change the boot delay before USB is enabled.

        Args:
            delay_in_ms (UInt32): the new boot delay, in milliseconds.

        Returns:
            BonAppetitChecked[int]
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.SET_USB_ON_BOOT_DELAY,
            args=SetUSBOnBootDelayCommandArgs(usb_on_boot_delay_in_ms=delay_in_ms.v),
        )

    def get_uart_baud_rate(self) -> BonAppetitChecked[pdt.UartBaudRate]:
        """For Forcen devices which support UART, request the baud rate of the UART peripheral.

        Returns:
            BonAppetitChecked[pdt.UartBaudRate]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_UART_BAUD_RATE,
            response_type=GetUartBaudRateResponseData,
            parse_func=lambda data: pdt.UartBaudRate(data.uart_baud_rate),
        )

    def set_uart_baud_rate(self, baud_rate: pdt.UartBaudRate) -> BonAppetitChecked[None]:
        """For Forcen devices which support UART, change the baudrate of the UART peripheral.

        Args:
            baud_rate (pdt.UartBaudRate): the new baudrate.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.SET_UART_BAUD_RATE,
            args=SetUartBaudRateCommandArgs(uart_baud_rate=baud_rate),
        )

    def get_uart_parity(self) -> BonAppetitChecked[pdt.UartParity]:
        """For Forcen devices which support UART, request the UART parity bits.

        Returns:
            BonAppetitChecked[pdt.UartParity]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_UART_PARITY,
            response_type=GetUartParityResponseData,
            parse_func=lambda data: data.uart_parity,
        )

    def set_uart_parity(self, parity: pdt.UartParity) -> BonAppetitChecked[None]:
        """For Forcen devices which support UART, change the UART parity bits.

        Args:
            parity (pdt.UartParity): the new UART parity bits.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.SET_UART_PARITY,
            args=SetUartParityCommandArgs(parity),
        )

    def get_uart_stopbits(self) -> BonAppetitChecked[pdt.UartStopbits]:
        """For Forcen devices which support UART, request the UART stop bits.

        Returns:
            BonAppetitChecked[pdt.UartStopbits]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_UART_STOP_BITS,
            response_type=GetUartStopbitsResponseData,
            parse_func=lambda data: pdt.UartStopbits(data.uart_stopbits),
        )

    def set_uart_stopbits(self, stopbits: pdt.UartStopbits) -> BonAppetitChecked[None]:
        """For Forcen devices which support UART, change the UART stop bits.

        Args:
            stopbits (pdt.UartStopbits): the new stop bits.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.SET_UART_STOP_BITS,
            args=SetUartStopbitsCommandArgs(uart_stopbits=stopbits),
        )

    def get_can_node_id(self) -> BonAppetitChecked[pdt.CanNodeID]:
        """For Forcen devices which support CAN, request the Forcen device's CAN bus node ID.

        Returns:
            BonAppetitChecked[pdt.CanNodeID]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_CAN_NODE_ID,
            response_type=GetCANNodeIDResponseData,
            parse_func=lambda data: pdt.CanNodeID(data.can_node_id),
        )

    def set_can_node_id(self, node_id: pdt.CanNodeID) -> BonAppetitChecked[None]:
        """or Forcen devices which support CAN, change the device's CAN bus node ID.

        Args:
            node_id (pdt.CanNodeID): the new node id.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.SET_CAN_NODE_ID,
            args=SetCANNodeIDCommandArgs(can_node_id=node_id),
        )

    def get_can_baud_rate(self) -> BonAppetitChecked[pdt.CanBaudRate]:
        """For Forcen devices which support CAN, get the baud rate of the CAN bus.

        Returns:
            BonAppetitChecked[pdt.CanBaudRate]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_CAN_BAUD_RATE,
            response_type=GetCANBaudRateReponseData,
            parse_func=lambda data: data.can_baud_rate,
        )

    def set_can_baud_rate(self, baud_rate: pdt.CanBaudRate) -> BonAppetitChecked[None]:
        """or Forcen devices which support CAN, change the baud rate on the CAN bus.

        Args:
            baud_rate (pdt.CanBaudRate): the new baud rate.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.SET_CAN_BAUD_RATE,
            args=SetCANBaudRateCommandArgs(can_baud_rate=baud_rate),
        )

    def get_data_rate(self) -> BonAppetitChecked[int]:
        """Request the rate at which the Forcen device is publishing data, in Hz.

        Returns:
            BonAppetitChecked[int]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_DATA_RATE,
            response_type=GetDataRateResponseData,
            parse_func=lambda data: data.adc_data_rate_hz,
        )

    def set_data_rate(self, data_rate_hz: int) -> BonAppetitChecked[None]:
        """Change the rate at which the Forcen device is publishing data.

        Args:
            data_rate_hz (int): the new data rate, in Hz. Must be positive.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.SET_DATA_RATE,
            args=SetDataRateCommandArgs(adc_data_rate_hz=data_rate_hz),
        )

    def get_led_data(self) -> BonAppetitChecked[pdt.LedData]:
        """Request information about the Forcen device's LED status.

        Returns:
            BonAppetitChecked[pdt.LedData]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_LED_DATA,
            response_type=GetLedDataResponseData,
            parse_func=lambda data: data.led_data,
        )

    def set_led_to_events(self) -> BonAppetitChecked[None]:
        """Set the Forcen device's LED to run in events mode."""
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.SET_LED_TO_EVENTS,
        )

    def set_led_brightness(self, value: int) -> BonAppetitChecked[None]:
        """Set the Forcen device's LED brightness to a specific percentage value.

        Args:
            value (int): the brightness level for the LED.
                Note that only values of 0 or 2-100 are allowed.
                If you wish to set the LED to events mode (a brightness of 1), use `set_led_to_events()`.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.SET_LED_BRIGHTNESS,
            args=SetLedBrightnessCommandArgs(led_brightness=value),
        )

    def get_user_constant(self, register: int) -> BonAppetitChecked[float]:
        """Request the user constant stored in one of the user registers.

        Args:
            register (int): The user register index. See the Forcen device's documentation
                for the allowable range of values.

        Returns:
            BonAppetitChecked[float]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_USER_CONSTANT,
            args=GetUserConstantCommandArgs(user_constant_index=register),
            response_type=GetUserConstantResponseData,
            parse_func=lambda data: float(data.user_constant.float_value),
        )

    def set_user_constant(self, register: int, float_value: str) -> BonAppetitChecked[None]:
        """Change the value of a user constant register.

        Args:
            register (int): the user register index. See the Forcen device's documentation for
                the allowable range of values.
            float_value (str): the new value of that user constant, expressed in string format.
                You must provide a string which is parseable into a float, and provide the number
                of decimal places required for the precision you need.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.SET_USER_CONSTANT,
            args=SetUserConstantCommandArgs(
                UserConstantValue(index=register, float_value=float_value)
            ),
        )

    def load_user_constants(self) -> BonAppetitChecked[None]:
        """Command the Forcen device to load user constants, if supported.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(self._client, command=WSServerCommand.LOAD_USER_CONSTANT)

    def reset_communication(self) -> BonAppetitChecked[None]:
        """Command the Forcen device to reset all communication channels.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(self._client, command=WSServerCommand.RESET_COMMUNICATION)

    def reset_module(self) -> BonAppetitChecked[None]:
        """Command the Forcen device to reboot.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(self._client, command=WSServerCommand.RESET_MODULE)

    def factory_reset(self) -> BonAppetitChecked[None]:
        """Command the Forcen device to perform a full factory reset.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(self._client, command=WSServerCommand.FACTORY_RESET)

    def get_adc_downsample_factor(self) -> BonAppetitChecked[int]:
        """Request the Forcen device's ADC downsampling factor.

        Returns:
            BonAppetitChecked[int]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_ADC_DOWNSAMPLE_FACTOR,
            response_type=GetADCDownsampleFactorResponseData,
            parse_func=lambda data: data.downsampling_factor,
        )

    def set_adc_downsample_factor(self, downsampling_factor: int) -> BonAppetitChecked[None]:
        """Change the Forcen device's ADC downsampling factor, if supported.

        Args:
            downsampling_factor (int): the new downsampling factor. See Forcen documentation for
                allowable values for the device.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.SET_ADC_DOWNSAMPLE_FACTOR,
            args=SetADCDownsampleFactorCommandArgs(downsampling_factor),
        )

    def get_temperature_compensation_enabled(
        self,
    ) -> BonAppetitChecked[bool]:
        """Determine if the Forcen device is compensating sensor data for temperature.

        Returns:
            BonAppetitChecked[bool]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_IS_TEMPERATURE_COMPENSATION_ENABLED,
            response_type=GetIsTemperatureCompensationEnabledResponseData,
            parse_func=lambda data: data.enabled,
        )

    def set_temperature_compensation_enabled(
        self,
        temperature_compensation_mode: int,
    ) -> BonAppetitChecked[None]:
        """Set the amount of temperature compensation on the Forcen device, if supported.

        Args:
            temperature_compensation_mode (int): the temperature compensation mode to enable.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.SET_IS_TEMPERATURE_COMPENSATION_ENABLED,
            args=SetIsTemperatureCompensationEnabledCommandArgs(temperature_compensation_mode != 0),
        )

    def disable_usb_on_boot(self) -> BonAppetitChecked[None]:
        """Turn off the Forcen device's USB on boot process.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(self._client, command=WSServerCommand.DISABLE_USB_ON_BOOT)

    def get_tare_status(
        self,
    ) -> BonAppetitChecked[pdt.TareStatus]:
        """Get the current status of Forcen device calibration, if supported.

        Returns:
            BonAppetitChecked[pdt.TareStatus]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_TARE_STATUS,
            response_type=GetTareStatusResponseData,
            parse_func=lambda data: data.status,
        )

    def get_selected_output_data_stream(
        self,
    ) -> BonAppetitChecked[Set[pdt.SelectedOutputDataStream]]:
        """Request the output data stream selected by the Forcen device.

        Returns:
            BonAppetitChecked[Set[pdt.SelectedOutputDataStream]]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_SELECTED_OUTPUT_STREAM,
            response_type=GetSelectedOutputDataStreamResponseData,
            parse_func=lambda data: set(data.sensor_data_output_modes),
        )

    def select_output_data_stream(
        self,
        sensor_data_output_modes: Set[pdt.SelectedOutputDataStream],
    ) -> BonAppetitChecked[None]:
        """Change the output data stream on the Forcen device.

        Args:
            sensor_data_output_modes (Set[pdt.SelectedOutputDataStream]): the new set of output data.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.SET_SELECTED_OUTPUT_STREAM,
            args=SetSelectedOutputDataStreamCommandArgs(list(sensor_data_output_modes)),
        )

    def get_hardware_error(
        self,
    ) -> BonAppetitChecked[pdt.HardwareErrorCode]:
        """Get the value of the Forcen device's hardware error register, if supported.

        Returns:
            BonAppetitChecked[pdt.HardwareErrorCode]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_HARDWARE_ERROR,
            response_type=GetHardwareErrorResponseData,
            parse_func=lambda data: data.code,
        )

    def clear_hardware_error(
        self,
    ) -> BonAppetitChecked[None]:
        """Clear the Forcen device's hardware error.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(self._client, command=WSServerCommand.CLEAR_HARDWARE_ERROR)

    def get_runtime_device_error(
        self, register: int = 0
    ) -> BonAppetitChecked[Set[pdt.RuntimeDeviceErrorCode]]:
        """Request the value of a software error register on the Forcen device.

        Args:
            register (int, optional): the error register to read. Defaults to 0.

        Returns:
            BonAppetitChecked[Set[pdt.RuntimeDeviceErrorCode]]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_RUNTIME_DEVICE_ERROR,
            args=GetRuntimeDeviceErrorCommandArgs(register=register),
            response_type=GetRuntimeDeviceErrorResponseData,
            parse_func=lambda data: set(data.codes),
        )

    def send_raw_packet_unchecked_unsafe(
        self,
        packet: SendTransportPacket,
        kill_server_debug_unsafe: bool = False,
        kill_udp_sensor_data_publishers_unsafe: bool = False,
    ) -> BonAppetitChecked[ReplyPacketStamped]:
        """Send a raw packet to the server, without checking if it is valid.

        Args:
            packet (SendTransportPacket): the data to send to the server.
            kill_server_debug_unsafe (bool, optional): debug flag to force the server to turn off
                its heartbeat. This only does something if that server is connected to
                a BonAppetitMaster, and is intended for debugging purposes only. Defaults to False.
            kill_udp_sensor_data_publishers_unsafe (bool, optional): Turn off the server's sensor
                data publishers. This is intended for debugging purposes only. Defaults to False.

        Returns:
            BonAppetitChecked[ReplyPacketStamped]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.SEND_RAW_PACKET_UNCHECKED_UNSAFE,
            args=SendRawPacketUncheckedUnsafeCommandArgs(
                transport_packet=str(packet.payload),
                kill_server_debug_unsafe=kill_server_debug_unsafe,
                kill_udp_sensor_data_publishers_unsafe=kill_udp_sensor_data_publishers_unsafe,
            ),
            response_type=SendRawPacketUncheckedUnsafeResponseData,
            parse_func=lambda data: data.reply_packet_stamped,
        )

    def set_process_function_from_raw_script_unchecked_unsafe(
        self,
        encrypted_user_script: Optional[BonappetitUserScriptEncoderResultNoPassword],
    ) -> BonAppetitChecked[None]:
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.SET_USER_SCRIPT_UNCHECKED_UNSAFE,
            args=SetUserScriptUncheckedUnsafeCommandArgs(encrypted_script=encrypted_user_script),
        )

    # Methods added by CLv1.2.x
    # -------------------------

    def get_sensor_data_frame(self) -> BonAppetitChecked[None]:
        """Request a one-time packet of sensor data from a Forcen device in ACTIVE mode.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.GET_SENSOR_DATA_FRAME,
        )

    # # TODO (swapnil) - I think this already exists in v7.2/v7.3. Confirm
    # def get_device_model(self) -> BonAppetitChecked[pdt.SensorOutputModel]:
    #     raise NotImplementedError()

    # # TODO (swapnil) - I think this already exists in v7.2/v7.3. Confirm
    # def get_device_type(self) -> BonAppetitChecked[str]:
    #     raise NotImplementedError()

    def enter_boot_mode(self) -> BonAppetitChecked[None]:
        """Command the Forcen device to enter boot mode.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.ENTER_BOOT_MODE,
        )

    def get_imu_data_style(self) -> BonAppetitChecked[pdt.ImuDataStyle]:
        """For Forcen devices with IMUs, request the type of data stream outputted by that IMU.

        Returns:
            BonAppetitChecked[pdt.ImuDataStyle]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_IMU_DATA_STYLE,
            response_type=GetImuDataStyleResponseData,
            parse_func=lambda data: data.imu_data_style,
        )

    def set_imu_data_style(self, imu_style: pdt.ImuDataStyle) -> BonAppetitChecked[None]:
        """For Forcen devices with IMUs, change the data types outputted by that IMU.

        Args:
            imu_style (pdt.ImuDataStyle): the list of output data types.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.SET_IMU_DATA_STYLE,
            args=SetImuDataStyleCommandArgs(imu_data_style=imu_style),
        )

    def get_ip_address(self) -> BonAppetitChecked[IPv4]:
        """Request the IP address of a Forcen device with a network card.

        Returns:
            BonAppetitChecked[IPv4]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_IP_ADDRESS,
            response_type=GetIPAddressResponseData,
            parse_func=lambda data: self._parse_ipv4_from_string(data.ipv4),
        )

    def set_ip_address(self, ip_address: IPv4) -> BonAppetitChecked[None]:
        """Change the IP address of a Forcen device with a network card.

        Args:
            ip_address (IPv4): the new ip address.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.SET_IP_ADDRESS,
            args=SetIPAddressCommandArgs(ipv4=str(ip_address)),
        )

    def get_netmask(self) -> BonAppetitChecked[IPv4]:
        """Request the netmask of a Forcen device's network card.

        Returns:
            BonAppetitChecked[IPv4]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_NETMASK,
            response_type=GetNetmaskResponseData,
            parse_func=lambda data: self._parse_ipv4_from_string(data.netmask),
        )

    def set_netmask(self, netmask: IPv4) -> BonAppetitChecked[None]:
        """Change the netmask of a Forcen device's network card.

        Args:
            netmask (IPv4): the new netmask

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.SET_NETMASK,
            args=SetNetmaskCommandArgs(netmask=str(netmask)),
        )

    def get_network_gateway(self) -> BonAppetitChecked[IPv4]:
        """Get the gateway address of a Forcen device's network card.

        Returns:
            BonAppetitChecked[IPv4]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_NETWORK_GATEWAY,
            response_type=GetGatewayResponseData,
            parse_func=lambda data: self._parse_ipv4_from_string(data.gateway),
        )

    def set_network_gateway(self, gateway: IPv4) -> BonAppetitChecked[None]:
        """Change the gateway address of a Forcen device's network card.

        Args:
            gateway (IPv4): the new gateway address.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.SET_NETWORK_GATEWAY,
            args=SetGatewayCommandArgs(gateway=str(gateway)),
        )

    def get_mac_address(self) -> BonAppetitChecked[MacAddr48]:
        """Request the Forcen device's MAC address.

        Returns:
            BonAppetitChecked[MacAddr48]
        """
        return send_and_recv_data(
            self._client,
            command=WSServerCommand.GET_MAC_ADDRESS,
            response_type=GetMacAddressResponseData,
            parse_func=lambda data: self._parse_mac_addr_48_from_string(data.mac_address_48),
        )

    def set_mac_address(self, mac_address: MacAddr48) -> BonAppetitChecked[None]:
        """Change the Forcen device's MAC address.

        Args:
            mac_address (MacAddr48): the new mac address for the device.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSServerCommand.SET_MAC_ADDRESS,
            args=SetMacAddressCommandArgs(mac_address_48=str(mac_address)),
        )

    def heartbeat_fire_and_forget(self) -> BonAppetitChecked[None]:
        """Heartbeat functions not implemented"""

        raise NotImplementedError()

    def is_heartbeat_reply(self, data: ReplyPacketStamped) -> bool:
        """Heartbeat functions not implemented"""

        raise NotImplementedError()

    # -------------- #
    # Helper Methods #
    # -------------- #
    def _parse_ipv4_from_string(self, raw_ip_addr: str) -> IPv4:
        maybe_ip = IPv4.from_str(raw_ip_addr)
        if maybe_ip is None:
            raise ValueError(
                f"Invalid ip address, expected IPv4-formatted string."
                f" Got [{raw_ip_addr}] instead."
            )
        return maybe_ip

    def _parse_mac_addr_48_from_string(self, raw_mac_addr: str) -> MacAddr48:
        maybe_mac_addr = MacAddr48.from_str(raw_mac_addr)
        if maybe_mac_addr is None:
            raise ValueError(
                f"Invalid mac address, expected MacAddr48-formatted string."
                f" Got [{raw_mac_addr}] instead."
            )
        return maybe_mac_addr
