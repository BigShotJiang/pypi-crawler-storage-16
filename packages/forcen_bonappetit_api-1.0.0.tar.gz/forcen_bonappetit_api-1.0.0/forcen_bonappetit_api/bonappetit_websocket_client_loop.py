import copy
import enum
import json
import threading
import time
from typing import Callable, List, Optional, Tuple, Any, Dict

import websockets.exceptions as ws_excp
import websockets.sync.client as ws_cli

import forcen_public_utils.checked as ch
from forcen_bonappetit_api.bonappetit_websocket_server_messages import SensorDataList
from forcen_bonappetit_api.common.error_types import BonAppetitChecked, BonAppetitCode
from forcen_bonappetit_api.protocol.protocol_transport_types import RTDPacketStamped
from forcen_bonappetit_api.bonappetit_websocket_helpers import make_client
from forcen_public_utils.interactive_thread import InteractiveThread
from forcen_public_utils.loggers.console_logger import ConsoleLogger
from forcen_public_utils.rate import Rate
from forcen_public_utils.websocket_uri import make_websocket_uri

_MAX_DATA_PARSE_ERROR_COUNTER = 5


class _RecvError(enum.Enum):
    DATA_PARSE_ERROR = enum.auto()
    CONNECTION_CLOSED = enum.auto()


_RecvChecked = ch.Checked[Optional[Dict[str, Any]], _RecvError]


class BonappetitWebsocketClientLoop:
    """This object is designed to be used by BonAppetitClient, to handle websocket subscriptions to sensor data.

    It manages and collects non-realtime data, which is streamed via UDP by the BonAppetitServer 
    to the client.
    """
    def __init__(
        self,
        server_name: str,
        default_timeout: float,
        ip_address: str,
        port: int,
        error_callback: Callable[[ch.FullError[BonAppetitCode]], None],
        data_callback: Callable[[Dict[str, Any]], None],
    ):
        self._name = server_name
        self._default_timeout = default_timeout
        self._subscriber = make_client(self._name, ip_address, port, default_timeout)
        self._peer_address = (ip_address, port)
        self._self_address = self._subscriber.socket.getsockname()

        self._data_parse_error_counter = 0
        self._error_callback = error_callback
        self._data_callback = data_callback

        self._is_dead = False
        self._thread = InteractiveThread()
        self._thread.start(self._loop)

    def stop(self):
        self._thread.stop()
        self._subscriber.close()

    def get_address(self) -> Optional[Tuple[str, int]]:
        return self._self_address.get_copy()

    def _handle_recv_errors(self, full_error: ch.FullError[_RecvError]) -> ch.FullError[BonAppetitCode]:
        ConsoleLogger.get().warning(full_error.message)
        if full_error.error == _RecvError.DATA_PARSE_ERROR:
            self._data_parse_error_counter += 1
            if self._data_parse_error_counter < _MAX_DATA_PARSE_ERROR_COUNTER:
                return ch.FullError(BonAppetitCode.PACKET_ERROR, message=full_error.message)
            else:
                return ch.FullError(
                    BonAppetitCode.SERVER_DISCONNECT,
                    message=f"[{self._name}] Too many consecutive data parsing errors",
                )

        elif full_error.error == _RecvError.CONNECTION_CLOSED:
            return ch.FullError(
                BonAppetitCode.SERVER_DISCONNECT,
                message=f"[{self._name}]  Connection Closed",
            )
        
        raise ValueError("_RecvError enum wasn't fully handled, fatal error")

    def _recv(self) -> _RecvChecked:
        try:
            message = self._subscriber.recv(0)
        except TimeoutError:
            return ch.ok(None)            
        except ws_excp.ConnectionClosed as e:
            return ch.bad(_RecvError.CONNECTION_CLOSED, message=f"{e}")

        try:
            return ch.ok(json.loads(message))
        except json.JSONDecodeError as e:
            return ch.bad(
                _RecvError.DATA_PARSE_ERROR,
                message=(
                    f"Failed to decode websocket message into json. "
                    f"Raw msg: {message}. "
                    f"Error: {e}."
                ),
            )

    def _loop(
        self,
        stop_requested: threading.Event,
    ) -> None:
        ConsoleLogger.get().info("BonAppetitClient - subscriber loop started")
        rate = Rate(100)
        try:
            while not stop_requested.is_set():
                rate.sleep()
                
                maybe_recv_data = self._recv()
                if maybe_recv_data.has_value():
                    recv_data = maybe_recv_data.value()
                    if recv_data is not None:
                        self._data_parse_error_counter = 0
                        self._data_callback(recv_data)
                else:
                    bonappetit_error = self._handle_recv_errors(maybe_recv_data.full_error())
                    self._error_callback(bonappetit_error)
                    if bonappetit_error.error == BonAppetitCode.SERVER_DISCONNECT:
                        return

        except ws_excp.ConnectionClosed as e:
            self._error_callback(
                ch.FullError(
                    BonAppetitCode.SERVER_DISCONNECT,
                    message=f"[{self._name}] Connection closed. Got: {e}",
                )
            )
            raise e
        except Exception as e:
            self._error_callback(
                ch.FullError(
                    BonAppetitCode.EXCEPTION_RAISED,
                    message=f"[{self._name}] subscriber loop exception: {e}",
                )
            )
            raise e
        finally:
            self._is_dead = True
            ConsoleLogger.get().warning(f"[{self._name}] subscriber loop function end")
