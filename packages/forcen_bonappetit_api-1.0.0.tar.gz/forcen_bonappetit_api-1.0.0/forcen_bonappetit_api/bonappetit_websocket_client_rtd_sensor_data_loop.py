import dataclasses
import enum
import select
import socket
import threading
import time
from typing import Callable, List, Optional, Tuple, cast

import forcen_public_utils.checked as ch
from forcen_bonappetit_api.bonappetit_websocket_generic_messages import AsciiConst
from forcen_bonappetit_api.common.error_types import BonAppetitChecked, BonAppetitCode
from forcen_bonappetit_api.protocol.protocol_transport_types import RTDPacketStamped
from forcen_public_utils.atomic import NullableAtomic
from forcen_public_utils.interactive_thread import InteractiveThread
from forcen_public_utils.loggers.console_logger import ConsoleLogger

_MAX_DATA_PARSE_ERROR_COUNTER = 5
_MAX_SOCKET_RECV_ERRORS = 5
_MAX_HEARTBEAT_PERIOD = 5.0


@dataclasses.dataclass
class _RecvData:
    heartbeat_timestamp: Optional[float] = None
    packets: Optional[List[RTDPacketStamped]] = None


class _RecvError(enum.Enum):
    DATA_PARSE_ERROR = enum.auto()
    SOCKET_RECV_ERROR = enum.auto()


_RecvChecked = ch.Checked[_RecvData, _RecvError]


class BonappetitWebsocketClientRTDSensorDataLoop:
    """This object is designed to be used by BonAppetitClient, to handle real time subscriptions to sensor data.

    It manages and collects realtime data, which is streamed via UDP by the BonAppetitServer using
    a peer-to-peer connection with this object.
    """

    def __init__(
        self,
        peer_address: NullableAtomic[Tuple[str, int]],
        error_callback: Callable[[ch.FullError[BonAppetitCode]], None],
        rtd_packet_callback: Callable[[List[RTDPacketStamped]], None],
    ):
        """Create a UDP connection to a server and begin collecting realtime sensor data.

        Args:
            peer_address (NullableAtomic[Tuple[str, int]]): the peer address of the server,
                given as a nullable atomic tuple containing the ip_address and port for the connection.
            error_callback (Callable[[BonAppetitChecked[None]], None]): this is called whenever
                realtime data packets received via UDP have an error.
            rtd_packet_callback (Callable[[RTDPacketStamped], None]): this is called whenever
                relatime data packets received via UDP are valid.
        """
        ConsoleLogger.get().info("Creating udp socket for sensor data connection")
        self._udp_socket = self._make_udp_socket()
        self._peer_address = peer_address
        self._self_address = NullableAtomic[Tuple[str, int]](self._udp_socket.getsockname())

        self._last_heartbeat_recv_time = time.time()
        self._udp_socket_error_counter = 0
        self._data_parse_error_counter = 0
        self._error_callback = error_callback
        self._packet_callback = rtd_packet_callback

        ConsoleLogger.get().info("Starting thread for sensor data udp socket")
        self._is_dead = False
        self._thread = InteractiveThread()
        self._thread.start(self._loop)

    def stop(self):
        """Stop receiving data."""
        self._thread.stop()

    def get_address(self) -> Optional[Tuple[str, int]]:
        """Get the peer address of this object's UDP socket.

        Returns:
            Optional[Tuple[str, int]]: a tuple containing the ip address and port.
        """
        return self._self_address.get_copy()

    @staticmethod
    def _make_udp_socket() -> socket.socket:
        udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        udp_socket.bind(("localhost", 0))
        udp_socket.setblocking(False)
        return udp_socket

    def _recv(self) -> _RecvChecked:
        try:
            received_packets: List[RTDPacketStamped] = []
            while True:
                sockets_avail_for_reading, _, _ = select.select([self._udp_socket], [], [], 0.0001)
                if len(sockets_avail_for_reading) == 0:
                    if len(received_packets) == 0:
                        return ch.ok(_RecvData())
                    else:
                        return ch.ok(_RecvData(packets=received_packets))

                ready_socket = cast(socket.socket, sockets_avail_for_reading[0])
                data, _ = ready_socket.recvfrom(64)
                recv_time = time.time()
                data.strip(b"\x00")
                data.strip(b"\n")
                if data == AsciiConst.ACK.value:
                    return ch.ok(_RecvData(heartbeat_timestamp=recv_time))

                try:
                    tokens = data.decode("utf-8").split(" ")
                    # if we get sensor data from the server, that also means the server is alive
                    received_packets.append(
                        RTDPacketStamped(
                            tuple([int(ii) for ii in tokens[1:]]), float(tokens[0])
                        )
                    )
                except (IndexError, ValueError) as e:
                    return ch.bad(
                        _RecvError.DATA_PARSE_ERROR,
                        message=f"failed to parse data received on udp connection. {data}.\n\n{e}",
                    )

        except socket.error as e:
            return ch.bad(
                _RecvError.SOCKET_RECV_ERROR,
                message=f"got error while trying to receive data from udp socket.\n\n{e}",
            )

    def _handle_recv_errors(self, full_error: ch.FullError[_RecvError]) -> ch.FullError[BonAppetitCode]:
        ConsoleLogger.get().warning(full_error.message)
    
        if full_error.error == _RecvError.DATA_PARSE_ERROR:
            self._data_parse_error_counter += 1
            if self._data_parse_error_counter < _MAX_DATA_PARSE_ERROR_COUNTER:
                return ch.FullError(BonAppetitCode.PACKET_ERROR, message=full_error.message)
            else:
                return ch.FullError(
                    BonAppetitCode.SENSOR_DATA_SOCKET_FATAL,
                    message=f"Too many consecutive data parsing errors. Ending sensor data connection",
                )

        elif full_error.error == _RecvError.SOCKET_RECV_ERROR:
            self._udp_socket_error_counter += 1
            if self._udp_socket_error_counter < _MAX_SOCKET_RECV_ERRORS:
                self._udp_socket = self._make_udp_socket()
                self._self_address.set(self._udp_socket.getsockname())
                return ch.FullError(
                    BonAppetitCode.SENSOR_DATA_SOCKET_ERROR, message=full_error.message
                )
            else:
                return ch.FullError(
                    BonAppetitCode.SENSOR_DATA_SOCKET_FATAL,
                    message=f"Too many consecutive socket connection errors. Ending sensor data connection",
                )
            
        raise ValueError("Didn't exhaustively handle _RecvError enum, Fatal Error")

    def _loop(self, stop_requested: threading.Event):
        ConsoleLogger.get().info(f"BonAppetitClient - udp connection loop started")

        prev_heartbeat_send_time = time.time()
        last_heartbeat_recv_time = time.time()
        try:
            while not stop_requested.is_set():
                curr_time = time.time()
                server_addr = self._peer_address.get_copy()
                recv_resp = self._recv()
                if recv_resp.has_value():
                    self._data_parse_error_counter = 0
                    self._udp_socket_error_counter = 0

                    recv_resp_value = recv_resp.value()
                    if recv_resp_value.heartbeat_timestamp is not None:
                        last_heartbeat_recv_time = recv_resp_value.heartbeat_timestamp
                    if recv_resp_value.packets is not None and len(recv_resp_value.packets) > 0:
                        self._packet_callback(recv_resp_value.packets)
                else:
                    error_ret = self._handle_recv_errors(recv_resp.full_error())
                    self._error_callback(error_ret)
                    if error_ret.error == BonAppetitCode.SENSOR_DATA_SOCKET_FATAL:
                        break

                if server_addr is not None and curr_time - prev_heartbeat_send_time > 1.0:
                    self._udp_socket.sendto(AsciiConst.ENQ.value + AsciiConst.LF.value, server_addr)
                    prev_heartbeat_send_time = curr_time
                    if curr_time - last_heartbeat_recv_time > _MAX_HEARTBEAT_PERIOD:
                        self._error_callback(
                            ch.FullError(
                                BonAppetitCode.SENSOR_DATA_SOCKET_FATAL,
                                message=f"no heartbeats received from udp sensor data server for {_MAX_HEARTBEAT_PERIOD} seconds",
                            )
                        )
                        break

        finally:
            self._is_dead = True
            self._self_address.clear()
            self._udp_socket.close()
            ConsoleLogger.get().warning(f"BonAppetitClient - udp connection loop ended")
