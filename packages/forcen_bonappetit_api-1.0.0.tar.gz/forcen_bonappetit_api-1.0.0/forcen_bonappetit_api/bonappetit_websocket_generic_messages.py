"""A collection of flags, enums, dataclasses, and other objects defining the messages 
which can be sent to/from Forcen websocket servers or clients.
"""
import dataclasses
import enum
from typing import Any, Dict, Generic, Optional, TypeVar

import dataclasses_json

from forcen_bonappetit_api.common.error_types import BonAppetitCode

_T = TypeVar("_T", bound=enum.Enum)


class AsciiConst(enum.Enum):
    NUL = b"\x00"
    SOH = b"\x01"
    STX = b"\x02"
    ETX = b"\x03"
    EOT = b"\x04"
    ENQ = b"\x05"
    ACK = b"\x06"
    BEL = b"\x07"
    BS = b"\x08"
    HT = b"\x09"
    LF = b"\x0A"
    VT = b"\x0B"
    FF = b"\x0C"
    CR = b"\x0D"
    SO = b"\x0E"
    SI = b"\x0F"
    DLE = b"\x10"
    DC1 = b"\x11"
    DC2 = b"\x12"
    DC3 = b"\x13"
    DC4 = b"\x14"
    NAK = b"\x15"
    SYN = b"\x16"
    ETB = b"\x17"
    CAN = b"\x18"
    EM = b"\x19"
    SUB = b"\x1A"
    ESC = b"\x1B"
    FS = b"\x1C"
    GS = b"\x1D"
    RS = b"\x1E"
    US = b"\x1F"
    SPACE = b"\x20"
    DEL = b"\x7F"


@dataclasses.dataclass(frozen=True)
class DetailedCommand(dataclasses_json.DataClassJsonMixin, Generic[_T]):
    command: _T
    command_args: Dict[str, Any] = dataclasses.field(default_factory=dict)


@dataclasses.dataclass
class Response:
    desc: str
    code: Optional[BonAppetitCode]
    payload: Dict[str, Any]
    success: bool = dataclasses.field(init=False)

    def __post_init__(self):
        self.success = self.code is None


@dataclasses.dataclass
class TaggedResponse(dataclasses_json.DataClassJsonMixin, Generic[_T]):
    command: _T
    desc: str
    code: Optional[BonAppetitCode]
    payload: Dict[str, Any]
    success: bool = dataclasses.field(init=False)

    def __post_init__(self):
        self.success = self.code is None

    @staticmethod
    def from_response(command: _T, response: Response) -> "TaggedResponse[_T]":
        return TaggedResponse(
            command=command,
            code=response.code,
            payload=response.payload,
            desc=response.desc,
        )
