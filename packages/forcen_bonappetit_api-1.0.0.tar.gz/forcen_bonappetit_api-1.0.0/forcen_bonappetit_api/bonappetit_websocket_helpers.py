"""Helper methods for websocket communication."""

import enum
import json
import time
from typing import Any, Callable, Dict, Optional, Type, TypeVar

import dataclasses_json
import websockets.exceptions as ws_excp
import websockets.sync.client as ws_cli  # pyright: ignore[reportUnusedImport]
import websockets.sync.server as ws_srv
import websockets.sync.connection as ws_conn
import websockets.typing as ws_typing

import forcen_public_utils.checked as ch
from forcen_public_utils.rate import Rate
from forcen_public_utils.loggers.console_logger import ConsoleLogger
from forcen_public_utils.websocket_uri import make_websocket_uri

from forcen_bonappetit_api.bonappetit_websocket_generic_messages import (
    TaggedResponse,  # pyright: ignore[reportUnusedImport]
)
from forcen_bonappetit_api.bonappetit_websocket_generic_messages import (
    DetailedCommand,
    Response,
)
from forcen_bonappetit_api.common.error_types import BonAppetitChecked, BonAppetitCode

_Enum = TypeVar("_Enum", bound=enum.Enum)
_CommandArgsT = TypeVar("_CommandArgsT", bound=dataclasses_json.DataClassJsonMixin)
_ResponseT = TypeVar("_ResponseT", bound=dataclasses_json.DataClassJsonMixin)
_OutputT = TypeVar("_OutputT")


def send_response(
    ws_server: ws_srv.ServerConnection, command: enum.Enum, response: Response
) -> None:
    """Send a tagged response to a server as JSON

    Args:
        ws_server (ws_srv.ServerConnection): the server to which we are sending the tagged response.
        command (enum.Enum): the command to send
        response (Response): the response message containing the success code, payload, etc.
    """
    ws_server.send(TaggedResponse.from_response(command, response).to_json())


def parse_message(
    command_type: Type[_Enum], message: ws_typing.Data
) -> ch.MaybeVal[DetailedCommand[_Enum]]:
    try:
        return ch.ok(DetailedCommand[_Enum].from_json(message))
    except (json.JSONDecodeError, KeyError, ValueError) as e:
        return ch.bad(
            message=(
                f"Failed to decode websocket message into json. Raw msg: {message}. "
                f"Error:\n\n{e}"
            )
        )


def make_client(name: str, ip_address: str, port: int, timeout: float) -> ws_cli.ClientConnection:
    throttle_rate = Rate(10)
    start_time = time.time()
    while True:
        if time.time() - start_time > timeout:
            raise TimeoutError(f"Failed to connect to {name} {ip_address}:{port}")

        try:
            ConsoleLogger.get().info(f"Trying to connect to {name} {ip_address}:{port}")
            return ws_cli.connect(make_websocket_uri(ip_address, port))
        except (ConnectionRefusedError, OSError):
            throttle_rate.sleep()


def send_and_recv_empty_data(
    client: ws_conn.Connection,
    command: enum.Enum,
    args: Optional[_CommandArgsT] = None,
    timeout: float = 10.0,
) -> BonAppetitChecked[None]:
    """Send a command to through a client connection and wait for the server to respond with an empty message.

    Args:
        client (ws_conn.Connection): the client that is sending the command.
        command (enum.Enum): the command to send
        args (Optional[_CommandArgsT], optional): The command's arguments, if any. Defaults to None.
        timeout (float, optional): how long to wait for a server reply. Defaults to 10.0.

    Returns:
        BonAppetitChecked[None]
    """
    maybe_data = _send_and_recv_helper(client, command, args, timeout)
    if maybe_data.has_error():
        return ch.fwd_err(maybe_data)
    return ch.ok()


def send_and_recv_data(
    client: ws_conn.Connection,
    command: enum.Enum,
    response_type: Type[_ResponseT],
    args: Optional[_CommandArgsT] = None,
    parse_func: Callable[[_ResponseT], _OutputT] = lambda x: x,
    timeout: float = 10.0,
) -> BonAppetitChecked[_OutputT]:
    """Send a command to through a client connection and wait for the server to respond with a
    message of a pre-specified type.

    Args:
        client (ws_conn.Connection): the client that is sending the command
        command (enum.Enum): the command to send to the server
        response_type (Type[_ResponseT]): the expected type of the response message
        args (Optional[_CommandArgsT], optional): the command arguments, if any. Defaults to None.
        parse_func (Callable[[_ResponseT], _OutputT], optional): a callable which defines how
            to parse the response from the server. Defaults to lambdax:x.
        timeout (float, optional): how long to wait for a server response. Defaults to 10.0.

    Returns:
        BonAppetitChecked[_OutputT]
    """
    maybe_data = _send_and_recv_helper(client, command, args, timeout)
    if maybe_data.has_error():
        return ch.fwd_err(maybe_data)

    try:
        output = response_type.from_dict(maybe_data.value())
        output = parse_func(output)
    except Exception as e:  # pylint: disable=broad-exception-caught
        return ch.bad(
            BonAppetitCode.PACKET_ERROR,
            message=(
                f"Failed to interpret response data. If the connection is stable, this could be a "
                f"bug in the parsing implementation.\n\n{e}\n"
            ),
        )

    return ch.ok(output, message=maybe_data.message)


def _send_and_recv_helper(
    client: ws_conn.Connection,
    command: enum.Enum,
    args: Optional[_CommandArgsT] = None,
    timeout: float = 10.0,
) -> BonAppetitChecked[Dict[str, Any]]:
    command_args = {} if args is None else args.to_dict()
    try:
        json_detailed_command = DetailedCommand(command, command_args).to_json()
        client.send(json_detailed_command)
    except (RuntimeError, ws_excp.ConnectionClosed, TypeError) as e:
        return ch.bad(
            BonAppetitCode.SERVER_DISCONNECT,
            message=f"Failed to send data to server.\n\n{e}\n",
        )

    try:
        data = client.recv(timeout)
    except TimeoutError as _:
        return ch.bad(
            BonAppetitCode.SERVER_TIMEOUT,
            message="received no reply from websocket server.",
        )
    except ws_excp.ConnectionClosed as e:
        return ch.bad(
            BonAppetitCode.SERVER_DISCONNECT,
            message=f"websocket connection closed with result: {e}",
        )

    try:
        tagged_response = TaggedResponse.from_json(data)
    except (json.JSONDecodeError, TypeError) as e:
        return ch.bad(
            BonAppetitCode.PACKET_ERROR,
            message=f"failed to parse websocket response into json.\n\n{e}\n",
        )

    if command != tagged_response.command:
        return ch.bad(
            BonAppetitCode.PACKET_ERROR,
            message=f"Got reply from websocket server, but for a different command. Response: {data}",
        )

    if not tagged_response.success:
        assert tagged_response.code is not None
        return ch.bad(tagged_response.code, message=tagged_response.desc)

    assert tagged_response.payload is not None
    return ch.ok(tagged_response.payload, message=tagged_response.desc)
