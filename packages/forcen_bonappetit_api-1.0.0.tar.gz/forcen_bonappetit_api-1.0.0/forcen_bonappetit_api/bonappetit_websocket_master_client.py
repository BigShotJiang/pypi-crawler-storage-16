import time
import threading
from typing import Any, Dict, List, Sequence, Union, Callable, Optional
from uuid import UUID

import websockets.sync.client as ws_cli

from forcen_bonappetit_api.bonappetit_websocket_helpers import (
    send_and_recv_data,
    send_and_recv_empty_data,
)
from forcen_bonappetit_api.bonappetit_websocket_master_messages import (
    KillAllServerResponseData,  # pyright: ignore[reportUnusedImport]
)
from forcen_bonappetit_api.bonappetit_websocket_master_messages import (
    KillServerResponseData,  # pyright: ignore[reportUnusedImport]
)
from forcen_bonappetit_api.bonappetit_websocket_master_messages import (
    DetectedSerialDevice,
    GetActiveServersResponseData,
    GetDetectedDevicesCommandArgs,
    GetDetectedDevicesResponseData,
    KillServerCommandArgs,
    PartialServerInfo,
    ServerInfo,
    SpawnServerCommandArgs,
    SpawnServerResponseData,
    WSMasterCommand,
    ConnectToExistingServerCommandArgs,
    ConnectToExistingServerResponseData,
    ServerInfoWithError,
)
from forcen_bonappetit_api.common.error_types import (
    BonAppetitCode,  # pyright: ignore[reportUnusedImport]
)
from forcen_bonappetit_api.common.error_types import BonAppetitChecked
from forcen_bonappetit_api.bonappetit_websocket_helpers import make_client
from forcen_bonappetit_api.bonappetit_websocket_client_loop import BonappetitWebsocketClientLoop

from forcen_public_utils.interactive_thread import InteractiveThread
from forcen_public_utils.rate import Rate
from forcen_public_utils.websocket_uri import make_websocket_uri
import forcen_public_utils.checked as ch
from forcen_public_utils.loggers.console_logger import ConsoleLogger


class BonAppetitMasterClient:
    """A websocket-based client which can send commands and messages with the BonAppetitMaster.

    This client implements the master-client/master-server protocol defined in
    `docs/websocket_protocol.md`.

    Usage assuming the master is running on the local computer, at port 65535:
    ```python
    with BonAppetitMasterClient("localhost", 65535) as master_client:
        # Send commands to the master here:
        active_servers = master_client.get_active_servers().value()
        # etc...
    ```
    """

    def __init__(
        self,
        master_ip_address: str,
        master_command_srv_port: int,
        master_error_pub_port: int,
        default_timeout: float = 10,
        error_callback: Optional[
            Callable[[Union[ServerInfoWithError, ch.FullError[BonAppetitCode]]], None]
        ] = None,
    ):
        """Open a websocket client connection with a BonAppetitMaster.

        Args:
            master_ip_address (str): the ip address where the master can be located.
            master_port (int): the port on which the master is receiving data.
            default_timeout (float, optional): how long to try connecting to the master. Defaults to 10.

        Raises:
            TimeoutError: if the timeout is triggered before a connection is complete.
        """
        self._default_timeout = default_timeout
        self._error_callback = error_callback if error_callback is not None else lambda _: None

        self._client = make_client(
            name="bonappetit master command client",
            ip_address=master_ip_address,
            port=master_command_srv_port,
            timeout=default_timeout,
        )

        def server_error_cb_helper(raw_err: Dict[str, Any]) -> None:
            ConsoleLogger.get().error(f"mc got error: {ServerInfoWithError.from_dict(raw_err)}")
            self._error_callback(ServerInfoWithError.from_dict(raw_err))

        self._error_sub = BonappetitWebsocketClientLoop(
            server_name="bonappetit master error subscriber",
            ip_address=master_ip_address,
            port=master_error_pub_port,
            default_timeout=default_timeout,
            error_callback=self._error_callback,
            data_callback=server_error_cb_helper,
        )

    def __enter__(self):
        return self

    def __exit__(self, exception_type, exception_value, exception_traceback):
        self.stop()

    def stop(self) -> None:
        """Close the websocket connection with the BonAppetitMaster."""
        self._client.close()

    def get_active_servers(
        self,
    ) -> BonAppetitChecked[Sequence[Union[ServerInfo, PartialServerInfo]]]:
        """Request that the BonAppetitMaster send a list of all living servers it is currently managing.

        Returns:
            BonAppetitChecked[List[ServerInfo]]
        """
        return send_and_recv_data(
            self._client,
            command=WSMasterCommand.GET_ACTIVE_SERVERS,
            response_type=GetActiveServersResponseData,
            parse_func=lambda data: data.servers,
        )

    def get_detected_devices(
        self, rerun_detection: bool
    ) -> BonAppetitChecked[List[DetectedSerialDevice]]:
        """Get the list of Forcen devices connected (via Serial port)
        to the same computer on which the BonAppetitMaster is running.

        Args:
            rerun_detection (bool): if true, run a scan of all serial ports. If false, return the
                list of Forcen devices found during the last scan.

        Returns:
            BonAppetitChecked[List[DetectedSerialDevice]]
        """
        return send_and_recv_data(
            self._client,
            command=WSMasterCommand.GET_DETECTED_DEVICES,
            args=GetDetectedDevicesCommandArgs(rerun_detection),
            response_type=GetDetectedDevicesResponseData,
            parse_func=lambda data: data.serial_devices,
        )

    def spawn_server(
        self,
        server_ip_address: str,
        transport_type: str,
        device_info: Dict[str, Any],
        enable_sensor_data_logging: bool,
        enable_comms_logging: bool,
    ) -> BonAppetitChecked[UUID]:
        """Tell the BonAppetitMaster to spawn a new websocket server, which will connect to the Forcen device
        that has the given device information.

        For example, if there is a Forcen sensor on the network which has a TCP port open at
        "192.168.0.7" at port 2000, you would run:
        ```python
        spawn_server("tcp", {"ip_address": "192.168.0.7", "port":2000})
        ```

        If there were a Forcen device connected via Serial port at "COM7" (e.g. one found with
        `get_detected_devices()`), you would do:
        ```python
        spawn_server("serial", {"port": "COM7"})
        ```

        Args:
            transport_type (str): the transport by which the device is connected to the computer on which
                the BonAppetitMaster is running. Examples are "tcp", "udp", or "serial".
            device_info (Dict[str, Any]): additional information required to connect to the device,
                which depends on the transport_type. For example, "tcp" and "udp" connections
                need a dictionary with the keys "ip_address" and "port" defined; while "serial" connections
                need only "port".

        Returns:
            BonAppetitChecked[ServerInfo]
        """
        return send_and_recv_data(
            self._client,
            command=WSMasterCommand.SPAWN_SERVER,
            args=SpawnServerCommandArgs(
                server_ip_address=server_ip_address,
                transport_type=transport_type,
                device_info=device_info,
                enable_sensor_data_logging=enable_sensor_data_logging,
                enable_comms_logging=enable_comms_logging,
            ),
            response_type=SpawnServerResponseData,
            parse_func=lambda data: data.server_uuid,
        )

    def connect_to_existing_server(
        self,
        server_address: str,
        server_port: int,
        master_ip_address: str,
    ) -> BonAppetitChecked[UUID]:
        return send_and_recv_data(
            self._client,
            command=WSMasterCommand.CONNECT_TO_EXISTING_SERVER,
            args=ConnectToExistingServerCommandArgs(
                server_address=server_address,
                server_port=server_port,
                master_ip_address=master_ip_address,
            ),
            response_type=ConnectToExistingServerResponseData,
            parse_func=lambda data: data.server_uuid,
        )

    def kill_server(self, server_uuid: UUID) -> BonAppetitChecked[None]:
        """Tell the BonnAppetitMaster to shut down the websocket server with the given UUID.

        You can find the UUID in the server information returned by a call to `get_active_servers()`.

        Args:
            server_uuid (UUID): the ID of the server to kill.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client,
            args=KillServerCommandArgs(server_uuid),
            command=WSMasterCommand.KILL_SERVER,
        )

    def kill_all_servers(self) -> BonAppetitChecked[None]:
        """Tell the BonAppetitMaster to kill all the servers it is managing.

        Returns:
            BonAppetitChecked[None]
        """
        return send_and_recv_empty_data(
            self._client,
            command=WSMasterCommand.KILL_ALL_SERVERS,
        )

    def wait_for_partially_initialized_server(
        self,
        partially_initialized_server_uuid: UUID,
        timeout: float,
    ) -> BonAppetitChecked[ServerInfo]:
        """
        Spawning or Connecting to a server returns immediately, but server connection will still be
        partially initialized. This helper wraps the wait+polling into a one-liner
        """
        start_time = time.time()
        first_check = True
        poll_rate = Rate(1)
        while True:
            ConsoleLogger.get().info(
                f"Waiting for server [{partially_initialized_server_uuid.hex[0:8]}] to be fully initialized..."
            )
            if time.time() - start_time > timeout:
                return ch.bad(
                    BonAppetitCode.SERVER_TIMEOUT,
                    message="Server still in partially initialized state",
                )

            maybe_active_servers = self.get_active_servers()
            if maybe_active_servers.has_error():
                return ch.fwd_err(maybe_active_servers)

            server_of_interest = next(
                (
                    ii
                    for ii in maybe_active_servers.value()
                    if ii.uuid == partially_initialized_server_uuid
                ),
                None,
            )
            if server_of_interest is None:
                if first_check:
                    return ch.bad(
                        BonAppetitCode.USER_ERROR,
                        message="Server UUID was not found in active server list. Either server was never started, or it disconnected sometime after the last time this UUID was valid",
                    )

                return ch.bad(
                    BonAppetitCode.USER_ERROR,
                    message="Server UUID no longer in active server list, but was valid before. This means that the Master has given up on connecting to this server",
                )

            if isinstance(server_of_interest, ServerInfo):
                return ch.ok(server_of_interest)

            poll_rate.sleep()
