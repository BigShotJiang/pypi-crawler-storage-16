"""All messages and responses that can be sent between the BonAppetitMasterClient and the BonAppetitMaster,
or the BonAppetitMaster and the BonAppetitServer.
"""

import dataclasses
import datetime
import enum
from typing import Any, Dict, List, Optional, Union, Sequence
from uuid import UUID

import dataclasses_json

from forcen_public_utils.version import Version
from forcen_bonappetit_api.common.error_types import BonAppetitCode

class WSMasterCommand(str, enum.Enum):
    GET_DETECTED_DEVICES = "get_detected_devices"
    GET_ACTIVE_SERVERS = "get_active_servers"
    SPAWN_SERVER = "spawn_server"
    CONNECT_TO_EXISTING_SERVER = "connect_to_existing_server"
    KILL_SERVER = "kill_server"
    KILL_ALL_SERVERS = "kill_all_servers"


@dataclasses.dataclass
class DetectedSerialDevice(dataclasses_json.DataClassJsonMixin):
    port: str


@dataclasses.dataclass
class WebsocketConnectionInfo:
    ip_address: str
    server_port: int
    publisher_port: int


@dataclasses.dataclass
class _PartialServerInfoTag: pass


@dataclasses.dataclass
class PartialServerInfo(dataclasses_json.DataClassJsonMixin):
    uuid: UUID
    device_transport_type: Optional[str] = None
    device_connection_info: Optional[Dict[str, Any]] = None
    ip_address: Optional[str] = None
    commands_srv_port: Optional[int] = None

    # This makes this class deserialize properly when in a union by making it unique
    _partial_server_info_tag: _PartialServerInfoTag = dataclasses.field(default_factory=_PartialServerInfoTag)

@dataclasses.dataclass
class _ServerInfoTag: pass

@dataclasses.dataclass
class ServerInfo(dataclasses_json.DataClassJsonMixin):
    uuid: UUID
    device_transport_type: str
    device_connection_info: Dict[str, Any]
    ip_address: str
    commands_srv_port: int
    sensor_data_pub_port: int
    errors_pub_port: int
    replies_pub_port: int
    server_version: Version

    # This makes this class deserialize properly when in a union by making it unique
    _server_info_tag: _ServerInfoTag = dataclasses.field(default_factory=_ServerInfoTag)


@dataclasses.dataclass
class ServerInfoWithError(dataclasses_json.DataClassJsonMixin):
    info: Union[ServerInfo, PartialServerInfo]
    code: BonAppetitCode
    message: str

@dataclasses.dataclass
class GetDetectedDevicesCommandArgs(dataclasses_json.DataClassJsonMixin):
    rerun_detection: bool


@dataclasses.dataclass
class GetDetectedDevicesResponseData(dataclasses_json.DataClassJsonMixin):
    serial_devices: List[DetectedSerialDevice]


@dataclasses.dataclass
class SpawnServerCommandArgs(dataclasses_json.DataClassJsonMixin):
    server_ip_address: str
    transport_type: str
    device_info: Dict[str, Any]
    enable_sensor_data_logging: bool
    enable_comms_logging: bool


@dataclasses.dataclass
class SpawnServerResponseData(dataclasses_json.DataClassJsonMixin):
    server_uuid: UUID


@dataclasses.dataclass
class ConnectToExistingServerCommandArgs(dataclasses_json.DataClassJsonMixin):
    server_address: str
    server_port: int
    master_ip_address: str = "localhost"  # must be ipv4 addr if master/server not on same device


@dataclasses.dataclass
class ConnectToExistingServerResponseData(dataclasses_json.DataClassJsonMixin):
    server_uuid: UUID



@dataclasses.dataclass
class KillServerCommandArgs(dataclasses_json.DataClassJsonMixin):
    server_uuid: UUID
    kill_timeout: float = 5.0


@dataclasses.dataclass
class KillServerResponseData(dataclasses_json.DataClassJsonMixin):
    pass


@dataclasses.dataclass
class KillAllServersCommandArgs(dataclasses_json.DataClassJsonMixin):
    kill_timeout_per_server: float = 5.0


@dataclasses.dataclass
class KillAllServerResponseData(dataclasses_json.DataClassJsonMixin):
    pass


@dataclasses.dataclass
class HeartbeatCommandArgs(dataclasses_json.DataClassJsonMixin):
    server_info: ServerInfo
    timestamp: datetime.datetime


@dataclasses.dataclass
class HeartbeatResponseData(dataclasses_json.DataClassJsonMixin):
    timestamp: datetime.datetime
    disconnect_request: bool


@dataclasses.dataclass
class GetActiveServersCommandArgs(dataclasses_json.DataClassJsonMixin):
    pass


@dataclasses.dataclass
class GetActiveServersResponseData(dataclasses_json.DataClassJsonMixin):
    servers: Sequence[Union[ServerInfo, PartialServerInfo]]
