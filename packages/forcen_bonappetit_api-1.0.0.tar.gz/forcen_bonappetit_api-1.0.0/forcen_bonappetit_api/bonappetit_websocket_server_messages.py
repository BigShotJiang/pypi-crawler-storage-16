"""All messages that can be sent between the BonAppetitClient and the BonAppetitServer.

These dataclasses capture the Forcen Websocket Protocol. 

Transmission dataclasses:
- Typical data sent from the Client -> Server is captured by the `DetailedCommand` dataclass
- Typical data sent from Server -> Client is captured by the `TaggedResponse` dataclass
- Both dataclasses are (de)serialized to json (before)after transmission

Each specific command can have arguments
- Some commands have no arguments. For these, the corresponding field is left as an empty dict
- For any command that has 1 or more args, a ...CommandArgs dataclass exist"
- These can be easily (de)serialized to json, or to python dict as needed
- For commands with only 1 arg, this may seem extraneous, but it's necessary for writing 
generic and consistent encoding/decoding code on the server/client side. Otherwise, keys would have
to be synced between the server and client manually (hardcode twice) 
"""

import dataclasses
import enum
from typing import Any, Dict, List, Optional, Union

import dataclasses_json

import forcen_bonappetit_api.protocol.protocol_data_types as pdt
from forcen_bonappetit_api.bonappetit_user_script_encoder import (
    BonappetitUserScriptEncoderResultNoPassword,
)
from forcen_bonappetit_api.protocol.protocol_transport_types import ReplyPacketStamped
from forcen_bonappetit_api.common.error_types import BonAppetitCode


class WSServerCommand(str, enum.Enum):
    GET_WS_SERVER_VERSION = "get_ws_server_version"
    ADD_UDP_SENSOR_DATA_CONN = "add_udp_sensor_data_conn"
    GET_FIMRWARE_VERSION = "get_firmware_version"
    GET_SERIAL_NUMBER = "get_serial_number"
    GET_EEPROM_WRITE_COUNT = "get_eeprom_write_count"
    GET_TRANSPORT_CONNECTION_INFO = "get_transport_connection_info"
    GET_TEMPERATURE = "get_temperature"
    GET_ADC_OVERSAMPLE_RATIO = "get_adc_osr"
    GET_ADC_GAIN = "get_adc_gain"
    SET_ADC_GAIN = "set_adc_gain"
    GET_ADC_ENABLED_CHANNELS = "get_adc_enabled_channels"
    SET_ADC_ENABLED_CHANNELS = "set_adc_enabled_channels"
    GET_ADC_DIGIPOT = "get_adc_digipot"
    SET_ADC_DIGIPOT = "set_adc_digipot"
    GET_ADC_CALIBRATION_CONSTANT = "get_adc_calibration_constant"
    SET_ADC_CALIBRATION_CONSTANT = "set_adc_calibration_constant"
    SAVE_ADC_CALIBRATION_CONSTANTS = "save_adc_calibration_constants"
    GET_ADC_SENSOR_OUTPUT_MODEL = "get_adc_sensor_output_model"
    SET_ADC_SENSOR_OUTPUT_MODEL = "set_adc_sensor_output_model"
    UNLOCK_RESTRICTED_FUNCTIONS = "unlock_restricted_functions"
    SET_ACCESS_LOCK = "set_access_lock"
    RESET_ACCESS_LOCK = "reset_access_lock"
    GET_MODE = "get_mode"
    SET_MODE = "set_mode"
    GET_PERIPHERAL_TYPE = "get_peripheral_type"
    SET_PERIPHERAL_TYPE = "set_peripheral_type"
    GET_USB_ON_BOOT_DELAY = "get_usb_on_boot_delay"
    SET_USB_ON_BOOT_DELAY = "set_usb_on_boot_delay"
    GET_UART_BAUD_RATE = "get_uart_baud_rate"
    SET_UART_BAUD_RATE = "set_uart_baud_rate"
    GET_UART_PARITY = "get_uart_parity"
    SET_UART_PARITY = "set_uart_parity"
    GET_UART_STOP_BITS = "get_uart_stop_bits"
    SET_UART_STOP_BITS = "set_uart_stop_bits"
    GET_CAN_NODE_ID = "get_can_node_id"
    SET_CAN_NODE_ID = "set_can_node_id"
    GET_CAN_BAUD_RATE = "get_can_baud_rate"
    SET_CAN_BAUD_RATE = "set_can_baud_rate"
    GET_DATA_RATE = "get_data_rate"
    SET_DATA_RATE = "set_data_rate"
    GET_LED_DATA = "get_led_data"
    SET_LED_TO_EVENTS = "set_led_to_events"
    SET_LED_BRIGHTNESS = "set_led_brightness"
    GET_USER_CONSTANT = "get_user_constant"
    SET_USER_CONSTANT = "set_user_constant"
    LOAD_USER_CONSTANT = "load_user_constant"
    RESET_COMMUNICATION = "reset_communication"
    RESET_MODULE = "reset_module"
    FACTORY_RESET = "factory_reset"
    GET_ADC_DOWNSAMPLE_FACTOR = "get_adc_downsample_factor"
    SET_ADC_DOWNSAMPLE_FACTOR = "set_adc_downsample_factor"
    GET_IS_TEMPERATURE_COMPENSATION_ENABLED = "get_is_temperature_compensation_enabled"
    SET_IS_TEMPERATURE_COMPENSATION_ENABLED = "set_temperature_compensation_enabled"
    DISABLE_USB_ON_BOOT = "disable_usb_on_boot"
    GET_TARE_STATUS = "get_tare_status"
    GET_SELECTED_OUTPUT_STREAM = "get_selected_output_stream"
    SET_SELECTED_OUTPUT_STREAM = "set_selected_output_stream"
    GET_HARDWARE_ERROR = "get_hardware_error"
    CLEAR_HARDWARE_ERROR = "clear_hardware_error"
    GET_RUNTIME_DEVICE_ERROR = "get_runtime_device_error"
    ENTER_BOOT_MODE = "enter_boot_mode"
    GET_IP_ADDRESS = "get_ip_address"
    SET_IP_ADDRESS = "set_ip_address"
    GET_NETMASK = "get_netmask"
    SET_NETMASK = "set_netmask"
    GET_NETWORK_GATEWAY = "get_network_gateway"
    SET_NETWORK_GATEWAY = "set_network_gateway"
    GET_MAC_ADDRESS = "get_mac_address"
    SET_MAC_ADDRESS = "set_mac_address"
    GET_IMU_DATA_STYLE = "get_imu_data_style"
    SET_IMU_DATA_STYLE = "set_imu_data_style"
    GET_SENSOR_DATA_FRAME = "get_sensor_data_frame"
    SEND_RAW_PACKET_UNCHECKED_UNSAFE = "send_raw_packet_unchecked_unsafe"
    SET_USER_SCRIPT_UNCHECKED_UNSAFE = "set_user_script_unchecked_unsafe"

    # This command is only to be used by the master to synchronize with a server
    # NOTE (swapnil) - this being "public" isn't ideal, since a typical user shouldn't be calling
    # this at all, but the risk is minimal. An already Master-connected-server will just reject any
    # calls to this.
    INTERNAL_MASTER_CONNECT_REQUEST_ = "internal_master_connect_request_"
    INTERNAL_SELF_MONITOR_PING_ = "internal_self_monitor_ping_"


@dataclasses.dataclass
class GetWSServerVersionResponseData(dataclasses_json.DataClassJsonMixin):
    version: str


@dataclasses.dataclass
class SensorData(dataclasses_json.DataClassJsonMixin):
    data: List[Union[int, float]]
    timestamp: float


@dataclasses.dataclass
class SensorDataList(dataclasses_json.DataClassJsonMixin):
    frames: List[SensorData]


@dataclasses.dataclass
class WSServerError(dataclasses_json.DataClassJsonMixin):
    code: BonAppetitCode
    msg: str


@dataclasses.dataclass
class ReplyData(dataclasses_json.DataClassJsonMixin):
    reply: ReplyPacketStamped


@dataclasses.dataclass
class AddUdpSensorDataConnCommandArgs(dataclasses_json.DataClassJsonMixin):
    ip_address: str
    port: int


@dataclasses.dataclass
class AddUdpSensorDataConnResponseData(dataclasses_json.DataClassJsonMixin):
    ip_address: str
    port: int


@dataclasses.dataclass
class GetFirmwareVersionResponseData(dataclasses_json.DataClassJsonMixin):
    firmware_version: str


@dataclasses.dataclass
class GetSerialNumberResponseData(dataclasses_json.DataClassJsonMixin):
    serial_number: str


@dataclasses.dataclass
class GetEEPROMWriteCountResponseData(dataclasses_json.DataClassJsonMixin):
    eeprom_write_count: int


@dataclasses.dataclass
class GetTransportConnInfoResponseData(dataclasses_json.DataClassJsonMixin):
    transport_type: str
    conn_info: Dict[str, Any]


@dataclasses.dataclass
class GetTemperatureResponseData(dataclasses_json.DataClassJsonMixin):
    temperature: float


@dataclasses.dataclass
class GetADCOversamplingRatioResponseData(dataclasses_json.DataClassJsonMixin):
    adc_oversampling_ratio: pdt.ADCOverSamplingRatio


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class GetADCGainResponseData(dataclasses_json.DataClassJsonMixin):
    adc_gain: pdt.ADCGain


@dataclasses.dataclass
class SetADCGainCommandArgs(dataclasses_json.DataClassJsonMixin):
    adc_gain: pdt.ADCGain


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class GetADCEnabledChannelsResponseData(dataclasses_json.DataClassJsonMixin):
    adc_enabled_channels: List[pdt.ADCChannel]


@dataclasses.dataclass
class SetADCEnabledChannelsCommandArgs(dataclasses_json.DataClassJsonMixin):
    adc_enabled_channels: List[pdt.ADCChannel]


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class GetADCDigipotCommandArgs(dataclasses_json.DataClassJsonMixin):
    adc_digitpot_index: int


@dataclasses.dataclass
class ADCDigipotValue(dataclasses_json.DataClassJsonMixin):
    index: int
    value: int


@dataclasses.dataclass
class GetADCDigipotResponseData(dataclasses_json.DataClassJsonMixin):
    adc_digipot: ADCDigipotValue


@dataclasses.dataclass
class SetADCDigipotCommandArgs(dataclasses_json.DataClassJsonMixin):
    adc_digitpot: ADCDigipotValue


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class GetADCCalibrationConstantCommandArgs(dataclasses_json.DataClassJsonMixin):
    calibration_constant: pdt.CalibrationConstant


@dataclasses.dataclass
class CalibConstantValue(dataclasses_json.DataClassJsonMixin):
    constant: pdt.CalibrationConstant
    float_value: str


@dataclasses.dataclass
class GetADCCalibrationConstantResponseData(dataclasses_json.DataClassJsonMixin):
    calibration_constant: CalibConstantValue


@dataclasses.dataclass
class SetADCCalibConstantCommandArgs(dataclasses_json.DataClassJsonMixin):
    calibration_constant: CalibConstantValue


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class GetADCSensorOutputModelResponseData(dataclasses_json.DataClassJsonMixin):
    adc_sensor_output_model: pdt.SensorOutputModel


@dataclasses.dataclass
class SetADCSensorOutputModelCommandArgs(dataclasses_json.DataClassJsonMixin):
    adc_sensor_output_model: pdt.SensorOutputModel


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class SetAccessLockCommandArgs(dataclasses_json.DataClassJsonMixin):
    access_lock_value_as_hex: str


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class GetModeResponseData(dataclasses_json.DataClassJsonMixin):
    device_mode: pdt.DeviceMode


@dataclasses.dataclass
class SetModeCommandArgs(dataclasses_json.DataClassJsonMixin):
    device_mode: pdt.DeviceMode


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class GetPeripheralTypeResponseData(dataclasses_json.DataClassJsonMixin):
    peripheral_type: pdt.PeripheralType


@dataclasses.dataclass
class SetPeripheralTypeCommandArgs(dataclasses_json.DataClassJsonMixin):
    peripheral_type: pdt.PeripheralType


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class GetUSBOnBootDelayResponseData(dataclasses_json.DataClassJsonMixin):
    usb_on_boot_delay_in_ms: int


@dataclasses.dataclass
class SetUSBOnBootDelayCommandArgs(dataclasses_json.DataClassJsonMixin):
    usb_on_boot_delay_in_ms: int


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class GetUartBaudRateResponseData(dataclasses_json.DataClassJsonMixin):
    uart_baud_rate: int


@dataclasses.dataclass
class SetUartBaudRateCommandArgs(dataclasses_json.DataClassJsonMixin):
    uart_baud_rate: pdt.UartBaudRate


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class GetUartParityResponseData(dataclasses_json.DataClassJsonMixin):
    uart_parity: pdt.UartParity


@dataclasses.dataclass
class SetUartParityCommandArgs(dataclasses_json.DataClassJsonMixin):
    uart_parity: pdt.UartParity


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class GetUartStopbitsResponseData(dataclasses_json.DataClassJsonMixin):
    uart_stopbits: pdt.UartStopbits


@dataclasses.dataclass
class SetUartStopbitsCommandArgs(dataclasses_json.DataClassJsonMixin):
    uart_stopbits: pdt.UartStopbits


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class GetCANNodeIDResponseData(dataclasses_json.DataClassJsonMixin):
    can_node_id: int


@dataclasses.dataclass
class SetCANNodeIDCommandArgs(dataclasses_json.DataClassJsonMixin):
    can_node_id: pdt.CanNodeID


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class GetCANBaudRateReponseData(dataclasses_json.DataClassJsonMixin):
    can_baud_rate: pdt.CanBaudRate


@dataclasses.dataclass
class SetCANBaudRateCommandArgs(dataclasses_json.DataClassJsonMixin):
    can_baud_rate: pdt.CanBaudRate


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class GetDataRateResponseData(dataclasses_json.DataClassJsonMixin):
    adc_data_rate_hz: int


@dataclasses.dataclass
class SetDataRateCommandArgs(dataclasses_json.DataClassJsonMixin):
    adc_data_rate_hz: int


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class GetLedDataResponseData(dataclasses_json.DataClassJsonMixin):
    led_data: pdt.LedData


@dataclasses.dataclass
class SetLedBrightnessCommandArgs(dataclasses_json.DataClassJsonMixin):
    led_brightness: int


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class GetUserConstantCommandArgs(dataclasses_json.DataClassJsonMixin):
    user_constant_index: int


@dataclasses.dataclass
class UserConstantValue(dataclasses_json.DataClassJsonMixin):
    index: int
    float_value: str


@dataclasses.dataclass
class GetUserConstantResponseData(dataclasses_json.DataClassJsonMixin):
    user_constant: UserConstantValue


@dataclasses.dataclass
class SetUserConstantCommandArgs(dataclasses_json.DataClassJsonMixin):
    user_constant: UserConstantValue


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class GetADCDownsampleFactorResponseData(dataclasses_json.DataClassJsonMixin):
    downsampling_factor: int


@dataclasses.dataclass
class SetADCDownsampleFactorCommandArgs(dataclasses_json.DataClassJsonMixin):
    downsampling_factor: int


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class GetIsTemperatureCompensationEnabledResponseData(dataclasses_json.DataClassJsonMixin):
    enabled: bool


@dataclasses.dataclass
class SetIsTemperatureCompensationEnabledCommandArgs(dataclasses_json.DataClassJsonMixin):
    enabled: bool


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class GetTareStatusResponseData(dataclasses_json.DataClassJsonMixin):
    status: pdt.TareStatus


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class GetSelectedOutputDataStreamResponseData(dataclasses_json.DataClassJsonMixin):
    sensor_data_output_modes: List[pdt.SelectedOutputDataStream]


@dataclasses.dataclass
class SetSelectedOutputDataStreamCommandArgs(dataclasses_json.DataClassJsonMixin):
    sensor_data_output_modes: List[pdt.SelectedOutputDataStream]


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class GetHardwareErrorResponseData(dataclasses_json.DataClassJsonMixin):
    code: pdt.HardwareErrorCode


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class GetRuntimeDeviceErrorCommandArgs(dataclasses_json.DataClassJsonMixin):
    register: int = 0


@dataclasses.dataclass
class GetRuntimeDeviceErrorResponseData(dataclasses_json.DataClassJsonMixin):
    codes: List[pdt.RuntimeDeviceErrorCode]


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class GetIPAddressResponseData(dataclasses_json.DataClassJsonMixin):
    ipv4: str


@dataclasses.dataclass
class SetIPAddressCommandArgs(dataclasses_json.DataClassJsonMixin):
    ipv4: str


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class GetNetmaskResponseData(dataclasses_json.DataClassJsonMixin):
    netmask: str


@dataclasses.dataclass
class SetNetmaskCommandArgs(dataclasses_json.DataClassJsonMixin):
    netmask: str


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class GetGatewayResponseData(dataclasses_json.DataClassJsonMixin):
    gateway: str


@dataclasses.dataclass
class SetGatewayCommandArgs(dataclasses_json.DataClassJsonMixin):
    gateway: str


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class GetMacAddressResponseData(dataclasses_json.DataClassJsonMixin):
    mac_address_48: str


@dataclasses.dataclass
class SetMacAddressCommandArgs(dataclasses_json.DataClassJsonMixin):
    mac_address_48: str


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class GetImuDataStyleResponseData(dataclasses_json.DataClassJsonMixin):
    imu_data_style: pdt.ImuDataStyle


@dataclasses.dataclass
class SetImuDataStyleCommandArgs(dataclasses_json.DataClassJsonMixin):
    imu_data_style: pdt.ImuDataStyle


# --------------------------------------------------------------------------------------------------


@dataclasses.dataclass
class SendRawPacketUncheckedUnsafeCommandArgs(dataclasses_json.DataClassJsonMixin):
    transport_packet: str
    kill_server_debug_unsafe: bool = False
    kill_udp_sensor_data_publishers_unsafe: bool = False


@dataclasses.dataclass
class SendRawPacketUncheckedUnsafeResponseData(dataclasses_json.DataClassJsonMixin):
    reply_packet_stamped: ReplyPacketStamped


@dataclasses.dataclass
class SetUserScriptUncheckedUnsafeCommandArgs(dataclasses_json.DataClassJsonMixin):
    encrypted_script: Optional[BonappetitUserScriptEncoderResultNoPassword]
