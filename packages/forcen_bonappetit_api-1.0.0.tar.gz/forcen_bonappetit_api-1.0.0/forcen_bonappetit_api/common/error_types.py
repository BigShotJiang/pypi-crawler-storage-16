from typing import TypeVar
import enum

import forcen_public_utils.checked as ch
from forcen_public_utils.json_dataclasses_enum import patch_json_dataclass_enum_encoder


@patch_json_dataclass_enum_encoder
@enum.unique
class BonAppetitCode(enum.Enum):
    """
    This enum should only contain the minimum number of codes that are meaningful to higher levels
    of abstraction. Anything only meant for human eyes shouldn't be part of this enum.
    """

    # 1000 series errors:
    # Typical user errors, bad args, invalid command in current state, unsupported, etc
    # These errors are expected to be common as a user interacts with the system
    # They don't indicate any serious issue with the system
    USER_ERROR = 1001  # bad input value or combo (detected by driver, not device)
    REQUEST_FAILED = 1002  # device returned failure for request/call
    UNSUPPORTED = 1003  # function not supported by current device, protocol or peripheral
    EXCEPTION_RAISED = 1004  # The function handler threw an exception. Severity unknown

    # 2000 series errors:
    # Communication related issues, (de)serialization issues, timeouts, heartbeat failures, etc
    # These typically indicate that something is broken and likely requires the user to fix it
    TRANSPORT_ERROR = 2001  # connection to device failure, errors from peripheral libraries
    PACKET_ERROR = 2002  # packet parsing errors, checksum errors
    SERVER_TIMEOUT = 2003  # timeout between websocket server and client
    SERVER_DISCONNECT = 2004  # websocket server/client connection error
    SENSOR_DATA_SOCKET_ERROR = 2005  # socket for sensor data streaming is dead, will retry
    SENSOR_DATA_SOCKET_FATAL = 2006  # socket for sensor data streaming is data, won't retry

    # 9000 series errors:
    # These are critical errors, bugs, oversights and unhandled edgecases, etc.
    # These are likely unrecoverable by the user, and they should contact Forcen
    INTERNAL_FATAL = 9000  # unknown error, unhandled case, unrecoverable/impossible state
    SYSTEM_SHUTDOWN = 9001  # system got request while already in process of shutting down


_T = TypeVar("_T")

BonAppetitChecked = ch.Checked[_T, BonAppetitCode]
