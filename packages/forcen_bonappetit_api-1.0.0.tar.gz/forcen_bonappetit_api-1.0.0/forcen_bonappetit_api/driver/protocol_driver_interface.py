from uuid import UUID
from typing import Protocol, Set, Callable, Optional, List

from forcen_bonappetit_api.bonappetit_user_script_encoder import (
    BonappetitUserScriptEncoderResultNoPassword,
)
from forcen_bonappetit_api.common.error_types import BonAppetitChecked, BonAppetitCode
from forcen_bonappetit_api.protocol.protocol_data_types import (
    ADCChannel,
    ADCGain,
    ADCOverSamplingRatio,
    CalibrationConstant,
    CanBaudRate,
    CanNodeID,
    DeviceMode,
    ForcenProtocolVersion,
    HardwareErrorCode,
    ImuDataStyle,
    LedData,
    PeripheralType,
    RuntimeDeviceErrorCode,
    SelectedOutputDataStream,
    SensorOutputModel,
    TareStatus,
    UartBaudRate,
    UartParity,
    UartStopbits,
)
from forcen_bonappetit_api.protocol.protocol_transport_types import (
    SendTransportPacket,
    PacketStamped,
    ReplyPacketStamped,
    RTDPacketStamped,
)
from forcen_bonappetit_api.transport.transport_types import TransportConnectionInfo
from forcen_public_utils.math_types import UInt8, UInt32
from forcen_public_utils.ip_address import IPv4, MacAddr48
from forcen_public_utils.sync_queue import SyncQueue
import forcen_public_utils.checked as ch


RTDQueueT = SyncQueue[RTDPacketStamped]
ReplyQueueT = SyncQueue[ReplyPacketStamped]
MixedQueueT = SyncQueue[PacketStamped]
ErrorQueueT = SyncQueue[ch.FullError[BonAppetitCode]]
RTDCallbackT = Callable[[List[RTDPacketStamped]], None]
ReplyCallbackT = Callable[[ReplyPacketStamped], None]
MixedCallbackT = Callable[[PacketStamped], None]
ErrorCallbackT = Callable[[ch.FullError[BonAppetitCode]], None]


class ProtocolDriverInterface(Protocol):

    # Contex Management
    # -----------------
    def __enter__(self) -> "ProtocolDriverInterface": ...

    def __exit__(self, exception_type, exception_value, exception_traceback) -> None: ...

    def stop(self) -> None: ...

    # Transport Interface
    # -------------------

    def get_transport_connection_info(self) -> BonAppetitChecked[TransportConnectionInfo]: ...

    def send_raw_packet_unchecked_unsafe(
        self, packet: SendTransportPacket
    ) -> BonAppetitChecked[ReplyPacketStamped]: ...

    def set_process_function_from_raw_script_unchecked_unsafe(
        self, 
        encrypted_user_script: Optional[BonappetitUserScriptEncoderResultNoPassword],
    ) -> BonAppetitChecked[None]: ...

    # Data collection and subscription
    # --------------------------------

    def attach_sensor_data_callback(self, callback: RTDCallbackT, realtime_stream: bool = False) -> BonAppetitChecked[None]: ...

    def attach_reply_callback(self, callback: ReplyCallbackT) -> BonAppetitChecked[None]: ...

    def attach_callback_for_everything(
        self, callback: MixedCallbackT
    ) -> BonAppetitChecked[None]: ...

    def attach_error_callback(self, callback: ErrorCallbackT) -> BonAppetitChecked[None]: ...

    def subscribe_to_sensor_packets(
        self,
        max_buffer_size: int,
        realtime_stream: bool = False,
    ) -> BonAppetitChecked[RTDQueueT]: ...

    def subscribe_to_reply_packets(
        self, max_buffer_size: int
    ) -> BonAppetitChecked[ReplyQueueT]: ...

    def subscribe_to_all_packets(self, max_buffer_size: int) -> BonAppetitChecked[MixedQueueT]: ...

    def subscribe_to_errors(self, max_buffer_size: int) -> BonAppetitChecked[ErrorQueueT]: ...

    # Heartbeat Checking
    # ------------------
    def heartbeat_fire_and_forget(self) -> BonAppetitChecked[List[ReplyPacketStamped]]: ...

    def is_heartbeat_reply(self, data: ReplyPacketStamped) -> bool: ...

    # Devices with Firmware version and Serial Numbers
    # ------------------------------------------------

    def get_firmware_version(self) -> BonAppetitChecked[ForcenProtocolVersion]: ...

    def get_serial_number(self) -> BonAppetitChecked[str]: ...

    # Devices with an exposed EEPROM
    # ------------------------------

    def get_eeprom_write_count(self) -> BonAppetitChecked[int]: ...

    # Devices with a modifiable device mode
    # -------------------------------------

    def get_mode(self) -> BonAppetitChecked[DeviceMode]: ...

    def set_mode(self, device_mode: DeviceMode) -> BonAppetitChecked[None]: ...

    # Devices with Device Info
    # ------------------------

    # (swapnil) - is this duplicated by get_adc_sensor_output_model?
    # (Adan) - let's keep this for now: it makes sense to have this for devices which don't have a
    #          modifiable ADC (e.g. CLHub)
    # (swapnil) - sorry, i started to remove this before seeing this note. Commenting out for now
    # def get_device_model(self) -> BonAppetitChecked[SensorOutputModel]: ...

    # def get_device_type(self) -> BonAppetitChecked[str]: ...

    # Devices with requestable sensor data
    # ----------------------------------

    def get_sensor_data_frame(self) -> BonAppetitChecked[None]: ...

    # Devices with a settable data rate
    # ---------------------------------

    def get_data_rate(self) -> BonAppetitChecked[int]: ...

    def set_data_rate(self, data_rate_hz: int) -> BonAppetitChecked[None]: ...

    # Devices with LEDs
    # -----------------
    def get_led_data(self) -> BonAppetitChecked[LedData]: ...

    def set_led_to_events(self) -> BonAppetitChecked[None]: ...

    def set_led_brightness(self, value: int) -> BonAppetitChecked[None]: ...

    # Devices with temperature sensors
    # --------------------------------

    def get_temperature(self) -> BonAppetitChecked[float]: ...

    # NOTE: The following are for BEv7.3.x

    def get_temperature_compensation_enabled(
        self,
    ) -> BonAppetitChecked[bool]: ...

    def set_temperature_compensation_enabled(
        self,
        temperature_compensation_mode: int,
    ) -> BonAppetitChecked[None]: ...

    # Devices with ADCs
    # -----------------

    def get_adc_oversampling_ratio(self) -> BonAppetitChecked[ADCOverSamplingRatio]: ...

    def get_adc_gain(self) -> BonAppetitChecked[ADCGain]: ...

    def set_adc_gain(self, adc_gain: ADCGain) -> BonAppetitChecked[None]: ...

    def get_enabled_adc_channels(self) -> BonAppetitChecked[Set[ADCChannel]]: ...

    def set_enabled_adc_channels(
        self, adc_channels: Set[ADCChannel]
    ) -> BonAppetitChecked[None]: ...

    def get_adc_digipot(self, channel: int) -> BonAppetitChecked[UInt8]: ...

    def set_adc_digipot(self, channel: int, value: UInt8) -> BonAppetitChecked[None]: ...

    def get_adc_calibration_constant(
        self, constant: CalibrationConstant
    ) -> BonAppetitChecked[float]: ...

    def set_adc_calibration_constant(
        self, constant: CalibrationConstant, float_value: str
    ) -> BonAppetitChecked[None]: ...

    def get_adc_sensor_output_model(self) -> BonAppetitChecked[SensorOutputModel]: ...

    def set_adc_sensor_output_model(
        self, sensor_output_model: SensorOutputModel
    ) -> BonAppetitChecked[None]: ...

    # NOTE: These are for BEv7.3.x

    def get_adc_downsample_factor(self) -> BonAppetitChecked[int]: ...

    def set_adc_downsample_factor(self, downsampling_factor: int) -> BonAppetitChecked[None]: ...

    # Devices with access locks
    # -------------------------

    def unlock_restricted_functions(self) -> BonAppetitChecked[None]: ...

    def set_access_lock(self, value_as_hex: str) -> BonAppetitChecked[None]: ...

    def reset_access_lock(self) -> BonAppetitChecked[None]: ...

    # Devices with additional peripheral modes
    # ----------------------------------------

    def set_peripheral_type(self, peripheral_type: PeripheralType) -> BonAppetitChecked[None]: ...

    def get_peripheral_type(self) -> BonAppetitChecked[PeripheralType]: ...

    # Devices with USB on Boot
    # ------------------------

    def get_usb_on_boot_delay(self) -> BonAppetitChecked[int]: ...

    def set_usb_on_boot_delay(self, delay_in_ms: UInt32) -> BonAppetitChecked[None]: ...

    # NOTE: These were added in BEv7.3.x

    def disable_usb_on_boot(self) -> BonAppetitChecked[None]: ...

    # Devices with UART
    # -----------------

    def get_uart_baud_rate(self) -> BonAppetitChecked[UartBaudRate]: ...

    def set_uart_baud_rate(self, baud_rate: UartBaudRate) -> BonAppetitChecked[None]: ...

    def get_uart_parity(self) -> BonAppetitChecked[UartParity]: ...

    def set_uart_parity(self, parity: UartParity) -> BonAppetitChecked[None]: ...

    def get_uart_stopbits(self) -> BonAppetitChecked[UartStopbits]: ...

    def set_uart_stopbits(self, stopbits: UartStopbits) -> BonAppetitChecked[None]: ...

    # Devices with CAN
    # ----------------

    def get_can_node_id(self) -> BonAppetitChecked[CanNodeID]: ...

    def set_can_node_id(self, node_id: CanNodeID) -> BonAppetitChecked[None]: ...

    def get_can_baud_rate(self) -> BonAppetitChecked[CanBaudRate]: ...

    def set_can_baud_rate(self, baud_rate: CanBaudRate) -> BonAppetitChecked[None]: ...

    # Devices with Calibration / Taring
    # ---------------------------------

    def continue_calibration(self) -> BonAppetitChecked[None]: ...

    def calibration_set_num_samples(self, num_samples: UInt32) -> BonAppetitChecked[None]: ...

    def save_all_from_ram_to_rom(self) -> BonAppetitChecked[None]: ...

    # NOTE: These are for BEv7.3.x and CLv1.2.x

    def get_tare_status(self) -> BonAppetitChecked[TareStatus]: ...

    # NOTE: These were added for CLv1.2.x

    def get_calibration_num_samples(self) -> BonAppetitChecked[UInt32]: ...

    # Devices with user constants
    # ---------------------------

    def get_user_constant(self, register: int) -> BonAppetitChecked[float]: ...

    def set_user_constant(self, register: int, float_value: str) -> BonAppetitChecked[None]: ...

    def load_user_constants(self) -> BonAppetitChecked[None]: ...

    # Devices with soft resets
    # ------------------------

    def reset_communication(self) -> BonAppetitChecked[None]: ...

    def reset_module(self) -> BonAppetitChecked[None]: ...

    def factory_reset(self) -> BonAppetitChecked[None]: ...

    # NOTE: These were added for CLv1.2.x

    def enter_boot_mode(self) -> BonAppetitChecked[None]: ...

    # Devices with selectable output data streams
    # -------------------------------------------

    def get_selected_output_data_stream(
        self,
    ) -> BonAppetitChecked[Set[SelectedOutputDataStream]]: ...

    def select_output_data_stream(
        self,
        sensor_data_output_modes: Set[SelectedOutputDataStream],
    ) -> BonAppetitChecked[None]: ...

    # Devices with Hardware Error codes
    # ---------------------------------

    def get_hardware_error(
        self,
    ) -> BonAppetitChecked[HardwareErrorCode]: ...

    def clear_hardware_error(
        self,
    ) -> BonAppetitChecked[None]: ...

    # Devices with a single runtime error register
    # --------------------------------------------

    def get_runtime_device_error(
        self, register: int = 0
    ) -> BonAppetitChecked[Set[RuntimeDeviceErrorCode]]: ...

    # Devices with IMUs
    # -----------------

    # NOTE: These are for CLv1.2.x

    def get_imu_data_style(self) -> BonAppetitChecked[ImuDataStyle]: ...

    def set_imu_data_style(self, imu_style: ImuDataStyle) -> BonAppetitChecked[None]: ...

    # Devices with Ethernet
    # ---------------------

    # NOTE: These are for CLv1.2.x

    def get_ip_address(self) -> BonAppetitChecked[IPv4]: ...

    def set_ip_address(self, ip_address: IPv4) -> BonAppetitChecked[None]: ...

    def get_netmask(self) -> BonAppetitChecked[IPv4]: ...

    def set_netmask(self, netmask: IPv4) -> BonAppetitChecked[None]: ...

    def get_network_gateway(self) -> BonAppetitChecked[IPv4]: ...

    def set_network_gateway(self, gateway: IPv4) -> BonAppetitChecked[None]: ...

    def get_mac_address(self) -> BonAppetitChecked[MacAddr48]: ...

    def set_mac_address(self, mac_address: MacAddr48) -> BonAppetitChecked[None]: ...
