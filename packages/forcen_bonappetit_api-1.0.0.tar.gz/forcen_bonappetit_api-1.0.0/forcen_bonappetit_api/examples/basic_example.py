import argparse
import os

from forcen_bonappetit_api.bonappetit_websocket_client import BonAppetitClient
from forcen_bonappetit_api.bonappetit_websocket_master_client import (
    BonAppetitMasterClient,
)
from forcen_bonappetit_api.protocol.protocol_data_types import DeviceMode

from forcen_public_utils.loggers.console_logger import ConsoleLogger


def main() -> int:
    console_logger = ConsoleLogger.initialize_comprehensive_logger(
        app_name="basic_example"
    ).get()

    parser = argparse.ArgumentParser("bon_echo_mock_node")
    parser.add_argument(
        "master_ip_address",
        type=str,
        help="IP Address of the Bonappetit Websocket Master",
    )
    parser.add_argument(
        "master_command_port",
        type=int,
        help="Port number that the Bonappetit Websocket Master is listening on",
    )
    parser.add_argument(
        "master_error_port",
        type=int,
        help="Port number that the Bonappetit Websocket Master is listening on",
    )
    parser.add_argument(
        "serial_port",
        type=str,
        help="Serial port number for the sensor",
    )

    args = parser.parse_args()

    console_logger.info(
        f"Connecting client to master at {args.master_ip_address}:{args.master_command_port}"
    )

    with BonAppetitMasterClient(
        master_ip_address=args.master_ip_address,
        master_command_srv_port=args.master_command_port,
        master_error_pub_port=args.master_error_port,
        default_timeout=60,
    ) as master_client:

        # let's kill all existing servers and start clean
        result = master_client.kill_all_servers()
        if result.has_error():
            console_logger.error(
                f"Failed to kill existing servers: {result.error()}"
            )
            return 1

        maybe_active_servers = master_client.get_active_servers()
        if maybe_active_servers.has_error():
            console_logger.error(
                f"Failed to get detected servers: {maybe_active_servers.error()}"
            )
            return 1
        if len(maybe_active_servers.value()) != 0:
            console_logger.error("Failed to kill all servers")
            return 1

        maybe_devices = master_client.get_detected_devices(rerun_detection=True)
        if maybe_devices.has_error():
            console_logger.error(
                f"Failed to get detected devices: {maybe_devices.error()}"
            )
            return 1

        device_matched = any(
            device.port == args.serial_port for device in maybe_devices.value()
        )
        if not device_matched:
            console_logger.error(
                f"No device found at this port {args.serial_port}"
            )
            return 1

        maybe_server_uuid = master_client.spawn_server(
            server_ip_address="localhost",
            transport_type="serial",
            device_info={
                "baudrate": 115200,
                "port": args.serial_port,
            },
            enable_sensor_data_logging=True,
            enable_comms_logging=True,
        )

        if maybe_server_uuid.has_error():
            console_logger.error(
                f"Failed to get uuid of the server: {maybe_server_uuid.error()}"
            )
            return 1

        new_server_uuid = maybe_server_uuid.value()

        maybe_server_info = master_client.wait_for_partially_initialized_server(
            new_server_uuid, 15.0
        )
        if maybe_server_info.has_error():
            console_logger.error(
                f"Failed to get info of the server: {maybe_server_info.error()}"
            )
            return 1

        server_info = maybe_server_info.value()

        with BonAppetitClient(
            server_ip_address=server_info.ip_address,
            server_command_port=server_info.commands_srv_port,
            server_data_pub_port=server_info.sensor_data_pub_port,
            server_error_pub_port=server_info.errors_pub_port,
            server_replies_pub_port=server_info.replies_pub_port,
        ) as client:

            maybe_firmware_version = client.get_firmware_version()
            if maybe_firmware_version.has_error():
                console_logger.error(
                    f"Failed to request firmware version: "
                    f"{maybe_firmware_version.full_error}."
                )
                return 1

            firmware_version = maybe_firmware_version.value()
            console_logger.info(
                f"Connected to sensor version {firmware_version}."
            )

            if client.set_mode(device_mode=DeviceMode.RUNNING).has_error():
                console_logger.error(
                    "Failed to set the device to RUNNING."
                )
                return 1

            maybe_data_queue = client.subscribe_to_sensor_packets(
                max_buffer_size=10, realtime_stream=False
            )
            if not maybe_data_queue or maybe_data_queue.has_error():
                # depends how BonAppetitChecked is implemented; adjust if needed
                err = (
                    maybe_data_queue.full_error()
                    if hasattr(maybe_data_queue, "full_error")
                    else "unknown error"
                )
                console_logger.error(
                    f"Failed to subscribe to sensor data: {err}"
                )
                return 1

            sensor_data_queue = maybe_data_queue.value()
            sensor_data = sensor_data_queue.sync_get_all(timeout=10)
            if sensor_data is None:
                console_logger.error(
                    "No sensor data was received in the Queue before timeout."
                )
                return 1

            console_logger.success(f"Got sensor data: {sensor_data}")

        console_logger.info(f"Killing server with info: {new_server_uuid}")
        master_client.kill_server(new_server_uuid)

    console_logger.info("Closing program")
    return 0


if __name__ == "__main__":
    code = main()
    os._exit(code)  # skips cleanup, kills process immediately
