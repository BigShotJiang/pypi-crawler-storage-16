# Getting Started with Forcenpy

## Verifying everything before scripting

Extract your forcenpy zip folder. In a new terminal window, navigate to the extracted folder and you'll find a bunch of exectuables. 

```bash
username@computer:~/forcenpy/$ ls -la
```

```bash
drwxrwxr-x 3 username username    4096 Jul  3 19:52 .
drwxrwxr-x 8 username username    4096 Jul  3 19:53 ..
-rwxr-xr-x 1 username username 5103600 Jul  3 19:52 ascii_protocol_driver_manual_test
-rwxr-xr-x 1 username username 3475704 Jul  3 19:52 bonappetit_websocket_client_command_line_ui
-rwxr-xr-x 1 username username 3463872 Jul  3 19:52 bonappetit_websocket_client_data_streamer
-rwxr-xr-x 1 username username 3079008 Jul  3 19:52 bon_echo_mock_server
drwxrwxr-x 9 username username    4096 Jul  3 19:52 _internal
-rwxr-xr-x 1 username username 3749808 Jul  3 19:52 run_bonappetit_websocket_master
-rwxr-xr-x 1 username username 3690272 Jul  3 19:52 run_bonappetit_websocket_server
-rwxr-xr-x 1 username username 3810192 Jul  3 19:52 websocket_server_client_longevity_test
```

The main app starts when you execute `run_bonappetit_websocket_master`. Let's run it with `--help` to see what it does

```bash
myusername@mycomputer:~/forcenpy/$ ./run_bonappetit_websocket_master --help
```

```bash
username@computer:~/forcenpy$ ./run_bonappetit_websocket_master --help
PyInstaller/loader/pyimod02_importers.py:419: UserWarning: pkg_resources is deprecated as an API. See https://setuptools.pypa.io/en/latest/pkg_resources.html. The pkg_resources package is slated for removal as early as 2025-11-30. Refrain from using this package or pin to Setuptools<81.
usage: run_bonappetit_websocket_master [-h] [-t] [-d] [--keyboard-interrupt-to-cancel] ip_address command_srv_port error_pub_port

positional arguments:
  ip_address            Websocket IP Address for the master. default is localhost
  command_srv_port      Websocket Port for Commands. Auto-assigns by default
  error_pub_port        Websocket Port for Errors. Auto-assigns by default

options:
  -h, --help            show this help message and exit
  -t, --terse-log       Set the verbosity level of the Console logs to TERSE instead of VERBOSE.
  -d, --debug           Set console logger to comprehensive mode
  --keyboard-interrupt-to-cancel
                        Normally, this script blocks on an 'input' call and ends on 'line break'. Set this to true to avoid stdin capture and just block using sleep
```

It can be run without any args, but you can also specify IP Address and Port. If you're running on LAN, specifying and IP address will be important. Let's run it.

```bash
username@computer:~/forcenpy$ ./run_bonappetit_websocket_master localhost 5656 5657
```

```bash
PyInstaller/loader/pyimod02_importers.py:419: UserWarning: pkg_resources is deprecated as an API. See https://setuptools.pypa.io/en/latest/pkg_resources.html. The pkg_resources package is slated for removal as early as 2025-11-30. Refrain from using this package or pin to Setuptools<81.
2025-07-10 02:06:10.004 | MainThread |   MainProcess (PID-10539) | INFO     | forcen_bonappetit.server.bonappetit_master:_find_serial_devices:374 | Detecting Serial Devices...
2025-07-10 02:06:10.004 | MainThread |   MainProcess (PID-10539) | INFO     | forcen_comm_utils.serial_helpers:get_serial_ports:18 | Looking for serial devices with identifier [{'USB VID:PID=0483:5740'}]
2025-07-10 02:06:10.011 | MainThread |   MainProcess (PID-10539) | INFO     | forcen_bonappetit.server.bonappetit_master:__init__:148 | Creating master websocket server...
2025-07-10 02:06:10.012 | MainThread |   MainProcess (PID-10539) | INFO     | forcen_bonappetit.server.bonappetit_master:__init__:174 | Creating heartbeat monitoring thread...
BonAppetitMaster is online at port [5656]. Press <ENTER> to stop...
2025-07-10 02:06:10.013 | MainThread |   MainProcess (PID-10539) | INFO     | forcen_websockets.websocket_sync_server:__init__:49 | master_ws_error_pub_thread Started websocket server at [localhost:5657]
```

The master is now running, and can accept commands over websocket. To do this, you have two options:
- Use the `BonAppetitMasterClient` class to communicate with the master
- User the `bonappetit_websocket_client_command_line_ui` exe included with forcenpy for interactive access

Let's use the `bonappetit_websocket_client_command_line_ui` exe. Run it with `--help` to see how it works

```bash
username@computer:~/forcenpy$ ./bonappetit_websocket_client_command_line_ui --help
```

```bash
PyInstaller/loader/pyimod02_importers.py:419: UserWarning: pkg_resources is deprecated as an API. See https://setuptools.pypa.io/en/latest/pkg_resources.html. The pkg_resources package is slated for removal as early as 2025-11-30. Refrain from using this package or pin to Setuptools<81.
usage: bonappetit_websocket_master_tester [-h] [--terse] websocket_master_ip_address websocket_master_command_srv_port websocket_master_error_pub_port

positional arguments:
  websocket_master_ip_address
                        bonappetit websocket master ip address
  websocket_master_command_srv_port
                        bonappetit websocket master ip address
  websocket_master_error_pub_port
                        bonappetit websocket master ip address

options:
  -h, --help            show this help message and exit
  --terse               Whether logging should be terse or not
```

We should specify the same IP and ports we used when starting the master.

```bash
username@computer:~/forcenpy$ ./bonappetit_websocket_client_command_line_ui localhost 5656 5657
```

```bash
PyInstaller/loader/pyimod02_importers.py:419: UserWarning: pkg_resources is deprecated as an API. See https://setuptools.pypa.io/en/latest/pkg_resources.html. The pkg_resources package is slated for removal as early as 2025-11-30. Refrain from using this package or pin to Setuptools<81.
2025-07-10 02:10:59.580 | MainThread |   MainProcess (PID-10857) | INFO     | forcen_bonappetit_api.bonappetit_websocket_helpers:make_client:70 | Trying to connect to bonappetit master command client localhost:5656
2025-07-10 02:10:59.593 | MainThread |   MainProcess (PID-10857) | INFO     | forcen_bonappetit_api.bonappetit_websocket_helpers:make_client:70 | Trying to connect to bonappetit master error subscriber localhost:5657


Enter command to send to master from list
[1] - call GetDetectedDevices
[2] - call GetActiveServers
[3] - call SpawnServer
[4] - call KillServer
[5] - call KillAllServers
[6] - call ConnectToExistingServer
[e] - escape master client UI

[q] - quit script

Enter Command:  2025-07-10 02:10:59.596 | Thread-3 (_loop) |   MainProcess (PID-10857) | INFO     | forcen_bonappetit_api.bonappetit_websocket_client_loop:_loop:112 | BonAppetitClient - subscriber loop started
```

You can now use the commandline to interact with the master. You can call `GetDetectedDevices`, `GetActiveServers`, and `KillAllServers` to see what happens. Before we can spawn a server, let's start a mock sensor. This is done using the `bon_echo_mock_server` exe. Let's check it out with `--help`

```bash
username@computer:~/forcenpy$ ./bon_echo_mock_server --help
```

```bash
PyInstaller/loader/pyimod02_importers.py:419: UserWarning: pkg_resources is deprecated as an API. See https://setuptools.pypa.io/en/latest/pkg_resources.html. The pkg_resources package is slated for removal as early as 2025-11-30. Refrain from using this package or pin to Setuptools<81.
usage: bon_echo_mock_node [-h] [-p PORT] [-V VERSION]

options:
  -h, --help            show this help message and exit
  -p PORT, --port PORT  TCP Port of the Bon Echo Mock
  -V VERSION, --version VERSION
                        What firmware version to emulate
```

Let's create a v7.2.7 sensor on a specific port

```bash
username@computer:~/forcenpy$ ./bon_echo_mock_server --version "7.2.7" --port 5658
```

```bash
PyInstaller/loader/pyimod02_importers.py:419: UserWarning: pkg_resources is deprecated as an API. See https://setuptools.pypa.io/en/latest/pkg_resources.html. The pkg_resources package is slated for removal as early as 2025-11-30. Refrain from using this package or pin to Setuptools<81.
2025-07-10 02:15:11.288 | MainThread |   MainProcess (PID-11169) | INFO     | __main__:main:50 | Creating BonEchoMock...
2025-07-10 02:15:11.289 | MainThread |   MainProcess (PID-11169) | INFO     | forcen_bonappetit.mocks.bon_echo_mock_v7_2_x:__init__:116 | Initializing mock Bonecho v7.2.0 sensor.
2025-07-10 02:15:11.289 | MainThread |   MainProcess (PID-11169) | INFO     | forcen_bonappetit.transport.tcp_server:__init__:46 | TCPServer - Bound to [('127.0.0.1', 5658)]
2025-07-10 02:15:11.290 | MainThread |   MainProcess (PID-11169) | INFO     | forcen_bonappetit.transport.tcp_server:__init__:52 | TCPServer - Starting server thread...
2025-07-10 02:15:11.290 | Thread-1 (_server_spin) |   MainProcess (PID-11169) | INFO     | forcen_bonappetit.transport.tcp_server:_server_spin:198 | TCPServer - Server thread started
2025-07-10 02:15:11.291 | Thread-2 (bon_echo_mock_runner) |   MainProcess (PID-11169) | INFO     | forcen_bonappetit.mocks.bon_echo_mock_v7_x_helpers:bon_echo_mock_runner:84 | bon_echo_mock_runner - thread started
2025-07-10 02:15:11.292 | Thread-3 (bon_echo_mock_sensor_data_runner) |   MainProcess (PID-11169) | INFO     | forcen_bonappetit.mocks.bon_echo_mock_v7_x_helpers:bon_echo_mock_sensor_data_runner:42 | bon_echo_mock_sensor_data_runner - thread started
2025-07-10 02:15:11.293 | MainThread |   MainProcess (PID-11169) | INFO     | __main__:main:52 | Started BonEchoMock at [127.0.0.1:5658]
2025-07-10 02:15:11.295 | MainThread |   MainProcess (PID-11169) | INFO     | __main__:main:55 | BonEchoMock is running. Ctrl+C to quit
```

With that running, lets go back to our command line UI and try SpawnServer

```bash
Received [3]


Spawn server selected. What type of server do you want to spawn?
(m)ock server [or leave blank]
(t)cp device server
(u)art device server
```

Let's select TCP device by entering `t`

```bash
What should the server's IP Address be? Leave blank for 'localhost'
```

Localhost works, just press enter

```bash
Enter BonEcho TCP Server ip address and port as <address>:<port>
```

We're on localhost, and the mock sensor was started at 5658 (or w/e you chose to start at)
```bash
localhost:5658
```

You should get a bunch of printout on the Master as it receives the command

```bash
2025-07-10 02:17:56.252 | Thread-3 (conn_handler) |   MainProcess (PID-10539) | INFO     | forcen_bonappetit.server.bonappetit_websocket_message_handler:_step:98 | [bonappetit_master_ws_server] [127.0.0.1:46720] CMD [spawn_server] ARGS [{'server_ip_address': 'localhost', 'transport_type': 'tcp', 'device_info': {'ip_address': 'localhost', 'port': 5658, 'timeout': 1.0}}]
2025-07-10 02:17:56.253 | Thread-3 (conn_handler) |   MainProcess (PID-10539) | INFO     | forcen_bonappetit.server.bonappetit_websocket_master_servers_manager:add_server:97 | Creating new Bonappetit server in subprocess with params:
transport_type: tcp
{'ip_address': 'localhost', 'port': 5658, 'timeout': 1.0}

2025-07-10 02:17:56.253 | Thread-3 (conn_handler) |   MainProcess (PID-10539) | INFO     | forcen_bonappetit.server.bonappetit_websocket_master_server_thread:_make_partial_server:154 | Args provided to spawn new server as subprocess
2025-07-10 02:17:56.253 | Thread-3 (conn_handler) |   MainProcess (PID-10539) | INFO     | forcen_bonappetit.server.bonappetit_websocket_master_server_thread:__init__:105 | Args provided to spawn new server as subprocess
2025-07-10 02:17:56.255 | Thread-7 (_spawn_server_worker) |   MainProcess (PID-10539) | INFO     | forcen_bonappetit.server.bonappetit_websocket_master_server_thread:_spawn_server_worker:232 | Started thread to spawn server for [c9c81761]
2025-07-10 02:17:56.256 | Thread-3 (conn_handler) |   MainProcess (PID-10539) | INFO     | forcen_bonappetit.server.bonappetit_websocket_master_server_thread:__init__:125 | Initializing Bonappetit Server Thread Manager for [c9c81761]
2025-07-10 02:17:56.256 | Thread-3 (conn_handler) |   MainProcess (PID-10539) | INFO     | forcen_bonappetit.server.bonappetit_websocket_message_handler:__call__:164 | [bonappetit_master_ws_server] [spawn_server] OK, 
Payload:
{'server_uuid': UUID('c9c81761-ffb5-45cc-a5e7-eb58642bbcdd')}
PyInstaller/loader/pyimod02_importers.py:419: UserWarning: pkg_resources is deprecated as an API. See https://setuptools.pypa.io/en/latest/pkg_resources.html. The pkg_resources package is slated for removal as early as 2025-11-30. Refrain from using this package or pin to Setuptools<81.
PyInstaller/loader/pyimod02_importers.py:419: UserWarning: pkg_resources is deprecated as an API. See https://setuptools.pypa.io/en/latest/pkg_resources.html. The pkg_resources package is slated for removal as early as 2025-11-30. Refrain from using this package or pin to Setuptools<81.
2025-07-10 02:17:56.491 | MainThread |   SpawnProcess-1 (PID-11216) | INFO     | forcen_bonappetit.transport.tcp_client_transport:__init__:37 | TCPClientTransport - Connected to server at [127.0.0.1:5658]
2025-07-10 02:17:56.502 | MainThread |   SpawnProcess-1 (PID-11216) | INFO     | forcen_bonappetit.drivers.ascii_protocol_driver:__init__:209 | Found potential firmware version v7.2.0
2025-07-10 02:17:56.502 | MainThread |   SpawnProcess-1 (PID-11216) | INFO     | forcen_bonappetit.drivers.ascii_protocol_driver:__init__:228 | Getting serial number
2025-07-10 02:17:56.547 | Thread-1 (_runner_loop) |   SpawnProcess-1 (PID-11216) | INFO     | forcen_bonappetit.drivers.driver_data_collector:_runner_loop:489 | DriverCommsCollector - runner loop started
2025-07-10 02:17:56.547 | MainThread |   SpawnProcess-1 (PID-11216) | INFO     | forcen_bonappetit.server.bonappetit_master_multiprocessing_helpers:server_process_function:64 | Instantiating BonappetitServer
2025-07-10 02:17:56.549 | MainThread |   SpawnProcess-1 (PID-11216) | INFO     | forcen_websockets.websocket_sync_server:__init__:49 | command_srv Started websocket server at [localhost:37233]
2025-07-10 02:17:56.550 | MainThread |   SpawnProcess-1 (PID-11216) | INFO     | forcen_websockets.websocket_sync_server:__init__:49 | 009000_data_pub Started websocket server at [localhost:43065]
2025-07-10 02:17:56.551 | MainThread |   SpawnProcess-1 (PID-11216) | INFO     | forcen_websockets.websocket_sync_server:__init__:49 | 009000_errors_pub Started websocket server at [localhost:45663]
2025-07-10 02:17:56.551 | MainThread |   SpawnProcess-1 (PID-11216) | INFO     | forcen_bonappetit.server.bonappetit_master_multiprocessing_helpers:server_process_function:71 | Instantiated BonappetitServer version [0.2.0]
IP Address: localhost
server_port: 37233
data_pub_port: 43065
2025-07-10 02:17:56.555 | Thread-6 (conn_handler) |   SpawnProcess-1 (PID-11216) | WARNING  | forcen_bonappetit.server.bonappetit_websocket_server:_error_pub_handler:1173 | [localhost][0x000013370000424200009000] New client for error pub from [127.0.0.1:41406]
2025-07-10 02:17:56.557 | Thread-9 (conn_handler) |   SpawnProcess-1 (PID-11216) | INFO     | forcen_bonappetit.server.bonappetit_websocket_message_handler:__call__:139 | [009000_command_server] [127.0.0.1:44726] New client connected
2025-07-10 02:17:57.566 | Thread-9 (conn_handler) |   SpawnProcess-1 (PID-11216) | INFO     | forcen_bonappetit.drivers.ascii_protocol_driver:_send_packet_and_parse_reply:1693 | [ReplyPacketStamped(packet_type=<PacketType.REGISTER: 'r'>
```

if no errors or exceptions are thrown, server started fine. Let's verify in our CL UI with `GetActiveServers`

```bash
Getting active servers...


Response:
(ServerInfo(uuid=UUID('c9c81761-ffb5-45cc-a5e7-eb58642bbcdd'),
            device_transport_type='tcp',
            device_connection_info={'ip_address': 'localhost',
                                    'port': 5658,
                                    'timeout': 1.0},
            ip_address='localhost',
            commands_srv_port=37233,
            sensor_data_pub_port=43065,
            errors_pub_port=45663,
            server_version=Version(major=0, minor=2, patch=0),
            _server_info_tag=_ServerInfoTag()),)
```

If you get something like that, server has spawned properly and connected to our mock sensor. Let's get data out of it. In the CL UI, use `[e]` to `escape master client UI`. You'll get a new set of options like this:


```bash
Choose which client to use:

[m] - Master Client
[0] - transport_type: tcp
		port: 127.0.0.1
		port: 5658
[q] - to quit script completely
```

`[m]` will take you back to the master client, but we want to go to the client for our newly started server. Use `[0]` to get to it.

```bash
input raw json to send over websocket to client. 
all json should follow the format: 

{ 
  command: <int> 
  command_args: <dict> 
} 

Alternatively, enter 'e' to return to client selection:
```

You can now send commands to the websocket server directly. This is not the best way to interact with the server, for that use BonAppetitClient, but this is a quick and interactive way to make sure everything is nominal. Let's set the data rate first. Copy this into the CL UI terminal and send it

```json
{"command": "set_data_rate", "command_args": {"adc_data_rate_hz": 1}}
```

That should produce a response like:

```bash
Received [{"command": "set_data_rate", "command_args": {"adc_data_rate_hz": 1}}]


{
  "command": "set_data_rate",
  "desc": "",
  "code": null,
  "payload": {},
  "success": true
}


input raw json to send over websocket to client. 
all json should follow the format: 

{ 
  command: <int> 
  command_args: <dict> 
} 

Alternatively, enter 'e' to return to client selection:
```

Since `success` is `true`, we're good. You'll see similar confirmation if you look at the terminal output of the mock sensor and the master. Before we start streaming data, let's start another script to receive and dump sensor data to console. For that, we use the `bonappetit_websocket_client_command_line_ui` exe. 

```bash
username@computer:~/Documents/repos/forcen/forcenpy$ ./bonappetit_websocket_client_data_streamer --help
PyInstaller/loader/pyimod02_importers.py:419: UserWarning: pkg_resources is deprecated as an API. See https://setuptools.pypa.io/en/latest/pkg_resources.html. The pkg_resources package is slated for removal as early as 2025-11-30. Refrain from using this package or pin to Setuptools<81.
usage: bonappetit_websocket_master_tester [-h] [-r] [--terse]
                                          websocket_master_ip_address
                                          websocket_master_port

positional arguments:
  websocket_master_ip_address
                        bonappetit websocket master ip address
  websocket_master_port
                        bonappetit websocket master ip address

options:
  -h, --help            show this help message and exit
  -r, --realtime_stream
                        whether to use websocket or udp for sensor data
  --terse               reducing logging output

```

Let's give this the master IP and command PORT we set earlier

```bash
username@computer:~/forcenpy$ ./bonappetit_websocket_client_data_streamer localhost 5656
```

```bash
PyInstaller/loader/pyimod02_importers.py:419: UserWarning: pkg_resources is deprecated as an API. See https://setuptools.pypa.io/en/latest/pkg_resources.html. The pkg_resources package is slated for removal as early as 2025-11-30. Refrain from using this package or pin to Setuptools<81.
2025-07-10 02:29:39.707 | MainThread |   MainProcess (PID-11654) | INFO     | __main__:main:40 | This script communicates with a bonappetit websocket master
Found the following servers

[0] - localhost:37233:43065

Enter number to view data streamed by that server:
```

You can see that there's a detected server we can tap into. Let's enter `[0]` to we live data. Currently, live data isn't streaming from our mock sensor, so nothing will happen after some setup prints. Now set the device mode to be `RUNNING`. Going back to the command line ui terminal, let's send: 

```json
{"command": "set_mode", "command_args": {"device_mode": "RUNNING"}}
```

Now you should see data streaming on the previous terminal. Enter this to stop the data

```json
{"command": "set_mode", "command_args": {"device_mode": "SLEEP"}}
```

And with that, you've verified that the system is working. We can now do this programmatically. 

## Controlling everything with Scripting

Close anything running and start the Master and Mock Sensor in separate terminals. This time, instead of using the CL UI, we'll use a script.

```python
if __name__=="__main__":
  from forcen_bonappetit_api.bonappetit_websocket_master_client import BonAppetitMasterClient
  from forcen_bonappetit_api.bonappetit_websocket_client import BonAppetitClient
  with BonAppetitMasterClient(
    master_ip_address="localhost", # adjust to match master
    master_command_srv_port=5656, # adjust to match master
    master_error_pub_port=5657, # adjust to match master
  ) as master_client:
    print(master_client.kill_all_servers().value()) # throws if error

    active_servers = master_client.get_active_servers().value() # throws if error
    assert len(active_servers) == 0  # nothing running yet

    server_uuid = master_client.spawn_server(
      server_ip_address="localhost",
      transport_type="tcp",
      device_info={
        "ip_address": "localhost",
        "port": 5658,  # adjust to match mock sensor
        "timeout": 5,
      },
    ).value()  # throws if error

    server_info = master_client.wait_for_partially_initialized_server(
      partially_initialized_server_uuid=server_uuid,
    ).value()  # throws if error

    # You can now user server_info to start a Client.

    with BonAppetitClient(
      server_ip_address=server_info.ip_address,
      server_command_port=server_info.commands_srv_port,
      server_data_pub_port=server_info.sensor_data_pub_port,
      server_error_pub_port=server_info.errors_pub_port,
    ) as client:
      # you can do whatever you want with it from here. See the python class for API. 
      ...

```