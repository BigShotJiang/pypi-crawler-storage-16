import dataclasses
import enum
from typing import Dict, NewType, Optional, Set

import forcen_public_utils.checked as ch
from forcen_public_utils.json_dataclasses_enum import patch_json_dataclass_enum_encoder
from forcen_public_utils.version import Version

DeviceType = NewType("DeviceType", int)
SerialNumber = NewType("SerialNumber", str)
UartBaudRate = NewType("UartBaudRate", int)
CanNodeID = NewType("CanNodeID", int)



ForcenWSServerVersion = Version


@enum.unique
class ReleaseType(enum.Enum):
    """Enum denoting the version labels for different release types."""

    NORMAL = enum.auto()
    BETA = enum.auto()

    @staticmethod
    def from_version_str(version_str: str) -> ch.MaybeVal["ReleaseType"]:
        return ReleaseType.from_char(version_str[0])

    @staticmethod
    def from_char(c: str) -> ch.MaybeVal["ReleaseType"]:
        """Get a release type from a full version code."""
        if c == "v":
            return ch.ok(ReleaseType.NORMAL)
        elif c == "u":
            return ch.ok(ReleaseType.BETA)
        else:
            return ch.bad(
                message=f"version string must contain `v` or `u` as first character, got {c}"
            )

    def as_char(self) -> str:
        """Convert this release type to a string character."""
        if self == ReleaseType.NORMAL:
            return "v"
        elif self == ReleaseType.BETA:
            return "u"
        else:
            raise RuntimeError(f"Invalid, unenumerated release type, {self}")


@dataclasses.dataclass(frozen=True)
class ForcenProtocolVersion:
    """Firmware versioning object for Forcen devices."""

    release_type: ReleaseType
    major: int
    minor: int
    patch: int

    @staticmethod
    def from_str(version_str: str) -> ch.MaybeVal["ForcenProtocolVersion"]:
        """Convert a string representation of a firmware version to a python object."""
        maybe_release_type = ReleaseType.from_version_str(version_str)
        if maybe_release_type.has_error():
            return ch.fwd_err(maybe_release_type)

        try:
            tokens = [int(ii) for ii in version_str[1:].split(".")]
        except ValueError as e:
            return ch.bad(message=f"Failed to parse version parts as ints, got {e}")

        if len(tokens) != 3:
            return ch.bad(
                message=f"Version string must contain 3 dot-separated numbers (x.y.z), got {version_str[1:]}"
            )

        return ch.ok(
            ForcenProtocolVersion(
                release_type=maybe_release_type.value(),
                major=tokens[0],
                minor=tokens[1],
                patch=tokens[2],
            )
        )

    def is_match(
        self, major: int, minor: Optional[int] = None, patch: Optional[int] = None
    ) -> bool:
        if self.major != major:
            return False

        if minor is None:
            return True

        if self.minor != minor:
            return False

        if patch is None:
            return True

        if self.patch != patch:
            return False

        return True

    def __str__(self) -> str:
        return f"{self.release_type.as_char()}{self.major}.{self.minor}.{self.patch}"

    def __hash__(self) -> int:
        return hash(repr(self))


@patch_json_dataclass_enum_encoder
@enum.unique
class DeviceMode(enum.Enum):
    """All possible device modes for all Ascii protocols.

    To implement, construct a dictionary in each individual protocol implementation which
    connects these codes to their corresponding value.

    e.g.
    BONECHO_VX_Y_Z_DEVICE_MODE = {
        DeviceMode.SLEEP: 0,
        ...
    }
    """

    SLEEP = enum.auto()
    ACTIVE = enum.auto()
    RUNNING = enum.auto()
    CALIBRATION = enum.auto()
    BOOTLOADER = enum.auto()
    DETECT = enum.auto()
    WINK = enum.auto()
    IMU_CALIBRATION = enum.auto()


# NOTE: If these codes ever change value (e.g. if 0x00 ever represents USB, for instance), such as
# might be the case for CLv1.1.x, then replace these values with enum.auto() and create dictionaries
# inside each concrete protocol.
@patch_json_dataclass_enum_encoder
@enum.unique
class PeripheralType(enum.Enum):
    """
    Choose which peripheral connectiohn to use.

    These are the same for BEv7.2.x and BEv7.3.x and CLv1.0.x.
    """

    CAN = 0x00
    UART = 0x01
    USB = 0x02


@patch_json_dataclass_enum_encoder
@enum.unique
class SensorOutputModel(enum.Enum):
    RAW = 0
    OFFSET_ONLY = 1
    LINEAR_MODEL = 2
    PIECEWISE_MODEL = 3


@patch_json_dataclass_enum_encoder
@enum.unique
class LedState(enum.Enum):
    OFF = 0
    EVENTS = 1
    MANUAL = 2


@dataclasses.dataclass(frozen=True)
class LedData:
    state: LedState
    brightness: int

    @staticmethod
    def from_raw(value: int) -> "LedData":
        if value < 0 or value > 255:
            raise ValueError("led raw value must be within 0 and 255")
        if value == 0:
            return LedData(LedState.OFF, 0)
        elif value == 1:
            return LedData(LedState.EVENTS, 1)
        else:
            return LedData(LedState.MANUAL, value)

    @staticmethod
    def events() -> "LedData":
        return LedData.from_raw(1)


@patch_json_dataclass_enum_encoder
@enum.unique
class ADCGain(enum.Enum):
    X_ONE_THIRD = 0
    X_ONE = 1
    X_TWO = 2
    X_FOUR = 3
    X_EIGHT = 4
    X_SIXTEEN = 5
    X_THIRTY_TWO_DIGITAL = 6
    X_SIXTY_FOUR_DIGITAL = 7


@patch_json_dataclass_enum_encoder
@enum.unique
class ADCOverSamplingRatio(enum.Enum):
    OSR_32 = 0
    OSR_64 = 1
    OSR_128 = 2
    OSR_256 = 3
    OSR_512 = 4
    OSR_1024 = 5
    OSR_2048 = 6
    OSR_4096 = 7
    OSR_8192 = 8
    OSR_16384 = 9
    OSR_20480 = 10
    OSR_24576 = 11
    OSR_40960 = 12
    OSR_49152 = 13
    OSR_81920 = 14
    OSR_98304 = 15


@patch_json_dataclass_enum_encoder
@enum.unique
class ADCChannel(enum.IntFlag):
    CHANNEL_1 = 0b0000_0000_0000_0001
    CHANNEL_2 = 0b0000_0000_0000_0010
    CHANNEL_3 = 0b0000_0000_0000_0100
    CHANNEL_4 = 0b0000_0000_0000_1000
    TEMPERATURE = 0b0001_0000_0000_0000
    AVDD = 0b0010_0000_0000_0000
    VCM = 0b0100_0000_0000_0000
    OFFSET = 0b1000_0000_0000_0000

    @staticmethod
    def all_channels() -> Set["ADCChannel"]:
        return set([e for e in ADCChannel])

    @staticmethod
    def only_force_channels() -> Set["ADCChannel"]:
        return set(
            [
                ADCChannel.CHANNEL_1,
                ADCChannel.CHANNEL_2,
                ADCChannel.CHANNEL_3,
                ADCChannel.CHANNEL_4,
            ]
        )

    @staticmethod
    def from_combined_int(value: int) -> Set["ADCChannel"]:
        return set([e for e in ADCChannel if (e & value)])

    @staticmethod
    def to_combined_int(channels: Set["ADCChannel"]) -> int:
        out = 0
        for c in channels:
            out = out | c.value
        return out


@patch_json_dataclass_enum_encoder
@enum.unique
class CalibrationConstant(enum.Enum):
    STRAIN_1_OFFSET = 0
    STRAIN_2_OFFSET = 1
    STRAIN_3_OFFSET = 2
    STRAIN_4_OFFSET = 3
    CHANNEL_1_TO_STRAIN_1_GAIN = 4
    CHANNEL_1_TO_STRAIN_2_GAIN = 5
    CHANNEL_1_TO_STRAIN_3_GAIN = 6
    CHANNEL_1_TO_STRAIN_4_GAIN = 7
    CHANNEL_2_TO_STRAIN_1_GAIN = 8
    CHANNEL_2_TO_STRAIN_2_GAIN = 9
    CHANNEL_2_TO_STRAIN_3_GAIN = 10
    CHANNEL_2_TO_STRAIN_4_GAIN = 11
    CHANNEL_3_TO_STRAIN_1_GAIN = 12
    CHANNEL_3_TO_STRAIN_2_GAIN = 13
    CHANNEL_3_TO_STRAIN_3_GAIN = 14
    CHANNEL_3_TO_STRAIN_4_GAIN = 15
    CHANNEL_4_TO_STRAIN_1_GAIN = 16
    CHANNEL_4_TO_STRAIN_2_GAIN = 17
    CHANNEL_4_TO_STRAIN_3_GAIN = 18
    CHANNEL_4_TO_STRAIN_4_GAIN = 19
    CHANNEL_1_TO_STRAIN_1_GAIN_NEG = 20
    CHANNEL_1_TO_STRAIN_2_GAIN_NEG = 21
    CHANNEL_1_TO_STRAIN_3_GAIN_NEG = 22
    CHANNEL_1_TO_STRAIN_4_GAIN_NEG = 23
    CHANNEL_2_TO_STRAIN_1_GAIN_NEG = 24
    CHANNEL_2_TO_STRAIN_2_GAIN_NEG = 25
    CHANNEL_2_TO_STRAIN_3_GAIN_NEG = 26
    CHANNEL_2_TO_STRAIN_4_GAIN_NEG = 27
    CHANNEL_3_TO_STRAIN_1_GAIN_NEG = 28
    CHANNEL_3_TO_STRAIN_2_GAIN_NEG = 29
    CHANNEL_3_TO_STRAIN_3_GAIN_NEG = 30
    CHANNEL_3_TO_STRAIN_4_GAIN_NEG = 31
    CHANNEL_4_TO_STRAIN_1_GAIN_NEG = 32
    CHANNEL_4_TO_STRAIN_2_GAIN_NEG = 33
    CHANNEL_4_TO_STRAIN_3_GAIN_NEG = 34
    CHANNEL_4_TO_STRAIN_4_GAIN_NEG = 35
    STRAIN_1_BOUND = 36
    STRAIN_2_BOUND = 37
    STRAIN_3_BOUND = 38
    STRAIN_4_BOUND = 39

    @staticmethod
    def get_init_dict() -> Dict["CalibrationConstant", float]:
        d = {c: 0.0 for c in CalibrationConstant}
        d[CalibrationConstant.CHANNEL_1_TO_STRAIN_1_GAIN] = 1
        d[CalibrationConstant.CHANNEL_2_TO_STRAIN_2_GAIN] = 1
        d[CalibrationConstant.CHANNEL_3_TO_STRAIN_3_GAIN] = 1
        d[CalibrationConstant.CHANNEL_4_TO_STRAIN_4_GAIN] = 1
        d[CalibrationConstant.CHANNEL_1_TO_STRAIN_1_GAIN_NEG] = 1
        d[CalibrationConstant.CHANNEL_2_TO_STRAIN_2_GAIN_NEG] = 1
        d[CalibrationConstant.CHANNEL_3_TO_STRAIN_3_GAIN_NEG] = 1
        d[CalibrationConstant.CHANNEL_4_TO_STRAIN_4_GAIN_NEG] = 1
        return d


@patch_json_dataclass_enum_encoder
@enum.unique
class UartParity(enum.Enum):
    PARITY_NONE = 0
    PARITY_EVEN = 1
    PARITY_ODD = 2


@patch_json_dataclass_enum_encoder
@enum.unique
class UartStopbits(enum.Enum):
    STOPBITS_0_5 = 0
    STOPBITS_1_0 = 1
    STOPBITS_1_5 = 2
    STOPBITS_2_0 = 3


@patch_json_dataclass_enum_encoder
@enum.unique
class CanBaudRate(enum.Enum):
    R_1000_KBPS = 0
    R_500_KBPS = 1
    R_250_KBPS = 2
    R_125_KBPS = 3
    R_100_KBPS = 4
    R_83_KBPS = 5
    R_50_KBPS = 6
    R_20_KBPS = 7
    R_10_KBPS = 8


@patch_json_dataclass_enum_encoder
@enum.unique
class HardwareErrorCode(enum.Enum):
    """
    Swapnil - Feb 19th, 2024
    Introduced in v7.3.x
    The values for that version are set to the values of the enum.
    If in the future some v7.y.x has different values, use enum.auto() for the enum values and
    create a Dict[Enum, int] for each version as a costant
    """

    NO_ERROR = 0
    HARDWARE_ABSTRACTION_INITIALIZATION_FAILURE = 1
    OSCILLATOR_INITIALIZATION_FAILURE = 2
    CLOCK_INITIALIZATION_FAILURE = 3
    PERIPHERAL_CLOCK_INITIALIZATION_FAILURE = 4
    VOLTAGE_SCALING_INITIALIZATION_FAILURE = 5
    UNEXPECTED_HARDWARE_FAULT = 6
    MEMORY_FAULT = 7
    BUS_FAULT = 8
    USAGE_FAULT = 9  # This needs more detail, but the PDF protocol doc doesn't have more
    USB_SPEED_ERROR = 10
    USB_INITIALIZATION_ERROR = 11


@patch_json_dataclass_enum_encoder
@enum.unique
class RuntimeDeviceErrorCode(enum.Enum):
    """
    Swapnil - Feb 19th, 2024
    Introduced in v7.3.x
    The values for that version are set to the values of the enum.
    If in the future some v7.y.x has different values, use enum.auto() for the enum values and
    create a Dict[Enum, int] for each version as a costant
    """

    INTERNAL_SPI_BUS_INITIALIZATION_ERROR = 0
    INTERNAL_I2C_BUS_INITIALIZATION_ERROR = 1
    INTERNAL_ADC_INITIALIZATION_ERROR = 2
    INTERNAL_REF_CIRCUIT_INITIALIZATION_ERROR = 3
    DATA_COLLECTION_ERROR_1 = 4
    DATA_COLLECTION_ERROR_2 = 5
    DATA_COLLECTION_ERROR_3 = 6
    DATA_COLLECTION_ERROR_4 = 7
    # Errors defined by CLv1.2.x
    INTERNAL_CAN_BUS_INITIALIZATION_ERROR = 8
    DETECTION_MISMATCH_ERROR = 9
    GENERIC_PROCESSING_ERROR = 10
    GENERIC_INITIALIZATION_ERROR = 11
    NO_ERROR = 255  # TODO (Swapnil) - Is this true?

    def is_data_collection_error(self) -> bool:
        return self in set(
            [
                RuntimeDeviceErrorCode.DATA_COLLECTION_ERROR_1,
                RuntimeDeviceErrorCode.DATA_COLLECTION_ERROR_2,
                RuntimeDeviceErrorCode.DATA_COLLECTION_ERROR_3,
                RuntimeDeviceErrorCode.DATA_COLLECTION_ERROR_4,
            ]
        )


@patch_json_dataclass_enum_encoder
@enum.unique
class TareStatus(enum.Enum):
    """
    Swapnil - Feb 19th, 2024
    Introduced in v7.3.x
    The values for that version are set to the values of the enum.
    If in the future some v7.y.x has different values, use enum.auto() for the enum values and
    create a Dict[Enum, int] for each version as a costant
    """

    MODEL_OK = 0
    MODEL_TRANSITION = 0x10
    MODEL_COLLECTING = 0x11
    CHECKPOINT_0 = 0x12
    CHECKPOINT_1 = 0x13
    CHECKPOINT_2 = 0x14
    CHECKPOINT_3 = 0x15
    CHECKPOINT_4 = 0x16
    CHECKPOINT_5 = 0x17
    CHECKPOINT_6 = 0x18
    CHECKPOINT_7 = 0x19
    CHECKPOINT_8 = 0x1A
    CHECKPOINT_9 = 0x1B
    CHECKPOINT_WAITING_0 = 0x20
    CHECKPOINT_WAITING_1 = 0x21
    CHECKPOINT_WAITING_2 = 0x22
    CHECKPOINT_WAITING_3 = 0x23
    CHECKPOINT_WAITING_4 = 0x24
    CHECKPOINT_WAITING_5 = 0x25
    CHECKPOINT_WAITING_6 = 0x26
    CHECKPOINT_WAITING_7 = 0x27
    CHECKPOINT_WAITING_8 = 0x28
    CHECKPOINT_WAITING_9 = 0x29
    COLLECT_PAUSED = 0xD0
    MODEL_WARNING = 0xE0
    MODEL_ERROR = 0xF0
    PARAMS_NOT_LINKED = 0xF1
    NOT_ENOUGH_MEMORY = 0xF2
    NOT_ENOUGH_CONSTANTS = 0xF3
    NOT_ENOUGH_VARIABLES = 0xF4
    NOT_ENOUGH_INPUT_POINTERS = 0xF5
    INPUT_NOT_INITIALIZED = 0xF6
    MODEL_NOT_LOADED = 0xF7
    MODEL_INIT_FAILED = 0xF8
    MODEL_FILTER_INIT_FAILED = 0xF9
    MODEL_BUFFER_INIT_FAILED = 0xFA
    MODEL_BUFFER_PUSH_FAILED = 0xFB
    MODEL_NOT_TARED = 0xFF


@patch_json_dataclass_enum_encoder
@enum.unique
class SelectedOutputDataStream(enum.Enum):
    """
    Swapnil - Feb 19th, 2024
    Introduced in v7.3.x
    The values for that version are set to the values of the enum.
    If in the future some v7.y.x has different values, use enum.auto() for the enum values and
    create a Dict[Enum, int] for each version as a costant
    """

    TIME_IN_MILLISECONDS = 0b0000_0001
    RAW_SENSOR_DATA = 0b0000_0010
    TEMPERATURE_COMPENSATED_DATA = 0b0000_0100
    TEMPERATURE_IN_COUNTS = 0b0000_1000
    PROCESSED_MODEL_DATA = 0b0001_0000
    DETAILED_PROCESSED_MODEL_DATA = 0b0010_0000

    @staticmethod
    def from_combined_int(value: int) -> Set["SelectedOutputDataStream"]:
        return set([e for e in SelectedOutputDataStream if (e.value & value)])

    @staticmethod
    def to_combined_int(streams: Set["SelectedOutputDataStream"]) -> int:
        out = 0
        for ss in streams:
            out = out | ss.value
        return out


@patch_json_dataclass_enum_encoder
@enum.unique
class ImuMode(enum.Enum):
    """This was added in CLv1.0.x.

    This indicates the operating mode of the IMU, i.e., which sensors are enabled.

    """

    IMU = 0x00  # gyro + accelerometer
    COMPASS = 0x01  # accelerometer + magnetometer
    MAGNETOMETER_FOR_GYRO = 0x02  # accelerometer + magnetometer
    NDOF_WITH_FAST_MAG_CALIBRATION_DISABLED = 0x03  # gyro + accelerometer + magnetometer
    NDOF_WITH_FAST_MAG_CALIBRATION_ENABLED = 0x04  # gyro + accelerometer + magnetometer


@patch_json_dataclass_enum_encoder
@enum.unique
class ImuCalibrationFlag(enum.Enum):
    """This was added in CLv1.0.x, and indicates if an IMU calibration is stored on the device."""

    NO_CALIBRATION_PROFILE = 0x00
    CALIBRATION_PROFILE_SAVED = 0xAA


class ImuCalibrationStatus:
    """This was added in CLv1.0.x."""

    system_calibration_status: int
    gyroscope_calibration_status: int
    accelerometer_calibration_status: int
    magnetometer_calibration_status: int


@dataclasses.dataclass
class ImuDataStyle:
    """This was added in CLv1.0.x and CL1.2.x.

    This object specifies which IMU output data is added to the RTD data stream.

    Note that not all flags are used for all sensor versions.
    """

    output_raw_gyro: bool = False
    output_raw_accelerations: bool = False
    output_gravity_vector: bool = False
    output_linear_accelerations: bool = False
    output_quaternions: bool = False
    output_euler_angles: bool = False
