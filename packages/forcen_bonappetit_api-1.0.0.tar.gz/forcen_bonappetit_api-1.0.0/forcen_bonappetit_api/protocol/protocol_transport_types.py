import dataclasses
import enum
from typing import Callable, List, Optional, Tuple, Union, cast

from forcen_bonappetit_api.common.error_types import (
    BonAppetitCode,  # pyright: ignore [reportUnusedImport]
)
from forcen_bonappetit_api.common.error_types import BonAppetitChecked
from forcen_bonappetit_api.protocol.protocol_data_types import ForcenProtocolVersion
from forcen_bonappetit_api.transport.transport_types import (
    RecvTransportPacket,
    TransportMessageType,  # pyright: ignore [reportUnusedImport]
    WriteMetaInfo,  # pyright: ignore [reportUnusedImport]
    ControlCharPair,
    SendTransportPacket,
)


@enum.unique
class PacketType(str, enum.Enum):
    REALTIME_DATA = " "
    REGISTER = "r"
    EMERGENCY = "e"
    ACKNOWLEDGE = "a"

    @staticmethod
    def default_type():
        return PacketType.REALTIME_DATA

    @staticmethod
    def all() -> List["PacketType"]:
        return list(PacketType)

    @staticmethod
    def all_except_realtime() -> List["PacketType"]:
        ret = list(PacketType)
        ret.remove(PacketType.REALTIME_DATA)
        return ret

    @staticmethod
    def from_id(character: str) -> Optional["PacketType"]:
        try:
            return PacketType(character)
        except ValueError:
            return None

    def id(self) -> str:
        return self.value


@dataclasses.dataclass
class RTDPacket:
    data: List[Union[int, float]]


@dataclasses.dataclass
class ReplyPacket:
    packet_type: PacketType
    data: str


@dataclasses.dataclass
class RTDPacketStamped:
    data: Tuple[Union[int, float], ...]
    timestamp: float


@dataclasses.dataclass
class ReplyPacketStamped:
    packet_type: PacketType
    data: str
    timestamp: float


@dataclasses.dataclass
class Packet:
    packet_type: PacketType
    data: Union[str, Optional[Tuple[Union[int, float], ...]]]

    def as_union_type(self) -> Union[ReplyPacket, RTDPacket]:
        if self.packet_type == PacketType.REALTIME_DATA:
            return RTDPacket(cast(List[Union[int, float]], self.data))
        else:
            return ReplyPacket(self.packet_type, cast(str, self.data))


@dataclasses.dataclass
class PacketStamped:
    packet_type: PacketType
    data: Union[str, Optional[Tuple[Union[float, int], ...]]]
    timestamp: float

    def as_union_type(self) -> Union[ReplyPacketStamped, RTDPacketStamped]:
        if self.packet_type == PacketType.REALTIME_DATA:
            return RTDPacketStamped(cast(Tuple[int, ...], self.data), self.timestamp)
        else:
            return ReplyPacketStamped(self.packet_type, cast(str, self.data), self.timestamp)


@dataclasses.dataclass(frozen=True)
class FirmwareCommandData:
    firmware_cmd: SendTransportPacket
    ctrl_pair: ControlCharPair
    encoding: str
    parse_raw_packet: Callable[[RecvTransportPacket], BonAppetitChecked[Packet]]
    parse_firmware: Callable[[ReplyPacket], BonAppetitChecked[ForcenProtocolVersion]]
