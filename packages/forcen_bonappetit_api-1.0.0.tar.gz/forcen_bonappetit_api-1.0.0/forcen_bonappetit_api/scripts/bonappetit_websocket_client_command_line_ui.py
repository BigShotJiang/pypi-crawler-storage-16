"""Main script for testing master-client to master-server commands, or client to server commands."""

import argparse
import json
import sys
from pprint import pformat
from typing import Any, List, Optional, Union, Sequence
from uuid import UUID

import websockets.exceptions as ws_excp

from forcen_bonappetit_api.bonappetit_websocket_client import (
    BonAppetitChecked,
    BonAppetitClient,
    BonAppetitCode,
)
from forcen_bonappetit_api.bonappetit_websocket_master_client import (
    BonAppetitMasterClient,
    PartialServerInfo,  # pyright: ignore[reportUnusedImport]
    ServerInfo,
    DetectedSerialDevice,
)
from forcen_bonappetit_api.transport.transport_types import TransportConnectionInfo
from forcen_public_utils.ip_address import IPv4
from forcen_public_utils.loggers.console_logger import ConsoleLogger
import forcen_public_utils.checked as ch


def _is_escape_like(user_input: str) -> bool:
    return user_input.lower() in set(["esc", "e", "escape", "cancel", "c"])


def _is_yes_like(user_input: str) -> bool:
    return user_input.lower() in set(["yes", "ok", "y", "1", "true"])


def _is_quit_like(user_input: str) -> bool:
    return user_input.lower() in set(["q", "quit", "exit"])


class BonAppetitMasterClientCommandLineUI:
    def __init__(
        self, master_ip_address: str, master_command_srv_port: int, master_error_pub_port: int
    ):
        self._ws_master_cli = BonAppetitMasterClient(
            master_ip_address=master_ip_address,
            master_command_srv_port=master_command_srv_port,
            master_error_pub_port=master_error_pub_port,
            default_timeout=20,
        )

    def __enter__(self):
        return self

    def __exit__(self, exception_type, exception_value, exception_traceback):
        self.stop()

    def stop(self):
        self._ws_master_cli.stop()

    def _print_response(self, output: BonAppetitChecked[Any]):
        if output.has_error():
            print(pformat(output.full_error()))
            return output.error() != BonAppetitCode.SERVER_DISCONNECT

        print(f"\nResponse:\n{pformat(output.value())}\n")

    def _get_detected_devices(self) -> BonAppetitChecked[List[DetectedSerialDevice]]:
        user_input = input(f"Rerun detection? (y)es / (n)o / (e)scape: ")
        if _is_escape_like(user_input):
            raise RuntimeError("command canceled")

        print("")

        rerun = _is_yes_like(user_input)
        print(f"Rerunning detection: {rerun}\n")
        return self._ws_master_cli.get_detected_devices(rerun)

    def _get_active_servers(
        self,
    ) -> BonAppetitChecked[Sequence[Union[ServerInfo, PartialServerInfo]]]:
        print("Getting active servers...\n")
        return self._ws_master_cli.get_active_servers()

    def _spawn_server(self) -> BonAppetitChecked[UUID]:
        user_input = input(
            "Spawn server selected. What type of server do you want to spawn?\n"
            "(m)ock server [or leave blank]\n"
            "(t)cp device server\n"
            "(u)art device server\n\n"
        )
        if _is_escape_like(user_input):
            raise RuntimeError("command canceled")

        transport_type = user_input.lower()

        user_input = input("What should the server's IP Address be? Leave blank for 'localhost'\n")
        if _is_escape_like(user_input):
            raise RuntimeError("command canceled")

        server_ip_address = "localhost" if user_input == "" else user_input

        if transport_type in ["m", "mock", ""]:
            return self._ws_master_cli.spawn_server(
                server_ip_address=server_ip_address, 
                transport_type="mock", 
                device_info={},
                enable_sensor_data_logging=False,
                enable_comms_logging=False,
            )

        if transport_type in ["t", "tcp"]:
            user_input = input(
                "Enter BonEcho TCP Server ip address and port as <address>:<port>\n\n"
            )

            ip_address, port = user_input.split(":")
            return self._ws_master_cli.spawn_server(
                server_ip_address=server_ip_address,
                transport_type="tcp",
                device_info={
                    "ip_address": ip_address,
                    "port": int(port),
                    "timeout": 1.0,
                },
                enable_sensor_data_logging=True,
                enable_comms_logging=True,
            )

        if transport_type in ["u", "uart", "serial"]:
            user_input = input("Enter BonEcho serial port and baudrate as <port>:<baudrate>\n\n")
            port, baudrate = user_input.split(":")
            return self._ws_master_cli.spawn_server(
                server_ip_address=server_ip_address,
                transport_type="serial",
                device_info={
                    "baudrate": int(baudrate),
                    "port": port,
                    "timeout": 1.0,
                },
                enable_sensor_data_logging=True,
                enable_comms_logging=True,
            )

        return ch.bad(BonAppetitCode.USER_ERROR, message="Invalid args")

    def _connect_to_existing_server(self) -> BonAppetitChecked[UUID]:
        user_input = input(
            "Specify Master IP address or leave blank if master and server are on the same device:\n"
        )
        if _is_escape_like(user_input):
            raise RuntimeError("command canceled")

        if user_input == "":
            master_ip_address = "localhost"
        else:
            master_ip_address = IPv4.from_str(user_input)
            if master_ip_address is None:
                ConsoleLogger.get().warning("Invalid IP address specified")

        user_input = input("Specify Server IP address and port as <address>:<port> :\n")
        if _is_escape_like(user_input):
            raise RuntimeError("command canceled")

        ip_address, port = user_input.split(":")
        return self._ws_master_cli.connect_to_existing_server(
            master_ip_address=str(master_ip_address),
            server_address=ip_address,
            server_port=int(port),
        )

    def _kill_server(self) -> BonAppetitChecked[None]:
        print("KillServer command selected")
        user_input = input(
            f"Enter the UUID of the server to kill (Get this by calling GetActiveServers). Or enter 'e' to escape/cancel: "
        )
        if _is_escape_like(user_input):
            raise RuntimeError("command canceled")

        try:
            server_uuid = UUID(user_input)
        except ValueError as e:
            print(f"Failed to create UUID from [{user_input}]. Got: [{e}]")
            raise RuntimeError from e

        return self._ws_master_cli.kill_server(server_uuid)

    def _kill_all_servers(self) -> BonAppetitChecked[None]:
        print("KillAllServer command selected\n\n")
        return self._ws_master_cli.kill_all_servers()

    def step(self) -> bool:
        user_input = input(
            f"\n\nEnter command to send to master from list\n"
            f"[1] - call GetDetectedDevices\n"
            f"[2] - call GetActiveServers\n"
            f"[3] - call SpawnServer\n"
            f"[4] - call KillServer\n"
            f"[5] - call KillAllServers\n"
            f"[6] - call ConnectToExistingServer\n"
            f"[e] - escape master client UI\n\n"
            f"[q] - quit script\n\n"
            f"Enter Command:  "
        )
        print(f"\nReceived [{user_input}]\n\n")

        commands = {
            1: self._get_detected_devices,
            2: self._get_active_servers,
            3: self._spawn_server,
            4: self._kill_server,
            5: self._kill_all_servers,
            6: self._connect_to_existing_server,
        }

        if _is_quit_like(user_input) or _is_escape_like(user_input):
            return False

        try:
            command = int(user_input)
        except ValueError:
            print("Improper number was entered, try again...\n\n")
            return True

        try:
            ret = commands[command]()
            self._print_response(ret)
        except Exception as e:  # pylint: disable=broad-exception-caught
            print(f"[{command}] Got Exception:\n{e}\n")

        return True


class BonAppetitClientCommandLineUI:
    def __init__(
        self,
        server_ip_address: str,
        server_command_srv_port: int,
        server_data_pub_port: int,
        server_error_pub_port: int,
        server_replies_pub_port: int,
    ):
        self.cli = BonAppetitClient(
            server_ip_address=server_ip_address,
            server_command_port=server_command_srv_port,
            server_data_pub_port=server_data_pub_port,
            server_error_pub_port=server_error_pub_port,
            server_replies_pub_port=server_replies_pub_port,
        )

    def __enter__(self):
        return self

    def __exit__(self, exception_type, exception_value, exception_traceback):
        self.stop()

    def stop(self):
        self.cli.stop()

    def _print_response(self, output: BonAppetitChecked[Any]):
        if output.has_error():
            print(pformat(output.full_error()))
            return

        print(pformat(output.value()))

    def step(self) -> bool:
        user_input = input(
            f"input raw json to send over websocket to client. \n"
            f"all json should follow the format: \n\n"
            "{ \n"
            "  command: <int> \n"
            "  command_args: <dict> \n"
            "} \n\n"
            f"Alternatively, enter 'e' to return to client selection:\n\n"
        )

        print(f"\nReceived [{user_input}]\n\n")

        if _is_quit_like(user_input) or _is_escape_like(user_input):
            return False

        try:
            json_obj = json.loads(user_input)
        except (json.JSONDecodeError, ValueError, TypeError):
            ConsoleLogger.get().warning("Failed to parse input as proper JSON, try again...\n\n")
            return True

        try:
            self.cli._client.send(  # pyright: ignore[reportPrivateUsage]
                json.dumps(json_obj)
            )  # pyright: ignore [reportPrivateUsage]
        except (RuntimeError, ws_excp.ConnectionClosed, TypeError) as e:
            print(f"failed to send command to websocket server. Got\n\n{e}")
            return True
        try:
            data = self.cli._client.recv(10.0)  # pyright: ignore [reportPrivateUsage]
        except TimeoutError as e:
            print(f"failed to recv command from websocket server. Got\n\n{e}")
            return True
        print(json.dumps(json.loads(data), indent=2))
        print("\n")
        return True


def main():
    parser = argparse.ArgumentParser("bonappetit_websocket_master_tester")


    parser.add_argument(
        "websocket_master_ip_address", help="API Master IP address"
    )
    parser.add_argument(
        "websocket_master_command_srv_port", help="API Master Command Srv Port"
    )

    parser.add_argument(
        "websocket_master_error_pub_port", help="API Master Error Pub Port"
    )

    parser.add_argument(
        "--terse", default=False, action="store_true", help="Whether logging should be terse or not"
    )

    args = parser.parse_args()

    ConsoleLogger.initialize_standard_logger(
        app_name="bonappetit_client_command_line_ui", verbose=not args.terse
    )

    ws_master_cli_ui = BonAppetitMasterClientCommandLineUI(
        master_ip_address=args.websocket_master_ip_address,
        master_command_srv_port=int(args.websocket_master_command_srv_port),
        master_error_pub_port=int(args.websocket_master_error_pub_port),
    )

    active_client = ws_master_cli_ui

    def check_cli_conn_and_get_conn_info(clients: List[BonAppetitClientCommandLineUI]):
        indices_to_delete = []
        transport_conn_infos = []
        for ii, cli in enumerate(clients):
            maybe_transport_conn_info = cli.cli.get_transport_connection_info()
            if maybe_transport_conn_info.has_error():
                indices_to_delete.append(ii)
                continue

            transport_conn_infos.append(maybe_transport_conn_info.value())

        for ii in sorted(indices_to_delete, reverse=True):
            del clients[ii]

        return clients, transport_conn_infos

    def format_transport_conn_info(
        transport_conn_infos: TransportConnectionInfo,
    ) -> Optional[str]:
        ret_str = f"transport_type: {transport_conn_infos.transport_type}"
        if "ip_address" in transport_conn_infos.conn_info:
            ret_str += f"\n\t\tport: {transport_conn_infos.conn_info['ip_address']}"
        if "port" in transport_conn_infos.conn_info:
            ret_str += f"\n\t\tport: {transport_conn_infos.conn_info['port']}"
        return ret_str

    clients: List[BonAppetitClientCommandLineUI] = []
    try:
        while True:
            res = active_client.step()
            if not res:

                def _cli_filter(cli: BonAppetitClientCommandLineUI, server_infos: List[ServerInfo]):
                    ip_address = cli.cli.server_ip_address
                    server_port = cli.cli.server_command_port
                    publisher_port = cli.cli.server_data_pub_port
                    res = any(
                        [
                            info.ip_address == ip_address
                            and info.commands_srv_port == server_port
                            and info.sensor_data_pub_port == publisher_port
                        ]
                        for info in server_infos
                    )
                    if not res:
                        cli.stop()
                        return False
                    return True

                while True:
                    clients = []

                    # Create new clients based on server infos received from BonAppetitMaster
                    maybe_active_servers = (
                        ws_master_cli_ui._ws_master_cli.get_active_servers()  # pyright: ignore [reportPrivateUsage]
                    )
                    if maybe_active_servers.has_error():
                        break

                    server_infos = [
                        ii for ii in maybe_active_servers.value() if isinstance(ii, ServerInfo)
                    ]
                    for server_info in server_infos:
                        if any(
                            [
                                (
                                    cl.cli.server_ip_address == server_info.ip_address
                                    and cl.cli.server_command_port == server_info.commands_srv_port
                                )
                                for cl in clients
                            ]
                        ):
                            continue

                        clients.append(
                            BonAppetitClientCommandLineUI(
                                server_ip_address=server_info.ip_address,
                                server_command_srv_port=server_info.commands_srv_port,
                                server_data_pub_port=server_info.sensor_data_pub_port,
                                server_error_pub_port=server_info.errors_pub_port,
                                server_replies_pub_port=server_info.replies_pub_port,
                            )
                        )

                    # Remove clients that don't match any server_infos received from BonAppetitMaster
                    clients = list(filter(lambda cli: _cli_filter(cli, server_infos), clients))

                    # Remove clients that when we try to get connection info from them, we fail
                    clients, transport_conn_infos = check_cli_conn_and_get_conn_info(clients)
                    cli_transport_conn_info_formatted = "\n".join(
                        [
                            f"[{ii}] - {format_transport_conn_info(info)}"
                            for ii, info in enumerate(transport_conn_infos)
                        ]
                    )
                    user_input = input(
                        f"\n\nChoose which client to use:\n\n"
                        f"[m] - Master Client\n"
                        f"{cli_transport_conn_info_formatted}\n"
                        f"[q] - to quit script completely\n\n"
                    )

                    if _is_quit_like(user_input) or _is_escape_like(user_input):
                        sys.exit()

                    if user_input.lower() in set(["m", "master"]):
                        active_client = ws_master_cli_ui
                        break

                    try:
                        cli_num = int(user_input)
                    except ValueError:
                        print("\nInvalid Client selected, try again")
                        continue

                    if cli_num >= len(clients):
                        print("\nInvalid Client selected, try again")
                        continue

                    active_client = clients[cli_num]
                    break

    except KeyboardInterrupt:
        pass
    finally:
        for ba_cli in clients:
            ba_cli.stop()
        ws_master_cli_ui.stop()


if __name__ == "__main__":
    main()
