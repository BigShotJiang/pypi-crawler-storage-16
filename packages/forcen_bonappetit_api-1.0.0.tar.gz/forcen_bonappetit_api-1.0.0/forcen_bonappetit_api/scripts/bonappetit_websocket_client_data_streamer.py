import argparse

import websockets.sync.client as ws_cli

from forcen_bonappetit_api.bonappetit_websocket_client import BonAppetitClient
from forcen_bonappetit_api.bonappetit_websocket_helpers import send_and_recv_data
from forcen_bonappetit_api.bonappetit_websocket_master_messages import (
    GetActiveServersCommandArgs,
    GetActiveServersResponseData,
    ServerInfo,
    WSMasterCommand,
)
from forcen_public_utils.loggers.console_logger import ConsoleLogger
from forcen_public_utils.websocket_uri import make_websocket_uri


def main():
    parser = argparse.ArgumentParser("bonappetit_websocket_master_tester")

    parser.add_argument(
        "websocket_master_ip_address", help="API Master IP Address"
    )
    parser.add_argument("websocket_master_command_srv_port", help="API Master Command Srv Port")
    parser.add_argument("-r", "--realtime_stream", action="store_true", default=False, help="whether to use websocket or udp for sensor data")
    parser.add_argument("--terse", action="store_true", default=False, help="reducing logging output")

    args = parser.parse_args()

    ConsoleLogger.initialize_standard_logger(
        app_name="bonappetit_websocket_client_data_streamer", verbose=not args.terse
    )

    try:
        ws_master_cli = ws_cli.connect(
            make_websocket_uri(args.websocket_master_ip_address, int(args.websocket_master_command_srv_port))
        )
    except ConnectionRefusedError as e:
        raise RuntimeError(f"failed to connect to Forcen API master.") from e

    ConsoleLogger.get().info(f"This script communicates with a Forcen API master")

    try:
        while True:
            maybe_active_servers = send_and_recv_data(
                client=ws_master_cli,
                command=WSMasterCommand.GET_ACTIVE_SERVERS,
                response_type=GetActiveServersResponseData,
                args=GetActiveServersCommandArgs(),
                parse_func=lambda dd: dd.servers,
            )

            if maybe_active_servers.has_error():
                raise RuntimeError(
                    f"failed to get active servers. Got\n {maybe_active_servers.error()}\n{maybe_active_servers.message}"
                )

            active_servers = [ii for ii in maybe_active_servers.value() if isinstance(ii, ServerInfo)]

            options = "\n".join(
                [
                    f"[{ii}] - "
                    f"{ss.ip_address}:"
                    f"{ss.commands_srv_port}:"
                    f"{ss.sensor_data_pub_port}"
                    for ii, ss in enumerate(active_servers)
                ]
            )

            raw_input = input(
                f"Found the following servers\n\n"
                f"{options}\n\n"
                f"Enter number to view data streamed by that server:\n\n"
            )

            try:
                server_num = int(raw_input)
            except ValueError:
                ConsoleLogger.get().info(f"Failed to parse input into number. Try again...")
                continue

            with BonAppetitClient(
                server_ip_address=active_servers[server_num].ip_address,
                server_command_port=active_servers[server_num].commands_srv_port,
                server_data_pub_port=active_servers[server_num].sensor_data_pub_port,
                server_error_pub_port=active_servers[server_num].errors_pub_port,
                server_replies_pub_port=active_servers[server_num].replies_pub_port,
            ) as cli:
                counter = 0
                def rtd_cb(packet):
                    nonlocal counter
                    ConsoleLogger.get().info(f"{counter:02} - {packet}")
                    if counter == 99:
                        counter = 0
                    counter += 1

                def err_cb(err):
                    ConsoleLogger.get().info(f"got error: {err}")

                if cli.attach_error_callback(err_cb).has_error():
                    raise RuntimeError("failed to attach callback for errors")
                
                if cli.attach_sensor_data_callback(rtd_cb, realtime_stream=args.realtime_stream).has_error():
                    raise RuntimeError("failed to attach callback for sensor data")
                
                input("press any key to quit...")

    except KeyboardInterrupt:
        pass
    finally:
        ConsoleLogger.get().info("cleaning up API client")
        ws_master_cli.close()

if __name__ == "__main__":
    main()
