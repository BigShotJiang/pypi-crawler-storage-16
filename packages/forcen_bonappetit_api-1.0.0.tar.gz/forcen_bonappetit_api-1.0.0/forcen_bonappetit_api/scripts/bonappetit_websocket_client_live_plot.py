#!/usr/bin/env python3
import argparse
import collections
import threading
import time
from typing import Deque, List, Tuple

import matplotlib.pyplot as plt
import matplotlib.animation as animation
import websockets.sync.client as ws_cli

from forcen_bonappetit_api.bonappetit_websocket_client import BonAppetitClient
from forcen_bonappetit_api.bonappetit_websocket_helpers import send_and_recv_data
from forcen_bonappetit_api.bonappetit_websocket_master_messages import (
    GetActiveServersCommandArgs,
    GetActiveServersResponseData,
    ServerInfo,
    WSMasterCommand,
)
from forcen_bonappetit_api.protocol.protocol_transport_types import RTDPacketStamped
from forcen_public_utils.loggers.console_logger import ConsoleLogger
from forcen_public_utils.websocket_uri import make_websocket_uri

# ----------------- Plot / buffer config ----------------- #

BUFFER_SIZE = 2000          # points to keep in buffer
CHANNEL_INDEX = 1           # which element of .data to plot (0..4)
PLOT_UPDATE_INTERVAL_MS = 50  # ms between plot updates
TIME_WINDOW = 5.0           # seconds of history to show

# Shared buffer: (t, value)
_live_buffer: Deque[Tuple[float, float]] = collections.deque(maxlen=BUFFER_SIZE)
_buffer_lock = threading.Lock()
_ANI = None


# -------------------- RTD callback ---------------------- #

def rtd_cb(packets: List[RTDPacketStamped]) -> None:
    """
    Called by BonAppetitClient when RTD packets arrive.
    Buffers one selected channel for plotting.
    """
    if not packets:
        return

    with _buffer_lock:
        for pkt in packets:
            data = getattr(pkt, "data", None)
            ts = getattr(pkt, "timestamp", None)
            if data is None or ts is None:
                continue
            if len(data) <= CHANNEL_INDEX:
                continue

            value = float(data[CHANNEL_INDEX])
            _live_buffer.append((float(ts), value))


def err_cb(err) -> None:
    ConsoleLogger.get().info(f"got error: {err}")


# ---------------------- Plotting ------------------------ #

def start_live_plot() -> None:
    global _ANI   # <-- keep reference alive globally

    fig, ax = plt.subplots()
    line, = ax.plot([], [], lw=1.0)

    ax.set_xlabel("Time [s] (relative)")
    ax.set_ylabel(f"Channel {CHANNEL_INDEX}")
    ax.set_title("Live RTD Stream")

    def init():
        line.set_data([], [])
        return line,

    def update(_frame):
        with _buffer_lock:
            if not _live_buffer:
                return line,

            ts, vals = zip(*_live_buffer)

        t0 = ts[0]
        t_rel = [t - t0 for t in ts]
        t_max = t_rel[-1]

        t_min = max(0.0, t_max - TIME_WINDOW)
        start_idx = next((i for i, tt in enumerate(t_rel) if tt >= t_min), 0)

        t_plot = t_rel[start_idx:]
        v_plot = vals[start_idx:]

        line.set_data(t_plot, v_plot)

        ax.set_xlim(
            t_plot[0] if len(t_plot) > 1 else 0.0,
            t_plot[-1] if len(t_plot) > 1 else TIME_WINDOW,
        )

        ymin, ymax = min(v_plot), max(v_plot)
        if ymin == ymax:
            ymin -= 1
            ymax += 1
        ax.set_ylim(ymin, ymax)

        return line,

    # IMPORTANT: store in global variable
    _ANI = animation.FuncAnimation(
        fig,
        update,
        init_func=init,
        interval=PLOT_UPDATE_INTERVAL_MS,
        blit=False,
        cache_frame_data=False,
    )

    plt.tight_layout()
    plt.show()

# ------------------- Main / BonAppetit ------------------ #

def pick_server(ws_master_cli) -> ServerInfo:
    """
    Query websocket master once and let user pick a server.
    """
    maybe_active_servers = send_and_recv_data(
        client=ws_master_cli,
        command=WSMasterCommand.GET_ACTIVE_SERVERS,
        response_type=GetActiveServersResponseData,
        args=GetActiveServersCommandArgs(),
        parse_func=lambda dd: dd.servers,
    )

    if maybe_active_servers.has_error():
        raise RuntimeError(
            f"failed to get active servers. Got\n"
            f"{maybe_active_servers.error()}\n{maybe_active_servers.message}"
        )

    active_servers = [ii for ii in maybe_active_servers.value() if isinstance(ii, ServerInfo)]
    if not active_servers:
        raise RuntimeError("no active servers found")

    options = "\n".join(
        [
            f"[{idx}] - "
            f"{srv.ip_address}:"
            f"{srv.commands_srv_port}:"
            f"{srv.sensor_data_pub_port}"
            for idx, srv in enumerate(active_servers)
        ]
    )

    print(
        f"Found the following servers\n\n"
        f"{options}\n"
    )

    while True:
        raw_input_str = input("Enter number to view data streamed by that server: ")
        try:
            server_num = int(raw_input_str)
        except ValueError:
            ConsoleLogger.get().info("Failed to parse input into number. Try again...")
            continue

        if 0 <= server_num < len(active_servers):
            return active_servers[server_num]

        ConsoleLogger.get().info("Index out of range. Try again...")


def main():
    parser = argparse.ArgumentParser("bonappetit_live_stream_plotter")

    parser.add_argument(
        "websocket_master_ip_address",
        help="bonappetit websocket master ip address",
    )
    parser.add_argument(
        "websocket_master_port",
        help="bonappetit websocket master port",
        type=int,
    )
    parser.add_argument(
        "-r",
        "--realtime_stream",
        action="store_true",
        default=False,
        help="whether to use websocket or udp for sensor data",
    )
    parser.add_argument(
        "--terse",
        action="store_true",
        default=False,
        help="reducing logging output",
    )

    args = parser.parse_args()

    ConsoleLogger.initialize_standard_logger(
        app_name="bonappetit_websocket_live_plotter",
        verbose=not args.terse,
    )

    # -------- Connect to websocket master and pick server -------- #
    try:
        ws_master_cli = ws_cli.connect(
            make_websocket_uri(
                args.websocket_master_ip_address,
                int(args.websocket_master_port),
            )
        )
    except ConnectionRefusedError as e:
        raise RuntimeError("failed to connect to websocket master") from e

    ConsoleLogger.get().info(
        "This script communicates with a bonappetit websocket master"
    )

    try:
        server = pick_server(ws_master_cli)
    finally:
        ConsoleLogger.get().info("Closing websocket master connection")
        ws_master_cli.close()

    ConsoleLogger.get().info(
        f"Connecting to server at {server.ip_address}:"
        f"{server.commands_srv_port}:"
        f"{server.sensor_data_pub_port}"
    )

    # -------- Start BonAppetitClient + plotting -------- #
    try:
        with BonAppetitClient(
            server_ip_address=server.ip_address,
            server_command_port=server.commands_srv_port,
            server_data_pub_port=server.sensor_data_pub_port,
            server_error_pub_port=server.errors_pub_port,
            server_replies_pub_port=server.replies_pub_port,
        ) as cli:

            if cli.attach_error_callback(err_cb).has_error():
                raise RuntimeError("failed to attach callback for errors")

            if cli.attach_sensor_data_callback(
                rtd_cb,
                realtime_stream=args.realtime_stream,
            ).has_error():
                raise RuntimeError("failed to attach callback for sensor data")

            ConsoleLogger.get().info(
                "Live plotting started. Close the plot window to exit."
            )

            # Blocking call; BonAppetitClient internal threads keep filling the buffer.
            start_live_plot()

    except KeyboardInterrupt:
        ConsoleLogger.get().info("Keyboard interrupt, exiting.")
    finally:
        ConsoleLogger.get().info("Done.")


if __name__ == "__main__":
    main()
