import dataclasses
import enum
from typing import Optional, Union, Dict, Any


# TODO (swapnil) - This is specific to non-frame modes of transport (TCP/UDP/RS232) and is not
# universal. Rename this to make that clear, and encapsulate in a more generic dataclass
@dataclasses.dataclass(frozen=True)
class ControlCharPair:
    start: Optional[bytes]
    end: bytes

    @staticmethod
    def line_breaks() -> "ControlCharPair":
        return ControlCharPair(None, b"\n")


@dataclasses.dataclass
class TransportConnectionInfo:
    transport_type: str
    conn_info: Dict[str, Any]


class TransportMessageType(enum.Enum):
    """
    Some Transports sort their data frames into types. For example, CANopen will use the ID bits
    to specify
    """

    REQUEST = enum.auto()
    """A request sent by a client in a client<->server interaction"""

    RESPONSE = enum.auto()
    """A response sent by a server in a client<->server interaction"""

    ASYNC_SEND = enum.auto()
    """An (unprompted) transmission from a node. There may or may not be receivers"""

    ASYNC_ERROR = enum.auto()
    """
    An error (unprompted) generated from a device. This is NOT for errors sent when *requested* 
    by a client
    """

    HEARTBEAT = enum.auto()
    """
    A keep-alive signal sent (unprompted) from a device. This is NOT for heartbeats sent when 
    *requested* by a client
    """


# TODO (swapnil) - rename this to something like `GenericPacket` and move it out of
# TransportInterface. This should be the data that a Forcen-Protocol encodes to (and parses from).
# The `TransportPacket`-type object should contain the `GenericPacket` + addition metadata about a
# device to facilitate the transmission (like address, device id, port, etc.). That should live here
@dataclasses.dataclass(frozen=True)
class SendTransportPacket:
    """
    All transport interface children transact in this dataclass. All implementations should be able
    to construct the specific frames/packets required by their implementation from the data
    contained in this object. The reverse must also be possible. Any protocol built on top of these
    transports will provide data using this, allow for the higher level protocols to interoperate
    with multiple transports (if they're compatible)

    NOTE (swapnil): more fields can be added here if a transport interface child requires it, but
    be judicious as all higher level protocols (which presumably are working without this
    additional field) will need to provide it as well.
    """

    payload: bytes
    """the body of data to be sent. In simple transports, this is all that's required"""


# TODO (swapnil) - once the `SendTransportPacket` is renamed to `GenericPacket`, this can become
# just `TransportPacket`.
@dataclasses.dataclass(frozen=True)
class RecvTransportPacket:
    """
    All transport interface children transact in this dataclass. All implementations should be able
    to construct the specific frames/packets required by their implementation from the data
    contained in this object. The reverse must also be possible. Any protocol built on top of these
    transports will provide data using this, allow for the higher level protocols to interoperate
    with multiple transports (if they're compatible)

    NOTE (swapnil): more fields can be added here if a transport interface child requires it, but
    be judicious as all higher level protocols (which presumably are working without this
    additional field) will need to provide it as well.
    """

    payload: bytes
    """the body of data that were received. In simple transports, this is all we'll get"""

    control_chars: Optional[ControlCharPair] = None
    """if the payload received was surrounded by control chars, they'll be included here"""

    recv_address: Optional[Union[str, int]] = None
    """
    Some transports maybe receive data from multiple devices. If possible, this should contain the
    address of device from where data was received. It should be useful when using the write func
    to send data to the same device later 
    """

    recv_port: Optional[int] = None
    """
    Some transports maybe receive data from multiple processes on a given device. If possible, this
    should contain the id of the process from where data was received. It should be useful when 
    using the write func to send data to the same process later 
    """


@dataclasses.dataclass
class WriteMetaInfo:
    address: Optional[Union[str, int]] = None
    """
    In multi-device communication transports, this is needed to identify a device. 
    For example, a UDP connection requires an IP address
    
    NOTE: Transports which are inherently 1-to-1 typically won't need this
    """

    port: Optional[int] = None
    """
    In a communication transport which distinguishes between processes on a given device, this is 
    needed to identify the process.

    For example, a UDP connection requires a port

    NOTE: Transports which are inherently 1-to-1 typically won't need this
    """
