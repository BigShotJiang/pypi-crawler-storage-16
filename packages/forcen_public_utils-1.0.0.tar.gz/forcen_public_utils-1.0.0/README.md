# forcen_public_utils

forcen_public_utils contains reusable helpers and shared abstractions that streamline development across multiple Forcen projects.
It is designed to stay lightweight, dependency-minimal, and suitable as a foundational layer for other packages.


## License
Copyright (c) 2019 Forcen Inc. All Rights Reserved.
Restriction on Use, Publication or Disclosure of Proprietary Information.
Unauthorized copying, distribution, or use is strictly prohibited.