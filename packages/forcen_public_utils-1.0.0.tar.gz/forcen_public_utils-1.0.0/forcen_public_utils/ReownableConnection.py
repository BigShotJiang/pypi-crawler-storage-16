"""
NOTE (swapnil) - This class is deprecated since the new forcen_bonapptit will use websockets, not
python multiprocessing

Motivation:
- Thin wrapper around a Connection instance to enable/disable usage
- This is required in cases where destructing/reconstructing the Connection instance is unacceptable
"""

from typing import Any, Optional
from multiprocessing.connection import Connection

class ReownableConnection():
    _connection: Connection
    _is_owned: bool
    
    def __init__(self, connection: Connection):
        self._connection = connection
        self._is_owned = False

    def claim(self) -> None:
        self._is_owned = True

    def release(self) -> None:
        self._is_owned = False

    def is_claimed(self) -> bool:
        return self._is_owned

    def send(self, msg: Any) -> None:
        self._connection.send(msg)

    def recv(self) -> Any:
        return self._connection.recv()

    def poll(self, timeout: Optional[float] = 0) -> bool:
        return self._connection.poll(timeout)