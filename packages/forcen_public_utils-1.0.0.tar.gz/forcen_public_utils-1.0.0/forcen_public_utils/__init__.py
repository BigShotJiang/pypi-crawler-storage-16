# Ignore interactive_thread in documentation, as it fails due to TypeVarTuple
__pdoc__ = {"interactive_thread":False}