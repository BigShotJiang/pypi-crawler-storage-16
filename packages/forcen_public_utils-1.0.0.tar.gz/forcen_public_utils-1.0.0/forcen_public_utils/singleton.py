"""
Motivation:

Provide a base metaclass object which allows for creation of a singleton.
"""


class Singleton(type):
    """Metaclass implementation of a singleton.

    See https://stackoverflow.com/questions/6760685/what-is-the-best-way-of-implementing-singleton-in-python.

    Usage:
        class MyClass(metaclass=Singleton)
            ...

        MyClass.instantiated() # False
        MyClass(*args, **kwargs)
        MyClass.instantiated() # True
        MyClass() # returns the instance initialized with (*args, **kwargs)
    """

    _instances = {}

    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
        return cls._instances[cls]

    def instantiated(cls) -> bool:
        return cls in cls._instances
