from typing import List

def split_string(text: str, max_length: int = 35) -> List[str]:
    # Ensure ':' is followed by a new line for consistent breaking
    text = text.replace(":", ":\n")
    lines = text.split('\n')  # Split based on explicit newlines first
    wrapped_lines = []

    for line in lines:
        words = line.split()  # Split the current line into words
        current_line = []

        for word in words:
            # Check if adding the next word would exceed max_length
            if sum(len(w) for w in current_line) + len(word) + len(current_line) <= max_length:
                current_line.append(word)
            else:
                wrapped_lines.append(' '.join(current_line))
                current_line = [word]

        if current_line:
            wrapped_lines.append(' '.join(current_line))

    return wrapped_lines

# def _calculate_score(char_a: str, char_b) -> float:
#     return (
#         (1 / (abs(ord(char_a) - ord(char_b)) + 1))
#         * ((num_char - idx - 0.5) / num_char)
#         * 2
#         / num_char
#     )

# def find_closest_match(query: str, options: List[str], threshold: float=0.7) -> Optional[str]:
#     matched = []
#     best_match = ["", 0]
#     for key_idx, key in enumerate(options):
#         matched.append((key, 0))
#         num_char = min(len(query), len(key))
#         if num_char <= 0:
#             continue
#         # Compare each character - Major characters weighted more - metric based on ASCII value
#         for idx, (e_c, k_c) in enumerate(zip(query, key)):
#             matched[key_idx][1] += (
#                 (1 / (abs(ord(e_c) - ord(k_c)) + 1))
#                 * ((num_char - idx - 0.5) / num_char)
#                 * 2
#                 / num_char
#             )
#         # Determine the best match
#         if matched[key_idx][1] >= best_match[1]:
#             best_match = matched[key_idx]
#     # If the best match is greater than threshold - use the version found
#     if best_match[1] > threshold:
#         return best_match[0]
#     else:
#         return None
