import time
from typing import TypeVar, Callable
from forcen_public_utils.rate import Rate

_T = TypeVar("_T")


def try_for(predicate: Callable[[], bool], duration: float, rate: Rate):
    start_time = time.time()
    while time.time() - start_time < duration:
        if predicate():
            return True
        
        rate.sleep()
    return False