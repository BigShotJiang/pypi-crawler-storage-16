from typing import Optional, TypeVar

_T = TypeVar("_T")


def not_none(arg: Optional[_T]) -> _T:
    assert arg is not None
    return arg
