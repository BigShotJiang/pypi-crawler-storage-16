def make_websocket_uri(address: str, port: int):
    return f"ws://{address}:{port}"

def make_localhost_websocket_uri(port: int):
    return f"ws://localhost:{port}"