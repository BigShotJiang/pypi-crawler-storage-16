def main():
    print("Hello from formdt!")


if __name__ == "__main__":
    main()
