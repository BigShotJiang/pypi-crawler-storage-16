from .SynthDef import SynthDef
from .synthdefs import *
