"""FPSupport provides libraries to assist in fp programming."""
