from pathlib import Path

SETTINGS_CONFIG_DICT = dict(
    case_sensitive=True,
    env_file=Path(".fractal_server.env"),
    extra="ignore",
)
