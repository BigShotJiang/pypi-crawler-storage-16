"""Session module unit tests."""
