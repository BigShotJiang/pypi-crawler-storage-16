# <TOPIC_TITLE> - 内容草稿

> 生成时间：<YYYY-MM-DD HH:MM>
> 素材来源：outputs/01_draft.jsonl

---

## 收集的观点

### 观点类 A：<CATEGORY_LABEL>

- @<USERNAME_1>: "<TWEET_CONTENT_QUOTE>"
  - 来源：<REAL_TWEET_URL>
  - scroll_to: "<UNIQUE_TEXT_FRAGMENT>"

- @<USERNAME_2>: "<TWEET_CONTENT_QUOTE>"
  - 来源：<REAL_TWEET_URL>
  - scroll_to: "<UNIQUE_TEXT_FRAGMENT>"

### 观点类 B：<CATEGORY_LABEL>

- @<USERNAME_3>: "<TWEET_CONTENT_QUOTE>"
  - 来源：<REAL_TWEET_URL>
  - scroll_to: "<UNIQUE_TEXT_FRAGMENT>"

### 观点类 C：<CATEGORY_LABEL>

- @<USERNAME_4>: "<TWEET_CONTENT_QUOTE>"
  - 来源：<REAL_TWEET_URL>
  - scroll_to: "<UNIQUE_TEXT_FRAGMENT>"

---

## 我的评论

<HOST_COMMENTARY_AFTER_DISCUSSION>

---

## 素材索引（供后续录制使用）

| 序号 | 作者 | URL | scroll_to_text | 类型 |
|-----|------|-----|----------------|------|
| 1 | @<USERNAME> | <REAL_URL> | "<TEXT_FRAGMENT>" | tweet/comment |
| 2 | @<USERNAME> | <REAL_URL> | "<TEXT_FRAGMENT>" | tweet/comment |

---

**注意**：
- 所有 URL 必须是真实可访问的链接
- scroll_to_text 用于后续录制时定位元素
- 观点分类标签应简洁概括该类观点的核心立场
