CREATE TABLE tv_order (
    id UUID PRIMARY KEY,
    data JSONB
);
