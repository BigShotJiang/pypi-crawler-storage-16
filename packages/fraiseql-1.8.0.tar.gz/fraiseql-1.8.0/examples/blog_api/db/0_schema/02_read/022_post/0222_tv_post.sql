CREATE TABLE tv_post (
    id UUID PRIMARY KEY,
    data JSONB
);
