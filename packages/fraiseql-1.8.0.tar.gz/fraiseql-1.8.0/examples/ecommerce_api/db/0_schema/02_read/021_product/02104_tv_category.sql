CREATE TABLE tv_category (
    id UUID PRIMARY KEY,
    data JSONB
);
