#!/bin/sh
rm -r conditioned_filters/ predictions/ report/
