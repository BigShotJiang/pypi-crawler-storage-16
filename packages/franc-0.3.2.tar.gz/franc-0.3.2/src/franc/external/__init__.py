"""Wrappers for other implementations of filtering techniques."""

from .spicypy_wf import SpicypyWienerFilter

__all__ = ["SpicypyWienerFilter"]
