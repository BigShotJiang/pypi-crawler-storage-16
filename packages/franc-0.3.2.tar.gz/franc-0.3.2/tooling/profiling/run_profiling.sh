#/bin/sh
python profile.py
python profile_singlethread.py
python plot.py
