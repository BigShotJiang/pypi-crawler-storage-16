"""Helpers for interacting with the FranklinWH API."""

from typing import Final

DEFAULT_URL_BASE: Final[str] = "https://energy.franklinwh.com/"
