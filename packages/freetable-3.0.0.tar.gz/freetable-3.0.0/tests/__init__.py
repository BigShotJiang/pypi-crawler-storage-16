"""Tests for freetable package."""
