from freqtrade.config_schema.config_schema import CONF_SCHEMA


__all__ = ["CONF_SCHEMA"]
