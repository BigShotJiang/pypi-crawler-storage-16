# Dispatch Highlevel Interface Release Notes

## Summary

This release just updates some dependencies to allow compatibility with newer versions.
