# Frequenz Microgrid Component Graph Library Release Notes

## New Features

- Grid formulas now use single successor meters as fallback components for meters attached to the grid.
- Adds wind turbine bindings