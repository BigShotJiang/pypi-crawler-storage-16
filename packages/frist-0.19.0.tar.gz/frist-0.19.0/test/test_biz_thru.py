"""
Tests verifying inclusive `thru` behavior for Biz units.

These ensure `ns.thru(start, end)` produces the correct half-open semantics
by advancing the end by 1 compared to `in_`.

Style: Arrange / Act / Assert (AA) per project `codeguide.md`.
"""

import datetime as dt

from frist._biz import Biz

BIZ_UNITS = ["biz_day", "work_day", "fis_qtr", "fis_year"]


def test_biz_thru_behavior():
    """
    Test inclusive `thru` behavior for Biz unit adapters.

    Verifies that for each Biz unit (`biz_day`, `work_day`, `fis_qtr`, `fis_year`),
    in_(0) returns True and in_(-1) returns False when target and reference are set
    to a weekday. Confirms correct half-open semantics for current and previous units.
    """
    # Arrange: choose a weekday so business/working-day checks are True
    ref = dt.datetime(2025, 3, 14, 12, 34, 56)
    biz = Biz(target_dt=ref, ref_dt=ref)

    # Act / Assert
    for prop in BIZ_UNITS:
        ns = getattr(biz, prop)

        # Golden check: when ref==target on a weekday, current unit True, previous False
        assert ns.in_(0) is True
        assert ns.in_(-1) is False

        # inclusive slice syntax removed; verify call form only
