"""
The L{fritter.repeat.rules} package contains various implementations of
L{fritter.boundaries.RecurrenceRule}.
"""
