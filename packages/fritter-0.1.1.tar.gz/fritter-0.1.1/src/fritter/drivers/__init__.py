"""
Implementations of L{fritter.boundaries.TimeDriver} and
L{fritter.boundaries.AsyncDriver}.
"""
