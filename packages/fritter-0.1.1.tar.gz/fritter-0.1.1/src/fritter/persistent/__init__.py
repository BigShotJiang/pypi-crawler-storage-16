"""
Package of mechanisms for persisting schedulers and timed calls.
"""
