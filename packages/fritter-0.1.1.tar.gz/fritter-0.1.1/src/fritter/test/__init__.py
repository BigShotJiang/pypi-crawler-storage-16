# -*- test-case-name: fritter.test -*-
"""
Test cases.
"""
