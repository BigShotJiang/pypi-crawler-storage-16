from .frogml_suggestion_exception import FrogmlSuggestionException


class FrogmlRemoteBuildFailedException(FrogmlSuggestionException):
    pass
