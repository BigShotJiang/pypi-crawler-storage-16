# Frogml Inference

FrogML is an end-to-end production ML platform designed to allow data scientists to build, deploy, and monitor their models in production with minimal engineering friction.
FrogML Inference contains tools that allow predicting against the FrogML Platform
