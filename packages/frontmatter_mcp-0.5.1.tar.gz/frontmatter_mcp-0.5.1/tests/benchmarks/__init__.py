"""Benchmark tests for frontmatter-mcp."""
