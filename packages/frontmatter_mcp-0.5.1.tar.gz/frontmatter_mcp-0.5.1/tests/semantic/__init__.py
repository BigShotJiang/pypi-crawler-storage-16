"""Tests for semantic search module."""
