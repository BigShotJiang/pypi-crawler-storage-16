# 𝓕(Rₓₓ)

A library to produce and analyze weather radar moments and spectra from I/Q data.

---

### Installation

```bash
pip install frxx
```