# 𝓕(Rₓₓ)-view

A library to visualize and edit radar data. Support for custom handlers is planned.

---

### Installation

```bash
pip install frxx-view
```
