FscanSummaryPage
----------------

Can be run from the command line using

.. code-block:: bash

    FscanSummaryPage <arguments>

This will produce the Summary Page style webpages with Fscan output plots

.. automodule:: fscan.html
   :members:
   :show-inheritance:
