fscan.process.autotag module
----------------------------

Can be run from the command line using

.. code-block:: bash

    FscanAutoTag <arguments>

The output will be two files containing autotagged frequencies that are found as peaks in the frequency-domain data.

API
^^^

.. automodule:: fscan.process.autotag
   :members:
   :show-inheritance:
