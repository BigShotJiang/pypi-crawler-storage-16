fscan.process.linefinder module
-------------------------------

This module enables finding peak features in frequency-domain spectral data.
One should pass the spectral data to this function and the output may be passed to other functions like ``fscan.process.combfinder.find_combs()``.

API
^^^

.. automodule:: fscan.process.linefinder
   :members:
   :show-inheritance:
