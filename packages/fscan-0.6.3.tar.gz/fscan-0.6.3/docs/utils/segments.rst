fscan.utils.segments module
---------------------------

This module contains functionality to query the data quality segment database (DQSegDB) for times when the detectors are operating with certain flags (like DMT-ANALYSIS_READY).

API
^^^

.. automodule:: fscan.utils.segments
   :members:
   :show-inheritance:
