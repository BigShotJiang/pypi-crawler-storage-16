# fsspeckit.core.filesystem

> **Package Structure Note:** fsspeckit has been refactored to use a package-based structure. The preferred import path is now `from fsspeckit.core import filesystem`, though legacy imports still work.

::: fsspeckit.core.filesystem