"""FTC CLI - Team Management Tool"""

__version__ = "0.1.1"
__author__ = "Kashyap Sukshavasi"
__email__ = "ksukshavasi@gmail.com"