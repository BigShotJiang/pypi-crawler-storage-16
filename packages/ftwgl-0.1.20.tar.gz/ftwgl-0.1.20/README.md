# FTW Python Client

Used to make requests with an API Key to the FTWGL backend.

## Release Process

1. Increment version in setup.py
2. Run `python setup.py sdist`
3. Run `twine upload dist/$VERSION`
