down
====

.. cappa:: fujin.commands.down.Down
   :style: terminal
   :terminal-width: 0