prune
======

.. cappa:: fujin.commands.prune.Prune
   :style: terminal
   :terminal-width: 0

