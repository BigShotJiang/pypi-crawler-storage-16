fujin documentation
===================


.. important::

   This a work in progress, not ready for production use yet.

.. raw:: html

   <script src="https://asciinema.org/a/687274.js" id="asciicast-687274" async="true"></script>

.. include:: ../README.md
   :parser: myst_parser.sphinx_
   :start-after: <!-- content:start -->
   :end-before: <!-- content:end -->

.. toctree::
   :maxdepth: 2
   :hidden:

   installation
   howtos/index
   configuration
   commands/index
   secrets
   integrations
   changelog

