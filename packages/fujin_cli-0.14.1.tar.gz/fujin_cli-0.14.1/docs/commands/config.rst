config
======

.. cappa:: fujin.commands.config.ConfigCMD
   :style: terminal
   :terminal-width: 0
