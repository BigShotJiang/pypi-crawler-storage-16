Commands
========

.. cappa:: fujin.__main__.Fujin
   :style: terminal
   :terminal-width: 0

.. toctree::
   :maxdepth: 2
   :hidden:

   app
   config
   deploy
   docs
   down
   init
   printenv
   prune
   rollback
   server
   up