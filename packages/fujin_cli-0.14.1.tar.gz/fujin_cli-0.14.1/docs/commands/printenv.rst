printenv
=======

.. cappa:: fujin.commands.printenv.Printenv
   :style: terminal
   :terminal-width: 0

