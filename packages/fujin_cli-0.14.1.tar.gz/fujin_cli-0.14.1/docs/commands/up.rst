up
==

.. cappa:: fujin.commands.up.Up
   :style: terminal
   :terminal-width: 0