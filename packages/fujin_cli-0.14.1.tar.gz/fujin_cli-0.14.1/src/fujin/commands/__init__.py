from ._base import BaseCommand, install_archive_script, uninstall_archive_script  # noqa
