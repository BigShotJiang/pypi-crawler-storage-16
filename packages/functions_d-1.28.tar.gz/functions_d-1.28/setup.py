from setuptools import setup
setup()  # 仅用于兼容旧工具，实际配置从 setup.cfg 读取