"""FurlanSpellChecker scripts package."""
