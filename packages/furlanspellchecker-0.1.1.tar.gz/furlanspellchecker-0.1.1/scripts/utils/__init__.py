"""FurlanSpellChecker utility scripts package."""
