"""Version information for FurlanSpellChecker."""

__version__ = "0.1.1"
