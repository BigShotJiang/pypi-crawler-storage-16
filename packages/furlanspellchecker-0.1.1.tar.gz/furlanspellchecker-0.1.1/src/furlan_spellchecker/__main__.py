"""Entry point for running FurlanSpellChecker as a module."""

from furlan_spellchecker.cli.app import main

if __name__ == "__main__":
    main()
