"""Phonetic dictionary database module.

Phonetic database support is provided by repository implementations in
furlan_spellchecker.database.repositories.sqlite.
"""
