"""Main entry point for FurlanSpellChecker."""

from .cli.app import main

if __name__ == "__main__":
    main()
