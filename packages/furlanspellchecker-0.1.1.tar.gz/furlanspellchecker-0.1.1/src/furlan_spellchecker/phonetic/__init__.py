"""Phonetic module initialization."""

from .furlan_phonetic import FurlanPhoneticAlgorithm

__all__ = [
    "FurlanPhoneticAlgorithm",
]
