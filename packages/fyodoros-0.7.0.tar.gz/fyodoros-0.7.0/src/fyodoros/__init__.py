"""
FyodorOS Package.

This is the top-level package for the FyodorOS simulated operating system.
It contains the kernel, shell, supervisor, plugins, and utility modules.
"""
