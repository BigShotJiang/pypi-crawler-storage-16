gaia_server = 'https://gea.esac.esa.int/'
data_release = 'Gaia DR3'
