from importlib import metadata

# Expose version attribute
__version__ = metadata.version('gaiaxpy')
