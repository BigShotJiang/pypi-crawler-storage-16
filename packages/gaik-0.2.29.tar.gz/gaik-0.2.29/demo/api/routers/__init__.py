"""GAIK Demo API Routers"""
