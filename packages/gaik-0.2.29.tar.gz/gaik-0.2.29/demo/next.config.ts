const nextConfig = {
  reactCompiler: true,
  // output: "standalone", // Uncomment for Docker deployment
};

export default nextConfig;
