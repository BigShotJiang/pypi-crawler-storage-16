
.. image:: https://badge.fury.io/py/galaxy-app.svg
   :target: https://pypi.org/project/galaxy-app/


Overview
--------

The Galaxy_ application logic (backend).

* Code: https://github.com/galaxyproject/galaxy

.. _Galaxy: http://galaxyproject.org/
