"""create tsi branch

Revision ID: d4a650f47a3c
Revises:
Create Date: 2021-11-05 16:32:25.113750

"""

# revision identifiers, used by Alembic.
revision = "d4a650f47a3c"
down_revision = None
branch_labels = ("tsi",)
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
