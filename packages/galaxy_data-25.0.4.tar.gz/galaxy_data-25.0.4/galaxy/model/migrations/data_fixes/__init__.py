"""
Package contains code for fixing inconsistent data in the database that must be
run together with a migration script.
"""
