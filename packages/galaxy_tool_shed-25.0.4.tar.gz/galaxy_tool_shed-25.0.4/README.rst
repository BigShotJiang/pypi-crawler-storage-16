
.. image:: https://badge.fury.io/py/galaxy-tool-shed.svg
   :target: https://pypi.org/project/galaxy-tool-shed/



Overview
--------

The Galaxy_ tool shed server.

* Code: https://github.com/galaxyproject/galaxy

.. _Galaxy: http://galaxyproject.org/
