"""
Galaxy tool shed web application framework
"""
