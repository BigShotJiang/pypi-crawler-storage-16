
.. image:: https://badge.fury.io/py/galaxy-tool-util.svg
   :target: https://pypi.org/project/galaxy-tool-util/


Overview
--------

The Galaxy_ tool utilities.

* Code: https://github.com/galaxyproject/galaxy/tree/dev/packages/tool_util

.. _Galaxy: http://galaxyproject.org/
