"""
Galaxy web controllers.
"""
