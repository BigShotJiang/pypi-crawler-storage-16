"""Galileo SDK exceptions."""


class GalileoLoggerException(Exception):
    """Exception raised by GalileoLogger."""
