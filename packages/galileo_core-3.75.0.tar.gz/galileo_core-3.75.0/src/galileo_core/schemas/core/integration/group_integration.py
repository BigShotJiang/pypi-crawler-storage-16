from galileo_core.schemas.core.collaborator import GroupCollaboratorCreate


class GroupIntegrationCollaboratorResponse(GroupCollaboratorCreate):
    group_name: str
