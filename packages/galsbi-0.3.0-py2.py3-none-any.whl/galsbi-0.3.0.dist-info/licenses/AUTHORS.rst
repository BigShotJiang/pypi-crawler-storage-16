=======
Credits
=======

Development Lead
----------------

* Silvan Fischbacher (current maintainer) silvanf@phys.ethz.ch
* Luca Tortorelli (maintainer of GalSBI-SPS) luca.tortorelli@physik.lmu.de
* Beatrice Moser
* Tomasz Kacprzak
* Jörg Herbel
* Uwe Schmitt

Contributors
------------

None yet. Why not be the first?
