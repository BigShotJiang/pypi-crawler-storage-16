# Copyright (C) 2025 LMU Munich
# Author: Luca Tortorelli
# created: Jun 2025

import os

import numpy as np
import ufig.config.common
from cosmo_torrent import data_path
from ivy.loop import Loop
from ufig.workflow_util import FiltersStopCriteria

import galsbi.ucat.config.common
import galsbi.ucat_sps.config.common_sps


# Import all common settings from ucat and ufig as default
def _update_globals(module, globals_):
    globals_.update(
        {k: v for k, v in module.__dict__.items() if not k.startswith("__")}
    )


_update_globals(ufig.config.common, globals())
_update_globals(galsbi.ucat.config.common, globals())
_update_globals(galsbi.ucat_sps.config.common_sps, globals())

# Default size of the image
sampling_mode = "wcs"
ra0 = 0
dec0 = 0
pixscale = 0.168
size_x = 1000
size_y = 1000


# Define the filters
filters = ["g", "r", "i", "z", "y"]
filters_full_names = {
    "B": "SuprimeCam_B",
    "g": "HSC_g",
    "r": "HSC_r2",
    "i": "HSC_i2",
    "z": "HSC_z",
    "y": "HSC_y",
}
reference_band = "i"
filters_full_names_prospect = ["g_HSC", "r_HSC", "i_HSC", "z_HSC", "Y_HSC"]
magzero_dict = {"g": 27.0, "r": 27.0, "i": 27.0, "z": 27.0, "y": 27.0}

# Define the plugins that should be used
plugins = [
    "ufig.plugins.multi_band_setup",
    "galsbi.ucat_sps.plugins.sample_galaxies_sps",
    # "ufig.plugins.draw_stars_besancon_map",
    Loop(
        [
            "ufig.plugins.single_band_setup",
            "ufig.plugins.background_noise",
            "ufig.plugins.resample",
            "ufig.plugins.add_psf",
            "ufig.plugins.gamma_interpolation_table",
            "ufig.plugins.render_galaxies_flexion",
            "ufig.plugins.convert_photons_to_adu",
            # because from the image we see single spike in the x direction
            "ufig.plugins.saturate_pixels_x",
            "galsbi.ucat.plugins.write_catalog",
            "ufig.plugins.write_image",
        ],
        stop=FiltersStopCriteria(),
    ),
    "ivy.plugin.show_stats",
]

# Background noise (corresponding roughly to a HSC deep field image)
background_type = "gaussian"
background_sigma_dict = {"g": 1.2, "r": 1.5, "i": 2.6, "z": 6.4, "y": 8.6}
bkg_noise_amp_dict = {"g": 0.005, "r": 0.005, "i": 0.01, "z": 0.01, "y": 0.02}
bkg_noise_multiply_gain = False
gain_dict = {
    "g": 70,
    "r": 60,
    "i": 80,
    "z": 105,
    "y": 70,
}
n_exp_dict = {
    "g": 20,
    "r": 16,
    "i": 22,
    "z": 30,
    "y": 20,
}

# PSF  (corresponding roughly to a HSC deep field image)
psf_type = "constant_moffat"  # constant PSF defined by Moffat profile
psf_e1 = 0.0  # PSF e1
psf_e2 = 0.0  # PSF e2
psf_beta = [2.0, 5.0]  # Moffat beta parameter
seeing = 0.6  # mean seeing in arcsec

# Sampling methods ucat
nside_sampling = 1024

# Filter throughputs
filters_file_name = os.path.join(
    data_path("HSC_tables"), "HSC_filters_collection_yfix.h5"
)

# Extinction
extinction_map_file_name = os.path.join(
    data_path("lambda_sfd_ebv"), "lambda_sfd_ebv.fits"
)

# SSP library
ssp_library_filepath = os.path.join(data_path("GalSBI_SPS_res"), "PG_Ch_Mi_C3K.fits")

# ProMage magnitude emulator
ProMage_model_filepath = os.path.join(
    data_path("GalSBI_SPS_res"), "ProMage_GalSBI_SPS_HSC_mags.pt"
)
ProMage_property_scaler_filepath = os.path.join(
    data_path("GalSBI_SPS_res"), "ProMage_GalSBI_SPS_HSC_mags_property_scaler.pkl"
)
ProMage_magnitude_scaler_filepath = os.path.join(
    data_path("GalSBI_SPS_res"), "ProMage_GalSBI_SPS_HSC_mags_magnitude_scaler.pkl"
)

# Surviving stellar mass emulator
surviv_stellar_mass_emulator_property_scaler = os.path.join(
    data_path("GalSBI_SPS_res"), "property_scaler_surv_sm_emulator.pkl"
)
surviv_stellar_mass_emulator_ssm_scaler = os.path.join(
    data_path("GalSBI_SPS_res"), "ssm_scaler_surv_sm_emulator.pkl"
)
surviv_stellar_mass_emulator_model = os.path.join(
    data_path("GalSBI_SPS_res"), "surv_sm_emulator.pt"
)

# Catalog precision
catalog_precision = np.float32

# Seed
seed = 1996

# Parameters that are specific to the Tortorelli+25 model
# Mainly the different parametrizations of the galaxy population model.
# DO NOT CHANGE THESE VALUES IF YOU WANT TO USE THE MODEL OF TORTORELLI+25
# CHANGING THESE VALUES WILL LEAD TO A DIFFERENT MEANING OF SOME OF THE PARAMETERS
ellipticity_sampling_method = "beta_mode_red_blue"
sersic_sampling_method = "sersic_stellar_mass"
sed_generator = "emulator"
add_agn_component = False
abs_path_temple2021 = os.path.join(data_path("GalSBI_SPS_res"), "qsogen")
save_SEDs = False
full_resolution_SEDs = False
