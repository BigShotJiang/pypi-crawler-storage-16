# Copyright (C) 2024 ETH Zurich
# Institute for Particle Physics and Astrophysics
# Author: Silvan Fischbacher
# created: Fri Aug 30 2024

# Copyright (C) 2025 LMU Munich
# Main contributor: Luca Tortorelli
# updated: Apr 2025

# This file contains the model names and citations for the models.

ALL_MODELS = ["Moser+24", "Fischbacher+24", "Tortorelli+25"]

CITE_MOSER24 = """
@article{Moser2024,
	title        = {{Simulation-based inference of deep fields: galaxy population model and redshift distributions}},
	author       = {Moser, Beatrice and Kacprzak, Tomasz and Fischbacher, Silvan and Refregier, Alexandre and Grimm, Dominic and Tortorelli, Luca},
	year         = 2024,
	journal      = {JCAP},
	volume       = {05},
	pages        = {049},
	doi          = {10.1088/1475-7516/2024/05/049},
	eprint       = {2401.06846},
	archiveprefix = {arXiv},
	primaryclass = {astro-ph.CO}
}

"""

CITE_FISCHBACHER24 = """
@article{Fischbacher2025_GalSBI_phenomenological,
    author = "Fischbacher, Silvan and Kacprzak, Tomasz and Tortorelli, Luca and Moser, Beatrice and Refregier, Alexandre and Gebhardt, Patrick and Gruen, Daniel",
    title = "{GalSBI: phenomenological galaxy population model for cosmology using simulation-based inference}",
    eprint = "2412.08701",
    archivePrefix = "arXiv",
    primaryClass = "astro-ph.CO",
    doi = "10.1088/1475-7516/2025/06/007",
    journal = "JCAP",
    volume = "06",
    pages = "007",
    year = "2025"
}
"""

CITE_TORTORELLI25 = """
@ARTICLE{Tortorelli2025_GalSBI_SPS,
       author = {{Tortorelli}, Luca and {Fischbacher}, Silvan and {Gr{\"u}n}, Daniel and {Refregier}, Alexandre and {Bellstedt}, Sabine and {Robotham}, Aaron S.~G. and {Kacprzak}, Tomasz},
        title = "{GALSBI-SPS: A stellar population synthesis-based galaxy population model for cosmology and galaxy evolution applications}",
      journal = {\aap},
     keywords = {galaxies: evolution, galaxies: luminosity function, mass function, galaxies: statistics, galaxies: stellar content, cosmology: observations, large-scale structure of Universe},
         year = 2025,
        month = nov,
       volume = {703},
          eid = {A255},
        pages = {A255},
          doi = {10.1051/0004-6361/202555759},
       adsurl = {https://ui.adsabs.harvard.edu/abs/2025A&A...703A.255T},
      adsnote = {Provided by the SAO/NASA Astrophysics Data System}
}
"""

CITE_UFIG = """
@article{Fischbacher2025_ufig,
	title        = {UFig v1: The ultra-fast image generator},
	author       = {Fischbacher, Silvan and Moser, Beatrice and Kacprzak, Tomasz and Tortorelli, Luca and Herbel, Joerg and Bruderer, Claudio and Schmitt, Uwe and Refregier, Alexandre and Berge, Joel and Gamper, Lukas and Amara, Adam},
	year         = 2025,
	journal      = {Journal of Open Source Software},
	publisher    = {The Open Journal},
	volume       = 10,
	number       = 113,
	pages        = 8697,
	doi          = {10.21105/joss.08697},
	url          = {https://doi.org/10.21105/joss.08697}
}
"""

CITE_GALSBI = """
@article{Fischbacher2025_galsbi_package,
	title        = {galsbi: A Python package for the GalSBI galaxy population model},
	author       = {Fischbacher, Silvan and Moser, Beatrice and Kacprzak, Tomasz and Herbel, Joerg and Tortorelli, Luca and Schmitt, Uwe and Refregier, Alexandre and Amara, Adam},
	year         = 2025,
	journal      = {Journal of Open Source Software},
	publisher    = {The Open Journal},
	volume       = 10,
	number       = 114,
	pages        = 8766,
	doi          = {10.21105/joss.08766},
	url          = {https://doi.org/10.21105/joss.08766}
}
"""

CITE_PROMAGE = """
@ARTICLE{Tortorelli2025b_ProMage,
        title = "{ProMage: fast galaxy magnitudes emulation combining SED forward-modelling and machine learning}",
       author = {{Tortorelli}, Luca and {Fischbacher}, Silvan and {Robotham}, Aaron S.~G. and {Nussbaumer}, C{\'e}line and {Refregier}, Alexandre},
      journal = {arXiv e-prints},
     keywords = {Astrophysics of Galaxies, Instrumentation and Methods for Astrophysics},
         year = 2025,
        month = aug,
          eid = {arXiv:2509.00150},
        pages = {arXiv:2509.00150},
          doi = {10.48550/arXiv.2509.00150},
archivePrefix = {arXiv},
       eprint = {2509.00150},
 primaryClass = {astro-ph.GA},
       adsurl = {https://ui.adsabs.harvard.edu/abs/2025arXiv250900150T},
}
"""
