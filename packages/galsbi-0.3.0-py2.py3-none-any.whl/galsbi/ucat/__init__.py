__author__ = (
    "Joerg Herbel, Luca Tortorelli, Tomasz Kacprzak, Beatrice Moser, Silvan Fischbacher"
)
__email__ = "silvanf@phys.ethz.ch"
__version__ = "0.1.1"
__credits__ = "ETH Zurich, Institute for Particle Physics and Astrophysics"
