# Copyright (C) 2025 LMU Munich
# Author: Luca Tortorelli
# created: Apr 2025


import numpy as np
import PyCosmo

from galsbi.ucat.config.common import h, omega_m
from galsbi.ucat_sps.galaxy_population_models.galaxy_star_formation_history import (
    get_age_of_the_universe_from_redshift,
)

# ==================================================================
# G A L A X Y   C A T A L O G
# ==================================================================

# ---------------------
# Stellar Mass Function
# ---------------------

gal_sm_fct_seed_offset = 123491
SEED_OFFSET_SMFUN = 100

# Functional forms of M* and phi*, can be linexp (linear and exponential) or
# logpower (for logarithmic and power law)
sm_fct_parametrization = "logquadratic_power"
# Resolution for sampling stellar mass
sm_fct_z_res = 0.001
# Maximum redshift of galaxies to sample
sm_fct_z_max = 5
# Minimum stellar mass to be sampled
sm_fct_sm_min = 8
# Resolution for sampling stellar masses
sm_fct_sm_res = 0.001
# Schechter parameter alpha for blue galaxies
sm_fct_alpha_blue_lowmass = -1.434
# Schechter parameter alpha for blue galaxies
sm_fct_alpha_blue_highmass = -0.123
# Schechter parameter alpha for red galaxies
sm_fct_alpha_red_lowmass = -2.01
# Schechter parameter alpha for red galaxies
sm_fct_alpha_red_highmass = -0.52

# values from Weaver+23
sm_fct_m_star_blue_0_lowmass = 10.42822754
sm_fct_m_star_blue_1_lowmass = 2.75747512
sm_fct_m_star_blue_2_lowmass = -3.78410885
sm_fct_phi_star_blue_amp_lowmass = 0.00120151
sm_fct_phi_star_blue_exp_lowmass = -1.0522461

sm_fct_m_star_blue_0_highmass = sm_fct_m_star_blue_0_lowmass
sm_fct_m_star_blue_1_highmass = sm_fct_m_star_blue_1_lowmass
sm_fct_m_star_blue_2_highmass = sm_fct_m_star_blue_2_lowmass
sm_fct_phi_star_blue_amp_highmass = 7.14975958e-04
sm_fct_phi_star_blue_exp_highmass = -1.35852989e00

sm_fct_m_star_red_0_lowmass = 11.13180376
sm_fct_m_star_red_1_lowmass = -1.32213682
sm_fct_m_star_red_2_lowmass = 0.08538828
sm_fct_phi_star_red_amp_lowmass = 4.80658020e-05
sm_fct_phi_star_red_exp_lowmass = -6.00859413e00

sm_fct_m_star_red_0_highmass = sm_fct_m_star_red_0_lowmass
sm_fct_m_star_red_1_highmass = sm_fct_m_star_red_1_lowmass
sm_fct_m_star_red_2_highmass = sm_fct_m_star_red_2_lowmass
sm_fct_phi_star_red_amp_highmass = 0.00133062
sm_fct_phi_star_red_exp_highmass = -0.84695455

# -------------------
# Size model (stellar mass)
# -------------------

SEED_OFFSET_SIZE = 700

# Lognormal distribution as with luminosity but the mean is a function of stellar mass
# Default values from Nedkova+21 on GAMA galaxies

r50_stellar_mass_logA_blue_intcpt = 0.86882979
r50_stellar_mass_logA_blue_slope = -0.16382979
r50_stellar_mass_B_blue_intcpt = 0.25182844
r50_stellar_mass_B_blue_slope = -0.05056433

r50_stellar_mass_eta_red_intcpt = 0.11901468
r50_stellar_mass_eta_red_slope = -0.21145203
r50_stellar_mass_theta_red_intcpt = 1.68920793
r50_stellar_mass_theta_red_slope = -0.21753742
r50_stellar_mass_logzeta_red_intcpt = -1.12244718
r50_stellar_mass_logzeta_red_slope = 2.36436158
r50_stellar_mass_delta_red_intcpt = 10.96599095
r50_stellar_mass_delta_red_slope = -0.10815138

# Standard deviation of the log of physical sizes, values from Shen+2003
logr50_stellar_mass_std_red = 0.3
logr50_stellar_mass_std_blue = 0.3

# ------------------------
# Velocity dispersion
# ------------------------

SEED_OFFSET_VELDISP = 800

# default values from Zahid+16
vel_disp_logsigma_b = 2.073
vel_disp_logM_b = 10.26
vel_disp_s_1 = 0.403
vel_disp_s_2 = 0.293
vel_disp_std = 10

# ----------------------
# Star formation history
# ----------------------

time_step = 1e8
cosmo = PyCosmo.build()
cosmo.set(h=h, omega_m=omega_m)
time_grid = np.arange(0, get_age_of_the_universe_from_redshift(0, cosmo), time_step)

SEED_OFFSET_SFH = 200

# parameters for the snorm_trunc SFH parametrisation obtained from GAMA & DEVILS ata

magemax_z0 = 13.4
mtrunc = 2

logmpeak_massevo_slope_zevo_intcpt_red = -0.10385816
logmpeak_massevo_slope_zevo_slope_red = -1.52420053

logmpeak_massevo_slope_zevo_intcpt_blue = 0.00648434
logmpeak_massevo_slope_zevo_slope_blue = -3.54384208

logmpeak_massevo_intcpt_zevo_intcpt_red = 0.22328791
logmpeak_massevo_intcpt_zevo_slope_red = 15.14361675

logmpeak_massevo_intcpt_zevo_intcpt_blue = -0.65466787
logmpeak_massevo_intcpt_zevo_slope_blue = 35.0180344

logmperiod_massevo_intcpt_red = 1.19767
logmperiod_massevo_slope_red = -0.09370334

logmperiod_massevo_intcpt_blue = 2.72710091
logmperiod_massevo_slope_blue = -0.21035425

mskew_massevo_intcpt_red = -0.55390266
mskew_massevo_slope_red = 0.06286995

mskew_massevo_intcpt_blue = 0.02656692
mskew_massevo_slope_blue = 0.01594687

logmpeak_norm_min_blue = -3
logmpeak_norm_max_blue = 0.06
logmpeak_norm_min_red = -3
logmpeak_norm_max_red = 0.06

logmperiod_min_blue = np.log10(0.3)
logmperiod_max_blue = 2
logmperiod_min_red = np.log10(0.3)
logmperiod_max_red = 2

mskew_min_blue = -0.5
mskew_max_blue = 1.0
mskew_min_red = -0.5
mskew_max_red = 1.0

sfh_shape_params_cov_blue = np.array(
    [
        [0.4211092, -0.02020991, -0.05997905],
        [-0.02020991, 0.2025788, -0.07062304],
        [-0.05997905, -0.07062304, 0.12102846],
    ]
)
sfh_shape_params_cov_red = np.array(
    [
        [0.51743558, -0.00445069, -0.06305345],
        [-0.00445069, 0.13260276, -0.0822066],
        [-0.06305345, -0.0822066, 0.09058901],
    ]
)

# ----------------------
# Surviving stellar mass emulator
# ----------------------

surviv_stellar_mass_emulator_property_scaler = "property_scaler_surv_sm_emulator.pkl"
surviv_stellar_mass_emulator_ssm_scaler = "ssm_scaler_surv_sm_emulator.pkl"
surviv_stellar_mass_emulator_model = "surv_sm_emulator.pt"

# ----------------------
# Prospect SED generator
# ----------------------

sed_generator = "Prospect"
ssp_library_filepath = "PG_Ch_Mi_C3K.fits"
filters_full_names_prospect = [
    "g_HSC",
    "r_HSC",
    "i_HSC",
    "z_HSC",
    "Y_HSC",
    "u_SDSS",
    "Y_VISTA",
    "J_VISTA",
    "H_VISTA",
    "K_VISTA",
]
save_SEDs = False
full_resolution_SEDs = False
n_cores_for_sed_generation = 2
SOLAR_LUMINOSITY_ERG_S = 3.8275 * 10**33
MPC_TO_CM = 3.08567758128 * 10**24
LIGHTSPEED_ANGSTROM_S = 2.9979245800 * 10**18

# ----------------------
# ProMage magnitude emulator
# ----------------------

ProMage_model_filepath = "ProMage_GalSBI_SPS_HSC_mags.pt"
ProMage_property_scaler_filepath = "ProMage_GalSBI_SPS_HSC_mags_property_scaler.pkl"
ProMage_magnitude_scaler_filepath = "ProMage_GalSBI_SPS_HSC_mags_magnitude_scaler.pkl"

# ----------------
# Dust attenuation
# ----------------

SEED_OFFSET_DUSTATT = 500

# logtauscreen limits from Thorne+2022 in place of Bellstedt+20
dust_attenuation_law = "CharlotFall2000"
logtaubirth_mean_blue = -0.10
logtaubirth_mean_red = -0.18
logtaubirth_scatter_blue = 0.24
logtaubirth_scatter_red = 0.21
logtaubirth_min = -2.5
logtaubirth_max = 1.5

logtauscreen_a0_blue = -0.861
logtauscreen_a1_blue = 0.643
logtauscreen_a2_blue = 0.210
logtauscreen_a3_blue = 0.170
logtauscreen_scatter_blue = 0.247

logtauscreen_a0_red = 0.850
logtauscreen_a1_red = 1.586
logtauscreen_a2_red = -0.174
logtauscreen_a3_red = -0.0083
logtauscreen_scatter_red = 0.417

logtauscreen_min = -5
logtauscreen_max = 1

# ----------------
# Dust emission
# ----------------

SEED_OFFSET_DUSTEM = 600

dust_emission_mean_blue = np.array([1.80, 1.70])
dust_emission_mean_red = np.array([1.97, 1.91])
dust_emission_cov_blue = np.array([[0.19, 0.12], [0.12, 0.20]])
dust_emission_cov_red = np.array([[0.08, 0.02], [0.02, 0.16]])

# -------------------
# Metallicity
# -------------------

# # SOLAR_GAS_METALLICITY = 0.0142
SOLAR_GAS_METALLICITY = (
    0.02  # Aaron's suggestion to ensure compatibility with PROSPECT definitions
)
SOLAR_LOG_OH_PLUS12 = 8.69
SOLAR_STELLAR_METALLICITY = 0.02
SEED_OFFSET_ZGAS = 300

# parametrization from Bellstedt+2021
# parameters for the scatter: Bellstedt+2021
gas_metallicity_scatter0_blue = 0.427
gas_metallicity_scatter1_blue = -0.02979
gas_metallicity_scatter2_blue = 0.0026182
gas_metallicity_scatter0_red = 0.427
gas_metallicity_scatter1_red = -0.02979
gas_metallicity_scatter2_red = 0.0026182

gas_metallicity_alpha0_blue = -0.9202
gas_metallicity_alpha1_blue = 0.2916
gas_metallicity_alpha2_blue = -0.05082
gas_metallicity_beta0_blue = 1.198
gas_metallicity_beta1_blue = -0.2658
gas_metallicity_beta2_blue = 0.04884
gas_metallicity_gamma0_blue = -2.785
gas_metallicity_gamma1_blue = 2.268
gas_metallicity_gamma2_blue = -0.4267
gas_metallicity_alpha0_red = -0.9202
gas_metallicity_alpha1_red = 0.2916
gas_metallicity_alpha2_red = -0.05082
gas_metallicity_beta0_red = 1.198
gas_metallicity_beta1_red = -0.2658
gas_metallicity_beta2_red = 0.04884
gas_metallicity_gamma0_red = -2.785
gas_metallicity_gamma1_red = 2.268
gas_metallicity_gamma2_red = -0.4267

# limits from Bellstedt+2021
Zgas_init = 0.0001
Zgas_max = 10 ** (-1.3)

# --------------
# Gas ionization
# --------------

SEED_OFFSET_LOGU = 400

# parametrization from Kashino+2019
gas_ionization_upsilon0 = -2.316
gas_ionization_upsilon1 = -0.360
gas_ionization_upsilon2 = -0.292
gas_ionization_upsilon3 = 0.428
gas_ionization_scatter = 0.1
logUmin = -4
logUmax = -1

# --------------
# AGN
# --------------

SEED_OFFSET_AGN = 900

abs_path_temple2021 = "qsogen"
add_agn_component = False

logfagn_mu1_blue = -6.25
logfagn_sigma1_blue = 2
logfagn_mu2_blue = -0.75
logfagn_sigma2_blue = 0.8

logfagn_mu1_red = -5.5
logfagn_sigma1_red = 1.75
logfagn_mu2_red = -0.25
logfagn_sigma2_red = 0.7

alpha_AGN_03_z_08 = -0.25
alpha_AGN_08_z_15 = -0.19
alpha_AGN_15_z_25 = -0.03

log_Mstar_AGN_03_z_08 = 10.99
log_Mstar_AGN_08_z_15 = 10.99
log_Mstar_AGN_15_z_25 = 10.99

phi_star_AGN_03_z_08 = 10 ** (-3.83)
phi_star_AGN_08_z_15 = 10 ** (-3.54)
phi_star_AGN_15_z_25 = 10 ** (-3.84)

logfagn_nohost_min = -10
logfagn_nohost_max = -1

logfagn_host_min = -1
logfagn_host_max = 2

# -------------------
# Sersic distribution
# -------------------

sersic_sampling_method = "sersic_stellar_mass"

# minimum sersic index
sersic_n_min = 0.2
# maximum sersic index
sersic_n_max = 10

sersic_n_0_blue = 1.04269007
sersic_n_1_blue = 0.17637649
sersic_n_2_blue = 12.75004841
sersic_n_scatter_blue = 0.90902036

sersic_n_0_red = 1.05421348
sersic_n_1_red = 1.45273864
sersic_n_2_red = 7.63380979
sersic_n_scatter_red = 1.4392298
