# Copyright (C) 2025 LMU Munich
# Author: Luca Tortorelli
# created: Apr 2025

from galsbi.ucat.config import common
from galsbi.ucat_sps.config import common_sps

for name in [name for name in dir(common) if not name.startswith("__")]:
    globals()[name] = getattr(common, name)

for name in [name for name in dir(common_sps) if not name.startswith("__")]:
    globals()[name] = getattr(common_sps, name)


plugins = ["ucat_sps.plugins.sample_galaxies_sps"]

maps_remote_dir = "ucat/resources/"

# Filter throughputs
filters_file_name = "filters_collection.h5"

extinction_map_file_name = "lambda_sfd_ebv.fits"
