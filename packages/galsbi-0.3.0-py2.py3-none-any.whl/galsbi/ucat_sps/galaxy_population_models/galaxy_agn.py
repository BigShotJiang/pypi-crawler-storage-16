# Copyright (C) 2025 LMU Munich
# Author: Luca Tortorelli
# created: Apr 2025

import numpy as np
from scipy.stats import truncnorm

from galsbi.ucat_sps.galaxy_population_models.galaxy_stellar_mass_function import (
    double_stellar_mass_function_parametrisation,
    single_stellar_mass_function_parametrisation,
    stellar_mass_function_m_star,
    stellar_mass_function_phi_star,
)


def sample_ratio_agn_to_galaxy_bolometric_luminosity(
    par, redshifts, log10_stellar_masses, galaxy_type="blue", seed=None
):
    """
    We first compute the probability that a galaxy hosts an AGN as function of
    redshift and stellar mass by taking the ratio between the redshift- evolving SMFs of
    blue and red galaxies and the AGN host galaxy mass function dervied in Bongiorno et
    al 2016. Then, we statistically assign an AGN to a host galaxy with a Bernoulli
    trial proportional to the computed probability. As in López-López et al. (2024), we
    assume fixed AGN fractions outside the redshift ranges specified by Bongiorno et al.
    (2016). In particular, the probability of hosting an AGN is 1% at all stellar masses
    below z = 0.55, while at z > 2 we maintain a constant fraction taken from the last
    redshift bin in Bongiorno et al. (2016). We then assign AGN flux contributions to
    all galaxies, regardless of whether they are classified as AGN hosts. However, fAGN
    is sampled from different distributions depending on the AGN classification.
    Galaxies hosting AGNs draw from the high-log (fAGN) distribution, while non-AGN
    galaxies draw from the low-log (fAGN) one. We adopt a threshold of log(fAGN) = −1 to
    separate these two regimes. The ratio of the AGN to galaxy bolometric luminosity
    fagn is sampled from the sum of two Normal distributions that matches the fagn
    distribution computed with Prospect using the best-fitting parameters of DEVILS D10
    field used in Thorne+2022. fagn = L_bol_AGN / L_bol_galaxy.

    :param par: (obj) par objects containing the Ucat parameters.
    :param redshifts: (array_like[n_gal,]) redshifts drawn from the stellar mass
        function.
    :param log10_stellar_masses: (array_like[n_gal,]) log10 of the stellar masses
        sampled from the stellar mass function.
    :param galaxy_type: (str) "blue" or "red" galaxy population.
    :param seed: (int) random seed.
    :return fagn: (array_like[n_gal,]) AGN to galaxy bolometric luminosity fraction.
    """
    if seed is None:
        seed = 42
    rng = np.random.default_rng(seed=seed)

    alpha_AGN = np.zeros_like(log10_stellar_masses)
    alpha_AGN[(redshifts > 0.3) & (redshifts <= 0.8)] = par.alpha_AGN_03_z_08
    alpha_AGN[(redshifts > 0.8) & (redshifts <= 1.5)] = par.alpha_AGN_08_z_15
    alpha_AGN[(redshifts > 1.5) & (redshifts <= 2.5)] = par.alpha_AGN_15_z_25

    log_Mstar_AGN = np.zeros_like(log10_stellar_masses)
    log_Mstar_AGN[(redshifts > 0.3) & (redshifts <= 0.8)] = par.log_Mstar_AGN_03_z_08
    log_Mstar_AGN[(redshifts > 0.8) & (redshifts <= 1.5)] = par.log_Mstar_AGN_08_z_15
    log_Mstar_AGN[(redshifts > 1.5) & (redshifts <= 2.5)] = par.log_Mstar_AGN_15_z_25

    phi_star_AGN = np.zeros_like(log10_stellar_masses)
    phi_star_AGN[(redshifts > 0.3) & (redshifts <= 0.8)] = par.phi_star_AGN_03_z_08
    phi_star_AGN[(redshifts > 0.8) & (redshifts <= 1.5)] = par.phi_star_AGN_08_z_15
    phi_star_AGN[(redshifts > 1.5) & (redshifts <= 2.5)] = par.phi_star_AGN_15_z_25

    agn_host_galaxy_number_densities = single_stellar_mass_function_parametrisation(
        log10_stellar_masses, log_Mstar_AGN, phi_star_AGN, alpha_AGN
    )

    sm_fct_m_star_0_lowmass = getattr(par, f"sm_fct_m_star_{galaxy_type}_0_highmass")
    sm_fct_m_star_1_lowmass = getattr(par, f"sm_fct_m_star_{galaxy_type}_1_highmass")
    sm_fct_m_star_2_lowmass = getattr(par, f"sm_fct_m_star_{galaxy_type}_2_highmass")
    sm_fct_phi_star_amp_lowmass = getattr(
        par, f"sm_fct_phi_star_{galaxy_type}_amp_lowmass"
    )
    sm_fct_phi_star_exp_lowmass = getattr(
        par, f"sm_fct_phi_star_{galaxy_type}_exp_lowmass"
    )
    sm_fct_phi_star_amp_highmass = getattr(
        par, f"sm_fct_phi_star_{galaxy_type}_amp_highmass"
    )
    sm_fct_phi_star_exp_highmass = getattr(
        par, f"sm_fct_phi_star_{galaxy_type}_exp_highmass"
    )
    sm_fct_alpha_lowmass = getattr(par, f"sm_fct_alpha_{galaxy_type}_lowmass")
    sm_fct_alpha_highmass = getattr(par, f"sm_fct_alpha_{galaxy_type}_highmass")

    log_Mstar = stellar_mass_function_m_star(
        redshifts,
        par.sm_fct_parametrization,
        sm_fct_m_star_0_lowmass,
        sm_fct_m_star_1_lowmass,
        quadratic_term=sm_fct_m_star_2_lowmass,
    )
    phi_star_low_mass = stellar_mass_function_phi_star(
        redshifts,
        par.sm_fct_parametrization,
        sm_fct_phi_star_amp_lowmass,
        sm_fct_phi_star_exp_lowmass,
    )
    phi_star_high_mass = stellar_mass_function_phi_star(
        redshifts,
        par.sm_fct_parametrization,
        sm_fct_phi_star_amp_highmass,
        sm_fct_phi_star_exp_highmass,
    )

    galaxy_smf_number_densities = double_stellar_mass_function_parametrisation(
        log10_stellar_masses,
        log_Mstar,
        phi_star_low_mass,
        phi_star_high_mass,
        sm_fct_alpha_lowmass,
        sm_fct_alpha_highmass,
    )

    agn_host_probability = (
        agn_host_galaxy_number_densities / galaxy_smf_number_densities
    )
    agn_host_probability[redshifts < 0.3] = 0.01
    agn_host_probability[redshifts > 2.5] = 0.2

    agn_hosts_mask = rng.uniform(size=agn_host_probability.shape) < agn_host_probability

    logfagn_mu1 = getattr(par, f"logfagn_mu1_{galaxy_type}")
    logfagn_sigma1 = getattr(par, f"logfagn_sigma1_{galaxy_type}")
    logfagn_mu2 = getattr(par, f"logfagn_mu2_{galaxy_type}")
    logfagn_sigma2 = getattr(par, f"logfagn_sigma2_{galaxy_type}")

    logfagn = np.ones_like(log10_stellar_masses)

    logfagn_nohost_min = (par.logfagn_nohost_min - logfagn_mu1) / logfagn_sigma1
    logfagn_nohost_max = (par.logfagn_nohost_max - logfagn_mu1) / logfagn_sigma1
    logfagn[~agn_hosts_mask] = truncnorm.rvs(
        logfagn_nohost_min,
        logfagn_nohost_max,
        loc=logfagn_mu1,
        scale=logfagn_sigma1,
        size=len(logfagn[~agn_hosts_mask]),
        random_state=rng,
    )

    logfagn_host_min = (par.logfagn_host_min - logfagn_mu2) / logfagn_sigma2
    logfagn_host_max = (par.logfagn_host_max - logfagn_mu2) / logfagn_sigma2
    logfagn[agn_hosts_mask] = truncnorm.rvs(
        logfagn_host_min,
        logfagn_host_max,
        loc=logfagn_mu2,
        scale=logfagn_sigma2,
        size=len(logfagn[agn_hosts_mask]),
        random_state=rng,
    )

    return 10**logfagn
