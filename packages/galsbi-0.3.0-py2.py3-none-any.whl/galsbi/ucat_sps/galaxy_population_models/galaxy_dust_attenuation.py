# Copyright (C) 2025 LMU Munich
# Author: Luca Tortorelli
# created: Apr 2025

import numpy as np
from scipy.stats import truncnorm


def sample_dust_attenuation_parameters_charlotfall2000(
    par,
    log10_stellar_masses,
    log_specific_star_formation_rates,
    redshifts,
    galaxy_type="blue",
    seed=None,
):
    """
    The Charlot&Fall2000 dust attenuation prescription is used in this case. It is
    implemented in ProSpect by means of the tau_birth, tau_screen and Eb parameters. We
    use DEVILS data to model the dependence of tau_screen and tau_birth on redshift,
    stellar mass and specific star-formation rate. We find that tau_birth does not
    depend on any of those quantities. tau_screen depends instead on redshift, stellar
    mass and specific star-formation rate. tau_birth is sampled from a Gaussian
    distribution with different parameter values for blue and red galaxies. The Eb of
    the 2175 Å bump in the Drude profile is assumed to have the typical value of 1.

    :param par: (obj) par objects containing the Ucat parameters.
    :param log10_stellar_masses: (array_like[n_gal,]) log10 of the stellar masses drawn
        from the stellar mass function.
    :param log_specific_star_formation_rates: (array_like[n_gal,]) log10 of the specific
        star formation rate.
    :param redshifts: (array_like[n_gal,]) galaxy redshifts.
    :param galaxy_type: (str) "blue" or "red" galaxy population.
    :param seed: (int) random seed.
    :return dust_attenuation_params: (array_like[n_gal,3]) dust attenuation parameters
        tau_birth, tau_screen, Eb.
    """
    if seed is None:
        seed = 42
    rng = np.random.default_rng(seed=seed)

    logtaubirth_mean = getattr(par, f"logtaubirth_mean_{galaxy_type}")
    logtaubirth_scatter = getattr(par, f"logtaubirth_scatter_{galaxy_type}")
    logtaubirth_min = (par.logtaubirth_min - logtaubirth_mean) / logtaubirth_scatter
    logtaubirth_max = (par.logtaubirth_max - logtaubirth_mean) / logtaubirth_scatter
    logtaubirth = truncnorm.rvs(
        logtaubirth_min,
        logtaubirth_max,
        loc=logtaubirth_mean,
        scale=logtaubirth_scatter,
        size=len(log10_stellar_masses),
        random_state=rng,
    )

    logtauscreen_a0 = getattr(par, f"logtauscreen_a0_{galaxy_type}")
    logtauscreen_a1 = getattr(par, f"logtauscreen_a1_{galaxy_type}")
    logtauscreen_a2 = getattr(par, f"logtauscreen_a2_{galaxy_type}")
    logtauscreen_a3 = getattr(par, f"logtauscreen_a3_{galaxy_type}")
    logtauscreen_scatter = getattr(par, f"logtauscreen_scatter_{galaxy_type}")
    logtauscreen_mean = (
        logtauscreen_a0
        + logtauscreen_a1 * np.log10(1 + redshifts)
        + logtauscreen_a2 * log10_stellar_masses
        + logtauscreen_a3 * log_specific_star_formation_rates
    )
    logtauscreen_min = (par.logtauscreen_min - logtauscreen_mean) / logtauscreen_scatter
    logtauscreen_max = (par.logtauscreen_max - logtauscreen_mean) / logtauscreen_scatter
    logtauscreen = truncnorm.rvs(
        logtauscreen_min,
        logtauscreen_max,
        loc=logtauscreen_mean,
        scale=logtauscreen_scatter,
        size=len(log10_stellar_masses),
        random_state=rng,
    )

    Eb = np.full_like(logtauscreen, 1)

    return np.stack((logtaubirth, logtauscreen, Eb)).T


def sample_dust_attenuation_parameters(
    par,
    log10_stellar_mass,
    log_specific_star_formation_rate,
    redshift,
    galaxy_type="blue",
    seed=None,
):
    """
    This function samples dust attenuation parameters depending on the specific user-
    defined dust attenuation law.

    :param par: (obj) par objects containing the Ucat parameters.
    :param log10_stellar_mass:
    :param log_specific_star_formation_rate: (array_like[n_gal,]) log10 of the specific
        star formation rate.
    :param redshift: (array_like[n_gal,]) galaxy redshifts.
    :param galaxy_type: (str) "blue" or "red" galaxy population.
    :param seed: (int) random seed.
    :return dust_attenuation_params: (array_like[n_gal,n_params]) dust attenuation
        parameters for specific attenuation law.
    """
    if par.dust_attenuation_law == "CharlotFall2000":
        dust_attenuation_params = sample_dust_attenuation_parameters_charlotfall2000(
            par,
            log10_stellar_mass,
            log_specific_star_formation_rate,
            redshift,
            galaxy_type=galaxy_type,
            seed=seed,
        )
    else:
        raise KeyError

    return dust_attenuation_params
