# Copyright (C) 2025 LMU Munich
# Author: Luca Tortorelli
# created: Apr 2025

import numpy as np


def sample_Dale2014_dust_emission_parameters(
    par, n_galaxies, galaxy_type="blue", seed=None
):
    """
    Sample Dale 2014 dust emission parameters from modelling the distribution in
    Thorne+2022. These parameters are used by Prospect to simulate dust emission which
    has a contribution of the order of 10^-4 in griZ and 10^-3 in JHKs. DaleNormSFR only
    for Dale2014 templates including star formation and not agn component which is
    instead given by Temple templates.

    :param par: (obj) par objects containing the Ucat parameters.
    :param n_galaxies: (int) number of galaxies to sample.
    :param galaxy_type: (str) "blue" or "red" galaxy population.
    :param seed: (int) random seed.
    :return dust_emission_params: (array_like[n_gal,2]) dust emission parameters for
        Dale 2014 implementation in ProSpect.
    """
    if seed is None:
        seed = 42
    rng = np.random.default_rng(seed)

    dale2014_dust_em_mean = getattr(par, f"dust_emission_mean_{galaxy_type}")
    dale2014_dust_em_cov = getattr(par, f"dust_emission_cov_{galaxy_type}")
    alpha_birth, alpha_screen = rng.multivariate_normal(
        dale2014_dust_em_mean, dale2014_dust_em_cov, n_galaxies
    ).T

    return np.stack((alpha_birth, alpha_screen)).T
