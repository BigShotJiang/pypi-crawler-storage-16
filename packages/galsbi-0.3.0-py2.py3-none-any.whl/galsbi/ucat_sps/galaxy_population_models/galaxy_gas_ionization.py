# Copyright (C) 2025 LMU Munich
# Author: Luca Tortorelli
# created: Apr 2025

import numpy as np
from scipy.stats import truncnorm

from galsbi.ucat_sps.config.common_sps import SOLAR_GAS_METALLICITY, SOLAR_LOG_OH_PLUS12


def sample_gas_ionization_Kashino19(
    Zgas_final, star_formation_rates, log10_stellar_masses, par, seed=None
):
    """
    This function computes the gas ionization parameter using the relation in
    equation 12 of Kashino+19. We keep the electron density fixed to the value with
    which the CLOUDY templates of FSPS have been generated, i.e. ne~100 cm^-3. We sample
    logU from a Normal distribution with mean given by the Kashino+19 relation and
    scatter of 0.1 dex, as highlighted in Kashino+19. The Normal distribution is
    truncated within the range [-4, -1].

    :param Zgas_final: (array_like[n_gal,]) final gas-phase metallicity in absolute
        units.
    :param star_formation_rates: (array_like[n_gal,]) SFR averaged over the last 100 Myr
        of the galaxy SFH. Units are Msun/yr.
    :param log10_stellar_masses: (array_like[n_gal,]) log10 of the stellar masses
        sampled from the stellar mass function.
    :param par: (obj) par objects containing the Ucat parameters.
    :param seed: (int) random seed for the truncnorm sampling.
    :return logU: (array_like[n_gal,]) gas ionization parameters.
    """
    if seed is None:
        seed = 42
    rng = np.random.default_rng(seed=seed)

    log_sSFR = np.log10(star_formation_rates / (10**log10_stellar_masses))
    logOH = np.log10(Zgas_final / SOLAR_GAS_METALLICITY) + SOLAR_LOG_OH_PLUS12 - 12
    log_ne = 2  # 100 cm^-3
    logU_mean = (
        par.gas_ionization_upsilon0
        + par.gas_ionization_upsilon1 * (logOH + 4)
        + par.gas_ionization_upsilon2 * log_ne
        + par.gas_ionization_upsilon3 * (log_sSFR + 9)
    )
    logUmin = (par.logUmin - logU_mean) / par.gas_ionization_scatter
    logUmax = (par.logUmax - logU_mean) / par.gas_ionization_scatter
    logU = truncnorm.rvs(
        logUmin,
        logUmax,
        loc=logU_mean,
        scale=par.gas_ionization_scatter,
        size=len(Zgas_final),
        random_state=rng,
    )

    return logU
