# Copyright (C) 2025 LMU Munich
# Author: Luca Tortorelli
# created: Apr 2025

from scipy.stats import truncnorm


def sample_sersic_stellar_mass(
    n_gal, n_0, n_1, n_2, n_scatter, log10_stellar_mass, min_n, max_n
):
    """
    This function samples Sérsic indices conditioned on the galaxy stellar masses.
    The stellar mass dependence of the Sérsic index is modelled using the GAMA data in
    Kelvin+12.

    :param n_gal: (int) number of galaxies.
    :param n_0: (float) Sérsic index - stellar mass relation intercept.
    :param n_1: (float) Sérsic index - stellar mass relation slope.
    :param n_2: (float) Sérsic index - stellar mass relation exponent.
    :param n_scatter: (float) Sérsic index - stellar mass relation scatter.
    :param log10_stellar_mass: (array_like[n_gal,])
        log10 of the stellar masses sampled from the stellar mass function.
    :param min_n: (float) minimum Sérsic index for the truncated distribution.
    :param max_n: (float) maximum Sérsic index for the truncated distribution.
    :return sersic_n: (array_like[n_gal,]) Sérsic indices.
    """

    sersic_n_mean = n_0 + n_1 * (log10_stellar_mass / 10.5) ** n_2
    sersic_n_min = (min_n - sersic_n_mean) / n_scatter
    sersic_n_max = (max_n - sersic_n_mean) / n_scatter
    sersic_n = truncnorm.rvs(
        sersic_n_min,
        sersic_n_max,
        loc=sersic_n_mean,
        scale=n_scatter,
        size=n_gal,
    )

    return sersic_n


def sample_sersic_for_galaxy_type(n_gal, galaxy_type, par, log10_stellar_mass):
    """
    This function samples Sérsic indices conditioned on the galaxy stellar masses for
    different galaxy types.

    :param n_gal: (int) number of galaxies.
    :param galaxy_type: (str) "blue" or "red" galaxy population.
    :param par: (obj) par objects containing the Ucat parameters.
    :param log10_stellar_mass: (array_like[n_gal,]) log10 of the stellar masses sampled
        from the stellar mass function.
    :return sersic_n: (array_like[n_gal,]) Sérsic indices.
    """

    assert galaxy_type in [
        "blue",
        "red",
    ], f"Sérsic index for galaxy_type {galaxy_type} not implemented"

    sersic_n = sample_sersic_stellar_mass(
        n_gal=n_gal,
        n_0=getattr(par, f"sersic_n_0_{galaxy_type}"),
        n_1=getattr(par, f"sersic_n_1_{galaxy_type}"),
        n_2=getattr(par, f"sersic_n_2_{galaxy_type}"),
        n_scatter=getattr(par, f"sersic_n_scatter_{galaxy_type}"),
        log10_stellar_mass=log10_stellar_mass,
        min_n=par.sersic_n_min,
        max_n=par.sersic_n_max,
    )

    return sersic_n.astype(par.catalog_precision)
