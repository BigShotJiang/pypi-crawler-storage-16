# Copyright (C) 2025 LMU Munich
# Copyright (C) 2025 ETH Zurich, Institute for Particle Physics and Astrophysics
# Author: Luca Tortorelli, Silvan Fischbacher
# created: Apr 2025

import numba
import numpy as np
from scipy.stats import truncnorm

from galsbi.ucat_sps.config.common_sps import SOLAR_GAS_METALLICITY, SOLAR_LOG_OH_PLUS12
from galsbi.ucat_sps.galaxy_population_models.galaxy_star_formation_history import (
    get_lookbacktime_from_redshift,
)


def vectorized_truncnorm_sample(
    mean, std, lower_bound, upper_bound, size=None, seed=None
):
    if seed is None:
        seed = 42
    rng = np.random.default_rng(seed=seed)
    a = (lower_bound - mean) / std
    b = (upper_bound - mean) / std
    return truncnorm.rvs(a, b, loc=mean, scale=std, size=size, random_state=rng)


def sample_gas_metallicity(
    log10_stellar_masses,
    redshifts,
    star_formation_rates,
    par,
    cosmology,
    galaxy_type="blue",
    seed=None,
):
    """
    This function samples the final gas metallicities of the galaxies based on
    equation 10 in Bellstedt+21. The coefficients of the equation evolves
    quadratically with lookback time of the observer (not that of the galaxy). The
    values in Bellstedt+21 have been obtained only for a sample of star-forming
    galaxies. The scatter around the plane also evolves quadratically with lookback
    time. The lookback times should be in units of Gyr.

    The final gas metallicity in absolute units is obtained following equation 1
    in Bellstedt+21,
    $Z_{gas} = Z_{\odot} \times 10^{[12+\log{(O/H)}] - [12+\log{(O/H)}]_{\odot}}$
    It represents the current gas-phase metallicity of the galaxy.

    :param log10_stellar_masses: (array_like[n_gal,]) log10 of the stellar masses
        drawn from the stellar mass function.
    :param redshifts: (array_like[n_gal,]) redshifts drawn from the stellar mass
        function.
    :param star_formation_rates: (array_like[n_gal,]) SFR averaged over the last
        100 Myr of the galaxy SFH. Units are Msun/yr.
    :param par: (obj) par objects containing the Ucat parameters.
    :param cosmology: (obj) PyCosmo class object.
    :param galaxy_type: (str) "blue" or "red" galaxy population.
    :param seed: (int) random seed.
    :return Zgas_final: (array_like[n_gal,]) final gas-phase metallicity in
        absolute units.
    """
    rng = np.random.default_rng(seed=seed)
    lookback_times = get_lookbacktime_from_redshift(redshifts, cosmology) / 1e9  # Gyr

    gas_metallicity_alpha0 = getattr(par, f"gas_metallicity_alpha0_{galaxy_type}")
    gas_metallicity_alpha1 = getattr(par, f"gas_metallicity_alpha1_{galaxy_type}")
    gas_metallicity_alpha2 = getattr(par, f"gas_metallicity_alpha2_{galaxy_type}")
    gas_metallicity_beta0 = getattr(par, f"gas_metallicity_beta0_{galaxy_type}")
    gas_metallicity_beta1 = getattr(par, f"gas_metallicity_beta1_{galaxy_type}")
    gas_metallicity_beta2 = getattr(par, f"gas_metallicity_beta2_{galaxy_type}")
    gas_metallicity_gamma0 = getattr(par, f"gas_metallicity_gamma0_{galaxy_type}")
    gas_metallicity_gamma1 = getattr(par, f"gas_metallicity_gamma1_{galaxy_type}")
    gas_metallicity_gamma2 = getattr(par, f"gas_metallicity_gamma2_{galaxy_type}")

    alphas_gas = (
        gas_metallicity_alpha0
        + gas_metallicity_alpha1 * lookback_times
        + gas_metallicity_alpha2 * lookback_times**2
    )
    betas_gas = (
        gas_metallicity_beta0
        + gas_metallicity_beta1 * lookback_times
        + gas_metallicity_beta2 * lookback_times**2
    )
    gammas_gas = (
        gas_metallicity_gamma0
        + gas_metallicity_gamma1 * lookback_times
        + gas_metallicity_gamma2 * lookback_times**2
    )

    logO_H_plus_12 = (
        alphas_gas * np.log10(star_formation_rates)
        + betas_gas * log10_stellar_masses
        + gammas_gas
    )

    scatter_0 = getattr(par, f"gas_metallicity_scatter0_{galaxy_type}")
    scatter_1 = getattr(par, f"gas_metallicity_scatter1_{galaxy_type}")
    scatter_2 = getattr(par, f"gas_metallicity_scatter2_{galaxy_type}")
    scatter_sigma = (
        scatter_0 + scatter_1 * lookback_times + scatter_2 * lookback_times**2
    )
    logO_H_plus_12_min = (
        np.log10(par.Zgas_init / SOLAR_GAS_METALLICITY) + SOLAR_LOG_OH_PLUS12
    )
    logO_H_plus_12_max = (
        np.log10(par.Zgas_max / SOLAR_GAS_METALLICITY) + SOLAR_LOG_OH_PLUS12
    )
    logO_H_plus_12_min = (logO_H_plus_12_min - logO_H_plus_12) / scatter_sigma
    logO_H_plus_12_max = (logO_H_plus_12_max - logO_H_plus_12) / scatter_sigma
    logO_H_plus_12_sampled = truncnorm.rvs(
        logO_H_plus_12_min,
        logO_H_plus_12_max,
        loc=logO_H_plus_12,
        scale=scatter_sigma,
        size=len(log10_stellar_masses),
        random_state=rng,
    )
    Zgas_final = SOLAR_GAS_METALLICITY * 10 ** (
        logO_H_plus_12_sampled - SOLAR_LOG_OH_PLUS12
    )

    return Zgas_final


@numba.jit(nopython=True)
def integrate_sfh(sfh, time_grid, time_step):
    """
    This function computes the cumulative formed stellar mass based on the input star
    formation history.

    :param sfh: (array_like[n_time_bins, ]) galaxy SFHs along a grid in increasing time.
                Units are Msun/yr.
    :param time_grid: (array_like[n_time_bins, ]) time grid in units of yr.
    :param time_step: (float) time grid step in units of yr.
    :return cumulative_mass: (array_like[n_time_bins, ]) formed stellar mass in units of
                             Msun.
    """
    if sfh.size != time_grid.size:
        raise ValueError("sfh and time_grid must have the same length.")

    n_steps = sfh.size
    if n_steps == 0:
        return np.empty(0, dtype=np.float64)

    cumulative_mass = np.zeros(n_steps, dtype=np.float64)
    for idx in range(1, n_steps):
        dt = time_grid[idx] - time_grid[idx - 1]
        if dt <= 0:
            dt = time_step
        area = 0.5 * (sfh[idx] + sfh[idx - 1]) * dt
        cumulative_mass[idx] = cumulative_mass[idx - 1] + area
    return cumulative_mass


def generate_gas_metallicity_history_snorm_trunc(
    Zgas_final,
    star_formation_histories,
    par,
    Zgas_init=0.0001,
):
    """
    This function creates, for each galaxy, a gas metallicity history under the
    assumption that the metallicity enrichment follows the mass build up. This
    prescription assumes the same low initial gas-phase metallicity for every
    galaxy, while different final Zgas, drawn from the
    sample_gas_metallicity_function. In order to compute the stellar mass formed
    in each time step, we use the star formation histories as function of lookback
    time. par.time_step needs to be equal to the time step in par.time_grid.

    :param Zgas_final: (array_like[n_gal,]) final gas-phase metallicity in
        absolute units.
    :param star_formation_histories: (array_like[n_gal,n_time_bins]) galaxy SFHs
        along a grid in lookback time. Units are Msun/yr.
    :param par: (obj) par objects containing the Ucat parameters.
    :param Zgas_init: (float) The initial value of the gas-phase metallicity
        history. Best to set this value to the lowest metallicity available in
        the stellar/gas templates.
    :return Z_gas: (array_like[n_gal,n_time_bins]) galaxy gas-phase metallicity
        histories along a grid in time since the beginning of the Universe.
    """
    n_gal = len(Zgas_final)
    n_time_bins = star_formation_histories.shape[1]

    if par.time_grid.shape[0] != n_time_bins:
        raise ValueError(
            "star_formation_histories and par.time_grid must have the same length."
        )

    integrated_sfh = np.zeros((n_gal, n_time_bins))
    for i in range(n_gal):
        integrated_sfh[i] = integrate_sfh(
            star_formation_histories[i][::-1], par.time_grid, par.time_step
        )

    Z_gas = np.zeros_like(star_formation_histories, dtype=float)

    for i in range(n_gal):
        total_mass = integrated_sfh[i, -1]
        if total_mass <= 0:
            fraction_of_mass_formed_per_time = np.zeros(n_time_bins)
        else:
            fraction_of_mass_formed_per_time = np.clip(
                integrated_sfh[i] / total_mass, 0.0, 1.0
            )

        Z_gas[i, :] = (
            Zgas_init
            + (Zgas_final[i] - Zgas_init) * fraction_of_mass_formed_per_time[::-1]
        )

    return Z_gas
