# Copyright (C) 2025 LMU Munich
# Author: Luca Tortorelli
# created: Apr 2025

import numpy as np

from galsbi.ucat.galaxy_population_models.galaxy_size import r50_phys_to_ang


def sample_r50_from_stellar_mass(
    redshifts, log10_stellar_mass, cosmology, par, galaxy_type="blue", seed=None
):
    """
    This function samples galaxy sizes conditioned on their stellar masses and types.

    :param redshifts: (array_like[n_gal,]) redshifts drawn from the stellar mass
        function.
    :param log10_stellar_mass: (array_like[n_gal,]) log10 of the stellar masses drawn
        from the stellar mass function.
    :param cosmology: (obj) PyCosmo class object.
    :param par: (obj) par objects containing the Ucat parameters.
    :param galaxy_type: (str) "blue" or "red" galaxy population.
    :param seed: (int) random seed.
    :return r50_ang: (array_like[n_gal,]) angular sizes in pixel.
    :return r50_phys: (array_like[n_gal,]) physical sizes of galaxies in kpc.
    """
    r50_phys = sample_r50_phys_from_stellar_mass(
        redshifts, log10_stellar_mass, par, galaxy_type, seed=seed
    )
    # convert physical size to observerd angular size
    r50_ang = r50_phys_to_ang(r50_phys, cosmology, redshifts)

    r50_ang_pix = r50_ang.astype(par.catalog_precision) / par.pixscale
    r50_ang_arcsec = r50_ang.astype(par.catalog_precision)
    r50_phys = r50_phys.astype(par.catalog_precision)

    return r50_ang_pix, r50_ang_arcsec, r50_phys


def sample_r50_phys_from_stellar_mass(
    redshifts, log10_stellar_mass, par, galaxy_type, seed=None
):
    """
    This function samples the physical galaxy sizes conditioned on the stellar mass.
    The mean size has a power-law dependence from stellar mass. A single power-law
    correctly represents blue galaxy sizes, while a flattend power-law at low sizes is
    required for red galaxies. The parameters of the power-laws evolve linearly with
    redshift. The actual galaxy sizes are drawn from a log-normal distribution centred
    on the mean size from the power-law and with scatter value taken from Shen+2003. The
    functional forms are from Nedkova+2021.

    :param redshifts: (array_like[n_gal,]) redshifts drawn from the stellar mass
        function.
    :param log10_stellar_mass: (array_like[n_gal,]) log10 of the stellar masses drawn
        from the stellar mass function.
    :param par: (obj) par objects containing the Ucat parameters.
    :param galaxy_type: (str) "blue" or "red" galaxy population.
    :param seed: (int) random seed.
    :return r50_phys: (array_like[n_gal,]) physical sizes of galaxies in kpc.
    """
    if seed is None:
        seed = 42
    rng = np.random.default_rng(seed)

    log10A_slope = par.r50_stellar_mass_logA_blue_slope
    log10A_intcpt = par.r50_stellar_mass_logA_blue_intcpt
    log10A = log10A_intcpt + log10A_slope * redshifts
    B_slope = par.r50_stellar_mass_B_blue_slope
    B_intcpt = par.r50_stellar_mass_B_blue_intcpt
    B = B_intcpt + B_slope * redshifts

    eta_slope = par.r50_stellar_mass_eta_red_slope
    eta_intcpt = par.r50_stellar_mass_eta_red_intcpt
    eta = eta_intcpt + eta_slope * redshifts
    theta_slope = par.r50_stellar_mass_theta_red_slope
    theta_intcpt = par.r50_stellar_mass_theta_red_intcpt
    theta = theta_intcpt + theta_slope * redshifts
    log10zeta_slope = par.r50_stellar_mass_logzeta_red_slope
    log10zeta_intcpt = par.r50_stellar_mass_logzeta_red_intcpt
    log10zeta = log10zeta_intcpt + log10zeta_slope * redshifts
    delta_slope = par.r50_stellar_mass_delta_red_slope
    delta_intcpt = par.r50_stellar_mass_delta_red_intcpt
    delta = delta_intcpt + delta_slope * redshifts

    if galaxy_type == "blue":
        r50_phys_mean = (
            10**log10A * ((10**log10_stellar_mass) / (5 * 10**10)) ** B
        )  # unit: kpc
    elif galaxy_type == "red":
        r50_phys_mean = ((10**log10zeta) * (10**log10_stellar_mass) ** eta) * (
            1 + ((10**log10_stellar_mass) / (10**delta))
        ) ** (theta - eta)
    else:
        raise ValueError(f"Unknown galaxy type: {galaxy_type}")

    # sample from log-normal distribution
    r50_phys_std = getattr(par, f"logr50_stellar_mass_std_{galaxy_type}")
    r50_phys = rng.normal(loc=np.log(r50_phys_mean), scale=r50_phys_std)
    r50_phys = np.exp(r50_phys)  # unit: kpc

    return r50_phys
