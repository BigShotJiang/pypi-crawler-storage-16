# Copyright (C) 2025 LMU Munich
# Copyright (C) 2025 ETH Zurich, Institute for Particle Physics and Astrophysics
# Author: Luca Tortorelli, Silvan Fischbacher
# created: Apr 2025

import warnings

import joblib
import numpy as np
from scipy.integrate import trapezoid
from scipy.stats import norm
from sklearn.exceptions import InconsistentVersionWarning

from galsbi.ucat.galaxy_sampling_util import TruncatedMVN


def massfunc_snorm_trunc(
    age, mSFR=10.0, mpeak=10.0, mperiod=1.0, mskew=0.5, magemax=13.8, mtrunc=2.0
):
    """
    This functions is a Python translation of the R code in ProSpect that
    generates SFHs from the massfunc_snorm_trunc parametrisation described in
    Robotham+20.

    :param age: (array_like[n_time_bins,]) Lookback time in units of years.
        0 means now from the point of view of the galaxy.
    :param mSFR: (float) The value of the SFR at the peak of the SFH in Msun/yr.
    :param mpeak: (float) The time at which the SFH peaks, i.e. the time at
        which the SFR is equal to mSFR, in units of Gyr.
    :param mperiod: (float) The width of the normal distribution in units of Gyr.
    :param mskew: (float) The skewness of the normal distribution in units of
        Gyr.
    :param magemax: (float) The age beyond which the SFR is set to 0, it is
        defined as 13.4 Gyr - lookbacktime(z), where magemax_z0=13.4 Gyr
        represents the epoch at which the highest redshift galaxies are known
        to exist.
    :param mtrunc: (float) This parameter controls truncation between mpeak and
        magemax. 0 means no extra truncation, 1 is about half truncated and 2
        is softly but fairly fully truncated.
    :return sfh: (array_like[n_time_bins,]) The SFH of the galaxy in units of
        Msun/yr. The array as the same length as age.
    """
    # Ensure age is an array
    age = np.atleast_1d(age)

    # Scale function ages to years
    mpeak *= 1e9
    mperiod *= 1e9
    magemax *= 1e9

    age = np.maximum(age, 1e5)  # Stop dodgy very young stellar pops forming

    # Normal SFH
    Xtemp = (age - mpeak) / mperiod
    Ytemp = Xtemp * (np.exp(mskew) ** np.arcsinh(Xtemp))
    sfh = mSFR * np.exp(-(Ytemp**2) / 2)

    # Truncation
    timetrunc = np.abs(magemax - mpeak)
    trunc_factor = 1 - norm.cdf(
        age, loc=mpeak + timetrunc / mtrunc, scale=timetrunc / (2 * mtrunc)
    )
    sfh *= trunc_factor

    # Ensuring non-negative values and limiting ages
    sfh[sfh < 0] = 0
    sfh[age > magemax] = 0

    # If input was scalar, return scalar
    if sfh.size == 1:
        return sfh.item()
    return sfh


def single_galaxy_sfh_snorm_trunc(
    time_grid, mSFR_norm, mpeak, mperiod, mskew, magemax, mtrunc
):
    """
    Evaluate the truncated skewed normal SFH for a single set of parameters.

    This is a light-weight convenience wrapper around :func:`massfunc_snorm_trunc`
    that makes the intent explicit in the public API and keeps scalar inputs
    behaving like scalars (which is relied upon in the tests).
    """
    return massfunc_snorm_trunc(
        age=time_grid,
        mSFR=mSFR_norm,
        mpeak=mpeak,
        mperiod=mperiod,
        mskew=mskew,
        magemax=magemax,
        mtrunc=mtrunc,
    )


def get_age_of_the_universe_from_redshift(redshifts, cosmology):
    """
    This function returns the age of the Universe at redshift z in years.

    :param redshifts: (array_like[n_gal,]) galaxy redshifts.
    :param cosmology: (obj) PyCosmo cosmology object.
    :return t: (array_like[n_time_bins,]) age of the Universe at the galaxy
        redshifts in years.
    """
    H0 = cosmology.params.H0
    omega_m = cosmology.params.omega_m
    omega_l = cosmology.params.omega_l
    t = np.sqrt(omega_l * (1 + redshifts) ** (-3)) + np.sqrt(
        omega_m + omega_l * (1 + redshifts) ** (-3)
    )
    t /= np.sqrt(omega_m)
    t = np.log(t)
    t *= 2 / (3 * H0 * np.sqrt(omega_l))  # s Mpc/km
    t *= 3.0857e19  # s
    t /= 3.1558150e7  # yr
    return t


def get_lookbacktime_from_redshift(redshifts, cosmology):
    """This function returns the lookback time of the observer at redshift z in
    years.

    :param redshifts: (array_like[n_time_bins,]) galaxy redshifts.
    :param cosmology: (obj) PyCosmo cosmology object.
    :return lookbacktime: (array_like[n_time_bins,]) observer lookback time at
        the galaxy redshifts in years.
    """
    age_0 = get_age_of_the_universe_from_redshift(0, cosmology)
    return age_0 - get_age_of_the_universe_from_redshift(redshifts, cosmology)


def get_mean_sfh_shape_params(log10_stellar_masses, redshifts, par, galaxy_type="blue"):
    """
    This function returns the mean values of the SFH massfunc_snorm_trunc shape
    parameters conditioned on galaxy redshifts and stellar masses. We assume that mskew
    and logmperiod evolve linearly with stellar mass, while mpeak with both redshift
    and stellar mass. The stellar mass and redshift evolutions are assumed to be linear
    in log10(stellar_mass) and log10(1+z).

    :param log10_stellar_masses: (array_like[n_gal,]) log10 of the stellar
        masses drawn from the stellar mass function.
    :param redshifts: (array_like[n_gal,]) redshifts drawn from the stellar
        mass function.
    :param par: (obj) par objects containing the Ucat parameters.
    :param galaxy_type: either blue or red.
    :return mean_sfh_shape_params: (array_like[n_gal, 3])
        mean values of the SFH shape parameters obtained as function of redshift and
        stellar mass.
    """

    logmpeak_massevo_slope_zevo_intcpt = getattr(
        par, f"logmpeak_massevo_slope_zevo_intcpt_{galaxy_type}"
    )
    logmpeak_massevo_slope_zevo_slope = getattr(
        par, f"logmpeak_massevo_slope_zevo_slope_{galaxy_type}"
    )
    logmpeak_massevo_intcpt_zevo_intcpt = getattr(
        par, f"logmpeak_massevo_intcpt_zevo_intcpt_{galaxy_type}"
    )
    logmpeak_massevo_intcpt_zevo_slope = getattr(
        par, f"logmpeak_massevo_intcpt_zevo_slope_{galaxy_type}"
    )
    logmperiod_massevo_intcpt = getattr(par, f"logmperiod_massevo_intcpt_{galaxy_type}")
    logmperiod_massevo_slope = getattr(par, f"logmperiod_massevo_slope_{galaxy_type}")
    mskew_massevo_intcpt = getattr(par, f"mskew_massevo_intcpt_{galaxy_type}")
    mskew_massevo_slope = getattr(par, f"mskew_massevo_slope_{galaxy_type}")

    mean_sfh_shape_params = np.empty((len(log10_stellar_masses), 3))

    logmpeak_massevo_slope = (
        logmpeak_massevo_slope_zevo_intcpt
        + logmpeak_massevo_slope_zevo_slope * np.log10(1 + redshifts)
    )
    logmpeak_massevo_intcpt = (
        logmpeak_massevo_intcpt_zevo_intcpt
        + logmpeak_massevo_intcpt_zevo_slope * np.log10(1 + redshifts)
    )
    mean_sfh_shape_params[:, 0] = (
        logmpeak_massevo_intcpt + logmpeak_massevo_slope * log10_stellar_masses
    )
    mean_sfh_shape_params[:, 1] = (
        logmperiod_massevo_intcpt + logmperiod_massevo_slope * log10_stellar_masses
    )
    mean_sfh_shape_params[:, 2] = (
        mskew_massevo_intcpt + mskew_massevo_slope * log10_stellar_masses
    )

    return mean_sfh_shape_params


def sample_sfh_shape_params(
    log10_stellar_masses, redshifts, par, galaxy_type="blue", seed=None
):
    """
    This function samples the SFH shape parameters from a Multivariate Truncated Normal
    distribution.

    :param log10_stellar_masses: (array_like[n_gal, ]) log10 of the stellar
        masses drawn from the stellar mass function.
    :param redshifts: (array_like[n_gal, ]) redshifts drawn from the stellar
        mass function.
    :param par: (obj) par objects containing the Ucat parameters.
    :param galaxy_type: either blue or red.
    :param seed: (int) random seed for the TruncatedMVN sampling.
    :return mpeak_norm: (array_like[n_gal, ]) fraction of the galaxy age at which SFH
        peaks.
    :return mperiod: (array_like[n_gal, ]) The width of the normal distribution in
        units of Gyr.
    :return mskew: (array_like[n_gal, ]) The skewness of the normal distribution in
        units of Gyr.
    """

    logmpeak_norm_min = getattr(par, f"logmpeak_norm_min_{galaxy_type}")
    logmpeak_norm_max = getattr(par, f"logmpeak_norm_max_{galaxy_type}")
    logmperiod_min = getattr(par, f"logmperiod_min_{galaxy_type}")
    logmperiod_max = getattr(par, f"logmperiod_max_{galaxy_type}")
    mskew_min = getattr(par, f"mskew_min_{galaxy_type}")
    mskew_max = getattr(par, f"mskew_max_{galaxy_type}")
    sfh_shape_params_cov = getattr(par, f"sfh_shape_params_cov_{galaxy_type}")

    mean_sfh_shape_params = get_mean_sfh_shape_params(
        log10_stellar_masses, redshifts, par, galaxy_type=galaxy_type
    )
    tmvn_lb = np.array([logmpeak_norm_min, logmperiod_min, mskew_min])
    tmvn_ub = np.array([logmpeak_norm_max, logmperiod_max, mskew_max])
    samples = np.array(
        [
            TruncatedMVN(
                mean_sfh_shape_params[i, :],
                sfh_shape_params_cov,
                tmvn_lb,
                tmvn_ub,
                seed=seed,
            )
            .sample(1)
            .T[0]
            for i in range(log10_stellar_masses.shape[0])
        ]
    )
    mpeak_norm, mperiod, mskew = (
        10 ** (samples[:, 0]),
        10 ** (samples[:, 1]),
        samples[:, 2],
    )

    return mpeak_norm, mperiod, mskew


def sample_sfh_snorm_trunc(
    log10_stellar_masses, redshifts, par, cosmology, galaxy_type="blue", seed=None
):
    """
    This function computes the galaxy star formation histories using the
    parametric star formation history massfunc_snorm_trunc implemented in
    Robotham+20 and used in Bellstedt+20,21. This parametrization is based on
    the four parameters mSFR, mpeak, mperiod, mskew. We do not model their
    distribution from GAMA and DEVILS data directly, otherwise we would end
    up imposing their redshift and stellar mass functions. Instead, we model
    the stellar mass and redshift dependence of the shape parameters mpeak,
    mperiod and mskew, since observationally we expect that more massive
    galaxies assembled their mass earlier and more rapidly than less massive
    galaxies. mpeak has been redefined to be the fractional age
    at which the SFH peaks, i.e., when mSFR occurs, where 0 means at the
    beginning of the galaxy life, and 1 means at the galaxy redshift.
    mpeak depends on both redshift and stellar mass,
    while mperiod and mskew depend only on stellar mass as we did not find a
    well-defined trend in data. We model the dependency on these physical
    quantities as linear relations. Once sampled from a truncated multivariate
    Normal distribution, we compute the shape of the SFH by imposing mSFR=1.0. We then
    compute the correct value of mSFR such that the integration of the star formation
    history yields the formed mass sampled from the stellar mass function.

    The time grid used here refers to the lookback time with respect to the galaxy,
    so t=0 effectively means now for the galaxy, not the observer.
    The grid goes, however, up to 13.8 Gyr to have a common time grid for every
    galaxy. The SFH is set to be 0 beyond magemax = 13.4 - lookbacktime(z),
    i.e., age of the Universe at the galaxy redshift. We limit the sampled parameters
    to the observational limits set in Bellstedt+21. We also compute the star formation
    rate averaged over the last 100 Myr of the galaxy. magemax_z0=13.4 Gyr is the age
    at which the earliest galaxies are known to exist. mtrunc=2 ensures smooth
    truncation at SFR=0 at the beginning of the galaxy life.

    :param log10_stellar_masses: (array_like[n_gal, ]) log10 of the stellar
        masses drawn from the stellar mass function.
    :param redshifts: (array_like[n_gal, ]) redshifts drawn from the stellar
        mass function.
    :param par: (obj) par objects containing the Ucat parameters.
    :param cosmology: (obj) PyCosmo class object.
    :param galaxy_type: Either blue or red.
    :param seed: (int) random seed for the TruncatedMVN sampling.
    :return sfhs: (array_like[n_gal, n_time_bins]) galaxy star formation
        histories in units of Msun/yr on the linear lookback time grid.
    :return sfrs: (array_like[n_gal, ]) star formation rates averaged over the
        last 100 Myr of the galaxy star formation history in units of Msun/yr.
    :return mSFR: (float) The value of the SFR at the peak of the SFH in units
        of Msun/yr after multiplying by formed stellar mass.
    :return mpeak_reconstrs: (float) The time at which the SFH peaks, i.e. the
        time at which the SFR is equal to mSFR, in units of Gyr.
    :return mperiod: (float) The width of the normal distribution in units of
        Gyr.
    :return mskew: (float) The skewness of the normal distribution in units of
        Gyr.
    """
    magemax_z0 = par.magemax_z0
    mtrunc = par.mtrunc

    mpeak_norm, mperiod, mskew = sample_sfh_shape_params(
        log10_stellar_masses, redshifts, par, galaxy_type=galaxy_type, seed=seed
    )

    magemaxs = magemax_z0 - (get_lookbacktime_from_redshift(redshifts, cosmology) / 1e9)
    mpeak_reconstrs = magemaxs - magemaxs * mpeak_norm

    sfhs = np.zeros((len(redshifts), len(par.time_grid)))
    sfrs = np.zeros(len(redshifts))
    mSFR = np.zeros(len(redshifts))

    for i in range(len(redshifts)):
        sfh_shape = massfunc_snorm_trunc(
            par.time_grid,
            mSFR=1.0,
            mpeak=mpeak_reconstrs[i],
            mperiod=mperiod[i],
            mskew=mskew[i],
            magemax=magemaxs[i],
            mtrunc=mtrunc,
        )
        sfh_area = trapezoid(sfh_shape, par.time_grid)
        mSFR[i] = 10 ** log10_stellar_masses[i] / sfh_area
        sfhs[i, :] = sfh_shape * mSFR[i]
        select_100Myr = (
            par.time_grid <= 1e8
        )  # here time grid has the lookback time meaning
        sfrs[i] = (
            trapezoid(sfhs[i, :][select_100Myr], par.time_grid[select_100Myr]) / 1e8
        )
    sfrs[sfrs < 1e-30] = 1e-30

    return sfhs, sfrs, mSFR, mpeak_reconstrs, mperiod, mskew


def compute_surviving_stellar_mass(
    redshifts, log10_stellar_masses, mSFR, mpeak, mperiod, mskew, Zgas_final, par
):
    """
    This function uses an emulator model to compute the surviving stellar mass of
    individual galaxies conditioned on their star formation histories and metallicities.
    Galaxies are split in bins of 0.5 in redshift and then passed to the emulator for
    log10 surviving stellar mass predictions.

    :param redshifts: (array_like[n_gal, ]) redshifts drawn from the stellar
        mass function.
    :param log10_stellar_masses: (array_like[n_gal, ]) log10 of the stellar
        masses drawn from the stellar mass function.
    :param mSFR: (array_like[n_gal, ]) The values of the SFR at the peak of the SFH in
    units of Msun/yr.
    :param mpeak: (array_like[n_gal, ]) The times at which the SFH peaks, i.e. the
        time at which the SFR is equal to mSFR, in units of Gyr.
    :param mperiod: (array_like[n_gal, ]) The widths of the normal distribution in
        units of Gyr.
    :param mskew: (array_like[n_gal, ]) The skewnesses of the normal distribution in
        units of Gyr.
    :param Zgas_final: (array_like[n_gal, ]) final gas-phase metallicity in absolute
        units.
    :param par: (obj) par objects containing the Ucat parameters.

    :return log10_surviv_stellar_masses: (array_like[n_gal,]) log10 of surviving stellar
        masses
    """
    device = "cpu"
    warnings.filterwarnings("ignore", category=InconsistentVersionWarning)

    import torch

    property_scaler = joblib.load(par.surviv_stellar_mass_emulator_property_scaler)
    log10_surviv_stellar_mass_scaler = joblib.load(
        par.surviv_stellar_mass_emulator_ssm_scaler
    )
    surviv_stellar_masses_model = torch.jit.load(
        par.surviv_stellar_mass_emulator_model, map_location=torch.device(device)
    )
    surviv_stellar_masses_model.eval()

    X_prop = np.zeros((len(log10_stellar_masses), 7))
    X_prop[:, 0] = redshifts
    X_prop[:, 1] = np.log10(mSFR)
    X_prop[:, 2] = mpeak
    X_prop[:, 3] = np.log10(mperiod)
    X_prop[:, 4] = mskew
    X_prop[:, 5] = np.log10(Zgas_final)
    X_prop[:, 6] = log10_stellar_masses
    X_prop_scaled = property_scaler.transform(X_prop)

    with torch.no_grad():
        log10_surviv_stellar_masses_scaled = surviv_stellar_masses_model(
            torch.tensor(X_prop_scaled, dtype=torch.float32).to(device)
        )
        log10_surviv_stellar_masses_scaled = (
            log10_surviv_stellar_masses_scaled.cpu().numpy()
        )
    log10_surviv_stellar_masses = log10_surviv_stellar_mass_scaler.inverse_transform(
        log10_surviv_stellar_masses_scaled
    )[:, 0]

    return log10_surviv_stellar_masses
