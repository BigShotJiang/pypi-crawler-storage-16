# Copyright (C) 2025 LMU Munich
# Author: Luca Tortorelli
# created: Apr 2025

import numpy as np


def sample_velocity_dispersion_zahid(par, log10_stellar_masses, seed=None):
    """
    This function samples the velocity dispersion of each galaxy conditioned on its
    stellar mass. We use equation 5 in Zahid+2016 to determine the mean velocity
    dispersion as function of stellar mass. Then we sample the actual velocity
    dispersion from a Gaussian having width from Figure 9 in Zahid+2016. We also set a
    lower limit equal to 10 km/s for the velocity dispersion.

    :param par: (obj) par objects containing the Ucat parameters.
    :param log10_stellar_masses: (array_like[n_gal,]) log10 of the stellar masses drawn
        from the stellar mass function.
    :param seed: (int) random seed.
    :return vel_disp: (array_like[n_gal,]) velocity dispersions in units of km/s.
    """
    if seed is None:
        seed = 42
    rng = np.random.default_rng(seed)

    logsigma_b_zahid = par.vel_disp_logsigma_b
    logM_b_zahid = par.vel_disp_logM_b
    s_1_zahid = par.vel_disp_s_1
    s_2_zahid = par.vel_disp_s_2
    std_vel_disp_zahid = par.vel_disp_std

    vel_disp_mean = np.zeros(len(log10_stellar_masses))
    select_lowmass = log10_stellar_masses <= logM_b_zahid
    select_highmass = log10_stellar_masses > logM_b_zahid
    vel_disp_mean[select_lowmass] = (10**logsigma_b_zahid) * (
        (10 ** log10_stellar_masses[select_lowmass]) / (10**logM_b_zahid)
    ) ** s_1_zahid
    vel_disp_mean[select_highmass] = (10**logsigma_b_zahid) * (
        (10 ** log10_stellar_masses[select_highmass]) / (10**logM_b_zahid)
    ) ** s_2_zahid
    vel_disp = rng.normal(loc=vel_disp_mean, scale=std_vel_disp_zahid)
    vel_disp[(vel_disp < 10)] = 10  # km/s

    return vel_disp
