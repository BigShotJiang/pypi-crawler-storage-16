# Copyright (C) 2025 LMU Munich
# Copyright (C) 2025 ETH Zurich, Institute for Particle Physics and Astrophysics
# Author: Luca Tortorelli, Silvan Fischbacher
# created: Apr 2025

import warnings

import healpy as hp
import numpy as np
import PyCosmo
from cosmic_toolbox import logger
from ivy.plugin.base_plugin import BasePlugin
from ufig import coordinate_util

from galsbi.ucat import filters_util, galaxy_sampling_util, utils
from galsbi.ucat.galaxy_population_models.galaxy_position import sample_position_uniform
from galsbi.ucat.galaxy_population_models.galaxy_shape import (
    sample_ellipticities_for_galaxy_type,
)
from galsbi.ucat.plugins.sample_galaxies_photo import ExtinctionMapEvaluator, in_pos
from galsbi.ucat_sps.galaxy_population_models.galaxy_agn import (
    sample_ratio_agn_to_galaxy_bolometric_luminosity,
)
from galsbi.ucat_sps.galaxy_population_models.galaxy_dust_attenuation import (
    sample_dust_attenuation_parameters,
)
from galsbi.ucat_sps.galaxy_population_models.galaxy_dust_emission import (
    sample_Dale2014_dust_emission_parameters,
)
from galsbi.ucat_sps.galaxy_population_models.galaxy_gas_ionization import (
    sample_gas_ionization_Kashino19,
)
from galsbi.ucat_sps.galaxy_population_models.galaxy_light_profile import (
    sample_sersic_for_galaxy_type,
)
from galsbi.ucat_sps.galaxy_population_models.galaxy_metallicity_history import (
    generate_gas_metallicity_history_snorm_trunc,
    sample_gas_metallicity,
)
from galsbi.ucat_sps.galaxy_population_models.galaxy_size import (
    sample_r50_from_stellar_mass,
)
from galsbi.ucat_sps.galaxy_population_models.galaxy_star_formation_history import (
    compute_surviving_stellar_mass,
    sample_sfh_snorm_trunc,
)
from galsbi.ucat_sps.galaxy_population_models.galaxy_stellar_mass_function import (
    initialize_stellar_mass_functions,
)
from galsbi.ucat_sps.galaxy_population_models.galaxy_velocity_dispersion import (
    sample_velocity_dispersion_zahid,
)
from galsbi.ucat_sps.sps_sed_generator import MagnitudeGenerator

LOGGER = logger.get_logger(__file__)
warnings.filterwarnings("once")


def check_max_mem_error(max_mem_hard_limit=10000):
    """
    Check if the catalog does not exceed allowed memory.

    Prevents job crashes on clusters.
    """

    mem_mb_current = utils.memory_usage_psutil()
    if mem_mb_current > max_mem_hard_limit:
        raise galaxy_sampling_util.UCatNumGalError(
            "The sample_galaxies process is taking too much memory: "
            f"mem_mb_current={mem_mb_current}, max_mem_hard_limit={max_mem_hard_limit}"
        )


class Plugin(BasePlugin):
    """
    Generate a catalog of galaxies with SPS computed magnitudes in multiple bands.
    """

    def __call__(self):
        par = self.ctx.parameters

        # Cosmology
        cosmo = PyCosmo.build()
        cosmo.set(h=par.h, omega_m=par.omega_m)

        # Healpix pixelization
        if par.sampling_mode == "wcs":
            LOGGER.info("Sampling galaxies based on RA/DEC and pixel scale")
            # Healpix pixelization
            w = coordinate_util.wcs_from_parameters(par)
            self.ctx.pixels = coordinate_util.get_healpix_pixels(
                par.nside_sampling, w, par.size_x, par.size_y
            )
            if len(self.ctx.pixels) < 15:
                LOGGER.warning(
                    f"Only {len(self.ctx.pixels)} healpy pixels in the footprint,"
                    " consider increasing the nside_sampling"
                )
        elif par.sampling_mode == "healpix":
            LOGGER.info("Sampling galaxies based on healpix pixels")
            self.ctx.pixels = coordinate_util.get_healpix_pixels_from_map(par)
            w = None
        else:
            raise ValueError(
                f"Unknown sampling mode: {par.sampling_mode}, must be wcs or healpix"
            )
        self.ctx.pixarea = hp.nside2pixarea(par.nside_sampling, degrees=False)

        # Magnitude calculator
        all_filters = np.unique(par.filters + [par.lum_fct_filter_band])

        # backward compatibility - check if full filter names are set
        if not hasattr(par, "filters_full_names"):
            par.filters_full_names = filters_util.get_default_full_filter_names(
                all_filters
            )
            warnings.warn(
                "setting filters to default, this will cause problems if you work"
                " with filters from different cameras in the same band",
                stacklevel=1,
            )

        # initialize stellar mass functions
        sm_funcs_lowmass = initialize_stellar_mass_functions(
            par,
            cosmo=cosmo,
            pixarea=self.ctx.pixarea,
            z_sm_intp=None,
            mass_key="lowmass",  # z_m_intp
        )

        sm_funcs_highmass = initialize_stellar_mass_functions(
            par,
            cosmo=cosmo,
            pixarea=self.ctx.pixarea,
            z_sm_intp=None,
            mass_key="highmass",  # z_m_intp
        )

        # setup SPS SED generator
        sps_sed_generator = MagnitudeGenerator(par)

        # Extinction
        exctinction_eval = ExtinctionMapEvaluator(par)

        # Initialize galaxy catalog
        self.ctx.galaxies = galaxy_sampling_util.Catalog()
        self.ctx.galaxies.columns = [
            "id",
            "z",
            "log10_stellar_mass",
            "log10_surviv_stellar_mass",
            "star_formation_history",
            "star_formation_rate",
            "mSFR",
            "mpeak",
            "mperiod",
            "mskew",
            "gas_metallicity",
            "metallicity_history",
            "gas_ionization",
            "dust_attenuation",
            "dust_emission",
            "int_r50",
            "r50_phys",
            "int_e1",
            "int_e2",
            "sersic_n",
            "sigma_vel",
            "fagn",
            # "mag",
            "galaxy_type",
            "excess_b_v",
        ]

        # Columns modified inside loop
        loop_cols = [
            "z",
            "log10_stellar_mass",
            "log10_surviv_stellar_mass",
            "star_formation_history",
            "star_formation_rate",
            "mSFR",
            "mpeak",
            "mperiod",
            "mskew",
            "gas_metallicity",
            "metallicity_history",
            "gas_ionization",
            "dust_attenuation",
            "dust_emission",
            "int_r50",
            "r50_phys",
            "int_e1",
            "int_e2",
            "sersic_n",
            "sigma_vel",
            "fagn",
            # "mag",
            "galaxy_type",
            "excess_b_v",
        ]
        if w is not None:
            loop_cols += ["x", "y"]
            self.ctx.galaxies.columns += ["x", "y"]
        else:
            loop_cols += ["ra", "dec"]
            self.ctx.galaxies.columns += ["ra", "dec"]
        for c in loop_cols:
            setattr(self.ctx.galaxies, c, [])

        self.ctx.galaxies.int_magnitude_dict = dict()
        self.ctx.galaxies.abs_magnitude_dict = dict()
        for key in par.filters:
            self.ctx.galaxies.int_magnitude_dict[key] = []
            self.ctx.galaxies.abs_magnitude_dict[key] = []
        # loop over stellar mass functions
        for g in par.galaxy_types:
            n_gal_type = 0
            n_gal_type_max = getattr(par, f"n_gal_max_{g}")
            max_reached = False

            for i in LOGGER.progressbar(
                range(len(self.ctx.pixels)),
                desc=f"getting {g:<4s} galaxies for healpix pixels",
                at_level="debug",
            ):
                # Sample stellar masses and redshifts from double stellar mass function
                sm_lowmass, z_lowmass = sm_funcs_lowmass[g].sample_z_sm_and_apply_cut(
                    seed_ngal=par.seed
                    + self.ctx.pixels[i]
                    + par.gal_num_seed_offset
                    + par.SEED_OFFSET_SMFUN * i,
                    n_gal_max=n_gal_type_max,
                )

                sm_highmass, z_highmass = sm_funcs_highmass[
                    g
                ].sample_z_sm_and_apply_cut(
                    seed_ngal=par.seed
                    + self.ctx.pixels[i]
                    + par.gal_num_seed_offset
                    + par.SEED_OFFSET_SMFUN * i,
                    n_gal_max=n_gal_type_max,
                )

                log10_stellar_masses = np.concatenate(
                    (sm_lowmass, sm_highmass)
                )  # log10(Mass/Msun)
                z = np.concatenate((z_lowmass, z_highmass))

                ngal = len(log10_stellar_masses)

                # star formation history
                (
                    sfhs_msun_yr,
                    sfrs_msun_yr,
                    mSFR,
                    mpeak,
                    mperiod,
                    mskew,
                ) = sample_sfh_snorm_trunc(
                    log10_stellar_masses,
                    z,
                    par,
                    cosmo,
                    galaxy_type=g,
                    seed=par.seed
                    + self.ctx.pixels[i]
                    + par.gal_num_seed_offset
                    + par.SEED_OFFSET_SFH * i,
                )

                # gas metallicity history
                Zgas_final = sample_gas_metallicity(
                    log10_stellar_masses,
                    z,
                    sfrs_msun_yr,
                    par,
                    cosmo,
                    galaxy_type=g,
                    seed=par.seed
                    + self.ctx.pixels[i]
                    + par.gal_num_seed_offset
                    + par.SEED_OFFSET_ZGAS * i,
                )
                Z_gas = generate_gas_metallicity_history_snorm_trunc(
                    Zgas_final,
                    sfhs_msun_yr,
                    par,
                    Zgas_init=par.Zgas_init,
                )

                # surviving stellar mass
                log10_surviv_stellar_masses = compute_surviving_stellar_mass(
                    z,
                    log10_stellar_masses,
                    mSFR,
                    mpeak,
                    mperiod,
                    mskew,
                    Zgas_final,
                    par,
                )

                # gas ionization
                logU = sample_gas_ionization_Kashino19(
                    Zgas_final,
                    sfrs_msun_yr,
                    log10_stellar_masses,
                    par,
                    seed=par.seed
                    + self.ctx.pixels[i]
                    + par.gal_num_seed_offset
                    + par.SEED_OFFSET_LOGU * i,
                )

                # dust attenuation (internal to the observed galaxy)
                log_specific_star_formation_rate = np.log10(
                    sfrs_msun_yr / 10**log10_stellar_masses
                )
                dust_attenuation_params = sample_dust_attenuation_parameters(
                    par,
                    log10_stellar_masses,
                    log_specific_star_formation_rate,
                    z,
                    galaxy_type=g,
                    seed=par.seed
                    + self.ctx.pixels[i]
                    + par.gal_num_seed_offset
                    + par.SEED_OFFSET_DUSTATT * i,
                )
                # dust emission
                dust_emission_params = sample_Dale2014_dust_emission_parameters(
                    par,
                    len(log10_stellar_masses),
                    galaxy_type=g,
                    seed=par.seed
                    + self.ctx.pixels[i]
                    + par.gal_num_seed_offset
                    + par.SEED_OFFSET_DUSTEM * i,
                )

                # intrinsic size z
                int_r50, int_r50_arcsec, r50_phys = sample_r50_from_stellar_mass(
                    z,
                    log10_stellar_masses,
                    cosmo,
                    par,
                    galaxy_type=g,
                    seed=par.seed
                    + self.ctx.pixels[i]
                    + par.gal_num_seed_offset
                    + par.SEED_OFFSET_SIZE * i,
                )

                # intrinsic ellipticity
                np.random.seed(
                    par.seed + self.ctx.pixels[i] + par.gal_ellipticities_seed_offset
                )
                (
                    int_e1,
                    int_e2,
                ) = sample_ellipticities_for_galaxy_type(
                    n_gal=ngal, galaxy_type=g, par=par
                )

                # sersic index
                np.random.seed(
                    par.seed + self.ctx.pixels[i] + par.gal_sersic_seed_offset
                )
                sersic_n = sample_sersic_for_galaxy_type(
                    n_gal=ngal,
                    galaxy_type=g,
                    par=par,
                    log10_stellar_mass=log10_stellar_masses,
                )

                # assign velocity dispersion
                vel_disp = sample_velocity_dispersion_zahid(
                    par,
                    log10_stellar_masses,
                    seed=par.seed
                    + self.ctx.pixels[i]
                    + par.gal_num_seed_offset
                    + par.SEED_OFFSET_VELDISP * i,
                )

                # sample agn luminosity
                fagn = sample_ratio_agn_to_galaxy_bolometric_luminosity(
                    par,
                    z,
                    log10_stellar_masses,
                    galaxy_type=g,
                    seed=par.seed
                    + self.ctx.pixels[i]
                    + par.gal_num_seed_offset
                    + par.SEED_OFFSET_AGN * i,
                )

                # Positions
                np.random.seed(par.seed + self.ctx.pixels[i] + par.gal_dist_seed_offset)
                # x and y for wcs, ra and dec for healpix model
                x, y = sample_position_uniform(
                    len(z), w, self.ctx.pixels[i], par.nside_sampling
                )
                # Make the catalog precision already here to avoid inconsistencies in
                # the selection
                x = x.astype(par.catalog_precision)
                y = y.astype(par.catalog_precision)

                # apply MW Extinction
                excess_b_v = exctinction_eval(w, x, y)
                if len(z) == 1:
                    excess_b_v = np.array([excess_b_v])

                # select galaxies in image boundaries
                if w is not None:
                    select = in_pos(x, y, par)
                else:
                    select = np.ones_like(x, dtype=bool)
                n_gal = np.count_nonzero(select)
                n_gal_type += n_gal

                # store
                if w is not None:
                    self.ctx.galaxies.x.append(x[select].astype(par.catalog_precision))
                    self.ctx.galaxies.y.append(y[select].astype(par.catalog_precision))
                else:
                    self.ctx.galaxies.ra.append(x[select].astype(par.catalog_precision))
                    self.ctx.galaxies.dec.append(
                        y[select].astype(par.catalog_precision)
                    )

                self.ctx.galaxies.z.append(z[select].astype(par.catalog_precision))

                self.ctx.galaxies.galaxy_type.append(
                    np.ones(n_gal, dtype=np.ushort) * sm_funcs_lowmass[g].galaxy_type
                )
                self.ctx.galaxies.excess_b_v.append(
                    excess_b_v[select].astype(par.catalog_precision)
                )
                self.ctx.galaxies.log10_stellar_mass.append(
                    log10_stellar_masses[select].astype(par.catalog_precision)
                )
                self.ctx.galaxies.star_formation_history.append(
                    np.array(sfhs_msun_yr)[select]
                )
                self.ctx.galaxies.star_formation_rate.append(sfrs_msun_yr[select])
                self.ctx.galaxies.mSFR.append(mSFR[select])
                self.ctx.galaxies.mpeak.append(mpeak[select])
                self.ctx.galaxies.mperiod.append(mperiod[select])
                self.ctx.galaxies.mskew.append(mskew[select])
                self.ctx.galaxies.gas_metallicity.append(
                    np.array(Zgas_final)[select].astype(par.catalog_precision)
                )
                self.ctx.galaxies.metallicity_history.append(Z_gas[select])
                self.ctx.galaxies.log10_surviv_stellar_mass.append(
                    log10_surviv_stellar_masses[select]
                )
                self.ctx.galaxies.gas_ionization.append(
                    np.array(logU)[select].astype(par.catalog_precision)
                )
                self.ctx.galaxies.dust_attenuation.append(
                    np.array(dust_attenuation_params)[select].astype(
                        par.catalog_precision
                    )
                )
                self.ctx.galaxies.dust_emission.append(
                    np.array(dust_emission_params)[select].astype(par.catalog_precision)
                )
                self.ctx.galaxies.int_r50.append(
                    np.array(int_r50)[select].astype(par.catalog_precision)
                )
                self.ctx.galaxies.r50_phys.append(
                    np.array(r50_phys)[select].astype(par.catalog_precision)
                )
                self.ctx.galaxies.int_e1.append(
                    np.array(int_e1)[select].astype(par.catalog_precision)
                )
                self.ctx.galaxies.int_e2.append(
                    np.array(int_e2)[select].astype(par.catalog_precision)
                )
                self.ctx.galaxies.sersic_n.append(
                    np.array(sersic_n)[select].astype(par.catalog_precision)
                )
                self.ctx.galaxies.sigma_vel.append(
                    np.array(vel_disp)[select].astype(par.catalog_precision)
                )
                self.ctx.galaxies.fagn.append(
                    np.array(fagn)[select].astype(par.catalog_precision)
                )

                # check memory footprint
                check_max_mem_error()

                # see if number of galaxies is OK
                if n_gal_type > n_gal_type_max * par.ngal_multiplier:
                    max_reached = True
                    if par.raise_max_num_gal_error:
                        raise galaxy_sampling_util.UCatNumGalError(
                            f"exceeded number of {g} galaxies "
                            "{n_gal_type}>{n_gal_type_max}"
                        )
                    else:
                        break

            LOGGER.info(
                f"smfun={g} n_gals={n_gal_type} maximum number of galaxies "
                f"reached={max_reached} ({n_gal_type_max})"
            )

        # Concatenate columns
        for c in loop_cols:
            setattr(self.ctx.galaxies, c, np.concatenate(getattr(self.ctx.galaxies, c)))

        LOGGER.info(f"Computing magnitudes with {par.sed_generator}")
        output_sed_generator = sps_sed_generator(
            par,
            z=self.ctx.galaxies.z,
            mSFR=self.ctx.galaxies.mSFR,
            mpeak=self.ctx.galaxies.mpeak,
            mperiod=self.ctx.galaxies.mperiod,
            mskew=self.ctx.galaxies.mskew,
            Zgas_final=self.ctx.galaxies.gas_metallicity,
            logU=self.ctx.galaxies.gas_ionization,
            fagn=self.ctx.galaxies.fagn,
            dust_attenuation_params=self.ctx.galaxies.dust_attenuation,
            excess_b_v=self.ctx.galaxies.excess_b_v,
            dust_emission_params=self.ctx.galaxies.dust_emission,
            vel_disp=self.ctx.galaxies.sigma_vel,
            ssp_library_filepath=par.ssp_library_filepath,
            filter_names=par.filters_full_names_prospect,
            cosmology=cosmo,
            log10_stellar_mass=self.ctx.galaxies.log10_stellar_mass,
        )

        for j, key in enumerate(par.filters):
            self.ctx.galaxies.int_magnitude_dict[key] = output_sed_generator[1][
                :, j
            ]  # maybe save mags before and after mw extinction
            self.ctx.galaxies.abs_magnitude_dict[key] = output_sed_generator[0][:, j]

        # Set apparent (lensed) magnitudes, for now equal to intrinsic magnitudes
        self.ctx.galaxies.magnitude_dict = dict()
        for band, mag in self.ctx.galaxies.int_magnitude_dict.items():
            self.ctx.galaxies.magnitude_dict[band] = mag.copy()

        # Number of galaxies and id
        self.ctx.numgalaxies = self.ctx.galaxies.z.size
        self.ctx.galaxies.id = np.arange(self.ctx.numgalaxies)

        # Backward compatibility
        self.ctx.galaxies.blue_red = np.ones(len(self.ctx.galaxies.z), dtype=np.ushort)
        self.ctx.galaxies.blue_red[
            self.ctx.galaxies.galaxy_type == sm_funcs_lowmass["blue"].galaxy_type
        ] = 1
        self.ctx.galaxies.blue_red[
            self.ctx.galaxies.galaxy_type == sm_funcs_lowmass["red"].galaxy_type
        ] = 0

        if par.save_SEDs & (par.sed_generator.lower() == "prospect"):
            # Store SEDs in the catalog
            self.ctx.restframe_wavelength_for_SED = output_sed_generator[2]
            self.ctx.galaxies.sed = output_sed_generator[3]

        LOGGER.info(
            f"galaxy counts n_total={self.ctx.numgalaxies} "
            "mem_mb_current={utils.memory_usage_psutil():5.1f}"
        )

    def __str__(self):
        return "sample gal photo prospect"
