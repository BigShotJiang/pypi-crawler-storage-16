#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(rhdf5)
  library(ProSpect)
  library(foreach)
  library(celestial)
  library(doParallel)
})

args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 2) {
  stop("Usage: run_prospect.R input.h5 output.h5")
}
input_file  <- args[1]
output_file <- args[2]

# --- 1) Read inputs from HDF5 ---
ssp_library_filepath <- h5read(input_file, "ssp_library_filepath")
ssp_library_filepath <- as.character(ssp_library_filepath)

full_resolution_SEDs_flag <- h5read(input_file, "full_resolution_SEDs")
full_resolution_SEDs <- as.logical(full_resolution_SEDs_flag)

n_cores <- as.integer(h5read(input_file, "n_cores"))

redshifts          <- h5read(input_file, "redshifts")
mSFR               <- h5read(input_file, "mSFR")
mpeak              <- h5read(input_file, "mpeak")
mperiod            <- h5read(input_file, "mperiod")
mskew              <- h5read(input_file, "mskew")
gas_metallicity    <- h5read(input_file, "gas_metallicity")
gas_ionization     <- h5read(input_file, "gas_ionization")
tau_birth          <- h5read(input_file, "tau_birth")
tau_screen         <- h5read(input_file, "tau_screen")
velocity_dispersion<- h5read(input_file, "velocity_dispersion")
Eb                 <- h5read(input_file, "Eb")
alpha_SF_birth     <- h5read(input_file, "alpha_SF_birth")
alpha_SF_screen    <- h5read(input_file, "alpha_SF_screen")

H0     <- as.numeric(h5read(input_file, "H0"))
OmegaM <- as.numeric(h5read(input_file, "OmegaM"))

filters <- h5read(input_file, "filters")
filters <- as.character(filters)

# --- 2) Set up SSP library and filters ---
SSP_library <- speclib_FITSload(ssp_library_filepath)
if (!full_resolution_SEDs) {
  SSP_library <- speclibReBin(SSP_library, wavegrid = BC03lr$Wave)
}

filtout <- foreach(i = filters) %do% { approxfun(getfilt(i)) }

# --- 3) Parallel setup ---
cl <- makeCluster(n_cores)
registerDoParallel(cl)
cat(paste0("Running ProSpect on ", n_cores, " cores\n"))

LumDist_Mpc <- cosdistLumDist(z = redshifts, H0 = H0, OmegaM = OmegaM)
t_lb_Gyr    <- cosdistTravelTime(z = redshifts, H0 = H0, OmegaM = OmegaM)
agemax      <- 13.4e9 - t_lb_Gyr * 1e9

# --- 4) Main ProSpect loop (same as your foreach) ---
results <- foreach(
  i = seq_along(redshifts),
  .packages = c("rhdf5", "ProSpect", "foreach", "doParallel", "celestial")
) %dopar% {

  genSED <- ProSpectSED(
    massfunc         = massfunc_snorm_trunc,
    mSFR             = mSFR[i],
    mpeak            = mpeak[i],
    mperiod          = mperiod[i],
    mskew            = mskew[i],
    tau_birth        = tau_birth[i],
    tau_screen       = tau_screen[i],
    alpha_SF_birth   = alpha_SF_birth[i],
    alpha_SF_screen  = alpha_SF_screen[i],
    Eb               = Eb[i],
    z                = 0,
    LumDist_Mpc      = LumDist_Mpc[i],
    filtout          = filtout,
    filters          = filters,
    Z                = Zfunc_massmap_lin,
    Dale             = Dale_NormTot,
    speclib          = SSP_library,
    agemax           = agemax[i],
    magemax          = agemax[i] / 1e9,
    emission         = TRUE,
    Zfinal           = gas_metallicity[i],
    q                = 10^(gas_ionization[i]) * 29970254700,
    Zagemax          = agemax[i] / 1e9,
    AGNlum           = 0,
    disp_stars       = TRUE,
    veldisp          = velocity_dispersion[i]
  )

  list(
    rest_mags           = genSED$Photom,
    rest_fluxes_Lsol_A  = genSED$FinalLum$lum
  )
}

stopCluster(cl)

# --- 5) Stack results ---
rest_mags_matrix <- do.call(cbind, lapply(results, function(x) x$rest_mags))
rest_fluxes_Lsol_A_matrix <- do.call(
  cbind, lapply(results, function(x) x$rest_fluxes_Lsol_A)
)

# For the wavelength grid, reuse genSED from the first object
genSED_first <- ProSpectSED(
  massfunc         = massfunc_snorm_trunc,
  mSFR             = mSFR[1],
  mpeak            = mpeak[1],
  mperiod          = mperiod[1],
  mskew            = mskew[1],
  tau_birth        = tau_birth[1],
  tau_screen       = tau_screen[1],
  alpha_SF_birth   = alpha_SF_birth[1],
  alpha_SF_screen  = alpha_SF_screen[1],
  Eb               = Eb[1],
  z                = 0,
  LumDist_Mpc      = LumDist_Mpc[1],
  filtout          = filtout,
  filters          = filters,
  Z                = Zfunc_massmap_lin,
  Dale             = Dale_NormTot,
  speclib          = SSP_library,
  agemax           = agemax[1],
  magemax          = agemax[1] / 1e9,
  emission         = TRUE,
  Zfinal           = gas_metallicity[1],
  q                = 10^(gas_ionization[1]) * 29970254700,
  Zagemax          = agemax[1] / 1e9,
  AGNlum           = 0,
  disp_stars       = TRUE,
  veldisp          = velocity_dispersion[1]
)

rest_wave_A <- genSED_first$FinalLum$wave

# --- 6) Write outputs to HDF5 for Python ---
if (file.exists(output_file)) file.remove(output_file)
h5createFile(output_file)

h5write(rest_mags_matrix,          output_file, "rest_mags")
h5write(rest_wave_A,               output_file, "rest_wave_A")
h5write(rest_fluxes_Lsol_A_matrix, output_file, "rest_fluxes_Lsol_A")

H5close()
