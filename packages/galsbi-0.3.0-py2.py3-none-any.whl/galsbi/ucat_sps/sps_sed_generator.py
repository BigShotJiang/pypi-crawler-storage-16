# Copyright (C) 2025 LMU Munich
# Author: Luca Tortorelli
# created: Apr 2025

import os
import subprocess
import tempfile
import warnings
from importlib.resources import files

import h5py
import joblib
import numpy as np
import torch
from scipy import interpolate
from scipy.integrate import trapezoid

import galsbi
from galsbi.ucat.spectrum_util import spline_ext_coeff
from galsbi.ucat_sps.config.common_sps import (
    LIGHTSPEED_ANGSTROM_S,
    MPC_TO_CM,
    SOLAR_LUMINOSITY_ERG_S,
)
from galsbi.ucat_sps.spectrum_util_sps import (
    apply_extinction,
    compute_Temple21_AGN_contributions,
)


class MagnitudeGenerator:
    """
    Class to generate magnitudes using SPS models.

    It will contain ProSpect, magnitude emulator and spectra emulator.
    """

    def __init__(self, par):
        if par.sed_generator.lower() == "prospect":
            self.magnitude_calculator = get_magnitudes_with_ProSpect
        elif par.sed_generator == "emulator":
            self.magnitude_calculator = get_magnitudes_with_emulator
        else:
            raise KeyError

    def __call__(self, par, z, **params):
        """Returns observed magnitudes :param **params:"""
        return self.magnitude_calculator(par, z, **params)


def get_magnitudes_with_ProSpect(
    par,
    z,
    mSFR,
    mpeak,
    mperiod,
    mskew,
    Zgas_final,
    logU,
    fagn,
    dust_attenuation_params,
    excess_b_v,
    dust_emission_params=None,
    vel_disp=None,
    ssp_library_filepath=None,
    filter_names=None,
    cosmology=None,
    log10_stellar_mass=None,
):
    """
    This function returns AB magnitudes for the galaxies sampled in GalSBI- SPS. It
    computes rest-frame SEDs with ProSpect, applies velocity broadening, adds the AGN
    component, applies Milky Way extinction, and integrates in the filter bands.

    :param par: (obj) par objects containing the Ucat parameters.
    :param z: (array_like[n_gal,]) galaxy redshift.
    :param mSFR: (array_like[n_gal, ]) mSFR parameter for the
        massfunc_snorm_trunc function in ProSpect in Msun/yr.
    :param mpeak: (array_like[n_gal, ]) mpeak parameter for the
        massfunc_snorm_trunc function in ProSpect in Gyr.
    :param mperiod: (array_like[n_gal, ]) mperiod parameter for the
        massfunc_snorm_trunc function in ProSpect.
    :param mskew: (array_like[n_gal, ]) mskew parameter for the
        massfunc_snorm_trunc function in ProSpect.
    :param Zgas_final: (array_like[n_gal, ]) gas-phase metallicity at the
        time of observation.
    :param logU: (array_like[n_gal, ]) gas ionisation parameter.
    :param vel_disp: (array_like[n_gal, ]) velocity dispersion in km/s.
    :param fagn: (array_like[n_gal, ]) fraction of AGN luminosity sampled
        from GalSBI-SPS.
    :param dust_attenuation_params: (array_like[n_gal,3]) dust
        attenuation parameters for the tau_birth and tau_screen
        parameters in ProSpect.
    :param excess_b_v: (array_like[n_gal, ]) E(B-V) Milky Way extinction.
    :param dust_emission_params: (array_like[n_gal,2]) dust
        emission parameters for the alpha_SF_birth and alpha_SF_screen
        parameters in ProSpect.
    :param ssp_library_filepath: (str) Filepath to the SSP library
        generated with ProGeny.
    :param filter_names: (list) filter names recognized by ProSpect.
    :param cosmology: (obj) PyCosmo cosmology object.
    :param log10_stellar_mass: (array_like[n_gal, ]) log10 stellar mass.
        Not used in this function, but needed for emulator.
    :return rest_mags: (array_like[n_gal, n_bands]) rest-frame AB
        magnitudes.
    :return obs_mags: (array_like[n_gal, n_bands]) observed-frame AB
        magnitudes.
    """
    warnings.filterwarnings("ignore", category=DeprecationWarning)
    with tempfile.NamedTemporaryFile(suffix=".h5", delete=False) as tmp_in:
        tmp_in_path = tmp_in.name
    with tempfile.NamedTemporaryFile(suffix=".h5", delete=False) as tmp_out:
        tmp_out_path = tmp_out.name

    with h5py.File(tmp_in_path, "w") as f:
        f.create_dataset("ssp_library_filepath", data=np.bytes_(ssp_library_filepath))
        f.create_dataset(
            "full_resolution_SEDs", data=int(bool(par.full_resolution_SEDs))
        )
        f.create_dataset("n_cores", data=par.n_cores_for_sed_generation)
        f.create_dataset("redshifts", data=z)
        f.create_dataset("mSFR", data=mSFR)
        f.create_dataset("mpeak", data=mpeak)
        f.create_dataset("mperiod", data=mperiod)
        f.create_dataset("mskew", data=mskew)
        f.create_dataset("gas_metallicity", data=Zgas_final)
        f.create_dataset("gas_ionization", data=logU)
        f.create_dataset("tau_birth", data=10 ** (dust_attenuation_params[:, 0]))
        f.create_dataset("tau_screen", data=10 ** (dust_attenuation_params[:, 1]))
        f.create_dataset("velocity_dispersion", data=vel_disp)
        f.create_dataset("Eb", data=dust_attenuation_params[:, 2])
        f.create_dataset("alpha_SF_birth", data=dust_emission_params[:, 0])
        f.create_dataset("alpha_SF_screen", data=dust_emission_params[:, 1])
        f.create_dataset("H0", data=par.h * 100.0)
        f.create_dataset("OmegaM", data=par.omega_m)
        # Filters as variable-length strings
        dt = h5py.string_dtype(encoding="utf-8")
        f.create_dataset("filters", data=np.array(filter_names, dtype=dt))

    r_script_path = files(galsbi).joinpath("ucat_sps/run_prospect.r")
    cmd = [
        "Rscript",
        str(r_script_path),
        tmp_in_path,
        tmp_out_path,
    ]
    subprocess.check_call(cmd)

    with h5py.File(tmp_out_path, "r") as f:
        rest_mags = np.array(f["rest_mags"])  # (n_bands, n_samples)
        rest_frame_wavelength_A = np.array(f["rest_wave_A"])  # (n_wave,)
        rest_frame_fluxes_Lsol_A = np.array(
            f["rest_fluxes_Lsol_A"]
        )  # (n_wave, n_samples)

    if os.path.exists(tmp_in_path):
        os.remove(tmp_in_path)
    if os.path.exists(tmp_out_path):
        os.remove(tmp_out_path)

    rest_frame_fluxes_erg_s_A = rest_frame_fluxes_Lsol_A * SOLAR_LUMINOSITY_ERG_S
    lum_dist_cm = cosmology.background.dist_lum_a(1 / (1 + z)) * MPC_TO_CM
    obs_frame_wave_Ang = rest_frame_wavelength_A[np.newaxis, :] * (1 + z[:, np.newaxis])
    obs_frame_fluxes_erg_s_cm2_A = rest_frame_fluxes_erg_s_A / (
        4 * np.pi * (1 + z[:, np.newaxis]) * lum_dist_cm[:, np.newaxis] ** 2
    )

    if par.add_agn_component:
        quasar_fluxes_erg_s_cm2_A = compute_Temple21_AGN_contributions(
            par, rest_frame_fluxes_erg_s_A, rest_frame_wavelength_A, fagn, z
        )
        obs_frame_fluxes_erg_s_cm2_A = (
            obs_frame_fluxes_erg_s_cm2_A + quasar_fluxes_erg_s_cm2_A
        )

    extinction_spline = spline_ext_coeff()
    obs_frame_fluxes_erg_s_cm2_A = apply_extinction(
        obs_frame_fluxes_erg_s_cm2_A,
        obs_frame_wave_Ang,
        excess_b_v,
        extinction_spline,
    )
    obs_mags = compute_ab_magnitudes(
        par,
        obs_frame_wave_Ang,
        obs_frame_fluxes_erg_s_cm2_A[:, 0, :],
    )

    if par.save_SEDs & (par.sed_generator.lower() == "prospect"):
        return (
            rest_mags,
            obs_mags,
            rest_frame_wavelength_A,
            obs_frame_fluxes_erg_s_cm2_A[:, 0, :],
        )
    else:
        return rest_mags, obs_mags


def compute_ab_magnitudes(par, obs_frame_waves_A, obs_frame_fluxes_erg_s_cm2_A):
    """
    This function computes AB magnitudes by integrating galaxy observed- frame SEDs
    in units of erg/s/cm2/Å.

    :param par: (obj) par objects containing the Ucat parameters.
    :param obs_frame_waves_A: (array_like[n_gal, n_lambda]) observed- frame wavelengths
        array in Ångstrom.
    :param obs_frame_fluxes_erg_s_cm2_A: (array_like[n_gal, n_lambda]) observed-frame
        fluxes array in erg/s/cm2/Å.
    :return obs_mags: (array_like[n_gal, n_bands]) observed-frame AB magnitudes.
    """
    obs_mags = np.zeros((len(obs_frame_fluxes_erg_s_cm2_A), len(par.filters)))
    for j, key in enumerate(par.filters):
        with h5py.File(par.filters_file_name, "r") as h5:
            filter_wavelength = h5[par.filters_full_names[key]]["lam"][:]
            filter_transmission = h5[par.filters_full_names[key]]["amp"][:]
        f = interpolate.interp1d(
            filter_wavelength, filter_transmission, bounds_error=False, fill_value=0
        )
        for i in range(len(obs_frame_fluxes_erg_s_cm2_A)):
            filt_interp = f(obs_frame_waves_A[i])
            numerator = trapezoid(
                obs_frame_fluxes_erg_s_cm2_A[i]
                * filt_interp
                * obs_frame_waves_A[i]
                / LIGHTSPEED_ANGSTROM_S,
                x=obs_frame_waves_A[i],
            )
            denominator = trapezoid(
                filt_interp / obs_frame_waves_A[i], x=obs_frame_waves_A[i]
            )
            obs_mags[i, j] = -2.5 * np.log10(numerator / denominator) - 48.6

    return obs_mags


def get_magnitudes_with_emulator(
    par,
    z,
    mSFR,
    mpeak,
    mperiod,
    mskew,
    Zgas_final,
    logU,
    fagn,
    dust_attenuation_params,
    excess_b_v,
    dust_emission_params=None,
    vel_disp=None,
    ssp_library_filepath=None,
    filter_names=None,
    cosmology=None,
    log10_stellar_mass=None,
):
    """
    This function returns AB observed-frame and rest-frame magnitudes using the ProMage
    emulator trained on ProSpect outputs. Rest-frame magnitudes refer to the host galaxy
    only, without AGN contribution.

    :param par: (obj) par objects containing the Ucat parameters.
    :param z: (array_like[n_gal,]) galaxy redshift.
    :param mSFR: (array_like[n_gal,]) mSFR parameter for the
        massfunc_snorm_trunc function in ProSpect in Msun/yr.
    :param mpeak: (array_like[n_gal,]) mpeak parameter for the
        massfunc_snorm_trunc function in ProSpect in Gyr.
    :param mperiod: (array_like[n_gal,]) mperiod parameter for the
        massfunc_snorm_trunc function in ProSpect.
    :param mskew: (array_like[n_gal,]) mskew parameter for the
        massfunc_snorm_trunc function in ProSpect.
    :param Zgas_final: (array_like[n_gal,]) gas-phase metallicity at the time
        of observation.
    :param logU: (array_like[n_gal,]) gas ionisation parameter.
    :param fagn: (array_like[n_gal,]) fraction of AGN luminosity sampled from
        GalSBI-SPS.
    :param dust_attenuation_params: (array_like[n_gal,3]) dust attenuation
        parameters for the tau_birth and tau_screen parameters in ProSpect.
    :param excess_b_v: (array_like[n_gal,]) E(B-V) Milky Way extinction.
    :param dust_emission_params: (array_like[n_gal,2]) dust
        emission parameters for the alpha_SF_birth and alpha_SF_screen
        parameters in ProSpect.
    :param vel_disp: (array_like[n_gal,]) velocity dispersion in km/s. Not
        needed in this function, but used in ProSpect.
    :param ssp_library_filepath: (str) Filepath to the SSP library generated
        with ProGeny. Not needed in this function, but used in ProSpect.
    :param filter_names: (list) filter names recognized by ProSpect. Not
        needed in this function, but used in ProSpect.
    :param cosmology: (obj) PyCosmo cosmology object. Not needed in this
        function, but used in ProSpect.
    :param log10_stellar_mass: (array_like[n_gal,]) log10 stellar mass.
    :return rest_mags: (array_like[n_gal,n_bands]) emulated rest-frame AB
        magnitudes.
    :return obs_mags: (array_like[n_gal,n_bands]) emulated observed-frame AB
        magnitudes.
    """
    device = "cpu"
    emulator_model = torch.jit.load(par.ProMage_model_filepath)
    emulator_model.eval()
    property_scaler = joblib.load(par.ProMage_property_scaler_filepath)
    magnitude_scaler = joblib.load(par.ProMage_magnitude_scaler_filepath)

    X_prop = np.zeros((len(log10_stellar_mass), 12))
    X_prop[:, 0] = z
    X_prop[:, 1] = log10_stellar_mass
    X_prop[:, 2] = np.log10(mSFR)
    X_prop[:, 3] = mpeak
    X_prop[:, 4] = np.log10(mperiod)
    X_prop[:, 5] = mskew
    X_prop[:, 6] = np.log10(Zgas_final)
    X_prop[:, 7] = logU
    X_prop[:, 8] = dust_attenuation_params[:, 0]
    X_prop[:, 9] = dust_attenuation_params[:, 1]
    X_prop[:, 10] = np.log10(fagn)
    X_prop[:, 11] = excess_b_v

    X_prop_scaled = property_scaler.transform(X_prop)
    with torch.no_grad():
        emulated_magnitudes_scaled = emulator_model(
            torch.tensor(X_prop_scaled, dtype=torch.float32).to(device)
        )
        emulated_magnitudes_scaled = emulated_magnitudes_scaled.cpu().numpy()
    emulated_magnitudes = magnitude_scaler.inverse_transform(emulated_magnitudes_scaled)

    return emulated_magnitudes[:, len(filter_names) :], emulated_magnitudes[
        :, : len(filter_names)
    ]
