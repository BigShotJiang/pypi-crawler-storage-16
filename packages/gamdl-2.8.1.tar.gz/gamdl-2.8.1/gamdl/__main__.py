from gamdl.cli.cli import main

main()
