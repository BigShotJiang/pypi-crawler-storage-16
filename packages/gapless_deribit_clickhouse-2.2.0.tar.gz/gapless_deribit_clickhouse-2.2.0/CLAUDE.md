# gapless-deribit-clickhouse Project Memory

## Preferred Tools

| Category               | Tool                         | Avoid                         |
| ---------------------- | ---------------------------- | ----------------------------- |
| **Task runner**        | `mise tasks` (`.mise.toml`)  | Make, just, Taskfile, Earthly |
| **Python**             | `uv` (management, execution) | pip, conda, poetry            |
| **Version management** | `mise` for tool versions     | asdf, nvm, pyenv              |
| **Static analysis**    | Semgrep, Gitleaks            | ESLint (for Python)           |
| **Containers**         | Local-first (avoid)          | Docker Compose, Earthly       |
| **CI/CD**              | Local-first                  | GitHub Actions for tests      |

## Schema-First Architecture

**Pattern**: YAML schema is Single Source of Truth (SSoT) - following gapless-network-data.

### YAML Schema with Extensions

```yaml
# schema/clickhouse/*.yaml
$schema: "https://json-schema.org/draft/2020-12/schema"
properties:
  field_name:
    type: string
    x-clickhouse: # ClickHouse-specific metadata
      type: "DateTime64(3)"
      not_null: true
    x-pandas: # DataFrame type hints
      dtype: "datetime64[ns, UTC]"
```

### Schema Loader Pattern

```python
# Load YAML -> typed Schema object
from gapless_deribit_clickhouse.schema.loader import load_schema
schema = load_schema("options_trades")
# Access: schema.columns, schema.clickhouse, schema.required_columns
```

### Schema Validation (Introspector)

```bash
mise run schema-validate  # Compare YAML vs live ClickHouse
```

## Contract Tests (Architectural Invariants)

**Location**: `tests/contracts/`

**Purpose**: Validate structural consistency, NOT data behavior.

Key contract tests:

- `test_yaml_schema_exists()` - Schema file must exist
- `test_required_fields_not_nullable()` - Required fields = NOT NULL
- `test_parse_format_roundtrip()` - Instrument parsing invariant
- `test_api_function_exports()` - Public API contract
- `test_exception_exports()` - Exception hierarchy contract

**Rule**: Contract tests are deletion-proof. They validate architecture, not features.

## Credentials

**Pattern**: `.env` + 1Password (never commit secrets)

**1Password Item**: `gapless-deribit-clickhouse` (Engineering vault)

```bash
# Retrieve credentials
op item get "gapless-deribit-clickhouse" --vault Engineering --reveal
```

**Connection Details**:

| Setting  | Value                                       |
| -------- | ------------------------------------------- |
| Host     | `ebmf8f35lu.us-west-2.aws.clickhouse.cloud` |
| Port     | `443` (not 8443 - network compatibility)    |
| User     | `default`                                   |
| Database | `deribit`                                   |
| Table    | `options_trades`                            |
| Secure   | `true` (HTTPS)                              |

**Environment Variables** (`.env`):

```bash
CLICKHOUSE_HOST_READONLY=ebmf8f35lu.us-west-2.aws.clickhouse.cloud
CLICKHOUSE_USER_READONLY=default
CLICKHOUSE_PASSWORD_READONLY=<from 1Password>
```

**Avoid**: Doppler for this project (simplified to .env)

## mise Tasks

```toml
# .mise.toml
[tasks.test-unit]      # No credentials needed
[tasks.test-contracts] # Schema + API contracts
[tasks.test-e2e]       # Real Deribit API
[tasks.schema-validate] # YAML vs live ClickHouse
[tasks.lint]           # ruff check
[tasks.security]       # semgrep + gitleaks
```

## ITP Workflow Integration

For significant changes, use the `/itp:itp` slash command:

```
/itp:itp [name] [-b branch] [-r release] [-p pypi]
```

**Phases**:

1. **Preflight**: ADR + design spec creation
2. **Phase 1**: Implementation (uses TodoWrite checklist)
3. **Phase 2**: Push to GitHub, format markdown
4. **Phase 3**: Release (if -r flag)

**Key files created by ITP**:

- `docs/adr/YYYY-MM-DD-slug.md` - ADR with MADR 4.0 frontmatter
- `docs/design/YYYY-MM-DD-slug/spec.md` - Design spec with tasks

## DBeaver Configuration

**ADR**: [Pydantic-Based DBeaver Config](/docs/adr/2025-12-09-pydantic-dbeaver-config.md)

**Pattern**: Pydantic SSoT → Generator → DBeaver JSON

### Quick Start

```bash
# Generate DBeaver config (reads .env for cloud credentials)
mise run dbeaver-generate

# Launch DBeaver with project connections
mise run dbeaver

# Print connection settings for any GUI tool
mise run db-connect-info
```

### Connection Settings

| Mode  | Host                                        | Port | Database | User    | SSL |
| ----- | ------------------------------------------- | ---- | -------- | ------- | --- |
| Local | `localhost`                                 | 8123 | deribit  | default | No  |
| Cloud | `ebmf8f35lu.us-west-2.aws.clickhouse.cloud` | 443  | deribit  | default | Yes |

### Files

| File                                 | Purpose                | Git Status  |
| ------------------------------------ | ---------------------- | ----------- |
| `src/.../config/connections.py`      | Pydantic models (SSoT) | Committed   |
| `scripts/generate_dbeaver_config.py` | Generator script       | Committed   |
| `.dbeaver/data-sources.json`         | Generated config       | **Ignored** |
| `.dbeaver/data-sources.schema.json`  | JSON Schema for IDE    | Committed   |

### Modifying Connections

1. Edit `src/gapless_deribit_clickhouse/config/connections.py`
2. Run `mise run dbeaver-generate`
3. Launch DBeaver to verify

## References

- **ADR**: [ClickHouse Naming Convention](/docs/adr/2025-12-08-clickhouse-naming-convention.md)
- **ADR**: [Pydantic-Based DBeaver Config](/docs/adr/2025-12-09-pydantic-dbeaver-config.md)
- **Pattern source**: gapless-network-data schema loader
- **Contract tests pattern**: alpha-forge
