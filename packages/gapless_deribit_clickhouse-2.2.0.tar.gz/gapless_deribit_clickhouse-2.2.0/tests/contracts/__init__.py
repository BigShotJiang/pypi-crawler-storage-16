# ADR: 2025-12-07-schema-first-e2e-validation
