"""
E2E test fixtures.

Note: Core fixtures (skip_without_credentials, skip_without_deribit)
are now in tests/conftest.py for broader availability.

ADR: 2025-12-07-schema-first-e2e-validation
"""

# E2E-specific fixtures can be added here as needed.
# Common fixtures are inherited from tests/conftest.py.
