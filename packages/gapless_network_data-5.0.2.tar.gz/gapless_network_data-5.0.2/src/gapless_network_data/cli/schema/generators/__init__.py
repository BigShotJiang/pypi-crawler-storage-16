"""Schema generators for code, DDL, and documentation."""
