"""Schema CLI commands for gapless-network-data."""

from gapless_network_data.cli.schema.commands import schema_command

__all__ = ["schema_command"]
