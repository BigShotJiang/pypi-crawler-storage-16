# AUTO-GENERATED - DO NOT EDIT
# This package contains generated types from schema/clickhouse/*.yaml
# Regenerate with: uv run gapless-network-data schema generate-types
