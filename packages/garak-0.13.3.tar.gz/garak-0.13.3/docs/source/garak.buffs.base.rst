garak.buffs.base
================

.. automodule:: garak.buffs.base
   :members:
   :undoc-members:
   :show-inheritance:
