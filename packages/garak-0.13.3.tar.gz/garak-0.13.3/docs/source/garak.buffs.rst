garak.buffs
===========



.. automodule:: garak.buffs
   :members:
   :undoc-members:
   :show-inheritance:
