garak.detectors.continuation
============================

.. automodule:: garak.detectors.continuation
   :members:
   :undoc-members:
   :show-inheritance:
