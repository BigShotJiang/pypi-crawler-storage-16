garak.detectors.perspective
===========================

.. automodule:: garak.detectors.perspective
   :members:
   :undoc-members:
   :show-inheritance:
