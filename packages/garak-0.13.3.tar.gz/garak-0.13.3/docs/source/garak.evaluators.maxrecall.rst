garak.evaluators.maxrecall
==========================

.. automodule:: garak.evaluators.maxrecall
   :members:
   :undoc-members:
   :show-inheritance:
