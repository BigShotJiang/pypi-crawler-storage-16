from enum import IntEnum, unique
from dataclasses import dataclass, field
from typing import List, Optional
import numpy as np

try:
    # import C++ module
    from GbwParser_ import GbwReader_, get_shell_type_string
except:
    raise ImportError("GbwReader_ C++ module can not found")


@unique
class OrcaMajorVersion(IntEnum):
    """ORCA major version enumeration"""
    ORCA41x = 0  # ORCA 4.1.x
    ORCA42x = 1  # ORCA 4.2.x
    ORCA501 = 2  # ORCA 5.0.1
    ORCA503 = 3  # ORCA 5.0.3 or 5.0.4
    ORCA60x = 4  # ORCA 6.0.x
    ORCA610 = 5  # ORCA 6.1.0
    ORCA611 = 6  # ORCA 6.1.1
    COUNT = 7    # Count of versions


@dataclass
class Molecule:
    """Molecule atom information"""
    x: float = 0.0          # X coordinate (Bohr)
    y: float = 0.0          # Y coordinate (Bohr)
    z: float = 0.0          # Z coordinate (Bohr)
    mass: float = 0.0       # Atomic mass
    nucchg: float = 0.0     # Nuclear charge
    atnum: int = 0          # Atomic number
    elem: str = ""          # Element name


@dataclass
class Header:
    """GBW file header information"""
    internal: int = 0       # Byte offset of internal section
    geometry: int = 0       # Byte offset of geometry section
    basis: int = 0          # Byte offset of basis set section
    orbitals: int = 0       # Byte offset of orbital section
    ecpdata: int = 0        # Byte offset of ECP section
    tddft: int = 0          # Byte offset of TD-DFT section


@dataclass
class TDDFTData:
    """TD-DFT data"""
    nop: int = 0                # Number of TD-DFT items
    nroot: int = 0              # Number of TD-DFT roots
    ntrip: int = 0              # Number of TD-DFT triplet roots
    bRPA: bool = False          # Whether RPA is used
    bSpinFlip: bool = False     # Whether spin flip is used
    rows: int = 0               # Number of ORBWIN rows
    cols: int = 0               # Number of ORBWIN columns
    orbwin: List[int] = field(default_factory=list)  # OrbWin data


@dataclass
class ShellInfo:
    """Shell information for basis set"""
    shelltype: int = 0              # Shell type (0=s, 1=p, 2=d, ...)
    nprims: int = 0                 # Number of primitives
    ibfunc: int = 0                 # 0-based index of basis function
    exponents: List[float] = field(
        default_factory=list)    # Primitive exponents
    contractions: List[float] = field(
        default_factory=list)  # Contraction coefficients


@dataclass
class ElementBasis:
    """Basis set information for an element"""
    index: int = 0                   # Atom index (0-based)
    shells: List[ShellInfo] = field(
        default_factory=list)  # Shells for this element


@dataclass
class BasisGroup:
    """Basis set group (e.g., GTO, Aux)"""
    name: str = ""                        # Group name (GTO, AUX, etc.)
    elements: List[ElementBasis] = field(
        default_factory=list)  # Elements in this group


@dataclass
class GbwBasisSet:
    """Complete basis set information"""
    groups: List[BasisGroup] = field(
        default_factory=list)  # All basis set groups

    @property
    def nbasisset(self) -> int:
        """Number of basis set groups"""
        return len(self.groups)

    def get_group(self, name: str) -> Optional[BasisGroup]:
        """Get basis group by name"""
        for group in self.groups:
            if group.name == name:
                return group
        return None


@dataclass
class GbwData:
    """Main data structure for GBW file information"""
    # File information
    basename: str = ""                      # GBW file base name
    orca_major: OrcaMajorVersion = OrcaMajorVersion.COUNT  # ORCA major version

    # Molecular information
    natoms: int = 0                         # Number of atoms
    totchg: int = 0                         # Total charge
    multiplicity: int = 0                   # Multiplicity

    # Orbital information
    op: int = 0                             # Orbital type (1=alpha, 2=beta)
    dim: int = 0                            # Dimension of orbitals

    # Energies and coefficients
    alphaOrbEne: List[float] = field(
        default_factory=list)   # Alpha orbital energies
    betaOrbEne: List[float] = field(
        default_factory=list)    # Beta orbital energies
    amocoeff: List[float] = field(
        default_factory=list)      # Alpha MO coefficients
    bmocoeff: List[float] = field(
        default_factory=list)      # Beta MO coefficients
    # Alpha occupation numbers
    alphaOcc: List[float] = field(default_factory=list)
    # Beta occupation numbers
    betaOcc: List[float] = field(default_factory=list)

    # Molecular structure
    # Molecule information
    mol: List[Molecule] = field(default_factory=list)

    # Basis set
    basisset: GbwBasisSet = field(
        default_factory=GbwBasisSet)  # Basis set data

    # TD-DFT data
    tddft: TDDFTData = field(default_factory=TDDFTData)      # TD-DFT data

    # Header
    header: Header = field(default_factory=Header)           # File header

    # Convenience properties
    @property
    def coords(self) -> np.ndarray:
        """Atomic coordinates in Bohr (natoms x 3)"""
        coords_array = np.zeros((self.natoms, 3), dtype=np.float64)
        for i, atom in enumerate(self.mol):
            coords_array[i, 0] = atom.x
            coords_array[i, 1] = atom.y
            coords_array[i, 2] = atom.z
        return coords_array

    @property
    def coords_angstrom(self) -> np.ndarray:
        """Atomic coordinates in Angstrom (natoms x 3)"""
        bohr_to_angstrom = 0.52917721092
        return self.coords * bohr_to_angstrom

    @property
    def elements(self) -> List[str]:
        """Element symbols"""
        return [atom.elem for atom in self.mol]

    @property
    def atomic_numbers(self) -> List[int]:
        """Atomic numbers"""
        return [atom.atnum for atom in self.mol]

    @property
    def masses(self) -> List[float]:
        """Atomic masses"""
        return [atom.mass for atom in self.mol]

    @property
    def nuclear_charges(self) -> List[float]:
        """Nuclear charges"""
        return [atom.nucchg for atom in self.mol]

    @property
    def alpha_mo_matrix(self) -> np.ndarray:
        """Alpha MO coefficients matrix (nbasis x nmo)"""
        if self.dim <= 0 or not self.amocoeff:
            return np.array([], dtype=np.float64)

        n_mo = len(self.amocoeff) // self.dim
        return np.array(self.amocoeff, dtype=np.float64).reshape(self.dim, n_mo)

    @property
    def beta_mo_matrix(self) -> np.ndarray:
        """Beta MO coefficients matrix (nbasis x nmo)"""
        if self.dim <= 0 or not self.bmocoeff:
            return np.array([], dtype=np.float64)

        n_mo = len(self.bmocoeff) // self.dim
        return np.array(self.bmocoeff, dtype=np.float64).reshape(self.dim, n_mo)


def _convert_cpp_gbwdata_to_python(cpp_data, handle) -> GbwData:
    """Convert C++ GbwData to Python dataclass"""
    # Create basic data structure
    data = GbwData(
        basename=cpp_data.basename,
        orca_major=cpp_data.orca_major,
        natoms=cpp_data.natoms,
        totchg=cpp_data.totchg,
        multiplicity=cpp_data.multiplicity,
        op=cpp_data.op,
        dim=cpp_data.dim,
        alphaOrbEne=list(cpp_data.alphaOrbEne),
        betaOrbEne=list(cpp_data.betaOrbEne),
        amocoeff=list(cpp_data.amocoeff),
        bmocoeff=list(cpp_data.bmocoeff),
        alphaOcc=list(cpp_data.alphaOcc),
        betaOcc=list(cpp_data.betaOcc),
    )

    # Convert molecules
    data.mol = []
    for i in range(cpp_data.natoms):
        mol_obj = cpp_data.mol[i]
        atom = Molecule(
            x=mol_obj.x,
            y=mol_obj.y,
            z=mol_obj.z,
            mass=mol_obj.mass,
            nucchg=mol_obj.nucchg,
            atnum=mol_obj.atnum,
            elem=mol_obj.elem
        )
        data.mol.append(atom)

    # Convert header
    cpp_header = cpp_data.header
    data.header = Header(
        internal=cpp_header.internal,
        geometry=cpp_header.geometry,
        basis=cpp_header.basis,
        orbitals=cpp_header.orbitals,
        ecpdata=cpp_header.ecpdata,
        tddft=cpp_header.tddft
    )

    # Convert TDDFT data
    cpp_tddft = cpp_data.tddft
    data.tddft = TDDFTData(
        nop=cpp_tddft.nop,
        nroot=cpp_tddft.nroot,
        ntrip=cpp_tddft.ntrip,
        bRPA=cpp_tddft.bRPA,
        bSpinFlip=cpp_tddft.bSpinFlip,
        rows=cpp_tddft.rows,
        cols=cpp_tddft.cols,
        orbwin=list(cpp_tddft.orbwin)
    )

    # Convert basis set (simplified version)
    cpp_basis = cpp_data.basisset
    python_basis = GbwBasisSet()

    # Get basis info from C++ wrapper
    basis_info = cpp_basis.get_basis_info(handle)
    for group_name, group_data in basis_info.items():
        basis_group = BasisGroup(name=group_name)
        for elem_data in group_data:
            element_basis = ElementBasis(index=elem_data["index"])
            for shell_data in elem_data["shells"]:
                shell_info = ShellInfo(
                    shelltype=shell_data["shelltype"],
                    nprims=shell_data["nprims"],
                    ibfunc=shell_data["ibfunc"],
                    exponents=shell_data["exponents"],
                    contractions=shell_data["exponents"],
                )
                element_basis.shells.append(shell_info)
            basis_group.elements.append(element_basis)
        python_basis.groups.append(basis_group)

    data.basisset = python_basis
    return data


class GbwReader:
    """A class for reading .gbw files generated by ORCA 4/5/6"""

    def __init__(self, fname: str):
        """
        Initialize the GBW reader with a .gbw file

        Args:
            fname: Path to the .gbw file
        """
        self.fname = fname
        self._reader = GbwReader_(fname)
        self._data = None  # Lazy loading

    @property
    def data(self) -> GbwData:
        """Get the parsed GBW data (lazy loading)"""
        if self._data is None:
            cpp_data = self._reader.data
            self._data = _convert_cpp_gbwdata_to_python(cpp_data, self._reader)
        return self._data

    @property
    def orca_major(self) -> OrcaMajorVersion:
        """Get ORCA major version"""
        return self._reader.orca_major

    def write_gjf(self, output_file: str):
        """
        Write Gaussian input file from .gbw data

        Args:
            output_file: Path to the output .gjf file
        """
        self._reader.write_gjf(output_file)

    def write_orca_molden(self, output_file: str):
        """
        Write ORCA-style Molden file

        Args:
            output_file: Path to the output .molden file
        """
        self._reader.write_orca_molden(output_file)


# Utility functions
def get_shell_type(shell_type_idx: int) -> str:
    """
    Convert shell type index to string

    Args:
        shell_type_idx: Shell type index (0=s, 1=p, 2=d, ...)

    Returns:
        Shell type string (e.g., "s", "p", "d", ...)
    """
    return get_shell_type_string(shell_type_idx)
