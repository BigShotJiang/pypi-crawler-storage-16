from .GbwReader import GbwReader

# always keep the value is same as setup.py
__version__ = "0.1.0"
