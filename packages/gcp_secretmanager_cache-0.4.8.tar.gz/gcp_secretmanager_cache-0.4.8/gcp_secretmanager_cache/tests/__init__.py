# -*- coding: utf-8 -*-
"""
This modules purpose is to test gcp-secretmanager-cache
"""
