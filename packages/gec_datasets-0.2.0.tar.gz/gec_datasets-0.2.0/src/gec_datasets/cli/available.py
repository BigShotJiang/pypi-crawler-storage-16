import gec_datasets
import argparse

def main():
    print(gec_datasets.available())

def cli_main():
    main()

if __name__ == '__main__':
    main()