"""Module to clean and process GECI data"""

__version__ = "0.15.0"
from .cli import *  # noqa
