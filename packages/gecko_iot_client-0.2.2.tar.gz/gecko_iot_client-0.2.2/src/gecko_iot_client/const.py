# API endpoints
API_BASE_URL = "https://api.geckowatermonitor.com"
AUTH0_BASE_URL = "https://gecko-prod.us.auth0.com"