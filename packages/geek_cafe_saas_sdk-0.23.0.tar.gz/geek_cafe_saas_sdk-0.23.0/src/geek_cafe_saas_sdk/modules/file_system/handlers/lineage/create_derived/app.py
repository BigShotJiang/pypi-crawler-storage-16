"""
Lambda handler for creating a derived file from a main file.

Requires authentication (secure mode).
"""

from typing import Dict, Any
from geek_cafe_saas_sdk.lambda_handlers import create_handler, LambdaEvent
from geek_cafe_saas_sdk.core.service_result import ServiceResult
from geek_cafe_saas_sdk.modules.file_system.services import FileSystemService
import base64


# Factory creates handler (defaults to secure auth)
handler_wrapper = create_handler(
    service_class=FileSystemService,
    require_body=True,
    convert_request_case=True
)


def lambda_handler(event: Dict[str, Any], context: Any, injected_service=None) -> Dict[str, Any]:
    """
    Create a derived file from a main file (e.g., data cleaning).
    
    Args:
        event: Lambda event from API Gateway
        context: Lambda context
        injected_service: Optional FileSystemService for testing
    
    Expected body (camelCase from frontend):
    {
        "mainFileId": "file-456",  # Main file ID
        "fileName": "data_clean_v1.csv",
        "fileData": "base64_encoded_content",
        "transformationOperation": "data_cleaning_v1",
        "transformationMetadata": {
            "cleaning_version": 1,
            "operations": ["remove_nulls", "normalize_units"],
            "rows_processed": 1000
        },
        "directoryId": "dir-789"  # Optional
    }
    
    Returns 201 with created derived file
    """
    return handler_wrapper.execute(event, context, create, injected_service)


def create(event: LambdaEvent, service: FileSystemService) -> ServiceResult:
    """
    Business logic for creating derived file.
    """
    payload = event.body()
    
    # Extract parent file ID from path parameters (parent-id)
    parent_id = event.path("parent-id", "parent_id", "parent_id", "mainFileId")
    if not parent_id:
        raise ValueError("parent file ID is required in path (parent-id)")
    
    # Extract required fields from body
    file_name = payload.get("file_name")
    file_data_b64 = payload.get("file_data")
    transformation_operation = payload.get("transformation_operation")
    if not file_name:
        raise ValueError("file_name is required")
    if not file_data_b64:
        raise ValueError("file_data is required")
    if not transformation_operation:
        raise ValueError("transformation_operation is required")
    
    # Decode base64 file data
    try:
        file_data = base64.b64decode(file_data_b64)
    except Exception as e:
        raise ValueError(f"Invalid base64 file_data: {str(e)}")
    
    # Extract optional fields
    transformation_type = payload.get("transformation_type")
    transformation_metadata = payload.get("transformation_metadata", {})
    directory_id = payload.get("directory_id")
    
    # Create derived file
    # Note: tenant_id and user_id come from service's request_context
    result = service.create(
        parent_id=parent_id,
        name=file_name,
        data=file_data,
        transformation_operation=transformation_operation,
        transformation_type=transformation_type,
        transformation_metadata=transformation_metadata,
        directory_id=directory_id
    )
    
    return result
