"""Test suite for gemini-photo-edit MCP server."""
