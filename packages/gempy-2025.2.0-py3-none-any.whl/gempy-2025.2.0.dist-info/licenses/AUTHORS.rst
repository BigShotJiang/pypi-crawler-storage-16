.. _authors_ref:

Authors
-------

.. image:: https://img.shields.io/github/contributors/gempy-project/gempy_engine.svg?logo=github&logoColor=white
   :target: https://github.com/gempy-projects/gempy_engine/graphs/contributors/


The following is a list of authors who have made substantial contributions to
the conception or design of this software; or the creation of new code used in
this software; or have drafted the work or substantively revised it:

- Miguel de la Varga, (`@leguark <https://github.com/leguark/>`_)
- Alexander Zimmerman
- Elisa Heim
- Alexander Schaaf
- Fabian Stamm
- Florian Wellmann
