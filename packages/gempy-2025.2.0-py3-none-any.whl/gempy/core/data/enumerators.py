﻿from enum import Enum, auto


class ExampleModel(Enum):
    TWO_AND_A_HALF_D = auto()
    HORIZONTAL_STRAT = auto()
    ANTICLINE = auto()
    ONE_FAULT = auto()
    COMBINATION = auto()
    ONE_FAULT_GRAVITY = auto()
    GRABEN = auto()
