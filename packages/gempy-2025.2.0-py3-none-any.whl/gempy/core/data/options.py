import enum
class InterpolationOptionsType(enum.Enum):
    
    DENSE_GRID = enum.auto()
    OCTREE = enum.auto()
