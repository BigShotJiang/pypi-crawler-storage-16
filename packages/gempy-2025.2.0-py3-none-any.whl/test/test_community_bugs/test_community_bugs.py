"""
This scrip is to add test for specific issues that the community has found. Use the the following template:

def test_issue_XXX():
    ...

"""
