def test_installation():
    import gempy
    import gempy_engine