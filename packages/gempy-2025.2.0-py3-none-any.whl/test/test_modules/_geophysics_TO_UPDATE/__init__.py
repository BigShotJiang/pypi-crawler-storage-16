import pytest

pytestmark = pytest.mark.skip(reason="Geophysics module is not yet updated")