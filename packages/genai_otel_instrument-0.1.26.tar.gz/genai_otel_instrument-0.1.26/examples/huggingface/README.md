# HuggingFace Transformers Example
```bash
pip install genai-otel-instrument[huggingface]
cp .env.example .env
python example.py
```
