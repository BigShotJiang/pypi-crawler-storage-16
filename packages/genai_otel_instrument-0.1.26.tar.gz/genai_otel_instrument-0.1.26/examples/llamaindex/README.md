# LlamaIndex Example
```bash
pip install genai-otel-instrument[llamaindex,openai]
mkdir data && echo "Sample document" > data/sample.txt
cp .env.example .env
python example.py
```
