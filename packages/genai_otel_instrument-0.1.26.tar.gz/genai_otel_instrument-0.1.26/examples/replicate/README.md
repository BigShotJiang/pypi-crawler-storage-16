# Replicate Example
```bash
pip install genai-otel-instrument[replicate]
cp .env.example .env
python example.py
```
