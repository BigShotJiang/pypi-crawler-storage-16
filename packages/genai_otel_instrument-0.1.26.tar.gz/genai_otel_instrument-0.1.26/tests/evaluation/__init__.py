"""Tests for evaluation and safety features."""
