__version__ = '0.6.0'
version = __version__

__all__ = [
    'version'
]
