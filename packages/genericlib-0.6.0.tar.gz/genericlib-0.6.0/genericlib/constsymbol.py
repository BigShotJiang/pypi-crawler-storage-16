
class SYMBOL:
    PIPE = '|'
    VERTICAL_LINE = '|'

    FORWARD_SLASH = '/'
    BACK_SLASH = '\\'

    SPACE = ' '

    PLUS = '+'
    ASTERISK = '*'
    STAR = '*'
    MULTIPLY = '*'
    COMMA = ','

    CARET = '^'

    DOLLAR_SIGN = '$'

    QUESTION_MARK = '?'

    LEFT_PARENTHESIS = '('
    RIGHT_PARENTHESIS = ')'
    LEFT_ROUND_BRACKET = '('
    RIGHT_ROUND_BRACKET = ')'

    LEFT_CURLY_BRACKET = '{'
    RIGHT_CURLY_BRACKET = '}'

    LEFT_SQUARE_BRACKET = '['
    RIGHT_SQUARE_BRACKET = ']'

    LEFT_ANGLE_BRACKET = '<'
    RIGHT_ANGLE_BRACKET = '>'
