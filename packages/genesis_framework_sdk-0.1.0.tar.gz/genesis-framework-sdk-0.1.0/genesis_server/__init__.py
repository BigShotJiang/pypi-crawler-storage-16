"""
Genesis Server - RAG Backend for the Genesis Framework
"""