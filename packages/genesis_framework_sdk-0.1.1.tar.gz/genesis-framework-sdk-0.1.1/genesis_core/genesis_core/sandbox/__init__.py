"""
Sandbox module for the Genesis Core framework.

This package provides isolated execution environments for agents using Docker.
"""