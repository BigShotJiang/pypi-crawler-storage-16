from genie import abstract
abstract.declare_token(submodel='c9800_cl')
