from genie import abstract
abstract.declare_token(model='ie3100')
