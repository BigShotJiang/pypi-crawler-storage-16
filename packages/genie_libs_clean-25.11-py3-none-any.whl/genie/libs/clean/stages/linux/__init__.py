# Enable abstraction using this directory name as the abstraction token
from genie import abstract
abstract.declare_token(os='linux')