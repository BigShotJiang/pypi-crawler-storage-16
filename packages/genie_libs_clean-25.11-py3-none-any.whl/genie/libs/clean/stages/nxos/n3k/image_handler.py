'''NXOS N3K: Image Handler Class'''

# Genie
from genie.libs.clean.stages.nxos.n9k.image_handler import ImageHandler as N9KImageHandler

class ImageHandler(N9KImageHandler):
    pass