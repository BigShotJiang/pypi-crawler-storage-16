from genie import abstract
abstract.declare_token(pid='C9500X-28C8D')