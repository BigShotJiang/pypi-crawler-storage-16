""" File utils base class for IOS devices. """

# Parent inheritance
from ..iosxe import FileUtils as FileUtilsXEDevice

class FileUtils(FileUtilsXEDevice):
    pass
