""" File utils base class for HTTPS on IOS devices. """

from ...iosxe.https.fileutils import FileUtils as FileUtilsXEBase

class FileUtils(FileUtilsXEBase):
    pass
