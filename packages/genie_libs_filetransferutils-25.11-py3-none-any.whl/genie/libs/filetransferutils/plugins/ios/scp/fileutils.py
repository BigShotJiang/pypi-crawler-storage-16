""" File utils base class for SCP on IOS devices. """

from ...iosxe.scp.fileutils import FileUtils as FileUtilsXEBase

class FileUtils(FileUtilsXEBase):
    pass
