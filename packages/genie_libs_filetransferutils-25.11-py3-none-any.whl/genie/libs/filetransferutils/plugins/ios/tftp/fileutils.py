""" File utils base class for TFTP on IOS devices. """

from ...iosxe.tftp.fileutils import FileUtils as FileUtilsXEBase

class FileUtils(FileUtilsXEBase):
	pass
