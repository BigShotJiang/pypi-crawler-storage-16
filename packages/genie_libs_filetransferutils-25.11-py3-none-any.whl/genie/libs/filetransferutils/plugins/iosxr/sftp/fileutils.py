""" File utils base class for sftp on IOSXR devices. """

from ..fileutils import FileUtils as FileUtilsXRBase

class FileUtils(FileUtilsXRBase):
	pass