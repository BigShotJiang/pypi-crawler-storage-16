""" File utils base class for FTP on JunOS devices. """

from ..fileutils import FileUtils as FileUtilsJunOSBase

class FileUtils(FileUtilsJunOSBase):
	pass