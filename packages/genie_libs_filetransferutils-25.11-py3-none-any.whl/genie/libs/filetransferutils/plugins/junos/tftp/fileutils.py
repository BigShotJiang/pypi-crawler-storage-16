""" File utils base class for TFTP on JunOS devices. """

from ..fileutils import FileUtils as FileUtilsJunOSBase

class FileUtils(FileUtilsJunOSBase):
	pass