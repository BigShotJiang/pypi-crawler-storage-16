'''
ACL Genie Ops Object for IOS - CLI.
'''
from ..iosxe.acl import Acl as AclXE

class Acl(AclXE):
    pass