from genie.ops.base import Base

class Dot1X(Base):
    exclude = []