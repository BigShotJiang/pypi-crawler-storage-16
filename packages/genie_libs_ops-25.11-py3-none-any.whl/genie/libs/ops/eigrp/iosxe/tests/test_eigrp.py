
# Python
import unittest
from unittest.mock import Mock

# ATS
from pyats.topology import Device

# Genie
from genie.libs.ops.eigrp.iosxe.eigrp import Eigrp
from genie.libs.ops.eigrp.iosxe.tests.eigrp_output import EigrpOutput

# iosxe show_eigrp
from genie.libs.parser.iosxe.show_eigrp import ShowIpEigrpNeighborsDetail,\
                                               ShowIpv6EigrpNeighborsDetail

outputs = {}
outputs['show ip eigrp neighbors detail'] = EigrpOutput.ShowIpEigrpNeighborsDetail
outputs['show ipv6 eigrp neighbors detail'] = EigrpOutput.ShowIpv6EigrpNeighborsDetail

def mapper(key, **kwargs):
    return outputs[key]

class test_eigrp(unittest.TestCase):

    def setUp(self):
        self.device = Device(name='aDevice')
        self.device.os = 'iosxe'
        self.device.mapping = {}
        self.device.mapping['cli'] = 'cli'
        # Create a mock connection to get output for parsing
        self.device_connection = Mock(device=self.device)
        self.device.connectionmgr.connections['cli'] = self.device_connection
        # Set outputs
        self.device_connection.execute.side_effect = mapper

    def test_complete_output(self):
        self.maxDiff = None
        eigrp = Eigrp(device=self.device)

        # Set outputs
        eigrp.maker.outputs[ShowIpEigrpNeighborsDetail] = {'': EigrpOutput.ShowIpEigrpNeighborsDetail}
        eigrp.maker.outputs[ShowIpv6EigrpNeighborsDetail] = {'': EigrpOutput.ShowIpv6EigrpNeighborsDetail}

        # Return outputs above as inputs to parser when called


        # Learn the feature
        eigrp.learn()

        # Verify Ops was created successfully
        self.assertEqual(eigrp.info, EigrpOutput.EigrpInfo)

    def test_selective_attribute(self):
        self.maxDiff = None
        eigrp = Eigrp(device=self.device)

        # Set outputs
        eigrp.maker.outputs[ShowIpEigrpNeighborsDetail] = {'': EigrpOutput.ShowIpEigrpNeighborsDetail}
        eigrp.maker.outputs[ShowIpv6EigrpNeighborsDetail] = {'': EigrpOutput.ShowIpv6EigrpNeighborsDetail}

        # Return outputd above as inputs to parser when called


        # Learn the feature
        eigrp.learn()

        self.assertEqual(5, eigrp.info['eigrp_instance']['100']['vrf']\
                                      ['default']['address_family']['ipv4']\
                                      ['eigrp_interface']['Ethernet1/0']\
                                      ['eigrp_nbr']['10.1.2.1']\
                                      ['nbr_sw_ver']['os_majorver'])

    def test_empty_output(self):
        self.maxDiff = None
        eigrp = Eigrp(device=self.device)

        # Set outputs
        eigrp.maker.outputs[ShowIpEigrpNeighborsDetail] = {'': {}}
        eigrp.maker.outputs[ShowIpv6EigrpNeighborsDetail] = {'': {}}

        # Return outputs above as inputs to parser when called


        # Learn the feature
        eigrp.learn()

        # Verify attribute is missing
        with self.assertRaises(AttributeError):
            eigrp.info['eigrp_instance']

    def test_missing_attributes(self):
        self.maxDiff = None
        eigrp = Eigrp(device=self.device)

        # Set outputs
        eigrp.maker.outputs[ShowIpEigrpNeighborsDetail] = {'': EigrpOutput.ShowIpEigrpNeighborsDetail}
        eigrp.maker.outputs[ShowIpv6EigrpNeighborsDetail] = {'': {}}

        # Return outputs above as inputs to parser when called


        # Learn the feature
        eigrp.learn()

        # Veritfy key not created to do output missing

        with self.assertRaises(KeyError):
            single_value_preference = eigrp.info['eigrp_instance']['vrf']\
                ['address_family']['eigrp_interface']\
                ['eigrp_nbr']['nbr_sw_ver']


if __name__ == '__main__':
    unittest.main()
