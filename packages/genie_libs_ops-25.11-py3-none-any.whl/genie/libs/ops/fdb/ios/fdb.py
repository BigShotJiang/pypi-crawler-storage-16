'''
FDB Genie Ops Object for IOS - CLI.
'''
from ..iosxe.fdb import Fdb as FdbXE

class Fdb(FdbXE):
    pass