# Genie
from genie.ops.base import Base

class Hsrp(Base):
    exclude = []