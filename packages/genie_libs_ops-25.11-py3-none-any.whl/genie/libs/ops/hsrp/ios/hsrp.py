""" 
HSRP Genie Ops Object for IOS.
"""
from genie.libs.ops.hsrp.iosxe.hsrp import Hsrp as HsrpXE

class Hsrp(HsrpXE):    
    pass