from genie import abstract
abstract.declare_token(platform='cat3k')
