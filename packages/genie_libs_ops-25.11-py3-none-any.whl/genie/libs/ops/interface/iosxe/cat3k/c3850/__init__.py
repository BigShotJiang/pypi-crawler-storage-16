from genie import abstract
abstract.declare_token(model='c3850')
