from genie import abstract
abstract.declare_token(revision='1')