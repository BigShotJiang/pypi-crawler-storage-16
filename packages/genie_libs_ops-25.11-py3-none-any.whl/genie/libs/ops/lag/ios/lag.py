'''
Lag Genie Ops Object for IOS - CLI.
'''
from ..iosxe.lag import Lag as LagXE

class Lag(LagXE):
    pass