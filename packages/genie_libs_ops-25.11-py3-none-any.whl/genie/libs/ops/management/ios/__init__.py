from genie import abstract
abstract.declare_token(os='ios')