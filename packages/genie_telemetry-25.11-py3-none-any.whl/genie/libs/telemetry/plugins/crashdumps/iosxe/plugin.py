''' 
GenieTelemetry Crashdumps Plugin for IOSXE
'''
from ..plugin import Plugin as BasePlugin


class Plugin(BasePlugin):
    pass