''' 
GenieTelemetry Crashdumps Plugin for NXOS
'''

# GenieTelemetry
from ..plugin import Plugin as BasePlugin


class Plugin(BasePlugin):

    pass
