"""GenifAI CLI - AI-powered HTTP test case generator"""

__version__ = "0.1.0"