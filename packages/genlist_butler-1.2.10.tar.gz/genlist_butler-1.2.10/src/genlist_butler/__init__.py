"""GenList Butler - HTML music catalog generator"""

__version__ = "1.2.10"
