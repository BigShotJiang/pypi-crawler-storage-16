import altair as alt
import pandas as pd
from flask import Blueprint
from flask import render_template
from flask.typing import ResponseReturnValue
from flask_babel import gettext as _

from ...core.activities import ActivityRepository
from ...core.config import Config
from ...core.summary_stats import get_equipment_use_table
from ..plot_util import make_kind_scale


def make_equipment_blueprint(
    repository: ActivityRepository, config: Config
) -> Blueprint:
    blueprint = Blueprint("equipment", __name__, template_folder="templates")

    @blueprint.route("/")
    def index() -> ResponseReturnValue:
        equipment_summary = get_equipment_use_table(
            repository.meta, config.equipment_offsets
        )

        # Prepare data for the stacked area chart
        activities = repository.meta.dropna(subset=["start_local"])
        activities["month"] = (
            activities["start_local"].dt.to_period("M").apply(lambda r: r.start_time)
        )
        monthly_data = (
            activities.groupby(["month", "equipment"])
            .agg(total_distance=("distance_km", "sum"))
            .reset_index()
        )

        stacked_area_chart = (
            alt.Chart(
                monthly_data, height=300, width=1200, title=_("Monthly Equipment Usage")
            )
            .mark_area()
            .encode(
                x=alt.X("month:T", title=_("Month")),
                y=alt.Y("total_distance:Q", title=_("Total Kilometers per Month")),
                color=alt.Color("equipment:N", title=_("Equipment")),
                tooltip=[
                    alt.Tooltip("month:T", title=_("Date")),
                    alt.Tooltip("equipment:N", title=_("Equipment")),
                    alt.Tooltip(
                        "total_distance:Q", format=".0f", title=_("Total Distance")
                    ),
                ],
            )
            .interactive()
            .to_json(format="vega")
        )

        equipment_variables = {}
        for equipment in equipment_summary["equipment"]:
            selection = repository.meta.loc[repository.meta["equipment"] == equipment]
            total_distances = pd.DataFrame(
                {
                    "time": selection["start_local"],
                    "total_distance_km": selection["distance_km"].cumsum(),
                }
            )

            total_distances_plot = (
                alt.Chart(
                    total_distances,
                    height=300,
                    width=300,
                    title=_("Usage over Time"),
                )
                .mark_line(interpolate="step-after")
                .encode(
                    alt.X("time", title=_("Date")),
                    alt.Y("total_distance_km", title=_("Cumulative distance / km")),
                    tooltip=[
                        alt.Tooltip("time:T", title=_("Date")),
                        alt.Tooltip(
                            "total_distance_km:Q",
                            title=_("Cumulative distance / km"),
                            format=".0f",
                        ),
                    ],
                )
                .interactive()
                .to_json(format="vega")
            )

            yearly_distance_plot = (
                alt.Chart(
                    selection,
                    height=300,
                    title=_("Yearly distance"),
                )
                .mark_bar()
                .encode(
                    alt.X("year(start_local):O", title=_("Year")),
                    alt.Y("sum(distance_km)", title=_("Distance / km")),
                    alt.Color(
                        "kind",
                        scale=make_kind_scale(repository.meta, config),
                        title=_("Kind"),
                    ),
                    tooltip=[
                        alt.Tooltip("year(start_local):O", title=_("Year")),
                        alt.Tooltip(
                            "sum(distance_km):Q", title=_("Distance / km"), format=".0f"
                        ),
                        alt.Tooltip("kind:N", title=_("Kind")),
                    ],
                )
                .to_json(format="vega")
            )

            usages_plot = (
                alt.Chart(
                    selection,
                    height=300,
                    title=_("Kinds"),
                )
                .mark_bar()
                .encode(
                    alt.X(
                        "kind",
                        title=_("Kind"),
                    ),
                    alt.Y("sum(distance_km)", title=_("Distance / km")),
                    tooltip=[
                        alt.Tooltip("kind:N", title=_("Kind")),
                        alt.Tooltip(
                            "sum(distance_km):Q", title=_("Distance / km"), format=".0f"
                        ),
                    ],
                )
                .to_json(format="vega")
            )

            equipment_variables[equipment] = {
                "total_distances_plot": total_distances_plot,
                "total_distances_plot_id": f"total_distances_plot_{hash(equipment)}",
                "yearly_distance_plot": yearly_distance_plot,
                "yearly_distance_plot_id": f"yearly_distance_plot_{hash(equipment)}",
                "usages_plot": usages_plot,
                "usages_plot_id": f"usages_plot_{hash(equipment)}",
            }

        variables = {
            "equipment_variables": equipment_variables,
            "equipment_summary": equipment_summary.to_dict(orient="records"),
            "stacked_area_chart": stacked_area_chart,
        }

        return render_template("equipment/index.html.j2", **variables)

    return blueprint
