#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#from . import shell_like
from .dict_utils   import *
from .list_utils   import *
from .shell_like   import *
from .utils_core   import *

