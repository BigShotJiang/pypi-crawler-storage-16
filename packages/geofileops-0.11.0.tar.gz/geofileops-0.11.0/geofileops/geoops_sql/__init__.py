"""Sub-module for SQL-based geometry operations."""
