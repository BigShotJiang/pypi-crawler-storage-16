:order: 3

geometric purity
================

    adhere to classical construction rules to ensure logical consistency
