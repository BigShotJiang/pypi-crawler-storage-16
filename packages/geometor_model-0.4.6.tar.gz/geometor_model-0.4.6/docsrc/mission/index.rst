:navigation: header
:order: 1

mission
=======

    provide tools for modeling classical geometric constructions

goals
-----

.. collection::
   :sort: order


