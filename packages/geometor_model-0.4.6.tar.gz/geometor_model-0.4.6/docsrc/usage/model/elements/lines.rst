:order: 2

lines
=====

Lines are constructed by connecting two points. They extend infinitely in both directions.

.. automodule:: geometor.model.lines
   :members:
   :noindex:
