:order: 4

polygons
========

Polygons are closed shapes formed by a sequence of points.

.. automodule:: geometor.model.polygons
   :members:
   :noindex:
