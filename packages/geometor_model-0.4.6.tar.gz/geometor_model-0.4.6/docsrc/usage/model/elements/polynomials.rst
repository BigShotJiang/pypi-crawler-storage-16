:order: 5

polynomials
===========

Polynomials represent algebraic curves other than lines and circles.

.. automodule:: geometor.model.polynomials
   :members:
   :noindex:
