:navigation: footer
:order: 3

glossary
========

.. todo:: establish glossary entries

.. glossary::
   example
       an example of how to structure a glossary item

