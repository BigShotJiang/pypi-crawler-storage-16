GEOMETOR • model
================

.. image:: _static/splash.png

.. include:: intro.rst



indices
-------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
