:order: 1 

effortless composition
======================

    constructions are easily composed through simple operations
