:order: 2

symbolic accuracy
=================

    maintain exact symbolic relationships between elements using algebraic expressions
