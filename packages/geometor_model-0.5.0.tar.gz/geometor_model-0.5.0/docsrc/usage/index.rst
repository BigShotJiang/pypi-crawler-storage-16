:navigation: header
:order:    points
    lines
    circles
    polygons
    cli
    segments

usage
=====

.. collection::
   :sort: order
