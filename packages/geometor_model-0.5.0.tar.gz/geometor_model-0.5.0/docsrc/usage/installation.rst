:order: 1

installation
------------

You can install ``geometor.model`` using pip:

.. code-block:: bash

   pip install geometor-model

or clone this repo and install it directly.

.. code-block:: bash

   git clone https://github.com/geometor/model
   cd model
   pip install -e .

