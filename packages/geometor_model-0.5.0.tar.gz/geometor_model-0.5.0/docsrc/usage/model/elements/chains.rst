:order: 7

chains
======

Chains are sequences of connected segments or related geometry.

.. automodule:: geometor.model.chains
   :members:
   :noindex:
