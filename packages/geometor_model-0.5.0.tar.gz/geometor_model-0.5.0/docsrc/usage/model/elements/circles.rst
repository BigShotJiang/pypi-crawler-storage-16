:order: 3

circles
=======

Circles are defined by a center point and a radius point (or a set radius).

.. automodule:: geometor.model.circles
   :members:
   :noindex:
