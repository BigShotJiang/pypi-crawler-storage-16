:order: 1

points
======

Points are the fundamental building blocks of any construction. In ``geometor.model``, points are symbolic entities with exact coordinates.

.. automodule:: geometor.model.points
   :members:
   :noindex:
