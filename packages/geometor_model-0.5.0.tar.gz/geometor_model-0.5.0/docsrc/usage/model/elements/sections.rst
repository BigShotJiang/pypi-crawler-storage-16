:order: 8

sections
========

Sections refer to the division of segments, specifically analyzing Golden Sections.

.. automodule:: geometor.model.sections
   :members:
   :noindex:
