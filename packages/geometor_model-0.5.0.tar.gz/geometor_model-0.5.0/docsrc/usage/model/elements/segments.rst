:order: 6

segments
========

Segments are finite portions of a line defined by two endpoints.

.. automodule:: geometor.model.segments
   :members:
   :noindex:
