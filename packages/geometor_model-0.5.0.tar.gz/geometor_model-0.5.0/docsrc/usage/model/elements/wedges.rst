:order: 9

wedges
======

Wedges represent angles formed by identifying three points.

.. automodule:: geometor.model.wedges
   :members:
   :noindex:
