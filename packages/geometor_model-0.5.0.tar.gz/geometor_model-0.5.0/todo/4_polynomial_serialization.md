Investigate and fix the serialization of Polynomial elements. The current implementation breaks the model.
