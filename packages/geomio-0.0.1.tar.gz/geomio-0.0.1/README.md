# geomio

Geometry Operations, Analysis, and Management for GeoPackages.

## Installation

`geomio` is available from the [Python Package Index](https://pypi.org/project/geomio/).


## Python Compatibility

The `geomio` library is compatible with Python 3.11 to 3.13.  Developed and 
tested on **macOS** and **Windows**, should be fine on **Linux** too.


## License

MIT

## Release History

### v0.0.1
* land grab
