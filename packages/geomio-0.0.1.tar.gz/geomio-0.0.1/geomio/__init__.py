# -*- coding: utf-8 -*-
"""
Package Initialization
"""


__version__ = '0.0.1'


if __name__ == '__main__':  # pragma: no cover
    pass
