import django.dispatch

emitted_notices = django.dispatch.Signal()
