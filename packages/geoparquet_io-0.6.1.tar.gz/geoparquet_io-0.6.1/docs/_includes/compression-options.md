Supported formats:

- `ZSTD` (default) - Best balance, level 1-22, default 15
- `GZIP` - Wide compatibility, level 1-9, default 6
- `BROTLI` - High compression, level 1-11, default 6
- `LZ4` - Fastest
- `SNAPPY` - Fast, good compression
- `UNCOMPRESSED` - No compression
