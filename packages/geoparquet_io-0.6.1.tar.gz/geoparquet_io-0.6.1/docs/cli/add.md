# add Command

For detailed usage and examples, see the [Add User Guide](../guide/add.md).

## Quick Reference

```bash
gpio add --help
```

This will show all available subcommands and options.
