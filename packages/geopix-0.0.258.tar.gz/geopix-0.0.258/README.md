# geopix

## Installation
```sh
pip install geopix
```

## Getting Started
See tests.
