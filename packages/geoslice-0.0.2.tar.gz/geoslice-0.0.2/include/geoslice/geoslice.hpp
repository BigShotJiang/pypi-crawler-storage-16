#pragma once

#include "geoslice/mmap_reader.hpp"
#include "geoslice/geo_transform.hpp"
#include "geoslice/window_cache.hpp"

namespace geoslice {
    constexpr const char* VERSION = "0.0.1";
}
