
class Colorscheme:
    class KiCad:
        wire = 'black'
        bus = 'black'
        lines = 'black'
        no_connect = 'black'
        text = 'black'
        values = 'black'
        labels = 'black'
        fill = '#cccccc'
        background = 'white'

