# Get

A command-line tool that automates Git commit message generation using Google's Gemini AI. Get analyzes your staged changes and generates concise, conventional commit messages, making your Git workflow more efficient.

## Features

- 🤖 **AI-Powered Commit Messages**: Uses Google's Gemini 2.5 Flash model to generate intelligent commit messages
- 📝 **Conventional Commit Format**: Automatically follows conventional commit standards
- 🔍 **Smart Analysis**: Analyzes staged files and their diffs to understand what changed
- ✅ **Interactive Confirmation**: Prompts for confirmation before committing to prevent mistakes
- 🚀 **Simple CLI**: Easy-to-use command-line interface

## Installation

### Prerequisites

- Python 3.12 or higher
- Git installed and configured
- A Google AI API key (for Gemini)

### Install from Source

1. Clone the repository:
```bash
git clone <repository-url>
cd get
```

2. Install dependencies using `uv` (recommended) or `pip`:
```bash
# Using uv
uv sync

# Or using pip
pip install -e .
```

## Configuration

Before using Get, you need to set up your Google AI API key:

1. Create a `.env` file in the project root:
```bash
touch .env
```

2. Add your Google AI API key to the `.env` file:
```
GOOGLE_AI_API_KEY=your_api_key_here
```

You can obtain a Google AI API key from the [Google AI Studio](https://makersuite.google.com/app/apikey).

## Usage

### Generate and Commit

To generate a commit message based on your staged changes and commit:

```bash
get commit
```

The tool will:
1. Analyze all staged files and their diffs
2. Generate a commit message using Gemini AI
3. Display the generated message
4. Prompt you to confirm before committing

### Example Workflow

```bash
# Stage your changes
git add .

# Generate and commit with AI-generated message
get commit

# Output example:
# feat: add user authentication module
# 
# Do you want to commit with this message? (y/n): y
```

## How It Works

1. **File Analysis**: Get checks which files are staged using `git diff --cached --name-only`
2. **Diff Extraction**: Retrieves the full diff of staged changes using `git diff --cached`
3. **AI Generation**: Sends the staged files and diff to Gemini AI with instructions to generate a conventional commit message
4. **User Confirmation**: Displays the generated message and asks for confirmation
5. **Commit**: If confirmed, commits the changes with the generated message

## Commit Message Guidelines

The AI is instructed to generate commit messages that:
- Are concise (preferably one line, max 72 characters)
- Follow conventional commit format (e.g., `feat:`, `fix:`, `docs:`, etc.)
- Describe what was changed and why
- Use imperative mood (e.g., "Add feature" not "Added feature")

## Requirements

- Python >= 3.12
- `pydantic-ai >= 1.30.0`
- `python-dotenv >= 1.2.1`

## Development

### Project Structure

```
get/
├── get/
│   ├── __init__.py
│   ├── __main__.py
│   └── main.py          # Main CLI logic
├── pyproject.toml       # Project configuration
└── README.md
```

### Running as a Module

You can also run Get as a Python module:

```bash
python -m get commit
```

## License

[Add your license here]

## Contributing

[Add contribution guidelines here]

