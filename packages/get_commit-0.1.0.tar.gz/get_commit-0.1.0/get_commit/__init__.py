"""Get - A CLI tool that automates commit messages using Gemini AI."""

__version__ = "0.1.0"
