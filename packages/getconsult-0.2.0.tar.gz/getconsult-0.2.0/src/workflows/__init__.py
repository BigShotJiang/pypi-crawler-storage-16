"""
Workflows for Consult
"""

from .consensus.consensus_workflow import ConsensusWorkflow

__all__ = ["ConsensusWorkflow"]