"""Memory management for Consult."""

from .memory_manager import MemoryManager

__all__ = ["MemoryManager"]