"""
Consult TUI Package
Multi-Agent AI Orchestration Terminal Interface
"""

from .app import ChatTUI, main

__all__ = ["ChatTUI", "main"]
