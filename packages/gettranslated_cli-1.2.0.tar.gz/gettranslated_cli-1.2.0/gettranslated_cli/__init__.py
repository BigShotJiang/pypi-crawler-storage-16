"""GetTranslated CLI - Command-line tool for syncing translations with GetTranslated.ai"""

__version__ = "1.2.0"

