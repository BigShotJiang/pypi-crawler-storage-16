# gfs-file-prune
Grandfather-Father-Son file pruning
