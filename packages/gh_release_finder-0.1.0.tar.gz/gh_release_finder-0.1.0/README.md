# release-finder

A CLI tool to fetch GitHub repository release information. Defaults to `milvus-io/milvus`.

## Installation

```bash
uv venv -p 3.10
source .venv/bin/activate
uv pip install -e .
```

## Usage

### List releases

```bash
# List latest 10 releases (default: milvus-io/milvus)
release-finder list

# Limit number of releases
release-finder list --limit 5

# Specify different repository
release-finder list --repo langchain-ai/langchain
```

### Get latest release

```bash
release-finder latest
release-finder latest --repo owner/repo
```

### Get specific release by tag

```bash
release-finder get v2.5.0
release-finder get v2.5.0 --repo owner/repo
```

### Find latest minor versions

Find the latest releases for the two most recent minor versions (e.g., v2.6.x and v2.5.x):

```bash
release-finder minor
```

Output:
```
Minor Version  | Latest Tag | Published        | URL
-------------- | ---------- | ---------------- | ---
v2.6.x         | v2.6.7     | 2025-12-04 09:40 | https://github.com/milvus-io/milvus/releases/tag/v2.6.7
v2.5.x         | v2.5.23    | 2025-11-20 02:45 | https://github.com/milvus-io/milvus/releases/tag/v2.5.23

Version Tags:
  v2.6.7
  v2.5.23
```

## Options

| Option | Short | Description |
|--------|-------|-------------|
| `--repo` | `-r` | GitHub repository in format `owner/repo` (default: `milvus-io/milvus`) |
| `--limit` | `-l` | Number of releases to fetch (default: 10, only for `list` command) |
| `--token` | `-t` | GitHub token for authentication (or set `GITHUB_TOKEN` env var) |

## Authentication

For higher rate limits, set your GitHub token:

```bash
export GITHUB_TOKEN=your_token_here
# or
release-finder list --token your_token_here
```
