import re
import click
import requests
from rich.console import Console
from rich.table import Table
from rich import box
from typing import Optional
from datetime import datetime


console = Console()


def parse_version(tag: str) -> Optional[tuple[int, int, int]]:
    """Parse version tag like v2.6.7 into tuple (2, 6, 7)."""
    match = re.match(r"v?(\d+)\.(\d+)\.(\d+)", tag)
    if match:
        return (int(match.group(1)), int(match.group(2)), int(match.group(3)))
    return None


def get_minor_version(version: tuple[int, int, int]) -> tuple[int, int]:
    """Get minor version (major, minor) from full version."""
    return (version[0], version[1])


def fetch_releases(repo: str, limit: int = 10, token: Optional[str] = None) -> list:
    """Fetch releases from GitHub API."""
    url = f"https://api.github.com/repos/{repo}/releases"
    headers = {"Accept": "application/vnd.github+json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    params = {"per_page": limit}

    try:
        response = requests.get(url, headers=headers, params=params, timeout=30)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        console.print(f"[red]Error fetching releases: {e}[/red]")
        return []


def format_date(date_str: str) -> str:
    """Format ISO date string to readable format."""
    try:
        dt = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M")
    except (ValueError, AttributeError):
        return date_str or "N/A"


def display_releases(releases: list, repo: str) -> None:
    """Display releases in a formatted table."""
    if not releases:
        console.print(f"[yellow]No releases found for {repo}[/yellow]")
        return

    table = Table(
        title=f"Releases for {repo}",
        box=box.ROUNDED,
        show_header=True,
        header_style="bold cyan",
    )

    table.add_column("Tag", style="green", no_wrap=True)
    table.add_column("Name", style="white")
    table.add_column("Published", style="yellow")
    table.add_column("Pre-release", style="magenta")
    table.add_column("Author", style="blue")

    for release in releases:
        tag = release.get("tag_name", "N/A")
        name = release.get("name", "N/A") or tag
        published = format_date(release.get("published_at", ""))
        prerelease = "Yes" if release.get("prerelease") else "No"
        author = release.get("author", {}).get("login", "N/A")

        table.add_row(tag, name, published, prerelease, author)

    console.print(table)


def display_release_detail(release: dict) -> None:
    """Display detailed information about a single release."""
    console.print(f"\n[bold cyan]Release: {release.get('name', release.get('tag_name', 'N/A'))}[/bold cyan]")
    console.print(f"[green]Tag:[/green] {release.get('tag_name', 'N/A')}")
    console.print(f"[yellow]Published:[/yellow] {format_date(release.get('published_at', ''))}")
    console.print(f"[magenta]Pre-release:[/magenta] {'Yes' if release.get('prerelease') else 'No'}")
    console.print(f"[blue]Author:[/blue] {release.get('author', {}).get('login', 'N/A')}")
    console.print(f"[cyan]URL:[/cyan] {release.get('html_url', 'N/A')}")

    # Display assets
    assets = release.get("assets", [])
    if assets:
        console.print(f"\n[bold]Assets ({len(assets)}):[/bold]")
        for asset in assets:
            size_mb = asset.get("size", 0) / (1024 * 1024)
            console.print(f"  - {asset.get('name')} ({size_mb:.2f} MB)")

    # Display release body
    body = release.get("body", "")
    if body:
        console.print(f"\n[bold]Release Notes:[/bold]")
        console.print(body[:1000] + ("..." if len(body) > 1000 else ""))


@click.group()
@click.version_option(version="0.1.0", prog_name="release-finder")
def cli():
    """A CLI tool to fetch GitHub repository release information."""
    pass


@cli.command()
@click.option(
    "--repo", "-r",
    default="milvus-io/milvus",
    help="GitHub repository in format 'owner/repo' (default: milvus-io/milvus)"
)
@click.option(
    "--limit", "-l",
    default=10,
    type=int,
    help="Number of releases to fetch (default: 10)"
)
@click.option(
    "--token", "-t",
    envvar="GITHUB_TOKEN",
    help="GitHub token for authentication (or set GITHUB_TOKEN env var)"
)
def list(repo: str, limit: int, token: Optional[str]):
    """List releases for a GitHub repository."""
    console.print(f"[dim]Fetching releases for {repo}...[/dim]")
    releases = fetch_releases(repo, limit, token)
    display_releases(releases, repo)


@cli.command()
@click.option(
    "--repo", "-r",
    default="milvus-io/milvus",
    help="GitHub repository in format 'owner/repo' (default: milvus-io/milvus)"
)
@click.option(
    "--token", "-t",
    envvar="GITHUB_TOKEN",
    help="GitHub token for authentication (or set GITHUB_TOKEN env var)"
)
def latest(repo: str, token: Optional[str]):
    """Get the latest release for a GitHub repository."""
    url = f"https://api.github.com/repos/{repo}/releases/latest"
    headers = {"Accept": "application/vnd.github+json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    try:
        response = requests.get(url, headers=headers, timeout=30)
        response.raise_for_status()
        release = response.json()
        display_release_detail(release)
    except requests.exceptions.RequestException as e:
        console.print(f"[red]Error fetching latest release: {e}[/red]")


@cli.command()
@click.argument("tag")
@click.option(
    "--repo", "-r",
    default="milvus-io/milvus",
    help="GitHub repository in format 'owner/repo' (default: milvus-io/milvus)"
)
@click.option(
    "--token", "-t",
    envvar="GITHUB_TOKEN",
    help="GitHub token for authentication (or set GITHUB_TOKEN env var)"
)
def get(tag: str, repo: str, token: Optional[str]):
    """Get a specific release by tag name."""
    url = f"https://api.github.com/repos/{repo}/releases/tags/{tag}"
    headers = {"Accept": "application/vnd.github+json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    try:
        response = requests.get(url, headers=headers, timeout=30)
        response.raise_for_status()
        release = response.json()
        display_release_detail(release)
    except requests.exceptions.HTTPError as e:
        if response.status_code == 404:
            console.print(f"[red]Release with tag '{tag}' not found in {repo}[/red]")
        else:
            console.print(f"[red]Error fetching release: {e}[/red]")
    except requests.exceptions.RequestException as e:
        console.print(f"[red]Error fetching release: {e}[/red]")


@cli.command()
@click.option(
    "--repo", "-r",
    default="milvus-io/milvus",
    help="GitHub repository in format 'owner/repo' (default: milvus-io/milvus)"
)
@click.option(
    "--token", "-t",
    envvar="GITHUB_TOKEN",
    help="GitHub token for authentication (or set GITHUB_TOKEN env var)"
)
def minor(repo: str, token: Optional[str]):
    """Find latest releases for the two most recent minor versions.

    For example, if the latest is v2.6.7, this will show:
    - Latest v2.6.x release (e.g., v2.6.7)
    - Latest v2.5.x release (e.g., v2.5.23)
    """
    console.print(f"[dim]Fetching releases for {repo}...[/dim]")

    # Fetch more releases to ensure we find both minor versions
    releases = fetch_releases(repo, limit=100, token=token)

    if not releases:
        console.print("[red]No releases found[/red]")
        return

    # Parse and group releases by minor version
    version_releases: dict[tuple[int, int], list] = {}

    for release in releases:
        if release.get("prerelease"):
            continue
        tag = release.get("tag_name", "")
        version = parse_version(tag)
        if version:
            minor_ver = get_minor_version(version)
            if minor_ver not in version_releases:
                version_releases[minor_ver] = []
            version_releases[minor_ver].append((version, release))

    if not version_releases:
        console.print("[red]No valid version releases found[/red]")
        return

    # Sort minor versions descending
    sorted_minors = sorted(version_releases.keys(), reverse=True)

    if len(sorted_minors) < 2:
        console.print("[yellow]Only one minor version found[/yellow]")
        sorted_minors = sorted_minors[:1]
    else:
        sorted_minors = sorted_minors[:2]

    # For each minor version, get the latest patch release
    table = Table(
        title=f"Latest Minor Version Releases for {repo}",
        box=box.ROUNDED,
        show_header=True,
        header_style="bold cyan",
    )

    table.add_column("Minor Version", style="cyan", no_wrap=True)
    table.add_column("Latest Tag", style="green", no_wrap=True)
    table.add_column("Published", style="yellow")
    table.add_column("URL", style="blue")

    for minor_ver in sorted_minors:
        # Sort by full version to get the latest patch
        releases_for_minor = sorted(version_releases[minor_ver], key=lambda x: x[0], reverse=True)
        _, latest_release = releases_for_minor[0]

        minor_str = f"v{minor_ver[0]}.{minor_ver[1]}.x"
        tag = latest_release.get("tag_name", "N/A")
        published = format_date(latest_release.get("published_at", ""))
        url = latest_release.get("html_url", "N/A")

        table.add_row(minor_str, tag, published, url)

    console.print(table)

    # Also print simple output for scripting
    console.print("\n[bold]Version Tags:[/bold]")
    for minor_ver in sorted_minors:
        releases_for_minor = sorted(version_releases[minor_ver], key=lambda x: x[0], reverse=True)
        _, latest_release = releases_for_minor[0]
        tag = latest_release.get("tag_name", "")
        console.print(f"  {tag}")


def main():
    """Main entry point."""
    cli()
