def main() -> None:
    print("Hello from ghbin!")
