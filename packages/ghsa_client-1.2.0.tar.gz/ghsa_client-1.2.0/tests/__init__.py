"""Tests for ghsa-client package."""
