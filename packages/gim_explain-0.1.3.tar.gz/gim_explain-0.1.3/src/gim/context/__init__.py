"""GIM context manager and related utilities."""
from gim.context.gim import GIM

__all__ = ["GIM"]
