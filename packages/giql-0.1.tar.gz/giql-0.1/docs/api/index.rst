API Reference
=============

This section documents the GIQL Python API.

.. toctree::
   :maxdepth: 2

.. automodule:: giql
   :members:
   :undoc-members:
   :show-inheritance:
