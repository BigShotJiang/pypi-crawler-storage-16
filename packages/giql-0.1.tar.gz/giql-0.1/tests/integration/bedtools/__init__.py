"""Bedtools integration tests for GIQL.

This package contains integration tests that validate GIQL query results
against bedtools command outputs using simulated genomic datasets.
"""
