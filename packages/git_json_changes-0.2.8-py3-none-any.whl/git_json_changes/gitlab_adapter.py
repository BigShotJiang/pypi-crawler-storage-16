def fetch_gitlab_issue(issue_number, repo_path, content_limit):
    raise NotImplementedError('GitLab Issues support not yet implemented')