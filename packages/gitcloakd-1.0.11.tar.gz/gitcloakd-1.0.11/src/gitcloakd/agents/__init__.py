"""AI Agent support for gitcloakd."""

from gitcloakd.agents.manager import AgentManager

__all__ = ["AgentManager"]
