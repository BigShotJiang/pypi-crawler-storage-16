"""gitcloakd CLI module."""

from gitcloakd.cli.main import cli

__all__ = ["cli"]
