"""
gitcloakd Web Admin Interface
All data encrypted with GPG - nothing stored in plaintext
"""
