"""Alert system for gitcloakd."""

from gitcloakd.alerts.notifier import AlertNotifier

__all__ = ["AlertNotifier"]
