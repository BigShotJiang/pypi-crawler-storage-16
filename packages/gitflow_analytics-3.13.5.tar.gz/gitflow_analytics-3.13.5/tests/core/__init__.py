"""Tests for core analytics functionality."""
