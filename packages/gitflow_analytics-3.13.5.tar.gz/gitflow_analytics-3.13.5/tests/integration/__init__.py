"""Integration tests for GitFlow Analytics.

This package contains end-to-end integration tests that verify complete workflows
from configuration through analysis to report generation.
"""
