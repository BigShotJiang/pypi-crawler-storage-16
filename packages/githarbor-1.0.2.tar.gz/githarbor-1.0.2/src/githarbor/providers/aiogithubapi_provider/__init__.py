"""AIOGitHubAPI Provider package."""

from githarbor.providers.aiogithubapi_provider.repository import AioGitHubRepository

__all__ = ["AioGitHubRepository"]
