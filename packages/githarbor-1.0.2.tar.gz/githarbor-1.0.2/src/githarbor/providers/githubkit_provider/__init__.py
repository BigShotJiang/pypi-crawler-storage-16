"""GitHubKit Provider package."""

from githarbor.providers.githubkit_provider.repository import GitHubKitRepository

__all__ = ["GitHubKitRepository"]
