"""GitLab Provider package."""

from githarbor.providers.gitlab_provider.repository import GitLabRepository

__all__ = ["GitLabRepository"]
