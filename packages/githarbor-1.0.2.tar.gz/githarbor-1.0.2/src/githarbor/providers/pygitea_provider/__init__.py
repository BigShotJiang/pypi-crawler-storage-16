"""PyGitea provider package."""

from __future__ import annotations

from githarbor.providers.pygitea_provider.repository import PyGiteaRepository

__all__ = ["PyGiteaRepository"]
