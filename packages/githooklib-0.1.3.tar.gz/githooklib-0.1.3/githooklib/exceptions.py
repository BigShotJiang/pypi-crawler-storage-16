class GitHookLibException(Exception):
    pass


__all__ = ["GitHookLibException"]
