from . import git

__all__ = [
    "WORKSPACE_SUFFIX_SEP",
    git
]

WORKSPACE_SUFFIX_SEP = "-"
