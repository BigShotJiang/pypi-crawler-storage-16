# Pyarmor 9.2.2 (trial), 000000, 2025-12-14T19:05:25.831696
from .pyarmor_runtime import __pyarmor__
