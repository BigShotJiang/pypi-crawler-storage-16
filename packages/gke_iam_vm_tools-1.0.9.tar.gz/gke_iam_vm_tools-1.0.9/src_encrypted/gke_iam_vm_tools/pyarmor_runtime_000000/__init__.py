# Pyarmor 9.2.2 (trial), 000000, 2025-12-14T22:11:59.895554
from .pyarmor_runtime import __pyarmor__
