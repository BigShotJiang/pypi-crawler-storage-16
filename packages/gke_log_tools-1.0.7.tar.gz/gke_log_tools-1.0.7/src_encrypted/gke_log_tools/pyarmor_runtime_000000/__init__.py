# Pyarmor 9.2.2 (trial), 000000, 2025-12-14T20:48:45.846292
from .pyarmor_runtime import __pyarmor__
