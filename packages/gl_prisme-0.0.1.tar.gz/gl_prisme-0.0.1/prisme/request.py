from datetime import date, datetime
from typing import TypeVar


class PrismeResponse:
    pass


ResponseType = TypeVar("ResponseType", bound=PrismeResponse)


class PrismeRequest[ResponseType]:

    @classmethod
    def method(cls) -> str:
        raise NotImplementedError("Must be implemented in subclass")  # pragma: no cover

    @property
    def xml(self):
        raise NotImplementedError("Must be implemented in subclass")  # pragma: no cover

    @classmethod
    def response_class(cls) -> type[ResponseType]:
        raise NotImplementedError("Must be implemented in subclass")  # pragma: no cover

    @staticmethod
    def prepare(value: str | datetime | date | None) -> str:
        if value is None:
            return ""
        if isinstance(value, datetime):
            value = f"{value:%Y-%m-%dT%H:%M:%S}"
        if isinstance(value, date):
            value = f"{value:%Y-%m-%d}"
        return str(value)
