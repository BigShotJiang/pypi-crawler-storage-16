"""Provides fundamental components and utilities."""
