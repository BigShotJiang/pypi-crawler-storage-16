"""Adapters for external formats."""

from gllm_core.adapters.tool import from_google_function, from_langchain_tool

__all__ = ["from_google_function", "from_langchain_tool"]
