"""Google ADK tool adapter conversions.

Authors:
    Dimitrij Ray (dimitrij.ray@gdplabs.id)

References:
    NONE
"""

import asyncio
from typing import Any, Callable

from gllm_core.schema.tool import Tool

_DEFAULT_SCHEMA: dict[str, Any] = {"type": "object", "properties": {}}


def _validate_and_extract_schema(parameters: Any) -> dict[str, Any]:
    """Validate and extract the input schema from Google ADK parameters.

    Args:
        parameters (Any): The parameters from the Google ADK function declaration.

    Returns:
        dict[str, Any]: The validated input schema.

    Raises:
        TypeError: If the schema has invalid structure.
    """
    if parameters is None:
        return _DEFAULT_SCHEMA.copy()

    if isinstance(parameters, dict):
        if "properties" in parameters and not isinstance(parameters.get("properties"), dict):
            raise TypeError("Google ADK function schema 'properties' must be a dictionary.")
        return parameters

    return dict(parameters) if hasattr(parameters, "__iter__") else _DEFAULT_SCHEMA.copy()


def from_google_function(function_declaration: Any, func: Callable | None = None) -> Tool:
    """Convert a Google ADK function declaration into the SDK Tool representation.

    The Google ADK `FunctionDeclaration` provides access to:
    1. `name`: The function name
    2. `description`: The function description
    3. `parameters`: A dict in JSON Schema format (OpenAPI 3.0 compatible)

    Args:
        function_declaration (Any): The Google ADK function declaration to convert.
        func (Callable | None, optional): The implementation function for the tool. Defaults to None.

    Returns:
        Tool: The converted SDK tool.

    Raises:
        ValueError: If the function declaration is None or has invalid fields.
        AttributeError: If required attributes are missing.
        TypeError: If field types are incorrect.
    """
    if function_declaration is None:
        raise ValueError("Google ADK function declaration cannot be None.")

    for attr in ("name", "description"):
        if not hasattr(function_declaration, attr):
            raise AttributeError(f"Google ADK function declaration must have a {attr!r} attribute.")

    name = function_declaration.name
    description = function_declaration.description

    if not isinstance(name, str) or not name:
        raise ValueError("Google ADK function 'name' must be a non-empty string.")

    if description is not None and not isinstance(description, str):
        raise TypeError("Google ADK function 'description' must be a string when provided.")

    if func is not None and not callable(func):
        raise TypeError("Google ADK tool implementation must be callable when provided.")

    parameters = getattr(function_declaration, "parameters", None)
    input_schema = _validate_and_extract_schema(parameters)

    is_async = asyncio.iscoroutinefunction(func) if func else False

    return Tool(
        name=name,
        description=description,
        input_schema=input_schema,
        func=func,
        is_async=is_async,
    )
