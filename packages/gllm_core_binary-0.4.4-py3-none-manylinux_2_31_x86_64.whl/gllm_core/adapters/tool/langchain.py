"""LangChain tool adapter conversions.

Authors:
    Dimitrij Ray (dimitrij.ray@gdplabs.id)

References:
    NONE
"""

import asyncio
from typing import Any, Callable

from gllm_core.schema.tool import Tool


class LangChainToolKeys:
    """Constants for LangChain tool attribute keys."""

    FUNC = "func"
    COROUTINE = "coroutine"
    RUN = "_run"
    ARUN = "_arun"
    NAME = "name"
    DESCRIPTION = "description"
    ARGS_SCHEMA = "args_schema"


LANGCHAIN_FUNCTION_ATTRS = (
    LangChainToolKeys.FUNC,
    LangChainToolKeys.COROUTINE,
    LangChainToolKeys.RUN,
    LangChainToolKeys.ARUN,
)


def _extract_attribute(tool: Any, attr_name: str) -> Any:
    """Extract an attribute from a LangChain tool.

    A LangChain tool can be either a dictionary-like object or an object with attributes.
    This function handles both cases:
        1. If the tool has the attribute as an attribute, it returns the attribute value.
        2. If the tool has the attribute as a key (is a dictionary-like object), it returns the key value.
        3. Otherwise, it returns None.

    Args:
        tool (Any): The LangChain tool to extract the attribute from.
        attr_name (str): The attribute name to extract.

    Returns:
        Any: The attribute value, or None if not found.
    """
    if hasattr(tool, attr_name):
        return getattr(tool, attr_name)

    if hasattr(tool, "get"):
        return tool.get(attr_name)

    return None


def _get_langchain_tool_func(tool: Any) -> Callable | None:
    """Gets the function from a LangChain tool.

    This function extracts the appropriate callable from a LangChain tool, with the following priority:
        1. func
        2. coroutine
        3. _run
        4. _arun

    Args:
        tool (Any): The LangChain tool to extract the function from.

    Returns:
        Callable | None: The extracted function, or None if no function is found.
    """
    for func_key in LANGCHAIN_FUNCTION_ATTRS:
        func = _extract_attribute(tool, func_key)
        if callable(func):
            return func

    return None


def _get_input_schema(tool: Any) -> dict[str, Any]:
    """Get input schema from a LangChain tool.

    Args:
        tool (Any): The LangChain tool to get schema from.

    Returns:
        dict[str, Any]: The input schema, or default empty schema if none found.
    """
    input_schema = _extract_attribute(tool, LangChainToolKeys.ARGS_SCHEMA)

    return input_schema if input_schema is not None else {"type": "object", "properties": {}}


def from_langchain_tool(langchain_tool: Any) -> Tool:
    """Convert a LangChain tool into the SDK Tool representation.

    This function handles both traditional LangChain tools created with the @tool decorator
    and tools created by subclassing the LangChain Tool class.

    Args:
        langchain_tool (Any): The LangChain tool to convert.

    Returns:
        Tool: The converted SDK tool.

    Raises:
        ValueError: If the input is not a valid LangChain tool.
    """
    name = _extract_attribute(langchain_tool, LangChainToolKeys.NAME)
    if not name:
        raise ValueError("LangChain tool must have a 'name' attribute or key.")

    description = _extract_attribute(langchain_tool, LangChainToolKeys.DESCRIPTION)
    if not description:
        raise ValueError("LangChain tool must have a 'description' attribute or key.")

    func = _get_langchain_tool_func(langchain_tool)
    input_schema = _get_input_schema(langchain_tool)

    return Tool(
        name=name,
        description=description,
        input_schema=input_schema,
        func=func,
        is_async=asyncio.iscoroutinefunction(func) if func is not None else False,
    )
