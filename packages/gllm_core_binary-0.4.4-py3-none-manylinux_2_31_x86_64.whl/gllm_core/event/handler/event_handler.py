"""Defines an abstract base class for all event handlers used throughout the Gen AI applications.

Authors:
    Henry Wicaksono (henry.wicaksono@gdplabs.id)

References:
    NONE
"""

from abc import ABC, abstractmethod

from gllm_core.constants import EventType, EventTypeSuffix
from gllm_core.schema import Event
from gllm_core.utils import LoggerManager

DEFAULT_COLOR_MAP = {
    EventType.ACTIVITY: "bright_blue",
    EventType.CODE: "bright_red",
    EventType.THINKING: "bright_yellow",
    EventType.REFERENCE: "bright_green",
    EventType.STATUS: "bright_black",
}
DEFAULT_COLOR = "white"


class BaseEventHandler(ABC):
    """An abstract base class for all event handlers used throughout the Gen AI applications.

    Attributes:
        name (str): The name assigned to the event handler.
        color_map (dict[str, str]): The dictionary that maps certain event types to their
            corresponding colors in Rich format.
    """

    def __init__(
        self,
        name: str | None = None,
        color_map: dict[str, str] | None = None,
    ):
        """Initializes a new instance of the BaseEventHandler class.

        Args:
            name (str | None, optional): The name assigned to the event handler. Defaults to None,
                in which case the class name will be used.
            color_map (dict[str, str], optional): The dictionary that maps certain event types to their corresponding
                colors in Rich format. Defaults to None, in which case the default color map will be used.
        """
        self.name = name or self.__class__.__name__
        self.color_map = color_map or DEFAULT_COLOR_MAP
        self._logger = LoggerManager().get_logger(self.name)

    @abstractmethod
    async def emit(self, event: Event) -> None:
        """Emits the given event.

        This abstract method must be implemented by subclasses to define how an event is emitted.

        Args:
            event (Event): The event to be emitted.

        Raises:
            NotImplementedError: If the method is not implemented in a subclass.
        """
        raise NotImplementedError

    async def close(self) -> None:  # noqa: B027
        """Closes the event handler.

        By default, this method does nothing. Subclasses can override this method to perform cleanup tasks
        (e.g., closing connections or releasing resources) when needed. Event handlers that do not require
        cleanup can inherit this default behavior without any changes.

        Returns:
            None
        """

    def _get_rich_color(self, value: str) -> str:
        """Gets the assigned Rich color for the given value.

        Args:
            value (str): The value to get the Rich color for.

        Returns:
            str: The Rich color for the given value.
        """
        for suffix in EventTypeSuffix:
            value = value.removesuffix(suffix)

        return self.color_map.get(value, DEFAULT_COLOR)
