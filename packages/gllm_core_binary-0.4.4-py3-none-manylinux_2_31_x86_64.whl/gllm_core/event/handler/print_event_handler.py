"""Defines an event handler class to print events with human readable format.

Authors:
    Henry Wicaksono (henry.wicaksono@gdplabs.id)

References:
    NONE
"""

from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.style import Style

from gllm_core.constants import EventType, EventTypeSuffix
from gllm_core.event.handler.event_handler import BaseEventHandler
from gllm_core.schema import Event


class PrintEventHandler(BaseEventHandler):
    """An event handler that prints the event with human readable format.

    Attributes:
        name (str): The name assigned to the event handler.
        padding_char (str): The character to use for padding.
        color_map (dict[str, str]): The dictionary that maps certain event types to their
            corresponding colors in Rich format.
        console (Console): The Rich Console object to use for printing.
    """

    def __init__(
        self,
        name: str | None = None,
        color_map: dict[str, str] | None = None,
        padding_char: str = "=",
    ):
        """Initializes a new instance of the PrintEventHandler class.

        Args:
            name (str | None, optional): The name assigned to the event handler. Defaults to None,
                in which case the class name will be used.
            color_map (dict[str, str], optional): The dictionary that maps certain event types to their corresponding
                colors in Rich format. Defaults to None, in which case the default color map will be used.
            padding_char (str, optional): The character to use for padding. Defaults to "=".
        """
        super().__init__(name, color_map)
        self.padding_char = padding_char
        self.console = Console(highlight=False)

    async def emit(self, event: Event) -> None:
        """Emits the given event.

        Args:
            event (Event): The event to be emitted.
        """
        if event.type == EventType.STATUS:
            self.console.print(f"[{event.level.name}][{event.timestamp}] {event.value}")
            return

        if event.type == EventType.ACTIVITY:
            self._print_activity(event.value)
        elif event.type.endswith(EventTypeSuffix.START) or event.type.endswith(EventTypeSuffix.END):
            self._print_start_end(event.type)
        else:
            style = Style(color=self._get_rich_color(event.type))
            self.console.print(event.value, end="", style=style)

    def _print_activity(self, activity: dict[str, Any]) -> None:
        """Prints the activity.

        This method prints the activity with the following format:

        ╭──────────────────╮
        │     ACTIVITY     │
        ╰──────────────────╯
        >>> key1: value1
        >>> key2: value2

        Args:
            activity (dict[str, Any]): The activity to print.
        """
        color = self._get_rich_color(EventType.ACTIVITY)
        panel = self._create_separator_panel(EventType.ACTIVITY, color)
        self.console.print()
        self.console.print(panel)

        for key, value in activity.items():
            self.console.print(f">>> {key}: {value}", style=Style(color=color))

    def _print_start_end(self, event_type: str) -> None:
        """Prints the start or end of block based events.

        This method prints the start or end of block based events with the following format:

        ╭─────────────────────╮
        │     EVENT START     │
        ╰─────────────────────╯
        Event content...
        ╭───────────────────╮
        │     EVENT END     │
        ╰───────────────────╯

        Args:
            event_type (str): The type of the event.
        """
        color = self._get_rich_color(event_type)
        panel = self._create_separator_panel(event_type, color)
        self.console.print()
        self.console.print(panel)

    def _create_separator_panel(self, value: str, color: str) -> Panel:
        """Creates a separator panel.

        This method creates a separator Rich Panel with the following format:

        ╭───────────────╮
        │     VALUE     │
        ╰───────────────╯

        Args:
            value (str): The value to format.
            color (str): The color of the separator.

        Returns:
            Panel: The separator panel.
        """
        value = value.replace("_", " ").upper().strip()
        style = Style(color=color, bold=True)
        return Panel.fit(value, style=style, border_style=style, padding=(0, 5))
