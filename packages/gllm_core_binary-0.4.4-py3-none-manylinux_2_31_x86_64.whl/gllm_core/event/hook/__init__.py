"""Defines the event hooks module used throughout the Gen AI applications."""

from gllm_core.event.hook.json_stringify_event_hook import JSONStringifyEventHook

__all__ = ["JSONStringifyEventHook"]
