"""Defines a component used for custom event messaging in Gen AI applications pipelines.

Authors:
    Henry Wicaksono (henry.wicaksono@gdplabs.id)

References:
    NONE
"""

from typing import Any

from gllm_core.event import EventEmitter
from gllm_core.schema import Component
from gllm_core.utils import get_placeholder_keys


class Messenger(Component):
    """Emits a custom event message with possible access to the state variables.

    This component acts as an intermediary step, designed to be placed between other pipeline steps.
    It allows for event messaging operations to be performed outside individual components but still within
    the context of the pipeline execution.

    Attributes:
        message (str): The message to be sent, may contain placeholders enclosed in curly braces `{}`.
        is_template (bool): Whether the message is a template that can be injected with state variables.
            Defaults to True.
        variable_keys (list[str]): The keys of the message that can be injected with state variables.
            Only used if `is_template` is set to True.

    Plain string message example:
    ```python
    event_emitter = EventEmitter(handlers=[ConsoleEventHandler()])
    kwargs = {"event_emitter": event_emitter}

    messenger = Messenger("Executing component.", is_template=False)
    await messenger.run(**kwargs)
    ```

    Template message example:
    ```python
    event_emitter = EventEmitter(handlers=[ConsoleEventHandler()])
    state_variables = {"query": "Hi!", "top_k": 10}
    kwargs = {"event_emitter": event_emitter, "state_variables": state_variables}

    messenger = Messenger("Executing component for query {query} and top k {top_k}.")
    await messenger.run(**kwargs)
    ```
    """

    def __init__(self, message: str, is_template: bool = True):
        """Initializes a new instance of the Messenger class.

        Args:
            message (str): The message to be sent, may contain placeholders enclosed in curly braces `{}`.
            is_template (bool, optional): Whether the message is a template that can be injected with state variables.
                Defaults to True.

        Raises:
            ValueError: If the keys of the message does not match the provided keys.
        """
        self.message = message
        self.is_template = is_template
        self.variable_keys = get_placeholder_keys(message) if is_template else []

    async def _run(self, **kwargs: Any) -> None:
        """Executes the messaging operation.

        This method validates the provided kwargs to make sure it contains the necessary keys and values, then
        calls the `send_message` method to emit the message.

        Args:
            **kwargs (Any): A dictionary of arguments for the event process, must include `event_emitter` and may
                optionally include `state_variables`, and `emit_kwargs`.

        Raises:
            KeyError: If the kwargs is missing the `event_emitter` key.
        """
        if "event_emitter" not in kwargs or not isinstance(kwargs["event_emitter"], EventEmitter):
            raise KeyError("The input kwargs must include an `event_emitter` key with an EventEmitter instance.")

        return await self.send_message(
            kwargs["event_emitter"],
            state_variables=kwargs.get("state_variables"),
            emit_kwargs=kwargs.get("emit_kwargs"),
        )

    async def send_message(
        self,
        event_emitter: EventEmitter,
        state_variables: dict[str, Any] | None = None,
        emit_kwargs: dict[str, Any] | None = None,
    ) -> None:
        """Emits the message to the event emitter.

        This method validates the variables, formats the message if required, and then emits the message using the
        event emitter.

        Args:
            event_emitter (EventEmitter): The event emitter instance to emit the message.
            state_variables (dict[str, Any] | None, optional): The state variables to be injected into the message
                placeholders. Can only be provided if `is_template` is set to True. Defaults to None.
            emit_kwargs (dict[str, Any] | None, optional): The keyword arguments to be passed to the event emitter's
                emit method. Defaults to None.
        """
        state_variables = state_variables or {}
        emit_kwargs = emit_kwargs or {}
        formatted_message = self.message

        if self.is_template:
            self._validate_variables(state_variables)
            message_kwargs = {key: state_variables[key] for key in self.variable_keys}
            formatted_message = formatted_message.format(**message_kwargs)
        elif state_variables:
            raise ValueError("State variables can only be provided if `is_template` is set to True.")

        await event_emitter.emit(formatted_message, **emit_kwargs)

    def _validate_variables(self, variables: dict[str, Any]) -> None:
        """Validates the variables to ensure there are no missing keys.

        This method checks if the provided variables are missing any of the expected keys. If so, it raises a
        `ValueError`.

        Args:
            variables (dict[str, Any]): The variables to be validated.

        Raises:
            ValueError: If the variables are missing the expected keys.
        """
        missing_keys = set(self.variable_keys) - set(variables.keys())
        if missing_keys:
            raise ValueError(f"The following keys are missing in the variables: {missing_keys}")
