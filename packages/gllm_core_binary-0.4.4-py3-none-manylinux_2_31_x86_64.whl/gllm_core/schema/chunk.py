"""Defines the Chunk schema, which represents a chunk of content retrieved from a vector store.

Authors:
    Dimitrij Ray (dimitrij.ray@gdplabs.id)

References:
    NONE
"""

from typing import Any, Generic, Iterable, TypeVar
from uuid import uuid4

from pydantic import BaseModel, Field, field_validator

MAX_PREVIEW_LENGTH = 50
MAX_ITEMS_PREVIEW = 3

T = TypeVar("T")


class _TruncatedIterable(Generic[T]):
    """Represents a truncated iterable with first and last elements visible.

    Attributes:
        items (Iterable[T]): The iterable to be truncated.
        max_items_preview (int): Maximum number of items to show before truncation.
    """

    def __init__(self, items: Iterable[T], max_items_preview: int = MAX_ITEMS_PREVIEW) -> None:
        """Initialize a TruncatedIterable.

        Args:
            items (Iterable[T]): The iterable to be truncated.
            max_items_preview (int, optional): Maximum number of items to show before truncation.
                Defaults to MAX_ITEMS_PREVIEW.
        """
        self.items = list(items)
        self.max_items_preview = max_items_preview

    def __repr__(self) -> str:
        """Return a string representation of the truncated iterable.

        Returns:
            str: The string representation in the format [first, ..., last] if truncated,
                 or [item1, item2, ...] if not truncated.
        """
        if len(self.items) <= self.max_items_preview:
            return str(self.items)

        def format_element(elem: Any) -> str:
            return f"{elem!r}"

        first_item = format_element(self.items[0])
        last_item = format_element(self.items[-1])
        return f"[{first_item}, ..., {last_item}]"


class Chunk(BaseModel, arbitrary_types_allowed=True):
    """Represents a chunk of content retrieved from a vector store.

    Attributes:
        id (str): A unique identifier for the chunk. Defaults to a random UUID.
        content (str | bytes): The content of the chunk, either text or binary.
        metadata (dict[str, Any]): Additional metadata associated with the chunk. Defaults to an empty dictionary.
        score (float | None): Similarity score of the chunk (if available). Defaults to None.
    """

    id: str = Field(default_factory=lambda: str(uuid4()))
    content: str | bytes
    metadata: dict[str, Any] = Field(default_factory=dict)
    score: float | None = None

    @field_validator("content")
    @classmethod
    def validate_content(cls, value: str | bytes) -> str | bytes:
        """Validate the content of the Chunk.

        This is a class method required by Pydantic validators. As such, it follows its signature and conventions.

        Args:
            value (str | bytes): The content to validate.

        Returns:
            str | bytes: The validated content.

        Raises:
            ValueError: If the content is empty or not a string or bytes.
        """
        if not value:
            raise ValueError("Content must not be empty")
        if not isinstance(value, (str, bytes)):
            raise ValueError("Content must be either str or bytes")
        return value

    def is_text(self) -> bool:
        """Check if the content is text.

        Returns:
            bool: True if the content is text, False otherwise.
        """
        return isinstance(self.content, str)

    def is_binary(self) -> bool:
        """Check if the content is binary.

        Returns:
            bool: True if the content is binary, False otherwise.
        """
        return isinstance(self.content, bytes)

    def _format_value(self, value: Any) -> Any:
        """Format a value for string representation.

        Args:
            value (Any): The value to format.

        Returns:
            Any: The formatted value.
        """
        if isinstance(value, str):
            return f"{value[:MAX_PREVIEW_LENGTH]}{'...' if len(value) > MAX_PREVIEW_LENGTH else ''}"

        if isinstance(value, bytes):
            return "(Binary content)"

        if isinstance(value, (list, tuple)):
            return _TruncatedIterable(value)

        if isinstance(value, dict):
            return {k: self._format_value(v) for k, v in value.items()}

        return value

    def __repr__(self) -> str:
        """Return a string representation of the Chunk.

        Returns:
            str: The string representation of the Chunk.
        """
        content_preview = self._format_value(self.content)
        formatted_metadata = self._format_value(self.metadata)

        return (
            f"Chunk(id={self.id}, "
            f"content={content_preview}, "
            f"metadata={formatted_metadata}, "
            f"score={self.score})"
        )
