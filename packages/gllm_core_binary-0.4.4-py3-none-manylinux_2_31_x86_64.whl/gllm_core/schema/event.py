"""Defines the Event schema, which represents an event emitted by the system.

Authors:
    Dimitrij Ray (dimitrij.ray@gdplabs.id)
    Henry Wicaksono (henry.wicaksono@gdplabs.id)

References:
    NONE
"""

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field, field_serializer

from gllm_core.constants import EventLevel, EventType


class Event(BaseModel):
    """A data class to store an event attributes.

    Attributes:
        id (str): The ID of the event. Defaults to None.
        value (str | dict[str, Any]): The value of the event. Defaults to an empty string.
        level (EventLevel): The severity level of the event. Defaults to EventLevel.INFO.
        type (str): The type of the event. Defaults to EventType.RESPONSE.
        timestamp (datetime): The timestamp of the event. Defaults to the current timestamp.
        metadata (dict[str, Any]): The metadata of the event. Defaults to an empty dictionary.
    """

    id: str | None = None
    value: str | dict[str, Any] = ""
    level: EventLevel = EventLevel.INFO
    type: str = EventType.RESPONSE.value
    timestamp: datetime = Field(default_factory=datetime.now)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_serializer("level")
    def serialize_level(self, level: EventLevel) -> str:
        """Serializes an EventLevel object into its string representation.

        This method serializes the given EventLevel object by returning its name as a string.

        Args:
            level (EventLevel): The EventLevel object to be serialized.

        Returns:
            str: The name of the EventLevel object.
        """
        return level.name
