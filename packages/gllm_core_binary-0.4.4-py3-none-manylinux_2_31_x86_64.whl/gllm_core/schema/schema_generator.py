"""Utility for generating Pydantic models from component methods.

Authors:
    Dimitrij Ray (dimitrij.ray@gdplabs.id)

References:
    NONE
"""

from __future__ import annotations

import inspect
from typing import Any, Callable, get_type_hints

from pydantic import BaseModel, ConfigDict, create_model

from gllm_core.utils.analyzer import analyze_method


def generate_params_model(method: Callable, class_name: str) -> type[BaseModel]:
    """Generate a Pydantic model representing a component method signature.

    The generated class is named `{class_name}Params` and contains one field for
    every parameter in `method`. The first `self` parameter is ignored, `*args` are
    skipped entirely, and `**kwargs` trigger `extra="allow"` to permit arbitrary
    keyword arguments at runtime.

    For legacy `_run` methods with only `**kwargs`, this function will use
    RunAnalyzer to infer parameters from the method body usage patterns.

    Args:
        method (Callable): Method whose signature should be represented.
        class_name (str): Component class name used to derive the generated model name.

    Returns:
        type[BaseModel]: A Pydantic `BaseModel` subclass describing the method's
            parameters.

    Example:
        ```python
        class_name = "TextProcessor"

        def process(self, text: str, count: int = 5) -> str:
            return text * count

        Model = generate_params_model(process, class_name)
        assert Model.__name__ == "TextProcessorParams"
        assert Model(text="hello", count=2).model_dump() == {"text": "hello", "count": 2}
        ```
    """
    signature = inspect.signature(method)

    non_self_params = [param for param in signature.parameters.values() if param.name != "self"]

    if len(non_self_params) == 1 and non_self_params[0].kind == inspect.Parameter.VAR_KEYWORD:
        return _generate_from_analyzer(method, class_name)

    return _generate_from_signature(method, class_name)


def _generate_from_signature(method: Callable, class_name: str) -> type[BaseModel]:
    """Generate model using method signature analysis.

    This function is used for modern methods with explicit parameter annotations.

    Args:
        method (Callable): Method whose signature should be represented.
        class_name (str): Component class name used to derive the generated model name.

    Returns:
        type[BaseModel]: A Pydantic `BaseModel` subclass describing the method's
            parameters.
    """
    signature = inspect.signature(method)

    try:
        type_hints = get_type_hints(method)
    except Exception:  # pragma: no cover - defensive fallback
        type_hints = {}

    fields: dict[str, tuple[type[Any], Any]] = {}
    extra_setting = "forbid"

    for param_name, param in signature.parameters.items():
        if param_name == "self":
            continue
        if param.kind == inspect.Parameter.VAR_POSITIONAL:
            continue
        if param.kind == inspect.Parameter.VAR_KEYWORD:
            extra_setting = "allow"
            continue

        annotation = type_hints.get(param_name, Any)
        if param.default is inspect.Parameter.empty:
            fields[param_name] = (annotation, ...)
        else:
            fields[param_name] = (annotation, param.default)

    model_name = f"{class_name}Params"
    return create_model(  # type: ignore[call-overload]
        model_name,
        __config__=ConfigDict(extra=extra_setting, arbitrary_types_allowed=True),
        **fields,
    )


def _generate_from_analyzer(method: Callable, class_name: str) -> type[BaseModel]:
    """Generate model using RunAnalyzer to infer parameters from method body.

    This is used for legacy `_run` methods that only have `**kwargs` in their signature
    but use specific parameters within the method body.

    Args:
        method (Callable): Method whose signature should be represented.
        class_name (str): Component class name used to derive the generated model name.

    Returns:
        type[BaseModel]: A Pydantic `BaseModel` subclass describing the method's
            parameters.
    """

    class MockClass:
        pass

    MockClass._run = method
    config_dict = ConfigDict(extra="allow", arbitrary_types_allowed=True)

    try:
        profile = analyze_method(MockClass, method)

        fields: dict[str, tuple[type[Any], Any]] = {}

        for param_name in profile.arg_usages.required:
            fields[param_name] = (Any, ...)

        for param_name in profile.arg_usages.optional:
            fields[param_name] = (Any, None)

        model_name = f"{class_name}Params"
        return create_model(  # type: ignore[call-overload]
            model_name,
            __config__=config_dict,
            **fields,
        )
    except Exception:
        model_name = f"{class_name}Params"
        return create_model(  # type: ignore[call-overload]
            model_name,
            __config__=config_dict,
        )
