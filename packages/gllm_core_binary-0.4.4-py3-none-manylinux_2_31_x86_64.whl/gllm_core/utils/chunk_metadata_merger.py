"""Defines a helper class to merge metadata from multiple chunks.

Authors:
    Henry Wicaksono (henry.wicaksono@gdplabs.id)

References:
    NONE
"""

from typing import Any, Callable

from gllm_core.constants import DefaultChunkMetadata
from gllm_core.utils.merger_method import MergerMethod


class ChunkMetadataMerger:
    """A helper class to merge metadata from multiple chunks.

    Attributes:
        merger_func_map (dict[str, Callable[[list[Any]], Any]]): A mapping of metadata keys to merger functions.
        default_merger_func (Callable[[list[Any]], Any]): The default merger function for metadata keys that are not
            present in the merger_func_map.
        retained_keys (set[str] | None): The keys that should be retained in the merged metadata.
            If None, all intersection keys are retained.
    """

    def __init__(
        self,
        merger_func_map: dict[str, Callable[[list[Any]], Any]] | None = None,
        default_merger_func: Callable[[list[Any]], Any] | None = None,
        retained_keys: set[str] | None = None,
    ):
        """Initializes a new instance of the ChunkMetadataMerger class.

        Args:
            merger_func_map (dict[str, Callable[[list[Any]], Any]] | None, optional): A mapping of metadata keys to
                merger functions. Defaults to None, in which case a default merger map is used. The default merger map:
                1. Picks the first value of the PREV_CHUNK_ID key.
                2. Picks the last value of the NEXT_CHUNK_ID key.
            default_merger_func (Callable[[list[Any]], Any] | None, optional): The default merger for metadata keys that
                are not present in the merger_func_map. Defaults to None, in which case a default merger that picks the
                first value is used.
            retained_keys (set[str] | None, optional): The keys that should be retained in the merged metadata. Defaults
                to None, in which case all intersection keys are retained.
        """
        self.merger_map = merger_func_map or {
            DefaultChunkMetadata.PREV_CHUNK_ID: MergerMethod.pick_first,
            DefaultChunkMetadata.NEXT_CHUNK_ID: MergerMethod.pick_last,
        }
        self.default_merger = default_merger_func or MergerMethod.pick_first
        self.retained_keys = retained_keys

    def merge(self, metadatas: list[dict[str, Any]]) -> dict[str, Any]:
        """Merges metadata from multiple chunks.

        Args:
            metadatas (list[dict[str, Any]]): The metadata to merge.

        Returns:
            dict[str, Any]: The merged metadata.
        """
        if not metadatas:
            return {}

        metadata_keys = self._get_retained_keys(metadatas)

        merged_metadata = {}
        for key in metadata_keys:
            metadata_values = [metadata[key] for metadata in metadatas]

            if key in self.merger_map:
                merged_value = self.merger_map[key](metadata_values)
            else:
                merged_value = self.default_merger(metadata_values)

            merged_metadata[key] = merged_value

        return merged_metadata

    def _get_retained_keys(self, metadatas: list[dict[str, Any]]) -> set[str]:
        """Gets the set of retained keys.

        This method ensures that the retained keys are present in all metadata dictionaries.

        Args:
            metadatas (list[dict[str, Any]]): The metadata to parse.

        Returns:
            set[str]: The set of retained keys.

        Raises:
            ValueError: If any of the retained keys are missing from any of the metadata dictionaries.
        """
        common_keys = set.intersection(*(set(metadata.keys()) for metadata in metadatas))

        retained_keys = self.retained_keys or common_keys

        missing_keys = retained_keys - common_keys
        if missing_keys:
            raise ValueError(f"The following keys are missing in the metadata: {missing_keys}")

        return retained_keys
