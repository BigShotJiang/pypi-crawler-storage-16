"""Concurrency utilities for bridging sync and async code.

This module provides two primary helpers:

1. asyncify: Wrap a synchronous function so it can be awaited in async code
   by offloading it to a worker thread using AnyIO.
2. syncify: Wrap an asynchronous function so it can be called from synchronous
   code. By default, this uses a shared AnyIO BlockingPortal running in a
   background thread.

Usage:
    ```python
    from gllm_core.utils.concurrency import asyncify, syncify

    # Asyncify a sync function
    async_op = asyncify(blocking_fn)
    result = await async_op(arg1, arg2)

    # Syncify an async function
    sync_op = syncify(async_fn)
    result = sync_op(arg1, arg2)
    ```

Notes:
1. For asyncify: Cancelling an await of an asyncified sync function cancels the awaiter, but
   the underlying thread cannot be forcibly interrupted. The function continues to run until it returns.
2. For syncify: A shared default BlockingPortal is lazily created on first use and shut down
   at process exit.

Authors:
    Dimitrij Ray (dimitrij.ray@gdplabs.id)

References:
    NONE
"""

from __future__ import annotations

import atexit
import threading
from typing import Awaitable, Callable, ContextManager, ParamSpec, TypeVar

import anyio
from anyio.abc import BlockingPortal
from anyio.from_thread import start_blocking_portal

P = ParamSpec("P")
R = TypeVar("R")


class _DefaultPortalManager:
    """Lazily manages a process-wide AnyIO BlockingPortal.

    The portal runs an event loop in a background thread started via
    anyio.from_thread.start_blocking_portal(). It is created on first access and stopped
    automatically at interpreter shutdown.
    """

    _lock: threading.Lock
    _portal: BlockingPortal | None
    _cm: ContextManager[BlockingPortal] | None

    def __init__(self) -> None:
        """Initialize the default portal manager."""
        self._lock = threading.Lock()
        self._portal = None
        self._cm = None

    def get(self) -> BlockingPortal:
        """Return the shared BlockingPortal, creating it if necessary.

        This method is thread-safe: concurrent callers will see the same portal.

        Returns:
            BlockingPortal: The shared default portal.
        """
        with self._lock:
            portal = self._portal
            if portal is None:
                cm = start_blocking_portal()
                portal = cm.__enter__()

                atexit.register(cm.__exit__, None, None, None)

                self._cm = cm
                self._portal = portal

            return portal


_default_portal_mgr = _DefaultPortalManager()


def get_default_portal() -> BlockingPortal:
    """Return the shared default BlockingPortal.

    Returns:
        BlockingPortal: A process-wide portal running on a background thread.
    """
    return _default_portal_mgr.get()


def asyncify(
    func: Callable[P, R], *, cancellable: bool = False, limiter: anyio.CapacityLimiter | None = None
) -> Callable[P, Awaitable[R]]:
    """Wrap a sync function into an awaitable callable using a worker thread.

    Args:
        func (Callable[P, R]): Synchronous function to wrap.
        cancellable (bool, optional): If True, allow cancellation of the awaiter while running in a
            worker thread. Defaults to False.
        limiter (anyio.CapacityLimiter | None, optional): Capacity limiter to throttle concurrent
            thread usage. Defaults to None.

    Returns:
        Callable[P, Awaitable[R]]: An async function that when awaited will execute `func` in a
        worker thread and return its result.

    Usage:
        ```python
        async def handler() -> int:
            wrapped = asyncify(blocking_func)
            return await wrapped(1, 2)
        ```
    """

    async def _wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
        return await anyio.to_thread.run_sync(lambda: func(*args, **kwargs), abandon_on_cancel=cancellable, limiter=limiter)

    return _wrapper


def syncify(
    async_func: Callable[P, Awaitable[R]],
    *,
    portal: BlockingPortal | None = None,
) -> Callable[P, R]:
    """Wrap an async function to be callable from synchronous code.

    Lifecycle and portals:
    1. This helper uses an already running AnyIO `BlockingPortal` to execute the coroutine.
    2. If `portal` is not provided, a process-wide shared portal is used. Its lifecycle is
      managed internally: it is created lazily on first use and shut down automatically at process exit.
    3. If you provide a `portal`, you are expected to manage its lifecycle, typically with a
      context manager. This is recommended when making many calls in a bounded scope since it
      avoids per-call startup costs while allowing deterministic teardown.

    Args:
        async_func (Callable[P, Awaitable[R]]): Asynchronous function to wrap.
        portal (BlockingPortal | None, optional): Portal to use for calling the async function
            from sync code. Defaults to None, in which case a shared default portal is used.

    Returns:
        Callable[P, R]: A synchronous function that runs the coroutine and returns its result.

    Usage:
        ```python
        # Use the default shared portal (most convenient)
        def do_work(x: int) -> int:
            sync_call = syncify(async_func)
            return sync_call(x)
        ```

        ```python
        # Reuse a scoped portal for multiple calls (deterministic lifecycle)
        from anyio.from_thread import start_blocking_portal

        with start_blocking_portal() as portal:
            sync_call = syncify(async_func, portal=portal)
            a = sync_call(1)
            b = sync_call(2)
        ```

    Notes:
        Creating a brand-new portal per call is discouraged due to the overhead of spinning up
        and tearing down a background event loop/thread. Prefer the shared portal or a scoped
        portal reused for a batch of calls.
    """

    def _wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
        p: BlockingPortal = portal if portal is not None else get_default_portal()
        return p.call(lambda: async_func(*args, **kwargs))

    return _wrapper
