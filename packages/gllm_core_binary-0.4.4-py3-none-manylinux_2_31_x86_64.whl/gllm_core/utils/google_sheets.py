"""Defines functions to interact with Google Sheets API.

Authors:
    Henry Wicaksono (henry.wicaksono@gdplabs.id)

References:
    [1] https://github.com/GDP-ADMIN/gen-ai-veriwise/blob/main/main/backend/module/google_sheets/auth.py
"""

import gspread
from google.oauth2 import service_account
from gspread import Client, Spreadsheet, Worksheet


def load_gsheets(
    client_email: str,
    private_key: str,
    sheet_id: str,
    worksheet_id: str,
) -> list[dict[str, str]]:
    """Loads data from a Google Sheets worksheet.

    This function retrieves data from a Google Sheets worksheet using service account credentials.
    It authorizes the client, selects the specified worksheet, and reads the worksheet data.
    The first row of the worksheet will be treated as the column names.

    Args:
        client_email (str): The client email associated with the service account.
        private_key (str): The private key used for authentication.
        sheet_id (str): The ID of the Google Sheet.
        worksheet_id (str): The ID of the worksheet within the Google Sheet.

    Returns:
        list[dict[str, str]]: A list of dictionaries containing the Google Sheets content.
    """
    account_info = _get_account_info(client_email, private_key)
    client = _get_client(account_info)
    worksheet = _get_worksheet(client, sheet_id, worksheet_id)
    return worksheet.get_all_records()


def _get_account_info(client_email: str, private_key: str) -> dict[str, str]:
    """Generates a dictionary with Google Sheets API authentication information.

    This function returns a dictionary containing authentication details required for a Google Sheets API service
    account.

    Args:
        client_email (str): The client email associated with the service account.
        private_key (str): The private key used for authentication.

    Returns:
        dict[str, str]: A dictionary containing the authentication details for the Google Sheets API.
    """
    return {
        "type": "service_account",
        "private_key": private_key,
        "client_email": client_email,
        "client_id": "https://www.googleapis.com/auth/spreadsheets",
        "token_uri": "https://oauth2.googleapis.com/token",
    }


def _get_client(info: dict[str, str]) -> Client:
    """Gets a Google Sheets client with the provided credentials and scopes.

    This function initializes a Google Sheets client using the provided service account credentials
    (info) and OAuth2 scopes. It authorizes the client and returns it for further use in Google Sheets
    interactions.

    Args:
        info (dict[str, str]): Service account information for authentication.

    Returns:
        Client: An authorized Google Sheets client.
    """
    scopes = ["https://www.googleapis.com/auth/spreadsheets"]
    credentials = service_account.Credentials.from_service_account_info(info=info, scopes=scopes)
    client = gspread.authorize(credentials)
    return client


def _get_sheet(client: Client, sheet_id: str) -> Spreadsheet:
    """Gets a Google Sheets spreadsheet by its ID using a Google Sheets client.

    This function opens the spreadsheet using Sheet ID and returns the corresponding Spreadsheet object.

    Args:
      client (Client): An authorized Google Sheets client.
      sheet_id (str): The ID of the Google Sheets spreadsheet.

    Returns:
      Spreadsheet: The Google Sheets spreadsheet as a Spreadsheet object.
    """
    sheet = client.open_by_key(sheet_id)
    return sheet


def _get_worksheet(client: Client, sheet_id: str, worksheet_id: str) -> Worksheet:
    """Gets a specific worksheet from a Google Sheets spreadsheet using a Google Sheets client and worksheet ID.

    This function first retrieves the target Google Sheets spreadsheet using the provided client and sheet ID.
    Then, it fetches the desired worksheet within the spreadsheet based on the worksheet ID and returns it.

    Args:
        client (Client): An authorized Google Sheets client.
        sheet_id (str): The ID of the Google Sheets spreadsheet.
        worksheet_id (str): The ID of the worksheet to retrieve.

    Returns:
        Worksheet: The specified worksheet as a Worksheet object.
    """
    sheet = _get_sheet(client, sheet_id)
    worksheet = sheet.get_worksheet_by_id(int(worksheet_id))
    return worksheet
