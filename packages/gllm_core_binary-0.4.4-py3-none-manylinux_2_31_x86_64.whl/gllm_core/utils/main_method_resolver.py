"""Main method resolver for Component classes.

This module provides the MainMethodResolver class which encapsulates the logic
for resolving the main entrypoint method for Component subclasses.

Authors:
    Dimitrij Ray (dimitrij.ray@gdplabs.id)

References:
    NONE
"""

from abc import ABC
from typing import Callable

from gllm_core.utils.logger_manager import LoggerManager


class MainMethodResolver:
    """Resolves the main entrypoint method for Component classes.

    This resolver implements the precedence rules for determining which method
    should be used as the main entrypoint:
    1. Method decorated with @main in the most derived class.
    2. Method named by __main_method__ property.
    3. _run method (with deprecation warning).

    Attributes:
        cls (type): The Component class to resolve the main method for.
    """

    def __init__(self, component_class: type):
        """Initialize the resolver with a Component class.

        Args:
            component_class (type): The Component class to resolve the main method for.
        """
        self.cls = component_class
        self._logger = LoggerManager().get_logger(f"MainMethodResolver.{component_class.__name__}")

    @staticmethod
    def validate_class(component_class: type) -> None:
        """Validate main method configuration at class definition time.

        This performs early validation that can be done when a Component subclass
        is defined, before any instances are created or methods are called.

        Validations performed:
        1. Check that __main_method__ property points to an existing method
        2. Check that only one @main decorator is used within the same class

        Note: Multiple inheritance conflicts are intentionally NOT checked here,
        as they are deferred to runtime (get_main()) to allow class definition
        to succeed.

        Args:
            component_class (type): The Component class to validate.

        Raises:
            AttributeError: If __main_method__ refers to a non-existent method.
            TypeError: If multiple methods are decorated with @main in the same class.
        """
        if (method_name := getattr(component_class, "__main_method__", None)) is not None:
            if not hasattr(component_class, method_name):
                raise AttributeError(
                    f"Method {method_name!r} specified in __main_method__ does not exist in {component_class.__name__}"
                )

        main_methods = []
        for name, method in component_class.__dict__.items():
            if callable(method) and hasattr(method, "__is_main__"):
                main_methods.append(name)

        if len(main_methods) > 1:
            raise TypeError(f"Multiple main methods defined in {component_class.__name__}: {', '.join(main_methods)}")

    def resolve(self) -> Callable | None:
        """Resolve the main method following precedence rules.

        Returns:
            Callable | None: The resolved main method, or None if not found.

        Raises:
            TypeError: If conflicting main methods are inherited from multiple ancestors.
        """
        if decorated := self._resolve_decorated():
            self._warn_if_redundant_property()
            return decorated

        if property_method := self._resolve_property():
            return property_method

        return self._resolve_legacy()

    def _resolve_decorated(self) -> Callable | None:
        """Find the most-derived @main decorated method in the MRO (method resolution order).

        Returns:
            Callable | None: The decorated main method, or None if not found.

        Raises:
            TypeError: If conflicting main methods are inherited from multiple ancestors.
        """
        classes_with_main = []
        for base in self.cls.__mro__:
            if base.__name__ == "Component" or base is ABC:
                continue

            main_method_name = next(
                (name for name, method in base.__dict__.items() if callable(method) and hasattr(method, "__is_main__")),
                None,
            )

            if main_method_name:
                classes_with_main.append((base, main_method_name))

        if not classes_with_main:
            return None

        most_derived_class, method_name = classes_with_main[0]
        actual_method = getattr(self.cls, method_name)

        self._validate_no_decorator_conflicts(classes_with_main, most_derived_class, actual_method)

        return actual_method

    def _validate_no_decorator_conflicts(
        self, classes_with_main: list[tuple[type, str]], most_derived_class: type, actual_method: Callable
    ) -> None:
        """Validate that there are no conflicting @main decorators in multiple inheritance.

        This method checks for conflicts only when multiple classes in the inheritance hierarchy have @main decorated
        methods. It allows intentional overrides (when the most derived class defines its own @main method) but prevents
        conflicts from multiple inheritance where different ancestors define different @main methods.

        Args:
            classes_with_main (list[tuple[type, str]]): List of (class, method_name) tuples for classes with @main.
            most_derived_class (type): The most derived class in the hierarchy with @main.
            actual_method (Callable): The resolved method from the most derived class.

        Raises:
            TypeError: If conflicting main methods are inherited from multiple ancestors and the most derived class
                is not the current class (indicating a true conflict rather than an intentional override).
        """
        if len(classes_with_main) > 1 and most_derived_class is not self.cls:
            for _, name in classes_with_main[1:]:
                other_method = getattr(self.cls, name)
                if other_method is not actual_method:
                    raise TypeError(
                        f"Conflicting main methods inherited from multiple ancestors in {self.cls.__name__}. "
                        "Please explicitly override with @main decorator."
                    )

    def _resolve_property(self) -> Callable | None:
        """Find method via __main_method__ property.

        Returns:
            Callable | None: The method named by __main_method__, or None if not found.
        """
        if hasattr(self.cls, "__main_method__") and self.cls.__main_method__ is not None:
            method_name = self.cls.__main_method__
            return getattr(self.cls, method_name, None)

    def _resolve_legacy(self) -> Callable | None:
        """Fall back to _run method with deprecation warning.

        Returns:
            Callable | None: The _run method, or None if not found.
        """
        if hasattr(self.cls, "_run"):
            self._logger.warning(
                f"Using legacy _run method for {self.cls.__name__}. "
                f"Consider using @main decorator to explicitly declare the main entrypoint.",
                stacklevel=4,
            )
            return self.cls._run

    def _warn_if_redundant_property(self) -> None:
        """Emit warning if both @main decorator and __main_method__ are defined."""
        if self.cls.__dict__.get("__main_method__") is not None:
            self._logger.warning(
                f"Both @main decorator and __main_method__ property are defined in {self.cls.__name__}. "
                "The @main decorator takes precedence. This redundant configuration should be resolved.",
                stacklevel=4,
            )
