"""Defines a collection of merger methods.

Authors:
    Henry Wicaksono (henry.wicaksono@gdplabs.id)

References:
    NONE
"""

import os
from typing import Any, Callable


class MergerMethod:
    """A collection of merger methods."""

    @staticmethod
    def concatenate(delimiter: str = "-") -> Callable[[list[Any]], str]:
        """Creates a function that concatenates a list of values with a delimiter.

        Args:
            delimiter (str, optional): The delimiter to use when concatenating the values. Defaults to "-".

        Returns:
            Callable[[list[Any]], str]: A function that concatenates a list of values with the delimiter.
        """

        def _concat_with_delimiter(values: list[Any]) -> str:
            return delimiter.join([str(value) for value in values])

        return _concat_with_delimiter

    @staticmethod
    def pick_first(values: list[Any]) -> Any:
        """Picks the first value from a list of values.

        Args:
            values (list[Any]): The values to pick from.

        Returns:
            Any: The first value from the list.
        """
        return values[0] if values else None

    @staticmethod
    def pick_last(values: list[Any]) -> Any:
        """Picks the last value from a list of values.

        Args:
            values (list[Any]): The values to pick from.

        Returns:
            Any: The last value from the list.
        """
        return values[-1] if values else None

    @staticmethod
    def merge_overlapping_strings(delimiter: str = "\n") -> Callable[[list[str]], str]:
        r"""Creates a function that merges a list of strings, handling common prefixes and overlaps.

        The created function will:
        - Identify and remove any common prefix shared by the strings.
        - Process each pair of adjacent strings to remove overlapping strings.
        - Join the cleaned strings together, including the common prefix at the beginning.

        Args:
            delimiter (str, optional): The delimiter to use when merging the values. Defaults to "\n".

        Returns:
            Callable[[list[str]], str]: A function that merges a list of strings, handling common prefixes and overlaps.
        """

        def _merge_overlapping_strings(values: list[str]) -> str:
            values = [str(value) for value in values]
            common_prefix = MergerMethod._get_common_prefix(values)
            values = [string[len(common_prefix) :] for string in values]

            for idx in range(len(values) - 1):
                overlap = MergerMethod._find_overlap(values[idx], values[idx + 1])
                values[idx] = values[idx].replace(overlap, "")

            values.insert(0, common_prefix)

            return delimiter.join([string.strip() for string in values if string.strip()])

        return _merge_overlapping_strings

    @staticmethod
    def _get_common_prefix(strings: list[str]) -> str:
        """Identifies the common prefix shared by a list of strings.

        This method uses `os.path.commonprefix` to find the common prefix shared by all strings in the provided
        `strings`. If the common prefix does not end with a newline, the method removes the last partial line to
        ensure the prefix ends at a full line break.

        Args:
            strings (list[str]): A list of strings to find the common prefix.

        Returns:
            str: The common prefix shared by all strings, ending at the last full line.
        """
        common_prefix = os.path.commonprefix(strings)
        last_newline_index = common_prefix.rfind("\n")

        if last_newline_index != -1:
            return common_prefix[:last_newline_index]

        return ""

    @staticmethod
    def _find_overlap(first_string: str, second_string: str) -> str:
        """Finds the overlapping portion between two strings.

        This method compares the end of the `first_string` with the beginning of the `second_string` to find the
        longest overlapping substring. It returns the overlap if found, otherwise returns an empty string.

        Args:
            first_string (str): The first string to compare.
            second_string (str): The second string to compare.

        Returns:
            str: The overlapping substring between the two strings, or an empty string if no overlap is found.
        """
        max_overlap_len = min(len(first_string), len(second_string))

        for i in range(max_overlap_len, 0, -1):
            if first_string[-i:] == second_string[:i]:
                return first_string[-i:]

        return ""
