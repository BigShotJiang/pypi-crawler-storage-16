"""Defines retry and timeout utilities.

Authors:
    Henry Wicaksono (henry.wicaksono@gdplabs.id)

References:
    NONE
"""

import asyncio
import functools
import inspect
import random
from typing import Any, Callable, TypeVar, overload

from pydantic import BaseModel, Field, model_validator

from gllm_core.utils import LoggerManager
from gllm_core.utils.concurrency import syncify

logger = LoggerManager().get_logger(__name__)

T = TypeVar("T")

BASE_EXPONENTIAL_BACKOFF = 2.0


class RetryConfig(BaseModel):
    """Configuration for retry behavior.

    Attributes:
        max_retries (int): Maximum number of retry attempts.
        base_delay (float): Base delay in seconds between retries.
        max_delay (float): Maximum delay in seconds between retries.
        jitter (bool): Whether to add random jitter to delays.
        timeout (float | None): Overall timeout in seconds for the entire operation. If None, timeout is disabled.
        retry_on_exceptions (tuple[type[Exception], ...]): Tuple of exception types to retry on.
    """

    max_retries: int = Field(default=0, ge=0)
    base_delay: float = Field(default=1.0, gt=0.0)
    max_delay: float = Field(default=10.0, gt=0.0)
    jitter: bool = Field(default=True)
    timeout: float | None = Field(default=None, gt=0.0)
    retry_on_exceptions: tuple[type[Exception], ...] = Field(default=(Exception,))

    @model_validator(mode="after")
    def validate_delay_constraints(self) -> "RetryConfig":
        """Validates that max_delay is greater than or equal to base_delay.

        Returns:
            RetryConfig: The validated configuration.

        Raises:
            ValueError: If max_delay is less than base_delay.
        """
        if self.timeout == 0:
            logger.warning(
                "Setting timeout=0.0 is deprecated and will raise an error in v0.4. "
                "Please use timeout=None instead to disable timeout."
            )
            self.timeout = None

        if self.max_delay < self.base_delay:
            raise ValueError("The 'max_delay' parameter must be greater than or equal to 'base_delay'.")

        return self


def _calculate_delay(attempt: int, config: RetryConfig) -> float:
    """Calculates the delay for the next retry attempt.

    Args:
        attempt (int): The current attempt number (0-based).
        config (RetryConfig): The retry configuration.

    Returns:
        float: The delay in seconds.
    """
    delay = config.base_delay * (BASE_EXPONENTIAL_BACKOFF**attempt)

    if config.jitter:
        jitter_factor = random.uniform(0, 0.25)
        delay += delay * jitter_factor

    return min(delay, config.max_delay)


async def _retry_async(
    func: Callable[..., Any],
    *args: Any,
    retry_config: RetryConfig | None = None,
    **kwargs: Any,
) -> T:
    """Executes a function with retry logic and exponential backoff.

    This function executes the provided function with retry logic. It will first try to execute the function once.
    If the function raises an exception that matches the retry_on_exceptions, it will retry up to max_retries times
    with exponential backoff. Therefore, the max number of attempts is max_retries + 1. If provided, the timeout
    applies to the entire retry operation, including all attempts and delays.

    Example:
        If you set timeout=10.0 and max_retries=3, the entire retry operation (including all attempts
        and delays) will timeout after 10 seconds, not 10 seconds per attempt.

    Args:
        func (Callable[..., Any]): The function to execute.
        *args (Any): Positional arguments to pass to the function.
        retry_config (RetryConfig | None, optional): Retry configuration. If None, uses default config.
            Defaults to None.
        **kwargs (Any): Keyword arguments to pass to the function.

    Returns:
        T: The result of the function execution.

    Raises:
        Exception: The last exception raised by the function if all retries are exhausted.
        asyncio.TimeoutError: If the overall timeout is exceeded.
    """
    config = retry_config or RetryConfig()

    async def attempt_loop() -> T:
        max_retries = config.max_retries + 1

        for attempt in range(max_retries):
            try:
                result = func(*args, **kwargs)
                if inspect.isawaitable(result):
                    return await result
                return result

            except asyncio.TimeoutError:
                raise

            except config.retry_on_exceptions as exc:
                if attempt == config.max_retries:
                    logger.error(f"Function {func.__name__} failed after {max_retries} attempts. Last error: {exc}")
                    raise exc from None

                delay = _calculate_delay(attempt, config)
                logger.warning(
                    f"Function {func.__name__} failed on attempt {attempt + 1}/{max_retries}. "
                    f"Retrying in {delay:.2f} seconds. Error: {exc}"
                )
                await asyncio.sleep(delay)

    if config.timeout is not None:
        return await asyncio.wait_for(attempt_loop(), timeout=config.timeout)

    return await attempt_loop()


@overload
async def retry(
    func: Callable[..., Any],
    *args: Any,
    retry_config: RetryConfig | None = None,
    **kwargs: Any,
) -> T: ...


@overload
def retry(config: RetryConfig | None = None) -> Callable[[Callable[..., Any]], Callable[..., Any]]: ...


def retry(
    func_or_config: Callable[..., Any] | RetryConfig | None = None,
    *args: Any,
    retry_config: RetryConfig | None = None,
    **kwargs: Any,
) -> T | Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Executes a function with retry logic or creates a retry decorator.

    This function supports two usage patterns:
    1. Direct function execution: await retry(func, *args, retry_config=config, **kwargs)
    2. Decorator factory: @retry() or @retry(config)

    Args:
        func_or_config (Callable[..., Any] | RetryConfig | None, optional): Either a function to execute or a
            RetryConfig for decorator usage. Defaults to None.
        *args (Any): Positional arguments (only used in direct execution mode).
        retry_config (RetryConfig | None, optional): Retry configuration (only used in direct execution mode).
            Defaults to None, in which case no retry nor timeout is applied.
        **kwargs (Any): Keyword arguments (only used in direct execution mode).

    Returns:
        T | Callable[[Callable[..., Any]], Callable[..., Any]]: Either the result of function execution or
            a decorator function.

    Raises:
        Exception: The last exception raised by the function if all retries are exhausted.
        asyncio.TimeoutError: If the overall timeout is exceeded.

    Examples:
        # Direct function execution
        ```python
        result = await retry(my_function, arg1, arg2, retry_config=config)
        ```

        # Decorator usage - parameterless
        ```python
        @retry()
        async def my_async_function():
            # Use default settings, in which case no retry nor timeout is applied.
            pass
        ```

        # Decorator usage - with custom configuration
        ```python
        @retry(RetryConfig(max_retries=3, timeout=120))
        async def my_function():
            # Will retry up to 3 times with 0.5s base delay
            pass
        ```

        # Decorator on sync functions
        ```python
        @retry()
        def my_sync_function():
            # Works with sync functions too
            return "success"
        ```

        # Decorator on class methods
        ```python
        class MyService:
            @retry(RetryConfig(max_retries=2))
            async def get_data(self, id: str):
                return {"id": id, "data": "value"}
        ```
    """
    if callable(func_or_config) and not isinstance(func_or_config, RetryConfig):
        func = func_or_config

        async def async_wrapper() -> T:
            return await _retry_async(func, *args, retry_config=retry_config, **kwargs)

        return async_wrapper()

    config = func_or_config

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        if asyncio.iscoroutinefunction(func):

            @functools.wraps(func)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                return await _retry_async(func, *args, retry_config=config, **kwargs)

            return async_wrapper

        @functools.wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            sync_retry = syncify(lambda: _retry_async(func, *args, retry_config=config, **kwargs))
            return sync_retry()

        return sync_wrapper

    return decorator
