"""Defines validation utilities.

Authors:
    Henry Wicaksono (henry.wicaksono@gdplabs.id)

References:
    NONE
"""

from enum import StrEnum


def validate_string_enum(enum_type: type[StrEnum], value: str) -> None:
    """Validates that the provided value is a valid string enum value.

    Args:
        enum_type (type[StrEnum]): The type of the string enum.
        value (str): The value to validate.

    Raises:
        ValueError: If the provided value is not a valid string enum value.
    """
    valid_values = [item.value for item in enum_type]
    if value not in valid_values:
        error_message = f"Invalid {enum_type.__name__}: {value!r}. Valid values: {valid_values}."
        raise ValueError(error_message) from None
