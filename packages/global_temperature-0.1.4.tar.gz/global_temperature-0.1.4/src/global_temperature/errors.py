class NoNearbyPointError(Exception):
    """Custom exception raised for errors when there is no nearest point."""
    pass