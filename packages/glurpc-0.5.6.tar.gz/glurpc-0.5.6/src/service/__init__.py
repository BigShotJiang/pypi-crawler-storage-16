registry = {
    "glurpc_combined": {
        "grpc": 7003,
        "rest": 8000,
    },
}

