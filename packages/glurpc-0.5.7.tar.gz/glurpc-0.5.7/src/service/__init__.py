registry = {
    "glurpc_service": {
        "grpc": 7003,
        "rest": 8000,
    },
    "combined_service": {
        "grpc": 7003,
        "rest": 8000,
    }
}

