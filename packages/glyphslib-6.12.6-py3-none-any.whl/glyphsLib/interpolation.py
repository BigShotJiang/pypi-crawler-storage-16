from glyphsLib.builder.instances import apply_instance_data, apply_instance_data_to_ufo

__all__ = ["apply_instance_data", "apply_instance_data_to_ufo"]
