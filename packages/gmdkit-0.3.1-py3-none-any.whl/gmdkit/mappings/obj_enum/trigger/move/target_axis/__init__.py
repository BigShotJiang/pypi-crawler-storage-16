NONE = 0
X = 1
Y = 2