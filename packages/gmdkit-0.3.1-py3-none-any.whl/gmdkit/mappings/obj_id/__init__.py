LEVEL_START = 0
TEXT = 914
ITEM_LABEL = 1615
PARTICLE_OBJECT = 2065
from . import portal
from . import trigger
from . import pad
from . import orb
from . import deprecated
from . import collectible
from . import speed
from . import modifier
