from websocket import create_connection


class LiveEditor:
    
    pass