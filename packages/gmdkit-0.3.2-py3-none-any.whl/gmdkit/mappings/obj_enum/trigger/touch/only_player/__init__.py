NONE = 0
P1 = 1
P2 = 2

