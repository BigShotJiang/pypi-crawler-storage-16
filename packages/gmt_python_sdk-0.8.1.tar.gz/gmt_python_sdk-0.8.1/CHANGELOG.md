# Changelog

## 0.8.1 (2025-12-09)

Full Changelog: [v0.8.0...v0.8.1](https://github.com/cameo6/gmt-python-sdk/compare/v0.8.0...v0.8.1)

### Bug Fixes

* **types:** allow pyright to infer TypedDict types within SequenceNotStr ([58aeecc](https://github.com/cameo6/gmt-python-sdk/commit/58aeecc79443b9b01525e4fee4175a17d032de39))

## 0.8.0 (2025-12-08)

Full Changelog: [v0.7.0...v0.8.0](https://github.com/cameo6/gmt-python-sdk/compare/v0.7.0...v0.8.0)

### Features

* **api:** api update ([3def11a](https://github.com/cameo6/gmt-python-sdk/commit/3def11a05f9c92676f251e7a2af305fa2be5d5bc))

## 0.7.0 (2025-12-08)

Full Changelog: [v0.6.0...v0.7.0](https://github.com/cameo6/gmt-python-sdk/compare/v0.6.0...v0.7.0)

### Features

* **api:** add refund repository ([d8db552](https://github.com/cameo6/gmt-python-sdk/commit/d8db552d131f6c5ef561b525a88ddb640367f381))

## 0.6.0 (2025-12-08)

Full Changelog: [v0.5.0...v0.6.0](https://github.com/cameo6/gmt-python-sdk/compare/v0.5.0...v0.6.0)

### Features

* **api:** api update ([67ec995](https://github.com/cameo6/gmt-python-sdk/commit/67ec995a28fb98f9e262bf599c0549e0cdae73ba))

## 0.5.0 (2025-12-08)

Full Changelog: [v0.4.0...v0.5.0](https://github.com/cameo6/gmt-python-sdk/compare/v0.4.0...v0.5.0)

### Features

* **api:** add webhooks endpoint ([eb61be5](https://github.com/cameo6/gmt-python-sdk/commit/eb61be5bdfde7153dc653d265893f5c1ef21b4ca))

## 0.4.0 (2025-12-08)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/cameo6/gmt-python-sdk/compare/v0.3.0...v0.4.0)

### Features

* **api:** api update ([6fd4046](https://github.com/cameo6/gmt-python-sdk/commit/6fd4046e10082492f50987970e6880390272ba37))


### Chores

* update lockfile ([dbbf2e9](https://github.com/cameo6/gmt-python-sdk/commit/dbbf2e9f243aa59dd4eb64246cab4eaec204f506))

## 0.3.0 (2025-11-28)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/cameo6/gmt-python-sdk/compare/v0.2.0...v0.3.0)

### Features

* **api:** api update ([3d8f73c](https://github.com/cameo6/gmt-python-sdk/commit/3d8f73c03a372b6bacad14b4925d1350fab12548))

## 0.2.0 (2025-11-28)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/cameo6/gmt-python-sdk/compare/v0.1.0...v0.2.0)

### Features

* **api:** api update ([31f9595](https://github.com/cameo6/gmt-python-sdk/commit/31f9595ad1832708e52ebdd77acd34776e19a890))

## 0.1.0 (2025-11-28)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/cameo6/gmt-python-sdk/compare/v0.0.1...v0.1.0)

### Features

* **api:** api update ([0ba3d7e](https://github.com/cameo6/gmt-python-sdk/commit/0ba3d7e4e9a87866e89d244fd6c7ca98a59236af))
* **api:** manual updates ([81d9f33](https://github.com/cameo6/gmt-python-sdk/commit/81d9f33de9f266d7c5e06379cf75d55a40f1366a))


### Bug Fixes

* ensure streams are always closed ([5ab47f0](https://github.com/cameo6/gmt-python-sdk/commit/5ab47f0219cc85563e6e7352e460cda9275f1601))


### Chores

* **deps:** mypy 1.18.1 has a regression, pin to 1.17 ([a1731e0](https://github.com/cameo6/gmt-python-sdk/commit/a1731e0758cf5de45fb93fd59fc03dbfbb1a806a))
* update SDK settings ([2d9f3a9](https://github.com/cameo6/gmt-python-sdk/commit/2d9f3a90bc50ded9e8df86031ffd6509852d9bd6))
* update SDK settings ([904acac](https://github.com/cameo6/gmt-python-sdk/commit/904acacb04e79821b2f5ac9990b09e8ec6bd8fdc))
