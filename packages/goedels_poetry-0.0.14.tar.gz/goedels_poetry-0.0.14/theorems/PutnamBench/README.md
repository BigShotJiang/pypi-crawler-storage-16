# PutnamBench Problem Library

This directory contains Lean formalizations of the PutnamBench dataset.<sup>[1](https://github.com/trishullab/PutnamBench)</sup>.

The collection targets Lean `v4.9.0`, commit [b867bc72d6d725b48ae3a27d540a0b78e1c7d6f3](https://github.com/trishullab/PutnamBench/tree/b867bc72d6d725b48ae3a27d540a0b78e1c7d6f3) of [PutnamBench](https://github.com/trishullab/PutnamBench/tree/b867bc72d6d725b48ae3a27d540a0b78e1c7d6f3), matching the compiler version expected by the Goedel-Prover-V2 project.
