EN
    This is a package for the ones that don't wana lose time with small things, such as capitalizing literals or making a massive block for writing JSON in a file.
    -- CONTENT --
        - true -
            Variable that is equal to True
        - false -
            Variable that is equal to False
        - none -
            Variable that is equal to None
        - rjson(file_or_CRU) -
            Function to convert JSON from a string or from a file into python
        - wjson(object, file=none) -
            Function to convert an object (not only OOP objects, but anything) into JSON, if file argument is provided, writes the final result into the specified file

PT
    Este é um pacote para quem não quer perder tempo com as pequenas coisas, como capitalizar literais ou fazer um bloco massivo pra escrever JSON em um arquivo.
    --  CONTEÚDO --
        - true -
            Variável que equivale a True
        - false -
            Variável que equivale a False
        - none -
            Variável que equivale a None
        - rjson(arquivo_ou_CRU) -
            Função para converter JSON de uma string ou arquivo em python
        - wjson(objeto, arquivo=none) -
            Função para converter objetos (não só objetos de POO, mas qualquer coisa) em JSON, se o argumento arquivo for providenciado, escreve o resultado final no arquivo especificado
