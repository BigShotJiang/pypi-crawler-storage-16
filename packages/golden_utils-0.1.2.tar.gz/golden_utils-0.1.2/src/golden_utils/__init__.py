from .goldenutils import true, false, none, rjson, wjson
