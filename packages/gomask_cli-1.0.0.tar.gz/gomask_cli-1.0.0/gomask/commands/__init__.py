"""
GoMask CLI commands
"""