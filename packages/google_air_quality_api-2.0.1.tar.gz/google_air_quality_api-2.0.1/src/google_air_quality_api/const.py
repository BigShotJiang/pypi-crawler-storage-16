"""Constants for Google Air Quality API."""

API_BASE_URL = "https://airquality.googleapis.com/v1"
