class SignatureVerificationError(Exception):
    """Raised when signature verification fails."""

    pass
