# API

::: gopher.read_encyclopedia
::: gopher.read_metamorpheus
::: gopher.read_diann
::: gopher.test_enrichment
::: gopher.get_data_dir
::: gopher.set_data_dir
