# Changelog for gopher

## [v0.3.0] - 2025-12-09
### Changed
- Modernized codebase for uv.

### Fixed
- Linting errors.
- Publish action.

## [v0.2.0] - 2025-05-08
- Update github actions
- Update mkdocs.yml
- Add `read_diann` function
