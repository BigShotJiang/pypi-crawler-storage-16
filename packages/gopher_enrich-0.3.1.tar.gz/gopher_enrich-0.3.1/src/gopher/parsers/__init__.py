"""The parsers."""

from .tabular import read_diann, read_encyclopedia, read_metamorpheus
