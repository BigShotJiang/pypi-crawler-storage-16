"""
GPU Stats CLI - A beautiful terminal UI for monitoring NVIDIA GPU metrics
"""

__version__ = "0.1.0"
__author__ = "Your Name"
__license__ = "MIT"
