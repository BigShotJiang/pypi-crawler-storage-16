from .onto import DBConfig, DBType

__all__ = [
    "DBConfig",
    "DBType",
]
