# grahana

`grahana` is a Python package for classifying exoplanet candidates using a pre-trained Keras model. It takes planetary features as input and predicts whether an object is a "candidate" exoplanet or a "false_positive".

## Installation

Run the following command in the root of the project:

```bash
pip install .
```

## Usage

You can use the `predict` function to get a classification label or raw probabilities.

### Basic Usage (Get Label)

```python
from grahana import predict

label = predict(
    orbital_period_days=3.52,
    transit_depth_ppm=1500,
    transit_duration_hours=2.5,
    snr=12.0,
    insolation_flux=1.3,
)
print(label)  # Output: "false_positive" or "candidate"
```

### Advanced Usage (Get Probabilities)

```python
from grahana import predict

probs = predict(
    3.52, 1500, 2.5, 12.0, 1.3,
    return_label=False,
)
print(probs)  # Output: e.g. [0.85, 0.15]
```
