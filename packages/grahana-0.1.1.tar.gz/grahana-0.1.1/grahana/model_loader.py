from pathlib import Path
from tensorflow.keras.models import load_model

MODEL_PATH = Path(__file__).parent / "exoplanet_model.h5"
_model = None

def get_model():
    """Return a singleton instance of the loaded Keras model."""
    global _model
    if _model is None:
        if not MODEL_PATH.exists():
            raise FileNotFoundError(f"Model file not found at: {MODEL_PATH}")
        _model = load_model(MODEL_PATH)
    return _model
