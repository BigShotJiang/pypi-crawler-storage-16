import numpy as np
from .model_loader import get_model

INDEX_TO_LABEL = {
    0: "false_positive",
    1: "candidate",
}

def _preprocess_features(
    orbital_period_days: float,
    transit_depth_ppm: float,
    transit_duration_hours: float,
    snr: float,
    insolation_flux: float,
) -> np.ndarray:
    """
    Pack features into a (1, 5) NumPy array.
    
    TODO: If scaling/normalization was used during training (e.g., StandardScaler, MinMaxScaler),
    the same transformation must be applied here.
    """
    features = [
        orbital_period_days,
        transit_depth_ppm,
        transit_duration_hours,
        snr,
        insolation_flux
    ]
    return np.array([features], dtype=np.float32)

def predict(
    orbital_period_days: float,
    transit_depth_ppm: float,
    transit_duration_hours: float,
    snr: float,
    insolation_flux: float,
    return_label: bool = True,
):
    """
    Predict whether an exoplanet is a false positive or candidate.

    Parameters
    ----------
    orbital_period_days : float
    transit_depth_ppm : float
    transit_duration_hours : float
    snr : float
    insolation_flux : float
    return_label : bool, default True
        If True, return a string label ("false_positive"/"candidate").
        If False, return the raw numpy array of probabilities.

    Returns
    -------
    str or np.ndarray
    """
    model = get_model()
    
    x = _preprocess_features(
        orbital_period_days,
        transit_depth_ppm,
        transit_duration_hours,
        snr,
        insolation_flux
    )
    
    # model.predict output shape is (samples, classes), we take the first row
    predictions = model.predict(x, verbose=0)[0]
    
    if not return_label:
        return predictions
        
    class_index = np.argmax(predictions)
    return INDEX_TO_LABEL[class_index]
