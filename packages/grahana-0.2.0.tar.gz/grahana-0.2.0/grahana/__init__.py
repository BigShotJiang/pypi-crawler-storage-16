from .predictor import predict

__all__ = ["predict"]
