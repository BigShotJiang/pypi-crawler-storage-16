"""Graphent - A multi-agent framework for building conversational AI systems.

This module provides the public API for the Graphent framework.

Example:
    >>> from graphent import Agent, AgentBuilder, Context
    >>> agent = (AgentBuilder()
    ...     .with_name("Assistant")
    ...     .with_model(my_llm)
    ...     .with_system_prompt("You are helpful.")
    ...     .with_description("A helpful assistant")
    ...     .build())
    >>> context = Context().add_message(HumanMessage(content="Hello!"))
    >>> result = agent.invoke(context)
"""

__version__ = "0.1.0"

# Core classes
from lib.Agent import Agent
from lib.AgentBuilder import AgentBuilder
from lib.Context import Context

# Hooks system
from lib.hooks import (
    HookRegistry,
    HookType,
    HookCallback,
    # Event data classes
    ToolCallEvent,
    ToolResultEvent,
    ResponseEvent,
    ModelCallEvent,
    ModelResultEvent,
    DelegationEvent,
    TodoChangeEvent,
    # Hook decorators
    on_tool_call,
    after_tool_call,
    on_response,
    before_model_call,
    after_model_call,
    on_delegation,
    on_todo_change,
)

# Configuration
from lib.config import (
    GraphentConfig,
    get_config,
    set_config,
    reset_config,
)

# Exceptions
from lib.exceptions import (
    GraphentError,
    AgentConfigurationError,
    ToolExecutionError,
    DelegationError,
    MaxIterationsExceededError,
    HookExecutionError,
)

# Logging utilities
from lib.logging_utils import (
    AgentLoggerConfig,
    log_agent_activity,
)

# Submodules (for explicit imports like `from lib import tools`)
from lib import tools
from lib import agents
from lib import graph

# YAML configuration loading
from lib.yaml_loader import load_agent_from_yaml, load_graph_from_yaml

# Graph-based architecture
from lib.graph import (
    Graph,
    GraphBuilder,
    ActionNode,
    AgentNode,
    ClassifierNode,
    Edge,
    ConditionalEdge,
    BaseNode,
    GraphHookRegistry,
    GraphHookType,
    NodeEnterEvent,
    NodeExitEvent,
    EdgeTraverseEvent,
    ClassificationEvent,
    on_node_enter,
    on_node_exit,
    on_edge_traverse,
    on_classification,
)

__all__ = [
    # Version
    "__version__",
    # Core classes
    "Agent",
    "AgentBuilder",
    "Context",
    # Hooks
    "HookRegistry",
    "HookType",
    "HookCallback",
    "ToolCallEvent",
    "ToolResultEvent",
    "ResponseEvent",
    "ModelCallEvent",
    "ModelResultEvent",
    "DelegationEvent",
    "on_tool_call",
    "after_tool_call",
    "on_response",
    "before_model_call",
    "after_model_call",
    "on_delegation",
    # Configuration
    "GraphentConfig",
    "get_config",
    "set_config",
    "reset_config",
    # Exceptions
    "GraphentError",
    "AgentConfigurationError",
    "ToolExecutionError",
    "DelegationError",
    "MaxIterationsExceededError",
    "HookExecutionError",
    # Logging
    "AgentLoggerConfig",
    "log_agent_activity",
    # Submodules
    "tools",
    "agents",
    "graph",
    # Graph-based architecture
    "Graph",
    "GraphBuilder",
    "ActionNode",
    "AgentNode",
    "ClassifierNode",
    "Edge",
    "ConditionalEdge",
    "BaseNode",
    "GraphHookRegistry",
    "GraphHookType",
    "NodeEnterEvent",
    "NodeExitEvent",
    "EdgeTraverseEvent",
    "ClassificationEvent",
    "on_node_enter",
    "on_node_exit",
    "on_edge_traverse",
    "on_classification",
    # YAML loading
    "load_agent_from_yaml",
    "load_graph_from_yaml",
]
