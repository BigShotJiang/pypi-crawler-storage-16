# Changelog

This page was created to track changes to versions of GraphEx-Web-Automation-Plugin. The changelog was created in v1.1.3 and only changes starting from that version are tracked here.

## 1.2.0

- Update playwright pin to v1.56.0 (latest) and mitre-graphex to 1.18.0 (latest)
- Pin greenlet to 3.2.4 to match mitre-graphex
- Only install playwright chromium on Oracle Linux (still requires user to setup many RPM package dependencies)

## 1.1.3

- Update package metadata for PyPI
- Pin setuptools verison
