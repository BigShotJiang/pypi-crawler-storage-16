********
Covering
********

.. automodule:: networkx.algorithms.covering
.. autosummary::
   :toctree: generated/

   min_edge_cover
   is_edge_cover
