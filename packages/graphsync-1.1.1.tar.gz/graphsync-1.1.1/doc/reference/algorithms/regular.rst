*******
Regular
*******

.. automodule:: networkx.algorithms.regular
.. autosummary::
   :toctree: generated/

   is_regular
   is_k_regular
   k_factor
