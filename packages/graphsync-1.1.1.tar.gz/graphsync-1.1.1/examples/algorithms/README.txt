Algorithms
----------
