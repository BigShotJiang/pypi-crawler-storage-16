"""
graphsync
========

graphsync is a Python package for the creation, manipulation, and study of the
structure, dynamics, and functions of complex networks.

See https://networkx.org for complete documentation.
"""

__version__ = "1.1.1"


def __getattr__(name):
    """Remove functions and provide informative error messages."""
    if name == "nx_yaml":
        raise ImportError(
            "\nThe nx_yaml module has been removed from graphsync.\n"
            "Please use the `yaml` package directly for working with yaml data.\n"
            "For example, a graphsync.Graph `G` can be written to and loaded\n"
            "from a yaml file with:\n\n"
            "    import yaml\n\n"
            "    with open('path_to_yaml_file', 'w') as fh:\n"
            "        yaml.dump(G, fh)\n"
            "    with open('path_to_yaml_file', 'r') as fh:\n"
            "        G = yaml.load(fh, Loader=yaml.Loader)\n\n"
            "Note that yaml.Loader is considered insecure - see the pyyaml\n"
            "documentation for further details.\n\n"
        )
    if name == "read_yaml":
        raise ImportError(
            "\nread_yaml has been removed from graphsync, please use `yaml`\n"
            "directly:\n\n"
            "    import yaml\n\n"
            "    with open('path', 'r') as fh:\n"
            "        yaml.load(fh, Loader=yaml.Loader)\n\n"
            "Note that yaml.Loader is considered insecure - see the pyyaml\n"
            "documentation for further details.\n\n"
        )
    if name == "write_yaml":
        raise ImportError(
            "\nwrite_yaml has been removed from graphsync, please use `yaml`\n"
            "directly:\n\n"
            "    import yaml\n\n"
            "    with open('path_for_yaml_output', 'w') as fh:\n"
            "        yaml.dump(G_to_be_yaml, path_for_yaml_output, **kwds)\n\n"
        )
    raise AttributeError(f"module {__name__} has no attribute {name}")


# These are import orderwise
from graphsync.exception import *

from graphsync import utils

from graphsync import classes
from graphsync.classes import filters
from graphsync.classes import *

from graphsync import convert
from graphsync.convert import *

from graphsync import convert_matrix
from graphsync.convert_matrix import *

from graphsync import relabel
from graphsync.relabel import *

from graphsync import generators
from graphsync.generators import *

from graphsync import readwrite
from graphsync.readwrite import *

# Need to test with SciPy, when available
from graphsync import algorithms
from graphsync.algorithms import *

from graphsync import linalg
from graphsync.linalg import *

from graphsync.testing.test import run as test

from graphsync import drawing
from graphsync.drawing import *
