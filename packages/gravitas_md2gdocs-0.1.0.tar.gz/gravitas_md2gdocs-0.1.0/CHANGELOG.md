# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] - 2025-12-09

### Added
- Initial release
- `to_requests()` function for converting markdown to Docs API requests
- Support for headers (H1-H6)
- Support for bold, italic, bold+italic text
- Support for strikethrough
- Support for inline code and code blocks
- Support for links
- Support for bullet and numbered lists
- Support for blockquotes
- Helper functions: `append()`, `replace()`, `insert_at()`, `replace_range()`
- Full test suite
- CI/CD pipeline with GitHub Actions
