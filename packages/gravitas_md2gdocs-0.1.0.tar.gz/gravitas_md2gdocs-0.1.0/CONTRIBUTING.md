# Contributing to gravitas-md2gdocs

We welcome contributions! Here's how to get started.

## Development Setup

1. Clone the repository:
   ```bash
   git clone https://github.com/significant-gravitas/gravitas-md2gdocs.git
   cd gravitas-md2gdocs
   ```

2. Install dev dependencies with uv:
   ```bash
   uv sync --extra dev
   ```

   Or with Google API support:
   ```bash
   uv sync --extra dev --extra google
   ```

## Running Tests

```bash
uv run pytest tests/ -v
```

With coverage:
```bash
uv run pytest tests/ -v --cov=src/gravitas_md2gdocs
```

## Linting and Formatting

We use ruff for linting and formatting:

```bash
# Check for issues
uv run ruff check .

# Auto-fix issues
uv run ruff check --fix .

# Format code
uv run ruff format .

# Check formatting only
uv run ruff format --check .
```

## Pull Request Process

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/my-feature`)
3. Make your changes
4. Run tests and linting
5. Commit your changes (`git commit -am 'Add my feature'`)
6. Push to your fork (`git push origin feature/my-feature`)
7. Open a Pull Request

## CI/CD

All PRs must pass:
- Linting (ruff)
- Tests on Python 3.10, 3.11, 3.12
- Build verification

## Releasing

Releases are automated via GitHub Actions. To create a release:

1. Update CHANGELOG.md with the new version
2. Create a git tag (e.g., `git tag v0.1.0`)
3. Push the tag (`git push origin v0.1.0`)
4. GitHub Actions will automatically build and publish to PyPI
