# GEData SDK for Python

https://help.gravity-engine.com/docs/track-python