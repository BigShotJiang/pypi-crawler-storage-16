"""Allow running greenmining as a module: python -m greenmining"""

from greenmining.cli import cli

if __name__ == "__main__":
    cli()
