# greetpkg

A very simple Python package that prints a greeting.
