def greet(name="World"):
    print(f"Hello, {name}!")
