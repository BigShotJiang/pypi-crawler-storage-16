import click
import pandas as pd
from gresecml.core.session_manager import SessionManager
from gresecml.core.pcap_manager import lazy_read_packets
from gresecml.core.pcap_manager import read_packets
from gresecml.core.sniffer_manager import sniff_packets
from gresecml.core.progress_manager import ProgressManager
from gresecml.core.tensorflow_prediction_manager import tensorflow_predict
from gresecml.core.output_manager import output_dataframe
from gresecml.core.pushbullet_manager import send_pushbullet_notification

# Set non feature columns to exclude from prediction input
non_feature_columns = ['src_ip', 'dst_ip', 'src_port']
# Set columns to exclude from output
columns_to_exclude = ['time_mean', 'time_std', 'bytes_mean', 'bytes_std', 'inter_arrival_std', 'inter_arrival_min', 'inter_arrival_max', 'flag_syn_count', 'flag_ack_count', 'flag_fin_count', 'flag_rst_count', 'flag_dns_count', 'successful_connection', 'num_of_dest_unreachable']
# Supported output file types
supported_output_file_types = ['html', 'csv']

@click.group()
def tf():
    """Make predictions using TensorFlow."""
    pass

@click.command()
@click.argument('input', type=click.Path(exists=True, file_okay=True, dir_okay=False, readable=True, resolve_path=True))
@click.option('--output', '-o', type=click.Path(dir_okay=False, writable=True, resolve_path=True), default=None, help=f'Path for file to append output to. Supported file types: {supported_output_file_types}. If not provided, no file will be saved.')
@click.option('--enable-full-output', '-efo', is_flag=True, help='Enable full output including all features in the file and console output.')
@click.option('--prop-normal-max', '-pnm', type=int, default=None, help='Set the maximum normal traffic probability threshold(%) for output. Default is None (no threshold).')
@click.option('--lazy-load', '-ll', is_flag=True, help='Enable lazy loading. Predicts sessions one by one to save memory.')
@click.option('--verbose', '-v', is_flag=True, help='Enable verbose output.')
def predict(input, output: click.Path, enable_full_output, prop_normal_max, lazy_load, verbose):
    """Make predictions for a given pcap file using TensorFlow.
    
    INPUT: Path to the pcap file to analyze.
    """
    try:
        click.echo(click.style(f"\nAnalyzing network traffic using tensorflow model.\n", fg='yellow', bold=True))

        # Initialize session manager
        session_manager = SessionManager()

        if lazy_load:
            returned_sessions = session_manager.start_processing(lazy_read_packets(input))

            # Lazy read packets and transform to sessions while making predictions
            progress_manager = ProgressManager()
            progress_manager.start(description="Processing network packets into sessions and making predictions")

            final_dataframe = pd.DataFrame()

            for session in returned_sessions:
                # Create input dictionary for prediction excluding non-feature columns
                input_dict = {col: session.iloc[0][col] for col in session.columns if col not in non_feature_columns}
                # Make predictions using TensorFlow model
                preds = tensorflow_predict(input_data=input_dict)
                
                # Update session with predictions
                for key, value in preds.items():
                    session[key] = value

                if prop_normal_max is not None:
                    if session.iloc[0]['prediction_normal'] * 100 <= prop_normal_max:
                        # Output final results
                        output_dataframe(session, output, enable_full_output, columns_to_exclude, sort_by='prediction_normal', verbose=verbose, progress_manager=progress_manager)
                else:
                    # Output final results
                    output_dataframe(session, output, enable_full_output, columns_to_exclude, sort_by='prediction_normal', verbose=verbose, progress_manager=progress_manager)

            progress_manager.stop()
            
        if not lazy_load:
            # For predicting all sessions together after processing (stores all sessions in memory)

            returned_sessions = session_manager.start_processing(read_packets(input))
            # Load packets and transform to sessions
            progress_manager = ProgressManager()
            progress_manager.start(description="Processing network packets into sessions")

            sessions = pd.DataFrame()

            for session in returned_sessions:
                sessions = pd.concat([sessions, session], ignore_index=True)

            progress_manager.stop()
        
            # Make predictions using TensorFlow model
            progress_manager = ProgressManager(True)
            progress_manager.start(description="Making predictions", total=len(sessions))

            columns = sessions.columns.tolist()

            for idx, session in sessions.iterrows():
                input_dict = {col: session[col] for col in columns if col not in non_feature_columns}

                preds = tensorflow_predict(input_data=input_dict)
                
                for key, value in preds.items():
                    sessions.loc[idx, key] = value
                
                progress_manager.advance()

            progress_manager.stop()

            # Display predictions
            if prop_normal_max is not None:
                # Filter sessions based on normal traffic probability threshold
                filtered_sessions: pd.DataFrame = sessions[sessions['prediction_normal'] * 100 <= prop_normal_max]
                # Output filtered results
                output_dataframe(filtered_sessions, output, enable_full_output, columns_to_exclude, sort_by='prediction_normal', verbose=verbose, progress_manager=progress_manager)
            else:
                # Output all results
                output_dataframe(sessions, output, enable_full_output, columns_to_exclude, sort_by='prediction_normal', verbose=verbose, progress_manager=progress_manager)

        click.echo(click.style("\nPrediction process completed.\n", fg='yellow', bold=True))
    except Exception as e:
        click.echo(click.style(f"\nAn error occurred during prediction: \"{str(e)}\"\n", fg='red', bold=True))

tf.add_command(predict)

@click.command()
@click.option('--output', '-o', type=click.Path(dir_okay=False, writable=True, resolve_path=True), default=None, help=f'Path for file to append output to. Supported file types: {supported_output_file_types}. If not provided, no file will be saved.')
@click.option('--enable-full-output', '-efo', is_flag=True, help='Enable full output including all features in the file and console output.')
@click.option('--prop-normal-max', '-pnm', type=int, default=None, help='Set the maximum normal traffic probability threshold(%) for output. Default is None (no threshold).')
@click.option('--iface', '-if', type=str, default=None, help='Network interface for live capture. If not provided, the default interface will be used.')
@click.option('--timeout', '-t', type=int, default=None, help='Timeout in seconds for live capture. Default is 60 seconds.')
@click.option('--pushbullet-token', '-pbt', type=str, default=None, help='Pushbullet access token for sending notifications. Use -pnm to set threshold for notifications.')
@click.option('--verbose', '-v', is_flag=True, help='Enable verbose output.')
def predict_live(enable_full_output, prop_normal_max, iface, timeout, output, pushbullet_token, verbose):
    """Make predictions for a live capture using TensorFlow."""
    try:
        click.echo(click.style(f"\nAnalyzing live network traffic using tensorflow model.\n", fg='yellow', bold=True))

        # Initialize session manager
        session_manager = SessionManager()

        # Get packets from live capture
        returned_sessions = session_manager.start_processing(sniff_packets(iface=iface, timeout=timeout))

        progress_manager = ProgressManager()
        progress_manager.start(description="Predicting sessions from live capture")

        for session in returned_sessions:
            # Create input dictionary for prediction excluding non-feature columns
            input_dict = {col: session.iloc[0][col] for col in session.columns if col not in non_feature_columns}
            # Make predictions using TensorFlow model
            preds = tensorflow_predict(input_data=input_dict)
            
            # Update session with predictions
            for key, value in preds.items():
                session[key] = value

            if prop_normal_max is not None:
                if session.iloc[0]['prediction_normal'] * 100 <= prop_normal_max:
                    # Output final results
                    output_dataframe(session, output, enable_full_output, columns_to_exclude, sort_by='prediction_normal', verbose=verbose, progress_manager=progress_manager)
                    # Send Pushbullet notification if token is provided
                    if pushbullet_token:
                        try:
                            send_pushbullet_notification(pushbullet_token, session)
                        except Exception as e:
                            progress_manager.progress.console.print(f"\n[red]{str(e)}\n")
            else:
                # Output final results
                output_dataframe(session, output, enable_full_output, columns_to_exclude, sort_by='prediction_normal', verbose=verbose, progress_manager=progress_manager)
                # Send Pushbullet notification if token is provided
                if pushbullet_token:
                    # Send Pushbullet notification if token is provided
                    if pushbullet_token:
                        try:
                            send_pushbullet_notification(pushbullet_token, session)
                        except Exception as e:
                            progress_manager.progress.console.print(f"\n[red]{str(e)}\n")
        
        progress_manager.end()

        click.echo(click.style("\nLive prediction process finished.\n", fg='yellow', bold=True))
    except Exception as e:
        click.echo(click.style(f"\nAn error occurred during live prediction: \"{str(e)}\"\n", fg='red', bold=True))

tf.add_command(predict_live)
    