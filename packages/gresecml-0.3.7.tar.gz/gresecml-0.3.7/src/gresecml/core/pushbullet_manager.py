import requests
import pandas as pd
from datetime import datetime

def send_pushbullet_notification(access_token, dataframe: pd.DataFrame) -> bool:
    # API endpoint
    url = "https://api.pushbullet.com/v2/pushes"

    title = "GresecML Alert"
    body = f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\nSession from {dataframe.iloc[0]['src_ip']} to {dataframe.iloc[0]['dst_ip']} detected with:\nNormal traffic probability ({dataframe.iloc[0]['prediction_normal']*100:.2f}%).\nPort scan probability ({dataframe.iloc[0]['prediction_portscan']*100:.2f}%)."

    # Notification payload
    data = {
        "type": "note",
        "title": title,
        "body": body
    }

    # Send request
    resp = requests.post(url, json=data, headers={
        "Access-Token": access_token,
        "Content-Type": "application/json"
    })

    if resp.status_code == 200:
        return True
    else:
        raise Exception(f"Failed to send notification: HTTP status code - {resp.status_code}")