from .conllu_parser import ConlluParser

__all__ = ["ConlluParser"]
