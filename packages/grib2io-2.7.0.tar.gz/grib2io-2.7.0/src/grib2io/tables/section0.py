table_0_0 = {
'0':'Meteorological Products',
'1':'Hydrological Products',
'2':'Land Surface Products',
'3':'Satellite Remote Sensing Products',
'4':'Space Weather Products',
'5-9':'Reserved',
'10':'Oceanographic Products',
'11-19':'Reserved',
'20':'Health and Socioeconomic Impacts',
'21-190':'Reserved',
'191':'Computational Parameters',
'192-254':'Reserved for Local Use',
'255':'Missing',
}

