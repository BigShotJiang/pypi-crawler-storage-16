table_6_0 = {
'0':'A bit map applies to this product and is specified in this section.',
'1-253':'A bit map pre-determined by the orginating/generating center applies to this product and is not specified in this section.',
'254':'A bit map previously defined in the same GRIB2 message applies to this product.',
'255':'A bit map does not apply to this product.',
}

