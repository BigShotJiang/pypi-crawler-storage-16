# Version placeholder that will be replaced during substitution
__version__ = "0.1.0rc1"
