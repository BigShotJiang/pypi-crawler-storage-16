
Authors
=======

* David Seddon - https://seddonym.me
* Kevin Amado - https://github.com/kamadorueda
* Matthew Gamble - https://github.com/mwgamble
* NetworkX developers - The shortest path algorithm was adapted from the NetworkX library https://networkx.org/.
* Peter Byfield - https://github.com/Peter554
* Shane Smiskol - https://github.com/sshane
* Andreas Rammhold - https://github.com/andir
* Nicholas Bunn - https://github.com/NicholasBunn
