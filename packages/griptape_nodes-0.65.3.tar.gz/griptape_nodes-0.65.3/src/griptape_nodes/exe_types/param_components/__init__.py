"""Parameter components for reusable node functionality."""
