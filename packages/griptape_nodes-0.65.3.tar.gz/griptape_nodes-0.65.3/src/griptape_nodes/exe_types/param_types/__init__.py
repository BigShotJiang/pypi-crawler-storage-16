"""Parameter types for simple parameter creation."""
