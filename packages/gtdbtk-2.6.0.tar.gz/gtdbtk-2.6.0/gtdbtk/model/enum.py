from enum import Enum


class Domain(Enum):
    ARCHAEA = 'arc'
    BACTERIA = 'bac'
