The methods and actions in this domain implement the near-optimal
blocks-world planning algorithm described in the following paper:

    N. Gupta and D. S. Nau. On the complexity of blocks-world 
    planning. Artificial Intelligence 56(2-3):223–254, 1992.

--Dana Nau, July 2, 2021

