"""GuardianHub SDK - Unified SDK for Local AI Guardian

This package provides core functionality for the GuardianHub platform,
including logging, metrics, and FastAPI utilities.
"""

# Version
from ._version import __version__  # version exported for users

# Core functionality
from .logging import get_logger, setup_logging

# Public API
__all__ = [
    # Version
    "__version__",
    
    # Logging
    "get_logger",
    "setup_logging",
]