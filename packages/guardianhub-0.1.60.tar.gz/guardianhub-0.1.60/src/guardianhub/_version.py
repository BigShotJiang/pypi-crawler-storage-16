# src/guardianhub/_version.py
# single-source of truth for hatch version plugin
__version__ = '0.1.60'