from .settings import get_settings
settings = get_settings()