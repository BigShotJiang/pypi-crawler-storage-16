from .remote_inference import get_use_remote_inference

__all__ = ["get_use_remote_inference"]
