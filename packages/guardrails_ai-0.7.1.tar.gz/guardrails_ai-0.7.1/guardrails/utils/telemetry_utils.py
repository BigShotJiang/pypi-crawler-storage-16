# These are referenced in the docs so we have to keep them importable from here for now.
from guardrails.telemetry.default_otel_collector_tracer_mod import (
    default_otel_collector_tracer,  # noqa
)  # noqa
from guardrails.telemetry.default_otlp_tracer_mod import (
    default_otlp_tracer,  # noqa
)  # noqa
