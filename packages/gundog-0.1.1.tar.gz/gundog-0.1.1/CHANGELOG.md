# CHANGELOG

<!-- version list -->

## v0.1.1 (2025-12-14)

### Chores

- Fix release mess
  ([`c60b36d`](https://github.com/adhityaravi/gundog/commit/c60b36db1c5848b5d56fe1b87bc16fdfa54f0ba9))


## v1.0.0 (2025-12-14)

- Initial Release
