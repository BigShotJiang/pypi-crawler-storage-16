"""Test module for exclusion patterns feature."""

from pytest_bdd import scenarios

scenarios("../features/exclusions.feature")
