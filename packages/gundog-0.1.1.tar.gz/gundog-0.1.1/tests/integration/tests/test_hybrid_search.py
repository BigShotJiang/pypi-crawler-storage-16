"""Test module for hybrid search feature."""

from pytest_bdd import scenarios

scenarios("../features/hybrid_search.feature")
