"""Gundog - Semantic retrieval for architectural knowledge."""

from gundog._version import __version__

__all__ = ["__version__"]
