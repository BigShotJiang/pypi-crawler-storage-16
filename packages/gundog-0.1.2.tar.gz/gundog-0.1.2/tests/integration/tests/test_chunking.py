"""Test module for chunking feature."""

from pytest_bdd import scenarios

scenarios("../features/chunking.feature")
