"""Test module for score rescaling feature."""

from pytest_bdd import scenarios

scenarios("../features/scoring.feature")
