"""Front tracking module for exact nonlinear transport modeling."""
