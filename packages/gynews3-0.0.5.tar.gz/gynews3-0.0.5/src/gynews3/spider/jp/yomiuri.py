import scrapy
from scrapy.linkextractors import LinkExtractor

from gynews3.model import LinkType
from gynews3.spider.jp import CommonSpider


class Spider(CommonSpider):
    name = "yomiuri"
    allowed_domains = ["yomiuri.co.jp"]
    start_urls = ["https://www.yomiuri.co.jp/news"]

    link_extractor = LinkExtractor(
        allow_domains=["yomiuri.co.jp"],
        restrict_css="#latest_list_news .news-top-latest__list-item h3 a",
        unique=True,
    )

    def parse(self, response):
        for link in self.link_extractor.extract_links(response):
            yield scrapy.Request(
                link.url,
                callback=self.parse_article,
                cb_kwargs={"linkType": LinkType.NEWS},
            )
