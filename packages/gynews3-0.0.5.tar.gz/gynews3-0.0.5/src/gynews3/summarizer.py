import os

import dotenv
from huggingface_hub import InferenceClient


def create_hf_client(api_key: str | None = None) -> InferenceClient:
    if api_key is None:
        dotenv.load_dotenv()
        api_key = os.environ.get("HF_TOKEN")

    return InferenceClient(
        provider="hf-inference",
        api_key=api_key,
    )


def hf_summarize(client: InferenceClient, text: str) -> str:
    result = client.summarization(
        text,
        model="csebuetnlp/mT5_multilingual_XLSum",
    )
    return result.summary_text
