# `haco` Home Assistant Control Objects

`haco` is a Python/Berry library to greatly simplify the process of
exposing Home
Assistant controls (e.g. Pull-down Lists, Number Sliders, Sensors, etc.) from a device - and handling the
communication between both sides.

It is in very early release. Documentation is (may) be forthcoming.
