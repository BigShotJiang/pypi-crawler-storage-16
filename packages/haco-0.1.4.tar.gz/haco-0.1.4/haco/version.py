from fmtr.tools import version

__version__ = version.read()
