"""Common utilities for graph implementations."""

from haiku.rag.utils import get_model

__all__ = ["get_model"]
