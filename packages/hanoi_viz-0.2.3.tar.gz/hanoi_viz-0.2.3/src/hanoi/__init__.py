from .solver import hanoi

__all__ = ['hanoi']
