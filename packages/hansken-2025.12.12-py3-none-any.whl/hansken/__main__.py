from hansken.tool import run


# hide traceback for builtin commands unless we're operating in verbose mode
run(error='exit')
