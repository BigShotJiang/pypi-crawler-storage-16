"""Hark: 100% offline, Whisper-powered voice notes from your terminal."""

__version__ = "0.1.0"
