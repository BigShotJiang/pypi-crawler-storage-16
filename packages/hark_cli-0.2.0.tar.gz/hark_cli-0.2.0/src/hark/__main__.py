"""Entry point for python -m hark."""

from hark.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
