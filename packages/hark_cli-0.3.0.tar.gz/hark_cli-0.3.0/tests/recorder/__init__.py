"""Tests for hark.recorder module."""
