from importlib.metadata import version

__version__ = version("harmonized-landsat-sentinel")
