# def test_HLS1_import():
#     from harmonized_landsat_sentinel import HLS1Connection

def test_HLS2_import():
    from harmonized_landsat_sentinel import HLS2Connection
