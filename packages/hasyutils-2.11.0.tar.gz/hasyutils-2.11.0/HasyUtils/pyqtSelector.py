#!/bin/env python
'''
this file appears 2 times
$HOME/gitlabDESY/hasyutils/HasyUtils/pyqtSelector.py 
$HOME/gitlabDESY/pySpectra/PySpectra/pyqtSelector.py 
'''

import sys
from PyQt5 import QtGui, QtCore, QtWidgets
from PyQt5.QtCore import QLineF
from PyQt5.QtCore import QRectF
from PyQt5.QtGui import QFont
from PyQt5.QtGui import QColor
from PyQt5.QtGui import QPen
from PyQt5.QtGui import QBrush
from PyQt5.QtGui import QPainter
from PyQt5.QtGui import QKeySequence
from PyQt5.QtWidgets import QWidget
from PyQt5.QtWidgets import QDialog
from PyQt5.QtWidgets import QMainWindow
from PyQt5.QtWidgets import QFrame
from PyQt5.QtWidgets import QListWidget
from PyQt5.QtWidgets import QListWidgetItem
from PyQt5.QtWidgets import QApplication
from PyQt5.QtWidgets import QHBoxLayout
from PyQt5.QtWidgets import QVBoxLayout
from PyQt5.QtWidgets import QGridLayout
from PyQt5.QtWidgets import QTextEdit
from PyQt5.QtWidgets import QLabel
from PyQt5.QtWidgets import QScrollArea
from PyQt5.QtWidgets import QComboBox
from PyQt5.QtWidgets import QCheckBox
from PyQt5.QtWidgets import QInputDialog
from PyQt5.QtWidgets import QPushButton
from PyQt5.QtWidgets import QMenu
from PyQt5.QtWidgets import QMenuBar
from PyQt5.QtWidgets import QStatusBar
from PyQt5.QtWidgets import QAction
from PyQt5.QtWidgets import QDesktopWidget
from PyQt5.QtWidgets import QLineEdit
from PyQt5.QtWidgets import QSlider
from PyQt5.QtWidgets import QMessageBox
from PyQt5.QtWidgets import QErrorMessage
from PyQt5.QtWidgets import QGroupBox
from PyQt5.QtWidgets import QSpacerItem
from PyQt5.QtWidgets import QGraphicsView
from PyQt5.QtWidgets import QGraphicsScene
from PyQt5.QtWidgets import QSizePolicy
from PyQt5.QtWidgets import QSpinBox
