__all__ = ('ComponentMetadataChannelSelect', )

from scarletio import copy_docs

from .entity_select_base import ComponentMetadataEntitySelectBase
from .fields import parse_channel_types, put_channel_types, validate_channel_types


class ComponentMetadataChannelSelect(ComponentMetadataEntitySelectBase):
    """
    Channel select component metadata.
    
    Attributes
    ----------
    channel_types : ``None | tuple<ChannelType>``
        The allowed channel types by the select.
    
    custom_id : `None | str`
        Custom identifier to detect which component was used by the user.
    
    default_values : ``None | tuple<EntitySelectDefaultValue>``
        Entities presented in the select by default.
    
    enabled : `bool`
        Whether the component is enabled.
    
    max_values : `int
        The maximal amount of options to select.
    
    min_values : `int`
        The minimal amount of options to select.
    
    placeholder : `None | str`
        Placeholder text of the select.
    
    required : `bool`
        Whether the field is required to be fulfilled.
    """
    __slots__ = ('channel_types',)
    
    
    def __new__(
        cls,
        *,
        channel_types = ...,
        custom_id = ...,
        default_values = ...,
        enabled = ...,
        max_values = ...,
        min_values = ...,
        placeholder = ...,
        required = ...,
    ):
        """
        Creates a new channel select component metadata with the given parameters.
        
        Parameters
        ----------
        channel_types : ``None | iterable<int> | iterable<ChannelType>``, Optional (Keyword only)
            The allowed channel types by the select.
        
        custom_id : `None | str`, Optional (Keyword only)
            Custom identifier to detect which component was used by the user.
        
        default_values : ``None | iterable<Channel> | iterable<Role> | iterable<ClientUserBase> | iterable<EntitySelectDefaultValue> | iterable<(str | EntitySelectDefaultValueTyp, int | str)>>`` \
                , Optional (Keyword only)
            Entities presented in the select by default.
        
        enabled : `bool`, Optional (Keyword only)
            Whether the component is enabled.
        
        max_values : `int, Optional (Keyword only)
            The maximal amount of options to select.
        
        min_values : `int`, Optional (Keyword only)
            The minimal amount of options to select.
        
        placeholder : `None | str`, Optional (Keyword only)
            Placeholder text of the select.
        
        required : `None | bool`, Optional (Keyword only)
            Whether the field is required to be fulfilled.
        
        Raises
        ------
        TypeError
            - If a parameter's type is incorrect.
        ValueError
            - If a parameter's value is incorrect.
        """
        # channel_types
        if channel_types is ...:
            channel_types = None
        else:
            channel_types = validate_channel_types(channel_types)
        
        # Construct
        self = ComponentMetadataEntitySelectBase.__new__(
            cls,
            custom_id = custom_id,
            default_values = default_values,
            enabled = enabled,
            max_values = max_values,
            min_values = min_values,
            placeholder = placeholder,
            required = required,
        )
        self.channel_types = channel_types
        
        return self
    
    
    @classmethod
    @copy_docs(ComponentMetadataEntitySelectBase.from_keyword_parameters)
    def from_keyword_parameters(cls, keyword_parameters):
        return cls(
            channel_types = keyword_parameters.pop('channel_types', ...),
            custom_id = keyword_parameters.pop('custom_id', ...),
            default_values = keyword_parameters.pop('default_values', ...),
            enabled = keyword_parameters.pop('enabled', ...),
            max_values = keyword_parameters.pop('max_values', ...),
            min_values = keyword_parameters.pop('min_values', ...),
            placeholder = keyword_parameters.pop('placeholder', ...),
            required = keyword_parameters.pop('required', ...),
        )
    
    
    @copy_docs(ComponentMetadataEntitySelectBase._add_type_specific_repr_fields_into)
    def _add_type_specific_repr_fields_into(self, repr_parts):
        # channel_types
        repr_parts.append(', channel_types = ')
        channel_types = self.channel_types
        if (channel_types is None):
            repr_parts.append('[]')
        else:
            repr_parts.append('[')
            
            index = 0
            limit = len(channel_types)
            
            while True:
                option = channel_types[index]
                index += 1
                
                repr_parts.append(repr(option))
                
                if index == limit:
                    break
                
                repr_parts.append(', ')
                continue
            
            repr_parts.append(']')
    
    
    @copy_docs(ComponentMetadataEntitySelectBase.__hash__)
    def __hash__(self):
        hash_value = ComponentMetadataEntitySelectBase.__hash__(self)
        
        # channel_types
        channel_types = self.channel_types
        if (channel_types is not None):
            hash_value ^= len(channel_types) << 12
            for index, channel_type in enumerate(channel_types):
                hash_value ^= channel_type.value << (index << 1)
        
        return hash_value
    
    
    @copy_docs(ComponentMetadataEntitySelectBase._is_equal_same_type)
    def _is_equal_same_type(self, other):
        if not ComponentMetadataEntitySelectBase._is_equal_same_type(self, other):
            return False
        
        # channel_types
        if self.channel_types != other.channel_types:
            return False
        
        return True
    
    
    @classmethod
    @copy_docs(ComponentMetadataEntitySelectBase.from_data)
    def from_data(cls, data):
        self = super(ComponentMetadataChannelSelect, cls).from_data(data)
        self.channel_types = parse_channel_types(data)
        return self
    
    
    @copy_docs(ComponentMetadataEntitySelectBase.to_data)
    def to_data(self, *, defaults = False, include_internals = False):
        data = ComponentMetadataEntitySelectBase.to_data(
            self, defaults = defaults, include_internals = include_internals
        )
        
        put_channel_types(self.channel_types, data, defaults)
        
        return data
    
    
    @copy_docs(ComponentMetadataEntitySelectBase.clean_copy)
    def clean_copy(self, guild = None):
        new = ComponentMetadataEntitySelectBase.clean_copy(self, guild)
        
        # channel_types
        channel_types = self.channel_types
        if (channel_types is not None):
            channel_types = (*channel_types,)
        new.channel_types = channel_types
        
        return new
    
    
    @copy_docs(ComponentMetadataEntitySelectBase.copy)
    def copy(self):
        new = ComponentMetadataEntitySelectBase.copy(self)
        
        # channel_types
        channel_types = self.channel_types
        if (channel_types is not None):
            channel_types = (*channel_types,)
        new.channel_types = channel_types
        
        return new
    
    
    def copy_with(
        self,
        *,
        channel_types = ...,
        custom_id = ...,
        default_values = ...,
        enabled = ...,
        max_values = ...,
        min_values = ...,
        placeholder = ...,
        required = ...,
    ):
        """
        Copies the channel select component metadata with the given fields.
        
        Parameters
        ----------
        channel_types : ``None | iterable<int> | iterable<ChannelType>``, Optional (Keyword only)
            The allowed channel types by the select.
        
        custom_id : `None | str`, Optional (Keyword only)
            Custom identifier to detect which component was used by the user.
        
        default_values : ``None | iterable<Channel> | iterable<Role> | iterable<ClientUserBase> | iterable<EntitySelectDefaultValue> | iterable<(str | EntitySelectDefaultValueTyp, int | str)>>`` \
                , Optional (Keyword only)
            Entities presented in the select by default.
        
        enabled : `bool`, Optional (Keyword only)
            Whether the component is enabled.
        
        max_values : `int, Optional (Keyword only)
            The maximal amount of options to select.
        
        min_values : `int`, Optional (Keyword only)
            The minimal amount of options to select.
        
        placeholder : `None | str`, Optional (Keyword only)
            Placeholder text of the select.
        
        required : `None | bool`, Optional (Keyword only)
            Whether the field is required to be fulfilled.
        
        Returns
        -------
        new : `instance<type<self>>`
        
        Raises
        ------
        TypeError
            - If a parameter's type is incorrect.
        ValueError
            - If a parameter's value is incorrect.
        """
        # channel_types
        if channel_types is ...:
            channel_types = self.channel_types
            if (channel_types is not None):
                channel_types = (*channel_types,)
        else:
            channel_types = validate_channel_types(channel_types)
        
        # Construct
        
        new = ComponentMetadataEntitySelectBase.copy_with(
            self,
            custom_id = custom_id,
            default_values = default_values,
            enabled = enabled,
            max_values = max_values,
            min_values = min_values,
            placeholder = placeholder,
            required = required,
        )
        new.channel_types = channel_types
        return new
    
    
    @copy_docs(ComponentMetadataEntitySelectBase.copy_with_keyword_parameters)
    def copy_with_keyword_parameters(self, keyword_parameters):
        return self.copy_with(
            channel_types = keyword_parameters.pop('channel_types', ...),
            custom_id = keyword_parameters.pop('custom_id', ...),
            default_values = keyword_parameters.pop('default_values', ...),
            enabled = keyword_parameters.pop('enabled', ...),
            max_values = keyword_parameters.pop('max_values', ...),
            min_values = keyword_parameters.pop('min_values', ...),
            placeholder = keyword_parameters.pop('placeholder', ...),
            required = keyword_parameters.pop('required', ...),
        )
