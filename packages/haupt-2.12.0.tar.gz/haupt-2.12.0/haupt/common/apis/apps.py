from django.apps import AppConfig


class CommonApisConfig(AppConfig):
    name = "haupt.common.apis"
    verbose_name = "commonApis"
    label = "commonApis"
