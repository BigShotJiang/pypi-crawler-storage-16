import uuid

from polyaxon._constants.globals import DEFAULT


class Owner:
    name = DEFAULT
    uuid = uuid.UUID("9b0a3806e3f84ea1959a7842e34129ed")
    id = 1


class Actor:
    username = DEFAULT
    id = 1
