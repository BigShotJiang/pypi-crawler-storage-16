from haupt.db.abstracts.users import BaseUser


class User(BaseUser):
    pass
