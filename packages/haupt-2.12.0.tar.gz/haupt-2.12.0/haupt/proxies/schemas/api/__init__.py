from haupt.proxies.schemas.api.base import get_base_config
