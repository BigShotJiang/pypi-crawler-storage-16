"""
Performance tests for HBAT.

This module contains performance tests that measure execution time,
memory usage, and scalability of different components.
"""