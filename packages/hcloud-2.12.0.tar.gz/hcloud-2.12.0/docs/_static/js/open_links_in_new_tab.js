$(document).ready(function () {
  $("a[href^='http']").attr("target", "_blank");
});
