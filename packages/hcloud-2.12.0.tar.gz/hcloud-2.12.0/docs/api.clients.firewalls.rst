FirewallsClient
==================


.. autoclass:: hcloud.firewalls.client.FirewallsClient
    :members:

.. autoclass:: hcloud.firewalls.client.BoundFirewall
    :members:

.. autoclass:: hcloud.firewalls.domain.Firewall
    :members:

.. autoclass:: hcloud.firewalls.domain.FirewallRule
    :members:

.. autoclass:: hcloud.firewalls.domain.FirewallResource
    :members:

.. autoclass:: hcloud.firewalls.domain.CreateFirewallResponse
    :members:
