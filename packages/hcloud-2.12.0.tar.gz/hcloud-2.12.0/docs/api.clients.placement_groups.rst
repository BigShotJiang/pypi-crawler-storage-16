PlacementGroupsClient
=====================


.. autoclass:: hcloud.placement_groups.client.PlacementGroupsClient
    :members:

.. autoclass:: hcloud.placement_groups.client.BoundPlacementGroup
    :members:

.. autoclass:: hcloud.placement_groups.domain.PlacementGroup
    :members:

.. autoclass:: hcloud.placement_groups.domain.CreatePlacementGroupResponse
    :members:
