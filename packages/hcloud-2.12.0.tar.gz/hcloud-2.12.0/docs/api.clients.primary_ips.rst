PrimaryIPsClient
==================


.. autoclass:: hcloud.primary_ips.client.PrimaryIPsClient
    :members:

.. autoclass:: hcloud.primary_ips.client.BoundPrimaryIP
    :members:

.. autoclass:: hcloud.primary_ips.domain.PrimaryIP
    :members:
