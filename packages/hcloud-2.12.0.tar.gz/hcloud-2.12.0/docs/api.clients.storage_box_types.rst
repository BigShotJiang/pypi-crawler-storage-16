StorageBoxTypesClient
=====================

.. autoclass:: hcloud.storage_box_types.client.StorageBoxTypesClient
    :members:

.. autoclass:: hcloud.storage_box_types.client.StorageBoxTypesPageResult
    :members:

.. autoclass:: hcloud.storage_box_types.client.BoundStorageBoxType
    :members:

.. autoclass:: hcloud.storage_box_types.domain.StorageBoxType
    :members:
