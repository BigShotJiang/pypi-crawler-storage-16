ZonesClient
==================


.. autoclass:: hcloud.zones.client.ZonesClient
    :members:

.. autoclass:: hcloud.zones.client.BoundZone
    :members:

.. autoclass:: hcloud.zones.client.BoundZoneRRSet
    :members:

.. autoclass:: hcloud.zones.domain.Zone
    :members:

.. autoclass:: hcloud.zones.domain.ZoneAuthoritativeNameservers
    :members:

.. autoclass:: hcloud.zones.domain.ZonePrimaryNameserver
    :members:

.. autoclass:: hcloud.zones.domain.ZoneRecord
    :members:

.. autoclass:: hcloud.zones.domain.ZoneRRSet
    :members:

.. autoclass:: hcloud.zones.domain.CreateZoneResponse
    :members:
