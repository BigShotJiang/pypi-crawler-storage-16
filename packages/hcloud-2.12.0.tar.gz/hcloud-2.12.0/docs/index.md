:::{toctree}
:maxdepth: 4
:hidden:

self
installation.rst
api.rst
Hetzner Cloud API Documentation <https://docs.hetzner.cloud>
contributing.rst
upgrading.md
changelog.md

:::

:::{include} ../README.md
:::
