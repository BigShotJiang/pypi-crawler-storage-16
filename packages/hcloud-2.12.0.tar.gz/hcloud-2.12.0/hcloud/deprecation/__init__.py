from __future__ import annotations

from .domain import DeprecationInfo

__all__ = ["DeprecationInfo"]
