"""Core package - fundamental components without circular dependencies.

Extracted modules here avoid circular imports between config and commands.
"""
