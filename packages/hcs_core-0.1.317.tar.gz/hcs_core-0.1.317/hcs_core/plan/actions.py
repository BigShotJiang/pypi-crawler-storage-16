class actions:
    create = "create"
    update = "update"
    skip = "skip"
    recreate = "recreate"
    delete = "delete"
