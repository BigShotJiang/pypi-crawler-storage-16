When the version has been updated, do

- bump the version in pyproject.toml
- reflect the changes in changelog

hatch build
