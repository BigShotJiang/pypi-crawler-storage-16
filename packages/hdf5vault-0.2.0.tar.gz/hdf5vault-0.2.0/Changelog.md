## 0.1.1 - 2025-05-08
- Initial release

## 0.1.2 - 2025-05-12
- changed requirement from python-blosc2 to blosc2

## 0.1.3 - 2025-05-12
- changed executable names to hdf5vault_create and hdf5vault_check
- added missing dependencies
- moved main() dedicated function

## 0.1.4 - 2025-05-28
- updated README.md file

## 0.1.5 - 2025-05-28
- expanded documentation, fixed prog name in Argumentparser

## 0.1.6 - 2025-09-05
- added option to create zip archives instead of HDF5 archives
- added parallel extraction tool 
- fixed bug that skipped hidden files

## 0.1.7 - 2025-09-05
- added parallel extraction as standalone command

## 0.1.9 - 2025-12-11
- additional error handler for compression

## 0.2.0 - 2025-12-12
- overlapping file scanning with archiving.
