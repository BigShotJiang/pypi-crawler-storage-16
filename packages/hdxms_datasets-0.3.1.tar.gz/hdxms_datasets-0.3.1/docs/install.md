# Installation


```bash
$ pip install hdxms-datasets
```