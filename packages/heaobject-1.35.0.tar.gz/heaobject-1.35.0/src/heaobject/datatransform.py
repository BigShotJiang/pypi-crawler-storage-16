from .root import AbstractDesktopObject
from abc import ABC


class DataTransform(AbstractDesktopObject, ABC):
    pass
