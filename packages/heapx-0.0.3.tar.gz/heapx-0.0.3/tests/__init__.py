'''
This file marks the `tests/` directory as a Python package. 
While intentionally empty of executable code, its presence is 
architecturally essential for the heapx modle's testing infrastructure.
'''
