# Ping

Methods:

- <code title="get /ping">client.ping.<a href="./src/hedgewise/resources/ping.py">ping</a>() -> object</code>

# Data

Types:

```python
from hedgewise.types import Tick, DataRetrieveResponse
```

Methods:

- <code title="get /v1/data">client.data.<a href="./src/hedgewise/resources/data.py">retrieve</a>() -> <a href="./src/hedgewise/types/data_retrieve_response.py">DataRetrieveResponse</a></code>

# Assets

Types:

```python
from hedgewise.types import AssetListResponse
```

Methods:

- <code title="get /v1/assets">client.assets.<a href="./src/hedgewise/resources/assets/assets.py">list</a>() -> <a href="./src/hedgewise/types/asset_list_response.py">AssetListResponse</a></code>

## Futures

Types:

```python
from hedgewise.types.assets import (
    FutureListResponse,
    FutureGetCalendarResponse,
    FutureGetPricesResponse,
)
```

Methods:

- <code title="get /v1/assets/futures">client.assets.futures.<a href="./src/hedgewise/resources/assets/futures/futures.py">list</a>() -> <a href="./src/hedgewise/types/assets/future_list_response.py">FutureListResponse</a></code>
- <code title="get /v1/assets/futures/calendars/{symbol}">client.assets.futures.<a href="./src/hedgewise/resources/assets/futures/futures.py">get_calendar</a>(symbol, \*\*<a href="src/hedgewise/types/assets/future_get_calendar_params.py">params</a>) -> <a href="./src/hedgewise/types/assets/future_get_calendar_response.py">FutureGetCalendarResponse</a></code>
- <code title="get /v1/assets/futures/prices/{symbol}">client.assets.futures.<a href="./src/hedgewise/resources/assets/futures/futures.py">get_prices</a>(symbol, \*\*<a href="src/hedgewise/types/assets/future_get_prices_params.py">params</a>) -> <a href="./src/hedgewise/types/assets/future_get_prices_response.py">FutureGetPricesResponse</a></code>

### Forecasts

Types:

```python
from hedgewise.types.assets.futures import (
    Asset,
    AssetForecastData,
    AssetForecastModelData,
    MarketDriver,
    MovingAverage,
    ForecastGetResponse,
    ForecastGetLongTermForecastResponse,
    ForecastGetModelsResponse,
    ForecastGetWithOptionsResponse,
)
```

Methods:

- <code title="get /v1/assets/futures/forecasts/{symbol}">client.assets.futures.forecasts.<a href="./src/hedgewise/resources/assets/futures/forecasts.py">get</a>(symbol, \*\*<a href="src/hedgewise/types/assets/futures/forecast_get_params.py">params</a>) -> <a href="./src/hedgewise/types/assets/futures/forecast_get_response.py">ForecastGetResponse</a></code>
- <code title="get /v1/assets/futures/forecasts/{symbol}/long_term_forecast">client.assets.futures.forecasts.<a href="./src/hedgewise/resources/assets/futures/forecasts.py">get_long_term_forecast</a>(symbol, \*\*<a href="src/hedgewise/types/assets/futures/forecast_get_long_term_forecast_params.py">params</a>) -> <a href="./src/hedgewise/types/assets/futures/forecast_get_long_term_forecast_response.py">ForecastGetLongTermForecastResponse</a></code>
- <code title="get /v1/assets/futures/forecasts/{symbol}/models">client.assets.futures.forecasts.<a href="./src/hedgewise/resources/assets/futures/forecasts.py">get_models</a>(symbol, \*\*<a href="src/hedgewise/types/assets/futures/forecast_get_models_params.py">params</a>) -> <a href="./src/hedgewise/types/assets/futures/forecast_get_models_response.py">ForecastGetModelsResponse</a></code>
- <code title="post /v1/assets/futures/forecasts/{symbol}">client.assets.futures.forecasts.<a href="./src/hedgewise/resources/assets/futures/forecasts.py">get_with_options</a>(symbol, \*\*<a href="src/hedgewise/types/assets/futures/forecast_get_with_options_params.py">params</a>) -> <a href="./src/hedgewise/types/assets/futures/forecast_get_with_options_response.py">ForecastGetWithOptionsResponse</a></code>

### Indicators

Types:

```python
from hedgewise.types.assets.futures import IndicatorListResponse, IndicatorGetHedgeResponse
```

Methods:

- <code title="get /v1/assets/futures/indicators">client.assets.futures.indicators.<a href="./src/hedgewise/resources/assets/futures/indicators.py">list</a>() -> <a href="./src/hedgewise/types/assets/futures/indicator_list_response.py">IndicatorListResponse</a></code>
- <code title="get /v1/assets/futures/indicators/hedge/{symbol}">client.assets.futures.indicators.<a href="./src/hedgewise/resources/assets/futures/indicators.py">get_hedge</a>(symbol, \*\*<a href="src/hedgewise/types/assets/futures/indicator_get_hedge_params.py">params</a>) -> <a href="./src/hedgewise/types/assets/futures/indicator_get_hedge_response.py">IndicatorGetHedgeResponse</a></code>

# Forex

Types:

```python
from hedgewise.types import ForexData, ForexRetrieveResponse, ForexListResponse
```

Methods:

- <code title="get /v1/forex/{code}">client.forex.<a href="./src/hedgewise/resources/forex.py">retrieve</a>(code, \*\*<a href="src/hedgewise/types/forex_retrieve_params.py">params</a>) -> <a href="./src/hedgewise/types/forex_retrieve_response.py">ForexRetrieveResponse</a></code>
- <code title="get /v1/forex">client.forex.<a href="./src/hedgewise/resources/forex.py">list</a>() -> <a href="./src/hedgewise/types/forex_list_response.py">ForexListResponse</a></code>

# Features

Types:

```python
from hedgewise.types import (
    FeatureNode,
    TransformedFeature,
    FeatureListResponse,
    FeatureRetrieveHistoricalResponse,
)
```

Methods:

- <code title="get /v1/features">client.features.<a href="./src/hedgewise/resources/features.py">list</a>(\*\*<a href="src/hedgewise/types/feature_list_params.py">params</a>) -> <a href="./src/hedgewise/types/feature_list_response.py">FeatureListResponse</a></code>
- <code title="get /v1/features/weighted_index/">client.features.<a href="./src/hedgewise/resources/features.py">get_weighted_index</a>(\*\*<a href="src/hedgewise/types/feature_get_weighted_index_params.py">params</a>) -> <a href="./src/hedgewise/types/transformed_feature.py">TransformedFeature</a></code>
- <code title="get /v1/features/historical/{feature_code}">client.features.<a href="./src/hedgewise/resources/features.py">retrieve_historical</a>(feature_code, \*\*<a href="src/hedgewise/types/feature_retrieve_historical_params.py">params</a>) -> <a href="./src/hedgewise/types/feature_retrieve_historical_response.py">FeatureRetrieveHistoricalResponse</a></code>
- <code title="get /v1/features/transform/{feature_code}">client.features.<a href="./src/hedgewise/resources/features.py">transform</a>(feature_code, \*\*<a href="src/hedgewise/types/feature_transform_params.py">params</a>) -> <a href="./src/hedgewise/types/transformed_feature.py">TransformedFeature</a></code>

# SectorIndex

Types:

```python
from hedgewise.types import SectorIndexRetrieveResponse
```

Methods:

- <code title="get /v1/sector_index/{asset_class_symbol}">client.sector_index.<a href="./src/hedgewise/resources/sector_index.py">retrieve</a>(asset_class_symbol, \*\*<a href="src/hedgewise/types/sector_index_retrieve_params.py">params</a>) -> <a href="./src/hedgewise/types/sector_index_retrieve_response.py">SectorIndexRetrieveResponse</a></code>

# Models

Types:

```python
from hedgewise.types import ModelRetrieveOutputResponse
```

Methods:

- <code title="get /v1/models/output/{symbol}">client.models.<a href="./src/hedgewise/resources/models/models.py">retrieve_output</a>(symbol, \*\*<a href="src/hedgewise/types/model_retrieve_output_params.py">params</a>) -> <a href="./src/hedgewise/types/model_retrieve_output_response.py">ModelRetrieveOutputResponse</a></code>

## Performance

Types:

```python
from hedgewise.types.models import PerformanceRetrieveResponse, PerformanceListResponse
```

Methods:

- <code title="get /v1/models/performance/{symbol}">client.models.performance.<a href="./src/hedgewise/resources/models/performance.py">retrieve</a>(symbol, \*\*<a href="src/hedgewise/types/models/performance_retrieve_params.py">params</a>) -> <a href="./src/hedgewise/types/models/performance_retrieve_response.py">PerformanceRetrieveResponse</a></code>
- <code title="get /v1/models/performance">client.models.performance.<a href="./src/hedgewise/resources/models/performance.py">list</a>() -> <a href="./src/hedgewise/types/models/performance_list_response.py">PerformanceListResponse</a></code>

# Supply

Types:

```python
from hedgewise.types import (
    FeatureCategory,
    SupplyListResponse,
    SupplyGetPhenologyResponse,
    SupplyRetrieveDataResponse,
)
```

Methods:

- <code title="get /v1/supply">client.supply.<a href="./src/hedgewise/resources/supply.py">list</a>() -> <a href="./src/hedgewise/types/supply_list_response.py">SupplyListResponse</a></code>
- <code title="get /v1/supply/phenology">client.supply.<a href="./src/hedgewise/resources/supply.py">get_phenology</a>(\*\*<a href="src/hedgewise/types/supply_get_phenology_params.py">params</a>) -> <a href="./src/hedgewise/types/supply_get_phenology_response.py">SupplyGetPhenologyResponse</a></code>
- <code title="get /v1/supply/{symbol}">client.supply.<a href="./src/hedgewise/resources/supply.py">retrieve_data</a>(symbol, \*\*<a href="src/hedgewise/types/supply_retrieve_data_params.py">params</a>) -> <a href="./src/hedgewise/types/supply_retrieve_data_response.py">SupplyRetrieveDataResponse</a></code>

# Datasets

Types:

```python
from hedgewise.types import DatasetListResponse
```

Methods:

- <code title="get /v1/datasets">client.datasets.<a href="./src/hedgewise/resources/datasets.py">list</a>(\*\*<a href="src/hedgewise/types/dataset_list_params.py">params</a>) -> <a href="./src/hedgewise/types/dataset_list_response.py">DatasetListResponse</a></code>

# UserRegistration

Methods:

- <code title="post /v1/user_registration">client.user_registration.<a href="./src/hedgewise/resources/user_registration.py">create</a>(\*\*<a href="src/hedgewise/types/user_registration_create_params.py">params</a>) -> None</code>
