# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable, Optional

import httpx

from ...._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ...._utils import maybe_transform, async_maybe_transform
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.assets.futures import (
    forecast_get_params,
    forecast_get_models_params,
    forecast_get_with_options_params,
    forecast_get_long_term_forecast_params,
)
from ....types.assets.futures.forecast_get_response import ForecastGetResponse
from ....types.assets.futures.forecast_get_models_response import ForecastGetModelsResponse
from ....types.assets.futures.forecast_get_with_options_response import ForecastGetWithOptionsResponse
from ....types.assets.futures.forecast_get_long_term_forecast_response import ForecastGetLongTermForecastResponse

__all__ = ["ForecastsResource", "AsyncForecastsResource"]


class ForecastsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> ForecastsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/earthdaily/hedgewise-sdk-python#accessing-raw-response-data-eg-headers
        """
        return ForecastsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ForecastsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/earthdaily/hedgewise-sdk-python#with_streaming_response
        """
        return ForecastsResourceWithStreamingResponse(self)

    def get(
        self,
        symbol: str,
        *,
        end_date: Optional[str] | Omit = omit,
        estimate_uncertainty: bool | Omit = omit,
        get_market_drivers: bool | Omit = omit,
        get_moving_averages: bool | Omit = omit,
        interpolate: bool | Omit = omit,
        model_name: Optional[str] | Omit = omit,
        price_collar_sigma: float | Omit = omit,
        start_date: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ForecastGetResponse:
        """Returns a list of all forecasts made for a given future symbol.

        Forecasts are
        made at various horizons, and can be interpolated to daily values. Forecasted
        prices, estimated lower and upper bounds, and market drivers are available for
        each forecast.

        Args:
          symbol: Future symbol

          end_date: End of forecast window (YYYY-MM-DD). The returned object will contain every
              forecast made between start*date and end_date. \\__Default value* : most recent
              date with forecasts

          estimate_uncertainty: Estimate prediction uncertainty based on recent historical accuracy.

          get_market_drivers: Return market drivers for each forecast.

          get_moving_averages: Return moving averages for each forecast.

          interpolate: Interpolate between forecast horizons and return daily forecast.

          model_name: Select a specific data model to use when generating a forecast for a future
              symbol.

          price_collar_sigma: Apply an empirical price collar to the forecasts. This regulates the forecast
              when it suggests implausibly large price changes. A smaller number results in a
              more aggressive collar. Must be a positive number.

          start_date: Start of forecast window (YYYY-MM-DD). The returned object will contain every
              forecast made between start*date and end_date. \\__Default value* : most recent
              date with forecasts

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not symbol:
            raise ValueError(f"Expected a non-empty value for `symbol` but received {symbol!r}")
        return self._get(
            f"/v1/assets/futures/forecasts/{symbol}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "end_date": end_date,
                        "estimate_uncertainty": estimate_uncertainty,
                        "get_market_drivers": get_market_drivers,
                        "get_moving_averages": get_moving_averages,
                        "interpolate": interpolate,
                        "model_name": model_name,
                        "price_collar_sigma": price_collar_sigma,
                        "start_date": start_date,
                    },
                    forecast_get_params.ForecastGetParams,
                ),
            ),
            cast_to=ForecastGetResponse,
        )

    def get_long_term_forecast(
        self,
        symbol: str,
        *,
        end_date: Optional[str] | Omit = omit,
        horizon: Optional[int] | Omit = omit,
        rollover_type: Optional[str] | Omit = omit,
        start_date: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ForecastGetLongTermForecastResponse:
        """
        Returns a list of booleans indicating whether the price of the given future is
        expected to increase over the next 12 months.

        Args:
          symbol: Future symbol

          end_date: End of forecast window (YYYY-MM-DD). The returned object will contain every
              forecast made between start*date and end_date. \\__Default value* : most recent
              date with forecasts

          horizon: Number of months to forecast. _Default value_ : Shortest available term for
              requested symbol.

          rollover_type: Which rollover method to use. _Default value_ : hist_vol

          start_date: Start of forecast window (YYYY-MM-DD). The returned object will contain every
              forecast made between start*date and end_date. \\__Default value* : most recent
              date with forecasts

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not symbol:
            raise ValueError(f"Expected a non-empty value for `symbol` but received {symbol!r}")
        return self._get(
            f"/v1/assets/futures/forecasts/{symbol}/long_term_forecast",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "end_date": end_date,
                        "horizon": horizon,
                        "rollover_type": rollover_type,
                        "start_date": start_date,
                    },
                    forecast_get_long_term_forecast_params.ForecastGetLongTermForecastParams,
                ),
            ),
            cast_to=ForecastGetLongTermForecastResponse,
        )

    def get_models(
        self,
        symbol: str,
        *,
        details: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ForecastGetModelsResponse:
        """Return a list of all forecast models for a given future symbol.

        Forecast models
        generate forecasts at various horizons

        Args:
          symbol: Future symbol

          details: Expose additional details about the models available

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not symbol:
            raise ValueError(f"Expected a non-empty value for `symbol` but received {symbol!r}")
        return self._get(
            f"/v1/assets/futures/forecasts/{symbol}/models",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform({"details": details}, forecast_get_models_params.ForecastGetModelsParams),
            ),
            cast_to=ForecastGetModelsResponse,
        )

    def get_with_options(
        self,
        symbol: str,
        *,
        strategy: Iterable[forecast_get_with_options_params.Strategy],
        concatenate_trajectories: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ForecastGetWithOptionsResponse:
        """
        Returns a list of all forecasts made for a given future symbol, date range, and
        model name. Forecasts are made at various horizons, and can be interpolated to
        daily values. Forecasted prices, estimated lower and upper bounds, and market
        drivers are available for each forecast.

        Args:
          symbol: Future symbol

          concatenate_trajectories: Return a concatenated version of the requested trajectories as if it was coming
              from a single model. Some restrictions apply

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not symbol:
            raise ValueError(f"Expected a non-empty value for `symbol` but received {symbol!r}")
        return self._post(
            f"/v1/assets/futures/forecasts/{symbol}",
            body=maybe_transform({"strategy": strategy}, forecast_get_with_options_params.ForecastGetWithOptionsParams),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {"concatenate_trajectories": concatenate_trajectories},
                    forecast_get_with_options_params.ForecastGetWithOptionsParams,
                ),
            ),
            cast_to=ForecastGetWithOptionsResponse,
        )


class AsyncForecastsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncForecastsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/earthdaily/hedgewise-sdk-python#accessing-raw-response-data-eg-headers
        """
        return AsyncForecastsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncForecastsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/earthdaily/hedgewise-sdk-python#with_streaming_response
        """
        return AsyncForecastsResourceWithStreamingResponse(self)

    async def get(
        self,
        symbol: str,
        *,
        end_date: Optional[str] | Omit = omit,
        estimate_uncertainty: bool | Omit = omit,
        get_market_drivers: bool | Omit = omit,
        get_moving_averages: bool | Omit = omit,
        interpolate: bool | Omit = omit,
        model_name: Optional[str] | Omit = omit,
        price_collar_sigma: float | Omit = omit,
        start_date: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ForecastGetResponse:
        """Returns a list of all forecasts made for a given future symbol.

        Forecasts are
        made at various horizons, and can be interpolated to daily values. Forecasted
        prices, estimated lower and upper bounds, and market drivers are available for
        each forecast.

        Args:
          symbol: Future symbol

          end_date: End of forecast window (YYYY-MM-DD). The returned object will contain every
              forecast made between start*date and end_date. \\__Default value* : most recent
              date with forecasts

          estimate_uncertainty: Estimate prediction uncertainty based on recent historical accuracy.

          get_market_drivers: Return market drivers for each forecast.

          get_moving_averages: Return moving averages for each forecast.

          interpolate: Interpolate between forecast horizons and return daily forecast.

          model_name: Select a specific data model to use when generating a forecast for a future
              symbol.

          price_collar_sigma: Apply an empirical price collar to the forecasts. This regulates the forecast
              when it suggests implausibly large price changes. A smaller number results in a
              more aggressive collar. Must be a positive number.

          start_date: Start of forecast window (YYYY-MM-DD). The returned object will contain every
              forecast made between start*date and end_date. \\__Default value* : most recent
              date with forecasts

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not symbol:
            raise ValueError(f"Expected a non-empty value for `symbol` but received {symbol!r}")
        return await self._get(
            f"/v1/assets/futures/forecasts/{symbol}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "end_date": end_date,
                        "estimate_uncertainty": estimate_uncertainty,
                        "get_market_drivers": get_market_drivers,
                        "get_moving_averages": get_moving_averages,
                        "interpolate": interpolate,
                        "model_name": model_name,
                        "price_collar_sigma": price_collar_sigma,
                        "start_date": start_date,
                    },
                    forecast_get_params.ForecastGetParams,
                ),
            ),
            cast_to=ForecastGetResponse,
        )

    async def get_long_term_forecast(
        self,
        symbol: str,
        *,
        end_date: Optional[str] | Omit = omit,
        horizon: Optional[int] | Omit = omit,
        rollover_type: Optional[str] | Omit = omit,
        start_date: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ForecastGetLongTermForecastResponse:
        """
        Returns a list of booleans indicating whether the price of the given future is
        expected to increase over the next 12 months.

        Args:
          symbol: Future symbol

          end_date: End of forecast window (YYYY-MM-DD). The returned object will contain every
              forecast made between start*date and end_date. \\__Default value* : most recent
              date with forecasts

          horizon: Number of months to forecast. _Default value_ : Shortest available term for
              requested symbol.

          rollover_type: Which rollover method to use. _Default value_ : hist_vol

          start_date: Start of forecast window (YYYY-MM-DD). The returned object will contain every
              forecast made between start*date and end_date. \\__Default value* : most recent
              date with forecasts

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not symbol:
            raise ValueError(f"Expected a non-empty value for `symbol` but received {symbol!r}")
        return await self._get(
            f"/v1/assets/futures/forecasts/{symbol}/long_term_forecast",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "end_date": end_date,
                        "horizon": horizon,
                        "rollover_type": rollover_type,
                        "start_date": start_date,
                    },
                    forecast_get_long_term_forecast_params.ForecastGetLongTermForecastParams,
                ),
            ),
            cast_to=ForecastGetLongTermForecastResponse,
        )

    async def get_models(
        self,
        symbol: str,
        *,
        details: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ForecastGetModelsResponse:
        """Return a list of all forecast models for a given future symbol.

        Forecast models
        generate forecasts at various horizons

        Args:
          symbol: Future symbol

          details: Expose additional details about the models available

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not symbol:
            raise ValueError(f"Expected a non-empty value for `symbol` but received {symbol!r}")
        return await self._get(
            f"/v1/assets/futures/forecasts/{symbol}/models",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"details": details}, forecast_get_models_params.ForecastGetModelsParams
                ),
            ),
            cast_to=ForecastGetModelsResponse,
        )

    async def get_with_options(
        self,
        symbol: str,
        *,
        strategy: Iterable[forecast_get_with_options_params.Strategy],
        concatenate_trajectories: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ForecastGetWithOptionsResponse:
        """
        Returns a list of all forecasts made for a given future symbol, date range, and
        model name. Forecasts are made at various horizons, and can be interpolated to
        daily values. Forecasted prices, estimated lower and upper bounds, and market
        drivers are available for each forecast.

        Args:
          symbol: Future symbol

          concatenate_trajectories: Return a concatenated version of the requested trajectories as if it was coming
              from a single model. Some restrictions apply

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not symbol:
            raise ValueError(f"Expected a non-empty value for `symbol` but received {symbol!r}")
        return await self._post(
            f"/v1/assets/futures/forecasts/{symbol}",
            body=await async_maybe_transform(
                {"strategy": strategy}, forecast_get_with_options_params.ForecastGetWithOptionsParams
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"concatenate_trajectories": concatenate_trajectories},
                    forecast_get_with_options_params.ForecastGetWithOptionsParams,
                ),
            ),
            cast_to=ForecastGetWithOptionsResponse,
        )


class ForecastsResourceWithRawResponse:
    def __init__(self, forecasts: ForecastsResource) -> None:
        self._forecasts = forecasts

        self.get = to_raw_response_wrapper(
            forecasts.get,
        )
        self.get_long_term_forecast = to_raw_response_wrapper(
            forecasts.get_long_term_forecast,
        )
        self.get_models = to_raw_response_wrapper(
            forecasts.get_models,
        )
        self.get_with_options = to_raw_response_wrapper(
            forecasts.get_with_options,
        )


class AsyncForecastsResourceWithRawResponse:
    def __init__(self, forecasts: AsyncForecastsResource) -> None:
        self._forecasts = forecasts

        self.get = async_to_raw_response_wrapper(
            forecasts.get,
        )
        self.get_long_term_forecast = async_to_raw_response_wrapper(
            forecasts.get_long_term_forecast,
        )
        self.get_models = async_to_raw_response_wrapper(
            forecasts.get_models,
        )
        self.get_with_options = async_to_raw_response_wrapper(
            forecasts.get_with_options,
        )


class ForecastsResourceWithStreamingResponse:
    def __init__(self, forecasts: ForecastsResource) -> None:
        self._forecasts = forecasts

        self.get = to_streamed_response_wrapper(
            forecasts.get,
        )
        self.get_long_term_forecast = to_streamed_response_wrapper(
            forecasts.get_long_term_forecast,
        )
        self.get_models = to_streamed_response_wrapper(
            forecasts.get_models,
        )
        self.get_with_options = to_streamed_response_wrapper(
            forecasts.get_with_options,
        )


class AsyncForecastsResourceWithStreamingResponse:
    def __init__(self, forecasts: AsyncForecastsResource) -> None:
        self._forecasts = forecasts

        self.get = async_to_streamed_response_wrapper(
            forecasts.get,
        )
        self.get_long_term_forecast = async_to_streamed_response_wrapper(
            forecasts.get_long_term_forecast,
        )
        self.get_models = async_to_streamed_response_wrapper(
            forecasts.get_models,
        )
        self.get_with_options = async_to_streamed_response_wrapper(
            forecasts.get_with_options,
        )
