# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional

import httpx

from ..types import dataset_list_params
from .._types import Body, Omit, Query, Headers, NotGiven, SequenceNotStr, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.dataset_list_response import DatasetListResponse

__all__ = ["DatasetsResource", "AsyncDatasetsResource"]


class DatasetsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> DatasetsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/earthdaily/hedgewise-sdk-python#accessing-raw-response-data-eg-headers
        """
        return DatasetsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> DatasetsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/earthdaily/hedgewise-sdk-python#with_streaming_response
        """
        return DatasetsResourceWithStreamingResponse(self)

    def list(
        self,
        *,
        limit: int,
        offset: int,
        countries: SequenceNotStr[str] | Omit = omit,
        dataset_keys: SequenceNotStr[str] | Omit = omit,
        favorites_only: Optional[bool] | Omit = omit,
        frequencies: SequenceNotStr[str] | Omit = omit,
        phenology_stages: SequenceNotStr[str] | Omit = omit,
        search: Optional[str] | Omit = omit,
        sources: SequenceNotStr[str] | Omit = omit,
        statistic_types: SequenceNotStr[str] | Omit = omit,
        symbols: SequenceNotStr[str] | Omit = omit,
        variable_types: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DatasetListResponse:
        """Returns a list of all datasets.

        Datasets are collections of features grouped by
        interest, relevance, commodity, and/or asset class.

        Args:
          limit: Maximum number of results to return (required). Maximum is 1000.

          offset: Number of results to skip before returning (required)

          countries: Filter by country on all features attached to the dataset

          dataset_keys: Dataset key to which the features belong

          favorites_only: Filter to datasets containing only favorite features for current user

          frequencies: Filter by frequency on all features attached to the dataset

          phenology_stages: Filter by phenology_stage or phenology_phase on all features attached to the
              dataset

          search: Search string to match against feature fields.

          sources: Filter by source on all features attached to the dataset

          statistic_types: Filter by statistic_type on all features attached to the dataset

          symbols: List of futures contract symbols

          variable_types: Filter by variable_type on all features attached to the dataset

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/v1/datasets",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "limit": limit,
                        "offset": offset,
                        "countries": countries,
                        "dataset_keys": dataset_keys,
                        "favorites_only": favorites_only,
                        "frequencies": frequencies,
                        "phenology_stages": phenology_stages,
                        "search": search,
                        "sources": sources,
                        "statistic_types": statistic_types,
                        "symbols": symbols,
                        "variable_types": variable_types,
                    },
                    dataset_list_params.DatasetListParams,
                ),
            ),
            cast_to=DatasetListResponse,
        )


class AsyncDatasetsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncDatasetsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/earthdaily/hedgewise-sdk-python#accessing-raw-response-data-eg-headers
        """
        return AsyncDatasetsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncDatasetsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/earthdaily/hedgewise-sdk-python#with_streaming_response
        """
        return AsyncDatasetsResourceWithStreamingResponse(self)

    async def list(
        self,
        *,
        limit: int,
        offset: int,
        countries: SequenceNotStr[str] | Omit = omit,
        dataset_keys: SequenceNotStr[str] | Omit = omit,
        favorites_only: Optional[bool] | Omit = omit,
        frequencies: SequenceNotStr[str] | Omit = omit,
        phenology_stages: SequenceNotStr[str] | Omit = omit,
        search: Optional[str] | Omit = omit,
        sources: SequenceNotStr[str] | Omit = omit,
        statistic_types: SequenceNotStr[str] | Omit = omit,
        symbols: SequenceNotStr[str] | Omit = omit,
        variable_types: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> DatasetListResponse:
        """Returns a list of all datasets.

        Datasets are collections of features grouped by
        interest, relevance, commodity, and/or asset class.

        Args:
          limit: Maximum number of results to return (required). Maximum is 1000.

          offset: Number of results to skip before returning (required)

          countries: Filter by country on all features attached to the dataset

          dataset_keys: Dataset key to which the features belong

          favorites_only: Filter to datasets containing only favorite features for current user

          frequencies: Filter by frequency on all features attached to the dataset

          phenology_stages: Filter by phenology_stage or phenology_phase on all features attached to the
              dataset

          search: Search string to match against feature fields.

          sources: Filter by source on all features attached to the dataset

          statistic_types: Filter by statistic_type on all features attached to the dataset

          symbols: List of futures contract symbols

          variable_types: Filter by variable_type on all features attached to the dataset

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/v1/datasets",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "limit": limit,
                        "offset": offset,
                        "countries": countries,
                        "dataset_keys": dataset_keys,
                        "favorites_only": favorites_only,
                        "frequencies": frequencies,
                        "phenology_stages": phenology_stages,
                        "search": search,
                        "sources": sources,
                        "statistic_types": statistic_types,
                        "symbols": symbols,
                        "variable_types": variable_types,
                    },
                    dataset_list_params.DatasetListParams,
                ),
            ),
            cast_to=DatasetListResponse,
        )


class DatasetsResourceWithRawResponse:
    def __init__(self, datasets: DatasetsResource) -> None:
        self._datasets = datasets

        self.list = to_raw_response_wrapper(
            datasets.list,
        )


class AsyncDatasetsResourceWithRawResponse:
    def __init__(self, datasets: AsyncDatasetsResource) -> None:
        self._datasets = datasets

        self.list = async_to_raw_response_wrapper(
            datasets.list,
        )


class DatasetsResourceWithStreamingResponse:
    def __init__(self, datasets: DatasetsResource) -> None:
        self._datasets = datasets

        self.list = to_streamed_response_wrapper(
            datasets.list,
        )


class AsyncDatasetsResourceWithStreamingResponse:
    def __init__(self, datasets: AsyncDatasetsResource) -> None:
        self._datasets = datasets

        self.list = async_to_streamed_response_wrapper(
            datasets.list,
        )
