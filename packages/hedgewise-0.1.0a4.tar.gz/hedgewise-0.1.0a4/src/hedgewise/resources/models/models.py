# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional

import httpx

from ...types import model_retrieve_output_params
from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .performance import (
    PerformanceResource,
    AsyncPerformanceResource,
    PerformanceResourceWithRawResponse,
    AsyncPerformanceResourceWithRawResponse,
    PerformanceResourceWithStreamingResponse,
    AsyncPerformanceResourceWithStreamingResponse,
)
from ..._base_client import make_request_options
from ...types.model_retrieve_output_response import ModelRetrieveOutputResponse

__all__ = ["ModelsResource", "AsyncModelsResource"]


class ModelsResource(SyncAPIResource):
    @cached_property
    def performance(self) -> PerformanceResource:
        return PerformanceResource(self._client)

    @cached_property
    def with_raw_response(self) -> ModelsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/earthdaily/hedgewise-sdk-python#accessing-raw-response-data-eg-headers
        """
        return ModelsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ModelsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/earthdaily/hedgewise-sdk-python#with_streaming_response
        """
        return ModelsResourceWithStreamingResponse(self)

    def retrieve_output(
        self,
        symbol: str,
        *,
        end_date: Optional[str] | Omit = omit,
        model: Optional[str] | Omit = omit,
        start_date: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ModelRetrieveOutputResponse:
        """Returns all output from a requested model over a given time span.

        The model

        Args:
          symbol: Future symbol

          end_date: End of forecast window (YYYY-MM-DD). The returned object will contain every
              forecast made between start*date and end_date. \\__Default value* : most recent
              date with forecasts

          model: Model name.

          start_date: Start of forecast window (YYYY-MM-DD). The returned object will contain every
              forecast made between start*date and end_date. \\__Default value* : most recent
              date with forecasts

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not symbol:
            raise ValueError(f"Expected a non-empty value for `symbol` but received {symbol!r}")
        return self._get(
            f"/v1/models/output/{symbol}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "end_date": end_date,
                        "model": model,
                        "start_date": start_date,
                    },
                    model_retrieve_output_params.ModelRetrieveOutputParams,
                ),
            ),
            cast_to=ModelRetrieveOutputResponse,
        )


class AsyncModelsResource(AsyncAPIResource):
    @cached_property
    def performance(self) -> AsyncPerformanceResource:
        return AsyncPerformanceResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncModelsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/earthdaily/hedgewise-sdk-python#accessing-raw-response-data-eg-headers
        """
        return AsyncModelsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncModelsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/earthdaily/hedgewise-sdk-python#with_streaming_response
        """
        return AsyncModelsResourceWithStreamingResponse(self)

    async def retrieve_output(
        self,
        symbol: str,
        *,
        end_date: Optional[str] | Omit = omit,
        model: Optional[str] | Omit = omit,
        start_date: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ModelRetrieveOutputResponse:
        """Returns all output from a requested model over a given time span.

        The model

        Args:
          symbol: Future symbol

          end_date: End of forecast window (YYYY-MM-DD). The returned object will contain every
              forecast made between start*date and end_date. \\__Default value* : most recent
              date with forecasts

          model: Model name.

          start_date: Start of forecast window (YYYY-MM-DD). The returned object will contain every
              forecast made between start*date and end_date. \\__Default value* : most recent
              date with forecasts

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not symbol:
            raise ValueError(f"Expected a non-empty value for `symbol` but received {symbol!r}")
        return await self._get(
            f"/v1/models/output/{symbol}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "end_date": end_date,
                        "model": model,
                        "start_date": start_date,
                    },
                    model_retrieve_output_params.ModelRetrieveOutputParams,
                ),
            ),
            cast_to=ModelRetrieveOutputResponse,
        )


class ModelsResourceWithRawResponse:
    def __init__(self, models: ModelsResource) -> None:
        self._models = models

        self.retrieve_output = to_raw_response_wrapper(
            models.retrieve_output,
        )

    @cached_property
    def performance(self) -> PerformanceResourceWithRawResponse:
        return PerformanceResourceWithRawResponse(self._models.performance)


class AsyncModelsResourceWithRawResponse:
    def __init__(self, models: AsyncModelsResource) -> None:
        self._models = models

        self.retrieve_output = async_to_raw_response_wrapper(
            models.retrieve_output,
        )

    @cached_property
    def performance(self) -> AsyncPerformanceResourceWithRawResponse:
        return AsyncPerformanceResourceWithRawResponse(self._models.performance)


class ModelsResourceWithStreamingResponse:
    def __init__(self, models: ModelsResource) -> None:
        self._models = models

        self.retrieve_output = to_streamed_response_wrapper(
            models.retrieve_output,
        )

    @cached_property
    def performance(self) -> PerformanceResourceWithStreamingResponse:
        return PerformanceResourceWithStreamingResponse(self._models.performance)


class AsyncModelsResourceWithStreamingResponse:
    def __init__(self, models: AsyncModelsResource) -> None:
        self._models = models

        self.retrieve_output = async_to_streamed_response_wrapper(
            models.retrieve_output,
        )

    @cached_property
    def performance(self) -> AsyncPerformanceResourceWithStreamingResponse:
        return AsyncPerformanceResourceWithStreamingResponse(self._models.performance)
