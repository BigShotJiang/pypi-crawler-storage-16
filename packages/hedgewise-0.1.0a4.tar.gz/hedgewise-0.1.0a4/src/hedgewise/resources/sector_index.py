# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional

import httpx

from ..types import sector_index_retrieve_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.sector_index_retrieve_response import SectorIndexRetrieveResponse

__all__ = ["SectorIndexResource", "AsyncSectorIndexResource"]


class SectorIndexResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> SectorIndexResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/earthdaily/hedgewise-sdk-python#accessing-raw-response-data-eg-headers
        """
        return SectorIndexResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> SectorIndexResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/earthdaily/hedgewise-sdk-python#with_streaming_response
        """
        return SectorIndexResourceWithStreamingResponse(self)

    def retrieve(
        self,
        asset_class_symbol: str,
        *,
        methodology: str,
        end_date: Optional[str] | Omit = omit,
        freq: Optional[str] | Omit = omit,
        start_date: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SectorIndexRetrieveResponse:
        """
        Return the selected sector or asset class index historical values using a
        proprietary methodology and composition

        Args:
          asset_class_symbol: A list of Asset Class (sector) identifier requested. `ALL` can be used to query
              all asset classes indices at the same time

          methodology: The type of indexing methodology requested. Equal weight (`equalweight`) or
              risk-parity (`riskparity`) are supported

          end_date: End of index data window (YYYY-MM-DD)

          freq: By default, time-series are returned using daily time frequency. Request
              resampled data using `weekly` or `monthly` as query parameter

          start_date: Start of the index data window (YYYY-MM-DD) - Index will start at 100 on that
              date

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not asset_class_symbol:
            raise ValueError(f"Expected a non-empty value for `asset_class_symbol` but received {asset_class_symbol!r}")
        return self._get(
            f"/v1/sector_index/{asset_class_symbol}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "methodology": methodology,
                        "end_date": end_date,
                        "freq": freq,
                        "start_date": start_date,
                    },
                    sector_index_retrieve_params.SectorIndexRetrieveParams,
                ),
            ),
            cast_to=SectorIndexRetrieveResponse,
        )


class AsyncSectorIndexResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncSectorIndexResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/earthdaily/hedgewise-sdk-python#accessing-raw-response-data-eg-headers
        """
        return AsyncSectorIndexResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncSectorIndexResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/earthdaily/hedgewise-sdk-python#with_streaming_response
        """
        return AsyncSectorIndexResourceWithStreamingResponse(self)

    async def retrieve(
        self,
        asset_class_symbol: str,
        *,
        methodology: str,
        end_date: Optional[str] | Omit = omit,
        freq: Optional[str] | Omit = omit,
        start_date: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SectorIndexRetrieveResponse:
        """
        Return the selected sector or asset class index historical values using a
        proprietary methodology and composition

        Args:
          asset_class_symbol: A list of Asset Class (sector) identifier requested. `ALL` can be used to query
              all asset classes indices at the same time

          methodology: The type of indexing methodology requested. Equal weight (`equalweight`) or
              risk-parity (`riskparity`) are supported

          end_date: End of index data window (YYYY-MM-DD)

          freq: By default, time-series are returned using daily time frequency. Request
              resampled data using `weekly` or `monthly` as query parameter

          start_date: Start of the index data window (YYYY-MM-DD) - Index will start at 100 on that
              date

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not asset_class_symbol:
            raise ValueError(f"Expected a non-empty value for `asset_class_symbol` but received {asset_class_symbol!r}")
        return await self._get(
            f"/v1/sector_index/{asset_class_symbol}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "methodology": methodology,
                        "end_date": end_date,
                        "freq": freq,
                        "start_date": start_date,
                    },
                    sector_index_retrieve_params.SectorIndexRetrieveParams,
                ),
            ),
            cast_to=SectorIndexRetrieveResponse,
        )


class SectorIndexResourceWithRawResponse:
    def __init__(self, sector_index: SectorIndexResource) -> None:
        self._sector_index = sector_index

        self.retrieve = to_raw_response_wrapper(
            sector_index.retrieve,
        )


class AsyncSectorIndexResourceWithRawResponse:
    def __init__(self, sector_index: AsyncSectorIndexResource) -> None:
        self._sector_index = sector_index

        self.retrieve = async_to_raw_response_wrapper(
            sector_index.retrieve,
        )


class SectorIndexResourceWithStreamingResponse:
    def __init__(self, sector_index: SectorIndexResource) -> None:
        self._sector_index = sector_index

        self.retrieve = to_streamed_response_wrapper(
            sector_index.retrieve,
        )


class AsyncSectorIndexResourceWithStreamingResponse:
    def __init__(self, sector_index: AsyncSectorIndexResource) -> None:
        self._sector_index = sector_index

        self.retrieve = async_to_streamed_response_wrapper(
            sector_index.retrieve,
        )
