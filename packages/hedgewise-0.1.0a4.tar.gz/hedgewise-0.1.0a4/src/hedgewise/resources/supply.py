# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional

import httpx

from ..types import supply_get_phenology_params, supply_retrieve_data_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.supply_list_response import SupplyListResponse
from ..types.supply_get_phenology_response import SupplyGetPhenologyResponse
from ..types.supply_retrieve_data_response import SupplyRetrieveDataResponse

__all__ = ["SupplyResource", "AsyncSupplyResource"]


class SupplyResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> SupplyResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/earthdaily/hedgewise-sdk-python#accessing-raw-response-data-eg-headers
        """
        return SupplyResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> SupplyResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/earthdaily/hedgewise-sdk-python#with_streaming_response
        """
        return SupplyResourceWithStreamingResponse(self)

    def list(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SupplyListResponse:
        """Returns a list of all commodities that have supply models available.

        Country
        codes follow the UN/LOCODE standard:
        https://unece.org/trade/cefact/unlocode-code-list-country-and-territory
        """
        return self._get(
            "/v1/supply",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SupplyListResponse,
        )

    def get_phenology(
        self,
        *,
        symbol: str,
        country_region: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SupplyGetPhenologyResponse:
        """
        Returns the month day of the beginning and end of phenology stages for a given
        crop and region

        Args:
          symbol: Asset symbol

          country_region: Country name or region

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/v1/supply/phenology",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "symbol": symbol,
                        "country_region": country_region,
                    },
                    supply_get_phenology_params.SupplyGetPhenologyParams,
                ),
            ),
            cast_to=SupplyGetPhenologyResponse,
        )

    def retrieve_data(
        self,
        symbol: str,
        *,
        country_code: Optional[str] | Omit = omit,
        end_date: Optional[str] | Omit = omit,
        get_feature_contributions: bool | Omit = omit,
        model: str | Omit = omit,
        start_date: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SupplyRetrieveDataResponse:
        """
        Returns historical and forecasted supply data for a given commodity and country.
        Country codes follow the UN/LOCODE standard:
        https://unece.org/trade/cefact/unlocode-code-list-country-and-territory

        Args:
          symbol: Asset symbol

          country_code: Country code (UN/LOCODE). If blank, return global data.

          end_date: End of date range for supply forecasts (YYYY-MM-DD)

          get_feature_contributions: Return feature contributions for requested forecasts.

          model: Supply model to use for forecasting.

          start_date: Start of date range for supply forecasts (YYYY-MM-DD)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not symbol:
            raise ValueError(f"Expected a non-empty value for `symbol` but received {symbol!r}")
        return self._get(
            f"/v1/supply/{symbol}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "country_code": country_code,
                        "end_date": end_date,
                        "get_feature_contributions": get_feature_contributions,
                        "model": model,
                        "start_date": start_date,
                    },
                    supply_retrieve_data_params.SupplyRetrieveDataParams,
                ),
            ),
            cast_to=SupplyRetrieveDataResponse,
        )


class AsyncSupplyResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncSupplyResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/earthdaily/hedgewise-sdk-python#accessing-raw-response-data-eg-headers
        """
        return AsyncSupplyResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncSupplyResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/earthdaily/hedgewise-sdk-python#with_streaming_response
        """
        return AsyncSupplyResourceWithStreamingResponse(self)

    async def list(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SupplyListResponse:
        """Returns a list of all commodities that have supply models available.

        Country
        codes follow the UN/LOCODE standard:
        https://unece.org/trade/cefact/unlocode-code-list-country-and-territory
        """
        return await self._get(
            "/v1/supply",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SupplyListResponse,
        )

    async def get_phenology(
        self,
        *,
        symbol: str,
        country_region: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SupplyGetPhenologyResponse:
        """
        Returns the month day of the beginning and end of phenology stages for a given
        crop and region

        Args:
          symbol: Asset symbol

          country_region: Country name or region

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/v1/supply/phenology",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "symbol": symbol,
                        "country_region": country_region,
                    },
                    supply_get_phenology_params.SupplyGetPhenologyParams,
                ),
            ),
            cast_to=SupplyGetPhenologyResponse,
        )

    async def retrieve_data(
        self,
        symbol: str,
        *,
        country_code: Optional[str] | Omit = omit,
        end_date: Optional[str] | Omit = omit,
        get_feature_contributions: bool | Omit = omit,
        model: str | Omit = omit,
        start_date: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SupplyRetrieveDataResponse:
        """
        Returns historical and forecasted supply data for a given commodity and country.
        Country codes follow the UN/LOCODE standard:
        https://unece.org/trade/cefact/unlocode-code-list-country-and-territory

        Args:
          symbol: Asset symbol

          country_code: Country code (UN/LOCODE). If blank, return global data.

          end_date: End of date range for supply forecasts (YYYY-MM-DD)

          get_feature_contributions: Return feature contributions for requested forecasts.

          model: Supply model to use for forecasting.

          start_date: Start of date range for supply forecasts (YYYY-MM-DD)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not symbol:
            raise ValueError(f"Expected a non-empty value for `symbol` but received {symbol!r}")
        return await self._get(
            f"/v1/supply/{symbol}",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "country_code": country_code,
                        "end_date": end_date,
                        "get_feature_contributions": get_feature_contributions,
                        "model": model,
                        "start_date": start_date,
                    },
                    supply_retrieve_data_params.SupplyRetrieveDataParams,
                ),
            ),
            cast_to=SupplyRetrieveDataResponse,
        )


class SupplyResourceWithRawResponse:
    def __init__(self, supply: SupplyResource) -> None:
        self._supply = supply

        self.list = to_raw_response_wrapper(
            supply.list,
        )
        self.get_phenology = to_raw_response_wrapper(
            supply.get_phenology,
        )
        self.retrieve_data = to_raw_response_wrapper(
            supply.retrieve_data,
        )


class AsyncSupplyResourceWithRawResponse:
    def __init__(self, supply: AsyncSupplyResource) -> None:
        self._supply = supply

        self.list = async_to_raw_response_wrapper(
            supply.list,
        )
        self.get_phenology = async_to_raw_response_wrapper(
            supply.get_phenology,
        )
        self.retrieve_data = async_to_raw_response_wrapper(
            supply.retrieve_data,
        )


class SupplyResourceWithStreamingResponse:
    def __init__(self, supply: SupplyResource) -> None:
        self._supply = supply

        self.list = to_streamed_response_wrapper(
            supply.list,
        )
        self.get_phenology = to_streamed_response_wrapper(
            supply.get_phenology,
        )
        self.retrieve_data = to_streamed_response_wrapper(
            supply.retrieve_data,
        )


class AsyncSupplyResourceWithStreamingResponse:
    def __init__(self, supply: AsyncSupplyResource) -> None:
        self._supply = supply

        self.list = async_to_streamed_response_wrapper(
            supply.list,
        )
        self.get_phenology = async_to_streamed_response_wrapper(
            supply.get_phenology,
        )
        self.retrieve_data = async_to_streamed_response_wrapper(
            supply.retrieve_data,
        )
