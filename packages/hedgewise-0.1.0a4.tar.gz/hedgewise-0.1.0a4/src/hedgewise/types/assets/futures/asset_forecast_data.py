# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from .asset import Asset
from ...tick import Tick
from ...._models import BaseModel
from .market_driver import MarketDriver
from .moving_average import MovingAverage

__all__ = ["AssetForecastData", "Contract", "ContractForecast", "ContractForecastClosePriceTrajectory"]


class ContractForecastClosePriceTrajectory(BaseModel):
    close_price: float

    date: datetime

    target_date_contract: str

    interpolated: Optional[bool] = None

    lower_bounds: Optional[List[float]] = None

    sigmas: Optional[List[float]] = None

    upper_bounds: Optional[List[float]] = None


class ContractForecast(BaseModel):
    close_price_trajectory: List[ContractForecastClosePriceTrajectory]

    forecast_date: datetime

    model: str


class Contract(BaseModel):
    asset_symbol: str

    forecasts: List[ContractForecast]

    market_drivers: Optional[List[MarketDriver]] = None

    moving_averages: Optional[List[MovingAverage]] = None

    name: str

    symbol: str

    last_tick: Optional[Tick] = None


class AssetForecastData(BaseModel):
    asset: Asset

    contracts: List[Contract]
