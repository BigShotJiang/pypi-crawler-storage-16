# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import date

from pydantic import Field as FieldInfo

from ...._models import BaseModel

__all__ = ["AssetForecastModelData", "Strategy", "StrategyTrajectory"]


class StrategyTrajectory(BaseModel):
    horizon: int

    model: str


class Strategy(BaseModel):
    start_date: date

    trajectory: List[StrategyTrajectory]

    end_date: Optional[date] = None


class AssetForecastModelData(BaseModel):
    display_name: str

    end_date: date

    horizons: List[int]

    indicators: List[str]

    api_model_name: str = FieldInfo(alias="model_name")

    api_model_type: str = FieldInfo(alias="model_type")

    native: bool

    start_date: date

    features: Optional[List[str]] = None

    rolling_mean_windows: Optional[List[int]] = None

    strategy: Optional[List[Strategy]] = None

    target_type: Optional[str] = None
