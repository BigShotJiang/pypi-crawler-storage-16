# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from typing_extensions import Literal

from ...._models import BaseModel
from .asset_forecast_data import AssetForecastData

__all__ = ["ForecastGetWithOptionsResponse"]


class ForecastGetWithOptionsResponse(BaseModel):
    data: List[AssetForecastData]

    success: Literal[True]
