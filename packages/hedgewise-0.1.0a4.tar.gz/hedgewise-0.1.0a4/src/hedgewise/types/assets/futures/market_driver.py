# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from datetime import datetime

from ...._models import BaseModel
from ...feature_category import FeatureCategory

__all__ = ["MarketDriver"]


class MarketDriver(BaseModel):
    categories: List[FeatureCategory]

    forecast_date: datetime

    horizon: int

    model: str

    target_date_contract: str
