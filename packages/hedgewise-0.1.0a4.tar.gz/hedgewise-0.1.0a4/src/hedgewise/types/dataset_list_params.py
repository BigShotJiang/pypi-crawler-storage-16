# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, TypedDict

from .._types import SequenceNotStr

__all__ = ["DatasetListParams"]


class DatasetListParams(TypedDict, total=False):
    limit: Required[int]
    """Maximum number of results to return (required). Maximum is 1000."""

    offset: Required[int]
    """Number of results to skip before returning (required)"""

    countries: SequenceNotStr[str]
    """Filter by country on all features attached to the dataset"""

    dataset_keys: SequenceNotStr[str]
    """Dataset key to which the features belong"""

    favorites_only: Optional[bool]
    """Filter to datasets containing only favorite features for current user"""

    frequencies: SequenceNotStr[str]
    """Filter by frequency on all features attached to the dataset"""

    phenology_stages: SequenceNotStr[str]
    """
    Filter by phenology_stage or phenology_phase on all features attached to the
    dataset
    """

    search: Optional[str]
    """Search string to match against feature fields."""

    sources: SequenceNotStr[str]
    """Filter by source on all features attached to the dataset"""

    statistic_types: SequenceNotStr[str]
    """Filter by statistic_type on all features attached to the dataset"""

    symbols: SequenceNotStr[str]
    """List of futures contract symbols"""

    variable_types: SequenceNotStr[str]
    """Filter by variable_type on all features attached to the dataset"""
