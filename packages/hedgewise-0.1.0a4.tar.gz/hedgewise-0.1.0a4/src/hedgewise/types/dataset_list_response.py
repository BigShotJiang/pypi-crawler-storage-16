# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["DatasetListResponse", "Data"]


class Data(BaseModel):
    """Response model for individual dataset with feature count."""

    id: str

    created_at: datetime

    description: str

    end_date: Optional[datetime] = None

    feature_count: int
    """Number of features associated with this dataset"""

    frequency: Optional[str] = None

    key: str

    name: str

    publisher_id: Optional[str] = None

    publisher_name: str

    start_date: Optional[datetime] = None

    type: str

    updated_at: datetime


class DatasetListResponse(BaseModel):
    data: List[Data]

    success: Literal[True]
