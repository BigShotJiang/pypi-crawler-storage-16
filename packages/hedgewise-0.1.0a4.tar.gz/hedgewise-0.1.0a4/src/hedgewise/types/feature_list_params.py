# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, TypedDict

from .._types import SequenceNotStr

__all__ = ["FeatureListParams"]


class FeatureListParams(TypedDict, total=False):
    limit: Required[int]
    """Maximum number of results to return (required). Maximum is 1000."""

    offset: Required[int]
    """Number of results to skip before returning (required)"""

    countries: Optional[SequenceNotStr[str]]
    """Filter by country"""

    dataset_keys: Optional[SequenceNotStr[str]]
    """Dataset key to which the features"""

    favorites_only: Optional[bool]
    """Filter to only favorite features for current user"""

    features_strength: bool
    """Calculate how strongly a feature affects a given commodity"""

    frequencies: Optional[SequenceNotStr[str]]
    """Filter by frequency"""

    phenology_stages: Optional[SequenceNotStr[str]]
    """Filter by phenology_stage or phenology_phase"""

    search: Optional[str]
    """Search string to match against feature fields."""

    sources: Optional[SequenceNotStr[str]]
    """Filter by source"""

    statistic_types: Optional[SequenceNotStr[str]]
    """Filter by statistic_type"""

    symbols: Optional[SequenceNotStr[str]]
    """Futures contract symbol"""

    variable_types: Optional[SequenceNotStr[str]]
    """Filter by variable_type"""
