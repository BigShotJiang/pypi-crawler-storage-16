# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import TypedDict

__all__ = ["ModelRetrieveOutputParams"]


class ModelRetrieveOutputParams(TypedDict, total=False):
    end_date: Optional[str]
    """End of forecast window (YYYY-MM-DD).

    The returned object will contain every forecast made between start*date and
    end_date. \\__Default value* : most recent date with forecasts
    """

    model: Optional[str]
    """Model name."""

    start_date: Optional[str]
    """Start of forecast window (YYYY-MM-DD).

    The returned object will contain every forecast made between start*date and
    end_date. \\__Default value* : most recent date with forecasts
    """
