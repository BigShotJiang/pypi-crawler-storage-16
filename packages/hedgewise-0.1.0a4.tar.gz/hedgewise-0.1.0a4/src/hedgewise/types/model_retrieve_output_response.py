# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from datetime import datetime
from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["ModelRetrieveOutputResponse", "Data"]


class Data(BaseModel):
    commodity: str

    contract: str

    date: datetime

    forecast: float

    forecast_error: float

    forecast_error_percent: float

    horizon: int

    realized_price: float

    run_date: datetime

    run_date_price: float


class ModelRetrieveOutputResponse(BaseModel):
    data: List[Data]

    success: Literal[True]
