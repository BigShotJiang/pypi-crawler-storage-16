# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, TypedDict

__all__ = ["SectorIndexRetrieveParams"]


class SectorIndexRetrieveParams(TypedDict, total=False):
    methodology: Required[str]
    """The type of indexing methodology requested.

    Equal weight (`equalweight`) or risk-parity (`riskparity`) are supported
    """

    end_date: Optional[str]
    """End of index data window (YYYY-MM-DD)"""

    freq: Optional[str]
    """By default, time-series are returned using daily time frequency.

    Request resampled data using `weekly` or `monthly` as query parameter
    """

    start_date: Optional[str]
    """
    Start of the index data window (YYYY-MM-DD) - Index will start at 100 on that
    date
    """
