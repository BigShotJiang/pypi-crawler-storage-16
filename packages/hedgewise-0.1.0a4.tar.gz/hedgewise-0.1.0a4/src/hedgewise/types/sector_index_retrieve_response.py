# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

import datetime
from typing import List
from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["SectorIndexRetrieveResponse", "Data", "DataData"]


class DataData(BaseModel):
    date: datetime.date

    value: float


class Data(BaseModel):
    asset_class: str

    data: List[DataData]


class SectorIndexRetrieveResponse(BaseModel):
    data: List[Data]

    success: Literal[True]
