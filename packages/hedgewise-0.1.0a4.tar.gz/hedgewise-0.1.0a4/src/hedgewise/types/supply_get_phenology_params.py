# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, TypedDict

__all__ = ["SupplyGetPhenologyParams"]


class SupplyGetPhenologyParams(TypedDict, total=False):
    symbol: Required[str]
    """Asset symbol"""

    country_region: Optional[str]
    """Country name or region"""
