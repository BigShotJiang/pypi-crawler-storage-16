# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from datetime import date
from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["SupplyGetPhenologyResponse", "Data"]


class Data(BaseModel):
    crop: str

    end: date

    location: str

    phenology_phase: str

    start: date


class SupplyGetPhenologyResponse(BaseModel):
    data: List[Data]

    success: Literal[True]
