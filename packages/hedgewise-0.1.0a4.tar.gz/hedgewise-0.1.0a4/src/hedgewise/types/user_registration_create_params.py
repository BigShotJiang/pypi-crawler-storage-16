# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["UserRegistrationCreateParams"]


class UserRegistrationCreateParams(TypedDict, total=False):
    company_name: Required[str]

    email_address: Required[str]

    first_name: Required[str]

    last_name: Required[str]
