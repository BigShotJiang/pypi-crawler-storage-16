# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from hedgewise import Hedgewise, AsyncHedgewise
from tests.utils import assert_matches_type
from hedgewise.types import SectorIndexRetrieveResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestSectorIndex:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_retrieve(self, client: Hedgewise) -> None:
        sector_index = client.sector_index.retrieve(
            asset_class_symbol="GRN",
            methodology="riskparity",
        )
        assert_matches_type(SectorIndexRetrieveResponse, sector_index, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_retrieve_with_all_params(self, client: Hedgewise) -> None:
        sector_index = client.sector_index.retrieve(
            asset_class_symbol="GRN",
            methodology="riskparity",
            end_date="2025-04-25",
            freq="weekly",
            start_date="2025-03-24",
        )
        assert_matches_type(SectorIndexRetrieveResponse, sector_index, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_retrieve(self, client: Hedgewise) -> None:
        response = client.sector_index.with_raw_response.retrieve(
            asset_class_symbol="GRN",
            methodology="riskparity",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        sector_index = response.parse()
        assert_matches_type(SectorIndexRetrieveResponse, sector_index, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_retrieve(self, client: Hedgewise) -> None:
        with client.sector_index.with_streaming_response.retrieve(
            asset_class_symbol="GRN",
            methodology="riskparity",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            sector_index = response.parse()
            assert_matches_type(SectorIndexRetrieveResponse, sector_index, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_retrieve(self, client: Hedgewise) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `asset_class_symbol` but received ''"):
            client.sector_index.with_raw_response.retrieve(
                asset_class_symbol="",
                methodology="riskparity",
            )


class TestAsyncSectorIndex:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_retrieve(self, async_client: AsyncHedgewise) -> None:
        sector_index = await async_client.sector_index.retrieve(
            asset_class_symbol="GRN",
            methodology="riskparity",
        )
        assert_matches_type(SectorIndexRetrieveResponse, sector_index, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_retrieve_with_all_params(self, async_client: AsyncHedgewise) -> None:
        sector_index = await async_client.sector_index.retrieve(
            asset_class_symbol="GRN",
            methodology="riskparity",
            end_date="2025-04-25",
            freq="weekly",
            start_date="2025-03-24",
        )
        assert_matches_type(SectorIndexRetrieveResponse, sector_index, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncHedgewise) -> None:
        response = await async_client.sector_index.with_raw_response.retrieve(
            asset_class_symbol="GRN",
            methodology="riskparity",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        sector_index = await response.parse()
        assert_matches_type(SectorIndexRetrieveResponse, sector_index, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncHedgewise) -> None:
        async with async_client.sector_index.with_streaming_response.retrieve(
            asset_class_symbol="GRN",
            methodology="riskparity",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            sector_index = await response.parse()
            assert_matches_type(SectorIndexRetrieveResponse, sector_index, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncHedgewise) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `asset_class_symbol` but received ''"):
            await async_client.sector_index.with_raw_response.retrieve(
                asset_class_symbol="",
                methodology="riskparity",
            )
