# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from hedgewise import Hedgewise, AsyncHedgewise

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestUserRegistration:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create(self, client: Hedgewise) -> None:
        user_registration = client.user_registration.create(
            company_name="company_name",
            email_address="email_address",
            first_name="first_name",
            last_name="last_name",
        )
        assert user_registration is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Hedgewise) -> None:
        response = client.user_registration.with_raw_response.create(
            company_name="company_name",
            email_address="email_address",
            first_name="first_name",
            last_name="last_name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        user_registration = response.parse()
        assert user_registration is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Hedgewise) -> None:
        with client.user_registration.with_streaming_response.create(
            company_name="company_name",
            email_address="email_address",
            first_name="first_name",
            last_name="last_name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            user_registration = response.parse()
            assert user_registration is None

        assert cast(Any, response.is_closed) is True


class TestAsyncUserRegistration:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncHedgewise) -> None:
        user_registration = await async_client.user_registration.create(
            company_name="company_name",
            email_address="email_address",
            first_name="first_name",
            last_name="last_name",
        )
        assert user_registration is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncHedgewise) -> None:
        response = await async_client.user_registration.with_raw_response.create(
            company_name="company_name",
            email_address="email_address",
            first_name="first_name",
            last_name="last_name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        user_registration = await response.parse()
        assert user_registration is None

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncHedgewise) -> None:
        async with async_client.user_registration.with_streaming_response.create(
            company_name="company_name",
            email_address="email_address",
            first_name="first_name",
            last_name="last_name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            user_registration = await response.parse()
            assert user_registration is None

        assert cast(Any, response.is_closed) is True
