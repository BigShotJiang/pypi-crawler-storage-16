"""
Bundled example traces for Hegelion demo mode.

This package exposes JSONL files that the CLI can load via importlib.resources
so that `hegelion --demo` works from both a source checkout and an installed wheel.
"""
