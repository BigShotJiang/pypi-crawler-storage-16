from .server import main as server_main

__all__ = ["server_main"]
