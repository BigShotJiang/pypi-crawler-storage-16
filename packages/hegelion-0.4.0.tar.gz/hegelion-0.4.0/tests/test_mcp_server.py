"""Tests for model-agnostic MCP server."""

import pytest
from hegelion.mcp.server import call_tool, list_tools


@pytest.mark.asyncio
class TestPromptMCPServer:

    async def test_list_tools(self):
        """Test that all prompt tools are listed."""
        tools = await list_tools()
        tool_names = [t.name for t in tools]

        assert "dialectical_workflow" in tool_names
        assert "dialectical_single_shot" in tool_names
        assert "thesis_prompt" in tool_names
        assert "antithesis_prompt" in tool_names
        assert "synthesis_prompt" in tool_names

    async def test_dialectical_workflow_tool(self):
        """Test dialectical workflow tool execution."""
        args = {"query": "test query"}
        content, workflow = await call_tool("dialectical_workflow", args)

        assert len(content) >= 1
        assert content[-1].type == "text"

        assert workflow["query"] == "test query"
        assert len(workflow["steps"]) >= 3
        assert workflow["instructions"]["response_style"] == "sections"

    async def test_dialectical_single_shot_tool(self):
        """Test single shot prompt tool."""
        args = {"query": "test query", "use_council": True}
        result = await call_tool("dialectical_single_shot", args)

        contents, structured = result
        assert len(contents) == 1
        prompt = contents[0].text
        assert "test query" in prompt
        assert "THE LOGICIAN" in prompt
        assert structured["response_style"] == "sections"

    async def test_thesis_prompt_tool(self):
        """Test thesis prompt tool."""
        args = {"query": "test query"}
        contents, structured = await call_tool("thesis_prompt", args)

        assert len(contents) == 1
        content = contents[0].text
        assert "THESIS PROMPT" in content
        assert "test query" in content
        assert structured["phase"] == "thesis"

    async def test_antithesis_prompt_tool(self):
        """Test antithesis prompt tool."""
        args = {"query": "test query", "thesis": "some thesis"}
        contents, structured = await call_tool("antithesis_prompt", args)

        content = contents[0].text
        assert "ANTITHESIS PROMPT" in content
        assert "test query" in content
        assert "some thesis" in content
        assert structured["phase"] == "antithesis"

    async def test_antithesis_council_prompt_tool(self):
        """Test antithesis prompt tool with council."""
        args = {"query": "test query", "thesis": "some thesis", "use_council": True}
        contents, structured = await call_tool("antithesis_prompt", args)

        content = contents[0].text
        assert "COUNCIL ANTITHESIS PROMPTS" in content
        assert "The Logician" in content
        assert structured["phase"] == "antithesis_council"
        assert len(structured["prompts"]) == 3

    async def test_synthesis_prompt_tool(self):
        """Test synthesis prompt tool."""
        args = {"query": "test query", "thesis": "T", "antithesis": "A"}
        contents, structured = await call_tool("synthesis_prompt", args)

        content = contents[0].text
        assert "SYNTHESIS PROMPT" in content
        assert "T" in content
        assert "A" in content
        assert structured["phase"] == "synthesis"

    async def test_single_prompt_json_response_style(self):
        """Ensure response_style alters the returned prompt."""
        args = {
            "query": "test query",
            "format": "single_prompt",
            "response_style": "json",
        }

        contents, structured = await call_tool("dialectical_workflow", args)

        assert "JSON" in contents[0].text
        assert structured["response_style"] == "json"
