::: helical.models.c2s.Cell2SenConfig
    handler: python
    options:
      show_root_heading: True
      show_source: True