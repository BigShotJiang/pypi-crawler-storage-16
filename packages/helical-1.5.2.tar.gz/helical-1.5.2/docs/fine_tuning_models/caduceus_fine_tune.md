::: helical.models.caduceus.CaduceusFineTuningModel
    handler: python
    options:
      members:
        - train
        - get_outputs
      show_root_heading: false
      show_source: True