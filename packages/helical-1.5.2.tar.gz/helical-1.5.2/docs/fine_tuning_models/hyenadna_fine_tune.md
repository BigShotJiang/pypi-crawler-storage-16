::: helical.models.hyena_dna.HyenaDNAFineTuningModel
    handler: python
    options:
      members:
        - train
        - get_outputs
      show_root_heading: false
      show_source: True