::: helical.models.evo_2.Evo2
    handler: python
    options:
      members:
        - process_data
        - get_embeddings
        - generate
      show_root_heading: True
      show_source: True