::: helical.models.tahoe.Tahoe
    handler: python
    options:
      members:
        - process_data
        - get_embeddings
        - get_transformer_embeddings
        - decode_embeddings
      show_root_heading: True
      show_source: True