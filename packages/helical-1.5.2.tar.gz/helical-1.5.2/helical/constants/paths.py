from pathlib import Path

CACHE_DIR_HELICAL = Path(Path.home(), ".cache", "helical", "models")
