from .model import GenePT
from .genept_config import GenePTConfig
