# Copyright (C) Tahoe Therapeutics 2025. All rights reserved.
from .gene_tokenizer import GeneVocab

__all__ = ["GeneVocab"]
