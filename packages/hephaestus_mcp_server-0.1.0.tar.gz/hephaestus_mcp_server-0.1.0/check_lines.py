#!/usr/bin/env python3

with open("tests/test_component_management.py", "r") as f:
    lines = f.readlines()
    for i, line in enumerate(lines[365:375], 1):
        print(f"{i + 365}: {repr(line)}")
