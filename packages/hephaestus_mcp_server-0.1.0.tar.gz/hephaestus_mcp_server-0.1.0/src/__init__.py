"""Hephaestus MCP Server - Flat package structure."""
