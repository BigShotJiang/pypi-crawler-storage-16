"""Project context model for Hephaestus."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List


@dataclass
class ProjectContext:
    """Comprehensive context information about an Anvil project."""

    # Basic project information
    project_path: Path
    project_name: str
    anvil_version: str = "unknown"

    # Architecture patterns
    theme_type: str = "classic"
    routing_system: str = "none"
    has_reactive: bool = False
    data_layer: str = "unknown"
    layout_system: str = "traditional"

    # Analysis metrics
    modernisation_score: float = 0.0
    generation_mode: str = "legacy-compatible"
    complexity_score: float = 0.0
    maintainability_index: float = 0.0

    # Component analysis
    component_count: int = 0
    form_count: int = 0
    server_function_count: int = 0
    custom_component_count: int = 0

    # Pattern analysis
    detected_patterns: Dict[str, Any] = field(default_factory=dict)
    architecture_patterns: List[str] = field(default_factory=list)
    anti_patterns: List[str] = field(default_factory=list)

    # Recommendations
    performance_opportunities: List[str] = field(default_factory=list)
    breaking_change_risks: List[str] = field(default_factory=list)
    modernisation_suggestions: List[str] = field(default_factory=list)
    security_recommendations: List[str] = field(default_factory=list)

    # Metadata
    analysis_timestamp: str = ""
    analysis_version: str = "2.0"


@dataclass
class AnalysisResult:
    """Result of a project analysis operation."""

    success: bool
    context: ProjectContext | None = None
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    analysis_duration: float = 0.0


@dataclass
class PatternMatch:
    """A detected pattern match."""

    pattern_type: str
    pattern_name: str
    file_path: str
    line_number: int
    confidence: float
    context: str = ""


@dataclass
class PerformanceIssue:
    """A detected performance issue."""

    issue_type: str
    severity: str  # "low", "medium", "high", "critical"
    file_path: str
    line_number: int
    description: str
    recommendation: str
    estimated_impact: str = ""
