"""Response builder for Hephaestus MCP server."""

from __future__ import annotations

from typing import Any

from ..errors.hephaestus_errors import HephaestusError


class ResponseBuilder:
    """Build consistent responses for MCP tools."""

    @staticmethod
    def success(
        data: Any = None, message: str = "Operation completed successfully"
    ) -> dict:
        """Build a success response."""
        response = {"success": True, "message": message}
        if data is not None:
            response["data"] = data
        return response

    @staticmethod
    def error(error: HephaestusError, suggestion: str | None = None) -> dict:
        """Build an error response."""
        response = {
            "success": False,
            "error": error.message,
            "error_type": error.error_code,
            "error_code": error.error_code,
        }

        if error.context:
            response["context"] = error.context

        if suggestion:
            response["suggestion"] = suggestion

        return response

    @staticmethod
    def validation_error(errors: list[str], suggestion: str | None = None) -> dict:
        """Build a validation error response."""
        return ResponseBuilder.error(
            HephaestusError(
                f"Validation failed: {'; '.join(errors)}", "VALIDATION_ERROR"
            ),
            suggestion or "Please check your input parameters and try again",
        )

    @staticmethod
    def analysis_error(
        error: str, project_path: str | None = None, suggestion: str | None = None
    ) -> dict:
        """Build an analysis error response."""
        from ..errors.hephaestus_errors import ProjectAnalysisError

        return ResponseBuilder.error(
            ProjectAnalysisError(error, project_path),
            suggestion
            or "Please check that the project path is correct and the project is a valid Anvil project",
        )

    @staticmethod
    def generation_error(
        error: str,
        form_config: dict | None = None,
        output_path: str | None = None,
        suggestion: str | None = None,
    ) -> dict:
        """Build a generation error response."""
        from ..errors.hephaestus_errors import FormGenerationError

        return ResponseBuilder.error(
            FormGenerationError(error, form_config, output_path),
            suggestion or "Please check your form configuration and output path",
        )

    @staticmethod
    def configuration_error(
        error: str, config_key: str | None = None, suggestion: str | None = None
    ) -> dict:
        """Build a configuration error response."""
        from ..errors.hephaestus_errors import ConfigurationError

        return ResponseBuilder.error(
            ConfigurationError(error, config_key),
            suggestion or "Please check your configuration settings",
        )

    @staticmethod
    def dependency_error(
        error: str, service_type: str | None = None, suggestion: str | None = None
    ) -> dict:
        """Build a dependency injection error response."""
        from ..errors.hephaestus_errors import DependencyInjectionError

        return ResponseBuilder.error(
            DependencyInjectionError(error, service_type),
            suggestion or "Please check your dependency injection configuration",
        )
