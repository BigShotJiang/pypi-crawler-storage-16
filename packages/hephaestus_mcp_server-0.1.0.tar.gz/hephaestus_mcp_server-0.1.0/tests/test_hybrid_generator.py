"""Test hybrid generator tools."""

import pytest


def test_hybrid_generator_tools_registered(test_container):
    """Test that hybrid generator tools are registered."""
    from src.registry.tool_registry import ToolRegistry

    registry = ToolRegistry(test_container)

    # Get all registered tools (after registration)
    from src.dependencies.container import FileSystem, ProjectManager

    # Create a mock MCP server
    class MockMCP:
        def __init__(self):
            self.tools = []

        def tool(self):
            def decorator(func):
                self.tools.append(func.__name__)
                return func

            return decorator

    mcp = MockMCP()
    registry.register_anvil_tools(mcp)

    # Check that hybrid generator tools are registered
    expected_tools = [
        "generate_hybrid_component",
        "enhance_existing_form",
        "create_migration_enhancement_plan",
    ]

    for tool_name in expected_tools:
        assert tool_name in mcp.tools, (
            f"Hybrid generator tool {tool_name} not registered"
        )


def test_hybrid_generator_tool_parameters(test_container):
    """Test that hybrid generator tools have correct parameters."""
    from src.registry.tool_registry import ToolRegistry

    registry = ToolRegistry(test_container)

    # Create a mock MCP server
    class MockMCP:
        def __init__(self):
            self.tools = {}

        def tool(self):
            def decorator(func):
                self.tools[func.__name__] = func
                return func

            return decorator

    mcp = MockMCP()
    registry.register_anvil_tools(mcp)

    # Check generate_hybrid_component parameters
    tool = registry.get_tool("generate_hybrid_component")
    assert tool is not None, "generate_hybrid_component tool not found"
    assert "component_name" in tool["parameters"]
    assert "component_type" in tool["parameters"]
    assert "properties" in tool["parameters"]
    assert "config" in tool["parameters"]

    # Check enhance_existing_form parameters
    tool = registry.get_tool("enhance_existing_form")
    assert tool is not None, "enhance_existing_form tool not found"
    assert "form_path" in tool["parameters"]
    assert "enhancement_type" in tool["parameters"]
    assert "config" in tool["parameters"]

    # Check create_migration_enhancement_plan parameters
    tool = registry.get_tool("create_migration_enhancement_plan")
    assert tool is not None, "create_migration_enhancement_plan tool not found"
    assert "target_components" in tool["parameters"]
    assert "migration_goals" in tool["parameters"]
    assert "config" in tool["parameters"]
