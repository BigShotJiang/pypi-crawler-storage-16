"""Integration tests for Hephaestus MCP server."""

from __future__ import annotations

import sys
from pathlib import Path

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from src.server import HephaestusMCPServer


def test_server_with_real_mcp_client():
    """Test server communication with real MCP client."""
    from fastmcp import FastMCP

    mcp = FastMCP("integration-test-hephaestus")
    server = HephaestusMCPServer(mcp)

    assert server is not None
    assert server.mcp.name == "integration-test-hephaestus"


def test_server_tool_registration():
    """Test that tools can be registered with the server."""
    from fastmcp import FastMCP

    mcp = FastMCP("tool-test-hephaestus")
    server = HephaestusMCPServer(mcp)

    @mcp.tool()
    def test_tool():
        return "Test tool response"

    assert test_tool is not None


def test_server_startup_and_shutdown():
    """Test server startup and shutdown lifecycle."""
    from fastmcp import FastMCP

    mcp = FastMCP("lifecycle-test-hephaestus")
    server = HephaestusMCPServer(mcp)

    assert server is not None
    assert hasattr(server, "run")
    assert callable(server.run)


def test_server_with_sample_project(sample_anvil_project):
    """Test server operations with sample Anvil project."""
    from fastmcp import FastMCP

    mcp = FastMCP("project-test-hephaestus")
    server = HephaestusMCPServer(mcp)

    assert server is not None
    assert sample_anvil_project.exists()
    assert (sample_anvil_project / "client_code").exists()
    assert (sample_anvil_project / "server_code").exists()
    assert (sample_anvil_project / "app.json").exists()
