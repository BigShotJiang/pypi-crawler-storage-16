"""Tests for the Hephaestus MCP server."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest
from fastmcp import FastMCP

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from src.server import HephaestusMCPServer


def test_server_creation():
    """Test that the server can be created successfully."""
    mcp = FastMCP("test-hephaestus")
    server = HephaestusMCPServer(mcp)

    assert server is not None
    assert server.mcp is mcp


def test_server_run_methods():
    """Test that server run methods exist and are callable."""
    mcp = FastMCP("test-hephaestus")
    server = HephaestusMCPServer(mcp)

    assert hasattr(server, "run")
    assert callable(server.run)


def test_main_function_exists():
    """Test that main function exists and is callable."""
    from src.server import main

    assert callable(main)


def test_server_initialization_with_different_params():
    """Test server initialization with different parameters."""
    mcp = FastMCP("custom-hephaestus")
    server = HephaestusMCPServer(mcp)

    assert server.mcp.name == "custom-hephaestus"


def test_routing_migrator_tools_registered():
    """Test that routing migrator tools are properly registered."""
    from src.registry.tool_registry import ToolRegistry
    from src.dependencies.container import DIContainer, FileSystem, ProjectManager

    mcp = FastMCP("test-hephaestus")
    container = DIContainer()
    # Register required services like in server initialization
    container.register(FileSystem, FileSystem())
    container.register(ProjectManager, ProjectManager(container.get(FileSystem)))

    registry = ToolRegistry(container)
    registry.register_anvil_tools(mcp)

    # Check that routing migrator tools are registered
    routing_tools = [
        "migrate_routing_system",
        "analyze_routing_migration",
        "create_routing_migration_plan",
    ]

    for tool_name in routing_tools:
        tool = registry.get_tool(tool_name)
        assert tool is not None, f"Tool {tool_name} should be registered"
        assert "description" in tool, f"Tool {tool_name} should have description"
        assert "parameters" in tool, f"Tool {tool_name} should have parameters"
        assert "migration" in tool["tags"], (
            f"Tool {tool_name} should have migration tag"
        )
        assert "routing" in tool["tags"], f"Tool {tool_name} should have routing tag"
        assert "phase4" in tool["tags"], f"Tool {tool_name} should have phase4 tag"


def test_layout_migrator_tools_registered():
    """Test that layout migrator tools are properly registered."""
    from src.registry.tool_registry import ToolRegistry
    from src.dependencies.container import DIContainer, FileSystem, ProjectManager

    mcp = FastMCP("test-hephaestus")
    container = DIContainer()
    # Register required services like in server initialization
    container.register(FileSystem, FileSystem())
    container.register(ProjectManager, ProjectManager(container.get(FileSystem)))

    registry = ToolRegistry(container)
    registry.register_anvil_tools(mcp)

    # Check that layout migrator tools are registered
    layout_tools = [
        "modernize_layout_architecture",
        "analyze_layout_migration_feasibility",
        "create_layout_migration_plan",
    ]

    for tool_name in layout_tools:
        tool = registry.get_tool(tool_name)
        assert tool is not None, f"Tool {tool_name} should be registered"
        assert "description" in tool, f"Tool {tool_name} should have description"
        assert "parameters" in tool, f"Tool {tool_name} should have parameters"
        assert "migration" in tool["tags"], (
            f"Tool {tool_name} should have migration tag"
        )
        assert "layouts" in tool["tags"], f"Tool {tool_name} should have layouts tag"
        assert "phase4" in tool["tags"], f"Tool {tool_name} should have phase4 tag"
