# Hephaestus Task Completion Checklist

## Code Quality Requirements

### Before Considering a Task Complete

#### 1. Code Quality Checks
```bash
# Run all quality checks
just lint          # Must pass without errors
just format        # Must format code correctly
just typecheck     # Must pass type checking
```

#### 2. Testing Requirements
```bash
# Run test suite
just test          # All tests must pass
just test-coverage # Maintain or improve coverage
```

#### 3. Build Verification
```bash
# Ensure package builds correctly
just build         # Must build without errors
```

## Task-Specific Requirements

### MCP Server Development
- [ ] Server starts without errors
- [ ] Tools are properly registered with FastMCP
- [ ] Error handling is comprehensive
- [ ] Logging is appropriate for debugging
- [ ] Configuration options work correctly
- [ ] Transport modes (stdio/http) function properly

### Anvil Tool Development
- [ ] Tool follows MCP specification
- [ ] Input validation is comprehensive
- [ ] Error messages are clear and helpful
- [ ] Generated code follows Anvil best practices
- [ ] YAML output is valid and properly formatted
- [ ] Component types are validated against Anvil API
- [ ] Context-aware generation works correctly

### Code Generation Features
- [ ] Generated code follows project style conventions
- [ ] Type hints are correct and complete
- [ ] Documentation is appropriate
- [ ] Error handling is robust
- [ ] Performance considerations are addressed
- [ ] Security best practices are followed

### Model Classes Generation
- [ ] Field definitions are correct
- [ ] Relationships are properly defined
- [ ] Validation rules are appropriate
- [ ] Default values are sensible
- [ ] Type annotations are accurate
- [ ] Serialization works correctly

### Reactive Components
- [ ] Signal usage is correct
- [ ] Render effects are optimized
- [ ] Data bindings work properly
- [ ] Performance is acceptable
- [ ] Memory leaks are avoided
- [ ] Component lifecycle is handled correctly

## Documentation Requirements

### Code Documentation
- [ ] All public functions have docstrings
- [ ] Complex logic is explained
- [ ] Parameters and return values are documented
- [ ] Usage examples are provided where helpful
- [ ] Error conditions are documented

### API Documentation
- [ ] Tool descriptions are clear
- [ ] Parameter specifications are complete
- [ ] Example usage is provided
- [ ] Error conditions are explained
- [ ] Integration examples are included

## Testing Requirements

### Unit Tests
- [ ] All new functions have tests
- [ ] Edge cases are covered
- [ ] Error conditions are tested
- [ ] Mocking is used appropriately
- [ ] Tests are fast and reliable

### Integration Tests
- [ ] MCP server integration works
- [ ] Tool execution is tested end-to-end
- [ ] Error handling is verified
- [ ] Performance is acceptable
- [ ] Resource cleanup is verified

### Manual Testing
- [ ] Server starts and runs
- [ ] Tools can be called via MCP client
- [ ] Generated code works in Anvil environment
- [ ] Error scenarios are handled gracefully
- [ ] Performance is acceptable under load

## Security Requirements

### Input Validation
- [ ] All inputs are validated
- [ ] Injection attacks are prevented
- [ ] File access is restricted appropriately
- [ ] Resource limits are enforced
- [ ] Sensitive data is handled securely

### Code Generation Security
- [ ] Generated code doesn't contain vulnerabilities
- [ ] No hardcoded secrets or credentials
- [ ] Proper escaping is used for generated content
- [ ] File permissions are appropriate
- [ ] Resource usage is controlled

## Performance Requirements

### Code Generation Performance
- [ ] Generation is fast enough for interactive use
- [ ] Memory usage is reasonable
- [ ] Large projects are handled efficiently
- [ ] Caching is used where appropriate
- [ ] Resource cleanup is prompt

### Server Performance
- [ ] Server startup time is acceptable
- [ ] Request handling is efficient
- [ ] Concurrent requests are handled properly
- [ ] Memory usage is stable
- [ ] Error handling doesn't impact performance

## Compatibility Requirements

### Python Compatibility
- [ ] Code works on Python 3.13+
- [ ] Dependencies are compatible
- [ ] Type annotations are correct
- [ ] Modern Python features are used appropriately
- [ ] Backward compatibility is considered where relevant

### Anvil Compatibility
- [ ] Generated code works with current Anvil version
- [ ] Component types are valid
- [ ] YAML format is correct
- [ ] Event bindings work properly
- [ ] Data bindings function correctly

### MCP Compatibility
- [ ] Server follows MCP specification
- [ ] Tool definitions are correct
- [ ] Error handling follows MCP patterns
- [ ] Transport protocols work correctly
- [ ] Client integration is seamless

## Final Verification Steps

### 1. Clean Build Test
```bash
# Start from clean state
git clean -fd
uv sync
just build
```

### 2. Full Test Suite
```bash
just test
just lint
just format
just typecheck
```

### 3. Manual Verification
- [ ] Server starts and runs without errors
- [ ] Tools can be called successfully
- [ ] Generated code is valid and functional
- [ ] Documentation is accurate and helpful
- [ ] Performance is acceptable

### 4. Git Readiness
```bash
# Ensure no uncommitted changes
git status

# Review changes before commit
git diff

# Commit with descriptive message
git commit -m "feat: add new feature with comprehensive tests and documentation"
```

## Release Preparation (if applicable)

### Version Management
- [ ] Version number is updated appropriately
- [ ] Changelog is updated
- [ ] Breaking changes are documented
- [ ] Migration guide is provided if needed

### Distribution
- [ ] Package builds correctly
- [ ] Dependencies are specified correctly
- [ ] Entry points work properly
- [ ] Installation instructions are accurate
- [ ] Examples are tested and working

## Post-Task Monitoring

### After Task Completion
- [ ] Monitor for any issues in usage
- [ ] Check performance in real scenarios
- [ ] Gather feedback from users
- [ ] Document any lessons learned
- [ ] Plan improvements for future iterations