"""Error handling for Hephaestus."""

from .hephaestus_errors import (
    HephaestusError,
    ValidationError,
    ProjectAnalysisError,
    FormGenerationError,
    ConfigurationError,
    DependencyInjectionError,
)

__all__ = [
    "HephaestusError",
    "ValidationError",
    "ProjectAnalysisError",
    "FormGenerationError",
    "ConfigurationError",
    "DependencyInjectionError",
]
