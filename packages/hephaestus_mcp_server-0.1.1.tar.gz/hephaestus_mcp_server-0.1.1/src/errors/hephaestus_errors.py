"""Hephaestus-specific error classes."""

from __future__ import annotations

from typing import Any


class HephaestusError(Exception):
    """Base exception for all Hephaestus errors."""

    def __init__(
        self,
        message: str,
        error_code: str | None = None,
        context: dict[str, Any] | None = None,
    ):
        super().__init__(message)
        self.message = message
        self.error_code = error_code
        self.context = context or {}


class ValidationError(HephaestusError):
    """Raised when component or form validation fails."""

    def __init__(
        self, message: str, field: str | None = None, value: str | None = None
    ):
        super().__init__(message, "VALIDATION_ERROR", {"field": field, "value": value})
        self.field = field
        self.value = value


class ProjectAnalysisError(HephaestusError):
    """Raised when project analysis fails."""

    def __init__(self, message: str, project_path: str | None = None):
        super().__init__(message, "ANALYSIS_ERROR", {"project_path": project_path})
        self.project_path = project_path


class FormGenerationError(HephaestusError):
    """Raised when form generation fails."""

    def __init__(
        self,
        message: str,
        form_config: dict[str, Any] | None = None,
        output_path: str | None = None,
    ):
        super().__init__(
            message,
            "GENERATION_ERROR",
            {"form_config": form_config, "output_path": output_path},
        )
        self.form_config = form_config
        self.output_path = output_path


class ConfigurationError(HephaestusError):
    """Raised when configuration is invalid."""

    def __init__(self, message: str, config_key: str | None = None):
        super().__init__(message, "CONFIG_ERROR", {"config_key": config_key})
        self.config_key = config_key


class DependencyInjectionError(HephaestusError):
    """Raised when dependency injection fails."""

    def __init__(self, message: str, service_type: str | None = None):
        super().__init__(message, "DI_ERROR", {"service_type": service_type})
        self.service_type = service_type


class GenerationError(FormGenerationError):
    """Alias for FormGenerationError for backward compatibility."""

    def __init__(
        self,
        message: str,
        form_config: dict[str, Any] | None = None,
        output_path: str | None = None,
    ):
        super().__init__(message, form_config, output_path)
