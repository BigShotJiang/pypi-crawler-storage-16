"""Main FastMCP server for Hephaestus Anvil development integration."""

from __future__ import annotations

import argparse
from pathlib import Path

from fastmcp import FastMCP

from .dependencies.container import DIContainer, FileSystem, ProjectManager


class HephaestusMCPServer:
    """Main MCP server for Hephaestus Anvil development."""

    def __init__(self, mcp: FastMCP, container: DIContainer | None = None):
        self.mcp = mcp
        self.container = container or self._create_default_container()
        self._register_tools()

    def _create_default_container(self) -> DIContainer:
        """Create default dependency injection container."""
        container = DIContainer()
        container.register(FileSystem, FileSystem())
        container.register(ProjectManager, ProjectManager(container.get(FileSystem)))
        return container

    def _register_tools(self) -> None:
        """Register all Anvil development tools with MCP server."""
        from .registry.tool_registry import ToolRegistry

        registry = ToolRegistry(self.container)
        registry.register_anvil_tools(self.mcp)

    def run(
        self, host: str = "localhost", port: int = 8000, transport: str = "stdio"
    ) -> None:
        """Run the MCP server."""
        if transport == "http":
            self.mcp.run(host=host, port=port, transport="http")
        else:
            self.mcp.run()


def main() -> None:
    """Main entry point for the MCP server."""
    mcp = FastMCP("hephaestus-mcp-server")
    server = HephaestusMCPServer(mcp)

    parser = argparse.ArgumentParser(
        description="Hephaestus MCP Server for Anvil Development"
    )
    parser.add_argument("--host", default="localhost", help="Host for HTTP transport")
    parser.add_argument(
        "--port", type=int, default=8000, help="Port for HTTP transport"
    )
    parser.add_argument(
        "--transport", choices=["stdio", "http"], default="stdio", help="Transport type"
    )

    args = parser.parse_args()

    server.run(host=args.host, port=args.port, transport=args.transport)


if __name__ == "__main__":
    main()
