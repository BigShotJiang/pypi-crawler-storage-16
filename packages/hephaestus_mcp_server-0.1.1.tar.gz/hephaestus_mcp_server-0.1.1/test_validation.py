#!/usr/bin/env python3

import sys

sys.path.append("src")
from validators.component_operations_validator import ComponentOperationsValidator

validator = ComponentOperationsValidator()
form_with_component = {
    "container": {"type": "ColumnPanel"},
    "components": [
        {
            "name": "button_test",
            "type": "Button",
            "properties": {"text": "Test", "role": "outlined-button"},
            "layout_properties": {"grid_position": "0,0"},
        }
    ],
}
is_valid, errors, warnings = validator.validate_move_operation(
    form_with_component, "button_test", "invalid_position"
)
print(f"Valid: {is_valid}")
print(f"Errors: {errors}")
print(f"Warnings: {warnings}")
