"""Test configuration and fixtures for Hephaestus MCP server."""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest
from fastmcp import FastMCP

from src.server import HephaestusMCPServer
from src.dependencies.container import DIContainer, FileSystem, ProjectManager


@pytest.fixture
def temp_project_dir():
    """Create a temporary directory for test projects."""
    with tempfile.TemporaryDirectory() as temp_dir:
        yield Path(temp_dir)


@pytest.fixture
def sample_anvil_project(temp_project_dir):
    """Create a minimal sample Anvil project structure."""
    (temp_project_dir / "client_code").mkdir()
    (temp_project_dir / "server_code").mkdir()
    (temp_project_dir / "theme").mkdir()

    form_content = """container:
  type: ColumnPanel
  properties: {}
  components:
    - name: button_1
      type: Button
      properties:
        text: "Click me"
      layout_properties:
        grid_position: "0,0"
"""
    (temp_project_dir / "client_code" / "Form1.yaml").write_text(form_content)

    server_content = """import anvil.server

@anvil.server.callable
def hello_world():
    return "Hello from Hephaestus!"
"""
    (temp_project_dir / "server_code" / "main.py").write_text(server_content)

    config_content = """{
  "name": "TestProject",
  "runtime_options": {
    "client_version": "1",
    "server_version": "1"
  }
}"""
    (temp_project_dir / "app.json").write_text(config_content)

    return temp_project_dir


@pytest.fixture
def mcp_server():
    """Create a FastMCP server instance for testing."""
    mcp = FastMCP("test-hephaestus")
    return HephaestusMCPServer(mcp)


@pytest.fixture
def test_container():
    """Create a test DI container with required services."""
    container = DIContainer()
    container.register(FileSystem, FileSystem())
    container.register(ProjectManager, ProjectManager(FileSystem()))
    return container


@pytest.fixture
def sample_form_config():
    """Sample form configuration for testing."""
    return {
        "name": "TestForm",
        "container": {"type": "ColumnPanel", "properties": {"spacing": "medium"}},
        "components": [
            {
                "name": "textbox_name",
                "type": "TextBox",
                "properties": {"placeholder": "Enter your name", "role": "outlined"},
                "layout_properties": {"grid_position": "0,0"},
            },
            {
                "name": "button_submit",
                "type": "Button",
                "properties": {"text": "Submit", "role": "raised-button"},
                "layout_properties": {"grid_position": "1,0"},
                "event_bindings": {"click": "button_submit_click"},
            },
        ],
    }


@pytest.fixture
def sample_project_context():
    """Sample project context for testing."""
    return {
        "theme_type": "material-3",
        "routing_system": "official",
        "has_reactive": True,
        "data_layer": "model-classes",
        "layout_system": "layouts",
        "modernisation_score": 0.8,
        "generation_mode": "modern",
        "performance_opportunities": ["reactive-optimisation", "layout-improvements"],
        "breaking_change_risks": [],
    }
