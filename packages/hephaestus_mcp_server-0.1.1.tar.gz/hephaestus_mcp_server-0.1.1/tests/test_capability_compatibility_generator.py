"""Test capability compatibility generator tools registration."""

import pytest
from src.registry.tool_registry import ToolRegistry
from src.dependencies.container import DIContainer, FileSystem, ProjectManager


def test_capability_compatibility_generator_tools_registered(test_container):
    """Test that capability compatibility generator tools are properly registered."""
    registry = ToolRegistry(test_container)

    # Register all tools (this will include capability compatibility tools)
    from mcp.server.fastmcp import FastMCP

    mcp = FastMCP("test")
    registry.register_anvil_tools(mcp)

    # Check that capability compatibility tools are registered
    capability_tools = [
        "generate_capability_compatible_component",
        "create_capability_upgrade_plan",
        "generate_capability_fallback_component",
    ]

    for tool_name in capability_tools:
        tool = registry.get_tool(tool_name)
        if tool:
            assert "description" in tool
            assert "parameters" in tool
            tags = tool.get("tags", [])
            assert "phase4" in tags
        else:
            assert False, f"Tool {tool_name} should be registered"


def test_capability_compatibility_generator_tool_parameters(test_container):
    """Test that capability compatibility generator tools have correct parameters."""
    registry = ToolRegistry(test_container)

    from mcp.server.fastmcp import FastMCP

    mcp = FastMCP("test")
    registry.register_anvil_tools(mcp)

    # Test generate_capability_compatible_component parameters
    tool = registry.get_tool("generate_capability_compatible_component")
    if tool and tool.get("parameters"):
        params = tool.get("parameters", {})
        assert "component_name" in params
        assert "component_type" in params
        assert "properties" in params
        assert "config" in params

    # Test create_capability_upgrade_plan parameters
    tool = registry.get_tool("create_capability_upgrade_plan")
    if tool and tool.get("parameters"):
        params = tool.get("parameters", {})
        assert "current_capability" in params
        assert "target_capability" in params
        assert "components" in params
        assert "config" in params

    # Test generate_capability_fallback_component parameters
    tool = registry.get_tool("generate_capability_fallback_component")
    if tool and tool.get("parameters"):
        params = tool.get("parameters", {})
        assert "component_name" in params
        assert "component_type" in params
        assert "properties" in params
        assert "unsupported_features" in params
        assert "config" in params
