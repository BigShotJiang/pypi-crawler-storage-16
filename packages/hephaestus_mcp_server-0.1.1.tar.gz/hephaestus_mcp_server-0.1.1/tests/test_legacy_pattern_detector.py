"""Tests for legacy pattern detection functionality."""

from pathlib import Path
import pytest
from src.analyzers.legacy_pattern_detector import (
    LegacyPattern,
    LegacyPatternDetector,
    PatternCompatibility,
)
from src.dependencies.container import FileSystem, ProjectManager
from src.patterns.pattern_library import PatternLibrary


@pytest.fixture
def pattern_detector(test_container):
    """Create a legacy pattern detector instance for testing."""
    return LegacyPatternDetector(
        test_container.get(FileSystem),
        test_container.get(ProjectManager),
    )


class TestLegacyPatternDetector:
    """Test suite for LegacyPatternDetector class."""

    def test_detector_initialization(self, pattern_detector):
        """Test that detector initializes correctly."""
        assert pattern_detector.file_system is not None
        assert pattern_detector.project_manager is not None
        assert pattern_detector.pattern_library is not None

    def test_detect_anvil_patterns_basic(self, pattern_detector, sample_anvil_project):
        """Test basic pattern detection functionality."""
        result = pattern_detector.detect_anvil_patterns(sample_anvil_project)

        assert "legacy_patterns" in result
        assert "mixed_architectures" in result
        assert "anti_patterns" in result
        assert "compatibility_matrix" in result
        assert "migration_opportunities" in result
        assert "risk_assessment" in result
        assert "analysis_summary" in result
        assert isinstance(result["legacy_patterns"], list)

    def test_detect_anvil_patterns_invalid_path(self, pattern_detector):
        """Test error handling for non-existent directory."""
        non_existent = Path("/nonexistent/path/to/project")

        with pytest.raises(ValueError, match="Not an Anvil project"):
            pattern_detector.detect_anvil_patterns(non_existent)


class TestLegacyPattern:
    """Test suite for LegacyPattern dataclass."""

    def test_legacy_pattern_creation(self):
        """Test creating a LegacyPattern instance."""
        pattern = LegacyPattern(
            name="anvil-extras-routing",
            category="routing",
            description="Using anvil-extras routing",
            file_path=Path("client_code/Form1.py"),
            line_numbers=[1, 2, 3],
            severity="medium",
            migration_complexity="moderate",
        )

        assert pattern.name == "anvil-extras-routing"
        assert pattern.severity == "medium"
        assert len(pattern.line_numbers) == 3
        assert pattern.dependencies == []


class TestPatternCompatibility:
    """Test suite for PatternCompatibility dataclass."""

    def test_pattern_compatibility_creation(self):
        """Test creating a PatternCompatibility instance."""
        compat = PatternCompatibility(
            pattern1="anvil-extras-routing",
            pattern2="official-routing",
            compatibility_score=0.3,
            conflicts=["Routing systems conflict"],
            synergies=[],
        )

        assert compat.compatibility_score == 0.3
        assert len(compat.conflicts) > 0
        assert "conflict" in compat.conflicts[0].lower()
