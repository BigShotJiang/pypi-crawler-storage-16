Scripts for setting up and testing this application (https://github.com/github/scripts-to-rule-them-all).
