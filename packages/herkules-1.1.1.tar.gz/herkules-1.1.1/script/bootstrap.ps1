Write-Output ""

# create virtual environment and install dependencies
uv sync --no-managed-python

Write-Output ""
