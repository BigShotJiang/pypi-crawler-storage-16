Write-Output ""

uv tree --no-dev

Write-Output ""
Write-Output "------------------------------------------------------------------------"
Write-Output ""

uv tree --only-dev

Write-Output ""
