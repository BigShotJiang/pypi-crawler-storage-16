```{toctree}
:hidden:

API reference <reference/index>
Changelog <changelog>
```

```{include} ../../README.md
:relative-docs: docs/
:relative-images: docs/

