import base64
import hashlib
import os
from pprint import pprint
from typing import Optional

import requests

from hexss.config import load_config


def fingerprint(pubkey: str) -> str:
    """
    Convert an SSH public key (e.g., ssh-ed25519 ...) to its SHA256 fingerprint.
    Matches the format shown by GitHub and ssh-keygen -lf.
    """
    try:
        # Split "ssh-ed25519 <base64> [comment]"
        parts = pubkey.strip().split()
        if len(parts) < 2:
            raise ValueError("Invalid SSH public key format")

        key_data = parts[1]
        decoded = base64.b64decode(key_data)
        sha256_hash = hashlib.sha256(decoded).digest()
        fingerprint = base64.b64encode(sha256_hash).decode().rstrip('=')
        return f"SHA256:{fingerprint}"
    except Exception as e:
        raise ValueError(f"Failed to compute fingerprint: {e}")


def get_auth_headers(token=None):
    token = token or os.getenv("GITHUB_TOKEN") or load_config('github').get('token')
    headers = {"Accept": "application/vnd.github+json"}
    if token:
        headers["Authorization"] = f"token {token}"
    return headers


def list_my_ssh_keys(token: Optional[str] = None):
    """List all SSH keys from your GitHub account."""
    url = "https://api.github.com/user/keys"
    res = requests.get(url, headers=get_auth_headers(token))
    res.raise_for_status()
    for item in res.json():
        pprint(item)
        # name = item.get("title", f"id:{item.get('id')}")
        # key = item.get("key")
        # fp = fingerprint(key)
        # print(f"{name} : {fp}")


# ------------------ Run ------------------
if __name__ == "__main__":
    from hexss.env import set_proxy

    set_proxy()
    list_my_ssh_keys()
