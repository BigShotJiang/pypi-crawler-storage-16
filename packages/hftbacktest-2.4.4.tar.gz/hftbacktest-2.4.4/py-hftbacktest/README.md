# Py-HftBacktest

To build the shared library for testing the Python bindings, run the command below.

```
maturin develop
```