# hg_oap issues

1. date generators need operators for first calendar day, first business day, last calendar day, last business day of month