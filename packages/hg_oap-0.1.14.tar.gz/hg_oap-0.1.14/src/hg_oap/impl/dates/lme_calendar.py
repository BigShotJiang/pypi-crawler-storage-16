from hg_oap.dates import WeekendCalendar


class LmeExecutionCalendar(WeekendCalendar):
    ...

