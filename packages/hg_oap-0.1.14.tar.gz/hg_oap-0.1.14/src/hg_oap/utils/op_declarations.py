from hg_oap.utils.op import ParameterOp

__all__ = ('SELF',)

SELF = ParameterOp(0, _name='SELF')
