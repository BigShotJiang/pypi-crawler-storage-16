HG Systematic Issues
--------------------

