HG Systematic Concepts
======================

This covers concepts for implementing systematic trading strategies using the
HGraph platform.

.. toctree::
    time_and_calendars
    formula
    backtesting_concepts




