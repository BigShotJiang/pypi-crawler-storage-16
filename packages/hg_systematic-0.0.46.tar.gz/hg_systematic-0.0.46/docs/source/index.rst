.. include:: ../../README.rst

HG Systematic Documentation
===========================


Contents
--------

.. toctree::
    :maxdepth: 1

    Home <self>
    concepts/index
    reference/index
    references
