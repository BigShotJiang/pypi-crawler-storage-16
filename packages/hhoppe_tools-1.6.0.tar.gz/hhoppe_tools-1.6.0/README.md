# Package `hhoppe-tools`

Library of Python tools -- [Hugues Hoppe](https://hhoppe.com).

[**[API docs]**](https://hhoppe.github.io/hhoppe-tools/)
