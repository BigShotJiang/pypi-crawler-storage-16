DIRECTIONS = ['hlr', 'hrl', 'vlr', 'vrl']

COLORS = ['black', 'red', 'green', 'blue', \
    'white', 'aqua', 'fuchsia', 'gray', \
    'lime', 'maroon', 'navy', 'olive', \
    'purple', 'silver', 'teal', 'yellow']

PLACES = ['t', 'b', 's', 'e', 'ts', 'te', 'bs', 'be']
