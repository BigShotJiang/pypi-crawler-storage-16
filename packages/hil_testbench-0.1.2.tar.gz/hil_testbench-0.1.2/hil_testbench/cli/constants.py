"""CLI-level constants shared across modules."""

DEFAULT_CONFIG_FILE = "tasks.yaml"
LOG_HINT = "Consult the logs directory for detailed run output."
