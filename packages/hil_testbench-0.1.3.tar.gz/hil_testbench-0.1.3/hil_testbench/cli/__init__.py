"""Command-line interface helpers for hil_testbench."""
