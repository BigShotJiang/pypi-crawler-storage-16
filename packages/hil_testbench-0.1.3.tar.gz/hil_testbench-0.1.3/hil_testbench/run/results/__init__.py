"""Result aggregation helpers."""

from .task_outcome import MultiTaskOutcome, TaskOutcome

__all__ = ["MultiTaskOutcome", "TaskOutcome"]
