from __future__ import annotations
from himena.qt.settings._widget import QSettingsDialog

__all__ = ["QSettingsDialog"]
