from contextvars import ContextVar
import threading

__all__ = ["_config_creation_lock", "_config_creation_stack"]

# Lock for thread-safe class decoration
_config_creation_lock = threading.Lock()

# Track config creation stack for circular dependency detection
_config_creation_stack: ContextVar[list[str] | None] = ContextVar(
  "_config_creation_stack", default=None
)
