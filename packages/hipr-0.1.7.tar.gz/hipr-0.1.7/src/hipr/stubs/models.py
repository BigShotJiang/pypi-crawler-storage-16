from __future__ import annotations

from dataclasses import dataclass
from typing import NamedTuple


class HyperParam(NamedTuple):
  """Represents a hyperparameter extracted from a function signature."""

  name: str
  type_annotation: str
  default_value: str


@dataclass
class FunctionInfo:
  """Information about a @configurable decorated function."""

  name: str
  params: list[HyperParam]
  all_params: list[tuple[str, str, str]]  # (name, type, default)
  return_type: str
  has_data_param: bool
  is_function: bool
