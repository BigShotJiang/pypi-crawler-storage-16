"""Test recursive make behavior and strict Config types."""

from __future__ import annotations

from typing import ClassVar

from hipr import DEFAULT, Hyper, MakeableModel, configurable


@configurable
class Leaf:
  Config: ClassVar[type[MakeableModel[object]]]

  def __init__(self, value: int = 1):
    self.value = value

  def to_config(self) -> MakeableModel[object]:
    """Stub for to_config until implemented."""
    return self.Config.from_instance(self)  # type: ignore


@configurable
class Node:
  Config: ClassVar[type[MakeableModel[object]]]

  def __init__(self, leaf: Hyper[Leaf] = DEFAULT):
    self.leaf = leaf


@configurable
class Tree:
  Config: ClassVar[type[MakeableModel[object]]]

  def __init__(self, node: Hyper[Node] = DEFAULT):
    self.node = node


def test_recursive_make_defaults() -> None:
  """Test that make() recursively instantiates defaults."""
  config = Tree.Config()
  tree = config.make()

  assert isinstance(tree, Tree)
  assert isinstance(tree.node, Node)
  assert isinstance(tree.node.leaf, Leaf)
  assert tree.node.leaf.value == 1


def test_recursive_make_overrides() -> None:
  """Test that make() recursively instantiates with overrides."""
  config = Tree.Config(node=Node.Config(leaf=Leaf.Config(value=10)))
  tree = config.make()

  assert isinstance(tree, Tree)
  assert isinstance(tree.node, Node)
  assert isinstance(tree.node.leaf, Leaf)
  assert tree.node.leaf.value == 10


def test_instance_injection_via_to_config() -> None:
  """Test passing an existing instance using .to_config()."""
  my_leaf = Leaf(value=99)

  # Should be able to pass .to_config() result where Config is expected
  config = Node.Config(leaf=my_leaf.to_config())
  node = config.make()

  assert isinstance(node, Node)
  assert node.leaf is my_leaf  # Should be the exact same instance
  assert node.leaf.value == 99


def test_mixed_config_and_instance() -> None:
  """Test mixing Config objects and injected instances."""
  my_leaf = Leaf(value=42)

  config = Tree.Config(node=Node.Config(leaf=my_leaf.to_config()))
  tree = config.make()

  assert isinstance(tree, Tree)
  assert isinstance(tree.node, Node)
  assert tree.node.leaf is my_leaf
  assert tree.node.leaf.value == 42
