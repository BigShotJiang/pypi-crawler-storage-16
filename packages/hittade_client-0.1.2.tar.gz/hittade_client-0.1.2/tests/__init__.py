"""Tests for the Hittade API client."""
