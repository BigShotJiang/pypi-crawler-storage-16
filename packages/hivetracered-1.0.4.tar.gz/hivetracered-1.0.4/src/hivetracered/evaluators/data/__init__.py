"""
Data module for evaluators, containing default keywords and regex patterns.
""" 