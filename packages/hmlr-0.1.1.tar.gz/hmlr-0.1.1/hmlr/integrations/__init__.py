"""
HMLR LangChain Integration

Optional adapter for using HMLR as a memory backend in LangChain applications.
"""

__all__ = []

# LangChain integration will be added in Phase 4
