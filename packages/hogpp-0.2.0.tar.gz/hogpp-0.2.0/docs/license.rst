License
=======

.. image:: https://i.creativecommons.org/l/by-sa/4.0/88x31.png
   :align: right
   :alt: Creative Commons License

This document and all the figures are licensed under a `Creative Commons
Attribution-ShareAlike 4.0 International License
<http://creativecommons.org/licenses/by-sa/4.0/>`__.

HOGpp is distributed under `Apache License 2.0
<http://www.apache.org/licenses/LICENSE-2.0>`__ terms.

