API Documentation
=================

.. automodule:: hogpp
   :members:
   :special-members: __call__, __bool__
