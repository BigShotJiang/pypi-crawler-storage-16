TOOLSET_CONFIG_MISSING_ERROR = "The toolset is missing its configuration"

STANDARD_END_DATETIME_TOOL_PARAM_DESCRIPTION = (
    "End datetime, inclusive. Should be formatted in rfc3339. Defaults to NOW"
)
