# Color constants for terminal output
USER_COLOR = "#DEFCC0"  # light green
AI_COLOR = "#00FFFF"  # cyan
TOOLS_COLOR = "magenta"
HELP_COLOR = "cyan"  # same as AI_COLOR for now
ERROR_COLOR = "red"
STATUS_COLOR = "yellow"
