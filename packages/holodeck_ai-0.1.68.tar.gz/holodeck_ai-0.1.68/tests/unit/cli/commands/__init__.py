"""HoloDeck CLI commands unit tests."""
