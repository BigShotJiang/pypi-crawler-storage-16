"""Unit tests for MCP tool module."""
