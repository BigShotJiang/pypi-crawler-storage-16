For context please read :

- the README.md

and #fetch:

- https://gofastmcp.com/getting-started/welcome.md
- https://gofastmcp.com/patterns/testing.md
