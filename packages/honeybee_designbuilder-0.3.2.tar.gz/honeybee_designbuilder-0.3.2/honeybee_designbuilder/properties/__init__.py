"""honeybee-designbuilder properties."""
