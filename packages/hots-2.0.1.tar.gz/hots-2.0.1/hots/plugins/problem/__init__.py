"""Problem‑domain plugins for HOTS."""
