Annotations
===========

.. autoclass:: pyhpo.Omim
   :members:
   :inherited-members:

.. autoclass:: pyhpo.Orpha
   :members:
   :inherited-members:

.. autoclass:: pyhpo.Gene
   :members:
   :inherited-members:
