HPOTerm
=======

.. autoclass:: pyhpo.HPOTerm
   :members:
   :inherited-members:


.. autoclass:: pyhpo.types.InformationContent
   :members:
   :inherited-members:
