Statistical Analysis
====================

EnrichmentModel
---------------

.. autoclass:: pyhpo.stats.EnrichmentModel
   :members:
   :inherited-members:


Linkage
-------

.. autofunction:: pyhpo.stats.linkage
