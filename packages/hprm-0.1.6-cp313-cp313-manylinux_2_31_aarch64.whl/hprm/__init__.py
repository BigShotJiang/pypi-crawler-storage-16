from .hprm import *

__doc__ = hprm.__doc__
if hasattr(hprm, "__all__"):
    __all__ = hprm.__all__