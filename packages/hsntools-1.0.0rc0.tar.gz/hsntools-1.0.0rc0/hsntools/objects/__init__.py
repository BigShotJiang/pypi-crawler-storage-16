"""Object sub-module for hsntools."""

from .task import TaskBase
from .electrodes import Electrodes
