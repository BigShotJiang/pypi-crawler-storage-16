"""Plots sub-module for hsntools."""
