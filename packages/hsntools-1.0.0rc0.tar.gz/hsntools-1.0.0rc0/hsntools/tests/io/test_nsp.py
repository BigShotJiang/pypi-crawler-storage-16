"""Tests for hsntools.io.nsp"""

from hsntools.io.nsp import *

###################################################################################################
###################################################################################################

def test_load_blackrock():
    # Note: need to add dummy neo object to check this - skipped for now
    pass

def test_check_blackrock_file_info():
    # Note: need to add dummy neo object to check this - skipped for now
    pass
