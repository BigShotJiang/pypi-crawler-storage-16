"""Timestamps sub-module for hsntools."""
