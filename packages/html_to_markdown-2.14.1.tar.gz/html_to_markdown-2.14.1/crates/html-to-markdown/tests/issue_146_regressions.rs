//! Issue #146 Regression Tests
//!
//! Tests for ensuring that `strip_tags` and `preserve_tags` properly prevent
//! `<meta>` and `<title>` tags from appearing in YAML frontmatter when metadata
//! extraction is enabled.

use html_to_markdown_rs::{ConversionOptions, convert};

#[test]
fn test_strip_tags_prevents_metadata_extraction() {
    // Issue #146: strip_tags with "meta" should prevent meta tags from being extracted into frontmatter
    let html = r#"<!DOCTYPE html>
<html>
<head>
    <title>Test Document</title>
    <meta name="author" content="John Doe">
    <meta name="description" content="A test document">
    <meta property="og:title" content="Test OG Title">
</head>
<body>
    <p>Main content here</p>
</body>
</html>"#;

    let mut options = ConversionOptions::default();
    options.extract_metadata = true;
    options.strip_tags = vec!["meta".to_string()];

    let result = convert(html, Some(options)).unwrap();

    // The body content should still be present
    assert!(
        result.contains("Main content here"),
        "Body content should be preserved: {}",
        result
    );

    // Title should still be extracted (not stripped)
    assert!(
        result.contains("title: Test Document"),
        "Title should still be extracted in frontmatter: {}",
        result
    );

    // But meta tags should NOT appear in the frontmatter
    // when strip_tags includes "meta"
    assert!(
        !result.contains("meta-author"),
        "meta-author should NOT be in frontmatter when strip_tags=['meta']: {}",
        result
    );
    assert!(
        !result.contains("meta-description"),
        "meta-description should NOT be in frontmatter when strip_tags=['meta']: {}",
        result
    );
    assert!(
        !result.contains("meta-og-title"),
        "meta-og-title should NOT be in frontmatter when strip_tags=['meta']: {}",
        result
    );
}

#[test]
fn test_strip_tags_title_prevents_extraction() {
    // Issue #146: strip_tags with "title" should prevent title extraction into frontmatter
    let html = r#"<!DOCTYPE html>
<html>
<head>
    <title>Should Be Stripped</title>
    <meta name="author" content="Jane Smith">
    <meta name="keywords" content="test, demo">
</head>
<body>
    <h1>Document Heading</h1>
    <p>Some content</p>
</body>
</html>"#;

    let mut options = ConversionOptions::default();
    options.extract_metadata = true;
    options.strip_tags = vec!["title".to_string()];

    let result = convert(html, Some(options)).unwrap();

    // Body content should be present
    assert!(
        result.contains("Document Heading") && result.contains("Some content"),
        "Body content should be preserved: {}",
        result
    );

    // Meta tags should still be extracted (title is stripped, not meta)
    assert!(
        result.contains("meta-author"),
        "meta-author should still be extracted when only title is stripped: {}",
        result
    );
    assert!(
        result.contains("meta-keywords"),
        "meta-keywords should still be extracted when only title is stripped: {}",
        result
    );

    // But title should NOT be in the frontmatter
    assert!(
        !result.contains("title: Should Be Stripped"),
        "title should NOT be in frontmatter when strip_tags=['title']: {}",
        result
    );
}

#[test]
fn test_preserve_tags_prevents_metadata_extraction() {
    // Issue #146: preserve_tags should also prevent metadata extraction
    // When a tag is preserved, it should appear as HTML (not stripped and not extracted as metadata)
    let html = r#"<!DOCTYPE html>
<html>
<head>
    <title>Preserved Title</title>
    <meta name="viewport" content="width=device-width">
    <meta name="author" content="Test Author">
</head>
<body>
    <div>
        <p>Body content</p>
    </div>
</body>
</html>"#;

    let mut options = ConversionOptions::default();
    options.extract_metadata = true;
    // When preserve_tags is set for "meta", meta tags should be output as HTML
    // and NOT extracted into the YAML frontmatter
    options.preserve_tags = vec!["meta".to_string()];

    let result = convert(html, Some(options)).unwrap();

    // Body content should be present
    assert!(
        result.contains("Body content"),
        "Body content should be preserved: {}",
        result
    );

    // Title should still be extracted (not in preserve_tags)
    assert!(
        result.contains("title: Preserved Title"),
        "title should still be extracted in frontmatter: {}",
        result
    );

    // Meta attributes should NOT appear in YAML frontmatter
    assert!(
        !result.contains("meta-viewport"),
        "meta-viewport should NOT be in YAML frontmatter when preserve_tags=['meta']: {}",
        result
    );
    assert!(
        !result.contains("meta-author"),
        "meta-author should NOT be in YAML frontmatter when preserve_tags=['meta']: {}",
        result
    );
}
