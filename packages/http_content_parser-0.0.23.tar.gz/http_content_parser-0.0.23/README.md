# HttpParser Package

This is a http content parser package.

## build package

```bash
python3 -m build
```

## upload to pypi

```bash
rm -f dist/*
python3 -m twine upload dist/*
```
