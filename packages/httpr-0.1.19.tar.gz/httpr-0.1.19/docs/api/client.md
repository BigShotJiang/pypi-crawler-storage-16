# Client

The synchronous HTTP client with connection pooling.

::: httpr.Client
    options:
      members:
        - __init__
        - request
        - get
        - head
        - options
        - delete
        - post
        - put
        - patch
        - close
      show_root_heading: true
      show_root_full_path: false
      heading_level: 2
