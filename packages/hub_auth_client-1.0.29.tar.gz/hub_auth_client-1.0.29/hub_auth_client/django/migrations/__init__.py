"""Migrations package for hub_auth_client Django models."""
