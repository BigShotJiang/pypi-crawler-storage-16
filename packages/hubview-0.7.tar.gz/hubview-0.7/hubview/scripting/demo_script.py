"""
demo script 
"""

import time


print('counting to 10')

for i in range(10):
    print(i)
    time.sleep(1)

print('done')