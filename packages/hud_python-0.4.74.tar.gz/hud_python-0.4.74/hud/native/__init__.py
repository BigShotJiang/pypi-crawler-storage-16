"""Native Python MCP servers for HUD.

These servers run as pure Python processes without containerization.
They can be run standalone or mounted into other servers, providing
lightweight evaluation and comparison capabilities.
"""
