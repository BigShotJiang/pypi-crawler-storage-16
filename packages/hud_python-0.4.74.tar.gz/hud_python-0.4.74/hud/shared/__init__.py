from __future__ import annotations

from .requests import make_request, make_request_sync

__all__ = ["make_request", "make_request_sync"]
