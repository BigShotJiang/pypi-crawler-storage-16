# 🧠 Humsana Local

**Your AI coding assistant doesn't know if you're in deep focus or exhausted. Now it does.**

A tiny local server that gives Continue.dev (and other AI tools) real-time awareness of your focus state. No cloud, no accounts, no tracking.

![Humsana Local Demo](demo.png)

## 🚀 Install
```bash
pip install humsana-local
```

## ▶️ Run
```bash
humsana-local

# If that doesn't work (PATH issues):
python -m humsana_local.server
```

## ⚙️ Add to Continue.dev

Add to `~/.continue/config.json` under `contextProviders`:
```json
{
  "name": "http",
  "params": {
    "url": "http://localhost:25060/api/v5/context",
    "title": "myself",
    "displayTitle": "My State"
  }
}
```

## ✨ Use It

Type `@myself` in Continue chat. Your AI now sees:
```
## My Current State
- State: deep_coding
- Focus Score: 0.87 (high - don't over-explain)
- Energy: 0.65 (good)
- Cognitive Load: deep_focus
- Interruptible: no - in the zone

AI Guidance: User is in deep focus. Be concise. Skip explanations. Provide code directly.
```

## 🔍 What It Detects

| Signal | How | Why It Matters |
|--------|-----|----------------|
| **Focus Score** | Window switching frequency | Lots of alt-tabbing = fragmented attention |
| **Energy Level** | Time of day + session length | 3am after 6 hours = probably exhausted |
| **Coding Ratio** | Time in IDE vs other apps | High ratio = deep in code |
| **State** | Combined signals | `deep_coding`, `focused_work`, `context_switching`, `low_energy` |

## 🔒 Privacy

- **100% local** — nothing leaves your machine
- **No accounts** — just run it
- **No telemetry** — we don't even know you're using it
- **Open source** — read the code yourself

## 🍎 macOS Note

For window tracking, you may need to grant Terminal **Accessibility** permissions in System Preferences → Privacy & Security → Accessibility.

## 🆚 Local vs Cloud

| Feature | Humsana Local (Free) | Humsana Cloud |
|---------|---------------------|---------------|
| Privacy | 100% offline | Enterprise-grade encryption |
| Focus Detection | ✅ Window switching | ✅ + behavioral context |
| Energy Estimate | ✅ Time of day | ✅ + calendar + workload |
| Meeting Awareness | ❌ | ✅ |
| Communication Style | ❌ | ✅ |
| Personality Model | ❌ | ✅ OCEAN profiling |
| Burnout Prediction | ❌ | ✅ |
| Anomaly Detection | ❌ | ✅ |

**Local is for Focus. Cloud is for Context.**

Local sees you typing fast. Cloud knows it's the deadline, not the coffee.

→ [Unlock full context](https://humsana.com/connect)

## 💬 Feedback?

Early beta. Found a bug? Have an idea?

[Open an Issue](https://github.com/ramchatrern/humsana-local/issues) or DM on [Twitter/X](https://twitter.com/humsana)

## License

MIT