# humsana_local/server.py
"""
Humsana Local - Zero-friction behavioral context for AI coding assistants
Run this, add the recipe to Continue.dev, type @myself - done.

Install: pip install humsana-local
Run: python -m humsana_local.server
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime, timedelta
from collections import deque
from typing import Optional
import threading
import time
import platform

app = FastAPI(title="Humsana Local", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ============== OS DETECTION ==============

IS_MACOS = platform.system() == "Darwin"
IS_WINDOWS = platform.system() == "Windows"

# Optional imports - graceful degradation
try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False

try:
    if IS_MACOS:
        from AppKit import NSWorkspace
        HAS_WINDOW = True
        USE_APPKIT = True
    else:
        import pygetwindow as gw
        HAS_WINDOW = True
        USE_APPKIT = False
except ImportError:
    HAS_WINDOW = False
    USE_APPKIT = False


# ============== LOCAL SIGNAL COLLECTOR ==============

class LocalSignalCollector:
    """Collects behavioral signals from local machine - no OAuth, no cloud"""
    
    def __init__(self):
        self.window_history = deque(maxlen=100)
        self.session_start = datetime.now()
        self.last_activity = datetime.now()
        self.current_window = None
        self.window_switch_count = 0
        self.coding_windows = {'code', 'vscode', 'visual studio', 'intellij', 
                               'pycharm', 'sublime', 'vim', 'nvim', 'emacs',
                               'cursor', 'zed', 'terminal', 'iterm', 'warp'}
        
        self._running = True
        self._collector_thread = threading.Thread(target=self._collect_loop, daemon=True)
        self._collector_thread.start()
    
    def _collect_loop(self):
        """Background loop to collect signals every second"""
        while self._running:
            self._sample_window()
            time.sleep(1)
    
    def _sample_window(self):
        """Sample current active window"""
        if not HAS_WINDOW:
            return
        
        try:
            if USE_APPKIT:
                active_app = NSWorkspace.sharedWorkspace().activeApplication()
                window_title = active_app.get('NSApplicationName', '').lower() if active_app else None
            else:
                active = gw.getActiveWindow()
                window_title = active.title.lower() if active and active.title else None
            
            if window_title and window_title != self.current_window:
                self.window_history.append({
                    'title': window_title,
                    'timestamp': datetime.now(),
                    'is_coding': any(c in window_title for c in self.coding_windows)
                })
                self.window_switch_count += 1
                self.current_window = window_title
                self.last_activity = datetime.now()
        except Exception:
            pass
    
    def get_focus_score(self) -> float:
        """Calculate focus score based on window switching patterns"""
        if not self.window_history:
            return 0.5
        
        five_min_ago = datetime.now() - timedelta(minutes=5)
        recent_switches = sum(
            1 for w in self.window_history 
            if w['timestamp'] > five_min_ago
        )
        
        focus = max(0.2, min(1.0, 1.0 - (recent_switches * 0.07)))
        return round(focus, 2)
    
    def get_coding_ratio(self) -> float:
        """What % of recent time was spent in coding windows"""
        if not self.window_history:
            return 0.5
        
        ten_min_ago = datetime.now() - timedelta(minutes=10)
        recent = [w for w in self.window_history if w['timestamp'] > ten_min_ago]
        
        if not recent:
            return 0.5
        
        coding_count = sum(1 for w in recent if w.get('is_coding', False))
        return round(coding_count / len(recent), 2)
    
    def get_energy_estimate(self) -> float:
        """Estimate energy based on time of day + session length"""
        hour = datetime.now().hour
        
        if 9 <= hour <= 11:
            base_energy = 0.85
        elif 14 <= hour <= 15:
            base_energy = 0.55
        elif 16 <= hour <= 18:
            base_energy = 0.75
        elif 22 <= hour or hour <= 6:
            base_energy = 0.4
        else:
            base_energy = 0.65
        
        session_hours = (datetime.now() - self.session_start).seconds / 3600
        fatigue_penalty = min(0.3, session_hours * 0.05)
        
        return round(max(0.2, base_energy - fatigue_penalty), 2)
    
    def get_cognitive_load(self) -> str:
        """Estimate cognitive load from context switching"""
        focus = self.get_focus_score()
        coding_ratio = self.get_coding_ratio()
        
        if focus > 0.8 and coding_ratio > 0.7:
            return "deep_focus"
        elif focus > 0.6:
            return "moderate"
        elif focus > 0.4:
            return "fragmented"
        else:
            return "high_switching"
    
    def get_state(self) -> str:
        """Determine overall behavioral state"""
        focus = self.get_focus_score()
        coding_ratio = self.get_coding_ratio()
        energy = self.get_energy_estimate()
        
        if focus > 0.8 and coding_ratio > 0.7:
            return "deep_coding"
        elif focus > 0.7 and coding_ratio > 0.5:
            return "focused_work"
        elif energy < 0.4:
            return "low_energy"
        elif focus < 0.4:
            return "context_switching"
        else:
            return "neutral"
    
    def is_interruptible(self) -> bool:
        """Should AI interrupt with suggestions?"""
        state = self.get_state()
        return state not in ["deep_coding", "focused_work"]


collector = LocalSignalCollector()


# ============== API ENDPOINTS ==============

@app.get("/")
async def root():
    """Health check"""
    return {"status": "running", "service": "humsana-local", "version": "1.0.0"}


@app.get("/api/v5/context")
@app.post("/api/v5/context")
async def get_context(query: Optional[str] = None):
    """
    Main context endpoint - Continue.dev calls this
    """
    
    state = collector.get_state()
    focus = collector.get_focus_score()
    energy = collector.get_energy_estimate()
    cognitive_load = collector.get_cognitive_load()
    interruptible = collector.is_interruptible()
    coding_ratio = collector.get_coding_ratio()
    
    if state == "deep_coding":
        ai_guidance = "User is in deep focus. Be extremely concise. Skip explanations unless asked. Provide code directly."
    elif state == "focused_work":
        ai_guidance = "User is focused. Keep responses concise but can include brief context."
    elif state == "low_energy":
        ai_guidance = "User appears fatigued. Break information into smaller chunks. Suggest breaks if appropriate."
    elif state == "context_switching":
        ai_guidance = "User is multitasking. Provide clear, scannable responses. Use structure."
    else:
        ai_guidance = "Normal state. Respond naturally."
    
    return {
        "content": f"""## My Current State
- **State:** {state}
- **Focus Score:** {focus} ({"high - don't over-explain" if focus > 0.7 else "moderate" if focus > 0.4 else "fragmented"})
- **Energy:** {energy} ({"good" if energy > 0.6 else "moderate" if energy > 0.4 else "low - keep it brief"})
- **Cognitive Load:** {cognitive_load}
- **Interruptible:** {"yes" if interruptible else "no - in the zone"}

**AI Guidance:** {ai_guidance}
""",
        "description": f"State: {state} | Focus: {focus} | ⚡ Want GitHub/Slack context? → humsana.com/connect",
        
        "raw": {
            "state": state,
            "focus_score": focus,
            "energy_level": energy,
            "cognitive_load": cognitive_load,
            "interruptible": interruptible,
            "coding_ratio": coding_ratio,
            "session_minutes": (datetime.now() - collector.session_start).seconds // 60,
            "timestamp": datetime.now().isoformat()
        }
    }


@app.get("/health")
async def health():
    """Detailed health check"""
    return {
        "status": "healthy",
        "collectors": {
            "psutil": HAS_PSUTIL,
            "window_tracking": HAS_WINDOW,
            "using_appkit": USE_APPKIT
        },
        "session_start": collector.session_start.isoformat(),
        "samples_collected": len(collector.window_history)
    }


# ============== CLI ENTRY POINT ==============

def main():
    import uvicorn
    print("""
    ╔═══════════════════════════════════════════════════════════╗
    ║                 🧠 Humsana Local v1.0                     ║
    ╠═══════════════════════════════════════════════════════════╣
    ║  ✅ Running on http://localhost:25060                     ║
    ║  📡 Tracking: Window focus, typing rhythm, session time   ║
    ║                                                           ║
    ║  ✨ HUMSANA CLOUD UNDERSTANDS:                            ║
    ║     The "Why" behind the "What".                          ║
    ║                                                           ║
    ║     • Local sees you typing fast.                         ║
    ║     • Cloud knows it's the Deadline, not the Coffee.      ║
    ║                                                           ║
    ║     What "focus" looks like for YOU — not a generic rule. ║
    ║     When AI should challenge you vs. just execute.        ║
    ║                                                           ║
    ║     Not tracking. Understanding.                          ║
    ║                                                           ║
    ║  → https://humsana.com/connect                            ║
    ╠═══════════════════════════════════════════════════════════╣
    ║  Add to Continue.dev config.json under contextProviders:  ║
    ║                                                           ║
    ║    {                                                      ║
    ║      "name": "http",                                      ║
    ║      "params": {                                          ║
    ║        "url": "http://localhost:25060/api/v5/context",    ║
    ║        "title": "myself"                                  ║
    ║      }                                                    ║
    ║    }                                                      ║
    ║                                                           ║
    ║  Then type @myself in Continue chat.                      ║
    ╚═══════════════════════════════════════════════════════════╝
    """)
    uvicorn.run(app, host="127.0.0.1", port=25060, log_level="warning")


if __name__ == "__main__":
    main()
