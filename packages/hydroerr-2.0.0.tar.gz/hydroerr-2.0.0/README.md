[![CI](https://github.com/BYU-Hydroinformatics/HydroErr/actions/workflows/ci.yml/badge.svg?branch=master)](https://github.com/BYU-Hydroinformatics/HydroErr/actions/workflows/ci.yml?query=branch:master)
[![image](https://img.shields.io/pypi/v/HydroErr.svg)](https://pypi.python.org/pypi/HydroErr)
[![image](https://img.shields.io/pypi/l/HydroErr.svg)](https://github.com/BYU-Hydroinformatics/HydroErr/blob/master/LICENSE)
[![image](https://img.shields.io/pypi/pyversions/HydroErr.svg)](https://pypi.python.org/pypi/HydroErr)

Goodness of fit metrics for use in comparison studies, specifically for use in the field of hydrology

- **Documentation:** https://hydroerr.readthedocs.io/en/stable/
- **Source:** https://github.com/BYU-Hydroinformatics/HydroErr
- **Bug reports:** https://github.com/BYU-Hydroinformatics/HydroErr/issues

HydroErr provides:

- A library of over 70 error metrics to measure hydrologic skill
- Treatment of NaN, Inf, negative, and zero values.
- Scholarly journal sources and code examples for metric methods in the documentation.

Publications:
- Roberts, W., Williams, G., Jackson, E., Nelson, E., Ames, D., 2018. Hydrostats: A Python Package for Characterizing Errors between Observed and Predicted Time Series. Hydrology 5(4) 66, doi:10.3390/hydrology5040066

We would request that if you use this package that you please cite the above paper. The journal paper is open access and can be found at https://doi.org/10.3390/hydrology5040066. BibTeX, EndNote, and RIS files can be downloaded at the journal site.

[![Powered by BYU Hydroinformatics](https://img.shields.io/badge/powered%20by-BYU%20HydroInformatics-blue.svg)](http://worldwater.byu.edu/)
