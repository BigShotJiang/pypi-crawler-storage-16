"""Setup configuration for HydroSim package."""

from setuptools import setup

# Use pyproject.toml for configuration, but keep setup.py for compatibility
setup()
