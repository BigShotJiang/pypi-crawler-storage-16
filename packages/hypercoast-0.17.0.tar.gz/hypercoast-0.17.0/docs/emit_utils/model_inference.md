# model_inference module

::: hypercoast.emit_utils.model_inference
