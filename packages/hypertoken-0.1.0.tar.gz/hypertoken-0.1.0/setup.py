#!/usr/bin/env python3
"""
Legacy setup.py for compatibility with older pip versions.
Primary configuration is in pyproject.toml.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
