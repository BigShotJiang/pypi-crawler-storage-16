Utilities for Herlegon tools
