from pydantic import BeforeValidator, computed_field
from typing import Annotated

from hzclient.utils import parse_json_dict
from .base import _Base

class Voucher(_Base):
  id: int = 0
  code: str = ""
  ts_end: int = 0

  rewards: Annotated[dict, BeforeValidator(parse_json_dict)] = {}

  @computed_field
  @property
  def type(self) -> str:
    for word in ["training", "energy"]:
      if word in self.code:
        return word
    return "unknown"

  @computed_field
  @property
  def reward_amount(self) -> int:
    return next(iter(self.rewards.values()), 0)
