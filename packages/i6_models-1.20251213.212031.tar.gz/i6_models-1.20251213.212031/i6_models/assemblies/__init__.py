"""
Assemblies are composed of one or more parts/assemblies. They are used to construct more complex models.
"""
