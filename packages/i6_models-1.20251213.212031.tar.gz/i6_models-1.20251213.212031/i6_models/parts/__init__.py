"""
Parts are atomic components that do not use any other parts / assemblies from this repository.
They are using pyTorch/3rd-party tools and should have limited complexity.
"""
