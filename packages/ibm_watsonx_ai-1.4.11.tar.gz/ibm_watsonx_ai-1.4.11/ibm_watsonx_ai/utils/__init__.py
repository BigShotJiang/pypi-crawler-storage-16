#  -----------------------------------------------------------------------------------------
#  (C) Copyright IBM Corp. 2023-2025.
#  https://opensource.org/licenses/BSD-3-Clause
#  -----------------------------------------------------------------------------------------

from ibm_watsonx_ai.utils.cpd_version import *  # noqa: F403
from ibm_watsonx_ai.utils.utils import *  # noqa: F403
