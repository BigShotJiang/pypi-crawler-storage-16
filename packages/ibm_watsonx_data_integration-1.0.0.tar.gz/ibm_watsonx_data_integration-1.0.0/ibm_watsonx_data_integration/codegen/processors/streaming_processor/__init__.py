#  IBM Confidential
#  PID 5900-BAF
#  Copyright StreamSets Inc., an IBM Company 2025

"""Wraps code related to StreamingProcessor."""

from ibm_watsonx_data_integration.codegen.processors.streaming_processor.streaming_processor import StreamingProcessor

__all__ = ["StreamingProcessor"]
