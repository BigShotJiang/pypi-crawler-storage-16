"""Module for extended properties."""

from pydantic import BaseModel


class ExtendedProperties(BaseModel):
    """Class for extended properties."""

    pass
