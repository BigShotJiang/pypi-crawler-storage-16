#!/usr/bin/env python3
"""Compare icd-estimate outputs across multiple run folders.

Run directories should contain ``att_effects.csv`` and/or ``aggregated_effects.csv``.
You can pass runs as plain paths or as ``label=/path/to/run`` pairs to control how
they appear in the report. The first run (or the one named with ``--reference``)
is treated as the baseline; all other runs are compared against it.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import pandas as pd

FILE_CONFIG: Dict[str, Dict[str, Sequence[str]]] = {
    "att_effects.csv": {
        "keys": [
            "chapter",
            "outcome",
            "sample",
            "reference_year",
            "relative_year",
        ],
        "metrics": ["estimate", "conf_low", "conf_high", "std_error"],
    },
    "aggregated_effects.csv": {
        "keys": [
            "chapter",
            "outcome",
            "sample",
            "aggregation",
            "component",
            "reference_year",
            "relative_year",
            "event_time",
            "horizon_label",
            "horizon_start",
            "horizon_end",
            "bucket_periods",
        ],
        "metrics": ["estimate", "conf_low", "conf_high", "std_error"],
    },
}


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Compare icd-estimate outputs across multiple runs."
    )
    parser.add_argument(
        "runs",
        nargs="+",
        help="Run folders (optionally label=/path). At least two are required.",
    )
    parser.add_argument(
        "--reference",
        help="Label of the reference run (defaults to the first run).",
    )
    parser.add_argument(
        "--files",
        nargs="*",
        choices=list(FILE_CONFIG),
        default=list(FILE_CONFIG),
        help="Which output files to compare (default: both att_effects and aggregated_effects).",
    )
    parser.add_argument(
        "--top",
        type=int,
        default=5,
        help="How many rows with the largest differences to show per comparison.",
    )
    parser.add_argument(
        "--precision",
        type=int,
        default=4,
        help="Decimal places when printing numeric differences.",
    )
    return parser.parse_args(argv)


def resolve_reference_label(
    ref_arg: str | None, run_entries: Sequence[Tuple[str, Path]]
) -> str:
    if not run_entries:
        raise SystemExit("No runs supplied.")
    if ref_arg is None:
        return run_entries[0][0]

    candidate_path = Path(ref_arg).expanduser()
    for label, path in run_entries:
        if ref_arg == label:
            return label
        try:
            if candidate_path.resolve() == path.resolve():
                return label
        except Exception:
            # Fallback to direct comparison if resolve() fails (e.g., permissions)
            if candidate_path == path:
                return label
        if ref_arg == path.name:
            return label

    available = ", ".join(label for label, _ in run_entries)
    raise SystemExit(
        f"Reference run '{ref_arg}' was not supplied. Available labels: {available}"
    )


def parse_run_arg(arg: str) -> Tuple[str, Path]:
    if "=" in arg:
        label, path_str = arg.split("=", 1)
    else:
        label, path_str = None, arg
    path = Path(path_str).expanduser()
    label = label or path.name
    return label, path


def load_table(
    run_label: str,
    run_path: Path,
    filename: str,
    keys: Sequence[str],
    metrics: Sequence[str],
) -> pd.DataFrame | None:
    csv_path = run_path / filename
    if not csv_path.exists():
        print(f"[WARN] {filename} missing in {run_path}")
        return None

    df = pd.read_csv(csv_path)
    missing_keys = [col for col in keys if col not in df.columns]
    if missing_keys:
        print(
            f"[WARN] {filename} in {run_path} is missing key columns: "
            + ", ".join(missing_keys)
        )
        return None

    df = df.copy()
    for key in keys:
        df[key] = df[key].astype("string").fillna("")

    active_metrics: List[str] = []
    for metric in metrics:
        if metric in df.columns:
            df[metric] = pd.to_numeric(df[metric], errors="coerce")
            active_metrics.append(metric)
        else:
            print(
                f"[WARN] {filename} in {run_path} has no column '{metric}'; "
                "skipping it for comparisons."
            )

    if not active_metrics:
        print(f"[WARN] {filename} in {run_path} has no comparable numeric columns.")
        return None

    df["__run__"] = run_label
    column_order = list(keys) + active_metrics + ["__run__"]
    return df[column_order]


def key_set(df: pd.DataFrame, keys: Sequence[str]) -> set[Tuple[str, ...]]:
    return set(df[keys].itertuples(index=False, name=None))


def format_key(keys: Sequence[str], values: Iterable[object]) -> str:
    return ", ".join(f"{k}={v}" for k, v in zip(keys, values))


def describe_differences(
    filename: str,
    keys: Sequence[str],
    metrics: Sequence[str],
    ref_label: str,
    ref_df: pd.DataFrame,
    other_label: str,
    other_df: pd.DataFrame,
    top: int,
    precision: int,
) -> None:
    ref_keys = key_set(ref_df, keys)
    other_keys = key_set(other_df, keys)
    ref_only = ref_keys - other_keys
    other_only = other_keys - ref_keys

    merged = ref_df.merge(
        other_df,
        on=keys,
        how="inner",
        suffixes=(f"_{ref_label}", f"_{other_label}"),
    )

    print(f"\n{filename}: {ref_label} vs {other_label}")
    print(
        f"  shared rows: {len(merged)} | "
        f"{ref_label} only: {len(ref_only)} | {other_label} only: {len(other_only)}"
    )

    if ref_only:
        preview = list(ref_only)[:3]
        print("  Missing from other (first 3):")
        for key_vals in preview:
            print(f"    - {format_key(keys, key_vals)}")
        if len(ref_only) > len(preview):
            print(f"    ... {len(ref_only) - len(preview)} more")

    if other_only:
        preview = list(other_only)[:3]
        print("  Only in other (first 3):")
        for key_vals in preview:
            print(f"    - {format_key(keys, key_vals)}")
        if len(other_only) > len(preview):
            print(f"    ... {len(other_only) - len(preview)} more")

    active_metrics = [
        metric
        for metric in metrics
        if f"{metric}_{ref_label}" in merged.columns
        and f"{metric}_{other_label}" in merged.columns
    ]
    if merged.empty or not active_metrics:
        print("  No comparable rows with numeric columns.")
        return

    for metric in active_metrics:
        merged[f"{metric}_diff"] = (
            merged[f"{metric}_{other_label}"] - merged[f"{metric}_{ref_label}"]
        )
        merged[f"{metric}_abs_diff"] = merged[f"{metric}_diff"].abs()
        diffs = merged[f"{metric}_abs_diff"].dropna()
        if diffs.empty:
            print(f"  {metric}: no numeric values to compare.")
            continue
        print(
            f"  {metric}: max abs diff {diffs.max():.{precision}f}, "
            f"mean abs diff {diffs.mean():.{precision}f}"
        )

    abs_cols = [f"{metric}_abs_diff" for metric in active_metrics]
    merged["max_abs_diff"] = merged[abs_cols].max(axis=1, skipna=True)
    top_rows = merged.sort_values("max_abs_diff", ascending=False).head(top)
    if top_rows.empty:
        print("  No numeric differences to display.")
        return

    print(f"  Top {len(top_rows)} differences:")
    for _, row in top_rows.iterrows():
        key_str = format_key(keys, (row[key] for key in keys))
        parts: List[str] = []
        for metric in active_metrics:
            ref_val = row[f"{metric}_{ref_label}"]
            other_val = row[f"{metric}_{other_label}"]
            diff_val = row[f"{metric}_diff"]
            parts.append(
                f"{metric}: {other_val:.{precision}f} vs {ref_val:.{precision}f} "
                f"(diff {diff_val:+.{precision}f})"
            )
        print(f"    - {key_str} | " + "; ".join(parts))


def main(argv: Sequence[str] | None = None) -> None:
    args = parse_args(argv)

    run_entries = [parse_run_arg(arg) for arg in args.runs]
    run_map: Dict[str, Path] = {}
    for label, path in run_entries:
        if label in run_map:
            raise SystemExit(f"Duplicate run label: {label}")
        if not path.is_dir():
            raise SystemExit(f"Run path does not exist or is not a directory: {path}")
        run_map[label] = path

    ref_label = resolve_reference_label(args.reference, run_entries)

    for filename in args.files:
        config = FILE_CONFIG[filename]
        loaded: Dict[str, pd.DataFrame] = {}
        for label, path in run_entries:
            df = load_table(label, path, filename, config["keys"], config["metrics"])
            if df is not None:
                loaded[label] = df

        if ref_label not in loaded:
            print(f"\n[WARN] Skipping {filename}: reference run '{ref_label}' not loaded.")
            continue

        for label, df in loaded.items():
            if label == ref_label:
                continue
            describe_differences(
                filename,
                config["keys"],
                config["metrics"],
                ref_label,
                loaded[ref_label],
                label,
                df,
                args.top,
                args.precision,
            )


if __name__ == "__main__":  # pragma: no cover
    main()
