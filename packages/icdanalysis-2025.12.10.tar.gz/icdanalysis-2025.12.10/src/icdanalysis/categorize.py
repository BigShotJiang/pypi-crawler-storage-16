"""Categorization helpers for employment, education, ethnicity, and cohabitation."""

from __future__ import annotations

from typing import List, Optional

import numpy as np
import pandas as pd

from .constants import (
    CIVST_MARRIED,
    CIVST_NOT_MARRIED,
    DANISH_COUNTRY_CODES,
    FAMILIE_TYPE_ALONE,
    FAMILIE_TYPE_COHABITING,
    SOCIO13_OUTSIDE,
    SOCIO13_RETIRED,
    SOCIO13_TEMPORARILY_UNEMPLOYED,
    SOCIO13_WORKING,
    WESTERN_COUNTRY_CODES,
)


def categorize_employment(series: pd.Series) -> pd.Series:
    codes = pd.to_numeric(series, errors="coerce")
    categories = pd.Series("Missing/other", index=series.index, dtype="string")

    categories[codes.isin(list(SOCIO13_WORKING))] = "Working/Student"
    categories[codes.isin(list(SOCIO13_TEMPORARILY_UNEMPLOYED))] = (
        "Temporarily unemployed"
    )
    categories[codes.isin(list(SOCIO13_OUTSIDE))] = "Outside workforce"
    categories[codes.isin(list(SOCIO13_RETIRED))] = "Retired"

    return categories.astype("string")


def categorize_education(series: pd.Series) -> pd.Series:
    levels = pd.to_numeric(series, errors="coerce")
    categories = pd.Series("Unknown", index=series.index, dtype="string")

    categories[levels <= 2] = "Short education"
    categories[levels.isin([3, 4])] = "Medium education"
    categories[levels >= 5] = "Long education"
    categories[levels == 9] = "Unknown"

    categories[pd.isna(levels)] = "Unknown"
    return categories.astype("string")


def _normalise_country_code(value: object) -> Optional[str]:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return None
    text = str(value).strip().upper()
    if not text:
        return None
    text = text.replace(" ", "")
    if text.startswith("D") and len(text) > 1 and text[1:].isdigit():
        text = text[1:]
    return text


def _split_parent_codes(value: object) -> List[str]:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return []
    text = str(value).strip()
    if not text:
        return []
    separators = [";", ",", "|"]
    for sep in separators:
        if sep in text:
            parts = [part for part in text.split(sep) if part]
            normalized = [_normalise_country_code(part) for part in parts]
            return [code for code in normalized if code]
    parts = text.split()
    if len(parts) > 1:
        normalized = [_normalise_country_code(part) for part in parts]
        return [code for code in normalized if code]
    code = _normalise_country_code(text)
    return [code] if code else []


def categorize_ethnicity(
    child_country: pd.Series,
    parent_country: pd.Series,
    child_ie_type: pd.Series,
) -> pd.Series:
    child_codes = child_country.map(_normalise_country_code)
    parent_codes = parent_country.map(_split_parent_codes)
    ie_types = pd.to_numeric(child_ie_type, errors="coerce")

    categories: List[str] = []
    for idx in child_country.index:
        child_code = child_codes.at[idx]
        parents = [code for code in parent_codes.at[idx] if code]
        ie_type = ie_types.at[idx]

        child_danish = child_code in DANISH_COUNTRY_CODES
        child_western = child_code in WESTERN_COUNTRY_CODES
        child_non_western = (
            child_code not in DANISH_COUNTRY_CODES
            and child_code not in WESTERN_COUNTRY_CODES
            and child_code is not None
        )

        parents_danish = parents and all(
            code in DANISH_COUNTRY_CODES for code in parents
        )
        parents_western = parents and any(
            code in WESTERN_COUNTRY_CODES for code in parents
        )
        parents_non_western = parents and any(
            (code not in DANISH_COUNTRY_CODES) and (code not in WESTERN_COUNTRY_CODES)
            for code in parents
        )

        if ie_type == 1:
            categories.append("Danish Origin")
            continue

        if child_danish and (not parents or parents_danish):
            categories.append("Danish Origin")
            continue

        if child_western:
            categories.append("Western")
            continue

        if child_non_western:
            categories.append("Non-Western")
            continue

        if child_danish and parents_western and not parents_non_western:
            categories.append("Western")
            continue

        if child_danish and parents_non_western:
            categories.append("Non-Western")
            continue

        if parents_western and not parents_non_western:
            categories.append("Western")
            continue

        if parents_non_western:
            categories.append("Non-Western")
            continue

        if ie_type in {2, 3}:
            categories.append("Non-Western")
            continue

        categories.append("Unknown")

    return pd.Series(categories, index=child_country.index, dtype="string")


def categorize_cohabitation(
    familie_type: pd.Series,
    civst: pd.Series,
    civ_vfra: pd.Series,
) -> pd.Series:
    familie_codes = pd.to_numeric(familie_type, errors="coerce")
    civst_codes = civst.astype("string").str.upper().str.strip()

    cohab_status = pd.Series("Missing", index=familie_type.index, dtype="string")
    cohab_status[familie_codes.isin(list(FAMILIE_TYPE_COHABITING))] = "Cohabiting"
    cohab_status[familie_codes.isin(list(FAMILIE_TYPE_ALONE))] = "Living alone"

    marital_status = pd.Series("Missing", index=civst.index, dtype="string")
    marital_status[civst_codes.isin(list(CIVST_MARRIED))] = "Married"
    marital_status[civst_codes.isin(list(CIVST_NOT_MARRIED))] = "Not married"

    labels: List[str] = []
    for idx in familie_type.index:
        cohab = cohab_status.at[idx]
        marital = marital_status.at[idx]

        if cohab == "Cohabiting" or marital == "Married":
            labels.append("Cohabiting/Married")
        elif cohab == "Living alone" or marital == "Not married":
            labels.append("LivingAlone/NotMarried")
        else:
            labels.append("LivingAlone/NotMarried")

    return pd.Series(labels, index=familie_type.index, dtype="string")
