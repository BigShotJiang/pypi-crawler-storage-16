#!/usr/bin/env python3
"""Unified CLI entrypoint for icdanalysis tools."""

from __future__ import annotations

import argparse
from typing import Optional, Sequence

from . import compare_runs, estimation, preprocessing, table1
from . import manuscript

COMMANDS = {
    "preprocess": preprocessing.main,
    "estimate": estimation.main,
    "table1": table1.main,
    "compare-runs": compare_runs.main,
    "format-att": manuscript.cli_format_att,
    "refresh-outputs": manuscript.cli_refresh_outputs,
}


def main(argv: Optional[Sequence[str]] = None) -> None:
    parser = argparse.ArgumentParser(description="ICD analysis toolkit CLI")
    parser.add_argument(
        "command",
        choices=sorted(COMMANDS.keys()),
        help="Which tool to run (use the chosen subcommand's --help for options).",
    )
    args, remaining = parser.parse_known_args(argv)

    handler = COMMANDS[args.command]
    handler(remaining)


if __name__ == "__main__":  # pragma: no cover
    main()
