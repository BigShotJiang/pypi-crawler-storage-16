"""Shared constants for ICD analysis utilities."""

from __future__ import annotations

DEFAULT_CPI_BASE_YEAR = 2015

DKK_PER_EUR = 7.45  # Fixed conversion rate to report amounts in EUR

ANNUAL_CPI_INDEX = {
    2000: 76.2167,
    2001: 78.0250,
    2002: 79.9167,
    2003: 81.5750,
    2004: 82.5167,
    2005: 84.0167,
    2006: 85.6333,
    2007: 87.0833,
    2008: 90.0583,
    2009: 91.2333,
    2010: 93.3417,
    2011: 95.9167,
    2012: 98.2167,
    2013: 98.9917,
    2014: 99.5500,
    2015: 100.0000,
    2016: 100.2500,
    2017: 101.4000,
    2018: 102.2250,
    2019: 103.0000,
    2020: 103.4333,
    2021: 105.3500,
    2022: 113.4583,
    2023: 117.2083,
    2024: 118.8167,
    2025: 120.9900,
}

DANISH_COUNTRY_CODES = {"5100", "5101", "5115", "5901", "5902"}
WESTERN_COUNTRY_CODES = {
    "5104",
    "5105",
    "5106",
    "5107",
    "5108",
    "5109",
    "5110",
    "5111",
    "5116",
    "5120",
    "5124",
    "5126",
    "5128",
    "5129",
    "5130",
    "5134",
    "5140",
    "5142",
    "5150",
    "5153",
    "5154",
    "5156",
    "5158",
    "5159",
    "5160",
    "5164",
    "5170",
    "5174",
    "5176",
    "5180",
    "5182",
    "5184",
    "5314",
    "5390",
    "5397",
    "5399",
    "5422",
    "5502",
    "5514",
    "5607",
    "5609",
    "5611",
    "5750",
    "5752",
    "5776",
    "5778",
}
REGION_PREFIX_MAP = {
    "01": "danish_origin",
    "02": "western",
    "03": "non_western",
}

FAMILIE_TYPE_COHABITING = {1, 2, 3, 4, 7, 8}
FAMILIE_TYPE_ALONE = {5, 9, 10}
CIVST_MARRIED = {"G", "P"}
CIVST_NOT_MARRIED = {"U", "F", "O", "E", "L"}

SOCIO13_WORKING = {110, 111, 112, 113, 114, 120, 131, 132, 133, 134, 135, 139, 310}
SOCIO13_UNEMPLOYED = {210}
SOCIO13_SICK_OR_PARENTAL_LEAVE = {220}
SOCIO13_OUTSIDE = {330, 321}
SOCIO13_RETIRED = {323, 322}
SOCIO13_TEMPORARILY_UNEMPLOYED = SOCIO13_UNEMPLOYED | SOCIO13_SICK_OR_PARENTAL_LEAVE
