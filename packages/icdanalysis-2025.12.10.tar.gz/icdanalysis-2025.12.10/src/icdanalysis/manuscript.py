"""Utilities for generating manuscript-ready artefacts from estimation outputs.

This module packages the logic that previously lived in ``scripts/`` so it can
be used as part of the installed CLI. Templates for tables and plots are
shipped with the package and loaded via ``importlib.resources`` by default.
"""

from __future__ import annotations

import argparse
import csv
import re
from importlib import resources
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

FLOAT_COLUMNS = ("estimate", "std_error", "conf_low", "conf_high")
INT_COLUMNS = ("reference_year", "relative_year", "n_pairs", "n_treated", "n_control")
SAMPLE_ORDER = {"all": 0, "mother": 1, "father": 2}

HORIZON_ORDER = [
    "horizon_short_term",
    "horizon_medium_term",
    "horizon_long_term",
    "horizon_very_long_term",
]

CHAPTER_MAP = {
    "II": "II Neoplasms",
    "III": "III Diseases of the blood and blood-forming organs and certain disorders involving the immune mechanism",
    "IV": "IV Endocrine, nutritional and metabolic diseases",
    "VI": "VI Diseases of the nervous system",
    "IX": "IX Diseases of the circulatory system",
    "X": "X Diseases of the respiratory system",
    "XI": "XI Diseases of the digestive system",
    "XIII": "XIII Diseases of the musculoskeletal system and connective tissue",
    "XIV": "XIV Diseases of the genitourinary system",
    "XVI": "XVI Certain conditions originating in the perinatal period",
    "XVII": "XVII Congenital malformations, deformations and chromosomal abnormalities",
}


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def friendly_outcome_name(outcome: str) -> str:
    return outcome.split("_")[0]


def format_numeric(row: dict) -> dict:
    formatted = row.copy()
    for key in INT_COLUMNS:
        if key in formatted and formatted[key] != "":
            formatted[key] = str(int(float(formatted[key])))
    for key in FLOAT_COLUMNS:
        if key in formatted and formatted[key] != "":
            formatted[key] = f"{float(formatted[key]):.1f}"
    return formatted


def sort_rows(rows: Iterable[dict], keys: Sequence[str]) -> List[dict]:
    def sort_key(row: dict) -> tuple:
        ordering = []
        for key in keys:
            if key == "sample":
                ordering.append(SAMPLE_ORDER.get(row.get(key, ""), len(SAMPLE_ORDER)))
            elif key in INT_COLUMNS:
                ordering.append(int(row[key]))
            else:
                ordering.append(row.get(key, ""))
        return tuple(ordering)

    return sorted(rows, key=sort_key)


def write_tsv(path: Path, rows: Iterable[dict], fieldnames: Sequence[str]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter="\t")
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fieldnames})
    return path


def read_att_rows(path: Path) -> List[dict]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _with_suffix(path: Path, suffix: str) -> Path:
    if not suffix:
        return path
    suffix = suffix if suffix.startswith(".") else f".{suffix}"
    return path.with_name(path.stem + suffix + path.suffix)


def _read_template(relative_path: str, override_root: Optional[Path] = None) -> str:
    if override_root is not None:
        return (override_root / relative_path).read_text(encoding="utf-8")
    resource_path = resources.files("icdanalysis.templates").joinpath(relative_path)
    with resource_path.open("r", encoding="utf-8") as handle:
        return handle.read()


# --------------------------------------------------------------------------- #
# ATT formatting
# --------------------------------------------------------------------------- #
def format_att_effects(
    att_path: Path, results_dir: Path, suffix: str = ""
) -> Tuple[Path, Path, Path]:
    """Split ATT CSV into primary/secondary/sensitivity TSVs."""
    if not att_path.exists():
        raise FileNotFoundError(f"att_effects.csv not found: {att_path}")

    rows = read_att_rows(att_path)

    primary, secondary, sensitivity = [], [], []
    for row in rows:
        if row["chapter"] == "OVERALL":
            out = row.copy()
            out["outcome"] = friendly_outcome_name(out["outcome"])
            out = format_numeric(out)
            if out["outcome"].startswith("PERINDKIALT"):
                primary.append(out)
            elif out["outcome"].startswith("LOENMV"):
                secondary.append(out)
        else:
            out = row.copy()
            out["outcome"] = friendly_outcome_name(out["outcome"])
            out["icd_chapter"] = out.pop("chapter")
            sensitivity.append(format_numeric(out))

    primary = sort_rows(primary, ("sample", "reference_year", "relative_year"))
    secondary = sort_rows(secondary, ("sample", "reference_year", "relative_year"))
    sensitivity = sort_rows(
        sensitivity,
        ("outcome", "icd_chapter", "sample", "reference_year", "relative_year"),
    )

    primary_path = _with_suffix(results_dir / "primary_outcome.tsv", suffix)
    secondary_path = _with_suffix(results_dir / "secondary_outcome.tsv", suffix)
    sensitivity_path = _with_suffix(
        results_dir / "sensitivity_icd_chapters.tsv", suffix
    )

    write_tsv(
        primary_path,
        primary,
        [
            "outcome",
            "sample",
            "reference_year",
            "relative_year",
            "estimate",
            "std_error",
            "conf_low",
            "conf_high",
            "n_pairs",
            "n_treated",
            "n_control",
            "convergence",
        ],
    )
    write_tsv(
        secondary_path,
        secondary,
        [
            "outcome",
            "sample",
            "reference_year",
            "relative_year",
            "estimate",
            "std_error",
            "conf_low",
            "conf_high",
            "n_pairs",
            "n_treated",
            "n_control",
            "convergence",
        ],
    )
    write_tsv(
        sensitivity_path,
        sensitivity,
        [
            "outcome",
            "icd_chapter",
            "sample",
            "reference_year",
            "relative_year",
            "estimate",
            "std_error",
            "conf_low",
            "conf_high",
            "n_pairs",
            "n_treated",
            "n_control",
            "convergence",
        ],
    )
    return primary_path, secondary_path, sensitivity_path


# --------------------------------------------------------------------------- #
# Table 2 (horizon aggregates)
# --------------------------------------------------------------------------- #
def load_aggregated_effects(path: Path) -> List[dict]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def extract_horizon_values(
    rows: Iterable[dict],
) -> Tuple[Dict[Tuple[str, str, str], Tuple[int, int, int]], Dict[str, List[int]]]:
    """
    Return:
      vals[(sample, label, component)] = (est, lo, hi) rounded to int
      pairs[sample] = average n_pairs per period for each horizon
    """
    vals: Dict[Tuple[str, str, str], Tuple[int, int, int]] = {}
    pairs: Dict[str, List[int]] = {"mother": [], "father": []}
    for comp in HORIZON_ORDER:
        for sample in ("mother", "father"):
            for outcome, label in (("PERINDKIALT", "total"), ("LOENMV", "wage")):
                row = next(
                    r
                    for r in rows
                    if r["chapter"] == "OVERALL"
                    and r["sample"] == sample
                    and r["outcome"].startswith(outcome)
                    and r["component"] == comp
                )
                est, lo, hi = (
                    round(float(row[k])) for k in ("estimate", "conf_low", "conf_high")
                )
                vals[(sample, label, comp)] = (est, lo, hi)
            bucket = int(row["bucket_periods"] or 1)
            pairs[sample].append(round(int(row["n_pairs"]) / bucket))
    return vals, pairs


def render_horizon_block(
    vals: Dict[Tuple[str, str, str], Tuple[int, int, int]], sample: str, label: str
) -> str:
    entries = []
    for comp in HORIZON_ORDER:
        est, lo, hi = vals[(sample, label, comp)]
        entries.append(f"\\estci{{{est}}}{{{lo}}}{{{hi}}}")
    return f"& {label.capitalize()} income\n\t\t& " + " & ".join(entries) + " \\\\"


def update_estimates_table(
    vals: Dict[Tuple[str, str, str], Tuple[int, int, int]],
    pairs: Dict[str, List[int]],
    output_path: Path,
    template_root: Optional[Path] = None,
) -> Path:
    text = _read_template("tables/estimates.tex", template_root)

    def replace_block(sample: str, label: str, comment_label: str) -> None:
        nonlocal text
        pattern = (
            rf"(% {comment_label}\s*\n\s*& {label.capitalize()} income\s*& .*?\\\\)"
        )
        replacement = render_horizon_block(vals, sample, label)
        text = re.sub(
            pattern,
            lambda _: f"% {comment_label}\n\t\t{replacement}",
            text,
            count=1,
            flags=re.S,
        )

    replace_block("mother", "total", "Mothers - Total income")
    replace_block("mother", "wage", "Mothers - Wage income")
    replace_block("father", "total", "Fathers - Total income")
    replace_block("father", "wage", "Fathers - Wage income")

    footnote_pattern = r"Average matched pairs per horizon .*?are\n\t.*?for mothers and\n\t.*?for fathers\."
    footnote_repl = (
        "Average matched pairs per horizon (0--2 / 3--6 / 7--10 / 11--15) are\n\t"
        + " / ".join(f"{n:,}" for n in pairs["mother"])
        + " for mothers and\n\t"
        + " / ".join(f"{n:,}" for n in pairs["father"])
        + " for fathers."
    )
    text = re.sub(footnote_pattern, footnote_repl, text, count=1, flags=re.S)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(text)
    return output_path


# --------------------------------------------------------------------------- #
# Appendix event-time table
# --------------------------------------------------------------------------- #
def update_model_estimates_table(
    primary_tsv: Path,
    secondary_tsv: Path,
    output_path: Path,
    template_root: Optional[Path] = None,
) -> Path:
    pri = list(csv.DictReader(primary_tsv.open(), delimiter="\t"))
    sec = list(csv.DictReader(secondary_tsv.open(), delimiter="\t"))

    def lookup(data: List[dict], sample: str, rel: int) -> Tuple[int, int, int]:
        row = next(
            r
            for r in data
            if r["sample"] == sample
            and r["reference_year"] == "-1"
            and int(r["relative_year"]) == rel
        )
        return tuple(
            round(float(row[k])) for k in ("estimate", "conf_low", "conf_high")
        )

    lines = []
    for rel in range(0, 16):
        mt = lookup(pri, "mother", rel)
        mw = lookup(sec, "mother", rel)
        ft = lookup(pri, "father", rel)
        fw = lookup(sec, "father", rel)
        lines.append(
            f"\t\t{rel:>2}  & \\estci{{{mt[0]}}}{{{mt[1]}}}{{{mt[2]}}} & "
            f"\\estci{{{mw[0]}}}{{{mw[1]}}}{{{mw[2]}}} & "
            f"\\estci{{{ft[0]}}}{{{ft[1]}}}{{{ft[2]}}} & "
            f"\\estci{{{fw[0]}}}{{{fw[1]}}}{{{fw[2]}}} \\\\"
        )

    block = "\n".join(lines)
    text = _read_template("appendix/model_estimates.tex", template_root)
    text = re.sub(r"\t\t0.*?15 .*?\\\\", lambda _: block, text, flags=re.S)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(text)
    return output_path


# --------------------------------------------------------------------------- #
# Plot coordinate generation
# --------------------------------------------------------------------------- #
def update_plots_from_att(
    att_path: Path,
    output_dir: Path,
    templates_root: Optional[Path] = None,
) -> None:
    rows = read_att_rows(att_path)

    def build_series(
        chapter: str, outcome_prefix: str, sample: str
    ) -> List[Tuple[int, float, float]]:
        relevant = [
            r
            for r in rows
            if r["chapter"] == chapter
            and r["sample"] == sample
            and r["outcome"].startswith(outcome_prefix)
        ]
        by_key = {}
        for r in relevant:
            if not r["estimate"] or not r["conf_high"]:
                continue
            by_key[(int(r["reference_year"]), int(r["relative_year"]))] = r

        series: List[Tuple[int, float, float]] = []
        for ref in (-5, -4, -3, -2):
            key = (ref, -1)
            if key not in by_key:
                continue
            r = by_key[key]
            est = float(r["estimate"]) / 100
            err = float(r["conf_high"]) / 100 - est
            series.append((ref, est, err))
        series.append((-1, 0.0, 0.0))
        for rel in range(0, 16):
            key = (-1, rel)
            if key not in by_key:
                continue
            r = by_key[key]
            est = float(r["estimate"]) / 100
            err = float(r["conf_high"]) / 100 - est
            series.append((rel, est, err))
        return series

    def format_coords(series: List[Tuple[int, float, float]]) -> str:
        lines = []
        for x, y, err in series:
            lines.append(f"\t\t\t({x}, {y:.2f}) +- (0, {err:.3f}) +- (0, {err:.3f})")
        return "\n".join(lines)

    def replace_after_marker(text: str, marker: str, new_lines: str) -> str:
        idx = text.index(marker)
        head, tail = text[:idx], text[idx:]
        replaced = re.sub(
            r"(coordinates \{\n)(.*?)(\n\s*\};)",
            lambda m: m.group(1) + new_lines + m.group(3),
            tail,
            count=1,
            flags=re.S,
        )
        return head + replaced

    def load_plot_template(relative_path: str) -> str:
        return _read_template(relative_path, templates_root)

    output_dir.mkdir(parents=True, exist_ok=True)
    sens_output_dir = output_dir / "sensitivity_icd"
    sens_output_dir.mkdir(parents=True, exist_ok=True)

    for filename, outcome_prefix in (
        ("labour_earnings.tex", "LOENMV"),
        ("total_income.tex", "PERINDKIALT"),
    ):
        text = load_plot_template(f"plots/{filename}")
        mother_coords = format_coords(build_series("OVERALL", outcome_prefix, "mother"))
        father_coords = format_coords(build_series("OVERALL", outcome_prefix, "father"))
        text = replace_after_marker(text, "mothercolor", mother_coords)
        text = replace_after_marker(text, "fathercolor", father_coords)
        (output_dir / filename).write_text(text)

    for roman, chapter in CHAPTER_MAP.items():
        template_name = f"plots/sensitivity_icd/total_income_icd_{roman}.tex"
        try:
            text = load_plot_template(template_name)
        except FileNotFoundError:
            continue
        mother_coords = format_coords(build_series(chapter, "PERINDKIALT", "mother"))
        father_coords = format_coords(build_series(chapter, "PERINDKIALT", "father"))
        text = replace_after_marker(text, "mothercolor", mother_coords)
        text = replace_after_marker(text, "fathercolor", father_coords)
        (sens_output_dir / Path(template_name).name).write_text(text)


def update_results_text() -> None:
    """No-op placeholder retained for backward compatibility."""
    return None


# --------------------------------------------------------------------------- #
# Orchestration
# --------------------------------------------------------------------------- #
def refresh_outputs(
    drop_dir: Path,
    output_root: Optional[Path] = None,
    results_dir: Optional[Path] = None,
    suffix: str = ".generated",
    templates_root: Optional[Path] = None,
    skip_plots: bool = False,
    skip_text: bool = False,
) -> None:
    root = output_root or Path.cwd()
    results = results_dir or (root / "results")
    results.mkdir(parents=True, exist_ok=True)

    att_path = drop_dir / "att_effects.csv"
    agg_path = drop_dir / "aggregated_effects.csv"

    primary_path, secondary_path, _ = format_att_effects(
        att_path, results, suffix=suffix
    )

    agg_rows = load_aggregated_effects(agg_path)
    horizon_vals, pair_counts = extract_horizon_values(agg_rows)

    tables_dir = root / "tables"
    tables_dir.mkdir(parents=True, exist_ok=True)
    est_out = tables_dir / f"estimates{suffix}.tex"
    update_estimates_table(
        horizon_vals, pair_counts, est_out, template_root=templates_root
    )

    appendix_dir = root / "appendix"
    appendix_dir.mkdir(parents=True, exist_ok=True)
    appendix_out = appendix_dir / f"model_estimates{suffix}.tex"
    update_model_estimates_table(
        primary_path, secondary_path, appendix_out, template_root=templates_root
    )

    if not skip_plots:
        plots_out = root / "plots" / "generated"
        update_plots_from_att(att_path, plots_out, templates_root=templates_root)
    if not skip_text:
        update_results_text()

    print("[done] refresh complete")


# --------------------------------------------------------------------------- #
# CLI entry points
# --------------------------------------------------------------------------- #
def cli_format_att(argv: Optional[Sequence[str]] = None) -> None:
    parser = argparse.ArgumentParser(description="Format ATT outputs into TSV tables.")
    parser.add_argument("att_path", type=Path, help="Path to att_effects.csv")
    parser.add_argument(
        "--results-dir",
        type=Path,
        default=Path.cwd() / "results",
        help="Directory for TSV outputs (default: ./results)",
    )
    parser.add_argument(
        "--suffix",
        default="",
        help="Suffix inserted before .tsv (e.g., .generated). Default: none (overwrite base files).",
    )
    args = parser.parse_args(argv)

    format_att_effects(args.att_path, args.results_dir, suffix=args.suffix)


def cli_refresh_outputs(argv: Optional[Sequence[str]] = None) -> None:
    parser = argparse.ArgumentParser(
        description="Refresh manuscript artefacts from a new estimation drop."
    )
    parser.add_argument(
        "drop_dir",
        type=Path,
        help="Directory containing att_effects.csv and aggregated_effects.csv",
    )
    parser.add_argument(
        "--output-root",
        type=Path,
        default=Path.cwd(),
        help="Root directory for generated artefacts (results/tables/appendix/plots). Default: CWD.",
    )
    parser.add_argument(
        "--results-dir",
        type=Path,
        default=None,
        help="Optional override for results directory (defaults to <output-root>/results).",
    )
    parser.add_argument(
        "--suffix",
        default=".generated",
        help="Suffix inserted before output extensions (default: .generated).",
    )
    parser.add_argument(
        "--templates-root",
        type=Path,
        default=None,
        help="Optional directory containing template files to override the packaged defaults.",
    )
    parser.add_argument(
        "--skip-plots",
        action="store_true",
        help="Skip plot coordinate regeneration.",
    )
    parser.add_argument(
        "--skip-text",
        action="store_true",
        help="Skip narrative text replacement.",
    )
    args = parser.parse_args(argv)

    refresh_outputs(
        args.drop_dir,
        output_root=args.output_root,
        results_dir=args.results_dir,
        suffix=args.suffix,
        templates_root=args.templates_root,
        skip_plots=args.skip_plots,
        skip_text=args.skip_text,
    )
