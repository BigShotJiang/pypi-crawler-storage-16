#!/usr/bin/env python3
"""Event-study preprocessing utilities.

This script reads a parquet dataset and adds the high-level categorizations used
throughout the project. It consolidates the R-based logic from the
`PYTHON/r-categorization` helpers into a lightweight Python CLI:

* Employment category from `SOCIO13`
* Education category from `ISCED`
* Ethnicity category from `PARENT_OPR_LAND`, `CHILD_OPR_LAND`, `CHILD_IE_TYPE`
* Cohabitation category from `FAMILIE_TYPE`, `CIVST`, `CIV_VFRA`
* Winsorised versions of `PERINDKIALT_13` and `LOENMV_13`

Example
-------

```
uv run python PYTHON/preprocessing.py \
  --input data/raw_dataset.parquet \
  --output data/preprocessed_dataset.parquet
```
"""

from __future__ import annotations

import argparse
import logging
from pathlib import Path
from typing import Optional, Sequence

import numpy as np
import pandas as pd

from .categorize import (
    categorize_cohabitation,
    categorize_education,
    categorize_employment,
    categorize_ethnicity,
)
from .constants import ANNUAL_CPI_INDEX, DEFAULT_CPI_BASE_YEAR, DKK_PER_EUR
from .geo import normalise_municipality_codes

LOGGER = logging.getLogger(__name__)


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--input",
        required=True,
        help="Input parquet file.",
    )
    parser.add_argument(
        "--output",
        required=True,
        help="Output parquet file.",
    )
    parser.add_argument(
        "--winsor-lower",
        type=float,
        default=0.01,
        help="Lower winsorisation percentile (default: 0.01).",
    )
    parser.add_argument(
        "--winsor-upper",
        type=float,
        default=0.99,
        help="Upper winsorisation percentile (default: 0.99).",
    )
    parser.add_argument(
        "--cpi-base-year",
        type=int,
        default=DEFAULT_CPI_BASE_YEAR,
        help=f"Reference year for CPI deflation (default: {DEFAULT_CPI_BASE_YEAR}).",
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        help="Logging verbosity (default: INFO).",
    )
    return parser.parse_args(argv)


def configure_logging(level: str) -> None:
    logging.basicConfig(
        level=getattr(logging, level),
        format="[%(levelname)s] %(message)s",
    )


def winsorise(series: pd.Series, lower: float, upper: float) -> pd.Series:
    if series.dropna().empty:
        return series
    quantiles = series.quantile([lower, upper])
    lower_bound = quantiles.iloc[0]
    upper_bound = quantiles.iloc[1]
    return series.clip(lower=lower_bound, upper=upper_bound)


def winsorise_by_group(
    df: pd.DataFrame,
    column: str,
    group_column: str,
    lower: float,
    upper: float,
) -> pd.Series:
    if group_column not in df.columns:
        raise KeyError(f"Grouping column '{group_column}' not found in dataframe.")

    numeric = pd.to_numeric(df[column], errors="coerce")
    grouped = numeric.groupby(df[group_column], observed=True)
    lower_bounds = grouped.quantile(lower)
    upper_bounds = grouped.quantile(upper)

    lower_map = lower_bounds.reindex(df[group_column]).to_numpy()
    upper_map = upper_bounds.reindex(df[group_column]).to_numpy()

    global_quantiles = numeric.quantile([lower, upper])
    global_lower = global_quantiles.iloc[0]
    global_upper = global_quantiles.iloc[1]

    lower_map = np.where(np.isnan(lower_map), global_lower, lower_map)
    upper_map = np.where(np.isnan(upper_map), global_upper, upper_map)

    clipped = np.clip(numeric.to_numpy(dtype=float), lower_map, upper_map)
    return pd.Series(clipped, index=df.index)


def deflate_outcomes(
    df: pd.DataFrame,
    base_year: Optional[int],
    outcomes: Sequence[str] = ("PERINDKIALT_13", "LOENMV_13"),
) -> pd.DataFrame:
    if "YEAR" not in df.columns:
        LOGGER.warning("Column 'YEAR' missing; skipping CPI deflation.")
        return df

    cpi_df = pd.DataFrame(
        {
            "YEAR": list(ANNUAL_CPI_INDEX.keys()),
            "CPI_VALUE": list(ANNUAL_CPI_INDEX.values()),
        }
    )
    df = df.copy()
    max_year = int(df["YEAR"].max())
    last_cpi_year = int(cpi_df["YEAR"].max())
    if max_year > last_cpi_year:
        last_value = float(
            cpi_df.loc[cpi_df["YEAR"] == last_cpi_year, "CPI_VALUE"].iloc[0]
        )
        extra_years = pd.DataFrame(
            {"YEAR": range(last_cpi_year + 1, max_year + 1), "CPI_VALUE": last_value}
        )
        cpi_df = pd.concat([cpi_df, extra_years], ignore_index=True)

    reference_year = base_year if base_year is not None else DEFAULT_CPI_BASE_YEAR
    if reference_year not in set(cpi_df["YEAR"]):
        raise ValueError(f"Reference year {reference_year} not available in CPI table.")
    reference_value = float(
        cpi_df.loc[cpi_df["YEAR"] == reference_year, "CPI_VALUE"].iloc[0]
    )
    cpi_df["__deflator"] = reference_value / cpi_df["CPI_VALUE"]

    df = df.merge(cpi_df[["YEAR", "__deflator"]], on="YEAR", how="left")
    if df["__deflator"].isna().any():
        missing = df.loc[df["__deflator"].isna(), "YEAR"].unique()
        LOGGER.warning(
            "Missing CPI values for years: %s. Using reference-year deflator instead.",
            ", ".join(map(str, sorted(missing))),
        )
        df["__deflator"] = df["__deflator"].fillna(1.0)

    LOGGER.info(
        "Deflating monetary outcomes using CPI reference year %s (value %.2f)",
        reference_year,
        reference_value,
    )

    for outcome in outcomes:
        if outcome not in df.columns:
            LOGGER.warning("Outcome column '%s' missing; skipping deflation.", outcome)
            continue
        nominal_series = pd.to_numeric(df[outcome], errors="coerce")
        if nominal_series.isna().all():
            LOGGER.warning(
                "Outcome column '%s' contains no numeric data after coercion; skipping.",
                outcome,
            )
            continue
        nominal_dkk = nominal_series
        df[f"{outcome}_nominal_dkk"] = nominal_dkk
        df[f"{outcome}_nominal_eur"] = nominal_dkk / DKK_PER_EUR
        df[f"{outcome}_deflated_dkk"] = nominal_dkk * df["__deflator"]
        df[f"{outcome}_deflated_eur"] = df[f"{outcome}_deflated_dkk"] / DKK_PER_EUR
        df[f"{outcome}_deflated"] = df[f"{outcome}_deflated_eur"]
        df[outcome] = df[f"{outcome}_deflated_eur"]

    df = df.drop(columns="__deflator")
    return df


def add_categorizations(
    df: pd.DataFrame,
    winsor_lower: float,
    winsor_upper: float,
) -> pd.DataFrame:
    enriched = df.copy()

    if "SOCIO13" in enriched.columns:
        LOGGER.info("Creating employment_category from SOCIO13")
        enriched["employment_category"] = categorize_employment(enriched["SOCIO13"])
    else:
        LOGGER.warning(
            "Column 'SOCIO13' not found; skipping employment categorization."
        )

    if "ISCED" in enriched.columns:
        LOGGER.info("Creating education_category from ISCED")
        enriched["education_category"] = categorize_education(enriched["ISCED"])
    else:
        LOGGER.warning("Column 'ISCED' not found; skipping education categorization.")

    if "MUN_CODE" in enriched.columns:
        LOGGER.info(
            "Standardizing municipality codes to 2007 version and mapping to LAN/REGION"
        )
        geo_df = normalise_municipality_codes(enriched["MUN_CODE"])
        for col in geo_df.columns:
            enriched[col] = geo_df[col]
    else:
        LOGGER.warning(
            "Column 'MUN_CODE' not found; skipping municipality/region mapping."
        )

    required_ethnicity_cols = {"PARENT_OPR_LAND", "CHILD_OPR_LAND", "CHILD_IE_TYPE"}
    if required_ethnicity_cols.issubset(enriched.columns):
        LOGGER.info("Creating ethnicity_category from origin columns")
        enriched["ethnicity_category"] = categorize_ethnicity(
            enriched["CHILD_OPR_LAND"],
            enriched["PARENT_OPR_LAND"],
            enriched["CHILD_IE_TYPE"],
        )
    else:
        missing = required_ethnicity_cols - set(enriched.columns)
        LOGGER.warning(
            "Skipping ethnicity categorization; missing columns: %s",
            ", ".join(sorted(missing)),
        )

    required_cohab_cols = {"FAMILIE_TYPE", "CIVST", "CIV_VFRA"}
    if required_cohab_cols.issubset(enriched.columns):
        LOGGER.info(
            "Creating cohabitation_category from family and civil status columns"
        )
        enriched["cohabitation_category"] = categorize_cohabitation(
            enriched["FAMILIE_TYPE"],
            enriched["CIVST"],
            enriched["CIV_VFRA"],
        )
    else:
        missing = required_cohab_cols - set(enriched.columns)
        LOGGER.warning(
            "Skipping cohabitation categorization; missing columns: %s",
            ", ".join(sorted(missing)),
        )

    group_column = "YEAR"
    for outcome in ("PERINDKIALT_13", "LOENMV_13"):
        if outcome in enriched.columns:
            if group_column in enriched.columns:
                LOGGER.info(
                    "Winsorising %s by %s (%.2f, %.2f)",
                    outcome,
                    group_column,
                    winsor_lower,
                    winsor_upper,
                )
                enriched[f"{outcome}_winsorized"] = winsorise_by_group(
                    enriched,
                    outcome,
                    group_column,
                    winsor_lower,
                    winsor_upper,
                )
            else:
                LOGGER.warning(
                    "Grouping column '%s' missing; applying global winsorisation to %s.",
                    group_column,
                    outcome,
                )
                enriched[f"{outcome}_winsorized"] = winsorise(
                    pd.to_numeric(enriched[outcome], errors="coerce"),
                    winsor_lower,
                    winsor_upper,
                )
        else:
            LOGGER.warning(
                "Outcome column '%s' not found; skipping winsorisation.", outcome
            )

    return enriched


def main(argv: Optional[Sequence[str]] = None) -> None:
    args = parse_args(argv)
    configure_logging(args.log_level)

    input_path = Path(args.input)
    output_path = Path(args.output)

    LOGGER.info("Reading parquet data from %s", input_path)
    df = pd.read_parquet(input_path)

    df = deflate_outcomes(df, args.cpi_base_year)

    enriched = add_categorizations(df, args.winsor_lower, args.winsor_upper)

    LOGGER.info("Writing enriched data to %s", output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    enriched.to_parquet(output_path, index=False)
    LOGGER.info("Preprocessing completed successfully.")


if __name__ == "__main__":  # pragma: no cover
    main()
