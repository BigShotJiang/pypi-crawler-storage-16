"""Helper functions for Table 1 summaries and derived covariates."""

from __future__ import annotations

from typing import Optional, Tuple, cast

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.weightstats import CompareMeans, DescrStatsW

from .constants import (
    SOCIO13_OUTSIDE,
    SOCIO13_RETIRED,
    SOCIO13_TEMPORARILY_UNEMPLOYED,
    SOCIO13_WORKING,
)


def ensure_datetime(series: pd.Series) -> pd.Series:
    return pd.to_datetime(series, errors="coerce")


def compute_age(reference: pd.Series, birth: pd.Series) -> pd.Series:
    ref = ensure_datetime(reference)
    birth = ensure_datetime(birth)
    delta = cast(pd.Series, ref - birth)
    seconds = cast(pd.Series, delta.dt.total_seconds())
    return seconds / (365.25 * 24 * 3600)


def derive_gender(df: pd.DataFrame) -> pd.Series:
    if "gender" in df.columns:
        return df["gender"].astype("string")

    gender = pd.Series("unknown", index=df.index, dtype="string")
    if "parent_type" in df.columns:
        parent = df["parent_type"].astype("string").str.lower().str.strip()
        gender[parent.isin({"mother", "mor", "m", "moder"})] = "female"
        gender[parent.isin({"father", "far", "f", "fader"})] = "male"

    for candidate in ("gender_code", "gender_flag", "sex"):
        if candidate in df.columns:
            code = df[candidate].astype("string").str.lower().str.strip()
            gender[code.isin({"female", "f", "kvinde", "2"})] = "female"
            gender[code.isin({"male", "m", "mand", "1"})] = "male"
            break

    return gender


def weighted_counts(
    series: pd.Series, weights: Optional[pd.Series]
) -> Tuple[pd.Series, float]:
    if weights is None:
        counts = series.value_counts(dropna=False, sort=False)
        total = float(counts.sum())
    else:
        working = pd.DataFrame({"cat": series, "w": weights})
        counts = working.groupby("cat")[["w"]].sum()["w"]
        total = float(counts.sum())
    return counts, total


def derive_parity(df: pd.DataFrame) -> pd.Series:
    if "parity_category" in df.columns:
        return df["parity_category"].astype("string")
    if "PARITET_CAT" in df.columns:
        parity_numeric = pd.to_numeric(df["PARITET_CAT"], errors="coerce")
        parity = cast(pd.Series, parity_numeric).fillna(0).astype(int)
        labels = parity.map({0: "unknown", 1: "1", 2: "2"}).astype("string")
        labels[parity >= 3] = "3+"
        return labels
    return pd.Series("unknown", index=df.index, dtype="string")


def derive_employment_split(series: pd.Series) -> pd.Series:
    """Split Working/Student into separate categories for descriptives."""
    codes = pd.to_numeric(series, errors="coerce")
    categories = pd.Series("Missing/other", index=series.index, dtype="string")
    working_codes = set(SOCIO13_WORKING) - {310}
    categories[codes.isin(list(working_codes))] = "Working"
    categories[codes == 310] = "Student"
    categories[codes.isin(list(SOCIO13_TEMPORARILY_UNEMPLOYED))] = (
        "Temporarily unemployed"
    )
    categories[codes.isin(list(SOCIO13_OUTSIDE))] = "Outside workforce"
    categories[codes.isin(list(SOCIO13_RETIRED))] = "Retired"
    return categories.astype("string")


def derive_student_status(series: pd.Series) -> pd.Series:
    codes = pd.to_numeric(series, errors="coerce")
    status = pd.Series("Not student", index=series.index, dtype="string")
    status[codes.isna()] = "Missing/other"
    status[codes == 310] = "Student"
    return status.astype("string")


def compute_categorical_p_value(
    df: pd.DataFrame,
    variable: str,
    group_col: str,
    weights: Optional[pd.Series],
) -> float:
    groups = df[group_col].unique()
    if len(groups) != 2:
        return np.nan

    group1, group2 = groups
    categories = df[variable].dropna().unique()
    if len(categories) <= 1:
        return np.nan

    if weights is None:
        contingency = pd.crosstab(df[variable], df[group_col], dropna=False)
        chi2, p_value, _, _ = stats.chi2_contingency(contingency)
        return float(p_value)

    df = df.copy()
    df["_weight"] = weights
    contingency = pd.pivot_table(
        df, values="_weight", index=variable, columns=group_col, aggfunc="sum"
    ).fillna(0)
    chi2, p_value, _, _ = stats.chi2_contingency(contingency)
    return float(p_value)


def compute_continuous_p_value(
    df: pd.DataFrame,
    variable: str,
    group_col: str,
    weights: Optional[pd.Series],
) -> float:
    groups = df[group_col].unique()
    if len(groups) != 2:
        return np.nan
    group1, group2 = groups

    if weights is None:
        stat, p_value = stats.ttest_ind(
            df[df[group_col] == group1][variable].dropna(),
            df[df[group_col] == group2][variable].dropna(),
            equal_var=False,
        )
    else:
        g1 = DescrStatsW(
            df[df[group_col] == group1][variable].dropna(),
            weights=df[df[group_col] == group1][weights.name].dropna(),
        )
        g2 = DescrStatsW(
            df[df[group_col] == group2][variable].dropna(),
            weights=df[df[group_col] == group2][weights.name].dropna(),
        )
        cm = CompareMeans(g1, g2)
        stat, p_value = cm.ttest_ind(usevar="unequal")
    return float(p_value)


def summarize_continuous(
    series: pd.Series, weights: Optional[pd.Series] = None
) -> Tuple[float, float, float, float, float]:
    if weights is not None:
        w = weights.loc[series.index]
        weighted_stats = DescrStatsW(series, weights=w, ddof=0)
        mean = float(weighted_stats.mean)
        std = float(weighted_stats.std)
        median = float(series.median())
        q1 = float(series.quantile(0.25))
        q3 = float(series.quantile(0.75))
        return mean, std, median, q1, q3
    mean = float(series.mean())
    std = float(series.std())
    median = float(series.median())
    q1 = float(series.quantile(0.25))
    q3 = float(series.quantile(0.75))
    return mean, std, median, q1, q3


def summarize_followup(df: pd.DataFrame, sample: str, id_column: str) -> pd.DataFrame:
    followup = df[df["sample"] == sample][id_column].value_counts()
    return pd.DataFrame({"periods_observed": followup.index, "count": followup.values})
