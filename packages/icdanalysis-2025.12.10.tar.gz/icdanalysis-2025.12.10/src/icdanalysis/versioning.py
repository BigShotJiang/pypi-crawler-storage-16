"""Custom setuptools-scm schemes for date-only versioning."""

from __future__ import annotations

from datetime import date


def date_version_scheme(version) -> str:
    """Return build date as YYYY.MM.DD regardless of git tags."""
    return date.today().strftime("%Y.%m.%d")


def empty_local_scheme(version) -> str:
    """No local version segment; keep version clean (no +suffix)."""
    return ""
