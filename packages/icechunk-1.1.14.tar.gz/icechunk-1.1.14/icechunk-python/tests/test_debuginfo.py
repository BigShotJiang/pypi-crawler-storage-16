from icechunk import print_debug_info


def test_debug_info() -> None:
    # simple test that this does not cause an error.
    print_debug_info()
