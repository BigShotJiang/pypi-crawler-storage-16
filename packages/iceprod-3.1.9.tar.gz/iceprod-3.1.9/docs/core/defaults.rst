Defaults
======

.. automodule:: iceprod.core.defaults