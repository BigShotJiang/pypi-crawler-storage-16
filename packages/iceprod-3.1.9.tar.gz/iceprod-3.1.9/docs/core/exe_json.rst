.. index:: ExeJSON
.. _ExeJSON:

JSONRPC Calls
=============

.. automodule:: iceprod.core.exe_json
