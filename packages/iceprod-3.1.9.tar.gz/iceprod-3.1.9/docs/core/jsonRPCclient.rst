JSON-RPC Client
===============

.. automodule:: iceprod.core.jsonRPCclient
   :no-members:

.. autoclass:: Client
   :no-undoc-members:
   
.. autoclass:: JSONRPC
   :no-undoc-members:



