Login
=====

Users can log in to IceProd like any other web application.

Authentication is handled by IceCube SSO.
