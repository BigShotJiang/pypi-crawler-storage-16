Task Monitoring
===============

When looking at the task details, the first section is a selection of
task attributes.  If you're on this page because of an error, this
is probably less relevant.

The bottom of the page lists any logs from the task. `stdout` and `stderr`
should be from the actual task, while `stdlog` is from IceProd. The
last 40 lines are shown directly, and clicking on the file name will
show the entire log file.