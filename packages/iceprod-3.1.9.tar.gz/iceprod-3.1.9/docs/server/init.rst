.. index:: server_init
.. _server_init:


Server Init
===========

.. automodule:: iceprod.server