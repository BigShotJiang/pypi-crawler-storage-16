.. index:: master_updater_module
.. _master_updater_module:

Master Updater Module
=============

.. automodule:: iceprod.server.modules.master_updater
