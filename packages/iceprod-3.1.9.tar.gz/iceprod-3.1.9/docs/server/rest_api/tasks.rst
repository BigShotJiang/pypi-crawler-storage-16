REST API - Tasks
================

.. automodule:: iceprod.rest.handlers.tasks
