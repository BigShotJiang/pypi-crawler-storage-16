import unicodedata

from django.contrib.auth.models import Group

# from rest_framework.authtoken.models import Token
from mozilla_django_oidc.auth import OIDCAuthenticationBackend

from ..models.member import Member


def generate_username(email):

    return unicodedata.normalize("NFKC", email.split("@")[0][:150])


class MemberOIDCAuthenticationBackend(OIDCAuthenticationBackend):

    def create_user(self, claims):
        user = super().create_user(claims)

        # Create an associated Member
        member = Member(user_ptr_id=user.pk)
        member.__dict__.update(user.__dict__)

        # If there's a 'regular user' group assign them
        group = Group.objects.filter(name="regular_users").first()
        if group:
            member.groups.add(group)
        member.save()

        # Token.objects.create(user=user)

        return user
