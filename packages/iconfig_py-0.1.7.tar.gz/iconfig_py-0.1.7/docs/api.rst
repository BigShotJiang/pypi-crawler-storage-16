API Reference
=============

iConfig Module
--------------

.. automodule:: iconfig.iconfig
   :members:
   :undoc-members:
   :show-inheritance:

KeyIndex Module
---------------

.. automodule:: iconfig.keyindex
   :members:
   :undoc-members:
   :show-inheritance:

Labels Module
-------------

.. automodule:: iconfig.labels
   :members:
   :undoc-members:
   :show-inheritance:

Utils Module
------------

.. automodule:: iconfig.utils
   :members:
   :undoc-members:
   :show-inheritance: