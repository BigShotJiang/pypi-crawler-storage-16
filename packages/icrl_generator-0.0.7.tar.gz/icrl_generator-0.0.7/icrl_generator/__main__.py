from icrl_generator import APP

APP()
