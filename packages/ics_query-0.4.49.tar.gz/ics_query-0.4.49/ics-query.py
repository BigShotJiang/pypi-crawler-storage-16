"""ics-query script for pyinstaller."""

from ics_query import main

main()
