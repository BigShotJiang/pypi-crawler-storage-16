"""ICSC Echo MCP Server - 極簡MCP Server，提供echo功能"""

__version__ = "0.1.0"
