"""允許使用 python -m icsc_echo_mcp_server 執行"""

from icsc_echo_mcp_server.server import main

if __name__ == "__main__":
    main()
