"""Various supporting functions and classes."""
