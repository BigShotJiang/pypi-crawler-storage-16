idds-doma
====

idds-doma subpackage is for DOMA hep specific functions and plugins.
With it, iDDS can support DOMA LSST workflows.
