
var appConfig = {{
    'iddsAPI_request': "{hostname_url}/idds/monitor_request/null/null",
    'iddsAPI_transform': "{hostname_url}/idds/monitor_transform/null/null",
    'iddsAPI_processing': "{hostname_url}/idds/monitor_processing/null/null",
    'iddsAPI_request_detail': "{hostname_url}/idds/monitor/null/null/true/false/false",
    'iddsAPI_transform_detail': "{hostname_url}/idds/monitor/null/null/false/true/false",
    'iddsAPI_processing_detail': "{hostname_url}/idds/monitor/null/null/false/false/true"
}}
