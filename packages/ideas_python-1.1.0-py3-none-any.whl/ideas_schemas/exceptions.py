from typing import Any


class SchemaValidationError(Exception):
    """
    Raised if the schema does not validate.
    """

    schema: Any
    message: str

    def __init__(self, *args, schema: Any, message: str):
        self.schema = schema
        self.message = message
        super().__init__(*args)
