from .core import read_passport

__all__ = ['read_passport']
