from dataclasses import dataclass

from dots.operation.operation import Operation
from dots.operation.target import Target


@dataclass
class CopyFile(Operation):
    source_path: str
    destination_path: str

    async def apply(self, target: Target):
        await target.copy_file(
            source=self.source_path,
            destination=self.destination_path,
        )
