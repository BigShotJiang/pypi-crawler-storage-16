from dots.operation.operation import Operation
from dots.operation.target import Target
from dots.operation.noop import noop

from dots.util.run_sync import run_sync


class _Op(Operation):
    def __init__(self, awaitable):
        self._awaitable = awaitable

    async def apply(self, target: Target):
        op = (await self._awaitable) or noop()
        return await op.apply(target)


def defer(awaitable) -> Operation:
    return _Op(awaitable)
