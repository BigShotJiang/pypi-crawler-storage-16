from dataclasses import dataclass

import aiofiles

from dots.operation.operation import Operation
from dots.operation.target import Target
from dots.util.run_command import run_command


@dataclass
class WriteCommandOutput(Operation):
    command: [str]
    path: str

    async def apply(self, target: Target):
        stdout, _, _ = await run_command(self.command)

        async with aiofiles.tempfile.NamedTemporaryFile("w") as file:
            await file.write(stdout)
            await file.flush()
            await file.seek(0)

            await target.copy_file(
                source=file.name,
                destination=self.path,
            )
