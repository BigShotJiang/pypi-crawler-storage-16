import os
from dataclasses import dataclass

from loguru import logger

from dots.operation.operation import Operation
from dots.operation.target import Target
from dots.util.run_command import run_command


def _check_code(code, stderr, message):
    if code != 0:
        raise RuntimeError(f"{message}: {stderr}")


@dataclass
class CloneRepository(Operation):
    url: str
    destination: str

    async def apply(self, target: Target):
        if os.path.exists(self.destination):
            if not os.path.isdir(self.destination):
                raise ValueError(f"{self.destination} exists and is not a directory")

            logger.info(f"checking remote URL of repository in {self.destination}...")
            stdout, stderr, code = await run_command(
                [
                    "git",
                    "config",
                    "--get",
                    "remote.origin.url",
                ],
                cwd=self.destination,
            )
            _check_code(code, stderr, "git config failed")

            actual_url = stdout.strip()
            if actual_url != self.url:
                raise ValueError(f"actual url: {actual_url}, expected: {self.url}")

            logger.info(f"checking if pull is needed in {self.destination}...")
            stdout, stderr, code = await run_command(
                ["git", "status", "-uno"],
                cwd=self.destination,
            )
            _check_code(code, stderr, "git status failed")

            if "Your branch is behind" not in stdout:
                logger.info(f"{self.destination} is up to date")
            else:
                logger.info(f"pulling {self.url} in {self.destination}...")
                _, stderr, code = await run_command(
                    ["git", "pull"],
                    cwd=self.destination,
                )
                _check_code(code, stderr, "git pull failed")

        else:
            _, stderr, code = await run_command(
                [
                    "git",
                    "clone",
                    self.url,
                    self.destination,
                ],
            )

            if code != 0:
                raise RuntimeError(f"git clone failed: {stderr}")
