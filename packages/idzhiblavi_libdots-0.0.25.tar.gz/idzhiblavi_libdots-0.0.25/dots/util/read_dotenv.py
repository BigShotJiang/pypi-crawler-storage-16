from dotenv import dotenv_values

def read_dotenv_file(path: str):
    return dotenv_values(path)
