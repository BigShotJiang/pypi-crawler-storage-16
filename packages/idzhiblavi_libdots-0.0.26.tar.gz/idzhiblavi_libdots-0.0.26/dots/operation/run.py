from dataclasses import dataclass

import asyncio

from dots.operation.operation import Operation
from dots.operation.target import Target
from dots.operation.noop import noop


class _Run(Operation):
    def __init__(self, func, *args):
        self.func = func
        self.args = args

    async def apply(self, target: Target):
        if asyncio.iscoroutinefunction(self.func):
            op = (await self.func(*self.args)) or noop()
            return await op.apply(target)

        if callable(self.func):
            op = self.func(*self.args) or noop()
            return await op.apply(target)

        raise ValueError(f"run used with non-function value of type {type(self.func)}")


def run(func, *args) -> Operation:
    return _Run(func, *args)
