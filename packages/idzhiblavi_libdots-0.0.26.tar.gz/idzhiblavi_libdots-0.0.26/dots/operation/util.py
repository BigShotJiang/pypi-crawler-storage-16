import os
import difflib

from loguru import logger

from dots.util.read_file import read_file


async def print_files_diff(a, b):
    c_a = await read_file(a)
    c_b = await read_file(b)
    return print_lines_diff(c_a.splitlines(), c_b.splitlines(), a, b)


def print_lines_diff(a, b, path_a, path_b):
    diff = list(difflib.unified_diff(a[:1000], b[:1000], path_a, path_b))
    if not diff:
        return

    logger.info(f"files {path_a} and {path_b} differ (result may be not full):")
    print("\n".join(diff)[:10000])


def check_can_put_file(path: str):
    if os.path.isdir(path):
        raise RuntimeError(f"cannot put file at path {path}: is a directory")


def check_can_put_directory(path: str):
    if os.path.isfile(path):
        raise RuntimeError(f"cannot put directory at path {path}: is a file")


def softlink_exists(source, destination):
    if not os.path.islink(destination):
        return False

    return os.path.realpath(os.readlink(destination)) == os.path.realpath(source)


def make_shell_patterns_matcher(patterns):
    def matcher(name):
        return any(map(lambda pattern: fnmatch.fnmatch(name, pattern), patterns))

    return matcher


def create_parent_dir_if_not_exists(self, target_path):
    directory = os.path.dirname(os.path.abspath(target_path))
    if os.path.exists(directory):
        return

    os.makedirs(directory, exist_ok=True)
    logger.info(f"created a parent directory: {directory}")
