from dataclasses import dataclass, field

import aiofiles

from dots.operation.clone_repository import CloneRepository
from dots.util.run_command import run_command


@dataclass
class Repository:
    url: str

    def clone_to(self, destination: str):
        return CloneRepository(
            url=self.url,
            destination=destination,
        )
