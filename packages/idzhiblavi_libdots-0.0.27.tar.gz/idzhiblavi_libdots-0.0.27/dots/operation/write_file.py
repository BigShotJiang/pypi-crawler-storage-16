from dataclasses import dataclass

import asyncio
import aiofiles

from dots.operation.operation import Operation
from dots.operation.target import Target


@dataclass
class WriteFile(Operation):
    content: str  # or callable, coroutine, coroutine callable
    path: str

    async def apply(self, target: Target):
        if asyncio.iscoroutinefunction(self.content):
            content = await self.content()
        elif asyncio.iscoroutine(self.content):
            content = await self.content
        elif callable(self.content):
            content = self.content()
        elif isinstance(self.content, str):
            content = self.content
        else:
            raise RuntimeError(f"unsupported content type: {type(self.content)}")

        async with aiofiles.tempfile.NamedTemporaryFile("w") as file:
            await file.write(content)
            await file.flush()
            await file.seek(0)

            await target.copy_file(
                source=file.name,
                destination=self.path,
            )
