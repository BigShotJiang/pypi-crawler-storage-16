import subprocess

from dataclasses import dataclass, field

from dots.operation.write_file import WriteFile
from dots.util.run_command import run_command


@dataclass
class Command:
    command: [str]

    def write_to(self, path: str):
        return WriteFile(
            content=self._run_command(),
            path=path,
        )

    async def _run_command(self):
        stdout, stderr, code = await run_command(self.command)

        if code != 0:
            raise RuntimeError(f"command failed: code={code}: {stderr}")

        return stdout
