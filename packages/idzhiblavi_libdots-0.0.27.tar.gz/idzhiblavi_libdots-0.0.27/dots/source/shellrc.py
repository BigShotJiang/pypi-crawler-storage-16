from loguru import logger

import asyncio

from dots.operation.write_file import WriteFile


class Shellrc:
    def __init__(self):
        self._env = {}
        self._aliases = {}
        self._path = []
        self._pre = []
        self._mid = []
        self._post = []

    def write_to(self, path: str):
        return WriteFile(
            content=self._render,
            path=path,
        )

    def add_path(self, path: str):
        if path not in self._path:
            self._path.append(path)
        return self

    def add_env(self, key: str, value: str):
        if key in self._env and value != self._env[key]:
            logger.warning(
                f'overriding environment variable {key}="{self._env[key]}" with {value}',
            )

        self._env[key] = value
        return self

    def add_alias(self, key: str, value: str):
        if key in self._aliases and value != self._aliases[key]:
            logger.warning(
                f'overriding alias variable {key}="{self._aliases[key]}" with {value}',
            )

        self._aliases[key] = value
        return self

    def add_pre(self, code: str):
        self._pre.append(code)
        return self

    def add_mid(self, code: str):
        self._mid.append(code)
        return self

    def add_post(self, code: str):
        self._post.append(code)
        return self

    async def _evaluate(self, value):
        if isinstance(value, str):
            return value
        if asyncio.iscoroutine(value):
            return await value
        if asyncio.iscoroutinefunction(value):
            return await value()
        if callable(value):
            return value()

        raise ValueError(f"cannot evalue value of type {type(value)}")

    async def _render(self) -> str:
        lines = []

        lines.extend([await self._evaluate(v) for v in self._pre])
        self._render_environ(lines)
        self._render_path(lines)
        lines.extend([await self._evaluate(v) for v in self._mid])
        self._render_aliases(lines)
        lines.extend([await self._evaluate(v) for v in self._post])

        return "\n".join(lines)

    def _render_path(self, out: [str]):
        if not self._path:
            return
        path_env = ""
        for path in self._path:
            path_env += ":" + path
        out.append(f"export PATH={path_env}:${{PATH}}")

    def _render_environ(self, out: [str]):
        self._render_dict(self._env, "export", out)

    def _render_aliases(self, out: [str]):
        self._render_dict(self._aliases, "alias", out)

    def _render_dict(self, kv, prefix: str, out: [str]):
        for key, value in kv.items():
            out.append(f'{prefix} {key}="{str(value)}"')
