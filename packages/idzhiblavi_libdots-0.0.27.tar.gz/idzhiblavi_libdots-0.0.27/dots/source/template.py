from typing import Dict
from dataclasses import dataclass

import jinja2

from dots.operation.write_file import WriteFile
from dots.util.read_file import read_file


@dataclass
class Template:
    path: str
    data: Dict[str, str]

    def render_to(self, destination: str):
        return WriteFile(
            content=self._render(),
            path=destination,
        )

    async def _render(self):
        template = jinja2.Template(await read_file(self.path))
        return template.render(**self.data)
