import asyncio


async def run_command(command: [str], **kwargs):
    params = {
        "stdout": asyncio.subprocess.PIPE,
        "stderr": asyncio.subprocess.PIPE,
    }
    params.update(**kwargs)

    process = await asyncio.create_subprocess_exec(*command, **params)
    stdout, stderr = await process.communicate()

    return stdout.decode(), stderr.decode(), process.returncode
