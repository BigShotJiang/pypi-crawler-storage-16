"""WebTestPilot - AI-powered GUI E2E testing agent"""

__version__ = "0.0.1"
