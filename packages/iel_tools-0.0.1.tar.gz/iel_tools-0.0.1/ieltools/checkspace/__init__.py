
import sqlite3
import pandas as pd
import io
import os
from google.colab import files

def check():
  import pandas as pd
  #query = "SELECT Cuenta FROM balance_bbva WHERE Cuenta LIKE '%Resultado Neto del Ejercicio%' LIMIT 1"
  bd = input("¿Cuál es la base de datos? (*.db): ")
  conn = sqlite3.connect(bd)
  variable = input("Cuál es la variable (campo, columna)?: ")
  tabla = input("¿Cuál es la tabla?: ")
  valor =  input("¿Cuál es el valor aproximado?: ")
  query = f"SELECT {variable} FROM {tabla} WHERE Cuenta LIKE '%{valor}%' LIMIT 1"
  df_test = pd.read_sql_query(query, conn)
  if not df_test.empty:
    texto_real = df_test.iloc[0, 0]   
    print(f"Texto analizado: '{texto_real}'")
    print("-" * 60)
    print(f"Posición | Carácter | Código ASCII | ¿Es Espacio?")
    print("-" * 60)
    contador_espacios = 0  
    for i, letra in enumerate(texto_real):
        codigo_ascii = ord(letra)      
        es_espacio = ""
        if letra == ' ':
            es_espacio = "🔴 SI"
            contador_espacios += 1          
        print(f"   {i:02d}    |    '{letra}'   |      {codigo_ascii}     | {es_espacio}")
    print("-" * 60)
    print(f"📊 CONTEO FINAL: El texto tiene {len(texto_real)} caracteres.")
    print(f"🗑️ ESPACIOS DETECTADOS: Hay {contador_espacios} espacios en blanco.")
    
  else:
    print("No se encontró la fila para analizar.")
