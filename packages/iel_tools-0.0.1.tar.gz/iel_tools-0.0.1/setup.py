from setuptools import setup, find_packages

setup(
    name="iel-tools",            # Nombre para instalar: pip install iel-tools
    version="0.0.1",             # Primera versión
    author="Tu Nombre",
    description="Librería unificada con herramientas PromptSQL y CheckSpace",
    
    # ¡La magia! Esto busca carpetas con __init__.py automáticamente
    packages=find_packages(),    
    
    # Aquí pones las librerías que tu código necesita para funcionar
    install_requires=[           
        "pandas",
        "numpy",
        "openai",                # Si promptsql usa IA
        "requests"
    ],
)
