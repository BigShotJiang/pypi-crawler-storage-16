
import sqlite3
import pandas as pd
import io
import os
from google.colab import files

def inicio():
    conn = None
    nombre_db_actual = None

    print("👋 ¡Bienvenido al Sistema SQL Dinámico v2.0!")

    while True:

        estado = f"🟢 Conectado a '{nombre_db_actual}'" if conn else "🔴 Desconectado"

        print("\n" + "="*50)
        print(f"      🛠️  MENÚ PRINCIPAL ({estado})  🛠️")
        print("="*50)
        print("1. 📂 Importar Excel (Define o cambia Base de Datos)")
        print("2. 🔍 Consultar datos (SQL: Select)")
        print("3. ✏️  Modificar datos (SQL: Insert, Update, Delete)")
        print("4. 🚪 Salir")
        print("-" * 50)

        opcion = input(">> Elige una opción (1-4): ")

        # --- OPCIÓN 1: IMPORTAR EXCEL ---
        if opcion == '1':
            try:
                print("\n📄 Paso 1: Sube tu archivo Excel (.xlsx):")
                uploaded = files.upload()

                if not uploaded:
                    print("⚠️ No se seleccionó archivo.")
                    continue

                nombre_archivo_excel = list(uploaded.keys())[0]

                # Configurar BD
                cambiar_db = True
                if conn is not None:
                    print(f"\n⚠️  Conectado a '{nombre_db_actual}'.")
                    resp = input(">> ¿Quieres cambiar de base de datos? (s/n): ").lower()
                    if resp != 's':
                        cambiar_db = False

                if cambiar_db:
                    if conn: conn.close()
                    nuevo_nombre = input("\n🗄️  Paso 2: Nombre para la Base de Datos (ej: empresa.db): ")
                    if not nuevo_nombre.endswith('.db'): nuevo_nombre += '.db'
                    conn = sqlite3.connect(nuevo_nombre)
                    nombre_db_actual = nuevo_nombre
                    print(f"✅ Conectado a '{nombre_db_actual}'.")

                # Cargar Excel
                print(f"   Leyendo '{nombre_archivo_excel}'...")
                df = pd.read_excel(io.BytesIO(uploaded[nombre_archivo_excel]))
                df.columns = df.columns.str.lower().str.replace('[^a-z0-9_]+', '_', regex=True)

                nombre_tabla = input(">> Nombre para la TABLA en SQL: ")
                df.to_sql(nombre_tabla, conn, if_exists='replace', index=False)
                print(f"✅ Tabla '{nombre_tabla}' importada correctamente.")

            except Exception as e:
                print(f"❌ Error: {e}")

        # --- OPCIÓN 2 y 3: CONSULTAR Y MODIFICAR ---
        elif opcion in ['2', '3']:
            # Verificar conexión
            if conn is None:
                print("\n⚠️  No hay conexión activa.")
                db_input = input(">> Nombre de la base de datos a conectar (ej: empresa.db): ")
                try:
                    conn = sqlite3.connect(db_input)
                    nombre_db_actual = db_input
                    print(f"✅ Conectado a '{nombre_db_actual}'.")
                except Exception as e:
                    print(f"❌ Error al conectar: {e}")
                    continue

            # Lógica diferenciada por opción
            try:
                # --- OPCIÓN 2: CONSULTAR (SELECT) ---
                if opcion == '2':
                    print("\n🔍 Modo Consulta. Escribe tu SELECT:")
                    comando_sql = input("SQL >> ")
                    if comando_sql.strip().lower().startswith("select"):
                        resultado = pd.read_sql_query(comando_sql, conn)
                        print("\n--- RESULTADO ---")
                        print(resultado if not resultado.empty else "⚠️ Consulta vacía.")
                    else:
                        print("⚠️ En la opción 2 solo se permiten consultas SELECT.")

                # --- OPCIÓN 3: MODIFICAR (INSERT/UPDATE/DELETE) ---
                else:
                    print("\n✏️  Modo Edición. Escribe tu INSERT/UPDATE/DELETE:")
                    comando_sql = input("SQL >> ")
                    cursor = conn.cursor()
                    cursor.execute(comando_sql)
                    conn.commit()
                    print(f"✅ Comando ejecutado. Filas afectadas: {cursor.rowcount}")

            except Exception as e:
                print(f"❌ Error SQL: {e}")

        # --- OPCIÓN 4: SALIR ---
        elif opcion == '4':
            if conn: conn.close()
            print("👋 ¡Hasta luego!")
            break

        else:
            print("⚠️ Opción no válida.")
