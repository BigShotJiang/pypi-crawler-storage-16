
import sqlite3
import pandas as pd
import os

def check():
    print("👋 ¡Bienvenido al Chequeo de Espacios de Iel Tools!")
    print("👋 Se asume que ya hay una tabla conectada")
    print("👋 Para cancelar, escriba 'salir'")
    
    while True:
        print("\n" + "="*50)
        print("🔍 NUEVA CONSULTA (Escribe 'salir' en cualquier momento para terminar)")
        
        variable = input("1. ¿Cuál es la variable (columna)? : ")
        if variable.lower().strip() == 'salir': break
        
        tabla = input("2. ¿Cuál es la tabla?             : ")
        if tabla.lower().strip() == 'salir': break
        
        valor = input("3. ¿Valor aproximado a buscar?    : ")
        if valor.lower().strip() == 'salir': break

        # Usamos try/except para capturar errores sin cerrar el programa
        try:
            # Nota: 'conn' debe estar definida globalmente antes de llamar a esta función
            query = f"SELECT {variable} FROM {tabla} WHERE {variable} LIKE '%{valor}%' LIMIT 1"
            df_test = pd.read_sql_query(query, conn)
            
            if not df_test.empty:
                texto_real = str(df_test.iloc[0, 0]) 
                print("-" * 60)
                print(f"🎯 TEXTO ENCONTRADO: '{texto_real}'")
                print("-" * 60)
                print(f"Pos | Char | ASCII | ¿Es Espacio?")
                print("-" * 60)
                
                contador_espacios = 0  
                for i, letra in enumerate(texto_real):
                    codigo_ascii = ord(letra)      
                    es_espacio = ""
                    if letra == ' ':
                        es_espacio = "🔴 SI"
                        contador_espacios += 1          
                    elif codigo_ascii == 160: 
                        es_espacio = "👻 ESPACIO FANTASMA (160)"
                        contador_espacios += 1

                    print(f" {i:02d} |  '{letra}' |  {codigo_ascii:03d}  | {es_espacio}")
                
                print("-" * 60)
                print(f"📊 LONGITUD TOTAL: {len(texto_real)} caracteres.")
                print(f"🗑️ ESPACIOS TOTALES: {contador_espacios}")
                
            else:
                print("⚠️ No se encontró ninguna fila que coincida con esa búsqueda.")
        
        except Exception as e:
            print(f"❌ Error: {e}")
            print("(Verifica que la conexión 'conn' exista y los datos sean correctos)")

    # Al hacer break, llega aquí.
    try:
        conn.close()
        print("\n👋 Conexión cerrada.")
    except:
        print("\n👋 Salida realizada (No se pudo cerrar la conexión automáticamente).")
