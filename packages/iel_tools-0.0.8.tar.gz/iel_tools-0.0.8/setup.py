from setuptools import setup, find_packages

setup(
    name="iel-tools",            
    version="0.0.8",             # <--- ¡IMPORTANTÍSIMO CAMBIAR ESTO SIEMPRE!
    author="José Manuel Martin Coronado",
    description="Librería unificada con herramientas PromptSQL y CheckSpace",
    packages=find_packages(),
    author_email="jm@martincoronado.com.pe",
    install_requires=[
        "pandas", "numpy", "openai", "requests"
    ],
)
