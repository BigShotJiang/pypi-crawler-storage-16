# ighap-bot

Unofficial Python client for iGap Bot API.

## Installation
```bash
pip install ighap-bot

Usage

from ighap_bot.bot import BotClient

bot = BotClient(token="YOUR_TOKEN")

@bot.on_message()
async def handle_message(message):
    await bot.send_message(message.room_id, "Hello from iGap bot!")

bot.run()


Features
• 	Async client using 
• 	Message handling with filters
• 	File upload support
• 	Extensible architecture
License
MIT