"""Package information."""

__version__ = "8.3.1"
__build__ = "2025102109"
