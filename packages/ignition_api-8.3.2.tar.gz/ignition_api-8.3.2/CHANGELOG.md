## 8.3.2 (2025-12-10)

### Refactor

- decouple java[x] into standalone package (#26)
- **java**: add exception classes to java.nio.file (#23)

## 8.3.1.post2 (2025-12-08)

### Refactor

- decouple java[x] into standalone package (#26)
- **java**: add exception classes to java.nio.file (#23)

## 8.3.1.post1 (2025-11-27)

### Refactor

- **java**: add exception classes to java.nio.file (#23)

## 8.3.1 (2025-10-22)

### Feat

- **system**: add dnp and bring back security (#15)

### Refactor

- **ia**: add PyDataset and make Dataset iterable (#18)

## 8.3.0.post2 (2025-10-10)

### Feat

- **system**: add dnp and bring back security (#15)

### Refactor

- **ia**: add PyDataset and make Dataset iterable (#18)

## 8.3.0.post1 (2025-10-01)

### Feat

- **system**: add dnp and bring back security (#15)

## 8.3.0 (2025-09-16)

## 8.3.0rc1 (2025-08-29)

### Feat

- **system**: add call and whatsapp functions to twilio (#9)

## 8.3.0b3 (2025-08-19)

### Fix

- **system**: remove deprecated and add back db functions (#7)

## 8.3.0b2 (2025-08-18)

### Feat

- **ia**: add missing system functions (#5)

## 8.3.0b1 (2025-08-07)

## 8.3.0b0 (2025-07-30)

### Feat

- initial release
