#prova331
# esempio che restituisce una stringa

def prova331():
    #print("ciao")
    return("ciao da prova331")

def main():
    x = prova331()
    print(x)

if __name__== "__main__":
  main()