from oggi_ita import *

def stampa_under(stringa):  
    return (f"💡💡  {stringa} - {oggi_ita()}\n")

def main():
    stampa_under("function stampa_under")

if __name__== "__main__":    
   main()
