# IIKO Cloud SDK API

## Описание

Утилитарный пакет, содержащий в себе интеграционный модуль с [IIKO Cloud SDK](https://api-ru.iiko.services/docs)