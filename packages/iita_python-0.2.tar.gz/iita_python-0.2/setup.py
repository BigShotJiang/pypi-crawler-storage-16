from setuptools import setup, find_packages

with open('README.md', 'r') as f:
    long_description = f.read()

setup(
    name='iita_python',
    version='0.2',
    author='Aliaksei Badnarchuk',
    packages=find_packages(),
    install_requires=[
        'numpy',
        'pandas',
    ],
    long_description=long_description,
    long_description_content_type='text/markdown',
)