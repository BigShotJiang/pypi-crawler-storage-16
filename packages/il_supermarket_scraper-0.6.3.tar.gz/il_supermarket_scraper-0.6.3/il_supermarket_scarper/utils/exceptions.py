class RestartSessionError(Exception):
    """This error will be raised if we would like to retry to downalod after a session restart"""
