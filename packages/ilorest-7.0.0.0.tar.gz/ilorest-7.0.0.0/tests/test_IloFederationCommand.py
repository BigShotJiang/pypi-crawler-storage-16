def test_getprivs():
    assert False


def test__federation_parse():
    assert False
