"""
Model inference optimization utilities
"""

__all__ = []