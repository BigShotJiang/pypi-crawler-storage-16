# IlyasMessageProtocol

Небольшая библиотека для протокола сообщений.
