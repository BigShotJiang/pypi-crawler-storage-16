from .web import WebInstrument
from .file import FileInstrument
