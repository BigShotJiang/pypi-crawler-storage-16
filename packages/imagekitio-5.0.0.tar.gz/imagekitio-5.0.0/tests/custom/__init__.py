# Custom tests for manually created helper functions
# These tests are separate from auto-generated API tests
