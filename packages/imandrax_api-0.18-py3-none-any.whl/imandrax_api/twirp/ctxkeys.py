SERVICE_NAME = 'service_name'
METHOD_NAME = 'method_name'

RAW_HEADERS = 'raw_headers'
RAW_REQUEST_PATH = 'raw_request_path'

RESPONSE_STATUS = 'response_status'

ORIGINAL_EXCEPTION = 'original_exception'
