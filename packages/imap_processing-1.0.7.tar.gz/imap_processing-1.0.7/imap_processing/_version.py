# These version placeholders will be replaced later during substitution.
__version__ = "1.0.7"
__version_tuple__ = (1, 0, 7)
