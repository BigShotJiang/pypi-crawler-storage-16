dbperf
======

*dbperf* evaluates performance of MDSPLUS and HDF5 Backends with IDS get operation


Syntax dbperf
~~~~~~~~~~~~~~~

    .. command-output:: dbperf -h


Example dbperf
~~~~~~~~~~~~~~

    .. code-block:: bash

        $ dbperf -u $USER -d ITER
