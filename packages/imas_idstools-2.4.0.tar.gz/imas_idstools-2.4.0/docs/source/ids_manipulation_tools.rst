########################
 IDS Manipulation Tools
########################

IDS Manipulation tools allow you to manipulate data within IDSes by
copying, moving, or comparing differences etc.

.. toctree::
   :maxdepth: 1

   eqdsk2ids
   idscp
   idsdiff
   idslist
   idsperf
   idsprint
   idsquery
   idsresample
   idsrosettacode
   idsrescale_equilibrium
   idsshift_equilibrium
   idssize
