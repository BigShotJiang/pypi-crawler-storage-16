################
 idsrosettacode
################

*idsrosettacode* retrieves the size of IDS objects from a database entry
and shows IDS size in bytes and the time taken to read each object. It
also shows total size of all IDS objects in the data entry. It shows
total time taken to read all objects from the data entry. It is helpful
for performance check of ids objects.

***********************
 Syntax idsrosettacode
***********************

    .. command-output:: idsrosettacode -h
        
************************
 Example idsrosettacode
************************

   .. code:: bash

      $ idsrosettacode
