################
 watch_db_entry
################

Subscribe/unsubscribe as a watcher to a simulation file stored in IMAS DB

**********************
 Syntax watch_db_entry
**********************

   .. command-output:: watch_db_entry -h


