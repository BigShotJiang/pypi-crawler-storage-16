..
    Taken from xarray

{% extends "!autosummary/base.rst" %}
