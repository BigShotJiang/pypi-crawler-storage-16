API reference
=============

This page provides an auto-generated summary of IMAS-MUSCLE3's API. For more details
and examples, refer to the relevant chapters in the main part of the
documentation.

IMAS-MUSCLE3
------------

.. autosummary::
   :toctree: generated/
   :recursive:
   :template: custom-module-template.rst

   imas_muscle3
   
