.. _`IMAS-Python Examples`:

IMAS-Python Examples
====================

Most IMAS-Python usage examples can be found throughout the documentation pages. On this
page we collect some examples that are too big or too generic to include in specific
pages. Currently this is a short list, but we expect that it will grow over time.

.. toctree::
    :caption: IMAS-Python examples
    :maxdepth: 1

    examples/custom_conversion_em_coupling
