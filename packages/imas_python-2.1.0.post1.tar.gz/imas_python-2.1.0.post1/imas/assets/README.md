# IDS_minimal.xml
This is a minimal data dictionary which is still valid.

# IDS_minimal_types.xml
This is a minimal data dictionary with one entry of each primitive data type.
