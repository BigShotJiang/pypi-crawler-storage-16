# This file is part of IMAS-Python.
# You should have received the IMAS-Python LICENSE file with this project.
"""NetCDF IO support for IMAS-Python. Requires [netcdf] extra dependencies.
"""
