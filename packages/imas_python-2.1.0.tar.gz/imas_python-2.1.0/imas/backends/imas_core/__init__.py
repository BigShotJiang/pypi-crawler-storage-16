# This file is part of IMAS-Python.
# You should have received the IMAS-Python LICENSE file with this project.
"""Subpackage implementing data access through the IMAS Access Layer Core.
"""
