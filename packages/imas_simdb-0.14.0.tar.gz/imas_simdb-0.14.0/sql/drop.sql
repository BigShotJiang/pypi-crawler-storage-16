PRAGMA foreign_keys = OFF;

DROP TABLE IF EXISTS files;
DROP TABLE IF EXISTS simulations;
DROP TABLE IF EXISTS metadata;
DROP TABLE IF EXISTS simulation_files;