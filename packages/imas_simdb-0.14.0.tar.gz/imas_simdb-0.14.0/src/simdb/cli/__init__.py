# -*- coding: utf-8 -*-
"""CLI module.

The CLI module contains the code for the SimDB Command Line Interface including the commands run by the argparse
argument parser and the API for talking to the remote REST API.
"""
