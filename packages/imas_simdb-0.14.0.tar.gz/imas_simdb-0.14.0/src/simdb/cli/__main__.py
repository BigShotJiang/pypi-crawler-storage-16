from .simdb import main

main()
