class FileSystem:
    pass
