from collections import namedtuple


User = namedtuple("User", ("name", "email"))
