

def log(*args):
    print(*args)
