class FrameNotFoundError(IndexError):
    pass
