---
agent: speckit.implement
---
