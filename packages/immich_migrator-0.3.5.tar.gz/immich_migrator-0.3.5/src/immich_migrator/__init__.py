"""Immich Migration Tool - CLI tool for migrating albums between Immich servers."""

__version__ = "0.3.5"
