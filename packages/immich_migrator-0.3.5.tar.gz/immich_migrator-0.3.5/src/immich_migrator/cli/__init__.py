"""CLI application and TUI components."""
