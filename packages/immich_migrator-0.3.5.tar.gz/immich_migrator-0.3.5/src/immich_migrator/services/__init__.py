"""Services for Immich API client, downloading, uploading, and state management."""
