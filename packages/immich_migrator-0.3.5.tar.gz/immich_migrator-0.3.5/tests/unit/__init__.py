"""Test __init__ for unit tests."""
