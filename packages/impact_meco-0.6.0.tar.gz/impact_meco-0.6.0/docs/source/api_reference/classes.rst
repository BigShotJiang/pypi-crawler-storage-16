**********
Impact API
**********

.. todo::

   Add documentation for other classes of Impact

mpc
===

.. automodule:: impact.mpc
    :members:

dotdict
=======

.. automodule:: impact.dotdict
    :members:

model
=====

.. automodule:: impact.model
    :members:
    