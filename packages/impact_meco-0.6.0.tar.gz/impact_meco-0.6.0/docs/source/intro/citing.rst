************
Citing
************

Please cite Impact's publication if you use the library for your publications.

.. code-block:: tex

   @inproceedings{FlorezIFAC2023,
    booktitle = {Proceedings of the IFAC World Congress 2023},
    title = {IMPACT: A Toolchain for Nonlinear Model Predictive Control Specification, Prototyping, and Deployment},
    year = {2023},
    author = {Alvaro Florez and Alejandro Astudillo and Wilm Decre and Jan Swevers and Joris Gillis},
