Gallery of examples
===================
