[ ] Add tests for the change.
[ ] Add any appropriate documentation.
[ ] Run `just check`.
[ ] Add a summary of changes to `docs/release_notes.md`.
[ ] Add your name to `docs/authors.md` (in alphabetical order).

