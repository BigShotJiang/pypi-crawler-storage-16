# Authors

* [David Seddon](https://seddonym.me)

## Contributors

* [Aaron Gokaslan](https://github.com/Skylion007)
* [Alexandre Beaufays](https://github.com/abeaufays)
* [Anthony Sottile](https://github.com/asottile)
* [Anton Gruebel](https://github.com/gruebel)
* [Ben Warren](https://github.com/bwarren)
* [Daniel Jurczak](https://github.com/danieljurczak)
* [Daniele Esposti](https://github.com/expobrain)
* [Fabian Binz](https://github.com/fbinz)
* [Felix Uhl](https://github.com/iFreilicht)
* [Ilya S. (Tapeline)](https://github.com/Tapeline)
* [James Owen](https://github.com/leamingrad)
* [Jan Bielecki](https://github.com/K4liber)
* [Kai Mueller](https://github.com/kasium)
* [Łukasz Skarżyński](https://github.com/skarzi)
* [Matthew Gamble](https://github.com/mwgamble)
* [Neil Williams](https://github.com/spladug)
* [Nicholas Bunn](https://github.com/NicholasBunn)
* [Nick Pope](https://github.com/ngnpope)
* [Peter Byfield](https://github.com/Peter554)
* [Petter Friberg](https://github.com/flaeppe)
* [piglei](https://github.com/piglei)
* [Uberto Barbini](https://github.com/uberto)

