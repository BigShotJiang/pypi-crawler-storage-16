# Install

Install `import-linter` using your favorite Python package manager, e.g.:

```console
pip install import-linter
```
