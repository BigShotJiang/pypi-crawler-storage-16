from .five import SOME_VAR


def another_func(a): ...
