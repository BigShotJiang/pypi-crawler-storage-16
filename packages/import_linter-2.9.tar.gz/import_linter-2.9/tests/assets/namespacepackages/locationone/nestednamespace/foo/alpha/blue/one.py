import itertools
import urllib.request

import pytest

from . import two
