from typing import TYPE_CHECKING

from testpackage import utils
from testpackage.indirect import yellow

if TYPE_CHECKING:
    from testpackage.high.blue import two
