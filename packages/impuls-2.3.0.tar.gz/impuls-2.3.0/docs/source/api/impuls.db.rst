﻿impuls.db
=========

.. automodule:: impuls.db
    :exclude-members: DBConnection

    .. class:: DBConnection

        See :py:class:`impuls.DBConnection`.
