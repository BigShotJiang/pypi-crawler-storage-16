﻿impuls.errors
=============

.. automodule:: impuls.errors
