﻿impuls.model
============

.. automodule:: impuls.model
    :exclude-members: Entity, sql_table_name, sql_create_table, sql_columns, sql_placeholder, sql_where_clause, sql_set_clause, sql_marshall, sql_primary_key, sql_unmarshall

    .. autoclass:: impuls.model.Entity
        :members: sql_table_name, sql_create_table, sql_columns, sql_placeholder, sql_where_clause, sql_set_clause, sql_marshall, sql_primary_key, sql_unmarshall
