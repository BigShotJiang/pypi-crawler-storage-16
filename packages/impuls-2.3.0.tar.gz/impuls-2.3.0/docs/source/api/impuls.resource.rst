﻿impuls.resource
===============

.. automodule:: impuls.resource
    :exclude-members: Resource, LocalResource, HTTPResource, cache_resources, ensure_resources_cached, prepare_resources

    .. class:: Resource

        See :py:class:`impuls.Resource`.

    .. class:: LocalResource

        See :py:class:`impuls.LocalResource`.

    .. class:: HTTPResource

        See :py:class:`impuls.HTTPResource`.
