﻿impuls.tasks.merge
==================

.. module:: impuls.tasks.merge

    .. autoclass:: DatabaseToMerge

    .. autoclass:: Merge

    .. autoclass:: ConflictResolution
