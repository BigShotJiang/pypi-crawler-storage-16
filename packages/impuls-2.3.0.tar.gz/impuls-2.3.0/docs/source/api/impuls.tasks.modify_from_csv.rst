﻿impuls.tasks.modify\_from\_csv
==============================

.. automodule:: impuls.tasks.modify_from_csv
    :exclude-members: ModifyStopsFromCSV, ModifyRoutesFromCSV

    .. class:: ModifyStopsFromCSV

        See :py:class:`impuls.tasks.ModifyStopsFromCSV`.

    .. class:: ModifyRoutesFromCSV

        See :py:class:`impuls.tasks.ModifyRoutesFromCSV`.
