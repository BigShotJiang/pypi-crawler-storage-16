﻿impuls.tools.iteration
======================

.. automodule:: impuls.tools.iteration
