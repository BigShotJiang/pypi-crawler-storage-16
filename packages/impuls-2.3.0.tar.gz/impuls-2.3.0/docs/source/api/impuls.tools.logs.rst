﻿impuls.tools.logs
=================

.. automodule:: impuls.tools.logs
    :exclude-members: initialize

    .. function:: initialize

        See :py:class:`impuls.initialize_logging`.
