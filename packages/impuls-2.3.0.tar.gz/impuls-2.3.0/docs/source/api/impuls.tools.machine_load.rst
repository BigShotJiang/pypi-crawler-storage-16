﻿impuls.tools.machine_load
=========================

.. automodule:: impuls.tools.machine_load
    :exclude-members: memory_usage_kb

    .. function:: memory_usage_kb() -> int

        Returns the memory usage of the current process in KiB.
        May be nopped out to return 0 on weird platforms.
