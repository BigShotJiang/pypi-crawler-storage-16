﻿impuls.tools.polish\_calendar\_exceptions
=========================================

.. module:: impuls.tools.polish_calendar_exceptions

    .. autodata:: RESOURCE

    .. autofunction:: load_exceptions

    .. autoclass:: CalendarException

    .. autoclass:: PolishRegion()

    .. autoclass:: CalendarExceptionType()
