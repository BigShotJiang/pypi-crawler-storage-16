﻿impuls.tools.testing_mocks
==========================

.. automodule:: impuls.tools.testing_mocks
    :exclude-members: MockResource

    .. autoclass:: MockResource(content: bytes, fetchtime: datetime = datetime.datetime(1, 1, 1, 0, 0, tzinfo=datetime.timezone.utc), last_modified: datetime = datetime.datetime(1, 1, 1, 0, 0, tzinfo=datetime.timezone.utc), clock: DatetimeNowLike = datetime.now, persist_last_modified: bool = False)
