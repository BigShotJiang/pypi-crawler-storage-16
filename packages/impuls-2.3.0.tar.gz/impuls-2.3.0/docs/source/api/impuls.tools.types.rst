﻿impuls.tools.types
==================

.. automodule:: impuls.tools.types
