.. include:: ../README.rst

.. toctree::
   :hidden:
   :maxdepth: 2
   :caption: Contents:

   contributing
   authors
   changelog

