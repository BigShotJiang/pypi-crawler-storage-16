from . import default_files

if __name__ == "__main__":
    print("The impyre strikes back!")

    default_files.writeFiles("./impyre", True)
