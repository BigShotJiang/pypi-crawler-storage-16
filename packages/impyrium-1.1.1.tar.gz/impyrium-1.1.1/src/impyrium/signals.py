# These can be numbers to save memory, but for debug clarity strings are better
DEVICE_LIST_UPDATE = "DEVICE_LIST_UPDATE"
