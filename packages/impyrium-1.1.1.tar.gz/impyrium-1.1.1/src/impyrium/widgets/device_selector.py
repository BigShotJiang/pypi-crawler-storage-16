# TODO: A multi select widget for devices
# This will allow popup windows to select which devices
# to use in a simple fashion
