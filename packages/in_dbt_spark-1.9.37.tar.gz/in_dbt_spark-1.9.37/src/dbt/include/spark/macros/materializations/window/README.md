# Window materialization (experimental)

The `window` materialization produces bounded, self-healing outputs by filtering source rows to a window of event time and overwriting only the affected partitions. It mirrors the incremental materialization’s hooks, grants, retention, and table properties, and always uses dynamic INSERT OVERWRITE (any `incremental_strategy` setting is ignored).

## Configuration

Example model config:

```jinja
{{
  config(
    materialized = 'window',
    file_format = 'openhouse',
    partition_by = [{'field': 'country', 'data_type': 'string'}],
    retention_period = '14d',
    window_configs = {
      'size': 7,
      'frequency': 'daily',
      'delay': 0,
      'partition_column': 'datepartition',
      'partition_pattern': '%Y-%m-%d-00',
      'event_time_column': 'timestamp',
      'timezone': 'US/Pacific'
    }
  )
}}
```

Defaults:

- size: 1
- frequency: daily (hourly, daily, weekly, monthly supported)
- delay: 0
- partition_column: datepartition
- partition_pattern: '%Y-%m-%d-00'
- event_time_column: timestamp (epoch millis)
- timezone: US/Pacific

## Behavior

- Computes `start_date` and `end_date` using `in_dbt_utils.start_date`/`end_date`.
- Converts Python `strftime` pattern to Spark `date_format` pattern.
- Interprets `event_time_column` as epoch millis, converts to timestamp in the configured timezone, and filters rows to an inclusive window `[start_date, end_date]`.
- Adds a derived partition value via `date_format(event_ts, spark_pattern)` as `partition_column`. The model must NOT output this column; other `partition_by` columns are allowed in the model.
- Creates table (if missing) partitioned by `[partition_column] + partition_by` (deduped), then INSERT OVERWRITEs from the filtered temp view. Dynamic overwrite ensures only impacted partitions are replaced.

## Supported frequencies

- hourly, daily, weekly, monthly (aligned end_date; inclusive start spanning `size`).

## Notes

- `incremental_strategy` is ignored for `materialized='window'`.
- Delta Lake is not supported for INSERT OVERWRITE.
- Retention is applied similarly to incremental via `retention_period` and `partition_by` rules.


