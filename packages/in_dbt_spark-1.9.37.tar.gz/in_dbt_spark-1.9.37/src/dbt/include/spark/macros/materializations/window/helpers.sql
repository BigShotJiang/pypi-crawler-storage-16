{% macro window__python_to_spark_pattern(python_pattern) -%}
  {#-- Map common strftime tokens to Spark date_format tokens --#}
  {%- set mappings = {
    '%Y': 'yyyy', '%y': 'yy', '%m': 'MM', '%d': 'dd', '%H': 'HH', '%I': 'hh',
    '%M': 'mm', '%S': 'ss'
  } -%}
  {%- set out = python_pattern -%}
  {%- for k, v in mappings.items() -%}
    {%- set out = out.replace(k, v) -%}
  {%- endfor -%}
  {{ return(out) }}
{%- endmacro %}

{% macro window__parse_window_configs(raw_cfg) -%}
  {%- do log("[DBT_MACRO] WINDOW_PARSE_CONFIGS: Parsing window_configs: " ~ raw_cfg, info=true) -%}
  {%- if raw_cfg is none -%}
    {{ exceptions.raise_compiler_error("'window_configs' must be provided for materialized='window'.") }}
  {%- endif -%}

  {%- set defaults = {
    'size': 1,
    'frequency': 'daily',
    'delay': 0,
    'partition_column': 'datepartition',
    'partition_pattern': '%Y-%m-%d-00',
    'event_time_column': 'timestamp',
    'timezone': 'US/Pacific'
  } -%}

  {%- set cfg = defaults.copy() -%}
  {%- for k in raw_cfg.keys() -%}
    {%- set _ = cfg.update({k: raw_cfg[k]}) -%}
  {%- endfor -%}

  {#-- Coerce integers possibly provided as strings --#}
  {%- if cfg['size'] is string -%}
    {%- set _ = cfg.update({'size': cfg['size'] | int}) -%}
  {%- endif -%}
  {%- if cfg['delay'] is string -%}
    {%- set _ = cfg.update({'delay': cfg['delay'] | int}) -%}
  {%- endif -%}

  {%- if cfg['event_time_column'] is none -%}
    {{ exceptions.raise_compiler_error("'event_time_column' must be provided in window_configs.") }}
  {%- endif -%}

  {{ return(cfg) }}
{%- endmacro %}

{% macro window__bounds(cfg) -%}
  {%- set start_str = in_dbt_utils.start_date(cfg['frequency'], cfg['delay'], cfg['size'], cfg['partition_pattern'], cfg['timezone']) -%}
  {%- set end_str   = in_dbt_utils.end_date(cfg['frequency'], cfg['delay'], cfg['partition_pattern'], cfg['timezone']) -%}
  {{ return({'start': start_str, 'end': end_str}) }}
{%- endmacro %}

{% macro window__event_ts_expr(epoch_ms_column, tz) -%}
  from_utc_timestamp(from_unixtime({{ epoch_ms_column }} / 1000), '{{ tz }}')
{%- endmacro %}

{% macro window__merge_partition_by(required_partition_col) -%}
  {#-- Normalize partition_by to a list of field names, merge required_partition_col at front --#}
  {%- set raw_pb = config.get('partition_by', none) -%}
  {%- set cols = [] -%}
  {%- if raw_pb is not none -%}
    {%- set parsed = adapter.parse_partition_by(raw_pb) -%}
    {%- if parsed is not none -%}
      {%- for p in parsed -%}
        {%- set cols = cols + [p.field] -%}
      {%- endfor -%}
    {%- endif -%}
  {%- endif -%}
  {%- if required_partition_col not in cols -%}
    {%- set cols = [required_partition_col] + cols -%}
  {%- endif -%}
  {{ return(cols) }}
{%- endmacro %}

{% macro window__create_table_as(relation, select_sql, merged_partition_cols) -%}
  {%- do log("[DBT_MACRO] WINDOW_CREATE_TABLE_AS: Creating table: " ~ relation ~ ", partitions=" ~ merged_partition_cols, info=true) -%}
  {% if config.get('file_format', validator=validation.any[basestring]) in ['delta', 'iceberg'] %}
    create or replace table {{ relation }}
  {% else %}
    create table {{ relation }}
  {% endif %}
  {{ file_format_clause() }}
  {{ options_clause() }}
  {{ tblproperties_clause() }}
  {%- if merged_partition_cols and (merged_partition_cols | length) > 0 -%}
    partitioned by (
      {%- for c in merged_partition_cols -%}
      {{ c }}{% if not loop.last %}, {% endif %}
      {%- endfor -%}
    )
  {%- endif -%}
  {{ clustered_cols(label="clustered by") }}
  {{ location_clause() }}
  {{ comment_clause() }}
  as
  {{ select_sql }}
{%- endmacro %}


