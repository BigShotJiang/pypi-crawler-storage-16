{% materialization window, adapter='spark', supported_languages=['sql'] -%}

  {% do log("[DBT_MACRO] WINDOW_MATERIALIZATION: Starting window materialization", info=true) %}

  {#-- Validate early and collect configs --#}
  {%- set raw_file_format = config.get('file_format', default='openhouse') -%}
  {%- set grant_config = config.get('grants') -%}
  {%- set raw_retention = config.get('retention_period', none) -%}

  {%- set file_format = indbt_dbt_spark_validate_get_file_format(raw_file_format) -%}
  {%- set retention = dbt_spark_validate_retention_configs(raw_retention, file_format) -%}

  {%- set language = model['language'] -%}
  {%- set on_schema_change = incremental_validate_on_schema_change(config.get('on_schema_change'), default='ignore') -%}
  {%- if language != 'sql' -%}
    {{ exceptions.raise_compiler_error("materialized='window' supports only SQL models.") }}
  {%- endif -%}

  {%- set target_relation = this -%}
  {%- set existing_relation = load_relation(this) -%}

  {# -- TODO: DATAFND-1122 Hard coding the catalog as a workaround for APA-75325. Need to remove this once the spark v2 fix is deployed #}
  {% do adapter.dispatch('use_catalog', 'dbt')('spark_catalog') %}

  {#-- Run pre-hooks --#}
  {{ run_hooks(pre_hooks) }}

  {#-- Test environment variable access --#}
  {{ test_env_vars() }}

  {#-- Set WAP ID configuration if environment variable is set --#}
  {{ set_wap_id_config() }}

  {#-- Parse window configs --#}
  {%- set cfg = window__parse_window_configs(config.get('window_configs')) -%}
  {%- do log("[DBT_MACRO] WINDOW_MATERIALIZATION: window_configs parsed: " ~ cfg, info=true) -%}

  {#-- Ensure model does not already provide the derived partition column --#}
  {%- set query_columns = get_columns_in_query(compiled_code) -%}
  {%- for c in query_columns if c == cfg['partition_column'] -%}
    {{ exceptions.raise_compiler_error("Model SQL must not output the derived partition column '" ~ cfg['partition_column'] ~ "' for materialized='window'. It is added by the materialization.") }}
  {%- endfor -%}

  {#-- Compute bounds and patterns --#}
  {%- set bounds = window__bounds(cfg) -%}
  {%- set spark_pat = window__python_to_spark_pattern(cfg['partition_pattern']) -%}
  {%- do log("[DBT_MACRO] WINDOW_MATERIALIZATION: start=" ~ bounds['start'] ~ ", end=" ~ bounds['end'] ~ ", spark_pattern=" ~ spark_pat, info=true) -%}

  {#-- Set dynamic partition overwrite --#}
  {%- call statement() -%}
    set spark.sql.sources.partitionOverwriteMode = DYNAMIC
  {%- endcall -%}

  {#-- Create temp view with window filter and derived partition column --#}
  {%- set tmp_relation = make_temp_relation(this) -%}
  {%- set tmp_relation = tmp_relation.include(database=false, schema=false) -%}
  {% do log("[DBT_MACRO] WINDOW_MATERIALIZATION: Creating temp view: " ~ tmp_relation, info=true) %}

  {%- set filtered_sql -%}
    select
      src.*,
      date_format(
        {{ window__event_ts_expr('src.' ~ cfg['event_time_column'], cfg['timezone']) }},
        '{{ spark_pat }}'
      ) as {{ cfg['partition_column'] }}
    from (
      {{ compiled_code }}
    ) src
    where src.{{ cfg['event_time_column'] }} is not null
      and {{ window__event_ts_expr('src.' ~ cfg['event_time_column'], cfg['timezone']) }}
          between to_timestamp('{{ bounds['start'] }}', '{{ spark_pat }}')
              and to_timestamp('{{ bounds['end'] }}',   '{{ spark_pat }}')
  {%- endset -%}

  {%- call statement('create_tmp_relation', language='sql') -%}
    {{ create_table_as(True, tmp_relation, filtered_sql, 'sql') }}
  {%- endcall -%}

  {#-- Materialization paths --#}
  {%- if existing_relation is none or should_full_refresh() -%}
    {% do log("[DBT_MACRO] WINDOW_MATERIALIZATION: Creating or replacing base table", info=true) %}
    {%- set merged_parts = window__merge_partition_by(cfg['partition_column']) -%}
    {%- set ctas_sql -%}
      select * from {{ tmp_relation }}
    {%- endset -%}
    {%- call statement('main', language='sql') -%}
      {{ window__create_table_as(target_relation, ctas_sql, merged_parts) }}
    {%- endcall -%}
    {% do persist_constraints(target_relation, model) %}
  {%- else -%}
    {% do log("[DBT_MACRO] WINDOW_MATERIALIZATION: Overwriting partitions via INSERT OVERWRITE", info=true) %}
    {%- do process_schema_changes(on_schema_change, tmp_relation, existing_relation) -%}
    {#-- Use WAP if configured --#}
    {{ set_wap_id_config() }}

    {%- set dest_columns = adapter.get_columns_in_relation(target_relation) -%}
    {%- set dest_cols_csv = dest_columns | map(attribute='quoted') | join(', ') -%}
    {%- set merged_parts = window__merge_partition_by(cfg['partition_column']) -%}

    {%- call statement('main', language='sql') -%}
      {% if existing_relation.is_iceberg or existing_relation.is_openhouse %}
        insert overwrite {{ target_relation }}
      {% else %}
        insert overwrite table {{ target_relation }}
        {% if merged_parts and (merged_parts | length) > 0 %}
          partition (
            {%- for p in merged_parts -%}
            {{ p }}{% if not loop.last %}, {% endif %}
            {%- endfor -%}
          )
        {% endif %}
      {% endif %}
      select {{ dest_cols_csv }} from {{ tmp_relation }}
    {%- endcall -%}
  {%- endif -%}

  {#-- Apply grants, retention, docs, and custom table properties --#}
  {% set should_revoke = should_revoke(existing_relation, full_refresh_mode) %}
  {% do apply_grants(target_relation, grant_config, should_revoke) %}
  {% do apply_retention(target_relation, retention) %}
  {% do persist_docs(target_relation, model) %}
  {% set set_tbl_properties = adapter.dispatch('set_dbt_tblproperties', 'in_dbt_utils') %}
  {% do set_tbl_properties(target_relation, model) %}

  {{ run_hooks(post_hooks) }}

  {{ return({'relations': [target_relation]}) }}

{%- endmaterialization %}


