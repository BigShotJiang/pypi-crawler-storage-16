#!/usr/bin/env python3
from pathlib import Path

print(
    f"[{Path(__file__).stem}] Hello World, from prestart.py!",
    "Add database migrations and other scripts here.",
)
