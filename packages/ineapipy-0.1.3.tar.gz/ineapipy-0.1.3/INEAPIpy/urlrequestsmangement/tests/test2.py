# Set shebang if needed
# -*- coding: utf-8 -*-
"""
Created on Sat Dec 13 16:25:18 2025

@author: mano
"""

from src import RequestsManagement as RM

A2 = RM.RequestsManager(0.30, True)