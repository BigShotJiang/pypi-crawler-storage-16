# Set shebang if needed
# -*- coding: utf-8 -*-
"""
Created on Sat Dec 13 16:25:11 2025

@author: mano
"""


from src import RequestsManagement as RM


A1 = RM.RequestsManager()