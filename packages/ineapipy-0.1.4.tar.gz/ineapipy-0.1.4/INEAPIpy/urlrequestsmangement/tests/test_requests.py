#
# Set shebang if needed
# -*- coding: utf-8 -*-
"""
Created on Mon Jun 16 17:21:46 2025

@author: mano
"""


import test1
import test2

A1 = test1.A1
A2 = test2.A2

print(A1 is A2)





