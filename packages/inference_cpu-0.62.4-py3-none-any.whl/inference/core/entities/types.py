DatasetID = str
ModelID = str
VersionID = int
TaskType = str
ModelType = str
WorkspaceID = str
