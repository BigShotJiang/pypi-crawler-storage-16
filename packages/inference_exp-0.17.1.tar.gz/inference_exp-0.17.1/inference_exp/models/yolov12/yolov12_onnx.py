from inference_exp.models.yolov8.yolov8_object_detection_onnx import (
    YOLOv8ForObjectDetectionOnnx,
)


class YOLOv12ForObjectDetectionOnnx(YOLOv8ForObjectDetectionOnnx):
    pass
