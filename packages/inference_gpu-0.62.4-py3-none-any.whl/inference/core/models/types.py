from typing import Dict, NewType

PreprocessReturnMetadata = NewType("PreprocessReturnMetadata", Dict)
