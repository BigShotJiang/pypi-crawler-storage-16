__version__ = "0.62.4"


if __name__ == "__main__":
    print(__version__)
