from __future__ import annotations

__doctitle__ = "Detection Pipeline (Async)"
