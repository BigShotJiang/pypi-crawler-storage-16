"""
Allow running infiltrator as a module: python3 -m infiltrator
"""

from infiltrator.cli import main

if __name__ == '__main__':
    main()
