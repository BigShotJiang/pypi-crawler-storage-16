"""Core framework components for Infiltrator."""

from infiltrator.core.config import Config
from infiltrator.core.logger import Logger

__all__ = ['Config', 'Logger']
