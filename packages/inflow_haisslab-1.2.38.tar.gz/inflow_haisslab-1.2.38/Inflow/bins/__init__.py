# -*- coding: utf-8 -*-
"""
Created on Wed Jan 25 15:36:27 2023

@author: tjostmou
"""

from . import content
from .content import Reader
