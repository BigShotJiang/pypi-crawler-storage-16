export default {
    base_url: 'https://docs.infrahub.app/',
  };