ILLEGAL_NAMESPACES = {"Internal", "Infrahub", "Schema"}
