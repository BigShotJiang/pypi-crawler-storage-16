import inspect
from io import StringIO
from unittest import mock

import pytest
from pytest_httpx import HTTPXMock
from rich.console import Console

from infrahub_sdk import Config, InfrahubClient, InfrahubClientSync
from infrahub_sdk.ctl.schema import display_schema_load_errors
from infrahub_sdk.exceptions import SchemaNotFoundError, ValidationError
from infrahub_sdk.protocols import BuiltinIPAddress, BuiltinIPAddressSync, BuiltinTag, BuiltinTagSync
from infrahub_sdk.schema import BranchSchema, InfrahubSchema, InfrahubSchemaBase, InfrahubSchemaSync, NodeSchemaAPI
from infrahub_sdk.schema.repository import (
    InfrahubCheckDefinitionConfig,
    InfrahubJinja2TransformConfig,
    InfrahubPythonTransformConfig,
    InfrahubRepositoryArtifactDefinitionConfig,
    InfrahubRepositoryConfig,
)
from tests.unit.sdk.conftest import BothClients

async_schema_methods = [method for method in dir(InfrahubSchema) if not method.startswith("_")]
sync_schema_methods = [method for method in dir(InfrahubSchemaSync) if not method.startswith("_")]

client_types = ["standard", "sync"]


async def test_method_sanity() -> None:
    """Validate that there is at least one public method and that both clients look the same."""
    assert async_schema_methods
    assert async_schema_methods == sync_schema_methods


@pytest.mark.parametrize("method", async_schema_methods)
async def test_validate_method_signature(method) -> None:
    async_method = getattr(InfrahubSchema, method)
    sync_method = getattr(InfrahubSchemaSync, method)
    async_sig = inspect.signature(async_method)
    sync_sig = inspect.signature(sync_method)
    assert async_sig.parameters == sync_sig.parameters
    assert async_sig.return_annotation == sync_sig.return_annotation


@pytest.mark.parametrize("client_type", client_types)
async def test_fetch_schema(mock_schema_query_01, client_type) -> None:
    if client_type == "standard":
        client = InfrahubClient(config=Config(address="http://mock", insert_tracker=True))
        nodes = await client.schema.fetch(branch="main")
    else:
        client = InfrahubClientSync(config=Config(address="http://mock", insert_tracker=True))
        nodes = client.schema.fetch(branch="main")

    assert len(nodes) == 4
    assert sorted(nodes.keys()) == [
        "BuiltinLocation",
        "BuiltinTag",
        "CoreGraphQLQuery",
        "CoreRepository",
    ]
    assert isinstance(nodes["BuiltinTag"], NodeSchemaAPI)


@pytest.mark.parametrize("client_type", client_types)
async def test_fetch_schema_conditional_refresh(mock_schema_query_01: HTTPXMock, client_type: str) -> None:
    """Verify that only one schema request is sent if we request to update the schema but already have the correct hash"""
    if client_type == "standard":
        client = InfrahubClient(config=Config(address="http://mock", insert_tracker=True))
        nodes = await client.schema.all(branch="main")
        schema_hash = client.schema.cache["main"].hash
        assert schema_hash
        nodes = await client.schema.all(branch="main", refresh=True, schema_hash=schema_hash)
    else:
        client = InfrahubClientSync(config=Config(address="http://mock", insert_tracker=True))
        nodes = client.schema.all(branch="main")
        schema_hash = client.schema.cache["main"].hash
        assert schema_hash
        nodes = client.schema.all(branch="main", refresh=True, schema_hash=schema_hash)

    assert len(nodes) == 4
    assert sorted(nodes.keys()) == [
        "BuiltinLocation",
        "BuiltinTag",
        "CoreGraphQLQuery",
        "CoreRepository",
    ]
    assert isinstance(nodes["BuiltinTag"], NodeSchemaAPI)
    assert len(mock_schema_query_01.get_requests()) == 1


@pytest.mark.parametrize("client_type", client_types)
async def test_schema_data_validation(rfile_schema, client_type) -> None:
    if client_type == "standard":
        client = InfrahubClient(config=Config(address="http://mock", insert_tracker=True))
    else:
        client = InfrahubClientSync(config=Config(address="http://mock", insert_tracker=True))

    client.schema.validate_data_against_schema(
        schema=rfile_schema,
        data={"name": "some-name", "description": "Some description"},
    )

    with pytest.raises(ValidationError) as excinfo:
        client.schema.validate_data_against_schema(
            schema=rfile_schema, data={"name": "some-name", "invalid_field": "yes"}
        )

    assert excinfo.value.message == "invalid_field is not a valid value for CoreTransformJinja2"


@pytest.mark.parametrize("client_type", client_types)
async def test_add_dropdown_option(
    clients, client_type, mock_schema_query_01, mock_query_mutation_schema_dropdown_add
) -> None:
    if client_type == "standard":
        await clients.standard.schema.add_dropdown_option("BuiltinTag", "status", "something")
    else:
        clients.sync.schema.add_dropdown_option("BuiltinTag", "status", "something")


@pytest.mark.parametrize("client_type", client_types)
async def test_remove_dropdown_option(
    clients, client_type, mock_schema_query_01, mock_query_mutation_schema_dropdown_remove
) -> None:
    if client_type == "standard":
        await clients.standard.schema.remove_dropdown_option("BuiltinTag", "status", "active")
    else:
        clients.sync.schema.remove_dropdown_option("BuiltinTag", "status", "active")


@pytest.mark.parametrize("client_type", client_types)
async def test_add_enum_option(clients, client_type, mock_schema_query_01, mock_query_mutation_schema_enum_add) -> None:
    if client_type == "standard":
        await clients.standard.schema.add_enum_option("BuiltinTag", "mode", "hard")
    else:
        clients.sync.schema.add_enum_option("BuiltinTag", "mode", "hard")


@pytest.mark.parametrize("client_type", client_types)
async def test_remove_enum_option(
    clients, client_type, mock_schema_query_01, mock_query_mutation_schema_enum_remove
) -> None:
    if client_type == "standard":
        await clients.standard.schema.remove_enum_option("BuiltinTag", "mode", "easy")
    else:
        clients.sync.schema.remove_enum_option("BuiltinTag", "mode", "easy")


@pytest.mark.parametrize("client_type", client_types)
async def test_add_dropdown_option_raises(clients, client_type, mock_schema_query_01) -> None:
    if client_type == "standard":
        with pytest.raises(SchemaNotFoundError):
            await clients.standard.schema.add_dropdown_option("DoesNotExist", "atribute", "option")
        with pytest.raises(ValueError):
            await clients.standard.schema.add_dropdown_option("BuiltinTag", "attribute", "option")
    else:
        with pytest.raises(SchemaNotFoundError):
            clients.sync.schema.add_dropdown_option("DoesNotExist", "atribute", "option")
        with pytest.raises(ValueError):
            clients.sync.schema.add_dropdown_option("BuiltinTag", "attribute", "option")


@pytest.mark.parametrize("client_type", client_types)
async def test_add_enum_option_raises(clients, client_type, mock_schema_query_01) -> None:
    if client_type == "standard":
        with pytest.raises(SchemaNotFoundError):
            await clients.standard.schema.add_enum_option("DoesNotExist", "atribute", "option")
        with pytest.raises(ValueError):
            await clients.standard.schema.add_enum_option("BuiltinTag", "attribute", "option")
    else:
        with pytest.raises(SchemaNotFoundError):
            clients.sync.schema.add_enum_option("DoesNotExist", "atribute", "option")
        with pytest.raises(ValueError):
            clients.sync.schema.add_enum_option("BuiltinTag", "attribute", "option")


@pytest.mark.parametrize("client_type", client_types)
async def test_remove_dropdown_option_raises(clients, client_type, mock_schema_query_01) -> None:
    if client_type == "standard":
        with pytest.raises(SchemaNotFoundError):
            await clients.standard.schema.remove_dropdown_option("DoesNotExist", "atribute", "option")
        with pytest.raises(ValueError):
            await clients.standard.schema.remove_dropdown_option("BuiltinTag", "attribute", "option")
    else:
        with pytest.raises(SchemaNotFoundError):
            clients.sync.schema.remove_dropdown_option("DoesNotExist", "atribute", "option")
        with pytest.raises(ValueError):
            clients.sync.schema.remove_dropdown_option("BuiltinTag", "attribute", "option")


@pytest.mark.parametrize("client_type", client_types)
async def test_remove_enum_option_raises(clients, client_type, mock_schema_query_01) -> None:
    if client_type == "standard":
        with pytest.raises(SchemaNotFoundError):
            await clients.standard.schema.remove_enum_option("DoesNotExist", "atribute", "option")
        with pytest.raises(ValueError):
            await clients.standard.schema.remove_enum_option("BuiltinTag", "attribute", "option")
    else:
        with pytest.raises(SchemaNotFoundError):
            clients.sync.schema.add_enum_option("DoesNotExist", "atribute", "option")
        with pytest.raises(ValueError):
            clients.sync.schema.add_enum_option("BuiltinTag", "attribute", "option")


@pytest.mark.parametrize("client_type", client_types)
async def test_schema_wait_happy_path(clients: BothClients, client_type: list[str], httpx_mock: HTTPXMock) -> None:
    """Simplistic unittest that can be removed once we have the integration tests running again."""
    httpx_mock.add_response(
        method="POST",
        url="http://mock/graphql/branch1",
        json={"data": {"InfrahubStatus": {"summary": {"schema_hash_synced": False}}}},
    )
    httpx_mock.add_response(
        method="POST",
        url="http://mock/graphql/branch1",
        json={"data": {"InfrahubStatus": {"summary": {"schema_hash_synced": True}}}},
    )
    if client_type == "standard":
        await clients.standard.schema.wait_until_converged(branch="branch1")
    else:
        clients.sync.schema.wait_until_converged(branch="branch1")

    assert len(httpx_mock.get_requests()) == 2


@pytest.mark.parametrize("client_type", client_types)
async def test_schema_set_cache_dict(clients: BothClients, client_type: list[str], schema_query_01_data: dict) -> None:
    if client_type == "standard":
        client = clients.standard
    else:
        client = clients.sync

    client.schema.set_cache(schema_query_01_data, branch="branch1")
    assert "branch1" in client.schema.cache
    assert client.schema.cache["branch1"].nodes["CoreGraphQLQuery"]


@pytest.mark.parametrize("client_type", client_types)
async def test_schema_set_cache_branch_schema(
    clients: BothClients, client_type: list[str], schema_query_01_data: dict
) -> None:
    if client_type == "standard":
        client = clients.standard
    else:
        client = clients.sync

    schema = BranchSchema.from_api_response(schema_query_01_data)

    client.schema.set_cache(schema)
    assert "main" in client.schema.cache
    assert client.schema.cache["main"].nodes["CoreGraphQLQuery"]


async def test_infrahub_repository_config_getters() -> None:
    repo_config = InfrahubRepositoryConfig(
        jinja2_transforms=[
            InfrahubJinja2TransformConfig(name="rfile01", query="query01", template_path="."),
            InfrahubJinja2TransformConfig(name="rfile02", query="query01", template_path="."),
        ],
        artifact_definitions=[
            InfrahubRepositoryArtifactDefinitionConfig(
                name="artifact01",
                parameters={},
                content_type="JSON",
                targets="group1",
                transformation="transformation01",
            ),
            InfrahubRepositoryArtifactDefinitionConfig(
                name="artifact02",
                parameters={},
                content_type="JSON",
                targets="group2",
                transformation="transformation01",
            ),
        ],
        check_definitions=[
            InfrahubCheckDefinitionConfig(name="check01", file_path=".", parameters={}, class_name="MyClass"),
            InfrahubCheckDefinitionConfig(name="check02", file_path=".", parameters={}, class_name="MyClass"),
        ],
        python_transforms=[
            InfrahubPythonTransformConfig(name="transform01", file_path=".", class_name="MyClass"),
            InfrahubPythonTransformConfig(name="transform02", file_path=".", class_name="MyClass"),
        ],
    )

    assert repo_config.has_jinja2_transform(name="rfile01") is True
    assert repo_config.has_jinja2_transform(name="rfile99") is False
    assert isinstance(repo_config.get_jinja2_transform(name="rfile01"), InfrahubJinja2TransformConfig)

    assert repo_config.has_artifact_definition(name="artifact01") is True
    assert repo_config.has_artifact_definition(name="artifact99") is False
    assert isinstance(
        repo_config.get_artifact_definition(name="artifact01"), InfrahubRepositoryArtifactDefinitionConfig
    )

    assert repo_config.has_check_definition(name="check01") is True
    assert repo_config.has_check_definition(name="check99") is False
    assert isinstance(repo_config.get_check_definition(name="check01"), InfrahubCheckDefinitionConfig)

    assert repo_config.has_python_transform(name="transform01") is True
    assert repo_config.has_python_transform(name="transform99") is False
    assert isinstance(repo_config.get_python_transform(name="transform01"), InfrahubPythonTransformConfig)


async def test_infrahub_repository_config_dups() -> None:
    with pytest.raises(ValueError) as exc:
        InfrahubRepositoryConfig(
            jinja2_transforms=[
                InfrahubJinja2TransformConfig(name="rfile01", query="query01", template_path="."),
                InfrahubJinja2TransformConfig(name="rfile02", query="query01", template_path="."),
                InfrahubJinja2TransformConfig(name="rfile02", query="query01", template_path="."),
            ],
        )

    assert "Found multiples element with the same names: ['rfile02']" in str(exc.value)

    with pytest.raises(ValueError) as exc:
        InfrahubRepositoryConfig(
            check_definitions=[
                InfrahubCheckDefinitionConfig(name="check01", file_path=".", parameters={}, class_name="MyClass"),
                InfrahubCheckDefinitionConfig(name="check01", file_path=".", parameters={}, class_name="MyClass"),
                InfrahubCheckDefinitionConfig(name="check02", file_path=".", parameters={}, class_name="MyClass"),
                InfrahubCheckDefinitionConfig(name="check02", file_path=".", parameters={}, class_name="MyClass"),
                InfrahubCheckDefinitionConfig(name="check02", file_path=".", parameters={}, class_name="MyClass"),
                InfrahubCheckDefinitionConfig(name="check03", file_path=".", parameters={}, class_name="MyClass"),
            ],
        )

    assert "Found multiples element with the same names: ['check01', 'check02']" in str(exc.value)


@mock.patch(
    "infrahub_sdk.ctl.schema.get_node",
    return_value={
        "name": "Instance",
        "namespace": "Cloud",
        "attributes": [{"name": "name", "kind": "Text"}, {"name": "status", "kind": "Dropdown"}],
    },
)
async def test_display_schema_load_errors_details_dropdown(mock_get_node) -> None:
    """Validate error message with details when loading schema."""
    error = {
        "detail": [
            {
                "type": "value_error",
                "loc": ["body", "schemas", 0, "nodes", 0, "attributes", 1],
                "msg": "Value error, The property 'choices' is required for kind=Dropdown",
                "input": {"name": "status", "kind": "Dropdown"},
                "ctx": {"error": {}},
                "url": "https://errors.pydantic.dev/2.7/v/value_error",
            },
        ]
    }

    with mock.patch("infrahub_sdk.ctl.schema.console", Console(file=StringIO(), width=1000)) as console:
        display_schema_load_errors(response=error, schemas_data=[])
        mock_get_node.assert_called_once()
        output = console.file.getvalue()
        expected_console = """Unable to load the schema:
  Node: CloudInstance | Attribute: status ({'name': 'status', 'kind': 'Dropdown'}) | Value error, The property 'choices' is required for kind=Dropdown (value_error)
"""  # noqa: E501
        assert output == expected_console


@mock.patch(
    "infrahub_sdk.ctl.schema.get_node",
    return_value={
        "name": "Instance",
        "namespace": "OuT",
        "attributes": [{"name": "name", "kind": "Text"}, {"name": "status", "kind": "Dropdown"}],
    },
)
async def test_display_schema_load_errors_details_namespace(mock_get_node) -> None:
    """Validate error message with details when loading schema."""
    error = {
        "detail": [
            {
                "type": "string_pattern_mismatch",
                "loc": ["body", "schemas", 0, "nodes", 0, "namespace"],
                "msg": "String should match pattern '^[A-Z][a-z0-9]+$'",
                "input": "OuT",
                "ctx": {"pattern": "^[A-Z][a-z0-9]+$"},
                "url": "https://errors.pydantic.dev/2.7/v/string_pattern_mismatch",
            },
        ]
    }

    with mock.patch("infrahub_sdk.ctl.schema.console", Console(file=StringIO(), width=1000)) as console:
        display_schema_load_errors(response=error, schemas_data=[])
        mock_get_node.assert_called_once()
        output = console.file.getvalue()
        expected_console = """Unable to load the schema:
  Node: OuTInstance | namespace (OuT) | String should match pattern '^[A-Z][a-z0-9]+$' (string_pattern_mismatch)
"""
        assert output == expected_console


@mock.patch(
    "infrahub_sdk.ctl.schema.get_node",
    return_value={
        "name": "TailscaleSSHRule",
        "namespace": "Security",
        "icon": "mdi:security",
        "inherit_from": ["SecurityRule"],
        "attributes": [
            {
                "name": "check_period",
                "kind": "Number",
                "optional": True,
                "default_value": 720,
                "min_value": 0,
                "max_value": 10080,
            },
            {"name": "accept_env", "kind": "List", "optional": True},
            {
                "name": "action",
                "optional": True,
                "kind": "Dropdown",
                "default_value": "allow",
                "choices": [
                    {"label": "allow", "name": "allow"},
                    {"label": "check", "name": "check"},
                ],
            },
        ],
    },
)
async def test_display_schema_load_errors_details_when_error_is_in_attribute_or_relationship(mock_get_node) -> None:
    """Validate error message with details when loading schema and errors are in attribute or relationship."""
    error = {
        "detail": [
            {
                "type": "extra_forbidden",
                "loc": ["body", "schemas", 0, "nodes", 4, "attributes", "min_value"],
                "msg": "Extra inputs are not permitted",
                "input": 0,
            },
            {
                "type": "extra_forbidden",
                "loc": ["body", "schemas", 0, "nodes", 4, "attributes", "max_value"],
                "msg": "Extra inputs are not permitted",
                "input": 10080,
            },
        ]
    }

    with mock.patch("infrahub_sdk.ctl.schema.console", Console(file=StringIO(), width=1000)) as console:
        display_schema_load_errors(response=error, schemas_data=[])
        assert mock_get_node.call_count == 2
        output = console.file.getvalue()
        expected_console = """Unable to load the schema:
  Node: SecurityTailscaleSSHRule | Attribute: check_period (0) | Extra inputs are not permitted (extra_forbidden)
  Node: SecurityTailscaleSSHRule | Attribute: check_period (10080) | Extra inputs are not permitted (extra_forbidden)
"""
        assert output == expected_console


def test_schema_base__get_schema_name__returns_correct_schema_name_for_protocols() -> None:
    assert InfrahubSchemaBase._get_schema_name(schema=BuiltinTagSync) == "BuiltinTag"
    assert InfrahubSchemaBase._get_schema_name(schema=BuiltinTag) == "BuiltinTag"
    assert InfrahubSchemaBase._get_schema_name(schema="BuiltinTag") == "BuiltinTag"
    assert InfrahubSchemaBase._get_schema_name(schema=BuiltinIPAddressSync) == "BuiltinIPAddress"
    assert InfrahubSchemaBase._get_schema_name(schema=BuiltinIPAddress) == "BuiltinIPAddress"
    assert InfrahubSchemaBase._get_schema_name(schema="BuiltinIPAddress") == "BuiltinIPAddress"
