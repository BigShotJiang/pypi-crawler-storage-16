# Infraion

A flexible inference framework for large language models.

## Installation

```bash
pip install infraion
```

With provider support:

```bash
pip install infraion[openai]
pip install infraion[anthropic]
pip install infraion[all]
```

## Quick Start

```python
from infraion import InfraionEngine, InfraionConfig

config = InfraionConfig(model="gpt-4")
engine = InfraionEngine(config)

response = await engine.generate("Hello, world!")
print(response)
```

## Status

This package is currently in pre-alpha. Full implementation coming soon.

## License

Apache-2.0
