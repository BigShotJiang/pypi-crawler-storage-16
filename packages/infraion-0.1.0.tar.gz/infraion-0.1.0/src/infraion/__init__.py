"""
Infraion - LLM Inference Framework

A flexible framework for large language model inference.
"""

__version__ = "0.1.0"

from .engine import InfraionEngine
from .config import InfraionConfig

__all__ = [
    "__version__",
    "InfraionEngine",
    "InfraionConfig",
]
