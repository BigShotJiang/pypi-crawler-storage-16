"""Configuration for Infraion."""

from typing import Optional, Dict, Any
from pydantic import BaseModel


class InfraionConfig(BaseModel):
    """Configuration for the inference engine."""

    model: str = "gpt-4"
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    timeout: float = 60.0
    max_retries: int = 3
    options: Dict[str, Any] = {}
