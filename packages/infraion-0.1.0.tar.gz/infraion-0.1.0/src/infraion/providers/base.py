"""Base provider interface."""

from typing import AsyncIterator, Any, Protocol


class BaseProvider(Protocol):
    """Protocol for LLM providers."""

    async def complete(self, prompt: str, **kwargs: Any) -> str:
        """Generate completion."""
        ...

    async def stream(self, prompt: str, **kwargs: Any) -> AsyncIterator[str]:
        """Stream completion."""
        ...
