"""Sampling utilities."""
