"""Common definitions for the package"""
