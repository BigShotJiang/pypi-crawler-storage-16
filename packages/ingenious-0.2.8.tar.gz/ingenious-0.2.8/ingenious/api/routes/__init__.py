"""Route definitions for ingenious API endpoints.

This module provides extensible path support for route modules.
"""

from pkgutil import extend_path

__path__ = extend_path(__path__, __name__)
