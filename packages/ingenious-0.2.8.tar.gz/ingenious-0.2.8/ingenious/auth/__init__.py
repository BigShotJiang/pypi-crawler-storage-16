"""Authentication module for ingenious.

This module provides JWT token management and authentication middleware
for securing API endpoints.
"""
