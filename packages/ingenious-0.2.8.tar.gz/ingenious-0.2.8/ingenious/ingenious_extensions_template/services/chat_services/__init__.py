"""Chat service implementations for project extensions."""
