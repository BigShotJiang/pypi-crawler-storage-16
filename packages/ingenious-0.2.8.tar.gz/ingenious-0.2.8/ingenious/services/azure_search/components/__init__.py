"""Azure AI Search component implementations.

Provides reusable components for Azure AI Search functionality including
query builders, filters, and response processors.
"""
