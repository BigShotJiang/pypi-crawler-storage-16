"""Test suite for Azure AI Search integration."""
