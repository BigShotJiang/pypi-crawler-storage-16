"""Document retrieval services for Ingenious.

Provides unified interface for document retrieval from various sources including
Azure AI Search, ChromaDB, and other vector databases.
"""
