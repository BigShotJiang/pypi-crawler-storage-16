"""List all our custom exceptions."""


class MissingEnvVariable(Exception):
    """Raised if a critical env variable is missing."""

    pass

