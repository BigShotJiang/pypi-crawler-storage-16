# App

A simple interactive app.

## Example

![Example](app.gif)

```python
--8<-- "examples/app.py"
```
