# Confirm

A confirmation prompt that allows the user to confirm or reject.

## Example

![Example](confirm.gif)

```python
--8<-- "examples/prompt_confirm.py"
```
