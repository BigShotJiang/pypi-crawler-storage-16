# Multi

A prompt that allows the user to answer multiple prompts in sequence.

## Example

![Example](multi.gif)

```python
--8<-- "examples/prompt_multi.py"
```
