# Select

A select widget that allows a single selection from a list of choices.

## Example

![Example](select.gif)

```python
--8<-- "examples/prompt_select.py"
```
