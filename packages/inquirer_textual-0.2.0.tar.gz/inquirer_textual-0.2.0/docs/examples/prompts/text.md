# Text

A text input prompt that allows the user to enter a string.

## Example

![Example](text.gif)

```python
--8<-- "examples/prompt_text.py"
```
