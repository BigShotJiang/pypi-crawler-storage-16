# Frequently Asked Questions

## What are similar projects?

- [InquirerPy](https://github.com/kazhala/InquirerPy)
- [python-inquirer](https://github.com/magmax/python-inquirer) 
