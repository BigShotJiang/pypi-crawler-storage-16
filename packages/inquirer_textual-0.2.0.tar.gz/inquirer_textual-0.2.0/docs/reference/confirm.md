# InquirerConfirm

::: inquirer_textual.widgets.InquirerConfirm.InquirerConfirm
