# InquirerMulti

::: inquirer_textual.widgets.InquirerMulti.InquirerMulti
