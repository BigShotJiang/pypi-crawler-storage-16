# InquirerNumber

::: inquirer_textual.widgets.InquirerNumber.InquirerNumber
