# InquirerSelect

::: inquirer_textual.widgets.InquirerSelect.InquirerSelect
