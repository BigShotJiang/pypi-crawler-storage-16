# InquirerText

::: inquirer_textual.widgets.InquirerText.InquirerText
