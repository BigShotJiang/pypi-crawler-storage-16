This devcontainer include tools such as minikube and Helm which are required for
Kubernetes Sandbox Environment development and testing.

It is used by the CI pipeline. Its use is optional for local development.
