The Compose Spec was downloaded from
https://github.com/compose-spec/compose-spec/blob/main/schema/compose-spec.json in March
2025 revision 6632cc1064e1d5461e59cd80db8096367fc78840.
