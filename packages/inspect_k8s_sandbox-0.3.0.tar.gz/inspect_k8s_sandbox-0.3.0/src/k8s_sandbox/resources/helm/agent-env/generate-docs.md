# Generate docs

You can regenerate docs using [helm-docs](https://github.com/norwoodj/helm-docs) after
changing values.yaml.

This is performed automatically by a pre-commit hook.
