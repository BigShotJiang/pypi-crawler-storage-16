from install_locked_env.__main__ import cli
