from importlib.metadata import version

__version__ = version("install-locked-env")
