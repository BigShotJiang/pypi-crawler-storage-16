def main():
    """
    Placeholder entrypoint for evaluators.
    Does NOT execute anything yet.
    """
    pass
