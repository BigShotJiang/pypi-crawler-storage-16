from .base_executor import BaseExecutor


class DockerExecutor(BaseExecutor):
    pass
