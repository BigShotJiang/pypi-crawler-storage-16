from .base_executor import BaseExecutor


class LocalExecutor(BaseExecutor):
    pass
