class ExecutionResult:
    """
    Placeholder. Real fields will be populated later.
    """
    pass
