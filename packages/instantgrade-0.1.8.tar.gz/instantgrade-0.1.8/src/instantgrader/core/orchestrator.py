class Orchestrator:
    """
    Placeholder orchestrator. Does NOT change current grading behavior.
    Real logic will be added later.
    """
    pass
