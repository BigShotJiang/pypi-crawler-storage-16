class PluginRegistry:
    """
    Placeholder plugin mapping.
    """
    def register(self, assignment_type, config):
        pass

    def get(self, assignment_type):
        return None
