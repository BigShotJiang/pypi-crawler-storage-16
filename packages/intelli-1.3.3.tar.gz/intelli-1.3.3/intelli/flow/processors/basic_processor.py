class TextProcessor:

    @staticmethod
    def text_head(text, size=800):
        return text[:size]
