"""Utility exports for IntentKit."""

from intentkit.utils.ens import resolve_ens_to_address

__all__ = ["resolve_ens_to_address"]
