# Copyright (c) 2023 The InterpretML Contributors
# Distributed under the MIT software license

from interpret.glassbox._ebm._ebm import (
    DPExplainableBoostingClassifier,  # noqa: F401
    DPExplainableBoostingRegressor,  # noqa: F401
)
