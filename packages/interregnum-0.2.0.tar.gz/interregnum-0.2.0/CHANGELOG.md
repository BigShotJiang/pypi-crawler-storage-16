<!--
SPDX-FileCopyrightText: 2025 wmj <wmj.py@gmx.com>

SPDX-License-Identifier: LGPL-3.0-or-later
-->

## Changelog


### 0.2.0

- Command line: generate a dependency graph in Graphviz DOT format from an electoral system


### 0.1.0

- Initial public release
