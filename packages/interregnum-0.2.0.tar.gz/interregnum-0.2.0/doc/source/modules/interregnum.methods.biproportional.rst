.. SPDX-FileCopyrightText: 2025 wmj <wmj.py@gmx.com>
..
.. SPDX-License-Identifier: LGPL-3.0-or-later

interregnum.methods.biproportional package
==========================================

.. automodule:: interregnum.methods.biproportional
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

interregnum.methods.biproportional.table module
-----------------------------------------------

.. automodule:: interregnum.methods.biproportional.table
   :members:
   :undoc-members:
   :show-inheritance:

interregnum.methods.biproportional.tally module
-----------------------------------------------

.. automodule:: interregnum.methods.biproportional.tally
   :members:
   :undoc-members:
   :show-inheritance:
