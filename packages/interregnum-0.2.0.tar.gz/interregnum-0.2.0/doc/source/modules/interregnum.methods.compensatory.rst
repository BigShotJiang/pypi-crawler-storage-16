.. SPDX-FileCopyrightText: 2025 wmj <wmj.py@gmx.com>
..
.. SPDX-License-Identifier: LGPL-3.0-or-later

interregnum.methods.compensatory package
========================================

.. automodule:: interregnum.methods.compensatory
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

interregnum.methods.compensatory.additional\_member module
----------------------------------------------------------

.. automodule:: interregnum.methods.compensatory.additional_member
   :members:
   :undoc-members:
   :show-inheritance:

interregnum.methods.compensatory.mixed\_member module
-----------------------------------------------------

.. automodule:: interregnum.methods.compensatory.mixed_member
   :members:
   :undoc-members:
   :show-inheritance:
