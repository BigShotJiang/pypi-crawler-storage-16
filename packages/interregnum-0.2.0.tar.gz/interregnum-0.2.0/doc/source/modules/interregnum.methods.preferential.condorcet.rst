.. SPDX-FileCopyrightText: 2025 wmj <wmj.py@gmx.com>
..
.. SPDX-License-Identifier: LGPL-3.0-or-later

interregnum.methods.preferential.condorcet package
==================================================

.. automodule:: interregnum.methods.preferential.condorcet
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

interregnum.methods.preferential.condorcet.pairwise module
----------------------------------------------------------

.. automodule:: interregnum.methods.preferential.condorcet.pairwise
   :members:
   :undoc-members:
   :show-inheritance:

interregnum.methods.preferential.condorcet.ranked\_pairs module
---------------------------------------------------------------

.. automodule:: interregnum.methods.preferential.condorcet.ranked_pairs
   :members:
   :undoc-members:
   :show-inheritance:

interregnum.methods.preferential.condorcet.rankings module
----------------------------------------------------------

.. automodule:: interregnum.methods.preferential.condorcet.rankings
   :members:
   :undoc-members:
   :show-inheritance:
