#!/bin/bash

# SPDX-FileCopyrightText: 2025 wmj <wmj.py@gmx.com>
#
# SPDX-License-Identifier: LGPL-3.0-or-later

sphinx-autobuild -j 12 --watch ../src/interregnum/ source build
