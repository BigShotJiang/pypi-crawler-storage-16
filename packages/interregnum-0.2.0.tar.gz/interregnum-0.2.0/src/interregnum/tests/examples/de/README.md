<!--
SPDX-FileCopyrightText: 2025 wmj <wmj.py@gmx.com>

SPDX-License-Identifier: LGPL-3.0-or-later
-->

https://www.bundeswahlleiterin.de/bundestagswahlen/2025/ergebnisse/opendata.html#df814f61-8eef-4145-b693-fbc6d038ab40
