<!--
SPDX-FileCopyrightText: 2025 wmj <wmj.py@gmx.com>

SPDX-License-Identifier: LGPL-3.0-or-later
-->

https://valgresultat.no/valg/2021/st

Valgdistriktnummer
    Número de distrito electoral
Valgdistriktnavn
    Nombre del distrito electoral
Antall stemmeberettigede
    Número de votantes
Godkjente stemmegivninger — Forhånd
    Votos aprobados — Avance
Godkjente stemmegivninger - Valgting
    Votos aprobados - Consejo Electoral
Godkjente stemmegivninger - Totalt
    Votos aprobados - Total
Forkastede stemmegivninger - Forhånd
    Votos rechazados - Avance
Forkastede stemmegivninger - Totalt
    Votos rechazados - Total
Godkjente stemmesedler - Forhånd
    Boletas Aprobadas - Anticipadas
Godkjente stemmesedler - Valgting
    Papeletas aprobadas - Consejo Electoral
Godkjente stemmesedler - Totalt
    Votos Aprobados - Total
Forkastede stemmesedler - Forhånd
    Papeletas rechazadas - Adelanto
Forkastede stemmesedler - Totalt
    Papeletas rechazadas - Total
Blanke stemmesedler - Forhånd
    Votos en blanco - Adelanto
Blanke stemmesedler - Totalt
    Votos en blanco - Total


Oppslutning prosentvis
    Porcentaje de soporte 
Antall stemmeberettigede
    Número de votantes
Antall forhåndsstemmer
    Número de votos anticipados
Antall valgtingstemmer
    Número de votos electorales
Antall stemmer totalt
    Número total de votos
Endring % siste tilsvarende valg
    Cambio % última elección correspondiente
Antall mandater
    Número de mandatos
Antall utjevningsmandater
    Número de mandatos de igualación

