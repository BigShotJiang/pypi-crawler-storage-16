..
    Copyright (C) 2020 CERN.

    Invenio-Records-Resources is free software; you can redistribute it and/or
    modify it under the terms of the MIT License; see LICENSE file for more
    details.

==========================
 Invenio-Records-Resources
==========================

.. image:: https://github.com/inveniosoftware/invenio-records-resources/workflows/CI/badge.svg
        :target: https://github.com/inveniosoftware/invenio-records-resources/actions?query=workflow%3ACI

.. image:: https://img.shields.io/coveralls/inveniosoftware/invenio-records-resources.svg
        :target: https://coveralls.io/r/inveniosoftware/invenio-records-resources

.. image:: https://img.shields.io/github/tag/inveniosoftware/invenio-records-resources.svg
        :target: https://github.com/inveniosoftware/invenio-records-resources/releases

.. image:: https://img.shields.io/pypi/dm/invenio-records-resources.svg
        :target: https://pypi.python.org/pypi/invenio-records-resources

.. image:: https://img.shields.io/github/license/inveniosoftware/invenio-records-resources.svg
        :target: https://github.com/inveniosoftware/invenio-records-resources/blob/master/LICENSE

Invenio Resources module to create REST APIs

TODO: Please provide feature overview of module

Further documentation is available on
https://invenio-records-resources.readthedocs.io/
