..
    This file is part of Invenio.
    Copyright (C) 2015-2018 CERN.

    Invenio is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.

====================
 Invenio-Records-UI
====================

.. image:: https://img.shields.io/github/license/inveniosoftware/invenio-records-ui.svg
        :target: https://github.com/inveniosoftware/invenio-records-ui/blob/master/LICENSE

.. image:: https://github.com/inveniosoftware/invenio-records-ui/workflows/CI/badge.svg
        :target: https://github.com/inveniosoftware/invenio-records-ui/actions

.. image:: https://img.shields.io/coveralls/inveniosoftware/invenio-records-ui.svg
        :target: https://coveralls.io/r/inveniosoftware/invenio-records-ui

.. image:: https://img.shields.io/pypi/v/invenio-records-ui.svg
        :target: https://pypi.org/pypi/invenio-records-ui

User interface for Invenio-Records.

Further documentation is available on
https://invenio-records-ui.readthedocs.io/.
