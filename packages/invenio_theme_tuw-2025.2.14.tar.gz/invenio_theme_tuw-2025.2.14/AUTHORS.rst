..
    Copyright (C) 2020 - 2021 TU Wien.

    Invenio-Theme-TUW is free software; you can redistribute it and/or
    modify it under the terms of the MIT License; see LICENSE file for more
    details.

Authors
=======

TU Wien theme for Invenio (RDM).

- TU Wien <tudata@tuwien.ac.at>
