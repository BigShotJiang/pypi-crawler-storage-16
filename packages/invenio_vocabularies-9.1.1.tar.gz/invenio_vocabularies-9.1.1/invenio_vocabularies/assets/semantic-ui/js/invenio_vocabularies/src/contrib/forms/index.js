// This file is part of InvenioVocabularies
// Copyright (C) 2023 CERN.
//
// Invenio is free software; you can redistribute it and/or modify it
// under the terms of the MIT License; see LICENSE file for more details.

export { FundingField } from "./Funding";
