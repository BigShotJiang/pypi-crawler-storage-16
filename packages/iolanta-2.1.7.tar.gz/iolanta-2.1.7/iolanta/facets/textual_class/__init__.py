from iolanta.facets.textual_class.facets import Class

__all__ = ['Class']
