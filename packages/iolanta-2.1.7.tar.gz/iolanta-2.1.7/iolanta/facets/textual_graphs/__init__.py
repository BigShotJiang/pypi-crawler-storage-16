"""Facet to render named graphs."""

from iolanta.facets.textual_graphs.facets import Graphs

__all__ = ['Graphs']

