from iolanta.facets.textual_link.facet import TextualLinkFacet

__all__ = ['TextualLinkFacet']
