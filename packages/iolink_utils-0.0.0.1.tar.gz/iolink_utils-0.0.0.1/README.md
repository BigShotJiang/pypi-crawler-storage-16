[![Build](https://github.com/shaag7967/iolink_utils/actions/workflows/tests.yml/badge.svg)](https://app.codecov.io/github/shaag7967/iolink_utils?search=&displayType=list)
[![codecov](https://codecov.io/github/shaag7967/iolink_utils/branch/main/graph/badge.svg?token=RN09P8UIID)](https://codecov.io/github/shaag7967/iolink_utils)
![Python](https://img.shields.io/badge/python-3.8%20%7C%203.11%20%7C%203.13-blue)

