from enum import IntEnum


class TransmissionDirection(IntEnum):
    Write = 0,
    Read = 1
