[![PyPI version](https://badge.fury.io/py/iolink-utils.svg)](https://pypi.org/project/iolink-utils/)
[![Build](https://github.com/shaag7967/iolink-utils/actions/workflows/tests.yml/badge.svg)](https://app.codecov.io/github/shaag7967/iolink_utils?search=&displayType=list)
[![codecov](https://codecov.io/github/shaag7967/iolink-utils/branch/main/graph/badge.svg?token=RN09P8UIID)](https://codecov.io/github/shaag7967/iolink-utils)
![Python](https://img.shields.io/badge/python-3.8%20%7C%203.11%20%7C%203.13-blue)
![License](https://img.shields.io/github/license/shaag7967/iolink-utils.svg)

**Still under development - use with caution.**
