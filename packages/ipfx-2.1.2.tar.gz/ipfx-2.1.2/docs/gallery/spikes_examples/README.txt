.. _spikes_examples:

Spike Detection
---------------




