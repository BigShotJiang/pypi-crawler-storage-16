# -*- coding: utf-8 -*-

"""Top-level package for ipfx."""
from ._version import __version__

__author__ = """Allen Institute for Brain Science"""
