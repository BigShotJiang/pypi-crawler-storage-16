
class FeatureError(Exception):
    """Generic Python-exception-derived object raised by feature 
    detection functions.
    """
