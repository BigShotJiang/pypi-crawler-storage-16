"""
This package allows to create NeuroDataWithoutBorders v2 files from ABF and DAT files.

See Readme.md for more information.
"""
