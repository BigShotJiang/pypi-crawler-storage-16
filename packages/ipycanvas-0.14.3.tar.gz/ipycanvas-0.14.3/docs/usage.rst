Usage
=====

.. toctree::
    :caption: Usage
    :maxdepth: 2

    basic_usage
    drawing_shapes
    drawing_paths
    styles_and_colors
    rough_canvas
    drawing_text
    drawing_images
    retrieve_images
    animations
    canvas_state
    transformations
    events
    advanced
