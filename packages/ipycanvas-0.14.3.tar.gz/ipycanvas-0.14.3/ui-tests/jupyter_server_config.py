from jupyterlab.galata import configure_jupyter_server

configure_jupyter_server(c)  # noqa F821
# Uncomment to set server log level to debug level
# c.ServerApp.log_level = "DEBUG"
