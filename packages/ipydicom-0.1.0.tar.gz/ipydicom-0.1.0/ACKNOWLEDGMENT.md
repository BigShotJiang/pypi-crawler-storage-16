# Acknowledgment

Sample DICOM + SEG data included for testing:

- **QIICR/dcmqi** samples (Apache-2.0):
  - `samples/dcmqi_ct3slice/` (CT slices + `partial_overlaps.dcm` DICOM-SEG)

Data sourced from https://github.com/QIICR/dcmqi (Apache-2.0).
