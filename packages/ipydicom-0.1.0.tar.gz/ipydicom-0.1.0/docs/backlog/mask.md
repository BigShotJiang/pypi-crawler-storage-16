# Mask & Labelmap Overlay Backlog

## Feature Request
Add first-class support for segmentation masks/labelmaps in the MPR and 3D viewers with per-label styling, quick navigation, and standard loaders.

## Use Cases
- Visualize precomputed segmentations (lesions, organs) alongside clinical images for multimodal review.
- Load masks from common formats (NumPy `.npy`, NIfTI/NRRD, DICOM-SEG) without manual shape handling.
- Work with multi-label maps: distinct colors/alphas per structure, quick show/hide, and “jump to label” to land on a slice that intersects the label.
- Keep the UI responsive in notebook environments (remote servers, limited resources); avoid heavy inference in the viewer loop.

## Requirements (proposed)
1) **Loading**
   - Single binary masks and multi-label maps (integer labels).
   - Helpers to read `.npy` (already) and add NIfTI/NRRD/DICOM-SEG loaders.
   - Shape validation against the current volume; clear error messaging.
2) **Styling**
   - Per-label color/alpha; sensible defaults with optional user overrides (dict[label_id] -> {name, color, alpha}).
   - Persistence of label metadata (name, source/model, date) for provenance.
3) **Interaction**
   - Add/show/hide/remove/clear overlays by id/label.
   - “Jump to label” (centroid or bounding box) so planes intersect the structure immediately.
   - Keep 2D/3D in sync; optional 3D mask rendering (isosurface) behind a toggle.
4) **Performance**
   - Use uint8/uint16 labelmaps; keep overlay updates aligned with the existing low-res/high-res display logic.
   - Avoid running segmentation inference inside the viewer; masks are precomputed elsewhere.

## Implementation Plan (library-level)
1) **Data model**
   - Extend overlays to accept multi-label maps: normalize to uint16, store label metadata (name, color, alpha).
   - Keep backward compatibility for single-mask add/set/clear.
2) **Loading helpers**
   - Add loader functions: `load_mask_npy` (exists), plus `load_mask_nifti(path)`, `load_mask_nrrd(path)`, `load_mask_dicom_seg(path)` (use pydicom + pydicom-seg or highdicom to parse SEG frames and metadata).
   - Validate shape vs current volume; raise clear errors.
3) **API surface**
   - Viewer/Controller: `add_overlay(...)`, `remove_overlay(id)`, `clear_overlays()`, `set_overlay(...)` (single), `new_empty_mask()`.
   - New: `add_labelmap(labelmap, label_styles: dict, jump_to_label=None)`; `toggle_label(label_id, visible: bool)`; `jump_to_label(label_id, mode="centroid|bbox_center")`.
4) **Rendering**
   - MPR: per-label compositing by rendering one artist per label present on the slice, using per-label color/alpha; cache artists; respect low-res during drag.
   - 3D: optional isosurface/volume rendering for selected labels (downsampled), enabled via toggle to avoid default perf hit.
5) **Sync & navigation**
   - Reuse existing crosshair/3D sync; integrate jump-to-label to move the locator and planes.
6) **Docs / examples**
   - Add notebook snippets showing: loading labelmaps, styling, toggling labels, jumping to labels, enabling 3D mask rendering.

## Sample data (for testing)
- Added a small open dataset to `samples/dcmqi_ct3slice/`:
  - `01.dcm`, `02.dcm`, `03.dcm`: CT slices (3-slice series).
  - `partial_overlaps.dcm`: DICOM-SEG object with overlapping segments.
- Next: add a loader example in the notebook to read this DICOM-SEG and overlay segments with distinct colors/alphas.

## Non-Goals
- Running heavy segmentation models inside the viewer loop; inference should remain external and feed masks into the viewer.
