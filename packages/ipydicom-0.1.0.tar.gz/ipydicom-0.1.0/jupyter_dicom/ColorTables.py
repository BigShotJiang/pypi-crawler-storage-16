from dataclasses import dataclass
from typing import List, Dict, Tuple, Optional
import numpy as np

@dataclass
class WindowLevel:
    """Window/Level preset for DICOM display"""
    name: str
    window: float  # Window width
    level: float   # Window center
    description: str

@dataclass
class ColorPoint:
    """Color point in a color map"""
    position: float  # Position in range [0, 1]
    r: float        # Red component [0, 1]
    g: float        # Green component [0, 1]
    b: float        # Blue component [0, 1]
    a: float        # Alpha (opacity) [0, 1]

class ColorMap:
    """Color map for DICOM visualization"""
    
    def __init__(self, name: str, points: List[ColorPoint], is_discrete: bool = False):
        """Initialize color map
        
        Args:
            name: Color map name
            points: List of color points defining the map
            is_discrete: Whether the map is discrete or continuous
        """
        self.name = name
        self.points = sorted(points, key=lambda p: p.position)
        self.is_discrete = is_discrete
        
    def get_color(self, value: float) -> Tuple[float, float, float, float]:
        """Get interpolated color for a value
        
        Args:
            value: Value in range [0, 1]
            
        Returns:
            Tuple of (r, g, b, a) values
        """
        if value <= 0.0:
            return (self.points[0].r, self.points[0].g, 
                   self.points[0].b, self.points[0].a)
            
        if value >= 1.0:
            return (self.points[-1].r, self.points[-1].g, 
                   self.points[-1].b, self.points[-1].a)
            
        # Find surrounding points
        for i in range(len(self.points) - 1):
            if self.points[i].position <= value <= self.points[i + 1].position:
                if self.is_discrete:
                    return (self.points[i].r, self.points[i].g, 
                           self.points[i].b, self.points[i].a)
                    
                # Linear interpolation
                t = ((value - self.points[i].position) / 
                     (self.points[i + 1].position - self.points[i].position))
                
                return (
                    self.points[i].r + t * (self.points[i + 1].r - self.points[i].r),
                    self.points[i].g + t * (self.points[i + 1].g - self.points[i].g),
                    self.points[i].b + t * (self.points[i + 1].b - self.points[i].b),
                    self.points[i].a + t * (self.points[i + 1].a - self.points[i].a)
                )
                
        return (self.points[-1].r, self.points[-1].g, 
               self.points[-1].b, self.points[-1].a)
        
    def apply_to_array(self, array: np.ndarray) -> np.ndarray:
        """Apply color map to array
        
        Args:
            array: Input array (assumed to be normalized to [0, 1])
            
        Returns:
            RGBA array with shape [..., 4]
        """
        # Reshape array to 1D
        original_shape = array.shape
        flattened = array.ravel()
        
        # Initialize output array
        result = np.zeros((len(flattened), 4), dtype=np.float32)
        
        # Apply color map
        for i, value in enumerate(flattened):
            result[i] = self.get_color(value)
            
        # Reshape back to original dimensions
        return result.reshape((*original_shape, 4))

class ColorTables:
    """Manages color maps and window/level presets for DICOM visualization"""
    
    def __init__(self):
        """Initialize color tables"""
        self.color_maps: Dict[str, ColorMap] = {}
        self.window_presets: Dict[str, Dict[str, WindowLevel]] = {}
        
        self._initialize_color_maps()
        self._initialize_window_presets()
        
    def _initialize_color_maps(self):
        """Initialize default color maps"""
        # Grayscale
        self.color_maps['grayscale'] = ColorMap(
            'Grayscale',
            [
                ColorPoint(0.0, 0.0, 0.0, 0.0, 1.0),
                ColorPoint(1.0, 1.0, 1.0, 1.0, 1.0)
            ]
        )
        
        # Hot Iron
        self.color_maps['hot_iron'] = ColorMap(
            'Hot Iron',
            [
                ColorPoint(0.0, 0.0, 0.0, 0.0, 1.0),
                ColorPoint(0.2, 0.5, 0.0, 0.0, 1.0),
                ColorPoint(0.4, 1.0, 0.0, 0.0, 1.0),
                ColorPoint(0.6, 1.0, 0.5, 0.0, 1.0),
                ColorPoint(0.8, 1.0, 0.8, 0.3, 1.0),
                ColorPoint(1.0, 1.0, 1.0, 1.0, 1.0)
            ]
        )
        
        # PET
        self.color_maps['pet'] = ColorMap(
            'PET',
            [
                ColorPoint(0.0, 0.0, 0.0, 0.0, 1.0),
                ColorPoint(0.2, 0.0, 0.0, 0.8, 1.0),
                ColorPoint(0.4, 0.0, 0.8, 0.0, 1.0),
                ColorPoint(0.6, 0.8, 0.8, 0.0, 1.0),
                ColorPoint(0.8, 1.0, 0.4, 0.0, 1.0),
                ColorPoint(1.0, 1.0, 1.0, 1.0, 1.0)
            ]
        )
        
    def _initialize_window_presets(self):
        """Initialize window/level presets for different modalities"""
        # CT presets
        self.window_presets['CT'] = {
            'brain': WindowLevel('Brain', 80, 40, 
                               'Brain tissue visualization'),
            'bone': WindowLevel('Bone', 2000, 500, 
                              'Bone structures'),
            'soft_tissue': WindowLevel('Soft Tissue', 400, 40, 
                                     'General soft tissue'),
            'lung': WindowLevel('Lung', 1500, -600, 
                              'Lung tissue'),
            'mediastinum': WindowLevel('Mediastinum', 350, 50, 
                                     'Mediastinal structures')
        }
        
        # MR presets
        self.window_presets['MR'] = {
            't1': WindowLevel('T1', 1200, 600, 
                            'T1-weighted visualization'),
            't2': WindowLevel('T2', 1500, 750, 
                            'T2-weighted visualization'),
            'flair': WindowLevel('FLAIR', 1600, 950, 
                               'FLAIR sequence')
        }
        
    def get_color_map(self, name: str) -> Optional[ColorMap]:
        """Get color map by name
        
        Args:
            name: Color map name
            
        Returns:
            ColorMap object or None if not found
        """
        return self.color_maps.get(name)
    
    def get_window_preset(self, modality: str, name: str) -> Optional[WindowLevel]:
        """Get window/level preset
        
        Args:
            modality: Imaging modality (e.g., 'CT', 'MR')
            name: Preset name
            
        Returns:
            WindowLevel object or None if not found
        """
        modality_presets = self.window_presets.get(modality, {})
        return modality_presets.get(name)
    
    def apply_window_level(self, array: np.ndarray, 
                          window: float, level: float) -> np.ndarray:
        """Apply window/level to array
        
        Args:
            array: Input array
            window: Window width
            level: Window center
            
        Returns:
            Windowed array normalized to [0, 1]
        """
        low = level - window/2
        high = level + window/2
        return np.clip((array - low) / (high - low), 0, 1)
    
    def apply_color_map(self, array: np.ndarray, 
                       color_map_name: str = 'grayscale') -> np.ndarray:
        """Apply color map to array
        
        Args:
            array: Input array (assumed normalized to [0, 1])
            color_map_name: Name of color map to apply
            
        Returns:
            RGBA array
        """
        color_map = self.get_color_map(color_map_name)
        if color_map is None:
            color_map = self.color_maps['grayscale']
            
        return color_map.apply_to_array(array)
    
    def process_image(self, array: np.ndarray, modality: str, 
                     preset_name: str, color_map_name: str = 'grayscale') -> np.ndarray:
        """Process image with window/level and color map
        
        Args:
            array: Input array
            modality: Imaging modality
            preset_name: Window/level preset name
            color_map_name: Color map name
            
        Returns:
            Processed RGBA array
        """
        # Get window/level preset
        preset = self.get_window_preset(modality, preset_name)
        if preset is None:
            # Default to array min/max if no preset found
            win = np.max(array) - np.min(array)
            lev = (np.max(array) + np.min(array)) / 2
        else:
            win = preset.window
            lev = preset.level
            
        # Apply window/level
        windowed = self.apply_window_level(array, win, lev)
        
        # Apply color map
        return self.apply_color_map(windowed, color_map_name)