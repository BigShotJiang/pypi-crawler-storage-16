import os
import re
import pydicom
import numpy as np
import cv2
from dataclasses import dataclass
from typing import List, Dict, Tuple, Optional, Any
from threading import Lock
import threading
from .ImageProcessor import ImageProcessor

import logging
# Configure the logging system
logging.basicConfig(
    level=logging.INFO,  # Set the minimum level of messages to log
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),         # Log to the console
        logging.FileHandler("app.log")     # Log to a file named "app.log"
    ]
)

logger = logging.getLogger(__name__)


@dataclass
class DICOMMetadata:
    filename: str
    slice_location: float
    instance_number: int
    formatted_metadata: str
    spacing: Tuple[float, float]
    thickness: float
    raw_metadata: Any

class MetadataFormatter:
    """Helper class to format DICOM metadata for display"""
    
    @staticmethod
    def format_dicom(ds: pydicom.dataset.FileDataset) -> str:
        """Format DICOM metadata into HTML grid layout"""
        pattern = re.compile(r'^\(([^)]+)\)\s+(.*)\s+([A-Z]{2})(?=\s*:\s)(?:\s*:\s)(.*)$')
        sec_pattern = re.compile(r'^\(([^)]+)\)\s+(.*?)\s+(\d+\s+item\(s\))\s+(----)$')
        parts = []
        
        for line in str(ds).split("\n"):
            line = line.strip()
            if "--------" in line:
                parts.append("<div></div><div></div><div></div><div></div>")
            else:
                match = pattern.match(line)
                if match is None:
                    match = sec_pattern.match(line)
                    if match is None:
                        continue
                        
                if len(match.groups()) == 4:
                    parts.append(f"<div>{match.group(1)}</div><div>{match.group(2)}</div><div>{match.group(3)}</div><div>{match.group(4)}</div>")
                else:
                    parts.append(f"<div>{match.group(1)}</div><div>{match.group(2)}</div><div></div><div></div>")
                    
        return "<div class='table-grid'>" + ''.join(parts) + "</div>"

class SliceCache:
    """Cache for storing and managing DICOM slices"""
    
    def __init__(self, max_size: int = 50):
        self.cache = {}
        self.max_size = max_size
        self._lock = Lock()
        
    def get_slice(self, vol: np.ndarray, axis: str, index: int, low_res: bool = False) -> np.ndarray:
        """Get a slice from the cache or compute it if not present"""
        key = (axis, index, low_res)
        with self._lock:
            if key not in self.cache:
                if len(self.cache) >= self.max_size:
                    self.cache.clear()
                    
                if axis == 'axial':
                    slice_data = vol[index, :, :]
                elif axis == 'coronal':
                    slice_data = vol[:, index, :]
                else:  # sagittal
                    slice_data = vol[:, :, index]
                    
                if low_res and (axis == 'coronal' or axis == 'sagittal'):
                    slice_data = slice_data[::2, ::2]
                    
                self.cache[key] = slice_data
                
            return self.cache[key]

    def clear(self):
        """Clear the cache"""
        with self._lock:
            self.cache.clear()


@dataclass
class Normalization:
    ORIGINAL = "original"
    PERCENTILE = "percentile"
    HARMONIZED = "harmonized"
    
class DICOMHandler:
    """Main class for handling DICOM series loading and management"""
    
    def __init__(self):
        self.slice_cache = SliceCache()
        self.metadata_formatter = MetadataFormatter()
        self.image_processor = ImageProcessor()

        # Initialize state
        self.current_normalization = Normalization.ORIGINAL
        self.processed_volumes = {
            Normalization.ORIGINAL: None,
            Normalization.PERCENTILE: None,
            Normalization.HARMONIZED: None
        }
        
        self.volume: Optional[np.ndarray] = None
        self.volume_original: Optional[np.ndarray] = None
        self.metadata_list: List[DICOMMetadata] = []
        self.dimensions: Tuple[int, int, int] = (0, 0, 0)  # z, y, x
        self.spacing: Tuple[float, float, float] = (1.0, 1.0, 1.0)  # z, y, x
        
    def _load_files(self, files: List[str]) -> Tuple[np.ndarray, Tuple[int, int, int]]:
        """Load a list of DICOM file paths into a volume."""
        slices = []
        for filepath in files:
            ds = pydicom.dcmread(filepath)

            # Skip segmentation/storage objects; only load image slices here
            sop_uid = getattr(ds, "SOPClassUID", None)
            sop_name = getattr(sop_uid, "name", "") if sop_uid is not None else ""
            if "Segmentation Storage" in sop_name:
                logger.debug("Skipping DICOM-SEG object during image load: %s", filepath)
                continue
            
            position = getattr(ds, 'ImagePositionPatient', None)
            if position is not None:
                slice_location = float(position[2])  # Z position
            else:
                slice_location = getattr(ds, 'SliceLocation', 
                                       float(getattr(ds, 'InstanceNumber', 0)))
            
            if hasattr(ds, 'PixelSpacing'):
                pixel_spacing = [float(x) for x in ds.PixelSpacing]
            else:
                pixel_spacing = [1.0, 1.0]
                
            if hasattr(ds, 'SliceThickness'):
                slice_thickness = float(ds.SliceThickness)
            else:
                slice_thickness = 1.0
                
            metadata = DICOMMetadata(
                filename=os.path.basename(filepath),
                slice_location=slice_location,
                instance_number=getattr(ds, 'InstanceNumber', 0),
                formatted_metadata=self.metadata_formatter.format_dicom(ds),
                spacing=tuple(pixel_spacing),
                thickness=slice_thickness,
                raw_metadata=ds
            )
            
            slices.append((slice_location, ds.pixel_array, metadata))

        if not slices:
            raise ValueError("No DICOM files found.")
        
        # Sort slices by position
        slices.sort(key=lambda x: x[0] if x[0] is not None else 1e9)
        # we probably want to reuse the original values or do a different normalization
        # pixel_arrays = [s[1] for s in slices]
        pixel_arrays = [self.image_processor.normalize_array(s[1]) for s in slices]
        self.volume_original = np.ascontiguousarray(np.stack(pixel_arrays, axis=0))           
        # Calculate actual slice spacing from positions
        if len(slices) > 1:
            slice_spacing = abs(slices[1][0] - slices[0][0])
        else:
            slice_spacing = slices[0][2].thickness
            
        # Stack arrays and store metadata
        self.metadata_list = [s[2] for s in slices]
     
        self.volume = self.volume_original
        self.dimensions = self.volume.shape
        
        # Store spacing (z, y, x)
        pixel_spacing = self.metadata_list[0].spacing  # (y, x)
        self.spacing = (slice_spacing, pixel_spacing[0], pixel_spacing[1])
        
        # Clear cache
        self.slice_cache.clear()

        # Create normalized volumes
        self._process_volumes_async()
        
        return self.volume, self.dimensions

    def load_series(self, path: str) -> Tuple[np.ndarray, Tuple[int, int, int]]:
        """Load a DICOM series from a folder or a single DICOM file."""
        if not os.path.exists(path):
            raise ValueError(f"Path not found: {path}")

        if os.path.isdir(path):
            dcm_files = [os.path.join(path, f) for f in os.listdir(path) if f.lower().endswith('.dcm')]
            if not dcm_files:
                raise ValueError("No DICOM files found in folder")
            return self._load_files(dcm_files)

        # Single file
        if not path.lower().endswith('.dcm'):
            raise ValueError("Provided file is not a DICOM (.dcm)")
        return self._load_files([path])

    def reset_volume(self):
        """
        Reset to volume_original and empty the cache
        """
        self.set_volume(self.volume_original)

    def set_volume(self, vol):
        """
        Set volume to any new volume, then empty the cache
        """
        self.volume = vol
        self.slice_cache.clear()
        
    def get_metadata(self, slice_index: int) -> DICOMMetadata:
        """Get metadata for a specific slice"""
        if not self.metadata_list:
            raise ValueError("No metadata available. Load DICOM series first.")
        return self.metadata_list[slice_index]
    
    def get_slice(self, axis: str, index: int, low_res: bool = False) -> np.ndarray:
        """Get a slice from the volume using the cache"""
        if self.volume is None:
            raise ValueError("No volume loaded. Load DICOM series first.")
        return self.slice_cache.get_slice(self.volume, axis, index, low_res)

    def load_segmentation_labelmap(self, seg_path: str) -> np.ndarray:
        """
        Load a DICOM-SEG file and return a labelmap aligned to the current volume.
        Follows a simple strategy:
        - If pixel_array shape is (frames, y, x): map frames to z slices in order.
        - If pixel_array shape is (segments, frames, y, x): assign label IDs 1..N.
        """
        if self.volume is None:
            raise ValueError("Load a DICOM series before loading a segmentation.")
        ds = pydicom.dcmread(seg_path)
        arr = ds.pixel_array
        dims = self.dimensions  # (z, y, x)

        def fit_frames(frame_arr):
            frames = frame_arr.shape[0]
            labelmap = np.zeros(dims, dtype=np.uint8)
            use = min(frames, dims[0])
            labelmap[:use] = (frame_arr[:use] > 0).astype(np.uint8)
            return labelmap

        if arr.ndim == 3:  # (frames, y, x)
            return fit_frames(arr)

        if arr.ndim == 4:  # (segments, frames, y, x)
            segs, frames, y, x = arr.shape
            labelmap = np.zeros(dims, dtype=np.uint16)
            use = min(frames, dims[0])
            for i in range(segs):
                frame_block = arr[i, :use]
                labelmap[:use][frame_block > 0] = i + 1
            return labelmap

        raise ValueError(f"Unsupported SEG pixel_array shape {arr.shape}")
    
    def get_spacing(self) -> Tuple[float, float, float]:
        """Get volume spacing (z, y, x)"""
        if self.volume is None:
            raise ValueError("No volume loaded. Load DICOM series first.")
        return self.spacing
    
    def clear_cache(self):
        """Clear the slice cache"""
        self.slice_cache.clear()

    def set_normalization(self, mode):
        if mode not in self.processed_volumes:
            logger.info("WARNING : trying to use an unknown normalization (", mode , ")")
        if self.current_normalization == mode:
            logger.info("NOTICE : won't change normalization as trying to recompute the same")

        self.current_normalization = mode
        self.set_volume(self.processed_volumes[mode])

    def _process_volumes_async(self):
        """Process volumes in background thread"""
        def process():
            logger.debug("Starting async processing...")
            try:
                # Process percentile volume
                self.processed_volumes[Normalization.PERCENTILE] = \
                    self.image_processor.process_volume(self.volume_original, "percentile")
                
                # Process harmonized volume
                self.processed_volumes[Normalization.HARMONIZED] = \
                    self.image_processor.process_volume(self.volume_original, "harmonize")

                self.processed_volumes[Normalization.ORIGINAL] = self.volume_original
                
            except Exception as e:
                logger.error(f"Error processing volumes: {e}")

        threading.Thread(target=process, daemon=True).start()
