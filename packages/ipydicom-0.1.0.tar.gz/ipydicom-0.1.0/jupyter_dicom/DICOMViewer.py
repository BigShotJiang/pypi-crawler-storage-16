from .ViewerController import ViewerController
from jupyter_popup import create_popup
from IPython.display import display, HTML

# Enable required extensions
import panel as pn
pn.extension('vtk', comms='ipywidgets')

class DICOMViewer:
    """Main DICOM Viewer class that provides a simple interface to the viewer system"""
    
    def __init__(self, dicom_path: str = None):
        """Initialize the DICOM viewer"""
        # Set up display environment
        display(HTML("<style>.container { width:100% !important; } "
                    ".jupyter-matplotlib-header { display: none !important; } "
                    ".table-grid { display: grid; grid-template-columns: auto 35% 60px 1fr; "
                    "gap: 0.5rem; width: 100%; } "
                    ".vtk-content { width: 100%; height: 100%; }</style>"))
                    
        # Initialize the controller after display setup
        self.controller = ViewerController()
        if dicom_path:
            self.controller.load_path(dicom_path, show_outputs=False)
        
    def display(self):
        """Display the viewer interface"""
        # Display through the controller
        self.controller.display()
        
    @staticmethod
    def version():
        """Return the viewer version"""
        return "1.0.0"
    
    def help(self):
        """Display help information using jupyter-popup"""
        help_text = """
        <div style='font-family: sans-serif; padding: 10px;'>
            <h2 style='color: #2c3e50;'>DICOM Viewer Help</h2>
            
            <h3 style='color: #34495e;'>1. Controls</h3>
            <ul>
                <li><strong>File Chooser:</strong> Select a DICOM folder</li>
                <li><strong>View Modes:</strong>
                    <ul>
                        <li><i class="fa fa-eye"></i> Original: Display original values</li>
                        <li><i class="fa fa-adjust"></i> Normalized: Display normalized values (1%-99%)</li>
                        <li><i class="fa fa-magic"></i> Harmonized: Display harmonized values</li>
                    </ul>
                </li>
                <li><strong>3D View:</strong> Open 3D volume rendering</li>
                <li><strong>Metadata:</strong> View DICOM metadata</li>
            </ul>
            
            <h3 style='color: #34495e;'>2. Navigation</h3>
            <ul>
                <li>Click on any view to set crosshair position</li>
                <li>Use sliders to navigate through slices</li>
                <li>In 3D view, use mouse to:
                    <ul>
                        <li>Left click + drag: Rotate</li>
                        <li>Right click + drag: Zoom</li>
                        <li>Middle click + drag: Pan</li>
                    </ul>
                </li>
            </ul>
            
            <h3 style='color: #34495e;'>3. Features</h3>
            <ul>
                <li>Multi-planar reconstruction (MPR)</li>
                <li>3D volume rendering</li>
                <li>DICOM metadata viewing</li>
                <li>Image processing options</li>
            </ul>
        </div>
        """
        
        create_popup(help_text, "DICOM Viewer Help")

    # Convenience passthroughs
    def set_overlay(self, mask_volume, *, alpha: float = 0.35, color=(1.0, 0.0, 0.0), jump_to: bool = False):
        """Attach a mask overlay to the MPR views (volume must be loaded first)."""
        return self.controller.set_overlay(mask_volume, alpha=alpha, color=color, jump_to=jump_to)

    def add_overlay(self, mask_volume, *, alpha: float = 0.35, color=(1.0, 0.0, 0.0),
                    overlay_id: str = None, jump_to: bool = False):
        """Add a mask overlay (per-overlay color/alpha) and optionally jump to its centroid."""
        return self.controller.add_overlay(mask_volume, alpha=alpha, color=color, overlay_id=overlay_id, jump_to=jump_to)

    def clear_overlay(self):
        """Remove any active mask overlay from the MPR views."""
        self.controller.clear_overlay()

    def remove_overlay(self, overlay_id: str):
        """Remove a specific overlay by id."""
        self.controller.remove_overlay(overlay_id)

    def jump_to(self, x: int, y: int, z: int):
        """Programmatically move to a voxel index and sync 2D/3D views."""
        self.controller.jump_to(x, y, z)

    def reset_view(self):
        """Reset crosshair to volume center and refresh 2D/3D views."""
        self.controller.reset_view()

    def new_empty_mask(self, dtype=None):
        """Return a zero mask shaped like the loaded volume."""
        return self.controller.new_empty_mask(dtype=dtype or None)

    def load_mask_npy(self, path: str, dtype=None):
        """Load a .npy mask and validate shape vs current volume."""
        return self.controller.load_mask_npy(path, dtype=dtype or None)

    def load_mask_dicom_seg(self, path: str):
        """Load a DICOM-SEG file into a labelmap aligned to the current volume."""
        return self.controller.load_mask_dicom_seg(path)
