from numba import njit
import numpy as np
import cv2
from typing import Optional

class ImageProcessor:
    """Handles all image processing operations"""

    @staticmethod
    @njit
    def normalize_array(array: np.ndarray) -> np.ndarray:
        """Basic min-max normalization to 8-bit"""
        min_val = np.min(array)
        max_val = np.max(array)
        if max_val == min_val:
            return np.zeros_like(array, dtype=np.uint8)
        normalized = 255.0 * (array - min_val) / (max_val - min_val)
        return normalized.astype(np.uint8)

    @staticmethod
    @njit
    def normalize_percentile(array: np.ndarray, p_low: float = 1, p_high: float = 99) -> np.ndarray:
        """Normalize array using percentile values"""
        flat = array.ravel()
        sorted_flat = np.sort(flat)
        n = len(sorted_flat)
        p1_idx = int(p_low / 100 * n)
        p99_idx = int(p_high / 100 * n)
        vmin = sorted_flat[p1_idx]
        vmax = sorted_flat[p99_idx]
        normalized = np.clip((array - vmin) / (vmax - vmin) * 255.0, 0, 255)
        return normalized.astype(np.uint8)

    @staticmethod
    def harmonize_histogram(vol: np.ndarray) -> np.ndarray:
        """Apply CLAHE harmonization to volume"""
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
        vol_out = np.zeros_like(vol, dtype=np.uint8)
        for z in range(vol.shape[0]):
            vol_out[z] = clahe.apply(vol[z].astype(np.uint8))
        return vol_out

    @classmethod
    def process_volume(cls, volume: np.ndarray, 
                      mode: str = "normalize", 
                      **kwargs) -> np.ndarray:
        """Process entire volume based on specified mode"""
        if mode == "normalize":
            return cls.normalize_array(volume)
        elif mode == "percentile":
            p_low = kwargs.get('p_low', 1)
            p_high = kwargs.get('p_high', 99)
            return cls.normalize_percentile(volume, p_low, p_high)
        elif mode == "harmonize":
            # First normalize then harmonize
            normalized = cls.normalize_array(volume)
            return cls.harmonize_histogram(normalized)
        else:
            raise ValueError(f"Unknown processing mode: {mode}")