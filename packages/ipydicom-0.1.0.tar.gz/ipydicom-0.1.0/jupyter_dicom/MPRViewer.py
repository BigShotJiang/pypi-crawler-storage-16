import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import numpy as np
from typing import Tuple, List, Optional, Callable, Dict
from dataclasses import dataclass
import threading
from time import time
import ipywidgets as widgets
from IPython.display import display

@dataclass
class ViewerState:
    """Stores the current state of the MPR viewer"""
    cur_x: int = 0
    cur_y: int = 0
    cur_z: int = 0
    is_sliding: bool = False
    last_update_time: float = 0
    MIN_UPDATE_INTERVAL: float = 0.05
    update_timer: Optional[threading.Timer] = None

@dataclass
class Overlay:
    """Represents a single overlay mask with its rendering artists."""
    id: str
    volume: np.ndarray  # binary/boolean mask, shape matches volume
    color: Tuple[float, float, float]
    alpha: float
    artists: Dict[str, Optional[object]]  # populated lazily

class MPRViewer:
    """Main class for MPR visualization"""
    def __init__(self, *, dicom_handler, viewer_state):
        """Initialize MPR Viewer"""
        self.dicom_handler = dicom_handler
        self.state = viewer_state
        self.fig = None
        self.ax_axial = None
        self.ax_coronal = None
        self.ax_sagittal = None
        self.img_axial = None
        self.img_coronal = None
        self.img_sagittal = None
        self.lines_axial = []
        self.lines_coronal = []
        self.lines_sagittal = []
        self.current_volume = None
        self.overlays: List[Overlay] = []
        self.spacing = (1.0, 1.0, 1.0)  # z, y, x
        self.dimensions = (0, 0, 0)  # z, y, x
        self.state_listeners: List[Callable[[ViewerState], None]] = []
        self._suspend_slider_events = False
        self._slider_handlers_attached = False
        self._setup_ui()

    def _setup_ui(self):
        """Setup UI components"""
        plt.style.use("dark_background")
        self.sliders = {
            'axial': widgets.FloatSlider(description="Axial: ", continuous_update=True),
            'coronal': widgets.FloatSlider(description="Coronal: ", continuous_update=True),
            'sagittal': widgets.FloatSlider(description="Sagittal: ", continuous_update=True)
        }
        
        for slider in self.sliders.values():
            slider._dom_classes = ['custom-slider']
            slider.observe(self._on_slider_mousedown, names='_dragging')
            slider.observe(self._on_slider_mouseup, names='_drag_release')
        self._attach_slider_value_handlers()

    def _attach_slider_value_handlers(self):
        """Attach value change handlers once."""
        if self._slider_handlers_attached:
            return
        for slider in self.sliders.values():
            slider.observe(self._on_slider_value_change, names='value')
        self._slider_handlers_attached = True

    def initialize_figure(self):
        """Initialize the matplotlib figure and axes"""
        if self.fig is not None:
            plt.close(self.fig)
            
        self.fig = plt.figure(figsize=(14, 6))
        self.fig.canvas.toolbar_visible = False
        self.fig.canvas.header_visible = False
        self.fig.canvas.resizable = False
        
        gs = self.fig.add_gridspec(1, 3)
        self.ax_axial = self.fig.add_subplot(gs[0, 0])
        self.ax_coronal = self.fig.add_subplot(gs[0, 1])
        self.ax_sagittal = self.fig.add_subplot(gs[0, 2])
        
        for ax in (self.ax_axial, self.ax_coronal, self.ax_sagittal):
            ax.set_box_aspect(1)
            ax.set_xticks([])
            ax.set_yticks([])
            
        self.fig.subplots_adjust(left=0.01, right=0.99, top=1, bottom=0, wspace=0.05, hspace=0.05)
        self.fig.canvas.mpl_connect("button_press_event", self._on_click)
        
        if self.current_volume is not None:
            self.initialize_images(self.current_volume)
            self.initialize_crosshairs()

    def initialize_images(self, vol):
        """Initialize image displays"""
        axial_extent = [0, self.dimensions[2] * self.spacing[2], 
                       0, self.dimensions[1] * self.spacing[1]]
        coronal_extent = [0, self.dimensions[2] * self.spacing[2], 
                         0, self.dimensions[0] * self.spacing[0]]
        sagittal_extent = [0, self.dimensions[1] * self.spacing[1], 
                          0, self.dimensions[0] * self.spacing[0]]
        
        self.img_axial = self.ax_axial.imshow(vol[self.state.cur_z], cmap='gray', 
                                             origin='lower', extent=axial_extent, vmin=0, vmax=255, interpolation="nearest")
        self.img_coronal = self.ax_coronal.imshow(vol[:, self.state.cur_y], cmap='gray', 
                                                 origin='lower', extent=coronal_extent, vmin=0, vmax=255, interpolation="nearest")
        self.img_sagittal = self.ax_sagittal.imshow(vol[:, :, self.state.cur_x], cmap='gray', 
                                                   origin='lower', extent=sagittal_extent, vmin=0, vmax=255, interpolation="nearest")

        # Cache extents to reuse for overlays
        self._axial_extent = axial_extent
        self._coronal_extent = coronal_extent
        self._sagittal_extent = sagittal_extent

    def initialize_crosshairs(self):
        """Initialize crosshair lines"""
        self.lines_axial = [
            self.ax_axial.axvline(self.state.cur_x * self.spacing[2], color='g', lw=1),
            self.ax_axial.axhline(self.state.cur_y * self.spacing[1], color='r', lw=1)
        ]
        
        self.lines_coronal = [
            self.ax_coronal.axvline(self.state.cur_x * self.spacing[2], color='g', lw=1),
            self.ax_coronal.axhline(self.state.cur_z * self.spacing[0], color='b', lw=1)
        ]
        
        self.lines_sagittal = [
            self.ax_sagittal.axvline(self.state.cur_y * self.spacing[1], color='r', lw=1),
            self.ax_sagittal.axhline(self.state.cur_z * self.spacing[0], color='b', lw=1)
        ]

    def _initialize_overlay_images(self):
        """Create overlay image artists if an overlay volume is present"""
        if self.overlay_volume is None:
            return

        cmap = LinearSegmentedColormap.from_list(
            "overlay", [(0, 0, 0, 0), (*self.overlay_color, 1.0)]
        )

        # Initialize with actual slices to establish sane clim
        axial_slice = self._get_overlay_slice("axial", self.state.cur_z, False)
        coronal_slice = self._get_overlay_slice("coronal", self.state.cur_y, False)
        sagittal_slice = self._get_overlay_slice("sagittal", self.state.cur_x, False)

        common_kwargs = dict(cmap=cmap, alpha=self.overlay_alpha, vmin=0, vmax=1, interpolation="nearest")

        self.overlay_axial = self.ax_axial.imshow(
            axial_slice, origin="lower", extent=self._axial_extent, **common_kwargs
        )
        self.overlay_coronal = self.ax_coronal.imshow(
            coronal_slice, origin="lower", extent=self._coronal_extent, **common_kwargs
        )
        self.overlay_sagittal = self.ax_sagittal.imshow(
            sagittal_slice, origin="lower", extent=self._sagittal_extent, **common_kwargs
        )

    def set_volume(self, volume: np.ndarray, spacing: Tuple[float, float, float]):
        """Set the volume data and initialize views"""
        self.current_volume = volume
        self.spacing = spacing
        self.dimensions = volume.shape
        # Drop overlays that don't match the new volume shape
        self.overlays = [ov for ov in self.overlays if ov.volume.shape == self.dimensions]
        
        if self.state.cur_z == 0 and self.state.cur_y == 0 and self.state.cur_x == 0:
            self.state.cur_z = self.dimensions[0] // 2
            self.state.cur_y = self.dimensions[1] // 2
            self.state.cur_x = self.dimensions[2] // 2
        
        self.dicom_handler.clear_cache()
        self.initialize_figure()
        self._setup_sliders()
        plt.show()

    def _update_display(self, force_high_res: bool = False, force_update: bool = False):
        """Update MPR display"""
        current_time = time()
        if not force_update and current_time - self.state.last_update_time < self.state.MIN_UPDATE_INTERVAL:
            return
            
        self.state.last_update_time = current_time
        
        vol = self.current_volume
        if vol is None:
            return
            
        use_low_res = self.state.is_sliding and not force_high_res
        
        self.img_axial.set_array(self.dicom_handler.get_slice('axial', self.state.cur_z, False))
        self.img_coronal.set_array(self.dicom_handler.get_slice('coronal', self.state.cur_y, use_low_res))
        self.img_sagittal.set_array(self.dicom_handler.get_slice('sagittal', self.state.cur_x, use_low_res))
        
        self._update_crosshairs()
        self._update_overlays(use_low_res)
        
        self.ax_axial.set_title(f"Axial ({self.state.cur_z})", fontsize=10)
        self.ax_coronal.set_title(f"Coronal ({self.state.cur_y})", fontsize=10)
        self.ax_sagittal.set_title(f"Sagittal ({self.state.cur_x})", fontsize=10)
        
        self._update_sliders()
        self.fig.canvas.draw_idle()
        self._notify_state_change()

    def _update_crosshairs(self):
        """Update crosshair positions"""
        self.lines_axial[0].set_xdata([self.state.cur_x * self.spacing[2]] * 2)
        self.lines_axial[1].set_ydata([self.state.cur_y * self.spacing[1]] * 2)
        
        self.lines_coronal[0].set_xdata([self.state.cur_x * self.spacing[2]] * 2)
        self.lines_coronal[1].set_ydata([self.state.cur_z * self.spacing[0]] * 2)
        
        self.lines_sagittal[0].set_xdata([self.state.cur_y * self.spacing[1]] * 2)
        self.lines_sagittal[1].set_ydata([self.state.cur_z * self.spacing[0]] * 2)

    def _setup_sliders(self):
        """Setup slider ranges based on volume dimensions"""
        self.sliders['axial'].min = 0
        self.sliders['axial'].max = (self.dimensions[0] - 1) * self.spacing[0]
        self.sliders['axial'].step = self.spacing[0]
        self.sliders['axial'].value = self.state.cur_z * self.spacing[0]

        self.sliders['coronal'].min = 0
        self.sliders['coronal'].max = (self.dimensions[1] - 1) * self.spacing[1]
        self.sliders['coronal'].step = self.spacing[1]
        self.sliders['coronal'].value = self.state.cur_y * self.spacing[1]

        self.sliders['sagittal'].min = 0
        self.sliders['sagittal'].max = (self.dimensions[2] - 1) * self.spacing[2]
        self.sliders['sagittal'].step = self.spacing[2]
        self.sliders['sagittal'].value = self.state.cur_x * self.spacing[2]

    def _on_click(self, event):
        """Handle mouse click events"""
        if event.inaxes is None:
            return
            
        if event.inaxes == self.ax_axial:
            x_index = int(round(event.xdata / self.spacing[2]))
            y_index = int(round(event.ydata / self.spacing[1]))
            if 0 <= x_index < self.dimensions[2] and 0 <= y_index < self.dimensions[1]:
                self.state.cur_x = x_index
                self.state.cur_y = y_index
        elif event.inaxes == self.ax_coronal:
            x_index = int(round(event.xdata / self.spacing[2]))
            z_index = int(round(event.ydata / self.spacing[0]))
            if 0 <= x_index < self.dimensions[2] and 0 <= z_index < self.dimensions[0]:
                self.state.cur_x = x_index
                self.state.cur_z = z_index
        elif event.inaxes == self.ax_sagittal:
            y_index = int(round(event.xdata / self.spacing[1]))
            z_index = int(round(event.ydata / self.spacing[0]))
            if 0 <= y_index < self.dimensions[1] and 0 <= z_index < self.dimensions[0]:
                self.state.cur_y = y_index
                self.state.cur_z = z_index
                
        self._update_display(force_high_res=True, force_update=True)

    def _on_slider_mousedown(self, change):
        """Handle slider mouse down event"""
        self.state.is_sliding = True

    def _on_slider_mouseup(self, change):
        """Handle slider mouse up event"""
        self.state.is_sliding = False
        self._update_display(force_high_res=True, force_update=True)

    def _on_slider_value_change(self, change):
        """Handle slider value change"""
        if self._suspend_slider_events:
            return

        if change['owner'] is self.sliders['axial']:
            new_z = int(round(change['new'] / self.spacing[0]))
            if 0 <= new_z < self.dimensions[0]:
                self.state.cur_z = new_z
        elif change['owner'] is self.sliders['coronal']:
            new_y = int(round(change['new'] / self.spacing[1]))
            if 0 <= new_y < self.dimensions[1]:
                self.state.cur_y = new_y
        elif change['owner'] is self.sliders['sagittal']:
            new_x = int(round(change['new'] / self.spacing[2]))
            if 0 <= new_x < self.dimensions[2]:
                self.state.cur_x = new_x
        
        self._debounced_update()

    def _safe_set_slider_value(self, slider, value: float):
        """Set slider value without triggering recursive callbacks."""
        if abs(slider.value - value) < 1e-6:
            return
        self._suspend_slider_events = True
        slider.unobserve(self._on_slider_value_change, names='value')
        slider.value = value
        slider.observe(self._on_slider_value_change, names='value')
        self._suspend_slider_events = False

    def _update_sliders(self):
        """Update slider values"""
        self._safe_set_slider_value(self.sliders['axial'], self.state.cur_z * self.spacing[0])
        self._safe_set_slider_value(self.sliders['coronal'], self.state.cur_y * self.spacing[1])
        self._safe_set_slider_value(self.sliders['sagittal'], self.state.cur_x * self.spacing[2])

    def _debounced_update(self):
        """Debounce updates to prevent too frequent refreshes"""
        if self.state.update_timer is not None:
            self.state.update_timer.cancel()
        
        self.state.update_timer = threading.Timer(
            self.state.MIN_UPDATE_INTERVAL, 
            lambda: self._update_display(False))
        self.state.update_timer.start()

    def display_controls(self):
        """Display the UI controls"""
        sliders_box = widgets.HBox(list(self.sliders.values()))
        display(sliders_box)

    # Public API
    def add_overlay(self, overlay_volume: np.ndarray, *, alpha: float = 0.35,
                    color: Tuple[float, float, float] = (1.0, 0.0, 0.0),
                    overlay_id: Optional[str] = None, jump_to: bool = False) -> str:
        """
        Add an overlay mask. Returns overlay_id.
        """
        if self.current_volume is None:
            raise ValueError("Load a volume before attaching an overlay.")
        if overlay_volume.shape != self.dimensions:
            raise ValueError(f"Overlay shape {overlay_volume.shape} does not match volume {self.dimensions}.")

        oid = overlay_id or f"overlay_{len(self.overlays) + 1}"
        # Overwrite existing overlay with same id
        self.overlays = [ov for ov in self.overlays if ov.id != oid]
        mask = (overlay_volume > 0).astype(np.uint8)
        self.overlays.append(Overlay(id=oid, volume=mask, color=color, alpha=alpha, artists={"axial": None, "coronal": None, "sagittal": None}))

        if jump_to and mask.any():
            z, y, x = np.argwhere(mask > 0)[len(np.argwhere(mask > 0)) // 2]
            self.jump_to(int(x), int(y), int(z))

        self._update_overlays(use_low_res=False)
        self.fig.canvas.draw_idle()
        return oid

    def set_overlay(self, overlay_volume: Optional[np.ndarray], *, alpha: float = 0.35,
                    color: Tuple[float, float, float] = (1.0, 0.0, 0.0),
                    jump_to: bool = False):
        """Backward-compatible: clear existing overlays then add one."""
        self.clear_overlays()
        if overlay_volume is not None:
            return self.add_overlay(overlay_volume, alpha=alpha, color=color, jump_to=jump_to)
        return None

    def remove_overlay(self, overlay_id: str):
        """Remove a specific overlay by id."""
        survivors = []
        for ov in self.overlays:
            if ov.id == overlay_id:
                for artist in ov.artists.values():
                    if artist is not None:
                        artist.remove()
                continue
            survivors.append(ov)
        self.overlays = survivors
        self.fig.canvas.draw_idle()

    def clear_overlays(self):
        """Remove all overlays."""
        for ov in self.overlays:
            for artist in ov.artists.values():
                if artist is not None:
                    artist.remove()
        self.overlays = []
        self.fig.canvas.draw_idle()

    def jump_to(self, x: int, y: int, z: int):
        """Programmatically move the crosshair to a voxel index (x, y, z)."""
        if self.current_volume is None:
            raise ValueError("Load a volume before jumping to a point.")

        self.state.cur_x = int(np.clip(x, 0, self.dimensions[2] - 1))
        self.state.cur_y = int(np.clip(y, 0, self.dimensions[1] - 1))
        self.state.cur_z = int(np.clip(z, 0, self.dimensions[0] - 1))
        self._update_display(force_high_res=True, force_update=True)

    def reset_view(self):
        """Reset crosshair to volume center and refresh views."""
        if self.current_volume is None:
            raise ValueError("Load a volume before resetting the view.")
        self.state.cur_z = self.dimensions[0] // 2
        self.state.cur_y = self.dimensions[1] // 2
        self.state.cur_x = self.dimensions[2] // 2
        self._update_display(force_high_res=True, force_update=True)

    def add_state_listener(self, callback: Callable[[ViewerState], None]):
        """Register a callback notified after each display update."""
        self.state_listeners.append(callback)

    # Internal helpers
    def _get_overlay_slice(self, volume: np.ndarray, axis: str, index: int, low_res: bool = False) -> np.ndarray:
        """Fetch an overlay slice with optional downsampling."""
        if axis == "axial":
            slc = volume[index, :, :]
        elif axis == "coronal":
            slc = volume[:, index, :]
        else:
            slc = volume[:, :, index]

        if low_res and axis in ("coronal", "sagittal"):
            slc = slc[::2, ::2]
        return slc

    def _ensure_overlay_artists(self, overlay: Overlay):
        """Create overlay artists for an overlay if missing."""
        if overlay.artists.get("axial") is not None:
            return

        cmap = LinearSegmentedColormap.from_list(
            overlay.id, [(0, 0, 0, 0), (*overlay.color, 1.0)]
        )

        common = dict(cmap=cmap, alpha=overlay.alpha, vmin=0, vmax=1, interpolation="nearest")
        overlay.artists["axial"] = self.ax_axial.imshow(
            self._get_overlay_slice(overlay.volume, "axial", self.state.cur_z, False),
            origin="lower", extent=self._axial_extent, **common
        )
        overlay.artists["coronal"] = self.ax_coronal.imshow(
            self._get_overlay_slice(overlay.volume, "coronal", self.state.cur_y, False),
            origin="lower", extent=self._coronal_extent, **common
        )
        overlay.artists["sagittal"] = self.ax_sagittal.imshow(
            self._get_overlay_slice(overlay.volume, "sagittal", self.state.cur_x, False),
            origin="lower", extent=self._sagittal_extent, **common
        )

    def _update_overlays(self, use_low_res: bool):
        """Update overlay image data if present."""
        if not self.overlays:
            return

        for overlay in self.overlays:
            self._ensure_overlay_artists(overlay)
            axial_slice = self._get_overlay_slice(overlay.volume, "axial", self.state.cur_z, False)
            coronal_slice = self._get_overlay_slice(overlay.volume, "coronal", self.state.cur_y, use_low_res)
            sagittal_slice = self._get_overlay_slice(overlay.volume, "sagittal", self.state.cur_x, use_low_res)

            overlay.artists["axial"].set_data(axial_slice)
            overlay.artists["coronal"].set_data(coronal_slice)
            overlay.artists["sagittal"].set_data(sagittal_slice)

            for artist in overlay.artists.values():
                artist.set_alpha(overlay.alpha)
                artist.set_clim(0, 1)
                artist.set_visible(True)

    def _notify_state_change(self):
        """Inform listeners of current state changes."""
        for cb in self.state_listeners:
            try:
                cb(self.state)
            except Exception:
                continue
