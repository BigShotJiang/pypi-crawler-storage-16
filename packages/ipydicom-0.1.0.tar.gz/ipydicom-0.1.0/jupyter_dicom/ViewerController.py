import ipywidgets as widgets
import numpy as np
import os
from IPython.display import display, HTML
from typing import Optional
from ipyfilechooser import FileChooser
from dataclasses import dataclass

from jupyter_popup import create_popup
import panel as pn

from .DICOMHandler import DICOMHandler
from .DICOMHandler import Normalization
from .MPRViewer import MPRViewer, ViewerState
from .Volume3DViewer import Volume3DViewer



class ViewerController:
    """Coordinates between different viewer components and manages UI"""
    
    def __init__(self):
        # Initialize core components
        self.dicom_handler = DICOMHandler()
        self.viewer_state = ViewerState()
        self.mpr_viewer = MPRViewer(dicom_handler=self.dicom_handler,
                                  viewer_state=self.viewer_state)
        self.volume_3d = None
        # Keep 3D in sync with 2D crosshair
        self.mpr_viewer.add_state_listener(self._sync_3d_position)
        self._preloaded_path: Optional[str] = None
        self._preloaded_single_slice: Optional[bool] = None
        self.current_series_path: Optional[str] = None  # directory used for 3D loading
        
        # Initialize UI components as None
        self.output = None
        self.vtk_output = None
        self.folder_chooser = None
        self.original_button = None
        self.normalized_button = None
        self.harmonized_button = None
        self.view3d_button = None
        self.meta_button = None
        
    def _create_widgets(self):
        """Create all UI widgets on-demand"""
        # Create outputs
        self.output = widgets.Output()
        self.vtk_output = widgets.Output()
        
        # Create file chooser
        self.folder_chooser = FileChooser()
        self.folder_chooser.title = "<b>Select DICOM Folder</b>"
        self.folder_chooser.show_only_dirs = True
        self.folder_chooser.register_callback(self._on_folder_selection)
        
        # Create buttons
        self.original_button = widgets.Button(
            description="",
            icon="eye",
            tooltip="Original Values",
            layout=widgets.Layout(max_width="80px"),
            disabled=True
        )
        
        self.normalized_button = widgets.Button(
            description="",
            icon="adjust",
            tooltip="Normalized (1%-99%)",
            layout=widgets.Layout(max_width="80px"),
            disabled=True
        )
        
        self.harmonized_button = widgets.Button(
            description="",
            icon="magic",
            tooltip="Harmonized",
            layout=widgets.Layout(max_width="80px"),
            disabled=True
        )
        
        self.view3d_button = widgets.Button(
            description="3D View",
            icon="cube",
            tooltip="Display 3D Reconstruction",
            layout=widgets.Layout(max_width="120px"),
            disabled=True
        )
        
        self.meta_button = widgets.Button(
            description="Metadata",
            icon="tags",
            tooltip="View the metadata of current DICOM file",
            layout=widgets.Layout(max_width="120px"),
            disabled=True
        )
        
        # Setup button callbacks
        self.original_button.on_click(lambda b: self._on_view_mode_change(Normalization.ORIGINAL))
        self.normalized_button.on_click(lambda b: self._on_view_mode_change(Normalization.PERCENTILE))
        self.harmonized_button.on_click(lambda b: self._on_view_mode_change(Normalization.HARMONIZED))
        self.view3d_button.on_click(self._on_3d_view_click)
        self.meta_button.on_click(self._on_meta_click)
        
    def _on_folder_selection(self, chooser):
        """Handle folder selection"""
        selected_folder = self.folder_chooser.selected_path
        if not selected_folder:
            return
        self.load_path(selected_folder, show_outputs=True)
                

    def load_path(self, path: str, show_outputs: bool = False):
        """Load a DICOM file/folder and optionally update UI outputs."""
        self._preloaded_path = path
        try:
            volume, dimensions = self.dicom_handler.load_series(path)
            spacing = self.dicom_handler.get_spacing()
            self.mpr_viewer.set_volume(volume, spacing)
            self._preloaded_single_slice = dimensions[0] <= 1
            # For 3D, always point to a directory
            if path and not os.path.isdir(path):
                self.current_series_path = os.path.dirname(path)
            else:
                self.current_series_path = path
        except Exception as e:
            print(f"Error loading DICOM: {e}")
            return

        if not show_outputs or self.output is None or self.vtk_output is None:
            return

        self.vtk_output.clear_output()
        with self.output:
            self.output.clear_output()
            self._enable_buttons(self._preloaded_single_slice)
            # Keep chooser in sync if available
            if self.folder_chooser is not None:
                try:
                    # FileChooser is dir-only; set to directory for files
                    if path and not os.path.isdir(path):
                        self.folder_chooser.selected_path = os.path.dirname(path)
                    else:
                        self.folder_chooser.selected_path = path
                except Exception:
                    pass

    def _on_view_mode_change(self, mode: str):
        """Handle view mode change"""
        self.dicom_handler.set_normalization(mode)
        self.mpr_viewer._update_display(force_high_res=True)
            
    def _on_3d_view_click(self, b):
        """Handle 3D view button click"""
        if self.volume_3d is None:
            self.volume_3d = Volume3DViewer(self.vtk_output, self.viewer_state)
            
        self.volume_3d.load_volume(self.current_series_path or self.folder_chooser.selected_path)
        
    def _on_meta_click(self, b):
        """Handle metadata button click"""
        with self.output:
            metadata = self.dicom_handler.get_metadata(self.viewer_state.cur_z)
            create_popup(metadata.formatted_metadata, 
                        f"{metadata.filename} metadata")
                        
    def _enable_buttons(self, is_single_slice: bool):
        """Enable or disable buttons based on state"""
        self.original_button.disabled = False
        self.normalized_button.disabled = False
        self.harmonized_button.disabled = False
        self.meta_button.disabled = False
        self.view3d_button.disabled = is_single_slice
                        
    def display(self):
        """Create and display all UI components"""
        # Create widgets just before displaying them
        self._create_widgets()
        
        # Create button box
        buttons_box = widgets.HBox([
            self.original_button,
            self.normalized_button,
            self.harmonized_button,
            self.view3d_button,
            self.meta_button
        ])
        
        # Display components in sequence
        display(self.folder_chooser)
        display(buttons_box)
        self.mpr_viewer.display_controls()
        display(self.output)
        display(self.vtk_output)
        # If already loaded (constructor preload), enable controls and sync chooser
        if self.dicom_handler.volume is not None:
            self._enable_buttons(self._preloaded_single_slice if self._preloaded_single_slice is not None else (self.dicom_handler.dimensions[0] <= 1))
            if self._preloaded_path and self.folder_chooser is not None:
                try:
                    self.folder_chooser.selected_path = self._preloaded_path
                except Exception:
                    pass

    # Public control surface
    def set_overlay(self, mask_volume, *, alpha: float = 0.35, color=(1.0, 0.0, 0.0), jump_to: bool = False):
        """Backward-compatible single overlay."""
        return self.mpr_viewer.set_overlay(mask_volume, alpha=alpha, color=color, jump_to=jump_to)

    def add_overlay(self, mask_volume, *, alpha: float = 0.35, color=(1.0, 0.0, 0.0),
                    overlay_id: str = None, jump_to: bool = False):
        """Add an overlay and optionally jump to its centroid."""
        return self.mpr_viewer.add_overlay(mask_volume, alpha=alpha, color=color, overlay_id=overlay_id, jump_to=jump_to)

    def clear_overlay(self):
        """Remove any overlay from the MPR viewer."""
        self.mpr_viewer.clear_overlays()

    def remove_overlay(self, overlay_id: str):
        """Remove a specific overlay."""
        self.mpr_viewer.remove_overlay(overlay_id)

    def jump_to(self, x: int, y: int, z: int):
        """Programmatically move to a voxel and refresh 2D/3D views."""
        self.mpr_viewer.jump_to(x, y, z)

    def reset_view(self):
        """Reset crosshair to volume center and refresh 2D/3D views."""
        self.mpr_viewer.reset_view()

    def new_empty_mask(self, dtype=np.uint8):
        """Return a zero mask shaped like the loaded volume."""
        if self.dicom_handler.volume is None:
            raise ValueError("Load a DICOM series before creating a mask.")
        return np.zeros_like(self.dicom_handler.volume, dtype=dtype)

    def load_mask_dicom_seg(self, seg_path: str):
        """Load a DICOM-SEG and return a labelmap aligned to the current volume."""
        return self.dicom_handler.load_segmentation_labelmap(seg_path)

    def load_mask_npy(self, path: str, dtype=np.uint8):
        """
        Load a mask from a .npy file and ensure it matches the current volume shape.
        """
        if self.dicom_handler.volume is None:
            raise ValueError("Load a DICOM series before loading a mask.")
        mask = np.load(path).astype(dtype)
        if mask.shape != self.dicom_handler.volume.shape:
            raise ValueError(f"Mask shape {mask.shape} does not match volume {self.dicom_handler.volume.shape}.")
        return mask

    def _sync_3d_position(self, _state: ViewerState):
        """Update 3D locator when crosshair changes."""
        if self.volume_3d is not None:
            self.volume_3d.update_position()
