import vtk
import panel as pn
from typing import Tuple, Optional
from dataclasses import dataclass
import ipywidgets as widgets
from IPython.display import display
from .MPRViewer import ViewerState

class Volume3DViewer:
    """Handles 3D volume rendering using VTK"""
    
    def __init__(self, vtk_output, viewer_state: ViewerState):
        self.state = viewer_state  # Use shared state from MPRViewer
        self.vtk_renderer: Optional[vtk.vtkRenderer] = None
        self.vtk_render_window: Optional[vtk.vtkRenderWindow] = None
        self.vtk_interactor: Optional[vtk.vtkRenderWindowInteractor] = None
        self.vtk_panel: Optional[pn.pane.VTK] = None
        self.output = vtk_output
        
        # VTK actors and sources
        self.volume_actor: Optional[vtk.vtkVolume] = None
        self.intersection_sphere: Optional[vtk.vtkActor] = None
        self.sphere_source: Optional[vtk.vtkSphereSource] = None
        
        # Volume properties
        self.origin: Tuple[float, float, float] = (0.0, 0.0, 0.0)
        self.spacing: Tuple[float, float, float] = (1.0, 1.0, 1.0)
        self.dimensions: Tuple[int, int, int] = (0, 0, 0)
        
    def initialize_vtk(self):
        """Initialize VTK rendering components"""
        # Create renderer
        self.vtk_renderer = vtk.vtkRenderer()
        self.vtk_renderer.SetBackground(0.1, 0.1, 0.1)
        
        # Create render window
        self.vtk_render_window = vtk.vtkRenderWindow()
        self.vtk_render_window.SetSize(800, 600)
        self.vtk_render_window.AddRenderer(self.vtk_renderer)
        
        # Create interactor
        self.vtk_interactor = vtk.vtkRenderWindowInteractor()
        self.vtk_render_window.SetInteractor(self.vtk_interactor)
        self.vtk_interactor.Initialize()
        
    def setup_volume_properties(self) -> vtk.vtkVolumeProperty:
        """Configure volume rendering properties"""
        volume_property = vtk.vtkVolumeProperty()
        
        # Set color transfer function
        color = vtk.vtkColorTransferFunction()
        color.AddRGBPoint(0, 0.0, 0.0, 0.0)
        color.AddRGBPoint(300, 0.5, 0.5, 0.5)
        color.AddRGBPoint(1000, 1.0, 1.0, 1.0)
        volume_property.SetColor(color)
        
        # Set opacity transfer function
        opacity = vtk.vtkPiecewiseFunction()
        opacity.AddPoint(0, 0.0)
        opacity.AddPoint(500, 0.05)
        opacity.AddPoint(1000, 0.1)
        volume_property.SetScalarOpacity(opacity)
        
        # Enable shading
        volume_property.ShadeOn()
        volume_property.SetInterpolationTypeToLinear()
        
        return volume_property
        
    def create_volume_transform(self, center: Tuple[float, float, float]) -> vtk.vtkTransform:
        """Create transform for proper volume orientation"""
        transform = vtk.vtkTransform()
        transform.PostMultiply()
        transform.Translate(-center[0], -center[1], -center[2])
        transform.RotateX(180)  # Flip upside down
        transform.RotateZ(180)  # Orient anterior to top
        transform.Translate(center[0], center[1], center[2])
        return transform
        
    def setup_intersection_sphere(self):
        """Create and setup intersection sphere"""
        self.sphere_source = vtk.vtkSphereSource()
        self.sphere_source.SetRadius(min(self.spacing) * 3)
        
        # Calculate initial position from shared state
        x_pos = self.origin[0] + self.state.cur_x * self.spacing[0]
        y_pos = self.origin[1] + self.state.cur_y * self.spacing[1]
        z_pos = self.origin[2] + (self.dimensions[2] - self.state.cur_z - 1) * self.spacing[2]
        
        self.sphere_source.SetCenter(x_pos, y_pos, z_pos)
        
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputConnection(self.sphere_source.GetOutputPort())
        
        self.intersection_sphere = vtk.vtkActor()
        self.intersection_sphere.SetMapper(mapper)
        self.intersection_sphere.GetProperty().SetColor(1, 0, 0)
        self.intersection_sphere.GetProperty().SetOpacity(1.0)
        
    def load_volume(self, dicom_path: str):
        """Load and setup volume from DICOM data"""
        # Initialize VTK if needed
        if self.vtk_renderer is None:
            self.initialize_vtk()
            
        # Read DICOM data
        reader = vtk.vtkDICOMImageReader()
        reader.SetDirectoryName(dicom_path)
        reader.Update()
        
        # Get volume properties
        vtk_image = reader.GetOutput()
        self.origin = vtk_image.GetOrigin()
        self.spacing = vtk_image.GetSpacing()
        self.dimensions = vtk_image.GetDimensions()
        
        # Setup volume rendering
        mapper = vtk.vtkSmartVolumeMapper()
        mapper.SetInputData(vtk_image)
        
        self.volume_actor = vtk.vtkVolume()
        self.volume_actor.SetMapper(mapper)
        self.volume_actor.SetProperty(self.setup_volume_properties())
        
        # Calculate volume center
        center = (
            self.origin[0] + self.spacing[0] * self.dimensions[0] / 2,
            self.origin[1] + self.spacing[1] * self.dimensions[1] / 2,
            self.origin[2] + self.spacing[2] * self.dimensions[2] / 2
        )
        
        # Apply transform
        transform = self.create_volume_transform(center)
        self.volume_actor.SetUserTransform(transform)
        
        # Add volume to renderer
        self.vtk_renderer.AddVolume(self.volume_actor)
        
        # Setup and add intersection sphere
        self.setup_intersection_sphere()
        self.intersection_sphere.SetUserTransform(transform)
        self.vtk_renderer.AddActor(self.intersection_sphere)
        
        # Setup camera
        camera = self.vtk_renderer.GetActiveCamera()
        camera.SetViewUp(0, -1, 0)
        camera.SetPosition(center[0], center[1], -self.dimensions[2] * self.spacing[2] * 2)
        camera.SetFocalPoint(center[0], center[1], center[2])
        
        # Reset camera and render
        self.vtk_renderer.ResetCamera()
        self.refresh_panel()
        
    def update_position(self):
        """Update intersection sphere position based on shared viewer state"""
        if self.sphere_source is None:
            return
            
        # Convert from DICOM coordinates (ViewerState) to VTK coordinates
        x_pos = self.origin[0] + self.state.cur_x * self.spacing[0]
        y_pos = self.origin[1] + self.state.cur_y * self.spacing[1]
        # Note the z-coordinate flip for VTK coordinate system
        z_pos = self.origin[2] + (self.dimensions[2] - self.state.cur_z - 1) * self.spacing[2]
        
        self.sphere_source.SetCenter(x_pos, y_pos, z_pos)
        self.refresh_panel()
        
    def refresh_panel(self):
        """Refresh the VTK panel display"""
        if self.vtk_panel is None:
            self.output.clear_output()
            with self.output:
                self.vtk_panel = pn.pane.VTK(self.vtk_render_window, width=800, height=800)
                display(self.vtk_panel)
                self.vtk_panel.show(embed=True)
                self.vtk_panel.servable(target='notebook')
        else:
            try:
                self.vtk_panel._update_pane()
            except Exception as e:
                print(f"Failed to update VTK pane: {e}")
                
    def get_output(self) -> widgets.Output:
        """Get the output widget for display"""
        return self.output