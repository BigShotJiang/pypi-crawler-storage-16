# Sample Data

Small open sample datasets for quick testing:

- `dcmqi_ct3slice/`: CT (3 slices) + DICOM-SEG `partial_overlaps.dcm`

Source: QIICR/dcmqi (Apache-2.0) — https://github.com/QIICR/dcmqi
