"""
IPyTool - A lightweight Jupyter-like notebook for Python
"""

__version__ = '0.3.0'
__author__ = 'Your Name'
