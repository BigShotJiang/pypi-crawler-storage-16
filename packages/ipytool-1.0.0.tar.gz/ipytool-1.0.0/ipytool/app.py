"""
Mini Jupyter - Flask Backend
A simple Jupyter-like notebook server that executes Python code locally.
"""

from flask import Flask, request, jsonify, send_from_directory
import sys
import io
import uuid
import json
import os
import traceback
import subprocess
import re

# Get the directory where this app.py file is located
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, 'static')

app = Flask(__name__, static_folder=STATIC_DIR)

# Global dictionary to store session states
# Key: session_id (string UUID)
# Value: { "globals": dict, "locals": dict }
SESSIONS = {}

# Notebooks directory in current working directory
# This allows the package to work from any location
NOTEBOOKS_DIR = os.path.join(os.getcwd(), "notebooks")
os.makedirs(NOTEBOOKS_DIR, exist_ok=True)


@app.route('/')
def index():
    """Serve the main HTML page"""
    return send_from_directory(STATIC_DIR, 'index.html')


@app.route('/static/<path:path>')
def serve_static(path):
    """Serve static files (CSS, JS)"""
    return send_from_directory(STATIC_DIR, path)


def handle_pip_install(packages):
    """
    Handle pip install commands
    """
    try:
        # Run pip install command
        result = subprocess.run(
            [sys.executable, '-m', 'pip', 'install'] + packages.split(),
            capture_output=True,
            text=True,
            timeout=300  # 5 minutes timeout
        )
        
        output = result.stdout
        if result.stderr:
            output += result.stderr
        
        if result.returncode == 0:
            output += f"\n✓ Successfully installed: {packages}"
        else:
            output += f"\n✗ Installation failed for: {packages}"
        
        return jsonify({
            "output": output,
            "error": None,
            "needs_input": False
        })
        
    except subprocess.TimeoutExpired:
        return jsonify({
            "output": "",
            "error": "Installation timeout (5 minutes exceeded)",
            "needs_input": False
        })
    except Exception as e:
        return jsonify({
            "output": "",
            "error": f"Installation error: {str(e)}",
            "needs_input": False
        })


@app.route('/api/new_session', methods=['POST'])
def new_session():
    """
    Create a new execution session.
    Returns a unique session_id that will be used for all subsequent code executions.
    """
    session_id = str(uuid.uuid4())
    
    # Initialize session with basic globals
    SESSIONS[session_id] = {
        "globals": {"__name__": "__main__"},
        "locals": {}
    }
    
    return jsonify({"session_id": session_id})


@app.route('/api/run_cell', methods=['POST'])
def run_cell():
    """
    Execute Python code in a specific session.
    Maintains state across multiple executions within the same session.
    Handles input() function with interactive prompts.
    Supports pip install commands.
    """
    data = request.get_json()
    
    session_id = data.get('session_id')
    code = data.get('code', '')
    user_inputs = data.get('inputs', [])  # List of user-provided inputs for input() calls
    
    # Validate session
    if not session_id or session_id not in SESSIONS:
        return jsonify({
            "output": "",
            "error": "Invalid or missing session_id"
        }), 400
    
    # Check if this is a pip install command
    pip_pattern = r'^!pip\s+install\s+(.+)$'
    match = re.match(pip_pattern, code.strip())
    
    if match:
        # Execute pip install command
        packages = match.group(1)
        return handle_pip_install(packages)
    
    # Get session's global and local scopes
    session = SESSIONS[session_id]
    globals_dict = session["globals"]
    locals_dict = session["locals"]
    
    # Capture stdout and stderr
    stdout_buffer = io.StringIO()
    stderr_buffer = io.StringIO()
    
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    old_stdin = sys.stdin
    
    error_message = None
    needs_input = False
    input_prompt = ""
    
    try:
        # Redirect output streams
        sys.stdout = stdout_buffer
        sys.stderr = stderr_buffer
        
        # Create a custom input handler
        input_counter = [0]  # Use list to allow modification in nested function
        collected_inputs = []
        
        def custom_input(prompt=""):
            """Custom input function that either uses provided inputs or requests them"""
            nonlocal needs_input, input_prompt
            
            if input_counter[0] < len(user_inputs):
                # Use pre-provided input
                value = user_inputs[input_counter[0]]
                input_counter[0] += 1
                # Echo the input like Jupyter does
                print(f"{prompt}{value}")
                return value
            else:
                # Need to request input from user
                needs_input = True
                input_prompt = prompt if prompt else "Input required:"
                # Raise a special exception to pause execution
                raise InterruptedError(f"__INPUT_REQUIRED__|{input_prompt}")
        
        # Replace built-in input with custom input
        globals_dict['input'] = custom_input
        
        # Execute the code and capture last expression result
        # Use compile in 'single' mode for REPL-like behavior
        code_stripped = code.strip()
        
        # Try to detect if the last line is a standalone expression
        lines = code_stripped.split('\n')
        last_line = None
        for line in reversed(lines):
            stripped = line.strip()
            if stripped and not stripped.startswith('#'):
                last_line = stripped
                break
        
        result = None
        
        # Check if last line might be an expression (not starting with keywords like print, def, etc.)
        is_likely_expression = False
        if last_line:
            # Simple heuristic: if it doesn't start with statement keywords, might be expression
            statement_starters = ['print', 'import', 'from', 'def', 'class', 'if', 'for', 'while', 
                                 'with', 'try', 'return', 'raise', 'assert', 'del', 'pass', 
                                 'break', 'continue', 'global', 'nonlocal', 'yield']
            
            first_word = last_line.split('(')[0].split('.')[0].split('[')[0].strip()
            is_likely_expression = not any(last_line.startswith(kw) for kw in statement_starters)
            is_likely_expression = is_likely_expression and '=' not in last_line.split('(')[0]
        
        if is_likely_expression and last_line:
            # Split code: everything except last line, then evaluate last line separately
            code_without_last = '\n'.join(lines[:-1])
            
            try:
                # Execute everything except last line
                if code_without_last.strip():
                    exec(compile(code_without_last, '<string>', 'exec'), globals_dict, locals_dict)
                
                # Evaluate last line as expression
                result = eval(compile(last_line, '<string>', 'eval'), globals_dict, locals_dict)
                
            except (SyntaxError, TypeError):
                # Last line is not a valid expression, execute entire code normally
                exec(compile(code_stripped, '<string>', 'exec'), globals_dict, locals_dict)
        else:
            # Execute entire code normally
            exec(compile(code_stripped, '<string>', 'exec'), globals_dict, locals_dict)
        
        # If last expression is a pandas DataFrame, convert to HTML table
        if result is not None:
            try:
                import pandas as pd
                if isinstance(result, pd.DataFrame):
                    html_table = result.to_html(classes='dataframe-table', index=True, border=0)
                    print("__HTML_TABLE__" + html_table)
            except ImportError:
                pass  # pandas not installed
        
        # Update locals in the session (to persist variables)
        # Merge locals back into globals for Jupyter-like behavior
        globals_dict.update(locals_dict)
        
    except InterruptedError as e:
        # This is our custom input request exception
        error_message = str(e)
        
    except Exception as e:
        # Capture the full traceback
        error_message = traceback.format_exc()
    
    finally:
        # Restore original streams and input
        sys.stdout = old_stdout
        sys.stderr = old_stderr
        sys.stdin = old_stdin
    
    # Get captured output
    output = stdout_buffer.getvalue()
    stderr_output = stderr_buffer.getvalue()
    
    # Combine stdout and stderr
    if stderr_output:
        output += stderr_output
    
    # Check if we need input from user
    if error_message and error_message.startswith("__INPUT_REQUIRED__|"):
        input_prompt_text = error_message.split("|", 1)[1]
        return jsonify({
            "output": output,
            "error": None,
            "needs_input": True,
            "input_prompt": input_prompt_text
        })
    
    return jsonify({
        "output": output,
        "error": error_message,
        "needs_input": False
    })


@app.route('/api/save_notebook', methods=['POST'])
def save_notebook():
    """
    Save notebook to a JSON file.
    Format: { "name": "notebook_name", "cells": [...] }
    """
    data = request.get_json()
    
    name = data.get('name', 'untitled')
    cells = data.get('cells', [])
    
    # Sanitize filename
    safe_name = "".join(c for c in name if c.isalnum() or c in (' ', '-', '_')).strip()
    if not safe_name:
        safe_name = 'untitled'
    
    # Ensure notebooks directory exists
    os.makedirs(NOTEBOOKS_DIR, exist_ok=True)
    
    filepath = os.path.join(NOTEBOOKS_DIR, f"{safe_name}.json")
    
    # Save to file
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump({"cells": cells}, f, indent=2)
    
    return jsonify({
        "status": "ok",
        "path": filepath
    })


@app.route('/api/load_notebook', methods=['GET'])
def load_notebook():
    """
    Load a notebook from a JSON file.
    Query parameter: name=notebook_name
    """
    name = request.args.get('name', '')
    
    if not name:
        return jsonify({"error": "No notebook name provided"}), 400
    
    # Sanitize filename
    safe_name = "".join(c for c in name if c.isalnum() or c in (' ', '-', '_')).strip()
    filepath = os.path.join(NOTEBOOKS_DIR, f"{safe_name}.json")
    
    if not os.path.exists(filepath):
        return jsonify({"error": f"Notebook '{name}' not found"}), 404
    
    # Load from file
    with open(filepath, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    return jsonify(data)


@app.route('/api/list_notebooks', methods=['GET'])
def list_notebooks():
    """
    List all saved notebooks.
    Returns an array of notebook names (without .json extension).
    """
    try:
        # Ensure notebooks directory exists
        os.makedirs(NOTEBOOKS_DIR, exist_ok=True)
        
        files = os.listdir(NOTEBOOKS_DIR)
        notebooks = [f[:-5] for f in files if f.endswith('.json')]
        return jsonify({"notebooks": notebooks})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == '__main__':
    print("=" * 60)
    print("Mini Jupyter - Local Python Notebook")
    print("=" * 60)
    print("Starting server at http://localhost:5000")
    print("Press Ctrl+C to stop the server")
    print("=" * 60)
    
    app.run(debug=True, host='localhost', port=5000)
