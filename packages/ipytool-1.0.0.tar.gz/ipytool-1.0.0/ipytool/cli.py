#!/usr/bin/env python3
"""
IPyTool CLI - Command-line interface for IPyTool notebook
"""

import sys
import webbrowser
import time
from threading import Timer
from ipytool.app import app, NOTEBOOKS_DIR
import os


def open_browser():
    """Open the browser after a short delay"""
    time.sleep(1.5)
    webbrowser.open('http://localhost:5000')


def main():
    """Main entry point for ipytool command"""
    print("=" * 60)
    print("IPyTool - Jupyter-like Python Notebook")
    print("=" * 60)
    print(f"Notebooks directory: {NOTEBOOKS_DIR}")
    print("Starting server at http://localhost:5000")
    print("Opening in your default browser...")
    print("Press Ctrl+C to stop the server")
    print("=" * 60)
    
    # Open browser in a separate thread
    Timer(1.5, open_browser).start()
    
    # Start Flask app
    try:
        app.run(host='0.0.0.0', port=5000, debug=False, use_reloader=False)
    except KeyboardInterrupt:
        print("\n\nShutting down IPyTool...")
        sys.exit(0)


if __name__ == '__main__':
    main()
