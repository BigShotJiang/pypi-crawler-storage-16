/**
 * PyInMind Notebook - Frontend Logic
 * Professional notebook interface with stateful Python execution
 */

// Python keywords and built-in functions for autocomplete
const PYTHON_KEYWORDS = [
    'False', 'None', 'True', 'and', 'as', 'assert', 'async', 'await', 'break',
    'class', 'continue', 'def', 'del', 'elif', 'else', 'except', 'finally',
    'for', 'from', 'global', 'if', 'import', 'in', 'is', 'lambda', 'nonlocal',
    'not', 'or', 'pass', 'raise', 'return', 'try', 'while', 'with', 'yield'
];

const PYTHON_BUILTINS = [
    'abs', 'all', 'any', 'ascii', 'bin', 'bool', 'bytearray', 'bytes',
    'callable', 'chr', 'classmethod', 'compile', 'complex', 'delattr',
    'dict', 'dir', 'divmod', 'enumerate', 'eval', 'exec', 'filter',
    'float', 'format', 'frozenset', 'getattr', 'globals', 'hasattr',
    'hash', 'help', 'hex', 'id', 'input', 'int', 'isinstance',
    'issubclass', 'iter', 'len', 'list', 'locals', 'map', 'max',
    'memoryview', 'min', 'next', 'object', 'oct', 'open', 'ord',
    'pow', 'print', 'property', 'range', 'repr', 'reversed', 'round',
    'set', 'setattr', 'slice', 'sorted', 'staticmethod', 'str', 'sum',
    'super', 'tuple', 'type', 'vars', 'zip', '__import__'
];

const PYTHON_COMMON_MODULES = [
    'pandas', 'numpy', 'matplotlib', 'seaborn', 'sklearn', 'scipy',
    'requests', 'json', 'os', 'sys', 'datetime', 're', 'math', 'random',
    'collections', 'itertools', 'functools', 'pathlib', 'csv', 'pickle'
];

/**
 * Custom Python autocomplete function
 */
function pythonHint(cm) {
    const cur = cm.getCursor();
    const token = cm.getTokenAt(cur);
    const start = token.start;
    const end = cur.ch;
    const line = cm.getLine(cur.line);
    const currentWord = token.string;
    
    // Get all text to find user-defined variables and functions
    const allText = cm.getValue();
    const userDefinedPattern = /(?:def|class)\s+(\w+)|^(\w+)\s*=/gm;
    const userDefined = [];
    let match;
    while ((match = userDefinedPattern.exec(allText)) !== null) {
        const name = match[1] || match[2];
        if (name && !userDefined.includes(name)) {
            userDefined.push(name);
        }
    }
    
    // Combine all suggestions
    const allSuggestions = [
        ...PYTHON_KEYWORDS,
        ...PYTHON_BUILTINS,
        ...PYTHON_COMMON_MODULES,
        ...userDefined
    ];
    
    // Filter based on current input
    const suggestions = allSuggestions.filter(word => 
        word.toLowerCase().startsWith(currentWord.toLowerCase()) && word !== currentWord
    ).sort();
    
    if (suggestions.length === 0) {
        // Fallback to anyword hint
        return CodeMirror.hint.anyword(cm);
    }
    
    return {
        list: suggestions,
        from: CodeMirror.Pos(cur.line, start),
        to: CodeMirror.Pos(cur.line, end)
    };
}

// Register custom hint
CodeMirror.registerHelper('hint', 'python', pythonHint);

// Global state
let sessionId = null;
let cells = [];
let cellCounter = 0;
let selectedCellIndex = 0;
let currentInputCallback = null;
let pendingInputs = [];
let codeMirrorInstances = {}; // Store CodeMirror instances by cell ID

// DOM Elements
const cellsContainer = document.getElementById('cells');
const sessionStatus = document.getElementById('session-status');
const btnNewCell = document.getElementById('btn-new-cell');
const btnRunCell = document.getElementById('btn-run-cell');
const btnRunAll = document.getElementById('btn-run-all');
const btnSave = document.getElementById('btn-save');
const btnLoad = document.getElementById('btn-load');
const btnList = document.getElementById('btn-list');
const btnRestartKernel = document.getElementById('btn-restart-kernel');
const notebookNameInput = document.getElementById('notebook-name');
const inputModal = document.getElementById('input-modal');
const inputValue = document.getElementById('input-value');
const inputPromptText = document.getElementById('input-prompt-text');

/**
 * Initialize the application on page load
 */
async function init() {
    // Create a new session
    await createNewSession();
    
    // Add initial cell with sample code
    const sampleCode = `print("Hello, Welcome to PyInMind Notebook!")`;
    
    addCell(sampleCode);
    
    // Attach event listeners
    btnNewCell.addEventListener('click', () => addCellBelow());
    btnRunCell.addEventListener('click', () => runSelectedCell());
    btnRunAll.addEventListener('click', runAll);
    btnSave.addEventListener('click', saveNotebook);
    btnLoad.addEventListener('click', loadNotebook);
    btnList.addEventListener('click', listNotebooks);
    btnRestartKernel.addEventListener('click', restartKernel);
    
    // Keyboard shortcuts
    document.addEventListener('keydown', handleKeyboard);
    
    // Input modal Enter key
    inputValue.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            submitInput();
        }
    });
}

/**
 * Handle keyboard shortcuts 
 */
function handleKeyboard(e) {
    // Alt+M: Toggle cell type between code and markdown
    if (e.altKey && e.key === 'm') {
        e.preventDefault();
        if (selectedCellIndex !== null && selectedCellIndex < cells.length) {
            toggleCellType(selectedCellIndex);
        }
        return;
    }
    
    // Shift+Enter: Run cell and select next
    if (e.shiftKey && e.key === 'Enter') {
        const activeElement = document.activeElement;
        if (activeElement.classList.contains('cell-code')) {
            e.preventDefault();
            runSelectedCell();
        }
    }
    
    // Ctrl+Enter: Run cell
    if (e.ctrlKey && e.key === 'Enter') {
        const activeElement = document.activeElement;
        if (activeElement.classList.contains('cell-code')) {
            e.preventDefault();
            runCellByIndex(selectedCellIndex);
        }
    }
    
    // B: Insert cell below (when not in input)
    if (e.key === 'b' && document.activeElement.tagName !== 'TEXTAREA' && 
        document.activeElement.tagName !== 'INPUT') {
        addCellBelow();
    }
    
    // DD: Delete cell (press D twice)
    // (simplified - just using Delete key for now)
}

/**
 * Create a new execution session on the server
 */
async function createNewSession() {
    try {
        const response = await fetch('/api/new_session', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });
        
        const data = await response.json();
        sessionId = data.session_id;
        sessionStatus.textContent = `Session: ${sessionId.substring(0, 8)}...`;
        sessionStatus.style.color = '#666';
        
        // Reset execution counters
        cells.forEach(cell => {
            cell.executionCount = null;
        });
        
    } catch (error) {
        sessionStatus.textContent = `Error: ${error.message}`;
        sessionStatus.style.color = '#d9534f';
    }
}

/**
 * Restart kernel (create new session)
 */
async function restartKernel() {
    if (confirm('Restart kernel? All variables will be lost.')) {
        // Clear all CodeMirror instances
        Object.keys(codeMirrorInstances).forEach(cellId => {
            if (codeMirrorInstances[cellId]) {
                codeMirrorInstances[cellId].toTextArea();
            }
        });
        codeMirrorInstances = {};
        
        await createNewSession();
        
        // Clear all outputs
        cells.forEach(cell => {
            cell.output = '';
            cell.executionCount = null;
        });
        renderCells();
        alert('✓ Kernel restarted');
    }
}


/**
 * Add a new cell to the notebook
 * @param {string} initialCode - Initial code to populate the cell
 * @param {number} index - Position to insert the cell
 * @param {string} cellType - 'code' or 'markdown'
 */
function addCell(initialCode = '', index = null, cellType = 'code') {
    cellCounter++;
    const cellId = `cell-${cellCounter}`;
    
    const cell = {
        id: cellId,
        type: cellType,  // 'code' or 'markdown'
        code: initialCode,
        output: '',
        executionCount: null,  // Jupyter-style execution counter (only for code cells)
        index: index !== null ? index : cells.length
    };
    
    if (index !== null) {
        cells.splice(index, 0, cell);
    } else {
        cells.push(cell);
    }
    
    // Update indices
    cells.forEach((c, idx) => c.index = idx);
    
    renderCells();
    
    // Focus the new cell
    setTimeout(() => {
        if (codeMirrorInstances[cellId]) {
            codeMirrorInstances[cellId].focus();
        }
    }, 100);
}

/**
 * Add cell below current selection or at specified index
 */
function addCellBelow(atIndex = null) {
    const insertIndex = atIndex !== null ? atIndex + 1 : selectedCellIndex + 1;
    addCell('', insertIndex);
    selectedCellIndex = insertIndex;
}

/**
 * Move cell up in the notebook
 */
function moveCellUp(index) {
    if (index <= 0 || index >= cells.length) return;
    
    // Swap cells
    [cells[index - 1], cells[index]] = [cells[index], cells[index - 1]];
    
    // Update indices
    cells.forEach((c, idx) => c.index = idx);
    
    // Update selected index
    if (selectedCellIndex === index) {
        selectedCellIndex = index - 1;
    } else if (selectedCellIndex === index - 1) {
        selectedCellIndex = index;
    }
    
    renderCells();
}

/**
 * Move cell down in the notebook
 */
function moveCellDown(index) {
    if (index < 0 || index >= cells.length - 1) return;
    
    // Swap cells
    [cells[index], cells[index + 1]] = [cells[index + 1], cells[index]];
    
    // Update indices
    cells.forEach((c, idx) => c.index = idx);
    
    // Update selected index
    if (selectedCellIndex === index) {
        selectedCellIndex = index + 1;
    } else if (selectedCellIndex === index + 1) {
        selectedCellIndex = index;
    }
    
    renderCells();
}

/**
 * Delete a cell from the notebook
 * @param {string} cellId - ID of the cell to delete
 */
function deleteCell(cellId) {
    const index = cells.findIndex(c => c.id === cellId);
    if (index !== -1) {
        if (cells.length === 1) {
            // Don't delete the last cell, just clear it
            cells[0].code = '';
            cells[0].output = '';
            cells[0].executionCount = null;
            
            // Clear CodeMirror instance
            if (codeMirrorInstances[cells[0].id]) {
                codeMirrorInstances[cells[0].id].setValue('');
            }
        } else {
            // Remove CodeMirror instance
            if (codeMirrorInstances[cellId]) {
                codeMirrorInstances[cellId].toTextArea();
                delete codeMirrorInstances[cellId];
            }
            
            cells.splice(index, 1);
        }
        
        // Update indices
        cells.forEach((c, idx) => c.index = idx);
        
        // Adjust selected cell
        if (selectedCellIndex >= cells.length) {
            selectedCellIndex = cells.length - 1;
        }
        
        renderCells();
    }
}

/**
 * Render all cells to the DOM (Jupyter style with CodeMirror)
 * Preserves existing CodeMirror instances to prevent code loss
 */
function renderCells() {
    // Store existing CodeMirror instances temporarily
    const existingInstances = { ...codeMirrorInstances };
    
    cellsContainer.innerHTML = '';
    
    if (cells.length === 0) {
        cellsContainer.innerHTML = '<div class="empty-notebook">No cells. Click + to add a cell.</div>';
        return;
    }
    
    cells.forEach((cell, index) => {
        const cellDiv = document.createElement('div');
        cellDiv.className = 'cell';
        if (index === selectedCellIndex) {
            cellDiv.classList.add('selected');
        }
        cellDiv.id = cell.id;
        
        // Cell prompt (PyCell[1]:)
        const prompt = document.createElement('div');
        prompt.className = 'cell-prompt';
        
        // Only show execution count for code cells
        if (cell.type === 'markdown') {
            prompt.textContent = '';  // No prompt for markdown
        } else {
            prompt.textContent = cell.executionCount !== null ? `PyCell[${cell.executionCount}]:` : 'PyCell[ ]:';
        }
        
        // Cell content wrapper
        const content = document.createElement('div');
        content.className = 'cell-content';
        
        // Cell toolbar (appears on hover)
        const toolbar = document.createElement('div');
        toolbar.className = 'cell-toolbar';
        
        const btnRun = document.createElement('button');
        btnRun.className = 'btn-run';
        btnRun.textContent = '▶';
        btnRun.addEventListener('click', () => runCellByIndex(index));
        
        // Cell type toggle button
        const btnCellType = document.createElement('button');
        btnCellType.className = 'btn-cell-type';
        btnCellType.textContent = cell.type === 'markdown' ? 'MD' : 'Code';
        btnCellType.title = cell.type === 'markdown' ? 'Switch to Code' : 'Switch to Markdown';
        btnCellType.addEventListener('click', () => toggleCellType(cell.id));
        
        const btnDelete = document.createElement('button');
        btnDelete.className = 'btn-delete';
        btnDelete.textContent = '🗑';
        btnDelete.addEventListener('click', () => deleteCell(cell.id));
        
        // Move up button
        const btnMoveUp = document.createElement('button');
        btnMoveUp.className = 'btn-move';
        btnMoveUp.textContent = '↑';
        btnMoveUp.title = 'Move cell up';
        btnMoveUp.addEventListener('click', () => moveCellUp(index));
        if (index === 0) btnMoveUp.disabled = true;
        
        // Move down button
        const btnMoveDown = document.createElement('button');
        btnMoveDown.className = 'btn-move';
        btnMoveDown.textContent = '↓';
        btnMoveDown.title = 'Move cell down';
        btnMoveDown.addEventListener('click', () => moveCellDown(index));
        if (index === cells.length - 1) btnMoveDown.disabled = true;
        
        // Add cell below button
        const btnAddBelow = document.createElement('button');
        btnAddBelow.className = 'btn-add-below';
        btnAddBelow.textContent = '+';
        btnAddBelow.title = 'Add cell below';
        btnAddBelow.addEventListener('click', () => addCellBelow(index));
        
        toolbar.appendChild(btnRun);
        toolbar.appendChild(btnCellType);
        toolbar.appendChild(btnMoveUp);
        toolbar.appendChild(btnMoveDown);
        toolbar.appendChild(btnAddBelow);
        toolbar.appendChild(btnDelete);
        
        cellDiv.appendChild(prompt);
        cellDiv.appendChild(content);
        cellsContainer.appendChild(cellDiv);
        
        // Check cell type and render accordingly
        if (cell.type === 'markdown') {
            renderMarkdownCell(cell, content, toolbar, index);
        } else {
            renderCodeCell(cell, content, toolbar, index, existingInstances);
        }
    });
}

/**
 * Render a code cell with CodeMirror
 */
function renderCodeCell(cell, content, toolbar, index, existingInstances) {
    // Code editor wrapper
    const codeWrapper = document.createElement('div');
    codeWrapper.className = 'cell-code-wrapper';
    codeWrapper.id = `code-wrapper-${cell.id}`;
    
    content.appendChild(codeWrapper);
    content.appendChild(toolbar);
        
        // Handle CodeMirror instance
        if (existingInstances[cell.id]) {
            // Reuse existing instance
            const wrapper = document.getElementById(`code-wrapper-${cell.id}`);
            wrapper.appendChild(existingInstances[cell.id].getWrapperElement());
            codeMirrorInstances[cell.id] = existingInstances[cell.id];
            
            // Update the index for keyboard shortcuts
            const cm = existingInstances[cell.id];
            cm.setOption('extraKeys', {
                'Shift-Enter': function() {
                    // Shift+Enter: Just run the cell
                    runCellByIndex(index);
                },
                'Ctrl-Enter': function() {
                    // Ctrl+Enter: Run cell and add new cell below
                    runCellByIndex(index).then(() => {
                        addCell('', index + 1);
                        selectedCellIndex = index + 1;
                    });
                },
                'Tab': function(cm) {
                    if (cm.somethingSelected()) {
                        cm.indentSelection('add');
                    } else {
                        cm.replaceSelection('    ', 'end');
                    }
                },
                'Ctrl-Space': 'autocomplete'
            });
            
            // Refresh CodeMirror to fix display issues
            setTimeout(() => cm.refresh(), 1);
            
        } else {
            // Create new instance
            const textarea = document.createElement('textarea');
            textarea.className = 'cell-code';
            textarea.value = cell.code;
            
            const wrapper = document.getElementById(`code-wrapper-${cell.id}`);
            wrapper.appendChild(textarea);
            
            setTimeout(() => {
                const cm = CodeMirror.fromTextArea(textarea, {
                    mode: 'python',
                    lineNumbers: false,
                    matchBrackets: true,
                    autoCloseBrackets: true,
                    indentUnit: 4,
                    indentWithTabs: false,
                    lineWrapping: true,
                    viewportMargin: Infinity,
                    hintOptions: {
                        completeSingle: false,
                        alignWithWord: true,
                        closeOnUnfocus: true
                    },
                    extraKeys: {
                        'Shift-Enter': function() {
                            // Shift+Enter: Just run the cell
                            runCellByIndex(index);
                        },
                        'Ctrl-Enter': function() {
                            // Ctrl+Enter: Run cell and add new cell below
                            runCellByIndex(index).then(() => {
                                addCell('', index + 1);
                                selectedCellIndex = index + 1;
                            });
                        },
                        'Tab': function(cm) {
                            if (cm.somethingSelected()) {
                                cm.indentSelection('add');
                            } else {
                                cm.replaceSelection('    ', 'end');
                            }
                        },
                        'Ctrl-Space': 'autocomplete'
                    }
                });
                
                codeMirrorInstances[cell.id] = cm;
                
                // Auto-trigger autocomplete on typing
                cm.on('inputRead', function(cm, change) {
                    if (change.text[0] && /\w/.test(change.text[0])) {
                        // Trigger autocomplete after typing a word character
                        cm.showHint({hint: pythonHint, completeSingle: false});
                    }
                });
                
                // Update cell code when editor changes
                cm.on('change', function() {
                    cell.code = cm.getValue();
                });
                
                // Handle focus to select cell
                cm.on('focus', function() {
                    selectedCellIndex = index;
                    updateCellSelection();
                });
                
                // Set initial value
                cm.setValue(cell.code);
                cm.refresh();
            }, 1);
        }
        
        // Output area
        if (cell.output) {
            const outputArea = document.createElement('div');
            outputArea.className = 'output-area';
            
            const outputPrompt = document.createElement('div');
            outputPrompt.className = 'output-prompt';
            outputPrompt.textContent = cell.executionCount !== null ? `Out[${cell.executionCount}]:` : '';
            
            const outputWrapper = document.createElement('div');
            outputWrapper.className = 'cell-output-wrapper';
            
            // Check if output contains HTML table
            if (cell.output.includes('__HTML_TABLE__')) {
                const parts = cell.output.split('__HTML_TABLE__');
                
                // Show text output before table (if any)
                if (parts[0].trim()) {
                    const textOutput = document.createElement('pre');
                    textOutput.className = 'cell-output';
                    textOutput.textContent = parts[0];
                    outputWrapper.appendChild(textOutput);
                }
                
                // Show HTML table
                const tableDiv = document.createElement('div');
                tableDiv.className = 'cell-output html-output';
                tableDiv.innerHTML = parts[1];
                outputWrapper.appendChild(tableDiv);
            } else {
                // Regular text output
                const output = document.createElement('pre');
                output.className = 'cell-output';
                output.textContent = cell.output;
                
                if (cell.output.includes('ERROR:') || cell.output.includes('Traceback')) {
                    output.classList.add('error');
                }
                
                outputWrapper.appendChild(output);
            }
            
            outputArea.appendChild(outputPrompt);
            outputArea.appendChild(outputWrapper);
            content.appendChild(outputArea);
        }
}

/**
 * Render a markdown cell
 */
function renderMarkdownCell(cell, content, toolbar, index) {
    // Markdown display/edit wrapper
    const mdWrapper = document.createElement('div');
    mdWrapper.className = 'markdown-wrapper';
    mdWrapper.id = `md-wrapper-${cell.id}`;
    
    // Rendered markdown view
    const mdRendered = document.createElement('div');
    mdRendered.className = 'markdown-rendered';
    mdRendered.innerHTML = marked.parse(cell.code || '**Double-click to edit**');
    mdRendered.addEventListener('dblclick', () => {
        toggleMarkdownEdit(cell.id, true);
    });
    
    // Markdown editor (hidden by default)
    const mdEditor = document.createElement('textarea');
    mdEditor.className = 'markdown-editor';
    mdEditor.value = cell.code;
    mdEditor.style.display = 'none';
    mdEditor.addEventListener('blur', () => {
        cell.code = mdEditor.value;
        toggleMarkdownEdit(cell.id, false);
    });
    mdEditor.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            cell.code = mdEditor.value;
            toggleMarkdownEdit(cell.id, false);
        }
        if (e.shiftKey && e.key === 'Enter') {
            e.preventDefault();
            cell.code = mdEditor.value;
            toggleMarkdownEdit(cell.id, false);
        }
    });
    
    mdWrapper.appendChild(mdRendered);
    mdWrapper.appendChild(mdEditor);
    
    content.appendChild(mdWrapper);
    content.appendChild(toolbar);
}

/**
 * Toggle markdown cell between edit and view mode
 */
function toggleMarkdownEdit(cellId, editMode) {
    const wrapper = document.getElementById(`md-wrapper-${cellId}`);
    if (!wrapper) return;
    
    const rendered = wrapper.querySelector('.markdown-rendered');
    const editor = wrapper.querySelector('.markdown-editor');
    const cell = cells.find(c => c.id === cellId);
    
    if (editMode) {
        rendered.style.display = 'none';
        editor.style.display = 'block';
        editor.focus();
    } else {
        editor.style.display = 'none';
        rendered.style.display = 'block';
        rendered.innerHTML = marked.parse(cell.code || '**Double-click to edit**');
    }
}

/**
 * Toggle cell type between code and markdown
 */
function toggleCellType(cellId) {
    const cell = cells.find(c => c.id === cellId);
    if (!cell) return;
    
    // Clear CodeMirror instance if switching from code
    if (cell.type === 'code' && codeMirrorInstances[cellId]) {
        codeMirrorInstances[cellId].toTextArea();
        delete codeMirrorInstances[cellId];
    }
    
    // Toggle type
    cell.type = cell.type === 'markdown' ? 'code' : 'markdown';
    
    // Clear output when switching to markdown
    if (cell.type === 'markdown') {
        cell.output = '';
        cell.executionCount = null;
    }
    
    renderCells();
}

/**
 * Update cell selection styling without full re-render
 */
function updateCellSelection() {
    document.querySelectorAll('.cell').forEach((cellDiv, i) => {
        if (i === selectedCellIndex) {
            cellDiv.classList.add('selected');
        } else {
            cellDiv.classList.remove('selected');
        }
    });
}


/**
 * Run selected cell
 */
function runSelectedCell() {
    if (selectedCellIndex >= 0 && selectedCellIndex < cells.length) {
        runCellByIndex(selectedCellIndex);
    }
}

/**
 * Run cell by index
 */
async function runCellByIndex(index) {
    if (index < 0 || index >= cells.length) return;
    
    const cell = cells[index];
    await runCell(cell, index);
}

/**
 * Run code in a specific cell with input() support
 * @param {Object} cell - Cell object to execute
 * @param {number} index - Cell index
 * @param {Array} inputs - Pre-collected inputs for input() calls
 */
async function runCell(cell, index, inputs = []) {
    // Skip execution for markdown cells
    if (cell.type === 'markdown') {
        return;
    }
    
    if (!sessionId) {
        alert('No active session. Please refresh the page.');
        return;
    }
    
    // Find the cell div
    const cellDiv = document.getElementById(cell.id);
    if (!cellDiv) return;
    
    const prompt = cellDiv.querySelector('.cell-prompt');
    const runButton = cellDiv.querySelector('.btn-run');
    
    // Show executing state
    if (prompt) {
        prompt.textContent = 'PyCell[*]:';
        cellDiv.classList.add('executing');
    }
    if (runButton) {
        runButton.textContent = '⏳';
        runButton.disabled = true;
    }
    
    // Clear previous output
    const existingOutput = cellDiv.querySelector('.output-area');
    if (existingOutput) existingOutput.remove();
    
    try {
        const response = await fetch('/api/run_cell', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                session_id: sessionId,
                code: cell.code,
                inputs: inputs
            })
        });
        
        const data = await response.json();
        
        // Check if input is needed
        if (data.needs_input) {
            // Show input modal
            const userInput = await showInputModal(data.input_prompt);
            
            if (userInput !== null) {
                // User provided input, re-run with the input
                inputs.push(userInput);
                await runCell(cell, index, inputs);
                return;
            } else {
                // User cancelled
                cell.output = data.output + '\n\n(Execution cancelled by user)';
                cell.executionCount = null;
            }
        } else {
            // Execution completed
            // Assign execution counter
            if (!data.error) {
                const maxCount = Math.max(0, ...cells.map(c => c.executionCount || 0));
                cell.executionCount = maxCount + 1;
            } else {
                cell.executionCount = null;
            }
            
            // Build output string
            let output = data.output || '';
            
            if (data.error) {
                output += (output ? '\n\n' : '') + data.error;
            }
            
            cell.output = output;
        }
        
    } catch (error) {
        cell.output = `Connection Error: ${error.message}`;
        cell.executionCount = null;
    } finally {
        if (cellDiv.classList.contains('executing')) {
            cellDiv.classList.remove('executing');
        }
        if (runButton) {
            runButton.textContent = '▶';
            runButton.disabled = false;
        }
        
        // Update only this cell's display without full re-render
        updateCellDisplay(cell, cellDiv);
    }
}

/**
 * Update a single cell's display (prompt and output) without re-rendering everything
 */
function updateCellDisplay(cell, cellDiv) {
    // Update prompt
    const prompt = cellDiv.querySelector('.cell-prompt');
    if (prompt) {
        prompt.textContent = cell.executionCount !== null ? `PyCell[${cell.executionCount}]:` : 'PyCell[ ]:';
    }
    
    // Remove existing output if any
    const existingOutput = cellDiv.querySelector('.output-area');
    if (existingOutput) existingOutput.remove();
    
    // Add output if exists
    if (cell.output) {
        const content = cellDiv.querySelector('.cell-content');
        
        const outputArea = document.createElement('div');
        outputArea.className = 'output-area';
        
        const outputPrompt = document.createElement('div');
        outputPrompt.className = 'output-prompt';
        outputPrompt.textContent = cell.executionCount !== null ? `Out[${cell.executionCount}]:` : '';
        
        const outputWrapper = document.createElement('div');
        outputWrapper.className = 'cell-output-wrapper';
        
        // Check if output contains HTML table
        if (cell.output.includes('__HTML_TABLE__')) {
            const parts = cell.output.split('__HTML_TABLE__');
            
            // Show text output before table (if any)
            if (parts[0].trim()) {
                const textOutput = document.createElement('pre');
                textOutput.className = 'cell-output';
                textOutput.textContent = parts[0];
                outputWrapper.appendChild(textOutput);
            }
            
            // Show HTML table
            const tableDiv = document.createElement('div');
            tableDiv.className = 'cell-output html-output';
            tableDiv.innerHTML = parts[1];
            outputWrapper.appendChild(tableDiv);
        } else {
            // Regular text output
            const output = document.createElement('pre');
            output.className = 'cell-output';
            output.textContent = cell.output;
            
            if (cell.output.includes('ERROR:') || cell.output.includes('Traceback')) {
                output.classList.add('error');
            }
            
            outputWrapper.appendChild(output);
        }
        
        outputArea.appendChild(outputPrompt);
        outputArea.appendChild(outputWrapper);
        content.appendChild(outputArea);
    }
}

/**
 * Show input modal and wait for user input
 * @param {string} prompt - Prompt text to show
 * @returns {Promise<string|null>} - User input or null if cancelled
 */
function showInputModal(prompt) {
    return new Promise((resolve) => {
        inputPromptText.textContent = prompt;
        inputValue.value = '';
        inputModal.classList.add('active');
        inputValue.focus();
        
        // Store the resolve function
        window.submitInput = () => {
            const value = inputValue.value;
            inputModal.classList.remove('active');
            resolve(value);
        };
        
        window.cancelInput = () => {
            inputModal.classList.remove('active');
            resolve(null);
        };
    });
}

/**
 * Run all cells in sequence
 */
async function runAll() {
    btnRunAll.textContent = '⏳ Running...';
    btnRunAll.disabled = true;
    
    for (let i = 0; i < cells.length; i++) {
        await runCellByIndex(i);
    }
    
    btnRunAll.textContent = '▶▶ Run All';
    btnRunAll.disabled = false;
}


/**
 * Save the current notebook to a file
 */
async function saveNotebook() {
    const name = notebookNameInput.value || 'Untitled';
    
    try {
        const response = await fetch('/api/save_notebook', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                name: name,
                cells: cells.map(c => ({
                    id: c.id,
                    type: c.type || 'code',  // Save cell type
                    code: c.code,
                    output: c.output,
                    executionCount: c.executionCount
                }))
            })
        });
        
        const data = await response.json();
        
        if (data.status === 'ok') {
            // Show brief success indicator
            const originalText = btnSave.textContent;
            btnSave.textContent = '✓ Saved';
            btnSave.style.background = 'linear-gradient(#5cb85c, #4cae4c)';
            btnSave.style.color = 'white';
            
            setTimeout(() => {
                btnSave.textContent = originalText;
                btnSave.style.background = '';
                btnSave.style.color = '';
            }, 2000);
        } else {
            alert(`Failed to save: ${data.error || 'Unknown error'}`);
        }
    } catch (error) {
        alert(`Error saving notebook: ${error.message}`);
    }
}

/**
 * Load a notebook from a file
 */
async function loadNotebook() {
    try {
        // First, get list of saved notebooks
        const listResponse = await fetch('/api/list_notebooks');
        const listData = await listResponse.json();
        
        console.log('List response:', listData);
        
        if (!listData.notebooks || listData.notebooks.length === 0) {
            alert('No saved notebooks found. Please save a notebook first.');
            return;
        }
        
        // Create a selection dialog
        let message = 'Select a notebook to load:\n\n';
        listData.notebooks.forEach((name, idx) => {
            message += `${idx + 1}. ${name}\n`;
        });
        message += '\nEnter the number or name:';
        
        const selection = prompt(message);
        if (!selection) return;
        
        // Determine the notebook name
        let name;
        const num = parseInt(selection);
        if (!isNaN(num) && num > 0 && num <= listData.notebooks.length) {
            name = listData.notebooks[num - 1];
        } else {
            name = selection;
        }
        
        console.log('Loading notebook:', name);
        
        const response = await fetch(`/api/load_notebook?name=${encodeURIComponent(name)}`);
        
        console.log('Load response status:', response.status);
        
        if (!response.ok) {
            const error = await response.json();
            console.error('Load error:', error);
            alert(`Error: ${error.error || 'Failed to load notebook'}`);
            return;
        }
        
        const data = await response.json();
        console.log('Loaded data:', data);
        
        // Clear existing CodeMirror instances properly
        // Don't call toTextArea() on instances that are already removed
        codeMirrorInstances = {};
        
        // Clear cells array first
        cells = [];
        cellCounter = 0;
        
        // Reset session for clean state
        await createNewSession();
        
        // Load cells
        if (!data.cells || !Array.isArray(data.cells)) {
            console.error('Invalid cells data:', data);
            alert('Error: Invalid notebook format');
            return;
        }
        
        cells = data.cells.map((c, idx) => ({
            id: c.id || `cell-${Date.now()}-${idx}`,
            type: c.type || 'code',  // Load cell type
            code: c.code || '',
            output: c.output || '',
            executionCount: c.executionCount || null,
            index: idx
        }));
        
        console.log('Loaded cells:', cells);
        
        cellCounter = cells.length;
        selectedCellIndex = 0;
        
        // Update notebook name
        notebookNameInput.value = name;
        
        renderCells();
        
        alert(`✓ Loaded: ${name}`);
        
    } catch (error) {
        console.error('Load notebook error:', error);
        alert(`Error loading notebook: ${error.message}`);
    }
}

/**
 * List all saved notebooks
 */
async function listNotebooks() {
    try {
        const response = await fetch('/api/list_notebooks');
        const data = await response.json();
        
        if (data.notebooks.length > 0) {
            const list = data.notebooks.map((name, idx) => `${idx + 1}. ${name}`).join('\n');
            alert(`📋 Saved Notebooks (${data.notebooks.length}):\n\n${list}\n\nUse "Load" button to open a notebook.`);
        } else {
            alert('📋 No notebooks saved yet.\n\nUse "Save" button to save your current notebook.');
        }
    } catch (error) {
        alert(`Error listing notebooks: ${error.message}`);
    }
}

// Initialize the app when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}
