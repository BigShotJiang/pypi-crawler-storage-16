from .deprecated import deprecated

__all__ = ["deprecated"]
