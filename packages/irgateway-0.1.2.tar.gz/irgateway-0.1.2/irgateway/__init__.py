"""Python SDK for Zarinpal Payment Gateway with sync and async support."""

__version__ = "0.1.2"
