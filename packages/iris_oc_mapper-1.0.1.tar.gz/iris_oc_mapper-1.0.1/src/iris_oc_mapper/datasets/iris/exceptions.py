class IRISDatasetError(Exception):
    """Custom exception for IRIS dataset operations."""

    pass
