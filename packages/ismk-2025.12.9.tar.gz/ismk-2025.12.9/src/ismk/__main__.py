# This script makes it possible to invoke ismk with 'python3 -m ismk'
from ismk.cli import main

main()
