__author__ = "Johannes Köster"
__copyright__ = "Copyright 2022, Johannes Köster, Vanessa Sochat"
__email__ = "johannes.koester@uni-due.de"
__license__ = "MIT"


executor_plugin_prefix = "ismk-executor-plugin-"
executor_plugin_module_prefix = executor_plugin_prefix.replace("-", "_")
