from ismk.remote import RemoteProviderBase


class RemoteProvider(RemoteProviderBase):
    pass
