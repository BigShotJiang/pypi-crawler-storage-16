"""IssueDB - A command-line issue tracking system for software development projects."""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

from issuedb.models import Issue, Priority, Status

__all__ = ["Issue", "Priority", "Status"]
