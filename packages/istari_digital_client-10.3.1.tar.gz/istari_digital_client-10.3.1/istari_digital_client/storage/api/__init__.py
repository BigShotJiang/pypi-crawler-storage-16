# flake8: noqa

# import apis into api package
from istari_digital_client.storage.api.storage_api import StorageApi
