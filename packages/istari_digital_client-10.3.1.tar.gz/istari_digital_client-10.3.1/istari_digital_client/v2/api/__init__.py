# flake8: noqa

# import apis into api package
from istari_digital_client.v2.api.v2_api import V2Api
