"""Activate the representation of Pandas dataframes as interactive tables"""

from .javascript import init_notebook_mode

init_notebook_mode()
