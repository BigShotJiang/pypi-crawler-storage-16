"""ITables' version number"""

# Must match [N!]N(.N)*[{a|b|rc}N][.postN][.devN], cf. PEP 440
__version__ = "2.6.1"
