from .ITable import ITable

__all__ = [
    "ITable"
]