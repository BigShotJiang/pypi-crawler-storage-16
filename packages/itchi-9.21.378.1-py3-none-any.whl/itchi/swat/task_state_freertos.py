import logging
import itchi.taskstate.instrumentation_freertos as instrumentation_freertos
import itchi.type_enum
from itchi.config import InstrumentationTypeEnum
from itchi.swat.state import SwatState
from itchi.profilerxml.model import SwatObjectProperties, TaskState
from itchi.swat.encoding import ObjectEncoding, OBJECT_ENCODING_THREADS_TYPE_NAME, size_to_mask


def get_freertos_encoding(state: SwatState):
    encoding = state.generic_encoding.model_copy()
    encoding.type_id_name = OBJECT_ENCODING_THREADS_TYPE_NAME
    encoding.type_id_key = state.get_and_inc_type_id_key()

    encoding.state_id_offset = encoding.type_id_size
    encoding.state_id_size = 3

    encoding.object_id_offset = encoding.state_id_offset + encoding.state_id_size
    # TODO(felixm): Should we parse the highest thread ID from the task_tags_file
    # or should winIDEA do that check?
    encoding.object_id_size = 8

    state.freertos_task_encoding = encoding
    return encoding


def get_task_state_swat(encoding: ObjectEncoding):
    return TaskState(
        mask_id=size_to_mask(
            encoding.object_id_size, encoding.object_id_offset - encoding.type_id_size
        ),
        mask_state=size_to_mask(
            encoding.state_id_size, encoding.state_id_offset - encoding.type_id_size
        ),
        type=itchi.type_enum.TASK_STATE_MAPPING,
    )


def get_freertos_object_properties(encoding: ObjectEncoding) -> SwatObjectProperties:
    data_size = encoding.core_id_size + encoding.state_id_size + encoding.object_id_size
    data_offset = encoding.type_id_size
    return SwatObjectProperties(
        type_value=encoding.type_id_key,
        data_size=data_size,
        data_offset=data_offset,
    )


def task_state_swat_freertos(state: SwatState):
    logging.info("Create SWAT configuration for freeRTOS Task tracing.")
    profiler_xml = state.profiler_xml
    config = state.config

    if config.task_state_inst_freertos is None:
        m = "task_state_inst_freertos must be configured for --task_state_swat_freertos command"
        raise ValueError(m)

    if config.task_state_inst_freertos.instrumentation_type != InstrumentationTypeEnum.SWAT:
        config.task_state_inst_freertos.instrumentation_type = InstrumentationTypeEnum.SWAT
        logging.warning("Forcing 'swat' for task_state_swat_freertos")

    thread_type_enum = instrumentation_freertos.get_thread_mapping_type_enum(
        config.task_state_inst_freertos.task_tags_file
    )
    profiler_xml.set_type_enum(thread_type_enum)

    state_type_enum = instrumentation_freertos.get_state_mapping_freertos()
    profiler_xml.set_type_enum(state_type_enum)

    thread_encoding = get_freertos_encoding(state)
    thread_object = instrumentation_freertos.get_thread_object(config.task_state_inst_freertos)
    thread_object.swat_object_properties = get_freertos_object_properties(thread_encoding)
    thread_object.task_state = get_task_state_swat(thread_encoding)
    thread_object.expression = None
    thread_object.signaling = "SWAT"
    profiler_xml.set_object(thread_object)

    instrumentation_freertos.write_instrumentation_code(config.task_state_inst_freertos)
