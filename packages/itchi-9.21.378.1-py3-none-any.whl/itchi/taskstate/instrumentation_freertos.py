import logging
from pathlib import Path

import itchi.type_enum
from itchi.templates.render import render_template_from_templates_and_write
from itchi.profilerxml.model import ProfilerXml, ProfilerObject, TaskState, TypeEnum, Enum
from itchi.config import ItchiConfig, TaskStateInstFreertosConfig, InstrumentationTypeEnum


def task_state_instrumentation_freertos(profiler_xml: ProfilerXml, config: ItchiConfig):
    logging.info("Running task_state_instrumentation_freertos")

    if config.task_state_inst_freertos is None:
        raise ValueError(
            "task_state_inst_freertos' must be configured for --task_state_instrumentation_freertos"
        )

    if config.task_state_inst_freertos.instrumentation_type != InstrumentationTypeEnum.DATA_TRACE:
        config.task_state_inst_freertos.instrumentation_type = InstrumentationTypeEnum.DATA_TRACE
        logging.warning("Forcing 'data_trace' for task_state_instrumentation_freertos")

    profiler_xml.name = "freeRTOS"
    profiler_xml.orti = None

    thread_type_enum = get_thread_mapping_type_enum(config.task_state_inst_freertos.task_tags_file)
    profiler_xml.set_type_enum(thread_type_enum)

    state_type_enum = get_state_mapping_freertos()
    profiler_xml.set_type_enum(state_type_enum)

    thread = get_thread_object(config.task_state_inst_freertos)
    profiler_xml.set_object(thread)

    write_instrumentation_code(config.task_state_inst_freertos)


def get_state_mapping_freertos() -> TypeEnum:
    return TypeEnum(
        name=itchi.type_enum.TASK_STATE_MAPPING,
        enums=[
            Enum("RUNNING", "1", task_state_property="RUNNING"),
            Enum("READY", "2", task_state_property="READY"),
            Enum("DELETED", "3", task_state_property="TERMINATED"),
            Enum("BLOCKED", "4", task_state_property="WAITING"),
            Enum("SUSPENDED", "5", task_state_property="WAITING"),
        ],
    )


def get_thread_mapping_type_enum(header_file_name: Path):
    return TypeEnum(
        name=itchi.type_enum.THREAD_MAPPING,
        header_file_name=header_file_name,
    )


def get_task_state_data_trace():
    return TaskState(
        mask_id="0x0000FFFF",
        mask_state="0x00FF0000",
        type=itchi.type_enum.TASK_STATE_MAPPING,
    )


def get_thread_object(config: TaskStateInstFreertosConfig) -> ProfilerObject:
    """Get ProfilerObject for Vector MICROSAR OS Thread profiling."""

    profiler_object = ProfilerObject(
        definition="Threads_Definition",
        description="All Cores: Threads",
        type=itchi.type_enum.THREAD_MAPPING,
        name="Threads_Name",
        level="Task",
        expression=config.trace_variable,
        task_state=get_task_state_data_trace(),
    )
    return profiler_object


def write_instrumentation_code(config: TaskStateInstFreertosConfig):
    kwargs = dict(config)
    TEMPLATE_FILE = Path("FreeRTOS.h")

    destination_file = config.impl_freertos_hooks_h
    if not destination_file or str(destination_file) == "":
        raise ValueError("freeRTOS hooks header implementation file must be valid")

    if config.instrumentation_type not in [
        InstrumentationTypeEnum.DATA_TRACE,
        InstrumentationTypeEnum.SWAT,
    ]:
        raise ValueError(f"{config.instrumentation_type} is currently not supported for freeRTOS")

    include_guard = str(destination_file.name).upper().replace(".", "_")
    kwargs["include_guard_str"] = include_guard

    logging.info(f"Render template '{TEMPLATE_FILE}' into '{destination_file}'.")
    render_template_from_templates_and_write(TEMPLATE_FILE, destination_file, kwargs)
