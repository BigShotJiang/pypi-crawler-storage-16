#ifndef {{ include_guard_str }}
#define {{ include_guard_str }}

/***** CONFIGURATION ********************/

{% if instrumentation_type == "swat" %}
#define WINIDEA_TRACE_MODE_SWAT
{% elif instrumentation_type == "data_trace" %}
#define WINIDEA_TRACE_MODE_HW
{% else %}
#define WINIDEA_TRACE_MODE_NONE
{% endif %}

{% if use_idle_task_check %}
#define WINIDEA_USE_IDLE_TASK_CHECK
#define WINIDEA_IDLE_TASK_TAG   {{ '0x%X' % idle_task_tag }}
#define WINIDEA_FREERTOS_VERSION_MAJOR {{ freertos_major_version }}
{% endif %}

/****************************************/

/* Defines based on the selected trace mode. */

#if defined(WINIDEA_TRACE_MODE_SWAT)

  #include "swat_observer.h"
  #define WINIDEA_TRACE(taskTag, state) SWAT_observe_freertos_task(taskTag, state)

#elif defined(WINIDEA_TRACE_MODE_HW)

  extern volatile unsigned int winidea_trace;
  #define WINIDEA_TASK_STATE_OFFSET 16
  #define WINIDEA_TASK_STATE_MASK   0xFF
  #define WINIDEA_TASK_TAG_OFFSET   0
  #define WINIDEA_TASK_TAG_MASK     0xFFFF
  #define WINIDEA_TRACE(taskTag, state) {{ trace_variable }} =                   \
      ((taskTag & WINIDEA_TASK_TAG_MASK) << WINIDEA_TASK_TAG_OFFSET) |    \
      ((state & WINIDEA_TASK_STATE_MASK) << WINIDEA_TASK_STATE_OFFSET)

#elif defined(WINIDEA_TRACE_MODE_NONE)

  /* Nothing needed. The rest of this file will be excluded. */

#else

  #error "One of WINIDEA_TRACE_MODE_XXX macros must be defined."

#endif /* defined(WINIDEA_TRACE_MODE_XXX) */


/* Only include the rest of the file if the selected trace mode is not 'None'. */
#if !defined(WINIDEA_TRACE_MODE_NONE)


/* Defines based on whether idle check is enabled. */

#if defined(WINIDEA_USE_IDLE_TASK_CHECK)

  #if !defined(WINIDEA_IDLE_TASK_TAG)
    #error "WINIDEA_IDLE_TASK_TAG must be defined to use idle task check."
  #endif

  #if !defined(WINIDEA_FREERTOS_VERSION_MAJOR)
    #error "WINIDEA_FREERTOS_VERSION_MAJOR must be defined to use idle task check."
  #endif

  #if WINIDEA_FREERTOS_VERSION_MAJOR >= 11u
    #define WINIDEA_IDLE_TASK_HANDLE xIdleTaskHandles[0]
  #else
    #define WINIDEA_IDLE_TASK_HANDLE xIdleTaskHandle
  #endif

  #define WINIDEA_TRACE_TASK(pxTCB, state)                    \
      if (pxTCB == WINIDEA_IDLE_TASK_HANDLE)                  \
      {                                                       \
        WINIDEA_TRACE(WINIDEA_IDLE_TASK_TAG, state);          \
      }                                                       \
      else                                                    \
      {                                                       \
        WINIDEA_TRACE((unsigned int)pxTCB->pxTaskTag, state); \
      }

#else /* !defined(WINIDEA_USE_IDLE_TASK_CHECK) */

  #define WINIDEA_TRACE_TASK(pxTCB, state) \
      WINIDEA_TRACE((unsigned int)pxTCB->pxTaskTag, state);

#endif /* defined(WINIDEA_USE_IDLE_TASK_CHECK) */


/* Task State Mapping */

#define WINIDEA_RUNNING         1
#define WINIDEA_READY           2
#define WINIDEA_DELETE          3
#define WINIDEA_BLOCKED         4
#define WINIDEA_SUSPENDED       5


/* Helper macros */

#define WINIDEA_SET_STATE_UNLESS_CURRENT(pxTCB, state)                                  \
    if ( ((unsigned int)pxTCB->pxTaskTag) != ((unsigned int)pxCurrentTCB->pxTaskTag) )  \
    {                                                                                   \
      WINIDEA_TRACE_TASK(pxTCB, state);                                                 \
    }
    
#define WINIDEA_IS_IN_LIST(list) \
    ((TCB_t*)pxCurrentTCB)->xStateListItem.pxContainer == &list

#define traceTASK_SWITCHED_OUT()                            \
    if( WINIDEA_IS_IN_LIST(xDelayedTaskList1)               \
         || WINIDEA_IS_IN_LIST(xDelayedTaskList2)           \
         || WINIDEA_IS_IN_LIST(xPendingReadyList) )         \
     {                                                      \
       WINIDEA_TRACE_TASK(pxCurrentTCB, WINIDEA_BLOCKED);   \
     }                                                      \
     else if(WINIDEA_IS_IN_LIST(xSuspendedTaskList))        \
     {                                                      \
       WINIDEA_TRACE_TASK(pxCurrentTCB, WINIDEA_SUSPENDED); \
     }                                                      \
     else if(WINIDEA_IS_IN_LIST(xTasksWaitingTermination))  \
     {                                                      \
       WINIDEA_TRACE_TASK(pxCurrentTCB, WINIDEA_DELETE);    \
     }                                                      \
     else                                                   \
     {                                                      \
       WINIDEA_TRACE_TASK(pxCurrentTCB, WINIDEA_READY);     \
     }


/* FreeRTOS trace hooks implementation */

#define traceTASK_SWITCHED_IN() \
    WINIDEA_TRACE_TASK(pxCurrentTCB, WINIDEA_RUNNING);
    
#define traceMOVED_TASK_TO_READY_STATE(pxTCB) \
    WINIDEA_SET_STATE_UNLESS_CURRENT(pxTCB, WINIDEA_READY);
    
#define traceTASK_DELETE(pxTCB) \
    WINIDEA_SET_STATE_UNLESS_CURRENT(pxTCB, WINIDEA_DELETE); 
    
#define traceTASK_SUSPEND(pxTCB) \
    WINIDEA_SET_STATE_UNLESS_CURRENT(pxTCB, WINIDEA_SUSPENDED);
    
#define traceTASK_RESUME(pxTCB) \
    WINIDEA_SET_STATE_UNLESS_CURRENT(pxTCB, WINIDEA_READY);
    
#define traceTASK_RESUME_FROM_ISR(pxTCB) \
    WINIDEA_SET_STATE_UNLESS_CURRENT(pxTCB, WINIDEA_READY);


#endif /* !defined(WINIDEA_TRACE_MODE_NONE) */

#endif /* {{ include_guard_str }} */
