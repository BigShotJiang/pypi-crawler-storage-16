import os
import jinja2
import logging
from pathlib import Path
from typing import Optional


def render_template(template_file_path: Path, kwargs) -> Optional[str]:
    """Use Jinja2 to render kwargs into filename and return result as string."""
    searchpath = os.path.dirname(template_file_path)
    loader = jinja2.FileSystemLoader(searchpath=searchpath)
    env = jinja2.Environment(loader=loader, trim_blocks=True, lstrip_blocks=True)
    template = env.get_template(os.path.basename(template_file_path))
    result = template.render(**kwargs)
    if isinstance(result, str):
        return result
    else:
        msg = f"Failed to render template {template_file_path}."
        logging.critical(msg)
        return None


def render_template_from_templates(template_file_name: Path, kwargs) -> Optional[str]:
    """Render kwargs into file in templates directory that comes with iTCHi."""
    # The location where render.py (aka __file__) is located is where the other
    # templates are, too.
    templates_path = os.path.abspath(os.path.dirname(__file__))
    return render_template(Path(os.path.join(templates_path, template_file_name)), kwargs)


def render_template_from_templates_and_write(template_file: Path, target_file: Path, kwargs):
    """Render kwargs into one of the templates that comes with iTCHi and write into target_file."""
    content = render_template_from_templates(template_file, kwargs)
    if content is None:
        raise ValueError(f"Could not render '{template_file}'")

    target_file = Path(target_file)
    target_file.parent.mkdir(parents=True, exist_ok=True)
    with open(target_file, "w", encoding="utf-8") as f:
        f.write(content)


def render_string(input: str, **kwargs) -> Optional[str]:
    template = jinja2.Template(input)
    result = template.render(**kwargs)
    return result
