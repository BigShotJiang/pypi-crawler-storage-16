.. _api_ref:

=============
API Reference
=============

.. automodule:: iterative_ensemble_smoother

.. raw:: latex

    \clearpage
