**Date**: |today| **Version**: |version|

.. mdinclude:: ../../README.md

.. toctree::
   :hidden:
   :maxdepth: 1

   examples
   api
   glossary
   bibliography


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
