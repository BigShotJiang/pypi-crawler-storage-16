from django.apps import AppConfig


class ItoutilsAppConfig(AppConfig):
    name = "itoutils"
