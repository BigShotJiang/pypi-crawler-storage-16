def test_module_import():
    import itoutils  # noqa: F401
