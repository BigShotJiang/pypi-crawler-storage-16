# pylint: skip-file
"""Java API Specification."""

from setuptools import setup

setup()
