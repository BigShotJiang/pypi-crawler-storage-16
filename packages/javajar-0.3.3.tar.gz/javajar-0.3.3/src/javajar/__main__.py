if __name__ == "__main__":
    from javajar.cli import app
    app()