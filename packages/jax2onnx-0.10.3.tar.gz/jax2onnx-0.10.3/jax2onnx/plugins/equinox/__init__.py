# jax2onnx/plugins/equinox/__init__.py

"""Plugins for Equinox modules in the IR-only pipeline."""
