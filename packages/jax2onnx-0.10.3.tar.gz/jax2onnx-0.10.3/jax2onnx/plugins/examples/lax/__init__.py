# jax2onnx/plugins/examples/lax/__init__.py

"""Lax examples for the converter pipeline."""
