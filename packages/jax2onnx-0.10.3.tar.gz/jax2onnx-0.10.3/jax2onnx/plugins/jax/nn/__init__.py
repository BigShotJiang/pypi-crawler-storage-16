# jax2onnx/plugins/jax/nn/__init__.py

"""IR-only jax.nn primitive lowerings."""
