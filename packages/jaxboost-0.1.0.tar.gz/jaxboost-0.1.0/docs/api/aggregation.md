# Aggregation

Boosting aggregation functions.

::: jaxboost.aggregation.boosting

