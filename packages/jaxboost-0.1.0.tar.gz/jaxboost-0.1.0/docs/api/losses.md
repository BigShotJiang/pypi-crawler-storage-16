# Losses

Loss functions for training.

## Regression Losses

::: jaxboost.losses.regression

## Classification Losses

::: jaxboost.losses.classification

