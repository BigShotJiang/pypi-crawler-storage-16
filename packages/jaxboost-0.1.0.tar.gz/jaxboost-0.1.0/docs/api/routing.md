# Routing

Soft routing functions for differentiable trees.

::: jaxboost.routing.soft

