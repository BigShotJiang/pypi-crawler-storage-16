# Structures

Tree structures for gradient boosting.

## Oblivious Trees

::: jaxboost.structures.oblivious
    options:
      members:
        - ObliviousTree
        - ObliviousTreeParams

