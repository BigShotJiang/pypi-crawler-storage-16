# Training

High-level training API for JAXBoost.

::: jaxboost.training
    options:
      members:
        - GBMTrainer
        - TrainerConfig

