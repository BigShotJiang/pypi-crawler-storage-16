"""Version information for jaxboost."""

__version__ = "0.1.0"

