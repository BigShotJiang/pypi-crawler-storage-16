"""Aggregation functions for jaxboost."""

from jaxboost.aggregation.boosting import boosting_aggregate

__all__ = [
    "boosting_aggregate",
]
