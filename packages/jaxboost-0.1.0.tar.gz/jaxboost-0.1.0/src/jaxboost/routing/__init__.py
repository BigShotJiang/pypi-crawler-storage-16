"""Routing functions for jaxboost."""

from jaxboost.routing.soft import soft_routing

__all__ = [
    "soft_routing",
]
