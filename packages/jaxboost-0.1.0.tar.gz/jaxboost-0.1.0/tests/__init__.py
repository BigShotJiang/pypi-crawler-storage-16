"""Tests for jaxboost."""

