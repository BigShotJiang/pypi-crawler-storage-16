Math
====

.. currentmodule:: jaxsim.math

.. automodule:: jaxsim.math.adjoint
    :members:
    :undoc-members:

.. automodule:: jaxsim.math.cross
    :members:
    :undoc-members:

.. automodule:: jaxsim.math.inertia
    :members:
    :undoc-members:

.. automodule:: jaxsim.math.quaternion
    :members:
    :undoc-members:

.. automodule:: jaxsim.math.rotation
    :members:
    :undoc-members:

.. automodule:: jaxsim.math.skew
    :members:
    :undoc-members:
