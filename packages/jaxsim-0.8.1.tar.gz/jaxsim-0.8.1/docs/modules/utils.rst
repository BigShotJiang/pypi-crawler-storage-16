Utils
=====

.. automodule:: jaxsim.utils
    :members:
    :inherited-members:

.. autoclass:: jaxsim.utils.JaxsimDataclass
    :members:
    :inherited-members:
