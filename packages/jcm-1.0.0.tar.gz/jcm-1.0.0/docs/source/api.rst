API
===

.. autosummary::
   :toctree: generated
   :recursive:

   jcm.model
   jcm.model.Model
   jcm.physics_interface
   jcm.physics_interface.PhysicsState
   jcm.physics_interface.PhysicsTendency
   jcm.physics_interface.Physics
