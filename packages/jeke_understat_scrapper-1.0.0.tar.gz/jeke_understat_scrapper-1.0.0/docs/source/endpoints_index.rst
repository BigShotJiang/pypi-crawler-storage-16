Endpoints
=========

.. toctree::
    :maxdepth: 2
    :caption: Contents:

    BaseEndPoint <understatapi.endpoints.base.rst>
    LeagueEndpoint <understatapi.endpoints.league.rst>
    MatchEndpoint <understatapi.endpoints.match.rst>
    PlayerEndpoint <understatapi.endpoints.player.rst>
    TeamEndpoint <understatapi.endpoints.team.rst>