"""tests"""

from .mock_requests import mocked_requests_get
