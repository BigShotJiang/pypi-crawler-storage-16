"""An API for scraping data from understat.com"""

from .api import UnderstatClient

__version__ = "1.0.0"
