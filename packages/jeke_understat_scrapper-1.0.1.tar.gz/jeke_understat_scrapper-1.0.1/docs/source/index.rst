understatAPI Home
=================

.. toctree::
   :hidden:

   self

.. toctree::
   :maxdepth: 2

   Usage <usage.md>
   API Referance <api_index.rst>
   Glossary <glossary.rst>

.. mdinclude:: README.md

