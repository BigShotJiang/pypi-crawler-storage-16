#!/usr/bin/env sh
pip install -r requirements.txt -r test_requirements.txt
pip install -r docs_requirements.txt

