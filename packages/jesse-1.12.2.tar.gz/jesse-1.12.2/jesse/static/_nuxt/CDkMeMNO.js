import{O as a,P as e,Q as t}from"./BZBcjETW.js";const s=a((r,o)=>{if(e().plan==="free"||e().plan==="guest")return t("/")});export{s as default};
