# jinjitest

This is a demo package for testing purposes (jinjitest).

## Installation

```bash
pip install jinjitest
```

## Usage

```python
from jinjitest import emergency_call

result = emergency_call()
print(result)
```
