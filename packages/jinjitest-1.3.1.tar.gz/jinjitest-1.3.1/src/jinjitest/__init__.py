def emergency_call():
    print("This is a critical function from jinjitest package v1.3.1!")
    return "Help is on the way!"
