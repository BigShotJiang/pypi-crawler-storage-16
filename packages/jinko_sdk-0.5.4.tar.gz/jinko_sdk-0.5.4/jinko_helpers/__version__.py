"""
jinko_helpers package version number (auto-generated).
"""

__version__ = "0.5.4"
