'''
Date: 2025-10-28 16:49:49
LastEditors: Xinxiang Sun sunxx@nao.cas.cn
LastEditTime: 2025-10-29 12:33:37
FilePath: /research/jinwu/src/jinwu/physics/radiation.py
'''
import naima
from naima.radiative import InverseCompton, Synchrotron, Bremsstrahlung
