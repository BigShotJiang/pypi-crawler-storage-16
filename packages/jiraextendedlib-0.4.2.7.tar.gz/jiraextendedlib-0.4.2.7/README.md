# jira_extended_lib

This is an extension to the Jira package to do Ipass autothentication