# Server module for Mirix
# This module contains all server-related functionality

__all__ = ["app"]
