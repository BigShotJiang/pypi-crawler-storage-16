# jmd - JSON to Markdown

Streaming JSON to Markdown converter using blockquote syntax.

## Installation

```bash
pip install jmd
```

## Usage

```bash
# Pipe JSON
cat data.json | jmd

# From file
jmd data.json

# JSONL
cat records.jsonl | jmd

# With head (streaming)
cat huge.json | jmd | head -20

# With key filtering
jq '.items[]' data.json | jmd

```

## Examples

### Example 1
#### Initial JSON
  {"role": "user", "content": "Can you write a python function to add two numbers?"},
  {"role": "assistant", "content": "Sure! Here it is:\n\n```python\ndef add(a, b):\n    return a + b\n```"},
  {"role": "user", "content": "Thanks!"},
  {"role": "assistant", "content": "You're welcome."}

#### Converted Markdown
```markdown
> > role: user  
> > content: Can you write a python function to add two numbers?  
>  
> > role: assistant  
> > content:  
> > > Sure! Here it is:  
> > >   
> > > ```python  
> > > def add(a, b):  
> > >     return a + b  
> > > ```  
>  
> > role: user  
> > content: Thanks!  
>  
> > role: assistant  
> > content:  
> > > You're welcome.
```

#### Rendered Markdown
> > role: user  
> > content: Can you write a python function to add two numbers?  
>  
> > role: assistant  
> > content:  
> > > Sure! Here it is:  
> > >   
> > > ```python  
> > > def add(a, b):  
> > >     return a + b  
> > > ```  
>  
> > role: user  
> > content: Thanks!  
>  
> > role: assistant  
> > content:  
> > > You're welcome.


### Example 2
#### Initial JSON
```json
{"name": "Gilbert", "wins": [["straight\nwin", "7♣"], {"Test": ["8"]}]}
```

#### Converted Markdown
```markdown
> name: Gilbert  
> # wins:  
> > > > straight  
> > > > win  
>  
> > > 7♣  
>  
> > > # Test:  
> > > > > 8  
```

#### Rendered Markdown

> name: Gilbert  
> # wins:  
> > > > straight  
> > > > win  
>  
> > > 7♣  
>  
> > > # Test:  
> > > > > 8  


## Python API

```python
from jmd import to_markdown, to_markdown_from_str, stream_json_to_md

# From Python object
md = to_markdown({"name": "Alice", "items": [1, 2, 3]})

# From JSON string
md = to_markdown_from_str('{"key": "value"}')

# Streaming from file
with open("data.json") as f:
    for line in stream_json_to_md(f):
        print(line)
```

## Format

Unstable, subject to change.

| JSON | Markdown |
|------|----------|
| `{"key": "value"}` | `> key: value  ` |
| `{"key": "has: colon"}` | `> key:  ` + `> > has: colon  ` |
| `{"# list": [...]}` | `> # list:  ` + items |
| `{"bad key": v}` | `> <q>bad key</q>: v  ` |
| `[]`, `{}`, `""` | `[]`, `{}`, `""` (inline) |
| Array items | Separated by `>  ` |
| Multiline strings | depth+1, no separator |


## Features

- **Streaming**: O(chunk + max_string + depth) memory
- **C-accelerated**: Uses `json.decoder.scanstring`
- **JSONL support**: Multiple JSON values
- **Pipe-friendly**: Handles `| head` gracefully
