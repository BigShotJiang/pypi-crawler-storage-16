import sys
import os
import json

# Add current directory to path so we can import jmd
sys.path.insert(0, os.getcwd())

from jmd import to_markdown

data = [
  {"role": "user", "content": "Can you write a python function to add two numbers?"},
  {"role": "assistant", "content": "Sure! Here it is:\n\n```python\ndef add(a, b):\n    return a + b\n```"},
  {"role": "user", "content": "Thanks!"},
  {"role": "assistant", "content": "You're welcome."}
]

print("JSON:")
print(json.dumps(data))
print("\nMarkdown:")
print(to_markdown(data))
