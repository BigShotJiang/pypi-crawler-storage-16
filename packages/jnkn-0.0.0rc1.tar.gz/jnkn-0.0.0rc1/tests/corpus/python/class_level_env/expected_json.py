{
  "description": "Env vars at class and module level - tests scope handling",
  "env_vars": [
    {
      "name": "DEFAULT_TIMEOUT",
      "pattern": "os.getenv",
      "line": 6,
      "scope": "module"
    },
    {
      "name": "MAX_RETRIES",
      "pattern": "os.environ.get",
      "line": 7,
      "scope": "module"
    },
    {
      "name": "DATABASE_URL",
      "pattern": "os.getenv",
      "line": 14,
      "scope": "class:Config"
    },
    {
      "name": "REDIS_HOST",
      "pattern": "os.environ.get",
      "line": 15,
      "scope": "class:Config"
    },
    {
      "name": "REDIS_PORT",
      "pattern": "os.environ.get",
      "line": 16,
      "scope": "class:Config"
    },
    {
      "name": "API_KEY",
      "pattern": "os.getenv",
      "line": 19,
      "scope": "class:Config"
    },
    {
      "name": "SESSION_SECRET",
      "pattern": "os.getenv",
      "line": 23,
      "scope": "method:Config.__init__"
    },
    {
      "name": "DB_HOST",
      "pattern": "os.environ[]",
      "line": 29,
      "scope": "class:DatabaseConfig"
    },
    {
      "name": "DB_PORT",
      "pattern": "os.environ.get",
      "line": 30,
      "scope": "class:DatabaseConfig"
    },
    {
      "name": "DB_NAME",
      "pattern": "os.getenv",
      "line": 31,
      "scope": "class:DatabaseConfig"
    }
  ],
  "acceptable_false_positives": ["30", "3", "localhost", "6379", "5432"]
}