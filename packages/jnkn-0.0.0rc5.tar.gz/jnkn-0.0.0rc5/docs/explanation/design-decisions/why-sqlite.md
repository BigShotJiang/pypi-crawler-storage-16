# Why SQLite?

Storage strategy.

