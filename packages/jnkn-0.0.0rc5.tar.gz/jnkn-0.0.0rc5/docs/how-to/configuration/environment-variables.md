# Environment Variables

Configuring Jnkn via env vars.

