# Ignore Files

Using .jnknignore.

