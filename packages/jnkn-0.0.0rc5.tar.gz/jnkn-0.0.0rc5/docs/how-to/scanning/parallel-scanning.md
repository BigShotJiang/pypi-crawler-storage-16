# Parallel Scanning

Optimizing performance.

