# Filtering Scans

Using include/exclude patterns.

