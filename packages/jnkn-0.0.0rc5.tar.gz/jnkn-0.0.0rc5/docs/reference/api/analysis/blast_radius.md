# Blast Radius

::: jnkn.analysis.blast_radius
