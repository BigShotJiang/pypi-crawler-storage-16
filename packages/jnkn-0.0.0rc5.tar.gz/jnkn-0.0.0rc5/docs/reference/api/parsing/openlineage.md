
# OpenLineage Parser

::: jnkn.parsing.openlineage.parser
