# Stitching Engine

::: jnkn.core.stitching
    options:
      show_root_heading: false
      show_source: false
      members:
        - Stitcher
        - MatchConfig
