# Diff

::: jnkn.cli.commands.diff
    options:
      show_root_heading: false
      show_source: false
