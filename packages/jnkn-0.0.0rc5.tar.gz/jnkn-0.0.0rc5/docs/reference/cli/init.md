# Init

::: jnkn.cli.commands.initialize
    options:
      show_root_heading: false
      show_source: false
