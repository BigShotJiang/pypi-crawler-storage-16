# Stats

::: jnkn.cli.commands.stats
    options:
      show_root_heading: false
      show_source: false
