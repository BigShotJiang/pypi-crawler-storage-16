# Suppress

::: jnkn.cli.commands.suppress
    options:
      show_root_heading: false
      show_source: false
