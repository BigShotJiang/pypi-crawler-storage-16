# JavaScript Patterns

Supported JavaScript patterns.

