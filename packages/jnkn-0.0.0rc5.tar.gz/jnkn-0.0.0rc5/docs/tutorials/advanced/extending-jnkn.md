# Extending Jnkn

Using the plugin architecture.

