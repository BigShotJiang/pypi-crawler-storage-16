# Confidence Tuning

Adjusting matching thresholds for your organization.

