"""Generated protobuf modules for Joblet SDK."""

# This package contains auto-generated protobuf code
# Import the modules directly, not through this __init__.py

__all__ = ["joblet_pb2", "joblet_pb2_grpc"]
