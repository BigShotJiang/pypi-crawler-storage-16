"""Common utilities module"""

from common.logging import setup_logging

__all__ = ["setup_logging"]
