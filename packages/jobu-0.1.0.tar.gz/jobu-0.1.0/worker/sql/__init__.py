"""Worker SQL 쿼리"""
