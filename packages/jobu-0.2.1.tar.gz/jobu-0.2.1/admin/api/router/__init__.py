"""Admin API 라우터 패키지"""

from admin.api.router.api import router

__all__ = ['router']
