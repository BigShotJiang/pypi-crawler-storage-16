"""jobu - Python 기반 통합 배치 스케줄링 시스템"""

__version__ = "0.2.1"
