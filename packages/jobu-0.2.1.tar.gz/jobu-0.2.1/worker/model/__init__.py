"""Worker 모델"""

from worker.model.executor import JobInfo

__all__ = ["JobInfo"]
