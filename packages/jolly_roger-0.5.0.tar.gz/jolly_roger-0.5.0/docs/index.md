# jolly-roger

```{include} ../README.md
:start-after: <!-- SPHINX-START -->
```

## Table of contents

```{toctree}
:maxdepth: 1

flagging.md
nulling.md

```

## Indices and tables

- {ref}`genindex`
- {ref}`modindex`
- {ref}`search`
