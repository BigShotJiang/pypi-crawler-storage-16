"""
Copyright (c) 2025 Alec Thomson. All rights reserved.

jolly-roger: The pirate flagger
"""

from __future__ import annotations

from ._version import version as __version__

__all__ = ["__version__"]
