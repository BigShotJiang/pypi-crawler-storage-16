import unittest


class BaseTestCase(unittest.TestCase):
    """Base test case for all jpprint tests."""

    pass
