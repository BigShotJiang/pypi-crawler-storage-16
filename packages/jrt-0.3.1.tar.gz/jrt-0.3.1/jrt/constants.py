ID_KEYS = {"id", "identifier", "identifiant"}
LABEL_KEYS = {"title", "name", "label"}
COMMENT_KEYS = {"description", "comment"}
TYPE_KEYS = {"type", "_typ", "_type"}