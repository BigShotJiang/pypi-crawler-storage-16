# Internal Compatability Shims
import sys


import importlib_resources


__all__ = ["importlib_resources"]
