import aiohttp
from jsmon.analysis.ai_providers import get_ai_provider

async def send_diff_to_ai(session: aiohttp.ClientSession, diff: str, js_url: str, args, source_page: str = None) -> dict:
    """Sends a diff to the configured AI provider for analysis."""
    
    provider_name = getattr(args, 'ai_provider', None)
    api_key = getattr(args, 'ai_api_key', None)
    model = getattr(args, 'ai_model', None)
    
    if not provider_name or not api_key:
        return None

    provider = get_ai_provider(provider_name, api_key, model)
    if not provider:
        if args.debug:
            print(f"[AI] Unknown provider: {provider_name}")
        return None

    context = f"File: {js_url}\nSource Page: {source_page or 'Unknown'}"
    
    if args.debug:
        print(f"[AI] Sending diff to {provider_name} ({len(diff)} chars)...")

    return await provider.analyze_diff(session, diff, context)
