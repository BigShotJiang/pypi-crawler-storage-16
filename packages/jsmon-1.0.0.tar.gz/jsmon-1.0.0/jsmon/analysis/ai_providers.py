import abc
import aiohttp
import json
import asyncio
from typing import Optional, Dict, Any

class AIProvider(abc.ABC):
    """Abstract base class for AI providers."""
    
    def __init__(self, api_key: str, model: str = None):
        self.api_key = api_key
        self.model = model

    @abc.abstractmethod
    async def analyze_diff(self, session: aiohttp.ClientSession, diff: str, context: str) -> Optional[Dict[str, Any]]:
        """Analyzes the diff and returns a structured JSON response."""
        pass

class GeminiProvider(AIProvider):
    """Google Gemini API provider."""
    
    BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
    
    def __init__(self, api_key: str, model: str = "gemini-1.5-flash"):
        super().__init__(api_key, model)
        self.url = self.BASE_URL.format(model=self.model)

    async def analyze_diff(self, session: aiohttp.ClientSession, diff: str, context: str) -> Optional[Dict[str, Any]]:
        headers = {"Content-Type": "application/json"}
        params = {"key": self.api_key}
        
        # Parse context for structured info
        ctx_lines = context.split('\n')
        js_file = ctx_lines[0].replace('File: ', '') if len(ctx_lines) > 0 else 'Unknown'
        source_page = ctx_lines[1].replace('Source Page: ', '') if len(ctx_lines) > 1 else 'Unknown'
        
        # Count diff stats
        lines_added = diff.count('\n+')
        lines_removed = diff.count('\n-')
        
        prompt = f"""
🎯 You are a Bug Bounty Hunter's Discovery AI

## Task: Analyze JavaScript Diff for NEW ATTACK SURFACE ONLY

### Context
- **JS File:** {js_file}
- **Loaded From:** {source_page}
- **Diff Stats:** +{lines_added} lines, -{lines_removed} lines

### Your Mission
Find ONLY changes that represent **NEW functionality** or **NEW attack vectors**.

### ✅ FOCUS ON (High Priority):
1. **New API Endpoints**
   - Any new HTTP paths (e.g., `/api/v2/admin/delete`)
   - New fetch/axios calls with different URLs
   - New WebSocket endpoints
   
2. **New Routes/Paths**
   - React Router / Vue Router new routes
   - New page URLs
   
3. **New Parameters**
   - New query parameters
   - New POST body fields
   - New headers being sent
   
4. **Feature Flags / Hidden Features**
   - `if (user.isAdmin)` checks
   - Beta/internal feature toggles
   - New permission checks
   
5. **Authentication Changes**
   - New auth endpoints
   - New token handling
   - New session logic

### ❌ IGNORE (Low Priority / Noise):
- Variable/function renames (unless security-relevant)
- Code style/formatting changes
- Comment updates
- Performance optimizations
- Library updates
- Refactoring without logic changes

### Output Format (JSON):
Return ONLY this exact structure:

{{
    "signals_found": [
        {{
            "rule_id": "new_api_endpoint",
            "context": "Relevant code snippet (max 3 lines)",
            "llm_analysis": {{
                "alert_message": "Short punchy title (e.g., 'Admin User Deletion API Found')",
                "feature_name": "Admin User Management",
                "change_description": "Added new DELETE endpoint for removing users with admin privileges",
                "technical_clues": {{
                    "endpoints": ["/api/v2/admin/users/delete"],
                    "http_method": "DELETE",
                    "required_params": ["userId", "reason"],
                    "code_identifiers": ["deleteAdminUser", "requiresAdminRole"]
                }},
                "location_inference": {{
                    "likely_area": "Admin Panel",
                    "best_guess_url": "{source_page}/admin/users",
                    "confidence": "HIGH",
                    "reasoning": "Endpoint path contains 'admin' and function name matches UI pattern"
                }},
                "test_suggestion": "curl -X DELETE '{source_page}/api/v2/admin/users/delete' -H 'Authorization: Bearer TOKEN' -d '{{\\"userId\\":123,\\"reason\\":\\"test\\"}}'",
                "confidence_score": 0.95,
                "is_trivial": false
            }}
        }}
    ]
}}

**CRITICAL:** 
- If you find ZERO meaningful changes, return: {{"signals_found": []}}
- Do NOT report trivial refactoring
- Focus on ACTIONABLE intelligence for bug hunters
- Include curl/test commands when possible

### Diff to Analyze:
```diff
{diff[:30000]}
```
        """
        
        payload = {
            "contents": [{
                "parts": [{"text": prompt}]
            }],
            "generationConfig": {
                "response_mime_type": "application/json",
                "temperature": 0.1  # Low temperature for consistency
            }
        }

        try:
            async with session.post(self.url, params=params, json=payload, headers=headers, timeout=90) as resp:
                if resp.status != 200:
                    text = await resp.text()
                    print(f"[Gemini] Error {resp.status}: {text}")
                    return None
                
                data = await resp.json()
                try:
                    text_response = data['candidates'][0]['content']['parts'][0]['text']
                    result = json.loads(text_response)
                    
                    # Filter out low-confidence results
                    if 'signals_found' in result:
                        filtered = []
                        for signal in result['signals_found']:
                            llm = signal.get('llm_analysis', {})
                            confidence = llm.get('confidence_score', 1.0)
                            is_trivial = llm.get('is_trivial', False)
                            
                            if confidence >= 0.7 and not is_trivial:
                                filtered.append(signal)
                        
                        result['signals_found'] = filtered
                    
                    return result
                except (KeyError, IndexError, json.JSONDecodeError) as e:
                    print(f"[Gemini] Parsing error: {e}")
                    return None
        except Exception as e:
            print(f"[Gemini] Request failed: {e}")
            return None

class GroqProvider(AIProvider):
    """Groq API provider."""
    
    BASE_URL = "https://api.groq.com/openai/v1/chat/completions"
    
    def __init__(self, api_key: str, model: str = "llama3-70b-8192"):
        super().__init__(api_key, model)

    async def analyze_diff(self, session: aiohttp.ClientSession, diff: str, context: str) -> Optional[Dict[str, Any]]:
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        system_prompt = """
        You are a JavaScript Security & Functionality Analyst.
        Analyze the provided git diff. Identify NEW functionality, API endpoints, or security risks.
        Return ONLY valid JSON matching the specified schema. No markdown.
        """
        
        user_prompt = f"""
        Context: {context}
        
        Schema:
        {{
            "signals_found": [
                {{
                    "rule_id": "new_functionality",
                    "context": "snippet",
                    "llm_analysis": {{
                        "alert_message": "Title",
                        "feature_name": "Feature Name",
                        "change_description": "Description",
                        "technical_clues": {{ "endpoints": [], "code_identifiers": [] }},
                        "location_inference": {{ "likely_area": "Area", "confidence": "HIGH" }},
                        "test_suggestion": "Test steps"
                    }}
                }}
            ]
        }}

        DIFF:
        {diff[:15000]}
        """

        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            "response_format": {"type": "json_object"}
        }

        try:
            async with session.post(self.BASE_URL, json=payload, headers=headers, timeout=30) as resp:
                if resp.status != 200:
                    text = await resp.text()
                    print(f"[Groq] Error {resp.status}: {text}")
                    return None
                
                data = await resp.json()
                content = data['choices'][0]['message']['content']
                return json.loads(content)
        except Exception as e:
            print(f"[Groq] Request failed: {e}")
            return None

class OpenAIProvider(AIProvider):
    """OpenAI API provider (compatible with any OpenAI-like API)."""
    
    def __init__(self, api_key: str, model: str = "gpt-4o", base_url: str = "https://api.openai.com/v1/chat/completions"):
        super().__init__(api_key, model)
        self.base_url = base_url

    async def analyze_diff(self, session: aiohttp.ClientSession, diff: str, context: str) -> Optional[Dict[str, Any]]:
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        # Similar logic to Groq/OpenAI standard
        # ... (Implementation omitted for brevity, can be added if requested)
        return None

def get_ai_provider(provider_name: str, api_key: str, model: str = None) -> Optional[AIProvider]:
    if provider_name.lower() == "gemini":
        return GeminiProvider(api_key, model or "gemini-1.5-flash")
    elif provider_name.lower() == "groq":
        return GroqProvider(api_key, model or "llama3-70b-8192")
    return None
