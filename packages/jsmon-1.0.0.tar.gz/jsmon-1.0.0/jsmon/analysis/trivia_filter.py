"""
Trivia Filter - Eliminates noise from JavaScript diff analysis.

This module filters out trivial changes that don't represent new attack surface:
- Variable/function renames
- Code formatting changes
- Comment updates
- Webpack hash changes
- Library version bumps
"""

import re
from typing import Tuple
from difflib import SequenceMatcher

# Patterns for detecting trivial changes
WEBPACK_HASH_PATTERN = re.compile(r'[a-f0-9]{20,}')
VERSION_PATTERN = re.compile(r'\d+\.\d+\.\d+')
COMMENT_PATTERN = re.compile(r'(//.*?$|/\*.*?\*/)', re.MULTILINE | re.DOTALL)

def is_webpack_hash_change(diff: str) -> bool:
    """Detects if diff is primarily webpack hash changes."""
    lines = diff.split('\n')
    hash_changes = 0
    total_changes = 0
    
    for line in lines:
        if line.startswith('+') or line.startswith('-'):
            total_changes += 1
            if WEBPACK_HASH_PATTERN.search(line):
                hash_changes += 1
    
    if total_changes == 0:
        return False
    
    # If >80% of changes are hash-related
    return (hash_changes / total_changes) > 0.8

def is_comment_only_change(diff: str) -> bool:
    """Detects if diff only contains comment changes."""
    lines = diff.split('\n')
    comment_lines = 0
    total_changes = 0
    
    for line in lines:
        if line.startswith('+') or line.startswith('-'):
            total_changes += 1
            # Remove the +/- prefix
            content = line[1:].strip()
            if (content.startswith('//') or 
                content.startswith('/*') or 
                content.startswith('*') or
                content.endswith('*/')):
                comment_lines += 1
    
    if total_changes == 0:
        return False
    
    return (comment_lines / total_changes) > 0.9

def is_formatting_change(diff: str) -> bool:
    """Detects if diff is primarily formatting (whitespace/semicolons)."""
    lines = diff.split('\n')
    
    added = []
    removed = []
    
    for line in lines:
        if line.startswith('+') and not line.startswith('+++'):
            added.append(line[1:])
        elif line.startswith('-') and not line.startswith('---'):
            removed.append(line[1:])
    
    if len(added) != len(removed):
        return False
    
    # Compare without whitespace and semicolons
    formatting_only = 0
    for a, r in zip(added, removed):
        a_normalized = re.sub(r'[\s;,]+', '', a)
        r_normalized = re.sub(r'[\s;,]+', '', r)
        if a_normalized == r_normalized:
            formatting_only += 1
    
    if len(added) == 0:
        return False
    
    return (formatting_only / len(added)) > 0.9

def is_version_bump(diff: str) -> bool:
    """Detects library version updates."""
    lines = diff.split('\n')
    version_changes = 0
    total_changes = 0
    
    for line in lines:
        if line.startswith('+') or line.startswith('-'):
            total_changes += 1
            if VERSION_PATTERN.search(line) and ('version' in line.lower() or 'v=' in line.lower()):
                version_changes += 1
    
    if total_changes == 0:
        return False
    
    return (version_changes / total_changes) > 0.7

def calculate_identifier_rename_ratio(diff: str) -> float:
    """
    Calculates ratio of simple identifier renames.
    Returns 0.0-1.0, where 1.0 = pure rename.
    """
    lines = diff.split('\n')
    
    added = []
    removed = []
    
    for line in lines:
        if line.startswith('+') and not line.startswith('+++'):
            added.append(line[1:].strip())
        elif line.startswith('-') and not line.startswith('---'):
            removed.append(line[1:].strip())
    
    if not added or not removed:
        return 0.0
    
    # Use SequenceMatcher to detect structural similarity
    matcher = SequenceMatcher(None, ' '.join(removed), ' '.join(added))
    similarity = matcher.ratio()
    
    # If structure is >85% similar, likely just renames
    return similarity if similarity > 0.85 else 0.0

def extract_new_strings(diff: str) -> list:
    """Extracts new string literals from diff (potential endpoints/features)."""
    lines = diff.split('\n')
    new_strings = []
    
    # Match strings in quotes
    string_pattern = re.compile(r'''["']([^"']+)["']''')
    
    for line in lines:
        if line.startswith('+') and not line.startswith('+++'):
            matches = string_pattern.findall(line)
            for match in matches:
                # Filter out common noise
                if (len(match) > 3 and 
                    not match.isdigit() and
                    '/' in match or '?' in match or 'api' in match.lower()):
                    new_strings.append(match)
    
    return new_strings

def calculate_trivia_score(diff: str) -> float:
    """
    Comprehensive trivia score calculation.
    Returns 0.0-1.0, where 1.0 = completely trivial.
    """
    if not diff or len(diff) < 10:
        return 1.0
    
    scores = []
    
    # Check individual trivia types
    if is_webpack_hash_change(diff):
        scores.append(1.0)
    
    if is_comment_only_change(diff):
        scores.append(1.0)
    
    if is_formatting_change(diff):
        scores.append(1.0)
    
    if is_version_bump(diff):
        scores.append(0.9)
    
    # Check rename ratio
    rename_ratio = calculate_identifier_rename_ratio(diff)
    scores.append(rename_ratio)
    
    # Check if there are new strings (potential endpoints)
    new_strings = extract_new_strings(diff)
    if new_strings:
        # Presence of new API-like strings reduces trivia
        scores.append(max(0.0, 0.5 - len(new_strings) * 0.1))
    
    # If no scores, assume non-trivial
    if not scores:
        return 0.0
    
    # Return max score (most trivial indicator wins)
    return max(scores)

async def should_analyze_with_ai(diff: str, js_url: str, debug: bool = False) -> Tuple[bool, str]:
    """
    Determines if a diff should be sent to AI for analysis.
    
    Returns:
        (should_analyze: bool, reason: str)
    """
    # Fast checks first
    if is_webpack_hash_change(diff):
        return False, "webpack_hash"
    
    if is_comment_only_change(diff):
        return False, "comments_only"
    
    if is_formatting_change(diff):
        return False, "formatting_only"
    
    if is_version_bump(diff):
        return False, "version_bump"
    
    # Comprehensive trivia check
    trivia_score = calculate_trivia_score(diff)
    
    if debug:
        print(f"[TRIVIA] {js_url}: score={trivia_score:.2f}")
    
    # Threshold: 0.75 = likely trivial
    if trivia_score > 0.75:
        return False, f"trivial_score_{trivia_score:.2f}"
    
    # Extract meaningful indicators
    new_strings = extract_new_strings(diff)
    if new_strings and debug:
        print(f"[TRIVIA] Found {len(new_strings)} potential new strings/endpoints")
    
    return True, "significant_change"
