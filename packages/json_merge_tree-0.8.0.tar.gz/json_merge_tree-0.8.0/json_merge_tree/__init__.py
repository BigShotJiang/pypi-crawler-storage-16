from json_merge_tree.json_objects import merge, merge_tree

__all__ = 'merge', 'merge_tree'
