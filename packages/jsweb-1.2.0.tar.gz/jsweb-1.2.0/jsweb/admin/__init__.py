# This file makes the 'admin' directory a Python package.
from jsweb.admin.views import Admin
