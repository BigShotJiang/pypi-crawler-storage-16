__version__ = "0.23.10"


def get_version() -> str:
    return __version__
