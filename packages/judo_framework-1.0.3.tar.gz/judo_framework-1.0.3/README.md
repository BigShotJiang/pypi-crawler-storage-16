# Judo Framework 🥋

**The Complete API Testing Framework for Python**

Judo Framework is a comprehensive API testing library for Python that brings all the power and simplicity of Karate Framework to the Python ecosystem. With Judo, you can write expressive, readable API tests using a natural DSL syntax.

## Features

- 🚀 **Complete Karate DSL Implementation** - Full feature parity with Karate Framework
- 🥒 **Behave Integration** - Full BDD support with Gherkin syntax (like Cucumber for Java)
- 🔧 **HTTP/REST API Testing** - Comprehensive HTTP client with advanced features
- 📊 **JSON/XML Processing** - Powerful data manipulation and validation
- 🔍 **JSONPath & XPath Support** - Advanced querying capabilities
- 🎭 **Mock Server** - Built-in mock server for testing
- 🌐 **WebSocket Support** - Real-time communication testing
- 🔐 **Authentication** - OAuth, JWT, Basic Auth, and custom auth schemes
- 📝 **Schema Validation** - JSON Schema and custom validation
- 🎲 **Data Generation** - Built-in fake data generation
- 🔄 **Parallel Execution** - Run tests in parallel for faster execution
- 📈 **Rich Reporting** - Detailed test reports with metrics
- 🎯 **UI Testing** - Selenium and Playwright integration

## Quick Start

### Installation

```bash
pip install judo-framework
```

### Basic Example

```python
from judo import Judo

# Create a Judo instance
judo = Judo()

# Configure base URL
judo.url = "https://jsonplaceholder.typicode.com"

# Make a GET request
response = judo.get("/posts/1")

# Validate response
judo.match(response.status, 200)
judo.match(response.json.userId, 1)
judo.match(response.json.title, "##string")

# POST request with JSON
user_data = {
    "name": "John Doe",
    "email": "john@example.com"
}

response = judo.post("/users", json=user_data)
judo.match(response.status, 201)
```

### DSL Syntax Examples

```python
# Variable assignment
judo.set("baseUrl", "https://api.example.com")
judo.set("userId", 123)

# Conditional logic
if judo.get_var("environment") == "prod":
    judo.set("apiKey", judo.get_env("PROD_API_KEY"))

# Data-driven testing
users = [
    {"name": "Alice", "age": 25},
    {"name": "Bob", "age": 30}
]

for user in users:
    response = judo.post("/users", json=user)
    judo.match(response.status, 201)

# Schema validation
user_schema = {
    "type": "object",
    "properties": {
        "id": {"type": "integer"},
        "name": {"type": "string"},
        "email": {"type": "string", "format": "email"}
    },
    "required": ["id", "name", "email"]
}

judo.match(response.json, user_schema)
```

### BDD Testing with Behave (Gherkin)

```gherkin
Feature: User API Testing
  Background:
    Given I have a Judo API client
    And the base URL is "https://api.example.com"

  Scenario: Get user information
    When I send a GET request to "/users/1"
    Then the response status should be 200
    And the response should contain "name"
    And the response "$.email" should be a valid email

  Scenario: Create new user
    When I send a POST request to "/users" with JSON:
      """
      {
        "name": "John Doe",
        "email": "john@example.com"
      }
      """
    Then the response status should be 201
    And the response "$.name" should be "John Doe"
```

Run with: `behave features/`

## Documentation

- [Getting Started Guide](docs/getting-started.md)
- [DSL Reference](docs/dsl-reference.md)
- [Behave Integration (BDD)](docs/behave-integration.md)
- [HTTP Client](docs/http-client.md)
- [Data Validation](docs/validation.md)
- [Mock Server](docs/mock-server.md)
- [Examples](examples/)

## License

MIT License - see [LICENSE](LICENSE) file for details.

## Contributing

We welcome contributions! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.