"""
Behave integration module - Gherkin DSL support for Judo Framework
Provides step definitions and utilities for BDD testing with Behave
"""

from .steps import *
from .context import JudoContext
from .hooks import *

__all__ = [
    'JudoContext',
    'before_all',
    'before_scenario', 
    'after_scenario',
    'after_all',
    'setup_judo_context'
]

def setup_judo_context(context):
    """
    Setup Judo Framework context for Behave
    
    Args:
        context: Behave context object
    """
    from ..core.judo import Judo
    from ..reporting.reporter import JudoReporter
    
    # Initialize Judo instance
    context.judo = Judo()
    
    # Setup reporter
    context.judo_reporter = JudoReporter("Behave Test Report", "judo_reports")
    
    # Add helper methods to context
    context.get_last_response = lambda: getattr(context, 'response', None)
    context.set_base_url = lambda url: context.judo.set("baseUrl", url)
    
    return context