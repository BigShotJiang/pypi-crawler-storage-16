# 🥋 Judo Framework

**A comprehensive API testing framework for Python, inspired by Karate Framework**

[![PyPI version](https://badge.fury.io/py/judo-framework.svg)](https://badge.fury.io/py/judo-framework)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

[🇪🇸 Español](docs/README_ES.md) | [🇺🇸 English](README.md)

## 🚀 Quick Start

```bash
pip install judo-framework
```

```python
from judo import Judo

# Create Judo instance
judo = Judo()

# Make HTTP request
response = judo.get("https://jsonplaceholder.typicode.com/users/1")

# Validate response using Karate-like DSL
judo.match(response.status, 200)
judo.match(response.json["name"], "##string")
judo.match(response.json["email"], "##email")

print("✅ Test passed!")
```

## 🎯 Key Features

- **🥋 Karate-like DSL** - Familiar syntax for Karate Framework users
- **🥒 BDD Integration** - Full Behave (Gherkin) support with predefined steps
- **🌐 HTTP Testing** - Complete REST API testing capabilities
- **📄 File Support** - JSON/YAML test data management like Karate's `read()` function
- **📊 HTML Reports** - Automatic detailed test reports with request/response details
- **⚡ Parallel Execution** - Run tests in parallel for maximum speed
- **🎭 Mock Server** - Built-in mock server for isolated testing
- **✅ Schema Validation** - JSON schema validation support
- **🔐 Authentication** - JWT, OAuth, Basic Auth support

## 🧪 BDD Testing (Just like Karate!)

**features/api_test.feature:**
```gherkin
Feature: API Testing
  Background:
    Given I set the base URL to "https://jsonplaceholder.typicode.com"
  
  @smoke
  Scenario: Get user data
    When I send a GET request to "/users/1"
    Then the response status should be 200
    And the response should contain:
      | field | value    |
      | name  | ##string |
      | email | ##email  |
      | id    | 1        |
    And the response should match "$.address.city" with "##string"
```

**features/environment.py:**
```python
from judo.behave import setup_judo_context

def before_all(context):
    setup_judo_context(context)
```

**Run tests:**
```bash
behave features/                    # Run all tests
behave features/ --tags @smoke      # Run smoke tests only
```

## 🏃 Custom Test Runners

```python
from judo.runner import BaseRunner

class MyTestRunner(BaseRunner):
    def __init__(self):
        super().__init__(
            features_dir="features",
            parallel=True,
            max_workers=6
        )
    
    def run_smoke_tests(self):
        return self.run(tags=["@smoke"])
    
    def run_api_tests_parallel(self):
        self.set_parallel(True, max_workers=8)
        return self.run(tags=["@api"], exclude_tags=["@manual"])

# Usage
runner = MyTestRunner()
results = runner.run_smoke_tests()
print(f"Tests: {results['passed']}/{results['total']} passed")
```

## 📊 Automatic HTML Reports

Beautiful HTML reports are automatically generated in `judo_reports/` with:
- 📋 Complete request/response details
- ✅ Assertion results with expected vs actual values
- ⏱️ Performance metrics and timing
- 🔍 Error tracking and stack traces
- 📈 Test execution statistics

## 🔧 Installation Options

**Basic Installation (Recommended):**
```bash
pip install judo-framework
```

**With Optional Features:**
```bash
pip install judo-framework[crypto]    # JWT, OAuth, encryption support
pip install judo-framework[xml]       # XPath, SOAP testing support  
pip install judo-framework[browser]   # Selenium, Playwright integration
pip install judo-framework[full]      # All optional features included
```

## 📚 Documentation

| Topic | English | Español |
|-------|---------|---------|
| Getting Started | [📖 English](docs/getting-started.md) | [📖 Español](docs/getting-started_ES.md) |
| DSL Reference | [📖 English](docs/dsl-reference.md) | [📖 Español](docs/dsl-reference_ES.md) |
| Behave Integration | [📖 English](docs/behave-integration.md) | [📖 Español](docs/behave-integration_ES.md) |
| HTML Reporting | [📖 English](docs/html-reporting.md) | [📖 Español](docs/html-reporting_ES.md) |
| Creating Runners | [📖 English](docs/creating-runners.md) | [📖 Español](docs/creating-runners_ES.md) |
| Examples | [📖 English](docs/examples.md) | [📖 Español](docs/examples_ES.md) |
| Author Info | [📖 English](docs/AUTHOR.md) | [📖 Español](docs/AUTHOR_ES.md) |

## 🆚 Migration from Karate

Judo Framework uses the same concepts and similar syntax as Karate:

**Karate (JavaScript):**
```javascript
* def response = call read('get-user.feature')
* match response.name == '#string'
* match response.email == '#email'
```

**Judo (Python):**
```python
response = judo.get("/users/1")
judo.match(response.json["name"], "##string")
judo.match(response.json["email"], "##email")
```

## 🤝 Contributing

We welcome contributions! Here's how to get started:

```bash
git clone https://github.com/judo-framework/judo
cd judo
pip install -e .[dev]
pytest tests/
```

## 📄 License

MIT License - See [LICENSE](LICENSE) for details.

## 👨‍💻 Author

**Created by Felipe Farias at [CENTYC](https://www.centyc.cl)**

[CENTYC](https://www.centyc.cl) - Centro Latinoamericano de Testing y Calidad del Software  
*Latin American Center for Software Testing and Quality*

## 🙏 Acknowledgments

- Inspired by [Karate Framework](https://github.com/karatelabs/karate) by Peter Thomas
- Developed at [CENTYC](https://www.centyc.cl) for the Latin American testing community
- Built for the global Python API testing community
- Special thanks to all contributors

---

**Made with ❤️ at [CENTYC](https://www.centyc.cl) for API testing excellence**