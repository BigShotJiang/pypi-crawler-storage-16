"""
Behave integration module - Gherkin DSL support for Judo Framework
Provides step definitions and utilities for BDD testing with Behave
"""

# Import all steps to register them automatically
from . import steps
from .context import JudoContext
from .hooks import *

# Force import of all step definitions
import sys
import importlib

def _ensure_steps_loaded():
    """Ensure all step definitions are loaded and registered"""
    try:
        # Force reload of steps module to ensure registration
        if 'judo.behave.steps' in sys.modules:
            importlib.reload(sys.modules['judo.behave.steps'])
        else:
            from . import steps
    except Exception as e:
        print(f"Warning: Could not load Judo steps: {e}")

# Load steps immediately
_ensure_steps_loaded()

__all__ = [
    'JudoContext',
    'before_all',
    'before_scenario', 
    'after_scenario',
    'after_all',
    'setup_judo_context'
]

def setup_judo_context(context):
    """
    Setup Judo Framework context for Behave
    
    Args:
        context: Behave context object
    """
    from ..core.judo import Judo
    from ..reporting.reporter import JudoReporter
    
    # Ensure steps are loaded
    _ensure_steps_loaded()
    
    # Initialize Judo context
    context.judo_context = JudoContext(context)
    
    # Initialize Judo instance (for backward compatibility)
    context.judo = context.judo_context.judo
    
    # Setup reporter
    context.judo_reporter = JudoReporter("Behave Test Report", "judo_reports")
    
    # Add helper methods to context
    context.get_last_response = lambda: getattr(context.judo_context, 'response', None)
    context.set_base_url = lambda url: context.judo_context.set_base_url(url)
    
    return context