#!/usr/bin/env python3
"""
Ejemplo de uso del guardado automático de requests y responses
Este ejemplo muestra cómo configurar y usar la funcionalidad de logging
"""

import sys
import os
from pathlib import Path

# Añadir el directorio raíz al path para importar judo
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from judo.runner.base_runner import BaseRunner


def example_with_runner():
    """Ejemplo usando el runner con logging habilitado"""
    print("🎯 Ejemplo 1: Configuración desde el Runner")
    print("=" * 50)
    
    # Crear runner con logging habilitado
    runner = BaseRunner(
        features_dir="examples",
        output_dir="example_output",
        save_requests_responses=True,  # Habilitar logging
        requests_responses_dir="example_output/api_logs"  # Directorio personalizado
    )
    
    # También se puede configurar después de crear el runner
    runner.set_request_response_logging(
        enabled=True,
        directory="example_output/custom_api_logs"
    )
    
    print("✅ Runner configurado con logging de requests/responses")
    print(f"📁 Directorio de salida: {runner.requests_responses_dir}")
    
    # Ejecutar tests (descomentado para el ejemplo)
    # result = runner.run(tags=["@http"])
    # print(f"📊 Resultado: {result}")


def example_with_environment_variables():
    """Ejemplo usando variables de entorno"""
    print("\n🎯 Ejemplo 2: Configuración con Variables de Entorno")
    print("=" * 50)
    
    # Configurar variables de entorno
    os.environ['JUDO_SAVE_REQUESTS_RESPONSES'] = 'true'
    os.environ['JUDO_OUTPUT_DIRECTORY'] = 'env_output/api_requests'
    os.environ['JUDO_LOG_SAVED_FILES'] = 'true'  # Para ver los archivos guardados
    
    print("✅ Variables de entorno configuradas:")
    print(f"   JUDO_SAVE_REQUESTS_RESPONSES = {os.environ.get('JUDO_SAVE_REQUESTS_RESPONSES')}")
    print(f"   JUDO_OUTPUT_DIRECTORY = {os.environ.get('JUDO_OUTPUT_DIRECTORY')}")
    print(f"   JUDO_LOG_SAVED_FILES = {os.environ.get('JUDO_LOG_SAVED_FILES')}")
    
    # Ahora cualquier ejecución de behave usará estas configuraciones
    print("\n💡 Ahora puedes ejecutar:")
    print("   behave examples/complete_showcase.feature --tags=@http")


def example_directory_structure():
    """Mostrar la estructura de directorios que se creará"""
    print("\n🎯 Ejemplo 3: Estructura de Directorios Generada")
    print("=" * 50)
    
    structure = """
    output_directory/
    ├── GET_request_-_Retrieve_a_resource/
    │   ├── 01_GET_143052_request.json
    │   ├── 01_GET_143052_response.json
    │   └── ...
    ├── POST_request_-_Create_a_new_resource/
    │   ├── 01_POST_143053_request.json
    │   ├── 01_POST_143053_response.json
    │   └── ...
    ├── Complete_CRUD_workflow/
    │   ├── 01_POST_143054_request.json    # CREATE
    │   ├── 01_POST_143054_response.json
    │   ├── 02_GET_143055_request.json     # READ
    │   ├── 02_GET_143055_response.json
    │   ├── 03_PUT_143056_request.json     # UPDATE
    │   ├── 03_PUT_143056_response.json
    │   ├── 04_PATCH_143057_request.json   # PARTIAL UPDATE
    │   ├── 04_PATCH_143057_response.json
    │   ├── 05_DELETE_143058_request.json  # DELETE
    │   └── 05_DELETE_143058_response.json
    └── ...
    """
    
    print("📁 Estructura de archivos generada:")
    print(structure)
    
    print("📝 Formato de archivos:")
    print("   • Directorio por escenario (nombre sanitizado)")
    print("   • Archivos numerados secuencialmente")
    print("   • Formato: {contador}_{METODO}_{timestamp}_{request|response}.json")
    print("   • Contenido JSON con todos los detalles de request/response")


def example_json_content():
    """Mostrar el contenido de ejemplo de los archivos JSON"""
    print("\n🎯 Ejemplo 4: Contenido de los Archivos JSON")
    print("=" * 50)
    
    request_example = {
        "method": "POST",
        "url": "https://jsonplaceholder.typicode.com/posts",
        "endpoint": "/posts",
        "headers": {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "Judo-Framework-Behave/1.0"
        },
        "params": {},
        "body": {
            "title": "Judo Framework Test",
            "body": "Testing POST request",
            "userId": 1
        },
        "content_type": "application/json",
        "timestamp": "2024-12-12T14:30:52.123456",
        "scenario": "POST request - Create a new resource"
    }
    
    response_example = {
        "status_code": 201,
        "headers": {
            "Content-Type": "application/json; charset=utf-8",
            "Location": "https://jsonplaceholder.typicode.com/posts/101"
        },
        "body": {
            "id": 101,
            "title": "Judo Framework Test",
            "body": "Testing POST request",
            "userId": 1
        },
        "text": None,
        "elapsed_ms": 245.67,
        "timestamp": "2024-12-12T14:30:52.369123",
        "scenario": "POST request - Create a new resource"
    }
    
    print("📄 Ejemplo de archivo request.json:")
    import json
    print(json.dumps(request_example, indent=2, ensure_ascii=False))
    
    print("\n📄 Ejemplo de archivo response.json:")
    print(json.dumps(response_example, indent=2, ensure_ascii=False))


def example_usage_in_features():
    """Mostrar cómo usar en archivos .feature"""
    print("\n🎯 Ejemplo 5: Uso en Archivos .feature")
    print("=" * 50)
    
    feature_example = '''
# language: en
Feature: API Testing with Request/Response Logging

  Background:
    Given I have a Judo API client
    And the base URL is "https://jsonplaceholder.typicode.com"
    # Habilitar logging para este feature
    And I enable request/response logging to directory "feature_logs"

  @logging
  Scenario: Test with automatic logging
    When I send a GET request to "/users/1"
    Then the response status should be 200
    # Los archivos se guardan automáticamente en:
    # feature_logs/Test_with_automatic_logging/01_GET_xxxxxx_request.json
    # feature_logs/Test_with_automatic_logging/01_GET_xxxxxx_response.json

  @logging
  Scenario: Multiple requests logged
    When I send a POST request to "/posts" with JSON
      """
      {"title": "Test", "body": "Content", "userId": 1}
      """
    Then the response status should be 201
    And I extract "id" from the response as "postId"
    When I send a GET request to "/posts/{postId}"
    Then the response status should be 200
    # Se crean 4 archivos:
    # 01_POST_xxxxxx_request.json, 01_POST_xxxxxx_response.json
    # 02_GET_xxxxxx_request.json, 02_GET_xxxxxx_response.json
    '''
    
    print("📝 Ejemplo de uso en archivo .feature:")
    print(feature_example)
    
    spanish_example = '''
# language: es
Característica: Pruebas API con Logging de Peticiones/Respuestas

  Antecedentes:
    Dado que tengo un cliente API Judo
    Y la URL base es "https://jsonplaceholder.typicode.com"
    # Habilitar logging para esta característica
    Y habilito el guardado de peticiones y respuestas en el directorio "logs_api"

  @logging
  Escenario: Prueba con logging automático
    Cuando hago una petición GET a "/users/1"
    Entonces el código de respuesta debe ser 200
    # Los archivos se guardan automáticamente
    '''
    
    print("\n📝 Ejemplo en español:")
    print(spanish_example)


if __name__ == "__main__":
    print("🥋 Judo Framework - Request/Response Logging Examples")
    print("=" * 60)
    
    example_with_runner()
    example_with_environment_variables()
    example_directory_structure()
    example_json_content()
    example_usage_in_features()
    
    print("\n🎉 ¡Ejemplos completados!")
    print("\n💡 Para probar:")
    print("1. Ejecuta este script: python examples/request_response_logging_example.py")
    print("2. Configura las variables de entorno")
    print("3. Ejecuta tus tests: behave examples/complete_showcase.feature --tags=@http")
    print("4. Revisa los archivos generados en el directorio de salida")