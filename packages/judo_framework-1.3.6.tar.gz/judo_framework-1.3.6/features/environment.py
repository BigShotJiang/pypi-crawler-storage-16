"""
Behave environment configuration for Judo Framework
This file is automatically loaded by Behave and sets up the test environment
"""

import os
import sys

# Add the project root to Python path so we can import judo
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

# Import Judo Behave hooks with different names to avoid conflicts
from judo.behave.hooks import (
    before_all as judo_before_all, 
    before_scenario as judo_before_scenario, 
    after_scenario as judo_after_scenario, 
    after_all as judo_after_all
)
from judo.reporting.reporter import get_reporter


def before_all(context):
    """Setup before all tests"""
    # Call Judo's before_all hook first (this sets up request/response logging)
    judo_before_all(context)


def before_scenario(context, scenario):
    """Setup before each scenario"""
    # Call Judo's before_scenario hook first (this sets the current scenario name for logging)
    judo_before_scenario(context, scenario)
    
    # Start scenario in reporter
    reporter = get_reporter()
    if not hasattr(context, 'current_feature_started'):
        reporter.start_feature(scenario.feature.name, scenario.feature.description or "")
        context.current_feature_started = True
    
    reporter.start_scenario(scenario.name, [tag for tag in scenario.tags])


def after_scenario(context, scenario):
    """Cleanup after each scenario"""
    # Finish scenario in reporter first
    reporter = get_reporter()
    from judo.reporting.report_data import ScenarioStatus
    status = ScenarioStatus.PASSED if scenario.status == "passed" else ScenarioStatus.FAILED
    error_msg = str(scenario.exception) if hasattr(scenario, 'exception') and scenario.exception else None
    reporter.finish_scenario(status, error_msg)
    
    # Call Judo's after_scenario hook
    judo_after_scenario(context, scenario)


def after_all(context):
    """Cleanup after all tests"""
    # Generate HTML report
    reporter = get_reporter()
    reporter.finish_feature()
    report_path = reporter.generate_html_report()
    print(f"\n📊 HTML Report generated: {report_path}")
    
    # Call Judo's after_all hook
    judo_after_all(context)