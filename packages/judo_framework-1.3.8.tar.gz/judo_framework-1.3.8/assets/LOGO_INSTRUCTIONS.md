# 📋 Logo Installation Instructions

## 🎯 Required Files

Please save the logo images in this directory with these exact names:

### 1. Main Logo (Horizontal with Text)
- **Filename**: `judo-framework-logo.png`
- **Description**: The complete logo with "JUDO FRAMEWORK" text
- **Usage**: README files, documentation headers, presentations
- **Recommended size**: 800x200px or similar 4:1 ratio

### 2. Icon Only (Optional)
- **Filename**: `judo-logo-icon.png` 
- **Description**: Just the judoka figure in a circle (for favicons)
- **Usage**: Small spaces, social media, favicons
- **Recommended size**: 200x200px (square)

## 📁 Current Status

- ✅ Directory created: `assets/`
- ✅ README files updated with logo references
- ✅ MANIFEST.in updated to include assets
- ⏳ **PENDING**: Save the actual logo files

## 🚀 Next Steps

1. Save the logo image as `assets/judo-framework-logo.png`
2. Optionally create an icon version as `assets/judo-logo-icon.png`
3. The logos will automatically appear in:
   - Main README.md
   - examples/README.md
   - docs/request-response-logging.md

## 📐 Technical Specifications

### Main Logo
- **Format**: PNG with transparent background
- **Colors**: Black text/figure on transparent background
- **Aspect ratio**: Approximately 4:1 (width:height)
- **Minimum width**: 300px for readability

### Icon (if created)
- **Format**: PNG with transparent background
- **Shape**: Square or circular
- **Colors**: Black figure on white/transparent background
- **Size**: 200x200px minimum

## ✅ Verification

After saving the logo, verify it appears correctly in:
- [ ] README.md (main project page)
- [ ] examples/README.md
- [ ] docs/request-response-logging.md

---

**The logo integration is ready - just save the image file!** 🎨