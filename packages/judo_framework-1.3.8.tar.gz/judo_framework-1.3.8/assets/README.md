# 🎨 Judo Framework Assets

This directory contains branding assets for Judo Framework.

## 📁 Files

### Logos
- `judo-framework-logo.png` - Main logo with text (horizontal)
- `judo-logo-icon.png` - Icon only (circular)

## 🎯 Usage Guidelines

### Main Logo
- **Primary use**: README files, documentation headers, presentations
- **Minimum width**: 300px for readability
- **Background**: Works best on light backgrounds
- **Format**: PNG with transparent background

### Icon Only
- **Primary use**: Favicons, small spaces, social media avatars
- **Minimum size**: 32x32px
- **Background**: Circular white background with black judoka

## 📐 Specifications

### Main Logo (judo-framework-logo.png)
- **Dimensions**: 800x200px (4:1 ratio)
- **Format**: PNG with transparency
- **Colors**: Black text on transparent background
- **Typography**: Bold, modern sans-serif

### Icon (judo-logo-icon.png)
- **Dimensions**: 200x200px (1:1 ratio)
- **Format**: PNG with transparency
- **Style**: Circular white background with black judoka silhouette

## 🚀 Implementation

### In README.md
```markdown
<div align="center">
  <img src="assets/judo-framework-logo.png" alt="Judo Framework Logo" width="400"/>
</div>
```

### As Favicon
```html
<link rel="icon" type="image/png" href="assets/judo-logo-icon.png">
```

### In Documentation
```markdown
![Judo Framework](assets/judo-framework-logo.png)
```

## 🎨 Brand Colors

- **Primary**: Black (#000000)
- **Secondary**: White (#FFFFFF)
- **Accent**: Transparent backgrounds

## 📝 Notes

- Logo represents the discipline and power of Judo martial art
- Minimalist design reflects the framework's simplicity
- Professional appearance suitable for enterprise environments
- Scalable design works at various sizes

## 🌐 More Information

**📖 Official Documentation**: [http://centyc.cl/judo-framework/](http://centyc.cl/judo-framework/)

---

**Created for Judo Framework by CENTYC** 🥋