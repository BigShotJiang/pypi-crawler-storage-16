<div align="center">
  <img src="../assets/judo-framework-logo.png" alt="Judo Framework Logo" width="300"/>
</div>

# Request/Response Logging

Judo Framework provides automatic logging of HTTP requests and responses to JSON files. This feature is useful for debugging, auditing, and creating documentation of API interactions.

## 🎯 Overview

When enabled, Judo Framework automatically saves:
- **Request data**: Method, URL, headers, parameters, body, timestamp
- **Response data**: Status code, headers, body, response time, timestamp
- **Metadata**: Scenario name, request counter, timestamps

Files are organized by scenario name in separate directories, making it easy to trace API interactions for each test case.

## 📁 Directory Structure

```
output_directory/
├── Scenario_Name_1/
│   ├── 01_GET_143052_request.json
│   ├── 01_GET_143052_response.json
│   ├── 02_POST_143053_request.json
│   ├── 02_POST_143053_response.json
│   └── ...
├── Scenario_Name_2/
│   ├── 01_PUT_143054_request.json
│   ├── 01_PUT_143054_response.json
│   └── ...
└── ...
```

### File Naming Convention

- **Format**: `{counter}_{METHOD}_{timestamp}_{type}.json`
- **Counter**: Sequential number (01, 02, 03...)
- **Method**: HTTP method (GET, POST, PUT, PATCH, DELETE)
- **Timestamp**: Time in HHMMSS format
- **Type**: `request` or `response`

## 🚀 Configuration

### 1. Environment Variables

Set these environment variables before running tests:

```bash
# Enable/disable logging
export JUDO_SAVE_REQUESTS_RESPONSES=true

# Set output directory
export JUDO_OUTPUT_DIRECTORY=api_logs

# Show saved file paths (optional)
export JUDO_LOG_SAVED_FILES=true
```

### 2. Runner Configuration

Configure when creating the runner:

```python
from judo.runner.base_runner import BaseRunner

# Configure during initialization
runner = BaseRunner(
    features_dir="features",
    save_requests_responses=True,
    requests_responses_dir="custom_logs"
)

# Or configure after creation
runner.set_request_response_logging(
    enabled=True,
    directory="api_interaction_logs"
)

# Run tests
runner.run(tags=["@api"])
```

### 3. Feature File Configuration

Enable/disable logging within feature files:

```gherkin
# English
Feature: API Testing with Logging

  Background:
    Given I have a Judo API client
    And the base URL is "https://api.example.com"
    And I enable request/response logging to directory "feature_logs"

  Scenario: Test with logging
    When I send a GET request to "/users/1"
    Then the response status should be 200
    
  Scenario: Disable logging for this scenario
    Given I disable request/response logging
    When I send a GET request to "/users/2"
    Then the response status should be 200
```

```gherkin
# Spanish
Característica: Pruebas API con Logging

  Antecedentes:
    Dado que tengo un cliente API Judo
    Y la URL base es "https://api.example.com"
    Y habilito el guardado de peticiones y respuestas en el directorio "logs_caracteristica"

  Escenario: Prueba con logging
    Cuando hago una petición GET a "/users/1"
    Entonces el código de respuesta debe ser 200
```

## 📄 File Content Examples

### Request File (`01_GET_143052_request.json`)

```json
{
  "method": "GET",
  "url": "https://jsonplaceholder.typicode.com/users/1",
  "endpoint": "/users/1",
  "headers": {
    "Content-Type": "application/json",
    "Accept": "application/json",
    "User-Agent": "Judo-Framework-Behave/1.0"
  },
  "params": {
    "limit": "10"
  },
  "body": null,
  "content_type": null,
  "timestamp": "2024-12-12T14:30:52.123456",
  "scenario": "GET request - Retrieve a resource"
}
```

### Response File (`01_GET_143052_response.json`)

```json
{
  "status_code": 200,
  "headers": {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "max-age=43200"
  },
  "body": {
    "id": 1,
    "name": "Leanne Graham",
    "username": "Bret",
    "email": "Sincere@april.biz"
  },
  "text": null,
  "elapsed_ms": 245.67,
  "timestamp": "2024-12-12T14:30:52.369123",
  "scenario": "GET request - Retrieve a resource"
}
```

## 🎮 Available Steps

### English Steps

```gherkin
# Enable/disable logging
Given I enable request/response logging
Given I disable request/response logging

# Enable with custom directory
Given I enable request/response logging to directory "custom_logs"

# Set output directory
Given I set the output directory to "my_logs"
```

### Spanish Steps

```gherkin
# Habilitar/deshabilitar logging
Dado que habilito el guardado de peticiones y respuestas
Dado que deshabilito el guardado de peticiones y respuestas

# Habilitar con directorio personalizado
Dado que habilito el guardado de peticiones y respuestas en el directorio "logs_personalizados"

# Establecer directorio de salida
Dado que establezco el directorio de salida a "mis_logs"
```

## 💡 Use Cases

### 1. Debugging Failed Tests

When a test fails, examine the logged requests and responses to understand what went wrong:

```bash
# Find the scenario directory
ls api_logs/Failed_Scenario_Name/

# Check the last request/response
cat api_logs/Failed_Scenario_Name/03_POST_*_request.json
cat api_logs/Failed_Scenario_Name/03_POST_*_response.json
```

### 2. API Documentation

Use logged requests/responses to create API documentation:

```python
# Script to generate documentation from logs
import json
from pathlib import Path

def generate_api_docs(logs_dir):
    for scenario_dir in Path(logs_dir).iterdir():
        if scenario_dir.is_dir():
            print(f"## {scenario_dir.name}")
            
            for request_file in scenario_dir.glob("*_request.json"):
                with open(request_file) as f:
                    request = json.load(f)
                
                response_file = request_file.with_name(
                    request_file.name.replace("_request.json", "_response.json")
                )
                
                with open(response_file) as f:
                    response = json.load(f)
                
                print(f"### {request['method']} {request['endpoint']}")
                print(f"Status: {response['status_code']}")
                print()

generate_api_docs("api_logs")
```

### 3. Performance Analysis

Analyze response times across scenarios:

```python
import json
from pathlib import Path

def analyze_performance(logs_dir):
    times = []
    
    for response_file in Path(logs_dir).rglob("*_response.json"):
        with open(response_file) as f:
            response = json.load(f)
            times.append({
                'scenario': response['scenario'],
                'method': response_file.name.split('_')[1],
                'elapsed_ms': response['elapsed_ms']
            })
    
    # Sort by response time
    times.sort(key=lambda x: x['elapsed_ms'], reverse=True)
    
    print("Slowest requests:")
    for time_data in times[:10]:
        print(f"{time_data['elapsed_ms']:.2f}ms - {time_data['method']} in {time_data['scenario']}")

analyze_performance("api_logs")
```

### 4. Test Data Extraction

Extract test data from successful requests:

```python
import json
from pathlib import Path

def extract_test_data(logs_dir, output_file):
    test_data = {}
    
    for request_file in Path(logs_dir).rglob("*_request.json"):
        with open(request_file) as f:
            request = json.load(f)
        
        if request['body'] and request['method'] in ['POST', 'PUT', 'PATCH']:
            scenario = request['scenario']
            if scenario not in test_data:
                test_data[scenario] = []
            
            test_data[scenario].append({
                'method': request['method'],
                'endpoint': request['endpoint'],
                'body': request['body']
            })
    
    with open(output_file, 'w') as f:
        json.dump(test_data, f, indent=2)
    
    print(f"Test data extracted to {output_file}")

extract_test_data("api_logs", "extracted_test_data.json")
```

## ⚙️ Advanced Configuration

### Custom File Naming

Modify the `JudoContext` class to customize file naming:

```python
# In judo/behave/context.py
def _save_request_response(self, method, endpoint, request_data, response_data):
    # Custom naming logic
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]  # Include milliseconds
    base_filename = f"{self.request_counter:03d}_{method}_{timestamp}"
    
    # Add endpoint info to filename
    safe_endpoint = endpoint.replace('/', '_').replace('?', '_')
    base_filename = f"{base_filename}_{safe_endpoint}"
    
    # Continue with existing logic...
```

### Filtering Sensitive Data

Remove sensitive information from logs:

```python
def _sanitize_data(self, data):
    """Remove sensitive information from request/response data"""
    if isinstance(data, dict):
        sanitized = data.copy()
        
        # Remove sensitive headers
        if 'headers' in sanitized:
            sensitive_headers = ['Authorization', 'X-API-Key', 'Cookie']
            for header in sensitive_headers:
                sanitized['headers'].pop(header, None)
        
        # Remove sensitive body fields
        if 'body' in sanitized and isinstance(sanitized['body'], dict):
            sensitive_fields = ['password', 'token', 'secret']
            for field in sensitive_fields:
                if field in sanitized['body']:
                    sanitized['body'][field] = "***REDACTED***"
        
        return sanitized
    
    return data
```

## 🔧 Troubleshooting

### Common Issues

1. **Permission Errors**
   ```bash
   # Ensure directory is writable
   chmod 755 output_directory
   ```

2. **Large Files**
   ```python
   # Limit response body size in logs
   if len(response_body) > 10000:  # 10KB limit
       response_data['body'] = f"[TRUNCATED - {len(response_body)} bytes]"
   ```

3. **Special Characters in Scenario Names**
   - Automatically sanitized using `_sanitize_filename()`
   - Invalid characters replaced with underscores

### Performance Considerations

- **Disk Space**: Monitor disk usage with large test suites
- **I/O Impact**: Minimal impact on test execution time
- **Cleanup**: Implement log rotation for long-running test suites

```python
# Cleanup old logs
import shutil
from datetime import datetime, timedelta

def cleanup_old_logs(logs_dir, days_to_keep=7):
    cutoff_date = datetime.now() - timedelta(days=days_to_keep)
    
    for log_dir in Path(logs_dir).iterdir():
        if log_dir.is_dir():
            # Check directory modification time
            if datetime.fromtimestamp(log_dir.stat().st_mtime) < cutoff_date:
                shutil.rmtree(log_dir)
                print(f"Removed old logs: {log_dir}")
```

## 📚 Examples

See the complete examples in:
- `examples/request_response_logging_example.py` - Python configuration examples
- `examples/logging_demo.feature` - English feature file examples
- `examples/demo_logging_es.feature` - Spanish feature file examples

## 🎯 Best Practices

1. **Use descriptive scenario names** - They become directory names
2. **Enable logging selectively** - Only for scenarios that need it
3. **Clean up regularly** - Implement log rotation
4. **Sanitize sensitive data** - Remove passwords, tokens, etc.
5. **Monitor disk usage** - Large test suites generate many files
6. **Use for debugging** - Great for troubleshooting failed tests
7. **Document APIs** - Use logs to generate API documentation

## 🌐 More Information

**📖 Complete Documentation**: [http://centyc.cl/judo-framework/](http://centyc.cl/judo-framework/)

**🔗 Related Links**:
- [Main README](../README.md)
- [Examples](../examples/README.md)
- [GitHub Repository](https://github.com/FelipeFariasAlfaro/Judo-Framework)

---

**Made with ❤️ at CENTYC for API testing excellence** 🥋

*"As simple as Karate, as powerful as Python"*