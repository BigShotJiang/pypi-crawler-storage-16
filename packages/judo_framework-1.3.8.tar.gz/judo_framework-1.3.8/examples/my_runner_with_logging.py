from judo.runner.base_runner import BaseRunner
import os

class MyRunner(BaseRunner):
    def __init__(self):
        # Ajustar rutas a tu estructura
        super().__init__(
            features_dir="../features",  # Subir un nivel y entrar a Features
            output_dir="./judo_reports",  # Reportes en Runner/judo_reports
            generate_cucumber_json=False,
            cucumber_json_dir="./judo_reports/cucumber-json",
            parallel=False,
            max_workers=6,
            # 🆕 NUEVAS OPCIONES PARA LOGGING DE REQUESTS/RESPONSES
            save_requests_responses=True,  # Habilitar guardado automático
            requests_responses_dir="./judo_reports/api_logs"  # Directorio personalizado
        )
    
    def run_smoke_tests(self):
        return self.run(tags=["@english"])
    
    def run_api_tests_parallel(self):
        self.set_parallel(True, max_workers=8)
        return self.run(tags=["@api"], exclude_tags=["@manual"])
    
    # 🆕 MÉTODOS PARA CONTROLAR EL LOGGING DINÁMICAMENTE
    def run_tests_with_logging(self, tags=None, log_directory=None):
        """Ejecutar tests con logging habilitado"""
        # Configurar logging dinámicamente
        self.set_request_response_logging(
            enabled=True,
            directory=log_directory or "./judo_reports/detailed_logs"
        )
        return self.run(tags=tags or ["@test"])
    
    def run_tests_without_logging(self, tags=None):
        """Ejecutar tests sin logging para mejor performance"""
        self.set_request_response_logging(enabled=False)
        return self.run(tags=tags or ["@test"])

# Uso
if __name__ == "__main__":
    # Cambiar al directorio correcto
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    runner = MyRunner()
    
    print("🥋 Judo Framework - Ejecutando desde Runner/")
    print(f"📁 Features dir: {os.path.abspath('../Features')}")
    print(f"📊 Reports dir: {os.path.abspath('./judo_reports')}")
    print(f"💾 API Logs dir: {os.path.abspath('./judo_reports/api_logs')}")
    
    try:
        # OPCIÓN 1: Ejecutar con logging habilitado (configurado en __init__)
        print("\n🔥 Ejecutando smoke tests CON logging automático...")
        results = runner.run_smoke_tests()
        
        # OPCIÓN 2: Ejecutar con logging en directorio personalizado
        # print("\n🔥 Ejecutando tests CON logging en directorio personalizado...")
        # results = runner.run_tests_with_logging(
        #     tags=["@api"], 
        #     log_directory="./custom_api_logs"
        # )
        
        # OPCIÓN 3: Ejecutar SIN logging para mejor performance
        # print("\n🔥 Ejecutando tests SIN logging...")
        # results = runner.run_tests_without_logging(tags=["@performance"])
        
        print(f"📊 Resultado: {results['passed']}/{results['total']} tests pasaron")
        
        if results['total'] > 0:
            print(f"📄 Ver reporte HTML en: Runner/judo_reports/")
            print(f"💾 Ver logs de API en: Runner/judo_reports/api_logs/")
            print(f"📁 Cada escenario tiene su propio directorio con archivos JSON")
    
    except Exception as e:
        print(f"❌ Error: {e}")
        print("💡 Verifica que el archivo Features/feature1.feature tenga tags @test1")