"""Julee documentation utilities.

This package provides Sphinx extensions and utilities for documenting
Julee-based solutions using Human-Centered Design patterns.
"""
