"""
Polling services tests for the polling contrib module infrastructure.

This module contains unit tests for polling service implementations in the
infrastructure layer, including HTTP and other protocol-specific pollers.
"""
