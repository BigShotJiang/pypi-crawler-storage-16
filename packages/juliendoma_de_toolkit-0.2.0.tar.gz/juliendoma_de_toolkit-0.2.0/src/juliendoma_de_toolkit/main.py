import click
from juliendoma_de_toolkit.vm import connect, start, stop


@click.group()
def cli():
    pass


cli.add_command(connect)
cli.add_command(start)
cli.add_command(stop)
