import click
import subprocess


@click.command()
def start():
    """Start your vm"""
    subprocess.run(
        [
            "gcloud",
            "compute",
            "instances",
            "start",
            "--zone=europe-west1-b",
            "bootcamp-de-vm",
        ]
    )


@click.command()
def stop():
    """Stop your vm"""
    subprocess.run(
        [
            "gcloud",
            "compute",
            "instances",
            "stop",
            "--zone=europe-west1-b",
            "bootcamp-de-vm",
        ]
    )


@click.command()
def connect():
    """Connect to your vm in vscode inside your ~/code/juliendoma/folder"""
    subprocess.run(
        [
            "code",
            "--remote=ssh-remote+bootcamp-de-vm",
            "/home/mailrandomgcp2/code/JulienDoma/data-engineering-challenges",
        ]
    )
