## [0.0.0](https://github.com/juaml/junifer-julio/tree/0.0.0) - 2025-12-11

### Added

- Create repository skeleton and publish package
