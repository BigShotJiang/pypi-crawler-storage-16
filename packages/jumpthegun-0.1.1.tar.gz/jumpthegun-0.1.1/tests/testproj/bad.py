import sys
import os

def foo() -> str:
    return ("foo")
