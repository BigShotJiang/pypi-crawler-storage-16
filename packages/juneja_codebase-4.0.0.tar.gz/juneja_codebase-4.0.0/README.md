# juneja-codebase

A Python CLI tool to generate academic practical code files offline.

## Installation

```bash
pip install juneja-codebase
```

## Usage

### Standard Method
```bash
# List available subjects
juneja-codebase --list

# Generate all code files
juneja-codebase --all

# Generate specific subject
juneja-codebase --subject compiler_design

# Save to specific directory
juneja-codebase --all --output ./my_codes

# Create zip file
juneja-codebase --all --zip
```

### Alternative Method (Use this in lab/college systems if `juneja-codebase` command doesn't work)
```bash
# If you get "command not found" or "not recognized" error, use:
python3 -m juneja_codebase.main --list
python3 -m juneja_codebase.main --all
python3 -m juneja_codebase.main --subject compiler_design
python3 -m juneja_codebase.main --all --zip
```

**Note:** The alternative method works on ALL systems and doesn't require the Scripts folder to be in PATH.

## Subjects Included

1. **Compiler Design** - Lex and Yacc practical files
2. **Deep Learning** - Deep learning implementations
3. **Social Network Analysis** - Network analysis code

## Features

- Works completely offline
- All practical files bundled in the package
- Perfect for lab practicals and exam preparation
- No internet required after installation

## License

MIT License

