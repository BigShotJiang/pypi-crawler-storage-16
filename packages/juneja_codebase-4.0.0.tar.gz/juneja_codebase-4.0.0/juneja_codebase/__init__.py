"""
reqcode-aj: A CLI tool to generate academic practical code files
"""

__version__ = "0.1.0"
__author__ = "AJ"
