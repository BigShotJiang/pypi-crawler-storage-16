jupyter\_client.blocking package
================================

Submodules
----------


.. automodule:: jupyter_client.blocking.client
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: jupyter_client.blocking
   :members:
   :show-inheritance:
   :undoc-members:
