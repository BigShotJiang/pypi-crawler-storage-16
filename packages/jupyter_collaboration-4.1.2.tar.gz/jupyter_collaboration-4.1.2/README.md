# jupyter-collaboration

A meta-package for:
- jupyter-collaboration-ui
- jupyter-docprovider
- jupyter-server-ydoc
