# @jupyter/collaboration-extension

A JupyterLab package which provides a set of plugins for Real Time Collaboration.
