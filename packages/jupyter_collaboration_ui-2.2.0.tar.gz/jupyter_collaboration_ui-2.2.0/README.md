# jupyter-collaboration-ui

JupyterLab/Jupyter Notebook 7+ extension providing user interface integration for real time collaboration.
