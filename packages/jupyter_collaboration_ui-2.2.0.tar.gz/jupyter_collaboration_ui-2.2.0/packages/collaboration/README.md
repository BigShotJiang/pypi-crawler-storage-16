# @jupyter/collaboration

A JupyterLab package which provides a set of widgets for Real Time Collaboration.
