# Copyright (c) Jupyter Development Team.
# Distributed under the terms of the Modified BSD License.

# setup.py shim for use with applications that require it.
__import__("setuptools").setup()
