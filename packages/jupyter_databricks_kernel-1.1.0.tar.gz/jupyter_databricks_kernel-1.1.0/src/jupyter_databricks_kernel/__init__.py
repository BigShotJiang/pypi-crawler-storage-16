"""Jupyter kernel for Databricks remote execution."""

from ._version import __version__

__all__ = ["__version__"]
