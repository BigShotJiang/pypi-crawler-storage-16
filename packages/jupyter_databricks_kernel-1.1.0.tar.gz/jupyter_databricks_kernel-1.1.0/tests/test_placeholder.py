"""Placeholder test to ensure pytest runs successfully."""


def test_placeholder() -> None:
    """Placeholder test that always passes.

    Remove this file when real tests are added.
    """
    assert True
