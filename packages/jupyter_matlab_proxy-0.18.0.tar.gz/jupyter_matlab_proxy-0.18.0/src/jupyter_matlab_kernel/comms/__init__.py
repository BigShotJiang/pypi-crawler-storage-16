# Copyright 2025 The MathWorks, Inc.

from .labextension import LabExtensionCommunication
