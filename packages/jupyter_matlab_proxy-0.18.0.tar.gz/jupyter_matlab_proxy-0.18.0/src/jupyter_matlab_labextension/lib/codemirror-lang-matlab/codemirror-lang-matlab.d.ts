import { LanguageSupport, LRLanguage } from '@codemirror/language';
export declare const matlabLanguage: LRLanguage;
export declare function matlab(): LanguageSupport;
