export declare function getDedentPattern(): RegExp;
export declare function lineIndent(indentUnit: number, currentLineText: string, previousLineText: string): number;
