import { LabIcon } from '@jupyterlab/ui-components';
export declare const matlabIcon: LabIcon;
export declare const openMATLABIcon: LabIcon;
export declare const newMFileIcon: LabIcon;
export declare const notebookIcon: LabIcon;
