export const matlabHighlighting: import("@lezer/common").NodePropSource;
