export const parseComments: ExternalTokenizer;
import { ExternalTokenizer } from "@lezer/lr";
