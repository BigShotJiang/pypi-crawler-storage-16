export const parser: LRParser;
import { LRParser } from "@lezer/lr";
