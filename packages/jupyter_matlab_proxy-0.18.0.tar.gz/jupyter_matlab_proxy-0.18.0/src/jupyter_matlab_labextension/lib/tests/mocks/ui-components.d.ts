export class LabIcon {
    static resolve(icon: any): any;
    constructor(name: any, options: any);
    name: any;
    svgstr: any;
}
