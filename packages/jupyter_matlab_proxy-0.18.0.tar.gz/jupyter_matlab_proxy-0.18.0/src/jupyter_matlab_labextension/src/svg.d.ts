// Copyright 2023 The MathWorks, Inc.

declare module '*.svg' {
  const value: string;
  export default value;
}
