# Reference

Technical reference. Covers tools, components, commands, and resources.

```{toctree}
:maxdepth: 1
:caption: Contents:

releaser_cli
api_docs
configuration
theory
```
