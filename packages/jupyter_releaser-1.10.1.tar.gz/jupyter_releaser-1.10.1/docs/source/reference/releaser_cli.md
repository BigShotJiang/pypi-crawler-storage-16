# Releaser CLI

```{click} jupyter_releaser.cli:main
:prog: jupyter-releaser
:nested: full
```
