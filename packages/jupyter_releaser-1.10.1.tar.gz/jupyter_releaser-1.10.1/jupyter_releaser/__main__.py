"""The main entry point for Jupyter Releaser."""
# Copyright (c) Jupyter Development Team.
# Distributed under the terms of the Modified BSD License.
from jupyter_releaser.cli import main

if __name__ == "__main__":
    main()
