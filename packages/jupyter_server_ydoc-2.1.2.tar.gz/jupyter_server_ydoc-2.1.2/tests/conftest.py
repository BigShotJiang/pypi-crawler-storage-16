# Copyright (c) Jupyter Development Team.
# Distributed under the terms of the Modified BSD License.

pytest_plugins = [
    "jupyter_server.pytest_plugin",
    "jupyter_server_fileid.pytest_plugin",
    "jupyter_server_ydoc.pytest_plugin",
]
