.. Copyright (c) Jupyter Development Team.
.. Distributed under the terms of the Modified BSD License.

JavaScript API
==============

.. meta::
    :http-equiv=refresh: 0;url=./api/index.html

The `@jupyter/ydoc` API reference docs are `here <./api/index.html>`_
if you are not redirected automatically.
