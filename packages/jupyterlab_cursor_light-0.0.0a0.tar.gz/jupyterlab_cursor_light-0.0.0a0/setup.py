from setuptools import setup

setup(
    name="jupyterlab-cursor-light",
    version="0.0.0a0"
)
