# Override root conftest.py for standalone tests
# No pytest_jupyter dependency needed for unit tests
