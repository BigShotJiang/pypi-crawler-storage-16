"""
Version information for jupyterlab-mlflow
"""

__version__ = "0.1.0"

