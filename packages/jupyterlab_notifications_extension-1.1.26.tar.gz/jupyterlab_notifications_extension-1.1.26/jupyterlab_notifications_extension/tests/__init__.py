"""Python unit tests for jupyterlab_notifications_extension."""
