import json
import os

import requests
import tornado
from jupyter_server.base.handlers import APIHandler
from jupyter_server.utils import url_path_join


class RouteHandler(APIHandler):
    # The following decorator should be present on all verb methods (head, get, post,
    # patch, put, delete, options) to ensure only authorized user can request the
    # Jupyter server
    @tornado.web.authenticated
    def get(self) -> None:
        self.finish(json.dumps(dict(os.environ)))


class ShareNotebookHandler(APIHandler):
    @tornado.web.authenticated
    def post(self) -> None:

        data = json.loads(self.request.body)

        api_data = {
            "email": data.get("email"),
            "notebook_path": data.get("notebook_path"),
            "username": os.environ.get("JUPYTERHUB_USER"),
            "servername": os.environ.get("JUPYTERHUB_SERVER_NAME"),
        }

        # TODO: Set DJango API Token in config.yml and read it here is os.environ
        # api_url = "http://host.docker.internal:9187/api/v1/jupyter-service/share"
        # QA and PROD /share endpoint both point to the same JupyterHub instance
        api_url = "https://jupyter-service.platform.gcp.oreilly.review/api/v1/jupyter-service/share"
        try:
            response = requests.post(api_url, json=api_data)
            response.raise_for_status()
            self.finish(
                json.dumps(
                    {
                        "success": True,
                        "api_response": response.json(),
                        "info": api_data,
                    }
                )
            )
        except requests.exceptions.RequestException as e:
            status_code = getattr(e.response, "status_code", 500)
            self.set_status(status_code)
            # TODO: remove error details in production
            self.finish(json.dumps({"message": f"{e.response.json()} {api_data}"}))


def setup_handlers(web_app: tornado.web.Application) -> None:
    host_pattern = ".*$"

    base_url = web_app.settings["base_url"]
    handlers = [
        (url_path_join(base_url, "jupyterlab-orm", "get-example"), RouteHandler),
        (url_path_join(base_url, "jupyterlab-orm", "share"), ShareNotebookHandler),
    ]
    web_app.add_handlers(host_pattern, handlers)
