import json
import os
from unittest import mock


async def test_get_example(jp_fetch) -> None:
    """
    Test expected behavior of the get-example handler
    """

    mock_env = {"TEST_KEY": "TEST_VALUE", "ANOTHER_KEY": "123"}
    with mock.patch.dict(os.environ, mock_env, clear=True):
        response = await jp_fetch("jupyterlab-orm", "get-example")
        assert response.code == 200
        payload = json.loads(response.body)
        assert payload == mock_env
