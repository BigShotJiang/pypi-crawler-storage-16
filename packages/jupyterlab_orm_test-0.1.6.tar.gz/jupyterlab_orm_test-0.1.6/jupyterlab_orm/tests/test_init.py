import importlib
import json
import os
from unittest import mock


def test_init_module_version_file_exists() -> None:
    """
    Test expected behavior when jupyterlab_orm is installed
    """

    pkg_path = os.path.join(os.path.dirname(__file__), "../../package.json")
    with open(pkg_path) as f:
        pkg = json.load(f)
    expected_version = pkg["version"]

    class MockVersion:
        pass

    mock_version = MockVersion()
    mock_version.__version__ = expected_version
    with mock.patch.dict("sys.modules", {"jupyterlab_orm._version": mock_version}):
        mod = importlib.reload(importlib.import_module("jupyterlab_orm"))
        assert mod.__version__ == expected_version
        assert mod._jupyter_labextension_paths() == [
            {"src": "labextension", "dest": pkg["name"]}
        ]
        assert mod._jupyter_server_extension_points() == [{"module": "jupyterlab_orm"}]


def test_init_module_version_file_not_exists() -> None:
    """
    Test expected behavior when jupyterlab_orm is not installed
    """

    pkg_path = os.path.join(os.path.dirname(__file__), "../../package.json")
    with open(pkg_path) as f:
        pkg = json.load(f)
    with mock.patch.dict("sys.modules", {"jupyterlab_orm._version": None}):
        with mock.patch("importlib.util.find_spec", return_value=None):
            mod = importlib.reload(importlib.import_module("jupyterlab_orm"))
            assert mod.__version__ == "dev"
            assert mod._jupyter_labextension_paths() == [
                {"src": "labextension", "dest": pkg["name"]}
            ]
            assert mod._jupyter_server_extension_points() == [
                {"module": "jupyterlab_orm"}
            ]
