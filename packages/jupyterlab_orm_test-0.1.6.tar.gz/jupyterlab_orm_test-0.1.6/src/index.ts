import {
  JupyterFrontEnd,
  JupyterFrontEndPlugin
} from '@jupyterlab/application';

import { track } from '@oreillymedia/fe-analytics';
import { clientType, meterType } from '@oreillymedia/usage-meter';

import { requestAPI } from './handler';
import sharePlugin from './sharePlugin';

/**
 * Initialization data for the jupyterlab-orm extension.
 */
const plugin: JupyterFrontEndPlugin<void> = {
  id: 'jupyterlab-orm:plugin',
  description:
    "A JupyterLab extension to facilitate O'Reilly Media customizations.",
  autoStart: true,
  activate: (app: JupyterFrontEnd) => {
    console.log('JupyterLab extension jupyterlab-orm is activated!!');

    console.log("O'Reilly Media Usage Meter import test");
    console.log(`Client types: ${Object.keys(clientType)}`);
    console.log(`Meter types: ${Object.keys(meterType)}`);

    console.log("O'Reilly Media FE Analytics import test");
    console.log(`track function: ${track}`);

    requestAPI<any>('get-example')
      .then(data => {
        console.log('Received env vars from backend extension:', data);
      })
      .catch(reason => {
        console.error(
          `The jupyterlab_orm server extension appears to be missing.\n${reason}`
        );
      });
  }
};

export default [plugin, sharePlugin];
