import {
  JupyterFrontEnd,
  JupyterFrontEndPlugin
} from '@jupyterlab/application';
import { INotebookTracker } from '@jupyterlab/notebook';
import { ToolbarButton } from '@jupyterlab/apputils';
import { InputDialog, showDialog, Dialog } from '@jupyterlab/apputils';

import { requestAPI } from './handler';

/**
 * Share notebook plugin
 */
const sharePlugin: JupyterFrontEndPlugin<void> = {
  id: 'jupyterlab-orm:share',
  description: 'Share notebook with other users',
  autoStart: true,
  requires: [INotebookTracker],
  activate: (app: JupyterFrontEnd, notebookTracker: INotebookTracker) => {
    console.log('Share plugin activated!');

    // Add share button to notebook toolbar
    notebookTracker.widgetAdded.connect((sender, notebookPanel) => {
      // Create the Share button
      const shareButton = new ToolbarButton({
        label: 'Share',
        onClick: async () => {
          // Show dialog asking for email
          const result = await InputDialog.getText({
            title: 'Share Notebook',
            label: 'Enter email address:',
            placeholder: 'user@example.com'
          });

          // If user clicked OK and entered an email
          if (result.button.accept && result.value) {
            const email = result.value;
            // Get current notebook path
            const notebookPath = notebookPanel.context.path;
            try {
              // Send to backend API
              const response = await requestAPI<any>('share', {
                method: 'POST',
                body: JSON.stringify({
                  email: email,
                  notebook_path: notebookPath
                }),
                headers: {
                  'Content-Type': 'application/json'
                }
              });

              console.log('Share response:', response);

              // Show success dialog
              await showDialog({
                title: 'Share Successful',
                body: `Notebook shared with ${email}! \n ${response.api_response.share_url}`,
                buttons: [Dialog.okButton()]
              });
            } catch (error) {
              await showDialog({
                title: 'Share Failed',
                body: 'Failed to share notebook. Please try again.',
                buttons: [Dialog.okButton()]
              });
              console.error('Error sharing notebook:', error);
            }
          }
        }
      });

      // Add button to notebook toolbar
      notebookPanel.toolbar.insertItem(10, 'share', shareButton);
    });
  }
};

export default sharePlugin;
