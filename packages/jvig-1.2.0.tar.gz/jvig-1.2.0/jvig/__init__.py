from .__version__ import (
    __author__,
    __copyright__,
    __description__,
    __email__,
    __license__,
    __title__,
    __url__,
    __version__,
)
