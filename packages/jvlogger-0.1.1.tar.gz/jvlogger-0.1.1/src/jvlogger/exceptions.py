class SingleInstanceError(RuntimeError):
    """Raised when a single-instance lock prevents start."""
    pass
