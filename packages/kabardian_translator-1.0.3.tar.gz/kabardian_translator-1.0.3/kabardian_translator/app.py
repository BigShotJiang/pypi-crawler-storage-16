# app.py
# Kabardian-Russian Translator with Text-to-Speech and Transliteration
# License: CC BY-NC 4.0 (Non-Commercial Use Only)

# ЕСЛИ ЗАПУСК НАПРЯМУЮ (python app.py) - ПРЕДЛОЖИТЬ ИСПОЛЬЗОВАТЬ CLI
if __name__ == "__main__":
    print("🎯 Kabardian Translator")
    print("=" * 50)
    print("⚠️  Рекомендуемый способ запуска:")
    print("   kabardian-translator")
    print("\n📦 Для установки как пакет:")
    print("   pip install kabardian-translator")
    print("   kabardian-translator")
    print("\n📥 Для загрузки моделей:")
    print("   kabardian-download-models")
    print("=" * 50)
    print("\n⚡ Запускаю в обычном режиме...")
    print("   (модели не будут скачиваться автоматически)")
    import time
    time.sleep(2)

from flask import Flask, render_template, request, jsonify, send_file, Response
import torch
import os
import time
import atexit
import signal
import sys
import gc

# ИСПРАВЛЕННЫЕ ИМПОРТЫ - ДОБАВЛЕНО "."
from .translation_service import TranslationService
from .tts_service import TTSService
from .transliterator import transliterator

# ИСПРАВЛЕННЫЙ ПУТЬ К ШАБЛОНАМ
current_file = os.path.abspath(__file__)
current_dir = os.path.dirname(current_file)
template_dir = os.path.join(current_dir, 'templates')

# Если templates не найден в текущей директории, попробовать родительскую
if not os.path.exists(template_dir):
    parent_dir = os.path.dirname(current_dir)
    template_dir = os.path.join(parent_dir, 'kabardian_translator', 'templates')
    if not os.path.exists(template_dir):
        # Последняя попытка
        template_dir = os.path.join(current_dir, 'templates')

app = Flask(__name__, template_folder=template_dir)

# Memory cleanup function
def cleanup_memory():
    """Clear memory cache"""
    gc.collect()
    if torch.backends.mps.is_available():
        torch.mps.empty_cache()
    elif torch.cuda.is_available():
        torch.cuda.empty_cache()
    print("🧹 System memory cleaned")

# Initialize services
device = "mps" if torch.backends.mps.is_available() else "cpu"
print(f"🖥️  Device: {device}")

# Clean memory before loading
cleanup_memory()

translator = TranslationService(device)
tts_service = TTSService(device)  # TTS will load on first use

# UI translations
UI_TRANSLATIONS = {
    'ru': {
        'title': 'Кабардинский Переводчик',
        'model_info': '100 языков + Транслитерация',
        'theme_dark': 'Темная',
        'theme_light': 'Светлая',
        'tts_info': 'Озвучивание с транслитерацией: Турецкий/Азербайджанский/Грузинский/Армянский/Немецкий/Испанский/Латышский → автоматическая транслитерация',
        'source_placeholder': 'Введите текст для перевода...',
        'target_placeholder': 'Здесь появится перевод...',
        'clear': 'Очистить',
        'speak': 'Озвучить',
        'copy': 'Копировать',
        'characters': 'символов',
        'time': 'мс',
        'translate': 'Перевести',
        'processing': 'Обработка...',
        'swap_tooltip': 'Поменять языки',
        'cascade_translation': 'Использован каскадный перевод через русский язык',
        'transliteration_preview': 'Транслитерация для TTS',
        'transliteration_info': 'Текст автоматически транслитерирован для озвучки',
        'tts_transliterated': 'Озвучен транслитерированный текст через спикера:',
        'tts_direct': 'Озвучено через спикера:',
        'text_truncated': 'Текст был обрезан до 200 символов',
        'network_error': 'Ошибка сети:',
        'synthesis_error': 'Ошибка синтеза:',
        'translation_error': 'Ошибка перевода',
        'empty_text_error': 'Введите текст для перевода',
        'language_groups': {
            'slavic': 'Славянские языки',
            'caucasian_turkic': 'Кавказские/тюркские языки',
            'turkic': 'Тюркские языки',
            'european': 'Европейские языки'
        }
    },
    'en': {
        'title': 'Kabardian Translator',
        'model_info': '100 Languages + Transliteration',
        'theme_dark': 'Dark',
        'theme_light': 'Light',
        'tts_info': 'Speech synthesis with transliteration: Turkish/Azerbaijani/Georgian/Armenian/German/Spanish/Latvian → automatic transliteration',
        'source_placeholder': 'Enter text to translate...',
        'target_placeholder': 'Translation will appear here...',
        'clear': 'Clear',
        'speak': 'Speak',
        'copy': 'Copy',
        'characters': 'characters',
        'time': 'ms',
        'translate': 'Translate',
        'processing': 'Processing...',
        'swap_tooltip': 'Swap languages',
        'cascade_translation': 'Used cascade translation via Russian',
        'transliteration_preview': 'Transliteration for TTS',
        'transliteration_info': 'Text automatically transliterated for speech synthesis',
        'tts_transliterated': 'Transliterated text spoken via speaker:',
        'tts_direct': 'Spoken via speaker:',
        'text_truncated': 'Text was truncated to 200 characters',
        'network_error': 'Network error:',
        'synthesis_error': 'Synthesis error:',
        'translation_error': 'Translation error',
        'empty_text_error': 'Enter text to translate',
        'language_groups': {
            'slavic': 'Slavic Languages',
            'caucasian_turkic': 'Caucasian/Turkic Languages',
            'turkic': 'Turkic Languages',
            'european': 'European Languages'
        }
    }
}

# HTML template (with updates for transliteration and language switching)
HTML_TEMPLATE = '''
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title data-ru="Кабардинский Переводчик с Озвучиванием" data-en="Kabardian Translator with Speech Synthesis">Кабардинский Переводчик с Озвучиванием</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        :root {
            --primary-color: #667eea;
            --secondary-color: #764ba2;
            --success-color: #10b981;
            --error-color: #ef4444;
            --warning-color: #f59e0b;
            --info-color: #3b82f6;
        }
        
        /* Light theme */
        body.light-theme {
            --bg-gradient-start: #667eea;
            --bg-gradient-end: #764ba2;
            --surface-color: #ffffff;
            --surface-secondary: #f8f9fa;
            --text-primary: #1f2937;
            --text-secondary: #6b7280;
            --border-color: #e5e7eb;
            --hover-color: #f3f4f6;
            --shadow: rgba(0,0,0,0.1);
        }
        
        /* Dark theme */
        body.dark-theme {
            --bg-gradient-start: #1e293b;
            --bg-gradient-end: #0f172a;
            --surface-color: #1e293b;
            --surface-secondary: #334155;
            --text-primary: #f1f5f9;
            --text-secondary: #94a3b8;
            --border-color: #475569;
            --hover-color: #334155;
            --shadow: rgba(0,0,0,0.3);
        }
        
        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: linear-gradient(135deg, var(--bg-gradient-start) 0%, var(--bg-gradient-end) 100%);
            min-height: 100vh;
            padding: 20px;
            color: var(--text-primary);
            transition: all 0.3s ease;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: var(--surface-color);
            border-radius: 20px;
            box-shadow: 0 20px 60px var(--shadow);
            overflow: hidden;
            transition: all 0.3s ease;
        }
        
        .header {
            background: var(--surface-color);
            padding: 24px 32px;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 24px;
            font-weight: 700;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .logo i {
            font-size: 32px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .header-controls {
            display: flex;
            align-items: center;
            gap: 16px;
        }
        
        .language-switcher {
            display: flex;
            align-items: center;
            gap: 8px;
            background: var(--surface-secondary);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            overflow: hidden;
        }
        
        .lang-btn {
            padding: 8px 16px;
            background: transparent;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
            color: var(--text-secondary);
            font-weight: 500;
        }
        
        .lang-btn.active {
            background: var(--primary-color);
            color: white;
        }
        
        .lang-btn:hover:not(.active) {
            background: var(--hover-color);
        }
        
        .theme-toggle {
            background: var(--surface-secondary);
            border: 1px solid var(--border-color);
            padding: 10px 16px;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--text-primary);
        }
        
        .theme-toggle:hover {
            background: var(--hover-color);
            transform: translateY(-2px);
        }
        
        .model-info {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.1), rgba(118, 75, 162, 0.1));
            padding: 10px 20px;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 500;
            color: var(--primary-color);
        }
        
        .main-content {
            display: grid;
            grid-template-columns: 1fr auto 1fr;
            gap: 0;
            padding: 0;
        }
        
        .translation-panel {
            padding: 32px;
            display: flex;
            flex-direction: column;
            min-height: 500px;
        }
        
        .source-panel {
            border-right: 1px solid var(--border-color);
        }
        
        .target-panel {
            border-left: 1px solid var(--border-color);
        }
        
        .panel-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
            padding-bottom: 16px;
            border-bottom: 2px solid var(--border-color);
        }
        
        .language-selector {
            position: relative;
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 16px;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.2s ease;
            border: 2px solid var(--border-color);
            background: var(--surface-secondary);
        }
        
        .language-selector:hover {
            border-color: var(--primary-color);
            background: var(--hover-color);
        }
        
        .language-flag {
            font-size: 24px;
        }
        
        .language-name {
            font-size: 16px;
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .language-dropdown {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: var(--surface-color);
            border: 2px solid var(--primary-color);
            border-radius: 12px;
            box-shadow: 0 10px 40px var(--shadow);
            z-index: 1000;
            max-height: 400px;
            overflow-y: auto;
            display: none;
            margin-top: 8px;
        }
        
        .language-dropdown.open {
            display: block;
        }
        
        .language-group-title {
            padding: 12px 16px;
            background: var(--surface-secondary);
            font-weight: 600;
            font-size: 12px;
            text-transform: uppercase;
            color: var(--text-secondary);
            border-bottom: 1px solid var(--border-color);
        }
        
        .language-option {
            padding: 12px 20px;
            cursor: pointer;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            gap: 10px;
            border-bottom: 1px solid var(--border-color);
        }
        
        .language-option:hover {
            background: var(--hover-color);
            padding-left: 24px;
        }
        
        .language-option.selected {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.1), rgba(118, 75, 162, 0.1));
            color: var(--primary-color);
            font-weight: 600;
        }
        
        .tts-badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 2px 8px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 600;
            margin-left: auto;
        }
        
        .tts-badge.has-tts {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success-color);
        }
        
        .tts-badge.no-tts {
            background: rgba(156, 163, 175, 0.1);
            color: var(--text-secondary);
        }
        
        .tts-badge.transliterated {
            background: rgba(59, 130, 246, 0.1);
            color: var(--info-color);
        }
        
        .action-buttons {
            display: flex;
            gap: 8px;
        }
        
        .icon-button {
            background: var(--surface-secondary);
            border: 1px solid var(--border-color);
            padding: 10px;
            border-radius: 10px;
            cursor: pointer;
            color: var(--text-secondary);
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
        }
        
        .icon-button:hover {
            background: var(--hover-color);
            color: var(--primary-color);
            transform: translateY(-2px);
        }
        
        .icon-button:active {
            transform: translateY(0);
        }
        
        .icon-button.playing {
            background: var(--primary-color);
            color: white;
        }
        
        .swap-button {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            border: none;
            border-radius: 50%;
            width: 56px;
            height: 56px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
            margin: 0 20px;
            align-self: center;
            box-shadow: 0 4px 20px var(--shadow);
        }
        
        .swap-button:hover {
            transform: scale(1.1) rotate(180deg);
            box-shadow: 0 6px 30px var(--shadow);
        }
        
        .text-area-container {
            flex: 1;
            display: flex;
            flex-direction: column;
            border: 2px solid var(--border-color);
            border-radius: 16px;
            overflow: hidden;
            transition: all 0.3s ease;
            background: var(--surface-secondary);
        }
        
        .text-area-container:focus-within {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        }
        
        .text-area {
            flex: 1;
            border: none;
            outline: none;
            padding: 24px;
            font-size: 16px;
            line-height: 1.6;
            resize: none;
            background: transparent;
            font-family: inherit;
            color: var(--text-primary);
        }
        
        .panel-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 16px 24px;
            background: var(--surface-secondary);
            border-top: 1px solid var(--border-color);
            border-radius: 0 0 14px 14px;
        }
        
        .text-info {
            font-size: 13px;
            color: var(--text-secondary);
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .translate-button {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            border: none;
            padding: 16px 48px;
            border-radius: 16px;
            font-weight: 600;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s ease;
            align-self: center;
            margin: 24px 0;
            box-shadow: 0 4px 20px var(--shadow);
        }
        
        .translate-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 30px var(--shadow);
        }
        
        .translate-button:active {
            transform: translateY(-1px);
        }
        
        .loading {
            display: none;
            text-align: center;
            padding: 24px;
        }
        
        .spinner {
            border: 3px solid var(--border-color);
            border-top: 3px solid var(--primary-color);
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 0 auto 12px;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .error-message {
            background: rgba(239, 68, 68, 0.1);
            color: var(--error-color);
            padding: 16px 20px;
            border-radius: 12px;
            margin: 20px 32px;
            font-size: 14px;
            display: none;
            border-left: 4px solid var(--error-color);
        }
        
        .info-message {
            background: rgba(59, 130, 246, 0.1);
            color: var(--info-color);
            padding: 12px 20px;
            border-radius: 12px;
            margin: 20px 32px;
            font-size: 13px;
            display: none;
            border-left: 4px solid var(--info-color);
        }
        
        .tts-info {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(5, 150, 105, 0.1));
            padding: 12px 20px;
            border-radius: 12px;
            margin: 20px 32px;
            font-size: 13px;
            color: var(--success-color);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .tts-info i {
            font-size: 16px;
        }
        
        .tts-info .warning {
            color: var(--warning-color);
            margin-left: 8px;
        }
        
        .transliteration-preview {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(0,0,0,0.95);
            color: white;
            padding: 24px;
            border-radius: 16px;
            z-index: 10000;
            max-width: 500px;
            width: 90%;
            text-align: center;
            border: 3px solid var(--primary-color);
            box-shadow: 0 20px 60px rgba(0,0,0,0.5);
            backdrop-filter: blur(10px);
        }
        
        .transliteration-preview h4 {
            margin-bottom: 16px;
            color: var(--primary-color);
            font-size: 18px;
        }
        
        .transliteration-text {
            background: rgba(255,255,255,0.1);
            padding: 16px;
            border-radius: 8px;
            margin: 16px 0;
            font-family: monospace;
            font-size: 16px;
            line-height: 1.5;
            border-left: 4px solid var(--primary-color);
        }
        
        .transliteration-meta {
            font-size: 14px;
            opacity: 0.8;
            margin-top: 12px;
        }
        
        @media (max-width: 768px) {
            .main-content {
                grid-template-columns: 1fr;
            }
            
            .swap-button {
                margin: 20px auto;
                transform: rotate(90deg);
            }
            
            .header {
                flex-direction: column;
                gap: 16px;
            }
            
            .header-controls {
                flex-wrap: wrap;
                justify-content: center;
            }
            
            .transliteration-preview {
                width: 95%;
                padding: 16px;
            }
        }
    </style>
</head>
<body class="light-theme">
    <div class="container">
        <div class="header">
            <div class="logo">
                <i class="fas fa-language"></i>
                <span data-ru="Кабардинский Переводчик" data-en="Kabardian Translator">Кабардинский Переводчик</span>
            </div>
            <div class="header-controls">
                <div class="language-switcher">
                    <button class="lang-btn active" data-lang="ru" onclick="switchLanguage('ru')">RU</button>
                    <button class="lang-btn" data-lang="en" onclick="switchLanguage('en')">EN</button>
                </div>
                <div class="model-info">
                    <i class="fas fa-robot"></i> <span data-ru="M2M100 + Транслитерация" data-en="M2M100 + Transliteration">M2M100 + Транслитерация</span>
                </div>
                <button class="theme-toggle" onclick="toggleTheme()">
                    <i class="fas fa-moon" id="theme-icon"></i>
                    <span id="theme-text" data-ru="Темная" data-en="Dark">Темная</span>
                </button>
            </div>
        </div>
        
        <div class="tts-info">
            <i class="fas fa-info-circle"></i>
            <span data-ru="Озвучивание с транслитерацией: Турецкий/Азербайджанский/Грузинский/Армянский/Немецкий/Испанский/Латышский → автоматическая транслитерация" 
                  data-en="Speech synthesis with transliteration: Turkish/Azerbaijani/Georgian/Armenian/German/Spanish/Latvian → automatic transliteration">
                Озвучивание с транслитерацией: Турецкий/Азербайджанский/Грузинский/Армянский/Немецкий/Испанский/Латышский → автоматическая транслитерация
            </span>
        </div>
        
        <div class="main-content">
            <!-- Source Panel -->
            <div class="translation-panel source-panel">
                <div class="panel-header">
                    <div class="language-selector" id="source-lang-selector" onclick="toggleLanguageDropdown('source')">
                        <span class="language-flag" id="source-flag">🇷🇺</span>
                        <span class="language-name" id="source-lang-name">Русский</span>
                        <i class="fas fa-chevron-down" style="margin-left: auto; color: var(--text-secondary);"></i>
                        
                        <div class="language-dropdown" id="source-dropdown">
                            <!-- Will be populated by JS -->
                        </div>
                    </div>
                    <div class="action-buttons">
                        <button class="icon-button" onclick="clearSourceText()" title="Очистить" data-ru-title="Очистить" data-en-title="Clear">
                            <i class="fas fa-times"></i>
                        </button>
                        <button class="icon-button" id="source-speak-btn" onclick="speakSourceText()" title="Озвучить" data-ru-title="Озвучить" data-en-title="Speak">
                            <i class="fas fa-volume-up"></i>
                        </button>
                    </div>
                </div>
                
                <div class="text-area-container">
                    <textarea 
                        class="text-area" 
                        id="source-text" 
                        placeholder="Введите текст для перевода..."
                        data-ru-placeholder="Введите текст для перевода..."
                        data-en-placeholder="Enter text to translate..."
                        oninput="onSourceTextChange()"
                    ></textarea>
                </div>
                
                <div class="panel-footer">
                    <div class="text-info">
                        <span><i class="fas fa-font"></i> <span id="source-length">0</span> <span data-ru="символов" data-en="characters">символов</span></span>
                    </div>
                </div>
            </div>
            
            <!-- Swap Button -->
            <button class="swap-button" onclick="swapLanguages()" title="Поменять языки" data-ru-title="Поменять языки" data-en-title="Swap languages">
                <i class="fas fa-exchange-alt"></i>
            </button>
            
            <!-- Target Panel -->
            <div class="translation-panel target-panel">
                <div class="panel-header">
                    <div class="language-selector" id="target-lang-selector" onclick="toggleLanguageDropdown('target')">
                        <span class="language-flag" id="target-flag">🌐</span>
                        <span class="language-name" id="target-lang-name">Кабардинский</span>
                        <i class="fas fa-chevron-down" style="margin-left: auto; color: var(--text-secondary);"></i>
                        
                        <div class="language-dropdown" id="target-dropdown">
                            <!-- Will be populated by JS -->
                        </div>
                    </div>
                    <div class="action-buttons">
                        <button class="icon-button" onclick="copyTranslation()" title="Копировать" data-ru-title="Копировать" data-en-title="Copy">
                            <i class="far fa-copy"></i>
                        </button>
                        <button class="icon-button" id="target-speak-btn" onclick="speakTranslation()" title="Озвучить" data-ru-title="Озвучить" data-en-title="Speak">
                            <i class="fas fa-volume-up"></i>
                        </button>
                    </div>
                </div>
                
                <div class="text-area-container">
                    <textarea 
                        class="text-area" 
                        id="target-text" 
                        placeholder="Здесь появится перевод..."
                        data-ru-placeholder="Здесь появится перевод..."
                        data-en-placeholder="Translation will appear here..."
                        readonly
                    ></textarea>
                </div>
                
                <div class="panel-footer">
                    <div class="text-info">
                        <span><i class="fas fa-font"></i> <span id="target-length">0</span> <span data-ru="символов" data-en="characters">символов</span></span>
                        <span>•</span>
                        <span><i class="fas fa-clock"></i> <span id="translation-time">-</span> <span data-ru="мс" data-en="ms">мс</span></span>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="loading" id="loading">
            <div class="spinner"></div>
            <div data-ru="Обработка..." data-en="Processing...">Обработка...</div>
        </div>
        
        <div class="error-message" id="error-message"></div>
        <div class="info-message" id="info-message"></div>
        
        <button class="translate-button" onclick="translateText()">
            <i class="fas fa-play"></i> <span data-ru="Перевести" data-en="Translate">Перевести</span>
        </button>
    </div>

    <script>
        // State
        let sourceLang = 'rus_Cyrl';
        let targetLang = 'kbd_Cyrl';
        let currentAudio = null;
        let languages = {};
        let languageGroups = {};
        let ttsSpeakers = {};
        let currentUILanguage = 'ru'; // Default UI language

        // Language flags
        const languageFlags = {
            'rus_Cyrl': '🇷🇺',
            'ukr_Cyrl': '🇺🇦',
            'bel_Cyrl': '🇧🇾',
            'lav_Latn': '🇱🇻',
            'kbd_Cyrl': '🌐',
            'kaz_Cyrl': '🇰🇿',
            'kat_Geor': '🇬🇪',
            'hye_Armn': '🇦🇲',
            'azj_Latn': '🇦🇿',
            'tur_Latn': '🇹🇷',
            'eng_Latn': '🇬🇧',
            'deu_Latn': '🇩🇪',
            'fra_Latn': '🇫🇷',
            'spa_Latn': '🇪🇸',
        };

        // Languages requiring transliteration for TTS
        const transliterationLanguages = ['tur_Latn', 'azj_Latn', 'kat_Geor', 'hye_Armn', 'lav_Latn', 'deu_Latn', 'spa_Latn'];
        
        // All languages with TTS support (including transliteration)
        const allTtsSupportedLanguages = [
            'rus_Cyrl', 'ukr_Cyrl', 'bel_Cyrl', 'lav_Latn',  // Slavic + Latvian with transliteration
            'kbd_Cyrl', 'kaz_Cyrl',                          // Caucasian/Turkic with direct TTS
            'tur_Latn', 'azj_Latn', 'kat_Geor', 'hye_Armn',  // with transliteration
            'deu_Latn', 'spa_Latn'                           // German and Spanish with transliteration
        ];

        // UI translations
        const uiTranslations = {
            'ru': {
                'cascade_translation': 'Использован каскадный перевод через русский язык',
                'tts_transliterated': 'Озвучен транслитерированный текст через спикера:',
                'tts_direct': 'Озвучено через спикера:',
                'text_truncated': 'Текст был обрезан до 200 символов',
                'network_error': 'Ошибка сети:',
                'synthesis_error': 'Ошибка синтеза:',
                'translation_error': 'Ошибка перевода',
                'empty_text_error': 'Введите текст для перевода',
                'transliteration_preview': 'Транслитерация для TTS',
                'transliteration_info': 'Текст автоматически транслитерирован для озвучки'
            },
            'en': {
                'cascade_translation': 'Used cascade translation via Russian',
                'tts_transliterated': 'Transliterated text spoken via speaker:',
                'tts_direct': 'Spoken via speaker:',
                'text_truncated': 'Text was truncated to 200 characters',
                'network_error': 'Network error:',
                'synthesis_error': 'Synthesis error:',
                'translation_error': 'Translation error',
                'empty_text_error': 'Enter text to translate',
                'transliteration_preview': 'Transliteration for TTS',
                'transliteration_info': 'Text automatically transliterated for speech synthesis'
            }
        };

        // DOM Elements
        const sourceText = document.getElementById('source-text');
        const targetText = document.getElementById('target-text');
        const sourceLength = document.getElementById('source-length');
        const targetLength = document.getElementById('target-length');
        const translationTime = document.getElementById('translation-time');
        const loadingElement = document.getElementById('loading');
        const errorMessage = document.getElementById('error-message');
        const infoMessage = document.getElementById('info-message');

        // Initialize
        async function init() {
            await loadLanguages();
            populateLanguageDropdowns();
            updateTTSButtons();
            sourceText.focus();
            
            // Load saved UI language
            const savedLang = localStorage.getItem('ui_language');
            if (savedLang) {
                switchLanguage(savedLang, false);
            }
        }

        // Switch UI language
        function switchLanguage(lang, save = true) {
            currentUILanguage = lang;
            
            // Update language switcher buttons
            document.querySelectorAll('.lang-btn').forEach(btn => {
                btn.classList.remove('active');
                if (btn.dataset.lang === lang) {
                    btn.classList.add('active');
                }
            });
            
            // Update all translatable elements
            document.querySelectorAll('[data-ru], [data-en]').forEach(element => {
                const translation = element.getAttribute(`data-${lang}`);
                if (translation) {
                    if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
                        element.placeholder = translation;
                    } else {
                        element.textContent = translation;
                    }
                }
            });
            
            // Update title
            const title = document.querySelector('title');
            const titleTranslation = title.getAttribute(`data-${lang}`);
            if (titleTranslation) {
                title.textContent = titleTranslation;
            }
            
            // Update tooltips
            document.querySelectorAll('[data-ru-title], [data-en-title]').forEach(element => {
                const tooltip = element.getAttribute(`data-${lang}-title`);
                if (tooltip) {
                    element.title = tooltip;
                }
            });
            
            // Update language group titles in dropdowns
            updateLanguageGroupTitles();
            
            if (save) {
                localStorage.setItem('ui_language', lang);
            }
        }

        // Update language group titles in dropdowns
        function updateLanguageGroupTitles() {
            // This will be called after language groups are loaded
            if (Object.keys(languageGroups).length > 0) {
                populateLanguageDropdowns();
            }
        }

        // Load languages from server
        async function loadLanguages() {
            try {
                const response = await fetch('/languages');
                const data = await response.json();
                languages = data.languages;
                languageGroups = data.groups;
                ttsSpeakers = data.tts_speakers;
                console.log('Loaded languages:', languages);
                console.log('TTS speakers:', ttsSpeakers);
            } catch (error) {
                console.error('Error loading languages:', error);
                showError(uiTranslations[currentUILanguage].network_error + error.message);
            }
        }

        // Populate language dropdowns
        function populateLanguageDropdowns() {
            populateDropdown('source-dropdown', sourceLang);
            populateDropdown('target-dropdown', targetLang);
        }

        function populateDropdown(dropdownId, selectedLang) {
            const dropdown = document.getElementById(dropdownId);
            let html = '';

            for (const [groupKey, groupTitle] of Object.entries(languageGroups)) {
                const groupLangs = languages[groupKey];
                if (groupLangs && Object.keys(groupLangs).length > 0) {
                    // Get translated group title
                    const translatedGroupTitle = getTranslatedGroupTitle(groupKey);
                    html += `<div class="language-group-title">${translatedGroupTitle}</div>`;
                    
                    for (const [code, name] of Object.entries(groupLangs)) {
                        const isSelected = code === selectedLang;
                        const hasDirectTTS = ttsSpeakers[code] !== null;
                        const needsTransliteration = transliterationLanguages.includes(code);
                        const hasTTS = hasDirectTTS || needsTransliteration;
                        
                        let ttsInfo = '';
                        if (needsTransliteration) {
                            ttsInfo = `<span class="tts-badge transliterated" title="${currentUILanguage === 'ru' ? 'Озвучение с транслитерацией' : 'Speech with transliteration'}"><i class="fas fa-exchange-alt"></i></span>`;
                        } else if (hasDirectTTS) {
                            ttsInfo = `<span class="tts-badge has-tts" title="${currentUILanguage === 'ru' ? 'Есть озвучение' : 'Has speech synthesis'}"><i class="fas fa-volume-up"></i></span>`;
                        } else {
                            ttsInfo = `<span class="tts-badge no-tts" title="${currentUILanguage === 'ru' ? 'Без озвучки' : 'No speech synthesis'}"><i class="fas fa-volume-mute"></i></span>`;
                        }
                        
                        html += `
                            <div class="language-option ${isSelected ? 'selected' : ''}" 
                                 data-code="${code}" 
                                 onclick="selectLanguage('${code}', '${dropdownId}')">
                                <span>${languageFlags[code] || '🌐'}</span>
                                <span>${name}</span>
                                ${ttsInfo}
                            </div>
                        `;
                    }
                }
            }

            dropdown.innerHTML = html;
        }

        // Get translated group title
        function getTranslatedGroupTitle(groupKey) {
            const groupTranslations = {
                'slavic': { 'ru': 'Славянские языки', 'en': 'Slavic Languages' },
                'caucasian_turkic': { 'ru': 'Кавказские/тюркские языки', 'en': 'Caucasian/Turkic Languages' },
                'turkic': { 'ru': 'Тюркские языки', 'en': 'Turkic Languages' },
                'european': { 'ru': 'Европейские языки', 'en': 'European Languages' }
            };
            
            return groupTranslations[groupKey]?.[currentUILanguage] || groupKey;
        }

        // Toggle language dropdown
        function toggleLanguageDropdown(type) {
            const dropdown = document.getElementById(`${type}-dropdown`);
            const allDropdowns = document.querySelectorAll('.language-dropdown');
            
            // Close other dropdowns
            allDropdowns.forEach(d => {
                if (d !== dropdown) {
                    d.classList.remove('open');
                }
            });
            
            dropdown.classList.toggle('open');
            event.stopPropagation();
        }

        // Close dropdowns on outside click
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.language-selector')) {
                document.querySelectorAll('.language-dropdown').forEach(d => {
                    d.classList.remove('open');
                });
            }
        });

        // Select language
        function selectLanguage(code, dropdownId) {
            const isSource = dropdownId.includes('source');
            
            if (isSource) {
                sourceLang = code;
                updateLanguageDisplay('source', code);
            } else {
                targetLang = code;
                updateLanguageDisplay('target', code);
            }
            
            // Close dropdown
            document.getElementById(dropdownId).classList.remove('open');
            
            // Update dropdowns to show selection
            populateLanguageDropdowns();
            
            // Update TTS buttons
            updateTTSButtons();
            
            // Auto-translate if there's text
            if (sourceText.value.trim()) {
                translateText();
            }
            
            event.stopPropagation();
        }

        // Update language display
        function updateLanguageDisplay(type, code) {
            const flag = document.getElementById(`${type}-flag`);
            const name = document.getElementById(`${type}-lang-name`);
            
            flag.textContent = languageFlags[code] || '🌐';
            
            // Get language name
            let langName = code;
            for (const group of Object.values(languages)) {
                if (group[code]) {
                    langName = group[code];
                    break;
                }
            }
            name.textContent = langName;
        }

        // Update TTS buttons visibility and tooltips
        function updateTTSButtons() {
            const sourceSpeakBtn = document.getElementById('source-speak-btn');
            const targetSpeakBtn = document.getElementById('target-speak-btn');
            
            // Check if TTS is supported for current languages
            const sourceHasTTS = allTtsSupportedLanguages.includes(sourceLang);
            const targetHasTTS = allTtsSupportedLanguages.includes(targetLang);
            
            console.log('TTS buttons update:', {
                sourceLang, sourceHasTTS,
                targetLang, targetHasTTS
            });
            
            // Show/hide buttons based on TTS support
            sourceSpeakBtn.style.display = sourceHasTTS ? 'flex' : 'none';
            targetSpeakBtn.style.display = targetHasTTS ? 'flex' : 'none';
            
            // Update tooltips for transliteration
            const sourceNeedsTranslit = transliterationLanguages.includes(sourceLang);
            const targetNeedsTranslit = transliterationLanguages.includes(targetLang);
            
            if (sourceHasTTS) {
                if (sourceNeedsTranslit) {
                    sourceSpeakBtn.title = currentUILanguage === 'ru' ? 
                        'Озвучить (с автоматической транслитерацией)' : 
                        'Speak (with automatic transliteration)';
                    sourceSpeakBtn.innerHTML = '<i class="fas fa-exchange-alt"></i>';
                } else {
                    sourceSpeakBtn.title = currentUILanguage === 'ru' ? 'Озвучить' : 'Speak';
                    sourceSpeakBtn.innerHTML = '<i class="fas fa-volume-up"></i>';
                }
            }
            
            if (targetHasTTS) {
                if (targetNeedsTranslit) {
                    targetSpeakBtn.title = currentUILanguage === 'ru' ? 
                        'Озвучить (с автоматической транслитерацией)' : 
                        'Speak (with automatic transliteration)';
                    targetSpeakBtn.innerHTML = '<i class="fas fa-exchange-alt"></i>';
                } else {
                    targetSpeakBtn.title = currentUILanguage === 'ru' ? 'Озвучить' : 'Speak';
                    targetSpeakBtn.innerHTML = '<i class="fas fa-volume-up"></i>';
                }
            }
        }

        // Theme Toggle
        function toggleTheme() {
            const body = document.body;
            const themeIcon = document.getElementById('theme-icon');
            const themeText = document.getElementById('theme-text');
            
            if (body.classList.contains('light-theme')) {
                body.classList.remove('light-theme');
                body.classList.add('dark-theme');
                themeIcon.className = 'fas fa-sun';
                themeText.textContent = currentUILanguage === 'ru' ? 'Светлая' : 'Light';
                localStorage.setItem('theme', 'dark');
            } else {
                body.classList.remove('dark-theme');
                body.classList.add('light-theme');
                themeIcon.className = 'fas fa-moon';
                themeText.textContent = currentUILanguage === 'ru' ? 'Темная' : 'Dark';
                localStorage.setItem('theme', 'light');
            }
        }

        // Load saved theme and language
        window.addEventListener('DOMContentLoaded', () => {
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') {
                toggleTheme();
            }
            init();
        });

        // Swap languages
        function swapLanguages() {
            [sourceText.value, targetText.value] = [targetText.value, sourceText.value];
            [sourceLang, targetLang] = [targetLang, sourceLang];
            
            updateLanguageDisplay('source', sourceLang);
            updateLanguageDisplay('target', targetLang);
            populateLanguageDropdowns();
            updateTTSButtons();
            updateTextLengths();
            
            if (sourceText.value.trim()) {
                translateText();
            }
        }

        // Source text change handler
        function onSourceTextChange() {
            updateTextLengths();
            hideError();
            hideInfo();
        }

        // Main translation function
        async function translateText() {
            const text = sourceText.value.trim();
            
            if (!text) {
                targetText.value = '';
                updateTextLengths();
                return;
            }
            
            showLoading();
            hideError();
            hideInfo();
            
            try {
                const response = await fetch('/translate', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        text: text,
                        source_lang: sourceLang,
                        target_lang: targetLang
                    })
                });
                
                const data = await response.json();
                
                if (response.ok) {
                    targetText.value = data.translation;
                    translationTime.textContent = data.time_ms;
                    updateTextLengths();
                    
                    // Show cascade translation info
                    if (data.cascade) {
                        showInfo(uiTranslations[currentUILanguage].cascade_translation);
                    }
                } else {
                    showError(data.error || uiTranslations[currentUILanguage].translation_error);
                }
                
            } catch (error) {
                showError(uiTranslations[currentUILanguage].network_error + error.message);
            } finally {
                hideLoading();
            }
        }

        // TTS Functions with transliteration
        async function speakSourceText() {
            const text = sourceText.value.trim();
            if (!text) return;
            
            await speakTextWithTransliteration(text, sourceLang, 'source-speak-btn');
        }

        async function speakTranslation() {
            const text = targetText.value.trim();
            if (!text) return;
            
            await speakTextWithTransliteration(text, targetLang, 'target-speak-btn');
        }

        async function speakTextWithTransliteration(text, langCode, buttonId) {
            const button = document.getElementById(buttonId);
            
            // If already playing, stop
            if (currentAudio) {
                currentAudio.pause();
                currentAudio = null;
                document.querySelectorAll('.icon-button').forEach(btn => {
                    btn.classList.remove('playing');
                });
                return;
            }
            
            try {
                // Show transliteration preview for relevant languages
                if (transliterationLanguages.includes(langCode)) {
                    await showTransliterationPreview(text, langCode);
                }
                
                button.classList.add('playing');
                
                // Determine correct speaker for language
                const speaker = ttsSpeakers[langCode] || 'ru_eduard';
                
                const response = await fetch('/synthesize', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        text: text,
                        speaker: speaker,  // Pass correct speaker
                        lang_code: langCode  // Pass language code for transliteration
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    currentAudio = new Audio(`/audio/${data.filename}`);
                    
                    currentAudio.onended = () => {
                        button.classList.remove('playing');
                        currentAudio = null;
                        // Delete file after playback
                        fetch(`/cleanup-audio/${data.filename}`, { method: 'POST' });
                    };
                    
                    currentAudio.onerror = () => {
                        button.classList.remove('playing');
                        currentAudio = null;
                        showError(uiTranslations[currentUILanguage].synthesis_error);
                    };
                    
                    await currentAudio.play();
                    
                    // Show transliteration info
                    if (data.transliterated) {
                        showInfo(`🔤 ${uiTranslations[currentUILanguage].tts_transliterated} ${data.speaker}`);
                    } else {
                        showInfo(`🔊 ${uiTranslations[currentUILanguage].tts_direct} ${data.speaker}`);
                        setTimeout(hideInfo, 3000);
                    }
                    
                    if (data.truncated) {
                        showError(uiTranslations[currentUILanguage].text_truncated);
                        setTimeout(hideError, 3000);
                    }
                } else {
                    button.classList.remove('playing');
                    showError(data.error || uiTranslations[currentUILanguage].synthesis_error);
                }
                
            } catch (error) {
                button.classList.remove('playing');
                showError(uiTranslations[currentUILanguage].synthesis_error + error.message);
            }
        }

        // Show transliteration preview
        async function showTransliterationPreview(text, langCode) {
            try {
                const response = await fetch('/preview-transliteration', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        text: text,
                        lang_code: langCode
                    })
                });
                
                const data = await response.json();
                
                if (data.success && data.needs_transliteration) {
                    // Create popup with preview
                    const popup = document.createElement('div');
                    popup.className = 'transliteration-preview';
                    popup.innerHTML = `
                        <h4><i class="fas fa-exchange-alt"></i> ${uiTranslations[currentUILanguage].transliteration_preview}</h4>
                        <div style="margin-bottom: 12px; font-size: 14px; opacity: 0.9;">
                            ${langCode} → ${data.target_speaker}
                        </div>
                        <div class="transliteration-text">
                            "${data.transliterated.length > 150 ? data.transliterated.substring(0, 150) + '...' : data.transliterated}"
                        </div>
                        <div class="transliteration-meta">
                            <i class="fas fa-info-circle"></i>
                            ${uiTranslations[currentUILanguage].transliteration_info}
                        </div>
                    `;
                    
                    document.body.appendChild(popup);
                    
                    // Auto-close after 3 seconds
                    setTimeout(() => {
                        if (popup.parentNode) {
                            popup.parentNode.removeChild(popup);
                        }
                    }, 3000);
                }
            } catch (error) {
                console.error('Transliteration preview error:', error);
            }
        }

        // Utility functions
        function updateTextLengths() {
            sourceLength.textContent = sourceText.value.length;
            targetLength.textContent = targetText.value.length;
        }

        function clearSourceText() {
            sourceText.value = '';
            targetText.value = '';
            updateTextLengths();
            hideError();
            hideInfo();
            sourceText.focus();
        }

        function copyTranslation() {
            if (targetText.value) {
                navigator.clipboard.writeText(targetText.value).then(() => {
                    const button = event.target.closest('.icon-button');
                    const originalHTML = button.innerHTML;
                    button.innerHTML = '<i class="fas fa-check"></i>';
                    setTimeout(() => {
                        button.innerHTML = originalHTML;
                    }, 2000);
                });
            }
        }

        function showLoading() {
            loadingElement.style.display = 'block';
        }

        function hideLoading() {
            loadingElement.style.display = 'none';
        }

        function showError(message) {
            errorMessage.textContent = message;
            errorMessage.style.display = 'block';
        }

        function hideError() {
            errorMessage.style.display = 'none';
        }

        function showInfo(message) {
            infoMessage.textContent = message;
            infoMessage.style.display = 'block';
        }

        function hideInfo() {
            infoMessage.style.display = 'none';
        }

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                e.preventDefault();
                translateText();
            }
            
            if ((e.ctrlKey || e.metaKey) && e.key === 'ArrowUp') {
                e.preventDefault();
                swapLanguages();
            }
            
            // Speech with Ctrl+Space
            if ((e.ctrlKey || e.metaKey) && e.key === ' ') {
                e.preventDefault();
                if (document.activeElement === sourceText) {
                    speakSourceText();
                } else if (document.activeElement === targetText) {
                    speakTranslation();
                }
            }
        });
    </script>
</body>
</html>
'''

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/translate', methods=['POST'])
def translate():
    try:
        data = request.get_json()
        text = data.get('text', '').strip()
        source_lang = data.get('source_lang', 'rus_Cyrl')
        target_lang = data.get('target_lang', 'kbd_Cyrl')
        
        if not text:
            return jsonify({'error': 'Enter text to translate'}), 400
        
        result = translator.translate(text, source_lang, target_lang)
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'error': f'Server error: {str(e)}'}), 500

@app.route('/synthesize', methods=['POST'])
def synthesize():
    try:
        data = request.get_json()
        text = data.get('text', '').strip()
        speaker = data.get('speaker', 'ru_eduard')  # Get speaker from request
        lang_code = data.get('lang_code')  # New parameter for transliteration
        
        if not text:
            return jsonify({'error': 'Enter text for speech synthesis'}), 400
        
        print(f"🔊 TTS request: lang_code={lang_code}, speaker={speaker}, text='{text[:50]}...'")
        
        # Use transliteration if language code provided AND transliteration needed
        if lang_code and transliterator.needs_transliteration(lang_code):
            print(f"🔤 Applying transliteration for {lang_code}")
            result = tts_service.synthesize(text, speaker, lang_code)
        else:
            # For languages without transliteration use provided speaker
            print(f"🔊 Direct TTS for {lang_code} with speaker {speaker}")
            result = tts_service.synthesize(text, speaker)
        
        return jsonify(result)
        
    except Exception as e:
        print(f"❌ Synthesis error: {e}")
        return jsonify({'error': f'Synthesis error: {str(e)}'}), 500

@app.route('/audio/<filename>')
def serve_audio(filename):
    try:
        filepath = os.path.join(tts_service.temp_dir, filename)
        if os.path.exists(filepath):
            return send_file(filepath, mimetype='audio/wav')
        else:
            return jsonify({'error': 'File not found'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/cleanup-audio/<filename>', methods=['POST'])
def cleanup_audio(filename):
    try:
        filepath = os.path.join(tts_service.temp_dir, filename)
        tts_service.cleanup_file(filepath)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/preview-transliteration', methods=['POST'])
def preview_transliteration():
    """Preview transliterated text"""
    try:
        data = request.get_json()
        text = data.get('text', '').strip()
        lang_code = data.get('lang_code')
        
        if not text or not lang_code:
            return jsonify({'error': 'Text and language code required'}), 400
        
        if transliterator.needs_transliteration(lang_code):
            # Determine target alphabet
            if lang_code in ['kat_Geor', 'hye_Armn']:
                target_script = 'kbd'
            else:
                target_script = 'kbd'
            
            transliterated = transliterator.transliterate_for_tts(
                text, lang_code, target_script
            )
            target_speaker = transliterator.get_target_speaker(lang_code)
            
            return jsonify({
                'success': True,
                'original': text,
                'transliterated': transliterated,
                'target_speaker': target_speaker,
                'needs_transliteration': True
            })
        else:
            return jsonify({
                'success': True,
                'original': text,
                'transliterated': text,
                'needs_transliteration': False
            })
            
    except Exception as e:
        return jsonify({'error': f'Transliteration error: {str(e)}'}), 500

@app.route('/languages')
def get_languages():
    """Return all languages with TTS information"""
    langs_data = translator.get_languages_by_group()
    
    # Add TTS speaker information for each language
    flat_langs = translator.get_flat_languages()
    tts_speakers = {}
    
    for lang_code in flat_langs.keys():
        tts_speakers[lang_code] = translator.get_tts_speaker(lang_code)
    
    return jsonify({
        'languages': langs_data['languages'],
        'groups': langs_data['groups'],
        'tts_speakers': tts_speakers
    })

@app.route('/ui-translations')
def get_ui_translations():
    """Return UI translations for current language"""
    lang = request.args.get('lang', 'ru')
    return jsonify(UI_TRANSLATIONS.get(lang, UI_TRANSLATIONS['ru']))

@app.route('/health')
def health_check():
    health = translator.health_check()
    health['tts_enabled'] = True
    health['tts_speakers'] = ['ru_eduard', 'kbd_eduard']
    health['transliteration_enabled'] = True
    health['transliteration_languages'] = ['tur_Latn', 'azj_Latn', 'kat_Geor', 'hye_Armn']
    health['ui_languages'] = ['ru', 'en']
    return jsonify(health)

# Cleanup on shutdown
def cleanup_on_shutdown():
    print("\n🛑 Stopping server...")
    translator.cleanup()
    tts_service.cleanup_all()
    cleanup_memory()
    print("✅ Cleanup completed")

atexit.register(cleanup_on_shutdown)

def signal_handler(sig, frame):
    cleanup_on_shutdown()
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

if __name__ == '__main__':
    health_info = translator.health_check()
    print("🚀 Kabardian Translator started (with transliteration)!")
    print(f"📊 Model: M2M100 (float16) + Silero TTS")
    print(f"🌐 Supported languages: {health_info['supported_languages_count']}")
    print(f"   • Slavic: Russian, Ukrainian, Belarusian")
    print(f"   • Caucasian/Turkic: Kabardian, Kazakh, Georgian, Armenian")
    print(f"   • Turkic: Turkish, Azerbaijani") 
    print(f"   • European: English, German, French, Spanish")
    print(f"💻 Device: {health_info['device']}")
    print(f"🔊 TTS with transliteration:")
    print(f"   • ru_eduard → Russian, Ukrainian, Belarusian, Latvian, German, Spanish")
    print(f"   • kbd_eduard → Kabardian, Kazakh + transliterated:")
    print(f"     - Turkish → Kabardian speaker")
    print(f"     - Azerbaijani → Kabardian speaker") 
    print(f"     - Georgian → Kabardian speaker")
    print(f"     - Armenian → Kabardian speaker")
    print(f"🔤 Transliteration: automatic for 7 languages")
    print(f"🌍 UI Languages: Russian, English")
    print(f"🎨 Themes: Light/Dark (toggle in interface)")
    print(f"🎤 Speech synthesis: up to 200 characters at a time")
    print(f"👁️ Preview: transliteration shown in popup")
    print(f"🧹 Auto-cleanup: temporary audio files deleted after playback")
    print("⚡ Optimizations:")
    print("   • float16 (memory saving ~50%)")
    print("   • torch.no_grad() for inference") 
    print("   • Cascade translation for pairs with Kabardian")
    print("   • Lazy loading of TTS model")
    print("   • Auto memory cleanup on start/stop")
    
    app.run(host='0.0.0.0', port=5500, debug=False)