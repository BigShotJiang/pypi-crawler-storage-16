# x-release-please-start-version
__version__ = "0.17.3rc13"
# x-release-please-end

SDK_NAME = "kadoa-python-sdk"
SDK_LANGUAGE = "python"
