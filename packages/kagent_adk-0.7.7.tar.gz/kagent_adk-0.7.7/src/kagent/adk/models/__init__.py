from ._openai import AzureOpenAI, OpenAI

__all__ = ["OpenAI", "AzureOpenAI"]
