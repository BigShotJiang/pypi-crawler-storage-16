import kaipy.kaiH5 as kh5
print(kh5.__file__)