from KairoCore import Panic

# User用户 异常 业务代码 20010 ~ 20021
SCM_USER_PARAM_VALIDATE_ERROR = Panic(20010, "用户参数验证失败，请检查！")