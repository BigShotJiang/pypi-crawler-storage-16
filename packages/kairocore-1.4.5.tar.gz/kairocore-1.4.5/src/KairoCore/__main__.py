"""允许使用 `python -m KairoCore` 作为命令入口。"""

from .cli import main


if __name__ == "__main__":
    main()

