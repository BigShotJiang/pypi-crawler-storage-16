# Kakariki

Speech-to-text library for Python.

## Installation

```bash
pip install kakariki
```

## Usage

Coming soon...

## License

MIT

