"""
Kakariki - Speech-to-text library
"""

__version__ = "0.0.1"

