import boto3

from adam.commands.export.importer import Importer
from adam.commands.export.utils_export import GeneratorStream, ing
from adam.config import Config
from adam.utils import log2
from adam.utils_athena import Athena
from adam.utils_k8s.pods import Pods

class AthenaImporter(Importer):
    def ping():
        session = boto3.session.Session()
        credentials = session.get_credentials()

        return credentials is not None

    def prefix(self):
        return 'e'

    def import_from_csv(self, pod: str, namespace: str, to_session: str, from_session: str, keyspace: str, table: str, target_table: str, columns: str, multi_tables = True, create_db = False):
        # db = self.db(self.prefix_adjusted_session(session), keyspace)
        csv_file = self.csv_file(from_session, table, target_table)
        db = self.db(to_session, keyspace)
        suppress_ing_log = self.suppress_ing_log(multi_tables)

        succeeded = False
        try:
            bucket = Config().get('export.bucket', 'c3.ops--qing')

            def upload_to_s3():
                bytes = Pods.read_file(pod, 'cassandra', namespace, csv_file)

                s3 = boto3.client('s3')
                s3.upload_fileobj(GeneratorStream(bytes), bucket, f'export/{db}/{keyspace}/{target_table}/{table}.csv')

            ing(f'[{to_session}] Uploading to S3', upload_to_s3, suppress_log=suppress_ing_log)

            def create_schema():
                query = f'CREATE DATABASE IF NOT EXISTS {db};'
                if Config().is_debug():
                    log2(query)
                Athena.query(query, 'default')

                query = f'DROP TABLE IF EXISTS {target_table};'
                if Config().is_debug():
                    log2(query)
                Athena.query(query, db)

                athena_columns = ', '.join([f'{c} string' for c in columns.split(',')])
                query = f'CREATE EXTERNAL TABLE IF NOT EXISTS {target_table}(\n' + \
                        f'    {athena_columns})\n' + \
                            "ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'\n" + \
                            'WITH SERDEPROPERTIES (\n' + \
                            '    "separatorChar" = ",",\n' + \
                            '    "quoteChar"     = "\\"")\n' + \
                        f"LOCATION 's3://{bucket}/export/{db}/{keyspace}/{target_table}'\n" + \
                            'TBLPROPERTIES ("skip.header.line.count"="1");'
                if Config().is_debug():
                    log2(query)
                try:
                    Athena.query(query, db)
                except Exception as e:
                    log2(f'*** Failed query:\n{query}')
                    raise e

            ing(f"[{to_session}] Creating database {db}" if create_db else f"Creating table {target_table}", create_schema, suppress_log=suppress_ing_log)

            to, _ = self.move_to_done(pod, namespace, to_session, from_session, keyspace, target_table)

            succeeded = True

            return to, to_session
        finally:
            if succeeded:
                self.remove_csv(pod, namespace, from_session, table, target_table, multi_tables)
                Athena.clear_cache()

                if not suppress_ing_log:
                    query = f'select * from {target_table} limit 10'
                    log2(query)
                    Athena.run_query(query, db)