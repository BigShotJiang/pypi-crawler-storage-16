from adam.commands.command import Command
from adam.commands.export.exporter import Exporter
from adam.repl_state import ReplState, RequiredState

class CleanUpExportSessions(Command):
    COMMAND = 'clean up all export sessions'

    # the singleton pattern
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, 'instance'): cls.instance = super(CleanUpExportSessions, cls).__new__(cls)

        return cls.instance

    def __init__(self, successor: Command=None):
        super().__init__(successor)

    def command(self):
        return CleanUpExportSessions.COMMAND

    def required(self):
        return RequiredState.CLUSTER_OR_POD

    def run(self, cmd: str, state: ReplState):
        if not(args := self.args(cmd)):
            return super().run(cmd, state)

        state, args = self.apply_state(args, state)
        if not self.validate_state(state):
            return state

        if Exporter.clean_up_all_sessions(state.sts, state.pod, state.namespace):
            Exporter.clear_export_session_cache()

        return state

    def completion(self, _: ReplState):
        return {}

    def help(self, _: ReplState):
        return f'{CleanUpExportSessions.COMMAND}\t clean up all export sessions'