from abc import abstractmethod
from adam.commands.command import Command
from adam.config import Config
from adam.repl_state import ReplState
from adam.utils import log2

class Device:
    @abstractmethod
    def ls(self, cmd: str, state: ReplState):
        pass

    def ls_completion(self, cmd: str, state: ReplState, default: dict = {}):
        return default

    def cd(self, dir: str, state: ReplState):
        pass

    def cd_completion(self, cmd: str, state: ReplState, default: dict = {}):
        return default

    @abstractmethod
    def pwd(self, state: ReplState):
        pass

    def try_fallback_action(self, chain: Command, state: ReplState, cmd: str):
        return False, None

    def enter(self, state: ReplState):
        pass

    def preview(self, table: str, state: ReplState):
        if not table:
            if state.in_repl:
                log2('Table is required.')
                log2()
                log2('Tables:')
                self.show_tables(state)
            else:
                log2('* Table is missing.')
                self.show_tables(state)

                Command.display_help()

            return 'command-missing'

        rows = Config().get('preview.rows', 10)
        self.show_table_preview(state, table, rows)

        return state

    @abstractmethod
    def show_tables(self, state: ReplState):
        pass

    @abstractmethod
    def show_table_preview(self, state: ReplState, table: str, rows: int):
        pass
