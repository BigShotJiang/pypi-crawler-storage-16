from abc import abstractmethod
from adam.commands.command import Command
from adam.config import Config
from adam.repl_state import ReplState
from adam.utils import log2

class Device:
    @abstractmethod
    def ls(self, cmd: str, state: ReplState):
        pass

    def ls_completion(self, cmd: str, state: ReplState, default: dict = {}):
        return default

    def cd(self, dir: str, state: ReplState):
        pass

    def cd_completion(self, cmd: str, state: ReplState, default: dict = {}):
        return default

    @abstractmethod
    def pwd(self, state: ReplState):
        pass

    def try_fallback_action(self, chain: Command, state: ReplState, cmd: str):
        return False, None

    def enter(self, state: ReplState):
        pass

    def preview(self, table: str, state: ReplState):
        if not table:
            if state.in_repl:
                log2('Table is required.')
                log2()
                log2('Tables:')
                self.show_tables(state)
            else:
                log2('* Table is missing.')
                self.show_tables(state)

                Command.display_help()

            return 'command-missing'

        rows = Config().get('preview.rows', 10)
        self.show_table_preview(state, table, rows)

        return state

    @abstractmethod
    def show_tables(self, state: ReplState):
        pass

    @abstractmethod
    def show_table_preview(self, state: ReplState, table: str, rows: int):
        pass

    def bash(self, s0: ReplState, s1: ReplState, args: list[str]):
            def _run(state_changed: bool, cli: Callable[[str], None]):
                if s1.in_repl:
                    if state_changed:
                        r = self.exec_with_dir(s1, args)
                    else:
                        r = self.exec_with_dir(s0, args)

                    if not r:
                        s1.exit_bash()

                        return 'inconsistent pwd'

                    return r
                else:
                    cli(' '.join(args))

                    return s1

            if s1.device == ReplState.A:
                def cli(command: str):
                    if s1.app_pod:
                        AppPods.exec(s1.app_pod, s1.namespace, command, show_out=True)
                    elif s1.app_app:
                        AppClusters.exec(AppPods.pod_names(s1.namespace, s1.app_env, s1.app_app), s1.namespace, command, action='bash', show_out=True)

                return _run(s0.app_env != s1.app_env or s0.app_app != s1.app_app or s0.app_pod != s1.app_pod, cli)
            elif s1.device == ReplState.P:
                def cli(command: str):
                    Pods.exec(s1.app_pod, 'ops', s1.namespace, command, show_out=True)

                return _run(s0.pg_path != s1.pg_path, cli)

            def cli(command: str):
                if s1.pod:
                    CassandraNodes.exec(s1.pod, s1.namespace, command, show_out=True)
                elif s1.sts:
                    CassandraClusters.exec(s1.sts, s1.namespace, command, action='bash', show_out=True)

            return _run(s0.sts != s1.sts or s0.pod != s1.pod, cli)

