"""Prompt templates for agentic correction."""

