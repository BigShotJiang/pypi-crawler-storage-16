from karrio.mappers.chronopost.mapper import Mapper
from karrio.mappers.chronopost.proxy import Proxy
from karrio.mappers.chronopost.settings import Settings
