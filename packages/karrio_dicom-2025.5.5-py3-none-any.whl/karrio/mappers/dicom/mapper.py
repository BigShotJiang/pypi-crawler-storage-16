from typing import List, Tuple
from karrio.core.utils.serializable import Serializable, Deserializable
from karrio.api.mapper import Mapper as BaseMapper
from karrio.core.models import (
    # ShipmentCancelRequest,
    # PickupUpdateRequest,
    # PickupCancelRequest,
    # ShipmentRequest,
    TrackingRequest,
    # PickupRequest,
    # RateRequest,
    #
    # ConfirmationDetails,
    TrackingDetails,
    # ShipmentDetails,
    # PickupDetails,
    # RateDetails,
    Message,
)
from karrio.providers.dicom import (
    # parse_shipment_cancel_response,
    # parse_pickup_update_response,
    # parse_pickup_cancel_response,
    # parse_shipment_response,
    parse_tracking_response,
    # parse_pickup_response,
    # parse_rate_response,
    #
    # shipment_cancel_request,
    # pickup_update_request,
    # pickup_cancel_request,
    tracking_request,
    # shipment_request,
    # pickup_request,
    # rate_request,
)
from karrio.mappers.dicom.settings import Settings


class Mapper(BaseMapper):
    settings: Settings

    # def create_rate_request(
    #     self, payload: RateRequest
    # ) -> Serializable:
    #     return rate_request(payload, self.settings)

    def create_tracking_request(self, payload: TrackingRequest) -> Serializable:
        return tracking_request(payload, self.settings)

    # def create_shipment_request(
    #     self, payload: ShipmentRequest
    # ) -> Serializable:
    #     return shipment_request(payload, self.settings)
    #
    # def create_pickup_request(
    #     self, payload: PickupRequest
    # ) -> Serializable:
    #     return pickup_request(payload, self.settings)
    #
    # def create_pickup_update_request(
    #     self, payload: PickupUpdateRequest
    # ) -> Serializable:
    #     return pickup_update_request(payload, self.settings)
    #
    # def create_cancel_pickup_request(
    #     self, payload: PickupCancelRequest
    # ) -> Serializable:
    #     return pickup_cancel_request(payload, self.settings)
    #
    # def create_cancel_shipment_request(self, payload: ShipmentCancelRequest) -> Serializable:
    #     return shipment_cancel_request(payload, self.settings)

    # def parse_cancel_pickup_response(
    #     self, response: Deserializable
    # ) -> Tuple[ConfirmationDetails, List[Message]]:
    #     return parse_pickup_cancel_response(response, self.settings)
    #
    # def parse_cancel_shipment_response(
    #     self, response: Deserializable
    # ) -> Tuple[ConfirmationDetails, List[Message]]:
    #     return parse_shipment_cancel_response(response, self.settings)
    #
    # def parse_pickup_response(
    #     self, response: Deserializable
    # ) -> Tuple[PickupDetails, List[Message]]:
    #     return parse_pickup_response(response, self.settings)
    #
    # def parse_pickup_update_response(
    #     self, response: Deserializable
    # ) -> Tuple[PickupDetails, List[Message]]:
    #     return parse_pickup_update_response(response, self.settings)
    #
    # def parse_rate_response(
    #     self, response: Deserializable
    # ) -> Tuple[List[RateDetails], List[Message]]:
    #     return parse_rate_response(response, self.settings)
    #
    # def parse_shipment_response(
    #     self, response: Deserializable
    # ) -> Tuple[ShipmentDetails, List[Message]]:
    #     return parse_shipment_response(response, self.settings)

    def parse_tracking_response(
        self, response: Deserializable
    ) -> Tuple[List[TrackingDetails], List[Message]]:
        return parse_tracking_response(response, self.settings)
