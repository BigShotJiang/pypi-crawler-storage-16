import datetime
import karrio.lib as lib
import karrio.core as core
import karrio.core.errors as errors
import karrio.core.models as models


class Settings(core.Settings):
    """eShipper connection settings."""

    principal: str
    credential: str

    @property
    def carrier_name(self):
        return "eshipper"

    @property
    def server_url(self):
        return (
            "https://uu2.eshipper.com" if self.test_mode else "https://ww2.eshipper.com"
        )

    @property
    def access_token(self):
        """Retrieve the "token" using the principal|credential pair
        or collect it from the cache if an unexpired "token" exist.
        """
        cache_key = f"{self.carrier_name}|{self.principal}|{self.credential}"

        return self.connection_cache.thread_safe(
            refresh_func=lambda: login(self),
            cache_key=cache_key,
            buffer_minutes=30,
            token_field="token",
        ).get_state()


def login(settings: Settings):
    """Sign in response
    {
      "token": "string",
      "expires_in": "string",
      "token_type": "string",
      "refresh_token": "string",
      "refresh_expires_in": "string"
    }
    """
    import karrio.providers.eshipper.error as error

    result = lib.request(
        url=f"{settings.server_url}/api/v2/authenticate",
        data=lib.to_json(
            {
                "principal": settings.principal,
                "credential": settings.credential,
            }
        ),
        method="POST",
        headers={"content-Type": "application/json"},
    )
    response = lib.to_dict(result)
    messages = error.parse_error_response(response, settings)

    if any(messages):
        raise errors.ParsedMessagesError(messages=messages)

    # Validate that token is present in the response
    if "token" not in response:
        raise errors.ParsedMessagesError(
            messages=[
                models.Message(
                    carrier_name=settings.carrier_name,
                    carrier_id=settings.carrier_id,
                    message="Authentication failed: No token received",
                    code="AUTH_ERROR",
                )
            ]
        )

    expiry = datetime.datetime.now() + datetime.timedelta(
        seconds=float(response.get("expires_in", 0))
    )
    return {**response, "expiry": lib.fdatetime(expiry)}
