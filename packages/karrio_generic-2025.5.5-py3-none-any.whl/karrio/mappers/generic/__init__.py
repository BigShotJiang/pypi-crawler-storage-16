from karrio.mappers.generic.mapper import Mapper
from karrio.mappers.generic.proxy import Proxy
from karrio.mappers.generic.settings import Settings
