import logging

logging.disable(logging.CRITICAL)

from karrio.server.providers.tests.test_connections import *
