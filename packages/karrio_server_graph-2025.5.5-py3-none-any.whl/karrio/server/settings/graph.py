# type: ignore
from karrio.server.settings.base import *


INSTALLED_APPS += [
    "strawberry.django",
]
