import karrio.server.manager.views.addresses
import karrio.server.manager.views.parcels
import karrio.server.manager.views.shipments
import karrio.server.manager.views.trackers
import karrio.server.manager.views.customs
import karrio.server.manager.views.pickups
import karrio.server.manager.views.documents
import karrio.server.manager.views.manifests
from karrio.server.manager.router import router
