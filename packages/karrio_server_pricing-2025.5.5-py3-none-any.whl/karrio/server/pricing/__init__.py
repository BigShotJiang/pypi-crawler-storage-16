default_app_config = 'karrio.server.pricing.apps.PricingConfig'
