import logging

logging.disable(logging.CRITICAL)

from karrio.server.proxy.tests.test_rating import *
from karrio.server.proxy.tests.test_shipping import *
from karrio.server.proxy.tests.test_tracking import *
from karrio.server.proxy.tests.test_pickup import *
