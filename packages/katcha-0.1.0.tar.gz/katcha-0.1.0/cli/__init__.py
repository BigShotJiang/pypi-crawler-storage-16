"""Katcha CLI - Schema-aware seed-data orchestrator."""

__version__ = "0.1.0"
