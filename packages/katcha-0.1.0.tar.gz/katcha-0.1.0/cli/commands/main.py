import typer

from cli.commands.init import init
from cli.commands.build import build
from cli.commands.seed import seed

app = typer.Typer(
    name="katcha",
    help="Schema-aware seed-data orchestrator",
    no_args_is_help=True,
)

app.command()(init)
app.command()(build)
app.command()(seed)


def main():
    """Entry point for the CLI."""
    app()


if __name__ == "__main__":
    main()
