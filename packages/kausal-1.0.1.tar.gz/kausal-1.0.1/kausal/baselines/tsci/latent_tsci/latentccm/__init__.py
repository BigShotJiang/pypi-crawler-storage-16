__version__ = "0.1.0"
import os.path

DATADIR = os.path.join(os.path.dirname(__file__), "..", "data")
EXPDIR = os.path.join(os.path.dirname(__file__), "..", "experiments")
