from .pinv import PINV
from .dmd import DMD