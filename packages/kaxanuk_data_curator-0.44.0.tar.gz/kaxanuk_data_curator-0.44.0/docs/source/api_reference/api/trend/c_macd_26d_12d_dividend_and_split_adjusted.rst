.. _c_macd_26d_12d_dividend_and_split_adjusted_ref:

c_macd_26d_12d_dividend_and_split_adjusted
==========================================

.. currentmodule:: kaxanuk.data_curator.features.calculations

.. autofunction:: c_macd_26d_12d_dividend_and_split_adjusted
   :no-index:
