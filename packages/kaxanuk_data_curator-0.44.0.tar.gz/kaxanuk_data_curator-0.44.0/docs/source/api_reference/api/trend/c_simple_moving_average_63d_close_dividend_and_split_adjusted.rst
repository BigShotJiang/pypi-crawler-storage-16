.. _c_simple_moving_average_63d_close_dividend_and_split_adjusted_ref:

c_simple_moving_average_63d_close_dividend_and_split_adjusted
=============================================================

.. currentmodule:: kaxanuk.data_curator.features.calculations

.. autofunction:: c_simple_moving_average_63d_close_dividend_and_split_adjusted
   :no-index:
