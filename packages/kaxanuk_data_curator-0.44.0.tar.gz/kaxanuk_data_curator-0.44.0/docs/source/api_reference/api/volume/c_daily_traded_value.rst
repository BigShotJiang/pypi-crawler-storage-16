.. _c_daily_traded_value_ref:

c_daily_traded_value
====================

.. currentmodule:: kaxanuk.data_curator.features.calculations

.. autofunction:: c_daily_traded_value
   :no-index:
