.. _c_daily_traded_value_sma_21d_ref:

c_daily_traded_value_sma_21d
============================

.. currentmodule:: kaxanuk.data_curator.features.calculations

.. autofunction:: c_daily_traded_value_sma_21d
   :no-index:
