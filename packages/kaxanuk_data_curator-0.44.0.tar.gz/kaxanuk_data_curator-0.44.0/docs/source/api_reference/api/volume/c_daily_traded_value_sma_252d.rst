.. _c_daily_traded_value_sma_252d_ref:

c_daily_traded_value_sma_252d
=============================

.. currentmodule:: kaxanuk.data_curator.features.calculations

.. autofunction:: c_daily_traded_value_sma_252d
   :no-index:
