"""
Package containing built-in data blocks (with provisional API, subject to change).
"""
