"""
Package containing the feature calculation functions and their related helpers.
"""
