# -*- coding: utf-8 -*-
import requests,traceback,time
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
from .selenium3 import webdriver as webdriver3
from .selenium3.webdriver.chrome.options import Options as Options3
from .selenium3.webdriver.common.by import By as webdriver3By
class Http:
    By=webdriver3By
    "http请求类"
    set_proxies=None  #设置代理
    set_cookies={} #设置请求cookie
    set_header={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36'} #请求头
    set_timeout=(6.05,10) #超时时间  6.05表示连接采时时间  3030表示读取超时时间  #注意 set_timeout参数主要关注的是“无响应”的时间段，而不是整个请求的处理时间
    set_max_retries=2 #重试次数 (实际请求3次)
    set_verify=False  #SSL 证书的验证 sll证书路径
    set_encoding="" #设置text输出编码 如utf-8 不填表示自动
    set_session=True #是否启用会话

    get_header={} #获取响应头
    get_cookies={} #获取最后的响应cookie
    get_cookie_str='' #获取最后的响应cookie 字符串
    get_text='' #获取body响应内容
    get_content='' #获取body响应二进制内容
    get_response='' #获取响应对象
    get_status_code=None #获取响应状态码
    keep_alive=True #默认的http connection是keep-alive的  False表示关闭
    req=None
    def __init(self):
        self.set_proxies=None  #设置代理
        self.set_cookies={} #设置请求cookie
        self.set_header={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36'} #请求头
        self.set_timeout=(6.05,10) #超时时间  6.05表示连接采时时间  3030表示读取超时时间  #注意 set_timeout参数主要关注的是“无响应”的时间段，而不是整个请求的处理时间
        self.set_max_retries=2 #重试次数 (实际请求3次)
        self.set_verify=False  #SSL 证书的验证 sll证书路径
        self.set_encoding="" #设置text输出编码
        self.set_session=True #是否启用会话

        self.get_header={} #获取响应头
        self.get_cookies={} #获取最后的响应cookie
        self.get_cookie_str='' #获取最后的响应cookie 字符串
        self.get_text='' #获取body响应内容
        self.get_content='' #获取body响应二进制内容
        self.get_response='' #获取响应对象
        self.get_status_code=None #获取响应状态码
        self.keep_alive=True #默认的http connection是keep-alive的  False表示关闭
        self.req=None
    def __init__(self):
        self.__init()
    def __del__(self):
        self.__init()
    def gettext(self):
        """得到响应text"""
        return self.get_text
    PhantomJsObj=None
    def open_PhantomJS(self,url,executable_path='',closedriver=True):
        """通过PhantomJS引擎模拟浏览器请求 可以获取到js渲染后的html

        """
        if not self.PhantomJsObj:
            self.PhantomJsObj=webdriver3.PhantomJS(executable_path=executable_path)
        if self.set_session:
            self.get_cookies=self.set_cookies
            for k in self.PhantomJsObj.get_cookies():
                self.get_cookies=self.__merge(self.get_cookies,k)
            if self.get_cookies:
                self.get_cookie_str=self.cookieTdictstr(self.get_cookies)
                self.get_cookies=self.cookieserTdict(self.get_cookie_str)
            if self.get_cookies!=self.set_cookies:
                self.PhantomJsObj.delete_all_cookies()
                for name,value in self.set_cookies:
                    t={'name':name, 'value':value}
                    self.PhantomJsObj.add_cookie(t)
        


        self.PhantomJsObj.get(url)

        if not closedriver:
            response = requests.head(url,cookies=self.set_cookies,allow_redirects=True)
            resheader=dict(response.headers)
            self.get_header={}
            for k in resheader:
                self.get_header[k.lower()]=resheader[k]
                    
        self.get_text = self.PhantomJsObj.page_source
        self.get_cookies=self.set_cookies
        for k in reversed(self.PhantomJsObj.get_cookies()):
            zd={k['name']:k['value']}
            self.get_cookies=self.__merge(self.get_cookies,zd)
        if self.get_cookies:
            self.get_cookie_str=self.cookieTdictstr(self.get_cookies)
            self.get_cookies=self.cookieserTdict(self.get_cookie_str)
        if self.set_session:
            self.set_cookies=self.get_cookies
        if closedriver:
            self.PhantomJsObj.quit()
    ChromeObj=None
    def open_Chrome(self,url,executable_path='',closedriver=True,setheadless=True):
        """通过Chrome浏览器引擎模拟浏览器请求 可以获取到js渲染后的html

        closedriver 是否关闭退出

        setheadless 是否设置无头

        """
        if not self.ChromeObj:
            chrome_options = Options3()
            if setheadless:
                chrome_options.add_argument("--headless") #设置无头
            chrome_options.add_argument("--disable-gpu")  # 禁用GPU硬件加速，适用于Linux和Windows系统
            chrome_options.add_argument("--no-sandbox")  # 禁用沙盒模式，在某些Linux系统上需要
            try:
                self.ChromeObj = webdriver3.Chrome(executable_path=executable_path,chrome_options=chrome_options)
            except Exception as e:
                import os
                print("\033[93mChromeChromeChromeChromeChromeChromeChromeChromeChromeChromeChromeChromeve\033[0m",e)
                if os.name == 'nt' and 'Driver info: chromedriver=142.0.7444.175' in str(e):
                    # print("\033[93mchromedriver与您操作系统的Chrome不兼容性 下载地址参考",'https://file.kwebapp.cn/sh/install/chrome/chromedriver-win64-142/GoogleChrome.msi\033[0m')
                    response=requests.get('https://file.kwebapp.cn/sh/install/chrome/chromedriver-win64-142/GoogleChrome.msi')
                    f=open('Chrome.msi',"wb")
                    tsize=f.write(response.content)
                    f.close()
                    if tsize<10*1024*1024:
                        os.remove('Chrome.msi')
                        raise Exception('文件下载失败:https://file.kwebapp.cn/sh/install/chrome/chromedriver-win64-142/GoogleChrome.msi')
                    print('\033[93mchromedriver与您操作系统的Chrome不兼容/不存在，正在为您安装Chrome...\033[0m')
                    os.system("msiexec /i Chrome.msi")
                    os.remove('Chrome.msi')
                    # print('\033[93m安装完成，请重试\033[0m')
                    self.open_Chrome(url=url,executable_path=executable_path,closedriver=closedriver,setheadless=setheadless)
                elif os.name == 'posix' and 'Driver info: chromedriver=106.0.5249.21' in str(e):
                    def systemtypes():
                        try:
                            with open('/etc/os-release', 'r') as f:
                                content = f.read()
                                if 'CentOS-7' in content or 'CentOS Linux 7' in content:
                                    return 'CentOS7'
                        except FileNotFoundError:
                            pass
                        return False
                    t=systemtypes()
                    if t=='CentOS7':
                        # print("\033[93mchromedriver与您操作系统的Chrome不兼容性 下载地址参考",'https://file.kwebapp.cn/sh/install/chrome/google-chrome-unstable-106.0.5249.12-1.x86_64.rpm\033[0m')
                        response=requests.get('https://file.kwebapp.cn/sh/install/chrome/google-chrome-unstable-106.0.5249.12-1.x86_64.rpm')
                        f=open('google-chrome-unstable-106.0.5249.12-1.x86_64.rpm',"wb")
                        tsize=f.write(response.content)
                        f.close()
                        if tsize<10*1024*1024:
                            os.remove('google-chrome-unstable-106.0.5249.12-1.x86_64.rpm')
                            raise Exception('文件下载失败:https://file.kwebapp.cn/sh/install/chrome/google-chrome-unstable-106.0.5249.12-1.x86_64.rpm')
                
                        print('\033[93mchromedriver与您操作系统的Chrome不兼容/不存在，正在为您安装Chrome...\033[0m')
                        os.system("sudo yum -y install google-chrome-unstable-106.0.5249.12-1.x86_64.rpm")
                        os.remove('google-chrome-unstable-106.0.5249.12-1.x86_64.rpm')
                        # print('\033[93m安装完成，请重试\033[0m')
                        self.open_Chrome(url=url,executable_path=executable_path,closedriver=closedriver,setheadless=setheadless)
                    else:
                        raise Exception('暂不支持该操作系统版本，目前仅支持CentOS7和windows10。')
                else:
                    raise Exception('暂不支持该操作系统版本，目前仅支持CentOS7和windows10')
        
        if self.ChromeObj:    
            if self.set_session:
                self.get_cookies=self.set_cookies
                for k in self.ChromeObj.get_cookies():
                    self.get_cookies=self.__merge(self.get_cookies,k)
                if self.get_cookies:
                    self.get_cookie_str=self.cookieTdictstr(self.get_cookies)
                    self.get_cookies=self.cookieserTdict(self.get_cookie_str)
                if self.get_cookies!=self.set_cookies:
                    self.ChromeObj.delete_all_cookies()
                    for name,value in self.set_cookies:
                        t={'name':name, 'value':value}
                        self.ChromeObj.add_cookie(t)
            
            

            self.ChromeObj.get(url)
            # time.sleep(5)
            # print('self.ChromeObj.get_cookies()',self.ChromeObj.get_cookies())
            if not closedriver:
                response = requests.head(url,cookies=self.set_cookies,allow_redirects=True)
                resheader=dict(response.headers)
                self.get_header={}
                for k in resheader:
                    self.get_header[k.lower()]=resheader[k]
                time.sleep(0.1)
            else:
                time.sleep(0.5)
            self.get_text = self.ChromeObj.page_source
            self.get_cookies=self.set_cookies
            for k in reversed(self.ChromeObj.get_cookies()):
                zd={k['name']:k['value']}
                self.get_cookies=self.__merge(self.get_cookies,zd)
            if self.get_cookies:
                self.get_cookie_str=self.cookieTdictstr(self.get_cookies)
                self.get_cookies=self.cookieserTdict(self.get_cookie_str)
            if self.set_session:
                self.set_cookies=self.get_cookie_str
            if closedriver:
                self.ChromeObj.close()
                self.ChromeObj.quit()
    def close_webdriver(self):
        if self.ChromeObj:
            self.ChromeObj.close()
            self.ChromeObj.quit()
        if self.PhantomJsObj:
            self.PhantomJsObj.quit()
            
    def openurl(self,url,method="GET",data=None,params=None,jsonparams=None,files=None,allow_redirects=True):
        """模拟浏览器请求

        url : 目标地址

        method ：GET POST 等

        data：请求参数

        params:请求参数

        jsonparams:请求json参数

        file 上传文件

        allow_redirects 是否重定向
        """
        if self.set_session:
            if self.req is None:
                self.req = requests.Session()
                self.req.mount('http://', requests.adapters.HTTPAdapter(max_retries=self.set_max_retries))
                self.req.mount('https://', requests.adapters.HTTPAdapter(max_retries=self.set_max_retries))
                # print('requests初始化')
        else:
            if self.req is None:
                self.req = requests
                # print('requests初始化')
        if not self.keep_alive:
            self.req.keep_alive=False
        if self.set_cookies and isinstance(self.set_cookies,str):
            self.set_cookies=self.cookieserTdict(self.set_cookies)
        response=self.req.request(method, url,data=data,params=params,json=jsonparams,files=files,proxies=self.set_proxies,cookies=self.set_cookies,headers=self.set_header,timeout=self.set_timeout,verify=self.set_verify,allow_redirects=allow_redirects)
        if self.set_encoding:
            response.encoding=self.set_encoding
        else:
            response.encoding=response.apparent_encoding
        resheader=dict(response.headers)
        self.get_header={}
        for k in resheader:
            self.get_header[k.lower()]=resheader[k]
        cookie=requests.utils.dict_from_cookiejar(response.cookies)
        if self.get_cookies and cookie:
            self.get_cookies=self.__merge(self.get_cookies,cookie)
        elif cookie:
            self.get_cookies=cookie
        if self.set_cookies:
            self.get_cookies=self.__merge(self.set_cookies,self.get_cookies)
        if self.get_cookies:
            self.get_cookie_str=self.cookieTdictstr(self.get_cookies)
        self.get_text=response.text
        self.get_content=response.content
        self.get_response=response
        self.get_status_code=int(response.status_code)
    def __is_index(self,params,index):
        """判断列表或字典里的索引是否存在

        params  列表或字典

        index   索引值

        return Boolean类型
        """
        try:
            params[index]
        except KeyError:
            return False
        except IndexError:
            return False
        else:
            return True
    def __merge(self,dict1, dict2):
        "合并两个字典"
        C_dict = {}
        for key,value in dict1.items():
            C_dict[key]=value
        for key,value in dict2.items():
            if value:
                if isinstance(value, str) or (self.__is_index(C_dict,key) and isinstance(C_dict[key], str)):
                    if self.__is_index(C_dict,key):
                        t1,t2=len(str(value)),len(str(C_dict[key]))
                        if t1>=t2:
                            C_dict[key]=value
                    else:
                        C_dict[key]=value
                else:
                    C_dict[key]=value
        return C_dict
    def cookieserTdict(self,cookiesstr):
        "cookies字符串转换字典"
        if isinstance(cookiesstr,str):
            cok={}
            for line in cookiesstr.split(";"):
                lists=line.split("=",1)
                # print(lists[])
                if lists[0] and len(lists)==2:
                    cok[lists[0]]=lists[1]
            return cok
    def cookieTdictstr(self,cookie):
        cookiestr=''
        for key in cookie:
            if not cookie[key]:
                cookie[key]=''
            cookiestr+=str(key)+"="+str(cookie[key])+";"
        return cookiestr