# -*- coding: utf-8 -*-
from . autoload import *
from . import globals
from . import request
G=globals.G #5.328之后的版本将G作为框架用户全局变量 与之前的“globals.G”功能相同 
