"""Kdenlive MCP - Model Context Protocol server for Kdenlive automation."""

from kdenlive_mcp.server import main, mcp

__version__ = "0.1.0"
__all__ = ["main", "mcp"]
