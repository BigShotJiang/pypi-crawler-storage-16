from KeePassDiff.launch import launch

launch()
