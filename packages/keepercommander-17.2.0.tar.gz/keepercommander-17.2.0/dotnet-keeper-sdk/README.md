Note: The .Net SDK has moved. For the latest Commander SDK for .Net and PowerShell, see below:

Visit the [Keeper .Net and PowerShell library](https://github.com/Keeper-Security/keeper-sdk-dotnet)
