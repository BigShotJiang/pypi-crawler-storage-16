__version__ = '0.3.2'

# lastpass-ruby's version
VERSION = '1.5.0'
