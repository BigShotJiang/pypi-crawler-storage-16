from enum import Enum


class Task_Type(Enum):
    Train = "train"
    Test = "test"
    Val = "val"
