from .recorder import MainRecorder

main_recorder = MainRecorder()