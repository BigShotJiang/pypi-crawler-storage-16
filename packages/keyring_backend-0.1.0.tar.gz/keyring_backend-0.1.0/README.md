# Python Keyring Backend

This package provides a custom Python keyring backend.
It can be used in e.g., Alpine Linux containers, where the system keyring is not available.
