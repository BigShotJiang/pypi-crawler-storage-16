import keyring

from keyring_backend.backend import Backend

keyring.set_keyring(Backend())
