import keyring.backend
from keyring_backend import files, secure


class Service:
  def __init__(self, directory: str):
    self._directory = directory
    self._users: dict[str, str] = {}  # username -> filename

  @property
  def directory_path(self) -> str:
    return self._directory

  def set_filename(self, name: str, filename: str) -> None:
    self._users[name] = filename

  def get_filename(self, name: str) -> str | None:
    return self._users.get(name)


class Backend(keyring.backend.KeyringBackend):
  priority = 1

  def __init__(self):
    super().__init__()
    self._services: dict[str, Service] = {}
    files.init_root()

  def get_password(self, service: str, username: str) -> str | None:
    srv_dir = self._services.get(service)
    if srv_dir is None:
      return None
    read = files.read(srv_dir.directory_path, srv_dir.get_filename(username))
    srv_dir.set_filename(username, read.filename)
    return secure.decrypt(read.content).decode()

  def set_password(self, service: str, username: str, password: str) -> None:
    srv = self._services.get(service)
    if srv is None:
      srv = Service(files.init_service())
      self._services[service] = srv
    created = files.create(srv.directory_path, username, secure.encrypt(password))
    srv.set_filename(username, created)
