import os
import tempfile
from dataclasses import dataclass


@dataclass
class UpdatedEntry:
  filename: str
  content: str


def _get_dir(service):
  return os.path.join(tempfile.gettempdir(), 'kb', service)


def create(service, user, content) -> str:
  with tempfile.NamedTemporaryFile(delete=False,
                                   dir=_get_dir(service)) as f:
    f.write(content.encode('utf-8'))
  return f.name


def init_root() -> None:
  os.makedirs(os.path.join(tempfile.gettempdir(), 'kb'), exist_ok=True)


def init_service() -> str:
  return tempfile.TemporaryDirectory(dir=os.path.join(tempfile.gettempdir(), 'kb'), delete=False).name


def read(service, user) -> UpdatedEntry:
  content = ''
  with open(os.path.join(_get_dir(service), user), 'r') as f:
    content = f.read()
  new_file = create(service, user, content)
  return UpdatedEntry(new_file, content)
