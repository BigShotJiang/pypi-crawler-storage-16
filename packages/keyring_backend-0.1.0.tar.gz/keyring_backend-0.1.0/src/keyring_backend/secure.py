import base64

from cryptography.fernet import Fernet


def encrypt(message: str | bytes):
  if isinstance(message, str):
    message = message.encode()
  key = Fernet.generate_key()
  try:
    ciphertext = Fernet(key).encrypt(message)
    return base64.b64encode(key + ciphertext).decode()
  finally:
    del key


def decrypt(ciphertext):
  raw_data = base64.b64decode(ciphertext)
  try:
    return Fernet(raw_data[:44]).decrypt(raw_data[44:])
  finally:
    del raw_data
