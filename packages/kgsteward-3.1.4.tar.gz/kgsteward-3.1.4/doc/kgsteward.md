# kgsteward vocabulary

```ttl

prefix kgsteward: <https://purl.expasy.org/kgsteward/> .

kgsteward:checkSum a rdf:Property .

```
