"""
For compatibility with legacy builds or tools that don't support certain
packaging standards.
"""

from setuptools import setup

setup()
