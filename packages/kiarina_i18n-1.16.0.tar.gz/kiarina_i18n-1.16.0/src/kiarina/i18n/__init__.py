import logging
from importlib import import_module
from importlib.metadata import version
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ._helpers.get_translator import get_translator
    from ._models.translator import Translator
    from ._settings import I18nSettings, settings_manager
    from ._types.catalog import Catalog
    from ._types.i18n_key import I18nKey
    from ._types.i18n_scope import I18nScope
    from ._types.language import Language

__version__ = version("kiarina-i18n")

__all__ = [
    # ._helpers
    "get_translator",
    # ._models
    "Translator",
    # ._settings
    "I18nSettings",
    "settings_manager",
    # ._types
    "Catalog",
    "I18nKey",
    "I18nScope",
    "Language",
]

logging.getLogger(__name__).addHandler(logging.NullHandler())


def __getattr__(name: str) -> object:
    if name not in __all__:
        raise AttributeError(f"module '{__name__}' has no attribute '{name}'")

    module_map = {
        # ._helpers
        "get_translator": "._helpers.get_translator",
        # ._models
        "Translator": "._models.translator",
        # ._settings
        "I18nSettings": "._settings",
        "settings_manager": "._settings",
        # ._types
        "Catalog": "._types.catalog",
        "I18nKey": "._types.i18n_key",
        "I18nScope": "._types.i18n_scope",
        "Language": "._types.language",
    }

    globals()[name] = getattr(import_module(module_map[name], __name__), name)
    return globals()[name]
