def test_sanity() -> None:
    print("placeholder")
    assert True
