What's new-
Added progress bars, sliders, and checkboxes