from PyQt6.QtWidgets import (
    QLabel, QPushButton, QLineEdit, QComboBox, QWidget,
    # New imports for v0.4.0
    QCheckBox, QProgressBar, QScrollBar, QSlider 
)
from PyQt6.QtWebEngineWidgets import QWebEngineView 
from PyQt6.QtCore import QUrl, Qt 

# --- Existing Widgets (v0.3.0) ---

class Label:
    def __init__(self, text="Label", parent=None):
        self.qt_widget = QLabel(text, parent)
        self.qt_widget.setStyleSheet("font-size: 14pt; margin: 5px;")
    
    def set_text(self, text):
        self.qt_widget.setText(text)

class Button:
    def __init__(self, text="Button", on_click=None, parent=None):
        self.qt_widget = QPushButton(text, parent)
        self.qt_widget.setStyleSheet("padding: 8px 15px; background-color: #4CAF50; color: white; border-radius: 5px; border: none;")
        if on_click:
            self.qt_widget.clicked.connect(on_click)

class TextBox:
    def __init__(self, initial_text="", placeholder="Enter text...", parent=None):
        self.qt_widget = QLineEdit(initial_text, parent)
        self.qt_widget.setPlaceholderText(placeholder)
        self.qt_widget.setStyleSheet("padding: 5px; border: 1px solid #ccc; border-radius: 3px;")
    
    def get_text(self):
        return self.qt_widget.text()

class Dropdown:
    def __init__(self, items=None, parent=None):
        self.qt_widget = QComboBox(parent)
        if items:
            self.qt_widget.addItems(items)
        self.qt_widget.setStyleSheet("padding: 5px; border: 1px solid #ccc; border-radius: 3px;")
    
    def get_selected(self):
        return self.qt_widget.currentText()

class Browser:
    """A web browser widget using QWebEngineView."""
    def __init__(self, url="https://www.google.com", parent=None):
        self.qt_widget = QWebEngineView(parent)
        self.load_url(url)
        self.qt_widget.setMinimumHeight(400) 

    def load_url(self, url):
        """Loads a given URL in the browser view."""
        self.qt_widget.setUrl(QUrl(url))

    def reload(self):
        """Reloads the current page."""
        self.qt_widget.reload()

# --- New Widgets for v0.4.0 ---

class Checkbox:
    """A simple check box for boolean input."""
    def __init__(self, text="Check me", checked=False, on_toggle=None, parent=None):
        self.qt_widget = QCheckBox(text, parent)
        self.qt_widget.setChecked(checked)
        self.qt_widget.setStyleSheet("margin: 5px;")
        if on_toggle:
            self.qt_widget.stateChanged.connect(on_toggle)

    def is_checked(self):
        return self.qt_widget.isChecked()

class ProgressBar:
    """A bar to display task progress."""
    def __init__(self, minimum=0, maximum=100, value=0, parent=None):
        self.qt_widget = QProgressBar(parent)
        self.qt_widget.setRange(minimum, maximum)
        self.qt_widget.setValue(value)
        self.qt_widget.setTextVisible(True)
        self.qt_widget.setStyleSheet("height: 20px; margin: 10px 0;")

    def set_value(self, value):
        self.qt_widget.setValue(value)

    def get_value(self):
        return self.qt_widget.value()

class Slider:
    """A horizontal slider for selecting a value in a range."""
    def __init__(self, minimum=0, maximum=100, value=50, on_value_change=None, parent=None):
        # We specify Horizontal orientation using Qt.Orientation.Horizontal
        self.qt_widget = QSlider(Qt.Orientation.Horizontal, parent)
        self.qt_widget.setRange(minimum, maximum)
        self.qt_widget.setValue(value)
        self.qt_widget.setStyleSheet("margin: 10px 0;")
        
        if on_value_change:
            self.qt_widget.valueChanged.connect(on_value_change)

    def get_value(self):
        return self.qt_widget.value()

class Scrollbar:
    """A basic vertical scroll bar, useful for manual control or within custom widgets."""
    def __init__(self, minimum=0, maximum=100, value=0, on_value_change=None, parent=None):
        # We specify Vertical orientation using Qt.Orientation.Vertical
        self.qt_widget = QScrollBar(Qt.Orientation.Vertical, parent)
        self.qt_widget.setRange(minimum, maximum)
        self.qt_widget.setValue(value)
        
        if on_value_change:
            self.qt_widget.valueChanged.connect(on_value_change)
            
    def get_value(self):
        return self.qt_widget.value()

__all__ = [
    'Label', 'Button', 'TextBox', 'Dropdown', 'Browser', 
    'Checkbox', 'ProgressBar', 'Slider', 'Scrollbar' 
]