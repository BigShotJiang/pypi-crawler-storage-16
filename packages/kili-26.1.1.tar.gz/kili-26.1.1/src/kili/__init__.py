"""Kili Python SDK."""

__version__ = "26.1.1"
