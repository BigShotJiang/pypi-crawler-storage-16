"""Question domain."""

from typing import NewType

QuestionId = NewType("QuestionId", str)
