"""Tag domain."""

from typing import NewType

TagId = NewType("TagId", str)
