"""Fragments of project version mutations."""

PROJECT_VERSION_FRAGMENT = """
content
id
name
projectId
"""
