"""This module contains the code for parsing label data."""
