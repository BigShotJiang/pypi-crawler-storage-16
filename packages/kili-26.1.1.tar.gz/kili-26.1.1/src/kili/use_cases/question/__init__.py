"""Use cases of question module."""

from .question_use_case import QuestionToCreateUseCaseInput, QuestionUseCases

__all__ = ["QuestionUseCases", "QuestionToCreateUseCaseInput"]
