class LeanError(Exception):
    pass


class ReplError(Exception):
    pass


class NoAvailableReplError(Exception):
    pass
