def is_blank(s: str) -> bool:
    return not s.strip()
