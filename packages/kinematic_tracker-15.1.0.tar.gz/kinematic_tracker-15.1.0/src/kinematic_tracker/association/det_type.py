from typing import Sequence

import numpy as np


MT = np.ndarray[tuple[int, int], np.dtype[float]]
DT = Sequence[np.ndarray[int, float]] | MT
