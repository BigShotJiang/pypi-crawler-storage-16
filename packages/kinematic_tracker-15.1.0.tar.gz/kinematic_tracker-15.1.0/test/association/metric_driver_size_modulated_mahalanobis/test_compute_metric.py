"""."""

import cv2
import numpy as np
import pytest

from kinematic_tracker.association.metric_size_modulated_mahalanobis import (
    MetricSizeModulatedMahalanobis,
)


def test_compute_metric(
    det_rz: list[np.ndarray[int, float]],
    filters: list[cv2.KalmanFilter],
    driver: MetricSizeModulatedMahalanobis,
) -> None:
    metric = driver.compute_metric(det_rz, filters)
    ref = [
        [1.0, 0.9760750935048036, 0.9228298024606032],
        [0.9805168491782723, 1.0, 0.9851645434569364],
    ]
    assert metric == pytest.approx(np.array(ref))
    assert np.shares_memory(metric, driver.metric_rt)
