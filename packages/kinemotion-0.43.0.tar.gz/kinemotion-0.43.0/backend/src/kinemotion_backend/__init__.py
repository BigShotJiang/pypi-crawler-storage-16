"""Kinemotion FastAPI Backend - Web API for video-based kinematic analysis."""

__version__ = "0.1.0"
