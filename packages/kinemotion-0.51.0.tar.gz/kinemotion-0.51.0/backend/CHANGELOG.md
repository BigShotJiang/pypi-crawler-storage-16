# CHANGELOG

<!-- version list -->

## v0.1.1 (2025-12-13)

### Bug Fixes

- **docs**: Enhance api module docstring with examples and analysis types
  ([`94e32f1`](https://github.com/feniix/kinemotion/commit/94e32f1061505747c0345e8683a61bcf8dc60ee3))


## v0.1.0 (2025-12-13)

- Initial Release

## v0.1.0 (2025-12-13)

- Initial Release

## v0.52.0 (2025-12-13)

### Features

- Implement continuous deployment with optional semantic releases
  ([`3596e47`](https://github.com/feniix/kinemotion/commit/3596e47e055dd54dda130bba9d7e78c14c4b2819))

### Refactoring

- Decouple semantic-release configs with directory-specific filtering
  ([`b7d4fef`](https://github.com/feniix/kinemotion/commit/b7d4fefcff2972d2d347dfef69a830b1f2473cfc))

- Separate release job in backend deployment workflow
  ([`521f03f`](https://github.com/feniix/kinemotion/commit/521f03f4d32c6bcf0b048c2fba3d54d74c7c0677))


## v0.51.0 (2025-12-13)

### Bug Fixes

- Correct MetricsData instantiation and metrics_count calculation
  ([`e2ebca1`](https://github.com/feniix/kinemotion/commit/e2ebca1d5614faa86cdb3c4e23ef9fa034cd8d2a))

- Update error handling tests to use status field instead of status_code
  ([`890e54b`](https://github.com/feniix/kinemotion/commit/890e54b6ac7bead9dceb0f34fdaeb4789e3b3dbd))

### Continuous Integration

- Add semantic-release configuration to backend
  ([`f8e447c`](https://github.com/feniix/kinemotion/commit/f8e447c86b03d7ad6cf9e40d67217371f642f254))

- Improve workflow configuration and add backend versioning
  ([`8d86933`](https://github.com/feniix/kinemotion/commit/8d8693398b6aec20c847ae0616488dd3b90c35af))

### Features

- Add comprehensive granular logging for pipeline stage timing
  ([`0489222`](https://github.com/feniix/kinemotion/commit/04892221faf2cb39f355867475242b8baafa34cd))
