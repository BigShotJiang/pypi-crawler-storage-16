#pragma once

// C/C++
#include <string>

namespace kintera {

std::string to_lower_copy(const std::string& str);

}  // namespace kintera
