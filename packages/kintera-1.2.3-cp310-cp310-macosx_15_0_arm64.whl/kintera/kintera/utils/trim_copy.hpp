#pragma once

// C/C++
#include <string>

namespace kintera {

std::string trim_copy(const std::string& str);

}  // namespace kintera
