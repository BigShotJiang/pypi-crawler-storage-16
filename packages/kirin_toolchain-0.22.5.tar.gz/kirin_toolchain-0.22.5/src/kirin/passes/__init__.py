from kirin.passes.abc import Pass as Pass
from kirin.passes.fold import Fold as Fold
from kirin.passes.typeinfer import TypeInfer as TypeInfer

from .default import Default as Default
from .hint_const import HintConst as HintConst
