"""Version information for kittylog."""

__version__ = "3.0.7"
