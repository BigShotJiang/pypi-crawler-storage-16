"""UI and prompt utilities for kittylog."""
