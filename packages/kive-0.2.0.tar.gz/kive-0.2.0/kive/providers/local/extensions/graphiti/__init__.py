"""Graphiti Extensions

Extensions for Graphiti library to support Chinese LLM ecosystem and fix known issues.
"""
