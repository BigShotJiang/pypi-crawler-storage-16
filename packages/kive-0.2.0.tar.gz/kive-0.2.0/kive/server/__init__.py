"""Kive Memory Gateway Server"""
from kive.server.server import Server

__all__ = ["Server"]
