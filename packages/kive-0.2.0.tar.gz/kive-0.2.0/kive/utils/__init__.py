"""
Utility functions module
"""

from .logger import logger

__all__ = ["logger"]
