"""Defines a no-operation function that does nothing."""


def nop(*args, **kwargs) -> None:
    """Do nothing."""
    pass
