pubtools-quay
=============

This directory includes a Python module to communicate with
the https://quay.io service!

The original code base has been copied from the
https://github.com/release-engineering/pubtools-quay repository
with additional modifications provided later.

All files inside of this directory are distributed under their original
GNU Lesser General Public License!
