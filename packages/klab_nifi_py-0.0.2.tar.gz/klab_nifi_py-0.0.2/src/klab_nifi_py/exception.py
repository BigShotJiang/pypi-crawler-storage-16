class KlabNifiException(BaseException):
    '''
    Exceptions that occur in Klab Nifi
    '''