from __future__ import annotations

import contextlib
import math
import random
import time

import rich.status as rich_status
from rich.color import Color
from rich.console import Console, ConsoleOptions, RenderableType, RenderResult
from rich.spinner import Spinner as RichSpinner
from rich.style import Style
from rich.table import Table
from rich.text import Text

from klaude_code import const
from klaude_code.ui.rich.theme import ThemeKey
from klaude_code.ui.terminal.color import get_last_terminal_background_rgb

# Use an existing Rich spinner name; BreathingSpinner overrides its rendering
BREATHING_SPINNER_NAME = "dots"

# Alternating glyphs for the breathing spinner - switches at each "transparent" point
# All glyphs are center-symmetric (point-symmetric)
_BREATHING_SPINNER_GLYPHS_BASE = [
    # Stars
    "✦",
    "✶",
    "✲",
    "⏺",
    "◆",
    "❖",
]

# Shuffle glyphs on module load for variety across sessions
BREATHING_SPINNER_GLYPHS = _BREATHING_SPINNER_GLYPHS_BASE.copy()
random.shuffle(BREATHING_SPINNER_GLYPHS)


_process_start: float | None = None


def _elapsed_since_start() -> float:
    """Return seconds elapsed since first call in this process."""
    global _process_start
    now = time.perf_counter()
    if _process_start is None:
        _process_start = now
    return now - _process_start


def _shimmer_profile(main_text: str) -> list[tuple[str, float]]:
    """Compute per-character shimmer intensity for a horizontal band.

    Returns a list of (character, intensity) where intensity is in [0, 1].
    """

    chars = list(main_text)
    if not chars:
        return []

    padding = const.STATUS_SHIMMER_PADDING
    char_count = len(chars)
    period = char_count + padding * 2

    # Keep a roughly constant shimmer speed (characters per second)
    # regardless of text length by deriving a character velocity from a
    # baseline text length and the configured sweep duration.
    # The baseline is chosen to be close to the default
    # "Thinking … (esc to interrupt)" status line.
    baseline_chars = 30
    base_period = baseline_chars + padding * 2
    sweep_seconds = const.STATUS_SHIMMER_SWEEP_SECONDS
    char_speed = base_period / sweep_seconds if sweep_seconds > 0 else base_period

    elapsed = _elapsed_since_start()
    pos_f = (elapsed * char_speed) % float(period)
    pos = int(pos_f)
    band_half_width = const.STATUS_SHIMMER_BAND_HALF_WIDTH

    profile: list[tuple[str, float]] = []
    for index, ch in enumerate(chars):
        i_pos = index + padding
        dist = abs(i_pos - pos)
        if dist <= band_half_width:
            x = math.pi * (dist / band_half_width)
            intensity = 0.5 * (1.0 + math.cos(x))
        else:
            intensity = 0.0
        profile.append((ch, intensity))
    return profile


def _shimmer_style(console: Console, base_style: Style, intensity: float) -> Style:
    """Compute shimmer style for a single character.

    When intensity is 0, returns the base style. As intensity increases, the
    foreground color is blended towards the terminal background color, similar
    to codex-rs shimmer's use of default_fg/default_bg and blend().
    """

    if intensity <= 0.0:
        return base_style

    alpha = max(0.0, min(1.0, intensity * const.STATUS_SHIMMER_ALPHA_SCALE))

    base_color = base_style.color or Color.default()
    base_triplet = base_color.get_truecolor()
    bg_triplet = Color.default().get_truecolor(foreground=False)

    base_r, base_g, base_b = base_triplet
    bg_r, bg_g, bg_b = bg_triplet

    r = int(bg_r * alpha + base_r * (1.0 - alpha))
    g = int(bg_g * alpha + base_g * (1.0 - alpha))
    b = int(bg_b * alpha + base_b * (1.0 - alpha))

    shimmer_color = Color.from_rgb(r, g, b)
    return base_style + Style(color=shimmer_color)


def _breathing_intensity() -> float:
    """Compute breathing intensity in [0, 1] for the spinner.

    Intensity follows a smooth cosine curve over the configured period, starting
    from 0 (fully blended into background), rising to 1 (full style color),
    then returning to 0, giving a subtle "breathing" effect.
    """

    period = max(const.SPINNER_BREATH_PERIOD_SECONDS, 0.1)
    elapsed = _elapsed_since_start()
    phase = (elapsed % period) / period
    return 0.5 * (1.0 - math.cos(2.0 * math.pi * phase))


def _breathing_glyph() -> str:
    """Get the current glyph for the breathing spinner.

    Alternates between glyphs at each breath cycle (when intensity reaches 0).
    """
    period = max(const.SPINNER_BREATH_PERIOD_SECONDS, 0.1)
    elapsed = _elapsed_since_start()
    cycle = int(elapsed / period)
    return BREATHING_SPINNER_GLYPHS[cycle % len(BREATHING_SPINNER_GLYPHS)]


def _breathing_style(console: Console, base_style: Style, intensity: float) -> Style:
    """Blend a base style's foreground color toward terminal background.

    When intensity is 0, the color matches the background (effectively
    "transparent"); when intensity is 1, the color is the base style color.
    """

    base_color = base_style.color or Color.default()
    base_triplet = base_color.get_truecolor()
    base_r, base_g, base_b = base_triplet

    cached_bg = get_last_terminal_background_rgb()
    if cached_bg is not None:
        bg_r, bg_g, bg_b = cached_bg
    else:
        bg_triplet = Color.default().get_truecolor(foreground=False)
        bg_r, bg_g, bg_b = bg_triplet

    intensity_clamped = max(0.0, min(1.0, intensity))
    r = int(bg_r * (1.0 - intensity_clamped) + base_r * intensity_clamped)
    g = int(bg_g * (1.0 - intensity_clamped) + base_g * intensity_clamped)
    b = int(bg_b * (1.0 - intensity_clamped) + base_b * intensity_clamped)

    breathing_color = Color.from_rgb(r, g, b)
    return base_style + Style(color=breathing_color)


class ShimmerStatusText:
    """Renderable status line with shimmer effect on the main text and hint."""

    def __init__(self, main_text: str | Text, main_style: ThemeKey) -> None:
        self._main_text = main_text if isinstance(main_text, Text) else Text(main_text)
        self._main_style = main_style
        self._hint_text = Text(const.STATUS_HINT_TEXT)
        self._hint_style = ThemeKey.STATUS_HINT

    def __rich_console__(self, console: Console, options: ConsoleOptions) -> RenderResult:
        result = Text()
        main_style = console.get_style(str(self._main_style))
        hint_style = console.get_style(str(self._hint_style))

        combined_text = self._main_text.plain + self._hint_text.plain
        split_index = len(self._main_text.plain)

        for index, (ch, intensity) in enumerate(_shimmer_profile(combined_text)):
            if index < split_index:
                # Get style from main_text, merge with main_style
                char_style = self._main_text.get_style_at_offset(console, index)
                base_style = main_style + char_style
            else:
                base_style = hint_style
            style = _shimmer_style(console, base_style, intensity)
            result.append(ch, style=style)

        yield result


def spinner_name() -> str:
    return BREATHING_SPINNER_NAME


class BreathingSpinner(RichSpinner):
    """Custom spinner that animates color instead of glyphs.

    The spinner always renders a single "⏺" glyph whose foreground color
    smoothly interpolates between the terminal background and the spinner
    style color, producing a breathing effect.
    """

    def __rich_console__(self, console: Console, options: ConsoleOptions) -> RenderResult:  # type: ignore[override]
        if self.name != BREATHING_SPINNER_NAME:
            # Fallback to Rich's default behavior for other spinners.
            yield from super().__rich_console__(console, options)
            return

        yield self._render_breathing(console)

    def _resolve_base_style(self, console: Console) -> Style:
        style = self.style
        if isinstance(style, Style):
            return style
        if style is None:
            return Style()
        style_name = str(style).strip()
        if not style_name:
            return Style()
        return console.get_style(style_name)

    def _render_breathing(self, console: Console) -> RenderableType:
        base_style = self._resolve_base_style(console)
        intensity = _breathing_intensity()
        style = _breathing_style(console, base_style, intensity)

        glyph = _breathing_glyph()
        frame = Text(glyph, style=style)

        if not self.text:
            return frame
        if isinstance(self.text, (str, Text)):
            return Text.assemble(frame, " ", self.text)

        table = Table.grid(padding=1)
        table.add_row(frame, self.text)
        return table


# Monkey-patch Rich's Status module to use the breathing spinner implementation
# for the configured spinner name, while preserving default behavior elsewhere.
# Best-effort patch; if it fails we silently fall back to default spinner.
with contextlib.suppress(Exception):
    rich_status.Spinner = BreathingSpinner  # type: ignore[assignment]
