"""
Operation protocol for the executor system.

This module defines the operation types and submission structure
that the executor uses to handle different types of requests.
"""

from __future__ import annotations

from enum import Enum
from typing import TYPE_CHECKING
from uuid import uuid4

from pydantic import BaseModel, Field

from klaude_code.protocol.model import UserInputPayload

if TYPE_CHECKING:
    from klaude_code.protocol.op_handler import OperationHandler


class OperationType(Enum):
    """Enumeration of supported operation types."""

    USER_INPUT = "user_input"
    INTERRUPT = "interrupt"
    INIT_AGENT = "init_agent"
    END = "end"


class Operation(BaseModel):
    """Base class for all operations that can be submitted to the executor."""

    type: OperationType
    id: str = Field(default_factory=lambda: uuid4().hex)

    async def execute(self, handler: OperationHandler) -> None:
        """Execute this operation using the given handler."""
        raise NotImplementedError("Subclasses must implement execute()")


class UserInputOperation(Operation):
    """Operation for handling user input (text and optional images) that should be processed by an agent."""

    type: OperationType = OperationType.USER_INPUT
    input: UserInputPayload
    session_id: str | None = None

    async def execute(self, handler: OperationHandler) -> None:
        """Execute user input by running it through an agent."""
        await handler.handle_user_input(self)


class InterruptOperation(Operation):
    """Operation for interrupting currently running tasks."""

    type: OperationType = OperationType.INTERRUPT
    target_session_id: str | None = None  # If None, interrupt all sessions

    async def execute(self, handler: OperationHandler) -> None:
        """Execute interrupt by cancelling active tasks."""
        await handler.handle_interrupt(self)


class InitAgentOperation(Operation):
    """Operation for initializing an agent and replaying history if any.

    If session_id is None, a new session is created with an auto-generated ID.
    If session_id is provided, attempts to load existing session or creates new one.
    """

    type: OperationType = OperationType.INIT_AGENT
    session_id: str | None = None

    async def execute(self, handler: OperationHandler) -> None:
        await handler.handle_init_agent(self)


class EndOperation(Operation):
    """Operation for gracefully stopping the executor."""

    type: OperationType = OperationType.END

    async def execute(self, handler: OperationHandler) -> None:
        """Execute end operation - this is a no-op, just signals the executor to stop."""
        pass


class Submission(BaseModel):
    """A submission represents a request sent to the executor for processing."""

    id: str
    operation: Operation
