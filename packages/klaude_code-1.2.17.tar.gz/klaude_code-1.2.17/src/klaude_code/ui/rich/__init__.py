# Rich rendering utilities
