from __future__ import annotations

from setuptools import setup

setup()
