import json
import uuid
import atexit
import threading
import queue
import time
import urllib.request
import urllib.parse
import urllib.error
from typing import Dict, Optional, Any, List
from datetime import datetime, timezone

from .types import (
    Event,
    EventType,
    EventContext,
    LibraryInfo,
    BatchResponse,
    ValidationError,
)

DEFAULT_ENDPOINT = "https://i.klime.com"
DEFAULT_FLUSH_INTERVAL = 2000  # milliseconds
DEFAULT_MAX_BATCH_SIZE = 20
DEFAULT_MAX_QUEUE_SIZE = 1000
DEFAULT_RETRY_MAX_ATTEMPTS = 5
DEFAULT_RETRY_INITIAL_DELAY = 1000  # milliseconds
MAX_BATCH_SIZE = 100
MAX_EVENT_SIZE_BYTES = 200 * 1024  # 200KB
MAX_BATCH_SIZE_BYTES = 10 * 1024 * 1024  # 10MB
SDK_VERSION = "1.0.2"


class KlimeClient:
    def __init__(
        self,
        write_key: str,
        endpoint: Optional[str] = None,
        flush_interval: Optional[int] = None,
        max_batch_size: Optional[int] = None,
        max_queue_size: Optional[int] = None,
        retry_max_attempts: Optional[int] = None,
        retry_initial_delay: Optional[int] = None,
        flush_on_shutdown: Optional[bool] = None,
    ):
        if not write_key:
            raise ValueError("write_key is required")

        self.write_key = write_key
        self.endpoint = endpoint or DEFAULT_ENDPOINT
        self.flush_interval = flush_interval or DEFAULT_FLUSH_INTERVAL
        self.max_batch_size = min(
            max_batch_size or DEFAULT_MAX_BATCH_SIZE, MAX_BATCH_SIZE
        )
        self.max_queue_size = max_queue_size or DEFAULT_MAX_QUEUE_SIZE
        self.retry_max_attempts = retry_max_attempts or DEFAULT_RETRY_MAX_ATTEMPTS
        self.retry_initial_delay = retry_initial_delay or DEFAULT_RETRY_INITIAL_DELAY
        self.flush_on_shutdown = (
            flush_on_shutdown if flush_on_shutdown is not None else True
        )

        self._queue: queue.Queue = queue.Queue()
        self._lock = threading.Lock()
        self._flush_timer: Optional[threading.Timer] = None
        self._is_shutdown = False
        self._flush_in_progress = False

        if self.flush_on_shutdown:
            atexit.register(self.shutdown)

        self._schedule_flush()

    def track(
        self,
        event: str,
        properties: Optional[Dict[str, Any]] = None,
        user_id: Optional[str] = None,
        group_id: Optional[str] = None,
        ip: Optional[str] = None,
    ) -> None:
        if self._is_shutdown:
            return

        event_obj = Event(
            type=EventType.TRACK,
            messageId=self._generate_uuid(),
            event=event,
            timestamp=self._generate_timestamp(),
            properties=properties or {},
            userId=user_id,
            groupId=group_id,
            context=self._get_context(ip),
        )

        self._enqueue(event_obj)

    def identify(
        self,
        user_id: str,
        traits: Optional[Dict[str, Any]] = None,
        ip: Optional[str] = None,
    ) -> None:
        if self._is_shutdown:
            return

        event_obj = Event(
            type=EventType.IDENTIFY,
            messageId=self._generate_uuid(),
            userId=user_id,
            timestamp=self._generate_timestamp(),
            traits=traits or {},
            context=self._get_context(ip),
        )

        self._enqueue(event_obj)

    def group(
        self,
        group_id: str,
        traits: Optional[Dict[str, Any]] = None,
        user_id: Optional[str] = None,
        ip: Optional[str] = None,
    ) -> None:
        if self._is_shutdown:
            return

        event_obj = Event(
            type=EventType.GROUP,
            messageId=self._generate_uuid(),
            groupId=group_id,
            userId=user_id,
            timestamp=self._generate_timestamp(),
            traits=traits or {},
            context=self._get_context(ip),
        )

        self._enqueue(event_obj)

    def flush(self) -> None:
        if self._is_shutdown or self._flush_in_progress:
            return

        with self._lock:
            if self._flush_in_progress:
                return
            self._flush_in_progress = True

        try:
            self._do_flush()
        finally:
            with self._lock:
                self._flush_in_progress = False

    def shutdown(self) -> None:
        if self._is_shutdown:
            return

        self._is_shutdown = True

        if self._flush_timer:
            self._flush_timer.cancel()
            self._flush_timer = None

        # Force flush remaining events (bypass normal flush which checks _is_shutdown)
        self._flush_remaining()

    def _enqueue(self, event: Event) -> None:
        # Check event size
        event_size = self._estimate_event_size(event)
        if event_size > MAX_EVENT_SIZE_BYTES:
            print(
                f"Klime: Event size ({event_size} bytes) exceeds {MAX_EVENT_SIZE_BYTES} bytes limit"
            )
            return

        # Drop oldest if queue is full
        if self._queue.qsize() >= self.max_queue_size:
            try:
                self._queue.get_nowait()
            except queue.Empty:
                pass

        self._queue.put(event)

        # Check if we should flush immediately
        if self._queue.qsize() >= self.max_batch_size:
            self.flush()

    def _do_flush(self) -> None:
        # Cancel scheduled flush
        if self._flush_timer:
            self._flush_timer.cancel()
            self._flush_timer = None

        # Process batches
        self._flush_remaining()

        # Schedule next flush
        if not self._is_shutdown:
            self._schedule_flush()

    def _flush_remaining(self) -> None:
        """Flush all queued events without scheduling (used by shutdown)."""
        while True:
            batch = self._extract_batch()
            if not batch:
                break
            self._send_batch(batch)

    def _extract_batch(self) -> List[Event]:
        batch: List[Event] = []
        batch_size = 0

        while (
            not self._queue.empty()
            and len(batch) < MAX_BATCH_SIZE
            and len(batch) < self.max_batch_size
        ):
            try:
                event = self._queue.get_nowait()
            except queue.Empty:
                break

            event_size = self._estimate_event_size(event)

            # Check if adding this event would exceed batch size limit
            if batch_size + event_size > MAX_BATCH_SIZE_BYTES:
                # Put event back
                self._queue.put(event)
                break

            batch.append(event)
            batch_size += event_size

        return batch

    def _send_batch(self, batch: List[Event]) -> None:
        if not batch:
            return

        request_body = json.dumps({"batch": [event.to_dict() for event in batch]})
        url = f"{self.endpoint}/v1/batch"

        attempt = 0
        delay = self.retry_initial_delay / 1000.0  # Convert to seconds

        while attempt < self.retry_max_attempts:
            try:
                req = urllib.request.Request(
                    url,
                    data=request_body.encode("utf-8"),
                    headers={
                        "Content-Type": "application/json",
                        "Authorization": f"Bearer {self.write_key}",
                    },
                    method="POST",
                )

                with urllib.request.urlopen(req, timeout=10) as response:
                    response_body = response.read().decode("utf-8")
                    data = json.loads(response_body)

                    if response.status == 200:
                        batch_response = BatchResponse(
                            status=data.get("status", "ok"),
                            accepted=data.get("accepted", 0),
                            failed=data.get("failed", 0),
                            errors=[
                                ValidationError(
                                    index=err.get("index", -1),
                                    message=err.get("message", ""),
                                    code=err.get("code", ""),
                                )
                                for err in data.get("errors", [])
                            ]
                            if data.get("errors")
                            else None,
                        )

                        if batch_response.failed > 0 and batch_response.errors:
                            print(
                                f"Klime: Batch partially failed. Accepted: {batch_response.accepted}, Failed: {batch_response.failed}"
                            )
                        return

                    # Handle error responses
                    if response.status == 400 or response.status == 401:
                        print(f"Klime: Permanent error ({response.status}): {data}")
                        return

                    # Transient errors - retry with backoff
                    if response.status == 429 or response.status == 503:
                        retry_after = response.headers.get("Retry-After")
                        if retry_after:
                            try:
                                delay = int(retry_after)
                            except ValueError:
                                pass

                        attempt += 1
                        if attempt < self.retry_max_attempts:
                            time.sleep(delay)
                            delay = min(delay * 2, 16.0)  # Cap at 16s
                            continue

                    # Other errors - retry
                    attempt += 1
                    if attempt < self.retry_max_attempts:
                        time.sleep(delay)
                        delay = min(delay * 2, 16.0)

            except urllib.error.HTTPError as e:
                # Handle HTTP errors
                if e.code == 400 or e.code == 401:
                    print(f"Klime: Permanent error ({e.code}): {e.reason}")
                    return

                attempt += 1
                if attempt < self.retry_max_attempts:
                    if e.code == 429 or e.code == 503:
                        retry_after = e.headers.get("Retry-After")
                        if retry_after:
                            try:
                                delay = int(retry_after)
                            except ValueError:
                                pass
                    time.sleep(delay)
                    delay = min(delay * 2, 16.0)
                else:
                    print(f"Klime: Failed to send batch after retries: {e}")

            except Exception as e:
                # Network errors - retry
                attempt += 1
                if attempt < self.retry_max_attempts:
                    time.sleep(delay)
                    delay = min(delay * 2, 16.0)
                else:
                    print(f"Klime: Failed to send batch after retries: {e}")

    def _schedule_flush(self) -> None:
        if self._is_shutdown or self._flush_timer:
            return

        def flush_wrapper() -> None:
            self.flush()

        self._flush_timer = threading.Timer(
            self.flush_interval / 1000.0, flush_wrapper
        )
        self._flush_timer.daemon = True
        self._flush_timer.start()

    def _generate_uuid(self) -> str:
        return str(uuid.uuid4())

    def _generate_timestamp(self) -> str:
        return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"

    def _get_context(self, ip: Optional[str] = None) -> EventContext:
        context = EventContext(
            library=LibraryInfo(name="python-sdk", version=SDK_VERSION)
        )

        if ip:
            context.ip = ip

        return context

    def _estimate_event_size(self, event: Event) -> int:
        try:
            return len(json.dumps(event.to_dict()))
        except Exception:
            return 500

