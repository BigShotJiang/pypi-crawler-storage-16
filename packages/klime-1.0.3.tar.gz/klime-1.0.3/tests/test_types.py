"""Unit tests for Klime SDK types."""

import json
import re
from klime.types import (
    Event,
    EventType,
    EventContext,
    LibraryInfo,
    BatchResponse,
    ValidationError,
)


class TestEventType:
    def test_track_value(self):
        assert EventType.TRACK == "track"

    def test_identify_value(self):
        assert EventType.IDENTIFY == "identify"

    def test_group_value(self):
        assert EventType.GROUP == "group"


class TestLibraryInfo:
    def test_initialization(self):
        info = LibraryInfo(name="python-sdk", version="1.0.0")
        assert info.name == "python-sdk"
        assert info.version == "1.0.0"


class TestEventContext:
    def test_empty_context(self):
        context = EventContext()
        assert context.library is None
        assert context.ip is None

    def test_with_library(self):
        library = LibraryInfo(name="python-sdk", version="1.0.0")
        context = EventContext(library=library)
        assert context.library is not None
        assert context.library.name == "python-sdk"

    def test_with_ip(self):
        context = EventContext(ip="192.168.1.1")
        assert context.ip == "192.168.1.1"


class TestEvent:
    def test_generates_uuid(self):
        event = Event(
            type=EventType.TRACK,
            messageId="test-uuid",
            timestamp="2025-01-01T00:00:00.000Z",
        )
        assert event.messageId == "test-uuid"

    def test_uuid_format(self):
        """UUID should be in standard format."""
        import uuid
        
        test_uuid = str(uuid.uuid4())
        event = Event(
            type=EventType.TRACK,
            messageId=test_uuid,
            timestamp="2025-01-01T00:00:00.000Z",
        )
        # UUID format: 8-4-4-4-12 hex chars
        assert re.match(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", event.messageId, re.I)

    def test_timestamp_stored(self):
        event = Event(
            type=EventType.TRACK,
            messageId="test",
            timestamp="2025-01-15T10:30:00.123Z",
        )
        assert event.timestamp == "2025-01-15T10:30:00.123Z"

    def test_to_dict_basic(self):
        event = Event(
            type=EventType.TRACK,
            messageId="test-id",
            timestamp="2025-01-01T00:00:00.000Z",
        )
        result = event.to_dict()
        assert result["type"] == "track"
        assert result["messageId"] == "test-id"
        assert result["timestamp"] == "2025-01-01T00:00:00.000Z"

    def test_to_dict_with_event_name(self):
        event = Event(
            type=EventType.TRACK,
            messageId="test-id",
            timestamp="2025-01-01T00:00:00.000Z",
            event="Button Clicked",
        )
        result = event.to_dict()
        assert result["event"] == "Button Clicked"

    def test_to_dict_with_user_id(self):
        event = Event(
            type=EventType.IDENTIFY,
            messageId="test-id",
            timestamp="2025-01-01T00:00:00.000Z",
            userId="user_123",
        )
        result = event.to_dict()
        assert result["userId"] == "user_123"

    def test_to_dict_with_group_id(self):
        event = Event(
            type=EventType.GROUP,
            messageId="test-id",
            timestamp="2025-01-01T00:00:00.000Z",
            groupId="org_456",
        )
        result = event.to_dict()
        assert result["groupId"] == "org_456"

    def test_to_dict_with_properties(self):
        event = Event(
            type=EventType.TRACK,
            messageId="test-id",
            timestamp="2025-01-01T00:00:00.000Z",
            properties={"button": "signup"},
        )
        result = event.to_dict()
        assert result["properties"] == {"button": "signup"}

    def test_to_dict_with_traits(self):
        event = Event(
            type=EventType.IDENTIFY,
            messageId="test-id",
            timestamp="2025-01-01T00:00:00.000Z",
            traits={"email": "test@example.com"},
        )
        result = event.to_dict()
        assert result["traits"] == {"email": "test@example.com"}

    def test_to_dict_with_context(self):
        library = LibraryInfo(name="python-sdk", version="1.0.0")
        context = EventContext(library=library, ip="192.168.1.1")
        event = Event(
            type=EventType.TRACK,
            messageId="test-id",
            timestamp="2025-01-01T00:00:00.000Z",
            context=context,
        )
        result = event.to_dict()
        assert result["context"]["library"]["name"] == "python-sdk"
        assert result["context"]["library"]["version"] == "1.0.0"
        assert result["context"]["ip"] == "192.168.1.1"

    def test_to_dict_omits_none_fields(self):
        event = Event(
            type=EventType.TRACK,
            messageId="test-id",
            timestamp="2025-01-01T00:00:00.000Z",
        )
        result = event.to_dict()
        assert "event" not in result
        assert "userId" not in result
        assert "groupId" not in result
        assert "properties" not in result
        assert "traits" not in result
        assert "context" not in result

    def test_serializable_to_json(self):
        library = LibraryInfo(name="python-sdk", version="1.0.0")
        context = EventContext(library=library)
        event = Event(
            type=EventType.TRACK,
            messageId="test-id",
            timestamp="2025-01-01T00:00:00.000Z",
            event="Test Event",
            userId="user_123",
            properties={"key": "value"},
            context=context,
        )
        # Should not raise
        json_str = json.dumps(event.to_dict())
        parsed = json.loads(json_str)
        assert parsed["type"] == "track"
        assert parsed["event"] == "Test Event"


class TestValidationError:
    def test_initialization(self):
        error = ValidationError(index=0, message="Invalid field", code="INVALID")
        assert error.index == 0
        assert error.message == "Invalid field"
        assert error.code == "INVALID"


class TestBatchResponse:
    def test_initialization(self):
        response = BatchResponse(status="ok", accepted=10, failed=0)
        assert response.status == "ok"
        assert response.accepted == 10
        assert response.failed == 0
        assert response.errors is None

    def test_with_errors(self):
        errors = [ValidationError(index=0, message="Error", code="ERR")]
        response = BatchResponse(status="partial", accepted=9, failed=1, errors=errors)
        assert response.failed == 1
        assert len(response.errors) == 1
        assert response.errors[0].message == "Error"

