"""GitHub templates package for Klondike Spec CLI.

This package contains template files for scaffolding the .github directory
with Copilot instructions, prompts, and workflow templates.
"""
