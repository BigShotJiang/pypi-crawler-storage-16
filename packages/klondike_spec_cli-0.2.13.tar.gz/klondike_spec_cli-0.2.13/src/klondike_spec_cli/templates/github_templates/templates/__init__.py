"""Template files for .github/templates directory."""
