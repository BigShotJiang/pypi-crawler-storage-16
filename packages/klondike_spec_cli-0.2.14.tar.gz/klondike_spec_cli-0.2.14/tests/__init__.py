"""Tests for klondike-spec-cli."""
