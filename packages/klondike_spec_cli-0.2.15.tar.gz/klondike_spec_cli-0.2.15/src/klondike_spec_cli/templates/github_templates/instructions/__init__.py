"""Instructions templates for .github/instructions directory."""
