"""Prompt templates for .github/prompts directory."""
