from cement import Controller, ex

from ..core.auth import device_login, auth_status, logout
from ..core.api import DEFAULT_BASE_URL


class AuthController(Controller):
    class Meta:
        label = 'auth'
        stacked_on = 'base'
        stacked_type = 'nested'
        help = 'Authenticate with the Kodo server'

    @ex(
        help='Login using device authorization flow',
        arguments=[
            (['--base-url'], {
                'help': 'Kodo server base URL',
                'dest': 'base_url',
                'action': 'store'
            }),
            (['--interval'], {
                'help': 'Polling interval in seconds',
                'dest': 'interval',
                'type': float,
                'default': 2.0
            }),
        ],
    )
    def login(self):
        base_url = self.app.pargs.base_url or DEFAULT_BASE_URL
        interval = self.app.pargs.interval
        device_login(base_url=base_url, poll_interval=interval, print_fn=self.app.log.info)

    @ex(help='Show auth status')
    def status(self):
        auth_status(print_fn=self.app.log.info)

    @ex(help='Logout and clear local session')
    def logout(self):
        logout(print_fn=self.app.log.info)
