import json
from typing import Dict, List, Any, Optional

from cement import Controller, ex

from ..core.api import APIClient, load_session
from ..core.fs import write_files_to_dir


def _parse_vars(kvs: List[str]) -> Dict[str, str]:
    result: Dict[str, str] = {}
    for item in kvs or []:
        if "=" not in item:
            continue
        k, v = item.split("=", 1)
        result[k] = v
    return result


class GenerateController(Controller):
    class Meta:
        label = 'generate'
        stacked_on = 'base'
        stacked_type = 'nested'
        help = 'Generate a project from templates'

    @ex(
        help='Generate a project',
        arguments=[
            (['--global-template-id'], {'dest': 'global_template_id', 'type': int}),
            (['--project-template-id'], {'dest': 'project_template_id', 'type': int}),
            (['--project-name'], {'dest': 'project_name'}),
            (['--var'], {
                'dest': 'vars',
                'action': 'append',
                'help': 'Variable KEY=VALUE (repeatable)'
            }),
            (['--vars-file'], {'dest': 'vars_file', 'help': 'Path to JSON file with variables'}),
            (['--stream'], {
                'dest': 'stream',
                'action': 'store_true',
                'help': 'Use SSE streaming'
            }),
            (['--out'], {
                'dest': 'out',
                'required': True,
                'help': 'Output directory for generated files'
            }),
            (['--team-id'], {
                'dest': 'team_id',
                'type': int,
                'help': 'Team ID (overrides current team context)'
            }),
        ],
    )
    def run(self):
        session = load_session()
        if not session:
            raise RuntimeError("Not authenticated. Run: kodo auth login")
        client = APIClient(session_info=session)

        def fetch_templates(t: str) -> List[Dict[str, Any]]:
            params = {"type": t}
            team_id = (
                self.app.pargs.team_id if self.app.pargs.team_id is not None
                else session.team_id
            )
            if team_id is not None:
                params["teamId"] = team_id
            resp = client.get("/api/templates", params=params)
            client.ensure_ok(resp)
            data = resp.json() or {}
            # API returns { templates: [...], pagination: {...} }
            if isinstance(data, dict):
                return data.get("templates", [])
            elif isinstance(data, list):
                return data
            return []

        def fetch_settings(template_id: int, t: str) -> Dict[str, Any]:
            resp = client.get(
                "/api/templates/settings",
                params={"templateId": str(template_id), "templateType": t}
            )
            client.ensure_ok(resp)
            return resp.json() or {}

        def prompt_select(
            templates: List[Dict[str, Any]],
            t: str,
            allow_skip: bool = True
        ) -> Optional[int]:
            if not templates:
                self.app.log.info(f"No {t} templates available.")
                return None
            self.app.log.info(f"Select a {t} template:")
            for idx, tmpl in enumerate(templates, start=1):
                if t == "global":
                    self.app.log.info(
                        f"  {idx}) id={tmpl.get('id')} name={tmpl.get('name')} "
                        f"default={bool(tmpl.get('is_default'))}"
                    )
                else:
                    self.app.log.info(
                        f"  {idx}) id={tmpl.get('id')} name={tmpl.get('name')} "
                        f"lang={tmpl.get('language')} fw={tmpl.get('framework')}"
                    )
            if allow_skip:
                self.app.log.info("  0) none")
            while True:
                raw = input(f"Enter selection for {t} template (number): ").strip()
                if raw == "" and allow_skip:
                    return None
                if allow_skip and raw == "0":
                    return None
                try:
                    choice = int(raw)
                    if 1 <= choice <= len(templates):
                        return int(templates[choice - 1]["id"])
                except Exception:
                    pass
                self.app.log.info("Invalid selection, try again.")

        def _cast_value(vtype: str, raw: str) -> Any:
            if vtype == "number":
                try:
                    return int(raw) if raw.isdigit() else float(raw)
                except Exception:
                    raise RuntimeError(f"Invalid number: {raw}")
            if vtype == "boolean":
                truthy = {"y", "yes", "true", "1"}
                falsy = {"n", "no", "false", "0"}
                val = raw.strip().lower()
                if val in truthy:
                    return True
                if val in falsy:
                    return False
                raise RuntimeError(f"Invalid boolean: {raw}")
            if vtype == "multiselect":
                return [s.strip() for s in raw.split(",") if s.strip()]
            # text/select/email/url/tel/date/time/datetime-local/password/textarea
            return raw

        def prompt_variables(
            var_defs: List[Dict[str, Any]],
            prefilled: Dict[str, Any]
        ) -> Dict[str, Any]:
            result: Dict[str, Any] = dict(prefilled or {})
            for vd in var_defs:
                name = vd.get("name")
                label = vd.get("label") or name
                vtype = vd.get("type", "text")
                required = bool(vd.get("required", False))
                default = vd.get("defaultValue")
                options = vd.get("options") or []
                if name in result and result[name] not in (None, ""):
                    continue
                prompt = f"{label}"
                if options and vtype in ("select", "multiselect"):
                    prompt += f" {options}"
                if default not in (None, [], ""):
                    prompt += f" [{default}]"
                prompt += ": "
                while True:
                    raw = input(prompt).strip()
                    if raw == "":
                        if default not in (None, []):
                            result[name] = default
                            break
                        if not required:
                            result[name] = "" if vtype != "multiselect" else []
                            break
                        self.app.log.info("This field is required.")
                        continue
                    # Basic validation for select/multiselect
                    if options and vtype in ("select", "multiselect"):
                        if vtype == "select":
                            if raw not in options:
                                self.app.log.info(f"Must be one of {options}")
                                continue
                        else:
                            values = [s.strip() for s in raw.split(",") if s.strip()]
                            if any(v not in options for v in values):
                                self.app.log.info(f"Each value must be in {options}")
                                continue
                    try:
                        result[name] = _cast_value(vtype, raw)
                        break
                    except Exception as e:
                        self.app.log.info(str(e))
                        continue
            return result

        variables = _parse_vars(self.app.pargs.vars or [])
        if self.app.pargs.vars_file:
            with open(self.app.pargs.vars_file, "r", encoding="utf-8") as f:
                from_file = json.load(f)
            variables.update(from_file or {})

        global_id = self.app.pargs.global_template_id
        project_id = self.app.pargs.project_template_id

        # If no IDs provided, interactively prompt user to select
        if not global_id and not project_id:
            globals_list = fetch_templates("global")
            projects_list = fetch_templates("project")
            selected_global = prompt_select(globals_list, "global", allow_skip=True)
            selected_project = prompt_select(projects_list, "project", allow_skip=True)
            if not selected_global and not selected_project:
                raise RuntimeError("You must select at least one template (global or project).")
            global_id = selected_global
            project_id = selected_project

        # Fetch variables from template settings and prompt for missing values
        var_defs: List[Dict[str, Any]] = []
        if global_id:
            gs = fetch_settings(global_id, "global")
            var_defs.extend(gs.get("variables") or [])
        if project_id:
            ps = fetch_settings(project_id, "project")
            # allow project to override by name (replace any existing with same name)
            existing_names = {v.get("name") for v in var_defs}
            for v in ps.get("variables") or []:
                if v.get("name") in existing_names:
                    # replace prior def
                    var_defs = [vv for vv in var_defs if vv.get("name") != v.get("name")]
                var_defs.append(v)
        if var_defs:
            variables = prompt_variables(var_defs, variables)

        payload = {
            "globalTemplateId": global_id,
            "projectTemplateId": project_id,
            "projectName": self.app.pargs.project_name,
            "variables": variables,
        }
        # Add teamId if specified or in session
        team_id = (
            self.app.pargs.team_id if self.app.pargs.team_id is not None
            else session.team_id
        )
        if team_id is not None:
            payload["teamId"] = team_id

        if self.app.pargs.stream:
            # Stream SSE events, and capture final complete payload
            resp = client.post("/api/generate/stream", json=payload, stream=True)
            if resp.status_code != 200:
                raise RuntimeError(f"Stream failed: {resp.status_code} {resp.text}")
            files = None
            for raw_line in resp.iter_lines(decode_unicode=True):
                if not raw_line:
                    continue
                line = raw_line.strip()
                if line.startswith("data:"):
                    try:
                        data_str = line[5:].strip()
                        event = json.loads(data_str)
                    except Exception:
                        continue
                    et = event.get("type")
                    msg = event.get("message")
                    if et in ("info", "warning", "error", "success", "docker", "command"):
                        self.app.log.info(f"[{et}] {msg}")
                    if et == "complete":
                        try:
                            final = json.loads(msg) if isinstance(msg, str) else msg
                            files = final.get("files")
                        except Exception:
                            pass
            if not files:
                raise RuntimeError("No final files received from stream.")
            write_files_to_dir(files, self.app.pargs.out)
            self.app.log.info(f"Wrote {len(files)} files to {self.app.pargs.out}")
            return

        resp = client.post("/api/generate", json=payload)
        client.ensure_ok(resp)
        data = resp.json()
        if not data.get("success"):
            raise RuntimeError(f"Generation failed: {data}")
        files = data["files"]
        write_files_to_dir(files, self.app.pargs.out)
        self.app.log.info(f"Wrote {len(files)} files to {self.app.pargs.out}")
