from cement import Controller, ex

from ..core.api import APIClient, load_session, save_session


class TeamsController(Controller):
    class Meta:
        label = 'teams'
        stacked_on = 'base'
        stacked_type = 'nested'
        help = 'Manage team context'

    @ex(help='List all teams you belong to')
    def list(self):
        session = load_session()
        if not session:
            raise RuntimeError("Not authenticated. Run: kodo auth login")
        client = APIClient(session_info=session)
        resp = client.get("/api/teams")
        client.ensure_ok(resp)
        teams = resp.json() or []
        if not teams:
            self.app.log.info("No teams found. You can create teams in the web interface.")
            return

        current_team_id = session.team_id
        self.app.log.info("Teams:")
        self.app.log.info("  0) Personal (no team)")
        for idx, team in enumerate(teams, start=1):
            team_id = team.get("id")
            name = team.get("name")
            role = team.get("role", "member")
            marker = " (current)" if team_id == current_team_id else ""
            self.app.log.info(f"  {idx}) {name} (role: {role}){marker}")

    @ex(
        help='Select team context',
        arguments=[
            (['--team-id'], {'dest': 'team_id', 'type': int, 'help': 'Team ID to select'}),
        ],
    )
    def select(self):
        session = load_session()
        if not session:
            raise RuntimeError("Not authenticated. Run: kodo auth login")
        client = APIClient(session_info=session)

        team_id = self.app.pargs.team_id

        # If no team_id provided, list teams and prompt
        if team_id is None:
            resp = client.get("/api/teams")
            client.ensure_ok(resp)
            teams = resp.json() or []

            self.app.log.info("Select team context:")
            self.app.log.info("  0) Personal (no team)")
            for idx, team in enumerate(teams, start=1):
                name = team.get("name")
                role = team.get("role", "member")
                self.app.log.info(f"  {idx}) {name} (role: {role})")

            while True:
                raw = input("Enter selection (number): ").strip()
                if raw == "":
                    team_id = None
                    break
                if raw == "0":
                    team_id = None
                    break
                try:
                    choice = int(raw)
                    if 1 <= choice <= len(teams):
                        team_id = teams[choice - 1]["id"]
                        break
                except Exception:
                    pass
                self.app.log.info("Invalid selection, try again.")

        # Validate team membership if team_id is provided
        if team_id is not None:
            resp = client.get("/api/teams")
            client.ensure_ok(resp)
            teams = resp.json() or []
            team_ids = [t.get("id") for t in teams]
            if team_id not in team_ids:
                raise RuntimeError(f"Team {team_id} not found or you don't have access to it.")

        # Update session
        session.team_id = team_id
        save_session(session)

        if team_id is None:
            self.app.log.info("Switched to Personal context")
        else:
            # Get team name for display
            resp = client.get("/api/teams")
            client.ensure_ok(resp)
            teams = resp.json() or []
            team = next((t for t in teams if t.get("id") == team_id), None)
            team_name = team.get("name") if team else f"Team {team_id}"
            self.app.log.info(f"Switched to team context: {team_name}")

    @ex(help='Show current team context')
    def current(self):
        session = load_session()
        if not session:
            raise RuntimeError("Not authenticated. Run: kodo auth login")

        if session.team_id is None:
            self.app.log.info("Current context: Personal")
        else:
            client = APIClient(session_info=session)
            resp = client.get("/api/teams")
            client.ensure_ok(resp)
            teams = resp.json() or []
            team = next((t for t in teams if t.get("id") == session.team_id), None)
            if team:
                self.app.log.info(
                    f"Current context: {team.get('name')} (role: {team.get('role', 'member')})"
                )
            else:
                self.app.log.info(f"Current context: Team {session.team_id} (team not found)")
