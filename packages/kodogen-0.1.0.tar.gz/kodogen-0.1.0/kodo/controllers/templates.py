import json
import os
from typing import Any, Dict, List

from cement import Controller, ex

from ..core.api import APIClient, load_session
from ..core.fs import find_template_root, iter_files, save_json, TEMPLATE_CONFIG_FILENAME


class TemplatesController(Controller):
    class Meta:
        label = 'templates'
        stacked_on = 'base'
        stacked_type = 'nested'
        help = 'Manage templates'

    @ex(
        help='List templates',
        arguments=[
            (['--type'], {
                'dest': 'type',
                'choices': ['global', 'project'],
                'required': True
            }),
            (['--team-id'], {
                'dest': 'team_id',
                'type': int,
                'help': 'Team ID (overrides current team context)'
            }),
        ],
    )
    def list(self):
        session = load_session()
        if not session:
            raise RuntimeError("Not authenticated. Run: kodo auth login")
        client = APIClient(session_info=session)
        params = {"type": self.app.pargs.type}
        team_id = (
            self.app.pargs.team_id if self.app.pargs.team_id is not None
            else session.team_id
        )
        if team_id is not None:
            params["teamId"] = team_id
        resp = client.get("/api/templates", params=params)
        client.ensure_ok(resp)
        data = resp.json() or {}
        # API returns { templates: [...], pagination: {...} }
        if isinstance(data, dict):
            items = data.get("templates", [])
        elif isinstance(data, list):
            items = data
        else:
            items = []
        context_str = f" (team {team_id})" if team_id else " (personal)"
        self.app.log.info(f"Templates{context_str}:")
        for t in items:
            if self.app.pargs.type == "global":
                self.app.log.info(
                    f"[global] id={t.get('id')} name={t.get('name')} "
                    f"default={bool(t.get('is_default'))}"
                )
            else:
                self.app.log.info(
                    f"[project] id={t.get('id')} name={t.get('name')} "
                    f"lang={t.get('language')} fw={t.get('framework')}"
                )

    @ex(
        help='Pull a template to local directory',
        arguments=[
            (['--id'], {'dest': 'id', 'required': True}),
            (['--type'], {
                'dest': 'type',
                'choices': ['global', 'project'],
                'required': True
            }),
            (['--dest'], {'dest': 'dest', 'default': None}),
        ],
    )
    def pull(self):
        session = load_session()
        if not session:
            raise RuntimeError("Not authenticated. Run: kodo auth login")
        client = APIClient(session_info=session)
        template_id = str(self.app.pargs.id)
        template_type = self.app.pargs.type
        dest = self.app.pargs.dest or f"./template-{template_id}"
        os.makedirs(dest, exist_ok=True)

        # Fetch tree
        tree_resp = client.get(
            "/api/templates/files",
            params={"templateId": template_id, "templateType": template_type}
        )
        client.ensure_ok(tree_resp)
        tree = tree_resp.json().get("files", [])

        def walk_nodes(nodes: List[Dict[str, Any]]):
            for n in nodes:
                if n.get("type") == "directory":
                    yield from walk_nodes(n.get("children", []))
                elif n.get("type") == "file":
                    yield n.get("path")

        files = list(walk_nodes(tree))
        for rel in files:
            # Get each file content
            content_resp = client.get(
                "/api/templates/files",
                params={
                    "templateId": template_id,
                    "templateType": template_type,
                    "filePath": rel
                },
            )
            if content_resp.status_code == 200:
                content = content_resp.json().get("content", "")
                path = os.path.join(dest, rel)
                os.makedirs(os.path.dirname(path), exist_ok=True)
                with open(path, "w", encoding="utf-8") as f:
                    f.write(content)

        # Fetch settings
        settings_resp = client.get(
            "/api/templates/settings",
            params={"templateId": template_id, "templateType": template_type}
        )
        if settings_resp.status_code == 200:
            settings = settings_resp.json()
            save_json(os.path.join(dest, TEMPLATE_CONFIG_FILENAME), settings)
        self.app.log.info(f"Pulled template {template_id} ({template_type}) into {dest}")

    @ex(
        help='Save local template to server',
        arguments=[
            (['--type'], {
                'dest': 'type',
                'choices': ['global', 'project'],
                'help': 'Template type (overrides config)'
            }),
            (['--name'], {'dest': 'name', 'help': 'Template name (for creating new)'}),
            (['--framework'], {
                'dest': 'framework',
                'help': 'Framework (for creating new project template)'
            }),
            (['--language'], {
                'dest': 'language',
                'help': 'Language (for creating new project template)'
            }),
            (['--template-id'], {'dest': 'template_id', 'help': 'Existing template ID'}),
            (['--dir'], {
                'dest': 'dir',
                'help': 'Directory to save (defaults to nearest template root)'
            }),
            (['--team-id'], {
                'dest': 'team_id',
                'type': int,
                'help': 'Team ID (overrides current team context)'
            }),
        ],
    )
    def save(self):
        session = load_session()
        if not session:
            raise RuntimeError("Not authenticated. Run: kodo auth login")
        client = APIClient(session_info=session)

        root = self.app.pargs.dir or find_template_root()
        if not root:
            raise RuntimeError("No template.config.json found in current or parent directories.")
        config_path = os.path.join(root, TEMPLATE_CONFIG_FILENAME)
        with open(config_path, "r", encoding="utf-8") as f:
            settings = json.load(f)

        metadata = settings.get("_metadata", {}) or {}
        template_type = self.app.pargs.type or metadata.get("templateType") or "project"
        template_id = self.app.pargs.template_id or metadata.get("templateId")

        # Create template if needed
        if not template_id:
            body = {
                "type": template_type,
                "name": (
                    self.app.pargs.name or
                    settings.get("_metadata", {}).get("templateName") or
                    "New Template"
                ),
            }
            if template_type == "project":
                if self.app.pargs.language or settings.get("language"):
                    body["language"] = self.app.pargs.language or settings.get("language")
                if self.app.pargs.framework or settings.get("framework"):
                    body["framework"] = self.app.pargs.framework or settings.get("framework")
            # Add team_id if specified or in session
            team_id = (
                self.app.pargs.team_id if self.app.pargs.team_id is not None
                else session.team_id
            )
            if team_id is not None:
                body["teamId"] = team_id
            resp = client.post("/api/templates", json=body)
            client.ensure_ok(resp)
            created = resp.json()
            template_id = str(created.get("id"))
            context_str = f" (team {team_id})" if team_id else " (personal)"
            self.app.log.info(f"Created {template_type} template id={template_id}{context_str}")

        # Upload files (multipart)
        files_payload = []
        open_files = []
        try:
            for rel, apath in iter_files(root):
                # preserve directory structure in filename field
                f = open(apath, "rb")
                open_files.append(f)
                files_payload.append(("files", (rel, f, "application/octet-stream")))
            data = {
                "templateType": template_type,
                "templateId": str(template_id),
            }
            resp = client.post("/api/templates/upload", files=files_payload, data=data)
            client.ensure_ok(resp)
        finally:
            for f in open_files:
                try:
                    f.close()
                except Exception:
                    pass

        # Ensure templateId is written into settings via API
        get_set = client.get(
            "/api/templates/settings",
            params={"templateId": template_id, "templateType": template_type}
        )
        if get_set.status_code == 200:
            current = get_set.json() or {}
            meta = current.get("_metadata") or {}
            current_tid = meta.get("templateId")
            # Check if we need to update metadata
            if isinstance(template_id, str) and template_id.isdigit():
                need_put = ("templateId" not in meta) or (current_tid != int(template_id))
            else:
                need_put = ("templateId" not in meta) or (current_tid != template_id)
            if need_put:
                upd = dict(current)
                tid_value = (
                    int(template_id) if str(template_id).isdigit() else template_id
                )
                tpl_name = (
                    self.app.pargs.name or
                    settings.get("_metadata", {}).get("templateName") or
                    "Template"
                )
                upd["_metadata"] = {
                    "templateId": tid_value,
                    "templateType": template_type,
                    "templateName": tpl_name,
                }
                put_resp = client.put(
                    "/api/templates/settings",
                    json={
                        "templateId": template_id,
                        "templateType": template_type,
                        "settings": upd
                    }
                )
                if put_resp.status_code not in (200, 201):
                    self.app.log.warning(
                        "Could not update template.config.json metadata via API; "
                        "server may preserve existing metadata."
                    )

        self.app.log.info(f"Saved template {template_id} ({template_type}) from {root}")
