import json
import os
from dataclasses import dataclass
from typing import Optional, Iterable

import requests


DEFAULT_BASE_URL = os.environ.get("KODO_BASE_URL", "http://localhost:3000")
SESSION_DIR = os.path.join(os.path.expanduser("~"), ".kodo")
SESSION_PATH = os.path.join(SESSION_DIR, "session.json")


@dataclass
class SessionInfo:
    base_url: str
    cookie_name: str
    session_token: str
    team_id: Optional[int] = None


def _ensure_session_dir() -> None:
    if not os.path.isdir(SESSION_DIR):
        os.makedirs(SESSION_DIR, exist_ok=True)


def load_session() -> Optional[SessionInfo]:
    try:
        if not os.path.isfile(SESSION_PATH):
            return None
        with open(SESSION_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        return SessionInfo(
            base_url=data.get("base_url", DEFAULT_BASE_URL),
            cookie_name=data["cookie_name"],
            session_token=data["session_token"],
            team_id=data.get("team_id"),
        )
    except Exception:
        return None


def save_session(session: SessionInfo) -> None:
    _ensure_session_dir()
    with open(SESSION_PATH, "w", encoding="utf-8") as f:
        json.dump(
            {
                "base_url": session.base_url,
                "cookie_name": session.cookie_name,
                "session_token": session.session_token,
                "team_id": session.team_id,
            },
            f,
            indent=2,
        )


def clear_session() -> None:
    try:
        if os.path.isfile(SESSION_PATH):
            os.remove(SESSION_PATH)
    except Exception:
        pass


class APIClient:
    def __init__(self, base_url: Optional[str] = None, session_info: Optional[SessionInfo] = None):
        if session_info:
            self.base_url = base_url or session_info.base_url
        else:
            self.base_url = base_url or DEFAULT_BASE_URL
        self._session = requests.Session()
        self._session.headers.update({"User-Agent": "kodo-cli/0.1"})
        self._cookie_name = None
        self._cookie_value = None
        if session_info:
            self.set_cookie(session_info.cookie_name, session_info.session_token)

    def set_cookie(self, cookie_name: str, cookie_value: str) -> None:
        self._cookie_name = cookie_name
        self._cookie_value = cookie_value
        # requests.Session cookies jar
        self._session.cookies.set(cookie_name, cookie_value)

    def _url(self, path: str) -> str:
        if path.startswith("http://") or path.startswith("https://"):
            return path
        return self.base_url.rstrip("/") + "/" + path.lstrip("/")

    def get(self, path: str, **kwargs) -> requests.Response:
        return self._session.get(self._url(path), timeout=kwargs.pop("timeout", 60), **kwargs)

    def post(self, path: str, **kwargs) -> requests.Response:
        return self._session.post(self._url(path), timeout=kwargs.pop("timeout", 60), **kwargs)

    def put(self, path: str, **kwargs) -> requests.Response:
        return self._session.put(self._url(path), timeout=kwargs.pop("timeout", 60), **kwargs)

    def delete(self, path: str, **kwargs) -> requests.Response:
        return self._session.delete(self._url(path), timeout=kwargs.pop("timeout", 60), **kwargs)

    def ensure_ok(self, resp: requests.Response, allowed: Iterable[int] = (200, 201)) -> None:
        if resp.status_code not in allowed:
            try:
                data = resp.json()
            except Exception:
                data = {"error": resp.text}
            raise RuntimeError(f"HTTP {resp.status_code}: {data}")
