import time
from typing import Optional

from .api import APIClient, SessionInfo, save_session, load_session, clear_session, DEFAULT_BASE_URL


def device_login(base_url: Optional[str] = None, poll_interval: float = 2.0, print_fn=print) -> SessionInfo:
    client = APIClient(base_url=base_url or DEFAULT_BASE_URL)
    # Initiate
    resp = client.post("/api/auth/vscode", json={"clientName": "Kodo CLI"})
    if resp.status_code != 200:
        raise RuntimeError(f"Auth init failed: {resp.status_code} {resp.text}")
    data = resp.json()
    code = data["code"]
    auth_url = data["authUrl"]
    expires_in = data.get("expiresIn", 600)

    full_url = client._url(auth_url)
    print_fn(f"To sign in, open this URL in your browser:\n  {full_url}")
    print_fn("Then approve the request. Waiting for approval...")

    start = time.time()
    while True:
        if time.time() - start > expires_in:
            raise TimeoutError("Authorization code expired. Please try again.")
        status_resp = client.get("/api/auth/vscode", params={"code": code})
        if status_resp.status_code == 200:
            status = status_resp.json()
            if status.get("status") == "approved":
                session_token = status["sessionToken"]
                cookie_name = status.get("cookieName", "authjs.session-token")
                info = SessionInfo(
                    base_url=client.base_url,
                    cookie_name=cookie_name,
                    session_token=session_token,
                )
                save_session(info)
                print_fn("Login successful.")
                return info
        elif status_resp.status_code in (404, 410):
            # invalid/expired
            raise RuntimeError(status_resp.json().get("error", "Authorization failed"))
        time.sleep(poll_interval)


def auth_status(print_fn=print) -> bool:
    session = load_session()
    if not session:
        print_fn("Not authenticated.")
        return False
    client = APIClient(session_info=session)
    resp = client.get("/api/auth/session")
    if resp.status_code == 200:
        data = resp.json()
        # API returns session object { user: {...}, expires: ... } or null
        if data and data.get("user"):
            user = data.get("user", {})
            print_fn(
                f"Authenticated as {user.get('email', 'unknown')} "
                f"(userId={user.get('id', 'unknown')})"
            )
            return True
    print_fn("Authentication invalid or expired. Try logging in again.")
    return False


def logout(print_fn=print) -> None:
    clear_session()
    print_fn("Logged out and local session cleared.")
