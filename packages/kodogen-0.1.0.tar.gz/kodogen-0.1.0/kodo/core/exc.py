
class KodoError(Exception):
    """Generic errors."""
    pass
