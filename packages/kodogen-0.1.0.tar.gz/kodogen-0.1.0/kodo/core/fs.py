import json
import os
from typing import Dict, Iterable, Optional, Tuple


TEMPLATE_CONFIG_FILENAME = "template.config.json"


def find_template_root(start_dir: Optional[str] = None) -> Optional[str]:
    """Walk upward from start_dir (or CWD) to find template.config.json."""
    current = os.path.abspath(start_dir or os.getcwd())
    root = os.path.abspath(os.sep)
    while True:
        candidate = os.path.join(current, TEMPLATE_CONFIG_FILENAME)
        if os.path.isfile(candidate):
            return current
        if current == root:
            return None
        current = os.path.dirname(current)


def iter_files(root: str) -> Iterable[Tuple[str, str]]:
    """Yield (relative_path, absolute_path) for all files under root."""
    for dirpath, _, filenames in os.walk(root):
        for fname in filenames:
            abs_path = os.path.join(dirpath, fname)
            rel_path = os.path.relpath(abs_path, root)
            yield rel_path.replace("\\", "/"), abs_path


def _sanitize_rel_path(path: str) -> str:
    rel = path.replace("\\", "/")
    # strip leading slashes to prevent absolute writes
    while rel.startswith("/"):
        rel = rel[1:]
    # normalize and drop parent traversal
    rel = os.path.normpath(rel).replace("\\", "/")
    while rel.startswith("../"):
        rel = rel[3:]
    if rel == ".":
        rel = ""
    return rel


def write_files_to_dir(files: Dict[str, str], out_dir: str) -> None:
    os.makedirs(out_dir, exist_ok=True)
    for rel_path, content in files.items():
        safe_rel = _sanitize_rel_path(rel_path)
        dest_path = os.path.join(out_dir, safe_rel)
        os.makedirs(os.path.dirname(dest_path), exist_ok=True)
        with open(dest_path, "w", encoding="utf-8") as f:
            f.write(content)


def load_json(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_json(path: str, data: dict) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
