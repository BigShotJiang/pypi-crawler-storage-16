from cement import App, TestApp, init_defaults
from cement.core.exc import CaughtSignal
from .core.exc import KodoError
from .controllers.base import Base
from .controllers.auth import AuthController
from .controllers.generate import GenerateController
from .controllers.templates import TemplatesController
from .controllers.teams import TeamsController

# configuration defaults
CONFIG = init_defaults('kodo')
CONFIG['kodo']['foo'] = 'bar'


class Kodo(App):
    """Kodo primary application."""

    class Meta:
        label = 'kodo'

        # configuration defaults
        config_defaults = CONFIG

        # call sys.exit() on close
        exit_on_close = True

        # load additional framework extensions
        extensions = [
            'yaml',
            'colorlog',
            'jinja2',
        ]

        # configuration handler
        config_handler = 'yaml'

        # configuration file suffix
        config_file_suffix = '.yml'

        # set the log handler
        log_handler = 'colorlog'

        # set the output handler
        output_handler = 'jinja2'

        # register handlers
        handlers = [
            Base,
            AuthController,
            TeamsController,
            GenerateController,
            TemplatesController,
        ]


class KodoTest(TestApp, Kodo):
    """A sub-class of Kodo that is better suited for testing."""

    class Meta:
        label = 'kodo'


def main():
    with Kodo() as app:
        try:
            app.run()

        except AssertionError as e:
            print('AssertionError > %s' % e.args[0])
            app.exit_code = 1

            if app.debug is True:
                import traceback
                traceback.print_exc()

        except KodoError as e:
            print('KodoError > %s' % e.args[0])
            app.exit_code = 1

            if app.debug is True:
                import traceback
                traceback.print_exc()

        except CaughtSignal as e:
            # Default Cement signals are SIGINT and SIGTERM, exit 0 (non-error)
            print('\n%s' % e)
            app.exit_code = 0


if __name__ == '__main__':
    main()
