
from setuptools import setup, find_packages

VERSION = "0.1.0"

f = open('README.md', 'r')
LONG_DESCRIPTION = f.read()
f.close()

setup(
    name='kodogen',
    version=VERSION,
    description='Code generation for teams.',
    long_description=LONG_DESCRIPTION,
    long_description_content_type='text/markdown',
    author='Ryan Flynn',
    author_email='ryan@narwh.al',
    url='https://github.com/kodogen/cli',
    license='unlicensed',
    packages=find_packages(exclude=['ez_setup', 'tests*']),
    package_data={'kodo': ['templates/*']},
    include_package_data=True,
    entry_points="""
        [console_scripts]
        kodo = kodo.main:main
    """,
)
