from kodo.main import KodoTest


def test_kodo():
    # test kodo without any subcommands or arguments
    with KodoTest() as app:
        app.run()
        assert app.exit_code == 0


def test_kodo_debug():
    # test that debug mode is functional
    argv = ['--debug']
    with KodoTest(argv=argv) as app:
        app.run()
        assert app.debug is True
