"""Core status views for the Kollabor CLI application."""

import logging
import psutil
from typing import List

from .status_renderer import StatusViewConfig, BlockConfig

logger = logging.getLogger(__name__)


class CoreStatusViews:
    """Provides default core status views for the application."""

    def __init__(self, llm_service=None, config=None):
        """Initialize core status views.

        Args:
            llm_service: LLM service instance for status data.
            config: Configuration manager for toggleable sections.
        """
        self.llm_service = llm_service
        self.config = config

    def register_all_views(self, status_registry) -> None:
        """Register all core status views with the registry.

        Args:
            status_registry: StatusViewRegistry to register views with.
        """
        try:
            # View 0: Overview - Consolidated view with everything (priority 1100 - highest)
            overview_view = StatusViewConfig(
                name="Overview",
                plugin_source="core",
                priority=1100,
                blocks=[
                    BlockConfig(
                        width_fraction=0.33,
                        content_provider=self._get_overview_ai_session_content,
                        title="AI & Session",
                        priority=100,
                    ),
                    BlockConfig(
                        width_fraction=0.33,
                        content_provider=self._get_overview_model_content,
                        title="Model",
                        priority=90,
                    ),
                    BlockConfig(
                        width_fraction=0.34,
                        content_provider=self._get_overview_performance_content,
                        title="Performance",
                        priority=80,
                    ),
                ],
            )
            status_registry.register_status_view("core", overview_view)

            # View 1: Session Stats (priority 1000)
            session_view = StatusViewConfig(
                name="Session Stats",
                plugin_source="core",
                priority=1000,
                blocks=[
                    BlockConfig(
                        width_fraction=0.5,
                        content_provider=self._get_session_stats_content,
                        title="Session Stats",
                        priority=100,
                    ),
                    BlockConfig(
                        width_fraction=0.5,
                        content_provider=self._get_ai_status_content,
                        title="AI Status",
                        priority=90,
                    ),
                ],
            )
            status_registry.register_status_view("core", session_view)

            # View 2: Performance (priority 800)
            performance_view = StatusViewConfig(
                name="Performance",
                plugin_source="core",
                priority=800,
                blocks=[
                    BlockConfig(
                        width_fraction=1.0,
                        content_provider=self._get_performance_content,
                        title="Performance",
                        priority=100,
                    )
                ],
            )
            status_registry.register_status_view("core", performance_view)

            # View 3: Minimal (priority 600)
            minimal_view = StatusViewConfig(
                name="Minimal",
                plugin_source="core",
                priority=600,
                blocks=[
                    BlockConfig(
                        width_fraction=1.0,
                        content_provider=self._get_minimal_content,
                        title="Minimal",
                        priority=100,
                    )
                ],
            )
            status_registry.register_status_view("core", minimal_view)

            # View 4: LLM Details (priority 700)
            llm_view = StatusViewConfig(
                name="LLM Details",
                plugin_source="core",
                priority=700,
                blocks=[
                    BlockConfig(
                        width_fraction=1.0,
                        content_provider=self._get_llm_details_content,
                        title="LLM Configuration",
                        priority=100,
                    )
                ],
            )
            status_registry.register_status_view("core", llm_view)

            logger.info(
                "Registered 5 core status views: "
                "Overview, Session Stats, Performance, LLM Details, Minimal"
            )

        except Exception as e:
            logger.error(f"Failed to register core status views: {e}")

    def _get_overview_ai_session_content(self) -> List[str]:
        """Get AI and Session stats for Overview (left column)."""
        try:
            import os
            from pathlib import Path

            lines = []

            # Get config toggles
            show_ai = self._get_config("terminal.status.overview.show_ai", True)
            show_session = self._get_config("terminal.status.overview.show_session", True)
            show_directory = self._get_config("terminal.status.overview.show_directory", True)

            # Current Directory
            if show_directory:
                cwd = Path.cwd()
                # Show just the directory name, or full path if configured
                show_full_path = self._get_config("terminal.status.overview.show_full_path", False)
                if show_full_path:
                    dir_display = str(cwd)
                else:
                    # Show home as ~ and just the folder name
                    try:
                        home = Path.home()
                        if cwd == home:
                            dir_display = "~"
                        elif cwd.is_relative_to(home):
                            rel_path = cwd.relative_to(home)
                            # Show last 2 parts of path for context
                            parts = rel_path.parts
                            if len(parts) > 2:
                                dir_display = f"~/{'/'.join(parts[-2:])}"
                            else:
                                dir_display = f"~/{rel_path}"
                        else:
                            # Show last 2 parts of absolute path
                            parts = cwd.parts
                            if len(parts) > 2:
                                dir_display = f"{'/'.join(parts[-2:])}"
                            else:
                                dir_display = str(cwd)
                    except Exception:
                        dir_display = cwd.name or str(cwd)

                lines.append(f"Dir: {dir_display}")

            # AI Status
            if show_ai and self.llm_service:
                processing = "* Processing" if self.llm_service.is_processing else "✓ Ready"
                queue_size = 0
                if hasattr(self.llm_service, "processing_queue"):
                    queue_size = self.llm_service.processing_queue.qsize()

                lines.append(f"AI: {processing}")
                if queue_size > 0:
                    lines.append(f"Queue: {queue_size}")

            # Session Stats
            if show_session and self.llm_service and hasattr(self.llm_service, "session_stats"):
                stats = self.llm_service.session_stats
                msgs = stats.get('messages', 0)
                tokens_in = stats.get('input_tokens', 0)
                tokens_out = stats.get('output_tokens', 0)
                total_tokens = tokens_in + tokens_out

                # Format tokens
                if total_tokens < 1000:
                    token_display = f"{total_tokens}"
                elif total_tokens < 1000000:
                    token_display = f"{total_tokens/1000:.1f}K"
                else:
                    token_display = f"{total_tokens/1000000:.1f}M"

                lines.append(f"Messages: {msgs}")
                lines.append(f"Tokens: {token_display}")
                lines.append(f"In/Out: {tokens_in}/{tokens_out}")

            return lines if lines else ["Hidden"]

        except Exception as e:
            logger.error(f"Error getting AI/Session content: {e}")
            return ["Error"]

    def _get_overview_model_content(self) -> List[str]:
        """Get Model info for Overview (middle column)."""
        try:
            lines = []

            show_model = self._get_config("terminal.status.overview.show_model", True)

            if show_model and self.llm_service and hasattr(self.llm_service, "api_service"):
                api_service = self.llm_service.api_service
                model = getattr(api_service, "model", "Unknown")
                temp = getattr(api_service, "temperature", None)
                max_tok = getattr(api_service, "max_tokens", None)
                api_url = getattr(api_service, "api_url", "Unknown")

                # Extract endpoint from URL
                endpoint = "Unknown"
                if api_url != "Unknown":
                    try:
                        from urllib.parse import urlparse
                        parsed = urlparse(api_url)
                        endpoint = parsed.hostname or api_url
                    except Exception:
                        endpoint = api_url

                lines.append(f"Model: {model}")
                if endpoint != "Unknown":
                    lines.append(f"Endpoint: {endpoint}")
                if temp is not None:
                    lines.append(f"Temp: {temp}")
                if max_tok is not None:
                    lines.append(f"Max Tokens: {max_tok}")

            return lines if lines else ["Hidden"]

        except Exception as e:
            logger.error(f"Error getting model content: {e}")
            return ["Error"]

    def _get_overview_performance_content(self) -> List[str]:
        """Get Performance info for Overview (right column)."""
        try:
            # Performance metrics disabled per user request
            return []

        except Exception as e:
            logger.error(f"Error getting performance content: {e}")
            return ["Error"]

    def _get_config(self, key: str, default):
        """Get config value with fallback to default."""
        if self.config and hasattr(self.config, "get"):
            return self.config.get(key, default)
        return default

    def _get_session_stats_content(self) -> List[str]:
        """Get session statistics content."""
        try:
            # Get session stats from LLM service
            if self.llm_service and hasattr(self.llm_service, "session_stats"):
                stats = self.llm_service.session_stats
                return [
                    f"Messages: {stats.get('messages', 0)}",
                    f"Tokens In: {stats.get('input_tokens', 0)}",
                    f"Tokens Out: {stats.get('output_tokens', 0)}",
                ]
            return ["Messages: 0", "Tokens: 0"]
        except Exception:
            return ["Session: N/A"]

    def _get_ai_status_content(self) -> List[str]:
        """Get AI status content."""
        try:
            if self.llm_service:
                processing = (
                    "* Processing" if self.llm_service.is_processing else "✓ Ready"
                )
                if hasattr(self.llm_service, "processing_queue"):
                    queue_size = self.llm_service.processing_queue.qsize()
                else:
                    queue_size = 0

                # Get model and endpoint info from API service
                model = "Unknown"
                endpoint = "Unknown"
                if hasattr(self.llm_service, "api_service"):
                    api_service = self.llm_service.api_service
                    model = getattr(api_service, "model", "Unknown")
                    api_url = getattr(api_service, "api_url", "Unknown")
                    # Extract domain from URL for cleaner display
                    if api_url != "Unknown":
                        try:
                            from urllib.parse import urlparse

                            parsed = urlparse(api_url)
                            endpoint = parsed.hostname or api_url
                        except Exception:
                            endpoint = api_url

                return [
                    f"AI: {processing}",
                    f"Model: {model}",
                    f"Endpoint: {endpoint}",
                    f"Queue: {queue_size}",
                ]
            return ["AI: Unknown"]
        except Exception:
            return ["AI: N/A"]

    def _get_performance_content(self) -> List[str]:
        """Get performance content."""
        try:
            # Performance metrics disabled per user request
            return []
        except Exception:
            return []

    def _get_minimal_content(self) -> List[str]:
        """Get minimal view content."""
        try:
            ai_status = "✓ Ready"
            model = "Unknown"
            if self.llm_service:
                if self.llm_service.is_processing:
                    ai_status = "* Processing"

                # Get model info
                if hasattr(self.llm_service, "api_service"):
                    model = getattr(self.llm_service.api_service, "model", "Unknown")

            messages = 0
            tokens = 0
            if self.llm_service and hasattr(self.llm_service, "session_stats"):
                stats = self.llm_service.session_stats
                messages = stats.get("messages", 0)
                input_tokens = stats.get("input_tokens", 0)
                output_tokens = stats.get("output_tokens", 0)
                tokens = input_tokens + output_tokens

            if tokens < 1000:
                token_display = f"{tokens}"
            else:
                token_display = f"{tokens/1000:.1f}K"

            return [
                f"AI: {ai_status} ({model}) | Messages: {messages} "
                f"| Tokens: {token_display}"
            ]
        except Exception:
            return ["Status: N/A"]

    def _get_llm_details_content(self) -> List[str]:
        """Get detailed LLM configuration content."""
        try:
            if not self.llm_service:
                return ["LLM: Not initialized"]

            ai_status = (
                "* Processing" if self.llm_service.is_processing else "✓ Ready"
            )
            model = "Unknown"
            endpoint = "Unknown"
            temperature = "Unknown"
            max_tokens = "Unknown"

            if hasattr(self.llm_service, "api_service"):
                api_service = self.llm_service.api_service
                model = getattr(api_service, "model", "Unknown")
                temperature = getattr(api_service, "temperature", "Unknown")
                max_tokens = getattr(api_service, "max_tokens", "Unknown")
                api_url = getattr(api_service, "api_url", "Unknown")

                # Extract domain from URL for cleaner display
                if api_url != "Unknown":
                    try:
                        from urllib.parse import urlparse

                        parsed = urlparse(api_url)
                        endpoint = parsed.hostname or api_url
                    except Exception:
                        endpoint = api_url

            return [
                f"Status: {ai_status}",
                f"Model: {model}",
                f"Endpoint: {endpoint}",
                f"Temperature: {temperature}",
                f"Max Tokens: {max_tokens}",
            ]
        except Exception:
            return ["LLM Details: N/A"]
