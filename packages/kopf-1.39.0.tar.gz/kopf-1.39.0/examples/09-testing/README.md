# Kopf example for testing the operator

Kopf provides some basic tools to test the Kopf-based operators.
With these tools, the testing frameworks (pytest in this case)
can run the operator-under-test in the background, while the test
performs the resource manipulation.

To run the tests:

```bash
pytest
```
