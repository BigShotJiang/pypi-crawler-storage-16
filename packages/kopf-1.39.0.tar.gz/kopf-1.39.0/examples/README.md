# Kopf examples

For the examples to work, a sample CRD (Custom Resource Definition) should be created:

```bash
kubectl apply -f crd.yaml
```

Also, some libraries are needed for some operators and handlers:

```bash
pip install --group test -e .
```
