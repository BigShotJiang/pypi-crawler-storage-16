# ⚖️ 대한민국 법령/판례 검색기 (Korean Law MCP)

[![MCP Badge](https://lobehub.com/badge/mcp/seo-jinseok-korean-law-mcp)](https://lobehub.com/mcp/seo-jinseok-korean-law-mcp)


**"법률 정보를 누구나 쉽게."**

이 프로그램은 복잡한 대한민국 법령과 판례를 **채팅하듯이 쉽게 검색하고 찾아볼 수 있게 해주는 도구**입니다. Claude와 같은 AI와 연결하여 사용할 수 있습니다.

---

## 🚀 시작하기 (Quick Start)

가장 쉬운 사용 방법을 안내해 드립니다.

### 방법 1: `uv`를 이용한 자동 설치 (Mac/Linux/Windows 추천)
`uv`가 설치되어 있다면 가장 간편한 방법입니다. Claude 설정 파일에 아래 내용을 추가하세요. (Python 등을 직접 설치할 필요가 없습니다)

*   **설정 파일 경로**:
    *   MacOS: `~/Library/Application Support/Claude/claude_desktop_config.json`
    *   Windows: `%APPDATA%\Claude\claude_desktop_config.json`

```json
{
  "mcpServers": {
    "korean-law": {
      "command": "uvx",
      "args": [
        "korean-law-mcp"
      ],
      "env": {
        "OPEN_LAW_ID": "여기에_아이디를_넣으세요"
      }
    }
  }
}
```

### 방법 2: 윈도우 실행 파일 (설치 불필요)
`uv`나 Python 설정이 어려운 **윈도우(Windows) 사용자**를 위한 방법입니다.

1. [다운로드 페이지(Releases)](https://github.com/seo-jinseok/korean-law-mcp/releases)로 이동합니다.
2. 최신 버전의 **`korean-law-mcp.exe`** 파일을 다운로드합니다.
3. 다운로드한 파일의 경로를 복사해 둡니다. (예: `C:\Users\홍길동\Downloads\korean-law-mcp.exe`)
4. Claude Desktop 설정 파일(`claude_desktop_config.json`)을 열고 아래와 같이 적어주세요.

```json
{
  "mcpServers": {
    "korean-law": {
      "command": "C:\\Users\\홍길동\\Downloads\\korean-law-mcp.exe",
      "env": {
        "OPEN_LAW_ID": "여기에_아이디를_넣으세요"
      }
    }
  }
}
```

---

## 🔑 필수 준비물: API 아이디
이 프로그램을 사용하려면 **국가법령정보센터 아이디**가 꼭 필요합니다.

1. [국가법령정보센터(law.go.kr)](https://www.law.go.kr/)에 접속하여 회원가입을 합니다.
2. [Open API 신청 페이지](https://www.law.go.kr/)에서 '사용 신청'을 합니다. (무료입니다)
3. 발급받은 아이디를 설정 파일의 `"OPEN_LAW_ID"` 부분에 넣어주세요.

---

## ✨ 주요 기능
이 도구로 할 수 있는 것들입니다.

*   **🔍 법령 검색**: "고등교육법 제20조 찾아줘"라고 물어보면 법 조항을 바로 보여줍니다.
*   **⚖️ 판례 찾기**: "학교폭력 관련 대법원 판례 찾아줘"라고 하면 관련 판례를 요약해 줍니다.
*   **📜 행정규칙/자치법규**: 훈령, 예규, 지자체 조례까지 모두 검색 가능합니다.
*   **📖 법령 용어**: "근로자가 뭐야?"라고 물으면 법적 정의를 정확히 알려줍니다.
*   **🤔 법령 해석례**: "이 법을 이렇게 해석해도 되나?" 궁금할 때 법제처의 유권해석 사례를 찾아줍니다.
*   **📎 서식/별표**: 법령에 첨부된 서식이나 표를 목록으로 보여줍니다.
*   **🤖 스마트 검색**: 법령 이름을 정확히 몰라도, "김영란법"처럼 흔히 부르는 이름으로 검색해도 알아서 찾아줍니다.

---

## 👩‍💻 개발자용 (고급)

Python 환경에서 개발하거나 직접 설치하고 싶으신 분들을 위한 안내입니다.

### 설치
```bash
pip install korean-law-mcp
```

### 실행
```bash
# 환경 변수 설정 후 실행
export OPEN_LAW_ID=your_id
korean-law-mcp
```

---

> **문의 및 기여**: 버그 제보나 기능 제안은 [GitHub Issues](https://github.com/seo-jinseok/korean-law-mcp/issues)에 남겨주세요.
