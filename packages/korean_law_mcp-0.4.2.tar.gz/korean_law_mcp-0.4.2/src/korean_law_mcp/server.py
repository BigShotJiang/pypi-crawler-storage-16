from mcp.server.fastmcp import FastMCP

# Initialize FastMCP
mcp = FastMCP("Korean Law MCP")
