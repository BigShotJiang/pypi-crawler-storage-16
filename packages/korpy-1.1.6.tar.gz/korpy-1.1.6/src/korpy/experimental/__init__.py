"""
Experimental features for korpy
WARNING: These features are not stable and may change or be removed in future releases.
"""
from .core import accuracy_per_word

__all__ = ["accuracy_per_word"]