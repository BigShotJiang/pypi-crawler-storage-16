"""
kos_Htools.redis_core - Модуль для работы с Redis
"""

from .redisetup import RedisBase, RedisShortened, RedisDifKey

__all__ = ["RedisBase", "RedisShortened", "RedisDifKey"] 