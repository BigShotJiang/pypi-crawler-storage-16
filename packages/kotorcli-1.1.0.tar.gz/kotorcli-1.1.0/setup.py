"""Setup script for KotorCLI."""
from setuptools import setup

# This file is maintained for backwards compatibility
# The actual configuration is in pyproject.toml
setup()



