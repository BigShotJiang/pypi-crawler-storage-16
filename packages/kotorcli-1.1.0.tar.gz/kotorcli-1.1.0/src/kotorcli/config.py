"""Configuration management for KotorCLI."""
from __future__ import annotations

VERSION = "1.1.0"
APP_NAME = "KotorCLI"
APP_AUTHOR = "PyKotor"



