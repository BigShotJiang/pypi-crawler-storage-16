"""Configuration management for KotorCLI."""
from __future__ import annotations

VERSION = "1.2.0"
APP_NAME = "KotorCLI"
APP_AUTHOR = "PyKotor"
