"""Integrated KotorDiff package for KotorCLI."""
from __future__ import annotations

from kotorcli.config import VERSION

__all__ = ["VERSION"]
__version__ = VERSION

