"""
Package for IO modules - reader, writer, serializer

Note that naming this package 'io' breaks the pycharm debugger
https://youtrack.jetbrains.com/issue/PY-23615

A workaround is to remove the working directory in the run/debug configuration
"""
