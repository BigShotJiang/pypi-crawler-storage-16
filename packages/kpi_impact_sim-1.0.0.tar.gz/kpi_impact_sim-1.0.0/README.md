# kpi-impact-sim

**kpi-impact-sim** es un motor de simulación basado en *Ridge Regression* que permite estimar cuánto debe modificarse cada variable operativa para lograr una mejora específica en un KPI objetivo.

Permite a cualquier empresa:
- Identificar qué variables impactan realmente un KPI.
- Simular escenarios de mejora (+1%, +2 puntos, +5%, etc.).
- Entender límites operativos realistas.
- Ejecutar análisis sin depender de dashboards externos.

Ideal para áreas de:
✔ Retenciones  
✔ Contactabilidad  
✔ Ventas  
✔ Operaciones  
✔ Experiencia del cliente  
✔ Analítica en general  

---

## ✨ Características Principales

- Preprocesamiento automático de columnas (fechas, porcentajes, numéricas).
- Detección automática de unidades (0–1 vs 0–100).
- Entrenamiento RidgeCV estable y robusto.
- Coeficientes desescalados en unidades reales.
- Simulación operativa con validaciones de factibilidad.
- Compatible con cualquier dataset empresarial.
- Perfecto para automatizar decisiones.

---

## 📦 Instalación

```bash
pip install kpi-impact-sim