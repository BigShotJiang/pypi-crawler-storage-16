# src/kpi_impact_sim/cli.py

import argparse
import os
import sys

import pandas as pd

from .pipeline import run_kpi_analysis
from .exceptions import (
    DataValidationError,
    ModelTrainingError,
    SimulationError,
    KPIImpactSimError,
)
from .logging_utils import get_logger

logger = get_logger("cli")


def run_cli() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "CLI para entrenar un modelo Ridge y simular impacto en un KPI "
            "usando kpi-impact-sim."
        )
    )

    parser.add_argument(
        "--data",
        required=True,
        help="Ruta al CSV de entrada (dataset histórico).",
    )
    parser.add_argument(
        "--target",
        required=True,
        help="Nombre del KPI objetivo (columna numérica del CSV).",
    )
    parser.add_argument(
        "--increment",
        type=float,
        required=True,
        help=(
            "Incremento deseado en el KPI:\n"
            "  - Si el KPI está en 0–1: 0.02 ≈ +2 puntos porcentuales\n"
            "  - Si está en 0–100: 2 = +2 puntos\n"
            "  - Si es métrico normal: 5 = +5% relativo"
        ),
    )
    parser.add_argument(
        "--output",
        required=False,
        default="simulacion_resultado.csv",
        help="Ruta para guardar la simulación (CSV).",
    )
    parser.add_argument(
        "--top",
        type=int,
        default=10,
        help="Número de variables a mostrar en la explicación (top-n).",
    )
    parser.add_argument(
        "--profile",
        action="store_true",
        help="Si se pasa, el pipeline devuelve información de perfilado de tiempo.",
    )

    args = parser.parse_args()

    try:
        logger.info("Iniciando CLI kpi-impact-sim.")

        # -------------------------
        # Validar ruta de datos
        # -------------------------
        if not os.path.exists(args.data):
            raise DataValidationError(f"El archivo de datos no existe: {args.data}")

        logger.info("Cargando dataset desde %s ...", args.data)
        df = pd.read_csv(args.data)
        logger.info("Dataset cargado: shape=%s", df.shape)

        # -------------------------
        # Ejecutar pipeline
        # -------------------------
        logger.info(
            "Ejecutando run_kpi_analysis(target=%s, incremento=%s)",
            args.target,
            args.increment,
        )

        res = run_kpi_analysis(
            df=df,
            target=args.target,
            incremento=args.increment,
            top_n=args.top,
            save_prefix=None,
            profile=args.profile,
        )

        sim = res["simulation"]
        exp = res["explain"]

        candidates = sim.get("candidates", None)

        # -------------------------
        # Guardar simulación
        # -------------------------
        if isinstance(candidates, pd.DataFrame) and not candidates.empty:
            candidates.to_csv(args.output, index=False)
            logger.info("Simulación guardada en %s", args.output)
        else:
            logger.info(
                "No se generaron candidatos de simulación factibles; no se escribe CSV."
            )

        # -------------------------
        # Salida por consola
        # -------------------------
        print("✅ Simulación completada.")
        print("📄 Archivo simulación:", args.output)

        print("\n🎯 KPI objetivo")
        print("   Base:", sim.get("base_target"))
        print("   Objetivo:", sim.get("objetivo"))

        print("\n📌 Top recomendaciones:")
        if isinstance(candidates, pd.DataFrame) and not candidates.empty:
            print(candidates.head(10).to_string(index=False))
        else:
            print("   (no hay candidatos factibles con las reglas actuales)")

        print("\n📊 Top variables explicativas:")
        print(exp.head(args.top).to_string(index=False))

    except DataValidationError as e:
        logger.error("Error de datos: %s", e)
        print(f"❌ Error de datos: {e}")
        sys.exit(1)

    except ModelTrainingError as e:
        logger.error("Error de entrenamiento: %s", e)
        print(f"❌ Error en el entrenamiento del modelo: {e}")
        sys.exit(1)

    except SimulationError as e:
        logger.error("Error en la simulación: %s", e)
        print(f"❌ Error en la simulación: {e}")
        sys.exit(1)

    except KPIImpactSimError as e:
        logger.error("Error de librería: %s", e)
        print(f"❌ Error en kpi-impact-sim: {e}")
        sys.exit(1)

    except Exception as e:
        logger.exception("Error inesperado en la CLI.")
        print(f"❌ Error inesperado: {e}")
        sys.exit(1)
