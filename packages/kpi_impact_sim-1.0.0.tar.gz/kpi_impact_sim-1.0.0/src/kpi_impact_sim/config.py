# src/kpi_impact_sim/config.py

from dataclasses import dataclass

@dataclass
class Settings:
    # logging
    LOG_LEVEL: str = "INFO"

    # pipeline
    MIN_ROWS: int = 30
    DEFAULT_TOP_N: int = 5

    # simulation defaults
    BASE_TYPE: str = "mean"

settings = Settings()
