import json
import os
from pathlib import Path

CONFIG_DIR = Path.home() / ".kpi_impact_sim"
CONFIG_DIR.mkdir(exist_ok=True)

def _profile_path(name: str):
    return CONFIG_DIR / f"{name}.json"

def save_profile(name: str, config: dict):
    path = _profile_path(name)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=4, ensure_ascii=False)
    return path

def load_profile(name: str) -> dict:
    path = _profile_path(name)
    if not path.exists():
        raise FileNotFoundError(f"Perfil '{name}' no existe en {path}.")
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def list_profiles():
    return [p.stem for p in CONFIG_DIR.glob("*.json")]

def profile_exists(name: str) -> bool:
    return _profile_path(name).exists()


