# src/kpi_impact_sim/exceptions.py

class KPIImpactSimError(Exception):
    """Error base del paquete."""
    pass


class DataValidationError(KPIImpactSimError):
    """Errores relacionados con columnas faltantes, tipos incorrectos, etc."""
    pass


class ModelTrainingError(KPIImpactSimError):
    """Errores al entrenar Ridge o problemas de convergencia."""
    pass


class TrainingError(ModelTrainingError):
    """
    Alias legacy para compatibilidad con código antiguo que importaba TrainingError.
    No lo uses en código nuevo; usa ModelTrainingError.
    """
    pass


class SimulationError(KPIImpactSimError):
    """Errores en simulación: delta imposible, coef inválido, etc."""
    pass


class ExplainabilityError(KPIImpactSimError):
    """Errores en módulo de explicabilidad."""
    pass
