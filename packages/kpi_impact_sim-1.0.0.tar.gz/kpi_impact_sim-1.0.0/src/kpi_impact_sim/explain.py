import numpy as np
import pandas as pd

from .logging_utils import get_logger

logger = get_logger("explain")


def explain_kpi_model(
    X: pd.DataFrame,
    y: pd.Series,
    coef_series: pd.Series,
    top: int = 10,
) -> pd.DataFrame:
    """
    Construye una tabla de explicabilidad del modelo:

    - coef: coeficiente desescalado (unidades originales de la feature)
    - beta_std: coeficiente estandarizado (impacto relativo)
    - abs_beta: |beta_std|
    - corr_with_target: correlación simple feature–target
    - variance: varianza de la feature
    - importance_score: métrica compuesta para ordenar
    - rank: ranking (1 = más importante)

    Mantiene compatibilidad con los tests existentes.
    """
    logger.info("Construyendo explicabilidad del modelo. X.shape=%s, y.len=%s", X.shape, len(y))

    if not isinstance(coef_series, pd.Series):
        coef_series = pd.Series(coef_series, index=X.columns[: len(coef_series)])

    # Asegurar alineación de índices
    common_cols = [c for c in X.columns if c in coef_series.index]
    if not common_cols:
        raise ValueError("No hay columnas comunes entre X y coef_series para explicar el modelo.")

    Xc = X[common_cols]
    coefs = coef_series[common_cols]

    std_x = Xc.std(ddof=0).replace(0, np.nan)
    std_y = y.std(ddof=0)
    if std_y == 0:
        logger.warning("La desviación estándar del target es 0; beta_std no es interpretable.")
        std_y = np.nan

    beta_std = coefs * (std_x / (std_y + 1e-12))
    abs_beta = beta_std.abs()

    corr_with_target = Xc.corrwith(y)
    variance = Xc.var(ddof=0)

    # Métrica compuesta de importancia
    importance_score = abs_beta * (corr_with_target.abs() + 1e-6)

    df_imp = pd.DataFrame({
        "feature": common_cols,
        "coef": coefs.values,
        "beta_std": beta_std.values,
        "abs_beta": abs_beta.values,
        "corr_with_target": corr_with_target.values,
        "variance": variance.values,
        "importance_score": importance_score.values,
    })

    # Ranking
    df_imp = df_imp.sort_values(by="importance_score", ascending=False).reset_index(drop=True)
    df_imp["rank"] = np.arange(1, len(df_imp) + 1)

    if top is not None and top > 0:
        df_imp = df_imp.head(top).reset_index(drop=True)

    logger.info("Explicación generada con %d features (top=%s).", len(df_imp), top)
    return df_imp

