import pandas as pd
import numpy as np
import json

def generate_feature_report(df: pd.DataFrame, output_path="feature_report.json"):
    report = {}

    for col in df.columns:
        s = pd.to_numeric(df[col], errors="coerce")
        report[col] = {
            "dtype": str(df[col].dtype),
            "missing_pct": float(s.isna().mean()),
            "std": float(s.std()),
            "min": float(s.min()),
            "max": float(s.max()),
            "p1": float(np.nanpercentile(s, 1)),
            "p99": float(np.nanpercentile(s, 99)),
            "unique": int(s.nunique())
        }

    with open(output_path, "w") as f:
        json.dump(report, f, indent=4)

    return report



