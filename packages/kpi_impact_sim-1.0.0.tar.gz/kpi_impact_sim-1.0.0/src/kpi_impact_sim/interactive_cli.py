"""
CLI interactivo (wizard) para kpi-impact-sim.

Se ejecuta con:
    py -m kpi_impact_sim.interactive_cli
o, si tienes definido entry point:
    kpi-impact-sim-interactive
"""

import os
import sys
import traceback
from typing import Optional

import pandas as pd
from kpi_impact_sim.pipeline import run_kpi_analysis
from kpi_impact_sim.logging import get_logger
from kpi_impact_sim.exceptions import KPIImpactSimError, DataValidationError

logger = get_logger("kpi_impact_sim.interactive")

def _print_header():
    print("-" * 70)
    print("🧩 kpi-impact-sim :: Interactive Wizard")
    print("-" * 70)

def _print_section(title):
    print("-" * 70)
    print(title)
    print("-" * 70)

def main():
    _print_header()

    # ------------------------------  
    # 1. File input
    # ------------------------------
    path = input("📂 Ruta al CSV (o ENTER para salir): ").strip()
    if not path:
        print("Cancelado.")
        return

    try:
        df = pd.read_csv(path)
    except Exception as e:
        raise DataValidationError(f"No se pudo leer el CSV: {e}")

    print("\n📊 Columnas detectadas:")
    for i, c in enumerate(df.columns):
        print(f"  [{i}] {c}  (dtype={df[c].dtype})")

    # ------------------------------
    # Target selection
    # ------------------------------
    num_cols = df.select_dtypes(include="number").columns
    print("\n🔍 Columnas numéricas (candidatas a target):")
    for i, c in enumerate(num_cols):
        print(f"  [{i}] {c}")

    idx = int(input("\n👉 Ingresa el índice del target: "))
    if idx < 0 or idx >= len(num_cols):
        raise DataValidationError("Índice inválido.")

    target = num_cols[idx]

    # ------------------------------
    # Incremento
    # ------------------------------
    incremento = float(input("\n👉 Incremento deseado: ").strip())

    # ------------------------------
    # RUN PIPELINE
    # ------------------------------
    print("\n🚀 Ejecutando análisis completo...\n")

    try:
        res = run_kpi_analysis(
            df,
            target=target,
            incremento=incremento,
        )
    except KPIImpactSimError as e:
        logger.error(f"Error en análisis: {e}")
        print(f"❌ Error: {e}")
        return

    # ------------------------------
    # SUMMARY
    # ------------------------------
    _print_section("✅ Resultado del análisis")

    sim = res["simulation"]
    base = sim["base_target"]
    objetivo = sim["objetivo"]

    print(f"Target: {target}")
    print(f"Base histórica: {base:.4f}")
    print(f"Objetivo: {objetivo:.4f}")

    reco = sim["candidates"]
    factibles = reco[reco["feasible"]]

    print("\n📌 Recomendaciones:")
    if factibles.empty:
        print("   (no hay factibles con las reglas actuales)")
    else:
        print(factibles.head(10).to_string(index=False))


if __name__ == "__main__":
    main()
