import logging

def get_logger(name="kpi-impact-sim", level="INFO"):
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger
    
    handler = logging.StreamHandler()
    fmt = "[%(asctime)s] %(levelname)s - %(message)s"
    handler.setFormatter(logging.Formatter(fmt))

    logger.addHandler(handler)
    logger.setLevel(level)
    return logger

