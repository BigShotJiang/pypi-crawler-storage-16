import logging
import os
from datetime import datetime

_LOGGER = None

def get_logger(name="kpi_impact_sim"):
    global _LOGGER
    if _LOGGER is not None:
        return _LOGGER

    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)

    if not logger.handlers:
        fmt = "[%(asctime)s] [%(levelname)s] %(name)s - %(message)s"
        formatter = logging.Formatter(fmt, datefmt="%Y-%m-%d %H:%M:%S")

        # Consola
        ch = logging.StreamHandler()
        ch.setFormatter(formatter)
        logger.addHandler(ch)

        # Archivo
        log_dir = "logs"
        os.makedirs(log_dir, exist_ok=True)
        fname = datetime.now().strftime("kpi_sim_%Y%m%d.log")
        fh_path = os.path.join(log_dir, fname)
        fh = logging.FileHandler(fh_path, encoding="utf-8")
        fh.setFormatter(formatter)
        logger.addHandler(fh)

    _LOGGER = logger
    return logger



