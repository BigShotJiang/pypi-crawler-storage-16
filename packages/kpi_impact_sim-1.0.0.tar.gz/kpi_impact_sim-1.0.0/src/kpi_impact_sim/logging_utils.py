import logging
import os

_DEFAULT_LOG_LEVEL = os.getenv("KPI_IMPACT_SIM_LOG_LEVEL", "INFO").upper()
_LOGGER_NAME_ROOT = "kpi_impact_sim"


def _ensure_root_logger():
    logger = logging.getLogger(_LOGGER_NAME_ROOT)
    if logger.handlers:
        return logger

    level = getattr(logging, _DEFAULT_LOG_LEVEL, logging.INFO)
    logger.setLevel(level)

    handler = logging.StreamHandler()
    formatter = logging.Formatter(
        "[%(asctime)s] [%(levelname)s] %(name)s - %(message)s"
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.propagate = False
    return logger


def get_logger(name: str | None = None) -> logging.Logger:
    """
    Devuelve un logger consistente para toda la librería.
    Si no hay handlers, configura uno de consola.
    """
    root = _ensure_root_logger()
    if not name or name == _LOGGER_NAME_ROOT:
        return root
    return logging.getLogger(f"{_LOGGER_NAME_ROOT}.{name}")


