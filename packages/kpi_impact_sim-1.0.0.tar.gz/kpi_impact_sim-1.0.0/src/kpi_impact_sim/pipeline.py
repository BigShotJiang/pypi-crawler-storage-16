"""
Pipeline unificado para KPI Impact Sim.
Incluye:
- Preprocesamiento
- RidgeCV
- Simulación
- Explicabilidad
- Logging opcional
"""

from __future__ import annotations
import pandas as pd
from typing import Optional, Dict, Any

from .preprocessing import preprocess_dataframe
from .ridge_model import fit_ridge_model
from .simulate import apply_simulation
from .explain import explain_kpi_model
from .utils import tipo_variable

from .logger import get_logger

logger = get_logger(__name__)


def run_kpi_analysis(
    df: pd.DataFrame,
    target: str,
    incremento: float,
    top_n: int = 5,
    save_prefix: Optional[str] = None,
    profile: bool = False,
) -> Dict[str, Any]:
    """
    Ejecuta el pipeline completo:
        1. Preprocesamiento
        2. Ridge Regression
        3. Simulación
        4. Explicabilidad

    Retorna un dict estructurado.
    """

    logger.info(f"Iniciando run_kpi_analysis(target={target}, incremento={incremento})")

    # --------------------------
    # 1. Preprocesamiento
    # --------------------------
    logger.info("Paso 1/4: preprocesamiento.")
    df_proc = preprocess_dataframe(df)
    df_num = df_proc.select_dtypes(include="number")

    if target not in df_num.columns:
        raise ValueError(f"El target '{target}' no existe en el DataFrame procesado.")

    X = df_num.drop(columns=[target])
    y = df_num[target]

    # --------------------------
    # 2. RidgeCV
    # --------------------------
    logger.info(f"Paso 2/4: entrenamiento RidgeCV. X.shape={X.shape}, y.len={len(y)}")
    res_ridge = fit_ridge_model(X, y)
    coefs = res_ridge["coefs"]

    # --------------------------
    # 3. Simulación
    # --------------------------
    logger.info("Paso 3/4: simulación de impacto.")
    sim = apply_simulation(
        coef_series=coefs,
        df_mes=df_num,
        target=target,
        incremento_pts=incremento,
        tipo_variable_func=tipo_variable,
    )

    # --------------------------
    # 4. Explicabilidad
    # --------------------------
    logger.info("Paso 4/4: generación de explicabilidad.")
    exp = explain_kpi_model(
        X=X,
        y=y,
        coef_series=coefs,
        top=top_n
    )

    logger.info("run_kpi_analysis completado correctamente.")

    result = {
        "ridge": res_ridge,
        "simulation": sim,
        "explain": exp,
        "objetivo": sim["objetivo"],
        "base_target": sim["base_target"],
    }

    # Guardado opcional
    if save_prefix:
        sim["candidates"].to_csv(f"{save_prefix}_sim.csv", index=False)
        exp.to_csv(f"{save_prefix}_exp.csv", index=False)

    # Perfil de rendimiento opcional
    if profile:
        import time
        result["profile_timestamp"] = time.time()

    return result
