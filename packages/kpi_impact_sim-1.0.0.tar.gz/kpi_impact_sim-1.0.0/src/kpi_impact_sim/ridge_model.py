import numpy as np
import pandas as pd

from sklearn.linear_model import RidgeCV
from sklearn.model_selection import RepeatedKFold, cross_val_score
from sklearn.preprocessing import StandardScaler

from typing import Iterable, Optional, Dict, Any


# Alphas por defecto para RidgeCV (de 1e-3 a 1e3 en escala log)
DEFAULT_ALPHAS = np.logspace(-3, 3, 25)


def _ensure_dataframe(X) -> pd.DataFrame:
    """
    Convierte X a DataFrame si no lo es, y fuerza tipos numéricos básicos.
    """
    if isinstance(X, pd.DataFrame):
        return X.copy()
    return pd.DataFrame(X)


def _drop_zero_variance(X: pd.DataFrame) -> pd.DataFrame:
    """
    Elimina columnas con varianza cero (constantes), que solo meten ruido numérico.
    """
    std = X.astype(float).std(axis=0)
    zero_var_cols = std[std == 0].index.tolist()
    if zero_var_cols:
        X = X.drop(columns=zero_var_cols)
    return X


def fit_ridge_model(
    X: pd.DataFrame,
    y: pd.Series,
    alphas: Optional[Iterable[float]] = None,
    cv_splits: int = 5,
    n_repeats: int = 3,
    random_state: int = 1,
    scoring: str = "r2",
) -> Dict[str, Any]:
    """
    Entrena un modelo RidgeCV estable y devuelve:

    - model   : instancia entrenada de RidgeCV
    - scaler  : StandardScaler usado para estandarizar X
    - coefs   : pd.Series con coeficientes *desescalados* (en unidades originales de las features)
    - scores  : array de scores de validación cruzada (R² por defecto), o None si algo falla

    Parámetros
    ----------
    X : DataFrame
        Matriz de features numéricas.
    y : Series o array
        Target continuo (KPI a modelar).
    alphas : iterable, opcional
        Valores de alpha para RidgeCV. Si es None, usa DEFAULT_ALPHAS.
    cv_splits : int
        Número de folds para RepeatedKFold.
    n_repeats : int
        Número de repeticiones para RepeatedKFold.
    random_state : int
        Semilla reproducible.
    scoring : str
        Métrica de evaluación (por defecto 'r2').

    Notas
    -----
    - Los coeficientes devueltos en `coefs` están en la escala original de X,
      lo cual es lo que necesita tu motor de simulación.
    """

    # Asegurar tipos
    X = _ensure_dataframe(X)
    y = pd.Series(y).astype(float)

    # Eliminar columnas constantes
    X = _drop_zero_variance(X)
    if X.shape[1] == 0:
        raise ValueError("X debe contener al menos una feature no constante.")

    # Alphas por defecto si no se pasan
    if alphas is None:
        alphas = DEFAULT_ALPHAS

    # CV estable y reproducible
    rkf = RepeatedKFold(
        n_splits=cv_splits,
        n_repeats=n_repeats,
        random_state=random_state,
    )

    # Escalado
    scaler = StandardScaler()
    Xs = scaler.fit_transform(X.astype(float))

    # Entrenamiento RidgeCV
    model = RidgeCV(alphas=alphas, cv=rkf, scoring=scoring)
    model.fit(Xs, y.values)

    # Desescalar coeficientes: coef_estandarizados / sigma_X
    coefs = pd.Series(model.coef_, index=X.columns) / scaler.scale_

    # Scores de CV (adicionales, no los usa el core de tu motor pero sirven para diagnósticos)
    try:
        scores = cross_val_score(
            model,
            Xs,
            y.values,
            cv=rkf,
            scoring=scoring,
            n_jobs=-1,
        )
    except Exception:
        scores = None

    return {
        "model": model,
        "scaler": scaler,
        "coefs": coefs,
        "scores": scores,
    }
