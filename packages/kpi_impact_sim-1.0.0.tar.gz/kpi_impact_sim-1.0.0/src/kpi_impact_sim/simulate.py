"""
Simulación de impacto en un KPI dado un vector de coeficientes.
"""

import pandas as pd
import numpy as np
from typing import Callable, Optional, Tuple


def obtener_base(df: pd.DataFrame, columna: str, tipo: str = "mean"):
    """Base histórica de una columna (mean o max)."""
    if columna not in df.columns:
        return np.nan
    s = pd.to_numeric(df[columna], errors="coerce").dropna()
    if s.empty:
        return np.nan
    return s.max() if tipo == "max" else s.mean()


def detect_unit(series: pd.Series) -> str:
    s = pd.to_numeric(series.dropna(), errors="coerce")
    if s.empty:
        return "other"
    mx = s.max()
    p95 = np.nanpercentile(s, 95)
    if p95 <= 1.1:
        return "proportion"
    if mx > 1.1:
        return "percent"
    return "other"


def _check_bounds(tipo_var: str, nuevo: float, base_k: float, hist_span: Optional[float]) -> Tuple[bool, str]:
    if tipo_var == "porcentaje":
        if (base_k <= 1.1 and (nuevo < 0 or nuevo > 1.0)) or (
            base_k > 1.1 and (nuevo < 0 or nuevo > 100.0)
        ):
            return False, "fuera_de_rango_porcentaje"

    if tipo_var == "tiempo":
        if nuevo < 0:
            return False, "tiempo_negativo"
        if hist_span is not None and nuevo > (hist_span * 3 + base_k):
            return False, "excesivo_sobre_historial"

    if tipo_var == "entero":
        if base_k == 0:
            if abs(nuevo) > 1000:
                return False, "delta_abs_demasiado_grande"
        else:
            if abs((nuevo - base_k) / (base_k + 1e-9)) > 0.5:
                return False, "delta_rel>0.50"

    return True, "ok"


def _standardize_increment(incremento_pts: float, tipo_t: str, base_target: float) -> float:
    """
    Normaliza incremento a la unidad del target.
    """
    if tipo_t == "porcentaje":
        if base_target <= 1.1:
            # target en 0..1
            if incremento_pts > 1:
                return incremento_pts / 100.0
            return incremento_pts
        else:
            # target en 0..100
            if incremento_pts > 1:
                return incremento_pts
            return incremento_pts * 100.0
    else:
        return base_target * (incremento_pts / 100.0)


def apply_simulation(
    coef_series: pd.Series,
    df_mes: pd.DataFrame,
    target: str,
    incremento_pts: float,
    tipo_variable_func: Callable[[str], str],
    obtener_base_func: Optional[Callable[[pd.DataFrame, str], float]] = None,
    base_type: str = "mean",
    save_path: Optional[str] = None,
):
    """
    Devuelve dict con:
    - base_target
    - objetivo
    - candidates: DataFrame con columnas
      ['feature','coef','base','delta_x','nuevo','feasible','reason']
    """
    if obtener_base_func is None:
        obtener_base_func = lambda d, c: obtener_base(d, c, tipo=base_type)

    base_target = obtener_base_func(df_mes, target)
    if pd.isna(base_target):
        raise RuntimeError(f"No se pudo calcular base del target '{target}'")

    tipo_t = tipo_variable_func(target)
    delta_target = _standardize_increment(incremento_pts, tipo_t, base_target)
    objetivo = base_target + delta_target

    rows = []
    for feat, coef in coef_series.items():
        try:
            coef_val = float(coef)
        except Exception:
            continue
        if abs(coef_val) < 1e-12:
            continue

        base_k = obtener_base_func(df_mes, feat)
        if pd.isna(base_k):
            continue

        if abs(coef_val) < 1e-8:
            delta_x = np.nan
            nuevo = np.nan
            feasible = False
            reason = "coef_demasiado_pequeño"
        else:
            delta_x = delta_target / coef_val
            nuevo = base_k + delta_x

            serie_hist = (
                pd.to_numeric(df_mes[feat], errors="coerce").dropna()
                if feat in df_mes.columns
                else pd.Series(dtype=float)
            )
            hist_span = None
            if not serie_hist.empty:
                hist_span = serie_hist.max() - serie_hist.min()

            tipo_var = tipo_variable_func(feat)
            feasible, reason = _check_bounds(tipo_var, nuevo, base_k, hist_span)

        rows.append(
            {
                "feature": feat,
                "coef": coef_val,
                "base": base_k,
                "delta_x": delta_x,
                "nuevo": nuevo,
                "feasible": feasible,
                "reason": reason,
            }
        )

    dfc = pd.DataFrame(rows)
    if dfc.empty:
        result = {"base_target": base_target, "objetivo": objetivo, "candidates": dfc}
        if save_path:
            dfc.to_csv(save_path, index=False)
        return result

    dfc = dfc.sort_values(by="coef", key=lambda s: s.abs(), ascending=False).reset_index(drop=True)

    if save_path:
        try:
            dfc.to_csv(save_path, index=False)
        except Exception:
            pass

    return {"base_target": base_target, "objetivo": objetivo, "candidates": dfc}
