import pandas as pd
import numpy as np

class DataValidationError(Exception):
    pass

def validate_dataset(df: pd.DataFrame, target: str):
    if df.shape[0] < 50:
        raise DataValidationError("El dataset debe tener al menos 50 filas.")

    if target not in df.columns:
        raise DataValidationError(f"El target '{target}' no existe en el dataset.")

    if df[target].std() <= 1e-6:
        raise DataValidationError("El target no tiene variabilidad suficiente.")

    num_cols = df.select_dtypes(include=[np.number]).columns
    if len(num_cols) < 3:
        raise DataValidationError("Se requieren al menos 3 columnas numéricas para entrenar un modelo.")

    empty_cols = [c for c in df.columns if df[c].dropna().empty]
    if empty_cols:
        raise DataValidationError(f"Columnas vacías detectadas: {empty_cols}")

    return True


