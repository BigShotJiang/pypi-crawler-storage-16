import pandas as pd
import numpy as np

from kpi_impact_sim.ridge_model import fit_ridge_model
from kpi_impact_sim.explain import explain_kpi_model


def test_explain_kpi_model_basic():
    # Data de juguete
    rng = np.random.default_rng(0)
    X = pd.DataFrame({
        "x1": rng.normal(0, 1, 100),
        "x2": rng.normal(0, 1, 100),
        "x3": rng.normal(0, 1, 100),
    })
    # y = 2*x1 - 0.5*x2 + ruido
    y = 2 * X["x1"] - 0.5 * X["x2"] + rng.normal(0, 0.5, 100)

    res = fit_ridge_model(X, y)
    coefs = res["coefs"]

    df_imp = explain_kpi_model(X, y, coefs, top=2)

    # Debe devolver algo no vacío
    assert not df_imp.empty
    # Debe contener columnas clave
    for col in ["coef", "beta_std", "abs_beta", "rank"]:
        assert col in df_imp.columns
