import pandas as pd
import numpy as np
from kpi_impact_sim.pipeline import run_kpi_analysis

def test_pipeline_basic():
    rng = np.random.default_rng(1)
    df = pd.DataFrame({
        "x1": rng.normal(0, 1, 120),
        "x2": rng.normal(0, 1, 120),
        "target": rng.uniform(0.3, 0.7, 120)
    })

    res = run_kpi_analysis(df, target="target", incremento=0.02)

    assert "ridge" in res
    assert "simulation" in res
    assert "explain" in res
    assert not res["explain"].empty
    assert "candidates" in res["simulation"]
