from kpi_impact_sim.simulate import apply_simulation
import pandas as pd

def test_apply_simulation_runs():
    df = pd.DataFrame({
        "feature1": [1, 2, 3],
        "target": [0.5, 0.6, 0.55]
    })

    coef = pd.Series({"feature1": 0.1})

    result = apply_simulation(
        coef,
        df,
        target="target",
        incremento_pts=0.01,
        tipo_variable_func=lambda x: "porcentaje"
    )

    assert "candidates" in result
    assert not result["candidates"].empty
