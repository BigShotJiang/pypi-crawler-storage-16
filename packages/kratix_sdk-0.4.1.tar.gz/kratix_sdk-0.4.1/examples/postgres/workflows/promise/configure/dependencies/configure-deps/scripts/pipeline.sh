#!/usr/bin/env sh

cp /resources/* /kratix/output