"""kseal - A Python CLI wrapper for kubeseal with automatic binary management."""

__version__ = "0.1.0"
