"""kseal - A Python CLI wrapper for kubeseal with automatic binary management."""

from importlib.metadata import version

__version__ = version("kseal")
