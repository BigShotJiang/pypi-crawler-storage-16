"""kubectl-marimo: Deploy marimo notebooks to Kubernetes."""

__version__ = "0.2.0"
