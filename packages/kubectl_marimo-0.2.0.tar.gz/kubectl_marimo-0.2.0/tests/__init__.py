"""Tests for kubectl-marimo plugin."""
