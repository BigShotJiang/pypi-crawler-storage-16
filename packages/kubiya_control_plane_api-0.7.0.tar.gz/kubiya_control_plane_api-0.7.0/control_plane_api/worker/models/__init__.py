"""Data models for worker activities"""
