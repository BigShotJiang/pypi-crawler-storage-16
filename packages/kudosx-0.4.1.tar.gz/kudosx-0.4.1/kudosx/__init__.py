"""Kudosx - An AI software team that builds products with industry standard practices."""

__version__ = "0.3.6"
__package_name__ = "KudosX"