# OPS02-BP04: Team members know what they are responsible for

## Description

Mọi người hiểu rõ trách nhiệm của mình.

## Implementation Guidance

- Clear job descriptions and role definitions
- Onboarding includes responsibility overview
- Regular 1:1s to clarify expectations
- Document team responsibilities publicly
- Role clarity reviews in retrospectives

## Risk Level

Medium - Unclear responsibilities cause gaps and overlaps.
