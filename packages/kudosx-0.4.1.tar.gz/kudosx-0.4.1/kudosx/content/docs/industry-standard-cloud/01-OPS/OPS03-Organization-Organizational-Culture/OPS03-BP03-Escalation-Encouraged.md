# OPS03-BP03: Escalation is encouraged

## Description

Khuyến khích escalation khi cần thiết, không có fear of blame.

## Implementation Guidance

- Clear escalation paths documented
- No-blame culture for escalations
- Reward early problem surfacing
- Regular reviews of escalation patterns
- Psychological safety training

## Risk Level

High - Fear of escalation leads to hidden problems.
