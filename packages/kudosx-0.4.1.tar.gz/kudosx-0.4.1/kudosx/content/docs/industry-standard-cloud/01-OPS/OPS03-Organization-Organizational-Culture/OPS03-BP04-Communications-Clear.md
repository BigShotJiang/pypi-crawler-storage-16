# OPS03-BP04: Communications are timely, clear, and actionable

## Description

Giao tiếp rõ ràng và kịp thời.

## Implementation Guidance

- Communication templates for incidents
- Regular status updates during events
- Clear action items in communications
- Multiple communication channels
- Feedback on communication effectiveness

## Risk Level

Medium - Poor communication causes confusion and delays.
