# OPS08-BP02: Define workload metrics

## Description

Định nghĩa metrics cần thu thập.

## Implementation Guidance

- RED metrics for services
- USE metrics for resources
- Custom business metrics
- Metric naming conventions
- Metric documentation

## Risk Level

Medium - Undefined metrics lead to gaps in visibility.
