# OPS09-BP01: Identify key performance indicators

## Description

KPIs cho operations (deployment frequency, lead time).

## Implementation Guidance

- DORA metrics tracking
- Toil measurement
- Incident metrics
- Change success rate
- Team velocity indicators

## Risk Level

Medium - Wrong operations KPIs lead to poor team performance.
