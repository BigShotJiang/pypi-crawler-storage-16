# OPS10-BP04: Define escalation paths

## Description

Escalation paths rõ ràng.

## Implementation Guidance

- Escalation matrix documented
- Contact information current
- Time-based escalation
- Functional escalation paths
- Management escalation

## Risk Level

High - Unclear escalation causes prolonged incidents.
