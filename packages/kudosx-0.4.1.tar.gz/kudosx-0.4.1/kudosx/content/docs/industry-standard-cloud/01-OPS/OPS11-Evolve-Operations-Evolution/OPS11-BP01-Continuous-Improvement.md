# OPS11-BP01: Have a process for continuous improvement

## Description

Process để liên tục cải tiến.

## Implementation Guidance

- Regular retrospectives
- Kaizen approach
- OKRs for improvement
- Improvement backlog
- Metrics-driven decisions

## Risk Level

Medium - Without improvement process, operations stagnate.
