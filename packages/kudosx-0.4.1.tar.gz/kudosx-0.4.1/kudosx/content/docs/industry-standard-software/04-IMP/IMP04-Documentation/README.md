# IMP04 - Documentation

Technical documentation: code comments, README, ADRs.

## Best Practices

| # | Best Practice | Mô tả |
|---|---------------|-------|
| BP01 | [Technical Documentation](IMP04-BP01-Technical-Documentation.md) | Viết technical docs hiệu quả |

## Tham khảo

- Write the Docs Community
- Google Developer Documentation Style Guide
- Diátaxis Documentation Framework
