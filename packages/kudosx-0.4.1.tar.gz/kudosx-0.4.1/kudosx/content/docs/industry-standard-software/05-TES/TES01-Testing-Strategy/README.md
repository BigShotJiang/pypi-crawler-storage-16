# TES01 - Testing Strategy

Chiến lược kiểm thử: test pyramid, coverage goals, test planning.

## Best Practices

| # | Best Practice | Mô tả |
|---|---------------|-------|
| BP01 | [Test Pyramid](TES01-BP01-Test-Pyramid.md) | Chiến lược phân bổ test types |

## Tham khảo

- Martin Fowler - Test Pyramid
- Google Testing Blog
- xUnit Test Patterns
