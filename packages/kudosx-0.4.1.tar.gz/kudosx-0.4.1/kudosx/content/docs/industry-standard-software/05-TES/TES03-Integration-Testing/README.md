# TES03 - Integration Testing

Integration testing: API testing, database testing.

## Best Practices

| # | Best Practice | Mô tả |
|---|---------------|-------|
| BP01 | [API Testing](TES03-BP01-API-Testing.md) | Testing REST APIs |

## Tham khảo

- Supertest Documentation
- Testing Node.js Applications
