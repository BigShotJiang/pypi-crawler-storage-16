# TES04 - E2E Testing

End-to-End testing với Playwright.

## Best Practices

| # | Best Practice | Mô tả |
|---|---------------|-------|
| BP01 | [Playwright Best Practices](TES04-BP01-Playwright-Best-Practices.md) | E2E testing với Playwright |

## Tham khảo

- Playwright Documentation
- Testing Library
- Cypress Best Practices
