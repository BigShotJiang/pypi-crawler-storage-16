def main():
    print("Hello from scripts!")


if __name__ == "__main__":
    main()
