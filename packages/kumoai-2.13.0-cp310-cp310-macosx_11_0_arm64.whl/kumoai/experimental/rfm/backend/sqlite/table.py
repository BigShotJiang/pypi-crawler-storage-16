import re
import warnings
from typing import List, Optional, Sequence

import pandas as pd
from kumoapi.typing import Dtype

from kumoai.experimental.rfm.backend.sqlite import Connection
from kumoai.experimental.rfm.base import SourceColumn, SourceForeignKey, Table
from kumoai.experimental.rfm.infer import infer_dtype


class SQLiteTable(Table):
    r"""A table backed by a :class:`sqlite` database.

    Args:
        connection: The connection to a :class:`sqlite` database.
        name: The name of this table.
        columns: The selected columns of this table.
        primary_key: The name of the primary key of this table, if it exists.
        time_column: The name of the time column of this table, if it exists.
        end_time_column: The name of the end time column of this table, if it
            exists.
    """
    def __init__(
        self,
        connection: Connection,
        name: str,
        columns: Optional[Sequence[str]] = None,
        primary_key: Optional[str] = None,
        time_column: Optional[str] = None,
        end_time_column: Optional[str] = None,
    ) -> None:

        self._connection = connection

        super().__init__(
            name=name,
            columns=columns,
            primary_key=primary_key,
            time_column=time_column,
            end_time_column=end_time_column,
        )

    def _get_source_columns(self) -> List[SourceColumn]:
        source_columns: List[SourceColumn] = []
        with self._connection.cursor() as cursor:
            cursor.execute(f"PRAGMA table_info({self.name})")
            rows = cursor.fetchall()

            if len(rows) == 0:
                raise ValueError(f"Table '{self.name}' does not exist")

            for _, column, type, _, _, is_pkey in rows:
                # Determine column affinity:
                type = type.strip().upper()
                if re.search('INT', type):
                    dtype = Dtype.int
                elif re.search('TEXT|CHAR|CLOB', type):
                    dtype = Dtype.string
                elif re.search('REAL|FLOA|DOUB', type):
                    dtype = Dtype.float
                else:  # NUMERIC affinity.
                    ser = self._sample_df[column]
                    try:
                        dtype = infer_dtype(ser)
                    except Exception:
                        warnings.warn(
                            f"Data type inference for column '{column}' in "
                            f"table '{self.name}' failed. Consider changing "
                            f"the data type of the column to use it within "
                            f"this table.")
                        continue

                source_column = SourceColumn(
                    name=column,
                    dtype=dtype,
                    is_primary_key=bool(is_pkey),
                    is_unique_key=False,
                )
                source_columns.append(source_column)

        return source_columns

    def _get_source_foreign_keys(self) -> List[SourceForeignKey]:
        source_fkeys: List[SourceForeignKey] = []
        with self._connection.cursor() as cursor:
            cursor.execute(f"PRAGMA foreign_key_list({self.name})")
            for _, _, dst_table, fkey, pkey, _, _, _ in cursor.fetchall():
                source_fkeys.append(SourceForeignKey(fkey, dst_table, pkey))
        return source_fkeys

    def _get_sample_df(self) -> pd.DataFrame:
        with self._connection.cursor() as cursor:
            cursor.execute(f"SELECT * FROM {self.name} "
                           f"ORDER BY rowid LIMIT 1000")
            table = cursor.fetch_arrow_table()
            return table.to_pandas(types_mapper=pd.ArrowDtype)

    def _get_num_rows(self) -> Optional[int]:
        return None
