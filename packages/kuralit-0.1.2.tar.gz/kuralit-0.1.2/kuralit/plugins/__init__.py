"""Plugin system for Kuralit."""

__all__ = []

