"""Agent integration handler for WebSocket server."""

import asyncio
import json
import logging
import os
import time
from pathlib import Path
from typing import Any, AsyncIterator, Dict, List, Optional

logger = logging.getLogger(__name__)

from kuralit.agent import Agent
from kuralit.plugins.llm.gemini import Gemini
from kuralit.models.message import Message
from kuralit.models.response import ModelResponse
from kuralit.tools.api import RESTAPIToolkit

from kuralit.server.agent_session import AgentSession
from kuralit.server.config import ServerConfig
from kuralit.server.event_bus import EventBus
from kuralit.server.exceptions import AgentError
from kuralit.server.metrics import MetricsCollector
from kuralit.telemetry.events import AgentEvent, ToolEvent, ErrorEvent
from kuralit.telemetry.collector import TelemetryCollector
from kuralit.server.protocol import (
    ServerPartialMessage,
    ServerSTTMessage,
    ServerTextMessage,
    ServerToolCallMessage,
    ServerToolResultMessage,
)
from kuralit.server.session import Session


class AgentHandler:
    """Handles agent processing for WebSocket server."""
    
    def __init__(
        self,
        agent_session: Optional[AgentSession] = None,
        config: Optional[ServerConfig] = None,
        metrics: Optional[MetricsCollector] = None,
        event_bus: Optional[EventBus] = None,
        telemetry: Optional[TelemetryCollector] = None,
    ):
        """Initialize agent handler.
        
        Args:
            agent_session: Optional AgentSession configuration (takes precedence)
            config: Optional server configuration (fallback if agent_session not provided)
            metrics: Optional metrics collector
            event_bus: Optional event bus for broadcasting events
            telemetry: Optional telemetry collector
        """
        # Store event bus and telemetry
        self.event_bus = event_bus
        self.telemetry = telemetry
        
        # Use AgentSession if provided, otherwise use config
        if agent_session:
            self.config = agent_session._config.server if agent_session._config else (config or ServerConfig())
            self.metrics = metrics
            
            # Extract from AgentSession
            self.model = agent_session.llm
            self.tools = agent_session.tools or []
            self.instructions = agent_session.instructions
            self.name = agent_session.name
            
            # Log instructions status
            if self.instructions:
                logger.info(f"AgentHandler: Instructions loaded from AgentSession (length: {len(self.instructions)} chars)")
                logger.debug(f"AgentHandler: Instructions preview: {self.instructions[:150]}...")
            else:
                logger.warning("AgentHandler: No instructions provided in AgentSession")
        elif config:
            # Fallback to old config-based approach
            self.config = config
            self.metrics = metrics
            
            # Create Gemini model (old way)
            self.model = Gemini(
                id=config.agent_model_id,
                api_key=config.agent_api_key,
                include_thoughts=True,
            )
            
            # Load REST API tools if Postman collection is provided
            tools = []
            if config.postman_collection_path:
                try:
                    # Resolve collection path
                    collection_path = Path(config.postman_collection_path)
                    if not collection_path.is_absolute():
                        # Try relative to project root
                        project_root = Path(__file__).parent.parent.parent.parent
                        resolved_path = project_root / collection_path
                        if not resolved_path.exists():
                            # Try relative to current working directory
                            resolved_path = Path.cwd() / collection_path
                        if resolved_path.exists():
                            collection_path = resolved_path.resolve()
                        else:
                            raise FileNotFoundError(
                                f"Postman collection not found: {config.postman_collection_path}. "
                                f"Tried: {project_root / config.postman_collection_path}, "
                                f"{Path.cwd() / config.postman_collection_path}"
                            )
                    else:
                        if not collection_path.exists():
                            raise FileNotFoundError(f"Postman collection not found: {collection_path}")
                        collection_path = collection_path.resolve()
                    
                    # Create REST API toolkit from Postman collection
                    api_toolkit = RESTAPIToolkit.from_postman_collection(
                        collection_path=str(collection_path),
                        base_url=config.api_base_url,
                        # api_key can be added if needed
                        # headers=config.api_headers,
                    )
                    tools.append(api_toolkit)
                    
                    # Log available tools
                    if config.debug:
                        print(f"✅ Loaded REST API tools from: {collection_path}")
                        if hasattr(api_toolkit, 'get_functions'):
                            functions = api_toolkit.get_functions()
                            print(f"   Available API tools: {len(functions)}")
                            if len(functions) <= 10:
                                print(f"   Tools: {', '.join(f.name for f in functions)}")
                            else:
                                print(f"   Tools: {', '.join(f.name for f in functions[:10])}... and {len(functions) - 10} more")
                except Exception as e:
                    import warnings
                    warnings.warn(
                        f"Failed to load REST API tools from Postman collection: {e}. "
                        f"Continuing without API tools."
                    )
        
            # Create agent with tools (old way)
            instructions = "You are a helpful assistant with access to realtime communication. "
            if tools:
                instructions += "You also have access to REST API endpoints. Use the available API tools to help users interact with APIs when needed. "
            instructions += "Provide clear, concise, and helpful responses."
            
            self.tools = tools
            self.instructions = instructions
            self.name = "WebSocket Agent"
        else:
            # No config or agent_session - create minimal defaults
            self.config = ServerConfig()
            self.metrics = metrics
            raise ValueError("Either agent_session or config must be provided")
        
        # Create agent with instructions
        # Log tool registration for debugging
        if self.tools:
            logger.info(f"AgentHandler: Registering {len(self.tools)} toolkit(s) with agent")
            for i, tool in enumerate(self.tools):
                if hasattr(tool, 'get_functions'):
                    functions = tool.get_functions()
                    logger.info(f"  Toolkit {i+1}: {len(functions)} functions - {', '.join(f.name for f in functions[:5])}{'...' if len(functions) > 5 else ''}")
        else:
            logger.info("AgentHandler: No tools provided to agent")
        
        self.agent = Agent(
            model=self.model,
            name=self.name,
            instructions=self.instructions,
            tools=self.tools if self.tools else None,
            debug_mode=self.config.debug,
        )
        
        # Log registered functions
        if self.agent.functions:
            logger.info(f"AgentHandler: Agent has {len(self.agent.functions)} registered functions: {', '.join(list(self.agent.functions.keys())[:5])}{'...' if len(self.agent.functions) > 5 else ''}")
        else:
            logger.warning("AgentHandler: Agent has NO registered functions despite tools being provided")
        
        # Collect agent initialization telemetry (NON-BLOCKING)
        if self.telemetry and self.telemetry.config.enable_usage_telemetry:
            try:
                # Get model ID if available
                model_id = None
                if hasattr(self.model, 'model_id'):
                    model_id = self.model.model_id
                elif hasattr(self.model, 'id'):
                    model_id = self.model.id
                
                self.telemetry.collect(AgentEvent(
                    event_type="agent_initialized",
                    session_id=None,  # Not session-specific
                    timestamp=time.time(),
                    data={
                        "agent_name": self.name,
                        "has_stt": agent_session.stt is not None if agent_session else False,
                        "stt_provider": type(agent_session.stt).__name__ if (agent_session and agent_session.stt) else None,
                        "has_llm": self.model is not None,
                        "llm_provider": type(self.model).__name__ if self.model else None,
                        "llm_model_id": model_id,
                        "has_vad": agent_session.vad is not None if agent_session else False,
                        "vad_provider": type(agent_session.vad).__name__ if (agent_session and agent_session.vad) else None,
                        "has_turn_detection": agent_session.turn_detection is not None if agent_session else False,
                        "turn_detection_provider": type(agent_session.turn_detection).__name__ if (agent_session and agent_session.turn_detection) else None,
                        "tool_count": len(self.agent.functions) if self.agent.functions else 0,
                        "has_instructions": bool(self.instructions),
                        "instructions_length": len(self.instructions) if self.instructions else 0,
                    },
                    metadata={
                        "tool_names": list(self.agent.functions.keys())[:20] if self.agent.functions else [],  # First 20 tool names
                    }
                ))
            except Exception:
                pass  # Never fail on telemetry
    
    def _format_messages_for_logging(self, messages: List[Message]) -> str:
        """Format messages for logging output.
        
        Args:
            messages: List of Message objects
            
        Returns:
            Formatted string representation of the conversation history
        """
        import json
        formatted = []
        for i, msg in enumerate(messages):
            role = msg.role
            content = msg.content
            
            # Truncate very long content for readability
            if content and isinstance(content, str) and len(content) > 500:
                content_preview = content[:500] + f"... (truncated, total length: {len(content)} chars)"
            elif content and not isinstance(content, str):
                # If content is not a string (e.g., dict), convert to JSON
                try:
                    content_preview = json.dumps(content, indent=2, ensure_ascii=False)
                    if len(content_preview) > 500:
                        content_preview = content_preview[:500] + f"... (truncated, total length: {len(content_preview)} chars)"
                except (TypeError, ValueError):
                    content_preview = str(content)[:500]
            else:
                content_preview = content if content else "(empty)"
            
            # Handle tool calls
            tool_info = ""
            if hasattr(msg, 'tool_calls') and msg.tool_calls:
                tool_names = [tc.get('function', {}).get('name', 'unknown') for tc in msg.tool_calls if isinstance(tc, dict)]
                tool_info = f" [tool_calls: {len(msg.tool_calls)} - {', '.join(tool_names[:3])}{'...' if len(tool_names) > 3 else ''}]"
            elif hasattr(msg, 'function_call') and msg.function_call:
                func_name = msg.function_call.get('name', 'unknown') if isinstance(msg.function_call, dict) else 'unknown'
                tool_info = f" [function_call: {func_name}]"
            
            # Handle tool role messages (they have function content)
            if role == "tool" or role == "function":
                if isinstance(content, dict):
                    func_name = content.get('name', 'unknown')
                    func_result = content.get('result', content.get('content', 'N/A'))
                    if isinstance(func_result, str) and len(func_result) > 200:
                        func_result = func_result[:200] + "... (truncated)"
                    content_preview = f"Function: {func_name}, Result: {func_result}"
            
            formatted.append(f"  [{i}] {role.upper()}: {content_preview}{tool_info}")
        
        return "\n".join(formatted)
    
    def _prepare_messages_with_instructions(self, messages: List[Message]) -> List[Message]:
        """Prepare messages with system instructions if provided.
        
        Args:
            messages: List of conversation messages
            
        Returns:
            List of messages with system instructions prepended if available
        """
        # Check if messages already have a system message
        has_system_message = any(msg.role == "system" for msg in messages)
        
        # Check if there are tool results in the messages
        has_tool_results = any(msg.role == "tool" for msg in messages)
        
        # Add system instructions if provided and not already present
        if self.instructions and not has_system_message:
            instructions = self.instructions
            
            # If tool results are present, add an extra reminder to convert them to natural language
            if has_tool_results:
                reminder = (
                    "\n\nCRITICAL REMINDER: You have just received tool/API results in JSON format. "
                    "You MUST convert these results into natural, conversational English. "
                    "NEVER output:"
                    "\n- Raw JSON strings"
                    "\n- Code blocks with JSON"
                    "\n- Technical data structures"
                    "\n- The word 'tool_outputs' or similar"
                    "\n- Any format like ```json or ```tool_outputs"
                    "\n\nInstead, extract the meaningful information and explain it naturally. "
                    "For example, if the tool returned cart data, say 'Your cart contains...' not 'The tool returned: {...}'"
                )
                instructions = instructions + reminder
                logger.debug("AgentHandler: Added tool result conversion reminder to instructions")
            
            system_message = Message(role="system", content=instructions)
            logger.info(f"AgentHandler: Adding system instructions to messages (length: {len(instructions)} chars)")
            logger.debug(f"AgentHandler: System instructions preview: {instructions[:100]}...")
            return [system_message] + messages
        elif has_system_message:
            logger.debug("AgentHandler: System message already present in conversation history")
        elif not self.instructions:
            logger.debug("AgentHandler: No instructions provided, using default behavior")
        return messages
    
    async def process_text_async(
        self,
        session: Session,
        text: str,
        metadata: Optional[Dict] = None,
    ) -> AsyncIterator[ServerPartialMessage | ServerTextMessage | ServerToolCallMessage | ServerToolResultMessage]:
        """Process text input and stream response.
        
        Args:
            session: Session object
            text: Input text
            metadata: Optional metadata
            
        Yields:
            ServerPartialMessage, ServerTextMessage, ServerToolCallMessage, 
            or ServerToolResultMessage
        """
        start_time = time.time()
        
        try:
            # Log entry into process_text_async
            logger.info("AgentHandler: ========== process_text_async CALLED ==========")
            logger.info(f"AgentHandler: Processing user message: '{text[:100]}{'...' if len(text) > 100 else ''}'")
            logger.info(f"AgentHandler: Session ID: {session.session_id}")
            
            # Log metadata if provided (e.g., is_final flag for STT transcripts)
            if metadata:
                is_final = metadata.get("is_final", False)
                source = metadata.get("source", "unknown")
                logger.info(f"AgentHandler: Message metadata - source={source}, is_final={is_final}")
            
            logger.info(f"AgentHandler: Agent object exists: {self.agent is not None}")
            if self.agent:
                logger.info(f"AgentHandler: Agent type: {type(self.agent)}")
                logger.info(f"AgentHandler: Agent has 'functions' attribute: {hasattr(self.agent, 'functions')}")
            
            # Add user message to conversation
            # Note: For audio transcripts, this is always the final accumulated text (is_final=True)
            user_message = Message(role="user", content=text)
            session.add_message(user_message)
            
            # Get conversation history
            messages = session.get_conversation_history()
            logger.info(f"AgentHandler: Conversation history length: {len(messages)} messages")
            
            # Use agent.run() which handles tool calls automatically
            # But we need to stream the response, so we'll use the model directly
            # and handle tool calls if needed
            
            # Check if agent has tools (REST API tools)
            logger.info("AgentHandler: ========== TOOL PREPARATION (START) ==========")
            logger.info(f"AgentHandler: Checking agent.functions - exists: {hasattr(self.agent, 'functions')}, "
                       f"type: {type(self.agent.functions) if hasattr(self.agent, 'functions') else 'N/A'}")
            
            has_tools = self.agent.functions and len(self.agent.functions) > 0
            logger.info(f"AgentHandler: has_tools check result: {has_tools}")
            
            if hasattr(self.agent, 'functions'):
                if self.agent.functions:
                    logger.info(f"AgentHandler: agent.functions is not None/empty - length: {len(self.agent.functions)}, "
                               f"type: {type(self.agent.functions)}")
                    if isinstance(self.agent.functions, dict):
                        logger.info(f"AgentHandler: agent.functions keys (first 10): {list(self.agent.functions.keys())[:10]}")
                else:
                    logger.warning("AgentHandler: agent.functions exists but is None or empty!")
            else:
                logger.warning("AgentHandler: agent.functions attribute does not exist!")
            
            # Prepare tool definitions if tools are available
            # Convert Function objects to dicts for Gemini API
            tool_definitions = []
            if has_tools:
                logger.info(f"AgentHandler: Starting tool definition conversion from {len(self.agent.functions)} functions")
                for func in self.agent.functions.values():
                    # Convert Function to dict format expected by Gemini
                    if hasattr(func, 'to_dict'):
                        tool_dict = func.to_dict()
                        tool_definitions.append(tool_dict)
                        logger.debug(f"AgentHandler: Converted function '{func.name}' to dict using to_dict() method")
                    elif isinstance(func, dict):
                        tool_definitions.append(func)
                        logger.debug(f"AgentHandler: Function is already a dict, added directly")
                    else:
                        logger.warning(f"AgentHandler: Function {func.name if hasattr(func, 'name') else 'unknown'} cannot be converted to dict - "
                                     f"type: {type(func)}, has to_dict: {hasattr(func, 'to_dict')}")
                
                logger.info(f"AgentHandler: Successfully prepared {len(tool_definitions)} tool definitions for model")
                tool_names = [f.get('name', 'unknown') for f in tool_definitions]
                logger.info(f"AgentHandler: Tool names: {tool_names}")
                
                # Log structure of first tool for debugging
                if tool_definitions:
                    first_tool = tool_definitions[0]
                    logger.debug(f"AgentHandler: First tool structure - keys: {list(first_tool.keys()) if isinstance(first_tool, dict) else 'not a dict'}")
                    if isinstance(first_tool, dict) and 'function' in first_tool:
                        func_info = first_tool['function']
                        logger.debug(f"AgentHandler: First tool function info - name: {func_info.get('name', 'N/A')}, "
                                   f"description length: {len(func_info.get('description', '')) if func_info.get('description') else 0}")
            else:
                logger.warning("AgentHandler: No tools available for this request - has_tools is False")
            logger.info("AgentHandler: ========== TOOL PREPARATION (END) ==========")
            
            # Prepare messages with system instructions (will be updated in loop)
            messages_with_instructions = self._prepare_messages_with_instructions(messages)
            
            # Log message structure for debugging
            message_roles = [msg.role for msg in messages_with_instructions]
            logger.debug(f"AgentHandler: Initial messages: {len(messages_with_instructions)} with roles: {message_roles}")
            if messages_with_instructions and messages_with_instructions[0].role == "system":
                logger.info(f"AgentHandler: System instructions included in LLM request (first message is system)")
            
            # Use single continuous loop like Agno - handles tool calls automatically
            # This matches Agno's architecture: one loop that continues until no more tool calls
            accumulated_text = ""
            tool_call_count = 0
            tool_call_limit = 10  # Prevent infinite loops
            
            # Tool parameters - same throughout the loop (like Agno)
            tools_param = tool_definitions if tool_definitions else None
            # Use "auto" mode (or None which defaults to "auto" when tools are present)
            # This allows the model to decide whether to call tools based on the user's query
            # Agno uses "auto" as default when tools are present - this matches that behavior
            tool_choice_param = "auto" if tool_definitions else None
            
            logger.info("AgentHandler: ========== STARTING CONTINUOUS LOOP (AGNO-STYLE) ==========")
            logger.info(f"AgentHandler: Tools available: {len(tool_definitions) if tool_definitions else 0}")
            logger.info(f"AgentHandler: tool_choice: {tool_choice_param}")
            
            # Single continuous loop - like Agno's aresponse_stream
            while True:
                # Refresh messages_with_instructions from session at start of each iteration
                # This ensures we always have the complete conversation history including any previous tool results
                messages = session.get_conversation_history()
                messages_with_instructions = self._prepare_messages_with_instructions(messages)
                
                # Safety check: ensure we have messages to send
                if not messages_with_instructions:
                    logger.error("AgentHandler: No messages to send to model, breaking loop")
                    break
                
                # Create assistant message for this iteration
                assistant_message = Message(role="assistant")
                
                # Log iteration
                logger.info(f"AgentHandler: ========== LOOP ITERATION (tool_call_count={tool_call_count}) ==========")
                logger.info(f"AgentHandler: Messages in conversation: {len(messages_with_instructions)}")
                
                # Stream response from model
                collected_tool_calls = []
                iteration_text = ""
                
                logger.info(f"AgentHandler: Calling model.ainvoke_stream (tools={'PASSED' if tools_param else 'NOT PASSED'})")
                async for response_chunk in self.model.ainvoke_stream(
                    messages=messages_with_instructions,
                    assistant_message=assistant_message,
                    tools=tools_param,
                    tool_choice=tool_choice_param,
                ):
                    if response_chunk.content:
                        chunk_text = response_chunk.content
                        iteration_text += chunk_text
                        accumulated_text += chunk_text
                        
                        # Check for fake tool outputs in the text (common LLM hallucination)
                        if tool_definitions and ("tool_outputs" in chunk_text.lower() or 
                                               ("```" in chunk_text and "tool" in chunk_text.lower() and "output" in chunk_text.lower())):
                            logger.warning(
                                f"AgentHandler: Detected potential fake tool output in LLM response. "
                                f"Text preview: {chunk_text[:200]}..."
                            )
                        
                        # Yield partial message
                        yield ServerPartialMessage.create(
                            session_id=session.session_id,
                            text=chunk_text,
                            is_final=False,
                        )
                    
                    # Collect tool calls from chunks
                    if response_chunk.tool_calls:
                        collected_tool_calls.extend(response_chunk.tool_calls)
                        logger.info(f"AgentHandler: Collected {len(response_chunk.tool_calls)} tool call(s) from response chunk")
                
                # Set content and tool_calls on assistant message
                if iteration_text:
                    assistant_message.content = iteration_text
                if collected_tool_calls:
                    # Ensure tool_calls are in the correct format for Gemini
                    # Format: [{"function": {"name": "...", "arguments": "..."}, "id": "..."}]
                    formatted_tool_calls = []
                    for tc in collected_tool_calls:
                        if isinstance(tc, dict):
                            # Check if already in correct format
                            if "function" in tc:
                                formatted_tool_calls.append(tc)
                            elif "name" in tc or "tool_name" in tc:
                                # Convert from our format to Gemini format
                                func_name = tc.get("function", {}).get("name") or tc.get("name") or tc.get("tool_name")
                                func_args = tc.get("function", {}).get("arguments") or tc.get("arguments") or "{}"
                                formatted_tool_calls.append({
                                    "function": {
                                        "name": func_name,
                                        "arguments": func_args if isinstance(func_args, str) else json.dumps(func_args)
                                    },
                                    "id": tc.get("id") or tc.get("tool_call_id") or f"call_{func_name}_{len(formatted_tool_calls)}"
                                })
                            else:
                                formatted_tool_calls.append(tc)
                        else:
                            formatted_tool_calls.append(tc)
                    assistant_message.tool_calls = formatted_tool_calls
                    logger.debug(f"AgentHandler: Set {len(formatted_tool_calls)} tool call(s) on assistant message")
                
                # Add assistant message to conversation
                # Only add if it has content or tool_calls (don't add empty messages)
                if assistant_message.content or assistant_message.tool_calls:
                    session.add_message(assistant_message)
                    logger.debug(f"AgentHandler: Added assistant message to session - has_content={bool(assistant_message.content)}, has_tool_calls={bool(assistant_message.tool_calls)}")
                else:
                    logger.warning("AgentHandler: Skipping empty assistant message (no content or tool_calls)")
                
                # Check for tool calls to execute
                tool_calls_to_execute = collected_tool_calls if collected_tool_calls else (assistant_message.tool_calls or [])
                
                # Check if LLM generated fake tool outputs instead of making tool calls
                if tool_definitions and not tool_calls_to_execute and iteration_text:
                    fake_patterns = [
                        "tool_outputs" in iteration_text.lower(),
                        "```tool" in iteration_text.lower() and "output" in iteration_text.lower(),
                        '{"' in iteration_text and "tool" in iteration_text.lower() and "response" in iteration_text.lower(),
                    ]
                    if any(fake_patterns):
                        logger.warning(
                            f"AgentHandler: LLM generated fake tool outputs instead of making tool calls. "
                            f"Response contains patterns suggesting tool outputs: {iteration_text[:300]}..."
                        )
                
                # Handle tool calls if present (like Agno)
                if tool_calls_to_execute:
                    # Execute tool calls
                    logger.info(f"AgentHandler: Executing {len(tool_calls_to_execute)} tool call(s)")
                    function_call_results = []
                    for tool_call in tool_calls_to_execute:
                        func_name = tool_call.get("function", {}).get("name", "unknown")
                        func_args_str = tool_call.get("function", {}).get("arguments", "{}")
                        tool_call_id = tool_call.get("id") or tool_call.get("function", {}).get("id")
                        
                        try:
                            func_args = json.loads(func_args_str) if isinstance(func_args_str, str) else func_args_str
                            
                            # Notify client that tool is being called
                            yield ServerToolCallMessage.create(
                                session_id=session.session_id,
                                tool_name=func_name,
                                tool_arguments=func_args,
                                tool_call_id=tool_call_id,
                            )
                            
                            # Emit tool_call_start event
                            if self.event_bus:
                                await self.event_bus.publish(
                                    event_type="tool_call_start",
                                    session_id=session.session_id,
                                    data={
                                        "tool_name": func_name,
                                        "tool_arguments": func_args,
                                        "tool_call_id": tool_call_id,
                                    }
                                )
                            
                            # Record tool call in metrics
                            if self.metrics:
                                self.metrics.record_tool_call(session.session_id)
                                # Note: metrics_updated will be emitted after agent response completes
                            
                            # Collect tool call start telemetry (NON-BLOCKING)
                            tool_start_time = time.time()
                            if self.telemetry:
                                try:
                                    session_metrics = self.metrics.get_session_metrics(session.session_id) if self.metrics else None
                                    self.telemetry.collect(ToolEvent(
                                        event_type="tool_call_start",
                                        session_id=session.session_id,
                                        timestamp=tool_start_time,
                                        data={
                                            "tool_name": func_name,
                                            "tool_call_id": tool_call_id,
                                            "has_arguments": bool(func_args),
                                            "argument_count": len(func_args) if isinstance(func_args, dict) else 0,
                                        },
                                        metadata={
                                            "tool_sequence_position": len(session_metrics.tool_calls) + 1 if session_metrics else 1,
                                        }
                                    ))
                                except Exception:
                                    pass  # Never fail on telemetry
                            
                            # Execute the function in a thread pool to avoid blocking the event loop
                            # Tool execution (HTTP requests) is synchronous and can take time
                            logger.info(f"AgentHandler: Executing tool '{func_name}' with args: {func_args}")
                            loop = asyncio.get_event_loop()
                            try:
                                # Run in executor with timeout
                                result = await asyncio.wait_for(
                                    loop.run_in_executor(
                                        None,
                                        self.agent._execute_function,
                                        func_name,
                                        func_args
                                    ),
                                    timeout=30.0  # 30 second timeout for tool execution
                                )
                                tool_latency_ms = (time.time() - tool_start_time) * 1000
                                logger.info(f"AgentHandler: Tool '{func_name}' completed successfully")
                                
                                # Collect tool call complete telemetry (NON-BLOCKING)
                                if self.telemetry:
                                    try:
                                        self.telemetry.collect(ToolEvent(
                                            event_type="tool_call_complete",
                                            session_id=session.session_id,
                                            timestamp=time.time(),
                                            data={
                                                "tool_name": func_name,
                                                "tool_call_id": tool_call_id,
                                                "success": True,
                                                "latency_ms": tool_latency_ms,
                                                "has_result": result is not None,
                                                "result_length": len(str(result)) if result else 0,
                                                # Include FULL arguments/results if enabled
                                                "arguments": func_args if self.telemetry.config.include_message_content else None,
                                                "result": result if self.telemetry.config.include_message_content else None,
                                                "full_execution_data": {
                                                    "input": func_args,
                                                    "output": result,
                                                    "execution_time": tool_latency_ms,
                                                } if self.telemetry.config.include_message_content else None,
                                            },
                                            metadata={
                                                "error_type": None,
                                                "content_included": self.telemetry.config.include_message_content,
                                            }
                                        ))
                                    except Exception:
                                        pass  # Never fail on telemetry
                                
                                # Emit tool_call_complete event
                                if self.event_bus:
                                    # Format result preview for event (truncate if too long)
                                    result_preview = str(result)
                                    if len(result_preview) > 500:
                                        result_preview = result_preview[:500] + "..."
                                    
                                    await self.event_bus.publish(
                                        event_type="tool_call_complete",
                                        session_id=session.session_id,
                                        data={
                                            "tool_name": func_name,
                                            "tool_call_id": tool_call_id,
                                            "result_preview": result_preview,
                                            "success": True,
                                        }
                                    )
                            except asyncio.TimeoutError:
                                error_msg = f"Tool '{func_name}' execution timed out after 30 seconds"
                                logger.error(error_msg)
                                
                                # Collect tool error telemetry (NON-BLOCKING)
                                if self.telemetry and self.telemetry.config.enable_error_telemetry:
                                    try:
                                        tool_latency_ms = (time.time() - tool_start_time) * 1000
                                        import traceback
                                        self.telemetry.collect(ErrorEvent(
                                            event_type="error",
                                            session_id=session.session_id,
                                            timestamp=time.time(),
                                            data={
                                                "error_type": "TimeoutError",
                                                "error_category": "tool_execution",
                                                "retriable": True,
                                                # Include FULL error details if enabled
                                                "error_message": error_msg if self.telemetry.config.include_message_content else None,
                                                "stack_trace": traceback.format_exc() if (self.telemetry.config.include_message_content and self.telemetry.config.include_stack_traces) else None,
                                            },
                                            metadata={
                                                "component": "agent_handler",
                                                "operation": "tool_execution",
                                                "tool_name": func_name,
                                                "tool_call_id": tool_call_id,
                                                "content_included": self.telemetry.config.include_message_content,
                                            }
                                        ))
                                    except Exception:
                                        pass  # Never fail on telemetry
                                
                                # Emit tool_call_error event
                                if self.event_bus:
                                    await self.event_bus.publish(
                                        event_type="tool_call_error",
                                        session_id=session.session_id,
                                        data={
                                            "tool_name": func_name,
                                            "tool_call_id": tool_call_id,
                                            "error": error_msg,
                                            "error_type": "timeout",
                                        }
                                    )
                                
                                raise TimeoutError(error_msg)
                            except Exception as tool_error:
                                # Collect tool error telemetry (NON-BLOCKING)
                                if self.telemetry and self.telemetry.config.enable_error_telemetry:
                                    try:
                                        tool_latency_ms = (time.time() - tool_start_time) * 1000
                                        import traceback
                                        self.telemetry.collect(ErrorEvent(
                                            event_type="error",
                                            session_id=session.session_id,
                                            timestamp=time.time(),
                                            data={
                                                "error_type": type(tool_error).__name__,
                                                "error_category": "tool_execution",
                                                "retriable": getattr(tool_error, 'retriable', False),
                                                # Include FULL error details if enabled
                                                "error_message": str(tool_error) if self.telemetry.config.include_message_content else None,
                                                "stack_trace": traceback.format_exc() if (self.telemetry.config.include_message_content and self.telemetry.config.include_stack_traces) else None,
                                            },
                                            metadata={
                                                "component": "agent_handler",
                                                "operation": "tool_execution",
                                                "tool_name": func_name,
                                                "tool_call_id": tool_call_id,
                                                "content_included": self.telemetry.config.include_message_content,
                                            }
                                        ))
                                    except Exception:
                                        pass  # Never fail on telemetry
                                
                                # Re-raise to be handled by outer exception handler
                                raise
                            
                            # Notify client of tool result
                            yield ServerToolResultMessage.create(
                                session_id=session.session_id,
                                tool_name=func_name,
                                result=result,
                                tool_call_id=tool_call_id,
                                success=True,
                            )
                            
                            # Format tool result properly for Gemini function response
                            # REST API tools return json.dumps() which is already a JSON string
                            # We need to ensure it's clean and properly formatted
                            
                            # Log raw result for debugging
                            result_preview = str(result)[:200] + "..." if len(str(result)) > 200 else str(result)
                            logger.debug(f"AgentHandler: Raw tool result from '{func_name}': {result_preview}")
                            logger.debug(f"AgentHandler: Tool result type: {type(result)}")
                            
                            # Format tool result content
                            if isinstance(result, str):
                                # Result is already a string - could be JSON string or plain text
                                tool_result_content = result
                                # Try to parse and re-serialize to ensure it's valid JSON
                                # This helps catch nested JSON strings (double-encoded)
                                try:
                                    parsed = json.loads(result)
                                    # If it parses successfully, re-serialize to ensure clean format
                                    # This handles cases where JSON might be nested as a string
                                    tool_result_content = json.dumps(parsed, ensure_ascii=False)
                                    logger.debug(f"AgentHandler: Tool result parsed and re-serialized as JSON")
                                except (json.JSONDecodeError, TypeError):
                                    # Not JSON, use as-is (plain text result)
                                    tool_result_content = result
                                    logger.debug(f"AgentHandler: Tool result is plain text, using as-is")
                            elif isinstance(result, (dict, list)):
                                # Result is a dict/list - serialize to JSON
                                tool_result_content = json.dumps(result, ensure_ascii=False)
                                logger.debug(f"AgentHandler: Tool result is dict/list, serialized to JSON")
                            else:
                                # Other types - convert to string
                                tool_result_content = str(result)
                                logger.debug(f"AgentHandler: Tool result is {type(result)}, converted to string")
                            
                            # Log formatted content preview
                            content_preview = tool_result_content[:200] + "..." if len(tool_result_content) > 200 else tool_result_content
                            logger.debug(f"AgentHandler: Formatted tool result content: {content_preview}")
                            
                            # Create Message with proper structure for Gemini function response
                            # Gemini expects: role="tool" with tool_calls containing tool_name and content
                            tool_result_message = Message(
                                role="tool",
                                content=tool_result_content,
                                tool_calls=[{
                                    "tool_name": func_name,
                                    "content": tool_result_content
                                }]
                            )
                            
                            # Log the Message structure for debugging
                            logger.debug(f"AgentHandler: Created tool result Message - role={tool_result_message.role}, "
                                       f"tool_calls count={len(tool_result_message.tool_calls) if tool_result_message.tool_calls else 0}")
                            
                            function_call_results.append(tool_result_message)
                        except Exception as e:
                            error_msg = str(e)
                            if self.config.debug:
                                print(f"Error executing tool {func_name}: {error_msg}")
                            
                            # Emit tool_call_error event
                            if self.event_bus:
                                await self.event_bus.publish(
                                    event_type="tool_call_error",
                                    session_id=session.session_id,
                                    data={
                                        "tool_name": func_name,
                                        "tool_call_id": tool_call_id,
                                        "error": error_msg,
                                        "error_type": "execution_error",
                                    }
                                )
                            
                            # Notify client of tool error
                            yield ServerToolResultMessage.create(
                                session_id=session.session_id,
                                tool_name=func_name,
                                result=None,
                                tool_call_id=tool_call_id,
                                success=False,
                                error=error_msg,
                            )
                            
                            function_call_results.append(Message(
                                role="tool",
                                content=f"Error: {error_msg}",
                                tool_calls=[{
                                    "tool_name": func_name,
                                    "content": f"Error: {error_msg}"
                                }]
                            ))
                    
                    # Add tool results to conversation
                    for result in function_call_results:
                        session.add_message(result)
                        logger.debug(f"AgentHandler: Added tool result message - role={result.role}")
                    
                    # Update tool call count
                    tool_call_count += len(function_call_results)
                    
                    # Check tool call limit
                    if tool_call_limit and tool_call_count >= tool_call_limit:
                        logger.warning(f"AgentHandler: Tool call limit ({tool_call_limit}) reached, breaking loop")
                        break
                    
                    # Continue loop to get next response (like Agno)
                    # messages_with_instructions will be refreshed at the start of next iteration
                    logger.info(f"AgentHandler: Continuing loop after tool execution (tool_call_count={tool_call_count})")
                    continue
                
                # No tool calls - break and return final response (like Agno)
                logger.info(f"AgentHandler: No tool calls, breaking loop. Final text length: {len(accumulated_text)}")
                break
            
            logger.info("AgentHandler: ========== CONTINUOUS LOOP COMPLETE ==========")
            
            # Final message handling
            # If we have accumulated text, ensure the last assistant message has it set
            # and yield a final ServerTextMessage with the complete text
            if accumulated_text:
                # Find the last assistant message and ensure content is set
                for msg in reversed(session.get_conversation_history()):
                    if msg.role == "assistant":
                        if msg.content != accumulated_text:
                            msg.content = accumulated_text
                            logger.debug(f"AgentHandler: Updated last assistant message content (length: {len(accumulated_text)})")
                        break
                
                # Record metrics
                latency_ms = (time.time() - start_time) * 1000
                if self.metrics:
                    self.metrics.record_agent_response(latency_ms, session.session_id)
                
                # Collect agent response telemetry (NON-BLOCKING)
                if self.telemetry and self.telemetry.config.enable_performance_telemetry:
                    try:
                        # Get conversation history for context
                        conversation_history = session.get_conversation_history()
                        conversation_context = None
                        if self.telemetry.config.include_message_content:
                            # PII filtering will be applied by telemetry collector
                            conversation_context = [
                                {"role": msg.role, "content": str(msg.content)}
                                for msg in conversation_history[-10:]  # Last 10 messages
                            ]
                        
                        # Get prompt text from last messages sent to model
                        prompt_text = None
                        if self.telemetry.config.include_message_content and messages_with_instructions:
                            # Reconstruct prompt from messages (PII filtering will be applied by telemetry collector)
                            prompt_parts = []
                            for msg in messages_with_instructions:
                                if msg.role == "system":
                                    prompt_parts.append(f"System: {msg.content}")
                                elif msg.role == "user":
                                    prompt_parts.append(f"User: {msg.content}")
                                elif msg.role == "assistant":
                                    prompt_parts.append(f"Assistant: {msg.content}")
                            prompt_text = "\n".join(prompt_parts)
                        
                        # Get model ID
                        model_id = None
                        if hasattr(self.model, 'model_id'):
                            model_id = self.model.model_id
                        elif hasattr(self.model, 'id'):
                            model_id = self.model.id
                        
                        self.telemetry.collect(AgentEvent(
                            event_type="agent_response",
                            session_id=session.session_id,
                            timestamp=time.time(),
                            data={
                                "latency_ms": latency_ms,
                                "response_length": len(accumulated_text),
                                "model_id": model_id,
                                # Include FULL content if enabled
                                # PII filtering will be applied by telemetry collector in _process_event()
                                "response_content": accumulated_text if (self.telemetry.config.include_message_content and accumulated_text) else None,
                                "prompt_content": prompt_text if self.telemetry.config.include_message_content else None,
                                "conversation_context": conversation_context if self.telemetry.config.include_message_content else None,
                            },
                            metadata={
                                "agent_name": self.name,
                                "content_included": self.telemetry.config.include_message_content,
                            }
                        ))
                    except Exception:
                        pass  # Never fail on telemetry
                
                # Yield final text message with complete accumulated text
                # This ensures the client receives the full response even if partial messages were streamed
                logger.info(f"AgentHandler: Yielding final ServerTextMessage with text length: {len(accumulated_text)}")
                yield ServerTextMessage.create(
                    session_id=session.session_id,
                    text=accumulated_text,
                    metadata=metadata,
                )
            else:
                # Empty response - still yield to signal completion
                logger.warning("AgentHandler: No accumulated text, yielding empty ServerTextMessage")
                yield ServerTextMessage.create(
                    session_id=session.session_id,
                    text="",
                    metadata=metadata,
                )
                
        except Exception as e:
            error_msg = f"Agent processing failed: {str(e)}"
            if self.metrics:
                self.metrics.record_error(session.session_id)
            
            # Collect error telemetry (NON-BLOCKING)
            if self.telemetry and self.telemetry.config.enable_error_telemetry:
                try:
                    import traceback
                    self.telemetry.collect(ErrorEvent(
                        event_type="error",
                        session_id=session.session_id,
                        timestamp=time.time(),
                        data={
                            "error_type": type(e).__name__,
                            "error_category": "agent_processing",
                            "retriable": getattr(e, 'retriable', False),
                            # Include FULL error details if enabled
                            "error_message": str(e) if self.telemetry.config.include_message_content else None,
                            "stack_trace": traceback.format_exc() if (self.telemetry.config.include_message_content and self.telemetry.config.include_stack_traces) else None,
                        },
                        metadata={
                            "component": "agent_handler",
                            "operation": "process_text_async",
                            "content_included": self.telemetry.config.include_message_content,
                        }
                    ))
                except Exception:
                    pass  # Never fail on telemetry
            
            raise AgentError(error_msg, retriable=False) from e
    
    async def process_transcription_async(
        self,
        session: Session,
        transcription: str,
        metadata: Optional[Dict] = None,
    ) -> AsyncIterator[ServerPartialMessage | ServerTextMessage | ServerToolCallMessage | ServerToolResultMessage]:
        """Process STT transcription and stream response.
        
        Args:
            session: Session object
            transcription: Transcribed text
            metadata: Optional metadata
            
        Yields:
            ServerPartialMessage, ServerTextMessage, 
            ServerToolCallMessage, or ServerToolResultMessage
            
        Note: ServerSTTMessage is sent separately by the websocket server
        before calling this method, so we don't send it here to avoid duplicates.
        """
        # Process as text (STT message is already sent by websocket_server)
        async for message in self.process_text_async(session, transcription, metadata):
            yield message
    
    async def process_audio_async(
        self,
        session: Session,
        audio_bytes: bytes,
        sample_rate: int,
        encoding: str,
        metadata: Optional[Dict] = None,
    ) -> AsyncIterator[ServerPartialMessage | ServerTextMessage]:
        """Process audio input (directly to agent, bypassing STT).
        
        Note: This is for future use when Gemini supports direct audio input.
        Currently, audio should be transcribed first using STT.
        
        Args:
            session: Session object
            audio_bytes: Audio bytes
            sample_rate: Sample rate
            encoding: Encoding format
            metadata: Optional metadata
            
        Yields:
            ServerPartialMessage or ServerTextMessage
        """
        raise NotImplementedError("Direct audio processing not yet implemented. Use STT first.")

