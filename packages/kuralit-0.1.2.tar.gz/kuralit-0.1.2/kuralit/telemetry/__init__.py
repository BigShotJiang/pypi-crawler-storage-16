"""Telemetry collection module for Kuralit.

This module provides non-blocking telemetry collection for diagnostics and analytics.
All telemetry operations are designed to never interfere with application functionality.
"""

from kuralit.telemetry.collector import TelemetryCollector
from kuralit.telemetry.events import (
    TelemetryEvent,
    SessionEvent,
    AgentEvent,
    ToolEvent,
    STTEvent,
    ErrorEvent,
)

__all__ = [
    "TelemetryCollector",
    "TelemetryEvent",
    "SessionEvent",
    "AgentEvent",
    "ToolEvent",
    "STTEvent",
    "ErrorEvent",
]

