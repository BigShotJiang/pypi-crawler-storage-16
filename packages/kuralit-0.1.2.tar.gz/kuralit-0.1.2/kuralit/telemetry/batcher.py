"""Batching logic for telemetry events."""

import logging
import time
from typing import List, Optional
from kuralit.telemetry.events import TelemetryEvent

logger = logging.getLogger(__name__)


class TelemetryBatcher:
    """Batches telemetry events for efficient transmission."""
    
    def __init__(
        self,
        batch_size: int = 100,
        batch_interval_seconds: int = 30,
    ):
        """Initialize batcher.
        
        Args:
            batch_size: Maximum events per batch
            batch_interval_seconds: Maximum time to wait before sending batch
        """
        self.batch_size = batch_size
        self.batch_interval_seconds = batch_interval_seconds
        self.current_batch: List[TelemetryEvent] = []
        self.last_batch_time = time.time()
    
    def add_event(self, event: TelemetryEvent) -> Optional[List[TelemetryEvent]]:
        """Add event to batch.
        
        Args:
            event: Telemetry event to add
            
        Returns:
            Batch of events if ready to send, None otherwise
        """
        self.current_batch.append(event)
        
        # Check if batch is full
        if len(self.current_batch) >= self.batch_size:
            batch = self.current_batch.copy()
            self.current_batch.clear()
            self.last_batch_time = time.time()
            return batch
        
        # Check if batch interval has elapsed
        elapsed = time.time() - self.last_batch_time
        if elapsed >= self.batch_interval_seconds and len(self.current_batch) > 0:
            batch = self.current_batch.copy()
            self.current_batch.clear()
            self.last_batch_time = time.time()
            return batch
        
        return None
    
    def get_pending_batch(self) -> Optional[List[TelemetryEvent]]:
        """Get pending batch if it has events.
        
        Returns:
            Batch of events if any pending, None otherwise
        """
        if len(self.current_batch) > 0:
            batch = self.current_batch.copy()
            self.current_batch.clear()
            return batch
        return None
    
    def clear(self) -> None:
        """Clear current batch."""
        self.current_batch.clear()

