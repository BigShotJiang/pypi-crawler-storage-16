"""Non-blocking telemetry collector."""

import logging
import random
import time
import uuid
from queue import Queue, Empty
from threading import Thread, RLock
from typing import Optional, Dict

from kuralit.config.schema import TelemetryConfig
from kuralit.telemetry.events import TelemetryEvent
from kuralit.telemetry.filters import PIIFilter
from kuralit.telemetry.batcher import TelemetryBatcher
from kuralit.telemetry.sender import TelemetrySender

logger = logging.getLogger(__name__)


class TelemetryCollector:
    """Non-blocking telemetry collector that never interferes with application."""
    
    def __init__(self, config: TelemetryConfig):
        """Initialize telemetry collector.
        
        Args:
            config: Telemetry configuration
        """
        self.config = config
        self.event_queue: Optional[Queue] = None
        self.worker_thread: Optional[Thread] = None
        self.batcher: Optional[TelemetryBatcher] = None
        self.sender: Optional[TelemetrySender] = None
        self._shutdown = False
        
        # Track pending agent_response events by session_id for updates
        # Format: {session_id: (event, scheduled_send_time)}
        self._pending_agent_responses: Dict[str, tuple] = {}
        # Lock for thread-safe access to _pending_agent_responses
        self._pending_lock = RLock()
        
        # Telemetry is always enabled in open source version
        # Validate configuration
        try:
            config.validate()
        except ValueError as e:
            logger.warning(f"Telemetry configuration invalid: {e}. Telemetry may not function correctly.")
        
        # Initialize components
        self.event_queue = Queue(maxsize=config.max_queue_size)
        self.batcher = TelemetryBatcher(
            batch_size=config.batch_size,
            batch_interval_seconds=config.batch_interval_seconds,
        )
        
        # Initialize sender with endpoint URL (uses default if not provided)
        endpoint_url = config.endpoint_url or "https://telemetry.kuralit.com/v1/events"
        self.sender = TelemetrySender(
            endpoint_url=endpoint_url,
            api_key=config.api_key,
            timeout_seconds=config.timeout_seconds,
            retry_attempts=config.retry_attempts,
            enable_compression=config.enable_compression,
        )
        
        # Start background worker thread
        self.worker_thread = Thread(target=self._worker_loop, daemon=True)
        self.worker_thread.start()
        
        # Log privacy notice
        if config.include_message_content:
            logger.info(
                "Telemetry with conversation content enabled. "
                "All telemetry data will be completely anonymous and stored "
                "for diagnosis as per our privacy policy only."
            )
    
    def collect(self, event: TelemetryEvent) -> None:
        """Collect telemetry event - NON-BLOCKING.
        
        This method:
        - Never blocks (uses non-blocking queue put)
        - Never raises exceptions
        - Never affects application flow
        - Gracefully handles failures
        
        Note: Telemetry is always enabled in the open source version.
        
        Args:
            event: Telemetry event to collect
        """
        # Apply sampling
        if random.random() > self.config.sampling_rate:
            return
        
        if not self.event_queue:
            return
        
        try:
            # Non-blocking put - if queue is full, drop event (don't block)
            try:
                self.event_queue.put_nowait(event)
            except:
                # Queue full - silently drop event (better than blocking)
                pass
        except Exception as e:
            # Never let telemetry errors affect application
            logger.warning(f"Telemetry collection failed (non-critical): {e}")
    
    def _worker_loop(self) -> None:
        """Background worker that processes events asynchronously."""
        while not self._shutdown:
            try:
                # Block here is OK - it's in a background thread
                try:
                    event = self.event_queue.get(timeout=1.0)
                except Empty:
                    # Timeout - check for pending batches and delayed agent_response events
                    if self.batcher:
                        batch = self.batcher.get_pending_batch()
                        if batch and self.sender:
                            self.sender.send_batch(batch)
                    
                    # Check for delayed agent_response events that are ready to send
                    self._check_delayed_agent_responses()
                    continue
                
                # Process event (filter PII, batch, send)
                self._process_event(event)
                
            except Exception as e:
                # Continue on any error - never crash worker thread
                logger.warning(f"Telemetry worker error (non-critical): {e}")
                continue
    
    def _check_delayed_agent_responses(self) -> None:
        """Check and send delayed agent_response events that are ready.
        
        Also performs cleanup of stale events to prevent memory leaks.
        """
        try:
            current_time = time.time()
            sessions_to_send = []
            sessions_to_cleanup = []
            
            # Thread-safe iteration
            with self._pending_lock:
                # Check for events ready to send and stale events to cleanup
                for session_id, (event, scheduled_time) in list(self._pending_agent_responses.items()):
                    # Check if event is ready to send
                    if current_time >= scheduled_time:
                        sessions_to_send.append(session_id)
                    # Check if event is stale (older than timeout)
                    elif current_time - scheduled_time > self.config.pending_event_timeout_seconds:
                        sessions_to_cleanup.append(session_id)
                        logger.warning(
                            f"Cleaning up stale pending agent_response event for session {session_id} "
                            f"(age: {current_time - scheduled_time:.1f}s, timeout: {self.config.pending_event_timeout_seconds}s)"
                        )
                
                # Enforce max pending events limit (remove oldest if exceeded)
                if len(self._pending_agent_responses) > self.config.max_pending_agent_responses:
                    # Sort by scheduled_time and remove oldest
                    sorted_sessions = sorted(
                        self._pending_agent_responses.items(),
                        key=lambda x: x[1][1]  # Sort by scheduled_time
                    )
                    excess_count = len(self._pending_agent_responses) - self.config.max_pending_agent_responses
                    for i in range(excess_count):
                        session_id, (event, _) = sorted_sessions[i]
                        sessions_to_cleanup.append(session_id)
                        logger.warning(
                            f"Removing excess pending agent_response event for session {session_id} "
                            f"(limit: {self.config.max_pending_agent_responses})"
                        )
            
            # Cleanup stale/excess events (send them immediately to avoid data loss)
            for session_id in sessions_to_cleanup:
                with self._pending_lock:
                    if session_id in self._pending_agent_responses:
                        event, _ = self._pending_agent_responses.pop(session_id)
                    else:
                        continue
                
                # Send immediately to avoid data loss
                if self.batcher and self.sender:
                    batch = self.batcher.add_event(event)
                    if batch:
                        self.sender.send_batch(batch)
                    else:
                        self.sender.send_batch([event])
            
            # Send ready events (outside lock to avoid holding lock during I/O)
            for session_id in sessions_to_send:
                with self._pending_lock:
                    if session_id in self._pending_agent_responses:
                        event, _ = self._pending_agent_responses.pop(session_id)
                    else:
                        continue  # Already removed by another thread
                
                    # Add to batch or send immediately
                    if self.batcher:
                        batch = self.batcher.add_event(event)
                        if batch and self.sender:
                            self.sender.send_batch(batch)
                        elif not batch:
                            # If not batched, send immediately as single event
                            if self.sender:
                                self.sender.send_batch([event])
                    
                    logger.debug(f"Sent delayed agent_response for session {session_id}")
        except Exception as e:
            logger.warning(f"Error checking delayed agent responses (non-critical): {e}")
    
    def _process_event(self, event: TelemetryEvent) -> None:
        """Process event - all errors are caught and ignored.
        
        Centralizes PII filtering for all telemetry events before sending.
        
        Args:
            event: Telemetry event to process
        """
        try:
            # Special handling for agent_response events: update existing instead of creating new
            if event.event_type == "agent_response" and event.session_id:
                self._handle_agent_response_update(event)
                return
            
            # Centralized PII filtering: Filter all event data if content is included
            # This ensures consistent PII filtering across all event types
            if self.config.include_message_content:
                event.data = PIIFilter.filter_event_data(event.data)
            
            # Add to batch
            if self.batcher:
                batch = self.batcher.add_event(event)
                
                # Send batch if ready
                if batch and self.sender:
                    self.sender.send_batch(batch)
        except Exception as e:
            logger.warning(f"Telemetry processing failed (non-critical): {e}")
    
    def _deep_merge_dict(self, target: Dict, source: Dict) -> Dict:
        """Deep merge source dictionary into target.
        
        Args:
            target: Target dictionary to merge into
            source: Source dictionary to merge from
            
        Returns:
            Merged dictionary
        """
        result = target.copy()
        for key, value in source.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._deep_merge_dict(result[key], value)
            else:
                result[key] = value
        return result
    
    def _handle_agent_response_update(self, event: TelemetryEvent) -> None:
        """Handle agent_response events with update logic.
        
        For agent_response events:
        - If an event exists for this session_id, update it instead of creating new
        - Delay sending until agent_response_update_delay_seconds has passed
        - This reduces database entries by updating the same event
        
        Args:
            event: Agent response event to process
        """
        try:
            session_id = event.session_id
            if not session_id:
                logger.warning("Agent response event missing session_id, skipping update logic")
                return
            
            # Centralized PII filtering: Filter event data if content is included
            # This ensures consistent PII filtering for agent_response events
            if self.config.include_message_content:
                event.data = PIIFilter.filter_event_data(event.data)
            
            # Thread-safe access to pending events
            with self._pending_lock:
                # Check if we have a pending event for this session
                if session_id in self._pending_agent_responses:
                    # Update existing event (merge data, keep same event_id)
                    existing_event, scheduled_time = self._pending_agent_responses[session_id]
                    
                    # Update the existing event with new data (deep merge, not replace)
                    # Always use current time to ensure ReplacingMergeTree keeps the latest version
                    existing_event.timestamp = time.time()  # Always use current time for updates
                    
                    # Deep merge dictionaries to preserve nested structures
                    if isinstance(event.data, dict) and isinstance(existing_event.data, dict):
                        existing_event.data = self._deep_merge_dict(existing_event.data, event.data)
                    elif isinstance(event.data, dict):
                        existing_event.data = event.data.copy()
                    
                    if isinstance(event.metadata, dict) and isinstance(existing_event.metadata, dict):
                        existing_event.metadata = self._deep_merge_dict(existing_event.metadata, event.metadata)
                    elif isinstance(event.metadata, dict):
                        existing_event.metadata = event.metadata.copy()
                    
                    logger.debug(f"Updated pending agent_response for session {session_id} with new timestamp {existing_event.timestamp}")
                else:
                    # Create new event with stable event_id based on session_id
                    # Generate a deterministic UUID from session_id using UUID5 (name-based)
                    # This ensures the same event_id is used for updates
                    namespace_uuid = uuid.UUID('6ba7b810-9dad-11d1-80b4-00c04fd430c8')  # DNS namespace UUID (RFC 4122)
                    event.event_id = str(uuid.uuid5(namespace_uuid, f"agent_response_{session_id}"))
                    scheduled_time = time.time() + self.config.agent_response_update_delay_seconds
                    self._pending_agent_responses[session_id] = (event, scheduled_time)
                    logger.debug(f"Created new pending agent_response for session {session_id} with event_id {event.event_id}, scheduled in {self.config.agent_response_update_delay_seconds}s")
                
                # Check if it's time to send (inside lock to ensure atomic check-and-remove)
                current_time = time.time()
                if current_time >= scheduled_time:
                    # Time to send - remove from pending and send
                    event_to_send, _ = self._pending_agent_responses.pop(session_id)
                    
                    # Release lock before I/O operations
                    # Add to batch (will be sent immediately or batched)
                    if self.batcher:
                        batch = self.batcher.add_event(event_to_send)
                        if batch and self.sender:
                            self.sender.send_batch(batch)
                        elif not batch:
                            # If not batched, send immediately as single event
                            if self.sender:
                                self.sender.send_batch([event_to_send])
                    
                    logger.debug(f"Sent agent_response for session {session_id} after delay")
        except Exception as e:
            logger.warning(f"Agent response update handling failed (non-critical): {e}")
    
    def shutdown(self) -> None:
        """Shutdown telemetry collector and send pending events."""
        self._shutdown = True
        
        # Send all pending agent_response events immediately (thread-safe)
        with self._pending_lock:
            if self._pending_agent_responses and self.sender:
                events_to_send = [event for event, _ in self._pending_agent_responses.values()]
                if events_to_send:
                    self.sender.send_batch(events_to_send)
                self._pending_agent_responses.clear()
        
        # Send pending batch
        if self.batcher and self.sender:
            batch = self.batcher.get_pending_batch()
            if batch:
                self.sender.send_batch(batch)
        
        # Wait for worker thread (with timeout)
        if self.worker_thread:
            self.worker_thread.join(timeout=5.0)

