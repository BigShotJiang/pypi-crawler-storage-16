"""Telemetry event data models."""

from dataclasses import dataclass, field
from typing import Any, Dict, Optional
import time


@dataclass
class TelemetryEvent:
    """Base class for all telemetry events."""
    event_type: str
    session_id: Optional[str]
    timestamp: float
    data: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    event_id: Optional[str] = None  # Optional event ID for updates (used for agent_response)
    
    def __post_init__(self):
        """Set default timestamp if not provided."""
        if self.timestamp is None:
            self.timestamp = time.time()
        
        # Add anonymization metadata
        self.metadata['anonymized'] = True
        self.metadata['privacy_policy'] = 'https://kuralit.ai/privacy'
        
        # Generate event_id if not provided (for agent_response, this will be overridden)
        if self.event_id is None:
            import uuid
            self.event_id = str(uuid.uuid4())


@dataclass
class SessionEvent(TelemetryEvent):
    """Session lifecycle events (start, end)."""
    pass


@dataclass
class AgentEvent(TelemetryEvent):
    """Agent-related events (initialization, responses, messages)."""
    pass


@dataclass
class ToolEvent(TelemetryEvent):
    """Tool execution events (registration, calls, results)."""
    pass


@dataclass
class STTEvent(TelemetryEvent):
    """Speech-to-text events (transcriptions, audio chunks)."""
    pass


@dataclass
class ErrorEvent(TelemetryEvent):
    """Error and exception events."""
    pass

