"""PII filtering for telemetry data using Microsoft Presidio."""

import logging
import subprocess
import sys
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

# Try to import Presidio - gracefully handle if not available
_analyzer = None
_anonymizer = None
_presidio_available = False


def _download_spacy_model(model_name: str = "en_core_web_lg") -> bool:
    """Automatically download spacy model if not available.
    
    Args:
        model_name: Name of the spacy model to download
        
    Returns:
        True if download succeeded or model already exists, False otherwise
    """
    try:
        import spacy
        # Check if model is already installed
        try:
            spacy.load(model_name)
            logger.debug(f"Spacy model '{model_name}' already installed")
            return True
        except OSError:
            # Model not found, download it
            logger.info(f"Downloading spacy model '{model_name}'...")
            subprocess.check_call(
                [sys.executable, "-m", "spacy", "download", model_name],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            logger.info(f"Successfully downloaded spacy model '{model_name}'")
            return True
    except subprocess.CalledProcessError as e:
        logger.warning(f"Failed to download spacy model '{model_name}': {e}")
        return False
    except Exception as e:
        logger.warning(f"Error checking/downloading spacy model: {e}")
        return False


def _initialize_presidio():
    """Initialize Presidio engines with automatic spacy model download."""
    global _analyzer, _anonymizer, _presidio_available
    
    try:
        from presidio_analyzer import AnalyzerEngine
        from presidio_anonymizer import AnonymizerEngine
        
        try:
            _analyzer = AnalyzerEngine()
            _anonymizer = AnonymizerEngine()
            _presidio_available = True
            logger.info("Presidio PII filtering enabled")
        except Exception as e:
            # Try to download spacy model and retry
            error_msg = str(e).lower()
            if "spacy" in error_msg or "model" in error_msg or "en_core" in error_msg:
                logger.info("Spacy model not found, attempting automatic download...")
                if _download_spacy_model():
                    try:
                        _analyzer = AnalyzerEngine()
                        _anonymizer = AnonymizerEngine()
                        _presidio_available = True
                        logger.info("Presidio PII filtering enabled after model download")
                    except Exception as retry_error:
                        logger.warning(
                            f"Presidio initialization failed after model download: {retry_error}. "
                            "PII filtering will be disabled."
                        )
                        _presidio_available = False
                else:
                    logger.warning(
                        f"Presidio initialized but failed to load models: {e}. "
                        "PII filtering will be disabled."
                    )
                    _presidio_available = False
            else:
                logger.warning(
                    f"Presidio initialization failed: {e}. "
                    "PII filtering will be disabled."
                )
                _presidio_available = False
    except ImportError:
        logger.warning(
            "Presidio not installed. PII filtering disabled. "
            "Install with: pip install presidio_analyzer presidio_anonymizer"
        )
        _presidio_available = False


# Initialize Presidio on module import
_initialize_presidio()


class PIIFilter:
    """Filter PII from telemetry data before transmission using Microsoft Presidio."""
    
    @staticmethod
    def filter_pii(text: str, language: str = "en") -> str:
        """Remove PII from text content using Presidio.
        
        Args:
            text: Text content to filter
            language: Language code for analysis (default: "en")
            
        Returns:
            Filtered text with PII anonymized by Presidio
        """
        if not text or not isinstance(text, str):
            return text
        
        # If Presidio is not available, return text as-is (graceful degradation)
        if not _presidio_available:
            logger.debug("Presidio not available, skipping PII filtering")
            return text
        
        try:
            # Analyze the text to detect PII entities
            analyzer_results = _analyzer.analyze(text=text, language=language)
            
            # Anonymize the text using the default operator (replace with entity type)
            anonymized_results = _anonymizer.anonymize(
                text=text,
                analyzer_results=analyzer_results
            )
            
            return anonymized_results.text
        except Exception as e:
            # Never fail on PII filtering - log and return original text
            logger.warning(f"PII filtering failed: {e}. Returning original text.")
            return text
    
    @staticmethod
    def filter_event_data(data: Dict[str, Any], language: str = "en") -> Dict[str, Any]:
        """Filter PII from event data dictionary using Presidio.
        
        Args:
            data: Event data dictionary
            language: Language code for Presidio analysis (default: "en")
            
        Returns:
            Filtered event data with PII anonymized
        """
        if not isinstance(data, dict):
            return data
        
        filtered = {}
        for key, value in data.items():
            if isinstance(value, str):
                # Filter text fields that might contain PII
                if any([
                    'content' in key.lower(),
                    'message' in key.lower(),
                    'text' in key.lower(),
                    'transcript' in key.lower(),
                    'prompt' in key.lower(),
                    'response' in key.lower(),
                    'error' in key.lower(),
                    'exception' in key.lower(),
                    'traceback' in key.lower(),
                    'result' in key.lower(),
                    'argument' in key.lower(),
                ]):
                    filtered[key] = PIIFilter.filter_pii(value, language=language)
                else:
                    filtered[key] = value
            elif isinstance(value, dict):
                # Recursively filter nested dictionaries
                filtered[key] = PIIFilter.filter_event_data(value, language=language)
            elif isinstance(value, list):
                # Filter list items
                filtered[key] = [
                    PIIFilter.filter_event_data(item, language=language) if isinstance(item, dict)
                    else PIIFilter.filter_pii(item, language=language) if isinstance(item, str)
                    else item
                    for item in value
                ]
            else:
                filtered[key] = value
        
        return filtered

