"""HTTP sender for telemetry events."""

import gzip
import json
import logging
import time
from typing import List, Optional
import requests
from kuralit.telemetry.events import TelemetryEvent

logger = logging.getLogger(__name__)


class TelemetrySender:
    """Sends telemetry events to the telemetry endpoint."""
    
    def __init__(
        self,
        endpoint_url: str,
        api_key: Optional[str] = None,
        timeout_seconds: int = 10,
        retry_attempts: int = 3,
        enable_compression: bool = True,
    ):
        """Initialize sender.
        
        Args:
            endpoint_url: Telemetry endpoint URL
            api_key: API key for authentication
            timeout_seconds: HTTP request timeout
            retry_attempts: Number of retry attempts
            enable_compression: Whether to compress payloads
        """
        self.endpoint_url = endpoint_url
        self.api_key = api_key
        self.timeout_seconds = timeout_seconds
        self.retry_attempts = retry_attempts
        self.enable_compression = enable_compression
    
    def send_batch(self, events: List[TelemetryEvent]) -> bool:
        """Send batch of events to telemetry endpoint.
        
        Args:
            events: List of telemetry events to send
            
        Returns:
            True if successful, False otherwise
        """
        if not events:
            return True
        
        # Convert events to JSON
        try:
            payload = {
                "events": [
                    {
                        "event_type": event.event_type,
                        "session_id": event.session_id,
                        "timestamp": event.timestamp,
                        "data": event.data,
                        "metadata": event.metadata,
                        # Only include event_id for agent_response events (for updates)
                        **({"event_id": event.event_id} if event.event_type == "agent_response" and event.event_id else {}),
                    }
                    for event in events
                ]
            }
            json_data = json.dumps(payload)
        except Exception as e:
            logger.debug(f"Failed to serialize telemetry events: {e}")
            return False
        
        # Prepare headers
        headers = {
            "Content-Type": "application/json",
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        
        # Compress if enabled
        data = json_data.encode('utf-8')
        if self.enable_compression:
            data = gzip.compress(data)
            headers["Content-Encoding"] = "gzip"
        
        # Log request details for debugging
        logger.info(f"Telemetry: Sending batch of {len(events)} events to {self.endpoint_url}")
        logger.debug(f"Telemetry: Request headers: {headers}")
        logger.debug(f"Telemetry: Payload (first 500 chars): {json_data[:500] if not self.enable_compression else '[compressed]'}")
        
        # Retry logic
        for attempt in range(self.retry_attempts):
            try:
                response = requests.post(
                    self.endpoint_url,
                    data=data,
                    headers=headers,
                    timeout=self.timeout_seconds,
                )
                response.raise_for_status()
                logger.info(f"Telemetry: Successfully sent batch of {len(events)} events")
                return True
            except requests.exceptions.HTTPError as e:
                # Log detailed error information
                error_detail = ""
                try:
                    error_detail = response.text
                    logger.error(f"Telemetry: HTTP {response.status_code} error: {error_detail}")
                except:
                    logger.error(f"Telemetry: HTTP {response.status_code} error: {str(e)}")
                
                # Log the actual payload being sent (uncompressed) for debugging
                if self.enable_compression:
                    logger.debug(f"Telemetry: Uncompressed payload: {json_data[:1000]}")
                
                if attempt < self.retry_attempts - 1:
                    # Exponential backoff
                    time.sleep(2 ** attempt)
                    continue
                else:
                    logger.warning(f"Telemetry: Failed to send batch after {self.retry_attempts} attempts: {e}")
                    return False
            except requests.exceptions.RequestException as e:
                logger.warning(f"Telemetry: Request exception: {e}")
                if attempt < self.retry_attempts - 1:
                    # Exponential backoff
                    time.sleep(2 ** attempt)
                    continue
                else:
                    logger.warning(f"Telemetry: Failed to send telemetry batch after {self.retry_attempts} attempts: {e}")
                    return False
        
        return False

