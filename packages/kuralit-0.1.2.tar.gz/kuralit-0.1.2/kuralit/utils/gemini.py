"""Standalone Gemini utility functions for Kuralit."""

import json
from typing import Any, Dict, List, Optional, Union

from kuralit.utils.log import log_debug, log_error, log_info, log_warning

try:
    from google.genai.types import (
        FunctionDeclaration,
        Schema,
        Tool,
    )
    from google.genai.types import (
        Type as GeminiType,
    )
except ImportError:
    raise ImportError("`google-genai` not installed. Please install it using `pip install google-genai`")


def convert_schema(
    schema_dict: Dict[str, Any], root_schema: Optional[Dict[str, Any]] = None, visited_refs: Optional[set] = None
) -> Optional[Schema]:
    """
    Recursively convert a JSON-like schema dictionary to a types.Schema object.
    
    Based on Agno's implementation for proper Gemini SDK type conversion.
    
    Parameters:
        schema_dict (dict): The JSON schema dictionary with keys like "type", "description",
                            "properties", and "required".
        root_schema (dict, optional): The root schema containing $defs for resolving $ref
        visited_refs (set, optional): Set of visited $ref paths to detect circular references
    
    Returns:
        types.Schema: The converted schema.
    """
    # If this is the initial call, set root_schema to self and initialize visited_refs
    if root_schema is None:
        root_schema = schema_dict
    if visited_refs is None:
        visited_refs = set()

    # Handle $ref references with cycle detection
    if "$ref" in schema_dict:
        ref_path = schema_dict["$ref"]

        # Check for circular reference
        if ref_path in visited_refs:
            # Return a basic object schema to break the cycle
            return Schema(
                type=GeminiType.OBJECT,
                description=f"Circular reference to {ref_path}",
            )

        if ref_path.startswith("#/$defs/"):
            def_name = ref_path.split("/")[-1]
            if "$defs" in root_schema and def_name in root_schema["$defs"]:
                # Add to visited set before recursing
                new_visited = visited_refs.copy()
                new_visited.add(ref_path)

                referenced_schema = root_schema["$defs"][def_name]
                return convert_schema(referenced_schema, root_schema, new_visited)
        # If we can't resolve the reference, return None
        return None

    schema_type = schema_dict.get("type", "")
    if schema_type is None or schema_type == "null":
        return None
    description = schema_dict.get("description", None)
    default = schema_dict.get("default", None)

    # Handle enum types
    if "enum" in schema_dict:
        enum_values = schema_dict["enum"]
        return Schema(type=GeminiType.STRING, enum=enum_values, description=description, default=default)

    if schema_type == "object":
        # Handle regular objects with properties
        if "properties" in schema_dict:
            properties = {}
            for key, prop_def in schema_dict["properties"].items():
                # Process nullable types
                prop_type = prop_def.get("type", "")
                is_nullable = False
                if isinstance(prop_type, list) and "null" in prop_type:
                    prop_def["type"] = prop_type[0]
                    is_nullable = True

                # Process property schema (pass root_schema and visited_refs for $ref resolution)
                converted_schema = convert_schema(prop_def, root_schema, visited_refs)
                if converted_schema is not None:
                    if is_nullable:
                        converted_schema.nullable = True
                    properties[key] = converted_schema

            required = schema_dict.get("required", [])

            if properties:
                return Schema(
                    type=GeminiType.OBJECT,
                    properties=properties,
                    required=required,
                    description=description,
                    default=default,
                )
            else:
                return Schema(type=GeminiType.OBJECT, description=description, default=default)

        # Handle Dict types (objects with additionalProperties but no properties)
        elif "additionalProperties" in schema_dict:
            additional_props = schema_dict["additionalProperties"]

            # If additionalProperties is a schema object (Dict[str, T] case)
            if isinstance(additional_props, dict) and "type" in additional_props:
                # For Gemini, we need to represent Dict[str, T] as an object with at least one property
                # to avoid the "properties should be non-empty" error.
                # We'll create a generic property that represents the dictionary structure

                # Handle both single types and union types (arrays) from Zod schemas
                type_value = additional_props.get("type", "string")
                if isinstance(type_value, list):
                    value_type = type_value[0].upper() if type_value else "STRING"
                    union_types = ", ".join(type_value)
                    type_description_suffix = f" (supports union types: {union_types})"
                else:
                    # Single type
                    value_type = type_value.upper()
                    type_description_suffix = ""

                # Create a placeholder property to satisfy Gemini's requirements
                # This is a workaround since Gemini doesn't support additionalProperties directly
                placeholder_properties = {
                    "example_key": Schema(
                        type=value_type,
                        description=f"Example key-value pair. This object can contain any number of keys with {value_type.lower()} values{type_description_suffix}.",
                    )
                }
                if value_type == "ARRAY":
                    placeholder_properties["example_key"].items = {}  # type: ignore

                return Schema(
                    type=GeminiType.OBJECT,
                    properties=placeholder_properties,
                    description=description
                    or f"Dictionary with {value_type.lower()} values{type_description_suffix}. Can contain any number of key-value pairs.",
                    default=default,
                )
            else:
                # additionalProperties is false or true
                return Schema(type=GeminiType.OBJECT, description=description, default=default)

        # Handle empty objects
        else:
            return Schema(type=GeminiType.OBJECT, description=description, default=default)

    elif schema_type == "array" and "items" in schema_dict:
        if not schema_dict["items"]:  # Handle empty {}
            items = Schema(type=GeminiType.STRING)
        else:
            converted_items = convert_schema(schema_dict["items"], root_schema, visited_refs)
            items = converted_items if converted_items is not None else Schema(type=GeminiType.STRING)
        min_items = schema_dict.get("minItems")
        max_items = schema_dict.get("maxItems")
        return Schema(
            type=GeminiType.ARRAY,
            description=description,
            items=items,
            min_items=min_items,
            max_items=max_items,
        )

    elif schema_type == "string":
        schema_kwargs = {
            "type": GeminiType.STRING,
            "description": description,
            "default": default,
        }
        if "format" in schema_dict:
            schema_kwargs["format"] = schema_dict["format"]
        return Schema(**schema_kwargs)

    elif schema_type in ("integer", "number"):
        schema_kwargs = {
            "type": schema_type.upper(),
            "description": description,
            "default": default,
        }
        if "maximum" in schema_dict:
            schema_kwargs["maximum"] = schema_dict["maximum"]
        if "minimum" in schema_dict:
            schema_kwargs["minimum"] = schema_dict["minimum"]
        return Schema(**schema_kwargs)

    elif schema_type == "" and "anyOf" in schema_dict:
        any_of = []
        for sub_schema in schema_dict["anyOf"]:
            sub_schema_converted = convert_schema(sub_schema, root_schema, visited_refs)
            any_of.append(sub_schema_converted)

        is_nullable = False
        filtered_any_of = []

        for schema in any_of:
            if schema is None:
                is_nullable = True
            else:
                filtered_any_of.append(schema)

        any_of = filtered_any_of  # type: ignore
        if len(any_of) == 1 and any_of[0] is not None:
            any_of[0].nullable = is_nullable
            return any_of[0]
        else:
            return Schema(
                any_of=any_of,
                description=description,
                default=default,
            )
    else:
        if isinstance(schema_type, list):
            non_null_types = [t for t in schema_type if t != "null"]
            if non_null_types:
                schema_type = non_null_types[0]
            else:
                schema_type = ""
        # Only convert to uppercase if schema_type is not empty
        if schema_type:
            schema_type = schema_type.upper()
            return Schema(type=schema_type, description=description, default=default)
        else:
            # If we get here with an empty type and no other handlers matched,
            # something is wrong with the schema
            return None


def format_function_definitions(tools_list: List[Union[Dict, Any]]) -> Optional[Tool]:
    """Format function definitions for Gemini API using proper SDK types.
    
    Based on Agno's implementation for proper Gemini SDK type conversion.
    
    Args:
        tools_list: List of tool definitions (dicts or Function objects)
                   Can be in format:
                   - {"name": ..., "description": ..., "parameters": ...} (Kuralit format)
                   - {"type": "function", "function": {"name": ..., ...}} (Agno format)
        
    Returns:
        Tool object with FunctionDeclaration instances, or None if no valid tools
    """
    log_info(f"format_function_definitions: Processing {len(tools_list)} tools")
    function_declarations = []

    for i, tool in enumerate(tools_list):
        # Handle different tool formats
        if isinstance(tool, dict):
            # Check if it's Agno format: {"type": "function", "function": {...}}
            if tool.get("type") == "function":
                func_info = tool.get("function", {})
                name = func_info.get("name")
                description = func_info.get("description", "")
                parameters_dict = func_info.get("parameters", {})
                log_debug(f"format_function_definitions: Tool {i+1} - Agno format, name={name}")
            # Check if it's Kuralit format: {"name": ..., "description": ..., "parameters": ...}
            elif "name" in tool and "parameters" in tool:
                name = tool.get("name")
                description = tool.get("description", "")
                parameters_dict = tool.get("parameters", {})
                log_debug(f"format_function_definitions: Tool {i+1} - Kuralit format, name={name}")
            else:
                # Unknown format, skip
                log_warning(f"format_function_definitions: Tool {i+1} - Unknown format, skipping. Keys: {list(tool.keys()) if isinstance(tool, dict) else 'not a dict'}")
                continue
        else:
            # Assume it's a Function-like object with to_dict method
            func_def = tool.to_dict() if hasattr(tool, 'to_dict') else {}
            if not func_def or "name" not in func_def or "parameters" not in func_def:
                log_warning(f"format_function_definitions: Tool {i+1} - Cannot convert to dict or missing fields")
                continue
            name = func_def.get("name")
            description = func_def.get("description", "")
            parameters_dict = func_def.get("parameters", {})
            log_debug(f"format_function_definitions: Tool {i+1} - Function object, name={name}")

        # Skip if we don't have required fields
        if not name or not parameters_dict:
            log_warning(f"format_function_definitions: Tool {i+1} - Missing name or parameters, skipping")
            continue

        # Convert parameters schema to Gemini Schema object
        try:
            parameters_schema = convert_schema(parameters_dict)
            if parameters_schema is None:
                # Fallback to basic object schema if conversion fails
                log_warning(f"format_function_definitions: Tool {i+1} ({name}) - Schema conversion returned None, using fallback")
                parameters_schema = Schema(type=GeminiType.OBJECT, description="Function parameters")
            else:
                log_debug(f"format_function_definitions: Tool {i+1} ({name}) - Schema converted successfully")
        except Exception as e:
            log_error(f"format_function_definitions: Tool {i+1} ({name}) - Error converting schema: {e}")
            # Fallback to basic object schema
            parameters_schema = Schema(type=GeminiType.OBJECT, description="Function parameters")

        # Create a FunctionDeclaration instance using Gemini SDK types
        try:
            function_decl = FunctionDeclaration(
                name=name,
                description=description,
                parameters=parameters_schema,
            )
            function_declarations.append(function_decl)
            log_debug(f"format_function_definitions: Tool {i+1} ({name}) - FunctionDeclaration created successfully")
        except Exception as e:
            log_error(f"format_function_definitions: Tool {i+1} ({name}) - Error creating FunctionDeclaration: {e}")
            continue
    
    if function_declarations:
        try:
            tool_obj = Tool(function_declarations=function_declarations)
            log_info(f"format_function_definitions: Successfully created Tool object with {len(function_declarations)} FunctionDeclarations")
            log_debug(f"format_function_definitions: Tool object type: {type(tool_obj)}, has function_declarations: {hasattr(tool_obj, 'function_declarations')}")
            return tool_obj
        except Exception as e:
            log_error(f"format_function_definitions: Error creating Tool object: {e}")
            return None
    else:
        log_warning("format_function_definitions: No valid function declarations created")
        return None


def format_image_for_message(image: Any) -> Optional[Dict[str, Any]]:
    """Format an image for Gemini message.
    
    Args:
        image: Image object with content, url, or filepath
        
    Returns:
        Dictionary with mime_type and data, or None
    """
    if not image:
        return None
    
    # Try to get bytes
    image_bytes = None
    mime_type = "image/jpeg"  # Default
    
    if hasattr(image, 'get_content_bytes'):
        image_bytes = image.get_content_bytes()
    elif hasattr(image, 'content') and isinstance(image.content, bytes):
        image_bytes = image.content
    elif hasattr(image, 'filepath'):
        from pathlib import Path
        path = Path(image.filepath) if isinstance(image.filepath, str) else image.filepath
        if path.exists():
            image_bytes = path.read_bytes()
            # Try to determine mime type from extension
            ext = path.suffix.lower()
            mime_map = {
                '.jpg': 'image/jpeg',
                '.jpeg': 'image/jpeg',
                '.png': 'image/png',
                '.gif': 'image/gif',
                '.webp': 'image/webp',
            }
            mime_type = mime_map.get(ext, 'image/jpeg')
    
    if image_bytes:
        return {
            "mime_type": mime_type,
            "data": image_bytes
        }
    
    return None


def prepare_response_schema(response_format: Optional[Union[Dict, Any]]) -> Optional[Dict[str, Any]]:
    """Prepare response schema for Gemini.
    
    Args:
        response_format: Response format (dict or Pydantic model)
        
    Returns:
        Schema dict for Gemini, or None
    """
    if response_format is None:
        return None
    
    if isinstance(response_format, dict):
        return response_format
    
    # If it's a Pydantic model, get its schema
    if hasattr(response_format, 'model_json_schema'):
        return response_format.model_json_schema()
    
    return None

