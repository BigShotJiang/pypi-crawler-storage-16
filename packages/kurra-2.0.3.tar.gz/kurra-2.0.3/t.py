import re
from pathlib import Path

from typer.testing import CliRunner

from kurra.cli import app

runner = CliRunner()

sparql_endpoint = "http://localhost:3030/test/"
f = Path("/Users/nick/work/kurrawong/kurra/tests/test_cli/db/config.ttl")
TESTING_GRAPH = "https://example.com/testing-graph"

result = runner.invoke(
    app,
    [
        "db",
        "gsp",
        "get",
        #str(f),
        # "-g",
        # "https://example.com/testing-graph",
        # TESTING_GRAPH,
        sparql_endpoint,
    ],
)
print(result.stdout)

# from kurra.db.gsp import upload
#
# print(upload(sparql_endpoint, f))