__version__ = "1.6.3"
__version_info__ = tuple(int(i) for i in __version__.split("."))

# Database schema version for migration support
DB_SCHEMA_VERSION = "1.0"
