LEVEL_MAX_DEFAULT = 3

# Hook action types
ACTION_CREATE = "create"
ACTION_MODIFY = "modify"
ACTION_DELETE = "delete"
