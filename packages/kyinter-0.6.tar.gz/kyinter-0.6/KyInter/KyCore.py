class Position():
    def __init__(self, x: int, y: int) -> None:
        self.x = x
        self.y = y

class Size():
    def __init__(self, width: int, height: int) -> None:
        self.width = width
        self.height = height