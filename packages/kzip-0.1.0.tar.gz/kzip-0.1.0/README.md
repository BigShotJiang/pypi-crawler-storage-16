# kzip

![Zip Archiver Logo](https://img.shields.io/badge/kzip%20-v0.1.0-blue?style=for-the-badge&logo=python)  
[![PyPI version](https://badge.fury.io/py/kzip.svg)](https://badge.fury.io/py/kzip)  
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)  
[![Python Version](https://img.shields.io/badge/python-3.8%2B-blue.svg)](https://www.python.org/downloads/)  

A compact and easy-to-use Python library for archiving files and directories into ZIP files, as well as extracting ZIP archives. Built with standard Python libraries—no external dependencies required! 🚀

## Features ✨
- **Archive Files & Directories**: Recursively zip files or entire folders with customizable compression.
- **Extract ZIPs**: Easily unpack archives to any directory.
- **Lightweight**: Uses only `zipfile` and `os` from the standard library.
- **Flexible Compression**: Supports various ZIP compression methods (e.g., DEFLATED, STORED).
- **Cross-Platform**: Works on Windows, macOS, and Linux.

## Installation 📦
#### Install via pip from PyPI:

```bash
pip install kzip
```

## Quick Start ⚡
### Archiving Files
#### Create an instance of archiver and use the archive method:
```Python
from kzip import archiver

zip = archiver()  # Default compression: ZIP_DEFLATED

# Archive a file and a directory
zip.archive('my_archive.zip', ['example.txt', 'my_folder/'])
```
### Extracting Archives
#### Use the extract method to unpack:
```Python
from kzip import archiver

zip = archiver()

# Extract to current directory
zip.extract('my_archive.zip')

# Or to a specific folder
zip.extract('my_archive.zip', extract_to='output/')
```

### Custom Compression
#### Specify compression during initialization:
```Python
import zipfile
from kzip import archiver

zip = archiver(compression=zipfile.ZIP_STORED)  # No compression
zip.archive('fast_archive.zip', ['large_file.bin'])
```
## API Reference 📖
### Class: archiver
- `__init__(self, compression: int = zipfile.ZIP_DEFLATED)`: Initializes with optional compression type.
- `archive(self, zip_path: str, paths: list[str]) -> None`: Archives files/directories to a ZIP.
- `extract(self, zip_path: str, extract_to: str = '.') -> None`: Extracts ZIP to a directory.

## Error Handling ⚠️
Wrap calls in `try-except` for robustness:
```Python
try:
    archiver.archive('archive.zip', ['nonexistent.txt'])
except FileNotFoundError as e:
    print(f"Error: {e}")
```
## License 📄
This project is licensed under the MIT License - see the LICENSE file for details.