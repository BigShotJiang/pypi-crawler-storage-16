# A compact Python library for archiving and extracting ZIP files.
import zipfile
import os
class archiver:
    """
    A class for archiving and extracting ZIP files.
    """
    
    
        
    
    def archive(self, zip_path: str, paths: list[str]) -> None:
        """
        Archives files or directories into a ZIP file.
        
        :param zip_path: Path to the output ZIP file.
        :param paths: List of file or directory paths to archive.
        """
        with zipfile.ZipFile(zip_path, 'w', compression=self.compression) as zipf:
            for path in paths:
                if os.path.isdir(path):
                    for root, _, files in os.walk(path):
                        for file in files:
                            file_path = os.path.join(root, file)
                            arcname = os.path.relpath(file_path, os.path.dirname(path))
                            zipf.write(file_path, arcname)
                else:
                    zipf.write(path, os.path.basename(path))
    
    def __init__(self, compression: int = zipfile.ZIP_DEFLATED):
        """
        Initialize the archiver with optional compression type.
        
        :param compression: Compression type (default: ZIP_DEFLATED).
        """
        self.compression = compression
        
    
    def extract(self, zip_path: str, extract_to: str = '.') -> None:
        """
        Extracts a ZIP file to a directory.
        
        :param zip_path: Path to the input ZIP file.
        :param extract_to: Directory to extract to (default: current directory).
        """
        with zipfile.ZipFile(zip_path, 'r') as zipf:
            zipf.extractall(extract_to)