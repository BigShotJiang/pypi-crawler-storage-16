authorization_urls = dict(
    homologation='http://dfe.test.arba.gov.ar/DomicilioElectronico/SeguridadCliente/dfeServicioDescargaPadron.do',
    production='http://dfe.arba.gov.ar/DomicilioElectronico/SeguridadCliente/dfeServicioDescargaPadron.do',
)
