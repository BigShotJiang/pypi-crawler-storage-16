class LabelStudioXMLSyntaxErrorSentryIgnored(Exception):
    pass
