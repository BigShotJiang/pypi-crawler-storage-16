About
=====

.. todo:: Add brief history of the project

.. todo:: Add guiding principles

Development Team
++++++++++++++++

The *labscript suite* has been in active development for over 10 years and has had many developers and contributors.

Original Development Team (at Monash University)
------------------------------------------------

- Philip Starkey
- Chris Billington
- Shaun Johnstone
- Martijn Jasperse
- Russell Anderson

With supervision from:

- Prof. Kris Helmerson
- Dr. Lincoln Turner
- Dr. Russell Anderson

Current Core *labscript suite* Team
-----------------------------------

- Russell Anderson
- Chris Billington
- David Meyer
- Philip Starkey

Contributors
------------

- Daniel Barker
- Michael Doris
- Matt Earnshaw
- Mikhail Egorov
- Lars Kohfahl
- Rene Kolb
- Francisco Salces
- Ian Spielman
- Lincoln Turner
- Zak Vendeiro
- Jan Werkmann