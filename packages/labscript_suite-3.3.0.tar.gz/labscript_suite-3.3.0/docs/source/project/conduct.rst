Code of Conduct
===============

.. todo:: Adopt a code of conduct