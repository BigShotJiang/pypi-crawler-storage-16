from datetime import datetime
from typing import List

from dotenv import load_dotenv
from loguru import logger
from sqlalchemy import Boolean, Column, DateTime, Integer, String, and_, or_, select
from sqlalchemy.orm import Session, declarative_base

load_dotenv()

Base = declarative_base()


class Libertador(Base):
    __tablename__ = "libertador3"
    solicitud = Column(Integer, primary_key=True)
    fecha_radicacion = Column(DateTime)
    fecha_resultado = Column(DateTime)
    resultado = Column(String(50))
    destino = Column(String(50))
    tipo_persona = Column(String(30))
    ciudad = Column(String(50))
    direccion = Column(String(100))
    numero_inmobiliaria = Column(String(30))
    nombre_inquilino = Column(String(100))
    numero_inquilino = Column(String(30))
    nombre_asesor = Column(String(100))
    correo_asesor = Column(String(100))
    fecha_actualizacion = Column(DateTime)
    notified = Column(Boolean, nullable=False, default=False)
    documento_inquilino = Column(String(20))
    canon = Column(String(20))
    correo = Column(String(100))
    fecha_expedicion = Column(String(50))
    ingresos = Column(String(20))


class SoftsegurosAdvisorNotifications(Base):
    __tablename__ = "softseguros_advisor_notifications"
    solicitud = Column(Integer, primary_key=True)
    notified = Column(Boolean, nullable=False, default=False)


def insert_record(record: Libertador, session_: Session):
    with session_() as session:
        # Asegura tipos (evita marcar PK como cambiado por str vs int)
        record.solicitud = int(record.solicitud)
        try:
            record.fecha_expedicion = datetime.fromisoformat(record.fecha_expedicion.replace("T", " ")).date()
        except Exception:
            ...
        current: Libertador = session.get(Libertador, record.solicitud)
        if current:
            # actualiza SOLO campos no-PK
            current.fecha_radicacion = record.fecha_radicacion
            current.fecha_resultado = record.fecha_resultado
            current.resultado = record.resultado
            current.destino = record.destino
            current.tipo_persona = record.tipo_persona
            current.ciudad = record.ciudad
            current.direccion = record.direccion
            current.numero_inmobiliaria = record.numero_inmobiliaria
            current.nombre_inquilino = record.nombre_inquilino
            current.numero_inquilino = record.numero_inquilino
            current.nombre_asesor = record.nombre_asesor
            current.correo_asesor = record.correo_asesor
            current.fecha_actualizacion = record.fecha_actualizacion
            current.documento_inquilino = record.documento_inquilino
            current.canon = record.canon
            current.correo = record.correo
            current.fecha_expedicion = record.fecha_expedicion
            current.ingresos = record.ingresos
            logger.info(f"Registro actualizado -> solicitud:{record.solicitud}")
        else:
            session.add(record)  # INSERT (no intenta tocar el PK en UPDATE)
            logger.info(f"Registro insertado -> solicitud:{record.solicitud}")
        session.commit()


def select_record(solicitud: int, session_: Session):
    with session_() as session:
        stmt = select(Libertador).filter(and_(Libertador.solicitud == solicitud, Libertador.notified == False))
        record = session.scalars(statement=stmt).all()
        return record


def get_approved_records(session_: Session) -> List[Libertador]:
    with session_() as session:
        stmt = select(Libertador).filter(and_(Libertador.resultado == "APROBADA", Libertador.notified == False))
        records = session.scalars(statement=stmt).all()
        logger.info(f"Registros libertador aprobados: {len(records)=}")
        return records


def get_records_with_state_postponed(session_: Session) -> List[Libertador]:
    with session_() as session:
        stmt = select(Libertador).filter(or_(Libertador.resultado == "APLAZADO-NUBE", Libertador.resultado == "APLAZADA"))
        records = session.scalars(statement=stmt).all()
        return records


def update_state_solicitud(solicitud: int, state, session_: Session):
    with session_() as session:
        stmt = select(Libertador).filter(Libertador.solicitud == solicitud)
        record = session.scalars(statement=stmt).first()
        record.notified = state
        session.commit()
        logger.info(f"Registro actualizado -> {solicitud=}")
        return record


if __name__ == "__main__":
    # Base.metadata.create_all(engine_estrella)
    ...
