class GatewayTimeoutError(RuntimeError):
    pass

class OutputFormatNotSupported(Exception):
    pass
