#!/usr/bin/env python3
"""
Oscilloscope cursor control for both PicoScope and Rigol devices.

For Rigol: Uses VISA/SCPI commands via the Net/Mapper infrastructure
For PicoScope: Cursor control is not supported (use web visualization instead)
"""

import os
import json
import sys

# ANSI color codes
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
RESET = '\033[0m'

# Constants
LOCAL_NETS_PATH = "/etc/lager/saved_nets.json"


def load_saved_nets():
    """Load nets from the saved nets file."""
    try:
        with open(LOCAL_NETS_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return []
    except Exception as e:
        print(f"{RED}Error loading saved nets: {e}{RESET}", file=sys.stderr)
        return []


def get_net_info(netname):
    """Get net info by name from saved nets."""
    nets = load_saved_nets()
    for net in nets:
        if net.get("name") == netname and net.get("role") == "scope":
            return net
    return None


def is_picoscope(net_info):
    """Check if the net is a PicoScope based on instrument name."""
    if not net_info:
        return False
    instrument = net_info.get("instrument", "").lower()
    return "pico" in instrument or "picoscope" in instrument


def is_rigol(net_info):
    """Check if the net is a Rigol oscilloscope."""
    if not net_info:
        return False
    instrument = net_info.get("instrument", "").lower()
    return "rigol" in instrument or "mso" in instrument


def get_rigol_net(netname):
    """Get a Rigol Net object using Net.get()."""
    from lager.pcb.net import Net
    from lager.pcb.constants import NetType

    net = Net.get(netname, NetType.Analog)
    return net


# ============ Cursor functions (Rigol only) ============

def set_cursor_a(netname, x, y):
    """Set cursor A position."""
    net = get_rigol_net(netname)
    net.cursor.set_a(x=x, y=y)
    print(f"{GREEN}Cursor A set{RESET}")


def set_cursor_b(netname, x, y):
    """Set cursor B position."""
    net = get_rigol_net(netname)
    net.cursor.set_b(x=x, y=y)
    print(f"{GREEN}Cursor B set{RESET}")


def move_cursor_a(netname, del_x, del_y):
    """Move cursor A by delta."""
    net = get_rigol_net(netname)
    net.cursor.move_a(x_del=del_x, y_del=del_y)
    print(f"{GREEN}Cursor A moved{RESET}")


def move_cursor_b(netname, del_x, del_y):
    """Move cursor B by delta."""
    net = get_rigol_net(netname)
    net.cursor.move_b(x_del=del_x, y_del=del_y)
    print(f"{GREEN}Cursor B moved{RESET}")


def hide_cursor(netname):
    """Hide the cursors."""
    net = get_rigol_net(netname)
    net.cursor.hide()
    print(f"{GREEN}Cursors hidden{RESET}")


def main():
    command = json.loads(os.environ.get('LAGER_COMMAND_DATA', '{}'))
    action = command.get('action', '')
    params = command.get('params', {})
    netname = params.get('netname')

    if not netname:
        print(f"{RED}No netname provided{RESET}", file=sys.stderr)
        sys.exit(1)

    # Check if it's a PicoScope - cursor control not supported
    net_info = get_net_info(netname)
    if is_picoscope(net_info):
        print(f"{YELLOW}Cursor control is not supported for PicoScope devices.{RESET}")
        print(f"{YELLOW}Use the web visualization for cursor measurements.{RESET}")
        sys.exit(0)

    # Rigol cursor operations
    try:
        if action == 'set_a':
            set_cursor_a(**params)
        elif action == 'move_a':
            move_cursor_a(**params)
        elif action == 'set_b':
            set_cursor_b(**params)
        elif action == 'move_b':
            move_cursor_b(**params)
        elif action == 'hide_cursor':
            hide_cursor(**params)
        else:
            print(f"{RED}Unknown action: {action}{RESET}", file=sys.stderr)
            sys.exit(1)
    except Exception as e:
        print(f"{RED}Error: {e}{RESET}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
