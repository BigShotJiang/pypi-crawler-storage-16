#!/usr/bin/env python3
"""
Oscilloscope trigger configuration for both PicoScope and Rigol devices.

For Rigol: Uses VISA/SCPI commands via the Net/Mapper infrastructure
For PicoScope: Uses WebSocket commands to the oscilloscope-daemon
"""

import os
import json
import sys
import asyncio

# ANSI color codes
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
RESET = '\033[0m'

# Constants
LOCAL_NETS_PATH = "/etc/lager/saved_nets.json"
DAEMON_HOST = "localhost"
DAEMON_COMMAND_PORT = 8085


def load_saved_nets():
    """Load nets from the saved nets file."""
    try:
        with open(LOCAL_NETS_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return []
    except Exception as e:
        print(f"{RED}Error loading saved nets: {e}{RESET}", file=sys.stderr)
        return []


def get_net_info(netname):
    """Get net info by name from saved nets."""
    nets = load_saved_nets()
    for net in nets:
        if net.get("name") == netname and net.get("role") == "scope":
            return net
    return None


def is_picoscope(net_info):
    """Check if the net is a PicoScope based on instrument name."""
    if not net_info:
        return False
    instrument = net_info.get("instrument", "").lower()
    return "pico" in instrument or "picoscope" in instrument


def is_rigol(net_info):
    """Check if the net is a Rigol oscilloscope."""
    if not net_info:
        return False
    instrument = net_info.get("instrument", "").lower()
    return "rigol" in instrument or "mso" in instrument


# ============ PicoScope trigger via WebSocket ============

def send_command_pico(command: dict) -> dict:
    """Send a command to the PicoScope daemon via WebSocket."""
    try:
        import websockets
    except ImportError:
        return {"error": "websockets library not installed"}

    async def send_async():
        uri = f"ws://{DAEMON_HOST}:{DAEMON_COMMAND_PORT}"
        try:
            async with websockets.connect(uri, close_timeout=5) as ws:
                await ws.send(json.dumps(command))
                response = await asyncio.wait_for(ws.recv(), timeout=10.0)
                return json.loads(response)
        except ConnectionRefusedError:
            return {"error": "Oscilloscope daemon not running"}
        except asyncio.TimeoutError:
            return {"error": "Timeout waiting for daemon response"}
        except Exception as e:
            return {"error": f"Communication error: {str(e)}"}

    return asyncio.get_event_loop().run_until_complete(send_async())


def trigger_edge_pico(netname, mode, coupling, source, slope, level):
    """Configure edge trigger for PicoScope."""
    errors = []

    # Set trigger mode
    if mode:
        response = send_command_pico({
            "command": "SetCaptureMode",
            "capture_mode": mode.lower()
        })
        if "error" in response:
            errors.append(f"mode: {response['error']}")

    # Set trigger level
    if level is not None:
        response = send_command_pico({
            "command": "SetTriggerLevel",
            "trigger_level": level
        })
        if "error" in response:
            errors.append(f"level: {response['error']}")

    # Set trigger slope
    if slope:
        slope_map = {"rising": "rising", "falling": "falling", "both": "either"}
        response = send_command_pico({
            "command": "SetTriggerSlope",
            "trigger_slope": slope_map.get(slope.lower(), "rising")
        })
        if "error" in response:
            errors.append(f"slope: {response['error']}")

    if errors:
        print(f"{YELLOW}Some settings could not be applied: {'; '.join(errors)}{RESET}")
    else:
        print(f"{GREEN}Trigger configured successfully{RESET}")


# ============ Rigol trigger via VISA ============

def get_rigol_net(netname):
    """Get a Rigol Net object using Net.get()."""
    from lager.pcb.net import Net
    from lager.pcb.constants import NetType

    net = Net.get(netname, NetType.Analog)
    return net


def get_source_net(source_name):
    """Get source net if specified."""
    if not source_name:
        return None
    from lager.pcb.net import Net
    from lager.pcb.constants import NetType
    return Net.get(source_name, NetType.Analog)


def trigger_uart(netname, mode, coupling, source, level, trigger_on, parity, stop_bits, baud, data_width, data):
    target_net = get_rigol_net(netname)
    target_net.enable()
    source_net = get_source_net(source)
    if source_net:
        source_net.enable()

    if mode.lower() == "auto":
        target_net.trigger_settings.set_mode_auto()
    elif mode.lower() == "normal":
        target_net.trigger_settings.set_mode_normal()
    elif mode.lower() == "single":
        target_net.trigger_settings.set_mode_single()
    else:
        raise Exception(f"{mode} is not a valid option")

    if coupling.lower() == "dc":
        target_net.trigger_settings.set_coupling_DC()
    elif coupling.lower() == "ac":
        target_net.trigger_settings.set_coupling_AC()
    elif coupling.lower() == "hp_filt":
        target_net.trigger_settings.set_coupling_low_freq_reject()
    elif coupling.lower() == "lp_filt":
        target_net.trigger_settings.set_coupling_high_freq_reject()
    else:
        raise Exception(f"{coupling} type is not a valid option")

    from lager.pcb.defines import TriggerType, TriggerUARTParity
    target_net.trigger_settings.set_type(TriggerType.UART)

    if source_net:
        target_net.trigger_settings.uart.set_source(source_net)

    if level is not None:
        target_net.trigger_settings.uart.set_level(level)

    trig_parity = None
    if parity:
        if parity.lower() == "even":
            trig_parity = TriggerUARTParity.Even
        elif parity.lower() == "odd":
            trig_parity = TriggerUARTParity.Odd
        elif parity.lower() == "none":
            trig_parity = TriggerUARTParity.NoParity
        else:
            raise Exception(f"{parity} is not a valid option")
    target_net.trigger_settings.uart.set_uart_params(parity=trig_parity, stopbits=stop_bits, baud=baud, bits=data_width)

    if trigger_on:
        if trigger_on.lower() == "start":
            target_net.trigger_settings.uart.set_trigger_on_start()
        elif trigger_on.lower() == "error":
            target_net.trigger_settings.uart.set_trigger_on_error()
        elif trigger_on.lower() == "cerror":
            target_net.trigger_settings.uart.set_trigger_on_cerror()
        elif trigger_on.lower() == "data":
            target_net.trigger_settings.uart.set_trigger_on_data(data=data)
        else:
            raise Exception(f"{trigger_on} type is not a valid option")

    print(f"{GREEN}UART trigger configured{RESET}")


def trigger_edge(netname, mode, coupling, source, level, slope):
    target_net = get_rigol_net(netname)
    target_net.enable()
    source_net = get_source_net(source)
    if source_net:
        source_net.enable()

    if mode.lower() == "auto":
        target_net.trigger_settings.set_mode_auto()
    elif mode.lower() == "normal":
        target_net.trigger_settings.set_mode_normal()
    elif mode.lower() == "single":
        target_net.trigger_settings.set_mode_single()
    else:
        raise Exception(f"{mode} is not a valid option")

    if coupling.lower() == "dc":
        target_net.trigger_settings.set_coupling_DC()
    elif coupling.lower() == "ac":
        target_net.trigger_settings.set_coupling_AC()
    elif coupling.lower() == "hp_filt":
        target_net.trigger_settings.set_coupling_low_freq_reject()
    elif coupling.lower() == "lp_filt":
        target_net.trigger_settings.set_coupling_high_freq_reject()
    else:
        raise Exception(f"{coupling} is not a valid option")

    from lager.pcb.defines import TriggerType
    target_net.trigger_settings.set_type(TriggerType.Edge)
    if source_net:
        target_net.trigger_settings.edge.set_source(source_net)

    if level is not None:
        target_net.trigger_settings.edge.set_level(level)
    if slope:
        if slope.lower() == "rising":
            target_net.trigger_settings.edge.set_slope_rising()
        elif slope.lower() == "falling":
            target_net.trigger_settings.edge.set_slope_falling()
        elif slope.lower() == "both":
            target_net.trigger_settings.edge.set_slope_both()
        else:
            raise Exception(f"{slope} is not a valid option")

    print(f"{GREEN}Edge trigger configured{RESET}")


def trigger_pulse(netname, mode, coupling, source, level, trigger_on, upper, lower):
    target_net = get_rigol_net(netname)
    target_net.enable()
    source_net = get_source_net(source)
    if source_net:
        source_net.enable()

    if mode.lower() == "auto":
        target_net.trigger_settings.set_mode_auto()
    elif mode.lower() == "normal":
        target_net.trigger_settings.set_mode_normal()
    elif mode.lower() == "single":
        target_net.trigger_settings.set_mode_single()
    else:
        raise Exception(f"{mode} is not a valid option")

    if coupling.lower() == "dc":
        target_net.trigger_settings.set_coupling_DC()
    elif coupling.lower() == "ac":
        target_net.trigger_settings.set_coupling_AC()
    elif coupling.lower() == "hp_filt":
        target_net.trigger_settings.set_coupling_low_freq_reject()
    elif coupling.lower() == "lp_filt":
        target_net.trigger_settings.set_coupling_high_freq_reject()
    else:
        raise Exception(f"{coupling} is not a valid option")

    from lager.pcb.defines import TriggerType
    target_net.trigger_settings.set_type(TriggerType.Pulse)

    if source_net:
        target_net.trigger_settings.pulse.set_source(source_net)

    if level is not None:
        target_net.trigger_settings.pulse.set_level(level)

    if trigger_on:
        if trigger_on.lower() == "gt":
            target_net.trigger_settings.pulse.set_trigger_on_pulse_greater_than_width(lower)
        elif trigger_on.lower() == "lt":
            target_net.trigger_settings.pulse.set_trigger_on_pulse_less_than_width(upper)
        elif trigger_on.lower() == "gtlt":
            target_net.trigger_settings.pulse.set_trigger_on_pulse_less_than_greater_than(max_pulse_width=upper, min_pulse_width=lower)
        else:
            raise Exception(f"{target_net} is not a valid option")

    print(f"{GREEN}Pulse trigger configured{RESET}")


def trigger_i2c(netname, mode, coupling, source_scl, level_scl, source_sda, level_sda, trigger_on, address, addr_width, data, data_width, direction):
    target_net = get_rigol_net(netname)
    target_net.enable()

    source_scl_net = get_source_net(source_scl)
    if source_scl_net:
        source_scl_net.enable()

    source_sda_net = get_source_net(source_sda)
    if source_sda_net:
        source_sda_net.enable()

    if mode.lower() == "auto":
        target_net.trigger_settings.set_mode_auto()
    elif mode.lower() == "normal":
        target_net.trigger_settings.set_mode_normal()
    elif mode.lower() == "single":
        target_net.trigger_settings.set_mode_single()
    else:
        raise Exception(f"{mode} is not a valid option")

    if coupling.lower() == "dc":
        target_net.trigger_settings.set_coupling_DC()
    elif coupling.lower() == "ac":
        target_net.trigger_settings.set_coupling_AC()
    elif coupling.lower() == "hp_filt":
        target_net.trigger_settings.set_coupling_low_freq_reject()
    elif coupling.lower() == "lp_filt":
        target_net.trigger_settings.set_coupling_high_freq_reject()
    else:
        raise Exception(f"{coupling} is not a valid option")

    from lager.pcb.defines import TriggerType, TriggerI2CDirection
    target_net.trigger_settings.set_type(TriggerType.I2C)

    target_net.trigger_settings.i2c.set_source(net_scl=source_scl_net, net_sda=source_sda_net)

    if level_scl is not None:
        target_net.trigger_settings.i2c.set_scl_trigger_level(level_scl)

    if level_sda is not None:
        target_net.trigger_settings.i2c.set_sda_trigger_level(level_sda)

    if direction:
        if direction == 'write':
            direction = TriggerI2CDirection.Write
        elif direction == 'read':
            direction = TriggerI2CDirection.Read
        elif direction == 'rw':
            direction = TriggerI2CDirection.RW
        else:
            raise Exception(f"{direction} is not a valid option")

    if trigger_on:
        if trigger_on.lower() == "start":
            target_net.trigger_settings.i2c.set_trigger_on_start()
        elif trigger_on.lower() == "restart":
            target_net.trigger_settings.i2c.set_trigger_on_restart()
        elif trigger_on.lower() == "stop":
            target_net.trigger_settings.i2c.set_trigger_on_stop()
        elif trigger_on.lower() == "nack":
            target_net.trigger_settings.i2c.set_trigger_on_nack()
        elif trigger_on.lower() == "address":
            target_net.trigger_settings.i2c.set_trigger_on_address(bits=addr_width, direction=direction, address=address)
        elif trigger_on.lower() == "data":
            target_net.trigger_settings.i2c.set_trigger_on_data(width=data_width, data=data)
        elif trigger_on.lower() == "addr_data":
            target_net.trigger_settings.i2c.set_trigger_on_addr_data(bits=addr_width, direction=direction, address=address, width=data_width, data=data)
        else:
            raise Exception(f"{trigger_on} is not a valid option")

    print(f"{GREEN}I2C trigger configured{RESET}")


def trigger_spi(netname, mode, coupling, source_mosi_miso, source_sck, source_cs, level_mosi_miso, level_sck, level_cs, data, data_width, clk_slope, trigger_on, cs_idle, timeout):
    target_net = get_rigol_net(netname)
    target_net.enable()

    source_mosi_miso_net = get_source_net(source_mosi_miso)
    if source_mosi_miso_net:
        source_mosi_miso_net.enable()

    source_sck_net = get_source_net(source_sck)
    if source_sck_net:
        source_sck_net.enable()

    source_cs_net = get_source_net(source_cs)
    if source_cs_net:
        source_cs_net.enable()

    if mode.lower() == "auto":
        target_net.trigger_settings.set_mode_auto()
    elif mode.lower() == "normal":
        target_net.trigger_settings.set_mode_normal()
    elif mode.lower() == "single":
        target_net.trigger_settings.set_mode_single()
    else:
        raise Exception(f"{mode} is not a valid option")

    if coupling.lower() == "dc":
        target_net.trigger_settings.set_coupling_DC()
    elif coupling.lower() == "ac":
        target_net.trigger_settings.set_coupling_AC()
    elif coupling.lower() == "hp_filt":
        target_net.trigger_settings.set_coupling_low_freq_reject()
    elif coupling.lower() == "lp_filt":
        target_net.trigger_settings.set_coupling_high_freq_reject()
    else:
        raise Exception(f"{coupling} is not a valid option")

    from lager.pcb.defines import TriggerType
    target_net.trigger_settings.set_type(TriggerType.SPI)
    target_net.trigger_settings.spi.set_source(net_sck=source_sck_net, net_mosi_miso=source_mosi_miso_net, net_cs=source_cs_net)

    if level_mosi_miso is not None:
        target_net.trigger_settings.spi.set_mosi_miso_trigger_level(level_mosi_miso)

    if level_sck is not None:
        target_net.trigger_settings.spi.set_sck_trigger_level(level_sck)

    if level_cs is not None:
        target_net.trigger_settings.spi.set_cs_trigger_level(level_cs)

    target_net.trigger_settings.spi.set_trigger_data(bits=data_width, data=data)

    if clk_slope:
        if clk_slope.lower() == "positive":
            target_net.trigger_settings.spi.set_clk_edge_positive()
        elif clk_slope.lower() == "negative":
            target_net.trigger_settings.spi.set_clk_edge_negative()

    if trigger_on:
        if trigger_on.lower() == "timeout":
            if timeout is not None:
                target_net.trigger_settings.spi.set_trigger_on_timeout(timeout)
        elif trigger_on.lower() == "cs":
            if cs_idle:
                if cs_idle.lower() == "high":
                    target_net.trigger_settings.spi.set_trigger_on_cs_low()
                elif cs_idle.lower() == "low":
                    target_net.trigger_settings.spi.set_trigger_on_cs_high()
                else:
                    raise Exception(f"{cs_idle} is not a valid option")
        else:
            raise Exception(f"{trigger_on} is not a valid option")

    print(f"{GREEN}SPI trigger configured{RESET}")


def main():
    command = json.loads(os.environ.get('LAGER_COMMAND_DATA', '{}'))
    action = command.get('action', '')
    params = command.get('params', {})
    netname = params.get('netname')

    if not netname:
        print(f"{RED}No netname provided{RESET}", file=sys.stderr)
        sys.exit(1)

    # Check if it's a PicoScope
    net_info = get_net_info(netname)
    if is_picoscope(net_info):
        # Only edge trigger is supported for PicoScope
        if action == 'trigger_edge':
            trigger_edge_pico(
                netname,
                params.get('mode', 'auto'),
                params.get('coupling', 'dc'),
                params.get('source'),
                params.get('slope'),
                params.get('level')
            )
        else:
            print(f"{YELLOW}Only edge trigger is supported for PicoScope.{RESET}")
            print(f"{YELLOW}Use: lager scope {netname} trigger edge --slope rising --level 0{RESET}")
        sys.exit(0)

    # Rigol trigger configuration
    try:
        if action == 'trigger_uart':
            trigger_uart(**params)
        elif action == 'trigger_edge':
            trigger_edge(
                params.get('netname'),
                params.get('mode', 'normal'),
                params.get('coupling', 'dc'),
                params.get('source'),
                params.get('level'),
                params.get('slope')
            )
        elif action == 'trigger_i2c':
            trigger_i2c(**params)
        elif action == 'trigger_spi':
            trigger_spi(**params)
        elif action == 'trigger_pulse':
            trigger_pulse(**params)
        else:
            print(f"{RED}Unknown action: {action}{RESET}", file=sys.stderr)
            sys.exit(1)
    except Exception as e:
        print(f"{RED}Error: {e}{RESET}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
