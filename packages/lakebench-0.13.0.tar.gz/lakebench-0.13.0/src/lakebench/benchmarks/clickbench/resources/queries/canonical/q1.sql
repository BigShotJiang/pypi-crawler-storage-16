SELECT
    COUNT(*)
FROM
    hits;