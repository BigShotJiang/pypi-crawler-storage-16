SELECT
    UserID,
    SearchPhrase,
    COUNT(*)
FROM
    hits
GROUP BY
    UserID,
    SearchPhrase
ORDER BY
    COUNT(*) DESC
LIMIT
    10;