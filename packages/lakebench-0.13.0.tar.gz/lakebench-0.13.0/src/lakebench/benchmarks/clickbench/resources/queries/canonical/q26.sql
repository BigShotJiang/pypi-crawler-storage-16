SELECT
    SearchPhrase
FROM
    hits
WHERE
    SearchPhrase <> ''
ORDER BY
    SearchPhrase
LIMIT
    10;