SELECT
    MIN(EventDate),
    MAX(EventDate)
FROM
    hits;