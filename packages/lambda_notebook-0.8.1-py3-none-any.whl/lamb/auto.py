# convenience module: lets you set up the standard lambda notebook kernel
# infrastructure with `import lamb.auto`
import lamb.lnsetup
lamb.lnsetup.ipython_setup()
