#!/usr/bin/env python3
import sys
import lamb.lnsetup

if __name__ == "__main__":
    lamb.lnsetup.launch_lambda_console(sys.argv)
