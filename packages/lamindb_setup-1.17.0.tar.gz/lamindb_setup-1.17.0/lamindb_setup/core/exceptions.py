from lamindb_setup.errors import DefaultMessageException  # backwards compatibility
