"""Integration tests for agent middleware."""
