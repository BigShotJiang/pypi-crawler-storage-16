from langchain_community.document_loaders import SQLDatabaseLoader


class CrateDBLoader(SQLDatabaseLoader):
    pass
