"""Chain that interprets a prompt and **executes python code to do math**.

Heavily borrowed from `llm_math`, uses the [SymPy](https://www.sympy.org/) package.
"""
