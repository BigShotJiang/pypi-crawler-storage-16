# flake8: noqa

# For backwards compatibility.
from langchain_classic.agents.openai_assistant.base import (
    OpenAIAssistantAction,
    OpenAIAssistantFinish,
    OpenAIAssistantRunnable,
)
