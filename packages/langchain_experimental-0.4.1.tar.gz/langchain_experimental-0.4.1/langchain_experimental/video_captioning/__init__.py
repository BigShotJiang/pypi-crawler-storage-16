from langchain_experimental.video_captioning.base import VideoCaptioningChain

__all__ = ["VideoCaptioningChain"]
