"""Scripts for Ollama partner integration."""
