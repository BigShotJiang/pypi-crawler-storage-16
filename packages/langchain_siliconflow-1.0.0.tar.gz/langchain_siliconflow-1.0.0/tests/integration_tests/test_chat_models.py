"""Test ChatSiliconFlow chat model."""

from typing import Type

from langchain_tests.integration_tests import ChatModelIntegrationTests

from langchain_siliconflow.chat_models import ChatSiliconFlow


class TestChatChatSiliconFlowIntegration(ChatModelIntegrationTests):
    @property
    def chat_model_class(self) -> Type[ChatSiliconFlow]:
        return ChatSiliconFlow

    @property
    def chat_model_params(self) -> dict:
        # These should be parameters used to initialize your integration for testing
        return {"model": "deepseek-ai/DeepSeek-V3.1", "temperature": 0}
