"""LangChain integration for SQL Server."""

from langchain_sqlserver.vectorstores import SQLServer_VectorStore

__all__ = [
    "SQLServer_VectorStore",
]
