"""Database module for trigger operations."""

from .interface import TriggerDatabaseInterface

__all__ = ["TriggerDatabaseInterface"]
