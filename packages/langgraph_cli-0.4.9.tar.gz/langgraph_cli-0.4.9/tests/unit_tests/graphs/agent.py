from langgraph.func import entrypoint


@entrypoint()
def graph(state):
    return None
