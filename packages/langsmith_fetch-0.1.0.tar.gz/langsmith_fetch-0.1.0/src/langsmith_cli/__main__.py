"""Entry point for python -m langsmith_cli."""

from .cli import main

if __name__ == "__main__":
    main()
