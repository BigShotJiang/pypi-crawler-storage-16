#!/usr/bin/env python3
"""Quick test of the API call."""
import os
import json
import requests

import sys

api_key = os.environ.get('LANGSMITH_API_KEY')
if len(sys.argv) > 1:
    project_uuid = sys.argv[1]
else:
    project_uuid = "80f1ecb3-a16b-411e-97ae-1c89adbb5c49"  # Default from README

headers = {
    "X-API-Key": api_key,
    "Content-Type": "application/json"
}

url = "https://api.smith.langchain.com/runs/query"
body = {
    "session": [project_uuid],
    "is_root": True
}

print(f"Making request to: {url}")
print(f"Body: {json.dumps(body, indent=2)}")
print(f"API Key: {api_key[:10]}...")

response = requests.post(url, headers=headers, data=json.dumps(body))

print(f"\nStatus: {response.status_code}")
print(f"Response: {response.text[:500]}")

if response.status_code == 200:
    data = response.json()
    runs = data.get('runs', [])
    print(f"\nFound {len(runs)} runs")
    if runs:
        print(f"First run keys: {runs[0].keys()}")
