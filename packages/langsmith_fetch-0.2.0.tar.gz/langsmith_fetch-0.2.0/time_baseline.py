#!/usr/bin/env python3
"""Baseline timing test for trace fetching."""
import time
import subprocess
import sys

def time_command(cmd, description):
    """Time a command and return the duration."""
    print(f"\n{description}")
    print(f"Command: {' '.join(cmd)}")
    print("-" * 60)

    start = time.perf_counter()
    result = subprocess.run(cmd, capture_output=True, text=True)
    duration = time.perf_counter() - start

    if result.returncode != 0:
        print(f"ERROR: Command failed")
        print(f"stderr: {result.stderr}")
        return None

    # Count traces in output
    trace_count = result.stdout.count('"trace_id":')

    print(f"Duration: {duration:.3f}s")
    print(f"Traces fetched: {trace_count}")
    if trace_count > 0:
        print(f"Average per trace: {duration/trace_count:.3f}s")

    return duration

# Test cases
tests = [
    {
        "cmd": ["uv", "run", "langsmith-fetch", "traces",
                "--project-uuid", "51bd3779-bede-4f6d-9461-292e58d4b1a6",
                "--limit", "1", "--format", "raw"],
        "desc": "Fetching 1 trace"
    },
    {
        "cmd": ["uv", "run", "langsmith-fetch", "traces",
                "--project-uuid", "51bd3779-bede-4f6d-9461-292e58d4b1a6",
                "--limit", "5", "--format", "raw"],
        "desc": "Fetching 5 traces"
    },
    {
        "cmd": ["uv", "run", "langsmith-fetch", "traces",
                "--project-uuid", "51bd3779-bede-4f6d-9461-292e58d4b1a6",
                "--limit", "10", "--format", "raw"],
        "desc": "Fetching 10 traces"
    }
]

print("=" * 60)
print("BASELINE TIMING TEST")
print("=" * 60)

results = []
for test in tests:
    duration = time_command(test["cmd"], test["desc"])
    if duration:
        results.append((test["desc"], duration))
    time.sleep(0.5)  # Small delay between tests

print("\n" + "=" * 60)
print("SUMMARY")
print("=" * 60)
for desc, duration in results:
    print(f"{desc:30s}: {duration:.3f}s")
