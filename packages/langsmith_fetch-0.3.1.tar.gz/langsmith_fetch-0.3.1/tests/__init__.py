"""Tests for langsmith-fetch CLI."""
