# Language Detector

Detector de lenguajes de programación para directorios.

## Instalación

```bash
pip install code-analyzer
```

## Uso

```bash
code-analyzer ./mi_proyecto
```

Guardar en JSON:
```bash
code-analyzer ./mi_proyecto -o resultados.json
```

## Como librería

```python
from code_analyzer import LanguageDetector

detector = LanguageDetector("./mi_proyecto")
results = detector.analyze_directory()
```
