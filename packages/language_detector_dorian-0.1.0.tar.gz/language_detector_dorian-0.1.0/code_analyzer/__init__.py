"""Language Detector"""

from .analyzer import LanguageDetector

__all__ = ["LanguageDetector"]
