"""Interfaz de línea de comandos"""

import argparse
import json
import sys
from .analyzer import LanguageDetector


def main():
    parser = argparse.ArgumentParser(description="Detector de lenguajes de programación")
    parser.add_argument("path", help="Ruta del directorio")
    parser.add_argument("-o", "--output", help="Archivo JSON de salida", default=None)
    
    args = parser.parse_args()
    
    try:
        detector = LanguageDetector(args.path)
        results = detector.analyze_directory()
        
        print(json.dumps(results, indent=2, ensure_ascii=False))
        
        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                json.dump(results, f, indent=2, ensure_ascii=False)
        
        return 0
    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
