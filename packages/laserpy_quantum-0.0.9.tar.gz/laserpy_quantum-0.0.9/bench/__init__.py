""" Benchmark for LaserPy """

# No need .py
# python -m bench.bench_<package name>

from .benchmark import benchmark

# bench_Laser 1e-8: Moving Average time (min): 116.071001 ms
# bench_Laser 1e-7: Moving Average time (min): 910.125190 ms