"""
latency-audit: HFT-grade Linux infrastructure validator.

This package provides tools to audit Linux systems against
Tier 1 High-Frequency Trading latency standards.
"""

__version__ = "0.1.0"
