from .table import latex_table
from .image import latex_image
