from .tables import latexTable
from .images import latexImage
from .wrap import wrapLatex

__all__ = ['latexTable', 'latexImage', 'wrapLatex']
