def latexImage(image):
    return "\\includegraphics[width=\\textwidth]{" + image + "}"
