from .main import cli_main

cli_main()
