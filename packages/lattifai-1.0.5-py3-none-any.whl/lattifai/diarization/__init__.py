"""Speaker diarization module for LattifAI."""

from .lattifai import LattifAIDiarizer

__all__ = ["LattifAIDiarizer"]
