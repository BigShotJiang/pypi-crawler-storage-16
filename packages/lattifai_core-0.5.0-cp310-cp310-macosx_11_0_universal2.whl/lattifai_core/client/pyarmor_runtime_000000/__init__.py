# Pyarmor 9.2.2 (trial), 000000, 2025-12-13T07:27:46.502801
from .pyarmor_runtime import __pyarmor__
