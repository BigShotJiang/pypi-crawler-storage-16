# Pyarmor 9.2.2 (trial), 000000, 2025-12-13T15:53:08.261555
from .pyarmor_runtime import __pyarmor__
