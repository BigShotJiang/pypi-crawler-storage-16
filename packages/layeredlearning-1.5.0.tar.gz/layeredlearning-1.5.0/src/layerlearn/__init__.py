# here is the package imports
from .flexiblestacked import FlexibleStackedClassifier
from .flexiblestacked import FlexibleStackedRegressor

# here is the version of the package
__version__ = "1.5.0"