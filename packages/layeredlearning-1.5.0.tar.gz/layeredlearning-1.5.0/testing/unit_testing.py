import unittest
import numpy as np
from sklearn.datasets import make_regression
from sklearn.exceptions import NotFittedError

try:
    from layerlearn.baseLR import (
        LinearForestRegressor,
        LinearSupportRegressor,
        LinearDecisionRegressor,
        LinearKNNRegressor,
        LinearXGboostRegressor,
        LinearCatboostRegressor,
        LinearGradientBoostingRegressor,
        LinearAdaBoostRegressor,
        LinearLightGBMRegressor
    )
except ImportError:
    # Fallback if testing in the same file or different structure
    # You might need to paste your classes here or fix the import path
    print("Could not import modules from src.layerlearn.models. Please check your file structure.")
    raise

class TestLayeredLearning(unittest.TestCase):

    def setUp(self):
        # Create a synthetic regression dataset
        # 100 samples, 10 features, noise included
        self.X, self.y = make_regression(n_samples=100, n_features=10, noise=0.1, random_state=42)
        
        # List of all classes to test
        self.model_classes = [
            LinearForestRegressor,
            LinearSupportRegressor,
            LinearDecisionRegressor,
            LinearKNNRegressor,
            LinearXGboostRegressor,
            LinearCatboostRegressor,
            LinearGradientBoostingRegressor,
            LinearAdaBoostRegressor,
            LinearLightGBMRegressor
        ]

    def test_all_models_fit_and_predict(self):
        """
        Iterate through every model class, instantiate, fit, and predict.
        """
        for ModelClass in self.model_classes:
            with self.subTest(model=ModelClass.__name__):
                print(f"Testing {ModelClass.__name__}...")
                
                # 1. Instantiate
                model = ModelClass(cv=3)
                
                # 2. Fit
                try:
                    model.fit(self.X, self.y)
                except Exception as e:
                    self.fail(f"{ModelClass.__name__} failed to fit. Error: {e}")

                # 3. Predict
                try:
                    predictions = model.predict(self.X)
                except Exception as e:
                    self.fail(f"{ModelClass.__name__} failed to predict. Error: {e}")
                
                # 4. Check Shape
                # Predictions should be 1D array of shape (n_samples,) or (n_samples, 1)
                self.assertTrue(predictions.shape[0] == self.X.shape[0], 
                                f"{ModelClass.__name__} prediction shape mismatch.")
                
                # 5. Check Values (sanity check)
                self.assertFalse(np.isnan(predictions).any(), 
                                 f"{ModelClass.__name__} produced NaN values.")

    def test_custom_base_and_meta_models(self):
        """
        Verify that we can pass custom parameters to base and meta models.
        Using LinearForestRegressor as a proxy for all.
        """
        from sklearn.linear_model import Ridge
        from sklearn.ensemble import RandomForestRegressor
        
        custom_base = Ridge(alpha=1.0)
        custom_meta = RandomForestRegressor(n_estimators=10, max_depth=2)
        
        model = LinearForestRegressor(base_model=custom_base, meta_model=custom_meta, cv=2)
        model.fit(self.X, self.y)
        preds = model.predict(self.X)
        
        self.assertEqual(len(preds), 100)

    def test_error_if_not_fitted(self):
        """
        Ensure the model raises RuntimeError (or NotFittedError) if predict is called before fit.
        """
        model = LinearForestRegressor()
        with self.assertRaises(RuntimeError):
            model.predict(self.X)

if __name__ == '__main__':
    unittest.main()