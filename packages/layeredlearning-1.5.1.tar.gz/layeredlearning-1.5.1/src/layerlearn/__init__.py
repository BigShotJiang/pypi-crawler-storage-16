# here is the package imports
from layerlearn.flexiblestacked import FlexibleStackedClassifier
from layerlearn.flexiblestacked import FlexibleStackedRegressor
from layerlearn.baseLinear import LinearForestRegressor
from layerlearn.baseLinear import LinearSupportRegressor
from layerlearn.baseLinear import LinearDecisionRegressor
from layerlearn.baseLinear import LinearKNNRegressor
from layerlearn.baseLinear import LinearXGBRRegressor
from layerlearn.baseLinear import LinearCatRegressor
from layerlearn.baseLinear import LinearGradientRegressor
from layerlearn.baseLinear import LinearAdaRegressor
from layerlearn.baseLinear import LinearLightRegressor


# here is the version of the package
__version__ = "1.5.1"