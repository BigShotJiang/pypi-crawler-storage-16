"""Layrz Forms Types"""

from typing import Any, TypeAlias

ErrorType: TypeAlias = dict[str, Any]
