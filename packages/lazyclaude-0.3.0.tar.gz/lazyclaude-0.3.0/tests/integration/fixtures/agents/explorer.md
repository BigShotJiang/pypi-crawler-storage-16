---
name: explorer
description: Explores the codebase structure
tools: Glob, Grep, Read
model: haiku
---
# Explorer Agent
Use this agent for codebase exploration tasks.
