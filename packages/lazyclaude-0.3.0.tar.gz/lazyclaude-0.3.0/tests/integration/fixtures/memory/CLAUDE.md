# Project Guidelines

@AGENTS.md

## Code Style
- Use type hints
- Follow PEP 8
