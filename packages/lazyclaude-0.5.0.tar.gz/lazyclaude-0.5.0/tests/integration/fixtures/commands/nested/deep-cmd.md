---
description: A nested command for testing rglob
---
# Deep Command
This command is nested in a subdirectory.
