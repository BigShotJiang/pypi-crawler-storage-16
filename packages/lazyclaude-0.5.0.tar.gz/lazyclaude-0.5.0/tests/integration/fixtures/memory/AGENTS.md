# Agents Configuration

## Available Agents
- explorer: For codebase exploration
- reviewer: For code review
