---
name: reviewer
description: Reviews code changes
tools: Read, Grep
model: sonnet
---
# Reviewer Agent
Use this agent for code review tasks.
