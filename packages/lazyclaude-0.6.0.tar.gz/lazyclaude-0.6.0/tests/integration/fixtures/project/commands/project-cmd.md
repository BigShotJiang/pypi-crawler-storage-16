---
description: A project-level command
---
# Project Command
This is a project-level slash command.
