"""Integration tests for ConfigDiscoveryService."""
