---
description: Say hello to someone
allowed-tools: Bash(echo:*)
argument-hint: <name>
---
# Greet Command
Say hello to the specified person.
