---
name: plugin-skill
description: A skill from a plugin
---
# Plugin Skill
This skill comes from the example-plugin.
