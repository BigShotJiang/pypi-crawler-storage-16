"""
Utility methods; not user-facing.
"""