from __future__ import annotations

"""
The Hatchet Current Version

Patched: {{ timestamp }}
Version: {{ version }}
Last Version: {{ last_version }}
"""

from ..{{ current_version_name }} import Context, ContextT, Worker, CURRENT_VERSION, LAST_VERSION
