"""Database adapters, configuration helpers, and backend registries."""
