"""
FastAPI Extensions: Middlewares
"""

from .persistent import PersistentMiddleware