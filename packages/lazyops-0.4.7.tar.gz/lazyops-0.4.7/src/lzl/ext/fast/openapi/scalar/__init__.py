"""
FastAPI Extensions: OpenAPI Documentation Generator: Scalar

Ref: `https://github.com/scalar/scalar`
"""

from .types import ScalarOpenAPI as Scalar