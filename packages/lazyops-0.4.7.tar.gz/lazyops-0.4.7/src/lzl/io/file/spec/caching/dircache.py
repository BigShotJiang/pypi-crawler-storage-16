from __future__ import annotations

"""
An Implementation of DirCache based on `lzl.io.PersistentDict`
"""

from fsspec.dircache import DirCache

