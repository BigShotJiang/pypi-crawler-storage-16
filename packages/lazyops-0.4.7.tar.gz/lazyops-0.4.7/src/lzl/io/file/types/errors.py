
class FileExistsError(Exception):
    """
    Raised when a file already exists.
    """
    pass