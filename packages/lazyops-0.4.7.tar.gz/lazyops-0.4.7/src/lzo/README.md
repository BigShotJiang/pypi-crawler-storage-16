# LaZyOps v2

A rewrite of the original `lazyops` library to better organize the code and make it more modular.

The original `lazyops` remains available in the `src` directory for backwards compatibility.