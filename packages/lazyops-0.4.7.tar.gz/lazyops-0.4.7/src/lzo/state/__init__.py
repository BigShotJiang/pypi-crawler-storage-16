"""
Registry of Apps / Modules / Objects 
"""
