# LB2

*LB2 Ticket* LB2 company Ticket tool for manager tickets on workestre system

