

def hello(): 
    return 'hi'