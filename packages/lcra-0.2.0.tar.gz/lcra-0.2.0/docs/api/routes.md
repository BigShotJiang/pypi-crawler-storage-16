# API Routes

::: api.app
    options:
      show_root_heading: true
      show_source: true
      members:

- root
- get_complete_flood_report
- get_lake_levels
- get_river_conditions
- get_floodgate_operations
- health_check

