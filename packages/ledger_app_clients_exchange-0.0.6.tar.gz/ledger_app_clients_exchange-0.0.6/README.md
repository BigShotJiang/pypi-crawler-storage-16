# Exchange client to run swap tests

This package provides modules to be able to run swap tests with Exchange app.

To deploy this client package, please do:

1. Update the `CHANGELOG`, adding the version (example `[M.N.P]`), date and description
2. Merge the modifications of the `CHANGELOG`
3. Push a tag, corresponding to the `CHANGELOG` information (example `client-M.N.P`)
