# Description of the geometry

This section provides detailed descriptions of the geometry components, with a
particular focus on the names of physical volumes and their organization.

```{warning}

This documentation is not implemented yet due to the ongoing development of the
geometry. Please refer to the source code for the most accurate and up-to-date
information.

```
