from __future__ import annotations

from pygeoml1000._version import version as __version__
from pygeoml1000.core import construct

__all__ = ["__version__", "construct"]
