"""Test suite for the legopic package."""
