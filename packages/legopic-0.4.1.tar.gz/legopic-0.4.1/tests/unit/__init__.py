"""Unit tests for legopic package."""
