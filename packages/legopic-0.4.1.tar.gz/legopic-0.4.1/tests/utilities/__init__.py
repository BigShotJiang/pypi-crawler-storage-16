"""Test utilities for legopic tests."""
