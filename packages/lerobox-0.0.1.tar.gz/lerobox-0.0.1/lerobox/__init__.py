"""Placeholder package to reserve the name lerobox on PyPI."""
