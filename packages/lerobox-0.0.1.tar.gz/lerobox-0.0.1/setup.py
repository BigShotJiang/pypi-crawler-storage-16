from setuptools import setup, find_packages

setup(
    name="lerobox",
    version="0.0.1",
    author="fracapuano",
    description="A placeholder package to reserve the name lerobox",
    packages=find_packages(),
    python_requires=">=3.6",
)