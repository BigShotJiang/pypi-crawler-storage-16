Lesson 9

'''
Python kod yozamiz
'''