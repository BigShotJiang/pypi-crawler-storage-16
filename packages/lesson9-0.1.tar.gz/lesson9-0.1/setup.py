from setuptools import setup, find_packages

setup(
    name='lesson9',
    version='0.1',
    author='Shoxrux',
    author_email='shoxruxaminboyev367@gmail.com',
    description="Shoxrux's first package",
    long_description=open('README.md').read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    requires=[],
    license='MIT'







)