[![CI](https://github.com/jediknight112/lets-debug-helper/actions/workflows/main.yml/badge.svg)](https://github.com/jediknight112/lets-debug-helper/actions/workflows/main.yml)
[![Coverage Status](https://coveralls.io/repos/github/jediknight112/lets-debug-helper/badge.svg?branch=main)](https://coveralls.io/github/jediknight112/lets-debug-helper?branch=main)

# lets-debug-helper

This is a cli tool that interacts with the Let's Debug API

The API homepage can be found at https://letsdebug.net/

To install this package:

```
pip install lets-debug-helper
```

# Usage

```
lets-debug domain.com
```
