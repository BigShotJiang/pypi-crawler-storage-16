"""
Pre-qualification configuration for AI agents.

Defines the data collection, acceptance criteria, and destination actions
for qualifying/disqualifying users.
"""

from pydantic import BaseModel, Field
from typing import Optional, List
from enum import StrEnum
from letschatty.models.utils.types.identifier import StrObjectId


class PreQualifyDestination(StrEnum):
    """
    Destination/action when pre-qualification reaches a terminal state.
    """
    SUBSCRIBE_TO_LAUNCH = "subscribe_to_launch"  # Subscribe to launch + welcome kit
    CALENDAR_SCHEDULER = "calendar_scheduler"    # Allow AI agent to schedule meetings
    ESCALATE = "escalate"                        # Escalate to human
    CUSTOM_MESSAGE = "custom_message"            # Send a custom message
    CONTINUE = "continue"                        # Continue normal AI agent flow
    NONE = "none"                                # Do nothing


class PreQualifyConfig(BaseModel):
    """
    Configuration for pre-qualification process.
    Embedded in ChattyAIAgent.
    """
    # Form fields to collect
    form_fields: List[StrObjectId] = Field(
        default_factory=list,
        description="List of FormField IDs to be collected"
    )

    # Acceptance criteria
    acceptance_criteria: str = Field(
        default="",
        description="Description of criteria for AI to evaluate if user qualifies. Empty = no criteria (auto-qualify on mandatory completion)"
    )

    # On qualified actions
    on_qualified_destination: PreQualifyDestination = Field(
        default=PreQualifyDestination.CONTINUE,
        description="Action when user qualifies"
    )
    on_qualified_message: Optional[str] = Field(
        default=None,
        description="Custom message to send when user qualifies (if destination is custom_message)"
    )

    # On unqualified actions
    on_unqualified_destination: PreQualifyDestination = Field(
        default=PreQualifyDestination.NONE,
        description="Action when user does NOT qualify"
    )
    on_unqualified_message: Optional[str] = Field(
        default=None,
        description="Custom message to send when user does NOT qualify (if destination is custom_message or escalate)"
    )

    @property
    def has_form_fields(self) -> bool:
        """Check if pre-qualify has form fields configured"""
        return len(self.form_fields) > 0

    @property
    def has_acceptance_criteria(self) -> bool:
        """Check if acceptance criteria is configured"""
        return bool(self.acceptance_criteria.strip())

    @property
    def is_configured(self) -> bool:
        """Check if pre-qualify is configured (has form fields)"""
        return self.has_form_fields

