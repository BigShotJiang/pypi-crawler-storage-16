from pydantic import BaseModel, Field
from typing import Optional, Any, ClassVar, List
from letschatty.models.base_models.chatty_asset_model import CompanyAssetModel, ChattyAssetPreview


class FormFieldPreview(ChattyAssetPreview):
    """Preview model for FormField - used in list views"""
    field_key: str = Field(description="Unique key identifier for the field")
    required: bool = Field(default=False, description="Whether this field is required")
    is_system_field: bool = Field(default=False, description="True if this is a system/standard field")
    question_example: Optional[str] = Field(default=None, description="Example question for AI")


class SystemFieldCustomization(BaseModel):
    """
    Company-specific customization for a system form field.
    Only question_example and description can be customized.
    """
    system_field_id: str = Field(description="The system field ID being customized")
    company_id: str = Field(description="Company that owns this customization")
    question_example: Optional[str] = Field(default=None, description="Custom question for AI")
    description: Optional[str] = Field(default=None, description="Custom description")


class FormField(CompanyAssetModel):
    """
    Company asset for data collection fields.
    AI handles all validation - no regex or type constraints.

    System fields (is_system_field=True) are standard fields that map directly
    to Client model properties (name, email, phone, document_id).
    """
    name: str = Field(description="Display name of the field (e.g., 'Email', 'Budget')")
    field_key: str = Field(description="Unique key identifier for the field (e.g., 'email', 'budget')")
    description: str = Field(
        default="",
        description="Description of what information this field aims to collect"
    )
    question_example: Optional[str] = Field(
        default=None,
        description="Example of how AI should ask for this information"
    )
    required: bool = Field(
        default=False,
        description="Whether this field is required (mandatory)"
    )
    is_system_field: bool = Field(
        default=False,
        description="True if this is a system/standard field (cannot be deleted)"
    )

    # Preview class for API responses
    preview_class: ClassVar[type[FormFieldPreview]] = FormFieldPreview

    @classmethod
    def example_email(cls) -> dict:
        """Example email field"""
        return {
            "name": "Email",
            "field_key": "email",
            "description": "Customer's email address for communication",
            "question_example": "Could you share your email so I can send you more information?",
            "required": True
        }

    @classmethod
    def example_budget(cls) -> dict:
        """Example budget field"""
        return {
            "name": "Budget",
            "field_key": "budget",
            "description": "Customer's budget allocation for the project",
            "question_example": "What's your budget range for this project?",
            "required": False
        }


class SystemFormFields:
    """
    Standard system fields available for all companies.
    These map directly to Client model properties.
    """

    # System field IDs (fixed ObjectIds for consistency)
    SYSTEM_NAME_ID = "000000000000000000000001"
    SYSTEM_EMAIL_ID = "000000000000000000000002"
    SYSTEM_PHONE_ID = "000000000000000000000003"
    SYSTEM_DOCUMENT_ID = "000000000000000000000004"
    SYSTEM_EXTERNAL_ID = "000000000000000000000005"

    @classmethod
    def get_all(cls) -> List[dict]:
        """Get all system form fields as dicts (for API responses)"""
        return [
            cls.name_field(),
            cls.email_field(),
            cls.phone_field(),
            cls.document_id_field(),
            cls.external_id_field(),
        ]

    @classmethod
    def get_all_ids(cls) -> List[str]:
        """Get all system field IDs"""
        return [
            cls.SYSTEM_NAME_ID,
            cls.SYSTEM_EMAIL_ID,
            cls.SYSTEM_PHONE_ID,
            cls.SYSTEM_DOCUMENT_ID,
            cls.SYSTEM_EXTERNAL_ID,
        ]

    @classmethod
    def is_system_field_id(cls, field_id: str) -> bool:
        """Check if a field ID is a system field"""
        return field_id in cls.get_all_ids()

    @classmethod
    def get_by_id(cls, field_id: str) -> Optional[dict]:
        """Get a system field by its ID"""
        fields_map = {
            cls.SYSTEM_NAME_ID: cls.name_field(),
            cls.SYSTEM_EMAIL_ID: cls.email_field(),
            cls.SYSTEM_PHONE_ID: cls.phone_field(),
            cls.SYSTEM_DOCUMENT_ID: cls.document_id_field(),
            cls.SYSTEM_EXTERNAL_ID: cls.external_id_field(),
        }
        return fields_map.get(field_id)

    @classmethod
    def name_field(cls) -> dict:
        """Standard name field"""
        return {
            "id": cls.SYSTEM_NAME_ID,
            "name": "Nombre",
            "field_key": "name",
            "description": "Nombre del cliente",
            "question_example": "¿Cuál es tu nombre?",
            "required": False,
            "is_system_field": True,
            "deleted_at": None
        }

    @classmethod
    def email_field(cls) -> dict:
        """Standard email field"""
        return {
            "id": cls.SYSTEM_EMAIL_ID,
            "name": "Email",
            "field_key": "email",
            "description": "Dirección de correo electrónico del cliente",
            "question_example": "¿Podrías compartirme tu email para enviarte más información?",
            "required": False,
            "is_system_field": True,
            "deleted_at": None
        }

    @classmethod
    def phone_field(cls) -> dict:
        """Standard phone field"""
        return {
            "id": cls.SYSTEM_PHONE_ID,
            "name": "Teléfono",
            "field_key": "phone",
            "description": "Número de teléfono del cliente",
            "question_example": "¿Cuál es tu número de teléfono?",
            "required": False,
            "is_system_field": True,
            "deleted_at": None
        }

    @classmethod
    def document_id_field(cls) -> dict:
        """Standard document ID field (DNI/ID)"""
        return {
            "id": cls.SYSTEM_DOCUMENT_ID,
            "name": "DNI / Documento",
            "field_key": "document_id",
            "description": "Número de documento de identidad del cliente",
            "question_example": "¿Cuál es tu número de DNI o documento?",
            "required": False,
            "is_system_field": True,
            "deleted_at": None
        }

    @classmethod
    def external_id_field(cls) -> dict:
        """Standard external/CRM ID field"""
        return {
            "id": cls.SYSTEM_EXTERNAL_ID,
            "name": "ID Externo / CRM",
            "field_key": "external_id",
            "description": "Identificador externo del cliente en CRM u otro sistema",
            "question_example": "¿Tienes un número de cliente o código de referencia?",
            "required": False,
            "is_system_field": True,
            "deleted_at": None
        }


class CollectedData(BaseModel):
    """
    Data collected from customer during conversation.
    AI validates format - we just store strings.
    """
    name: Optional[str] = Field(default=None, description="Customer's name")
    email: Optional[str] = Field(default=None, description="Customer's email address")
    phone: Optional[str] = Field(default=None, description="Customer's phone number")
    document_id: Optional[str] = Field(default=None, description="Customer's DNI/ID number")

    # Generic key-value store for any other collected fields
    additional_fields: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional collected fields as key-value pairs"
    )


    @classmethod
    def example(cls) -> dict:
        """Example collected data"""
        return {
            "email": "customer@example.com",
            "phone": "+5491123456789",
            "dni": "12345678",
            "additional_fields": {
                "budget": "10000-50000",
                "timeline": "this_month",
                "company_size": "25"
            }
        }

    @classmethod
    def get_json_schema_property(cls) -> dict:
        """Returns JSON schema for OpenAI structured output"""
        return {
            "type": "object",
            "properties": {
                "email": {
                    "anyOf": [{"type": "string"}, {"type": "null"}],
                    "description": "Customer's email address if provided"
                },
                "phone": {
                    "anyOf": [{"type": "string"}, {"type": "null"}],
                    "description": "Customer's phone number if provided"
                },
                "dni": {
                    "anyOf": [{"type": "string"}, {"type": "null"}],
                    "description": "Customer's DNI/ID number if provided"
                },
                "additional_fields": {
                    "type": "object",
                    "additionalProperties": True,
                    "description": "Other collected fields as key-value pairs (e.g., budget, timeline)"
                }
            },
            "required": ["email", "phone", "dni", "additional_fields"],
            "additionalProperties": False
        }
