from django.contrib import admin

# Process admin configurations will be added here as needed