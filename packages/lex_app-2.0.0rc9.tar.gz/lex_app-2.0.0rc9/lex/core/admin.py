from django.contrib import admin

# Core admin configurations will be added here as needed