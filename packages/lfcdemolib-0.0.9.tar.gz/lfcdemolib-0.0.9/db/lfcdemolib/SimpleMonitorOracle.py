#!/usr/bin/env python3
"""
SimpleMonitorOracle.py - Oracle specific monitoring implementation

This module provides Oracle specific performance and schema monitoring capabilities.
"""

import datetime
import sqlalchemy as sa
from sqlalchemy import text
from typing import Dict, Any, List
from .SimpleMonitorBase import MonitorProviderBase, PerformanceMetrics, SchemaMetrics

class OracleMonitorProvider(MonitorProviderBase):
    """Oracle specific monitoring implementation"""
    
    def get_default_schema_name(self) -> str:
        """Get the default schema name for Oracle"""
        return 'PUBLIC'
    
    def capture_performance_metrics(self, timestamp: datetime.datetime) -> PerformanceMetrics:
        """Capture Oracle specific performance metrics"""
        with self.engine.connect() as conn:
            # Initialize default values
            cpu_percent = 0.0
            memory_gb = 0.0
            io_reads_per_sec = 0.0
            io_writes_per_sec = 0.0
            io_read_bytes_per_sec = 0.0
            io_write_bytes_per_sec = 0.0
            network_kb_per_sec = 0.0
            buffer_cache_hit_ratio = 0.0
            active_connections = 0
            blocking_sessions = 0
            wal_size_mb = 0.0
            cpu_count = 1
            max_memory_gb = 1.0
            
            # CPU utilization
            try:
                cpu_query = text("""
                    SELECT VALUE 
                    FROM V$SYSSTAT 
                    WHERE NAME = 'CPU used by this session'
                    AND ROWNUM = 1
                """)
                cpu_result = conn.execute(cpu_query).fetchone()
                
                if cpu_result and cpu_result[0]:
                    # Convert centiseconds to percentage (rough approximation)
                    cpu_percent = min(float(cpu_result[0]) / 100.0, 100.0)
                
                print(f"🔍 CPU: {cpu_percent:.1f}%")
            except Exception as e:
                print(f"⚠️ Could not capture CPU metrics: {e}")
            
            # Memory usage - SGA and PGA
            try:
                memory_query = text("""
                    SELECT 
                        ROUND(SUM(VALUE) / 1024 / 1024 / 1024, 2) AS memory_gb
                    FROM V$SGA
                """)
                memory_result = conn.execute(memory_query).fetchone()
                memory_gb = float(memory_result[0]) if memory_result and memory_result[0] else 0.0
                max_memory_gb = max(memory_gb * 1.5, 1.0)  # Estimate
            except Exception as e:
                print(f"⚠️ Could not capture memory metrics: {e}")
            
            # I/O metrics
            try:
                io_query = text("""
                    SELECT 
                        SUM(PHYSICAL_READS) AS physical_reads,
                        SUM(PHYSICAL_WRITES) AS physical_writes,
                        SUM(PHYSICAL_READ_BYTES) AS read_bytes,
                        SUM(PHYSICAL_WRITE_BYTES) AS write_bytes
                    FROM V$SESS_IO
                    WHERE ROWNUM <= 1
                """)
                io_result = conn.execute(io_query).fetchone()
                
                if io_result:
                    io_reads_per_sec = float(io_result[0] or 0) / 3600  # Rough hourly average
                    io_writes_per_sec = float(io_result[1] or 0) / 3600
                    io_read_bytes_per_sec = float(io_result[2] or 0) / 3600
                    io_write_bytes_per_sec = float(io_result[3] or 0) / 3600
            except Exception as e:
                print(f"⚠️ Could not capture I/O metrics: {e}")
            
            # Buffer cache hit ratio
            try:
                cache_query = text("""
                    SELECT 
                        ROUND(
                            (1 - (phy.value / (db.value + con.value))) * 100, 
                            2
                        ) AS buffer_cache_hit_ratio
                    FROM 
                        V$SYSSTAT phy,
                        V$SYSSTAT db,
                        V$SYSSTAT con
                    WHERE 
                        phy.name = 'physical reads' 
                        AND db.name = 'db block gets' 
                        AND con.name = 'consistent gets'
                        AND ROWNUM = 1
                """)
                cache_result = conn.execute(cache_query).fetchone()
                
                if cache_result and cache_result[0]:
                    buffer_cache_hit_ratio = float(cache_result[0])
            except Exception as e:
                print(f"⚠️ Could not capture buffer cache metrics: {e}")
            
            # Connection metrics
            try:
                conn_query = text("""
                    SELECT COUNT(*) 
                    FROM V$SESSION 
                    WHERE STATUS = 'ACTIVE'
                """)
                conn_result = conn.execute(conn_query).fetchone()
                active_connections = int(conn_result[0]) if conn_result else 0
                
                # Blocking sessions
                blocking_query = text("""
                    SELECT COUNT(DISTINCT blocking_session) 
                    FROM V$SESSION 
                    WHERE blocking_session IS NOT NULL
                """)
                blocking_result = conn.execute(blocking_query).fetchone()
                blocking_sessions = int(blocking_result[0]) if blocking_result else 0
            except Exception as e:
                print(f"⚠️ Could not capture connection metrics: {e}")
            
            # Redo log size (WAL equivalent for Oracle)
            try:
                redo_query = text("""
                    SELECT 
                        ROUND(SUM(BYTES) / 1024 / 1024, 2) AS redo_size_mb
                    FROM V$LOG
                """)
                redo_result = conn.execute(redo_query).fetchone()
                wal_size_mb = float(redo_result[0]) if redo_result and redo_result[0] else 0.0
            except Exception as e:
                print(f"⚠️ Could not capture redo log metrics: {e}")
            
            return PerformanceMetrics(
                timestamp=timestamp,
                cpu_percent=cpu_percent,
                memory_gb=memory_gb,
                io_reads_per_sec=io_reads_per_sec,
                io_writes_per_sec=io_writes_per_sec,
                io_read_bytes_per_sec=io_read_bytes_per_sec,
                io_write_bytes_per_sec=io_write_bytes_per_sec,
                network_kb_per_sec=network_kb_per_sec,
                buffer_cache_hit_ratio=buffer_cache_hit_ratio,
                active_connections=active_connections,
                blocking_sessions=blocking_sessions,
                wal_size_mb=wal_size_mb,
                cpu_count=cpu_count,
                max_memory_gb=max_memory_gb
            )
    
    def capture_schema_metrics(self, schema: str) -> SchemaMetrics:
        """Capture Oracle specific schema metrics"""
        with self.engine.connect() as conn:
            tables = []
            indexes = []
            constraints = []
            procedures = []
            
            # Get tables
            try:
                tables_query = text("""
                    SELECT table_name, num_rows, blocks, avg_row_len
                    FROM all_tables
                    WHERE owner = :schema
                    ORDER BY table_name
                """)
                tables_result = conn.execute(tables_query, {"schema": schema.upper()})
                
                for row in tables_result:
                    tables.append({
                        'name': row[0],
                        'row_count': int(row[1]) if row[1] else 0,
                        'size_mb': float(row[2] * 8 / 1024) if row[2] else 0.0  # Oracle blocks are typically 8KB
                    })
            except Exception as e:
                print(f"⚠️ Could not capture table metrics: {e}")
            
            # Get indexes
            try:
                indexes_query = text("""
                    SELECT index_name, table_name, uniqueness, leaf_blocks
                    FROM all_indexes
                    WHERE owner = :schema
                    ORDER BY index_name
                """)
                indexes_result = conn.execute(indexes_query, {"schema": schema.upper()})
                
                for row in indexes_result:
                    indexes.append({
                        'name': row[0],
                        'table': row[1],
                        'is_unique': row[2] == 'UNIQUE',
                        'size_mb': float(row[3] * 8 / 1024) if row[3] else 0.0
                    })
            except Exception as e:
                print(f"⚠️ Could not capture index metrics: {e}")
            
            return SchemaMetrics(
                schema_name=schema,
                table_count=len(tables),
                index_count=len(indexes),
                constraint_count=len(constraints),
                procedure_count=len(procedures),
                total_size_mb=sum(t['size_mb'] for t in tables) + sum(i['size_mb'] for i in indexes),
                table_metrics=tables,
                index_metrics=indexes
            )
    
    def get_table_info(self, schema: str, table_name: str) -> Dict[str, Any]:
        """Get Oracle specific table information"""
        with self.engine.connect() as conn:
            try:
                query = text("""
                    SELECT 
                        t.num_rows,
                        t.blocks,
                        t.avg_row_len,
                        t.last_analyzed
                    FROM all_tables t
                    WHERE t.owner = :schema
                    AND t.table_name = :table_name
                """)
                result = conn.execute(query, {"schema": schema.upper(), "table_name": table_name.upper()}).fetchone()
                
                if result:
                    return {
                        'row_count': int(result[0]) if result[0] else 0,
                        'size_mb': float(result[1] * 8 / 1024) if result[1] else 0.0,
                        'avg_row_length': int(result[2]) if result[2] else 0,
                        'last_analyzed': result[3]
                    }
                
                return {
                    'row_count': 0,
                    'size_mb': 0.0,
                    'avg_row_length': 0,
                    'last_analyzed': None
                }
            except Exception as e:
                print(f"⚠️ Could not get table info: {e}")
                return {
                    'row_count': 0,
                    'size_mb': 0.0,
                    'avg_row_length': 0,
                    'last_analyzed': None
                }







