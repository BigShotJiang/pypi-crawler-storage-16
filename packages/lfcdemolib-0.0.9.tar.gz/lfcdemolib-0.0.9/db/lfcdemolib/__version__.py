"""Version information for lfcdemolib."""

__version__ = "0.0.9"
