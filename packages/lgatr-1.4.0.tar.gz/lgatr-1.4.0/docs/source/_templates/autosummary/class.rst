{{ fullname }}
{{ underline }}

.. autoclass:: {{ fullname }}
   :members:
   :inherited-members: False
   :undoc-members:
   :show-inheritance:
