-- -----------------------------------------------------------
-- Analysis Productions database definition
-- -----------------------------------------------------------

USE AnalysisProductionsDB;
