## 1.0.8 (2025-12-09)
### Fixed
- Fix TH pegel page scraping

## 1.0.7 (2025-11-23)
### Fixed
- Fix HE without flow

## 1.0.6 (2025-10-06)
### Fixed
- Fix RP name and url generation

## 1.0.5 (2025-05-24)
### Fixed
- Fix BB encoding

## 1.0.4 (2024-12-24)
### Fixed
- Fix NI invalid values
- Fix BB encoding
- Add get_all_stations()

## 1.0.3 (2024-10-02)
### Fixed
- Fix BE encoding

## 1.0.2 (2024-03-03)
### Fixed
- Update minimum required Python version to 3.11 due to usage of datetime.UTC

## 1.0.1 (2024-03-02)
### Fixed
- Fix `last_update` for BE pegel
- Fix `stage` for SN pegel

## 1.0.0 (2024-03-02)
### Added
- Extract lhpapi from Home Assistant hochwasserportal integration
