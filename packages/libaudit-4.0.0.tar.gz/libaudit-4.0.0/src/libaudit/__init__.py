default_app_config = f'{__package__}.apps.AppConfig'
