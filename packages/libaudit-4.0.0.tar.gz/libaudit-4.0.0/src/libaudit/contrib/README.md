## Дополнения
[Вьюсет для просмотра журнала (для database_table обработчика)](journal_viewer/README.md)

[Расширения для аутентификации DRF](rest_framework/README.md)
