AUDIT_LOG_TABLE_NAME = 'libaudit_audit_log'
