from pydantic import BaseModel

class BaseConfigModel(BaseModel):
    """
    設定モデルクラス
    """
    
    pass