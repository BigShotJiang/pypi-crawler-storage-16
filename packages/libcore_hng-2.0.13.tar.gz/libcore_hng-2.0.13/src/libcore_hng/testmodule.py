
def test_function():
    return "This is a test function from testmodule.py"