"""
Initializing the Python package
"""

__version__ = "0.99"

__all__ = ("__version__",)
