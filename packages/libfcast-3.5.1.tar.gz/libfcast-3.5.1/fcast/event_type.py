class EventType:
	MediaItemStart = 0
	MediaItemEnd = 1
	MediaItemChange = 2
	KeyDown = 3
	KeyUp = 4