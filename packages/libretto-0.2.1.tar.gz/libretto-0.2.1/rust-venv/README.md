# rust-venv
Simple crate to execute command in virtualenv 