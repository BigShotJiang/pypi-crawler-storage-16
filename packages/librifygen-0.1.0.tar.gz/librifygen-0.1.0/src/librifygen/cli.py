import argparse
import logging
from .preview import generate_video_preview, generate_previews
from .thumbnail import generate_thumbnails

logger = logging.getLogger(__name__)

def main():
    p = argparse.ArgumentParser(prog="Librifygen - Media Processor CLI")
    sub = p.add_subparsers(dest="cmd", required=True)

    t = sub.add_parser("thumbs", help="Generate thumbnails from media folder")
    t.add_argument("input")
    t.add_argument("output")
    t.add_argument("--workers", type=int, default=6)

    v = sub.add_parser("preview", help="Create previews for videos")
    v.add_argument("input")
    v.add_argument("output")
    v.add_argument("--num-clips", type=int, default=4)
    v.add_argument("--clip-duration", type=int, default=5)
    v.add_argument("--workers", type=int, default=4)
    v.add_argument("--transition", action="store_true")

    args = p.parse_args()
    logging.basicConfig(level=logging.INFO)

    if args.cmd == "thumbs":
        generate_thumbnails(args.input, args.output, worker_count=args.workers)
    elif args.cmd == "preview":
        # directory or single file detection
        import os
        if os.path.isdir(args.input):
            batch_create_previews(args.input, args.output, num_clips=args.num_clips,
                                  clip_duration=args.clip_duration, max_workers=args.workers,
                                  transition=args.transition)
        else:
            create_video_preview(args.input, args.output, num_clips=args.num_clips,
                                 clip_duration=args.clip_duration, transition=args.transition)

if __name__ == "__main__":
    main()
