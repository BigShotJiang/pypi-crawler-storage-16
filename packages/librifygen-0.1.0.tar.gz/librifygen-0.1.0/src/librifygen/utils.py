class FFmpegMissingError(RuntimeError):
    pass

def _ensure_ffmpeg_available() -> None:
    """Raise FFmpegMissingError if the ffmpeg binary or ffmpeg-python isn't available."""
    import shutil as _sh
    if _sh.which("ffmpeg") is None:
        raise FFmpegMissingError("ffmpeg binary not found in PATH. Install ffmpeg (apt/brew/choco) and ensure it's on PATH.")