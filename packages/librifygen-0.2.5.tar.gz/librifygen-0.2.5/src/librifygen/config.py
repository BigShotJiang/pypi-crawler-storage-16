# librifygen/config.py

# Default values
IMAGE_EXTS = (".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".webp")
VIDEO_EXTS = (".mp4", ".mov", ".mkv", ".avi", ".webm", ".flv", ".m4v")

def set_extensions(video_exts=None, image_exts=None):
    """Allows external projects to override default media extensions.

    Accepts iterables of extensions (strings like '.mp4'). Keeps types as sets.
    """
    global VIDEO_EXTS
    global IMAGE_EXTS

    if video_exts is not None:
        VIDEO_EXTS = tuple(ext.lower() for ext in video_exts if isinstance(ext, str) and ext.strip())

    if image_exts is not None:
        IMAGE_EXTS = tuple(ext.lower() for ext in image_exts if isinstance(ext, str) and ext.strip())
