# LibSNDFile Cython Extension

A Cython extension for [libsndfile](https://pypi.org/project/libsndfile/), a Python wrapper for the popular C library [libsndfile](https://github.com/libsndfile/libsndfile).