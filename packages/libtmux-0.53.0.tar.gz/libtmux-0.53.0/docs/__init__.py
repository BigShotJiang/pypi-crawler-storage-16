"""Documentation for the libtmux package."""
