# Exceptions

```{eval-rst}
.. automodule:: libtmux.exc
   :members:
```
