(api)=

(reference)=

# API Reference

```{toctree}

properties
servers
sessions
windows
panes
options
hooks
constants
common
exceptions
```
