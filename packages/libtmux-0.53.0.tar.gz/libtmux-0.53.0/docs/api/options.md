# Options

```{eval-rst}
.. automodule:: libtmux.options
   :members:
```
