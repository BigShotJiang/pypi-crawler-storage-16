from .lick import interpol, lick, lick_box, lick_box_plot

__version__ = "0.9.0"  # keep in sync with pyproject.toml
