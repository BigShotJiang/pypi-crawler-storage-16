# Copyright (c) ZhangYundi.
# Licensed under the MIT License. 
# Created on 2025/7/17 14:15
# Description:



if __name__ == '__main__':
    # settings = lidb.get_settings()
    import lidb

    print(lidb.get_settings().as_dict())


