"""API layer tests for the lifx-async."""
