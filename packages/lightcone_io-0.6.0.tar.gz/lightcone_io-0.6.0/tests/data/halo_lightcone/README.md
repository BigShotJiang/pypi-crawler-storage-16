# Test data for halo lightcone reader

This directory contains a small lightcone halo catalogue made by random
sampling the halos in a snapshot from the L1_m9 FLAMINGO run.