# Test data for HEALPix map reader

This directory contains HEALpix maps from the L1_m9_DMO FLAMINGO run down
sampled to very low resolution (nside=16).