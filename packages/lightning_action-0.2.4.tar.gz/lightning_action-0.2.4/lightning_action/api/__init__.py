from lightning_action.api.model import Model

__all__ = [
    'Model',
]
