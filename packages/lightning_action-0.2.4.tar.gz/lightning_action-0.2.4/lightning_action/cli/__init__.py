"""Command-line interface for lightning-action."""

from lightning_action.cli.main import main

__all__ = ['main']
