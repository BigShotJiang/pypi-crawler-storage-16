"""Version information for lightning_sdk."""

__version__ = "2025.12.09"
