class LightRagHttpError(Exception):
    """Исключение для HTTP ошибок."""

class LightRagError(Exception):
    """Исключение для HTTP ошибок."""
