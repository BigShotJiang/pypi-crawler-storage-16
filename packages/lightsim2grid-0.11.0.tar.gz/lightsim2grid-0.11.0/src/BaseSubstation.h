// Copyright (c) 2025, RTE (https://www.rte-france.com)
// See AUTHORS.txt
// This Source Code Form is subject to the terms of the Mozilla Public License, version 2.0.
// If a copy of the Mozilla Public License, version 2.0 was not distributed with this file,
// you can obtain one at http://mozilla.org/MPL/2.0/.
// SPDX-License-Identifier: MPL-2.0
// This file is part of LightSim2grid, LightSim2grid implements a c++ backend targeting the Grid2Op platform.

#ifndef BASESUBSTATION_H
#define BASESUBSTATION_H

#include <iostream>
#include <vector>
// #include <set>
#include <stdio.h>
#include <cstdint> // for int32
#include <chrono>
#include <cmath>  // for PI

#include "Utils.h"

// eigen is necessary to easily pass data from numpy to c++ without any copy.
// and to optimize the matrix operations
#include "Eigen/Core"
#include "Eigen/Dense"
#include "Eigen/SparseCore"
#include "Eigen/SparseLU"

class Substation
{
    public:

    typedef std::tuple<
       int,  // n_sub_
       int,  // nmax_busbar_per_sub
       std::vector<real_type>, // sub_vn_kv_;
       std::vector<bool>,  // bus_status_;
       std::vector<real_type>,  // bus_vn_kv_;
       std::vector<std::string>  // sub_names_
       > StateRes;
    

    Substation::StateRes get_state() const;
    void set_state(Substation::StateRes & my_state);

    Substation():
        n_sub_(-1), 
        nmax_busbar_per_sub_(-1),
        n_bus_max_(-1){}
        
    Substation(int n_sub, int nmax_busbar_per_sub):
        n_sub_(n_sub),
        nmax_busbar_per_sub_(nmax_busbar_per_sub),
        n_bus_max_(n_sub * nmax_busbar_per_sub),
        sub_vn_kv_(n_sub),
        bus_status_(n_bus_max_, false),
        bus_vn_kv_(n_bus_max_){}

    void reset_bus_status(){
        for(auto i = 0; i < n_bus_max_; ++ i) bus_status_[i] = -1;
    }

    void init_sub(const RealVect & sub_vn_kv){
        for(auto i = 0; i < n_sub_; ++i){
            // store substation vn kv
            sub_vn_kv_[i] = sub_vn_kv[i];
            for(auto j = 0; j < nmax_busbar_per_sub_; ++j){
                // store the buses vn kv, for all buses
                bus_vn_kv_[i + j * n_sub_] = sub_vn_kv[i];
            }
        }

    }

    void init_sub_names(const std::vector<std::string> & sub_names){
        if(sub_names.size() != n_sub_){
            throw std::runtime_error("Wrong number of substation when setting their names.");
        }
        sub_names_ = sub_names;
    }
    const std::vector<std::string> & get_sub_names() const {
        return sub_names_;
    }

    // void from_agent_topology(int sub_id, int local_bus_id){
    //     bus_status_[sub_id + local_bus_id * n_sub_] = true;

    // }

    int nb_sub() const {return n_sub_;}
    unsigned int nb_bus() const {return bus_vn_kv_.size();}
    Eigen::Ref<const RealVect> get_bus_vn_kv() const {return bus_vn_kv_;}
    bool is_bus_connected(int global_bus_id) const {return bus_status_[global_bus_id];}
    bool is_bus_connected(int sub_id, int local_bus_id) const {return bus_status_[local_to_global(sub_id, local_bus_id)];}

    void init_bus(int n_sub, int nmax_busbar_per_sub, const RealVect & bus_vn_kv)
    {
        if(bus_vn_kv.size() != n_sub * nmax_busbar_per_sub){
            std::ostringstream exc_;
            exc_ << "Substation::init_bus: ";
            exc_ << "your model counts ";
            exc_ << n_sub_  << " substations and ";
            exc_ << nmax_busbar_per_sub_  << " maximum busbars per substation. But you provided a bus_vn_kv with ";
            exc_ << bus_vn_kv.size() << " elements.";
            exc_ << "Both should match.";
            throw std::runtime_error(exc_.str());
        }

        n_sub_ = n_sub;
        nmax_busbar_per_sub_ = nmax_busbar_per_sub;
        bus_vn_kv_ = bus_vn_kv;  // base_kv

        bus_status_ = std::vector<bool>(nb_bus(), true); // by default everything is connected
    }
    const std::vector<bool> & get_bus_status() const {return bus_status_;}
    /**
    Retrieve the number of connected buses
    **/
    int nb_connected_bus() const
    {
        int res = 0;
        for(const auto & el : bus_status_)
        {
            if(el) ++res;
        }
        return res;
    }
    
    void disconnect_all_buses(){
        for(unsigned int i = 0; i < nb_bus(); ++i) bus_status_[i] = false;
    }
    void reconnect_bus(int global_bus_id){
        bus_status_[global_bus_id] = true;
    }
    void reconnect_bus(int sub_id, int local_bus_id){
        reconnect_bus(local_to_global(sub_id, local_bus_id));
    }
    void disconnect_bus(int global_bus_id){
        bus_status_[global_bus_id] = false;
    }
    void disconnect_bus(int sub_id, int local_bus_id){
        disconnect_bus(local_to_global(sub_id, local_bus_id));
    }

    protected:
        int local_to_global(int sub_id, int local_bus_id) const{
            return sub_id + local_bus_id * n_sub_;
        }

    private:
        int n_sub_;
        int nmax_busbar_per_sub_;
        int n_bus_max_;
        RealVect sub_vn_kv_;
        std::vector<bool> bus_status_;
        RealVect bus_vn_kv_;
        std::vector<std::string> sub_names_;

};

#endif // BASESUBSTATION_H
