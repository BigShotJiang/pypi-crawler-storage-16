from .core import resolve, get_system_dns_server

__all__ = ["resolve", "get_system_dns_server"]

