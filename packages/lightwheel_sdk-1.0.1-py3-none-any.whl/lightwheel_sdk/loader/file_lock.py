from pathlib import Path
import fcntl


class FileLock:
    """File-based lock for cross-process synchronization."""

    def __init__(self, lock_file_path: Path):
        self.lock_file_path = lock_file_path
        self.lock_file = None

    def acquire(self):
        """Acquire the file lock."""
        # Ensure parent directory exists
        self.lock_file_path.parent.mkdir(parents=True, exist_ok=True)
        self.lock_file = open(self.lock_file_path, "w")
        fcntl.flock(self.lock_file.fileno(), fcntl.LOCK_EX)

    def release(self):
        """Release the file lock."""
        if self.lock_file:
            try:
                fcntl.flock(self.lock_file.fileno(), fcntl.LOCK_UN)
                self.lock_file.close()
            except:
                pass
            finally:
                self.lock_file = None

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.release()
