beam\_calculator module
==================================================

.. automodule:: lightwin.beam_calculation.beam_calculator
   :members:
   :undoc-members:
   :show-inheritance:
