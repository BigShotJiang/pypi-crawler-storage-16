element\_envelope3d\_parameters\_factory module
=======================================================================================

.. automodule:: lightwin.beam_calculation.envelope_3d.element_envelope3d_parameters_factory
   :members:
   :undoc-members:
   :show-inheritance:
