util module
===================================================

.. automodule:: lightwin.beam_calculation.envelope_3d.util
   :members:
   :undoc-members:
   :show-inheritance:
