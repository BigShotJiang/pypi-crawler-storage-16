rk4 module
=================================================

.. automodule:: lightwin.beam_calculation.integrators.rk4
   :members:
   :undoc-members:
   :show-inheritance:
