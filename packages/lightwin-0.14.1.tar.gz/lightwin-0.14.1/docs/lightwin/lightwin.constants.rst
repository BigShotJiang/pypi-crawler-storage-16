constants module
=========================

.. automodule:: lightwin.constants
   :members:
   :undoc-members:
   :show-inheritance:
