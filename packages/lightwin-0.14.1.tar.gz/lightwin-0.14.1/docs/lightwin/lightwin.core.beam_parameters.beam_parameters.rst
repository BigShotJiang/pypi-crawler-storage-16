beam\_parameters module
======================================================

.. automodule:: lightwin.core.beam_parameters.beam_parameters
   :members:
   :undoc-members:
   :show-inheritance:
