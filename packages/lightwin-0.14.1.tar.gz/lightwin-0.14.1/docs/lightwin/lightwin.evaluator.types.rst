types module
===============================

.. automodule:: lightwin.evaluator.types
   :members:
   :undoc-members:
   :show-inheritance:
