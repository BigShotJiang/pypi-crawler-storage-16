set\_of\_cavity\_settings module
==================================================

.. automodule:: lightwin.failures.set_of_cavity_settings
   :members:
   :undoc-members:
   :show-inheritance:
