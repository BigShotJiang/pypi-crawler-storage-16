downhill\_simplex\_penalty module
==================================================================

.. automodule:: lightwin.optimisation.algorithms.downhill_simplex_penalty
   :members:
   :undoc-members:
   :show-inheritance:
