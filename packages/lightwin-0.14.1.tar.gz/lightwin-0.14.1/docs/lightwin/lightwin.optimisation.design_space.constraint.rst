constraint module
=====================================================

.. automodule:: lightwin.optimisation.design_space.constraint
   :members:
   :undoc-members:
   :show-inheritance:
