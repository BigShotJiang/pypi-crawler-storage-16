design\_space\_parameter module
===================================================================

.. automodule:: lightwin.optimisation.design_space.design_space_parameter
   :members:
   :undoc-members:
   :show-inheritance:
