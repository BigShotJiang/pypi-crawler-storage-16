design\_space\_specs module
=================================================

.. automodule:: lightwin.optimisation.design_space_specs
   :members:
   :undoc-members:
   :show-inheritance:
