minimize\_difference\_with\_ref module
======================================================================

.. automodule:: lightwin.optimisation.objective.minimize_difference_with_ref
   :members:
   :undoc-members:
   :show-inheritance:
