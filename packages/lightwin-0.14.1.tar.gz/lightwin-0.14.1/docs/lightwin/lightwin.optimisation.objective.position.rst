position module
===============================================

.. automodule:: lightwin.optimisation.objective.position
   :members:
   :undoc-members:
   :show-inheritance:
