optimization module
==========================================

.. automodule:: lightwin.visualization.optimization
   :members:
   :undoc-members:
   :show-inheritance:
