"""Define the modules for the :class:`.CyEnvelope1D` beam calculator.

This is the Cython version of :class:`.Envelope1D`. It is faster, but requires
a compilation. Check out :file:`setup.py`.

"""
