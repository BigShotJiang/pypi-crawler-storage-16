"""Define some constants for the :class:`.Envelope3D`."""

from typing import Literal

ENVELOPE3D_METHODS = ("RK4",)  #:
ENVELOPE3D_METHODS_T = Literal["RK4",]
