"""Define solver parameters for each :class:`.Element`."""
