"""Define the :class:`.Accelerator` and a factory to create it."""
