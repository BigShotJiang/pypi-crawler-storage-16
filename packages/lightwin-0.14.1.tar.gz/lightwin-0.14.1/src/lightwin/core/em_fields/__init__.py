"""Define objects and functions to manipulate electromagnetic fields."""
