"""
In this subpackage, we define :class:`.ListOfElements`.

This object holds several contiguous :class:.`Element`. We also define factory
methods to instantiate this objects more easily, as well as helper functions.

"""
