transfer\_matrix\_factory module
============================================================================

.. automodule:: lightwin.beam_calculation.cy_envelope_1d.transfer_matrix_factory
   :members:
   :undoc-members:
   :show-inheritance:
