deprecated\_specs module
===================================================

.. automodule:: lightwin.beam_calculation.deprecated_specs
   :members:
   :undoc-members:
   :show-inheritance:
