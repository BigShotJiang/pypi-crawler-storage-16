transfer\_matrices module
=================================================================

.. automodule:: lightwin.beam_calculation.envelope_1d.transfer_matrices
   :members:
   :undoc-members:
   :show-inheritance:
