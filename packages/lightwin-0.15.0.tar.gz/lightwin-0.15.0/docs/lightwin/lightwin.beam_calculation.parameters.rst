parameters package
=============================================

.. automodule:: lightwin.beam_calculation.parameters
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 5

   lightwin.beam_calculation.parameters.element_parameters
   lightwin.beam_calculation.parameters.factory
