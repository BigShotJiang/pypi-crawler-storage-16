factory module
============================================================

.. automodule:: lightwin.beam_calculation.simulation_output.factory
   :members:
   :undoc-members:
   :show-inheritance:
