factory module
========================================

.. automodule:: lightwin.core.accelerator.factory
   :members:
   :undoc-members:
   :show-inheritance:
