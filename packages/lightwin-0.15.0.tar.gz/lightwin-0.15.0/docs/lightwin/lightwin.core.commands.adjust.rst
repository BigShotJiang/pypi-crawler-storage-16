adjust module
====================================

.. automodule:: lightwin.core.commands.adjust
   :members:
   :undoc-members:
   :show-inheritance:
