dummy\_command module
============================================

.. automodule:: lightwin.core.commands.dummy_command
   :members:
   :undoc-members:
   :show-inheritance:
