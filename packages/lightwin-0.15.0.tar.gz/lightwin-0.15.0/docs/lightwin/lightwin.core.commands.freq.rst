freq module
==================================

.. automodule:: lightwin.core.commands.freq
   :members:
   :undoc-members:
   :show-inheritance:
