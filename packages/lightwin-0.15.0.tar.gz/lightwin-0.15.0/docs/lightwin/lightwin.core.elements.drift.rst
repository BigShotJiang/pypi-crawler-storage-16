drift module
===================================

.. automodule:: lightwin.core.elements.drift
   :members:
   :undoc-members:
   :show-inheritance:
