quad module
==================================

.. automodule:: lightwin.core.elements.quad
   :members:
   :undoc-members:
   :show-inheritance:
