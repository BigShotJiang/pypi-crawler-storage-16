superposed\_fields module
==================================================

.. automodule:: lightwin.core.em_fields.superposed_fields
   :members:
   :undoc-members:
   :show-inheritance:
