instructions\_factory module
==========================================

.. automodule:: lightwin.core.instructions_factory
   :members:
   :undoc-members:
   :show-inheritance:
