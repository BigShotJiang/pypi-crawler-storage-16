helper module
==============================================

.. automodule:: lightwin.core.list_of_elements.helper
   :members:
   :undoc-members:
   :show-inheritance:
