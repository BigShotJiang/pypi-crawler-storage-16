transfer\_matrix module
======================================================

.. automodule:: lightwin.core.transfer_matrix.transfer_matrix
   :members:
   :undoc-members:
   :show-inheritance:
