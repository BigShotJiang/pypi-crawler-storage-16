helper module
================================

.. automodule:: lightwin.evaluator.helper
   :members:
   :undoc-members:
   :show-inheritance:
