differential\_evolution module
===============================================================

.. automodule:: lightwin.optimisation.algorithms.differential_evolution
   :members:
   :undoc-members:
   :show-inheritance:
