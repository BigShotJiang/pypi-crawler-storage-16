downhill\_simplex module
=========================================================

.. automodule:: lightwin.optimisation.algorithms.downhill_simplex
   :members:
   :undoc-members:
   :show-inheritance:
