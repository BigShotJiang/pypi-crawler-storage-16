factory module
===============================================

.. automodule:: lightwin.optimisation.algorithms.factory
   :members:
   :undoc-members:
   :show-inheritance:
