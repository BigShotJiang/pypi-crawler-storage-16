factory module
==================================================

.. automodule:: lightwin.optimisation.design_space.factory
   :members:
   :undoc-members:
   :show-inheritance:
