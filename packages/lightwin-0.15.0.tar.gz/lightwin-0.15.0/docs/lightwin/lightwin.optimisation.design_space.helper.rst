helper module
=================================================

.. automodule:: lightwin.optimisation.design_space.helper
   :members:
   :undoc-members:
   :show-inheritance:
