factory module
==============================================

.. automodule:: lightwin.optimisation.objective.factory
   :members:
   :undoc-members:
   :show-inheritance:
