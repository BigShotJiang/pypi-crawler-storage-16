``plots`` section (mandatory)
*****************************
.. toctree::
   :maxdepth: 5

This section defines what quantities will be plotted at the end of the simulation.

.. csv-table::
   :file: entries/plots.csv
   :header-rows: 1

.. warning::
   Plot of transfer matrix currently not working.

