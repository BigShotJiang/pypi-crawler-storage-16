``wtf`` section
***************

``wtf`` stands for *what to fit*.
This section parametrizes the failed cavities, as well as how they are fixed.

.. todo::
   Implement tests for all these configurations keys!

.. toctree::
   :maxdepth: 3

   wtf_common
   wtf_k_out_of_n
   wtf_l_neighboring_lattices
   wtf_corrector_at_exit
   wtf_manual
   wtf_global
   wtf_optimization

