.. toctree::
   :maxdepth: 3

Global, global downstream compensation
--------------------------------------

Use either all cavities of the linac, or all cavities downstream of the failure.
These methods require a very large number of compensating cavities and therefore significant numerical resources.
As a result, they are only lightly tested.

.. todo::
   Are they still implemented?
