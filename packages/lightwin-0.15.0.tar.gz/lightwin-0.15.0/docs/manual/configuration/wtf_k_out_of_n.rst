.. toctree::
   :maxdepth: 3

*k out of n* method
-------------------

Compensate the :math:`n` failed cavities with :math:`k\times n` closest cavities :cite:`saini_assessment_2021,Yee-Rendon2022a`.

.. csv-table::
   :file: entries/wtf_k_out_of_n.csv
   :header-rows: 1

