Installation
============

.. toctree::
   :maxdepth: 5

   installation.pypi
   installation.building
   installation.tracewin
   installation.cython
   installation.testing
   installation.troubleshooting
