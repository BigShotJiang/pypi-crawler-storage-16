"""Automatically compensate cavity failures in linacs."""

import importlib.metadata

__version__ = importlib.metadata.version("lightwin")
