"""Define functions used by the field maps.

.. todo::
    Mmmh... Looks like this module is pretty useless.

"""
