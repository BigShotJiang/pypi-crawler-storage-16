"""Define tools to evaluate a fit quality."""
