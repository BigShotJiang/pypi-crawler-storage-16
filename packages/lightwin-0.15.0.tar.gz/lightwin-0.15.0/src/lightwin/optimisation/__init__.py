"""This folder holds all the optimisation related modules."""
