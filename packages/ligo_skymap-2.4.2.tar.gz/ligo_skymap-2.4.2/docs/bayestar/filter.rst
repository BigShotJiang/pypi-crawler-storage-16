Matched Filtering (`ligo.skymap.bayestar.filter`)
=================================================

.. automodule:: ligo.skymap.bayestar.filter
    :members:
    :show-inheritance:
