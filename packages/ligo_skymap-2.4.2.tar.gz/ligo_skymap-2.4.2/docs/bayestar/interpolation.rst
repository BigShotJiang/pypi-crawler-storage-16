Sub-Sample SNR Interpolation (`ligo.skymap.bayestar.interpolation`)
===================================================================

.. automodule:: ligo.skymap.bayestar.interpolation
    :members:
    :show-inheritance:
