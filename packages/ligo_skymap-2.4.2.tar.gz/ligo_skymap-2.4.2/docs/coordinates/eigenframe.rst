Eigenframe (`ligo.skymap.coordinates.eigenframe`)
=================================================

.. automodule:: ligo.skymap.coordinates.eigenframe
    :members:
    :show-inheritance:
