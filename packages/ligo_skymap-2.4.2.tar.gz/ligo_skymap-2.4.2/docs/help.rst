Getting help
============

Users that are members of LIGO, Virgo, or KAGRA and have a @ligo.org email
address can post questions and get help in the `#ligo-skymap channel`_ on
`chat.ligo.org`_, the organization's `Mattermost`_ chat instance.

Users that do not have a @ligo.org email address can reach the author by email
directly at leo.singer@ligo.org.

For submitting bug reports or patches, see the :doc:`contributing` section.

.. _`#ligo-skymap channel`: https://chat.ligo.org/ligo/channels/ligo-skymap
.. _`chat.ligo.org`: https://chat.ligo.org/
.. _`Mattermost`: https://mattermost.com/
