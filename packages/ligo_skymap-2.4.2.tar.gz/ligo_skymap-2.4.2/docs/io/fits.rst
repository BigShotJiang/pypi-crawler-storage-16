Sky Map I/O (`ligo.skymap.io.fits`)
===================================

.. automodule:: ligo.skymap.io.fits
    :members:
    :show-inheritance:
