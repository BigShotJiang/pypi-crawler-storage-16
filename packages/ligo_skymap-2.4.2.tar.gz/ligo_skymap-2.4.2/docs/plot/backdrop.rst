Common All-Sky Bitmap Images (`ligo.skymap.plot.backdrop`)
==========================================================

.. automodule:: ligo.skymap.plot.backdrop
    :members:
    :show-inheritance:
