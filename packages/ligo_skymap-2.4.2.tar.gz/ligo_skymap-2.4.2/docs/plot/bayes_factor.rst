Bayes factor bullet charts (`ligo.skymap.plot.bayes_factor`)
============================================================

.. automodule:: ligo.skymap.plot.bayes_factor
    :members:
    :show-inheritance:
