Plot Markers (`ligo.skymap.plot.marker`)
========================================

.. autodata:: ligo.skymap.plot.marker.earth
.. autodata:: ligo.skymap.plot.marker.sun

.. automodule:: ligo.skymap.plot.marker
    :members:
    :show-inheritance:
