Uncertainty Ellipses (`ligo.skymap.postprocess.ellipse`)
========================================================

.. automodule:: ligo.skymap.postprocess.ellipse
    :members:
    :show-inheritance:
