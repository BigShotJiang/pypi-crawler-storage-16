Observing Scenarios Injection Tool (`bayestar-inject`)
======================================================

.. argparse::
    :module: ligo.skymap.tool.bayestar_inject
    :func: parser

Python helper functions
-----------------------

.. currentmodule:: ligo.skymap.tool.bayestar_inject
.. autoclass:: GWCosmo
