Offline Localization (`bayestar-localize-coincs`)
=================================================

.. argparse::
    :module: ligo.skymap.tool.bayestar_localize_coincs
    :func: parser
