Noise Curves (`bayestar-sample-model-psd`)
==========================================

.. argparse::
    :module: ligo.skymap.tool.bayestar_sample_model_psd
    :func: parser
