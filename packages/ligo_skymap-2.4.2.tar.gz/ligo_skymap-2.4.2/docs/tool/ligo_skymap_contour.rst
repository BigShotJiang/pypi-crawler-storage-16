GeoJSON Contours (`ligo-skymap-contour`)
========================================

.. argparse::
    :module: ligo.skymap.tool.ligo_skymap_contour
    :func: parser
