Flatten Multi-Resolution Sky Maps (`ligo-skymap-flatten`)
=========================================================

.. argparse::
    :module: ligo.skymap.tool.ligo_skymap_flatten
    :func: parser
