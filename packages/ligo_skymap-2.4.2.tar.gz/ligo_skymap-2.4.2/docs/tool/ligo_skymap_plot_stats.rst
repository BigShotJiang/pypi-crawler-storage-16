Plot Summary Statistics (`ligo-skymap-plot-stats`)
==================================================

.. argparse::
    :module: ligo.skymap.tool.ligo_skymap_plot_stats
    :func: parser
