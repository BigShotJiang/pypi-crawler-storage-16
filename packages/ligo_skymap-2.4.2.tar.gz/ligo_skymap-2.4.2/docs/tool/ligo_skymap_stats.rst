Gather Summary Statistics (`ligo-skymap-stats`)
===============================================

.. argparse::
    :module: ligo.skymap.tool.ligo_skymap_stats
    :func: parser
