File Utilities (`ligo.skymap.util.file`)
========================================

.. automodule:: ligo.skymap.util.file
    :members:
    :show-inheritance:
