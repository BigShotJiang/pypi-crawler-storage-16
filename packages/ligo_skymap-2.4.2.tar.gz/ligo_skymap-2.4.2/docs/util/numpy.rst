Numpy Utilities (`ligo.skymap.util.numpy`)
==========================================

.. automodule:: ligo.skymap.util.numpy
    :members:
    :show-inheritance:
