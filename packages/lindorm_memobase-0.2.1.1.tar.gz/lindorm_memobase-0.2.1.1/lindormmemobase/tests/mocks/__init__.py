"""Mock implementations for testing lindormmemobase."""
