import numpy as np
import matplotlib.pyplot as plt
from skimage.draw import line
from scipy.ndimage import gaussian_filter
from skimage.draw import disk
import cv2
import random
import imageio
import os
from PIL import Image, ImageFilter, ImageEnhance, ImageOps
def preprocess_image(image_path):
    # it does stuff to image to make it ready for processing
    img = Image.open(image_path).convert("L")
    img = img.filter(ImageFilter.EDGE_ENHANCE_MORE)
    img = ImageEnhance.Contrast(img).enhance(1)
    img = ImageOps.invert(img)
    img_array = np.array(img)
    return img_array
def generate_pins(num_pins, r):
    # It generated pins given the number of pins and the radius in a circle 
    angles = np.linspace(0, 2 * np.pi, num_pins, endpoint=False)
    pins = [(r+(r * np.cos(angle)), r+(r * np.sin(angle))) for angle in angles]
    for i in range(len(pins)):
        x, y = pins[i]
        x = max(0, min(2*r - 1, x))
        y = max(0, min(2*r - 1, y))
        pins[i] = (x, y)
    return pins
def display_board(board,pins):
    # Read the name if you dont understand this function
    plt.imshow(board, cmap="gray_r")
    plt.title("Pin Board Representation")
    plt.plot([x for x, y in pins], [y for x, y in pins], "ro", markersize=2)
    plt.show()
def generate_line(radius_size, pins, start_pin, end_pin, thickness=3, blur=1.0):
    # This generated the line between two pins with a thickness and a blur if you want
    size = radius_size * 2 + 1
    line_board = np.zeros((size, size), dtype=float)
    x0, y0 = pins[start_pin]
    x1, y1 = pins[end_pin]
    x0 = int(round(x0 + radius_size))
    y0 = int(round(y0 + radius_size))
    x1 = int(round(x1 + radius_size))
    y1 = int(round(y1 + radius_size))
    rr, cc = line(y0, x0, y1, x1)
    line_board[rr, cc] = 1.0
    if thickness > 1:
        for r, c in zip(rr, cc):
            rr_d, cc_d = disk((r, c), thickness, shape=line_board.shape)
            line_board[rr_d, cc_d] = 1.0
    if blur > 0:
        line_board = gaussian_filter(line_board, sigma=blur)
    return line_board * 0.3, rr, cc
def generate_line_pixels(pins, start_pin, end_pin):
    # This generated the pixels of a line between two pins
    y0, x0 = pins[start_pin]
    y1, x1 = pins[end_pin]
    rr, cc = line(int(y0), int(x0), int(y1), int(x1))
    return rr, cc
def mask_image(image_array:np.array,radius):
    # returns the image in a circle
    height, width = image_array.shape
    cy, cx = height / 2, width / 2
    Y, X = np.ogrid[:height, :width]
    mask = (X - cx)**2 + (Y - cy)**2 <= radius**2
    masked_image = np.zeros_like(image_array)
    masked_image[mask] = image_array[mask]
    return masked_image
def calculate_max_r(image_array:np.array):
    # calculates the maximum radius for the image
    height, width = image_array.shape
    return min(height, width) // 2
def put_image_to_board(radius_size,image_array:np.array, board_array:np.array):
    # puts the image onto the board at the center
    temp_board = board_array.copy()
    height, width = image_array.shape
    center_y, center_x = height // 2, width // 2
    for y in range(height):
        for x in range(width):
            if image_array[y, x] > 0:
                board_y = radius_size + (y - center_y)
                board_x = radius_size + (x - center_x)
                if 0 <= board_y < temp_board.shape[0] and 0 <= board_x < temp_board.shape[1]:
                    temp_board[board_y, board_x] += image_array[y, x]
    return temp_board
def draw_every_nth_line(board, lines, n=10, line_intensity=0.3, thickness=2):
    # Draws every nth line on the board
    new_board = board.copy()
    shape = new_board.shape
    sorted_keys = sorted(lines.keys())
    for i, key in enumerate(sorted_keys):
        if i % n == 0:
            rr, cc = lines[key]
            thick_rr = []
            thick_cc = []
            for r, c in zip(rr, cc):
                rr_d, cc_d = disk((r, c), thickness, shape=shape)
                thick_rr.extend(rr_d)
                thick_cc.extend(cc_d)
            thick_rr = np.array(thick_rr, dtype=int)
            thick_cc = np.array(thick_cc, dtype=int)
            mask = (thick_rr >= 0) & (thick_rr < shape[0]) & (thick_cc >= 0) & (thick_cc < shape[1])
            thick_rr = thick_rr[mask]
            thick_cc = thick_cc[mask]
            new_board[thick_rr, thick_cc] += line_intensity
    return new_board
def bresenham_path(start, end, board):
    # makes a path of pixels between two points using Bresenham's line algorithm
    x1, y1 = start
    x2, y2 = end
    x1 = max(0, min(round(x1), board.shape[0] - 1))
    y1 = max(0, min(round(y1), board.shape[1] - 1))
    x2 = max(0, min(round(x2), board.shape[0] - 1))
    y2 = max(0, min(round(y2), board.shape[1] - 1))
    dx = x2 - x1
    dy = y2 - y1
    path = []
    is_steep = abs(dy) > abs(dx)
    if is_steep:
        x1, y1 = y1, x1
        x2, y2 = y2, x2
    if x1 > x2:
        x1, x2 = x2, x1
        y1, y2 = y2, y1
    dx = x2 - x1
    dy = y2 - y1
    error = int(dx / 2.0)
    ystep = 1 if y1 < y2 else -1
    y = y1
    for x in range(x1, x2 + 1):
        if is_steep:
            path.append([y, x])
        else:
            path.append([x, y])
        error -= abs(dy)
        if error < 0:
            y += ystep
            error += dx
    return path

def find_best_next_nail(board_with_image, current, pins):
    # finds best nial to draw
    max_score = -float("inf")
    best_target = None
    best_data = None
    for target in range(len(pins)):
        if target != current:
            rr, cc = generate_line_pixels(pins, current, target)
            dark_pixels = board_with_image[rr, cc]
            score = np.sum(dark_pixels)
            if score > max_score:
                max_score = score
                best_target = target
                best_data = (rr, cc)
    return best_target, max_score, best_data


def render_as_gif(board_size, pins, list_of_pins, line_intensity, fps = 10, show_img = 2, filename="output.gif"):
    # renderes the board
    size = board_size * 2 + 1
    frames = []
    board_array = np.ones((size, size), dtype=float)
    
    target_fps = min(fps, 60)
    frame_skip = max(1, int(fps / 60)) if fps > 60 else 1
    
    for i in range(len(list_of_pins)-1):
        start_pin = list_of_pins[i]
        end_pin = list_of_pins[i+1]
        rr, cc = generate_line_pixels(pins, start_pin, end_pin)
        for r, c in zip(rr, cc):
            board_array[r, c]-=line_intensity
        board_array[board_array < 0] = 0
        
        if i % frame_skip == 0:
            frame = np.uint8(board_array * 255)
            frames.append(frame)
    
    for i in range(target_fps*show_img):
        frames.append(frame)
    imageio.mimsave(filename, frames, fps=target_fps)



def get_all_img(folder_path):
    # gets all images in a folder
    valid_extensions = ('.png', '.jpg', '.jpeg', '.bmp', '.tiff')
    img_files = [f for f in os.listdir(folder_path) if f.lower().endswith(valid_extensions)]
    img_paths = [os.path.join(folder_path, f) for f in img_files]
    folder_paths = [os.path.join(folder_path, d) for d in os.listdir(folder_path) if os.path.isdir(os.path.join(folder_path, d)) and not d.startswith('.')]
    for subfolder in folder_paths:
        img_paths.extend(get_all_img(subfolder))
    return img_paths
