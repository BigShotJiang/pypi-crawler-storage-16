"""
linkedin-jobs-api-py - Unofficial LinkedIn Jobs scraper API for Python
"""

__version__ = "0.1.0"
__all__ = ["query"]

from .client import query
