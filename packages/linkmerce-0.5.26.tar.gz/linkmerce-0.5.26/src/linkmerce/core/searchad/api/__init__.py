from linkmerce.core.searchad.api.common import NaverSearchAdAPI
