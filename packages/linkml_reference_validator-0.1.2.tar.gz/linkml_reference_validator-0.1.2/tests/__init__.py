"""Tests for linkml-reference-validator."""
