# -*- coding: UTF-8 -*-
# Copyright 2017 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)
"""Extended and specific plugins for Lino Noi.

.. autosummary::
   :toctree:

    contacts
    amici

"""
