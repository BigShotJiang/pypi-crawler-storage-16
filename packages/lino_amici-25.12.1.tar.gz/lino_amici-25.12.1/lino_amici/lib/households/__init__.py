from lino_xl.lib.households import Plugin
