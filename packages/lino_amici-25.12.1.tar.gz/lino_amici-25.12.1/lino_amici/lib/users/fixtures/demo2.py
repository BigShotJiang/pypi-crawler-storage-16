from lino.modlib.users.fixtures.demo2 import *
