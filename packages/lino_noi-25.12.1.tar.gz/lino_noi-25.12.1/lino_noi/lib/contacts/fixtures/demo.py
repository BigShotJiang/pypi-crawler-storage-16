from lino_xl.lib.contacts.fixtures.demo import objects
