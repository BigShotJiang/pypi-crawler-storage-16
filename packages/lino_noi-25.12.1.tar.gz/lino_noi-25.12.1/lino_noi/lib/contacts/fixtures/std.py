from lino_xl.lib.contacts.fixtures.std import *
