# -*- coding: UTF-8 -*-
# Copyright 2016-2018 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

# The default workflows_module for Lino Noi applications.

from lino_noi.lib.tickets.workflows import *
from lino_xl.lib.cal.workflows.voga import *
# from lino_xl.lib.courses.workflows import *
# from lino_xl.lib.meetings.workflows import *
