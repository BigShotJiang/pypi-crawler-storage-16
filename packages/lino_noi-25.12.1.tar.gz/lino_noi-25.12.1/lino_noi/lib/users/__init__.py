from lino.modlib.users import Plugin
