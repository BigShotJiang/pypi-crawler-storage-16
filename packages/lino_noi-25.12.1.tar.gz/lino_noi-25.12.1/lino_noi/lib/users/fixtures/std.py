from lino.modlib.users.fixtures.std import *
