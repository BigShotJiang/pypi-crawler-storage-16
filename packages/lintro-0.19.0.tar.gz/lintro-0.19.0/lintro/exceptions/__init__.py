"""Project-specific exception classes and error helpers."""
