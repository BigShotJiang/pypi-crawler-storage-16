"""Parsing utilities and types for Prettier output."""
