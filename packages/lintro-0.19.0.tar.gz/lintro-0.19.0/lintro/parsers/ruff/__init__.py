"""Ruff parser module."""
