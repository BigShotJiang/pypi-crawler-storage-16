"""Actionlint parser package."""
