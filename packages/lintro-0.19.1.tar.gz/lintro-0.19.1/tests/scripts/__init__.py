"""Tests for shell scripts in the scripts/ directory."""
