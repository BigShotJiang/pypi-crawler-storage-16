"""Lipi Lekhika is a library for transliterating text from one script to another."""

from .main import transliterate
