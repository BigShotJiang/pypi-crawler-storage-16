__author__ = 'Wanchang.Lin@liverpool.ac.uk, Warwick.Dunn@liverpool.ac.uk'
__credits__ = 'Wanchang.Lin@liverpool.ac.uk, Warwick.Dunn@liverpool.ac.uk'
__version__ = '1.0.0'
__license__ = 'GPLv3'
