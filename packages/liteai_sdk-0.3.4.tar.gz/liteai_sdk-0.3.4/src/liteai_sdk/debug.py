import litellm

def enable_debugging():
    litellm._turn_on_debug()
