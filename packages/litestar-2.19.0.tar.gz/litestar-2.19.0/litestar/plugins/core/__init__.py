from ._msgspec import MsgspecDIPlugin

__all__ = ("MsgspecDIPlugin",)
