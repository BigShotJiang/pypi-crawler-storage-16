# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import List, Optional
from typing_extensions import Literal, Required, TypedDict

from ..._types import SequenceNotStr
from .velocity_limit_period_param import VelocityLimitPeriodParam

__all__ = ["VelocityLimitParamsParam", "Filters"]


class Filters(TypedDict, total=False):
    exclude_countries: Optional[SequenceNotStr[str]]
    """ISO-3166-1 alpha-3 Country Codes to exclude from the velocity calculation.

    Transactions matching any of the provided will be excluded from the calculated
    velocity.
    """

    exclude_mccs: Optional[SequenceNotStr[str]]
    """Merchant Category Codes to exclude from the velocity calculation.

    Transactions matching this MCC will be excluded from the calculated velocity.
    """

    include_countries: Optional[SequenceNotStr[str]]
    """ISO-3166-1 alpha-3 Country Codes to include in the velocity calculation.

    Transactions not matching any of the provided will not be included in the
    calculated velocity.
    """

    include_mccs: Optional[SequenceNotStr[str]]
    """Merchant Category Codes to include in the velocity calculation.

    Transactions not matching this MCC will not be included in the calculated
    velocity.
    """

    include_pan_entry_modes: Optional[
        List[
            Literal[
                "AUTO_ENTRY",
                "BAR_CODE",
                "CONTACTLESS",
                "CREDENTIAL_ON_FILE",
                "ECOMMERCE",
                "ERROR_KEYED",
                "ERROR_MAGNETIC_STRIPE",
                "ICC",
                "KEY_ENTERED",
                "MAGNETIC_STRIPE",
                "MANUAL",
                "OCR",
                "SECURE_CARDLESS",
                "UNSPECIFIED",
                "UNKNOWN",
            ]
        ]
    ]
    """PAN entry modes to include in the velocity calculation.

    Transactions not matching any of the provided will not be included in the
    calculated velocity.
    """


class VelocityLimitParamsParam(TypedDict, total=False):
    filters: Required[Filters]

    period: Required[VelocityLimitPeriodParam]
    """Velocity over the current day since 00:00 / 12 AM in Eastern Time"""

    scope: Required[Literal["CARD", "ACCOUNT"]]
    """The scope the velocity is calculated for"""

    limit_amount: Optional[int]
    """
    The maximum amount of spend velocity allowed in the period in minor units (the
    smallest unit of a currency, e.g. cents for USD). Transactions exceeding this
    limit will be declined.
    """

    limit_count: Optional[int]
    """
    The number of spend velocity impacting transactions may not exceed this limit in
    the period. Transactions exceeding this limit will be declined. A spend velocity
    impacting transaction is a transaction that has been authorized, and optionally
    settled, or a force post (a transaction that settled without prior
    authorization).
    """
