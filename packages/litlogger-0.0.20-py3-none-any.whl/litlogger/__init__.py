from litlogger.logger import LightningLogger

__all__ = ["LightningLogger"]

__version__ = "0.0.20"
