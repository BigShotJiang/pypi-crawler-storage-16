"""
You can run the command with `python -m livesrt`
"""

from .cli import cli

if __name__ == "__main__":
    cli()
