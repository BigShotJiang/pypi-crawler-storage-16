"""
LiziEngine - 向量场可视化引擎
"""
__version__ = "2.0.0"
__author__ = "LiziEngine Team"
__description__ = "现代化的向量场可视化引擎"
