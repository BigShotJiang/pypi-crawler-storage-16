# code

[![PyPI - Version](https://img.shields.io/pypi/v/code.svg)](https://pypi.org/project/code)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/code.svg)](https://pypi.org/project/code)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install code
```

## License

`code` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
