# -*- coding: utf-8 -*-
# cython: language_level=3, always_allow_keywords=True


from ll.xist import xsc


xmlns = "http://purl.org/dc/elements/1.1/"


class type(xsc.Element):
	xmlns = xmlns
