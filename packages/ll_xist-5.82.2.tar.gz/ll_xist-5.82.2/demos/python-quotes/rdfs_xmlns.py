# -*- coding: utf-8 -*-
# cython: language_level=3, always_allow_keywords=True


from ll.xist import xsc


xmlns = "http://www.w3.org/2000/01/rdf-schema#"
