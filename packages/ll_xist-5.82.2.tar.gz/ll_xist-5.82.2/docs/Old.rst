Old history
===========

The following documents document changes or migration info for modules and
packages that where merged into XIST (starting with XIST 3.2) or into the
former core package (starting with XIST 2.12).

.. toctree::
   :maxdepth: 1

   OLDNEWS
   OLDMIGRATION
