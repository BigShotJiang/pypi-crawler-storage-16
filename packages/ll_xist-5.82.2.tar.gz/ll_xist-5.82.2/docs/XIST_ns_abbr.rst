:mod:`!abbr` -- Abbreviation entities
=====================================

.. automodule:: ll.xist.ns.abbr
