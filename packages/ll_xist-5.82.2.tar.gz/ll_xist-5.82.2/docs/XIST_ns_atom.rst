:mod:`!atom` -- Atom 1.0
========================

.. automodule:: ll.xist.ns.atom
