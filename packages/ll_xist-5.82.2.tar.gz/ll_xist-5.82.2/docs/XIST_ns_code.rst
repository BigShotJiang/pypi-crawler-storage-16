:mod:`!code` -- Embedding Python code in XML
============================================

.. automodule:: ll.xist.ns.code
