:mod:`!detox` -- Detox templates
================================

.. automodule:: ll.xist.ns.detox
