:mod:`!doc` -- Automated documentation generation
=================================================

.. automodule:: ll.xist.ns.doc
