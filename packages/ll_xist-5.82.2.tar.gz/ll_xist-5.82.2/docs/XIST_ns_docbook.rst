:mod:`!docbook` -- DocBook 5.0
==============================

.. automodule:: ll.xist.ns.docbook
