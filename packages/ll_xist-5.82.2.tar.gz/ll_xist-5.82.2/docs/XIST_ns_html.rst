:mod:`!html` -- HTML namespace
==============================

.. automodule:: ll.xist.ns.html
