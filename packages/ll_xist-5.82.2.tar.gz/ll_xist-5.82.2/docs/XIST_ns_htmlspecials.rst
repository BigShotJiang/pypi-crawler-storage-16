:mod:`!htmlspecials` -- Elements for HTML generation
====================================================

.. automodule:: ll.xist.ns.htmlspecials
