:mod:`!rss20` -- RSS 2.0
========================

.. automodule:: ll.xist.ns.rss20
