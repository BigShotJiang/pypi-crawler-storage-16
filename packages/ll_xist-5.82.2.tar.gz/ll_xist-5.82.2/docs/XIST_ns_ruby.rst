:mod:`!ruby` -- W3C Ruby annotations
====================================

.. automodule:: ll.xist.ns.ruby
