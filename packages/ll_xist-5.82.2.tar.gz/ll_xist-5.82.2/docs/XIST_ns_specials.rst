:mod:`!specials` -- Common useful elements
==========================================

.. automodule:: ll.xist.ns.specials
