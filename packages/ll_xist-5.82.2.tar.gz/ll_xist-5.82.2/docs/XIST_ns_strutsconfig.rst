:mod:`!struts_config` -- Struts configuration files
===================================================

.. automodule:: ll.xist.ns.struts_config
