:mod:`!svg` -- SVG 1.1
======================

.. automodule:: ll.xist.ns.svg
