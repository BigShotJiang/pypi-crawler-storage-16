:mod:`!toxic` -- Embed PL/SQL in XIST XML
=========================================

.. automodule:: ll.xist.ns.toxic
