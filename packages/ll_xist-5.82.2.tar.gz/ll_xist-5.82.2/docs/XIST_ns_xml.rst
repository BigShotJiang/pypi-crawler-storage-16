:mod:`!xml` -- Global attributes from the XML namespace
=======================================================

.. automodule:: ll.xist.ns.xml
