:mod:`!present` -- Screen output of XML trees
=============================================

.. automodule:: ll.xist.present
