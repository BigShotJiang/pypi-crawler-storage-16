.. _doc2txt:

:program:`doc2txt` -- Creating text files from XIST doc files
=============================================================

.. automodule:: ll.xist.scripts.doc2txt
