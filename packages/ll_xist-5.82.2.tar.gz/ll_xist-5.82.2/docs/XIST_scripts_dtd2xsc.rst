.. _dtd2xsc:

:program:`dtd2xsc` -- Creating XIST namespaces from DTDs
========================================================

.. automodule:: ll.xist.scripts.dtd2xsc
