.. _tld2xsc:

:program:`tld2xsc` -- Creating XIST namespaces from Java tag libraries
======================================================================

.. automodule:: ll.xist.scripts.tld2xsc
