.. _xml2xsc:

:program:`xml2xsc` -- Creating XIST namespaces from XML
=======================================================

.. automodule:: ll.xist.scripts.xml2xsc
