:mod:`!sims` -- Simple schema validation
========================================

.. automodule:: ll.xist.sims
