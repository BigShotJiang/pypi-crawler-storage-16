About us
========

Responsibility for contents
---------------------------

|	LivingLogic AG
|	Handelsregister Bayreuth HRB 3274
|	VAT number: DE208246480
|	Executive board: Dr. Alois Kastner-Maresch

Postal address
~~~~~~~~~~~~~~

|	Markgrafenallee 44
|	95448 Bayreuth


Copyright and trademark protection
----------------------------------

© LivingLogic AG 1999-2018.
All rights reserved.

All texts, images, graphics, multimedia databases and design of the LivingLogic
website are subject to copyright and other intellectual property protection.
Further use in any form requires the explicit approval from the LivingLogic AG.

Liability for contents
----------------------

The websites of the LivingLogic AG are maintained constantly and have been
prepared with utmost care. LivingLogic AG will however not assume liability for
accuracy and completeness of the information.

Disassociation
--------------

The hyperlinks found on the websites of the LivingLogic AG are not to be
regarded as recommendations. The accuracy and correctness of the information on
the linked pages is not monitored by the LivingLogic AG. The LivingLogic AG is
not responsible for the contents of the linked websites and accepts no liability
for damages that might arise from the use of such information.
