:mod:`!ll.misc` -- Utility functions and classes
================================================

.. automodule:: ll.misc
