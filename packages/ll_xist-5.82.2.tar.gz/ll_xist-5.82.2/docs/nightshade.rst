:mod:`!ll.nightshade` -- Using Oracle with CherryPy
===================================================

.. automodule:: ll.nightshade
