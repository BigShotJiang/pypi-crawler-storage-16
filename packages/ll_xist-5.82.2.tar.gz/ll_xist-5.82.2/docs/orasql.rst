:mod:`!ll.orasql` -- Utilities for :mod:`cx_Oracle`
===================================================

.. automodule:: ll.orasql

.. toctree::
   :maxdepth: 2

   orasql_scripts
