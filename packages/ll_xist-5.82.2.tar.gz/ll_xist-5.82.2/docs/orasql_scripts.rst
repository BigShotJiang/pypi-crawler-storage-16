:mod:`!scripts` -- Oracle related scripts
=========================================

.. automodule:: ll.orasql.scripts

.. toctree::
   :maxdepth: 1
   :caption: Package content
   :name: oracle_scripts_content

   orasql_scripts_oracreate
   orasql_scripts_oradrop
   orasql_scripts_oradelete
   orasql_scripts_oragrant
   orasql_scripts_orafind
   orasql_scripts_oradiff
   orasql_scripts_oramerge
   orasql_scripts_orareindex
   orasql_scripts_oracycles
