.. _oracreate:

:program:`oracreate` -- Printing a schema definition
====================================================

.. automodule:: ll.orasql.scripts.oracreate
