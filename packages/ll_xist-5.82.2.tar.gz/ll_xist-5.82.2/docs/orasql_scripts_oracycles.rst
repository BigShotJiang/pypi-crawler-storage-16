.. _oracycles:

:program:`oracycles` -- Finding cyclic foreign keys
===================================================

.. automodule:: ll.orasql.scripts.oracycles
