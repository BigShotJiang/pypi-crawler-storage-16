.. _oradelete:

:program:`oradelete` -- Deleting all records
============================================

.. automodule:: ll.orasql.scripts.oradelete
