.. _oradiff:

:program:`oradiff` -- Diffing two schemas
=========================================

.. automodule:: ll.orasql.scripts.oradiff
