.. _oradrop:

:program:`oradrop` -- Deleting a schema definition
==================================================

.. automodule:: ll.orasql.scripts.oradrop
