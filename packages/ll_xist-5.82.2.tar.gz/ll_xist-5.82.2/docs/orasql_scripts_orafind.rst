.. _orafind:

:program:`orafind` -- Finding records in a schema
=================================================

.. automodule:: ll.orasql.scripts.orafind
