.. _oragrant:

:program:`oragrant` -- Printing permissions for a schema
========================================================

.. automodule:: ll.orasql.scripts.oragrant
