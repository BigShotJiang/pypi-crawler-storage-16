.. _oramerge:

:program:`oramerge` -- Three-way merging of schemas
===================================================

.. automodule:: ll.orasql.scripts.oramerge
