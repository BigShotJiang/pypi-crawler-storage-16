.. _orareindex:

:program:`orareindex` -- Recreating indexes/constraints
=======================================================

.. automodule:: ll.orasql.scripts.orareindex
