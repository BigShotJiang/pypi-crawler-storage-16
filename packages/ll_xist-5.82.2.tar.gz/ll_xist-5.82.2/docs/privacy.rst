Datenschutzerklärung
====================

Wir respektieren Ihre Privatsphäre.

Unsere Datenschutzpraxis steht im Einklang mit dem Bundesdatenschutzgesetz
(BDSG) und dem Telemediengesetz (TMG).

Verantwortliche Stelle im Sinne der Datenschutzgesetze ist die LivingLogic AG,
Markgrafenallee 44, 95448 Bayreuth, vertreten durch den Vorstand
Dr. Alois Kastner-Maresch.

Wir haben einen betrieblichen Datenschutzbeauftragten bestellt.

Wenn Sie eine Webseite besuchen, speichert der zugrundeliegende Webserver immer
die IP-Adresse Ihres Providers, die Webseite, die Sie vorher besucht haben, die
Webseiten, die Sie auf dem Webserver abrufen sowie das Datum und die Dauer Ihres
Besuchs. Diese Informationen sind für die technische Übermittlung der Webseiten
und den Serverbetrieb erforderlich. LivingLogic garantiert Ihnen, dass keine
personalisierte Auswertung dieser Daten erfolgt und dass diese Daten weder im
Rohzustand noch in einem ausgewerteten Zustand an Dritte weitergegeben werden.
Die gespeicherten Daten werden nur zur Weiterentwicklung der Website von
LivingLogic im Interesse der Nutzer ausgewertet.
