.. _ucp:

:program:`ucp` -- Copying files/directories
===========================================

.. automodule:: ll.scripts.ucp
