.. _udiff:

:program:`udiff` -- Diffing files/directories
=============================================

.. automodule:: ll.scripts.udiff
