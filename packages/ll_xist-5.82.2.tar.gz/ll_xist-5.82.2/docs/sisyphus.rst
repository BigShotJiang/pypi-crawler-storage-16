:mod:`!ll.sisyphus` -- Writing jobs with Python
===============================================

.. automodule:: ll.sisyphus
