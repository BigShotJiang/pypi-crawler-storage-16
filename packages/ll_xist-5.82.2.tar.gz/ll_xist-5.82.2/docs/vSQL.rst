:mod:`!ll.vsql` -- Half an ORM
==============================

.. automodule:: ll.vsql
