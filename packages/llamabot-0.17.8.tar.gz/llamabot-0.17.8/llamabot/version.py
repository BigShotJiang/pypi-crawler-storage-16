"""Version information for llamabot."""

version = "0.17.8"
