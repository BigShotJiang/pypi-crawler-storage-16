from enum import Enum


class PrintingStatus(Enum):
    Thought = "thought"
    Response = "response"
