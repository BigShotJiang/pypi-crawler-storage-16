"""Command-line interface for the LLM completion library."""

# Ensure the CLI directory is recognized as a Python package