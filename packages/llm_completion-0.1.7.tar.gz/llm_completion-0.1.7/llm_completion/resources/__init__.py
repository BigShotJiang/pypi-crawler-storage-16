"""Resource modules for the LLM completion library."""

# Ensure the resources directory is recognized as a Python package