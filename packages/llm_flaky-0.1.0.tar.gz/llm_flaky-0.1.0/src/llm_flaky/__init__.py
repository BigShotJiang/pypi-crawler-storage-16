"""llm-flaky - Pytest plugin for non-deterministic LLM tests."""

__version__ = "0.1.0"
