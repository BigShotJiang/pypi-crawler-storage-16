## TODO Task List
- [x] cache the code assist project id after first retrieval
- [x] implement model listing for code assist models
- [x] fix tests
- [ ] verify github workflows and publishing steps
- [x] validate tool calling and other modes
- [x] validate llm gemini-ca auth command
- [x] clean up code by removing all reference to API key usage
- [x] remove references to the GOOGLE_CLOUD_PROJECT env var
