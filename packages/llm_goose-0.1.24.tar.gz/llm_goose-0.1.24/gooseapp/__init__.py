"""Goose application package."""

from __future__ import annotations

from gooseapp.app import app

__all__ = ["app"]
