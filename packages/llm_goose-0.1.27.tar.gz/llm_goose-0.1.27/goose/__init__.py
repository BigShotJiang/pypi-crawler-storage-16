"""Goose - LLM agent development toolkit."""

from __future__ import annotations

from goose.core.app import GooseApp

__all__ = ["GooseApp"]
