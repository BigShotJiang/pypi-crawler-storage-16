"""Tooling module for Goose - browse and invoke LangChain tools."""

from __future__ import annotations
