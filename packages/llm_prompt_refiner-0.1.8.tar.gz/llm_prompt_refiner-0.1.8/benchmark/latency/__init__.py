"""Latency benchmark for prompt-refiner."""
