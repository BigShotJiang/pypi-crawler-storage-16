"""Analyzer module - Operations for analyzing and reporting on text."""

from .counter import CountTokens

__all__ = ["CountTokens"]
