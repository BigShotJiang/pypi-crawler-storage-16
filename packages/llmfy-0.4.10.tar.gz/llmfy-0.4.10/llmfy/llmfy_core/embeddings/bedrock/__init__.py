from .bedrock_embedding import BedrockEmbedding

__all__ = [
    "BedrockEmbedding",
]
