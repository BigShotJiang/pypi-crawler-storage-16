"""Skills package for Claude Code Skills support."""

from llmling_agent.skills.manager import SkillsManager

__all__ = ["SkillsManager"]
