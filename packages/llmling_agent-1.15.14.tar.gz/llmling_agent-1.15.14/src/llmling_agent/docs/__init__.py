"""Example / Docs helpers."""
