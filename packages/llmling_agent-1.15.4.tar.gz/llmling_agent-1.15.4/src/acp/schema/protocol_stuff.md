Stdio MCP server type discriminator
ReadTextFileRequest.line should be ge 1, not ge 0?
AudioContentBlock should have "uri"?
