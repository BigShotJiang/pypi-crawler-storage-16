"""Example comparing sequential and parallel downloads with agents."""

TITLE = "Download Agents"
ICON = "octicon:download-16"
