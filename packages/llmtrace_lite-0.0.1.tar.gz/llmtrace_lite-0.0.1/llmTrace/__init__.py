"""
llmtrace-lite: Zero-config decorator for tracing LLM calls.
"""

from .trace import trace

__all__ = ['trace']
__version__ = '0.1.0'
