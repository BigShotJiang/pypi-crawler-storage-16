"""Integration tests for lm-cloud-sync."""
