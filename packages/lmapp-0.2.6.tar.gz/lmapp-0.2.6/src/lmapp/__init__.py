"""lmapp - Local LLM Made Simple"""

__version__ = "0.2.6"
__author__ = "lmapp Contributors"
__license__ = "MIT"
