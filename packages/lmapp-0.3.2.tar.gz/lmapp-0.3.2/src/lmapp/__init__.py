"""lmapp - Local LLM Made Simple"""

__version__ = "0.3.2"
__author__ = "lmapp Contributors"
__license__ = "MIT"
