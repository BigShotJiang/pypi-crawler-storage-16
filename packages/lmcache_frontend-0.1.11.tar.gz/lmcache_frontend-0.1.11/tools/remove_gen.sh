(cd "$(dirname "$0")" && rm -rf ../dist ../build ../*.egg-info)
