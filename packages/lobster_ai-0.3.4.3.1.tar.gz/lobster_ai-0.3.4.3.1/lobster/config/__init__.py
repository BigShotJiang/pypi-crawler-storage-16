"""
Configuration module.

This module handles application configuration settings, providing
centralized configuration management for the application.
"""
