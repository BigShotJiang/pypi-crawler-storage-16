def main():
    print("Hello from lobster!")


if __name__ == "__main__":
    main()
