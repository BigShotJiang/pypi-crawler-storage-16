"""
Data formatting utilities for Rich displays.

This module contains utilities for formatting bioinformatics data
for display in Rich UI components with proper styling and branding.
"""
