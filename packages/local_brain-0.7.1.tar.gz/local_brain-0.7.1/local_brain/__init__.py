"""Local Brain - Chat with local Ollama models that can use tools."""

__version__ = "0.7.1"
