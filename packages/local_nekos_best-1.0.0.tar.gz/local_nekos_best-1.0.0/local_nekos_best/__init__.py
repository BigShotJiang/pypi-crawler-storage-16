"""
local-nekos-best - Lightning fast access to nekos.best anime gifs and images.

Zero API calls, no rate limits, instant responses.
"""

from .core import (
    call_neko,
    call_neko_intent,
    call_neko_actions,
    call_neko_count,
    call_neko_load,
    VALID_ACTIONS,
    IMAGE_CATEGORIES,
    CONTENT_TYPES,
    MODES,
)

__version__ = "1.0.0"
__all__ = [
    # Main functions
    "call_neko",
    "call_neko_intent",
    "call_neko_actions",
    "call_neko_count",
    "call_neko_load",
    # Constants
    "VALID_ACTIONS",
    "IMAGE_CATEGORIES",
    "CONTENT_TYPES",
    "MODES",
]
