import json
import math
import random
from pathlib import Path
from typing import Any

# ============================================================================
# Constants
# ============================================================================

VALID_ACTIONS: list[str] = [
    "angry",
    "baka",
    "bite",
    "blush",
    "bored",
    "cry",
    "cuddle",
    "dance",
    "facepalm",
    "feed",
    "handhold",
    "handshake",
    "happy",
    "highfive",
    "hug",
    "husbando",
    "kick",
    "kiss",
    "kitsune",
    "laugh",
    "lurk",
    "neko",
    "nod",
    "nom",
    "nope",
    "pat",
    "peck",
    "poke",
    "pout",
    "punch",
    "run",
    "shoot",
    "shrug",
    "slap",
    "sleep",
    "smile",
    "smug",
    "stare",
    "think",
    "thumbsup",
    "tickle",
    "waifu",
    "wave",
    "wink",
    "yawn",
    "yeet",
]

# Categories that return image type (type 1) instead of GIF type (type 2)
IMAGE_CATEGORIES: set[str] = {"husbando", "kitsune", "neko", "waifu"}


class CONTENT_TYPES:
    """Content type constants."""
    IMAGE: int = 1
    GIF: int = 2
    BOTH: int = 3


class MODES:
    """Selection mode constants."""
    RANDOM: str = "random"
    DISTRIBUTED: str = "distributed"
    EACH: str = "each"


# Type aliases for normalization
TYPE_ALIASES: dict[int | str, int] = {
    1: CONTENT_TYPES.IMAGE,
    2: CONTENT_TYPES.GIF,
    3: CONTENT_TYPES.BOTH,
    "image": CONTENT_TYPES.IMAGE,
    "images": CONTENT_TYPES.IMAGE,
    "gif": CONTENT_TYPES.GIF,
    "gifs": CONTENT_TYPES.GIF,
    "both": CONTENT_TYPES.BOTH,
}

# Mode aliases for normalization
MODE_ALIASES: dict[int | str, str] = {
    1: MODES.RANDOM,
    2: MODES.DISTRIBUTED,
    3: MODES.EACH,
    "random": MODES.RANDOM,
    "distributed": MODES.DISTRIBUTED,
    "each": MODES.EACH,
}

# Valid metadata fields for images and gifs
METADATA_FIELDS: dict[str, list[str]] = {
    "IMAGE": ["artist_href", "artist_name", "source_url"],
    "GIF": ["anime_name"],
}

# Configuration constants
CONFIG: dict[str, Any] = {
    "MAX_RETRY_ATTEMPTS": 50,
    "BASE_URL": "https://nekos.best/api/v2",
}

# ============================================================================
# Intent State Management
# ============================================================================


class _IntentConfig:
    """Intent configuration - set once at initialization."""
    
    def __init__(self) -> None:
        self.active: bool = False
        self.metadata: list[str] | None = None  # None = all, [] = none, [...fields] = specific
        self.type: int = CONTENT_TYPES.BOTH
        self.allowed_categories: set[str] = set(VALID_ACTIONS)


_intent_config = _IntentConfig()
_intent_locked: bool = False

# ============================================================================
# State Management
# ============================================================================

# Load raw data at module initialization
_data_path = Path(__file__).parent / "data.json"
with open(_data_path, "r", encoding="utf-8") as f:
    _raw_gifs_data: dict[str, list[dict[str, Any]]] | None = json.load(f)

# Active data based on intent (initially full data)
_gifs_data: dict[str, list[dict[str, Any]]] = dict(_raw_gifs_data) if _raw_gifs_data else {}

# ============================================================================
# Helper Functions
# ============================================================================


def _get_content_type(category: str) -> int:
    """
    Determines the content type based on category.
    
    Args:
        category: The category name
        
    Returns:
        Content type (1 for images, 2 for GIFs)
    """
    return CONTENT_TYPES.IMAGE if category in IMAGE_CATEGORIES else CONTENT_TYPES.GIF


def _construct_full_url(filename: str) -> str:
    """
    Constructs full URL from filename.
    
    Args:
        filename: The filename (e.g., /angry/uuid.gif)
        
    Returns:
        Full URL
    """
    return f"{CONFIG['BASE_URL']}{filename}"


def _should_include_metadata_field(field: str, category: str) -> bool:
    """
    Checks if a metadata field should be included based on intent.
    
    Args:
        field: The metadata field name
        category: The category name
        
    Returns:
        True if field should be included
    """
    # If no intent is active, include all fields
    if not _intent_config.active:
        return True

    # If metadata is None (all for current type), check if field is valid for category type
    if _intent_config.metadata is None:
        category_type = _get_content_type(category)
        if category_type == CONTENT_TYPES.IMAGE:
            return field in METADATA_FIELDS["IMAGE"]
        else:
            return field in METADATA_FIELDS["GIF"]

    # If metadata is empty list (none), include no fields
    if len(_intent_config.metadata) == 0:
        return False

    # Check if field is in the allowed list
    return field in _intent_config.metadata


def _create_response_object(item: dict[str, Any], category: str) -> dict[str, Any]:
    """
    Creates a properly formatted response object with all required fields.
    
    Args:
        item: Raw item data
        category: The category name
        
    Returns:
        Formatted response object
    """
    base_response: dict[str, Any] = {
        "url": _construct_full_url(item["url"]),
        "action": category,
        "type": _get_content_type(category),
    }

    if category in IMAGE_CATEGORIES:
        if _should_include_metadata_field("artist_href", category):
            base_response["artist_href"] = item.get("artist_href")
        if _should_include_metadata_field("artist_name", category):
            base_response["artist_name"] = item.get("artist_name")
        if _should_include_metadata_field("source_url", category):
            base_response["source_url"] = item.get("source_url")
    else:
        if _should_include_metadata_field("anime_name", category):
            base_response["anime_name"] = item.get("anime_name")

    return base_response


def _validate_intent_action(action: str) -> None:
    """
    Validates that requested action is allowed by current intent.
    
    Args:
        action: Action to validate
        
    Raises:
        ValueError: If action not allowed by intent
    """
    if _intent_config.active and action not in _intent_config.allowed_categories:
        action_type = _get_content_type(action)
        if _intent_config.type == CONTENT_TYPES.IMAGE:
            intent_type_str = "images"
        elif _intent_config.type == CONTENT_TYPES.GIF:
            intent_type_str = "GIFs"
        else:
            intent_type_str = "both"

        raise ValueError(
            f'Action "{action}" (type: {"image" if action_type == CONTENT_TYPES.IMAGE else "gif"}) '
            f"was not specified in intent (type: {intent_type_str}). "
            f"Intent only allows: {', '.join(_intent_config.allowed_categories)}"
        )


def _normalize_type(type_val: Any) -> int:
    """
    Normalizes type parameter to content type number.
    
    Args:
        type_val: Type parameter (string, number, or None)
        
    Returns:
        Valid content type
    """
    if type_val is None:
        return CONTENT_TYPES.BOTH

    normalized = TYPE_ALIASES.get(type_val)
    if normalized is not None:
        return normalized

    if type_val in [1, 2, 3]:
        return type_val

    return CONTENT_TYPES.BOTH


def _normalize_mode(mode: Any) -> str:
    """
    Normalizes mode parameter to mode string.
    
    Args:
        mode: Mode parameter (string, number, or None)
        
    Returns:
        Valid mode string
    """
    if mode is None:
        return MODES.RANDOM

    normalized = MODE_ALIASES.get(mode)
    if normalized is not None:
        return normalized

    if mode in [MODES.RANDOM, MODES.DISTRIBUTED, MODES.EACH]:
        return mode

    return MODES.RANDOM


def _normalize_actions(actions: Any) -> list[str]:
    """
    Normalizes actions parameter to list of action strings.
    
    Args:
        actions: Actions parameter (string, list, or None)
        
    Returns:
        List of action strings
    """
    if actions is None:
        # If intent is active, return only allowed categories
        if _intent_config.active:
            return list(_intent_config.allowed_categories)
        return list(VALID_ACTIONS)

    action_list = actions if isinstance(actions, list) else [actions]

    invalid_actions = [a for a in action_list if a not in VALID_ACTIONS]
    if invalid_actions:
        raise ValueError(
            f"Invalid actions: {', '.join(invalid_actions)}. "
            f"Valid actions: {', '.join(VALID_ACTIONS)}"
        )

    # Validate against intent
    for action in action_list:
        _validate_intent_action(action)

    return action_list


def _normalize_search(search: Any) -> list[str]:
    """
    Normalizes search parameter to list of search strings.
    
    Args:
        search: Search parameter (string, list, or None)
        
    Returns:
        List of search strings (empty list means no filter)
    """
    if search is None or search == "":
        return []

    search_list = search if isinstance(search, list) else [search]
    return [
        s.strip() for s in search_list
        if isinstance(s, str) and s.strip()
    ]


def _matches_content_type(category: str, content_type: int) -> bool:
    """
    Checks if a category matches the content type filter.
    
    Args:
        category: The category name
        content_type: The content type filter
        
    Returns:
        True if category matches content type
    """
    if content_type == CONTENT_TYPES.BOTH:
        return True

    item_type = _get_content_type(category)
    return item_type == content_type


def _matches_search(item: dict[str, Any], category: str, search_terms: list[str]) -> bool:
    """
    Checks if an item matches any of the search criteria.
    
    Args:
        item: The item to check
        category: The category name
        search_terms: List of search terms
        
    Returns:
        True if item matches any search term (or if no search terms)
    """
    if not search_terms:
        return True

    search_field = item.get("artist_name") if category in IMAGE_CATEGORIES else item.get("anime_name")

    if not search_field:
        return False

    field_lower = search_field.lower()
    return any(term.lower() in field_lower for term in search_terms)


def _validate_and_filter_categories(categories: list[str], content_type: int) -> list[str]:
    """
    Validates and filters categories by content type.
    
    Args:
        categories: Categories to filter
        content_type: Content type filter
        
    Returns:
        Valid categories
        
    Raises:
        ValueError: If no categories match content type
    """
    filtered = [cat for cat in categories if _matches_content_type(cat, content_type)]

    if not filtered:
        if content_type == CONTENT_TYPES.IMAGE:
            type_str = "images"
        elif content_type == CONTENT_TYPES.GIF:
            type_str = "GIFs"
        else:
            type_str = "both"
        raise ValueError(
            f"No categories match content type filter ({type_str}). "
            f"Image categories: {', '.join(IMAGE_CATEGORIES)}"
        )

    return filtered


def _build_search_filtered_categories(
    categories: list[str], search_terms: list[str]
) -> dict[str, list[dict[str, Any]]]:
    """
    Pre-filters all categories by search terms and returns a dict of filtered items.
    
    Args:
        categories: Categories to filter
        search_terms: Search filter terms
        
    Returns:
        Dict of category to filtered items
    """
    filtered_map: dict[str, list[dict[str, Any]]] = {}

    for category in categories:
        category_items = _gifs_data.get(category)
        if not category_items:
            continue

        filtered = [
            item for item in category_items
            if _matches_search(item, category, search_terms)
        ]

        if filtered:
            filtered_map[category] = filtered

    return filtered_map


def _get_random_items(
    items: list[dict[str, Any]],
    count: int,
    category: str,
    allow_duplicates: bool = False
) -> list[dict[str, Any]]:
    """
    Gets random items from pre-filtered items with duplicate control.
    
    Args:
        items: List of items
        count: Number of items to return
        category: The category name
        allow_duplicates: Whether to allow duplicate items
        
    Returns:
        List of selected items
    """
    available = len(items)

    if available == 0:
        return []

    if not allow_duplicates and count >= available:
        return [_create_response_object(item, category) for item in items]

    result: list[dict[str, Any]] = []

    if allow_duplicates:
        for _ in range(count):
            random_item = items[random.randint(0, available - 1)]
            result.append(_create_response_object(random_item, category))
    else:
        indices = list(range(available))
        actual_count = min(count, available)

        for i in range(actual_count):
            random_index = i + random.randint(0, available - i - 1)
            indices[i], indices[random_index] = indices[random_index], indices[i]
            result.append(_create_response_object(items[indices[i]], category))

    return result


def _select_random_mode(
    amount: int,
    categories: list[str],
    search_terms: list[str],
    allow_duplicates: bool
) -> list[dict[str, Any]]:
    """
    Selects items using random mode.
    """
    # Build filtered items map first (search priority)
    filtered_map = _build_search_filtered_categories(categories, search_terms)
    available_categories = list(filtered_map.keys())

    if not available_categories:
        return []

    if len(available_categories) == 1:
        category = available_categories[0]
        return _get_random_items(
            filtered_map[category],
            amount,
            category,
            allow_duplicates
        )

    result: list[dict[str, Any]] = []
    used_urls: set[str] = set()

    for _ in range(amount):
        random_category = available_categories[random.randint(0, len(available_categories) - 1)]
        category_items = filtered_map[random_category]

        if allow_duplicates:
            random_item = category_items[random.randint(0, len(category_items) - 1)]
            result.append(_create_response_object(random_item, random_category))
        else:
            attempts = 0
            found_unique = False

            while attempts < CONFIG["MAX_RETRY_ATTEMPTS"] and not found_unique:
                random_item = category_items[random.randint(0, len(category_items) - 1)]
                url = _construct_full_url(random_item["url"])

                if url not in used_urls:
                    result.append(_create_response_object(random_item, random_category))
                    used_urls.add(url)
                    found_unique = True
                attempts += 1

            if not found_unique:
                break

    return result


def _select_distributed_mode(
    amount: int,
    categories: list[str],
    search_terms: list[str],
    allow_duplicates: bool
) -> list[dict[str, Any]]:
    """
    Selects items using distributed mode.
    """
    # Build filtered items map first (search priority)
    filtered_map = _build_search_filtered_categories(categories, search_terms)
    available_categories = list(filtered_map.keys())

    if not available_categories:
        return []

    result: list[dict[str, Any]] = []
    base_amount = amount // len(available_categories)
    remainder = amount % len(available_categories)

    for index, cat in enumerate(available_categories):
        category_amount = base_amount + 1 if index < remainder else base_amount
        items = _get_random_items(
            filtered_map[cat],
            category_amount,
            cat,
            allow_duplicates
        )
        result.extend(items)

    return result


def _select_each_mode(
    amount: int,
    categories: list[str],
    search_terms: list[str],
    allow_duplicates: bool
) -> list[dict[str, Any]]:
    """
    Selects items using each mode.
    """
    # Build filtered items map first (search priority)
    filtered_map = _build_search_filtered_categories(categories, search_terms)
    available_categories = list(filtered_map.keys())

    if not available_categories:
        return []

    result: list[dict[str, Any]] = []

    for cat in available_categories:
        items = _get_random_items(
            filtered_map[cat],
            amount,
            cat,
            allow_duplicates
        )
        result.extend(items)

    return result


def _parse_options(
    amount: int = 1,
    actions: Any = None,
    search: Any = None,
    type: Any = None,
    mode: Any = None,
    dupe: bool = False
) -> dict[str, Any]:
    """
    Parses and validates options.
    
    Returns:
        Normalized options dict
    """
    # Validate amount is a valid number
    if not isinstance(amount, (int, float)) or not math.isfinite(amount) or amount < 1:
        raise ValueError("Amount must be a finite number greater than or equal to 1")

    normalized_actions = _normalize_actions(actions)
    normalized_search = _normalize_search(search)
    normalized_type = _normalize_type(type)
    normalized_mode = _normalize_mode(mode)

    valid_actions = _validate_and_filter_categories(normalized_actions, normalized_type)

    return {
        "amount": int(amount),
        "actions": valid_actions,
        "search": normalized_search,
        "type": normalized_type,
        "mode": normalized_mode,
        "dupe": bool(dupe),
    }


# ============================================================================
# Public API Functions
# ============================================================================


def call_neko_intent(
    *,
    metadata: int | bool | list[str] | None = None,
    type: int | str = 3
) -> None:
    """
    Configures what data to load in memory (one-time setup).
    Once set, cannot be changed. Must be called before any other function.
    
    Args:
        metadata: Metadata to load: 0/False=none, 1/True=all, list=specific fields
        type: Content type: 1/'images', 2/'gifs', 3/'both'
        
    Raises:
        ValueError: If intent already set or invalid parameters
        
    Example:
        >>> # Load only anime_name metadata, only GIFs
        >>> call_neko_intent(metadata=["anime_name"], type=2)
        
        >>> # Load no metadata, only images
        >>> call_neko_intent(metadata=0, type=1)
    """
    global _intent_locked, _intent_config, _raw_gifs_data, _gifs_data

    if _intent_locked:
        raise ValueError(
            "Intent already configured. call_neko_intent() can only be called once per session."
        )

    # Normalize type
    normalized_type = _normalize_type(type)

    # Determine allowed categories based on type
    allowed_categories: set[str] = set()
    for action in VALID_ACTIONS:
        action_type = _get_content_type(action)
        if normalized_type == CONTENT_TYPES.BOTH or action_type == normalized_type:
            allowed_categories.add(action)

    # Normalize metadata parameter
    metadata_fields: list[str | None] = None

    if metadata is None:
        # Default: load all metadata
        metadata_fields = None
    elif metadata == 0 or metadata is False:
        # Load no metadata
        metadata_fields = []
    elif metadata == 1 or metadata is True:
        # Load all metadata
        metadata_fields = None
    elif isinstance(metadata, list):
        # Load specific fields, but filter based on type
        requested_fields = [f.strip() for f in metadata if isinstance(f, str) and f.strip()]

        # Validate that requested fields are valid
        all_valid_fields = METADATA_FIELDS["IMAGE"] + METADATA_FIELDS["GIF"]
        invalid_fields = [f for f in requested_fields if f not in all_valid_fields]
        if invalid_fields:
            raise ValueError(
                f"Invalid metadata fields: {', '.join(invalid_fields)}. "
                f"Valid fields: {', '.join(all_valid_fields)}"
            )

        # Filter fields based on type - exclude irrelevant metadata
        metadata_fields = []

        if normalized_type == CONTENT_TYPES.GIF or normalized_type == CONTENT_TYPES.BOTH:
            metadata_fields.extend([f for f in requested_fields if f in METADATA_FIELDS["GIF"]])

        if normalized_type == CONTENT_TYPES.IMAGE or normalized_type == CONTENT_TYPES.BOTH:
            metadata_fields.extend([f for f in requested_fields if f in METADATA_FIELDS["IMAGE"]])
    else:
        raise ValueError(
            "metadata must be 0/False (none), 1/True (all), or list of field names"
        )

    # When type is IMAGE or GIF only, automatically filter metadata
    if metadata_fields is None:
        # If loading all metadata but only one type, filter appropriately
        if normalized_type == CONTENT_TYPES.IMAGE:
            metadata_fields = list(METADATA_FIELDS["IMAGE"])
        elif normalized_type == CONTENT_TYPES.GIF:
            metadata_fields = list(METADATA_FIELDS["GIF"])
        # else BOTH: keep None to load all

    # Update intent configuration and lock it
    _intent_config.active = True
    _intent_config.metadata = metadata_fields
    _intent_config.type = normalized_type
    _intent_config.allowed_categories = allowed_categories
    _intent_locked = True

    # Rebuild data based on intent
    _gifs_data.clear()
    if _raw_gifs_data:
        for category in allowed_categories:
            if category in _raw_gifs_data:
                _gifs_data[category] = _raw_gifs_data[category]

    # Free memory from unused categories
    _raw_gifs_data = None


def call_neko_load() -> dict[str, list[dict[str, Any]]]:
    """
    Returns the entire data set with constructed URLs (respects intent).
    
    Returns:
        Dict containing all categories with their data and constructed URLs
        
    Example:
        >>> data = call_neko_load()
        >>> print(data["hug"])
    """
    result: dict[str, list[dict[str, Any]]] = {}

    categories_to_load = (
        list(_intent_config.allowed_categories)
        if _intent_config.active
        else VALID_ACTIONS
    )

    for category in categories_to_load:
        if category in _gifs_data:
            result[category] = [
                _create_response_object(item, category)
                for item in _gifs_data[category]
            ]

    return result


def call_neko_actions() -> list[str]:
    """
    Returns all available action categories (respects intent).
    
    Returns:
        List of valid action names
        
    Example:
        >>> actions = call_neko_actions()
        >>> print(actions)
    """
    if _intent_config.active:
        return list(_intent_config.allowed_categories)
    return list(VALID_ACTIONS)


def call_neko_count() -> dict[str, Any]:
    """
    Returns statistics about available content (respects intent).
    
    Returns:
        Statistics dict with total count and per-category counts
        
    Example:
        >>> stats = call_neko_count()
        >>> print(stats)
    """
    stats: dict[str, Any] = {
        "total": 0,
        "categories": {},
    }

    categories_to_count = (
        list(_intent_config.allowed_categories)
        if _intent_config.active
        else VALID_ACTIONS
    )

    for action in categories_to_count:
        if action in _gifs_data:
            count = len(_gifs_data[action])
            stats["categories"][action] = count
            stats["total"] += count

    # Sort categories by count (highest first)
    stats["categories"] = dict(
        sorted(stats["categories"].items(), key=lambda x: x[1], reverse=True)
    )

    return stats


def call_neko(
    *,
    amount: int = 1,
    actions: str | list[str] | None = None,
    search: str | list[str] | None = None,
    type: int | str | None = None,
    mode: int | str | None = None,
    dupe: bool = False
) -> dict[str, Any] | list[dict[str, Any]]:
    """
    Fetches nekos.best content based on provided options (respects intent).
    Priority order: search > type > actions > mode
    
    Args:
        amount: Number of items to fetch (default: 1)
        actions: Specific action(s) to fetch from
        search: Search filter(s) for artist_name or anime_name
        type: Content type: 1/'images', 2/'gifs', 3/'both'
        mode: Selection mode: 1/'random', 2/'distributed', 3/'each'
        dupe: Allow duplicate items (default: False)
        
    Returns:
        Single dict or list of dicts
        
    Raises:
        ValueError: If invalid parameters or intent restrictions violated
        
    Example:
        >>> item = call_neko()
        >>> hugs = call_neko(amount=5, actions='hug')
    """
    params = _parse_options(
        amount=amount,
        actions=actions,
        search=search,
        type=type,
        mode=mode,
        dupe=dupe
    )

    result: list[dict[str, Any]] = []

    if params["mode"] == MODES.RANDOM:
        result = _select_random_mode(
            params["amount"],
            params["actions"],
            params["search"],
            params["dupe"]
        )
    elif params["mode"] == MODES.DISTRIBUTED:
        result = _select_distributed_mode(
            params["amount"],
            params["actions"],
            params["search"],
            params["dupe"]
        )
    elif params["mode"] == MODES.EACH:
        result = _select_each_mode(
            params["amount"],
            params["actions"],
            params["search"],
            params["dupe"]
        )

    return result[0] if params["amount"] == 1 and len(result) == 1 else result
