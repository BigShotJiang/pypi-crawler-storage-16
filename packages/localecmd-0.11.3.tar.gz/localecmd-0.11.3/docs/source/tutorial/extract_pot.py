#!/usr/bin/env python3
import functions

from localecmd import create_pot

create_pot([functions], 'locale', project='localecli_tutorial')
