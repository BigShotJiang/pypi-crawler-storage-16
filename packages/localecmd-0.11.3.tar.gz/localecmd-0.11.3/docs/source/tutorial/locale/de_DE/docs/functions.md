# Turtle-Funktionen

### tschüss ⠀

Aufnahme beenden, Turtle-Fenter schließen und Programm schließen: TSCHÜSS

### kreis args... ⠀

Kreis mit gegebenem Radius zeichnen: KREIS 50

### vorwärts args... ⠀

Schildkröte vorwärts bewegen:  VORWÄRTS 10

### geh_nach args... ⠀

Schildkröte gedreht an bestimmte Stelle bewegen.  GEH_NACH 100

### richtung ⠀

Ausrichtung der Schildkröte drucken:  RICHTUNG

### nach_hause ⠀

Schildkröte nach Hause ziehen:  NACH_HAUSE

### links args... ⠀

Schildkröte um einen Winkel in Grad nach links drehen:  LINKS 90

### abspielen ab_Zeile bis_Zeile ⠀

Alle Befehle zwichen zwei Zeilen wieder ausführen

### position ⠀

Jetzigen Ort der Schildkröte drucken:  POSITION

### zurücksetzen ⠀

Fenster entleeren und Schildkröte in die Mitte setzen:  ZURÜCKSETZEN

### rechts args... ⠀

Schildkröte um einen Winkel in Grad nach rechts drehen:  RECHTS 90
