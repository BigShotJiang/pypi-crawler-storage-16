from rolo.resource import Resource, resource

__all__ = [
    "resource",
    "Resource",
]
