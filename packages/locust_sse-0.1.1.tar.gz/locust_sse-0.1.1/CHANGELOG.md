# Changelog

## [0.1.1](https://github.com/Aleph-Alpha/locust-sse/compare/v0.1.0...v0.1.1) (2025-12-09)


### Bug Fixes

* add environment 'pypi' to release job ([9877aed](https://github.com/Aleph-Alpha/locust-sse/commit/9877aed633ada14ede5ea169f0dd8b011e86795f))

## 0.1.0 (2025-12-09)


### Features

* implement SSEUser with requests-sse and tests ([6183092](https://github.com/Aleph-Alpha/locust-sse/commit/6183092d16e671d63396faa93779e6b204265d05))


### Documentation

* add README and LICENSE ([f611389](https://github.com/Aleph-Alpha/locust-sse/commit/f6113892c369c7558d0f327d4afc67169dede47d))
