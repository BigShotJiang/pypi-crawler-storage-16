class RecorderPluginAlreadyRegistered(Exception):
    pass


class RecorderPluginLoadError(Exception):
    pass


class RecorderPluginError(Exception):
    pass
