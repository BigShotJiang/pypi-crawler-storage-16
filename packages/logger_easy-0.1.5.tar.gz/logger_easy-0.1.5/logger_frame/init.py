from .fwork_init import init_project

def main():
    init_project()
    
