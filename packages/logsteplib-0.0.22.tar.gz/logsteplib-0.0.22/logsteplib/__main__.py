from .stream import StreamLogger


def main():
    print("logsteplib is a library for using internal standard log format.")


if __name__ == "__main__":
    main()
