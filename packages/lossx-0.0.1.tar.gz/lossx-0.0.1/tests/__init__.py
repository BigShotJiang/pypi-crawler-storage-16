"""Tests for the lossx library."""
