def pytest_xhtml_report_title(report):
    report.title = "Lounger Test Report"
