from lrucache_rs._lib import LRUCache

__all__ = ('LRUCache',)
