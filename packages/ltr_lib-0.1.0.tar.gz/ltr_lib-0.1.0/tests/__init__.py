"""Test suite for ltr_lib."""
