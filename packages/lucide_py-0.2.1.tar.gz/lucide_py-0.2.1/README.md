# Lucide Python

A Python implementation of the [lucide icon library](https://github.com/lucide-icons/lucide) that can be used with the `tagflow` package to easily render icons in your Python web applications.

This project provides a full set of lucide icons as Python context managers, along with a demo application to browse and search all available icons.

## Features

-   **Complete set of lucide icons**: All icons from the lucide library are available.
-   **Easy to use**: Icons can be rendered as context managers using `tagflow`.
-   **Customizable**: Icons can be customized with `width`, `height`, and other SVG attributes.
-   **Demo application**: A web application to browse, search, and filter all icons.

## Screenshot

![App Screenshot](screenshot.png)

## Setup and Installation

1.  **Clone the repository:**
    ```sh
    git clone https://github.com/dotlabshq/lucide-py.git
    cd lucide-py
    ```

2.  **Build the environment:**
    This will create a virtual environment and install all the necessary dependencies.
    ```sh
    make build-env
    ```

3.  **Download the icons:**
    This will clone the original `lucide` repository to download the SVG icon assets.
    ```sh
    make setup-resources
    ```

4.  **Generate the icon library:**
    This will generate the Python modules for each icon from the SVG assets.
    ```sh
    make generate-icons
    ```

## Running the Demo Application

To browse all the available icons, you can run the demo application.

```sh
make run
```

This will start a web server on `http://127.0.0.1:8000`. Open this URL in your browser to see the icon library.

The demo application allows you to:
-   View all icons grouped by category.
-   Filter icons by category.
-   Search for icons by name.

## Usage in Your Application

You can use the generated icons in any application that uses `tagflow`.

Here's an example of how to use an icon:

```python
from lucide.icons import Activity
from tagflow import document

with document() as doc:
    with Activity(width="48", height="48", classes="text-blue-500"):
        pass

print(doc.to_html())
```

This will produce the following HTML:

```html
<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke_width="2" stroke_linecap="round" stroke_linejoin="round" class="text-blue-500">
    <path d="M22 12h-4l-3 9L9 3l-3 9H2"></path>
</svg>
```

## Running Tests

To run the test suite, which verifies that all icons are generated correctly:

```sh
make test
```

## License

Lucide is licensed under the MIT license. See [LICENSE](https://lucide.dev/license).