
import contextlib
from collections.abc import Generator

from .base import IconBase

                        
@contextlib.contextmanager
def Album(**kwargs) -> Generator[None]:
    data = {'classes': ['lucide lucide-album'], 'items': [{'rect': {'width': '18', 'height': '18', 'x': '3', 'y': '3', 'rx': '2', 'ry': '2'}}, {'polyline': {'points': '11 3 11 11 14 8 17 11 17 3'}}]}
    with IconBase(data, **kwargs):
        pass
    yield
