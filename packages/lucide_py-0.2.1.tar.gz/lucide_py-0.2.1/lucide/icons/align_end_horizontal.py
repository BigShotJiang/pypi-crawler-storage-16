
import contextlib
from collections.abc import Generator

from .base import IconBase

                        
@contextlib.contextmanager
def AlignEndHorizontal(**kwargs) -> Generator[None]:
    data = {'classes': ['lucide lucide-align-end-horizontal'], 'items': [{'rect': {'width': '6', 'height': '16', 'x': '4', 'y': '2', 'rx': '2'}}, {'rect': {'width': '6', 'height': '9', 'x': '14', 'y': '9', 'rx': '2'}}, {'path': {'d': 'M22 22H2'}}]}
    with IconBase(data, **kwargs):
        pass
    yield
