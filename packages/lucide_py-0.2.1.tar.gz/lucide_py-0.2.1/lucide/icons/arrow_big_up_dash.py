
import contextlib
from collections.abc import Generator

from .base import IconBase

                        
@contextlib.contextmanager
def ArrowBigUpDash(**kwargs) -> Generator[None]:
    data = {'classes': ['lucide lucide-arrow-big-up-dash'], 'items': [{'path': {'d': 'M9 13a1 1 0 0 0-1-1H5.061a1 1 0 0 1-.75-1.811l6.836-6.835a1.207 1.207 0 0 1 1.707 0l6.835 6.835a1 1 0 0 1-.75 1.811H16a1 1 0 0 0-1 1v2a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1z'}}, {'path': {'d': 'M9 20h6'}}]}
    with IconBase(data, **kwargs):
        pass
    yield
