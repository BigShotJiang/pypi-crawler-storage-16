
import contextlib
from collections.abc import Generator

from .base import IconBase

                        
@contextlib.contextmanager
def ArrowUpWideNarrow(**kwargs) -> Generator[None]:
    data = {'classes': ['lucide lucide-arrow-up-wide-narrow'], 'items': [{'path': {'d': 'm3 8 4-4 4 4'}}, {'path': {'d': 'M7 4v16'}}, {'path': {'d': 'M11 12h10'}}, {'path': {'d': 'M11 16h7'}}, {'path': {'d': 'M11 20h4'}}]}
    with IconBase(data, **kwargs):
        pass
    yield
