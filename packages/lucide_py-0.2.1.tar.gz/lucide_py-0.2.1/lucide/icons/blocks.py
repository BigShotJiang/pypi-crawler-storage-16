
import contextlib
from collections.abc import Generator

from .base import IconBase

                        
@contextlib.contextmanager
def Blocks(**kwargs) -> Generator[None]:
    data = {'classes': ['lucide lucide-blocks'], 'items': [{'path': {'d': 'M10 22V7a1 1 0 0 0-1-1H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-5a1 1 0 0 0-1-1H2'}}, {'rect': {'x': '14', 'y': '2', 'width': '8', 'height': '8', 'rx': '1'}}]}
    with IconBase(data, **kwargs):
        pass
    yield
