
import contextlib
from collections.abc import Generator

from .base import IconBase

                        
@contextlib.contextmanager
def BookKey(**kwargs) -> Generator[None]:
    data = {'classes': ['lucide lucide-book-key'], 'items': [{'path': {'d': 'm19 3 1 1'}}, {'path': {'d': 'm20 2-4.5 4.5'}}, {'path': {'d': 'M20 7.898V21a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20'}}, {'path': {'d': 'M4 19.5v-15A2.5 2.5 0 0 1 6.5 2h7.844'}}, {'circle': {'cx': '14', 'cy': '8', 'r': '2'}}]}
    with IconBase(data, **kwargs):
        pass
    yield
