
import contextlib
from collections.abc import Generator

from .base import IconBase

                        
@contextlib.contextmanager
def Bubbles(**kwargs) -> Generator[None]:
    data = {'classes': ['lucide lucide-bubbles'], 'items': [{'path': {'d': 'M7.2 14.8a2 2 0 0 1 2 2'}}, {'circle': {'cx': '18.5', 'cy': '8.5', 'r': '3.5'}}, {'circle': {'cx': '7.5', 'cy': '16.5', 'r': '5.5'}}, {'circle': {'cx': '7.5', 'cy': '4.5', 'r': '2.5'}}]}
    with IconBase(data, **kwargs):
        pass
    yield
