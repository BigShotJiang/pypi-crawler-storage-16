
import contextlib
from collections.abc import Generator

from .base import IconBase

                        
@contextlib.contextmanager
def CalendarOff(**kwargs) -> Generator[None]:
    data = {'classes': ['lucide lucide-calendar-off'], 'items': [{'path': {'d': 'M4.2 4.2A2 2 0 0 0 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 1.82-1.18'}}, {'path': {'d': 'M21 15.5V6a2 2 0 0 0-2-2H9.5'}}, {'path': {'d': 'M16 2v4'}}, {'path': {'d': 'M3 10h7'}}, {'path': {'d': 'M21 10h-5.5'}}, {'path': {'d': 'm2 2 20 20'}}]}
    with IconBase(data, **kwargs):
        pass
    yield
