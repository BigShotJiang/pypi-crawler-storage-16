
import contextlib
from collections.abc import Generator

from .base import IconBase

                        
@contextlib.contextmanager
def CalendarSync(**kwargs) -> Generator[None]:
    data = {'classes': ['lucide lucide-calendar-sync'], 'items': [{'path': {'d': 'M11 10v4h4'}}, {'path': {'d': 'm11 14 1.535-1.605a5 5 0 0 1 8 1.5'}}, {'path': {'d': 'M16 2v4'}}, {'path': {'d': 'm21 18-1.535 1.605a5 5 0 0 1-8-1.5'}}, {'path': {'d': 'M21 22v-4h-4'}}, {'path': {'d': 'M21 8.5V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h4.3'}}, {'path': {'d': 'M3 10h4'}}, {'path': {'d': 'M8 2v4'}}]}
    with IconBase(data, **kwargs):
        pass
    yield
