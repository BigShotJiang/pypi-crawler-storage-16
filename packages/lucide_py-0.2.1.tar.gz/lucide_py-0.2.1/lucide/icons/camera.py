
import contextlib
from collections.abc import Generator

from .base import IconBase

                        
@contextlib.contextmanager
def Camera(**kwargs) -> Generator[None]:
    data = {'classes': ['lucide lucide-camera'], 'items': [{'path': {'d': 'M13.997 4a2 2 0 0 1 1.76 1.05l.486.9A2 2 0 0 0 18.003 7H20a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h1.997a2 2 0 0 0 1.759-1.048l.489-.904A2 2 0 0 1 10.004 4z'}}, {'circle': {'cx': '12', 'cy': '13', 'r': '3'}}]}
    with IconBase(data, **kwargs):
        pass
    yield
