
import contextlib
from collections.abc import Generator

from .base import IconBase

                        
@contextlib.contextmanager
def ChartBarDecreasing(**kwargs) -> Generator[None]:
    data = {'classes': ['lucide lucide-chart-bar-decreasing'], 'items': [{'path': {'d': 'M3 3v16a2 2 0 0 0 2 2h16'}}, {'path': {'d': 'M7 11h8'}}, {'path': {'d': 'M7 16h3'}}, {'path': {'d': 'M7 6h12'}}]}
    with IconBase(data, **kwargs):
        pass
    yield
