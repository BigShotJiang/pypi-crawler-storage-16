
import contextlib
from collections.abc import Generator

from .base import IconBase

                        
@contextlib.contextmanager
def ChartColumn(**kwargs) -> Generator[None]:
    data = {'classes': ['lucide lucide-chart-column'], 'items': [{'path': {'d': 'M3 3v16a2 2 0 0 0 2 2h16'}}, {'path': {'d': 'M18 17V9'}}, {'path': {'d': 'M13 17V5'}}, {'path': {'d': 'M8 17v-3'}}]}
    with IconBase(data, **kwargs):
        pass
    yield
