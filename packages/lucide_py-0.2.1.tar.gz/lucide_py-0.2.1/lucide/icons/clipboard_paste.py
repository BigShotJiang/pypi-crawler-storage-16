
import contextlib
from collections.abc import Generator

from .base import IconBase

                        
@contextlib.contextmanager
def ClipboardPaste(**kwargs) -> Generator[None]:
    data = {'classes': ['lucide lucide-clipboard-paste'], 'items': [{'path': {'d': 'M11 14h10'}}, {'path': {'d': 'M16 4h2a2 2 0 0 1 2 2v1.344'}}, {'path': {'d': 'm17 18 4-4-4-4'}}, {'path': {'d': 'M8 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 1.793-1.113'}}, {'rect': {'x': '8', 'y': '2', 'width': '8', 'height': '4', 'rx': '1'}}]}
    with IconBase(data, **kwargs):
        pass
    yield
