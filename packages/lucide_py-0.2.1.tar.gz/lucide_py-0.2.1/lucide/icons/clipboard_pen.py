
import contextlib
from collections.abc import Generator

from .base import IconBase

                        
@contextlib.contextmanager
def ClipboardPen(**kwargs) -> Generator[None]:
    data = {'classes': ['lucide lucide-clipboard-pen'], 'items': [{'rect': {'width': '8', 'height': '4', 'x': '8', 'y': '2', 'rx': '1'}}, {'path': {'d': 'M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-5.5'}}, {'path': {'d': 'M4 13.5V6a2 2 0 0 1 2-2h2'}}, {'path': {'d': 'M13.378 15.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z'}}]}
    with IconBase(data, **kwargs):
        pass
    yield
