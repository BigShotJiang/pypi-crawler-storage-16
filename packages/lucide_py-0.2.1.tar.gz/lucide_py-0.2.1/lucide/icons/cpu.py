
import contextlib
from collections.abc import Generator

from .base import IconBase

                        
@contextlib.contextmanager
def Cpu(**kwargs) -> Generator[None]:
    data = {'classes': ['lucide lucide-cpu'], 'items': [{'path': {'d': 'M12 20v2'}}, {'path': {'d': 'M12 2v2'}}, {'path': {'d': 'M17 20v2'}}, {'path': {'d': 'M17 2v2'}}, {'path': {'d': 'M2 12h2'}}, {'path': {'d': 'M2 17h2'}}, {'path': {'d': 'M2 7h2'}}, {'path': {'d': 'M20 12h2'}}, {'path': {'d': 'M20 17h2'}}, {'path': {'d': 'M20 7h2'}}, {'path': {'d': 'M7 20v2'}}, {'path': {'d': 'M7 2v2'}}, {'rect': {'x': '4', 'y': '4', 'width': '16', 'height': '16', 'rx': '2'}}, {'rect': {'x': '8', 'y': '8', 'width': '8', 'height': '8', 'rx': '1'}}]}
    with IconBase(data, **kwargs):
        pass
    yield
