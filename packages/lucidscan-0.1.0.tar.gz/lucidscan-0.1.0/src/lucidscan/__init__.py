"""
lucidscan package root.

This module currently only exposes version metadata. Core functionality lives in
subpackages such as `core`, `schema`, and `scanners`.
"""

__all__ = ["__version__"]

__version__ = "0.1.0"


