"""Scanner adapters for integrating external tools (Trivy, Checkov, Semgrep, ...)."""


