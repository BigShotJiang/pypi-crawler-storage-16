"""OpenTelemetry tracing utilities for Lunette."""

from lunette.tracing.tracer import LunetteTracer


__all__ = ["LunetteTracer"]
