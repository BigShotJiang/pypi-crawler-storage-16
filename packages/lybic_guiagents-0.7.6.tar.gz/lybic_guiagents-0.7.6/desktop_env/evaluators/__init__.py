#from .table import compare_table

#eval_funcs = {
    #"compare_table(expected, actual)": compare_table
#}
