"""Lyceum CLI tests."""
