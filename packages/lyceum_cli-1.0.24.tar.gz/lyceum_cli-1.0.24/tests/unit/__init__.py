"""Unit tests for Lyceum CLI."""
