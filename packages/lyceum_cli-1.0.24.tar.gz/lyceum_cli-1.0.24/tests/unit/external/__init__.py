"""Unit tests for external modules."""
