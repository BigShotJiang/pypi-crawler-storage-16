"""Unit tests for compute modules."""
