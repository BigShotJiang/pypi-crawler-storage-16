"""Setup script for CodeIndex Python SDK"""
from setuptools import setup, find_packages
from pathlib import Path

# 读取 README
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text(encoding="utf-8") if readme_file.exists() else ""

setup(
    name="lydiacai-codeindex-sdk",
    version="0.1.4",
    description="CodeIndex 的官方 Python SDK，内置 Node Worker 以便直接查询索引",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="acaicai",
    author_email="acaicai@example.com",
    url="https://github.com/LydiaCai1203/codeindex",
    packages=find_packages(),
    include_package_data=True,
    # 包含 codeindex_sdk 包内的 worker_server.js 文件
    package_data={
        "codeindex_sdk": ["worker_server.js"],
    },
    python_requires=">=3.9",
    install_requires=[
        "typing_extensions>=4.5.0",
    ],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
)

