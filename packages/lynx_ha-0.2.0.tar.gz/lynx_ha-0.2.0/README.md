# lynx-ha

Helpers to reduce boilerplate when integrating **Lynx / IoT Open** with **Home Assistant**.

The goal is to move all the repetitive patterns into this library so that Home Assistant custom components / forks can stay minimal and focused.

> Status: early prototype (`0.1.0`).

## Installation

```bash
pip install lynx-ha
