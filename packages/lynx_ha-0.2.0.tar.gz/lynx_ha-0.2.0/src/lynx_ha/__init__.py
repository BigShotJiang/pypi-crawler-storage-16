# SPDX-License-Identifier: MIT
"""
lynx-ha

Helpers to reduce boilerplate when integrating Lynx / IoT Open with Home Assistant.

This library is intentionally independent of the Home Assistant core package.
Your HA integration (or any other application) should import these helpers and
map them to its own entity / device models.
"""

from __future__ import annotations

from .models import (
    EntityClassification,
    EntityKind,
    FunctionDescriptor,
    FunctionSnapshot,
)
from .naming import (
    build_device_identifier_and_name,
    build_entity_id_slug,
    build_unique_id,
    normalize_slug,
    split_attributes,
)
from .classifier import classify_function, guess_sensor_semantics
from .grouping import classify_all, group_by_kind, filter_functions
from .pipeline import (
    build_snapshot_dict,
    classify_snapshots_by_kind,
    select_snapshots,
)
from .ha_adapter import (
    HaEntitySpec,
    build_ha_entity_specs_from_snapshots,
    build_ha_entity_specs_from_raw,
    group_specs_by_platform,
    build_ha_layout_from_api,
    group_specs_by_device,
)

__all__ = [
    # models
    "EntityKind",
    "EntityClassification",
    "FunctionDescriptor",
    "FunctionSnapshot",
    # naming
    "normalize_slug",
    "build_unique_id",
    "build_entity_id_slug",
    "build_device_identifier_and_name",
    "split_attributes",
    # classification / grouping
    "classify_function",
    "guess_sensor_semantics",
    "classify_all",
    "group_by_kind",
    "filter_functions",
    # pipeline
    "build_snapshot_dict",
    "classify_snapshots_by_kind",
    "select_snapshots",
    # HA adapter
    "HaEntitySpec",
    "build_ha_entity_specs_from_snapshots",
    "build_ha_entity_specs_from_raw",
    "group_specs_by_platform",
    "build_ha_layout_from_api",
    "group_specs_by_device",
]

# Keep this in sync with pyproject.toml -> project.version
__version__ = "0.2.0"
