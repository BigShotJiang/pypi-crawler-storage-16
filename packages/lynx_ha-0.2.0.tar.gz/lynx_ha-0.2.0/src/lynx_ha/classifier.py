# SPDX-License-Identifier: MIT
"""
lynx_ha.classifier

Logic to map IoT Open FunctionX metadata to HA-style entity semantics.
"""

from __future__ import annotations

from typing import Any, Mapping, Tuple

from .models import EntityClassification, EntityKind, FunctionDescriptor
from .naming import (
    build_entity_id_slug,
    build_unique_id,
    split_attributes,
)


def _lower_or_empty(value: Any) -> str:
    return str(value).lower() if value is not None else ""


def guess_sensor_semantics(
    func_type: str,
    unit: str | None,
) -> Tuple[str | None, str | None, str | None]:
    t = _lower_or_empty(func_type)
    u = _lower_or_empty(unit)

    dev_class: str | None = None
    state_class: str | None = None

    if t in {"power", "power_active", "power_reactive"} or u in {"w", "kw"}:
        dev_class = "power"
        unit = unit or "W"
        state_class = "measurement"
    elif "energy" in t or u in {"kwh", "wh"}:
        dev_class = "energy"
        state_class = "total_increasing"
    elif t in {"temperature", "temp"} or u in {"c", "°c", "degc"}:
        dev_class = "temperature"
        unit = unit or "°C"
        state_class = "measurement"
    elif t in {"humidity", "rel_humidity"} or u == "%":
        dev_class = "humidity"
        unit = unit or "%"
        state_class = "measurement"
    elif "voltage" in t or u in {"v", "mv"}:
        dev_class = "voltage"
        unit = unit or "V"
        state_class = "measurement"
    elif "current" in t or u in {"a", "ma"}:
        dev_class = "current"
        unit = unit or "A"
        state_class = "measurement"
    elif "pressure" in t or u in {"pa", "kpa", "hpa", "bar"}:
        dev_class = "pressure"
        state_class = "measurement"
    elif "illuminance" in t or u in {"lx"}:
        dev_class = "illuminance"
        state_class = "measurement"
    elif "co2" in t or u in {"ppm"}:
        dev_class = "carbon_dioxide"
        state_class = "measurement"

    if not unit:
        unit = None

    return dev_class, unit, state_class


def _is_probably_binary(func_type: str, meta: Mapping[str, Any]) -> bool:
    t = _lower_or_empty(func_type)

    if t.startswith("alarm_"):
        return True

    for keyword in (
        "motion",
        "presence",
        "contact",
        "door",
        "window",
        "smoke",
        "tamper",
        "occupancy",
    ):
        if keyword in t:
            return True

    meta_type = _lower_or_empty(meta.get("ha_device_class"))
    if meta_type == "binary":
        return True

    return False


def _is_probably_switch(func_type: str, meta: Mapping[str, Any]) -> bool:
    t = _lower_or_empty(func_type)

    if t == "switch" or t.endswith("_switch"):
        return True

    if "topic_set" in meta or "topic_write" in meta:
        if "state_on" in meta or "state_off" in meta:
            return True

    return False


def _is_writable(func_type: str, meta: Mapping[str, Any]) -> bool:
    if _is_probably_switch(func_type, meta):
        return True

    if meta.get("writable") is True:
        return True

    if "topic_set" in meta or "topic_write" in meta:
        return True

    return False


def classify_function(
    func: FunctionDescriptor,
    *,
    domain_prefix: str = "iotopen",
    default_name_prefix: str = "IoT Open",
) -> EntityClassification:
    func_type = func.type
    meta = dict(func.meta)

    friendly_name = (
        meta.get("friendly_name")
        or f"{default_name_prefix} Function {func.function_id}"
    )

    slug = build_entity_id_slug(
        installation_id=func.installation_id,
        function_id=func.function_id,
        func_type=func_type,
        device_id=func.device_id,
    )

    unique_id = build_unique_id(
        domain_prefix,
        func.installation_id,
        func.function_id,
    )

    kind: EntityKind
    unit: str | None = meta.get("unit") or meta.get("unit_of_measurement")

    if _is_probably_switch(func_type, meta):
        kind = EntityKind.SWITCH
    elif _is_probably_binary(func_type, meta):
        kind = EntityKind.BINARY_SENSOR
    else:
        kind = EntityKind.SENSOR

    device_class: str | None = None
    state_class: str | None = None

    if kind == EntityKind.SENSOR:
        device_class, unit, state_class = guess_sensor_semantics(
            func_type=func_type,
            unit=unit,
        )

    is_writable = _is_writable(func_type, meta)
    icon = meta.get("icon")
    attributes = split_attributes(meta)

    return EntityClassification(
        kind=kind,
        unique_id=unique_id,
        entity_id_slug=slug,
        name=str(friendly_name),
        installation_id=func.installation_id,
        function_id=func.function_id,
        device_id=func.device_id,
        device_class=device_class,
        state_class=state_class,
        unit_of_measurement=unit,
        is_writable=is_writable,
        attributes=attributes,
        icon=icon,
    )
