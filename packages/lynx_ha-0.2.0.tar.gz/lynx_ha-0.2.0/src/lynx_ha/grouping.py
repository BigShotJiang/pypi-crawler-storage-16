# SPDX-License-Identifier: MIT
"""
lynx_ha.grouping

Helpers to classify many FunctionDescriptor objects at once,
group them by EntityKind, and filter them according to simple
criteria.

These helpers are meant to be used by higher-level code
(e.g. a Home Assistant integration) when it needs:

- all sensors vs all binary_sensors vs all switches
- only writable entities
- only functions of a certain type prefix

They deliberately return EntityClassification objects so that
callers have direct access to the derived metadata.

Enhanced version:
- Accepts both FunctionDescriptor and FunctionSnapshot as input.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Dict, Iterable, List, Optional, Union

from .classifier import classify_function
from .models import (
    EntityClassification,
    EntityKind,
    FunctionDescriptor,
    FunctionSnapshot,
)

DescriptorLike = Union[FunctionDescriptor, FunctionSnapshot]


def _as_descriptor(obj: DescriptorLike) -> FunctionDescriptor:
    """Normalize input into a FunctionDescriptor.

    If you pass a FunctionDescriptor, it is returned as-is.
    If you pass a FunctionSnapshot, we use its .descriptor.
    """
    if isinstance(obj, FunctionDescriptor):
        return obj
    return obj.descriptor


def classify_all(
    funcs: Iterable[DescriptorLike],
    *,
    domain_prefix: str = "iotopen",
    default_name_prefix: str = "IoT Open",
) -> List[EntityClassification]:
    """
    Classify a sequence of FunctionDescriptor / FunctionSnapshot objects.

    Parameters
    ----------
    funcs:
        Iterable of FunctionDescriptor or FunctionSnapshot.
    domain_prefix:
        Integration domain prefix that goes into the unique_id.
    default_name_prefix:
        Prefix for the friendly name if no meta-friendly-name is found.

    Returns
    -------
    list[EntityClassification]
        A list of classification results, in the same order
        as the input functions.
    """
    results: List[EntityClassification] = []

    for obj in funcs:
        desc = _as_descriptor(obj)
        classification = classify_function(
            desc,
            domain_prefix=domain_prefix,
            default_name_prefix=default_name_prefix,
        )
        results.append(classification)

    return results


def group_by_kind(
    funcs: Iterable[DescriptorLike],
    *,
    domain_prefix: str = "iotopen",
    default_name_prefix: str = "IoT Open",
) -> Dict[EntityKind, List[EntityClassification]]:
    """
    Classify all functions/snapshots and group them by EntityKind.

    This is a convenience wrapper around `classify_all`, most
    useful for building lists of entities per HA platform.

    Example
    -------
    >>> groups = group_by_kind(funcs)
    >>> sensor_entities = groups[EntityKind.SENSOR]
    >>> switch_entities = groups[EntityKind.SWITCH]
    """
    grouped: Dict[EntityKind, List[EntityClassification]] = defaultdict(list)

    for obj in funcs:
        desc = _as_descriptor(obj)
        classification = classify_function(
            desc,
            domain_prefix=domain_prefix,
            default_name_prefix=default_name_prefix,
        )
        grouped[classification.kind].append(classification)

    return dict(grouped)


def filter_functions(
    funcs: Iterable[DescriptorLike],
    *,
    kind: Optional[EntityKind] = None,
    writable: Optional[bool] = None,
    type_prefix: Optional[str] = None,
    type_equals: Optional[str] = None,
    domain_prefix: str = "iotopen",
    default_name_prefix: str = "IoT Open",
) -> List[EntityClassification]:
    """
    Classify and filter a list of FunctionDescriptor / FunctionSnapshot objects.

    This is a simple, opinionated filtering helper:

    - `kind` filters on EntityKind (sensor / binary_sensor / switch / ...).
    - `writable` filters on classification.is_writable.
    - `type_prefix` filters on the *original* FunctionDescriptor.type
      lowercased starting with this prefix.
    - `type_equals` filters on the *original* FunctionDescriptor.type
      lowercased being exactly equal to this value.

    Notes
    -----
    - The return type is a list of EntityClassification objects
      so that you don't have to re-classify later.
    - If both `type_prefix` and `type_equals` are provided,
      both conditions must be satisfied.
    """
    # Pre-normalize type filters for cheaper comparisons
    prefix_norm: Optional[str] = type_prefix.lower() if type_prefix else None
    equals_norm: Optional[str] = type_equals.lower() if type_equals else None

    results: List[EntityClassification] = []

    for obj in funcs:
        desc = _as_descriptor(obj)
        classification = classify_function(
            desc,
            domain_prefix=domain_prefix,
            default_name_prefix=default_name_prefix,
        )

        # Filter by kind
        if kind is not None and classification.kind is not kind:
            continue

        # Filter by writable flag
        if writable is not None and classification.is_writable is not writable:
            continue

        # Filter by original function type
        func_type_norm = desc.type.lower()

        if prefix_norm is not None and not func_type_norm.startswith(prefix_norm):
            continue

        if equals_norm is not None and func_type_norm != equals_norm:
            continue

        results.append(classification)

    return results
