# SPDX-License-Identifier: MIT
"""
lynx_ha.ha_adapter

Home Assistant–oriented helpers built on top of the core models and
classification logic.

This module is still *not* coupled to Home Assistant itself – it does
not import HA – but it exposes a representation that maps very closely
to what an integration needs to create entities:

- platform: "sensor" | "binary_sensor" | "switch" | ...
- unique_id: stable across restarts
- name: human-readable name
- device identifiers / names for device registry grouping
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Iterable, Mapping, Sequence

from .classifier import classify_function
from .models import (
    EntityKind,
    FunctionDescriptor,
    FunctionSnapshot,
)
from .pipeline import build_snapshot_dict


# ---------------------------------------------------------------------------
# Snapshot source normalisation
# ---------------------------------------------------------------------------

SnapshotSource = Iterable[FunctionSnapshot] | Mapping[int, FunctionSnapshot]


def _iter_snapshots(source: SnapshotSource) -> Iterable[FunctionSnapshot]:
    """Normalize snapshot source (dict or plain iterable) into an iterable."""
    if isinstance(source, Mapping):
        return source.values()
    return source


# ---------------------------------------------------------------------------
# HA-facing entity spec
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class HaEntitySpec:
    """
    Minimal, HA-friendly description of an entity.

    This object is deliberately simple so your HA platform code can
    just translate it into a Home Assistant Entity subclass.

    Fields
    ------
    platform:
        HA platform name: "sensor", "binary_sensor", "switch", ...
    kind:
        EntityKind enum value for this entity.
    installation_id:
        IoT Open installation id.
    function_id:
        FunctionX id.
    unique_id:
        Globally unique id to use in HA (entity.unique_id).
    name:
        Human-readable name for the entity.
    device_identifier:
        String identifier for the device in HA's device registry
        (e.g. "device_123" or "installation_2083").
    device_name:
        Human-readable name for the device (for the device registry).
    is_writable:
        True if the function is considered writable (switches etc.).
    descriptor:
        The underlying FunctionDescriptor.
    snapshot:
        The underlying FunctionSnapshot.
    """

    platform: str
    kind: EntityKind
    installation_id: int
    function_id: int
    unique_id: str
    name: str
    device_identifier: str
    device_name: str
    is_writable: bool
    descriptor: FunctionDescriptor
    snapshot: FunctionSnapshot


_PLATFORM_BY_KIND: Dict[EntityKind, str] = {
    EntityKind.SENSOR: "sensor",
    EntityKind.BINARY_SENSOR: "binary_sensor",
    EntityKind.SWITCH: "switch",
    # Future kinds (NUMBER, SELECT, etc.) can be added here later.
}


# ---------------------------------------------------------------------------
# Device grouping helpers
# ---------------------------------------------------------------------------


def _device_id_from_descriptor(desc: FunctionDescriptor) -> int | None:
    """Best-effort extraction of DeviceX id from the descriptor.

    Priority:
      1) desc.device_id attribute, if present and convertible to int.
      2) meta["device_id"], if present and convertible to int.
    """
    # 1) Dedicated attribute, but only if set to a meaningful value.
    if hasattr(desc, "device_id"):
        value = getattr(desc, "device_id")
        if value is not None:
            try:
                return int(value)
            except (TypeError, ValueError):
                # Fall through to meta-based discovery.
                pass

    # 2) Fallback: meta.device_id
    meta = desc.meta or {}
    raw = meta.get("device_id")
    if raw is None:
        return None
    try:
        return int(raw)
    except (TypeError, ValueError):
        return None


def _build_device_identifier_and_name(
    desc: FunctionDescriptor,
) -> tuple[str, str]:
    """Mirror the grouping logic we want in HA's device registry.

    If we have a device_id -> group under "IoT Open Device <id>".
    Otherwise group by installation: "IoT Open Installation <installation_id>".
    """
    device_id = _device_id_from_descriptor(desc)
    if device_id is not None:
        identifier = f"device_{device_id}"
        name = f"IoT Open Device {device_id}"
    else:
        identifier = f"installation_{desc.installation_id}"
        name = f"IoT Open Installation {desc.installation_id}"
    return identifier, name


# ---------------------------------------------------------------------------
# Core builders
# ---------------------------------------------------------------------------


def build_ha_entity_specs_from_snapshots(
    snapshots: SnapshotSource,
    *,
    domain_prefix: str = "iotopen",
    default_name_prefix: str = "IoT Open",
) -> list[HaEntitySpec]:
    """
    Produce HA-friendly entity specs from FunctionSnapshot objects.

    Parameters
    ----------
    snapshots:
        Either a mapping {function_id: FunctionSnapshot} (as typically
        used in a DataUpdateCoordinator) or any iterable of snapshots.
    domain_prefix:
        Prefix for classification.unique_id; usually the integration domain.
    default_name_prefix:
        Fallback prefix when no meaningful name can be derived.

    Returns
    -------
    list[HaEntitySpec]
        A flat list of specs across all kinds (sensor, binary_sensor, switch).
    """
    specs: list[HaEntitySpec] = []

    for snapshot in _iter_snapshots(snapshots):
        desc = snapshot.descriptor
        classification = classify_function(
            desc,
            domain_prefix=domain_prefix,
            default_name_prefix=default_name_prefix,
        )

        kind = classification.kind
        platform = _PLATFORM_BY_KIND.get(kind, "sensor")

        device_identifier, device_name = _build_device_identifier_and_name(desc)

        spec = HaEntitySpec(
            platform=platform,
            kind=kind,
            installation_id=desc.installation_id,
            function_id=desc.function_id,
            unique_id=classification.unique_id,
            name=classification.name,
            device_identifier=device_identifier,
            device_name=device_name,
            is_writable=classification.is_writable,
            descriptor=desc,
            snapshot=snapshot,
        )
        specs.append(spec)

    return specs


def build_ha_entity_specs_from_raw(
    functionx_raw: Iterable[Mapping[str, Any]],
    status_raw: Iterable[Mapping[str, Any]],
    *,
    domain_prefix: str = "iotopen",
    default_name_prefix: str = "IoT Open",
) -> list[HaEntitySpec]:
    """
    Convenience helper for Home Assistant:

    Take raw IoT Open FunctionX + Status API responses and produce
    HaEntitySpec objects in one step.

    Typical usage (inside a coordinator or platform):

        functionx = await api.async_list_functionx(installation_id=2083)
        status = await api.async_get_status_for_topics(installation_id=2083, topics=topics)
        specs = build_ha_entity_specs_from_raw(functionx, status, domain_prefix="iotopen")

    This is equivalent to:

        snapshots = build_snapshot_dict(functionx, status)
        specs = build_ha_entity_specs_from_snapshots(snapshots.values(), ...)
    """
    snapshot_dict = build_snapshot_dict(functionx_raw, status_raw)
    return build_ha_entity_specs_from_snapshots(
        snapshot_dict.values(),
        domain_prefix=domain_prefix,
        default_name_prefix=default_name_prefix,
    )


# ---------------------------------------------------------------------------
# Grouping helpers
# ---------------------------------------------------------------------------


def group_specs_by_platform(specs: Iterable[HaEntitySpec]) -> Dict[str, list[HaEntitySpec]]:
    """
    Group HaEntitySpec objects by HA platform.

    Example
    -------
    >>> specs = build_ha_entity_specs_from_snapshots(coordinator.data)
    >>> grouped = group_specs_by_platform(specs)
    >>> sensor_specs = grouped.get("sensor", [])
    >>> switch_specs = grouped.get("switch", [])
    """
    grouped: Dict[str, list[HaEntitySpec]] = {}
    for spec in specs:
        grouped.setdefault(spec.platform, []).append(spec)
    return grouped


def group_specs_by_device(specs: Iterable[HaEntitySpec]) -> Dict[str, list[HaEntitySpec]]:
    """
    Group HaEntitySpec objects by their device identifier.

    The device_identifier/device_name values are already computed by
    `_build_device_identifier_and_name`, so this function is just a
    convenience for building "per-device" views.

    Example
    -------
    >>> specs = build_ha_entity_specs_from_raw(functionx, status)
    >>> by_device = group_specs_by_device(specs)
    >>> device_ids = list(by_device.keys())
    """
    grouped: Dict[str, list[HaEntitySpec]] = {}
    for spec in specs:
        grouped.setdefault(spec.device_identifier, []).append(spec)
    return grouped


# ---------------------------------------------------------------------------
# High-level layout helper
# ---------------------------------------------------------------------------


def build_ha_layout_from_api(
    functionx: Sequence[Mapping[str, object]],
    status: Sequence[Mapping[str, object]],
    *,
    domain_prefix: str = "iotopen",
    default_name_prefix: str = "IoT Open",
) -> Dict[str, list[HaEntitySpec]]:
    """High-level helper: from raw IoT Open API data -> HA layout by platform.

    This is a convenience wrapper around:
        1) build_ha_entity_specs_from_raw(...)
        2) group_specs_by_platform(...)

    Parameters
    ----------
    functionx:
        Sequence of raw FunctionX dicts as returned by the IoT Open API.
        Each item must at least have:
          - "id"
          - "installation_id"
          - "type"
          - "meta" (mapping with at least "topic_read")
    status:
        Sequence of status samples; each item must have:
          - "topic"
          - "value"
          - "timestamp"
    domain_prefix:
        Prefix used when generating unique_ids (normally the HA domain).
    default_name_prefix:
        Fallback prefix for generated names.

    Returns
    -------
    Dict[str, list[HaEntitySpec]]
        Mapping from Home Assistant platform name ("sensor", "binary_sensor",
        "switch", ...) to a list of HaEntitySpec for that platform.

    Notes
    -----
    - This function is purely in-memory and side-effect free.
    - It does not talk to IoT Open or Home Assistant; it only reshapes data.
    """
    specs = build_ha_entity_specs_from_raw(
        functionx,
        status,
        domain_prefix=domain_prefix,
        default_name_prefix=default_name_prefix,
    )
    return group_specs_by_platform(specs)
