# SPDX-License-Identifier: MIT
"""
lynx_ha.iotopen

Helpers specifically for dealing with IoT Open / Lynx API responses.

This module knows about:

- Raw FunctionX records (as returned by /api/v2/functionx/...).
- Raw Status samples (as returned by /api/v2/status/...).
- Meta conventions like:
    * topic_read / topic_write / topic_set
    * device_id
    * ha.disabled / ha.hidden

It does NOT import Home Assistant.

The main responsibilities:

1. Turn raw FunctionX records into FunctionDescriptor.
2. Combine FunctionX + Status into FunctionSnapshot objects.
3. Implement generic "visibility" rules (is_exposed_to_ha meta flags).
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Mapping, MutableMapping, Optional

from .models import FunctionDescriptor, FunctionSnapshot


# ---------------------------------------------------------------------------
# Meta helpers
# ---------------------------------------------------------------------------


def _truthy_flag(value: Any) -> bool:
    """
    Interpret typical boolean-ish strings.

    True for: "1", "true", "yes", "on" (case-insensitive).
    """
    if value is None:
        return False
    s = str(value).strip().lower()
    return s in ("1", "true", "yes", "on")


def is_exposed_to_ha(meta: Mapping[str, Any] | None) -> bool:
    """
    Return True if this FunctionX should be exposed to Home Assistant.

    Meta flags (case-insensitive values):

      - If meta['ha.disabled'] is truthy -> NOT exposed
      - If meta['ha.hidden']   is truthy -> NOT exposed
    """
    if not meta:
        return True

    if _truthy_flag(meta.get("ha.disabled")):
        return False

    if _truthy_flag(meta.get("ha.hidden")):
        return False

    return True


def parse_device_id(raw: Any) -> Optional[int]:
    """
    Best-effort conversion of meta.device_id to an int.

    Accepts both "7" and 7; returns None on failure.
    """
    if raw is None:
        return None
    try:
        return int(raw)
    except (TypeError, ValueError):
        return None


# ---------------------------------------------------------------------------
# Raw structures and conversion
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class StatusSample:
    """
    Minimal representation of an IoT Open Status sample.

    This matches the shape returned by /api/v2/status/{installation_id}:

        {
            "topic": "2086/obj/...",
            "value": 42,
            "timestamp": 1700000000
        }
    """

    topic: str
    value: Any
    timestamp: int


def _normalize_function_meta(raw_meta: Any) -> Dict[str, Any]:
    """Ensure meta is always a dict[str, Any]."""
    if isinstance(raw_meta, Mapping):
        return dict(raw_meta)
    return {}


def functionx_to_descriptor(
    item: Mapping[str, Any],
    *,
    default_installation_id: Optional[int] = None,
) -> FunctionDescriptor:
    """
    Convert a raw FunctionX record (from IoT Open API) into a FunctionDescriptor.

    Expected shape of `item` (example):

        {
            "id": 508312,
            "installation_id": 2083,
            "type": "power",
            "meta": {
                "name": "Main Power",
                "topic_read": "2086/obj/...",
                "topic_write": "2086/set/obj/...",
                "device_id": "7",
                "unit": "W",
                ...
            }
        }
    """
    meta = _normalize_function_meta(item.get("meta"))
    installation_id_raw = item.get("installation_id", default_installation_id)
    if installation_id_raw is None:
        raise ValueError("FunctionX record is missing installation_id")

    installation_id = int(installation_id_raw)
    function_id = int(item.get("id"))
    func_type = str(item.get("type") or "")

    topic_read = meta.get("topic_read") or meta.get("topic") or None
    # topic_set is the "write" direction – prefer explicit topic_set, then topic_write.
    topic_set = meta.get("topic_set") or meta.get("topic_write") or None

    device_id = parse_device_id(meta.get("device_id"))

    return FunctionDescriptor(
        installation_id=installation_id,
        function_id=function_id,
        type=func_type,
        meta=meta,
        device_id=device_id,
        topic_read=str(topic_read) if topic_read is not None else None,
        topic_set=str(topic_set) if topic_set is not None else None,
        state_on=meta.get("state_on"),
        state_off=meta.get("state_off"),
        last_value=None,
    )


def status_records_to_samples(
    raw_status: Iterable[Mapping[str, Any]],
) -> Dict[str, StatusSample]:
    """
    Build a mapping topic -> *latest* StatusSample per topic.

    If multiple samples exist for a topic, the one with the highest
    timestamp wins (>= comparison).
    """
    by_topic: Dict[str, StatusSample] = {}

    for item in raw_status:
        topic_raw = item.get("topic")
        if not topic_raw:
            continue

        topic = str(topic_raw)
        ts_raw = item.get("timestamp") or 0
        try:
            ts = int(ts_raw)
        except (TypeError, ValueError):
            ts = 0

        value = item.get("value")

        current = by_topic.get(topic)
        if current is None or ts >= current.timestamp:
            by_topic[topic] = StatusSample(topic=topic, value=value, timestamp=ts)

    return by_topic


def build_function_snapshots(
    functionx_raw: Iterable[Mapping[str, Any]],
    status_raw: Iterable[Mapping[str, Any]],
    *,
    default_installation_id: Optional[int] = None,
    require_topic_read: bool = True,
    respect_ha_visibility_flags: bool = True,
) -> Dict[int, FunctionSnapshot]:
    """
    Convert raw FunctionX + Status responses into FunctionSnapshot objects.

    This is essentially the core logic currently living inside
    the HA IoTOpenDataUpdateCoordinator, but expressed in a
    reusable, Home Assistant–agnostic form.

    Parameters
    ----------
    functionx_raw:
        Iterable of raw FunctionX records (/api/v2/functionx/...).
    status_raw:
        Iterable of raw status records (/api/v2/status/...).
    default_installation_id:
        Used when a FunctionX record has no explicit installation_id field.
    require_topic_read:
        If True, functions missing meta.topic_read are skipped.
    respect_ha_visibility_flags:
        If True, respects meta["ha.disabled"] and meta["ha.hidden"].

    Returns
    -------
    dict[int, FunctionSnapshot]
        Mapping of function_id -> snapshot.
    """
    # First, map status samples by topic
    status_by_topic = status_records_to_samples(status_raw)

    snapshots: Dict[int, FunctionSnapshot] = {}

    for raw in functionx_raw:
        meta = _normalize_function_meta(raw.get("meta"))

        if respect_ha_visibility_flags and not is_exposed_to_ha(meta):
            continue

        # Build descriptor
        try:
            descriptor = functionx_to_descriptor(
                raw,
                default_installation_id=default_installation_id,
            )
        except ValueError:
            # Missing installation_id etc – skip gracefully
            continue

        if require_topic_read and not descriptor.topic_read:
            # Cannot correlate with status API without a read topic
            continue

        # Pick the latest status sample for this function's topic, if any
        sample: Optional[StatusSample] = None
        if descriptor.topic_read:
            sample = status_by_topic.get(descriptor.topic_read)

        last_value: Any | None
        last_timestamp: int | None

        if sample is None:
            last_value = None
            last_timestamp = None
        else:
            last_value = sample.value
            last_timestamp = sample.timestamp

        descriptor.last_value = last_value

        snapshots[descriptor.function_id] = FunctionSnapshot(
            descriptor=descriptor,
            last_value=last_value,
            last_timestamp=last_timestamp,
        )

    return snapshots
