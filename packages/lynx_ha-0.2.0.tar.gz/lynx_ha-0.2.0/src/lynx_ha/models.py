# SPDX-License-Identifier: MIT
"""
lynx_ha.models

Core data models used by the lynx-ha helper library.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, Mapping, Optional


class EntityKind(str, Enum):
    """High-level entity kind for Home Assistant platforms."""

    SENSOR = "sensor"
    BINARY_SENSOR = "binary_sensor"
    SWITCH = "switch"
    NUMBER = "number"
    SELECT = "select"
    BUTTON = "button"
    UNKNOWN = "unknown"


@dataclass(slots=True)
class FunctionDescriptor:
    """
    Minimal representation of an IoT Open FunctionX for HA mapping.

    This is *not* tied to Home Assistant; it just knows about
    IoT Open-ish metadata conventions:

    - installation_id / function_id / device_id
    - meta including:
        * unit / unit_of_measurement
        * topic_read / topic_set / topic_write
        * state_on / state_off
        * state_alarm / state_no_alarm
        * ha.disabled / ha.hidden
    """

    installation_id: int
    function_id: int
    type: str

    meta: Mapping[str, Any] = field(default_factory=dict)

    device_id: Optional[int] = None
    topic_read: Optional[str] = None
    topic_set: Optional[str] = None
    state_on: Optional[Any] = None
    state_off: Optional[Any] = None

    last_value: Optional[Any] = None

    def get_meta(self, key: str, default: Any = None) -> Any:
        """Convenience accessor for meta values."""
        return self.meta.get(key, default)


@dataclass(slots=True)
class EntityClassification:
    """
    Result of mapping a FunctionDescriptor to a HA-friendly entity config.
    """

    kind: EntityKind

    unique_id: str
    entity_id_slug: str
    name: str

    installation_id: int
    function_id: int
    device_id: Optional[int] = None

    device_class: Optional[str] = None
    state_class: Optional[str] = None
    unit_of_measurement: Optional[str] = None

    is_writable: bool = False

    attributes: Dict[str, Any] = field(default_factory=dict)

    icon: Optional[str] = None


@dataclass(slots=True)
class FunctionSnapshot:
    """
    Combined view of a FunctionX record and its latest status.

    This is designed to be a drop-in replacement for the HA-side
    IoTOpenFunctionState dataclass, but usable outside Home Assistant.

    It is intentionally thin:

    - It stores a FunctionDescriptor.
    - It stores last_value + last_timestamp.
    - It exposes read-only convenience properties to mirror the
      old IoTOpenFunctionState API (installation_id, type, name, ...).

    The 'name' property is derived from meta["name"] or a fallback.
    """

    descriptor: FunctionDescriptor
    last_value: Any | None
    last_timestamp: int | None

    # --------------------------------------------------------------
    # Convenience properties for compatibility / ergonomics
    # --------------------------------------------------------------

    @property
    def installation_id(self) -> int:
        return self.descriptor.installation_id

    @property
    def function_id(self) -> int:
        return self.descriptor.function_id

    @property
    def type(self) -> str:
        return self.descriptor.type

    @property
    def device_id(self) -> Optional[int]:
        return self.descriptor.device_id

    @property
    def topic_read(self) -> Optional[str]:
        return self.descriptor.topic_read

    @property
    def meta(self) -> Mapping[str, Any]:
        return self.descriptor.meta

    @property
    def name(self) -> str:
        meta = self.descriptor.meta or {}
        return str(
            meta.get("name")
            or meta.get("friendly_name")
            or f"Function {self.descriptor.function_id}"
        )
