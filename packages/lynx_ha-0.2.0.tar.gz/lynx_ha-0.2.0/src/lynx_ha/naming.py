# SPDX-License-Identifier: MIT
"""
lynx_ha.naming

Helpers for building unique IDs, entity_id slugs and device identifiers.
"""

from __future__ import annotations

import re
from typing import Any, Dict, Tuple


_SLUG_RE = re.compile(r"[^a-z0-9_]+")


def normalize_slug(value: str) -> str:
    """
    Normalize a string to a safe entity_id slug.
    """
    value = value.strip().lower().replace(" ", "_")
    value = _SLUG_RE.sub("_", value)
    while "__" in value:
        value = value.replace("__", "_")
    return value.strip("_") or "unnamed"


def build_unique_id(*parts: Any) -> str:
    """
    Build a stable unique_id from arbitrary parts.
    """
    norm_parts = []
    for p in parts:
        if p is None:
            continue
        s = str(p).strip()
        if not s:
            continue
        norm_parts.append(s)
    return ":".join(norm_parts)


def build_entity_id_slug(
    installation_id: int,
    function_id: int,
    func_type: str,
    device_id: int | None = None,
) -> str:
    """
    Build a suggested entity_id slug *without* the domain prefix.
    """
    base_parts = ["installation", installation_id]
    if device_id is not None:
        base_parts.extend(["device", device_id])
    base_parts.extend([func_type, function_id])
    return normalize_slug("_".join(map(str, base_parts)))


def build_device_identifier_and_name(
    installation_id: int,
    device_id: int | None,
) -> Tuple[str, str]:
    """
    Compute the (identifier_key, human_name) pair for a DeviceInfo-style object.
    """
    if device_id is not None:
        identifier = f"device_{device_id}"
        name = f"IoT Open Device {device_id}"
    else:
        identifier = f"installation_{installation_id}"
        name = f"IoT Open Installation {installation_id}"
    return identifier, name


def split_attributes(
    raw_meta: Dict[str, Any],
    reserved_keys: set[str] | None = None,
) -> Dict[str, Any]:
    """
    Filter out reserved keys from meta to produce extra attributes.
    """
    if reserved_keys is None:
        reserved_keys = {
            "function_id",
            "installation_id",
            "device_id",
            "topic_read",
            "topic_set",
            "topic_write",
            "state_on",
            "state_off",
            "type",
            "id",
            "created",
            "updated",
        }

    return {k: v for k, v in raw_meta.items() if k not in reserved_keys}
