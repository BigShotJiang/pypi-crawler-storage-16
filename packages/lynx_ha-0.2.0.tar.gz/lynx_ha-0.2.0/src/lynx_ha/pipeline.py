# SPDX-License-Identifier: MIT
"""
lynx_ha.pipeline

High-level helpers that combine IoT Open raw API data with
the classification & grouping utilities.

This layer exists so that a Home Assistant integration (or
any other app) can be extremely thin:

    1) Call IoT Open API for FunctionX + Status.
    2) Call build_snapshot_dict(...) to get FunctionSnapshot objects.
    3) Call classify_snapshots_by_kind(...) or select_snapshots(...)
       to drive platform/entity creation.
"""

from __future__ import annotations

from typing import Dict, Iterable, Mapping, Optional, Union

from .grouping import group_by_kind, filter_functions
from .iotopen import build_function_snapshots
from .models import (
    EntityClassification,
    EntityKind,
    FunctionSnapshot,
)


SnapshotIterable = Iterable[FunctionSnapshot]
SnapshotDict = Mapping[int, FunctionSnapshot]
SnapshotSource = Union[SnapshotIterable, SnapshotDict]


def _snapshots_iter(snapshots: SnapshotSource) -> SnapshotIterable:
    """Normalize snapshot source (dict or iterable) into an iterable."""
    if isinstance(snapshots, Mapping):
        return snapshots.values()
    return snapshots


def build_snapshot_dict(
    functionx_raw: Iterable[Mapping[str, object]],
    status_raw: Iterable[Mapping[str, object]],
    *,
    default_installation_id: Optional[int] = None,
    require_topic_read: bool = True,
    respect_ha_visibility_flags: bool = True,
) -> Dict[int, FunctionSnapshot]:
    """
    Convert raw FunctionX + Status responses into FunctionSnapshot objects.

    This is a thin wrapper around `iotopen.build_function_snapshots` that
    keeps the public API surface focused around snapshots.

    Parameters
    ----------
    functionx_raw:
        Iterable of raw FunctionX records (from /api/v2/functionx/...).
    status_raw:
        Iterable of raw Status records (from /api/v2/status/...).
    default_installation_id:
        Fallback installation id if a FunctionX record is missing it.
    require_topic_read:
        If True, functions without meta.topic_read are skipped.
    respect_ha_visibility_flags:
        If True, respects meta["ha.disabled"] / meta["ha.hidden"].

    Returns
    -------
    dict[int, FunctionSnapshot]
        Mapping function_id -> FunctionSnapshot.
    """
    return build_function_snapshots(
        functionx_raw,
        status_raw,
        default_installation_id=default_installation_id,
        require_topic_read=require_topic_read,
        respect_ha_visibility_flags=respect_ha_visibility_flags,
    )


def classify_snapshots_by_kind(
    snapshots: SnapshotSource,
    *,
    domain_prefix: str = "iotopen",
    default_name_prefix: str = "IoT Open",
) -> Dict[EntityKind, list[EntityClassification]]:
    """
    Classify snapshots and group them by EntityKind.

    This is a convenience wrapper that combines:

        snapshots -> grouping.group_by_kind(...)

    Example usage in a HA platform module
    -------------------------------------
    >>> groups = classify_snapshots_by_kind(coordinator.data)
    >>> sensor_entities = groups.get(EntityKind.SENSOR, [])
    >>> switch_entities = groups.get(EntityKind.SWITCH, [])
    """
    iterable = _snapshots_iter(snapshots)
    return group_by_kind(
        iterable,
        domain_prefix=domain_prefix,
        default_name_prefix=default_name_prefix,
    )


def select_snapshots(
    snapshots: SnapshotSource,
    *,
    kind: Optional[EntityKind] = None,
    writable: Optional[bool] = None,
    type_prefix: Optional[str] = None,
    type_equals: Optional[str] = None,
    domain_prefix: str = "iotopen",
    default_name_prefix: str = "IoT Open",
) -> list[EntityClassification]:
    """
    Classify + filter snapshots in a single call.

    This is a wrapper around `filter_functions` that accepts the
    snapshot dict (coordinator.data) or a list of snapshots.

    Parameters mirror `filter_functions`, but the input is snapshots.

    Example
    -------
    >>> # all writable switches:
    >>> switches = select_snapshots(
    ...     coordinator.data,
    ...     kind=EntityKind.SWITCH,
    ...     writable=True,
    ... )
    """
    iterable = _snapshots_iter(snapshots)
    return filter_functions(
        iterable,
        kind=kind,
        writable=writable,
        type_prefix=type_prefix,
        type_equals=type_equals,
        domain_prefix=domain_prefix,
        default_name_prefix=default_name_prefix,
    )
