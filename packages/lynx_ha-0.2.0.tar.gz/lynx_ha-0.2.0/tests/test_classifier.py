# tests/test_classifier.py

from lynx_ha import (
    EntityKind,
    FunctionDescriptor,
    classify_function,
    guess_sensor_semantics,
)


# ---------------------------------------------------------------------------
# guess_sensor_semantics
# ---------------------------------------------------------------------------

def test_guess_sensor_semantics_power():
    dev_class, unit, state_class = guess_sensor_semantics("power", None)
    assert dev_class == "power"
    assert unit == "W"
    assert state_class == "measurement"


def test_guess_sensor_semantics_energy():
    dev_class, unit, state_class = guess_sensor_semantics("energy_counter", "kWh")
    assert dev_class == "energy"
    # energy counters are typically total_increasing
    assert state_class == "total_increasing"


def test_guess_sensor_semantics_temperature():
    dev_class, unit, state_class = guess_sensor_semantics("temp", None)
    assert dev_class == "temperature"
    assert unit == "°C"
    assert state_class == "measurement"


def test_guess_sensor_semantics_humidity():
    dev_class, unit, state_class = guess_sensor_semantics("humidity", "%")
    assert dev_class == "humidity"
    assert unit == "%"
    assert state_class == "measurement"


def test_guess_sensor_semantics_voltage():
    dev_class, unit, state_class = guess_sensor_semantics("voltage", "V")
    assert dev_class == "voltage"
    assert unit == "V"
    assert state_class == "measurement"


def test_guess_sensor_semantics_current():
    dev_class, unit, state_class = guess_sensor_semantics("current", "A")
    assert dev_class == "current"
    assert unit == "A"
    assert state_class == "measurement"


def test_guess_sensor_semantics_co2():
    dev_class, unit, state_class = guess_sensor_semantics("co2", "ppm")
    assert dev_class == "carbon_dioxide"
    assert state_class == "measurement"


# ---------------------------------------------------------------------------
# classify_function – sensor / binary / switch heuristics
# ---------------------------------------------------------------------------

def test_classify_sensor_function():
    func = FunctionDescriptor(
        installation_id=2083,
        function_id=508312,
        type="power",
        meta={"unit": "W", "friendly_name": "Main Power"},
    )
    result = classify_function(func)
    assert result.kind == EntityKind.SENSOR
    assert result.device_class == "power"
    assert result.unit_of_measurement == "W"
    assert result.state_class == "measurement"
    assert result.name == "Main Power"
    # We keep friendly_name also in attributes for debugging
    assert "friendly_name" in result.attributes


def test_classify_binary_alarm_function_by_type():
    func = FunctionDescriptor(
        installation_id=2083,
        function_id=1,
        type="alarm_power_management",
        meta={"friendly_name": "Power Alarm"},
    )
    result = classify_function(func)
    assert result.kind == EntityKind.BINARY_SENSOR
    assert result.is_writable is False


def test_classify_binary_function_by_meta_hint():
    # type is generic, but meta says ha_device_class=binary
    func = FunctionDescriptor(
        installation_id=2083,
        function_id=2,
        type="generic_status",
        meta={"ha_device_class": "binary", "friendly_name": "Generic Binary"},
    )
    result = classify_function(func)
    assert result.kind == EntityKind.BINARY_SENSOR
    assert result.is_writable is False


def test_classify_switch_function_by_type_exact():
    func = FunctionDescriptor(
        installation_id=2083,
        function_id=3,
        type="switch",
        meta={
            "friendly_name": "Zigbee Plug",
            "topic_set": "obj/generated/ha/zigbee_plug/state",
            "state_on": 1,
            "state_off": 0,
        },
    )
    result = classify_function(func)
    assert result.kind == EntityKind.SWITCH
    assert result.is_writable is True
    assert result.unit_of_measurement is None  # switches don't need a unit


def test_classify_switch_function_by_type_suffix():
    # type ends with "_switch"
    func = FunctionDescriptor(
        installation_id=2083,
        function_id=4,
        type="relay_switch",
        meta={"friendly_name": "Relay Switch"},
    )
    result = classify_function(func)
    assert result.kind == EntityKind.SWITCH
    # no explicit write topics, but type heuristic is enough
    assert result.is_writable is True


def test_classify_switch_function_by_topic_write():
    # generic type, but has topic_write + state_on/state_off
    func = FunctionDescriptor(
        installation_id=2083,
        function_id=5,
        type="generic",
        meta={
            "friendly_name": "Write-only Switch",
            "topic_write": "foo/bar",
            "state_on": "ON",
            "state_off": "OFF",
        },
    )
    result = classify_function(func)
    assert result.kind == EntityKind.SWITCH
    assert result.is_writable is True


def test_classify_writable_non_switch_by_writable_flag():
    # Marked as writable but not a "switch", e.g. a NUMBER in HA later
    func = FunctionDescriptor(
        installation_id=2083,
        function_id=6,
        type="setpoint",
        meta={
            "friendly_name": "Setpoint",
            "writable": True,
            "unit": "°C",
        },
    )
    result = classify_function(func)
    # still a SENSOR kind, but flagged writable=True so HA can map to number/select
    assert result.kind == EntityKind.SENSOR
    assert result.is_writable is True
    assert result.device_class == "temperature"


def test_classify_writable_by_topic_only():
    # Not a switch type, no explicit flag, but has topic_set -> writable
    func = FunctionDescriptor(
        installation_id=2083,
        function_id=7,
        type="generic",
        meta={
            "friendly_name": "Writable Generic",
            "topic_set": "foo/bar",
        },
    )
    result = classify_function(func)
    assert result.is_writable is True


def test_unique_id_and_slug_are_stable():
    func = FunctionDescriptor(
        installation_id=2083,
        function_id=508312,
        type="power",
        meta={"unit": "W"},
        device_id=42,
    )
    result = classify_function(func, domain_prefix="iotopen", default_name_prefix="IoT Open")
    # Basic shape of unique_id and slug should be stable
    assert result.unique_id == "iotopen:2083:508312"
    assert result.entity_id_slug == "installation_2083_device_42_power_508312"
