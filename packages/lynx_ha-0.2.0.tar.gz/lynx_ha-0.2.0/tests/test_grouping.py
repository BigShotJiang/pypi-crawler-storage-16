from lynx_ha import (
    EntityKind,
    FunctionDescriptor,
    FunctionSnapshot,
    classify_all,
    filter_functions,
    group_by_kind,
)


def _make_sample_descriptors() -> list[FunctionDescriptor]:
    return [
        # Sensor: power
        FunctionDescriptor(
            installation_id=1,
            function_id=1,
            type="power",
            meta={"unit": "W", "name": "Main Power"},
            topic_read="topic/power",
        ),
        # Binary sensor: alarm
        FunctionDescriptor(
            installation_id=1,
            function_id=2,
            type="alarm_power_management",
            meta={"name": "Power Alarm"},
            topic_read="topic/alarm",
        ),
        # Switch: explicit type + state mapping
        FunctionDescriptor(
            installation_id=1,
            function_id=3,
            type="switch",
            meta={
                "name": "Relay Switch",
                "topic_write": "set/relay",
                "state_on": 1,
                "state_off": 0,
            },
            topic_read="topic/switch",
            state_on=1,
            state_off=0,
        ),
    ]


def _make_sample_snapshots() -> list[FunctionSnapshot]:
    descs = _make_sample_descriptors()
    return [
        FunctionSnapshot(descriptor=descs[0], last_value=42, last_timestamp=100),
        FunctionSnapshot(descriptor=descs[1], last_value=1, last_timestamp=200),
        FunctionSnapshot(descriptor=descs[2], last_value=0, last_timestamp=300),
    ]


def test_classify_all_with_descriptors_preserves_order():
    funcs = _make_sample_descriptors()
    results = classify_all(funcs, domain_prefix="iotopen_test")

    assert len(results) == len(funcs)
    assert [r.function_id for r in results] == [f.function_id for f in funcs]
    assert all(r.unique_id.startswith("iotopen_test:") for r in results)


def test_classify_all_with_snapshots_uses_descriptor():
    snaps = _make_sample_snapshots()
    results = classify_all(snaps)

    assert len(results) == len(snaps)
    # Should map back to the underlying descriptor ids
    assert [r.function_id for r in results] == [
        snap.descriptor.function_id for snap in snaps
    ]


def test_group_by_kind_splits_into_expected_kinds():
    funcs = _make_sample_descriptors()
    groups = group_by_kind(funcs)

    # We at least have SENSOR, BINARY_SENSOR, and SWITCH present
    assert EntityKind.SENSOR in groups
    assert EntityKind.BINARY_SENSOR in groups
    assert EntityKind.SWITCH in groups

    sensor_ids = {c.function_id for c in groups[EntityKind.SENSOR]}
    binary_ids = {c.function_id for c in groups[EntityKind.BINARY_SENSOR]}
    switch_ids = {c.function_id for c in groups[EntityKind.SWITCH]}

    # Assuming classifier maps:
    #   power -> SENSOR
    #   alarm_* -> BINARY_SENSOR
    #   switch -> SWITCH
    assert 1 in sensor_ids
    assert 2 in binary_ids
    assert 3 in switch_ids


def test_filter_functions_by_kind_only():
    funcs = _make_sample_descriptors()
    sensors = filter_functions(funcs, kind=EntityKind.SENSOR)

    assert all(c.kind is EntityKind.SENSOR for c in sensors)
    # At least our "power" function should be there
    ids = {c.function_id for c in sensors}
    assert 1 in ids


def test_filter_functions_by_kind_and_writable_flag():
    funcs = _make_sample_descriptors()
    # We don't care if the result is empty or not for coverage;
    # the important part is that the writable filter path is exercised.
    _ = filter_functions(funcs, kind=EntityKind.SENSOR, writable=True)
    _ = filter_functions(funcs, kind=EntityKind.SENSOR, writable=False)


def test_filter_functions_by_type_prefix():
    funcs = _make_sample_descriptors()
    alarms = filter_functions(funcs, type_prefix="alarm_")

    ids = {c.function_id for c in alarms}
    assert ids == {2}


def test_filter_functions_by_type_equals():
    funcs = _make_sample_descriptors()
    switches = filter_functions(funcs, type_equals="switch")

    ids = {c.function_id for c in switches}
    assert ids == {3}


def test_filter_functions_combined_filters_with_snapshots():
    snaps = _make_sample_snapshots()
    # Kind SENSOR + type starting with "pow"
    results = filter_functions(
        snaps,
        kind=EntityKind.SENSOR,
        type_prefix="pow",
    )
    ids = {c.function_id for c in results}
    # Only the power function (id=1) should match
    assert ids == {1}
