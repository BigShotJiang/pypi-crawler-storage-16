from lynx_ha import (
    EntityKind,
    FunctionDescriptor,
    FunctionSnapshot,
    HaEntitySpec,
    build_ha_entity_specs_from_snapshots,
    build_ha_entity_specs_from_raw,
    build_snapshot_dict,
    group_specs_by_platform,
)


def _make_snapshots():
    # SENSOR-like
    fd1 = FunctionDescriptor(
        installation_id=2083,
        function_id=1,
        type="power",
        meta={"name": "Main Power", "topic_read": "topic/power", "unit": "W"},
        topic_read="topic/power",
    )
    snap1 = FunctionSnapshot(
        descriptor=fd1,
        last_value=42,
        last_timestamp=100,
    )

    # BINARY_SENSOR-like (alarm)
    fd2 = FunctionDescriptor(
        installation_id=2083,
        function_id=2,
        type="alarm_power_management",
        meta={"name": "Power Alarm", "topic_read": "topic/alarm"},
        topic_read="topic/alarm",
    )
    snap2 = FunctionSnapshot(
        descriptor=fd2,
        last_value=1,
        last_timestamp=200,
    )

    # SWITCH-like
    fd3 = FunctionDescriptor(
        installation_id=2083,
        function_id=3,
        type="switch",
        meta={
            "name": "Relay Switch",
            "topic_read": "topic/switch",
            "topic_write": "set/switch",
            "state_on": 1,
            "state_off": 0,
            "device_id": "123",
        },
        topic_read="topic/switch",
        state_on=1,
        state_off=0,
    )
    snap3 = FunctionSnapshot(
        descriptor=fd3,
        last_value=0,
        last_timestamp=300,
    )

    return [snap1, snap2, snap3]


def test_build_ha_entity_specs_from_snapshots_basic():
    snaps = _make_snapshots()
    specs = build_ha_entity_specs_from_snapshots(snaps, domain_prefix="iotopen_test")

    # 1:1 relationship
    assert len(specs) == len(snaps)
    assert all(isinstance(s, HaEntitySpec) for s in specs)

    # Preserve ids
    assert {s.function_id for s in specs} == {1, 2, 3}
    assert {s.installation_id for s in specs} == {2083}

    # unique_id prefix
    assert all(s.unique_id.startswith("iotopen_test:") for s in specs)


def test_build_ha_entity_specs_platform_and_kind_mapping():
    snaps = _make_snapshots()
    specs = build_ha_entity_specs_from_snapshots(snaps)

    by_id = {s.function_id: s for s in specs}

    s1 = by_id[1]
    s2 = by_id[2]
    s3 = by_id[3]

    # power -> SENSOR -> "sensor"
    assert s1.kind is EntityKind.SENSOR
    assert s1.platform == "sensor"

    # alarm_* -> BINARY_SENSOR -> "binary_sensor"
    assert s2.kind is EntityKind.BINARY_SENSOR
    assert s2.platform == "binary_sensor"

    # switch -> SWITCH -> "switch"
    assert s3.kind is EntityKind.SWITCH
    assert s3.platform == "switch"


def test_build_ha_entity_specs_device_grouping_uses_device_id_when_present():
    snaps = _make_snapshots()
    specs = build_ha_entity_specs_from_snapshots(snaps)

    by_id = {s.function_id: s for s in specs}
    s_device = by_id[3]  # has meta.device_id

    assert s_device.device_identifier == "device_123"
    assert s_device.device_name == "IoT Open Device 123"

    # A function without device_id groups at installation-level
    s_installation = by_id[1]
    assert s_installation.device_identifier == "installation_2083"
    assert s_installation.device_name == "IoT Open Installation 2083"


def test_group_specs_by_platform():
    snaps = _make_snapshots()
    specs = build_ha_entity_specs_from_snapshots(snaps)
    grouped = group_specs_by_platform(specs)

    assert set(grouped.keys()) == {"sensor", "binary_sensor", "switch"}

    assert {s.function_id for s in grouped["sensor"]} == {1}
    assert {s.function_id for s in grouped["binary_sensor"]} == {2}
    assert {s.function_id for s in grouped["switch"]} == {3}


def test_build_ha_entity_specs_from_raw_matches_snapshot_path():
    # Build raw objects that look like IoT Open API responses
    functionx_raw = [
        {
            "id": 1,
            "installation_id": 2083,
            "type": "power",
            "meta": {
                "name": "Main Power",
                "topic_read": "topic/power",
                "unit": "W",
            },
        },
        {
            "id": 2,
            "installation_id": 2083,
            "type": "alarm_power_management",
            "meta": {
                "name": "Power Alarm",
                "topic_read": "topic/alarm",
            },
        },
        {
            "id": 3,
            "installation_id": 2083,
            "type": "switch",
            "meta": {
                "name": "Relay Switch",
                "topic_read": "topic/switch",
                "topic_write": "set/switch",
                "state_on": 1,
                "state_off": 0,
                "device_id": "123",
            },
        },
    ]

    status_raw = [
        {"topic": "topic/power", "value": 42, "timestamp": 100},
        {"topic": "topic/alarm", "value": 1, "timestamp": 200},
        {"topic": "topic/switch", "value": 0, "timestamp": 300},
    ]

    snapshots = build_snapshot_dict(functionx_raw, status_raw)
    specs_via_snapshots = build_ha_entity_specs_from_snapshots(
        snapshots.values(),
        domain_prefix="iotopen_test2",
    )
    specs_via_raw = build_ha_entity_specs_from_raw(
        functionx_raw,
        status_raw,
        domain_prefix="iotopen_test2",
    )

    # Compare a stable subset of attributes to ensure both paths behave the same.
    def _key(s: HaEntitySpec):
        return (
            s.function_id,
            s.installation_id,
            s.platform,
            s.kind,
            s.unique_id,
            s.device_identifier,
        )

    assert sorted(map(_key, specs_via_raw)) == sorted(
        map(_key, specs_via_snapshots)
    )
