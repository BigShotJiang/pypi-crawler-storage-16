from lynx_ha import FunctionDescriptor, FunctionSnapshot
from lynx_ha.iotopen import (
    build_function_snapshots,
    functionx_to_descriptor,
    is_exposed_to_ha,
    parse_device_id,
    status_records_to_samples,
)


def test_is_exposed_to_ha_default_true():
    assert is_exposed_to_ha(None) is True
    assert is_exposed_to_ha({}) is True
    assert is_exposed_to_ha({"ha.disabled": "0"}) is True
    assert is_exposed_to_ha({"ha.hidden": "false"}) is True


def test_is_exposed_to_ha_disabled_or_hidden():
    assert is_exposed_to_ha({"ha.disabled": "1"}) is False
    assert is_exposed_to_ha({"ha.disabled": "true"}) is False
    assert is_exposed_to_ha({"ha.hidden": "yes"}) is False
    assert is_exposed_to_ha({"ha.hidden": "on"}) is False


def test_parse_device_id_variants():
    assert parse_device_id(None) is None
    assert parse_device_id("7") == 7
    assert parse_device_id(7) == 7
    assert parse_device_id("not-int") is None


def test_functionx_to_descriptor_basic():
    raw = {
        "id": 508312,
        "installation_id": 2083,
        "type": "power",
        "meta": {
            "name": "Main Power",
            "topic_read": "2086/obj/power/state",
            "topic_write": "2086/set/obj/power/state",
            "device_id": "7",
            "unit": "W",
            "state_on": 1,
            "state_off": 0,
        },
    }

    desc = functionx_to_descriptor(raw)

    assert isinstance(desc, FunctionDescriptor)
    assert desc.installation_id == 2083
    assert desc.function_id == 508312
    assert desc.type == "power"
    assert desc.topic_read == "2086/obj/power/state"
    assert desc.topic_set == "2086/set/obj/power/state"
    assert desc.device_id == 7
    assert desc.state_on == 1
    assert desc.state_off == 0
    assert desc.get_meta("unit") == "W"


def test_status_records_to_samples_picks_latest():
    raw_status = [
        {"topic": "t/1", "value": 10, "timestamp": 100},
        {"topic": "t/1", "value": 11, "timestamp": 110},  # later -> chosen
        {"topic": "t/2", "value": "foo", "timestamp": 50},
        {"topic": "t/2", "value": "bar", "timestamp": 40},  # older -> ignored
    ]

    by_topic = status_records_to_samples(raw_status)

    assert set(by_topic.keys()) == {"t/1", "t/2"}
    assert by_topic["t/1"].value == 11
    assert by_topic["t/1"].timestamp == 110
    assert by_topic["t/2"].value == "foo"
    assert by_topic["t/2"].timestamp == 50


def test_build_function_snapshots_basic_flow():
    functionx_raw = [
        {
            "id": 1,
            "installation_id": 2083,
            "type": "power",
            "meta": {
                "name": "Main Power",
                "topic_read": "topic/power",
            },
        },
        {
            "id": 2,
            "installation_id": 2083,
            "type": "alarm_power_management",
            "meta": {
                "name": "Power Alarm",
                "topic_read": "topic/alarm",
            },
        },
    ]

    status_raw = [
        {"topic": "topic/power", "value": 42, "timestamp": 100},
        {"topic": "topic/alarm", "value": 1, "timestamp": 200},
    ]

    snapshots = build_function_snapshots(functionx_raw, status_raw)

    assert set(snapshots.keys()) == {1, 2}

    snap1 = snapshots[1]
    snap2 = snapshots[2]

    assert isinstance(snap1, FunctionSnapshot)
    assert snap1.installation_id == 2083
    assert snap1.function_id == 1
    assert snap1.last_value == 42
    assert snap1.last_timestamp == 100
    assert snap1.topic_read == "topic/power"
    assert snap1.name == "Main Power"

    assert snap2.last_value == 1
    assert snap2.last_timestamp == 200
    assert snap2.name == "Power Alarm"


def test_build_function_snapshots_skips_hidden_or_no_topic():
    functionx_raw = [
        {
            "id": 1,
            "installation_id": 2083,
            "type": "power",
            "meta": {
                "name": "Visible",
                "topic_read": "topic/visible",
            },
        },
        {
            "id": 2,
            "installation_id": 2083,
            "type": "power",
            "meta": {
                "name": "Hidden",
                "topic_read": "topic/hidden",
                "ha.hidden": "true",
            },
        },
        {
            "id": 3,
            "installation_id": 2083,
            "type": "power",
            "meta": {
                "name": "No topic",
                # no topic_read
            },
        },
    ]

    status_raw = [
        {"topic": "topic/visible", "value": 42, "timestamp": 100},
        {"topic": "topic/hidden", "value": 99, "timestamp": 120},
    ]

    snapshots = build_function_snapshots(functionx_raw, status_raw)

    # Only function id=1 should be present: 2 is hidden, 3 has no topic
    assert set(snapshots.keys()) == {1}
    snap = snapshots[1]
    assert snap.last_value == 42
    assert snap.name == "Visible"
