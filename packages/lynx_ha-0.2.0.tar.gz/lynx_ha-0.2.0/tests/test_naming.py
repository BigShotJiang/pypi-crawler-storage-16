from lynx_ha import (
    normalize_slug,
    build_unique_id,
    build_entity_id_slug,
    build_device_identifier_and_name,
    split_attributes,
)


def test_normalize_slug_basic():
    assert normalize_slug("  My Value  ") == "my_value"
    assert normalize_slug("A+B/C") == "a_b_c"
    assert normalize_slug("___") == "unnamed"


def test_build_unique_id_skips_none_and_empty():
    uid = build_unique_id("lynx", None, "2083", "", "func", 508312)
    assert uid == "lynx:2083:func:508312"


def test_build_entity_id_slug():
    slug = build_entity_id_slug(
        installation_id=2083,
        function_id=508312,
        func_type="power",
        device_id=42,
    )
    assert slug == "installation_2083_device_42_power_508312"


def test_build_device_identifier_and_name_with_device():
    ident, name = build_device_identifier_and_name(installation_id=2083, device_id=7)
    assert ident == "device_7"
    assert name == "IoT Open Device 7"


def test_build_device_identifier_and_name_without_device():
    ident, name = build_device_identifier_and_name(installation_id=2083, device_id=None)
    assert ident == "installation_2083"
    assert name == "IoT Open Installation 2083"


def test_split_attributes_filters_reserved_keys():
    raw = {
        "installation_id": 2083,
        "function_id": 1,
        "device_id": 7,
        "topic_read": "foo",
        "friendly_name": "My Func",
        "custom": "value",
    }
    attrs = split_attributes(raw)
    assert "installation_id" not in attrs
    assert "function_id" not in attrs
    assert "device_id" not in attrs
    assert "topic_read" not in attrs
    assert attrs["friendly_name"] == "My Func"
    assert attrs["custom"] == "value"
