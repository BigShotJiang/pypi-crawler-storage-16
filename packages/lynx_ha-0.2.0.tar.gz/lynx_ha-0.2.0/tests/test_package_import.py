from importlib import import_module


def test_import_root_package():
    mod = import_module("lynx_ha")
    assert hasattr(mod, "__version__")
    assert isinstance(mod.__version__, str)


def test_public_api():
    from lynx_ha import (
        EntityKind,
        EntityClassification,
        FunctionDescriptor,
        normalize_slug,
        build_unique_id,
        build_entity_id_slug,
        build_device_identifier_and_name,
        split_attributes,
        classify_function,
        guess_sensor_semantics,
    )

    assert EntityKind.SENSOR.value == "sensor"
    assert EntityClassification is not None
    assert FunctionDescriptor is not None
    assert callable(normalize_slug)
    assert callable(build_unique_id)
    assert callable(build_entity_id_slug)
    assert callable(build_device_identifier_and_name)
    assert callable(split_attributes)
    assert callable(classify_function)
    assert callable(guess_sensor_semantics)
