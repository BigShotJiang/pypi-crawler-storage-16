from lynx_ha import (
    EntityKind,
    FunctionSnapshot,
    build_snapshot_dict,
    classify_snapshots_by_kind,
    select_snapshots,
)


def _sample_functionx_raw():
    # power -> SENSOR
    yield {
        "id": 1,
        "installation_id": 2083,
        "type": "power",
        "meta": {
            "name": "Main Power",
            "topic_read": "topic/power",
            "unit": "W",
        },
    }
    # alarm_* -> BINARY_SENSOR (by classifier heuristics)
    yield {
        "id": 2,
        "installation_id": 2083,
        "type": "alarm_power_management",
        "meta": {
            "name": "Power Alarm",
            "topic_read": "topic/alarm",
        },
    }
    # switch -> SWITCH (writable)
    yield {
        "id": 3,
        "installation_id": 2083,
        "type": "switch",
        "meta": {
            "name": "Relay Switch",
            "topic_read": "topic/switch",
            "topic_write": "set/switch",
            "state_on": 1,
            "state_off": 0,
        },
    }


def _sample_status_raw():
    yield {"topic": "topic/power", "value": 42, "timestamp": 100}
    yield {"topic": "topic/alarm", "value": 1, "timestamp": 200}
    yield {"topic": "topic/switch", "value": 0, "timestamp": 300}


def test_build_snapshot_dict_basic_flow():
    snapshots = build_snapshot_dict(_sample_functionx_raw(), _sample_status_raw())

    # We expect snapshots for ids 1,2,3
    assert set(snapshots.keys()) == {1, 2, 3}

    snap1 = snapshots[1]
    snap2 = snapshots[2]
    snap3 = snapshots[3]

    assert isinstance(snap1, FunctionSnapshot)
    assert snap1.installation_id == 2083
    assert snap1.function_id == 1
    assert snap1.last_value == 42
    assert snap1.last_timestamp == 100
    assert snap1.topic_read == "topic/power"
    assert snap1.name == "Main Power"

    assert snap2.last_value == 1
    assert snap2.last_timestamp == 200

    assert snap3.last_value == 0
    assert snap3.last_timestamp == 300


def test_classify_snapshots_by_kind_from_dict():
    snapshots = build_snapshot_dict(_sample_functionx_raw(), _sample_status_raw())

    groups = classify_snapshots_by_kind(snapshots, domain_prefix="iotopen_test")

    assert EntityKind.SENSOR in groups
    assert EntityKind.BINARY_SENSOR in groups
    assert EntityKind.SWITCH in groups

    sensor_ids = {c.function_id for c in groups[EntityKind.SENSOR]}
    binary_ids = {c.function_id for c in groups[EntityKind.BINARY_SENSOR]}
    switch_ids = {c.function_id for c in groups[EntityKind.SWITCH]}

    assert 1 in sensor_ids
    assert 2 in binary_ids
    assert 3 in switch_ids

    # unique_ids have the right domain prefix
    all_unique_ids = {c.unique_id for kind in groups.values() for c in kind}
    assert all(u.startswith("iotopen_test:") for u in all_unique_ids)


def test_classify_snapshots_by_kind_from_iterable():
    snapshots_dict = build_snapshot_dict(_sample_functionx_raw(), _sample_status_raw())
    snapshots_iter = list(snapshots_dict.values())

    groups = classify_snapshots_by_kind(snapshots_iter)

    # Same ids as before, regardless of input type
    sensor_ids = {c.function_id for c in groups[EntityKind.SENSOR]}
    binary_ids = {c.function_id for c in groups[EntityKind.BINARY_SENSOR]}
    switch_ids = {c.function_id for c in groups[EntityKind.SWITCH]}

    assert 1 in sensor_ids
    assert 2 in binary_ids
    assert 3 in switch_ids


def test_select_snapshots_filters_by_kind_and_type_prefix():
    snapshots = build_snapshot_dict(_sample_functionx_raw(), _sample_status_raw())

    # select only alarm_* as binary sensors (kind + type_prefix together)
    alarms = select_snapshots(
        snapshots,
        kind=EntityKind.BINARY_SENSOR,
        type_prefix="alarm_",
    )

    ids = {c.function_id for c in alarms}
    assert ids == {2}


def test_select_snapshots_from_iterable_writable_switches():
    snapshots_dict = build_snapshot_dict(_sample_functionx_raw(), _sample_status_raw())
    snapshots_iter = list(snapshots_dict.values())

    # Even if the classifier marks writable=False by default, this call
    # exercises the 'writable' filter path for coverage and API stability.
    _ = select_snapshots(
        snapshots_iter,
        kind=EntityKind.SWITCH,
        writable=True,
    )
    _ = select_snapshots(
        snapshots_iter,
        kind=EntityKind.SWITCH,
        writable=False,
    )
