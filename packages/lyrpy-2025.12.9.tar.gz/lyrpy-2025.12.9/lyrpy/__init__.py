import os

# print("import lyrpy")
print(os.path.abspath(__file__))

#-------------------------------------------------------------------------------
#
#-------------------------------------------------------------------------------
def main ():
#beginfunction
    print("Hello, **lyrpy**")
#endfunction

#------------------------------------------
#
#------------------------------------------
#beginmodule
if __name__ == "__main__":
    main()
#endif

#endmodule
