#!/bin/bash

# TODO: npm i datasheet

datasheet -i index.adoc -o index.pdf
