from .client import M8

__version__ = "0.1.0"
__all__ = ["M8"]