
# disable usage and erroror reports to kilocode in About/Export page.
# Disable model api provider data collection.
