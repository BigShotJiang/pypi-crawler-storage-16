
from pathlib import Path

FZFG_LINUX_PATH = Path(__file__).parent.joinpath("scripts_linux", "fzfg")
FZFG_WINDOWS_PATH = Path(__file__).parent.joinpath("scripts_windows", "fzfg.ps1")
