from .voting import (
    VotingClassifier,
    VotingRegressor,
)

__all__ = [
    "VotingClassifier",
    "VotingRegressor",
]
