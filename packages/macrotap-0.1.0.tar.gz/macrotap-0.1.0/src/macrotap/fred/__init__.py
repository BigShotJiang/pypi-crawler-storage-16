
from .main import from_fred

__all__ = ("from_fred", )

