import dataclasses


@dataclasses.dataclass
class ReturnValue:
    pass
