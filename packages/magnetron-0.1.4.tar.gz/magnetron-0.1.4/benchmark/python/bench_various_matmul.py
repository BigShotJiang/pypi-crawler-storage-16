# (c) 2025 Mario Sieg. <mario.sieg.64@gmail.com>

from bench import bench_permuted_matmul

bench_permuted_matmul()
