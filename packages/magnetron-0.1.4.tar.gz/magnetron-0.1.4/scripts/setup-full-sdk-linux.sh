#!/usr/bin/env bash

sudo apt install -y cpufrequtils doxygen graphviz libboost-all-dev
