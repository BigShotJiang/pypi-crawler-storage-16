#define CENTER_OF_MASS_STORAGE
#include "center_of_mass_impl.h"
