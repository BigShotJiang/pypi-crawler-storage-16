"""Runtime benchmarking harness for MagTrack."""

from __future__ import annotations

__all__ = [
    "run_all",
]
