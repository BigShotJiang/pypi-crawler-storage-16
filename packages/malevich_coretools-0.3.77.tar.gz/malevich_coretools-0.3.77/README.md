# malevich-coretools

## Install 

pip install -U malevich-coretools

## Main

This is a library with a low-level malevich-core api
