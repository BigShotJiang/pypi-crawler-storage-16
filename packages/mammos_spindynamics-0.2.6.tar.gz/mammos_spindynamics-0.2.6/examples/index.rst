mammos-spindynamics
===================

This package provides functionality to get magnetic material properties from spindynamics methods.

.. toctree::
   :maxdepth: 1

   quickstart

