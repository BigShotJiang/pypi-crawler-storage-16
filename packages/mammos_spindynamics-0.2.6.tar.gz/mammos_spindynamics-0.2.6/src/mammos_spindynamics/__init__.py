"""Spindynamics-based magnetic material properties."""

import importlib.metadata

from mammos_spindynamics import db as db

__version__ = importlib.metadata.version(__package__)
