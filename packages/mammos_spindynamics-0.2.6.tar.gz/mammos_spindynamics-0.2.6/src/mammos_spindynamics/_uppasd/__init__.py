"""Uppsala Atomistic Spin Dynamics (UppASD) software."""
