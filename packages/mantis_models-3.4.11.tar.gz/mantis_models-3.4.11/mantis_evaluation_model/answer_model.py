# -*- coding: utf-8 -*-
"""Data models for evaluation submitted by the participants.
"""
from typing import List
from typing import Union

from pydantic import BaseModel


class SubmittedAssessmentItem(BaseModel):
    identifier: str
    submitted_response: Union[str, int, float, bool]


class SubmittedSection(BaseModel):
    identifier: str
    assessment_items: List[SubmittedAssessmentItem]


class SubmittedTestPart(BaseModel):
    identifier: str
    assessment_section: List[SubmittedSection]


class SubmittedAssessmentTest(BaseModel):
    identifier: str
    test_part: List[SubmittedTestPart]
