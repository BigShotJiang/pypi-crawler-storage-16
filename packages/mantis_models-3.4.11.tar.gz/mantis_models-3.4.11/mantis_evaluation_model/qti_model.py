# -*- coding: utf-8 -*-
"""Data models for evaluation capabilities with M&NTIS.


This is heavily inspired by QTI (Question and Test Interoperability) assessment items and tests based on the QTI 3.0
 specification. Any modification should respect this.
 Inspiration can also be found here: https://github.com/trilogy-group/timeback-client/blob/main/src/timeback_client/models/qti.py
"""
from enum import Enum
from typing import List
from typing import Optional
from typing import Union

from pydantic import BaseModel
from pydantic import model_validator


class InteractionEnum(str, Enum):
    """QTI Interaction Types per QTI 3.0 specification."""

    CHOICE = "choice"
    TEXT_ENTRY = "text-entry"
    # EXTENDED_TEXT = "extended-text"
    # INLINE_CHOICE = "inline-choice"
    # MATCH = "match"
    # ORDER = "order"
    # ASSOCIATE = "associate"
    # HOTSPOT = "hotspot"
    # SELECT_POINT = "select-point"
    # GRAPHIC_ORDER = "graphic-order"
    # GRAPHIC_ASSOCIATE = "graphic-associate"
    # GRAPHIC_GAP_MATCH = "graphic-gap-match"
    # SLIDER = "slider"
    # DRAWING = "drawing"
    # MEDIA = "media"
    # CUSTOM = "custom"
    # UPLOAD = "upload"


class CardinalityEnum(str, Enum):
    """Cardinality Enum
    https://www.imsglobal.org/sites/default/files/spec/qti/v3/info/index.html#Enumerated_CardinalityEnum
    """

    SINGLE = "single"
    MULTIPLE = "multiple"
    ORDERED = "ordered"
    RECORD = "record"


class BaseTypeEnum(str, Enum):
    """
    Base Type Enum
    https://www.imsglobal.org/sites/default/files/spec/qti/v3/info/index.html#DataCharacteristic_ResponseDeclaration.Attr_base-type
    """

    BOOLEAN = "boolean"
    DIRECTED_PAIR = "directedPair"
    DURATION = "duration"
    FILE = "file"
    FLOAT = "float"
    IDENTIFIER = "identifier"
    INTEGER = "integer"
    PAIR = "pair"
    POINT = "point"
    STRING = "string"
    URI = "uri"


class NavigationMode(str, Enum):
    """QTI navigation modes."""

    LINEAR = "linear"
    NONLINEAR = "nonlinear"


class SubmissionMode(str, Enum):
    INDIVIDUAL = "individual"
    SIMULTANEOUS = "simultaneous"


class SimpleChoice(BaseModel):
    """Simple Choice model."""

    identifier: str
    choice: str


class ChoiceInteraction(BaseModel):
    """Choice option for choice interactions."""

    ## Characteristics
    # shuffle: Optional[bool] = None ignored for now
    max_choices: Optional[int] = None
    min_choices: Optional[int] = None
    # orientation is ignored for now
    # data-min-selections-message is ignored for now
    # data-max-selections-message is ignored for now
    response_identifier: str

    ## Attributes
    simple_choice: List[SimpleChoice]


class TextEntryInteraction(BaseModel):
    """
    Text Entry Interaction model.
    """

    ## Characteristics
    placeholder_text: Optional[str]
    response_identifier: str
    #  all are ignored for now


class CorrectResponse(BaseModel):
    """Correct Response
    https://www.imsglobal.org/sites/default/files/spec/qti/v3/info/index.html#DataAttribute_ResponseDeclaration_qti-correct-response
    """

    ## characteristics
    # interpretation is ignored for now

    ## Children attributes
    value: Union[str, int, float, bool]


class ResponseDeclaration(BaseModel):
    """Response Declaration that defines the expected response.
    https://www.imsglobal.org/sites/default/files/spec/qti/v3/info/index.html#Data_ResponseDeclaration
    """

    ## Characteristics
    identifier: str
    cardinality: CardinalityEnum
    base_type: BaseTypeEnum

    ## Children attributes
    # qti-default-value is ignored for now
    correct_response: Union[CorrectResponse, List[CorrectResponse]]
    # qti-mapping is ignored for now
    # qti-area-mapping is ignored for now


class DefaultValue(BaseModel):
    """Default Value.
    https://www.imsglobal.org/sites/default/files/spec/qti/v3/info/index.html#Data_DefaultValue
    """

    ## characteristics
    # interpretation is ignored for now

    ## children
    value: Union[str, int, float, bool]


class OutcomeDeclaration(BaseModel):
    """Outcome Declaration for test results
    https://www.imsglobal.org/sites/default/files/spec/qti/v3/info/index.html#Root_OutcomeDeclaration
    """

    ## characteristics
    identifier: str
    cardinality: CardinalityEnum
    base_type: BaseTypeEnum
    # view is ignored for now
    # interpretation is ignored for now
    # long-interpretation is ignored for now
    normal_maximum: Optional[float] = None
    normal_minimum: Optional[float] = None
    # external-scored is ignored for now
    # variable-identifier-ref is ignored for now

    ## Children
    default_value: Optional[DefaultValue] = None
    # lookup-table is ignored for now


class ItemBody(BaseModel):
    """QTI Item Body containing elements."""

    # huge deviation from the spec
    prompt: str  # the question to prompt
    interaction: Union[ChoiceInteraction, TextEntryInteraction]
    interaction_type: InteractionEnum

    @model_validator(mode="after")
    def check_interaction_type(self):
        if isinstance(self.interaction, ChoiceInteraction):
            if self.interaction_type != InteractionEnum.CHOICE:
                raise ValueError(
                    "interaction_type must be 'choice' for ChoiceInteraction"
                )
        elif isinstance(self.interaction, TextEntryInteraction):
            if self.interaction_type != InteractionEnum.TEXT_ENTRY:
                raise ValueError(
                    "interaction_type must be 'text-entry' for TextEntryInteraction"
                )
        return self


class AssessmentItem(BaseModel):
    """Assessment Item model to match the API expectations.
    https://www.imsglobal.org/sites/default/files/spec/qti/v3/info/index.html#Root_AssessmentItem
    """

    # Characteristics
    identifier: str
    title: str
    label: Optional[str] = None
    language: Optional[str] = None
    # tool-name is ignored for now - specified at test level
    # tool-version is ignored for now - specified at test level
    # adaptative is ignored for now
    # time-dependent is ignored for now
    # data-extension is ignored

    ## attributes
    # qti-context-declaration is ignored for now
    response_declarations: List[ResponseDeclaration]
    outcome_declaration: Optional[List[OutcomeDeclaration]] = None
    # qti-template-declaration is ignored for now
    # qti-template-processing is ignored for now
    # qti-assessment-stimulus0-ref is ignored for now
    # qti-companion-materials-info is ignored for now
    # qti-stylesheet is ignored for now
    item_body: ItemBody
    # qti-catalog-info is ignored for now
    # qti-response_processing is ignored for now
    # qti-modal-feedback is ignored for now


class Section(BaseModel):
    """Section model
    https://www.imsglobal.org/sites/default/files/spec/qti/v3/info/index.html#Root_AssessmentSection
    """

    # children
    identifier: str
    required: Optional[bool] = False
    fixed: Optional[bool] = False
    title: str
    # class_: Optional[List[str]] = Field(None, alias="class") ignore for now
    # visible: bool = True ignore for now
    # keep_together: Optional[bool] = Field(None, alias="keep-together") ignore for now
    # sequence: Optional[int] = None ignore for now, does not seem to be in the spec
    # qti_assessment_item_ref: Optional[List[QTIItemRef]] = Field(
    #     None, alias="qti-assessment-item-ref"
    # )

    # this is a huge deviation from the spec to be quicker - we are not using ref
    assessment_items: List[AssessmentItem]


class TestPart(BaseModel):
    """Test Part model
    https://www.imsglobal.org/sites/default/files/spec/qti/v3/info/index.html#Data_TestPart
    """

    ## characteristics
    identifier: str
    title: Optional[str]
    # class is ignored for now
    navigation_mode: NavigationMode = NavigationMode.LINEAR
    submission_mode: SubmissionMode = SubmissionMode.SIMULTANEOUS
    # data-extension is ignored for now

    ## children
    # we ignore all children for now except this section
    assessment_section: List[Section]


class AssessmentTest(BaseModel):
    """Assessment Test model
    https://www.imsglobal.org/sites/default/files/spec/qti/v3/info/index.html#Root_AssessmentTest
    """

    ## Characteristics
    identifier: str
    title: str
    # class is ignored for now
    tool_name: Optional[str] = "M&NTIS Platform"
    tool_version: Optional[str] = None

    ## Children attributes
    # qti-context-declaration is ignored for now
    # qti-outcome_declaration: List[OutcomeDeclaration] is ignored for now
    # qti-time-limits is ignored for now
    # qti-stylesheet is ignored for now
    # qti-rubric-block is ignored for now
    test_part: List[TestPart]
    # qti-outcome-processing
    # qti-test-feedback
