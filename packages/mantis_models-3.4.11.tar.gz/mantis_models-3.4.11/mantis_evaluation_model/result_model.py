# -*- coding: utf-8 -*-
"""Data models for results.
"""
from typing import List

from pydantic import BaseModel


class AssessmentItemResult(BaseModel):
    identifier: str
    result: bool


class SectionResult(BaseModel):
    identifier: str
    assessment_items: List[AssessmentItemResult]


class TestPartResult(BaseModel):
    identifier: str
    assessment_section: List[SectionResult]


class AssessmentTestResult(BaseModel):
    identifier: str
    test_part: List[TestPartResult]
