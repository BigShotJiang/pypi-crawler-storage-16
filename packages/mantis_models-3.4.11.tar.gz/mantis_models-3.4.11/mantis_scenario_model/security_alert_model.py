# -*- coding: utf-8 -*-
from enum import Enum
from typing import List
from typing import Optional

from mantis_scenario_model.common import WorkerMitreData
from pydantic import BaseModel


class SecurityAlertStatus(str, Enum):
    new = "NEW"
    active = "ACTIVE"
    closed = "CLOSED"
    unknown = "UNKNOWN"


class SecurityAlert(BaseModel):
    alert_id: Optional[str] = None
    """ID of the generated alert."""

    alert_name: str
    """Name of the generated alert."""

    alert_status: Optional[SecurityAlertStatus] = None
    """Status of the alert."""

    alert_logs: List[str] = []
    """Logs associated with the alert."""

    signature_id: Optional[str] = None
    """ID of the associated signature."""

    signature_name: Optional[str] = None
    """Name of the associated signature."""

    mitre_data: Optional[WorkerMitreData] = None
    """MITRE ATT&CK classification."""

    asset_ip: Optional[str] = None
    """IP address of the asset on which the event has taken place."""

    asset_hostname: Optional[str] = None
    """Hostname of the asset on which the event has taken place."""

    start_time: str
    """Start time of first associated event, in the ISO 8601 format: "2025-10-08T20:51:25.143635+00:00". """

    end_time: str
    """End time of last associated event, in the ISO 8601 format: "2025-10-08T20:51:25.143635+00:00". """

    correlated_attacks: List[int] = []
    """List of corresponding attack IDs identified after
    attack-defense correlation.

    A security alert may have multiple corresponding attack steps.

    A security alert not associated with an attack step may correspond
    to a false positive.

    """
