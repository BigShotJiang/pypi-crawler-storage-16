:notoc: true

.. _index:

Welcome to mapflow's documentation!
===================================

``mapflow`` transforms 3D ``xr.DataArray`` into video files in one line of code.

.. toctree::
   :maxdepth: 1
   :caption: Contents:
   :hidden:

   installation
   how_to_use
   api
