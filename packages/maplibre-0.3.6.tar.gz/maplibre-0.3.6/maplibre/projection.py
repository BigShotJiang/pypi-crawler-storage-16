from enum import Enum

class ProjectionType(Enum):
    MERCATOR = "mercator"
    VERTICAL_PERSPECTIVE = "vertical-perspective"
    GLOBE = "vertical-perspective"
