"""
Gemini API Client - Google Gemini 模型的批量调用客户端

与 OpenAIClient 保持相同的接口，方便上层代码无缝切换
"""

import asyncio
import base64
import re
from typing import TYPE_CHECKING, List, Union, Optional, Any

from loguru import logger

from maque import ConcurrentRequester
from .processors.image_processor import ImageCacheConfig

if TYPE_CHECKING:
    from maque.async_api.interface import RequestResult


class GeminiClient:
    """
    Google Gemini API 客户端

    与 OpenAIClient 保持相同的接口，支持：
    - 单条/批量聊天完成
    - 流式输出
    - 图片处理（自动转换为 Gemini 格式）
    - 两种 API 模式：Gemini Developer API 和 Vertex AI

    Example (Gemini Developer API):
        >>> client = GeminiClient(
        ...     api_key="your-api-key",
        ...     model="gemini-2.5-flash"
        ... )
        >>> result = client.chat_completions_sync(
        ...     messages=[{"role": "user", "content": "Hello!"}]
        ... )

    Example (Vertex AI):
        >>> client = GeminiClient(
        ...     project_id="your-project-id",
        ...     location="us-central1",
        ...     model="gemini-2.5-flash",
        ...     use_vertex_ai=True,
        ... )
    """

    # Gemini Developer API 基础 URL
    DEFAULT_BASE_URL = "https://generativelanguage.googleapis.com/v1beta"
    # Vertex AI 基础 URL 模板
    VERTEX_AI_URL_TEMPLATE = "https://{location}-aiplatform.googleapis.com/v1"

    def __init__(
        self,
        api_key: str = None,
        model: str = None,
        base_url: str = None,
        concurrency_limit: int = 10,
        max_qps: int = 60,  # Gemini 默认限制较低
        timeout: int = 120,
        retry_times: int = 3,
        retry_delay: float = 1.0,
        cache_image: bool = False,
        cache_dir: str = "image_cache",
        # Vertex AI 专用参数
        use_vertex_ai: bool = False,
        project_id: str = None,
        location: str = "us-central1",
        credentials: Any = None,
        **kwargs,
    ):
        """
        初始化 Gemini 客户端

        Args:
            api_key: Google AI API 密钥（Gemini Developer API 模式）
            model: 模型名称，如 "gemini-2.5-flash", "gemini-2.5-pro"
            base_url: API 基础 URL，默认根据模式自动选择
            concurrency_limit: 并发请求限制
            max_qps: 最大 QPS（Gemini 免费版限制较严格）
            timeout: 请求超时时间（秒）
            retry_times: 重试次数
            retry_delay: 重试延迟（秒）
            cache_image: 是否缓存图片
            cache_dir: 图片缓存目录
            use_vertex_ai: 是否使用 Vertex AI 模式
            project_id: GCP 项目 ID（Vertex AI 模式必需）
            location: GCP 区域，如 "us-central1", "europe-west1"（Vertex AI 模式）
            credentials: Google Cloud 凭证对象（Vertex AI 模式，可选，默认使用 ADC）
        """
        self._use_vertex_ai = use_vertex_ai
        self._project_id = project_id
        self._location = location
        self._credentials = credentials
        self._access_token = None
        self._token_expiry = None

        # 验证参数
        if use_vertex_ai:
            if not project_id:
                raise ValueError("Vertex AI 模式需要提供 project_id")
            self._base_url = base_url or self.VERTEX_AI_URL_TEMPLATE.format(location=location)
        else:
            if not api_key:
                raise ValueError("Gemini Developer API 模式需要提供 api_key")
            self._base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")

        self._client = ConcurrentRequester(
            concurrency_limit=concurrency_limit,
            max_qps=max_qps,
            timeout=timeout,
            retry_times=retry_times,
            retry_delay=retry_delay,
        )
        self._api_key = api_key
        self._model = model
        self._concurrency_limit = concurrency_limit
        self._cache_config = ImageCacheConfig(
            enabled=cache_image,
            cache_dir=cache_dir,
            force_refresh=False,
            retry_failed=False,
        )

    def _convert_messages_to_contents(
        self,
        messages: List[dict],
        system_instruction: str = None,
    ) -> tuple[List[dict], Optional[dict]]:
        """
        将 OpenAI 格式的 messages 转换为 Gemini 格式的 contents

        OpenAI 格式:
            [{"role": "user", "content": "Hello"}]
            [{"role": "user", "content": [{"type": "text", "text": "..."},
                                          {"type": "image_url", "image_url": {"url": "..."}}]}]

        Gemini 格式:
            [{"role": "user", "parts": [{"text": "Hello"}]}]
            [{"role": "user", "parts": [{"text": "..."},
                                        {"inline_data": {"mime_type": "...", "data": "..."}}]}]

        Returns:
            (contents, system_instruction_obj)
        """
        contents = []
        extracted_system = system_instruction

        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")

            # 处理系统消息 -> Gemini 的 systemInstruction
            if role == "system":
                if isinstance(content, str):
                    extracted_system = content
                elif isinstance(content, list):
                    # 提取文本部分
                    texts = [p.get("text", "") for p in content if p.get("type") == "text"]
                    extracted_system = "\n".join(texts)
                continue

            # 转换角色名称
            gemini_role = "model" if role == "assistant" else "user"

            # 转换内容
            parts = self._convert_content_to_parts(content)

            if parts:
                contents.append({
                    "role": gemini_role,
                    "parts": parts
                })

        # 构建 systemInstruction 对象
        system_obj = None
        if extracted_system:
            system_obj = {
                "parts": [{"text": extracted_system}]
            }

        return contents, system_obj

    def _convert_content_to_parts(self, content: Any) -> List[dict]:
        """
        将 OpenAI 格式的 content 转换为 Gemini 格式的 parts
        """
        if content is None:
            return []

        # 简单字符串
        if isinstance(content, str):
            return [{"text": content}]

        # 复杂内容列表
        if isinstance(content, list):
            parts = []
            for item in content:
                if isinstance(item, str):
                    parts.append({"text": item})
                elif isinstance(item, dict):
                    item_type = item.get("type", "text")

                    if item_type == "text":
                        text = item.get("text", "")
                        if text:
                            parts.append({"text": text})

                    elif item_type == "image_url":
                        # 转换图片 URL
                        image_data = self._convert_image_url(item.get("image_url", {}))
                        if image_data:
                            parts.append(image_data)

                    elif item_type == "image":
                        # 直接的 base64 图片数据
                        image_data = self._convert_image_direct(item)
                        if image_data:
                            parts.append(image_data)

            return parts

        return []

    def _convert_image_url(self, image_url_obj: dict) -> Optional[dict]:
        """
        将 OpenAI 的 image_url 格式转换为 Gemini 的 inline_data 格式

        OpenAI: {"url": "data:image/jpeg;base64,..."} 或 {"url": "https://..."}
        Gemini: {"inline_data": {"mime_type": "image/jpeg", "data": "..."}}
        """
        url = image_url_obj.get("url", "")

        if not url:
            return None

        # base64 数据 URL
        if url.startswith("data:"):
            match = re.match(r"data:([^;]+);base64,(.+)", url)
            if match:
                mime_type = match.group(1)
                data = match.group(2)
                return {
                    "inline_data": {
                        "mime_type": mime_type,
                        "data": data
                    }
                }

        # HTTP(S) URL - Gemini 支持直接使用 URL（仅限 Google Cloud Storage）
        # 对于普通 URL，需要下载并转换为 base64
        # 这里先返回 None，让上层处理器先将 URL 转为 base64
        logger.warning(
            f"Gemini API 不直接支持外部 URL，请先将图片转换为 base64 格式: {url[:50]}..."
        )
        return None

    def _convert_image_direct(self, image_obj: dict) -> Optional[dict]:
        """
        处理直接的图片数据
        """
        data = image_obj.get("data", "")
        mime_type = image_obj.get("mime_type", "image/jpeg")

        if data:
            return {
                "inline_data": {
                    "mime_type": mime_type,
                    "data": data
                }
            }
        return None

    def _build_request_body(
        self,
        contents: List[dict],
        system_instruction: Optional[dict] = None,
        max_tokens: int = None,
        temperature: float = None,
        top_p: float = None,
        top_k: int = None,
        stop_sequences: List[str] = None,
        safety_settings: List[dict] = None,
        **kwargs,
    ) -> dict:
        """
        构建 Gemini API 请求体
        """
        body = {"contents": contents}

        if system_instruction:
            body["systemInstruction"] = system_instruction

        # 构建 generationConfig
        gen_config = {}
        if max_tokens is not None:
            gen_config["maxOutputTokens"] = max_tokens
        if temperature is not None:
            gen_config["temperature"] = temperature
        if top_p is not None:
            gen_config["topP"] = top_p
        if top_k is not None:
            gen_config["topK"] = top_k
        if stop_sequences:
            gen_config["stopSequences"] = stop_sequences

        if gen_config:
            body["generationConfig"] = gen_config

        # 安全设置
        if safety_settings:
            body["safetySettings"] = safety_settings

        return body

    def _get_access_token(self) -> str:
        """
        获取 Vertex AI 的 Access Token（使用 ADC 或指定凭证）
        """
        import time

        # 检查缓存的 token 是否还有效（留 60 秒余量）
        if self._access_token and self._token_expiry:
            if time.time() < self._token_expiry - 60:
                return self._access_token

        try:
            import google.auth
            import google.auth.transport.requests

            if self._credentials:
                credentials = self._credentials
            else:
                # 使用 Application Default Credentials (ADC)
                credentials, _ = google.auth.default(
                    scopes=["https://www.googleapis.com/auth/cloud-platform"]
                )

            # 刷新凭证获取 token
            request = google.auth.transport.requests.Request()
            credentials.refresh(request)

            self._access_token = credentials.token
            # 大部分 token 有效期 1 小时
            self._token_expiry = time.time() + 3600

            return self._access_token

        except ImportError:
            raise ImportError(
                "Vertex AI 模式需要安装 google-auth 库: pip install google-auth"
            )
        except Exception as e:
            raise RuntimeError(f"获取 Vertex AI 访问令牌失败: {e}")

    def _get_url(self, model: str, stream: bool = False) -> str:
        """
        获取 API URL
        """
        action = "streamGenerateContent" if stream else "generateContent"

        if self._use_vertex_ai:
            # Vertex AI URL 格式
            # https://{location}-aiplatform.googleapis.com/v1/projects/{project}/locations/{location}/publishers/google/models/{model}:generateContent
            return (
                f"{self._base_url}/projects/{self._project_id}"
                f"/locations/{self._location}/publishers/google/models/{model}:{action}"
            )
        else:
            # Gemini Developer API URL 格式
            return f"{self._base_url}/models/{model}:{action}?key={self._api_key}"

    def _get_headers(self) -> dict:
        """
        获取请求头
        """
        headers = {"Content-Type": "application/json"}

        if self._use_vertex_ai:
            token = self._get_access_token()
            headers["Authorization"] = f"Bearer {token}"

        return headers

    def _extract_response_text(self, response_data: dict) -> Optional[str]:
        """
        从 Gemini 响应中提取文本

        Gemini 响应格式:
        {
            "candidates": [{
                "content": {
                    "parts": [{"text": "..."}],
                    "role": "model"
                },
                "finishReason": "STOP"
            }]
        }
        """
        try:
            candidates = response_data.get("candidates", [])
            if not candidates:
                # 检查是否被安全过滤
                if "promptFeedback" in response_data:
                    feedback = response_data["promptFeedback"]
                    block_reason = feedback.get("blockReason", "UNKNOWN")
                    logger.warning(f"Request blocked by Gemini: {block_reason}")
                return None

            content = candidates[0].get("content", {})
            parts = content.get("parts", [])

            # 合并所有文本部分
            texts = [p.get("text", "") for p in parts if "text" in p]
            return "".join(texts) if texts else None

        except Exception as e:
            logger.warning(f"Failed to extract response text: {e}")
            return None

    async def wrap_to_request_params(
        self,
        messages: List[dict],
        model: str,
        max_tokens: int = None,
        temperature: float = None,
        top_p: float = None,
        meta: Any = None,
        stream: bool = False,
        **kwargs,
    ) -> dict:
        """
        将参数包装为请求参数（与 OpenAIClient 接口一致）
        """
        contents, system_obj = self._convert_messages_to_contents(messages)

        body = self._build_request_body(
            contents=contents,
            system_instruction=system_obj,
            max_tokens=max_tokens,
            temperature=temperature,
            top_p=top_p,
            **kwargs,
        )

        return {
            "json": body,
            "headers": self._get_headers(),
            "meta": meta,
            "_model": model,  # 存储模型名用于构建 URL
            "_stream": stream,
        }

    async def chat_completions(
        self,
        messages: List[dict],
        model: str = None,
        return_raw: bool = False,
        show_progress: bool = False,
        **kwargs,
    ) -> Union[str, "RequestResult"]:
        """
        单条聊天完成（与 OpenAIClient 接口一致）

        Args:
            messages: OpenAI 格式的消息列表
            model: 模型名称
            return_raw: 是否返回原始响应
            show_progress: 是否显示进度
            **kwargs: 其他参数（temperature, max_tokens 等）

        Returns:
            生成的文本或原始响应对象
        """
        effective_model = model or self._model
        if not effective_model:
            raise ValueError("必须提供 model 参数或在初始化时指定 model")

        request_params = await self.wrap_to_request_params(
            messages, effective_model, **kwargs
        )

        url = self._get_url(effective_model, stream=False)

        results, _ = await self._client.process_requests(
            request_params=[{
                "json": request_params["json"],
                "headers": request_params["headers"],
                "meta": request_params.get("meta"),
            }],
            url=url,
            method="POST",
            show_progress=show_progress,
        )

        data = results[0]

        if return_raw:
            return data

        if data.status == "success":
            return self._extract_response_text(data.data)
        else:
            return data

    def chat_completions_sync(
        self,
        messages: List[dict],
        model: str = None,
        return_raw: bool = False,
        **kwargs,
    ) -> Union[str, "RequestResult"]:
        """
        同步版本的聊天完成
        """
        return asyncio.run(
            self.chat_completions(
                messages=messages,
                model=model,
                return_raw=return_raw,
                **kwargs,
            )
        )

    async def chat_completions_batch(
        self,
        messages_list: List[List[dict]],
        model: str = None,
        return_raw: bool = False,
        show_progress: bool = True,
        return_summary: bool = False,
        **kwargs,
    ) -> Union[List[str], tuple]:
        """
        批量聊天完成（与 OpenAIClient 接口一致）

        Args:
            messages_list: 消息列表的列表
            model: 模型名称
            return_raw: 是否返回原始响应
            show_progress: 是否显示进度条
            return_summary: 是否返回统计摘要
            **kwargs: 其他参数

        Returns:
            生成的文本列表，或 (文本列表, 摘要)
        """
        effective_model = model or self._model
        if not effective_model:
            raise ValueError("必须提供 model 参数或在初始化时指定 model")

        url = self._get_url(effective_model, stream=False)

        # 构建所有请求参数
        request_params_list = []
        for messages in messages_list:
            params = await self.wrap_to_request_params(
                messages, effective_model, **kwargs
            )
            request_params_list.append({
                "json": params["json"],
                "headers": params["headers"],
                "meta": params.get("meta"),
            })

        results, progress = await self._client.process_requests(
            request_params=request_params_list,
            url=url,
            method="POST",
            show_progress=show_progress,
        )

        summary = progress.summary(print_to_console=False) if progress else None

        if return_raw:
            return (results, summary) if return_summary else results

        # 提取文本内容
        content_list = []
        for result in results:
            try:
                if result.status == "success":
                    content = self._extract_response_text(result.data)
                else:
                    logger.warning(f"Request failed: {result}")
                    content = None
            except Exception as e:
                logger.warning(f"Error extracting content: {e}, result={result}")
                content = None
            content_list.append(content)

        return (content_list, summary) if return_summary else content_list

    def chat_completions_batch_sync(
        self,
        messages_list: List[List[dict]],
        model: str = None,
        return_raw: bool = False,
        show_progress: bool = True,
        return_summary: bool = False,
        **kwargs,
    ) -> Union[List[str], tuple]:
        """
        同步版本的批量聊天完成
        """
        return asyncio.run(
            self.chat_completions_batch(
                messages_list=messages_list,
                model=model,
                return_raw=return_raw,
                show_progress=show_progress,
                return_summary=return_summary,
                **kwargs,
            )
        )

    async def chat_completions_stream(
        self,
        messages: List[dict],
        model: str = None,
        **kwargs,
    ):
        """
        流式聊天完成 - 逐 token 返回响应

        Args:
            messages: 消息列表
            model: 模型名称
            **kwargs: 其他参数

        Yields:
            str: 流式返回的 token 片段
        """
        import aiohttp
        import json

        effective_model = model or self._model
        if not effective_model:
            raise ValueError("必须提供 model 参数或在初始化时指定 model")

        contents, system_obj = self._convert_messages_to_contents(messages)
        body = self._build_request_body(
            contents=contents,
            system_instruction=system_obj,
            **kwargs,
        )

        url = self._get_url(effective_model, stream=True)
        # 添加 alt=sse 以获取 SSE 格式的流式响应
        if "?" in url:
            url += "&alt=sse"
        else:
            url += "?alt=sse"

        timeout = aiohttp.ClientTimeout(total=120)

        async with aiohttp.ClientSession() as session:
            async with session.post(
                url,
                json=body,
                headers=self._get_headers(),
                timeout=timeout,
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise Exception(f"HTTP {response.status}: {error_text}")

                async for line in response.content:
                    line = line.decode("utf-8").strip()

                    if line.startswith("data: "):
                        data_str = line[6:]

                        if data_str == "[DONE]":
                            break

                        try:
                            data = json.loads(data_str)
                            text = self._extract_response_text(data)
                            if text:
                                yield text
                        except json.JSONDecodeError:
                            continue

    def model_list(self) -> List[str]:
        """
        获取可用模型列表

        Note: Gemini API 的模型列表端点与 OpenAI 不同
        """
        import requests

        if self._use_vertex_ai:
            # Vertex AI 模型列表需要通过不同的 API
            url = (
                f"{self._base_url}/projects/{self._project_id}"
                f"/locations/{self._location}/publishers/google/models"
            )
            headers = self._get_headers()
            response = requests.get(url, headers=headers)
        else:
            url = f"{self._base_url}/models?key={self._api_key}"
            response = requests.get(url)

        if response.status_code == 200:
            data = response.json()
            models = data.get("models", [])
            return [m.get("name", "").replace("models/", "") for m in models]
        else:
            logger.error(f"Failed to fetch model list: {response.text}")
            return []
