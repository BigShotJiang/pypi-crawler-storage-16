import asyncio
from typing import TYPE_CHECKING, List, Union, Optional

from loguru import logger

from maque import ConcurrentRequester
from .processors.messages_processor import (
    batch_process_messages,
    messages_preprocess,
)
from .processors.unified_processor import (
    batch_process_messages as optimized_batch_messages_preprocess,
)
from .processors.image_processor import ImageCacheConfig
from .response_cache import ResponseCache, ResponseCacheConfig

if TYPE_CHECKING:
    from maque.async_api.interface import RequestResult


class OpenAIClient:
    def __init__(
        self,
        base_url: str,
        api_key="EMPTY",
        model=None,
        concurrency_limit=10,
        max_qps=1000,
        timeout=100,
        retry_times=3,
        retry_delay=0.55,
        cache_image=False,
        cache_dir="image_cache",
        response_cache: Optional[ResponseCacheConfig] = None,
        **kwargs,
    ):
        self._client = ConcurrentRequester(
            concurrency_limit=concurrency_limit,
            max_qps=max_qps,
            timeout=timeout,
            retry_times=retry_times,
            retry_delay=retry_delay,
        )
        self._concurrency_limit = concurrency_limit
        self._headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        }
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._model = model
        self._cache_config = ImageCacheConfig(
            enabled=cache_image,
            cache_dir=cache_dir,
            force_refresh=False,
            retry_failed=False,
        )
        # 响应缓存
        self._response_cache = ResponseCache(response_cache) if response_cache else None

    async def wrap_to_request_params(
        self,
        messages: list,
        model: str,
        max_tokens=None,
        meta=None,
        preprocess_msg=False,
        stream=False,
        **kwargs,
    ):
        if preprocess_msg:
            messages = await messages_preprocess(
                messages, preprocess_msg=preprocess_msg, cache_config=self._cache_config
            )
        request_params = {
            "json": {
                "messages": messages,
                "model": model,
                "stream": stream,
                "max_tokens": max_tokens,
                **kwargs,
            },
            "headers": self._headers,
            "meta": meta,
        }
        return request_params

    async def chat_completions(
        self,
        messages: list,
        model: str = None,
        return_raw=False,
        preprocess_msg=False,
        url=None,
        show_progress=False,
        **kwargs,
    ) -> Union[str, "RequestResult"]:
        # 如果没有传递model参数，使用初始化时的model
        effective_model = model or self._model
        if not effective_model:
            raise ValueError("必须提供model参数或在初始化OpenAIClient时指定model")
        
        result, _ = await self._client.process_requests(
            request_params=[
                await self.wrap_to_request_params(
                    messages, effective_model, preprocess_msg=preprocess_msg, **kwargs
                )
            ],
            url=url or f"{self._base_url}/chat/completions",
            method="POST",
            show_progress=show_progress,
        )
        data = result[0]
        if return_raw:
            return data
        else:
            if data.status == "success":
                return data.data["choices"][0]["message"]["content"]
            else:
                return data

    def chat_completions_sync(
        self, messages: list, model: str = None, return_raw=False, url=None, **kwargs
    ):
        return asyncio.run(
            self.chat_completions(
                messages=messages, model=model, return_raw=return_raw, url=url, **kwargs
            )
        )

    async def chat_completions_batch(
        self,
        messages_list: List[list],
        model: str = None,
        url=None,
        return_raw=False,
        show_progress=True,
        preprocess_msg=False,
        return_summary=False,
        use_cache=True,
        **kwargs,
    ):
        # 如果没有传递model参数，使用初始化时的model
        effective_model = model or self._model
        if not effective_model:
            raise ValueError("必须提供model参数或在初始化OpenAIClient时指定model")

        if preprocess_msg:
            messages_list = await optimized_batch_messages_preprocess(
                messages_list,
                max_concurrent=self._concurrency_limit,
                cache_config=self._cache_config,
            )

        # 检查响应缓存
        cached_responses = [None] * len(messages_list)
        uncached_indices = list(range(len(messages_list)))

        if use_cache and self._response_cache:
            cached_responses, uncached_indices = self._response_cache.get_batch(
                messages_list, model=effective_model, **kwargs
            )
            if uncached_indices:
                logger.info(f"缓存命中: {len(messages_list) - len(uncached_indices)}/{len(messages_list)}")

        # 只请求未缓存的
        if uncached_indices:
            uncached_messages = [messages_list[i] for i in uncached_indices]
            results, progress = await self._client.process_requests(
                request_params=[
                    await self.wrap_to_request_params(
                        messages, effective_model, preprocess_msg=False, **kwargs
                    )
                    for messages in uncached_messages
                ],
                url=url or f"{self._base_url}/chat/completions",
                method="POST",
                show_progress=show_progress,
            )

            # 提取内容并缓存
            for idx, result in zip(uncached_indices, results):
                try:
                    content = result.data["choices"][0]["message"]["content"]
                    cached_responses[idx] = content
                    # 保存到缓存
                    if self._response_cache:
                        self._response_cache.set(
                            messages_list[idx], content,
                            model=effective_model, **kwargs
                        )
                except Exception as e:
                    logger.warning(f"Error: {e}, set content to None")
                    cached_responses[idx] = None

            summary = progress.summary(print_to_console=False) if progress else None
        else:
            summary = None

        if return_raw:
            # raw 模式不支持缓存，直接返回
            return (cached_responses, summary) if return_summary else cached_responses

        return (cached_responses, summary) if return_summary else cached_responses

    def chat_completions_batch_sync(
        self,
        messages_list: List[list],
        model: str = None,
        url=None,
        return_raw=False,
        show_progress=True,
        preprocess_msg=False,
        return_summary=False,
        **kwargs,
    ):
        return asyncio.run(
            self.chat_completions_batch(
                messages_list=messages_list,
                model=model,
                url=url,
                return_raw=return_raw,
                show_progress=show_progress,
                preprocess_msg=preprocess_msg,
                return_summary=return_summary,
                **kwargs,
            )
        )

    async def iter_chat_completions_batch(
        self,
        messages_list: List[list],
        model: str,
        url=None,
        batch_size=None,
        return_raw=False,
        show_progress=True,
        preprocess_msg=False,
        return_summary=False,
        **kwargs,
    ):
        if preprocess_msg:
            messages_list = await batch_process_messages(
                messages_list,
                preprocess_msg=preprocess_msg,
                max_concurrent=self._concurrency_limit,
            )

        async for batch_result in self._client.aiter_stream_requests(
            request_params=[
                await self.wrap_to_request_params(
                    messages, model, preprocess_msg=False, **kwargs
                )
                for messages in messages_list
            ],
            url=url or f"{self._base_url}/chat/completions",
            method="POST",
            show_progress=show_progress,
            batch_size=batch_size,
        ):
            for result in batch_result.completed_requests:
                if return_raw:
                    yield (
                        result.data,
                        batch_result.progress.summary(print_to_console=False)
                        if return_summary
                        else result.data,
                    )
                else:
                    try:
                        content = result.data["choices"][0]["message"]["content"]
                    except Exception as e:
                        logger.warning(
                            f"Error in chat_completions_batch: {e}\n {result=}\n set content to None"
                        )
                        content = None
                    yield (
                        content,
                        batch_result.progress.summary(print_to_console=False)
                        if return_summary
                        else content,
                    )

    async def chat_completions_stream(
        self,
        messages: list,
        model: str = None,
        preprocess_msg=False,
        url=None,
        **kwargs,
    ):
        """
        流式聊天完成 - 逐token返回响应
        
        Args:
            messages: 消息列表
            model: 模型名称
            preprocess_msg: 是否预处理消息
            url: API URL
            **kwargs: 其他参数
            
        Yields:
            str: 流式返回的token片段
        """
        # 如果没有传递model参数，使用初始化时的model
        effective_model = model or self._model
        if not effective_model:
            raise ValueError("必须提供model参数或在初始化OpenAIClient时指定model")
            
        if preprocess_msg:
            messages = await messages_preprocess(
                messages, preprocess_msg=preprocess_msg, cache_config=self._cache_config
            )
        
        request_params = await self.wrap_to_request_params(
            messages, effective_model, preprocess_msg=False, stream=True, **kwargs
        )
        
        import aiohttp
        import json
        
        timeout_obj = getattr(self._client, '_timeout', aiohttp.ClientTimeout(total=100))
        async with aiohttp.ClientSession() as session:
            async with session.post(
                url or f"{self._base_url}/chat/completions",
                json=request_params["json"],
                headers=request_params["headers"],
                timeout=timeout_obj
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise Exception(f"HTTP {response.status}: {error_text}")
                
                async for line in response.content:
                    line = line.decode('utf-8').strip()
                    if line.startswith('data: '):
                        data_str = line[6:]  # 移除 'data: ' 前缀
                        
                        # 检查是否为结束标记
                        if data_str == '[DONE]':
                            break
                        
                        try:
                            data = json.loads(data_str)
                            if 'choices' in data and len(data['choices']) > 0:
                                delta = data['choices'][0].get('delta', {})
                                if 'content' in delta:
                                    yield delta['content']
                        except json.JSONDecodeError:
                            # 忽略无法解析的行
                            continue

    def model_list(self):
        from openai import OpenAI

        client = OpenAI(base_url=self._base_url, api_key=self._api_key)
        openai_model_list = [i.id for i in client.models.list()]
        return openai_model_list
