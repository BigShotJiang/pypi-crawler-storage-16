"""
LLMClientBase - LLM 客户端抽象基类

提供通用的方法实现，子类只需实现核心的差异化方法。
"""

import asyncio
from abc import ABC
from typing import TYPE_CHECKING, List, Union, Optional, Any

from loguru import logger

from maque import ConcurrentRequester
from .processors.image_processor import ImageCacheConfig
from .processors.messages_processor import messages_preprocess
from .processors.unified_processor import batch_process_messages as optimized_batch_preprocess
from .response_cache import ResponseCache, ResponseCacheConfig

if TYPE_CHECKING:
    from maque.async_api.interface import RequestResult


class LLMClientBase(ABC):
    """
    LLM 客户端抽象基类

    子类只需实现 4 个核心方法：
    - _get_url(model, stream) -> str
    - _get_headers() -> dict
    - _build_request_body(messages, model, **kwargs) -> dict
    - _extract_content(response_data) -> str

    可选覆盖：
    - _extract_stream_content(data) -> str
    - _get_stream_url(model) -> str
    """

    def __init__(
        self,
        base_url: str = None,
        api_key: str = None,
        model: str = None,
        concurrency_limit: int = 10,
        max_qps: int = 1000,
        timeout: int = 120,
        retry_times: int = 3,
        retry_delay: float = 1.0,
        cache_image: bool = False,
        cache_dir: str = "image_cache",
        response_cache: Optional[ResponseCacheConfig] = None,
        **kwargs,
    ):
        self._base_url = base_url.rstrip("/") if base_url else None
        self._api_key = api_key
        self._model = model
        self._concurrency_limit = concurrency_limit
        self._timeout = timeout

        self._client = ConcurrentRequester(
            concurrency_limit=concurrency_limit,
            max_qps=max_qps,
            timeout=timeout,
            retry_times=retry_times,
            retry_delay=retry_delay,
        )

        self._cache_config = ImageCacheConfig(
            enabled=cache_image,
            cache_dir=cache_dir,
            force_refresh=False,
            retry_failed=False,
        )

        self._response_cache = ResponseCache(response_cache) if response_cache else None

    # ========== 核心抽象方法（子类必须实现）==========

    def _get_url(self, model: str, stream: bool = False) -> str:
        raise NotImplementedError

    def _get_headers(self) -> dict:
        raise NotImplementedError

    def _build_request_body(
        self, messages: List[dict], model: str, stream: bool = False, **kwargs
    ) -> dict:
        raise NotImplementedError

    def _extract_content(self, response_data: dict) -> Optional[str]:
        raise NotImplementedError

    # ========== 可选覆盖的钩子方法 ==========

    def _extract_stream_content(self, data: dict) -> Optional[str]:
        return self._extract_content(data)

    def _get_stream_url(self, model: str) -> str:
        return self._get_url(model, stream=True)

    # ========== 通用工具方法 ==========

    def _get_effective_model(self, model: str = None) -> str:
        effective_model = model or self._model
        if not effective_model:
            raise ValueError("必须提供 model 参数或在初始化时指定 model")
        return effective_model

    async def _preprocess_messages(
        self, messages: List[dict], preprocess_msg: bool = False
    ) -> List[dict]:
        """消息预处理（图片转 base64 等）"""
        if preprocess_msg:
            return await messages_preprocess(
                messages, preprocess_msg=preprocess_msg, cache_config=self._cache_config
            )
        return messages

    async def _preprocess_messages_batch(
        self, messages_list: List[List[dict]], preprocess_msg: bool = False
    ) -> List[List[dict]]:
        """批量消息预处理"""
        if preprocess_msg:
            return await optimized_batch_preprocess(
                messages_list, max_concurrent=self._concurrency_limit, cache_config=self._cache_config
            )
        return messages_list

    # ========== 通用接口实现 ==========

    async def chat_completions(
        self,
        messages: List[dict],
        model: str = None,
        return_raw: bool = False,
        show_progress: bool = False,
        preprocess_msg: bool = False,
        **kwargs,
    ) -> Union[str, "RequestResult"]:
        """单条聊天完成"""
        effective_model = self._get_effective_model(model)
        messages = await self._preprocess_messages(messages, preprocess_msg)

        body = self._build_request_body(messages, effective_model, stream=False, **kwargs)
        request_params = {"json": body, "headers": self._get_headers()}
        url = self._get_url(effective_model, stream=False)

        results, _ = await self._client.process_requests(
            request_params=[request_params], url=url, method="POST", show_progress=show_progress
        )

        data = results[0]
        if return_raw:
            return data
        if data.status == "success":
            return self._extract_content(data.data)
        return data

    def chat_completions_sync(
        self, messages: List[dict], model: str = None, return_raw: bool = False, **kwargs
    ) -> Union[str, "RequestResult"]:
        """同步版本的聊天完成"""
        return asyncio.run(
            self.chat_completions(messages=messages, model=model, return_raw=return_raw, **kwargs)
        )

    async def chat_completions_batch(
        self,
        messages_list: List[List[dict]],
        model: str = None,
        return_raw: bool = False,
        show_progress: bool = True,
        return_summary: bool = False,
        preprocess_msg: bool = False,
        use_cache: bool = True,
        **kwargs,
    ) -> Union[List[str], tuple]:
        """批量聊天完成"""
        effective_model = self._get_effective_model(model)
        url = self._get_url(effective_model, stream=False)
        headers = self._get_headers()

        messages_list = await self._preprocess_messages_batch(messages_list, preprocess_msg)

        async def executor(msgs):
            request_params = [
                {"json": self._build_request_body(m, effective_model, **kwargs), "headers": headers}
                for m in msgs
            ]
            return await self._client.process_requests(
                request_params=request_params, url=url, method="POST", show_progress=show_progress
            )

        def extractor(result):
            return self._extract_content(result.data)

        # 带缓存执行 or 直接执行
        if use_cache and self._response_cache:
            responses, progress = await self._response_cache.execute_with_cache(
                messages_list, executor, extractor, model=effective_model, **kwargs
            )
        else:
            results, progress = await executor(messages_list)
            responses = []
            for r in results:
                try:
                    responses.append(extractor(r))
                except Exception as e:
                    logger.warning(f"Error: {e}, set content to None")
                    responses.append(None)

        summary = progress.summary(print_to_console=False) if progress else None
        return (responses, summary) if return_summary else responses

    def chat_completions_batch_sync(
        self,
        messages_list: List[List[dict]],
        model: str = None,
        return_raw: bool = False,
        show_progress: bool = True,
        return_summary: bool = False,
        **kwargs,
    ) -> Union[List[str], tuple]:
        """同步版本的批量聊天完成"""
        return asyncio.run(
            self.chat_completions_batch(
                messages_list=messages_list,
                model=model,
                return_raw=return_raw,
                show_progress=show_progress,
                return_summary=return_summary,
                **kwargs,
            )
        )

    async def chat_completions_stream(
        self, messages: List[dict], model: str = None, preprocess_msg: bool = False, **kwargs
    ):
        """流式聊天完成"""
        import aiohttp
        import json

        effective_model = self._get_effective_model(model)
        messages = await self._preprocess_messages(messages, preprocess_msg)

        body = self._build_request_body(messages, effective_model, stream=True, **kwargs)
        url = self._get_stream_url(effective_model)
        headers = self._get_headers()

        timeout = aiohttp.ClientTimeout(total=self._timeout)

        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=body, headers=headers, timeout=timeout) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise Exception(f"HTTP {response.status}: {error_text}")

                async for line in response.content:
                    line = line.decode("utf-8").strip()
                    if line.startswith("data: "):
                        data_str = line[6:]
                        if data_str == "[DONE]":
                            break
                        try:
                            data = json.loads(data_str)
                            content = self._extract_stream_content(data)
                            if content:
                                yield content
                        except json.JSONDecodeError:
                            continue

    def model_list(self) -> List[str]:
        raise NotImplementedError("子类需要实现 model_list 方法")

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(model='{self._model}')"
