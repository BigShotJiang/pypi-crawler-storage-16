"""
OpenAI 兼容 API 客户端

支持 OpenAI、vLLM、通义千问、DeepSeek 等兼容 OpenAI API 的服务。
"""

from typing import TYPE_CHECKING, List, Union, Optional

import aiohttp
import json
from loguru import logger

from .base_client import LLMClientBase
from .processors.messages_processor import batch_process_messages
from .response_cache import ResponseCacheConfig

if TYPE_CHECKING:
    from maque.async_api.interface import RequestResult


class OpenAIClient(LLMClientBase):
    """
    OpenAI 兼容 API 客户端

    Example:
        >>> client = OpenAIClient(
        ...     base_url="https://api.openai.com/v1",
        ...     api_key="your-key",
        ...     model="gpt-4",
        ... )
        >>> result = await client.chat_completions(messages)
    """

    def __init__(
        self,
        base_url: str,
        api_key: str = "EMPTY",
        model: str = None,
        concurrency_limit: int = 10,
        max_qps: int = 1000,
        timeout: int = 100,
        retry_times: int = 3,
        retry_delay: float = 0.55,
        cache_image: bool = False,
        cache_dir: str = "image_cache",
        response_cache: Optional[ResponseCacheConfig] = None,
        **kwargs,
    ):
        super().__init__(
            base_url=base_url,
            api_key=api_key,
            model=model,
            concurrency_limit=concurrency_limit,
            max_qps=max_qps,
            timeout=timeout,
            retry_times=retry_times,
            retry_delay=retry_delay,
            cache_image=cache_image,
            cache_dir=cache_dir,
            response_cache=response_cache,
            **kwargs,
        )
        self._headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        }

    # ========== 实现基类核心方法 ==========

    def _get_url(self, model: str, stream: bool = False) -> str:
        return f"{self._base_url}/chat/completions"

    def _get_headers(self) -> dict:
        return self._headers

    def _build_request_body(
        self, messages: List[dict], model: str, stream: bool = False, max_tokens: int = None, **kwargs
    ) -> dict:
        body = {"messages": messages, "model": model, "stream": stream}
        if max_tokens is not None:
            body["max_tokens"] = max_tokens
        body.update(kwargs)
        return body

    def _extract_content(self, response_data: dict) -> Optional[str]:
        try:
            return response_data["choices"][0]["message"]["content"]
        except (KeyError, IndexError) as e:
            logger.warning(f"Failed to extract content: {e}")
            return None

    def _extract_stream_content(self, data: dict) -> Optional[str]:
        try:
            if "choices" in data and len(data["choices"]) > 0:
                return data["choices"][0].get("delta", {}).get("content")
        except Exception:
            pass
        return None

    # ========== OpenAI 特有：支持自定义 url 参数 ==========

    async def chat_completions(
        self,
        messages: list,
        model: str = None,
        return_raw: bool = False,
        preprocess_msg: bool = False,
        url: str = None,
        show_progress: bool = False,
        **kwargs,
    ) -> Union[str, "RequestResult"]:
        """单条聊天完成，支持自定义 url"""
        if url is None:
            # 使用基类实现
            return await super().chat_completions(
                messages, model, return_raw, show_progress, preprocess_msg, **kwargs
            )

        # 自定义 url 时的实现
        effective_model = self._get_effective_model(model)
        messages = await self._preprocess_messages(messages, preprocess_msg)

        body = self._build_request_body(messages, effective_model, stream=False, **kwargs)
        results, _ = await self._client.process_requests(
            request_params=[{"json": body, "headers": self._headers}],
            url=url,
            method="POST",
            show_progress=show_progress,
        )

        data = results[0]
        if return_raw:
            return data
        if data.status == "success":
            return self._extract_content(data.data)
        return data

    async def chat_completions_batch(
        self,
        messages_list: List[list],
        model: str = None,
        url: str = None,
        return_raw: bool = False,
        show_progress: bool = True,
        preprocess_msg: bool = False,
        return_summary: bool = False,
        use_cache: bool = True,
        **kwargs,
    ):
        """批量聊天完成，支持自定义 url"""
        if url is None:
            # 使用基类实现
            return await super().chat_completions_batch(
                messages_list, model, return_raw, show_progress, return_summary, preprocess_msg, use_cache, **kwargs
            )

        # 自定义 url 时的实现
        effective_model = self._get_effective_model(model)
        messages_list = await self._preprocess_messages_batch(messages_list, preprocess_msg)

        async def executor(msgs):
            request_params = [
                {"json": self._build_request_body(m, effective_model, **kwargs), "headers": self._headers}
                for m in msgs
            ]
            return await self._client.process_requests(
                request_params=request_params, url=url, method="POST", show_progress=show_progress
            )

        def extractor(result):
            return self._extract_content(result.data)

        if use_cache and self._response_cache:
            responses, progress = await self._response_cache.execute_with_cache(
                messages_list, executor, extractor, model=effective_model, **kwargs
            )
        else:
            results, progress = await executor(messages_list)
            responses = []
            for r in results:
                try:
                    responses.append(extractor(r))
                except Exception as e:
                    logger.warning(f"Error: {e}, set content to None")
                    responses.append(None)

        summary = progress.summary(print_to_console=False) if progress else None
        return (responses, summary) if return_summary else responses

    async def chat_completions_stream(
        self, messages: list, model: str = None, preprocess_msg: bool = False, url: str = None, **kwargs
    ):
        """流式聊天完成，支持自定义 url"""
        if url is None:
            async for chunk in super().chat_completions_stream(messages, model, preprocess_msg, **kwargs):
                yield chunk
            return


        effective_model = self._get_effective_model(model)
        messages = await self._preprocess_messages(messages, preprocess_msg)

        body = self._build_request_body(messages, effective_model, stream=True, **kwargs)
        timeout = aiohttp.ClientTimeout(total=self._timeout)

        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=body, headers=self._headers, timeout=timeout) as response:
                if response.status != 200:
                    raise Exception(f"HTTP {response.status}: {await response.text()}")

                async for line in response.content:
                    line = line.decode("utf-8").strip()
                    if line.startswith("data: "):
                        data_str = line[6:]
                        if data_str == "[DONE]":
                            break
                        try:
                            content = self._extract_stream_content(json.loads(data_str))
                            if content:
                                yield content
                        except json.JSONDecodeError:
                            continue

    # ========== OpenAI 特有方法 ==========

    async def iter_chat_completions_batch(
        self,
        messages_list: List[list],
        model: str,
        url: str = None,
        batch_size: int = None,
        return_raw: bool = False,
        show_progress: bool = True,
        preprocess_msg: bool = False,
        return_summary: bool = False,
        **kwargs,
    ):
        """迭代式批量聊天完成，边请求边返回结果"""
        if preprocess_msg:
            messages_list = await batch_process_messages(
                messages_list, preprocess_msg=preprocess_msg, max_concurrent=self._concurrency_limit
            )

        request_params = [
            {"json": self._build_request_body(m, model, **kwargs), "headers": self._headers}
            for m in messages_list
        ]

        async for batch_result in self._client.aiter_stream_requests(
            request_params=request_params,
            url=url or self._get_url(model),
            method="POST",
            show_progress=show_progress,
            batch_size=batch_size,
        ):
            for result in batch_result.completed_requests:
                content = result.data if return_raw else self._extract_content(result.data) if result.data else None
                summary = batch_result.progress.summary(print_to_console=False) if return_summary else None
                yield (content, summary) if return_summary else content

    def model_list(self) -> List[str]:
        from openai import OpenAI
        client = OpenAI(base_url=self._base_url, api_key=self._api_key)
        return [i.id for i in client.models.list()]
