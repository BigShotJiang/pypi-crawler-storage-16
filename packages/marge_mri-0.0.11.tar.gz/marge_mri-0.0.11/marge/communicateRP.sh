#!/bin/sh

timeout 2s ssh root@$1 $2
