side = ["None", "Left", "Right"]
orientation = ["Feet First Supine (FFS)", "Head First Supine (HFS)", "Feet First Prono (FFP)", "Head First Prono(HFP)"]
screenshot_folder = "experiments/screenshots"
