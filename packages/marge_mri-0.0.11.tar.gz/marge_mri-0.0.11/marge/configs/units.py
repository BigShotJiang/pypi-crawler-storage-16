cm = 1e-2
mm = 1e-3
kHz = 1e3
MHz = 1e6
us = 1e-6
ms = 1e-3
sh = 1e-4
mTm = 1e-3