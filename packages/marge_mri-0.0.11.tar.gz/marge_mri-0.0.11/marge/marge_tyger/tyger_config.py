
docker_img_RARE = 'ghcr.io/teresaguallartnaval/rare_tyger:latest'
recon_code_RARE = 'stream_recon_RARE.py'
cp_batchsize_RARE = 1000