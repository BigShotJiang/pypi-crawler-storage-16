# Copyright 2024 Marimo. All rights reserved.
from __future__ import annotations

from marimo._cli.cli import main

if __name__ == "__main__":
    main(prog_name="marimo")
