# Copyright 2025 Marimo. All rights reserved.
from __future__ import annotations

DEFAULT_MAX_TOKENS = 4096
DEFAULT_MODEL = "openai/gpt-4o"
