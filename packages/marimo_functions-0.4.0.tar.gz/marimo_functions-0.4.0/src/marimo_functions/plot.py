from typing import List
import marimo as mo


class MarimoPlot:
    """
    Every plot has a ui() and a plot() method.
    The ui() method returns the marimo UI elements needed to configure the plot.
    The plot() method renders the plot based on the user input.
    """

    name: str
    description: str
    plot_type: str

    @classmethod
    def ui(cls) -> mo.Html:
        """
        Return the marimo UI elements needed to configure the plot.
        """
        raise NotImplementedError("ui() method not implemented.")
        return {}

    @classmethod
    def ui2(cls, **kwargs) -> mo.Html:
        """
        Return the marimo UI elements needed to configure the plot.
        """
        raise NotImplementedError("ui() method not implemented.")
        return {}

    @classmethod
    def ui3(cls, **kwargs) -> mo.Html:
        """
        Return the marimo UI elements needed to configure the plot.
        """
        raise NotImplementedError("ui() method not implemented.")
        return {}

    @classmethod
    def plot(cls, **kwargs) -> mo.Html:
        """
        Render the plot based on the user input.
        """
        raise NotImplementedError("plot() method not implemented.")
        return mo.Html("<div>No plot implemented.</div>")


class MarimoPlotList:
    plots: List[MarimoPlot]

    def __init__(self, plots: List[MarimoPlot]):
        self.plots = plots

    def prompt(self, label: str, value=None):
        return mo.ui.dropdown(
            label=label,
            options={plot.name: plot for plot in self.plots},
            value=value
        )

    def get_plot(self, name: str) -> MarimoPlot:
        for plot in self.plots:
            if plot.name == name:
                return plot
        raise ValueError(f"Plot '{name}' not found.")

    def plot(self, name: str, **kwargs) -> mo.Html:
        plot_class = self.get_plot(name)
        return plot_class.plot(**kwargs)
