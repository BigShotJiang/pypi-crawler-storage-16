class InvalidStatusException(Exception):
    pass


class InitialisationException(Exception):
    pass
