# wiki page name staring with an octothorpe

2022-08-02: created this page in Emacs. Could not do it in Obsidian, but, hey, maybe there are options to set in Obsidian to let that happen?

- so now the test is to see what happens when
  (1) I look at the vault in Obsidian, and
  (2) I run MWB to build the website
  
- test successful: page created in Emacs, viewed in Obsidian, website constructed and `#` replaced by `_` in MWB output

