# samePageName

2022-09-19: test page to explore what happens with fuzzy-linking and all-pages list if (when?) the wiki has two different notes with the same page name.

This is the first page created with the name: `samePageName`
