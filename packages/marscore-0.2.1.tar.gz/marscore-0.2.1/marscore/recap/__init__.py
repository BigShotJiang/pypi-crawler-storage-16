from .downloader import MultiParquetDownloader as MultiParquetDownloader
# 暴露下载器类
__all__ = ['MultiParquetDownloader']