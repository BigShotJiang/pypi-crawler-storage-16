# MARSGuard Python SDK

A modular Python SDK for generating guardrails via the MARSGuard backend API. This SDK enforces request/response schemas using Pydantic and provides robust error handling with custom exceptions.

## Features

- Enforced request/response schema (Pydantic models)
- Modular, easy-to-use client interface
- Structured error handling with custom exceptions
- Minimal dependencies

## Installation

```bash
pip install marsguard
```

## Usage

```python
from marsguard.types import AppModel, ModelSpec, GenerateGuardrailsRequest
from marsguard.sdk import MarsGuardClient

client = MarsGuardClient()
req = GenerateGuardrailsRequest(
    app=AppModel(name="My Project", description="Project description"),
    domain="insurance",
    model=ModelSpec(name="gpt-4o")
)
try:
    resp = client.generate_guardrails(req)
    print("Guardrails:", resp.guardrails)
except Exception as e:
    print("Error:", e)
```

See `marsguard/example_usage.py` for a complete example.

## Error Handling

The SDK raises structured exceptions for robust error handling:

- `MarsGuardValidationError`: Raised for invalid request or response schema.
- `MarsGuardAPIError`: Raised for API errors (non-2xx HTTP responses). Includes status code and response text.
- `MarsGuardNetworkError`: Raised for network/connection errors.

Example:

```python
from marsguard.exceptions import MarsGuardAPIError, MarsGuardValidationError, MarsGuardNetworkError

try:
    resp = client.generate_guardrails(req)
except MarsGuardValidationError as ve:
    print("Validation error:", ve)
except MarsGuardAPIError as ae:
    print(f"API error {ae.status_code}: {ae.response_text}")
except MarsGuardNetworkError as ne:
    print("Network error:", ne)
```

## Dependencies

- pydantic >=2.0,<3.0
- requests >=2.28,<3.0

