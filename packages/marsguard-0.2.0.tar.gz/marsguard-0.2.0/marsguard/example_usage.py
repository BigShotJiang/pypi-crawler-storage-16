"""
Example usage of the MARSGuard SDK with enforced schema.
This script demonstrates how to call the backend and handle errors, with logging for visibility.
"""

import logging
from marsguard import MarsGuardClient, AppModel, ModelSpec, GenerateGuardrailsRequest

# Configure logging to output to the console
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

if __name__ == "__main__":
    logging.info("Starting MARSGuard SDK example usage script.")

    # Instantiate the MarsGuardClient (uses a fixed backend URL internally)
    logging.info("Instantiating MarsGuardClient...")
    client = MarsGuardClient()

    # Optionally, you can provide a project_spec dictionary with additional project details
    # For this example, we'll leave it empty, but you can add fields as needed
    project_spec = {
        # Example: "custom_field": "value"
    }

    # Construct the request object using the enforced schema
    logging.info("Building GenerateGuardrailsRequest object...")
    req = GenerateGuardrailsRequest(
        app=AppModel(
            name="Example Project",  # Name of your project
            description="Demo project for SDK test"  # Optional description
        ),
        custom="", # Extra Custom Description
        domain="insurance",  # The domain/context for the guardrails
        model=ModelSpec(provider="openai",name="gpt-4o"),  # LLM model to use (provider defaults to "openai")
        project_spec=project_spec  # Optional: additional project specification
    )
    logging.info(f"Request object: {req!r}")

    # Call the backend and handle errors gracefully
    try:
        logging.info("Sending request to backend...")
        resp = client.generate_guardrails(req)
        logging.info("Received response from backend.")
        # Log the guardrails (the main result from the backend)
        logging.info("Guardrails response:")
        logging.info(resp.guardrails)
    except Exception as e:
        # Log any errors that occur (validation, network, or API errors)
        logging.error(f"Error occurred during guardrails generation: {e}")
