"""Typed models for MARSGuard SDK (enforced schema)."""

from __future__ import annotations
from typing import Any, Dict, Optional
from pydantic import BaseModel, Field

class AppModel(BaseModel):
    """
    Application model for guardrails generation.
    """
    name: str
    description: Optional[str] = None

class ModelSpec(BaseModel):
    """
    Model specification for LLM provider and name.
    """
    provider: Optional[str] = "openai"
    name: str

class GenerateGuardrailsRequest(BaseModel):
    """
    Request schema for /guardrails/generate endpoint.
    """
    app: AppModel
    domain: str
    custom: Optional[str] = None
    model: Optional[ModelSpec] = None
    project_spec: Optional[Dict[str, Any]] = None

class MinimalGuardrailsResponse(BaseModel):
    """
    Response schema for /guardrails/generate endpoint.
    """
    guardrails: Dict[str, Any]

__all__ = [
    "AppModel",
    "ModelSpec",
    "GenerateGuardrailsRequest",
    "MinimalGuardrailsResponse",
]
