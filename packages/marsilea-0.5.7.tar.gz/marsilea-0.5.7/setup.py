import setuptools

setuptools.setup(name="marsilea")
