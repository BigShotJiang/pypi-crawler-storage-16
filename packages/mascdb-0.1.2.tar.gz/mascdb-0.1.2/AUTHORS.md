# Project Contributors

The following people have made contributions to this project:

<!--- Use your GitHub account or any other personal reference URL --->

<!--- If you wish to not use your real name, please use your github username --->

<!--- The list should be alphabetical by last name if possible, with github usernames at the bottom  and the istitution --->

<!--- See https://gist.github.com/djhoese/52220272ec73b12eb8f4a29709be110d for auto-generating parts of this list --->

- [Jacopo Grazioli (jacgraz)](https://github.com/jacgraz) - EPFL
- [Gionata Ghiggi (ghiggi)](https://github.com/ghiggi) - EPFL
- [Alexis Berne](https://people.epfl.ch/alexis.berne?lang=en) - EPFL
