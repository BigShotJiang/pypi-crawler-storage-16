# Changelog

## Version 0.0.2 - Glorious Green - XXXX-XX-XX

### Enhancements

- TODO

### Changes

- TODO

### Bugfixes

- TODO

## Version 0.0.1 - MASCDB Birth Date - 2022-12-05

First release of pymascdb Python package.
