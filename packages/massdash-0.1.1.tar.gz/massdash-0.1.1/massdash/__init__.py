"""
massdash
~~~~~~~~
TODO: ADD general documentation about how to use the auto API here

Package Structure
-----------------
testing - a test package
"""

__all__ = [ 'structs', 'preprocess', 'loaders', 'ui', 'server', 'testing' ]
__version__ = "0.1.1"
