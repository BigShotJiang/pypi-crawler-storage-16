"""
massdash/plotting/StaticPlotter
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
"""

# Plotting
from .GenericPlotter import GenericPlotter

class StaticPlotter(GenericPlotter):
    
    def __init__(self):
        pass