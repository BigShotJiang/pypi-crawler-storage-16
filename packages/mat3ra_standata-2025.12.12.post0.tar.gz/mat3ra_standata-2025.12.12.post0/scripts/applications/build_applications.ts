import { ApplicationsProcessor } from "../processors/ApplicationsProcessor";

new ApplicationsProcessor(__dirname).process();
