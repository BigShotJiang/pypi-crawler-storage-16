# matematica_utils/operacoes.py

def somar(a, b):
    """Retorna a soma de dois numeros"""
    return a + b

def subtrair(a, b):
    """Retorna a diferença entre dois numeros"""
    return a - b

def multiplicacao(a, b):
    """Retorna a multiplicacao entre dois numeros"""
    return a * b

def divisao(a, b):
    """Retorna a Divisao entre dois numeros"""
    return a / b
