# setup.py
from setuptools import setup, find_packages

setup(
    name='matematica_utils',
    version='0.1',
    packages=find_packages(),
    author='André Souza',
    keywords='matematica basica',
)

