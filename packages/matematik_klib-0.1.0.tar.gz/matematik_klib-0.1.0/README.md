# Matematik_KLIB

A small math library with polynomial solvers and power/root functions.

## Features

- Solve quadratic and cubic equations
- Compute powers and n-th roots easily

## Installation

```bash
pip install matematik_klib
