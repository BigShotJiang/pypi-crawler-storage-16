from .classification import LogisticRegression, NaiveBayes, KNN

__all__ = [
    "LogisticRegression",
    "NaiveBayes",
    "KNN"
]
