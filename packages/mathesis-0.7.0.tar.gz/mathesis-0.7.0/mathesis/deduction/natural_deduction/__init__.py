from mathesis.deduction.natural_deduction import rules
from mathesis.deduction.natural_deduction.natural_deduction import NDTree

__all__ = ["rules", "NDTree"]
