from mathesis.system.classical import truth_table

__all__ = ["truth_table"]
