from mathesis.system.intuitionistic import sequent_calculus

__all__ = ["sequent_calculus"]
