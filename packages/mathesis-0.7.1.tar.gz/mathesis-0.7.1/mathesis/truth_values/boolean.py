class BooleanTruthValues:
    values = [True, False]
    designated_values = [True]

