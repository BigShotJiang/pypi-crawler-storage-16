from mathesis.deduction.tableau.tableau import *
