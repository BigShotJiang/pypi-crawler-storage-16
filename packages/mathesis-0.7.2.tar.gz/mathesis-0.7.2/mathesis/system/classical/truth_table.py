from mathesis.semantics.truth_table.classical import (
    NegationClause,
    ConjunctionClause,
    DisjunctionClause,
    ConditionalClause,
    ClassicalTruthTable,
)
