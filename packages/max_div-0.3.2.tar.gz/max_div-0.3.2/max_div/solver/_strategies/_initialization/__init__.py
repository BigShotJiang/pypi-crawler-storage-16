from ._base import InitializationStrategy
