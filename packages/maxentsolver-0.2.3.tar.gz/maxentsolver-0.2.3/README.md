# maxentsolver
A Python package for fitting maximum entropy models to BOLD time-series data. The toolkit automatically binarizes fMRI/BOLD signals, constructs pairwise maximum entropy (MaxEnt) models, and provides utilities to analyze the inferred interaction network.
