"""
 advanced_billing

 This file was automatically generated for Maxio by APIMATIC v3.0 (
https://www.apimatic.io ).
"""

from abc import ABC

from apimatic_core_interfaces.client.http_client_provider import (
    HttpClientProvider as CoreHttpClientProvider
)

class HttpClientProvider(CoreHttpClientProvider, ABC):
    """
     Defines a contract for providing HTTP client configuration.

     Classes implementing this interface are expected to supply a configured
     HTTP session and timeout value that will be used by the SDK's internal
     HTTP layer when making network requests.

     This allows developers to inject their own custom HTTP clients while
     maintaining compatibility with the SDK's request/response handling.
    """

    pass
