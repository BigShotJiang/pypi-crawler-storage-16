
"""
advanced_billing

This file was automatically generated for Maxio by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""

import os
from apimatic_core.http.configurations.proxy_settings import ProxySettings as CoreProxySettings

class ProxySettings(CoreProxySettings):
    """
    A simple data model for configuring HTTP(S) proxy settings.
    """

    @classmethod
    def from_environment(cls):
        address = os.getenv('PROXY_ADDRESS', None)
        if not address:
            return None

        port = os.getenv('PROXY_PORT', None)
        if port is not None:
            try:
                port = int(port)
            except (TypeError, ValueError):
                port = None

        return cls(
            address=address,
            port=port,
            username=os.getenv('PROXY_USERNAME', None),
            password=os.getenv('PROXY_PASSWORD', None),
        )
