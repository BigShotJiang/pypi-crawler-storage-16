from mayan.apps.icons.icons import Icon

icon_current_user_oidc_details = Icon(
    driver_name='fontawesome-dual', primary_symbol='user',
    secondary_symbol='key'
)
