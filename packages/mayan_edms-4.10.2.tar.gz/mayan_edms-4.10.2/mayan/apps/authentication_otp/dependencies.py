from mayan.apps.dependencies.classes import PythonDependency

PythonDependency(
    module=__name__, name='pyotp', version_string='==2.9.0'
)
