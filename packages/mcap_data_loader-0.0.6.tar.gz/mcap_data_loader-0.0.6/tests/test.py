from pydantic import ImportString, validate_call, FilePath
from typing import TypeVar, Type

T = TypeVar("T")


@validate_call
def import_string(import_path: ImportString[T]) -> T:
    return import_path

print(import_string("math.sqrt")(16))  # Should print 4.0