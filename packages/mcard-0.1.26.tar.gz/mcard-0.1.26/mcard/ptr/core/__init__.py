"""
PTR Core Module

Core components for the Polynomial Type Runtime system.
"""

from .engine import PTREngine
from .lens_protocol import LensProtocol
from .verifier import CLMVerifier

# Optional NetworkRuntime (requires aiohttp)
try:
    from .network_runtime import NetworkRuntime
    __all__ = ["PTREngine", "CLMVerifier", "LensProtocol", "NetworkRuntime"]
except ImportError:
    __all__ = ["PTREngine", "CLMVerifier", "LensProtocol"]
