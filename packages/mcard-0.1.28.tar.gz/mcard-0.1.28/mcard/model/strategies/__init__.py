# Content type detection strategies
