"""Infrastructure and shared utilities for the Bookshelf Library."""
