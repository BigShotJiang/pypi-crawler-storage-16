"""Beet plugins provided and used by the Bookshelf Library."""
