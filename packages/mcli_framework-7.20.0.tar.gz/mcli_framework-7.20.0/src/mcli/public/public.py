from mcli.lib.logger.logger import get_logger

logger = get_logger(__name__)
