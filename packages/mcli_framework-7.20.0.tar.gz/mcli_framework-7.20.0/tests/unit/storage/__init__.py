"""Unit tests for storage module."""
