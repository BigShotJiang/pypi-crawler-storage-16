"""Windows-specific utilities for MCP."""
