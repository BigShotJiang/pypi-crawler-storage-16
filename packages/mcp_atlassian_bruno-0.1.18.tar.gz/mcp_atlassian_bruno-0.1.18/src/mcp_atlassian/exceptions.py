class MCPAtlassianAuthenticationError(Exception):
    """Raised when Atlassian API authentication fails (401/403)."""

    pass


class FortiGateAuthenticationRequiredError(Exception):
    """Raised when FortiGate SSL inspection requires authentication.

    This exception is raised when the MCP receives an HTML response from
    FortiGate instead of JSON from the Jira API. This indicates that a
    Fortinet FortiGate SSL inspection appliance is intercepting HTTPS
    connections and redirecting to an authentication portal.

    Attributes:
        auth_url: The FortiGate authentication URL to open in a browser
        message: Human-readable error message with instructions
    """

    def __init__(self, auth_url: str | None = None, message: str | None = None) -> None:
        self.auth_url = auth_url
        if message:
            self.message = message
        elif auth_url:
            self.message = (
                "Fortinet FortiGate SSL inspection is blocking access to Jira. "
                "This is a network-level security appliance intercepting HTTPS connections. "
                "Please contact your network administrator to allow MCP server access. "
                "Authentication in your browser alone will NOT resolve this issue for the server."
            )
        else:
            self.message = (
                "FortiGate SSL inspection detected. "
                "Please contact your network administrator to configure access for the MCP server."
            )
        super().__init__(self.message)

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "error": "fortinet_auth_required",
            "auth_required": True,
            "auth_url": self.auth_url,
            "message": self.message,
            "details": (
                "Fortinet FortiGate is performing Deep Packet Inspection (DPI) on HTTPS traffic. "
                "Each connection from the server is treated separately and requires network-level authorization."
            ),
            "quick_fix": (
                "1. Call the 'fortinet_authenticate' tool with your auth_url"
                if self.auth_url
                else "Please contact your network administrator"
            ),
            "recommended_actions": [
                "IMMEDIATE ACTION:",
                "1. Call the 'fortinet_authenticate' Jira tool with the auth_url parameter below",
                "   Example: fortinet_authenticate(auth_url='...')",
                "2. This will open the authentication portal in your browser automatically",
                "3. Complete the FortiGate authentication",
                "4. Retry your original Jira operation",
                "",
                "If automatic authentication fails:",
                "- Manually open this URL in your browser:",
                f"  {self.auth_url}" if self.auth_url else "  (URL not available)",
                "- Complete authentication",
                "- Then retry your Jira operation",
                "",
                "For PERMANENT access (recommended):",
                "- Contact your network administrator with these requests:",
                "  * Whitelist the MCP server IP for direct Jira access (bypass FortiGate DPI)",
                "  * OR configure a client certificate for the server",
                "  * OR set up a proxy server with FortiGate credentials",
            ],
            "user_action": (
                f"Call: fortinet_authenticate(auth_url='{self.auth_url}')"
                if self.auth_url
                else "Contact your network administrator"
            ),
        }
