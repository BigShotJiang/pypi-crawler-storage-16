class MCPAtlassianAuthenticationError(Exception):
    """Raised when Atlassian API authentication fails (401/403)."""

    pass


class FortiGateAuthenticationRequiredError(Exception):
    """Raised when FortiGate SSL inspection requires authentication.

    This exception is raised when the MCP receives an HTML response from
    FortiGate instead of JSON from the Jira API. This indicates that a
    Fortinet FortiGate SSL inspection appliance is intercepting HTTPS
    connections and redirecting to an authentication portal.

    Attributes:
        auth_url: The FortiGate authentication URL to open in a browser
        message: Human-readable error message with instructions
    """

    def __init__(self, auth_url: str | None = None, message: str | None = None) -> None:
        self.auth_url = auth_url
        if message:
            self.message = message
        elif auth_url:
            self.message = (
                "Fortinet FortiGate SSL inspection is blocking access to Jira. "
                "This is a network-level security appliance intercepting HTTPS connections. "
                "Please contact your network administrator to allow MCP server access. "
                "Authentication in your browser alone will NOT resolve this issue for the server."
            )
        else:
            self.message = (
                "FortiGate SSL inspection detected. "
                "Please contact your network administrator to configure access for the MCP server."
            )
        super().__init__(self.message)

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "error": "fortinet_auth_required",
            "auth_required": True,
            "auth_url": self.auth_url,
            "message": self.message,
            "details": (
                "Fortinet FortiGate is performing Deep Packet Inspection (DPI) on HTTPS traffic. "
                "The cookie is automatically extracted from the authentication URL when detected."
            ),
            "quick_fix": (
                "The system attempts automatic extraction. If that fails, call 'set_fortinet_cookie' with the token"
                if self.auth_url
                else "Please contact your network administrator"
            ),
            "recommended_actions": [
                "AUTOMATIC EXTRACTION (Recommended):",
                "1. The system automatically extracts the token from the FortiGate URL",
                "2. If automatic extraction succeeds, retry your operation",
                "",
                "MANUAL EXTRACTION (If automatic fails):",
                "1. Get the authentication URL (shown above or contact your admin)",
                "2. Open the URL in your browser",
                "3. You will be redirected back with the FGTAUTH cookie set",
                "4. Extract the cookie from browser DevTools (F12 → Application → Cookies)",
                "5. Call: set_fortinet_cookie(cookie_value='<extracted_token>')",
                "6. Retry your original Jira operation",
                "",
                "PERMANENT ACCESS (recommended):",
                "- Contact your network administrator with these requests:",
                "  * Whitelist the MCP server IP for direct Jira access (bypass FortiGate DPI)",
                "  * OR configure a client certificate for the server",
                "  * OR set up a proxy server with FortiGate credentials",
            ],
            "user_action": (
                "System is attempting automatic extraction...\n"
                "If manual action needed, call: set_fortinet_cookie(cookie_value='<token_from_url>')"
                if self.auth_url
                else "Contact your network administrator"
            ),
        }
