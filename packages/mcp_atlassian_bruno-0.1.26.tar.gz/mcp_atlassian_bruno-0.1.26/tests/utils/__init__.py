"""Test utilities for MCP Atlassian test suite."""
