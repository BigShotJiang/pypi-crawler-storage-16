class MCPAtlassianAuthenticationError(Exception):
    """Raised when Atlassian API authentication fails (401/403)."""

    pass


class FortiGateAuthenticationRequiredError(Exception):
    """Raised when FortiGate SSL inspection requires authentication.

    This exception is raised when the MCP receives an HTML response from
    FortiGate instead of JSON from the Jira API. The user must authenticate
    with FortiGate first before the MCP can access Jira.

    Attributes:
        auth_url: The FortiGate authentication URL to open in a browser
        message: Human-readable error message with instructions
    """

    def __init__(self, auth_url: str | None = None, message: str | None = None) -> None:
        self.auth_url = auth_url
        if message:
            self.message = message
        elif auth_url:
            self.message = (
                f"FortiGate authentication required. "
                f"Please open this URL in your browser to authenticate, "
                f"then retry the operation: {auth_url}"
            )
        else:
            self.message = (
                "FortiGate authentication required. "
                "Please authenticate with your network administrator."
            )
        super().__init__(self.message)

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "error": "fortinet_auth_required",
            "auth_required": True,
            "auth_url": self.auth_url,
            "message": self.message,
            "user_action": (
                f"Open this URL to authenticate: {self.auth_url}"
                if self.auth_url
                else "Contact your network administrator"
            ),
        }
