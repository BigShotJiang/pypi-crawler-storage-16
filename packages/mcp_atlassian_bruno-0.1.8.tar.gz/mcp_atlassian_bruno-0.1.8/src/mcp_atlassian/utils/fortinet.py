"""Utility to detect and handle Fortinet FortiGate SSL inspection issues."""

import logging
import re
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from requests import Response, Session

logger = logging.getLogger("mcp-jira.fortinet")


def extract_fgtauth_url(response_text: str) -> str | None:
    """
    Extract the FortiGate authentication URL from HTML response.

    Looks for patterns like:
    - window.location="https://192.168.11.118/fgtauth?070e0b8d9bf6c39d"
    - <meta http-equiv="refresh" content="0;url=https://...">

    Args:
        response_text: The HTML response body

    Returns:
        The authentication URL if found, None otherwise
    """
    # Pattern 1: window.location="URL"
    match = re.search(
        r'window\.location\s*=\s*["\']([^"\']*fgtauth[^"\']*)["\']',
        response_text,
        re.IGNORECASE,
    )
    if match:
        return match.group(1)

    # Pattern 2: meta refresh redirect
    match = re.search(
        r'<meta[^>]*url=([^"\'>\s]*fgtauth[^"\'>\s]*)',
        response_text,
        re.IGNORECASE,
    )
    if match:
        return match.group(1)

    # Pattern 3: href with fgtauth
    match = re.search(
        r'href\s*=\s*["\']([^"\']*fgtauth[^"\']*)["\']',
        response_text,
        re.IGNORECASE,
    )
    if match:
        return match.group(1)

    return None


def is_fortinet_response(response_text: str) -> bool:
    """
    Detect if response is from Fortinet FortiGate SSL inspection.

    Args:
        response_text: The response body text

    Returns:
        True if response appears to be from Fortinet FortiGate
    """
    fortinet_indicators = [
        "fgtauth",
        "fortigate",
        "fortinet",
        "forticlient",
        "login.cgi",
        "check_fgtauth",
        "window.location",  # Redirection script
    ]

    text_lower = response_text.lower()

    # Check for any fortinet indicator
    has_indicator = any(indicator in text_lower for indicator in fortinet_indicators)

    # Check for specific fgtauth redirect pattern
    has_fgtauth_redirect = "fgtauth?" in text_lower or "/fgtauth" in text_lower

    return has_indicator or has_fgtauth_redirect
def is_html_response(content_type: str | None, response_text: str | None) -> bool:
    """
    Detect if response is HTML (likely error/redirect).

    Args:
        content_type: Content-Type header value
        response_text: Response body text

    Returns:
        True if response appears to be HTML
    """
    if content_type and "text/html" in content_type.lower():
        return True

    if response_text and response_text.strip().startswith("<"):
        return True

    return False


def detect_and_report_fortinet_issue(
    response_text: str, content_type: str | None = None, url: str | None = None
) -> dict[str, Any] | None:
    """
    Detect Fortinet FortiGate SSL inspection issue and provide diagnostic info.

    Args:
        response_text: The response body text
        content_type: Content-Type header value
        url: The requested URL

    Returns:
        Dictionary with diagnostic information if issue detected, None otherwise
    """
    if is_fortinet_response(response_text):
        # Extract the authentication URL
        auth_url = extract_fgtauth_url(response_text)

        logger.error(
            "Fortinet FortiGate SSL Inspection detected! "
            "HTTPS requests are being intercepted and redirected to /fgtauth. "
            f"Authentication URL: {auth_url or 'Not found'}"
        )

        return {
            "issue": "fortinet_ssl_inspection",
            "auth_required": True,
            "auth_url": auth_url,
            "description": (
                "Fortinet FortiGate is intercepting HTTPS requests. "
                "Please authenticate first, then retry."
            ),
            "user_action": (
                f"Open this URL in your browser to authenticate: {auth_url}"
                if auth_url
                else "FortiGate authentication required. Contact admin."
            ),
            "indicators": {
                "is_fortinet": True,
                "is_html": is_html_response(content_type, response_text),
                "url": url,
                "content_type": content_type,
                "response_preview": response_text[:200],
            },
            "recommended_actions": [
                f"1. Authenticate: {auth_url}" if auth_url else "1. Authenticate",
                "2. After authentication, retry the operation",
                "3. If issue persists, request Jira SSL inspection exclusion",
                "4. Alternative: Install Fortinet CA certificate",
            ],
        }

    if is_html_response(content_type, response_text):
        logger.warning(
            f"Received HTML response from {url} instead of JSON. "
            "This might indicate a redirect or authentication issue."
        )

        return {
            "issue": "unexpected_html_response",
            "description": "Received HTML instead of JSON API response",
            "indicators": {
                "is_html": True,
                "is_fortinet": False,
                "url": url,
                "content_type": content_type,
                "response_preview": response_text[:200],
            },
            "recommended_actions": [
                "1. Verify Jira API URL is correct",
                "2. Check authentication credentials",
                "3. Verify SSL certificate (if using HTTPS)",
                "4. Check if Jira is behind a proxy/firewall",
                "5. Check for Fortinet FortiGate SSL inspection",
            ],
        }

    return None


def create_fortinet_response_hook() -> Callable[["Response"], "Response"]:
    """
    Create a requests response hook that detects FortiGate SSL inspection.

    This hook checks each HTTP response for FortiGate HTML redirects
    and raises FortiGateAuthenticationRequiredError if detected.

    Returns:
        A function that can be used as a requests response hook

    Usage:
        session = requests.Session()
        session.hooks['response'].append(create_fortinet_response_hook())
    """
    from requests import Response

    from mcp_atlassian.exceptions import FortiGateAuthenticationRequiredError

    def fortinet_check_hook(
        response: Response, *args: object, **kwargs: object
    ) -> Response:
        """Check response for FortiGate authentication redirect."""
        # Only check responses that might be HTML (non-JSON)
        content_type = response.headers.get("Content-Type", "")

        # Skip if response is JSON
        if "application/json" in content_type.lower():
            return response

        # Check for HTML responses
        try:
            text = response.text
        except (AttributeError, UnicodeDecodeError):
            return response

        # Check for FortiGate redirect
        if is_fortinet_response(text):
            auth_url = extract_fgtauth_url(text)
            logger.error(
                f"FortiGate authentication required! "
                f"Auth URL: {auth_url or 'Not found in response'}"
            )
            raise FortiGateAuthenticationRequiredError(auth_url=auth_url)

        return response

    return fortinet_check_hook


def install_fortinet_hook(session: "Session") -> None:
    """
    Install the FortiGate detection hook on a requests Session.

    Args:
        session: A requests.Session instance
    """
    hook = create_fortinet_response_hook()
    if "response" not in session.hooks:
        session.hooks["response"] = []
    session.hooks["response"].append(hook)
    logger.debug("FortiGate detection hook installed on session")
