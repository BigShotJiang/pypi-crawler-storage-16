#!/usr/bin/env python3
"""
BaseTracker - Abstract base class for platform-specific MCP trackers

Provides a stable adapter interface for Claude Code, Codex CLI, Gemini CLI, and future platforms.
"""

import hashlib
import json
import warnings
from abc import ABC, abstractmethod
from collections import defaultdict
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple

if TYPE_CHECKING:
    from .display import DisplayAdapter

from . import __version__

# Schema version (see docs/data-contract.md for compatibility guarantees)
SCHEMA_VERSION = "1.5.0"


def _now_with_timezone() -> datetime:
    """Get current datetime with local timezone offset."""
    return datetime.now(timezone.utc).astimezone()


def _format_timestamp(dt: datetime) -> str:
    """Format datetime as ISO 8601 with timezone offset (e.g., 2025-12-01T14:19:38+11:00)."""
    if dt.tzinfo is None:
        # Add local timezone if naive
        dt = dt.replace(tzinfo=datetime.now(timezone.utc).astimezone().tzinfo)
    return dt.isoformat(timespec="seconds")


# ============================================================================
# Core Data Structures (Schema v1.1.0)
# ============================================================================


@dataclass
class FileHeader:
    """Self-describing file header for AI-Agent readability (v1.1.0)"""

    name: str  # File name (e.g., "mcp-audit-2025-12-01T14-19-38.json")
    type: str = "mcp_audit_session"  # File type identifier
    purpose: str = (
        "Complete MCP session log with token usage and tool call statistics for AI agent analysis"
    )
    schema_version: str = SCHEMA_VERSION
    schema_docs: str = "https://github.com/littlebearapps/mcp-audit/blob/main/docs/data-contract.md"
    generated_by: str = ""  # e.g., "mcp-audit v0.4.0"
    generated_at: str = ""  # ISO 8601 with timezone

    def to_dict(self) -> Dict[str, Any]:
        """Convert to JSON-serializable dict"""
        return asdict(self)


@dataclass
class Call:
    """Single MCP tool call record"""

    timestamp: datetime = field(default_factory=_now_with_timezone)
    tool_name: str = ""
    server: str = ""  # Server name extracted from tool_name (v1.1.0)
    index: int = 0  # Sequential call number within session (v1.1.0)
    input_tokens: int = 0
    output_tokens: int = 0
    cache_created_tokens: int = 0
    cache_read_tokens: int = 0
    total_tokens: int = 0
    duration_ms: int = 0  # 0 if not available
    content_hash: Optional[str] = None
    platform_data: Optional[Dict[str, Any]] = None
    # Token estimation metadata (v1.4.0)
    is_estimated: bool = False  # True for Codex/Gemini MCP tools
    estimation_method: Optional[str] = None  # "tiktoken", "sentencepiece", or "character"
    estimation_encoding: Optional[str] = None  # e.g., "o200k_base", "sentencepiece:gemma"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to JSON-serializable dict for v1.4.0 format"""
        result: Dict[str, Any] = {
            "index": self.index,
            "timestamp": _format_timestamp(self.timestamp),
            "tool": self.tool_name,
            "server": self.server,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "cache_created_tokens": self.cache_created_tokens,
            "cache_read_tokens": self.cache_read_tokens,
            "total_tokens": self.total_tokens,
            "duration_ms": self.duration_ms if self.duration_ms > 0 else None,
            "content_hash": self.content_hash,
        }
        # v1.4.0: Add estimation fields only when tokens are estimated
        # Omit when False to minimize file size for Claude Code sessions
        if self.is_estimated:
            result["is_estimated"] = True
            result["estimation_method"] = self.estimation_method
            result["estimation_encoding"] = self.estimation_encoding
        return result

    def to_dict_v1_0(self) -> Dict[str, Any]:
        """Convert to JSON-serializable dict for v1.0.0 backward compatibility"""
        data = asdict(self)
        data["timestamp"] = self.timestamp.isoformat()
        data["schema_version"] = "1.0.0"  # For v1.0.0 format
        return data


@dataclass
class ToolStats:
    """Statistics for a single MCP tool"""

    calls: int = 0
    total_tokens: int = 0
    avg_tokens: float = 0.0
    call_history: List[Call] = field(default_factory=list)
    total_duration_ms: Optional[int] = None
    avg_duration_ms: Optional[float] = None
    max_duration_ms: Optional[int] = None
    min_duration_ms: Optional[int] = None
    # Per-tool cache tracking (task-47.4)
    cache_created_tokens: int = 0
    cache_read_tokens: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to JSON-serializable dict (v1.1.0 - no schema_version)"""
        return {
            "calls": self.calls,
            "total_tokens": self.total_tokens,
            "avg_tokens": self.avg_tokens,
            "cache_created_tokens": self.cache_created_tokens,
            "cache_read_tokens": self.cache_read_tokens,
            "total_duration_ms": self.total_duration_ms,
            "avg_duration_ms": self.avg_duration_ms,
            "max_duration_ms": self.max_duration_ms,
            "min_duration_ms": self.min_duration_ms,
            "call_history": [call.to_dict() for call in self.call_history],
        }

    def to_dict_v1_0(self) -> Dict[str, Any]:
        """Convert to JSON-serializable dict for v1.0.0 backward compatibility"""
        data = asdict(self)
        data["schema_version"] = "1.0.0"
        data["call_history"] = [call.to_dict_v1_0() for call in self.call_history]
        return data


@dataclass
class ServerSession:
    """Statistics for a single MCP server"""

    server: str = ""
    tools: Dict[str, ToolStats] = field(default_factory=dict)
    total_calls: int = 0
    total_tokens: int = 0
    metadata: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to JSON-serializable dict (v1.1.0 - no schema_version)"""
        return {
            "server": self.server,
            "tools": {name: stats.to_dict() for name, stats in self.tools.items()},
            "total_calls": self.total_calls,
            "total_tokens": self.total_tokens,
            "metadata": self.metadata,
        }

    def to_dict_v1_0(self) -> Dict[str, Any]:
        """Convert to JSON-serializable dict for v1.0.0 backward compatibility"""
        data = asdict(self)
        data["schema_version"] = "1.0.0"
        data["tools"] = {name: stats.to_dict_v1_0() for name, stats in self.tools.items()}
        return data


@dataclass
class TokenUsage:
    """Token usage statistics

    Attributes:
        input_tokens: Tokens from user input/context
        output_tokens: Tokens from model output (excludes reasoning)
        cache_created_tokens: Tokens added to cache
        cache_read_tokens: Tokens read from cache
        reasoning_tokens: Thinking/reasoning tokens (Gemini CLI: thoughts,
            Codex CLI: reasoning_output_tokens, Claude Code: 0)
        total_tokens: Sum of all token types
        cache_efficiency: Ratio of cache_read to total input (0.0-1.0)
    """

    input_tokens: int = 0
    output_tokens: int = 0
    cache_created_tokens: int = 0
    cache_read_tokens: int = 0
    reasoning_tokens: int = 0  # v1.3.0: Gemini thoughts / Codex reasoning
    total_tokens: int = 0
    cache_efficiency: float = 0.0


@dataclass
class MCPToolCalls:
    """MCP tool call summary"""

    total_calls: int = 0
    unique_tools: int = 0
    most_called: str = ""


@dataclass
class MCPSummary:
    """Pre-computed MCP summary for quick AI access (v1.1.0)"""

    total_calls: int = 0
    unique_tools: int = 0
    unique_servers: int = 0
    servers_used: List[str] = field(default_factory=list)
    top_by_tokens: List[Dict[str, Any]] = field(default_factory=list)
    top_by_calls: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to JSON-serializable dict"""
        return asdict(self)


@dataclass
class BuiltinToolSummary:
    """Summary of built-in tool usage for session logs (v1.2.0)

    Tracks aggregate and per-tool statistics for built-in tools
    (Bash, Read, Write, Edit, Glob, Grep, etc.)
    """

    total_calls: int = 0
    total_tokens: int = 0
    tools: List[Dict[str, Any]] = field(default_factory=list)  # Per-tool breakdown

    def to_dict(self) -> Dict[str, Any]:
        """Convert to JSON-serializable dict"""
        return {
            "total_calls": self.total_calls,
            "total_tokens": self.total_tokens,
            "tools": self.tools,
        }


@dataclass
class CacheAnalysis:
    """AI-optimized cache analysis for session logs (task-47.3)

    Provides a clear breakdown of cache efficiency for AI agents to understand:
    - What happened (status + summary)
    - Why (top creators/readers)
    - What to do (recommendation)
    """

    status: str = "neutral"  # "efficient", "inefficient", "neutral"
    summary: str = ""  # Human/AI readable summary
    creation_tokens: int = 0
    read_tokens: int = 0
    ratio: float = 0.0  # read/creation ratio (higher = better)
    net_savings_usd: float = 0.0  # Positive = savings, negative = net cost
    top_cache_creators: List[Dict[str, Any]] = field(default_factory=list)
    top_cache_readers: List[Dict[str, Any]] = field(default_factory=list)
    recommendation: str = ""

    def to_dict(self) -> Dict[str, Any]:
        """Convert to JSON-serializable dict"""
        return asdict(self)


# ============================================================================
# Schema v1.5.0 Data Structures (Insight Layer)
# ============================================================================


@dataclass
class Smell:
    """Efficiency anti-pattern detected in a session (v1.5.0)

    Represents a single "code smell" for MCP tool usage patterns that
    may indicate inefficiency or suboptimal behavior.

    Attributes:
        pattern: Pattern identifier (e.g., "HIGH_VARIANCE", "CHATTY")
        severity: "info", "warning", or "error"
        tool: Tool name triggering the smell (optional, some are session-level)
        description: Human-readable explanation
        evidence: Pattern-specific supporting data
    """

    pattern: str  # HIGH_VARIANCE, TOP_CONSUMER, HIGH_MCP_SHARE, CHATTY, LOW_CACHE_HIT
    severity: str = "info"  # "info", "warning", "error"
    tool: Optional[str] = None  # Tool that triggered the smell (if applicable)
    description: str = ""
    evidence: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to JSON-serializable dict"""
        result = {
            "pattern": self.pattern,
            "severity": self.severity,
            "description": self.description,
            "evidence": self.evidence,
        }
        if self.tool:
            result["tool"] = self.tool
        return result


@dataclass
class DataQuality:
    """Data quality and accuracy indicators for a session (v1.5.0)

    Provides clear labeling of how accurate the token metrics are,
    helping users understand the reliability of the data.

    Attributes:
        accuracy_level: "exact", "estimated", or "calls-only"
        token_source: Tokenizer/source used (e.g., "native", "tiktoken", "sentencepiece")
        token_encoding: Specific encoding (e.g., "o200k_base", "gemma")
        confidence: Estimated accuracy as float (0.0-1.0)
        notes: Additional context about data quality
    """

    accuracy_level: str = "exact"  # "exact", "estimated", "calls-only"
    token_source: str = "native"  # "native", "tiktoken", "sentencepiece", "character"
    token_encoding: Optional[str] = None  # e.g., "o200k_base", "gemma"
    confidence: float = 1.0  # 0.0-1.0
    notes: str = ""

    def to_dict(self) -> Dict[str, Any]:
        """Convert to JSON-serializable dict"""
        result = {
            "accuracy_level": self.accuracy_level,
            "token_source": self.token_source,
            "confidence": self.confidence,
        }
        if self.token_encoding:
            result["token_encoding"] = self.token_encoding
        if self.notes:
            result["notes"] = self.notes
        return result


@dataclass
class Session:
    """Complete session data"""

    schema_version: str = SCHEMA_VERSION
    mcp_audit_version: str = ""  # Version of mcp-audit that tracked this session
    project: str = ""
    platform: str = ""  # "claude-code", "codex-cli", "gemini-cli"
    model: str = ""  # Model used (e.g., "claude-opus-4-5-20251101") (v1.1.0)
    working_directory: str = ""  # Directory where mcp-audit was run (v1.1.0)
    timestamp: datetime = field(default_factory=_now_with_timezone)
    session_id: str = ""
    token_usage: TokenUsage = field(default_factory=TokenUsage)
    cost_estimate: float = 0.0
    cost_no_cache: float = 0.0  # Cost without caching (task-47.3)
    cache_savings_usd: float = 0.0  # Net savings from caching (task-47.3)
    mcp_tool_calls: MCPToolCalls = field(default_factory=MCPToolCalls)
    server_sessions: Dict[str, ServerSession] = field(default_factory=dict)
    redundancy_analysis: Optional[Dict[str, Any]] = None
    anomalies: List[Dict[str, Any]] = field(default_factory=list)
    end_timestamp: Optional[datetime] = None
    duration_seconds: Optional[float] = None
    source_files: List[str] = field(default_factory=list)  # Files monitored (v1.1.0)
    message_count: int = 0  # Number of assistant messages (task-49.1)
    # Built-in tool tracking (v1.2.0)
    builtin_tool_stats: Dict[str, Dict[str, int]] = field(
        default_factory=dict
    )  # tool -> {calls, tokens}
    # v1.5.0: Insight Layer
    smells: List["Smell"] = field(default_factory=list)  # Efficiency anti-patterns
    data_quality: Optional["DataQuality"] = None  # Accuracy indicators
    zombie_tools: Dict[str, List[str]] = field(default_factory=dict)  # server -> unused tools
    _call_index: int = field(default=0, repr=False)  # Internal counter for call indices

    def to_dict(self) -> Dict[str, Any]:
        """Convert to v1.5.0 JSON-serializable dict with Insight Layer blocks"""
        # Build flat tool_calls array from all server sessions
        tool_calls = []
        for server_session in self.server_sessions.values():
            for tool_stats in server_session.tools.values():
                for call in tool_stats.call_history:
                    tool_calls.append(call.to_dict())

        # Sort by index (sequential order)
        tool_calls.sort(key=lambda x: x.get("index", 0))

        # Build MCP summary
        mcp_summary = self._build_mcp_summary()

        # Build cache analysis (task-47.3)
        cache_analysis = self._build_cache_analysis(self.cache_savings_usd)

        # Build builtin tool summary (v1.2.0 - task-78)
        builtin_tool_summary = self._build_builtin_tool_summary()

        # v1.5.0: Build data quality block
        data_quality_dict = self.data_quality.to_dict() if self.data_quality else None

        result = {
            "_file": None,  # To be set by save_session()
            "session": {
                "id": self.session_id,
                "project": self.project,
                "platform": self.platform,
                "model": self.model,
                "working_directory": self.working_directory,
                "started_at": _format_timestamp(self.timestamp),
                "ended_at": _format_timestamp(self.end_timestamp) if self.end_timestamp else None,
                "duration_seconds": self.duration_seconds,
                "source_files": self.source_files,
                "message_count": self.message_count,
            },
            "token_usage": asdict(self.token_usage),
            "cost_estimate_usd": self.cost_estimate,
            "cost_no_cache_usd": self.cost_no_cache,
            "cache_savings_usd": self.cache_savings_usd,
            "mcp_summary": mcp_summary.to_dict(),
            "builtin_tool_summary": builtin_tool_summary.to_dict(),
            "cache_analysis": cache_analysis.to_dict(),
            "tool_calls": tool_calls,
            # v1.5.0: Insight Layer blocks
            "smells": [smell.to_dict() for smell in self.smells],
            "zombie_tools": self.zombie_tools if self.zombie_tools else {},
            "analysis": {
                "redundancy": self.redundancy_analysis,
                "anomalies": self.anomalies,
            },
        }

        # v1.5.0: Add data_quality only if set (platform-dependent)
        if data_quality_dict:
            result["data_quality"] = data_quality_dict

        return result

    def to_dict_v1_0(self) -> Dict[str, Any]:
        """Convert to v1.0.0 JSON-serializable dict for backward compatibility"""
        data = {
            "schema_version": "1.0.0",
            "mcp_audit_version": self.mcp_audit_version,
            "project": self.project,
            "platform": self.platform,
            "timestamp": self.timestamp.isoformat(),
            "session_id": self.session_id,
            "token_usage": asdict(self.token_usage),
            "cost_estimate": self.cost_estimate,
            "mcp_tool_calls": asdict(self.mcp_tool_calls),
            "server_sessions": {
                name: sess.to_dict_v1_0() for name, sess in self.server_sessions.items()
            },
            "redundancy_analysis": self.redundancy_analysis,
            "anomalies": self.anomalies,
        }
        if self.end_timestamp:
            data["end_timestamp"] = self.end_timestamp.isoformat()
        if self.duration_seconds is not None:
            data["duration_seconds"] = self.duration_seconds
        return data

    def _build_mcp_summary(self) -> MCPSummary:
        """Build pre-computed MCP summary.

        Note: Excludes "builtin" pseudo-server (task-95.2). Built-in tools
        (shell_command, update_plan, etc.) are tracked separately in
        builtin_tool_summary.
        """
        all_tools: List[Tuple[str, str, int, int]] = []  # (tool, server, tokens, calls)

        # Filter out "builtin" pseudo-server - these are NOT MCP tools (task-95.2)
        mcp_servers = {
            name: session for name, session in self.server_sessions.items() if name != "builtin"
        }

        for server_name, server_session in mcp_servers.items():
            for tool_name, tool_stats in server_session.tools.items():
                all_tools.append(
                    (tool_name, server_name, tool_stats.total_tokens, tool_stats.calls)
                )

        # Sort by tokens for top_by_tokens
        by_tokens = sorted(all_tools, key=lambda x: x[2], reverse=True)[:5]
        top_by_tokens = [
            {"tool": t[0], "server": t[1], "tokens": t[2], "calls": t[3]} for t in by_tokens
        ]

        # Sort by calls for top_by_calls
        by_calls = sorted(all_tools, key=lambda x: x[3], reverse=True)[:5]
        top_by_calls = [
            {"tool": t[0], "server": t[1], "calls": t[3], "tokens": t[2]} for t in by_calls
        ]

        return MCPSummary(
            total_calls=sum(ss.total_calls for ss in mcp_servers.values()),
            unique_tools=len({t[0] for t in all_tools}),
            unique_servers=len(mcp_servers),
            servers_used=list(mcp_servers.keys()),
            top_by_tokens=top_by_tokens,
            top_by_calls=top_by_calls,
        )

    def _build_cache_analysis(self, net_savings_usd: float = 0.0) -> CacheAnalysis:
        """Build AI-optimized cache analysis (task-47.3).

        Args:
            net_savings_usd: Net savings in USD (positive = savings, negative = cost).
                            Should be calculated by the caller using pricing config.
        """
        creation_tokens = self.token_usage.cache_created_tokens
        read_tokens = self.token_usage.cache_read_tokens

        # Calculate read/creation ratio (higher = better cache efficiency)
        ratio = read_tokens / creation_tokens if creation_tokens > 0 else 0.0

        # Collect per-tool cache stats
        tool_cache_stats: List[Tuple[str, int, int]] = []  # (tool, created, read)
        for server_session in self.server_sessions.values():
            for tool_name, tool_stats in server_session.tools.items():
                if tool_stats.cache_created_tokens > 0 or tool_stats.cache_read_tokens > 0:
                    tool_cache_stats.append(
                        (tool_name, tool_stats.cache_created_tokens, tool_stats.cache_read_tokens)
                    )

        # Top cache creators (by cache_created_tokens)
        by_creation = sorted(tool_cache_stats, key=lambda x: x[1], reverse=True)[:5]
        top_cache_creators = []
        for tool, created, _read in by_creation:
            if created > 0:
                pct = (created / creation_tokens * 100) if creation_tokens > 0 else 0
                top_cache_creators.append({"tool": tool, "tokens": created, "pct": round(pct, 1)})

        # Top cache readers (by cache_read_tokens)
        by_read = sorted(tool_cache_stats, key=lambda x: x[2], reverse=True)[:5]
        top_cache_readers = []
        for tool, _created, read in by_read:
            if read > 0:
                pct = (read / read_tokens * 100) if read_tokens > 0 else 0
                top_cache_readers.append({"tool": tool, "tokens": read, "pct": round(pct, 1)})

        # Determine status and generate summary/recommendation
        if creation_tokens == 0 and read_tokens == 0:
            status = "neutral"
            summary = "No cache activity in this session."
            recommendation = ""
        elif creation_tokens == 0 and read_tokens > 0:
            # Read-only cache (Codex CLI, Gemini CLI) - always efficient
            # You're reading from existing cache without paying creation cost
            status = "efficient"
            summary = (
                f"Read-only cache: {read_tokens:,} tokens read from cache. "
                f"No cache creation cost incurred."
            )
            recommendation = "Cache is working efficiently with read-only access."
        elif net_savings_usd > 0:
            status = "efficient"
            summary = (
                f"Cache saved ${net_savings_usd:.4f}. "
                f"Created {creation_tokens:,} tokens, read {read_tokens:,} tokens "
                f"(ratio: {ratio:.2f})."
            )
            recommendation = "Cache is working efficiently. Continue current usage patterns."
        elif ratio >= 1.0 and read_tokens > 0:
            # High ratio but no cost data - assume efficient
            status = "efficient"
            summary = (
                f"Good cache reuse: created {creation_tokens:,}, read {read_tokens:,} "
                f"(ratio: {ratio:.2f})."
            )
            recommendation = "Cache is working efficiently. Continue current usage patterns."
        else:
            status = "inefficient"
            abs_cost = abs(net_savings_usd)
            if read_tokens == 0:
                summary = (
                    f"High cache creation ({creation_tokens:,} tokens) with no reuse. "
                    f"Net cost: ${abs_cost:.4f}."
                )
                recommendation = (
                    "Consider batching related queries to reuse cached context. "
                    "New context every call prevents cache benefits."
                )
            elif ratio < 0.1:
                summary = (
                    f"High cache creation ({creation_tokens:,}) with low reuse ({read_tokens:,}). "
                    f"Net cost: ${abs_cost:.4f}."
                )
                recommendation = (
                    "Cache creation exceeds reuse benefit. "
                    "Try grouping related operations to maximize cache hits."
                )
            else:
                summary = (
                    f"Cache creation cost exceeds read savings. "
                    f"Created {creation_tokens:,}, read {read_tokens:,}. "
                    f"Net cost: ${abs_cost:.4f}."
                )
                recommendation = (
                    "Ratio is acceptable but volume is low. "
                    "Consider longer sessions to amortize cache creation cost."
                )

        return CacheAnalysis(
            status=status,
            summary=summary,
            creation_tokens=creation_tokens,
            read_tokens=read_tokens,
            ratio=round(ratio, 4),
            net_savings_usd=round(net_savings_usd, 4),
            top_cache_creators=top_cache_creators,
            top_cache_readers=top_cache_readers,
            recommendation=recommendation,
        )

    def _build_builtin_tool_summary(self) -> BuiltinToolSummary:
        """Build summary of built-in tool usage (v1.2.0 - task-78).

        Converts internal builtin_tool_stats dict to a structured summary
        for inclusion in session output.

        Returns:
            BuiltinToolSummary with total counts and per-tool breakdown
        """
        if not self.builtin_tool_stats:
            return BuiltinToolSummary()

        total_calls = 0
        total_tokens = 0
        tools_list: List[Dict[str, Any]] = []

        # Sort by tokens (descending) for consistent output
        sorted_tools = sorted(
            self.builtin_tool_stats.items(),
            key=lambda x: x[1].get("tokens", 0),
            reverse=True,
        )

        for tool_name, stats in sorted_tools:
            calls = stats.get("calls", 0)
            tokens = stats.get("tokens", 0)
            total_calls += calls
            total_tokens += tokens
            tools_list.append(
                {
                    "tool": tool_name,
                    "calls": calls,
                    "tokens": tokens,
                }
            )

        return BuiltinToolSummary(
            total_calls=total_calls,
            total_tokens=total_tokens,
            tools=tools_list,
        )

    def next_call_index(self) -> int:
        """Get next sequential call index"""
        self._call_index += 1
        return self._call_index


# ============================================================================
# BaseTracker Abstract Class
# ============================================================================


class BaseTracker(ABC):
    """
    Abstract base class for platform-specific MCP trackers.

    Provides common functionality and defines the adapter interface
    that all platform trackers must implement.
    """

    def __init__(self, project: str, platform: str):
        """
        Initialize base tracker.

        Args:
            project: Project name (e.g., "mcp-audit")
            platform: Platform identifier (e.g., "claude-code", "codex-cli", "gemini-cli")
        """
        self.project = project
        self.platform = platform
        self.timestamp = _now_with_timezone()
        self.session_id = self._generate_session_id()
        self.working_directory = str(Path.cwd())

        # Session data
        self.session = Session(
            project=project,
            platform=platform,
            timestamp=self.timestamp,
            session_id=self.session_id,
            mcp_audit_version=__version__,
            working_directory=self.working_directory,
        )

        # Server sessions (key: server name)
        self.server_sessions: Dict[str, ServerSession] = {}

        # Duplicate detection (key: content_hash)
        self.content_hashes: Dict[str, List[Call]] = defaultdict(list)

        # Session directory and file path
        self.session_dir: Optional[Path] = None
        self.session_path: Optional[Path] = None  # Full path to saved session file

        # Output directory (default: ~/.mcp-audit/sessions)
        self.output_dir: Path = Path.home() / ".mcp-audit" / "sessions"

    def _generate_session_id(self) -> str:
        """Generate unique session ID"""
        timestamp_str = self.timestamp.strftime("%Y-%m-%dT%H-%M-%S")
        return f"{self.project}-{timestamp_str}"

    # ========================================================================
    # Abstract Methods (Platform-specific implementation required)
    # ========================================================================

    @abstractmethod
    def start_tracking(self) -> None:
        """
        Start tracking session.

        Platform-specific implementation:
        - Claude Code: Start tailing debug.log
        - Codex CLI: Start process wrapper
        - Gemini CLI: Start process wrapper with --debug
        """
        pass

    @abstractmethod
    def parse_event(self, event_data: Any) -> Optional[Tuple[str, Dict[str, Any]]]:
        """
        Parse platform-specific event into normalized format.

        Args:
            event_data: Raw event data (line, JSON object, etc.)

        Returns:
            Tuple of (tool_name, usage_dict) if MCP tool call, None otherwise

        Platform-specific parsing:
        - Claude Code: Parse debug.log JSON event
        - Codex CLI: Parse stdout/stderr text
        - Gemini CLI: Parse debug output or checkpoint
        """
        pass

    @abstractmethod
    def get_platform_metadata(self) -> Dict[str, Any]:
        """
        Get platform-specific metadata.

        Returns:
            Dictionary with platform-specific data
            (e.g., model, debug_log_path, checkpoint_path)
        """
        pass

    # ========================================================================
    # Normalization (Shared implementation)
    # ========================================================================

    def normalize_server_name(self, tool_name: str) -> str:
        """
        Extract and normalize server name from tool name.

        Examples:
            "mcp__zen__chat" → "zen"
            "mcp__zen-mcp__chat" → "zen" (Codex CLI format)
            "mcp__brave-search__web" → "brave-search"
            "builtin__read_file" → "builtin" (Gemini CLI format, task-78)
            "__builtin__:shell_command" → "builtin" (Codex CLI format, task-69.31.2)

        Args:
            tool_name: Full MCP tool name or built-in tool name

        Returns:
            Normalized server name
        """
        # Handle built-in tools (task-78, task-69.31.2)
        # Gemini CLI format: builtin__tool_name
        if tool_name.startswith("builtin__"):
            return "builtin"
        # Codex CLI format: __builtin__:tool_name
        if tool_name.startswith("__builtin__:"):
            return "builtin"

        if not tool_name.startswith("mcp__"):
            warnings.warn(f"Tool name doesn't start with 'mcp__': {tool_name}", stacklevel=2)
            return "unknown"

        # Remove mcp__ prefix
        name_parts = tool_name[5:].split("__")

        # Handle Codex CLI format: mcp__zen-mcp__chat
        server_name = name_parts[0]
        if server_name.endswith("-mcp"):
            server_name = server_name[:-4]

        return server_name

    def normalize_tool_name(self, tool_name: str) -> str:
        """
        Normalize tool name to consistent format.

        Examples:
            "mcp__zen-mcp__chat" → "mcp__zen__chat" (Codex CLI)
            "mcp__zen__chat" → "mcp__zen__chat" (Claude Code)

        Args:
            tool_name: Raw tool name from platform

        Returns:
            Normalized tool name (Claude Code format)
        """
        # Strip -mcp suffix from server name (Codex CLI compatibility)
        if "-mcp__" in tool_name:
            parts = tool_name.split("__")
            if len(parts) >= 2 and parts[0] == "mcp":
                server_name = parts[1].replace("-mcp", "")
                tool_suffix = "__".join(parts[2:])
                return f"mcp__{server_name}__{tool_suffix}"

        return tool_name

    # ========================================================================
    # Session Management (Shared implementation)
    # ========================================================================

    def record_tool_call(
        self,
        tool_name: str,
        input_tokens: int,
        output_tokens: int,
        cache_created_tokens: int = 0,
        cache_read_tokens: int = 0,
        duration_ms: int = 0,
        content_hash: Optional[str] = None,
        platform_data: Optional[Dict[str, Any]] = None,
        is_estimated: bool = False,
        estimation_method: Optional[str] = None,
        estimation_encoding: Optional[str] = None,
    ) -> None:
        """
        Record a single MCP tool call.

        Args:
            tool_name: Normalized tool name
            input_tokens: Input token count
            output_tokens: Output token count
            cache_created_tokens: Cache creation tokens
            cache_read_tokens: Cache read tokens
            duration_ms: Call duration in milliseconds (0 if not available)
            content_hash: SHA256 hash of input (for duplicate detection)
            platform_data: Platform-specific metadata
            is_estimated: True if token counts are estimated (v1.4.0)
            estimation_method: "tiktoken", "sentencepiece", or "character" (v1.4.0)
            estimation_encoding: e.g., "o200k_base", "sentencepiece:gemma" (v1.4.0)
        """
        # Normalize tool name
        normalized_tool = self.normalize_tool_name(tool_name)
        server_name = self.normalize_server_name(normalized_tool)

        # Create Call object with sequential index
        total_tokens = input_tokens + output_tokens + cache_created_tokens + cache_read_tokens
        call_index = self.session.next_call_index()
        call = Call(
            timestamp=_now_with_timezone(),
            tool_name=normalized_tool,
            server=server_name,  # v1.1.0: include server name in call
            index=call_index,  # v1.1.0: sequential call number
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cache_created_tokens=cache_created_tokens,
            cache_read_tokens=cache_read_tokens,
            total_tokens=total_tokens,
            duration_ms=duration_ms,
            content_hash=content_hash,
            platform_data=platform_data,
            # v1.4.0: Token estimation metadata
            is_estimated=is_estimated,
            estimation_method=estimation_method,
            estimation_encoding=estimation_encoding,
        )

        # Track duplicate calls
        if content_hash:
            self.content_hashes[content_hash].append(call)

        # Get or create server session
        if server_name not in self.server_sessions:
            self.server_sessions[server_name] = ServerSession(server=server_name)

        server_session = self.server_sessions[server_name]

        # Get or create tool stats
        if normalized_tool not in server_session.tools:
            server_session.tools[normalized_tool] = ToolStats()

        tool_stats = server_session.tools[normalized_tool]

        # Update tool stats
        tool_stats.calls += 1
        tool_stats.total_tokens += total_tokens
        tool_stats.avg_tokens = tool_stats.total_tokens / tool_stats.calls
        tool_stats.call_history.append(call)
        # Per-tool cache tracking (task-47.4)
        tool_stats.cache_created_tokens += cache_created_tokens
        tool_stats.cache_read_tokens += cache_read_tokens

        # Update duration stats (if available)
        if duration_ms > 0:
            if tool_stats.total_duration_ms is None:
                tool_stats.total_duration_ms = 0
            tool_stats.total_duration_ms += duration_ms
            tool_stats.avg_duration_ms = tool_stats.total_duration_ms / tool_stats.calls

            if tool_stats.max_duration_ms is None or duration_ms > tool_stats.max_duration_ms:
                tool_stats.max_duration_ms = duration_ms

            if tool_stats.min_duration_ms is None or duration_ms < tool_stats.min_duration_ms:
                tool_stats.min_duration_ms = duration_ms

        # Update server totals
        server_session.total_calls += 1
        server_session.total_tokens += total_tokens

        # Update session token usage
        self.session.token_usage.input_tokens += input_tokens
        self.session.token_usage.output_tokens += output_tokens
        self.session.token_usage.cache_created_tokens += cache_created_tokens
        self.session.token_usage.cache_read_tokens += cache_read_tokens
        self.session.token_usage.total_tokens += total_tokens

        # Recalculate cache efficiency: percentage of INPUT tokens served from cache
        total_input = (
            self.session.token_usage.input_tokens
            + self.session.token_usage.cache_created_tokens
            + self.session.token_usage.cache_read_tokens
        )
        if total_input > 0:
            self.session.token_usage.cache_efficiency = (
                self.session.token_usage.cache_read_tokens / total_input
            )

    def finalize_session(self) -> Session:
        """
        Finalize session data and calculate summary statistics.

        Returns:
            Complete Session object
        """
        # Update session end time (use timezone-aware datetime for v1.1.0)
        self.session.end_timestamp = _now_with_timezone()
        self.session.duration_seconds = (
            self.session.end_timestamp - self.session.timestamp
        ).total_seconds()

        # Update MCP tool calls summary
        # Filter out "builtin" pseudo-server - these are NOT MCP tools (task-95.2)
        mcp_server_sessions = {
            name: session for name, session in self.server_sessions.items() if name != "builtin"
        }

        all_tools: set[str] = set()
        most_called_tool = ""
        most_called_count = 0

        for server_session in mcp_server_sessions.values():
            for tool_name, tool_stats in server_session.tools.items():
                all_tools.add(tool_name)
                if tool_stats.calls > most_called_count:
                    most_called_count = tool_stats.calls
                    most_called_tool = f"{tool_name} ({tool_stats.calls} calls)"

        self.session.mcp_tool_calls.total_calls = sum(
            ss.total_calls for ss in mcp_server_sessions.values()
        )
        self.session.mcp_tool_calls.unique_tools = len(all_tools)
        self.session.mcp_tool_calls.most_called = most_called_tool

        # Add server sessions to session
        self.session.server_sessions = self.server_sessions

        # Analyze duplicates
        self.session.redundancy_analysis = self._analyze_redundancy()

        # Detect anomalies
        self.session.anomalies = self._detect_anomalies()

        # Detect efficiency smells (v1.5.0 - task-103.1)
        from .smells import detect_smells

        self.session.smells = detect_smells(self.session)

        # Detect zombie tools (v1.5.0 - task-103.4)
        from .zombie_detector import detect_zombie_tools

        self.session.zombie_tools = detect_zombie_tools(self.session)

        return self.session

    def _analyze_redundancy(self) -> Dict[str, Any]:
        """Analyze duplicate tool calls"""
        duplicate_calls = 0
        potential_savings = 0

        for _content_hash, calls in self.content_hashes.items():
            if len(calls) > 1:
                duplicate_calls += len(calls) - 1
                # Calculate savings (all calls after first could be cached)
                for call in calls[1:]:
                    potential_savings += call.total_tokens

        return {"duplicate_calls": duplicate_calls, "potential_savings": potential_savings}

    def _detect_anomalies(self) -> List[Dict[str, Any]]:
        """Detect anomalies in tool usage"""
        anomalies = []

        for server_session in self.server_sessions.values():
            for tool_name, tool_stats in server_session.tools.items():
                # High frequency (>10 calls)
                if tool_stats.calls > 10:
                    anomalies.append(
                        {
                            "type": "high_frequency",
                            "tool": tool_name,
                            "calls": tool_stats.calls,
                            "threshold": 10,
                        }
                    )

                # High average tokens (>500K per call - task-42.2 AC#2)
                # Note: Claude Code reports cumulative context per call (~120-130K typical)
                # So 500K indicates genuinely expensive operations like thinkdeep/consensus
                if tool_stats.avg_tokens > 500000:
                    anomalies.append(
                        {
                            "type": "high_avg_tokens",
                            "tool": tool_name,
                            "avg_tokens": tool_stats.avg_tokens,
                            "threshold": 500000,
                        }
                    )

        return anomalies

    # ========================================================================
    # High-Level Interface (CLI integration)
    # ========================================================================

    def start(self) -> None:
        """
        Initialize tracking (called before monitor loop).

        Default implementation is a no-op. Subclasses may override
        for any pre-monitoring setup.
        """
        return None  # Intentional no-op: subclasses override as needed

    def monitor(self, display: Optional["DisplayAdapter"] = None) -> None:
        """
        Main monitoring loop with optional display integration.

        Default implementation calls start_tracking() which contains
        the platform-specific monitoring loop. Subclasses should override
        this to integrate display updates.

        Args:
            display: Optional DisplayAdapter for real-time UI updates
        """
        # Store display for use in event processing
        self._display = display
        # Call platform-specific tracking
        self.start_tracking()

    def stop(self) -> Optional[Session]:
        """
        Stop tracking and finalize session.

        Returns:
            Finalized Session object, or None if no data collected
        """
        session = self.finalize_session()

        # Save session data using configured output directory
        self.save_session(self.output_dir)

        return session

    # ========================================================================
    # Persistence (Shared implementation)
    # ========================================================================

    def save_session(self, output_dir: Path) -> None:
        """
        Save session data to disk using v1.1.0 format.

        v1.1.0 Changes:
        - Date subdirectories: ~/.mcp-audit/sessions/YYYY-MM-DD/
        - Single file per session: <project>-<timestamp>.json
        - Self-describing _file header block
        - Flat tool_calls array (no separate mcp-*.json files)

        Args:
            output_dir: Base directory for sessions (default: ~/.mcp-audit/sessions)
        """
        # Create platform/date subdirectory structure
        # e.g., ~/.mcp-audit/sessions/codex-cli/2025-12-04/
        date_str = self.timestamp.strftime("%Y-%m-%d")
        platform_dir = output_dir / self.platform
        date_dir = platform_dir / date_str
        date_dir.mkdir(parents=True, exist_ok=True)

        # Generate file name: <project>-<timestamp>.json
        # Use safe timestamp format for filenames (no colons)
        timestamp_str = self.timestamp.strftime("%Y-%m-%dT%H-%M-%S")
        file_name = f"{self.project}-{timestamp_str}.json"
        session_path = date_dir / file_name

        # Store session_dir for reference (point to date dir, file is single file)
        self.session_dir = date_dir
        self.session_path = session_path  # Full path to session file

        # Build the _file header
        file_header = FileHeader(
            name=file_name,
            type="mcp_audit_session",
            purpose=(
                "Complete MCP session log with token usage and tool call statistics "
                "for AI agent analysis"
            ),
            schema_version=SCHEMA_VERSION,
            schema_docs="https://github.com/littlebearapps/mcp-audit/blob/main/docs/data-contract.md",
            generated_by=f"mcp-audit v{__version__}",
            generated_at=_format_timestamp(_now_with_timezone()),
        )

        # Get session data and inject _file header
        session_data = self.session.to_dict()
        session_data["_file"] = file_header.to_dict()

        # Save as single JSON file
        with open(session_path, "w") as f:
            json.dump(session_data, f, indent=2, default=str)

        # Note: v1.1.0 removes separate mcp-*.json files - all data in single file

    # ========================================================================
    # Unrecognized Line Handler (Shared implementation)
    # ========================================================================

    def handle_unrecognized_line(self, line: str) -> None:
        """
        Handle unrecognized event lines gracefully.

        Args:
            line: Unrecognized event line
        """
        # Log warning but don't crash
        warnings.warn(f"Unrecognized event format: {line[:100]}...", stacklevel=2)

    # ========================================================================
    # Utility Methods
    # ========================================================================

    @staticmethod
    def compute_content_hash(input_data: Any) -> str:
        """
        Compute SHA256 hash of input data for duplicate detection.

        Args:
            input_data: Tool input parameters

        Returns:
            SHA256 hash string
        """
        # Convert to stable JSON string
        json_str = json.dumps(input_data, sort_keys=True)
        return hashlib.sha256(json_str.encode()).hexdigest()
