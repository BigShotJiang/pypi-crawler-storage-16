"""CLI module for mcp-browser."""

from .main import main

__all__ = ["main"]
