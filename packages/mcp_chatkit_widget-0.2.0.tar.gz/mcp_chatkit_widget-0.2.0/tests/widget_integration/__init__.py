"""Package for widget integration test utilities."""
