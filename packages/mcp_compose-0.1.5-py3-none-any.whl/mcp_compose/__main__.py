#!/usr/bin/env python3
"""Main entry point for the mcp-compose package."""

from mcp_compose.cli import main

if __name__ == "__main__":
    main()
