"""数据模型包"""

from .mind import Mind, MindGenerateResult

__all__ = [
    "Mind",
    "MindGenerateResult",
]