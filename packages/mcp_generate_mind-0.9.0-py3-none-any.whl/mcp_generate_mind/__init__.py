"""思维导图生成 MCP服务器包"""

__version__ = "0.1.0"
__author__ = "chenzeng"
__email__ = "chenzeng@cmss.chinamobile.com"