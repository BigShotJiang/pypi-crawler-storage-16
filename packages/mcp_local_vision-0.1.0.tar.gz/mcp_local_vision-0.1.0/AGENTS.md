# Repository Guidelines

## Project Structure & Modules
- `src/mcp_local_vision/server.py`: FastMCP server with the `analyze_local_image` tool and provider dispatch logic (local/OpenAI/OpenRouter/Ollama/Anthropic/Google).
- `src/mcp_local_vision/__init__.py`: Package marker; console entry point registered as `mcp-local-vision`.
- `tests/test_server.py`: Pytest suite covering validation and provider dispatch; relies on mocks rather than live API calls.
- Root artifacts: `pyproject.toml` (deps and scripts), `README.md` (setup/usage), `uv.lock` (resolved deps), `test_*.log` (prior run outputs; safe to ignore).

## Build, Test, and Development Commands
- Create env: `python -m venv .venv && source .venv/bin/activate` (or use `uv venv && source .venv/bin/activate`).
- Install (dev): `pip install -e .[dev]` (installs `fastmcp`, OpenAI/Anthropic/Gemini clients, pytest).
- Run server from source: `python src/mcp_local_vision/server.py` (starts FastMCP with the registered tool). From an installed package: `uvx mcp-local-vision`.
- Quick check: `python -c "import mcp_local_vision; print('ok')"` to verify import path resolution.
- Tests: `pytest` (add `-q` for terse output).
- Key env vars: `LOCAL_INFERENCE_URL`/`LOCAL_INFERENCE_KEY` for local loops; `LOCAL_MODEL` (default `llava`) to pick the vision model name; provider-specific keys (`OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, `GOOGLE_API_KEY`, `OPENROUTER_API_KEY`, `OLLAMA_URL`, `OLLAMA_MODEL`).

## Coding Style & Naming Conventions
- Python 3.10+; 4-space indentation; prefer type hints on public functions (see `analyze_image_logic` signature).
- Use snake_case for functions/variables; keep provider names lowercase (`local`, `openai`, `anthropic`, `google`, `openrouter`, `ollama`).
- Favor small, testable helpers (e.g., `_call_openai_compatible`, `_call_anthropic`, `_call_google`). Keep error messages explicit and user-facing.
- Avoid committing secrets; read configuration from environment variables.

## Testing Guidelines
- Use pytest with function-level tests named `test_*` under `tests/`.
- Prefer fixtures (e.g., `tmp_path`) for creating temp assets; mock network-bound functions (`openai.OpenAI`, `Anthropic`, `google.generativeai`) and file I/O as in existing tests.
- When adding providers or branches, add a dispatch test plus validation for error/edge cases (missing API key, non-image file).
- No coverage threshold enforced; keep tests fast and offline-only.

## Commit & Pull Request Guidelines
- Write concise, imperative commit messages (e.g., `Add google provider fallback`, `Harden image mime validation`). If adding features, mention provider or tool touched.
- PRs should include: scope summary, testing commands run (`pytest`, manual server invocation), and any required env vars (`LOCAL_INFERENCE_URL`, `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, `GOOGLE_API_KEY`, `OPENROUTER_API_KEY`, `OLLAMA_URL`, `OLLAMA_MODEL`, etc.).
- When behavior changes, note user-facing errors or defaults (e.g., default model names, timeout handling).
