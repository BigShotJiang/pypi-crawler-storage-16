from fastmcp import FastMCP
import os
import base64
import sys
import mimetypes
from typing import Optional

# Initialize FastMCP
mcp = FastMCP(
    "Local Vision Bridge", 
    dependencies=["openai", "anthropic", "google-generativeai"]
)

@mcp.tool()
def analyze_local_image(
    file_path: str, 
    question: str = "Describe this image in detail",
    timeout: int = 30,
    provider: str = "local"
) -> str:
    """
    Analyzes a local image file using the specified vision provider.

    Args:
        file_path: Absolute path to the image.
        question: The prompt for the vision model.
        timeout: Request timeout in seconds (default: 30).
        provider: The provider to use for inference. Options:
            - 'local': Use generic OpenAI-compatible local server (LM Studio, Ollama, vLLM).
                       Requires LOCAL_INFERENCE_URL (default: http://localhost:1234/v1).
            - 'openai': Use OpenAI API. Requires OPENAI_API_KEY.
            - 'anthropic': Use Anthropic API. Requires ANTHROPIC_API_KEY.
            - 'google': Use Google Gemini API. Requires GOOGLE_API_KEY.
            - 'openrouter': Use OpenRouter. Requires OPENROUTER_API_KEY.
    """
    return analyze_image_logic(file_path, question, timeout, provider)

def analyze_image_logic(
    file_path: str,
    question: str,
    timeout: int,
    provider: str
) -> str:
    if not os.path.exists(file_path):
        return f"Error: File not found at {file_path}"
    
    # Basic mime validation (extension based)
    mime_type, _ = mimetypes.guess_type(file_path)
    if not mime_type or not mime_type.startswith('image/'):
        return f"Error: File at {file_path} is not recognized as an image. Mime type detected: {mime_type}"

    try:
        # 2. Encode Image
        with open(file_path, "rb") as image_file:
            encoded_string = base64.b64encode(image_file.read()).decode('utf-8')
        
        # 3. Provider Dispatch
        if provider in ["local", "openai", "openrouter", "ollama"]:
            return _call_openai_compatible(provider, encoded_string, mime_type, question, timeout)
        elif provider == "anthropic":
            return _call_anthropic(encoded_string, mime_type, question, timeout)
        elif provider == "google":
            return _call_google(file_path, question, timeout) # Google pass file directly or upload
        else:
            return f"Error: Unknown provider '{provider}'. Supported: local, openai, anthropic, google, openrouter."

    except Exception as e:
        return f"Error during vision analysis: {str(e)}"

def _call_openai_compatible(provider: str, b64_img: str, mime: str, prompt: str, timeout: int) -> str:
    from openai import OpenAI
    import httpx
    
    # Defaults for 'local'
    base_url = os.environ.get("LOCAL_INFERENCE_URL", "http://localhost:1234/v1")
    api_key = os.environ.get("LOCAL_INFERENCE_KEY", "lm-studio")
    model = (
        os.environ.get("LOCAL_MODEL")
        or os.environ.get("LOCAL_VISION_MODEL")
        or "llava"
    )

    if provider == "openai":
        base_url = None # Default
        api_key = os.environ.get("OPENAI_API_KEY")
        model = "gpt-4o"
    elif provider == "openrouter":
        base_url = "https://openrouter.ai/api/v1"
        api_key = os.environ.get("OPENROUTER_API_KEY")
        model = os.environ.get("OPENROUTER_MODEL", "google/gemini-2.0-flash-exp:free") 
    elif provider == "ollama":
        # Ollama typically runs on 11434
        base_url = os.environ.get("OLLAMA_URL", "http://localhost:11434/v1")
        api_key = "ollama"
        model = os.environ.get("OLLAMA_MODEL", "llava")

    if not api_key and provider != "local" and provider != "ollama":
        return f"Error: Missing API key for {provider}. Set environment variable."

    try:
        client = OpenAI(base_url=base_url, api_key=api_key, timeout=timeout)
        response = client.chat.completions.create(
            model=model,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:{mime};base64,{b64_img}"
                            },
                        },
                    ],
                }
            ],
            max_tokens=1000, 
        )
        msg = response.choices[0].message
        content = msg.content
        
        if not content:
            # Fallback for reasoning models
            data = msg.model_dump() if hasattr(msg, 'model_dump') else msg.__dict__
            reasoning = data.get('reasoning_content') or data.get('reasoning')
            if reasoning:
                return f"[Thinking Process]:\n{reasoning}"
            return "Error: Model returned empty response. Ensure a Vision Model is loaded."
        return content

    except httpx.ConnectError:
        if provider in ["local", "ollama"]:
            return (f"Error: Could not connect to {provider} server at {base_url}. " 
                   "Please ensure your local inference server (LM Studio / Ollama) is running and accessible. "
                   "If you are using a GUI agent, remember the server needs to be running separately.")
        raise
    except Exception as e:
        raise e

def _call_anthropic(b64_img: str, mime: str, prompt: str, timeout: int) -> str:
    from anthropic import Anthropic
    
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        return "Error: ANTHROPIC_API_KEY not found."

    client = Anthropic(api_key=api_key, timeout=timeout)
    
    # Anthropic expects 'image/jpeg', 'image/png', 'image/gif', or 'image/webp'
    # and strip 'image/' from media_type arg? No, parameter name is media_type
    
    response = client.messages.create(
        model="claude-3-5-sonnet-20241022",
        max_tokens=1000,
        messages=[
            {
                "role": "user",
                "content": [
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": mime,
                            "data": b64_img,
                        },
                    },
                    {
                        "type": "text",
                        "text": prompt
                    }
                ],
            }
        ],
    )
    return response.content[0].text

def _call_google(file_path: str, prompt: str, timeout: int) -> str:
    import google.generativeai as genai
    
    api_key = os.environ.get("GOOGLE_API_KEY")
    if not api_key:
        return "Error: GOOGLE_API_KEY not found."
    
    genai.configure(api_key=api_key)
    
    # Upload file (Gemini API handles images better via upload for large files, but for strict local privacy...
    # wait, if using google provider, privacy is already out. But user might want to avoid 'uploading' to a storage manager if possible.
    # However, genai.upload_file is standard.)
    
    try:
        # Note: server-side file API might be slow for a 'local loop'. 
        # Alternative: Data inline. Gemini supports inline data.
        with open(file_path, "rb") as f:
            image_data = f.read()
            
        mime_type, _ = mimetypes.guess_type(file_path)
        
        model = genai.GenerativeModel("gemini-1.5-flash")
        
        # Timeout handling for Google is a bit generic
        response = model.generate_content(
            [
                {"mime_type": mime_type, "data": image_data},
                prompt
            ],
            request_options={"timeout": timeout}
        )
        return response.text
    except Exception as e:
        return f"Google API Error: {str(e)}"

if __name__ == "__main__":
    mcp.run()
