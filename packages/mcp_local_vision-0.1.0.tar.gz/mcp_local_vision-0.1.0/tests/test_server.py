import pytest
import base64
import os
from unittest.mock import MagicMock, patch
import mcp_local_vision.server as server

# Helper to create a dummy image file
@pytest.fixture
def dummy_image(tmp_path):
    img_path = tmp_path / "test_image.png"
    # Create a small valid PNG signature (not a full valid png, just enough for mime guess if needed, 
    # but mocks will handle the actual reading usually. 
    # However mime guessing looks at extension mostly in python standard lib unless using python-magic)
    with open(img_path, "wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01") 
    return str(img_path)

@pytest.fixture
def dummy_text_file(tmp_path):
    txt_path = tmp_path / "test.txt"
    with open(txt_path, "w") as f:
        f.write("This is not an image")
    return str(txt_path)

def test_validation_file_not_found():
    result = server.analyze_image_logic("/non/existent/path.jpg", question="q", timeout=30, provider="local")
    assert "Error: File not found" in result

def test_validation_not_an_image(dummy_text_file):
    result = server.analyze_image_logic(dummy_text_file, question="q", timeout=30, provider="local")
    assert "Error: File at" in result
    assert "is not recognized as an image" in result

@patch("mcp_local_vision.server.mimetypes.guess_type")
@patch("builtins.open", new_callable=MagicMock)
@patch("mcp_local_vision.server._call_openai_compatible")
def test_provider_dispatch_local(mock_call_openai, mock_open, mock_guess, dummy_image):
    mock_guess.return_value = ("image/png", None)
    # create a mock file context
    mock_file = MagicMock()
    mock_file.read.return_value = b"fakedata"
    mock_open.return_value.__enter__.return_value = mock_file
    
    server.analyze_image_logic(dummy_image, question="desc", timeout=30, provider="local")
    
    mock_call_openai.assert_called_once()
    args, _ = mock_call_openai.call_args
    # Check that provider was passed correctly
    assert args[0] == "local"
    # Check that base64 encoding happened (b64 of 'fakedata' is 'ZmFrZWRhdGE=')
    assert args[1] == "ZmFrZWRhdGE="
    assert args[2] == "image/png"

@patch("mcp_local_vision.server.mimetypes.guess_type")
@patch("builtins.open", new_callable=MagicMock)
@patch("mcp_local_vision.server._call_anthropic")
def test_provider_dispatch_anthropic(mock_call_anthropic, mock_open, mock_guess, dummy_image):
    mock_guess.return_value = ("image/jpeg", None)
    mock_file = MagicMock()
    mock_file.read.return_value = b"fakedata"
    mock_open.return_value.__enter__.return_value = mock_file

    server.analyze_image_logic(dummy_image, question="desc", timeout=30, provider="anthropic")
    
    mock_call_anthropic.assert_called_once()
    args, _ = mock_call_anthropic.call_args
    assert args[1] == "image/jpeg"

def test_unknown_provider(dummy_image):
    # We need to mock open/exists/mime for this to reach provider check
    with patch("os.path.exists", return_value=True), \
         patch("mcp_local_vision.server.mimetypes.guess_type", return_value=("image/png", None)), \
         patch("mcp_local_vision.server.mimetypes.guess_type", return_value=("image/png", None)), \
         patch("builtins.open", new_callable=MagicMock) as mock_open:
        
        mock_file = MagicMock()
        mock_file.read.return_value = b"fakebytes"
        mock_open.return_value.__enter__.return_value = mock_file
        
        result = server.analyze_image_logic("somepath.png", question="q", timeout=30, provider="unknown_provider")
        assert "Error: Unknown provider 'unknown_provider'" in result

@patch("openai.OpenAI")
def test_openai_compatible_logic(mock_openai_cls):
    # Mock the client instance and response
    mock_client = MagicMock()
    mock_openai_cls.return_value = mock_client
    
    mock_response = MagicMock()
    mock_message = MagicMock()
    mock_message.content = "A description of the image"
    mock_response.choices = [MagicMock(message=mock_message)]
    
    mock_client.chat.completions.create.return_value = mock_response
    
    result = server._call_openai_compatible(
        provider="local", 
        b64_img="abc", 
        mime="image/png", 
        prompt="desc", 
        timeout=10
    )
    
    assert result == "A description of the image"
    mock_client.chat.completions.create.assert_called_once()
    
    # Check timeout was passed
    _, kwargs = mock_openai_cls.call_args
    assert kwargs["timeout"] == 10

@patch("openai.OpenAI")
def test_openai_compatible_reasoning_fallback(mock_openai_cls):
    mock_client = MagicMock()
    mock_openai_cls.return_value = mock_client
    
    # Create a simple mock object structure properly
    mock_message = MagicMock()
    mock_message.content = None
    # We can't easily mock __dict__ on a MagicMock in a way that serialization uses without unintended side effects in some versions
    # Instead, let's mock the behavior of model_dump which we prefer
    mock_message.model_dump.return_value = {"reasoning_content": "I am thinking..."}
    
    mock_choice = MagicMock()
    mock_choice.message = mock_message
    
    mock_response = MagicMock()
    mock_response.choices = [mock_choice]
    
    mock_client.chat.completions.create.return_value = mock_response
    mock_client.chat.completions.create.return_value = mock_response
    
    result = server._call_openai_compatible(
        provider="local", 
        b64_img="abc", 
        mime="image/png", 
        prompt="desc", 
        timeout=10
    )
    
    assert "[Thinking Process]" in result
    assert "I am thinking..." in result
