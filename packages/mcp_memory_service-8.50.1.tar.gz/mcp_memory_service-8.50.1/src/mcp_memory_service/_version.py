"""Version information for MCP Memory Service."""

__version__ = "8.50.1"
