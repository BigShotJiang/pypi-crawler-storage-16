"""
API endpoints for MCP Open Client.
"""