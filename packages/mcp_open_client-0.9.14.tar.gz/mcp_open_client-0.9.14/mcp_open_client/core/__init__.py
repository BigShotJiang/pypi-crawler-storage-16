"""
Core module for MCP Open Client.
"""