"""MCP PDF ChromaDB Server - PDF processing and semantic search with ChromaDB."""

__version__ = "1.0.0"
