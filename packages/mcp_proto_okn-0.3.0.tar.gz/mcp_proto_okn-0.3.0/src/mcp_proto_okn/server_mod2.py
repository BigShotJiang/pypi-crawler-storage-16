"""
MCP SPARQL Server for Proto-OKN Knowledge Graphs

This module provides a Model Context Protocol (MCP) server that enables querying
of SPARQL endpoints, particularly those in the Proto-OKN (Prototype Open Knowledge Network)
ecosystem hosted on the FRINK platform.

The server automatically detects FRINK endpoints and provides appropriate documentation
links to the knowledge graph registry. It supports querying various knowledge graphs
including SPOKE, BioBricks ICE, DREAM-KG, SAWGraph, and many others in the Proto-OKN
program.

For FRINK endpoints (https://frink.apps.renci.org/*), the server automatically generates
a description pointing to the knowledge graph registry. For other endpoints, you can
provide a custom description using the --description argument.

This class is an extension of the mcp-server-sparql MCP server.
"""

import json
import argparse
from typing import Dict, Any, Optional, Union, List, Tuple
from io import StringIO
import csv
from urllib.parse import urlparse
from urllib.request import urlopen
from urllib.error import URLError, HTTPError

from SPARQLWrapper import SPARQLWrapper, JSON
from SPARQLWrapper.SPARQLExceptions import EndPointNotFound

from mcp.server.fastmcp import FastMCP


class SPARQLServer:
    """SPARQL endpoint wrapper with Proto-OKN/registry awareness."""

    def __init__(self, endpoint_url: str, description: Optional[str] = None):
        self.endpoint_url = endpoint_url
        self.description = description  # None means: try to infer
        self.kg_name = ""
        self.registry_url: Optional[str] = None
        self.github_base_url = "https://raw.githubusercontent.com/sbl-sdsc/mcp-proto-okn/main/metadata/entities"

        # Initialize SPARQLWrapper with only the query endpoint
        self.sparql = SPARQLWrapper(endpoint_url)
        self.sparql.setReturnFormat(JSON)

    # ---------------------- Internal helpers ---------------------- #

    def _extract_values(self, result: Any, var: str) -> List[str]:
        """Extract variable bindings from a SPARQL JSON result."""
        # SPARQLWrapper default .convert() returns:
        # {
        #   'head': {'vars': [...]},
        #   'results': {'bindings': [
        #       { var: { 'type': 'uri', 'value': '...' }, ... },
        #   ]}
        # }
        if isinstance(result, dict) and "results" in result:
            out: List[str] = []
            for binding in result["results"].get("bindings", []):
                if var in binding and "value" in binding[var]:
                    out.append(binding[var]["value"])
            return out
    
        # Fallback: some custom execute() wrappers might just return a list of dicts
        if isinstance(result, list):
            return [
                row.get(var)
                for row in result
                if isinstance(row, dict) and var in row
            ]
    
        # Last resort: return as-is wrapped in list if it's a string, else []
        if isinstance(result, str):
            return [result]
        return []

    def _simplify_result(self, result: Dict) -> Dict:
        """Remove type/datatype metadata, keep only values"""
        if 'results' not in result:
            return result
            
        simplified_bindings = []
        for binding in result['results']['bindings']:
            row = {}
            for var, data in binding.items():
                row[var] = data.get('value', '')
            simplified_bindings.append(row)
        
        return {
            'variables': result['head']['vars'],
            'rows': simplified_bindings,
            'count': len(simplified_bindings)
        }

    def _values_only(self, result: Dict) -> List[Dict[str, str]]:
        """Return flat list of value dictionaries"""
        if 'results' not in result:
            return []
        
        values_list = []
        for binding in result['results']['bindings']:
            row = {}
            for var in binding:
                row[var] = binding[var].get('value', '')
            values_list.append(row)
        
        return values_list

    def _to_csv(self, result: Dict) -> str:
        """Convert result to CSV string"""
        if 'results' not in result:
            return ""
        
        output = StringIO()
        vars = result['head']['vars']
        writer = csv.DictWriter(output, fieldnames=vars)
        writer.writeheader()
        
        for binding in result['results']['bindings']:
            row = {}
            for var in vars:
                if var in binding:
                    row[var] = binding[var].get('value', '')
                else:
                    row[var] = ''
            writer.writerow(row)
        
        return output.getvalue()
    
    def _get_registry_url(self) -> Optional[Tuple[str, str]]:
        """Return (kg_name, registry_url) if this looks like a FRINK endpoint, else None."""
        if not self.endpoint_url.startswith("https://frink.apps.renci.org/"):
            return None

        path_parts = urlparse(self.endpoint_url).path.strip("/").split("/")
        kg_name = path_parts[-2] if len(path_parts) >= 2 else "unknown"

        registry_url = (
            "https://raw.githubusercontent.com/frink-okn/okn-registry/"
            "refs/heads/main/docs/registry/kgs/"
            f"{kg_name}.md"
        )
        self.registry_url = registry_url
        return kg_name, registry_url

    def _fetch_registry_content(self) -> Optional[str]:
        """Fetch registry page content in markdown format or None on failure."""
        try:
            result = self._get_registry_url()
            if not result:
                return None

            kg_name, registry_url = result
            self.kg_name = kg_name

            with urlopen(registry_url, timeout=5) as resp:
                raw = resp.read()
                text = raw.decode("utf-8", errors="replace")
                return text.strip()
        except Exception:
            return None

    def _get_entity_metadata(self) -> Dict[str, Dict[str, str]]:
        """
        Fetch entity metadata from GitHub CSV file.
        Returns a dict mapping URI to {label, description}.
        """
        # Construct the GitHub raw file URL
        kg_name, _ = self._get_registry_url()
        filename = f"{kg_name}_entities.csv"
        url = f"{self.github_base_url}/{filename}"
        
        try:
            with urlopen(url) as response:
                # Read and decode the response
                content = response.read().decode('utf-8')
            
            # Parse CSV
            csv_data = StringIO(content)
            reader = csv.DictReader(csv_data)
            
            # Create lookup dict: URI -> {label, description}
            metadata = {}
            for row in reader:
                uri = row.get('URI', '').strip()
                metadata[uri] = {
                    'label': row.get('Label', ''),
                    'description': row.get('Description', ''),
                }
            
            return metadata
            
        except HTTPError as e:
            print(f"HTTP Error fetching entity metadata: {e.code} - {e.reason}")
            print(f"URL attempted: {url}")
            return {}
        except URLError as e:
            print(f"URL Error fetching entity metadata: {e.reason}")
            print(f"URL attempted: {url}")
            return {}
        except Exception as e:
            print(f"Error parsing entity metadata: {e}")
            return {}
                

    # ---------------------- Public API ---------------------- #
    def execute(self, query_string: str, format: str = 'simplified') -> Union[Dict[str, Any], str]:
        """Execute SPARQL query with format options: 'full', 'simplified', 'values', 'csv'"""
        try:
            self.sparql.setQuery(query_string)
            result = self.sparql.query().convert()
            
            if format == 'simplified':
                # Strip type/datatype metadata, return just values
                return self._simplify_result(result)
            elif format == 'values':
                # Return only values as list of dicts
                return self._values_only(result)
            elif format == 'csv':
                # Convert to CSV string
                return self._to_csv(result)
            else:
                return result  # full format
                
        except Exception as e:
            # Could special-case EndPointNotFound if imported.
            return {"error": f"Query error: {str(e)}"}

    def query_schema(self, compact: bool = True) -> Dict[str, Any]:
        """Return a dict with classes and predicates discovered in the graph."""
        class_query = """
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
SELECT DISTINCT ?class
WHERE {
    ?instance rdf:type ?class .
}
GROUP BY ?class
LIMIT 50
        """
        classes = self.execute(class_query, format='full')

        predicate_query = """
SELECT DISTINCT ?predicate
WHERE {
  ?s ?predicate ?o .
}
GROUP BY ?predicate
LIMIT 200
        """
        predicates = self.execute(predicate_query, format='full')

        class_uris = self._extract_values(classes, "class")
        predicate_uris = self._extract_values(predicates, "predicate")
        
        # Enrich with entity metadata
        metadata = self._get_entity_metadata()
        
        if compact:
            # Return just URI: label mapping for more compact output
            return {
                'classes': {
                    uri: metadata.get(uri, {}).get('label', uri.split('/')[-1].split('#')[-1]) 
                    for uri in class_uris
                },
                'predicates': {
                    uri: metadata.get(uri, {}).get('label', uri.split('/')[-1].split('#')[-1]) 
                    for uri in predicate_uris
                },
                'count': {
                    'classes': len(class_uris),
                    'predicates': len(predicate_uris)
                }
            }
        
        # Full mode with descriptions
        if len(metadata) > 0:
            
            # Enrich classes
            enriched_classes = []
            for uri in class_uris:
                entry = {'uri': uri}
                if uri in metadata:
                    entry['label'] = metadata[uri]['label']
                    entry['description'] = metadata[uri]['description']
                enriched_classes.append(entry)
            
            # Enrich predicates
            enriched_predicates = []
            for uri in predicate_uris:
                entry = {'uri': uri}
                if uri in metadata:
                    entry['label'] = metadata[uri]['label']
                    entry['description'] = metadata[uri]['description']
                enriched_predicates.append(entry)
            
            return {
                "classes": enriched_classes,
                "predicates": enriched_predicates,
            }
        else:
            # Return original format without enrichment
            return {
                "classes": class_uris,
                "predicates": predicate_uris,
            }

    def build_description(self) -> str:
        """Return human-readable metadata about this endpoint."""
        # If caller provided an explicit description, honor it.
        if self.description is not None:
            return self.description.strip()

        # Otherwise, try FRINK registry
        content = self._fetch_registry_content()
        if content and self.registry_url:
            header = f"[registry: {self.registry_url}]\n\n"
            return header + content

        # Fallback
        return "SPARQL Query Server"


def parse_args():
    parser = argparse.ArgumentParser(description="MCP SPARQL Query Server")
    parser.add_argument(
        "--endpoint",
        required=True,
        help="SPARQL endpoint URL (e.g., https://frink.apps.renci.org/spoke/sparql)",
    )
    parser.add_argument(
        "--description",
        required=False,
        help=(
            "Description of the SPARQL endpoint "
            "(For FRINK endpoints this is automatically generated)"
        ),
    )
    return parser.parse_args()


def main():
    args = parse_args()

    # Initialize server (auto-derives kg metadata & dynamic description if applicable)
    sparql_server = SPARQLServer(
        endpoint_url=args.endpoint,
        description=args.description,
    )

    # Create MCP server
    mcp = FastMCP("SPARQL Query Server")

    query_doc = f"""
Execute a SPARQL query against the {sparql_server.kg_name or ''} knowledge graph endpoint: {sparql_server.endpoint_url}.

Args:
    query_string: A valid SPARQL query string
    format: Output format - 'simplified' (default, compact JSON), 'full' (complete SPARQL JSON), 'values' (list of dicts), or 'csv' (CSV string)

Returns:
    The query results in the specified format
"""

    @mcp.tool(description=query_doc)
    def query(query_string: str, format: str = 'simplified') -> Union[Dict[str, Any], List[Dict[str, Any]], str]:
        return sparql_server.execute(query_string, format=format)

    schema_doc = f"""
Return the schema (classes, relationships, properties) of the {sparql_server.kg_name or ''} knowledge graph endpoint: {sparql_server.endpoint_url}.

Args:
    compact: If True (default), returns compact URI:label mappings. If False, returns full metadata with descriptions.

Returns:
    The schema in the specified format
"""

    @mcp.tool(description=schema_doc)
    def get_schema(compact: bool = True) -> Union[Dict[str, Any], List[Dict[str, Any]]]:
        return sparql_server.query_schema(compact=compact)

    description_doc = """
Get a description and other metadata about the endpoint, including the PI, funding information, and more.

Returns:
    A string containing either:
      - Registry page content prefixed with a header line identifying the registry source, OR
      - The static/server-provided description when no registry URL applies.
"""

    @mcp.tool(description=description_doc)
    def get_description() -> str:
        return sparql_server.build_description()

    # Run MCP server over stdio
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()