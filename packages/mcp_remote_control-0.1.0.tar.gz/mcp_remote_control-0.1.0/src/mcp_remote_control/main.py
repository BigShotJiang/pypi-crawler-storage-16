def main():
    print("Hello from mcp-tv-control!")


if __name__ == "__main__":
    main()
