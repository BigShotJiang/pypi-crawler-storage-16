"""Farming analysis services."""

from .farming_service import FarmingService

__all__ = ["FarmingService"]
