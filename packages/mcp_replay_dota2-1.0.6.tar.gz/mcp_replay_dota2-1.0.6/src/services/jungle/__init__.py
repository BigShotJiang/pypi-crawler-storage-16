"""
Jungle analysis services.
"""

from .jungle_service import JungleService

__all__ = ["JungleService"]
