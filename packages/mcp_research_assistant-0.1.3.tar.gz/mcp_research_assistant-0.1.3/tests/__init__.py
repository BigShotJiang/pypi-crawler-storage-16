"""Tests for research-assistant-mcp package."""
