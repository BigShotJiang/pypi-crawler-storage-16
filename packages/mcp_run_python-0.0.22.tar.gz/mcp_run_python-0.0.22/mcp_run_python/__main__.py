"""This means `python -m mcp_run_python` should run the CLI."""

from ._cli import cli

if __name__ == '__main__':
    cli()
