import process from 'node:process'

// Stub `process.env` and always return an empty object
Object.defineProperty(process, 'env', {
  get() {
    return {}
  },
})
