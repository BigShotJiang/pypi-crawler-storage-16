# MCP Server Builder

[![PyPI version](https://img.shields.io/pypi/v/mcp-server-builder.svg)](https://pypi.org/project/mcp-server-builder/)
[![CI](https://github.com/praveenc/mcp-server-builder/actions/workflows/ci.yml/badge.svg)](https://github.com/praveenc/mcp-server-builder/actions/workflows/ci.yml)
[![Python 3.13+](https://img.shields.io/badge/python-3.13%2B-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Model Context Protocol (MCP) server for searching MCP protocol and FastMCP documentation.

This MCP server helps you build correct MCP servers by providing searchable access to the official MCP specification and FastMCP framework documentation, always reflecting the current state of the protocol.

## Features

- **BM25 Search** — Advanced full-text search with Porter stemming and n-gram indexing
- **Stop Word Removal** — 179 common English stop words filtered for better relevance
- **Domain Term Preservation** — MCP-specific terms (`mcp`, `json`, `rpc`, `stdio`) kept intact
- **Lazy Loading** — Fast startup with on-demand content fetching
- **Always Current** — Indexes live documentation from `llms.txt` sources on startup

## Data Sources

The server indexes documentation from these curated `llms.txt` sources:

| Source | Description |
|--------|-------------|
| [modelcontextprotocol.io/llms.txt](https://modelcontextprotocol.io/llms.txt) | Official MCP protocol specification |
| [gofastmcp.com/llms.txt](https://gofastmcp.com/llms.txt) | FastMCP Python framework documentation |

## Prerequisites

1. Install `uv` from [Astral](https://docs.astral.sh/uv/getting-started/installation/)
2. Install Python 3.13 or newer using `uv python install 3.13`

## Installation

Configure in your MCP client:

```json
{
  "mcpServers": {
    "mcp-server-builder": {
      "command": "uvx",
      "args": ["mcp-server-builder@latest"],
      "disabled": false,
      "autoApprove": []
    }
  }
}
```

**Config file locations:**

- **Claude Desktop (macOS)**: `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Claude Desktop (Windows)**: `%APPDATA%\Claude\claude_desktop_config.json`
- **Windsurf**: `~/.codeium/windsurf/mcp_config.json`
- **Kiro**: `.kiro/settings/mcp.json` in your project

### Install from PyPI

```bash
# Using uv
uv add mcp-server-builder

# Using pip
pip install mcp-server-builder
```

## Basic Usage

Example prompts to try:

- "How do I define tools in FastMCP?"
- "What is the MCP lifecycle?"
- "Show me stdio transport configuration"
- "How to handle tool errors in MCP?"
- "What are MCP resources and how do I use them?"

## Available Tools

### `search_mcp_docs`

Search MCP protocol AND FastMCP framework documentation with ranked results and snippets.

```python
search_mcp_docs(query: str, k: int = 5, source: str | None = None) -> list[dict]
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `query` | str | required | Search query (e.g., "tool input schema", "stdio transport") |
| `k` | int | 5 | Maximum number of results to return |
| `source` | str \| None | None | Optional filter: `"mcp"` for protocol docs, `"fastmcp"` for framework docs |

**Returns:** List of results with `url`, `title`, `score`, `snippet`, and `source`.

**Examples:**

```python
# Search both sources
search_mcp_docs("how to define tools", k=3)

# Search only MCP protocol docs
search_mcp_docs("lifecycle", source="mcp")

# Search only FastMCP framework docs
search_mcp_docs("authentication", source="fastmcp")
```

### `fetch_mcp_doc`

Retrieve full documentation page content by URL from MCP protocol or FastMCP framework docs.

```python
fetch_mcp_doc(uri: str) -> dict
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `uri` | str | required | Document URL (http/https from supported domains) |

**Supported domains:** `modelcontextprotocol.io`, `gofastmcp.com`

**Returns:** Dictionary with `url`, `title`, `content`, `source` (or `error` on failure).

**Example:**

```python
# Fetch MCP protocol doc
fetch_mcp_doc("https://modelcontextprotocol.io/docs/concepts/tools")

# Fetch FastMCP framework doc
fetch_mcp_doc("https://gofastmcp.com/tutorials/tools")
```

## Workflow Example

**Step 1:** Search for relevant documentation

```python
search_mcp_docs("FastMCP tool decorator", k=5)
```

**Step 2:** Fetch full content of the most relevant result

```python
fetch_mcp_doc("https://gofastmcp.com/tutorials/tools")
```

## Architecture

```text
llms.txt URLs (MCP + FastMCP)
    ↓ startup
BM25 index with stemmed tokens + n-grams (titles only, fast)
    ↓ search request
Stem query → match unigrams/bigrams/trigrams → BM25 rank
    ↓ top-k
Lazy content hydration → snippet extraction
    ↓ response
{ url, title, score, snippet }
```

## Development

```bash
# Clone and install
git clone https://github.com/praveenc/mcp-server-builder.git
cd mcp-server-builder
uv sync --dev
source .venv/bin/activate

# Run tests
uv run pytest

# Run with MCP Inspector
npx @anthropic-ai/mcp-inspector uv run mcp-server-builder

# Linting and type checking
uv run ruff check src tests
uv run pyright
```

## License

MIT - see [LICENSE](LICENSE) for details.

## Contributing

Contributions welcome! Please open an issue or submit a pull request.

## Support

For issues and questions, use the [GitHub issue tracker](https://github.com/praveenc/mcp-server-builder/issues)
