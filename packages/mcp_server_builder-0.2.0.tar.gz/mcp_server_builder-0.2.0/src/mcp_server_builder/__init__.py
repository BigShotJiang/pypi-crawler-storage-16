"""MCP Server Builder - Search MCP protocol and FastMCP documentation."""

__version__ = "0.2.0"
