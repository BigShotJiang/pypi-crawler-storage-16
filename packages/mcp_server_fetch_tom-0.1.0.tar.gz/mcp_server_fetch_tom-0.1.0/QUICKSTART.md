# Quick Start Guide

Your own fetch MCP server has been created successfully!

## Directory Structure

```
fetch_mcp/
├── src/
│   └── mcp_server_fetch/
│       ├── __init__.py      # Entry point with CLI argument parsing
│       ├── __main__.py      # Module runner
│       └── server.py        # Main server implementation
├── pyproject.toml           # Project configuration and dependencies
├── .python-version          # Python version (3.11)
└── README.md               # Full documentation
```

## Installation

### Option 1: Using uv (Recommended)

```bash
# Install dependencies
uv pip install -e .

# Run the server
uv run mcp-server-fetch
```

### Option 2: Using pip

```bash
# Install in development mode
pip install -e .

# Run the server
python -m mcp_server_fetch
```

## Testing

Test the server using the MCP inspector:

```bash
npx @modelcontextprotocol/inspector uv run mcp-server-fetch
```

## What This Server Does

The fetch MCP server provides:
- **fetch** tool: Fetches URLs and converts HTML to markdown
- Configurable user-agent strings
- robots.txt compliance (optional)
- Proxy support
- Content truncation with pagination

## Configuration for Claude Desktop

Add this to your Claude config file:

```json
{
  "mcpServers": {
    "fetch": {
      "command": "uv",
      "args": ["run", "--directory", "/home/tom/fetch_mcp", "mcp-server-fetch"]
    }
  }
}
```

## Next Steps

1. Customize the server by editing `src/mcp_server_fetch/server.py`
2. Update `pyproject.toml` with your own name and details
3. Add new features or modify existing ones
4. Test with the MCP inspector

Happy coding!
