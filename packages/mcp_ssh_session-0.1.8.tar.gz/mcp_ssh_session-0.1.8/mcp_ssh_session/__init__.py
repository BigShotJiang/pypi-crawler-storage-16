"""MCP SSH Session server."""
from .server import mcp

__version__ = "0.1.0"
__all__ = ["mcp"]
