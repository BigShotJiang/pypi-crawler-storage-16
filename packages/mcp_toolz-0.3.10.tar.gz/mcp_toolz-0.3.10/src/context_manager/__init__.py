"""Context manager for saving and querying contexts."""
