"""MCP server for Claude Code providing context management, todo persistence, and AI second opinions."""
