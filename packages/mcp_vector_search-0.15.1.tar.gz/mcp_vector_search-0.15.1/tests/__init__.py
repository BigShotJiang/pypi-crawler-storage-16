"""Tests for MCP Vector Search."""
