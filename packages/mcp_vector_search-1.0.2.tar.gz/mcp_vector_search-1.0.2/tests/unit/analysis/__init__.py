"""Unit tests for analysis module."""
