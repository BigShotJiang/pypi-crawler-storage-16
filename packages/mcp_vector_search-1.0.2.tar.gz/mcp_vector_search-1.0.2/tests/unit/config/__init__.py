"""Unit tests for configuration modules."""
