"""MCP Worklog - 自动化工作日报服务"""

__version__ = "0.1.2"
