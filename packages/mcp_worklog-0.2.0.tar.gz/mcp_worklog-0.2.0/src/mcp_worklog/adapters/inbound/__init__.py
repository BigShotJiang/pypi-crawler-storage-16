"""入站适配器 - MCP Server 等驱动适配器"""
