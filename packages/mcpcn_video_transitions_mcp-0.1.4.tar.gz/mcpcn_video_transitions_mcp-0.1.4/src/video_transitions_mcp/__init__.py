"""
Video Transitions MCP Server

一个专注于视频进入和退出动画的 MCP 服务器，提供淡入淡出等过渡效果。
"""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

from .main import main

__all__ = ["main"]
