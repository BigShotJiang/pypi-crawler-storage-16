import asyncio
import json
import re
from typing import Any, Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.syntax import Syntax

from mcpctl.utils import call_tool_result_to_dict

from . import discover as discover_mod
from . import server as server_mod
from .registry import create_registry

app = typer.Typer(help="CLI for MCP servers")
console = Console()


def parse_arg_value(value: str, is_json: bool = False) -> Any:
    """Parse an argument value to its appropriate type.

    If is_json=True, parse as raw JSON.
    Otherwise, auto-detect: int, float, bool, null, or string.
    """
    if is_json:
        try:
            return json.loads(value)
        except json.JSONDecodeError as e:
            raise typer.BadParameter(f"Invalid JSON: {e}")

    # Empty string
    if value == "":
        return ""

    # Boolean
    if value == "true":
        return True
    if value == "false":
        return False

    # Null
    if value == "null":
        return None

    # Number: only if it looks like a clean number (no leading zeros except "0" or "0.x")
    # Leading zeros like "01234" stay as strings (zipcodes, etc.)
    if re.match(r'^-?(?:0|[1-9]\d*)$', value):
        return int(value)
    if re.match(r'^-?(?:0|[1-9]\d*)\.\d+$', value):
        return float(value)

    # Default: string
    return value


def parse_arg(arg: str) -> tuple[str, Any]:
    """Parse a CLI argument in key=value or key:=json format.

    Returns (key, parsed_value).
    """
    # Check for := (explicit JSON) first
    if ":=" in arg:
        k, v = arg.split(":=", 1)
        if not k:
            raise typer.BadParameter("arg must have a key before :=")
        return k, parse_arg_value(v, is_json=True)

    # Standard = separator
    if "=" not in arg:
        raise typer.BadParameter("arg must be key=value or key:=json")

    k, v = arg.split("=", 1)
    if not k:
        raise typer.BadParameter("arg must have a key before =")
    return k, parse_arg_value(v, is_json=False)

registry_app = typer.Typer(help="Registry operations")
app.add_typer(registry_app, name="registry")


def _get_registry():
    return create_registry()


@registry_app.command("list")
def registry_list():
    reg = _get_registry()
    items = asyncio.run(reg.list())
    for name, value in items.items():
        console.print(f"{name}: {value}")


@registry_app.command("add")
def registry_add(
    name: str,
    transport: str = typer.Option(..., help="http|stdio"),
    url: Optional[str] = None,
    cmd: Optional[str] = None,
    cmd_arg: Optional[list[str]] = typer.Option(
        None, help="Command args", shell_complete=None
    ),
    env: Optional[list[str]] = typer.Option(None, help="ENV in KEY=VAL"),
    cwd: Optional[str] = None,
    bearer_env: Optional[str] = None,
    oauth: bool = False,
):
    reg = _get_registry()
    env_dict = None
    if env:
        env_dict = {}
        for item in env:
            if "=" not in item:
                raise typer.BadParameter("ENV must be KEY=VAL")
            k, v = item.split("=", 1)
            env_dict[k] = v
    value = {
        "transport": transport,
        "url": url,
        "cmd": cmd,
        "cmd_args": cmd_arg,
        "env": env_dict,
        "cwd": cwd,
        "bearer_env": bearer_env,
        "oauth": oauth,
    }
    asyncio.run(reg.set(name, value))
    console.print(f"Added {name}")


@registry_app.command("show")
def registry_show(name: str, json_out: bool = False):
    reg = _get_registry()
    value = asyncio.run(reg.get(name))
    if value is None:
        raise typer.Exit(code=1)
    if json_out:
        console.print_json(data=value)
    else:
        console.print(value)


@registry_app.command("delete")
def registry_delete(name: str):
    reg = _get_registry()
    asyncio.run(reg.delete(name))
    console.print(f"Deleted {name}")


@app.command("discover")
def discover(
    query: str, mode: str = typer.Option("pattern", help="pattern|regex|semantic")
):
    names = asyncio.run(discover_mod.discover(query, mode))
    for n in names:
        console.print(n)


@app.command()
def ping(server: str):
    reg = _get_registry()
    entry = asyncio.run(reg.get(server))
    if not entry:
        raise typer.BadParameter("Unknown server")
    asyncio.run(server_mod.ping(entry, token_store=reg.store))
    console.print("ok")


def _require_entry(server: str):
    reg = _get_registry()
    entry = asyncio.run(reg.get(server))
    if not entry:
        raise typer.BadParameter("Unknown server")
    return entry


def _print_tool_details(tool):
    """Print detailed info for a single tool."""
    from rich.text import Text

    # Header with name and description
    title = f"[bold cyan]{tool.name}[/bold cyan]"
    if tool.title:
        title += f" ({tool.title})"

    console.print(Panel(title, title="Tool", border_style="cyan"))

    if tool.description:
        console.print(f"\n[bold]Description:[/bold] {tool.description}\n")

    # Input schema
    if tool.inputSchema:
        console.print("[bold]Input Schema:[/bold]")
        schema = tool.inputSchema
        props = schema.get("properties", {})
        required = schema.get("required", [])

        if props:
            table = Table(show_header=True, header_style="bold magenta")
            table.add_column("Parameter")
            table.add_column("Type")
            table.add_column("Required")
            table.add_column("Description")

            for name, spec in props.items():
                param_type = spec.get("type", "any")
                # Handle type as list: ['string', 'null'] -> "string | null"
                if isinstance(param_type, list):
                    param_type = " | ".join(str(t) for t in param_type)
                elif "anyOf" in spec:
                    types = [t.get("type", "?") for t in spec["anyOf"] if t.get("type")]
                    param_type = " | ".join(str(t) for t in types)
                is_req = "✓" if name in required else ""
                desc = spec.get("description", "")
                table.add_row(name, str(param_type), is_req, desc)

            console.print(table)
        else:
            console.print("  [dim]No parameters[/dim]")

        # Show full schema as JSON
        console.print("\n[bold]Full inputSchema:[/bold]")
        console.print(Syntax(json.dumps(schema, indent=2), "json", theme="monokai"))

    # Output schema
    if tool.outputSchema:
        console.print("\n[bold]Output Schema:[/bold]")
        console.print(Syntax(json.dumps(tool.outputSchema, indent=2), "json", theme="monokai"))

    # Annotations
    if tool.annotations:
        console.print("\n[bold]Annotations:[/bold]")
        console.print(tool.annotations)


@app.command()
def tools(server: str, tool_name: Optional[str] = typer.Argument(None), json_out: bool = False):
    """List tools or show details for a specific tool."""
    entry = _require_entry(server)
    reg = _get_registry()
    all_tools = asyncio.run(server_mod.list_tools(entry, token_store=reg.store))
    if not all_tools:
        if tool_name:
            console.print(f"[red]Tool '{tool_name}' not found[/red]", style="bold")
            raise typer.Exit(code=1)
        if json_out:
            console.print_json(data=[])
        return

    if tool_name:
        # Find specific tool
        tool = next((t for t in all_tools if t.name == tool_name), None)
        if not tool:
            console.print(f"[red]Tool '{tool_name}' not found[/red]", style="bold")
            raise typer.Exit(code=1)
        if json_out:
            console.print_json(data=tool.model_dump())
        else:
            _print_tool_details(tool)
    else:
        # List all tools
        if json_out:
            console.print_json(data=[t.model_dump() for t in all_tools])
        else:
            table = Table(title=f"{server} tools")
            table.add_column("Name")
            table.add_column("Description")
            for t in all_tools:
                table.add_row(t.name, t.description or "")
            console.print(table)


@app.command("tools-call")
def tools_call(
    server: str,
    tool: str,
    arg: Optional[list[str]] = typer.Option(None, help="key=value or key:=json"),
):
    entry = _require_entry(server)
    reg = _get_registry()
    args = {}
    if arg:
        for item in arg:
            k, v = parse_arg(item)
            args[k] = v
    result = asyncio.run(server_mod.call_tool(entry, tool, args, token_store=reg.store))
    console.print()
    output = call_tool_result_to_dict(result)
    if isinstance(output, (dict, list)):
        console.print_json(data=output)
    else:
        console.print(output)


@app.command("call")
def call(
    server: str,
    tool: str,
    arg: Optional[list[str]] = typer.Option(None, help="key=value"),
):
    """
    Invoke a tool on a server (alias for tools-call).
    Kept for CLI parity with tests and to provide a shorter name.
    """
    tools_call(server=server, tool=tool, arg=arg)


@app.command()
def resources(
    server: str, list: bool = False, templates: bool = False, uri: Optional[str] = None
):
    entry = _require_entry(server)
    reg = _get_registry()
    if list:
        res = asyncio.run(server_mod.list_resources(entry, token_store=reg.store))
        if not res:
            console.print("[]")
            return
        console.print([r.model_dump() for r in res])
    elif templates:
        res = asyncio.run(
            server_mod.list_resource_templates(entry, token_store=reg.store)
        )
        if not res:
            console.print("[]")
            return
        console.print_json(data=[r.model_dump() for r in res])
    elif uri:
        content = asyncio.run(
            server_mod.read_resource(entry, uri, token_store=reg.store)
        )
        console.print(content)
    else:
        raise typer.BadParameter("Provide --list or --templates or --uri")


@app.command()
def prompts(server: str, list: bool = False, name: Optional[str] = None):
    entry = _require_entry(server)
    reg = _get_registry()
    if list:
        res = asyncio.run(server_mod.list_prompts(entry, token_store=reg.store))
        if not res:
            console.print([])
            return
        console.print([r.model_dump() for r in res])
    elif name:
        res = asyncio.run(server_mod.get_prompt(entry, name, token_store=reg.store))
        if not res:
            console.print("[]")
            return
        console.print(res.model_dump())
    else:
        raise typer.BadParameter("Provide --list or --name")


@app.command()
def auth(server: str):
    entry = _require_entry(server)
    if not entry.get("oauth"):
        raise typer.BadParameter("Server not configured for OAuth")
    # persistent token storage: reuse registry store so tokens survive restarts
    reg = _get_registry()

    # force OAuth registration by initializing transport; a ping triggers auth flow
    async def do_auth():
        async with server_mod._make_client(entry, token_store=reg.store) as client:
            await client.ping()

    asyncio.run(do_auth())
    console.print("logged in")


if __name__ == "__main__":
    app()
