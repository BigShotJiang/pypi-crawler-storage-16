import asyncio
from typing import List
import typer
from rich.table import Table
from rich.console import Console

from .registry import create_registry
from . import server as server_mod

console = Console()


def format_tools(tools):
    table = Table(title="Tools")
    table.add_column("Name")
    table.add_column("Description")
    for t in tools:
        if t is None:
            continue
        table.add_row(t.name, t.description or "")
    console.print(table)


async def _discover_for_entry(entry, store, query: str, mode: str):
    async def do_discover(client):
        return await client.discover(query, mode=mode)

    return await server_mod._run_with_client(entry, store, do_discover)


async def discover(query: str, mode: str = "pattern") -> List[str]:
    """Discover tools across all registered servers.

    Returns unique tool names preserving first-seen order.
    """
    registry = create_registry()
    entries = await registry.list()
    if not entries:
        return []

    names: List[str] = []
    seen = set()

    store = registry.store
    for entry in entries.values():
        try:
            tools = await _discover_for_entry(entry, store, query, mode)
        except Exception:
            # skip servers that fail discovery
            continue
        for tool in tools or []:
            if tool is None:
                continue
            if tool.name in seen:
                continue
            seen.add(tool.name)
            names.append(tool.name)
    return names


def discover_command(query: str, mode: str = typer.Option("pattern", help="pattern|regex|semantic")):
    names = asyncio.run(discover(query, mode))
    for n in names:
        console.print(n)
