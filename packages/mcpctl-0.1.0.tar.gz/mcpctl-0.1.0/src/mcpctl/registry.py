import os
from typing import Optional, Dict, Any, List
from dataclasses import dataclass

from key_value.aio.protocols.key_value import AsyncKeyValue
from key_value.aio.stores.memory.store import MemoryStore
from key_value.aio.stores.disk.store import DiskStore


@dataclass
class ServerEntry:
    name: str
    transport: str
    url: Optional[str] = None
    cmd: Optional[str] = None
    cmd_args: Optional[list[str]] = None
    env: Optional[Dict[str, str]] = None
    cwd: Optional[str] = None
    bearer_env: Optional[str] = None
    oauth: bool = False


class Registry:
    def __init__(self, store: AsyncKeyValue):
        self.store = store
        self._key_index = "__registry_keys__"

    async def list(self):
        keys = await self._load_keys()
        values = await self.store.get_many(keys) if hasattr(self.store, "get_many") else []
        result = {}
        if values:
            for k, v in zip(keys, values):
                if v is not None:
                    result[k] = v
            return result
        # fallback fetch individually
        for k in keys:
            v = await self.store.get(k)
            if v is not None:
                result[k] = v
        return result

    async def get(self, name: str):
        return await self.store.get(name)

    async def set(self, name: str, value: Dict[str, Any]):
        await self.store.put(name, value)
        keys = await self._load_keys()
        if name not in keys:
            keys.append(name)
            await self.store.put(self._key_index, {"keys": keys})

    async def delete(self, name: str):
        await self.store.delete(name)
        keys = await self._load_keys()
        if name in keys:
            keys.remove(name)
            await self.store.put(self._key_index, {"keys": keys})

    async def _load_keys(self) -> List[str]:
        index = await self.store.get(self._key_index)
        if index and "keys" in index:
            return list(index["keys"])
        return []


def get_registry_store() -> AsyncKeyValue:
    path = os.getenv("MCPCTL_REGISTRY_DISK_PATH")
    if path:
        return DiskStore(directory=path)
    url = os.getenv("MCPCTL_REGISTRY_REDIS_URL")
    if url:
        try:
            from key_value.aio.stores.redis.store import RedisStore  # optional dependency
            from redis.asyncio import Redis
            parsed = None
            ssl = False
            try:
                from urllib.parse import urlparse
                parsed = urlparse(url)
                ssl = parsed.scheme == "rediss"
            except Exception:
                parsed = None
            if parsed:
                client = Redis(
                    host=parsed.hostname or "localhost",
                    port=parsed.port or 6379,
                    db=int(parsed.path.lstrip("/")) if parsed.path and parsed.path != "/" else 0,
                    password=parsed.password,
                    ssl=ssl,
                    ssl_cert_reqs=None if ssl else None,
                    decode_responses=True,
                )
                return RedisStore(client=client)
            return RedisStore(url=url)
        except ImportError:
            # fallback to memory when redis extra is missing
            pass
    return MemoryStore()


def create_registry() -> Registry:
    return Registry(get_registry_store())
