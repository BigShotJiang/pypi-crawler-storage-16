from datetime import timedelta
from typing import Any, Dict, Callable, Awaitable
from fastmcp.tools.tool import CallToolResult
import typer
from rich.console import Console
from fastmcp.client import Client, OAuth, BearerAuth
from fastmcp.client.transports import StreamableHttpTransport, StdioTransport
from key_value.aio.protocols.key_value import AsyncKeyValue
from .registry import create_registry

console = Console()


def _resolve_store(token_store: AsyncKeyValue | None) -> AsyncKeyValue:
    """Use provided token store or fall back to the registry store."""
    if token_store is not None:
        return token_store
    return create_registry().store


def _make_client(entry: Dict[str, Any], token_store: AsyncKeyValue | None = None) -> Client:
    transport = entry["transport"]
    if transport == "http":
        url = entry["url"]
        auth = None
        if entry.get("oauth"):
            auth = OAuth(url, token_storage=_resolve_store(token_store))
        elif entry.get("bearer_env"):
            import os
            token = os.getenv(entry["bearer_env"])
            if token:
                auth = BearerAuth(token)
        transport_obj = StreamableHttpTransport(url=url, auth=auth)
        return Client(transport_obj, init_timeout=timedelta(seconds=60))
    elif transport == "stdio":
        import shlex

        cmd = entry["cmd"]
        args = entry.get("cmd_args") or []
        # If the command string contains whitespace and no explicit args were provided,
        # split it so "npx my-mcp" works the same as cmd="npx", cmd_args=["my-mcp"].
        if isinstance(cmd, str) and (not args) and (" " in cmd or "\t" in cmd):
            parts = shlex.split(cmd)
            if parts:
                cmd, *args = parts
        transport_obj = StdioTransport(
            command=cmd,
            args=args,
            env=entry.get("env"),
            cwd=entry.get("cwd"),
        )
        return Client(transport_obj, init_timeout=timedelta(seconds=60))
    else:
        raise typer.BadParameter("Unknown transport")


def _is_unauthorized(exc: Exception) -> bool:
    status = getattr(exc, "status_code", None)
    if status == 401:
        return True
    msg = str(exc)
    return "401" in msg or "unauthorized" in msg.lower()


async def _clear_auth_tokens(auth: Any):
    adapter = getattr(auth, "token_storage_adapter", None)
    if adapter and hasattr(adapter, "clear"):
        try:
            await adapter.clear()
        except Exception:
            pass


async def _run_with_client(entry: Dict[str, Any], token_store: AsyncKeyValue | None, func: Callable[[Client], Awaitable[Any]]):
    store = _resolve_store(token_store)
    last_auth = None

    async def run_once():
        nonlocal last_auth
        client = _make_client(entry, token_store=store)
        last_auth = getattr(getattr(client, "transport", None), "auth", None)
        async with client as c:
            result = await func(c)
        last_auth = getattr(getattr(client, "transport", None), "auth", last_auth)
        return result

    for attempt in (1, 2):
        try:
            return await run_once()
        except Exception as exc:
            is_auth_error = _is_unauthorized(exc)
            loop_closed = "event loop is closed" in str(exc).lower()
            if attempt == 1 and (is_auth_error or loop_closed):
                # clear stored tokens and retry once on auth errors or loop-closed transient errors
                await _clear_auth_tokens(last_auth)
                continue
            raise


async def ping(entry: Dict[str, Any], token_store: AsyncKeyValue | None = None):
    await _run_with_client(entry, token_store, lambda client: client.ping())


async def list_tools(entry: Dict[str, Any], token_store: AsyncKeyValue | None = None):
    return await _run_with_client(entry, token_store, lambda client: client.list_tools())


async def call_tool(entry: Dict[str, Any], tool: str, args: Dict[str, Any], token_store: AsyncKeyValue | None = None) -> CallToolResult:
    return await _run_with_client(entry, token_store, lambda client: client.call_tool(tool, args))


async def list_resources(entry: Dict[str, Any], token_store: AsyncKeyValue | None = None):
    return await _run_with_client(entry, token_store, lambda client: client.list_resources())


async def list_resource_templates(entry: Dict[str, Any], token_store: AsyncKeyValue | None = None):
    return await _run_with_client(entry, token_store, lambda client: client.list_resource_templates())


async def read_resource(entry: Dict[str, Any], uri: str, token_store: AsyncKeyValue | None = None):
    return await _run_with_client(entry, token_store, lambda client: client.read_resource(uri))


async def list_prompts(entry: Dict[str, Any], token_store: AsyncKeyValue | None = None):
    return await _run_with_client(entry, token_store, lambda client: client.list_prompts())


async def get_prompt(entry: Dict[str, Any], name: str, token_store: AsyncKeyValue | None = None):
    return await _run_with_client(entry, token_store, lambda client: client.get_prompt(name))
