import json
from typing import Any

from mcp.types import BlobResourceContents, CallToolResult


def call_tool_result_to_dict(result: CallToolResult) -> dict | str | list | Any:
    """Return a JSON-safe dict from CallToolResult or plain dict.

    - If `result` provides `model_dump`, use that (Pydantic models).
    - If `result` is already a dict, return it untouched.
    - Otherwise fall back to `__dict__` to keep best-effort serialization.
    """
    output: list[dict] = []
    for i, content in enumerate(result.content):
        match content.type:
            case "text":
                try:
                    output.append(json.loads(content.text))
                except Exception:
                    output.append(content.text)
            case "image":
                output.append({"image": content.data, "mimeType": content.mimeType})
            case "audio":
                output.append({"audio": content.data, "mimeType": content.mimeType})
            case "resource":
                resource = content.resource
                if type(resource) is BlobResourceContents:
                    output.append(
                        {"blob": resource.blob, "mimeType": resource.mimeType}
                    )
                else:
                    output.append(resource.text)
            case "resource_link":
                output.append({"uri": str(content.uri)})

    return output if len(output) > 1 else output[0]
