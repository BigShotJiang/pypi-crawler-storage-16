"""Tests for CLI argument type coercion feature.

Tests the parse_arg_value() and parse_arg() functions that automatically
parse --arg values to appropriate types (int, float, bool, null, str)
with support for explicit JSON mode via := separator.

Test cases from features.json: ARG001-ARG016
"""

import pytest
import json


def test_parse_arg_value_auto_parse_integer():
    """ARG001: Auto-parse integer from string."""
    from mcpctl.cli import parse_arg_value

    result = parse_arg_value("5", is_json=False)
    assert result == 5
    assert isinstance(result, int)


def test_parse_arg_value_auto_parse_negative_integer():
    """ARG002: Auto-parse negative integer."""
    from mcpctl.cli import parse_arg_value

    result = parse_arg_value("-10", is_json=False)
    assert result == -10
    assert isinstance(result, int)


def test_parse_arg_value_auto_parse_float():
    """ARG003: Auto-parse float."""
    from mcpctl.cli import parse_arg_value

    result = parse_arg_value("3.14", is_json=False)
    assert result == 3.14
    assert isinstance(result, float)


def test_parse_arg_value_auto_parse_boolean_true():
    """ARG004: Auto-parse boolean true."""
    from mcpctl.cli import parse_arg_value

    result = parse_arg_value("true", is_json=False)
    assert result is True
    assert isinstance(result, bool)


def test_parse_arg_value_auto_parse_boolean_false():
    """ARG005: Auto-parse boolean false."""
    from mcpctl.cli import parse_arg_value

    result = parse_arg_value("false", is_json=False)
    assert result is False
    assert isinstance(result, bool)


def test_parse_arg_value_auto_parse_null():
    """ARG006: Auto-parse null."""
    from mcpctl.cli import parse_arg_value

    result = parse_arg_value("null", is_json=False)
    assert result is None


def test_parse_arg_value_plain_string_stays_string():
    """ARG007: Plain string stays string."""
    from mcpctl.cli import parse_arg_value

    result = parse_arg_value("hello", is_json=False)
    assert result == "hello"
    assert isinstance(result, str)


def test_parse_arg_value_string_with_spaces():
    """ARG008: String with spaces stays string."""
    from mcpctl.cli import parse_arg_value

    result = parse_arg_value("go to google", is_json=False)
    assert result == "go to google"
    assert isinstance(result, str)


def test_parse_arg_value_explicit_json_object():
    """ARG009: Explicit JSON object with is_json=True."""
    from mcpctl.cli import parse_arg_value

    result = parse_arg_value('{"timeout": 30}', is_json=True)
    assert result == {"timeout": 30}
    assert isinstance(result, dict)


def test_parse_arg_value_explicit_json_array():
    """ARG010: Explicit JSON array with is_json=True."""
    from mcpctl.cli import parse_arg_value

    result = parse_arg_value('["a", "b"]', is_json=True)
    assert result == ["a", "b"]
    assert isinstance(result, list)


def test_parse_arg_value_force_string_with_json_mode():
    """ARG011: Force string with is_json=True using quoted string."""
    from mcpctl.cli import parse_arg_value

    result = parse_arg_value('"5"', is_json=True)
    assert result == "5"
    assert isinstance(result, str)


def test_parse_arg_value_leading_zero_stays_string():
    """ARG012: String with leading zero stays string (not octal)."""
    from mcpctl.cli import parse_arg_value

    result = parse_arg_value("01234", is_json=False)
    assert result == "01234"
    assert isinstance(result, str)


def test_parse_arg_value_empty_string():
    """ARG013: Empty string."""
    from mcpctl.cli import parse_arg_value

    result = parse_arg_value("", is_json=False)
    assert result == ""
    assert isinstance(result, str)


def test_parse_arg_value_url_stays_string():
    """ARG014: URL stays string."""
    from mcpctl.cli import parse_arg_value

    result = parse_arg_value("https://example.com", is_json=False)
    assert result == "https://example.com"
    assert isinstance(result, str)


def test_parse_arg_value_invalid_json_raises_error():
    """ARG016: Invalid JSON with is_json=True raises error."""
    from click.exceptions import BadParameter
    from mcpctl.cli import parse_arg_value

    with pytest.raises(BadParameter) as exc_info:
        parse_arg_value("{not valid json}", is_json=True)

    assert "Invalid JSON" in str(exc_info.value)


def test_parse_arg_value_various_numeric_formats():
    """Test various numeric formats with auto-parsing."""
    from mcpctl.cli import parse_arg_value

    # Test zero
    assert parse_arg_value("0", is_json=False) == 0

    # Test positive integer
    assert parse_arg_value("42", is_json=False) == 42

    # Test negative float
    assert parse_arg_value("-3.14", is_json=False) == -3.14

    # Test float with leading zero
    assert parse_arg_value("0.5", is_json=False) == 0.5


def test_parse_arg_value_case_sensitive_booleans():
    """Test that boolean parsing is case-sensitive (only 'true'/'false' lowercase)."""
    from mcpctl.cli import parse_arg_value

    # Only lowercase should be parsed as booleans
    assert parse_arg_value("True", is_json=False) == "True"  # stays string
    assert parse_arg_value("FALSE", is_json=False) == "FALSE"  # stays string
    assert parse_arg_value("true", is_json=False) is True  # parsed as bool
    assert parse_arg_value("false", is_json=False) is False  # parsed as bool


def test_parse_arg_value_case_sensitive_null():
    """Test that null parsing is case-sensitive (only 'null' lowercase)."""
    from mcpctl.cli import parse_arg_value

    assert parse_arg_value("null", is_json=False) is None  # parsed
    assert parse_arg_value("Null", is_json=False) == "Null"  # stays string
    assert parse_arg_value("NULL", is_json=False) == "NULL"  # stays string


def test_parse_arg_value_json_true_false():
    """Test that JSON mode can parse True/False variants."""
    from mcpctl.cli import parse_arg_value

    # JSON mode should handle standard JSON booleans
    assert parse_arg_value("true", is_json=True) is True
    assert parse_arg_value("false", is_json=True) is False


def test_parse_arg_split_key_value_with_equals():
    """Test parse_arg() splitting on = sign."""
    from mcpctl.cli import parse_arg

    key, value = parse_arg("maxSteps=5")
    assert key == "maxSteps"
    assert value == 5


def test_parse_arg_split_key_value_with_colon_equals():
    """Test parse_arg() splitting on := sign for JSON mode."""
    from mcpctl.cli import parse_arg

    key, value = parse_arg('config:={"timeout": 30}')
    assert key == "config"
    assert value == {"timeout": 30}


def test_parse_arg_multiple_equals_takes_first():
    """Test parse_arg() with multiple = signs (first is separator)."""
    from mcpctl.cli import parse_arg

    key, value = parse_arg("equation=a=b+c")
    assert key == "equation"
    assert value == "a=b+c"


def test_parse_arg_multiple_colon_equals():
    """Test parse_arg() with multiple := (first is separator)."""
    from mcpctl.cli import parse_arg

    # This is a JSON mode test - the value contains the := pattern
    key, value = parse_arg('data:={"formula": "a:=b"}')
    assert key == "data"
    assert value == {"formula": "a:=b"}


def test_parse_arg_no_separator_raises_error():
    """Test parse_arg() raises error when no = or := found."""
    from click.exceptions import BadParameter
    from mcpctl.cli import parse_arg

    with pytest.raises(BadParameter) as exc_info:
        parse_arg("no_separator_here")

    error_msg = str(exc_info.value)
    assert "=" in error_msg


def test_parse_arg_empty_key_with_equals():
    """Test parse_arg() raises error with empty key."""
    from click.exceptions import BadParameter
    from mcpctl.cli import parse_arg

    with pytest.raises(BadParameter):
        parse_arg("=value")


def test_parse_arg_empty_value_with_equals():
    """Test parse_arg() with empty value (ARG013 via parse_arg)."""
    from mcpctl.cli import parse_arg

    key, value = parse_arg("empty=")
    assert key == "empty"
    assert value == ""


def test_parse_arg_string_value_with_equals():
    """Test parse_arg() parsing string value."""
    from mcpctl.cli import parse_arg

    key, value = parse_arg("name=hello")
    assert key == "name"
    assert value == "hello"
    assert isinstance(value, str)


def test_parse_arg_integer_value_with_equals():
    """Test parse_arg() parsing integer value."""
    from mcpctl.cli import parse_arg

    key, value = parse_arg("count=10")
    assert key == "count"
    assert value == 10
    assert isinstance(value, int)


def test_parse_arg_boolean_value_with_equals():
    """Test parse_arg() parsing boolean value."""
    from mcpctl.cli import parse_arg

    key, value = parse_arg("verbose=true")
    assert key == "verbose"
    assert value is True


def test_parse_arg_array_with_colon_equals():
    """Test parse_arg() parsing array with := operator."""
    from mcpctl.cli import parse_arg

    key, value = parse_arg('tags:=["a", "b"]')
    assert key == "tags"
    assert value == ["a", "b"]
    assert isinstance(value, list)


def test_parse_arg_quoted_string_with_colon_equals():
    """Test parse_arg() forcing string with := (ARG011)."""
    from mcpctl.cli import parse_arg

    key, value = parse_arg('port:="5"')
    assert key == "port"
    assert value == "5"
    assert isinstance(value, str)


def test_parse_arg_value_whitespace_handling():
    """Test that whitespace in values is preserved."""
    from mcpctl.cli import parse_arg_value

    # Leading/trailing spaces should be preserved
    result = parse_arg_value("  spaces  ", is_json=False)
    assert result == "  spaces  "


def test_parse_arg_value_special_characters():
    """Test values with special characters."""
    from mcpctl.cli import parse_arg_value

    special_values = [
        "hello@world.com",
        "path/to/file",
        "value_with_underscore",
        "value-with-dash",
        "value.with.dots",
    ]

    for val in special_values:
        result = parse_arg_value(val, is_json=False)
        assert result == val


def test_parse_arg_value_json_nested_structures():
    """Test JSON mode with nested structures."""
    from mcpctl.cli import parse_arg_value

    json_str = '{"nested": {"key": "value", "numbers": [1, 2, 3]}}'
    result = parse_arg_value(json_str, is_json=True)

    assert result == {"nested": {"key": "value", "numbers": [1, 2, 3]}}
    assert result["nested"]["key"] == "value"
    assert result["nested"]["numbers"] == [1, 2, 3]


def test_parse_arg_value_json_null_in_json_mode():
    """Test null in JSON mode."""
    from mcpctl.cli import parse_arg_value

    result = parse_arg_value("null", is_json=True)
    assert result is None


def test_parse_arg_value_json_boolean_in_json_mode():
    """Test booleans in JSON mode."""
    from mcpctl.cli import parse_arg_value

    assert parse_arg_value("true", is_json=True) is True
    assert parse_arg_value("false", is_json=True) is False


def test_parse_arg_value_json_number_in_json_mode():
    """Test numbers in JSON mode."""
    from mcpctl.cli import parse_arg_value

    assert parse_arg_value("42", is_json=True) == 42
    assert parse_arg_value("3.14", is_json=True) == 3.14


def test_parse_arg_value_json_string_in_json_mode():
    """Test strings in JSON mode (must be quoted)."""
    from mcpctl.cli import parse_arg_value

    result = parse_arg_value('"hello"', is_json=True)
    assert result == "hello"
    assert isinstance(result, str)


def test_parse_arg_value_json_unquoted_string_fails():
    """Test that unquoted strings fail in JSON mode."""
    from click.exceptions import BadParameter
    from mcpctl.cli import parse_arg_value

    # In JSON mode, unquoted 'hello' is invalid JSON
    with pytest.raises(BadParameter):
        parse_arg_value("hello", is_json=True)


def test_parse_arg_value_scientific_notation():
    """Test scientific notation stays as string in auto-mode (not supported)."""
    from mcpctl.cli import parse_arg_value

    # Scientific notation is not auto-parsed, stays as string
    result = parse_arg_value("1e-5", is_json=False)
    assert result == "1e-5"
    assert isinstance(result, str)


def test_parse_arg_value_hex_stays_string():
    """Test that hex notation stays as string in auto-mode."""
    from mcpctl.cli import parse_arg_value

    result = parse_arg_value("0xFF", is_json=False)
    assert result == "0xFF"
    assert isinstance(result, str)


def test_parse_arg_colon_equals_priority():
    """Test that := is checked before = for separation."""
    from mcpctl.cli import parse_arg

    # This should use := as separator, not =
    key, value = parse_arg('data:=[1, 2, 3]')
    assert key == "data"
    assert value == [1, 2, 3]


def test_parse_arg_value_float_no_decimal():
    """Test that numbers without decimals become integers."""
    from mcpctl.cli import parse_arg_value

    result = parse_arg_value("100", is_json=False)
    assert result == 100
    assert isinstance(result, int)
    assert not isinstance(result, float)


def test_parse_arg_value_float_with_decimal():
    """Test that numbers with decimals become floats."""
    from mcpctl.cli import parse_arg_value

    result = parse_arg_value("100.0", is_json=False)
    assert result == 100.0
    assert isinstance(result, float)


# Integration tests combining multiple features

def test_arg_parsing_integration_multiple_types():
    """Integration test: parse multiple arguments with different types (ARG015)."""
    from mcpctl.cli import parse_arg

    args = [
        "task=search",
        "count=10",
        "verbose=true",
    ]

    results = {}
    for arg in args:
        key, value = parse_arg(arg)
        results[key] = value

    assert results == {"task": "search", "count": 10, "verbose": True}


def test_arg_parsing_integration_json_and_auto():
    """Integration test: mixing auto-parsed and JSON arguments."""
    from mcpctl.cli import parse_arg

    auto_arg = parse_arg("port=8080")
    json_arg = parse_arg('config:={"timeout": 30}')

    assert auto_arg == ("port", 8080)
    assert json_arg == ("config", {"timeout": 30})


def test_arg_parsing_integration_edge_cases():
    """Integration test: edge cases and tricky values."""
    from mcpctl.cli import parse_arg

    # Value that looks like JSON but is auto-parsed
    key, value = parse_arg("text={not json}")
    assert key == "text"
    assert value == "{not json}"
    assert isinstance(value, str)

    # Value with special meaning in JSON
    key, value = parse_arg("special=true-ish")
    assert key == "special"
    assert value == "true-ish"  # Not parsed as boolean

    # Very long string
    key, value = parse_arg("data=" + "x" * 1000)
    assert key == "data"
    assert len(value) == 1000


def test_parse_arg_value_boolean_edge_cases():
    """Test edge cases for boolean parsing."""
    from mcpctl.cli import parse_arg_value

    # Must be exact match
    assert parse_arg_value("truee", is_json=False) == "truee"
    assert parse_arg_value("t rue", is_json=False) == "t rue"
    assert parse_arg_value("tru e", is_json=False) == "tru e"

    assert parse_arg_value("fals", is_json=False) == "fals"
    assert parse_arg_value("fal se", is_json=False) == "fal se"


def test_parse_arg_value_numeric_string_with_plus():
    """Test numeric string with explicit plus sign."""
    from mcpctl.cli import parse_arg_value

    result = parse_arg_value("+42", is_json=False)
    assert result == "+42"  # Plus sign makes it stay string
    assert isinstance(result, str)


def test_parse_arg_value_numeric_with_comma():
    """Test numeric format with comma stays string."""
    from mcpctl.cli import parse_arg_value

    result = parse_arg_value("1,000", is_json=False)
    assert result == "1,000"
    assert isinstance(result, str)


def test_parse_arg_value_octal_zero_prefix():
    """Test that octal notation (0xxx) stays string."""
    from mcpctl.cli import parse_arg_value

    result = parse_arg_value("0755", is_json=False)
    assert result == "0755"
    assert isinstance(result, str)
    assert result != 493  # not octal 755
