"""
Test suite for CallToolResult JSON serialization.

Spec: When calling a tool via CLI, the output must be valid JSON to stdout.
"""
import json
import pytest
from unittest.mock import AsyncMock, patch, MagicMock
from typer.testing import CliRunner
from mcp.types import CallToolResult, TextContent, ImageContent, EmbeddedResource, ResourceLink

from mcpctl.cli import app

runner = CliRunner()


# --- Serialization unit tests ---

def test_call_tool_result_text_content_serializes():
    """Test 1: Basic CallToolResult with TextContent serializes to dict."""
    result = CallToolResult(
        content=[TextContent(type="text", text="Hello, world!")],
        isError=False
    )
    data = result.model_dump()
    assert isinstance(data, dict)
    assert data["content"][0]["text"] == "Hello, world!"
    assert data["isError"] is False
    # Verify JSON serializable
    json_str = json.dumps(data)
    assert "Hello, world!" in json_str


def test_call_tool_result_error_flag_serializes():
    """Test 2: CallToolResult with isError=True serializes correctly."""
    result = CallToolResult(
        content=[TextContent(type="text", text="Error occurred")],
        isError=True
    )
    data = result.model_dump()
    assert data["isError"] is True
    json_str = json.dumps(data)
    parsed = json.loads(json_str)
    assert parsed["isError"] is True


def test_call_tool_result_multiple_content_items():
    """Test 3: CallToolResult with multiple content items serializes."""
    result = CallToolResult(
        content=[
            TextContent(type="text", text="First"),
            TextContent(type="text", text="Second"),
            TextContent(type="text", text="Third"),
        ],
        isError=False
    )
    data = result.model_dump()
    assert len(data["content"]) == 3
    json_str = json.dumps(data)
    parsed = json.loads(json_str)
    assert len(parsed["content"]) == 3


def test_call_tool_result_empty_content():
    """Test 4: CallToolResult with empty content list serializes."""
    result = CallToolResult(content=[], isError=False)
    data = result.model_dump()
    assert data["content"] == []
    json_str = json.dumps(data)
    parsed = json.loads(json_str)
    assert parsed["content"] == []


def test_call_tool_result_image_content():
    """Test 5: CallToolResult with ImageContent (base64) serializes."""
    result = CallToolResult(
        content=[
            ImageContent(type="image", data="aGVsbG8=", mimeType="image/png")
        ],
        isError=False
    )
    data = result.model_dump()
    assert data["content"][0]["type"] == "image"
    assert data["content"][0]["data"] == "aGVsbG8="
    json_str = json.dumps(data)
    assert "aGVsbG8=" in json_str


def test_call_tool_result_nested_pydantic_models():
    """Test 6: Nested Pydantic models in content serialize correctly."""
    result = CallToolResult(
        content=[
            TextContent(type="text", text="nested"),
        ],
        isError=False
    )
    data = result.model_dump()
    # The model_dump should recursively serialize all nested models
    assert isinstance(data["content"], list)
    assert isinstance(data["content"][0], dict)
    assert data["content"][0]["type"] == "text"


def test_call_tool_result_structured_content():
    """Test 9: CallToolResult with structuredContent field serializes."""
    result = CallToolResult(
        content=[TextContent(type="text", text="result")],
        structuredContent={"workouts": [{"id": "123", "name": "Upper 1"}]},
        isError=False
    )
    data = result.model_dump()
    assert data["structuredContent"]["workouts"][0]["id"] == "123"
    json_str = json.dumps(data)
    parsed = json.loads(json_str)
    assert parsed["structuredContent"]["workouts"][0]["name"] == "Upper 1"


# --- CLI integration tests ---

@pytest.fixture
def mock_registry(tmp_path, monkeypatch):
    """Setup mock registry with test server entry."""
    monkeypatch.setenv("MCPCTL_REGISTRY_DISK_PATH", str(tmp_path))
    # Add a test server
    result = runner.invoke(app, [
        "registry", "add", "testserver",
        "--transport", "http",
        "--url", "https://example.com"
    ])
    assert result.exit_code == 0
    return tmp_path


def test_cli_tools_call_outputs_valid_json(mock_registry, monkeypatch):
    """Test 7: CLI tools-call command outputs valid JSON."""
    mock_result = CallToolResult(
        content=[TextContent(type="text", text="CLI test output")],
        isError=False
    )

    with patch("mcpctl.server.call_tool", new_callable=AsyncMock) as mock_call:
        mock_call.return_value = mock_result
        result = runner.invoke(app, ["tools-call", "testserver", "test_tool"])

    assert result.exit_code == 0, f"Exit code was {result.exit_code}: {result.output}"
    # Output is the extracted content (text string in this case)
    assert result.output.strip() == "CLI test output"


def test_cli_call_alias_outputs_valid_json(mock_registry, monkeypatch):
    """Test 8: CLI call command (alias) outputs valid JSON."""
    mock_result = CallToolResult(
        content=[TextContent(type="text", text="Alias test")],
        isError=False
    )

    with patch("mcpctl.server.call_tool", new_callable=AsyncMock) as mock_call:
        mock_call.return_value = mock_result
        result = runner.invoke(app, ["call", "testserver", "test_tool"])

    assert result.exit_code == 0, f"Exit code was {result.exit_code}: {result.output}"
    # Output is the extracted content (text string in this case)
    assert result.output.strip() == "Alias test"


def test_cli_call_with_complex_nested_result(mock_registry, monkeypatch):
    """Test 10: Output matches spec - complex nested result as JSON to stdout."""
    # Simulate the actual error case from the bug report
    mock_result = CallToolResult(
        content=[
            TextContent(
                type="text",
                text='{"workouts": [{"id": "abc", "title": "Upper 1", "exercises": ["Bench", "Rows"]}]}'
            )
        ],
        structuredContent={
            "workouts": [
                {
                    "id": "abc",
                    "title": "Upper 1",
                    "routine_id": "def",
                    "exercises": ["Bench", "Rows"]
                }
            ]
        },
        isError=False
    )

    with patch("mcpctl.server.call_tool", new_callable=AsyncMock) as mock_call:
        mock_call.return_value = mock_result
        result = runner.invoke(app, ["call", "testserver", "list_workouts"])

    assert result.exit_code == 0, f"Failed with: {result.output}"
    # Output is parsed JSON content from text (call_tool_result_to_dict parses JSON strings)
    parsed = json.loads(result.output.strip())
    assert parsed["workouts"][0]["title"] == "Upper 1"


def test_cli_call_handles_call_tool_result_directly(mock_registry, monkeypatch):
    """Test that CallToolResult is properly serialized even if hasattr check fails."""
    mock_result = CallToolResult(
        content=[TextContent(type="text", text="Direct CallToolResult test")],
        isError=False
    )

    with patch("mcpctl.server.call_tool", new_callable=AsyncMock) as mock_call:
        mock_call.return_value = mock_result
        result = runner.invoke(app, ["call", "testserver", "test_tool"])

    assert result.exit_code == 0, f"Exit code was {result.exit_code}: {result.output}"
    # Output is the extracted content (text string in this case)
    assert result.output.strip() == "Direct CallToolResult test"
