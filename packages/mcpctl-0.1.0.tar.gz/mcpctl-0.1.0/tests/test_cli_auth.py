import pytest
from typer.testing import CliRunner
from mcpctl.cli import app

runner = CliRunner()


class FakeReg:
    def __init__(self):
        self.store = None

    async def get(self, name):
        return {"transport": "http", "url": "https://example.com", "oauth": True}


class FakeClient:
    """Client that requires async context to be considered connected."""

    def __init__(self):
        self.connected = False

    async def __aenter__(self):
        self.connected = True
        return self

    async def __aexit__(self, exc_type, exc, tb):
        self.connected = False

    async def ping(self):
        if not self.connected:
            raise RuntimeError("Client not connected")
        return None


def _setup_registry(monkeypatch):
    import mcpctl.cli as cli
    monkeypatch.setattr(cli, "_get_registry", lambda: FakeReg())


def test_auth_calls_ping(monkeypatch):
    # Arrange: registry entry with oauth
    monkeypatch.setenv("MCPCTL_REGISTRY_DISK_PATH", "/tmp/mcpctl-test-auth")

    _setup_registry(monkeypatch)

    # fake client that demands context manager
    import mcpctl.server as server
    monkeypatch.setattr(server, "_make_client", lambda entry, token_store=None: FakeClient())

    result = runner.invoke(app, ["auth", "one"])
    assert result.exit_code == 0
    assert "logged in" in result.output


def test_auth_uses_async_context(monkeypatch):
    """Regression test: auth should open the client session before pinging."""

    monkeypatch.setenv("MCPCTL_REGISTRY_DISK_PATH", "/tmp/mcpctl-test-auth")
    _setup_registry(monkeypatch)

    import mcpctl.server as server
    # Provide a fresh client each call; ping will raise if context not entered
    monkeypatch.setattr(server, "_make_client", lambda entry, token_store=None: FakeClient())

    result = runner.invoke(app, ["auth", "one"])

    assert result.exit_code == 0
    assert "logged in" in result.output
