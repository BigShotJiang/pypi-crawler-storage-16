import pytest
from typer.testing import CliRunner
from mcpctl.cli import app

runner = CliRunner()


def test_discover_no_server(monkeypatch):
    # mock discover to return names
    import mcpctl.discover as d

    async def fake(q, mode="pattern"):
        return ["a", "b"]

    monkeypatch.setattr(d, "discover", fake)
    result = runner.invoke(app, ["discover", "a"])
    assert result.exit_code == 0
    assert "a" in result.output
    assert "b" in result.output
