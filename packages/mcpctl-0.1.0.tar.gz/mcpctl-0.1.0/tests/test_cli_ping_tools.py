import pytest
from typer.testing import CliRunner

from mcpctl.cli import app


runner = CliRunner()


class FakeReg:
    def __init__(self, entry):
        self.entry = entry
        self.store = None

    async def get(self, name):
        return self.entry


class FakeClient:
    """Client that enforces async context before use."""

    def __init__(self, tools=None):
        self.connected = False
        self._tools = tools or []

    async def __aenter__(self):
        self.connected = True
        return self

    async def __aexit__(self, exc_type, exc, tb):
        self.connected = False

    async def ping(self):
        if not self.connected:
            raise RuntimeError("Client not connected")
        return None

    async def list_tools(self):
        if not self.connected:
            raise RuntimeError("Client not connected")
        return self._tools


def _patch_registry(monkeypatch, entry):
    import mcpctl.cli as cli
    monkeypatch.setattr(cli, "_get_registry", lambda: FakeReg(entry))


def _patch_client(monkeypatch, client_factory):
    import mcpctl.server as server
    monkeypatch.setattr(server, "_make_client", client_factory)


def test_ping_uses_async_context(monkeypatch):
    entry = {"transport": "http", "url": "https://example.com"}
    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient())

    result = runner.invoke(app, ["ping", "demo"])

    assert result.exit_code == 0
    assert "ok" in result.output


def test_tools_uses_async_context(monkeypatch):
    entry = {"transport": "http", "url": "https://example.com"}
    fake_tools = []
    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=fake_tools))

    result = runner.invoke(app, ["tools", "demo", "--json-out"])

    assert result.exit_code == 0
    assert result.output.strip() == "[]"
