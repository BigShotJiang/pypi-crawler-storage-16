import pytest
from typer.testing import CliRunner
from mcpctl.cli import app

runner = CliRunner()


def test_registry_add_show_list_delete(tmp_path, monkeypatch):
    # force disk store to use temp dir
    monkeypatch.setenv("MCPCTL_REGISTRY_DISK_PATH", str(tmp_path))
    result = runner.invoke(app, ["registry", "add", "demo", "--transport", "http", "--url", "https://example.com"])
    assert result.exit_code == 0
    result = runner.invoke(app, ["registry", "show", "demo", "--json-out"])
    assert "example.com" in result.output
    result = runner.invoke(app, ["registry", "list"])
    assert "demo" in result.output
    result = runner.invoke(app, ["registry", "delete", "demo"])
    assert result.exit_code == 0
