import asyncio
import pytest


@pytest.mark.asyncio
async def test_discover_calls_client_discover(monkeypatch):
    from mcpctl import discover as d

    called = {}

    class FakeTool:
        def __init__(self, name):
            self.name = name
            self.description = None

    async def fake_run(entry, store, func):
        called["entry"] = entry
        called["store"] = store
        return [FakeTool("alpha")]

    class FakeRegistry:
        store = object()

        async def list(self):
            return {"s1": {"transport": "http", "url": "http://x"}}

    monkeypatch.setattr(d, "create_registry", lambda: FakeRegistry())
    monkeypatch.setattr(d.server_mod, "_run_with_client", fake_run)

    names = await d.discover("query")

    assert names == ["alpha"]
    assert called["entry"]["url"] == "http://x"
    assert called["store"] is FakeRegistry.store


@pytest.mark.asyncio
async def test_discover_passes_mode(monkeypatch):
    from mcpctl import discover as d

    captured_mode = None

    class FakeTool:
        def __init__(self, name):
            self.name = name
            self.description = None

    async def fake_run(entry, store, func):
        nonlocal captured_mode
        # execute the provided function to capture mode
        class FakeClient:
            async def discover(self, query, mode="pattern"):
                nonlocal captured_mode
                captured_mode = mode
                return [FakeTool("beta")]

        return await func(FakeClient())

    class FakeRegistry:
        store = object()

        async def list(self):
            return {"s1": {"transport": "http", "url": "http://x"}}

    monkeypatch.setattr(d, "create_registry", lambda: FakeRegistry())
    monkeypatch.setattr(d.server_mod, "_run_with_client", fake_run)

    names = await d.discover("q", mode="semantic")

    assert names == ["beta"]
    assert captured_mode == "semantic"


@pytest.mark.asyncio
async def test_discover_aggregates_multiple_servers(monkeypatch):
    from mcpctl import discover as d

    class FakeTool:
        def __init__(self, name):
            self.name = name
            self.description = None

    async def fake_run(entry, store, func):
        return [FakeTool(entry["name"] + "_tool")]

    class FakeRegistry:
        store = object()

        async def list(self):
            return {
                "a": {"transport": "http", "url": "http://a", "name": "a"},
                "b": {"transport": "http", "url": "http://b", "name": "b"},
            }

    monkeypatch.setattr(d, "create_registry", lambda: FakeRegistry())
    monkeypatch.setattr(d.server_mod, "_run_with_client", fake_run)

    names = await d.discover("whatever")

    assert set(names) == {"a_tool", "b_tool"}


@pytest.mark.asyncio
async def test_discover_deduplicates(monkeypatch):
    from mcpctl import discover as d

    class FakeTool:
        def __init__(self, name):
            self.name = name
            self.description = None

    async def fake_run(entry, store, func):
        return [FakeTool("dup"), FakeTool(entry["id"])]

    class FakeRegistry:
        store = object()

        async def list(self):
            return {
                "x": {"transport": "http", "url": "http://x", "id": "x"},
                "y": {"transport": "http", "url": "http://y", "id": "y"},
            }

    monkeypatch.setattr(d, "create_registry", lambda: FakeRegistry())
    monkeypatch.setattr(d.server_mod, "_run_with_client", fake_run)

    names = await d.discover("q")

    assert names == ["dup", "x", "y"]


@pytest.mark.asyncio
async def test_discover_empty_registry(monkeypatch):
    from mcpctl import discover as d

    class FakeRegistry:
        store = object()

        async def list(self):
            return {}

    monkeypatch.setattr(d, "create_registry", lambda: FakeRegistry())
    # ensure _run_with_client would fail if called
    monkeypatch.setattr(d.server_mod, "_run_with_client", lambda *args, **kwargs: (_ for _ in ()).throw(RuntimeError("should not be called")))

    names = await d.discover("anything")

    assert names == []


@pytest.mark.asyncio
async def test_discover_skips_server_on_error(monkeypatch):
    from mcpctl import discover as d

    class FakeTool:
        def __init__(self, name):
            self.name = name
            self.description = None

    async def fake_run(entry, store, func):
        if entry["url"] == "bad":
            raise RuntimeError("boom")
        return [FakeTool("good")]

    class FakeRegistry:
        store = object()

        async def list(self):
            return {
                "bad": {"transport": "http", "url": "bad"},
                "good": {"transport": "http", "url": "good"},
            }

    monkeypatch.setattr(d, "create_registry", lambda: FakeRegistry())
    monkeypatch.setattr(d.server_mod, "_run_with_client", fake_run)

    names = await d.discover("q")

    assert names == ["good"]


@pytest.mark.asyncio
async def test_discover_preserves_order(monkeypatch):
    from mcpctl import discover as d

    class FakeTool:
        def __init__(self, name):
            self.name = name
            self.description = None

    async def fake_run(entry, store, func):
        return [FakeTool(entry["name"] + "1"), FakeTool(entry["name"] + "2")]

    class FakeRegistry:
        store = object()

        async def list(self):
            return {
                "first": {"transport": "http", "url": "http://1", "name": "a"},
                "second": {"transport": "http", "url": "http://2", "name": "b"},
            }

    monkeypatch.setattr(d, "create_registry", lambda: FakeRegistry())
    monkeypatch.setattr(d.server_mod, "_run_with_client", fake_run)

    names = await d.discover("q")

    assert names == ["a1", "a2", "b1", "b2"]


@pytest.mark.asyncio
async def test_discover_returns_names_only(monkeypatch):
    from mcpctl import discover as d

    class FakeTool:
        def __init__(self, name, description):
            self.name = name
            self.description = description

    async def fake_run(entry, store, func):
        return [FakeTool("n", "desc")]

    class FakeRegistry:
        store = object()

        async def list(self):
            return {"s": {"transport": "http", "url": "http://s"}}

    monkeypatch.setattr(d, "create_registry", lambda: FakeRegistry())
    monkeypatch.setattr(d.server_mod, "_run_with_client", fake_run)

    names = await d.discover("q")

    assert names == ["n"]


@pytest.mark.asyncio
async def test_discover_invokes_client_func(monkeypatch):
    from mcpctl import discover as d

    called = False

    class FakeTool:
        def __init__(self, name):
            self.name = name
            self.description = None

    async def fake_run(entry, store, func):
        nonlocal called
        called = True
        # ensure provided function is executed by calling it with a fake client
        class FakeClient:
            async def discover(self, *args, **kwargs):
                return [FakeTool("z")]

        return await func(FakeClient())

    class FakeRegistry:
        store = object()

        async def list(self):
            return {"s": {"transport": "http", "url": "http://s"}}

    monkeypatch.setattr(d, "create_registry", lambda: FakeRegistry())
    monkeypatch.setattr(d.server_mod, "_run_with_client", fake_run)

    names = await d.discover("q")

    assert called is True
    assert names == ["z"]


@pytest.mark.asyncio
async def test_discover_filters_none_results(monkeypatch):
    from mcpctl import discover as d

    class FakeTool:
        def __init__(self, name):
            self.name = name
            self.description = None

    async def fake_run(entry, store, func):
        return [FakeTool("ok"), None]

    class FakeRegistry:
        store = object()

        async def list(self):
            return {"s": {"transport": "http", "url": "http://s"}}

    monkeypatch.setattr(d, "create_registry", lambda: FakeRegistry())
    monkeypatch.setattr(d.server_mod, "_run_with_client", fake_run)

    names = await d.discover("q")

    assert names == ["ok"]
