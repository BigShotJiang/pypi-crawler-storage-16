import asyncio
import pytest

import mcpctl.server as server


class FlakyLoopClient:
    """
    Simulates a client whose first connection fails with 'Event loop is closed'
    but succeeds on retry. This mirrors the real-world failure reported when
    connecting to some remote HTTP MCP servers.
    """
    def __init__(self, behavior):
        self.behavior = behavior
        self.transport = type("t", (), {"auth": None})()
        self.connected = False

    async def __aenter__(self):
        self.behavior()
        self.connected = True
        return self

    async def __aexit__(self, exc_type, exc, tb):
        self.connected = False

    async def ping(self):
        if not self.connected:
            raise RuntimeError("not connected")
        return None


def _patch_client(monkeypatch, behavior):
    monkeypatch.setattr(server, "_make_client", lambda entry, token_store=None: FlakyLoopClient(behavior))


@pytest.mark.asyncio
async def test_event_loop_closed_retries(monkeypatch):
    """
    When the first client connection fails with 'Event loop is closed',
    the runner should retry with a fresh client and succeed.
    """
    # failing first call, succeeding next
    attempts = {"n": 0}

    def behavior():
        attempts["n"] += 1
        if attempts["n"] == 1:
            raise RuntimeError("Event loop is closed")

    _patch_client(monkeypatch, behavior)

    entry = {"transport": "http", "url": "https://example.com"}

    # Should not raise
    await server._run_with_client(entry, None, lambda client: client.ping())

    assert attempts["n"] == 2, "Second attempt should have been made after loop-closed failure"
