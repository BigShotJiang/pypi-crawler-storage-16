import asyncio
import pytest
from typer.testing import CliRunner

from mcpctl.cli import app
import mcpctl.server as server


runner = CliRunner()


# Simple AsyncKeyValue stub -------------------------------------------------
class DummyTokenStore:
    def __init__(self):
        self.data = {}

    async def get(self, key):
        return self.data.get(key)

    async def put(self, key, value):
        self.data[key] = value

    async def delete(self, key):
        self.data.pop(key, None)


# Registry stub -------------------------------------------------------------
class FakeReg:
    def __init__(self, entry, store):
        self.entry = entry
        self.store = store

    async def get(self, name):
        return self.entry


# Token storage adapter mimic -----------------------------------------------
class FakeStoreAdapter:
    def __init__(self, kv, key="token"):
        self.kv = kv
        self.key = key

    async def clear(self):
        await self.kv.delete(self.key)

    async def get(self):
        return await self.kv.get(self.key)

    async def put(self, value):
        await self.kv.put(self.key, value)


# Client stub ---------------------------------------------------------------
class FakeClient:
    def __init__(self, store_adapter, behavior):
        self.connected = False
        self.transport = type("t", (), {"auth": type("a", (), {"token_storage_adapter": store_adapter})})()
        self.behavior = behavior

    async def __aenter__(self):
        self.connected = True
        return self

    async def __aexit__(self, exc_type, exc, tb):
        self.connected = False

    async def ping(self):
        self.behavior("ping")
        return None

    async def list_tools(self):
        self.behavior("list_tools")
        class T:
            name = "t"
            description = ""
            def model_dump(self_inner):
                return {"name": self_inner.name, "description": self_inner.description}
        return [T()]

    async def call_tool(self, tool, args):
        self.behavior("call_tool")
        from mcp.types import CallToolResult, TextContent
        return CallToolResult(content=[TextContent(type="text", text="ok")], isError=False)

    async def list_resources(self):
        self.behavior("list_resources")
        class R:
            def model_dump(self_inner):
                return {"uri": "x"}
        return [R()]

    async def list_resource_templates(self):
        self.behavior("list_resource_templates")
        class R:
            def model_dump(self_inner):
                return {"uri": "t"}
        return [R()]

    async def read_resource(self, uri):
        self.behavior("read_resource")
        return "ok"

    async def list_prompts(self):
        self.behavior("list_prompts")
        class P:
            def model_dump(self_inner):
                return {"name": "p"}
        return [P()]

    async def get_prompt(self, name):
        self.behavior("get_prompt")
        class P:
            def model_dump(self_inner):
                return {"name": name}
        return P()


def _patch_registry(monkeypatch, entry, store):
    import mcpctl.cli as cli
    monkeypatch.setattr(cli, "_get_registry", lambda: FakeReg(entry, store))


def _patch_client(monkeypatch, client_factory):
    monkeypatch.setattr(server, "_make_client", client_factory)


# Helpers -------------------------------------------------------------------
def _make_write_behavior(adapter, value):
    def behavior(method):
        asyncio.get_event_loop().create_task(adapter.put(value))
    return behavior


def _make_401_once_behavior(adapter, value):
    called = {"count": 0}
    def behavior(method):
        called["count"] += 1
        if called["count"] == 1:
            raise Exception("401 unauthorized")
        asyncio.get_event_loop().create_task(adapter.put(value))
    return behavior


# Tests ---------------------------------------------------------------------
def test_auth_persists_token(monkeypatch):
    store = DummyTokenStore()
    adapter = FakeStoreAdapter(store)
    entry = {"transport": "http", "url": "https://example.com", "oauth": True}

    _patch_registry(monkeypatch, entry, store)
    behavior = _make_write_behavior(adapter, {"access_token": "abc"})
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(adapter, behavior))

    result = runner.invoke(app, ["auth", "svc"])
    assert result.exit_code == 0
    assert store.data.get("token") == {"access_token": "abc"}


@pytest.mark.parametrize(
    "cmd,args",
    [
        ("ping", ["svc"]),
        ("tools", ["svc", "--json-out"]),
        ("prompts", ["svc", "--list"]),
        ("resources", ["svc", "--list"]),
        ("resources", ["svc", "--templates"]),
        ("resources", ["svc", "--uri", "x"]),
        ("call", ["svc", "demo"]),
        ("tools", ["svc"]),
        ("prompts", ["svc", "--name", "p"]),
        # discover uses discover_mod, unrelated to auth flow; skip
    ],
)
def test_reauth_on_401(monkeypatch, cmd, args):
    store = DummyTokenStore()
    adapter = FakeStoreAdapter(store)
    entry = {"transport": "http", "url": "https://example.com", "oauth": True}

    behavior = _make_401_once_behavior(adapter, {"access_token": "new"})

    _patch_registry(monkeypatch, entry, store)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(adapter, behavior))

    result = runner.invoke(app, [cmd] + args)
    assert result.exit_code == 0
    assert store.data.get("token") == {"access_token": "new"}
