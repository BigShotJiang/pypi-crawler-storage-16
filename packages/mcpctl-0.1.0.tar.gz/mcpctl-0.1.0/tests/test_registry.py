import pytest
import anyio
from mcpctl.registry import Registry, get_registry_store


@pytest.mark.anyio
async def test_memory_registry_roundtrip():
    reg = Registry(get_registry_store())
    await reg.set("demo", {"transport": "http"})
    value = await reg.get("demo")
    assert value["transport"] == "http"
    items = await reg.list()
    assert "demo" in items
    await reg.delete("demo")
    assert await reg.get("demo") is None
