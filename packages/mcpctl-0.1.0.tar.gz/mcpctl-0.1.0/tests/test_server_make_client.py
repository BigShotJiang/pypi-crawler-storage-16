import pytest
from mcpctl.server import _make_client
from fastmcp.client import Client


def test_http_bearer(monkeypatch):
    monkeypatch.setenv("TOKEN", "abc")
    entry = {"transport": "http", "url": "https://example.com", "bearer_env": "TOKEN"}
    client = _make_client(entry)
    assert isinstance(client, Client)


def test_stdio(monkeypatch):
    # provide a temp script file to satisfy PythonStdioTransport
    import tempfile, textwrap, os, sys
    with tempfile.NamedTemporaryFile("w", suffix=".py", delete=False) as f:
        f.write("import sys\nprint('ok')\n")
        script_path = f.name
    entry = {"transport": "stdio", "cmd": script_path, "cmd_args": []}
    client = _make_client(entry)
    assert isinstance(client, Client)
    os.unlink(script_path)
