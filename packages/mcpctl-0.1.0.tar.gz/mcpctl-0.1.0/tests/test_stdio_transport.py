"""Tests for stdio transport spec: servers added with transport=stdio must work."""

import os
import tempfile
import pytest
from unittest.mock import patch, MagicMock, AsyncMock
from typer.testing import CliRunner

from mcpctl.cli import app
from mcpctl.server import _make_client
from fastmcp.client import Client


runner = CliRunner()


class FakeReg:
    def __init__(self, entry):
        self.entry = entry
        self.store = None

    async def get(self, name):
        return self.entry


class FakeClient:
    def __init__(self, tools=None):
        self.connected = False
        self._tools = tools or []

    async def __aenter__(self):
        self.connected = True
        return self

    async def __aexit__(self, exc_type, exc, tb):
        self.connected = False

    async def ping(self):
        if not self.connected:
            raise RuntimeError("Client not connected")
        return None

    async def list_tools(self):
        if not self.connected:
            raise RuntimeError("Client not connected")
        return self._tools


def _patch_registry(monkeypatch, entry):
    import mcpctl.cli as cli
    monkeypatch.setattr(cli, "_get_registry", lambda: FakeReg(entry))


def _patch_client(monkeypatch, client_factory):
    import mcpctl.server as server
    monkeypatch.setattr(server, "_make_client", client_factory)


# Test 1: _make_client creates correct transport for command in PATH
def test_stdio_transport_with_path_command():
    """Server with cmd as a command in PATH should use StdioTransport."""
    from fastmcp.client.transports import StdioTransport

    entry = {"transport": "stdio", "cmd": "echo", "cmd_args": ["hello"]}
    client = _make_client(entry)

    assert isinstance(client, Client)
    assert isinstance(client.transport, StdioTransport)
    assert client.transport.command == "echo"
    assert client.transport.args == ["hello"]


# Test 2: _make_client creates transport for script path
def test_stdio_transport_with_script_path():
    """Server with cmd as script path should use StdioTransport."""
    from fastmcp.client.transports import StdioTransport

    with tempfile.NamedTemporaryFile("w", suffix=".py", delete=False) as f:
        f.write("print('ok')\n")
        script_path = f.name

    try:
        entry = {"transport": "stdio", "cmd": script_path, "cmd_args": []}
        client = _make_client(entry)

        assert isinstance(client, Client)
        assert isinstance(client.transport, StdioTransport)
        assert client.transport.command == script_path
    finally:
        os.unlink(script_path)


# Test 3: cmd_args are passed correctly to transport
def test_stdio_transport_passes_cmd_args():
    """cmd_args should be passed as args to StdioTransport."""
    from fastmcp.client.transports import StdioTransport

    entry = {
        "transport": "stdio",
        "cmd": "my-mcp-server",
        "cmd_args": ["--port", "8080", "--verbose"],
        "env": {"API_KEY": "secret"},
        "cwd": "/tmp",
    }
    client = _make_client(entry)

    assert isinstance(client.transport, StdioTransport)
    assert client.transport.command == "my-mcp-server"
    assert client.transport.args == ["--port", "8080", "--verbose"]
    assert client.transport.env == {"API_KEY": "secret"}
    assert client.transport.cwd == "/tmp"


# Test 4: ping works with stdio transport server
def test_ping_stdio_server(monkeypatch):
    """ping command should work with stdio transport servers."""
    entry = {"transport": "stdio", "cmd": "cerebras-code-mcp", "cmd_args": None}
    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient())

    result = runner.invoke(app, ["ping", "cerebras"])

    assert result.exit_code == 0
    assert "ok" in result.output


# Test 5: tools works with stdio transport server
def test_tools_stdio_server(monkeypatch):
    """tools command should work with stdio transport servers."""
    entry = {"transport": "stdio", "cmd": "cerebras-code-mcp", "cmd_args": None}
    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=[]))

    result = runner.invoke(app, ["tools", "cerebras", "--json-out"])

    assert result.exit_code == 0
    assert result.output.strip() == "[]"
