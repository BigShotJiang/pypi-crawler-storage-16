"""
Test suite for tools describe feature (TC001-TC006).

Spec: Display detailed schema information for a single tool by name.
"""
import json
import pytest
from typer.testing import CliRunner
from mcp.types import Tool

from mcpctl.cli import app

runner = CliRunner()


class FakeReg:
    def __init__(self, entry):
        self.entry = entry
        self.store = None

    async def get(self, name):
        return self.entry


class FakeClient:
    """Client that enforces async context before use."""

    def __init__(self, tools=None):
        self.connected = False
        self._tools = tools or []

    async def __aenter__(self):
        self.connected = True
        return self

    async def __aexit__(self, exc_type, exc, tb):
        self.connected = False

    async def list_tools(self):
        if not self.connected:
            raise RuntimeError("Client not connected")
        return self._tools


def _patch_registry(monkeypatch, entry):
    import mcpctl.cli as cli
    monkeypatch.setattr(cli, "_get_registry", lambda: FakeReg(entry))


def _patch_client(monkeypatch, client_factory):
    import mcpctl.server as server
    monkeypatch.setattr(server, "_make_client", client_factory)


# ============================================================================
# TC001: Show single tool details in human-readable format
# ============================================================================

def test_tc001_show_tool_details_human_readable(monkeypatch):
    """TC001: Show single tool details in human-readable format.

    Command: mcpctl tools <server> <tool_name>
    Expected: exit_code 0, output contains "name", "description", "inputSchema",
              format is table or panel
    """
    entry = {"transport": "http", "url": "https://example.com"}
    tool = Tool(
        name="weather_tool",
        description="Get weather information",
        inputSchema={
            "type": "object",
            "properties": {
                "location": {"type": "string", "description": "City name"}
            },
            "required": ["location"]
        }
    )

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=[tool]))

    result = runner.invoke(app, ["tools", "demo", "weather_tool"])

    assert result.exit_code == 0, f"Exit code: {result.exit_code}, output: {result.output}"
    # Check output contains required keys
    assert "name" in result.output.lower()
    assert "description" in result.output.lower()
    assert "inputschema" in result.output.lower()
    # Check for human-readable content (tool name and description should be present)
    assert "weather_tool" in result.output
    assert "Get weather information" in result.output


def test_tc001_tool_details_display_all_fields(monkeypatch):
    """TC001: Verify all tool fields are displayed."""
    entry = {"transport": "http", "url": "https://example.com"}
    tool = Tool(
        name="example_tool",
        title="Example Tool Title",
        description="Example description",
        inputSchema={"type": "object", "properties": {}}
    )

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=[tool]))

    result = runner.invoke(app, ["tools", "demo", "example_tool"])

    assert result.exit_code == 0
    assert "example_tool" in result.output


# ============================================================================
# TC002: Show single tool details as JSON
# ============================================================================

def test_tc002_show_tool_details_json(monkeypatch):
    """TC002: Show single tool details as JSON.

    Command: mcpctl tools --json-out <server> <tool_name>
    Expected: exit_code 0, valid JSON output, JSON has keys "name", "description",
              "inputSchema"
    """
    entry = {"transport": "http", "url": "https://example.com"}
    tool = Tool(
        name="weather_tool",
        description="Get weather information",
        inputSchema={
            "type": "object",
            "properties": {
                "location": {"type": "string", "description": "City name"}
            },
            "required": ["location"]
        }
    )

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=[tool]))

    result = runner.invoke(app, ["tools", "demo", "weather_tool", "--json-out"])

    assert result.exit_code == 0, f"Exit code: {result.exit_code}, output: {result.output}"
    # Parse JSON output
    try:
        output_json = json.loads(result.output)
    except json.JSONDecodeError:
        pytest.fail(f"Output is not valid JSON: {result.output}")

    # Verify JSON has required keys
    assert "name" in output_json
    assert "description" in output_json
    assert "inputSchema" in output_json

    # Verify values match
    assert output_json["name"] == "weather_tool"
    assert output_json["description"] == "Get weather information"
    assert output_json["inputSchema"]["properties"]["location"]["type"] == "string"


def test_tc002_json_output_valid_json_structure(monkeypatch):
    """TC002: Verify JSON output has valid structure with all fields."""
    entry = {"transport": "http", "url": "https://example.com"}
    tool = Tool(
        name="complex_tool",
        description="A complex tool",
        inputSchema={
            "type": "object",
            "properties": {
                "param1": {"type": "string"},
                "param2": {"type": "number"}
            },
            "required": ["param1"]
        },
        outputSchema={
            "type": "object",
            "properties": {
                "result": {"type": "string"}
            }
        }
    )

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=[tool]))

    result = runner.invoke(app, ["tools", "demo", "complex_tool", "--json-out"])

    assert result.exit_code == 0
    output_json = json.loads(result.output)

    # Check all expected fields
    assert output_json["name"] == "complex_tool"
    assert output_json["description"] == "A complex tool"
    assert isinstance(output_json["inputSchema"], dict)
    assert "properties" in output_json["inputSchema"]


# ============================================================================
# TC003: Error when tool name not found
# ============================================================================

def test_tc003_tool_not_found_error(monkeypatch):
    """TC003: Error when tool name not found.

    Command: mcpctl tools <server> nonexistent_tool
    Expected: exit_code 1, stderr contains "not found"
    """
    entry = {"transport": "http", "url": "https://example.com"}
    existing_tool = Tool(
        name="existing_tool",
        description="An existing tool",
        inputSchema={}
    )

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=[existing_tool]))

    result = runner.invoke(app, ["tools", "demo", "nonexistent_tool"])

    assert result.exit_code == 1
    # Check stderr or output contains "not found" (case-insensitive)
    output = result.output.lower()
    assert "not found" in output or "not found" in result.stderr if result.stderr else "not found" in output


def test_tc003_tool_not_found_with_multiple_tools(monkeypatch):
    """TC003: Error when tool not found in list of multiple tools."""
    entry = {"transport": "http", "url": "https://example.com"}
    tools = [
        Tool(name="tool1", description="First tool", inputSchema={}),
        Tool(name="tool2", description="Second tool", inputSchema={}),
        Tool(name="tool3", description="Third tool", inputSchema={}),
    ]

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=tools))

    result = runner.invoke(app, ["tools", "demo", "missing_tool"])

    assert result.exit_code == 1
    assert "not found" in result.output.lower()


# ============================================================================
# TC004: Show outputSchema when present
# ============================================================================

def test_tc004_show_output_schema_when_present(monkeypatch):
    """TC004: Show outputSchema when present.

    Command: mcpctl tools <server> <tool_with_output_schema>
    Expected: exit_code 0, output contains "outputSchema"
    """
    entry = {"transport": "http", "url": "https://example.com"}
    tool = Tool(
        name="compute_tool",
        description="Computes a result",
        inputSchema={
            "type": "object",
            "properties": {
                "input": {"type": "string"}
            }
        },
        outputSchema={
            "type": "object",
            "properties": {
                "result": {"type": "number"},
                "status": {"type": "string"}
            }
        }
    )

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=[tool]))

    result = runner.invoke(app, ["tools", "demo", "compute_tool"])

    assert result.exit_code == 0
    assert "outputschema" in result.output.lower() or "output" in result.output.lower()


def test_tc004_output_schema_in_json_output(monkeypatch):
    """TC004: Verify outputSchema is present in JSON output."""
    entry = {"transport": "http", "url": "https://example.com"}
    tool = Tool(
        name="json_tool",
        description="Tool with JSON output",
        inputSchema={"type": "object"},
        outputSchema={
            "type": "object",
            "properties": {
                "output": {"type": "string"}
            }
        }
    )

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=[tool]))

    result = runner.invoke(app, ["tools", "demo", "json_tool", "--json-out"])

    assert result.exit_code == 0
    output_json = json.loads(result.output)
    assert "outputSchema" in output_json
    assert output_json["outputSchema"] is not None


# ============================================================================
# TC005: Show required parameters clearly
# ============================================================================

def test_tc005_show_required_parameters(monkeypatch):
    """TC005: Show required parameters clearly.

    Command: mcpctl tools <server> <tool_name>
    Expected: exit_code 0, output contains "required"
    """
    entry = {"transport": "http", "url": "https://example.com"}
    tool = Tool(
        name="params_tool",
        description="Tool with required params",
        inputSchema={
            "type": "object",
            "properties": {
                "param1": {"type": "string", "description": "Required parameter"},
                "param2": {"type": "string", "description": "Optional parameter"}
            },
            "required": ["param1"]
        }
    )

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=[tool]))

    result = runner.invoke(app, ["tools", "demo", "params_tool"])

    assert result.exit_code == 0
    assert "required" in result.output.lower()


def test_tc005_required_params_in_json_output(monkeypatch):
    """TC005: Verify required parameters visible in JSON output."""
    entry = {"transport": "http", "url": "https://example.com"}
    tool = Tool(
        name="required_tool",
        description="Tool showing required fields",
        inputSchema={
            "type": "object",
            "properties": {
                "email": {"type": "string"},
                "name": {"type": "string"}
            },
            "required": ["email"]
        }
    )

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=[tool]))

    result = runner.invoke(app, ["tools", "demo", "required_tool", "--json-out"])

    assert result.exit_code == 0
    output_json = json.loads(result.output)
    assert "inputSchema" in output_json
    assert "required" in output_json["inputSchema"]
    assert "email" in output_json["inputSchema"]["required"]


# ============================================================================
# TC006: Show parameter types and descriptions
# ============================================================================

def test_tc006_show_parameter_types_and_descriptions(monkeypatch):
    """TC006: Show parameter types and descriptions.

    Command: mcpctl tools <server> <tool_name>
    Expected: exit_code 0, output contains "type" and "description"
    """
    entry = {"transport": "http", "url": "https://example.com"}
    tool = Tool(
        name="detailed_tool",
        description="Tool with detailed parameters",
        inputSchema={
            "type": "object",
            "properties": {
                "age": {
                    "type": "integer",
                    "description": "Age of the person"
                },
                "name": {
                    "type": "string",
                    "description": "Full name of the person"
                }
            }
        }
    )

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=[tool]))

    result = runner.invoke(app, ["tools", "demo", "detailed_tool"])

    assert result.exit_code == 0
    # Check output contains both type and description indicators
    output_lower = result.output.lower()
    assert "type" in output_lower
    assert "description" in output_lower


def test_tc006_parameter_types_in_json_output(monkeypatch):
    """TC006: Verify parameter types and descriptions in JSON output."""
    entry = {"transport": "http", "url": "https://example.com"}
    tool = Tool(
        name="schema_tool",
        description="Tool with complete schema",
        inputSchema={
            "type": "object",
            "properties": {
                "count": {
                    "type": "integer",
                    "description": "Number of items"
                },
                "enabled": {
                    "type": "boolean",
                    "description": "Enable feature"
                },
                "items": {
                    "type": "array",
                    "description": "List of items"
                }
            }
        }
    )

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=[tool]))

    result = runner.invoke(app, ["tools", "demo", "schema_tool", "--json-out"])

    assert result.exit_code == 0
    output_json = json.loads(result.output)

    # Verify types are in the properties
    props = output_json["inputSchema"]["properties"]
    assert props["count"]["type"] == "integer"
    assert props["enabled"]["type"] == "boolean"
    assert props["items"]["type"] == "array"

    # Verify descriptions are present
    assert props["count"]["description"] == "Number of items"
    assert props["enabled"]["description"] == "Enable feature"
    assert props["items"]["description"] == "List of items"


def test_tc006_complex_types_in_output(monkeypatch):
    """TC006: Show nested and complex parameter types."""
    entry = {"transport": "http", "url": "https://example.com"}
    tool = Tool(
        name="complex_types_tool",
        description="Tool with complex parameter types",
        inputSchema={
            "type": "object",
            "properties": {
                "config": {
                    "type": "object",
                    "description": "Configuration object",
                    "properties": {
                        "timeout": {"type": "number"},
                        "retries": {"type": "integer"}
                    }
                },
                "tags": {
                    "type": "array",
                    "description": "List of tags",
                    "items": {"type": "string"}
                }
            }
        }
    )

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=[tool]))

    result = runner.invoke(app, ["tools", "demo", "complex_types_tool", "--json-out"])

    assert result.exit_code == 0
    output_json = json.loads(result.output)

    props = output_json["inputSchema"]["properties"]
    assert props["config"]["type"] == "object"
    assert props["config"]["description"] == "Configuration object"
    assert props["tags"]["type"] == "array"
    assert props["tags"]["description"] == "List of tags"


# ============================================================================
# TC007: Handle type as list (e.g., ['string', 'null'])
# ============================================================================

def test_tc007_handle_type_as_list(monkeypatch):
    """TC007: Handle type as list (e.g., ['string', 'null']).

    Tool has inputSchema with "type": ["string", "null"] (list form)
    Expected: exit_code 0, output contains "string | null"
    """
    entry = {"transport": "http", "url": "https://example.com"}
    tool = Tool(
        name="optional_string_tool",
        description="Tool with optional string parameter",
        inputSchema={
            "type": "object",
            "properties": {
                "value": {
                    "type": ["string", "null"],
                    "description": "Optional string value"
                }
            }
        }
    )

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=[tool]))

    result = runner.invoke(app, ["tools", "demo", "optional_string_tool"])

    assert result.exit_code == 0, f"Exit code: {result.exit_code}, output: {result.output}"
    # Check output contains the union type representation
    assert "string" in result.output.lower() and "null" in result.output.lower()
    # Check for pipe separator or similar union representation
    assert "|" in result.output


def test_tc007_type_as_list_in_json_output(monkeypatch):
    """TC007: Verify type as list is preserved in JSON output."""
    entry = {"transport": "http", "url": "https://example.com"}
    tool = Tool(
        name="nullable_string_tool",
        description="Tool with nullable string parameter",
        inputSchema={
            "type": "object",
            "properties": {
                "name": {
                    "type": ["string", "null"],
                    "description": "Optional name"
                }
            }
        }
    )

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=[tool]))

    result = runner.invoke(app, ["tools", "demo", "nullable_string_tool", "--json-out"])

    assert result.exit_code == 0
    output_json = json.loads(result.output)
    props = output_json["inputSchema"]["properties"]
    # Type should be a list in the JSON
    assert isinstance(props["name"]["type"], list)
    assert "string" in props["name"]["type"]
    assert "null" in props["name"]["type"]


# ============================================================================
# TC008: Handle anyOf type unions
# ============================================================================

def test_tc008_handle_anyof_type_unions(monkeypatch):
    """TC008: Handle anyOf type unions.

    Tool has inputSchema with "anyOf": [{"type": "string"}, {"type": "null"}]
    Expected: exit_code 0, output contains "|" (types joined)
    """
    entry = {"transport": "http", "url": "https://example.com"}
    tool = Tool(
        name="anyof_union_tool",
        description="Tool with anyOf type union",
        inputSchema={
            "type": "object",
            "properties": {
                "value": {
                    "anyOf": [
                        {"type": "string"},
                        {"type": "null"}
                    ],
                    "description": "String or null value"
                }
            }
        }
    )

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=[tool]))

    result = runner.invoke(app, ["tools", "demo", "anyof_union_tool"])

    assert result.exit_code == 0, f"Exit code: {result.exit_code}, output: {result.output}"
    # Check output contains types joined with pipe separator
    assert "|" in result.output


def test_tc008_anyof_multiple_types(monkeypatch):
    """TC008: Handle anyOf with multiple different types."""
    entry = {"transport": "http", "url": "https://example.com"}
    tool = Tool(
        name="multi_type_tool",
        description="Tool with multiple type options",
        inputSchema={
            "type": "object",
            "properties": {
                "data": {
                    "anyOf": [
                        {"type": "string"},
                        {"type": "number"},
                        {"type": "boolean"}
                    ],
                    "description": "Can be string, number, or boolean"
                }
            }
        }
    )

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=[tool]))

    result = runner.invoke(app, ["tools", "demo", "multi_type_tool"])

    assert result.exit_code == 0, f"Exit code: {result.exit_code}, output: {result.output}"
    # Check output contains pipe separator for union representation
    assert "|" in result.output


def test_tc008_anyof_in_json_output(monkeypatch):
    """TC008: Verify anyOf is preserved in JSON output."""
    entry = {"transport": "http", "url": "https://example.com"}
    tool = Tool(
        name="anyof_json_tool",
        description="Tool with anyOf union",
        inputSchema={
            "type": "object",
            "properties": {
                "flexible": {
                    "anyOf": [
                        {"type": "string"},
                        {"type": "integer"}
                    ],
                    "description": "Flexible type parameter"
                }
            }
        }
    )

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=[tool]))

    result = runner.invoke(app, ["tools", "demo", "anyof_json_tool", "--json-out"])

    assert result.exit_code == 0
    output_json = json.loads(result.output)
    props = output_json["inputSchema"]["properties"]
    # anyOf should be present in the JSON
    assert "anyOf" in props["flexible"]
    assert isinstance(props["flexible"]["anyOf"], list)
    assert len(props["flexible"]["anyOf"]) == 2


# ============================================================================
# Additional edge case tests
# ============================================================================

def test_tool_with_no_description(monkeypatch):
    """Test tool with missing description."""
    entry = {"transport": "http", "url": "https://example.com"}
    tool = Tool(
        name="no_desc_tool",
        description=None,
        inputSchema={}
    )

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=[tool]))

    result = runner.invoke(app, ["tools", "demo", "no_desc_tool"])

    assert result.exit_code == 0
    assert "no_desc_tool" in result.output


def test_tool_with_empty_input_schema(monkeypatch):
    """Test tool with empty input schema."""
    entry = {"transport": "http", "url": "https://example.com"}
    tool = Tool(
        name="empty_schema_tool",
        description="Tool with empty schema",
        inputSchema={}
    )

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=[tool]))

    result = runner.invoke(app, ["tools", "demo", "empty_schema_tool"])

    assert result.exit_code == 0
    assert "empty_schema_tool" in result.output


def test_tool_details_multiple_tools_in_server(monkeypatch):
    """Test showing details of one tool when server has many."""
    entry = {"transport": "http", "url": "https://example.com"}
    tools = [
        Tool(name="tool1", description="First", inputSchema={}),
        Tool(name="tool2", description="Second", inputSchema={}),
        Tool(name="target_tool", description="Target tool", inputSchema={"type": "object"}),
        Tool(name="tool3", description="Third", inputSchema={}),
    ]

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=tools))

    result = runner.invoke(app, ["tools", "demo", "target_tool"])

    assert result.exit_code == 0
    assert "target_tool" in result.output
    # Should not show all tools, just details of the one requested
    assert "Target tool" in result.output
