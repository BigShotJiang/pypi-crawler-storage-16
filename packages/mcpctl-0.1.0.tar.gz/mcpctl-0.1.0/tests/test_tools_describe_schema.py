"""
Test suite for tools describe schema feature (TC004, TC005, TC006).

These tests verify that the CLI displays detailed schema information for a single tool,
including outputSchema, required parameters, types, and descriptions.

Note: These tests assume the `mcpctl tools <server> <tool_name>` command has been
implemented to display detailed schema for a specific tool (currently it only lists all tools).
"""
import json
import pytest
from typer.testing import CliRunner
from mcp.types import Tool

from mcpctl.cli import app

runner = CliRunner()


class FakeReg:
    """Mock registry for testing."""
    def __init__(self, entry):
        self.entry = entry
        self.store = None

    async def get(self, name):
        return self.entry


class FakeClient:
    """Mock client that supports async context manager and lists tools."""
    def __init__(self, tools=None):
        self.connected = False
        self._tools = tools or []

    async def __aenter__(self):
        self.connected = True
        return self

    async def __aexit__(self, exc_type, exc, tb):
        self.connected = False

    async def list_tools(self):
        if not self.connected:
            raise RuntimeError("Client not connected")
        return self._tools


def _patch_registry(monkeypatch, entry):
    """Patch the CLI registry with a fake one."""
    import mcpctl.cli as cli
    monkeypatch.setattr(cli, "_get_registry", lambda: FakeReg(entry))


def _patch_client(monkeypatch, client_factory):
    """Patch the server module's _make_client with a factory."""
    import mcpctl.server as server
    monkeypatch.setattr(server, "_make_client", client_factory)


# ============================================================================
# Test Case TC004: Show outputSchema when present
# ============================================================================

def test_tc004_show_output_schema_when_present(monkeypatch):
    """
    TC004: Show outputSchema when present

    Command: mcpctl tools <server> <tool_with_output_schema>
    Expected: exit_code 0, output contains "outputSchema"
    """
    entry = {"transport": "http", "url": "https://example.com"}

    # Create a tool with outputSchema
    tool_with_output = Tool(
        name="transform_text",
        description="Transforms text in various ways",
        inputSchema={
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "Text to transform"},
                "operation": {"type": "string", "description": "Operation to perform"}
            },
            "required": ["text", "operation"]
        },
        outputSchema={
            "type": "object",
            "properties": {
                "result": {"type": "string", "description": "Transformed text"}
            }
        }
    )

    tools = [tool_with_output]

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=tools))

    # Command: mcpctl tools <server> <tool_name>
    result = runner.invoke(app, ["tools", "demo", "transform_text"])

    assert result.exit_code == 0, f"Command failed: {result.output}"
    # Check for "Output Schema:" (the displayed format) or "outputSchema" (the JSON key)
    assert "Output Schema" in result.output or "outputSchema" in result.output, f"outputSchema not found in output: {result.output}"


def test_tc004_output_schema_with_json_out(monkeypatch):
    """TC004: Verify outputSchema appears in JSON output format."""
    entry = {"transport": "http", "url": "https://example.com"}

    tool_with_output = Tool(
        name="analyze_data",
        description="Analyzes data and returns metrics",
        inputSchema={
            "type": "object",
            "properties": {
                "data": {"type": "array", "description": "Data to analyze"}
            },
            "required": ["data"]
        },
        outputSchema={
            "type": "object",
            "properties": {
                "mean": {"type": "number"},
                "median": {"type": "number"},
                "std_dev": {"type": "number"}
            }
        }
    )

    tools = [tool_with_output]

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=tools))

    result = runner.invoke(app, ["tools", "demo", "analyze_data", "--json-out"])

    assert result.exit_code == 0, f"Command failed: {result.output}"
    # Parse JSON and verify outputSchema is present
    data = json.loads(result.output)
    assert "outputSchema" in data, f"outputSchema not in JSON: {data}"
    assert data["outputSchema"]["properties"]["mean"]["type"] == "number"


def test_tc004_tool_without_output_schema(monkeypatch):
    """TC004: Verify tools without outputSchema still work (outputSchema is optional)."""
    entry = {"transport": "http", "url": "https://example.com"}

    tool_without_output = Tool(
        name="log_message",
        description="Logs a message",
        inputSchema={
            "type": "object",
            "properties": {
                "message": {"type": "string", "description": "Message to log"}
            },
            "required": ["message"]
        }
        # No outputSchema
    )

    tools = [tool_without_output]

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=tools))

    result = runner.invoke(app, ["tools", "demo", "log_message"])

    assert result.exit_code == 0, f"Command failed: {result.output}"
    # Should still work even without outputSchema
    assert "log_message" in result.output or "description" in result.output.lower()


# ============================================================================
# Test Case TC005: Show required parameters clearly
# ============================================================================

def test_tc005_show_required_parameters_clearly(monkeypatch):
    """
    TC005: Show required parameters clearly

    Command: mcpctl tools <server> <tool_name>
    Expected: exit_code 0, output contains "required"
    """
    entry = {"transport": "http", "url": "https://example.com"}

    tool = Tool(
        name="calculate",
        description="Performs calculations",
        inputSchema={
            "type": "object",
            "properties": {
                "a": {"type": "number", "description": "First number"},
                "b": {"type": "number", "description": "Second number"},
                "operation": {"type": "string", "description": "Operation to perform"}
            },
            "required": ["a", "b", "operation"]
        }
    )

    tools = [tool]

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=tools))

    result = runner.invoke(app, ["tools", "demo", "calculate"])

    assert result.exit_code == 0, f"Command failed: {result.output}"
    # Check for "Required" column header or checkmark (✓) indicating required, or "required" in JSON
    assert "Required" in result.output or "✓" in result.output or "required" in result.output.lower(), f"'required' indicator not found in output: {result.output}"


def test_tc005_required_parameters_in_json_output(monkeypatch):
    """TC005: Verify required parameters appear correctly in JSON output."""
    entry = {"transport": "http", "url": "https://example.com"}

    tool = Tool(
        name="search",
        description="Searches for content",
        inputSchema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query"},
                "limit": {"type": "integer", "description": "Result limit"},
                "offset": {"type": "integer", "description": "Result offset"}
            },
            "required": ["query", "limit"]
        }
    )

    tools = [tool]

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=tools))

    result = runner.invoke(app, ["tools", "demo", "search", "--json-out"])

    assert result.exit_code == 0, f"Command failed: {result.output}"
    data = json.loads(result.output)

    # Verify required is in the inputSchema
    assert "inputSchema" in data
    assert "required" in data["inputSchema"]
    assert "query" in data["inputSchema"]["required"]
    assert "limit" in data["inputSchema"]["required"]
    assert "offset" not in data["inputSchema"]["required"]


def test_tc005_tool_with_no_required_parameters(monkeypatch):
    """TC005: Handle tools with no required parameters."""
    entry = {"transport": "http", "url": "https://example.com"}

    tool = Tool(
        name="get_status",
        description="Gets system status",
        inputSchema={
            "type": "object",
            "properties": {
                "verbose": {"type": "boolean", "description": "Verbose output"}
            }
            # No required array
        }
    )

    tools = [tool]

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=tools))

    result = runner.invoke(app, ["tools", "demo", "get_status"])

    assert result.exit_code == 0, f"Command failed: {result.output}"
    # Should still display the tool info even without required params


# ============================================================================
# Test Case TC006: Show parameter types and descriptions
# ============================================================================

def test_tc006_show_parameter_types_and_descriptions(monkeypatch):
    """
    TC006: Show parameter types and descriptions

    Command: mcpctl tools <server> <tool_name>
    Expected: exit_code 0, output contains "type", "description"
    """
    entry = {"transport": "http", "url": "https://example.com"}

    tool = Tool(
        name="process_file",
        description="Processes a file",
        inputSchema={
            "type": "object",
            "properties": {
                "filepath": {
                    "type": "string",
                    "description": "Path to the file to process"
                },
                "format": {
                    "type": "string",
                    "description": "Output format (json, csv, xml)"
                },
                "verbose": {
                    "type": "boolean",
                    "description": "Enable verbose output"
                },
                "timeout": {
                    "type": "integer",
                    "description": "Timeout in seconds"
                }
            },
            "required": ["filepath"]
        }
    )

    tools = [tool]

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=tools))

    result = runner.invoke(app, ["tools", "demo", "process_file"])

    assert result.exit_code == 0, f"Command failed: {result.output}"
    # Check for type indicators (like "string", "boolean", "integer") or "Type" column header
    assert ("Type" in result.output or "string" in result.output or "boolean" in result.output or "integer" in result.output), \
        f"Type information not found in output: {result.output}"
    # Check for descriptions - should contain the actual descriptions or "Description" column header
    assert ("Description" in result.output or "Path to the file to process" in result.output or \
            "Output format" in result.output or "Enable verbose output" in result.output), \
        f"'description' info not found in output: {result.output}"


def test_tc006_parameter_types_in_json_output(monkeypatch):
    """TC006: Verify all parameter types appear in JSON output."""
    entry = {"transport": "http", "url": "https://example.com"}

    tool = Tool(
        name="complex_operation",
        description="Performs a complex operation",
        inputSchema={
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "Name of the operation"
                },
                "count": {
                    "type": "integer",
                    "description": "Number of iterations"
                },
                "factor": {
                    "type": "number",
                    "description": "Multiplication factor"
                },
                "enabled": {
                    "type": "boolean",
                    "description": "Enable operation"
                },
                "tags": {
                    "type": "array",
                    "description": "Operation tags",
                    "items": {"type": "string"}
                }
            },
            "required": ["name"]
        }
    )

    tools = [tool]

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=tools))

    result = runner.invoke(app, ["tools", "demo", "complex_operation", "--json-out"])

    assert result.exit_code == 0, f"Command failed: {result.output}"
    data = json.loads(result.output)

    # Verify properties and their types exist
    assert "inputSchema" in data
    props = data["inputSchema"]["properties"]

    assert "name" in props
    assert props["name"]["type"] == "string"
    assert "count" in props
    assert props["count"]["type"] == "integer"
    assert "factor" in props
    assert props["factor"]["type"] == "number"
    assert "enabled" in props
    assert props["enabled"]["type"] == "boolean"
    assert "tags" in props
    assert props["tags"]["type"] == "array"


def test_tc006_descriptions_visible_for_all_parameters(monkeypatch):
    """TC006: Verify descriptions are visible for each parameter."""
    entry = {"transport": "http", "url": "https://example.com"}

    tool = Tool(
        name="filter_data",
        description="Filters data based on criteria",
        inputSchema={
            "type": "object",
            "properties": {
                "dataset": {
                    "type": "string",
                    "description": "Name of the dataset to filter"
                },
                "min_value": {
                    "type": "number",
                    "description": "Minimum value threshold"
                },
                "max_value": {
                    "type": "number",
                    "description": "Maximum value threshold"
                },
                "include_nulls": {
                    "type": "boolean",
                    "description": "Whether to include null values"
                }
            },
            "required": ["dataset"]
        }
    )

    tools = [tool]

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=tools))

    result = runner.invoke(app, ["tools", "demo", "filter_data", "--json-out"])

    assert result.exit_code == 0, f"Command failed: {result.output}"
    data = json.loads(result.output)

    # Verify all descriptions are present
    props = data["inputSchema"]["properties"]
    assert "description" in props["dataset"]
    assert props["dataset"]["description"] == "Name of the dataset to filter"

    assert "description" in props["min_value"]
    assert props["min_value"]["description"] == "Minimum value threshold"

    assert "description" in props["max_value"]
    assert props["max_value"]["description"] == "Maximum value threshold"

    assert "description" in props["include_nulls"]
    assert props["include_nulls"]["description"] == "Whether to include null values"


def test_tc006_tool_with_nested_object_types(monkeypatch):
    """TC006: Handle tools with complex nested object types."""
    entry = {"transport": "http", "url": "https://example.com"}

    tool = Tool(
        name="configure_service",
        description="Configures a service",
        inputSchema={
            "type": "object",
            "properties": {
                "service_name": {
                    "type": "string",
                    "description": "Name of the service"
                },
                "config": {
                    "type": "object",
                    "description": "Configuration object",
                    "properties": {
                        "host": {
                            "type": "string",
                            "description": "Service host"
                        },
                        "port": {
                            "type": "integer",
                            "description": "Service port"
                        }
                    }
                }
            },
            "required": ["service_name", "config"]
        }
    )

    tools = [tool]

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=tools))

    result = runner.invoke(app, ["tools", "demo", "configure_service", "--json-out"])

    assert result.exit_code == 0, f"Command failed: {result.output}"
    data = json.loads(result.output)

    # Verify nested structure is preserved
    props = data["inputSchema"]["properties"]
    assert "config" in props
    assert props["config"]["type"] == "object"
    assert "properties" in props["config"]
    assert "host" in props["config"]["properties"]
    assert props["config"]["properties"]["host"]["description"] == "Service host"


# ============================================================================
# Error Handling and Edge Cases
# ============================================================================

def test_tool_not_found_error(monkeypatch):
    """Test that requesting a non-existent tool returns an error."""
    entry = {"transport": "http", "url": "https://example.com"}

    tool = Tool(
        name="existing_tool",
        description="An existing tool",
        inputSchema={"type": "object", "properties": {}}
    )

    tools = [tool]

    _patch_registry(monkeypatch, entry)
    _patch_client(monkeypatch, lambda entry, token_store=None: FakeClient(tools=tools))

    result = runner.invoke(app, ["tools", "demo", "nonexistent_tool"])

    # Should fail with non-zero exit code
    assert result.exit_code != 0, f"Expected error but got success: {result.output}"


def test_unknown_server_error(monkeypatch):
    """Test that requesting tools from an unknown server returns an error."""
    def fake_get_registry():
        return FakeReg(None)  # Will return None for any server

    import mcpctl.cli as cli
    monkeypatch.setattr(cli, "_get_registry", fake_get_registry)

    result = runner.invoke(app, ["tools", "unknown_server", "some_tool"])

    assert result.exit_code != 0, f"Expected error but got success: {result.output}"
