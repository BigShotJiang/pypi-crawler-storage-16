"""Callback handlers for MCPEvolve."""
