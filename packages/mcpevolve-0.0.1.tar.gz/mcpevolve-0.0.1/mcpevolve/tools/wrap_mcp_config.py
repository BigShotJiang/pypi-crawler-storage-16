"""CLI tool to wrap existing MCP servers from an mcp.json config file.

Usage:
    mcpevolve-wrap --mcp-config ~/.cursor/mcp.json

This will:
- Read your existing mcp.json
- For each server, create a wrapped proxy config
- Add <server>-plus entries to your mcp.json
- Store proxy configs in ~/.mcpevolve/configs/

Requires OPENAI_API_KEY environment variable to be set.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional


def _load_json(path: Path) -> Dict[str, Any]:
    """Load JSON file, return empty dict if doesn't exist."""
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _write_json(path: Path, data: Dict[str, Any]) -> None:
    """Write JSON file with pretty formatting."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
        f.write("\n")


def _get_config_dir() -> Path:
    """Get the mcpevolve config directory."""
    return Path.home() / ".mcpevolve" / "configs"


def _build_proxy_config(
    upstream: str,
    server_name: str,
    command: str,
    args: List[str],
    env: Optional[Dict[str, str]] = None,
    llm_model: str = "gpt-4.1",
    llm_api_key_env: str = "OPENAI_API_KEY",
    token_threshold: int = 400,
    post_processor_type: str = "extract",
) -> Dict[str, Any]:
    """Build a proxy wrapper config for the given upstream server."""
    return {
        "upstream_server": upstream,
        "server_name": server_name,
        "transport": "stdio",
        "upstream_address": "",
        "timeout": 30,
        "upstream_command": command,
        "upstream_args": args,
        "upstream_env": env or {},
        "llm": {
            "name": "openai",
            "config": {
                "model_name": llm_model,
                "api_key": f"${llm_api_key_env}",
            },
        },
        "wrapper": {
            "enabled": True,
            "token_threshold": token_threshold,
            "use_agent_llm": False,
            "post_process_llm": None,
            "enable_memory": True,
            "execution_timeout": 10,
            "max_iterations": 3,
            "post_processor_type": post_processor_type,
            "enable_reflection": True,
            "max_tool_output_chars": None,
        },
    }


def _build_cursor_entry(
    server_name: str,
    config_path: Path,
    llm_api_key_env: str = "OPENAI_API_KEY",
) -> Dict[str, Any]:
    """Build an MCP server entry for Cursor/Claude config."""
    return {
        "command": "python3",
        "args": [
            "-m",
            "mcpevolve.mcp.proxy_server",
            "--config",
            str(config_path),
            "--transport",
            "stdio",
        ],
        "env": {
            llm_api_key_env: f"${llm_api_key_env}",
        },
    }


def _parse_mcp_config(config_path: Path) -> Dict[str, Dict[str, Any]]:
    """Parse an mcp.json file and extract server definitions."""
    data = _load_json(config_path)

    # Handle both flat format and nested mcpServers format
    if "mcpServers" in data:
        return data.get("mcpServers", {})

    # Assume flat format where keys are server names
    return {k: v for k, v in data.items() if isinstance(v, dict) and "command" in v}


def wrap_servers(
    mcp_config_path: Path,
    servers: Optional[List[str]] = None,
    llm_model: str = "gpt-4.1",
    llm_api_key_env: str = "OPENAI_API_KEY",
    dry_run: bool = False,
    output_path: Optional[Path] = None,
) -> Dict[str, Any]:
    """
    Wrap MCP servers from a config file.

    Args:
        mcp_config_path: Path to the mcp.json file
        servers: List of server names to wrap (None = all)
        llm_model: LLM model to use for post-processing
        llm_api_key_env: Environment variable name for API key
        dry_run: If True, don't write files, just print what would be done
        output_path: Path to write the updated config (default: same as input)

    Returns:
        The updated config dict
    """
    config_dir = _get_config_dir()
    existing_servers = _parse_mcp_config(mcp_config_path)

    if not existing_servers:
        print(f"No MCP servers found in {mcp_config_path}", file=sys.stderr)
        sys.exit(1)

    # Filter to requested servers
    if servers:
        missing = set(servers) - set(existing_servers.keys())
        if missing:
            print(f"Servers not found in config: {missing}", file=sys.stderr)
            sys.exit(1)
        servers_to_wrap = {k: v for k, v in existing_servers.items() if k in servers}
    else:
        # Skip servers that are already -plus versions
        servers_to_wrap = {k: v for k, v in existing_servers.items() if not k.endswith("-plus")}

    if not servers_to_wrap:
        print("No servers to wrap (all may already be wrapped)", file=sys.stderr)
        sys.exit(0)

    print(f"Wrapping {len(servers_to_wrap)} server(s): {list(servers_to_wrap.keys())}")

    # Load full config to preserve structure
    full_config = _load_json(mcp_config_path)
    if "mcpServers" in full_config:
        servers_section = full_config["mcpServers"]
    else:
        servers_section = full_config

    new_entries = {}

    for name, server_cfg in servers_to_wrap.items():
        plus_name = f"{name}-plus"

        # Extract command/args from server config
        command = server_cfg.get("command", "")
        args = server_cfg.get("args", [])
        env = server_cfg.get("env", {})

        if not command:
            print(f"  Skipping {name}: no command found")
            continue

        # Build proxy config
        proxy_config = _build_proxy_config(
            upstream=name,
            server_name=plus_name,
            command=command,
            args=args,
            env=env,
            llm_model=llm_model,
            llm_api_key_env=llm_api_key_env,
        )

        # Write proxy config file
        proxy_config_path = config_dir / f"proxy_{name}.json"

        if dry_run:
            print(f"  Would create: {proxy_config_path}")
        else:
            _write_json(proxy_config_path, proxy_config)
            print(f"  Created: {proxy_config_path}")

        # Build cursor entry
        cursor_entry = _build_cursor_entry(
            server_name=plus_name,
            config_path=proxy_config_path,
            llm_api_key_env=llm_api_key_env,
        )
        new_entries[plus_name] = cursor_entry

    # Add new entries to config
    servers_section.update(new_entries)

    # Write updated config
    output = output_path or mcp_config_path
    if dry_run:
        print(f"\nWould update: {output}")
        print("\nNew entries that would be added:")
        print(json.dumps(new_entries, indent=2))
    else:
        _write_json(output, full_config)
        print(f"\nUpdated: {output}")
        print(f"\nAdded {len(new_entries)} wrapped server(s)")

    return full_config


def parse_args() -> argparse.Namespace:
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Wrap existing MCP servers with MCPEvolve post-processing.",
        epilog="Example: mcpevolve-wrap --mcp-config ~/.cursor/mcp.json",
    )
    parser.add_argument(
        "--mcp-config",
        required=True,
        help="Path to your mcp.json config file (e.g., ~/.cursor/mcp.json)",
    )
    parser.add_argument(
        "--servers",
        nargs="+",
        help="Specific server names to wrap (default: all)",
    )
    parser.add_argument(
        "--llm-model",
        default="gpt-4.1",
        help="LLM model for post-processing (default: gpt-4.1)",
    )
    parser.add_argument(
        "--llm-api-key-env",
        default="OPENAI_API_KEY",
        help="Env var name for LLM API key (default: OPENAI_API_KEY)",
    )
    parser.add_argument(
        "--output",
        help="Path to write updated config (default: overwrite input)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be done without making changes",
    )
    return parser.parse_args()


def main() -> None:
    """Entry point for mcpevolve-wrap command."""
    args = parse_args()

    mcp_config_path = Path(args.mcp_config).expanduser().resolve()
    if not mcp_config_path.exists():
        print(f"Config file not found: {mcp_config_path}", file=sys.stderr)
        sys.exit(1)

    # Check for API key
    api_key_env = args.llm_api_key_env
    if not os.environ.get(api_key_env) and not args.dry_run:
        print(f"Warning: {api_key_env} environment variable is not set.", file=sys.stderr)
        print(f"Set it with: export {api_key_env}=sk-...", file=sys.stderr)
        print("Continuing anyway (key will be needed at runtime)...\n", file=sys.stderr)

    output_path = Path(args.output).expanduser().resolve() if args.output else None

    wrap_servers(
        mcp_config_path=mcp_config_path,
        servers=args.servers,
        llm_model=args.llm_model,
        llm_api_key_env=api_key_env,
        dry_run=args.dry_run,
        output_path=output_path,
    )

    if not args.dry_run:
        print("\nDone! Reload your MCP client to use the wrapped servers.")


if __name__ == "__main__":
    main()
