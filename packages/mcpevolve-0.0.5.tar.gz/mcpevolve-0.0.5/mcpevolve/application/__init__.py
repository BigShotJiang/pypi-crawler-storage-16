"""
Application layer for MCP code generation and evaluation pipelines.
"""
