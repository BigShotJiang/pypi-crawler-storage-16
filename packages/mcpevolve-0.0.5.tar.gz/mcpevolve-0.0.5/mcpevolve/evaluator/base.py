"""
Base classes and data models for evaluators.
"""
# pylint: disable=unused-argument
import os.path
from typing import List, Dict, Any, Union, Optional
from abc import abstractmethod
from dataclasses import dataclass
from pydantic import BaseModel, Field
from mcpuniverse.llm.base import BaseLLM
from mcpevolve.common.misc import ComponentABCMeta
from mcpevolve.common.config import BaseConfig


class EvaluatorInput(BaseModel):
    """
    Input data for evaluator operations.
    
    Attributes:
        project_folder: Root directory of the project being evaluated.
        code_files: List of code file paths to evaluate.
        code_snippets: List of code snippets to evaluate directly.
        test_files: List of test file paths.
        metadata: Additional metadata for evaluation context.
    """
    project_folder: str = ""
    code_files: List[str] = Field(default_factory=list)
    code_snippets: List[str] = Field(default_factory=list)
    test_files: List[str] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class EvaluatorOutput(BaseModel):
    """
    Output data from evaluator operations.
    
    Attributes:
        success: Whether the evaluation completed successfully.
        message: Human-readable status or error message.
        metrics: Dictionary of numeric evaluation metrics.
        feedback: Detailed feedback from the evaluation.
    """
    success: bool
    message: str
    metrics: Dict[str, float]
    feedback: str


@dataclass
class BaseEvaluatorConfig(BaseConfig):
    """Base configuration class for evaluators."""


class BaseEvaluator(metaclass=ComponentABCMeta):
    """Abstract base class for all evaluators."""

    def __init__(
            self,
            config: Optional[Union[Dict, str]] = None,
            llm: Optional[BaseLLM] = None,
            **kwargs
    ):
        """
        Initialize the evaluator.
        
        Args:
            config: Configuration dict or path to config file.
            llm: Language model for evaluation tasks.
            **kwargs: Additional initialization arguments.
        """
        self._config = self.config_class.load(config)
        self._llm = llm

    @abstractmethod
    async def evaluate(self, param: EvaluatorInput) -> EvaluatorOutput:
        """
        Evaluate code based on input parameters.
        
        Args:
            param: Input parameters for evaluation.
            
        Returns:
            EvaluatorOutput: Results of the evaluation.
        """

    @abstractmethod
    def get_metric_list(self) -> List[str]:
        """
        Get list of metrics this evaluator provides.
        
        Returns:
            List of metric names.
        """

    def allow_parallel(self) -> bool:
        """
        Whether this evaluator supports parallel execution.
        
        Returns:
            False by default, subclasses can override.
        """
        return False

    @staticmethod
    def read_code(param: EvaluatorInput) -> str:
        """
        Read code from input parameters.
        
        Args:
            param: Input containing code files or snippets.
            
        Returns:
            Combined code content as a string.
            
        Raises:
            RuntimeError: If specified code files are not found.
        """
        if param.code_snippets:
            return "\n\n".join(param.code_snippets)
        codes = []
        for file in param.code_files:
            if os.path.exists(file):
                path = file
            else:
                path = os.path.join(param.project_folder, file)
                if not os.path.exists(path):
                    raise RuntimeError(f"File not found: {path}")
            with open(path, "r", encoding="utf-8") as f:
                codes.append(f.read())
        return "\n\n".join(codes)
