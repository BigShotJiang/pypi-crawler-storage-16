"""
Naive evaluator for basic testing and demonstration purposes.
"""
from dataclasses import dataclass
from typing import Dict, Union, Optional, List
from mcpevolve.evaluator.base import (
    BaseEvaluatorConfig,
    BaseEvaluator,
    EvaluatorInput,
    EvaluatorOutput
)
from mcpevolve.common.logger import get_logger


@dataclass
class NaiveEvaluatorConfig(BaseEvaluatorConfig):
    """Configuration for NaiveEvaluator with optional ID field."""
    id: str = ""


class NaiveEvaluator(BaseEvaluator):
    """
    Simple evaluator that always returns success for testing purposes.
    """
    config_class = NaiveEvaluatorConfig
    alias = ["naive"]

    def __init__(self, config: Optional[Union[Dict, str]] = None, **kwargs):
        """
        Initialize the NaiveEvaluator.
        
        Args:
            config: Configuration dict or JSON string.
            **kwargs: Additional initialization arguments.
        """
        super().__init__(config=config, **kwargs)
        self._logger = get_logger(self.__class__.__name__)

    async def evaluate(self, param: EvaluatorInput) -> EvaluatorOutput:
        """
        Perform naive evaluation that always succeeds.
        
        Args:
            param: Input parameters (serialized as message).
            
        Returns:
            EvaluatorOutput: Always successful with naive_score of 1.0.
        """
        message = param.model_dump_json()
        return EvaluatorOutput(
            success=True,
            message=message,
            metrics={"naive_score": 1.0},
            feedback=self._config.id
        )

    def get_metric_list(self) -> List[str]:
        """
        Get list of metrics provided by this evaluator.
        
        Returns:
            List containing 'naive_score' metric name.
        """
        return ["naive_score"]

    def allow_parallel(self) -> bool:
        """
        Whether this evaluator supports parallel execution.
        
        Returns:
            True, as this evaluator can run in parallel.
        """
        return True
