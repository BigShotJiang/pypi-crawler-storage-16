"""
Example: Running Benchmarks with Wrapper Support

EXISTING (Standard MCPUniverse usage):
- Import BenchmarkRunner from mcpuniverse.benchmark.runner
- Loads benchmark config and runs with standard MCP clients
- Prints results to console

THIS IMPLEMENTATION:
- Import BenchmarkRunnerWithWrapper from mcpevolve.application.benchmark_runner
- Automatically detects wrapper configs in YAML
- Wraps MCP clients with PostProcessAgent when configured
- Generates markdown report with BenchmarkReport
- Prints colored evaluation results to console
"""
import asyncio
from mcpuniverse.tracer.collectors import FileCollector
from mcpuniverse.callbacks.handlers.vprint import get_vprint_callbacks
from mcpevolve.application.benchmark_runner import BenchmarkRunnerWithWrapper
from mcpevolve.application.report import BenchmarkReportWithWrapper


async def main():
    """Run benchmark with wrapper support."""
    # Initialize file-based trace collector
    trace_collector = FileCollector(log_file="log/playwright.log")

    # Create benchmark runner with wrapper support
    # This config includes wrapper configuration for post-processing
    benchmark = BenchmarkRunnerWithWrapper(
        "mcpevolve/examples/benchmark_with_separate_llm_test.yaml"
    )

    # Run benchmark with verbose callbacks
    # Metrics are now extracted from tracer instead of callbacks
    vprint_callbacks = get_vprint_callbacks()

    results = await benchmark.run(
        trace_collector=trace_collector,
        callbacks=vprint_callbacks
    )
    print(results)

    # Generate markdown report with wrapper support
    report = BenchmarkReportWithWrapper(benchmark, trace_collector)
    report.dump()

    # Print evaluation results with color coding
    print('=' * 66)
    print('Evaluation Result')
    print('-' * 66)
    for task_name in results[0].task_results.keys():
        print(task_name)
        print('-' * 66)
        # Access evaluation_results key (matches MCPUniverse format)
        eval_results = results[0].task_results[task_name]['evaluation_results']
        for eval_result in eval_results:
            print("func:", eval_result.config.func)
            print("op:", eval_result.config.op)
            print("op_args:", eval_result.config.op_args)
            print("value:", eval_result.config.value)
            print('Passed?:', "\033[32mTrue\033[0m" if eval_result.passed else "\033[31mFalse\033[0m")
            print('-' * 66)


if __name__ == "__main__":
    asyncio.run(main())
