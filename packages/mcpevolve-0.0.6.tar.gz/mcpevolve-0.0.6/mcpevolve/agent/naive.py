"""
Naive agent implementation for basic MCP operations.
"""
from typing import Optional, Union, Dict, List
from dataclasses import dataclass
from mcpuniverse.mcp.manager import MCPManager
from mcpuniverse.llm.base import BaseLLM
from mcpuniverse.common.logger import get_logger
from mcpuniverse.tracer import Tracer
from mcpuniverse.agent.base import BaseAgentConfig, BaseAgent
from mcpuniverse.agent.utils import build_system_prompt
from mcpuniverse.agent.types import AgentResponse


@dataclass
class NaiveAgentConfig(BaseAgentConfig):
    """Configuration for NaiveAgent, inherits from BaseAgentConfig."""


class NaiveAgent(BaseAgent):
    """
    Simple agent for testing purpose.
    """

    config_class = NaiveAgentConfig
    alias = ["naive"]

    def __init__(
            self,
            mcp_manager: Optional[MCPManager] = None,
            llm: BaseLLM = None,
            config: Optional[Union[Dict, str]] = None
    ):
        """
        Initialize the NaiveAgent.
        
        Args:
            mcp_manager: Optional MCP manager.
            llm: Language model for generating responses (required).
            config: Configuration dict or JSON string.
            
        Raises:
            AssertionError: If llm is None.
        """
        assert llm is not None, "LLM cannot be None"
        super().__init__(mcp_manager=mcp_manager, llm=llm, config=config)
        self._logger = get_logger(f"{self.__class__.__name__}:{self._name}")

    async def _execute(
            self,
            message: Union[str, List[str]],
            output_format: Optional[Union[str, Dict]] = None,
            **kwargs
    ) -> AgentResponse:
        """
        Execute agent task given user input message.
        
        Args:
            message: User message or list of messages to process.
            output_format: Optional format specification for response.
            **kwargs: Additional arguments including tracer and callbacks.
            
        Returns:
            AgentResponse: Response containing generated content and metadata.
        """
        params = {"INSTRUCTION": self._config.instruction}
        params.update(self._config.template_vars)
        prompt = build_system_prompt(
            system_prompt_template=self._config.system_prompt,
            tool_prompt_template=self._config.tools_prompt,
            tools=None,
            **params
        )
        if isinstance(message, (list, tuple)):
            message = "\n".join(message)
        if output_format is not None:
            message = message + "\n\n" + self._get_output_format_prompt(output_format)
        tracer = kwargs.get("tracer", Tracer())
        callbacks = kwargs.get("callbacks", [])

        response = await self._llm.generate_async(
            messages=[{"role": "system", "content": prompt},
                      {"role": "user", "content": message}],
            tracer=tracer,
            callbacks=callbacks,
            remote_mcp=self.get_remote_mcp_list()
        )
        return AgentResponse(
            name=self._name,
            class_name=self.__class__.__name__,
            response=response,
            trace_id=tracer.trace_id
        )
