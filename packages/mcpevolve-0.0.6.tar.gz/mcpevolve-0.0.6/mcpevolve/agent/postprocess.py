"""
Post-process agent for filtering structured tool outputs.

This agent generates Python code to filter and extract relevant information
from long structured tool outputs based on expected information.
"""
# pylint: disable=broad-exception-caught
import json
from typing import Any, Dict, List, Optional
from datetime import datetime

from mcpuniverse.llm.base import BaseLLM
from mcpuniverse.common.logger import get_logger
from mcpuniverse.mcp.wrapper import SafeCodeExecutor


FILTER_CODE_GENERATION_PROMPT = """
You are a code generation assistant. Your task is to write Python code that extracts specific information from tool output based on the agent's stated goal.

Tool: {tool_name}
{tool_description_section}

Tool Output (first 2000 chars):
{tool_output_preview}

Agent's Goal: {expected_info}

{memory_section}

Your task is to analyze whether post-processing is needed and generate appropriate Python code.

DECISION FRAMEWORK:
1. If the agent explicitly states "all information is needed" or similar → Set result = data (no filtering)
2. If the tool output is small/simple and already matches what's needed → Set result = data (no filtering)
3. If specific information needs to be extracted from large/complex output → Write extraction code
4. If the agent's goal is vague or unclear → Set result = data (preserve all information when in doubt)

CODE GENERATION GUIDELINES:
- The input will be available as the variable `data` (always a string)
- Store the result in a variable called `result`
- Handle different data formats: JSON, HTML, plain text, XML, etc.
- If extraction is needed, be precise: extract ONLY what matches the agent's goal
- Include error handling (try/except) for parsing operations
- Keep code concise but readable
- Only use safe imports: json, re, datetime, math, collections, itertools
- Only use safe built-ins (no eval, exec, open, file operations, etc.)

EXAMPLES:

Example 1 - Extract specific field from JSON:
Agent's Goal: "The status field from the API response, needed to determine if the operation succeeded"
```python
import json
try:
    parsed = json.loads(data)
    result = str(parsed.get('status', 'Status not found'))
except:
    result = data
```

Example 2 - Extract list items from JSON:
Agent's Goal: "List of IDs from the items array, needed to make subsequent API calls for each item"
```python
import json
try:
    parsed = json.loads(data)
    items = parsed.get('items', [])
    ids = [str(item.get('id', '')) for item in items if 'id' in item]
    result = "\\n".join(ids) if ids else "No IDs found"
except:
    result = data
```

Example 3 - Extract links from HTML:
Agent's Goal: "All hyperlink URLs from the HTML content, needed to navigate to linked pages"
```python
import re
try:
    # Extract href attributes
    urls = re.findall(r'href=["\']([^"\']+)["\']', data)
    result = "\\n".join(urls) if urls else "No URLs found"
except:
    result = data
```

Example 4 - Extract specific pattern with regex:
Agent's Goal: "Email addresses from the text, needed to contact the listed individuals"
```python
import re
try:
    emails = re.findall(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{{2,}}', data)
    result = "\\n".join(emails) if emails else "No email addresses found"
except:
    result = data
```

Example 5 - All information needed:
Agent's Goal: "All information is needed because I need to analyze the complete response structure"
```python
result = data
```

Example 6 - Already concise output:
Agent's Goal: "The error message text"
(Output is already just an error message, 45 chars)
```python
result = data
```

IMPORTANT: When in doubt about what to extract, prefer returning the original data (result = data) rather than accidentally filtering out important information.

Output ONLY the Python code, no explanations. The code should be executable as-is.
""".strip()


class PostProcessAgent:
    """
    Post-processing agent that generates and executes filter code.

    This agent maintains session memory to reuse successful filter code
    for similar queries within the same session.
    """

    def __init__(
        self,
        llm: BaseLLM,
        safe_executor: SafeCodeExecutor,
        enable_memory: bool = True
    ):
        """
        Initialize the post-process agent.

        Args:
            llm: Language model for code generation.
            safe_executor: Safe code executor with restrictions.
            enable_memory: Enable session memory for code reuse.
        """
        self._llm = llm
        self._safe_executor = safe_executor
        self._enable_memory = enable_memory
        self._session_memory: List[Dict[str, Any]] = []
        self._logger = get_logger(self.__class__.__name__)

    async def process(
        self,
        tool_output: str,
        expected_info: str,
        tool_name: str,
        tool_description: Optional[str] = None
    ) -> str:
        """
        Process tool output by generating and executing filter code.

        This method:
        1. Checks session memory for existing successful code
        2. Reuses code if found, otherwise generates new code
        3. Executes the filter code
        4. Updates session memory with results

        Args:
            tool_output: Raw tool output to filter.
            expected_info: Description of expected information.
            tool_name: Name of the tool that produced the output.
            tool_description: Optional description of what the tool does.

        Returns:
            Filtered output as string.

        Raises:
            Exception: If code generation or execution fails.
        """
        self._logger.info(
            "Processing output for tool=%s, expected_info=%s",
            tool_name, expected_info
        )

        # Check memory for existing successful code
        cached_code = self._find_in_memory(tool_name, expected_info)

        if cached_code:
            self._logger.info("Found cached code in session memory, reusing")
            filter_code = cached_code
        else:
            # Generate new filter code
            self._logger.info("Received tool output:\n%s...%s (%d chars)\n", tool_output[:100], tool_output[-100:],
                              len(tool_output))
            self._logger.info("Generating new filter code via LLM")
            filter_code = await self.generate_filter_code(
                tool_output=tool_output,
                expected_info=expected_info,
                tool_name=tool_name,
                tool_description=tool_description
            )
        
        self._logger.info("Generated code:\n```\n%s\n```\n\n", filter_code)
        # Execute the filter code
        try:
            filtered_output = self._safe_executor.execute(filter_code, tool_output)

            # Update memory with successful execution
            self._add_to_memory(
                tool_name=tool_name,
                expected_info=expected_info,
                filter_code=filter_code,
                success=True,
                error=None,
                output_length=len(tool_output),
                filtered_length=len(str(filtered_output))
            )

            self._logger.info(
                "Successfully filtered output: %d → %d chars",
                len(tool_output), len(str(filtered_output))
            )
            self._logger.info(
                    "Filtered Output: %s", filtered_output)

            return str(filtered_output)

        except Exception as e:
            # Update memory with failed execution
            self._add_to_memory(
                tool_name=tool_name,
                expected_info=expected_info,
                filter_code=filter_code,
                success=False,
                error=str(e),
                output_length=len(tool_output),
                filtered_length=0
            )

            self._logger.error("Filter code execution failed: %s", str(e))
            raise

    async def generate_filter_code(
        self,
        tool_output: str,
        expected_info: str,
        tool_name: str,
        tool_description: Optional[str] = None
    ) -> str:
        """
        Generate Python filter code using LLM.

        Args:
            tool_output: Raw tool output (will be truncated for prompt).
            expected_info: Description of expected information.
            tool_name: Name of the tool.
            tool_description: Optional description of what the tool does.

        Returns:
            Generated Python code as string.
        """
        # Truncate output for prompt (show first 2000 chars)
        tool_output_preview = tool_output[:2000]
        if len(tool_output) > 2000:
            tool_output_preview += "\n... (truncated)"

        # Escape curly braces in dynamic content to prevent format string issues
        tool_output_preview = tool_output_preview.replace('{', '{{').replace('}', '}}')
        expected_info_escaped = expected_info.replace('{', '{{').replace('}', '}}')
        tool_name_escaped = tool_name.replace('{', '{{').replace('}', '}}')

        # Build tool description section
        tool_description_section = ""
        if tool_description:
            tool_description_escaped = tool_description.replace('{', '{{').replace('}', '}}')
            tool_description_section = f"Tool Description: {tool_description_escaped}\n"

        # Build memory section with relevant past examples
        memory_section = self._build_memory_section(tool_name)

        # Build prompt
        prompt = FILTER_CODE_GENERATION_PROMPT.format(
            tool_name=tool_name_escaped,
            tool_description_section=tool_description_section,
            expected_info=expected_info_escaped,
            tool_output_preview=tool_output_preview,
            memory_section=memory_section
        )

        # Generate code via LLM
        response = await self._llm.generate_async(
            messages=[{"role": "user", "content": prompt}]
        )

        # Clean up response (remove markdown code blocks if present)
        code = response.strip()
        if code.startswith("```"):
            # Remove ```python or ``` at start
            lines = code.split("\n")
            if lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            code = "\n".join(lines)

        self._logger.debug("Generated filter code:\n%s", code)

        return code

    def _build_memory_section(self, tool_name: str) -> str:
        """
        Build a memory section showing relevant past examples (success and failure) for the same tool.

        Args:
            tool_name: Tool name to find relevant examples for.

        Returns:
            Formatted memory section string, or empty string if no relevant memory.
        """
        if not self._enable_memory or not self._session_memory:
            return ""

        # Find past executions for the same tool
        relevant_entries = [
            entry for entry in self._session_memory
            if entry["tool_name"] == tool_name
        ]

        if not relevant_entries:
            return ""

        # Separate successful and failed attempts
        successful = [e for e in relevant_entries if e["success"]]
        failed = [e for e in relevant_entries if not e["success"]]

        memory_lines = ["\nPrevious Examples (for reference):"]

        # Show up to 3 most recent successful examples
        if successful:
            memory_lines.append("\nSuccessful Examples:")
            for i, entry in enumerate(reversed(successful[-3:]), 1):
                memory_lines.append(f"\n  Example {i}:")
                memory_lines.append(f"    Expected Info: {entry['expected_info']}")
                memory_lines.append(f"    Code Used:")
                # Indent the code
                code_lines = entry['filter_code'].split('\n')
                for line in code_lines:
                    memory_lines.append(f"      {line}")
                memory_lines.append(f"    Result: Reduced from {entry['output_length']} to {entry['filtered_length']} chars")

        # Show up to 2 most recent failed examples to learn from mistakes
        if failed:
            memory_lines.append("\nFailed Examples (avoid these patterns):")
            for i, entry in enumerate(reversed(failed[-2:]), 1):
                memory_lines.append(f"\n  Failed Example {i}:")
                memory_lines.append(f"    Expected Info: {entry['expected_info']}")
                memory_lines.append(f"    Code Attempted:")
                code_lines = entry['filter_code'].split('\n')
                for line in code_lines:
                    memory_lines.append(f"      {line}")
                memory_lines.append(f"    Error: {entry['error']}")

        return "\n".join(memory_lines)

    def _find_in_memory(
        self,
        tool_name: str,
        expected_info: str
    ) -> Optional[str]:
        """
        Search session memory for successful code with matching criteria.

        Args:
            tool_name: Tool name to match.
            expected_info: Expected info to match.

        Returns:
            Filter code if found, None otherwise.
        """
        if not self._enable_memory:
            return None

        # Search memory in reverse order (most recent first)
        for entry in reversed(self._session_memory):
            if (entry["tool_name"] == tool_name and
                entry["expected_info"] == expected_info and
                entry["success"]):
                return entry["filter_code"]

        return None

    def _add_to_memory(
        self,
        tool_name: str,
        expected_info: str,
        filter_code: str,
        success: bool,
        error: Optional[str],
        output_length: int,
        filtered_length: int
    ):
        """
        Add execution record to session memory.

        Args:
            tool_name: Name of the tool.
            expected_info: Expected information description.
            filter_code: Generated filter code.
            success: Whether execution succeeded.
            error: Error message if failed.
            output_length: Length of original output.
            filtered_length: Length of filtered output.
        """
        if not self._enable_memory:
            return

        memory_entry = {
            "tool_name": tool_name,
            "expected_info": expected_info,
            "filter_code": filter_code,
            "success": success,
            "error": error,
            "output_length": output_length,
            "filtered_length": filtered_length,
            "timestamp": datetime.now().isoformat()
        }

        self._session_memory.append(memory_entry)

        self._logger.debug(
            "Added to session memory: tool=%s, success=%s, entries=%d",
            tool_name, success, len(self._session_memory)
        )

    def get_memory(self) -> List[Dict[str, Any]]:
        """
        Get the current session memory.

        Returns:
            List of memory entries.
        """
        return self._session_memory.copy()

    def clear_memory(self):
        """Clear the session memory."""
        self._session_memory.clear()
        self._logger.info("Session memory cleared")

    def get_memory_summary(self) -> Dict[str, Any]:
        """
        Get a summary of the session memory.

        Returns:
            Dictionary with memory statistics.
        """
        if not self._session_memory:
            return {
                "total_entries": 0,
                "successful": 0,
                "failed": 0,
                "unique_tools": 0,
                "unique_queries": 0
            }

        successful = sum(1 for entry in self._session_memory if entry["success"])
        failed = len(self._session_memory) - successful
        unique_tools = len(set(entry["tool_name"] for entry in self._session_memory))
        unique_queries = len(set(
            f"{entry['tool_name']}:{entry['expected_info']}"
            for entry in self._session_memory
        ))

        return {
            "total_entries": len(self._session_memory),
            "successful": successful,
            "failed": failed,
            "unique_tools": unique_tools,
            "unique_queries": unique_queries
        }
