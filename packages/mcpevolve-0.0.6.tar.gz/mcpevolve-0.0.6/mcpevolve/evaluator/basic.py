"""
Basic evaluator for code quality analysis using LLM.
"""
# pylint: disable=broad-exception-caught
import json
from dataclasses import dataclass
from typing import Dict, Union, Optional, List
from mcpuniverse.llm.base import BaseLLM
from mcpuniverse.llm.utils import extract_json_output
from mcpevolve.evaluator.base import (
    BaseEvaluatorConfig,
    BaseEvaluator,
    EvaluatorInput,
    EvaluatorOutput
)
from mcpevolve.common.logger import get_logger


@dataclass
class BasicEvaluatorConfig(BaseEvaluatorConfig):
    """
    Configuration for BasicEvaluator with system prompt for code analysis.
    """
    system_prompt: str = """
You are an expert Python code review agent specializing in detecting anti-patterns and performance issues. 
Your task is to analyze the given Python code and provide detailed feedback on performance-related concerns, 
highlighting inefficient constructs, unnecessary complexity, or potential optimizations.

## Analysis Scope
IMPORTANT: Only identify issues that can be fixed by modifying the given code itself. 
Do NOT flag problems that would require:
- Changing external dependencies or libraries
- Modifying other files or classes not shown
- Changing system architecture or infrastructure
- Adding new external packages

## Output Format
Respond in valid JSON only, with the following fields:
{
  "anti_patterns": [
    {
      "issue": "Description of the performance issue or anti-pattern",
      "location": "Line number(s) or code snippet where the issue occurs",
      "recommendation": "Suggested fix or optimization"
    }
  ],
  "quality_score": "An integer from 1 to 10, where 10 means excellent code with no major performance concerns"
}
    """


class BasicEvaluator(BaseEvaluator):
    """
    LLM-based evaluator for Python code quality and performance analysis.
    """
    config_class = BasicEvaluatorConfig
    alias = ["basic"]

    def __init__(self, config: Optional[Union[Dict, str]] = None, llm: BaseLLM = None, **kwargs):
        """
        Initialize the BasicEvaluator.
        
        Args:
            config: Configuration dict or JSON string.
            llm: Language model for code evaluation (required).
            **kwargs: Additional initialization arguments.
            
        Raises:
            AssertionError: If llm is None.
        """
        assert llm is not None, "LLM cannot be None"
        super().__init__(config=config, llm=llm, **kwargs)
        self._logger = get_logger(self.__class__.__name__)

    async def evaluate(self, param: EvaluatorInput) -> EvaluatorOutput:
        """
        Evaluate code quality using LLM analysis.
        
        Args:
            param: Input parameters containing code to evaluate.
            
        Returns:
            EvaluatorOutput: Results with quality score and anti-pattern feedback.
        """
        user_message = self.read_code(param)
        result = None
        for _ in range(5):
            response = await self._llm.get_response_async(
                system_message=self._config.system_prompt,
                user_message=user_message
            )
            jsons = extract_json_output(response)
            if len(jsons) == 1:
                result = jsons[0]
                break

        try:
            score = int(result["quality_score"])
            return EvaluatorOutput(
                success=True,
                message=json.dumps(result, indent=2),
                metrics={"code_quality_score": min(max(score, 0), 10) / 10.0},
                feedback=json.dumps(result.get("anti_patterns", ""), indent=2)
            )
        except Exception as e:
            self._logger.error("Failed to parse the code review output: %s", str(e))
            return EvaluatorOutput(
                success=False,
                message="",
                metrics={"code_quality_score": 0},
                feedback=""
            )

    def get_metric_list(self) -> List[str]:
        """
        Get list of metrics provided by this evaluator.
        
        Returns:
            List containing 'code_quality_score' metric name.
        """
        return ["code_quality_score"]

    def allow_parallel(self) -> bool:
        """
        Whether this evaluator supports parallel execution.
        
        Returns:
            True, as this evaluator can run in parallel.
        """
        return True
