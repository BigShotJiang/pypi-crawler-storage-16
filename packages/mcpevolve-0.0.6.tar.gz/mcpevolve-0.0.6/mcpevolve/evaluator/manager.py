"""
Manager for building and creating evaluator instances.
"""
from typing import Dict, Optional, List
from mcpuniverse.llm.base import BaseLLM
from mcpevolve.common.misc import BaseBuilder, ComponentABCMeta
from mcpevolve.evaluator.base import BaseEvaluator


class EvaluatorManager(BaseBuilder):
    """
    Factory for creating evaluator instances by class name.
    """

    _EVALUATORS = ComponentABCMeta.get_class("evaluator")

    def __init__(self):
        """Initialize the evaluator manager with available evaluator classes."""
        super().__init__()
        self._classes = self._name_to_class(EvaluatorManager._EVALUATORS)

    def build_evaluator(
            self,
            class_name: str,
            config: Optional[str | Dict] = None,
            llm: Optional[BaseLLM] = None,
            **kwargs
    ) -> BaseEvaluator:
        """
        Build an evaluator instance by class name.
        
        Args:
            class_name: Name of the evaluator class to instantiate.
            config: Configuration dict or JSON string.
            llm: Language model for evaluators that require it.
            **kwargs: Additional arguments passed to evaluator constructor.
            
        Returns:
            BaseEvaluator: Configured evaluator instance.
            
        Raises:
            ValueError: If class_name is not found in available evaluators.
        """
        if class_name not in self._classes:
            raise ValueError(f"Evaluator {class_name} is not found. "
                             f"Please choose agent from {list(self._classes.keys())}")
        return self._classes[class_name](config=config, llm=llm, **kwargs)

    def list_evaluators(self) -> List[str]:
        """
        List all available evaluator class names.
        
        Returns:
            List[str]: List of available evaluator class names.
        """
        return list(self._classes.keys())
