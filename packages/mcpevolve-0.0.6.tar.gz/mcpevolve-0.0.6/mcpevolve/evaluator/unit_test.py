"""
Unit test evaluator for measuring test pass/fail metrics.

This module provides the UnitTestEvaluator class that runs pytest on specified
test files and generates metrics based on test results.
"""
# pylint: disable=protected-access
import os
import json
import subprocess
from dataclasses import dataclass
from typing import Dict, Union, Optional, List
from junitparser import JUnitXml
from mcpevolve.evaluator.base import (
    BaseEvaluatorConfig,
    BaseEvaluator,
    EvaluatorInput,
    EvaluatorOutput
)
from mcpevolve.common.logger import get_logger


@dataclass
class UnitTestEvaluatorConfig(BaseEvaluatorConfig):
    """Configuration for UnitTestEvaluator with default settings."""


class UnitTestEvaluator(BaseEvaluator):
    """Evaluator that runs unit tests and reports pass/fail metrics."""
    config_class = UnitTestEvaluatorConfig
    alias = ["unittest", "unit-test"]

    def __init__(self, config: Optional[Union[Dict, str]] = None, **kwargs):
        """
        Initialize the UnitTestEvaluator.

        Args:
            config: Configuration dict or JSON string.
            **kwargs: Additional initialization arguments.
        """
        super().__init__(config=config, **kwargs)
        self._logger = get_logger(self.__class__.__name__)

    async def evaluate(self, param: EvaluatorInput) -> EvaluatorOutput:
        """
        Run unit tests and return evaluation results.

        Args:
            param: Input parameters containing test files and project folder.

        Returns:
            Evaluation output with success status, metrics, and feedback.
        """
        tests = []
        for file in param.test_files:
            if param.project_folder not in file:
                file = os.path.join(param.project_folder, file)
            if not os.path.exists(file):
                raise RuntimeError(f"Test file not found: {file}")
            tests.append(file)

        python_path = f"PYTHONPATH={param.project_folder}:$PYTHONPATH"
        report_path = os.path.join(param.project_folder, "report.xml")
        test_files = " ".join(tests)
        command = f"{python_path} pytest --junitxml={report_path} {test_files}"

        result = subprocess.run(command, shell=True, capture_output=True, text=True, check=False)
        if result.returncode == 0:
            return EvaluatorOutput(
                success=True,
                message=str(result.stdout),
                metrics={
                    "test_pass_score": 1.0,
                    "test_success_ratio": 1.0
                },
                feedback=""
            )

        failures = []
        num_failed, num_tests = 0, 0
        xml = JUnitXml.fromfile(report_path)
        for suite in xml:
            for case in suite:
                for info in case:
                    if info._tag.lower() in ["failure", "error"]:
                        failures.append({
                            "message": info.message,
                            "text": info.text
                        })
            num_tests += int(suite.tests) - int(suite.skipped)
            num_failed += int(suite.failures) + int(suite.errors)

        test_success_ratio = 1.0 - num_failed / max(1, num_tests)
        messages = [f"<error>\n{failure['text']}\n</error>" for failure in failures]
        return EvaluatorOutput(
            success=False,
            message=json.dumps(failures, indent=2),
            metrics={
                "test_pass_score": 0.0,
                "test_success_ratio": test_success_ratio
            },
            feedback="\n\n".join(messages)
        )

    def get_metric_list(self) -> List[str]:
        """
        Get list of metrics provided by this evaluator.

        Returns:
            List of metric names: test_pass_score and test_success_ratio.
        """
        return ["test_pass_score", "test_success_ratio"]
