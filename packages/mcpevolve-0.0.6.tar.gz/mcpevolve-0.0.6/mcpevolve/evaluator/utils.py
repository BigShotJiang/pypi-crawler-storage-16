"""
Utility classes and functions for evaluation operations.
"""
# pylint: disable=broad-exception-caught
import os
import fcntl
import threading
import re
import json
import hashlib
from typing import Any, List


class EvaluationLock:
    """
    File-based lock for preventing concurrent evaluations.
    """

    def __init__(self, folder):
        """
        Initialize evaluation lock with folder path.
        
        Args:
            folder: Directory where lock file will be created.
        """
        self._folder = folder
        self._file = None

    def _close_file(self):
        """Close the lock file safely."""
        try:
            if self._file:
                self._file.close()
        except Exception:
            pass
        self._file = None

    def __del__(self):
        """Cleanup lock file on deletion."""
        self._close_file()

    def __enter__(self):
        """Acquire exclusive file lock."""
        # Acquire exclusive lock on the file
        self._close_file()
        self._file = open(os.path.join(self._folder, "evaluate.lock"), "a", encoding="utf-8")
        fcntl.flock(self._file.fileno(), fcntl.LOCK_EX)

    def __exit__(self, exc_type, exc_value, traceback):
        """Release file lock and close file."""
        fcntl.flock(self._file.fileno(), fcntl.LOCK_UN)
        self._close_file()


class EvaluationThread(threading.Thread):
    """
    Thread subclass that captures and returns the result.
    """

    def __init__(self, *args, **kwargs):
        """
        Initialize thread with result storage.
        
        Args:
            *args: Arguments passed to threading.Thread.
            **kwargs: Keyword arguments passed to threading.Thread.
        """
        super().__init__(*args, **kwargs)
        self.result = None

    def run(self):
        """Execute the target function and store result."""
        if self._target:
            self.result = self._target(*self._args, **self._kwargs)

    def join(self, *args, **kwargs) -> Any:
        """
        Join thread and return the stored result.
        
        Args:
            *args: Arguments passed to threading.Thread.join.
            **kwargs: Keyword arguments passed to threading.Thread.join.
            
        Returns:
            The result from the target function execution.
        """
        super().join(*args, **kwargs)
        return self.result


def extract_json_output(response: str) -> List[dict]:
    """
    Extracts and parses JSON-formatted outputs from an LLM response.

    This function searches for JSON-like structures within the given response,
    attempts to parse them, and returns a list of successfully parsed JSON objects.

    Args:
        response (str): The raw text response from an LLM.

    Returns:
        List[dict]: A list of parsed JSON objects extracted from the response.
            Returns an empty list if no valid JSON structures are found.

    Note:
        The function first looks for JSON structures enclosed in ```json``` blocks.
        If none are found, it searches for any content within ``` blocks.
        Invalid JSON structures are silently ignored.
    """
    results = []
    pattern = r"```json(.*?)```"
    matches = re.finditer(pattern, response, re.DOTALL | re.IGNORECASE)
    for match in matches:
        results.append(match.groups()[0])

    if len(results) == 0:
        pattern = r"```(.*?)```"
        matches = re.finditer(pattern, response, re.DOTALL | re.IGNORECASE)
        for match in matches:
            results.append(match.groups()[0])

    outputs = []
    for r in results:
        try:
            d = json.loads(r)
            outputs.append(d)
        except Exception:
            pass
    return outputs


class FileWriter:
    """
    Context manager for temporarily replacing files with backup/restore.
    """

    def __init__(self, cache_folder: str, original_path: str, new_program_path: str):
        """
        Initialize file writer with paths.
        
        Args:
            cache_folder: Directory for storing backup files.
            original_path: Path to the original file to be replaced.
            new_program_path: Path to the new file content.
            
        Raises:
            RuntimeError: If original_path or new_program_path don't exist.
        """
        self.folder = os.path.join(cache_folder, "cache")
        if not os.path.exists(self.folder):
            os.makedirs(self.folder, exist_ok=True)
        if not os.path.exists(original_path):
            raise RuntimeError(f"File not found: {original_path}")
        self.original_path = original_path
        if not os.path.exists(new_program_path):
            raise RuntimeError(f"File not found: {new_program_path}")
        self.new_program_path = new_program_path

    def __enter__(self):
        """Backup original file and replace with new content."""
        name = hashlib.md5(self.original_path.encode()).hexdigest()
        # Backup the original program
        with open(self.original_path, "r", encoding="utf-8") as infile:
            with open(os.path.join(self.folder, name), "w", encoding="utf-8") as outfile:
                outfile.write(infile.read())
        # Update to the new program
        with open(self.new_program_path, "r", encoding="utf-8") as infile:
            with open(self.original_path, "w", encoding="utf-8") as outfile:
                outfile.write(infile.read())

    def __exit__(self, exc_type, exc_value, traceback):
        """Restore original file from backup."""
        name = hashlib.md5(self.original_path.encode()).hexdigest()
        # Roll back to the original program
        with open(os.path.join(self.folder, name), "r", encoding="utf-8") as infile:
            with open(self.original_path, "w", encoding="utf-8") as outfile:
                outfile.write(infile.read())
