"""
Example: Using MCP Wrapper for Post-Processing Tool Outputs

This example demonstrates how to use the MCP wrapper to automatically
filter and post-process long structured tool outputs.
"""

import asyncio
import yaml
from mcpevolve.mcp.wrapper_manager import MCPWrapperManager
from mcpuniverse.agent.react import ReAct
from mcpuniverse.llm.manager import ModelManager


async def example_basic_wrapper():
    """
    Basic example using wrapper with default settings
    """
    print("=== Example 1: Basic Wrapper Configuration ===\n")

    # Load wrapper config from YAML
    with open("/Users/pjwalapuram/code/MCPUniverse/examples/wrapper_config_basic.yaml", "r") as f:
        wrapper_config = yaml.safe_load(f)

    # Create MCP manager and LLM
    mcp_manager = MCPWrapperManager()  # Uses default server list
    llm_manager = ModelManager()
    llm_config = {"name":"openai", "config":{"model_name":"gpt-5"}}
    #llm_config = {"name":"openai"}
    llm = llm_manager.build_model(**llm_config)

    #print(llm.config.model_name)
    # Create agent with wrapper config
    agent = ReAct(
        mcp_manager=mcp_manager,
        llm=llm,
        config={
            "name": "ReAct-agent",
            "instruction": "You are an agent for Browser automation.",
            "servers": [{"name": "playwright"}]
        },
    )

    # Initialize agent (wrapper is automatically initialized)
    await agent.initialize()

    # Use the agent - note: the agent will automatically use expected_info
    # when calling tools if the output is long
    response = await agent.execute(
        "I will travel to Singapore 3 days from now (If now is 2025-06-07, then 3 days later is 2025-06-10). I want to go to universal studios. Could you tell me the adult price of the ticket in the offcial website of sentosa (https://www.rwsentosa.com/)? I only want to see the price. Remember to close the browser after you finish the task."
    )

    print(f"Response: {response.response}\n")

    # Check post-processor memory
    if agent._post_processor:
        memory_summary = agent._post_processor.get_memory_summary()
        print(f"Post-processor memory summary: {memory_summary}\n")

    # Cleanup
    await agent.cleanup()


async def example_advanced_wrapper():
    """
    Advanced example using separate LLM for post-processing
    """
    print("=== Example 2: Advanced Wrapper with Separate LLM ===\n")

    # Load advanced wrapper config
    with open("wrapper_config_advanced.yaml", "r") as f:
        wrapper_config = yaml.safe_load(f)

    mcp_manager = MCPManager()

    # Main agent uses expensive model
    main_llm = build_llm({
        "provider": "anthropic",
        "model": "claude-3-5-sonnet-20241022"
    })

    agent = ReAct(
        mcp_manager=mcp_manager,
        llm=main_llm,
        config={
            "name": "web_agent",
            "servers": [{"name": "playwright"}]
        },
        wrapper_config=wrapper_config  # Uses Haiku for post-processing
    )

    await agent.initialize()

    response = await agent.execute(
        "Get all article titles from the Hacker News homepage"
    )

    print(f"Response: {response.response}\n")

    await agent.cleanup()


async def example_without_wrapper():
    """
    Example without wrapper for comparison
    """
    print("=== Example 3: Without Wrapper (for comparison) ===\n")

    mcp_manager = MCPManager()
    llm = build_llm({
        "provider": "anthropic",
        "model": "claude-3-5-sonnet-20241022"
    })

    # No wrapper_config parameter = no post-processing
    agent = ReAct(
        mcp_manager=mcp_manager,
        llm=llm,
        config={
            "name": "financial_agent",
            "servers": [{"name": "yfinance"}]
        }
    )

    await agent.initialize()

    response = await agent.execute(
        "What was Apple's closing price for the last 7 days?"
    )

    print(f"Response: {response.response}\n")

    await agent.cleanup()


async def example_inspect_memory():
    """
    Example showing how to inspect post-processor memory
    """
    print("=== Example 4: Inspecting Post-Processor Memory ===\n")

    with open("wrapper_config_basic.yaml", "r") as f:
        wrapper_config = yaml.safe_load(f)

    mcp_manager = MCPManager()
    llm = build_llm({
        "provider": "anthropic",
        "model": "claude-3-5-sonnet-20241022"
    })

    agent = ReAct(
        mcp_manager=mcp_manager,
        llm=llm,
        config={
            "name": "financial_agent",
            "servers": [{"name": "yfinance"}]
        },
        wrapper_config=wrapper_config
    )

    await agent.initialize()

    # Execute multiple queries
    queries = [
        "What was Apple's closing price last week?",
        "What was Microsoft's closing price last week?",  # Should reuse code
        "Get Tesla's volume data for yesterday"
    ]

    for query in queries:
        print(f"Query: {query}")
        response = await agent.execute(query)
        print(f"Response: {response.response}\n")

    # Inspect memory
    if agent._post_processor:
        memory = agent._post_processor.get_memory()
        print(f"Total memory entries: {len(memory)}")

        for i, entry in enumerate(memory):
            print(f"\nEntry {i+1}:")
            print(f"  Tool: {entry['tool_name']}")
            print(f"  Expected Info: {entry['expected_info']}")
            print(f"  Success: {entry['success']}")
            print(f"  Original Length: {entry['output_length']}")
            print(f"  Filtered Length: {entry['filtered_length']}")
            if entry['success']:
                print(f"  Code Preview: {entry['filter_code'][:100]}...")

    await agent.cleanup()


if __name__ == "__main__":
    # Run examples
    asyncio.run(example_basic_wrapper())
    # asyncio.run(example_advanced_wrapper())
    # asyncio.run(example_without_wrapper())
    # asyncio.run(example_inspect_memory())
