"""Utility command-line helpers for MCPEvolve."""

