"""
Evaluation orchestration for running multiple evaluators.
"""
# pylint: disable=too-few-public-methods
import os
import asyncio
from typing import List, Dict, Union
from pydantic import BaseModel, Field
from pydantic_core import from_json
from mcpuniverse.llm.manager import ModelManager
from mcpevolve.evaluator.manager import EvaluatorManager
from mcpevolve.evaluator.base import BaseEvaluator, EvaluatorInput, EvaluatorOutput
from mcpevolve.evaluator.utils import EvaluationLock


class EvaluatorConfig(BaseModel):
    """
    Configuration for a single evaluator instance.
    
    Attributes:
        name: Unique name for the evaluator instance.
        type: Class name of the evaluator to instantiate.
        config: Configuration dict or JSON string for the evaluator.
        llm: LLM configuration with type and optional config.
    """
    name: str
    type: str
    config: Union[str, Dict] = ""
    llm: Dict[str, Union[str, Dict]] = Field(default_factory=dict)


class EvaluationConfig(BaseModel):
    """
    Configuration for evaluation with multiple evaluators.
    
    Attributes:
        evaluators: List of evaluator configurations to run.
    """
    evaluators: List[EvaluatorConfig] = Field(default_factory=list)


class Evaluation:
    """Orchestrates evaluation using multiple configured evaluators."""

    def __init__(self, config: Union[Dict, str]):
        """
        Initialize evaluation with configuration.
        
        Args:
            config: Configuration dict or JSON string defining evaluators.
        """
        config = from_json(config) if isinstance(config, str) else config
        self._config = EvaluationConfig.model_validate(config)
        self._evaluators = self._load_evaluators()
        # Default config folder
        self._folder = os.path.join(os.path.expanduser("~"), ".mcpvolve")
        if not os.path.exists(self._folder):
            os.makedirs(self._folder, exist_ok=True)

    def _load_evaluators(self) -> Dict[str, BaseEvaluator]:
        """
        Load and initialize evaluators from configuration.
        
        Returns:
            Dict mapping evaluator names to initialized instances.
            
        Raises:
            AssertionError: If no evaluators defined or invalid LLM config.
        """
        assert len(self._config.evaluators) > 0, "No evaluators are defined"
        evaluators = {}
        evaluator_manager = EvaluatorManager()
        for evaluator in self._config.evaluators:
            kwargs = {"config": evaluator.config if evaluator.config else None}
            if evaluator.llm:
                assert isinstance(evaluator.llm, dict), "LLM config must be a dict"
                assert "type" in evaluator.llm, "LLM config must has `type`, e.g., type = openai"
                kwargs["llm"] = ModelManager().build_model(
                    name=evaluator.llm["type"],
                    config=evaluator.llm.get("config", None)
                )
            evaluators[evaluator.name] = evaluator_manager.build_evaluator(
                class_name=evaluator.type, **kwargs)
        return evaluators

    async def evaluate(self, param: EvaluatorInput) -> Dict[str, EvaluatorOutput]:
        """
        Run evaluation using all configured evaluators.
        
        Executes non-parallel evaluators sequentially, then parallel ones concurrently.
        Uses file locking to prevent conflicts between evaluation runs.
        
        Args:
            param: Input parameters for evaluation.
            
        Returns:
            Dict mapping evaluator names to their output results.
        """
        results = {}
        with EvaluationLock(folder=self._folder):
            # Run sequential evaluations
            for name, evaluator in self._evaluators.items():
                if not evaluator.allow_parallel():
                    results[name] = await evaluator.evaluate(param)
            # Run concurrent evaluations
            concurrents = [(name, e) for name, e in self._evaluators.items() if e.allow_parallel()]
            outputs = await asyncio.gather(*[e.evaluate(param) for _, e in concurrents])
            for i, (name, _) in enumerate(concurrents):
                results[name] = outputs[i]
        return results
