"""
Syntax evaluator for detecting Python parsing errors using tree-sitter.

This module provides the SyntaxEvaluator class that uses tree-sitter to parse
Python code files and identify syntax errors.
"""

import json
import os
from dataclasses import dataclass
from typing import Dict, Union, Optional, List

import tree_sitter_python
from tree_sitter import Language, Parser
from mcpevolve.evaluator.base import (
    BaseEvaluatorConfig,
    BaseEvaluator,
    EvaluatorInput,
    EvaluatorOutput
)
from mcpevolve.common.logger import get_logger


@dataclass
class SyntaxEvaluatorConfig(BaseEvaluatorConfig):
    """Configuration for SyntaxEvaluator with default settings."""


class SyntaxEvaluator(BaseEvaluator):
    """Evaluator that detects syntax errors in Python code using tree-sitter."""
    config_class = SyntaxEvaluatorConfig
    alias = ["syntax"]

    def __init__(self, config: Optional[Union[Dict, str]] = None, **kwargs):
        """
        Initialize the SyntaxEvaluator.

        Args:
            config: Configuration dict or JSON string.
            **kwargs: Additional initialization arguments.
        """
        super().__init__(config=config, **kwargs)
        self._logger = get_logger(self.__class__.__name__)
        parser = Parser()
        parser.language = Language(tree_sitter_python.language())
        self._parser = parser

    async def evaluate(self, param: EvaluatorInput) -> EvaluatorOutput:
        """
        Parse code files and detect syntax errors.

        Args:
            param: Input parameters containing code files and project folder.

        Returns:
            Evaluation output with success status, syntax score, and error details.
        """
        codes = {}
        for file in param.code_files:
            if os.path.exists(file):
                path = file
            else:
                path = os.path.join(param.project_folder, file)
                if not os.path.exists(path):
                    raise RuntimeError(f"File not found: {path}")
            with open(path, "r", encoding="utf-8") as f:
                codes[file] = f.read()

        parsing_errors = {}
        for file, code in codes.items():
            tree = self._parser.parse(bytes(code, "utf8"))
            if tree.root_node.type != "ERROR" and not tree.root_node.has_error:
                continue
            errors = SyntaxEvaluator._find_errors(tree.root_node)
            parsing_errors[file] = errors

        if not parsing_errors:
            return EvaluatorOutput(
                success=True,
                message="",
                metrics={"syntax_score": 1.0},
                feedback=""
            )
        messages = []
        for file, errors in parsing_errors.items():
            error_messages = []
            for i, error in enumerate(errors):
                error_messages.append(f"{i + 1}. Error at line {error['start_point'][0] + 1}, "
                                      f"col {error['start_point'][1] + 1}:\n{error['text']}")
            messages.append(f"""
File: {file}
Parsing errors found:
{chr(10).join(error_messages)}
""")
        return EvaluatorOutput(
            success=False,
            message=json.dumps(parsing_errors, indent=2),
            metrics={"syntax_score": 1.0 - len(parsing_errors) / max(len(codes), 1)},
            feedback="\n\n".join(messages)
        )

    def get_metric_list(self) -> List[str]:
        """
        Get list of metrics provided by this evaluator.

        Returns:
            List containing syntax_score metric.
        """
        return ["syntax_score"]

    @staticmethod
    def _find_errors(node):
        """
        Recursively find ERROR nodes in the parse tree.

        Args:
            node: Tree-sitter node to search.

        Returns:
            List of error dictionaries with type, text, and position info.
        """
        errors = []
        if node.type == "ERROR":
            errors.append({
                "type": node.type,
                "text": node.text.decode("utf8"),
                "start_point": node.start_point,
                "end_point": node.end_point
            })
        for child in node.children:
            errors.extend(SyntaxEvaluator._find_errors(child))
        return errors
