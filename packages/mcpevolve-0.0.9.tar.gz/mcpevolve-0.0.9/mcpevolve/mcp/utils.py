"""
MCP utilities for initializing and configuring MCP servers.
"""
# pylint: disable=protected-access
import os
from typing import Dict, Union, Optional
from mcpuniverse.mcp.manager import MCPManager
from mcpuniverse.common.context import Context


def init_mcp_manager(
        config: Optional[Union[str, Dict]] = None,
        context: Optional[Context] = None
) -> MCPManager:
    """
    Initialize an MCP manager with predefined server configurations.
    
    Creates and configures an MCPManager instance by loading server configurations
    from the local configs/server_list.json file. This provides a convenient way
    to set up MCP servers with standardized configurations for the MCPEvolve framework.
    
    Args:
        config: Optional configuration for the MCP manager. Can be a dictionary
            of configuration parameters or a string path to a configuration file.
        context: Optional context object for the MCP manager execution environment.
    
    Returns:
        MCPManager: A configured MCPManager instance with all servers from the
            server_list.json file added and ready for use.
    """
    folder = os.path.dirname(os.path.realpath(__file__))
    config_file = os.path.join(folder, "configs/server_list.json")
    assert os.path.isfile(config_file), f"File `{config_file}` does not exist"

    manager = MCPManager(config=config, context=context)
    configs = MCPManager._open_config(config_file)
    for name, conf in configs.items():
        manager.add_server_config(name, conf)
    return manager
