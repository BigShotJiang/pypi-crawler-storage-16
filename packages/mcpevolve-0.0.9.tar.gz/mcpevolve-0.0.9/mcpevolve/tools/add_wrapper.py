"""CLI helper to create a wrapped MCP proxy config and server entry.

Usage (from repo root):
    python -m mcpevolve.tools.add_wrapper --upstream fetch \
      --server-command uvx --server-args mcp-server-fetch

    # For args containing --flags, put --server-args LAST:
    python -m mcpevolve.tools.add_wrapper --upstream myserver \
      --server-command uv --server-args --directory /path run server.py

This will:
- Ensure the upstream exists in mcpevolve/mcp/configs/server_list.json
- Write a proxy config at mcpevolve/examples/proxy_wrapper_server_<upstream>.json
- Print a Cursor snippet you can paste into .cursor/mcp.json

Note: --server-args must be the LAST option; everything after it is captured.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, List


def _load_json(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _write_json(path: Path, data: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
        f.write("\n")


def _ensure_upstream_entry(
    server_list_path: Path,
    upstream: str,
    command: str | None,
    args: List[str] | None,
) -> bool:
    data = _load_json(server_list_path)
    if upstream in data:
        return False
    if not command or not args:
        raise ValueError(
            f"Upstream '{upstream}' not found in {server_list_path}. "
            "Provide --server-command and --server-args to add it."
        )
    data[upstream] = {
        "stdio": {
            "command": command,
            "args": args,
        }
    }
    _write_json(server_list_path, data)
    return True


def _build_proxy_config(
    upstream: str,
    server_name: str,
    timeout: int,
    post_processor_type: str,
    token_threshold: int,
    max_tool_output_chars: int | None,
    execution_timeout: int,
    max_iterations: int,
    llm_name: str,
    llm_model: str,
    llm_base_url: str | None,
    llm_api_key_env: str,
    expected_info_prompt_file: str | None,
) -> Dict[str, Any]:
    llm_config: Dict[str, Any] = {
        "name": llm_name,
        "config": {
            "model_name": llm_model,
            "api_key": f"${llm_api_key_env}",
        },
    }
    if llm_base_url:
        llm_config["config"]["base_url"] = llm_base_url

    wrapper_config: Dict[str, Any] = {
        "enabled": True,
        "token_threshold": token_threshold,
        # In Cursor there is no agent LLM to reuse; always rely on this LLM config.
        "use_agent_llm": False,
        "post_process_llm": None,
        "enable_memory": True,
        "execution_timeout": execution_timeout,
        "max_iterations": max_iterations,
        "post_processor_type": post_processor_type,
        "enable_reflection": True,
        "max_tool_output_chars": max_tool_output_chars,
    }
    if expected_info_prompt_file:
        wrapper_config["expected_info_prompt_file"] = expected_info_prompt_file

    return {
        "upstream_server": upstream,
        "server_name": server_name,
        "transport": "stdio",
        "upstream_address": "",
        "timeout": timeout,
        "llm": llm_config,
        "wrapper": wrapper_config,
    }


def _cursor_snippet(
    server_name: str,
    config_path: Path,
    repo_root: Path,
    python_command: str,
    llm_api_key_env: str,
) -> str:
    env_block: Dict[str, str] = {"PYTHONPATH": str(repo_root)}
    env_block[llm_api_key_env] = "<your-llm-key>"

    snippet = {
        server_name: {
            "command": python_command,
            "args": [
                "-m",
                "mcpevolve.mcp.proxy_server",
                "--config",
                str(config_path),
                "--transport",
                "stdio",
            ],
            "env": env_block,
        }
    }
    return json.dumps(snippet, indent=2)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Create a wrapped MCP proxy config and print a Cursor snippet."
    )
    parser.add_argument("--upstream", required=True, help="Upstream server name (as used by clients).")
    parser.add_argument(
        "--server-command",
        help="Command to start the upstream server (needed if not already in server_list.json).",
    )
    parser.add_argument(
        "--server-args",
        nargs=argparse.REMAINDER,
        help="Arguments for the upstream server command (must be LAST option; needed if not already in server_list.json).",
    )
    parser.add_argument(
        "--server-name",
        help="Name for the wrapped server (default: <upstream>-plus).",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=30,
        help="Timeout for upstream connections (seconds).",
    )
    parser.add_argument(
        "--post-processor-type",
        choices=["react", "extract", "basic"],
        default="extract",
        help="Post-processor type to use.",
    )
    parser.add_argument(
        "--token-threshold",
        type=int,
        default=400,
        help="Minimum token count before post-processing runs.",
    )
    parser.add_argument(
        "--max-tool-output-chars",
        type=int,
        default=None,
        help="Max chars shown to post-processor (None for no limit).",
    )
    parser.add_argument(
        "--execution-timeout",
        type=int,
        default=10,
        help="Timeout for generated code execution (seconds).",
    )
    parser.add_argument(
        "--max-iterations",
        type=int,
        default=3,
        help="Max post-processor refinement iterations.",
    )
    parser.add_argument(
        "--expected-info-prompt-file",
        help="Path to a custom expected_info prompt file.",
    )
    parser.add_argument(
        "--llm-name",
        default="openai",
        help="LLM provider name for the post-processor config.",
    )
    parser.add_argument(
        "--llm-model",
        default="gpt-4.1",
        help="Model name for the post-processor config.",
    )
    parser.add_argument(
        "--llm-base-url",
        default=None,
        help="Base URL for the post-processor LLM (default: OpenAI's https://api.openai.com/v1).",
    )
    parser.add_argument(
        "--llm-api-key-env",
        default="OPENAI_API_KEY",
        help="Env var name that should hold the LLM API key.",
    )
    parser.add_argument(
        "--config-out",
        help="Path to write the proxy config (default: mcpevolve/examples/proxy_wrapper_server_<upstream>.json).",
    )
    parser.add_argument(
        "--server-list",
        help="Path to server_list.json (default: mcpevolve/mcp/configs/server_list.json).",
    )
    parser.add_argument(
        "--python-command",
        default="python3",
        help="Python command used in the Cursor snippet (default: python3).",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    repo_root = Path(__file__).resolve().parents[2]

    server_list_path = Path(args.server_list) if args.server_list else repo_root / "mcpevolve/mcp/configs/server_list.json"
    config_path = (
        Path(args.config_out)
        if args.config_out
        else repo_root / f"mcpevolve/examples/proxy_wrapper_server_{args.upstream}.json"
    )
    server_name = args.server_name or f"{args.upstream}-plus"

    try:
        added = _ensure_upstream_entry(
            server_list_path=server_list_path,
            upstream=args.upstream,
            command=args.server_command,
            args=args.server_args,
        )
    except ValueError as exc:
        raise SystemExit(str(exc)) from exc

    if added:
        print(f"Added upstream '{args.upstream}' to {server_list_path}")
    else:
        print(f"Upstream '{args.upstream}' already present in {server_list_path}")

    proxy_config = _build_proxy_config(
        upstream=args.upstream,
        server_name=server_name,
        timeout=args.timeout,
        post_processor_type=args.post_processor_type,
        token_threshold=args.token_threshold,
        max_tool_output_chars=args.max_tool_output_chars,
        execution_timeout=args.execution_timeout,
        max_iterations=args.max_iterations,
        llm_name=args.llm_name,
        llm_model=args.llm_model,
        llm_base_url=args.llm_base_url,
        llm_api_key_env=args.llm_api_key_env,
        expected_info_prompt_file=args.expected_info_prompt_file,
    )
    _write_json(config_path, proxy_config)
    print(f"Wrote proxy config -> {config_path}")

    snippet = _cursor_snippet(
        server_name=server_name,
        config_path=config_path.resolve(),
        repo_root=repo_root,
        python_command=args.python_command,
        llm_api_key_env=args.llm_api_key_env,
    )
    print("\nCursor snippet (add to .cursor/mcp.json under mcpServers):")
    print(snippet)
    print("\nNote:")
    print(f"- Set your OpenAI API key: export {args.llm_api_key_env}=sk-...")
    print("- Reload your MCP client after pasting the snippet.")


if __name__ == "__main__":
    main()
