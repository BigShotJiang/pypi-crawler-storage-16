"""
FastMCP integration module for MCPM.

This module provides middleware and adapters to integrate MCPM's monitoring,
authentication, and configuration systems with FastMCP's proxy servers.
"""
