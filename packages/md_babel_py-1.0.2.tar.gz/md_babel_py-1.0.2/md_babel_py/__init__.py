"""md-babel-py: Execute code blocks in markdown files with session support."""

__version__ = "0.1.0"
