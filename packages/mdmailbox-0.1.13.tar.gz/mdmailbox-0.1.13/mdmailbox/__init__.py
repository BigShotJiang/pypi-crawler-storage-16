"""mdmail - Email as plain text files with YAML frontmatter."""

__version__ = "0.1.0"
