def main():
    print("Hello from mdmail!")


if __name__ == "__main__":
    main()
