# mdparser

A lightweight Markdown → HTML converter.

## Install

```bash
pip install mdparser-html
```

## Usage

md2html input.md -o output.html
