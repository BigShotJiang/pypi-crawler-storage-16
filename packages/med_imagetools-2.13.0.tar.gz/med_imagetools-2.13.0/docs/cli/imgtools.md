# `imgtools` CLI

::: mkdocs-click
    :module: imgtools.cli.__main__
    :command: cli
    :prog_name: imgtools
    :style: table
    :list_subcommands: True
    :depth: 1
