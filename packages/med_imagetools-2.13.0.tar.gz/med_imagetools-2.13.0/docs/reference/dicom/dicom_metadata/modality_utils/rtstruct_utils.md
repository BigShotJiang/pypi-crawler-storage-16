::: imgtools.dicom.dicom_metadata.modality_utils.rtstruct_utils
