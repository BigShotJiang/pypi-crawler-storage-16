::: imgtools.exceptions
