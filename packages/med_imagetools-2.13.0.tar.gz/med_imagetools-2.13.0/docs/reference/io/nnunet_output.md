::: imgtools.io.nnunet_output
