::: imgtools.nnunet_pipeline
