::: imgtools.pattern_parser.parser
