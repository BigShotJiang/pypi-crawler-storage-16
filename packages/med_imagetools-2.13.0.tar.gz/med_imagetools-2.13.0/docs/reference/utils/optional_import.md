::: imgtools.utils.optional_import
