"""MCP Server for Biological APIs Integration"""

__version__ = "0.1.0"
