"""
MCP Servers for each biological API
Each server is mounted at /tools/{api_name}/mcp
"""
