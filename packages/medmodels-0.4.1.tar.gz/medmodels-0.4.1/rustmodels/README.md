# rustmodels

`rustmodels` is the crate for the Python implementation of the `medmodels` rust library
