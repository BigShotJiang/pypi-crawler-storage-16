from meilisearch_python_sdk.index.async_index import AsyncIndex
from meilisearch_python_sdk.index.index import Index

__all__ = ["AsyncIndex", "Index"]
