"""Components used with reward models."""
