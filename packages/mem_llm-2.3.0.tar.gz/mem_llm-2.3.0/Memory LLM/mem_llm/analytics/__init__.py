"""
Analytics module for conversation analysis.
"""

from .topic_extractor import TopicExtractor

__all__ = ["TopicExtractor"]
