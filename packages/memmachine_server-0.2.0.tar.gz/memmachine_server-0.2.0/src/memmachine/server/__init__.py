"""Server entry points and FastAPI integration."""
