"""Alembic migration versions for semantic storage."""
