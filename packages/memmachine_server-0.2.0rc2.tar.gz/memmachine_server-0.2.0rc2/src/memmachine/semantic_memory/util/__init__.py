"""Utility helpers for semantic memory."""
