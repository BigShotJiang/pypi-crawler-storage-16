"""Embedder interfaces and implementations."""

from .embedder import Embedder

__all__ = [
    "Embedder",
]
