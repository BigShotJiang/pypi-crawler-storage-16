"""package for installation-related modules."""
