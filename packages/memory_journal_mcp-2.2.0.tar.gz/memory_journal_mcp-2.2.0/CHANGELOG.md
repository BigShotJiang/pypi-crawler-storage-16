# Changelog

The D1 Database Manager changelog is maintained in the project wiki.

## 📚 View the Changelog

**Wiki (recommended):** [Changelog](https://github.com/neverinfamous/memory-journal-mcp/wiki/CHANGELOG)

**GitHub Repository:** [neverinfamous/memory-journal-mcp](https://github.com/neverinfamous/memory-journal-mcp)

---

The wiki changelog includes:
- All version history and release notes
- Detailed feature descriptions
- Bug fixes and improvements
- Breaking changes and migration guides

For the latest updates, please refer to the wiki.
