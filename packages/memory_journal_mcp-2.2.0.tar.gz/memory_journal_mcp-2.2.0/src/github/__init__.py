"""
Memory Journal MCP Server - GitHub Integration Module
GitHub Projects API integration and context awareness.
"""
