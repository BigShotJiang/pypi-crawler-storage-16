"""Tests for Memory Journal MCP Server."""
