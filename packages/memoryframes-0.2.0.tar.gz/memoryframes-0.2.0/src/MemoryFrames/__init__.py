from importlib.metadata import version


# ----------------------------------------------------------------------
APP_NAME = "MemoryFrames"


# ----------------------------------------------------------------------
__version__ = version("MemoryFrames")
