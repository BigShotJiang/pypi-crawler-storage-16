This directory contains all information, base classes, helper classes, etc. used when creating Plugins that customize MemoryFrames behavior.
