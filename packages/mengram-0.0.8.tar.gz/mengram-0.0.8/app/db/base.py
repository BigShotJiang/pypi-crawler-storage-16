from sqlalchemy.orm import declarative_base

# Shared SQLAlchemy base for all ORM models
Base = declarative_base()
