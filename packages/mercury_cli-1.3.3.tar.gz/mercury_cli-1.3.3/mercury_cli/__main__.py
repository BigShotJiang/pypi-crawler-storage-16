from mercury_cli import main

main()
