"""
Meridian: Heroku for ML Features.
"""

__version__ = "1.5.0"
