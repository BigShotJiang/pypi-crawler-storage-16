"""
Merlya - AI-powered infrastructure assistant.

Version: 0.5.4
"""

__version__ = "0.5.4"
__author__ = "Cedric"
