"""
Merlya - AI-powered infrastructure assistant.

Version: 0.6.1
"""

__version__ = "0.6.1"
__author__ = "Cedric"
