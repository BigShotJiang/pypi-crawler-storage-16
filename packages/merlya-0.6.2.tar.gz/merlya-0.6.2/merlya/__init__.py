"""
Merlya - AI-powered infrastructure assistant.

Version: 0.6.2
"""

__version__ = "0.6.2"
__author__ = "Cedric"
