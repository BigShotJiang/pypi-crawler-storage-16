"""
Merlya - AI-powered infrastructure assistant.

Version: 0.7.0
"""

__version__ = "0.7.0"
__author__ = "Cedric"
