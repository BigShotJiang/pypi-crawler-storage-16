"""
Merlya - AI-powered infrastructure assistant.

Version: 0.7.2
"""

__version__ = "0.7.2"
__author__ = "Cedric"
