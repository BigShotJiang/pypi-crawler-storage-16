import logging
from copy import deepcopy
from ...configuration_utils import PretrainedConfig
from ..auto import CONFIG_MAPPING, AutoConfig
logger = logging.getLogger(__name__)
class ColPaliConfig(PretrainedConfig):
    model_type = "colpali"
    sub_configs = {"vlm_config": PretrainedConfig, "text_config": AutoConfig}
    def __init__(
        self,
        vlm_config=None,
        text_config=None,
        embedding_dim: int = 128,
        **kwargs,
    ):
        if vlm_config is None:
            vlm_config = CONFIG_MAPPING["paligemma"]()
            logger.info(
                "`vlm_config` is `None`. Initializing `vlm_config` with the `PaliGemmaConfig` with default values."
            )
        elif isinstance(vlm_config, dict):
            vlm_config = deepcopy(vlm_config)
            if "model_type" not in vlm_config:
                raise KeyError(
                    "The `model_type` key is missing in the `vlm_config` dictionary. Please provide the model type."
                )
            elif vlm_config["model_type"] not in CONFIG_MAPPING:
                raise ValueError(
                    f"The model type `{vlm_config['model_type']}` is not supported. Please provide a valid model type."
                )
            vlm_config = CONFIG_MAPPING[vlm_config["model_type"]](**vlm_config)
        elif not isinstance(vlm_config, PretrainedConfig):
            raise TypeError(
                f"Invalid type for `vlm_config`. Expected `PretrainedConfig`, `dict`, or `None`, but got {type(vlm_config)}."
            )
        self.vlm_config = vlm_config
        self.text_config = text_config if text_config is not None else vlm_config.text_config
        if isinstance(self.text_config, dict):
            text_config["model_type"] = text_config.get("model_type", "gemma")
            self.text_config = CONFIG_MAPPING[text_config["model_type"]](**text_config)
        self.embedding_dim = embedding_dim
        super().__init__(**kwargs)
__all__ = ["ColPaliConfig"]