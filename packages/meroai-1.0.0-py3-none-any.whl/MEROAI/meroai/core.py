import os
import sys
import platform
import re
from typing import Optional, List, Dict, Any, Union, Tuple
__version__ = "1.0.0"
__name__ = "MEROAI"
__author__ = "MERO"
__contact__ = "Telegram: @QP4RM"
class LanguageDetector:
    NAME = "MEROAI"
    DEVELOPER = "MERO"
    CONTACT = "Telegram: @QP4RM"
    LANGUAGE_PATTERNS = {
        "python": [
            (r"^\s*def\s+\w+\s*\(", 10),
            (r"^\s*class\s+\w+(\s*\(|\s*:)", 10),
            (r"^\s*import\s+\w+", 8),
            (r"^\s*from\s+\w+\s+import", 10),
            (r"^\s*if\s+.*:\s*$", 5),
            (r"^\s*for\s+\w+\s+in\s+", 8),
            (r"print\s*\(", 5),
            (r"self\.", 8),
            (r"__\w+__", 10),
        ],
        "javascript": [
            (r"^\s*function\s+\w+\s*\(", 10),
            (r"^\s*const\s+\w+\s*=", 8),
            (r"^\s*let\s+\w+\s*=", 8),
            (r"^\s*var\s+\w+\s*=", 6),
            (r"=>\s*\{", 10),
            (r"console\.(log|error|warn)", 10),
            (r"require\s*\(", 8),
        ],
        "typescript": [
            (r":\s*(string|number|boolean|any|void)\s*[;=\)]", 15),
            (r"interface\s+\w+\s*\{", 15),
            (r"type\s+\w+\s*=", 12),
        ],
        "c": [
            (r"#include\s*<\w+\.h>", 15),
            (r"#include\s*\"\w+\.h\"", 15),
            (r"#define\s+\w+", 10),
            (r"^\s*int\s+main\s*\(", 15),
            (r"printf\s*\(", 10),
            (r"malloc\s*\(", 10),
        ],
        "cpp": [
            (r"#include\s*<iostream>", 20),
            (r"#include\s*<vector>", 15),
            (r"using\s+namespace\s+std", 20),
            (r"std::", 15),
            (r"cout\s*<<", 15),
            (r"cin\s*>>", 15),
            (r"nullptr", 15),
        ],
        "csharp": [
            (r"using\s+System", 20),
            (r"namespace\s+\w+", 15),
            (r"public\s+class", 15),
            (r"Console\.(WriteLine|ReadLine)", 20),
        ],
        "java": [
            (r"public\s+class\s+\w+", 15),
            (r"public\s+static\s+void\s+main", 20),
            (r"System\.out\.print", 20),
            (r"import\s+java\.", 20),
        ],
        "go": [
            (r"package\s+\w+", 15),
            (r"func\s+\w+\s*\(", 15),
            (r":=", 10),
            (r"fmt\.(Print|Scan)", 18),
        ],
        "rust": [
            (r"fn\s+\w+\s*\(", 15),
            (r"let\s+mut\s+", 18),
            (r"println!\s*\(", 18),
            (r"use\s+\w+::", 15),
        ],
        "bash": [
            (r"^#!/bin/(ba)?sh", 25),
            (r"^\s*if\s+\[\s+", 12),
            (r"echo\s+", 8),
        ],
    }
    def detect(self, code: str) -> str:
        scores = {}
        for language, patterns in self.LANGUAGE_PATTERNS.items():
            score = 0
            for pattern, weight in patterns:
                matches = re.findall(pattern, code, re.MULTILINE)
                score += len(matches) * weight
            if score > 0:
                scores[language] = score
        if not scores:
            return "unknown"
        return max(scores.items(), key=lambda x: x[1])[0]
    def detect_from_extension(self, filename: str) -> str:
        extension_map = {
            ".py": "python", ".c": "c", ".h": "c",
            ".cpp": "cpp", ".cc": "cpp", ".hpp": "cpp",
            ".cs": "csharp", ".java": "java",
            ".js": "javascript", ".jsx": "javascript",
            ".ts": "typescript", ".tsx": "typescript",
            ".go": "go", ".rs": "rust",
            ".sh": "bash", ".bash": "bash",
        }
        for ext, lang in extension_map.items():
            if filename.endswith(ext):
                return lang
        return "unknown"
class CodeAnalyzer:
    NAME = "MEROAI"
    DEVELOPER = "MERO"
    CONTACT = "Telegram: @QP4RM"
    def analyze(self, code: str, language: str) -> List[str]:
        errors = []
        open_parens = code.count("(")
        close_parens = code.count(")")
        if open_parens != close_parens:
            errors.append(f"Mismatched parentheses: {open_parens} '(' vs {close_parens} ')'")
        open_brackets = code.count("[")
        close_brackets = code.count("]")
        if open_brackets != close_brackets:
            errors.append(f"Mismatched brackets: {open_brackets} '[' vs {close_brackets} ']'")
        open_braces = code.count("{")
        close_braces = code.count("}")
        if open_braces != close_braces:
            errors.append(f"Mismatched braces: {open_braces} '{{' vs {close_braces} '}}'")
        if language == "python":
            lines = code.split("\n")
            for i, line in enumerate(lines, 1):
                stripped = line.rstrip()
                if re.match(r"^\s*(def|class|if|elif|else|for|while|try|except|finally|with)\s+.*[^:]\s*$", stripped):
                    if not stripped.endswith(":") and not stripped.endswith("\\"):
                        if ":" not in stripped.split("#")[0]:
                            errors.append(f"Line {i}: Missing colon after statement")
        return list(set(errors))
class CodeFixer:
    NAME = "MEROAI"
    DEVELOPER = "MERO"
    CONTACT = "Telegram: @QP4RM"
    def fix(self, code: str, language: str) -> str:
        fixed = code
        lines = fixed.split("\n")
        fixed_lines = [line.rstrip() for line in lines]
        while fixed_lines and not fixed_lines[-1]:
            fixed_lines.pop()
        fixed = "\n".join(fixed_lines)
        if language == "python":
            fixed = re.sub(r'\bprint\s+(["\'])', r'print(\1', fixed)
        return fixed
    def remove_comments(self, code: str, language: str) -> str:
        if language == "python":
            lines = code.split("\n")
            fixed_lines = []
            for line in lines:
                comment_pos = line.find("#")
                if comment_pos >= 0:
                    in_string = False
                    for char in line[:comment_pos]:
                        if char in '"\'':
                            in_string = not in_string
                    if not in_string:
                        line = line[:comment_pos].rstrip()
                if line.strip():
                    fixed_lines.append(line)
            return "\n".join(fixed_lines)
        elif language in ["c", "cpp", "csharp", "java", "javascript", "typescript", "go", "rust"]:
            fixed = re.sub(r'/\*.*?\*/', '', code, flags=re.DOTALL)
            fixed = re.sub(r'//.*$', '', fixed, flags=re.MULTILINE)
            lines = [l for l in fixed.split("\n") if l.strip()]
            return "\n".join(lines)
        elif language == "bash":
            lines = code.split("\n")
            fixed_lines = []
            for line in lines:
                if line.strip().startswith("#") and not line.strip().startswith("#!"):
                    continue
                if line.strip():
                    fixed_lines.append(line)
            return "\n".join(fixed_lines)
        return code
class ImageProcessor:
    NAME = "MEROAI"
    DEVELOPER = "MERO"
    CONTACT = "Telegram: @QP4RM"
    SUPPORTED_FORMATS = [".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tiff", ".webp"]
    def analyze(self, path: str) -> Dict[str, Any]:
        result = {
            "path": path,
            "success": False,
            "credits": f"Analyzed by {self.NAME} - {self.DEVELOPER} ({self.CONTACT})"
        }
        if not os.path.exists(path):
            result["error"] = f"File not found: {path}"
            return result
        try:
            from PIL import Image
            with Image.open(path) as img:
                result["width"] = img.width
                result["height"] = img.height
                result["mode"] = img.mode
                result["format"] = img.format
                result["size_bytes"] = os.path.getsize(path)
                result["success"] = True
        except ImportError:
            result["error"] = "PIL not available"
        except Exception as e:
            result["error"] = str(e)
        return result
    def convert(self, source: str, destination: str, quality: int = 95) -> Dict[str, Any]:
        result = {
            "source": source,
            "destination": destination,
            "success": False,
            "credits": f"Converted by {self.NAME} - {self.DEVELOPER} ({self.CONTACT})"
        }
        try:
            from PIL import Image
            with Image.open(source) as img:
                dst_ext = os.path.splitext(destination)[1].lower()
                if dst_ext in [".jpg", ".jpeg"] and img.mode in ["RGBA", "P"]:
                    img = img.convert("RGB")
                img.save(destination, quality=quality)
                result["success"] = True
        except Exception as e:
            result["error"] = str(e)
        return result
class FileHandler:
    NAME = "MEROAI"
    DEVELOPER = "MERO"
    CONTACT = "Telegram: @QP4RM"
    CODE_EXTENSIONS = {
        ".py", ".c", ".h", ".cpp", ".cc", ".hpp",
        ".cs", ".java", ".js", ".jsx", ".ts", ".tsx",
        ".go", ".rs", ".sh", ".bash",
    }
    def __init__(self, encoding: str = "utf-8"):
        self.encoding = encoding
    def read(self, path: str) -> str:
        try:
            with open(path, "r", encoding=self.encoding) as f:
                return f.read()
        except UnicodeDecodeError:
            for enc in ["utf-8", "latin-1", "cp1252"]:
                try:
                    with open(path, "r", encoding=enc) as f:
                        return f.read()
                except UnicodeDecodeError:
                    continue
            raise
    def write(self, path: str, content: str) -> bool:
        try:
            os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
            with open(path, "w", encoding=self.encoding) as f:
                f.write(content)
            return True
        except Exception:
            return False
    def list_code_files(self, path: str, recursive: bool = True) -> List[str]:
        files = []
        if recursive:
            for root, dirs, filenames in os.walk(path):
                for filename in filenames:
                    if any(filename.endswith(ext) for ext in self.CODE_EXTENSIONS):
                        files.append(os.path.join(root, filename))
        return files
class FormatConverter:
    NAME = "MEROAI"
    DEVELOPER = "MERO"
    CONTACT = "Telegram: @QP4RM"
    def convert(self, source: str, destination: str) -> Dict[str, Any]:
        result = {
            "source": source,
            "destination": destination,
            "success": False,
            "credits": f"Converted by {self.NAME} - {self.DEVELOPER} ({self.CONTACT})"
        }
        if not os.path.exists(source):
            result["error"] = f"Source not found: {source}"
            return result
        try:
            import shutil
            os.makedirs(os.path.dirname(destination) or ".", exist_ok=True)
            shutil.copy2(source, destination)
            result["success"] = True
        except Exception as e:
            result["error"] = str(e)
        return result
class MEROAI:
    NAME = "MEROAI"
    VERSION = "1.0.0"
    DEVELOPER = "MERO"
    CONTACT = "Telegram: @QP4RM"
    SUPPORTED_LANGUAGES = [
        "python", "c", "cpp", "csharp", "java",
        "javascript", "typescript", "go", "rust", "bash"
    ]
    def __init__(self, auto_fix: bool = True):
        self.auto_fix = auto_fix
        self._detector = LanguageDetector()
        self._analyzer = CodeAnalyzer()
        self._fixer = CodeFixer()
        self._image_processor = ImageProcessor()
        self._file_handler = FileHandler()
        self._format_converter = FormatConverter()
        self._history: List[Dict[str, str]] = []
        self._system_info = {
            "os": platform.system(),
            "python_version": platform.python_version(),
        }
    def introduce(self) -> str:
    def analyze_code(self, code: str, language: Optional[str] = None) -> Dict[str, Any]:
        if language is None:
            language = self._detector.detect(code)
        errors = self._analyzer.analyze(code, language)
        return {
            "language": language,
            "errors": errors,
            "error_count": len(errors),
            "credits": f"Analyzed by {self.NAME} - {self.DEVELOPER} ({self.CONTACT})"
        }
    def fix_code(self, code: str, language: Optional[str] = None) -> str:
        if language is None:
            language = self._detector.detect(code)
        return self._fixer.fix(code, language)
    def remove_comments(self, code: str, language: Optional[str] = None) -> str:
        if language is None:
            language = self._detector.detect(code)
        return self._fixer.remove_comments(code, language)
    def analyze_image(self, path: str) -> Dict[str, Any]:
        return self._image_processor.analyze(path)
    def convert_format(self, source: str, destination: str) -> Dict[str, Any]:
        return self._format_converter.convert(source, destination)
    def analyze_file(self, path: str) -> Dict[str, Any]:
        content = self._file_handler.read(path)
        language = self._detector.detect_from_extension(path)
        if language == "unknown":
            language = self._detector.detect(content)
        return self.analyze_code(content, language)
    def fix_file(self, path: str, save: bool = True) -> Dict[str, Any]:
        content = self._file_handler.read(path)
        language = self._detector.detect_from_extension(path)
        if language == "unknown":
            language = self._detector.detect(content)
        fixed = self.fix_code(content, language)
        if save:
            self._file_handler.write(path, fixed)
        return {
            "path": path,
            "language": language,
            "saved": save,
            "credits": f"Fixed by {self.NAME} - {self.DEVELOPER} ({self.CONTACT})"
        }
    def chat(self):
        print(self.introduce())
        print("\nType 'exit' to quit, 'help' for commands.\n")
        while True:
            try:
                user_input = input(f"{self.NAME}> ").strip()
                if not user_input:
                    continue
                if user_input.lower() in ["exit", "quit", "q"]:
                    print(f"\nGoodbye! - {self.NAME} by {self.DEVELOPER}")
                    print(f"Contact: {self.CONTACT}")
                    break
                if user_input.lower() == "help":
)
                    continue
                if user_input.lower() == "info":
                    print(self.introduce())
                    continue
                if user_input.lower() == "credits":
)
                    continue
                code_indicators = ["def ", "class ", "import ", "function ", "const "]
                if any(ind in user_input for ind in code_indicators):
                    lang = self._detector.detect(user_input)
                    errors = self._analyzer.analyze(user_input, lang)
                    if errors:
                        print(f"\nLanguage: {lang}\nErrors:")
                        for e in errors:
                            print(f"  - {e}")
                        if self.auto_fix:
                            fixed = self._fixer.fix(user_input, lang)
                            print(f"\nFixed:\n{fixed}")
                    else:
                        print(f"\nLanguage: {lang}\nNo errors found!")
                else:
                    print(f"\nI am {self.NAME}. Type 'help' for commands.")
                print()
            except KeyboardInterrupt:
                print(f"\n\nGoodbye! - {self.NAME} by {self.DEVELOPER}")
                break
            except Exception as e:
                print(f"\nError: {str(e)}\n")