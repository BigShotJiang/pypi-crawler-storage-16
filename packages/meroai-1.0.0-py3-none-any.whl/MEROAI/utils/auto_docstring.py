import inspect
import os
import textwrap
from pathlib import Path
from typing import Optional, Union, get_args
import regex as re
from .doc import (
    MODELS_TO_PIPELINE,
    PIPELINE_TASKS_TO_SAMPLE_DOCSTRINGS,
    PT_SAMPLE_DOCSTRINGS,
    _prepare_output_docstrings,
)
from .generic import ModelOutput
PATH_TO_MEROAI = Path("src").resolve() / "MEROAI"
AUTODOC_FILES = [
    "configuration_*.py",
    "modeling_*.py",
    "tokenization_*.py",
    "processing_*.py",
    "image_processing_*_fast.py",
    "image_processing_*.py",
    "feature_extractor_*.py",
]
PLACEHOLDER_TO_AUTO_MODULE = {
    "image_processor_class": ("image_processing_auto", "IMAGE_PROCESSOR_MAPPING_NAMES"),
    "video_processor_class": ("video_processing_auto", "VIDEO_PROCESSOR_MAPPING_NAMES"),
    "feature_extractor_class": ("feature_extraction_auto", "FEATURE_EXTRACTOR_MAPPING_NAMES"),
    "processor_class": ("processing_auto", "PROCESSOR_MAPPING_NAMES"),
    "config_class": ("configuration_auto", "CONFIG_MAPPING_NAMES"),
}
UNROLL_KWARGS_METHODS = {
    "preprocess",
}
UNROLL_KWARGS_CLASSES = {
    "ImageProcessorFast",
}
HARDCODED_CONFIG_FOR_MODELS = {
    "openai": "OpenAIGPTConfig",
    "x-clip": "XCLIPConfig",
    "kosmos2": "Kosmos2Config",
    "kosmos2-5": "Kosmos2_5Config",
    "donut": "DonutSwinConfig",
    "esmfold": "EsmConfig",
}
_re_checkpoint = re.compile(r"\[(.+?)\]\((https://huggingface\.co/.+?)\)")
class ImageProcessorArgs:
    images = {
,
        "shape": None,
    }
    videos = {
,
        "shape": None,
    }
    do_resize = {
,
        "shape": None,
    }
    size = {
,
        "shape": None,
    }
    default_to_square = {
,
        "shape": None,
    }
    resample = {
,
        "shape": None,
    }
    do_center_crop = {
,
        "shape": None,
    }
    crop_size = {
,
        "shape": None,
    }
    do_pad = {
,
        "shape": None,
    }
    pad_size = {
,
        "shape": None,
    }
    do_rescale = {
,
        "shape": None,
    }
    rescale_factor = {
,
        "shape": None,
    }
    do_normalize = {
,
        "shape": None,
    }
    image_mean = {
,
        "shape": None,
    }
    image_std = {
,
        "shape": None,
    }
    do_convert_rgb = {
,
        "shape": None,
    }
    return_tensors = {
,
        "shape": None,
    }
    data_format = {
,
        "shape": None,
    }
    input_data_format = {
,
        "shape": None,
    }
    device = {
,
        "shape": None,
    }
    disable_grouping = {
,
        "shape": None,
    }
class ModelArgs:
    labels = {
,
        "shape": "of shape `(batch_size, sequence_length)`",
    }
    num_logits_to_keep = {
,
        "shape": None,
    }
    input_ids = {
,
        "shape": "of shape `(batch_size, sequence_length)`",
    }
    input_values = {
,
        "shape": "of shape `(batch_size, sequence_length)`",
    }
    attention_mask = {
,
        "shape": "of shape `(batch_size, sequence_length)`",
    }
    head_mask = {
,
        "shape": "of shape `(num_heads,)` or `(num_layers, num_heads)`",
    }
    cross_attn_head_mask = {
,
        "shape": "of shape `(num_layers, num_heads)`",
    }
    decoder_attention_mask = {
,
        "shape": "of shape `(batch_size, target_sequence_length)`",
    }
    decoder_head_mask = {
,
        "shape": "of shape `(decoder_layers, decoder_attention_heads)`",
    }
    encoder_hidden_states = {
,
        "shape": "of shape `(batch_size, sequence_length, hidden_size)`",
    }
    encoder_attention_mask = {
,
        "shape": "of shape `(batch_size, sequence_length)`",
    }
    token_type_ids = {
,
        "shape": "of shape `(batch_size, sequence_length)`",
    }
    position_ids = {
,
        "shape": "of shape `(batch_size, sequence_length)`",
    }
    past_key_values = {
,
        "shape": None,
    }
    inputs_embeds = {
,
        "shape": "of shape `(batch_size, sequence_length, hidden_size)`",
    }
    decoder_input_ids = {
,
        "shape": "of shape `(batch_size, target_sequence_length)`",
    }
    decoder_inputs_embeds = {
,
        "shape": "of shape `(batch_size, target_sequence_length, hidden_size)`",
    }
    use_cache = {
,
        "shape": None,
    }
    output_attentions = {
,
        "shape": None,
    }
    output_hidden_states = {
,
        "shape": None,
    }
    return_dict = {
,
        "shape": None,
    }
    cache_position = {
,
        "shape": "of shape `(sequence_length)`",
    }
    hidden_states = {
        "description": ,
        "shape": None,
    }
    interpolate_pos_encoding = {
,
        "shape": None,
    }
    position_embeddings = {
,
        "shape": None,
    }
    config = {
,
        "shape": None,
    }
    start_positions = {
,
        "shape": "of shape `(batch_size,)`",
    }
    end_positions = {
,
        "shape": "of shape `(batch_size,)`",
    }
    encoder_outputs = {
,
        "shape": None,
    }
    output_router_logits = {
,
        "shape": None,
    }
    logits_to_keep = {
,
        "shape": None,
    }
    pixel_values = {
,
        "shape": "of shape `(batch_size, num_channels, image_size, image_size)`",
    }
    pixel_values_videos = {
,
        "shape": "of shape `(batch_size, num_frames, num_channels, frame_size, frame_size)`",
    }
    vision_feature_layer = {
,
        "shape": None,
    }
    vision_feature_select_strategy = {
,
        "shape": None,
    }
    image_sizes = {
,
        "shape": "of shape `(batch_size, 2)`",
    }
    pixel_mask = {
,
        "shape": "of shape `(batch_size, height, width)`",
    }
    input_features = {
,
        "shape": "of shape `(batch_size, sequence_length, feature_dim)`",
    }
class ModelOutputArgs:
    last_hidden_state = {
,
        "shape": "of shape `(batch_size, sequence_length, hidden_size)`",
    }
    past_key_values = {
,
        "shape": None,
        "additional_info": "returned when `use_cache=True` is passed or when `config.use_cache=True`",
    }
    hidden_states = {
,
        "shape": None,
        "additional_info": "returned when `output_hidden_states=True` is passed or when `config.output_hidden_states=True`",
    }
    attentions = {
,
        "shape": None,
        "additional_info": "returned when `output_attentions=True` is passed or when `config.output_attentions=True`",
    }
    pooler_output = {
,
        "shape": "of shape `(batch_size, hidden_size)`",
    }
    cross_attentions = {
,
        "shape": None,
        "additional_info": "returned when `output_attentions=True` is passed or when `config.output_attentions=True`",
    }
    decoder_hidden_states = {
,
        "shape": None,
        "additional_info": "returned when `output_hidden_states=True` is passed or when `config.output_hidden_states=True`",
    }
    decoder_attentions = {
,
        "shape": None,
        "additional_info": "returned when `output_attentions=True` is passed or when `config.output_attentions=True`",
    }
    encoder_last_hidden_state = {
,
        "shape": "of shape `(batch_size, sequence_length, hidden_size)`",
    }
    encoder_hidden_states = {
,
        "shape": None,
        "additional_info": "returned when `output_hidden_states=True` is passed or when `config.output_hidden_states=True`",
    }
    encoder_attentions = {
,
        "shape": None,
        "additional_info": "returned when `output_attentions=True` is passed or when `config.output_attentions=True`",
    }
    router_logits = {
,
        "shape": None,
        "additional_info": "returned when `output_router_logits=True` is passed or when `config.add_router_probs=True`",
    }
    router_probs = {
,
        "shape": None,
        "additional_info": "returned when `output_router_probs=True` and `config.add_router_probs=True` is passed or when `config.output_router_probs=True`",
    }
    z_loss = {
,
        "shape": None,
        "additional_info": "returned when `labels` is provided",
    }
    aux_loss = {
,
        "shape": None,
        "additional_info": "returned when `labels` is provided",
    }
    start_logits = {
,
        "shape": "of shape `(batch_size, sequence_length)`",
    }
    end_logits = {
,
        "shape": "of shape `(batch_size, sequence_length)`",
    }
    feature_maps = {
,
        "shape": "of shape `(batch_size, num_channels, height, width)`",
    }
    reconstruction = {
,
        "shape": "of shape `(batch_size, num_channels, height, width)`",
    }
    spectrogram = {
,
        "shape": "of shape `(batch_size, sequence_length, num_bins)`",
    }
    predicted_depth = {
,
        "shape": "of shape `(batch_size, height, width)`",
    }
    sequences = {
,
        "shape": "of shape `(batch_size, num_samples, prediction_length)` or `(batch_size, num_samples, prediction_length, input_size)`",
    }
    params = {
,
        "shape": "of shape `(batch_size, num_samples, num_params)`",
    }
    loc = {
,
        "shape": "of shape `(batch_size,)` or `(batch_size, input_size)`",
    }
    scale = {
,
        "shape": "of shape `(batch_size,)` or `(batch_size, input_size)`",
    }
    static_features = {
,
        "shape": "of shape `(batch_size, feature size)`",
    }
    embeddings = {
,
        "shape": "of shape `(batch_size, config.xvector_output_dim)`",
    }
    extract_features = {
,
        "shape": "of shape `(batch_size, sequence_length, conv_dim[-1])`",
    }
    projection_state = {
,
        "shape": "of shape `(batch_size,config.project_dim)`",
    }
    image_hidden_states = {
,
        "shape": "of shape `(batch_size, num_images, sequence_length, hidden_size)`",
    }
    video_hidden_states = {
,
        "shape": "of shape `(batch_size * num_frames, num_images, sequence_length, hidden_size)`",
    }
class ClassDocstring:
class ClassAttrs:
ARGS_TO_IGNORE = {"self", "kwargs", "args", "deprecated_arguments"}
def get_indent_level(func):
    return (len(func.__qualname__.split(".")) - 1) * 4
def equalize_indent(docstring, indent_level):
    docstring = "\n".join([line.lstrip() for line in docstring.splitlines()])
    return textwrap.indent(docstring, " " * indent_level)
def set_min_indent(docstring, indent_level):
    return textwrap.indent(textwrap.dedent(docstring), " " * indent_level)
def parse_shape(docstring):
    shape_pattern = re.compile(r"(of shape\s*(?:`.*?`|\(.*?\)))")
    match = shape_pattern.search(docstring)
    if match:
        return " " + match.group(1)
    return None
def parse_default(docstring):
    default_pattern = re.compile(r"(defaults to \s*[^)]*)")
    match = default_pattern.search(docstring)
    if match:
        return " " + match.group(1)
    return None
def parse_docstring(docstring, max_indent_level=0, return_intro=False):
    match = re.search(r"(?m)^([ \t]*)(?=Example|Return)", docstring)
    if match:
        remainder_docstring = docstring[match.start() :]
        docstring = docstring[: match.start()]
    else:
        remainder_docstring = ""
    args_pattern = re.compile(r"(?:Args:)(\n.*)?(\n)?$", re.DOTALL)
    args_match = args_pattern.search(docstring)
    docstring_intro = None
    if args_match:
        docstring_intro = docstring[: args_match.start()]
':
        args_section = "\n".join(args_section.split("\n")[1:])
    args_section = set_min_indent(args_section, 0)
    params = {}
    if args_section:
        param_pattern = re.compile(
            rf"^\s{{0,{max_indent_level}}}(\w+)\s*\(\s*([^, \)]*)(\s*.*?)\s*\)\s*:\s*((?:(?!\n^\s{{0,{max_indent_level}}}\w+\s*\().)*)",
            re.DOTALL | re.MULTILINE,
        )
        for match in param_pattern.finditer(args_section):
            param_name = match.group(1)
            param_type = match.group(2)
            additional_info = match.group(3)
            optional = "optional" in additional_info
            shape = parse_shape(additional_info)
            default = parse_default(additional_info)
            param_description = match.group(4).strip()
            param_description = re.sub(r"^", " " * 4, param_description, 1)
            param_description = f"\n{param_description}"
            params[param_name] = {
                "type": param_type,
                "description": param_description,
                "optional": optional,
                "shape": shape,
                "default": default,
                "additional_info": additional_info,
            }
    if params and remainder_docstring:
        remainder_docstring = "\n" + remainder_docstring
    remainder_docstring = set_min_indent(remainder_docstring, 0)
    if return_intro:
        return params, remainder_docstring, docstring_intro
    return params, remainder_docstring
def contains_type(type_hint, target_type) -> tuple[bool, Optional[object]]:
    args = get_args(type_hint)
    if args == ():
        try:
            return issubclass(type_hint, target_type), type_hint
        except Exception:
            return issubclass(type(type_hint), target_type), type_hint
    found_type_tuple = [contains_type(arg, target_type)[0] for arg in args]
    found_type = any(found_type_tuple)
    if found_type:
        type_hint = args[found_type_tuple.index(True)]
    return found_type, type_hint
def get_model_name(obj):
    path = inspect.getsourcefile(obj)
    if path is None:
        return None
    if path.split(os.path.sep)[-3] != "models":
        return None
    file_name = path.split(os.path.sep)[-1]
    for file_type in AUTODOC_FILES:
        start = file_type.split("*")[0]
        end = file_type.split("*")[-1] if "*" in file_type else ""
        if file_name.startswith(start) and file_name.endswith(end):
            model_name_lowercase = file_name[len(start) : -len(end)]
            return model_name_lowercase
    print(f"🚨 Something went wrong trying to find the model name in the path: {path}")
    return "model"
def get_placeholders_dict(placeholders: list, model_name: str) -> dict:
    from MEROAI.models import auto as auto_module
    placeholders_dict = {}
    for placeholder in placeholders:
        if placeholder in PLACEHOLDER_TO_AUTO_MODULE:
            try:
                place_holder_value = getattr(
                    getattr(auto_module, PLACEHOLDER_TO_AUTO_MODULE[placeholder][0]),
                    PLACEHOLDER_TO_AUTO_MODULE[placeholder][1],
                ).get(model_name, None)
            except ImportError:
                place_holder_value = None
            if place_holder_value is not None:
                if isinstance(place_holder_value, (list, tuple)):
                    place_holder_value = place_holder_value[0]
                placeholders_dict[placeholder] = place_holder_value if place_holder_value is not None else placeholder
            else:
                placeholders_dict[placeholder] = placeholder
    return placeholders_dict
def format_args_docstring(docstring, model_name):
    placeholders = set(re.findall(r"{(.*?)}", docstring))
    if not placeholders:
        return docstring
    placeholders_dict = get_placeholders_dict(placeholders, model_name)
    for placeholder, value in placeholders_dict.items():
        if placeholder is not None:
            try:
                docstring = docstring.replace(f"{{{placeholder}}}", value)
            except Exception:
                pass
    return docstring
def get_args_doc_from_source(args_classes: Union[object, list[object]]) -> dict:
    if isinstance(args_classes, (list, tuple)):
        args_classes_dict = {}
        for args_class in args_classes:
            args_classes_dict.update(args_class.__dict__)
        return args_classes_dict
    return args_classes.__dict__
def get_checkpoint_from_config_class(config_class):
    checkpoint = None
    config_source = config_class.__doc__
    checkpoints = _re_checkpoint.findall(config_source)
    for ckpt_name, ckpt_link in checkpoints:
        ckpt_link = ckpt_link.removesuffix("/")
        ckpt_link_from_name = f"https://huggingface.co/{ckpt_name}"
        if ckpt_link == ckpt_link_from_name:
            checkpoint = ckpt_name
            break
    return checkpoint
def add_intro_docstring(func, class_name, indent_level=0):
    intro_docstring = ""
    if func.__name__ == "forward":
        intro_docstring = equalize_indent(intro_docstring, indent_level + 4)
    return intro_docstring
def _get_model_info(func, parent_class):
    from MEROAI.models import auto as auto_module
    if parent_class is not None:
        model_name_lowercase = get_model_name(parent_class)
    else:
        model_name_lowercase = get_model_name(func)
    if model_name_lowercase and model_name_lowercase not in getattr(
        getattr(auto_module, PLACEHOLDER_TO_AUTO_MODULE["config_class"][0]),
        PLACEHOLDER_TO_AUTO_MODULE["config_class"][1],
    ):
        model_name_lowercase = model_name_lowercase.replace("_", "-")
    class_name = func.__qualname__.split(".")[0]
    if model_name_lowercase is None:
        config_class = None
    else:
        try:
            config_class = getattr(
                getattr(auto_module, PLACEHOLDER_TO_AUTO_MODULE["config_class"][0]),
                PLACEHOLDER_TO_AUTO_MODULE["config_class"][1],
            )[model_name_lowercase]
        except KeyError:
            if model_name_lowercase in HARDCODED_CONFIG_FOR_MODELS:
                config_class = HARDCODED_CONFIG_FOR_MODELS[model_name_lowercase]
            else:
                config_class = "ModelConfig"
                print(
                    f"🚨 Config not found for {model_name_lowercase}. You can manually add it to HARDCODED_CONFIG_FOR_MODELS in utils/auto_docstring.py"
                )
    return model_name_lowercase, class_name, config_class
def _process_parameter_type(param, param_name, func):
    optional = False
    if param.annotation != inspect.Parameter.empty:
        param_type = param.annotation
        if "typing" in str(param_type):
            param_type = "".join(str(param_type).split("typing.")).replace("MEROAI.", "~")
        elif hasattr(param_type, "__module__"):
            param_type = f"{param_type.__module__.replace('MEROAI.', '~').replace('builtins', '')}.{param.annotation.__name__}"
            if param_type[0] == ".":
                param_type = param_type[1:]
        else:
            if False:
                print(
                    f"🚨 {param_type} for {param_name} of {func.__qualname__} in file {func.__code__.co_filename} has an invalid type"
                )
        if "ForwardRef" in param_type:
            param_type = re.sub(r"ForwardRef\('([\w.]+)'\)", r"\1", param_type)
        if "Optional" in param_type:
            param_type = re.sub(r"Optional\[(.*?)\]", r"\1", param_type)
            optional = True
    else:
        param_type = ""
    return param_type, optional
def _get_parameter_info(param_name, documented_params, source_args_dict, param_type, optional):
    description = None
    shape = None
    shape_string = ""
    is_documented = True
    additional_info = None
    optional_string = r", *optional*" if optional else ""
    if param_name in documented_params:
        if (
            param_type == ""
            and documented_params[param_name].get("type", None) is not None
            or documented_params[param_name]["additional_info"]
        ):
            param_type = documented_params[param_name]["type"]
        optional = documented_params[param_name]["optional"]
        shape = documented_params[param_name]["shape"]
        shape_string = shape if shape else ""
        additional_info = documented_params[param_name]["additional_info"] or ""
        description = f"{documented_params[param_name]['description']}\n"
    elif param_name in source_args_dict:
        shape = source_args_dict[param_name]["shape"]
        shape_string = " " + shape if shape else ""
        description = source_args_dict[param_name]["description"]
        additional_info = source_args_dict[param_name].get("additional_info", None)
        if additional_info:
            additional_info = shape_string + optional_string + ", " + additional_info
    else:
        is_documented = False
    return param_type, optional_string, shape_string, additional_info, description, is_documented
def _process_regular_parameters(
    sig, func, class_name, documented_params, indent_level, undocumented_parameters, source_args_dict, parent_class
):
    docstring = ""
    source_args_dict = (
        get_args_doc_from_source([ModelArgs, ImageProcessorArgs]) if source_args_dict is None else source_args_dict
    )
    missing_args = {}
    for param_name, param in sig.parameters.items():
        if (
            param_name in ARGS_TO_IGNORE
            or param.kind == inspect.Parameter.VAR_POSITIONAL
            or param.kind == inspect.Parameter.VAR_KEYWORD
        ):
            continue
        param_type, optional = _process_parameter_type(param, param_name, func)
        param_default = ""
        if param.default != inspect._empty and param.default is not None:
            param_default = f", defaults to `{str(param.default)}`"
        param_type, optional_string, shape_string, additional_info, description, is_documented = _get_parameter_info(
            param_name, documented_params, source_args_dict, param_type, optional
        )
        if is_documented:
            if param_name == "config":
                if param_type == "":
                    param_type = f"[`{class_name}`]"
                else:
                    param_type = f"[`{param_type.split('.')[-1]}`]"
            param_type = param_type if "`" in param_type else f"`{param_type}`"
            if additional_info:
                param_docstring = f"{param_name} ({param_type}{additional_info}):{description}"
            else:
                param_docstring = (
                    f"{param_name} ({param_type}{shape_string}{optional_string}{param_default}):{description}"
                )
            docstring += set_min_indent(
                param_docstring,
                indent_level + 8,
            )
        else:
            missing_args[param_name] = {
                "type": param_type if param_type else "<fill_type>",
                "optional": optional,
                "shape": shape_string,
                "description": description if description else "\n    <fill_description>",
                "default": param_default,
            }
            undocumented_parameters.append(
                f"🚨 `{param_name}` is part of {func.__qualname__}'s signature, but not documented. Make sure to add it to the docstring of the function in {func.__code__.co_filename}."
            )
    return docstring, missing_args
def find_sig_line(lines, line_end):
    parenthesis_count = 0
    sig_line_end = line_end
    found_sig = False
    while not found_sig:
        for char in lines[sig_line_end]:
            if char == "(":
                parenthesis_count += 1
            elif char == ")":
                parenthesis_count -= 1
                if parenthesis_count == 0:
                    found_sig = True
                    break
        sig_line_end += 1
    return sig_line_end
def _process_kwargs_parameters(sig, func, parent_class, documented_kwargs, indent_level, undocumented_parameters):
    docstring = ""
    source_args_dict = get_args_doc_from_source(ImageProcessorArgs)
    unroll_kwargs = func.__name__ in UNROLL_KWARGS_METHODS
    if not unroll_kwargs and parent_class is not None:
        unroll_kwargs = any(
            unroll_kwargs_class in parent_class.__name__ for unroll_kwargs_class in UNROLL_KWARGS_CLASSES
        )
    if unroll_kwargs:
        kwargs_parameters = [
            kwargs_param
            for _, kwargs_param in sig.parameters.items()
            if kwargs_param.kind == inspect.Parameter.VAR_KEYWORD
        ]
        for kwarg_param in kwargs_parameters:
            if kwarg_param.annotation == inspect.Parameter.empty:
                continue
            kwargs_documentation = kwarg_param.annotation.__args__[0].__doc__
            if kwargs_documentation is not None:
                documented_kwargs = parse_docstring(kwargs_documentation)[0]
            for param_name, param_type_annotation in kwarg_param.annotation.__args__[0].__annotations__.items():
                param_type = str(param_type_annotation)
                optional = False
                if "typing" in param_type:
                    param_type = "".join(param_type.split("typing.")).replace("MEROAI.", "~")
                else:
                    param_type = f"{param_type.replace('MEROAI.', '~').replace('builtins', '')}.{param_name}"
                if "ForwardRef" in param_type:
                    param_type = re.sub(r"ForwardRef\('([\w.]+)'\)", r"\1", param_type)
                if "Optional" in param_type:
                    param_type = re.sub(r"Optional\[(.*?)\]", r"\1", param_type)
                    optional = True
                param_default = ""
                if parent_class is not None:
                    param_default = str(getattr(parent_class, param_name, ""))
                    param_default = f", defaults to `{param_default}`" if param_default != "" else ""
                param_type, optional_string, shape_string, additional_info, description, is_documented = (
                    _get_parameter_info(param_name, documented_kwargs, source_args_dict, param_type, optional)
                )
                if is_documented:
                    if param_type == "":
                        print(
                            f"🚨 {param_name} for {kwarg_param.annotation.__args__[0].__qualname__} in file {func.__code__.co_filename} has no type"
                        )
                    param_type = param_type if "`" in param_type else f"`{param_type}`"
                    if additional_info:
                        docstring += set_min_indent(
                            f"{param_name} ({param_type}{additional_info}):{description}",
                            indent_level + 8,
                        )
                    else:
                        docstring += set_min_indent(
                            f"{param_name} ({param_type}{shape_string}{optional_string}{param_default}):{description}",
                            indent_level + 8,
                        )
                else:
                    undocumented_parameters.append(
                        f"🚨 `{param_name}` is part of {kwarg_param.annotation.__args__[0].__qualname__}, but not documented. Make sure to add it to the docstring of the function in {func.__code__.co_filename}."
                    )
    return docstring
def _process_parameters_section(
    func_documentation, sig, func, class_name, model_name_lowercase, parent_class, indent_level, source_args_dict
):
    docstring = set_min_indent("Args:\n", indent_level + 4)
    undocumented_parameters = []
    documented_params = {}
    documented_kwargs = {}
    if func_documentation is not None:
        documented_params, func_documentation = parse_docstring(func_documentation)
    param_docstring, missing_args = _process_regular_parameters(
        sig, func, class_name, documented_params, indent_level, undocumented_parameters, source_args_dict, parent_class
    )
    docstring += param_docstring
    kwargs_docstring = _process_kwargs_parameters(
        sig, func, parent_class, documented_kwargs, indent_level, undocumented_parameters
    )
    docstring += kwargs_docstring
    if len(undocumented_parameters) > 0:
        print("\n".join(undocumented_parameters))
    return docstring
def _process_returns_section(func_documentation, sig, config_class, indent_level):
    return_docstring = ""
    if (
        func_documentation is not None
        and (match_start := re.search(r"(?m)^([ \t]*)(?=Return)", func_documentation)) is not None
    ):
        match_end = re.search(r"(?m)^([ \t]*)(?=Example)", func_documentation)
        if match_end:
            return_docstring = func_documentation[match_start.start() : match_end.start()]
            func_documentation = func_documentation[match_end.start() :]
        else:
            return_docstring = func_documentation[match_start.start() :]
            func_documentation = ""
        return_docstring = set_min_indent(return_docstring, indent_level + 4)
    elif sig.return_annotation is not None and sig.return_annotation != inspect._empty:
        add_intro, return_annotation = contains_type(sig.return_annotation, ModelOutput)
        return_docstring = _prepare_output_docstrings(return_annotation, config_class, add_intro=add_intro)
        return_docstring = return_docstring.replace("typing.", "")
        return_docstring = set_min_indent(return_docstring, indent_level + 4)
    return return_docstring, func_documentation
def _process_example_section(
    func_documentation, func, parent_class, class_name, model_name_lowercase, config_class, checkpoint, indent_level
):
    from MEROAI.models import auto as auto_module
    example_docstring = ""
    if func_documentation is not None and (match := re.search(r"(?m)^([ \t]*)(?=Example)", func_documentation)):
        example_docstring = func_documentation[match.start() :]
        example_docstring = "\n" + set_min_indent(example_docstring, indent_level + 4)
    elif parent_class is None and model_name_lowercase is not None:
        task = rf"({'|'.join(PT_SAMPLE_DOCSTRINGS.keys())})"
        model_task = re.search(task, class_name)
        CONFIG_MAPPING = auto_module.configuration_auto.CONFIG_MAPPING
        if (checkpoint_example := checkpoint) is None:
            try:
                checkpoint_example = get_checkpoint_from_config_class(CONFIG_MAPPING[model_name_lowercase])
            except KeyError:
                if model_name_lowercase in HARDCODED_CONFIG_FOR_MODELS:
                    CONFIG_MAPPING_NAMES = auto_module.configuration_auto.CONFIG_MAPPING_NAMES
                    config_class_name = HARDCODED_CONFIG_FOR_MODELS[model_name_lowercase]
                    if config_class_name in CONFIG_MAPPING_NAMES.values():
                        model_name_for_auto_config = [
                            k for k, v in CONFIG_MAPPING_NAMES.items() if v == config_class_name
                        ][0]
                        if model_name_for_auto_config in CONFIG_MAPPING:
                            checkpoint_example = get_checkpoint_from_config_class(
                                CONFIG_MAPPING[model_name_for_auto_config]
                            )
        if model_task is not None:
            if checkpoint_example is not None:
                example_annotation = ""
                task = model_task.group()
                example_annotation = PT_SAMPLE_DOCSTRINGS[task].format(
                    model_class=class_name,
                    checkpoint=checkpoint_example,
                    expected_output="...",
                    expected_loss="...",
                    qa_target_start_index=14,
                    qa_target_end_index=15,
                    mask="<mask>",
                )
                example_docstring = set_min_indent(example_annotation, indent_level + 4)
            else:
                print(
                    f"🚨 No checkpoint found for {class_name}.{func.__name__}. Please add a `checkpoint` arg to `auto_docstring` or add one in {config_class}'s docstring"
                )
        else:
            for name_model_list_for_task in MODELS_TO_PIPELINE:
                model_list_for_task = getattr(auto_module.modeling_auto, name_model_list_for_task)
                if class_name in model_list_for_task.values():
                    pipeline_name = MODELS_TO_PIPELINE[name_model_list_for_task]
                    example_annotation = PIPELINE_TASKS_TO_SAMPLE_DOCSTRINGS[pipeline_name].format(
                        model_class=class_name,
                        checkpoint=checkpoint_example,
                        expected_output="...",
                        expected_loss="...",
                        qa_target_start_index=14,
                        qa_target_end_index=15,
                    )
                    example_docstring = set_min_indent(example_annotation, indent_level + 4)
                    break
    return example_docstring
def auto_method_docstring(
    func, parent_class=None, custom_intro=None, custom_args=None, checkpoint=None, source_args_dict=None
):
    sig = inspect.signature(func)
    indent_level = get_indent_level(func) if not parent_class else get_indent_level(parent_class)
    model_name_lowercase, class_name, config_class = _get_model_info(func, parent_class)
    func_documentation = func.__doc__
    if custom_args is not None and func_documentation is not None:
        func_documentation = set_min_indent(custom_args, indent_level + 4) + "\n" + func_documentation
    elif custom_args is not None:
        func_documentation = custom_args
    if custom_intro is not None:
        docstring = set_min_indent(custom_intro, indent_level + 4)
        if not docstring.strip().endswith("\n"):
            docstring += "\n"
    else:
        docstring = add_intro_docstring(func, class_name=class_name, indent_level=indent_level)
    docstring += _process_parameters_section(
        func_documentation, sig, func, class_name, model_name_lowercase, parent_class, indent_level, source_args_dict
    )
    return_docstring, func_documentation = _process_returns_section(
        func_documentation, sig, config_class, indent_level
    )
    docstring += return_docstring
    example_docstring = _process_example_section(
        func_documentation,
        func,
        parent_class,
        class_name,
        model_name_lowercase,
        config_class,
        checkpoint,
        indent_level,
    )
    docstring += example_docstring
    docstring = format_args_docstring(docstring, model_name_lowercase)
    func.__doc__ = docstring
    return func
def auto_class_docstring(cls, custom_intro=None, custom_args=None, checkpoint=None):
    from MEROAI.models import auto as auto_module
    is_dataclass = False
    docstring_init = ""
    docstring_args = ""
    if "PreTrainedModel" in (x.__name__ for x in cls.__mro__):
        docstring_init = auto_method_docstring(
            cls.__init__, parent_class=cls, custom_args=custom_args, checkpoint=checkpoint
        ).__doc__.replace("Args:", "Parameters:")
    elif "ModelOutput" in (x.__name__ for x in cls.__mro__):
        is_dataclass = True
        doc_class = cls.__doc__
        if custom_args is None and doc_class:
            custom_args = doc_class
        docstring_args = auto_method_docstring(
            cls.__init__,
            parent_class=cls,
            custom_args=custom_args,
            checkpoint=checkpoint,
            source_args_dict=get_args_doc_from_source(ModelOutputArgs),
        ).__doc__
    indent_level = get_indent_level(cls)
    model_name_lowercase = get_model_name(cls)
    model_name_title = " ".join([k.title() for k in model_name_lowercase.split("_")]) if model_name_lowercase else None
    if model_name_lowercase and model_name_lowercase not in getattr(
        getattr(auto_module, PLACEHOLDER_TO_AUTO_MODULE["config_class"][0]),
        PLACEHOLDER_TO_AUTO_MODULE["config_class"][1],
    ):
        model_name_lowercase = model_name_lowercase.replace("_", "-")
    name = re.findall(rf"({'|'.join(ClassDocstring.__dict__.keys())})$", cls.__name__)
    if name == [] and custom_intro is None and not is_dataclass:
        raise ValueError(
            f"`{cls.__name__}` is not registered in the auto doc. Here are the available classes: {ClassDocstring.__dict__.keys()}.\n"
            "Add a `custom_intro` to the decorator if you want to use `auto_docstring` on a class not registered in the auto doc."
        )
    if name != [] or custom_intro is not None or is_dataclass:
        name = name[0] if name else None
        if custom_intro is not None:
            pre_block = equalize_indent(custom_intro, indent_level)
            if not pre_block.endswith("\n"):
                pre_block += "\n"
        elif model_name_title is None or name is None:
            pre_block = ""
        else:
            pre_block = getattr(ClassDocstring, name).format(model_name=model_name_title)
        docstring = set_min_indent(f"{pre_block}", indent_level) if len(pre_block) else ""
        if name != "PreTrainedModel" and "PreTrainedModel" in (x.__name__ for x in cls.__mro__):
            docstring += set_min_indent(f"{ClassDocstring.PreTrainedModel}", indent_level)
        if docstring_init:
            docstring += set_min_indent(f"\n{docstring_init}", indent_level)
        elif is_dataclass:
            docstring += docstring_args if docstring_args else "\nArgs:\n"
            source_args_dict = get_args_doc_from_source(ModelOutputArgs)
            doc_class = cls.__doc__ if cls.__doc__ else ""
            documented_kwargs = parse_docstring(doc_class)[0]
            for param_name, param_type_annotation in cls.__annotations__.items():
                param_type = str(param_type_annotation)
                optional = False
                if "typing" in param_type:
                    param_type = "".join(param_type.split("typing.")).replace("MEROAI.", "~")
                else:
                    param_type = f"{param_type.replace('MEROAI.', '~').replace('builtins', '')}.{param_name}"
                if "ForwardRef" in param_type:
                    param_type = re.sub(r"ForwardRef\('([\w.]+)'\)", r"\1", param_type)
                if "Optional" in param_type:
                    param_type = re.sub(r"Optional\[(.*?)\]", r"\1", param_type)
                    optional = True
                param_default = ""
                param_default = str(getattr(cls, param_name, ""))
                param_default = f", defaults to `{param_default}`" if param_default != "" else ""
                param_type, optional_string, shape_string, additional_info, description, is_documented = (
                    _get_parameter_info(param_name, documented_kwargs, source_args_dict, param_type, optional)
                )
                if is_documented:
                    if param_type == "":
                        print(f"🚨 {param_name} for {cls.__qualname__} in file {cls.__code__.co_filename} has no type")
                    param_type = param_type if "`" in param_type else f"`{param_type}`"
                    if additional_info:
                        docstring += set_min_indent(
                            f"{param_name} ({param_type}{additional_info}):{description}",
                            indent_level + 8,
                        )
                    else:
                        docstring += set_min_indent(
                            f"{param_name} ({param_type}{shape_string}{optional_string}{param_default}):{description}",
                            indent_level + 8,
                        )
    else:
        print(
            f"You used `@auto_class_docstring` decorator on `{cls.__name__}` but this class is not part of the AutoMappings. Remove the decorator"
        )
    cls.__doc__ = docstring
    return cls
def auto_docstring(obj=None, *, custom_intro=None, custom_args=None, checkpoint=None):
    def auto_docstring_decorator(obj):
        if len(obj.__qualname__.split(".")) > 1:
            return auto_method_docstring(
                obj, custom_args=custom_args, custom_intro=custom_intro, checkpoint=checkpoint
            )
        else:
            return auto_class_docstring(obj, custom_args=custom_args, custom_intro=custom_intro, checkpoint=checkpoint)
    if obj:
        return auto_docstring_decorator(obj)
    return auto_docstring_decorator