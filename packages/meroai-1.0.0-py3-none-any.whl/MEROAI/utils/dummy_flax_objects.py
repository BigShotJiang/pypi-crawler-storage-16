from ..utils import DummyObject, requires_backends
class FlaxForcedBOSTokenLogitsProcessor(metaclass=DummyObject):
    _backends = ["flax"]
    def __init__(self, *args, **kwargs):
        requires_backends(self, ["flax"])
class FlaxForcedEOSTokenLogitsProcessor(metaclass=DummyObject):
    _backends = ["flax"]
    def __init__(self, *args, **kwargs):
        requires_backends(self, ["flax"])
class FlaxForceTokensLogitsProcessor(metaclass=DummyObject):
    _backends = ["flax"]
    def __init__(self, *args, **kwargs):
        requires_backends(self, ["flax"])
class FlaxGenerationMixin(metaclass=DummyObject):
    _backends = ["flax"]
    def __init__(self, *args, **kwargs):
        requires_backends(self, ["flax"])
class FlaxLogitsProcessor(metaclass=DummyObject):
    _backends = ["flax"]
    def __init__(self, *args, **kwargs):
        requires_backends(self, ["flax"])
class FlaxLogitsProcessorList(metaclass=DummyObject):
    _backends = ["flax"]
    def __init__(self, *args, **kwargs):
        requires_backends(self, ["flax"])
class FlaxLogitsWarper(metaclass=DummyObject):
    _backends = ["flax"]
    def __init__(self, *args, **kwargs):
        requires_backends(self, ["flax"])
class FlaxMinLengthLogitsProcessor(metaclass=DummyObject):
    _backends = ["flax"]
    def __init__(self, *args, **kwargs):
        requires_backends(self, ["flax"])
class FlaxSuppressTokensAtBeginLogitsProcessor(metaclass=DummyObject):
    _backends = ["flax"]
    def __init__(self, *args, **kwargs):
        requires_backends(self, ["flax"])
class FlaxSuppressTokensLogitsProcessor(metaclass=DummyObject):
    _backends = ["flax"]
    def __init__(self, *args, **kwargs):
        requires_backends(self, ["flax"])
class FlaxTemperatureLogitsWarper(metaclass=DummyObject):
    _backends = ["flax"]
    def __init__(self, *args, **kwargs):
        requires_backends(self, ["flax"])
class FlaxTopKLogitsWarper(metaclass=DummyObject):
    _backends = ["flax"]
    def __init__(self, *args, **kwargs):
        requires_backends(self, ["flax"])
class FlaxTopPLogitsWarper(metaclass=DummyObject):
    _backends = ["flax"]
    def __init__(self, *args, **kwargs):
        requires_backends(self, ["flax"])
class FlaxWhisperTimeStampLogitsProcessor(metaclass=DummyObject):
    _backends = ["flax"]
    def __init__(self, *args, **kwargs):
        requires_backends(self, ["flax"])
class FlaxPreTrainedModel(metaclass=DummyObject):
    _backends = ["flax"]
    def __init__(self, *args, **kwargs):
        requires_backends(self, ["flax"])