from ..utils import DummyObject, requires_backends
SLOW_TO_FAST_CONVERTERS = None
def convert_slow_tokenizer(*args, **kwargs):
    requires_backends(convert_slow_tokenizer, ["sentencepiece", "tokenizers"])