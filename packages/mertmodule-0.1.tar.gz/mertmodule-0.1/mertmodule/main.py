def mert():
    print('Mert')
def memleket(a):
    for i in range(a):
        print('Mugla evimiz Ortaca adresimizdir')
def rushhour():
    print('''[Intro]
Woo
Okay, woo
Yeah (Okay), yeah

[Verse 1]
I give a fuck less and less every day (Okay)
The more you give a fuck, I guess the less you make (Money)
Homie, we just out here tryna elevate (Skrrrrt)
Heaven is a crime scene, stay behind the yellow tape (Whoop whoop)
I started makin' money in eleventh grade
Soon as I learned that the more you do, the less you wait (Uh-huh)
Got a bigger crib, always use the extra space
Shit was so different in 2008 (Woo)
Growin' pains (Growin' pains), fill the open veins with Novocain
Relapse, I eat that, I don't complain
I'm just ramblin'
You want war? It's N64, Blitz Champion (Sucker)
Out of space channelin', brain-damagin'
Heavy rain, game cancelin', proud to be American (Da-da-da-da)

[Refrain]
Yeah, they tell me, "Get yourself straight (Woo)
How much more money can you make?" (Okay, okay, okay)

[Chorus]
I'm just tryna grow up old and rich (Old and rich)
Maybe get married to a local bitch (Local bitch)
I be, I be, I be, I be over shit (Over shit)
The world don't give a fuck about your loneliness (No way)
I'm just tryna grow up old and rich (Old and rich)
The world don't give a fuck about your loneliness (Okay)
I be, I be, I be, I be over shit (Over shit)
The world don't give a fuck about your loneliness (Okay)
See upcoming rap shows
Get tickets for your favorite artists
          
[Verse 2]
I'm a deranged motherfucker (Woo), took too many uppers (Woo)
Now it's rush hour, Jackie Chan, Chris Tucker, yeah (Fifty million dollars)
I stuck around the past six summers (Woo)
Karma is a bitch and that bitch don't love ya, yeah
We was in the attic, you could smell the weed
Bitches gettin' naked, we was sellin' E, argh
Bitches kissin' bitches just like Ellen D (Ellen D)
In the kitchen whippin' biscuits, givin' generously (Thank you)
I thank the Lord I made it out, no STD (Word)
Lost a few too many brain cells, I'm special needs

[Refrain]
Yeah, they tell me, "Get yourself straight (Straight)
How much more money can you make?"

[Chorus]
I'm just tryna grow up old and rich (Old and rich)
Maybe get married to a local bitch (A local bitch)
I be, I be, I be, I be over shit (Over shit)
The world don't give a fuck about your loneliness (No way, no way, no way, no way, no way)
I'm just tryna grow up old and rich (Old and rich)
The world don't give a fuck about your loneliness
I be, I be, I be, I be over shit (Over shit)
The world don't give a fuck about your loneliness (Okay)
[Outro: Franchise]
Ladies and gentlemen in attendance, good mornin'
It's the Babyface Don Dada checkin' in
And I want you to know
It ain't about complainin', it's about maintainin'
Y'know I'm talkin' about?
Don't ever become content
Because you will repent
Ya feel that? Go get it
That's your life, go live it
Pass me my Hennessy and my Grand Marnier
If you will''')
def goat():
    print('Goat her zaman ATATURK')
def musicgoat():
    print('Mac Miller')
def proprogrammer():
    print('Mert Bulut')