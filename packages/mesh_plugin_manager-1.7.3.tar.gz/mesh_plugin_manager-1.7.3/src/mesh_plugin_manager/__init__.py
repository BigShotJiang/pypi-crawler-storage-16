"""Mesh Plugin Manager (MPM) package."""

