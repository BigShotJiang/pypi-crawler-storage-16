"""MeshSync Core Common Library"""
