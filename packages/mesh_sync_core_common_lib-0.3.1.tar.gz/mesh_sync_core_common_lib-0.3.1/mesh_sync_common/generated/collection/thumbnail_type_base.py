# AUTO-GENERATED - DO NOT EDIT
# Generated from: collection/domain/thumbnail_type_enum.yaml

from enum import Enum


class ThumbnailType(Enum):
    """Type of the collection thumbnail"""
    DEFAULT = 'DEFAULT'
    UPLOADED = 'UPLOADED'
    GENERATED_STL = 'GENERATED_STL'
    IMAGE = 'IMAGE'
