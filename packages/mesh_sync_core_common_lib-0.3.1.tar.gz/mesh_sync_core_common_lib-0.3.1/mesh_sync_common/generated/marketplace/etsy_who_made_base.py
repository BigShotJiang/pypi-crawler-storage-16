# AUTO-GENERATED - DO NOT EDIT
# Generated from: marketplace/domain/etsy_who_made_enum.yaml

from enum import Enum


class EtsyWhoMade(Enum):
    """Etsy specific: Who made the item"""
    I_DID = 'i_did'
    COLLECTIVE = 'collective'
    SOMEONE_ELSE = 'someone_else'
