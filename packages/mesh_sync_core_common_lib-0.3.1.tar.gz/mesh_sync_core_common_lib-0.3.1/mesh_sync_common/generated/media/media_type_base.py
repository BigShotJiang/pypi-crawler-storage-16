# AUTO-GENERATED - DO NOT EDIT
# Generated from: media/domain/media_type_enum.yaml

from enum import Enum


class MediaType(Enum):
    """Type of the media file"""
    IMAGE = 'IMAGE'
    VIDEO = 'VIDEO'
    THREED_THUMBNAIL = 'THREED_THUMBNAIL'
