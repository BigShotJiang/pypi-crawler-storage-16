# AUTO-GENERATED - DO NOT EDIT
# Generated from: media/domain/watermark_content_type_enum.yaml

from enum import Enum


class WatermarkContentType(Enum):
    """Type of content used for watermark"""
    IMAGE = 'IMAGE'
    TEXT = 'TEXT'
