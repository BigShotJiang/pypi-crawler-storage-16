# AUTO-GENERATED - DO NOT EDIT
# Generated from: media/domain/watermark_position_horizontal_enum.yaml

from enum import Enum


class WatermarkPositionHorizontal(Enum):
    """Horizontal position of the watermark"""
    LEFT = 'LEFT'
    CENTER = 'CENTER'
    RIGHT = 'RIGHT'
