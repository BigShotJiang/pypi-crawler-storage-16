# AUTO-GENERATED - DO NOT EDIT
# Generated from: media/domain/watermark_position_vertical_enum.yaml

from enum import Enum


class WatermarkPositionVertical(Enum):
    """Vertical position of the watermark"""
    TOP = 'TOP'
    MIDDLE = 'MIDDLE'
    BOTTOM = 'BOTTOM'
