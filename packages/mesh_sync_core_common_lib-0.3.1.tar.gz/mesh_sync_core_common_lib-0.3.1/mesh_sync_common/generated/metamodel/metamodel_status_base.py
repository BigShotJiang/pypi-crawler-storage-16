# AUTO-GENERATED - DO NOT EDIT
# Generated from: metamodel/domain/metamodel_status_enum.yaml

from enum import Enum


class MetamodelStatus(Enum):
    """Status of the metamodel"""
    SUGGESTION = 'SUGGESTION'
    FINALIZED = 'FINALIZED'
