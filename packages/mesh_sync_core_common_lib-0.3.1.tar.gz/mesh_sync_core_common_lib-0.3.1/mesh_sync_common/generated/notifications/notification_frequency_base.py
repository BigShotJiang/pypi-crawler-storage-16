# AUTO-GENERATED - DO NOT EDIT
# Generated from: notifications/domain/notification_frequency_enum.yaml

from enum import Enum


class NotificationFrequency(Enum):
    """Frequency of notification delivery"""
    REALTIME = 'realtime'
    HOURLY = 'hourly'
    DAILY = 'daily'
