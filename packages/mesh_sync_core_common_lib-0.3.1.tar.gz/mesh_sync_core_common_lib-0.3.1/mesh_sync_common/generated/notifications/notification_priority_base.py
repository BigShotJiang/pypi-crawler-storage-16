# AUTO-GENERATED - DO NOT EDIT
# Generated from: notifications/domain/notification_priority_enum.yaml

from enum import Enum


class NotificationPriority(Enum):
    """Priority of the notification"""
    LOW = 'low'
    NORMAL = 'normal'
    HIGH = 'high'
    URGENT = 'urgent'
