# AUTO-GENERATED - DO NOT EDIT
# Generated from: storage/domain/scan_status_enum.yaml

from enum import Enum


class ScanStatus(Enum):
    """Status of a storage scan operation"""
    SUCCESS = 'SUCCESS'
    FAILED = 'FAILED'
    PENDING = 'PENDING'
    IN_PROGRESS = 'IN_PROGRESS'
