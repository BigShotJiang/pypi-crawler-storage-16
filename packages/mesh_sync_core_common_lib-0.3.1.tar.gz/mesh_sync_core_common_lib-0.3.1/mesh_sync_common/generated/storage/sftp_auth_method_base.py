# AUTO-GENERATED - DO NOT EDIT
# Generated from: storage/domain/sftp_auth_method_enum.yaml

from enum import Enum


class SftpAuthMethod(Enum):
    """Authentication methods for SFTP connections"""
    PASSWORD = 'password'
    PRIVATE_KEY = 'privateKey'
