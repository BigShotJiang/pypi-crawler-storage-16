# AUTO-GENERATED - DO NOT EDIT
# Generated from: storage/domain/storage_connection_type_enum.yaml

from enum import Enum


class StorageConnectionType(Enum):
    """Types of storage connections supported"""
    GOOGLE_DRIVE = 'google_drive'
    WEBDAV = 'webdav'
    SFTP = 'sftp'
