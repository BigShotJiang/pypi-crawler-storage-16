# AUTO-GENERATED - DO NOT EDIT
# Generated from: subscription/domain/plan_tier_enum.yaml

from enum import Enum


class PlanTier(Enum):
    """The subscription plan tier"""
    LIBRARIAN = 'LIBRARIAN'
    MAKER = 'MAKER'
    MERCHANT = 'MERCHANT'
    FACTORY = 'FACTORY'
