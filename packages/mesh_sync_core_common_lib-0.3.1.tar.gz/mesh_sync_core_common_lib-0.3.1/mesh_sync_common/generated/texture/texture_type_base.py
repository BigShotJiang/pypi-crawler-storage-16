# AUTO-GENERATED - DO NOT EDIT
# Generated from: texture/domain/texture_type_enum.yaml

from enum import Enum


class TextureType(Enum):
    """Type of the texture"""
    SOLID_COLOR = 'SOLID_COLOR'
    CUSTOM_HDR = 'CUSTOM_HDR'
    SYSTEM_DEFAULT = 'SYSTEM_DEFAULT'
