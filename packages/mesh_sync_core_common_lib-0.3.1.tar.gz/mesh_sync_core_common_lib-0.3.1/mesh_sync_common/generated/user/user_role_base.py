# AUTO-GENERATED - DO NOT EDIT
# Generated from: user/domain/user_role_enum.yaml

from enum import Enum


class UserRole(Enum):
    """User roles defining access levels and permissions"""
    ADMIN = 'ADMIN'
    CREATOR = 'CREATOR'
    VIEWER = 'VIEWER'
