"""Storage backend definitions."""
