# metaPTCM pipeline & dataset

# Install the pipeline

```bash
conda create -n metaPTCM python=3.10
conda activate metaPTCM
pip install -e .
```

# install the qc dashboard

Install node js and npm on your system. [node js](https://nodejs.org/en/download/)

```bash
npm install
npm run dev
```
