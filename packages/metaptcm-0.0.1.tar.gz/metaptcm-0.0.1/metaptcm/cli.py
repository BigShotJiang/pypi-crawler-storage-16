import argparse
import logging
import os

from metaptcm.pipeline import MetaPTCMPipeline
from metaptcm.step.registry import dag_registry
from metaptcm.utils.stats import accumulate_stats


def setup_logger():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )


def setup_parser():
    parser = argparse.ArgumentParser()

    # add directory argument
    parser.add_argument(
        "-d",
        "--directory",
        dest="directory",
        help="Dataset directory",
        default=os.getcwd(),
    )

    parser.add_argument(
        "--clean", action="store_true", help="Start from scratch.", default=False
    )

    # add subparsers
    action_subparsers = parser.add_subparsers(dest="action")

    action_subparsers.add_parser("run", help="Run full pipeline")

    stats_parser = action_subparsers.add_parser("stats", help="Calculate stats")
    stats_parser.add_argument(
        "--version",
        type=str,
        default="0.1",
        help="Version of the stats",
    )
    stats_parser.add_argument(
        "--exclude",
        action="append",
        help="Project folder to exclude (can be specified multiple times)",
        default=[],
    )

    parser_step = action_subparsers.add_parser(
        "step", help="Run single step in pipeline"
    )

    # add step subparsers
    step_subparsers = parser_step.add_subparsers(dest="step")

    for _name, cls in dag_registry.steps.items():
        cls.register_parser(step_subparsers)

    return parser


def run():
    setup_logger()

    parser = setup_parser()
    args = parser.parse_args()

    # show help if no arguments are given
    if not vars(args):
        parser.print_help()
        parser.exit()

    # get directory from cli context
    directory = os.getcwd()
    directory = args.directory if directory in args else os.getcwd()

    pipeline = MetaPTCMPipeline(directory, load=not args.clean)

    if args.action == "step":
        if not args.step:
            parser.print_help()
            parser.exit()

        pipeline.add_step(dag_registry.get(args.step)(**vars(args)))

    if args.action == "run":
        pipeline.run()

    if args.action == "stats":
        accumulate_stats(os.getcwd(), args.version, args.exclude)

    pipeline.save_to_file()
