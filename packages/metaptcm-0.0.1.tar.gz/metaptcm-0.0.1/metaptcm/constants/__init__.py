import os

import yaml

# constant variables
RAW_DATA = "raw_data"
VALID_RAW_EXTENSIONS = ["raw", "mzml", "mzml.gz"]
OUTPUT = "output"
SPECLIB = "speclib"
STATS = "stats"
CONFIG_FOLDER = "config"

SAGE_CONFIG = "_tmp_sage_config.json"
STATE_PICKLE = "state.pkl"
ANNOTATION_NAME = "annotation.tsv"

RAW_FILE_PARSER_PATH = (
    "C:\\Users\\alphadia2\\ThermoRawFileParser1.4.3\\ThermoRawFileParser.exe"
)
SAGE_PATH = (
    "c:\\Users\\alphadia2\\Documents\\sage-v0.14.6-x86_64-pc-windows-msvc\\sage.exe"
)


GLOBAL_CONFIG_NAME = "global_config.yaml"
GLOBAL_CONFIG = {"RAW_FILE_PARSER_PATH": RAW_FILE_PARSER_PATH, "SAGE_PATH": SAGE_PATH}


# Search engine configuration - single source of truth for all search engine readers
SEARCH_ENGINE_CONFIG = {
    "maxquant": {
        "pattern": "evidence.txt",
        "reader_name": "maxquant",
        "raw_name_field": "file_name_no_suffix",
    },
    "sage": {
        "pattern": "results.sage.parquet",
        "reader_name": "sage_parquet",
        "raw_name_field": "file_name",
    },
    "msfragger": {
        "pattern": "*.pep.xml",
        "reader_name": "msfragger_pepxml",
        "raw_name_field": "file_name_no_suffix",
    },
}


# vocabulary

VOCABULARY = {}
# Load the vocabulary
vocabulary_path = os.path.join(os.path.dirname(__file__), "vocabulary.yaml")
with open(vocabulary_path) as file:
    VOCABULARY = yaml.safe_load(file)
