import logging
import os
import pickle

from metaptcm import constants


class MetaPTCMPipeline:
    def __init__(self, directory: str, load: bool = True):
        """Pipeline class for running a series of steps.
        The pipeline is a collection of steps that are run in sequence.
        It can be saved to and loaded from a directory.

        Parameters
        ----------

        directory : str
            The directory containing the pipeline state.

        load : bool
            Load the state from the directory.

        """
        self.directory = os.path.abspath(directory)
        self.name = os.path.basename(directory)
        self.steps = []
        if load:
            self.load_from_file()

    def __repr__(self):
        """Return a string representation of the pipeline."""
        return f"MetaPTCMDataset({self.directory})"

    def get_step(self, step_name: str):
        """Get a step by name from the pipeline.

        Parameters
        ----------

        step_name : str
            The name of the step to get.

        Returns
        -------

        step : Step
            The step with the given name.

        Raises
        ------

        KeyError
            If the step is not found in the pipeline.
        """
        for step in self.steps:
            if step.__class__.__name__ == step_name:
                return step
        raise KeyError(f"Step {step_name} not found in pipeline.")

    def add_step(self, step: object):
        """Add a step to the pipeline.

        Parameters
        ----------

        step : DAGStep
            The step to add to the pipeline.

        Raises
        ------

        KeyError
            If the step is already in the pipeline.
        """

        # check if step is already in pipeline
        for s in self.steps:
            if s.__class__.__name__ == step.__class__.__name__:
                raise KeyError(f"Step {step.__class__.__name__} already in pipeline.")

        self.steps.append(step)

    def run(self):
        """Run the pipeline by running each step in sequence."""
        for step in self.steps:
            step(self)

    def load_from_file(self):
        """Load the pipeline state from a file."""
        pickle_file = os.path.join(self.directory, constants.STATE_PICKLE)
        if os.path.exists(pickle_file):
            logging.info(f"Loading state from {pickle_file}")
            with open(pickle_file, "rb") as f:
                self.steps = pickle.load(f)
        else:
            logging.info(f"No state found in {pickle_file}")

    def save_to_file(self):
        """Save the pipeline state to a file."""
        pickle_file = os.path.join(self.directory, constants.STATE_PICKLE)
        logging.info(f"Saving state to {pickle_file}")
        with open(pickle_file, "wb") as f:
            pickle.dump(self.steps, f)
