import logging

from colorama import Fore, Style

from metaptcm.pipeline import MetaPTCMPipeline


class DAGStep:
    def __init__(self, *args, **kwargs):
        """Base class for a step in a directed acyclic graph (DAG).

        Each step in the DAG is a node in the graph. The step can have dependencies on other steps.
        """

        self._required_steps = []

    @property
    def required_steps(self):
        return self._required_steps

    @required_steps.setter
    def required_steps(self, value):
        self._required_steps = value

    def __str__(self):
        return self.__class__.__name__

    def __call__(self, pipeline: MetaPTCMPipeline):
        """Run the step.

        Parameters
        ----------

        pipeline : MetaPTCMPipeline
            The pipeline containing all steps.
        """

        logging.info("")
        logging.info(
            f"⚙️  Running step: {Style.BRIGHT}{Fore.GREEN}{self}{Style.RESET_ALL}"
        )

        logging.info(f"   Validating step {self}")
        if self.validate(pipeline) and self.validate_dependencies(pipeline):
            logging.info(
                f"   validation {Style.BRIGHT}{Fore.GREEN}successful{Style.RESET_ALL}."
            )
        else:
            logging.error(
                f"   validation {Style.BRIGHT}{Fore.RED}failed{Style.RESET_ALL}."
            )
            return

        self.run(pipeline)

    def validate_dependencies(self, pipeline: MetaPTCMPipeline):
        """Check if all dependencies are met before running the step.

        Parameters
        ----------

        pipeline : MetaPTCMPipeline
            The pipeline containing all steps.
        """
        logging.info(f"   Checking dependencies for {self}")
        all_reuired_steps_found = True
        for required_step in self.required_steps:
            required_step_found = False
            for step in pipeline.steps:
                if step.__class__.__name__ == required_step:
                    required_step_found = True
                    break

            if required_step_found:
                logging.info(f"   ✅ {required_step}")
            else:
                logging.info(f"   ❌ {required_step}")
                all_reuired_steps_found = False

        if not all_reuired_steps_found:
            logging.error(
                f"   {Style.BRIGHT}{Fore.RED} Not all dependencies met. Exiting.{Style.RESET_ALL}"
            )

        return all_reuired_steps_found

    def validate(self, pipeline: MetaPTCMPipeline):
        raise NotImplementedError("Validate method not implemented")

    def run(self, pipeline: MetaPTCMPipeline):
        raise NotImplementedError("Run method not implemented")

    @classmethod
    def register_parser(cls, subparser):
        step_parser = subparser.add_parser(
            cls.__name__.lower(), help=f"Run the {cls.__name__} step."
        )
        step_parser.add_argument(
            "--clean", action="store_true", help="Start from scratch."
        )
