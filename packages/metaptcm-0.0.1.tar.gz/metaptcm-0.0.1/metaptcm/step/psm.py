import logging
import os
from pathlib import Path

import pandas as pd

from metaptcm import constants
from metaptcm.step import dag
from metaptcm.step.registry import dag_registry
from metaptcm.utils.helper import tabs


class PSMDiscovery(dag.DAGStep):
    def __init__(self, *args, search_engine="maxquant", **kwargs):
        super().__init__(*args, **kwargs)
        """Class for performing PSM discovery with different search engines."""
        self.search_engine = search_engine
        self.psm_index = None

    def run(self, pipeline):
        self.psm_index = self.discover(pipeline)
        logging.info(f"✅ Found {len(self.psm_index)} PSM files.")

    def discover(self, pipeline):
        output_folder = os.path.join(pipeline.directory, constants.OUTPUT)
        search_folder = os.path.join(output_folder, self.search_engine)

        pattern = constants.SEARCH_ENGINE_CONFIG[self.search_engine]["pattern"]

        psm_list = []
        for path in Path(search_folder).rglob(pattern):
            root, file_name = os.path.split(path)
            logging.debug(
                f"Found {self.search_engine.capitalize()} PSM file at {path}."
            )
            psm_list.append(
                {
                    "path": path,
                    "file_name": file_name,
                    "root": root,
                    "type": self.search_engine,
                }
            )

        return pd.DataFrame(psm_list)

    def validate(self, pipeline):
        valid = True

        # Check if the search engine is known
        if self.search_engine not in constants.SEARCH_ENGINE_CONFIG:
            logging.error(tabs(2) + f"Unknown search engine: {self.search_engine}.")
            valid = False

        # Check if the output folder exists
        root_folder = pipeline.directory
        output_folder = os.path.join(root_folder, constants.OUTPUT)
        search_folder = os.path.join(output_folder, self.search_engine)

        if not os.path.exists(output_folder):
            logging.error(
                tabs(2)
                + f"Output folder {output_folder} not found. Please run search first."
            )
            valid = False

        if not os.path.exists(search_folder):
            logging.error(
                tabs(2)
                + f"Search output folder {search_folder} not found. Please run search first."
            )
            valid = False

        return valid

    @classmethod
    def register_parser(cls, subparser):
        step_parser = subparser.add_parser(
            cls.__name__.lower(), help=f"Run the {cls.__name__} step."
        )
        step_parser.add_argument(
            "--clean", action="store_true", help="Start from scratch."
        )

        step_parser.add_argument(
            "--search-engine",
            dest="search_engine",
            help=f"Search engine to use for PSM discovery. Valid options are: {', '.join(constants.SEARCH_ENGINE_CONFIG.keys())}.",
            choices=list(constants.SEARCH_ENGINE_CONFIG.keys()),
            default="unknown",
        )


# Register the discovery step
dag_registry.register(PSMDiscovery)
