import logging
import os
from pathlib import Path

import pandas as pd

from metaptcm import constants
from metaptcm.pipeline import MetaPTCMPipeline
from metaptcm.step import dag
from metaptcm.step.registry import dag_registry
from metaptcm.utils.helper import tabs


class RawDiscovery(dag.DAGStep):
    def __init__(self, save_index: bool = True, *args, **kwargs):
        super().__init__(*args, **kwargs)
        """Class for performing raw file discovery."""
        self.raw_index = None
        self.save_index = save_index
        self.valid_extensions = constants.VALID_RAW_EXTENSIONS

    def run(self, pipeline: MetaPTCMPipeline):
        """Run the raw file discovery step.

        Parameters
        ----------

        pipeline : MetaPTCMPipeline
            The pipeline object.

        """
        self.raw_index = self.discover(pipeline)

        if self.save_index:
            raw_index_path = os.path.join(pipeline.directory, "raw_index.tsv")
            self.raw_index.to_csv(raw_index_path, index=False, sep="\t")
            logging.info(f"✅ Saved raw index to {raw_index_path}")

        n_unique_files = len(self.raw_index["file_name_no_suffix"].unique())
        n_total_files = len(self.raw_index)
        logging.info(
            f"✅ Found {n_total_files} files with {n_unique_files} unique MS runs."
        )

    def discover(self, pipeline: MetaPTCMPipeline):
        """Discover raw files in the raw data folder.

        Parameters
        ----------
        pipeline : MetaPTCMPipeline
            The pipeline object.

        Returns
        -------
        pd.DataFrame
            Index of raw files with columns: path, file, type.

        """

        raw_file_folder = os.path.join(pipeline.directory, constants.RAW_DATA)

        file_list = []
        for path in Path(raw_file_folder).rglob("*"):
            if path.is_file() and path.suffix.lower()[1:] in self.valid_extensions:
                file_name = path.name
                file_type = path.suffix.lower()[1:]
                file_name_no_suffix = path.stem
                logging.debug(f"Found raw file: {path}")
                file_list.append(
                    {
                        "path": str(path),
                        "file_name": file_name,
                        "file_name_no_suffix": file_name_no_suffix,
                        "type": file_type,
                    }
                )

        return pd.DataFrame(file_list)

    def validate(self, pipeline: MetaPTCMPipeline):
        """Validate the raw file discovery step.

        Parameters
        ----------

        pipeline : MetaPTCMPipeline
            The pipeline object.

        Returns
        -------
        bool
            True if the step is valid, False otherwise.

        """
        valid = True

        raw_file_folder = os.path.join(pipeline.directory, constants.RAW_DATA)

        if not os.path.exists(raw_file_folder):
            logging.error(tabs(2) + f"Raw data folder {raw_file_folder} not found.")
            valid = False

        return valid

    @classmethod
    def register_parser(cls, subparser):
        step_parser = subparser.add_parser(
            cls.__name__.lower(), help=f"Run the {cls.__name__} step."
        )
        step_parser.add_argument(
            "--clean", action="store_true", help="Start from scratch."
        )
        step_parser.add_argument(
            "--save-index",
            action="store_true",
            dest="save_index",
            help="Save the raw index to disk.",
        )


# Register the discovery step
dag_registry.register(RawDiscovery)
