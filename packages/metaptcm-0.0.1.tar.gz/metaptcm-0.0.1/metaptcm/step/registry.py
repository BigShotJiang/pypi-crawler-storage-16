class StepProvider:
    def __init__(self) -> None:
        self.steps = {}

    def register(self, step):
        self.steps[step.__name__.lower()] = step

    def get(self, name):
        return self.steps[name.lower()]


dag_registry = StepProvider()
