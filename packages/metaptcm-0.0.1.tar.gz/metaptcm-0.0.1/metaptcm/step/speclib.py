import logging
import multiprocessing as mp
import os
import traceback
from pathlib import Path

import pandas as pd
from alphabase.peptide.fragment import get_charged_frag_types
from alphabase.psm_reader.psm_reader import psm_reader_provider
from alphabase.spectral_library.base import SpecLibBase
from alphabase.spectral_library.flat import SpecLibFlat
from alpharaw.mzml import MzMLReader
from alpharaw.thermo import ThermoRawData

from metaptcm import constants
from metaptcm.pipeline import MetaPTCMPipeline
from metaptcm.step import dag
from metaptcm.step.registry import dag_registry
from metaptcm.utils.annotation import (
    add_dense_lib,
    annotate_fragments_flat,
    annotate_precursors_flat,
)
from metaptcm.utils.helper import get_mp_mode


class CreateSpecLib(dag.DAGStep):
    def __init__(
        self,
        num_proc: int = 1,
        ppm: int = 20,
        sanitize_filename: bool = False,
        *args,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)

        self.required_steps = [
            "PSMDiscovery",
            "RawDiscovery",
        ]
        self.num_proc = num_proc
        self.ppm = ppm
        self.sanitize_filename = sanitize_filename
        self.charged_frag_types = get_charged_frag_types(
            [
                "a",
                "x",
                "b",
                "y",
                "c",
                "z",
                "b_NH3",
                "y_NH3",
                "b_H2O",
                "y_H2O",
                "c_lossH",
                "z_addH",
            ],
            2,
        )

    @classmethod
    def register_parser(cls, subparser):
        step_parser = subparser.add_parser(
            cls.__name__.lower(), help=f"Run the {cls.__name__} step."
        )
        step_parser.add_argument(
            "--clean", action="store_true", help="Start from scratch."
        )

        step_parser.add_argument(
            "--num-proc",
            type=int,
            dest="num_proc",
            default=1,
            help="Number of threads to use.",
        )
        step_parser.add_argument(
            "--ppm",
            dest="ppm",
            type=int,
            default=20,
            help="Mass error in ppm.",
        )
        step_parser.add_argument(
            "--sanitize-filename",
            action="store_true",
            dest="sanitize_filename",
            help="Sanitize raw file names (remove special characters).",
        )

    def run(self, pipeline: MetaPTCMPipeline) -> None:
        """Process PSM files to create spectral libraries with metadata annotations.

        This method processes each PSM file in the pipeline to create annotated spectral
        libraries. It handles multiprocessing for raw file processing and saves the
        results in batches.

        Parameters
        ----------
        pipeline : MetaPTCMPipeline
            Pipeline object containing raw and PSM discovery steps

        Notes
        -----
        The method performs the following steps for each PSM file:
        1. Retrieves PSM data from the file
        2. Sets up metadata (project name, partition name and raw name)
        3. Processes raw files in parallel using multiprocessing
        4. Filters out failed processing attempts
        5. Saves the resulting spectral libraries in batches

        """
        raw_index = pipeline.get_step("RawDiscovery").raw_index
        psm_index = pipeline.get_step("PSMDiscovery").psm_index

        for psm_num, path, file, _root, type in psm_index.itertuples():
            logging.info(f"({psm_num + 1}/{len(psm_index)}) Processing {file}")

            precursor_df = self._get_psm(type, path)
            logging.info(f"   Found {len(precursor_df):,} PSMs.")

            metadata_project_name = pipeline.name
            metadata_partition_name = _sanitized_partition_name(
                path, pipeline.directory
            )

            mp_args = self._build_mp_args(
                precursor_df,
                raw_index,
                type,
                len(psm_index),
                metadata_project_name,
                metadata_partition_name,
            )

            mode = get_mp_mode()
            with mp.get_context(mode).Pool(processes=self.num_proc) as pool:
                speclib_list = pool.map(process_raw_file, mp_args)

            # Filter out None results (if any)
            speclib_list = [lib for lib in speclib_list if lib]

            if len(speclib_list) == 0:
                logging.error("Spectral library is empty.")
                continue

            self._process_and_save_batches(
                speclib_list, psm_num, pipeline, metadata_partition_name
            )

        logging.info(f"Completed processing {file}")

    def _process_and_save_batches(
        self,
        speclib_list: list[SpecLibBase],
        psm_num: int,
        pipeline: MetaPTCMPipeline,
        metadata_partition_name: str,
        batch_size: int = 50,
    ) -> None:
        """Process and save spectral libraries in batches.

        Parameters
        ----------
        speclib_list : list[SpecLibBase]
            List of spectral libraries to process
        psm_num : int
            PSM file index number
        pipeline : MetaPTCMPipeline
            Pipeline object containing output directory information
        metadata_partition_name : str
            Name of the partition for file naming
        batch_size : int, optional
            Number of libraries to process in each batch, by default 50

        """
        for batch_num, batch_start in enumerate(
            range(0, len(speclib_list), batch_size)
        ):
            batch_end = min(batch_start + batch_size, len(speclib_list))
            batch = speclib_list[batch_start:batch_end]

            merged_lib = batch[0]
            for speclib in batch[1:]:
                merged_lib.append(speclib)

            n_precursors = len(merged_lib.precursor_df)
            n_fragments = len(merged_lib.fragment_df)
            n_frag_types = len(merged_lib.charged_frag_types)

            logging.info(
                f"   Batch {batch_num}: Merged {n_precursors:,} PSMs and {n_fragments:,} fragments."
            )
            logging.info(
                f"   Batch {batch_num}: Annotated {n_frag_types} fragment types."
            )
            filename = f"{metadata_partition_name}_{psm_num}_batch_{batch_num}.hdf"

            output_folder = os.path.join(
                pipeline.directory, constants.OUTPUT, constants.SPECLIB
            )
            os.makedirs(output_folder, exist_ok=True)
            merged_lib.save_hdf(os.path.join(output_folder, filename))
            logging.info(f"Saved {filename}")

    def validate(self, pipeline: MetaPTCMPipeline) -> bool:
        valid = True

        try:
            raw_discovery = pipeline.get_step("RawDiscovery")
            if raw_discovery.raw_index is None or raw_discovery.raw_index.empty:
                logging.error("RawDiscovery: raw_index DataFrame is empty or None.")
                valid = False
        except KeyError:
            logging.error("RawDiscovery step not found in pipeline.")
            valid = False

        try:
            psm_discovery = pipeline.get_step("PSMDiscovery")
            if psm_discovery.psm_index is None or psm_discovery.psm_index.empty:
                logging.error("PSMDiscovery: psm_index DataFrame is empty or None.")
                valid = False
        except KeyError:
            logging.error("PSMDiscovery step not found in pipeline.")
            valid = False

        return valid

    def _build_mp_args(
        self,
        precursor_df,
        raw_index,
        type,
        n_raw,
        metadata_project_name,
        metadata_partition_name,
    ):
        group_iterator = precursor_df.groupby("raw_name")
        n_raw = len(group_iterator)

        mp_args = []
        for j, (raw_name, group_df) in enumerate(group_iterator):
            raw_name = self.get_sanitized_filename(raw_name)

            config = constants.SEARCH_ENGINE_CONFIG[type]
            raw_name_field = config["raw_name_field"]
            raw_df = raw_index[raw_index[raw_name_field] == raw_name]

            if raw_df.empty:
                logging.error(f"Raw file {raw_name} not found.")
                continue
            mp_args.append(
                (
                    raw_df,
                    group_df,
                    raw_name,
                    j,
                    n_raw,
                    self.ppm,
                    self.charged_frag_types,
                    metadata_project_name,
                    metadata_partition_name,
                )
            )
        return mp_args

    @staticmethod
    def _get_psm(type: str, path: str | Path) -> pd.DataFrame:
        if type not in constants.SEARCH_ENGINE_CONFIG:
            raise NotImplementedError(f"PSM type {type} not implemented.")

        config = constants.SEARCH_ENGINE_CONFIG[type]
        reader_name = config["reader_name"]
        return psm_reader_provider.get_reader(reader_name).import_file(str(path))

    def get_sanitized_filename(self, raw_name: str) -> str:
        if self.sanitize_filename:
            return (
                raw_name.strip()
                .replace("+", "")
                .replace("ä", "a")
                .replace("ö", "o")
                .replace("ü", "u")
                .replace("ß", "s")
            )
        else:
            return str(raw_name).strip()


# Move these methods outside the class to make them picklable
def _get_raw_data_object(type: str, path: str) -> ThermoRawData | MzMLReader:
    """Create a raw data reader object based on the file type.

    Parameters
    ----------
    type : str
        Type of raw data file ('raw' for Thermo Raw or 'mzml' for mzML format)
    path : str
        Path to the raw data file

    Returns
    -------
    Union[ThermoRawData, MzMLReader]
        Raw data reader object for the specified file

    Raises
    ------
    NotImplementedError
        If the specified file type is not supported

    Notes
    -----
    Currently supports two file types:
    - 'raw': Thermo Raw files (using ThermoRawData with activation data)
    - 'mzml': mzML format files (using MzMLReader)
    """
    if type == "raw":
        raw_file = ThermoRawData(process_count=1, auxiliary_items=["activation"])
        raw_file.import_raw(path)
        return raw_file
    elif type == "mzml":
        raw_file = MzMLReader()
        raw_file.import_raw(path)
        return raw_file
    else:
        raise NotImplementedError(f"File type {type} not implemented.")


def extract_spectra(
    raw_data: ThermoRawData | MzMLReader,
    precursor_df: pd.DataFrame,
    charged_frag_types: list[str],
    ppm: int = 20,
    metadata_project_name: str = "",
    metadata_partition_name: str = "",
    metadata_raw_name: str = "",
) -> SpecLibBase:
    """Extract and annotate spectra from raw mass spectrometry data.

    Parameters
    ----------
    raw_data : Union[ThermoRawData, MzMLReader]
        Raw mass spectrometry data object containing the spectra
    precursor_df : pd.DataFrame
        DataFrame containing precursor information
    charged_frag_types : list
        List of fragment types to consider for annotation
    ppm : int, optional
        Mass error tolerance in parts per million, by default 20
    metadata_project_name : str, optional
        Name of the project for metadata annotation, by default ""
    metadata_partition_name : str, optional
        Name of the partition for metadata annotation, by default ""
    metadata_raw_name : str, optional
        Name of the raw file for metadata annotation, by default ""

    Returns
    -------
    SpecLibBase
        Annotated spectral library containing precursor and fragment information
        with added metadata columns

    Notes
    -----
    This function performs several steps:
    1. Creates a dense spectral library from a precursor_df
    2. Annotates flat library precursors and fragments
    3. Annotates dense library to flat library
    4. Adds metadata columns
    """
    dense_lib = SpecLibBase(charged_frag_types=charged_frag_types)
    dense_lib.precursor_df = precursor_df.reset_index(drop=True)
    dense_lib.calc_precursor_mz()
    dense_lib.hash_precursor_df()
    dense_lib.calc_fragment_mz_df()

    flat_lib = SpecLibFlat(charged_frag_types=charged_frag_types)
    flat_lib.parse_base_library(dense_lib)
    del dense_lib

    annnotated_lib = annotate_precursors_flat(flat_lib, raw_data, spec_idx_offset=0)
    annnotated_lib = annotate_fragments_flat(
        annnotated_lib, raw_data, mass_error_ppm=ppm
    )
    annnotated_lib = add_dense_lib(annnotated_lib, charged_frag_types)
    annnotated_lib._protein_df = pd.DataFrame()
    print(f"      Annotated {len(annnotated_lib.precursor_df):,} PSMs.")

    # add metadata to the library
    annnotated_lib._precursor_df["metadata_project_name"] = metadata_project_name
    annnotated_lib._precursor_df["metadata_partition_name"] = metadata_partition_name
    annnotated_lib._precursor_df["metadata_raw_name"] = metadata_raw_name

    return annnotated_lib


def process_raw_file(
    args: tuple[pd.DataFrame, pd.DataFrame, str, int, int, int, list[str]],
) -> SpecLibBase | None:
    """Helper function to process a raw mass spectrometry file using multiprocessing.

    Parameters
    ----------
    args : tuple
        Contains the following elements:
        - raw_df : pd.DataFrame
            DataFrame containing raw file information including type and path
        - group_df : pd.DataFrame
            DataFrame containing PSM group information
        - raw_name : str
            Name of the raw file being processed
        - i : int
            Current file index
        - n_raw : int
            Total number of raw files to process
        - ppm : int
            Mass error tolerance in parts per million
        - charged_frag_types : list
            List of fragment types to consider

    Returns
    -------
    SpecLibBase or None
        Annotated spectral library if successful, None if processing fails
    """
    (
        raw_df,
        group_df,
        raw_name,
        i,
        n_raw,
        ppm,
        charged_frag_types,
        metadata_project_name,
        metadata_partition_name,
    ) = args
    print(f"   ({i + 1}/{n_raw}) Processing {raw_name} with {len(group_df):,} PSMs.")

    try:
        raw_data = _get_raw_data_object(
            raw_df["type"].values[0], raw_df["path"].values[0]
        )
        # Get raw name from raw file path
        metadata_raw_name = os.path.basename(raw_data.raw_file_path).split(".")[0]

        return extract_spectra(
            raw_data,
            group_df,
            charged_frag_types,
            ppm,
            metadata_project_name,
            metadata_partition_name,
            metadata_raw_name,
        )
    except Exception as e:
        logging.error(f"Error processing {raw_name}: {e}")
        # log the stack trace
        logging.error(traceback.format_exc())
        return None


def _sanitized_partition_name(psm_path: str | Path, pipeline_directory: str) -> str:
    """Create a sanitized partition name from PSM file path.

    Parameters
    ----------
    psm_path : str | Path
        Path to the PSM file
    pipeline_directory : str
        Root directory of the pipeline

    Returns
    -------
    str
        Sanitized partition name with non-specific folders removed
        and path separators replaced with underscores

    Examples
    --------
    >>> _sanitized_partition_name("project/output/maxquant/file.txt", "project")
    'file_txt'
    """

    non_specific_items = ["output"] + list(constants.SEARCH_ENGINE_CONFIG.keys())
    rel_path = os.path.relpath(psm_path, pipeline_directory)
    # iterate over folders in the path and remove non-specific items
    partition_name = [
        item for item in rel_path.split(os.path.sep) if item not in non_specific_items
    ]
    return "_".join(partition_name).replace(".", "_")


dag_registry.register(CreateSpecLib)
