import json
import logging
import multiprocessing as mp
import os
import pickle
from abc import abstractmethod
from collections import Counter
from multiprocessing import get_logger, log_to_stderr
from pathlib import Path
from typing import Any

import numpy as np
from alphabase.spectral_library.flat import SpecLibFlat

from metaptcm import constants
from metaptcm.step import dag
from metaptcm.step.registry import dag_registry
from metaptcm.utils.helper import get_mp_mode


class Metric:
    def __init__(self, name: str = ""):
        self.name = name

    @abstractmethod
    def to_dict(self):
        pass


class CounterMetric(Metric):
    def __init__(self, *args, name: str = "", **kwargs):
        super().__init__(name=name)
        self.counter = Counter(*args, **kwargs)

    def __str__(self):
        return self.counter.__str__()

    def to_dict(self):
        return {
            "name": self.name,
            "type": "CounterMetric",
            "value": dict(self.counter),
            "data": None,
        }

    def __add__(self, other):
        return CounterMetric(self.counter + other.counter, name=self.name)


class UniqueMetric(Metric):
    def __init__(self, *args, name: str = "", **kwargs):
        super().__init__(name=name)
        self.counter = Counter(*args, **kwargs)

    def __str__(self):
        return self.counter.__str__()

    def to_dict(self):
        return {
            "name": self.name,
            "type": "UniqueMetric",
            "value": {
                "n_total": sum(self.counter.values()),
                "n_unique": len(self.counter),
            },
        }

    def __add__(self, other):
        return UniqueMetric(self.counter + other.counter, name=self.name)


class BoxplotMetric(Metric):
    def __init__(self, x, name: str = ""):
        super().__init__(name=name)
        self.x = self.valid(x)

    def valid(self, x):
        return x[np.isfinite(x)]

    def to_dict(self):
        return {
            "name": self.name,
            "type": "BoxplotMetric",
            "value": {
                "min": float(np.min(self.x)),
                "Q1": float(np.quantile(self.x, 0.25)),
                "Q2": float(np.quantile(self.x, 0.5)),
                "Q3": float(np.quantile(self.x, 0.75)),
                "max": float(np.max(self.x)),
            },
            "data": None,
        }

    def __add__(self, other):
        return BoxplotMetric(np.concatenate([self.x, other.x]), name=self.name)


class MetricNode:
    def __init__(
        self,
        name: str,
        level: str,
        metrics: list[Metric] = None,
        children: list["MetricNode"] = None,
    ):
        if children is None:
            children = []
        if metrics is None:
            metrics = []
        self.name = name
        self.level = level
        self.metrics = metrics
        self.children = children

        self._accumulated_metrics()

    def _accumulated_metrics(self):
        for child in self.children:
            for child_metric in child.metrics:
                # Check if metric already exists
                metric_exists = False
                for i, own_metric in enumerate(self.metrics):
                    if child_metric.name == own_metric.name:
                        self.metrics[i] += child_metric
                        metric_exists = True

                # Only append if no matching metric was found
                if not metric_exists:
                    self.metrics.append(child_metric)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "level": self.level,
            "metrics": [metric.to_dict() for metric in self.metrics],
            "children": [child.to_dict() for child in self.children],
        }


class StatsAccumulator(dag.DAGStep):
    def __init__(self, num_proc: int = 1, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.num_proc = num_proc

        self.stats_df = None

    def run(self, pipeline):
        """Accumulate statistics from spectral library HDF files.

        Parameters
        ----------
        pipeline : MetaPTCMPipeline
            Pipeline object containing directory information
        """
        speclib_folder = os.path.join(
            pipeline.directory, constants.OUTPUT, constants.SPECLIB
        )

        file_list = []
        for file in Path(speclib_folder).rglob("*"):
            if file.is_file() and file.suffix == ".hdf":
                file_list.append(file)

        # Configure logging for multiprocessing
        log_to_stderr(logging.INFO)
        logger = get_logger()
        logger.setLevel(logging.INFO)

        mode = get_mp_mode()
        with mp.get_context(mode).Pool(processes=self.num_proc) as pool:
            partition_metric_nodes = pool.map(_speclib_stats, file_list)

        project_metric_node = MetricNode(
            name=pipeline.name, level="project", children=partition_metric_nodes
        )

        # save to json
        os.makedirs(
            os.path.join(pipeline.directory, constants.OUTPUT, constants.STATS),
            exist_ok=True,
        )

        stats_pickle_path = os.path.join(
            pipeline.directory, constants.OUTPUT, constants.STATS, "stats.pickle"
        )
        stats_json_path = os.path.join(
            pipeline.directory, constants.OUTPUT, constants.STATS, "stats.json"
        )

        logging.info(f"Saving metric node to {stats_pickle_path}")
        with open(stats_pickle_path, "wb") as f:
            pickle.dump(project_metric_node, f)

        logging.info(f"Saving metrics to {stats_json_path}")
        with open(stats_json_path, "w") as f:
            json.dump(project_metric_node.to_dict(), f)

    def validate(self, pipeline):
        valid = True

        speclib_folder = os.path.join(pipeline.directory, constants.OUTPUT, "speclib")

        if not os.path.exists(speclib_folder):
            logging.error(f"Spectral library folder not found: {speclib_folder}")
            valid = False

        return valid

    @classmethod
    def register_parser(cls, subparser):
        step_parser = subparser.add_parser(
            cls.__name__.lower(), help=f"Run the {cls.__name__} step."
        )
        step_parser.add_argument(
            "--clean", action="store_true", help="Start from scratch."
        )
        step_parser.add_argument(
            "--num-proc",
            type=int,
            dest="num_proc",
            default=1,
            help="Number of threads to use.",
        )


def _speclib_stats(speclib_path):
    logger = get_logger()
    logger.info(f"Calculating stats for {speclib_path}")

    try:
        spec_lib = SpecLibFlat()
        spec_lib.load_hdf(speclib_path)

        os.path.dirname(speclib_path)

        raw_name_metric_nodes = []
        for metadata_raw_name, group_df in spec_lib.precursor_df.groupby("raw_name"):
            metrics = []

            # Add metrics only if columns exist
            if "sequence" in group_df.columns:
                metrics.append(
                    UniqueMetric(group_df["sequence"].to_list(), name="sequence")
                )
                metrics.append(
                    CounterMetric(
                        group_df["sequence"].str[-1].to_list(), name="last_aa"
                    )
                )

            # Create tuple of (modified_sequence, charge) for unique precursor identification
            if all(
                [
                    col in group_df.columns
                    for col in ["sequence", "charge", "mods", "mod_sites"]
                ]
            ):
                seq_charge = list(
                    zip(
                        group_df["sequence"],
                        group_df["charge"],
                        group_df["mods"],
                        group_df["mod_sites"],
                    )
                )
                metrics.append(
                    UniqueMetric(seq_charge, name="modified_sequence_charge")
                )

            metrics.append(CounterMetric(group_df["charge"].to_list(), name="charge"))

            if "mod_seq_charge_hash" in group_df.columns:
                metrics.append(
                    UniqueMetric(
                        group_df["mod_seq_charge_hash"].to_list(), name="precursor"
                    )
                )

            if "nAA" in group_df.columns:
                metrics.append(CounterMetric(group_df["nAA"].to_list(), name="nAA"))

            if "mods" in group_df.columns:
                metrics.append(
                    CounterMetric(
                        [
                            mod
                            for mod in group_df["mods"].str.split(";").explode()
                            if mod
                        ],
                        name="mods",
                    )
                )

            if "activation" in group_df.columns:
                metrics.append(
                    CounterMetric(
                        group_df["activation"].to_list(),
                        name="activation",
                    )
                )

            if "mass_accuracy" in group_df.columns:
                metrics.append(
                    BoxplotMetric(
                        group_df["mass_accuracy"].to_numpy(),
                        name="mass_accuracy",
                    )
                )

            if "pif" in group_df.columns:
                metrics.append(
                    BoxplotMetric(
                        group_df["pif"].to_numpy(),
                        name="pif",
                    )
                )

            if "sequence_coverage" in group_df.columns:
                metrics.append(
                    BoxplotMetric(
                        group_df["sequence_coverage"].to_numpy(),
                        name="sequence_coverage",
                    )
                )

            raw_name_metric_node = MetricNode(
                name=metadata_raw_name, level="metadata_raw_name", metrics=metrics
            )
            raw_name_metric_nodes.append(raw_name_metric_node)

        return MetricNode(
            name=spec_lib.precursor_df["metadata_partition_name"].iloc[0],
            level="metadata_partition",
            children=raw_name_metric_nodes,
        )
    except Exception as e:
        logger.error(f"Error processing {speclib_path}: {str(e)}")
        raise


# Register the stats step
dag_registry.register(StatsAccumulator)
