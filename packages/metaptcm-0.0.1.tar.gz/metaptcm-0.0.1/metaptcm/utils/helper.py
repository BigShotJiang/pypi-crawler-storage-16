import platform


def tabs(number_of_tabs):
    return "    " * number_of_tabs


def get_mp_mode():
    return "spawn" if platform.system() != "Linux" else "forkserver"
