import json
import logging
import os
import pickle

from metaptcm import constants
from metaptcm.step.stats import MetricNode


def accumulate_stats(path, version, exclude=None):
    """Accumulate statistics from pickle files in project folders."""
    children = []
    exclude = exclude or []

    for folder_name in os.listdir(path):
        if folder_name in exclude:
            logging.info(f"⏭️ Excluding {folder_name} as requested")
            continue

        project_folder = os.path.join(path, folder_name)
        if os.path.isdir(project_folder):
            stats_path = os.path.join(
                project_folder, constants.OUTPUT, constants.STATS, "stats.pickle"
            )
            if os.path.exists(stats_path):
                logging.info(f"✅ Loading stats from {stats_path}")
            else:
                logging.info(
                    f"❌ Skipping {project_folder} because stats.pickle does not exist"
                )
                continue

            with open(stats_path, "rb") as f:
                stats_node = pickle.load(f)
                children.append(stats_node)

    # Create root metric node
    root_metric_node = MetricNode(
        name=f"metaPTCM {version}", level="root", children=children
    )

    # Save to pickle
    name = f"metaPTCM_{version}.json"
    with open(os.path.join(path, name), "w") as f:
        logging.info(f"Saving stats to {os.path.join(path, name)}")
        json.dump(root_metric_node.to_dict(), f)
