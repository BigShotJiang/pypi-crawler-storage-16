# Sentinel value for code_version in struct serialization
DEFAULT_CODE_VERSION = "metaxy__intitial"
