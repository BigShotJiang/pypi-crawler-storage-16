class WeekStartDayTypes:
    monday = "monday"
    tuesday = "tuesday"
    wednesday = "wednesday"
    thursday = "thursday"
    friday = "friday"
    saturday = "saturday"
    sunday = "sunday"
    default = monday
    options = [monday, tuesday, wednesday, thursday, friday, saturday, sunday]
