# MEYElens





Quick checklist – fresh install of WSL + GPU-enabled TensorFlow (Windows 11 / Windows 10 21H2+)

    All commands are meant for PowerShell (admin) or Ubuntu 22.04 inside WSL as noted.

1. Install WSL and Ubuntu

    Open PowerShell as Administrator

    wsl --install

        Reboot when prompted.

    Launch Ubuntu from the Start menu and create a Linux username and password.

2. Install NVIDIA WSL GPU driver on Windows

    Download “CUDA enabled driver for WSL” from NVIDIA’s site, run the installer, then reboot Windows.

3. Prepare Ubuntu repositories (inside WSL)

# import NVIDIA key
sudo mkdir -p /usr/share/keyrings
curl -fsSL https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-archive-keyring.gpg \
 | sudo tee /usr/share/keyrings/cuda-archive-keyring.gpg >/dev/null

# CUDA repo
echo "deb [signed-by=/usr/share/keyrings/cuda-archive-keyring.gpg] \
https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/ /" \
 | sudo tee /etc/apt/sources.list.d/cuda.list

# cuDNN repo
echo "deb [signed-by=/usr/share/keyrings/cuda-archive-keyring.gpg] \
https://developer.download.nvidia.com/compute/cudnn/repos/ubuntu2204/x86_64/ /" \
 | sudo tee /etc/apt/sources.list.d/cudnn.list

sudo apt update

4. Install minimal CUDA 12.4 runtime and cuDNN 8.9

sudo apt install -y cuda-compat-12-4 libcudnn8 libcudnn8-dev

Add runtime path:

echo 'export LD_LIBRARY_PATH=/usr/local/cuda/lib64:/usr/lib/wsl/lib:$LD_LIBRARY_PATH' >> ~/.bashrc
source ~/.bashrc
sudo ldconfig

Verify cuDNN appears:

ldconfig -p | grep cudnn | head

5. Install Miniconda and TensorFlow

# Miniconda (run once)
wget https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh
bash Miniconda3-latest-Linux-x86_64.sh
source ~/.bashrc

# create env and install TF built for CUDA 12 + cuDNN 8.9
conda create -n tf python=3.10 -y
conda activate tf
pip install --upgrade pip
pip install --no-deps tensorflow==2.16.2

6. Confirm everything

# driver visible?
nvidia-smi

# TensorFlow sees GPU?
python - <<'PY'
import tensorflow as tf
print("TF:", tf.__version__)
print("GPUs:", tf.config.list_physical_devices('GPU'))
PY