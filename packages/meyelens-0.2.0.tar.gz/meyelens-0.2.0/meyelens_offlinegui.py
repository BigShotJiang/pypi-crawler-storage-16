"""
Launch the MEYElens GUI via ``python -m meyelens_offlinegui``.
"""

from meyelens.meyelens_gui import main


if __name__ == "__main__":
    main()
