# Default configuration values
HOST = "127.0.0.1"
PORT = 8000
BUFFER_SIZE = 4096
BACKLOG = 5
ENCODING = "utf-8"