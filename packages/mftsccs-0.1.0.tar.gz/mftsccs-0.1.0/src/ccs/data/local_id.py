"""
Local ID generator - generates unique negative IDs for local concepts.

Local/virtual concepts use negative IDs to distinguish them from
server-assigned positive IDs. After sync, the server assigns a
permanent positive ID.
"""

import random
from threading import Lock


class LocalId:
    """
    Thread-safe generator for unique local (negative) concept IDs.

    Local IDs are always negative to distinguish them from server IDs.
    The ID counter decrements to ensure uniqueness within a session.

    Example:
        >>> concept_id = LocalId.get_concept_id()
        >>> print(concept_id)  # e.g., -1
        >>> connection_id = LocalId.get_connection_id()
        >>> print(connection_id)  # e.g., -1
    """

    _concept_counter: int = 0
    _connection_counter: int = 0
    _lock: Lock = Lock()

    @classmethod
    def get_concept_id(cls) -> int:
        """
        Get a new unique negative ID for a local concept.

        Returns:
            A unique negative integer ID.
        """
        with cls._lock:
            cls._concept_counter -= 1
            return cls._concept_counter

    @classmethod
    def get_connection_id(cls) -> int:
        """
        Get a new unique negative ID for a local connection.

        Returns:
            A unique negative integer ID.
        """
        with cls._lock:
            cls._connection_counter -= 1
            return cls._connection_counter

    @classmethod
    def get_random_id(cls) -> int:
        """
        Get a random negative ID (legacy compatibility).

        Returns:
            A random negative integer ID.
        """
        return -random.randint(1, 100_000_000)

    @classmethod
    def reset(cls) -> None:
        """Reset the ID counters (mainly for testing)."""
        with cls._lock:
            cls._concept_counter = 0
            cls._connection_counter = 0
