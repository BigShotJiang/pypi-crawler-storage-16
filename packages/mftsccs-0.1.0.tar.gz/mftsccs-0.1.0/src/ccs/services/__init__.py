"""
Services for the CCS library.

Contains business logic for concept creation, retrieval, and management.
"""

from ccs.services.local import (
    CreateTheConceptLocal,
    MakeTheConceptLocal,
    MakeTheTypeConceptLocal,
    MakeTheInstanceConceptLocal,
    GetConceptByCharacterAndCategoryLocal,
    SplitStrings,
)

__all__ = [
    # Local services
    "CreateTheConceptLocal",
    "MakeTheConceptLocal",
    "MakeTheTypeConceptLocal",
    "MakeTheInstanceConceptLocal",
    "GetConceptByCharacterAndCategoryLocal",
    "SplitStrings",
]
