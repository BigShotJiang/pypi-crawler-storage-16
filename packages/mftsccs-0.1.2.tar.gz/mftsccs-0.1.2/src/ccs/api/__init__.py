"""
API functions for communicating with the CCS backend.
"""

from ccs.api.get_concept import GetConcept

__all__ = [
    "GetConcept",
]
