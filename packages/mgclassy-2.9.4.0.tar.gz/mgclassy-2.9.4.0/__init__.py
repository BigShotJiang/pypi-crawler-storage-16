from ._classy import (
    __version__,
    Class,
    CosmoSevereError,
    CosmoComputationError
)
