from ._mgclassy import (
    __version__,
    Class,
    CosmoSevereError,
    CosmoComputationError
)
