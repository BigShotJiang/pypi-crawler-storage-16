import typer

__all__ = ('app', )


app = typer.Typer(
    name="MGost",
)
