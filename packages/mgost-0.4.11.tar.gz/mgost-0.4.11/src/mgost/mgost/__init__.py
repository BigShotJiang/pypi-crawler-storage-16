from .mgost import MGost
