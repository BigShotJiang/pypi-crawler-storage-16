# LOCAL_MODEL_NAME = "qwen3-coder:latest" # Use this for best results when testing locally
# LOCAL_MODEL_NAME = "deepseek-r1:latest" # fails and slow
LOCAL_MODEL_NAME = "qwen2.5-coder:latest" # fails. Hallucinating more but fast
# LOCAL_MODEL_NAME = "mistral:latest" # fails not responding in expected format. Runs same command multiple times
# LOCAL_MODEL_NAME = "phi3:latest" # fails
# LOCAL_MODEL_NAME = "llama3:latest" # fails, hallucinates
# LOCAL_MODEL_NAME = "qwen3:latest" # good but slow
LOCAL_MODEL_PORT = "11434"