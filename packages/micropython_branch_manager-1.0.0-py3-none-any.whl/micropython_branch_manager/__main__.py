"""Entry point for python -m micropython_branch_manager."""

from .cli import main

if __name__ == "__main__":
    main()
