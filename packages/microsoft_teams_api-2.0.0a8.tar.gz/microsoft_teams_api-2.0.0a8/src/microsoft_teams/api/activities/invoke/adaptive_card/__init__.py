"""
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the MIT License.
"""

from .action import AdaptiveCardInvokeActivity

__all__ = ["AdaptiveCardInvokeActivity"]
