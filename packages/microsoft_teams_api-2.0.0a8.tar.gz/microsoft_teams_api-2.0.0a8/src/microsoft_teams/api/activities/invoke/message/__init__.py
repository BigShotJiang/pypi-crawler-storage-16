"""
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the MIT License.
"""

from .submit_action import MessageSubmitActionInvokeActivity

__all__ = ["MessageSubmitActionInvokeActivity"]
