# Microsoft Teams BotBuilder

<p>
    <a href="https://pypi.org/project/microsoft-teams-botbuilder/" target="_blank">
        <img src="https://img.shields.io/pypi/v/microsoft-teams-botbuilder" />
    </a>
    <a href="https://pypi.org/project/microsoft-teams-botbuilder" target="_blank">
        <img src="https://img.shields.io/pypi/dw/microsoft-teams-botbuilder" />
    </a>
</p>

A package used to make the `microsoft-teams-apps` package backwards compatible with legacy bots built using
`BotBuilder`.

<a href="https://microsoft.github.io/teams-sdk" target="_blank">
    <img src="https://img.shields.io/badge/📖 Getting Started-blue?style=for-the-badge" />
</a>
