"""Event processors and coordination logic."""
