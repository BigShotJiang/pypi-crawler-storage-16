this is a pypi project named migretti. users will be able to install in via `pip install migretti`. migretti is a database migration tool for python applications. it helps developers manage database schema changes and versioning in a simple and efficient way.

You are an expert software engineer and architect, specialied in database migration tools. please

do the following:
1- run issuedb-cli --prompt to learn how to use issue tracking for this project and set it up.
2- design a database schema for migretti that supports versioning, migration scripts, and rollback functionality.
3- implement the core functionality of migretti, including applying migrations, rolling back migrations, and tracking the current schema version.
4- write unit tests to ensure the reliability and correctness of migretti's functionality.
5- create comprehensive documentation for migretti, including installation instructions, usage examples, and API references.
6- the migrations file should be in sql format.

here is how i like the UX to be:
1- `mg init` - initializes a new migration project in the current directory.
2- `mg create <migration_name>` - creates a new migration script with the given name.
3- `mg apply` - applies all pending migrations to the database.
4- `mg rollback <steps>` - rolls back the last <steps> migrations.
5- `mg status` - shows the current status of migrations, including applied and pending migrations
6- `mg list` - lists all migrations with their statuses (applied/pending).
7- `mg up` - applies the next pending migration.
8- `mg down` - rolls back the last applied migration.
9- `mg head` - shows the current schema version.
10- `mg help` - displays help information for migretti commands.

the database connection details should be looked at in current dir: `mg.yaml` file. please make sure to include error handling and logging for better debugging and user experience.

the project is specialied to be used with psycopg3 for postgresql databases. please make sure to include that in the dependencies.
all migrations should go into migrations/ folder in the project root.
the naming should use ULID for unique migration identifiers (install necessary package for that).
proper audit logging should be implemented to track who applied or rolled back migrations and when.
strict atomicity should be ensured for migration operations to prevent partial application of migrations.


start designing the system, add detailed tickets and summarise what you're going to do before starting the implementation.
the tickets should have all context.  use `issuedb-cli memory` to store imporant general project information for future reference.
