def main():
    print("Hello from Migretti!")

if __name__ == "__main__":
    main()
