import os
import yaml
from typing import Dict, Any

CONFIG_FILENAME = "mg.yaml"

def load_config() -> Dict[str, Any]:
    """
    Loads the configuration from mg.yaml in the current directory.
    """
    if not os.path.exists(CONFIG_FILENAME):
        return {}
    
    with open(CONFIG_FILENAME, "r") as f:
        try:
            return yaml.safe_load(f) or {}
        except yaml.YAMLError as e:
            raise RuntimeError(f"Error parsing {CONFIG_FILENAME}: {e}")
