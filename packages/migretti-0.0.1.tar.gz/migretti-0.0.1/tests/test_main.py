from migretti import __version__
from migretti.__main__ import main

def test_version():
    assert __version__ == "0.0.1"

def test_main(capsys):
    main()
    captured = capsys.readouterr()
    assert "Hello from Migretti!" in captured.out
