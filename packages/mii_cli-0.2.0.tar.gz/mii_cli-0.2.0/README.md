# mii-cli

https://pypi.org/project/mii-cli/

`pip install mii-cli` / `uvx mii-cli --help` / etc.

CLI for extracting .mii files from misc. Wii/Dolphin data dumps, and extracting information from them (name, fav. color, gender, etc.)

Based on https://github.com/PuccamiteTech/PyMii/

