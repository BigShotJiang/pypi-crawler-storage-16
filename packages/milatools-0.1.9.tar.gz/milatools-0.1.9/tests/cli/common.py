from __future__ import annotations

import functools
import inspect
import os
import subprocess
import sys
import typing
from collections.abc import Callable
from logging import getLogger as get_logger
from subprocess import CompletedProcess
from typing import Any

import fabric
import paramiko.ssh_exception
import pytest
from pytest_regressions.file_regression import FileRegressionFixture
from typing_extensions import ParamSpec

from milatools.cli.utils import SSH_CACHE_DIR, SSH_CONFIG_FILE, SSHConfig
from milatools.utils.remote_v2 import RemoteV2, get_controlpath_for

if typing.TYPE_CHECKING:
    from typing_extensions import TypeGuard

logger = get_logger(__name__)

in_github_CI = os.environ.get("GITHUB_ACTIONS") == "true"
"""True if this is being run inside the GitHub CI."""

# See https://docs.github.com/en/actions/learn-github-actions/variables#default-environment-variables
in_self_hosted_github_CI = (
    in_github_CI and os.environ.get("GITHUB_ACTION") == "self_hosted_integration_tests"
)
# in_self_hosted_github_CI = in_github_CI and (
#     "self-hosted" in os.environ.get("RUNNER_LABELS", "")
# )
in_github_cloud_CI = in_github_CI and not in_self_hosted_github_CI

skip_if_on_github_cloud_CI = pytest.mark.skipif(
    in_github_cloud_CI,
    reason="This test shouldn't run on the Github CI.",
)
skip_param_if_on_github_cloud_ci = functools.partial(
    pytest.param, marks=skip_if_on_github_cloud_CI
)


def ssh_to_localhost_is_setup() -> bool:
    SSH_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    control_path = get_controlpath_for(
        "localhost",
        ssh_config_path=SSH_CONFIG_FILE,
        ssh_cache_dir=SSH_CACHE_DIR,
    )
    # Unfortunately needs to be set.
    SSH_CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    if not SSH_CONFIG_FILE.exists():
        SSH_CONFIG_FILE.touch(mode=0o600)
    config = SSHConfig(SSH_CONFIG_FILE)
    if "localhost" not in config.hosts():
        config.add("localhost", StrictHostKeyChecking="no")
    else:
        config.set("localhost", StrictHostKeyChecking="no")
    config.save()

    if sys.platform != "win32":
        try:
            _localhost_remote = RemoteV2("localhost", control_path=control_path)
        except (
            subprocess.CalledProcessError,
            subprocess.TimeoutExpired,
        ) as err:
            logger.error(f"SSH connection to localhost is not setup: {err}")
            return False
        return True

    try:
        # todo: do we need to disable strict host key checking here as well?
        _connection = fabric.Connection("localhost")
        _connection.open()
    except (
        paramiko.ssh_exception.SSHException,
        paramiko.ssh_exception.NoValidConnectionsError,
    ):
        return False
    return True


passwordless_ssh_connection_to_localhost_is_setup = ssh_to_localhost_is_setup()

requires_ssh_to_localhost = pytest.mark.skipif(
    not passwordless_ssh_connection_to_localhost_is_setup,
    reason="Test requires a SSH connection to localhost.",
)


requires_no_s_flag = pytest.mark.skipif(
    "-s" in sys.argv,
    reason="Passing pytest's -s flag makes this test fail.",
)
on_windows = sys.platform == "win32"
in_github_windows_ci = in_github_CI and on_windows

P = ParamSpec("P")


def xfails_on_windows(
    raises: type[Exception] | tuple[type[Exception], ...] = (),
    strict: bool = False,
    reason: str = "TODO: Test doesn't work when running on Windows in the GitHub CI.",
    in_CI_only: bool = False,
):
    if in_github_windows_ci:
        assert sys.platform == "win32", sys.platform

    condition = on_windows
    if in_CI_only:
        condition = condition and in_github_windows_ci
    return pytest.mark.xfail(
        condition,
        reason=reason,
        strict=strict,
        raises=raises,
    )


cmdtest = """===============
Captured stdout
===============
{cout}
===============
Captured stderr
===============
{cerr}
=============
Result stdout
=============
{out}
=============
Result stderr
=============
{err}
"""


def output_tester(
    func: Callable[
        [],
        tuple[str | CompletedProcess[str] | None, str | CompletedProcess[str] | None],
    ],
    capsys: pytest.CaptureFixture,
    file_regression: FileRegressionFixture,
):
    # TODO: Rework this, or add a proper docstring explaining what this does.
    out, err = None, None
    try:
        out, err = func()
        if isinstance(out, CompletedProcess):
            out, err = out.stdout, out.stderr
    finally:
        captured = capsys.readouterr()
        out = out if out else ""
        err = err if err else ""
        file_regression.check(
            cmdtest.format(cout=captured.out, cerr=captured.err, out=out, err=err)
        )


def function_call_string(
    fn: Callable[P, Any],
    *args: P.args,
    **kwargs: P.kwargs,
) -> str:
    """Returns a nice string representation of code that calls `fn(*args, **kwargs)`.

    This is used to show code snippets in the regression files generated by unit tests.
    """

    # Call `repr` on the arguments, except for lambdas, which are shown as their body.
    args_str = [_lambda_to_str(v) if _is_lambda(v) else repr(v) for v in args]
    kwargs_str = {
        k: _lambda_to_str(v) if _is_lambda(v) else repr(v) for k, v in kwargs.items()
    }
    fn_str = fn.__name__

    single_line = (
        fn_str
        + "("
        + ", ".join(args_str)
        + (", " if args_str and kwargs_str else "")
        + ", ".join(f"{k}={v}" for k, v in kwargs_str.items())
        + ")"
    )
    indent = 4 * " "
    multi_line = (
        f"{fn_str}(\n"
        + "\n".join(f"{indent}{arg}," for arg in args_str)
        + ("\n" if args_str and kwargs_str else "")
        + "\n".join(f"{indent}{key}={value}," for key, value in kwargs_str.items())
        + "\n)"
    )

    if len(single_line) < 80:
        return single_line
    return multi_line


def _is_lambda(v: Any) -> TypeGuard[Callable]:
    """Returns whether the value is a lambda expression."""
    return (
        callable(v)
        and isinstance(v, type(lambda _: _))
        and getattr(v, "__name__", None) == "<lambda>"
    )


def _lambda_to_str(lambda_: Callable) -> str:
    """Shows the body of the lambda instead of the default repr."""
    lambda_body = inspect.getsource(lambda_).strip()
    # when putting lambdas in a list, like so:
    # funcs = [
    #    lambda x: x + 1,
    # ]
    # a trailing comma is returned by `inspect.getsource`, which we want to remove.
    return lambda_body.removesuffix(",")
