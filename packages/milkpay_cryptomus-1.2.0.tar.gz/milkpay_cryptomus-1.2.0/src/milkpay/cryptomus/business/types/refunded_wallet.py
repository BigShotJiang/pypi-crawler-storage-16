from .base import CryptomusObject


class RefundedWallet(CryptomusObject):
    uuid: str
    status: str
