from .__meta__ import __version__

__all__ = ["__version__"]
