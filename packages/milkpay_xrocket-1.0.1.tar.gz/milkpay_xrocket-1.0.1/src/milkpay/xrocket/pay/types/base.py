from stollen import StollenObject

from ..client import PayXRocket


class PayXRocketObject(StollenObject[PayXRocket]):
    pass
