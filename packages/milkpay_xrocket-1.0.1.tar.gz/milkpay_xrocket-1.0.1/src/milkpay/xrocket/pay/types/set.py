from .base import PayXRocketObject


class Set(PayXRocketObject):
    pass
