from .base import PayXRocketObject


class UserSubscriptionTransaction(PayXRocketObject):
    pass
