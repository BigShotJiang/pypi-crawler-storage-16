from stollen import StollenObject

from ..client import TradeXRocket


class TradeXRocketObject(StollenObject[TradeXRocket]):
    pass
