from .base import TradeXRocketObject


class CancelOrderResponseDto(TradeXRocketObject):
    success: bool
