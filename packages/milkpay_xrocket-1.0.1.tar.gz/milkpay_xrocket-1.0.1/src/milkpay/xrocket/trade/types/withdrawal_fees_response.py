from .base import TradeXRocketObject


class WithdrawalFeesResponse(TradeXRocketObject):
    success: bool
    """Indicate if request is successful"""
