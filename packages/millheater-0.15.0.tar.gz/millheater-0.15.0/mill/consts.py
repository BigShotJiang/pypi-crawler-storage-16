"""Constants used by pymill"""

__version__ = "0.15.0"
