from django.apps import AppConfig


class DjangoExcelConfig(AppConfig):
    name = "minchin.django.excel"
    default_auto_field = "django.db.models.BigAutoField"
