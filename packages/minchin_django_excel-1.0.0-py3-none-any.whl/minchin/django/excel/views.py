from django.shortcuts import render

# Create your views here.

# Nice JSONField editor
# https://github.com/jmrivas86/django-json-widget

# possible sheet display
# http://django.pyexcel.org/en/latest/
