"""Adapted from https://github.com/huggingface/diffusers/tree/main/src/diffusers/pipelines/ddim/__init__.py."""

from .pipeline_ddim import DDIMPipeline
