"""Adapted from https://github.com/huggingface/diffusers/tree/main/src/diffusers/pipelines/ddpm/__init__.py."""

from .pipeline_ddpm import DDPMPipeline
