class RESPONSE_TYPE:
    __slots__ = ()
    OK = "ok"
    TABLE = "table"
    ERROR = "error"
    COLUMNS_TABLE = "columns_table"  # for queries to information_schema.columns
    EOF = "eof"


RESPONSE_TYPE = RESPONSE_TYPE()
