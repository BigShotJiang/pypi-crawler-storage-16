from flask_restx import Namespace


ns_conf = Namespace('default', description='default ns', path='/')
