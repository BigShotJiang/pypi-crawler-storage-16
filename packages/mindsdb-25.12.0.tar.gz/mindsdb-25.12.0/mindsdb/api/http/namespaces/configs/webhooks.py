from flask_restx import Namespace

ns_conf = Namespace('webhooks', description='API to receive messages from bots')
