# History

Versions follow [Semantic Versioning](https://semver.org).

## 0.2.0 - 2025-12-11

### Changes

- **Project metadata:** Declared build backend `setuptools` into `pyproject.toml`.
- **Project metadata:** Added `MANIFEST.in` for setuptools.
- **Project structure:** According to [PEP 561](https://peps.python.org/pep-0561), an empty `py.typed` is added into the root directory of package.
- **Project structure:** Moved `typings.py` to the root directory of package.
- **This history file:** Corrected the date format in all tier-2 titles.
- Added a SHA-1 hexdigest container type for `sha1`/`hash` fields (un-)structuring. Its definition can be found at: `mcschemes.specials.Sha1Sum`.
- Added some tool functions to calculate a set of rules (iterable of `mcschemes.clientmanifest.nodes.RuleEntry` instances) means allow or disallow
  some operation, such as append an argument or download a library file.

## 0.1.0.post1 - 2025-12-05

### Changes

#### Project metadata

- Added project urls into `pyproject.toml`.
- Added disclaimer in `README.md`

## 0.1.0 - 2025-12-04

The initial release.
