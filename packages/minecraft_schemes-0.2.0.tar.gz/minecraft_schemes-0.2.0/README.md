# minecraft-schemes

Parse Minecraft-relative JSON to structured objects.

**Disclaimer:** Although the project name contains "minecraft", this project is not supported by Mojang Studios or Microsoft.

## Install

```commandline
pip install minecraft-schemes
```

## Usage

To run the following demo code, you need to:

- Copy code to an empty python file
- Download the [version manifest file](https://piston-meta.mojang.com/mc/game/version_manifest_v2.json) and save them to the location near the python
  file, with filename `version_manifest_v2.json`
- Download the [client manifest file for 1.21.10](https://piston-meta.mojang.com/v1/packages/d501809714c64141c1bf1e42f978d0b9e6caa70b/1.21.10.json),
  save them to the location near the python file, with filename `1.21.10.json`
- [Install](#install) both this package and [rich](https://pypi.org/project/rich)

```python
#!/usr/bin/env python3
from shutil import get_terminal_size

from rich.console import Console

import mcschemes

console = Console(markup=False)

# Version manifest
console.print('Version manifest'.center(get_terminal_size()[0], '='))
with open('version_manifest_v2.json') as f:
    version_manifest = mcschemes.load(f, mcschemes.Scheme.VERSION_MANIFEST)
    console.print('Latest release:', version_manifest.latest.release)
    console.print('Latest snapshot:', version_manifest.latest.snapshot)
    console.print('Prettified the first client manifest file info:', end=' ')
    console.print(version_manifest.versions[0])
console.print('=' * get_terminal_size()[0])

console.print()

# Client manifest
console.print('Client manifest of 1.21.10'.center(get_terminal_size()[0], '='))
with open('1.21.10.json') as f:
    client_manifest = mcschemes.load(f, mcschemes.Scheme.CLIENT_MANIFEST)
    console.print('Version ID:', client_manifest.id)
    console.print('Released at:', client_manifest.releaseTime.to_datetime_string())
    console.print('Updated at:', client_manifest.time.to_datetime_string())
    console.print('Main class name:', client_manifest.mainClass)
    console.print('Asset version ID:', client_manifest.assets)
    console.print('Prettified asset index file info:', end=' ')
    console.print(client_manifest.assetIndex)
    console.print('Prettified the first library dependency info:', end=' ')
    console.print(client_manifest.libraries[0])
console.print('=' * get_terminal_size()[0])
```

Outputs in the terminal (the size is 80x24):

```
================================Version manifest================================
Latest release: 1.21.10
Latest snapshot: 1.21.11-pre5
Prettified the first client manifest file info: VersionEntry(
    id='1.21.11-pre5',
    type=<VersionType.SNAPSHOT: 'snapshot'>,
    url='https://piston-meta.mojang.com/v1/packages/0c44a8417875d1b1d5d3056c3a35
ff9717342de0/1.21.11-pre5.json',
    time=DateTime(2025, 12, 3, 13, 26, 59, tzinfo=datetime.timezone.utc),
    releaseTime=DateTime(2025, 12, 3, 13, 14, 25, tzinfo=datetime.timezone.utc),
    sha1=Sha1Sum(hexdigest='0c44a8417875d1b1d5d3056c3a35ff9717342de0'),
    complianceLevel=1
)
================================================================================

===========================Client manifest of 1.21.10===========================
Version ID: 1.21.10
Released at: 2025-10-07 09:17:23
Updated at: 2025-10-07 09:17:23
Main class name: net.minecraft.client.main.Main
Asset version ID: 27
Prettified asset index file info: AssetIndexFileInfo(
    id='27',
    sha1=Sha1Sum(hexdigest='4a667d8cb576e16de8197074c978531c01cd6544'),
    size=507362,
    totalSize=435439577,
    url='https://piston-meta.mojang.com/v1/packages/4a667d8cb576e16de8197074c978
531c01cd6544/27.json'
)
Prettified the first library dependency info: LibraryDependencyInfo(
    name='ca.weblite:java-objc-bridge:1.1',
    artifact=None,
    classifiers={},
    natives={},
    extract=None,
    rules=[
        RuleEntry(
            action=<RuleAction.ALLOW: 'allow'>,
            features={},
            os=RuleOSEntry(name='osx', version=None, arch=None)
        )
    ]
)
================================================================================
```
