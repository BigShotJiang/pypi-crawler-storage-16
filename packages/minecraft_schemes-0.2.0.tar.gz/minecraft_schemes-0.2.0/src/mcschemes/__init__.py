# -*- encoding: utf-8 -*-
__all__ = (
    'Scheme',
    'load',
    'loads',
    'parse',
    '__version__'
)

from mcschemes.tools.parser import Scheme
from mcschemes.tools.parser import load
from mcschemes.tools.parser import loads
from mcschemes.tools.parser import parse

__version__ = '0.2.0'
