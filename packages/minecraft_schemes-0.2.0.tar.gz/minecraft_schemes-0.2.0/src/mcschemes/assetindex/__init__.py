# -*- encoding: utf-8 -*-
__all__ = (
    'AssetIndex',
    'nodes'
)

import attrs

from mcschemes.assetindex import nodes


@attrs.define(kw_only=True, slots=True)
class AssetIndex:
    objects: dict[str, nodes.AssetFileEntry]
    """
    A mapping of asset files.
    The key of the mapping is relative path to asset files under ``.minecraft/assets/``,
    and the value is ``mcschemes.assetindex.nodes.AssetFileEntry`` object.
    """
    virtual: bool | None = None
    map_to_resources: bool | None = None
