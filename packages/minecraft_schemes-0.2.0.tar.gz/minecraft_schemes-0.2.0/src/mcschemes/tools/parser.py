# -*- encoding: utf-8 -*-
__all__ = (
    'Scheme',
    'SchemeLiteral',
    'createConverter',
    'parse',
    'loads',
    'load'
)

import collections.abc
import enum
import json
import re
import threading
from inspect import isclass
from typing import Any
from typing import IO
from typing import Literal
from typing import NamedTuple
from typing import TypeAlias
from typing import TypeVar
from typing import overload

import cattrs.preconf.json
from pendulum import Date
from pendulum import DateTime

from mcschemes.assetindex import AssetIndex
from mcschemes.clientmanifest import ClientManifest
from mcschemes.specials import Sha1Sum
from mcschemes.typings import SupportsCustomStructure
from mcschemes.typings import SupportsCustomUnstructure
from mcschemes.versionmanifest import VersionManifest

_SchemeTargets: TypeAlias = (
        AssetIndex |
        ClientManifest |
        VersionManifest
)


class _SchemeAttribute(NamedTuple):
    target: type[_SchemeTargets]
    buildable: bool


@enum.unique
class Scheme(_SchemeAttribute, enum.Enum):
    VERSION_MANIFEST = (VersionManifest, False)
    CLIENT_MANIFEST = (ClientManifest, False)
    ASSET_INDEX = (AssetIndex, False)


SchemeLiteral: TypeAlias = Literal[
    Scheme.VERSION_MANIFEST,
    Scheme.CLIENT_MANIFEST,
    Scheme.ASSET_INDEX
]

_ConverterT = TypeVar('_ConverterT', bound=cattrs.Converter)


def createConverter(
        *, detailed_validation: bool = True,
        converter_class: type[_ConverterT] = cattrs.Converter,
        regex_flags: int | re.RegexFlag = 0,
) -> _ConverterT:
    if not isclass(converter_class):
        raise TypeError('{0!r} is not a class'.format(converter_class))
    elif not issubclass(converter_class, cattrs.Converter):
        raise TypeError('{0!r} is not subclass of cattrs.Converter'.format(converter_class))

    conv = converter_class(  # noqa: pycharm[PyShadowingNamesInspection]
            unstruct_collection_overrides={  # noqa: pycharm[PyTypeCheckerInspection]
                collections.abc.Set: list,
                collections.Counter: dict
            },
            detailed_validation=detailed_validation,
            omit_if_default=True,
    )
    cattrs.preconf.json.configure_converter(conv)

    # pendulum.Date and pendulum.DateTime (un-)structing support
    conv.register_structure_hook(Date, lambda value, cls_: cls_.fromisoformat(value))
    conv.register_unstructure_hook(Date, lambda value: value.isoformat())
    conv.register_structure_hook(DateTime, lambda value, cls_: cls_.fromisoformat(value))
    conv.register_unstructure_hook(DateTime, lambda value: value.isoformat())

    # Custom (un-)structuring supports
    conv.register_structure_hook(SupportsCustomStructure, lambda value, cls_: cls_.__structure__(conv, value))
    conv.register_unstructure_hook(SupportsCustomUnstructure, lambda value: value.__unstructure__(conv))

    # re.Pattern support
    conv.register_structure_hook(re.Pattern, lambda value, cls_: re.compile(value, flags=regex_flags))
    conv.register_unstructure_hook(re.Pattern, lambda value: value.pattern)

    # mcschemes.specials.Sha1Sum support
    conv.register_structure_hook(Sha1Sum, lambda value, cls_: cls_(value))
    conv.register_unstructure_hook(Sha1Sum, lambda value: value.hexdigest)

    return conv


_local_state = threading.local()


@overload
def parse(
        obj: Any,
        scheme: Literal[Scheme.ASSET_INDEX], /,
        *, converter: cattrs.Converter | None = ...
) -> AssetIndex: ...


@overload
def parse(
        obj: Any,
        scheme: Literal[Scheme.CLIENT_MANIFEST], /,
        *, converter: cattrs.Converter | None = ...
) -> ClientManifest: ...


@overload
def parse(
        obj: Any,
        scheme: Literal[Scheme.VERSION_MANIFEST], /,
        *, converter: cattrs.Converter | None = ...
) -> VersionManifest: ...


def parse(
        obj: Any,
        scheme: Any, /,
        *, converter: cattrs.Converter | None = None
) -> Any:
    scheme = Scheme(scheme)
    cl = scheme.target

    if converter is None:
        if not (hasattr(_local_state, 'converter') and isinstance(_local_state.converter, cattrs.Converter)):
            _local_state.converter = createConverter()
        converter = _local_state.converter
    elif not isinstance(converter, cattrs.Converter):
        raise TypeError(
                '{0!r} must be a cattrs.BaseConverter object, a cattrs.Converter object or None '
                '(got {1!r} that is {2.__qualname__!s} object)'.format('converter', converter, type(converter))
        )

    return converter.structure(obj, cl)


@overload
def loads(
        s: str,
        scheme: Literal[Scheme.ASSET_INDEX], /,
        *, converter: cattrs.Converter | None = ...,
        **json_loads_kwargs: Any
) -> AssetIndex: ...


@overload
def loads(
        s: str,
        scheme: Literal[Scheme.CLIENT_MANIFEST], /,
        *, converter: cattrs.Converter | None = ...,
        **json_loads_kwargs: Any
) -> ClientManifest: ...


@overload
def loads(
        s: str,
        scheme: Literal[Scheme.VERSION_MANIFEST], /,
        *, converter: cattrs.Converter | None = ...,
        **json_loads_kwargs: Any
) -> VersionManifest: ...


def loads(
        s: str,
        scheme: Any, /,
        *, converter: cattrs.Converter | None = None,
        **json_loads_kwargs: Any
) -> Any:
    return parse(json.loads(s, **json_loads_kwargs), scheme, converter=converter)


@overload
def load(
        fp: IO[str],
        scheme: Literal[Scheme.ASSET_INDEX], /,
        *, converter: cattrs.Converter | None = ...,
        **json_load_kwargs: Any
) -> AssetIndex: ...


@overload
def load(
        fp: IO[str],
        scheme: Literal[Scheme.CLIENT_MANIFEST], /,
        *, converter: cattrs.Converter | None = ...,
        **json_load_kwargs: Any
) -> ClientManifest: ...


@overload
def load(
        fp: IO[str],
        scheme: Literal[Scheme.VERSION_MANIFEST], /,
        *, converter: cattrs.Converter | None = ...,
        **json_load_kwargs: Any
) -> VersionManifest: ...


def load(
        fp: IO[str],
        scheme: Any, /,
        *, converter: cattrs.Converter | None = None,
        **json_load_kwargs: Any
) -> Any:
    return parse(json.load(fp, **json_load_kwargs), scheme, converter=converter)
