"""Agent implementations for mini-SWE-agent."""
