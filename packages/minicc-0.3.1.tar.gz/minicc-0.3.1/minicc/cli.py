"""命令行入口（仅启动 TUI）。"""

from minicc.tui.app import main

__all__ = ["main"]

