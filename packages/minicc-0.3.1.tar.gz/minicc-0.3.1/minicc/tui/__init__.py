from .app import MiniCCApp, main

__all__ = ["MiniCCApp", "main"]

