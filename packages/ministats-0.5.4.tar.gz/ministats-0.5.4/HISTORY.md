# History

## 0.2.0 (20243-03-28)

- Imported plotting functions from `plot_helpers.py` (in main namespace for now)

## 0.1.0 (2023-06-29)

- First release on PyPI.
