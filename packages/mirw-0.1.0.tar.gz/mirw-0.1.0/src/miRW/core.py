# src/miRW/core.py

def reverse_sequence(seq: str) -> str:
    """
    示例函数：反转字符串（可理解为反转 miRNA 序列）。
    """
    return seq[::-1]


def gc_content(seq: str) -> float:
    """
    简单计算 GC 含量，返回 0~1 之间的小数。
    """
    seq = seq.upper()
    if not seq:
        return 0.0
    gc = sum(1 for b in seq if b in ("G", "C"))
    return gc / len(seq)
