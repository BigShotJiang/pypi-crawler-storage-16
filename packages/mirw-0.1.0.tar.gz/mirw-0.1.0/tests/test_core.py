# tests/test_core.py

from miRW import reverse_sequence, gc_content


def test_reverse_sequence():
    assert reverse_sequence("AUGC") == "CGUA"


def test_gc_content():
    assert abs(gc_content("GCGC") - 1.0) < 1e-6
    assert abs(gc_content("AAAA") - 0.0) < 1e-6
