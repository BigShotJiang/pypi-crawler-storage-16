# miRW

**miRW: A Multi-Omics Random Walk Framework for Sample-Independent Construction of Personalized Protein Interaction Networks in Cancer**

miRW provides a computational framework for constructing personalized protein interaction networks by integrating multi-omics data and a modulation-adjusted Random Walk with Restart (RWR) strategy. This tool enables sample-specific network refinement and supports downstream analysis for cancer research and other complex diseases.

---

## Installation

Install the latest release via pip:

```bash
pip install miRW
