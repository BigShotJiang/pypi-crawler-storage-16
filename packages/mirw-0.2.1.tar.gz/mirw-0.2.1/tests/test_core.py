# tests/test_core.py

import pandas as pd
from pathlib import Path

from miRW import single_RWSeed_prepare, single_RWSeed_analysis


def test_rwseed_with_real_data():
    data_dir = Path(__file__).parent / "data"

    # load real example data
    links = pd.read_csv(data_dir / "Links.csv", index_col=0)
    expression_data = pd.read_csv(data_dir / "exprSet.csv", index_col=0)

    # optional seed file
    seed_file = data_dir / "CellMarkers.csv"
    if seed_file.exists():
        seed_nodes_df = pd.read_csv(seed_file)
    else:
        # if no seed file, create a minimal one from expression genes
        seed_nodes_df = pd.DataFrame({"symbol": [expression_data.index[0]]})

    # use the first sample column
    sample_id = expression_data.columns[0]

    G, real_w, expr, seeds = single_RWSeed_prepare(
        seed_nodes_df,
        links,
        expression_data
    )

    df = single_RWSeed_analysis(sample_id, G, real_w, expr, seeds)

    assert not df.empty
    assert "miRW-Imp" in df.columns
    assert "miRW-Flow" in df.columns


