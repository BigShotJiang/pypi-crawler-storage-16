import sys
import os
sys.path.append(os.getcwd()+'\misleep')

from misleep.gui.show import show
    
if __name__ == '__main__':

    show()