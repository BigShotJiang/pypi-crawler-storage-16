# -*- coding: UTF-8 -*-
"""
@Project: MiSleep_v2 
@File: __init__.py.py
@Author: Xueqiang Wang
@Date: 2024/3/8
@Description:  
"""

from .about_ui import *
from .main_window_ui import *
from .spec_window_ui import *
