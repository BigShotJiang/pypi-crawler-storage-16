from hdf5storage import loadmat

raw_data = loadmat(r'E:\workplace\EEGProcessing\00_DATA\20240401_0750_24h_baseline\mouse39\mouse39.mat')

