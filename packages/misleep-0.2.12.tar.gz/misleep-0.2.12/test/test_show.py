# -*- coding: UTF-8 -*-
"""
@Project: MiSleep_v2 
@File: test_show.py
@Author: Xueqiang Wang
@Date: 2024/3/8
@Description:  
"""
import unittest

from misleep.gui.show import show


class TestMiData(unittest.TestCase):
    def test_show(self):
        show()
