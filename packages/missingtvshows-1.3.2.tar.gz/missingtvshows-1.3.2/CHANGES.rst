Changelog
=========


1.3.1 (unreleased)
------------------

- tbd


1.3.0 (2024-10-07)
------------------

- Code Refactoring to follow Python best practice.

- Adoption of yaml for logging configuration

- Adoption of types and mypy

- Version upgrades

- Adoption of pyproject.toml

- Compatibility with Python [3.10 - 3.13]


1.2.2 (2018-08-25)
------------------

- Readthedocs integration

- Refactoring to PPIC


1.1.9 (2017-02-21)
-----------------

- Adapted code to the new Kodi MyVideos107 DB Schema.
