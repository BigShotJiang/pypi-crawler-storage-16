adnitc contributors
======================

- Andreas Ruppen <andreas.ruppen@gmail.com>

Find out who contributed::

    $ git shortlog -s -e
