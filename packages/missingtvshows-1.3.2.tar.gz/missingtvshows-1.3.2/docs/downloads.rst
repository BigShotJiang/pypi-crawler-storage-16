Downloads
===========

.. only:: builder_html

Download the application directly from here:

* :download:`missingtvshows_.pex <../dist/missingtvshows_.pex>` For Python > 3.10
