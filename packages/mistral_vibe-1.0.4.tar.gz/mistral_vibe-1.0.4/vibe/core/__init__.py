from __future__ import annotations

__all__ = ["__version__", "run_programmatic"]
__version__ = "1.0.4"

from vibe.core.programmatic import run_programmatic
