from __future__ import annotations

from pathlib import Path

VIBE_ROOT = Path(__file__).parent
