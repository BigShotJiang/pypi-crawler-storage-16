"""Tests for mixtrain SDK and CLI."""

