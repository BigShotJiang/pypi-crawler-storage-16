from mjxml.commons import MJCElement

__all__ = ["Contact"]

class Contact(MJCElement):
    pass