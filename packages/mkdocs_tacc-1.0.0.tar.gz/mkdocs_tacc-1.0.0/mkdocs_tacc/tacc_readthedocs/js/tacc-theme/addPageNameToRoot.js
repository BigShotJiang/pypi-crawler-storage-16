// Set page name using global variable from ReadTheDocs theme
// https://github.com/mkdocs/mkdocs/blob/1.4.2/mkdocs/themes/readthedocs/base.html#L38
document.body.dataset.pageName = window.mkdocs_page_input_path;
