"""Module containing base MkNodes."""
