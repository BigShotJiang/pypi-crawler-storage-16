"""Module containing Navs, subclasses and nav-related helpers like parsing stuff."""
