from .core import DataViz, analyze

__version__ = '0.1.0'
__all__ = ['DataViz', 'analyze']