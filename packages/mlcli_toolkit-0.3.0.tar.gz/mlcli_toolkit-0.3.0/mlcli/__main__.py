"""
Entry point for running mlcli as a module: python -m mlcli
"""

from mlcli.cli import app

if __name__ == "__main__":
    app()
