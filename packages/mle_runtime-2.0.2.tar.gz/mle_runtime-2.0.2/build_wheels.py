#!/usr/bin/env python3
"""
Cross-platform wheel building script for MLE Runtime
Builds wheels with embedded C++ core for all major platforms
"""

import os
import sys
import subprocess
import platform
import shutil
from pathlib import Path
import tempfile
import argparse

class WheelBuilder:
    """Cross-platform wheel builder with embedded C++ core"""
    
    def __init__(self):
        self.project_root = Path(__file__).parent
        self.cpp_core_dir = self.project_root / "cpp_core"
        self.dist_dir = self.project_root / "dist"
        
    def build_all_wheels(self):
        """Build wheels for all supported platforms"""
        print("Building MLE Runtime wheels with mandatory C++ core...")
        
        # Clean previous builds
        self.clean_build_artifacts()
        
        # Build for current platform
        self.build_current_platform()
        
        # If on CI/CD, build for multiple platforms using cibuildwheel
        if os.environ.get('CI') or os.environ.get('GITHUB_ACTIONS'):
            self.build_with_cibuildwheel()
        
        print(f"Wheels built successfully in {self.dist_dir}")
    
    def clean_build_artifacts(self):
        """Clean previous build artifacts"""
        print("Cleaning build artifacts...")
        
        # Remove build directories
        for build_dir in ['build', 'dist', '*.egg-info']:
            if build_dir.endswith('*'):
                import glob
                for path in glob.glob(str(self.project_root / build_dir)):
                    shutil.rmtree(path, ignore_errors=True)
            else:
                build_path = self.project_root / build_dir
                if build_path.exists():
                    shutil.rmtree(build_path, ignore_errors=True)
        
        # Remove compiled extensions
        for ext_pattern in ['**/*.so', '**/*.dll', '**/*.dylib', '**/*.pyd']:
            import glob
            for ext_file in glob.glob(str(self.project_root / ext_pattern), recursive=True):
                if 'cpp_core/build' not in ext_file:  # Don't remove build artifacts
                    os.remove(ext_file)
    
    def build_current_platform(self):
        """Build wheel for current platform"""
        print(f"Building wheel for {platform.system()} {platform.machine()}...")
        
        # Ensure dist directory exists
        self.dist_dir.mkdir(exist_ok=True)
        
        # Build wheel using setup_cpp_mandatory.py
        cmd = [
            sys.executable, "setup_cpp_mandatory.py", 
            "bdist_wheel", 
            "--dist-dir", str(self.dist_dir)
        ]
        
        # Add platform-specific flags
        if platform.system() == "Windows":
            cmd.extend(["--plat-name", "win_amd64"])
        elif platform.system() == "Darwin":
            # Build universal wheel for macOS
            cmd.extend(["--plat-name", "macosx_10_9_universal2"])
        elif platform.system() == "Linux":
            cmd.extend(["--plat-name", "linux_x86_64"])
        
        result = subprocess.run(cmd, cwd=self.project_root, capture_output=True, text=True)
        
        if result.returncode != 0:
            print(f"Build failed: {result.stderr}")
            sys.exit(1)
        
        print("Wheel built successfully!")
    
    def build_with_cibuildwheel(self):
        """Build wheels using cibuildwheel for multiple platforms"""
        print("Building wheels with cibuildwheel...")
        
        # Install cibuildwheel if not available
        try:
            import cibuildwheel
        except ImportError:
            subprocess.run([sys.executable, "-m", "pip", "install", "cibuildwheel"], check=True)
        
        # Set environment variables for cibuildwheel
        env = os.environ.copy()
        env.update({
            'CIBW_BUILD': 'cp38-* cp39-* cp310-* cp311-* cp312-*',
            'CIBW_SKIP': '*-win32 *-manylinux_i686 *-musllinux_*',
            'CIBW_ARCHS_WINDOWS': 'AMD64',
            'CIBW_ARCHS_MACOS': 'x86_64 arm64',
            'CIBW_ARCHS_LINUX': 'x86_64',
            'CIBW_BEFORE_BUILD': 'pip install cmake ninja pybind11',
            'CIBW_BUILD_VERBOSITY': '1',
            'CIBW_TEST_COMMAND': 'python -c "import mle_runtime; print(mle_runtime.get_core_info())"',
        })
        
        # Run cibuildwheel
        cmd = [sys.executable, "-m", "cibuildwheel", "--output-dir", str(self.dist_dir)]
        result = subprocess.run(cmd, cwd=self.project_root, env=env)
        
        if result.returncode != 0:
            print("cibuildwheel build failed")
            sys.exit(1)
    
    def validate_wheels(self):
        """Validate built wheels"""
        print("Validating built wheels...")
        
        wheels = list(self.dist_dir.glob("*.whl"))
        if not wheels:
            print("No wheels found!")
            return False
        
        for wheel in wheels:
            print(f"Validating {wheel.name}...")
            
            # Check wheel contents
            import zipfile
            with zipfile.ZipFile(wheel, 'r') as zf:
                files = zf.namelist()
                
                # Check for C++ extension
                has_extension = any(
                    f.endswith(('.so', '.dll', '.dylib', '.pyd')) and '_mle_core' in f
                    for f in files
                )
                
                if not has_extension:
                    print(f"WARNING: {wheel.name} missing C++ extension!")
                    return False
                
                # Check for required Python files
                required_files = [
                    'mle_runtime/__init__.py',
                    'mle_runtime/mle_runtime.py',
                    'mle_runtime/core_validation.py'
                ]
                
                for req_file in required_files:
                    if not any(f.endswith(req_file) for f in files):
                        print(f"WARNING: {wheel.name} missing {req_file}!")
                        return False
        
        print("All wheels validated successfully!")
        return True
    
    def test_wheels(self):
        """Test built wheels in isolated environments"""
        print("Testing built wheels...")
        
        wheels = list(self.dist_dir.glob("*.whl"))
        
        for wheel in wheels:
            print(f"Testing {wheel.name}...")
            
            # Create temporary virtual environment
            with tempfile.TemporaryDirectory() as temp_dir:
                venv_dir = Path(temp_dir) / "test_env"
                
                # Create virtual environment
                subprocess.run([sys.executable, "-m", "venv", str(venv_dir)], check=True)
                
                # Get python executable in venv
                if platform.system() == "Windows":
                    python_exe = venv_dir / "Scripts" / "python.exe"
                else:
                    python_exe = venv_dir / "bin" / "python"
                
                # Install wheel
                subprocess.run([str(python_exe), "-m", "pip", "install", str(wheel)], check=True)
                
                # Test import and basic functionality
                test_script = '''
import mle_runtime
print("MLE Runtime version:", mle_runtime.__version__)
core_info = mle_runtime.get_core_info()
print("C++ Core available:", core_info["core_available"])
print("Supported devices:", core_info.get("supported_devices", []))
print("Test passed!")
'''
                
                result = subprocess.run(
                    [str(python_exe), "-c", test_script],
                    capture_output=True, text=True
                )
                
                if result.returncode != 0:
                    print(f"Test failed for {wheel.name}: {result.stderr}")
                    return False
                
                print(f"✓ {wheel.name} test passed")
        
        print("All wheel tests passed!")
        return True

def main():
    parser = argparse.ArgumentParser(description="Build MLE Runtime wheels with C++ core")
    parser.add_argument("--validate", action="store_true", help="Validate built wheels")
    parser.add_argument("--test", action="store_true", help="Test built wheels")
    parser.add_argument("--clean", action="store_true", help="Clean build artifacts only")
    
    args = parser.parse_args()
    
    builder = WheelBuilder()
    
    if args.clean:
        builder.clean_build_artifacts()
        return
    
    if args.validate:
        success = builder.validate_wheels()
        sys.exit(0 if success else 1)
    
    if args.test:
        success = builder.test_wheels()
        sys.exit(0 if success else 1)
    
    # Build wheels
    builder.build_all_wheels()
    
    # Validate and test
    if builder.validate_wheels() and builder.test_wheels():
        print("✓ All wheels built, validated, and tested successfully!")
    else:
        print("✗ Wheel validation or testing failed!")
        sys.exit(1)

if __name__ == "__main__":
    main()