#pragma once

#include <string>
#include <vector>
#include <map>
#include <exception>
#include <cstdint>

namespace mle {

// Utility functions
std::string get_version();
std::map<std::string, std::string> get_build_info();
std::vector<std::string> get_supported_devices();
std::vector<std::string> get_supported_operators();

void set_num_threads(int num_threads);
int get_num_threads();

void clear_cache();
std::map<std::string, size_t> get_memory_usage();

// Compression functions
std::vector<uint8_t> compress_data(const uint8_t* data, size_t size, uint32_t compression_type);
std::vector<uint8_t> decompress_data(const uint8_t* data, size_t size, uint32_t compression_type, size_t uncompressed_size);

// Constants
extern const std::string VERSION;
extern const std::string BUILD_DATE;
extern const bool CUDA_AVAILABLE;
extern const bool COMPRESSION_AVAILABLE;
extern const bool CRYPTO_AVAILABLE;

// Exception classes
class MLEException : public std::exception {
public:
    explicit MLEException(const std::string& message) : message_(message) {}
    const char* what() const noexcept override { return message_.c_str(); }
private:
    std::string message_;
};

class LoaderException : public MLEException {
public:
    explicit LoaderException(const std::string& message) : MLEException("Loader Error: " + message) {}
};

class EngineException : public MLEException {
public:
    explicit EngineException(const std::string& message) : MLEException("Engine Error: " + message) {}
};

} // namespace mle