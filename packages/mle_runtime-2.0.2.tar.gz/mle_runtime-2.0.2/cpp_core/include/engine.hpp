#pragma once

#include <vector>
#include <string>
#include <memory>
#include <unordered_map>
#include <cstdint>

namespace mle {

enum class Device {
    CPU = 0,
    CUDA = 1,
    AUTO = 2
};

enum class OperatorType : uint32_t {
    LINEAR = 1,
    RELU = 2,
    GELU = 3,
    SOFTMAX = 4,
    LAYERNORM = 5,
    MATMUL = 6,
    ADD = 7,
    MUL = 8,
    CONV2D = 9,
    MAXPOOL2D = 10,
    BATCHNORM = 11,
    DROPOUT = 12,
    EMBEDDING = 13,
    ATTENTION = 14,
    DECISION_TREE = 26,
    TREE_ENSEMBLE = 27,
    GRADIENT_BOOSTING = 28,
    SVM = 29,
    NAIVE_BAYES = 30,
    KNN = 31,
    CLUSTERING = 32,
    DBSCAN = 33,
    DECOMPOSITION = 34
};

struct Tensor {
    std::vector<float> data;
    std::vector<size_t> shape;
    
    Tensor() = default;
    Tensor(const std::vector<float>& data, const std::vector<size_t>& shape);
    
    size_t size() const;
    size_t ndim() const;
    float* data_ptr() { return data.data(); }
    const float* data_ptr() const { return data.data(); }
};

struct Operator {
    OperatorType type;
    std::unordered_map<std::string, Tensor> weights;
    std::unordered_map<std::string, float> params;
    std::unordered_map<std::string, std::string> attributes;
    
    virtual ~Operator() = default;
    virtual Tensor forward(const Tensor& input) = 0;
};

class ModelGraph {
public:
    void add_operator(std::unique_ptr<Operator> op);
    std::vector<Tensor> execute(const std::vector<Tensor>& inputs);
    size_t get_operator_count() const { return operators_.size(); }
    
private:
    std::vector<std::unique_ptr<Operator>> operators_;
};

class Engine {
public:
    explicit Engine(Device device);
    ~Engine();
    
    void load_model(const std::string& path);
    std::vector<std::vector<float>> run(const std::vector<std::vector<float>>& inputs);
    
    Device get_device() const;
    bool is_model_loaded() const;
    std::string get_model_info() const;
    
    struct BenchmarkResult {
        double mean_time_ms;
        double std_time_ms;
        double min_time_ms;
        double max_time_ms;
    };
    
    BenchmarkResult benchmark(const std::vector<std::vector<float>>& inputs, int num_runs = 100);

private:
    Device device_;
    bool model_loaded_;
    std::string model_path_;
    std::unique_ptr<ModelGraph> graph_;
    std::unordered_map<std::string, std::string> metadata_;
    
    void parse_mle_file(const std::string& path);
    void parse_graph_and_weights(const std::vector<uint8_t>& graph_data, 
                                const std::vector<uint8_t>& weights_data,
                                const std::unordered_map<std::string, std::string>& metadata);
    std::vector<Tensor> convert_inputs(const std::vector<std::vector<float>>& inputs);
    std::vector<std::vector<float>> convert_outputs(const std::vector<Tensor>& outputs);
};

} // namespace mle