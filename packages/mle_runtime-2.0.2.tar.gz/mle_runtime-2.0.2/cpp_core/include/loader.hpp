#pragma once

#include <string>
#include <map>
#include <vector>
#include <cstdint>
#include <fstream>

namespace mle {

// MLE File Format Constants
constexpr uint32_t MLE_MAGIC = 0x00454C4D;
constexpr uint32_t MLE_VERSION_2 = 2;

// Feature flags
constexpr uint32_t FEATURE_COMPRESSION = 0x00000001;
constexpr uint32_t FEATURE_ENCRYPTION = 0x00000002;
constexpr uint32_t FEATURE_SIGNING = 0x00000004;
constexpr uint32_t FEATURE_STREAMING = 0x00000008;
constexpr uint32_t FEATURE_QUANTIZATION = 0x00000010;

// Compression types
enum class CompressionType : uint32_t {
    NONE = 0,
    LZ4 = 1,
    ZSTD = 2,
    BROTLI = 3,
    QUANTIZE_INT8 = 4,
    QUANTIZE_FP16 = 5
};

struct MLEHeader {
    uint32_t magic;
    uint32_t version;
    uint32_t feature_flags;
    uint32_t header_size;
    uint64_t metadata_offset;
    uint64_t metadata_size;
    uint64_t graph_offset;
    uint64_t graph_size;
    uint64_t weights_offset;
    uint64_t weights_size;
    uint64_t signature_offset;
    uint64_t signature_size;
    uint32_t metadata_checksum;
    uint32_t graph_checksum;
    uint32_t weights_checksum;
    uint32_t header_checksum;
};

class ModelLoader {
public:
    static bool validate_file(const std::string& path);
    static std::map<std::string, std::string> get_file_info(const std::string& path);
    static std::map<std::string, std::string> inspect_model(const std::string& path);
    
    static MLEHeader read_header(std::ifstream& file);
    static std::string read_metadata(std::ifstream& file, const MLEHeader& header);
    static std::vector<uint8_t> read_graph(std::ifstream& file, const MLEHeader& header);
    static std::vector<uint8_t> read_weights(std::ifstream& file, const MLEHeader& header);
    
    static uint32_t compute_crc32(const uint8_t* data, size_t size);
    static bool verify_checksum(const uint8_t* data, size_t size, uint32_t expected_crc);

private:
    static bool is_valid_magic(uint32_t magic);
    static bool is_supported_version(uint32_t version);
};

} // namespace mle