/**
 * Python bindings for MLE Runtime C++ Core
 * This file creates the mandatory Python interface to the C++ engine
 */

#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
#include <pybind11/stl.h>
#include "include/engine.hpp"
#include "include/loader.hpp"
#include "include/device.hpp"

namespace py = pybind11;

PYBIND11_MODULE(_mle_core, m) {
    m.doc() = "MLE Runtime C++ Core - High-performance ML inference engine v2.0.2";
    
    // Device enumeration
    py::enum_<mle::Device>(m, "Device")
        .value("CPU", mle::Device::CPU)
        .value("CUDA", mle::Device::CUDA)
        .value("AUTO", mle::Device::AUTO)
        .export_values();
    
    // Engine benchmark result
    py::class_<mle::Engine::BenchmarkResult>(m, "BenchmarkResult")
        .def_readonly("mean_time_ms", &mle::Engine::BenchmarkResult::mean_time_ms)
        .def_readonly("std_time_ms", &mle::Engine::BenchmarkResult::std_time_ms)
        .def_readonly("min_time_ms", &mle::Engine::BenchmarkResult::min_time_ms)
        .def_readonly("max_time_ms", &mle::Engine::BenchmarkResult::max_time_ms);
    
    // Engine class
    py::class_<mle::Engine>(m, "Engine")
        .def(py::init<mle::Device>(), "Initialize engine with device")
        .def("load_model", &mle::Engine::load_model, 
             "Load MLE model from file path",
             py::arg("path"))
        .def("run", &mle::Engine::run,
             "Run inference on input arrays",
             py::arg("inputs"))
        .def("get_device", &mle::Engine::get_device,
             "Get current device")
        .def("is_model_loaded", &mle::Engine::is_model_loaded,
             "Check if model is loaded")
        .def("get_model_info", &mle::Engine::get_model_info,
             "Get model information")
        .def("benchmark", &mle::Engine::benchmark,
             "Benchmark model performance",
             py::arg("inputs"), py::arg("num_runs") = 100);
    
    // Loader utilities
    py::class_<mle::ModelLoader>(m, "ModelLoader")
        .def_static("validate_file", &mle::ModelLoader::validate_file,
                   "Validate MLE file format",
                   py::arg("path"))
        .def_static("get_file_info", &mle::ModelLoader::get_file_info,
                   "Get file information",
                   py::arg("path"))
        .def_static("inspect_model", &mle::ModelLoader::inspect_model,
                   "Inspect model details",
                   py::arg("path"));
    
    // Compression utilities
    m.def("compress_data", [](py::bytes data, uint32_t compression_type) {
        std::string input = data;
        auto result = mle::compress_data(
            reinterpret_cast<const uint8_t*>(input.data()), 
            input.size(), 
            compression_type
        );
        return py::bytes(reinterpret_cast<const char*>(result.data()), result.size());
    }, "Compress data using specified algorithm",
       py::arg("data"), py::arg("compression_type"));
    
    m.def("decompress_data", [](py::bytes data, uint32_t compression_type, size_t uncompressed_size) {
        std::string input = data;
        auto result = mle::decompress_data(
            reinterpret_cast<const uint8_t*>(input.data()), 
            input.size(), 
            compression_type,
            uncompressed_size
        );
        return py::bytes(reinterpret_cast<const char*>(result.data()), result.size());
    }, "Decompress data using specified algorithm",
       py::arg("data"), py::arg("compression_type"), py::arg("uncompressed_size"));
    
    // Version information
    m.def("get_version", &mle::get_version, "Get C++ core version");
    m.def("get_build_info", &mle::get_build_info, "Get build information");
    m.def("get_supported_devices", &mle::get_supported_devices, "Get supported devices");
    m.def("get_supported_operators", &mle::get_supported_operators, "Get supported operators");
    
    // Performance utilities
    m.def("set_num_threads", &mle::set_num_threads, 
          "Set number of threads for CPU operations",
          py::arg("num_threads"));
    m.def("get_num_threads", &mle::get_num_threads, 
          "Get current number of threads");
    
    // Memory management
    m.def("clear_cache", &mle::clear_cache, "Clear internal caches");
    m.def("get_memory_usage", &mle::get_memory_usage, "Get memory usage statistics");
    
    // Error handling
    py::register_exception<mle::MLEException>(m, "MLEException");
    py::register_exception<mle::LoaderException>(m, "LoaderException");
    py::register_exception<mle::EngineException>(m, "EngineException");
    
    // Constants
    m.attr("VERSION") = mle::VERSION;
    m.attr("BUILD_DATE") = mle::BUILD_DATE;
    m.attr("CUDA_AVAILABLE") = mle::CUDA_AVAILABLE;
    m.attr("COMPRESSION_AVAILABLE") = mle::COMPRESSION_AVAILABLE;
    m.attr("CRYPTO_AVAILABLE") = mle::CRYPTO_AVAILABLE;
}