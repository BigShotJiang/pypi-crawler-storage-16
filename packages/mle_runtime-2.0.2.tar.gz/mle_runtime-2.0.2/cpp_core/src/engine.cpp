#include "engine.hpp"
#include "loader.hpp"
#include "device.hpp"
#include <chrono>
#include <algorithm>
#include <numeric>
#include <cmath>
#include <fstream>
#include <sstream>
#include <memory>
#include <random>

namespace mle {

// Tensor implementation
Tensor::Tensor(const std::vector<float>& data, const std::vector<size_t>& shape) 
    : data(data), shape(shape) {}

size_t Tensor::size() const {
    size_t result = 1;
    for (size_t dim : shape) {
        result *= dim;
    }
    return result;
}

size_t Tensor::ndim() const {
    return shape.size();
}

// Operator implementations
class LinearOperator : public Operator {
public:
    Tensor forward(const Tensor& input) override {
        const auto& weight = weights.at("weight");
        const auto& bias = weights.at("bias");
        
        size_t input_size = weight.shape[1];
        size_t output_size = weight.shape[0];
        size_t batch_size = input.shape[0];
        
        Tensor output({}, {batch_size, output_size});
        output.data.resize(batch_size * output_size);
        
        // Matrix multiplication: output = input * weight^T + bias
        for (size_t b = 0; b < batch_size; ++b) {
            for (size_t o = 0; o < output_size; ++o) {
                float sum = bias.data[o];
                for (size_t i = 0; i < input_size; ++i) {
                    sum += input.data[b * input_size + i] * weight.data[o * input_size + i];
                }
                output.data[b * output_size + o] = sum;
            }
        }
        
        return output;
    }
};

class ReLUOperator : public Operator {
public:
    Tensor forward(const Tensor& input) override {
        Tensor output = input;
        for (auto& val : output.data) {
            val = std::max(0.0f, val);
        }
        return output;
    }
};

class SoftmaxOperator : public Operator {
public:
    Tensor forward(const Tensor& input) override {
        Tensor output = input;
        size_t batch_size = input.shape[0];
        size_t feature_size = input.shape[1];
        
        for (size_t b = 0; b < batch_size; ++b) {
            size_t batch_offset = b * feature_size;
            
            // Find max for numerical stability
            float max_val = output.data[batch_offset];
            for (size_t i = 1; i < feature_size; ++i) {
                max_val = std::max(max_val, output.data[batch_offset + i]);
            }
            
            // Compute exp and sum
            float sum = 0.0f;
            for (size_t i = 0; i < feature_size; ++i) {
                output.data[batch_offset + i] = std::exp(output.data[batch_offset + i] - max_val);
                sum += output.data[batch_offset + i];
            }
            
            // Normalize
            for (size_t i = 0; i < feature_size; ++i) {
                output.data[batch_offset + i] /= sum;
            }
        }
        
        return output;
    }
};

// ModelGraph implementation
void ModelGraph::add_operator(std::unique_ptr<Operator> op) {
    operators_.push_back(std::move(op));
}

std::vector<Tensor> ModelGraph::execute(const std::vector<Tensor>& inputs) {
    if (inputs.empty() || operators_.empty()) {
        return {};
    }
    
    Tensor current = inputs[0];
    
    for (const auto& op : operators_) {
        current = op->forward(current);
    }
    
    return {current};
}

// Engine implementation
Engine::Engine(Device device) : device_(device), model_loaded_(false) {
    graph_ = std::make_unique<ModelGraph>();
}

Engine::~Engine() = default;

void Engine::load_model(const std::string& path) {
    if (!ModelLoader::validate_file(path)) {
        throw EngineException("Invalid MLE file: " + path);
    }
    
    try {
        parse_mle_file(path);
        model_path_ = path;
        model_loaded_ = true;
    } catch (const std::exception& e) {
        throw EngineException("Failed to load model: " + std::string(e.what()));
    }
}

void Engine::parse_mle_file(const std::string& path) {
    std::ifstream file(path, std::ios::binary);
    if (!file.is_open()) {
        throw LoaderException("Cannot open file: " + path);
    }
    
    // Read header
    MLEHeader header = ModelLoader::read_header(file);
    
    // Read metadata
    std::string metadata_json = ModelLoader::read_metadata(file, header);
    
    // Parse metadata JSON (simple parsing for now)
    std::unordered_map<std::string, std::string> metadata_map;
    // For now, just store the raw JSON string
    metadata_map["raw"] = metadata_json;
    
    // Read graph definition
    std::vector<uint8_t> graph_data = ModelLoader::read_graph(file, header);
    
    // Read weights
    std::vector<uint8_t> weights_data = ModelLoader::read_weights(file, header);
    
    // Parse graph and create operators
    parse_graph_and_weights(graph_data, weights_data, metadata_map);
}

void Engine::parse_graph_and_weights(const std::vector<uint8_t>& graph_data, 
                                    const std::vector<uint8_t>& weights_data,
                                    const std::unordered_map<std::string, std::string>& metadata) {
    // Simple example: create a basic neural network
    // In a real implementation, this would parse the actual graph format
    
    // Create Linear layer
    auto linear_op = std::make_unique<LinearOperator>();
    linear_op->type = OperatorType::LINEAR;
    
    // Example weights (would be loaded from weights_data)
    size_t input_size = 10;
    size_t output_size = 3;
    
    Tensor weight({}, {output_size, input_size});
    weight.data.resize(output_size * input_size);
    // Initialize with small random values
    for (size_t i = 0; i < weight.data.size(); ++i) {
        weight.data[i] = (static_cast<float>(rand()) / RAND_MAX - 0.5f) * 0.1f;
    }
    
    Tensor bias({}, {output_size});
    bias.data.resize(output_size);
    std::fill(bias.data.begin(), bias.data.end(), 0.0f);
    
    linear_op->weights["weight"] = weight;
    linear_op->weights["bias"] = bias;
    
    graph_->add_operator(std::move(linear_op));
    
    // Add ReLU activation
    auto relu_op = std::make_unique<ReLUOperator>();
    relu_op->type = OperatorType::RELU;
    graph_->add_operator(std::move(relu_op));
    
    // Add Softmax output
    auto softmax_op = std::make_unique<SoftmaxOperator>();
    softmax_op->type = OperatorType::SOFTMAX;
    graph_->add_operator(std::move(softmax_op));
}

std::vector<std::vector<float>> Engine::run(const std::vector<std::vector<float>>& inputs) {
    if (!model_loaded_) {
        throw EngineException("No model loaded");
    }
    
    if (inputs.empty()) {
        return {};
    }
    
    // Convert inputs to tensors
    std::vector<Tensor> tensor_inputs = convert_inputs(inputs);
    
    // Execute graph
    std::vector<Tensor> tensor_outputs = graph_->execute(tensor_inputs);
    
    // Convert outputs back to vectors
    return convert_outputs(tensor_outputs);
}

std::vector<Tensor> Engine::convert_inputs(const std::vector<std::vector<float>>& inputs) {
    std::vector<Tensor> tensors;
    
    if (!inputs.empty()) {
        size_t batch_size = inputs.size();
        size_t feature_size = inputs[0].size();
        
        std::vector<float> data;
        data.reserve(batch_size * feature_size);
        
        for (const auto& input : inputs) {
            data.insert(data.end(), input.begin(), input.end());
        }
        
        tensors.emplace_back(data, std::vector<size_t>{batch_size, feature_size});
    }
    
    return tensors;
}

std::vector<std::vector<float>> Engine::convert_outputs(const std::vector<Tensor>& outputs) {
    std::vector<std::vector<float>> result;
    
    if (!outputs.empty()) {
        const auto& output = outputs[0];
        size_t batch_size = output.shape[0];
        size_t feature_size = output.shape[1];
        
        for (size_t b = 0; b < batch_size; ++b) {
            std::vector<float> batch_output;
            batch_output.reserve(feature_size);
            for (size_t f = 0; f < feature_size; ++f) {
                batch_output.push_back(output.data[b * feature_size + f]);
            }
            result.push_back(batch_output);
        }
    }
    
    return result;
}

Device Engine::get_device() const {
    return device_;
}

bool Engine::is_model_loaded() const {
    return model_loaded_;
}

std::string Engine::get_model_info() const {
    if (!model_loaded_) {
        return "No model loaded";
    }
    
    std::string info = "Model: " + model_path_ + "\n";
    std::string device_str = (device_ == Device::CPU ? "CPU" : 
                             device_ == Device::CUDA ? "CUDA" : "AUTO");
    info += "Device: " + device_str + "\n";
    info += "Operators: " + std::to_string(graph_->get_operator_count());
    
    return info;
}

Engine::BenchmarkResult Engine::benchmark(const std::vector<std::vector<float>>& inputs, int num_runs) {
    if (!model_loaded_) {
        throw EngineException("No model loaded for benchmarking");
    }
    
    std::vector<double> times;
    times.reserve(num_runs);
    
    // Warmup
    for (int i = 0; i < 5; ++i) {
        run(inputs);
    }
    
    // Benchmark
    for (int i = 0; i < num_runs; ++i) {
        auto start = std::chrono::high_resolution_clock::now();
        run(inputs);
        auto end = std::chrono::high_resolution_clock::now();
        
        auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
        times.push_back(duration.count() / 1000.0); // Convert to milliseconds
    }
    
    // Calculate statistics
    double mean = std::accumulate(times.begin(), times.end(), 0.0) / times.size();
    
    double variance = 0.0;
    for (double time : times) {
        variance += (time - mean) * (time - mean);
    }
    variance /= times.size();
    double std_dev = std::sqrt(variance);
    
    auto min_time = *std::min_element(times.begin(), times.end());
    auto max_time = *std::max_element(times.begin(), times.end());
    
    return {mean, std_dev, min_time, max_time};
}

} // namespace mle