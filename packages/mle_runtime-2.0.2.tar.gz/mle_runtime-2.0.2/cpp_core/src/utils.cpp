#include "device.hpp"
#include <thread>
#include <cstring>
#include <numeric>

#ifdef ENABLE_COMPRESSION
#include <zlib.h>
#endif

namespace mle {

// Constants
const std::string VERSION = "2.0.2";
const std::string BUILD_DATE = __DATE__ " " __TIME__;

#ifdef ENABLE_CUDA
const bool CUDA_AVAILABLE = true;
#else
const bool CUDA_AVAILABLE = false;
#endif

#ifdef ENABLE_COMPRESSION
const bool COMPRESSION_AVAILABLE = true;
#else
const bool COMPRESSION_AVAILABLE = false;
#endif

#ifdef ENABLE_CRYPTO
const bool CRYPTO_AVAILABLE = true;
#else
const bool CRYPTO_AVAILABLE = false;
#endif

// Global state
static int g_num_threads = std::thread::hardware_concurrency();

std::string get_version() {
    return VERSION;
}

std::map<std::string, std::string> get_build_info() {
    std::map<std::string, std::string> info;
    info["version"] = VERSION;
    info["build_date"] = BUILD_DATE;
    
    info["compiler"] = 
#ifdef _MSC_VER
        "MSVC " + std::to_string(_MSC_VER);
#elif defined(__GNUC__)
        "GCC " + std::to_string(__GNUC__) + "." + std::to_string(__GNUC_MINOR__);
#elif defined(__clang__)
        "Clang " + std::to_string(__clang_major__) + "." + std::to_string(__clang_minor__);
#else
        "Unknown";
#endif

    info["platform"] = 
#ifdef _WIN32
        "Windows";
#elif defined(__linux__)
        "Linux";
#elif defined(__APPLE__)
        "macOS";
#else
        "Unknown";
#endif

    info["architecture"] = 
#ifdef _M_X64
        "x64";
#elif defined(_M_IX86)
        "x86";
#elif defined(__x86_64__)
        "x86_64";
#elif defined(__i386__)
        "i386";
#elif defined(__aarch64__)
        "arm64";
#elif defined(__arm__)
        "arm";
#else
        "unknown";
#endif

    info["cuda_available"] = CUDA_AVAILABLE ? "true" : "false";
    info["compression_available"] = COMPRESSION_AVAILABLE ? "true" : "false";
    info["crypto_available"] = CRYPTO_AVAILABLE ? "true" : "false";
    
    return info;
}

std::vector<std::string> get_supported_devices() {
    std::vector<std::string> devices = {"CPU"};
    if (CUDA_AVAILABLE) {
        devices.push_back("CUDA");
    }
    devices.push_back("AUTO");
    return devices;
}

std::vector<std::string> get_supported_operators() {
    return {
        // Neural network operators
        "Linear", "ReLU", "GELU", "Softmax", "LayerNorm", "MatMul", "Add", "Mul",
        "Conv2D", "MaxPool2D", "BatchNorm", "Dropout", "Embedding", "Attention",
        
        // Machine learning algorithms
        "DecisionTree", "TreeEnsemble", "GradientBoosting", "SVM", "NaiveBayes",
        "KNN", "Clustering", "DBSCAN", "Decomposition",
        
        // Activation functions
        "Sigmoid", "Tanh", "LeakyReLU", "ELU", "Swish",
        
        // Normalization
        "GroupNorm", "InstanceNorm", "LocalResponseNorm",
        
        // Pooling
        "AvgPool2D", "GlobalAvgPool", "GlobalMaxPool", "AdaptiveAvgPool",
        
        // Convolution variants
        "Conv1D", "Conv3D", "DepthwiseConv2D", "TransposeConv2D",
        
        // Recurrent
        "LSTM", "GRU", "RNN",
        
        // Utility
        "Reshape", "Transpose", "Concat", "Split", "Slice", "Gather", "Scatter"
    };
}

void set_num_threads(int num_threads) {
    if (num_threads > 0 && num_threads <= static_cast<int>(std::thread::hardware_concurrency() * 2)) {
        g_num_threads = num_threads;
    }
}

int get_num_threads() {
    return g_num_threads;
}

void clear_cache() {
    // Clear any internal caches (model cache, operator cache, etc.)
    // In a real implementation, this would clear various caches
}

std::map<std::string, size_t> get_memory_usage() {
    std::map<std::string, size_t> usage;
    
    // In a real implementation, these would track actual memory usage
    usage["total_allocated"] = 0;
    usage["peak_usage"] = 0;
    usage["current_usage"] = 0;
    usage["model_cache"] = 0;
    usage["operator_cache"] = 0;
    usage["tensor_pool"] = 0;
    
    return usage;
}

std::vector<uint8_t> compress_data(const uint8_t* data, size_t size, uint32_t compression_type) {
#ifdef ENABLE_COMPRESSION
    if (compression_type == 2) { // ZSTD fallback to zlib
        uLongf compressed_size = compressBound(static_cast<uLong>(size));
        std::vector<uint8_t> compressed(compressed_size);
        
        int result = compress(compressed.data(), &compressed_size, data, static_cast<uLong>(size));
        if (result != Z_OK) {
            throw MLEException("Compression failed with error: " + std::to_string(result));
        }
        
        compressed.resize(compressed_size);
        return compressed;
    }
#endif
    
    // No compression or unsupported type
    return std::vector<uint8_t>(data, data + size);
}

std::vector<uint8_t> decompress_data(const uint8_t* data, size_t size, uint32_t compression_type, size_t uncompressed_size) {
#ifdef ENABLE_COMPRESSION
    if (compression_type == 2) { // ZSTD fallback to zlib
        std::vector<uint8_t> decompressed(uncompressed_size);
        uLongf dest_len = static_cast<uLongf>(uncompressed_size);
        
        int result = uncompress(decompressed.data(), &dest_len, data, static_cast<uLong>(size));
        if (result != Z_OK) {
            throw MLEException("Decompression failed with error: " + std::to_string(result));
        }
        
        decompressed.resize(dest_len);
        return decompressed;
    }
#endif
    
    // No compression or unsupported type
    return std::vector<uint8_t>(data, data + size);
}

} // namespace mle