#!/usr/bin/env python3
"""
MLE Runtime - Mandatory C++ Core Setup
This setup script ensures C++ core is built and embedded for all platforms
"""

import os
import sys
import subprocess
import platform
from pathlib import Path
from setuptools import setup, find_packages, Extension
from setuptools.command.build_ext import build_ext
from setuptools.command.install import install
from setuptools.command.develop import develop
import shutil
import tempfile

class CMakeExtension(Extension):
    """Extension that uses CMake to build"""
    
    def __init__(self, name, sourcedir=''):
        Extension.__init__(self, name, sources=[])
        self.sourcedir = os.path.abspath(sourcedir)

class CMakeBuild(build_ext):
    """Custom build command that uses CMake"""
    
    def build_extension(self, ext):
        if not isinstance(ext, CMakeExtension):
            return super().build_extension(ext)
        
        extdir = os.path.abspath(os.path.dirname(self.get_ext_fullpath(ext.name)))
        
        # Required for auto-detection of auxiliary "native" libs
        if not extdir.endswith(os.path.sep):
            extdir += os.path.sep
        
        debug = int(os.environ.get('REL_WITH_DEB_INFO', 0)) or self.debug
        cfg = 'Debug' if debug else 'Release'
        
        # CMake lets you override the generator - we check this
        cmake_generator = os.environ.get('CMAKE_GENERATOR', '')
        
        # Set Python_EXECUTABLE instead if you use PYBIND11_FINDPYTHON
        cmake_args = [
            f'-DCMAKE_LIBRARY_OUTPUT_DIRECTORY={extdir}',
            f'-DPYTHON_EXECUTABLE={sys.executable}',
            f'-DCMAKE_BUILD_TYPE={cfg}',
            '-DENABLE_COMPRESSION=ON',
            '-DENABLE_CRYPTO=ON',
            '-DBUILD_TESTS=OFF',
        ]
        
        # Detect CUDA availability
        if self._has_cuda():
            cmake_args.append('-DENABLE_CUDA=ON')
            print("CUDA detected - enabling GPU acceleration")
        
        build_args = []
        
        if self.compiler.compiler_type != "msvc":
            # Using Ninja-build since it a) is available as a wheel and b)
            # multithreads automatically. MSVC would require all variables be
            # exported for Ninja to pick it up, which is a little tricky to do.
            # Users can override the generator with CMAKE_GENERATOR in CMake
            # 3.15+.
            if not cmake_generator or cmake_generator == "Ninja":
                try:
                    import ninja  # noqa: F401
                    ninja_executable_path = os.path.join(ninja.BIN_DIR, "ninja")
                    cmake_args += [
                        "-GNinja",
                        f"-DCMAKE_MAKE_PROGRAM:FILEPATH={ninja_executable_path}",
                    ]
                except ImportError:
                    pass
        else:
            # Single config generators are handled "normally"
            single_config = any(x in cmake_generator for x in {"NMake", "Ninja"})
            
            # CMake allows an arch-in-generator style for backward compatibility
            contains_arch = any(x in cmake_generator for x in {"ARM", "Win64"})
            
            # Specify the arch if using MSVC generator, but only if it doesn't
            # contain a backward-compatibility arch spec already in the
            # generator name.
            if not single_config and not contains_arch:
                cmake_args += ["-A", "x64" if platform.machine().endswith("64") else "Win32"]
            
            # Multi-config generators have a different way to specify configs
            if not single_config:
                cmake_args += [f"-DCMAKE_LIBRARY_OUTPUT_DIRECTORY_{cfg.upper()}={extdir}"]
                build_args += ["--config", cfg]
        
        if sys.platform.startswith("darwin"):
            # Cross-compile support for macOS - respect ARCHFLAGS if set
            archs = re.findall(r"-arch (\S+)", os.environ.get("ARCHFLAGS", ""))
            if archs:
                cmake_args += ["-DCMAKE_OSX_ARCHITECTURES={}".format(";".join(archs))]
        
        # Set CMAKE_BUILD_PARALLEL_LEVEL to control the parallel build level
        # across all generators.
        if "CMAKE_BUILD_PARALLEL_LEVEL" not in os.environ:
            # self.parallel is a Python 3 only way to set parallel jobs by hand
            # using -j in the build_ext call, not supported by pip or PyPA-build.
            if hasattr(self, "parallel") and self.parallel:
                # CMake 3.12+ only.
                build_args += [f"-j{self.parallel}"]
        
        build_temp = Path(self.build_temp) / ext.name
        if not build_temp.exists():
            build_temp.mkdir(parents=True)
        
        # Build the C++ core
        subprocess.run(
            ["cmake", ext.sourcedir] + cmake_args, cwd=build_temp, check=True
        )
        subprocess.run(
            ["cmake", "--build", ".", "--target", "mle_core"] + build_args, cwd=build_temp, check=True
        )
        
        # Copy the built library to the package
        self._copy_built_library(build_temp, extdir, ext.name)
    
    def _has_cuda(self):
        """Check if CUDA is available"""
        try:
            result = subprocess.run(['nvcc', '--version'], 
                                  capture_output=True, text=True, timeout=10)
            return result.returncode == 0
        except (subprocess.TimeoutExpired, FileNotFoundError):
            return False
    
    def _copy_built_library(self, build_temp, extdir, ext_name):
        """Copy the built library to the correct location"""
        system = platform.system().lower()
        
        if system == "windows":
            lib_pattern = "*.dll"
            lib_name = "mle_core.dll"
        elif system == "darwin":
            lib_pattern = "*.dylib"
            lib_name = "libmle_core.dylib"
        else:  # Linux and others
            lib_pattern = "*.so*"
            lib_name = "libmle_core.so"
        
        # Find the built library
        import glob
        built_libs = glob.glob(str(build_temp / lib_pattern))
        
        if not built_libs:
            raise RuntimeError(f"Could not find built library matching {lib_pattern} in {build_temp}")
        
        # Copy to package directory
        dest_path = Path(extdir) / "mle_runtime" / lib_name
        dest_path.parent.mkdir(parents=True, exist_ok=True)
        
        shutil.copy2(built_libs[0], dest_path)
        print(f"Copied {built_libs[0]} -> {dest_path}")

class MandatoryCppInstall(install):
    """Custom install that validates C++ core availability"""
    
    def run(self):
        super().run()
        self._validate_cpp_core()
    
    def _validate_cpp_core(self):
        """Validate that C++ core is properly installed"""
        try:
            # Try to import and initialize the C++ core
            import mle_runtime._mle_core as core
            engine = core.Engine(core.Device.CPU)
            print("✓ C++ core validation successful")
        except ImportError as e:
            raise RuntimeError(
                f"CRITICAL: C++ core not available after installation: {e}\n"
                "This package requires the C++ core for operation. "
                "Please ensure your system has the necessary build tools."
            )

class MandatoryCppDevelop(develop):
    """Custom develop that validates C++ core availability"""
    
    def run(self):
        super().run()
        self._validate_cpp_core()
    
    def _validate_cpp_core(self):
        """Validate that C++ core is properly installed"""
        try:
            import mle_runtime._mle_core as core
            engine = core.Engine(core.Device.CPU)
            print("✓ C++ core validation successful")
        except ImportError as e:
            raise RuntimeError(
                f"CRITICAL: C++ core not available in development mode: {e}\n"
                "Please build the C++ core first using: python setup_cpp_mandatory.py build_ext --inplace"
            )

def get_version():
    """Get version from __init__.py"""
    init_file = Path(__file__).parent / "mle_runtime" / "__init__.py"
    with open(init_file, 'r', encoding='utf-8') as f:
        content = f.read()
        import re
        version_match = re.search(r'^__version__ = [\'"]([^\'"]*)[\'"]', content, re.M)
        if version_match:
            return version_match.group(1)
    raise RuntimeError("Unable to find version string")

def get_long_description():
    """Get long description from README"""
    readme_file = Path(__file__).parent / "readme.md"
    if readme_file.exists():
        with open(readme_file, 'r', encoding='utf-8') as f:
            return f.read()
    return "High-performance machine learning inference engine with mandatory C++ core"

def get_requirements():
    """Get requirements from requirements.txt"""
    req_file = Path(__file__).parent / "requirements.txt"
    if req_file.exists():
        with open(req_file, 'r', encoding='utf-8') as f:
            return [line.strip() for line in f if line.strip() and not line.startswith('#')]
    return ['numpy>=1.19.0']

# Platform-specific requirements
def get_platform_requirements():
    """Get platform-specific build requirements"""
    requirements = []
    
    # Always require numpy for building
    requirements.extend(['numpy>=1.19.0', 'setuptools>=45'])
    
    # Add ninja for faster builds if available
    try:
        import ninja
        requirements.append('ninja')
    except ImportError:
        pass
    
    return requirements

setup(
    name="mle-runtime",
    version=get_version(),
    author="MLE Runtime Team",
    author_email="contact@mle-runtime.org",
    description="High-performance ML inference engine with mandatory C++ core (10-100x faster than joblib)",
    long_description=get_long_description(),
    long_description_content_type="text/markdown",
    url="https://github.com/mle-runtime/mle-runtime",
    project_urls={
        "Bug Tracker": "https://github.com/mle-runtime/mle-runtime/issues",
        "Documentation": "https://mle-runtime.readthedocs.io/",
        "Source Code": "https://github.com/mle-runtime/mle-runtime",
    },
    packages=find_packages(exclude=["tests*", "examples*", "docs*", "cpp_core*"]),
    ext_modules=[CMakeExtension("mle_runtime._mle_core", "cpp_core")],
    cmdclass={
        "build_ext": CMakeBuild,
        "install": MandatoryCppInstall,
        "develop": MandatoryCppDevelop,
    },
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: C++",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: System :: Archiving :: Compression",
    ],
    python_requires=">=3.8",
    install_requires=get_requirements(),
    setup_requires=get_platform_requirements(),
    extras_require={
        "dev": [
            "pytest>=6.0",
            "pytest-cov>=2.0",
            "black>=21.0",
            "flake8>=3.8",
            "mypy>=0.800",
            "cmake>=3.22",
            "ninja",
        ],
        "sklearn": ["scikit-learn>=1.0.0"],
        "pytorch": ["torch>=1.9.0"],
        "tensorflow": ["tensorflow>=2.6.0"],
        "xgboost": ["xgboost>=1.5.0"],
        "lightgbm": ["lightgbm>=3.2.0"],
        "catboost": ["catboost>=1.0.0"],
        "all": [
            "scikit-learn>=1.0.0",
            "torch>=1.9.0", 
            "tensorflow>=2.6.0",
            "xgboost>=1.5.0",
            "lightgbm>=3.2.0",
            "catboost>=1.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "mle-runtime=mle_runtime.cli:main",
            "mle-export=mle_runtime.exporters.cli:export_main",
            "mle-inspect=mle_runtime.cli:inspect_main",
            "mle-benchmark=mle_runtime.cli:benchmark_main",
        ],
    },
    include_package_data=True,
    package_data={
        "mle_runtime": ["*.so", "*.dll", "*.dylib", "_mle_core.*"],
    },
    zip_safe=False,  # Required for C extensions
    keywords=[
        "machine learning", "inference", "runtime", "performance", 
        "joblib", "scikit-learn", "pytorch", "tensorflow", "compression",
        "serialization", "model deployment", "edge computing", "cpp", "native"
    ],
)