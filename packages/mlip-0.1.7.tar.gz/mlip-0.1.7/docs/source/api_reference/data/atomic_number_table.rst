.. _atomic_number_table:

.. module:: mlip.data.helpers.atomic_number_table

Atomic Number Table
===================

.. autoclass:: AtomicNumberTable

    .. automethod:: __init__

    .. automethod:: index_to_z

    .. automethod:: z_to_index

    .. automethod:: z_to_index_map
