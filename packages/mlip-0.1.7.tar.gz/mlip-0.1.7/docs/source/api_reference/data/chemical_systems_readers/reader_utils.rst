.. _reader_utils:

.. module:: mlip.data.chemical_systems_readers.utils

Reader Utilities
================

This module contains utility functions for
:py:class:`ChemicalSystemsReader <mlip.data.chemical_systems_readers.ChemicalSystemsReader>` objects.


.. autofunction:: filter_systems_with_unseen_atoms_and_assign_atomic_species
