.. _graph_dataset:

.. module:: mlip.data.helpers.graph_dataset

Graph Dataset
=============

.. autoclass:: GraphDataset

    .. automethod:: __init__

    .. automethod:: __iter__

    .. automethod:: __len__

    .. automethod:: subset
