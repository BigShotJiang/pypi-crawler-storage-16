.. _graph_dataset_builder:

.. module:: mlip.data.graph_dataset_builder

Graph Dataset Builder
=====================

.. autoclass:: GraphDatasetBuilder

    .. automethod:: __init__

    .. automethod:: prepare_datasets

    .. automethod:: get_splits

    .. autoproperty:: dataset_info
