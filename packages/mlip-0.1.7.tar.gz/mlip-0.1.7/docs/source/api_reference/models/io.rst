.. _model_io:

Model I/O
=========

.. module:: mlip.models.model_io

    .. autofunction:: save_model_to_zip

    .. autofunction:: load_model_from_zip

.. module:: mlip.models.params_loading

    .. autofunction:: load_parameters_from_checkpoint
