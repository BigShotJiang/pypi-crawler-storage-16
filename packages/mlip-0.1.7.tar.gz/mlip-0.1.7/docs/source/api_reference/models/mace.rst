.. _mace:

MACE
====

.. module:: mlip.models.mace.models

    .. autoclass:: Mace

        .. automethod:: __call__

.. module:: mlip.models.mace.config

    .. autoclass:: MaceConfig
