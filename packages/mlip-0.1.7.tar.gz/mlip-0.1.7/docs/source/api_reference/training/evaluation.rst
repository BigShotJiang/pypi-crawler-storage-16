.. _evaluation:

.. module:: mlip.training.evaluation

Model evaluation
================

.. autofunction:: make_evaluation_step

.. autofunction:: run_evaluation
