
Areas for future developement.

### Future versions

- Development of active learning workflow.

### Version 1

**codes**

- Add supported MD and QM codes.

**similarity**

- Add additional descriptors to access similarity of configurations. e.g. 
    - SOAP
    - 
- Optimize with numba


**hpc_submission**

- Add supported hpcs.
- Support for cunstructing a custom script header
- generalise writing hpc scripts for SLURM, i.e. include repeated headers

**DataCollection**

- add save_and_remove for write_MD_submission_scripts

**append_to_database**

- options to append data of different boundry conditions.






