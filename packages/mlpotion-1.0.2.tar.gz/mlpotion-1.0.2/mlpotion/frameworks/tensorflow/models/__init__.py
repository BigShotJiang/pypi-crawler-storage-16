"""TensorFlow model components."""

from mlpotion.frameworks.tensorflow.models.inspection import ModelInspector

__all__ = [
    "ModelInspector",
]
