"""
This module provides common functionality for implementing rule learning algorithms.
"""
