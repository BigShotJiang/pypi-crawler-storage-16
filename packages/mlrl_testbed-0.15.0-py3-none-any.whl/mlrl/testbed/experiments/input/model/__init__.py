"""
Author Michael Rapp (michael.rapp.ml@gmail.com)

Provides classes that allow to read models from different sources.
"""
from mlrl.testbed.experiments.input.model.reader import ModelReader
