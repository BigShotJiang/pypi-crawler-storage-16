"""
Author Michael Rapp (michael.rapp.ml@gmail.com)

Provides classes that allow to write meta-data to different sinks.
"""
from mlrl.testbed.experiments.output.meta_data.writer import MetaDataWriter
