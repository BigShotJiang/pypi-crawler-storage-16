"""
Author Michael Rapp (michael.rapp.ml@gmail.com)

Provides classes that allow to read input data from SVM (light) files.
"""
from mlrl.testbed_sklearn.experiments.input.sources.source_svm import SvmFileSource
