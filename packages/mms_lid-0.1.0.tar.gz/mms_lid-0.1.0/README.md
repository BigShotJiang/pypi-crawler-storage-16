# mms-LID

MMS-LID는 Meta의 MMS-1B 모델을 기반으로 한 강력한 다국어 식별(LID) 도구입니다.

## 설치 방법 (Installation)

```bash
pip install mms-lid