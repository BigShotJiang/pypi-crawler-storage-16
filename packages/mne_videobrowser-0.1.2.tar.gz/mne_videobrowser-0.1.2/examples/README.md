# Examples for using mne-videobrowser

Examples `video_sample_meg_sync.py` and `multiple_meg_video_sync.py` use a sample dataset from MNE Python and a fake video file.
Other examples require you to have your own MEG/EEG data and video and/or audio files in a correct format.
