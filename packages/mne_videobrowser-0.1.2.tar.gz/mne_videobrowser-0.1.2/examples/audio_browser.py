"""Demo script for the AudioBrowser.

Running this requires an audio file in Helsinki videoMEG project format.
Adjust the file path as needed.
"""

# %%
import logging
import sys

from qtpy.QtWidgets import QApplication

from mne_videobrowser import AudioFileHelsinkiVideoMEG
from mne_videobrowser.browsers import AudioBrowser
from mne_videobrowser.timestamp_aligner import TimestampAligner

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s [%(levelname)s] %(message)s",
)

# Replace this with the path to your audio file
audio_path = "/u/69/taivait1/unix/video_meg_testing/2025-10-14--11-08-49_audio_00.aud"

# "/u/69/taivait1/unix/video_meg_testing/2025-07-11_MEG2MEG_test/2025-07-11--18-18-41_audio_00.aud"

# "/u/69/taivait1/unix/video_meg_testing/2025-10-14--11-08-49_audio_00.aud"

audio = AudioFileHelsinkiVideoMEG(audio_path)

# %%

audio.print_stats()

# %%

dur_min = audio.duration / 60  # duration in minutes
print("Audio duration (min):", dur_min)

# %%

timestamps = audio.get_audio_timestamps_ms()

# %%
import numpy as np

timestamps2 = np.linspace(timestamps[0], timestamps[-1], 60 * 60 * 1000)

# %%
print(len(timestamps), len(timestamps2))

# Compute the size of audio timestamp array

size = timestamps.nbytes / (1024**2)  # size in MB
print(f"Audio timestamps size: {size:.2f} MB")  

# %%
"""
aligner = TimestampAligner(
    timestamps_a=timestamps2,
    timestamps_b=timestamps,
    name_a="Generated 1kHz",
    name_b="Audio file",
)
"""
# %%

app = QApplication([])
window = AudioBrowser(audio)
window.resize(1000, 600)
window.show()
sys.exit(app.exec_())

# %%
