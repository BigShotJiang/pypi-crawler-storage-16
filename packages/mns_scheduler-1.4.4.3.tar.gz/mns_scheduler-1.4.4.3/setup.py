from setuptools import setup, find_packages

setup(
    name='mns_scheduler',
    version='1.4.4.3',
    packages=find_packages(),
    install_requires=[],  # 如果有依赖项，可以在这里列出
)
