﻿moabb.analysis.meta_analysis.collapse_session_scores
====================================================

.. currentmodule:: moabb.analysis.meta_analysis

.. autofunction:: collapse_session_scores

.. include:: moabb.analysis.meta_analysis.collapse_session_scores.examples

.. raw:: html

    <div style='clear:both'></div>