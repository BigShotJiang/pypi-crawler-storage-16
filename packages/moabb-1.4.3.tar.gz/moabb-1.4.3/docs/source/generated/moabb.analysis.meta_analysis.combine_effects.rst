﻿moabb.analysis.meta_analysis.combine_effects
============================================

.. currentmodule:: moabb.analysis.meta_analysis

.. autofunction:: combine_effects

.. include:: moabb.analysis.meta_analysis.combine_effects.examples

.. raw:: html

    <div style='clear:both'></div>