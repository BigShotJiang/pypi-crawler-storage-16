﻿moabb.analysis.plotting.paired_plot
===================================

.. currentmodule:: moabb.analysis.plotting

.. autofunction:: paired_plot

.. include:: moabb.analysis.plotting.paired_plot.examples

.. raw:: html

    <div style='clear:both'></div>