﻿moabb.benchmark
===============

.. currentmodule:: moabb

.. autofunction:: benchmark

.. include:: moabb.benchmark.examples

.. raw:: html

    <div style='clear:both'></div>