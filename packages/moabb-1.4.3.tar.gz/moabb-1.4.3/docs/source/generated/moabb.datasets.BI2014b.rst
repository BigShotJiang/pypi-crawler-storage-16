﻿moabb.datasets.BI2014b
======================

.. currentmodule:: moabb.datasets

.. autoclass:: BI2014b
   :special-members: __contains__,__getitem__,__iter__,__len__,__add__,__sub__,__mul__,__div__,__neg__,__hash__
   :members:

.. include:: moabb.datasets.BI2014b.examples

.. raw:: html

    <div style='clear:both'></div>