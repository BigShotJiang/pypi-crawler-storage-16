﻿moabb.datasets.EPFLP300
=======================

.. currentmodule:: moabb.datasets

.. autoclass:: EPFLP300
   :special-members: __contains__,__getitem__,__iter__,__len__,__add__,__sub__,__mul__,__div__,__neg__,__hash__
   :members:

.. include:: moabb.datasets.EPFLP300.examples

.. raw:: html

    <div style='clear:both'></div>