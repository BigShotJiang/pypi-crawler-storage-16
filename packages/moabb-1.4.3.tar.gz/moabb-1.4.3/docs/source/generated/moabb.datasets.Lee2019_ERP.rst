﻿moabb.datasets.Lee2019_ERP
==========================

.. currentmodule:: moabb.datasets

.. autoclass:: Lee2019_ERP
   :special-members: __contains__,__getitem__,__iter__,__len__,__add__,__sub__,__mul__,__div__,__neg__,__hash__
   :members:

.. include:: moabb.datasets.Lee2019_ERP.examples

.. raw:: html

    <div style='clear:both'></div>