﻿moabb.datasets.Lee2019_MI
=========================

.. currentmodule:: moabb.datasets

.. autoclass:: Lee2019_MI
   :special-members: __contains__,__getitem__,__iter__,__len__,__add__,__sub__,__mul__,__div__,__neg__,__hash__
   :members:

.. include:: moabb.datasets.Lee2019_MI.examples

.. raw:: html

    <div style='clear:both'></div>