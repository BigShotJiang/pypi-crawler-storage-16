﻿moabb.datasets.Shin2017B
========================

.. currentmodule:: moabb.datasets

.. autoclass:: Shin2017B
   :special-members: __contains__,__getitem__,__iter__,__len__,__add__,__sub__,__mul__,__div__,__neg__,__hash__
   :members:

.. include:: moabb.datasets.Shin2017B.examples

.. raw:: html

    <div style='clear:both'></div>