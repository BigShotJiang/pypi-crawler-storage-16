﻿moabb.datasets.base.CacheConfig
===============================

.. currentmodule:: moabb.datasets.base

.. autoclass:: CacheConfig
   :special-members: __contains__,__getitem__,__iter__,__len__,__add__,__sub__,__mul__,__div__,__neg__,__hash__
   :members:

.. include:: moabb.datasets.base.CacheConfig.examples

.. raw:: html

    <div style='clear:both'></div>