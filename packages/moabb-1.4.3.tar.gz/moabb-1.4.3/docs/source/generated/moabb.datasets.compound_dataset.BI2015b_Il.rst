﻿moabb.datasets.compound_dataset.BI2015b_Il
==========================================

.. currentmodule:: moabb.datasets.compound_dataset

.. autoclass:: BI2015b_Il
   :special-members: __contains__,__getitem__,__iter__,__len__,__add__,__sub__,__mul__,__div__,__neg__,__hash__
   :members:

.. include:: moabb.datasets.compound_dataset.BI2015b_Il.examples

.. raw:: html

    <div style='clear:both'></div>