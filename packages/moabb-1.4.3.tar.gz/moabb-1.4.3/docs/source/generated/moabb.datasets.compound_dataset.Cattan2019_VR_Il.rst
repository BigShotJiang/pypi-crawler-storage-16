﻿moabb.datasets.compound_dataset.Cattan2019_VR_Il
================================================

.. currentmodule:: moabb.datasets.compound_dataset

.. autoclass:: Cattan2019_VR_Il
   :special-members: __contains__,__getitem__,__iter__,__len__,__add__,__sub__,__mul__,__div__,__neg__,__hash__
   :members:

.. include:: moabb.datasets.compound_dataset.Cattan2019_VR_Il.examples

.. raw:: html

    <div style='clear:both'></div>