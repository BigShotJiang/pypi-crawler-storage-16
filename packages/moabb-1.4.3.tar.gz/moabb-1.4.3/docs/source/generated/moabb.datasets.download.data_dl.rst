﻿moabb.datasets.download.data_dl
===============================

.. currentmodule:: moabb.datasets.download

.. autofunction:: data_dl

.. include:: moabb.datasets.download.data_dl.examples

.. raw:: html

    <div style='clear:both'></div>