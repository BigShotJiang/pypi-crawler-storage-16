﻿moabb.datasets.download.data_path
=================================

.. currentmodule:: moabb.datasets.download

.. autofunction:: data_path

.. include:: moabb.datasets.download.data_path.examples

.. raw:: html

    <div style='clear:both'></div>