﻿moabb.datasets.download.fs_get_file_id
======================================

.. currentmodule:: moabb.datasets.download

.. autofunction:: fs_get_file_id

.. include:: moabb.datasets.download.fs_get_file_id.examples

.. raw:: html

    <div style='clear:both'></div>