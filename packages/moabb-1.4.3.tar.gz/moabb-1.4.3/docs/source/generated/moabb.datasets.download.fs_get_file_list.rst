﻿moabb.datasets.download.fs_get_file_list
========================================

.. currentmodule:: moabb.datasets.download

.. autofunction:: fs_get_file_list

.. include:: moabb.datasets.download.fs_get_file_list.examples

.. raw:: html

    <div style='clear:both'></div>