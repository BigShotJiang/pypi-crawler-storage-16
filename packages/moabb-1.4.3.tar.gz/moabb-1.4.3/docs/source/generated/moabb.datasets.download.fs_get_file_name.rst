﻿moabb.datasets.download.fs_get_file_name
========================================

.. currentmodule:: moabb.datasets.download

.. autofunction:: fs_get_file_name

.. include:: moabb.datasets.download.fs_get_file_name.examples

.. raw:: html

    <div style='clear:both'></div>