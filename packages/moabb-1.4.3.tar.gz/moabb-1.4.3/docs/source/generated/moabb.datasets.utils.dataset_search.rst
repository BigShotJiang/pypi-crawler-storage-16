﻿moabb.datasets.utils.dataset_search
===================================

.. currentmodule:: moabb.datasets.utils

.. autofunction:: dataset_search

.. include:: moabb.datasets.utils.dataset_search.examples

.. raw:: html

    <div style='clear:both'></div>