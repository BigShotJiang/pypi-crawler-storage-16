﻿moabb.datasets.utils.find_intersecting_channels
===============================================

.. currentmodule:: moabb.datasets.utils

.. autofunction:: find_intersecting_channels

.. include:: moabb.datasets.utils.find_intersecting_channels.examples

.. raw:: html

    <div style='clear:both'></div>