﻿moabb.datasets.utils.plot_datasets_grid
=======================================

.. currentmodule:: moabb.datasets.utils

.. autofunction:: plot_datasets_grid

.. include:: moabb.datasets.utils.plot_datasets_grid.examples

.. raw:: html

    <div style='clear:both'></div>