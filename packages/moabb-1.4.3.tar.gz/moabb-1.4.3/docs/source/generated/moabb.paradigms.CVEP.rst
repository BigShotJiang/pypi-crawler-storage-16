﻿moabb.paradigms.CVEP
====================

.. currentmodule:: moabb.paradigms

.. autoclass:: CVEP
   :special-members: __contains__,__getitem__,__iter__,__len__,__add__,__sub__,__mul__,__div__,__neg__,__hash__
   :members:

.. include:: moabb.paradigms.CVEP.examples

.. raw:: html

    <div style='clear:both'></div>