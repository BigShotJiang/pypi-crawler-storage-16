﻿moabb.paradigms.LeftRightImagery
================================

.. currentmodule:: moabb.paradigms

.. autoclass:: LeftRightImagery
   :special-members: __contains__,__getitem__,__iter__,__len__,__add__,__sub__,__mul__,__div__,__neg__,__hash__
   :members:

.. include:: moabb.paradigms.LeftRightImagery.examples

.. raw:: html

    <div style='clear:both'></div>