﻿moabb.paradigms.p300.BaseP300
=============================

.. currentmodule:: moabb.paradigms.p300

.. autoclass:: BaseP300
   :special-members: __contains__,__getitem__,__iter__,__len__,__add__,__sub__,__mul__,__div__,__neg__,__hash__
   :members:

.. include:: moabb.paradigms.p300.BaseP300.examples

.. raw:: html

    <div style='clear:both'></div>