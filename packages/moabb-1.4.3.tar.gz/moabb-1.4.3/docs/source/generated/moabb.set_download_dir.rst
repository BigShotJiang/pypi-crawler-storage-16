﻿moabb.set_download_dir
======================

.. currentmodule:: moabb

.. autofunction:: set_download_dir

.. include:: moabb.set_download_dir.examples

.. raw:: html

    <div style='clear:both'></div>