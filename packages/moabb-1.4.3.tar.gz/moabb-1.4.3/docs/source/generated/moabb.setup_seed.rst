﻿moabb.setup_seed
================

.. currentmodule:: moabb

.. autofunction:: setup_seed

.. include:: moabb.setup_seed.examples

.. raw:: html

    <div style='clear:both'></div>