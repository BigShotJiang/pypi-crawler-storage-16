import logging
import os
import os.path as osp
from pathlib import Path

import mne
import pandas as pd
import yaml
from mne.utils import _open_lock

from moabb import paradigms as moabb_paradigms
from moabb.analysis import analyze
from moabb.datasets.base import BaseDataset
from moabb.datasets.fake import FakeDataset
from moabb.evaluations import (
    CrossSessionEvaluation,
    CrossSubjectEvaluation,
    WithinSessionEvaluation,
)
from moabb.pipelines.utils import (
    generate_paradigms,
    generate_param_grid,
    parse_pipelines_from_directory,
)


try:
    from codecarbon import EmissionsTracker  # noqa

    _carbonfootprint = True
except ImportError:
    _carbonfootprint = False

log = logging.getLogger(__name__)


def benchmark(  # noqa: C901
    pipelines="./pipelines/",
    evaluations=None,
    paradigms=None,
    results="./results/",
    overwrite=False,
    output="./benchmark/",
    n_jobs=-1,
    plot=False,
    contexts=None,
    include_datasets=None,
    exclude_datasets=None,
    n_splits=None,
    cache_config=None,
    optuna=False,
):
    """Run benchmarks for selected pipelines and datasets.

    Load from saved pipeline configurations to determine associated paradigms. It is
    possible to include or exclude specific datasets and to choose the type of
    evaluation.

    If particular paradigms are mentioned through parameter paradigms, only the pipelines corresponding to those paradigms
    will be run. If no paradigms are mentioned, all pipelines will be run.

    To define the include_datasets or exclude_dataset, you could start from the full dataset list,
    using for example the following code::

        # Choose your paradigm
        p = moabb.paradigms.SSVEP()
        # Get the class names
        print(p.datasets)
        # Get the dataset code
        print([d.code for d in p.datasets])

    Parameters
    ----------
    pipelines : str or list of dict
       Folder containing the pipelines to evaluate or path to a single pipeline file,
       or a list of scikit-learn pipelines with format:

       .. code-block:: python

           pipelines = [
               {
                   "paradigms": ["SomeParadigm"],
                   "pipeline": make_pipeline(Transformer1(), Transformer2(), Classifier()),
                   "name": "PipelineName",
               },
               {
                   "paradigms": ["AnotherParadigm"],
                   "pipeline": make_pipeline(TransformerA(), ClassifierB()),
                   "name": "AnotherPipelineName",
               },
           ]

       Each entry is a dictionary with 3 keys: "name", "pipeline", "paradigms".

    evaluations : list of str
        If to restrict the types of evaluations to be run. By default, all 3 base types are run.
        Can be a list of these elements ["WithinSession", "CrossSession", "CrossSubject"].

    paradigms : list of str
        To restrict the paradigms on which evaluations should be run.
        Can be a list of these elements ['LeftRightImagery', 'MotorImagery', 'FilterBankSSVEP', 'SSVEP',
        'FilterBankMotorImagery'].

    results : str
        Folder to store the results.

    overwrite : bool
        Force evaluation of cached pipelines.

    output : str
        Folder to store the analysis results.

    n_jobs : int
        Number of threads to use for running parallel jobs.

    n_splits : int or None, default=None
        This parameter only works for CrossSubjectEvaluation. It defines the
        number of splits to be done in the cross-validation. If None,
        the number of splits is equal to the number of subjects in the dataset.

    plot : bool
        Plot results after computing.

    contexts : str
        File path to context.yml file that describes context parameters.
        If none, assumes all defaults. Must contain an entry for all
        paradigms described in the pipelines.

    include_datasets : list of str
        Dataset codes or Dataset objects to include in the benchmark run.
        By default, all suitable datasets are included. If both include_datasets
        and exclude_datasets are specified, raise an error.

    exclude_datasets : list of str
        Dataset codes or Dataset objects to exclude from the benchmark run.

    optuna : bool
        Enable Optuna for the hyperparameter search.

    Returns
    -------
    eval_results: DataFrame
        Results of benchmark for all considered paradigms

    Notes
    -----
    .. versionadded:: 1.1.1
        Includes the possibility to use Optuna for hyperparameter search.

    .. versionadded:: 0.5.0
        Create the function to run the benchmark
    """
    # set logs
    if evaluations is None:
        evaluations = ["WithinSession", "CrossSession", "CrossSubject"]

    eval_type = {
        "WithinSession": WithinSessionEvaluation,
        "CrossSession": CrossSessionEvaluation,
        "CrossSubject": CrossSubjectEvaluation,
    }

    mne.set_log_level(False)
    # logging.basicConfig(level=logging.WARNING)

    output = Path(output)
    if not osp.isdir(output):
        os.makedirs(output)

    if isinstance(pipelines, str):
        pipeline_configs = parse_pipelines_from_directory(pipelines)
    elif isinstance(pipelines, list):
        pipeline_configs = pipelines
    else:
        raise TypeError(f"Unsupported pipelines type {type(pipelines)}.")

    context_params = {}
    if contexts is not None:
        with _open_lock(contexts, "r") as cfile:
            context_params = yaml.load(cfile.read(), Loader=yaml.FullLoader)

    prdgms_from_pipelines = generate_paradigms(pipeline_configs, context_params, log)

    if paradigms and not set(paradigms).issubset(prdgms_from_pipelines):
        raise Exception(
            "The paradigms you provided are not correctly filtering the paradigms from the pipelines that are used for processing."
        )

    # Filter requested benchmark paradigms vs available in provided pipelines
    if paradigms is not None:
        prdgms_from_pipelines = {p: prdgms_from_pipelines[p] for p in paradigms}

    param_grid = generate_param_grid(pipeline_configs, context_params, log)

    print(f"The paradigms being run are {prdgms_from_pipelines.keys()}")

    if len(context_params) == 0:
        for paradigm in prdgms_from_pipelines:
            context_params[paradigm] = {}

    # Looping over the evaluations to be done
    df_eval = []
    for evaluation in evaluations:
        eval_results = dict()

        processed_paradigms = 0
        for paradigm in prdgms_from_pipelines:
            # get the context
            log.debug(f"{paradigm}: {context_params[paradigm]}")
            p = _get_paradigm_instance(paradigm, context_params)
            # List of dataset class instances, handles FakeDatasets as well
            datasets = (
                p.datasets
                + [ds for ds in (include_datasets or []) if isinstance(ds, FakeDataset)]
                if any(isinstance(ds, FakeDataset) for ds in (include_datasets or []))
                else p.datasets
            )
            compatible_datasets = _inc_exc_datasets(
                datasets, paradigm, include_datasets, exclude_datasets
            )

            if not compatible_datasets:
                print(f"WARNING: Paradigm {paradigm} skipped.")
                continue

            print(
                f"Datasets considered for {paradigm} paradigm {[dt.code for dt in compatible_datasets]}"
            )

            ppl_with_epochs, ppl_with_array = {}, {}
            for pn, pv in prdgms_from_pipelines[paradigm].items():
                ppl_with_array[pn] = pv

            if len(ppl_with_epochs) > 0:
                # Keras pipelines require return_epochs=True
                context = eval_type[evaluation](
                    paradigm=p,
                    datasets=compatible_datasets,
                    random_state=42,
                    hdf5_path=results,
                    n_jobs=n_jobs,
                    overwrite=overwrite,
                    return_epochs=True,
                    n_splits=n_splits,
                    cache_config=cache_config,
                    optuna=optuna,
                )
                paradigm_results = context.process(
                    pipelines=ppl_with_epochs, param_grid=param_grid
                )
                paradigm_results["paradigm"] = f"{paradigm}"
                paradigm_results["evaluation"] = f"{evaluation}"
                eval_results[f"{paradigm}"] = paradigm_results
                df_eval.append(paradigm_results)

            # Other pipelines, that use numpy arrays
            if len(ppl_with_array) > 0:
                context = eval_type[evaluation](
                    paradigm=p,
                    datasets=compatible_datasets,
                    random_state=42,
                    hdf5_path=results,
                    n_jobs=n_jobs,
                    overwrite=overwrite,
                    n_splits=n_splits,
                    cache_config=cache_config,
                    optuna=optuna,
                )
                paradigm_results = context.process(
                    pipelines=ppl_with_array, param_grid=param_grid
                )
                paradigm_results["paradigm"] = f"{paradigm}"
                paradigm_results["evaluation"] = f"{evaluation}"
                eval_results[f"{paradigm}"] = paradigm_results
                df_eval.append(paradigm_results)

            processed_paradigms = processed_paradigms + 1

        if processed_paradigms == 0:
            raise Exception(
                "Non of the paradigms provided by the pipelines received compatible datasets to evaluate."
            )

        # Combining FilterBank and direct paradigms
        eval_results = _combine_paradigms(eval_results)

        _save_results(eval_results, output, plot)

    df_eval = pd.concat(df_eval)
    _display_results(df_eval)

    return df_eval


def _display_results(results):
    """Print results after computation."""
    tab = []
    for d in results["dataset"].unique():
        for p in results["pipeline"].unique():
            for e in results["evaluation"].unique():
                r = {
                    "dataset": d,
                    "evaluation": e,
                    "pipeline": p,
                    "avg score": results[
                        (results["dataset"] == d)
                        & (results["pipeline"] == p)
                        & (results["evaluation"] == e)
                    ]["score"].mean(),
                }
                if _carbonfootprint:
                    r["carbon emission"] = results[
                        (results["dataset"] == d)
                        & (results["pipeline"] == p)
                        & (results["evaluation"] == e)
                    ]["carbon_emission"].sum()
                tab.append(r)
    tab = pd.DataFrame(tab)
    print(tab)


def _combine_paradigms(prdgm_results):
    """Combining FilterBank and direct paradigms.

    Applied only on SSVEP for now.

    Parameters
    ----------
    prdgm_results: dict of DataFrame
        Results of benchmark for all considered paradigms

    Returns
    -------
    eval_results: dict of DataFrame
        Results with filterbank and direct paradigms combined
    """
    eval_results = prdgm_results.copy()
    combine_paradigms = ["SSVEP"]
    for p in combine_paradigms:
        if f"FilterBank{p}" in eval_results.keys() and f"{p}" in eval_results.keys():
            eval_results[f"{p}"] = pd.concat(
                [eval_results[f"{p}"], eval_results[f"FilterBank{p}"]]
            )
            del eval_results[f"FilterBank{p}"]
    return eval_results


def _save_results(eval_results, output, plot):
    """Save results in specified folder.

    Parameters
    ----------
    eval_results: dict of DataFrame
        Results of benchmark for all considered paradigms
    output: str or Path
        Folder to store the analysis results
    plot: bool
        Plot results after computing
    """
    for prdgm, prdgm_result in eval_results.items():
        prdgm_path = Path(output) / prdgm
        if not osp.isdir(prdgm_path):
            prdgm_path.mkdir()
        analyze(prdgm_result, str(prdgm_path), plot=plot)


def _inc_exc_datasets(
    paradigm_datasets, paradigm_name, include_datasets=None, exclude_datasets=None
):
    """
    Filter datasets based on include_datasets and exclude_datasets.

    Parameters
    ----------
    datasets : list
        List of dataset class instances (each with a `.code` attribute).
    paradigm_name: str
        Paradigm name.
    include_datasets : list[str or Dataset], optional
        List of dataset codes or dataset class instances to include.
    exclude_datasets : list[str or Dataset], optional
        List of dataset codes or dataset class instances to exclude.

    Returns
    -------
    list
        Filtered list of dataset class instances.

    """
    # --- Safety checks ---
    if include_datasets is not None and exclude_datasets is not None:
        raise ValueError("Cannot specify both include_datasets and exclude_datasets.")

    all_paradigm_codes = [ds.code for ds in paradigm_datasets]
    d = list(paradigm_datasets)

    # --- Inclusion logic ---
    if include_datasets is not None:
        include_codes = _validate_list_per_paradigm(
            all_paradigm_codes, paradigm_name, include_datasets, "include_datasets"
        )
        # Keep only included datasets
        filtered = [ds for ds in paradigm_datasets if ds.code in include_codes]
        return filtered

    # --- Exclusion logic ---
    if exclude_datasets is not None:
        exclude_codes = _validate_list_per_paradigm(
            all_paradigm_codes, paradigm_name, exclude_datasets, "exclude_datasets"
        )
        if not exclude_codes:
            return []
        else:
            # Remove excluded datasets
            filtered = [ds for ds in paradigm_datasets if ds.code not in exclude_codes]
            return filtered

    return d


def _get_paradigm_instance(paradigm_name, context_params=None):
    """
    Get a paradigm instance from moabb.paradigms by name (case-insensitive).

    Parameters
    ----------
    paradigm_name : str
        Name of the paradigm to look up (e.g., 'P300', 'MotorImagery').
    context_params : dict, optional
        Dictionary mapping paradigm names to parameters.
        Will pass context_params[paradigm_name] to the paradigm constructor if available.

    Returns
    -------
    paradigm_instance : moabb.paradigms.BaseParadigm
        Instance of the requested paradigm.

    Raises
    ------
    ValueError
        If the paradigm name is not found in moabb.paradigms.
    """
    context_params = context_params or {}

    # Find matching class name in moabb.paradigms, case-insensitive
    cls_name = next(
        (name for name in dir(moabb_paradigms) if name.lower() == paradigm_name.lower()),
        None,
    )
    if cls_name is None:
        raise ValueError(
            f"Paradigm '{paradigm_name}' not found in moabb.paradigms. "
            f"Available paradigms: {[name for name in dir(moabb_paradigms) if not name.startswith('_')]}"
        )

    # Get the class and instantiate
    ParadigmClass = getattr(moabb_paradigms, cls_name)
    params = context_params.get(paradigm_name, {})
    return ParadigmClass(**params)


def _validate_list_per_paradigm(all_paradigm_codes, paradigm_name, ds_list, list_name):
    """
    Validates a list of include/exclude datasets for specific paradigm.

    Ensures the user-provided list of datasets is valid for use in the benchmark.
    Allows dataset lists that contain entries for multiple paradigms, as long as
    at least one dataset is compatible with the current paradigm.

    Checks:
    - The input is a list or tuple.
    - The list is not empty.
    - All elements are either strings or BaseDataset objects (no mix).
    - No duplicates are present.
    - Which datasets match the current paradigm’s available datasets (all_paradigm_codes).
    - Fake datasets (codes starting with "FakeDataset") are always accepted.

    Parameters
    ----------
    all_paradigm_codes: list
        Valid dataset codes for the paradigm.
    paradigm_name: str
        Paradigm name.
    ds_list : list[str or BaseDataset]
        The list to validate. Can contain dataset codes (e.g., ["BNCI2014-001"])
        or dataset objects (instances of BaseDataset or its subclasses).
    list_name : str
        The name of the list ("include_datasets" or "exclude_datasets"),
        used only for error messages.

    Returns
    -------
    list[str]
        A normalized list of dataset codes extracted from the input list.

    """
    if not isinstance(ds_list, (list, tuple)):
        raise TypeError(f"{list_name} must be a list or tuple.")

    # Empty list edge case
    if len(ds_list) == 0:
        raise ValueError(f"{list_name} cannot be an empty list.")

    # Ensure homogeneity: all strings or all dataset objects
    all_str = all(isinstance(x, str) for x in ds_list)
    all_obj = all(isinstance(x, BaseDataset) for x in ds_list)

    if not (all_str or all_obj):
        raise TypeError(
            f"{list_name} must contain either all strings or all dataset objects, not a mix."
        )

    # --- Handle case: list of dataset codes (strings) ---
    if all_str:
        # Check duplicates
        if len(ds_list) != len(set(ds_list)):
            raise ValueError(f"{list_name} contains duplicate dataset codes.")

        # Accept all codes that belong to the current paradigm or are fake datasets
        valid = [
            x for x in ds_list if x in all_paradigm_codes or x.startswith("FakeDataset")
        ]
        if not valid:
            print(
                f"WARNING: None of the datasets in {list_name} are compatible with paradigm {paradigm_name}. "
                f"Provided datasets: {ds_list}"
            )
        elif len(valid) != len(ds_list):
            print(
                f"WARNING: Some datasets in {list_name} are incompatible with paradigm {paradigm_name}. "
                f"Provided datasets: {ds_list}. Invalid datastes: {[x for x in ds_list if x not in valid]}"
            )
        return valid

    # --- Handle case: list of dataset objects ---
    codes = [x.code for x in ds_list]
    if len(codes) != len(set(codes)):
        raise ValueError(f"{list_name} contains duplicate dataset instances.")

    # Accept all dataset objects that belong to the current paradigm or are fake datasets
    valid = [
        x.code
        for x in ds_list
        if x.code in all_paradigm_codes or x.code.startswith("FakeDataset")
    ]
    if not valid:
        print(
            f"WARNING: None of the datasets in {list_name} are compatible with paradigm {paradigm_name}. "
            f"Provided datasets: {[x.code for x in ds_list]}"
        )
    elif len(valid) != len(ds_list):
        print(
            f"WARNING: Some datasets in {list_name} are incompatible with paradigm {paradigm_name}. "
            f"Provided datasets: {ds_list}. Invalid datastes: {[x for x in ds_list if x not in valid]}"
        )

    return valid
