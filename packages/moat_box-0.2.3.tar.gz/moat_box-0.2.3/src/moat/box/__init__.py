"""
MoaT inventory module to store boxes.
"""
