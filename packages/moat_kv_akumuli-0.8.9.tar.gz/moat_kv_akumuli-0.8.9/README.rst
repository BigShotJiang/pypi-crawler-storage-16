===========
DistAkumuli
===========

DistAkumuli is a simple link between Akumuli and DistKV.

It will update an Akumuli series whenever a DistKV value changes.
