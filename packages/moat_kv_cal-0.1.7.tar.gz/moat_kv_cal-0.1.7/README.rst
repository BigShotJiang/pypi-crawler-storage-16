===========
MoaT-KV-Cal
===========

MoaT-KV-Cal is a calendar extension to MoaT-KV.

It can monitor a calendar (or specific entries thereof), publish pending
entries, set alerts, control that they are acknowledged, and escalate
if/when they are not.
