* document basic usage

* document command line

* input handling: don't do the fancy debounce stuff if t_bounce is zero
