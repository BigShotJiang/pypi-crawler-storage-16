* document basic usage

* document command line

* add code to filter setters (e.g. delta filter, to avoid sensor noise)
