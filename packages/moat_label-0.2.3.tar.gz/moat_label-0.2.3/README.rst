##########
MoaT-Label
##########

This module handles label printing.

Labels contain some text and one or two barcodes. One code is a simple
2-of-5 numeric code that takes up as little space as possible. The other is
a Datamatrix code that contains an arbitrary link.

Labels are printed on sheets, then attached to boxes and/or things. A label
can be on one box and/or one thing.
