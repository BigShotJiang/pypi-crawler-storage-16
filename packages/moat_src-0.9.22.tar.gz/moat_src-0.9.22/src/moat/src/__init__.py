"""
This subpackage manages source code.
"""

from __future__ import annotations

from moat.util.config import CfgStore

CfgStore.with_(__name__)
