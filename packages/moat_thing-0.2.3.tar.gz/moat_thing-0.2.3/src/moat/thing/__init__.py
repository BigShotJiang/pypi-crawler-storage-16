"""
This subpackage manages things (stored in a database).
"""
