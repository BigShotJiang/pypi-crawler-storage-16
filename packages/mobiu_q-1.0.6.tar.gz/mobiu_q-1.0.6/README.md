# Mobiu-Q

**Mobiu-Q** is a next-generation optimizer built on *Soft Algebra* and *Demeasurement* theory, enabling stable and efficient optimization in quantum variational algorithms (VQE, QAOA).

### ✨ Features
- Soft Algebra update rule for stable convergence  
- SPSA Demeasurement for noisy hardware  
- Adaptive "Noisy Mode" presets
- **Validated on real quantum hardware (IBM)**

---

## 📦 Installation
```bash
pip install mobiu-q
```

## 🔑 License
```python
from mobiu_q import activate_license

activate_license("YOUR-LICENSE-KEY")
```
- **Free tier:** 5 runs/month
- **Pro tier:** Unlimited runs

---

## 🚀 Quick Start (Simulation)
Best for clean simulations or statevector backends.

```python
import numpy as np
from mobiu_q import MobiuQCore, Demeasurement, get_energy_function

energy_fn = get_energy_function("h2_molecule")

# Initialize in standard mode
opt = MobiuQCore(mode="standard") 

params = np.random.uniform(-np.pi, np.pi, 6)

for step in range(50):
    E = energy_fn(params)
    grad = Demeasurement.finite_difference(energy_fn, params)
    params = opt.step(params, grad, E)

opt.end()  # End session
```

## ⚡ Real Hardware / Shot Noise
When running on noisy quantum computers (IBM, IonQ) or simulators with shot noise:

```python
# Initialize in noisy mode (robust learning)
opt = MobiuQCore(mode="noisy") 

for step in range(100):
    # SPSA returns gradient AND energy estimate (saves 50% measurements)
    grad, E = Demeasurement.spsa(energy_fn, params, c_shift=0.1)
    params = opt.step(params, grad, E)

opt.end()
```

---

## 🔄 Multi-Seed Experiments (Important!)

When running experiments with multiple seeds, use `new_run()` to reset the optimizer state between seeds **without consuming additional runs** from your quota.

### ✅ Correct Usage (counts as 1 run)

```python
from mobiu_q import MobiuQCore, Demeasurement

opt = MobiuQCore(mode="standard")

for seed in range(10):
    np.random.seed(seed)
    params = np.random.uniform(-np.pi, np.pi, n_params)
    
    opt.new_run()  # Reset optimizer state, keep session open
    
    for step in range(100):
        grad = Demeasurement.finite_difference(energy_fn, params)
        params = opt.step(params, grad, energy_fn(params))

opt.end()  # Only here it counts as 1 run!
```

### ❌ Wrong Usage (counts as 10 runs!)

```python
# DON'T do this - each iteration creates a new session
for seed in range(10):
    opt = MobiuQCore(mode="standard")  # New session each time!
    # ... optimization ...
    opt.end()  # Counted as a run
```

### 💡 Comparing Multiple Optimizers

```python
# Create all optimizers once, before the seed loop
opt_standard = MobiuQCore(mode="standard")
opt_noisy = MobiuQCore(mode="noisy")

for seed in range(20):
    np.random.seed(seed)
    init_params = np.random.uniform(-np.pi, np.pi, n_params)
    
    # Test standard mode
    opt_standard.new_run()
    params = init_params.copy()
    for step in range(100):
        grad = Demeasurement.finite_difference(energy_fn, params)
        params = opt_standard.step(params, grad, energy_fn(params))
    
    # Test noisy mode
    opt_noisy.new_run()
    params = init_params.copy()
    for step in range(100):
        grad, E = Demeasurement.spsa(energy_fn, params)
        params = opt_noisy.step(params, grad, E)

# End all sessions (counts as 2 runs total)
opt_standard.end()
opt_noisy.end()
```

---

## 📊 Performance Results

### Clean Simulation
Tested on H2 molecule (6 params), 100 seeds:

| Optimizer | Gap to Ground State | Improvement |
|-----------|---------------------|-------------|
| Adam | 0.089 | - |
| **Mobiu-Q** | **0.034** | **+62%** ✅ |

### Shot Noise Simulation
Tested on Transverse Ising (4 qubits), 30 seeds:

| Shots | Adam Gap | Mobiu-Q Gap | Improvement | p-value |
|-------|----------|-------------|-------------|---------|
| 1000 | 1.63 | 1.48 | +9.2% | 0.002 ✅ |
| 500 | 1.65 | 1.49 | +9.8% | 0.002 ✅ |
| 50 | 2.00 | 1.82 | +9.2% | 0.009 ✅ |

### Real Quantum Hardware (IBM Fez)
H2 molecule optimization:

| Metric | Result |
|--------|--------|
| Initial gap | 0.22 |
| **Final gap** | **0.034** |
| Improvement | **85%** ✅ |

---

## 💡 Choosing the Right Mode

| Scenario | Mode | Gradient Method |
|----------|------|-----------------|
| Clean simulation (statevector) | `standard` | `finite_difference` |
| Shot noise simulation | `noisy` | `spsa` |
| Real quantum hardware | `noisy` | `spsa` |

### Mode Settings

| Mode | Learning Rate | Best For |
|------|---------------|----------|
| `standard` | 0.05 | Simulators (Qiskit Aer, PennyLane, Cirq) |
| `noisy` | 0.02 | Real hardware (IBM, IonQ, Rigetti) |

---

## 📚 Built-in Problems

```python
from mobiu_q import list_problems, get_energy_function, get_ground_state_energy

print(list_problems())
# ['h2_molecule', 'lih_molecule', 'transverse_ising', 'heisenberg_xxz', ...]

energy_fn = get_energy_function("h2_molecule")
E0 = get_ground_state_energy("h2_molecule")
```

---

## ⚙️ API Reference

### MobiuQCore

```python
MobiuQCore(
    license_key=None,       # Your license key (or use activate_license())
    mode="standard",        # 'standard' or 'noisy'
    base_lr=None,           # Custom learning rate (overrides mode)
    verbose=True            # Print session messages
)
```

**Methods:**
- `step(params, gradient, energy)` → updated params
- `new_run()` → reset optimizer state for new seed (same session)
- `end()` → close session (counts as 1 run)

### Demeasurement

```python
# For clean simulations (2*N function calls)
grad = Demeasurement.finite_difference(fn, params)

# For noisy environments (only 2 function calls!)
grad, energy = Demeasurement.spsa(fn, params, c_shift=0.1)
```

---

## 🔥 Full Example: IBM Hardware

```python
from qiskit_ibm_runtime import QiskitRuntimeService, EstimatorV2
from mobiu_q import MobiuQCore, Demeasurement

service = QiskitRuntimeService(channel="ibm_quantum")
backend = service.least_busy(simulator=False, min_num_qubits=5)
estimator = EstimatorV2(mode=backend)

opt = MobiuQCore(mode="noisy")

for step in range(60):
    grad, energy = Demeasurement.spsa(
        lambda p: estimator.run([(circuit, observable)]).result()[0].data.evs.item(),
        params,
        c_shift=0.12
    )
    params = opt.step(params, grad, energy)

opt.end()
```

---

© Mobiu Technologies, 2025