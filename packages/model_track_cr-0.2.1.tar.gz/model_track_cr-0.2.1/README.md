# model_track

O **model_track** é uma biblioteca Python voltada para o controle, versionamento e acompanhamento de modelos de Machine Learning ao longo de seu ciclo de vida.  
Ela tem como objetivo oferecer uma interface simples e extensível para registrar métricas, parâmetros, artefatos e metadados de maneira consistente, favorecendo rastreabilidade e boas práticas de engenharia.

O projeto segue uma abordagem **Test-Driven Development (TDD)** desde o início, garantindo qualidade, segurança na evolução e documentação viva por meio dos testes.

---

## 📦 Estrutura do Projeto

    model_track/
    │
    ├── model_track/
    │   └── …
    ├── tests/
    │   └── …
    ├── pyproject.toml
    ├── pytest.ini
    ├── .coveragerc
    ├── README.md
    └── Makefile

O projeto utiliza:

- **Poetry** para gestão de dependências e ambiente
- **pytest** para testes
- **pytest-cov** + **coverage** para cobertura
- **Makefile** para automatizar rotinas (testes, instalação, limpeza etc.)

---

## 🚀 Instalação

Clone o repositório:

```bash
git clone https://github.com/SEU_USUARIO/model_track.git
cd model_track

Instale o ambiente com:

make install

Ou diretamente:

poetry install
```

⸻

🧪 Executando Testes

Testes:

```bash
make test
```

Cobertura de código (com relatório HTML):

```bash
make cov
```

Limpeza de caches:

```bash
make clean
```

⸻

🛠 Desenvolvimento

1️⃣ Ativar o ambiente virtual

```bash
poetry shell
```
2️⃣ Desenvolvimento orientado a testes (TDD)

O fluxo recomendado é:
	1.	Criar/editar um teste em tests/
	2.	Rodar:

```bash
make test
```

	3.	Implementar o código mínimo para o teste passar
	4.	Refatorar com segurança usando os testes
	5.	Gerar relatório de cobertura (opcional):

```bash
make cov
```


⸻

🧩 Fixtures Globais

Todas as fixtures compartilhadas devem ficar em:

tests/conftest.py

Esse arquivo é carregado automaticamente pelo pytest.

⸻

🤝 Como Contribuir

Contribuições são bem-vindas! Siga os passos abaixo para manter a consistência do projeto.

1. Abra um fork do repositório

Crie seu fork e baixe localmente:

```bash
git clone https://github.com/SEU_USUARIO/model_track.git
```

2. Crie uma nova branch

```bash
git checkout -b feature/nome-da-feature
```

3. Siga o fluxo TDD

Qualquer funcionalidade nova deve vir acompanhada de testes.

4. Garanta que tudo passa

```bash
make test
```

5. Garanta 100% de cobertura para módulos novos
```bash
make cov
```

O relatório HTML ficará em:

htmlcov/index.html

6. Abra um Pull Request

O PR deve incluir:
*	descrição clara da mudança
*	justificativa
*	exemplos de uso, quando necessário

Os PRs só serão aceitos se:
*	todos os testes passarem
*	não quebrarem a cobertura mínima configurada
*	seguirem a filosofia de TDD

⸻

📚 Roadmap (em evolução)
*	Definição do core API para tracking de modelos
*	Adição de backend de armazenamento (filesystem, SQL, NoSQL)
*	Componente de versionamento automático
*	CLI com comandos para consulta e registro
*	Templates automáticos para experimentos

⸻

📝 Licença

Escolha recomendada: MIT, Apache 2.0 ou BSD-3-Clause.

