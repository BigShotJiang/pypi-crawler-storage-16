from .version import version as __version__


def get_version() -> str:
    return __version__
