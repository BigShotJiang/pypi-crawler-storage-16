# Copyright 2023 BioMap (Beijing) Intelligence Technology Limited

from .select_model import select_model
