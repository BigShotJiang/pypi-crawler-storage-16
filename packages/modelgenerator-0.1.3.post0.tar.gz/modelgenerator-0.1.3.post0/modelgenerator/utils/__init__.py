from modelgenerator.utils.kwargs_doc import GoogleKwargsDocstringInheritanceInitMeta

__all__ = [
    "GoogleKwargsDocstringInheritanceInitMeta",
]
