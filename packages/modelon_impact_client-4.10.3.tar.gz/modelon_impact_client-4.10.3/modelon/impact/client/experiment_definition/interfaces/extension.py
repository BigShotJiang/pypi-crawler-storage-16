from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


class BaseExperimentExtension:
    """Base class for an experiment extension class."""

    pass
