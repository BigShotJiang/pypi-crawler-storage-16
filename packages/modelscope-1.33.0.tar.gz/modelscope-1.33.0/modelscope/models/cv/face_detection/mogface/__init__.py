# Copyright (c) Alibaba, Inc. and its affiliates.
from .models.detectors import MogFaceDetector
