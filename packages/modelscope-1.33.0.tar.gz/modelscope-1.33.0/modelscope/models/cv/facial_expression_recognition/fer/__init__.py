# Copyright (c) Alibaba, Inc. and its affiliates.
from .facial_expression_recognition import FacialExpressionRecognition
