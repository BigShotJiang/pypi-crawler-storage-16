"""Example package configuration using bleeding edge toolset."""

__version__ = '0.0.1'
