"""
Main module for modict.
"""

def main():
    """
    Main entry point for the application.
    """
    print("Hello from modict!")


if __name__ == "__main__":
    main()