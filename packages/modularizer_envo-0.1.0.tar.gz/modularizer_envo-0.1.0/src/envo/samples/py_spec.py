from envo.magic_env import magic_env

X = 5
"""Test description"""

env  = magic_env(".env")