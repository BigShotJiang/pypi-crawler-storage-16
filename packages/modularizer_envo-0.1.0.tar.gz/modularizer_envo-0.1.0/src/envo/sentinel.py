unspecified = object()
"""Sentinel object used to distinguish between None and unspecified arguments."""

