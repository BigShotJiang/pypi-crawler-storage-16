"""CLI entry point for markdown renderer."""

from . import main

if __name__ == "__main__":
    main()

