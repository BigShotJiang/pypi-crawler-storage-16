RESET = "\033[0m"


# === Text Attributes ===
BOLD         = "\033[1m"
DIM          = "\033[2m"
ITALIC       = "\033[3m"
UNDERLINE    = "\033[4m"
BLINK        = "\033[5m"
REVERSE      = "\033[7m"
HIDDEN       = "\033[8m"
STRIKETHROUGH = "\033[9m"
