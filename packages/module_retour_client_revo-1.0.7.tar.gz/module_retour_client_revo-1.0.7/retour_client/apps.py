from django.apps import AppConfig


class RetourClientConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'retour_client'
