from dataclasses import dataclass


@dataclass
class WeatherCloudsBean:
	all: int
