from dataclasses import dataclass


@dataclass
class WeatherCoordBean:
	lon: float
	lat: float
