"""
MoFox Plugin Dev Toolkit 入口点
"""

from mpdt.cli import cli

if __name__ == "__main__":
    cli()
