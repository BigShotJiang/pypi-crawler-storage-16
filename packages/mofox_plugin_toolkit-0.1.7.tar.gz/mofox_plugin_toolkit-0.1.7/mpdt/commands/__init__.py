"""
命令模块
"""

__all__ = [
    "init",
    "generate",
    "check",
]
