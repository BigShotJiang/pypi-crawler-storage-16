:::mokkari.schemas.character.Character
:::mokkari.schemas.character.CharacterPost
:::mokkari.schemas.character.CharacterPostResponse