:::mokkari.schemas.generic.GenericItem
