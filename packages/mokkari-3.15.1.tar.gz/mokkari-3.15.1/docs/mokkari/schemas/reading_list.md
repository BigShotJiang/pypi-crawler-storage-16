:::mokkari.schemas.reading_list.AttributionSource
:::mokkari.schemas.reading_list.ReadingListIssue
:::mokkari.schemas.reading_list.ReadingListItem
:::mokkari.schemas.reading_list.ReadingListList
:::mokkari.schemas.reading_list.ReadingListRead
:::mokkari.schemas.reading_list.User