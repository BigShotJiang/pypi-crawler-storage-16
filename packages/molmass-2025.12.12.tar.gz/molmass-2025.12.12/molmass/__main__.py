# molmass/__main__.py

"""Molmass package command line script."""

import sys

from .molmass import main

sys.exit(main())
