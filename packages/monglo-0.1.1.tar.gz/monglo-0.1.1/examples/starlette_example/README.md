# Starlette Minimal Example

Minimal Starlette application with Monglo admin.

## Setup

```bash
cd examples/starlette_minimal
pip install -e "../../[starlette]"
```

## Run

```bash
python app.py
```

Visit: http://localhost:8000/api/admin

## Code

Only **10 lines** of code needed - library handles everything!
