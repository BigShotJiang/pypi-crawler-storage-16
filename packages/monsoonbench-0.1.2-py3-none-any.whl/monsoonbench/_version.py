"""Version information for MonsoonBench."""

__version__ = "0.1.0"
