"""Command-line interface module."""
