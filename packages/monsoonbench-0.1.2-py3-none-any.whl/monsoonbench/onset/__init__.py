"""Monsoon onset detection algorithms."""
