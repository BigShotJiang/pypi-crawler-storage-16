"""Spatial utilities for grids and regions."""
