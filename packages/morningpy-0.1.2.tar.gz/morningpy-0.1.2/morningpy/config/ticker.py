from morningpy.core.auth import AuthType

class TickerConfig:
    pass