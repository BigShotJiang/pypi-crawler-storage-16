from dataclasses import dataclass
from typing import Optional

from morningpy.core.dataframe_schema import DataFrameSchema

@dataclass
class TickerSchema(DataFrameSchema):
    pass