Changelog
=========

Version 0.1
-----------

New Features
~~~~~~~~~~~~
- Example code in Python


Bug Fixes
~~~~~~~~~
- Describe Bug Fixes here
- Remove this subsection if there are no Bug Fixes


Improvements
~~~~~~~~~~~~
- Describe Improvements here
- Remove this subsection if there are no Improvements