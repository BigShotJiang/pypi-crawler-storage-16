# morph-spines

Package to load morphologies with spines.


## Installation

The package can be installed through `pip`.


## Examples

See `examples` folder for usage examples.

See `examples/data` for documentation on the file format.


Copyright (c) 2025 Open Brain Institute
