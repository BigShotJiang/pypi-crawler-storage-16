"""Provides core functionalities for morphology with spines classes."""
