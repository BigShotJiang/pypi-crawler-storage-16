from ._widget import  morphodeep_widget

__all__ = ( "morphodeep_widget")
