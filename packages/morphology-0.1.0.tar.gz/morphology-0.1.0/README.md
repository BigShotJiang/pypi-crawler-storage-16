# morphology

`morphology` is a python package containing various primitives for measuring cellular morphology (written in Rust & under development).

## Installation

```bash
pip install morphology
```
