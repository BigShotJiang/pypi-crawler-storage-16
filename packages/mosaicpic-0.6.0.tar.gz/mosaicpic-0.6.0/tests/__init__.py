"""Test suite for the mosaicpic package."""
