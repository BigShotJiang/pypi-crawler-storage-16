"""Integration tests for mosaicpic package."""
