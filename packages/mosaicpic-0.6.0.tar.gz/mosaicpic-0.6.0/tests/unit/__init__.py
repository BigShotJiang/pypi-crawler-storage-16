"""Unit tests for mosaicpic package."""
