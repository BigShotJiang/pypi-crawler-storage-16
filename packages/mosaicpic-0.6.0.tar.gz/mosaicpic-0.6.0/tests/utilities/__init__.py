"""Test utilities for mosaicpic tests."""
