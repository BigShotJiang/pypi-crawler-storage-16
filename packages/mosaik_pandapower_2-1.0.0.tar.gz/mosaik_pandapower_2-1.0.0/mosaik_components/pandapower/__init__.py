import mosaik_api_v3

from mosaik_components.pandapower.simulator import Simulator

__all__ = ["Simulator"]


def main():
    mosaik_api_v3.start_simulation(Simulator(), "run the pandapower adapter for mosaik")


if __name__ == "__main__":
    main()
