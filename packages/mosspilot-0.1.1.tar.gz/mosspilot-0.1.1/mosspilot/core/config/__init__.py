"""
MossPilot 配置管理模块
"""

from mosspilot.core.config.settings import settings

__all__ = ["settings"]