"""
Moss 报告生成模块
"""

from mosspilot.core.reporting.html_reporter import HTMLReporter

__all__ = ["HTMLReporter"]