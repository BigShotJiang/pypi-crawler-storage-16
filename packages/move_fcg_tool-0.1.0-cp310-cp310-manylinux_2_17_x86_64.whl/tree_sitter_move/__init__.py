"""Move grammar for tree-sitter (supports Aptos Move and Sui Move)"""

from ._binding import language

__all__ = ["language"]

__version__ = "0.1.0"

