# Provider-specific type aliases
