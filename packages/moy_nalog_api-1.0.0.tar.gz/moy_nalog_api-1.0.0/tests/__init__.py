"""Tests for moy_nalog package."""
