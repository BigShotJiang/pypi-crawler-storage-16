from enum import Enum


class AnalysisUnit(Enum):
    CLIENT = "client_id"
    PROFILE_GROUP = "profile_group_id"
