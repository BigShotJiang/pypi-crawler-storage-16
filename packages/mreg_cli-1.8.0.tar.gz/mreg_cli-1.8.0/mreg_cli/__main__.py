"""Entry point for the mreg_cli application."""

from __future__ import annotations

from . import main

if __name__ == "__main__":
    main.main()
