"""Command modules for mreg_cli."""
