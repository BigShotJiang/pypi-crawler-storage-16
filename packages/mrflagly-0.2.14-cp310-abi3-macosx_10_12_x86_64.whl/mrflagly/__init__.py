from .mrflagly import *

__doc__ = mrflagly.__doc__
if hasattr(mrflagly, "__all__"):
    __all__ = mrflagly.__all__