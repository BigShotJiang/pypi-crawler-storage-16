# 🚀 MRG Language

The Simple, Fast & Beautiful Programming Language for Everyone

[![PyPI version](https://badge.fury.io/py/mrglang.svg)](https://badge.fury.io/py/mrglang)
[![Python](https://img.shields.io/badge/python-3.7+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## ✨ Features

- 🎯 **เขียนง่าย** - ไม่ต้องใช้ `{}` `[]` `()` `,` `.` 
- 🇹🇭 **รองรับภาษาไทย** - เขียนโค้ดเป็นภาษาไทยได้เต็มรูปแบบ
- ⚡ **เบาและเร็ว** - Performance สูง กินแรมน้อย
- 🤖 **Discord Bot** - สร้างบอท Discord ได้ง่ายมาก
- 📦 **Package Manager** - จัดการ modules สะดวก
- 💡 **ไม่ซับซ้อน** - เหมาะสำหรับมือใหม่

## 📦 การติดตั้ง

```bash
pip install mrglang
```

## 🎮 Quick Start

### 1. ติดตั้ง Discord Module

```bash
mrg install discord.mrg
```

### 2. สร้างบอท Discord

สร้างไฟล์ `bot.mrg`:

```mrg
# บอท Discord ภาษาไทย
bot MyAwesomeBot
    token YOUR_BOT_TOKEN_HERE
    prefix !
    
    on ready
        print บอทออนไลน์แล้ว!
        set status online
        set activity เล่นกับ MRG
    
    command สวัสดี
        reply สวัสดีครับ! ยินดีต้อนรับ 👋
    
    command ping
        reply Pong! 🏓
    
    command ข้อมูล
        embed
            title ข้อมูลเซิร์ฟเวอร์
            description เซิร์ฟเวอร์นี้เจ๋งมาก
            color blue
            field สมาชิก {member_count} คน
            footer ขอโดย {user_name}
        send embed
    
    command เมนู
        reply เลือกเมนูด้านล่าง
        button Primary หน้าหลัก btn_main
        button Success ช่วยเหลือ btn_help
        send buttons
    
    on button click btn_main
        reply ยินดีต้อนรับสู่หน้าหลัก! 🏠
    
    on button click btn_help
        reply ต้องการความช่วยเหลือใช่ไหม? 💡
```

### 3. รันบอท

```bash
mrg run bot.mrg
```

## 📚 คำสั่งทั้งหมด

### Package Management

```bash
mrg install <package>       # ติดตั้ง package
mrg i <package>             # ติดตั้ง (แบบสั้น)
mrg i pkg1 pkg2 pkg3        # ติดตั้งหลาย packages พร้อมกัน
mrg uninstall <package>     # ถอนการติดตั้ง
mrg list                    # แสดง packages ที่ติดตั้ง
mrg search <keyword>        # ค้นหา packages
mrg info <package>          # ดูข้อมูล package
mrg update                  # อัพเดท package registry
```

### Running

```bash
mrg run <file.mrg>          # รันไฟล์ .mrg
```

### Information

```bash
mrg version                 # เช็คเวอร์ชัน
mrg help                    # ดูคำสั่งทั้งหมด
```

## 📦 Packages ที่มี

- **discord.mrg** - Discord Bot Module
- **http.mrg** - HTTP Client
- **file.mrg** - File System Operations
- **json.mrg** - JSON Parser
- **database.mrg** - SQLite Database
- **math.mrg** - Math Functions
- **crypto.mrg** - Cryptography
- **image.mrg** - Image Processing

## 📖 ตัวอย่างเพิ่มเติม

### HTTP Request

```mrg
import http.mrg

command ราคาบิทคอยน์
    response = http get https://api.coindesk.com/v1/bpi/currentprice.json
    reply ราคาบิทคอยน์: {response.bpi.USD.rate} USD
```

### File Operations

```mrg
import file.mrg

command บันทึก
    file write data.txt สวัสดีจาก MRG
    reply บันทึกสำเร็จ!
```

### Database

```mrg
import database.mrg

command เพิ่มผู้ใช้
    db connect users.db
    db insert users name {user_name}
    reply เพิ่มผู้ใช้สำเร็จ!
```

## 🤝 Contributing

เรายินดีรับ contribution! 

1. Fork the repo
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

MIT License - ดูรายละเอียดใน [LICENSE](LICENSE)

## 🔗 Links

- [GitHub](https://github.com/yourusername/mrglang)
- [PyPI](https://pypi.org/project/mrglang/)
- [Documentation](https://mrglang.readthedocs.io)
- [Discord Community](https://discord.gg/your-server)

## 💖 Support

ถ้าชอบโปรเจกต์นี้ กด ⭐ บน GitHub ได้เลยครับ!

---

Made with ❤️ by MRG Team