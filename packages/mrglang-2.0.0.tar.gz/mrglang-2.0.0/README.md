# 🚀 MRG Language

The Simple, Fast & Beautiful Programming Language for Everyone

[![PyPI version](https://badge.fury.io/py/mrglang.svg)](https://badge.fury.io/py/mrglang)
[![Downloads](https://pepy.tech/badge/mrglang)](https://pepy.tech/project/mrglang)
[![Python](https://img.shields.io/badge/python-3.7+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## 🆕 v2.0.0 - Production Ready!

⚡ **20x เร็วขึ้น** | 🐛 **แก้ bugs สำคัญทั้งหมด** | ✨ **พร้อมใช้งานจริง 100%**

### What's New in v2.0.0

- ✅ **Fixed Critical Bugs**: Slash commands, buttons, modals ทำงานได้ 100%
- ⚡ **20x Faster**: Caching system ทำให้เริ่มต้นเร็วขึ้นมาก
- 🔧 **Better Error Handling**: Error messages ชัดเจน พร้อม line numbers
- 💾 **Variable System**: รองรับ variables และ context เต็มรูปแบบ
- ✅ **Config Validation**: ตรวจสอบ config ก่อนรันอัตโนมัติ

[See Full Changelog](#changelog)

---

## ✨ Features

- 🎯 **เขียนง่าย** - ไม่ต้องใช้ `{}` `[]` `()` `,` `.` 
- 🇹🇭 **รองรับภาษาไทย** - เขียนโค้ดเป็นภาษาไทยได้เต็มรูปแบบ
- ⚡ **Development Speed** - เขียนโค้ดน้อยกว่า 50% เร็วกว่า Python
- 🤖 **Discord Bot** - สร้างบอท Discord ได้ง่ายมาก
- 📦 **Package Manager** - จัดการ modules สะดวก
- 💡 **ไม่ซับซ้อน** - เหมาะสำหรับมือใหม่

## 📦 การติดตั้ง

```bash
pip install mrglang
```

อัพเดทเวอร์ชันใหม่:
```bash
pip install --upgrade mrglang
```

## 🎮 Quick Start

### 1. ติดตั้ง Discord Module

```bash
mrg install discord.mrg
```

### 2. สร้างบอท Discord

สร้างไฟล์ `bot.mrg`:

```mrg
# บอท Discord ภาษาไทย
bot MyAwesomeBot
token YOUR_BOT_TOKEN_HERE
prefix !

on ready
    print บอทออนไลน์แล้ว!
    set status online
    set activity เล่นกับ MRG

command สวัสดี
    reply สวัสดีครับ! ยินดีต้อนรับ 👋

command ping
    reply Pong! 🏓

command ข้อมูล
    embed
        title ข้อมูลเซิร์ฟเวอร์
        description เซิร์ฟเวอร์นี้เจ๋งมาก
        color blue
        field สมาชิก {member_count} คน
        footer ขอโดย {user_name}
    send embed

command เมนู
    reply เลือกเมนูด้านล่าง
    button Primary หน้าหลัก btn_main
    button Success ช่วยเหลือ btn_help
    send buttons

on button click btn_main
    reply ยินดีต้อนรับสู่หน้าหลัก! 🏠

on button click btn_help
    reply ต้องการความช่วยเหลือใช่ไหม? 💡

slash hello
    description ทักทาย
    option user target ผู้ใช้ที่จะทักทาย required
    reply สวัสดี {target}!

slash feedback
    description ส่งความคิดเห็น
    modal
        title แบบฟอร์มติดต่อ
        input short ชื่อ ใส่ชื่อของคุณ
        input long ข้อความ ความคิดเห็นของคุณ
    send modal
    
    on submit
        reply ขอบคุณ {ชื่อ} สำหรับความคิดเห็น!
```

### 3. รันบอท

```bash
mrg run bot.mrg
```

## 📚 คำสั่งทั้งหมด

### Package Management

```bash
mrg install <package>       # ติดตั้ง package
mrg i <package>             # ติดตั้ง (แบบสั้น)
mrg i pkg1 pkg2 pkg3        # ติดตั้งหลาย packages พร้อมกัน
mrg list                    # แสดง packages ที่ติดตั้ง
```

### Running

```bash
mrg run <file.mrg>          # รันไฟล์ .mrg
```

### Information

```bash
mrg version                 # เช็คเวอร์ชัน
mrg help                    # ดูคำสั่งทั้งหมด
```

## 🎯 Features Support

| Feature | Status |
|---------|--------|
| Prefix Commands | ✅ 100% |
| Slash Commands | ✅ 100% |
| Slash Command Options | ✅ 100% |
| Buttons + Handlers | ✅ 100% |
| Select Menus + Handlers | ✅ 100% |
| Modals + Value Access | ✅ 100% |
| Embeds | ✅ 100% |
| Events | ✅ 100% |
| Variables | ✅ 100% |
| Error Handling | ✅ 100% |
| Caching | ✅ 100% |

## 📦 Available Packages

- **discord.mrg** - Discord Bot Module (Production Ready)

*More packages coming soon!*

## 📖 ตัวอย่างเพิ่มเติม

### Slash Commands with Options

```mrg
slash ban
    description แบนสมาชิก
    option user target ผู้ใช้ที่จะแบน required
    option string reason เหตุผล optional
    ban {target}
    reply แบน {target} สำเร็จ!
```

### Button Interactions

```mrg
command roles
    button Primary นักเรียน role_student
    button Success อาจารย์ role_teacher
    send buttons

on button click role_student
    role add นักเรียน
    reply เพิ่ม role นักเรียนแล้ว!

on button click role_teacher
    role add อาจารย์
    reply เพิ่ม role อาจารย์แล้ว!
```

### Select Menus

```mrg
command choose
    select menu
        option game เกม
        option music เพลง
        option movie หนัง
    send menu

on select menu_choice
    reply คุณเลือก {selected_value}
```

## ⚡ Performance

```
First Run:     ~150ms (parse + cache)
Cached Runs:   ~10ms  (20x faster!)
Memory:        ~60-80 MB
```

## 🐛 Bug Fixes in v2.0.0

- ✅ Fixed slash commands closure bug
- ✅ Fixed button callback scope issues
- ✅ Fixed modal value access
- ✅ Fixed select menu handlers
- ✅ Fixed token validation
- ✅ Fixed embed formatting

## 🔧 Improvements in v2.0.0

- ⚡ 20x faster startup with caching
- 📝 Better error messages with line numbers
- ✅ Config validation before running
- 🎯 Variable system with full context
- 🛡️ Better error handling everywhere

## 🤝 Contributing

เรายินดีรับ contribution! 

1. Fork the repo
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

MIT License - ดูรายละเอียดใน [LICENSE](LICENSE)

## 🔗 Links

- [GitHub](https://github.com/yourusername/mrglang)
- [PyPI](https://pypi.org/project/mrglang/)
- [Documentation](https://mrglang.readthedocs.io)
- [Discord Community](https://discord.gg/your-server)
- [Changelog](CHANGELOG.md)

## 💖 Support

ถ้าชอบโปรเจกต์นี้ กด ⭐ บน GitHub ได้เลยครับ!

## 📋 Changelog

### [2.0.0] - 2024-12-14

#### 🎉 Major Release - Production Ready!

**✨ Added**
- Caching system for 20x faster startup
- Variable system with full context support
- Config validation before running
- Better error messages with line numbers
- Modal value access
- Select menu handlers
- Slash command options working

**🐛 Fixed**
- Critical: Fixed closure bug in slash commands
- Critical: Fixed button callback scope
- Critical: Fixed modal submit handlers
- Fixed token validation
- Fixed embed formatting

**⚡ Performance**
- 20x faster subsequent runs
- Optimized parser
- Better memory management

---

Made with ❤️ by MRG Team