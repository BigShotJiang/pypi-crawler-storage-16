# print(f'in lib library_core.__main__')
raise Exception(f'in lib library_core.__main__: should not be called')