# -*- coding: utf-8 -*-

version='1.0.1'
# NB this file is NOT USED ANY MORE ... it is only being kept for reverse-compatibility reasons: currently 2024-12-08
# only project sysadmin needs this file to be present.