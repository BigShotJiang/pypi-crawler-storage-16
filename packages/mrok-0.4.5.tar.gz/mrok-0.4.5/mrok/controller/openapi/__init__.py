from mrok.controller.openapi.utils import generate_openapi_spec

__all__ = ["generate_openapi_spec"]
