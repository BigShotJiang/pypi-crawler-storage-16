from django.apps import AppConfig


class DjangoLegalConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_legal'
