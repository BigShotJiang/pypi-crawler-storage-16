"""
Reusable notifications app providing transactional messaging with email-first support.
"""

default_app_config = "notifications.apps.NotificationsConfig"
