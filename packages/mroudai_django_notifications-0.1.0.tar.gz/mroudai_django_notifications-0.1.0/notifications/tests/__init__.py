import os

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "notifications.tests.settings")
