default_app_config = "notifications.tests.testapp.apps.TestAppConfig"
