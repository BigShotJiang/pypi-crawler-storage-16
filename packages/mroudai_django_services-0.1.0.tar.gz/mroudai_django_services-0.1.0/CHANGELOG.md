# Changelog

All notable changes to this project will be documented here.

## Unreleased
- Initial public release of `django-services`.
