default_app_config = "services.tests.tenants.apps.TenantsConfig"
