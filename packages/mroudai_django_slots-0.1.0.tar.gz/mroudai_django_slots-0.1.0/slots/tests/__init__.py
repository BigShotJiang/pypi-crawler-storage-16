# Test package for django-slots
