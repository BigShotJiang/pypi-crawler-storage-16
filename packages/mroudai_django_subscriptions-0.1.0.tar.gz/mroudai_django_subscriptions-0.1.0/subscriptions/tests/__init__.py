# Test package for django-subscriptions
