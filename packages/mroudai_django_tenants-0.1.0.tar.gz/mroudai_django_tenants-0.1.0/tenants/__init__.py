"""
Reusable tenant foundation for Django multi-tenant applications.
"""

default_app_config = "tenants.apps.TenantsConfig"
