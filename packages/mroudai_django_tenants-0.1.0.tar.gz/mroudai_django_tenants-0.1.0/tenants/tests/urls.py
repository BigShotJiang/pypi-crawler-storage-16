from django.urls import path

urlpatterns = [
    # Intentionally empty; required for Django setup in tests.
]
