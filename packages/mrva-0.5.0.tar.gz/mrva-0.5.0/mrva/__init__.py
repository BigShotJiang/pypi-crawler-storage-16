from importlib.metadata import version

from . import commands  # noqa: F401


__version__ = version("mrva")
