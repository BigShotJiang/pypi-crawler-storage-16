import sys

from mrva.main import main


sys.exit(main())
