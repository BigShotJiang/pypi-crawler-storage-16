# Copyright (c) Alibaba, Inc. and its affiliates.
from swift.megatron import megatron_rlhf_main

if __name__ == '__main__':
    megatron_rlhf_main()
