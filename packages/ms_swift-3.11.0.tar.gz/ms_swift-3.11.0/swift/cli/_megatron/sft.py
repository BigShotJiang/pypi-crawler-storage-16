# Copyright (c) Alibaba, Inc. and its affiliates.
from swift.megatron import megatron_sft_main

if __name__ == '__main__':
    megatron_sft_main()
