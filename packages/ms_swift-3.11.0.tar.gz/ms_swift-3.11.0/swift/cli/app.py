from swift.llm import app_main

if __name__ == '__main__':
    app_main()
