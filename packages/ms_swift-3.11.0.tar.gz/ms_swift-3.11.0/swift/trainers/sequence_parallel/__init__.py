# Copyright (c) Alibaba, Inc. and its affiliates.

from .ulysses import SequenceParallel

sequence_parallel = SequenceParallel()
