# Copyright (c) Alibaba, Inc. and its affiliates.
from swift.ui.llm_train.target import Target


class GRPOTarget(Target):

    group = 'llm_grpo'
