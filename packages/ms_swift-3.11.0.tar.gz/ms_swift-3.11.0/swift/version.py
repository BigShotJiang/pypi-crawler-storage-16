# Make sure to modify __release_datetime__ to release time when making official release.
__version__ = '3.11.0'
# default release datetime for branches under active development is set
# to be a time far-far-away-into-the-future
__release_datetime__ = '2025-12-08 23:59:39'
