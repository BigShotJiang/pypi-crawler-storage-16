__author__ = 'Bing Ads SDK Team'
__email__ = 'bing_ads_sdk@microsoft.com'

from .bulk_account_placement_exlucison_list import *
from .bulk_account_placement_exlucison_list_item import *
from .bulk_account_placement_inclusion_list import *
from .bulk_account_placement_inclusion_list_item import *
from .bulk_campaign_account_placement_exclusion_list_association import *
from .bulk_campaign_account_placement_inclusion_list_association import *
