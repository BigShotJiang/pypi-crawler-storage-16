# msauth_browser/__main__.py

# Built-in imports
import sys

# Internal imports
from . import cli

if __name__ == "__main__":
    sys.exit(cli.main())
