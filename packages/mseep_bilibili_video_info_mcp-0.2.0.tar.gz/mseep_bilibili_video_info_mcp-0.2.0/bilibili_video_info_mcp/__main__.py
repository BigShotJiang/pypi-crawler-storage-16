from bilibili_video_info_mcp import main

main()