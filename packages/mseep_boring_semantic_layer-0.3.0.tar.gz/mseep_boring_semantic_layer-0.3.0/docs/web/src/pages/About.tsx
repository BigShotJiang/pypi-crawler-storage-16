import { WhatIsBSL } from "@/components/WhatIsBSL";
import { Footer } from "@/components/Footer";

const About = () => {
  return (
    <>
      <WhatIsBSL />
      <Footer />
    </>
  );
};

export default About;
