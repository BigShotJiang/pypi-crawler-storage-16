import BSLMarkdownPage from './BSLMarkdownPage'

export default function QueryAgentMCP() {
  return <BSLMarkdownPage pageSlug="query-agent-mcp" />
}
