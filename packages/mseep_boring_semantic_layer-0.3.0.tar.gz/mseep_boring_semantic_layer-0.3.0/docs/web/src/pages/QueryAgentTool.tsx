import BSLMarkdownPage from './BSLMarkdownPage'

export default function QueryAgentTool() {
  return <BSLMarkdownPage pageSlug="query-agent-llm-tool" />
}
