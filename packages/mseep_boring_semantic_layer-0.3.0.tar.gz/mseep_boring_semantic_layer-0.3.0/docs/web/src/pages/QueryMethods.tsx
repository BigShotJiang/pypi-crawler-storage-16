import BSLMarkdownPage from './BSLMarkdownPage'

export default function QueryMethods() {
  return <BSLMarkdownPage pageSlug="query-methods" />
}
