---
name: General Report
about: Provide general feedback or inquiries
title: "[General]: "
labels: general
assignees: ""
---

### Feedback or Inquiry

Provide your feedback or inquiry.

### Additional Information

Add any other relevant details here.
