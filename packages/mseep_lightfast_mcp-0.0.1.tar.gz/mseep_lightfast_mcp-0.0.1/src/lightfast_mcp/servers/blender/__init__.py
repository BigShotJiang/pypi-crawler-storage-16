"""Blender MCP server module."""

from .server import BlenderMCPServer

__all__ = ["BlenderMCPServer"]
