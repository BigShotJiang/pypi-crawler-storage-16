"""Mock MCP server module."""

from .server import MockMCPServer

__all__ = ["MockMCPServer"]
