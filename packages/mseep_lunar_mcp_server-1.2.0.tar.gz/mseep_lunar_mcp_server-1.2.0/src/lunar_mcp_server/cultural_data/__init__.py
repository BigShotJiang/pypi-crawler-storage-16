"""
Cultural data module for Chinese lunar calendar tradition.
"""

from .chinese import ChineseData

__all__ = ["ChineseData"]
