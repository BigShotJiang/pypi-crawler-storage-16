"""Pre-commit guard helpers for MCP Agent Mail."""

from __future__ import annotations

import asyncio
import os
import subprocess
from pathlib import Path

from .config import Settings
from .storage import ProjectArchive, ensure_archive

__all__ = [
    "install_guard",
    "install_prepush_guard",
    "render_precommit_script",
    "render_prepush_script",
    "uninstall_guard",
]


def _render_chain_runner_script(hook_name: str) -> str:
    """
    Render a Python chain-runner for the given Git hook name.

    Behavior:
    - Runs executables in hooks.d/<hook_name>/* in lexical order.
    - For pre-push, reads STDIN once and forwards it to each child hook.
    - If a <hook_name>.orig exists and is executable, it is invoked last.
    - Exits non-zero on the first non-zero child exit code.
    """
    lines: list[str] = [
        "#!/usr/bin/env python3",
        f"# mcp-agent-mail chain-runner ({hook_name})",
        "import os",
        "import sys",
        "import stat",
        "import subprocess",
        "from pathlib import Path",
        "",
        "HOOK_DIR = Path(__file__).parent",
        f"RUN_DIR = HOOK_DIR / 'hooks.d' / '{hook_name}'",
        f"ORIG = HOOK_DIR / '{hook_name}.orig'",
        "",
        "def _is_exec(p: Path) -> bool:",
        "    try:",
        "        st = p.stat()",
        "        return bool(st.st_mode & (stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH))",
        "    except Exception:",
        "        return False",
        "",
        "def _list_execs() -> list[Path]:",
        "    if not RUN_DIR.exists() or not RUN_DIR.is_dir():",
        "        return []",
        "    items = sorted([p for p in RUN_DIR.iterdir() if p.is_file()], key=lambda p: p.name)",
        "    # On POSIX, honor exec bit; on Windows, include all files (we'll dispatch .py via python).",
        "    if os.name == 'posix':",
        "        try:",
        "            items = [p for p in items if _is_exec(p)]",
        "        except Exception:",
        "            pass",
        "    return items",
        "",
        "def _run_child(path: Path, * , stdin_bytes=None):",
        "    # On Windows, prefer 'python' for .py plugins to avoid PATHEXT reliance.",
        "    if os.name != 'posix' and path.suffix.lower() == '.py':",
        "        return subprocess.run(['python', str(path)], input=stdin_bytes, check=False).returncode",
        "    return subprocess.run([str(path)], input=stdin_bytes, check=False).returncode",
        "",
    ]
    if hook_name == "pre-push":
        lines += [
            "# Read STDIN once (Git passes ref tuples); forward to children",
            "stdin_bytes = sys.stdin.buffer.read()",
            "for exe in _list_execs():",
            "    rc = _run_child(exe, stdin_bytes=stdin_bytes)",
            "    if rc != 0:",
            "        sys.exit(rc)",
            "",
            "if ORIG.exists():",
            "    rc = _run_child(ORIG, stdin_bytes=stdin_bytes)",
            "    if rc != 0:",
            "        sys.exit(rc)",
            "sys.exit(0)",
        ]
    else:
        lines += [
            "for exe in _list_execs():",
            "    rc = _run_child(exe)",
            "    if rc != 0:",
            "        sys.exit(rc)",
            "",
            "if ORIG.exists():",
            "    rc = _run_child(ORIG)",
            "    if rc != 0:",
            "        sys.exit(rc)",
            "sys.exit(0)",
        ]
    return "\n".join(lines) + "\n"


def render_precommit_script(archive: ProjectArchive) -> str:
    """Return the pre-commit script content for the given archive.

    Construct with explicit lines at column 0 to avoid indentation errors.
    """

    file_reservations_dir = str((archive.root / "file_reservations").resolve())
    storage_root = str(archive.root.resolve())
    lines = [
        "#!/usr/bin/env python3",
        "# mcp-agent-mail guard hook (pre-commit)",
        "import json",
        "import os",
        "import sys",
        "import subprocess",
        "from pathlib import Path",
        "import fnmatch as _fn",
        "from datetime import datetime, timezone",
        "",
        "# Optional Git pathspec support (preferred when available)",
        "try:",
        "    from pathspec import PathSpec as _PS  # type: ignore[import-not-found]",
        "    from pathspec.patterns.gitwildmatch import GitWildMatchPattern as _GWM  # type: ignore[import-not-found]",
        "except Exception:",
        "    _PS = None  # type: ignore[assignment]",
        "    _GWM = None  # type: ignore[assignment]",
        "",
        f"FILE_RESERVATIONS_DIR = Path(\"{file_reservations_dir}\")",
        f"STORAGE_ROOT = Path(\"{storage_root}\")",
        "",
        "# Gate variables (presence) and mode",
        "GATE = (os.environ.get(\"WORKTREES_ENABLED\",\"0\") or os.environ.get(\"GIT_IDENTITY_ENABLED\",\"0\") or \"0\")",
        "",
        "# Exit early if gate is not enabled (WORKTREES_ENABLED=0 and GIT_IDENTITY_ENABLED=0)",
        "if GATE.strip().lower() not in {\"1\",\"true\",\"t\",\"yes\",\"y\"}:",
        "    sys.exit(0)",
        "",
        "# Advisory/blocking mode: default to 'block' unless explicitly set to 'warn'.",
        "MODE = (os.environ.get(\"AGENT_MAIL_GUARD_MODE\",\"block\") or \"block\").strip().lower()",
        "ADVISORY = MODE in {\"warn\",\"advisory\",\"adv\"}",
        "",
        "# Emergency bypass",
        "if (os.environ.get(\"AGENT_MAIL_BYPASS\",\"0\") or \"0\").strip().lower() in {\"1\",\"true\",\"t\",\"yes\",\"y\"}:",
        "    sys.stderr.write(\"[pre-commit] bypass enabled via AGENT_MAIL_BYPASS=1\\n\")",
        "    sys.exit(0)",
        "AGENT_NAME = os.environ.get(\"AGENT_NAME\")",
        "if not AGENT_NAME:",
        "    sys.stderr.write(\"[pre-commit] AGENT_NAME environment variable is required.\\n\")",
        "    sys.exit(1)",
        "",
        "# Collect staged paths (name-only) and expand renames/moves (old+new)",
        "paths = []",
        "try:",
        "    co = subprocess.run([\"git\",\"diff\",\"--cached\",\"--name-only\",\"-z\",\"--diff-filter=ACMRDTU\"],",
        "                        check=True,capture_output=True)",
        "    data = co.stdout.decode(\"utf-8\",\"ignore\")",
        "    for p in data.split(\"\\x00\"):",
        "        if p:",
        "            paths.append(p)",
        "    # Rename detection: capture both old and new names",
        "    cs = subprocess.run([\"git\",\"diff\",\"--cached\",\"--name-status\",\"-M\",\"-z\"],",
        "                        check=True,capture_output=True)",
        "    sdata = cs.stdout.decode(\"utf-8\",\"ignore\")",
        "    parts = [x for x in sdata.split(\"\\x00\") if x]",
        "    i = 0",
        "    while i < len(parts):",
        "        status = parts[i]",
        "        i += 1",
        "        if status.startswith(\"R\") and i + 1 < len(parts):",
        "            oldp = parts[i]; newp = parts[i+1]; i += 2",
        "            if oldp: paths.append(oldp)",
        "            if newp: paths.append(newp)",
        "        else:",
        "            # Status followed by one path",
        "            if i < len(parts):",
        "                pth = parts[i]; i += 1",
        "                if pth: paths.append(pth)",
        "except Exception:",
        "    pass",
        "",
        "if not paths:",
        "    sys.exit(0)",
        "",
        "# Local conflict detection against FILE_RESERVATIONS_DIR",
        "def _now_iso_utc():",
        "    return datetime.now(timezone.utc).isoformat()",
        "def _not_expired(expires_ts):",
        "    if not expires_ts:",
        "        return True",
        "    try:",
        "        return expires_ts > _now_iso_utc()",
        "    except Exception:",
        "        return True",
        "def _compile_one(patt):",
        "    q = patt.replace(\"\\\\\",\"/\")",
        "    if _PS and _GWM:",
        "        try:",
        "            return _PS.from_lines(_GWM, [q])",
        "        except Exception:",
        "            return None",
        "    return None",
        "conflicts = []",
        "try:",
        "    for f in FILE_RESERVATIONS_DIR.iterdir():",
        "        if not f.name.endswith('.json'):",
        "            continue",
        "        try:",
        "            data = json.loads(f.read_text(encoding='utf-8'))",
        "        except Exception:",
        "            continue",
        "        recs = data if isinstance(data, list) else [data]",
        "        for r in recs:",
        "            if not isinstance(r, dict):",
        "                continue",
        "            patt = (r.get('path_pattern') or '').strip()",
        "            if not patt:",
        "                continue",
        "            holder = (r.get('agent') or '').strip()",
        "            exclusive = r.get('exclusive', True)",
        "            expires = (r.get('expires_ts') or '').strip()",
        "            if not exclusive:",
        "                continue",
        "            if holder and holder == AGENT_NAME:",
        "                continue",
        "            spec = _compile_one(patt)",
        "            for p in paths:",
        "                norm = p.replace('\\\\','/').lstrip('/')",
        "                matched = spec.match_file(norm) if spec is not None else _fn.fnmatch(norm, patt)",
        "                if matched and _not_expired(expires):",
        "                    conflicts.append((patt, p, holder))",
        "except Exception:",
        "    conflicts = []",
        "if conflicts:",
        "    sys.stderr.write(\"Exclusive file_reservation conflicts detected\\n\")",
        "    for patt, path, holder in conflicts[:10]:",
        "        sys.stderr.write(f\"- {path} matches {patt} (holder: {holder})\\n\")",
        "    if ADVISORY:",
        "        sys.exit(0)",
        "    sys.exit(1)",
        "sys.exit(0)",
    ]
    return "\n".join(lines) + "\n"


def render_prepush_script(archive: ProjectArchive) -> str:
    """Return the pre-push script content that checks conflicts across pushed commits.

    Python script to avoid external shell assumptions; NUL-safe and respects gate/advisory mode.
    """
    file_reservations_dir = str((archive.root / "file_reservations").resolve())
    lines = [
        "#!/usr/bin/env python3",
        "# mcp-agent-mail guard hook (pre-push)",
        "import json",
        "import os",
        "import sys",
        "import subprocess",
        "from pathlib import Path",
        "import fnmatch as _fn",
        "from datetime import datetime, timezone",
        "",
        "# Optional Git pathspec support (preferred when available)",
        "try:",
        "    from pathspec import PathSpec as _PS  # type: ignore[import-not-found]",
        "    from pathspec.patterns.gitwildmatch import GitWildMatchPattern as _GWM  # type: ignore[import-not-found]",
        "except Exception:",
        "    _PS = None  # type: ignore[assignment]",
        "    _GWM = None  # type: ignore[assignment]",
        "",
        f"FILE_RESERVATIONS_DIR = Path(\"{file_reservations_dir}\")",
        "",
        "# Gate variables (presence) and mode",
        "GATE = (os.environ.get(\"WORKTREES_ENABLED\",\"0\") or os.environ.get(\"GIT_IDENTITY_ENABLED\",\"0\") or \"0\")",
        "",
        "# Exit early if gate is not enabled (WORKTREES_ENABLED=0 and GIT_IDENTITY_ENABLED=0)",
        "if GATE.strip().lower() not in {\"1\",\"true\",\"t\",\"yes\",\"y\"}:",
        "    sys.exit(0)",
        "",
        "MODE = (os.environ.get(\"AGENT_MAIL_GUARD_MODE\",\"block\") or \"block\").strip().lower()",
        "ADVISORY = MODE in {\"warn\",\"advisory\",\"adv\"}",
        "if (os.environ.get(\"AGENT_MAIL_BYPASS\",\"0\") or \"0\").strip().lower() in {\"1\",\"true\",\"t\",\"yes\",\"y\"}:",
        "    sys.stderr.write(\"[pre-push] bypass enabled via AGENT_MAIL_BYPASS=1\\n\")",
        "    sys.exit(0)",
        "AGENT_NAME = os.environ.get(\"AGENT_NAME\")",
        "if not AGENT_NAME:",
        "    sys.stderr.write(\"[pre-push] AGENT_NAME environment variable is required.\\n\")",
        "    sys.exit(1)",
        "if not FILE_RESERVATIONS_DIR.exists():",
        "    sys.exit(0)",
        "",
        "# Read tuples from STDIN: <local ref> <local sha> <remote ref> <remote sha>",
        "tuples = []",
        "for line in sys.stdin.read().splitlines():",
        "    parts = line.strip().split()",
        "    if len(parts) >= 4:",
        "        tuples.append((parts[0], parts[1], parts[2], parts[3]))",
        "",
        "changed = []",
        "commits = []",
        "for local_ref, local_sha, remote_ref, remote_sha in tuples:",
        "    if not local_sha:",
        "        continue",
        "    # Enumerate commits to be pushed using remote name from args (argv[1]) when available",
        "    remote = (sys.argv[1] if len(sys.argv) > 1 else \"origin\")",
        "    try:",
        "        cp = subprocess.run([\"git\",\"rev-list\",\"--topo-order\",local_sha,\"--not\",f\"--remotes={remote}\"],",
        "                            check=True,capture_output=True,text=True)",
        "        for sha in cp.stdout.splitlines():",
        "            if sha:",
        "                commits.append(sha.strip())",
        "    except Exception:",
        "        # Fallback: gather changed paths directly when range enumeration fails",
        "        rng = local_sha if (not remote_sha or set(remote_sha) == {\"0\"}) else f\"{remote_sha}..{local_sha}\"",
        "        try:",
        "            cp = subprocess.run([\"git\",\"diff\",\"--name-only\",rng],check=True,capture_output=True,text=True)",
        "            for p in cp.stdout.splitlines():",
        "                if p:",
        "                    changed.append(p.strip())",
        "        except Exception:",
        "            pass",
        "",
        "# changed already initialized above; add per-commit changed paths",
        "for c in commits:",
        "    try:",
        "        cp = subprocess.run([\"git\",\"diff-tree\",\"-r\",\"--no-commit-id\",\"--name-only\",\"--no-ext-diff\",\"--diff-filter=ACMRDTU\",\"-z\",c],",
        "                            check=True,capture_output=True)",
        "        data = cp.stdout.decode(\"utf-8\",\"ignore\")",
        "        paths = [p for p in data.split(\"\\x00\") if p]",
        "        changed.extend(paths)",
        "    except Exception:",
        "        continue",
        "",
        "# Local conflict detection against FILE_RESERVATIONS_DIR using changed paths",
        "if not changed:",
        "    sys.exit(0)",
        "def _now_iso_utc():",
        "    return datetime.now(timezone.utc).isoformat()",
        "def _not_expired(expires_ts):",
        "    if not expires_ts:",
        "        return True",
        "    try:",
        "        return expires_ts > _now_iso_utc()",
        "    except Exception:",
        "        return True",
        "def _compile_one(patt):",
        "    q = patt.replace(\"\\\\\",\"/\")",
        "    if _PS and _GWM:",
        "        try:",
        "            return _PS.from_lines(_GWM, [q])",
        "        except Exception:",
        "            return None",
        "    return None",
        "conflicts = []",
        "try:",
        "    for f in FILE_RESERVATIONS_DIR.iterdir():",
        "        if not f.name.endswith('.json'):",
        "            continue",
        "        try:",
        "            data = json.loads(f.read_text(encoding='utf-8'))",
        "        except Exception:",
        "            continue",
        "        recs = data if isinstance(data, list) else [data]",
        "        for r in recs:",
        "            if not isinstance(r, dict):",
        "                continue",
        "            patt = (r.get('path_pattern') or '').strip()",
        "            if not patt:",
        "                continue",
        "            holder = (r.get('agent') or '').strip()",
        "            exclusive = r.get('exclusive', True)",
        "            expires = (r.get('expires_ts') or '').strip()",
        "            if not exclusive:",
        "                continue",
        "            if holder and holder == AGENT_NAME:",
        "                continue",
        "            spec = _compile_one(patt)",
        "            for p in changed:",
        "                norm = p.replace('\\\\','/').lstrip('/')",
        "                matched = spec.match_file(norm) if spec is not None else _fn.fnmatch(norm, patt)",
        "                if matched and _not_expired(expires):",
        "                    conflicts.append((patt, p, holder))",
        "except Exception:",
        "    conflicts = []",
        "if conflicts:",
        "    sys.stderr.write(\"Exclusive file_reservation conflicts detected\\n\")",
        "    for patt, path, holder in conflicts[:10]:",
        "        sys.stderr.write(f\"- {path} matches {patt} (holder: {holder})\\n\")",
        "    if ADVISORY:",
        "        sys.exit(0)",
        "    sys.exit(1)",
        "sys.exit(0)",
    ]
    return "\n".join(lines) + "\n"


async def install_guard(settings: Settings, project_slug: str, repo_path: Path) -> Path:
    """Install the pre-commit chain-runner and Agent Mail guard plugin."""

    archive = await ensure_archive(settings, project_slug)

    def _git(cwd: Path, *args: str) -> str | None:
        try:
            cp = subprocess.run(["git", "-C", str(cwd), *args], check=True, capture_output=True, text=True)
            return cp.stdout.strip()
        except Exception:
            return None

    def _resolve_hooks_dir(repo: Path) -> Path:
        # Prefer core.hooksPath if configured
        hooks_path = _git(repo, "config", "--get", "core.hooksPath")
        if hooks_path:
            if hooks_path.startswith("/") or (((len(hooks_path) > 1) and ((hooks_path[1:3] == ":\\") or (hooks_path[1:3] == ":/")))):
                resolved = Path(hooks_path)
            else:
                # Resolve relative to repo root
                root = _git(repo, "rev-parse", "--show-toplevel") or str(repo)
                resolved = Path(root) / hooks_path
            return resolved
        # Fall back to git-dir/hooks
        git_dir = _git(repo, "rev-parse", "--git-dir")
        if git_dir:
            g = Path(git_dir)
            if not g.is_absolute():
                g = repo / g
            return g / "hooks"
        # Last resort: traditional path
        return repo / ".git" / "hooks"

    hooks_dir = _resolve_hooks_dir(repo_path)
    if not hooks_dir.exists():
        await asyncio.to_thread(hooks_dir.mkdir, parents=True, exist_ok=True)

    # Ensure hooks.d/pre-commit exists
    run_dir = hooks_dir / "hooks.d" / "pre-commit"
    await asyncio.to_thread(run_dir.mkdir, parents=True, exist_ok=True)

    chain_path = hooks_dir / "pre-commit"
    # Preserve existing non-chain hook as .orig
    if chain_path.exists():
        try:
            content = (await asyncio.to_thread(chain_path.read_text, "utf-8")).strip()
        except Exception:
            content = ""
        if "mcp-agent-mail chain-runner (pre-commit)" not in content:
            orig = hooks_dir / "pre-commit.orig"
            if not orig.exists():
                await asyncio.to_thread(chain_path.replace, orig)
    # Write/overwrite chain-runner
    chain_script = _render_chain_runner_script("pre-commit")
    await asyncio.to_thread(chain_path.write_text, chain_script, "utf-8")
    await asyncio.to_thread(os.chmod, chain_path, 0o755)

    # Windows shims (.cmd / .ps1) to invoke the Python chain-runner
    cmd_path = hooks_dir / "pre-commit.cmd"
    if not cmd_path.exists():
        cmd_body = (
            "@echo off\r\n"
            "setlocal\r\n"
            "set \"DIR=%~dp0\"\r\n"
            "python \"%DIR%pre-commit\" %*\r\n"
            "exit /b %ERRORLEVEL%\r\n"
        )
        await asyncio.to_thread(cmd_path.write_text, cmd_body, "utf-8")
    ps1_path = hooks_dir / "pre-commit.ps1"
    if not ps1_path.exists():
        ps1_body = (
            "$ErrorActionPreference = 'Stop'\n"
            "$hook = Join-Path $PSScriptRoot 'pre-commit'\n"
            "python $hook @args\n"
            "exit $LASTEXITCODE\n"
        )
        await asyncio.to_thread(ps1_path.write_text, ps1_body, "utf-8")

    # Write our guard plugin
    plugin_path = run_dir / "50-agent-mail.py"
    plugin_script = render_precommit_script(archive)
    await asyncio.to_thread(plugin_path.write_text, plugin_script, "utf-8")
    await asyncio.to_thread(os.chmod, plugin_path, 0o755)
    return chain_path


async def install_prepush_guard(settings: Settings, project_slug: str, repo_path: Path) -> Path:
    """Install the pre-push chain-runner and Agent Mail guard plugin."""
    archive = await ensure_archive(settings, project_slug)

    def _git(cwd: Path, *args: str) -> str | None:
        try:
            cp = subprocess.run(["git", "-C", str(cwd), *args], check=True, capture_output=True, text=True)
            return cp.stdout.strip()
        except Exception:
            return None

    def _resolve_hooks_dir(repo: Path) -> Path:
        hooks_path = _git(repo, "config", "--get", "core.hooksPath")
        if hooks_path:
            if hooks_path.startswith("/") or (((len(hooks_path) > 1) and ((hooks_path[1:3] == ":\\") or (hooks_path[1:3] == ":/")))):
                resolved = Path(hooks_path)
            else:
                root = _git(repo, "rev-parse", "--show-toplevel") or str(repo)
                resolved = Path(root) / hooks_path
            return resolved
        git_dir = _git(repo, "rev-parse", "--git-dir")
        if git_dir:
            g = Path(git_dir)
            if not g.is_absolute():
                g = repo / g
            return g / "hooks"
        return repo / ".git" / "hooks"

    hooks_dir = _resolve_hooks_dir(repo_path)
    await asyncio.to_thread(hooks_dir.mkdir, parents=True, exist_ok=True)
    # Ensure hooks.d/pre-push exists
    run_dir = hooks_dir / "hooks.d" / "pre-push"
    await asyncio.to_thread(run_dir.mkdir, parents=True, exist_ok=True)

    chain_path = hooks_dir / "pre-push"
    if chain_path.exists():
        try:
            content = (await asyncio.to_thread(chain_path.read_text, "utf-8")).strip()
        except Exception:
            content = ""
        if "mcp-agent-mail chain-runner (pre-push)" not in content:
            orig = hooks_dir / "pre-push.orig"
            if not orig.exists():
                await asyncio.to_thread(chain_path.replace, orig)
    chain_script = _render_chain_runner_script("pre-push")
    await asyncio.to_thread(chain_path.write_text, chain_script, "utf-8")
    await asyncio.to_thread(os.chmod, chain_path, 0o755)

    # Windows shims (.cmd / .ps1) to invoke the Python chain-runner
    cmd_path = hooks_dir / "pre-push.cmd"
    if not cmd_path.exists():
        cmd_body = (
            "@echo off\r\n"
            "setlocal\r\n"
            "set \"DIR=%~dp0\"\r\n"
            "python \"%DIR%pre-push\" %*\r\n"
            "exit /b %ERRORLEVEL%\r\n"
        )
        await asyncio.to_thread(cmd_path.write_text, cmd_body, "utf-8")
    ps1_path = hooks_dir / "pre-push.ps1"
    if not ps1_path.exists():
        ps1_body = (
            "$ErrorActionPreference = 'Stop'\n"
            "$hook = Join-Path $PSScriptRoot 'pre-push'\n"
            "python $hook @args\n"
            "exit $LASTEXITCODE\n"
        )
        await asyncio.to_thread(ps1_path.write_text, ps1_body, "utf-8")

    plugin_path = run_dir / "50-agent-mail.py"
    plugin_script = render_prepush_script(archive)
    await asyncio.to_thread(plugin_path.write_text, plugin_script, "utf-8")
    await asyncio.to_thread(os.chmod, plugin_path, 0o755)
    return chain_path


async def uninstall_guard(repo_path: Path) -> bool:
    """Remove Agent Mail guard plugin(s) from repo, returning True if any were removed.

    - Removes hooks.d/<hook>/50-agent-mail.py if present.
    - Legacy fallback: removes top-level pre-commit/pre-push only if they are old-style
      Agent Mail hooks (sentinel present) and not chain-runners.
    """

    def _git(cwd: Path, *args: str) -> str | None:
        try:
            cp = subprocess.run(["git", "-C", str(cwd), *args], check=True, capture_output=True, text=True)
            return cp.stdout.strip()
        except Exception:
            return None

    def _resolve_hooks_dir(repo: Path) -> Path:
        hooks_path = _git(repo, "config", "--get", "core.hooksPath")
        if hooks_path:
            if hooks_path.startswith("/") or (((len(hooks_path) > 1) and ((hooks_path[1:3] == ":\\") or (hooks_path[1:3] == ":/")))):
                return Path(hooks_path)
            root = _git(repo, "rev-parse", "--show-toplevel") or str(repo)
            return Path(root) / hooks_path
        git_dir = _git(repo, "rev-parse", "--git-dir")
        if git_dir:
            g = Path(git_dir)
            if not g.is_absolute():
                g = repo / g
            return g / "hooks"
        return repo / ".git" / "hooks"

    hooks_dir = _resolve_hooks_dir(repo_path)
    removed = False
    # Remove our hooks.d plugins if present
    for sub in ("pre-commit", "pre-push"):
        plugin = hooks_dir / "hooks.d" / sub / "50-agent-mail.py"
        if plugin.exists():
            await asyncio.to_thread(plugin.unlink)
            removed = True
    # Legacy top-level single-file uninstall (pre-chain-runner installs)
    pre_commit = hooks_dir / "pre-commit"
    pre_push = hooks_dir / "pre-push"
    SENTINELS = ("mcp-agent-mail guard hook", "AGENT_NAME environment variable is required.")
    for hook_path in (pre_commit, pre_push):
        if hook_path.exists():
            try:
                content = (await asyncio.to_thread(hook_path.read_text, "utf-8")).strip()
            except Exception:
                content = ""
            # Remove our chain-runner files (leave other hooks intact)
            if "mcp-agent-mail chain-runner" in content or any(s in content for s in SENTINELS):
                await asyncio.to_thread(hook_path.unlink)
                removed = True
    return removed
