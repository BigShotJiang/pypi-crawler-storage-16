__all__ = ["MCPChatBot", "__version__"]
__version__ = "0.1.0"

from .core import MCPChatBot  # noqa: E402