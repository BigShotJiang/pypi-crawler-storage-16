"""Command‑line interface wrappers (Typer)."""

from __future__ import annotations

import asyncio
from typing import Optional

import nest_asyncio  # Claude streaming & Jupyter friendliness
import typer
from rich.console import Console
from rich.markdown import Markdown

from .core import MCPChatBot

nest_asyncio.apply()

app = typer.Typer(add_completion=False, help="🧠 MCP‑ChatBot – Research assistant")
console = Console()


@app.command()
def run(config: str = typer.Option("server_config.json", help="Server config JSON")) -> None:
    """Interactive REPL chat loop."""

    async def _inner() -> None:
        bot = MCPChatBot()
        await bot.connect_all(config)

        console.print("[bold green]\nMCP Chatbot ready! Type 'quit' to exit.[/]")
        try:
            while True:
                user_input: str = console.input("[cyan]❯ ")
                if user_input.lower() in {"quit", "exit"}:
                    break
                answer = await bot.ask(user_input)
                console.print(Markdown(answer))
        finally:
            await bot.close()

    asyncio.run(_inner())


@app.command()
def once(query: str, config: str = "server_config.json") -> None:
    """Send *query* once and exit (good for scripts)."""
    asyncio.run(_once_async(query, config))


async def _once_async(query: str, cfg: str) -> None:
    bot = MCPChatBot()
    await bot.connect_all(cfg)
    try:
        response = await bot.ask(query)
        Console().print(Markdown(response))
    finally:
        await bot.close()