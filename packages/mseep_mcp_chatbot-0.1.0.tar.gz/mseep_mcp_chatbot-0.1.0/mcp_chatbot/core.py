"""Core asynchronous chatbot engine."""

from __future__ import annotations

import asyncio
import json
import os
from contextlib import AsyncExitStack
from typing import Any, Dict, List

from anthropic import Anthropic
from dotenv import load_dotenv
from loguru import logger
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

load_dotenv()

# ---------------------------------------------------------------------------
# Configuration constants – tweak via env vars or default values
# ---------------------------------------------------------------------------
MODEL_NAME           = os.getenv("ANTHROPIC_MODEL", "claude-3-sonnet-20250301")
MAX_TOKENS           = int(os.getenv("MAX_TOKENS", "2024"))
MAX_TOOL_CALL_DEPTH  = 5


class MCPChatBot:
    """High‑level orchestration layer between Claude and MCP servers."""

    def __init__(self) -> None:
        self._anthropic          = Anthropic()
        self._exit_stack         = AsyncExitStack()
        self.available_tools:    List[Dict[str, Any]] = []
        self.available_prompts:  List[Dict[str, Any]] = []
        self._sessions:          Dict[str, ClientSession] = {}

    # ---------------------------------------------------------------------
    # Connection helpers
    # ---------------------------------------------------------------------
    async def _connect_single(self, name: str, cfg: Dict[str, Any]) -> None:
        """Connect to a single MCP server and cache its tools/prompts."""
        try:
            params = StdioServerParameters(**cfg)
            reader, writer = await self._exit_stack.enter_async_context(
                stdio_client(params)
            )
            session = await self._exit_stack.enter_async_context(
                ClientSession(reader, writer)
            )
            await session.initialize()
            logger.success("✓ Connected to server '{}'", name)

            # Tools
            for tool in (await session.list_tools()).tools:
                self._sessions[tool.name] = session
                self.available_tools.append({
                    "name":         tool.name,
                    "description":  tool.description,
                    "input_schema": tool.inputSchema,
                })

            # Prompts
            for prompt in (await session.list_prompts()).prompts:
                self._sessions[prompt.name] = session
                self.available_prompts.append({
                    "name":        prompt.name,
                    "description": prompt.description,
                    "arguments":   prompt.arguments,
                })

            # Resources – map their URIs to the session
            for res in (await session.list_resources()).resources:
                self._sessions[str(res.uri)] = session
        except Exception as exc:  # noqa: BLE001
            logger.error("⚠ Could not connect to server '{}': {}", name, exc)

    async def connect_all(self, cfg_path: str = "server_config.json") -> None:
        """Connect to all MCP servers found in *cfg_path*."""
        with open(cfg_path, "r", encoding="utf-8") as fh:
            servers = json.load(fh).get("mcpServers", {})

        await asyncio.gather(*(self._connect_single(n, c) for n, c in servers.items()))

    async def close(self) -> None:  # noqa: D401
        """Close all network resources gracefully."""
        await self._exit_stack.aclose()

    # ---------------------------------------------------------------------
    # Chat loop and Anthropic interaction
    # ---------------------------------------------------------------------
    async def _anthropic_complete(self, messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Invoke Claude with tool support and return *assistant* content list."""
        response = self._anthropic.messages.create(
            model       = MODEL_NAME,
            max_tokens  = MAX_TOKENS,
            tools       = self.available_tools,
            messages    = messages,
        )
        return response.content

    async def _call_tool(self, tool_name: str, payload: Dict[str, Any]) -> str:
        session = self._sessions.get(tool_name)
        if not session:
            raise RuntimeError(f"Tool '{tool_name}' is not registered.")
        result = await session.call_tool(tool_name, arguments=payload)
        return result.content  # type: ignore[no-any-return]

    async def ask(self, user_query: str) -> str:  # noqa: C901
        """Main entry – process *user_query* through Claude + tools."""
        messages: List[Dict[str, Any]] = [
            {"role": "user", "content": user_query},
        ]
        depth = 0

        while depth < MAX_TOOL_CALL_DEPTH:
            depth += 1
            logger.debug("Anthropic call depth {}", depth)
            assistant_parts = await self._anthropic_complete(messages)

            tool_used = False
            buffer: List[Any] = []
            for part in assistant_parts:
                if part.type == "text":  # plain response from Claude
                    buffer.append(part.text)
                elif part.type == "tool_use":
                    tool_used = True
                    tool_name = part.name
                    logger.info("⚙ Invoking tool: {}", tool_name)

                    try:
                        tool_result = await self._call_tool(tool_name, part.input)
                    except Exception as exc:  # noqa: BLE001
                        logger.exception("Tool '{}' failed: {}", tool_name, exc)
                        tool_result = f"Tool error: {exc}"

                    # Send tool result back to Claude
                    messages.extend([
                        {"role": "assistant", "content": [part]},
                        {
                            "role": "user",
                            "content": [
                                {
                                    "type":        "tool_result",
                                    "tool_use_id": part.id,
                                    "content":     tool_result,
                                }
                            ],
                        },
                    ])

            if not tool_used:
                return "\n".join(buffer).strip()

        return "Maximum tool-call depth reached. Something went wrong."  # safety net