import pytest
from mcp_chatbot.core import MCPChatBot


@pytest.mark.asyncio
async def test_connect_and_close(tmp_path, monkeypatch):
    # Provide a dummy server config
    cfg = tmp_path / "servers.json"
    cfg.write_text('{"mcpServers": {}}')

    bot = MCPChatBot()
    await bot.connect_all(str(cfg))
    await bot.close()