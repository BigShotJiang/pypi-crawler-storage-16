import sys
from . import mcp_client

if __name__ == "__main__":
    sys.exit(mcp_client.main())
