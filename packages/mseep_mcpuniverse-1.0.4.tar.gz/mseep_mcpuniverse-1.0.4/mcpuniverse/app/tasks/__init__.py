TASK_ECHO = "mcpuniverse.app.tasks.echo.EchoTask"
TASK_BENCHMARK = "mcpuniverse.app.tasks.benchmark.Benchmark"