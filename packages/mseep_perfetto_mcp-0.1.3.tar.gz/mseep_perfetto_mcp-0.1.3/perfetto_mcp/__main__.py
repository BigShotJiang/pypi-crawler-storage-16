"""Module entrypoint for `python -m perfetto_mcp`."""

from . import main

if __name__ == "__main__":
    main()
