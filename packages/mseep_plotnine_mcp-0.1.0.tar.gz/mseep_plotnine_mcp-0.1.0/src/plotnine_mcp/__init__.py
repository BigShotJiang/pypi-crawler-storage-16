"""
Plotnine MCP Server - A modular MCP server for creating plotnine visualizations.
"""

__version__ = "0.1.0"
