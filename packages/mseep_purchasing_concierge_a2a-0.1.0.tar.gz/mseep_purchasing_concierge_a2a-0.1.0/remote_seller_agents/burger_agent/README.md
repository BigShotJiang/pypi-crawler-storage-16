# Burger Agent

This is a remote seller agent that built on top of Crew AI.
