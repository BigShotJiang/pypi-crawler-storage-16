"""
CLI entry points for ragex commands.
"""