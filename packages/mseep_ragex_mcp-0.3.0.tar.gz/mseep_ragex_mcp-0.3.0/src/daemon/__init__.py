"""
Socket daemon components.
"""