"""
Command handlers for the socket daemon.
"""