"""
Pure library components with no side effects.
These modules can be safely imported without triggering initialization.
"""