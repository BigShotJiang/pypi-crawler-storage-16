#!/usr/bin/env python3
"""
MCP Code Search Server - A secure ripgrep-based code search server
"""

# Early import debugging - log to syslog before any complex imports that could fail
try:
    import syslog
    import os
    import sys
    syslog.openlog("ragex-mcp-debug", syslog.LOG_PID)
    syslog.syslog(syslog.LOG_INFO, f"MCP: server.py starting, Python path: {sys.path[:3]}")
    syslog.syslog(syslog.LOG_INFO, f"MCP: Working directory: {os.getcwd()}")
    syslog.syslog(syslog.LOG_INFO, f"MCP: RAGEX_MCP_WORKSPACE: {os.environ.get('RAGEX_MCP_WORKSPACE')}")
    syslog.closelog()
except Exception as e:
    # If syslog fails, try stderr (though it might be redirected)
    print(f"Early debug failed: {e}", file=sys.stderr)

import asyncio
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import atexit
from pathlib import Path
from typing import Dict, List, Optional, Any
from datetime import datetime

try:
    from mcp.server import Server, NotificationOptions
    from mcp.server.models import InitializationOptions
    import mcp.server.stdio
    import mcp.types as types
    import syslog
    syslog.openlog("ragex-mcp-debug", syslog.LOG_PID)
    syslog.syslog(syslog.LOG_INFO, "MCP: MCP imports successful")
    syslog.syslog(syslog.LOG_INFO, "🚀 MCP SERVER UPDATED CODE VERSION - DEBUG ENABLED 🚀")
    syslog.closelog()
except Exception as e:
    import syslog
    syslog.openlog("ragex-mcp-debug", syslog.LOG_PID)
    syslog.syslog(syslog.LOG_ERR, f"MCP: MCP import failed: {e}")
    syslog.closelog()
    raise

# Import Tree-sitter enhancer and utilities
try:
    import syslog
    syslog.openlog("ragex-mcp-debug", syslog.LOG_PID)
    syslog.syslog(syslog.LOG_INFO, "MCP: Starting src imports")
    
    from src.tree_sitter_enhancer import TreeSitterEnhancer
    from src.ragex_core.pattern_matcher import PatternMatcher
    from src.ragex_core.project_detection import detect_project_from_cwd
    from src.ragex_core.project_utils import get_chroma_db_path
    from src.ragex_core.reranker import FeatureReranker
    from src.ragex_core.path_mapping import host_to_container_path
    from src.ragex_core.semantic_searcher import SemanticSearcher
    from src.ragex_core.regex_searcher import RegexSearcher
    from src.ragex_core.result_formatters import format_search_results_optimized
    from src.utils import configure_logging, get_logger
    from src.watchdog_monitor import WatchdogMonitor, WATCHDOG_AVAILABLE
    
    syslog.syslog(syslog.LOG_INFO, "MCP: src imports successful")
    syslog.closelog()
except ImportError as e:
    import syslog
    syslog.openlog("ragex-mcp-debug", syslog.LOG_PID)
    syslog.syslog(syslog.LOG_INFO, f"MCP: src import failed, trying relative imports: {e}")
    syslog.closelog()
    
    try:
        from .tree_sitter_enhancer import TreeSitterEnhancer
        from .ragex_core.pattern_matcher import PatternMatcher
        from .ragex_core.project_detection import detect_project_from_cwd
        from .ragex_core.project_utils import get_chroma_db_path
        from .ragex_core.reranker import FeatureReranker
        from .ragex_core.path_mapping import host_to_container_path
        from .ragex_core.semantic_searcher import SemanticSearcher
        from .ragex_core.regex_searcher import RegexSearcher
        from .ragex_core.result_formatters import format_search_results_optimized
        from .utils import configure_logging, get_logger
        try:
            from .watchdog_monitor import WatchdogMonitor, WATCHDOG_AVAILABLE
        except ImportError:
            WATCHDOG_AVAILABLE = False
            WatchdogMonitor = None
            
        syslog.openlog("ragex-mcp-debug", syslog.LOG_PID)
        syslog.syslog(syslog.LOG_INFO, "MCP: relative imports successful")
        syslog.closelog()
    except ImportError as e2:
        syslog.openlog("ragex-mcp-debug", syslog.LOG_PID)
        syslog.syslog(syslog.LOG_ERR, f"MCP: All imports failed: {e2}")
        syslog.closelog()
        raise

# Check if we're in MCP mode (--mcp flag)
is_mcp_mode = '--mcp' in sys.argv

if is_mcp_mode:
    # Configure consistent logging but redirect stderr to protect MCP JSON protocol
    # Use standard logging infrastructure for consistency with daemon logs
    configure_logging()
    logger = get_logger("ragex-mcp")
    
    # Configure MCP server logger to write to container logs like socket daemon
    # Add additional handler to ensure MCP server logs appear in docker logs
    import logging
    
    # Save original stderr before it gets redirected
    _original_stderr = sys.stderr
    
    # Redirect stderr to prevent ANY output except our JSON protocol
    class SilentIO:
        def write(self, text):
            if text and text != '\n':
                logger.debug(f"Suppressed stderr: {text}")
        def flush(self):
            pass
        def isatty(self):
            return False
    
    # Save original stderr for emergencies  
    _original_stderr = sys.stderr
    sys.stderr = SilentIO()
    
    # Now configure MCP server loggers to write to original stderr (docker logs)
    # Create a handler that writes to the original stderr (which goes to docker logs)
    stderr_handler = logging.StreamHandler(_original_stderr)
    stderr_handler.setFormatter(logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    ))
    stderr_handler.setLevel(logging.INFO)
    
    # Add this handler to the MCP logger and related loggers
    mcp_loggers = [
        "ragex-mcp", 
        "regex-searcher", 
        "symbol-searcher", 
        "semantic-searcher"
    ]
    
    for logger_name in mcp_loggers:
        target_logger = logging.getLogger(logger_name)
        target_logger.addHandler(stderr_handler)
        target_logger.setLevel(logging.INFO)
else:
    # Configure logging based on environment
    # Only configure logging if we're the main process, not when imported by socket daemon
    if os.environ.get('RAGEX_DAEMON_INITIALIZED') != '1':
        configure_logging()

    # Get logger for this module
    logger = get_logger("ragex-mcp")

    # Log startup info only if we're the main process
    if os.environ.get('RAGEX_DAEMON_INITIALIZED') != '1':
        logger.info("="*50)
        logger.info("MCP RAGex Server Started")
        logger.info(f"Time: {datetime.now()}")
        logger.info(f"CWD: {os.getcwd()}")
        logger.info(f"MCP_WORKING_DIR: {os.environ.get('MCP_WORKING_DIR', 'Not set')}")
        logger.info(f"Python: {sys.executable}")
        logger.info(f"Arguments: {sys.argv}")
        logger.info("="*50)

        # For MCP mode, we'll get the workspace directory from client paths parameter
        # Don't change working directory to avoid breaking Python imports

# Import RipgrepSearcher and constants
from src.ragex_core.ripgrep_searcher import RipgrepSearcher, ALLOWED_FILE_TYPES, DEFAULT_RESULTS, MAX_RESULTS, RAW_RESULTS_LIMIT


# Initialize server
app = Server("ragex-mcp")

# Removed global mcp_config_error - using direct exception handling instead

# Initialize shared pattern matcher
pattern_matcher = PatternMatcher()

# Initialize watchdog monitor if available and enabled
watchdog_monitor = None
if WATCHDOG_AVAILABLE and os.environ.get("RAGEX_ENABLE_WATCHDOG", "false").lower() in ("true", "1", "yes"):
    try:
        # Access the internal ignore manager from pattern matcher
        ignore_manager = pattern_matcher._ignore_manager
        watchdog_monitor = WatchdogMonitor(ignore_manager, debounce_seconds=1.0)
        
        def on_ignore_change(file_path: str):
            logger.info(f"Detected change to ignore file: {file_path}")
            # The ignore manager will automatically reload
            
        watchdog_monitor.start(on_change_callback=on_ignore_change)
        logger.info("Watchdog monitoring enabled for .rgignore files")
        
        # Register cleanup
        def cleanup_watchdog():
            if watchdog_monitor and watchdog_monitor.is_running():
                logger.info("Stopping watchdog monitor...")
                watchdog_monitor.stop()
                
        atexit.register(cleanup_watchdog)
        
    except Exception as e:
        logger.warning(f"Failed to initialize watchdog monitor: {e}")
        watchdog_monitor = None
else:
    if not WATCHDOG_AVAILABLE:
        logger.debug("Watchdog package not installed - hot reload disabled")
    else:
        logger.debug("Watchdog monitoring disabled (set RAGEX_ENABLE_WATCHDOG=true to enable)")

# Initialize components with same pattern matcher
searcher = RipgrepSearcher(pattern_matcher)

# Initialize Tree-sitter enhancer
try:
    enhancer = TreeSitterEnhancer(pattern_matcher)
    logger.info("Tree-sitter enhancer initialized successfully")
except Exception as e:
    logger.warning(f"Failed to initialize Tree-sitter enhancer: {e}")
    enhancer = None

# Initialize feature reranker
reranker = FeatureReranker()
logger.info("Feature reranker initialized")

# Initialize all search components (eager initialization)
semantic_searcher = None
semantic_available = False
regex_searcher = None
regex_available = False
current_project = None

def translate_mcp_paths_to_container(paths: Optional[List[str]]) -> Optional[List[str]]:
    """
    Translate host paths to container paths for MCP mode.
    
    Args:
        paths: List of host paths from MCP client
        
    Returns:
        List of container paths, or None if paths is None
    """
    if not paths:
        return paths
    
    # Get the host workspace directory (MCP uses RAGEX_MCP_WORKSPACE)
    mcp_workspace = os.environ.get('RAGEX_MCP_WORKSPACE')
    
    if not mcp_workspace:
        # Not in MCP mode, return paths unchanged
        logger.debug("No RAGEX_MCP_WORKSPACE set, skipping path translation")
        return paths
    
    try:
        # Use the existing host_to_container_path function, but pass the MCP workspace
        translated_paths = []
        for path in paths:
            container_path = host_to_container_path(path, workspace_host=mcp_workspace)
            translated_paths.append(container_path)
            logger.debug(f"Path translation: {path} → {container_path}")
        
        logger.info(f"Translated {len(paths)} host paths to container paths")
        return translated_paths
        
    except Exception as e:
        logger.error(f"Failed to translate paths: {e}")
        logger.info(f"Host paths: {paths}")
        logger.info(f"MCP workspace: {mcp_workspace}")
        # Return original paths rather than failing completely
        return paths


def get_workspace_directory(arguments: dict) -> str:
    """
    Determine workspace directory from MCP client paths parameter or environment fallback.
    
    Args:
        arguments: MCP tool call arguments
        
    Returns:
        Resolved workspace directory path
        
    Raises:
        ValueError: If no workspace directory can be determined
    """
    import syslog
    syslog.openlog("ragex-mcp", syslog.LOG_PID)
    
    logger.info(f"🔍 Debugging paths parameter: {json.dumps(arguments.get('paths'), indent=2)}")
    syslog.syslog(syslog.LOG_INFO, f"MCP: get_workspace_directory called with paths={arguments.get('paths')}")
    
    if 'paths' in arguments and arguments['paths']:
        # Use the first path provided by the client as workspace root
        workspace_dir = str(Path(arguments['paths'][0]).resolve())
        logger.info(f"📁 Using workspace directory from MCP client: {workspace_dir}")
        syslog.syslog(syslog.LOG_INFO, f"MCP: Using client paths: {workspace_dir}")
        syslog.closelog()
        return workspace_dir
    else:
        # Try to get workspace directory from environment variable (set by host ragex script)
        env_workspace = os.environ.get('RAGEX_MCP_WORKSPACE')
        logger.info(f"🔍 Checking environment RAGEX_MCP_WORKSPACE: {env_workspace}")
        syslog.syslog(syslog.LOG_INFO, f"MCP: Environment RAGEX_MCP_WORKSPACE={env_workspace}")
        
        if env_workspace:
            # Host workspace path is mounted as /workspace in container
            workspace_dir = "/workspace"
            logger.info(f"📁 Using container workspace directory (host path {env_workspace} mounted as /workspace)")
            syslog.syslog(syslog.LOG_INFO, f"MCP: Using env workspace: {env_workspace} → {workspace_dir}")
            syslog.closelog()
            return workspace_dir
        else:
            # No paths provided and no environment fallback - this is a fatal configuration error
            logger.error("❌ FATAL: No workspace directory available")
            logger.error(f"  Available arguments: {json.dumps(list(arguments.keys()))}")
            logger.error("  MCP client should provide 'paths' parameter OR host should set RAGEX_MCP_WORKSPACE")
            logger.error("  The MCP server cannot function without a valid workspace path to search")
            
            syslog.syslog(syslog.LOG_ERR, f"MCP: FATAL - No workspace directory, args={list(arguments.keys())}")
            syslog.closelog()
            
            raise ValueError(
                "MCP server cannot function without workspace directory. "
                "MCP client should provide 'paths' parameter in search requests OR "
                "host ragex script should set RAGEX_MCP_WORKSPACE environment variable. "
                f"Available arguments: {list(arguments.keys())}"
            )

def initialize_all_searchers():
    """Initialize all searchers with project auto-detection (eager initialization)"""
    global semantic_searcher, semantic_available, regex_searcher, regex_available, current_project
    
    # Add high-visibility startup logging
    logger.info("🚀 MCP SERVER: Starting initialization of unified searcher architecture")
    
    # Also write to a debug file to ensure we can see this
    try:
        with open("/tmp/mcp_debug.log", "a") as f:
            f.write(f"{datetime.now().isoformat()} - MCP SERVER: Starting initialization of unified searcher architecture\n")
            f.flush()
    except Exception:
        pass
    
    try:
        # Import semantic search modules
        try:
            from src.ragex_core.embedding_manager import EmbeddingManager
            from src.ragex_core.vector_store import CodeVectorStore
            from src.indexer import CodeIndexer
        except ImportError:
            # Try relative imports as fallback
            from .ragex_core.embedding_manager import EmbeddingManager
            from .ragex_core.vector_store import CodeVectorStore
            from .indexer import CodeIndexer
        
        # Auto-detect project from workspace directory (MCP environment variable) or current directory
        workspace_dir = os.environ.get('RAGEX_MCP_WORKSPACE')
        
        # Debug log to syslog what we received
        import syslog
        syslog.openlog("ragex-mcp", syslog.LOG_PID)
        syslog.syslog(syslog.LOG_INFO, f"MCP: initialize_semantic_search called, RAGEX_MCP_WORKSPACE={workspace_dir}")
        
        if workspace_dir:
            # Use the workspace directory passed by host ragex script  
            # Since we're in container, translate to /workspace mount point
            search_dir = "/workspace"
            logger.info(f"🔍 Detecting project from MCP workspace: {workspace_dir} → {search_dir}")
            syslog.syslog(syslog.LOG_INFO, f"MCP: Using workspace dir {workspace_dir} → {search_dir}")
        else:
            # Fallback to current working directory
            search_dir = os.getcwd()
            logger.info(f"🔍 Detecting project from CWD: {search_dir}")
            syslog.syslog(syslog.LOG_INFO, f"MCP: No workspace dir, using CWD: {search_dir}")
        
        # Temporarily change directory for project detection
        original_cwd = os.getcwd()
        try:
            os.chdir(search_dir)
            project_info = detect_project_from_cwd()
            
            if project_info:
                syslog.syslog(syslog.LOG_INFO, f"MCP: Project detected: {project_info['project_name']}")
            else:
                syslog.syslog(syslog.LOG_WARNING, f"MCP: No project found in {search_dir}")
        finally:
            os.chdir(original_cwd)
            syslog.closelog()
        if not project_info:
            logger.error("✗ No indexed project found in current directory")
            logger.error("  Run 'ragex index .' first to enable semantic search")
            return False
        
        current_project = project_info
        
        # Set workspace path to /workspace (container mount point) when using MCP
        if workspace_dir:
            current_project['workspace_path'] = '/workspace'
        
        logger.info(f"✓ Detected project: {project_info['project_name']} (ID: {project_info['project_id']})")
        logger.info(f"  Project data dir: {project_info['project_data_dir']}")
        logger.info(f"  Workspace path: {current_project.get('workspace_path', 'Not set')}")
        
        # Get ChromaDB path for this project
        chroma_path = get_chroma_db_path(project_info['project_data_dir'])
        
        if not chroma_path.exists():
            logger.warning(f"✗ ChromaDB not found at: {chroma_path}")
            logger.info("  Run: ragex index .")
            return False
        
        # Initialize all three searcher types with project context
        workspace_path = current_project['workspace_path']
        logger.info(f"🔧 Initializing all searchers with project context:")
        logger.info(f"  Project: {current_project['project_name']} (ID: {current_project['project_id']})")
        logger.info(f"  Workspace: {workspace_path}")
        logger.info(f"  Data dir: {current_project['project_data_dir']}")
        
        # Initialize semantic searcher
        try:
            semantic_searcher = SemanticSearcher(current_project, workspace_path)
            semantic_available = True
            logger.info("✓ SemanticSearcher initialized successfully")
            print("✓ MCP SERVER: SemanticSearcher initialized successfully", flush=True)
        except Exception as e:
            logger.error(f"✗ Failed to initialize SemanticSearcher: {e}")
            logger.exception("SemanticSearcher error:")
            print(f"✗ MCP SERVER: Failed to initialize SemanticSearcher: {e}", flush=True)
            semantic_available = False
        
        # Initialize regex searcher
        try:
            regex_searcher = RegexSearcher(current_project, workspace_path)
            regex_available = True
            logger.info("✓ RegexSearcher initialized successfully")
        except Exception as e:
            logger.error(f"✗ Failed to initialize RegexSearcher: {e}")
            logger.exception("RegexSearcher error:")
            regex_available = False
        
        # Log summary
        available_searchers = []
        if semantic_available:
            available_searchers.append("semantic")
        if symbol_available:
            available_searchers.append("symbol") 
        if regex_available:
            available_searchers.append("regex")
        
        if available_searchers:
            logger.info(f"🎉 Searcher initialization complete! Available: {', '.join(available_searchers)}")
            return True
        else:
            logger.error("❌ No searchers could be initialized")
            return False
            
    except ImportError as e:
        logger.warning(f"Semantic search dependencies not available: {e}")
        return False
    except Exception as e:
        logger.warning(f"Failed to initialize semantic search: {e}")
        return False

# Initialize all searchers on startup
initialize_all_searchers()


# Search mode detection and enhancement
def detect_query_type(query: str) -> str:
    """Detect the best search mode based on query characteristics"""
    
    # Check for environment variable and configuration patterns - use semantic
    env_config_indicators = [
        r'\b(env|environ|environment)\s+(var|variable)',
        r'\b(config|configuration|setting)',
        r'\bos\.environ',
        r'\bgetenv\b',
        r'^[A-Z][A-Z_]+[A-Z]$',           # CONSTANT_NAME pattern
        r'\b(API_KEY|DATABASE_URL|SECRET|TOKEN|PASSWORD)\b',
    ]
    
    if any(re.search(pattern, query, re.IGNORECASE) for pattern in env_config_indicators):
        return "semantic"  # Semantic search works best for env vars
    
    # Check for import patterns - use semantic
    import_indicators = [
        r'\b(import|imports|importing|uses?|using)\s+\w+',
        r'\bfrom\s+\w+\s+import',
        r'\b(files?|modules?)\s+(that\s+)?(use|import|require)',
        r'\b(pandas|numpy|requests|flask|django)\b',  # Common libraries
    ]
    
    if any(re.search(pattern, query, re.IGNORECASE) for pattern in import_indicators):
        return "semantic"  # Semantic search works best for imports
    
    # Check for regex patterns
    regex_indicators = [
        r'\.',      # literal dots
        r'\*',      # wildcards  
        r'\+',      # plus quantifier
        r'\?',      # optional quantifier
        r'\[.*\]',  # character classes
        r'\{.*\}',  # quantifiers
        r'\^',      # start anchor
        r'\$',      # end anchor
        r'\|',      # alternation
        r'\\[a-z]', # escape sequences
    ]
    
    if any(re.search(pattern, query) for pattern in regex_indicators):
        return "regex"
    
    # Check for simple identifier-like queries - treat as semantic now
    simple_identifier_indicators = [
        r'^[a-zA-Z_][a-zA-Z0-9_]*$',  # Simple identifier
        r'^class\s+\w+',              # "class MyClass"
        r'^def\s+\w+',                # "def function_name"
        r'^function\s+\w+',           # "function myFunc"
        r'^\w+\s*\(',                 # "funcName("
    ]
    
    # These used to be symbol searches, now route to semantic
    if any(re.search(pattern, query, re.IGNORECASE) for pattern in simple_identifier_indicators):
        return "semantic"
    
    # Check for natural language queries
    natural_language_indicators = [
        r'\b(functions?|methods?|classes?)\s+(that|which|for)\b',
        r'\b(how to|where|what|when|why)\b',
        r'\b(handles?|processes?|manages?|creates?|validates?)\b',
        r'\b(error|exception|authentication|database|queue|file)\b',
        r'\s(and|or|with|for|in|on|at|by)\s',
        r'\b(submit|send|process|handle|create|delete|update)\b',
    ]
    
    if any(re.search(pattern, query, re.IGNORECASE) for pattern in natural_language_indicators):
        return "semantic"
    
    # Default fallback logic
    if len(query.split()) >= 3:  # Multi-word queries likely semantic
        return "semantic"
    elif query.isidentifier():   # Valid identifier -> symbol search
        return "symbol"
    else:                        # Everything else -> regex
        return "regex"


def enhance_query_for_mode(query: str, mode: str) -> str:
    """Enhance query based on the selected mode"""
    
    if mode == "semantic":
        # Add context for better semantic matching
        enhanced = query
        
        # Add programming context
        if not any(word in query.lower() for word in ["function", "class", "method", "code"]):
            enhanced = f"code {enhanced}"
        
        # Expand abbreviations
        abbreviations = {
            "auth": "authentication",
            "db": "database", 
            "config": "configuration",
            "util": "utility",
            "impl": "implementation"
        }
        
        for abbr, full in abbreviations.items():
            enhanced = re.sub(rf'\b{abbr}\b', full, enhanced, flags=re.IGNORECASE)
        
        return enhanced
    
    elif mode == "regex":
        # Escape special chars if it doesn't look like intentional regex
        if not any(char in query for char in r'.*+?[]{}()^$|\\'):
            return re.escape(query)
        return query
    
    return query


def get_fallback_chain(preferred_mode: str, query: str) -> List[str]:
    """Get intelligent fallback chain based on preferred mode"""
    
    if preferred_mode == "semantic":
        # Don't fallback to regex - semantic queries don't work in regex
        return []  # No fallbacks
    
    elif preferred_mode == "regex":
        # Regex failed -> try semantic (maybe they meant natural language)
        return ["semantic"]
    
    return []


def generate_search_guidance(query: str, mode: str) -> Dict:
    """Generate helpful guidance when search fails"""
    
    guidance = {
        "message": f"No results found for '{query}' in {mode} mode.",
        "suggestions": []
    }
    
    if mode == "semantic":
        guidance["suggestions"] = [
            f"Try regex mode for patterns: search_code('{query}.*', mode='regex')",
            "Make query more specific: 'functions that handle file upload validation'",
            "Try broader terms: 'file processing code' or 'queue management'"
        ]
    
    elif mode == "regex":
        guidance["suggestions"] = [
            f"Try semantic mode: search_code('code that handles {query}', mode='semantic')",
            "Simplify pattern - remove some wildcards",
            "Try case-insensitive search",
            "Check regex syntax"
        ]
    
    return guidance


@app.list_tools()
async def handle_list_tools() -> list[types.Tool]:
    """List available tools"""
    return [
        types.Tool(
            name="search_code",
            description="Intelligent code search with automatic mode detection. Use 'semantic' mode when searching for concepts or functionality. Use 'symbol' or 'regex' modes when you know specific names or patterns.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search query (natural language for semantic search, exact names for symbol search, or patterns for regex search)",
                    },
                    "mode": {
                        "type": "string",
                        "enum": ["auto", "semantic", "regex"],
                        "description": "Search mode - 'auto' (default): automatically detects best mode. 'semantic': natural language search for concepts/functionality. 'regex': pattern matching with regular expressions",
                        "default": "auto"
                    },
                    "file_types": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": f"File types to search in. Options: {', '.join(sorted(ALLOWED_FILE_TYPES))}",
                    },
                    "paths": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Paths to search in (relative to current directory)",
                    },
                    "limit": {
                        "type": "integer",
                        "description": f"Maximum results to return (1-{MAX_RESULTS}, default: {DEFAULT_RESULTS})",
                        "minimum": 1,
                        "maximum": MAX_RESULTS,
                        "default": DEFAULT_RESULTS
                    },
                    "case_sensitive": {
                        "type": "boolean",
                        "description": "Whether search should be case sensitive (default: false)",
                        "default": False
                    },
                    "include_symbols": {
                        "type": "boolean",
                        "description": "Include symbol context (function/class info) in results (default: false)",
                        "default": False
                    },
                    "similarity_threshold": {
                        "type": "number",
                        "description": "Minimum similarity score for semantic search results (0.0-1.0, default: 0.25)",
                        "minimum": 0.0,
                        "maximum": 1.0,
                        "default": 0.25
                    },
                    "exclude_patterns": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Additional patterns to exclude (rgignore syntax)",
                    },
                    "respect_rgignore": {
                        "type": "boolean",
                        "description": "Whether to respect .rgignore files (default: true)",
                        "default": True
                    },
                    "format": {
                        "type": "string",
                        "enum": ["navigation", "raw"],
                        "description": "Output format: 'navigation' for human-friendly file grouping (default), 'raw' for simple file:line format",
                        "default": "navigation"
                    },
                    "detail_level": {
                        "type": "string",
                        "enum": ["minimal", "compact", "rich"],
                        "description": "Output detail level: 'minimal' (~2K tokens, CLI-like), 'compact' (~5K tokens, balanced), 'rich' (~15K tokens, full context)",
                        "default": "minimal"
                    },
                },
                "required": ["query"],
            },
        ),
        types.Tool(
            name="get_search_capabilities",
            description="Get detailed information about available search modes and current capabilities",
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
        types.Tool(
            name="search_code_simple", 
            description="Simple search interface - just provide a query and let the system handle everything",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Your search query in any format",
                    },
                    "detail_level": {
                        "type": "string",
                        "enum": ["minimal", "compact", "rich"],
                        "description": "Output detail level: 'minimal' (~2K tokens, CLI-like), 'compact' (~5K tokens, balanced), 'rich' (~15K tokens, full context)",
                        "default": "minimal"
                    },
                },
                "required": ["query"],
            },
        ),
        types.Tool(
            name="get_watchdog_status",
            description="Get the status of the watchdog file monitor for .rgignore hot reloading",
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
    ]

@app.call_tool()
async def handle_call_tool(
    name: str, arguments: dict | None
) -> list[types.TextContent | types.ImageContent | types.EmbeddedResource]:
    """Handle tool calls"""
    
    if not arguments:
        arguments = {}
    
    # Log all MCP client connection parameters
    logger.info(f"🔗 MCP Tool Call: {name}")
    logger.info(f"  Arguments: {json.dumps(arguments, indent=2)}")
    logger.info(f"  CWD: {os.getcwd()}")
    
    # Error handling is now done directly at the point of failure
    
    # Handle original search_code tool
    if name == "search_code":
        # Determine workspace directory from MCP client paths parameter or environment
        workspace_dir = get_workspace_directory(arguments)
        
        # Check if this is the new intelligent search (has 'query' param) or old search (has 'pattern' param)
        if 'query' in arguments:
            # New intelligent search
            return await handle_intelligent_search(
                query=arguments['query'],
                paths=[workspace_dir],  # Use resolved workspace directory
                mode=arguments.get('mode', 'auto'),
                file_types=arguments.get('file_types'),
                limit=arguments.get('limit', DEFAULT_RESULTS),
                case_sensitive=arguments.get('case_sensitive', False),
                include_symbols=arguments.get('include_symbols', False),
                similarity_threshold=arguments.get('similarity_threshold', 0.25),
                format=arguments.get('format', 'navigation'),
                detail_level=arguments.get('detail_level', 'minimal')
            )
        elif 'pattern' in arguments:
            # Old search - convert pattern to query and use intelligent search
            pattern = arguments.get('pattern')
            if not pattern:
                raise ValueError("Missing pattern argument")
            
            # Convert old pattern-based search to intelligent search
            logger.info(f"🔄 CONVERTING pattern search to intelligent search: '{pattern}'")
            return await handle_intelligent_search(
                query=pattern,
                paths=[workspace_dir],  # Use resolved workspace directory
                mode='auto',  # Let auto-detection handle it
                file_types=arguments.get('file_types'),
                limit=arguments.get('limit', DEFAULT_RESULTS),
                case_sensitive=arguments.get('case_sensitive', False),
                include_symbols=arguments.get('include_symbols', False),
                similarity_threshold=arguments.get('similarity_threshold', 0.25),
                format=arguments.get('format', 'navigation')
            )
        else:
            raise ValueError("Missing query or pattern argument")
    
    # Handle new intelligent search tools
    elif name == "get_search_capabilities":
        return await handle_search_capabilities()
    
    elif name == "search_code_simple":
        # Determine workspace directory from MCP client paths parameter or environment
        workspace_dir = get_workspace_directory(arguments)
        
        query = arguments.get('query')
        if not query:
            raise ValueError("Missing query argument")
        return await handle_intelligent_search(
            query, 
            paths=[workspace_dir], 
            mode="auto", 
            detail_level=arguments.get('detail_level', 'minimal')
        )
    
    elif name == "get_watchdog_status":
        return await handle_watchdog_status()
    
    else:
        raise ValueError(f"Unknown tool: {name}")
    
    # This should never be reached due to the routing above
    raise ValueError("Unexpected code path")


# Helper functions for intelligent search
async def handle_intelligent_search(
    query: str,
    paths: List[str],  # Required - no dangerous defaulting to cwd
    mode: str = "auto",
    file_types: Optional[List[str]] = None,
    limit: int = DEFAULT_RESULTS,
    case_sensitive: bool = False,
    include_symbols: bool = False,  # For compatibility with Claude Code
    similarity_threshold: float = 0.25,
    format: str = "navigation",
    detail_level: str = "minimal",  # NEW: Control response size
    **kwargs  # Catch any other unexpected parameters
) -> List[types.TextContent]:
    """
    Intelligent code search with automatic mode detection and fallback.
    """
    # Add search execution logging
    logger.info(f"🔍 MCP SEARCH STARTED: query='{query}', mode='{mode}', limit={limit}")
    
    # Also write to debug file
    try:
        with open("/tmp/mcp_debug.log", "a") as f:
            f.write(f"{datetime.now().isoformat()} - MCP SEARCH STARTED: query='{query}', mode='{mode}', limit={limit}\n")
            f.flush()
    except Exception:
        pass
    
    # Translate host paths to container paths for MCP mode
    container_paths = translate_mcp_paths_to_container(paths)
    if container_paths != paths:
        logger.info(f"🔄 Translated {len(paths)} host paths to container paths")
        logger.info(f"  Original paths: {paths}")
        logger.info(f"  Translated paths: {container_paths}")
        paths = container_paths
    
    # Detect or validate mode
    if mode == "auto":
        detected_mode = detect_query_type(query)
        logger.info(f"🔍 AUTO-DETECTED → {detected_mode.upper()} search: '{query}'")
    else:
        detected_mode = mode
        logger.info(f"🔍 EXPLICIT → {detected_mode.upper()} search: '{query}'")
    
    # Check searcher availability for requested mode
    if detected_mode == "semantic" and not semantic_available:
        error_msg = "Semantic search is not available. This usually means:\n" \
                   "1. Project is not indexed - run 'ragex index .' first\n" \
                   "2. ChromaDB index is missing or corrupted\n" \
                   "3. Embedding dependencies are not installed\n" \
                   "Try using 'regex' mode instead for pattern-based search."
        logger.error(f"❌ SEMANTIC search failed: {error_msg}")
        raise ValueError(f"Semantic search unavailable: {error_msg}")
    elif detected_mode == "regex" and not regex_available:
        error_msg = "Regex search requested but not available. Check ripgrep and workspace initialization."
        logger.error(f"❌ REGEX search failed: {error_msg}")
        raise ValueError(f"Regex search unavailable: {error_msg}")
    
    # Enhance query for the selected mode
    enhanced_query = enhance_query_for_mode(query, detected_mode)
    if enhanced_query != query:
        logger.info(f"Enhanced query: '{query}' → '{enhanced_query}'")
    
    # Execute search using new searcher instances
    if detected_mode == "semantic":
        logger.info(f"🧠 EXECUTING semantic search with new SemanticSearcher")
        result = await semantic_searcher.search(
            query=enhanced_query,
            limit=limit,
            file_types=file_types,
            similarity_threshold=similarity_threshold
        )
    else:  # regex mode
        logger.info(f"⚡ EXECUTING regex search with new RegexSearcher")
        result = await regex_searcher.search(
            query=enhanced_query,
            limit=limit,
            paths=paths,  # RegexSearcher handles string paths internally
            file_types=file_types,
            case_sensitive=case_sensitive
        )
    
    # Add metadata about search execution
    result.update({
        "original_query": query,
        "enhanced_query": enhanced_query,
        "requested_mode": mode,
        "detected_mode": detected_mode,
        "search_mode": detected_mode,
        "fallback_used": False
    })
    
    # Log search completion
    total_matches = result.get("total_matches", 0)
    success = result.get("success", False)
    logger.info(f"✅ MCP SEARCH COMPLETED: {detected_mode} search for '{query}' → {total_matches} matches (success={success})")
    
    # Format result using appropriate detail level for token efficiency
    formatted_text = format_search_results_optimized(result, detail_level=detail_level, max_tokens=20000)
    return [types.TextContent(type="text", text=formatted_text)]


async def handle_watchdog_status() -> List[types.TextContent]:
    """Get watchdog monitor status"""
    
    logger.info("🔍 Watchdog status requested")
    
    status_lines = ["# Watchdog Monitor Status\n"]
    
    # Check if watchdog is available
    if not WATCHDOG_AVAILABLE:
        status_lines.append("❌ **Watchdog not available**: Package not installed")
        status_lines.append("   Install with: `pip install watchdog` or `uv pip install watchdog`")
        return [types.TextContent(type="text", text="\n".join(status_lines))]
    
    # Check if watchdog is enabled
    watchdog_enabled = os.environ.get("RAGEX_ENABLE_WATCHDOG", "false").lower() in ("true", "1", "yes")
    if not watchdog_enabled:
        status_lines.append("⚠️  **Watchdog disabled**: Not enabled via environment variable")
        status_lines.append("   Enable with: `export RAGEX_ENABLE_WATCHDOG=true`")
        return [types.TextContent(type="text", text="\n".join(status_lines))]
    
    # Check if monitor is running
    if watchdog_monitor and watchdog_monitor.is_running():
        status_lines.append("✅ **Watchdog active**: Monitoring for .rgignore changes")
        status_lines.append(f"   Debounce period: {watchdog_monitor.debounce_seconds}s")
        
        # Get watched paths
        watched_paths = watchdog_monitor.get_watched_paths()
        status_lines.append(f"\n📁 **Watched directories** ({len(watched_paths)}):")
        for path in watched_paths:
            status_lines.append(f"   - {path}")
            
        # Get ignore files being monitored
        ignore_files = pattern_matcher._ignore_manager.get_ignore_files()
        status_lines.append(f"\n📄 **Active .rgignore files** ({len(ignore_files)}):")
        for file in ignore_files:
            status_lines.append(f"   - {file}")
            
    else:
        status_lines.append("❌ **Watchdog not running**: Failed to initialize or stopped")
        
    # Add configuration info
    status_lines.append("\n## Configuration")
    status_lines.append(f"- Ignore filename: `{pattern_matcher._ignore_manager.ignore_filename}`")
    status_lines.append(f"- Root path: `{pattern_matcher._ignore_manager.root_path}`")
    status_lines.append(f"- Multi-level support: ✅ Enabled")
    status_lines.append(f"- Hot reload: {'✅ Active' if watchdog_monitor and watchdog_monitor.is_running() else '❌ Inactive'}")
    
    return [types.TextContent(type="text", text="\n".join(status_lines))]


async def handle_search_capabilities() -> List[types.TextContent]:
    """Get detailed information about available search capabilities"""
    
    logger.info("📊 Search capabilities requested")
    
    # Check semantic search status
    semantic_status = {
        "available": semantic_available,
        "reason": "Index found" if semantic_available else "No index found - run build_semantic_index.py"
    }
    
    if semantic_available:
        try:
            stats = semantic_searcher['vector_store'].get_statistics()
            semantic_status.update({
                "symbols_indexed": stats.get('total_symbols', 0),
                "languages": list(stats.get('languages', {}).keys()),
                "index_size_mb": stats.get('index_size_mb', 0)
            })
        except Exception as e:
            semantic_status["error"] = str(e)
    
    capabilities = {
        "available_modes": {
            "regex": {
                "available": True,
                "description": "Fast exact pattern matching with ripgrep",
                "best_for": [
                    "Known exact patterns",
                    "Wildcards and regex expressions", 
                    "Case-sensitive searches",
                    "File name patterns"
                ],
                "examples": [
                    "handleError.*Exception",
                    "class.*User.*{",
                    "def.*validate.*:",
                    "*.py"
                ]
            },
            "symbol": {
                "available": True,
                "description": "Language-aware symbol search using Tree-sitter",
                "best_for": [
                    "Exact function/class names",
                    "Method names",
                    "Variable names",
                    "When you know the identifier"
                ],
                "examples": [
                    "DatabaseConnection",
                    "submitToQueue", 
                    "UserAuthService",
                    "validateInput"
                ]
            },
            "semantic": {
                "available": semantic_status["available"],
                "description": "Natural language search using embeddings",
                "best_for": [
                    "Conceptual searches",
                    "Finding related functionality",
                    "When you know what it does, not what it's called",
                    "Exploring unfamiliar codebase"
                ],
                "examples": [
                    "functions that handle user authentication",
                    "error handling for database connections",
                    "code that processes uploaded files",
                    "validation logic for user input"
                ],
                "status": semantic_status
            }
        },
        "auto_detection": {
            "enabled": True,
            "description": "Automatically chooses the best search mode",
            "fallback_chain": "Primary mode → fallback modes if no results"
        },
        "recommendations": {
            "unknown_exact_name": "Use semantic mode: 'functions that handle...'",
            "know_exact_name": "Use symbol mode: 'MyClassName'",
            "know_pattern": "Use regex mode: 'handle.*Error'",
            "exploring_codebase": "Use semantic mode with broad queries",
            "debugging_specific_issue": "Use regex mode with error patterns"
        }
    }
    
    import json
    response_text = f"# Search Capabilities\n\n```json\n{json.dumps(capabilities, indent=2)}\n```"
    return [types.TextContent(type="text", text=response_text)]


async def handle_simple_search(query: str) -> List[types.TextContent]:
    """Simple code search - auto-detects best mode and searches"""
    logger.info(f"🔍 Simple search requested: '{query}'")
    return await handle_intelligent_search(query, mode="auto")


# Helper functions for new search modes
async def execute_semantic_search(query: str, file_types: Optional[List[str]], paths: Optional[List[str]], limit: int, similarity_threshold: float) -> Dict:
    """Execute semantic search using embeddings"""
    
    # Check if semantic search is available
    if not semantic_available or not semantic_searcher:
        error_msg = "Semantic search is not available. "
        error_msg += "ChromaDB index may not be found or dependencies missing. "
        error_msg += "Check /tmp/mcp_ragex.log for initialization details."
        logger.error(error_msg)
        return {
            "success": False,
            "error": error_msg,
            "pattern": query,
            "total_matches": 0,
            "matches": [],
            "semantic_unavailable": True
        }
    
    try:
        # Create query embedding
        logger.info(f"Creating embedding for query: '{query}'")
        query_embedding = semantic_searcher['embedder'].embed_text(query)
        logger.info(f"Query embedding shape: {query_embedding.shape}, first 5 values: {query_embedding[:5]}")
        
        # Search vector store
        where_filter = {}
        if file_types:
            where_filter["language"] = {"$in": file_types}
            logger.info(f"Filtering by file types: {file_types}")
        
        logger.info(f"Searching vector store with limit={limit}, where={where_filter}")
        results = semantic_searcher['vector_store'].search(
            query_embedding=query_embedding,
            limit=limit,
            where=where_filter if where_filter else None
        )
        logger.info(f"Raw search returned {len(results.get('results', []))} results")
        
        # Convert to standard format
        matches = []
        logger.info(f"Filtering results with similarity_threshold={similarity_threshold} (distance <= {1.0 - similarity_threshold})")
        for i, result in enumerate(results["results"]):
            distance = result["distance"]
            similarity = 1.0 - distance
            if i < 5:  # Log first 5 for debugging
                logger.info(f"  Result {i}: distance={distance:.4f}, similarity={similarity:.4f}, file={result['metadata']['file']}, name={result['metadata']['name']}")
            
            if distance <= (1.0 - similarity_threshold):  # Convert similarity to distance
                matches.append({
                    "file": result["metadata"]["file"],
                    "line_number": result["metadata"]["line"],
                    "line": result["code"][:100] + "..." if len(result["code"]) > 100 else result["code"],
                    "similarity": similarity,
                    "type": result["metadata"].get("type", "unknown"),
                    "name": result["metadata"].get("name", ""),
                    "code": result.get("code", ""),
                    "docstring": result["metadata"].get("docstring", ""),
                    "signature": result["metadata"].get("signature", "")
                })
        
        # Apply feature-based re-ranking to improve result quality
        if matches:
            logger.info(f"Before reranking: Top 3 results by similarity: {[(m.get('name', 'unnamed'), m['similarity']) for m in matches[:3]]}")
            matches = reranker.rerank(query, matches, top_k=limit)
            logger.info(f"After reranking: Top 3 results by reranked_score: {[(m.get('name', 'unnamed'), m.get('reranked_score', 'no-score')) for m in matches[:3]]}")
            logger.info(f"Re-ranking completed, returning top {len(matches)} results")
        
        logger.info(f"Semantic search completed: found {len(matches)} matches for '{query}'")
        
        return {
            "success": True,
            "pattern": query,
            "total_matches": len(matches),
            "matches": matches,
            "truncated": False
        }
        
    except Exception as e:
        logger.error(f"Semantic search failed: {e}")
        logger.exception("Full traceback:")
        return {
            "success": False,
            "error": str(e),
            "pattern": query,
            "total_matches": 0,
            "matches": []
        }


async def execute_symbol_search(query: str, file_types: Optional[List[str]], paths: Optional[List[str]], limit: int) -> Dict:
    """Execute symbol search using Tree-sitter"""
    # For now, use enhanced ripgrep search
    # This could be enhanced to use the Tree-sitter enhancer directly
    # Convert string paths to Path objects for ripgrep searcher
    path_objects = [Path(p) for p in paths] if paths else None
    return await searcher.search(
        pattern=query,
        file_types=file_types,
        paths=path_objects,
        limit=limit,
        case_sensitive=False
    )


async def format_search_results(result: Dict, limit: int, format: str) -> List[types.TextContent]:
    """Format search results for display"""
    if format == "raw":
        response_text = ""
        if result.get("matches"):
            for match in result["matches"]:
                response_text += f"{match['file']}:{match['line_number']}\n"
        else:
            response_text = "No matches found."
        return [types.TextContent(type="text", text=response_text)]
    
    # Navigation format - reuse existing logic
    matches_by_file = {}
    for match in result.get("matches", []):
        file_path = match["file"]
        if file_path not in matches_by_file:
            matches_by_file[file_path] = []
        matches_by_file[file_path].append(match)
    
    # Build response with file-centric format
    response_text = f"## Search Results: '{result['pattern']}'\n\n"
    response_text += f"**Summary**: {result['total_matches']} matches in {len(matches_by_file)} files\n\n"
    
    # Add search mode info
    if "search_mode" in result:
        response_text += f"**Search mode**: {result['search_mode']}\n\n"
    
    if matches_by_file:
        response_text += "### Files with matches:\n\n"
        
        # List all files first for quick navigation
        for file_path in sorted(matches_by_file.keys()):
            match_count = len(matches_by_file[file_path])
            response_text += f"- `{file_path}` ({match_count} match{'es' if match_count > 1 else ''})\n"
        
        response_text += "\n### Match details:\n\n"
        
        # Then show details grouped by file
        for file_path in sorted(matches_by_file.keys()):
            matches = matches_by_file[file_path]
            response_text += f"#### {file_path}\n"
            
            for match in matches:
                line_num = match['line_number']
                line_preview = match['line'].strip()
                
                # Truncate long lines
                if len(line_preview) > 80:
                    line_preview = line_preview[:77] + "..."
                
                response_text += f"- Line {line_num}: `{line_preview}`\n"
                
                # Add similarity for semantic search
                if "similarity" in match:
                    response_text += f"  Similarity: {match['similarity']:.2f}\n"
            
            response_text += "\n"
        
        if result.get("truncated"):
            response_text += f"*Note: Results truncated to {limit} matches*\n"
    else:
        response_text += "No matches found.\n"
        
        # Add debugging info if semantic search was attempted but failed
        if result.get("search_mode") == "semantic" and result.get("requested_mode") == "semantic":
            response_text += "\n**Debugging info**: Semantic search was attempted but may have failed.\n"
            response_text += "Check /tmp/mcp_ragex.log for details about ChromaDB initialization.\n"
        
        # Show error if semantic search was unavailable
        if result.get("semantic_unavailable"):
            response_text += "\n⚠️ **Semantic Search Unavailable**\n"
            response_text += "The ChromaDB index could not be found. Please ensure:\n"
            response_text += "1. You have indexed the project: `ragex index .`\n"
            response_text += "2. You are running from within an indexed project directory\n"
            response_text += "\nFalling back to regex search instead.\n"
    
    return [types.TextContent(type="text", text=response_text)]


async def main():
    """Run the MCP server"""
    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        await app.run(
            read_stream,
            write_stream,
            InitializationOptions(
                server_name="ragex-mcp",
                server_version="0.1.0",
                capabilities=app.get_capabilities(
                    notification_options=NotificationOptions(),
                    experimental_capabilities={},
                ),
            ),
        )

if __name__ == "__main__":
    asyncio.run(main())
