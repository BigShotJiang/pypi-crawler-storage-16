"""Experiment CLI for GEPA optimization with MLflow tracking."""

__version__ = "1.0.0"
