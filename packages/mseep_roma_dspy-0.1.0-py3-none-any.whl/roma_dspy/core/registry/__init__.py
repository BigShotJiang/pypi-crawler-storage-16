"""Registry module for managing agent instances."""

from .agent_registry import AgentRegistry

__all__ = ["AgentRegistry"]
