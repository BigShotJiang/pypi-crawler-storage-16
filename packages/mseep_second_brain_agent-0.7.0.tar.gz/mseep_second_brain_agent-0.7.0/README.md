[![](https://img.shields.io/endpoint?style=plastic&url=https%3A%2F%2Fosstrack.io%2Fjson%2Ffreshness%2Fgithub%2Fflepied%2Fsecond-brain-agent%2Fmain)](https://osstrack.io/freshness/github/flepied/second-brain-agent/main)<br/>[![](https://img.shields.io/badge/Incubated_by-100.builders-9146ff?logo=gamejolt&logoColor=white&labelColor=464646&style=for-the-badge)](https://app.100.builders/directory)[![](https://img.shields.io/badge/Official_Selection-Artizen_Season_3-1acc6c?logo=image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHdpZHRoPSc2NCcgaGVpZ2h0PSc2NCcgZmlsbD0nI2ZmZicgdmlld0JveD0nMCAwIDE2MCAxMjgnPjxwYXRoIGQ9J00xNTkuODk2IDExOC45ODRDMTU5Ljg5NiAxMTYuODgxIDE1OC4wODggMTE1LjA3OCAxNTUuOTc5IDExNS4wNzhDMTQ0LjAyOCAxMTUuMDc4IDEzMi4xNzggMTEzLjU3NiAxMjEuMDMxIDEwOS43NzFDMTE1LjEwNiAxMDcuNzY5IDEwOS4yODEgMTA0Ljc2NSAxMDQuMzYgMTAwLjc1OUMxMTQuNzA0IDkxLjg0NzUgMTIzLjU0MSA4MS4zMzM1IDEyOS43NjggNjkuMTE3MkMxMzIuODgxIDYyLjkwOSAxMzUuMzkyIDU1Ljg5OTcgMTM0LjQ4OCA0OC43OTAyQzEzMy4wODIgMzguNDc2NSAxMjQuNTQ2IDMyLjQ2ODUgMTE0LjUwMyAzMS44Njc3Qzk4LjIzNCAzMC41NjYgODQuMDczOSAzOS45Nzg1IDc3LjE0NDQgNTQuMzk3N0M3My43Mjk5IDYxLjQwNyA3Mi4yMjM1IDY5LjMxNzUgNzIuNzI1NyA3Ny4xMjc5QzczLjEyNzQgODUuNjM5MiA3Ni4xNDAyIDkzLjY0OTkgODAuODYwMiAxMDAuNDU5QzY4LjcwODYgMTA4LjA2OSA1NC44NDk4IDExMi44NzUgNDAuNjg5NyAxMTIuOTc2QzM3LjE3NDcgMTEyLjk3NiAzMy41NTk0IDExMi43NzUgMzAuMTQ0OSAxMTIuMDc0QzI2LjkzMTIgMTExLjM3MyAyMy43MTc2IDExMC4wNzIgMjEuNDA3OCAxMDcuNzY5QzE2LjY4NzcgMTAyLjg2MiAxNy4zOTA3IDk1LjY1MjUgMTguOTk3NiA4OS4xNDM5QzIyLjkxNDIgNzUuMTI1MiAzMS43NTE3IDYyLjYwODYgNDEuNTkzNSA1MS44OTQzQzUxLjAzMzYgNDEuNzgwOSA2NC43OTIgMzAuNDY1OCA3OC45NTIxIDI2Ljk2MTJDODMuMzcwOSAyNS44NTk3IDg2LjU4NDUgMjIuMTU0OCA4Ny4yODc1IDE3LjY0ODhDODcuNDg4NCAxNS45NDY1IDg3LjY4OTIgMTQuMjQ0MiA4Ny42ODkyIDEyLjQ0MTlDODcuNjg5MiAxMC42Mzk1IDg3LjM4NzkgNy42MzU0NiA4Ny4wODY2IDUuNTMyNjZDODYuNDg0MSAyLjEyODEzIDgzLjM3MDkgLTAuMjc1MDY2IDc5Ljg1NTkgMC4wMjUzMzNDNzcuMDQ0IDAuMjI1NiA3NC4yMzIxIDAuNzI2MjY2IDcxLjUyMDYgMS40MjcyQzU0LjQ0ODEgNi4wMzMzMyA0MC4wODcxIDE4LjA0OTMgMjguNzM4OSAzMS4wNjY2QzE0LjM3NzkgNDcuNjg4NyAwLjgyMDM3MyA3MS4yMiAwLjAxNjk2MjMgOTMuNjQ5OUMtMC4zODQ3NDMgMTA4LjI2OSA2LjM0MzgyIDEyMC43ODYgMjAuNzA0OCAxMjUuNTkyQzI1LjcyNjEgMTI3LjI5NSAzMS4wNDg3IDEyNy44OTUgMzYuMjcwOSAxMjcuOTk2QzU1LjY1MzIgMTI4LjE5NiA3NC40MzI5IDEyMS41ODcgOTAuNTAxMSAxMTEuMTczQzkzLjgxNTIgMTEzLjk3NyA5Ny41MzEgMTE2LjM4IDEwMS40NDggMTE4LjI4M0MxMTcuMzE1IDEyNi4zOTMgMTM1LjM5MiAxMjcuOTk2IDE1Mi44NjYgMTI3Ljc5NUMxNTMuNzcgMTI3Ljc5NSAxNTQuODc0IDEyNy43OTUgMTU1Ljk3OSAxMjcuNzk1QzE1OC4xODkgMTI3Ljc5NSAxNjAuMDk3IDEyNS45OTMgMTU5Ljk5NiAxMjMuNzlWMTE4Ljk4NEgxNTkuODk2Wk05Mi4yMDg0IDgyLjEzNDZDODkuMzk2NSA2OS45MTgzIDk1LjYyMjkgNTUuMDk4NiAxMDguMTc2IDUxLjQ5MzhDMTEwLjI4NSA1MC44OTMgMTEyLjU5NSA1MC41OTI2IDExNC44MDQgNTAuNjkyN0MxMTUuMzA2IDUwLjY5MjcgMTE1LjgwOSA1MC43OTI5IDExNi4yMSA1MC44OTNDMTE2LjYxMiA1MC45OTMxIDExNi44MTMgNTEuMDkzMyAxMTcuMTE0IDUxLjM5MzdDMTE3LjgxNyA1Mi4wOTQ2IDExNy41MTYgNTMuNzk2OSAxMTcuNDE1IDU1LjA5ODZDMTE2LjkxMyA1OC41MDMxIDExNS41MDcgNjIuMzA4MiAxMTMuOCA2NS41MTI1QzEwOS4wOCA3NC4yMjQgMTAyLjU1MiA4Mi41MzUxIDk0LjkxOTkgODkuNTQ0NEM5My43MTQ4IDg3LjI0MTQgOTIuODExIDg0LjczOCA5Mi4yMDg0IDgyLjEzNDZaJy8+PC9zdmc+&labelColor=464646&style=for-the-badge)](https://vote.artizen.fund/index/second-brain-ai-agent-1692884508130x285177834121461760)

# 🧠 Second Brain AI agent

## Introducing the Second Brain AI Agent Project: Empowering Your Personal Knowledge Management

Are you overwhelmed with the information you collect daily? Do you often find yourself lost in a sea of markdown files, videos, web pages, and PDFs? What if there's a way to seamlessly index, search, and even interact with all this content like never before? Welcome to the future of Personal Knowledge Management: The Second Brain AI Agent Project.

### 📝 Inspired by Tiago Forte's Second Brain Concept

Tiago Forte's groundbreaking idea of the Second Brain has revolutionized the way we think about note-taking. It’s not just about jotting down ideas; it's about creating a powerful tool that enhances learning and creativity. Learn more about Building a Second Brain by Tiago Forte [here](https://fortelabs.com/blog/basboverview/).

### 💼 What Can the Second Brain AI Agent Project Do for You?

1. Automated Indexing: No more manually sorting through files! Automatically index the content of your markdown files along with contained links, such as PDF documents, YouTube videos, and web pages.

2. MCP-Powered Retrieval: Use the built-in Model Context Protocol (MCP) server to pull the most relevant context from your notes and plug it into the LLM or workflow of your choice.

3. Effortless Integration: Whether you follow the Second Brain method or have your own unique way of note-taking, our system seamlessly integrates with your style, helping you harness the true power of your information.

4. Enhanced Productivity: Spend less time organizing and more time innovating. By accessing your information faster and more efficiently, you can focus on what truly matters.

### ✅ Who Can Benefit?

* Professionals: Streamline your workflow and find exactly what you need in seconds.
* Students: Make study sessions more productive by quickly accessing and understanding your notes.
* Researchers: Dive deep into your research without getting lost in information overload.
* Creatives: Free your creativity by organizing your thoughts and ideas effortlessly.

### 🚀 Get Started Today

Don't let your notes and content overwhelm you. Make them your allies in growth, innovation, and productivity. Join us in transforming the way you manage your personal knowledge and take the leap into the future.

## Details

If you take notes using markdown files like in the Second Brain method or using your own way, this project automatically indexes the content of the markdown files and the contained links (pdf documents, youtube video, web pages) and allows you to ask question about your content using the OpenAI Large Language Model.

The system is built on top of the [LangChain](https://python.langchain.com/) framework and the [ChromaDB](https://www.trychroma.com/) vector store.

The system takes as input a directory where you store your markdown notes. For example, I take my notes with [Obsidian](https://obsidian.md/). The system then processes any change in these files automatically with the following pipeline:

```mermaid
graph TD
A[Markdown files from your editor]-->B[Text files from markdown and pointers]-->C[Text Chunks]-->D[Vector Database]-->E[AI Agent]
```

From a markdown file, [transform_md.py](transform_md.py) extracts the text from the markdown file, then from the links inside the markdown file, it extracts pdf, url, youtube video and transforms them into text.

**Supported link formats:**

* **Local PDFs**: `~/Documents/report.pdf` or `/home/user/papers/research.pdf`
* **Remote PDFs**: `https://arxiv.org/pdf/2305.04091.pdf`
* **Web pages**: `https://example.com/article`
* **YouTube videos**: `https://www.youtube.com/watch?v=VIDEO_ID`
* **File URLs**: `file:///path/to/document.pdf`

There is some support to extract history data from the markdown files: if there is an `## History` section or the file name contains `History`, the file is split in multiple parts according to `<day> <month> <year>` sections like `### 10 Sep 2023`.

From these text files, [transform_txt.py](transform_txt.py) breaks these text files into chunks, create a vector embeddings and then stores these vector embeddings into a vector database.

To be able to manipulate dates for activity reports. The system relies on some naming conventions. The first one is filenames containing `History`, `Journal` or `StatusReport` are considered journals with entries in this format: `## 02 Dec 2024` for each date. Other files can have an `## History` section with entries in this format: `### 02 Dec 2024` for each date.

To classify documents, the second brain agent uses a concept of a domain per document. The domain metadata is computed for each document by removing numbers and these strings: `At`, `Journal`, `Project`, `Notes` and `History`. This is handy if you use a documents named like `WorkoutHistory202412.md` then the domain is `Workout`.

To know which domain to use to filter documents, the second brain agent uses a special document that can be described in the `.env` files in the `SBA_ORG_DOC` variable and is defaulting to `SecondBrainOrganization.md`. This document describes the mapping between domains and other concepts if you want for example to separate work and personal activities.

## MCP Server

The Second Brain Agent relies on an AI Agent using the Second Brain MCP (Model Context Protocol) server that provides programmatic access to the vector database and document retrieval system.

### MCP Server Features

* **Retrieve Context**: Use `search_documents` to stream back the most relevant chunks from your notes
* **Search Documents**: Perform semantic search across your documents with metadata filtering
* **Document Management**: Get document counts, metadata, and list available domains
* **Domain-based Search**: Search within specific domains (work, personal, etc.)
* **Recent Documents**: Retrieve recently accessed documents

### Using the MCP Server

1. **Install the MCP server**:

   ```bash
   uv add fastmcp
   ```

2. **Run the MCP server**:

   ```bash
   uv run python mcp_server.py
   ```

3. **Test the server**:

   ```bash
   uv run python test_mcp_server.py
   ```

4. **Configure MCP clients** using the `mcp_config.json` file:

   ```json
   {
     "mcpServers": {
       "second-brain-agent": {
         "command": "/your/path/to/second-brain-agent/mcp-server.sh"
       }
     }
   }
   ```

### Available MCP Tools

* `search_documents`: Search for documents using semantic similarity
* `get_document_count`: Get the total number of documents
* `get_domains`: List all available domains
* `get_recent_documents`: Get recently accessed documents

## Installation

You need a Python 3 interpreter, [`uv`](https://docs.astral.sh/uv/) and the `inotify-tools` installed. All this has been tested under Fedora Linux 42 on my laptop and Ubuntu latest in the CI workflows. Let me know if it works on your system.

Get the source code:

```ShellSession
$ git clone https://github.com/flepied/second-brain-agent.git
```

Copy the example .env file and edit it to suit your settings:

```ShellSession
$ cp example.env .env
```

Install the dependencies using [uv](https://docs.astral.sh/uv/):

```ShellSession
$ uv sync --all-extras
```

Then to activate the virtual environment, do:

```ShellSession
$ source .venv/bin/activate
```

### systemd services

To install systemd services to manage automatically the different scripts when the operating system starts, use the following command (need sudo access):

```ShellSession
$ ./install-systemd-services.sh
```

To see the output of the md and txt services:

```ShellSession
$ journalctl --unit=sba-md.service --user
$ journalctl --unit=sba-txt.service --user
```

### Using the MCP server

The MCP server is now the single interface to explore your second brain. Once the environment is configured you can:

```ShellSession
# Start the MCP server
$ uv run python mcp_server.py
```

To experiment without a dedicated MCP client, the repository ships with a small helper script:

```ShellSession
$ uv run python example_mcp_usage.py
```

The script showcases how to call the exposed tools (document search, counts, domains, and recents) and prints sample results in the terminal. Check the output for an example MCP client configuration snippet that you can paste into Cursor or any other MCP-compatible tool.

### Command-line helper

Prefer a quick terminal search? Use the CLI wrapper:

```ShellSession
$ uv run python qa.py "What did I learn about LangChain last month?" -k 3
# Filter example: limit to history documents
$ uv run python qa.py "Summarize last quarter highlights" --filter '{"type": {"$eq": "history"}}'
```

It prints the top matches with their sources so you can jump straight into the relevant files.

## Development

Install the extra dependencies using [uv](https://docs.astral.sh/uv/):

```ShellSession
$ uv sync --all-extras
```

And then run the tests, like this:

```ShellSession
# Run all tests (unit + integration)
$ uv run pytest

# Run only unit tests (no external dependencies required)
$ uv run pytest -m "not integration"

# Run only integration tests (requires vector database)
$ uv run pytest -m integration

# Run only unit tests (same as above, more explicit)
$ uv run pytest -m unit
```

**Note**: Integration tests require a running vector database and are automatically excluded during pre-commit hooks. Unit tests run without external dependencies and are suitable for CI/CD pipelines.

### Full Integration Testing

For comprehensive testing of the entire system including the vector database and MCP server:

```ShellSession
$ ./integration-test.sh
```

This script:

* Sets up a complete test environment with ChromaDB
* Processes test documents through the system
* Runs pytest integration tests to validate MCP server functionality
* Tests document lifecycle (create, modify, delete)
* Provides end-to-end validation of the system

**Note**: This requires docker-compose/podman-compose and will create temporary test data.

### pre-commit

Before submitting a PR, make sure to activate [pre-commit](https://pre-commit.com/):

```ShellSession
uv run pre-commit install
```
