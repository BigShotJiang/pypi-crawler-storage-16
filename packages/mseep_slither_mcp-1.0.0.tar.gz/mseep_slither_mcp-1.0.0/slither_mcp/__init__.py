"""Slither MCP Server - MCP server for Slither static analysis."""

__version__ = "0.1.0"

