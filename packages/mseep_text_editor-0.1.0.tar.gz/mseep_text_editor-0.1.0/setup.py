#!/usr/bin/env python
# This file is included for backward compatibility

from setuptools import setup

if __name__ == "__main__":
    setup(    long_description="Package managed by MseeP.ai",
    long_description_content_type="text/plain",
)
