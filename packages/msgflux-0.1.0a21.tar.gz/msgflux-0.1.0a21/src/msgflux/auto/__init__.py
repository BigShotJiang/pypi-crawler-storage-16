"""Auto module for automatic parameter and configuration management."""

from msgflux.auto.params import AutoParams

__all__ = ["AutoParams"]
