"""Tests for model providers."""
