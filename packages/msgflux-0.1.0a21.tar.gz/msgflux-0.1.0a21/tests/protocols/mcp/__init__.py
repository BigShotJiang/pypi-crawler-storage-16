"""Tests for MCP (Model Context Protocol) integration."""
