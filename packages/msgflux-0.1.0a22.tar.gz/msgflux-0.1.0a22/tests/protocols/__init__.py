"""Tests for protocol integrations."""
