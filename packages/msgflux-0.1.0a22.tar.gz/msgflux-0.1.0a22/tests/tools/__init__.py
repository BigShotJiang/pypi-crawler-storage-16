"""Unit tests for msgflux.tools module."""
