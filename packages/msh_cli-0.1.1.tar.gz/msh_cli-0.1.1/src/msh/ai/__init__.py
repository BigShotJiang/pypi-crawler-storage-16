"""
AI module for msh CLI.

Provides AI-powered features including context packs, glossary support,
and AI commands (explain, review, new, fix, tests).
"""

