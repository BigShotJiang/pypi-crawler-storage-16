"""
AI command handlers.
"""

