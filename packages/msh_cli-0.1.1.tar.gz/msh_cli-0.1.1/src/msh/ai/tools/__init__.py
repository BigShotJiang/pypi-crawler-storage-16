"""
AI tool functions for LLM function calling.
"""

