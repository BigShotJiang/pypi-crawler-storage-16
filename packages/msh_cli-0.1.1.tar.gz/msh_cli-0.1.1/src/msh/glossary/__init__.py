"""
Glossary module for msh.

Supports dual glossary storage (project YAML + .msh/glossary.json cache).
"""

