def test_import_library():
    import msmu as mm
