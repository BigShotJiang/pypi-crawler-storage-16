# mssqlclient_ng/__main__.py

import sys

from . import cli

if __name__ == "__main__":
    sys.exit(cli.main())
