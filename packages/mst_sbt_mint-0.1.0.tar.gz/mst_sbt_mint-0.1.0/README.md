# mst-sbt-mint

Mustree Network용 SBT(Soulbound Token) 발행 Python SDK

## 설치 (로컬 테스트용)

```bash
pip install dist/mst_sbt_mint-0.1.0-py3-none-any.whl
