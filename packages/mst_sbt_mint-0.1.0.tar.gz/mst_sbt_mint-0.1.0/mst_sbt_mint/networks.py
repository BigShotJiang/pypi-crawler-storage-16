NETWORKS = {
    "NABIZAM": {
        "rpc_url": "https://nbmst.mst2.site",
        "chain_id": 7602,
        "sbt_contract_address": "0x6330641Bad6572B27eE470767eCd1DDd2A31e7e8",
    }
}