# flake8: noqa
from .fact import Fact, list_facts
