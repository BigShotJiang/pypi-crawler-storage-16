from setuptools import setup  # NOQA

setup(
    name="mtcsp",
    version="0.0.0a0",
)
