from muclic.__main__ import main
