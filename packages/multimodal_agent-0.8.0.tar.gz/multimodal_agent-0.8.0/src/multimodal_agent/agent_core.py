# Backward compatibility shim for old imports:
from multimodal_agent.core.agent_core import *  # noqa
