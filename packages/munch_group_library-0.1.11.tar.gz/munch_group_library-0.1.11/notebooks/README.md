
# Notebooks

Name notebooks like this: `template.ipynb`. Make sure the names reflects the content and that the numbers reflects the order in which the notebooks should be run.

This folder contains two dummy notebooks to showcase how what notebooks can look like and how their content can be referenced in a final report generated with `quarto`