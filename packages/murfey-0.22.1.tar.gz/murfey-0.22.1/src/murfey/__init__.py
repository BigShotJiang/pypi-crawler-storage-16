from __future__ import annotations

__version__ = "0.22.1"
__supported_client_version__ = "0.22.1"
