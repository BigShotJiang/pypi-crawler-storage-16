"""Entry point for python -m murmurai."""

from murmurai.main import run

if __name__ == "__main__":
    run()
