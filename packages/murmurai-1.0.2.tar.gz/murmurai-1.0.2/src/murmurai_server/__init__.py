"""MurmurAI - GPU-powered transcription service with speaker diarization."""

__version__ = "1.0.2"
