import{_ as s,cs as a}from"./index-GQ3lWXrm.js";const c=s(a,[["__scopeId","data-v-565bc716"]]);export{c as M};
