import{_ as s,cs as a}from"./index-7lYTz3rI.js";const c=s(a,[["__scopeId","data-v-565bc716"]]);export{c as M};
