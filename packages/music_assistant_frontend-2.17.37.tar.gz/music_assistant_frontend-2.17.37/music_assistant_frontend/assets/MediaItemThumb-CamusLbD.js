import{_ as s,cs as a}from"./index-B4UF4wLI.js";const c=s(a,[["__scopeId","data-v-565bc716"]]);export{c as M};
