import{_ as a,cr as s}from"./index-Cf2d7tRd.js";const c=a(s,[["__scopeId","data-v-565bc716"]]);export{c as M};
