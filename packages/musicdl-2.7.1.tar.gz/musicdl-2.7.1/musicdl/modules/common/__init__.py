'''initialize'''
from .gdstudio import GDStudioMusicClient