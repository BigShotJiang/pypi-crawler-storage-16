"""Tests for pcs-extract."""
