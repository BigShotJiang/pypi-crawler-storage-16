Welcome to mwtab's documentation!
=================================

.. include:: ../README.rst

Documentation index:
====================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   guide
   tutorial
   metadata_column_matching
   api
   license
   todo


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
