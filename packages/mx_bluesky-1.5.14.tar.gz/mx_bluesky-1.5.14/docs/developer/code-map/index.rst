Code Map
==================================

Explanation of the structure of the codebase

.. grid:: 2
    :gutter: 2

    .. grid-item-card:: :material-regular:`code;3em`

        .. toctree::
            :caption: Grid Detect Then Xray Centre
            :maxdepth: 1

            grid_detect_xrc

        +++
