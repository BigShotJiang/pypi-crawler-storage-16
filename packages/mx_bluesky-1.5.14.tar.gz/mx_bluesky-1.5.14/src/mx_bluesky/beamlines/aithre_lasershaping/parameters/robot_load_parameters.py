from mx_bluesky.common.parameters.components import (
    WithSample,
    WithSnapshot,
    WithVisit,
)


class AithreRobotLoad(
    WithSample,
    WithSnapshot,
    WithVisit,
):
    pass
