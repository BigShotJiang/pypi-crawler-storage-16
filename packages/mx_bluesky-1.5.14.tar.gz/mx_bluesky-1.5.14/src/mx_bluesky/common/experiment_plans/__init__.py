"""Common MX plans which includes open and close data collection runs. These be used in isolation or as part of a larger plan"""
