def greet(name):
    """ترجع رسالة ترحيب مخصصة."""
    return f"Hello, {name}! Welcome to my awesome library."

def add_two_numbers(a, b):
    """تضيف عددين معا."""
    return a + b