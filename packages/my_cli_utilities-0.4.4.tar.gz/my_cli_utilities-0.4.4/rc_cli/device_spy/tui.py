# -*- coding: utf-8 -*-

"""Interactive TUI for Device Spy management."""

from .tui import run_tui

__all__ = ["run_tui"]

