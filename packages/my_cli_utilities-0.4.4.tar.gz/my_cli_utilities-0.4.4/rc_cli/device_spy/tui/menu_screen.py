# -*- coding: utf-8 -*-

"""Main menu screen for Device Spy TUI."""

from textual.containers import Container, Vertical
from textual.widgets import Button, Footer, Header, Label

from ...tui_common import BaseScreen


class DeviceSpyMenuScreen(BaseScreen):
    """Main menu that routes to host/device flows."""

    def compose(self):
        yield Header()
        with Vertical():
            with Container(id="menu-container"):
                yield Label("🖥️ Device Spy", id="menu-title")
                with Container(id="menu-buttons"):
                    yield Button("Host info", id="host-btn", variant="primary")
                    yield Button("Device info", id="device-btn")
                    yield Button("Quit", id="quit-btn", variant="error")
        yield Footer()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle menu navigation."""
        button_id = event.button.id
        if button_id == "host-btn":
            self.app.push_screen("host-info")
        elif button_id == "device-btn":
            self.app.push_screen("device-info")
        elif button_id == "quit-btn":
            self.app.action_quit()

