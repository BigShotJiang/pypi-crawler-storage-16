# datagen

A simple Python library for generating reproducible synthetic datasets.

## Installation
```bash
pip install my_datagen_25


USAGE

from my_datagen_25 import generate_profiles

data = generate_profiles(n=10, seed=123)
