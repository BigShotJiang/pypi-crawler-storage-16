# config.py

MIN_SALARY = 30000
MAX_SALARY = 200000

REGIONS = ["Nairobi", "Mombasa", "Kisumu", "Nakuru", "Eldoret"]

CAR_BRANDS = ["Toyota", "Honda", "Nissan", "BMW", "Mercedes"]

FIRST_NAMES = ["John", "Mary", "David", "Grace", "Paul"]
LAST_NAMES = ["Oduor", "Kariuki", "Mwangi", "Kamau", "Otieno"]
