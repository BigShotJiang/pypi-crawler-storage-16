# my-entire-ml

A test package for ML explanation utilities.

## Installation

```bash
pip install my-entire-ml
```

## Quick Start

```python
import meml

# Print a simple greeting
meml.hello()  # Output: Hello!
```

## Usage

```python
import meml

# Call the hello function
meml.hello()
```

## Development

### Setup Development Environment

```bash
git clone https://github.com/yourusername/my-entire-ml.git
cd my-entire-ml
pip install -e .
```

### Building the Package

```bash
pip install build
python -m build
```

### Publishing to PyPI

```bash
pip install twine
twine upload dist/*
```