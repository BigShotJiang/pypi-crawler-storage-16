"""
Core functionality for mlml package
"""

import pyperclip

describe_text = """
list

- get_l2t1()
- get_l2t2()
- get_nn()
- get_pd()
- get_np()
- get_pipe()
- get_plt_sb()
- get_decision()
- get_imb()
- get_knn_nb_svm()
- get_lab1()
- get_reg()
- get_scipy()
- get_midterm()
- get_assign2()
- get_ml_clf()
- get_ml_clf_all()
- get_ml_reg()
- get_final()
- get_tfidf()
- get_nltk()
"""

l2t1_text = """import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import scale
from sklearn.model_selection import train_test_split
from keras.utils import to_categorical

# --- Task 1-1: Read the dataset and do descriptive analysis ---
# Note: Path updated to filename only for portability
df = pd.read_csv("Tojan-Sub-500-NColumn.csv") 

# Display head and info
print(df.head())
df.info()

# Check for missing values and description
# "As we can see... there are no values missing"
print(df.describe())

# --- Task 1-2: Print the dataset dimensions ---
print("Dataset Dimensions: ", df.shape)

# --- Task 1-3: Print the column's name ---
print("Column's name:")
print(df.columns)

# --- Task 1-4: Print the target values ---
print("Target Values:")
print(df['Class'])
print(df['Class'].value_counts())

# Replace class values: Trojan = 1, Benign = 0
df['Class'] = df['Class'].replace({"Trojan": 1, "Benign": 0})

# --- Task 1-5: Build train and test sets (70-30 split) ---
x = df.drop(columns=['Class'], axis=1)
y = df['Class']

# Convert to numpy and categorical (as per PDF code flow)
x = x.to_numpy()
v = to_categorical(y)

# Split the data
X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.3, random_state=42, stratify=y)

# --- Task 1-6: Print the correlation among all attributes ---
corr1 = df.corr()
print(corr1)

# --- Task 1-7: Plot the heatmap ---
sns.heatmap(corr1)
plt.show()
"""



l2t2_text = """from keras.models import Sequential
from keras.layers import Dense
from sklearn.preprocessing import scale

# --- Data Preprocessing for Task 2 ---
# Scaling predictors and targets as found in the PDF source code
x_train_scaled = scale(X_train)
x_test_scaled = scale(X_test)
y_train_scaled = scale(y_train)
y_test_scaled = scale(y_test)

# --- Model 1 ---
# Structure: 12 -> 8 -> 2
print("--- Model 1 ---")
model_1 = Sequential()
model_1.add(Dense(12, activation='relu'))
model_1.add(Dense(8, activation='relu'))
model_1.add(Dense(2, activation='sigmoid'))

model_1.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
model_1.fit(x_train_scaled, y_train_scaled, epochs=100, batch_size=8)
model_1.predict(x_test_scaled)
model_1.evaluate(x_train_scaled, y_train_scaled)
model_1.summary()


# --- Model 2 ---
# Structure: 24 -> 16 -> 2
# Loss Function: log_cosh
print("--- Model 2 ---")
model_2 = Sequential()
model_2.add(Dense(24, activation='relu'))
model_2.add(Dense(16, activation='relu'))
model_2.add(Dense(2, activation='sigmoid'))

model_2.compile(loss='log_cosh', optimizer='adam', metrics=['accuracy'])
model_2.fit(x_train_scaled, y_train_scaled, epochs=120, batch_size=10)
model_2.predict(x_test_scaled)
model_2.evaluate(x_train_scaled, y_train_scaled)
model_2.summary()


# --- Model 3 ---
# Structure: 6 -> 4 -> 2
# Loss Function: mean_absolute_error
print("--- Model 3 ---")
model_3 = Sequential()
model_3.add(Dense(6, activation='relu'))
model_3.add(Dense(4, activation='relu'))
model_3.add(Dense(2, activation='sigmoid'))

model_3.compile(loss='mean_absolute_error', optimizer='adam', metrics=['accuracy'])
model_3.fit(x_train_scaled, y_train_scaled, epochs=150, batch_size=9)
model_3.predict(x_test_scaled)
model_3.evaluate(x_train_scaled, y_train_scaled)
model_3.summary()


# --- Model 4 ---
# Structure: 18 -> 9 -> 2
# Loss Function: mean_squared_error
print("--- Model 4 ---")
model_4 = Sequential()
model_4.add(Dense(18, activation='relu'))
model_4.add(Dense(9, activation='relu'))
model_4.add(Dense(2, activation='sigmoid'))

model_4.compile(loss='mean_squared_error', optimizer='adam', metrics=['accuracy'])
model_4.fit(x_train_scaled, y_train_scaled, epochs=110, batch_size=12)
model_4.predict(x_test_scaled)
model_4.evaluate(x_train_scaled, y_train_scaled)
model_4.summary()


# --- Model 5 ---
# Structure: 100 -> 10 -> 2
# Loss Function: binary_crossentropy
print("--- Model 5 ---")
model_5 = Sequential()
model_5.add(Dense(100, activation='relu'))
model_5.add(Dense(10, activation='relu'))
model_5.add(Dense(2, activation='sigmoid'))

model_5.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
model_5.fit(x_train_scaled, y_train_scaled, epochs=150, batch_size=64)
model_5.predict(x_test_scaled)
model_5.evaluate(x_train_scaled, y_train_scaled)
model_5.summary()"""


nn_text = """import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from numpy import loadtxt
from sklearn.preprocessing import scale
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from tensorflow.keras.utils import to_categorical
from keras.models import Sequential
from keras.layers import Dense
import tensorflow as tf

# --- 1. Data Loading & Preprocessing ---

# Load dataset using pandas to check structure (Optional)
# Note: Update the file path as needed
df = pd.read_csv("pimaDiabetes.csv", header=None)
df.columns = ['Pregnancies', 'Glucose', 'BloodPressure', 'SkinThickness', 'Insulin',
              'BMI', 'DiabetesPedigreeFunction', 'Age', 'Class']
print(df.head())

# Load dataset using numpy for processing
dataset = loadtxt("pimaDiabetes.csv", delimiter=',')

# Split into input (X) and output (y) variables
X = dataset[:, 0:8]
y = dataset[:, 8]

# Scale the input features
X_scaled = scale(X)
print('Scaled_X:\n', X_scaled)

# Split dataset into training and testing sets (70% train, 30% test)
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.30, random_state=42)

# One-hot encode the target variable for the training set
# Note: This prepares y_train for a model with 2 output nodes
y_train_encoded = to_categorical(y_train)
print('Y_Train Encoded:\n', y_train_encoded)

# --- 2. Model Definition & Training ---

# Define the Keras model
model = Sequential()
model.add(Dense(12, input_dim=8, activation='relu'))
model.add(Dense(8, activation='relu'))
model.add(Dense(2, activation='sigmoid')) # 2 output nodes matches the one-hot encoded target

# Compile the model
model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
print(model.summary())

# Fit the model on the dataset
history = model.fit(X_train, y_train_encoded, epochs=100, batch_size=16)

# --- 3. Evaluation & Prediction ---

# Evaluate the model on training data
_, accuracy = model.evaluate(X_train, y_train_encoded)
print('Accuracy: %.2f' % (accuracy * 100))

# Make class predictions on the test set
# The model outputs probabilities for 2 classes, so we use argmax to get the class index
predictions = np.argmax(model.predict(X_test), axis=-1)

# Summarize the first 10 cases
for i in range(10):
    print('%s => %d (expected %d)' % (X_test[i].tolist(), predictions[i], y[i]))

# Calculate accuracy on the test set
y_pred_prob = model.predict(X_test)
y_pred = np.argmax(y_pred_prob, axis=1)
acc = accuracy_score(y_test, y_pred)
print(f"Test Accuracy: {acc}")



import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import tensorflow as tf
from sklearn.datasets import make_circles

# --- 1. Data Generation & Visualization ---

# Generate synthetic data (concentric circles)
samples = 1000
X, y = make_circles(samples, noise=0.03, random_state=42)

print('X shape:', X.shape, 'y shape:', y.shape)

# Visualizing the data in a DataFrame
circle = pd.DataFrame({'X0': X[:, 0], 'X1': X[:, 1], 'label': y})
print(circle.head())
print(circle.label.value_counts())

# Plot the data
plt.scatter(X[:, 0], X[:, 1], c=y, cmap=plt.cm.RdYlBu)
plt.title("Circles Dataset")
plt.show()

# --- 2. Models Experimentation ---

tf.random.set_seed(42)

# Model 1: Single Dense Layer (Linear)
# Result: Fails to learn non-linear boundaries (~50% accuracy)
print("--- Model 1 (Linear) ---")
model_1 = tf.keras.Sequential([tf.keras.layers.Dense(1)])
model_1.compile(loss='binary_crossentropy', optimizer=tf.keras.optimizers.SGD(), metrics=['accuracy'])
model_1.fit(X, y, epochs=200, verbose=0)
model_1.evaluate(X, y)

# Model 2: Two Dense Layers (Linear Activations by default)
# Result: Still behaves linearly, fails to learn (~50% accuracy)
print("--- Model 2 (Deep Linear) ---")
model_2 = tf.keras.Sequential([
    tf.keras.layers.Dense(1),
    tf.keras.layers.Dense(1)
])
model_2.compile(loss=tf.keras.losses.BinaryCrossentropy(),
                optimizer=tf.keras.optimizers.SGD(),
                metrics=['accuracy'])
model_2.fit(X, y, epochs=200, verbose=0)
model_2.evaluate(X, y)

# Model 3: More Layers/Neurons (Still Linear Activations)
# Result: Fails to learn (~50% accuracy) because combining linear functions is still linear
print("--- Model 3 (Wider/Deeper Linear) ---")
model_3 = tf.keras.Sequential([
    tf.keras.layers.Dense(100),
    tf.keras.layers.Dense(10),
    tf.keras.layers.Dense(1)
])
model_3.compile(loss=tf.keras.losses.BinaryCrossentropy(),
                optimizer=tf.keras.optimizers.Adam(),
                metrics=['accuracy'])
model_3.fit(X, y, epochs=200, verbose=0)
model_3.evaluate(X, y)

# Model 4: Deep Network with Non-Linear Activations (ReLU)
# Result: Successfully learns the circle (~99% accuracy)
print("--- Model 4 (Non-Linear Activations) ---")
model_4 = tf.keras.Sequential([
    tf.keras.layers.Dense(4, activation='relu'),
    tf.keras.layers.Dense(4, activation='relu'),
    tf.keras.layers.Dense(1, activation='sigmoid') # Output layer for binary classification
])
model_4.compile(loss=tf.keras.losses.binary_crossentropy,
                optimizer=tf.keras.optimizers.Adam(learning_rate=0.01),
                metrics=['accuracy'])

model_4.fit(X, y, epochs=25)
loss, accuracy = model_4.evaluate(X, y)
print(f'Model loss: {loss}, Model accuracy: {100*accuracy}%')

# --- 3. Decision Boundary Visualization ---

def plot_decision_boundary(model, X, y):
    # Define the axis boundaries of the plot and create a meshgrid
    x_min, x_max = X[:, 0].min() - 0.1, X[:, 0].max() + 0.1
    y_min, y_max = X[:, 1].min() - 0.1, X[:, 1].max() + 0.1
    xx, yy = np.meshgrid(np.linspace(x_min, x_max, 100),
                         np.linspace(y_min, y_max, 100))
    
    # Create X values (predict on grid)
    X_in = np.c_[xx.ravel(), yy.ravel()]
    
    # Make predictions
    y_pred = model.predict(X_in)
    
    # Reshape predictions for plotting
    if len(y_pred[0]) > 1:
        print("doing multiclass classification...")
        y_pred = np.argmax(y_pred, axis=1).reshape(xx.shape)
    else:
        print("doing binary classification...")
        y_pred = np.round(y_pred).reshape(xx.shape)
        
    # Plot contour
    plt.contourf(xx, yy, y_pred, cmap=plt.cm.RdYlBu, alpha=0.7)
    plt.scatter(X[:, 0], X[:, 1], c=y, s=40, cmap=plt.cm.RdYlBu)
    plt.xlim(xx.min(), xx.max())
    plt.ylim(yy.min(), yy.max())

# Plot results for Model 3 (Linear - Fail) vs Model 4 (Non-Linear - Success)
plt.figure(figsize=(12, 6))
plt.subplot(1, 2, 1)
plt.title("Model 3 (Linear)")
plot_decision_boundary(model_3, X, y)

plt.subplot(1, 2, 2)
plt.title("Model 4 (Non-Linear)")
plot_decision_boundary(model_4, X, y)
plt.show()

"""


pd_text = """# --- Library Import ---

# Import the pandas library and assign it the alias 'pd'
import pandas as pd
# Import the numpy library for array creation, as it's used to build a DataFrame
import numpy as np


# --- Series Creation and Manipulation ---

# Create a pandas Series with custom index labels
series1 = pd.Series([1,2,3,4,5], index=['row1', 'row2', 'row3', 'row4', 'row5'])

# Get the values from the Series as a NumPy array
series1.values

# Get the index labels of the Series
series1.index

# Access an element using its index label as an attribute
series1.row3

# Access an element using its index label in brackets
series1['row2']

# Change the index labels of an existing Series
series1.index = ['a', 'b', 'c', 'd', 'e']


# --- DataFrame Creation ---

# Create a NumPy array
array1 = np.array([[1,5,9,13], [2,6,10,19], [3,7,11,5], [4,8,12,16]])

# Create a DataFrame from the NumPy array with custom row and column labels
df1 = pd.DataFrame(array1, index=['row1', 'row2', 'row3', 'row4'], columns=['col1', 'col2', 'col3', 'col4'])

# Create a dictionary where keys are column names and values are lists of column data
dic1 = {'col1': [1,2,3,4], 'col2': [5,6,7,8], 'col3': [9,10,11,12], 'col4': [13,14,16,16]}

# Create a DataFrame from the dictionary
df2 = pd.DataFrame(dic1, index=['row1', 'row2', 'row3', 'row4'])


# --- DataFrame Inspection ---

# Get the index (row labels) of the DataFrame
df2.index

# Get the column labels of the DataFrame
df2.columns

# Get the values of the DataFrame as a NumPy array
df2.values


# --- Data Selection and Slicing ---

# Select a row by its label using .loc
df2.loc['row1'][:]

# Select a single cell by its row and column labels using .loc
df2.loc['row1']['col2']

# Select a row by its integer position using .iloc
df2.iloc[0][:]

# Select a single cell by its row and column integer positions using .iloc
df2.iloc[0][1]


# --- DataFrame Modification ---

# Rename a specific column
# Note: The original PDF had a syntax error. The correct syntax uses a dictionary.
df2.rename(columns={'col4': 'column4'})

# Replace all occurrences of the value 1 with 10 throughout the DataFrame
df2.replace({1: 10})


# --- Sorting and Viewing ---

# Sort the DataFrame by column labels in descending order
df2.sort_index(axis=1, ascending=False)

# Sort the DataFrame by the values in a specific column ('col1') in descending order
df2.sort_values(by='col1', ascending=False)

# Display the first 2 rows of the DataFrame
df2.head(2)

# Display the last 2 rows of the DataFrame
df2.tail(2)


# --- Importing Data ---

# Read data from a CSV file into a new DataFrame called 'data1'
data1 = pd.read_csv('F:/00-Douglas College/1- Semester 1/3- Machine Learning in Data Science (3290)/Slides/ozone1.csv')

# Display the first 5 rows of the imported data to verify it loaded correctly
data1.head()"""


np_text = """# --- Library Import and Version ---

# Import the NumPy library and assign it the alias 'np'
import numpy as np

# Check the installed version of NumPy
np.__version__

# --- Array and Matrix Creation ---

# Correctly create a 2x2 NumPy array
a = np.array([[1,2],[3,4]])

# Create a 2x2 NumPy matrix
b = np.matrix([[1,2],[3,4]])

# Create a 2x2 array with a specific data type (8-bit integer)
a = np.array([[1,2],[3,4]], dtype='int8')

# Create a 1D array
b = np.array([1,2,3])

# Create a 3x3 array filled with the value 1
c = np.ones((3,3))

# Create another 1D array
d = np.array([5,6,7])

# Create a 3x1 array filled with the value 1
e = np.ones((3,1))

# Create a 2x2 array
g = np.array([[1,2],[3,4]])

# --- Multiplication Operations ---

# Perform matrix multiplication on array 'a' with itself
np.dot(a,a)

# Perform element-wise multiplication on array 'a' with itself
np.multiply(a,a)

# Calculate the product of all elements in array 'a'
np.prod(a)

# --- Broadcasting ---

# Add 5 to each element in array 'b'
b + 5

# Add 1D array 'd' to each row of 2D array 'c'
c + d

# Add 1D array 'f' to each row of 2D array 'e'
# Note: 'f' was not defined in the provided snippets, assuming it's similar to 'd' for this example.
f = np.array([5,6,7])
e + f

# --- Basic Math Operations ---

# Calculate the sum of all elements in array 'g'
np.sum(g)

# Calculate the cumulative sum along the columns (axis=0)
np.cumsum(g, axis=0)

# Calculate the cumulative sum along the rows (axis=1)
np.cumsum(g, axis=1)

# Subtract array 'a' from itself element-wise
np.subtract(a,a)

# Divide each element in the list by 3
np.divide([5,6,7],3)

# Perform floor division for each element in the list by 3
np.floor_divide([5,6,7],3)

# Generate a 2x3 array with random numbers from a uniform distribution between 1 and 5
np.random.uniform(1,5,(2,3))

# Generate a 2x1 array with random numbers from a standard normal distribution
np.random.standard_normal((2,1))

# --- Array Generation and Properties ---

# Create an array starting from 1 up to (but not including) 10, with a step of 3
np.arange(1,10,3)

# Create an array with 4 evenly spaced numbers from 1 to 10
np.linspace(1,10,4)

# Get the total number of elements in array 'a'
np.size(a)

# Get the dimensions (shape) of array 'a'
np.shape(a)

# --- Set and Statistical Operations ---

# Create a 1D array
a = np.array([1,7,2,3,1,2,4,3])

# Find the unique elements in array 'a'
np.unique(a)

# Create another 1D array
b = np.array([3,4,6,7,8,1,2])

# Find the union of elements in arrays 'a' and 'b'
np.union1d(a,b)

# Find the common elements (intersection) between arrays 'a' and 'b'
np.intersect1d(a,b)

# Calculate the mean (average) of array 'a'
np.mean(a)

# Find the median of array 'a'
np.median(a)

# Calculate the standard deviation of array 'a'
np.std(a)

# Calculate the variance of array 'a'
np.var(a)

# --- Polynomial Operations ---

# Define polynomial coefficients for x^2 + x + 2
coeff = np.array([1,1,2])

# Evaluate the polynomial at x=1
np.polyval(coeff, 1)

# Calculate the derivative of the polynomial
np.polyder(coeff)

# Calculate the integral of the polynomial
np.polyint(coeff)"""


pipe_text = """# --- Library Imports ---

# General data science and machine learning libraries
from sklearn import datasets
from sklearn.model_selection import train_test_split, KFold, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.feature_selection import SelectKBest
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.metrics import accuracy_score
from pandas import read_csv


# --- Example 1: Basic Pipeline with Scaling, PCA, and a Classifier ---

# --- 1. Data Loading and Preparation ---

# Load the built-in Iris dataset
iris = datasets.load_iris()

# Separate the features (x) and the target variable (y)
x = iris.data
y = iris.target

# Split the data into training and testing sets, with 25% of the data reserved for testing
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.25)


# --- 2. Pipeline Creation and Execution ---

# Define the sequence of steps for the pipeline:
# 1. 'pca': Reduce dimensionality to 2 principal components.
# 2. 'std': Standardize the features (scale to unit variance).
# 3. 'DC': Use a Decision Tree Classifier for the final prediction.
pipeline1 = Pipeline([
    ('pca', PCA(n_components=2)),
    ('std', StandardScaler()),
    ('DC', DecisionTreeClassifier())
], verbose=True)

# Train the entire pipeline on the training data.
# This will execute each step in sequence on the data.
pipeline1.fit(x_train, y_train)


# --- 3. Evaluation ---

# Make predictions on the test set using the trained pipeline and print the accuracy score.
print(f"Accuracy for Pipeline 1: {accuracy_score(y_test, pipeline1.predict(x_test))}")


# --- Example 2: Pipeline with FeatureUnion for Combined Feature Extraction ---

# --- 1. Data Loading and Preparation ---

# URL for the Pima Indians Diabetes dataset
url_data = "https://raw.githubusercontent.com/jbrownlee/Datasets/master/pima-indians-diabetes.data.csv"

# Define column names for the dataset
varnames = ['var_preg', 'var_plas', 'var_pres', 'var_skin', 'var_test', 'var_mass', 'var_pedi', 'var_age', 'var_class']

# Read the CSV data from the URL into a pandas DataFrame
vardataframe = read_csv(url_data, names=varnames)

# Convert the DataFrame to a NumPy array
vararray = vardataframe.values

# Separate the features (varX) and the target variable (vary)
# Note: The PDF slice [:,0:7] was corrected to [:,0:8] to include all 8 feature columns.
varX = vararray[:, 0:8]
vary = vararray[:, 8]


# --- 2. Feature Union and Pipeline Creation ---

# Create a list to hold the feature extraction methods that will be combined
urlfeatures = []

# First feature extraction method: Select the 6 best features using statistical tests.
urlfeatures.append(('select_best', SelectKBest(k=6)))

# Second feature extraction method: Apply PCA to get the top 3 principal components.
urlfeatures.append(('pca', PCA(n_components=3)))

# Use FeatureUnion to combine the results of both feature extraction methods into a single feature set.
# The results of 'select_best' (6 features) and 'pca' (3 features) will be concatenated.
feature_union = FeatureUnion(urlfeatures)

# Create the final pipeline steps
pipeline2_steps = []

# Step 1: Apply the combined feature extraction (FeatureUnion).
pipeline2_steps.append(('feature_union', feature_union))

# Step 2: Apply a Logistic Regression model to the combined features.
pipeline2_steps.append(('logistic', LogisticRegression()))

# Create the final model by wrapping the steps in a Pipeline object
model = Pipeline(pipeline2_steps)


# --- 3. Evaluation using K-Fold Cross-Validation ---

# Initialize a 10-fold cross-validation splitter
varkfold = KFold(n_splits=10)

# Evaluate the entire pipeline model using 10-fold cross-validation and get the accuracy for each fold
dataresults = cross_val_score(model, varX, vary, cv=varkfold)

# Print the mean accuracy across all 10 folds
print(f"\nMean accuracy for Pipeline 2: {dataresults.mean()}")"""


plt_sb_text = """# --- Installation Commands (for Anaconda Prompt) ---

# Note: These are not Python code, but commands to be run in the Anaconda Powershell Prompt or terminal.
# conda install matplotlib
# conda install seaborn


# --- Library Imports ---

# Import necessary libraries for data handling, numerical operations, and plotting
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sb


# --- Matplotlib Basic Plots ---

# Define data for plotting
years = [1960, 1970, 1980, 1990, 2000, 2010]
population = [21.91, 23.90, 24.80, 20.93, 22.30, 26.90]

# 1. Line Plot: Shows trends over continuous intervals.
print("--- Displaying Line Plot ---")
plt.plot(years, population)
plt.show()

# 2. Scatter Plot: Shows the relationship between two variables.
print("--- Displaying Scatter Plot ---")
plt.scatter(years, population)
plt.show()

# Scatter Plot with custom colors
# Note: The PDF uses different variables 'Years' and 'Population' here without defining them.
# The following are example values to make the code runnable.
Years_example = [1990, 2000, 2010, 2020, 2030]
Population_example = [26.7, 23.4, 27.5, 28.5, 24.9]
colors = ['violet', 'tomato', 'crimson', 'green', 'blue']
print("--- Displaying Scatter Plot with Custom Colors ---")
plt.scatter(Years_example, Population_example, c=colors)
plt.show()


# Define data for city populations
city_Name = ['London', 'Paris', 'Tokyo', 'Beijing', 'Rome'] # Corrected typo from 'Tokyu'
city_Pop = [65342, 89123, 54239, 23098, 12367]

# 3. Histogram: Represents the distribution of numerical data.
print("--- Displaying Histogram (Default Bins) ---")
plt.hist(city_Pop)
plt.show()

# Histogram with a specified number of bins
print("--- Displaying Histogram (1 Bin) ---")
plt.hist(city_Pop, bins=1)
plt.show()

# Histogram with bins determined automatically
print("--- Displaying Histogram (Auto Bins) ---")
plt.hist(city_Pop, bins='auto')
plt.show()

# 4. Pie Chart: Shows the proportion of different categories.
print("--- Displaying Pie Chart ---")
plt.pie(city_Pop, labels=city_Name)
plt.show()


# --- Plot Customization ---

# Customize a line plot by adding labels, titles, and custom tick marks.
print("--- Displaying Customized Line Plot ---")
# Set the figure size and resolution
plt.figure(figsize=(9, 7), dpi=80)
# Create the plot
plt.plot(years, population)
# Add labels and titles
plt.xlabel('Years')
plt.ylabel('Population') # Corrected typo from 'Popuation'
# Set custom ticks for x and y axes
plt.xticks([1960, 1970, 1980, 1990, 2000, 2010])
plt.yticks([20.93, 21.91, 22.30, 23.90, 24.80, 26.90], ['20M', '21M', '22M', '23M', '24M', '26M'])
plt.show()

# Customize a scatter plot
# The first plot shows the default x-axis (0, 1, 2, 3, 4)
print("--- Displaying Scatter Plot with Default Ticks ---")
plt.scatter(np.arange(5), city_Pop)
plt.show()

# The second plot adds a title and custom x-axis tick labels
print("--- Displaying Customized Scatter Plot ---")
plt.scatter(np.arange(5), city_Pop)
plt.title('Most Populated Cities')
plt.xticks([0, 1, 2, 3, 4], ['1960', '1970', '1980', '1990', '2000'])
plt.show()


# --- Multiple Plots ---

# Define data for two countries
years = [1960, 1970, 1980, 1990, 2000, 2010]
Canada_Pop = [21.91, 23.90, 24.80, 20.93, 22.30, 26.90]
USA_Pop = [32.91, 24.80, 23.60, 21.92, 32.30, 26.90]

# 1. Plot multiple lines on the same axes
print("--- Displaying Multiple Plots on Same Axes ---")
plt.plot(years, Canada_Pop, marker='s', mew=8, ls='-', label='Canada') # marker='s' for square
plt.plot(years, USA_Pop, ls='--', lw=1, label='USA')
# Add a legend to identify the lines
plt.legend(['Canada', 'USA'], loc='best')
# Add a grid for better readability
plt.grid()
plt.show()

# 2. Use subplots to create multiple plots in the same figure
print("--- Displaying Multiple Plots using Subplots ---")
# First subplot (1 row, 2 columns, plot 1)
plt.subplot(1, 2, 1)
plt.plot(years, Canada_Pop, marker='s', mew=8, ls='-') # marker='s' for square
plt.title('Population of Canada')

# Second subplot (1 row, 2 columns, plot 2)
plt.subplot(1, 2, 2)
plt.plot(years, USA_Pop, ls='--', lw=1)
plt.title('Population of United States')
plt.show()


# --- Seaborn Plots ---

# Load the dataset for Seaborn plots
# Note: You will need to replace the file path with the actual location of your 'ozone1.csv' file.
# data1 = pd.read_csv('path/to/your/ozone1.csv')
# The path from the document is used here as a placeholder.
try:
    data1 = pd.read_csv('F:/00-Douglas College/1- Semester 1/3- Machine Learning in Data Science (3290)/Slides/ozone1.csv', low_memory=False)

    # 1. Strip Plot: A scatter plot for categorical data.
    # 'jitter=True' adds a small amount of random noise to prevent points from overlapping.
    print("--- Displaying Seaborn Strip Plot ---")
    sb.stripplot(x='State Name', y='Site Num', data=data1, size=10, jitter=True)
    plt.show()

    # 2. Box Plot: Shows the distribution of data based on a five-number summary.
    print("--- Displaying Seaborn Box Plot ---")
    sb.boxplot(x='State Name', y='Site Num', data=data1)
    plt.show()

    # 3. Joint Plot: Combines a scatter plot with histograms on the axes.
    print("--- Displaying Seaborn Joint Plot ---")
    sb.jointplot(x='State Name', y='Site Num', data=data1, kind='scatter')
    plt.show()

except FileNotFoundError:
    print("" + "="*50)
    print("--- Seaborn Plotting Skipped ---")
    print("Could not find the 'ozone1.csv' file at the specified path.")
    print("Please update the file path in the code to run the Seaborn examples.")
    print("="*50 + "\n")"""


decision_text = """# --- Library Imports ---

# Import pandas for data manipulation and analysis
import pandas as pd

# Import the datasets module from scikit-learn to load sample data
from sklearn import datasets

# Import the model_selection module for splitting data
from sklearn.model_selection import train_test_split

# Import the Decision Tree classifier model
from sklearn.tree import DecisionTreeClassifier

# Import the metrics module to evaluate model performance
from sklearn import metrics

# Import the tree module for visualization
from sklearn import tree

# Import pyplot for plotting graphs
import matplotlib.pyplot as plt


# --- Data Loading and Exploration ---

# Load the built-in Iris dataset from scikit-learn
iris1 = datasets.load_iris()

# Check the dimensions (shape) of the feature data (150 samples, 4 features)
iris1.data.shape

# Get the names of the four features
iris1.feature_names

# Get the names of the three target classes (species of iris)
iris1.target_names

# Get a full description of the dataset
iris1.DESCR


# --- Data Preparation and Visualization ---

# Convert the Iris data into a pandas DataFrame
irisDF = pd.DataFrame(iris1.data, columns=iris1.feature_names)

# Add the target labels (the species) as a new column in the DataFrame
irisDF['target'] = iris1.target

# Create a scatter plot matrix to visualize the relationships between all features
# The points are colored by their target class
pd.plotting.scatter_matrix(irisDF, c=iris1.target, figsize=[11, 11], s=150)
plt.show()

# Separate the features (X) and the target variable (y)
x = iris1.data
y = iris1.target

# Print the feature values and the target class for a single sample (the 3rd one)
print(x[2], y[2])

# Create a scatter plot of the first two features (sepal length vs. sepal width), colored by target class
plt.scatter(x[:, 0], x[:, 1], c=y)
plt.show()

# Create a new feature set 'x1' containing only the last two features (petal length and petal width)
x1 = iris1.data[:, [2, 3]]


# --- Model Training Preparation ---

# Split the dataset into training (70%) and testing (30%) sets.
# 'stratify=y' ensures that the proportion of classes is the same in both train and test sets.
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.3, random_state=42, stratify=y)

# Check the shape of the training feature set
x_train.shape

# Check the shape of the testing feature set
x_test.shape


# --- Decision Tree Model: Training, Prediction, and Evaluation ---

# Initialize the Decision Tree classifier model
tree1 = DecisionTreeClassifier()

# Train (fit) the model using the training data
tree1.fit(x_train, y_train)

# Use the trained model to make predictions on the test data
pre1 = tree1.predict(x_test)

# Calculate the accuracy of the model by comparing the predictions (pre1) with the actual labels (y_test)
metrics.accuracy_score(y_test, pre1)

# Another way to calculate the accuracy of the model on the test set
tree1.score(x_test, y_test)


# --- Decision Tree Visualization ---

# Get the feature names for labeling the plot
f1 = iris1.feature_names

# Generate and display a plot of the trained decision tree
tree.plot_tree(tree1, feature_names=f1)
plt.show()"""


imb_text = """# --- Library Imports and Data Loading ---

# Import necessary libraries
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import confusion_matrix, classification_report
from sklearn.model_selection import train_test_split
from imblearn.over_sampling import SMOTE
from imblearn.under_sampling import NearMiss

# Load the credit card fraud dataset from a CSV file
data1 = pd.read_csv('C:/Users/Paris/Desktop/creditcard.csv')

# Display a summary of the DataFrame, including data types and non-null values
print(data1.info())


# --- Initial Data Preparation and Splitting ---

# Drop the 'Time' and 'Amount' columns as they are not needed for this model
data1 = data1.drop(['Time', 'Amount'], axis=1)

# Check the distribution of the target variable 'Class' (0 for non-fraud, 1 for fraud)
data1['Class'].value_counts()

# Separate the feature variables (X) from the target variable (y)
x = data1.drop(['Class'], axis=1).values
y = data1['Class'].values # Corrected from PDF for consistency

# Split the data into training (70%) and testing (30%) sets
X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.3, random_state=0)

# Print the dimensions of the resulting datasets to confirm the split
print("Number transactions X_train dataset: ", X_train.shape)
print("Number transactions y_train dataset: ", y_train.shape)
print("Number transactions X_test dataset: ", X_test.shape)
print("Number transactions y_test dataset: ", y_test.shape)


# --- Model Training on Original (Imbalanced) Data ---

# Initialize a Logistic Regression model
lr = LogisticRegression()

# Train the model on the original imbalanced training data
# .ravel() is used to flatten the y_train array to the 1D format expected by the fit method
lr.fit(X_train, y_train.ravel())

# Make predictions on the test set
predictions = lr.predict(X_test)

# Print the classification report to evaluate the model's performance
print("--- Results on Imbalanced Data ---")
print(classification_report(y_test, predictions))

# Display the count of minority (1) and majority (0) classes before resampling
print("Before OverSampling, counts of label '1': {}".format(sum(y_train == 1)))
print("Before OverSampling, counts of label '0': {} \n".format(sum(y_train == 0)))


# --- Handling Imbalance with SMOTE (Oversampling) ---

# Initialize the SMOTE (Synthetic Minority Over-sampling Technique) algorithm
sm = SMOTE(random_state=2)

# Apply SMOTE to the training data to generate synthetic samples for the minority class
X_train_res, y_train_res = sm.fit_resample(X_train, y_train.ravel())

# Print the shape and class distribution of the newly resampled training data
print('After OverSampling, the shape of train_X: {}'.format(X_train_res.shape))
print('After OverSampling, the shape of train_y: {} \n'.format(y_train_res.shape))
print("After OverSampling, counts of label '1': {}".format(sum(y_train_res == 1)))
print("After OverSampling, counts of label '0': {}".format(sum(y_train_res == 0)))

# Initialize a new Logistic Regression model
lr1 = LogisticRegression()

# Train the new model on the balanced (oversampled) training data
lr1.fit(X_train_res, y_train_res.ravel())

# Make predictions on the original test set
predictions = lr1.predict(X_test)

# Print the classification report for the model trained on SMOTE data
print("--- Results after SMOTE Oversampling ---")
print(classification_report(y_test, predictions))


# --- Handling Imbalance with NearMiss (Undersampling) ---

# Display the class counts before applying undersampling
print("Before Undersampling, counts of label '1': {}".format(sum(y_train == 1)))
print("Before Undersampling, counts of label '0': {} \n".format(sum(y_train == 0)))

# Initialize the NearMiss undersampling algorithm
nr = NearMiss()

# Apply NearMiss to the training data to reduce the number of majority class samples
X_train_miss, y_train_miss = nr.fit_resample(X_train, y_train.ravel())

# Print the shape and class distribution of the newly undersampled training data
print('After Undersampling, the shape of train_X: {}'.format(X_train_miss.shape))
print('After Undersampling, the shape of train_y: {} \n'.format(y_train_miss.shape))
print("After Undersampling, counts of label '1': {}".format(sum(y_train_miss == 1)))
print("After Undersampling, counts of label '0': {}".format(sum(y_train_miss == 0)))

# Initialize a third Logistic Regression model
lr2 = LogisticRegression()

# Train the model on the balanced (undersampled) training data
lr2.fit(X_train_miss, y_train_miss.ravel())

# Make predictions on the original test set
predictions = lr2.predict(X_test)

# Print the classification report for the model trained on NearMiss data
print("--- Results after NearMiss Undersampling ---")
print(classification_report(y_test, predictions))"""


knn_nb_svm_text = """# --- Common Imports and Data Preparation ---

# Import necessary libraries
import pandas as pd
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.metrics import confusion_matrix, classification_report

# Load the Iris dataset, a classic dataset in machine learning
iris1 = datasets.load_iris()

# --- Inspect the Dataset ---

# Check the dimensions of the data (samples, features)
print("--- Iris Dataset Shape ---")
print(iris1.data.shape) # Expected output: (150, 4)

# Display the names of the features (columns)
print("--- Iris Feature Names ---")
print(iris1.feature_names)

# Display the names of the target classes (types of iris flowers)
print("--- Iris Target Names ---")
print(iris1.target_names)
print("" + "="*50 + "\n")


# --- Data Splitting ---

# Assign feature data to 'x' and target data to 'y'
x = iris1.data
y = iris1.target

# Split the dataset into training and testing sets
# 70% for training, 30% for testing
# stratify=y ensures that the proportion of classes is the same in train and test sets
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.3, random_state=42, stratify=y)

# --- K-Nearest Neighbors (KNN) Classifier ---

# Model 1: n_neighbors=6, metric='minkowski', p=2 (Euclidean distance)
print("--- KNN Model 1 (k=6, Euclidean) ---")
knn1 = KNeighborsClassifier(n_neighbors=6, metric='minkowski', p=2)
knn1.fit(x_train, y_train)
y_predict_knn1 = knn1.predict(x_test)
print(f"Score: {knn1.score(x_test, y_test)}\n") # Expected score: ~0.955

# Model 2: n_neighbors=20, metric='minkowski', p=2 (Euclidean distance)
print("--- KNN Model 2 (k=20, Euclidean) ---")
knn2 = KNeighborsClassifier(n_neighbors=20, metric='minkowski', p=2)
knn2.fit(x_train, y_train)
y_predict_knn2 = knn2.predict(x_test)
print(f"Score: {knn2.score(x_test, y_test)}\n") # Expected score: ~0.933

# Model 3: n_neighbors=6, metric='minkowski', p=1 (Manhattan distance)
print("--- KNN Model 3 (k=6, Manhattan) ---")
knn3 = KNeighborsClassifier(n_neighbors=6, metric='minkowski', p=1)
knn3.fit(x_train, y_train)
y_predict_knn3 = knn3.predict(x_test)
print(f"Score: {knn3.score(x_test, y_test)}\n") # Expected score: ~0.888
print("" + "="*50 + "\n")


# --- Gaussian Naïve Bayes Classifier ---
print("--- Gaussian Naïve Bayes Model ---")
gnb1 = GaussianNB()
# Fit the model and predict on the test data in one line
y_pred_gnb = gnb1.fit(x_train, y_train).predict(x_test)

# Evaluate the model's accuracy
print(f"Score: {gnb1.score(x_test, y_test)}\n") # Expected score: ~0.911

# Display the confusion matrix to see where the model made errors
print("--- Confusion Matrix ---")
print(confusion_matrix(y_test, y_pred_gnb))
print("")

# Display a detailed classification report (precision, recall, f1-score)
print("--- Classification Report ---")
print(classification_report(y_test, y_pred_gnb))
print("" + "="*50 + "\n")


# --- Support Vector Machine (SVM) Classifier ---

# Model 1: Linear Kernel with 'ovo' (one-vs-one) decision function
print("--- SVM Model 1 (Linear Kernel, ovo) ---")
svc1 = SVC(kernel='linear', random_state=0, decision_function_shape='ovo')
svc1.fit(x_train, y_train)
preds1 = svc1.predict(x_test)
print(f"Predictions: {preds1}")
print(f"Score: {svc1.score(x_test, y_test)}\n") # Expected score: 1.0

# Model 2: Linear Kernel with 'ovr' (one-vs-rest) decision function
print("--- SVM Model 2 (Linear Kernel, ovr) ---")
svc2 = SVC(kernel='linear', random_state=0, decision_function_shape='ovr')
svc2.fit(x_train, y_train)
preds2 = svc2.predict(x_test)
print(f"Score: {svc2.score(x_test, y_test)}\n") # Expected score: 1.0

# Model 3: RBF Kernel with high gamma (gamma=0.7)
# High gamma can lead to overfitting
print("--- SVM Model 3 (RBF Kernel, gamma=0.7) ---")
svc3 = SVC(kernel='rbf', gamma=0.7, C=1.0)
svc3.fit(x_train, y_train)
preds3 = svc3.predict(x_test)
print(f"Score: {svc3.score(x_test, y_test)}\n") # Expected score: ~0.977

# Model 4: RBF Kernel with lower gamma (gamma=0.2)
# Lower gamma creates a smoother decision boundary
print("--- SVM Model 4 (RBF Kernel, gamma=0.2) ---")
svc4 = SVC(kernel='rbf', gamma=0.2, C=1.0)
svc4.fit(x_train, y_train)
preds4 = svc4.predict(x_test)
print(f"Score: {svc4.score(x_test, y_test)}\n") # Expected score: 1.0

# Model 5: RBF Kernel with lower gamma (0.2) and smaller C (0.2)
# A smaller C value creates a wider margin, allowing for more misclassifications
print("--- SVM Model 5 (RBF Kernel, gamma=0.2, C=0.2) ---")
svc5 = SVC(kernel='rbf', gamma=0.2, C=0.2)
svc5.fit(x_train, y_train)
preds5 = svc5.predict(x_test)
print(f"Score: {svc5.score(x_test, y_test)}\n") # Expected score: ~0.933"""


lab1_text = """# --- Library Imports ---

# Import necessary libraries for data manipulation, analysis, and visualization
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sb

# Import scikit-learn modules for datasets, modeling, and evaluation
from sklearn.datasets import load_wine
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score


# --- Data Loading and Initial Exploration ---

# Load the built-in wine dataset
wine1 = load_wine()

# Check the shape of the dataset (number of samples, number of features)
print(wine1.data.shape)

# Display the names of the features (columns)
print(wine1.feature_names)

# Display the names of the target classes
print(wine1.target_names)

# Create a pandas DataFrame from the dataset for easier analysis
wineDF = pd.DataFrame(wine1.data, columns=wine1.feature_names)

# Add the target labels as a new column to the DataFrame
wineDF['target'] = wine1.target


# --- Data Visualization and Correlation Analysis ---

# Create a scatter plot matrix to visualize pairwise relationships between all features
# Points are colored by their target class
pd.plotting.scatter_matrix(wineDF, c=wine1.target, figsize=[11, 11], s=150)
plt.show()

# Calculate the correlation matrix for all features and the target
cor1 = wineDF.corr()

# Display the correlation matrix
print(cor1)

# Generate a heatmap to visually represent the correlation matrix
sb.heatmap(cor1)
plt.show()


# --- Data Preparation for Modeling ---

# Separate the features (x) and the target variable (y)
x = wine1.data
y = wine1.target

# Split the data into training (70%) and testing (30%) sets
# 'stratify=y' ensures the class proportions are maintained in both sets
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.3, random_state=42, stratify=y)


# --- Model 1: Decision Tree Classifier ---

# Initialize the Decision Tree classifier model
tree1 = DecisionTreeClassifier()

# Train (fit) the model using the training data
tree1.fit(x_train, y_train)

# Use the trained model to make predictions on the test data
pre1 = tree1.predict(x_test)

# Calculate and print the accuracy of the model
print(f"Decision Tree Accuracy: {accuracy_score(y_test, pre1)}")

# Print the detailed classification report (precision, recall, f1-score)
print("Decision Tree Classification Report:")
print(classification_report(y_test, pre1))

# Print the confusion matrix
print("Decision Tree Confusion Matrix:")
print(confusion_matrix(y_test, pre1))

# Visualize the structure of the trained decision tree
plt.figure(figsize=(20,10)) # Set figure size for better readability
plot_tree(tree1, feature_names=wine1.feature_names, class_names=wine1.target_names, filled=True)
plt.show()


# --- Model 2: K-Nearest Neighbors (KNN) Classifier ---

# --- KNN with k=6 ---
# Initialize the KNN classifier with 6 neighbors
knn1 = KNeighborsClassifier(n_neighbors=6, metric='minkowski', p=2)
knn1.fit(x_train, y_train)
print(f"\nKNN (k=6) Accuracy: {knn1.score(x_test, y_test)}")

# --- KNN with k=8 ---
# Initialize the KNN classifier with 8 neighbors
knn2 = KNeighborsClassifier(n_neighbors=8, metric='minkowski', p=2)
knn2.fit(x_train, y_train)
print(f"KNN (k=8) Accuracy: {knn2.score(x_test, y_test)}")

# --- KNN with k=10 ---
# Initialize the KNN classifier with 10 neighbors
knn3 = KNeighborsClassifier(n_neighbors=10, metric='minkowski', p=2)
knn3.fit(x_train, y_train)
y_predict3 = knn3.predict(x_test)
print(f"KNN (k=10) Accuracy: {knn3.score(x_test, y_test)}")

# Print the confusion matrix for the KNN model with k=10
print("KNN (k=10) Confusion Matrix:")
print(confusion_matrix(y_test, y_predict3))"""


reg_text = """# --- Library Imports ---

# Import necessary libraries for data handling, plotting, and machine learning
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.datasets import load_wine
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import confusion_matrix, classification_report, mean_squared_error
from sklearn.preprocessing import normalize


# --- Linear Regression Example ---

# --- 1. Data Creation and Visualization ---

# Create sample data using NumPy arrays for a simple linear relationship
x1 = np.arange(1, 10)
y1 = np.array([23, 34, 44, 56, 65, 67, 70, 76, 79]) # Note: y1 is redefined in the PDF later, using the values from the plot for consistency.

# Create a scatter plot to visualize the initial data points
plt.scatter(x1, y1)
plt.show()

# --- 2. Data Preparation ---

# Reshape the 1D arrays into 2D column vectors, as required by scikit-learn
x1 = x1.reshape(-1, 1)
y1 = y1.reshape(-1, 1) # Note: The PDF shows different values for y1 here. This code reflects the reshape action.

# --- 3. Model Training and Prediction ---

# Initialize the Linear Regression model
reg1 = LinearRegression()

# Train (fit) the model using the prepared data
reg1.fit(x1, y1)

# Use the trained model to make predictions on the original x-values
y_pred = reg1.predict(x1)

# --- 4. Evaluation and Visualization ---

# Plot the original data points (blue) and the model's predictions (orange)
plt.scatter(x1, y1)
plt.scatter(x1, y_pred)
plt.show()

# Calculate the Mean Squared Error (MSE) to evaluate the model's performance
mse1 = mean_squared_error(y1, y_pred)
print(f"Mean Squared Error: {mse1}")


# --- K-Fold Cross-Validation for Linear Regression ---

# Perform 4-fold cross-validation using the default scoring metric (R-squared)
cv_score_r2 = cross_val_score(reg1, x1, y1, cv=4)
print(f"\nCross-Validation R2 Scores: {cv_score_r2}")
print(f"Mean R2 Score: {np.mean(cv_score_r2)}")

# Perform 4-fold cross-validation using negative mean squared error as the scoring metric
cv_score_neg_mse = cross_val_score(reg1, x1, y1, cv=4, scoring='neg_mean_squared_error')
print(f"\nCross-Validation Negative MSE Scores: {cv_score_neg_mse}")
print(f"Mean Negative MSE: {np.mean(cv_score_neg_mse)}")

# Perform 4-fold cross-validation using negative root mean squared error
cv_score_neg_rmse = cross_val_score(reg1, x1, y1, cv=4, scoring='neg_root_mean_squared_error')
print(f"\nCross-Validation Negative RMSE Scores: {cv_score_neg_rmse}")
print(f"Mean Negative RMSE: {np.mean(cv_score_neg_rmse)}")


# --- Logistic Regression Example ---

# --- 1. Data Loading and Preparation ---

# Load the built-in Wine dataset
data1 = load_wine()

# Create a pandas DataFrame from the wine data for easier manipulation
wineDF = pd.DataFrame(data1.data, columns=data1.feature_names)
wineDF['target'] = data1.target

# Separate the features (x) and the target variable (y)
x = data1.data
y = data1.target

# Split the data into training (70%) and testing (30%) sets
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.3, random_state=42)

# --- 2. Model Training and Prediction ---

# Initialize the Logistic Regression model
reg2 = LogisticRegression(max_iter=2500) # Increased max_iter to address convergence warning in PDF

# Train the model on the training data
reg2.fit(x_train, y_train)

# Make predictions on the test data
pre2 = reg2.predict(x_test)

# --- 3. Evaluation ---

# Generate the confusion matrix to evaluate the classification accuracy
cm = confusion_matrix(y_test, pre2)
print("--- Logistic Regression Results ---")
print("Confusion Matrix:")
print(cm)

# Normalize the confusion matrix by row (using L1 norm) to see proportions
cm1 = normalize(cm, norm='l1', axis=1)

# Create a DataFrame from the normalized matrix for better readability
cm1Df = pd.DataFrame(cm1, columns=data1.target_names, index=data1.target_names)
print("Normalized Confusion Matrix:")
print(cm1Df)"""


scipy_text = """# Import necessary libraries
# pandas for data manipulation and analysis
import pandas as pd
# numpy for numerical operations
import numpy as np
# matplotlib.pyplot for plotting graphs
import matplotlib.pyplot as plt
# seaborn for statistical data visualization
import seaborn as sb
# scipy.stats for statistical functions
from scipy.stats import pearsonr, spearmanr, chi2_contingency

# --- DATASET 1: Weather Data ---

# Load the first dataset from a CSV file into a pandas DataFrame
# Note: You will need to replace the file path with the actual location of your 'Weather1.csv' file.
# data1 = pd.read_csv('path/to/your/Weather1.csv')
# The path from the document is used here as a placeholder.
data1 = pd.read_csv('F:/00-Douglas College/1- Semester 1/3- Machine Learning in Data Science (3290)/Slides/Weather1.csv')

# Display the entire DataFrame to inspect the data
print("--- Weather Dataset Head ---")
print(data1)
print("" + "="*50 + "\n")


# --- Feature Analysis: Humidity ---

# Access and print the 'Humidity' column (feature) of the DataFrame
print("--- Humidity Column ---")
print(data1.Humidity)
print("" + "="*50 + "\n")

# Calculate and print the mean (average) of the 'Humidity' column
humidity_mean = np.mean(data1.Humidity)
print(f"Mean of Humidity: {humidity_mean}")

# Calculate and print the standard deviation of the 'Humidity' column
humidity_std = np.std(data1.Humidity)
print(f"Standard Deviation of Humidity: {humidity_std}")
print("" + "="*50 + "\n")

# Count the occurrences of each unique value in the 'Humidity' column and print it
print("--- Value Counts for Humidity ---")
print(data1.Humidity.value_counts())
print("" + "="*50 + "\n")


# --- Data Visualization ---

# Generate a pairplot to visualize relationships between all numerical variables in the DataFrame
# Histograms are shown on the diagonal, and scatter plots for pairs of variables are shown on the off-diagonal
print("--- Generating Pairplot of Weather Data ---")
sb.pairplot(data1)
# Display the generated plot
plt.show()


# --- Correlation Analysis ---

# Calculate the Pearson correlation coefficient and the p-value between 'Temperature' and 'Humidity'
# This measures the linear relationship between the two variables.
cor1_pearson = pearsonr(data1.Temperature, data1.Humidity)
print(f"--- Pearson Correlation (Temperature vs Humidity) ---\n{cor1_pearson}\n")

# Calculate the Spearman rank-order correlation coefficient and the p-value between 'WindBearing' and 'WindSpeed'
# This measures the monotonic relationship between two variables.
sp1_spearman = spearmanr(data1.WindBearing, data1.WindSpeed)
print(f"--- Spearman Correlation (WindBearing vs WindSpeed) ---\n{sp1_spearman}\n")

# Compute the pairwise correlation of all columns in the DataFrame using the Pearson method by default
correlation_matrix = data1.corr()
print("--- Full Correlation Matrix (Pearson) ---")
print(correlation_matrix)
print("" + "="*50 + "\n")

# Visualize the correlation matrix using a heatmap
# This provides a color-coded overview of the relationships between variables
print("--- Generating Heatmap of Correlation Matrix ---")
sb.heatmap(correlation_matrix)
# Display the generated plot
plt.show()


# --- DATASET 2: Smartphone Data & Chi-Square Test ---

# Load the second dataset from a CSV file into a new DataFrame
# Note: You will need to replace the file path with the actual location of your 'smartphone.csv' file.
# data2 = pd.read_csv('path/to/your/smartphone.csv')
# The path from the document is used here as a placeholder.
data2 = pd.read_csv('F:/00-Douglas College/1- Semester 1/3- Machine Learning in Data Science (3290)/Slides/smartphone.csv')

# Display the first 5 rows of the new DataFrame to inspect it
print("--- Smartphone Dataset Head ---")
print(data2.head())
print("" + "="*50 + "\n")

# Create a contingency table (crosstab) of two categorical variables: 'Brand' and 'Ram'
# This table shows the frequency distribution of the variables.
contingency_table = pd.crosstab(data2.Brand, data2.Ram)
print("--- Contingency Table (Brand vs Ram) ---")
print(contingency_table)
print("" + "="*50 + "\n")

# Perform the Chi-Square test of independence on the contingency table
# This test determines if there is a significant association between the two categorical variables.
chi2, p_value, dof, expected = chi2_contingency(contingency_table.values)

# Print the results of the Chi-Square test
print("--- Chi-Square Test Results ---")
print(f"Chi-Square Statistic: {chi2}")
print(f"P-value: {p_value}")
print(f"Degrees of Freedom: {dof}")
print("--- Expected Frequencies ---")
print(expected)
print("" + "="*50 + "\n")"""


midterm_text = """# --- Library Imports ---

import pandas as pd
import seaborn as sb
import matplotlib.pyplot as plt
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from sklearn.feature_selection import SelectKBest
from sklearn.metrics import confusion_matrix, classification_report


# --- Task 1: Data Loading and Descriptive Analysis ---

# Load the breast cancer dataset from scikit-learn
cancer1 = load_breast_cancer()

# 1. Print the dimensions of the feature data and target data
print("Data shape:", cancer1.data.shape)
print("Target shape:", cancer1.target.shape)

# 2. Print the names of the features (columns)
print("Feature names:", cancer1.feature_names)

# 3. Print the target values (0 or 1 for cancer diagnosis)
print("Target values:", cancer1.target)

# 4. Convert the dataset into a pandas DataFrame for easier manipulation
df = pd.DataFrame(cancer1.data, columns=cancer1.feature_names)
df['target'] = cancer1.target

# 5. Split the data into training (75%) and testing (25%) sets
x = cancer1.data
y = cancer1.target
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.25, random_state=42, stratify=y)

# 6. Calculate the correlation matrix for all attributes in the DataFrame
cor1 = df.corr()

# 7. Plot a heatmap to visualize the correlation matrix
sb.heatmap(cor1)
plt.show()

# 8. Plot 'mean radius' vs. 'mean perimeter' and 'mean radius' vs. 'worst symmetry'
# First plot: mean radius vs mean perimeter (shows a strong linear relationship)
plt.plot(df["mean radius"], df["mean perimeter"], ls='-')
plt.grid()
plt.legend(['mean radius vs mean perimeter'])
plt.show()

# Second plot: mean radius vs worst symmetry (shows a weaker, more scattered relationship)
plt.plot(df["mean radius"], df["worst symmetry"], ls='--')
plt.grid()
plt.legend(['mean radius vs worst symmetry'])
plt.show()


# --- Task 2: Classification ---

# 1 & 2. Implement and evaluate the Decision Tree Classifier
tree1 = DecisionTreeClassifier()
tree1.fit(x_train, y_train)
pred_tree1 = tree1.predict(x_test)
print(f"Decision Tree Accuracy: {tree1.score(x_test, y_test)}")

# 3. Show the confusion matrix and classification report for the Decision Tree
print("Decision Tree Confusion Matrix:")
print(confusion_matrix(y_test, pred_tree1))
print("Decision Tree Classification Report:")
print(classification_report(y_test, pred_tree1))

# 4. Draw the trained decision tree
plt.figure(figsize=(20, 10)) # Added for better readability
plot_tree(tree1, feature_names=cancer1.feature_names, class_names=cancer1.target_names, filled=True)
plt.show()

# 5, 6, & 7. Implement and evaluate KNN for k=2 and k=10
# KNN with k=2
knn1 = KNeighborsClassifier(n_neighbors=2, metric='minkowski', p=2)
knn1.fit(x_train, y_train)
pred_knn1 = knn1.predict(x_test)
print(f"\nKNN (k=2) Accuracy: {knn1.score(x_test, y_test)}")
print("KNN (k=2) Confusion Matrix:")
print(confusion_matrix(y_test, pred_knn1))
print("KNN (k=2) Classification Report:")
print(classification_report(y_test, pred_knn1))

# KNN with k=10
knn2 = KNeighborsClassifier(n_neighbors=10, metric='minkowski', p=2)
knn2.fit(x_train, y_train)
pred_knn2 = knn2.predict(x_test)
print(f"\nKNN (k=10) Accuracy: {knn2.score(x_test, y_test)}")
print("KNN (k=10) Confusion Matrix:")
print(confusion_matrix(y_test, pred_knn2))
print("KNN (k=10) Classification Report:")
print(classification_report(y_test, pred_knn2))


# --- Task 3: Modeling and Feature Importance ---

# 1, 2, & 3. Implement and evaluate Random Forest for max_depth=4 and max_depth=6
# Random Forest with max_depth=4
rf1 = RandomForestClassifier(max_depth=4)
rf1.fit(x_train, y_train)
pred_rf1 = rf1.predict(x_test)
print(f"\nRandom Forest (depth=4) Accuracy: {rf1.score(x_test, y_test)}")
print("Random Forest (depth=4) Confusion Matrix:")
print(confusion_matrix(y_test, pred_rf1))
print("Random Forest (depth=4) Classification Report:")
print(classification_report(y_test, pred_rf1))

# Random Forest with max_depth=6
rf2 = RandomForestClassifier(max_depth=6)
rf2.fit(x_train, y_train)
pred_rf2 = rf2.predict(x_test)
print(f"\nRandom Forest (depth=6) Accuracy: {rf2.score(x_test, y_test)}")
print("Random Forest (depth=6) Confusion Matrix:")
print(confusion_matrix(y_test, pred_rf2))
print("Random Forest (depth=6) Classification Report:")
print(classification_report(y_test, pred_rf2))


# 4, 5, & 6. Implement and evaluate AdaBoost Classifier
ada1 = AdaBoostClassifier(n_estimators=50, learning_rate=0.2)
ada1.fit(x_train, y_train)
pred_ada1 = ada1.predict(x_test)
print(f"\nAdaBoost Accuracy: {ada1.score(x_test, y_test)}")
print("AdaBoost Confusion Matrix:")
print(confusion_matrix(y_test, pred_ada1))
print("AdaBoost Classification Report:")
print(classification_report(y_test, pred_ada1))


# 7 & 8. Calculate and show feature importances
print("Feature importances from Random Forest (depth=4):", rf1.feature_importances_)
print("Feature importances from Random Forest (depth=6):", rf2.feature_importances_)
print("Feature importances from AdaBoost:", ada1.feature_importances_)


# 9. Plot the feature importances in horizontal bar charts
# For Random Forest (depth=4)
plt.barh(cancer1.feature_names, sorted(rf1.feature_importances_))
plt.title("Feature importances of Random Forest Classifier with max depth of 4")
plt.show()

# For Random Forest (depth=6)
plt.barh(cancer1.feature_names, sorted(rf2.feature_importances_))
plt.title("Feature importances of Random Forest Classifier with max depth of 6")
plt.show()

# For AdaBoost
plt.barh(cancer1.feature_names, sorted(ada1.feature_importances_))
plt.title("Feature importances of AdaBoost Classifier")
plt.show()


# 10. Select the three and six most important features using SelectKBest
# Select three most important features
selector1 = SelectKBest(k=3)
selector1.fit(x_train, y_train)
x_train_selected3 = selector1.transform(x_train)
x_test_selected3 = selector1.transform(x_test)
selected3_feature_names = cancer1.feature_names[selector1.get_support()]
print(f"\nShape with 3 best features: {x_train_selected3.shape}")
print(f"Top 3 feature names: {selected3_feature_names}")


# Select six most important features
selector2 = SelectKBest(k=6)
selector2.fit(x_train, y_train)
x_train_selected6 = selector2.transform(x_train)
x_test_selected6 = selector2.transform(x_test)
selected6_feature_names = cancer1.feature_names[selector2.get_support()]
print(f"\nShape with 6 best features: {x_train_selected6.shape}")
print(f"Top 6 feature names: {selected6_feature_names}")"""


assign2_text = """# --- Library Imports ---

# Import necessary libraries for data handling, modeling, and evaluation
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix


# --- Data Loading and Exploration ---

# Load the heart disease dataset from a local CSV file
df = pd.read_csv('C:/Users/Xiangru/Downloads/heart2 1.csv')

# Display a summary of the DataFrame, including data types and non-null counts
df.info()

# Generate descriptive statistics for the numerical columns
df.describe()

# Display the first few rows of the dataset to inspect the data
df.head()

# Check the distribution of the target variable to see class balance
df['target'].value_counts()


# --- Data Partitioning ---

# Separate the features (X) from the target labels (y)
x = df.drop(columns=['target'])
y = df['target']

# Split the data into training (80%) and testing (20%) sets
# random_state=42 is used for reproducibility
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)


# --- Model 1: Support Vector Machine (SVM) ---

# --- Linear SVM ---
# Initialize and train a linear SVM with C=1.0 for a balance between fitting and generalization
C = 1.0
svc1 = SVC(kernel='linear', C=C).fit(x_train, y_train)
# Make predictions on the test set
y_pred_svc1 = svc1.predict(x_test)
# Evaluate the model
print('Accuracy of Linear SVM: {:.2f}'.format(accuracy_score(y_test, y_pred_svc1)))
print(confusion_matrix(y_test, y_pred_svc1))
print(classification_report(y_test, y_pred_svc1))

# --- RBF Kernel SVM ---
# Initialize and train an RBF kernel SVM. gamma=0.02 is chosen for moderate influence
rbf_svc = SVC(kernel='rbf', gamma=0.02, C=C).fit(x_train, y_train)
# Make predictions on the test set
y_pred_rbf = rbf_svc.predict(x_test)
# Evaluate the model
print('Accuracy of RBF: {:.2f}'.format(accuracy_score(y_test, y_pred_rbf)))
print(confusion_matrix(y_test, y_pred_rbf))
print(classification_report(y_test, y_pred_rbf))

# --- Polynomial Kernel SVM ---
# Initialize and train a Polynomial kernel SVM with degree=7 for a flexible decision boundary
poly_svc = SVC(kernel='poly', degree=7, C=C).fit(x_train, y_train)
# Make predictions on the test set
y_pred_poly = poly_svc.predict(x_test)
# Evaluate the model
print('Accuracy of Polynomial: {:.2f}'.format(accuracy_score(y_test, y_pred_poly)))
print(confusion_matrix(y_test, y_pred_poly))
print(classification_report(y_test, y_pred_poly))


# --- Model 2: Naïve Bayes ---

# Initialize the Gaussian Naïve Bayes model
gnb1 = GaussianNB()
# Train the model and make predictions on the test set
predNB = gnb1.fit(x_train, y_train).predict(x_test)
# Evaluate the model's performance
print(gnb1.score(x_test, y_test))
print(confusion_matrix(y_test, predNB))
print(classification_report(y_test, predNB))


# --- Model 3: K-Nearest Neighbors (KNN) ---

# Initialize the KNN model with 4 neighbors and Euclidean distance (p=2)
knn1 = KNeighborsClassifier(n_neighbors=4, metric='minkowski', p=2)
# Train the model on the training data
knn1.fit(x_train, y_train)
# Make predictions on the test set
y_predict = knn1.predict(x_test)
# Evaluate the model's performance
print(knn1.score(x_test, y_test))
print(confusion_matrix(y_test, y_predict))
print(classification_report(y_test, y_predict))"""


ml_clf_text = """# --- Imports ---
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sb

from sklearn.datasets import load_iris, load_wine, load_breast_cancer
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score, mean_squared_error


# --- Data Loading and Preparation ---
data = load_iris()
x = data.data
y = data.target

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.3, random_state=42, stratify=y)


# --- Imbalanced Data Handling (Optional) ---
# SMOTE (Over-sampling): sampling_strategy='auto'/'minority', k_neighbors=5
smote = SMOTE(random_state=42)
x_train_smote, y_train_smote = smote.fit_resample(x_train, y_train)

# NearMiss (Under-sampling): version=1/2/3, n_neighbors=3
nearmiss = NearMiss(version=1)
x_train_nm, y_train_nm = nearmiss.fit_resample(x_train, y_train)


# --- Model Instantiation ---
# KNN: n_neighbors=6/20, metric='minkowski', p=1(Manhattan)/2(Euclidean)
knn1 = KNeighborsClassifier(n_neighbors=6, metric='minkowski', p=2)

# Gaussian Naive Bayes: no hyperparameters
gnb1 = GaussianNB()

# SVM: kernel='linear'/'rbf'/'poly', gamma=0.2/0.7, C=0.2/1.0, decision_function_shape='ovo'/'ovr', degree=7(for poly)
svc1 = SVC(kernel='linear', random_state=0, decision_function_shape='ovr')

# Decision Tree: max_depth, criterion='gini'/'entropy'
tree1 = DecisionTreeClassifier()

# Logistic Regression: max_iter=2500, C, solver
logreg1 = LogisticRegression(max_iter=2500)


# --- Fit ---
knn1.fit(x_train, y_train)

# Option 2: With SMOTE
# knn1.fit(x_train_smote, y_train_smote)

# Option 3: With NearMiss
# knn1.fit(x_train_nm, y_train_nm)


# --- Predict ---
y_pred_knn1 = knn1.predict(x_test)


# --- Evaluation: Accuracy ---
print(f"KNN: {knn1.score(x_test, y_test)}")

# --- Evaluation: K-Fold Cross Validation ---
# cv=4/5/10, scoring='accuracy'/'precision'/'recall'/'f1'/'neg_mean_squared_error'
cv_scores = cross_val_score(knn1, x_train, y_train, cv=4)
print(f"Cross-Validation Scores: {cv_scores}")
print(f"Mean CV Score: {np.mean(cv_scores)}")


# --- Evaluation: Confusion Matrix ---
print(confusion_matrix(y_test, y_pred_knn1))


# --- Evaluation: Classification Report ---
print(classification_report(y_test, y_pred_knn1))"""


ml_clf_all_text = """# --- Imports ---
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sb
import shap
from xgboost import XGBClassifier

from sklearn.datasets import load_iris, load_wine, load_breast_cancer
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.decomposition import PCA
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, BaggingClassifier, AdaBoostClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score
from imblearn.over_sampling import SMOTE
from imblearn.under_sampling import NearMiss

# --- Data Loading and Preparation ---
# Load data (Change as needed)
data = load_iris()
# data = load_wine()
# data = load_breast_cancer()

x = data.data
y = data.target
feature_names = list(data.feature_names) # Convert to list to allow modification later

# Split data (Stratify maintains class ratios)
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.3, random_state=42, stratify=y)


# ==========================================
# --- Preprocessing Steps (Flattened) ---
# Uncomment necessary steps to enable
# Order: Split -> Imbalance -> Scaling -> PCA -> Model
# ==========================================

# 1. Imbalanced Data Handling
# --- SMOTE (Over-sampling) ---
# smote = SMOTE(random_state=42)
# x_train, y_train = smote.fit_resample(x_train, y_train)

# --- NearMiss (Under-sampling) ---
# nearmiss = NearMiss(version=1)
# x_train, y_train = nearmiss.fit_resample(x_train, y_train)


# 2. Scaling
# Almost mandatory for models involving distance calculations like KNN, SVM, LogisticRegression, PCA
scaler = StandardScaler() # or MinMaxScaler()
x_train = scaler.fit_transform(x_train)
x_test = scaler.transform(x_test) # Transform only for Test data (Do not Fit)


# 3. Dimensionality Reduction (PCA)
# --- PCA ---
# n_components = 2
# pca = PCA(n_components=n_components)
# x_train = pca.fit_transform(x_train)
# x_test = pca.transform(x_test)
# # Update feature names if PCA is used (for plotting)
# feature_names = [f'PC{i+1}' for i in range(n_components)]


# ==========================================
# --- Model Instantiation (Select ONE) ---
# ==========================================

# model = KNeighborsClassifier(n_neighbors=6)
# model = LogisticRegression(max_iter=2500)
# model = GaussianNB()
# model = SVC(kernel='linear', probability=True, random_state=42) # Kernel: 'rbf', 'poly'
# model = DecisionTreeClassifier(max_depth=3)
model = RandomForestClassifier(n_estimators=100, max_depth=4, random_state=42)
# model = BaggingClassifier(estimator=DecisionTreeClassifier(), n_estimators=20, random_state=42)
# model = AdaBoostClassifier(n_estimators=50, learning_rate=0.2, random_state=42)
# model = XGBClassifier(n_estimators=100, learning_rate=0.05, use_label_encoder=False, eval_metric='logloss')


# --- Fit & Predict ---
model.fit(x_train, y_train)
y_pred = model.predict(x_test)


# --- Evaluation ---
print(f"Model: {model.__class__.__name__}")
print(f"Accuracy: {accuracy_score(y_test, y_pred)}")
print(f"CV Score (Mean): {np.mean(cross_val_score(model, x_train, y_train, cv=5))}")
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))
print("Classification Report:\n", classification_report(y_test, y_pred))


# --- Feature Importance (Tree-based Models Only) ---
# If PCA is used, importances correspond to PC1, PC2..., not original features
if hasattr(model, 'feature_importances_') or (isinstance(model, BaggingClassifier) and hasattr(model.estimators_[0], 'feature_importances_')):
    if isinstance(model, BaggingClassifier):
        importances = np.mean([tree.feature_importances_ for tree in model.estimators_], axis=0)
    else:
        importances = model.feature_importances_

    indices = np.argsort(importances)
    
    plt.figure(figsize=(8, 4))
    plt.title(f'Feature Importances ({model.__class__.__name__})')
    plt.barh(range(len(indices)), importances[indices], align='center')
    # Check if feature count matches before plotting
    if len(indices) == len(feature_names):
        plt.yticks(range(len(indices)), np.array(feature_names)[indices])
    else:
        plt.yticks(range(len(indices)), indices) # Show index numbers if names do not match
    plt.tight_layout()
    plt.show()


# --- SHAP Visualization (Tree-based Models Only) ---
# TreeExplainer works only for Tree-based models (Recommend commenting out for SVM or KNN to avoid errors)
# If PCA is used, SHAP values represent contribution to principal components
try:
    if hasattr(model, 'feature_importances_') or "XGB" in str(model):
        explainer = shap.TreeExplainer(model)
        # For large datasets, use shap.sample(x_test, 100) instead of x_test for speed
        shap_values = explainer.shap_values(x_test)
        
        print("SHAP Summary Plot:")
        # Adjust for classification cases where shap_values might be a list
        if isinstance(shap_values, list):
            shap.summary_plot(shap_values[1], x_test, feature_names=feature_names) # SHAP for Class 1
        else:
            shap.summary_plot(shap_values, x_test, feature_names=feature_names)
except Exception as e:
    print(f"SHAP visualization skipped: {e}")"""


ml_reg_text = """# --- Imports ---
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import mean_squared_error, r2_score


# --- Data Creation and Preparation ---
x1 = np.arange(1, 10)
y1 = np.array([23, 34, 44, 56, 65, 67, 70, 76, 79])

# Reshape for sklearn
x1 = x1.reshape(-1, 1)
y1 = y1.reshape(-1, 1)


# --- Model Instantiation ---
# Linear Regression: fit_intercept=True/False, normalize=False
reg1 = LinearRegression()


# --- Fit ---
reg1.fit(x1, y1)


# --- Predict ---
y_pred = reg1.predict(x1)


# --- Evaluation: MSE and R2 ---
print(f"Mean Squared Error: {mean_squared_error(y1, y_pred)}")
print(f"R2 Score: {r2_score(y1, y_pred)}")


# --- Evaluation: K-Fold Cross Validation ---
# cv=4/5/10, scoring='r2'/'neg_mean_squared_error'/'neg_root_mean_squared_error'/'neg_mean_absolute_error'
cv_score_r2 = cross_val_score(reg1, x1, y1, cv=4, scoring='r2')
print(f"Cross-Validation R2 Scores: {cv_score_r2}")
print(f"Mean R2 Score: {np.mean(cv_score_r2)}")

cv_score_neg_mse = cross_val_score(reg1, x1, y1, cv=4, scoring='neg_mean_squared_error')
print(f"Cross-Validation Negative MSE Scores: {cv_score_neg_mse}")
print(f"Mean Negative MSE: {np.mean(cv_score_neg_mse)}")

cv_score_neg_rmse = cross_val_score(reg1, x1, y1, cv=4, scoring='neg_root_mean_squared_error')
print(f"Cross-Validation Negative RMSE Scores: {cv_score_neg_rmse}")
print(f"Mean Negative RMSE: {np.mean(cv_score_neg_rmse)}")"""


final_text = """
# --- Library Imports ---
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier, AdaBoostRegressor
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from scipy.cluster.hierarchy import dendrogram, linkage
from sklearn.preprocessing import LabelEncoder

# ============================================================
# TASK 1: Descriptive Analysis
# ============================================================

# 1. Read the data and print the dimensions
data = pd.read_csv('Weather1.csv')
print("1. Dimensions:", data.shape)

# 2. Print the correlation among all attributes
print("2. Correlation Matrix:")
cor1 = data.corr(numeric_only=True)
print(cor1)

# 3. Plot the heatmap for correlation
plt.figure(figsize=(10, 8))
sns.heatmap(cor1, annot=True, cmap='coolwarm')
plt.title('Correlation Heatmap')
plt.show()

# 4. Print the columns' names
print("4. Column Names:")
print(data.columns.tolist())

# 5. Print the total number of missing values per each column
print("5. Missing Values per Column:")
print(data.isnull().sum())

# 6. Show the statistical measures per each column
print("6. Statistical Measures:")
print(data.describe())

# 7. Show the boxplot per all columns
plt.figure(figsize=(12, 6))
data.select_dtypes(include=[np.number]).boxplot()
plt.title('Boxplot of All Numeric Columns')
plt.xlabel('Columns')
plt.ylabel('Values')
plt.xticks(rotation=45)
plt.show()
print("Outliers Discussion: Columns with points outside whiskers have outliers.")

# 8. Show a scatter plot of Temperature versus Humidity
plt.figure(figsize=(8, 6))
plt.scatter(data['Temperature'], data['Humidity'])
plt.title('Temperature vs Humidity')
plt.xlabel('Temperature')
plt.ylabel('Humidity')
plt.show()

# 9. Show a histogram of the Summary with 10 bins
plt.figure(figsize=(10, 6))
data['Summary'].value_counts().plot(kind='bar')
plt.title('Histogram of Summary')
plt.xlabel('Summary')
plt.ylabel('Frequency')
plt.xticks(rotation=45)
plt.show()

# ============================================================
# INTEGRATED VISUALIZATIONS
# ============================================================

# --- 1. Line Plot (Trends over index/time) ---
# Reference: plt.plot(years, population)
# # Display the trend of Temperature based on the data order (assuming chronological order).
# print("--- Displaying Line Plot (Temperature Trend) ---")
# plt.figure(figsize=(10, 5))
# plt.plot(data['Temperature'], label='Temperature', color='orange')
# plt.title('Temperature Trend')
# plt.xlabel('Index (Time)')
# plt.ylabel('Temperature')
# plt.legend()
# plt.grid(True)
# plt.show()

# --- 2. Pie Chart (Proportion of Categories) ---
# Reference: plt.pie(city_Pop, labels=city_Name)
# # Display the proportion of Summary (weather types) using a pie chart.
# print("--- Displaying Pie Chart (Summary Proportion) ---")
# summary_counts = data['Summary'].value_counts()
# plt.figure(figsize=(8, 8))
# plt.pie(summary_counts, labels=summary_counts.index, startangle=140)
# plt.title('Weather Summary Distribution')
# plt.show()

# --- 3. Subplots (Multiple Plots in One Figure) ---
# Reference: plt.subplot(1, 2, 1)...
# # Display histograms of Temperature and Humidity side-by-side.
# print("--- Displaying Subplots (Temperature & Humidity) ---")
# plt.figure(figsize=(12, 5))
#
# # Subplot 1: Temperature
# plt.subplot(1, 2, 1)
# plt.hist(data['Temperature'], bins='auto', color='skyblue', edgecolor='black')
# plt.title('Temperature Distribution')
# plt.xlabel('Temperature')
#
# # Subplot 2: Humidity
# plt.subplot(1, 2, 2)
# plt.hist(data['Humidity'], bins='auto', color='lightgreen', edgecolor='black')
# plt.title('Humidity Distribution')
# plt.xlabel('Humidity')
#
# plt.show()

# --- 4. Seaborn Strip Plot (Categorical Scatter) ---
# Reference: sb.stripplot(x=..., y=..., data=...)
# # Visualize the numerical distribution (Temperature) for each categorical variable (Summary).
# print("--- Displaying Seaborn Strip Plot ---")
# plt.figure(figsize=(12, 6))
# sns.stripplot(x='Summary', y='Temperature', data=data, size=5, jitter=True)
# plt.title('Temperature by Weather Summary')
# plt.xticks(rotation=45)
# plt.show()

# --- 5. Seaborn Joint Plot (Scatter + Histogram) ---
# Reference: sb.jointplot(x=..., y=..., kind='scatter')
# # Check the correlation between two variables and their respective distributions simultaneously.
# print("--- Displaying Seaborn Joint Plot ---")
# sns.jointplot(x='Temperature', y='Humidity', data=data, kind='scatter', height=7)
# plt.show()



# ============================================================
# TASK 2: Classification
# ============================================================

# 1. Convert to dataframe and read the first five samples
df = pd.read_csv('Weather1.csv')
print("1. First Five Samples:")
print(df.head())

# 2. Consider Summary column as the target
# Encode Summary column (categorical to numeric)
le = LabelEncoder()
df['Summary_encoded'] = le.fit_transform(df['Summary'])

# Prepare X and y
X = df.drop(['Summary', 'Summary_encoded'], axis=1)
X = X.select_dtypes(include=[np.number])  # Keep only numeric columns
y = df['Summary_encoded']

# 3. Partition the data as 70-30
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# 4. Run Random Forest Regressor model
rf_reg = RandomForestRegressor(n_estimators=100, random_state=42)
rf_reg.fit(X_train, y_train)
pred_reg = rf_reg.predict(X_test)
print("4. Random Forest Regressor Score:", rf_reg.score(X_test, y_test))

# 5. Run Random Forest Classifier model
rf_clf = RandomForestClassifier(max_depth=4, oob_score=True, random_state=42)
rf_clf.fit(X_train, y_train)
pred_clf = rf_clf.predict(X_test)
print("5. Random Forest Classifier Score:", rf_clf.score(X_test, y_test))

# 6. Print predictors' names
print("6. Predictor Names:")
print(X.columns.tolist())

# 7. Calculate feature importance and show horizontal bar chart
importances = rf_clf.feature_importances_
plt.figure(figsize=(10, 6))
plt.barh(X.columns, importances)
plt.title('Feature Importance (Random Forest Classifier)')
plt.xlabel('Importance')
plt.ylabel('Features')
plt.show()

# 8. Run AdaBoost Regressor model
ada_reg = AdaBoostRegressor(n_estimators=50, learning_rate=0.2, random_state=42)
ada_reg.fit(X_train, y_train)
pred_ada = ada_reg.predict(X_test)
print("8. AdaBoost Regressor Score:", ada_reg.score(X_test, y_test))





# ============================================================
# TASK 3: Clustering
# ============================================================

# 1. Read the data and print the first five samples
data3 = pd.read_csv('Weather1.csv')
print("1. First Five Samples:")
print(data3.head())

# 2. Eliminate "Summary" column and print first five samples
data3 = data3.drop('Summary', axis=1)
data3 = data3.select_dtypes(include=[np.number])  # Keep only numeric
print("2. After Eliminating Summary:")
print(data3.head())

# 3. Run KMeans from 1 to 5 clusters, calculate WSS
wss = []
for k in range(1, 6):
    kmeans = KMeans(n_clusters=k, init='k-means++', max_iter=300, n_init=10, random_state=42)
    kmeans.fit(data3)
    wss.append(kmeans.inertia_)
print("3. WSS Values:", wss)

# 4. Plot the WSS values (Elbow Method)
plt.figure(figsize=(8, 5))
plt.plot(range(1, 6), wss, marker='o')
plt.title('Elbow Method - WSS vs Number of Clusters')
plt.xlabel('Number of Clusters (K)')
plt.ylabel('WSS (Inertia)')
plt.xticks(range(1, 6))
plt.grid(True)
plt.show()
print("Best K: The elbow point where WSS decrease slows down (likely K=2 or K=3)")

# 5. Run KMeans with best K (assuming K=3 based on elbow)
best_k = 3
kmeans_best = KMeans(n_clusters=best_k, init='k-means++', max_iter=300, n_init=10, random_state=42)
kmeans_best.fit(data3)

# 6. Print labels and cluster centers
print("6. Labels:", kmeans_best.labels_)
print("Cluster Centers:")
print(kmeans_best.cluster_centers_)

# 7. Plot the data points and centers
plt.figure(figsize=(10, 6))
plt.scatter(data3.iloc[:, 0], data3.iloc[:, 1], c=kmeans_best.labels_, cmap='viridis')
plt.scatter(kmeans_best.cluster_centers_[:, 0], kmeans_best.cluster_centers_[:, 1], 
            c='red', marker='X', s=200, label='Centers')
plt.title('KMeans Clustering')
plt.xlabel(data3.columns[0])
plt.ylabel(data3.columns[1])
plt.legend()
plt.show()

# 8. Calculate Silhouette score
sil_score = silhouette_score(data3, kmeans_best.labels_)
print("8. Silhouette Score:", sil_score)

# 9. Dendrogram with ward method and euclidean distance
# method type: single, complete, average, ward
# metric type: euclidean, cityblock, chebyshev, minkowski
plt.figure(figsize=(12, 6))
linkage_ward = linkage(data3, method='ward', metric='euclidean')
dendrogram(linkage_ward)
plt.title('Dendrogram (Ward Method, Euclidean Distance)')
plt.xlabel('Samples')
plt.ylabel('Distance')
plt.show()

# 10. Dendrogram with average method and euclidean distance
plt.figure(figsize=(12, 6))
linkage_avg = linkage(data3, method='average', metric='euclidean')
dendrogram(linkage_avg)
plt.title('Dendrogram (Average Method, Euclidean Distance)')
plt.xlabel('Samples')
plt.ylabel('Distance')
plt.show()
"""


tfidf_text = """
# --- Library Imports ---
import pandas as pd
from sklearn.pipeline import make_pipeline
from sklearn.cluster import KMeans
from scipy.sparse import csr_matrix
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn.decomposition import TruncatedSVD

# --- Data and Vectorization Setup ---

docs = [
    'This session talks about CSR',
    'SVD works with CSR',
    'Kmeans clusteringcan be used in a pipeline',
    'pipeline can have any clustering approach',
    'TFIDF needs CSR'
]

# TfidfVectorizer setup and execution
tfi = TfidfVectorizer()
csr1 = tfi.fit_transform(docs)

# Print TF-IDF results
print(csr1.toarray())
print(csr1)

# Get and display features (words)
words1 = tfi.get_feature_names_out()
print(words1)

# Check stop words
print(tfi.get_stop_words())

# CountVectorizer setup and execution
vect1 = CountVectorizer()
vect1.fit(docs)
print("Vocabulary:", vect1.vocabulary_)
vector = vect1.transform(docs)
print("Encoded Document is:")
print(vector.toarray())

# Re-running TF-IDF
csr1 = tfi.fit_transform(docs)

# --- Model Definitions ---

# SVD models
svd2 = TruncatedSVD(n_components=2)
svd3 = TruncatedSVD(n_components=3)

# KMeans models
kmeans2 = KMeans(n_clusters=2)
kmeans3 = KMeans(n_clusters=3)

# --- Pipeline 1: SVD=2 / KMeans=2 ---
pipeline1 = make_pipeline(svd2, kmeans2)
pipeline1.fit(csr1)
labels1 = pipeline1.predict(csr1)
df = pd.DataFrame({'Labels': labels1, 'Docs': docs})
df1 = df.sort_values('Labels')
print(df1)

# --- Pipeline 2: SVD=2 / KMeans=3 ---
pipeline2 = make_pipeline(svd2, kmeans3)
pipeline2.fit(csr1)
labels2 = pipeline2.predict(csr1)
df = pd.DataFrame({'Labels': labels2, 'Docs': docs})
df2 = df.sort_values('Labels')
print(df2)

# --- Pipeline 3: SVD=3 / KMeans=2 ---
pipeline3 = make_pipeline(svd3, kmeans2)
pipeline3.fit(csr1)
labels3 = pipeline3.predict(csr1)
df = pd.DataFrame({'Labels': labels3, 'Docs': docs})
df3 = df.sort_values('Labels')
print(df3)

# --- Pipeline 4: SVD=3 / KMeans=3 ---
pipeline4 = make_pipeline(svd3, kmeans3)
pipeline4.fit(csr1)
labels4 = pipeline4.predict(csr1)
df = pd.DataFrame({'Labels': labels4, 'Docs': docs})
df4 = df.sort_values('Labels')
print(df4)"""

nltk_text = """
import nltk
import random
from nltk.corpus import names
import pandas as pd

# for classification model rather than native model (Decision Tree, Maxent, Naive Baise)
from nltk.classify.scikitlearn import SklearnClassifier
from sklearn.linear_model import LogisticRegression

# Download the names corpus if not already present
nltk.download('names')


# ============================================================================
# Load and Prepare Data
# ============================================================================

# Load male and female names from the corpus
names_data = ([(name, 'male') for name in names.words('male.txt')] +
              [(name, 'female') for name in names.words('female.txt')])

# Count total names loaded
print("Total names loaded:", len(names_data))

# Shuffle the data
random.shuffle(names_data)

# Split data into Train, Dev-Test, and Test sets
train_names = names_data[1500:]
devtest_names = names_data[500:1500]
test_names = names_data[:500]

print("Data Split Summary:")
print(f"- Training set: {len(train_names)}")
print(f"- Dev-Test set: {len(devtest_names)}")
print(f"- Test set: {len(test_names)}")


# ============================================================================
# Feature Extractors
# ============================================================================

# Feature Extractor 1: Simple (last letter only)
def gender_features_simple(word):
    return {'last_letter': word[-1]}


# Feature Extractor 2: Improved extractor (using suffixes)
def gender_features_improved(word):
    return {
        'suffix1': word[-1:], 
        'suffix2': word[-2:]
    }


# ===========================================================================
# Prepare Feature Sets
# ===========================================================================
# Simple feature sets
train_set_simple = [(gender_features_simple(n), g) for (n, g) in train_names]
devtest_set_simple = [(gender_features_simple(n), g) for (n, g) in devtest_names]
test_set_simple = [(gender_features_simple(n), g) for (n, g) in test_names]

# Improved feature sets
train_set_improved = [(gender_features_improved(n), g) for (n, g) in train_names]
devtest_set_improved = [(gender_features_improved(n), g) for (n, g) in devtest_names]
test_set_improved = [(gender_features_improved(n), g) for (n, g) in test_names]



# --- Feature Extractor 1: Simple ---
print("--- Feature Extractor 1: Simple (last letter) ---")

classifier1_v1 = nltk.DecisionTreeClassifier.train(train_set_simple)

acc_dt_simple_dev_test = nltk.classify.accuracy(classifier1_v1, devtest_set_simple)
acc_dt_simple_test = nltk.classify.accuracy(classifier1_v1, test_set_simple)

print(f"Dev-Test Accuracy: {acc_dt_simple_dev_test:.4f}")
print(f"Test Accuracy: {acc_dt_simple_test:.4f}")


# Error analysis
errors = []
for (name, tag) in devtest_names:
    guess = classifier1_v1.classify(gender_features_simple(name))
    if guess != tag:
        errors.append((tag, guess, name))

print(f"\nError List (showing first 20 of {len(errors)} errors):")
for (tag, guess, name) in sorted(errors)[:20]:
    print(f'correct={tag:<8} guess={guess:<8} name={name:<30}')


# --- Feature Extractor 2: Improved ---
print("--- Feature Extractor 2: Improved (suffix1, suffix2) ---")

classifier1_v2 = nltk.DecisionTreeClassifier.train(train_set_improved)

acc_dt_improved_dev_test = nltk.classify.accuracy(classifier1_v2, devtest_set_improved)
acc_dt_improved_test = nltk.classify.accuracy(classifier1_v2, test_set_improved)
print(f"Dev-Test Accuracy: {acc_dt_improved_dev_test:.4f}")
print(f"Test Accuracy: {acc_dt_improved_test:.4f}")

# Error analysis
errors = []
for (name, tag) in devtest_names:
    guess = classifier1_v2.classify(gender_features_improved(name))
    if guess != tag:
        errors.append((tag, guess, name))

print(f"\nError List (showing first 20 of {len(errors)} errors):")
for (tag, guess, name) in sorted(errors)[:20]:
    print(f'correct={tag:<8} guess={guess:<8} name={name:<30}')

    

    

# ============================================================================
# CLASSIFIER #2: Maximum Entropy Classifier
# ============================================================================
# --- Feature Extractor 1: Simple ---
print("--- Feature Extractor 1: Simple (last letter) ---")

classifier2_v1 = nltk.MaxentClassifier.train(train_set_simple, algorithm='iis', max_iter=10)

acc_me_simple_dev_test = nltk.classify.accuracy(classifier2_v1, devtest_set_simple)
acc_me_simple_test = nltk.classify.accuracy(classifier2_v1, test_set_simple)

print(f"Dev-Test Accuracy: {acc_me_simple_dev_test:.4f}")
print(f"Test Accuracy: {acc_me_simple_test:.4f}")

# Error analysis
errors = []
for (name, tag) in devtest_names:
    guess = classifier2_v1.classify(gender_features_simple(name))
    if guess != tag:
        errors.append((tag, guess, name))

print(f"\nError List (showing first 20 of {len(errors)} errors):")
for (tag, guess, name) in sorted(errors)[:20]:
    print(f'correct={tag:<8} guess={guess:<8} name={name:<30}')



# ============================================================================
# CLASSIFIER #3: Logistic Regression (via SklearnClassifier)
# ============================================================================

# --- Feature Extractor 1: Simple ---
print("--- Feature Extractor 1: Simple (last letter) ---")

classifier3_v1 = SklearnClassifier(LogisticRegression(max_iter=1000))
classifier3_v1.train(train_set_simple)

acc_lr_simple = nltk.classify.accuracy(classifier3_v1, test_set_simple)
acc_lr_simple_dev_test = nltk.classify.accuracy(classifier3_v1, devtest_set_simple)
print(f"Dev-Test Accuracy: {acc_lr_simple_dev_test:.4f}")
print(f"Test Accuracy: {acc_lr_simple:.4f}")

# Error analysis
errors = []
for (name, tag) in devtest_names:
    guess = classifier3_v1.classify(gender_features_simple(name))
    if guess != tag:
        errors.append((tag, guess, name))

print(f"\nError List (showing first 20 of {len(errors)} errors):")
for (tag, guess, name) in sorted(errors)[:20]:
    print(f'correct={tag:<8} guess={guess:<8} name={name:<30}')

    


data_dev_test = {
    'Decision Tree': [acc_dt_simple_dev_test, acc_dt_improved_dev_test],
    'Maxent': [acc_me_simple_dev_test, acc_me_improved_dev_test],
    'Logistic Regression': [acc_lr_simple_dev_test, acc_lr_improved_dev_test]
}

dev_test_df = pd.DataFrame(data_dev_test, index=['Simple Features', 'Improved Features'])
data_test = {
    'Decision Tree': [acc_dt_simple_test, acc_dt_improved_test],
    'Maxent': [acc_me_simple_test, acc_me_improved_test],
    'Logistic Regression': [acc_lr_simple, acc_lr_improved]
}

test_df = pd.DataFrame(data_test, index=['Simple Features', 'Improved Features'])

print("Dev-Test Set Accuracies:")
print(dev_test_df)
print("Test Set Accuracies:")
print(test_df)
"""

# - pd
# - np
# - pipe
# - plt_sb
# - decision
# - imb
# - knn_nb_svm
# - lab1
# - reg
# - scipy
# - midterm
# - assign2
# - ml_clf
# - ml_clf_all
# - ml_reg
# - l2t1
# - l2t2
# - nn
# - final
# - tfidf
# - nltk

def describe():
    return describe_text

def get_pd():
    pyperclip.copy(pd_text)
    return pd_text

def get_np():
    pyperclip.copy(np_text)
    return np_text

def get_pipe():
    pyperclip.copy(pipe_text)
    return pipe_text

def get_plt_sb():
    pyperclip.copy(plt_sb_text)
    return plt_sb_text

def get_decision():
    pyperclip.copy(decision_text)
    return decision_text

def get_imb():
    pyperclip.copy(imb_text)
    return imb_text

def get_knn_nb_svm():
    pyperclip.copy(knn_nb_svm_text)
    return knn_nb_svm_text

def get_lab1():
    pyperclip.copy(lab1_text)
    return lab1_text

def get_reg():
    pyperclip.copy(reg_text)
    return reg_text

def get_scipy():
    pyperclip.copy(scipy_text)
    return scipy_text

def get_midterm():
    pyperclip.copy(midterm_text)
    return midterm_text

def get_assign2():
    pyperclip.copy(assign2_text)
    return assign2_text

def get_ml_clf():
    pyperclip.copy(ml_clf_text)
    return ml_clf_text

def get_ml_clf_all():
    pyperclip.copy(ml_clf_all_text)
    return ml_clf_all_text

def get_ml_reg():
    pyperclip.copy(ml_reg_text)
    return ml_reg_text

def get_l2t1():
    pyperclip.copy(l2t1_text)
    return l2t1_text

def get_l2t2():
    pyperclip.copy(l2t2_text)
    return l2t2_text

def get_nn():
    pyperclip.copy(nn_text)
    return nn_text

def get_final():
    pyperclip.copy(final_text)
    return final_text

def get_tfidf():
    pyperclip.copy(tfidf_text)
    return tfidf_text

def get_nltk():
    pyperclip.copy(nltk_text)
    return nltk_text
