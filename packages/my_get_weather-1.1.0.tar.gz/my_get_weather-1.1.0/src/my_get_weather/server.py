import argparse
import json
import os
from typing import Any, Optional

import httpx
from mcp.server.fastmcp import FastMCP

# 初始化 MCP 服务器
# 在这里可以配置sse streamable http的访问路径 sse默认是/sse，streamable http默认是/mcp
mcp = FastMCP("WeatherServer",host="0.0.0.0")

# OpenWeather API 配置
OPENWEATHER_API_BASE = "https://api.openweathermap.org/data/2.5/weather"
USER_AGENT = "weather-app/1.0"

# 只读全局配置变量（在 main 中赋值）
API_KEY: Optional[str] = None

# 可选：复用 HTTP 客户端（简单版本）
# 可以考虑复用 AsyncClient 实例。例如：
# 在模块级创建一个 AsyncClient，进程终止时再关闭；
# 或者在更复杂的框架中用生命周期钩子管理。

_http_client: Optional[httpx.AsyncClient] = None


def get_http_client() -> httpx.AsyncClient:
    """
    获取全局 HTTP 客户端实例，如不存在则创建。
    注意：在进程退出时，由运行时负责清理（对本示例足够）。
    """
    global _http_client
    if _http_client is None:
        _http_client = httpx.AsyncClient(
            headers={"User-Agent": USER_AGENT},
            timeout=30.0,
        )
    return _http_client


async def fetch_weather(city: str) -> dict[str, Any]:
    """
    从 OpenWeather API 获取天气信息。
    :param city: 城市名称（需使用英文，如 Beijing）
    :return: 天气数据字典；若出错返回包含 error 信息的字典
    """
    if not API_KEY:
        return {"error": "API_KEY 未设置，请提供有效的 OpenWeather API Key。"}

    if not city:
        return {"error": "城市名称不能为空。"}

    params = {
        "q": city,
        "appid": API_KEY,
        "units": "metric",
        "lang": "zh_cn",
    }

    client = get_http_client()

    try:
        response = await client.get(OPENWEATHER_API_BASE, params=params)
        # 对非 2xx 状态码抛出 HTTPStatusError
        response.raise_for_status()
    except httpx.HTTPStatusError as e:
        status = e.response.status_code
        # 根据状态码返回更友好的错误信息
        if status == 401:
            msg = "认证失败：请检查 OpenWeather API Key 是否正确。"
        elif status == 403:
            msg = "访问被禁止：API Key 可能无权限或已被禁用。"
        elif status == 404:
            msg = f"未找到城市：{city}，请确认拼写是否正确（需使用英文）。"
        else:
            msg = f"OpenWeather 返回错误状态码：{status}。"
        # 视情况可以在此处打印或记录日志 e.response.text
        return {"error": msg}
    except httpx.RequestError as e:
        # 网络/连接类错误
        return {"error": f"网络请求失败：{e}。请检查网络连接。"}
    except Exception as e:
        # 兜底异常
        return {"error": f"请求失败：{e}"}

    # 尝试解析 JSON
    try:
        return response.json()
    except json.JSONDecodeError:
        return {"error": "解析 OpenWeather 返回数据失败，响应格式异常。"}
    # 理论上不会走到这里
    # return {"error": "未知错误。"}


def format_weather(data: dict[str, Any]) -> str:
    """
    将天气数据格式化为易读文本。
    :param data: 天气数据（字典）
    :return: 格式化后的天气信息字符串
    """

    # 如果数据中包含错误信息，直接返回错误提示
    if "error" in data:
        return f"⚠️ {data['error']}"

    # 提取数据时做容错处理
    city = data.get("name", "未知")
    country = data.get("sys", {}).get("country", "未知")

    maindata = data.get("main", {}) or {}
    temp = maindata.get("temp", "N/A")
    humidity = maindata.get("humidity", "N/A")

    wind = data.get("wind", {}) or {}
    wind_speed = wind.get("speed", "N/A")

    weather_list = data.get("weather") or []
    first_weather = weather_list[0] if weather_list else {}
    description = first_weather.get("description", "未知")

    # 美化展示
    temp_str = f"{temp}°C" if isinstance(temp, (int, float)) else "N/A"
    humidity_str = f"{humidity}%" if isinstance(humidity, (int, float)) else "N/A"
    wind_str = f"{wind_speed} m/s" if isinstance(wind_speed, (int, float)) else "N/A"

    return (
        f"🌍 {city}, {country}\n"
        f"🌡 温度: {temp_str}\n"
        f"💧 湿度: {humidity_str}\n"
        f"🌬 风速: {wind_str}\n"
        f"🌤 天气: {description}\n"
    )


@mcp.tool()
async def query_weather(city: str) -> str:
    """
    输入指定城市的英文名称，返回今日天气查询结果。
    """
    data = await fetch_weather(city)
    return format_weather(data)


def load_api_key_from_env() -> Optional[str]:
    """
    从环境变量中读取 API Key（可选）。
    """
    return os.getenv("OPENWEATHER_API_KEY")


def main() -> None:
    parser = argparse.ArgumentParser(description="Weather Server (MCP)")
    parser.add_argument(
        "--api_key",
        type=str,
        required=False,
        help="你的 OpenWeather API Key；若不提供，则尝试从环境变量 OPENWEATHER_API_KEY 读取。",
    )
    args = parser.parse_args()

    # 将 API_KEY 设为只读全局变量，通过命令行参数或环境变量传入
    global API_KEY
    API_KEY = args.api_key or load_api_key_from_env()

    if not API_KEY:
        raise SystemExit(
            "未提供 OpenWeather API Key。请使用 --api_key 参数或设置环境变量 OPENWEATHER_API_KEY。"
        )

    # 启动 MCP Server，使用 SSE 传输
    mcp.run(transport="sse")


if __name__ == "__main__":
    main()
