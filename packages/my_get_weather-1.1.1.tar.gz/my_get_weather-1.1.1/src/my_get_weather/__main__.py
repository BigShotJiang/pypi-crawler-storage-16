#from my_get_weather import main
from . import main

main()
