# ❤️ Love Calculator

A simple Python library that calculates love compatibility between two names.

## Installation
```bash
pip install love-calculator
