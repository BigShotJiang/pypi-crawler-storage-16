from.core import calculate_love

__all__ = ["calculate_love"]
__version__ = "1.0.0"

