# src/datagen/cars.py
import random
from .utils import set_seed


CARS = [
    ("Toyota", "Corolla"),
    ("Toyota", "Hilux"),
    ("Honda", "Civic"),
    ("BMW", "X5"),
]

COLORS = ["Red", "Blue", "Black", "White"]
TRANSMISSIONS = ["Manual", "Automatic"]


def generate_cars(n: int = 10, seed: int | None = None):
    """
    Generate synthetic car data.
    """
    set_seed(seed)

    cars = []

    for i in range(n):
        make, model = random.choice(CARS)

        cars.append(
            {
                "car_id": i + 1,
                "make": make,
                "model": model,
                "year": random.randint(2005, 2024),
                "color": random.choice(COLORS),
                "transmission": random.choice(TRANSMISSIONS),
                "price": random.randint(5000, 60000),
            }
        )

    return cars
