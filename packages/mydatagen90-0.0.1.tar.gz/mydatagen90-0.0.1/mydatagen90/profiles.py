# src/datagen/profiles.py
import random
from .utils import set_seed, random_date


FIRST_NAMES = ["John", "Jane", "Alice", "Bob", "Mary"]
LAST_NAMES = ["Doe", "Smith", "Johnson", "Brown"]
GENDERS = ["Male", "Female"]


def generate_profiles(n: int = 10, seed: int | None = None):
    """
    Generate synthetic user profile data.

    Parameters
    ----------
    n : int
        Number of profiles
    seed : int | None
        Random seed for reproducibility

    Returns
    -------
    list[dict]
    """
    set_seed(seed)

    profiles = []

    for i in range(n):
        first_name = random.choice(FIRST_NAMES)
        last_name = random.choice(LAST_NAMES)

        profile = {
            "user_id": i + 1,
            "first_name": first_name,
            "last_name": last_name,
            "email": f"{first_name.lower()}.{last_name.lower()}@example.com",
            "gender": random.choice(GENDERS),
            "date_of_birth": random_date().isoformat(),
            "latitude": round(random.uniform(-90, 90), 6),
            "longitude": round(random.uniform(-180, 180), 6),
        }

        profiles.append(profile)

    return profiles
