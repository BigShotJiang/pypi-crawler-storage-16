# src/datagen/regions.py
import random
from .utils import set_seed


REGIONS = [
    ("East Africa", "Kenya", "EAT"),
    ("West Africa", "Nigeria", "WAT"),
    ("Europe", "Germany", "CET"),
    ("North America", "USA", "EST"),
]


def generate_regions(n: int = 5, seed: int | None = None):
    """
    Generate region metadata.
    """
    set_seed(seed)

    regions = []

    for i in range(n):
        name, country, timezone = random.choice(REGIONS)

        regions.append(
            {
                "region_id": i + 1,
                "region_name": name,
                "country": country,
                "timezone": timezone,
                "manager": f"Manager_{i+1}",
            }
        )

    return regions
