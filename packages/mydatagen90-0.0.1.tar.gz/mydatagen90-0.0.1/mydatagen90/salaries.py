# src/datagen/salaries.py
import random
from .utils import set_seed


LEVELS = {
    "Junior": (30000, 50000),
    "Mid": (50000, 80000),
    "Senior": (80000, 120000),
}


def generate_salaries(n: int = 10, seed: int | None = None):
    """
    Generate synthetic salary data.
    """
    set_seed(seed)

    data = []

    for i in range(n):
        level = random.choice(list(LEVELS.keys()))
        base_min, base_max = LEVELS[level]
        base_pay = random.randint(base_min, base_max)
        bonus = random.randint(0, int(base_pay * 0.2))

        data.append(
            {
                "employee_id": i + 1,
                "level": level,
                "base_pay": base_pay,
                "bonus": bonus,
                "total_compensation": base_pay + bonus,
            }
        )

    return data
