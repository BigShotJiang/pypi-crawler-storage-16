# mydsaaa

This is a Python package to quickly access common DSA codes in C language for educational purposes.

## Installation

```bash
pip install mydsaaa
```

## Usage

```python
import dsa

# List available commands
dsa.help()

# Print a specific code
dsa.bubble_sort()

# Print ALL codes
dsa.all()
```
