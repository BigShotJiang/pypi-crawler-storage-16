from setuptools import setup, find_packages

setup(
    name="mydsaaa",
    version="0.0.2",
    author="me",
    author_email="me@gmail.com",
    description="A Python package that prints C++ DSA codes",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/mydsaaa",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
