# Changelog - myfy

All notable changes to the myfy meta-package will be documented in this file.

## [Unreleased]

## [0.1.0] - 2025-10-29

### Added
- Meta-package for convenient installation
- Core framework components
- CLI tools
- Optional web and frontend modules
- Installation extras: `[web]`, `[all]`
