"""
myfy CLI tools.
"""

from .main import app
from .version import __version__

__all__ = ["__version__", "app"]
