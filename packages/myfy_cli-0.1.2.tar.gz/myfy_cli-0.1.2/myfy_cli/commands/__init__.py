"""CLI command modules for myfy."""

from myfy_cli.commands.frontend import frontend_app

__all__ = ["frontend_app"]
