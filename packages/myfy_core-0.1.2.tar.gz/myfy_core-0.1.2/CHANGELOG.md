# Changelog - myfy-core

All notable changes to myfy-core will be documented in this file.

## [Unreleased]

## [0.1.0] - 2025-10-29

### Added
- Dependency injection container with compile-time resolution
- Configuration system with profiles and environment variables
- Application kernel and lifecycle management
- Module system with plugin support
- Scoped providers (SINGLETON, REQUEST, TASK)
