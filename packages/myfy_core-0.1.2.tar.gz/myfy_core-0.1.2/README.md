# myfy-core

Core kernel for the myfy framework.

Provides:
- Dependency injection with compile-time resolution
- Configuration system with profiles
- Application kernel and module system
- Lifecycle management

See the [main README](../../README.md) for documentation.
