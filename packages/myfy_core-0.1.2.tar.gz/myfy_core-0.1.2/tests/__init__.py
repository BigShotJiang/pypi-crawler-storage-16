"""Tests for myfy-core package."""
