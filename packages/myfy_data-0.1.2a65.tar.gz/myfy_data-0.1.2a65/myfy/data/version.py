"""Version information for myfy-data package."""

__version__ = "0.1.2a65"
