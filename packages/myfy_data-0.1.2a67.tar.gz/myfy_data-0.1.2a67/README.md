# myfy-data

Database/ORM module for the myfy framework.

Provides async SQLAlchemy integration with REQUEST-scoped sessions, connection pooling, and Alembic migrations.

See the [main README](../../README.md) for documentation.
