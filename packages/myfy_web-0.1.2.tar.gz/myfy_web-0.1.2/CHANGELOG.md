# Changelog - myfy-web

All notable changes to myfy-web will be documented in this file.

## [Unreleased]

## [0.1.0] - 2025-10-29

### Added
- ASGI application integration
- FastAPI-like routing with dependency injection
- Request context management
- Middleware system
- HTTP method decorators
- WebModule for easy application setup
