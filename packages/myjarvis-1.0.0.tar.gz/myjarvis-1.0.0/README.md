# MyJARVIS - 您的个人AI助手

一个功能强大的个人AI助手，支持语音识别、自动化控制、智能搜索等功能。专为 macOS 设计，适配 Intel Mac 和 Apple Silicon。

## ✨ 功能特性

- 🎤 **语音识别**：支持 macOS 听写功能和在线语音识别
- 🤖 **AI对话**：集成多种AI模型（智谱AI、DeepSeek、Qwen等）
- 🔍 **智能搜索**：自动打开浏览器并搜索，支持屏幕分析
- 🖱️ **自动化控制**：鼠标、键盘自动化操作
- 💬 **图形界面**：美观的GUI界面和状态栏图标
- 📝 **记忆系统**：保存对话历史和用户偏好
- 🔔 **提醒功能**：工作提醒、闹钟等

## 📋 系统要求

- macOS 12 或更高版本
- Python 3.10 或更高版本
- Intel Mac 或 Apple Silicon

## 🚀 快速开始

### 1. 安装

#### 从 PyPI 安装（推荐）

```bash
pip install myjarvis
```

#### 从源码安装

```bash
git clone https://github.com/yourusername/myjarvis.git
cd myjarvis
pip install -r requirements.txt
```

### 2. 配置

复制配置文件模板：

```bash
cp config.json.example config.json
```

编辑 `config.json`，配置您的API密钥（可选）：

```json
{
  "api": {
    "zhipu_api_key": "您的智谱AI密钥",
    "deepseek_api_key": "您的DeepSeek密钥",
    "qwen_api_key": "您的Qwen密钥"
  }
}
```

**注意**：如果不配置API密钥，系统会自动使用免费在线API。

### 3. 运行

```bash
python3 main.py
```

或者使用状态栏模式：

```bash
python3 main.py --menubar
```

## 🔑 API密钥配置

### 方法1：配置文件（推荐）

编辑 `config.json`，添加您的API密钥：

```json
{
  "api": {
    "zhipu_api_key": "您的密钥",
    "deepseek_api_key": "您的密钥",
    "qwen_api_key": "您的密钥"
  }
}
```

### 方法2：环境变量

```bash
export ZHIPU_API_KEY='您的密钥'
export DEEPSEEK_API_KEY='您的密钥'
export QWEN_API_KEY='您的密钥'
```

### 获取API密钥

1. **智谱AI（推荐）**：
   - 访问：https://open.bigmodel.cn/
   - 注册账号并获取API密钥

2. **DeepSeek**：
   - 访问：https://platform.deepseek.com/
   - 注册账号并获取API密钥

3. **Qwen**：
   - 访问：https://dashscope.aliyuncs.com/
   - 注册账号并获取API密钥

## 📖 使用说明

### 基本命令

- `打开Safari` - 打开应用程序
- `搜索Python教程` - 智能搜索
- `定一个十秒后的闹钟` - 设置提醒
- `几点了` - 查询时间
- `帮助` - 查看功能说明

### 语音输入

1. 点击"🎤 语音输入"按钮
2. 系统会自动触发听写功能（或手动按 Fn Fn）
3. 开始说话
4. 说完后按 Fn 键或点击完成按钮
5. 识别结果会自动填入并执行

### 搜索功能

系统会自动：
1. 打开Safari浏览器
2. 输入搜索关键词
3. 执行搜索
4. 分析搜索结果
5. 点击第一个搜索结果

## 🛠️ 开发

### 项目结构

```
MyJARVIS/
├── main.py                 # 主入口
├── jarvis_core/           # 核心模块
│   ├── ai_client.py       # AI客户端
│   ├── automation.py       # 自动化控制
│   ├── gui.py             # 图形界面
│   ├── memory.py           # 记忆系统
│   ├── speech.py           # 语音识别
│   └── tools.py            # 系统工具
├── config.json.example     # 配置模板
└── requirements.txt       # 依赖列表
```

### 安装开发依赖

```bash
pip install -r requirements.txt
```

## 🐛 故障排除

### 语音识别无法使用

1. 确保系统设置 > 键盘 > 听写 已启用
2. 确保系统设置 > 安全性与隐私 > 隐私 > 麦克风 已授予权限
3. 尝试手动按 Fn Fn 触发听写

### 搜索功能不工作

1. 确保Safari已安装
2. 确保系统设置 > 安全性与隐私 > 隐私 > 辅助功能 已授予权限
3. 检查日志文件：`logs/jarvis_*.log`

### 程序崩溃

1. 确保使用 Python 3.10 或更高版本
2. 检查系统设置 > 安全性与隐私 > 隐私 > 屏幕录制 权限
3. 查看崩溃日志

## 📝 许可证

MIT License

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

## 📧 联系方式

- GitHub Issues: https://github.com/yourusername/myjarvis/issues
- 文档: https://github.com/yourusername/myjarvis#readme

## 🙏 致谢

感谢所有贡献者和开源社区的支持！

---

**注意**：请勿在代码或配置文件中提交您的API密钥。使用 `config.json.example` 作为模板，并将 `config.json` 添加到 `.gitignore`。
