"""
JARVIS Core 模块
整合AutoGLM所有功能
"""

__version__ = "2.0.0"
__author__ = "MyJARVIS Team"

# 导出核心模块
from jarvis_core.memory import MemorySystem
from jarvis_core.tools import SystemTools
from jarvis_core.automation import AutomationController
from jarvis_core.speech import SpeechEngine
from jarvis_core.ai_client import AIClient

# AutoGLM核心功能模块
try:
    from jarvis_core.screen_understanding import ScreenUnderstanding
    from jarvis_core.task_planner import TaskPlanner
    from jarvis_core.enhanced_jarvis import EnhancedJARVIS
    AUTOGLM_AVAILABLE = True
except ImportError:
    AUTOGLM_AVAILABLE = False

__all__ = [
    "MemorySystem",
    "SystemTools",
    "AutomationController",
    "SpeechEngine",
    "AIClient",
    "ScreenUnderstanding",
    "TaskPlanner",
    "EnhancedJARVIS",
    "AUTOGLM_AVAILABLE"
]
