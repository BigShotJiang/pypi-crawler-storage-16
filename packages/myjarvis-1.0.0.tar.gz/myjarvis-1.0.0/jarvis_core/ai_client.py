"""
AI API 客户端 - 适配 Intel Mac macOS 12（使用在线免费API，无需密钥）
"""
import requests
import json
import logging
from typing import Optional, Dict, List, Any
import time

logger = logging.getLogger(__name__)


class AIClient:
    """AI API 客户端 - 适配 Intel Mac，使用在线免费API"""
    
    def __init__(self, config: Dict[str, Any]):
        """
        初始化 AI 客户端
        
        Args:
            config: 配置字典，包含 API 密钥和 URL
        """
        self.config = config
        self.api_config = config.get("api", {})
        self.qwen_api_key = self.api_config.get("qwen_api_key", "")
        self.qwen_api_url = self.api_config.get("qwen_api_url", "https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation")
        self.deepseek_api_key = self.api_config.get("deepseek_api_key", "")
        self.deepseek_api_url = self.api_config.get("deepseek_api_url", "https://api.deepseek.com/v1/chat/completions")
        # 智谱AI (AutoGLM基础模型) - 尝试自动获取或使用默认密钥
        self.zhipu_api_key = self.api_config.get("zhipu_api_key", "")
        # 如果没有配置，尝试使用环境变量或默认测试密钥
        if not self.zhipu_api_key:
            import os
            self.zhipu_api_key = os.environ.get("ZHIPU_API_KEY", "")
        self.zhipu_api_url = self.api_config.get("zhipu_api_url", "https://open.bigmodel.cn/api/paas/v4/chat/completions")
        
        # 确定使用哪个 API（优先级：智谱AI > DeepSeek > Qwen > 免费在线API > 智能基础回复）
        # 注意：Intel Mac macOS 12 不支持本地模型，使用在线免费API
        if self.zhipu_api_key:
            self.provider = "zhipu"
            logger.info("✅ 使用智谱AI (AutoGLM基础模型) API")
        elif self.deepseek_api_key:
            self.provider = "deepseek"
            logger.info("✅ 使用 DeepSeek API")
        elif self.qwen_api_key:
            self.provider = "qwen"
            logger.info("✅ 使用 Qwen API")
        else:
            # Intel Mac 使用在线免费 API（无需密钥）
            self.provider = "free_api"
            logger.info("✅ 使用免费在线 AI API（无需密钥，适配 Intel Mac）")
    
    def chat(self, user_input: str, conversation_history: Optional[List[Dict]] = None) -> str:
        """
        与 AI 对话（快速响应）
        
        Args:
            user_input: 用户输入
            conversation_history: 对话历史
        
        Returns:
            AI 回复
        """
        try:
            if self.provider == "zhipu":
                return self._chat_zhipu(user_input, conversation_history)
            elif self.provider == "deepseek":
                return self._chat_deepseek(user_input, conversation_history)
            elif self.provider == "qwen":
                return self._chat_qwen(user_input, conversation_history)
            elif self.provider == "free_api":
                return self._chat_free_api(user_input, conversation_history)
            else:
                return self._fallback_response(user_input)
        except Exception as e:
            logger.error(f"AI API 调用失败: {e}")
            return self._fallback_response(user_input)
    
    def _chat_zhipu(self, user_input: str, conversation_history: Optional[List[Dict]] = None) -> str:
        """使用智谱AI API (AutoGLM基础模型)"""
        try:
            messages = []
            
            # 添加系统提示
            system_prompt = """你是一个高度智能的AI助手 JARVIS，像钢铁侠的JARVIS一样强大。你基于AutoGLM技术，具备以下核心能力：

1. **自主环境交互**：能够理解屏幕内容，识别GUI元素，执行复杂的多步骤操作
2. **智能任务规划**：能够将复杂任务分解为可执行的步骤，如外卖点单、机票预订等
3. **屏幕理解**：能够识别按钮、输入框、文本等界面元素
4. **多模态理解**：能够同时理解文本、图像和语音输入
5. **渐进式学习**：能够从交互中学习，不断优化操作策略

请用中文回复，简洁明了，语气自然友好，能够理解用户的真实意图并提供准确的帮助。对于复杂任务，请提供详细的执行步骤。"""
            
            messages.append({"role": "system", "content": system_prompt})
            
            # 添加对话历史
            if conversation_history:
                for item in conversation_history[-3:]:  # 只保留最近3轮
                    if "user_input" in item:
                        messages.append({"role": "user", "content": item["user_input"]})
                    if "jarvis_response" in item:
                        messages.append({"role": "assistant", "content": item["jarvis_response"]})
            
            # 添加当前用户输入
            messages.append({"role": "user", "content": user_input})
            
            # 调用智谱AI API
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.zhipu_api_key}"
            }
            
            data = {
                "model": "glm-4",  # 使用GLM-4模型（AutoGLM的基础模型）
                "messages": messages,
                "temperature": 0.7,
                "max_tokens": 2000
            }
            
            response = requests.post(
                self.zhipu_api_url,
                headers=headers,
                json=data,
                timeout=20  # 智谱AI可能需要稍长时间
            )
            
            if response.status_code == 200:
                result = response.json()
                if "choices" in result and len(result["choices"]) > 0:
                    return result["choices"][0]["message"]["content"]
                else:
                    logger.error(f"智谱AI API 响应格式异常: {result}")
                    return self._fallback_response(user_input)
            else:
                logger.error(f"智谱AI API 错误: {response.status_code}, {response.text}")
                return self._fallback_response(user_input)
        
        except requests.exceptions.Timeout:
            logger.error("智谱AI API 请求超时")
            return self._fallback_response(user_input)
        except Exception as e:
            logger.error(f"智谱AI API 调用异常: {e}")
            import traceback
            traceback.print_exc()
            return self._fallback_response(user_input)
    
    def _chat_deepseek(self, user_input: str, conversation_history: Optional[List[Dict]] = None) -> str:
        """使用 DeepSeek API"""
        try:
            messages = []
            
            # 添加系统提示
            system_prompt = """你是一个高度智能的AI助手 JARVIS，像钢铁侠的JARVIS一样强大。请用中文回复，简洁明了，语气自然友好。"""
            
            messages.append({"role": "system", "content": system_prompt})
            
            # 添加对话历史
            if conversation_history:
                for item in conversation_history[-3:]:  # 只保留最近3轮
                    if "user_input" in item:
                        messages.append({"role": "user", "content": item["user_input"]})
                    if "jarvis_response" in item:
                        messages.append({"role": "assistant", "content": item["jarvis_response"]})
            
            # 添加当前用户输入
            messages.append({"role": "user", "content": user_input})
            
            # 调用 API（快速超时）
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.deepseek_api_key}"
            }
            
            data = {
                "model": "deepseek-chat",
                "messages": messages,
                "temperature": 0.7,
                "max_tokens": 1000
            }
            
            response = requests.post(
                self.deepseek_api_url,
                headers=headers,
                json=data,
                timeout=15  # 缩短超时时间
            )
            
            if response.status_code == 200:
                result = response.json()
                return result["choices"][0]["message"]["content"]
            else:
                logger.error(f"DeepSeek API 错误: {response.status_code}")
                return self._fallback_response(user_input)
        
        except requests.exceptions.Timeout:
            logger.error("DeepSeek API 请求超时")
            return self._fallback_response(user_input)
        except Exception as e:
            logger.error(f"DeepSeek API 调用异常: {e}")
            return self._fallback_response(user_input)
    
    def _chat_qwen(self, user_input: str, conversation_history: Optional[List[Dict]] = None) -> str:
        """使用 Qwen API"""
        try:
            # 构建提示词
            prompt = "你是一个智能助手 JARVIS，像钢铁侠的JARVIS一样强大。请用中文回复，简洁明了。\n\n"
            if conversation_history:
                prompt += "对话历史：\n"
                for item in conversation_history[-2:]:
                    if "user_input" in item:
                        prompt += f"用户：{item['user_input']}\n"
                    if "jarvis_response" in item:
                        prompt += f"JARVIS：{item['jarvis_response']}\n"
            
            prompt += f"\n用户：{user_input}\nJARVIS："
            
            # 调用 API（快速超时）
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.qwen_api_key}"
            }
            
            data = {
                "model": "qwen-turbo",
                "input": {
                    "messages": [
                        {"role": "user", "content": user_input}
                    ]
                },
                "parameters": {
                    "temperature": 0.7,
                    "max_tokens": 1000
                }
            }
            
            response = requests.post(
                self.qwen_api_url,
                headers=headers,
                json=data,
                timeout=15  # 缩短超时时间
            )
            
            if response.status_code == 200:
                result = response.json()
                if "output" in result and "choices" in result["output"]:
                    return result["output"]["choices"][0]["message"]["content"]
                elif "output" in result:
                    return result["output"].get("text", "无法解析回复")
                else:
                    return str(result)
            else:
                logger.error(f"Qwen API 错误: {response.status_code}")
                return self._fallback_response(user_input)
        
        except requests.exceptions.Timeout:
            logger.error("Qwen API 请求超时")
            return self._fallback_response(user_input)
        except Exception as e:
            logger.error(f"Qwen API 调用异常: {e}")
            return self._fallback_response(user_input)
    
    def _chat_free_api(self, user_input: str, conversation_history: Optional[List[Dict]] = None) -> str:
        """使用免费在线API（无需密钥，适配Intel Mac，快速响应）"""
        try:
            # 构建简洁的提示词（减少token，提高速度）
            prompt = f"你是JARVIS智能助手，像钢铁侠的JARVIS一样强大。请用中文回复，简洁明了，语气自然友好。\n\n用户：{user_input}\nJARVIS："
            
            # 尝试多个免费API（按优先级，快速失败）
            # 优先尝试智谱AI（如果有API密钥）
            apis = []
            if self.zhipu_api_key:
                apis.append(("智谱AI (AutoGLM)", self._try_zhipu_free))
            apis.extend([
                ("OpenRouter免费模型", self._try_openrouter_free),
                ("HuggingChat", self._try_huggingchat_api),
                ("Together", self._try_together_api)
            ])
            
            for name, api_func in apis:
                try:
                    result = api_func(prompt)
                    if result and len(result) > 10:  # 确保有实际内容
                        logger.info(f"✅ 使用 {name} API 成功")
                        return result.strip()
                except Exception as e:
                    logger.debug(f"{name} API 失败: {e}")
                    continue
            
            # 如果所有API都失败，使用智能规则回复
            return self._fallback_response(user_input)
            
        except Exception as e:
            logger.error(f"免费API调用失败: {e}")
            return self._fallback_response(user_input)
    
    def _try_openrouter_free(self, prompt: str) -> str:
        """尝试使用 OpenRouter 免费模型（无需密钥）"""
        try:
            # 使用 OpenRouter 的免费模型端点
            url = "https://openrouter.ai/api/v1/chat/completions"
            headers = {
                "Content-Type": "application/json",
                "HTTP-Referer": "https://github.com/myjarvis",
                "X-Title": "MyJARVIS"
            }
            # 尝试使用免费的模型
            data = {
                "model": "google/gemini-flash-1.5:free",  # 免费模型
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": 500,
                "temperature": 0.7
            }
            response = requests.post(url, headers=headers, json=data, timeout=15)
            if response.status_code == 200:
                result = response.json()
                return result["choices"][0]["message"]["content"]
            elif response.status_code == 401:
                # 需要API密钥，尝试其他免费模型
                data["model"] = "meta-llama/llama-3.2-3b-instruct:free"
                response = requests.post(url, headers=headers, json=data, timeout=15)
                if response.status_code == 200:
                    result = response.json()
                    return result["choices"][0]["message"]["content"]
        except Exception as e:
            logger.debug(f"OpenRouter 免费API失败: {e}")
        return None
    
    def _try_zhipu_free(self, prompt: str) -> str:
        """尝试使用智谱AI免费接口（如果可用）"""
        try:
            # 智谱AI通常需要API密钥，但我们可以尝试一些公开的接口
            # 注意：这可能需要API密钥，如果失败会快速降级
            url = "https://open.bigmodel.cn/api/paas/v4/chat/completions"
            headers = {
                "Content-Type": "application/json"
            }
            data = {
                "model": "glm-4-flash",  # 尝试使用flash版本（更快）
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": 500,
                "temperature": 0.7
            }
            # 不设置Authorization，如果接口支持无密钥调用
            response = requests.post(url, headers=headers, json=data, timeout=10)
            if response.status_code == 200:
                result = response.json()
                if "choices" in result and len(result["choices"]) > 0:
                    return result["choices"][0]["message"]["content"]
        except Exception as e:
            logger.debug(f"智谱AI免费接口失败: {e}")
        return None
    
    def _try_groq_api(self, prompt: str) -> str:
        """尝试使用 Groq API（免费，快速）"""
        # Groq需要API密钥，跳过
        return None
    
    def _try_huggingchat_api(self, prompt: str) -> str:
        """尝试使用 HuggingChat API（免费，无需密钥）"""
        try:
            # 使用 Hugging Face Inference API（免费，无需密钥）
            api_url = "https://api-inference.huggingface.co/models/Qwen/Qwen2.5-7B-Instruct"
            data = {
                "inputs": prompt,
                "parameters": {
                    "max_new_tokens": 300,
                    "temperature": 0.7,
                    "return_full_text": False
                }
            }
            response = requests.post(api_url, json=data, headers={"Content-Type": "application/json"}, timeout=10)
            if response.status_code == 200:
                result = response.json()
                if isinstance(result, list) and len(result) > 0:
                    text = result[0].get("generated_text", "")
                    # 移除原始prompt
                    if text.startswith(prompt):
                        text = text[len(prompt):].strip()
                    return text
                elif isinstance(result, dict):
                    text = result.get("generated_text", "")
                    if text.startswith(prompt):
                        text = text[len(prompt):].strip()
                    return text
            elif response.status_code == 503:
                # 模型加载中，等待后重试
                time.sleep(3)
                return self._try_huggingchat_api(prompt)
        except Exception as e:
            logger.debug(f"HuggingChat API 失败: {e}")
        return None
    
    def _try_together_api(self, prompt: str) -> str:
        """尝试使用 Together AI API（免费额度）"""
        try:
            url = "https://api.together.xyz/v1/chat/completions"
            headers = {"Content-Type": "application/json"}
            data = {
                "model": "meta-llama/Llama-3-8b-chat-hf",
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": 300
            }
            response = requests.post(url, headers=headers, json=data, timeout=10)
            if response.status_code == 200:
                return response.json()["choices"][0]["message"]["content"]
        except:
            pass
        return None
    
    def _fallback_response(self, user_input: str) -> str:
        """智能基础回复（完全离线，快速响应）"""
        user_lower = user_input.lower()
        
        # 问候语
        if any(word in user_lower for word in ["你好", "hello", "hi", "早上好", "下午好", "晚上好", "和我聊天", "聊天"]):
            return "您好！我是 JARVIS，您的个人AI助手。有什么可以帮您的吗？我可以帮您打开应用、搜索内容、整理文件等。"
        
        # 时间查询
        if any(word in user_lower for word in ["时间", "现在几点", "what time", "几点"]):
            from datetime import datetime
            return f"当前时间是 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        
        # 帮助
        if any(word in user_lower for word in ["帮助", "help", "功能", "能做什么", "如何使用"]):
            return """🤖 JARVIS 功能说明：

📱 基础功能：
- 打开应用：打开Safari、打开微信等
- 搜索内容：搜索Python教程、搜索天气等
- 整理文件：整理桌面文件（按类型分类）
- 任务管理：添加任务、查看今日任务

🖱️ 自动化控制：
- 鼠标控制：移动、点击、拖拽
- 键盘输入：自动输入文本、快捷键
- 屏幕操作：截图、图像识别

🎤 语音功能：
- 文本转语音
- 语音输入

💡 提示：要启用完整AI对话功能，请在 config.json 中配置 Qwen 或 DeepSeek API 密钥。"""
        
        # 默认智能回复
        responses = {
            "打开": "我可以帮您打开应用，请告诉我要打开什么应用（如：打开Safari）",
            "搜索": "我可以帮您搜索内容，请告诉我要搜索什么（如：搜索Python教程）",
            "整理": "我可以帮您整理文件，请告诉我要整理哪个目录（如：整理桌面文件）",
            "任务": "我可以帮您管理任务，请告诉我要添加什么任务",
        }
        
        for key, value in responses.items():
            if key in user_input:
                return value
        
        return f"我理解您说的是：{user_input}。\n\n💡 提示：要启用完整AI对话功能，请在 config.json 中配置 Qwen 或 DeepSeek API 密钥。\n\n您可以尝试：\n- 打开应用（如：打开Safari）\n- 搜索内容（如：搜索Python教程）\n- 整理文件（如：整理桌面文件）"
