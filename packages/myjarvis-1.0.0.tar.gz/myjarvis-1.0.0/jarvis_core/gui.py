"""
图形界面模块 - 使用 Tkinter 创建主窗口
"""
import os
import sys
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import threading
from typing import Callable, Optional
import logging

# macOS 12 兼容性修复
if sys.platform == 'darwin':
    # 设置环境变量以修复 macOS 12 上的窗口初始化问题
    os.environ['TK_SILENCE_DEPRECATION'] = '1'
    # 确保在主线程中运行
    if hasattr(sys, '_getframe'):
        import threading
        if threading.current_thread() is not threading.main_thread():
            logger = logging.getLogger(__name__)
            logger.warning("GUI 应在主线程中创建")

logger = logging.getLogger(__name__)


class JARVISGUI:
    """JARVIS 图形界面"""
    
    def __init__(self, on_command: Optional[Callable] = None, on_voice_input: Optional[Callable] = None):
        """
        初始化GUI
        
        Args:
            on_command: 命令输入回调函数
            on_voice_input: 语音输入回调函数
        """
        self.on_command = on_command
        self.on_voice_input = on_voice_input
        self.root = None
        self.theme = "dark"
        self.automation_enabled = False
        self._init_gui()
    
    def _init_gui(self):
        """初始化GUI界面"""
        # 确保在主线程中运行
        if sys.platform == 'darwin':
            import threading
            if threading.current_thread() is not threading.main_thread():
                raise RuntimeError("GUI 必须在主线程中创建！")
        
        try:
            # macOS 12 兼容性：分步骤初始化，避免崩溃
            # 第一步：创建根窗口（不设置任何属性）
            self.root = tk.Tk()
            
            # 立即隐藏窗口，避免在初始化过程中显示
            self.root.withdraw()
            
            # 第二步：设置基本窗口属性（不涉及颜色）
            self.root.title("MyJARVIS - Your Personal AI")
            self.root.geometry("800x600")
            self.root.minsize(600, 400)
            
            # macOS 特定设置（延迟执行）
            if sys.platform == 'darwin':
                def set_mac_style():
                    try:
                        self.root.tk.call('::tk::unsupported::MacWindowStyle', 
                                         self.root._w, 'style', 'documentProc')
                    except:
                        pass
                # 延迟执行 macOS 特定设置
                self.root.after(100, set_mac_style)
            
            # 第三步：创建界面元素（完全不设置颜色，使用系统默认）
            self._create_widgets()
            
            # 第四步：绑定事件
            self._bind_events()
            
            # 第五步：显示窗口（在创建完所有组件后）
            # 使用 update_idletasks 确保所有组件都已创建
            self.root.update_idletasks()
            
            # 延迟显示窗口，给系统时间完成初始化
            import time
            time.sleep(0.1)  # 短暂延迟，确保系统准备好
            
            self.root.deiconify()
            self.root.update_idletasks()
            
            logger.info("GUI界面初始化完成（使用系统默认主题）")
            
        except Exception as e:
            logger.error(f"GUI初始化失败: {e}")
            import traceback
            traceback.print_exc()
            # 如果初始化失败，尝试清理
            if self.root:
                try:
                    self.root.destroy()
                except:
                    pass
            raise
    
    def _apply_dark_theme(self):
        """应用暗黑主题（macOS 12 上禁用）"""
        # macOS 12 上完全禁用，避免崩溃
        if sys.platform == 'darwin':
            logger.info("macOS 12 兼容模式：使用系统默认主题")
            return
        # 其他系统可以尝试应用
        self._apply_dark_theme_safe()
    
    def _apply_dark_theme_safe(self):
        """安全地应用暗黑主题（macOS 12 兼容）"""
        # macOS 12 上完全禁用颜色设置，使用系统默认主题
        if sys.platform == 'darwin':
            logger.info("macOS 12 兼容模式：使用系统默认主题，不应用自定义颜色")
            return
        
        # 非 macOS 12 系统可以尝试应用主题
        try:
            def apply_colors():
                try:
                    self.colors = {
                        "bg": "#1e1e1e",
                        "fg": "#ffffff",
                        "entry_bg": "#2d2d2d",
                        "entry_fg": "#ffffff",
                        "button_bg": "#3d3d3d",
                        "button_hover": "#4d4d4d",
                        "text_bg": "#252525",
                        "text_fg": "#ffffff",
                        "accent": "#007acc"
                    }
                    self.root.configure(bg=self.colors["bg"])
                except Exception as e:
                    logger.warning(f"应用主题颜色时出错: {e}")
            
            self.root.after(500, apply_colors)
        except Exception as e:
            logger.warning(f"应用暗黑主题失败: {e}，使用默认主题")
    
    def _create_widgets(self):
        """创建界面组件（macOS 12 兼容：不设置任何颜色）"""
        # 主容器（不设置 bg，使用系统默认）
        main_frame = tk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 消息显示区（不设置颜色）
        message_label = tk.Label(
            main_frame,
            text="对话历史",
            font=("Arial", 12, "bold"),
            anchor="w"
        )
        message_label.pack(fill=tk.X, pady=(0, 5))
        
        self.message_area = scrolledtext.ScrolledText(
            main_frame,
            font=("Arial", 11),
            wrap=tk.WORD,
            state=tk.DISABLED
        )
        self.message_area.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # 控制面板（不设置颜色）
        control_frame = tk.Frame(main_frame)
        control_frame.pack(fill=tk.X, pady=(0, 10))
        
        # 自动化开关（不设置颜色）
        automation_frame = tk.Frame(control_frame)
        automation_frame.pack(side=tk.LEFT)
        
        self.automation_var = tk.BooleanVar(value=False)
        automation_check = tk.Checkbutton(
            automation_frame,
            text="执行自动化",
            variable=self.automation_var,
            font=("Arial", 10),
            command=self._on_automation_toggle
        )
        automation_check.pack(side=tk.LEFT, padx=(0, 20))
        
        # 主题切换按钮（不设置颜色）
        theme_button = tk.Button(
            control_frame,
            text="🌓 切换主题",
            font=("Arial", 10),
            command=self._toggle_theme,
            relief=tk.FLAT,
            padx=10,
            pady=5
        )
        theme_button.pack(side=tk.RIGHT)
        
        # 输入区域（不设置颜色）
        input_frame = tk.Frame(main_frame)
        input_frame.pack(fill=tk.X)
        
        self.input_entry = tk.Entry(
            input_frame,
            font=("Arial", 11),
            relief=tk.FLAT
        )
        self.input_entry.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10), ipady=8)
        
        # 语音输入按钮（不设置颜色）
        voice_button = tk.Button(
            input_frame,
            text="🎤 语音输入",
            font=("Arial", 10, "bold"),
            command=self._on_voice_input,
            relief=tk.FLAT,
            padx=15,
            pady=8
        )
        voice_button.pack(side=tk.LEFT, padx=(0, 10))
        
        # 发送按钮（不设置颜色）
        send_button = tk.Button(
            input_frame,
            text="发送",
            font=("Arial", 10, "bold"),
            command=self._on_send,
            relief=tk.FLAT,
            padx=20,
            pady=8
        )
        send_button.pack(side=tk.LEFT)
    
    def _bind_events(self):
        """绑定事件"""
        # 回车键发送
        self.input_entry.bind("<Return>", lambda e: self._on_send())
        # 聚焦输入框
        self.input_entry.focus_set()
    
    def _on_send(self):
        """发送命令"""
        command = self.input_entry.get().strip()
        if command:
            self.add_message("用户", command)
            self.input_entry.delete(0, tk.END)
            if self.on_command:
                # 在新线程中执行，避免阻塞UI
                threading.Thread(target=self.on_command, args=(command,), daemon=True).start()
    
    def _on_voice_input(self):
        """语音输入"""
        if self.on_voice_input:
            self.add_message("系统", "正在监听语音输入...")
            threading.Thread(target=self.on_voice_input, daemon=True).start()
        else:
            messagebox.showinfo("提示", "语音输入功能未启用")
    
    def _on_automation_toggle(self):
        """自动化开关切换"""
        self.automation_enabled = self.automation_var.get()
        status = "已启用" if self.automation_enabled else "已禁用"
        self.add_message("系统", f"自动化控制: {status}")
        logger.info(f"自动化控制: {status}")
    
    def _toggle_theme(self):
        """切换主题（macOS 12 上禁用）"""
        if sys.platform == 'darwin':
            messagebox.showinfo("提示", "macOS 12 上主题切换已禁用，使用系统默认主题")
            return
        
        if self.theme == "dark":
            self.theme = "light"
            self.colors = {
                "bg": "#ffffff",
                "fg": "#000000",
                "entry_bg": "#f0f0f0",
                "entry_fg": "#000000",
                "button_bg": "#e0e0e0",
                "button_hover": "#d0d0d0",
                "text_bg": "#fafafa",
                "text_fg": "#000000",
                "accent": "#007acc"
            }
        else:
            self.theme = "dark"
            self.colors = {
                "bg": "#1e1e1e",
                "fg": "#ffffff",
                "entry_bg": "#2d2d2d",
                "entry_fg": "#ffffff",
                "button_bg": "#3d3d3d",
                "button_hover": "#4d4d4d",
                "text_bg": "#252525",
                "text_fg": "#ffffff",
                "accent": "#007acc"
            }
        
        # 安全地应用主题
        self._apply_dark_theme_safe()
        
        # 重新创建界面
        for widget in self.root.winfo_children():
            widget.destroy()
        self._create_widgets()
        logger.info(f"主题切换为: {self.theme}")
    
    def add_message(self, sender: str, message: str):
        """
        添加消息到显示区
        
        Args:
            sender: 发送者（"用户"、"JARVIS"、"系统"）
            message: 消息内容
        """
        self.message_area.config(state=tk.NORMAL)
        
        # 根据发送者设置颜色
        if sender == "用户":
            tag = "user"
            prefix = "👤 您: "
        elif sender == "JARVIS":
            tag = "jarvis"
            prefix = "🤖 JARVIS: "
        else:
            tag = "system"
            prefix = "ℹ️ 系统: "
        
        # 配置标签样式（macOS 12 上使用系统颜色）
        try:
            if sys.platform == 'darwin':
                # macOS 12 兼容：使用系统颜色
                if sender == "JARVIS":
                    self.message_area.tag_config(tag, foreground="SystemHighlight")
                elif sender == "系统":
                    self.message_area.tag_config(tag, foreground="SystemGray")
                else:
                    self.message_area.tag_config(tag, foreground="SystemWindowTextColor")
            else:
                # 其他系统可以使用自定义颜色
                self.message_area.tag_config(tag, foreground=self.colors.get("fg", "black"))
                if sender == "JARVIS":
                    self.message_area.tag_config(tag, foreground=self.colors.get("accent", "blue"))
                elif sender == "系统":
                    self.message_area.tag_config(tag, foreground="#888888")
        except Exception as e:
            logger.warning(f"设置消息颜色失败: {e}")
        
        # 插入消息
        self.message_area.insert(tk.END, f"{prefix}{message}\n\n", tag)
        self.message_area.see(tk.END)
        self.message_area.config(state=tk.DISABLED)
    
    def get_automation_enabled(self) -> bool:
        """获取自动化是否启用"""
        return self.automation_enabled
    
    def run(self):
        """运行GUI主循环"""
        try:
            self.root.mainloop()
        except Exception as e:
            logger.error(f"GUI运行错误: {e}")
    
    def destroy(self):
        """销毁GUI"""
        if self.root:
            self.root.destroy()
