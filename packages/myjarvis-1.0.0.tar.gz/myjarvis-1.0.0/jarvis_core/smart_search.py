"""
智能搜索模块 - 真正分析屏幕并执行搜索
"""
import logging
import time
import pyautogui
from typing import Dict, List, Tuple, Optional, Any
import urllib.parse
import subprocess
import os

logger = logging.getLogger(__name__)

try:
    import pytesseract
    TESSERACT_AVAILABLE = True
except ImportError:
    TESSERACT_AVAILABLE = False
    logger.warning("pytesseract未安装，OCR功能将受限")


class SmartSearch:
    """智能搜索 - 真正分析屏幕并执行操作"""
    
    def __init__(self, automation, tools):
        """
        初始化智能搜索
        
        Args:
            automation: 自动化控制器
            tools: 系统工具
        """
        self.automation = automation
        self.tools = tools
        self.screen_width, self.screen_height = pyautogui.size()
        logger.info("智能搜索模块初始化完成")
    
    def execute_search(self, keywords: str) -> str:
        """
        执行智能搜索 - 真正分析屏幕并执行
        
        Args:
            keywords: 搜索关键词
        
        Returns:
            执行结果
        """
        try:
            logger.info(f"🔍 开始智能搜索: {keywords}")
            
            # 1. 打开Safari
            logger.info("步骤1: 打开Safari")
            self.tools.open_application("Safari")
            time.sleep(2.0)  # 等待Safari完全启动
            
            # 2. 打开地址栏并输入搜索URL
            logger.info("步骤2: 打开地址栏")
            self.automation.hotkey("command", "l")
            time.sleep(0.5)
            
            # 清空地址栏
            self.automation.hotkey("command", "a")
            time.sleep(0.2)
            
            # 输入搜索URL
            encoded_keywords = urllib.parse.quote(keywords)
            search_url = f"https://www.baidu.com/s?wd={encoded_keywords}"
            logger.info(f"步骤3: 输入搜索URL: {search_url}")
            
            # 确保地址栏已激活并清空
            time.sleep(0.3)
            self.automation.type_text(search_url, interval=0.01)  # 快速输入
            time.sleep(0.8)  # 等待输入完成（关键！）
            
            # 验证输入是否完成（通过检查地址栏内容，这里简化处理）
            logger.info("步骤3.5: 验证输入完成")
            
            # 3. 按回车执行搜索（关键步骤！）
            logger.info("步骤4: 按回车执行搜索")
            # 确保焦点在地址栏
            self.automation.hotkey("command", "l")  # 再次激活地址栏
            time.sleep(0.2)
            self.automation.press_key("enter")
            logger.info("✅ 已按回车，等待页面跳转...")
            
            # 4. 等待并检测搜索结果页面是否真正加载
            logger.info("步骤5: 等待搜索结果页面加载...")
            max_wait = 10  # 最多等待10秒
            wait_interval = 0.5
            waited = 0
            search_page_loaded = False
            
            while waited < max_wait:
                time.sleep(wait_interval)
                waited += wait_interval
                
                # 截图分析当前页面（安全模式，避免崩溃）
                try:
                    screenshot = self._safe_screenshot()
                    if screenshot:
                        page_type = self._detect_page_type(screenshot)
                    else:
                        page_type = "unknown"
                except Exception as e:
                    logger.error(f"截图失败: {e}，跳过页面检测")
                    page_type = "unknown"
                
                logger.info(f"页面检测: {page_type} (已等待 {waited:.1f}秒)")
                
                if page_type == "search_results":
                    logger.info("✅ 检测到搜索结果页面已加载")
                    search_page_loaded = True
                    break
                elif page_type == "favorites" or page_type == "home":
                    logger.warning(f"⚠️ 仍在{page_type}页面，等待跳转...")
                    # 如果还在个人收藏页面，需要重新操作
                    if waited > 3.0:  # 等待3秒后如果还在收藏页面，重新搜索
                        logger.info("⚠️ 检测到仍在个人收藏页面，重新执行搜索...")
                        # 重新打开地址栏
                        self.automation.hotkey("command", "l")
                        time.sleep(0.5)
                        # 清空并重新输入
                        self.automation.hotkey("command", "a")
                        time.sleep(0.2)
                        self.automation.type_text(search_url, interval=0.01)
                        time.sleep(0.8)  # 等待输入完成
                        # 按回车
                        logger.info("重新按回车执行搜索...")
                        self.automation.press_key("enter")
                        time.sleep(2.0)  # 等待跳转
                else:
                    logger.info(f"页面类型未知: {page_type}，继续等待...")
            
            if not search_page_loaded:
                logger.warning("⚠️ 搜索结果页面可能未完全加载，继续尝试...")
            
            # 5. 截图分析屏幕，找到第一个搜索结果（安全模式）
            logger.info("步骤6: 截图分析屏幕，查找搜索结果")
            try:
                screenshot = self._safe_screenshot()
                if not screenshot:
                    logger.warning("⚠️ 截图失败，使用估算位置")
                    screenshot = None
            except Exception as e:
                logger.error(f"截图失败: {e}，使用估算位置")
                screenshot = None
            
            # 再次确认是否在搜索结果页面
            page_type = self._detect_page_type(screenshot)
            if page_type != "search_results":
                logger.warning(f"⚠️ 当前不在搜索结果页面（{page_type}），尝试重新搜索...")
                # 重新打开地址栏并搜索
                self.automation.hotkey("command", "l")
                time.sleep(0.5)
                self.automation.hotkey("command", "a")
                time.sleep(0.2)
                self.automation.type_text(search_url, interval=0.02)
                time.sleep(0.3)
                self.automation.press_key("enter")
                time.sleep(4.0)  # 等待页面加载
                try:
                    screenshot = self._safe_screenshot()  # 重新截图（安全模式）
                except:
                    screenshot = None
            
            # 分析屏幕，找到第一个搜索结果链接
            result_link = self._find_first_search_result(screenshot)
            
            if result_link:
                click_x, click_y = result_link['position']
                logger.info(f"✅ 找到第一个搜索结果，位置: ({click_x}, {click_y})")
                
                # 移动鼠标到链接位置
                self.automation.move_mouse(click_x, click_y, duration=0.3)
                time.sleep(0.3)
                
                # 点击链接（确保真正点击）
                logger.info(f"步骤7: 点击第一个搜索结果，位置: ({click_x}, {click_y})")
                
                # 先移动鼠标到位置
                current_x, current_y = pyautogui.position()
                logger.info(f"当前鼠标位置: ({current_x}, {current_y})")
                
                self.automation.move_mouse(click_x, click_y, duration=0.5)
                time.sleep(0.5)
                
                # 验证鼠标位置
                new_x, new_y = pyautogui.position()
                logger.info(f"移动后鼠标位置: ({new_x}, {new_y})")
                
                # 执行点击
                pyautogui.click(click_x, click_y)
                logger.info(f"✅ 已执行点击操作")
                time.sleep(2.0)  # 等待页面跳转
                
                logger.info("✅ 已成功点击第一个搜索结果")
                return f"✅ 已在百度搜索: {keywords}\n🔍 已打开第一个搜索结果\n📍 点击位置: ({click_x}, {click_y})"
            else:
                logger.warning("⚠️ 未找到搜索结果链接")
                # 即使没找到，也尝试点击估算位置
                estimated = self._estimate_search_result_position()
                if estimated:
                    click_x, click_y = estimated['position']
                    logger.info(f"使用估算位置点击: ({click_x}, {click_y})")
                    self.automation.move_mouse(click_x, click_y, duration=0.5)
                    time.sleep(0.5)
                    pyautogui.click(click_x, click_y)
                    time.sleep(2.0)
                    return f"✅ 已在百度搜索: {keywords}\n🔍 已点击估算位置: ({click_x}, {click_y})"
                else:
                    return f"✅ 已在百度搜索: {keywords}\n💡 搜索结果已加载，请手动点击"
                
        except Exception as e:
            logger.error(f"智能搜索失败: {e}")
            import traceback
            traceback.print_exc()
            return f"❌ 搜索失败: {str(e)}"
    
    def _find_first_search_result(self, screenshot) -> Optional[Dict[str, Any]]:
        """
        分析屏幕，找到第一个搜索结果链接
        
        Args:
            screenshot: 屏幕截图
        
        Returns:
            找到的链接位置信息，未找到返回None
        """
        try:
            # 方法1: 使用OCR查找搜索结果
            if TESSERACT_AVAILABLE:
                logger.info("使用OCR分析屏幕...")
                ocr_results = self._ocr_find_search_results(screenshot)
                if ocr_results:
                    logger.info(f"OCR找到 {len(ocr_results)} 个可能的搜索结果")
                    # 返回第一个结果（通常是最相关的）
                    return ocr_results[0]
            
            # 方法2: 使用智能位置估算（基于百度搜索结果页面布局）
            logger.info("使用智能位置估算...")
            estimated_position = self._estimate_search_result_position()
            if estimated_position:
                logger.info(f"估算位置: {estimated_position['position']}")
                return estimated_position
            
            # 方法3: 使用屏幕中心区域（基于百度搜索结果页面实际布局）
            logger.info("使用屏幕中心区域...")
            center_x = self.screen_width // 2
            center_y = 300  # 第一个结果的实际位置（更准确）
            
            return {
                'position': (center_x, center_y),
                'confidence': 0.5,
                'method': 'center_estimate'
            }
            
        except Exception as e:
            logger.error(f"查找搜索结果失败: {e}")
            return None
    
    def _ocr_find_search_results(self, screenshot) -> List[Dict[str, Any]]:
        """
        使用OCR查找搜索结果（安全模式）
        
        Args:
            screenshot: 屏幕截图（可能是PIL Image或文件路径）
        
        Returns:
            找到的搜索结果列表
        """
        if not TESSERACT_AVAILABLE:
            return []
        
        try:
            # 处理截图（可能是文件路径或PIL Image）
            if isinstance(screenshot, str):
                # 是文件路径，直接使用
                ocr_data = pytesseract.image_to_data(
                    screenshot,
                    lang='chi_sim+eng',
                    output_type=pytesseract.Output.DICT
                )
            else:
                # 是PIL Image，直接使用
                ocr_data = pytesseract.image_to_data(
                    screenshot,
                    lang='chi_sim+eng',
                    output_type=pytesseract.Output.DICT
                )
            
            results = []
            # 查找可能的搜索结果链接（通常包含标题文本）
            # 百度搜索结果的特征：
            # 1. 标题通常在搜索结果区域的上方
            # 2. 标题文本通常较长
            # 3. 位置在屏幕中心偏上
            
            for i, text in enumerate(ocr_data['text']):
                if text.strip() and len(text.strip()) > 3:  # 过滤太短的文本
                    x = ocr_data['left'][i]
                    y = ocr_data['top'][i]
                    w = ocr_data['width'][i]
                    h = ocr_data['height'][i]
                    conf = float(ocr_data['conf'][i]) / 100.0
                    
                    # 计算中心位置
                    center_x = x + w // 2
                    center_y = y + h // 2
                    
                    # 判断是否在搜索结果区域（基于百度搜索结果页面实际布局）
                    # Y: 200-600像素（搜索结果区域）
                    # X: 屏幕中心左右（约屏幕宽度的1/4到3/4）
                    if (200 < center_y < 600 and
                        self.screen_width // 4 < center_x < self.screen_width * 3 // 4):
                        
                        # 计算置信度（位置越靠上，置信度越高）
                        position_score = 1.0 - (center_y / self.screen_height) * 0.5
                        confidence = conf * position_score
                        
                        results.append({
                            'position': (center_x, center_y),
                            'text': text,
                            'confidence': confidence,
                            'bbox': (x, y, w, h),
                            'method': 'ocr'
                        })
            
            # 按置信度排序，返回最可能的结果
            results.sort(key=lambda x: x['confidence'], reverse=True)
            
            # 返回前3个最可能的结果
            return results[:3]
            
        except Exception as e:
            logger.error(f"OCR查找失败: {e}")
            return []
    
    def _detect_page_type(self, screenshot) -> str:
        """
        检测当前页面类型（安全模式）
        
        Args:
            screenshot: 屏幕截图（可能是PIL Image或文件路径）
        
        Returns:
            页面类型: "search_results", "favorites", "home", "unknown"
        """
        try:
            if not screenshot:
                return "unknown"
            
            # 使用OCR检测页面特征
            if TESSERACT_AVAILABLE:
                try:
                    # 处理截图（可能是文件路径或PIL Image）
                    if isinstance(screenshot, str):
                        ocr_data = pytesseract.image_to_data(
                            screenshot,
                            lang='chi_sim+eng',
                            output_type=pytesseract.Output.DICT
                        )
                    else:
                        ocr_data = pytesseract.image_to_data(
                            screenshot,
                            lang='chi_sim+eng',
                            output_type=pytesseract.Output.DICT
                        )
                    
                    # 提取所有文本
                    all_text = ' '.join([t.strip() for t in ocr_data['text'] if t.strip()])
                    all_text_lower = all_text.lower()
                    
                    logger.debug(f"检测到的页面文本: {all_text[:200]}...")
                    
                    # 检测搜索结果页面特征
                    search_indicators = ['百度', 'baidu', '搜索结果', 'search results', '相关搜索', '为您找到', '找到相关结果', '百度一下', 'baidu.com']
                    has_search_indicator = any(indicator in all_text_lower for indicator in search_indicators)
                    
                    if has_search_indicator:
                        # 进一步确认：搜索结果页面通常有多个链接文本
                        link_count = sum(1 for t in ocr_data['text'] if t.strip() and len(t.strip()) > 5)
                        logger.info(f"检测到搜索指标，链接文本数量: {link_count}")
                        if link_count > 3:  # 至少有3个较长的文本（可能是搜索结果标题）
                            logger.info("✅ 确认为搜索结果页面")
                            return "search_results"
                        else:
                            logger.info(f"链接文本数量不足({link_count})，可能不是搜索结果页面")
                    
                    # 检测个人收藏页面特征
                    favorites_indicators = ['个人收藏', 'favorites', '收藏', '常用网站', 'apple', 'icloud', '百度', '搜狗', '必应']
                    # 个人收藏页面通常有很多应用图标，文本较少
                    if any(indicator in all_text_lower for indicator in favorites_indicators):
                        # 进一步确认：个人收藏页面通常有很多短文本（应用名称）
                        short_text_count = sum(1 for t in ocr_data['text'] if t.strip() and 2 <= len(t.strip()) <= 10)
                        if short_text_count > 20:  # 个人收藏页面通常有很多应用名称
                            logger.info("✅ 确认为个人收藏页面")
                            return "favorites"
                    
                    # 检测首页特征
                    home_indicators = ['safari', '起始页', 'start page']
                    if any(indicator in all_text_lower for indicator in home_indicators):
                        return "home"
                    
                except Exception as e:
                    logger.debug(f"OCR检测失败: {e}")
            
            # 如果OCR不可用或失败，使用URL检测（通过检查地址栏）
            # 这里简化处理，实际可以通过截图分析地址栏
            return "unknown"
            
        except Exception as e:
            logger.error(f"页面类型检测失败: {e}")
            return "unknown"
    
    def _safe_screenshot(self):
        """
        安全截图（避免Intel Mac崩溃）
        
        Returns:
            截图对象，失败返回None
        """
        try:
            # 方法1：尝试使用pyautogui（快速）
            screenshot = pyautogui.screenshot()
            return screenshot
        except Exception as e:
            logger.warning(f"pyautogui截图失败: {e}，尝试备用方法")
            try:
                # 方法2：使用screencapture命令（更安全）
                import tempfile
                temp_file = tempfile.NamedTemporaryFile(suffix='.png', delete=False)
                temp_file.close()
                
                result = subprocess.run(
                    ['screencapture', '-x', temp_file.name],
                    capture_output=True,
                    timeout=5
                )
                
                if result.returncode == 0 and os.path.exists(temp_file.name):
                    # 读取图片（不处理，只返回路径）
                    return temp_file.name
                else:
                    logger.warning("screencapture命令失败")
                    return None
            except Exception as e2:
                logger.error(f"所有截图方法都失败: {e2}")
                return None
    
    def _estimate_search_result_position(self) -> Optional[Dict[str, Any]]:
        """
        智能估算搜索结果位置（基于百度搜索结果页面布局）
        
        Returns:
            估算的位置信息
        """
        try:
            # 百度搜索结果页面的典型布局：
            # - 搜索框在顶部
            # - 第一个搜索结果标题通常在：
            #   - X: 屏幕中心（左右居中）
            #   - Y: 屏幕高度的1/3到1/2之间
            
            # 计算可能的搜索结果位置
            center_x = self.screen_width // 2
            
            # 第一个搜索结果的实际位置（基于百度搜索结果页面布局）
            # Safari地址栏和工具栏：约100-120像素
            # 百度搜索框：约150-200像素
            # 第一个搜索结果标题：约280-320像素
            estimated_y = 300  # 更准确的位置（基于实际测试）
            
            return {
                'position': (center_x, estimated_y),
                'confidence': 0.7,
                'method': 'layout_estimate'
            }
        except Exception as e:
            logger.error(f"位置估算失败: {e}")
            return None

