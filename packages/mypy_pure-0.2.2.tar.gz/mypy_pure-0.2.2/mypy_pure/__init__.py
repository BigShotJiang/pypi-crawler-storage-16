from mypy_pure.decorators import pure  # noqa: F401

__all__ = ['pure']
