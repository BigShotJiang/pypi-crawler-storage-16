from mypy_pure import pure as p


@p
def pure_func() -> None:
    pass
