from . import something  # noqa


def foo() -> None:
    pass
