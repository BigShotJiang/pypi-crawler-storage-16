[![PyPi Version](https://img.shields.io/pypi/v/mypythonlibrary.svg?style=flat-square)](https://pypi.org/project/mypythonlibrary)
[![PyPI Downloads](https://static.pepy.tech/badge/mypythonlibrary)](https://pepy.tech/projects/mypythonlibrary)

# myPythonLibrary

A collection of python tools.

## Installation

```
pip install myPythonLibrary
```
