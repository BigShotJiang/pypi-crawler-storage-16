# mytools-nn

A python toolkit for file operations and Qwen API client.

## Install

pip install mytools-nn

## Usage
```python
from mytools_nn import mytools
print(mytools.add_timestamp_to_filename("data.json"))
```
