# coding=utf-8
import os
import time
import json
import re
import csv
import codecs
import requests
import pandas as pd
from functools import reduce
from openai import OpenAI
current_file_dir = os.getcwd()

base_dir = os.getcwd()


def get_string_from_content(content,pattern):
    matches = re.findall(pattern,content,flags=re.S)
    if matches:
        result = matches[-1]  # 取最后一个匹配
        return result
    else:
        return ''


def add_timestamp_to_filename(filename):
    import os
    import datetime
    # 获取当前时间
    now = datetime.datetime.now()

    # 格式化时间字符串（可以根据需要调整格式）
    timestamp = now.strftime("%Y%m%d_%H%M%S")

    # 分离文件名和扩展名
    name, ext = os.path.splitext(filename)

    # 构建新文件名
    new_filename = f"{name}_{timestamp}{ext}"

    return new_filename

def qwen_server_normal(_api_key,_base_url,model,content,think=True):
    client = OpenAI(api_key=_api_key,base_url=_base_url)
    start = time.time()
    completion = client.chat.completions.create(
        # 模型列表：
        model=model,
        messages=[
            {
                'role': 'user',
                'content': content
            }
        ],
        # Qwen3模型通过enable_thinking参数控制思考过程（开源版默认True，商业版默认False）
        # 使用Qwen3开源版模型时，若未启用流式输出，请将下行取消注释，否则会报错
        # extra_body={"enable_thinking": False},
        temperature=0,
        presence_penalty=1.5,
        response_format={"type": "json_object"},
        extra_body={
            "top_k": 1,
            "chat_template_kwargs": {"enable_thinking": think},
        },
    )
    print(f"[阿里云推理时间] time: {time.time() - start:.3f}s")
    json_content = completion.model_dump_json()  # 获取JSON字符串
    data = json.loads(json_content)  # 反序列化为字典
    content = data["choices"][0]["message"]["content"]  # 访问目标字段
    return content


def write_json(write_path, content_line):
    with open(write_path, "w+", encoding="utf-8") as writer:
        writer.write(json.dumps(content_line, ensure_ascii=False, indent=4))


def write_csv(csv_file, data_list):
    with open(csv_file, mode='w+', newline='', encoding="utf-8") as file:
        writer = csv.writer(file)
        for row in data_list:
            writer.writerow([row])

def write_json_by_line(write_path, content_line):
    with open(write_path, "w+", encoding="utf-8") as writer:
        for line in content_line:
            writer.write(json.dumps(line, ensure_ascii=False))
            writer.write("\n")


def write_json_a(write_path, content):
    with open(write_path, "w+", encoding="utf-8") as writer:
        writer.write(json.dumps(content, ensure_ascii=False))


def read_text(path):
    import json
    with open(path, "r", encoding="utf-8") as reader:
        return [json.loads(i.replace("\n", "")) for i in reader.readlines()]


def read_txt(path):
    with open(path, "r", encoding="utf-8") as reader:
        return reader.read()


def read_json_file(filename):
    """
    读取当前目录下的JSON文件

    参数:
        filename (str): 要读取的JSON文件名（包含扩展名）

    返回:
        dict: 解析后的JSON数据，如果出错则返回None
    """
    # 获取当前目录
    current_dir = os.path.dirname(os.path.abspath(__file__))
    # 拼接文件完整路径
    file_path = os.path.join(current_dir, filename)

    try:
        # 检查文件是否存在
        if not os.path.exists(file_path):
            print(f"错误: 文件 '{filename}' 不存在于当前目录")
            return None

        # 打开并读取JSON文件
        with open(file_path, 'r', encoding='utf-8') as file:
            data = json.load(file)
            # print(f"成功读取文件: {filename}")
            return data

    except json.JSONDecodeError:
        print(f"错误: 文件 '{filename}' 不是有效的JSON格式")
    except PermissionError:
        print(f"错误: 没有权限读取文件 '{filename}'")
    except Exception as e:
        print(f"读取文件时发生错误: {str(e)}")

    return None


# 用户自定义词典

def find_chinese_word(string):
    string = string.strip()
    pattern = r"[\u4e00-\u9fa5]+"
    pat = re.compile(pattern)
    result = pat.findall(string)
    if result:
        return " ".join(result)
    else:
        return ""


def find_english_word(string):
    pattern = r"[a-zA-Z]+|（[a-zA-Z]+）"
    pat = re.compile(pattern)
    result = pat.findall(string.strip())
    return " ".join(result)


def find_index(string):
    pattern = r"[A-Z0-9,，]+"
    pat = re.compile(pattern)
    result_list = pat.findall(string)
    if result_list:
        return [result.replace(",", " ").replace("，", " ") for result in result_list][0]
    else:
        return ""


def load_data(path):
    content_list = list()
    with open(path, "r", encoding="utf-8") as reader:
        for line in reader:
            line = json.loads(line)
            content_list.append(line)
        return content_list


def get_string_index(string, string_one):
    index_num = -1
    index_list = []
    string_length = len(string_one)
    if string_length:
        b = string.count(string_one)
        for i in range(b):  # 查找所有的下标
            index_num = string.find(string_one, index_num + 1, len(string))
            index_list.append([str(index_num), str(index_num + string_length)])
    return index_list



def generate_hash_id(input_str):
    import hashlib
    hash_object = hashlib.md5(input_str.encode('utf-8'))
    unique_id = hash_object.hexdigest()
    return unique_id

def read_json(path,encoding_model="utf-8"):
    with open(path, "r", encoding=encoding_model) as reader:
        return json.loads(reader.read())




def gen_id2corpus(corpus_file):
    id2corpus = {}
    with open(corpus_file, "r", encoding="utf-8") as f:
        for idx, line in enumerate(f):
            id2corpus[idx] = line.rstrip()
    return id2corpus


def server_request_fuc(_url, data_list):
    content_list = list()
    data = {"data_list": data_list}

    headers = {'Content-Type': 'application/json;charset=utf8'}
    reponse = requests.get(_url, data=json.dumps(data), headers=headers)
    try:
        if reponse.status_code == 200:
            reponse = json.loads(reponse.text)
            content_list.append(reponse)
        else:
            return 500, []
    except Exception as e:
        return 500, [e]
    else:
        return 200, content_list


def get_model_server(url, question):
    payload = json.dumps({
        "question": question
    })
    headers = {
        'User-Agent': 'Apifox/1.0.0 (https://apifox.com)',
        'Content-Type': 'application/json'
    }

    response = requests.request("POST", url, headers=headers, data=payload)
    return response.json()


def get_content(object_list, content_name="CONTENT"):
    return [content['{0}'.format(content_name)] for content in object_list]


def write_text(write_path, content_line):
    with open(write_path, "w+", encoding="utf-8") as writer:
        for num, content in enumerate(content_line):
            if num != len(content_line) - 1:
                writer.write(content + "\n")
            else:
                writer.write(content)


def write_text3(write_path, content_lines):
    with open(write_path, "w+", encoding="utf-8") as writer:
        for content_line in content_lines:
            for line in content_line:
                writer.write(line + "\n")
            writer.write("\n")



def request_fuc(_url, _payload):
    headers = {
        'User-Agent': 'Apifox/1.0.0 (https://apifox.com)',
        'Content-Type': 'application/json'
    }
    try:
        _payload = json.dumps(_payload, ensure_ascii=False)
        _payload = _payload.encode("utf-8").decode("latin-1")
        response = requests.request("POST", _url, headers=headers, data=_payload)

        if response.json()['code'] == 200:
            return {"code": 200, "origin_data": response.json()['origin_data']}
        else:
            return {"code": 500, "origin_data": []}
    except Exception as e:
        return {"code": 500, "origin_data": [e]}


def fast_align_data(en_list, ch_list):
    en2ch_list = list()
    assert len(en_list) == len(ch_list)
    for num, ch_content in enumerate(ch_list):
        en_content = en_list[num]
        new_content = en_content + ' ||| ' + ch_content
        en2ch_list.append(new_content)
    return en2ch_list


def sub_word(string):
    pattern_one = u"\\(.*?\\)|\\（.*?）|\\[.*?]|-|“|”|``|''"
    result = re.sub(pattern_one, "", string)
    pattern_two = u" +"
    result = re.sub(pattern_two, " ", result)

    return result


def faq_milvus_conf(utility, collection, _collection_name, LoadState):
    # 按照城市加载对应的ms索引
    try:
        collection = collection(_collection_name)
        # assert utility.load_state("test_load_state") == LoadState.NotExist
        if utility.load_state(_collection_name) == LoadState.NotLoad:
            return 500, "milvus collection 没有被加载"
        else:
            return 200, collection
    except Exception as e:
        return 500, e



def write_csv_pd(write_csv_path, data_dict):
    df = pd.DataFrame(data_dict)
    df.to_csv(write_csv_path, index=False, header=True)


def compare_lists(a, b):
    # 将列表转换为集合
    set_a = set(a)
    set_b = set(b)

    # 判断 a 是否是 b 的子集
    if set_a.issubset(set_b):
        return 1
    else:
        return 0

def write_line_json(write_path, content_line):
    with open(write_path, "w+", encoding="utf-8") as writer:
        for line in content_line:
            writer.write(json.dumps({line: content_line[line]}, ensure_ascii=False))
            writer.write("\n")


def write_bio(write_path, content_line):
    with open(write_path, "w+", encoding="utf-8") as writer:
        for contents in content_line:
            for content in contents:
                writer.write(content + "\n")


def write_bio2(write_path, content_line):
    with open(write_path, "w+", encoding="utf-8") as writer:
        for contents in content_line:
            writer.writelines(contents)
            writer.write("\n")


def read_csv(read_path, model="utf-8"):
    content_list = list()
    with codecs.open(read_path, encoding=model) as f:
        for row in csv.DictReader(f, skipinitialspace=True):
            content_list.append(row)
    return content_list


def delete_duplicate_elements(list_data):
    return reduce(lambda x, y: x if y in x else x + [y], [[], ] + list_data)


def write_ann_text(write_path, content_line):
    with open(write_path, "w+", encoding="utf-8") as writer:
        for content in content_line:
            writer.write(content + "\n")


def search_refined(qq_list):
    _question_id = -1
    _num_list = list()
    _question_answer_dict = dict()
    search_result_list = list()
    for recall in qq_list:
        _question_id = _question_id + 1
        _num_list.append(str(_question_id))
        _question_answer_dict[_question_id] = recall
        string = "{'query': '%s', 'title': '%s'}" % (recall[0], recall[1])
        search_result_list.append(string)
    return _num_list, search_result_list, _question_answer_dict


def rocketqa_request_fuc(_url, question_num, _question_list, _question_answer_dict, global_variable):
    """
    :param _url: 服务接口
    :param question_num:这里是问题按照序列排号
    :param _question_list: 这里的list中要求对应为字符串["{'query': '%s', 'title': '%s'}"]
    :param _question_answer_dict:
    :param global_variable:
    :return: 返回服务处理结果
    """
    try:
        _data = {"key": question_num, "value": _question_list}
        _payload = json.dumps(_data, ensure_ascii=False)
        headers = {
            'Content-Type': 'application/json'
        }
        payload = _payload.encode("utf-8").decode("latin-1")
        response = requests.request("POST", _url, headers=headers, data=payload)
        if response.json()['value']:
            result_data = dict()
            result_data['rank_type'] = "qq"
            _result = eval(response.json()['value'][0])
            assert len(_result) == len(_question_list)
            if _result:
                satisfy_list = []
                not_satisfy_list = []
                for _num, question in enumerate(_question_list):
                    _data_dict = {}
                    _question = eval(question)
                    es_ms_result = _question_answer_dict[_num]
                    if _result[_num] > global_variable['rocket_qq_rank_threshold']:
                        _data_dict['sentences'] = es_ms_result
                        _data_dict['score'] = _result[_num]
                        satisfy_list.append(_data_dict)
                    else:
                        _data_dict['sentences'] = es_ms_result
                        _data_dict['score'] = _result[_num]
                        not_satisfy_list.append(_data_dict)
                result_data['satisfy_list'] = satisfy_list
                result_data['not_satisfy_list'] = not_satisfy_list
                return {"code": 200, "origin_data": result_data}
            else:
                return {"code": 500, "origin_data": []}
        else:
            return {"code": 500, "origin_data": []}
            # print("返回答案为空",response.json()['value'])

    except Exception as e:
        return {"code": 500, "origin_data": [e]}


def my_data_processing_platform(qq_rank_result, qa_rank_result, _global_variable):
    """
    :param qq_rank_result:
    :param qa_rank_result:
    :param _global_variable: 全局阈值
    :return:
    """
    other_data = []
    result_dict = {}
    similarity_data = []
    correlation_data = []
    similarity_threshold = _global_variable['similarity_threshold']
    correlation_threshold = _global_variable['correlation_threshold']
    # model_chat_threshold = _global_variable['model_chat_threshold']
    # 优先对qq进行精排，按照给定阈值进行过滤不合格的数据
    if qq_rank_result['code'] == 200:
        satisfy_list = qq_rank_result['origin_data']['satisfy_list']
        if satisfy_list:  # 这是第一层过滤，这一层主要将粗排后的结果拿过来
            for qq in satisfy_list:
                if qq['score'] > similarity_threshold:  # 这是第二层过滤，这一层主要让qq精排结果大于我们设定的相似度
                    similarity_data.append(qq)
                else:
                    if correlation_threshold <= qq['score'] <= similarity_threshold:
                        correlation_data.append(qq)
                    else:
                        other_data.append(qq)
    # 其次对qa进行精排排序
    if qa_rank_result['code'] == 200 and not similarity_data:
        qa_data = qa_rank_result['origin_data']['satisfy_list']
        if qa_data:  # 从es数据库中检索得到qa数据集
            if correlation_data:  # 不存在相似数据，但存在相关数据，此时需要对qa相关性判别
                for qa in qa_data:
                    if correlation_threshold <= qa['score']:
                        correlation_data.append(qa)
                    else:
                        other_data.append(qa)
    # 格式统一，对最后的结果进行统一输出最后的答案
    if len(similarity_data) > 1:
        _similarity_data = [i['sentences'] for i in similarity_data]
        result_dict["similarity"] = [i[1] for i in _similarity_data]
        _correlation_data = sorted(correlation_data, key=lambda e: e['score'], reverse=True)
        result_dict["correlation"] = [_c['sentences'][-1] for _c in _correlation_data]
    elif len(similarity_data) == 1:
        result_dict["similarity"] = [similarity_data[0]['sentences'][-1]]
        result_dict["correlation"] = [_c['sentences'][-1] for _c in correlation_data]
    else:
        result_dict["similarity"] = []
        result_dict["correlation"] = []
    result_dict["other"] = other_data
    return result_dict


def data_processing_platform(qq_rank_result, qa_rank_result, _global_variable):
    """
    :param qq_rank_result:
    :param qa_rank_result:
    :param _global_variable: 全局阈值
    :return:
    """
    other_data = []
    result_dict = {}
    similarity_data = []
    correlation_data = []
    similarity_threshold = _global_variable['similarity_threshold']
    correlation_threshold = _global_variable['correlation_threshold']
    # model_chat_threshold = _global_variable['model_chat_threshold']
    # 优先对qq进行精排，按照给定阈值进行过滤不合格的数据
    if qq_rank_result['code'] == 200:
        satisfy_list = qq_rank_result['origin_data']['satisfy_list']
        if satisfy_list:  # 这是第一层过滤，这一层主要将粗排后的结果拿过来
            for qq in satisfy_list:
                if qq['score'] > similarity_threshold:  # 这是第二层过滤，这一层主要让qq精排结果大于我们设定的相似度
                    similarity_data.append(qq)
                else:
                    if correlation_threshold <= qq['score'] <= similarity_threshold:
                        correlation_data.append(qq)
                    else:
                        other_data.append(qq)
    # 其次对qa进行精排排序
    if qa_rank_result['code'] == 200 and not similarity_data:
        qa_data = qa_rank_result['origin_data']['satisfy_list']
        if qa_data:  # 从es数据库中检索得到qa数据集
            if correlation_data:  # 不存在相似数据，但存在相关数据，此时需要对qa相关性判别
                for qa in qa_data:
                    if correlation_threshold <= qa['score']:
                        correlation_data.append(qa)
                    else:
                        other_data.append(qa)
    # 格式统一，对最后的结果进行统一输出最后的答案
    if len(similarity_data) > 1:
        _similarity_data = sorted(similarity_data, key=lambda e: e['score'], reverse=True)
        result_dict["similarity"] = [_similarity_data[0]['sentences'][-1]]
        _correlation_data = correlation_data + _similarity_data[1:]
        _correlation_data = sorted(_correlation_data, key=lambda e: e['score'], reverse=True)
        result_dict["correlation"] = [_c['sentences'][-1] for _c in _correlation_data]
    elif len(similarity_data) == 1:
        result_dict["similarity"] = [similarity_data[0]['sentences'][-1]]
        result_dict["correlation"] = [_c['sentences'][-1] for _c in correlation_data]
    else:
        result_dict["similarity"] = []
        result_dict["correlation"] = []
    result_dict["other"] = other_data
    return result_dict


def get_llm_chat_server(_input_question, global_variable, is_instruction=False):
    if is_instruction:
        prompt_content = "请按照我给出的句子进行大模型润色，输出的问题必须跟原句保持一致，我输入的问题为：{0}".format(_input_question)
    else:
        prompt_content = "我输入的问题为：'{}',必须回答跟不动产登记相关的内容，其余内容不要回复，答案必须简短".format(_input_question)
    model_chat_result = get_model_server(global_variable['chat_model_url'], prompt_content)
    if model_chat_result['code'] == 200 and model_chat_result['origin_data']:
        chat_answer = model_chat_result['origin_data']
    else:  # 大模型输出异常，没有返回对应答案
        chat_answer = None
    return chat_answer


def get_stop_word(stopwords_path):
    with open(stopwords_path, 'r', encoding='utf-8') as f:
        stopwords = [line.strip() for line in f.readlines()]
    return stopwords




def read_line_by_jsonl(jsonl_path, encoding="utf-8"):
    data_list = []
    with open(jsonl_path, 'r', encoding=encoding) as f:
        for line in f:
            data = json.loads(line)
            data_list.append(data)
    return data_list
