# myutilpkg

A Python package with math and string utility functions.

Changes to the readme.