"""Python unit tests for NaaVRE_communicator_jupyterlab."""
