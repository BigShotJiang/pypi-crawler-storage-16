"""Pure-Python fallback implementation of the naay parser/dumper."""

from __future__ import annotations

from .parser import dumps as dumps
from .parser import loads as loads
