class PreservedMetadataKeys:
    REGISTER_SOURCE = "preserved.register.source"

    HEART_BEAT_TIMEOUT = "preserved.heart.beat.timeout"

    IP_DELETE_TIMEOUT = "preserved.ip.delete.timeout"

    HEART_BEAT_INTERVAL = "preserved.heart.beat.interval"

    INSTANCE_ID_GENERATOR = "preserved.instance.id.generator"
