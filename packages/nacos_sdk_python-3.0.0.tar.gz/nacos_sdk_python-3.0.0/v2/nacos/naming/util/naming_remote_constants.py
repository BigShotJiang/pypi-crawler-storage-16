class NamingRemoteConstants:
    REGISTER_INSTANCE = "registerInstance"

    BATCH_REGISTER_INSTANCE = "batchRegisterInstance"

    DE_REGISTER_INSTANCE = "deregisterInstance"

    QUERY_SERVICE = "queryService"

    SUBSCRIBE_SERVICE = "subscribeService"

    NOTIFY_SUBSCRIBER = "notifySubscriber"

    LIST_SERVICE = "listService"

    FORWARD_INSTANCE = "forwardInstance"

    FORWARD_HEART_BEAT = "forwardHeartBeat"
