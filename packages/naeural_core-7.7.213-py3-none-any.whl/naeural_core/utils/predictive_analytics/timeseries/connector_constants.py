class ConnectorConstants:
  CSV_CONNECTOR = 'CSV'
  ODBC_CONNECTOR = 'ODBC'
  DF_CONNECTOR = 'DF'
