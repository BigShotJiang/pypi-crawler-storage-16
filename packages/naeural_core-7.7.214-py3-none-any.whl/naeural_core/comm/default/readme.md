
# Communication module

This module is responsible for communication with the whole ecosystem including:
 - receive configuration requests
 - send paylod/results