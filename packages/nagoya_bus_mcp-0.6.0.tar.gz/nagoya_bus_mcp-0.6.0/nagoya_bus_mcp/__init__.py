"""Nagoya Bus MCP server package."""
