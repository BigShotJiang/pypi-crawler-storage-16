"""MCP server components for Nagoya Bus information."""
