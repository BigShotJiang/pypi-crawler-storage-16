"""Namecast - AI-powered brand name oracle."""

__version__ = "0.1.0"
