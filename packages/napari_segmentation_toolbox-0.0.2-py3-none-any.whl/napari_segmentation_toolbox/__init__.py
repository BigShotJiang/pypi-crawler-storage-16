__version__ = "0.0.1"
from .main_widget import LabelToolbox

__all__ = ("LabelToolbox",)
