import napari
import numpy as np
from qtpy.QtWidgets import (
    QComboBox,
    QGroupBox,
    QHBoxLayout,
    QPushButton,
)
from skimage.util import map_array

from napari_segmentation_toolbox.helpers.base_tool_widget import BaseToolWidget


class ColorFeatureWidget(BaseToolWidget):
    """Widget to produce images colored by property."""

    def __init__(
        self, viewer: "napari.viewer.Viewer", layer_type=(napari.layers.Labels)
    ) -> None:
        super().__init__(viewer, layer_type)

        self.property = QComboBox()
        self.update_status.connect(self.set_properties)

        self.run_btn = QPushButton("Run")
        self.run_btn.clicked.connect(self._color_by_feature)

        colorbox = QGroupBox("Color by feature")
        color_layout = QHBoxLayout()

        color_layout.addWidget(self.property)
        color_layout.addWidget(self.run_btn)
        colorbox.setLayout(color_layout)

        main_layout = QHBoxLayout()
        main_layout.addWidget(colorbox)

        self.setLayout(main_layout)

    def set_properties(self) -> None:
        """Retrieve the available properties and populate the dropdown menu"""

        current_prop = self.property.currentText()
        if self.layer is not None:
            props = list(self.layer.properties.keys())
            self.property.clear()
            self.property.addItems(
                [p for p in props if p not in ("label", "time_point")]
            )
            if current_prop in props:
                self.property.setCurrentText(current_prop)
            self.run_btn.setEnabled(True) if len(
                props
            ) > 0 else self.run_btn.setEnabled(False)
        else:
            self.run_btn.setEnabled(False)

    def _color_by_feature(self) -> None:
        """Add a new layer to the viewer that displays the labels colored by the selected
        property"""

        feature = self.property.currentText()
        image = map_array(
            self.layer.data,
            self.layer.properties["label"],
            self.layer.properties[feature],
        ).astype(np.float32)
        self.viewer.add_image(image, colormap="turbo", scale=self.layer.scale)
