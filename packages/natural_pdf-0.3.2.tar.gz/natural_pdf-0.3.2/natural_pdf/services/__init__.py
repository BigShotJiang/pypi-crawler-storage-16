"""Service helpers for the composition-based architecture."""
