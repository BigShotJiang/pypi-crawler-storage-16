"""REST API module for nautobot_capacity_metrics app."""
