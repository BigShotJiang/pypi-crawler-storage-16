"""Unit tests for nautobot_capacity_metrics app."""
