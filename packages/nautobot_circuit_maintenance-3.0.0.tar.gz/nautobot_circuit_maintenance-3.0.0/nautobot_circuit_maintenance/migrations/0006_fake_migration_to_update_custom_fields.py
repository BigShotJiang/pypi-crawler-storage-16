# Generated manually just to trigger post_migration signal that is
# used to create the Custom Fields

from django.db import migrations


class Migration(migrations.Migration):
    dependencies = [
        ("nautobot_circuit_maintenance", "0005_notificationsource__token"),
    ]

    operations = []
