"""REST API module for nautobot_floor_plan app."""
