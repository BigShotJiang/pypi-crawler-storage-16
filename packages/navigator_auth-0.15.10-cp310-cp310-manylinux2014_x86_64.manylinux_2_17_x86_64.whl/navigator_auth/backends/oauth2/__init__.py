from .backend import Oauth2Provider


__all__ = ('Oauth2Provider',)
