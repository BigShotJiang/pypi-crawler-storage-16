"""Navigator SDK - Simple and fast way to share logs."""

from navigator_sdk.setup import setup_logger

__all__ = ["setup_logger"]
