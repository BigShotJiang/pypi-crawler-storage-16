from .in_process_fame_fabric import InProcessFameFabric

__all__ = ["InProcessFameFabric"]
