<div align=center>

<img width="250" height="312" src="https://github.com/zhenxun-org/nb-cli-plugin-zhenxun/blob/main/docs_image/tt.jpg"/>

</div>

<div align="center">

<p>
  <img src="https://raw.githubusercontent.com/lgc-NB2Dev/readme/main/template/plugin.svg" alt="NoneBotPluginText">
</p>

# NB CLI Plugin For Zhenxun

_✨ 为[小真寻](https://github.com/HibiKier/zhenxun_bot)定制的 NoneBot2 CLI 插件 ✨_

![python](https://img.shields.io/badge/python-v3.9%2B-blue)
![nonebot](https://img.shields.io/badge/nonebot-v2.1.3-yellow)
![onebot](https://img.shields.io/badge/onebot-v11-black)
[![license](https://img.shields.io/badge/license-AGPL3.0-FE7D37)](https://github.com/zhenxun-org/zhenxun_bot/blob/main/LICENSE)

</div>

## 📖 介绍

安装 [小真寻](https://github.com/zhenxun-org/zhenxun_bot) 一步到胃！

> [!NOTE]
>
> <div align="center"><b>小真寻也很可爱呀，也会很喜欢你！</b></div>
>
> <div align="center">
> <img width="235" height="235" src="https://github.com/zhenxun-org/nb-cli-plugin-zhenxun/blob/main/docs_image/tt3.png"/>
> <img width="235" height="235" src="https://github.com/zhenxun-org/nb-cli-plugin-zhenxun/blob/main/docs_image/tt1.png"/>
> <img width="235" height="235" src="https://github.com/zhenxun-org/nb-cli-plugin-zhenxun/blob/main/docs_image/tt2.png"/>
> </div>

## 💿 安装


请直接查看 [文档](https://hibikier.github.io/zhenxun_bot/install/zhenxun/nb-install-zhenxun)


## ❤ 感谢

- [小派蒙脚手架](https://github.com/CMHopeSunshine/nb-cli-plugin-littlepaimon) : 项目参考
