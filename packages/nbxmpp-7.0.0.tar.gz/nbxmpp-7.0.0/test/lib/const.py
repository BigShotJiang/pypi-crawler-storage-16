STREAM_START = "<stream:stream xmlns:stream='http://etherx.jabber.org/streams' xmlns='jabber:client'>"
