# nbxmpp-client 2.0.1 (13 Dec 2025)

## Changed

* Set max nbxmpp version

# nbxmpp-client 2.0.0 (29 Jan 2023)

## Changed

* Port to GTK4 and libadwaita

# nbxmpp-client 1.0.0 (04 Jan 2023)

Initial Release
