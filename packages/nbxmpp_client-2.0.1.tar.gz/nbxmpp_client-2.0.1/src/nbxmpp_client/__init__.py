import gi

gi.require_version("Adw", "1")
gi.require_version("Gtk", "4.0")
gi.require_version("GtkSource", "5")
gi.require_version("GLib", "2.0")
gi.require_version("Soup", "3.0")

__version__ = "2.0.1"
