import json
import os
from ..utils.string_utils import to_snake_case
from ..observability.factory import get_logger

def load_json(path):
    with open(path) as f:
        return json.load(f)

def load_env(prefix=""):
    logger = get_logger().get()
    logger.info(f"Prefix Before: {prefix}")
    prefix = to_snake_case(prefix)
    logger.info(f"Prefix After: {prefix}")
    return {f"{k[len(prefix):]}".lower(): v for k, v in os.environ.items() if k.startswith(prefix.upper())}
