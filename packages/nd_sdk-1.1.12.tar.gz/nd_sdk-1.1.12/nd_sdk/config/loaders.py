import json
import os
from ..utils.string_utils import to_snake_case

def load_json(path):
    with open(path) as f:
        return json.load(f)

def load_env(prefix=""):
    print(f"Prefix Before: {prefix}", flush=True)
    print(f"Environ Values: {os.environ.items()}", flush=True)
    prefix = to_snake_case(prefix)
    print(f"Prefix After: {prefix}", flush=True)
    return {f"{k[len(prefix):]}".lower(): v for k, v in os.environ.items() if k.startswith(prefix.upper())}
