Please provide suggestions on Github! 
