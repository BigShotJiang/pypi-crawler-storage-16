import logging

__version__ = "3.2.0"

core_logger = logging.getLogger("neo3.core")
network_logger = logging.getLogger("neo3.network")
