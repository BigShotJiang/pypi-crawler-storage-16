"""
P2P network payloads and related classes.
"""
