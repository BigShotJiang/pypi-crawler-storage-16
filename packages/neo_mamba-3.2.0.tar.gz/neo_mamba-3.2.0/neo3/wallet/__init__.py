"""
Wallet & account base classes. Utilities to validate and convert from/to addresses.
"""
