"""
Core components for handling smart contracts. Contains the Manifest, Neo Executable Format (NEF) and utilities for
 obtaining a contract hash, extracting public keys etc.
"""
