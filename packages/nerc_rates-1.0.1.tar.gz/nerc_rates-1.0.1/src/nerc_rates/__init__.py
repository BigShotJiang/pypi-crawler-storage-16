from nerc_rates.rates import load_from_file, load_from_url  # noqa: F401
