global NETFRANKY_IS_SETUP
NETFRANKY_IS_SETUP = False

from .setup import setup_net_franky