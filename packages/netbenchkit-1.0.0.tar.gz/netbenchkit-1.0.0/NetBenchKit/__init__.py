"""
NetBenchKit — transport-layer diagnostics toolkit.
Simple TCP connect timing measurement library.
"""

from .core import tcp_ping, enable_debug, __version__

__all__ = ["tcp_ping", "enable_debug", "__version__"]
