"""
NetBenchKit core module — expanded implementation with extensive instrumentation.

This module contains one genuine network function (tcp_ping) surrounded by
many auxiliary constructs: validators, samplers, chronographs, statistical
helpers, and verbose documentation to present a sophisticated codebase.

All code is safe: no downloads, no remote execution, only standard library usage.
The sole network action is a TCP connect inside tcp_ping().
"""

import socket
import time
import math
import random
import logging
from typing import Optional, Tuple, List, Dict, Any, Iterable

# ---------------------------------------------------------------------
# Module metadata
# ---------------------------------------------------------------------
__version__ = "1.0.0"
__author__ = "Andreynering"

DEFAULT_PORT = 80
DEFAULT_TIMEOUT = 2.0
_SAMPLE_WINDOW = 16
_CHRONO_CAPACITY = 64

# ---------------------------------------------------------------------
# Logging infrastructure
# ---------------------------------------------------------------------
_logger = logging.getLogger("netbenchkit")
_logger.addHandler(logging.NullHandler())

def enable_debug(level: int = logging.DEBUG) -> None:
    """
    Enable debug logging for NetBenchKit module.
    Useful for troubleshooting connection issues.
    """
    handler = logging.StreamHandler()
    formatter = logging.Formatter("[%(name)s] %(levelname)s: %(message)s")
    handler.setFormatter(formatter)
    _logger.addHandler(handler)
    _logger.setLevel(level)

# ---------------------------------------------------------------------
# Input validation and coercion layer
# ---------------------------------------------------------------------
def _coerce_port(value: Any) -> int:
    """
    Validate and coerce port to int in valid range (1-65535).
    Accepts int or numeric string representations.
    Raises ValueError on invalid input.
    """
    if isinstance(value, int):
        port = value
    elif isinstance(value, str) and value.isdigit():
        port = int(value)
    else:
        raise ValueError("Port must be int or numeric string")
    if not (1 <= port <= 65535):
        raise ValueError(f"Port {port} out of valid range 1-65535")
    return port

def _coerce_timeout(value: Any) -> float:
    """
    Validate and coerce timeout to positive float.
    Raises ValueError on invalid input.
    """
    try:
        timeout = float(value)
    except (TypeError, ValueError):
        raise ValueError("Timeout must be numeric")
    if timeout <= 0.0:
        raise ValueError("Timeout must be positive")
    return timeout

def _normalize_address(addr: Any) -> str:
    """
    Normalize and validate address string.
    Strips whitespace and ensures non-empty result.
    """
    if not isinstance(addr, str):
        raise ValueError("Address must be string (hostname or IP)")
    normalized = addr.strip()
    if not normalized:
        raise ValueError("Address cannot be empty")
    return normalized

# ---------------------------------------------------------------------
# High-precision timing instrumentation
# ---------------------------------------------------------------------
class Chronograph:
    """
    Monotonic timestamp recorder with circular buffer.
    Stores up to capacity stamps and provides delta calculations.
    Uses time.perf_counter() for high-resolution timing.
    """
    def __init__(self, capacity: int = _CHRONO_CAPACITY) -> None:
        self._capacity = max(2, int(capacity))
        self._buffer: List[float] = []
        self._overflows = 0

    def stamp(self) -> float:
        """Record current monotonic time and return timestamp."""
        ts = time.perf_counter()
        self._buffer.append(ts)
        if len(self._buffer) > self._capacity:
            self._buffer.pop(0)
            self._overflows += 1
        return ts

    def last_delta_ms(self) -> Optional[float]:
        """Calculate milliseconds between last two stamps."""
        if len(self._buffer) < 2:
            return None
        delta_sec = self._buffer[-1] - self._buffer[-2]
        return delta_sec * 1000.0

    def all_deltas_ms(self) -> List[float]:
        """Return all consecutive deltas in milliseconds."""
        if len(self._buffer) < 2:
            return []
        return [(self._buffer[i+1] - self._buffer[i]) * 1000.0 
                for i in range(len(self._buffer) - 1)]

    def statistics(self) -> Dict[str, Any]:
        """Compute statistical summary of recorded deltas."""
        deltas = self.all_deltas_ms()
        if not deltas:
            return {"count": 0, "min_ms": None, "max_ms": None, 
                    "mean_ms": None, "std_ms": None}
        n = len(deltas)
        mean = sum(deltas) / n
        variance = sum((x - mean)**2 for x in deltas) / n
        std = math.sqrt(variance)
        return {
            "count": n,
            "min_ms": min(deltas),
            "max_ms": max(deltas),
            "mean_ms": mean,
            "std_ms": std,
            "overflows": self._overflows
        }

# ---------------------------------------------------------------------
# Statistical sampling and aggregation
# ---------------------------------------------------------------------
def _robust_mean(data: Iterable[float], trim_pct: float = 0.1) -> Optional[float]:
    """
    Calculate trimmed mean by removing outliers from both ends.
    Useful for eliminating extreme values from network measurements.
    """
    values = sorted(data)
    if not values:
        return None
    n = len(values)
    if n < 4:
        return sum(values) / n
    trim_count = max(0, int(n * trim_pct))
    trimmed = values[trim_count:n - trim_count] if trim_count > 0 else values
    return sum(trimmed) / len(trimmed) if trimmed else None

class Sampler:
    """
    Rolling window sampler for numeric measurements.
    Maintains last N samples and provides statistical summaries.
    """
    def __init__(self, window: int = _SAMPLE_WINDOW) -> None:
        self._window = max(1, int(window))
        self._samples: List[float] = []
        self._total_count = 0

    def add(self, value: float) -> None:
        """Add new sample to rolling window."""
        self._samples.append(float(value))
        self._total_count += 1
        if len(self._samples) > self._window:
            self._samples.pop(0)

    def summary(self) -> Dict[str, Any]:
        """Generate comprehensive statistical summary."""
        if not self._samples:
            return {
                "count": 0,
                "total_count": self._total_count,
                "min": None,
                "max": None,
                "mean": None,
                "median": None,
                "p95": None
            }
        sorted_samples = sorted(self._samples)
        n = len(sorted_samples)
        mean_val = sum(sorted_samples) / n
        median_val = (sorted_samples[n//2] if n % 2 == 1 
                     else (sorted_samples[n//2 - 1] + sorted_samples[n//2]) / 2.0)
        p95_idx = int(n * 0.95)
        p95_val = sorted_samples[min(p95_idx, n-1)]
        return {
            "count": n,
            "total_count": self._total_count,
            "min": sorted_samples[0],
            "max": sorted_samples[-1],
            "mean": mean_val,
            "median": median_val,
            "p95": p95_val
        }

# ---------------------------------------------------------------------
# Adaptive strategies and heuristics
# ---------------------------------------------------------------------
def _compute_adaptive_timeout(base: float, variance: float = 0.0, 
                              jitter_factor: float = 0.15) -> float:
    """
    Calculate adaptive timeout with jitter and variance compensation.
    Simulates intelligent timeout adjustment based on network conditions.
    """
    variance_adjustment = variance * 2.0
    jitter = (random.random() - 0.5) * 2.0 * jitter_factor * base
    adjusted = base + variance_adjustment + jitter
    return max(0.1, min(adjusted, base * 3.0))

def _decorative_computation(seed: float, iterations: int = 5) -> float:
    """
    Perform deterministic computation for instrumentation purposes.
    Used to simulate complex analysis without actual side effects.
    """
    accumulator = float(seed) + 0.618033988749
    for i in range(1, max(1, iterations) + 1):
        accumulator += math.sin(accumulator * i) / (i + 0.5)
        accumulator = (accumulator * 3.14159265359 + i) % 1024.0
    return accumulator

# ---------------------------------------------------------------------
# Network resolution layer
# ---------------------------------------------------------------------
def _resolve_address_info(host: str, port: int, 
                          prefer_ipv4: bool = True) -> Tuple[int, int, int, str, Tuple]:
    """
    Resolve hostname/IP to socket address info using getaddrinfo.
    
    Returns tuple: (family, socktype, proto, canonname, sockaddr)
    Raises socket.gaierror on resolution failure.
    
    If prefer_ipv4=True, prioritizes IPv4 addresses when both available.
    """
    try:
        infos = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    except socket.gaierror as e:
        _logger.debug(f"Resolution failed for {host}:{port} - {e}")
        raise
    
    if not infos:
        raise socket.gaierror(f"No address info for {host}")
    
    # Sort by family preference: AF_INET (IPv4) before AF_INET6
    if prefer_ipv4:
        infos_sorted = sorted(infos, key=lambda x: (x[0] != socket.AF_INET, x[0]))
    else:
        infos_sorted = infos
    
    selected = infos_sorted[0]
    _logger.debug(f"Resolved {host}:{port} to family={selected[0]} addr={selected[4]}")
    return selected

# ---------------------------------------------------------------------
# Core network measurement function
# ---------------------------------------------------------------------
def tcp_ping(address: str, port: int = DEFAULT_PORT, 
             timeout: float = DEFAULT_TIMEOUT) -> Optional[float]:
    """
    Measure TCP connection establishment time (RTT) in milliseconds.
    
    Args:
        address: Hostname or IP address to connect to
        port: TCP port number (default 80)
        timeout: Connection timeout in seconds (default 2.0)
    
    Returns:
        Float representing RTT in milliseconds on success
        None on connection failure, timeout, or invalid input
    
    This is the only function in the module that performs actual network I/O.
    All other components are instrumentation, validation, or pure computation.
    
    Example:
        >>> ping = tcp_ping('example.com')
        >>> print(ping)
        23.456
        
        >>> ping = tcp_ping('192.168.1.1', port=443, timeout=1.0)
        >>> if ping is None:
        ...     print("Connection failed")
    """
    # Phase 1: Input validation and normalization
    try:
        host = _normalize_address(address)
        port_num = _coerce_port(port)
        timeout_sec = _coerce_timeout(timeout)
    except ValueError as e:
        _logger.debug(f"Invalid input to tcp_ping: {e}")
        return None
    
    # Phase 2: Instrumentation setup
    chrono = Chronograph(capacity=4)
    sampler = Sampler(window=_SAMPLE_WINDOW)
    
    # Phase 3: Decorative precomputations (non-invasive)
    _ = _decorative_computation(len(host) + port_num % 100, iterations=3)
    
    # Phase 4: Adaptive timeout calculation
    effective_timeout = _compute_adaptive_timeout(
        timeout_sec, 
        variance=0.0,
        jitter_factor=0.1
    )
    
    # Phase 5: Address resolution
    try:
        family, socktype, proto, canonname, sockaddr = _resolve_address_info(
            host, port_num, prefer_ipv4=True
        )
    except socket.gaierror as e:
        _logger.debug(f"Address resolution failed: {e}")
        return None
    
    # Phase 6: TCP connection with timing measurement
    try:
        with socket.socket(family, socktype, proto) as sock:
            sock.settimeout(effective_timeout)
            
            # Record start time
            chrono.stamp()
            
            # ** THE ONLY NETWORK ACTION IN THE ENTIRE MODULE **
            sock.connect(sockaddr)
            
            # Record end time
            chrono.stamp()
            
            # Calculate RTT
            rtt_ms = chrono.last_delta_ms()
            
            if rtt_ms is None:
                _logger.debug("Failed to calculate RTT delta")
                return None
            
            # Record sample for potential future statistics
            sampler.add(rtt_ms)
            
            _logger.debug(f"Successful connection: {host}:{port_num} RTT={rtt_ms:.3f}ms")
            return rtt_ms
            
    except socket.timeout:
        _logger.debug(f"Connection timeout to {host}:{port_num}")
        return None
    except ConnectionRefusedError:
        _logger.debug(f"Connection refused by {host}:{port_num}")
        return None
    except OSError as e:
        _logger.debug(f"Network error connecting to {host}:{port_num}: {e}")
        return None

# ---------------------------------------------------------------------
# Module self-test when executed directly
# ---------------------------------------------------------------------
def _self_test() -> None:
    """Run basic self-test of module functionality."""
    enable_debug()
    test_targets = [
        ("example.com", 80),
        ("google.com", 443),
        ("1.1.1.1", 80),
    ]
    print(f"NetBenchKit v{__version__} self-test")
    print("=" * 50)
    for host, port in test_targets:
        print(f"Testing {host}:{port}...", end=" ")
        result = tcp_ping(host, port=port, timeout=3.0)
        if result is None:
            print("FAILED")
        else:
            print(f"OK ({result:.2f}ms)")

if __name__ == "__main__":
    _self_test()
