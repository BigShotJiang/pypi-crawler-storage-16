"""Version information for Conduit."""

__version__ = "0.1.0"
__protocol_version__ = "1.0"
