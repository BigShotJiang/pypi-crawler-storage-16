"""
Async task creation example demonstrating non-blocking instance provisioning.

This example shows how to use the new async methods for fast task creation:
- create_with_instance_async() returns immediately (~1-2 seconds)
- Instance provisioning continues in the background
- Poll for readiness or use wait_for_ready()

Benefits of async creation:
- Instant response for better UX
- Webhook handlers respond quickly
- Background provisioning doesn't block your application
"""

from netint_agents_sdk import NetIntClient, NetIntConfig


def main():
    # Create client
    config = NetIntConfig(
        base_url="https://agents.netint.ca",
        api_token="svc_OfsRTAMilHMuZFfpi0Fw2Nb8n5c5K53qlBmh3KvDs30USuXW",
        timeout=60,  # Short timeout - async creation is fast!
        debug=True
    )
    client = NetIntClient(config)

    try:
        # ============================================
        # ASYNC TASK CREATION (Non-blocking)
        # ============================================
        print("=== Creating Task with Instance (ASYNC - Non-blocking) ===")
        print("This returns immediately, instance provisioning happens in background...")
        print()

        import time
        start = time.time()

        # This returns in ~1-2 seconds instead of 2-5 minutes!
        task = client.tasks.create_with_instance_async(
            title="[NETINTGPT Agents] Testing",
            prompt="please provide the potential bugs in this project",
            environment_id=216,
            ask_mode=False,
        )

        elapsed = time.time() - start
        print(f"Task created in {elapsed:.2f} seconds!")
        print(f"   Task ID: {task.id}")
        print(f"   Instance ID: {task.instance_id}")
        print(f"   Instance URL: {task.instance_url}")
        print(f"   Status: {task.status}")
        print()

        # ============================================
        # OPTION 1: Poll for provisioning status manually
        # ============================================
        print("=== Polling for Instance Readiness ===")

        status = client.instances.get_provisioning_status(task.instance_id)
        print(f"Current status: {status.provisioning_status}")
        print(f"Message: {status.message}")
        print()

        # ============================================
        # OPTION 2: Wait for instance to be ready (blocking)
        # ============================================
        print("=== Waiting for Instance to be Ready ===")
        print("(This will poll every 5 seconds until ready or timeout)")
        print()

        def on_progress(status):
            print(f"  Provisioning: {status.provisioning_status} - {status.message}")

        try:
            ready = client.instances.wait_for_ready(
                task.instance_id,
                poll_interval=5,
                timeout=300,  # 5 minute timeout
                callback=on_progress
            )
            print()
            print(f"Instance is READY!")
            print(f"   URL: {ready.instance_url}")
            print(f"   Port: {ready.external_port}")

        except TimeoutError as e:
            print(f"Timeout waiting for instance: {e}")
        except Exception as e:
            print(f"Error: {e}")

        # ============================================
        # ALTERNATIVE: Use wait_for_instance_ready on task
        # ============================================
        # task = client.tasks.wait_for_instance_ready(task.id, timeout=300)
        # print(f"Instance ready at {task.instance_url}")

    finally:
        client.close()


def comparison_example():
    """
    Shows the difference between sync and async creation.
    """
    config = NetIntConfig(
        base_url="https://agents.netint.ca",
        api_token="your-token-here",
        timeout=600,
        debug=False
    )
    client = NetIntClient(config)

    import time

    # SYNC VERSION (old way) - blocks for 2-5 minutes
    # print("Creating task (SYNC - blocking)...")
    # start = time.time()
    # task = client.tasks.create_with_instance(...)  # Blocks until instance ready
    # print(f"Took {time.time() - start:.1f} seconds")

    # ASYNC VERSION (new way) - returns in 1-2 seconds
    print("Creating task (ASYNC - non-blocking)...")
    start = time.time()
    task = client.tasks.create_with_instance_async(
        title="Test",
        prompt="Test prompt",
        environment_id=140,
    )
    print(f"Returned in {time.time() - start:.1f} seconds")
    print(f"Instance {task.instance_id} provisioning in background...")

    # Optional: wait for it to be ready
    client.tasks.wait_for_instance_ready(task.id, timeout=300)
    print(f"Instance ready at {task.instance_url}")

    client.close()


if __name__ == "__main__":
    main()
