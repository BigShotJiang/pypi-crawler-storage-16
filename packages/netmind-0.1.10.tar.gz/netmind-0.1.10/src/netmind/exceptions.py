
class NetMindError(Exception):
    pass