from openai.resources import Chat as OpenChat, AsyncChat as AsyncOpenChat


class Chat(OpenChat):
    pass


class AsyncChat(AsyncOpenChat):
    pass
