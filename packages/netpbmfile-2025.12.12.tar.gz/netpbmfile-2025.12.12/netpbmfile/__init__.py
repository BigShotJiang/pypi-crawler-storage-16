# netpbmfile/__init__.py

from .netpbmfile import *
from .netpbmfile import __all__, __doc__, __version__

# constants are repeated for documentation

__version__ = __version__
"""Netpbmfile version string."""
