# Support & Community

If you need help, Join our Discord server: https://discord.com/invite/utv9qWsnRY
or e-mail us on: support@netpicker.io

# Nautobot Automation & Config Backup Plugin

[Nautobot](https://github.com/nautobot/nautobot) plugin to automatically Automate & Backup your Network with [Netpicker](https://netpicker.io).

## Compatibility

| Nautobot Version | Plugin Version |
|------------------|----------------|
|   Nautobot 3.x   |    >= 0.0.1    |

## Features

- **Netpicker Configuration View**: Integrated interface for managing Netpicker configurations within Nautobot
- **Device Synchronization**: Sync NetPicker devices into Nautobot with automatic mapping
- **Configuration Backups**: Browse and search device configuration backups
- **Simple Automation**: Streamlined automation workflows for network operations
- **Automation Jobs**: Create and manage automation jobs with platform-specific execution
- **Job Logs**: Detailed logging and execution history for automation jobs

## Installation

### Option 1: PyPI Installation

The plugin is available as a Python package on PyPI and can be installed with pip:

```bash
# Activate your Nautobot virtual environment
source /opt/nautobot/venv/bin/activate

# Install the plugin
pip install --no-cache-dir netpicker-nautobot-plugin
```

### Option 2: Development Installation

For development or custom modifications:

```bash
# Clone the repository
git clone https://gitlab.com/netyce/netpicker-nautobot-plugin.git
cd netpicker-nautobot-plugin

# Install dependencies
poetry install

# Install in development mode
poetry run pip install -e .
```

## Configuration

### 1. Add to Nautobot Configuration

Add the plugin to your `nautobot_config.py` or environment variables:

```python
PLUGINS = [
    'netpicker',
]
```

### 2. Run Database Migrations

```bash
nautobot-server migrate
```

### 3. Create Super User (if needed)

```bash
nautobot-server createsuperuser
```

### 4. Configure Plugin Settings

Navigate to **Plugins → NetPicker → Settings** in the Nautobot UI to configure:

- **Server URL**: Your NetPicker server URL (default: `https://sandbox.netpicker.io`)
- **API Key**: Your NetPicker API key
- **Tenant**: Your NetPicker tenant name (default: `default`)

### 5. Restart Nautobot

Restart your Nautobot service to load the plugin:

```bash
# If using systemd
sudo systemctl restart nautobot

# If using Docker
docker compose restart nautobot
```

## Docker Deployment

The project includes Docker support for easy deployment:

```bash
# Start all services
docker compose up -d --build

# View logs
docker compose logs -f nautobot

# Stop services
docker compose down
```

The Docker setup includes:
- Nautobot application
- Celery worker for background tasks
- Celery beat for scheduled tasks
- PostgreSQL database
- Redis for caching and sessions

## Usage

Once installed and configured, the Netpicker plugin will be available in your Nautobot interface:

1. Navigate to the Netpicker section in the Nautobot navigation
2. Access configuration views and automation tools
3. View device backups directly from device detail pages
4. Use the API endpoints for programmatic access

## API Endpoints

The plugin provides REST API endpoints accessible at `/api/plugins/netpicker/`.

## Development

For development information, see [DEVELOPMENT.md](DEVELOPMENT.md).

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a merge request

## Support

For issues and questions:
- Create an issue in the repository: https://gitlab.com/netyce/netpicker-nautobot-plugin/-/issues
- Join our Discord server: https://discord.com/invite/utv9qWsnRY
- Send an email to support@netpicker.io
