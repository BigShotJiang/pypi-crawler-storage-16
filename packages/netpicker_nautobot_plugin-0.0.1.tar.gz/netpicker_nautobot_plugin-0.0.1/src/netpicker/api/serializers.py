from nautobot.core.api import NautobotModelSerializer

from netpicker.models import NetpickerSetting


__all__ = 'NetpickerSettingSerializer',


class NetpickerSettingSerializer(NautobotModelSerializer):
    class Meta:
        model = NetpickerSetting
        fields = ('id', 'server_url', 'api_key', 'tenant')
