from nautobot.core.api.routers import OrderedDefaultRouter

router = OrderedDefaultRouter()
app_name = 'netpicker'
urlpatterns = router.urls
