"""
URL patterns to be injected into Nautobot's dcim URLs.
This allows URLs to be accessible directly under /dcim/devices/ without the plugin prefix.
"""
from django.urls import path
from netpicker import views

# This will be injected into nautobot.dcim.urls
urlpatterns = [
    path('devices/<uuid:pk>/netpicker/backups/', views.DeviceBackupsView.as_view(), name='device_backups'),
    path('devices/<uuid:pk>/netpicker/history/', views.DeviceBackupHistoryView.as_view(), name='device_backup_history'),
]
