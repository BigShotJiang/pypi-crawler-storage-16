import re
from contextlib import suppress

from django import forms
from django.core.exceptions import ValidationError
from django.forms import HiddenInput, TextInput
from django.utils.safestring import SafeText
from django.utils.translation import gettext_lazy as _
from netaddr import AddrFormatError
from netaddr.ip import IPNetwork

from nautobot.dcim.models import Device, Module
from nautobot.extras.forms import NautobotModelForm
from nautobot.core.forms.widgets import StaticSelect2Multiple
from netpicker import models
from netpicker import client
from netpicker.models import MappedDevice
from nautobot.core.forms.fields import DynamicModelChoiceField


re_commands = re.compile(r'(?:[^{]*(\{[a-zA-Z_]\w*})??[^{]*)??',
                         re.MULTILINE | re.DOTALL)


def validate_identifier(value):
    if isinstance(value, str) and value.isidentifier():
        return value
    raise ValidationError(f'{value} is not a valid identifier')


def validate_command(value):
    if not re_commands.fullmatch(value):
        raise ValidationError('Invalid commands specified')


class DeviceComponentForm(NautobotModelForm):
    device = DynamicModelChoiceField(
        label=_('Device'),
        queryset=Device.objects.all(),
        required=False,
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Disable reassignment of Device when editing an existing instance
        if self.instance.pk:
            self.fields['device'].disabled = False


class ModularDeviceComponentForm(DeviceComponentForm):
    module = DynamicModelChoiceField(
        label=_('Module'),
        queryset=Module.objects.all(),
        required=False,
        query_params={
            'device_id': '$device',
        }
    )


class PlatformMultipleChoiceField(forms.MultipleChoiceField):
    def __init__(self, **kwargs):
        domains = client.get_domains()
        platforms = domains['platforms']
        choices = [(platform, platform) for platform in platforms]
        kwargs['choices'] = choices
        if 'widget' not in kwargs:
            kwargs['widget'] = StaticSelect2Multiple(attrs={'data-placeholder': 'Select platforms...'})
        super().__init__(**kwargs)

    @staticmethod
    def get_choices():
        return PlatformMultipleChoiceField(
            label=_('Platforms'),
            required=False,
        )


class SettingsForm(NautobotModelForm):
    server_url = forms.CharField(required=True, label=_('API url'),
                                 help_text=_('Netpicker API base url (root url)'))
    tenant = forms.CharField(required=True, label=_('Tenant'), help_text=_('Name of your Netpicker tenant'))
    api_key = forms.CharField(required=True, label=_('API key'), widget=TextInput(),
                              help_text=SafeText('Key obtained from <a id="np-admin" href="" target="_blank">'
                                                 'Netpicker API admin</a>'))

    class Meta:
        model = models.NetpickerSetting
        fields = ['server_url', 'api_key', 'tenant']


class JobEditForm(NautobotModelForm):
    name = forms.CharField(
        required=True,
        label=_('Name'),
        help_text=_("The job's unique name"),
        validators=[validate_identifier]
    )
    commands = forms.CharField(
        required=True,
        validators=[validate_command],
        widget=forms.Textarea(attrs={
            'rows': 15,
            'cols': 80,
            'placeholder': 'Enter CLI configure commands separated by new-line...',
            'class': 'form-control .monospaced'
        }),
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['platforms'] = PlatformMultipleChoiceField()

        if self.instance and self.instance.commands:
            cmds = '\n'.join(self.instance.commands)
            self.initial['commands'] = cmds

    def clean_commands(self):
        commands = self.cleaned_data['commands']
        cleared = [n.strip() for n in commands.splitlines()]
        return cleared

    def save(self, commit=True):
        client.save_job(self.instance)
        self.instance.pk = self.instance.name
        return self.instance

    class Meta:
        model = models.Job
        fields = 'name', 'platforms', 'commands'


def valid_ip(s):
    with suppress(ValueError, AddrFormatError):
        return IPNetwork(s)


def platform_matches_pattern(platform: str, pattern: str) -> bool:
    """
    Check if a platform matches a pattern.
    - '*' matches all platforms
    - 'cisco*' matches platforms starting with 'cisco' (case-insensitive)
    - Exact matches also work
    """
    if not platform or not pattern:
        return False

    # '*' matches all
    if pattern == '*':
        return True

    # Convert to lowercase for case-insensitive matching
    platform_lower = platform.lower()
    pattern_lower = pattern.lower()

    # If pattern ends with '*', check if platform starts with the prefix
    if pattern_lower.endswith('*'):
        prefix = pattern_lower[:-1]
        return platform_lower.startswith(prefix)

    # Exact match (case-insensitive)
    return platform_lower == pattern_lower


def platform_matches_any_pattern(platform: str, patterns: list[str]) -> bool:
    """Check if a platform matches any of the given patterns."""
    if not patterns:
        return True
    return any(platform_matches_pattern(platform, pattern) for pattern in patterns)


def get_job_exec_form(job: models.Job, fixtures):
    params = {p.name: p for p in job.signature.params if p.name not in set(fixtures)}
    variables = params.keys()

    show_all_devices = job.platforms and '*' in job.platforms

    if job.platforms and not show_all_devices:
        all_mapped_devices = MappedDevice.objects.select_related('nautobot').all()
        filtered_mapped_devices = [
            md for md in all_mapped_devices
            if md.platform and platform_matches_any_pattern(md.platform, job.platforms)
        ]
        mapped_nautobots = {md.nautobot for md in filtered_mapped_devices if md.nautobot}
        qs = Device.objects.filter(pk__in=mapped_nautobots)
    else:
        selectables = MappedDevice.objects.values('nautobot')
        mapped_nautobots = set(selectables.values_list('nautobot', flat=True))
        qs = Device.objects.filter(pk__in=mapped_nautobots)

    all_netpicker_devices = client.get_netpicker_devices()
    mapped_ips = set(
        MappedDevice.objects.filter(
            nautobot__isnull=False
        ).values_list('ipaddress', flat=True)
    )
    choices = []
    for device in qs:
        choices.append((f"device:{device.pk}", f"{device.name}"))

    for ip, platform, tenant, name in all_netpicker_devices:
        if ip not in mapped_ips:
            if job.platforms and not show_all_devices:
                if not platform or not platform_matches_any_pattern(platform, job.platforms):
                    continue
            display_name = name if name else ip
            choices.append((f"ip:{ip}", f"{display_name}"))

    dev_field = forms.MultipleChoiceField(
        choices=choices,
        widget=StaticSelect2Multiple(attrs={'data-placeholder': 'Select devices...'}),
        help_text=('All devices known to Netpicker by IP address. '
                   'Nautobot devices are filtered by platform(s) specified by the job. '
                   'All NetPicker devices are included regardless of platform.')
    )
    devices = dict(devices=dev_field)
    vars = {v: forms.CharField(
        label=v,
        required=params[v].has_default is False,
        widget=forms.TextInput(attrs={'class': 'form-control'})
    ) for v in variables}
    meta = dict(Meta=type('Meta', tuple(), dict(model=models.Job, fields=variables)))
    misc = dict(confirm=forms.BooleanField(required=False, widget=HiddenInput()))
    attrs = devices | vars | misc | meta | dict(field_order=['devices', *variables])
    cls = type(forms.ModelForm)(f"Job_{job.signature}", (forms.ModelForm,), attrs)
    return cls
