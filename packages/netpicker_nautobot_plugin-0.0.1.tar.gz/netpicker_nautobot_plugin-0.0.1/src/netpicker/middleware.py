"""
Middleware to handle custom URL routing for device backups and history.
This allows the URLs /dcim/devices/<uuid>/netpicker/backups/ and
/dcim/devices/<uuid>/netpicker/history/ to work without plugin prefix.
"""
import re
from django.http import Http404
from django.urls import resolve, Resolver404
from netpicker.views.backup import DeviceBackupsView, DeviceBackupHistoryView


class DeviceBackupsURLMiddleware:
    """
    Middleware that intercepts requests to /dcim/devices/<uuid>/netpicker/backups/
    and /dcim/devices/<uuid>/netpicker/history/ and routes them to our views.
    """
    def __init__(self, get_response):
        self.get_response = get_response
        # Pattern to match: /dcim/devices/<uuid>/netpicker/backups/
        uuid_pattern = r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}'
        self.backups_pattern = re.compile(
            f'^/dcim/devices/({uuid_pattern})/netpicker/backups/?$'
        )
        # Pattern to match: /dcim/devices/<uuid>/netpicker/history/
        self.history_pattern = re.compile(
            f'^/dcim/devices/({uuid_pattern})/netpicker/history/?$'
        )

    def __call__(self, request):
        # Check if this is our custom URL pattern
        path = request.path

        # Check for backups URL
        match = self.backups_pattern.match(path)
        if match:
            # Extract the device UUID
            device_uuid = match.group(1)

            # Try to resolve the URL normally first (in case injection worked)
            try:
                resolve(path)
                # If it resolves, let Django handle it normally
                return self.get_response(request)
            except (Resolver404, Http404):
                # If it doesn't resolve, handle it ourselves
                view = DeviceBackupsView.as_view()
                return view(request, pk=device_uuid)

        # Check for history URL
        match = self.history_pattern.match(path)
        if match:
            # Extract the device UUID
            device_uuid = match.group(1)

            # Try to resolve the URL normally first (in case injection worked)
            try:
                resolve(path)
                # If it resolves, let Django handle it normally
                return self.get_response(request)
            except (Resolver404, Http404):
                # If it doesn't resolve, handle it ourselves
                view = DeviceBackupHistoryView.as_view()
                return view(request, pk=device_uuid)

        # For all other requests, proceed normally
        return self.get_response(request)
