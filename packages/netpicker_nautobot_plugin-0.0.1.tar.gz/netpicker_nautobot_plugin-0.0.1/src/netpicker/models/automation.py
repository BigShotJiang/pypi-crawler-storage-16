import uuid
from django.contrib.postgres.fields import ArrayField
from django.db import models
from django.db.models import BigIntegerField, BooleanField, CharField, DateTimeField, Field, ForeignKey, Model, \
    SET_NULL, TextField
from django.urls import reverse
from django.utils.translation import gettext_lazy as _

from nautobot.dcim.models import Device
from netpicker.models.base import NetpickerModel, ProxyQuerySet
from nautobot.core.models.querysets import RestrictedQuerySet


class Log(NetpickerModel):
    id = CharField(primary_key=True)
    name = TextField()
    job_name = TextField()
    ipaddress = TextField()
    variables = TextField()
    status = TextField()
    created = DateTimeField()
    exec_at = DateTimeField()
    exec_ns = BigIntegerField()
    initiator = TextField()
    return_value = TextField()
    log = TextField()

    objects = ProxyQuerySet.as_manager()

    class Meta:
        verbose_name = _('log')
        verbose_name_plural = _('logs')
        managed = False

    def get_absolute_url(self):
        return reverse(f'plugins:{self._meta.app_label}:log_detail', args=[self.pk])

    def get_relationships(self):
        """Return empty relationships dict to satisfy Nautobot form requirements."""
        return {}

    @classmethod
    def required_related_objects_errors(cls, data=None, output_for=None, initial_data=None, instance=None):
        """Return empty dict to satisfy Nautobot form requirements."""
        return {}

    @property
    def present_in_database(self):
        """Return True if this object exists in the database."""
        return bool(self.pk)


class Job(NetpickerModel):
    id = TextField(primary_key=True)
    name = TextField()
    author = TextField()
    platforms = ArrayField(TextField())
    tags = ArrayField(TextField())
    is_simple = BooleanField()
    commands = ArrayField(TextField())
    signature = Field()

    objects = ProxyQuerySet.as_manager()

    class Meta:
        verbose_name = _('job')
        verbose_name_plural = _('jobs')
        managed = False

    def get_absolute_url(self):
        return reverse(f'plugins:{self._meta.app_label}:job_detail', args=[self.name])

    def __str__(self):
        return f"Job: {self.name}"

    def get_relationships(self):
        """Return empty relationships dict to satisfy Nautobot form requirements."""
        return {}

    @classmethod
    def required_related_objects_errors(cls, data=None, output_for=None, initial_data=None, instance=None):
        """Return empty dict to satisfy Nautobot form requirements."""
        return {}

    @property
    def present_in_database(self):
        """Return True if this object exists in the database."""
        return bool(self.pk)

    def validate_unique(self, exclude=None):
        """Override to skip unique validation for proxy models."""
        pass

    def delete(self, *args, **kwargs):
        from netpicker.client import delete_job
        delete_job(self)


class NetpickerDeviceBase(Model):
    ipaddress = CharField()
    tenant = CharField()
    platform = CharField()
    name = CharField(null=True)

    class Meta:
        abstract = True


class MappedDevice(NetpickerDeviceBase):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    ipaddress = CharField()
    tenant = CharField()
    platform = CharField()
    nautobot = ForeignKey(Device, on_delete=SET_NULL, related_name='netpickers', null=True)

    objects = RestrictedQuerySet.as_manager()

    class Meta:
        unique_together = ('ipaddress', 'tenant')
        verbose_name = _('Netpicker device')
        verbose_name_plural = _('Netpicker devices')


class NetpickerDevice(NetpickerDeviceBase):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    objects = RestrictedQuerySet.as_manager()

    class Meta:
        verbose_name = _('Netpicker device')
        verbose_name_plural = _('Netpicker devices')
