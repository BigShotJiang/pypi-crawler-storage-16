from nautobot.core.apps import NavMenuItem, NavMenuTab, NavMenuGroup

menu_items = (
    NavMenuTab(
        name='Netpicker',
        groups=(
            NavMenuGroup(
                name='Netpicker',
                items=(
                    NavMenuItem(
                        link='plugins:netpicker:mappeddevice_list',
                        name='Devices',
                        permissions=["netpicker.view_mappeddevice"],
                    ),
                    NavMenuItem(
                        link='plugins:netpicker:backupsearchhit_list',
                        name='Config search',
                        permissions=["netpicker.view_backupsearchhit"],
                    ),
                    NavMenuItem(
                        link='plugins:netpicker:job_list',
                        name='Automation Jobs',
                        permissions=["netpicker.view_job"],
                    ),
                    NavMenuItem(
                        link='plugins:netpicker:log_list',
                        name='Automation Logs',
                        permissions=["netpicker.view_log"],
                    ),
                    NavMenuItem(
                        link='plugins:netpicker:settings',
                        name='Settings',
                        permissions=["netpicker.view_netpickersetting"],
                    ),
                )
            ),
        ),
        # icon_class='mdi mdi-bird',
    ),
)
