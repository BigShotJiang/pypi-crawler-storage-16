from nautobot.apps.ui import DistinctViewTab, TemplateExtension
from nautobot.core.ui.object_detail import get_obj_from_context
from netpicker.views.backup import get_label


def has_mapped_device(device):
    """Check if device has a matching MappedDevice.

    Returns True only if:
    1. There's a MappedDevice linked via ForeignKey (nautobot field), OR
    2. There's a MappedDevice with an exact name match AND the MappedDevice has a valid IP address
    """
    try:
        from netpicker.models import MappedDevice
        # First check if there's a MappedDevice linked via ForeignKey
        if MappedDevice.objects.filter(nautobot=device).exists():
            return True
        # Fallback: check if there's a MappedDevice with matching name that has an IP
        # Only match if name matches exactly and the mapped device has an IP address
        mapped_devices = MappedDevice.objects.filter(
            name=device.name
        ).exclude(ipaddress__isnull=True).exclude(ipaddress='')
        return mapped_devices.exists()
    except Exception:
        return False


class DeviceBackupsTab(DistinctViewTab):
    """Custom tab that generates the URL path directly."""
    def __init__(self):
        # Provide a dummy url_name since it's required, but we'll override URL generation
        super().__init__(
            weight=100,
            tab_id="netpicker_device_backups",
            label=get_label('Backups'),
            url_name="plugins:netpicker:device_detail_backups",  # Dummy, will be overridden
        )

    def get_extra_context(self, context):
        """Override to generate the URL directly, and check if device has matching MappedDevice."""
        try:
            obj = get_obj_from_context(context)
            if obj:
                # Check if device has a matching MappedDevice by name
                if not has_mapped_device(obj):
                    # Return a special URL that will be hidden via CSS
                    return {
                        "url": "#no-match-backups-tab",
                        "hide_tab": True,
                    }
                # Generate URL directly: /dcim/devices/<uuid>/netpicker/backups/
                return {"url": f"/dcim/devices/{obj.pk}/netpicker/backups/"}
        except Exception:
            pass
        # Fallback to plugin URL if something goes wrong
        try:
            from django.urls import reverse
            obj = get_obj_from_context(context)
            if obj:
                if not has_mapped_device(obj):
                    return {
                        "url": "#no-match-backups-tab",
                        "hide_tab": True,
                    }
                return {"url": reverse("plugins:netpicker:device_detail_backups", kwargs={"pk": obj.pk})}
        except Exception:
            pass
        return {}


class DeviceBackupHistoryTab(DistinctViewTab):
    """Custom tab for backup history that generates the URL path directly."""
    def __init__(self):
        super().__init__(
            weight=200,
            tab_id="netpicker_device_backup_history",
            label=get_label('Change history'),
            url_name="plugins:netpicker:device_backup_history",  # Dummy, will be overridden
        )

    def get_extra_context(self, context):
        """Override to generate the URL directly, and check if device has matching MappedDevice."""
        try:
            obj = get_obj_from_context(context)
            if obj:
                # Check if device has a matching MappedDevice by name
                if not has_mapped_device(obj):
                    # Return a special URL that will be hidden via CSS
                    return {
                        "url": "#no-match-backup-history-tab",
                        "hide_tab": True,
                    }
                # Generate URL directly: /dcim/devices/<uuid>/netpicker/history/
                return {"url": f"/dcim/devices/{obj.pk}/netpicker/history/"}
        except Exception:
            pass
        # Fallback to plugin URL if something goes wrong
        try:
            from django.urls import reverse
            obj = get_obj_from_context(context)
            if obj:
                if not has_mapped_device(obj):
                    return {
                        "url": "#no-match-backup-history-tab",
                        "hide_tab": True,
                    }
                return {"url": reverse("plugins:netpicker:device_backup_history", kwargs={"pk": obj.pk})}
        except Exception:
            pass
        return {}


class DeviceContent(TemplateExtension):
    model = "dcim.device"

    object_detail_tabs = [DeviceBackupsTab(), DeviceBackupHistoryTab()]

    def left_page(self):
        """Hide the backups and history tabs if device has no matching MappedDevice using CSS."""
        return '''
        <style>
        /* Hide backups tab when it has href="#no-match-backups-tab" (no matching device) */
        a[href="#no-match-backups-tab"],
        a[href*="#no-match-backups-tab"],
        a[href$="#no-match-backups-tab"],
        a[data-tab-id="netpicker_device_backups"][href="#no-match-backups-tab"],
        a[data-tab-id="netpicker_device_backups"][href*="#no-match-backups-tab"] {
            display: none !important;
            visibility: hidden !important;
        }
        li:has(a[href="#no-match-backups-tab"]),
        li:has(a[href*="#no-match-backups-tab"]),
        li:has(a[href$="#no-match-backups-tab"]),
        li:has(a[data-tab-id="netpicker_device_backups"][href="#no-match-backups-tab"]),
        li:has(a[data-tab-id="netpicker_device_backups"][href*="#no-match-backups-tab"]) {
            display: none !important;
            visibility: hidden !important;
        }
        /* Hide backup history tab when it has href="#no-match-backup-history-tab" (no matching device) */
        a[href="#no-match-backup-history-tab"],
        a[href*="#no-match-backup-history-tab"],
        a[href$="#no-match-backup-history-tab"],
        a[data-tab-id="netpicker_device_backup_history"][href="#no-match-backup-history-tab"],
        a[data-tab-id="netpicker_device_backup_history"][href*="#no-match-backup-history-tab"] {
            display: none !important;
            visibility: hidden !important;
        }
        li:has(a[href="#no-match-backup-history-tab"]),
        li:has(a[href*="#no-match-backup-history-tab"]),
        li:has(a[href$="#no-match-backup-history-tab"]),
        li:has(a[data-tab-id="netpicker_device_backup_history"][href="#no-match-backup-history-tab"]),
        li:has(a[data-tab-id="netpicker_device_backup_history"][href*="#no-match-backup-history-tab"]) {
            display: none !important;
            visibility: hidden !important;
        }
        /* Additional selectors for tab navigation */
        .nav-tabs a[href="#no-match-backups-tab"],
        .nav-tabs a[href*="#no-match-backups-tab"],
        .nav-tabs a[href="#no-match-backup-history-tab"],
        .nav-tabs a[href*="#no-match-backup-history-tab"],
        .nav-tabs li:has(a[href="#no-match-backups-tab"]),
        .nav-tabs li:has(a[href*="#no-match-backups-tab"]),
        .nav-tabs li:has(a[href="#no-match-backup-history-tab"]),
        .nav-tabs li:has(a[href*="#no-match-backup-history-tab"]) {
            display: none !important;
            visibility: hidden !important;
        }
        </style>
        <script>
        // Additional JavaScript fallback to hide tabs if CSS doesn't work
        (function() {
            function hideTabs() {
                // Hide backups tab
                document.querySelectorAll(
                    'a[href="#no-match-backups-tab"], a[href*="#no-match-backups-tab"]'
                ).forEach(function(el) {
                    el.style.display = 'none';
                    el.style.visibility = 'hidden';
                    var li = el.closest('li');
                    if (li) {
                        li.style.display = 'none';
                        li.style.visibility = 'hidden';
                    }
                });
                // Hide backup history tab
                document.querySelectorAll(
                    'a[href="#no-match-backup-history-tab"], '
                    'a[href*="#no-match-backup-history-tab"]'
                ).forEach(function(el) {
                    el.style.display = 'none';
                    el.style.visibility = 'hidden';
                    var li = el.closest('li');
                    if (li) {
                        li.style.display = 'none';
                        li.style.visibility = 'hidden';
                    }
                });
            }
            // Run on page load
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', hideTabs);
            } else {
                hideTabs();
            }
            // Also run after a short delay to catch dynamically loaded tabs
            setTimeout(hideTabs, 100);
        })();
        </script>
        '''


template_extensions = [DeviceContent]
