from django.urls import path
from . import views


urlpatterns = [
    # Automation Jobs
    path('automation/jobs/', views.AutomationJobsListView.as_view(), name='job_list'),
    path('automation/jobs/add/', views.AutomationJobEditView.as_view(), name='job_add'),
    path('automation/jobs/<str:pk>/', views.AutomationJobsView.as_view(), name='job_detail'),
    path('automation/jobs/<str:pk>/edit/', views.AutomationJobEditView.as_view(), name='job_edit'),
    path('automation/jobs/<str:pk>/delete/', views.AutomationJobDeleteView.as_view(), name='job_delete'),
    path('automation/jobs/<str:pk>/run/', views.AutomationJobRunView.as_view(), name='job_run'),
    path('automation/jobs/<str:pk>/job-logs/', views.JobsLogView.as_view(), name='job_logs'),

    # Automation Logs
    path('automation/logs/', views.AutomationLogsView.as_view(), name='log_list'),
    path('automation/logs/<int:pk>/', views.AutomationLogView.as_view(), name='log_detail'),

    # Backups
    path('automation/backups/<str:pk>/', views.BackupPreviewView.as_view(), name='backup_detail'),
    path('automation/backups/<str:pk>/download/', views.BackupDownloadView.as_view(), name='backup_download'),
    path('automation/backup-search/', views.BackupSearchView.as_view(), name='backupsearchhit_list'),

    # Device detail tabs
    path(
        'dcim/devices/<uuid:pk>/netpicker/backups/',
        views.DeviceBackupsView.as_view(),
        name='device_detail_backups'
    ),
    path(
        'dcim/devices/<uuid:pk>/netpicker/history/',
        views.DeviceBackupHistoryView.as_view(),
        name='device_backup_history'
    ),

    # Mapped Devices
    path('map-devices/', views.MappedDeviceListView.as_view(), name='mappeddevice_list'),
    path('map-devices/refresh/', views.MappedDeviceRefreshView.as_view(), name='mappeddevice_refresh'),

    # Settings
    path('settings/', views.SettingsView.as_view(), name='settings'),
    path('settings/<int:pk>/', views.SettingsView.as_view(), name='settings_edit'),
]
