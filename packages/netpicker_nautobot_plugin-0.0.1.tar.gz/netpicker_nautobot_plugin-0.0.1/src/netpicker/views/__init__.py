from .automation import (  # noqa
    AutomationJobsView, AutomationLogsView, AutomationLogView,
    AutomationJobsListView, JobsLogView, AutomationJobEditView,
    AutomationJobDeleteView, AutomationJobRunView
)
from .backup import (  # noqa
    BackupPreviewView, DeviceBackupsView, BackupDownloadView,
    DeviceBackupHistoryView, BackupSearchView
)
from .devices import (MappedDeviceListView, MappedDeviceRefreshView)  # noqa
from .setting import SettingsView  # noqa
