import logging
import re
import time

from django.contrib import messages
from django.contrib.contenttypes.models import ContentType
from django.http import HttpRequest, HttpResponse
from django.shortcuts import redirect, render
from django.urls import reverse
from django.utils.encoding import iri_to_uri
from django.utils.http import url_has_allowed_host_and_scheme
from django.utils.safestring import SafeText
from django.utils.translation import gettext_lazy as _

from nautobot.core.views import generic
from nautobot.core.views.utils import prepare_cloned_fields
from nautobot.dcim.models import Device
from netpicker import forms, tables
from netpicker.client import (
    get_fixtures, get_job_details, get_job_log_details, get_job_logs, get_jobs, run_job
)
from netpicker.models import Job, Log
from netpicker.models.base import ProxyQuerySet
from netpicker.views.base import RequireSettingsMixin
from nautobot.core.forms.utils import restrict_form_fields
from netpicker_client.exceptions import ServiceException


class JobProxyMixin:
    queryset = ProxyQuerySet(model=Job)

    def get_object(self, kwargs):
        if name := kwargs.get('pk'):
            job = get_job_details(name=name)
        else:
            job = Job()
        return job


class AutomationLogsView(RequireSettingsMixin, generic.ObjectListView):
    table = tables.AutomationLogTable
    template_name = 'netpicker/automation/logs.html'
    model = Log
    queryset = ProxyQuerySet(model=Log, data=[])
    action_buttons = []

    def alter_queryset(self, request):
        logs = get_job_logs()
        data = [Log.from_basemodel(obj) for obj in logs]
        return ProxyQuerySet(model=Log, data=data)


class AutomationLogView(RequireSettingsMixin, generic.ObjectView):
    table = tables.AutomationLogTable
    template_name = 'netpicker/automation/log-detail.html'
    queryset = ProxyQuerySet(model=Log)

    def get_queryset(self, request: HttpRequest):
        # this is a fake method to satisfy the view protocol
        return ProxyQuerySet(model=Log)

    def get_object(self, **kwargs):
        obj = get_job_log_details(id=str(kwargs['pk']))
        return Log.from_basemodel(obj)

    def get(self, request, *args, **kwargs):
        """
        Generic GET handler for accessing an object.
        """

        instance = self.get_object(**kwargs)
        model = self.queryset.model
        content_type = ContentType.objects.get_for_model(self.queryset.model)
        context = {
            "object": instance,
            "content_type": content_type,
            "verbose_name": "Log",
            "verbose_name_plural": "Logs",
            "object_detail_content": self.object_detail_content,
            "breadcrumbs": self.get_breadcrumbs(model, view_type=""),
            **self.get_extra_context(request, instance),
        }

        # Some of the legacy views overriding title in `get_extra_context` method.
        # But if not, we will generate the default `title` using the default
        # `Titles` class or one set in class under `view_titles`.
        if context.get("title") is None:
            context["title"] = self.get_view_titles(model, view_type="").render(context)

        return render(request, self.get_template_name(), context)


# Jobs #
class AutomationJobsListView(RequireSettingsMixin, generic.ObjectListView):
    table = tables.AutomationJobsTable
    template_name = 'netpicker/automation/jobs.html'
    model = Job
    verbose_name = _('job')
    verbose_name_plural = _('jobs')
    queryset = ProxyQuerySet(model=Job, data=[])
    action_buttons = ["add"]

    def alter_queryset(self, request):
        jobs = get_jobs()
        q = request.GET.get('q')
        if q:
            q_lower = q.lower()
            filtered_jobs = []
            for job in jobs:
                if q_lower in (job.name or '').lower():
                    filtered_jobs.append(job)
                    continue
                if q_lower in (job.author or '').lower():
                    filtered_jobs.append(job)
                    continue
                if job.tags:
                    if any(q_lower in (tag or '').lower() for tag in job.tags):
                        filtered_jobs.append(job)
                        continue
            jobs = filtered_jobs
        return ProxyQuerySet(model=Job, data=jobs)


class AutomationJobsView(RequireSettingsMixin, generic.ObjectView):
    template_name = 'netpicker/job.html'
    queryset = ProxyQuerySet(model=Job)

    def get_object(self, kwargs):
        if name := kwargs.get('pk'):
            job = get_job_details(name=name)
        else:
            job = Job()
        return job

    def get(self, request, *args, **kwargs):
        """
        Generic GET handler for accessing an object.
        """
        if 'tab' not in request.GET:
            return redirect(f"{request.get_full_path()}?tab=main")

        instance = self.get_object(kwargs)
        model = self.queryset.model
        content_type = ContentType.objects.get_for_model(self.queryset.model)
        context = {
            "object": instance,
            "content_type": content_type,
            "verbose_name": "Job",
            "verbose_name_plural": "Job",
            "object_detail_content": self.object_detail_content,
            "breadcrumbs": self.get_breadcrumbs(model, view_type=""),
            **self.get_extra_context(request, instance),
        }

        if context.get("title") is None:
            context["title"] = self.get_view_titles(model, view_type="").render(context)

        return render(request, self.get_template_name(), context)

    def get_extra_context(self, request, instance):
        nautoboted = instance and instance.tags and 'nautoboted' in instance.tags
        tab = request.GET.get('tab', 'main')

        logs_table = None
        if tab == 'logs' and instance and instance.name:
            logs = get_job_logs(job_name=instance.name)
            data = [Log.from_basemodel(obj) for obj in logs]
            logs_table = tables.AutomationLogTable(data, request=request)

        return {
            'nautoboted': nautoboted,
            'active_tab': tab,
            'logs_table': logs_table,
        }


class JobsLogView(JobProxyMixin, generic.ObjectView):
    table = tables.AutomationLogTable
    template_name = 'netpicker/automation/job-logs.html'

    def get_queryset(self, request):
        # Get the job name from the URL parameters
        job_name = self.kwargs.get('pk')
        if job_name:
            logs = get_job_logs(job_name=job_name)
            data = [Log.from_basemodel(obj) for obj in logs]
            return ProxyQuerySet(model=Log, data=data)
        return ProxyQuerySet(model=Log, data=[])


class AutomationJobEditView(RequireSettingsMixin, JobProxyMixin, generic.ObjectEditView):
    model_form = forms.JobEditForm
    template_name = 'netpicker/automation/job-edit.html'

    def get_required_permission(self):
        return "netpicker.view_job"

    def post(self, request, *args, **kwargs):
        """
        Override to skip Nautobot's object-level permission re-fetch, which
        fails for API-backed proxy objects that don't exist in the DB.
        """
        obj = self.alter_obj(self.get_object(kwargs), request, args, kwargs)
        if self.model_form is None:
            raise RuntimeError("self.model_form must not be None")

        form = self.model_form(  # pylint: disable=not-callable
            data=request.POST,
            files=request.FILES,
            initial=request.GET.dict(),
            instance=obj,
        )
        restrict_form_fields(form, request.user)

        if form.is_valid():
            object_created = not form.instance.present_in_database
            obj = form.save()

            if hasattr(form, "save_note") and callable(form.save_note):
                form.save_note(instance=obj, user=request.user)

            self.successful_post(request, obj, object_created, logging.getLogger(__name__ + ".AutomationJobEditView"))

            if "_addanother" in request.POST:
                if hasattr(obj, "clone_fields"):
                    url = f"{request.path}?{prepare_cloned_fields(obj)}"
                    return redirect(url)
                return redirect(request.get_full_path())

            return_url = form.cleaned_data.get("return_url")
            if url_has_allowed_host_and_scheme(url=return_url, allowed_hosts=request.get_host()):
                return redirect(iri_to_uri(return_url))
            return redirect(self.get_return_url(request, obj))

        return render(
            request,
            self.template_name,
            {
                "obj": obj,
                "obj_type": self.queryset.model._meta.verbose_name,
                "form": form,
                "view_action": "update" if obj.present_in_database else "create",
                "breadcrumbs": self.get_breadcrumbs(),
                "return_url": self.get_return_url(request, obj),
                "editing": obj.present_in_database,
                **self.get_extra_context(request, obj),
            },
        )


class AutomationJobDeleteView(RequireSettingsMixin, JobProxyMixin, generic.ObjectDeleteView):
    def _get_dependent_objects(self, obj):
        return {}

    def get_return_url(self, request, obj=None):
        return reverse('plugins:netpicker:job_list')


class AutomationJobRunView(RequireSettingsMixin, generic.ObjectEditView):
    template_name = 'netpicker/automation/job-run.html'
    queryset = ProxyQuerySet(model=Job)

    def get_object(self, **kwargs):
        if name := kwargs.get('pk'):
            job = get_job_details(name=name)
        else:
            job = Job()
        return job

    def form(self, instance: Job, **kwargs):
        fixtures = get_fixtures()
        form_cls = forms.get_job_exec_form(instance, fixtures)
        return form_cls(instance=instance, **kwargs)

    def get(self, request, *args, **kwargs):
        obj = self.get_object(**kwargs)
        form = self.form(instance=obj)
        restrict_form_fields(form, request.user)
        context = {
            'model': Job,
            'object': obj,
            'form': form,
            'return_url': self.get_return_url(request, obj),
            'final_commands': {},
            **self.get_extra_context(request, obj),
        }
        return render(request, self.template_name, context)

    def post(self, request: HttpRequest, *args, **kwargs):
        obj = self.get_object(**kwargs)
        form = self.form(data=request.POST, files=request.FILES, instance=obj)
        restrict_form_fields(form, request.user)
        final_commands = {}
        if form.is_valid():
            data = form.cleaned_data
            unconfirmed_data = data.copy()
            device_selections = data.pop('devices', None) or []

            devices = []
            ip_addresses = []
            for selection in device_selections:
                if selection.startswith('device:'):
                    try:
                        device_pk = int(selection.split(':', 1)[1])
                        device = Device.objects.get(pk=device_pk)
                        devices.append(device)
                    except (ValueError, Device.DoesNotExist):
                        pass
                elif selection.startswith('ip:'):
                    ip = selection.split(':', 1)[1]
                    ip_addresses.append(ip)

            if data.pop('confirm', False):
                try:
                    run_job(
                        obj,
                        devices=devices if devices else None,
                        ip_addresses=ip_addresses if ip_addresses else None,
                        variables=data
                    )
                    time.sleep(4)
                    messages.success(request, 'Job was successfully dispatched for execution.')
                    logs_url = reverse('plugins:netpicker:log_list')
                    if hasattr(request, 'htmx') and request.htmx:
                        return HttpResponse(headers={
                            'HX-Location': logs_url,
                        })

                    return redirect(logs_url)
                except ServiceException:
                    error_msg = _(
                        'Error executing job on the API server. '
                        'This may be a temporary issue. Please try again or '
                        'contact the API server administrator.'
                    )
                    messages.error(request, error_msg)

                    unconfirmed_data['confirm'] = True
                    form = self.form(data=unconfirmed_data, instance=obj)
                    final_commands = prefill_commands(obj, unconfirmed_data)
                    context = {
                        'model': Job,
                        'object': obj,
                        'form': form,
                        'return_url': self.get_return_url(request, obj),
                        'final_commands': final_commands,
                        **self.get_extra_context(request, obj),
                    }
                    return render(request, self.template_name, context)

            unconfirmed_data['confirm'] = True
            form = self.form(data=unconfirmed_data, instance=obj)
            final_commands = prefill_commands(obj, unconfirmed_data)

        context = {
            'model': Job,
            'object': obj,
            'form': form,
            'return_url': self.get_return_url(request, obj),
            'final_commands': final_commands,
            **self.get_extra_context(request, obj),
        }
        return render(request, self.template_name, context)


def prefill_commands(obj, data):
    if obj.commands is None:
        return 'Complex jobs cannot show rendered commands'

    hilited = {k: f"<b>{v}</b>" for k, v in data.items()}

    def safe_format(cmd, mapping):
        """Format a command string, handling missing keys gracefully."""
        def replace_placeholder(match):
            key = match.group(1)
            if key in mapping:
                return mapping[key]
            return f"<i>[{key}]</i>"

        return re.sub(r'\{(\w+)\}', replace_placeholder, cmd)

    lines = [safe_format(cmd, hilited) for cmd in obj.commands]
    block = '<br/>'.join(lines)
    return SafeText(block)
