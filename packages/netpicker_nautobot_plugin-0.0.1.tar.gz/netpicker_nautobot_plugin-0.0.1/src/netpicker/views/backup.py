from datetime import UTC, datetime, timedelta

import requests
from django.http import HttpRequest, StreamingHttpResponse
from django.utils.safestring import SafeText
from django.utils.translation import gettext_lazy as _
from django.views import View

from nautobot.apps.views import ObjectView
from nautobot.dcim.models import Device
from nautobot.dcim.views import DeviceUIViewSet
from nautobot.core.views import generic
from django.contrib.contenttypes.models import ContentType
from django.shortcuts import render
from netpicker.client import (
    download_config, get_device_readouts, get_readout_history,
    search_configs_with_error_handling
)
from netpicker.models import (
    Backup, BackupSearchHit, MappedDevice, ProxyQuerySet
)
from netpicker import tables
from netpicker.utilities import get_logo, get_settings
from netpicker.views.base import RequireSettingsMixin
from netpicker_client.exceptions import NotFoundException, ApiException


def get_label(prefix: str) -> SafeText:
    fmt_logo = get_logo(style="width:16px; vertical-align:top")
    result = SafeText(_(prefix) + ' ') + fmt_logo
    return result


class BackupProxyMixin:
    def get_object(self, **kwargs):
        backup = Backup()
        if pk := kwargs.get('pk'):
            backup.id = pk
            try:
                ipaddress, config_id = pk.split('-')
            except ValueError:
                backup.preview = None
                backup.error_message = "Invalid backup ID format"
                return backup

            try:
                backup.preview = download_config(ipaddress, config_id)
                backup.error_message = None
            except Exception as e:
                backup.preview = None
                backup.error_message = str(e)
        return backup

    def get_queryset(self, request: HttpRequest):
        # this is a fake method to satisfy the view protocol
        return ProxyQuerySet(model=Backup)


class DeviceBackupsView(RequireSettingsMixin, ObjectView):
    """
    This view's template extends the device detail template,
    making it suitable to show as a tab on the device detail page.

    Views that are intended to be for an object detail tab's content rendering must
    always inherit from nautobot.apps.views.ObjectView.
    """
    queryset = Device.objects.all()
    table = tables.DeviceBackupTable
    template_name = 'netpicker/device_backups_tab.html'
    object_detail_content = DeviceUIViewSet.object_detail_content

    def get_queryset(self, request):
        # Get the device ID from the URL parameters
        # This provides data for the table, not the device instance
        device_id = self.kwargs.get('pk')
        if device_id and request.settings:
            device = Device.objects.get(pk=device_id)
            mapped_devices = MappedDevice.objects.filter(nautobot=device)

            if not mapped_devices.exists():
                mapped_devices = MappedDevice.objects.filter(name=device.name)

            all_backups = []
            for mapped_device in mapped_devices:
                ipaddress = mapped_device.ipaddress
                try:
                    backups = get_device_readouts(device.id, ipaddress)
                    all_backups.extend(backups)
                except (NotFoundException, ApiException):
                    # Device not found in NetPicker API, skip this mapped device
                    continue

            return all_backups
        return []

    def get_extra_context(self, request, instance):
        extra_context = super().get_extra_context(request, instance)
        extra_context["active_tab"] = "netpicker_device_backups"

        # Add table to context for rendering
        backup_data = self.get_queryset(request)
        if self.table and backup_data:
            extra_context["table"] = self.table(backup_data, request=request)
        else:
            extra_context["table"] = None

        return extra_context


class BackupPreviewView(RequireSettingsMixin, BackupProxyMixin, generic.ObjectView):
    template_name = 'netpicker/backup.preview.html'
    queryset = ProxyQuerySet(model=Backup)

    def get_object(self, **kwargs):
        return BackupProxyMixin.get_object(self, **kwargs)

    def get(self, request, *args, **kwargs):
        instance = self.get_object(**kwargs)
        model = self.queryset.model
        content_type = ContentType.objects.get_for_model(self.queryset.model)
        context = {
            "object": instance,
            "content_type": content_type,
            "verbose_name": "Backup",
            "verbose_name_plural": "Backups",
            "breadcrumbs": self.get_breadcrumbs(model, view_type=""),
            **self.get_extra_context(request, instance),
        }

        if context.get("title") is None:
            context["title"] = self.get_view_titles(model, view_type="").render(context)

        return render(request, self.get_template_name(), context)


class BackupDownloadView(View):
    def dispatch(self, request: HttpRequest, *args, **kwargs):
        settings = get_settings(request)
        pk = request.resolver_match.kwargs.get('pk')
        ipaddress, config_id = pk.split('-')
        url = f"{settings.server_url}/api/v1/devices/{settings.tenant}/{ipaddress}/configs/{config_id}"
        headers = {'authorization': f"Bearer {settings.api_key}"}
        r = requests.get(url, headers=headers, stream=True)
        resp = StreamingHttpResponse(streaming_content=r.raw)
        resp['content-disposition'] = f'attachment; filename="{pk}.backup"'
        return resp


class DeviceBackupHistoryView(RequireSettingsMixin, ObjectView):
    """
    This view's template extends the device detail template,
    making it suitable to show as a tab on the device detail page.
    """
    queryset = Device.objects.all()
    table = tables.DeviceBackupHistoryTable
    template_name = 'netpicker/device_backup_history_tab.html'
    object_detail_content = DeviceUIViewSet.object_detail_content

    def get_queryset(self, request):
        # Get the device ID from the URL parameters
        # This provides data for the table, not the device instance
        device_id = self.kwargs.get('pk')
        if device_id and request.settings:
            device = Device.objects.get(pk=device_id)
            mapped_devices = MappedDevice.objects.filter(nautobot=device)

            if not mapped_devices.exists():
                mapped_devices = MappedDevice.objects.filter(name=device.name)

            # Get date from request, default to 30 days ago
            date_param = request.GET.get('after_date')
            if date_param:
                after = date_param
            else:
                start = datetime.now(UTC) - timedelta(days=30)
                after = start.strftime('%Y-%m-%d')

            all_history = []
            for mapped_device in mapped_devices:
                ipaddress = mapped_device.ipaddress
                try:
                    history = get_readout_history(ipaddress, after)
                    all_history.extend(history)
                except (NotFoundException, ApiException):
                    # Device not found in NetPicker API, skip this mapped device
                    continue

            return all_history
        return []

    def get_extra_context(self, request, instance):
        extra_context = super().get_extra_context(request, instance)
        extra_context["active_tab"] = "netpicker_device_backup_history"

        # Calculate default date (30 days ago)
        start = datetime.now(UTC) - timedelta(days=30)
        default_date = start.strftime('%Y-%m-%d')

        # Get current date from request or use default
        current_date = request.GET.get('after_date', default_date)
        extra_context["default_date"] = default_date
        extra_context["current_date"] = current_date

        # Add table to context for rendering
        history_data = self.get_queryset(request)
        if self.table and history_data:
            extra_context["table"] = self.table(history_data, request=request)
        else:
            extra_context["table"] = None

        return extra_context


class BackupSearchView(RequireSettingsMixin, generic.ObjectListView):
    table = tables.DeviceBackupSearchTable
    template_name = 'netpicker/backup-search.html'
    model = BackupSearchHit
    queryset = ProxyQuerySet(model=BackupSearchHit, data=[])
    action_buttons = []

    def alter_queryset(self, request):
        q = request.GET.get('q')
        if q:
            hits, error_occurred = search_configs_with_error_handling(q)
            # Store error flag in request for use in template
            request.api_error_occurred = error_occurred
        else:
            hits = []
            request.api_error_occurred = False
        return ProxyQuerySet(model=BackupSearchHit, data=hits)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['api_error_occurred'] = getattr(self.request, 'api_error_occurred', False)
        return context
