from django.contrib import messages
from django.db.models import Q
from django.shortcuts import redirect
from django.views import View
from nautobot.core.views import generic
from netpicker import tables
from netpicker.models import MappedDevice
from netpicker.utilities import reload_devices
from netpicker.views.base import RequireSettingsMixin


class MappedDeviceListView(RequireSettingsMixin, generic.ObjectListView):
    table = tables.MappedDeviceTable
    template_name = 'netpicker/devices.html'
    queryset = MappedDevice.objects.all()
    action_buttons = []

    def get(self, request, *args, **kwargs):
        return super().get(request, *args, **kwargs)

    def alter_queryset(self, request):
        """Filter queryset based on search query parameter."""
        queryset = self.queryset
        q = request.GET.get('q')
        if q:
            # Search in name, ipaddress, platform, and related Nautobot device name
            queryset = queryset.filter(
                Q(name__icontains=q) |
                Q(ipaddress__icontains=q) |
                Q(platform__icontains=q) |
                Q(nautobot__name__icontains=q)
            )
        return queryset


class MappedDeviceRefreshView(RequireSettingsMixin, View):
    def post(self, request, *args, **kwargs):
        try:
            reload_devices()
            messages.success(request, 'Devices refreshed successfully.')
        except Exception as e:
            messages.error(request, f'Error refreshing devices: {str(e)}')

        return redirect('plugins:netpicker:mappeddevice_list')
