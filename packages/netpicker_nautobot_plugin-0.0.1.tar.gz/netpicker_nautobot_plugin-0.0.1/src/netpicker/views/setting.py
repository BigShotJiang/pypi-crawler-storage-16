import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

from nautobot.core.views import generic
from netpicker import forms

from netpicker.models import NetpickerSetting
from netpicker.utilities import reload_devices

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)


class SettingsView(generic.ObjectEditView):
    model_form = forms.SettingsForm
    queryset = NetpickerSetting.objects.all()
    template_name = 'netpicker/settings/netpicker.html'

    def get_object(self, *args, **kwargs):
        # For settings, we always return the first (and only) setting
        # or create one if it doesn't exist
        pk = kwargs.get('pk')
        if pk:
            return self.queryset.get(pk=pk)
        else:
            obj, created = self.queryset.get_or_create(pk=1)
            return obj

    def post(self, request, *args, **kwargs):
        response = super().post(request, *args, **kwargs)

        is_success = (
            hasattr(response, 'status_code') and response.status_code in (302, 303)
        ) or (
            hasattr(response, 'headers') and 'HX-Location' in response.headers
        )

        if is_success:
            try:
                reload_devices()
            except Exception:
                pass

        return response
