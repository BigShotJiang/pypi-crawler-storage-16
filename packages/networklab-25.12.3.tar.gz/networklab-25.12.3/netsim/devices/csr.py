#
# Cisco IOS-XE quirks
#

from .iol import IOSXE as _IOSXE


class CSR(_IOSXE):
  pass
