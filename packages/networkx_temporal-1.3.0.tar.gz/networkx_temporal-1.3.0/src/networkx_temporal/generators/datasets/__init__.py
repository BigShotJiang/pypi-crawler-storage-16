from .collegemsg import collegemsg_graph
from .pubmed import pubmed_graph