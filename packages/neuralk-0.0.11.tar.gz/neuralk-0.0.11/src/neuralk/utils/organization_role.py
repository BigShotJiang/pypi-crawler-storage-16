from enum import Enum


class OrganizationRole(Enum):
    ADMIN = 1
    MEMBER = 3
