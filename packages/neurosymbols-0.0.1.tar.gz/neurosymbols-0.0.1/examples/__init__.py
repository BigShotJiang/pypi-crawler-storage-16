"""Example scripts demonstrating the neuro-symbolic pipeline."""
