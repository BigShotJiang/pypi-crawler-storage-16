# Copyright 2010 New Relic, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
import ssl
import sys
import time
import zlib
from pathlib import Path
from pprint import pprint

from newrelic import version
from newrelic.common import certs
from newrelic.common.encoding_utils import json_decode, json_encode, obfuscate_license_key
from newrelic.common.object_names import callable_name
from newrelic.common.object_wrapper import patch_function_wrapper
from newrelic.core.internal_metrics import internal_count_metric, internal_metric
from newrelic.network.exceptions import NetworkInterfaceException
from newrelic.packages import urllib3

try:
    from ssl import get_default_verify_paths
except ImportError:

    class _DEFAULT_CERT_PATH:
        cafile = None
        capath = None

    def get_default_verify_paths():
        return _DEFAULT_CERT_PATH


HEADER_AUDIT_LOGGING_DENYLIST = frozenset(("x-api-key", "api-key"))


# User agent string that must be used in all requests. The data collector
# does not rely on this, but is used to target specific agents if there
# is a problem with data collector handling requests.

USER_AGENT = f"NewRelic-PythonAgent/{version} (Python {sys.version.split()[0]} {sys.platform})"


# This is a monkey patch for urllib3 + python3.6 + gevent/eventlet.
# Gevent/Eventlet patches the ssl library resulting in a re-binding that causes
# infinite recursion in a super call. In order to prevent this error, the
# SSLContext object should be accessed through the ssl library attribute.
#
#   https://github.com/python/cpython/commit/328067c468f82e4ec1b5c510a4e84509e010f296#diff-c49248c7181161e24048bec5e35ba953R457
#   https://github.com/gevent/gevent/blob/f3acb176d0f0f1ac797b50e44a5e03726f687c53/src/gevent/_ssl3.py#L67
#   https://github.com/shazow/urllib3/pull/1177
#   https://bugs.python.org/issue29149
#
@patch_function_wrapper("newrelic.packages.urllib3.util.ssl_", "SSLContext")
def _urllib3_ssl_recursion_workaround(wrapped, instance, args, kwargs):
    try:
        import ssl

        return ssl.SSLContext(*args, **kwargs)
    except:
        return wrapped(*args, **kwargs)


class BaseClient:
    AUDIT_LOG_ID = 0

    def __init__(
        self,
        host,
        port,
        proxy_scheme=None,
        proxy_host=None,
        proxy_port=None,
        proxy_user=None,
        proxy_pass=None,
        timeout=None,
        ca_bundle_path=None,
        disable_certificate_validation=False,
        compression_threshold=64 * 1024,
        compression_level=None,
        compression_method="gzip",
        max_payload_size_in_bytes=1000000,
        audit_log_fp=None,
        default_content_encoding_header="Identity",
    ):
        self._host = host
        self._audit_log_fp = audit_log_fp

    def __enter__(self):
        return self

    def __exit__(self, exc, value, tb):
        pass

    def close_connection(self):
        pass

    def finalize(self):
        pass

    @staticmethod
    def _supportability_request(params, payload, body, compression_time):
        pass

    @classmethod
    def log_request(cls, fp, method, url, params, payload, headers, body=None, compression_time=None):
        cls._supportability_request(params, payload, body, compression_time)

        if not fp:
            return

        # Obfuscate license key from headers and URL params
        if headers:
            headers = {
                k: obfuscate_license_key(v) if k.lower() in HEADER_AUDIT_LOGGING_DENYLIST else v
                for k, v in headers.items()
            }

        if params and "license_key" in params:
            params = params.copy()
            params["license_key"] = obfuscate_license_key(params["license_key"])

        # Maintain a global AUDIT_LOG_ID attached to all class instances
        # NOTE: this is not thread safe so this class cannot be used
        # across threads when audit logging is on
        cls.AUDIT_LOG_ID += 1

        print(f"TIME: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())!r}", file=fp)
        print(file=fp)
        print(f"ID: {cls.AUDIT_LOG_ID!r}", file=fp)
        print(file=fp)
        print(f"PID: {os.getpid()!r}", file=fp)
        print(file=fp)
        print(f"URL: {url!r}", file=fp)
        print(file=fp)
        print(f"PARAMS: {params!r}", file=fp)
        print(file=fp)
        print(f"HEADERS: {headers!r}", file=fp)
        print(file=fp)
        print("DATA:", end=" ", file=fp)

        try:
            data = json_decode(payload.decode("utf-8"))
        except Exception:
            data = payload

        pprint(data, stream=fp)

        print(file=fp)
        print(78 * "=", file=fp)
        print(file=fp)

        fp.flush()

        return cls.AUDIT_LOG_ID

    @staticmethod
    def _supportability_response(status, exc, connection="direct"):
        pass

    @classmethod
    def log_response(cls, fp, log_id, status, headers, data, connection="direct"):
        if not status:
            # Exclude traceback in order to prevent a reference cycle
            exc_info = sys.exc_info()[:2]
        else:
            exc_info = None

        cls._supportability_response(status, exc_info and exc_info[0], connection)

        if not fp:
            return

        try:
            result = json_decode(data)
        except Exception:
            result = data

        print(f"TIME: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())!r}", file=fp)
        print(file=fp)
        print(f"ID: {log_id!r}", file=fp)
        print(file=fp)
        print(f"PID: {os.getpid()!r}", file=fp)
        print(file=fp)

        if exc_info:
            print(f"Exception: {exc_info[1]!r}", file=fp)
            print(file=fp)
        else:
            print(f"STATUS: {status!r}", file=fp)
            print(file=fp)
            print("HEADERS:", end=" ", file=fp)
            pprint(dict(headers), stream=fp)
            print(file=fp)
            print("RESULT:", end=" ", file=fp)
            pprint(result, stream=fp)
            print(file=fp)

        print(78 * "=", file=fp)
        print(file=fp)

        fp.flush()

    def send_request(
        self, method="POST", path="/agent_listener/invoke_raw_method", params=None, headers=None, payload=None
    ):
        return 202, b""


class HttpClient(BaseClient):
    CONNECTION_CLS = urllib3.HTTPSConnectionPool
    PREFIX_SCHEME = "https://"
    BASE_HEADERS = urllib3.make_headers(keep_alive=True, accept_encoding=True, user_agent=USER_AGENT)

    def __init__(
        self,
        host,
        port=443,
        proxy_scheme=None,
        proxy_host=None,
        proxy_port=None,
        proxy_user=None,
        proxy_pass=None,
        timeout=None,
        ca_bundle_path=None,
        disable_certificate_validation=False,
        compression_threshold=64 * 1024,
        compression_level=None,
        compression_method="gzip",
        max_payload_size_in_bytes=1000000,
        audit_log_fp=None,
        default_content_encoding_header="Identity",
    ):
        self._host = host
        self._port = port
        self._compression_threshold = compression_threshold
        self._compression_level = compression_level
        self._compression_method = compression_method
        self._max_payload_size_in_bytes = max_payload_size_in_bytes
        self._audit_log_fp = audit_log_fp
        self._default_content_encoding_header = default_content_encoding_header

        self._prefix = ""

        self._headers = dict(self.BASE_HEADERS)
        self._connection_kwargs = connection_kwargs = {"timeout": timeout}
        self._urlopen_kwargs = urlopen_kwargs = {}

        if self.CONNECTION_CLS.scheme == "https":
            if not ca_bundle_path:
                verify_path = get_default_verify_paths()

                if not verify_path.cafile and not verify_path.capath:
                    if sys.platform != "win32":
                        # If there is no resolved cafile on POSIX platforms, assume the bundled certs
                        # are required and report this condition as a supportability metric.
                        ca_bundle_path = certs.where()
                        internal_metric("Supportability/Python/Certificate/BundleRequired", 1)
                    else:
                        # If there is no resolved cafile on Windows, attempt to load the default certs.
                        try:
                            _context = ssl.SSLContext()
                            _context.load_default_certs()
                            system_certs = _context.get_ca_certs()
                        except Exception:
                            system_certs = None

                        # If we still can't find any certs after loading the default ones,
                        # then assume the bundled certs are required. If we do find them,
                        # we don't have to do anything. We let urllib3 handle loading the
                        # default certs from Windows.
                        if not system_certs:
                            ca_bundle_path = certs.where()
                            internal_metric("Supportability/Python/Certificate/BundleRequired", 1)

            if ca_bundle_path:
                if Path(ca_bundle_path).is_dir():
                    connection_kwargs["ca_cert_dir"] = ca_bundle_path
                else:
                    connection_kwargs["ca_certs"] = ca_bundle_path

            if disable_certificate_validation:
                connection_kwargs["cert_reqs"] = "NONE"

        proxy = self._parse_proxy(proxy_scheme, proxy_host, proxy_port, proxy_user, proxy_pass)
        proxy_headers = proxy and proxy.auth and urllib3.make_headers(proxy_basic_auth=proxy.auth)

        if proxy:
            if self.CONNECTION_CLS.scheme == "https" and proxy.scheme != "https":
                connection_kwargs["_proxy"] = proxy
                connection_kwargs["_proxy_headers"] = proxy_headers
            else:
                self._host = proxy.host
                self._port = proxy.port or 443
                self._prefix = f"{self.PREFIX_SCHEME + host}:{port!s}"
                urlopen_kwargs["assert_same_host"] = False
                if proxy_headers:
                    self._headers.update(proxy_headers)

        # Logging
        self._proxy = proxy

        self._connection_attr = None

    @staticmethod
    def _parse_proxy(scheme, host, port, username, password):
        # Users may specify a full URL for the host
        # In this case, the URL is used as a starting point to build up the URL
        components = urllib3.util.parse_url(host)

        scheme = components.scheme or scheme or None
        host = components.host or host or None
        port = components.port or port or None

        if components.auth:
            auth = components.auth
        else:
            auth = username
            if auth and password is not None:
                auth = f"{auth}:{password}"

        # Host must be defined
        if not host:
            return

        # At least one of (scheme, port) must be defined
        if not scheme and not port:
            return

        return urllib3.util.Url(scheme=scheme, auth=auth, host=host, port=port)

    def __enter__(self):
        self._connection.__enter__()
        return self

    def __exit__(self, exc, value, tb):
        if self._connection_attr:
            self._connection_attr.__exit__(exc, value, tb)
            self._connection_attr = None

    @property
    def _connection(self):
        if self._connection_attr:
            return self._connection_attr

        retries = urllib3.Retry(total=False, connect=None, read=None, redirect=0, status=None)
        self._connection_attr = self.CONNECTION_CLS(
            self._host, self._port, strict=True, retries=retries, **self._connection_kwargs
        )
        return self._connection_attr

    def close_connection(self):
        if self._connection_attr:
            self._connection_attr.close()
            self._connection_attr = None

    def log_request(self, fp, method, url, params, payload, headers, body=None, compression_time=None):
        if not self._prefix:
            url = f"{self.CONNECTION_CLS.scheme}://{self._host}{url}"

        return super().log_request(fp, method, url, params, payload, headers, body, compression_time)

    @staticmethod
    def _compress(data, method="gzip", level=None):
        compression_start = time.time()
        level = level or zlib.Z_DEFAULT_COMPRESSION
        wbits = 31 if method == "gzip" else 15

        compressor = zlib.compressobj(level, zlib.DEFLATED, wbits)
        data = compressor.compress(data)
        data += compressor.flush()

        compression_time = max(time.time(), compression_start) - compression_start

        return data, compression_time

    def send_request(
        self, method="POST", path="/agent_listener/invoke_raw_method", params=None, headers=None, payload=None
    ):
        if self._proxy:
            proxy_scheme = self._proxy.scheme or "http"
            connection = f"{proxy_scheme}-proxy"
        else:
            connection = "direct"

        merged_headers = dict(self._headers)
        if headers:
            merged_headers.update(headers)
        path = self._prefix + path
        body = payload
        compression_time = None
        if payload is not None:
            if len(payload) > self._compression_threshold:
                body, compression_time = self._compress(
                    payload, method=self._compression_method, level=self._compression_level
                )
                merged_headers["Content-Encoding"] = self._compression_method
            elif self._default_content_encoding_header:
                merged_headers["Content-Encoding"] = self._default_content_encoding_header

        request_id = self.log_request(
            self._audit_log_fp, "POST", path, params, payload, merged_headers, body, compression_time
        )

        if body and len(body) > self._max_payload_size_in_bytes:
            return 413, b""

        try:
            response = self._connection.request_encode_url(
                method, path, fields=params, body=body, headers=merged_headers, **self._urlopen_kwargs
            )
        except urllib3.exceptions.HTTPError as exc:
            self.log_response(self._audit_log_fp, request_id, 0, None, None, connection)
            # All urllib3 HTTP errors should be treated as a network
            # interface exception.
            raise NetworkInterfaceException(exc) from exc

        self.log_response(self._audit_log_fp, request_id, response.status, response.headers, response.data, connection)

        return response.status, response.data


class InsecureHttpClient(HttpClient):
    CONNECTION_CLS = urllib3.HTTPConnectionPool
    PREFIX_SCHEME = "http://"

    def __init__(
        self,
        host,
        port=80,
        proxy_scheme=None,
        proxy_host=None,
        proxy_port=None,
        proxy_user=None,
        proxy_pass=None,
        timeout=None,
        ca_bundle_path=None,
        disable_certificate_validation=False,
        compression_threshold=64 * 1024,
        compression_level=None,
        compression_method="gzip",
        max_payload_size_in_bytes=1000000,
        audit_log_fp=None,
        default_content_encoding_header="Identity",
    ):
        proxy = self._parse_proxy(proxy_scheme, proxy_host, None, None, None)
        if proxy and proxy.scheme == "https":
            # HTTPS must be used to connect to the proxy
            self.CONNECTION_CLS = urllib3.HTTPSConnectionPool
        else:
            # Disable any HTTPS specific options
            ca_bundle_path = None
            disable_certificate_validation = None

        super().__init__(
            host,
            port,
            proxy_scheme,
            proxy_host,
            proxy_port,
            proxy_user,
            proxy_pass,
            timeout,
            ca_bundle_path,
            disable_certificate_validation,
            compression_threshold,
            compression_level,
            compression_method,
            max_payload_size_in_bytes,
            audit_log_fp,
            default_content_encoding_header,
        )


class SupportabilityMixin:
    @staticmethod
    def _supportability_request(params, payload, body, compression_time):
        # *********
        # Used only for supportability metrics. Do not use to drive business
        # logic!
        # payload: uncompressed
        # body: compressed
        agent_method = params and params.get("method")
        # *********

        if agent_method and payload:
            # Compression was applied
            if compression_time is not None:
                internal_metric(f"Supportability/Python/Collector/{agent_method}/ZLIB/Bytes", len(body))
                internal_metric("Supportability/Python/Collector/ZLIB/Bytes", len(body))
                internal_metric(f"Supportability/Python/Collector/{agent_method}/ZLIB/Compress", compression_time)
            internal_metric(f"Supportability/Python/Collector/{agent_method}/Output/Bytes", len(payload))
            # Top level metric to aggregate overall bytes being sent
            internal_metric("Supportability/Python/Collector/Output/Bytes", len(payload))

    @staticmethod
    def _supportability_response(status, exc, connection="direct"):
        if exc or not 200 <= status < 300:
            internal_count_metric("Supportability/Python/Collector/Failures", 1)
            internal_count_metric(f"Supportability/Python/Collector/Failures/{connection}", 1)

            if exc:
                internal_count_metric(f"Supportability/Python/Collector/Exception/{callable_name(exc)}", 1)
            else:
                internal_count_metric(f"Supportability/Python/Collector/HTTPError/{status}", 1)


class ApplicationModeClient(SupportabilityMixin, HttpClient):
    pass


class DeveloperModeClient(SupportabilityMixin, BaseClient):
    RESPONSES = {  # noqa: RUF012
        "preconnect": {"redirect_host": "fake-collector.newrelic.com"},
        "agent_settings": [],
        "connect": {
            "js_agent_loader": "<!-- NREUM -->",
            "js_agent_file": "fake-js-agent.newrelic.com/nr-0.min.js",
            "browser_key": "1234567890",
            "browser_monitoring.loader_version": "0",
            "beacon": "fake-beacon.newrelic.com",
            "error_beacon": "fake-jserror.newrelic.com",
            "apdex_t": 0.5,
            "encoding_key": "1111111111111111111111111111111111111111",
            "entity_guid": "DEVELOPERMODEENTITYGUID",
            "agent_run_id": "1234567",
            "product_level": 50,
            "trusted_account_ids": [12345],
            "trusted_account_key": "12345",
            "url_rules": [],
            "collect_errors": True,
            "account_id": "12345",
            "cross_process_id": "12345#67890",
            "messages": [{"message": "Reporting to fake collector", "level": "INFO"}],
            "sampling_rate": 0,
            "collect_traces": True,
            "collect_span_events": True,
            "data_report_period": 60,
        },
        "metric_data": None,
        "get_agent_commands": [],
        "profile_data": [],
        "agent_command_results": [],
        "error_data": None,
        "transaction_sample_data": None,
        "sql_trace_data": None,
        "analytic_event_data": None,
        "error_event_data": None,
        "span_event_data": None,
        "custom_event_data": None,
        "log_event_data": None,
        "update_loaded_modules": ["Jars", [[" ", " ", {}]]],
        "shutdown": [],
    }

    def send_request(
        self, method="POST", path="/agent_listener/invoke_raw_method", params=None, headers=None, payload=None
    ):
        # Pre-connect and OTLP endpoint requests will not have the fake- prefix, so we forcibly add it just to be sure.
        host = self._host if self._host.startswith("fake-") else f"fake-{self._host}"
        url = f"https://{host}{path}"
        request_id = self.log_request(self._audit_log_fp, "POST", url, params, payload, headers)

        # Don't attempt to handle OTLP endpoint requests
        if host == "fake-otlp.nr-data.net":
            return 200, b""

        # Requests to the collector must have a method parameter or they're invalid
        if not params or "method" not in params:
            return 400, b"Missing method parameter"

        # If we don't have a canned response for the method, return an error
        method = params["method"]
        if method not in self.RESPONSES:
            return 400, b"Invalid method received"

        result = self.RESPONSES[method]
        payload = {"return_value": result}
        response_data = json_encode(payload).encode("utf-8")
        self.log_response(self._audit_log_fp, request_id, 200, {}, response_data)
        return 200, response_data


class ServerlessModeClient(DeveloperModeClient):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.payload = {}

    def send_request(
        self, method="POST", path="/agent_listener/invoke_raw_method", params=None, headers=None, payload=None
    ):
        result = super().send_request(method=method, path=path, params=params, headers=headers, payload=payload)

        # Check for the presence of agent_method to ensure this isn't an OTLP request
        agent_method = params and params.get("method")
        if result[0] == 200 and agent_method:
            self.payload[agent_method] = json_decode(payload.decode("utf-8"))

        return result

    def finalize(self):
        output = dict(self.payload)
        self.payload.clear()
        return output
