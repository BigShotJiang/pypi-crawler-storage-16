
if __name__ == "__main__":
    from neuroshard.cli import main
    main()
