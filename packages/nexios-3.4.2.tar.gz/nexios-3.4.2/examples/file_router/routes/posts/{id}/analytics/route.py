from nexios.http import Request, Response


async def get(req: Request, res: Response):
    pass
