console.log('Hello from JS');
