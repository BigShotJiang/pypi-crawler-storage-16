from ..enums import WebSocketOperationType
from .base import SimpleOperationAction


class WebSocketOperationAction(SimpleOperationAction[WebSocketOperationType]):
    pass
