"""
command line arguments
"""
if __name__ == '__main__':
    from nexus2srs.cli import cli_nexus2srs
    cli_nexus2srs()

