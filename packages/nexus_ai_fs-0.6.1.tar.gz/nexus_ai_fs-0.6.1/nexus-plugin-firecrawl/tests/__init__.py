"""Tests for nexus-plugin-firecrawl."""
