---
name: gcs
description: Google Cloud Storage connector mounted at {mount_path}. Access GCS bucket objects through the Nexus filesystem.
---
