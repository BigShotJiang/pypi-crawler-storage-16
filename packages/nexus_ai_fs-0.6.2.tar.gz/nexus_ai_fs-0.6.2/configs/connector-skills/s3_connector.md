---
name: s3
description: AWS S3 connector mounted at {mount_path}. Access S3 bucket objects through the Nexus filesystem.
---
