"""Nexus Skill Seekers Plugin - Generate skills from documentation."""

__version__ = "0.1.0"
