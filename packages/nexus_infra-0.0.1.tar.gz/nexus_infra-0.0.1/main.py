def main():
    print("Hello from nexus-ai!")


if __name__ == "__main__":
    main()
