"""
nexus_matcher.application | Layer: APPLICATION
Use cases and application services.

Contains:
- use_cases/: Core business use cases
- dto/: Data transfer objects
"""
