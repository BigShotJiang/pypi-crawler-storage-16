"""
nexus_matcher.infrastructure | Layer: INFRASTRUCTURE
External adapters and implementations.

Contains:
- adapters/: Implementations of domain ports
- config/: Configuration management
- persistence/: Data persistence utilities
"""
