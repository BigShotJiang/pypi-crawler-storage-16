"""
nexus_matcher.presentation | Layer: PRESENTATION
External interfaces for NexusMatcher (API, CLI, Plugins).

This layer contains:
- api/: REST API with FastAPI
- cli/: Command-line interface with Typer
- plugins/: Plugin system for extensions
"""
