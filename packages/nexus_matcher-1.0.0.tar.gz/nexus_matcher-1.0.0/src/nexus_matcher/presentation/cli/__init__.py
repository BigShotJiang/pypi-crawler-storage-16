"""
nexus_matcher.presentation.cli | Layer: PRESENTATION
Command-line interface for NexusMatcher.
"""

from nexus_matcher.presentation.cli.main import app, run

__all__ = ["app", "run"]
