"""
Nexus-VPN: 综合代理与 VPN 部署工具

一键部署 VLESS-Reality + IKEv2 VPN
"""

__version__ = "0.1.0"
__author__ = "Jerry"
