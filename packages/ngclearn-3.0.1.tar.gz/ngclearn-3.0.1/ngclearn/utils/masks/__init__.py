from .multiblock2d import MaskCollator
