# Example config files and imaging datasets

This directory contains a subdirectory of `.toml` config files that pair with the subdirectories of `imaging_datasets`.  Within each of the `imaging_datasets` subdirectories is also a `legacy_code` directory containing the `image_settings.txt` config file and output from running of the [legacy code](../legacy)  

For convenience, these examples are detailed here:

## NOVO imaging of a 14.8 MeV DT neutron source at PTB (ROOT DDAQ data format)

- Config file: [configs/novo_ptb.toml](configs/novo_ptb.toml)
- Dataset dir: [imaging_datasets/NOVO_experiment_DT_at_PTB](imaging_datasets/NOVO_experiment_DT_at_PTB)

## PHITS imaging of a neutron line source

- Config file: [configs/phits_usrdef_line.toml](configs/phits_usrdef_line.toml)
- Dataset dir: [imaging_datasets/PHITS_toy_line_source](imaging_datasets/PHITS_toy_line_source)

## PHITS imaging of a neutron + gamma combined source

- Config file: [configs/phits_usrdef_simple.toml](configs/phits_usrdef_simple.toml)
- Dataset dir: [imaging_datasets/PHITS_simple_ng_source](imaging_datasets/PHITS_simple_ng_source)

## PHITS imaging of a neutron ring source

- Config file: [configs/phits_usrdef_ring.toml](configs/phits_usrdef_ring.toml)
- Dataset dir: [imaging_datasets/PHITS_toy_ring_source](imaging_datasets/PHITS_toy_ring_source)

## PHITS imaging of a point gamma source

- Config file: [configs/phits_legacy_point_gammas.toml](configs/phits_legacy_point_gammas.toml)
- Dataset dir: [imaging_datasets/PHITS_point_gamma_source](imaging_datasets/PHITS_point_gamma_source)


