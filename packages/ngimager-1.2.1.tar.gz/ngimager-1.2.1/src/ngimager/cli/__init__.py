"""
Command-line interfaces (CLI) for ng-imager.

Currently exposed via:

- `ng-viz` → `ngimager.cli.viz:app`
- `ng-run` → `ngimager.pipelines.core:app`  (defined in the pipelines package)
"""
