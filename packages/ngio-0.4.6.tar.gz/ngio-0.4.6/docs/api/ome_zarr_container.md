# OmeZarrContainer: API Documentation

## Open an OME-Zarr Container

::: ngio.open_ome_zarr_container

## Create an OME-Zarr Container

::: ngio.create_empty_ome_zarr
::: ngio.create_ome_zarr_from_array

## OmeZarrContainer Class

::: ngio.OmeZarrContainer
