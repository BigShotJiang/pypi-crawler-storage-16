!!! warning
    The library is still in the early stages of development, no contribution guidelines are established yet.
    But contributions are welcome! Please open an issue or a pull request to discuss your ideas.
    We are looking for contributors to help us improve the library and documentation.
