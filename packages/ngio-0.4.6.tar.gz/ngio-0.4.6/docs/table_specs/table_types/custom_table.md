# Add a Custom Table

Ngio allows users to define custom tables that can be used to store any kind of tabular data. Custom tables are flexible and can be used to represent any kind of data that does not fit into the predefined table types.

!!! warning
    The library is still in the early stages and full documentation for custom tables is not yet available.
