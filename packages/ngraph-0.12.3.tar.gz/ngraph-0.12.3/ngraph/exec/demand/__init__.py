"""Demand manager subpackage.

This package contains helpers for building traffic matrices, expanding
specifications into concrete demands, and scheduling placement.
"""
