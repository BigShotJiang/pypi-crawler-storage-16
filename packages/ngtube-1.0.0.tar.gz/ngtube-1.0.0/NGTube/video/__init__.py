"""
NGTube Video Module
"""

from .video import Video