"""
NGTube Comments Module
"""

from .comments import Comments