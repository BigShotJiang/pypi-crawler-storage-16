"""
NGTube Shorts Module

This module provides functionality to extract shorts from YouTube.
"""

from .shorts import Shorts