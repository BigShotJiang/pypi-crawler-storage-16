import pandas as pd
import plotly.express as px
from pathlib import Path



BASE = Path(__file__).resolve().parent
CSV_PATH = BASE / "nhl_players_cleaned.csv"


df = pd.read_csv(CSV_PATH)


def get_player_stats(name: str, season=None, aggr=True):
    """
    Creates a dataframe for an NHL player's stats.
    """

    # Filter by player name
    player_df = df[df["Player"] == name].copy()

    if player_df.empty:
        return pd.DataFrame()

    # Normalize season input
    if season is None:
        season_list = None
    elif isinstance(season, list):
        season_list = season
    else:
        season_list = [season]

    # Filter by season(s)
    if season_list is not None:
        player_df = player_df[player_df["Season"].isin(season_list)]

    # Remove unnamed index column if it exists
    player_df = player_df.loc[:, ~player_df.columns.str.contains("^Unnamed")]

    # Move "Player" column to the front
    if "Player" in player_df.columns:
        cols = ["Player"] + [c for c in player_df.columns if c != "Player"]
        player_df = player_df[cols]

    if not aggr:
        return player_df

    # --- Aggregate block ---
    start_season = player_df["Season"].min()
    end_season   = player_df["Season"].max()
    seasons = f"{start_season}-{end_season}"

    player = player_df["Player"].iloc[0]

    # Unique-string helpers
    teams = ",".join(sorted(player_df["Team"].unique()))
    sc    = ",".join(sorted(player_df["S/C"].unique()))
    pos   = ",".join(sorted(player_df["Pos"].unique()))

    gp = player_df["GP"].sum()
    g  = player_df["G"].sum()
    a  = player_df["A"].sum()
    p  = player_df["P"].sum()

    plusminus = player_df["+/-"].sum()
    pim       = player_df["PIM"].sum()

    p_gp = p / gp if gp > 0 else None

    evg = player_df["EVG"].sum()
    evp = player_df["EVP"].sum()
    ppg = player_df["PPG"].sum()
    ppp = player_df["PPP"].sum()
    shg = player_df["SHG"].sum()
    shp = player_df["SHP"].sum()
    otg = player_df["OTG"].sum()
    gwg = player_df["GWG"].sum()

    s = player_df["S"].sum()
    sp = g / s if s > 0 else None

    TOI = player_df["TOI/GP"].mean()
    FOW = player_df["FOW%"].mean()

    # --- Build final one-row dataframe ---
    result = pd.DataFrame([{
        "Player": player,
        "Season(s)": seasons,
        "Team(s)": teams,
        "S/C": sc,
        "Position": pos,
        "GP": gp,
        "S": s,
        "G": g,
        "A": a,
        "P": p,
        "S%": sp,
        "+/-": plusminus,
        "PIM": pim,
        "P/GP": p_gp,
        "EVG": evg,
        "EVP": evp,
        "PPG": ppg,
        "PPP": ppp,
        "SHG": shg,
        "SHP": shp,
        "OTG": otg,
        "GWG": gwg,
        "TOI/GP": TOI,
        "FOW%": FOW
    }])

    return result

    

def get_roster_stats(team, season):
    """
    Returns the roster and stats of a team for a given season.

    Inputs:
        Team: Three letter abbreviation (as used on NHL.com)
        Season: Integer of the first year a season begins.
    """

    data = df.copy()
    data = data[data["Team"].str.contains(team, case=False, regex=False)]
    data = data[data["Season"] == season]

    # Remove unnamed index columns
    data = data.loc[:, ~data.columns.str.contains("^Unnamed")]

    # Move "Player" column to the front if it exists
    if "Player" in data.columns:
        cols = ["Player"] + [c for c in data.columns if c != "Player"]
        data = data[cols]

    return data


def score_plot(player, season=2024, metrics=["P", "G", "A"], df=df):
    """
    Plots a player's goals, assists, and points relative to the league averages.

    Other metrics can be included as a list in the metrics argument.

    Inputs:
        Player: Player name
        Season: Integer of the first year a season begins.
        Metrics: List containing any available metrics.
    """

    dfc = df[df["Season"]==season].copy()

    playerd = dfc[dfc["Player"]==player].copy()
    if playerd.empty:
        print("No data found for this player!")
        return
    
    league_avg = dfc[metrics].mean()

    plot_rows = []

    for m in metrics:
        plot_rows.append({"Metric": m, "Value": playerd.iloc[0][m], "Type": "Player"})
        plot_rows.append({"Metric": m, "Value": league_avg[m], "Type": "League Average"})

    plotdf = pd.DataFrame(plot_rows)

    fig = px.bar(
        plotdf,
        x="Metric",
        y="Value",
        color="Type",
        barmode="group",
        text="Value",
        title=f"{player} vs League Averages ({season})"
    )

    return fig


def score_scatter(player=None, season=None, team=None, metrics=["G", "A"], df=df):

    if season is not None:
        data = df[df["Season"]==season].copy()
    else:
        data = df.copy()
    def make_highlights(x, y):

        teams = [t.strip() for t in y.split(",")]

        if player is not None and team is not None and x == player and team in teams:
            return f"{player} / {team}"
        elif player is not None and x == player:
            return player
        elif team is not None and team in teams:
            return team
        else:
            return "Other"
        
    data["highlight"] = data.apply(
        lambda row: make_highlights(row["Player"], row["Team"]),
        axis=1
    )

    color_map = {}

    if player is not None:
        color_map[player] = "red"

    if team is not None:
        color_map[team] = "blue"

    if player is not None and team is not None:
        color_map[f"{player} / {team}"] = "purple"

    color_map["Other"] = "lightgray"

    if player is None and team is None:
        color_map["Other"] = "blue"


    min_size, max_size = 1, 15

    gp_min = data["GP"].min()
    gp_max = data["GP"].max()

    data["size"] = (
        (data["GP"] - gp_min) / (gp_max - gp_min) * (max_size - min_size) + min_size
    )

    fig = px.scatter(
        data, x=metrics[0], y=metrics[1],
        color="highlight", hover_name="Player",
        hover_data = ["Team", "G", "A", "P", "S/C", "Pos", "GP", "GWG", "S%"],
        title=f"NHL {metrics[0]} and {metrics[1]}",
        color_discrete_map=color_map,
        size= "size",
        size_max=max_size
    )
    return fig
