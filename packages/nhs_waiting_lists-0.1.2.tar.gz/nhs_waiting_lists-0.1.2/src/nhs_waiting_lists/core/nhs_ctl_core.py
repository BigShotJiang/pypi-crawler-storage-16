



# Shared core functionality
class NhsCtlCore:

    pass
