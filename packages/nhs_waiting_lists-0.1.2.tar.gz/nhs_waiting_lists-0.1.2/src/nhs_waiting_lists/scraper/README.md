# Scrapy based scraper

This directory contains the scrapy spiders and configuration.
