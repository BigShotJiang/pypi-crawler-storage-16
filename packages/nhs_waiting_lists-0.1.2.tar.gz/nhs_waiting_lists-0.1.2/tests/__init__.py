"""
Tests for the NHS waiting lists package.
"""
