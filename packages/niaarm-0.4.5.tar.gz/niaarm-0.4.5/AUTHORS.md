# Credits

## Main authors
- Žiga Stupan
- Iztok Fister, Jr.

## Maintainers
- Iztok Fister, Jr.

## Contributors (alphabetically)
- Ben Beasly
- Dušan Fister
- Erkan Karabulut
- Tadej Lahovnik