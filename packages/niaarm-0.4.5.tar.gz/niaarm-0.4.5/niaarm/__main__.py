import sys
from niaarm import cli


if __name__ == "__main__":
    sys.exit(cli.main())
