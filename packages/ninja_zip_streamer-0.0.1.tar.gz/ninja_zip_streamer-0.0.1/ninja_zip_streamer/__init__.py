"""Ninja zip streamer module."""

# flake8: noqa
from .core import extract