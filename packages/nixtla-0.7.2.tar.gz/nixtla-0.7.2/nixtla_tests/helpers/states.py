import uuid


class ModelIds:
    model_id1 = str(uuid.uuid4())
    model_id2 = None


model_ids_object = ModelIds()
