from nkv import NKVManager

nkv = NKVManager('testes', './tests')

# nkv.write('teste', ('teste', 123, 'sfkahkfdhfdnhs'))
print(nkv)