from pathlib import Path

from .engine import I18nAdapter
from .loaders import JSONFileLoader

translator = I18nAdapter(loader=JSONFileLoader(locales_path=Path(__file__).parent.joinpath("./locales").__str__()),
                         default_locale="fa")
