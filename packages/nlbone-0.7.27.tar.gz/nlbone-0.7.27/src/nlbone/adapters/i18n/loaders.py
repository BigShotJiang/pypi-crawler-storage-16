import json
import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict

logger = logging.getLogger(__name__)


class BaseLoader(ABC):
    @abstractmethod
    def load(self) -> Dict[str, Dict[str, str]]:
        pass


class JSONFileLoader(BaseLoader):
    def __init__(self, locales_path: str):
        self.locales_path = locales_path

    def load(self) -> Dict[str, Dict[str, str]]:
        translations: Dict[str, Dict[str, str]] = {}

        path_obj = Path(self.locales_path)

        if not path_obj.exists():
            logger.warning(f"Locales directory not found at: {self.locales_path}")
            return translations

        for file_path in path_obj.glob("*.json"):
            try:
                lang_code = file_path.stem

                with open(file_path, "r", encoding="utf-8") as f:
                    data = json.load(f)

                flat_data = self._flatten_dict(data)
                translations[lang_code] = flat_data

                logger.info(f"Loaded locale '{lang_code}' with {len(flat_data)} keys.")

            except json.JSONDecodeError as e:
                logger.error(f"Invalid JSON format in {file_path}: {e}")
            except Exception as e:
                logger.error(f"Error loading locale {file_path}: {e}")

        return translations

    def _flatten_dict(self, d: Dict[str, Any], parent_key: str = "", sep: str = ".") -> Dict[str, str]:
        items = []
        for k, v in d.items():
            new_key = f"{parent_key}{sep}{k}" if parent_key else k

            if isinstance(v, dict):
                items.extend(self._flatten_dict(v, new_key, sep=sep).items())
            else:
                items.append((new_key, str(v)))

        return dict(items)
