from typing import Dict, Optional

from nlbone.core.ports.translation import TranslationPort
from nlbone.utils.context import get_locale

from .loaders import BaseLoader


class I18nAdapter(TranslationPort):
    def __init__(self, loader: BaseLoader, default_locale: str = "fa"):
        self.default_locale = default_locale
        self._translations: Dict[str, Dict[str, str]] = loader.load()

    def translate(self, key: str, locale: Optional[str] = None, **kwargs) -> str:
        target_locale = locale or get_locale() or self.default_locale

        locale_data = self._translations.get(target_locale, {})
        text = locale_data.get(key)

        if text is None:
            text = self._translations.get(self.default_locale, {}).get(key, key)

        if kwargs:
            try:
                return text.format(**kwargs)
            except KeyError:
                pass
        return text
