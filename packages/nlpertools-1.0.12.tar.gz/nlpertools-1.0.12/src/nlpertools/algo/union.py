#!/usr/bin/python3.8
# -*- coding: utf-8 -*-
# @Author  : youshu.Ji
class UnionFind():
    def __init__(self, num):
        self.parent = list(range(num))

    def union(self):
        pass

    def find(self, index):
        if 1:
            pass
