#!/usr/bin/python3.8
# -*- coding: utf-8 -*-
# @Author  : youshu.Ji
import os
from pathlib import Path
from typing import overload, Literal, Union


# dir ----------------------------------------------------------------------
def j_mkdir(name):
    os.makedirs(name, exist_ok=True)


def j_walk(name, suffix=None):
    paths = []
    for root, dirs, files in os.walk(name):
        for file in files:
            path = os.path.join(root, file)
            if not (suffix and not path.endswith(suffix)):
                paths.append(path)
    return paths


def windows_to_wsl_path(windows_path):
    # 转换驱动器号
    if windows_path[1:3] == ":\\":
        drive_letter = windows_path[0].lower()
        path = windows_path[2:].replace("\\", "/")
        wsl_path = f"/mnt/{drive_letter}{path}"
    else:
        # 如果路径不是以驱动器号开头，则直接替换路径分隔符
        wsl_path = windows_path.replace("\\", "/").replace("'", "'")

    return wsl_path


def get_filename(path, suffix=True) -> str:
    """
    返回路径最后的文件名
    :param path:
    :return:
    """
    # path = r'***/**/***.txt'
    filename = os.path.split(path)[-1]
    if not suffix:
        filename = filename.split(".")[0]
    return filename


"""
因为os.listdir无法支持Path类型，虽然是bytelikepath,但是传入Path后只会返回字符串
且无法只返回文件名
故重新实现
"""


@overload
def listdir(dir_name: Path, including_dir: Literal[True]) -> list[Path]: ...
@overload
def listdir(dir_name: str, including_dir: Literal[True]) -> list[str]: ...
@overload
def listdir(dir_name: Path, including_dir: Literal[False] = False) -> list[str]: ...
@overload
def listdir(dir_name: str, including_dir: Literal[False] = False) -> list[str]: ...


def listdir(dir_name: Union[Path, str], including_dir: bool = False) -> list[Path] | list[str]:
    """
    including_dir=True -> list[Path] or list[str]
    including_dir=False -> list[str]
    """
    filenames = os.listdir(str(dir_name))
    match (including_dir, isinstance(dir_name, Path)):
        case (True, True):
            return [dir_name / filename for filename in filenames]
        case (True, False):
            return [os.path.join(dir_name, filename) for filename in filenames]
        case (False, True):
            return [Path(filename) for filename in filenames]
        case (False, False):
            return filenames


def listdir_yield(dir_name, including_dir=True):
    filenames = os.listdir(dir_name)
    for filename in filenames:
        if including_dir:
            yield os.path.join(dir_name, filename)
        else:
            yield filename


# 合并文件 TODO 还没写
def imgrate_files(path):
    filenames = os.listdir(path)
    return None


def case_sensitive_path_exists(path: str, relative_path=False):
    """
    https://juejin.cn/post/7316725867086692391
    Check if the path exists in a case-sensitive manner.
    """
    # 构造成Path
    if relative_path:
        path = Path.cwd() / path
    else:
        path = Path(path)
    if not path.exists():
        return False
    # resolved_path是系统里的该文件实际名称
    resolved_path = path.resolve()
    return str(resolved_path) == str(path)
