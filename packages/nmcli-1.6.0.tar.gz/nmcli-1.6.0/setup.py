#!/usr/bin/env python3
# This file is kept for backwards compatibility.
# All configuration is now in pyproject.toml
from setuptools import setup

setup()
