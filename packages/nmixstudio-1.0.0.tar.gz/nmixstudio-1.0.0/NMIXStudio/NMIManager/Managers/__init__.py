from .DeviceManager import NMIDevice
