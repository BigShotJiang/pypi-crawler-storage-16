from NMIXStudio import NMICommand,NMIEndpoint,NMIDevice
from NMIXStudio.Plots.ContainerPlot.ContainerPlotManager import ContainerPlotManager
from NMIXStudio.Container.NmiContainer.container import NMIContainer
from NMIXStudio.Container.NmiContainer.enums import*
from NMIXStudio.Container.NmiFrame.frameChannels import FrameChannels
from NMIXStudio.Container.NmiFrame.frame import NMIFrame
from NMIXStudio.ExternalDevices.Devices.utils import ExternalScanDevice
from NMIXStudio.ExternalDevices.Devices.Thorlabs_SPCM50 import*
from NMIXStudio.NMIManager.Managers.CustomScanner import CustomScanner

from NMIXStudio.ExternalDevices.Devices.externalTest import ExternalTest
from NMIXStudio import help

help()

Endpoint = NMIEndpoint("192.168.10.53",9024)
Device = NMIDevice(Endpoint)
Device.XYOFFSET().Start_GuiOffsetUpdater()

device2 = ExternalTest()

spcm_model = SPCM50ControlModel()
# Ayarları yükle (Örnek: varsayılanı kullan)
spcm_model.load_settings()
# Cihazı başlat
if spcm_model.initialize():
        # Ölçüm ile ilgili ön hazırlıkları yap
    if spcm_model.measurement_init():
        spcm_model.set_operating_mode(SPCM50_OPERATINGMODES.FreeRunning)
        
        spcm_model.average_count = 10
        spcm_model.set_bin_length(20)
        spcm_model.set_time_between(10)

        _ScanManager = CustomScanner(Device)

        ChannelList = [
            FrameChannels.Channel_Vz,
            FrameChannels.Channel_ITunnel,
            FrameChannels.Channel_Rms2,
        ]

        _ScanManager.InitScan(5,5,3,3,channelList=ChannelList,xOffset=0,yOffset=0)
        _ScanManager.AddExternalScanDevice(FrameChannels.Channel_Custom1,spcm_model)
        _ScanManager.AddExternalScanDevice(FrameChannels.Channel_Custom2,device2,128)
        _ScanManager.StartScan()

        Container = _ScanManager.GetScanContainer()

        Container.Save("sampleContainer2.json")

        ContainerPlotManager().plot8BitColorMapFromImage(Container.GetImageFromChannel(FrameChannels.Channel_Vz))
        ContainerPlotManager().plot8BitColorMapFromImage(Container.GetImageFromChannel(FrameChannels.Channel_ITunnel))
        ContainerPlotManager().plot8BitColorMapFromImage(Container.GetImageFromChannel(FrameChannels.Channel_Rms2))

        ContainerPlotManager().plot8BitColorMapFromImage(Container.GetImageFromChannel(FrameChannels.Channel_Custom1))
        ContainerPlotManager().plot16BitColorMapFromImage(Container.GetImageFromChannel(FrameChannels.Channel_Custom1))
        ContainerPlotManager().plot16BitRawMapFromImage(Container.GetImageFromChannel(FrameChannels.Channel_Custom1))