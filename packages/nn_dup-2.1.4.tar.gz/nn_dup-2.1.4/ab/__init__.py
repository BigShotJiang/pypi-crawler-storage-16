"""
This is a namespace package that extends the 'ab' namespace.
It coexists with ab.nn from the nn-dataset package.
"""
__path__ = __import__('pkgutil').extend_path(__path__, __name__)

