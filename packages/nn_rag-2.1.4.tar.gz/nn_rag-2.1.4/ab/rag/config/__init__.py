"""
Configuration for the PyTorch Block Extractor
"""
