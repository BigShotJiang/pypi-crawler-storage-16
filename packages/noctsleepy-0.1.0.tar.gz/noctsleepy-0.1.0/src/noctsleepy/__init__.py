""".. include:: ../../README.md"""  # noqa: D415

from noctsleepy.main import compute_sleep_metrics

__all__ = ["compute_sleep_metrics"]
