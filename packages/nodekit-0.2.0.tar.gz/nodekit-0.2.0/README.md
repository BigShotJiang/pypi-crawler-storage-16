# NodeKit

**NodeKit** is a modern, type-safe framework for browser-ready behavioral experiments. 

The framework is currently in alpha stage, and public APIs should be considered experimental and subject to change without notice. 