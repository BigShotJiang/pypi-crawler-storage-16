from .dmm import DirichletMultinomialMixture
from .tmm import CauchyMixture, StudentsTMixture
