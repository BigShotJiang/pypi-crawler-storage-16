"""
Custom exception classes for the Nomad SDK.
"""

class InvalidAPITypeException(Exception):
    """
    This class is used to throw an exception when the API type is invalid.
    """
    def __init__(self, message) -> None:
        self.message: str = message
        super().__init__(self.message)

class MissingCredentialsException(Exception):
    """
    This class is used to throw an exception when the login info is missing.
    """
    def __init__(self, credentials=None, message="Missing login credentials") -> None:
        if credentials:
            message = f"{message}: {', '.join(credentials)}"
        self.message: str = message
        self.credentials = credentials
        super().__init__(self.message)

class LoginException(Exception):
    """
    This class is used to throw an exception when the login info is incorrect.
    """
    def __init__(self, message="Login info incorrect") -> None:
        self.message: str = message
        super().__init__(self.message)
