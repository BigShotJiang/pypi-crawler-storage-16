from .netbox_models import (
    CreatePrefixInput,
    NetboxCommonArgs,
    NetboxFastApiArgs,
)
