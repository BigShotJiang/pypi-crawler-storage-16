from . import databaseds

databaseds.main()
