from typing import Any, Type
from typing import TypeVar

import httpx
from pydantic import BaseModel

__all__ = ["NotchPayBaseResource", "AsyncNotchPayBaseResource"]

T = TypeVar('T', bound=BaseModel)


class NotchPayBaseResource:
    def __init__(self, client: httpx.Client):
        self.client = client

    def _request(self, method: str, url: str, response_model: Type[T], **kwargs: Any) -> T:
        response = self.client.request(method, url, **kwargs)
        return response_model.model_validate(response.json(), extra='ignore')


class AsyncNotchPayBaseResource:
    def __init__(self, client: httpx.AsyncClient):
        self.client = client

    async def _request(self, method: str, url: str, response_model: Type[T], **kwargs: Any) -> T:
        response = await self.client.request(method, url, **kwargs)
        return response_model.model_validate(response.json(), extra='ignore')
