from typing import Optional

__all__ = [
    "NotchPayError",
    "NotchPayAPIError",
    "NotchPayAuthenticationError",
    "NotchPayValidationError",
]


class NotchPayError(Exception):
    pass


class NotchPayAPIError(NotchPayError):

    def __init__(self, *args: str, code: Optional[str] = None, status: Optional[str] = None,
                 message: Optional[str] = None):
        self.code = code
        self.status = status
        self.message = message
        super().__init__(*args)


class NotchPayAuthenticationError(NotchPayAPIError):
    pass


class NotchPayValidationError(NotchPayAPIError):

    def __init__(self, *args: str, errors: Optional[dict[str, list[str]]] = None, **kwargs: str):
        super().__init__(*args, **kwargs)
        self.errors = errors if errors is not None else {}
