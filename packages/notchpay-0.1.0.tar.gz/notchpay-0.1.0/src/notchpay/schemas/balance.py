from typing import Literal

from pydantic import BaseModel, Field

from .base import NotchPayResponse

__all__ = [
    "NotchPayBalance",
    "NotchPayBalanceResponse",
]


class NotchPayBalance(BaseModel):
    """Model representing a NotchPay account balance.

    Attributes:
        reserved: Reserved amount.
        total: Total amount.
        pending: Pending amount.
        credit: Credit amount.
        available: Available amount.
        currency: Balance currency (XAF, etc.).
        environment: Environment (sandbox or live).
    """

    reserved: int = Field(..., description="Reserved amount")
    total: int = Field(..., description="Total amount")
    pending: int = Field(..., description="Pending amount")
    credit: int = Field(..., description="Credit amount")
    available: int = Field(..., description="Available amount")
    currency: str = Field(..., description="Balance currency")
    environment: Literal["sandbox", "live"] = Field(..., description="Environment")


class NotchPayBalanceResponse(NotchPayResponse):
    """Balance retrieval response."""

    balance: NotchPayBalance = Field(..., description="Balance details")
