from typing import Awaitable, Generic, List, TypeVar, Optional, Dict, Union

from pydantic import BaseModel, Field

__all__ = [
    "NotchPayResponse",
    "NotchPayResponseList",
    "NotchPayErrorResponse",
    "MaybeAwaitable",
    "NotchPayPaginatedResponse"
]


class NotchPayResponse(BaseModel):
    """Base response properties shared across all NotchPay responses"""

    status: str = Field(..., description="Response status")
    message: str = Field('', description="Response message")
    code: int = Field(..., description="HTTP status code")


T = TypeVar('T')

MaybeAwaitable = Union[T, Awaitable[T]]


class NotchPayPaginatedResponse(NotchPayResponse):
    """Base model for paginated responses"""
    totals: Optional[int] = Field(None, description="The total number of items in the collection")
    last_page: Optional[int] = Field(None, description="The last page of the collection")
    current_page: Optional[int] = Field(None, description="The number of items per page")
    selected: Optional[int] = Field(None, description="The number of items on the current page")


class NotchPayResponseList(NotchPayPaginatedResponse, Generic[T]):
    """Collection response with pagination"""

    items: List[T] = Field(..., description="List of items")


class NotchPayErrorResponse(NotchPayResponse):
    errors: Optional[Dict[str, List[str]]] = Field(None, description="Errors")
