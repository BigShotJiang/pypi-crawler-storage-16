from enum import Enum
from typing import Optional, List, Literal

from pydantic import BaseModel, Field

__all__ = ["NotchPayChannel", "NotchPayChannels"]


class NotchPayChannel(BaseModel):
    """Model representing a NotchPay payment channel."""

    name: str = Field(..., description="Payment channel name")
    desc: str = Field(..., description="Channel description")
    active: bool = Field(..., description="Indicates if the channel is active")
    countries: List[str] = Field(..., description="List of supported country codes")
    id: str = Field(..., description="Unique channel identifier")
    slug: str = Field(..., description="Channel slug")
    type: Literal["card", "wallet", "mobile", "bank"] = Field(..., description="Channel type")
    reference: str = Field(..., description="Channel reference")
    delivery: Optional[int] = Field(None, description="Delivery delay")
    payment_delivery: Optional[int] = Field(None, description="Payment delivery delay")
    live: bool = Field(..., description="Indicates if the channel is in live mode")
    min_amount: Optional[int] = Field(None, description="Minimum amount")
    max_amount: Optional[int] = Field(None, description="Maximum amount")
    payout: int = Field(..., description="Payout indicator")
    charge: int = Field(..., description="Fee indicator")
    collect: int = Field(..., description="Indicateur de collecte")
    currency: str = Field(..., description="Code de la devise")


class NotchPayChannels(str, Enum):
    """Payment channels"""
    CARD = "card"
    PAYPAL = "paypal"
    CM_MTN = "cm.mtn"
    CM_ORANGE = "cm.orange"
    CM_MOBILE = "cm.mobile"
    EUMM = "eumm"
    YOOMEE = "yoomee"
    BANK = "bank"
    KE_MPESA = "ke.mpesa"
    KE_AIRTEL = "ke.airtel"
    KE_EQUITEL = "ke.equitel"
    KE_TKASH = "ke.tkash"
    CI_MTN = "ci.mtn"
    CI_ORANGE = "ci.orange"
    CI_MOOV = "ci.moov"
    CI_WAVE = "ci.wave"
    CI_GREEN = "ci.green"
    NG_MTN = "ng.mtn"
    NG_ORANGE = "ng.orange"
    SN_ORANGE = "sn.orange"
    SN_FREE = "sn.free"
    BJ_MTN = "bj.mtn"
    BJ_MOOV = "bj.moov"
    BJ_GLO = "bj.glo"
    BF_ORANGE = "bf.orange"
    BF_MOOV = "bf.moov"
    GH_MTN = "gh.mtn"
    GH_VODAFONE = "gh.vodafone"
    GH_AIRTEL = "gh.airtel"
    GH_AIRTELTIGO = "gh.airteltigo"
    CD_AIRTEL = "cd.airtel"
    CD_ORANGE = "cd.orange"
    CD_VODACOM = "cd.vodacom"
    UG_MTN = "ug.mtn"
    UG_AIRTEL = "ug.airtel"
    RW_MTN = "rw.mtn"
    RW_AIRTEL = "rw.airtel"
    TZ_AIRTEL = "tz.airtel"
    TZ_TIGO = "tz.tigo"
    TZ_VODAFONE = "tz.vodafone"
    TZ_HALOPESA = "tz.halopesa"
