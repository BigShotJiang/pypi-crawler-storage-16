
Resources: Embedding Tcl in C
-----------------------------

* http://www.beedub.com/book/3rd/Cprogint.pdf
* https://wiki.tcl-lang.org/page/Building+a+custom+tclsh
* https://wiki.tcl-lang.org/page/Tcl%5FObj+refCount+HOWTO

Custom handles:

* https://wiki.tcl-lang.org/page/Tcl+Handles