// SPDX-FileCopyrightText: 2024 Tobias Kaiser <mail@tb-kaiser.de>
// SPDX-License-Identifier: Apache-2.0

int cmd_infinite_loop(ClientData cd, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]);