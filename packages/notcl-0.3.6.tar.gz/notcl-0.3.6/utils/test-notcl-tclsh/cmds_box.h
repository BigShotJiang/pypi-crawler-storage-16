// SPDX-FileCopyrightText: 2024 Tobias Kaiser <mail@tb-kaiser.de>
// SPDX-License-Identifier: Apache-2.0

int cmd_create_box(ClientData cd, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]);
int cmd_unwrap_box(ClientData cd, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]);