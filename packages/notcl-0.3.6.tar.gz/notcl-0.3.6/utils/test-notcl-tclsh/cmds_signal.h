// SPDX-FileCopyrightText: 2024 Tobias Kaiser <mail@tb-kaiser.de>
// SPDX-License-Identifier: Apache-2.0

int cmd_ignore_sigint(ClientData cd, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]);
int cmd_reset_sigint(ClientData cd, Tcl_Interp *interp, int objc, Tcl_Obj *CONST objv[]);