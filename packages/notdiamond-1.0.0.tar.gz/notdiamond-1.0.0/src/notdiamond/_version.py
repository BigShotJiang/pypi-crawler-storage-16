# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "notdiamond"
__version__ = "1.0.0"  # x-release-please-version
