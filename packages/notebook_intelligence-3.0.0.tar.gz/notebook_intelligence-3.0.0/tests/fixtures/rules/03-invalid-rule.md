---
apply: invalid_mode
scope:
  file_patterns:
    - '*.txt'
active: not_a_boolean
---

# Invalid Rule for Testing

This rule has invalid YAML frontmatter for testing error handling.
