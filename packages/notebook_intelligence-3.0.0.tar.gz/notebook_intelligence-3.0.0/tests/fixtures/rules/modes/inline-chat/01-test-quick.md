---
apply: auto
scope:
  file_patterns:
    - '*.ipynb'
    - '*.py'
active: true
---

# Quick Help Guidelines

- Provide concise, actionable suggestions
- Focus on immediate solutions
- Keep explanations brief but clear
