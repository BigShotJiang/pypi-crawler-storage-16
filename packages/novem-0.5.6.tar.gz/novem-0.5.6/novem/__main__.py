from .cli import run_cli

# Run with command line arguments when called directly
# (rather than when imported)
if __name__ == "__main__":
    run_cli()
