from novem.table.selector import Selector

__all__ = ["Selector"]
