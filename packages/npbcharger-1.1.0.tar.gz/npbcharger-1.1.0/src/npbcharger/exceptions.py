class NPBCommunicationError(Exception):
    """
    Exception which handles loss of communication with NPB-1700
    """
    pass
