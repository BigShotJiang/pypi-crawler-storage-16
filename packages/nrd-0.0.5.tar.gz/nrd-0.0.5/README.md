# nrd

run `npm run dev` in background for all your laravel herd sites

