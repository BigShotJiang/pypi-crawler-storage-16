# -*- coding: utf-8 -*-
"""
reVX Configuration
"""
