# -*- coding: utf-8 -*-
"""
PLEXOS generation profile aggregation pipeline.
"""
