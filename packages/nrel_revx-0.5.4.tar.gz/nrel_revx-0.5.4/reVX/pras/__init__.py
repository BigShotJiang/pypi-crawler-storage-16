# -*- coding: utf-8 -*-
"""
PRAS generation profile aggregation pipeline
"""
