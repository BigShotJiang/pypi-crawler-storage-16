# -*- coding: utf-8 -*-
"""
Shadow Flicker exclusions calculator
"""
