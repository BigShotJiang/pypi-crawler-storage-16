# -*- coding: utf-8 -*-
"""
reVX version number
"""

__version__ = "0.5.4"
