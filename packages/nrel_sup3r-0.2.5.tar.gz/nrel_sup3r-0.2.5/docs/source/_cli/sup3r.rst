.. click:: sup3r.cli:main
   :prog: sup3r
   :show-nested:
