Installation
============

.. include:: ../../../README.rst
   :start-after: Installing sup3r
   :end-before: Recommended Citation
