"""Sup3r data pipeline architecture."""
