"""Basic Cacher container."""

from .base import Cacher
