"""Classes consisting of collections of containers."""

from .base import Collection
from .stats import StatsCollection
