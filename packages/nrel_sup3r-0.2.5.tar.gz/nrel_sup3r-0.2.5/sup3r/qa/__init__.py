"""sup3r QA module."""
