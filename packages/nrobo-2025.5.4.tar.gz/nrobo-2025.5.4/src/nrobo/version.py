__version__ = "2025.5.4"  # noqa: W292
