# Entidades base da Integração
_entidades_base = [
    'ns.gruposempresariais',
    'ns.empresas',
    'ns.estabelecimentos',
]

