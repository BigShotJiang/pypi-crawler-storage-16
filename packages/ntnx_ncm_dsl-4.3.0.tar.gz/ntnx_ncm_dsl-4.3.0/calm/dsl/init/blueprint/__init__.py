from .render import init_bp

__all__ = ["init_bp"]
