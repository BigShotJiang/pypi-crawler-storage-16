#!/bin/bash

set -ex

echo "Package installation steps go here ..."
