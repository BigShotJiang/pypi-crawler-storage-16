# Dummy script to verify credentials of custom provider accounts

print("Account credentials being validated:")
print("Username: @@{username}@@, Password: @@{password}@@")
print("Making a dummy request to authenticate to the below provider endpoint")
print("Server IP: @@{server_ip}@@, Port: @@{port_number}@@")
