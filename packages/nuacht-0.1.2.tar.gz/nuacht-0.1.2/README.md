Must create a `feeds.rss` file, with rss links separated by newlines.
