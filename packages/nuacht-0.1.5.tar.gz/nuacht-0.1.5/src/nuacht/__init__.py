from .nuacht import insert_into_database

__all__ = ['insert_into_database']
