# SPDX-FileCopyrightText: Copyright (c) 2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

from numbast.tools.static_binding_generator import static_binding_generator

if __name__ == "__main__":
    static_binding_generator()
