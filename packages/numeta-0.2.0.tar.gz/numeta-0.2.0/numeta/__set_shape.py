from .array_shape import ArrayShape


def __set_shape(variable, shape):
    if not isinstance(shape, ArrayShape):
        __shape = ArrayShape(shape, fortran_order=variable._shape.fortran_order)
    else:
        __shape = shape
    variable.__shape = shape
