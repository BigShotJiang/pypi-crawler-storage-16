def assume_shape(variable, shape):
    variable.dimension = shape
