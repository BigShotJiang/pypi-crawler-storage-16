from .iso_c_binding import iso_c
from .omp import omp
