from typing import TypeAlias, Any

# Type used to annotate compile-time variables
type comptime = Any
