import numeta as nm


@nm.jit(compile_flags="-Ofast -march=native")
def searchsorted(a, v, side: nm.comptime = "left"):

    if side == "left":
        n = a.shape[0]
        idx = nm.empty(v.shape[0], dtype=nm.int64)
        idx[:] = n
        lo, hi = nm.int64(0), nm.int64(n)
        mid = nm.int64(0)
        for j in nm.range(v.shape[0]):
            lo[:] = 0
            hi[:] = n
            with nm.DoWhile(lo < hi):
                mid[:] = (lo + hi) // 2
                with nm.If(a[mid] < v[j]):
                    lo[:] = mid + 1
                with nm.Else():
                    hi[:] = mid
            idx[j] = lo
        return idx
    elif side == "right":
        n = a.shape[0]
        idx = nm.int64(n)
        for i in nm.range(n):
            with nm.If(a[i] > v):
                idx[:] = i
                nm.Exit()
        return idx
