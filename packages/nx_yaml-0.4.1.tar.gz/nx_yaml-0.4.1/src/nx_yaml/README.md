# JSON Schema

The JSON Schema of a YAML Nodes describes the graph representation of YAML. It allows encoding higher level YAML content in JSON. This is not about JSON as a YAML subset, but about supporting roundtrip YAML<->JSON.
