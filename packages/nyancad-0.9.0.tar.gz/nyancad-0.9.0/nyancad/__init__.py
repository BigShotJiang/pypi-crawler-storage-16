"""
NyanCAD Python Library

A Python library for the NyanCAD schematic editor with anywidget integration.
Provides live access to schematic data from marimo notebooks.
"""

__version__ = "0.1.0"
__all__ = []
