from enum import Enum


class GroupByOptions(str, Enum):
    REQUESTS = "Requests"
    SKUS = "SKUs"




