from datetime import datetime
from pydantic import BaseModel, ConfigDict
from pydantic.alias_generators import to_camel


class Version(BaseModel):
    """
    Version class returned from the registry API
    """

    model_config = ConfigDict(alias_generator=to_camel)

    #: Version number
    version: int

    #: Event Timestamp
    event_timestamp: datetime | None = None

    #: Datetime when the version was created
    version_creation_timestamp: datetime

    #: Citation referring to the item version
    citation: str
