def main():
    print("Hello from oai-wrapper!")


if __name__ == "__main__":
    main()
