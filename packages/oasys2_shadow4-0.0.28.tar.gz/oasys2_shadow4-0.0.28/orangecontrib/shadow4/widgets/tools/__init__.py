"""
Sources
"""

NAME = "Shadow4 \u23F5 Tools"

DESCRIPTION = "Tools."

BACKGROUND = "#b9d47a"

ICON = "icons/utility.png"

PRIORITY = 4.3