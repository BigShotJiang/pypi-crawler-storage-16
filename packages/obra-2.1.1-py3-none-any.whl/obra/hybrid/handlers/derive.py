"""Derive handler for Hybrid Orchestrator.

This module handles the DERIVE action from the server. It takes an objective
and derives an implementation plan using the local LLM invocation.

The derivation process:
    1. Receive DeriveRequest with objective and context
    2. Gather local project context (files, structure, etc.)
    3. Invoke LLM to generate plan
    4. Parse structured output into plan items
    5. Return DerivedPlan to report to server

Related:
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md Section 1
    - obra/api/protocol.py
    - obra/hybrid/orchestrator.py
"""

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from obra.api.protocol import DeriveRequest
from obra.display import console, print_info

logger = logging.getLogger(__name__)


class DeriveHandler:
    """Handler for DERIVE action.

    Derives an implementation plan from the objective using LLM.
    The plan is structured as a list of plan items (tasks/stories).

    Example:
        >>> handler = DeriveHandler(Path("/path/to/project"))
        >>> request = DeriveRequest(objective="Add user authentication")
        >>> result = handler.handle(request)
        >>> print(result["plan_items"])
    """

    def __init__(self, working_dir: Path) -> None:
        """Initialize DeriveHandler.

        Args:
            working_dir: Working directory for file access
        """
        self._working_dir = working_dir

    def handle(self, request: DeriveRequest) -> Dict[str, Any]:
        """Handle DERIVE action.

        Args:
            request: DeriveRequest from server

        Returns:
            Dict with plan_items and raw_response
        """
        logger.info(f"Deriving plan for: {request.objective[:50]}...")
        print_info(f"Deriving plan for: {request.objective[:50]}...")

        # Gather context for derivation
        context = self._gather_context(request)

        # Generate derivation prompt
        prompt = self._build_prompt(request, context)

        # Invoke LLM
        raw_response = self._invoke_llm(prompt, request.llm_provider)

        # Parse response into plan items
        plan_items = self._parse_plan(raw_response)

        logger.info(f"Derived {len(plan_items)} plan items")
        print_info(f"Derived {len(plan_items)} plan items")

        return {
            "plan_items": plan_items,
            "raw_response": raw_response,
        }

    def _gather_context(self, request: DeriveRequest) -> Dict[str, Any]:
        """Gather local context for derivation.

        Args:
            request: DeriveRequest with project context

        Returns:
            Enhanced context dictionary
        """
        context = dict(request.project_context)

        # Add file structure summary (no content)
        try:
            structure = self._summarize_structure()
            context["file_structure"] = structure
        except Exception as e:
            logger.warning(f"Failed to gather file structure: {e}")

        # Add README if exists
        readme_path = self._working_dir / "README.md"
        if readme_path.exists():
            try:
                content = readme_path.read_text(encoding="utf-8")
                # Truncate to first 2000 chars
                context["readme"] = content[:2000] + ("..." if len(content) > 2000 else "")
            except Exception:
                pass

        return context

    def _summarize_structure(self) -> List[str]:
        """Summarize project file structure.

        Returns:
            List of important file paths (no content)
        """
        important_files = []
        important_patterns = [
            "*.py",
            "*.js",
            "*.ts",
            "*.tsx",
            "*.jsx",
            "package.json",
            "pyproject.toml",
            "requirements.txt",
            "Cargo.toml",
            "go.mod",
            "README.md",
            "Makefile",
            "Dockerfile",
        ]

        # Collect files (limit to prevent overwhelming context)
        max_files = 50
        skip_dirs = {".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build"}

        for pattern in important_patterns:
            for path in self._working_dir.rglob(pattern):
                # Skip ignored directories
                if any(skip_dir in path.parts for skip_dir in skip_dirs):
                    continue

                # Get relative path
                try:
                    rel_path = path.relative_to(self._working_dir)
                    important_files.append(str(rel_path))
                except ValueError:
                    continue

                if len(important_files) >= max_files:
                    break

            if len(important_files) >= max_files:
                break

        return sorted(important_files)[:max_files]

    def _build_prompt(self, request: DeriveRequest, context: Dict[str, Any]) -> str:
        """Build derivation prompt.

        Args:
            request: DeriveRequest
            context: Enhanced context

        Returns:
            Prompt string for LLM
        """
        # Build context section
        context_parts = []

        if context.get("languages"):
            context_parts.append(f"Languages: {', '.join(context['languages'])}")

        if context.get("frameworks"):
            context_parts.append(f"Frameworks: {', '.join(context['frameworks'])}")

        if context.get("file_structure"):
            files = context["file_structure"][:20]  # Limit displayed files
            context_parts.append(f"Key files: {', '.join(files)}")

        if context.get("readme"):
            context_parts.append(f"README excerpt:\n{context['readme'][:500]}")

        context_section = "\n".join(context_parts) if context_parts else "No project context available."

        # Build constraints section
        constraints = request.constraints
        constraints_section = ""
        if constraints:
            if constraints.get("max_items"):
                constraints_section += f"- Maximum {constraints['max_items']} plan items\n"
            if constraints.get("scope_boundaries"):
                constraints_section += f"- Scope boundaries: {', '.join(constraints['scope_boundaries'])}\n"

        prompt = f"""You are an expert software architect. Derive an implementation plan for the following objective.

## Objective
{request.objective}

## Project Context
{context_section}

{f"## Constraints{chr(10)}{constraints_section}" if constraints_section else ""}

## Instructions
Create a structured implementation plan with the following requirements:
1. Break the objective into logical tasks/stories
2. Each item should be independently testable
3. Order items by dependencies (items that must be done first come first)
4. Be specific about what each item accomplishes
5. Include acceptance criteria for each item

## Output Format
Return a JSON object with a "plan_items" array. Each item should have:
- id: Unique identifier (e.g., "T1", "T2")
- item_type: "task" or "story"
- title: Brief title
- description: Detailed description
- acceptance_criteria: Array of criteria strings
- dependencies: Array of item IDs this depends on

Example:
```json
{{
  "plan_items": [
    {{
      "id": "T1",
      "item_type": "task",
      "title": "Create database models",
      "description": "Define SQLAlchemy models for User and Session",
      "acceptance_criteria": ["User model has email, password_hash fields", "Session model links to User"],
      "dependencies": []
    }},
    {{
      "id": "T2",
      "item_type": "task",
      "title": "Implement login endpoint",
      "description": "Create POST /login endpoint that validates credentials",
      "acceptance_criteria": ["Endpoint returns JWT on valid credentials", "Returns 401 on invalid"],
      "dependencies": ["T1"]
    }}
  ]
}}
```

Return ONLY the JSON object, no additional text.
"""
        return prompt

    def _invoke_llm(self, prompt: str, provider: str) -> str:
        """Invoke LLM to generate plan.

        Args:
            prompt: Derivation prompt
            provider: LLM provider name

        Returns:
            Raw LLM response
        """
        # TODO: Implement actual LLM invocation via obra/llm module
        # For now, return a placeholder response for testing
        logger.debug(f"Invoking LLM provider: {provider}")

        # Placeholder: In production, this would call the LLM
        # For S7a we create the structure, LLM invocation is S8
        placeholder_response = json.dumps({
            "plan_items": [
                {
                    "id": "T1",
                    "item_type": "task",
                    "title": "Placeholder task",
                    "description": "This is a placeholder - LLM invocation will be implemented in S8",
                    "acceptance_criteria": ["LLM invocation implemented"],
                    "dependencies": [],
                }
            ]
        })

        return placeholder_response

    def _parse_plan(self, raw_response: str) -> List[Dict[str, Any]]:
        """Parse LLM response into plan items.

        Args:
            raw_response: Raw LLM response

        Returns:
            List of plan item dictionaries
        """
        try:
            # Try to extract JSON from response
            # Handle case where response might have markdown code blocks
            response = raw_response.strip()

            if response.startswith("```"):
                # Extract from code block
                lines = response.split("\n")
                start = 1 if lines[0].startswith("```") else 0
                end = len(lines) - 1 if lines[-1] == "```" else len(lines)
                response = "\n".join(lines[start:end])

            # Parse JSON
            data = json.loads(response)

            # Extract plan_items
            if isinstance(data, dict) and "plan_items" in data:
                items = data["plan_items"]
            elif isinstance(data, list):
                items = data
            else:
                logger.warning("Unexpected response format, wrapping as single item")
                items = [data]

            # Validate and normalize items
            normalized = []
            for i, item in enumerate(items):
                normalized_item = {
                    "id": item.get("id", f"T{i + 1}"),
                    "item_type": item.get("item_type", "task"),
                    "title": item.get("title", "Untitled"),
                    "description": item.get("description", ""),
                    "acceptance_criteria": item.get("acceptance_criteria", []),
                    "dependencies": item.get("dependencies", []),
                }
                normalized.append(normalized_item)

            return normalized

        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse plan JSON: {e}")
            # Return a fallback single-item plan
            return [
                {
                    "id": "T1",
                    "item_type": "task",
                    "title": "Implementation task",
                    "description": f"Parse error - raw response needs manual review: {str(e)}",
                    "acceptance_criteria": [],
                    "dependencies": [],
                }
            ]


__all__ = ["DeriveHandler"]
