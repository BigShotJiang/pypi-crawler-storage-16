"""Examine handler for Hybrid Orchestrator.

This module handles the EXAMINE action from the server. It examines the current
plan using LLM to identify issues that need to be addressed.

The examination process:
    1. Receive ExamineRequest with plan to examine
    2. Build examination prompt with IP-protected criteria from server
    3. Invoke LLM with extended thinking if required
    4. Parse structured issues from response
    5. Return ExaminationReport to report to server

Related:
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md Section 1
    - obra/api/protocol.py
    - obra/hybrid/orchestrator.py
"""

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from obra.api.protocol import ExamineRequest
from obra.display import console, print_info

logger = logging.getLogger(__name__)


class ExamineHandler:
    """Handler for EXAMINE action.

    Examines the current plan using LLM to identify issues.
    Issues are categorized and assigned severity levels.

    Example:
        >>> handler = ExamineHandler(Path("/path/to/project"))
        >>> request = ExamineRequest(
        ...     plan_version_id="v1",
        ...     plan_items=[{"id": "T1", "title": "Task 1", ...}]
        ... )
        >>> result = handler.handle(request)
        >>> print(result["issues"])
    """

    def __init__(self, working_dir: Path) -> None:
        """Initialize ExamineHandler.

        Args:
            working_dir: Working directory for file access
        """
        self._working_dir = working_dir

    def handle(self, request: ExamineRequest) -> Dict[str, Any]:
        """Handle EXAMINE action.

        Args:
            request: ExamineRequest from server

        Returns:
            Dict with issues, thinking_budget_used, and raw_response
        """
        logger.info(f"Examining plan version: {request.plan_version_id}")
        print_info(f"Examining plan ({len(request.plan_items)} items)...")

        # Build examination prompt
        prompt = self._build_prompt(request)

        # Invoke LLM with thinking if required
        raw_response, thinking_used, thinking_fallback = self._invoke_llm(
            prompt,
            request.thinking_required,
            request.thinking_level,
        )

        # Parse issues from response
        issues = self._parse_issues(raw_response)

        logger.info(f"Found {len(issues)} issues")
        print_info(f"Found {len(issues)} issues")

        # Log blocking issues
        blocking = [i for i in issues if i.get("severity") in ("P0", "P1", "critical", "high")]
        if blocking:
            logger.info(f"  Blocking issues: {len(blocking)}")
            print_info(f"  Blocking issues: {len(blocking)}")

        return {
            "issues": issues,
            "thinking_budget_used": thinking_used,
            "thinking_fallback": thinking_fallback,
            "raw_response": raw_response,
            "iteration": 0,  # Server tracks iteration
        }

    def _build_prompt(self, request: ExamineRequest) -> str:
        """Build examination prompt.

        Args:
            request: ExamineRequest

        Returns:
            Prompt string for LLM
        """
        # Format plan items for examination
        plan_text = self._format_plan(request.plan_items)

        prompt = f"""You are a software quality reviewer. Examine the following implementation plan and identify any issues.

## Plan to Examine
{plan_text}

## Examination Criteria
Review the plan for the following:

1. **Scope Issues** (category: "scope")
   - Scope creep beyond stated objective
   - Missing essential components
   - Unnecessary complexity

2. **Completeness Issues** (category: "completeness")
   - Missing acceptance criteria
   - Undefined behavior
   - Gap in implementation steps

3. **Clarity Issues** (category: "clarity")
   - Ambiguous descriptions
   - Unclear requirements
   - Missing context

4. **Dependencies Issues** (category: "dependencies")
   - Circular dependencies
   - Missing dependencies
   - Incorrect ordering

5. **Feasibility Issues** (category: "feasibility")
   - Technical impossibility
   - Unrealistic scope
   - Missing prerequisites

## Output Format
Return a JSON object with an "issues" array. Each issue should have:
- id: Unique identifier (e.g., "I1", "I2")
- category: One of "scope", "completeness", "clarity", "dependencies", "feasibility"
- severity: "critical", "high", "medium", or "low"
- description: Clear description of the issue
- affected_items: Array of plan item IDs affected

If no issues found, return an empty array.

Example:
```json
{{
  "issues": [
    {{
      "id": "I1",
      "category": "completeness",
      "severity": "high",
      "description": "Task T2 lacks acceptance criteria for error handling",
      "affected_items": ["T2"]
    }}
  ]
}}
```

Return ONLY the JSON object, no additional text.
"""
        return prompt

    def _format_plan(self, plan_items: List[Dict[str, Any]]) -> str:
        """Format plan items as readable text.

        Args:
            plan_items: List of plan item dicts

        Returns:
            Formatted plan text
        """
        lines = []
        for item in plan_items:
            item_id = item.get("id", "?")
            item_type = item.get("item_type", "task")
            title = item.get("title", "Untitled")
            description = item.get("description", "")
            criteria = item.get("acceptance_criteria", [])
            deps = item.get("dependencies", [])

            lines.append(f"### {item_id}: {title} ({item_type})")
            if description:
                lines.append(f"Description: {description}")
            if criteria:
                lines.append("Acceptance Criteria:")
                for c in criteria:
                    lines.append(f"  - {c}")
            if deps:
                lines.append(f"Dependencies: {', '.join(deps)}")
            lines.append("")

        return "\n".join(lines)

    def _invoke_llm(
        self,
        prompt: str,
        thinking_required: bool,
        thinking_level: str,
    ) -> tuple[str, int, bool]:
        """Invoke LLM for examination.

        Args:
            prompt: Examination prompt
            thinking_required: Whether extended thinking is required
            thinking_level: Thinking level (standard, high, max)

        Returns:
            Tuple of (raw_response, thinking_tokens_used, thinking_fallback)
        """
        # TODO: Implement actual LLM invocation via obra/llm module
        # For now, return a placeholder response for testing
        logger.debug(f"Invoking LLM with thinking={thinking_required}, level={thinking_level}")

        # Placeholder response - LLM invocation will be implemented in S8
        placeholder_response = json.dumps({
            "issues": []  # No issues found in placeholder
        })

        return placeholder_response, 0, False

    def _parse_issues(self, raw_response: str) -> List[Dict[str, Any]]:
        """Parse LLM response into issues list.

        Args:
            raw_response: Raw LLM response

        Returns:
            List of issue dictionaries
        """
        try:
            # Try to extract JSON from response
            response = raw_response.strip()

            if response.startswith("```"):
                lines = response.split("\n")
                start = 1 if lines[0].startswith("```") else 0
                end = len(lines) - 1 if lines[-1] == "```" else len(lines)
                response = "\n".join(lines[start:end])

            # Parse JSON
            data = json.loads(response)

            # Extract issues
            if isinstance(data, dict) and "issues" in data:
                issues = data["issues"]
            elif isinstance(data, list):
                issues = data
            else:
                logger.warning("Unexpected response format")
                return []

            # Validate and normalize issues
            normalized = []
            for i, issue in enumerate(issues):
                normalized_issue = {
                    "id": issue.get("id", f"I{i + 1}"),
                    "category": issue.get("category", "other"),
                    "severity": self._normalize_severity(issue.get("severity", "low")),
                    "description": issue.get("description", ""),
                    "affected_items": issue.get("affected_items", []),
                }
                normalized.append(normalized_issue)

            return normalized

        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse issues JSON: {e}")
            return []

    def _normalize_severity(self, severity: str) -> str:
        """Normalize severity string.

        Args:
            severity: Raw severity string

        Returns:
            Normalized severity (critical, high, medium, low, or P0-P3)
        """
        severity_lower = severity.lower()

        # Map common severity strings
        mapping = {
            "critical": "critical",
            "p0": "P0",
            "blocker": "critical",
            "high": "high",
            "p1": "P1",
            "major": "high",
            "medium": "medium",
            "p2": "P2",
            "minor": "medium",
            "low": "low",
            "p3": "P3",
            "trivial": "low",
        }

        return mapping.get(severity_lower, severity)


__all__ = ["ExamineHandler"]
