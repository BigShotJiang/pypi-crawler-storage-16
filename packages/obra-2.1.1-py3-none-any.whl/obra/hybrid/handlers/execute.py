"""Execute handler for Hybrid Orchestrator.

This module handles the EXECUTE action from the server. It executes a plan item
by deploying an implementation agent (Claude Code, etc.).

The execution process:
    1. Receive ExecutionRequest with plan item to execute
    2. Prepare execution context (files, dependencies)
    3. Deploy implementation agent
    4. Collect execution results (files changed, tests, etc.)
    5. Return ExecutionResult to report to server

Related:
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md Section 2
    - obra/api/protocol.py
    - obra/hybrid/orchestrator.py
"""

import logging
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional

from obra.api.protocol import ExecutionRequest, ExecutionStatus
from obra.display import console, print_error, print_info, print_warning

logger = logging.getLogger(__name__)


class ExecuteHandler:
    """Handler for EXECUTE action.

    Executes a plan item using an implementation agent.
    Returns execution results including files changed and test results.

    Example:
        >>> handler = ExecuteHandler(Path("/path/to/project"))
        >>> request = ExecutionRequest(
        ...     plan_items=[{"id": "T1", "title": "Create models", ...}],
        ...     execution_index=0
        ... )
        >>> result = handler.handle(request)
        >>> print(result["status"])
    """

    def __init__(self, working_dir: Path) -> None:
        """Initialize ExecuteHandler.

        Args:
            working_dir: Working directory for file access
        """
        self._working_dir = working_dir

    def handle(self, request: ExecutionRequest) -> Dict[str, Any]:
        """Handle EXECUTE action.

        Args:
            request: ExecutionRequest from server

        Returns:
            Dict with item_id, status, summary, files_changed, etc.
        """
        if not request.current_item:
            logger.error("No current item to execute")
            return {
                "item_id": "",
                "status": ExecutionStatus.FAILURE.value,
                "summary": "No item to execute",
                "files_changed": 0,
                "tests_passed": False,
                "test_count": 0,
                "coverage_delta": 0.0,
            }

        item = request.current_item
        item_id = item.get("id", "unknown")
        title = item.get("title", "Untitled")

        logger.info(f"Executing item {item_id}: {title}")
        print_info(f"Executing: {item_id} - {title}")

        # Build execution context
        context = self._build_context(request)

        # Execute via implementation agent
        result = self._execute_item(item, context)

        # Log result
        status = result.get("status", ExecutionStatus.FAILURE.value)
        if status == ExecutionStatus.SUCCESS.value:
            print_info(f"  Completed: {result.get('summary', 'Success')[:50]}")
        elif status == ExecutionStatus.PARTIAL.value:
            print_warning(f"  Partial: {result.get('summary', 'Partial completion')[:50]}")
        else:
            print_error(f"  Failed: {result.get('summary', 'Execution failed')[:50]}")

        return result

    def _build_context(self, request: ExecutionRequest) -> Dict[str, Any]:
        """Build execution context.

        Args:
            request: ExecutionRequest

        Returns:
            Context dictionary for execution
        """
        context: Dict[str, Any] = {
            "working_dir": str(self._working_dir),
            "plan_items": request.plan_items,
            "execution_index": request.execution_index,
            "dependencies_completed": [],
        }

        # Determine which dependencies have been completed
        if request.current_item:
            deps = request.current_item.get("dependencies", [])
            # Assume items before current index are completed
            completed_ids = [
                p.get("id") for p in request.plan_items[:request.execution_index]
            ]
            context["dependencies_completed"] = [d for d in deps if d in completed_ids]

        return context

    def _execute_item(self, item: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a single plan item.

        Args:
            item: Plan item to execute
            context: Execution context

        Returns:
            Execution result dictionary
        """
        item_id = item.get("id", "unknown")
        title = item.get("title", "Untitled")
        description = item.get("description", "")
        criteria = item.get("acceptance_criteria", [])

        # Build execution prompt
        prompt = self._build_execution_prompt(item, context)

        # Try to deploy implementation agent
        try:
            result = self._deploy_agent(prompt)

            # Count files changed (would be from git diff in production)
            files_changed = result.get("files_changed", 0)

            # Run tests if present
            tests_passed, test_count = self._run_tests()

            return {
                "item_id": item_id,
                "status": result.get("status", ExecutionStatus.SUCCESS.value),
                "summary": result.get("summary", f"Executed: {title}"),
                "files_changed": files_changed,
                "tests_passed": tests_passed,
                "test_count": test_count,
                "coverage_delta": 0.0,  # Would be calculated from coverage reports
            }

        except Exception as e:
            logger.error(f"Execution failed for {item_id}: {e}")
            return {
                "item_id": item_id,
                "status": ExecutionStatus.FAILURE.value,
                "summary": f"Execution failed: {str(e)}",
                "files_changed": 0,
                "tests_passed": False,
                "test_count": 0,
                "coverage_delta": 0.0,
            }

    def _build_execution_prompt(self, item: Dict[str, Any], context: Dict[str, Any]) -> str:
        """Build execution prompt for implementation agent.

        Args:
            item: Plan item
            context: Execution context

        Returns:
            Prompt string
        """
        title = item.get("title", "Untitled")
        description = item.get("description", "")
        criteria = item.get("acceptance_criteria", [])

        criteria_text = "\n".join(f"- {c}" for c in criteria) if criteria else "None specified"

        prompt = f"""Implement the following task in the codebase.

## Task
{title}

## Description
{description}

## Acceptance Criteria
{criteria_text}

## Instructions
1. Analyze the existing codebase structure
2. Make the necessary changes to implement this task
3. Ensure the acceptance criteria are met
4. Add or update tests as appropriate
5. Follow existing code style and patterns

Work in: {context.get('working_dir', '.')}
"""
        return prompt

    def _deploy_agent(self, prompt: str) -> Dict[str, Any]:
        """Deploy implementation agent.

        Args:
            prompt: Execution prompt

        Returns:
            Agent result dictionary
        """
        # TODO: Implement actual agent deployment via obra/agents module
        # For now, return a placeholder response for testing
        logger.debug("Deploying implementation agent")

        # Placeholder response - agent deployment will be implemented in S9
        return {
            "status": ExecutionStatus.SUCCESS.value,
            "summary": "Placeholder execution - agent deployment coming in S9",
            "files_changed": 0,
        }

    def _run_tests(self) -> tuple[bool, int]:
        """Run project tests.

        Returns:
            Tuple of (tests_passed, test_count)
        """
        # Try to detect and run tests
        # Check for common test runners
        test_commands = [
            ("pytest", ["pytest", "--tb=no", "-q"]),
            ("npm test", ["npm", "test", "--", "--passWithNoTests"]),
            ("go test", ["go", "test", "./..."]),
            ("cargo test", ["cargo", "test"]),
        ]

        for name, cmd in test_commands:
            # Check if the test runner is available and relevant
            try:
                # Simple check - does the command exist?
                result = subprocess.run(
                    [cmd[0], "--version"],
                    capture_output=True,
                    timeout=5,
                    cwd=self._working_dir,
                )
                if result.returncode != 0:
                    continue

                # Check if relevant config exists
                if cmd[0] == "pytest" and not (
                    (self._working_dir / "pytest.ini").exists()
                    or (self._working_dir / "pyproject.toml").exists()
                    or (self._working_dir / "tests").is_dir()
                ):
                    continue

                if cmd[0] == "npm" and not (self._working_dir / "package.json").exists():
                    continue

                # Run tests
                logger.debug(f"Running tests with {name}")
                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    timeout=120,  # 2 minute timeout
                    cwd=self._working_dir,
                )

                # Parse results (simplified)
                passed = result.returncode == 0
                # Count tests from output (very simplified)
                output = result.stdout.decode("utf-8", errors="ignore")
                test_count = output.count("passed") + output.count("PASS")

                return passed, max(test_count, 1 if passed else 0)

            except subprocess.TimeoutExpired:
                logger.warning(f"Test timeout with {name}")
                continue
            except FileNotFoundError:
                continue
            except Exception as e:
                logger.debug(f"Test runner {name} failed: {e}")
                continue

        # No tests found or run
        return True, 0  # Assume success if no tests


__all__ = ["ExecuteHandler"]
