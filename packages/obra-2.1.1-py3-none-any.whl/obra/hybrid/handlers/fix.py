"""Fix handler for Hybrid Orchestrator.

This module handles the FIX action from the server. It attempts to fix issues
found during review by deploying an implementation agent with specific fix instructions.

The fix process:
    1. Receive FixRequest with issues to fix and execution order
    2. For each issue in order:
       - Build fix prompt with issue details
       - Deploy implementation agent
       - Verify the fix
    3. Return FixResults to report to server

Related:
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md Section 2
    - obra/api/protocol.py
    - obra/hybrid/orchestrator.py
"""

import logging
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional

from obra.api.protocol import FixRequest, FixResult, Priority
from obra.display import console, print_error, print_info, print_warning

logger = logging.getLogger(__name__)


class FixHandler:
    """Handler for FIX action.

    Attempts to fix issues found during review by deploying implementation
    agents with targeted fix instructions.

    Example:
        >>> handler = FixHandler(Path("/path/to/project"))
        >>> request = FixRequest(
        ...     issues_to_fix=[{"id": "SEC-001", "description": "SQL injection"}],
        ...     execution_order=["SEC-001"]
        ... )
        >>> result = handler.handle(request)
        >>> print(result["fix_results"])
    """

    def __init__(self, working_dir: Path) -> None:
        """Initialize FixHandler.

        Args:
            working_dir: Working directory for file access
        """
        self._working_dir = working_dir

    def handle(self, request: FixRequest) -> Dict[str, Any]:
        """Handle FIX action.

        Args:
            request: FixRequest from server

        Returns:
            Dict with fix_results list
        """
        issues = request.issues_to_fix
        execution_order = request.execution_order

        if not issues:
            logger.info("No issues to fix")
            return {
                "fix_results": [],
                "fixed_count": 0,
                "failed_count": 0,
                "skipped_count": 0,
            }

        logger.info(f"Fixing {len(issues)} issues")
        print_info(f"Fixing {len(issues)} issues")

        # Build issue lookup for ordering
        issue_map = {issue.get("id", f"issue-{i}"): issue for i, issue in enumerate(issues)}

        # Determine execution order
        if execution_order:
            ordered_ids = execution_order
        else:
            # Default: order by priority (P0 first)
            ordered_ids = self._order_by_priority(issues)

        fix_results: List[Dict[str, Any]] = []
        fixed_count = 0
        failed_count = 0
        skipped_count = 0

        for issue_id in ordered_ids:
            issue = issue_map.get(issue_id)
            if not issue:
                logger.warning(f"Issue {issue_id} not found in issue map, skipping")
                skipped_count += 1
                continue

            result = self._fix_issue(issue)
            fix_results.append(result)

            status = result.get("status", "failed")
            if status == "fixed":
                fixed_count += 1
                print_info(f"  Fixed: {issue_id}")
            elif status == "skipped":
                skipped_count += 1
                print_warning(f"  Skipped: {issue_id}")
            else:
                failed_count += 1
                print_error(f"  Failed: {issue_id}")

        logger.info(f"Fix complete: {fixed_count} fixed, {failed_count} failed, {skipped_count} skipped")

        return {
            "fix_results": fix_results,
            "fixed_count": fixed_count,
            "failed_count": failed_count,
            "skipped_count": skipped_count,
        }

    def _order_by_priority(self, issues: List[Dict[str, Any]]) -> List[str]:
        """Order issues by priority.

        Args:
            issues: List of issues

        Returns:
            List of issue IDs in priority order (P0 first)
        """
        priority_order = {"P0": 0, "P1": 1, "P2": 2, "P3": 3}

        def get_priority_rank(issue: Dict[str, Any]) -> int:
            priority = issue.get("priority", "P3")
            return priority_order.get(priority, 4)

        sorted_issues = sorted(issues, key=get_priority_rank)
        return [issue.get("id", f"issue-{i}") for i, issue in enumerate(sorted_issues)]

    def _fix_issue(self, issue: Dict[str, Any]) -> Dict[str, Any]:
        """Fix a single issue.

        Args:
            issue: Issue dictionary

        Returns:
            FixResult dictionary
        """
        issue_id = issue.get("id", "unknown")
        description = issue.get("description", "")
        fix_guidance = issue.get("fix_guidance", "")
        affected_files = issue.get("affected_files", [])
        priority = issue.get("priority", "P3")

        logger.info(f"Fixing issue {issue_id}: {description[:50]}...")

        # Build fix prompt
        prompt = self._build_fix_prompt(issue)

        try:
            # Deploy implementation agent to fix
            result = self._deploy_agent(prompt)

            # Verify the fix
            verification = self._verify_fix(issue, result)

            # Determine status based on verification
            if verification.get("all_passed", False):
                status = "fixed"
            elif verification.get("partial", False):
                status = "fixed"  # Partial fix still counts
            else:
                status = "failed"

            return {
                "issue_id": issue_id,
                "status": status,
                "files_modified": result.get("files_modified", []),
                "verification": verification,
            }

        except Exception as e:
            logger.error(f"Failed to fix issue {issue_id}: {e}")
            return {
                "issue_id": issue_id,
                "status": "failed",
                "files_modified": [],
                "verification": {"error": str(e)},
            }

    def _build_fix_prompt(self, issue: Dict[str, Any]) -> str:
        """Build fix prompt for implementation agent.

        Args:
            issue: Issue dictionary

        Returns:
            Prompt string
        """
        issue_id = issue.get("id", "unknown")
        description = issue.get("description", "")
        fix_guidance = issue.get("fix_guidance", "")
        affected_files = issue.get("affected_files", [])
        code_snippet = issue.get("code_snippet", "")
        priority = issue.get("priority", "P3")
        category = issue.get("category", "general")

        files_text = "\n".join(f"- {f}" for f in affected_files) if affected_files else "Not specified"
        snippet_text = f"\n```\n{code_snippet}\n```" if code_snippet else ""

        prompt = f"""Fix the following issue in the codebase.

## Issue
**ID**: {issue_id}
**Priority**: {priority}
**Category**: {category}

## Description
{description}

## Affected Files
{files_text}
{snippet_text}

## Fix Guidance
{fix_guidance or "Apply best practices to resolve this issue."}

## Instructions
1. Analyze the issue and affected code
2. Implement the fix following the guidance
3. Ensure the fix doesn't introduce new issues
4. Add or update tests if appropriate
5. Follow existing code style and patterns

Work in: {self._working_dir}
"""
        return prompt

    def _deploy_agent(self, prompt: str) -> Dict[str, Any]:
        """Deploy implementation agent to apply fix.

        Args:
            prompt: Fix prompt

        Returns:
            Agent result dictionary
        """
        # TODO: Implement actual agent deployment via obra/agents module (S9)
        # For now, return placeholder response for testing
        logger.debug("Deploying implementation agent for fix (placeholder)")

        # Placeholder response - agent deployment will be implemented in S9
        return {
            "status": "success",
            "files_modified": [],
            "summary": "Placeholder fix - agent deployment coming in S9",
        }

    def _verify_fix(
        self,
        issue: Dict[str, Any],
        agent_result: Dict[str, Any],
    ) -> Dict[str, bool]:
        """Verify that the fix resolved the issue.

        Args:
            issue: Original issue
            agent_result: Result from fix agent

        Returns:
            Verification results dictionary
        """
        verification: Dict[str, bool] = {
            "agent_succeeded": agent_result.get("status") == "success",
            "files_modified": bool(agent_result.get("files_modified")),
        }

        # Check if specific verification steps are needed based on issue category
        category = issue.get("category", "")

        if category == "security":
            verification["security_check_passed"] = self._run_security_check()
        elif category == "testing":
            verification["tests_passed"] = self._run_tests()
        elif category == "code_quality":
            verification["lint_passed"] = self._run_lint()

        # Determine overall result
        verification["all_passed"] = all(
            v for k, v in verification.items()
            if k not in ("partial", "all_passed")
        )

        return verification

    def _run_security_check(self) -> bool:
        """Run security check to verify fix.

        Returns:
            True if security check passes
        """
        # TODO: Implement actual security check
        # For now, return placeholder
        return True

    def _run_tests(self) -> bool:
        """Run tests to verify fix.

        Returns:
            True if tests pass
        """
        # Try to run pytest if available
        try:
            result = subprocess.run(
                ["pytest", "--tb=no", "-q", "-x"],
                capture_output=True,
                timeout=60,
                cwd=self._working_dir,
            )
            return result.returncode == 0
        except (subprocess.TimeoutExpired, FileNotFoundError, Exception):
            # If tests can't be run, assume pass
            return True

    def _run_lint(self) -> bool:
        """Run linter to verify fix.

        Returns:
            True if lint passes
        """
        # Try to run ruff if available
        try:
            result = subprocess.run(
                ["ruff", "check", "."],
                capture_output=True,
                timeout=30,
                cwd=self._working_dir,
            )
            return result.returncode == 0
        except (subprocess.TimeoutExpired, FileNotFoundError, Exception):
            # If linter can't be run, assume pass
            return True


__all__ = ["FixHandler"]
