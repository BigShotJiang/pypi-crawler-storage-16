"""Revise handler for Hybrid Orchestrator.

This module handles the REVISE action from the server. It revises the current
plan based on issues identified during examination.

The revision process:
    1. Receive RevisionRequest with issues to address
    2. Build revision prompt with issues and guidance
    3. Invoke LLM to generate revised plan
    4. Parse revised plan items
    5. Return RevisedPlan to report to server

Related:
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md Section 1
    - obra/api/protocol.py
    - obra/hybrid/orchestrator.py
"""

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from obra.api.protocol import RevisionRequest
from obra.display import console, print_info

logger = logging.getLogger(__name__)


class ReviseHandler:
    """Handler for REVISE action.

    Revises the current plan based on issues from examination.
    Returns updated plan items with changes summary.

    Example:
        >>> handler = ReviseHandler(Path("/path/to/project"))
        >>> request = RevisionRequest(
        ...     issues=[{"id": "I1", "description": "Missing error handling"}],
        ...     blocking_issues=[{"id": "I1", ...}]
        ... )
        >>> result = handler.handle(request)
        >>> print(result["plan_items"])
    """

    def __init__(self, working_dir: Path) -> None:
        """Initialize ReviseHandler.

        Args:
            working_dir: Working directory for file access
        """
        self._working_dir = working_dir

    def handle(self, request: RevisionRequest) -> Dict[str, Any]:
        """Handle REVISE action.

        Args:
            request: RevisionRequest from server

        Returns:
            Dict with plan_items, changes_summary, and raw_response
        """
        logger.info(f"Revising plan to address {len(request.issues)} issues")
        print_info(f"Revising plan ({len(request.blocking_issues)} blocking issues)...")

        # Build revision prompt
        prompt = self._build_prompt(request)

        # Invoke LLM
        raw_response = self._invoke_llm(prompt)

        # Parse revised plan
        plan_items, changes_summary = self._parse_revision(raw_response)

        logger.info(f"Revised plan has {len(plan_items)} items")
        print_info(f"Revised plan: {len(plan_items)} items")

        return {
            "plan_items": plan_items,
            "changes_summary": changes_summary,
            "raw_response": raw_response,
        }

    def _build_prompt(self, request: RevisionRequest) -> str:
        """Build revision prompt.

        Args:
            request: RevisionRequest

        Returns:
            Prompt string for LLM
        """
        # Format issues
        issues_text = self._format_issues(request.issues)
        blocking_text = self._format_issues(request.blocking_issues)

        # Format focus areas
        focus_text = ""
        if request.focus_areas:
            focus_text = f"\n## Focus Areas\n{', '.join(request.focus_areas)}\n"

        prompt = f"""You are a software architect revising an implementation plan. Address the identified issues while preserving the original intent.

## Issues to Address

### Blocking Issues (MUST FIX)
{blocking_text if blocking_text else "None"}

### All Issues
{issues_text if issues_text else "None"}
{focus_text}
## Instructions
1. Address all blocking issues - these must be resolved
2. Address other issues where reasonable
3. Preserve unchanged parts of the plan
4. Maintain the same structure (id, item_type, title, description, acceptance_criteria, dependencies)
5. Document what changes you made

## Output Format
Return a JSON object with:
- plan_items: Array of revised plan items (full plan, not just changes)
- changes_summary: Brief description of changes made

Each plan item should have:
- id: Same ID as original OR new ID for new items
- item_type: "task" or "story"
- title: Title (may be updated)
- description: Description (may be updated)
- acceptance_criteria: Array of criteria (should address issues)
- dependencies: Array of item IDs

Example:
```json
{{
  "plan_items": [
    {{
      "id": "T1",
      "item_type": "task",
      "title": "Create database models with validation",
      "description": "Define models with proper validation and error handling",
      "acceptance_criteria": [
        "User model has email, password_hash fields",
        "Validation errors return clear messages",
        "Invalid data is rejected"
      ],
      "dependencies": []
    }}
  ],
  "changes_summary": "Added validation and error handling to T1 to address issue I1"
}}
```

Return ONLY the JSON object, no additional text.
"""
        return prompt

    def _format_issues(self, issues: List[Dict[str, Any]]) -> str:
        """Format issues as readable text.

        Args:
            issues: List of issue dicts

        Returns:
            Formatted issues text
        """
        if not issues:
            return ""

        lines = []
        for issue in issues:
            issue_id = issue.get("id", "?")
            category = issue.get("category", "other")
            severity = issue.get("severity", "unknown")
            description = issue.get("description", "")
            affected = issue.get("affected_items", [])

            lines.append(f"- [{issue_id}] ({severity}/{category}): {description}")
            if affected:
                lines.append(f"  Affects: {', '.join(affected)}")

        return "\n".join(lines)

    def _invoke_llm(self, prompt: str) -> str:
        """Invoke LLM for revision.

        Args:
            prompt: Revision prompt

        Returns:
            Raw LLM response
        """
        # TODO: Implement actual LLM invocation via obra/llm module
        # For now, return a placeholder response for testing
        logger.debug("Invoking LLM for revision")

        # Placeholder response - LLM invocation will be implemented in S8
        placeholder_response = json.dumps({
            "plan_items": [
                {
                    "id": "T1",
                    "item_type": "task",
                    "title": "Placeholder revised task",
                    "description": "This is a placeholder - LLM invocation will be implemented in S8",
                    "acceptance_criteria": ["Issues addressed", "LLM invocation implemented"],
                    "dependencies": [],
                }
            ],
            "changes_summary": "Placeholder revision - actual LLM invocation coming in S8",
        })

        return placeholder_response

    def _parse_revision(self, raw_response: str) -> tuple[List[Dict[str, Any]], str]:
        """Parse LLM response into revised plan.

        Args:
            raw_response: Raw LLM response

        Returns:
            Tuple of (plan_items, changes_summary)
        """
        try:
            # Try to extract JSON from response
            response = raw_response.strip()

            if response.startswith("```"):
                lines = response.split("\n")
                start = 1 if lines[0].startswith("```") else 0
                end = len(lines) - 1 if lines[-1] == "```" else len(lines)
                response = "\n".join(lines[start:end])

            # Parse JSON
            data = json.loads(response)

            # Extract plan_items
            if isinstance(data, dict):
                items = data.get("plan_items", [])
                summary = data.get("changes_summary", "")
            elif isinstance(data, list):
                items = data
                summary = ""
            else:
                logger.warning("Unexpected response format")
                return [], ""

            # Validate and normalize items
            normalized = []
            for i, item in enumerate(items):
                normalized_item = {
                    "id": item.get("id", f"T{i + 1}"),
                    "item_type": item.get("item_type", "task"),
                    "title": item.get("title", "Untitled"),
                    "description": item.get("description", ""),
                    "acceptance_criteria": item.get("acceptance_criteria", []),
                    "dependencies": item.get("dependencies", []),
                }
                normalized.append(normalized_item)

            return normalized, summary

        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse revision JSON: {e}")
            return [], f"Parse error: {str(e)}"


__all__ = ["ReviseHandler"]
