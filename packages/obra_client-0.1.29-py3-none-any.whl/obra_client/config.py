"""Configuration management for Obra Client.

Handles terms acceptance state and client configuration stored in
~/.obra/client-config.yaml.
"""

import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Optional

import yaml

# Legal document versions - must match bundled documents
TERMS_VERSION = "2.1"
PRIVACY_VERSION = "1.3"

# Config file path
CONFIG_PATH = Path.home() / ".obra" / "client-config.yaml"

# Firebase configuration
# This is the Firebase Web API Key (public, safe to include in client)
# Used for custom token → ID token exchange via Firebase Auth REST API
# Project: obra-205b0
FIREBASE_API_KEY = "AIzaSyDHQNxR_4BQvK_W_i83H2hNH4p2OKFi2wM"  # pragma: allowlist secret

# Default API URL (production)
# Can be overridden via OBRA_API_BASE_URL environment variable (Finding 10.3)
DEFAULT_API_BASE_URL = "https://us-central1-obra-205b0.cloudfunctions.net"

# Default LLM execution timeout (30 minutes)
# Can be overridden via OBRA_LLM_TIMEOUT environment variable
DEFAULT_LLM_TIMEOUT = 1800


def get_api_base_url() -> str:
    """Get API base URL with environment variable override support.

    Resolution order:
    1. OBRA_API_BASE_URL environment variable
    2. api_base_url from config file
    3. DEFAULT_API_BASE_URL constant

    Returns:
        API base URL string

    Example:
        # Override for local development
        export OBRA_API_BASE_URL="http://localhost:5001/obra-205b0/us-central1"

        # Override for staging
        export OBRA_API_BASE_URL="https://us-central1-obra-staging.cloudfunctions.net"
    """
    # Priority 1: Environment variable
    env_url = os.environ.get("OBRA_API_BASE_URL")
    if env_url:
        return env_url.rstrip("/")

    # Priority 2: Config file
    config = load_config()
    config_url = config.get("api_base_url")
    if config_url:
        return config_url.rstrip("/")

    # Priority 3: Default constant
    return DEFAULT_API_BASE_URL


def get_llm_timeout() -> int:
    """Get LLM execution timeout in seconds.

    Resolution order:
    1. OBRA_LLM_TIMEOUT environment variable
    2. llm_timeout from config file
    3. DEFAULT_LLM_TIMEOUT constant (1800s = 30 min)

    Returns:
        Timeout in seconds

    Example:
        # Override for long-running tasks
        export OBRA_LLM_TIMEOUT=3600

        # Or set in ~/.obra/client-config.yaml:
        # llm_timeout: 3600
    """
    # Priority 1: Environment variable
    env_timeout = os.environ.get("OBRA_LLM_TIMEOUT")
    if env_timeout:
        try:
            return int(env_timeout)
        except ValueError:
            pass  # Fall through to config file

    # Priority 2: Config file
    config = load_config()
    config_timeout = config.get("llm_timeout")
    if config_timeout:
        return int(config_timeout)

    # Priority 3: Default constant
    return DEFAULT_LLM_TIMEOUT


# =============================================================================
# LLM Configuration
# =============================================================================

# Supported LLM providers
LLM_PROVIDERS = {
    "anthropic": {
        "name": "Anthropic",
        "description": "Claude models (recommended)",
        "cli": "claude",  # Claude Code CLI
        "models": ["default", "sonnet", "opus", "haiku"],
        "default_model": "default",
        "oauth_env_var": None,  # OAuth uses browser-based login
        "api_key_env_var": "ANTHROPIC_API_KEY",  # pragma: allowlist secret
    },
    "google": {
        "name": "Google",
        "description": "Gemini models",
        "cli": "gemini",  # Gemini CLI
        "models": ["default", "gemini-2.0-flash", "gemini-2.5-pro"],
        "default_model": "default",
        "oauth_env_var": None,  # OAuth uses browser-based login (gemini auth login)
        "api_key_env_var": "GEMINI_API_KEY",  # pragma: allowlist secret
    },
    "openai": {
        "name": "OpenAI",
        "description": "Codex / GPT models",
        "cli": "codex",  # OpenAI Codex CLI
        "models": ["default", "gpt-4o", "gpt-4-turbo", "o3", "gpt-5"],
        "default_model": "default",
        "oauth_env_var": None,  # OAuth uses browser-based login (codex --login)
        "api_key_env_var": "OPENAI_API_KEY",  # pragma: allowlist secret
    },
}

# Auth methods
LLM_AUTH_METHODS = {
    "oauth": {
        "name": "OAuth (Flat Rate)",
        "description": "Subscription-based, fixed monthly cost",
        "recommended_model": "default",
        "note": "Recommended - inherits provider's optimal model",
    },
    "api_key": {
        "name": "API Key (Token Billing)",
        "description": "Pay per token usage",
        "recommended_model": None,  # User should choose
        "note": "⚠️ API Key method is currently untested",
    },
}

DEFAULT_PROVIDER = "anthropic"
DEFAULT_AUTH_METHOD = "oauth"
DEFAULT_MODEL = "default"


def get_llm_config() -> dict[str, Any]:
    """Get LLM configuration from config file.

    Returns:
        Dictionary with LLM config for both orchestrator and implementation:
        {
            "orchestrator": {
                "provider": "anthropic",
                "auth_method": "oauth",
                "model": "default"
            },
            "implementation": {
                "provider": "anthropic",
                "auth_method": "oauth",
                "model": "default"
            }
        }
    """
    config = load_config()
    default_config = {
        "orchestrator": {
            "provider": DEFAULT_PROVIDER,
            "auth_method": DEFAULT_AUTH_METHOD,
            "model": DEFAULT_MODEL,
        },
        "implementation": {
            "provider": DEFAULT_PROVIDER,
            "auth_method": DEFAULT_AUTH_METHOD,
            "model": DEFAULT_MODEL,
        },
    }
    return config.get("llm", default_config)


def set_llm_config(
    role: str,  # "orchestrator" or "implementation"
    provider: str,
    auth_method: str,
    model: str = "default",
) -> None:
    """Set LLM configuration for a specific role.

    Args:
        role: "orchestrator" or "implementation"
        provider: LLM provider (anthropic, openai)
        auth_method: Auth method (oauth, api_key)
        model: Model to use (default recommended for oauth)

    Raises:
        ValueError: If any parameter is invalid
    """
    if role not in ("orchestrator", "implementation"):
        raise ValueError(f"Invalid role: {role}. Must be 'orchestrator' or 'implementation'")

    if provider not in LLM_PROVIDERS:
        raise ValueError(f"Invalid provider: {provider}. Valid: {list(LLM_PROVIDERS.keys())}")

    if auth_method not in LLM_AUTH_METHODS:
        raise ValueError(f"Invalid auth method: {auth_method}. Valid: {list(LLM_AUTH_METHODS.keys())}")

    provider_info = LLM_PROVIDERS[provider]
    if model not in provider_info["models"]:
        raise ValueError(f"Invalid model '{model}' for {provider}. Valid: {provider_info['models']}")

    config = load_config()
    if "llm" not in config:
        config["llm"] = get_llm_config()

    config["llm"][role] = {
        "provider": provider,
        "auth_method": auth_method,
        "model": model,
    }

    save_config(config)


def get_llm_display(role: str) -> str:
    """Get a human-readable display string for LLM config.

    Args:
        role: "orchestrator" or "implementation"

    Returns:
        Display string like "Anthropic (OAuth, default)"
    """
    llm_config = get_llm_config()
    role_config = llm_config.get(role, {})

    provider = role_config.get("provider", DEFAULT_PROVIDER)
    auth_method = role_config.get("auth_method", DEFAULT_AUTH_METHOD)
    model = role_config.get("model", DEFAULT_MODEL)

    provider_name = LLM_PROVIDERS.get(provider, {}).get("name", provider)
    auth_name = "OAuth" if auth_method == "oauth" else "API Key"

    return f"{provider_name} ({auth_name}, {model})"


def get_llm_command() -> tuple[str, list[str]]:
    """Get the implementation LLM command and arguments.

    Returns:
        Tuple of (command, args) for subprocess execution.
        Uses provider-specific CLI:
        - Anthropic: claude (Claude Code CLI)
        - Google: gemini (Gemini CLI)
        - OpenAI: codex (OpenAI Codex CLI)
    """
    llm_config = get_llm_config()
    impl_config = llm_config.get("implementation", {})

    provider = impl_config.get("provider", DEFAULT_PROVIDER)
    model = impl_config.get("model", DEFAULT_MODEL)

    provider_info = LLM_PROVIDERS.get(provider, LLM_PROVIDERS[DEFAULT_PROVIDER])
    cli = provider_info.get("cli", "claude")

    # Build args based on provider CLI
    if provider == "anthropic":
        # Claude Code CLI
        args = ["--dangerously-skip-permissions"]
        if model and model != "default":
            args.extend(["--model", model])
        return cli, args

    if provider == "google":
        # Gemini CLI
        args = ["--sandbox=permissive"]
        if model and model != "default":
            args.extend(["--model", model])
        return cli, args

    if provider == "openai":
        # OpenAI Codex CLI - uses exec --full-auto mode
        args = ["exec", "--full-auto"]
        if model and model != "default":
            args.extend(["--model", model])
        return cli, args

    # Fallback to Claude Code CLI
    return "claude", ["--dangerously-skip-permissions"]


def get_config_path() -> Path:
    """Get path to client configuration file.

    Returns:
        Path to ~/.obra/client-config.yaml
    """
    return CONFIG_PATH


def load_config() -> dict[str, Any]:
    """Load configuration from ~/.obra/client-config.yaml.

    Returns:
        Configuration dictionary, empty dict if file doesn't exist
    """
    if not CONFIG_PATH.exists():
        return {}

    try:
        with open(CONFIG_PATH) as f:
            return yaml.safe_load(f) or {}
    except Exception:
        return {}


def save_config(config: dict[str, Any]) -> None:
    """Save configuration to ~/.obra/client-config.yaml.

    Args:
        config: Configuration dictionary to save

    Raises:
        OSError: If unable to write config file
    """
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)

    with open(CONFIG_PATH, "w") as f:
        yaml.safe_dump(config, f, default_flow_style=False, sort_keys=False)


def get_terms_acceptance() -> Optional[dict[str, Any]]:
    """Get stored terms acceptance data.

    Returns:
        Dictionary with terms acceptance info, or None if not accepted:
        {
            "version": "2.1",
            "privacy_version": "1.3",
            "accepted_at": "2025-12-03T12:00:00+00:00"
        }
    """
    config = load_config()
    return config.get("terms_accepted")


def is_terms_accepted() -> bool:
    """Check if current terms version has been accepted.

    Returns:
        True if terms are accepted and version matches current,
        False otherwise
    """
    acceptance = get_terms_acceptance()

    if not acceptance:
        return False

    # Check if accepted version matches current version
    accepted_version = acceptance.get("version")
    if accepted_version != TERMS_VERSION:
        return False

    return True


def needs_reacceptance() -> bool:
    """Check if terms need to be re-accepted due to version change.

    Returns:
        True if terms were previously accepted but version changed,
        False if never accepted or current version is accepted
    """
    acceptance = get_terms_acceptance()

    if not acceptance:
        return False  # Never accepted, not "re-acceptance"

    accepted_version = acceptance.get("version")
    return accepted_version != TERMS_VERSION


def save_terms_acceptance(
    version: str = TERMS_VERSION,
    privacy_version: str = PRIVACY_VERSION,
) -> None:
    """Save terms acceptance to config file.

    Args:
        version: Terms version being accepted (default: current TERMS_VERSION)
        privacy_version: Privacy policy version (default: current PRIVACY_VERSION)
    """
    config = load_config()

    config["terms_accepted"] = {
        "version": version,
        "privacy_version": privacy_version,
        "accepted_at": datetime.now(timezone.utc).isoformat(),
    }

    save_config(config)


def clear_terms_acceptance() -> None:
    """Clear stored terms acceptance (for testing/reset)."""
    config = load_config()

    if "terms_accepted" in config:
        del config["terms_accepted"]
        save_config(config)


# =============================================================================
# Firebase Auth Functions (EPIC-AUTH-MIGRATION-001)
# =============================================================================


def get_firebase_uid() -> Optional[str]:
    """Get stored Firebase UID from config.

    Returns:
        Firebase UID string or None if not authenticated
    """
    config = load_config()
    return config.get("firebase_uid")


def get_user_email() -> Optional[str]:
    """Get stored user email from config.

    Returns:
        User email string or None if not authenticated
    """
    config = load_config()
    return config.get("user_email")


def get_auth_token() -> Optional[str]:
    """Get stored Firebase ID token from config.

    Returns:
        Firebase ID token or None if not authenticated
    """
    config = load_config()
    return config.get("auth_token")


def get_refresh_token() -> Optional[str]:
    """Get stored Firebase refresh token from config.

    Returns:
        Firebase refresh token or None if not authenticated
    """
    config = load_config()
    return config.get("refresh_token")


def get_auth_provider() -> Optional[str]:
    """Get stored auth provider from config.

    Returns:
        Auth provider (e.g., "google.com", "github.com") or None
    """
    config = load_config()
    return config.get("auth_provider")


def is_authenticated() -> bool:
    """Check if user is authenticated with Firebase Auth.

    Returns:
        True if Firebase UID and auth token are present
    """
    config = load_config()
    return bool(config.get("firebase_uid") and config.get("auth_token"))


def save_firebase_auth(
    firebase_uid: str,
    email: str,
    auth_token: str,
    refresh_token: str,
    auth_provider: str,
    display_name: Optional[str] = None,
    token_expires_at: Optional[datetime] = None,
) -> None:
    """Save Firebase authentication to config file.

    Args:
        firebase_uid: Firebase user ID
        email: User's email address
        auth_token: Firebase ID token
        refresh_token: Firebase refresh token
        auth_provider: Auth provider (e.g., "google.com")
        display_name: Optional user display name
        token_expires_at: Optional token expiration time. If not provided,
            defaults to 1 hour from now (Firebase ID token lifetime).
    """
    config = load_config()

    config["firebase_uid"] = firebase_uid
    config["user_email"] = email
    config["auth_token"] = auth_token
    config["refresh_token"] = refresh_token
    config["auth_provider"] = auth_provider
    config["auth_timestamp"] = datetime.now(timezone.utc).isoformat()

    # Firebase ID tokens expire in 1 hour - save expiration for auto-refresh
    if token_expires_at is None:
        token_expires_at = datetime.now(timezone.utc) + timedelta(hours=1)
    config["token_expires_at"] = token_expires_at.isoformat()

    if display_name:
        config["display_name"] = display_name

    # Also set user_id to email for compatibility with existing code
    config["user_id"] = email

    save_config(config)


def clear_firebase_auth() -> None:
    """Clear stored Firebase authentication from config file."""
    config = load_config()

    # Remove Firebase auth fields
    for key in [
        "firebase_uid",
        "user_email",
        "auth_token",
        "refresh_token",
        "auth_provider",
        "auth_timestamp",
        "display_name",
    ]:
        config.pop(key, None)

    save_config(config)
