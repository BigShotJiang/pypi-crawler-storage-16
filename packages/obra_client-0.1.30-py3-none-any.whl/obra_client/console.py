"""Safe console wrapper with Unicode fallback for Windows compatibility.

This module provides a SafeConsole class that wraps Rich's Console
and automatically falls back to ASCII characters when the terminal
doesn't support Unicode (e.g., Windows cmd.exe or PowerShell ISE).

It also provides a decorator for CLI commands to handle encoding errors
gracefully with user-friendly messages.
"""

import functools
import io
import os
import sys
from typing import Any, Callable, TypeVar

from rich.console import Console

# Type variable for decorator
F = TypeVar("F", bound=Callable[..., Any])


# ASCII fallbacks for common symbols used in the CLI
SYMBOL_MAP = {
    # Status indicators
    "\u2713": "[OK]",      # ✓
    "\u2714": "[OK]",      # ✔
    "\u2717": "[X]",       # ✗
    "\u2718": "[X]",       # ✘
    "\u274c": "[ERROR]",   # ❌
    "\u26a0\ufe0f": "[WARN]",  # ⚠️
    "\u26a0": "[WARN]",    # ⚠
    # Action indicators
    "\U0001f680": ">>",    # 🚀
    "\U0001f4e1": "[API]", # 📡
    "\U0001f4e4": "[OUT]", # 📤
    "\u2728": "*",         # ✨
    "\U0001f4be": "[SAVE]", # 💾
    "\U0001f3af": "[TARGET]", # 🎯
    "\U0001f916": "[BOT]",  # 🤖
    "\U0001f504": "[SYNC]", # 🔄
    "\U0001f3e5": "[HEALTH]", # 🏥
    # Box drawing characters
    "\u2550": "=",         # ═
    "\u2501": "-",         # ━
    "\u2500": "-",         # ─
    "\u2502": "|",         # │
    "\u250c": "+",         # ┌
    "\u2510": "+",         # ┐
    "\u2514": "+",         # └
    "\u2518": "+",         # ┘
}


def _probe_console_unicode() -> bool:
    """Actually test if the console can write Unicode by attempting a write.

    This is the most reliable detection method - try to write a Unicode character
    and see if it succeeds. We use a non-visible test to avoid polluting output.

    Returns:
        True if Unicode write succeeded, False otherwise.
    """
    try:
        # Try to encode a representative emoji to the actual console encoding
        # We don't print it, just test if encoding would work
        test_char = "\U0001f680"  # 🚀

        # Get the actual console output stream (may be different from sys.stdout)
        if hasattr(sys.stdout, "buffer"):
            # Get the encoding the buffer will actually use
            console_encoding = getattr(sys.stdout, "encoding", "ascii") or "ascii"
            # Try to encode - this is what would fail during actual printing
            test_char.encode(console_encoding)
            return True
        else:
            # No buffer - try direct encoding test
            console_encoding = getattr(sys.stdout, "encoding", "ascii") or "ascii"
            test_char.encode(console_encoding)
            return True
    except (UnicodeEncodeError, LookupError):
        return False
    except Exception:
        # Any other exception - assume not safe
        return False


def is_unicode_safe() -> bool:
    """Check if the terminal supports Unicode output.

    Uses multiple detection strategies in order of reliability:
    1. Known good environments (Windows Terminal, VSCode)
    2. Explicit user override via OBRA_FORCE_ASCII=1
    3. Console probe test (actually try encoding Unicode)
    4. Default to ASCII on Windows for safety

    Returns:
        True if Unicode is safe to use, False if ASCII fallback needed.
    """
    # Allow explicit user override to force ASCII mode
    if os.environ.get("OBRA_FORCE_ASCII", "").lower() in ("1", "true", "yes"):
        return False

    if sys.platform == "win32":
        # Windows Terminal is known to support Unicode
        if "WT_SESSION" in os.environ:
            return True

        # VSCode integrated terminal supports Unicode
        if os.environ.get("TERM_PROGRAM") == "vscode":
            return True

        # ConEmu/Cmder support Unicode
        if os.environ.get("ConEmuANSI") == "ON":
            return True

        # For other Windows terminals, actually probe the console
        # This is more reliable than trusting sys.stdout.encoding
        if _probe_console_unicode():
            return True

        # Default to ASCII on Windows for safety
        return False

    # Unix-like systems generally support Unicode
    return True


def ascii_fallback(text: str) -> str:
    """Convert Unicode symbols to ASCII equivalents.

    Args:
        text: String potentially containing Unicode symbols.

    Returns:
        String with Unicode symbols replaced by ASCII equivalents.
    """
    result = text
    for unicode_char, ascii_char in SYMBOL_MAP.items():
        result = result.replace(unicode_char, ascii_char)
    return result


class SafeConsole(Console):
    """Console that falls back to ASCII on incompatible terminals.

    This wrapper detects terminal capabilities and automatically
    converts Unicode symbols to ASCII equivalents when needed.

    Example:
        >>> console = SafeConsole()
        >>> console.print("[green]✓[/green] Done")
        # On Windows cmd.exe: "[green][OK][/green] Done"
        # On Windows Terminal: "[green]✓[/green] Done"
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """Initialize SafeConsole with Unicode detection."""
        self._unicode_safe = is_unicode_safe()

        # If Unicode is not safe, configure Rich to avoid Unicode rendering issues
        if not self._unicode_safe and sys.platform == "win32":
            # Force Rich to use safe defaults
            kwargs.setdefault("force_terminal", True)
            kwargs.setdefault("no_color", False)
            # Ensure legacy Windows console mode doesn't trip us up
            kwargs.setdefault("legacy_windows", True)

        super().__init__(*args, **kwargs)

    def _make_safe(self, args: tuple) -> tuple:
        """Convert arguments to ASCII-safe strings.

        Args:
            args: Tuple of print arguments.

        Returns:
            Tuple with Unicode symbols replaced by ASCII equivalents.
        """
        return tuple(
            ascii_fallback(str(arg)) if isinstance(arg, str) else arg
            for arg in args
        )

    def _strip_non_ascii(self, args: tuple) -> tuple:
        """Strip all non-ASCII characters as last resort.

        Args:
            args: Tuple of print arguments.

        Returns:
            Tuple with all non-ASCII characters replaced.
        """
        return tuple(
            arg.encode("ascii", errors="replace").decode("ascii")
            if isinstance(arg, str) else arg
            for arg in args
        )

    def print(self, *args: Any, **kwargs: Any) -> None:
        """Print with automatic Unicode fallback.

        If the terminal doesn't support Unicode, symbols are
        automatically converted to ASCII equivalents before
        being passed to Rich.
        """
        # Pre-convert to ASCII if we know Unicode is not safe
        if not self._unicode_safe:
            args = self._make_safe(args)

        try:
            super().print(*args, **kwargs)
        except (UnicodeEncodeError, UnicodeDecodeError) as e:
            # Detection was wrong - mark as unsafe and retry
            self._unicode_safe = False
            safe_args = self._make_safe(args)
            try:
                super().print(*safe_args, **kwargs)
            except (UnicodeEncodeError, UnicodeDecodeError):
                # Last resort: strip all non-ASCII
                stripped_args = self._strip_non_ascii(safe_args)
                try:
                    super().print(*stripped_args, **kwargs)
                except Exception:
                    # Ultimate fallback: use basic print
                    # This bypasses Rich entirely
                    for arg in stripped_args:
                        print(arg, end="")
                    print()
        except Exception as e:
            # Catch any other Rich rendering errors
            # Try ASCII fallback
            if self._unicode_safe:
                self._unicode_safe = False
                safe_args = self._make_safe(args)
                try:
                    super().print(*safe_args, **kwargs)
                    return
                except Exception:
                    pass

            # Last resort: bypass Rich entirely
            stripped_args = self._strip_non_ascii(self._make_safe(args))
            for arg in stripped_args:
                print(arg, end="")
            print()


def handle_encoding_errors(func: F) -> F:
    """Decorator to catch encoding errors with user-friendly messages.

    Use this decorator on CLI commands to provide helpful error messages
    when Unicode encoding fails, instead of showing raw stack traces.

    Example:
        @app.command()
        @handle_encoding_errors
        def my_command():
            console.print("🚀 Starting...")
    """

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            return func(*args, **kwargs)
        except UnicodeEncodeError as e:
            # Use raw print to avoid any Rich formatting issues
            print("\n[ERROR] Terminal encoding issue detected.")
            print(f"        Character: {e.object[e.start:e.end]!r}")
            print("\nSolutions:")
            print("  1. Use Windows Terminal instead of cmd.exe or PowerShell ISE")
            print("  2. Set environment variable: OBRA_FORCE_ASCII=1")
            print("  3. Run: chcp 65001 (in cmd.exe before running obra-client)")
            print("\nFor more info: https://obra.dev/docs/troubleshooting/windows-unicode")

            # Import typer here to avoid circular imports
            import typer

            raise typer.Exit(1)

    return wrapper  # type: ignore[return-value]


# Module-level console instance for import
console = SafeConsole()
