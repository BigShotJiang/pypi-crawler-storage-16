"""Context collector that orchestrates all local project context gathering.

Coordinates FileWatcher, GitManager, and ErrorTracker to build
comprehensive tactical context for Tier 2 prompt enrichment.
"""

import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

from obra_client.error_tracker import ErrorInfo, ErrorTracker
from obra_client.file_watcher import FileInfo, FileWatcher


@dataclass
class GitCommitInfo:
    """Information about a git commit.

    Attributes:
        hash: Commit hash (short)
        message: Commit message
        author: Commit author
        timestamp: Commit timestamp
        files_changed: Number of files changed
    """

    hash: str
    message: str
    author: str
    timestamp: str
    files_changed: int


@dataclass
class ProjectContext:
    """Complete project context for Tier 2 enrichment.

    Attributes:
        working_dir: Project working directory
        recent_files: Recently modified files
        recent_commits: Recent git commits
        recent_errors: Recent errors from logs
        git_available: Whether git is available in this project
    """

    working_dir: str
    recent_files: List[FileInfo]
    recent_commits: List[GitCommitInfo]
    recent_errors: List[ErrorInfo]
    git_available: bool


class ContextCollector:
    """Orchestrates collection of all local project context.

    Combines FileWatcher, GitManager (via subprocess), and ErrorTracker
    to build comprehensive tactical context for prompt enrichment.

    Example:
        collector = ContextCollector()
        context = collector.collect_project_context(
            project_dir="/home/user/myproject"
        )
        print(f"Found {len(context.recent_files)} files")
        print(f"Found {len(context.recent_commits)} commits")
        print(f"Found {len(context.recent_errors)} errors")
    """

    def __init__(
        self,
        file_lookback_minutes: int = 10,
        commit_lookback_count: int = 5,
        error_lookback_minutes: int = 30,
    ) -> None:
        """Initialize ContextCollector.

        Args:
            file_lookback_minutes: How far back to look for modified files
            commit_lookback_count: Number of recent commits to fetch
            error_lookback_minutes: How far back to look for errors
        """
        self.file_lookback_minutes = file_lookback_minutes
        self.commit_lookback_count = commit_lookback_count
        self.error_lookback_minutes = error_lookback_minutes

        self.file_watcher = FileWatcher()
        self.error_tracker = ErrorTracker()

    def collect_project_context(
        self,
        project_dir: str | Path,
    ) -> ProjectContext:
        """Collect all available context from project directory.

        Args:
            project_dir: Project root directory

        Returns:
            ProjectContext with all gathered information

        Raises:
            ValueError: If project_dir doesn't exist
        """
        project_path = Path(project_dir).resolve()

        if not project_path.exists():
            raise ValueError(f"Project directory does not exist: {project_dir}")

        # Collect file context
        recent_files = self._collect_file_context(project_path)

        # Collect git context
        recent_commits, git_available = self._collect_git_context(project_path)

        # Collect error context
        recent_errors = self._collect_error_context(project_path)

        return ProjectContext(
            working_dir=str(project_path),
            recent_files=recent_files,
            recent_commits=recent_commits,
            recent_errors=recent_errors,
            git_available=git_available,
        )

    def _collect_file_context(self, project_dir: Path) -> List[FileInfo]:
        """Collect recently modified files.

        Args:
            project_dir: Project directory

        Returns:
            List of FileInfo objects
        """
        try:
            return self.file_watcher.get_modified_files(
                project_dir=project_dir,
                since_minutes=self.file_lookback_minutes,
            )
        except Exception:
            # Return empty list if collection fails
            return []

    def _collect_git_context(self, project_dir: Path) -> tuple[List[GitCommitInfo], bool]:
        """Collect recent git commits.

        Uses subprocess to call git directly (instead of importing GitManager
        which would require the main Obra package).

        Args:
            project_dir: Project directory

        Returns:
            Tuple of (commit list, git_available flag)
        """
        commits: List[GitCommitInfo] = []
        git_available = False

        try:
            # Check if this is a git repository
            result = subprocess.run(
                ["git", "rev-parse", "--git-dir"],
                cwd=project_dir,
                capture_output=True,
                text=True,
                encoding="utf-8",
                timeout=5,
            )

            if result.returncode != 0:
                return commits, False

            git_available = True

            # Get recent commits with format: hash|message|author|date|files
            result = subprocess.run(
                [
                    "git",
                    "log",
                    f"-{self.commit_lookback_count}",
                    "--format=%h|%s|%an|%ar|",
                    "--numstat",
                ],
                cwd=project_dir,
                capture_output=True,
                text=True,
                encoding="utf-8",
                timeout=10,
            )

            if result.returncode == 0:
                commits = self._parse_git_log(result.stdout)

        except (subprocess.TimeoutExpired, FileNotFoundError, PermissionError):
            # Git not available or timeout
            pass

        return commits, git_available

    def _parse_git_log(self, git_log_output: str) -> List[GitCommitInfo]:
        """Parse git log output into GitCommitInfo objects.

        Args:
            git_log_output: Raw output from git log command

        Returns:
            List of GitCommitInfo objects
        """
        commits: List[GitCommitInfo] = []
        current_commit: Optional[GitCommitInfo] = None
        files_changed = 0

        for line in git_log_output.splitlines():
            if "|" in line and line.count("|") >= 4:
                # This is a commit header line
                if current_commit:
                    # Save previous commit
                    current_commit.files_changed = files_changed
                    commits.append(current_commit)
                    files_changed = 0

                # Parse new commit
                parts = line.split("|", 4)
                current_commit = GitCommitInfo(
                    hash=parts[0].strip(),
                    message=parts[1].strip(),
                    author=parts[2].strip(),
                    timestamp=parts[3].strip(),
                    files_changed=0,  # Will be set when next commit starts
                )

            elif line.strip() and current_commit:
                # This is a file stat line (from --numstat)
                files_changed += 1

        # Don't forget the last commit
        if current_commit:
            current_commit.files_changed = files_changed
            commits.append(current_commit)

        return commits

    def _collect_error_context(self, project_dir: Path) -> List[ErrorInfo]:
        """Collect recent errors from log files.

        Args:
            project_dir: Project directory

        Returns:
            List of ErrorInfo objects
        """
        try:
            return self.error_tracker.get_recent_errors(
                project_dir=project_dir,
                since_minutes=self.error_lookback_minutes,
            )
        except Exception:
            # Return empty list if collection fails
            return []

    def format_for_prompt(self, context: ProjectContext) -> str:
        """Format project context for prompt injection.

        Args:
            context: ProjectContext object

        Returns:
            Formatted string for Tier 2 enrichment

        Example Output:
            ## Local Context (Provided by Client)

            Working Directory: /home/user/myproject

            Recent Files (modified in last 10 minutes):
              - src/auth.py (2.5m ago, 1.2KB)
              - tests/test_auth.py (5.1m ago, 3.4KB)

            Recent Commits (last 5):
              - a1b2c3d "Add JWT authentication" by Alice (2 hours ago, 3 files)
              - d4e5f6g "Fix login endpoint" by Bob (5 hours ago, 1 file)

            Recent Errors (last 30 minutes):
              - ValueError at src/auth.py:42 (15.3m ago)
                Message: Invalid token format
        """
        sections = [
            "## Local Context (Provided by Client)",
            "",
            f"Working Directory: {context.working_dir}",
            "",
        ]

        # Files section
        if context.recent_files:
            sections.append(self.file_watcher.format_for_prompt(context.recent_files))
        else:
            sections.append("Recent Files: None")

        sections.append("")

        # Commits section
        if context.git_available and context.recent_commits:
            sections.append(
                f"Recent Commits (last {self.commit_lookback_count}):"
            )
            for commit in context.recent_commits:
                # Truncate long commit messages
                message = commit.message
                if len(message) > 60:
                    message = message[:60] + "..."

                sections.append(
                    f'  - {commit.hash} "{message}" by {commit.author} '
                    f"({commit.timestamp}, {commit.files_changed} files)"
                )
        elif not context.git_available:
            sections.append("Git: Not available (not a git repository)")
        else:
            sections.append("Recent Commits: None")

        sections.append("")

        # Errors section
        if context.recent_errors:
            sections.append(self.error_tracker.format_for_prompt(context.recent_errors))
        else:
            sections.append("Recent Errors: None")

        return "\n".join(sections)
