"""Bundled documentation for Obra Client.

This package contains documentation files bundled in the wheel:
- ONBOARDING.txt: Getting started guide for agent onboarding
- USAGE_EXAMPLES.txt: Common usage patterns and examples

These documents are accessible via importlib.resources and can be
displayed by agents or included in prompts.
"""

from importlib import resources


def get_onboarding() -> str:
    """Get the agent onboarding documentation.

    This document explains how to use the Obra client for LLM agents,
    including setup, commands, and best practices.

    Returns:
        Content of ONBOARDING.txt
    """
    return resources.files(__package__).joinpath("ONBOARDING.txt").read_text()


def get_usage_examples() -> str:
    """Get usage examples for common Obra workflows.

    This document provides copy-paste examples for common operations.

    Returns:
        Content of USAGE_EXAMPLES.txt
    """
    return resources.files(__package__).joinpath("USAGE_EXAMPLES.txt").read_text()
