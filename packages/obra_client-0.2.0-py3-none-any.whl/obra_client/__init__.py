"""Obra SaaS Client - LLM Proxy with Prompt Enrichment.

This client connects to Obra Firebase Cloud Functions for orchestration,
enriches prompts with local project context, and executes LLM calls locally.

Architecture:
    - Tier 1 (Server): Strategic context generation (objectives, requirements, validation)
    - Tier 2 (Client): Tactical context injection (files, git, errors)

Usage:
    obra-client setup                     # First-run configuration
    obra-client orchestrate "Add auth"    # Start orchestration session
    obra-client status SESSION_ID         # Check session status
"""

from importlib.metadata import PackageNotFoundError, version

from obra_client.exceptions import (
    APIError,
    ConfigurationError,
    ExecutionError,
    ObraClientError,
)

try:
    __version__ = version("obra-client")
except PackageNotFoundError:
    # Package not installed (running from source)
    __version__ = "0.0.0-dev"

__author__ = "Omar Unpossible"

__all__ = [
    "APIError",
    "ConfigurationError",
    "ExecutionError",
    "ObraClientError",
    "__author__",
    "__version__",
]
