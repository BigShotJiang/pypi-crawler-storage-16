"""Console utilities for Obra Client.

This module provides a configured Rich Console and error handling utilities.

Encoding Strategy (following Python best practices):
---------------------------------------------------
UTF-8 mode is enforced at CLI startup in cli.py. This is the standard
approach used by major Python CLI tools (pip, poetry, black, etc.).

If encoding issues still occur despite UTF-8 enforcement, the
handle_encoding_errors decorator provides helpful guidance to users,
following Rich's own recommendation (GitHub Issue #212).

References:
- https://dev.to/methane/python-use-utf-8-mode-on-windows-212i
- https://peps.python.org/pep-0529/
- https://github.com/willmcgugan/rich/issues/212
"""

import functools
from typing import Any, Callable, TypeVar

from rich.console import Console

# Type variable for decorator
F = TypeVar("F", bound=Callable[..., Any])


def handle_encoding_errors(func: F) -> F:
    """Decorator to catch encoding errors with user-friendly messages.

    This follows Rich's recommended approach: when encoding fails,
    provide clear guidance on how to fix the environment rather than
    silently degrading functionality.

    Example:
        @app.command()
        @handle_encoding_errors
        def my_command():
            console.print("🚀 Starting...")
    """

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            return func(*args, **kwargs)
        except UnicodeEncodeError as e:
            # Use raw print to avoid any Rich formatting issues
            print("\n[ERROR] Terminal encoding issue detected.")
            print(f"        Character: {e.object[e.start:e.end]!r}")
            print("\nThis usually means your terminal is not configured for UTF-8.")
            print("\nSolutions:")
            print("  1. Use Windows Terminal (recommended) instead of cmd.exe")
            print("  2. Set environment variable: PYTHONUTF8=1")
            print("  3. Set environment variable: PYTHONIOENCODING=utf-8")
            print("  4. In cmd.exe, run: chcp 65001")
            print("\nFor more info: https://obra.dev/docs/troubleshooting/windows-unicode")

            # Import typer here to avoid circular imports
            import typer

            raise typer.Exit(1)

    return wrapper  # type: ignore[return-value]


# Module-level console instance
# Standard Rich Console - UTF-8 is enforced at CLI startup
console = Console()
