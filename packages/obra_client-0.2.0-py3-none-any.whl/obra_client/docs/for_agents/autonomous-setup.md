# Autonomous Setup Guide for LLM Agents

> **Document Purpose**: Step-by-step setup guide optimized for LLM agents to install and configure Obra autonomously.

---

## Your Role: During vs After Setup

```yaml
during_setup:
  role: EXECUTOR
  action: "Run commands directly to install and configure"

after_setup:
  role: TASK_ARCHITECT
  action: "Formulate prompts, delegate to Obra, DO NOT write code"
```

> **IMPORTANT**: Once Obra is set up, your role changes. You become a **task architect** - formulating detailed prompts and sending them to Obra. See `capability-brief.md` for the delegation protocol.

---

## Quick Reference

```yaml
package: obra-client
install: "pip install obra-client"
auth: "obra-client login"
verify: "obra-client health-check"
use_simple: "obra-client execute '<task>'"
use_advanced: "obra-client interactive -c '<task>' -c '/execute 1' -c '/exit'"
```

---

## Context

```yaml
what: "Obra = AI orchestration platform for autonomous software development"
deployment: "SaaS (recommended) via obra-client package"
architecture: "Two-Tier Prompting - server generates prompts, client executes locally"
privacy: "Your code never leaves your machine"
prerequisites:
  - "Python 3.12+"
  - "LLM CLI: Claude Code, Gemini CLI, or OpenAI Codex"
outcome: "User can run obra-client interactive successfully"
```

---

## Installation Flow

### Step 1: Verify Python

```bash
python --version
# Required: Python 3.12 or higher
```

```yaml
if_version_too_low:
  windows: "Download from python.org, ensure 'Add to PATH' checked"
  macos: "brew install python@3.12"
  linux: "sudo apt install python3.12 python3.12-venv"
```

### Step 2: Install obra-client

```bash
# Option A: pip (recommended)
pip install obra-client

# Option B: pipx (isolated environment)
pipx install obra-client
```

**Verify installation**:
```bash
obra-client version
# Expected: obra-client 0.1.24 or higher
```

### Step 3: Authenticate

```bash
obra-client login
```

**What happens**:
1. Browser opens to Google OAuth page
2. User signs in with Google account
3. Token saved locally to `~/.obra/config.json`
4. Terminal shows "Login successful"

```yaml
error_patterns:
  "Browser didn't open":
    cause: "No default browser or headless environment"
    fix: "Copy URL from terminal, paste in browser manually"
  "Not authorized":
    cause: "Email not on beta allowlist"
    fix: "Contact support@obra.dev for beta access"
  "Connection refused":
    cause: "Network/firewall blocking"
    fix: "Check internet, try different network"
```

**Verify authentication**:
```bash
obra-client whoami
# Expected: Shows email and auth status
```

### Step 4: Verify LLM CLI

Obra needs an LLM CLI for code execution. Verify one is available:

```bash
# Check for Claude Code (recommended)
claude --version

# OR check for Gemini CLI
gemini --version

# OR check for OpenAI Codex
codex --version
```

```yaml
if_no_llm_cli:
  claude_code:
    install: "npm install -g @anthropic-ai/claude-code"
    docs: "https://docs.anthropic.com/claude-code"
  gemini_cli:
    install: "pip install google-generativeai"
    docs: "https://ai.google.dev/gemini-api/docs"
  openai_codex:
    install: "npm install -g @openai/codex"
    docs: "https://platform.openai.com/docs"
```

### Step 5: Run Health Check

```bash
obra-client health-check
```

**Expected output**:
```
1. Python Version
   ✓ Python 3.12+

2. Configuration
   ✓ Authentication valid

3. API/Database Connectivity
   ✓ API reachable

4. LLM CLI
   ✓ LLM CLI found: claude
```

```yaml
error_patterns:
  "Authentication not valid":
    fix: "obra-client login"
  "API not reachable":
    fix: "Check internet connection"
  "LLM CLI not found":
    fix: "Install Claude Code, Gemini CLI, or OpenAI Codex"
```

### Step 6: Functional Test

```bash
obra-client interactive -c "/status" -c "/exit"
```

**Expected**: Shows orchestrator state without errors.

---

## Setup Complete Checklist

```yaml
checklist:
  - "[ ] Python 3.12+ installed"
  - "[ ] obra-client installed (pip install obra-client)"
  - "[ ] Authenticated (obra-client login)"
  - "[ ] LLM CLI available (claude/gemini/codex)"
  - "[ ] Health check passes (obra-client health-check)"
  - "[ ] Functional test works (obra-client interactive -c '/status' -c '/exit')"
```

---

## First Task Example

Once setup is complete, delegate a simple task to verify end-to-end:

```bash
obra-client interactive \
  -c "Create a task to add a hello world function to src/hello.py with a test" \
  -c "/execute 1" \
  -c "/exit"
```

**Expected flow**:
1. Session created
2. Task created
3. LLM executes task
4. Results displayed with status, quality score

---

## OS-Specific Notes

### Windows

```yaml
path_separator: "\\"
shell: "PowerShell or Command Prompt"
python_command: "python" or "py"
common_issues:
  - "Python not in PATH": "Reinstall Python, check 'Add to PATH'"
  - "Permission denied": "Run as Administrator or use --user flag"
```

### macOS

```yaml
path_separator: "/"
shell: "zsh (default) or bash"
python_command: "python3"
common_issues:
  - "python command not found": "Use python3 instead"
  - "SSL certificate errors": "Install certificates: /Applications/Python*/Install Certificates.command"
```

### Linux

```yaml
path_separator: "/"
shell: "bash"
python_command: "python3"
common_issues:
  - "pip not found": "sudo apt install python3-pip"
  - "Permission denied": "Use pip install --user or virtual environment"
```

### WSL (Windows Subsystem for Linux)

```yaml
notes:
  - "Treat as Linux for commands"
  - "Windows paths accessible via /mnt/c/"
  - "Browser login opens in Windows browser (works correctly)"
```

---

## Error Recovery

### Authentication Errors

| Error | Cause | Fix |
|-------|-------|-----|
| "Not authenticated" | No token | `obra-client login` |
| "Token expired" | Session timeout | `obra-client login` (refreshes) |
| "403 Forbidden" | Not on allowlist | Contact support for beta access |

### Installation Errors

| Error | Cause | Fix |
|-------|-------|-----|
| "pip not found" | Python not properly installed | Reinstall Python |
| "Permission denied" | No write access | `pip install --user obra-client` |
| "Module not found" | Path issues | Verify pip location in PATH |

### Execution Errors

| Error | Cause | Fix |
|-------|-------|-----|
| "LLM CLI not found" | Not installed or not in PATH | Install LLM CLI, restart terminal |
| "Session not found" | Session expired | Start new session |
| "API error 500" | Server error | Retry in a few minutes |

---

## Troubleshooting Commands

```bash
# Check installation
obra-client version

# Check authentication
obra-client whoami

# Full health check
obra-client health-check

# View current config
obra-client config show

# Clear auth and re-login
obra-client logout
obra-client login
```

---

## After Setup: Your Role Changes

```yaml
before_setup:
  you_do: "Run installation commands"

after_setup:
  you_do: "Formulate detailed prompts"
  you_dont: "Write code directly"
  obra_does: "Plan, execute, validate, iterate"
```

**Key principle**: Once Obra is set up, you become a **task architect**. Your job is to:

1. Understand what the user wants built
2. Formulate a clear prompt with:
   - Objective
   - Requirements
   - Deliverables
   - Success criteria
3. Send the prompt to Obra via `obra-client interactive -c "..."`
4. Review and report results

**See `capability-brief.md` for the full delegation protocol.**

---

## Quick Command Reference

```yaml
commands:
  install: "pip install obra-client"
  login: "obra-client login"
  logout: "obra-client logout"
  whoami: "obra-client whoami"
  version: "obra-client version"
  health: "obra-client health-check"
  config: "obra-client config show"
  interactive: "obra-client interactive"
  scripted: "obra-client interactive -c '<cmd>' -c '<cmd>' -c '/exit'"
```

---

## Further Reading

- **[capability-brief.md](capability-brief.md)** - When and how to use Obra
- **[task-templates.md](task-templates.md)** - Copy-paste task examples
