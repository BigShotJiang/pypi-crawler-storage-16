"""CLI entry point for Obra Client."""

# =============================================================================
# UTF-8 Enforcement (MUST be before any imports that might print)
# =============================================================================
# This follows Python best practices for Windows encoding:
# - https://dev.to/methane/python-use-utf-8-mode-on-windows-212i
# - https://peps.python.org/pep-0529/
# - Rich GitHub Issue #212
#
# Standard Python CLI tools (pip, poetry, black) don't use ASCII fallback -
# they expect UTF-8 to work. We do the same.
# =============================================================================
import os
import sys

if sys.platform == 'win32':
    # Enable Python UTF-8 mode for consistent encoding behavior
    os.environ.setdefault('PYTHONUTF8', '1')
    os.environ.setdefault('PYTHONIOENCODING', 'utf-8')

    # Reconfigure stdout/stderr if already initialized
    # This handles cases where Python was started without UTF-8 mode
    if hasattr(sys.stdout, 'reconfigure'):
        try:
            sys.stdout.reconfigure(encoding='utf-8', errors='backslashreplace')
        except Exception:
            pass
    if hasattr(sys.stderr, 'reconfigure'):
        try:
            sys.stderr.reconfigure(encoding='utf-8', errors='backslashreplace')
        except Exception:
            pass

# =============================================================================
# Standard imports (safe now that UTF-8 is enforced)
# =============================================================================
import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import typer
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Prompt

from obra_client.console import console, handle_encoding_errors

from obra_client import __version__
from obra_client.api_client import APIClient
from obra_client.config import (
    DEFAULT_API_BASE_URL,
    DEFAULT_AUTH_METHOD,
    DEFAULT_MODEL,
    DEFAULT_PROVIDER,
    FIREBASE_API_KEY,
    LLM_AUTH_METHODS,
    LLM_PROVIDERS,
    PRIVACY_VERSION,
    TERMS_VERSION,
    build_llm_args,
    clear_firebase_auth,
    get_auth_provider,
    get_firebase_uid,
    get_llm_cli,
    get_llm_config,
    get_llm_display,
    get_llm_timeout,
    get_refresh_token,
    get_user_email,
    is_authenticated,
    is_terms_accepted,
    load_config,
    needs_reacceptance,
    resolve_llm_config,
    save_config,
    save_firebase_auth,
    save_terms_acceptance,
    set_llm_config,
    validate_model,
)
from obra_client.exceptions import (
    APIError,
    AuthenticationError,
    ConfigurationError,
    ExecutionError,
    TermsNotAcceptedError,
)
from obra_client.executor import LLMExecutor
from obra_client.legal import get_terms_summary
from obra_client.prompt_enricher import PromptEnricher
from obra_client.session_manager import SessionManager
from obra_client.version_check import VersionChecker

app = typer.Typer(
    name="obra-client",
    help=(
        "Obra SaaS Client - AI orchestration for autonomous software development.\n\n"
        "FOR LLM AGENTS: Run 'obra-client docs agent-capabilities' to read the "
        "capability brief, or 'obra-client docs agent-path' to get the filesystem "
        "path to documentation files."
    ),
    add_completion=False,
)

# Console is imported from obra_client.console (line 49)


# =============================================================================
# Session Override Dataclasses
# =============================================================================


@dataclass
class LLMOverride:
    """Session-only LLM configuration override.

    Used for CLI flags that override config file settings
    without persisting changes.
    """

    provider: Optional[str] = None
    interface: Optional[str] = None  # "oauth" or "api_key"
    model: Optional[str] = None


def require_config() -> dict:
    """Load configuration and verify it exists.

    Returns:
        Configuration dictionary

    Raises:
        ConfigurationError: If config file doesn't exist or is invalid
    """
    from obra_client.config import CONFIG_PATH

    config = load_config()
    if not config:
        raise ConfigurationError(
            f"Configuration file not found: {CONFIG_PATH}\n"
            "Run 'obra-client setup' to create it."
        )
    return config


def require_terms_accepted() -> None:
    """Check if terms have been accepted, exit if not.

    This is a HARD STOP GATE - commands cannot proceed without terms acceptance.

    Raises:
        typer.Exit: If terms not accepted (exit code 1)
    """
    if not is_terms_accepted():
        console.print("\n[red]Terms not accepted.[/red]")
        console.print("Run 'obra-client setup' first to accept the Beta Terms.")
        raise typer.Exit(1)

    # Check for version mismatch (re-acceptance needed)
    if needs_reacceptance():
        console.print("\n[yellow]Terms have been updated (v{TERMS_VERSION}).[/yellow]")
        console.print("Run 'obra-client setup' to accept the updated terms.")
        raise typer.Exit(1)


@app.command()
@handle_encoding_errors
def setup() -> None:
    """Run first-time setup with REQUIRED terms acceptance.

    This command MUST be run before using any other obra-client commands.
    It performs these steps:

    1. Terms Acceptance (REQUIRED): Display and accept Beta Terms + Privacy Policy
    2. Authentication: Sign in with Firebase Auth (Google or GitHub OAuth)
    3. LLM Configuration: Configure implementation LLM settings

    The terms acceptance is a legal requirement - you cannot use obra-client
    without accepting the terms.

    Creates ~/.obra/client-config.yaml with configuration and acceptance state.
    """
    from obra_client.auth import (
        login_with_browser,
        save_auth,
        verify_beta_access,
    )
    from obra_client.config import CONFIG_PATH

    console.print(f"\n[bold]OBRA CLIENT SETUP[/bold] [dim]v{__version__}[/dim]")
    console.print("=" * 70)

    # Check if already set up
    existing_config = load_config()
    existing_acceptance = is_terms_accepted()
    already_authenticated = is_authenticated()

    if existing_config and existing_acceptance and already_authenticated:
        console.print(f"\n[green]✓[/green] Configuration exists: {CONFIG_PATH}")
        console.print(f"[green]✓[/green] Terms v{TERMS_VERSION} already accepted")
        console.print(f"[green]✓[/green] Signed in as: {get_user_email()}")
        console.print("\n[dim]To reconfigure, delete ~/.obra/client-config.yaml and run setup again.[/dim]")
        raise typer.Exit(0)

    # Check if re-acceptance needed (version change)
    if needs_reacceptance():
        console.print("\n[yellow]Terms have been updated. Re-acceptance required.[/yellow]")

    # =========================================================================
    # STEP 1: Terms Acceptance (REQUIRED - HARD STOP GATE)
    # =========================================================================
    if not existing_acceptance or needs_reacceptance():
        console.print("\n[bold red]STEP 1: TERMS ACCEPTANCE (REQUIRED)[/bold red]")
        console.print("-" * 70)
        console.print()

        # Display Plain Language Summary
        terms_summary = get_terms_summary()
        console.print(Panel(
            terms_summary,
            title="[bold red]PLAIN LANGUAGE SUMMARY[/bold red]",
            border_style="red",
        ))

        console.print()
        console.print("[bold]Full documents:[/bold]")
        console.print("  Terms:   [link=https://obra.dev/terms]https://obra.dev/terms[/link]")
        console.print("  Privacy: [link=https://obra.dev/privacy]https://obra.dev/privacy[/link]")
        console.print()
        console.print("[dim]Tip: Open these URLs in your browser before accepting.[/dim]")
        console.print()

        # Display acceptance confirmations (12 items from BETA_TERMS.md v2.1)
        console.print("[bold]BY TYPING \"I ACCEPT\", YOU CONFIRM THAT:[/bold]")
        console.print()
        confirmations = [
            "You have had the OPPORTUNITY TO READ the full terms and UNDERSTAND they are legally binding",
            "You AGREE to be legally bound by all terms",
            "You are using this as an INDIVIDUAL on personal equipment",
            "You are NOT using any Employer Systems or corporate equipment",
            "You are NOT using this for any business or organizational purpose",
            "You MEET all requirements in Section 3 (Tester Representations)",
            "You ACCEPT all risks described in Section 15 (Assumption of Risk)",
            "You AGREE to BINDING ARBITRATION (Section 23, with exceptions)",
            "You WAIVE your right to participate in class actions (Section 25)",
            "You WAIVE your right to a jury trial (Section 25)",
            "You UNDERSTAND certain provisions survive termination (Section 21)",
            "You had OPPORTUNITY TO CONSULT WITH LEGAL COUNSEL before accepting",
        ]
        for i, conf in enumerate(confirmations, 1):
            console.print(f"  [bold]{i:2}.[/bold] {conf}")

        console.print()
        console.print("[bold yellow]Type \"I ACCEPT\" to accept all terms, or \"EXIT\" to abort.[/bold yellow]")
        console.print()

        # Get user input
        user_input = typer.prompt("Your response").strip()

        if user_input.upper() == "EXIT":
            console.print("\n[dim]Setup aborted. You must accept the terms to use obra-client.[/dim]")
            raise typer.Exit(0)

        if user_input.upper() != "I ACCEPT":
            console.print("\n[red]Invalid response. You must type exactly \"I ACCEPT\" to proceed.[/red]")
            console.print("[dim]Run 'obra setup' again to retry.[/dim]")
            raise typer.Exit(1)

        console.print("\n[green]✓[/green] Terms acceptance recorded")

        # Save terms acceptance LOCALLY (will be registered with server after auth)
        save_terms_acceptance(TERMS_VERSION, PRIVACY_VERSION)
        console.print(f"[green]✓[/green] Local acceptance cache saved (v{TERMS_VERSION})")
    else:
        console.print(f"\n[green]✓[/green] Terms v{TERMS_VERSION} already accepted")

    # =========================================================================
    # STEP 2: Firebase Authentication
    # =========================================================================
    console.print("\n[bold]STEP 2: AUTHENTICATION[/bold]")
    console.print("-" * 70)

    if already_authenticated:
        email = get_user_email()
        console.print(f"\n[green]✓[/green] Already signed in as: {email}")
        auth_result = None
    else:
        console.print("\n[dim]Sign in with your Google or GitHub account.[/dim]")
        console.print("[dim]Your email must be on the beta allowlist.[/dim]")
        console.print()
        console.print("[bold]Opening browser for authentication...[/bold]")
        console.print("[dim]Waiting for authentication (timeout: 5 minutes)...[/dim]\n")

        try:
            # Perform browser OAuth
            auth_result = login_with_browser(timeout=300)

            console.print(f"[green]✓[/green] Signed in as: {auth_result.email}")
            console.print(f"[dim]  Provider: {auth_result.auth_provider}[/dim]")

            # Verify beta access
            console.print("\n[bold]Verifying beta access...[/bold]")

            try:
                verify_beta_access(auth_result.id_token, DEFAULT_API_BASE_URL)
                console.print(f"[green]✓[/green] Beta access verified")
            except AuthenticationError as e:
                console.print(f"\n[red]✗ Access denied:[/red] {e}")
                console.print("\n[dim]Your authentication succeeded, but you don't have beta access.[/dim]")
                console.print("[dim]Contact the Obra team to request access.[/dim]")
                raise typer.Exit(1)

            # Save authentication
            save_auth(auth_result)
            console.print(f"[green]✓[/green] Authentication saved")

        except AuthenticationError as e:
            console.print(f"\n[red]✗ Authentication failed:[/red] {e}")
            raise typer.Exit(1)

        except TimeoutError as e:
            console.print(f"\n[red]✗ Timeout:[/red] {e}")
            console.print("[dim]The browser sign-in was not completed in time.[/dim]")
            raise typer.Exit(1)

        except Exception as e:
            console.print(f"\n[red]✗ Unexpected error:[/red] {e}")
            raise typer.Exit(1)

    # =========================================================================
    # STEP 3: Register Terms Acceptance with Server
    # =========================================================================
    console.print("\n[bold]STEP 3: VERIFICATION[/bold]")
    console.print("-" * 70)

    # Initialize basic config
    config = load_config()
    config["api_base_url"] = DEFAULT_API_BASE_URL
    config["firebase_api_key"] = FIREBASE_API_KEY
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    save_config(config)

    try:
        # Create authenticated API client
        api_client = APIClient(
            base_url=DEFAULT_API_BASE_URL,
            auth_token=config.get("auth_token"),
            refresh_token=config.get("refresh_token"),
            firebase_api_key=FIREBASE_API_KEY,
        )

        # Check health
        health = api_client.health_check()
        console.print(f"[green]✓[/green] API reachable (status: {health['status']})")

        # Check version
        version_info = api_client.get_version()
        console.print(f"[green]✓[/green] API version: {version_info['api_version']}")

        # Check client compatibility
        min_version = version_info.get("min_client_version", "0.1.0")
        if __version__ < min_version:
            console.print(
                f"\n[yellow]⚠ Warning: Client version ({__version__}) "
                f"below minimum ({min_version})[/yellow]"
            )
            console.print("[dim]Consider: pip install --upgrade obra-client[/dim]")

        # Register terms acceptance with server
        console.print("\n[bold]Registering terms acceptance with server...[/bold]")
        server_logged = api_client.log_terms_acceptance(
            terms_version=TERMS_VERSION,
            privacy_version=PRIVACY_VERSION,
            client_version=__version__,
            source="cli_setup",
            user_id=get_firebase_uid(),
            email=get_user_email(),
        )
        if server_logged:
            console.print("[green]✓[/green] Terms acceptance registered with server")
        else:
            console.print("[yellow]⚠[/yellow] Could not register terms acceptance with server")
            console.print("[dim]Local acceptance is saved. Server registration will be retried on next use.[/dim]")

    except APIError as e:
        console.print(f"[yellow]⚠[/yellow] Could not verify API: {e}")
        console.print("[dim]You can still use the client, check API URL if issues persist.[/dim]")

    # =========================================================================
    # STEP 4: LLM Configuration
    # =========================================================================
    console.print("\n[bold]STEP 4: LLM CONFIGURATION[/bold]")
    console.print("-" * 70)
    console.print()
    console.print("[dim]Obra uses two LLMs:[/dim]")
    console.print("[dim]  • Orchestrator: Plans and coordinates tasks (server-side)[/dim]")
    console.print("[dim]  • Implementation: Executes code changes (local)[/dim]")
    console.print()

    # Configure both roles
    env_vars_needed = set()
    oauth_logins_needed = set()

    for role in ["orchestrator", "implementation"]:
        role_display = role.capitalize()
        console.print(f"\n[bold cyan]━━━ {role_display} LLM ━━━[/bold cyan]")
        console.print()

        # Step 1: Provider selection
        console.print("[bold]1. Select Provider:[/bold]")
        provider_keys = list(LLM_PROVIDERS.keys())
        for i, key in enumerate(provider_keys, 1):
            info = LLM_PROVIDERS[key]
            default_marker = " [green](recommended)[/green]" if key == DEFAULT_PROVIDER else ""
            console.print(f"   {i}. {info['name']}{default_marker} - {info['description']}")

        provider_choice = typer.prompt(
            f"   Select (1-{len(provider_keys)})",
            default="1",
        )

        try:
            provider_idx = int(provider_choice) - 1
            if provider_idx < 0 or provider_idx >= len(provider_keys):
                provider_idx = 0
            selected_provider = provider_keys[provider_idx]
        except ValueError:
            selected_provider = DEFAULT_PROVIDER

        provider_info = LLM_PROVIDERS[selected_provider]

        # Step 2: Auth method selection
        console.print()
        console.print("[bold]2. Select Auth Method:[/bold]")
        auth_keys = list(LLM_AUTH_METHODS.keys())
        for i, key in enumerate(auth_keys, 1):
            info = LLM_AUTH_METHODS[key]
            default_marker = " [green](recommended)[/green]" if key == "oauth" else ""
            console.print(f"   {i}. {info['name']}{default_marker}")
            console.print(f"      [dim]{info['description']}[/dim]")
            if key == "api_key":
                console.print(f"      [yellow]{info['note']}[/yellow]")

        auth_choice = typer.prompt(
            f"   Select (1-{len(auth_keys)})",
            default="1",
        )

        try:
            auth_idx = int(auth_choice) - 1
            if auth_idx < 0 or auth_idx >= len(auth_keys):
                auth_idx = 0
            selected_auth = auth_keys[auth_idx]
        except ValueError:
            selected_auth = DEFAULT_AUTH_METHOD

        # Step 3: Model selection (only for API Key auth)
        if selected_auth == "oauth":
            # OAuth users get "default" automatically - simplest path
            selected_model = "default"
            console.print()
            console.print("   [green]✓[/green] Model: default (provider's optimal choice)")
            console.print("   [dim]OAuth uses the provider's recommended model automatically.[/dim]")
        else:
            # API Key users can choose their model
            console.print()
            console.print("[bold]3. Select Model:[/bold]")

            models = provider_info["models"]
            for i, model in enumerate(models, 1):
                if model == "default":
                    console.print(f"   {i}. default - Provider's optimal choice")
                else:
                    console.print(f"   {i}. {model}")

            model_choice = typer.prompt(
                f"   Select (1-{len(models)})",
                default="1",
            )

            try:
                model_idx = int(model_choice) - 1
                if model_idx < 0 or model_idx >= len(models):
                    model_idx = 0
                selected_model = models[model_idx]
            except ValueError:
                selected_model = DEFAULT_MODEL

        # Save config for this role
        set_llm_config(role, selected_provider, selected_auth, selected_model)

        # Track auth requirements
        if selected_auth == "oauth":
            # OAuth uses browser-based login
            cli = provider_info.get("cli", "claude")
            oauth_logins_needed.add((provider_info["name"], cli))
        else:
            # API Key auth needs env var
            api_key_env = provider_info.get("api_key_env_var")
            if api_key_env:
                env_vars_needed.add(api_key_env)

        # Show confirmation
        console.print()
        console.print(f"   [green]✓[/green] {role_display}: {get_llm_display(role)}")

    # =========================================================================
    # Complete
    # =========================================================================
    console.print("\n" + "=" * 70)
    console.print("[bold green]SETUP COMPLETE[/bold green]")
    console.print("=" * 70)

    # Show auth requirements
    if oauth_logins_needed:
        console.print("\n[bold]OAuth Login Required:[/bold]")
        console.print("  [dim]Run these commands to authenticate (browser-based):[/dim]")
        for provider_name, cli in sorted(oauth_logins_needed):
            console.print(f"  {cli} --login          # {provider_name}")

    if env_vars_needed:
        console.print("\n[bold]API Key Required:[/bold]")
        console.print("  [dim]Set these environment variables:[/dim]")
        for env_var in sorted(env_vars_needed):
            console.print(f"  export {env_var}='your-api-key'")  # pragma: allowlist secret

    console.print()
    console.print("[bold]LLM Configuration Summary:[/bold]")
    console.print(f"  Orchestrator:    {get_llm_display('orchestrator')}")
    console.print(f"  Implementation:  {get_llm_display('implementation')}")

    console.print("\n[bold]Quick Start:[/bold]")
    console.print("  obra-client interactive          # Start REPL for iterative work")
    console.print("  obra-client orchestrate \"task\"   # One-shot task execution")
    console.print("  obra-client health-check         # Verify installation")

    console.print("\n[bold]Troubleshooting:[/bold]")
    console.print("  obra-client health-check         # Diagnose issues")
    console.print("  obra-client version              # Check compatibility")

    console.print(f"\n[dim]Config saved to: {CONFIG_PATH}[/dim]")
    console.print("[dim]To reconfigure: delete config file and run 'obra-client setup' again[/dim]")

    # Agent automation nudge - prominent suggestion
    console.print("\n" + "=" * 70)
    console.print("[bold cyan]OPERATE OBRA WITH YOUR LLM[/bold cyan]")
    console.print("=" * 70)
    console.print()
    console.print("Obra is designed to be operated by LLM agents (Claude, GPT, etc.).")
    console.print("Get a ready-to-use prompt for your AI agent:")
    console.print()
    console.print("  [bold]obra-client docs agent-prompt[/bold]")
    console.print()
    console.print("Copy the output and paste it to Claude, ChatGPT, or any LLM.")
    console.print()


@app.command()
@handle_encoding_errors
def orchestrate(
    objective: str,
    project_dir: Optional[str] = None,
    task_type: str = "feature",
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed debug output"),
) -> None:
    """Start orchestration session with Cloud Functions.

    Args:
        objective: Task objective (e.g., "Add user authentication")
        project_dir: Project directory (default: current directory)
        task_type: Type of task (feature, bug_fix, refactor, etc.)
        verbose: Show detailed debug output including server responses

    Example:
        obra-client orchestrate "Add rate limiting to API"
        obra-client orchestrate "Fix login bug" --task-type bug_fix
        obra-client orchestrate "Add feature" --verbose
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    try:
        # Load configuration
        config = require_config()

        # Determine project directory
        working_dir = Path(project_dir or os.getcwd()).resolve()

        if not working_dir.exists():
            console.print(f"[red]❌ Project directory not found: {working_dir}[/red]")
            raise typer.Exit(1)

        console.print(f"\n[bold]🚀 Starting Orchestration[/bold]")
        console.print(f"[dim]Objective:[/dim] {objective}")
        console.print(f"[dim]Project:[/dim] {working_dir}")
        console.print(f"[dim]Type:[/dim] {task_type}")

        # Initialize components
        # Use from_config() to enable automatic token refresh
        api_client = APIClient.from_config()

        enricher = PromptEnricher()

        # Resolve LLM configuration for implementation agent
        impl_config = resolve_llm_config("implementation")
        impl_args = build_llm_args(impl_config)
        impl_cli = config.get("llm_cli_path") or config.get("claude_code_path") or get_llm_cli(impl_config["provider"])

        # Show active LLM configuration
        model_display = impl_config["model"] if impl_config["model"] != "default" else "default"
        console.print(f"[dim]LLM:[/dim] {impl_config['provider']} ({model_display})\n")

        executor = LLMExecutor(
            cli_path=impl_cli,
            timeout=get_llm_timeout(),
            base_args=impl_args,
        )

        session_manager = SessionManager()

        # Step 1: Start orchestration session
        console.print("[bold]📡 Contacting server...[/bold]")

        # Get user_id with fallback for configs created before user_id was added
        user_id = config.get("user_id") or config.get("user_email") or config.get("firebase_uid")
        if not user_id:
            return False, None, "No user ID found. Please run 'obra login' to authenticate."

        session_response = api_client.orchestrate(
            user_id=user_id,
            project_id=config.get("project_id", "default"),
            working_dir=str(working_dir),
            objective=objective,
            task_type=task_type,
        )

        session_id = session_response["session_id"]
        base_prompt = session_response["base_prompt"]

        console.print(f"[green]✓[/green] Session created: [dim]{session_id}[/dim]\n")

        if verbose:
            console.print("[dim]─── Server Response ───[/dim]")
            console.print(f"[dim]  Status: {session_response.get('status', 'N/A')}[/dim]")
            console.print(f"[dim]  Base prompt: {len(base_prompt)} chars[/dim]")
            if session_response.get("metadata"):
                console.print(f"[dim]  Metadata: {json.dumps(session_response['metadata'], indent=2)}[/dim]")
            console.print("[dim]───────────────────────[/dim]\n")

        # Save checkpoint for resume capability
        session_manager.save_checkpoint(
            session_id=session_id,
            objective=objective,
            task_type=task_type,
            project_dir=str(working_dir),
            iteration=1,
            status="active",
        )

        # Orchestration loop
        iteration = 1
        max_iterations = 20  # Safety limit

        while iteration <= max_iterations:
            iteration_start = time.time()
            console.print(f"[bold]🔄 Iteration {iteration}[/bold]")

            # Step 2: Enrich prompt with local context
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                task = progress.add_task("Enriching prompt with local context...", total=None)
                enriched_prompt = enricher.enrich_prompt(base_prompt, str(working_dir))
                progress.update(task, completed=True)

            console.print(f"[green]✓[/green] Prompt enriched (~{len(enriched_prompt)} chars)\n")

            if verbose:
                console.print(f"[dim]  Base prompt: {len(base_prompt)} chars[/dim]")
                console.print(f"[dim]  Enriched prompt: {len(enriched_prompt)} chars[/dim]")
                console.print(f"[dim]  Context added: +{len(enriched_prompt) - len(base_prompt)} chars[/dim]")

            # Step 3: Execute LLM
            console.print("[bold]🤖 Executing with LLM...[/bold]")

            result = executor.execute(
                prompt=enriched_prompt,
                working_dir=working_dir,
            )

            if not result.success:
                console.print(f"[red]❌ LLM execution failed (exit code {result.exit_code})[/red]")
                console.print(f"[dim]{result.stderr}[/dim]")

                # Submit failure to server
                api_client.llm_result(
                    session_id=session_id,
                    result=result.stdout or result.stderr,
                    status="failure",
                )
                raise typer.Exit(1)

            console.print(f"[green]✓[/green] LLM execution complete\n")

            # Step 4: Submit result to server
            console.print("[bold]📤 Submitting result...[/bold]")

            server_response = api_client.llm_result(
                session_id=session_id,
                result=result.stdout,
                status="success",
            )

            action = server_response["action"]
            iteration_time = time.time() - iteration_start

            if verbose:
                console.print("[dim]─── Server Response ───[/dim]")
                console.print(f"[dim]  Action: {action}[/dim]")
                console.print(f"[dim]  Iteration: {server_response.get('iteration', 'N/A')}[/dim]")
                if server_response.get("feedback"):
                    console.print(f"[dim]  Feedback: {server_response['feedback']}[/dim]")
                if action == "continue" and server_response.get("base_prompt"):
                    console.print(f"[dim]  Next prompt: {len(server_response['base_prompt'])} chars[/dim]")
                console.print(f"[dim]  Iteration time: {iteration_time:.1f}s[/dim]")
                console.print("[dim]───────────────────────[/dim]")

            # Handle server response
            if action == "complete":
                console.print("\n[bold green]✨ Task completed successfully![/bold green]")
                console.print(f"[dim]{server_response.get('message', '')}[/dim]")
                if verbose:
                    console.print(f"[dim]Total iterations: {iteration}[/dim]")
                # Clear checkpoint on successful completion
                session_manager.clear_checkpoint()
                raise typer.Exit(0)

            elif action == "continue":
                # Server wants another iteration
                base_prompt = server_response["base_prompt"]
                console.print(f"[yellow]→[/yellow] Continuing to iteration {iteration + 1}...\n")
                iteration += 1
                # Update checkpoint with new iteration
                session_manager.update_iteration(iteration)

            elif action == "error":
                console.print(f"\n[red]❌ Server error:[/red] {server_response.get('message', 'Unknown error')}")
                raise typer.Exit(1)

            else:
                console.print(f"\n[red]❌ Unknown server action:[/red] {action}")
                raise typer.Exit(1)

        # Max iterations reached
        console.print(f"\n[yellow]⚠️  Maximum iterations ({max_iterations}) reached[/yellow]")
        console.print("[dim]Task may be incomplete. Check session status.[/dim]")
        raise typer.Exit(1)

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        if hasattr(e, 'recovery') and e.recovery:
            console.print(f"[cyan]💡 Recovery:[/cyan] {e.recovery}")
        raise typer.Exit(1)

    except TermsNotAcceptedError as e:
        # Server rejected request because terms not accepted
        # This can happen if local cache is out of sync or terms version changed
        console.print(f"\n[red]❌ Terms Not Accepted:[/red] {e}")
        console.print(f"[bold]{e.action}[/bold]")
        if e.required_version:
            console.print(f"[dim]Required version: {e.required_version}[/dim]")
        console.print(f"[dim]Terms: {e.terms_url}[/dim]")
        # Clear local cache since it's out of sync
        from obra_client.config import clear_terms_acceptance
        clear_terms_acceptance()
        raise typer.Exit(1)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        if e.status_code:
            console.print(f"[dim]Status code: {e.status_code}[/dim]")
        if hasattr(e, 'recovery') and e.recovery:
            console.print(f"[cyan]💡 Recovery:[/cyan] {e.recovery}")
        raise typer.Exit(1)

    except ExecutionError as e:
        console.print(f"\n[red]❌ Execution Error:[/red] {e}")
        if hasattr(e, 'recovery') and e.recovery:
            console.print(f"[cyan]💡 Recovery:[/cyan] {e.recovery}")
        raise typer.Exit(1)

    except KeyboardInterrupt:
        console.print("\n\n[yellow]⚠️  Interrupted by user[/yellow]")
        console.print(f"[dim]Session {session_id} is still active on server[/dim]")
        console.print(f"[dim]Resume with: obra-client resume {session_id}[/dim]")
        raise typer.Exit(130)

    except typer.Exit:
        # Re-raise typer.Exit without treating it as an error
        # (typer.Exit inherits from RuntimeError, so it's caught by Exception)
        raise

    except Exception as e:
        console.print(f"\n[red]❌ Unexpected Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
@handle_encoding_errors
def execute(
    prompt: str,
    project_dir: Optional[str] = typer.Option(
        None, "--project-dir", "-p", help="Project directory (default: current)"
    ),
    task_type: str = typer.Option(
        "feature", "--task-type", "-t", help="Type of task (feature, bug_fix, refactor)"
    ),
    # LLM override flags - session only, not persisted
    model: Optional[str] = typer.Option(
        None,
        "--model",
        help="Set implementation model. Example: --model opus",
    ),
    impl_model: Optional[str] = typer.Option(
        None,
        "--impl-model",
        help="Set implementation model (alias for --model). Example: --impl-model haiku",
    ),
    impl_provider: Optional[str] = typer.Option(
        None,
        "--impl-provider",
        help="Set implementation provider. Example: --impl-provider anthropic",
    ),
    impl_interface: Optional[str] = typer.Option(
        None,
        "--impl-interface",
        help="Set implementation auth interface. Values: oauth, api_key",
    ),
) -> None:
    """Execute a single task and exit (simplified interface for agents).

    This is a streamlined command for LLM agents that need to execute
    a single task without entering interactive mode. It's equivalent to:
        obra-client interactive -c "<prompt>" -c "exit"

    Args:
        prompt: Task objective (e.g., "Add user authentication")
        project_dir: Project directory (default: current directory)
        task_type: Type of task (feature, bug_fix, refactor, etc.)

    Model Override Flags (not persisted to config):
        --model          Set implementation model
        --impl-model     Alias for --model
        --impl-provider  Set implementation provider
        --impl-interface Set implementation auth (oauth/api_key)

    Examples:
        obra-client execute "Add user authentication with JWT"
        obra-client execute "Fix login bug" --task-type bug_fix
        obra-client execute "Refactor database layer" -p ~/myproject
        obra-client execute "Add feature" --model opus
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    try:
        config = require_config()

        # Determine project directory
        working_dir = Path(project_dir or os.getcwd()).resolve()

        if not working_dir.exists():
            console.print(f"[red]❌ Project directory not found: {working_dir}[/red]")
            raise typer.Exit(1)

        # Build LLM override from CLI flags
        impl_override = None
        if model or impl_model or impl_provider or impl_interface:
            impl_override = LLMOverride(
                provider=impl_provider,
                interface=impl_interface,
                model=impl_model or model,  # --impl-model takes precedence over --model
            )

        console.print(f"\n[bold]🚀 Executing Task[/bold]")
        console.print(f"[dim]Objective:[/dim] {prompt}")
        console.print(f"[dim]Project:[/dim] {working_dir}")
        console.print(f"[dim]Type:[/dim] {task_type}\n")

        success, session_id, error = _run_orchestration(
            objective=prompt,
            working_dir=working_dir,
            task_type=task_type,
            config=config,
            impl_override=impl_override,
        )

        if success:
            console.print(f"\n[green]✓[/green] Task completed successfully")
            if session_id:
                console.print(f"[dim]Session ID: {session_id}[/dim]")
            raise typer.Exit(0)
        else:
            console.print(f"\n[red]❌ Task failed:[/red] {error or 'Unknown error'}")
            if session_id:
                console.print(f"[dim]Session ID: {session_id}[/dim]")
                console.print("[dim]Run 'obra-client resume' to retry[/dim]")
            raise typer.Exit(1)

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        raise typer.Exit(1)

    except TermsNotAcceptedError as e:
        console.print(f"\n[red]❌ Terms Not Accepted:[/red] {e}")
        raise typer.Exit(1)

    except AuthenticationError as e:
        console.print(f"\n[red]❌ Authentication Error:[/red] {e}")
        raise typer.Exit(1)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        raise typer.Exit(1)

    except typer.Exit:
        raise

    except Exception as e:
        console.print(f"\n[red]❌ Unexpected Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
@handle_encoding_errors
def status(session_id: str) -> None:
    """Query orchestration session status.

    Args:
        session_id: Session ID from /orchestrate call

    Example:
        obra-client status abc123-def456-ghi789
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    try:
        config = require_config()

        # Use from_config() to enable automatic token refresh
        api_client = APIClient.from_config()

        console.print(f"\n[bold]📊 Session Status[/bold]")
        console.print(f"[dim]Session ID:[/dim] {session_id}\n")

        response = api_client.get_status(session_id)

        console.print(f"[bold]Status:[/bold] {response['status']}")
        console.print(f"[bold]Iteration:[/bold] {response['current_iteration']}")
        console.print(f"[bold]Objective:[/bold] {response['objective']}")
        console.print(f"[bold]Type:[/bold] {response['task_type']}")

        raise typer.Exit(0)

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        raise typer.Exit(1)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
@handle_encoding_errors
def resume(session_id: Optional[str] = None) -> None:
    """Resume interrupted orchestration session.

    Args:
        session_id: Session ID to resume (optional, will use last checkpoint if not provided)

    Example:
        obra-client resume                    # Resume last session
        obra-client resume abc123-def456      # Resume specific session
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    try:
        config = require_config()
        session_manager = SessionManager()

        # Load checkpoint
        checkpoint = session_manager.load_checkpoint()

        if not checkpoint:
            console.print("[yellow]⚠️  No saved session found[/yellow]")
            console.print("[dim]Run 'obra-client orchestrate' to start a new session[/dim]")
            raise typer.Exit(1)

        # Use provided session_id or checkpoint's session_id
        target_session_id = session_id or checkpoint.session_id

        # Initialize API client
        # Use from_config() to enable automatic token refresh
        api_client = APIClient.from_config()

        # Check if session can be resumed
        console.print(f"\n[bold]🔄 Resuming Session[/bold]")
        console.print(f"[dim]Session ID:[/dim] {target_session_id}")
        console.print(f"[dim]Objective:[/dim] {checkpoint.objective}")
        console.print(f"[dim]Last Iteration:[/dim] {checkpoint.iteration}\n")

        # Verify session is still active
        try:
            status_response = api_client.get_status(target_session_id)

            if status_response["status"] != "active":
                console.print(
                    f"[yellow]⚠️  Session is {status_response['status']}, cannot resume[/yellow]"
                )
                session_manager.clear_checkpoint()
                raise typer.Exit(1)

        except APIError as e:
            console.print(f"[red]❌ Session not found on server:[/red] {e}")
            session_manager.clear_checkpoint()
            raise typer.Exit(1)

        # Ask user to confirm resume
        confirm = typer.confirm("Resume this session?", default=True)
        if not confirm:
            console.print("[dim]Resume cancelled[/dim]")
            raise typer.Exit(0)

        console.print("[green]✓[/green] Resuming session...\n")

        # Get continuation prompt from server
        console.print("[bold]📡 Fetching continuation prompt...[/bold]")
        resume_response = api_client.resume(target_session_id)

        base_prompt = resume_response["base_prompt"]
        iteration = resume_response.get("iteration", checkpoint.iteration)

        console.print(f"[green]✓[/green] Got continuation prompt (iteration {iteration})")

        # Initialize executor and enricher
        enricher = PromptEnricher()

        # Resolve LLM configuration for implementation agent
        impl_config = resolve_llm_config("implementation")
        impl_args = build_llm_args(impl_config)
        impl_cli = config.get("llm_cli_path") or config.get("claude_code_path") or get_llm_cli(impl_config["provider"])

        # Show active LLM configuration
        model_display = impl_config["model"] if impl_config["model"] != "default" else "default"
        console.print(f"[dim]LLM:[/dim] {impl_config['provider']} ({model_display})\n")

        executor = LLMExecutor(
            cli_path=impl_cli,
            timeout=get_llm_timeout(),
            base_args=impl_args,
        )

        # Get working directory from checkpoint
        working_dir = Path(checkpoint.project_dir).resolve()

        # Orchestration loop (same as orchestrate command)
        max_iterations = 20  # Safety limit

        while iteration <= max_iterations:
            iteration_start = time.time()
            console.print(f"[bold]🔄 Iteration {iteration}[/bold]")

            # Enrich prompt with local context
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                task = progress.add_task("Enriching prompt with local context...", total=None)
                enriched_prompt = enricher.enrich_prompt(base_prompt, str(working_dir))
                progress.update(task, completed=True)

            console.print(f"[green]✓[/green] Prompt enriched (~{len(enriched_prompt)} chars)\n")

            # Execute LLM
            console.print("[bold]🤖 Executing with LLM...[/bold]")

            result = executor.execute(
                prompt=enriched_prompt,
                working_dir=working_dir,
            )

            if not result.success:
                console.print(f"[red]❌ LLM execution failed (exit code {result.exit_code})[/red]")
                console.print(f"[dim]{result.stderr}[/dim]")

                # Submit failure to server
                api_client.llm_result(
                    session_id=target_session_id,
                    result=result.stdout or result.stderr,
                    status="failure",
                )
                raise typer.Exit(1)

            console.print(f"[green]✓[/green] LLM execution complete\n")

            # Submit result to server
            console.print("[bold]📤 Submitting result...[/bold]")

            server_response = api_client.llm_result(
                session_id=target_session_id,
                result=result.stdout,
                status="success",
            )

            action = server_response["action"]
            iteration_time = time.time() - iteration_start

            console.print(f"[dim]  Iteration time: {iteration_time:.1f}s[/dim]")

            # Handle server response
            if action == "complete":
                console.print("\n[bold green]✨ Task completed successfully![/bold green]")
                console.print(f"[dim]{server_response.get('message', '')}[/dim]")
                # Clear checkpoint on successful completion
                session_manager.clear_checkpoint()
                raise typer.Exit(0)

            elif action == "continue":
                # Server wants another iteration
                base_prompt = server_response["base_prompt"]
                console.print(f"[yellow]→[/yellow] Continuing to iteration {iteration + 1}...\n")
                iteration += 1
                # Update checkpoint with new iteration
                session_manager.update_iteration(iteration)

            elif action == "error":
                console.print(f"\n[red]❌ Server error:[/red] {server_response.get('message', 'Unknown error')}")
                raise typer.Exit(1)

            else:
                console.print(f"\n[red]❌ Unknown server action:[/red] {action}")
                raise typer.Exit(1)

        # Max iterations reached
        console.print(f"\n[yellow]⚠️  Maximum iterations ({max_iterations}) reached[/yellow]")
        console.print("[dim]Task may be incomplete. Check session status.[/dim]")
        raise typer.Exit(1)

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        if hasattr(e, 'recovery') and e.recovery:
            console.print(f"[cyan]💡 Recovery:[/cyan] {e.recovery}")
        raise typer.Exit(1)

    except TermsNotAcceptedError as e:
        # Server rejected request because terms not accepted
        console.print(f"\n[red]❌ Terms Not Accepted:[/red] {e}")
        console.print(f"[bold]{e.action}[/bold]")
        if e.required_version:
            console.print(f"[dim]Required version: {e.required_version}[/dim]")
        console.print(f"[dim]Terms: {e.terms_url}[/dim]")
        from obra_client.config import clear_terms_acceptance
        clear_terms_acceptance()
        raise typer.Exit(1)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        if e.status_code:
            console.print(f"[dim]Status code: {e.status_code}[/dim]")
        if hasattr(e, 'recovery') and e.recovery:
            console.print(f"[cyan]💡 Recovery:[/cyan] {e.recovery}")
        raise typer.Exit(1)

    except ExecutionError as e:
        console.print(f"\n[red]❌ Execution Error:[/red] {e}")
        if hasattr(e, 'recovery') and e.recovery:
            console.print(f"[cyan]💡 Recovery:[/cyan] {e.recovery}")
        raise typer.Exit(1)

    except KeyboardInterrupt:
        console.print("\n\n[yellow]⚠️  Interrupted by user[/yellow]")
        console.print(f"[dim]Session {target_session_id} is still active on server[/dim]")
        console.print(f"[dim]Resume with: obra-client resume {target_session_id}[/dim]")
        raise typer.Exit(130)

    except typer.Exit:
        # Re-raise typer.Exit without treating it as an error
        raise

    except Exception as e:
        console.print(f"\n[red]❌ Unexpected Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
@handle_encoding_errors
def version() -> None:
    """Display Obra Client version and check server compatibility."""
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    console.print(f"[bold]Obra Client[/bold] v{__version__}\n")

    try:
        config = require_config()

        # Use from_config() to enable automatic token refresh
        api_client = APIClient.from_config()

        console.print("[bold]Checking server compatibility...[/bold]")
        server_version = api_client.get_version()

        console.print(f"[green]✓[/green] Server API Version: {server_version['api_version']}")

        # Handle both old and new response formats
        client_info = server_version.get("client", {})
        if client_info:
            # New format with client version checking
            console.print(
                f"[dim]Min Supported Version:[/dim] {client_info.get('min_supported_version', 'N/A')}"
            )
            console.print(
                f"[dim]Latest Version:[/dim] {client_info.get('latest_version', 'N/A')}"
            )
            status = client_info.get("status", "unknown")
            status_color = {"current": "green", "outdated": "yellow", "unsupported": "red"}.get(
                status, "dim"
            )
            console.print(f"[dim]Your Status:[/dim] [{status_color}]{status}[/{status_color}]")
        else:
            # Legacy format
            if "min_client_version" in server_version:
                console.print(
                    f"[dim]Min Client Version:[/dim] {server_version['min_client_version']}"
                )

        # Features (may be at top level or absent in new format)
        features = server_version.get("features", [])
        if features:
            console.print(f"[dim]Features:[/dim] {', '.join(features)}")

    except ConfigurationError as e:
        error_msg = str(e)
        if "not found" in error_msg.lower() and "config" in error_msg.lower():
            console.print("[yellow]⚠️  No configuration found[/yellow]")
            console.print("[dim]Run 'obra setup' to configure.[/dim]")
        elif "Not authenticated" in error_msg or "expired" in error_msg.lower():
            console.print(f"[red]❌ Authentication failed[/red]")
            console.print("[dim]Run 'obra login' to sign in again.[/dim]")
            console.print(f"\n[dim]Details: {error_msg}[/dim]")
        else:
            console.print(f"[yellow]⚠️  Configuration error:[/yellow] {error_msg}")
            console.print("[dim]Run 'obra setup' to reconfigure.[/dim]")

    except TermsNotAcceptedError as e:
        console.print(f"[red]❌ Terms not accepted[/red]")
        console.print("[dim]Delete config and run 'obra-client setup' to accept terms.[/dim]")

    except APIError as e:
        console.print(f"[red]❌ Server unreachable:[/red] {e}")

    raise typer.Exit(0)


@app.command(name="health-check")
@handle_encoding_errors
def health_check() -> None:
    """Verify Obra installation and configuration.

    Checks:
        - Python version (>= 3.12)
        - Configuration file validity
        - API/Database connectivity
        - LLM CLI availability

    Example:
        obra-client health-check
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    import shutil
    import subprocess

    console.print("\n[bold]🏥 Obra Health Check[/bold]")
    console.print("=" * 50)

    all_passed = True

    # Check 1: Python Version
    console.print("\n[bold]1. Python Version[/bold]")
    python_version = sys.version_info
    version_str = f"{python_version.major}.{python_version.minor}.{python_version.micro}"

    if python_version >= (3, 12):
        console.print(f"   [green]✓[/green] Python {version_str}")
    else:
        console.print(f"   [red]✗[/red] Python {version_str} (requires 3.12+)")
        console.print(f"   [dim]→ Upgrade Python: https://www.python.org/downloads/[/dim]")
        all_passed = False

    # Check 2: Configuration
    console.print("\n[bold]2. Configuration[/bold]")
    try:
        config = load_config()

        # Validate required fields (Firebase auth uses firebase_uid instead of license_key)
        required_fields = ["firebase_uid", "auth_token"]
        missing_fields = [f for f in required_fields if not config.get(f)]

        if missing_fields:
            console.print(f"   [red]✗[/red] Not authenticated")
            console.print(f"   [dim]→ Run: obra login[/dim]")
            all_passed = False
        else:
            console.print("   [green]✓[/green] Authentication valid")

    except ConfigurationError as e:
        console.print(f"   [red]✗[/red] Config error: {e}")
        console.print(f"   [dim]→ Run: obra-client setup[/dim]")
        all_passed = False

    # Check 3: API/Database Connectivity
    console.print("\n[bold]3. API/Database Connectivity[/bold]")
    try:
        config = load_config()

        # Create API client without auth for health check
        api_client = APIClient(
            base_url=config["api_base_url"],
            auth_token=None,
        )

        # Check health endpoint
        health = api_client.health_check()

        if health.get("status") == "healthy":
            console.print(f"   [green]✓[/green] API reachable (Firestore: {health.get('firestore', 'unknown')})")
        else:
            console.print(f"   [yellow]⚠[/yellow] API status: {health.get('status', 'unknown')}")
            all_passed = False

    except ConfigurationError:
        console.print("   [yellow]⚠[/yellow] Skipped (no config)")
        all_passed = False

    except APIError as e:
        console.print(f"   [red]✗[/red] API unreachable: {e}")
        console.print(f"   [dim]→ Check network connection and API URL[/dim]")
        all_passed = False

    except Exception as e:
        console.print(f"   [red]✗[/red] Connection error: {e}")
        console.print(f"   [dim]→ Verify API base URL in config[/dim]")
        all_passed = False

    # Check 4: LLM CLI
    console.print("\n[bold]4. LLM CLI[/bold]")
    try:
        config = load_config()
        # Check for configured path first, then search for available CLIs
        cli_path = config.get("llm_cli_path") or config.get("claude_code_path")

        # Supported CLIs in order of preference
        cli_options = [
            ("claude", "Claude Code", "https://docs.anthropic.com/claude-code"),
            ("gemini", "Gemini CLI", "https://ai.google.dev/gemini-api/docs"),
            ("codex", "OpenAI Codex", "https://platform.openai.com/docs"),
        ]

        found_cli = None
        if cli_path and shutil.which(cli_path):
            found_cli = cli_path
        else:
            # Search for available CLIs
            for cli_name, _, _ in cli_options:
                if shutil.which(cli_name):
                    found_cli = cli_name
                    break

        if found_cli:
            # Try to get version
            try:
                # On Windows, npm-installed CLIs are .cmd files that need shell=True
                import platform
                use_shell = platform.system() == "Windows"

                result = subprocess.run(
                    [found_cli, "--version"],
                    capture_output=True,
                    text=True,
                    encoding="utf-8",
                    timeout=5,
                    check=False,
                    shell=use_shell,
                )

                if result.returncode == 0:
                    version_output = result.stdout.strip() or result.stderr.strip()
                    console.print(f"   [green]✓[/green] LLM CLI found: {found_cli} ({version_output})")
                else:
                    console.print(f"   [green]✓[/green] LLM CLI found: {found_cli}")

            except subprocess.TimeoutExpired:
                console.print(f"   [yellow]⚠[/yellow] LLM CLI found ({found_cli}) but --version timed out")
            except FileNotFoundError:
                console.print(f"   [green]✓[/green] LLM CLI found: {found_cli}")

        else:
            console.print(f"   [yellow]⚠[/yellow] No LLM CLI found in PATH")
            console.print(f"   [dim]Install one of:[/dim]")
            for cli_name, cli_desc, cli_url in cli_options:
                console.print(f"   [dim]  • {cli_desc} ({cli_name}): {cli_url}[/dim]")
            all_passed = False

    except ConfigurationError:
        console.print("   [yellow]⚠[/yellow] Skipped (no config)")
        all_passed = False

    # Check 5: Client Version
    console.print("\n[bold]5. Client Version[/bold]")
    try:
        config = load_config()
        api_client = APIClient(
            base_url=config.get("api_base_url", DEFAULT_API_BASE_URL),
            auth_token=config.get("auth_token"),
        )
        version_checker = VersionChecker(api_client)
        status_indicator, status_message = version_checker.get_health_check_status()

        if status_indicator == "ok":
            console.print(f"   [green]✓[/green] {status_message}")
        elif status_indicator == "warning":
            console.print(f"   [yellow]⚠[/yellow] {status_message}")
            # Warning doesn't fail health check, just informational
        else:  # error
            console.print(f"   [red]✗[/red] {status_message}")
            console.print(f"   [dim]→ Run: {version_checker.get_upgrade_command()}[/dim]")
            all_passed = False

    except ConfigurationError:
        console.print("   [yellow]⚠[/yellow] Skipped (no config)")
    except Exception as e:
        console.print(f"   [yellow]⚠[/yellow] Version check failed: {e}")
        # Version check failures don't fail health check (fail-open)

    # Summary
    console.print("\n" + "=" * 50)

    if all_passed:
        console.print("[bold green]✨ All checks passed![/bold green]")
        console.print("\n[dim]Your Obra installation is ready to use.[/dim]")
        console.print("[dim]Next: obra-client orchestrate \"your task\"[/dim]")
        raise typer.Exit(0)
    else:
        console.print("[bold yellow]⚠  Some checks failed[/bold yellow]")
        console.print("\n[dim]Fix the issues above, then run health-check again.[/dim]")
        raise typer.Exit(1)


# =============================================================================
# Firebase Auth Commands (EPIC-AUTH-MIGRATION-001)
# =============================================================================


@app.command()
@handle_encoding_errors
def login() -> None:
    """Sign in with Firebase Auth (Google or GitHub OAuth).

    Opens your browser to complete OAuth sign-in. After authentication,
    verifies your email is on the beta allowlist.

    Example:
        obra login
    """
    from obra_client.auth import (
        login_with_browser,
        save_auth,
        verify_beta_access,
    )

    console.print(f"\n[bold]OBRA LOGIN[/bold] [dim]v{__version__}[/dim]")
    console.print("=" * 50)

    # Check if already authenticated
    if is_authenticated():
        email = get_user_email()
        console.print(f"\n[yellow]Already signed in as:[/yellow] {email}")
        console.print("[dim]Run 'obra logout' first to sign in with a different account.[/dim]")

        reauth = typer.confirm("Sign in again?", default=False)
        if not reauth:
            raise typer.Exit(0)

    console.print("\n[bold]Opening browser for authentication...[/bold]")
    console.print("[dim]Complete sign-in in the browser window.[/dim]")
    console.print("[dim]Waiting for authentication (timeout: 5 minutes)...[/dim]\n")

    try:
        # Perform browser OAuth
        auth_result = login_with_browser(timeout=300)

        # Verify beta access before saving
        config = load_config()
        api_base_url = config.get("api_base_url", DEFAULT_API_BASE_URL)

        try:
            access_info = verify_beta_access(auth_result.id_token, api_base_url)
        except AuthenticationError as e:
            console.print(f"\n[red]✗ Access denied:[/red] {e}")
            console.print("\n[dim]Your authentication succeeded, but you don't have beta access.[/dim]")
            console.print("[dim]Contact the Obra team to request access.[/dim]")
            raise typer.Exit(1)

        # CRITICAL: Save authentication IMMEDIATELY after successful verification
        # This must happen before any console output that could fail (e.g., Unicode)
        save_auth(auth_result)

        # Now safe to print status messages
        console.print(f"[green]✓[/green] Signed in as: {auth_result.email}")
        console.print(f"[dim]  Provider: {auth_result.auth_provider}[/dim]")
        console.print(f"[green]✓[/green] Beta access verified")
        console.print(f"[green]✓[/green] Authentication saved")

        console.print("\n[bold green]Login successful![/bold green]")
        console.print()
        console.print("[bold]Next steps:[/bold]")
        console.print("  obra whoami              # View your account info")
        console.print("  obra interactive         # Start interactive mode")
        console.print("  obra orchestrate \"task\"  # Run a task")

    except AuthenticationError as e:
        console.print(f"\n[red]✗ Authentication failed:[/red] {e}")
        raise typer.Exit(1)

    except TimeoutError as e:
        console.print(f"\n[red]✗ Timeout:[/red] {e}")
        console.print("[dim]The browser sign-in was not completed in time.[/dim]")
        raise typer.Exit(1)

    except Exception as e:
        console.print(f"\n[red]✗ Unexpected error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
@handle_encoding_errors
def logout() -> None:
    """Sign out and clear stored credentials.

    Removes stored Firebase authentication tokens from the config file.

    Example:
        obra logout
    """
    from obra_client.auth import clear_auth

    if not is_authenticated():
        console.print("\n[dim]Not currently signed in.[/dim]")
        raise typer.Exit(0)

    email = get_user_email()

    confirm = typer.confirm(f"Sign out from {email}?", default=True)
    if not confirm:
        console.print("[dim]Cancelled.[/dim]")
        raise typer.Exit(0)

    clear_auth()
    console.print(f"\n[green]✓[/green] Signed out from {email}")
    console.print("[dim]Run 'obra login' to sign in again.[/dim]")


@app.command()
@handle_encoding_errors
def whoami() -> None:
    """Show current authentication status.

    Displays your current sign-in status, email, and auth provider.

    Example:
        obra whoami
    """
    console.print(f"\n[bold]OBRA ACCOUNT[/bold] [dim]v{__version__}[/dim]")
    console.print("=" * 50)

    if not is_authenticated():
        console.print("\n[yellow]Not signed in.[/yellow]")
        console.print("[dim]Run 'obra login' to sign in.[/dim]")
        raise typer.Exit(0)

    # Get auth info
    firebase_uid = get_firebase_uid()
    email = get_user_email()
    provider = get_auth_provider()

    # Get config for additional info
    config = load_config()
    auth_timestamp = config.get("auth_timestamp", "Unknown")
    display_name = config.get("display_name")

    console.print()
    console.print(f"[bold]Email:[/bold]    {email}")
    if display_name:
        console.print(f"[bold]Name:[/bold]     {display_name}")
    console.print(f"[bold]Provider:[/bold] {provider}")
    console.print(f"[bold]User ID:[/bold]  [dim]{firebase_uid}[/dim]")
    console.print(f"[bold]Signed in:[/bold] [dim]{auth_timestamp[:19] if len(auth_timestamp) > 19 else auth_timestamp}[/dim]")

    # Check terms acceptance
    if is_terms_accepted():
        console.print(f"[bold]Terms:[/bold]    [green]Accepted (v{TERMS_VERSION})[/green]")
    else:
        console.print(f"[bold]Terms:[/bold]    [yellow]Not accepted[/yellow]")

    console.print()
    console.print("[dim]Commands:[/dim]")
    console.print("  obra logout     # Sign out")
    console.print("  obra login      # Sign in with different account")


def _run_orchestration(
    objective: str,
    working_dir: Path,
    task_type: str,
    config: dict,
    verbose: bool = False,
    impl_override: Optional[LLMOverride] = None,
) -> tuple[bool, Optional[str], Optional[str]]:
    """Run orchestration and return result (for REPL use).

    Args:
        objective: Task objective to orchestrate
        working_dir: Project working directory
        task_type: Type of task (feature, bug, etc.)
        config: User configuration dict
        verbose: Enable verbose output
        impl_override: Optional session override for implementation LLM

    Returns:
        Tuple of (success, session_id, error_message)
    """
    try:
        # Initialize components
        api_client = APIClient.from_config()
        enricher = PromptEnricher()

        # Resolve LLM configuration for implementation agent with session overrides
        impl_config = resolve_llm_config(
            "implementation",
            override_provider=impl_override.provider if impl_override else None,
            override_model=impl_override.model if impl_override else None,
            override_auth_method=impl_override.interface if impl_override else None,
        )
        impl_args = build_llm_args(impl_config)
        impl_cli = config.get("llm_cli_path") or config.get("claude_code_path") or get_llm_cli(impl_config["provider"])

        # Show active LLM configuration
        model_display = impl_config["model"] if impl_config["model"] != "default" else "default"
        console.print(f"[dim]LLM:[/dim] {impl_config['provider']} ({model_display})")

        executor = LLMExecutor(
            cli_path=impl_cli,
            timeout=get_llm_timeout(),
            base_args=impl_args,
        )
        session_manager = SessionManager()

        # Start orchestration session
        console.print("[bold]📡 Contacting server...[/bold]")

        # Get user_id with fallback for configs created before user_id was added
        user_id = config.get("user_id") or config.get("user_email") or config.get("firebase_uid")
        if not user_id:
            return False, None, "No user ID found. Please run 'obra login' to authenticate."

        session_response = api_client.orchestrate(
            user_id=user_id,
            project_id=config.get("project_id", "default"),
            working_dir=str(working_dir),
            objective=objective,
            task_type=task_type,
        )

        session_id = session_response["session_id"]
        base_prompt = session_response["base_prompt"]

        console.print(f"[green]✓[/green] Session created: [dim]{session_id}[/dim]\n")

        # Save checkpoint
        session_manager.save_checkpoint(
            session_id=session_id,
            objective=objective,
            task_type=task_type,
            project_dir=str(working_dir),
            iteration=1,
            status="active",
        )

        # Orchestration loop
        iteration = 1
        max_iterations = 20

        while iteration <= max_iterations:
            console.print(f"[bold]🔄 Iteration {iteration}[/bold]")

            # Enrich prompt
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                task = progress.add_task("Enriching prompt...", total=None)
                enriched_prompt = enricher.enrich_prompt(base_prompt, str(working_dir))
                progress.update(task, completed=True)

            console.print(f"[green]✓[/green] Prompt enriched (~{len(enriched_prompt)} chars)\n")

            # Execute LLM
            console.print("[bold]🤖 Executing with LLM...[/bold]")
            result = executor.execute(prompt=enriched_prompt, working_dir=working_dir)

            if not result.success:
                console.print(f"[red]❌ LLM execution failed[/red]")
                api_client.llm_result(
                    session_id=session_id,
                    result=result.stdout or result.stderr,
                    status="failure",
                )
                return False, session_id, "LLM execution failed"

            console.print(f"[green]✓[/green] LLM execution complete\n")

            # Submit result
            console.print("[bold]📤 Submitting result...[/bold]")
            server_response = api_client.llm_result(
                session_id=session_id,
                result=result.stdout,
                status="success",
            )

            action = server_response["action"]

            if action == "complete":
                console.print("\n[bold green]✨ Task completed successfully![/bold green]")
                session_manager.clear_checkpoint()
                return True, session_id, None

            elif action == "continue":
                base_prompt = server_response["base_prompt"]
                console.print(f"[yellow]→[/yellow] Continuing to iteration {iteration + 1}...\n")
                iteration += 1
                session_manager.update_iteration(iteration)

            elif action == "error":
                msg = server_response.get("message", "Unknown error")
                console.print(f"\n[red]❌ Server error:[/red] {msg}")
                return False, session_id, msg

            else:
                console.print(f"\n[red]❌ Unknown action:[/red] {action}")
                return False, session_id, f"Unknown action: {action}"

        console.print(f"\n[yellow]⚠️  Max iterations ({max_iterations}) reached[/yellow]")
        return False, session_id, "Max iterations reached"

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        return False, None, str(e)

    except TermsNotAcceptedError as e:
        console.print(f"\n[red]❌ Terms Not Accepted:[/red] {e}")
        from obra_client.config import clear_terms_acceptance
        clear_terms_acceptance()
        return False, None, str(e)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        return False, None, str(e)

    except ExecutionError as e:
        console.print(f"\n[red]❌ Execution Error:[/red] {e}")
        return False, None, str(e)

    except KeyboardInterrupt:
        console.print("\n[yellow]⚠️  Interrupted[/yellow]")
        return False, None, "Interrupted by user"


# =============================================================================
# Interactive Mode State and Helpers
# =============================================================================


@dataclass
class InteractiveState:
    """State container for interactive mode sessions."""

    working_dir: Path
    config: dict
    history: list = field(default_factory=list)
    last_session_id: Optional[str] = None
    last_objective: Optional[str] = None
    last_success: Optional[bool] = None
    should_exit: bool = False
    # Session-only LLM overrides (from CLI flags, not persisted)
    orch_override: Optional[LLMOverride] = None
    impl_override: Optional[LLMOverride] = None
    # Version checker for startup/completion notifications
    version_checker: Optional[VersionChecker] = None


def _handle_llm_command(cmd_arg: Optional[str], state: InteractiveState) -> None:
    """Handle /llm command with enhanced subcommand support.

    Supports:
        /llm                    Show current config (alias: /llm show)
        /llm show               Show current config with full details
        /llm model <model>      Set model for both roles
        /llm orch <key> <val>   Set orchestrator config
        /llm impl <key> <val>   Set implementation config
        /llm both <key> <val>   Set both roles to same config

    Keys: provider, interface (oauth/api_key), model
    """
    # Parse args
    args = cmd_arg.split() if cmd_arg else []

    if not args or args[0].lower() == "show":
        # /llm or /llm show - display current config
        _llm_show_config(state)
        return

    subcmd = args[0].lower()

    # /llm help - show usage
    if subcmd == "help":
        _llm_show_help()
        return

    # /llm model <model> - shorthand for setting both roles to same model
    if subcmd == "model":
        if len(args) < 2:
            console.print("[red]❌ Usage: /llm model <model>[/red]")
            console.print("[dim]Example: /llm model opus[/dim]")
            return
        model_name = args[1].lower()
        _llm_set_both_roles({"model": model_name})
        return

    # Legacy support: /llm <model> - shorthand for quick model switch
    valid_models = ["default", "sonnet", "opus", "haiku"]
    if subcmd in valid_models:
        _llm_set_both_roles({"model": subcmd})
        return

    # /llm orch|impl|both <key> <value> [<key> <value> ...]
    if subcmd in ("orch", "impl", "both"):
        if len(args) < 3:
            console.print(f"[red]❌ Usage: /llm {subcmd} <key> <value> [<key> <value> ...][/red]")
            console.print("[dim]Keys: provider, interface, model[/dim]")
            console.print(f"[dim]Example: /llm {subcmd} provider anthropic model opus[/dim]")
            return

        # Parse key-value pairs from remaining args
        updates = _llm_parse_key_values(args[1:])
        if updates is None:
            return  # Error already printed

        if subcmd == "both":
            _llm_set_both_roles(updates)
        else:
            role = "orchestrator" if subcmd == "orch" else "implementation"
            _llm_set_role(role, updates)
        return

    # Unknown subcommand
    console.print(f"[red]❌ Unknown /llm subcommand: {subcmd}[/red]")
    console.print("[dim]Type /llm help for usage.[/dim]")


def _llm_show_config(state: InteractiveState) -> None:
    """Display current LLM configuration with full details."""
    llm_config = get_llm_config()

    console.print()
    console.print("[bold]LLM Configuration:[/bold]")
    console.print()

    for role in ["orchestrator", "implementation"]:
        role_config = llm_config.get(role, {})
        provider = role_config.get("provider", DEFAULT_PROVIDER)
        auth_method = role_config.get("auth_method", DEFAULT_AUTH_METHOD)
        model = role_config.get("model", DEFAULT_MODEL)

        # Get provider display name
        provider_info = LLM_PROVIDERS.get(provider, {})
        provider_name = provider_info.get("name", provider)

        # Format interface name
        interface_name = "OAuth" if auth_method == "oauth" else "API Key"

        # Check for session overrides
        override = state.orch_override if role == "orchestrator" else state.impl_override
        has_override = override and (override.provider or override.interface or override.model)

        role_label = "Orchestrator" if role == "orchestrator" else "Implementation"
        console.print(f"  [bold]{role_label}:[/bold]")
        console.print(f"    Provider:  {provider_name} ({provider})")
        console.print(f"    Interface: {interface_name} ({auth_method})")
        console.print(f"    Model:     {model}")
        if has_override:
            override_parts = []
            if override.provider:
                override_parts.append(f"provider={override.provider}")
            if override.interface:
                override_parts.append(f"interface={override.interface}")
            if override.model:
                override_parts.append(f"model={override.model}")
            console.print(f"    [yellow]Session override: {', '.join(override_parts)}[/yellow]")
        console.print()

    console.print("[dim]Commands:[/dim]")
    console.print("  /llm model <model>         Set model for both roles")
    console.print("  /llm orch <key> <value>    Set orchestrator config")
    console.print("  /llm impl <key> <value>    Set implementation config")
    console.print("  /llm both <key> <value>    Set both roles")
    console.print("  /llm help                  Show full help")
    console.print()


def _llm_show_help() -> None:
    """Display full /llm command help."""
    console.print()
    console.print("[bold]/llm Command Reference[/bold]")
    console.print()
    console.print("[bold]Display:[/bold]")
    console.print("  /llm                       Show current configuration")
    console.print("  /llm show                  Show current configuration (alias)")
    console.print()
    console.print("[bold]Quick Model Switch:[/bold]")
    console.print("  /llm model <model>         Set model for both roles")
    console.print("  /llm <model>               Shorthand (e.g., /llm opus)")
    console.print()
    console.print("[bold]Role-Specific Config:[/bold]")
    console.print("  /llm orch <key> <val>      Set orchestrator config")
    console.print("  /llm impl <key> <val>      Set implementation config")
    console.print("  /llm both <key> <val>      Set both roles")
    console.print()
    console.print("[bold]Keys:[/bold]")
    console.print("  provider   LLM provider (anthropic, google, openai)")
    console.print("  interface  Auth method (oauth, api_key)")
    console.print("  model      Model name (default, sonnet, opus, haiku, or full name)")
    console.print()
    console.print("[bold]Examples:[/bold]")
    console.print("  /llm opus                              # Both roles → opus")
    console.print("  /llm model haiku                       # Both roles → haiku")
    console.print("  /llm orch model opus                   # Orchestrator → opus")
    console.print("  /llm impl provider google model flash  # Impl → Google Flash")
    console.print("  /llm both provider anthropic model sonnet")
    console.print()
    console.print("[dim]Note: Changes are persisted to ~/.obra/client-config.yaml[/dim]")
    console.print()


def _llm_parse_key_values(args: list[str]) -> Optional[dict[str, str]]:
    """Parse key-value pairs from argument list.

    Args:
        args: List like ["provider", "anthropic", "model", "opus"]

    Returns:
        Dict like {"provider": "anthropic", "model": "opus"} or None on error
    """
    if len(args) % 2 != 0:
        console.print("[red]❌ Keys and values must come in pairs[/red]")
        console.print(f"[dim]Got: {' '.join(args)}[/dim]")
        return None

    valid_keys = {"provider", "interface", "model"}
    result = {}

    for i in range(0, len(args), 2):
        key = args[i].lower()
        value = args[i + 1].lower()

        if key not in valid_keys:
            console.print(f"[red]❌ Unknown key: {key}[/red]")
            console.print(f"[dim]Valid keys: {', '.join(sorted(valid_keys))}[/dim]")
            return None

        result[key] = value

    return result


def _llm_set_role(role: str, updates: dict[str, str]) -> None:
    """Set LLM configuration for a single role.

    Args:
        role: "orchestrator" or "implementation"
        updates: Dict with provider, interface, and/or model keys
    """
    llm_config = get_llm_config()
    role_config = llm_config.get(role, {})

    # Get current values
    provider = updates.get("provider", role_config.get("provider", DEFAULT_PROVIDER))
    auth_method = updates.get("interface", role_config.get("auth_method", DEFAULT_AUTH_METHOD))
    model = updates.get("model", role_config.get("model", DEFAULT_MODEL))

    # Validate provider
    if provider not in LLM_PROVIDERS:
        console.print(f"[red]❌ Unknown provider: {provider}[/red]")
        console.print(f"[dim]Valid: {', '.join(LLM_PROVIDERS.keys())}[/dim]")
        return

    # Validate interface
    if auth_method not in LLM_AUTH_METHODS:
        console.print(f"[red]❌ Unknown interface: {auth_method}[/red]")
        console.print(f"[dim]Valid: {', '.join(LLM_AUTH_METHODS.keys())}[/dim]")
        return

    # Validate model (shortcuts only; full names are passthrough)
    try:
        model = validate_model(model, provider)
    except ValueError as e:
        console.print(f"[red]❌ {e}[/red]")
        return

    try:
        set_llm_config(role, provider, auth_method, model)
        role_label = "Orchestrator" if role == "orchestrator" else "Implementation"
        console.print(f"[green]✓[/green] {role_label} updated: {get_llm_display(role)}")
    except ValueError as e:
        console.print(f"[red]❌ {e}[/red]")


def _llm_set_both_roles(updates: dict[str, str]) -> None:
    """Set LLM configuration for both roles."""
    for role in ["orchestrator", "implementation"]:
        llm_config = get_llm_config()
        role_config = llm_config.get(role, {})

        # Get current values
        provider = updates.get("provider", role_config.get("provider", DEFAULT_PROVIDER))
        auth_method = updates.get("interface", role_config.get("auth_method", DEFAULT_AUTH_METHOD))
        model = updates.get("model", role_config.get("model", DEFAULT_MODEL))

        # Validate provider
        if provider not in LLM_PROVIDERS:
            console.print(f"[red]❌ Unknown provider: {provider}[/red]")
            console.print(f"[dim]Valid: {', '.join(LLM_PROVIDERS.keys())}[/dim]")
            return

        # Validate interface
        if auth_method not in LLM_AUTH_METHODS:
            console.print(f"[red]❌ Unknown interface: {auth_method}[/red]")
            console.print(f"[dim]Valid: {', '.join(LLM_AUTH_METHODS.keys())}[/dim]")
            return

        # Validate model
        try:
            model = validate_model(model, provider)
        except ValueError as e:
            console.print(f"[red]❌ {e}[/red]")
            return

        try:
            set_llm_config(role, provider, auth_method, model)
        except ValueError as e:
            console.print(f"[red]❌ {e}[/red]")
            return

    console.print("[green]✓[/green] Both roles updated:")
    console.print(f"    Orchestrator:    {get_llm_display('orchestrator')}")
    console.print(f"    Implementation:  {get_llm_display('implementation')}")


def _process_interactive_input(
    user_input: str,
    state: InteractiveState,
    quiet: bool = False,
) -> bool:
    """Process a single interactive mode input.

    Args:
        user_input: The command or objective to process.
        state: The current interactive session state.
        quiet: If True, suppress non-essential output (for scripted mode).

    Returns:
        True if processing should continue, False if exit was requested.
    """
    user_input = user_input.strip()

    # Skip empty input
    if not user_input:
        return True

    # Add to history
    state.history.append(user_input)

    # Handle commands (start with /)
    if user_input.startswith("/"):
        cmd_parts = user_input[1:].split(maxsplit=1)
        cmd = cmd_parts[0].lower()
        cmd_arg = cmd_parts[1] if len(cmd_parts) > 1 else None

        if cmd in ("exit", "quit", "q"):
            if not quiet:
                console.print("\n[dim]Goodbye![/dim]")
            state.should_exit = True
            return False

        elif cmd == "help":
            _repl_help()

        elif cmd == "clear":
            console.clear()
            console.print(f"[bold]OBRA INTERACTIVE MODE[/bold] [dim]v{__version__}[/dim]")
            console.print("═" * 70)

        elif cmd == "status":
            if state.last_session_id:
                status_str = "[green]completed[/green]" if state.last_success else "[red]failed[/red]"
                console.print(f"\n[bold]Last Session:[/bold]")
                console.print(f"  Session ID: [dim]{state.last_session_id}[/dim]")
                console.print(f"  Objective: {state.last_objective}")
                console.print(f"  Status: {status_str}")
                console.print()
            else:
                console.print("\n[dim]No session yet. Run an orchestration first.[/dim]\n")

        elif cmd == "session":
            # Show session info and recovery options
            console.print()
            console.print("[bold]━━━ SESSION INFO ━━━[/bold]")
            console.print()
            if state.last_session_id:
                status_str = "[green]completed[/green]" if state.last_success else "[red]failed[/red]"
                console.print("[bold]Current Session:[/bold]")
                console.print(f"  ID: [cyan]{state.last_session_id}[/cyan]")
                console.print(f"  Objective: {state.last_objective}")
                console.print(f"  Status: {status_str}")
                console.print()
                console.print("[bold]Recovery Options:[/bold]")
                if not state.last_success:
                    console.print(f"  [green]Resume:[/green] obra-client resume --session-id {state.last_session_id}")
                    console.print("  [dim]↳ Continue from last checkpoint[/dim]")
                console.print(f"  [yellow]Query:[/yellow]  obra-client status --session-id {state.last_session_id}")
                console.print("  [dim]↳ Get detailed status from server[/dim]")
            else:
                console.print("[dim]No active session.[/dim]")
                console.print()
                console.print("[bold]To start:[/bold]")
                console.print("  Type any objective text (without / prefix)")
                console.print("  Example: [dim]Add user authentication[/dim]")
            console.print()
            console.print("[bold]SaaS Session Notes:[/bold]")
            console.print("  • Sessions auto-expire after 1 hour of inactivity")
            console.print("  • Server manages checkpoints automatically")
            console.print("  • Your code never leaves your machine")
            console.print()

        elif cmd == "history":
            if state.history:
                console.print("\n[bold]Command History:[/bold]")
                for i, h in enumerate(state.history[-10:], 1):
                    console.print(f"  {i}. {h}")
                console.print()
            else:
                console.print("\n[dim]No history yet.[/dim]\n")

        elif cmd == "project":
            if cmd_arg:
                new_path = Path(cmd_arg).expanduser().resolve()
                if new_path.exists() and new_path.is_dir():
                    state.working_dir = new_path
                    console.print(f"[green]✓[/green] Project directory: {state.working_dir}")
                else:
                    console.print(f"[red]❌ Directory not found:[/red] {cmd_arg}")
            else:
                console.print(f"[bold]Project:[/bold] {state.working_dir}")

        elif cmd == "llm":
            # Handle /llm command - enhanced model/provider switching
            _handle_llm_command(cmd_arg, state)

        elif cmd == "execute":
            # /execute N - execute task N from the task list
            # For SaaS mode, this is a no-op since tasks execute automatically
            if cmd_arg:
                console.print(f"[dim]Note: In SaaS mode, tasks execute automatically.[/dim]")
                console.print(f"[dim]The /execute command is for compatibility with agent scripts.[/dim]")
            else:
                console.print("[dim]Usage: /execute <task_number>[/dim]")
                console.print("[dim]Note: In SaaS mode, tasks execute automatically.[/dim]")

        else:
            console.print(f"[red]Unknown command:[/red] /{cmd}")
            console.print("[dim]Type /help for available commands.[/dim]")

    else:
        # Treat as orchestration objective
        if not quiet:
            console.print()
        success, session_id, error = _run_orchestration(
            objective=user_input,
            working_dir=state.working_dir,
            task_type="feature",
            config=state.config,
            impl_override=state.impl_override,
        )
        state.last_session_id = session_id
        state.last_objective = user_input
        state.last_success = success
        if not quiet:
            console.print()
            # Show completion hint if version is outdated (subtle reminder)
            if state.version_checker:
                state.version_checker.show_completion_hint(console)

    return True


def _repl_help() -> None:
    """Show REPL help with SaaS-specific information."""
    console.print("\n[bold]━━━ OBRA INTERACTIVE REPL ━━━[/bold]")
    console.print()

    # Commands section
    console.print("[bold]Available Commands:[/bold]")
    console.print("  [cyan]/help[/cyan]           Show this help message")
    console.print("  [cyan]/status[/cyan]         Show current/last session status")
    console.print("  [cyan]/session[/cyan]        Show session info and recovery options")
    console.print("  [cyan]/history[/cyan]        Show command history")
    console.print("  [cyan]/project[/cyan] [path] Show or change working directory")
    console.print("  [cyan]/llm[/cyan] [args]     Show or configure LLM (/llm help for details)")
    console.print("  [cyan]/clear[/cyan]          Clear screen")
    console.print("  [cyan]/exit[/cyan]           Exit interactive mode")
    console.print()

    # Orchestration section
    console.print("[bold]Orchestration:[/bold]")
    console.print("  Type any text without / prefix to orchestrate a task.")
    console.print("  Example: [dim]Add user authentication[/dim]")
    console.print()

    # SaaS Session Model explanation
    console.print("[bold]SaaS Session Model:[/bold]")
    console.print("  Sessions are managed by Cloud Functions, not locally.")
    console.print()
    console.print("  [dim]• Sessions auto-expire after 1 hour of inactivity[/dim]")
    console.print("  [dim]• Server decides when iterations are complete[/dim]")
    console.print("  [dim]• Your code never leaves your machine (Two-Tier Prompting)[/dim]")
    console.print("  [dim]• Checkpoints are automatic - no manual saving needed[/dim]")
    console.print()

    # Key differences from CLI
    console.print("[bold]Differences from Standalone CLI:[/bold]")
    console.print("  [yellow]Not available here:[/yellow]")
    console.print("    [dim]• /pause[/dim] - Sessions auto-suspend instead")
    console.print("    [dim]• /budget[/dim] - Budget is server-managed")
    console.print("    [dim]• /checkpoint[/dim] - Checkpoints are automatic")
    console.print()
    console.print("  [green]Use command line instead:[/green]")
    console.print("    [dim]• obra-client resume[/dim] - Resume interrupted session")
    console.print("    [dim]• obra-client status <id>[/dim] - Check specific session")
    console.print()

    # Quick tips
    console.print("[bold]Quick Tips:[/bold]")
    console.print("  • /llm opus → Switch both roles to Opus")
    console.print("  • /llm orch model opus → Set orchestrator to Opus")
    console.print("  • /llm impl provider google → Switch impl to Gemini")
    console.print("  • /project ~/other → Change working directory")
    console.print()


# =============================================================================
# Config Commands
# =============================================================================

config_app = typer.Typer(help="Configuration management commands")
app.add_typer(config_app, name="config")


@config_app.command(name="llm")
@handle_encoding_errors
def config_llm(
    role: Optional[str] = typer.Argument(None, help="Role to configure: orch[estrator] or imp[lementation]"),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Model to use (default, sonnet, opus, haiku)"),
) -> None:
    """Show or set LLM configuration.

    Without arguments, shows current LLM configuration for both roles.
    With role argument, interactively configure that role.

    Examples:
        obra-client config llm              # Show current config
        obra-client config llm orch         # Configure orchestrator
        obra-client config llm imp          # Configure implementation
        obra-client config llm orch -m opus # Quick set orchestrator model
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    if role is None:
        # Show current configuration
        console.print("\n[bold]LLM Configuration[/bold]")
        console.print("-" * 50)

        console.print()
        console.print("[bold]Orchestrator:[/bold]")
        console.print(f"  {get_llm_display('orchestrator')}")

        console.print()
        console.print("[bold]Implementation:[/bold]")
        console.print(f"  {get_llm_display('implementation')}")

        console.print()
        console.print("[bold]Available Providers:[/bold]")
        for key, info in LLM_PROVIDERS.items():
            console.print(f"  • {info['name']}: {info['description']}")
            console.print(f"    [dim]Models: {', '.join(info['models'])}[/dim]")

        console.print()
        console.print("[dim]Usage:[/dim]")
        console.print("  obra-client config llm orch    # Configure orchestrator")
        console.print("  obra-client config llm imp     # Configure implementation")
        console.print("  obra-client config llm orch -m opus  # Quick set model")
        return

    # Normalize role name
    role_normalized = role.lower()
    if role_normalized.startswith("orch"):
        role_key = "orchestrator"
    elif role_normalized.startswith("imp"):
        role_key = "implementation"
    else:
        console.print(f"[red]❌ Unknown role: {role}[/red]")
        console.print("[dim]Valid: orch[estrator], imp[lementation][/dim]")
        raise typer.Exit(1)

    # Quick model set if -m provided
    if model:
        llm_config = get_llm_config()
        role_config = llm_config.get(role_key, {})
        provider = role_config.get("provider", DEFAULT_PROVIDER)
        auth_method = role_config.get("auth_method", DEFAULT_AUTH_METHOD)

        provider_info = LLM_PROVIDERS.get(provider, {})
        if model not in provider_info.get("models", []):
            console.print(f"[red]❌ Invalid model: {model}[/red]")
            console.print(f"[dim]Valid for {provider}: {', '.join(provider_info['models'])}[/dim]")
            raise typer.Exit(1)

        try:
            set_llm_config(role_key, provider, auth_method, model)
            console.print(f"[green]✓[/green] {role_key.capitalize()}: {get_llm_display(role_key)}")
        except ValueError as e:
            console.print(f"[red]❌ {e}[/red]")
            raise typer.Exit(1)
        return

    # Interactive configuration
    console.print(f"\n[bold]Configure {role_key.capitalize()} LLM[/bold]")
    console.print("-" * 40)

    # Provider
    console.print("\n[bold]Provider:[/bold]")
    provider_keys = list(LLM_PROVIDERS.keys())
    for i, key in enumerate(provider_keys, 1):
        info = LLM_PROVIDERS[key]
        console.print(f"  {i}. {info['name']} - {info['description']}")

    provider_choice = typer.prompt("Select", default="1")
    try:
        provider_idx = int(provider_choice) - 1
        selected_provider = provider_keys[max(0, min(provider_idx, len(provider_keys)-1))]
    except ValueError:
        selected_provider = DEFAULT_PROVIDER

    # Auth method
    console.print("\n[bold]Auth Method:[/bold]")
    console.print("  1. OAuth (Flat Rate) [green](recommended)[/green]")
    console.print("  2. API Key (Token Billing) [yellow]⚠️ untested[/yellow]")

    auth_choice = typer.prompt("Select", default="1")
    selected_auth = "oauth" if auth_choice == "1" else "api_key"

    # Model
    provider_info = LLM_PROVIDERS[selected_provider]
    console.print("\n[bold]Model:[/bold]")
    if selected_auth == "oauth":
        console.print("  [green]'default' strongly recommended for OAuth[/green]")

    for i, m in enumerate(provider_info["models"], 1):
        rec = " [green](recommended)[/green]" if m == "default" and selected_auth == "oauth" else ""
        console.print(f"  {i}. {m}{rec}")

    model_choice = typer.prompt("Select", default="1")
    try:
        model_idx = int(model_choice) - 1
        selected_model = provider_info["models"][max(0, min(model_idx, len(provider_info["models"])-1))]
    except ValueError:
        selected_model = DEFAULT_MODEL

    try:
        set_llm_config(role_key, selected_provider, selected_auth, selected_model)
        console.print(f"\n[green]✓[/green] {role_key.capitalize()}: {get_llm_display(role_key)}")
    except ValueError as e:
        console.print(f"[red]❌ {e}[/red]")
        raise typer.Exit(1)


@config_app.command(name="show")
@handle_encoding_errors
def config_show() -> None:
    """Show local client configuration settings."""
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    config = load_config()

    console.print("\n[bold]Obra Client Configuration (Local)[/bold]")
    console.print("-" * 50)

    # Authentication settings
    console.print("\n[bold]Authentication:[/bold]")
    email = config.get('user_email', 'Not signed in')
    firebase_uid = config.get('firebase_uid')
    auth_provider = config.get('auth_provider', 'Unknown')
    if firebase_uid:
        console.print(f"  Email:     {email}")
        console.print(f"  Provider:  {auth_provider}")
        console.print(f"  User ID:   [dim]{firebase_uid[:20]}...[/dim]")
    else:
        console.print(f"  Status:    [yellow]Not signed in[/yellow]")
        console.print(f"  [dim]→ Run: obra login[/dim]")
    console.print(f"  API URL:   [dim]{config.get('api_base_url', DEFAULT_API_BASE_URL)}[/dim]")

    # LLM settings
    console.print()
    console.print("[bold]LLM:[/bold]")
    console.print(f"  Orchestrator:    {get_llm_display('orchestrator')}")
    console.print(f"  Implementation:  {get_llm_display('implementation')}")
    timeout = get_llm_timeout()
    console.print(f"  Timeout:         {timeout}s ({timeout // 60} min)")

    # Terms
    terms = config.get("terms_accepted", {})
    console.print()
    console.print("[bold]Terms:[/bold]")
    console.print(f"  Version:  {terms.get('version', 'Not accepted')}")
    console.print(f"  Accepted: {terms.get('accepted_at', 'Never')[:19] if terms.get('accepted_at') else 'Never'}")

    console.print()
    console.print(f"[dim]Config file: {CONFIG_PATH}[/dim]")
    console.print()
    console.print("[dim]For SaaS feature config: obra-client config saas[/dim]")


# =============================================================================
# SaaS Configuration Commands (FEAT-SAAS-CONFIG-001)
# =============================================================================


@config_app.command(name="saas")
@handle_encoding_errors
def config_saas_show() -> None:
    """Show SaaS configuration (preset, overrides, feature flags).

    Displays your server-side configuration including:
    - Current preset (e.g., beta-tester-default, standard)
    - Your custom overrides
    - Key feature states (enabled/disabled)

    Example:
        obra-client config saas
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    try:
        api_client = APIClient.from_config()
        console.print("\n[bold]📡 Fetching SaaS configuration...[/bold]")

        config_data = api_client.get_user_config()

        console.print("\n[bold]SaaS Configuration[/bold]")
        console.print("=" * 50)

        # Preset
        console.print(f"\n[bold]Preset:[/bold] {config_data.get('preset', 'unknown')}")

        # Overrides
        overrides = config_data.get('overrides', {})
        if overrides:
            console.print("\n[bold]Your Overrides:[/bold]")
            for path, value in overrides.items():
                console.print(f"  {path} = {value}")
        else:
            console.print("\n[bold]Overrides:[/bold] [dim]None (using preset defaults)[/dim]")

        # Key features from resolved config
        resolved = config_data.get('resolved', {})
        features = resolved.get('features', {})

        console.print("\n[bold]Key Features:[/bold]")

        # Quality Automation
        qa = features.get('quality_automation', {})
        qa_enabled = qa.get('enabled', False)
        console.print(f"  Quality Automation: {'[green]enabled[/green]' if qa_enabled else '[dim]disabled[/dim]'}")
        if qa_enabled:
            agents = qa.get('agents', {})
            console.print(f"    • RCA Agent: {'✓' if agents.get('rca_agent') else '✗'}")
            console.print(f"    • Code Review: {'✓' if agents.get('code_review') else '✗'}")
            console.print(f"    • Security Audit: {'✓' if agents.get('security_audit') else '✗'}")

        # Performance Control / Budgets
        pc = features.get('performance_control', {})
        budgets = pc.get('budgets', {})
        budgets_enabled = budgets.get('enabled', False)
        console.print(f"  Budget Controls: {'[green]enabled[/green]' if budgets_enabled else '[dim]disabled[/dim]'}")

        # Advanced Planning
        ap = features.get('advanced_planning', {})
        ap_enabled = ap.get('enabled', False)
        console.print(f"  Advanced Planning: {'[green]enabled[/green]' if ap_enabled else '[dim]disabled[/dim]'}")

        # Documentation Governance
        dg = features.get('documentation_governance', {})
        dg_enabled = dg.get('enabled', False)
        console.print(f"  Doc Governance: {'[green]enabled[/green]' if dg_enabled else '[dim]disabled[/dim]'}")

        console.print("\n[bold]Commands:[/bold]")
        console.print("  obra-client config set <path> <value>  # Change a setting")
        console.print("  obra-client config preset list         # List available presets")
        console.print("  obra-client config preset use <name>   # Switch presets")
        console.print("  obra-client config reset               # Reset to default")

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        raise typer.Exit(1)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        raise typer.Exit(1)


@config_app.command(name="set")
@handle_encoding_errors
def config_saas_set(
    path: str = typer.Argument(..., help="Dot-notation path (e.g., features.performance_control.budgets.enabled)"),
    value: str = typer.Argument(..., help="Value to set (true/false for booleans, or string/number)"),
) -> None:
    """Set a SaaS configuration override.

    Use dot-notation to specify the path to the setting.
    Changes are persisted on the server and apply immediately.

    Examples:
        obra-client config set features.performance_control.budgets.enabled true
        obra-client config set features.quality_automation.agents.security_audit true
        obra-client config set features.quality_automation.agents.rca_agent false
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    try:
        api_client = APIClient.from_config()

        # Parse value (handle booleans, numbers, strings)
        parsed_value: any
        value_lower = value.lower()
        if value_lower == 'true':
            parsed_value = True
        elif value_lower == 'false':
            parsed_value = False
        elif value.isdigit():
            parsed_value = int(value)
        elif value.replace('.', '', 1).isdigit():
            parsed_value = float(value)
        else:
            parsed_value = value

        console.print(f"\n[bold]Setting:[/bold] {path} = {parsed_value}")

        result = api_client.update_user_config(overrides={path: parsed_value})

        console.print(f"[green]✓[/green] Configuration updated")
        console.print(f"[dim]Preset: {result.get('preset')}[/dim]")

        # Show the override was applied
        overrides = result.get('overrides', {})
        if path in overrides:
            console.print(f"[dim]Override active: {path} = {overrides[path]}[/dim]")

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        raise typer.Exit(1)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        if "invalid_preset" in str(e):
            console.print("[dim]Use 'obra-client config preset list' to see available presets[/dim]")
        raise typer.Exit(1)


@config_app.command(name="reset")
@handle_encoding_errors
def config_saas_reset(
    overrides_only: bool = typer.Option(False, "--overrides-only", "-o", help="Only clear overrides, keep preset"),
) -> None:
    """Reset SaaS configuration to defaults.

    By default, resets both preset and overrides to beta-tester-default.
    Use --overrides-only to keep current preset but clear custom overrides.

    Examples:
        obra-client config reset              # Full reset to default preset
        obra-client config reset --overrides-only  # Clear overrides only
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    try:
        api_client = APIClient.from_config()

        if overrides_only:
            console.print("\n[bold]Clearing all overrides...[/bold]")
            result = api_client.update_user_config(clear_overrides=True)
            console.print(f"[green]✓[/green] Overrides cleared")
            console.print(f"[dim]Preset remains: {result.get('preset')}[/dim]")
        else:
            console.print("\n[bold]Resetting to default configuration...[/bold]")
            result = api_client.update_user_config(preset="beta-tester-default", clear_overrides=True)
            console.print(f"[green]✓[/green] Configuration reset to beta-tester-default")

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        raise typer.Exit(1)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        raise typer.Exit(1)


# Preset management sub-app
preset_app = typer.Typer(help="Preset management commands")
config_app.add_typer(preset_app, name="preset")


@preset_app.command(name="list")
@handle_encoding_errors
def config_preset_list() -> None:
    """List available configuration presets.

    Shows all presets you can switch to, with descriptions.

    Example:
        obra-client config preset list
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    try:
        api_client = APIClient.from_config()
        console.print("\n[bold]📡 Fetching available presets...[/bold]")

        result = api_client.list_presets()
        presets = result.get('presets', [])

        console.print("\n[bold]Available Presets[/bold]")
        console.print("=" * 60)

        for preset in presets:
            name = preset.get('name', 'unknown')
            desc = preset.get('description', '')
            recommended = preset.get('recommended', False)
            rec_for = preset.get('recommended_for', '')

            # Format name with recommendation marker
            name_display = f"[bold]{name}[/bold]"
            if recommended:
                name_display += " [green]★ recommended[/green]"
            elif rec_for:
                name_display += f" [cyan]({rec_for})[/cyan]"

            console.print(f"\n{name_display}")
            if desc:
                console.print(f"  [dim]{desc}[/dim]")

            personas = preset.get('target_personas', [])
            if personas:
                console.print(f"  [dim]For: {', '.join(personas)}[/dim]")

        console.print("\n[bold]Usage:[/bold]")
        console.print("  obra-client config preset use <name>   # Switch to a preset")
        console.print("  obra-client config preset show <name>  # View preset details")

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        raise typer.Exit(1)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        raise typer.Exit(1)


@preset_app.command(name="use")
@handle_encoding_errors
def config_preset_use(
    name: str = typer.Argument(..., help="Preset name to switch to"),
    keep_overrides: bool = typer.Option(False, "--keep-overrides", "-k", help="Keep current overrides"),
) -> None:
    """Switch to a different configuration preset.

    When switching presets, overrides are cleared by default to give you
    a clean slate. Use --keep-overrides to preserve your custom settings.

    Examples:
        obra-client config preset use standard
        obra-client config preset use minimal --keep-overrides
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    try:
        api_client = APIClient.from_config()

        console.print(f"\n[bold]Switching to preset: {name}[/bold]")

        result = api_client.update_user_config(
            preset=name,
            clear_overrides=not keep_overrides
        )

        console.print(f"[green]✓[/green] Switched to preset: {result.get('preset')}")

        if keep_overrides:
            overrides = result.get('overrides', {})
            if overrides:
                console.print(f"[dim]Kept {len(overrides)} override(s)[/dim]")
        else:
            console.print("[dim]Overrides cleared[/dim]")

        console.print("\n[dim]Run 'obra-client config saas' to see new configuration[/dim]")

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        raise typer.Exit(1)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        if "invalid_preset" in str(e).lower():
            console.print("[dim]Use 'obra-client config preset list' to see available presets[/dim]")
        raise typer.Exit(1)


@preset_app.command(name="show")
@handle_encoding_errors
def config_preset_show(
    name: str = typer.Argument(..., help="Preset name to view"),
) -> None:
    """Show details of a specific preset.

    Displays the full feature configuration for a preset
    without applying it.

    Example:
        obra-client config preset show minimal
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    try:
        api_client = APIClient.from_config()
        console.print(f"\n[bold]📡 Fetching preset: {name}[/bold]")

        # Get list of presets to find the one we want
        result = api_client.list_presets()
        presets = result.get('presets', [])

        preset = next((p for p in presets if p.get('name') == name), None)
        if not preset:
            console.print(f"[red]❌ Preset not found: {name}[/red]")
            console.print("[dim]Use 'obra-client config preset list' to see available presets[/dim]")
            raise typer.Exit(1)

        console.print(f"\n[bold]Preset: {name}[/bold]")
        console.print("=" * 50)

        desc = preset.get('description', '')
        if desc:
            console.print(f"\n[dim]{desc}[/dim]")

        personas = preset.get('target_personas', [])
        if personas:
            console.print(f"\n[bold]Target Users:[/bold] {', '.join(personas)}")

        rec_for = preset.get('recommended_for', '')
        if rec_for:
            console.print(f"[bold]Recommended For:[/bold] {rec_for}")

        setup_time = preset.get('setup_time_target', '')
        if setup_time:
            console.print(f"[bold]Setup Time:[/bold] {setup_time}")

        console.print("\n[dim]To switch to this preset:[/dim]")
        console.print(f"  obra-client config preset use {name}")

    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        raise typer.Exit(1)

    except APIError as e:
        console.print(f"\n[red]❌ API Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
@handle_encoding_errors
def interactive(
    commands: Optional[list[str]] = typer.Option(
        None,
        "-c",
        "--command",
        help="Commands to execute non-interactively. Can be repeated. "
        "Example: -c 'Add auth' -c '/execute 1' -c 'exit'",
    ),
    # LLM override flags - session only, not persisted
    model: Optional[str] = typer.Option(
        None,
        "--model",
        help="Set model for both orchestrator and implementation (session only). "
        "Example: --model opus",
    ),
    orch_model: Optional[str] = typer.Option(
        None,
        "--orch-model",
        help="Set orchestrator model (session only). Example: --orch-model opus",
    ),
    impl_model: Optional[str] = typer.Option(
        None,
        "--impl-model",
        help="Set implementation model (session only). Example: --impl-model haiku",
    ),
    orch_provider: Optional[str] = typer.Option(
        None,
        "--orch-provider",
        help="Set orchestrator provider (session only). Example: --orch-provider google",
    ),
    impl_provider: Optional[str] = typer.Option(
        None,
        "--impl-provider",
        help="Set implementation provider (session only). Example: --impl-provider anthropic",
    ),
    orch_interface: Optional[str] = typer.Option(
        None,
        "--orch-interface",
        help="Set orchestrator auth interface (session only). Values: oauth, api_key",
    ),
    impl_interface: Optional[str] = typer.Option(
        None,
        "--impl-interface",
        help="Set implementation auth interface (session only). Values: oauth, api_key",
    ),
) -> None:
    """Start interactive orchestration mode.

    Interactive mode provides a REPL-like interface for orchestration,
    allowing you to iteratively work through development tasks with
    real-time feedback.

    Commands:
        /help      Show available commands
        /status    Show last session status
        /session   Show session info and recovery options
        /history   Show command history
        /project   Show or change working directory
        /llm       Show or configure LLM (/llm help for details)
        /execute   Execute task (compatibility for agent scripts)
        /clear     Clear screen
        /exit      Exit interactive mode

    Model Override Flags (session only, not persisted):
        --model          Set model for both roles
        --orch-model     Set orchestrator model only
        --impl-model     Set implementation model only
        --orch-provider  Set orchestrator provider only
        --impl-provider  Set implementation provider only
        --orch-interface Set orchestrator auth (oauth/api_key)
        --impl-interface Set implementation auth (oauth/api_key)

    Examples:
        obra-client interactive
        obra-client interactive --model opus
        obra-client interactive --orch-model opus --impl-model haiku
        obra-client interactive -c "Add user auth" -c "/execute 1" -c "exit"
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    try:
        config = require_config()
    except ConfigurationError as e:
        console.print(f"\n[red]❌ Configuration Error:[/red] {e}")
        raise typer.Exit(1)

    # Build LLM overrides from CLI flags (session only, not persisted)
    orch_override = None
    impl_override = None

    # --model applies to both roles
    if model or orch_model or orch_provider or orch_interface:
        orch_override = LLMOverride(
            provider=orch_provider,
            interface=orch_interface,
            model=orch_model or model,  # --orch-model takes precedence over --model
        )

    if model or impl_model or impl_provider or impl_interface:
        impl_override = LLMOverride(
            provider=impl_provider,
            interface=impl_interface,
            model=impl_model or model,  # --impl-model takes precedence over --model
        )

    # Initialize API client for version checking
    try:
        api_client = APIClient(
            base_url=config.get("api_base_url", DEFAULT_API_BASE_URL),
            auth_token=config.get("auth_token"),
        )
        version_checker = VersionChecker(api_client)
    except Exception:
        # If API client creation fails, proceed without version checking
        version_checker = None

    # Initialize state
    state = InteractiveState(
        working_dir=Path.cwd().resolve(),
        config=config,
        orch_override=orch_override,
        impl_override=impl_override,
        version_checker=version_checker,
    )

    # Check for unsupported version (blocking)
    if version_checker and version_checker.should_block():
        version_checker.show_startup_notification(console)
        raise typer.Exit(1)

    # Scripted mode: process commands and exit
    if commands:
        # Show version notification for scripted mode too
        if version_checker:
            version_checker.show_startup_notification(console)
        for cmd in commands:
            if not _process_interactive_input(cmd, state, quiet=True):
                break  # Exit requested
        # Show completion hint if version is outdated
        if version_checker:
            version_checker.show_completion_hint(console)
        raise typer.Exit(0 if state.last_success is not False else 1)

    # Interactive REPL mode
    # Welcome banner
    console.print()
    console.print(f"[bold]OBRA INTERACTIVE MODE[/bold] [dim]v{__version__}[/dim]")
    console.print("═" * 70)
    console.print(f"[dim]Project:[/dim] {state.working_dir}")
    console.print("[dim]Type objectives to orchestrate, or /help for commands.[/dim]")

    # Show version notification (yellow warning for outdated, after banner)
    if version_checker:
        version_checker.show_startup_notification(console)
    else:
        console.print()

    # Main REPL loop
    while True:
        try:
            # Get input
            user_input = Prompt.ask("[bold cyan]obra[/bold cyan]")

            if not _process_interactive_input(user_input, state):
                break  # Exit requested

        except KeyboardInterrupt:
            console.print("\n[dim]Use /exit to quit.[/dim]")
            continue

        except EOFError:
            # Ctrl+D
            console.print("\n[dim]Goodbye![/dim]")
            break

    raise typer.Exit(0)


# Create docs sub-app for documentation commands
docs_app = typer.Typer(
    name="docs",
    help=(
        "View bundled documentation and guides.\n\n"
        "FOR LLM AGENTS: Start with 'agent-capabilities' for the capability brief, "
        "or use 'agent-path' to get filesystem paths for direct file reading."
    ),
)
app.add_typer(docs_app, name="docs")


@docs_app.command(name="onboarding")
@handle_encoding_errors
def docs_onboarding() -> None:
    """Display agent onboarding documentation.

    Shows the getting-started guide for using obra-client,
    including setup instructions and key commands.

    Example:
        obra-client docs onboarding
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    from obra_client.docs import get_onboarding

    console.print(get_onboarding())


@docs_app.command(name="examples")
@handle_encoding_errors
def docs_examples() -> None:
    """Display usage examples and common workflows.

    Shows copy-paste examples for common Obra operations
    and best practices.

    Example:
        obra-client docs examples
    """
    # HARD STOP GATE: Require terms acceptance
    require_terms_accepted()

    from obra_client.docs import get_usage_examples

    console.print(get_usage_examples())


@docs_app.command(name="terms")
@handle_encoding_errors
def docs_terms() -> None:
    """Display full Beta Software Agreement.

    Shows the complete terms and conditions for using Obra.

    Example:
        obra-client docs terms
    """
    # Note: terms display does NOT require acceptance gate
    # Users should be able to read terms before deciding

    from obra_client.legal import get_full_terms

    console.print(get_full_terms())


@docs_app.command(name="agent-capabilities")
@handle_encoding_errors
def docs_agent_capabilities() -> None:
    """Display Obra capabilities brief for LLM agents.

    Comprehensive guide for LLM agents on what Obra can do and how to use it.
    This is the PRIMARY document agents should read before operating Obra.

    Example:
        obra-client docs agent-capabilities
    """
    require_terms_accepted()

    from obra_client.docs.for_agents import read_doc

    content = read_doc("capability-brief")
    if content:
        console.print(content)
    else:
        console.print("[red]Error: capability-brief.md not found[/red]")


@docs_app.command(name="agent-setup")
@handle_encoding_errors
def docs_agent_setup() -> None:
    """Display autonomous setup guide for LLM agents.

    Step-by-step guide for agents to set up and configure Obra autonomously.

    Example:
        obra-client docs agent-setup
    """
    require_terms_accepted()

    from obra_client.docs.for_agents import read_doc

    content = read_doc("autonomous-setup")
    if content:
        console.print(content)
    else:
        console.print("[red]Error: autonomous-setup.md not found[/red]")


@docs_app.command(name="agent-tasks")
@handle_encoding_errors
def docs_agent_tasks() -> None:
    """Display task templates for LLM agents.

    Pre-built task patterns and templates for common development workflows.

    Example:
        obra-client docs agent-tasks
    """
    require_terms_accepted()

    from obra_client.docs.for_agents import read_doc

    content = read_doc("task-templates")
    if content:
        console.print(content)
    else:
        console.print("[red]Error: task-templates.md not found[/red]")


@docs_app.command(name="agent-prompt")
@handle_encoding_errors
def docs_agent_prompt(
    copy: bool = typer.Option(
        False, "--copy", "-c", help="Copy the prompt to clipboard"
    ),
) -> None:
    """Generate a ready-to-use prompt for bootstrapping an LLM agent.

    Outputs a prompt you can copy and paste to any LLM (Claude, ChatGPT, etc.)
    to teach it how to operate Obra on your behalf.

    Examples:
        obra-client docs agent-prompt           # Display the prompt
        obra-client docs agent-prompt --copy    # Copy to clipboard
    """
    require_terms_accepted()

    from obra_client.docs.for_agents import get_docs_path

    docs_path = get_docs_path()
    capability_path = docs_path / "capability-brief.md"

    # The bootstrap prompt - concise, points to docs, establishes critical rule
    prompt = f"""Help me build software using Obra, an AI orchestration platform.

CRITICAL: You are a TASK ARCHITECT - you design tasks and delegate
to Obra. You do NOT write code, create files, or run tests yourself.

Read the capability documentation first:
  {capability_path}

Commands:
  obra-client execute "<task>"    # Single task
  obra-client interactive         # Multi-step session

After reading, confirm you understand, then ask what I want to build."""

    # Try to copy to clipboard if requested
    copied = False
    if copy:
        copied = _copy_to_clipboard(prompt)

    # Display the prompt with framing
    console.print()
    console.print("=" * 70)
    if copied:
        console.print("[bold green]  PROMPT COPIED TO CLIPBOARD[/bold green]")
    else:
        console.print("[bold cyan]  COPY THIS PROMPT TO YOUR LLM[/bold cyan]")
    console.print("=" * 70)
    console.print()
    console.print(prompt)
    console.print()
    console.print("-" * 70)
    console.print("[dim]Tip: For web-based LLMs that can't read files, run instead:[/dim]")
    console.print("[dim]     obra-client docs agent-capabilities[/dim]")
    console.print("[dim]     Then copy that output to your LLM.[/dim]")
    console.print()

    if copy and not copied:
        console.print("[yellow]Note: Could not copy to clipboard. Please copy manually.[/yellow]")
        console.print()


def _copy_to_clipboard(text: str) -> bool:
    """Copy text to system clipboard. Returns True if successful."""
    import subprocess
    import shutil

    # Try platform-specific clipboard commands
    if sys.platform == "darwin":  # macOS
        if shutil.which("pbcopy"):
            try:
                subprocess.run(["pbcopy"], input=text.encode(), check=True)
                return True
            except subprocess.SubprocessError:
                pass
    elif sys.platform == "win32":  # Windows
        if shutil.which("clip"):
            try:
                subprocess.run(["clip"], input=text.encode(), check=True)
                return True
            except subprocess.SubprocessError:
                pass
    else:  # Linux/other
        for cmd in ["xclip -selection clipboard", "xsel --clipboard --input"]:
            cmd_parts = cmd.split()
            if shutil.which(cmd_parts[0]):
                try:
                    subprocess.run(cmd_parts, input=text.encode(), check=True)
                    return True
                except subprocess.SubprocessError:
                    pass

    return False


@docs_app.command(name="agent-path")
@handle_encoding_errors
def docs_agent_path() -> None:
    """Show the filesystem path to agent documentation.

    Returns the path where agent docs are installed, so LLM agents can
    read the files directly without using CLI commands.

    Example:
        obra-client docs agent-path
    """
    require_terms_accepted()

    from obra_client.docs.for_agents import get_docs_path, list_docs

    docs_path = get_docs_path()
    available_docs = list_docs()

    console.print(f"\n[bold]Agent Documentation Path:[/bold]")
    console.print(f"  {docs_path}")
    console.print(f"\n[bold]Available Documents:[/bold]")
    for doc in available_docs:
        console.print(f"  • {doc}.md")
    console.print(f"\n[dim]LLM agents can read these files directly using their file reading tools.[/dim]")


if __name__ == "__main__":
    app()
