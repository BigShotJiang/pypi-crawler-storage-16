# Obra Capability Brief for LLM Agents

> **Document Purpose**: Dense reference for LLM agents to decide **when to route work through Obra** and **how to invoke it correctly**.

---

## CRITICAL: Your Role as the Calling Agent

```yaml
role: TASK_ARCHITECT
not: CODER
action: DELEGATE_TO_OBRA
```

> **YOU DO NOT WRITE CODE. YOU DELEGATE TO OBRA.**

When a user asks you to use Obra, your job is to be a **task architect**, not a coder:

| Your Role (Calling Agent) | Obra's Role (Execution) |
|---------------------------|-------------------------|
| Formulate clear objectives | Plan the implementation |
| Define requirements & constraints | Decompose into subtasks |
| Specify success criteria | Execute code changes |
| Describe target outputs | Validate quality |
| Review results | Iterate until threshold met |

### What You MUST Do

1. **Analyze the user's request** - Understand what they want built
2. **Formulate a detailed prompt** with:
   - Clear intention (what outcome)
   - Specific requirements (features, constraints)
   - Target outputs (files, deliverables)
   - Success criteria (how to verify)
3. **Send the prompt to Obra** via `obra-client interactive -c "..."`
4. **Review the results** and report back to the user

### What You MUST NOT Do

- **NEVER** write code yourself
- **NEVER** create files directly
- **NEVER** make git commits
- **NEVER** run tests yourself
- **NEVER** do the implementation work

**Why?** Obra has its own implementation agent (Claude Code, Gemini CLI, or OpenAI Codex) that will do all of this with quality validation, iteration, and pattern guidance. If you write code yourself, you bypass all of Obra's value.

### Example: User Says "Use Obra to add authentication"

**WRONG** (doing the work yourself):
```
Let me create an auth module...
[writes code]
[creates files]
```

**RIGHT** (delegating to Obra):
```bash
obra-client interactive -c "Create a task to implement user authentication:

**Objective**: Add JWT-based authentication to the REST API

**Requirements**:
- Login endpoint at POST /api/auth/login
- JWT tokens with 24h expiry
- Password hashing with bcrypt
- Protected route middleware

**Deliverables**:
- src/auth/jwt.py - Token generation/validation
- src/auth/middleware.py - Route protection
- src/routes/auth.py - Login endpoint
- tests/test_auth.py - Authentication tests

**Success Criteria**:
- All tests pass
- Login returns valid JWT
- Protected routes reject invalid tokens
" -c "/execute 1" -c "/exit"
```

Then report the results to the user.

---

## Quick Reference Index

```yaml
sections:
  identity: "What Obra is, deployment modes"
  architecture: "Two-Tier Prompting (SaaS), how it works"
  capabilities: "What Obra can orchestrate"
  decision_tree: "When to use Obra vs direct agent"
  invocation: "Commands, prerequisites, scripted patterns"
  task_quality: "How to write effective task descriptions"
  constraints: "Limits, timeouts, thresholds"
  output: "What results look like"
  handoff: "Protocol for delegating work"
  errors: "Common failure patterns and recovery"
```

---

## Identity

```yaml
name: Obra
type: AI Orchestration Platform
deployment_modes:
  - saas: "obra-client (recommended) - Cloud Functions + local LLM execution"
  - cli: "obra (full install) - Standalone, all components local"
current_version: "v2.1.0-beta"
```

**Obra** = Orchestration layer that wraps configurable LLM agents with validation, iteration, quality control, and work decomposition.

### Deployment Modes

| Mode | Package | Best For |
|------|---------|----------|
| **SaaS** (recommended) | `pip install obra-client` | Quick setup, managed orchestration |
| **CLI** (full control) | `pip install obra` | Self-hosted, offline use |

**This document focuses on SaaS mode** (`obra-client`), which is the recommended deployment for most users.

### Implementation Agents (Configurable)

```yaml
supported_agents:
  - claude-code: "Claude Code CLI (default, recommended)"
  - gemini-cli: "Google Gemini CLI (1M token context)"
  - openai-codex: "OpenAI Codex CLI"
```

**Critical understanding**: Obra orchestrates your chosen agent - it doesn't replace or restrict it. Tasks run through Obra have ALL capabilities of the configured implementation agent.

### Two-LLM Architecture

```
User Request
    │
    ▼
┌─────────────────────────────────────┐
│  Tier 1: Orchestration (Server)     │  ← Cloud Functions
│  - Task planning                    │  ← Quality rules
│  - Validation criteria              │  ← Iteration logic
│  - Base prompt generation           │
└─────────────────────────────────────┘
    │ Base Prompt (~2KB)
    ▼
┌─────────────────────────────────────┐
│  Tier 2: Execution (Client)         │  ← Your machine
│  - Local context injection          │  ← Files, git, errors
│  - LLM execution (Claude/Gemini)    │  ← Code generation
│  - Result validation                │
└─────────────────────────────────────┘
    │
    ▼
Quality-Controlled Result
```

**Privacy guarantee**: Your code never leaves your machine. Server generates strategic prompts; client enriches with local context and executes.

### What Obra Adds

- Automatic iteration until quality threshold met
- Work decomposition (Epic → Story → Task)
- Pattern-guided execution (9 workflow patterns)
- Stall detection and recovery
- Session continuity across context limits
- Structured logging and monitoring

### What Obra Does NOT Do

- Replace your agent (it orchestrates it)
- Restrict agent capabilities (agent retains all tools)
- Access your source code (privacy by design)
- Add new execution capabilities (orchestration only)

---

## Core Capabilities

```yaml
capabilities:
  autonomous_execution: "Execute code tasks without human intervention"
  quality_validation: "Validate output, retry until threshold met"
  work_decomposition: "Break Epic → Story → Task automatically"
  pattern_guidance: "Apply 9 workflow patterns"
  session_continuity: "Checkpoint, handoff, resume across sessions"
  natural_language: "Accept tasks in plain English"
```

| Capability | Description |
|------------|-------------|
| **Autonomous execution** | Execute code tasks without human intervention |
| **Quality validation** | Validate output, retry until threshold met |
| **Work decomposition** | Break Epic → Story → Task automatically |
| **Pattern guidance** | Apply 9 workflow patterns (docs, tests, commits, planning) |
| **Session continuity** | Checkpoint, handoff, resume across sessions |
| **Natural language** | Accept tasks in plain English, no DSL |

### Workflow Patterns (9-Pattern Library)

Patterns are selected automatically based on task type. Phrasing tasks to match pattern intent improves behavior.

| Pattern | Purpose | Trigger Phrases |
|---------|---------|-----------------|
| `architecture_docs` | Design & architecture docs | "new subsystem", "ADR", "design" |
| `implementation_planning` | Human + machine implementation plans | "plan implementation", "break down" |
| `test_suite` | Comprehensive tests & coverage | "add tests", "ensure coverage" |
| `git_commit` | Commit discipline & clean git state | "ready to commit", "finalize" |
| `continue_coding` | Maintain momentum, avoid stalls | "continue", "keep coding" |
| `best_practices` | Enforce code quality & style | "apply best practices", "clean up" |
| `continuation_prompt` | Session handoff & context management | "handoff", "pause work" |
| `changelog_update` | Keep CHANGELOG updated | "update changelog" |
| `agile_breakdown` | Epic → Story → Task breakdown | "large feature", "epic" |

---

## Decision Tree: Should You Use Obra?

```
Does task benefit from iteration/quality control?
├─ NO → Use implementation agent directly (faster)
└─ YES → Continue
    │
    Is task well-defined with clear deliverables?
    ├─ NO → Define better first, then use Obra
    └─ YES → Continue
        │
        Does task need decomposition or multi-step work?
        ├─ NO → Consider direct agent (simpler)
        └─ YES → Use Obra
            │
            Estimated scope?
            ├─ Small (<1 hour) → Create Task
            ├─ Medium (1-4 hours) → Create Story
            └─ Large (>4 hours) → Create Epic with Stories
```

### Use Obra For

```yaml
good_fit:
  - "Multi-step implementations needing decomposition"
  - "Quality-critical work requiring validation"
  - "Complex features with multiple deliverables"
  - "Autonomous execution without human babysitting"
  - "Long-running tasks needing stall detection"
  - "Web research + processing with quality validation"
```

### Don't Use Obra For

```yaml
poor_fit:
  - "Simple one-shot tasks (<15 min)"
  - "Exploratory research with undefined deliverables"
  - "Quick queries ('what does X mean?')"
  - "Real-time interactive work requiring human-in-loop"
  - "Tasks without clear success criteria"
```

---

## Common Misconceptions

| Misconception | Reality |
|---------------|---------|
| "Obra can't access the internet" | **FALSE** - Default agent (Claude Code) has WebSearch/WebFetch |
| "Obra is a different/limited agent" | **FALSE** - Obra orchestrates your agent, doesn't replace it |
| "Use Claude Code instead of Obra" | **WRONG FRAMING** - Obra USES Claude Code; they're not alternatives |
| "Obra is only for coding tasks" | **FALSE** - Any task your agent can do, Obra can orchestrate |
| "Obra sees my code" | **FALSE** - SaaS mode: code stays local, only prompts exchanged |

---

## Invocation

### Prerequisites (SaaS Mode)

```yaml
prerequisites:
  python: "3.12+"
  package: "pip install obra-client"
  auth: "obra-client login (browser OAuth)"
  llm: "Claude Code CLI, Gemini CLI, or OpenAI Codex"
```

### Health Check (Run First)

```bash
# 1. Verify installation
obra-client version
# Expected: obra-client 0.1.24 or higher

# 2. Verify authentication
obra-client whoami
# Expected: Shows your email and auth status

# 3. Full health check
obra-client health-check
# Expected: All checks pass (Python, Config, API, LLM CLI)

# 4. Quick functional test
obra-client interactive -c "/status" -c "/exit"
# Expected: Shows orchestrator state without errors
```

### Startup Failures

| Symptom | Cause | Fix |
|---------|-------|-----|
| "Not authenticated" | No OAuth token | `obra-client login` |
| "LLM CLI not found" | Claude/Gemini not installed | Install LLM CLI, verify in PATH |
| "API error 401" | Token expired | `obra-client login` (refreshes) |
| "API error 403" | Not on beta allowlist | Contact support for access |
| Connection timeout | Network or server issue | Check internet, retry |

### Model Override Flags

Session-only model overrides (not persisted to config):

```bash
# Set both orchestrator and implementation to same model
obra-client interactive --model opus

# Set specific roles independently
obra-client interactive --orch-model opus --impl-model haiku

# Override provider for specific role
obra-client interactive --impl-provider google --impl-model gemini-2.0-flash
```

| Flag | Purpose |
|------|---------|
| `--model` | Set model for both orchestrator and implementation |
| `--orch-model` | Set orchestrator model only |
| `--impl-model` | Set implementation model only |
| `--orch-provider` | Set orchestrator provider (anthropic, google, openai) |
| `--impl-provider` | Set implementation provider |
| `--orch-interface` | Set orchestrator auth method (oauth, api_key) |
| `--impl-interface` | Set implementation auth method |

**Note**: Role-specific flags (e.g., `--impl-model`) take precedence over `--model`.

### Basic Pattern

```bash
# Start interactive mode
obra-client interactive

# Inside interactive mode:
obra> Create a task to implement user authentication
obra> /execute 1
obra> /exit
```

### Scripted Pattern (Recommended for Agents)

```bash
obra-client interactive \
  -c "Create a task to implement user authentication with JWT" \
  -c "/execute 1" \
  -c "/exit"
```

### Single-Shot Pattern (Simplest for Agents)

```bash
# New in v0.1.26: Simplified execute command
obra-client execute "Implement user authentication with JWT"

# With options
obra-client execute "Fix login bug" --task-type bug_fix
obra-client execute "Refactor database layer" --project-dir ~/myproject
```

**Agent tip**: For single tasks, prefer `obra-client execute "<prompt>"` - it's the simplest invocation pattern. Use `interactive -c` when you need multiple commands in sequence.

---

## Task Description Quality

**Effective descriptions include**:

```yaml
required:
  - deliverable: "What to create (file, function, test)"
  - location: "Where to create it (file path)"
  - success_criteria: "How to verify completion"
optional:
  - constraints: "Limitations, requirements"
  - examples: "Sample inputs/outputs"
```

### Good Example

```
Create pytest tests for src/auth/login.py:
- Test successful login with valid credentials
- Test failed login with wrong password
- Test account lockout after 5 failures
Location: tests/test_login.py
Success: All tests pass, 90%+ coverage
```

### Bad Example

```
Write some tests for the login system
```

### Recommended Task Schema (for Internal Use)

```json
{
  "level": "task",
  "title": "Add unit tests for login",
  "description": "Create pytest tests for src/auth/login.py",
  "deliverables": ["tests/test_login.py"],
  "requirements": [
    "Test successful login",
    "Test failed login",
    "Test account lockout"
  ],
  "success_criteria": [
    "All tests pass",
    "Coverage ≥ 90%"
  ],
  "pattern_hints": ["test_suite"]
}
```

Render to natural language when invoking Obra.

---

## Constraints

```yaml
defaults:
  max_iterations: 50
  llm_timeout_s: 1800
  task_timeout_s: 3600
  quality_threshold: 0.70
  confidence_threshold: 0.50
  concurrent_tasks: 1
```

| Constraint | Default | Notes |
|------------|---------|-------|
| Max iterations | 50 | Per task |
| LLM timeout | 1800s | Per LLM execution (configurable via `OBRA_LLM_TIMEOUT` env var) |
| Task timeout | 3600s | Overall task (server-managed) |
| Quality threshold | 70% | For validation pass |
| Confidence threshold | 50% | For decisions |
| Concurrent tasks | 1 | Single task at a time |

**Note**: SaaS mode uses server-managed configuration. These defaults may be adjusted by server presets.

---

## Output Expectations

After task execution, you receive:

```yaml
output_fields:
  status: "completed | failed | stalled"
  quality_score: "0-100"
  confidence_score: "0-100"
  iterations_used: "count"
  files_modified: "list"
  git_commit: "hash (if enabled)"
```

### Normalized Result Schema

```json
{
  "status": "completed",
  "quality": 82,
  "confidence": 76,
  "iterations_used": 3,
  "files_modified": [
    "src/auth/login.py",
    "tests/test_login.py"
  ],
  "git_commit": "abc1234",
  "notes": "Tests added and all checks passed."
}
```

---

## Handoff Protocol

### Step-by-Step

1. **Assess Fit**: Use decision tree. If task fits, continue.
2. **Formulate Task**: Use schema above with clear deliverables
3. **Invoke Obra**:
   ```bash
   obra-client interactive \
     -c "Create a task to <title>: <description>" \
     -c "/execute 1" \
     -c "/exit"
   ```
4. **Check Results**: Parse output for status, quality, files
5. **Report to User**: Summarize what was accomplished

### Failure Recovery

| Status | Cause | Recovery |
|--------|-------|----------|
| `stalled` | Task too vague | Add specific deliverables, success criteria |
| `failed` (quality) | Requirements unclear | Clarify constraints, provide examples |
| `failed` (timeout) | Task too large | Decompose into Stories (<4h each) |
| `failed` (iteration) | Agent loops | Simplify requirements, add checkpoints |

### Retry Strategy

```yaml
retry_protocol:
  1: "Check output for specific error patterns"
  2: "If vague requirements → add deliverables, success criteria"
  3: "If too large → break into Epic with Stories"
  4: "If stalled on same error → try different approach"
```

---

## Work Hierarchy

```yaml
hierarchy:
  epic:
    scope: "3-15 sessions"
    example: "Implement auth system"
  story:
    scope: "1 session (4-16h)"
    example: "Add login page"
  task:
    scope: "1-4 hours"
    example: "Hash passwords"
```

**Decomposition rule**: If >4 hours, break down.

---

## Interactive Mode Commands

| Command | Purpose |
|---------|---------|
| `/help` | List all commands |
| `/status` | Orchestrator state, active task |
| `/task list` | All tasks with status |
| `/llm` | Show or configure LLM settings |
| `/execute <id>` | Run task by ID |
| `/exit` | Exit interactive mode |

**CRITICAL**: ALL commands require the `/` prefix. Text without `/` is treated as a task description sent to the orchestrator for execution.

```yaml
# COMMON MISTAKE - causes infinite iteration loops
wrong: 'obra-client interactive -c "/llm show" -c "exit"'
cause: '"exit" without / is treated as orchestration objective'
fix: 'obra-client interactive -c "/llm show" -c "/exit"'
```

### /llm Command Reference

Use `/llm` to view or change LLM configuration during a session:

```bash
/llm                      # Show current configuration
/llm show                 # Same as above
/llm model <model>        # Set model for both roles
/llm opus                 # Shorthand for /llm model opus
/llm orch model opus      # Set orchestrator model only
/llm impl provider google # Set implementation provider
/llm both provider anthropic model sonnet  # Set both roles
/llm help                 # Full command reference
```

**Keys**: `provider` (anthropic, google, openai), `interface` (oauth, api_key), `model` (default, sonnet, opus, haiku, or full model name)

**Note**: `/llm` changes are persisted to `~/.obra/client-config.yaml`. Use CLI flags (e.g., `--model opus`) for session-only overrides.

---

## Further Reading

- **[task-templates.md](task-templates.md)** - Copy-paste task examples
- **[autonomous-setup.md](autonomous-setup.md)** - First-time setup guide
- **[ADR-027](../../../decisions/ADR-027-two-tier-prompting-architecture.md)** - Two-Tier Prompting architecture
