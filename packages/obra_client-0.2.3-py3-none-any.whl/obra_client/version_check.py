"""Client version checking against backend.

This module provides functionality to check the client version against
the backend API and display appropriate notifications to users.

Features:
- Version status detection (current, outdated, unsupported)
- Session-based caching (one version check per session)
- Installation-aware upgrade commands (pip, pipx, uv)
- Fail-open error handling (version check failures never block operation)

Environment Variables:
- OBRA_SKIP_VERSION_CHECK=1: Bypass all version checking

Usage:
    from obra_client.version_check import VersionChecker

    checker = VersionChecker(api_client)
    checker.show_startup_notification(console)

    if checker.should_block():
        raise typer.Exit(1)
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from rich.console import Console

    from obra_client.api_client import APIClient


class VersionStatus(Enum):
    """Version status tiers for client version checking.

    Attributes:
        CURRENT: Client version >= latest version (no notification)
        OUTDATED: min_supported <= client version < latest (warning, continues)
        UNSUPPORTED: client version < min_supported (error, blocked)
        UNKNOWN: Version check failed or returned invalid data
    """

    CURRENT = "current"
    OUTDATED = "outdated"
    UNSUPPORTED = "unsupported"
    UNKNOWN = "unknown"


@dataclass
class VersionInfo:
    """Version information returned from backend API.

    Attributes:
        current_version: The client's installed version
        latest_version: The latest available client version
        min_supported_version: Minimum version supported by backend
        status: Computed version status tier
        upgrade_message: Optional message from backend about upgrading
        release_notes_url: URL to release notes/changelog
    """

    current_version: str
    latest_version: str
    min_supported_version: str
    status: VersionStatus
    upgrade_message: str | None = None
    release_notes_url: str | None = None


class VersionChecker:
    """Checks client version against backend and manages notifications.

    Implements session-based caching to avoid repeated API calls within
    a single CLI session. All version check failures fail open (silently)
    to ensure version checking never blocks normal operation.

    Attributes:
        api_client: APIClient instance for making API calls
        _cached_info: Cached VersionInfo from last check
        _notification_shown: Whether startup notification was shown
        _skip_check: Whether version checking is disabled

    Example:
        checker = VersionChecker(api_client)
        checker.show_startup_notification(console)

        if checker.should_block():
            raise typer.Exit(1)

        # ... run orchestration ...

        checker.show_completion_hint(console)
    """

    def __init__(self, api_client: APIClient) -> None:
        """Initialize VersionChecker.

        Args:
            api_client: APIClient instance for making version API calls
        """
        self.api_client = api_client
        self._cached_info: VersionInfo | None = None
        self._notification_shown: bool = False
        self._skip_check: bool = self._should_skip_version_check()

    @staticmethod
    def _should_skip_version_check() -> bool:
        """Check if version checking should be skipped.

        Returns:
            True if OBRA_SKIP_VERSION_CHECK env var is set to truthy value
        """
        skip_value = os.environ.get("OBRA_SKIP_VERSION_CHECK", "").lower()
        return skip_value in ("1", "true", "yes")

    def check_version(self) -> VersionInfo:
        """Fetch version info from backend (cached for session).

        Makes a single API call per session to /version endpoint,
        caching the result for subsequent calls.

        Returns:
            VersionInfo with current status and version details

        Raises:
            Exception: If API call fails (caller should handle gracefully)
        """
        if self._cached_info is not None:
            return self._cached_info

        if self._skip_check:
            # Return dummy "current" info when checks are skipped
            self._cached_info = VersionInfo(
                current_version="0.0.0",
                latest_version="0.0.0",
                min_supported_version="0.0.0",
                status=VersionStatus.CURRENT,
                upgrade_message=None,
                release_notes_url=None,
            )
            return self._cached_info

        response = self.api_client.get_version()
        client_data = response.get("client", {})

        # Parse status from response, defaulting to UNKNOWN
        status_str = client_data.get("status", "unknown")
        try:
            status = VersionStatus(status_str)
        except ValueError:
            status = VersionStatus.UNKNOWN

        self._cached_info = VersionInfo(
            current_version=client_data.get("current_version", "unknown"),
            latest_version=client_data.get("latest_version", "unknown"),
            min_supported_version=client_data.get("min_supported_version", "0.0.0"),
            status=status,
            upgrade_message=client_data.get("upgrade_message"),
            release_notes_url=client_data.get("release_notes_url"),
        )
        return self._cached_info

    def get_upgrade_command(self) -> str:
        """Detect installation method and return appropriate upgrade command.

        Detects the installation method (pip, pipx, or uv) and returns
        the correct command to upgrade obra-client.

        Returns:
            Upgrade command string appropriate for the installation method
        """
        # Check for pipx
        if shutil.which("pipx"):
            try:
                result = subprocess.run(
                    ["pipx", "list", "--short"],
                    capture_output=True,
                    text=True,
                    timeout=5,
                    check=False,
                )
                if "obra-client" in result.stdout:
                    return "pipx upgrade obra-client"
            except Exception:
                pass

        # Check for uv
        if shutil.which("uv") and "uv" in sys.prefix.lower():
            return "uv pip install --upgrade obra-client"

        # Default to pip
        return "pip install --upgrade obra-client"

    def should_block(self) -> bool:
        """Check if version is unsupported and should block operation.

        Returns:
            True if version is unsupported and operation should be blocked,
            False otherwise (including on check failures - fail open)
        """
        if self._skip_check:
            return False

        try:
            info = self.check_version()
        except Exception:
            # Fail open - don't block on version check failures
            return False
        else:
            return info.status == VersionStatus.UNSUPPORTED

    def show_startup_notification(self, console: Console) -> None:
        """Show version notification on startup if needed.

        Displays:
        - Red error for unsupported versions
        - Yellow warning for outdated versions
        - Nothing for current versions

        Args:
            console: Rich Console instance for output
        """
        if self._notification_shown or self._skip_check:
            return

        try:
            info = self.check_version()
        except Exception:
            # Fail silently - don't block on version check failures
            return

        upgrade_cmd = self.get_upgrade_command()

        if info.status == VersionStatus.UNSUPPORTED:
            console.print()
            console.print(
                f"[red]Your obra-client version (v{info.current_version}) "
                f"is no longer supported.[/red]"
            )
            console.print()
            console.print(
                f"   The minimum supported version is v{info.min_supported_version}."
            )
            console.print(f"   Please upgrade to continue: [cyan]{upgrade_cmd}[/cyan]")
            console.print()
            console.print(
                "   [dim]Older versions may not work correctly with the current API.[/dim]"
            )
            console.print()
            self._notification_shown = True

        elif info.status == VersionStatus.OUTDATED:
            console.print()
            console.print(
                f"[yellow]obra-client v{info.latest_version} available[/yellow] "
                f"(you have v{info.current_version})"
            )
            console.print(f"   Upgrade: [cyan]{upgrade_cmd}[/cyan]")
            console.print()
            self._notification_shown = True

    def show_completion_hint(self, console: Console) -> None:
        """Show subtle upgrade hint after task completion.

        Only shows hint if:
        - Startup notification was not already shown
        - Version is outdated (not unsupported or current)

        Args:
            console: Rich Console instance for output
        """
        if self._notification_shown or self._skip_check:
            return

        try:
            info = self.check_version()
        except Exception:
            # Fail silently
            return

        if info.status == VersionStatus.OUTDATED:
            upgrade_cmd = self.get_upgrade_command()
            console.print()
            console.print(f"   [dim]Tip: Update available -> {upgrade_cmd}[/dim]")
            self._notification_shown = True

    def get_health_check_status(self) -> tuple[str, str]:
        """Get version status for health-check command output.

        Returns:
            Tuple of (status_indicator, message) where status_indicator is
            one of "ok", "warning", or "error"
        """
        if self._skip_check:
            return ("ok", "Version check disabled (OBRA_SKIP_VERSION_CHECK=1)")

        try:
            info = self.check_version()
        except Exception as e:
            return ("warning", f"Version check failed: {e}")

        if info.status == VersionStatus.CURRENT:
            return ("ok", f"v{info.current_version} (current)")
        if info.status == VersionStatus.OUTDATED:
            return (
                "warning",
                f"v{info.current_version} (v{info.latest_version} available)",
            )
        if info.status == VersionStatus.UNSUPPORTED:
            return (
                "error",
                f"v{info.current_version} (unsupported, min: v{info.min_supported_version})",
            )
        return ("warning", f"v{info.current_version} (status unknown)")
