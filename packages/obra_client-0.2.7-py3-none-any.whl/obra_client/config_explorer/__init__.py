"""Configuration Explorer TUI for Obra Client.

This module provides an interactive terminal-based configuration browser
using Textual. Users can navigate, search, and modify Obra settings through
a visual tree interface.

Usage:
    obra-client config explore
    # or in interactive mode:
    /config explore
"""

from obra_client.config_explorer.app import ConfigExplorerApp

__all__ = ["ConfigExplorerApp"]
