"""Legal documents package for Obra Client.

This package contains bundled legal documents:
- BETA_TERMS.txt: Full Beta Software Agreement (v2.1)
- TERMS_SUMMARY.txt: Plain Language Summary for CLI display

These documents are bundled in the wheel and accessed via importlib.resources.
"""

from importlib import resources
from typing import Optional

# Legal document versions (must match source documents)
TERMS_VERSION = "2.1"
PRIVACY_VERSION = "1.3"


def get_terms_summary() -> str:
    """Get Plain Language Summary for CLI display.

    Returns:
        Content of TERMS_SUMMARY.txt
    """
    return resources.files(__package__).joinpath("TERMS_SUMMARY.txt").read_text()


def get_full_terms() -> str:
    """Get full Beta Terms for reference.

    Returns:
        Content of BETA_TERMS.txt
    """
    return resources.files(__package__).joinpath("BETA_TERMS.txt").read_text()


def get_terms_version() -> str:
    """Get current terms version.

    Returns:
        Terms version string (e.g., "2.1")
    """
    return TERMS_VERSION


def get_privacy_version() -> str:
    """Get current privacy policy version.

    Returns:
        Privacy policy version string (e.g., "1.3")
    """
    return PRIVACY_VERSION
