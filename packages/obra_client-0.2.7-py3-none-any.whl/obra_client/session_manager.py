"""Session manager for tracking and resuming orchestration sessions.

Provides checkpoint management for interrupted sessions, allowing users
to resume orchestration after network failures or client crashes.
"""

import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional

from obra_client.api_client import APIClient
from obra_client.exceptions import APIError


@dataclass
class SessionCheckpoint:
    """Session checkpoint data.

    Attributes:
        session_id: Session ID from Cloud Functions
        objective: Original task objective
        task_type: Task type (feature, bug_fix, etc.)
        project_dir: Project working directory
        iteration: Last known iteration number
        status: Last known status
        created_at: When session was created
        last_updated: When checkpoint was last updated
    """

    session_id: str
    objective: str
    task_type: str
    project_dir: str
    iteration: int
    status: str
    created_at: str
    last_updated: str


class SessionManager:
    """Manages session checkpoints for resume functionality.

    Stores session state locally in ~/.obra/last-session.json
    to enable resuming after interruptions.

    Example:
        manager = SessionManager()
        manager.save_checkpoint(session_id="abc123", objective="Add auth", ...)

        # Later, after restart
        checkpoint = manager.load_checkpoint()
        if checkpoint and manager.should_resume():
            # Resume from checkpoint
            ...
    """

    CHECKPOINT_FILE = Path.home() / ".obra" / "last-session.json"

    def __init__(self) -> None:
        """Initialize SessionManager."""
        # Ensure .obra directory exists
        self.CHECKPOINT_FILE.parent.mkdir(parents=True, exist_ok=True)

    def save_checkpoint(
        self,
        session_id: str,
        objective: str,
        task_type: str,
        project_dir: str,
        iteration: int,
        status: str,
    ) -> None:
        """Save session checkpoint to disk.

        Args:
            session_id: Session ID
            objective: Task objective
            task_type: Task type
            project_dir: Project directory
            iteration: Current iteration number
            status: Current status
        """
        checkpoint = {
            "session_id": session_id,
            "objective": objective,
            "task_type": task_type,
            "project_dir": project_dir,
            "iteration": iteration,
            "status": status,
            "created_at": datetime.now().isoformat(),
            "last_updated": datetime.now().isoformat(),
        }

        try:
            with open(self.CHECKPOINT_FILE, "w", encoding="utf-8") as f:
                json.dump(checkpoint, f, indent=2)
        except Exception as e:
            # Don't fail on checkpoint save errors
            print(f"Warning: Failed to save session checkpoint: {e}")

    def load_checkpoint(self) -> Optional[SessionCheckpoint]:
        """Load last session checkpoint from disk.

        Returns:
            SessionCheckpoint if exists, None otherwise
        """
        if not self.CHECKPOINT_FILE.exists():
            return None

        try:
            with open(self.CHECKPOINT_FILE, encoding="utf-8") as f:
                data = json.load(f)

            return SessionCheckpoint(**data)

        except Exception as e:
            # Corrupted checkpoint file
            print(f"Warning: Failed to load session checkpoint: {e}")
            return None

    def clear_checkpoint(self) -> None:
        """Remove checkpoint file."""
        if self.CHECKPOINT_FILE.exists():
            self.CHECKPOINT_FILE.unlink()

    def should_resume(
        self,
        checkpoint: SessionCheckpoint,
        api_client: APIClient,
    ) -> bool:
        """Check if session can be resumed.

        Verifies that:
        1. Session still exists on server
        2. Session is still active (not expired/completed)

        Args:
            checkpoint: Session checkpoint to verify
            api_client: API client for status checks

        Returns:
            True if session can be resumed, False otherwise
        """
        try:
            # Check session status on server
            status_response = api_client.get_status(checkpoint.session_id)

            # Can only resume if session is still active
            if status_response["status"] != "active":
                return False

            return True

        except APIError:
            # Session doesn't exist or server unreachable
            return False

    def update_iteration(self, iteration: int) -> None:
        """Update iteration number in existing checkpoint.

        Args:
            iteration: New iteration number
        """
        checkpoint = self.load_checkpoint()
        if checkpoint:
            self.save_checkpoint(
                session_id=checkpoint.session_id,
                objective=checkpoint.objective,
                task_type=checkpoint.task_type,
                project_dir=checkpoint.project_dir,
                iteration=iteration,
                status=checkpoint.status,
            )
