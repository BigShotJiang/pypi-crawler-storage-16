# Obra Setup Guide for LLM Agents

```yaml
# DOCUMENT METADATA
purpose: "Step-by-step setup for LLM agents to install and configure Obra"
audience: "LLM agents performing autonomous setup"
version: "2.1.1"
last_updated: "2025-12"

# DOCUMENT INDEX
sections:
  - quick_reference    # Lines 24-44: TL;DR commands
  - role_change        # Lines 48-62: Your role during vs after setup
  - installation       # Lines 66-168: Step-by-step install
  - agent_invocation   # Lines 172-262: CRITICAL - correct invocation patterns for LLM agents
  - working_directory  # Lines 266-312: CRITICAL project directory setup
  - verification       # Lines 316-352: Health checks and first task
  - os_specific        # Lines 356-393: Platform notes
  - error_recovery     # Lines 397-433: Troubleshooting
  - common_mistakes    # Lines 437-493: Anti-patterns (includes mistake_5: missing project)
  - further_reading    # Lines 550+: Related docs
```

---

## Quick Reference

```yaml
# TL;DR - copy these commands
install: "pip install obra-client"
auth: "obra-client login"
verify: "obra-client health-check"
test: "obra-client interactive -c '/status' -c '/exit'"

# CRITICAL: Always set project directory before tasks
use: |
  obra-client interactive \
    -c "/project ~/obra-projects/my-project" \
    -c "Create a task to <description>" \
    -c "/execute 1" \
    -c "/exit"

prerequisites:
  python: "3.12+"
  llm_cli: "claude | gemini | codex"
```

---

## Role Change: Setup vs Usage

```yaml
# IMPORTANT: Your role changes after setup

during_setup:
  role: EXECUTOR
  action: "Run installation commands directly"

after_setup:
  role: TASK_ARCHITECT
  action: "Formulate prompts, delegate to Obra"
  forbidden: "Writing code directly"

# After setup complete, see capability-brief.md for delegation protocol
```

---

## Installation (6 Steps)

### Step 1: Verify Python

```bash
python --version  # or python3 --version
# Required: 3.12+
```

```yaml
if_version_too_low:
  windows: "python.org → Download → Check 'Add to PATH'"
  macos: "brew install python@3.12"
  linux: "sudo apt install python3.12 python3.12-venv"
```

### Step 2: Install Package

```bash
# Option A: pip (recommended)
pip install obra-client

# Option B: pipx (isolated)
pipx install obra-client

# Verify:
obra-client version
# Expected: 0.1.24+
```

### Step 3: Authenticate

```bash
obra-client login
```

```yaml
flow:
  1: "Browser opens to Google/GitHub OAuth"
  2: "User signs in"
  3: "Token saved to ~/.obra/config.json"
  4: "Terminal shows 'Login successful'"

errors:
  "Browser didn't open":
    cause: "Headless environment"
    fix: "Copy URL from terminal, paste in browser"
  "Not authorized":
    cause: "Not on beta allowlist"
    fix: "Contact support@obra.dev"
  "Connection refused":
    cause: "Network/firewall"
    fix: "Check internet, try different network"
```

### Step 4: Verify LLM CLI

```bash
# At least one must be available:
claude --version    # Claude Code (recommended)
gemini --version    # Gemini CLI
codex --version     # OpenAI Codex
```

```yaml
if_no_llm_cli:
  claude_code:
    install: "npm install -g @anthropic-ai/claude-code"
    docs: "https://docs.anthropic.com/claude-code"
  gemini_cli:
    install: "pip install google-generativeai"
    docs: "https://ai.google.dev/gemini-api/docs"
  openai_codex:
    install: "npm install -g @openai/codex"
    docs: "https://platform.openai.com/docs"
```

### Step 5: Health Check

```bash
obra-client health-check
```

```yaml
expected_output:
  - "✓ Python 3.12+"
  - "✓ Authentication valid"
  - "✓ API reachable"
  - "✓ LLM CLI found"

errors:
  "Authentication not valid": "obra-client login"
  "API not reachable": "Check internet"
  "LLM CLI not found": "Install claude/gemini/codex"
```

### Step 6: Functional Test

```bash
obra-client interactive -c "/status" -c "/exit"
# Expected: Shows orchestrator state without errors
```

---

## Running Obra from an LLM Agent (CRITICAL)

```yaml
# CRITICAL: Running Obra incorrectly wastes context and causes failures
# Follow these patterns exactly

principle: "Run Obra as a FOREGROUND command that completes, not a background process to poll"
```

### Correct Pattern: Scripted Mode (Blocking)

```bash
# CORRECT: Use -c flags for scripted commands that exit cleanly
obra-client interactive \
  -c "/project ~/obra-projects/my-feature" \
  -c "Create hello_world.py that prints Hello World" \
  -c "/execute 1" \
  -c "/exit"

# This runs to completion and returns output directly
# No polling needed - command exits when done
```

### Correct Pattern: Single-Shot Execute

```bash
# CORRECT: Simplest pattern for single tasks
obra-client execute "Implement the feature" --project-dir ~/obra-projects/my-feature

# Runs to completion, no polling needed
```

### WRONG Pattern: Background Polling (DO NOT DO)

```yaml
# WRONG: Running interactive mode in background and polling
wrong_approach:
  step_1: "Start Obra with run_in_background: true"
  step_2: "Poll BashOutput repeatedly"
  result: "Context flooded with repeated startup messages"

why_it_fails:
  - "Each BashOutput poll returns the same startup output"
  - "Tight polling loop creates hundreds of redundant messages"
  - "Context window fills with repeated: 'Project directory...', 'Contacting server...'"
  - "Eventually causes context exhaustion or confusion"

symptoms:
  - "BashOutput repeated 10+ times with identical content"
  - "Terminal flooded with '✓ Project directory' messages"
  - "Session never progresses past startup"
```

### If You MUST Use Background Mode

```yaml
# Only use background mode for truly long-running tasks (>10 minutes)
# Even then, follow these rules:

rules:
  1: "Use run_in_background: true ONLY for very long tasks (>10 min)"
  2: "Wait 2-5 MINUTES between BashOutput polls (not seconds)"
  3: "Use filter parameter to capture only completion signals"
  4: "Set a maximum poll count (e.g., 5 attempts over 10-25 minutes)"

polling_intervals:
  wrong: "Every 5-30 seconds (floods context)"
  minimum: "Every 2 minutes"
  recommended: "Every 5 minutes for long tasks"
  example: "5 polls at 5-minute intervals = 25 minutes coverage"

example_with_filter:
  command: "BashOutput with filter: 'completed|failed|ERROR|Quality score'"
  why: "Only captures completion status, not startup spam"

better_alternative: |
  # Instead of background mode, use scripted mode with extended timeout
  # Let the command run to completion in foreground
  # Bash tool supports timeout up to 600000ms (10 minutes)
  obra-client interactive \
    -c "/project ~/my-project" \
    -c "Complex task description" \
    -c "/execute 1" \
    -c "/exit"
```

### Summary: Agent Invocation Checklist

```yaml
checklist:
  - "Use scripted mode (-c flags) or single-shot execute"
  - "Always include -c '/exit' as final command"
  - "Set /project FIRST before any task creation"
  - "Do NOT use background mode for normal tasks"
  - "If background mode required: poll sparingly with filters"
  - "Never poll in a tight loop"
```

---

## Working Directory Setup (CRITICAL)

```yaml
# CRITICAL: Obra outputs files to the PROJECT directory
# If not set, files go to unknown/previous location and you won't find them

pattern:
  1: "Create or identify target directory"
  2: "Set project in Obra BEFORE creating tasks"
  3: "Verify output in correct location after execution"

example_scripted:
  |
  mkdir -p ~/obra-projects/my-feature
  obra-client interactive \
    -c "/project ~/obra-projects/my-feature" \
    -c "Create hello_world.py that prints Hello World" \
    -c "/execute 1" \
    -c "/exit"
  ls ~/obra-projects/my-feature/  # Verify output location

example_single_shot:
  |
  obra-client execute "Create hello_world.py" --project-dir ~/obra-projects/my-feature

failure_pattern:
  symptom: "Task shows 'completed successfully' but no files found"
  cause: "Project directory not set before task creation"
  fix: "Always use /project as FIRST command in interactive mode"
```

### Interactive Mode: /project Command

```yaml
# Use /project to set working directory for file output
command: "/project <path>"
example: "/project ~/obra-projects/my-app"

behavior:
  - "Sets working directory for current session"
  - "All file operations happen in this directory"
  - "Must be set BEFORE creating tasks"
  - "Path is expanded (~ works)"

verification:
  - "After /project, run task"
  - "After exit, ls <path> to confirm files"
```

---

## Verification Checklist

```yaml
checklist:
  - python_3_12_plus: "python --version"
  - package_installed: "obra-client version"
  - authenticated: "obra-client whoami"
  - llm_cli_available: "claude --version (or gemini/codex)"
  - health_passes: "obra-client health-check"
  - functional_test: "obra-client interactive -c '/status' -c '/exit'"
```

### First Task (End-to-End Verification)

```bash
# 1. Create project directory
mkdir -p ~/obra-projects/hello-test

# 2. Run task with project directory set FIRST
obra-client interactive \
  -c "/project ~/obra-projects/hello-test" \
  -c "Create hello_world.py that prints Hello World" \
  -c "/execute 1" \
  -c "/exit"

# Expected: Session created → Task created → LLM executes → Results with quality score

# 3. VERIFY output location (CRITICAL!)
ls ~/obra-projects/hello-test/
# Expected: hello_world.py exists

cat ~/obra-projects/hello-test/hello_world.py
# Expected: Python file with print("Hello World")

python ~/obra-projects/hello-test/hello_world.py
# Expected: Hello World
```

---

## OS-Specific Notes

```yaml
windows:
  shell: "PowerShell or Command Prompt"
  python: "python or py"
  path_sep: "\\"
  issues:
    "Python not in PATH": "Reinstall with 'Add to PATH' checked"
    "Permission denied": "Run as Administrator or --user flag"

macos:
  shell: "zsh (default)"
  python: "python3"
  path_sep: "/"
  issues:
    "python not found": "Use python3"
    "SSL errors": "/Applications/Python*/Install Certificates.command"

linux:
  shell: "bash"
  python: "python3"
  path_sep: "/"
  issues:
    "pip not found": "sudo apt install python3-pip"
    "Permission denied": "pip install --user or use venv"

wsl:
  notes:
    - "Treat as Linux"
    - "Windows paths via /mnt/c/"
    - "Browser login opens in Windows (works)"
```

---

## Error Recovery

### Authentication Errors

| Error | Cause | Fix |
|-------|-------|-----|
| "Not authenticated" | No token | `obra-client login` |
| "Token expired" / 401 | Session timeout | `obra-client login` |
| "403 Forbidden" | Not on allowlist | Contact support |

### Installation Errors

| Error | Cause | Fix |
|-------|-------|-----|
| "pip not found" | Python incomplete | Reinstall Python |
| "Permission denied" | No write access | `pip install --user obra-client` |
| "Module not found" | PATH issue | Check pip location in PATH |

### Execution Errors

| Error | Cause | Fix |
|-------|-------|-----|
| "LLM CLI not found" | Not installed/PATH | Install, restart terminal |
| "Session not found" | Expired | Start new session |
| "API error 500" | Server issue | Retry in few minutes |

### 401 Despite Valid `whoami`

```yaml
# CRITICAL: whoami may show cached/stale data
scenario: "whoami shows valid auth, API returns 401"
cause: "Token cache mismatch"

fix:
  - "obra-client logout"
  - "obra-client login"
  - "obra-client interactive -c '/status' -c '/exit'  # Verify with real API"
```

---

## Common Mistakes

```yaml
# MEMORIZE THESE - high error rate

mistake_1:
  wrong: "obra-client project new --name 'MyProject'"
  error: "No such command 'project'"
  correct: "cd ~/projects/MyProject && obra-client interactive"
  why: "Sessions auto-create from working directory"

mistake_2:
  wrong: "obra-client task create 'Add authentication'"
  error: "No such command 'task'"
  correct: "obra-client interactive -c 'Create a task to add auth' -c '/execute 1' -c '/exit'"
  why: "Tasks created via natural language in interactive mode"

mistake_3:
  wrong: "obra-client project list"
  error: "No such command 'project'"
  correct: "obra-client interactive -c '/task list' -c '/exit'"
  why: "Use /task list INSIDE interactive mode"

mistake_4:
  symptom: "whoami valid but 401 on API calls"
  cause: "Cached auth display"
  fix: "obra-client logout && obra-client login"

mistake_5:
  symptom: "Task shows 'completed successfully' but no files found"
  cause: "Project directory not set, output went to old/unknown location"
  correct: "Set /project BEFORE task creation"
  example: '-c "/project ~/my-project" -c "Create task..." -c "/execute 1"'
  why: "Without /project, files go to whatever directory was previously active"

mistake_6:
  symptom: "Infinite iterations, 'exit' is treated as task objective"
  cause: "Missing / prefix on exit command"
  wrong: '-c "/status" -c "exit"'
  correct: '-c "/status" -c "/exit"'
  why: "ALL commands require / prefix. Text without / is sent to orchestrator as task"
```

### Commands That DO NOT Exist

```yaml
# DO NOT ATTEMPT - these will fail
nonexistent:
  - "obra-client project"
  - "obra-client task"
  - "obra-client create"
  - "obra-client list"
  - "obra-client new"
  - "obra-client init"
  - "obra-client run"

# Use interactive mode instead
correct_pattern: "obra-client interactive -c '<natural language>' -c '/execute 1' -c '/exit'"
```

---

## Quick Command Reference

```yaml
# ALL available obra-client commands
commands:
  # Setup
  setup: "First-time setup with terms"
  login: "Authenticate (OAuth)"
  logout: "Clear credentials"
  whoami: "Show auth status"

  # Core
  interactive: "Interactive mode (RECOMMENDED)"
  orchestrate: "Non-interactive session"
  execute: "Single task execution"
  status: "Query session"
  resume: "Resume session"

  # Utilities
  version: "Show version"
  health-check: "Verify setup"
  config: "Configuration"
  docs: "View documentation"
```

---

## After Setup: Role Change

```yaml
# IMPORTANT: Once setup complete, your role changes

before: "Run installation commands"
after: "Formulate prompts, delegate to Obra, DO NOT write code"

key_principle: |
  You become a TASK ARCHITECT. Your job:
  1. Understand user request
  2. Formulate prompt with: objective, requirements, deliverables, success criteria
  3. Send to Obra: obra-client interactive -c "..." -c "/execute 1" -c "/exit"
  4. Review and report results

# See capability-brief.md for full delegation protocol
```

---

## Troubleshooting Commands

```bash
# Diagnostic sequence:
obra-client version       # Check installation
obra-client whoami        # Check auth (may be cached!)
obra-client health-check  # Full system check
obra-client config show   # View config

# Reset auth:
obra-client logout && obra-client login

# Verify with actual API call:
obra-client interactive -c "/status" -c "/exit"
```

---

## Further Reading

```yaml
related_docs:
  capability-brief.md: "When/how to use Obra (READ AFTER SETUP)"
  task-templates.md: "Copy-paste task examples"
```
