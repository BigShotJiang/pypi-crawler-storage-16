# Task Templates for LLM Agents

```yaml
# DOCUMENT METADATA
purpose: "Copy-paste task templates for common operations"
audience: "LLM agents delegating work to Obra"
version: "2.1.0"
last_updated: "2025-01"

# DOCUMENT INDEX
sections:
  - role_reminder       # Lines 20-35: You are TASK_ARCHITECT
  - template_structure  # Lines 40-60: How templates work
  - features            # Lines 65-130: Feature implementation
  - bugfixes            # Lines 135-190: Bug fixes
  - tests               # Lines 195-250: Test suites
  - refactoring         # Lines 255-310: Code refactoring
  - research            # Lines 315-380: Web research/data collection
  - documentation       # Lines 385-430: Docs
  - epics               # Lines 435-480: Large features
  - invocation          # Lines 485-540: How to invoke
  - mistakes            # Lines 545-570: Common errors
```

---

## Role Reminder

```yaml
# STOP - READ THIS FIRST
role: TASK_ARCHITECT
forbidden: [CODER, IMPLEMENTER, FILE_CREATOR]
action: DELEGATE_TO_OBRA

# You adapt these templates and send to Obra
# Obra's implementation agent does the actual work
# See capability-brief.md for full protocol
```

---

## Template Structure

```yaml
# All tasks follow this pattern:
template:
  title: "Imperative verb + object"
  description: "What to build/fix/create"
  deliverables:
    - "file1.py"
    - "file2.py"
  requirements:
    - "requirement 1"
    - "requirement 2"
  success_criteria:
    - "how to verify 1"
    - "how to verify 2"

# Render to natural language when invoking
```

---

## Feature Implementation

### New Function

```yaml
template: new_function
---
Title: Implement password hashing function

Description: Create secure password hashing using bcrypt.

Deliverables:
- src/auth/password.py

Requirements:
- Use bcrypt library
- Include salt generation
- Support password verification
- Add type hints
- Include docstrings

Success Criteria:
- Function hashes passwords consistently
- Verification works for correct passwords
- Verification fails for wrong passwords
- All type hints present
```

### New API Endpoint

```yaml
template: new_endpoint
---
Title: Create user registration API endpoint

Description: Implement POST /api/users/register endpoint.

Deliverables:
- src/api/routes/users.py
- tests/api/test_users.py

Requirements:
- Accept JSON: {email, password, name}
- Validate email format
- Hash password before storage
- Return 201 with user ID on success
- Return 400 on validation failure
- Return 409 if email exists

Success Criteria:
- Endpoint accessible at POST /api/users/register
- All validation cases handled
- Tests cover success and all error cases
- Correct status codes returned
```

### New Component (React)

```yaml
template: new_component
---
Title: Create login form component

Description: React component for user login.

Deliverables:
- src/components/LoginForm.tsx
- src/components/LoginForm.test.tsx

Requirements:
- Email and password fields
- Submit button
- Loading state during submission
- Error message display
- Form validation
- TypeScript with proper types

Success Criteria:
- Component renders without errors
- Validation prevents empty submission
- Loading indicator shows during submit
- Errors display correctly
- All tests pass
```

---

## Bug Fixes

### With Reproduction Steps

```yaml
template: bugfix_with_repro
---
Title: Fix null pointer in user lookup

Description: Fix crash when looking up non-existent user.

Bug Details:
- Location: src/services/user_service.py:45
- Error: AttributeError: 'NoneType' has no attribute 'email'
- Reproduction: Call get_user_email(999) with non-existent ID

Deliverables:
- Updated src/services/user_service.py
- Regression test in tests/test_user_service.py

Requirements:
- Return None or raise UserNotFoundError for missing users
- Don't change behavior for existing users
- Add defensive null check

Success Criteria:
- No crash on non-existent user lookup
- Existing tests still pass
- New regression test covers the case
```

### Performance Issue

```yaml
template: bugfix_performance
---
Title: Optimize slow database query in report generation

Description: Reports taking >30s due to N+1 query problem.

Location: src/reports/generator.py:generate_monthly_report()

Deliverables:
- Optimized src/reports/generator.py
- Performance test showing improvement

Requirements:
- Use eager loading or batch queries
- Reduce from N+1 to 2-3 queries
- Maintain same output format
- Target: <5s for 1000 records

Success Criteria:
- Same report output as before
- Execution time <5s for 1000 records
- All existing tests pass
```

---

## Test Suites

### Unit Tests

```yaml
template: unit_tests
---
Title: Add unit tests for ConfigManager

Description: Comprehensive tests for src/core/config_manager.py.

Deliverables:
- tests/test_config_manager.py

Requirements:
- Test all public methods
- Test edge cases (missing file, invalid YAML, etc.)
- Use pytest fixtures
- Mock file system operations
- Target 90%+ coverage

Success Criteria:
- All tests pass
- Coverage >90% for config_manager.py
- Edge cases covered
- No external file dependencies
```

### Integration Tests

```yaml
template: integration_tests
---
Title: Add integration tests for authentication flow

Description: End-to-end tests for register → login → access protected route.

Deliverables:
- tests/integration/test_auth_flow.py

Requirements:
- Test complete user registration
- Test login with registered user
- Test accessing protected endpoint with token
- Test rejection without token
- Use test database

Success Criteria:
- Full flow works end-to-end
- All error cases tested
- Uses isolated test database
- Cleans up after tests
```

---

## Refactoring

### Extract Function

```yaml
template: refactor_extract
---
Title: Extract validation logic from UserController

Description: Move inline validation to separate validator class.

Location: src/controllers/user_controller.py

Deliverables:
- src/validators/user_validator.py
- Updated src/controllers/user_controller.py
- tests/test_user_validator.py

Requirements:
- Extract email, password, name validation
- UserController calls validator
- Same validation behavior
- Validator is reusable

Success Criteria:
- All existing tests pass
- Controller is cleaner (<100 lines)
- Validator has own tests
- Validation behavior unchanged
```

### Add Type Hints

```yaml
template: refactor_types
---
Title: Add type hints to payment module

Description: Full type coverage for src/payments/.

Deliverables:
- Updated src/payments/*.py

Requirements:
- Type hints on all functions
- Return type annotations
- Use Optional where appropriate
- Add TypedDict for complex dicts
- Pass mypy --strict

Success Criteria:
- mypy --strict passes with no errors
- All functions have type hints
- Return types annotated
- Complex types documented
```

---

## Web Research / Data Collection

### Batch Data Collection

```yaml
template: research_batch
---
Title: Collect competitor pricing data

Description: Research and collect pricing from competitor websites.

Deliverables:
- data/competitor_pricing.json

Requirements:
- Use WebSearch to find pricing pages
- Use WebFetch to extract data
- Collect: company name, product, price, URL, date
- Minimum 10 competitors
- JSON schema validation

Success Criteria:
- JSON file contains 10+ entries
- All required fields populated
- URLs are valid
- Prices are numeric
```

### Research with Structured Output

```yaml
template: research_structured
---
Title: Research API rate limits for payment providers

Description: Collect rate limit information from payment API documentation.

Deliverables:
- docs/reference/research/payment_api_limits.md

Requirements:
- Research: Stripe, Square, PayPal, Braintree
- For each: requests/second, daily limits, burst limits
- Include source URLs
- Markdown table format

Success Criteria:
- All 4 providers documented
- Rate limits have numeric values
- Source URLs are valid
- Table renders correctly
```

### Multi-Batch Collection (Epic)

```yaml
template: research_epic
---
Title: Collect interview questions database

Description: Build comprehensive database of technical interview questions.

Stories:
  1_algorithms:
    - WebSearch for algorithm interview questions
    - Collect 50 questions with difficulty rating
    - Output: data/questions_algorithms.json

  2_system_design:
    - WebSearch for system design interviews
    - Collect 30 questions with topics
    - Output: data/questions_system_design.json

  3_behavioral:
    - WebSearch for behavioral interview questions
    - Collect 40 questions with categories
    - Output: data/questions_behavioral.json

Deliverables:
- data/questions_*.json (3 files)
- data/questions_combined.json (merged)

Success Criteria:
- Each batch meets count requirement
- JSON validates against schema
- No duplicate questions across batches
- Combined file merges correctly
```

---

## Documentation

### API Documentation

```yaml
template: docs_api
---
Title: Document REST API endpoints

Description: OpenAPI/Swagger documentation for all endpoints.

Deliverables:
- docs/api/openapi.yaml

Requirements:
- All endpoints documented
- Request/response schemas
- Authentication requirements
- Example requests and responses
- Error responses

Success Criteria:
- Valid OpenAPI 3.0 spec
- All endpoints covered
- Examples are accurate
- Renders correctly in Swagger UI
```

### Code Documentation

```yaml
template: docs_code
---
Title: Add docstrings to orchestrator module

Description: Google-style docstrings for src/core/orchestrator.py.

Deliverables:
- Updated src/core/orchestrator.py

Requirements:
- All public methods documented
- Args, Returns, Raises sections
- Usage examples for complex methods
- Type hints in signatures

Success Criteria:
- All public methods have docstrings
- Docstrings follow Google style
- Examples are runnable
- pydoc generates clean output
```

---

## Epic Template

```yaml
template: epic
---
Title: Implement User Authentication System

Description: Complete authentication with registration, login, password reset.

Stories:
  1_registration:
    - Registration endpoint
    - Email validation
    - Password hashing
    - Tests

  2_login:
    - Login endpoint
    - JWT generation
    - Session management
    - Tests

  3_password_reset:
    - Reset request endpoint
    - Email sending
    - Reset confirmation
    - Tests

Deliverables:
- src/auth/ module
- tests/test_auth/ tests
- docs/api/auth.md

Success Criteria:
- All Stories complete
- 90%+ test coverage
- API documented
- Security review passed
```

---

## Invocation Examples

### Single Task

```bash
obra-client interactive \
  -c "Create a task to implement password hashing function in src/auth/password.py using bcrypt with salt generation and verification support" \
  -c "/execute 1" \
  -c "/exit"
```

### With Full Details

```bash
obra-client interactive \
  -c "Create a task to add unit tests for ConfigManager:

**Deliverables**: tests/test_config_manager.py

**Requirements**:
- Test all public methods
- Test edge cases (missing file, invalid YAML)
- Use pytest fixtures
- Mock file system operations
- Target 90%+ coverage

**Success Criteria**:
- All tests pass
- Coverage >90%
- No external file dependencies
" \
  -c "/execute 1" \
  -c "/exit"
```

### Web Research Task

```bash
obra-client interactive \
  -c "Create a task to research and collect competitor pricing data from 10 competitors into data/competitor_pricing.json with schema validation" \
  -c "/execute 1" \
  -c "/exit"
```

### Check Results

```bash
obra-client interactive \
  -c "/status" \
  -c "/task list" \
  -c "/exit"
```

---

## Common Mistakes

```yaml
mistakes:
  vague_description:
    wrong: "Fix the bug"
    correct: "Fix null pointer in src/services/user_service.py:45 when looking up non-existent user"

  no_deliverables:
    wrong: "Add some tests"
    correct: "Add tests to tests/test_login.py covering success, failure, and lockout cases"

  too_large:
    wrong: "Implement the entire payment system"
    correct: "Create Epic with Stories: payment models, payment API, payment webhooks"

  no_success_criteria:
    wrong: "Make it work"
    correct: "All tests pass, coverage >90%, response time <100ms"
```

---

## Further Reading

```yaml
related_docs:
  capability-brief.md: "When to use Obra, decision tree"
  autonomous-setup.md: "First-time setup"
```
