"""File watcher utility for tracking modified files in a project directory.

Provides lightweight file system monitoring to detect recently modified files
for prompt enrichment (Tier 2 context injection).
"""

import os
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import List


@dataclass
class FileInfo:
    """Information about a modified file.

    Attributes:
        path: Absolute path to the file
        relative_path: Path relative to project root
        size: File size in bytes
        modified_time: Last modification timestamp
        modified_ago_minutes: Minutes since last modification
    """

    path: str
    relative_path: str
    size: int
    modified_time: datetime
    modified_ago_minutes: float


class FileWatcher:
    """Tracks recently modified files in a project directory.

    This is a lightweight implementation that scans the file system
    on-demand (not continuous monitoring). Suitable for prompt enrichment
    where we need a snapshot of recent activity.

    Example:
        watcher = FileWatcher()
        recent_files = watcher.get_modified_files(
            project_dir="/home/user/myproject",
            since_minutes=30
        )
        for file in recent_files:
            print(f"{file.relative_path} modified {file.modified_ago_minutes:.1f}m ago")
    """

    # Files/directories to exclude from scanning (common patterns)
    DEFAULT_EXCLUDES = {
        ".git",
        ".obra",
        "__pycache__",
        ".pytest_cache",
        ".mypy_cache",
        ".ruff_cache",
        "node_modules",
        "venv",
        ".venv",
        "env",
        ".env",
        "dist",
        "build",
        "*.pyc",
        "*.pyo",
        "*.pyd",
        ".DS_Store",
        "*.swp",
        "*.swo",
        "*~",
    }

    def __init__(self, exclude_patterns: set[str] | None = None) -> None:
        """Initialize FileWatcher.

        Args:
            exclude_patterns: Additional patterns to exclude (merged with defaults)
        """
        self.exclude_patterns = self.DEFAULT_EXCLUDES.copy()
        if exclude_patterns:
            self.exclude_patterns.update(exclude_patterns)

    def get_modified_files(
        self,
        project_dir: str | Path,
        since_minutes: int = 10,
        max_files: int = 50,
    ) -> List[FileInfo]:
        """Get files modified within the last N minutes.

        Args:
            project_dir: Project root directory to scan
            since_minutes: Look back window in minutes (default: 10)
            max_files: Maximum number of files to return (default: 50)

        Returns:
            List of FileInfo objects, sorted by most recently modified first

        Raises:
            ValueError: If project_dir doesn't exist
            PermissionError: If project_dir is not readable
        """
        project_path = Path(project_dir).resolve()

        if not project_path.exists():
            raise ValueError(f"Project directory does not exist: {project_dir}")

        if not project_path.is_dir():
            raise ValueError(f"Path is not a directory: {project_dir}")

        # Calculate cutoff time
        now = datetime.now()
        cutoff_time = now - timedelta(minutes=since_minutes)

        # Scan for modified files
        modified_files: List[FileInfo] = []

        try:
            for root, dirs, files in os.walk(project_path):
                # Filter out excluded directories (modify in-place to skip traversal)
                dirs[:] = [d for d in dirs if not self._should_exclude(d)]

                for filename in files:
                    if self._should_exclude(filename):
                        continue

                    file_path = Path(root) / filename

                    try:
                        stat = file_path.stat()
                        modified_time = datetime.fromtimestamp(stat.st_mtime)

                        # Only include files modified after cutoff
                        if modified_time > cutoff_time:
                            relative_path = str(file_path.relative_to(project_path))
                            modified_ago_minutes = (now - modified_time).total_seconds() / 60

                            file_info = FileInfo(
                                path=str(file_path),
                                relative_path=relative_path,
                                size=stat.st_size,
                                modified_time=modified_time,
                                modified_ago_minutes=modified_ago_minutes,
                            )
                            modified_files.append(file_info)

                    except (OSError, PermissionError):
                        # Skip files we can't access
                        continue

        except PermissionError as e:
            raise PermissionError(f"Cannot read project directory: {e}") from e

        # Sort by most recently modified first
        modified_files.sort(key=lambda f: f.modified_time, reverse=True)

        # Limit to max_files
        return modified_files[:max_files]

    def _should_exclude(self, name: str) -> bool:
        """Check if file or directory should be excluded.

        Args:
            name: Filename or directory name

        Returns:
            True if should be excluded, False otherwise
        """
        # Exact match
        if name in self.exclude_patterns:
            return True

        # Wildcard match (simple glob-like patterns)
        for pattern in self.exclude_patterns:
            if "*" in pattern:
                # Simple wildcard matching
                if pattern.startswith("*") and name.endswith(pattern[1:]):
                    return True
                if pattern.endswith("*") and name.startswith(pattern[:-1]):
                    return True

        return False

    def format_for_prompt(
        self,
        files: List[FileInfo],
        max_path_length: int = 100,
    ) -> str:
        """Format file list for prompt injection.

        Args:
            files: List of FileInfo objects
            max_path_length: Maximum path length (truncate if longer)

        Returns:
            Formatted string for prompt enrichment

        Example Output:
            Recent Files (modified in last 10 minutes):
            - src/auth/handler.py (2.5m ago, 1.2KB)
            - tests/test_auth.py (5.1m ago, 3.4KB)
            - config/settings.py (8.7m ago, 890B)
        """
        if not files:
            return "No recently modified files."

        lines = ["Recent Files:"]

        for file in files:
            # Truncate long paths
            path = file.relative_path
            if len(path) > max_path_length:
                path = "..." + path[-(max_path_length - 3) :]

            # Format file size
            size_str = self._format_size(file.size)

            # Format time ago
            time_str = f"{file.modified_ago_minutes:.1f}m ago"

            lines.append(f"  - {path} ({time_str}, {size_str})")

        return "\n".join(lines)

    @staticmethod
    def _format_size(size_bytes: int) -> str:
        """Format file size in human-readable format.

        Args:
            size_bytes: Size in bytes

        Returns:
            Formatted size string (e.g., "1.2KB", "3.4MB")
        """
        if size_bytes < 1024:
            return f"{size_bytes}B"
        elif size_bytes < 1024 * 1024:
            return f"{size_bytes / 1024:.1f}KB"
        else:
            return f"{size_bytes / (1024 * 1024):.1f}MB"
