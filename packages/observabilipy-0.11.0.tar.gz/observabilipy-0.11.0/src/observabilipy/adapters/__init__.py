"""Adapters for observability storage and frameworks."""
