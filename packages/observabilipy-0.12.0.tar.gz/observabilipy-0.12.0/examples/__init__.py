# Examples package - makes examples importable for testing
