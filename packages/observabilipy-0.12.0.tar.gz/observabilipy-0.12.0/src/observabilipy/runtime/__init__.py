"""Runtime components for observability."""

from observabilipy.runtime.embedded import EmbeddedRuntime

__all__ = ["EmbeddedRuntime"]
