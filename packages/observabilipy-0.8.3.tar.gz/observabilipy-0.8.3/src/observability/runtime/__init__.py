"""Runtime components for observability."""

from observability.runtime.embedded import EmbeddedRuntime

__all__ = ["EmbeddedRuntime"]
