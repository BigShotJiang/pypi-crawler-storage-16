"""Framework adapters for observability endpoints."""
