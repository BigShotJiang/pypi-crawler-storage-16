if __name__ == "__main__":
    from .dms_mirror import DmsMirror
    DmsMirror().main()
