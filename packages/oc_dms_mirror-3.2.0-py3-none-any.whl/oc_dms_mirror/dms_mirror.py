#!/usr/bin/env python3

import argparse
import ast
import os
import time
import json
import tempfile
import multiprocessing
import posixpath
import re
import structlog
from enum import Enum

from oc_checksumsq.checksums_interface import ChecksumsQueueClient
from oc_checksumsq.checksums_interface import FileLocation
from string import Template

from oc_cdtapi import NexusAPI, DmsAPI, PgAPI, PgQAPI, VaultAPI

from oc_cdtapi.API import HttpAPIError
from oc_logging import setup_json_logging
from requests.exceptions import ConnectionError

class DmsMirror:
    """
    A class for artifacts mirroring from Dms API
    """
    def __init__(self):
        """
        Basic initialization
        """
        self.__errors = (ConnectionError, HttpAPIError, KeyError)
        self._dms_client = None
        self._mvn_client = None
        self._pg_client = None
        self._psql_mq_client = None
        self._queue_client = None
        self.__process_name = "?"

        self.logger = structlog.get_logger()

    def __log_msg(self, message):
        """
        Log a message for multiprocessing: append process name
        """
        return ': '.join([f"[{self.__process_name}]", message])

    @property
    def queue_client(self):
        if not self._queue_client:
            self._queue_client = self._get_queue_client()

        return self._queue_client

    @property
    def mvn_client(self):
        if not self._mvn_client:
            self._mvn_client = self._get_mvn_client()

        return self._mvn_client

    @property
    def dms_client(self):
        if not self._dms_client:
            self._dms_client = self._get_dms_client()

        return self._dms_client

    @property
    def pg_client(self):
        if not self._pg_client:
            self._pg_client = self._get_pg_client()

        return self._pg_client

    @property
    def psql_mq_client(self):
        if not self._psql_mq_client:
            self._psql_mq_client = self._get_psql_mq_client()

        return self._psql_mq_client

    def _get_pg_client(self):
        """
        Return PgAPI instance basing on version specified
        :return PgAPI.PostgresAPI:
        """

        _pg_client = PgAPI.PostgresAPI(
                root=self._args.pg_url,
                user=self._args.pg_user,
                auth=self._args.pg_password)

        return _pg_client

    def _get_psql_mq_client(self):
        """
        Return PgQAPI instance 
        :return PgQAPI.PgQAPI:
        """
        self.logger.debug(self.__log_msg("reached _get_psql_mq_client"))
        self.logger.debug(self.__log_msg("trying to connect to %s" % self._args.psql_mq_url))
        _psql_mq_client = PgQAPI.PgQAPI(
                url=self._args.psql_mq_url,
                username=self._args.psql_mq_user,
                password=self._args.psql_mq_password)

        return _psql_mq_client

    def _get_dms_client(self):
        """
        Return DmsAPI instance basing on version specified
        :return DmsAPI.DmsAPI:
        """

        if self._args.dms_api_version == 3:
            return DmsAPI.DmsAPIv3(root=self._args.dms_url,
                                   user=self._args.dms_user,
                                   auth=self._args.dms_password)


        if self._args.dms_crs_url:
            os.environ["DMS_CRS_URL"] = self._args.dms_crs_url

        if self._args.dms_token:
            os.environ["DMS_TOKEN"] = self._args.dms_token

        _dms_client = DmsAPI.DmsAPI(
                root=self._args.dms_url,
                user=self._args.dms_user,
                auth=self._args.dms_password)

        self.logger.debug(self.__log_msg(f"DMS_CRS_URL: [{_dms_client.crs_root}]"))
        # do not log headers since token may be displayed there!

        return _dms_client

    def _get_mvn_client(self):
        """
        Return NexusAPI instance
        """
        return NexusAPI.NexusAPI(root=self._args.mvn_url, user=self._args.mvn_user, auth=self._args.mvn_password,
                                 readonly=False, anonymous=False, upload_repo=self._args.mvn_upload_repo,
                                 download_repo=self._args.mvn_download_repo)

    def _get_queue_client(self):
        # Set AMQP Credentials to be taken from VaultAPI
        _q = ChecksumsQueueClient()
        _q.setup_from_args(self._args)
        _q.connect()
        _q.ping()
        _q.disconnect()
        return _q

    def process_component_webhook(self, payload):
        """
        Process component from webhook
        :param str payload: Webhook payload
        :return: 'None' on success, raised exception on failure
        """
        event_type = payload.get('type')

        if event_type != self.DmsEventType.PUBLISH_COMPONENT_VERSION.value:
            _err_msg = f"Event type is {event_type}, skipping"
            self.logger.error(self.__log_msg(_err_msg))
            raise Exception(_err_msg)

        component_data = payload.get('componentVersion', {})
        if not component_data or not isinstance(component_data, dict):
            raise ValueError("Missing or invalid componentVersion in payload")

        component = component_data.get('component')
        version = component_data.get('version')
        if not component or not version:
            raise ValueError(f"Missing required fields: component={component}, version={version}")

        if self._args.auto_register_component:
            self.register_component(payload)

        artifacts =  payload.get('artifacts')

        for artifact in artifacts:
            self.process_artifact(artifact, component, version)

    def register_component(self, payload):
        component_id = payload.get("componentVersion").get("component")
        component_name = payload.get("componentVersion").get("displayName")

        if self.is_component_registered(component_id):
            self.logger.info(f"Component with id [{component_id}] already registered, skipping")
            return

        self.logger.info(f"Registering component with id [{component_id}]")
        client = payload.get("componentVersion").get("clientCode")
        ciregexp = self.generate_ci_regexp(component_id, client)
        if not ciregexp:
            return
        register_payload = {
            "ci_type_id": component_id,
            "ci_type_group_id": component_id,
            "name": component_name,
            "is_standard": "N" if client else "Y",
            "is_deliverable": False,
            "regexp": self.generate_ci_regexp(component_id, client),
            "loc_type_id": "NXS",
            "dms_id": component_id,
            "doc_artifactid": component_id,
            "rn_artifactid": component_id
        }

        try:
            res = self.pg_client.post_new_component(register_payload)
            if res.status_code == 200:
                self.logger.warning("Component couldn't be registered, due to duplicate")
        except HttpAPIError as e:
            self.logger.error(f"Component registration error: [{e.resp}]")
        self.logger.info(f"Component with id [{component_id}] registered")

    def generate_ci_regexp(self, component, client=None):
        distr_gav_template = self._gav_template.get("tgtGavTemplate").get("distribution")
        if not distr_gav_template:
            self.logger.warning(
                self.__log_msg("Gav Template for distribution is not appear, skipping")
            )
            return None

        distr_gav_template = distr_gav_template.replace("\\", "")

        if client:
            distr_gav_template = distr_gav_template.replace("$component", component).replace(".$client", f".{client}")
        else:
            distr_gav_template = distr_gav_template.replace("$component", component).replace(".$client", "")

        _result = {
            "n": "[^:]+",
            "v": "_VERSION_",
            "p": "[a-z]+",
            "c": "",
            "prefix": self._args.mvn_prefix,
        }
        _result["c_hyphen"] = f"-{_result['c']}" if _result["c"] else ""
        _result["c_colon"] = f":{_result['c']}" if _result["c"] else ""

        temp_template = Template(distr_gav_template).substitute(_result)

        escaped_template = re.sub(r'(?<!\$)\.', r'\\.', temp_template)

        return escaped_template

    def is_component_registered(self, component):
        try:
            self.pg_client.get_citypedms_by_dms_id(component)
        except HttpAPIError as e:
            if e.code == 404:
                return False

        return True

    def process_component(self, component):
        """
        Process component
        To be called in separate process
        :param str component: DMS component ID
        :return: 'None' on success, raised exception on failure
        """
        self.__process_name = component

        if not self._components[component].get('enabled', True):
            self.logger.info(self.__log_msg(f"Skipping: [{component}]. Disabled in the configuration"))
            return None

        self.logger.info(self.__log_msg(f"Processing component {component} in separate thread"))

        if any(list(map(lambda x: self._components[component].get(x), ["componentId", "artifactType"]))):
            self.logger.warning(self.__log_msg(
                "'componentId' and 'artifactType' parameters are deprecated and may be safely removed"))

        try:
            versions = self._make_dms_api_call_with_retries(self.dms_client.get_versions, component) or list()
            self.logger.info(self.__log_msg(f"[{component}]: versions to process: [{len(versions)}]"))

            for version in versions:
                self.process_version(version, component)
        except Exception as _e:
            # this makes multiprocessing to stuck:
            # extending exception message to show the subprocess (i.e. component) where it has been raised
            # necessary to log all exceptions at the end
            # _e.args = (self.__log_msg(""), *_e.args)
            # DO NOT DO THAT!
            # the second bad idea is to return exception as a result in mulitprocessing stack
            # this makes stuck too unfortunately
            # transfer a human-readable string to log it at the end
            _error_message = self.__log_msg(repr(_e))
            self.logger.error(_error_message, exc_info=True)
            return _error_message

        return None

    def process_version(self, version, component):
        """
        Process versions of component
        :param str version: component version
        :param str component: DmsComponentID
        """
        artifacts = self._make_dms_api_call_with_retries(self.dms_client.get_artifacts, component, version) or list()
        self.logger.info(self.__log_msg(f"[{component}:{version}]: artifacts to process: [{len(artifacts)}]"))

        for artifact in artifacts:
            self.process_artifact(artifact, component, version)

    def _get_static_ci_type(self, artifact_type):
        """
        Return a type basing on dms_type
        :param str artifact_type: DMS artifact type
        :param dict params:
        :return str:
        """

        if artifact_type == "documentation":
            return self._args.ci_type_documentation

        if artifact_type in ["notes", "report"]:
            return self._args.ci_type_release_notes

        return None

    def _make_gav_substitute(self, component, version, artifact):
        """
        Return a dictionary for GAV substitutes
        :param str component:
        :param str version:
        :param dict artifact: artifact params from DMS
        :return dict:
        """
        _result = {
                "at": artifact["type"],
                "n": artifact.get("name") or "", # not returned by v3
                "v": version,
                "p": artifact.get("packaging") or "", # not returned by v3
                "c": artifact.get("classifier") or "", # not returned by v3
                "prefix": self._args.mvn_prefix}

        # try to update missing components using DMS API v3 detailed call
        if any(list(map(lambda _x: not _result.get(_x), ["n", "p"]))) and hasattr(self.dms_client, "get_artifact_info"):
            self.logger.debug(self.__log_msg(
                "Try to update missing components using DMS API v3 detailed call"))

            # we have to raise an exception if "id" is not present - it is a crime!
            _info = self._make_dms_api_call_with_retries(self.dms_client.get_artifact_info, component, version, artifact["id"])
            _result.update({
                "n": _result.get("n") or _info.get("gav", dict()).get("artifactId") or "",
                "p": _result.get("p") or _info.get("gav", dict()).get("packaging") or "",
                "c": _result.get("c") or _info.get("gav", dict()).get("classifier") or ""})

        if any(list(map(lambda _x: not _result.get(_x), ["n", "p"]))):
            self.logger.debug(self.__log_msg(
                f"Using DMS API v[{self._args.dms_api_version}], parsing filename [{artifact['fileName']}]."))
            _fn, _p = posixpath.splitext(artifact['fileName'])
            _p = _p.strip('.') or 'bin'
            _n = list(_fn.split(version))
            _c = ""

            if len(_n) > 1:
                _c = re.sub("^[\-_\.\s]+", "", _n.pop())
                _c = re.sub("[\-_\.\s]+$", "", _c)

            _n = re.sub("^[\-_\.\s]+", "", _n.pop(0))
            _n = re.sub("[\-_\.\s]+$", "", _n)
            _result.update({
                "n": _result.get("n") or _n,
                "p": _result.get("p") or _p,
                "c": _result.get("c") or _c})

        _result["cl"] = _result["c"]
        _result["c_hyphen"] = f"-{_result['c']}" if _result["c"] else ""
        _result["c_colon"] = f":{_result['c']}" if _result["c"] else ""
        self.logger.debug(self.__log_msg(f"Returning subst: [{_result}]"))
        return _result

    def process_artifact(self, artifact, component, version):
        """
        Process artifacts
        :param dict artifact: artifact properties from Dms
        :param str version: component version
        :param str component: DmsComponentID
        """

        if artifact.get("repositoryType") == "DOCKER":
            self.logger.info(self.__log_msg(f"Skipping {artifact}: incompatible [repositoryType]"))
            return

        self.logger.debug(self.__log_msg(f"Artifact: {artifact}"))

        # we need to raise an exception, so do not use 'get'
        # all these keys must exist
        _artifact_type = artifact['type']
        self.logger.info(self.__log_msg(
            f"Processing component:artifact_type:version = [{component}:{_artifact_type}:{version}]"))

        _params = self.get_component_config(component)
        if not _params:
            self.logger.warning(self.__log_msg(
                f"Component [{component}] has not yet registered, skipping"))
            return

        self.logger.debug(self.__log_msg(f"Params: {_params}"))
        _gav_template = _params.get("tgtGavTemplate")

        if not _gav_template:
            self.logger.warning(self.__log_msg(
                f"Component [{component}] has no GAV settings for artifact_type [{_artifact_type}], skipping"))
            return

        _gav_template = _gav_template.get(_artifact_type).replace("\\", "")

        self.logger.debug(self.__log_msg(f"GAV template for [{component}:{_artifact_type}:{version}]: [{_gav_template}]"))
        _tgt_gav = Template(_gav_template).substitute(self._make_gav_substitute(component, version, artifact))
        _tgt_gav = re.sub('[^\w\-\.\:_]+', "_", _tgt_gav)
        self.logger.info(self.__log_msg(f"Target GAV: [{component}:{_artifact_type}:{version}] ==> [{_tgt_gav}]"))

        if self.mvn_client.exists(_tgt_gav, repo=self._args.mvn_download_repo):
            self.logger.info(self.__log_msg(
                f"Already exists, skipping copying: [{component}:{_artifact_type}:{version}] ==> [{_tgt_gav}]"))
            if self._args.always_enqueue is True:
                self.logger.info(self.__log_msg("Always enqueue parameter set, registering"))
                _ci_type = self._get_static_ci_type(_artifact_type) or _params["ci_type"]
                self._register_artifact(_tgt_gav, _ci_type)
            return

        _ci_type = self._get_static_ci_type(_artifact_type) or _params["ci_type"]
        self.logger.debug(self.__log_msg(f"ci_type: [{component}:{_artifact_type}:{version}] ==> [{_ci_type}]"))

        self.logger.info(self.__log_msg(f"Copying: [{component}:{_artifact_type}:{version}] ==> [{_tgt_gav}]"))
        self._copy_artifact(component, version, artifact, _tgt_gav)
        self.logger.info(self.__log_msg(f"Registering: [{_tgt_gav}] with ci_type [{_ci_type}]"))
        self._register_artifact(_tgt_gav, _ci_type)

    def get_component_config(self, component):
        _params = self._components.get(component)
        if _params:
            return _params

        try:
            citype = self.pg_client.get_citypedms_by_dms_id(component)
        except HttpAPIError as e:
            if e.code == 404:
                self.logger.warning(
                    self.__log_msg(f"Component [{component}] not registered in config nor in database, skipping"))
            else:
                self.logger.error(
                    self.__log_msg(f"Postgres client error: {e.resp}"))
            return None

        return self._generate_component_config(citype)

    def _generate_component_config(self, citype):
        component = citype.get('dms_id')
        citype_id = citype.get('ci_type_id')
        if not component or not citype_id:
            self.logger.error(self.__log_msg(f"Invalid data for component [{component}] or citype [{citype_id}]"))
            return None
        self.logger.debug(self.__log_msg(f"Component [{component}] not registered in config, creating temporary one"))
        components = self._make_dms_api_call_with_retries(self.dms_client.get_components) or list()
        client_code = None
        for comp in components:
            if comp["id"] == component:
                client_code = comp["clientCode"]

        _component = self._gav_template
        if not _component:
            return _component

        _component_str = str(_component)
        if client_code:
            _component_str = _component_str.replace("$component", citype_id).replace(".$client", f".{client_code}")
        else:
            _component_str = _component_str.replace("$component", citype_id).replace(".$client", "")
        _component = ast.literal_eval(_component_str)

        return _component

    def _register_artifact(self, tgt_gav, ci_type):
        """
        Send a queue registration request
        :param str tgt_gav: target gav
        :param str ci_type: ci_type
        """
        # Send to RabbitMQ
        self.logger.info(self.__log_msg(f"About to send queue to mq"))
        self.queue_client.connect()
        _location = FileLocation(tgt_gav, "NXS", None)
        resp = self.queue_client.register_file(_location, ci_type, 0)
        self.logger.debug(self.__log_msg(f"Register response: [{resp}]"))
        self.queue_client.disconnect()

        # Send to PSQL MQ
        self.logger.info(self.__log_msg(f"About to send queue to psql"))
        params = {
            "location": _location,
            "citype": ci_type,
            "depth": 0
        }
        message = self.psql_mq_client.compose_message('register_file', params)
        self.logger.debug(self.__log_msg('Composed message: [%s]' % message))
        self.psql_mq_client.enqueue_message('cdt.dlartifacts.input', message)

    def _copy_artifact(self, component, version, artifact, tgt_gav):
        """
        Make an artifact copy
        :param str component:
        :param str version:
        :param dict artifact: artifact properties from DMS
        :param str tgt_gav: target GAV
        """

        _tgt_file = tempfile.TemporaryFile(mode='w+b')
        if hasattr(self.dms_client, "download_component"):
            self.logger.info(self.__log_msg(f"Downloading component: [{component}:{version}:{artifact['type']}]"))
            self._make_dms_api_call_with_retries(self.dms_client.download_component, component, version, artifact["id"], write_to=_tgt_file)
        elif hasattr(self.dms_client, "get_gav"):
            self.logger.debug(self.__log_msg(f"Getting GAV from DMS: [{component}:{version}:{artifact['type']}]"))
            _src_gav = self._make_dms_api_call_with_retries(
                    self.dms_client.get_gav, component, version,
                    artifact["type"], artifact["name"], artifact["classifier"])
            self.logger.info(self.__log_msg(f"Downloading source GAV: [{_src_gav}]"))
            self.mvn_client.cat(_src_gav, repo=self._args.mvn_download_repo,
                                stream=True, binary=True, write_to=_tgt_file)

        _tgt_file.seek(0, os.SEEK_SET)
        self.logger.info(self.__log_msg(
            f"Putting to [{self._args.mvn_upload_repo}]: [{component}:{version}:{artifact['type']}] ==> [{tgt_gav}]"))
        self.mvn_client.upload(tgt_gav, repo=self._args.mvn_upload_repo, data=_tgt_file, pom=True)
        _tgt_file.close()
        self.logger.debug(self.__log_msg(f"Uploaded: [{component}:{version}:{artifact['type']}] ==> [{tgt_gav}]"))

    def _make_dms_api_call_with_retries(self, method, *args, **kwargs):
        """
        Make DMS API call with set amount of retries on error
        :param method: method reference
        :return: result of the method call
        """
        _attempt = 0
        while True:
            _attempt += 1
            if hasattr(method, '__name__'):
                _method_name = method.__name__
            elif hasattr(method, '__func__'):
                _method_name = method.__func__.__name__
            else:
                _method_name = 'Unknown method'
            self.logger.debug(self.__log_msg(f"{_method_name}: attempt [{_attempt}]"))
            try:
                return method(*args, **kwargs)
            except self.__errors as _err:
                if _attempt >= self._args.retries_count:
                    raise

                self.logger.debug(self.__log_msg(repr(_err)), exc_info=True)
                time.sleep(30)

    class DmsEventType(Enum):
        PUBLISH_COMPONENT_VERSION = "PUBLISH_COMPONENT_VERSION"
        REVOKE_COMPONENT_VERSION = "REVOKE_COMPONENT_VERSION"
        REGISTER_COMPONENT_VERSION_ARTIFACT = "REGISTER_COMPONENT_VERSION_ARTIFACT"
        DELETE_COMPONENT_VERSION_ARTIFACT = "DELETE_COMPONENT_VERSION_ARTIFACT"


    def prepare_parser(self):
        """
        Return basic parser object with correct description
        :return argparse.ArgumentParser:
        """
        return argparse.ArgumentParser(description="Mirror artifacts from DMS to MVN", conflict_handler='resolve')

    def basic_args(self, parser=None):
        """
        Fill the parser with arguments
        """
        vault_api = VaultAPI.VaultAPI()

        if not parser:
            parser = self.prepare_parser()

        _q = ChecksumsQueueClient()
        _q.basic_args(parser)
        del _q

        parser.add_argument("--log-level", dest="log_level", type=int, default=20, help="Logging level")
        parser.add_argument("--config-file", dest="config_file", type=str, help="Path to configuration file",
                            default=os.path.join(os.getcwd(), "config.json"))
        parser.add_argument("--gav-template-config-file", dest="gav_template_config_file", type=str, help="Path to gav template configuration file",
                            default=os.path.join(os.getcwd(), "gav_template_config.json"))
        parser.add_argument("--retries-count", dest="retries_count", type=int,
                            help='Retries count for DMS connection failures', default=5)

        # MVN arguments
        parser.add_argument("--mvn-prefix", dest="mvn_prefix", type=str, help="MVN GroupId prefix for destination",
                            default=vault_api.load_secret("MVN_PREFIX") or "com.example")
        parser.add_argument("--mvn-url", dest="mvn_url", help="MVN URL",
                            default=vault_api.load_secret("MVN_URL"))
        parser.add_argument("--mvn-user", dest="mvn_user", help="MVN user",
                            default=vault_api.load_secret("MVN_USER"))
        parser.add_argument("--mvn-password", dest="mvn_password", help="MVN password",
                            default=vault_api.load_secret("MVN_PASSWORD"))
        parser.add_argument("--mvn-upload-repo", dest="mvn_upload_repo", help="MVN repository to upload to",
                            default=vault_api.load_secret("MVN_UPLOAD_REPO") or "\x63\x64\x74.wa\x79\x34")
        parser.add_argument("--mvn-download-repo", dest="mvn_download_repo", help="MVN repository to download from",
                            default=vault_api.load_secret("MVN_DOWNLOAD_REPO") or "maven-virtual")

        # AMQP arguments
        parser.add_argument('--amqp-username', '-l',
                            help='Queue server connection username', default=vault_api.load_secret('AMQP_USER'))
        parser.add_argument('--amqp-password',
                            help='Queue server connection password', default=vault_api.load_secret('AMQP_PASSWORD'))
        parser.add_argument('--amqp-url', '-u',
                            help='Queue server url in form: amqp://user:pass@host:port/<vhost>[?params]',
                            default=vault_api.load_secret('AMQP_URL', 'amqp://guest:guest@localhost/'))
        # DMS arguments
        parser.add_argument("--dms-api-version", dest="dms_api_version", type=int,
                            help="DMS REST API version to use", default=3, choices=[2,3])
        parser.add_argument("--dms-crs-url", dest="dms_crs_url", type=str,
                            help="DMS Component Registry URL (necessary for DMS API v2)",
                            default=vault_api.load_secret("DMS_CRS_URL"))
        parser.add_argument("--dms-token", dest="dms_token", type=str, help="DMS authorization token",
                            default=vault_api.load_secret("DMS_TOKEN"))
        parser.add_argument("--dms-url", dest="dms_url", help="DMS URL",
                            default=vault_api.load_secret("DMS_URL"))
        parser.add_argument("--dms-user", dest="dms_user", help="DMS user",
                            default=vault_api.load_secret("DMS_USER"))
        parser.add_argument("--dms-password", dest="dms_password", help="DMS password",
                            default=vault_api.load_secret("DMS_PASSWORD"))
        parser.add_argument("--pg-url", dest="pg_url", help="PG URL",
                            default=vault_api.load_secret("PG_URL"))
        parser.add_argument("--pg-user", dest="pg_user", help="PG user",
                            default=vault_api.load_secret("PG_USER"))
        parser.add_argument("--pg-password", dest="pg_password", help="PG password",
                            default=vault_api.load_secret("PG_PASSWORD"))
        parser.add_argument("--psql-mq-url", dest="psql_mq_url", help="PSQL MQ URL",
                            default=vault_api.load_secret("PSQL_MQ_URL"))
        parser.add_argument("--psql-mq-user", dest="psql_mq_user", help="PSQL MQ user",
                            default=vault_api.load_secret("PSQL_MQ_USER"))
        parser.add_argument("--psql-mq-password", dest="psql_mq_password", help="PSQL MQ password",
                            default=vault_api.load_secret("PSQL_MQ_PASSWORD"))
        parser.add_argument("--dms-processes", dest="dms_processes", 
                            help="Processes (threads) to run in parallel",
                            type=int, default=3)
        parser.add_argument("--always-enqueue", dest="always_enqueue",
                            help="Enqueue if artifact exists",
                            action="store_true", default=False)

        # CITYPE properties
        parser.add_argument("--ci-type-release-notes", dest="ci_type_release_notes",
                            help="CI Type for Release Notes artifacts", default="RELEASENOTES")
        parser.add_argument("--ci-type-documentation", dest="ci_type_documentation",
                            help="CI Type for Documentation artifacts", default="DOCS")
        parser.add_argument("--auto-register-component", dest="auto_register_component",
                            help="Auto registration for new component", default=vault_api.load_secret("AUTO_REGISTRATION", False))
        return parser

    def setup_from_args(self, args):
        """
        Do self initialization with arguments parsed
        :param argpares.namespace args: parsed arguments
        """
        self._args = args

        # adjust file paths to absolute
        self._args.config_file = os.path.abspath(self._args.config_file)
        self._args.gav_template_config_file = os.path.abspath(self._args.gav_template_config_file)

        # just log the arguments
        for _k, _v in self._args.__dict__.items():
            _display_value = _v

            if _v and any([_k.endswith('password'), _k.endswith('token')]):
                _display_value = '*'*len(_v)

            self.logger.info(self.__log_msg(f"{_k.upper()}:\t[{_display_value}]"))


    def load_config(self):
        with open(self._args.config_file, mode='rt') as _config:
            self._components = json.load(_config)

        if os.path.exists(self._args.gav_template_config_file):
            with open(self._args.gav_template_config_file, mode='rt') as _config:
                self._gav_template = json.load(_config)
        else:
            print(f"Gav template config file not found: {self._args.gav_template_config_file}")
            self._gav_template = None


    def run(self):
        """
        Do the main process
        """
        self.logger.info(self.__log_msg(f"Reading components configuration: [{self._args.config_file}]"))

        self.load_config()

        self.logger.info(self.__log_msg(f"Components to process: {len(self._components)}"))

        with multiprocessing.Pool(processes=self._args.dms_processes) as pool:
            _exceptions = pool.map(self.process_component, self._components)

        _components_count = len(_exceptions)
        _exceptions = list(filter(lambda x: bool(x), _exceptions))

        self.logger.info(self.__log_msg(f"All [{_components_count}] components processed. Errors: [{len(_exceptions)}]"))
        return _exceptions

    def main(self):
        _parser = self.basic_args()
        _args = _parser.parse_args()

        if hasattr(_args, "log_level"):
            setup_json_logging(_args.log_level)

        self.setup_from_args(_args)

        __start_time = time.time()

        _exceptions = self.run()

        __elapsed = time.time() - __start_time
        self.logger.info(self.__log_msg(f"Finished. Elapsed time: {__elapsed}"))

        if _exceptions:
            # log ALL exceptions
            # NOTE: 'labmda' and 'generator' expressions do not work here
            # because of standard output
            for _e in _exceptions:
                # NOTE: we do not need to modify log message here because process name
                # is inside the exception, see 'process_component' method
                self.logger.error(_e)

            # raise first one to return non-zero code
            raise Exception(_exceptions.pop(0))

if __name__ == '__main__':
    DmsMirror().main()
