class Config:
    DEBUG = True
    TESTING = False
