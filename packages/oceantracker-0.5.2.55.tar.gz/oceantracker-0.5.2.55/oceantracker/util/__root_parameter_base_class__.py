# utility class to sefine the root of all Pramater base claseses,
# to aviod cirular imports

class _RootParameterBaseClass(object):pass