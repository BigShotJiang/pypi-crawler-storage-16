# ocrd_validators

> OCR-D framework - data validators

See also: https://github.com/OCR-D/core
