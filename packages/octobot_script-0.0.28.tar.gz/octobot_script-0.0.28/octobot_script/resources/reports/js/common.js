const hidden_class = "d-none";
const borderColor = "#2a2e39";
const textColor = "#b2b5be";
