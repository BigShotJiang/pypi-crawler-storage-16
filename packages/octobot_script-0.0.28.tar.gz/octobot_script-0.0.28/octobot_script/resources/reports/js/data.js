const FULL_DATA = {{ FULL_DATA }}.data.sub_elements;
