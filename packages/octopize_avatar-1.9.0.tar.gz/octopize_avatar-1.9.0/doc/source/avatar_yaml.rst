.. Deprecated placeholder (previous Avatar YAML reference). Excluded via conf.py.

Deprecated - Avatar YAML reference removed
==========================================

The dedicated Avatar YAML reference page was intentionally removed to simplify the navigation.
