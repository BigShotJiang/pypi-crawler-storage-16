..
  Note that notebooks/ folder is downloaded by conf.py from a gist for now

Example Notebooks
#################

|Binder|

.. toctree::
   :maxdepth: 2

   notebooks/stac-load-e84-aws
   notebooks/stac-load-S2-ms
   notebooks/stac-load-S2-deafrica

.. |Binder| image:: https://mybinder.org/badge_logo.svg
   :target: https://mybinder.org/v2/gh/opendatacube/odc-stac/develop?urlpath=lab/workspaces/demo
   :alt: Run Examples in Binder
