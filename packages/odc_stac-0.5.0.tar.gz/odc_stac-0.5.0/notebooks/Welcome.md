# Sample Notebooks

- Access Sentinel 2 Data on Planetary Computer, [open](stac-load-S2-ms.ipynb)
  - Works on binder too, but might need to decrease resolution to fit in to 2Gb of RAM
- Access Sentinel 2 Data from AWS, [open](stac-load-e84-aws.ipynb)
