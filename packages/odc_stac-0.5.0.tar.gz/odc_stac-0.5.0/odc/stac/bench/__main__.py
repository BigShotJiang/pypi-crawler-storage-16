"""Run main."""

from ._cli import main

main()
