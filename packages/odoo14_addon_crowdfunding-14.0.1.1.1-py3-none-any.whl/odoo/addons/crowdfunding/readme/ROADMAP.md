As this module is designed to provide the bare neccessities, a couple of other modules will add more advanced functionality

-   crowdfunding\_membership allowing to restrict creating/claiming to members only
-   crowdfunding\_project allowing to create crowdfunding challenges from projects/tasks or vice versa
-   crowdfunding\_github allowing to create crowdfunding challenges from issues of some github project
-   crowdfunding\_gitlab the same as above but for gitlab
-   crowdfunding\_category allowing to move some of the base company wide configuration to categories
