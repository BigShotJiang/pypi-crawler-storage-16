This module allows users to mark their pledges as public.

Pledges show up beneath the challenge description as soon as they're paid.
