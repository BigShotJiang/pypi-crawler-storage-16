1. Navigate to /crowdfunding on your Odoo website while being logged in
2. Select a challenge from the list
3. Click the 'Pledge' button
4. Check the box 'Publish my pledge on the website'

In the backend, you can mark pledges as public on the crowdfunding tab of invoices.
