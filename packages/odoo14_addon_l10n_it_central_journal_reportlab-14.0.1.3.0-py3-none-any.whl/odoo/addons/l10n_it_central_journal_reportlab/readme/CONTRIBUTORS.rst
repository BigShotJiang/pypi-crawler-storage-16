* Gianmarco Conte <gconte@dinamicheaziendali.it>
* Lara Baggio <lbaggio@linkgroup.it>
* Glauco Prina <gprina@linkgroup.it>
* Giuseppe Borruso <gborruso@dinamicheaziendali.it>
* `Ooops <https://www.ooops404.com>`_:

  * Giovanni Serra <giovanni@gslab.it>
* `PyTech <https://www.pytech.it>`_:

  * Simone Rubino <simone.rubino@pytech.it>
