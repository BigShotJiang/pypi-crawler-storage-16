#. Go to Sign > Roles and create a role with the following data:

- Partner type: Expression
- Expression: ${object.partner_id.id}

#. Go to Sign > Templates and create a template with the following data:

- Model: Project Task
- In one of the fields, you must set the previously created role.

#. (Optional) Go to Project > Configuration > Settings.

- In the Task Sign section, define a template to enable automatic task sing requests.
- Use the template previously created.
