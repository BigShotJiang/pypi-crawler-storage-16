* `Escodoo <https://www.escodoo.com.br>`_:

  * Marcel Savegnago <marcel.savegnago@escodoo.com.br>
  * Wesley Oliveira <wesley.oliveira@escodoo.com.br>
