Account Credit Control module is a part of Financial Tools used in
business to ensure that once sales are made they are realised as cash.
This module helps to identify outstanding debt beyond tolerance level
and setup followup method.
