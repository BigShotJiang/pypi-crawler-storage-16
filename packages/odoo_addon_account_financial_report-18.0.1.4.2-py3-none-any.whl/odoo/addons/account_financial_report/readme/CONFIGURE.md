To configure dynamic intervals for Aged Partner Balance you need to:

Go on 'Settings' -> 'Invoicing' -> 'OCA Aged Report Configuration'.

Click on option 'Configurations' and create new record.

Create new interval.
The name established on line will be the column to display in Aged Partner Balance.
Inferior limit established on line is the interval

Example of configuration inferior limit:

-> 15
-> 30
-> 60

It means the first interval is from 0 to 15, the second from 16 to 30, and the third is 61+.

Go on 'Invoicing' -> 'Reporting' -> 'OCA accounting reports' -> 'Aged Partner Balance'

When wizard is open, you need to select your interval configuration and print report.

If you want to get default interval configuration any time you wish to print Aged Partner Report,
you can set default interval configuration per company in:

'Settings' -> 'Invoicing' -> 'OCA Aged Report Configuration'.
