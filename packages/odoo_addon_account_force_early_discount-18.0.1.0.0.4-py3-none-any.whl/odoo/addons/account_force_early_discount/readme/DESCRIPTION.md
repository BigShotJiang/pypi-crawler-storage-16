This module allows to force early payment discounts past the validity
date of the discount set through the payment term.
