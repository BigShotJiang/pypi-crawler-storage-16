The early payment discount will be applied automatically, even past
its validity date, using register payment wizard  if the "Force financial discount"
is used on the invoice.
