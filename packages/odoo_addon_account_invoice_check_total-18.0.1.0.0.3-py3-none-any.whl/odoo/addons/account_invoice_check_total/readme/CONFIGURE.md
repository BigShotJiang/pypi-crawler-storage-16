The setting **Check Total on Vendor Bills** needs to be checked. This
can be done as follows:

> - on the Access Rights (Technical Settings) of the user
> - on the Invoicing Settings inside of the section *Vendor Payments*
