This module is the technical basis to automate the download of supplier
invoices with Odoo. It must be used in combination with additionnal
modules that add download backends. The technical name of these
additionnal modules usually start with **account_invoice_download\_**.
