This module adds an OVH backend to the **account_invoice_download**
module. It allows you to auto-download [OVH](https://www.ovhcloud.com)
invoices via the [OVH API](https://api.ovh.com/).
