Refer to the usage instructions of the module
**account_invoice_download**.
