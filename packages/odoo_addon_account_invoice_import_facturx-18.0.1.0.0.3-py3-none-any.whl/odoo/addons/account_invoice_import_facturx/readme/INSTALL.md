This module requires the Python library
[factur-x](https://github.com/akretion/factur-x) developped by Akretion.
To install it, run:

``` 
sudo pip3 install --upgrade factur-x
```
