# Copyright 2015-2021 Akretion France (http://www.akretion.com/)
# @author: Alexis de Lattre <alexis.delattre@akretion.com>
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).


from odoo import Command, fields
from odoo.tests.common import TransactionCase
from odoo.tools import file_open, mute_logger


class TestFacturx(TransactionCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.env = cls.env(context=dict(cls.env.context, tracking_disable=True))
        cls.company = cls.env.ref("base.main_company")
        adjustment_credit_account_id = (
            cls.env["account.account"]
            .create(
                {
                    "company_ids": [Command.set([cls.company.id])],
                    "code": "758FXADJUST",
                    "name": "Adjustment income account",
                    "account_type": "income",
                }
            )
            .id
        )
        adjustment_debit_account_id = (
            cls.env["account.account"]
            .create(
                {
                    "company_ids": [Command.set([cls.company.id])],
                    "code": "658FXADJUST",
                    "name": "Adjustment expense account",
                    "account_type": "expense",
                }
            )
            .id
        )
        cls.company.write(
            {
                "adjustment_credit_account_id": adjustment_credit_account_id,
                "adjustment_debit_account_id": adjustment_debit_account_id,
            }
        )
        cls.expense_account = cls.env["account.account"].search(
            [
                ("company_ids", "=", cls.company.id),
                ("account_type", "=", "expense"),
            ],
            limit=1,
        )
        cls.purchase_tax = cls.env["account.tax"].search(
            [
                ("company_id", "=", cls.company.id),
                ("type_tax_use", "=", "purchase"),
                ("amount_type", "=", "percent"),
                ("amount", ">", 5),
            ],
            limit=1,
        )
        # When creating a new demo DB, the CoA is installed
        # AFTER account_invoice_import_facturx, so the search= on field account_id
        # in the demo XML file of this module doesn't give any result.
        # That's why we set the account_id field of account.invoice.import.config here
        demo_partner_model_datas = cls.env["ir.model.data"].search(
            [
                ("module", "=", "account_invoice_import_facturx"),
                ("model", "=", "res.partner"),
                ("res_id", "!=", False),
                ("name", "!=", False),
            ]
        )
        for model_data in demo_partner_model_datas:
            partner = (
                cls.env["res.partner"]
                .browse(int(model_data["res_id"]))
                .with_company(cls.company.id)
            )
            vals = {}
            if not partner.invoice_import_account_id:
                vals["invoice_import_account_id"] = cls.expense_account.id
            if not partner.invoice_import_tax_ids:
                vals["invoice_import_tax_ids"] = [Command.set([cls.purchase_tax.id])]
            if vals:
                partner.write(vals)

    # avoid warning logs pypdf._reader: incorrect startxref pointer(1)
    @mute_logger("pypdf._reader")
    def test_import_facturx_invoice(self):
        sample_files = {
            # BASIC
            "ZUGFeRD_1p0_BASIC_Einfach.pdf": {
                "invoice_number": "471102",
                "amount_untaxed": 198.0,
                "amount_total": 235.62,
                "invoice_date": "2013-03-05",
                "partner_xmlid": "lieferant",
            },
            # Cannot handle BASIC with allowancecharge != 0 and multi-taxes
            # 'ZUGFeRD_1p0_BASIC_Rechnungskorrektur.pdf': {
            #    'type': 'in_refund',
            #    'invoice_number': 'RK21012345',
            #    'amount_untaxed': 7.67,
            #    'amount_total': 8.79,
            #    'invoice_date': '2013-09-16',
            #    'partner_xmlid': 'lieferant',
            #    },
            # COMFORT
            "ZUGFeRD_1p0_COMFORT_Einfach.pdf": {
                "invoice_number": "471102",
                "amount_untaxed": 473.0,
                "amount_total": 529.87,
                "invoice_date": "2013-03-05",
                "invoice_date_due": "2013-04-04",
                "partner_xmlid": "lieferant",
            },
            "ZUGFeRD_1p0_COMFORT_Einfach.pdf-ZUGFeRD-invoice.xml": {
                "invoice_number": "471102",
                "amount_untaxed": 473.0,
                "amount_total": 529.87,
                "invoice_date": "2013-03-05",
                "partner_xmlid": "lieferant",
            },
            "ZUGFeRD_1p0_COMFORT_Haftpflichtversicherung_" "Versicherungssteuer.pdf": {
                "invoice_number": "01.234.567.8-2014-1",
                "amount_untaxed": 50.00,
                "amount_total": 59.50,
                "invoice_date": "2014-01-24",
                # stupid sample files: due date is before invoice date !
                "invoice_date_due": "2013-12-06",
                "partner_xmlid": "mvm_musterhafter",
            },
            "ZUGFeRD_1p0_COMFORT_Kraftfahrversicherung_" "Bruttopreise.pdf": {
                "invoice_number": "00.123.456.7-2014-1",
                "amount_untaxed": 184.87,
                "amount_total": 220.0,
                "invoice_date": "2014-03-11",
                "invoice_date_due": "2014-04-01",
                "partner_xmlid": "mvm_musterhafter",
            },
            # Disabled due to a bug in the XML
            # Contains Charge + allowance
            # 'ZUGFeRD_1p0_COMFORT_Rabatte.pdf': {
            #    'invoice_number': '471102',
            #    'amount_untaxed': 193.77,
            # There is a bug in the total amount of the last line
            # (55.46 ; right value is 20 x 2.7700 = 55.40)
            #    'amount_total': 215.14,
            #    'invoice_date': '2013-06-05',
            #    'partner_xmlid': 'lieferant',
            #    },
            # has AllowanceTotalAmount
            "ZUGFeRD_1p0_COMFORT_Rechnungskorrektur.pdf": {
                "type": "in_refund",
                "invoice_number": "RK21012345",
                "invoice_date": "2013-09-16",
                "amount_untaxed": 7.67,
                "amount_total": 8.79,
                "partner_xmlid": "lieferant",
            },
            "ZUGFeRD_1p0_COMFORT_Sachversicherung_berechneter_" "Steuersatz.pdf": {
                "invoice_number": "00.123.456.7-2014-1",
                "amount_untaxed": 1000.00,
                "amount_total": 1163.40,
                "invoice_date": "2014-04-18",
                "invoice_date_due": "2014-05-21",
                "partner_xmlid": "mvm_musterhafter",
            },
            "ZUGFeRD_1p0_COMFORT_SEPA_Prenotification.pdf": {
                "invoice_number": "471102",
                "amount_untaxed": 473.00,
                "amount_total": 529.87,
                "invoice_date": "2014-03-05",
                "invoice_date_due": "2014-03-20",
                "partner_xmlid": "lieferant",
            },
            # EXTENDED
            # has AllowanceTotalAmount
            # 'ZUGFeRD_1p0_EXTENDED_Kostenrechnung.pdf': {
            #    'invoice_number': 'KR87654321012',
            #    'amount_untaxed': 1056.05,
            #    'amount_total': 1256.70,
            #    'invoice_date': '2013-10-06',
            #    'partner_xmlid': 'musterlieferant',
            #    },  # disable for a malformed date "20139102"
            "ZUGFeRD_1p0_EXTENDED_Rechnungskorrektur.pdf": {
                "type": "in_refund",
                "invoice_number": "RK21012345",
                "amount_untaxed": 7.67,
                "amount_total": 8.79,
                "invoice_date": "2013-09-16",
                "partner_xmlid": "musterlieferant",
            },
            "ZUGFeRD_1p0_EXTENDED_Warenrechnung.pdf": {
                "invoice_number": "R87654321012345",
                "amount_untaxed": 448.99,
                "amount_total": 518.99,
                "invoice_date": "2013-08-06",
                "partner_xmlid": "musterlieferant",
            },
            "Facture_FR_MINIMUM.pdf": {
                "invoice_number": "FA-2017-0010",
                "amount_untaxed": 624.90,
                "amount_total": 671.15,
                "invoice_date": "2017-11-13",
                "partner_xmlid": "jolie_boutique",
            },
            "Facture_FR_BASICWL.pdf": {
                "invoice_number": "FA-2017-0010",
                "amount_untaxed": 624.90,
                "amount_total": 671.15,
                "invoice_date": "2017-11-13",
                "partner_xmlid": "jolie_boutique",
            },
            "Facture_FR_BASIC.pdf": {
                "invoice_number": "FA-2017-0010",
                "amount_untaxed": 624.90,
                "amount_total": 671.15,
                "invoice_date": "2017-11-13",
                "partner_xmlid": "jolie_boutique",
            },
            "Facture_FR_EN16931.pdf": {
                "invoice_number": "FA-2017-0010",
                "amount_untaxed": 624.90,
                "amount_total": 671.15,
                "invoice_date": "2017-11-13",
                "partner_xmlid": "jolie_boutique",
            },
            "Facture_FR_EXTENDED.pdf": {
                "invoice_number": "FA-2017-0010",
                "amount_untaxed": 624.90,
                "amount_total": 671.15,
                "invoice_date": "2017-11-13",
                "partner_xmlid": "jolie_boutique",
            },
        }
        amo = self.env["account.move"]
        cur = self.env.ref("base.EUR")
        # We need precision of product price at 4
        # in order to import ZUGFeRD_1p0_EXTENDED_Kostenrechnung.pdf
        price_precision = self.env.ref("product.decimal_price")
        price_precision.digits = 4
        for inv_file, res_dict in sample_files.items():
            f = file_open(
                "account_invoice_import_facturx/tests/files/" + inv_file, "rb"
            )
            pdf_file = f.read()
            f.close()
            wiz = self.env["account.invoice.import"].create(
                {
                    "invoice_attachment_ids": [
                        Command.create({"raw": pdf_file, "name": inv_file})
                    ],
                    "company_id": self.company.id,
                }
            )
            wiz.import_invoices()
            invoices = amo.search(
                [
                    ("state", "=", "draft"),
                    ("move_type", "in", ("in_invoice", "in_refund")),
                    ("ref", "=", res_dict["invoice_number"]),
                    ("company_id", "=", self.company.id),
                ]
            )
            self.assertEqual(len(invoices), 1)
            inv = invoices[0]
            self.assertEqual(inv.move_type, res_dict.get("type", "in_invoice"))
            self.assertEqual(
                fields.Date.to_string(inv.invoice_date), res_dict["invoice_date"]
            )
            if res_dict.get("invoice_date_due"):
                self.assertEqual(
                    fields.Date.to_string(inv.invoice_date_due),
                    res_dict["invoice_date_due"],
                )
            self.assertEqual(
                inv.partner_id,
                self.env.ref(
                    "account_invoice_import_facturx." + res_dict["partner_xmlid"]
                ),
            )
            self.assertFalse(
                cur.compare_amounts(
                    inv.amount_untaxed,
                    res_dict["amount_untaxed"],
                )
            )
            self.assertFalse(
                cur.compare_amounts(
                    inv.amount_total,
                    res_dict["amount_total"],
                )
            )
            # Delete because several sample invoices have the same number
            invoices.unlink()
