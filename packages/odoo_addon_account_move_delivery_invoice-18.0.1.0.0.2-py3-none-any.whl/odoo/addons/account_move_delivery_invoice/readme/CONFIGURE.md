Go to *Invoicing → Configuration → Settings*:

- **Invoice Report (PDF) Titles**: Configure custom titles for invoice-related PDF
  reports. Standard titles are used if left blank.
- **Use Delivery Note Comment**: Enable the delivery note comment field on invoices
  and credit notes (enabled by default).
- **Hide Narration on Delivery Note**: Hide the standard invoice narration (terms and
  conditions) on delivery note and return slip PDFs (enabled by default).
