This module is designed for business flows where delivery notes are created after
validating the delivery and generating the invoice.

If you need to create delivery notes before validating the delivery (during shipment
preparation), this module will not meet your requirements.
