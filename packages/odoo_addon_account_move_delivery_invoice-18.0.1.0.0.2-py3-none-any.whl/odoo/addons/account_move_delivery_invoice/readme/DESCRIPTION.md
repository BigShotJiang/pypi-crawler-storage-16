This module adds a Delivery Note report (納品書) to invoices. The report displays
the same content as the standard invoice but with a custom title and no tax information.

Configurable report titles are available for invoices, credit notes, delivery notes,
and return slips.
