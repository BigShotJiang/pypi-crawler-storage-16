This module stores the date when a journal entry is posted and the user
that posted it.
