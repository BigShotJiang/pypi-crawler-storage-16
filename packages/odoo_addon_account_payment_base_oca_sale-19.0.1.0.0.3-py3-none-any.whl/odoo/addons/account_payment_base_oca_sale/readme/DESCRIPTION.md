This modules improves the implementation of *Payment Mode* of sale orders:

- it adds the *Payment Mode* field in *Sales > Reporting > Sales*
- it updates the *Quotation / Order* report with Payment instructions
