This module adds several options on Payment Methods, cf
Invoicing/Accounting \> Configuration \> Management \> Payment Methods.
