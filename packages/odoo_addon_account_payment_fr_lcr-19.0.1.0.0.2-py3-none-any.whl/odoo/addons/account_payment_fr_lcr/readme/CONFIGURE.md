To configure this module, you need to create a new payment mode linked
to the payment method *Lettre de Change Relevé* that is automatically
created when you install this module.

Once you selected this payment method, you will have a new section *Bill
of Exchange* on the payment mode where you will have to configure:

- the *LCR type*: *Lettre de change non acceptée (LCR directe)*, *Lettre
  de change acceptée* or *Billet à ordre*,
- the *Default Collection Option*,
- if you have a *Dailly Convention*,
- in case you have a Dailly convention, you will be able to configure
  the *Default Dailly Option* and the *Convention Type*.
