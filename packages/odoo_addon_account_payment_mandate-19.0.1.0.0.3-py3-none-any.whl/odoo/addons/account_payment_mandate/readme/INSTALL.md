This module depends on : \* account_payment_batch_oca

This module is part of the OCA/bank-payment-alternative suite.
