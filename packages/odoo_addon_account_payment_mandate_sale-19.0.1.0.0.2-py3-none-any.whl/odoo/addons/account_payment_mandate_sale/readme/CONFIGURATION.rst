There is nothing to configure.
