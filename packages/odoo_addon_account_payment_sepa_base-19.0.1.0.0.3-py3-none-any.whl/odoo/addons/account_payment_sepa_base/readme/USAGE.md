See 'readme' files of the OCA/bank-payment-alternative suite.
