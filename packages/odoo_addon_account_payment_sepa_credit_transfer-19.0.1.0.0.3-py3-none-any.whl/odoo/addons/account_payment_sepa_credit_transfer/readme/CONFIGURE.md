- Create a Payment Method dedicated to SEPA Credit Transfer.
- Select the Technical Payment Method *SEPA Credit Transfer to suppliers* (which
  is automatically created upon module installation).
- Check that this technical payment method uses the proper version of PAIN.
