In the menu *Invoicing/Accounting \> Vendors \> Payment Orders*, create
a new payment order and select the *Payment Method* dedicated to SEPA Credit
Transfer that you created during the configuration step.
