from . import res_company
from . import account_banking_mandate
from . import account_payment_method_line
from . import account_payment_method
from . import account_payment_order
from . import account_payment_lot
from . import account_payment_line
