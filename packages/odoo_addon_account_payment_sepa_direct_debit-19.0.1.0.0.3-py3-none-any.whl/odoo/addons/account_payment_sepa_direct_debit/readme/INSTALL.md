This module depends on :

- account_payment_sepa_base
- account_payment_mandate

This module is part of the OCA/bank-payment-alternative suite.
