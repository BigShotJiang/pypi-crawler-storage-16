Odoo Agreement App does not provide an easy way to access helpdesk
tickets related to an agreement. Some organizations need to have a quick
access to helpdesk tickets to track the performance of an agreement.

This module allows you to link a helpdesk ticket to an agreement and
adds a smart button on the agreement to look at the list of related
helpdesk tickets.
