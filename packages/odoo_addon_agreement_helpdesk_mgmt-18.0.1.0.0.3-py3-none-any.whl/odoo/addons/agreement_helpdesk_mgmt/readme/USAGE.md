- Go to Helpdesk \> Tickets
- Select or create a helpdesk ticket and set the agreement
- Go to Agreement \> Agreements
- Open the previous agreement
- Click on the smart button "Tickets" to see the list of related
  helpdesk tickets
