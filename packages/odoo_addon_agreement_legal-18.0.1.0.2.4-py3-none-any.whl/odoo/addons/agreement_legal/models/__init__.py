# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import res_config_settings
from . import agreement_stage
from . import agreement
from . import agreement_appendix
from . import agreement_clause
from . import agreement_line
from . import agreement_recital
from . import agreement_section
from . import agreement_type
from . import agreement_subtype
