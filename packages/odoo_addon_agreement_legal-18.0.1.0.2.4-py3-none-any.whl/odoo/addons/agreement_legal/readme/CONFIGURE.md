To configure this module:

- Go to Agreement \> Configuration \> Templates
- Create a new template with sections and clauses and their respective
  content
- Go to Agreement \> Configuration \> Stages
- Create and reorder stages to match your process
