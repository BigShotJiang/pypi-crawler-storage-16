- Split the module to remove the dependencies on sale and account and
  provide the same feature in extra modules (agreement_sale,
  agreement_account, agreement_purchase)
