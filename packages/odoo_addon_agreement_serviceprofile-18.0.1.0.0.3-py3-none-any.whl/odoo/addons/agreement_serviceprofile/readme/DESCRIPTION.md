This module adds an *Agreement Service Profile* object with the
following properties:

- name,
- link to a agreement,
- active.
