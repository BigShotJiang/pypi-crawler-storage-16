Anonymize certain fields for a group of users when exporting them
directly or via relational fields.
