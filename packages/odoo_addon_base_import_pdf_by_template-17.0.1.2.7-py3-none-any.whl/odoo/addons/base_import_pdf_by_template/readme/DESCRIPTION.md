This module allows you to import PDF files and generate records based on
the data contained in those PDF files. It also allows you to define a
pattern that indicates how to recognize and extract the data from the
PDF to generate a record.
