This module allows to upload PDF files in any Odoo model. It processes
each of the files and converts it into a new record. Technically, the
pdf is transformed into text and that text is processed to create the
record. The module incorporates an option in actions 'Import records
(with template)' and Template configuration in order to recognized
any document structure.
