# Copyright 2025 Camptocamp SA
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

{
    "name": "Base - Write Diff",
    "summary": "Prevents updates on fields whose values won't change anyway",
    "version": "17.0.1.0.0",
    "author": "Camptocamp, Odoo Community Association (OCA)",
    "license": "AGPL-3",
    "category": "Hidden",
    "website": "https://github.com/OCA/server-tools",
    "installable": True,
    "depends": ["base", "web"],
}
