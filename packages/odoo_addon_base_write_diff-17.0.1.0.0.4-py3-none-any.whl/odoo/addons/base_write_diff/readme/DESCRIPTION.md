This module allows filtering values to update on records according to whether they are
actually different from the records' current values.
