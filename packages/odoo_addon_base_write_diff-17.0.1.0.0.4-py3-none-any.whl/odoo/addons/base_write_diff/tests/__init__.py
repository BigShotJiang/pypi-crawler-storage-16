from . import test_base_write_diff
