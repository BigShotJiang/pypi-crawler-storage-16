# Copyright 2020 Tecnativa - David Vidal
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).
{
    "name": "Delivery Package Number",
    "summary": "Set or compute number of packages for a picking",
    "version": "19.0.1.0.0",
    "category": "Delivery",
    "website": "https://github.com/OCA/delivery-carrier",
    "author": "Tecnativa, Odoo Community Association (OCA)",
    "license": "AGPL-3",
    "installable": True,
    "application": False,
    "depends": ["stock_delivery"],
    "data": [
        "security/ir.model.access.csv",
        "data/paperformat_data.xml",
        "reports/report_package_number.xml",
        "views/stock_picking_type_views.xml",
        "views/stock_picking_views.xml",
        "wizard/stock_number_package_validate_wiz_view.xml",
    ],
}
