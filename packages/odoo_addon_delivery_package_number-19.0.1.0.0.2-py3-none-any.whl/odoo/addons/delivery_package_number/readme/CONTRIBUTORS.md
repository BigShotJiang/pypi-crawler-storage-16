- [Tecnativa](https://www.tecnativa.com):
  - Pedro M. Baeza
  - David Vidal
  - Marçal Isern
  - Carlos Roca

 - [Sygel](https://www.sygel.es):
  - Ángel García de la Chica Herrera \<<angel.garcia@sygel.es>\>

- [Studio73](https://www.studio73.es/):
  - Eugenio Micó <eugenio@studio73.es>
