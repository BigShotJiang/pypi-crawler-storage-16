This module recovers the number of packages field that was present in
previous versions of Odoo, that can be either be set manually by the
user, but also allows to be computed when the delivery packages flow is
used.

This field can be used by delivery carrier extensions that need such
info to rate the shipment, print the labels, etc.
