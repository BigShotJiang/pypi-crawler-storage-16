If no delivery packages are used:

1.  Go to an open picking and click in the *Additional Info* tab.
2.  In the *Delivey Information* section you'll find a **Number of
    packages** field that you can edit.

If delivey packages are used:

1.  The field will be recomputed depending on the delivery packages used
    in the picking although can be edited at convenience later.

When the picking is confirmed, the user has the chance to change the
number of packages in the confirmation wizard.

Note: You can prevent the wizard from popping up to set the number of packages
by selecting the option "Avoid set number of packages" in the operation
type.
