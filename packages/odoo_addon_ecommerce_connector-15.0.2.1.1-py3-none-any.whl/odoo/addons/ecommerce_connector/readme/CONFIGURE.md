Check the operations manual provided by Sygel.
