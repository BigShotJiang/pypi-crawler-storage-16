Go to "EDI -\> EDI backend" then configure your backend to use a storage
backend.
