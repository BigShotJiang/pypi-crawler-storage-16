To use this module, you don't need to do anything. Automatically every
so often a 'scheduled action' will be executed that will try to import
from Voxel the sales orders that have not been imported previously.

Imports will be performed for the companies that have the 'Voxel' field
checked (See configuration section).
