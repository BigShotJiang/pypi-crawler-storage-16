Provides FastAPI dependencies for Api Key authentication.
