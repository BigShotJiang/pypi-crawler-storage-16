This module is the FastAPI implementation of `auth_partner <../auth_partner>`_ 
it provides all the routes to manage the authentication of partners.
