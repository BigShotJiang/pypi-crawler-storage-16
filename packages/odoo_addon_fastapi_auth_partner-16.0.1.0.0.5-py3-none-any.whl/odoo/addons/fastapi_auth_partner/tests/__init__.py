from . import test_auth
from . import test_fastapi_auth_partner_demo
