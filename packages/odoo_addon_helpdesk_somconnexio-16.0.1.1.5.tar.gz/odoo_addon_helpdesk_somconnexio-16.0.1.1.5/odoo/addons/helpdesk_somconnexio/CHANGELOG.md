# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
## [16.0.1.1.5] - 2025-12-09
### Fixed
- [#1685](https://git.coopdevs.org/coopdevs/som-connexio/odoo-somconnexio/-/merge_requests/1685) Fix mail activity search in contract view including helpdesk.ticket activities

### Changed
- [#1686](https://git.coopdevs.org/coopdevs/som-connexio/odoo-somconnexio/-/merge_requests/1686) Al desar un correu com a nota, el camp TO ha de ser no obligatori

## [16.0.1.1.4] - 2025-12-04
### Removed
- [#1681](https://git.coopdevs.org/coopdevs/som-connexio/odoo-somconnexio/-/merge_requests/1681) Remove priority search view
- [#1680](https://git.coopdevs.org/coopdevs/som-connexio/odoo/odoo-somconnexio/-/merge_requests/1680) Remove default email template for communication tab replying/forwarding actions

## [16.0.1.1.3] - 2025-11-24
### Added
- [#1678](https://git.coopdevs.org/coopdevs/som-connexio/odoo-somconnexio/-/merge_requests/1678) Bring changes from som-it

## [16.0.1.0.1] - 2025-11-21
### Fixed
- [#1675](https://git.coopdevs.org/coopdevs/som-connexio/odoo-somconnexio/-/merge_requests/1675) Fix helpdesk_ticket_mail_message dependency issues

## [16.0.1.0.0] - 2025-10-16
### Added
- [#1642](https://git.coopdevs.org/coopdevs/som-connexio/odoo-somconnexio/-/merge_requests/1642) Add helpdesk_somconnexio module
