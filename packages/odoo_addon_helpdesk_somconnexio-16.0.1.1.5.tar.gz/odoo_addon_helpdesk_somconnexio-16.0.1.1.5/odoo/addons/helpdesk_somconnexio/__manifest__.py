# Copyright 2025-SomItCoop SCCL(<https://gitlab.com/somitcoop>)
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).
{
    "name": "Odoo helpdesk Som Connexió Customizations",
    "version": "16.0.1.1.5",
    "summary": "Odoo Helpdesk customizations for Som Connexió",
    "author": "Som It Cooperatiu SCCL, Som Connexió SCCL",
    "website": "https://gitlab.com/somitcoop/erp-research/odoo-helpdesk",
    "license": "AGPL-3",
    "category": "Cooperative management",
    "depends": [
        "helpdesk_mgmt_rating",
        "helpdesk_mgmt_stage_validation",
        "helpdesk_ticket_mail_message",
        "helpdesk_ticket_contract_contract",
        "helpdesk_ticket_priority_filter",
    ],
    "data": [
        "security/ir.model.access.csv",
        "views/helpdesk_ticket_view.xml",
        "views/team_cross_domain_alias.xml",
        "views/helpdesk_ticket_menu.xml",
        "wizards/mail_compose_message_view.xml",
    ],
    "assets": {
        "web.assets_backend": [
            "helpdesk_somconnexio/static/src/js/mail_compose_message.js",
        ],
    },
    "application": False,
    "installable": True,
}
