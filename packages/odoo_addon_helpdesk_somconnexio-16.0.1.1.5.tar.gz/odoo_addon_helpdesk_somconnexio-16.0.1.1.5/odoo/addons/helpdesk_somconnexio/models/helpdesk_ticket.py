from odoo import models, fields, api
from odoo.tools.translate import _
from odoo.tools import email_normalize_all


class HelpdeskTicket(models.Model):
    _inherit = "helpdesk.ticket"

    primary_tag_ids = fields.Many2many(
        comodel_name="helpdesk.ticket.primary.tag",
        string="Primary Tags",
        help="Primary tags for the helpdesk ticket.",
    )
    secondary_tag_ids = fields.Many2many(
        comodel_name="helpdesk.ticket.secondary.tag",
        string="Secondary Tags",
        help="Secondary tags for the helpdesk ticket.",
    )
    priority = fields.Selection(
        selection=[
            ("0", _("Very Low")),
            ("1", _("Low")),
            ("2", _("Medium")),
            ("3", _("High")),
            ("4", _("Very High")),
            ("5", _("Urgent")),
        ],
        default="2",
    )

    @api.model
    def message_new(self, msg, custom_values=None):
        """Override message_new from mail gateway to route cross domain aliases."""
        ticket = super().message_new(msg, custom_values)

        recipients = set()
        for field in ["to", "cc", "delivered_to"]:
            if msg.get(field):
                recipients.update(set(email_normalize_all(msg.get(field))))

        for recipient in recipients:
            if "@" not in recipient:
                continue

            local_part, domain = recipient.split("@", 1)
            cross_domain_alias = self.env["team.cross.domain.alias"].search(
                [
                    ("alias_name", "=", local_part),
                    ("alias_domain", "=", domain),
                    ("active", "=", True),
                    ("company_id", "=", ticket.company_id.id),
                ],
                limit=1,
            )
            if cross_domain_alias:
                ticket.team_id = cross_domain_alias.helpdesk_team_id

                return ticket

        return ticket
