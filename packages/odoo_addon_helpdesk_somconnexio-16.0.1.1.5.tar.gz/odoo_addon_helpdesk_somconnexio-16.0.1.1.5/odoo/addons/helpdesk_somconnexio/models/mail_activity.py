from odoo import models, api
from odoo.osv import expression


class MailActivity(models.Model):
    _inherit = "mail.activity"

    @api.model
    def _search(
        self,
        args,
        offset=0,
        limit=None,
        order=None,
        count=False,
        access_rights_uid=None,
    ):
        is_contract_search = any(
            isinstance(clause, (tuple, list))
            and len(clause) >= 3
            and clause[0] == "res_model"
            and clause[1] == "="
            and clause[2] == "contract.contract"
            for clause in args or []
        )

        if not is_contract_search:
            return super()._search(args, offset, limit, order, count, access_rights_uid)

        ticket_ids = []
        for clause in args:
            if not (
                isinstance(clause, (tuple, list))
                and len(clause) >= 3
                and clause[0] == "res_id"
                and clause[1] in ("=", "in")
            ):
                continue

            contracts = self.env["contract.contract"].browse(clause[2])
            ticket_ids += contracts.mapped("helpdesk_ticket_ids").ids

        if ticket_ids:
            args = expression.OR(
                [
                    args,
                    [
                        ("res_model", "=", "helpdesk.ticket"),
                        ("res_id", "in", ticket_ids),
                    ],
                ]
            )

        id_list = super()._search(args, offset, limit, order, count, access_rights_uid)

        if id_list and not count:
            self._force_prefetch(id_list)

        return id_list

    def _force_prefetch(self, id_list):
        """Force prefetch of records to avoid registry error"""
        self.browse(id_list).read(["res_model", "res_id"])
