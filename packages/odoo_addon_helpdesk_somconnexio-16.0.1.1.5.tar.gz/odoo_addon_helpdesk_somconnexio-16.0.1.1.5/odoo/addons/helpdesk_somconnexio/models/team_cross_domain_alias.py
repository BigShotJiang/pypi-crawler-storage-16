from odoo import models, fields, api, _
from odoo.exceptions import UserError


class TeamCrossDomainAlias(models.Model):
    _name = "team.cross.domain.alias"
    _description = "Helpdesk Team Cross Domain Alias"
    _rec_name = "full_address"
    _check_company_auto = True

    helpdesk_team_id = fields.Many2one(
        comodel_name="helpdesk.ticket.team",
        string=_("Helpdesk Team"),
        required=True,
        ondelete="cascade",
    )
    alias_name = fields.Char(
        string=_("Alias Name"),
        required=True,
        help=_("The alias name used for cross-domain email routing."),
    )
    alias_domain = fields.Char(
        string=_("Alias Domain"),
        required=True,
        help=_("The domain associated with the alias name."),
    )
    full_address = fields.Char(
        string=_("Full Address"),
        compute="_compute_full_address",
        store=True,
        readonly=True,
        help=_("The full email address constructed from alias name and domain."),
    )
    active = fields.Boolean(
        string=_("Active"),
        default=True,
        help=_("Indicates whether the cross-domain alias is active."),
    )
    company_id = fields.Many2one(
        comodel_name="res.company",
        string=_("Company"),
        related="helpdesk_team_id.company_id",
        store=True,
        readonly=True,
    )

    _sql_constraints = [
        (
            "unque_helpdesk_team_alias",
            "unique(helpdesk_team_id, alias_name, alias_domain, company_id)",
            _(
                "The combination of Helpdesk Team, Alias Name, Alias Domain,"
                " and Company must be unique."
            ),
        ),
    ]

    @api.constrains("alias_name", "alias_domain")
    def _check_alias(self):
        for record in self:
            if not self.alias_name.strip() or not self.alias_domain.strip():
                raise UserError(
                    _("Alias Name and Alias Domain cannot be empty or whitespace.")
                )

            alias = record.helpdesk_team_id.alias_id
            if alias and (
                alias.alias_name == record.alias_name
                and alias.alias_domain == record.alias_domain
            ):
                raise UserError(
                    _(
                        "The alias name and domain cannot be the same as the helpdesk "
                        "team's main alias."
                    )
                )

    @api.depends("alias_name", "alias_domain")
    def _compute_full_address(self):
        for record in self:
            record.full_address = f"{record.alias_name}@{record.alias_domain}"
