/** @odoo-module **/

import { FormController } from "@web/views/form/form_controller";
import { formView } from "@web/views/form/form_view";
import { registry } from "@web/core/registry";


export class HelpdeskMailComposeFormController extends FormController {
    /**
     * Override to skip email_to required validation when clicking "Save as Note" button.
     * The save_note action creates a comment/note instead of sending an email,
     * so email_to should not be required in that case.
     */
    async beforeExecuteActionButton(clickParams) {
        const isSaveNoteAction = clickParams?.name === "save_note";
        const isMailComposeMessage = this.props?.resModel === "mail.compose.message";
        const isHelpdeskTicketActive = (
            this.props?.context?.active_model === "helpdesk.ticket"
            && this.model?.root?.data?.model === "helpdesk.ticket"
        );

        if (isSaveNoteAction && isMailComposeMessage && isHelpdeskTicketActive) {
            // Temporarily disable required validation on email_to field
            const emailToFieldInfo = this.archInfo?.activeFields?.email_to;
            const originalRequired = emailToFieldInfo?.modifiers?.required;
            
            if (emailToFieldInfo && originalRequired) {
                emailToFieldInfo.modifiers.required = false;
                
                // Execute the action with validation bypassed
                const result = await super.beforeExecuteActionButton(...arguments);
                
                // Restore the original required state after action completes
                emailToFieldInfo.modifiers.required = originalRequired;
                
                return result;
            }
        }

        return super.beforeExecuteActionButton(...arguments);
    }
}

registry.category("views").add("helpdesk_somconnexio_mail_compose_form", {
    ...formView,
    Controller: HelpdeskMailComposeFormController,
});
