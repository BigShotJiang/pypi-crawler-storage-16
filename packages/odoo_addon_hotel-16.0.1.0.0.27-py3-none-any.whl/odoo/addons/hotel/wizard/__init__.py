# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import hotel_wizard
from . import sale_make_invoice_advance
