Modelo 123 de la AEAT. Retenciones e ingresos a cuenta del Impuesto
sobre la Renta de las Personas Físicas, Impuesto sobre Sociedades y del
Impuesto sobre la Renta de no Residentes (establecimientos permanentes).
Determinados rendimientos del capital mobiliario o determinadas rentas.

Este modelo tiene su utilidad sobre todo en préstamos entre empresas o
particulares, o financiaciones recibidas por ENISA (Empresa Nacional de
Innovación) o CDTI (Centro para el Desarrollo Tecnológico Industrial).

Otra utilidad que se le da es para las retenciones en los repartos de
dividendos.

El modelo se presentará mensualmente para grandes empresas, y
trimestralmente para el resto, por parte de aquellas empresas que deban
abonar intereses de esos préstamos.
