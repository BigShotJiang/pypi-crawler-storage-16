- Este módulo asigna las claves de registro más comunes a las posiciones
  fiscales. Si se utilizan claves distintas a las predeterminadas, se debe
  tener precaución al actualizar el plan contable, ya que el sistema volverá
  a aplicar los valores por defecto.
- Comunicación de cobros y pagos.
- Determinadas facturas intracomunitarias (Articulo 66 RIVA).
- Asistente para consultar los documentos comunicados.
- Libro de bienes de inversión (Libro anual se crea un módulo aparte).
- Regímenes especiales de seguros, de agencias de viaje o de bienes
  usados.
- Devolución de IVA de viajeros.
- Facturas rectificativas por sustitución.
- Sistema de control de número de reintentos en caso de error en el envío.
- Soportar facturas de canje de facturas simplificadas por facturas
  completas. Ver <https://github.com/OCA/l10n-spain/issues/1171> para
  más información.
