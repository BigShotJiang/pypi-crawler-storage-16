-- DISABLE VERI*FACTU ON COMPANIES
UPDATE res_company SET verifactu_test = true;
