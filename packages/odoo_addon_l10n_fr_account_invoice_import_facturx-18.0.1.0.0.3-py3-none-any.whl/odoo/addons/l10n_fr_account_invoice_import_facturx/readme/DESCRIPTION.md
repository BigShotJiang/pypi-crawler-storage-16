This module implements the France-specific part of the Factur-X standard
to import Factur-X invoices. In particular, it extracts the SIRET of the
XML of the Factur-X invoices, which is an important information to match
the supplier.

Factur-X is the e-invoicing standard for France and Germany. The
Factur-X specifications are available on the website of
[FNFE-MPE](http://fnfe-mpe.org/factur-x/).

This module will be installed automatically when the modules
*account_invoice_import_facturx* and *l10n_fr_siret* are installed.
