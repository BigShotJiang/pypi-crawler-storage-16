This is a glue module between:

- account_invoice_import_simple_pdf from
  [OCA/edi](https://github.com/OCA/edi)
- l10n_fr_siret from *OCA/l10n-france*

Once this module is installed, partners will be auto-detected during the
simple PDF invoice import process if their SIREN is set in Odoo and the
SIREN is present as text in the PDF invoice.
