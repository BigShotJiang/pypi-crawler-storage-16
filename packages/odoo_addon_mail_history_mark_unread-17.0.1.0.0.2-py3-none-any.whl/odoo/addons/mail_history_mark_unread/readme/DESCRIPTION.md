This module introduces a "Mark as Unread" button for messages in the History mailbox of the Discuss App.
When done the message is restored back to the Inbox, just like if it were a new unread message, and disappears from the History mailbox.
