To use this module, you need to:

- go to Management Systems \> Manuals \> Hazard
- create a new hazard to enter analysis information, risk evaluation,
  control measures, implementation tests and residual risks evaluation.
