This module allows to return to draft a confirmed or cancelled MO.
