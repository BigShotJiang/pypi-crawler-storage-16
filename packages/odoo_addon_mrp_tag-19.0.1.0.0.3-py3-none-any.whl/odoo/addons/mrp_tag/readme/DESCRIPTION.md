This module allows to add multiple tags to Manufacturing Orders
