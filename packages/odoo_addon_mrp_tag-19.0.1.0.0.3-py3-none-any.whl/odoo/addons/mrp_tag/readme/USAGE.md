To use this module, you need to go to Manufacture Order and select tag.
