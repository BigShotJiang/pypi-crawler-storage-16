Enables workcenter dashboard, disabled by default in Odoo.
This dashboard was available in Odoo CE until v13. This addon enables
again it.
