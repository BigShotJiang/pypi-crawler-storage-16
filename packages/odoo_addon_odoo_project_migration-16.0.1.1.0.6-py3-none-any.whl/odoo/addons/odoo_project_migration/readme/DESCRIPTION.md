This module integrates the migration data collected by `odoo_repository_migration` module in your Odoo projects.
It allows to generate migration reports, giving some hints about the effort to provide to migrate the project to a newer Odoo version.
