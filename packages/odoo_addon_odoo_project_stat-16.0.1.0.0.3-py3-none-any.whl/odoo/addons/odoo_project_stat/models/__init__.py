from . import odoo_project_stat_config
from . import odoo_project_stat
from . import odoo_project
