To enable this feature, the option *Collect migration data* should be
enabled on repositories (opt-in).

To record what a module became starting from a given Odoo version, you
should do it through the *Odoo Repositories / Data / Modules /
Timelines* menu.

Once the scheduled action ran, the migration data are available on each
module in *Migration* tab, or through the *Odoo Repositories / Data /
Modules / Migrations* menu.
