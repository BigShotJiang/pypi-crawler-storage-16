This module is a containers of migration script to migrate from 17.0 to
18.0 version.
