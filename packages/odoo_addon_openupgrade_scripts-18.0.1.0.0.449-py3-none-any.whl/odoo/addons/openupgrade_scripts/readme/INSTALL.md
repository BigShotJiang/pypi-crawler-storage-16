This module does not need to be installed on a database. It simply needs
to be available via your `addons-path`.
