This module extends the functionality of base partner module to allow to
set a default delivery and invoice address and a default contact for
contacts.
