from . import product_pricelist
from . import res_partner
