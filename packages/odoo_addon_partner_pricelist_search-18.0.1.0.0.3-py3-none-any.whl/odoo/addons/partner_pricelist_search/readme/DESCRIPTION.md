This module adds search by pricelist field option in partners.

Also add a new smart button called "Customers" in pricelist form view to
show partners with that pricelist.
