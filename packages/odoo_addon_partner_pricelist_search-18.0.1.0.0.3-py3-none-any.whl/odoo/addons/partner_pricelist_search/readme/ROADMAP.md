With many partner records the search can be slow because all partners
are computed.

No grouping is allowed.
