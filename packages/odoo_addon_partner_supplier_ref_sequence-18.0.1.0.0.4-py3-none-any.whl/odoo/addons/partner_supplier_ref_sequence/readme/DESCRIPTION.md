This module adds the possibility to define a sequence for the partner's supplier
reference. Then when creating a new partner, if the partner is a supplier, the
supplier reference will be automatically set using this sequence.

To distinguish suppliers from customers the partner_manual_rank module is used.
