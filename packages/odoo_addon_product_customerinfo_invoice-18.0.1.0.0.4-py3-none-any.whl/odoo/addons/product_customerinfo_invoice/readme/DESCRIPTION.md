Based on product_customerinfo, this module loads in every
account invoice the customer code defined in the product.
