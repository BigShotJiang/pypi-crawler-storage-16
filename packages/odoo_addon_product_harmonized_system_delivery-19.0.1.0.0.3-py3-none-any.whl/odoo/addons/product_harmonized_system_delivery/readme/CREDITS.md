The migration of this module from 18.0 to 19.0 was financially supported by:

- Camptocamp