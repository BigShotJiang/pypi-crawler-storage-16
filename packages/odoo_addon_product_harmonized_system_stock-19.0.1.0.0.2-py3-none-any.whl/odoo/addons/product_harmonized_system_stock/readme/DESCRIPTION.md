This module adds a menu entry for **H.S. Codes**. This menu entry is
available under *Inventory \> Configuration \> Products*.
