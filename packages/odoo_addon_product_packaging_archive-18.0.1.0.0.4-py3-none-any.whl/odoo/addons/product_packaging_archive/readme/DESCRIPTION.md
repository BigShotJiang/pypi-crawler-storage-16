This module allows to archive product packaging.
