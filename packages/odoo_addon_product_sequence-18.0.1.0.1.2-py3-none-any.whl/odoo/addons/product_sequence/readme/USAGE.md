To specify a different sequence for a product category proceed as
follows:

1.  Go to the a Product Category form view. (**note:** you will need to
    install Inventory app to be able to access to the form view,
    *Inventory \> Configuration \> Products \> Products Categories*; or
    create a menuitem manually).
2.  Fill the *Prefix for Product Internal Reference* as desired.
3.  Under the settings (Settings -\> General Settings -\> Product
    Sequences), you can specify whether the prefix of the parent
    category should be used if no prefix has been specified for the
    category.
