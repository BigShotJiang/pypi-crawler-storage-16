Based on product_supplierinfo_for_customer, this module loads in every Stock move the
customer code defined in the product.
