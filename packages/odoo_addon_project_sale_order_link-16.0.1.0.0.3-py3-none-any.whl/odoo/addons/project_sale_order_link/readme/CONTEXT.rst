Currently a sales order can be linked to a project in the following ways:

  * A sale order item is selected in project.
  * A sale order item is selected in project task.
  * A sale order item is selected in timesheet.
  * A sale order item is selected in sale line/Employee map

But in the project you can only see the selected order in the project itself.
