To use this module, you need to:

#. Go to Project > Configuration > Projects.
#. Click on a project.
#. Click on Smartbutton to see sale orders linked.
