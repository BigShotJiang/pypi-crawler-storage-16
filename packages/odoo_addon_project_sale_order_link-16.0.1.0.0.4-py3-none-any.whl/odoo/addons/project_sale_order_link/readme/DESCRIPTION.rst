This module is glue module that allow you to see all order linked to project, project tasks or employee map.

Now you have 2 available fields referencing related sale orders and sale order lines on each project.
