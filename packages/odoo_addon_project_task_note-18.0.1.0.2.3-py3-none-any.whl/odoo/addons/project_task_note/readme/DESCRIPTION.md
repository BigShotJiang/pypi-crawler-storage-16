This module add notes in project tasks, only visible for internal users.
