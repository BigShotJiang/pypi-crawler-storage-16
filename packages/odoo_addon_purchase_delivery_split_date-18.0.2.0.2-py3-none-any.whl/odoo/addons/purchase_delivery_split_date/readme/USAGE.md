When a Purchase Order is confirmed, shipments will be grouped by same
scheduled date.
