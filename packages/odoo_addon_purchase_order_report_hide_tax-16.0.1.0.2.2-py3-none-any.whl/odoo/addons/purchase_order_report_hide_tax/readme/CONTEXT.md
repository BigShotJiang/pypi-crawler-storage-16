When the taxes are the same in every purchase line, that information might be redundant with the taxes summary and takes valuable space that other columns might take.

This might be event more annoying when there's tax exemptions like in EU intracomunitary operations.
