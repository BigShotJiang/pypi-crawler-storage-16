Shows the Product Tags menu in Inventory app
