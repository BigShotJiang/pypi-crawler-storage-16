This module is a bridge module to use the actual date field to calculate the
currency rate for completed pickings.
