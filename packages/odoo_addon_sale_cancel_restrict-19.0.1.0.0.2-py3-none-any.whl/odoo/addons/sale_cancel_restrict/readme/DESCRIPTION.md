When you try to cancel a sales order, if there is some delivery done or
an invoice not cancelled will prevent the sales order from being
cancelled.
