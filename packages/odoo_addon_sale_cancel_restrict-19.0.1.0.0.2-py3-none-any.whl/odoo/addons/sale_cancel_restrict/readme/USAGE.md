To use this module, you need to:

- Enable Sale Cancel Confirmed Invoice at Sales -\> Settings -\> Enable
  Sale Cancel Restrict.
- Click at "Cancel Order" button from a sales order which state equal to
  Sales Order
- It will show an alert that prevents the sale order from being
  cancelled.
