* go to Sales / Configuration / Settings
* scroll until you find the "Use SO Confirmation Groups" checkbox
* if you want to restrict SO confirmation permission:
  * activate the checkbox
  * add at least 1 security group to the list below the checkbox
* if you don't want to restrict SO confirmation permission:
  * deactivate the checkbox, or remove all security groups from the list below the checkbox
