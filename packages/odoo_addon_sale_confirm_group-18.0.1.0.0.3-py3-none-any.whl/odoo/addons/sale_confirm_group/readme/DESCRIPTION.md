This module allows configuring a list of groups per-company who are granted permission to confirm sale orders:

1. button "Confirm" in sale views is always hidden for users not in those groups
2. if users outside those groups try to confirm a SO, an error is raised
