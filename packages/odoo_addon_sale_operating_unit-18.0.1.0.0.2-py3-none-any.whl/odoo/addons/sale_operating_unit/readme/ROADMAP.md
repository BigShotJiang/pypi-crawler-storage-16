The onchange_team_id method is not working. If you try to change the
team in a sales quotation and the operating unit is not taken from the
sales team, and moreover, I cannot select the operating unit from the
team, only Main OU shows, must have to have your salesperson in the
sales team of the operating unit.
