Follow these steps:

1.  Create a Sale Order.
2.  The Operating Unit of the Sale Team is assigned to the Sale Order.
