This module was developed because there is no way to know what Product Attribute Values has been used on a product if there is only one attribute configured in the product with "Never create variants" mode.

It will be useful for you if you want to know which Product Attribute Values has been used in which Sale Order Lines.

If you need this module for those reasons, these might interest you too:

- sale_order_line_menu
