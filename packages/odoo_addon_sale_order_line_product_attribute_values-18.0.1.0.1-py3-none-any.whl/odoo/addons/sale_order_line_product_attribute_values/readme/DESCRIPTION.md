This module extends the functionality of Sale Order Lines to support view and filter by Product Attribute Values used.
