To use this module, you need to:

1. Create an Attribute called "Trademark" (for example) with Display Type "Pills", Variants Creation Mode "Never" and add an Attribute Value called "Adidas"
2. Create a product called "Shoe Adidas REF 123" and "Show Adidas REF 456"
3. Add "Trademark: Adidas" on Attributes & Variants tab on both products and configure (you can set an incremented price if you want)
4. Sell both products in a Sale Order
5. Created Sale Order Lines has Product Template Attribute Values and Attribute Values its lines.
6. If you has installed `sale_order_line_menu`, you can check those values on Sale > Orders > Order Lines.
