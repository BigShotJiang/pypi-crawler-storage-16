## Images

- Odoo Community Association:
  [Icon](https://github.com/OCA/maintainer-tools/blob/master/template/module/static/description/icon.svg).
