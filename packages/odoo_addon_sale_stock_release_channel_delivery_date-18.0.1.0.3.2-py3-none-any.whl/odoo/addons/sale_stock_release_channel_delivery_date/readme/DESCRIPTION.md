Provide the SO expected date according to possible channels respecting
SO warehouse, carrier and shipping partner.
