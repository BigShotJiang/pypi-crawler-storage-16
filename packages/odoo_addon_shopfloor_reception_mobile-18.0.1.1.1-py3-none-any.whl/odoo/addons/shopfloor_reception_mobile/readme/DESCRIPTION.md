Frontend for the reception scenario in shopfloor. Allows to receive
products and create the proper packs for each logistic unit.
