To view the new columns integrated into this module, 
we need to configure batch transfers. To do this, 
we have to activate it as follows:

1. Go to “Inventory.”
1. Activate “Batch, Wave & Cluster Transfers.”


And we need to activate product packaging:

1. Go to “Inventory.”
1. Activate “Product Packagings.”