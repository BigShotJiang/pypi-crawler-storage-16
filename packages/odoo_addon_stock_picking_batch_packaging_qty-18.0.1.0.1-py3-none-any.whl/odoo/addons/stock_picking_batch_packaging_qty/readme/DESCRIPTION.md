Add packaging fields in tree views inside picking batch.
