To see how this module works, we are going to create a new packaged product:

1. Products > Products. You can create or edit a new one
1. In the “Inventory” section, add a line in “Packaging”

Where you will find the new columns:

1. Operations > Batch Transfers create one or use one with a packaged product.
1. Confirm the batch transfer.
1. In Detailed Operations, we see two new fields.
1. In Operations, in the hidden view, we have a new column to display.