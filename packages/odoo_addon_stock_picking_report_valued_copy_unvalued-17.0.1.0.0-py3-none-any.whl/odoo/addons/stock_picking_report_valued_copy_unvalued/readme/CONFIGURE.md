To configure this module, you need to:

1. Go to Contact Form / Sales and Purchases. Configure the valued picking, and unvalued picking copy checks.
