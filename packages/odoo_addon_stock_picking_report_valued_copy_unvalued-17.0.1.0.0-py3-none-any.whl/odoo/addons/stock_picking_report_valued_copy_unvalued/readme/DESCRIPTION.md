This module allows to print an unvalued picking copy along with the valued picking in the delivery slip report.
