To use this module, you need to:

1. Go to Contact Form / Sales and Purchases. Configure the valued picking, and unvalued picking copy checks.

2. Create a delivery stock picking.

3. Print the delivery slip report.

4. In the "Additional info" section of the picking, you can edit the "unvalued picking copy" option without affecting its partner's default configuration option.
