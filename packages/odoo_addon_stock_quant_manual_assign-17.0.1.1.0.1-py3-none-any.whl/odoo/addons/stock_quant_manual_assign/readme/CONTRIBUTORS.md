* Mikel Arregi <mikelarregi@avanzosc.es>
* Ana Juaristi <anajuaristi@avanzosc.es>
* Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>
* Fanha Giang <fanha99@hotmail.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza <pedro.baeza@tecnativa.com>
  * Vicent Cubells <vicent.cubells@tecnativa.com>

* `ForgeFlow <https://www.forgeflow.com>`_:

  * Jordi Ballester <jordi.ballester@forgeflow.com>
  * Lois Rilo <lois.rilo@forgeflow.com>

* `Shine IT <https://www.openerp.cn>`_:

  * Tony Gu <tony@openerp.cn>

* `Quartile <https://www.quartile.co>`_:

  * Yoshi Tashiro
