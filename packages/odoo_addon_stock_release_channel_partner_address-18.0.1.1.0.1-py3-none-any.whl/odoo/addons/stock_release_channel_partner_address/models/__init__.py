from . import res_partner
from . import stock_release_channel
