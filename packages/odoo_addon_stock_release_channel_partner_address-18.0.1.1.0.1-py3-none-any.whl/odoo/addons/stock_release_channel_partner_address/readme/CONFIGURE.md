Define countries and states on the release channel to filter them by matching those info with the picking partner's country and state.
No filtering is made on the specific field if left blank.
