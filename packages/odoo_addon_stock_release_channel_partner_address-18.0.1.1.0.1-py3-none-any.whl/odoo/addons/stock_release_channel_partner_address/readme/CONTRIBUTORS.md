- Silvio Gregorini \<silvio.gregorini@camptocamp.com\>

## Design

- Jacques-Etienne Baudoux (BCIM) \<je@bcim.be\>
