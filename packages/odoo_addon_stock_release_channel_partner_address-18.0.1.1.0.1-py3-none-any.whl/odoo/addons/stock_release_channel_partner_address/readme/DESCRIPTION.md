Allows defining countries and states on release channels to filter them according to picking partners' addresses.
