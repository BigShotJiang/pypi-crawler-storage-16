- Synconics Technologies Pvt. Ltd. (https://www.synconics.com)

- Codeforward (https://www.codeforward.nl/):
  > - Joep Sanders \<<joep.sanders@codeforward.nl>\>
