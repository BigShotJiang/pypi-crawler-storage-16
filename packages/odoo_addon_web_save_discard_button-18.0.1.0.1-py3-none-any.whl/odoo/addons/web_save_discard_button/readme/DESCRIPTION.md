Change Save & Discard Button style.

![image](../static/description/save_button.png)
