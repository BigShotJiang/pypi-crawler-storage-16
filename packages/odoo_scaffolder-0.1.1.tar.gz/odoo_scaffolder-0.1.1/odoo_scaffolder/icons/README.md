# Icons Directory

Place your category-specific icon PNG files here:

- `accounting.png` - Icon for Accounting modules
- `hr.png` - Icon for HR modules
- `base.png` - Icon for Base modules
- `inventory.png` - Icon for Inventory modules
- `sales.png` - Icon for Sales modules
- `pos.png` - Icon for PoS modules
- `manufacturing.png` - Icon for Manufacturing modules
- `services.png` - Icon for Services modules
- `website.png` - Icon for Website modules

These icons will be bundled with the package and copied to new Odoo modules during scaffolding.
