Fire Dynamics Examples
======================

This page will contain practical examples of fire dynamics calculations using OpenFire.

Heat Release Rate Calculation
-----------------------------

.. code-block:: python

   import ofire

   # Example: Calculate heat release rate
   # (Add actual examples once the Python API is implemented)

Temperature Prediction
----------------------

.. code-block:: python

   import ofire

   # Example: Predict temperature development
   # (Add actual examples once the Python API is implemented)

.. note::
   Fire dynamics examples will be added as the Python API is developed. Check back regularly for updates.