# Security Policy

## Supported Versions

Currently we are supporting only ofsc v2.X

## Reporting a Vulnerability

Please report vulnerabilities by opening an issue. The repository is actively monitored via Dependabot & Snyk
