# ----------------------------------------------------------------------------
# Copyright (c) Omnissa, LLC. All rights reserved.
# This product is protected by copyright and intellectual property laws in the
# United States and other countries as well as by international treaties.
# ----------------------------------------------------------------------------

"""
Simulator implementation of LifecycleManagement interface.
"""

from typing import Any, Optional


from ohcs.lcm.models import DTemplate, VmInfo
from ohcs.lcm.examples.DemoStore import DemoStore
from ohcs.utils import PluginException

_demo = DemoStore()


def _get_vm(template: DTemplate, vmId: str) -> VmInfo:
    vm = _demo.get(template.id, vmId)
    if not vm:
        raise PluginException(f"VM not found: {template.id}/{vmId}")
    return vm


def init() -> Optional[dict[str, Any]]:
    pass


def health(template: DTemplate, params: dict[str, Any]) -> dict[str, Any]:
    return _demo.get_state()


def prepare_template(template: DTemplate, params: dict[str, Any]) -> Optional[dict[str, Any]]:
    pass


def destroy_template(template: DTemplate, params: dict[str, Any]) -> None:
    _demo.remove_template(template.id)


def list_vms(template: DTemplate, params: dict[str, Any]) -> list[VmInfo]:
    return _demo.list_vms(template.id)


def get_vm(template: DTemplate, vmId: str) -> VmInfo:
    return _demo.get(template.id, vmId)


def create_vm(template: DTemplate, vmId: str, params: dict[str, Any]) -> VmInfo:
    vm = VmInfo(id=vmId, cloudId=vmId, powerState="PoweredOn")
    _demo.add(template.id, vmId, vm)
    return vm


def delete_vm(template: DTemplate, vmId: str, params: dict[str, Any]) -> None:
    _demo.remove(template.id, vmId)


def power_on_vm(template: DTemplate, vmId: str, params: dict[str, Any]) -> VmInfo:
    vm = _get_vm(template, vmId)
    vm.powerState = "PoweredOn"
    _demo._save()
    return vm


def power_off_vm(template: DTemplate, vmId: str, params: dict[str, Any]) -> VmInfo:
    vm = _get_vm(template, vmId)
    vm.powerState = "PoweredOff"
    _demo._save()
    return vm


def restart_vm(template: DTemplate, vmId: str, params: dict[str, Any]) -> VmInfo:
    vm = _get_vm(template, vmId)
    vm.powerState = "PoweredOn"
    _demo._save()
    return vm


def shutdown_vm(template: DTemplate, vmId: str, params: dict[str, Any]) -> VmInfo:
    vm = _get_vm(template, vmId)
    vm.powerState = "PoweredOff"
    _demo._save()
    return vm


def snapshot_vm(template: DTemplate, vmId: str, params: dict[str, Any]) -> VmInfo:
    vm = _get_vm(template, vmId)
    current_snapshot = int(vm.snapshotId) if vm.snapshotId else 0
    vm.snapshotId = str(current_snapshot + 1)
    power_off_vm(template, vmId, params)
    return vm


def restore_vm(template: DTemplate, vmId: str, params: dict[str, Any]) -> VmInfo:
    vm = _get_vm(template, vmId)
    if vm.snapshotId is None:
        raise PluginException(f"No snapshot found for VM: {template.id}/{vmId}")
    return vm


def hibernate_vm(template: DTemplate, vmId: str, params: dict[str, Any]) -> VmInfo:
    vm = _get_vm(template, vmId)
    vm.powerState = "PoweredOff"
    _demo._save()
    return vm


def resize_vm(template: DTemplate, vmId: str, params: dict[str, Any]) -> VmInfo:
    vm = _get_vm(template, vmId)
    return vm


def _reset_simulator():
    _demo.clear()
