# ----------------------------------------------------------------------------
# Copyright (c) Omnissa, LLC. All rights reserved.
# This product is protected by copyright and intellectual property laws in the
# United States and other countries as well as by international treaties.
# ----------------------------------------------------------------------------

import traceback
from dataclasses import fields
from functools import wraps
from inspect import iscoroutinefunction
from typing import Any, Callable, Type, TypeVar

from loguru import logger
from yumako.lru import LRUDict

from ohcs.lcm.serve import factory
from ohcs.lcm.models import DTemplate, LifecycleManagement
from ohcs.utils import error_details

_template_cache = LRUDict[str, dict](capacity=500)

T = TypeVar("T")

# Color for KOP (Key Operation) log messages
KOP_COLOR = "magenta"


def _build_kop_path(operation_name: str, args: tuple, kwargs: dict) -> str:
    """Extract identifiers from arguments and build KOP path for logging.

    Args:
        operation_name: Name of the operation (function name)
        args: Positional arguments from the wrapped function
        kwargs: Keyword arguments from the wrapped function

    Returns:
        KOP path string (e.g., "KOP/create/template123/vm456")
    """
    # Extract template and get its id
    template = args[0] if args else kwargs.get("template")
    template_id = template["id"]

    # Check if second parameter contains vmId
    vmId = None
    if len(args) > 1:
        second_arg = args[1]
        if isinstance(second_arg, str):
            # Second parameter is vmId directly
            vmId = second_arg
        elif isinstance(second_arg, dict) and "vmId" in second_arg:
            # Second parameter is spec dict containing vmId
            vmId = second_arg["vmId"]
    elif "vmId" in kwargs:
        vmId = kwargs["vmId"]
    elif "spec" in kwargs and isinstance(kwargs["spec"], dict):
        vmId = kwargs["spec"].get("vmId")

    # Build and return KOP path
    kop_path = f"KOP/{operation_name}/{template_id}"
    if vmId:
        kop_path += f"/{vmId}"
    return kop_path


def kop_logger(func: Callable) -> Callable:
    """Decorator that adds KOP logging and error handling to lifecycle management functions.

    Automatically logs:
    - Start of operation with KOP path
    - Successful completion
    - Errors with details

    Expects first parameter to be 'template' dict with 'id' key.
    If second parameter is 'vmId' (string), it will be included in the KOP path.
    If second parameter is 'spec' (dict with 'vmId' key), vmId will be extracted from it.
    """
    operation_name = func.__name__
    is_async = iscoroutinefunction(func)

    @wraps(func)
    async def async_wrapper(*args, **kwargs):
        kop_path = _build_kop_path(operation_name, args, kwargs)

        logger.info(f"<{KOP_COLOR}>{kop_path}</{KOP_COLOR}> start")
        try:
            result = await func(*args, **kwargs)
            logger.info(f"<{KOP_COLOR}>{kop_path}</{KOP_COLOR}> success")
            return result
        except Exception as e:
            logger.error(f"{kop_path} error: {error_details(e)}")
            traceback.print_exc()
            raise

    @wraps(func)
    def sync_wrapper(*args, **kwargs):
        kop_path = _build_kop_path(operation_name, args, kwargs)

        logger.info(f"<{KOP_COLOR}>{kop_path}</{KOP_COLOR}> start")
        try:
            result = func(*args, **kwargs)
            logger.info(f"<{KOP_COLOR}>{kop_path}</{KOP_COLOR}> success")
            return result
        except Exception as e:
            logger.error(f"{kop_path} error: {error_details(e)}")
            traceback.print_exc()
            raise

    return async_wrapper if is_async else sync_wrapper


def _dict_to_dataclass(data: dict, dataclass_type: Type[T]) -> T:
    field_names = {f.name for f in fields(dataclass_type)}  # type: ignore[arg-type]
    filtered_data = {k: data.get(k) for k in field_names}
    return dataclass_type(**filtered_data)


@kop_logger
def prepare(template: dict, params: dict[str, Any]):
    provider, tmpl = _handle_template(template)
    extension_name = tmpl.extensionName or "lcm_plugin"
    logger.info(f"Template ID: {tmpl.id}, name: {tmpl.name}, extension: {extension_name}")
    provider.prepare_template(tmpl, params)


@kop_logger
def destroy(template: dict, params: dict[str, Any]):
    provider, tmpl = _handle_template(template)
    provider.destroy_template(tmpl, params)


@kop_logger
def list(template: dict, params: dict[str, Any]):
    provider, tmpl = _handle_template(template)
    return provider.list_vms(tmpl, params)


@kop_logger
def create(template: dict, vmId: str, params: dict[str, Any]):
    provider, tmpl = _handle_template(template)
    return provider.create_vm(tmpl, vmId, params)


@kop_logger
def delete(template: dict, vmId: str, params: dict[str, Any]):
    provider, tmpl = _handle_template(template)
    return provider.delete_vm(tmpl, vmId, params)


@kop_logger
def powerOn(template: dict, vmId: str, params: dict[str, Any]):
    provider, tmpl = _handle_template(template)
    return provider.power_on_vm(tmpl, vmId, params)


@kop_logger
def powerOff(template: dict, vmId: str, params: dict[str, Any]):
    provider, tmpl = _handle_template(template)
    return provider.power_off_vm(tmpl, vmId, params)


@kop_logger
def restart(template: dict, vmId: str, params: dict[str, Any]):
    provider, tmpl = _handle_template(template)
    return provider.restart_vm(tmpl, vmId, params)


@kop_logger
def shutdown(template: dict, vmId: str, params: dict[str, Any]):
    provider, tmpl = _handle_template(template)
    return provider.shutdown_vm(tmpl, vmId, params)


@kop_logger
def snapshot(template: dict, vmId: str, params: dict[str, Any]):
    provider, tmpl = _handle_template(template)
    return provider.snapshot_vm(tmpl, vmId, params)


@kop_logger
def restore(template: dict, vmId: str, params: dict[str, Any]):
    provider, tmpl = _handle_template(template)
    return provider.restore_vm(tmpl, vmId, params)


@kop_logger
def hibernate(template: dict, vmId: str, params: dict[str, Any]):
    provider, tmpl = _handle_template(template)
    return provider.hibernate_vm(tmpl, vmId, params)


@kop_logger
def get(template: dict, vmId: str):
    provider, tmpl = _handle_template(template)
    return provider.get_vm(tmpl, vmId)


@kop_logger
def health(template: dict, params: dict[str, Any]):
    provider, tmpl = _handle_template(template)
    return provider.health(tmpl, params)


def _handle_template(data: dict) -> tuple[LifecycleManagement, DTemplate]:
    template_id = data["id"]
    existing = _template_cache.get(template_id)
    if existing:
        existing.update(data)
        data = existing
    else:
        _template_cache[template_id] = data

    tmpl = _dict_to_dataclass(data, DTemplate)

    if not tmpl.extensionName:
        plugin_name = "lcm_plugin"
    else:
        plugin_name = tmpl.extensionName

    provider = factory.get_lifecycle_manager(plugin_name)
    return provider, tmpl


prepare.timeout = 600  # type: ignore[attr-defined]
destroy.timeout = 1200  # type: ignore[attr-defined]
list.timeout = 60  # type: ignore[attr-defined]
create.timeout = 1800  # type: ignore[attr-defined]
delete.timeout = 300  # type: ignore[attr-defined]
powerOn.timeout = 120  # type: ignore[attr-defined]
powerOff.timeout = 120  # type: ignore[attr-defined]
restart.timeout = 120  # type: ignore[attr-defined]
shutdown.timeout = 120  # type: ignore[attr-defined]
snapshot.timeout = 120  # type: ignore[attr-defined]
restore.timeout = 120  # type: ignore[attr-defined]
hibernate.timeout = 120  # type: ignore[attr-defined]
get.timeout = 60  # type: ignore[attr-defined]
health.timeout = 60  # type: ignore[attr-defined]
