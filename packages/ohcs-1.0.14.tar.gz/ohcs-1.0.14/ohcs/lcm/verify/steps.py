# ----------------------------------------------------------------------------
# Copyright (c) Omnissa, LLC. All rights reserved.
# This product is protected by copyright and intellectual property laws in the
# United States and other countries as well as by international treaties.
# ----------------------------------------------------------------------------

import json
import random
import sys
import time
from typing import Union

import click
from hcs_core.ctxp import profile
from yumako.time import display as display_time

from ohcs.lcm.verify.helper import context, create_template, fail, get_akka_plan_file_path, step, trivial
from ohcs.utils import error_details, run_cli


@step(10)
def check_hcs_cli_availability():
    try:
        version = run_cli("hcs --version", inherit_output=False).stdout.strip()
        trivial(version)
    except Exception as e:
        trivial(error_details(e))
        fail("hcs-cli is not available.")


@step(11, "[Check Precondition] identify the current user organization from login session")
def identify_user_organization():
    try:
        org_info = run_cli("hcs org get", output_json=True)
    except Exception as e:
        trivial(error_details(e))

        click.echo("It seems the curernt login session is not valid.")
        click.prompt(
            "Press ENTER to launch browser to login Horizon Cloud Service...",
            prompt_suffix="",
            default="",
            show_default=False,
        )
        run_cli("hcs login")
        click.echo()
        trivial("Login successful")
        org_info = run_cli("hcs org get", output_json=True)

    context.org_id = org_info["orgId"]
    trivial(f"Organization: {org_info['orgName']} ({context.org_id})")


@step(12, "[Check Precondition] check HCS connectivity")
def check_hcs_connectivity():
    trivial(f"HCS URL: {profile.current().hcs.url}")
    try:
        run_cli("hcs site list --ids", output_json=True)
    except Exception as e:
        trivial(error_details(e))
        fail("HCS connectivity or authentication is not successful.")


def _cleanup_impl():
    trivial("Cleaning up test resources...")
    template_ids = run_cli("hcs template list --search 'name $like lcm_test_' --ids", output_json=True)

    for template_id in template_ids:
        if context.lcm_access:
            run_cli(f"hcs lcm template delete -y {template_id}", inherit_output=False, raise_on_error=False)
        else:
            run_cli(f"hcs template delete -y {template_id}", inherit_output=False, raise_on_error=False)

    first = True
    for template_id in template_ids:
        if first:
            first = False
            time_to_wait = "10m"
        else:
            time_to_wait = "1m"
        if context.lcm_access:
            run_cli(
                f"hcs lcm template delete -y -w{time_to_wait} {template_id}", inherit_output=False, raise_on_error=False
            )
        else:
            run_cli(
                f"hcs template delete -y -w{time_to_wait} {template_id}", inherit_output=False, raise_on_error=False
            )

    if context.akka_deployment:
        trivial("Destroying Akka stack...")
        run_cli(f"hcs plan destroy -f {get_akka_plan_file_path()}")
        context.akka_deployment = None

    trivial("Test resources are cleaned up.")


@step(20)
def cleanup_previous_test_resources_if_any():
    _cleanup_impl()


@step(30, "[Resource] Verify or create provider")
def verify_or_create_provider():
    if context.user_provider_id:
        trivial(f"Verifying user specified provider: {context.user_provider_id}")
        if context.lcm_access:
            provider_info = run_cli(
                f"hcs lcm provider get {context.user_provider_id}", output_json=True, raise_on_error=False
            )
        else:
            provider_info = run_cli(
                f"hcs provider get {context.user_provider_id}", output_json=True, raise_on_error=False
            )

        if provider_info:
            context.provider_id = provider_info["id"]
            trivial(f"Provider: {context.provider_id} ({provider_info['type']}/{provider_info['name']})")
        else:
            fail(f"Provider: {context.user_provider_id} not found")
        return

    if context.mode_config == "builtin:akka":
        run_cli(f"hcs plan apply -f {get_akka_plan_file_path()}", output_json=False, inherit_output=True)
        deployment_info = run_cli("hcs plan output", output_json=True)
        trivial("Akka stack created successfully.")
        context.akka_deployment = deployment_info
        return

    if context.mode_config == "builtin:plugin-simulator":
        if context.lcm_access:
            payload = {
                "id": "lcm_test_ep1",
                "type": "EDGEPROXY",
                "orgId": context.org_id,
                "name": "lcm_test_ep1",
                "host": "dummy",
            }
            provider_info = run_cli("hcs lcm provider create", output_json=True, input=payload)
            context.provider_id = provider_info["id"]
            trivial(f"Provider created: {provider_info['id']} ({context.provider_type}/{payload['name']})")
        else:
            payload = {
                "orgId": context.org_id,
                "providerLabel": "custom",
                "name": "lcm-test",
                "edgeGatewayNeeded": False,
                "providerDetails": {
                    "method": "ByCustomPlugin",
                    "data": {"platformName": "testPlatform", "geoLocationLat": "37.38", "geoLocationLong": "-122"},
                },
            }
            provider_info = run_cli("hcs provider create", output_json=True, input=payload)
            context.provider_id = provider_info["id"]
            trivial(f"Provider created: {provider_info['id']} ({context.provider_type}/{payload['name']})")
        return

    if context.mode_config.startswith("file:"):
        return
    if context.mode_config.startswith("id:"):
        return
    raise click.ClickException(f"Invalid config: {context.mode_config}.")


@step(31)
def create_template1():
    template_info = create_template(random.randint(100, 199))
    context.template_id_1 = template_info["id"]

    trivial(f"Template created: {template_info['id']} ({template_info['templateType']}/{template_info['name']})")

    trivial("Waiting for template to be ready...")

    try:
        if context.lcm_access:
            run_cli(f"hcs lcm template wait {context.template_id_1} -t20m")
        else:
            run_cli(f"hcs template wait {context.template_id_1} -t20m")
    except Exception as e:
        if context.lcm_access:
            template_info = run_cli(f"hcs lcm template get {context.template_id_1}", output_json=True)
        else:
            template_info = run_cli(f"hcs template get {context.template_id_1}", output_json=True)
        click.echo()
        click.echo("---- Start template dump ----")
        if "customVariables" in template_info:
            template_info["customVariables"] = f"<redacted> ({len(template_info['customVariables'])})"
        if "customTemplate" in template_info:
            template_info["customTemplate"] = f"<redacted> ({len(template_info['customTemplate'])})"
        click.echo(json.dumps(template_info, indent=4, default=vars))
        click.echo("---- End template dump ----")
        fail(error_details(e))


@step(32, "[VM Basis] Verify the first VM")
def verify_vm():
    if context.lcm_access:
        vm = run_cli(f"hcs inventory list --first {context.template_id_1}", output_json=True)
    else:
        vm = run_cli(f"hcs vm list --first {context.template_id_1}", output_json=True)

    trivial(f"The first VM is: {vm['id']}")
    context.t1_vm0 = context.template_id_1 + "/" + vm["id"]

    lifecycle_status = vm["lifecycleStatus"]
    if lifecycle_status != "PROVISIONED":
        fail(f"The first VM is not provisioned. Lifecycle status: {lifecycle_status}. Error: {vm.get('error')}")
    trivial("The first VM lifecycle status is PROVISIONED.")

    power_state = vm.get("powerState")
    if power_state is None:
        # Rare case that the VM is not yet powered on
        time.sleep(5)
        if context.lcm_access:
            vm = run_cli(f"hcs inventory list --first {context.template_id_1}", output_json=True)
        else:
            vm = run_cli(f"hcs vm list --first {context.template_id_1}", output_json=True)
        power_state = vm.get("powerState")
    if power_state != "PoweredOn":
        fail(f"The first VM is not powered on. Power state: {power_state}. Error: {vm.get('error')}")
    trivial("The first VM is powered on.")

    agent_status = vm["agentStatus"]
    if agent_status != "AVAILABLE":
        fail(f"The first VM agent is not available. Agent status: {agent_status}. Error: {vm.get('error')}")
    trivial("The first VM agent is AVAILABLE.")


@step(40)
def test_power_off():
    if context.lcm_access:
        vm = run_cli(f"hcs lcm vm poweroff -w5m {context.t1_vm0}", output_json=True)
    else:
        vm = run_cli(f"hcs vm poweroff -w5m {context.t1_vm0}", output_json=True)
    power_state = vm["powerState"]
    if power_state != "PoweredOff":
        fail(f"The first VM is not powered off. Power state: {power_state}")


@step(41)
def test_power_on():
    if context.lcm_access:
        vm = run_cli(f"hcs lcm vm poweron -w5m {context.t1_vm0}", output_json=True)
    else:
        vm = run_cli(f"hcs vm poweron -w5m {context.t1_vm0}", output_json=True)
    power_state = vm["powerState"]
    if power_state != "PoweredOn":
        fail(f"The first VM is not powered on. Power state: {power_state}")


@step(42)
def test_shutdown():
    if context.lcm_access:
        run_cli(f"hcs lcm vm shutdown -w5m {context.t1_vm0}", output_json=True)
    else:
        run_cli(f"hcs vm shutdown -w5m {context.t1_vm0}", output_json=True)


@step(43)
def test_restart():
    if context.lcm_access:
        run_cli(f"hcs lcm vm poweron -w5m {context.t1_vm0}", output_json=True)
        run_cli(f"hcs lcm vm restart {context.t1_vm0}", output_json=True)
    else:
        run_cli(f"hcs vm poweron -w5m {context.t1_vm0}", output_json=True)
        run_cli(f"hcs vm restart {context.t1_vm0}", output_json=True)

    time.sleep(15)

    # wait for the VM to be PoweredOn again
    if context.lcm_access:
        run_cli(
            f"hcs lcm vm wait --property powerState=PoweredOn --timeout 5m {context.t1_vm0}",
            output_json=True,
            inherit_output=False,
        )
    else:
        run_cli(
            f"hcs vm wait --property powerState=PoweredOn --timeout 5m {context.t1_vm0}",
            output_json=True,
            inherit_output=False,
        )


@step(44)
def test_delete_vm():
    # shrink sparePolicy.min to 0, to prevent from auto recreation
    if context.lcm_access:
        run_cli(
            f"hcs lcm template update -u sparePolicy.min=0 -u sparePolicy.max=2 {context.template_id_1}",
            output_json=True,
        )
        run_cli(f"hcs lcm vm delete -y -w5m {context.t1_vm0}", output_json=False, inherit_output=False)
        vm_ids = run_cli(f"hcs inventory list {context.template_id_1} --ids", output_json=True)
    else:
        run_cli(
            f"hcs template update -u sparePolicy.min=0 -u sparePolicy.max=2 {context.template_id_1}", output_json=True
        )
        run_cli(f"hcs vm delete -y -w5m {context.t1_vm0}", output_json=False, inherit_output=False)
        vm_ids = run_cli(f"hcs vm list {context.template_id_1} --ids", output_json=True)

    if context.t1_vm0 in vm_ids:
        fail(f"The first VM is not deleted. VM ID: {context.t1_vm0}")


@step(50, "[Template Operation] Expand the template with 2 more VMs concurrently")
def test_parallel_expansion():
    if context.lcm_access:
        run_cli(
            f"hcs lcm template update -u sparePolicy.min=2 -u sparePolicy.max=2 {context.template_id_1}",
            output_json=True,
        )
    else:
        run_cli(
            f"hcs template update -u sparePolicy.min=2 -u sparePolicy.max=2 {context.template_id_1}",
            output_json=True,
        )
    trivial("Waiting for two more VMs to be created in parallel")

    start_time = time.time()
    while time.time() - start_time < 5 * 60:
        if context.lcm_access:
            template_info = run_cli(
                f"hcs lcm template get --field capacityInfo {context.template_id_1}", output_json=True
            )
            provisioned_vms = template_info["capacityInfo"]["provisionedVMs"]
        else:
            template_info = run_cli(
                f"hcs template get --field reportedStatus {context.template_id_1}", output_json=True
            )
            provisioned_vms = template_info["reportedStatus"]["provisionedVMs"]
        if provisioned_vms >= 2:
            break
        time.sleep(30)


@step(51)
def test_delete_template():
    if context.lcm_access:
        run_cli(f"hcs lcm template delete -y -w5m {context.template_id_1}", inherit_output=False)
    else:
        run_cli(f"hcs template delete -y -w5m {context.template_id_1}", inherit_output=False)


@step(60, "[Parallel Operation] Test operating two templates at the same time.")
def test_operating_two_templates_at_the_same_time():
    template_info2 = create_template(random.randint(200, 299), 2)
    context.template_id_2 = template_info2["id"]
    trivial(f"Template2 created: {template_info2['id']} ({template_info2['templateType']}/{template_info2['name']})")
    template_info3 = create_template(random.randint(300, 399), 2)
    context.template_id_3 = template_info3["id"]
    trivial(f"Template3 created: {template_info3['id']} ({template_info3['templateType']}/{template_info3['name']})")

    if context.lcm_access:
        run_cli(f"hcs lcm template wait -t20m {context.template_id_2}")
        run_cli(f"hcs lcm template wait -t1m {context.template_id_3}")
    else:
        run_cli(f"hcs template wait -t20m {context.template_id_2}")
        run_cli(f"hcs template wait -t1m {context.template_id_3}")


@step(61, "[Parallel Operation] Power off all VMs from all templates")
def power_off_all_vms_from_all_templates():
    t2_vms = run_cli(f"hcs vm list --ids {context.template_id_2}", output_json=True)
    t3_vms = run_cli(f"hcs vm list --ids {context.template_id_3}", output_json=True)
    payload = {"ids": t2_vms}
    run_cli(
        f"hcs api --post /admin/v2/templates/{context.template_id_2}/vms?action=powerOff&org_id={context.org_id}",
        input=payload,
        output_json=True,
    )
    payload = {"ids": t3_vms}
    run_cli(
        f"hcs api --post /admin/v2/templates/{context.template_id_3}/vms?action=powerOff&org_id={context.org_id}",
        input=payload,
        output_json=True,
    )

    full_vm_paths = [f"{context.template_id_2}/{id}" for id in t2_vms] + [
        f"{context.template_id_3}/{id}" for id in t3_vms
    ]
    first = True
    for full_vm_path in full_vm_paths:
        if first:
            first = False
            time_to_wait = "5m"
        else:
            time_to_wait = "1m"
        run_cli(
            f"hcs vm wait --property powerState=PoweredOff --timeout {time_to_wait} {full_vm_path}", output_json=True
        )
    trivial("All VMs from all templates are powered off")


@step(70, "[Parallel Operation] Delete two templates")
def delete_two_templates():
    if context.lcm_access:
        run_cli(f"hcs lcm template delete -y {context.template_id_2}", inherit_output=False)
        run_cli(f"hcs lcm template delete -y {context.template_id_3}", inherit_output=False)
        run_cli(f"hcs lcm template delete -y {context.template_id_2} -w10m", inherit_output=False)
        trivial("Template 2 deleted")
        # Because they are deleted in parallel, now we should not wait for long.
        run_cli(f"hcs lcm template delete -y {context.template_id_3} -w1m", inherit_output=False)
        trivial("Template 3 deleted")
    else:
        run_cli(f"hcs template delete -y {context.template_id_2}", inherit_output=False)
        run_cli(f"hcs template delete -y {context.template_id_3}", inherit_output=False)
        run_cli(f"hcs template delete -y {context.template_id_2} -w10m", inherit_output=False)
        trivial("Template 2 deleted")
        # Because they are deleted in parallel, now we should not wait for long.
        run_cli(f"hcs template delete -y {context.template_id_3} -w1m", inherit_output=False)
        trivial("Template 3 deleted")


@step(100)
def clean_up_test_resources():
    _cleanup_impl()


def run(
    mode_config: str,
    provider_id: str,
    specific_step: Union[str, int] = None,
    from_step: int = None,
    to_step: int = None,
    lcm_access: bool = False,
):
    context.user_provider_id = provider_id
    context.mode_config = mode_config
    context.lcm_access = lcm_access

    start_time = time.time()
    step.run(module=sys.modules[__name__], specific=specific_step, from_step=from_step, to_step=to_step)  # type: ignore[attr-defined]
    print()
    click.echo("✓ Complete. " + click.style(f"({display_time(time.time() - start_time)})", fg="bright_black"))


def clean(lcm_access: bool):
    context.lcm_access = lcm_access
    clean_up_test_resources()
