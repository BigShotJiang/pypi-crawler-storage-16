#!/usr/bin/env python3

# ----------------------------------------------------------------------------
# Copyright (c) Omnissa, LLC. All rights reserved.
# This product is protected by copyright and intellectual property laws in the
# United States and other countries as well as by international treaties.
# ----------------------------------------------------------------------------

import logging
import os
import sys
import traceback

import click

from ohcs import __version__
from ohcs.common.utils import OhcsSdkException, error_details, good
from ohcs.common.logging_config import setup_logging

logger = logging.getLogger(__name__)

setup_logging()


@click.group(context_settings=dict(help_option_names=["-h", "--help"]))
def cli():
    """OHCS (Omnissa Horizon Cloud Service) lifecycle management extension"""
    pass


@cli.command()
def version():
    """Show version information"""
    click.echo(f"Omnissa Horizon Cloud Service LCM SDK, v{__version__}")


@cli.command()
@click.option("--org", "-o", type=str, required=False, help="The organization ID.")
@click.option(
    "--provider",
    "-p",
    type=str,
    required=False,
    help="The provider instance to pair with. If not specified, local configuration will be reused if exists, otherwise a new one will be created.",
)
@click.option("--no-stub", is_flag=True, default=False, help="Do not create stub plugin implementation and tutorial.")
@click.option(
    "--config",
    "customization_file",
    required=False,
    help="Optional. Specify properties file path to override default settings.",
)
def pair(org: str, provider: str = None, no_stub: bool = False, customization_file: str = None):
    """Pair with Horizon Cloud Service. If the local config.yml file exists, it will reuse provider and edge from the previous configuration, if exists. Otherwise, new provider and edge record will be created."""

    if not org:
        from hcs_core.ctxp import profile

        org = profile.current().csp.orgId
        if not org:
            click.echo("Org ID not found in profile. Specify --org <org-id>.")
            return 1

    if customization_file:
        if not os.path.exists(customization_file):
            click.echo(f"Config file not found: {customization_file}")
            return 1

    from . import pair

    if provider:
        config = pair.pair_existing(org, customization_file, provider)
    else:
        config = pair.pair_existing_or_new(org, customization_file)

    if no_stub:
        pass
    else:
        pair.create_stub_plugin_and_tutorial(config)


@cli.command()
@click.option("--org", "-o", type=str, required=False, help="The organization ID.")
@click.option("--all", is_flag=True, default=False, help="Delete all custom provider instances from the cloud.")
@click.option("--confirm", "-y", is_flag=True, default=False, help="Confirm the operation without prompt.")
def reset(org: str, all: bool, confirm: bool):
    """Reset the pairing, delete records from cloud and local pairing configuration."""

    from . import pair

    if all:
        pair.reset_all(org, confirm)
    else:
        pair.reset(org, confirm)
    good("Reset completed.")


@cli.command()
@click.option(
    "--config",
    "-c",
    "config_file",
    type=str,
    required=False,
    default=None,
    help="Specify the path of config file to use",
)
def serve(config_file: str):
    """Serve the local lifecycle management extension"""

    from ohcs.lcm.serve import serve

    serve(config_file)


@cli.command()
@click.option(
    "--template-file",
    "-f",
    type=str,
    required=False,
    help="Specify the template file for testing. New templates will be created using the given template file.",
)
@click.option(
    "--template-id",
    "-t",
    type=str,
    required=False,
    help="Specify the ID of an existing template, to copy settings for test templates. The specified template will not be changed.",
)
@click.option(
    "--akka",
    is_flag=True,
    required=False,
    help="Use the AKKA template for testing.",
)
@click.option(
    "--plugin-simulator",
    is_flag=True,
    required=False,
    help="Use the plugin simulator template for testing.",
)
@click.option(
    "--provider", "-p", type=str, required=False, help="Override the provider instance ID to use for the test."
)
@click.option(
    "--step",
    "-s",
    type=str,
    required=False,
    help="Run a single specific step, either by name or index",
)
@click.option(
    "--from",
    "from_step",
    type=int,
    required=False,
    help="Run from a specific step index",
)
@click.option("--to", "to_step", type=int, required=False, help="Run to a specific step index")
@click.option(
    "--clean", "-c", is_flag=True, required=False, help="Clean up the test environment. Do not run test steps."
)
@click.option(
    "--lcm-access", is_flag=True, default=False, hidden=True, help="Use native service access in development env."
)
def verify(
    template_file: str,
    template_id: str,
    akka: bool,
    plugin_simulator: bool,
    provider: str,
    step: str,
    from_step: int,
    to_step: int,
    clean: bool,
    lcm_access: bool,
):
    """Run lifecycle management (LCM) verification test. This will invoke cloud API to create/delete templates and VMs to verify the provider and LCM plugin."""

    from . import verify

    if clean:
        if template_file or template_id or akka or plugin_simulator or provider or step or from_step or to_step:
            raise click.ClickException("Cannot specify --clean and other options at the same time")
        return verify.clean(lcm_access)

    if akka and template_file:
        raise click.ClickException("Cannot specify both --akka and --template-file")
    if akka and template_id:
        raise click.ClickException("Cannot specify both --akka and --template-id")
    if akka and plugin_simulator:
        raise click.ClickException("Cannot specify both --akka and --plugin-simulator")
    if akka and provider:
        raise click.ClickException(
            "Cannot specify both --akka and --provider. For akka mode, the provider will be automatically created."
        )
    if plugin_simulator and template_file:
        raise click.ClickException("Cannot specify both --plugin-simulator and --template-file")
    if plugin_simulator and template_id:
        raise click.ClickException("Cannot specify both --plugin-simulator and --template-id")
    if template_file and template_id:
        raise click.ClickException("Cannot specify both --template-file and --template-id")
    if step and from_step:
        raise click.ClickException("Cannot specify both step and from_step")
    if step and to_step:
        raise click.ClickException("Cannot specify both step and to_step")

    if akka:
        mode_config = "builtin:akka"
    elif plugin_simulator:
        mode_config = "builtin:plugin-simulator"
    elif template_file:
        mode_config = "file:" + template_file
    elif template_id:
        mode_config = "id:" + template_id
    else:
        raise click.ClickException(
            "Template file or template ID is required. Specify --template <file-path> or --template-id <template-id>."
        )

    return verify.run(mode_config, provider, specific_step=step, from_step=from_step, to_step=to_step)


@cli.command()
def info():
    """Show information about the running lifecycle management process"""
    import json
    from ohcs.common import stats
    from ohcs import __version__

    # Read stats from shared memory
    global_stats = stats.read_shared()

    # Build info response
    info_data = {"version": __version__, "stats": global_stats}

    click.echo(json.dumps(info_data, indent=4))


def _need_error_traceback(e):
    for type in []:
        if isinstance(e, type):
            return False
    return True


if __name__ == "__main__":
    try:
        cli()
    except OhcsSdkException as e:
        logger.error(f"OHCS Error: {error_details(e)}")
        sys.exit(1)
    except Exception as e:
        if _need_error_traceback(e):
            traceback.print_exc()
        logger.exception(f"Unexpected error: {error_details(e)}")
        sys.exit(1)
