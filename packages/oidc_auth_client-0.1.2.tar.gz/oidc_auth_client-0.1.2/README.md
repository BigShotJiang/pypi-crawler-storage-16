# oidc-auth-client

## Installing

`pip install oidc-auth-client`

## Example usage

```py
from oidc_auth_client import Config, AuthorizationCode, OidcProvider

access_token = AuthorizationCode(
    config=Config(
        client_id="<your-client-id>",
        oidc_provider=OidcProvider(
            openid_configuration_url="<auth-provider-url>/.well-known/openid-configuration"
        ),
        token_cache=TokenCache(),
    )
).get_token()
```

To allow the user to cache the token between usages, configure with a `TokenCache`. Will store the token in plaintext on the users system.

```py
from oidc_auth_client import Config, TokenCache

config = Config(
    # ...
    token_cache=TokenCache(),
)
```

see some example usage in the [examples folder](./examples/).
