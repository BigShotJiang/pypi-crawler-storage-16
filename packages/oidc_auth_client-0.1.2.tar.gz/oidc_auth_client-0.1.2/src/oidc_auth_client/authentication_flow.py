from dataclasses import dataclass
import logging
import sys
from abc import ABC, abstractmethod
from typing import Literal


from oidc_auth_client.oidc import OidcProvider
from oidc_auth_client.token_cache import TokenCache

LogLevel = Literal[
    "CRITICAL",
    "ERROR",
    "WARNING",
    "INFO",
    "DEBUG",
    "NOTSET",
]


@dataclass(frozen=True)
class Config:
    client_id: str
    oidc_provider: OidcProvider
    loglevel: LogLevel = "INFO"
    token_cache: TokenCache | None = None


class AuthenticationFlow(ABC):
    def __init__(
        self,
        config: Config,
    ) -> None:
        self._config = config
        self._logger = logging.getLogger("auth")
        self._logger.setLevel(config.loglevel)
        if not self._logger.handlers:
            handler = logging.StreamHandler(sys.stdout)
            handler.setFormatter(
                logging.Formatter(
                    "[%(asctime)s] %(name)s %(levelname)s: %(message)s",
                    datefmt="%H:%M:%S",
                )
            )
            self._logger.addHandler(handler)

        self._oidc_provider = self._config.oidc_provider
        self._config.oidc_provider.set_logger(self._logger)
        self._token_cache = self._config.token_cache

        if self._token_cache is not None:
            self._token_cache.set_logger(self._logger)
            self._token_cache.initialize(config.client_id)

    @abstractmethod
    def get_token(self) -> str: ...
