from oidc_auth_client.authentication_flow import AuthenticationFlow
from oidc_auth_client.oidc import OidcProvider
from oidc_auth_client.token_cache import TokenCache


class ClientCredentials(AuthenticationFlow):
    def __init__(
        self,
        client_id: str,
        client_secret: str,
        tokens_url: str,
        timeout: int = 10,  # Seconds
        app_name: str = "geohub_auth",
        loglevel: str = "INFO",
        oidc_provider: OidcProvider | None = None,
        token_cache: TokenCache | None = None,
    ) -> None:
        self._client_id = client_id
        self._client_secret = client_secret
        self._tokens_url = tokens_url
        self._timeout = timeout

        super().__init__(app_name, loglevel, oidc_provider, token_cache)

    def get_token(self) -> str:
        token: str | None = self._token_cache.load_cached_token()
        if token is not None:
            return token

        tokens = self._oidc_provider.tokens(
            self._tokens_url,
            data={
                "client_id": self._client_id,
                "client_secret": self._client_secret,
                "grant_type": "client_credentials",
            },
        )
        self._logger.debug("tokens successfully obtained")

        self._token_cache.cache_tokens(tokens)
        token = tokens["access_token"]
        return token
