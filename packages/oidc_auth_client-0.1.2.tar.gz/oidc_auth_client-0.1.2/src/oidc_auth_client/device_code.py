from oidc_auth_client import (
    OidcProvider,
    TokenCache,
)
from oidc_auth_client.authentication_flow import AuthenticationFlow


class DeviceCode(AuthenticationFlow):
    def __init__(
        self,
        app_name: str,
        loglevel: str,
        oidc_provider: OidcProvider | None,
        token_cache: TokenCache | None,
    ) -> None:
        super().__init__(app_name, loglevel, oidc_provider, token_cache)
