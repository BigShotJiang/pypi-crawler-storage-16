from datetime import UTC, datetime
import json
from logging import Logger
import os
import platform
import sys
import time

from oidc_auth_client.oidc import TokenResponseBody


def ts(timestamp: float | int):
    dt_local = datetime.fromtimestamp(timestamp, tz=UTC).astimezone()
    return dt_local.isoformat()


class TokenCache:
    def __init__(self) -> None:
        self._logger = None
        self._initialized = False

    def set_logger(self, logger: Logger):
        self._logger = logger

    @property
    def logger(self):
        if self._logger is None:
            raise Exception("Logger is None, set_logger() must be called")

        return self._logger

    def initialize(self, client_id: str):
        system = platform.system()

        self.logger.debug(f"Selecting cache dir for system type '{system}'")

        if system == "Windows":
            base = os.environ.get("LOCALAPPDATA", os.path.expanduser("~"))
            self._user_cache_dir = os.path.join(
                base, "oidc-auth-client", client_id, "Cache"
            )
        elif system == "Darwin":
            self._user_cache_dir = os.path.expanduser(
                f"~/Library/Caches/oidc-auth-client/{client_id}"
            )
        else:  # Linux / BSD / others
            base = os.environ.get("XDG_CACHE_HOME", os.path.expanduser("~/.cache"))
            self._user_cache_dir = os.path.join(base, "oidc-auth-client", client_id)

        self.logger.debug(f"Selected cache dir '{self._user_cache_dir}'")
        self._initialized = True

    def _get_cache_file(self) -> str:
        cache_dir = self._user_cache_dir
        os.makedirs(cache_dir, exist_ok=True)
        return os.path.join(cache_dir, "token.json")

    def _get_pref_file(self) -> str:
        return os.path.join(self._user_cache_dir, ".preference")

    def _save_user_pref(self, pref: bool) -> None:
        with open(self._get_pref_file(), "w") as f:
            if pref:
                cache_enabled = True
            else:
                cache_enabled = False

            json.dump({"cache_enabled": cache_enabled}, f)

    def _load_user_pref(self) -> bool | None:
        try:
            with open(self._get_pref_file(), "r") as f:
                pref = json.load(f)
            return pref.get("cache_enabled")
        except FileNotFoundError:
            return None

    def _should_cache_tokens(self) -> bool:
        pref = self._load_user_pref()
        if pref is not None:
            return pref

        # Non-interactive environment (no TTY) → default: no caching
        if not sys.stdin.isatty():
            self.logger.warning(
                "No TTY available and no cache preference set; defaulting to NOT caching tokens."
            )
            return False

        # Interactive prompt
        print("\nDo you want to cache token locally? (y/n): ", end="", flush=True)
        answer = input().strip().lower()
        enabled = answer.startswith("y")

        print(
            "Do you want to remember this choice for next time? (y/n): ",
            end="",
            flush=True,
        )
        save_pref = input().strip().lower().startswith("y")

        if save_pref:
            self._save_user_pref(enabled)

        return enabled

    def cache_tokens(self, tokens: TokenResponseBody):
        if not self._initialized:
            raise Exception("Must be initialized first. call initialize()")
        if not self._should_cache_tokens():
            self.logger.debug("Token caching disabled by user.")
            return

        cache_file_path = self._get_cache_file()
        self.logger.debug(f"Caching tokens at file path: {cache_file_path}")

        tokens["expires_at"] = time.time() + tokens["expires_in"]

        with open(cache_file_path, "w") as f:
            json.dump(tokens, f)

        self.logger.debug(
            f"Successfully cached tokens. Expires at {ts(tokens['expires_at'])}"
        )

    def load_cached_token(self) -> str | None:
        try:
            cache_file_path = self._get_cache_file()
            self.logger.debug(
                f"Attempting to load tokens from cache. File path: {cache_file_path}"
            )
            with open(cache_file_path, "r") as f:
                tokens = json.load(f)

        except FileNotFoundError:
            self.logger.debug("Tokens not loaded from cache. File not found.")
            return None

        if tokens.get("expires_at", 0) > time.time():
            self.logger.debug(
                f"Tokens loaded from cache. Expires at: {ts(tokens['expires_at'])}"
            )
            return tokens["access_token"]

        self.logger.debug("Tokens not loaded from cache. Tokens expired.")
        return None
