import base64
import hashlib
import queue
import threading
from urllib.parse import parse_qs, unquote, urlencode, urlparse
from uuid import uuid4

import httpx
import pytest

from oidc_auth_client import Config
from oidc_auth_client import AuthorizationCode
from oidc_auth_client.errors import AuthError
from oidc_auth_client.oidc import (
    TokenResponseBody,
)
from oidc_auth_client.token_cache import TokenCache
from tests.mocks import MockOIDC


class TokenCacheAlwaysMiss(TokenCache):
    def __init__(self) -> None:
        self._tokens: TokenResponseBody | None = None

    def cache_tokens(self, tokens: TokenResponseBody) -> None:
        self._tokens = tokens

    def load_cached_token(self) -> str | None:
        return None


def test_authorization_code_happy_path_roundtrip():
    browser_params_queue = queue.Queue()

    captured = {}

    def mock_browser(url: str):
        url_path = _get_url(url)

        correct_code = str(uuid4())
        redirect_uri = _query_param(url, "redirect_uri")
        state = _query_param(url, "state")

        code_challenge = _query_param(url, "code_challenge")
        code_challenge_method = _query_param(url, "code_challenge_method")

        params = {"code": correct_code, "state": state}

        _send_callback(f"{redirect_uri}?{urlencode(params)}")

        browser_params_queue.put(
            {
                "url_path": url_path,
                "state": state,
                "correct_code": correct_code,
                "redirect_uri": redirect_uri,
                "code_challenge": code_challenge,
                "code_challenge_method": code_challenge_method,
            }
        )

        return True

    expected_auth_url = "http://authurllocalhost"

    def oidc_tokens(data: dict) -> TokenResponseBody:
        tokens_data = data

        captured["browser"] = browser_params_queue.get(timeout=3)

        assert "code_verifier" in tokens_data
        code_verifier = tokens_data["code_verifier"]
        assert isinstance(code_verifier, str)
        captured["code_verifier"] = code_verifier
        assert 43 <= len(code_verifier) <= 128

        assert all(
            c.isalnum() or c in "-._~" for c in code_verifier.replace("~", "")
        )  # unreserved chars

        assert "=" not in code_verifier

        expected_challenge = (
            base64.urlsafe_b64encode(
                hashlib.sha256(captured["code_verifier"].encode()).digest()
            )
            .rstrip(b"=")
            .decode()
        )

        assert captured["browser"]["code_challenge"] == expected_challenge
        assert captured["browser"]["code_challenge_method"] == "S256"

        assert "redirect_uri" in tokens_data
        assert captured["browser"]["redirect_uri"] == tokens_data["redirect_uri"]

        assert "code" in tokens_data
        assert tokens_data["code"] == captured["browser"]["correct_code"]

        return {"access_token": "MOCK_ACCESS_TOKEN", "expires_in": 600}

    access_token = AuthorizationCode(
        config=Config(
            client_id="CLIENT_ID",
            oidc_provider=MockOIDC(
                authorize_endpoint=lambda: expected_auth_url,
                tokens=oidc_tokens,
            ),
            token_cache=TokenCacheAlwaysMiss(),
        ),
        browser=mock_browser,
    ).get_token()

    assert access_token == "MOCK_ACCESS_TOKEN"
    assert captured["browser"]["url_path"] == expected_auth_url


def test_authorization_code_wrong_state():
    def mock_browser(url: str):
        valid_code = str(uuid4())
        redirect_uri = _query_param(url, "redirect_uri")

        params = {"code": valid_code, "state": "just-a-madeup-state!!!"}

        _send_callback(f"{redirect_uri}?{urlencode(params)}")

        return True

    def tokens(data: dict) -> TokenResponseBody:
        _ = data
        return {"access_token": "MOCK_ACCESS_TOKEN", "expires_in": 600}

    with pytest.raises(AuthError) as e:
        AuthorizationCode(
            config=Config(
                client_id="CLIENT_ID",
                oidc_provider=MockOIDC(
                    authorize_endpoint=lambda: "",
                    tokens=tokens,
                ),
                token_cache=TokenCacheAlwaysMiss(),
            ),
            browser=mock_browser,
        ).get_token()

    assert "Invalid state parameter" in str(e.value)


def test_authorization_code_missing():
    def mock_browser(url: str):
        redirect_uri = _query_param(url, "redirect_uri")

        state = _query_param(url, "state")

        # Code is missing in the params
        params = {"state": state}

        _send_callback(f"{redirect_uri}?{urlencode(params)}")
        return True

    def tokens(data: dict) -> TokenResponseBody:
        _ = data
        return {"access_token": "MOCK_ACCESS_TOKEN", "expires_in": 600}

    with pytest.raises(AuthError) as e:
        AuthorizationCode(
            config=Config(
                client_id="CLIENT_ID",
                oidc_provider=MockOIDC(
                    authorize_endpoint=lambda: "",
                    tokens=tokens,
                ),
                token_cache=TokenCacheAlwaysMiss(),
            ),
            browser=mock_browser,
        ).get_token()

    assert "Could not obtain code" in str(e.value)


def _get_url(url: str):
    parsed = urlparse(url)
    return f"{parsed.scheme}://{parsed.netloc}{parsed.path}"


def _query_param(url: str, param: str) -> str | None:
    parsed = urlparse(url)
    query_params = parse_qs(parsed.query)

    p = query_params.get(param, [None])[0]
    p = unquote(p) if p else None
    return p


def _send_callback(url: str):
    def send_callback():
        httpx.get(url)

    threading.Thread(target=send_callback, daemon=True).start()
