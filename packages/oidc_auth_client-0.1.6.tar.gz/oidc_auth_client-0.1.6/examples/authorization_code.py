import os
from oidc_auth_client import Config, AuthorizationCode, OidcProvider
from oidc_auth_client.token_cache import TokenCache


CLIENT_ID = os.getenv("CLIENT_ID")
OPENID_CONFIGURATION_URL = os.getenv("OPENID_CONFIGURATION_URL")

if not CLIENT_ID or not OPENID_CONFIGURATION_URL:
    raise Exception(
        "Required env vars CLIENT_ID and OPENID_CONFIGURATION_URL not supplied"
    )

config = Config(
    client_id=CLIENT_ID,
    oidc_provider=OidcProvider(openid_configuration_url=OPENID_CONFIGURATION_URL),
    token_cache=TokenCache(),
)

print(AuthorizationCode(config=config).get_token())
