import os
from oidc_auth_client import ClientCredentials, OidcProvider, TokenCache
from oidc_auth_client.client_credentials import ClientCredentialsConfig

CLIENT_ID = os.getenv("CLIENT_ID")
CLIENT_SECRET = os.getenv("CLIENT_SECRET")
OPENID_CONFIGURATION_URL = os.getenv("OPENID_CONFIGURATION_URL")

if not CLIENT_ID or not CLIENT_SECRET or not OPENID_CONFIGURATION_URL:
    raise Exception(
        "Required env vars CLIENT_ID, CLIENT_SECRET and OPENID_CONFIGURATION_URL not supplied"
    )

config = ClientCredentialsConfig(
    client_id=CLIENT_ID,
    client_secret=CLIENT_SECRET,
    oidc_provider=OidcProvider(openid_configuration_url=OPENID_CONFIGURATION_URL),
    token_cache=TokenCache(),
)

print(ClientCredentials(config=config).get_token())
