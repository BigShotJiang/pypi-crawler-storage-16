import base64
import hashlib
import html
import http.server
import os
import queue
import secrets
import socketserver
import sys
import textwrap
import time
import urllib.parse
import webbrowser
from enum import StrEnum
from typing import Callable

from oidc_auth_client.authentication_flow import (
    AuthenticationFlow,
    Config,
)
from oidc_auth_client.errors import AuthError
from oidc_auth_client.terminal_helpers import Terminal


class QueueResult(StrEnum):
    CALLBACK_RECEIVED = "CALLBACK_RECEIVED"
    CALLBACK_FAILED = "CALLBACK_FAILED"


def generate_pkce_pair():
    # RFC 7636: verifier must be 43–128 chars, unreserved URI characters
    code_verifier = (
        base64.urlsafe_b64encode(os.urandom(64)).rstrip(b"=").decode("utf-8")
    )

    # Compute SHA256 and base64url encode
    code_challenge = (
        base64.urlsafe_b64encode(hashlib.sha256(code_verifier.encode("utf-8")).digest())
        .rstrip(b"=")
        .decode("utf-8")
    )
    return code_verifier, code_challenge


class TCPServer(socketserver.TCPServer):
    # This is needed for the socket server to release the bind on the
    # port as soon as possible
    allow_reuse_address = True


def code_handler(
    client_id: str,
    expected_state: str,
    queue: queue.Queue[tuple[QueueResult, str]],
    logger,
):
    class CodeHandler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            query = urllib.parse.urlparse(self.path).query
            params = urllib.parse.parse_qs(query)
            code = params.get("code", [None])[0]

            error: str = params.get("error", [""])[0]

            if error != "":
                error += ". "
                keycloak_error_description = params.get("error_description", [""])[0]

                if keycloak_error_description != "":
                    error += keycloak_error_description + ". "

            if params.get("state", [None])[0] != expected_state:
                error += "Invalid state parameter. "

            if not code:
                error += "Could not obtain code for authorization. "

            if error != "":
                self.send_response(500)
                self.send_header("Content-type", "text/html")
                self.end_headers()
                self.wfile.write(
                    textwrap.dedent(f"""
                        <!DOCTYPE html>
                        <html lang="en">
                        <head>
                            <meta charset="utf-8">
                            <title>{html.escape(client_id)} Authentication</title>
                        </head>
                        <body>
                            <p>
                                {html.escape(error)}
                                You can close this tab.
                            </p>
                        </body>
                        </html>
                    """).encode("utf-8")
                )
                queue.put((QueueResult.CALLBACK_FAILED, error))
            else:
                self.send_response(200)
                self.send_header("Content-type", "text/html")
                self.end_headers()
                self.wfile.write(
                    textwrap.dedent(f"""
                        <!DOCTYPE html>
                        <html lang="en">
                        <head>
                            <meta charset="utf-8">
                            <title>{html.escape(client_id)} Authentication</title>
                        </head>
                        <body>
                            <p>
                                {html.escape(client_id)} authentication successful.
                                You can close this tab.
                            </p>
                        </body>
                        </html>
                    """).encode("utf-8")
                )

                assert code
                queue.put((QueueResult.CALLBACK_RECEIVED, code))

        def log_message(self, format, *args):
            _ = format, args
            logger.debug(
                f"CodeHandler: Callback received from {self.client_address[0]} with path {self.path}"
            )

    return CodeHandler


class AuthorizationCode(AuthenticationFlow):
    def __init__(
        self,
        config: Config,
        timeout: int = 300,  # Seconds
        browser: Callable[[str], bool] = webbrowser.open_new_tab,
    ) -> None:
        """
        Authorization code flow will open your browser so you
        can sign in with your personal credentials or configured SSO.
        """
        self._timeout = timeout
        self._browser = browser
        self._result_queue: queue.Queue[tuple[QueueResult, str]] = queue.Queue()

        super().__init__(config)

    def get_token(self) -> str:
        if self._token_cache is not None:
            token: str | None = self._token_cache.load_cached_token()
            if token is not None:
                return token

        token = ""

        state = base64.urlsafe_b64encode(secrets.token_bytes(16)).rstrip(b"=").decode()

        try:
            with TCPServer(
                ("localhost", 0),
                code_handler(
                    self._config.client_id, state, self._result_queue, self._logger
                ),
            ) as httpd:
                # TCP Server with port 0 lets the os allocate a free port
                # Here we find which port it picked
                port = httpd.server_address[1]

                code_verifier, code_challenge = generate_pkce_pair()

                redirect_url = f"http://localhost:{port}"

                params = urllib.parse.urlencode(
                    {
                        "client_id": self._config.client_id,
                        "redirect_uri": redirect_url,
                        "response_type": "code",
                        "scope": "email",
                        "code_challenge": code_challenge,
                        "code_challenge_method": "S256",
                        "state": state,
                    }
                )

                authorize_url = f"{self._oidc_provider.authorize_endpoint()}?{params}"

                self._browser(authorize_url)
                self._logger.info(
                    "Please complete the authentication in your browser: "
                    f"{Terminal.link(authorize_url, authorize_url)}"
                )
                self._logger.debug(f"Waiting for callback on {redirect_url} ...")

                # Stop listening every second to unblock
                httpd.timeout = 1

                # Listen until timeout
                start, elapsed = time.time(), 0

                while elapsed <= self._timeout:
                    httpd.handle_request()

                    try:
                        status, message = self._result_queue.get_nowait()

                        if status == QueueResult.CALLBACK_FAILED:
                            raise AuthError(message)

                        elif status == QueueResult.CALLBACK_RECEIVED:
                            auth_code = message

                            self._logger.debug("using code to get tokens...")
                            tokens = self._oidc_provider.tokens(
                                # self._tokens_url,
                                data={
                                    "grant_type": "authorization_code",
                                    "code": auth_code,
                                    "redirect_uri": redirect_url,
                                    "client_id": self._config.client_id,
                                    "code_verifier": code_verifier,
                                },
                            )
                            self._logger.debug("tokens successfully obtained")

                            if self._token_cache is not None:
                                self._token_cache.cache_tokens(tokens)
                            token = tokens["access_token"]
                            break

                    except queue.Empty:
                        pass

                    elapsed = time.time() - start
                    if int(elapsed) % 5 == 0:  # log every 5s
                        self._logger.debug(f"Still waiting... {int(elapsed)}s elapsed")

        except AuthError as e:
            self._logger.error(Terminal.color(str(e), "red"))
            raise e

        except KeyboardInterrupt:
            print("\nInterrupted by keyboard. Terminating process with status code 1.")
            sys.exit(1)

        if not token or token == "":
            raise AuthError("Failed to get token")

        return token
