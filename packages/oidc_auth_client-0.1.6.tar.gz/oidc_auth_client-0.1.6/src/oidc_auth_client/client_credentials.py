from dataclasses import dataclass
from oidc_auth_client.authentication_flow import AuthenticationFlow, Config


@dataclass(frozen=True, kw_only=True)
class ClientCredentialsConfig(Config):
    client_secret: str


class ClientCredentials(AuthenticationFlow):
    def __init__(
        self,
        config: ClientCredentialsConfig,
    ) -> None:
        self._client_secret = config.client_secret
        super().__init__(config)

    def get_token(self) -> str:
        if self._token_cache is not None:
            token: str | None = self._token_cache.load_cached_token()
            if token is not None:
                return token

        tokens = self._oidc_provider.tokens(
            data={
                "grant_type": "client_credentials",
                "client_id": self._config.client_id,
                "client_secret": self._client_secret,
            },
        )

        self._logger.debug("tokens successfully obtained")

        if self._token_cache is not None:
            self._token_cache.cache_tokens(tokens)

        token = tokens["access_token"]
        return token
