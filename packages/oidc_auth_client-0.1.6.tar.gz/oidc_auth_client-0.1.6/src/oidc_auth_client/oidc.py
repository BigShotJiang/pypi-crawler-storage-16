from logging import Logger
from typing import NotRequired, TypedDict

import httpx

from oidc_auth_client.errors import AuthError


class TokenResponseBody(TypedDict):
    access_token: str
    expires_in: int
    refresh_expires_in: NotRequired[int]
    refresh_token: NotRequired[str]
    expires_at: NotRequired[float]


class DeviceAuthorizationResponseBody(TypedDict):
    device_code: str
    user_code: str
    verification_uri_complete: str
    interval: NotRequired[int]


class OidcProvider:
    def __init__(
        self,
        openid_configuration_url: str,
    ) -> None:
        try:
            response = httpx.get(openid_configuration_url)
            response.raise_for_status()
        except Exception:
            raise Exception(
                f"An error occured when getting the openid configuration. Are you sure that the authentication provider is available? ({openid_configuration_url})"
            )

        self._openid_config = response.json()
        self._logger = None

    def set_logger(self, logger: Logger):
        self._logger = logger

    @property
    def logger(self):
        if self._logger is None:
            raise Exception("Logger not set")

        return self._logger

    def authorize_endpoint(self):
        return self._openid_config["authorization_endpoint"]

    def device_authorization(self, client_id: str) -> DeviceAuthorizationResponseBody:
        self.logger.debug("Getting device code using device_authorization_endpoint...")
        response = httpx.post(
            self._openid_config["device_authorization_endpoint"],
            data={"client_id": client_id},
        )
        try:
            response.raise_for_status()
        except Exception as e:
            try:
                self.logger.debug(f"json response: {response.json()}")
            except Exception:
                pass

            self.logger.error(e)
            raise AuthError("An error occured when fetching token")

        device_code_data: DeviceAuthorizationResponseBody = response.json()
        return device_code_data

    def tokens(self, data: dict) -> TokenResponseBody:
        self.logger.debug("using code to get tokens...")
        token_response = httpx.post(
            self._openid_config["token_endpoint"],
            data=data,
        )

        try:
            token_response.raise_for_status()
        except Exception as e:
            try:
                self.logger.debug(f"json response: {token_response.json()}")
            except Exception:
                pass

            self.logger.error(e)
            raise AuthError("An error occured when fetching token")

        tokens: TokenResponseBody = token_response.json()
        return tokens
