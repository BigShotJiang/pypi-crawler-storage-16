from typing import Any, Callable
from oidc_auth_client.oidc import (
    DeviceAuthorizationResponseBody,
    OidcProvider,
    TokenResponseBody,
)


class MockOIDC(OidcProvider):
    def __init__(
        self,
        authorize_endpoint: Callable[[], str] | None = None,
        tokens: Callable[[dict], TokenResponseBody] | None = None,
        device_authorization: Callable[[str], DeviceAuthorizationResponseBody]
        | None = None,
    ) -> None:
        def not_implemented(*args, **kwargs) -> Any:
            _ = args, kwargs
            raise NotImplementedError()

        if authorize_endpoint is None:
            self._authorize_endpoint = not_implemented
        else:
            self._authorize_endpoint = authorize_endpoint

        if tokens is None:
            self._tokens = not_implemented
        else:
            self._tokens = tokens

        if device_authorization is None:
            self._device_authorization = not_implemented
        else:
            self._device_authorization = device_authorization

    def authorize_endpoint(self) -> str:
        return self._authorize_endpoint()

    def tokens(self, data: dict) -> TokenResponseBody:
        return self._tokens(data)

    def device_authorization(self, client_id: str) -> DeviceAuthorizationResponseBody:
        return self._device_authorization(client_id)
