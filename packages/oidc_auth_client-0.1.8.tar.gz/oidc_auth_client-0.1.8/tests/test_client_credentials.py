from oidc_auth_client import ClientCredentials
from oidc_auth_client.client_credentials import ClientCredentialsConfig
from oidc_auth_client.oidc import TokenResponseBody
from tests.mocks import MockOIDC


def test_client_credentials_happypath():
    expected_client_id = "EXPECTED_CLIENT_ID"
    expected_client_secret = "EXPECTED_CLIENT_SECRET"
    expected_access_token = "MOCK_ACCESS_TOKEN"

    def tokens(data: dict) -> TokenResponseBody:
        actual_client_id = data["client_id"]
        actual_client_secret = data["client_secret"]

        assert expected_client_id == actual_client_id
        assert expected_client_secret == actual_client_secret

        return {"access_token": expected_access_token, "expires_in": 600}

    actual_access_token = ClientCredentials(
        config=ClientCredentialsConfig(
            client_id=expected_client_id,
            client_secret=expected_client_secret,
            oidc_provider=MockOIDC(tokens=tokens),
        ),
    ).get_token()

    assert expected_access_token == actual_access_token
