
"""Инициализация пакета oidc"""

from .__version__ import __version__
__author__ = "Alex KingKisses"
__email__ = "lime2109@mail.ru"

from .oidc import CreateOIDCClient

__all__ = ["CreateOIDCClient"]