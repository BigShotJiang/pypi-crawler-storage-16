# Real Environment Tests for fetchModelList

This directory contains real environment tests that make actual API calls to external services.

## Overview

These tests verify that the fetchModelList module works correctly with real API endpoints. Unlike unit tests that mock responses, these tests:
- Make actual HTTP requests to provider APIs
- Require valid API keys (for some providers)
- Require internet connection
- Are skipped by default to avoid accidental API calls

## Test Files

- `test_openrouter_real.py` - Tests OpenRouter API (requires `OPENROUTER_API_KEY`)
- `test_siliconflow_real.py` - Tests SiliconFlow API (requires `SILICONFLOW_API_KEY`)
- `test_iflow_real.py` - Tests IFlow API (requires `IFLOW_API_KEY`)
- `test_modelscope_real.py` - Tests ModelScope API (no API key required)
- `test_zhipu_real.py` - Tests Zhipu website scraping (no API key required)
- `test_all_providers_real.py` - Comprehensive test of all available providers

## Running Tests

### 1. Set Environment Variables

For providers requiring API keys:

```bash
# Windows
set OPENROUTER_API_KEY=your_key_here
set SILICONFLOW_API_KEY=your_key_here
set IFLOW_API_KEY=your_key_here

# Enable real environment tests
set RUN_REAL_ENV_TESTS=true
```

### 2. Run Specific Tests

```bash
# Run all real environment tests
pytest tests/fetchModelList/realEnvTest/ -v

# Run tests for a specific provider
pytest tests/fetchModelList/realEnvTest/test_openrouter_real.py -v

# Run tests without API keys (will skip tests requiring keys)
pytest tests/fetchModelList/realEnvTest/test_modelscope_real.py -v
pytest tests/fetchModelList/realEnvTest/test_zhipu_real.py -v
```

### 3. Run with Coverage

```bash
pytest tests/fetchModelList/realEnvTest/ --cov=oiiai.fetchModelList -v
```

## Test Behavior

- Tests are **skipped by default** unless `RUN_REAL_ENV_TESTS=true`
- Tests requiring API keys are skipped if the corresponding environment variable is not set
- Tests include timeouts (default 30 seconds) to prevent hanging
- Results are printed to console for debugging

## Expected Results

- **Zhipu**: Returns a dictionary of model categories with lists of model names
- **ModelScope**: Returns a list of model names
- **OpenRouter**: Returns a list of model IDs
- **SiliconFlow**: Returns a list of model IDs
- **IFlow**: Returns a list of model names

## Notes

1. These tests may fail due to:
   - Network connectivity issues
   - API rate limiting
   - Changes in provider API responses
   - Invalid or expired API keys

2. For CI/CD pipelines:
   - Consider running these tests only in specific environments
   - Use dedicated test API keys with rate limits
   - Monitor for API changes that may break tests

3. The `test_all_providers_real.py` test requires at least 2 providers to succeed to pass.