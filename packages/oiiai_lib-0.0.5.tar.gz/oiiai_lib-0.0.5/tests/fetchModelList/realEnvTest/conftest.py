"""
Pytest configuration for real environment tests.
"""

import os
import pytest


def pytest_addoption(parser):
    """Add command line options for real environment tests."""
    parser.addoption(
        "--run-real",
        action="store_true",
        default=False,
        help="Run real environment tests (requires API keys)",
    )


def pytest_configure(config):
    """Configure pytest based on options."""
    # Set environment variable if --run-real is used
    if config.getoption("--run-real"):
        os.environ["RUN_REAL_ENV_TESTS"] = "true"


def pytest_collection_modifyitems(config, items):
    """Modify test collection based on options."""
    if not config.getoption("--run-real"):
        # Skip real environment tests unless --run-real is specified
        skip_real = pytest.mark.skip(reason="Need --run-real option to run")
        for item in items:
            if "realEnvTest" in str(item.fspath):
                item.add_marker(skip_real)