#!/usr/bin/env python3
"""
简单捕获Nova原始输出脚本
"""

import os
import json
import sys
import requests
from datetime import datetime
from pathlib import Path

# 添加项目根目录到Python路径
project_root = Path(__file__).parent.parent.parent.parent.parent
sys.path.insert(0, str(project_root))

from oiiai import FetchNova


def main():
    api_key = os.getenv("NOVA_API_KEY")
    if not api_key:
        print("❌ NOVA_API_KEY未设置")
        return 1
    
    output_dir = Path(__file__).parent
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # 官方API原始输出
    print("获取官方API原始输出...")
    try:
        response = requests.get(
            "https://api.nova.amazon.com/v1/models",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=30
        )
        response.raise_for_status()
        official_data = response.json()
        
        with open(output_dir / f"nova_official_{timestamp}.json", 'w') as f:
            json.dump(official_data, f, indent=2)
        print(f"✅ 官方API原始输出已保存")
    except Exception as e:
        print(f"❌ 官方API失败: {e}")
        return 1
    
    # 我们的实现输出 (fetch_models返回List[str])
    print("获取FetchNova输出...")
    try:
        fetcher = FetchNova(api_key=api_key)
        impl_data = fetcher.fetch_models()
        
        with open(output_dir / f"nova_implementation_{timestamp}.json", 'w') as f:
            json.dump(impl_data, f, indent=2)
        print(f"✅ FetchNova输出已保存")
    except Exception as e:
        print(f"❌ FetchNova失败: {e}")
        return 1
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
