#!/usr/bin/env python3
"""
Nova API 原始输出对比测试脚本

这个脚本会：
1. 调用我们的FetchNova实现获取模型列表
2. 直接调用Nova官方API获取原始响应
3. 对比两者的输出，确保我们的实现正确处理了API响应

使用方法：
1. 设置环境变量：
   set NOVA_API_KEY=your_key

2. 运行脚本：
   python test_nova_comparison.py
"""

import os
import json
import sys
import requests
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any

# 添加项目根目录到Python路径
project_root = Path(__file__).parent.parent.parent.parent.parent
sys.path.insert(0, str(project_root))

from oiiai import FetchNova


class NovaComparisonTester:
    """Nova API对比测试器"""
    
    NOVA_API_URL = "https://api.nova.amazon.com/v1/models"
    
    def __init__(self, api_key: str = None):
        """初始化测试器"""
        self.api_key = api_key or os.getenv("NOVA_API_KEY", "")
        self.results = {
            "timestamp": datetime.now().isoformat(),
            "api_key_provided": bool(self.api_key),
            "tests": {}
        }
    
    def test_official_api(self) -> Dict[str, Any]:
        """直接调用官方Nova API获取原始响应"""
        print("\n🔍 测试1: 直接调用官方Nova API...")
        
        if not self.api_key:
            print("  ❌ 未提供API密钥，跳过官方API测试")
            return {"error": "API_KEY_NOT_PROVIDED", "status": "skipped"}
        
        try:
            headers = {"Authorization": f"Bearer {self.api_key}"}
            response = requests.get(
                self.NOVA_API_URL,
                headers=headers,
                timeout=30
            )
            
            result = {
                "status_code": response.status_code,
                "headers": dict(response.headers),
                "success": response.status_code == 200
            }
            
            if response.status_code == 200:
                data = response.json()
                result["data"] = data
                result["data_structure"] = {
                    "has_object": "object" in data,
                    "has_data_array": "data" in data and isinstance(data.get("data"), list),
                    "data_array_length": len(data.get("data", [])),
                    "sample_item": data.get("data", [{}])[0] if data.get("data") else None
                }
                print(f"  ✅ 官方API调用成功")
                print(f"     - 状态码: {response.status_code}")
                print(f"     - 模型数量: {result['data_structure']['data_array_length']}")
            else:
                result["error"] = response.text[:200]
                print(f"  ❌ 官方API返回错误: {response.status_code}")
            
            return result
        except requests.exceptions.RequestException as e:
            print(f"  ❌ 官方API调用失败: {e}")
            return {"error": str(e), "status": "failed"}
    
    def test_our_implementation(self) -> Dict[str, Any]:
        """测试我们的FetchNova实现"""
        print("\n🔍 测试2: 测试FetchNova实现...")
        
        if not self.api_key:
            print("  ❌ 未提供API密钥，跳过实现测试")
            return {"error": "API_KEY_NOT_PROVIDED", "status": "skipped"}
        
        try:
            fetcher = FetchNova(api_key=self.api_key)
            
            # 测试fetch_models()
            print("  📋 调用fetch_models()...")
            models = fetcher.fetch_models()
            
            # 测试fetch_models_raw()
            print("  📋 调用fetch_models_raw()...")
            raw_response = fetcher.fetch_models_raw()
            
            result = {
                "success": True,
                "fetch_models": {
                    "type": type(models).__name__,
                    "length": len(models) if isinstance(models, list) else "N/A",
                    "sample": models[:3] if isinstance(models, list) else None
                },
                "fetch_models_raw": {
                    "type": type(raw_response).__name__,
                    "has_object": "object" in raw_response if isinstance(raw_response, dict) else False,
                    "has_data": "data" in raw_response if isinstance(raw_response, dict) else False,
                    "data_length": len(raw_response.get("data", [])) if isinstance(raw_response, dict) else "N/A"
                }
            }
            
            print(f"  ✅ FetchNova实现测试成功")
            print(f"     - fetch_models()返回{result['fetch_models']['length']}个模型")
            print(f"     - fetch_models_raw()返回原始响应")
            
            return result
        except Exception as e:
            print(f"  ❌ FetchNova实现测试失败: {e}")
            import traceback
            traceback.print_exc()
            return {"error": str(e), "status": "failed"}
    
    def compare_results(self, official: Dict, implementation: Dict) -> Dict[str, Any]:
        """对比官方API和我们的实现"""
        print("\n🔍 测试3: 对比官方API和实现...")
        
        comparison = {
            "official_success": official.get("success", False),
            "implementation_success": implementation.get("success", False),
            "checks": {}
        }
        
        # 检查1: 模型数量一致性
        if (official.get("success") and implementation.get("success")):
            official_count = official.get("data_structure", {}).get("data_array_length", 0)
            impl_count = implementation.get("fetch_models", {}).get("length", 0)
            
            check = {
                "official_count": official_count,
                "implementation_count": impl_count,
                "match": official_count == impl_count
            }
            comparison["checks"]["model_count_consistency"] = check
            
            if check["match"]:
                print(f"  ✅ 模型数量一致: {official_count} == {impl_count}")
            else:
                print(f"  ⚠️  模型数量不一致: {official_count} != {impl_count}")
        
        # 检查2: 数据结构一致性
        if official.get("success"):
            has_object = official.get("data_structure", {}).get("has_object", False)
            has_data = official.get("data_structure", {}).get("has_data_array", False)
            
            check = {
                "has_object_field": has_object,
                "has_data_array": has_data,
                "structure_valid": has_object and has_data
            }
            comparison["checks"]["data_structure"] = check
            
            if check["structure_valid"]:
                print(f"  ✅ 数据结构有效: 包含object和data字段")
            else:
                print(f"  ❌ 数据结构无效")
        
        # 检查3: 原始响应保留
        if (official.get("success") and implementation.get("success")):
            impl_has_data = implementation.get("fetch_models_raw", {}).get("has_data", False)
            
            check = {
                "raw_response_preserved": impl_has_data,
                "status": "✅ 原始响应已保留" if impl_has_data else "❌ 原始响应未保留"
            }
            comparison["checks"]["raw_response_preservation"] = check
            print(f"  {check['status']}")
        
        return comparison
    
    def save_results(self, official: Dict, implementation: Dict, comparison: Dict):
        """保存测试结果到文件"""
        output_dir = Path(__file__).parent
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # 保存官方API响应
        official_file = output_dir / f"nova_official_raw_{timestamp}.json"
        with open(official_file, 'w', encoding='utf-8') as f:
            json.dump({
                "provider": "nova_official",
                "timestamp": timestamp,
                "metadata": {"note": "官方Nova API原始响应"},
                "raw_data": official
            }, f, ensure_ascii=False, indent=2)
        print(f"\n📁 官方API响应已保存: {official_file.name}")
        
        # 保存我们的实现响应
        impl_file = output_dir / f"nova_implementation_raw_{timestamp}.json"
        with open(impl_file, 'w', encoding='utf-8') as f:
            json.dump({
                "provider": "nova_implementation",
                "timestamp": timestamp,
                "metadata": {"note": "FetchNova实现的响应"},
                "raw_data": implementation
            }, f, ensure_ascii=False, indent=2)
        print(f"📁 实现响应已保存: {impl_file.name}")
        
        # 保存对比结果
        comparison_file = output_dir / f"nova_comparison_{timestamp}.json"
        with open(comparison_file, 'w', encoding='utf-8') as f:
            json.dump({
                "timestamp": timestamp,
                "official": official,
                "implementation": implementation,
                "comparison": comparison
            }, f, ensure_ascii=False, indent=2)
        print(f"📁 对比结果已保存: {comparison_file.name}")
    
    def run(self):
        """运行所有测试"""
        print("=" * 70)
        print("Nova API 原始输出对比测试")
        print("=" * 70)
        
        # 检查API密钥
        if not self.api_key:
            print("\n⚠️  警告: 未设置NOVA_API_KEY环境变量")
            print("   请设置环境变量后重新运行此脚本")
            print("   set NOVA_API_KEY=your_key")
            return False
        
        print(f"\n✅ 已检测到API密钥")
        
        # 运行测试
        official = self.test_official_api()
        implementation = self.test_our_implementation()
        comparison = self.compare_results(official, implementation)
        
        # 保存结果
        self.save_results(official, implementation, comparison)
        
        # 汇总
        print("\n" + "=" * 70)
        print("测试汇总")
        print("=" * 70)
        
        if official.get("success") and implementation.get("success"):
            print("\n✅ 所有测试通过！")
            print(f"   - 官方API: ✅ 成功")
            print(f"   - 我们的实现: ✅ 成功")
            print(f"   - 对比结果: ✅ 通过")
            return True
        else:
            print("\n❌ 部分测试失败")
            if not official.get("success"):
                print(f"   - 官方API: ❌ 失败 ({official.get('error', 'Unknown error')})")
            if not implementation.get("success"):
                print(f"   - 我们的实现: ❌ 失败 ({implementation.get('error', 'Unknown error')})")
            return False


def main():
    """主函数"""
    api_key = os.getenv("NOVA_API_KEY")
    
    tester = NovaComparisonTester(api_key=api_key)
    success = tester.run()
    
    return 0 if success else 1


if __name__ == "__main__":
    try:
        exit_code = main()
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\n\n⚠️  用户中断操作")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ 脚本执行出错: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
