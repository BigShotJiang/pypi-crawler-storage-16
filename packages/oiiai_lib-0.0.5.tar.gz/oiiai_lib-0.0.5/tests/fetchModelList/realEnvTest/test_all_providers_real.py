"""
Comprehensive real environment tests for all providers.
"""

import os
import pytest
from oiiai import (
    FetchZhipu,
    FetchOpenRouter,
    FetchModelScope,
    FetchSiliconFlow,
    FetchIFlow,
)


class TestAllProvidersReal:
    """Test all providers in one go."""
    
    @pytest.fixture
    def providers(self):
        """Create all provider instances."""
        providers = []
        
        # Zhipu - no API key needed
        providers.append(("Zhipu", FetchZhipu()))
        
        # ModelScope - no API key needed
        providers.append(("ModelScope", FetchModelScope()))
        
        # OpenRouter - requires API key
        openrouter_key = os.getenv("OPENROUTER_API_KEY")
        if openrouter_key:
            providers.append(("OpenRouter", FetchOpenRouter(api_key=openrouter_key)))
        
        # SiliconFlow - requires API key
        siliconflow_key = os.getenv("SILICONFLOW_API_KEY")
        if siliconflow_key:
            providers.append(("SiliconFlow", FetchSiliconFlow()))
        
        # IFlow - requires API key
        iflow_key = os.getenv("IFLOW_API_KEY")
        if iflow_key:
            providers.append(("IFlow", FetchIFlow()))
        
        return providers
    
    def test_all_providers(self, providers):
        """Test all available providers."""
        results = {}
        
        for name, fetcher in providers:
            try:
                models = fetcher.fetch_models(timeout=30)
                
                # Validate results
                if isinstance(models, dict):  # Zhipu returns dict
                    assert len(models) > 0
                    model_count = sum(len(v) for v in models.values())
                else:  # Others return list
                    assert isinstance(models, list)
                    assert len(models) > 0
                    model_count = len(models)
                
                results[name] = {
                    "success": True,
                    "model_count": model_count,
                    "sample": models[:3] if isinstance(models, list) else list(models.keys())[:3]
                }
                
                print(f"{name}: ✓ {model_count} models")
                
            except Exception as e:
                results[name] = {
                    "success": False,
                    "error": str(e)
                }
                print(f"{name}: ✗ {str(e)}")
        
        # Summary
        print(f"\nSummary: {len([r for r in results.values() if r['success']])}/{len(results)} providers successful")
        
        # At least some providers should work
        successful = [r for r in results.values() if r['success']]
        assert len(successful) >= 2, f"Expected at least 2 providers to work, got {len(successful)}"
    
    def test_provider_consistency(self):
        """Test that providers return consistent data types."""
        # Test Zhipu returns dict
        zhipu = FetchZhipu()
        zhipu_result = zhipu.fetch_models()
        assert isinstance(zhipu_result, dict)
        
        # Test ModelScope returns list
        modelscope = FetchModelScope()
        modelscope_result = modelscope.fetch_models()
        assert isinstance(modelscope_result, list)