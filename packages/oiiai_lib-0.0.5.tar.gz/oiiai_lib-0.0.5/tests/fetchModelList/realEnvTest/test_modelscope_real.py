"""
Real environment tests for ModelScope API.
No API key required.
"""

import pytest
from oiiai import FetchModelScope


class TestModelScopeReal:
    """Real environment tests for ModelScope API."""
    
    @pytest.fixture
    def fetcher(self):
        """Create fetcher instance."""
        return FetchModelScope()
    
    def test_fetch_models_real(self, fetcher):
        """Test fetching models from ModelScope API."""
        models = fetcher.fetch_models()
        
        # Basic validation
        assert isinstance(models, list)
        assert len(models) > 0
        
        # Check model format
        for model in models:
            assert isinstance(model, str)
            assert len(model) > 0
        
        # Log results
        print(f"ModelScope: Found {len(models)} models")
        print(f"Sample models: {models[:5]}")
    
    def test_fetch_models_with_timeout(self, fetcher):
        """Test fetching models with timeout."""
        models = fetcher.fetch_models(timeout=30)
        
        assert isinstance(models, list)
        assert len(models) > 0