"""
Real environment tests for OpenRouter API.
Requires OPENROUTER_API_KEY environment variable.
"""

import os
import pytest
from oiiai import FetchOpenRouter


class TestOpenRouterReal:
    """Real environment tests for OpenRouter API."""
    
    @pytest.fixture
    def api_key(self):
        """Get API key from environment."""
        key = os.getenv("OPENROUTER_API_KEY")
        if not key:
            pytest.skip("OPENROUTER_API_KEY environment variable not set")
        return key
    
    @pytest.fixture
    def fetcher(self, api_key):
        """Create fetcher instance."""
        return FetchOpenRouter(api_key=api_key)
    
    def test_fetch_models_real(self, fetcher):
        """Test fetching models from OpenRouter API."""
        models = fetcher.fetch_models()
        
        # Basic validation
        assert isinstance(models, list)
        assert len(models) > 0
        
        # Check model format
        for model in models:
            assert isinstance(model, str)
            assert len(model) > 0
        
        # Log results
        print(f"OpenRouter: Found {len(models)} models")
        print(f"Sample models: {models[:5]}")
    
    def test_fetch_models_with_timeout(self, fetcher):
        """Test fetching models with timeout."""
        models = fetcher.fetch_models(timeout=30)
        
        assert isinstance(models, list)
        assert len(models) > 0