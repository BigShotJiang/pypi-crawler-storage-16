"""
Real environment tests for SiliconFlow API.
Requires SILICONFLOW_API_KEY environment variable.
"""

import os
import pytest
from oiiai import FetchSiliconFlow


class TestSiliconFlowReal:
    """Real environment tests for SiliconFlow API."""
    
    @pytest.fixture
    def api_key(self):
        """Get API key from environment."""
        key = os.getenv("SILICONFLOW_API_KEY")
        if not key:
            pytest.skip("SILICONFLOW_API_KEY environment variable not set")
        return key
    
    @pytest.fixture
    def fetcher(self):
        """Create fetcher instance (reads from environment)."""
        return FetchSiliconFlow()
    
    def test_fetch_models_real(self, fetcher):
        """Test fetching models from SiliconFlow API."""
        models = fetcher.fetch_models()
        
        # Basic validation
        assert isinstance(models, list)
        assert len(models) > 0
        
        # Check model format
        for model in models:
            assert isinstance(model, str)
            assert len(model) > 0
        
        # Log results
        print(f"SiliconFlow: Found {len(models)} models")
        print(f"Sample models: {models[:5]}")
    
    def test_environment_variable_used(self, api_key, fetcher):
        """Verify that environment variable is being used."""
        # The fetcher should use the environment variable
        models = fetcher.fetch_models()
        assert len(models) > 0