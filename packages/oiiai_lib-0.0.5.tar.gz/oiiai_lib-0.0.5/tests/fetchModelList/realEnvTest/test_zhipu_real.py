"""
Real environment tests for Zhipu API.
No API key required for model list fetching.
"""

import pytest
from oiiai import FetchZhipu


class TestZhipuReal:
    """Real environment tests for Zhipu API."""
    
    @pytest.fixture
    def fetcher(self):
        """Create fetcher instance."""
        return FetchZhipu()
    
    def test_fetch_models_real(self, fetcher):
        """Test fetching models from Zhipu website."""
        models = fetcher.fetch_models()
        
        # Basic validation - now returns List[str] like other providers
        assert isinstance(models, list)
        assert len(models) > 0
        
        # Check all items are non-empty strings
        for model in models:
            assert isinstance(model, str)
            assert len(model) > 0
        
        # Log results
        print(f"Zhipu: Found {len(models)} models")
        print(f"  Sample: {models[:5]}")
    
    def test_extract_model_names(self, fetcher):
        """Test HTML parsing functionality."""
        # This is more of a unit test, but included for completeness
        html = """
        <h2 id="通用模型"></h2>
        <table>
          <tbody>
            <tr><td>glm-4</td></tr>
            <tr><td>glm-4-flash</td></tr>
          </tbody>
        </table>
        """
        
        result = fetcher._extract_model_names(html)
        assert "通用模型" in result
        assert result["通用模型"] == ["glm-4", "glm-4-flash"]