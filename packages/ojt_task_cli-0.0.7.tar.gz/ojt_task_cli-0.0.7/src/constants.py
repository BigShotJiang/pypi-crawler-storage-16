# Task Priorities
PRIORITY_LOW = "Low"
PRIORITY_MEDIUM = "Medium"
PRIORITY_HIGH = "High"

# Task Statuses
STATUS_PENDING = "pending"
STATUS_DONE = "done"

# Recurrence Patterns
RECURRENCE_DAILY = "daily"
RECURRENCE_WEEKLY = "weekly"
RECURRENCE_MONTHLY = "monthly"
