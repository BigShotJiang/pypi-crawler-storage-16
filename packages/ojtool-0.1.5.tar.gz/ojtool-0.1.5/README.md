## ojtool

Online Judge Test Data Generator made by Python.