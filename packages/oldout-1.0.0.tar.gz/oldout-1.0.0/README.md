# old-stdout
**@readwithai** - [X](https://x.com/readwithai) - [blog](https://readwithai.substack.com/) - [machine-aided reading](https://www.reddit.com/r/machineAidedReading/) - [📖](https://readwithai.substack.com/p/what-is-reading-broadly-defined
)[⚡️](https://readwithai.substack.com/s/technical-miscellany)[🖋️](https://readwithai.substack.com/p/note-taking-with-obsidian-much-of)

Get the old output from shell commands, if you use tmux.

This is vibe-coded but will become less so over time.

## Motivation
It is quite natural to want to do thigns with the output of a command that you just run without having to rerun. If you have programmatic access to your shell scrollback, by using tmux this allows you to get output.

## Alternatives and prior work
You could collect the outputs of previous commands into files using `tee`.

You could use something like jupyter which matains history.


## Usage
Use tmux.

* `oldout` will show the output of the previous command.
* `oldout 2` shows you the output from the penultimate command (etc).
* `outdiff` shows the difference between the last two outputs


You can use `--command` with oldout to include the command.

## About me
I am **@readwithai**. I create tools for reading, research and agency sometimes using the markdown editor [Obsidian](https://readwithai.substack.com/p/what-exactly-is-obsidian).

I also create a [stream of tools](https://readwithai.substack.com/p/my-productivity-tools) that are related to carrying out my work.

I write about lots of things - including tools like this - on [X](https://x.com/readwithai).
My [blog](https://readwithai.substack.com/) is more about reading and research and agency.
