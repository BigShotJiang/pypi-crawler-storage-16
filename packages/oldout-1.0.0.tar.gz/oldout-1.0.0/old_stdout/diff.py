#!/usr/bin/env python3
"""
olddiff - Compare outputs of two previous shell commands

This tool uses oldout to compare the outputs of two different
commands from your tmux history.
"""

import argparse
import subprocess
import sys
import tempfile
import os

from .tmux import get_command_output, get_command_preview


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description='Compare outputs of two previous shell commands',
        epilog="""
Examples:
  olddiff              # Compare last two commands (1 vs 2)
  olddiff 1 3          # Compare 1st and 3rd most recent commands
  olddiff --side-by-side 1 2  # Show side-by-side comparison
  olddiff --context 5 1 2     # Show 5 lines of context around changes
        """,
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument(
        'cmd1', 
        type=int, 
        nargs='?', 
        default=2,
        help='First command number (default: 2)'
    )
    
    parser.add_argument(
        'cmd2', 
        type=int, 
        nargs='?', 
        default=1,
        help='Second command number (default: 1)'
    )
    
    parser.add_argument(
        '--side-by-side', '-y',
        action='store_true',
        help='Show side-by-side comparison'
    )
    
    parser.add_argument(
        '--context', '-c',
        type=int,
        metavar='NUM',
        help='Show NUM lines of context around changes'
    )
    
    parser.add_argument(
        '--unified', '-u',
        action='store_true',
        default=True,
        help='Show unified diff (default)'
    )
    
    parser.add_argument(
        '--no-color',
        action='store_true',
        help='Disable colored output'
    )
    
    parser.add_argument(
        '--version',
        action='version',
        version='olddiff 1.0.0'
    )
    
    args = parser.parse_args()
    
    # Get outputs from both commands
    try:
        print(f"Comparing command {args.cmd1} vs command {args.cmd2}:")
        print(f"  {args.cmd1}: {get_command_preview(args.cmd1)}")
        print(f"  {args.cmd2}: {get_command_preview(args.cmd2)}")
        print()
        
        output1 = get_command_output(args.cmd1)
        output2 = get_command_output(args.cmd2)
        
    except KeyboardInterrupt:
        sys.exit(1)
    except SystemExit:
        # Re-raise SystemExit from core module
        raise
    
    # Create temporary files for diff
    with tempfile.NamedTemporaryFile(mode='w', suffix=f'_cmd{args.cmd1}', delete=False) as f1:
        f1.write(output1)
        file1 = f1.name
    
    with tempfile.NamedTemporaryFile(mode='w', suffix=f'_cmd{args.cmd2}', delete=False) as f2:
        f2.write(output2)
        file2 = f2.name
    
    try:
        # Build diff command
        diff_cmd = []
        
        # Try to use colordiff if available and not disabled
        if not args.no_color:
            try:
                subprocess.run(['colordiff', '--version'], 
                             capture_output=True, check=True)
                diff_cmd.append('colordiff')
            except (subprocess.CalledProcessError, FileNotFoundError):
                diff_cmd.append('diff')
        else:
            diff_cmd.append('diff')
        
        # Add diff options
        if args.side_by_side:
            diff_cmd.extend(['--side-by-side', '--width=120'])
        elif args.context:
            diff_cmd.extend([f'--context={args.context}'])
        else:
            diff_cmd.append('--unified=3')
        
        # Add file labels
        diff_cmd.extend([
            f'--label=command {args.cmd1}',
            f'--label=command {args.cmd2}',
            file1, file2
        ])
        
        # Run diff
        result = subprocess.run(diff_cmd, capture_output=True, text=True)
        
        if result.returncode == 0:
            print("No differences found.")
        elif result.returncode == 1:
            print(result.stdout)
        else:
            print(f"Error running diff: {result.stderr}", file=sys.stderr)
            sys.exit(1)
            
    finally:
        # Clean up temporary files
        try:
            os.unlink(file1)
            os.unlink(file2)
        except OSError:
            pass


if __name__ == "__main__":
    main()