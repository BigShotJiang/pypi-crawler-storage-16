#!/usr/bin/env python3
"""
oldout - Get the output from previous shell commands in tmux

This tool captures and extracts command outputs from tmux pane history,
allowing you to programmatically access the results of previously run commands.
"""

import argparse
import sys

from .tmux import get_command_output, list_available_commands


def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description='Extract output from previous shell commands in tmux',
        epilog="""
Examples:
  oldout              # Get output of most recent command
  oldout 2            # Get output of 2nd most recent command
  oldout --command 1  # Include the command prompt line
  oldout --list       # Show available commands

Configuration:
  Create ~/.config/oldout.py to customize prompt detection:
  
    PROMPT_RE = r"^\\$ "  # Match shell prompts that start with "$ "
    PROMPT_LENGTH = 1     # Number of prompt lines to skip
        """,
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument(
        'n', 
        type=int, 
        nargs='?', 
        default=1, 
        help='Which command output to return (1=most recent, 2=second most recent, etc.)'
    )
    
    parser.add_argument(
        '--command', 
        action='store_true', 
        default=False, 
        help='Include the command prompt line in output'
    )
    
    parser.add_argument(
        '--list', 
        action='store_true', 
        default=False,
        help='List available command outputs with numbers'
    )
    
    parser.add_argument(
        '--debug', 
        action='store_true', 
        default=False,
        help='Show debug information about prompt matching and parsing'
    )
    
    parser.add_argument(
        '--version', 
        action='version', 
        version='oldout 1.0.0'
    )
    
    return parser.parse_args()


def main():
    """Main entry point."""
    args = parse_arguments()
    
    # Handle --list option
    if args.list:
        list_available_commands()
        return
    
    # Get and print the requested command output
    try:
        output = get_command_output(args.n, args.command, debug=args.debug)
        print(output)
    except KeyboardInterrupt:
        sys.exit(1)


if __name__ == "__main__":
    main()