#!/usr/bin/env python3
"""
Core functionality for extracting command outputs from tmux.

This module provides the core parsing and extraction logic used by
both oldout and olddiff commands.
"""

import getpass
import re
import socket
import subprocess
import sys
import os
from typing import List, Dict, Any


def get_config() -> Dict[str, Any]:
    """Load configuration from ~/.config/oldout.py if it exists."""
    config_path = os.path.expanduser('~/.config/oldout.py')
    if os.path.exists(config_path):
        config_globals = {}
        with open(config_path) as f:
            exec(f.read(), config_globals)
        return config_globals
    
    # Default configuration
    return {
        'PROMPT_RE': "^" + re.escape(getpass.getuser()) + "@" + re.escape(socket.gethostname()),
        'PROMPT_LENGTH': 1
    }


def run_tmux_command() -> List[str]:
    """Capture tmux pane content and return as lines."""
    try:
        command = "tmux capture-pane -p -S -1000"
        output = subprocess.check_output(command.split()).decode('utf8')
        return output.splitlines()
    except subprocess.CalledProcessError as e:
        print(f"Error: Failed to capture tmux pane. Are you running in tmux?", file=sys.stderr)
        print(f"Command failed: {e}", file=sys.stderr)
        sys.exit(1)
    except FileNotFoundError:
        print("Error: tmux not found. Please install tmux.", file=sys.stderr)
        sys.exit(1)


def group_by_prompts(lines: List[str], prompt_re: str, debug: bool = False) -> List[List[str]]:
    """
    Group lines by prompts, returning most recent command outputs first.
    
    Each group contains the output of one command, with the prompt line
    and subsequent output lines.
    """
    groups = []
    current_group = []
    matches_found = 0
    
    # Process lines in reverse order to find command boundaries
    for i, line in enumerate(reversed(lines)):
        if re.match(prompt_re, line):
            matches_found += 1
            if debug:
                print(f"DEBUG: Found prompt match {matches_found} at line {len(lines)-1-i}: {line!r}", file=sys.stderr)
            # Found a prompt - this ends the current group
            groups.append(list(reversed(current_group)))
            current_group = []
        else:
            current_group.append(line)
    
    # Add any remaining lines as the last group
    if current_group:
        groups.append(list(reversed(current_group)))
    
    if debug:
        print(f"DEBUG: Total prompt matches found: {matches_found}", file=sys.stderr)
    
    return groups


def get_command_output(n: int, include_command: bool = False, debug: bool = False) -> str:
    """
    Get the output from the nth most recent command.
    
    Args:
        n: Command number (1=most recent, 2=second most recent, etc.)
        include_command: Whether to include the command prompt line
        debug: Whether to show debug information
        
    Returns:
        The command output as a string
        
    Raises:
        SystemExit: If command not found or other error
    """
    config = get_config()
    
    if debug:
        print(f"DEBUG: Using PROMPT_RE = {config['PROMPT_RE']!r}", file=sys.stderr)
        print(f"DEBUG: Using PROMPT_LENGTH = {config['PROMPT_LENGTH']}", file=sys.stderr)
    
    # Get tmux pane content
    lines = run_tmux_command()
    if not lines:
        print("No tmux pane content found.", file=sys.stderr)
        sys.exit(1)
    
    if debug:
        print(f"DEBUG: Captured {len(lines)} lines from tmux", file=sys.stderr)
        print("DEBUG: Last 5 lines:", file=sys.stderr)
        for i, line in enumerate(lines[-5:]):
            print(f"DEBUG:   {len(lines)-5+i}: {line!r}", file=sys.stderr)
    
    # Group lines by command prompts
    grouped_lines = group_by_prompts(lines, config['PROMPT_RE'], debug)
    
    if debug:
        print(f"DEBUG: Found {len(grouped_lines)} command groups", file=sys.stderr)
        for i, group in enumerate(grouped_lines[:3]):  # Show first 3 groups
            print(f"DEBUG: Group {i+1}: {len(group)} lines", file=sys.stderr)
            if group:
                print(f"DEBUG:   First line: {group[0]!r}", file=sys.stderr)
    
    if not grouped_lines:
        print("No command outputs found. Check your prompt configuration.", file=sys.stderr)
        sys.exit(1)
    
    # Check if requested command exists (using 1-based indexing)
    if n >= len(grouped_lines):
        print(f"Error: Only {len(grouped_lines)-1} command outputs available.", file=sys.stderr)
        sys.exit(1)
    
    if n < 1:
        print("Error: Command number must be 1 or greater.", file=sys.stderr)
        sys.exit(1)
    
    # Get the requested command output (use 1-based indexing like tmux-result)
    selected_group = grouped_lines[n]  # Keep 1-based indexing
    
    if debug:
        print(f"DEBUG: Selected group {n}: {len(selected_group)} lines", file=sys.stderr)
        if selected_group:
            print(f"DEBUG: Group contents:", file=sys.stderr)
            for i, line in enumerate(selected_group):
                print(f"DEBUG:   {i}: {line!r}", file=sys.stderr)
    
    if include_command and selected_group:
        # Include the command prompt
        result_lines = [f"> {selected_group[0]}"] + selected_group[1:]
    else:
        # Skip prompt lines
        skip_lines = max(0, config['PROMPT_LENGTH'] - 1)
        result_lines = selected_group[skip_lines:]
        if debug:
            print(f"DEBUG: Skipping {skip_lines} prompt lines, returning {len(result_lines)} lines", file=sys.stderr)
    
    return '\n'.join(result_lines)


def list_available_commands() -> None:
    """List available command outputs with previews."""
    config = get_config()
    
    # Get tmux pane content
    lines = run_tmux_command()
    if not lines:
        print("No tmux pane content found.", file=sys.stderr)
        sys.exit(1)
    
    # Group lines by command prompts
    grouped_lines = group_by_prompts(lines, config['PROMPT_RE'], False)
    
    if not grouped_lines:
        print("No command outputs found. Check your prompt configuration.", file=sys.stderr)
        sys.exit(1)
    
    print("Available command outputs:")
    for i, group in enumerate(grouped_lines[:10], 1):  # Show first 10
        if group and len(group) > config['PROMPT_LENGTH'] - 1:
            preview = group[0][:60] + "..." if len(group[0]) > 60 else group[0]
            print(f"  {i}: {preview}")


def get_command_preview(n: int) -> str:
    """Get a preview of what command produced the output."""
    try:
        config = get_config()
        lines = run_tmux_command()
        grouped_lines = group_by_prompts(lines, config['PROMPT_RE'])
        
        if n < len(grouped_lines) and n >= 1:
            group = grouped_lines[n]  # Use 1-based indexing like get_command_output
            if group:
                return group[0]  # First line should be the command
        
        return f"command {n}"
    except:
        return f"command {n}"