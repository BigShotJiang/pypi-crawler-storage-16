from enum import StrEnum

from pydantic import BaseModel, Field


class DataSource(StrEnum):
    PLANETARY_COMPUTER = "planetary_computer"


class OperationalContext(BaseModel):
    """Environment/context-specific information necessary for controlling behavior of dataset and model operations."""

    data_source: DataSource = Field(default=DataSource.PLANETARY_COMPUTER, description="The data source for acquiring imagery")
