from enum import StrEnum


class ModalityName(StrEnum):
    SENTINEL2_L2A = "sentinel2_l2a"


SENTINEL2_L2A_BANDS = ["B01", "B02", "B03", "B04", "B05", "B06", "B07", "B08", "B8A", "B09", "B11", "B12"]

LABEL_LAYER_NAME = "label"
OUTPUT_LAYER_NAME = "output"

STAC_EO_CLOUD_COVER = "eo:cloud_cover"
