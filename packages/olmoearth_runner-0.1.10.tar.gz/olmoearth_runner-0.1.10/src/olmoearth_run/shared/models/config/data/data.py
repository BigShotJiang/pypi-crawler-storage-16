from pydantic import BaseModel

from olmoearth_run.shared.models.config.data.modalities import Modalities
from olmoearth_run.shared.models.config.data.output import Output
from olmoearth_run.shared.models.config.data.temporality import Temporality


class Data(BaseModel):
    temporality: Temporality
    modalities: Modalities
    output: Output
