"""
Named data transformers that manipulate input tensors before they are provided to the model.
These can provide normalizations ahead of specific encoders, augmentations during training, or other processing.

Meant to be chained.
"""

from typing import Annotated, Literal

from typing_extensions import TypeAliasType

from pydantic import BaseModel, Field


class OlmoEarthNormalize(BaseModel):
    name: Literal["olmoearth_normalize"]


class RandomFlip(BaseModel):
    name: Literal["random_flip"]
    x: bool = Field(default=True, description="Flip the image horizontally")
    y: bool = Field(default=True, description="Flip the image vertically")


Transform = TypeAliasType(
    "Transform",
    Annotated[
        OlmoEarthNormalize | RandomFlip,
        Field(discriminator="name")
    ]
)
