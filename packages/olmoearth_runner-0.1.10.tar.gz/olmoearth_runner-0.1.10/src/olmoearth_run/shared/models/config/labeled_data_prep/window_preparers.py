from typing import Annotated, Literal

from typing_extensions import TypeAliasType

from pydantic import BaseModel, Field


class PointToRasterWindowPreparer(BaseModel):
    """Preparer that converts point annotations into raster windows centered on the point."""
    name: Literal["point_to_raster"]
    window_buffer: int = Field(ge=0, description="The buffer around the point in pixels.")


class PolygonToRasterWindowPreparer(BaseModel):
    """Preparer that converts polygon annotations into raster windows enclosing the task geometry."""
    name: Literal["polygon_to_raster"]


WindowPreparer = TypeAliasType(
    "WindowPreparer",
    Annotated[
        PointToRasterWindowPreparer | PolygonToRasterWindowPreparer,
        Field(discriminator="name")
    ]
)
