from typing import Annotated, Literal

from typing_extensions import TypeAliasType

from pydantic import BaseModel, Field


class UseUTMProjection(BaseModel):
    method: Literal["use_utm"]


class CRSProjection(BaseModel):
    method: Literal["crs"]
    crs: str = Field(description="The CRS code of the output projection.")
    x_resolution: float = Field(gt=0, description="The x resolution of the output projection, in projection units.")
    y_resolution: float = Field(lt=0, description="The y resolution of the output projection, in projection units.")


Projection = TypeAliasType(
    "Projection",
    Annotated[
        UseUTMProjection | CRSProjection,
        Field(discriminator="method")
    ]
)
