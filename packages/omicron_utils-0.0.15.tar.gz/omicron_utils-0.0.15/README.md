# omicron-utils


## colection of classes, functions and programs that support omicron
