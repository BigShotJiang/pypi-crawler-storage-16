#!/usr/bin/env python
# -*- coding: utf-8 -*-
# vim: nu:ai:ts=4:sw=4

#
#  Copyright (C) 2025 Joseph Areeda <joseph.areeda@ligo.org>
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
"""
Provides functions to query job attributes in an HTCondor batch processing system.

This module contains utility functions to filter and retrieve job information from
an HTCondor batch processing scheduler. Queries can be performed using regex patterns,
cluster IDs, or constraints for more targeted results. Results are formatted according
to the specified projections, enabling flexible data extraction.
"""

__author__ = 'joseph areeda'
__email__ = 'joseph.areeda@ligo.org'

from time import sleep

import htcondor2 as htcondor


def schedd_query(constraint=None, schedd=None, projection=None,):
    """
    """
    if schedd is None:
        schedd = htcondor.Schedd()

    if projection is None:
        projection = ["ClusterId", "ProcId", "JobBatchName", "JobStatus"]

    ret = schedd.query(projection=projection, constraint=constraint)
    ret = list(ret) if ret else []
    return ret


def query_by_name(name, schedd=None, projection=None,):
    """
    Query the schedd for the value of a classad attribute
    :param str name: regex pattern to match against JobBatchName. EG: '.*online.*PEM1.*'
    :param htcondor.Schedd schedd: schedd to query
    :param list[str] projection: A list of classad attributes to return,
                                 defaults to ["ClusterId", "ProcId", "JobBatchName", "JobStatus"]
    :return: list of matching Job attributes containing the name
    """

    constraint = f'regexp("{name}", JobBatchName)'
    return schedd_query(constraint=constraint, schedd=schedd, projection=projection)


def query_by_clusterid(clusterid, procid=None, schedd=None, projection=None, ):
    """
    Retrieves information about a specific cluster of jobs in a batch processing scheduler.
    This function queries a scheduler using the provided cluster ID and retrieves relevant
    job information defined by the projection.

    :param clusterid: The unique cluster ID used to identify the batch of jobs.
    :type clusterid: int

    :param procid: The unique process ID used to identify a specific job within a cluster.
    :type procid: int

    :param schedd: The scheduler object to perform the query on. If not provided, a
        default scheduler will be used. Optional.
    :type schedd: object, optional

    :param projection: The list of attributes to include in the query result. Defaults
        to ["ClusterId", "ProcId", "JobBatchName", "JobStatus"].
    :type projection: list[str]

    :return: A list of job details matching the given cluster ID.
    :rtype: list[dict]
    """

    cid = clusterid
    constraint = f'ClusterId == {cid}'
    if procid and '.' not in str(clusterid):
        constraint += f' && ProcId == {procid}'
    return schedd_query(constraint=constraint, schedd=schedd, projection=projection)

def wait_for_job(job, schedd=None,):
    """
    Waits for the completion of a given job.

    This function monitors the status of a given job and waits until the job
    is completed. Use this function when there is a need to ensure that the
    execution of the code can only proceed after the job has finished.

    :param job: The job name or cluster id whose completion status is to be monitored.
    :type job: str|number
    :return: Returns when thejob is no longer found in the scheduler
    :rtype: None
    """
    while not query_by_clusterid(job, schedd=schedd) and not query_by_name(job, schedd=schedd):
        sleep(5)