::: omni.OmniFilterDefinition
