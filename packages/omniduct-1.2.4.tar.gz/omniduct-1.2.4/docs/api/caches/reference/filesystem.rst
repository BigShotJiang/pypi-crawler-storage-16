FileSystemCache
===============

.. autoclass:: omniduct.caches.filesystem.FileSystemCache
    :members:
    :special-members: __init__
    :inherited-members:
    :show-inheritance:
