DruidClient
===========

.. autoclass:: omniduct.databases.druid.DruidClient
    :members:
    :special-members: __init__
    :inherited-members:
    :show-inheritance:
