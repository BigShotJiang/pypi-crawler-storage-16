HiveServer2Client
=================

.. autoclass:: omniduct.databases.hiveserver2.HiveServer2Client
    :members:
    :special-members: __init__
    :inherited-members:
    :show-inheritance:
