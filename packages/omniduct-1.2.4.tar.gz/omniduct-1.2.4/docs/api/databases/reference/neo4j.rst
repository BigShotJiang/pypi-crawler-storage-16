Neo4jClient
===========

.. autoclass:: omniduct.databases.neo4j.Neo4jClient
    :members:
    :special-members: __init__
    :inherited-members:
    :show-inheritance:
