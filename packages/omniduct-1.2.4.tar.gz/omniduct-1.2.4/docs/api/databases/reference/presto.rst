PrestoClient
============

.. autoclass:: omniduct.databases.presto.PrestoClient
    :members:
    :special-members: __init__
    :inherited-members:
    :show-inheritance:
