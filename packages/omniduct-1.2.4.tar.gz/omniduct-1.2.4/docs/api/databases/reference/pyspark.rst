PySparkClient
============

.. autoclass:: omniduct.databases.pyspark.PySparkClient
    :members:
    :special-members: __init__
    :inherited-members:
    :show-inheritance:
