LocalFsClient
=============

.. autoclass:: omniduct.filesystems.local.LocalFsClient
    :members:
    :special-members: __init__
    :inherited-members:
    :show-inheritance:
