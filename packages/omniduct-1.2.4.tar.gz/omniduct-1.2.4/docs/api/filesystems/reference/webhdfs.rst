WebHdfsClient
=============

.. autoclass:: omniduct.filesystems.webhdfs.WebHdfsClient
    :members:
    :special-members: __init__
    :inherited-members:
    :show-inheritance:
