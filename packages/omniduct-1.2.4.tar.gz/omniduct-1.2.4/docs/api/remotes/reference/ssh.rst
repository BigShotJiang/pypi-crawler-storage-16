SSHClient
=========

.. autoclass:: omniduct.remotes.ssh.SSHClient
    :members:
    :special-members: __init__
    :inherited-members:
    :show-inheritance:
