Contributions
=============

Contributions of any nature are welcome, including software patches,
improvements to documentation, bug reports, or feature requests. One of the most
useful contributions will undoubtedly be support for new protocols, and so we
look forward to seeing your patches to support your favourite services.

For documentation on how to contribute support for new protocols, please refer
to :doc:`extensions`.
