"""
Utility functions and shared resources.
"""

from rich.console import Console

# Shared console instance
console = Console()
