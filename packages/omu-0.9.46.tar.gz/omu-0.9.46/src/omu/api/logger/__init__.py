from .extension import (
    LOGGER_LOG_PERMISSION_ID,
    LOGGER_SERVER_ID,
)

__all__ = [
    "LOGGER_LOG_PERMISSION_ID",
    "LOGGER_SERVER_ID",
]
