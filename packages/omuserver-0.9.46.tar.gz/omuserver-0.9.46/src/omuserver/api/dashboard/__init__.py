from .extension import DashboardExtension

__all__ = [
    "DashboardExtension",
]
