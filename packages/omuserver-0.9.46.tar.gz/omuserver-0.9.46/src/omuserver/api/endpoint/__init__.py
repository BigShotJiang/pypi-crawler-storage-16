from .extension import EndpointExtension

__all__ = ["EndpointExtension"]
