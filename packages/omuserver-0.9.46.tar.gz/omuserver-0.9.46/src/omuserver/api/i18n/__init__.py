from .extension import I18nExtension

__all__ = [
    "I18nExtension",
]
