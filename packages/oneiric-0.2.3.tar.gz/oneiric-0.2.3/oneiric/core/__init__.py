"""Core primitives for the Oneiric runtime."""

# Public re-exports are intentionally conservative for now.  Modules expose their
# own APIs and are imported explicitly where they are used.
