from ._command_lines_parser import main

if __name__ == "__main__":
    main()
