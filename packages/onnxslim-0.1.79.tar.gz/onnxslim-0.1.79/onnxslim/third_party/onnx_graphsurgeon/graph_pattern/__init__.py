from onnxslim.third_party.onnx_graphsurgeon.graph_pattern.graph_pattern import (
    GraphPattern,
    PatternMapping,
)
