NT_SCORE_FEATS = ['Niche_NTScore', 'Cell_NTScore']
NT_SCORE_FEAT_FILES = ['niche_NTScore.csv', 'cell_NTScore.csv']