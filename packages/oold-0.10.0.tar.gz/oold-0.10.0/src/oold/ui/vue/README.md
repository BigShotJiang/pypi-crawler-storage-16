# JsonEditor Vue Component

## Build

```bash
npm i
npm run build
```
