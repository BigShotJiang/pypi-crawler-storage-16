NameType = str | type
ParamType = str | bool | int | float | list["ParamType"] | dict[str, "ParamType"] | None