# SPDX-FileCopyrightText: 2025-present Andrew Hall <andrewmartinhall2@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
