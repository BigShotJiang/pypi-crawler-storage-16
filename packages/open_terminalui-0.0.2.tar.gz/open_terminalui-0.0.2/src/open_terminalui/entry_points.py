from open_terminalui.app import OpenTerminalUI

def app():
    app = OpenTerminalUI()
    app.run()
