"""Tests for openadapt-privacy package."""
