# python3-openadbapi

## Installation

	pip install git+https://gitlab.lrz.de/openadb/python3-openadbapi.git#egg=openadbapi

or

	pip install git+ssh://git@gitlab.lrz.de/openadb/python3-openadbapi.git#egg=openadbapi

or download from GitLab and install via pip:

	pip install python3-openadbapi/

## Documentation

A detailed documentation of the _openadbapi_ Python package can found [here](https://gitlab.lrz.de/openadb/python3-openadbapi/-/wikis/).
