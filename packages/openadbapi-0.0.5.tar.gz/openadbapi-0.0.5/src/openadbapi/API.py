import os
import sys
import re
import shapely
import netrc
import logging
import requests
import json
import pprint
import traceback

class NotFoundError(Exception):    
	def __init__(self, message):
		super().__init__(message)

class InvalidArgumentError(Exception):    
	def __init__(self, message):
		super().__init__(message)
		
class ArgumentNotFoundError(Exception):    
	def __init__(self, message):
		super().__init__(message)
	
class InternalServerError(Exception):    
	def __init__(self, message):
		super().__init__(message)

class PermissionDeniedError(Exception):    
	def __init__(self, message):
		super().__init__(message)

class API:
	
	' init logger '
	logger = logging.getLogger(__qualname__)	
	logger.propagate = False  
	if not logger.handlers:
		handler = logging.StreamHandler()
		formatter = logging.Formatter(
			"%(asctime)s %(levelname)s [%(filename)s:%(lineno)d] %(message)s",datefmt='%Y-%m-%d %H:%M:%S',
		)
		handler.setFormatter(formatter)
		logger.addHandler(handler)
				
	api_url = "https://openadb.dgfi.tum.de/api/v2/"
	
	def __init__(self, **kwargs,):
		
		log_level = kwargs.get('log_level',logging.INFO)
		debug = kwargs.get('debug',0)	
		self.username = None
		self.api_key = kwargs.get('api_key',None)
		
		' set log level '
		self.logger.setLevel(log_level)
		
		if debug == 1:
			self.api_url = "https://openadb.dgfi.tum.de:8001/api/v2/"
			self.logger.warning("Debug-API enabled ("+str(self.api_url)+")!")
				
		if self.api_key == None:
			' read credential from ~/.netrc '		
			n = netrc.netrc()
			credentials = n.authenticators('openadb.dgfi.tum.de')
			if credentials == None:
				self.logger.error('No credentials found in ~/.netrc')
				sys.exit(0)
			
			self.username = credentials[0]
			self.api_key = credentials[2]
			
		self.logger.info('Username: '+str(self.username))
		self.logger.info('API-Key: '+str(self.api_key))

		' authenicate user '		
		response = self.send_api_request(
			self.api_url+'auth/',
			{			
				'api_key' :  self.api_key
			}
		)		
		if response.status_code == 200:
			self.logger.info('Authentication successful!')		
		
	def send_api_request(self, url, args):
		
		
		response = requests.post(url, json=args)							
		if response.status_code == 400:	
			json_response = json.loads(response.text)			
			self.logger.error('400 - OpenADB-API url not found!')
			raise ArgumentNotFoundError(json_response['message'])
		elif response.status_code == 403:	
			json_response = json.loads(response.text)
			self.logger.error('403 - Permission denied!')
			raise PermissionDeniedError(json_response['message'])
		elif response.status_code == 471:	
			json_response = json.loads(response.text)
			self.logger.error('471 - Invalid Argument')
			raise InvalidArgumentError(json_response['message'])
		elif response.status_code == 500:
			json_response = json.loads(response.text)
			self.logger.error('500 - Internal Server Error')			
			raise InternalServerError(json_response['message'])	
					
		return response
		
	def get_mva_config(self, mission):
		
		self.logger.info('Get MVA config ...')
		
		args = {}
		args['api_key'] = self.api_key
		args['mission'] = mission
		
		response = self.send_api_request(
			self.api_url+'get-mva-config/',
			args
		)
				
		if type(response) == requests.models.Response:
			json_response = json.loads(response.text)
			return json_response
			
		return response
	
	def list_collections(self, args):
		
		self.logger.info('List collections ...')
		
		#~ args = {}
		args['api_key'] = self.api_key
		#~ args['mission'] = mission
		
		response = self.send_api_request(
			self.api_url+'list-collections/',
			args
		)
		if type(response) == requests.models.Response:
			json_response = json.loads(response.text)
			return json_response
			
		return response
		
	def search(self, collection, args={}):
		
		self.logger.info('Search datasets ...')
		
		#~ args = {}
		args['api_key'] = self.api_key
		args['collection'] = collection
		#~ args['mission'] = mission
		if 'aoi' in args:
			if type(args['aoi']) != shapely.geometry.polygon.Polygon:
				self.logger.error('AOI is not a shapely polygon!')
				return 9
			else:
				args['aoi'] = args['aoi'].wkt
				
		response = self.send_api_request(
			self.api_url+'search/',
			args
		)		
		if type(response) == requests.models.Response:			
			json_response = json.loads(response.text)
			return json_response
			
		return response
	
	def download(self, granules, path, overwrite=0):
		
		' check if output directory exists '
		if not os.path.isdir(path):
			self.logger.error("Output directory `"+path+"` does not exist! Create directory first!")
			sys.exit(0)			
		
		self.logger.info(str(len(granules))+' record(s) in download queue!')
		
		num_granules = len(granules)
		
		downloads_successful = 0
		downloads_failed = 0
		downloads_skipped = 0
		for i in range(num_granules):
			
			granule = granules[i]
						
			if not os.path.isdir(path+'/'+granule['collection']+'/'):
				os.mkdir(path+'/'+granule['collection']+'/')
			if not os.path.isdir(path+'/'+granule['collection']+'/'+granule['cycle']+'/'):
				os.mkdir(path+'/'+granule['collection']+'/'+granule['cycle']+'/')				
							
			if os.path.isfile(path+'/'+granule['collection']+'/'+granule['cycle']+'/'+granule['filename']) and overwrite == 0:
				self.logger.info(str(i)+'/'+str(num_granules)+' - '+('%.2f' % ((i/num_granules)*100.0))+'% '+granule['filename']+' already exist! SKIPPED!')
				downloads_skipped += 1
				continue					
			
			self.logger.info(str(i)+'/'+str(num_granules)+' - '+('%.2f' % ((i/num_granules)*100.0))+'% - Downloading '+granule['filename']+' ...')	
			granule['api_key'] = self.api_key
			response = self.send_api_request(
				self.api_url+'download/',
				granule
			)
			if type(response) == requests.models.Response:				
	
				with open(path+'/'+granule['collection']+'/'+granule['cycle']+'/'+granule['filename'], 'wb') as f:
					for chunk in response.iter_content(chunk_size=1024): 
						if chunk:
							f.write(chunk)
				if os.path.isfile(path+'/'+granule['collection']+'/'+granule['cycle']+'/'+granule['filename']):
					downloads_successful +=1
				else:
					downloads_failed +=1
		
		self.logger.info('Download summary (successful: '+str(downloads_successful)+' | failed: '+str(downloads_failed)+' | skipped: '+str(downloads_skipped)+')')
		
		summary = {}
		summary['successful'] = downloads_successful
		summary['failed'] = downloads_failed
		summary['skipped'] = downloads_skipped
		return summary
		