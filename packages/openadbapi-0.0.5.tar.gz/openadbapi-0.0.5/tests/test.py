import openadbapi

# Initialize Class
openadb_api = openadbapi.API(api_key="9B3DD76F66F4A675FD6A9A56F065EEC398922891B5FCD22A7912C00D38ABEA77",debug=0)