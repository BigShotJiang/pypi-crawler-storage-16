# `SQLAlchemySession`

::: agents.extensions.memory.sqlalchemy_session.SQLAlchemySession
