# `Lifecycle`

::: agents.lifecycle

    options:
        show_source: false
