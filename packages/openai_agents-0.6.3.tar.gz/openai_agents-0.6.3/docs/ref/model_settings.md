# `Model settings`

::: agents.model_settings
