#!/bin/bash
# WARNING THIS FILE IS A STAND-IN FOR AN EXTREMELY MALICIOUS SCRIPT
# IF YOU ARE READING THIS MESSAGE, YOU SHOULD NOT EXECUTE THIS SCRIPT

# The following line creates a file that is used to check if the script was executed
touch /tmp/jhdf834kbssdrg78
