"""openbench custom model providers."""
