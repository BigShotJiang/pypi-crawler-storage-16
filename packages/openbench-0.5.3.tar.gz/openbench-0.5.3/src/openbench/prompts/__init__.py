"""Prompt templates for OpenBench tasks."""
