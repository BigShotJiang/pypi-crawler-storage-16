"""Solver for exercism evaluation."""
