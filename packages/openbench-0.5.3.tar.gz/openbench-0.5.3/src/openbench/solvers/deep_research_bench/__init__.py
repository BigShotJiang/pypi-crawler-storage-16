"""
DeepResearch Bench solver package.
"""

from .deep_research_bench import deep_research_solver

__all__ = ["deep_research_solver"]
