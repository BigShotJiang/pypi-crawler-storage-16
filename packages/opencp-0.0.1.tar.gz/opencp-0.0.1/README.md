# opencp-dsa
A full library of data structures and algorithms for competitive programming.
