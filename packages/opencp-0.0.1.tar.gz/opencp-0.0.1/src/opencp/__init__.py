# src/opencp/__init__.py

# Import the Python wrapper class
from .queue import Queue

__all__ = ["Queue"]
