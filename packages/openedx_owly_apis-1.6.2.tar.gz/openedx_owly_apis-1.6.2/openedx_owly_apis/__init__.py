"""
One-line description for README and other doc files.
"""

__version__ = '1.6.2'
