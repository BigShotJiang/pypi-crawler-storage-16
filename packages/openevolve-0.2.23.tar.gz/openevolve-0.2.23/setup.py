from setuptools import setup

setup()  # All config in pyproject.toml
