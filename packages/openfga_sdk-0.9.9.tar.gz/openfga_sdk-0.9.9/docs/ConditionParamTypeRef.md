# ConditionParamTypeRef


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type_name** | [**TypeName**](TypeName.md) |  | 
**generic_types** | [**list[ConditionParamTypeRef]**](ConditionParamTypeRef.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


