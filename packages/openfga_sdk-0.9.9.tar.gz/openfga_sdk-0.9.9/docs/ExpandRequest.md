# ExpandRequest


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tuple_key** | [**ExpandRequestTupleKey**](ExpandRequestTupleKey.md) |  | 
**authorization_model_id** | **str** |  | [optional] 
**consistency** | [**ConsistencyPreference**](ConsistencyPreference.md) |  | [optional] 
**contextual_tuples** | [**ContextualTupleKeys**](ContextualTupleKeys.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


