# ListStoresResponse


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**stores** | [**list[Store]**](Store.md) |  | 
**continuation_token** | **str** | The continuation token will be empty if there are no more stores. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


