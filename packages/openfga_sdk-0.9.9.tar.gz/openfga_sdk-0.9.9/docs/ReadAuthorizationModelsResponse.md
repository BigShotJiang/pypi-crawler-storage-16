# ReadAuthorizationModelsResponse


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authorization_models** | [**list[AuthorizationModel]**](AuthorizationModel.md) |  | 
**continuation_token** | **str** | The continuation token will be empty if there are no more models. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


