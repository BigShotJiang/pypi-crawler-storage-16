# ReadChangesResponse


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**changes** | [**list[TupleChange]**](TupleChange.md) |  | 
**continuation_token** | **str** | The continuation token will be identical if there are no new changes. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


