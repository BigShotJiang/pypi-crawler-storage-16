# ReadRequest


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tuple_key** | [**ReadRequestTupleKey**](ReadRequestTupleKey.md) |  | [optional] 
**page_size** | **int** |  | [optional] 
**continuation_token** | **str** |  | [optional] 
**consistency** | [**ConsistencyPreference**](ConsistencyPreference.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


