# ReadResponse


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tuples** | [**list[Tuple]**](Tuple.md) |  | 
**continuation_token** | **str** | The continuation token will be empty if there are no more tuples. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


