# TupleChange


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tuple_key** | [**TupleKey**](TupleKey.md) |  | 
**operation** | [**TupleOperation**](TupleOperation.md) |  | 
**timestamp** | **datetime** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


