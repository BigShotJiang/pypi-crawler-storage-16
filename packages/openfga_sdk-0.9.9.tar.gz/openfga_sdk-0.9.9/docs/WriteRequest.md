# WriteRequest


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**writes** | [**WriteRequestWrites**](WriteRequestWrites.md) |  | [optional] 
**deletes** | [**WriteRequestDeletes**](WriteRequestDeletes.md) |  | [optional] 
**authorization_model_id** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


