# OpenGeodeWeb-Viewer

OpenSource Python framework for remote visualisation
