from scaler.entry_points.cluster import main

if __name__ == "__main__":
    main()
