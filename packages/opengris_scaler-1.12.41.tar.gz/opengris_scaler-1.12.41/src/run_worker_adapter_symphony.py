from scaler.entry_points.worker_adapter_symphony import main
from scaler.utility.debug import pdb_wrapped

if __name__ == "__main__":
    pdb_wrapped(main)()
