# Marks src as a package for CLI entry points and imports.

