"""Test package for openHAB MCP server."""
