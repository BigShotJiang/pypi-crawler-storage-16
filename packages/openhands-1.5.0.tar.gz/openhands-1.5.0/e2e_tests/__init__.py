"""E2E tests for OpenHands CLI."""
