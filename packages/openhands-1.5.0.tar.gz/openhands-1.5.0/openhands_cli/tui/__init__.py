from openhands_cli.tui.tui import DEFAULT_STYLE


__all__ = [
    "DEFAULT_STYLE",
]
