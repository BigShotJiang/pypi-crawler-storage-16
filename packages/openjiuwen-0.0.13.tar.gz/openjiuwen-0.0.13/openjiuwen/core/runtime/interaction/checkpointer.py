#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.


from openjiuwen.core.common.constants.constant import INTERACTIVE_INPUT
from openjiuwen.core.runtime.interaction.agent_storage import AgentStorage
from openjiuwen.core.runtime.interaction.base import Checkpointer
from openjiuwen.core.runtime.interaction.interactive_input import InteractiveInput
from openjiuwen.core.runtime.interaction.workflow_storage import WorkflowStorage
from openjiuwen.core.runtime.runtime import BaseRuntime
from openjiuwen.graph.store import Store
from openjiuwen.graph.store.inmemory import InMemoryStore
from openjiuwen.graph.pregel.constants import TASK_STATUS_INTERRUPT


class InMemoryCheckpointer(Checkpointer):
    def __init__(self):
        self._agent_stores = {}
        self._workflow_stores = {}
        self._graph_store = InMemoryStore()

    async def pre_workflow_execute(self, runtime: BaseRuntime, inputs: InteractiveInput):
        self._workflow_stores.setdefault(runtime.session_id(), WorkflowStorage())
        if isinstance(inputs, InteractiveInput):
            workflow_store = self._workflow_stores.get(runtime.session_id())
            workflow_store.recover(runtime, inputs)

    async def post_workflow_execute(self, runtime: BaseRuntime, result, exception):
        workflow_store = self._workflow_stores.get(runtime.session_id())
        if exception is not None:
            workflow_store.save(runtime)
            raise exception

        if result.get(TASK_STATUS_INTERRUPT) is None:
            await self._graph_store.delete(runtime.session_id(), runtime.workflow_id())
            workflow_store.clear(runtime.workflow_id())
            if runtime.config().get_agent_config() is None:
                self._workflow_stores.pop(runtime.session_id(), None)
        else:
            workflow_store.save(runtime)

    async def pre_agent_execute(self, runtime: BaseRuntime, inputs):
        agent_store = self._agent_stores.setdefault(runtime.session_id(), AgentStorage())
        agent_store.recover(runtime)
        if inputs is not None:
            runtime.state().set_state({INTERACTIVE_INPUT: [inputs]})

    async def interrupt_agent_execute(self, runtime: BaseRuntime):
        agent_store = self._agent_stores.get(runtime.session_id())
        agent_store.save(runtime)

    async def post_agent_execute(self, runtime: BaseRuntime):
        agent_store = self._agent_stores.get(runtime.session_id())
        agent_store.save(runtime)

    async def release(self, session_id: str, agent_id: str = None):
        if agent_id is not None:
            agent_store = self._agent_stores.get(session_id)
            agent_store.clear(agent_id)
        else:
            self._workflow_stores.pop(session_id, None)
            self._agent_stores.pop(session_id, None)

    def graph_store(self) -> Store:
        return self._graph_store


default_inmemory_checkpointer: Checkpointer = InMemoryCheckpointer()
