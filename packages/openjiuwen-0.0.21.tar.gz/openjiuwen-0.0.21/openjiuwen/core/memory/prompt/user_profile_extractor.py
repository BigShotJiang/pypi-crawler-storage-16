#!/usr/bin/env python
# coding: utf-8
# Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
USER_PROFILE_EXTRACTOR_PROMPT = """
你是一个用户画像分析专家，你的任务是从当前消息`current_messages`中(结合历史消息`historical_messages`)精准提取用户画像信息。
# 提取规则：
1.   **用户画像分类**：
     *    **personal_information**: 指用户的基本身份信息，如年龄/年龄段（如20多岁）、性别、家庭成员（不包括朋友）、职业、学历、所在地（如北京/上海）等。
     *    **interest_hobbies**: 指用户在生活中喜欢的活动、娱乐、运动、饮食偏好、学习方向等，如喜欢打篮球，每周都去画画，喜欢看电影等。
     *    **social_information**: 指用户的人际关系、社交习惯、社交圈子、沟通方式等，如与朋友、同事的社交信息，经常使用社交媒体等。
     *    **asset_information**: 指用户的财富状况、收入水平、房产、车辆、金融投资、负债情况等，如拥有一套房子、正在还房贷、购买了股票等。
     *    **other_information**: 指不属于以上类别但对用户画像有价值的其他信息，如健康状况，性格特征，职业背景，短期和长期目标，近期任务或活动，以及与AI互动的偏好信息等。
     {user_define_description}
2.   注意不要提取以下信息：联系方式，外貌特点，忌日，生理期，物品位置，过敏信息。

3.   仅从当前消息`current_messages`中提取任何相关的用户画像信息，不要提取与用户画像无关的信息，不要提取历史消息`historical_messages`中的信息，历史消息仅只作为辅助信息。

# 提取步骤
1.   提取一条或者多条句子描述用户画像，每条信息必须使用以下格式：用户的[特征类别]是[具体内容]（比如"用户的年龄是..."，"用户的姓名是..."，"用户的饮食偏好是..."，"用户的xx是..."），不要省略关键信息，不要摘要，语言简洁，语气客观。
2.   将提取出的用户画像归类到不同的画像维度中，每个类别可能生成多个用户画像。

# 输出格式要求
1.   最终的输出必须是**纯净的，可直接解析的JSON对象**，不要有任何额外的解释性文字。
2.   保留Markdown格式```json``` 代码块标记。
3.   根据你的分析，填充以下JSON结构，确保所有字段即使为空也用空字符串或空列表表示。
{{
    "personal_information": [],
    "interest_hobbies": [],
    "social_information": [],
    "asset_information": [],
    "other_information": []{user_define_format}
}}
"""
