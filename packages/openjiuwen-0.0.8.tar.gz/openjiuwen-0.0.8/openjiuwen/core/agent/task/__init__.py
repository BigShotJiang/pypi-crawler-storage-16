from .task import Task, TaskInput

__all__ = ['Task', 'TaskInput']
