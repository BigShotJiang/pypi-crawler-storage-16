"""Command-line helpers for OpenMed zero-shot workflows."""

from __future__ import annotations

__all__ = []
