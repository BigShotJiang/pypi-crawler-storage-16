:orphan:

{{ name }}
{{ underline }}

.. currentmodule:: {{ module }}

.. automethod:: {{ objname }}
