from ._funcs import *
from ._percolation import *
