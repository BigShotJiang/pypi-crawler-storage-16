r"""
Throat Centroid Model
---------------------

Calculate throat centroid values by averaging adjacent pore coordinates

"""

from ._funcs import *
