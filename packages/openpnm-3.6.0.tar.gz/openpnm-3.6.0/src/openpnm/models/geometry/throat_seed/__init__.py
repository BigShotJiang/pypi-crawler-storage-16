r"""
Throat Seed Models
------------------

This model contains a selection of functions for calcuating the
throat seed

"""

from ._funcs import *
