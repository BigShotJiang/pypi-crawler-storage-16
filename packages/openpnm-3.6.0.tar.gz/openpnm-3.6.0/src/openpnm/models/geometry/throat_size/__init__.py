r"""
Throat Size Models
------------------

This model contains a selection of functions for calcuating the
throat size

"""

from ._funcs import *
