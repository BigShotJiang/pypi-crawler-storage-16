r"""
Throat Vector Model
-------------------

Calculates throat vector as straight path between connected pores

"""

from ._funcs import *
