r"""
Throat Volume Models
--------------------

This model contains a selection of functions for calcuating
throat volume assuing various shapes

"""

from ._funcs import *
