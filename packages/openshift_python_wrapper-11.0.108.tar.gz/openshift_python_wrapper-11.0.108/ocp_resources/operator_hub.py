from ocp_resources.resource import Resource


class OperatorHub(Resource):
    api_group = Resource.ApiGroup.CONFIG_OPENSHIFT_IO
