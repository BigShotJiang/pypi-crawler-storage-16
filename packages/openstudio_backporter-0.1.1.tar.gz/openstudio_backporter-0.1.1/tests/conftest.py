# TODO: temp
import sys

sys.path.insert(0, '/Users/julien/Software/Others/OS-build-release/Products/python')

import pytest  # noqa: F401
