from openstudiobackporter.main import main

main()
