# These version placeholders will be replaced later during substitution.
__version__ = "1.7.1"
__version_tuple__ = (1, 7, 1)
