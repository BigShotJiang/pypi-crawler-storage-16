import logging

logger = logging.getLogger("opfer")
