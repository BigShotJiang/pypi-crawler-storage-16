"""OpticMCP - MCP server for USB camera capture with OpenCV."""

__version__ = "0.2.0"
