from optics_framework.optics import Optics

def test_icici_swipe():
    """Test case for ICICI app swipe functionality."""
    # Sample configuration for ICICI swipe test
    optics = Optics()

    config = {
        "driver_sources": [
            {
                "appium": {
                    "enabled": True,
                    "url": "https://icici-appium-hub.mozark.ai:443/wd/hub",
                    "capabilities": {
                        "appium:deviceName": "iPhone 13 mini",
                        "platformName": "iOS",
                        "appium:platformVersion": "18.3.2",
                        "appium:automationName": "XCUITest",
                        "appium:xcodeOrgId": "JPD2LB5SNR",
                        "appium:udid": "00008110-001C39810269801E",
                        "appium:xcodeSigningId": "iPhone Developer",
                        "appium:newCommandTimeout": "120",
                        "mozark:options": {
                            "secret": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiQ1VTVE9NLVRPS0VOX19odHRwczovL2NvZ25pdG8taWRwLmFwLXNvdXRoLTEuYW1hem9uYXdzLmNvbS9hcC1zb3V0aC0xX0VMRk5DZ2JTTCIsImNvZ25pdG86dXNlcm5hbWUiOiJhc2h3aW5AbW96YXJrLmFpIiwib3JpZ2luX2p0aSI6IjEwQWZSbDRTcTVUSjVQLTZTQU9rWFRFZEJOaXhhNy10MDRfZHBydjI2MzQ9IiwiY3VzdG9tOnRlbmFudElkIjoiaWNpY2kiLCJjdXN0b206dXNlclJvbGUiOiJUZW5hbnRBZG1pbiIsImF1ZCI6IjMzcDh1ZnZlbzE5dG5ua2htMmhnMjJtNXBtIiwidG9rZW5fdXNlIjoiaWQiLCJqdGkiOiJBU0lBNzU2MkYyNEEzRDMwRDdENzM3RDhGRTVEIiwiZW1haWwiOiJhc2h3aW5AbW96YXJrLmFpIiwiZXhwIjoyMDYyNDk4MTk5LCJpYXQiOjE3NDcxMzgxOTl9._Ijz3IvBwIFqwRWBMzzf9d5-k6-uOjVmzNHSKYYBs-8"
                        },
                    },
                }
            }
        ],
        "elements_sources": [
            {"appium_find_element": {"enabled": True}},
            {"appium_page_source": {"enabled": True}},
            {"appium_screenshot": {"enabled": True}},
        ],
        "execution_output_path": "/Users/dhruvmenon/Documents/optics-framework-1/optics_framework/samples/icici_swipe",
        # Optional extra keys:
        # "project_path": "/path/to/project",
        # "execution_output_path": "/tmp/optics-output",
    }

        # Configure Optics (instance method)
    optics.setup(config=config)
    # OR
    # optics = Optics.setup(config_path="path/to/your/config.yaml")
        # Launch the ICICI app with specific capabilities
    optics.launch_app(
        app_identifier="com.icicibank.imobilenativeuat",
        app_activity="com.csam.icici.bank.imobile.IMOBILE",
    )
    try:
        optics.sleep("10")  # Wait for the app to launch
        # print("App launched successfully.")
        optics.press_by_coordinates("187", "266")  # Initial tap to focus
        optics.sleep("10")  # Wait for 10 seconds
        print("Starting swipe actions 1.")
        optics.press_by_coordinates("72", "549")  # First swipe action
        optics.sleep("10")  # Wait for 10 seconds
        print("Starting swipe actions 2.")
        optics.press_by_coordinates("72", "549")  # Second swipe action
        optics.sleep("10")  # Wait for 10 seconds
        print("Starting swipe actions 3.")
        optics.press_by_coordinates("72", "549")  # Third swipe action
        optics.sleep("10")  # Wait for 10 seconds
        print("Starting swipe actions 4.")
        optics.press_by_coordinates("72", "549")  # Fourth swipe action
        optics.sleep("10")  # Wait for 10 seconds
        print("Starting swipe actions 5.")
        optics.press_by_coordinates("82", "473")  # Fifth swipe action
        optics.sleep("10")  # Wait for 10 seconds
        print("Starting swipe actions 6.")
        optics.press_by_coordinates("54", "305")  # Sixth swipe action
        optics.sleep("10")  # Wait for 10 seconds
        print("Starting swipe actions 7.")
        optics.press_by_coordinates("65", "546")  # Seventh swipe action
        optics.sleep("10")  # Wait for 10 seconds
        print("Starting swipe actions 8.")
        optics.press_by_coordinates("207", "483")  # Eighth swipe action
        optics.sleep("10")  # Wait for 10 seconds
        print("Starting swipe action 9 - swipe from element.")
        optics.swipe_from_element("//XCUIElementTypeApplication[@name=\"iMobile\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[4]","right","300")
        optics.sleep("10")  # Wait for 10 seconds
        print("Starting swipe actions 10.")
        optics.press_by_coordinates("200", "516")  # Ninth swipe action
        optics.sleep("10")  # Wait for 10 seconds
        print("Starting swipe actions 11.")
        optics.press_by_coordinates("205", "750")  # Tenth swipe action
    except:
        print("An error occurred during the test.")
    finally:
        optics.quit()
        # GetI see that the code needs to use the setup function from Optics. Looking at the current code, it's directly initializing Optics with a configuration dictionary, but it should use the setup function instead.
test_icici_swipe()
"""
    actions = ActionChains(driver)
actions.w3c_actions = ActionBuilder(driver, mouse=PointerInput(interaction.POINTER_TOUCH, "touch"))
actions.w3c_actions.pointer_action.move_to_location(187, 266)
actions.w3c_actions.pointer_action.pointer_down()
actions.w3c_actions.pointer_action.pause(0.1)
actions.w3c_actions.pointer_action.release()
actions.perform()

actions = ActionChains(driver)
actions.w3c_actions = ActionBuilder(driver, mouse=PointerInput(interaction.POINTER_TOUCH, "touch"))
actions.w3c_actions.pointer_action.move_to_location(72, 549)
actions.w3c_actions.pointer_action.pointer_down()
actions.w3c_actions.pointer_action.pause(0.1)
actions.w3c_actions.pointer_action.release()
actions.perform()

actions = ActionChains(driver)
actions.w3c_actions = ActionBuilder(driver, mouse=PointerInput(interaction.POINTER_TOUCH, "touch"))
actions.w3c_actions.pointer_action.move_to_location(72, 549)
actions.w3c_actions.pointer_action.pointer_down()
actions.w3c_actions.pointer_action.pause(0.1)
actions.w3c_actions.pointer_action.release()
actions.perform()

actions = ActionChains(driver)
actions.w3c_actions = ActionBuilder(driver, mouse=PointerInput(interaction.POINTER_TOUCH, "touch"))
actions.w3c_actions.pointer_action.move_to_location(72, 549)
actions.w3c_actions.pointer_action.pointer_down()
actions.w3c_actions.pointer_action.pause(0.1)
actions.w3c_actions.pointer_action.release()
actions.perform()

actions = ActionChains(driver)
actions.w3c_actions = ActionBuilder(driver, mouse=PointerInput(interaction.POINTER_TOUCH, "touch"))
actions.w3c_actions.pointer_action.move_to_location(72, 549)
actions.w3c_actions.pointer_action.pointer_down()
actions.w3c_actions.pointer_action.pause(0.1)
actions.w3c_actions.pointer_action.release()
actions.perform()

actions = ActionChains(driver)
actions.w3c_actions = ActionBuilder(driver, mouse=PointerInput(interaction.POINTER_TOUCH, "touch"))
actions.w3c_actions.pointer_action.move_to_location(82, 473)
actions.w3c_actions.pointer_action.pointer_down()
actions.w3c_actions.pointer_action.pause(0.1)
actions.w3c_actions.pointer_action.release()
actions.perform()

actions = ActionChains(driver)
actions.w3c_actions = ActionBuilder(driver, mouse=PointerInput(interaction.POINTER_TOUCH, "touch"))
actions.w3c_actions.pointer_action.move_to_location(54, 305)
actions.w3c_actions.pointer_action.pointer_down()
actions.w3c_actions.pointer_action.pause(0.1)
actions.w3c_actions.pointer_action.release()
actions.perform()

actions = ActionChains(driver)
actions.w3c_actions = ActionBuilder(driver, mouse=PointerInput(interaction.POINTER_TOUCH, "touch"))
actions.w3c_actions.pointer_action.move_to_location(65, 546)
actions.w3c_actions.pointer_action.pointer_down()
actions.w3c_actions.pointer_action.pause(0.1)
actions.w3c_actions.pointer_action.release()
actions.perform()

actions = ActionChains(driver)
actions.w3c_actions = ActionBuilder(driver, mouse=PointerInput(interaction.POINTER_TOUCH, "touch"))
actions.w3c_actions.pointer_action.move_to_location(207, 483)
actions.w3c_actions.pointer_action.pointer_down()
actions.w3c_actions.pointer_action.pause(0.1)
actions.w3c_actions.pointer_action.release()
actions.perform()

actions = ActionChains(driver)
actions.w3c_actions = ActionBuilder(driver, mouse=PointerInput(interaction.POINTER_TOUCH, "touch"))
actions.w3c_actions.pointer_action.move_to_location(17, 756)
actions.w3c_actions.pointer_action.pointer_down()
actions.w3c_actions.pointer_action.move_to_location(354, 755)
actions.w3c_actions.pointer_action.release()
actions.perform()

actions = ActionChains(driver)
actions.w3c_actions = ActionBuilder(driver, mouse=PointerInput(interaction.POINTER_TOUCH, "touch"))
actions.w3c_actions.pointer_action.move_to_location(200, 516)
actions.w3c_actions.pointer_action.pointer_down()
actions.w3c_actions.pointer_action.pause(0.1)
actions.w3c_actions.pointer_action.release()
actions.perform()

actions = ActionChains(driver)
actions.w3c_actions = ActionBuilder(driver, mouse=PointerInput(interaction.POINTER_TOUCH, "touch"))
actions.w3c_actions.pointer_action.move_to_location(205, 750)
actions.w3c_actions.pointer_action.pointer_down()
actions.w3c_actions.pointer_action.pause(0.1)
actions.w3c_actions.pointer_action.release()
actions.perform()


    """