from ._tektronix_tk512cb import tektronix_tk512cb

__all__ = [
    "tektronix_tk512cb",
]
