from ._e2v_ccd64_thick import e2v_ccd64_thick

__all__ = [
    "e2v_ccd64_thick",
]
