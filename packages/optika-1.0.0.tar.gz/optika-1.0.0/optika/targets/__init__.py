"""Test targets for visualizing the performance of optical systems."""

from ._airforce import airforce

__all__ = [
    "airforce",
]
