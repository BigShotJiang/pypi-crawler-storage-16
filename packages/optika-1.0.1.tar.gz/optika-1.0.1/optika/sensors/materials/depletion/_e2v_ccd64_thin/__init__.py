from ._e2v_ccd64_thin import e2v_ccd64_thin

__all__ = [
    "e2v_ccd64_thin",
]
