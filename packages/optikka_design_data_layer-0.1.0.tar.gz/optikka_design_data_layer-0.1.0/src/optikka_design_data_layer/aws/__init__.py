"""AWS service clients"""

from optikka_design_data_layer.aws.s3_utils import (
    generate_s3_location_for_script,
    upload_script_to_s3,
    download_script_from_s3,
)
from optikka_design_data_layer.aws.secrets_manager import SecretsManager
from optikka_design_data_layer.aws.bedrock_client import BedrockClient
from optikka_design_data_layer.aws.openai_client import OpenAIClient

__all__ = [
    "generate_s3_location_for_script",
    "upload_script_to_s3",
    "download_script_from_s3",
    "SecretsManager",
    "BedrockClient",
    "OpenAIClient",
]
