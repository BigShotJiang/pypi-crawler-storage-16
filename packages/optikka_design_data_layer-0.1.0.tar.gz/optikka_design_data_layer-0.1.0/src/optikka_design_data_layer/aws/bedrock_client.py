"""AWS Bedrock client"""

import json
from typing import Any

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError
from optikka_design_data_layer.logger import logger


class BedrockClient:
    """Client for AWS Bedrock Runtime operations."""

    CONFIG = Config(
        retries={"max_attempts": 3, "mode": "adaptive"},
        connect_timeout=60,
        read_timeout=300,
    )

    def __init__(self, region_name: str = "us-west-2"):
        self.region_name = region_name
        self.client = boto3.client("bedrock-runtime", region_name=region_name, config=self.CONFIG)
        logger.info(f"Initialized BedrockClient for region: {region_name}")

    def invoke(self, model_id: str, body: dict[str, Any]) -> dict[str, Any]:
        """Invoke a Bedrock model with the given body."""
        try:
            logger.info(f"Invoking Bedrock model: {model_id}")
            response = self.client.invoke_model(
                modelId=model_id,
                contentType="application/json",
                accept="application/json",
                body=json.dumps(body),
            )

            response_body = json.loads(response["body"].read())
            logger.info(f"Successfully invoked model: {model_id}")
            return response_body

        except ClientError as e:
            error_code = e.response["Error"]["Code"]
            logger.error(f"Bedrock ClientError: {error_code}")
            raise
        except Exception as e:
            logger.error(f"Error invoking Bedrock model: {e}")
            raise