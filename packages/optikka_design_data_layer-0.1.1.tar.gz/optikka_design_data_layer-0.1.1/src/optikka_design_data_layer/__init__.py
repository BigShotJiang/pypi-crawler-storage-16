"""
Optikka Design Data Layer
Shared utilities for Optikka microservices running on AWS Lambda.
"""

__version__ = "0.1.0"

# Re-export core utilities
from optikka_design_data_layer.logger import logger
from optikka_design_data_layer.config import EnvironmentVariables
from optikka_design_data_layer.errors import (
    S3UploadError,
    MongoDBUpsertError,
    AuthValidationError,
)
from optikka_design_data_layer.connection_types import (
    ConnectionHealthStatus,
    PostgresCredentials,
    ConnectionStats,
    ConnectionConfig,
)

# Subpackages are imported via their __init__.py files
# Users can import like: from optikka_design_data_layer.clients import mongodb_client

__all__ = [
    "logger",
    "EnvironmentVariables",
    "S3UploadError",
    "MongoDBUpsertError",
    "AuthValidationError",
    "ConnectionHealthStatus",
    "PostgresCredentials",
    "ConnectionStats",
    "ConnectionConfig",
]
