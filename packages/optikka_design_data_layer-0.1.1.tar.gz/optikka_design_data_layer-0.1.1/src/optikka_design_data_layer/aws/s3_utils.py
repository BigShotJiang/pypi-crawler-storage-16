"""
S3 utils.
"""

import os
import json
import uuid
import csv
import io

import boto3
from botocore.exceptions import ClientError, NoCredentialsError

from optikka_design_data_layer.logger import logger
from optikka_design_data_layer.config import EnvironmentVariables

def _generate_s3_location(render_run_name: str, file_name: str = None) -> dict[str, str]:
    """Generate a S3 location."""
    logger.debug(f"Generating S3 location for render run name: {render_run_name}")
    uuid_str = str(uuid.uuid4())
    bucket = os.getenv('RENDER_RUN_S3_BUCKET_NAME')
    logger.debug(f"Bucket: {bucket}")
    logger.debug(f"Key: {f'/render-run-csvs/{render_run_name}/{uuid_str}'}")
    return {
        'bucket': bucket,
        'key': f'render-run-csvs/{render_run_name}/{uuid_str}/{file_name}'
    }

def generate_s3_location_for_script(template_registry_id: str) -> dict[str, str]:
    """Generate a S3 location for a script."""
    logger.debug(f"Generating S3 location for script name: {template_registry_id}")
    return {
        'bucket': EnvironmentVariables.SCRIPT_S3_BUCKET_NAME,
        'key': f'ods_scripts/{template_registry_id}.json'
    }
def generate_presigned_upload_url(
        render_run_name: str,
        expiration: int = 3600,
        file_name: str = None
    ) -> tuple[str, dict[str, str]]:
    """Generate a presigned URL for S3 object."""
    try:
        s3_location = _generate_s3_location(render_run_name, file_name)
        logger.debug(f"Generating presigned URL for S3 location: {s3_location}")
        s3_client = boto3.client('s3')
        url = s3_client.generate_presigned_url(
            'put_object',
            Params={'Bucket': s3_location['bucket'], 'Key': s3_location['key']},
            ExpiresIn=expiration
        )
        logger.debug(f"Presigned URL: {url}")
        return url, s3_location
    except ClientError as e:
        logger.debug(f"Failed to generate presigned URL: {str(e)}")
        raise RuntimeError(f"Failed to generate presigned URL: {str(e)}") from e
    except NoCredentialsError as exc:
        logger.debug(f"AWS credentials not found: {str(exc)}")
        raise RuntimeError("AWS credentials not found") from exc
    except Exception as e:
        logger.debug(f"Failed to generate presigned URL: {str(e)}")
        raise RuntimeError(f"Failed to generate presigned URL: {str(e)}") from e


def download_csv_from_s3(bucket: str, key: str) -> bytes:
    """Download CSV file from S3."""
    try:
        s3_client = boto3.client('s3')
        response = s3_client.get_object(Bucket=bucket, Key=key)
        response_body = response['Body'].read()
        return response_body
    except ClientError as e:
        raise RuntimeError(f"Failed to download object: {str(e)}") from e
    except NoCredentialsError as exc:
        raise RuntimeError("AWS credentials not found") from exc


def parse_csv_to_json(csv_data: bytes) -> list[dict]:
    """Parse CSV data into JSON format."""
    try:
        # Decode bytes to string
        csv_string = csv_data.decode('utf-8')

        # Create a StringIO object to read the CSV
        csv_io = io.StringIO(csv_string)

        # Read CSV and convert to list of dictionaries
        reader = csv.DictReader(csv_io)
        json_data = list(reader)

        return json_data
    except UnicodeDecodeError as e:
        raise ValueError(f"Failed to decode CSV data: {str(e)}") from e
    except Exception as e:
        raise ValueError(f"Failed to parse CSV data: {str(e)}") from e


def download_and_parse_csv_from_s3(bucket: str, key: str) -> list[dict]:
    """Download CSV file from S3 and parse it into JSON format."""
    csv_data = download_csv_from_s3(bucket, key)
    logger.debug(f"CSV data: {csv_data}")
    return parse_csv_to_json(csv_data)


def download_csv_from_location(location_json: str) -> bytes:
    """Download CSV file from S3 location specified in JSON format: {"bucket": "x", "key": "y"}."""
    try:
        location = json.loads(location_json) if isinstance(location_json, str) else location_json

        if not isinstance(location, dict) or 'bucket' not in location or 'key' not in location:
            raise ValueError("Invalid S3 location format. Expected {'bucket': 'x', 'key': 'y'}")

        return download_csv_from_s3(location['bucket'], location['key'])
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON format: {str(e)}") from e

def upload_script_to_s3(script: str, s3_location: dict[str, str]) -> None:
    """Upload a script to S3."""
    try:
        s3_client = boto3.client('s3')
        s3_client.put_object(Bucket=s3_location['bucket'], Key=s3_location['key'], Body=script)
    except ClientError as e:
        raise RuntimeError(f"Failed to upload script to S3: {str(e)}") from e
    except NoCredentialsError as exc:
        raise RuntimeError("AWS credentials not found") from exc

def download_script_from_s3(s3_location: dict[str, str]) -> str:
    """Download a script from S3."""
    try:
        s3_client = boto3.client('s3')
        if s3_location['bucket'] is None or s3_location['key'] is None:
            raise ValueError("S3 location is invalid")
        response = s3_client.get_object(Bucket=s3_location['bucket'], Key=s3_location['key'])
        return response['Body'].read().decode('utf-8')
    except ClientError as e:
        raise RuntimeError(f"Failed to download script from S3: {str(e)}") from e
    except NoCredentialsError as exc:
        raise RuntimeError("AWS credentials not found") from exc
