"""
Optikka Design Data Layer
Shared utilities for Optikka microservices.

This package provides:
- Logger (AWS Lambda Powertools)
- Error classes
- Response utilities
- Auth validation

Usage:
    from optikka_design_data_layer import logger
    from optikka_design_data_layer.errors import AuthValidationError
    from optikka_design_data_layer.utils import create_success_response
    from optikka_design_data_layer.validation import validate_auth_from_event
"""

__version__ = "0.1.2"

# Re-export core utilities
from optikka_design_data_layer.logger import logger
from optikka_design_data_layer.errors import (
    S3UploadError,
    MongoDBUpsertError,
    AuthValidationError,
)

__all__ = [
    # Logger
    "logger",
    # Errors
    "S3UploadError",
    "MongoDBUpsertError",
    "AuthValidationError",
]
