import shutil
import json
from pathlib import Path


def clean_dir(path: Path):
    if path.exists():
        shutil.rmtree(path)
    # path.mkdir(exist_ok=True)


def dump_json(filename: str, data, **kwargs):
    kwargs.setdefault("indent", 4)
    with open(filename, "w") as f:
        json.dump(data, f, **kwargs)


def load_json(filename: str, **kwargs):
    with open(filename, "r") as f:
        return json.load(f, **kwargs)
