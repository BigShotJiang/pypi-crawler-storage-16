import logging
from pathlib import Path
import numpy as np

import param
from pyrameters import PRM

from optimflow.utils import clean_dir
from optimflow.param_iter import (
    OptimParams,
    ParameterSpaceExploration,
    SimulationParams,
)


DEFAULT_PARAMS = Path(__file__).parent / "log_params_TTP06.prm"


class LifexParams(SimulationParams):
    dict_excluded = ("out_dir", "lifex_param_set")
    lifex_params_fname = param.Filename(
        default=DEFAULT_PARAMS, doc="fname of baseline params"
    )
    lifex_param_set: dict = param.Dict(doc="dealII params")

    @param.depends("lifex_params_fname", watch=True, on_init=True)
    def _update_lifex_params_fname(self):
        with open(self.lifex_params_fname) as f:
            self.lifex_param_set = PRM(f.read())

    def add_optim_params(self, params: OptimParams):
        for k, v in params.to_dict().items():
            _ = self.lifex_param_set.get(f"/Ionic model/TTP06/Physical constants/{k}")
            assert _ is not None, f"Parameter {k!r} not found"
            self.lifex_param_set.set(f"/Ionic model/TTP06/Physical constants/{k}", v)

    def save(self, data: dict = None):
        with open(fname := self.out_dir / "lifex_params.prm", "w") as f:
            f.write(str(self.lifex_param_set))
        self.lifex_params_fname = fname
        super().save(data)


class LifexParameterSpaceExploration(ParameterSpaceExploration):
    def dump_params(
        self, simu_params: LifexParams, optim_params: OptimParams, n: int = 5
    ):
        clean_dir(self.out_dir)

        for i, x, infos in optim_params.linear_oneatatime_iter(
            *optim_params.all_keys, n=n
        ):
            params = simu_params.copy()
            params.out_dir = self.out_dir / f"case_{i}"
            params.add_optim_params(x)
            params.save(infos)


log = logging.getLogger(__name__)


# def lifex_worker(dname: str):
#     log.debug(f"Starting {str(dname)!r}")

#     params = LifexParams.load_from(dname)
#     # Popen([...])

#     Ko = params.lifex_param_set.get("/Ionic model/TTP06/Physical constants/Ko")
#     t = np.linspace(0, 1, 100)
#     res = Ko * np.sin(2 * np.pi * t)
#     np.savetxt(params.out_dir / "result.txt", res)

#     log.debug(f"Finished {str(dname)!r}")


# if __name__ == "__main__":
#     logging.basicConfig(level=logging.INFO)

#     out_path = Path(__file__).parent / "out"

#     class CMAESParams(OptimParams):
#         Ko = param.Number(0.5, bounds=(0, 2), doc="")
#         Cao = param.Number(10, bounds=(5, 25), doc="")

#     simulation_params = LifexParams()
#     optim_params = CMAESParams()

#     explo = LifexParameterSpaceExploration(out_path)
#     explo.dump_params(simulation_params, optim_params)
#     explo.run(lifex_worker)
#     explo.gather_results()
#     explo.plot_results()
