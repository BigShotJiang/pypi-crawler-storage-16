import logging
from functools import cached_property

from optimflow.utils import clean_dir
from optimflow.param_iter import OptimParams
from optimflow.lifex import LifexParameterSpaceExploration, LifexParams


class LifexParameterSpaceAsk(LifexParameterSpaceExploration):
    @cached_property
    def dirs(self):
        return sorted(self.out_dir.glob("pop_*"))

    def dump_params(self, values, simu_params: LifexParams, optim_params: OptimParams):
        clean_dir(self.out_dir)

        for i, row in enumerate(values):
            params = simu_params.copy()
            params.out_dir = self.out_dir / f"pop_{i}"
            names = optim_params.to_dict().keys()
            for k, v in zip(names, row):
                setattr(optim_params, k, v)
            params.add_optim_params(optim_params)
            params.save()


log = logging.getLogger(__name__)
