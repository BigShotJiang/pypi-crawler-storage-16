import logging
import json
from functools import cached_property
from concurrent.futures import ProcessPoolExecutor
from typing import Callable, Iterator, Tuple
from pathlib import Path
from copy import deepcopy
import numpy as np
from matplotlib import pyplot as plt
import pandas as pd

import param

from optimflow.utils import clean_dir, dump_json, load_json


class OptimParams(param.Parameterized):
    def to_dict(self) -> dict:
        x = json.loads(self.param.serialize_parameters())
        x.pop("name")
        return x

    def assign(self, x: list):
        for k, v in zip(self.to_dict().keys(), x):
            setattr(self, k, v)

    @property
    def all_keys(self):
        return list(self.to_dict().keys())

    def linear_iter(
        self, *ps: param.Parameter, n: int = None
    ) -> Iterator[Tuple[int, param.Parameterized]]:
        """
        Iterate over several sets of parameters
        """
        for i, x in enumerate(
            LinearIter(*[self.param[k] for k in list(ps)], defaults=self, n=n).gen
        ):
            yield i, x

    def linear_oneatatime_iter(
        self, *ps: param.Parameter, n: int = None
    ) -> Iterator[Tuple[int, param.Parameterized, dict]]:
        """
        Iterate over several sets of parameters
        """
        it = LinearOneAtATimeIter(
            *[self.param[k] for k in list(ps)], defaults=self, n=n
        )
        for i, (x, xi) in enumerate(zip(it.gen, it.gen_infos)):
            yield i, x, xi


class ParamIter:
    """
    Class intended to provide methods to iterate over several sets
    of parameters
    """

    def __init__(
        self,
        *ps: param.Parameter,
        defaults: OptimParams = None,
        n: int = None,
    ):
        self.params = list(ps)
        self.defaults = defaults or OptimParams()
        self.n = n

    def __len__(self):
        return len(self.params)

    @property
    def gen(self):
        raise NotImplementedError

    def save(self, fname: str):
        fname = Path(fname)
        fname.parent.mkdir()
        dump_json(
            fname,
            {
                "n": self.n,
                "N": len(self),
                "varying": self.params,
                "defaults": self.defaults.to_dict(),
            },
        )
        return self


class LinearIter(ParamIter):
    def __len__(self):
        return self.n

    @property
    def gen(self):
        """
        Return self.n sets of parameters, each parameter has n values
        varying linearly between its bounds
        """
        bds = [np.linspace(*x.bounds, self.n) for x in self.params]
        for i in range(self.n):
            d = deepcopy(self.defaults)
            updates = {p.name: bds[j][i] for j, p in enumerate(self.params)}
            d.param.update(**updates)
            yield d


class LinearOneAtATimeIter(ParamIter):
    def __len__(self):
        return self.n * len(self.params)

    @property
    def gen(self):
        """
        Return self.n*len(self.params) sets of parameters, each parameter has n values
        varying linearly between its bounds while the other are set to default
        """
        for x in self.params:
            bds = x.bounds
            for val in np.linspace(*bds, self.n):
                d = deepcopy(self.defaults)
                setattr(d, x.name, val)
                yield d

    @property
    def gen_infos(self):
        for x in self.params:
            bds = x.bounds
            for i, val in enumerate(np.linspace(*bds, self.n)):
                d = deepcopy(self.defaults)
                setattr(d, x.name, val)
                yield {"i": i, "varying": x.name, "value": val}


class Foldername(param.Foldername):
    __slots__ = ["create_if_not_exist", "must_exist"]

    def __init__(
        self, default=None, create_if_not_exist=True, must_exist=False, **params
    ):
        self.create_if_not_exist = create_if_not_exist
        self.must_exist = must_exist
        super().__init__(default, **params)

    def _resolve(self, path):
        if path is None:
            return
        p = Path(path)
        if self.create_if_not_exist:
            p.mkdir(parents=True, exist_ok=True)
        p = p.resolve()
        if self.must_exist and not p.exists():
            raise ValueError(f"Directory does not exist: {p}")
        return p


class SimulationParams(param.Parameterized):
    dict_excluded = ("out_dir",)
    out_dir = Foldername(doc="Simulation output directory")

    def to_dict(self) -> dict:
        subset = [p for p in self.param if p not in self.dict_excluded]
        data = json.loads(self.param.serialize_parameters(subset))
        data["out_dir"] = str(self.out_dir) if self.out_dir is not None else None
        return data

    @classmethod
    def load_from(cls, dname):
        data = load_json(dname / "params.json")
        allowed = {k: v for k, v in data.items() if k in cls.param}
        others = {k: v for k, v in data.items() if k not in cls.param}
        p = cls(**allowed)
        for k, v in others.items():
            p.param.add_parameter(k, param.Number(v))
        return p

    def save(self, data: dict = None):
        dump_json(self.out_dir / "params.json", self.to_dict())
        if data is not None:
            dump_json(self.out_dir / "infos.json", data)

    def copy(self):
        return deepcopy(self)

    def save_with(self, out: str, optim_params: OptimParams):
        self.out_dir = Path(out)
        for k, v in optim_params.to_dict().items():
            self.param.add_parameter(k, param.Number(v))
        self.save()


class ParameterSpaceExploration:
    def __init__(self, out: str):
        self.out_dir = Path(out)

    @cached_property
    def dirs(self):
        return sorted(self.out_dir.glob("case_*"))

    def dump_params(
        self, simu_params: SimulationParams, optim_params: OptimParams, n: int = 5
    ):
        clean_dir(self.out_dir)

        for i, x, infos in optim_params.linear_oneatatime_iter(
            *optim_params.all_keys, n=n
        ):
            params = simu_params.copy()
            params.out_dir = self.out_dir / f"case_{i}"
            for k, v in x.to_dict().items():
                params.param.add_parameter(k, param.Number(v))
            params.save(infos)

    def run(self, f: Callable, parallel=True) -> list:
        if not parallel:
            res = [f(x) for x in self.dirs]

        else:
            with ProcessPoolExecutor() as p:
                res = list(p.map(f, self.dirs))
        return res

    def gather_results(self) -> pd.DataFrame:
        cases: dict[tuple[str, int], pd.DataFrame] = {}

        for case_dir in self.dirs:
            infos = load_json(case_dir / "infos.json")
            res = np.loadtxt(case_dir / "result.txt")
            df_case = pd.DataFrame({"result": np.atleast_1d(res)})
            key = (infos["varying"], infos["i"])
            cases[key] = df_case

        # columns MultiIndex: level 0 = varying, level 1 = i
        df = pd.concat(cases, axis=1)
        df = df.sort_index(axis=1)

        df.to_csv(self.out_dir / "results.csv")
        return df

    @cached_property
    def value_map(self):
        # build mapping (var, i) -> value from infos.json
        value_map_ = {}
        for case_dir in self.out_dir.glob("case_*"):
            infos = load_json(case_dir / "infos.json")
            key = (infos["varying"], int(infos["i"]))
            value_map_[key] = float(infos["value"])
        return value_map_

    def plot_results(self, show=True):
        df = pd.read_csv(self.out_dir / "results.csv", index_col=0, header=[0, 1, 2])
        groups = list(df.groupby(level=[0, 2], axis=1))
        n = len(groups)
        cols = int(np.ceil(np.sqrt(n)))
        rows = int(np.ceil(n / cols))

        fig, axes = plt.subplots(rows, cols, figsize=(6 * cols, 3 * rows), sharex=True)
        for ax, ((var, comp), sub) in zip(axes, groups):
            block = sub.xs((var, comp), axis=1, level=[0, 2])

            for i in block.columns:
                v = self.value_map[(var, int(i))]
                ax.plot(block.index, block[i], label=f"{round(v, 3)}")

            ax.set_title(f"{var}")
            ax.set_xlabel("time [s]")
            ax.set_ylabel(f"{comp}")
            ax.legend()

        for ax in axes[n:]:
            ax.set_visible(False)
        fig.tight_layout()
        if show:
            plt.show()
        fig.savefig(self.out_dir / "plots.png")


class ParameterSpaceAsk(ParameterSpaceExploration):
    @cached_property
    def dirs(self):
        return sorted(self.out_dir.glob("pop_*"))

    def dump_params(
        self, values, simu_params: SimulationParams, optim_params: OptimParams
    ):
        clean_dir(self.out_dir)

        for i, row in enumerate(values):
            params = simu_params.copy()
            params.out_dir = self.out_dir / f"pop_{i}"
            names = optim_params.to_dict().keys()
            for k, v in zip(names, row):
                params.param.add_parameter(k, param.Number(v))
            params.save()


log = logging.getLogger(__name__)


# def worker(dname: str):
#     # must be in the global scope
#     params = SimulationParams.load_from(dname)
#     t = np.linspace(0, 1, 100)  # fake data
#     res = params.p1 * np.sin(params.p2 * 2 * np.pi * t)
#     np.savetxt(params.out_dir / "result.txt", res)


# if __name__ == "__main__":
#     logging.basicConfig(level=logging.INFO)

#     out_path = Path(__file__).parent / "out"

#     class Params(OptimParams):
#         p1 = param.Number(1, bounds=(0, 1), doc="Parameter 1")
#         p2 = param.Number(1, bounds=(0.9, 1.1), doc="Parameter 2")

#     simulation_params = SimulationParams()
#     optim_params = Params()

#     explo = ParameterSpaceExploration(out_path)
#     explo.dump_params(simulation_params, optim_params)
#     explo.run(worker)
#     explo.gather_results()
#     explo.plot_results()
