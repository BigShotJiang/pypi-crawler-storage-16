# Example configurations for OpusFilter

## paracrawl_fi-en

Corpus filtering and domain adaptation experiments for Finnish-English
translation (Aulamo et al., 2020b).

## qed_lm_langid.yaml

Example configuration for language identification with
`LMClassifierFilter`. Also shows how to use variables to loop multiple
languages in a single step.
