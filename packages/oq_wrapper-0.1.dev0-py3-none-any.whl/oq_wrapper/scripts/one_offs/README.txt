Scripts that were developed by the SW team for a one-off use to support a research project.
These scripts are not actively maintained by SW, and are therefore most likely out of date.