from enum import Enum


class DivergenceType(Enum):
    BULLISH = 1,
    BEARISH = 2