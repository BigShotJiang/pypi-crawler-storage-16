#include "ora/date_type.hh"

namespace ora {
namespace date {

//------------------------------------------------------------------------------

template class DateTemplate<DateTraits>;
template class DateTemplate<Date16Traits>;

//------------------------------------------------------------------------------

}  // namespace date
}  // namespace ora

