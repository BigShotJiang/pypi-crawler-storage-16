
BACKGROUND = "#fdbc73"
ICON = "icons/addon_icon.png"
