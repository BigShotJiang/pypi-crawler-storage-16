"""orange3-db-connections add-on.

Kumpulan widget koneksi database (PostgreSQL, MySQL, SQL Server, SQLite, ClickHouse).
"""

NAME = "DB Connections"
DESCRIPTION = "Widget koneksi ke berbagai database."
BACKGROUND = "#fdbc73"
ICON = "icons/addon_icon.png"

