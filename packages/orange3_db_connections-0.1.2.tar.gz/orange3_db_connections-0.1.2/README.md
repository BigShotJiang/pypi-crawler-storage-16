# orange3-db-connections

Add-on Orange untuk membuat koneksi ke berbagai database (PostgreSQL, MySQL, SQL Server, SQLite, ClickHouse)