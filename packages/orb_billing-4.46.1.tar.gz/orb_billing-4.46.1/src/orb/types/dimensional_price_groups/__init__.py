# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from .dimensional_price_groups import DimensionalPriceGroups as DimensionalPriceGroups
from .external_dimensional_price_group_id_update_params import (
    ExternalDimensionalPriceGroupIDUpdateParams as ExternalDimensionalPriceGroupIDUpdateParams,
)
