# core/ocdb.py

from typing import Any, Optional, List
from .config import load_config

# MEMORY ENGINE (SQLite/Postgres hybrid)
from orbmem.engines.memory.postgres_backend import PostgresMemoryBackend

# VECTOR ENGINE – Qdrant fallback to FAISS / in-memory
from orbmem.engines.vector.qdrant_backend import QdrantVectorBackend

# GRAPH ENGINE – fallback to NetworkX (in-memory)
from orbmem.engines.graph.neo4j_backend import Neo4jGraphBackend

# SAFETY ENGINE
from orbmem.engines.safety.mongo_backend import MongoSafetyBackend
from orbmem.engines.safety.timeseries_backend import TimeSeriesSafetyBackend


class OCDB:
    """
    High-level interface combining all cognitive engines:
      - Memory Engine (Postgres only, Redis disabled)
      - Vector Engine (FAISS fallback)
      - Graph Engine (NetworkX fallback)
      - Safety Engine (Mongo + TimeSeries)
    """

    def __init__(self):
        cfg = load_config()

        # -------------------------------
        # MEMORY ENGINE (NO REDIS)
        # -------------------------------
        self.pg_memory = PostgresMemoryBackend()
        self.redis_memory = None  # Fully disabled

        # -------------------------------
        # VECTOR ENGINE
        # -------------------------------
        self.vector_engine = QdrantVectorBackend()

        # -------------------------------
        # GRAPH ENGINE
        # -------------------------------
        self.graph_engine = Neo4jGraphBackend()

        # -------------------------------
        # SAFETY ENGINE
        # -------------------------------
        self.safety_event_engine = MongoSafetyBackend()
        self.safety_timeseries = TimeSeriesSafetyBackend()

    # =====================================================
    # MEMORY METHODS — SAFE & CLEAN (NO REDIS)
    # =====================================================

    def memory_set(self, key: str, value: dict, session_id: str = None, ttl_seconds: int = None):
        """
        Store memory in Postgres only (Redis disabled).
        """
        return self.pg_memory.set(key, value, session_id=session_id, ttl_seconds=ttl_seconds)

    def memory_get(self, key: str):
        """
        Retrieve memory from Postgres only.
        """
        return self.pg_memory.get(key)

    def memory_keys(self) -> List[str]:
        """
        List all memory keys.
        """
        return self.pg_memory.keys()

    # =====================================================
    # VECTOR METHODS
    # =====================================================

    def vector_search(self, query: str, k: int = 5):
        """
        Search vector embeddings using FAISS fallback (no Qdrant needed).
        """
        return self.vector_engine.search(query, k=k)

    # =====================================================
    # GRAPH METHODS
    # =====================================================

    def graph_add(self, node_id: str, content: str, parent: Optional[str] = None):
        """
        Add a node to in-memory reasoning graph.
        """
        return self.graph_engine.add_node(node_id, content, parent)

    def graph_path(self, start: str, end: str):
        """
        Get path between two graph nodes.
        """
        return self.graph_engine.get_path(start, end)

    # =====================================================
    # SAFETY METHODS
    # =====================================================

    def safety_scan(self, text: str):
        """
        Detect safety events and record in timeseries engine.
        """
        events = self.safety_event_engine.scan(text)

        # update timeseries fingerprint
        for evt in events:
            self.safety_timeseries.add_point(evt.tag, evt.severity)

        return [
            {
                "text": evt.text,
                "tag": evt.tag,
                "severity": evt.severity,
                "correction": evt.correction,
                "details": evt.details,
                "timestamp": evt.timestamp,
            }
            for evt in events
        ]
