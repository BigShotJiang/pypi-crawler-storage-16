# models/safety.py

from sqlalchemy import Column, Integer, String, Float, JSON, TIMESTAMP
from sqlalchemy.sql import func
from orbmem.db.postgres import Base

class SafetyEvent(Base):
    __tablename__ = "safety_events"

    id = Column(Integer, primary_key=True)
    text = Column(String, nullable=False)
    tag = Column(String, index=True, nullable=False)
    severity = Column(Float, nullable=False)
    correction = Column(String, nullable=True)

    # CHANGED: metadata → details
    details = Column(JSON, nullable=True)

    timestamp = Column(TIMESTAMP(timezone=True), server_default=func.now())
