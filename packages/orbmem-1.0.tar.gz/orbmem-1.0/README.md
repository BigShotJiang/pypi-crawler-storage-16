# OCDB — Cognitive Database Framework

OCDB (Orbynt Cognitive Database) is a lightweight, modular framework that combines
**🧠 Memory**, **🔍 Vector Search**, **🕸 Graph Reasoning**, and **🛡 Safety Scanning** into a single Python package.

Designed for:

- AI agents
- Chatbots
- Automation systems
- Reasoning pipelines
- Personal assistants
- Any system that needs context, memory, search, and safety  

This is the **local developer** version for PyPI.
A fully hosted **OCDB Cloud Platform** will launch separately.

---

## ✨ Features


### 🧠 1. Memory Engine
Store and retrieve structured memory using a simple API.

```python
from ocdb.core.ocdb import OCDB

ocdb = OCDB()
ocdb.memory_set("name", {"value": "Abhishek"})
print(ocdb.memory_get("name"))
```

---


### 🔍 2. Vector Search (FAISS local engine)
Semantic search powered by FAISS.

```python
ocdb.vector_engine.add_text("hello world", {"id": "1"})
results = ocdb.vector_search("hello", k=3)
```

---

### 🕸 3. Graph Engine (NetworkX)
Build reasoning trees or node-based logic.

```python
ocdb.graph_add("root", "Start")
ocdb.graph_add("child", "Next", parent="root")
```

---

### 🛡 4. Safety Engine
Simple text-safety scanning with MongoDB + time-series tracking.

```python
events = ocdb.safety_scan("This is a sample text")
```

---

### 📦 Installation

```nginx
pip install orbmem
```

---

### 📁 Project Structure
```makefile
ocdb/
 ├── core/        # Config, auth, high-level OCDB interface
 ├── engines/     # Memory, vector, graph, safety engines
 ├── models/      # Memory & safety models
 ├── utils/       # Helpers, exceptions, logging
 └── db/          # Database connectors (Mongo, Neo4j, Postgres, Redis)
```

---

### 🚀 Quickstart Example

```python
from ocdb.core.ocdb import OCDB

ocdb = OCDB()

# Memory
ocdb.memory_set("demo", {"text": "Hello OCDB"})
print(ocdb.memory_get("demo"))

# Vector
ocdb.vector_engine.add_text("Abhishek is building OCDB", {"id": "vec1"})
print(ocdb.vector_search("Abhishek"))

# Graph
ocdb.graph_add("n1", "Start")
ocdb.graph_add("n2", "Next", parent="n1")

# Safety
print(ocdb.safety_scan("Harmless text"))
```

---

### 📝license
This project is released under the *MIT License*.                       
See the `LICENSE` file for full terms.

---

### 👨‍💻 Author
**Tetala Lakshmi Abhishek Reddy**            
Creator of OCDB                   
📧Email: `abhishek.orbynt@gmail.com`

---

### ⭐ Support OCDB
f you like this project, please star the repository and share it!  
The OCDB Cloud Dashboard + Hosted API is coming soon… 🚀