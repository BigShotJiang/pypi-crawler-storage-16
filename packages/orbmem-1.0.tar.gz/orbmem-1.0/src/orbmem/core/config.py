# core/config.py

import os
from dataclasses import dataclass
from typing import List, Optional

from dotenv import load_dotenv
from utils.exceptions import ConfigError


# ===========================
# DATA CLASSES
# ===========================

@dataclass
class DatabaseConfig:
    postgres_url: str
    redis_url: Optional[str] = None
    mongo_url: Optional[str] = None
    neo4j_url: Optional[str] = None


@dataclass
class APIConfig:
    api_keys: List[str]
    debug: bool = False
    mode: str = "local"   # local | cloud


@dataclass
class OCDBConfig:
    db: DatabaseConfig
    api: APIConfig


# ===========================
# HELPERS
# ===========================

def _get_env(name: str, default: Optional[str] = None, required: bool = False) -> Optional[str]:
    """Fetch env variable with optional requirement."""
    value = os.getenv(name, default)

    # treat empty string as None
    if value is not None:
        value = value.strip()
        if value == "":
            value = None

    if required and not value:
        raise ConfigError(f"Missing required environment variable: {name}")

    return value


# ===========================
# MAIN CONFIG LOADER
# ===========================

def load_config() -> OCDBConfig:
    """
    Load configuration fresh every call.
    Respects OCDB_MODE (local/cloud).
    """

    # Reload .env every time (Windows safe)
    load_dotenv(override=True)

    # -------------------------------
    # MODE: local or cloud
    # -------------------------------
    mode = _get_env("OCDB_MODE", default="local").lower()
    if mode not in ("local", "cloud"):
        raise ConfigError("OCDB_MODE must be either 'local' or 'cloud'")

    # -------------------------------
    # DATABASES
    # -------------------------------
    postgres_url = _get_env("POSTGRES_URL", required=True)
    redis_url = _get_env("REDIS_URL")
    mongo_url = _get_env("MONGO_URL")
    neo4j_url = _get_env("NEO4J_URL")  # will be None in local mode

    # -------------------------------
    # API Keys (only required in cloud mode)
    # -------------------------------
    api_keys_raw = _get_env(
        "OCDB_API_KEYS",
        required=(mode == "cloud")  # Only required in cloud mode
    )

    api_keys = []
    if api_keys_raw:
        api_keys = [k.strip() for k in api_keys_raw.split(",") if k.strip()]

    # -------------------------------
    # DEBUG MODE
    # -------------------------------
    debug_raw = _get_env("OCDB_DEBUG", default="0")
    debug = debug_raw.lower() in ("1", "true", "yes", "y")

    # -------------------------------
    # Build config objects
    # -------------------------------
    db_cfg = DatabaseConfig(
        postgres_url=postgres_url,
        redis_url=redis_url,
        mongo_url=mongo_url,
        neo4j_url=neo4j_url,
    )

    api_cfg = APIConfig(
        api_keys=api_keys,
        debug=debug,
        mode=mode,
    )

    print(f"🔧 Loaded OCDB_MODE: {mode}")
    print(f"🔐 Loaded API keys: {api_keys}")
    print(f"🐬 Redis enabled: {bool(redis_url)}")
    print(f"🧠 Neo4j enabled: {bool(neo4j_url)}")

    return OCDBConfig(db=db_cfg, api=api_cfg)
