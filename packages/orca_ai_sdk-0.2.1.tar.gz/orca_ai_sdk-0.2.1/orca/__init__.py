"""
Orca - Unified Provider-Agnostic AI SDK

A production-grade Python library for interacting with multiple AI providers
through a single, unified interface.

Example:
    ```python
    from orca import Orca
    
    client = Orca(
        providers=["openai", "anthropic"],
        api_keys={"openai": "sk-...", "anthropic": "sk-ant-..."}
    )
    
    response = client.chat(
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello!"}]
    )
    print(response.text)
    ```
"""

__version__ = "0.1.0"

from .core.client import Orca
from .core.config import OrcaConfig, list_supported_providers
from .core.exceptions import (
    AuthenticationError,
    ConnectionError,
    ContentFilterError,
    ModelNotFoundError,
    OrcaError,
    ProviderError,
    QuotaExceededError,
    RateLimitError,
    StreamingError,
    TimeoutError,
    ValidationError,
)
from .utils.types import (
    Attachment,
    FinishReason,
    FunctionDeclaration,
    GenerationConfig,
    MessageRole,
    OrcaEmbedding,
    OrcaImage,
    OrcaModel,
    OrcaResponse,
    OrcaStreamChunk,
    SafetyCategory,
    SafetySetting,
    SafetyThreshold,
    TokenUsage,
    ToolCall,
)

__all__ = [
    # Main client
    "Orca",
    "OrcaConfig",
    "__version__",
    # Response types
    "OrcaResponse",
    "OrcaStreamChunk",
    "OrcaModel",
    "OrcaEmbedding",
    "OrcaImage",
    "TokenUsage",
    "FinishReason",
    "MessageRole",
    # Advanced features
    "Attachment",
    "FunctionDeclaration",
    "GenerationConfig",
    "SafetyCategory",
    "SafetySetting",
    "SafetyThreshold",
    "ToolCall",
    # Exceptions
    "OrcaError",
    "AuthenticationError",
    "RateLimitError",
    "ValidationError",
    "ModelNotFoundError",
    "ProviderError",
    "ConnectionError",
    "TimeoutError",
    "StreamingError",
    "ContentFilterError",
    "QuotaExceededError",
    # Utilities
    "list_supported_providers",
]
