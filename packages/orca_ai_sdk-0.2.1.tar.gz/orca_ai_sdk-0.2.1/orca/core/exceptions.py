"""
Orca Exception System

Provides a strict typed exception hierarchy for all provider-level errors.
Each exception includes provider context, response data, and helpful debugging info.
"""

from typing import Any, Optional


class OrcaError(Exception):
    """Base exception for all Orca errors."""
    
    def __init__(
        self,
        message: str,
        provider: Optional[str] = None,
        status_code: Optional[int] = None,
        response_data: Optional[dict[str, Any]] = None,
    ) -> None:
        self.message = message
        self.provider = provider
        self.status_code = status_code
        self.response_data = response_data or {}
        super().__init__(self._format_message())
    
    def _format_message(self) -> str:
        parts = [self.message]
        if self.provider:
            parts.insert(0, f"[{self.provider}]")
        if self.status_code:
            parts.append(f"(HTTP {self.status_code})")
        return " ".join(parts)


class AuthenticationError(OrcaError):
    """Raised when API authentication fails (invalid/missing API key)."""
    
    def __init__(
        self,
        provider: str,
        message: str = "Authentication failed",
        status_code: Optional[int] = 401,
        response_data: Optional[dict[str, Any]] = None,
    ) -> None:
        super().__init__(
            message=message,
            provider=provider,
            status_code=status_code,
            response_data=response_data,
        )


class RateLimitError(OrcaError):
    """Raised when API rate limits are exceeded."""
    
    def __init__(
        self,
        provider: str,
        message: str = "Rate limit exceeded",
        retry_after: Optional[float] = None,
        status_code: Optional[int] = 429,
        response_data: Optional[dict[str, Any]] = None,
    ) -> None:
        self.retry_after = retry_after
        super().__init__(
            message=message,
            provider=provider,
            status_code=status_code,
            response_data=response_data,
        )


class ValidationError(OrcaError):
    """Raised when request validation fails (invalid parameters)."""
    
    def __init__(
        self,
        message: str,
        provider: Optional[str] = None,
        field: Optional[str] = None,
        status_code: Optional[int] = 400,
        response_data: Optional[dict[str, Any]] = None,
    ) -> None:
        self.field = field
        if field:
            message = f"{message} (field: {field})"
        super().__init__(
            message=message,
            provider=provider,
            status_code=status_code,
            response_data=response_data,
        )


class ModelNotFoundError(OrcaError):
    """Raised when the specified model is not found in the registry."""
    
    def __init__(
        self,
        model: str,
        provider: Optional[str] = None,
        available_models: Optional[list[str]] = None,
    ) -> None:
        self.model = model
        self.available_models = available_models or []
        message = f"Model '{model}' not found"
        if available_models:
            suggestions = available_models[:5]
            message += f". Available: {', '.join(suggestions)}"
            if len(available_models) > 5:
                message += f" (+{len(available_models) - 5} more)"
        super().__init__(message=message, provider=provider, status_code=None)


class ProviderError(OrcaError):
    """Raised for general provider-level API errors."""
    
    def __init__(
        self,
        provider: str,
        message: str,
        status_code: Optional[int] = None,
        response_data: Optional[dict[str, Any]] = None,
        error_code: Optional[str] = None,
    ) -> None:
        self.error_code = error_code
        super().__init__(
            message=message,
            provider=provider,
            status_code=status_code,
            response_data=response_data,
        )


class ConnectionError(OrcaError):
    """Raised when connection to provider fails."""
    
    def __init__(
        self,
        provider: str,
        message: str = "Failed to connect to provider",
        original_error: Optional[Exception] = None,
    ) -> None:
        self.original_error = original_error
        super().__init__(message=message, provider=provider, status_code=None)


class TimeoutError(OrcaError):
    """Raised when a request times out."""
    
    def __init__(
        self,
        provider: str,
        timeout: float,
        message: Optional[str] = None,
    ) -> None:
        self.timeout = timeout
        message = message or f"Request timed out after {timeout}s"
        super().__init__(message=message, provider=provider, status_code=None)


class StreamingError(OrcaError):
    """Raised when streaming response parsing fails."""
    
    def __init__(
        self,
        provider: str,
        message: str = "Error processing streaming response",
        chunk_data: Optional[str] = None,
    ) -> None:
        self.chunk_data = chunk_data
        super().__init__(message=message, provider=provider, status_code=None)


class ContentFilterError(OrcaError):
    """Raised when content is blocked by provider safety filters."""
    
    def __init__(
        self,
        provider: str,
        message: str = "Content blocked by safety filters",
        filter_reason: Optional[str] = None,
        response_data: Optional[dict[str, Any]] = None,
    ) -> None:
        self.filter_reason = filter_reason
        if filter_reason:
            message = f"{message}: {filter_reason}"
        super().__init__(
            message=message,
            provider=provider,
            status_code=None,
            response_data=response_data,
        )


class QuotaExceededError(OrcaError):
    """Raised when API quota/credits are exhausted."""
    
    def __init__(
        self,
        provider: str,
        message: str = "API quota exceeded",
        status_code: Optional[int] = 402,
        response_data: Optional[dict[str, Any]] = None,
    ) -> None:
        super().__init__(
            message=message,
            provider=provider,
            status_code=status_code,
            response_data=response_data,
        )


def raise_for_status(
    provider: str,
    status_code: int,
    response_data: dict[str, Any],
) -> None:
    """
    Raise appropriate exception based on HTTP status code and response data.
    
    Args:
        provider: Name of the provider
        status_code: HTTP status code
        response_data: Parsed response body
    """
    error_message = _extract_error_message(response_data)
    
    if status_code == 401:
        raise AuthenticationError(
            provider=provider,
            message=error_message or "Invalid or missing API key",
            status_code=status_code,
            response_data=response_data,
        )
    elif status_code == 402:
        raise QuotaExceededError(
            provider=provider,
            message=error_message or "API quota exceeded",
            status_code=status_code,
            response_data=response_data,
        )
    elif status_code == 429:
        retry_after = response_data.get("retry_after")
        raise RateLimitError(
            provider=provider,
            message=error_message or "Rate limit exceeded",
            retry_after=retry_after,
            status_code=status_code,
            response_data=response_data,
        )
    elif status_code == 400:
        raise ValidationError(
            message=error_message or "Invalid request parameters",
            provider=provider,
            status_code=status_code,
            response_data=response_data,
        )
    elif status_code == 404:
        raise ProviderError(
            provider=provider,
            message=error_message or "Resource not found",
            status_code=status_code,
            response_data=response_data,
        )
    elif status_code >= 500:
        raise ProviderError(
            provider=provider,
            message=error_message or "Provider server error",
            status_code=status_code,
            response_data=response_data,
        )
    elif status_code >= 400:
        raise ProviderError(
            provider=provider,
            message=error_message or f"Request failed with status {status_code}",
            status_code=status_code,
            response_data=response_data,
        )


def _extract_error_message(response_data: dict[str, Any]) -> Optional[str]:
    """Extract error message from various provider response formats."""
    # OpenAI format
    if "error" in response_data:
        error = response_data["error"]
        if isinstance(error, dict):
            return error.get("message")
        return str(error)
    
    # Anthropic format
    if "message" in response_data:
        return response_data["message"]
    
    # Gemini format
    if "error" in response_data and isinstance(response_data["error"], dict):
        return response_data["error"].get("message")
    
    return None
