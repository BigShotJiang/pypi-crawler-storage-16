"""
Orca Request Engines

Provides sync and async HTTP request handling with retries,
timeout management, and unified error handling.
"""

import json
import logging
import time
from typing import Any, Callable, Iterator, Optional

import requests

from .config import OrcaConfig, ProviderConfig
from .exceptions import (
    ConnectionError,
    TimeoutError,
    raise_for_status,
)

logger = logging.getLogger(__name__)


class SyncRequestEngine:
    """
    Synchronous HTTP request engine using the requests library.
    
    Handles authentication, retries, and error mapping for all providers.
    """
    
    def __init__(
        self,
        config: OrcaConfig,
    ) -> None:
        """
        Initialize the sync request engine.
        
        Args:
            config: Global Orca configuration
        """
        self.config = config
        self._session: Optional[requests.Session] = None
    
    @property
    def session(self) -> requests.Session:
        """Get or create the requests session."""
        if self._session is None:
            self._session = requests.Session()
        return self._session
    
    def request(
        self,
        provider_config: ProviderConfig,
        api_key: str,
        method: str,
        path: str,
        data: Optional[dict[str, Any]] = None,
        params: Optional[dict[str, str]] = None,
        timeout: Optional[float] = None,
    ) -> dict[str, Any]:
        """
        Make a synchronous HTTP request.
        
        Args:
            provider_config: Provider configuration
            api_key: API key for authentication
            method: HTTP method (GET, POST, etc.)
            path: API endpoint path
            data: Request body data
            params: URL query parameters
            timeout: Request timeout in seconds
            
        Returns:
            Parsed JSON response
            
        Raises:
            Various OrcaError subclasses on failure
        """
        url = self._build_url(provider_config, path, api_key)
        headers = self._build_headers(provider_config, api_key)
        timeout = timeout or self.config.timeout
        
        start_time = time.perf_counter()
        
        for attempt in range(self.config.max_retries + 1):
            try:
                response = self.session.request(
                    method=method,
                    url=url,
                    headers=headers,
                    json=data if data else None,
                    params=params,
                    timeout=(self.config.connect_timeout, timeout),
                )
                
                elapsed_ms = int((time.perf_counter() - start_time) * 1000)
                
                if response.status_code >= 400:
                    try:
                        error_data = response.json()
                    except json.JSONDecodeError:
                        error_data = {"error": response.text}
                    raise_for_status(
                        provider=provider_config.name,
                        status_code=response.status_code,
                        response_data=error_data,
                    )
                
                result = response.json()
                result["_orca_latency_ms"] = elapsed_ms
                return result
                
            except requests.exceptions.Timeout:
                if attempt == self.config.max_retries:
                    raise TimeoutError(
                        provider=provider_config.name,
                        timeout=timeout,
                    )
                self._wait_retry(attempt)
                
            except requests.exceptions.ConnectionError as e:
                if attempt == self.config.max_retries:
                    raise ConnectionError(
                        provider=provider_config.name,
                        message=f"Failed to connect: {e}",
                        original_error=e,
                    )
                self._wait_retry(attempt)
        
        # Should not reach here
        raise ConnectionError(
            provider=provider_config.name,
            message="Request failed after all retries",
        )
    
    def request_stream(
        self,
        provider_config: ProviderConfig,
        api_key: str,
        method: str,
        path: str,
        data: Optional[dict[str, Any]] = None,
        timeout: Optional[float] = None,
    ) -> Iterator[bytes]:
        """
        Make a streaming HTTP request.
        
        Args:
            provider_config: Provider configuration
            api_key: API key for authentication
            method: HTTP method
            path: API endpoint path
            data: Request body data
            timeout: Request timeout in seconds
            
        Yields:
            Raw byte chunks from the response
        """
        url = self._build_url(provider_config, path, api_key)
        headers = self._build_headers(provider_config, api_key)
        timeout = timeout or self.config.timeout
        
        try:
            with self.session.request(
                method=method,
                url=url,
                headers=headers,
                json=data,
                stream=True,
                timeout=(self.config.connect_timeout, timeout),
            ) as response:
                if response.status_code >= 400:
                    try:
                        error_data = response.json()
                    except json.JSONDecodeError:
                        error_data = {"error": response.text}
                    raise_for_status(
                        provider=provider_config.name,
                        status_code=response.status_code,
                        response_data=error_data,
                    )
                
                for chunk in response.iter_lines():
                    if chunk:
                        yield chunk
                        
        except requests.exceptions.Timeout:
            raise TimeoutError(
                provider=provider_config.name,
                timeout=timeout,
            )
        except requests.exceptions.ConnectionError as e:
            raise ConnectionError(
                provider=provider_config.name,
                message=f"Stream connection failed: {e}",
                original_error=e,
            )
    
    def _build_url(
        self,
        config: ProviderConfig,
        path: str,
        api_key: str,
    ) -> str:
        """Build the full request URL."""
        url = f"{config.base_url}{path}"
        if config.api_key_in_url:
            separator = "&" if "?" in url else "?"
            url = f"{url}{separator}key={api_key}"
        return url
    
    def _build_headers(
        self,
        config: ProviderConfig,
        api_key: str,
    ) -> dict[str, str]:
        """Build request headers with authentication."""
        headers = dict(config.default_headers)
        
        if config.auth_header and not config.api_key_in_url:
            headers[config.auth_header] = f"{config.auth_prefix}{api_key}"
        
        return headers
    
    def _wait_retry(self, attempt: int) -> None:
        """Wait before retry with exponential backoff."""
        delay = self.config.retry_delay * (2 ** attempt)
        logger.debug(f"Retrying in {delay:.1f}s (attempt {attempt + 1})")
        time.sleep(delay)
    
    def close(self) -> None:
        """Close the session."""
        if self._session:
            self._session.close()
            self._session = None


class AsyncRequestEngine:
    """
    Asynchronous HTTP request engine using aiohttp.
    
    Provides async versions of all request methods for
    non-blocking API calls.
    """
    
    def __init__(
        self,
        config: OrcaConfig,
    ) -> None:
        """
        Initialize the async request engine.
        
        Args:
            config: Global Orca configuration
        """
        self.config = config
        self._session = None
    
    async def _get_session(self):
        """Get or create the aiohttp session."""
        if self._session is None:
            import aiohttp
            timeout = aiohttp.ClientTimeout(
                total=self.config.timeout,
                connect=self.config.connect_timeout,
            )
            self._session = aiohttp.ClientSession(timeout=timeout)
        return self._session
    
    async def request(
        self,
        provider_config: ProviderConfig,
        api_key: str,
        method: str,
        path: str,
        data: Optional[dict[str, Any]] = None,
        params: Optional[dict[str, str]] = None,
        timeout: Optional[float] = None,
    ) -> dict[str, Any]:
        """
        Make an asynchronous HTTP request.
        
        Args:
            provider_config: Provider configuration
            api_key: API key for authentication
            method: HTTP method
            path: API endpoint path
            data: Request body data
            params: URL query parameters
            timeout: Request timeout in seconds
            
        Returns:
            Parsed JSON response
        """
        import aiohttp
        import asyncio
        
        url = self._build_url(provider_config, path, api_key)
        headers = self._build_headers(provider_config, api_key)
        
        session = await self._get_session()
        start_time = time.perf_counter()
        
        for attempt in range(self.config.max_retries + 1):
            try:
                async with session.request(
                    method=method,
                    url=url,
                    headers=headers,
                    json=data,
                    params=params,
                ) as response:
                    elapsed_ms = int((time.perf_counter() - start_time) * 1000)
                    
                    if response.status >= 400:
                        try:
                            error_data = await response.json()
                        except (json.JSONDecodeError, aiohttp.ContentTypeError):
                            error_data = {"error": await response.text()}
                        raise_for_status(
                            provider=provider_config.name,
                            status_code=response.status,
                            response_data=error_data,
                        )
                    
                    result = await response.json()
                    result["_orca_latency_ms"] = elapsed_ms
                    return result
                    
            except asyncio.TimeoutError:
                if attempt == self.config.max_retries:
                    raise TimeoutError(
                        provider=provider_config.name,
                        timeout=timeout or self.config.timeout,
                    )
                await self._wait_retry(attempt)
                
            except aiohttp.ClientError as e:
                if attempt == self.config.max_retries:
                    raise ConnectionError(
                        provider=provider_config.name,
                        message=f"Async request failed: {e}",
                        original_error=e,
                    )
                await self._wait_retry(attempt)
        
        raise ConnectionError(
            provider=provider_config.name,
            message="Request failed after all retries",
        )
    
    async def request_stream(
        self,
        provider_config: ProviderConfig,
        api_key: str,
        method: str,
        path: str,
        data: Optional[dict[str, Any]] = None,
        timeout: Optional[float] = None,
    ):
        """
        Make an async streaming HTTP request.
        
        Args:
            provider_config: Provider configuration
            api_key: API key for authentication
            method: HTTP method
            path: API endpoint path
            data: Request body data
            timeout: Request timeout in seconds
            
        Yields:
            Raw byte lines from the response
        """
        import aiohttp
        
        url = self._build_url(provider_config, path, api_key)
        headers = self._build_headers(provider_config, api_key)
        
        session = await self._get_session()
        
        try:
            async with session.request(
                method=method,
                url=url,
                headers=headers,
                json=data,
            ) as response:
                if response.status >= 400:
                    try:
                        error_data = await response.json()
                    except (json.JSONDecodeError, aiohttp.ContentTypeError):
                        error_data = {"error": await response.text()}
                    raise_for_status(
                        provider=provider_config.name,
                        status_code=response.status,
                        response_data=error_data,
                    )
                
                async for line in response.content:
                    line = line.strip()
                    if line:
                        yield line
                        
        except aiohttp.ClientError as e:
            raise ConnectionError(
                provider=provider_config.name,
                message=f"Async stream failed: {e}",
                original_error=e,
            )
    
    def _build_url(
        self,
        config: ProviderConfig,
        path: str,
        api_key: str,
    ) -> str:
        """Build the full request URL."""
        url = f"{config.base_url}{path}"
        if config.api_key_in_url:
            separator = "&" if "?" in url else "?"
            url = f"{url}{separator}key={api_key}"
        return url
    
    def _build_headers(
        self,
        config: ProviderConfig,
        api_key: str,
    ) -> dict[str, str]:
        """Build request headers with authentication."""
        headers = dict(config.default_headers)
        
        if config.auth_header and not config.api_key_in_url:
            headers[config.auth_header] = f"{config.auth_prefix}{api_key}"
        
        return headers
    
    async def _wait_retry(self, attempt: int) -> None:
        """Wait before retry with exponential backoff."""
        import asyncio
        delay = self.config.retry_delay * (2 ** attempt)
        logger.debug(f"Async retrying in {delay:.1f}s (attempt {attempt + 1})")
        await asyncio.sleep(delay)
    
    async def close(self) -> None:
        """Close the session."""
        if self._session:
            await self._session.close()
            self._session = None
