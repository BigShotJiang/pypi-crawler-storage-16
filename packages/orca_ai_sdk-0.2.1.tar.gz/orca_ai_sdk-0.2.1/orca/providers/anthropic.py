"""
Anthropic Provider Implementation

Full implementation of the Anthropic Claude API including:
- Messages API (streaming and non-streaming)
- Model listing
"""

from typing import Any, AsyncIterator, Iterator, Optional
import json
import copy

from ..utils.format import (
    normalize_anthropic_model,
    normalize_anthropic_response,
    normalize_anthropic_stream_chunk,
    translate_to_anthropic,
)
from ..utils.types import (
    Attachment,
    FunctionDeclaration,
    GenerationConfig,
    OrcaModel,
    OrcaResponse,
    OrcaStreamChunk,
    SafetySetting,
)
from .base import BaseProvider


class AnthropicProvider(BaseProvider):
    """Anthropic Claude API provider."""
    
    def chat(
        self,
        model: str,
        messages: list[dict[str, Any]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        system_instruction: Optional[str] = None,
        tools: Optional[list[FunctionDeclaration]] = None,
        safety_settings: Optional[list[SafetySetting]] = None,
        generation_config: Optional[GenerationConfig] = None,
        attachments: Optional[list[Attachment]] = None,
        **kwargs: Any,
    ) -> OrcaResponse | Iterator[OrcaStreamChunk]:
        """
        Send a message request to Anthropic.

        Args:
            model: Model identifier (e.g., "claude-3-opus")
            messages: Conversation messages
            temperature: Sampling temperature
            max_tokens: Maximum tokens to generate
            stream: Whether to stream the response
            system_instruction: System prompt (Anthropic supports this natively)
            tools: List of function/tool declarations for function calling
            safety_settings: Ignored for Anthropic (Gemini-specific)
            generation_config: Generation configuration with temperature/max_tokens
            attachments: Multi-modal attachments (Anthropic supports images)
            **kwargs: Additional Anthropic-specific parameters

        Returns:
            OrcaResponse or Iterator[OrcaStreamChunk] if streaming
        """
        # Use generation_config parameters if provided
        if generation_config:
            if temperature is None:
                temperature = generation_config.temperature
            if max_tokens is None:
                max_tokens = generation_config.max_output_tokens

        # Add attachments to the last user message if present
        if attachments:
            # Create deep copy to avoid mutating input
            messages = copy.deepcopy(messages) if messages else [{"role": "user", "content": ""}]

            # Validate last message is from user
            last_msg = messages[-1]
            if last_msg.get("role") != "user":
                raise ValueError("Attachments can only be added to user messages")

            # Handle the last message's content
            if isinstance(last_msg.get("content"), str):
                # Simple text content - convert to multimodal format
                text_content = last_msg["content"]
                content_parts = [{"type": "text", "text": text_content}]
                for attachment in attachments:
                    content_parts.append(attachment.to_anthropic())
                last_msg["content"] = content_parts
            elif isinstance(last_msg.get("content"), list):
                # Already multimodal - append attachments
                for attachment in attachments:
                    last_msg["content"].append(attachment.to_anthropic())

        payload = translate_to_anthropic(
            messages=messages, model=model, temperature=temperature,
            max_tokens=max_tokens, stream=stream, system_instruction=system_instruction,
            tools=tools, **kwargs,
        )

        if stream:
            return self._stream_chat(payload, model)

        response = self._make_request("chat", data=payload)
        latency = response.pop("_orca_latency_ms", 0)
        return normalize_anthropic_response(response, latency)
    
    async def chat_async(
        self,
        model: str,
        messages: list[dict[str, Any]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        system_instruction: Optional[str] = None,
        tools: Optional[list[FunctionDeclaration]] = None,
        safety_settings: Optional[list[SafetySetting]] = None,
        generation_config: Optional[GenerationConfig] = None,
        attachments: Optional[list[Attachment]] = None,
        **kwargs: Any,
    ) -> OrcaResponse | AsyncIterator[OrcaStreamChunk]:
        """
        Async message request to Anthropic.
        """
        # Use generation_config parameters if provided
        if generation_config:
            if temperature is None:
                temperature = generation_config.temperature
            if max_tokens is None:
                max_tokens = generation_config.max_output_tokens

        # Add attachments to the last user message if present
        if attachments:
            # Create deep copy to avoid mutating input
            messages = copy.deepcopy(messages) if messages else [{"role": "user", "content": ""}]

            # Validate last message is from user
            last_msg = messages[-1]
            if last_msg.get("role") != "user":
                raise ValueError("Attachments can only be added to user messages")

            # Handle the last message's content
            if isinstance(last_msg.get("content"), str):
                text_content = last_msg["content"]
                content_parts = [{"type": "text", "text": text_content}]
                for attachment in attachments:
                    content_parts.append(attachment.to_anthropic())
                last_msg["content"] = content_parts
            elif isinstance(last_msg.get("content"), list):
                for attachment in attachments:
                    last_msg["content"].append(attachment.to_anthropic())

        payload = translate_to_anthropic(
            messages=messages, model=model, temperature=temperature,
            max_tokens=max_tokens, stream=stream, system_instruction=system_instruction,
            tools=tools, **kwargs,
        )

        if stream:
            return self._stream_chat_async(payload, model)

        response = await self._make_request_async("chat", data=payload)
        latency = response.pop("_orca_latency_ms", 0)
        return normalize_anthropic_response(response, latency)
    
    def _stream_chat(self, payload: dict, model: str) -> Iterator[OrcaStreamChunk]:
        """Handle streaming message response."""
        raw_stream = self._make_stream_request("chat", data=payload)
        accumulated = ""
        current_event = None
        
        for raw_line in raw_stream:
            line = raw_line.decode("utf-8") if isinstance(raw_line, bytes) else raw_line
            line = line.strip()
            if not line:
                continue
            if line.startswith("event: "):
                current_event = line[7:]
                continue
            if line.startswith("data: "):
                try:
                    data = json.loads(line[6:])
                except json.JSONDecodeError:
                    continue
                chunk = normalize_anthropic_stream_chunk(current_event or "", data, model)
                accumulated += chunk.delta_text
                chunk.accumulated_text = accumulated
                if chunk.delta_text or chunk.is_final:
                    yield chunk
                if chunk.is_final:
                    return
    
    async def _stream_chat_async(self, payload: dict, model: str) -> AsyncIterator[OrcaStreamChunk]:
        """Handle async streaming."""
        raw_stream = self._make_stream_request_async("chat", data=payload)
        accumulated = ""
        current_event = None
        
        async for raw_line in raw_stream:
            line = raw_line.decode("utf-8") if isinstance(raw_line, bytes) else raw_line
            line = line.strip()
            if not line:
                continue
            if line.startswith("event: "):
                current_event = line[7:]
                continue
            if line.startswith("data: "):
                try:
                    data = json.loads(line[6:])
                except json.JSONDecodeError:
                    continue
                chunk = normalize_anthropic_stream_chunk(current_event or "", data, model)
                accumulated += chunk.delta_text
                chunk.accumulated_text = accumulated
                if chunk.delta_text or chunk.is_final:
                    yield chunk
                if chunk.is_final:
                    return
    
    def list_models(self) -> list[OrcaModel]:
        """Fetch available models from Anthropic."""
        response = self._make_request("models", method="GET")
        return [normalize_anthropic_model(m) for m in response.get("data", [])]
    
    async def list_models_async(self) -> list[OrcaModel]:
        """Async fetch available models."""
        response = await self._make_request_async("models", method="GET")
        return [normalize_anthropic_model(m) for m in response.get("data", [])]
