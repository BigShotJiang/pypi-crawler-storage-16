"""
OpenRouter Provider Implementation

OpenRouter provides access to multiple AI providers through a unified API.
Uses OpenAI-compatible format.
"""

from typing import Any, AsyncIterator, Iterator, Optional
import json

from ..core.streaming import AsyncStreamHandler, SyncStreamHandler
from ..utils.format import (
    normalize_openai_stream_chunk,
    normalize_openrouter_model,
    normalize_openrouter_response,
    translate_to_openrouter,
)
from ..utils.types import OrcaModel, OrcaResponse, OrcaStreamChunk
from .base import BaseProvider


class OpenRouterProvider(BaseProvider):
    """OpenRouter multi-provider gateway."""
    
    def chat(
        self,
        model: str,
        messages: list[dict[str, Any]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        **kwargs: Any,
    ) -> OrcaResponse | Iterator[OrcaStreamChunk]:
        """Send chat completion via OpenRouter."""
        payload = translate_to_openrouter(
            messages=messages, model=model, temperature=temperature,
            max_tokens=max_tokens, stream=stream, **kwargs,
        )
        
        if stream:
            return self._stream_chat(payload, model)
        
        response = self._make_request("chat", data=payload)
        latency = response.pop("_orca_latency_ms", 0)
        return normalize_openrouter_response(response, latency)
    
    async def chat_async(
        self,
        model: str,
        messages: list[dict[str, Any]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        **kwargs: Any,
    ) -> OrcaResponse | AsyncIterator[OrcaStreamChunk]:
        """Async chat completion."""
        payload = translate_to_openrouter(
            messages=messages, model=model, temperature=temperature,
            max_tokens=max_tokens, stream=stream, **kwargs,
        )
        
        if stream:
            return self._stream_chat_async(payload, model)
        
        response = await self._make_request_async("chat", data=payload)
        latency = response.pop("_orca_latency_ms", 0)
        return normalize_openrouter_response(response, latency)
    
    def _stream_chat(self, payload: dict, model: str) -> Iterator[OrcaStreamChunk]:
        """Handle streaming response."""
        raw_stream = self._make_stream_request("chat", data=payload)
        return SyncStreamHandler(
            raw_iterator=raw_stream, provider="openrouter",
            model=model, chunk_parser=normalize_openai_stream_chunk,
        )
    
    async def _stream_chat_async(self, payload: dict, model: str) -> AsyncIterator[OrcaStreamChunk]:
        """Handle async streaming."""
        raw_stream = self._make_stream_request_async("chat", data=payload)
        handler = AsyncStreamHandler(
            raw_iterator=raw_stream, provider="openrouter",
            model=model, chunk_parser=normalize_openai_stream_chunk,
        )
        async for chunk in handler:
            yield chunk
    
    def list_models(self) -> list[OrcaModel]:
        """Fetch available models from OpenRouter."""
        response = self._make_request("models", method="GET")
        return [normalize_openrouter_model(m) for m in response.get("data", [])]
    
    async def list_models_async(self) -> list[OrcaModel]:
        """Async fetch available models."""
        response = await self._make_request_async("models", method="GET")
        return [normalize_openrouter_model(m) for m in response.get("data", [])]
