# Orca SDK

> **The Orca SDK**  
> A provider-agnostic Python library for unified AI model interactions.  
> Read the [LICENSE](LICENSE) file for full terms and conditions.

**Orca** is a unified SDK for interacting with multiple AI providers through a single, consistent interface. It truly transforms the way developers work with AI by making it intuitive, efficient, and provider-agnostic.

## Core Features

- **Unified Interface** — Single API for OpenAI, Anthropic, Google Gemini, and OpenRouter
- **Sync + Async** — Full support for both synchronous and asynchronous operations
- **Streaming** — Real-time streaming responses with iterator interface
- **Dynamic Registry** — Automatic model discovery with parallel provider fetching
- **Typed Exceptions** — Precise error handling with provider context
- **Structured Responses** — Normalized responses across all providers

## Quick Start

### 1. Installation

```bash
# Install with pip
pip install orca-ai-sdk

# Or with uv
uv pip install orca-ai-sdk
```

### 2. Basic Usage

```python
from orca import Orca

# Initialize with providers
client = Orca(
    providers=["openai", "anthropic"],
    api_keys={
        "openai": "sk-...",
        "anthropic": "sk-ant-..."
    }
)

# Chat completion
response = client.chat(
    model="gpt-5",
    messages=[{"role": "user", "content": "Hello!"}]
)
print(response.text)

# Streaming
for chunk in client.chat(model="claude-opus-4.5", messages=messages, stream=True):
    print(chunk.delta_text, end="", flush=True)

# Embeddings
embedding = client.embed(model="text-embedding-3-small", input="Hello world")
print(f"Dimensions: {embedding.dimensions}")
```

## Supported Providers

| Provider | Chat | Embeddings | Images | Streaming |
|----------|------|------------|--------|-----------|
| OpenAI | ✅ | ✅ | ✅ | ✅ |
| Anthropic | ✅ | ❌ | ❌ | ✅ |
| Gemini | ✅ | ✅ | ❌ | ✅ |
| OpenRouter | ✅ | ❌ | ❌ | ✅ |

## Repository Structure

```text
orca/
├── orca/
│   ├── core/          # Core client & registry
│   ├── providers/     # Provider implementations
│   └── utils/         # Types & formatters
├── tests/             # Test suite
├── pyproject.toml     # Package configuration
└── README.md          # This file
```

## Team

*   **Alexutzu** — Developer

## License

Copyright © TreeSoft 2025. Released under the MIT License.  
See [LICENSE](LICENSE) for full terms and conditions.
