"""
Orca Client

Main entry point for the Orca SDK. Provides a unified interface
for interacting with multiple AI providers.
"""

import logging
import os
from typing import Any, AsyncIterator, Iterator, Optional, Union

from .config import (
    PROVIDER_CONFIGS,
    OrcaConfig,
    get_provider_config,
    list_supported_providers,
)
from .exceptions import ModelNotFoundError, ValidationError
from .pricing import PricingFetcher
from .registry import ModelRegistry
from .request import AsyncRequestEngine, SyncRequestEngine
from ..providers import (
    AnthropicProvider,
    BaseProvider,
    GeminiProvider,
    GoogleBetaProvider,
    OpenAIProvider,
    OpenRouterProvider,
)
from ..utils.types import (
    Attachment,
    FunctionDeclaration,
    GenerationConfig,
    OrcaEmbedding,
    OrcaImage,
    OrcaModel,
    OrcaResponse,
    OrcaStreamChunk,
    SafetySetting,
)

logger = logging.getLogger(__name__)

PROVIDER_CLASSES: dict[str, type[BaseProvider]] = {
    "openai": OpenAIProvider,
    "anthropic": AnthropicProvider,
    "gemini": GeminiProvider,
    "googlebeta": GoogleBetaProvider,
    "openrouter": OpenRouterProvider,
}


class Orca:
    """
    Unified client for interacting with multiple AI providers.
    
    Example:
        ```python
        from orca import Orca
        
        client = Orca(
            providers=["openai", "anthropic"],
            api_keys={"openai": "sk-...", "anthropic": "sk-ant-..."}
        )
        
        response = client.chat(
            model="gpt-4",
            messages=[{"role": "user", "content": "Hello!"}]
        )
        print(response.text)
        ```
    """
    
    def __init__(
        self,
        providers: Optional[list[str]] = None,
        api_keys: Optional[dict[str, str]] = None,
        config: Optional[OrcaConfig] = None,
        lazy_init: bool = False,
    ) -> None:
        """
        Initialize the Orca client.
        
        Args:
            providers: List of provider names to enable
            api_keys: Mapping of provider name to API key
            config: Optional OrcaConfig for global settings
            lazy_init: If True, defer model registry initialization
        """
        self.config = config or OrcaConfig()
        self._api_keys = api_keys or {}
        self._providers: dict[str, BaseProvider] = {}
        self._registry = ModelRegistry()
        self._sync_engine = SyncRequestEngine(self.config)
        self._async_engine: Optional[AsyncRequestEngine] = None
        
        # Pricing and cost tracking
        self._pricing_fetcher = PricingFetcher(cache_ttl=self.config.cache_ttl)
        self._session_cost: float = 0.0
        
        # Load API keys from environment if not provided
        for provider in (providers or []):
            if provider not in self._api_keys:
                env_key = PROVIDER_CONFIGS.get(provider, {})
                if hasattr(env_key, 'api_key_env'):
                    env_var = env_key.api_key_env
                    if env_var and os.environ.get(env_var):
                        self._api_keys[provider] = os.environ[env_var]
        
        # Initialize providers
        enabled = providers or list(self._api_keys.keys())
        for provider_name in enabled:
            self._init_provider(provider_name)
        
        # Initialize model registry
        if not lazy_init and self._providers:
            self._init_registry()
    
    def _init_provider(self, name: str) -> None:
        """Initialize a single provider."""
        name = name.lower()
        
        if name not in PROVIDER_CLASSES:
            raise ValidationError(
                f"Unknown provider: {name}. Supported: {list_supported_providers()}"
            )
        
        api_key = self._api_keys.get(name)
        if not api_key:
            provider_config = get_provider_config(name)
            api_key = os.environ.get(provider_config.api_key_env, "")
        
        if not api_key:
            logger.warning(f"No API key for {name}, provider will be unavailable")
            return
        
        provider_class = PROVIDER_CLASSES[name]
        provider_config = get_provider_config(name)
        
        self._providers[name] = provider_class(
            api_key=api_key,
            config=self.config,
            provider_config=provider_config,
            sync_engine=self._sync_engine,
            async_engine=self._async_engine,
        )
        logger.debug(f"Initialized provider: {name}")
    
    def _init_registry(self) -> None:
        """Initialize the model registry from all providers."""
        fetchers = {
            name: provider.list_models
            for name, provider in self._providers.items()
        }
        
        if fetchers:
            try:
                self._registry.initialize_parallel(fetchers)
            except Exception as e:
                logger.error(f"Failed to initialize model registry: {e}")
    
    def _get_async_engine(self) -> AsyncRequestEngine:
        """Get or create the async engine."""
        if self._async_engine is None:
            self._async_engine = AsyncRequestEngine(self.config)
        return self._async_engine
    
    def _resolve_provider(self, model: str) -> BaseProvider:
        """Resolve model to provider and return provider instance."""
        # First check registry
        provider_name = self._registry.get_provider(model)
        
        if not provider_name:
            # Try to infer from model name patterns
            provider_name = self._infer_provider(model)
        
        if not provider_name:
            available = self._registry.list_models()[:10]
            raise ModelNotFoundError(
                model=model,
                available_models=[m.id for m in available],
            )
        
        if provider_name not in self._providers:
            raise ValidationError(f"Provider '{provider_name}' not initialized")
        
        return self._providers[provider_name]
    
    def _infer_provider(self, model: str) -> Optional[str]:
        """Infer provider from model name patterns."""
        model_lower = model.lower()
        
        if any(p in model_lower for p in ["gpt", "davinci", "dall-e", "whisper", "o1", "o3"]):
            return "openai"
        if any(p in model_lower for p in ["claude"]):
            return "anthropic"
        if any(p in model_lower for p in ["gemini", "palm"]):
            return "gemini"
        if "/" in model:
            return "openrouter"
        
        return None
    
    # =========================================================================
    # Public API - Chat
    # =========================================================================
    
    def chat(
        self,
        model: str,
        messages: list[dict[str, Any]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        system_instruction: Optional[str] = None,
        tools: Optional[list[FunctionDeclaration]] = None,
        safety_settings: Optional[list[SafetySetting]] = None,
        generation_config: Optional[GenerationConfig] = None,
        attachments: Optional[list[Attachment]] = None,
        **kwargs: Any,
    ) -> Union[OrcaResponse, Iterator[OrcaStreamChunk]]:
        """
        Send a chat completion request.

        Args:
            model: Model identifier (e.g., "gpt-4", "claude-3-opus")
            messages: List of conversation messages
            temperature: Sampling temperature
            max_tokens: Maximum tokens to generate
            stream: Whether to stream the response
            system_instruction: System prompt (provider-specific)
            tools: List of function/tool declarations
            safety_settings: Safety settings (Gemini-specific)
            generation_config: Generation configuration
            attachments: Multi-modal attachments
            **kwargs: Additional provider-specific arguments

        Returns:
            OrcaResponse or Iterator[OrcaStreamChunk] if streaming
        """
        provider = self._resolve_provider(model)
        result = provider.chat(
            model=model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=stream,
            system_instruction=system_instruction,
            tools=tools,
            safety_settings=safety_settings,
            generation_config=generation_config,
            attachments=attachments,
            **kwargs,
        )
        
        # Inject cost into response
        if not stream and isinstance(result, OrcaResponse):
            self._add_cost_to_response(result)
        
        return result
    
    async def chat_async(
        self,
        model: str,
        messages: list[dict[str, Any]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        system_instruction: Optional[str] = None,
        tools: Optional[list[FunctionDeclaration]] = None,
        safety_settings: Optional[list[SafetySetting]] = None,
        generation_config: Optional[GenerationConfig] = None,
        attachments: Optional[list[Attachment]] = None,
        **kwargs: Any,
    ) -> Union[OrcaResponse, AsyncIterator[OrcaStreamChunk]]:
        """Async version of chat()."""
        provider = self._resolve_provider(model)

        # Ensure async engine is available
        if provider.async_engine is None:
            provider.async_engine = self._get_async_engine()

        return await provider.chat_async(
            model=model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=stream,
            system_instruction=system_instruction,
            tools=tools,
            safety_settings=safety_settings,
            generation_config=generation_config,
            attachments=attachments,
            **kwargs,
        )
    
    # =========================================================================
    # Public API - Embeddings
    # =========================================================================
    
    def embed(
        self,
        model: str,
        input: Union[str, list[str]],
        **kwargs: Any,
    ) -> OrcaEmbedding:
        """
        Generate embeddings for text.
        
        Args:
            model: Embedding model identifier
            input: Text or list of texts to embed
            **kwargs: Additional arguments
            
        Returns:
            OrcaEmbedding with vectors
        """
        provider = self._resolve_provider(model)
        return provider.embed(model=model, input=input, **kwargs)
    
    async def embed_async(
        self,
        model: str,
        input: Union[str, list[str]],
        **kwargs: Any,
    ) -> OrcaEmbedding:
        """Async version of embed()."""
        provider = self._resolve_provider(model)
        if provider.async_engine is None:
            provider.async_engine = self._get_async_engine()
        return await provider.embed_async(model=model, input=input, **kwargs)
    
    # =========================================================================
    # Public API - Images
    # =========================================================================
    
    def generate_image(
        self,
        model: str,
        prompt: str,
        n: int = 1,
        size: str = "1024x1024",
        **kwargs: Any,
    ) -> OrcaImage:
        """
        Generate images from a prompt.
        
        Args:
            model: Image model identifier (e.g., "dall-e-3")
            prompt: Text description of the image
            n: Number of images to generate
            size: Image dimensions
            **kwargs: Additional arguments
            
        Returns:
            OrcaImage with URLs or base64 data
        """
        provider = self._resolve_provider(model)
        return provider.generate_image(
            model=model, prompt=prompt, n=n, size=size, **kwargs
        )
    
    async def generate_image_async(
        self,
        model: str,
        prompt: str,
        n: int = 1,
        size: str = "1024x1024",
        **kwargs: Any,
    ) -> OrcaImage:
        """Async version of generate_image()."""
        provider = self._resolve_provider(model)
        if provider.async_engine is None:
            provider.async_engine = self._get_async_engine()
        return await provider.generate_image_async(
            model=model, prompt=prompt, n=n, size=size, **kwargs
        )
    
    # =========================================================================
    # Public API - Models
    # =========================================================================
    
    def list_models(self, provider: Optional[str] = None) -> list[OrcaModel]:
        """
        List available models.
        
        Args:
            provider: Optional filter by provider
            
        Returns:
            List of OrcaModel instances
        """
        return self._registry.list_models(provider)
    
    def get_model(self, model_id: str) -> Optional[OrcaModel]:
        """Get model information by ID."""
        return self._registry.get(model_id)
    
    def search_models(self, query: str) -> list[OrcaModel]:
        """Search models by name/ID."""
        return self._registry.search(query)
    
    # =========================================================================
    # Public API - Pricing & Cost Tracking
    # =========================================================================
    
    def get_model_pricing(self, model: str) -> Optional[dict[str, Any]]:
        """
        Get pricing information for a model.
        
        Args:
            model: Model identifier
        
        Returns:
            Dictionary with pricing info, or None if not available
        """
        pricing = self._pricing_fetcher.get_pricing(model)
        if pricing:
            return pricing.to_dict()
        return None
    
    def get_session_cost(self) -> float:
        """
        Get total cost for all requests in this session.
        
        Returns:
            Total cost in USD
        """
        return self._session_cost
    
    def reset_session_cost(self) -> None:
        """Reset the session cost counter to zero."""
        self._session_cost = 0.0
    
    def _add_cost_to_response(self, response: OrcaResponse) -> None:
        """Calculate and add cost to a response object."""
        if response.tokens_used:
            cost = self._pricing_fetcher.calculate_cost(
                model_id=response.model,
                input_tokens=response.tokens_used.prompt_tokens,
                output_tokens=response.tokens_used.completion_tokens,
                cached_tokens=response.tokens_used.cached_tokens or 0,
            )
            if cost is not None:
                response.cost = cost
                self._session_cost += cost
    
    # =========================================================================
    # Lifecycle
    # =========================================================================
    
    def refresh_models(self) -> None:
        """Refresh the model registry from all providers."""
        self._registry.clear()
        self._init_registry()
    
    def close(self) -> None:
        """Close all connections and clean up resources."""
        self._sync_engine.close()
    
    async def close_async(self) -> None:
        """Async cleanup."""
        if self._async_engine:
            await self._async_engine.close()
    
    def __enter__(self) -> "Orca":
        return self
    
    def __exit__(self, *args) -> None:
        self.close()
    
    async def __aenter__(self) -> "Orca":
        return self
    
    async def __aexit__(self, *args) -> None:
        await self.close_async()
