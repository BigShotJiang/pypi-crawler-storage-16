"""
Orca Pricing Module

Handles dynamic pricing fetching, cost calculation, and pricing database.
"""

import logging
from datetime import datetime, timedelta
from typing import Any, Optional

logger = logging.getLogger(__name__)


# Pricing database - fallback for models without API pricing
# Prices are per 1M tokens (input/output)
PRICING_DATABASE = {
    # OpenAI Models
    "gpt-4o": {"input": 2.50, "output": 10.00},
    "gpt-4o-2024-11-20": {"input": 2.50, "output": 10.00},
    "gpt-4o-2024-08-06": {"input": 2.50, "output": 10.00},
    "gpt-4o-2024-05-13": {"input": 5.00, "output": 15.00},
    "gpt-4o-mini": {"input": 0.150, "output": 0.600},
    "gpt-4o-mini-2024-07-18": {"input": 0.150, "output": 0.600},
    "gpt-4-turbo": {"input": 10.00, "output": 30.00},
    "gpt-4-turbo-2024-04-09": {"input": 10.00, "output": 30.00},
    "gpt-4": {"input": 30.00, "output": 60.00},
    "gpt-4-0613": {"input": 30.00, "output": 60.00},
    "gpt-4-32k": {"input": 60.00, "output": 120.00},
    "gpt-3.5-turbo": {"input": 0.50, "output": 1.50},
    "gpt-3.5-turbo-0125": {"input": 0.50, "output": 1.50},
    "gpt-3.5-turbo-1106": {"input": 1.00, "output": 2.00},
    "o1": {"input": 15.00, "output": 60.00},
    "o1-2024-12-17": {"input": 15.00, "output": 60.00},
    "o1-mini": {"input": 3.00, "output": 12.00},
    "o1-mini-2024-09-12": {"input": 3.00, "output": 12.00},
    "o1-preview": {"input": 15.00, "output": 60.00},
    "o1-preview-2024-09-12": {"input": 15.00, "output": 60.00},
    
    # OpenAI Embeddings
    "text-embedding-3-small": {"input": 0.020, "output": 0.0},
    "text-embedding-3-large": {"input": 0.130, "output": 0.0},
    "text-embedding-ada-002": {"input": 0.100, "output": 0.0},
    
    # Anthropic Models
    "claude-opus-4-20250514": {"input": 15.00, "output": 75.00},
    "claude-opus-4": {"input": 15.00, "output": 75.00},
    "claude-3-5-sonnet-20241022": {"input": 3.00, "output": 15.00},
    "claude-3-5-sonnet-20240620": {"input": 3.00, "output": 15.00},
    "claude-3-5-haiku-20241022": {"input": 0.80, "output": 4.00},
    "claude-3-opus-20240229": {"input": 15.00, "output": 75.00},
    "claude-3-sonnet-20240229": {"input": 3.00, "output": 15.00},
    "claude-3-haiku-20240307": {"input": 0.25, "output": 1.25},
    
    # Google Gemini Models
    "gemini-2.0-flash-exp": {"input": 0.075, "output": 0.30},
    "gemini-2.0-flash-thinking-exp-1219": {"input": 0.075, "output": 0.30},
    "gemini-1.5-pro": {"input": 1.25, "output": 5.00},
    "gemini-1.5-pro-002": {"input": 1.25, "output": 5.00},
    "gemini-1.5-flash": {"input": 0.075, "output": 0.30},
    "gemini-1.5-flash-002": {"input": 0.075, "output": 0.30},
    "gemini-1.5-flash-8b": {"input": 0.0375, "output": 0.15},
    "gemini-1.0-pro": {"input": 0.50, "output": 1.50},
    
    # Gemini Embeddings
    "text-embedding-004": {"input": 0.00001, "output": 0.0},
    
    # Aliases for common names
    "gpt-5": {"input": 2.50, "output": 10.00},  # Alias for gpt-4o
    "claude-opus-4.5": {"input": 15.00, "output": 75.00},  # Future model placeholder
}


class ModelPricing:
    """Represents pricing information for a model."""
    
    def __init__(
        self,
        model_id: str,
        input_price: float,
        output_price: float,
        currency: str = "USD",
        per_tokens: int = 1_000_000,
        cached_input_price: Optional[float] = None,
    ):
        """
        Initialize model pricing.
        
        Args:
            model_id: Model identifier
            input_price: Price per input tokens
            output_price: Price per output tokens
            currency: Currency code (default USD)
            per_tokens: Number of tokens the price is for (default 1M)
            cached_input_price: Optional price for cached input tokens
        """
        self.model_id = model_id
        self.input_price = input_price
        self.output_price = output_price
        self.currency = currency
        self.per_tokens = per_tokens
        self.cached_input_price = cached_input_price or (input_price * 0.1)  # 90% discount
    
    def calculate_cost(
        self,
        input_tokens: int,
        output_tokens: int,
        cached_tokens: int = 0,
    ) -> float:
        """
        Calculate cost for given token usage.
        
        Args:
            input_tokens: Number of input tokens
            output_tokens: Number of output tokens
            cached_tokens: Number of cached input tokens
        
        Returns:
            Total cost in USD
        """
        # Calculate regular input tokens (excluding cached)
        regular_input = input_tokens - cached_tokens
        
        input_cost = (regular_input / self.per_tokens) * self.input_price
        output_cost = (output_tokens / self.per_tokens) * self.output_price
        cached_cost = (cached_tokens / self.per_tokens) * self.cached_input_price
        
        return input_cost + output_cost + cached_cost
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "model_id": self.model_id,
            "input_price_per_1m": self.input_price,
            "output_price_per_1m": self.output_price,
            "cached_input_price_per_1m": self.cached_input_price,
            "currency": self.currency,
        }


class PricingCache:
    """Simple TTL cache for pricing data."""
    
    def __init__(self, ttl_seconds: float = 3600.0):
        """
        Initialize cache.
        
        Args:
            ttl_seconds: Time-to-live for cache entries (default 1 hour)
        """
        self.ttl_seconds = ttl_seconds
        self._cache: dict[str, tuple[ModelPricing, datetime]] = {}
    
    def get(self, model_id: str) -> Optional[ModelPricing]:
        """Get pricing from cache if not expired."""
        if model_id in self._cache:
            pricing, timestamp = self._cache[model_id]
            if datetime.now() - timestamp < timedelta(seconds=self.ttl_seconds):
                return pricing
            else:
                # Expired, remove from cache
                del self._cache[model_id]
        return None
    
    def set(self, model_id: str, pricing: ModelPricing) -> None:
        """Store pricing in cache."""
        self._cache[model_id] = (pricing, datetime.now())
    
    def clear(self) -> None:
        """Clear all cache entries."""
        self._cache.clear()


class PricingFetcher:
    """Fetches and manages pricing information for models."""
    
    def __init__(self, cache_ttl: float = 3600.0):
        """
        Initialize pricing fetcher.
        
        Args:
            cache_ttl: Cache time-to-live in seconds
        """
        self.cache = PricingCache(ttl_seconds=cache_ttl)
        self.pricing_db = PRICING_DATABASE.copy()
    
    def get_pricing(self, model_id: str) -> Optional[ModelPricing]:
        """
        Get pricing for a model.
        
        First checks cache, then pricing database, then tries to fetch from provider.
        
        Args:
            model_id: Model identifier
        
        Returns:
            ModelPricing if found, None otherwise
        """
        # Check cache first
        cached = self.cache.get(model_id)
        if cached:
            return cached
        
        # Check pricing database
        if model_id in self.pricing_db:
            pricing_data = self.pricing_db[model_id]
            pricing = ModelPricing(
                model_id=model_id,
                input_price=pricing_data["input"],
                output_price=pricing_data["output"],
            )
            self.cache.set(model_id, pricing)
            return pricing
        
        # Try without version suffix (e.g., "gpt-4o-2024-11-20" -> "gpt-4o")
        base_model = self._get_base_model_name(model_id)
        if base_model != model_id and base_model in self.pricing_db:
            pricing_data = self.pricing_db[base_model]
            pricing = ModelPricing(
                model_id=model_id,
                input_price=pricing_data["input"],
                output_price=pricing_data["output"],
            )
            self.cache.set(model_id, pricing)
            return pricing
        
        logger.warning(f"No pricing information found for model: {model_id}")
        return None
    
    def calculate_cost(
        self,
        model_id: str,
        input_tokens: int,
        output_tokens: int,
        cached_tokens: int = 0,
    ) -> Optional[float]:
        """
        Calculate cost for a request.
        
        Args:
            model_id: Model identifier
            input_tokens: Number of input tokens
            output_tokens: Number of output tokens
            cached_tokens: Number of cached input tokens
        
        Returns:
            Cost in USD, or None if pricing not available
        """
        pricing = self.get_pricing(model_id)
        if not pricing:
            return None
        
        return pricing.calculate_cost(input_tokens, output_tokens, cached_tokens)
    
    def add_custom_pricing(
        self,
        model_id: str,
        input_price: float,
        output_price: float,
    ) -> None:
        """
        Add custom pricing for a model.
        
        Args:
            model_id: Model identifier
            input_price: Price per 1M input tokens
            output_price: Price per 1M output tokens
        """
        self.pricing_db[model_id] = {
            "input": input_price,
            "output": output_price,
        }
        # Clear cache for this model to force refresh
        if model_id in self.cache._cache:
            del self.cache._cache[model_id]
    
    def _get_base_model_name(self, model_id: str) -> str:
        """
        Extract base model name by removing version suffixes.
        
        Examples:
            "gpt-4o-2024-11-20" -> "gpt-4o"
            "claude-3-opus-20240229" -> "claude-3-opus"
        """
        # Remove date patterns like -YYYY-MM-DD or -YYYYMMDD
        parts = model_id.split("-")
        result = []
        
        for part in parts:
            # Skip if part looks like a date (4+ digits or matches YYYY-MM-DD pattern)
            if len(part) >= 4 and part.isdigit():
                break
            result.append(part)
        
        base = "-".join(result) if result else model_id
        return base if base else model_id


class CostCalculator:
    """
    Helper class for calculating costs from token usage.
    """
    
    def __init__(self, pricing_fetcher: PricingFetcher):
        """
        Initialize cost calculator.
        
        Args:
            pricing_fetcher: PricingFetcher instance
        """
        self.pricing_fetcher = pricing_fetcher
    
    def calculate(
        self,
        model_id: str,
        prompt_tokens: int,
        completion_tokens: int,
        cached_tokens: int = 0,
    ) -> Optional[float]:
        """
        Calculate cost from token counts.
        
        Args:
            model_id: Model identifier
            prompt_tokens: Input token count
            completion_tokens: Output token count
            cached_tokens: Cached input token count
        
        Returns:
            Cost in USD, or None if pricing unavailable
        """
        return self.pricing_fetcher.calculate_cost(
            model_id=model_id,
            input_tokens=prompt_tokens,
            output_tokens=completion_tokens,
            cached_tokens=cached_tokens,
        )
