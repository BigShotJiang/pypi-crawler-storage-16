"""
Orca Model Registry

Dynamic registry that aggregates models from all enabled providers.
Uses threaded parallel fetching for fast initialization.
"""

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from ..utils.threads import ThreadedModelFetcher
from ..utils.types import OrcaModel

logger = logging.getLogger(__name__)


@dataclass
class ModelEntry:
    """Entry in the model registry."""
    model: OrcaModel
    provider: str
    aliases: list[str] = field(default_factory=list)


class ModelRegistry:
    """
    Centralized model registry with parallel initialization.
    
    Aggregates models from all enabled providers into a unified
    lookup table for routing requests.
    """
    
    def __init__(self) -> None:
        self._models: dict[str, ModelEntry] = {}
        self._by_provider: dict[str, list[str]] = {}
        self._initialized: bool = False
        self._init_time_ms: float = 0
    
    @property
    def is_initialized(self) -> bool:
        """Check if registry has been populated."""
        return self._initialized
    
    @property
    def model_count(self) -> int:
        """Total number of registered models."""
        return len(self._models)
    
    def initialize_parallel(
        self,
        fetchers: dict[str, Callable[[], list[OrcaModel]]],
        timeout: float = 30.0,
    ) -> dict[str, int]:
        """
        Initialize registry by fetching models from all providers in parallel.
        
        Args:
            fetchers: Mapping of provider name to model fetch function
            timeout: Overall timeout for fetching
            
        Returns:
            Mapping of provider name to number of models fetched
        """
        start = time.perf_counter()
        
        # Convert to raw dict fetchers
        def make_fetcher(fn):
            def fetch():
                models = fn()
                return [m.model_dump() for m in models]
            return fetch
        
        raw_fetchers = {p: make_fetcher(f) for p, f in fetchers.items()}
        
        fetcher = ThreadedModelFetcher(timeout=timeout)
        results = fetcher.fetch_all(raw_fetchers)
        
        counts: dict[str, int] = {}
        
        for provider, result in results.items():
            if result.success:
                for model_data in result.models:
                    model = OrcaModel.model_validate(model_data)
                    self.register(model)
                counts[provider] = len(result.models)
                logger.info(f"Loaded {len(result.models)} models from {provider}")
            else:
                counts[provider] = 0
                logger.warning(f"Failed to load models from {provider}: {result.error}")
        
        self._initialized = True
        self._init_time_ms = (time.perf_counter() - start) * 1000
        logger.info(f"Registry initialized in {self._init_time_ms:.1f}ms with {self.model_count} models")
        
        return counts
    
    def register(self, model: OrcaModel, aliases: Optional[list[str]] = None) -> None:
        """
        Register a model in the registry.
        
        Args:
            model: OrcaModel instance
            aliases: Optional list of alias names
        """
        entry = ModelEntry(
            model=model,
            provider=model.provider,
            aliases=aliases or [],
        )
        
        self._models[model.id] = entry
        
        if model.provider not in self._by_provider:
            self._by_provider[model.provider] = []
        self._by_provider[model.provider].append(model.id)
        
        # Register aliases
        for alias in (aliases or []):
            self._models[alias] = entry
    
    def get(self, model_id: str) -> Optional[OrcaModel]:
        """Get a model by ID or alias."""
        entry = self._models.get(model_id)
        return entry.model if entry else None
    
    def get_provider(self, model_id: str) -> Optional[str]:
        """Get the provider for a model."""
        entry = self._models.get(model_id)
        return entry.provider if entry else None
    
    def resolve(self, model_id: str) -> tuple[str, str]:
        """
        Resolve a model ID to its canonical form and provider.
        
        Args:
            model_id: Model ID or alias
            
        Returns:
            Tuple of (canonical_id, provider)
            
        Raises:
            KeyError: If model not found
        """
        entry = self._models.get(model_id)
        if not entry:
            raise KeyError(f"Model '{model_id}' not found in registry")
        return entry.model.id, entry.provider
    
    def list_models(self, provider: Optional[str] = None) -> list[OrcaModel]:
        """
        List all registered models.
        
        Args:
            provider: Optional filter by provider
            
        Returns:
            List of OrcaModel instances
        """
        if provider:
            model_ids = self._by_provider.get(provider, [])
            return [self._models[mid].model for mid in model_ids]
        
        # Return unique models (not aliases)
        seen = set()
        models = []
        for entry in self._models.values():
            if entry.model.id not in seen:
                seen.add(entry.model.id)
                models.append(entry.model)
        return models
    
    def list_providers(self) -> list[str]:
        """List all providers with registered models."""
        return list(self._by_provider.keys())
    
    def search(self, query: str) -> list[OrcaModel]:
        """
        Search models by name/ID substring.
        
        Args:
            query: Search query (case-insensitive)
            
        Returns:
            Matching models
        """
        query = query.lower()
        results = []
        seen = set()
        
        for model_id, entry in self._models.items():
            if entry.model.id in seen:
                continue
            if query in model_id.lower() or (entry.model.name and query in entry.model.name.lower()):
                results.append(entry.model)
                seen.add(entry.model.id)
        
        return results
    
    def clear(self) -> None:
        """Clear all registered models."""
        self._models.clear()
        self._by_provider.clear()
        self._initialized = False
