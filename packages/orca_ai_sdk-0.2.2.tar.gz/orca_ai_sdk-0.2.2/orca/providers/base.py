"""
Orca Base Provider

Abstract base class for all AI provider implementations.
Defines the common interface and shared functionality.
"""

from abc import ABC, abstractmethod
from typing import Any, AsyncIterator, Iterator, Optional

from ..core.config import OrcaConfig, ProviderConfig
from ..core.request import AsyncRequestEngine, SyncRequestEngine
from ..utils.types import (
    Attachment,
    FunctionDeclaration,
    GenerationConfig,
    OrcaEmbedding,
    OrcaImage,
    OrcaModel,
    OrcaResponse,
    OrcaStreamChunk,
    SafetySetting,
)


class BaseProvider(ABC):
    """
    Abstract base class for AI provider implementations.
    
    Each provider must implement:
    - chat() / chat_async() - Chat completions
    - list_models() / list_models_async() - Model enumeration
    
    Optional implementations:
    - embed() / embed_async() - Text embeddings
    - generate_image() / generate_image_async() - Image generation
    """
    
    def __init__(
        self,
        api_key: str,
        config: OrcaConfig,
        provider_config: ProviderConfig,
        sync_engine: SyncRequestEngine,
        async_engine: Optional[AsyncRequestEngine] = None,
    ) -> None:
        """
        Initialize the provider.
        
        Args:
            api_key: API key for authentication
            config: Global Orca configuration
            provider_config: Provider-specific configuration
            sync_engine: Synchronous request engine
            async_engine: Asynchronous request engine (optional)
        """
        self.api_key = api_key
        self.config = config
        self.provider_config = provider_config
        self.sync_engine = sync_engine
        self.async_engine = async_engine
    
    @property
    def name(self) -> str:
        """Provider name."""
        return self.provider_config.name
    
    # =========================================================================
    # Abstract Methods - Must be implemented by each provider
    # =========================================================================
    
    @abstractmethod
    def chat(
        self,
        model: str,
        messages: list[dict[str, Any]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        system_instruction: Optional[str] = None,
        tools: Optional[list[FunctionDeclaration]] = None,
        safety_settings: Optional[list[SafetySetting]] = None,
        generation_config: Optional[GenerationConfig] = None,
        attachments: Optional[list[Attachment]] = None,
        **kwargs: Any,
    ) -> OrcaResponse | Iterator[OrcaStreamChunk]:
        """
        Send a chat completion request.

        Args:
            model: Model identifier
            messages: List of conversation messages
            temperature: Sampling temperature
            max_tokens: Maximum tokens to generate
            stream: Whether to stream the response
            system_instruction: System prompt (provider-specific)
            tools: List of function/tool declarations
            safety_settings: Safety settings (Gemini-specific)
            generation_config: Generation configuration
            attachments: Multi-modal attachments
            **kwargs: Additional provider-specific arguments

        Returns:
            OrcaResponse or Iterator[OrcaStreamChunk] if streaming
        """
        pass
    
    @abstractmethod
    async def chat_async(
        self,
        model: str,
        messages: list[dict[str, Any]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        system_instruction: Optional[str] = None,
        tools: Optional[list[FunctionDeclaration]] = None,
        safety_settings: Optional[list[SafetySetting]] = None,
        generation_config: Optional[GenerationConfig] = None,
        attachments: Optional[list[Attachment]] = None,
        **kwargs: Any,
    ) -> OrcaResponse | AsyncIterator[OrcaStreamChunk]:
        """Async version of chat()."""
        pass
    
    @abstractmethod
    def list_models(self) -> list[OrcaModel]:
        """
        Fetch available models from this provider.
        
        Returns:
            List of OrcaModel objects
        """
        pass
    
    @abstractmethod
    async def list_models_async(self) -> list[OrcaModel]:
        """Async version of list_models()."""
        pass
    
    # =========================================================================
    # Optional Methods - Not all providers support these
    # =========================================================================
    
    def embed(
        self,
        model: str,
        input: str | list[str],
        **kwargs: Any,
    ) -> OrcaEmbedding:
        """
        Generate embeddings for text.
        
        Args:
            model: Embedding model identifier
            input: Text or list of texts to embed
            **kwargs: Additional arguments
            
        Returns:
            OrcaEmbedding with vectors
            
        Raises:
            NotImplementedError if provider doesn't support embeddings
        """
        raise NotImplementedError(
            f"Provider '{self.name}' does not support embeddings"
        )
    
    async def embed_async(
        self,
        model: str,
        input: str | list[str],
        **kwargs: Any,
    ) -> OrcaEmbedding:
        """Async version of embed()."""
        raise NotImplementedError(
            f"Provider '{self.name}' does not support embeddings"
        )
    
    def generate_image(
        self,
        model: str,
        prompt: str,
        n: int = 1,
        size: str = "1024x1024",
        **kwargs: Any,
    ) -> OrcaImage:
        """
        Generate images from a prompt.
        
        Args:
            model: Image model identifier
            prompt: Text prompt
            n: Number of images to generate
            size: Image dimensions
            **kwargs: Additional arguments
            
        Returns:
            OrcaImage with generated image URLs
            
        Raises:
            NotImplementedError if provider doesn't support images
        """
        raise NotImplementedError(
            f"Provider '{self.name}' does not support image generation"
        )
    
    async def generate_image_async(
        self,
        model: str,
        prompt: str,
        n: int = 1,
        size: str = "1024x1024",
        **kwargs: Any,
    ) -> OrcaImage:
        """Async version of generate_image()."""
        raise NotImplementedError(
            f"Provider '{self.name}' does not support image generation"
        )
    
    # =========================================================================
    # Helper Methods
    # =========================================================================
    
    def _make_request(
        self,
        endpoint: str,
        data: Optional[dict[str, Any]] = None,
        method: str = "POST",
        path_params: Optional[dict[str, str]] = None,
    ) -> dict[str, Any]:
        """
        Make a synchronous API request.
        
        Args:
            endpoint: Endpoint name from provider config
            data: Request body
            method: HTTP method
            path_params: Parameters to substitute in path
            
        Returns:
            Parsed response data
        """
        endpoint_config = self.provider_config.endpoints.get(endpoint)
        if not endpoint_config:
            raise ValueError(f"Unknown endpoint: {endpoint}")
        
        path = endpoint_config.path
        if path_params:
            for key, value in path_params.items():
                path = path.replace(f"{{{key}}}", value)
        
        return self.sync_engine.request(
            provider_config=self.provider_config,
            api_key=self.api_key,
            method=method or endpoint_config.method,
            path=path,
            data=data,
        )
    
    async def _make_request_async(
        self,
        endpoint: str,
        data: Optional[dict[str, Any]] = None,
        method: str = "POST",
        path_params: Optional[dict[str, str]] = None,
    ) -> dict[str, Any]:
        """Async version of _make_request()."""
        if not self.async_engine:
            raise RuntimeError("Async engine not initialized")
        
        endpoint_config = self.provider_config.endpoints.get(endpoint)
        if not endpoint_config:
            raise ValueError(f"Unknown endpoint: {endpoint}")
        
        path = endpoint_config.path
        if path_params:
            for key, value in path_params.items():
                path = path.replace(f"{{{key}}}", value)
        
        return await self.async_engine.request(
            provider_config=self.provider_config,
            api_key=self.api_key,
            method=method or endpoint_config.method,
            path=path,
            data=data,
        )
    
    def _make_stream_request(
        self,
        endpoint: str,
        data: Optional[dict[str, Any]] = None,
        path_params: Optional[dict[str, str]] = None,
    ) -> Iterator[bytes]:
        """Make a synchronous streaming request."""
        endpoint_config = self.provider_config.endpoints.get(endpoint)
        if not endpoint_config:
            raise ValueError(f"Unknown endpoint: {endpoint}")
        
        path = endpoint_config.path
        if path_params:
            for key, value in path_params.items():
                path = path.replace(f"{{{key}}}", value)
        
        return self.sync_engine.request_stream(
            provider_config=self.provider_config,
            api_key=self.api_key,
            method=endpoint_config.method,
            path=path,
            data=data,
        )
    
    async def _make_stream_request_async(
        self,
        endpoint: str,
        data: Optional[dict[str, Any]] = None,
        path_params: Optional[dict[str, str]] = None,
    ):
        """Make an asynchronous streaming request."""
        if not self.async_engine:
            raise RuntimeError("Async engine not initialized")
        
        endpoint_config = self.provider_config.endpoints.get(endpoint)
        if not endpoint_config:
            raise ValueError(f"Unknown endpoint: {endpoint}")
        
        path = endpoint_config.path
        if path_params:
            for key, value in path_params.items():
                path = path.replace(f"{{{key}}}", value)
        
        async for chunk in self.async_engine.request_stream(
            provider_config=self.provider_config,
            api_key=self.api_key,
            method=endpoint_config.method,
            path=path,
            data=data,
        ):
            yield chunk
