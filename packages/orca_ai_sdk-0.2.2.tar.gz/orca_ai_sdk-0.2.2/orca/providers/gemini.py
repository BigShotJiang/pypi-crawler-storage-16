"""
Google Gemini Provider Implementation

Full implementation of the Gemini API including:
- GenerateContent (streaming and non-streaming)
- Embeddings
- Model listing
"""

from typing import Any, AsyncIterator, Iterator, Optional
import json

from ..utils.types import (
    Attachment,
    FunctionDeclaration,
    GenerationConfig,
    OrcaEmbedding,
    OrcaModel,
    OrcaResponse,
    OrcaStreamChunk,
    SafetySetting,
    ToolCall,
)

from ..utils.format import (
    normalize_gemini_embedding,
    normalize_gemini_model,
    normalize_gemini_response,
    normalize_gemini_stream_chunk,
    translate_to_gemini,
)
from ..utils.types import OrcaEmbedding, OrcaModel, OrcaResponse, OrcaStreamChunk
from .base import BaseProvider


class GeminiProvider(BaseProvider):
    """Google Gemini API provider."""
    
    def chat(
        self,
        model: str,
        messages: list[dict[str, Any]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        system_instruction: Optional[str] = None,
        tools: Optional[list[FunctionDeclaration]] = None,
        safety_settings: Optional[list[SafetySetting]] = None,
        generation_config: Optional[GenerationConfig] = None,
        attachments: Optional[list[Attachment]] = None,
        **kwargs: Any,
    ) -> OrcaResponse | Iterator[OrcaStreamChunk]:
        """Send a generateContent request to Gemini."""
        payload = translate_to_gemini(
            messages=messages, model=model, temperature=temperature,
            max_tokens=max_tokens, stream=stream, system_instruction=system_instruction,
            tools=tools, safety_settings=safety_settings,
            generation_config=generation_config, attachments=attachments,
            **kwargs,
        )

        endpoint = "chat_stream" if stream else "chat"
        path_params = {"model": model}

        if stream:
            return self._stream_chat(payload, model, path_params)

        response = self._make_request(endpoint, data=payload, path_params=path_params)
        latency = response.pop("_orca_latency_ms", 0)
        return normalize_gemini_response(response, model, latency)
    
    async def chat_async(
        self,
        model: str,
        messages: list[dict[str, Any]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        system_instruction: Optional[str] = None,
        tools: Optional[list[FunctionDeclaration]] = None,
        safety_settings: Optional[list[SafetySetting]] = None,
        generation_config: Optional[GenerationConfig] = None,
        attachments: Optional[list[Attachment]] = None,
        **kwargs: Any,
    ) -> OrcaResponse | AsyncIterator[OrcaStreamChunk]:
        """Async generateContent request."""
        payload = translate_to_gemini(
            messages=messages, model=model, temperature=temperature,
            max_tokens=max_tokens, stream=stream, system_instruction=system_instruction,
            tools=tools, safety_settings=safety_settings,
            generation_config=generation_config, attachments=attachments,
            **kwargs,
        )

        endpoint = "chat_stream" if stream else "chat"
        path_params = {"model": model}

        if stream:
            return self._stream_chat_async(payload, model, path_params)

        response = await self._make_request_async(endpoint, data=payload, path_params=path_params)
        latency = response.pop("_orca_latency_ms", 0)
        return normalize_gemini_response(response, model, latency)
    
    def _stream_chat(self, payload: dict, model: str, path_params: dict) -> Iterator[OrcaStreamChunk]:
        """Handle streaming response."""
        raw_stream = self._make_stream_request("chat_stream", data=payload, path_params=path_params)
        accumulated = ""
        
        for raw_line in raw_stream:
            line = raw_line.decode("utf-8") if isinstance(raw_line, bytes) else raw_line
            line = line.strip()
            if not line or line.startswith("[") or line.startswith("]"):
                continue
            if line.startswith(","):
                line = line[1:]
            try:
                data = json.loads(line)
                chunk = normalize_gemini_stream_chunk(data, model)
                accumulated += chunk.delta_text
                chunk.accumulated_text = accumulated
                yield chunk
            except json.JSONDecodeError:
                continue
    
    async def _stream_chat_async(self, payload: dict, model: str, path_params: dict) -> AsyncIterator[OrcaStreamChunk]:
        """Handle async streaming."""
        raw_stream = self._make_stream_request_async("chat_stream", data=payload, path_params=path_params)
        accumulated = ""
        
        async for raw_line in raw_stream:
            line = raw_line.decode("utf-8") if isinstance(raw_line, bytes) else raw_line
            line = line.strip()
            if not line or line.startswith("[") or line.startswith("]"):
                continue
            if line.startswith(","):
                line = line[1:]
            try:
                data = json.loads(line)
                chunk = normalize_gemini_stream_chunk(data, model)
                accumulated += chunk.delta_text
                chunk.accumulated_text = accumulated
                yield chunk
            except json.JSONDecodeError:
                continue
    
    def list_models(self) -> list[OrcaModel]:
        """Fetch available models from Gemini."""
        response = self._make_request("models", method="GET")
        return [normalize_gemini_model(m) for m in response.get("models", [])]
    
    async def list_models_async(self) -> list[OrcaModel]:
        """Async fetch available models."""
        response = await self._make_request_async("models", method="GET")
        return [normalize_gemini_model(m) for m in response.get("models", [])]
    
    def embed(
        self,
        model: str,
        input: str | list[str],
        **kwargs: Any,
    ) -> OrcaEmbedding:
        """Generate embeddings using Gemini."""
        text = input if isinstance(input, str) else input[0]
        payload = {"content": {"parts": [{"text": text}]}}
        response = self._make_request("embeddings", data=payload, path_params={"model": model})
        latency = response.pop("_orca_latency_ms", 0)
        return normalize_gemini_embedding(response, model, latency)
    
    async def embed_async(
        self,
        model: str,
        input: str | list[str],
        **kwargs: Any,
    ) -> OrcaEmbedding:
        """Async embedding generation."""
        text = input if isinstance(input, str) else input[0]
        payload = {"content": {"parts": [{"text": text}]}}
        response = await self._make_request_async("embeddings", data=payload, path_params={"model": model})
        latency = response.pop("_orca_latency_ms", 0)
        return normalize_gemini_embedding(response, model, latency)
