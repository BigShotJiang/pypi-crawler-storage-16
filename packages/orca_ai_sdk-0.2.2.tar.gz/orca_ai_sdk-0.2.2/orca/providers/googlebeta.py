"""
Google Beta Provider Implementation

Uses the v1beta endpoint for accessing preview/beta Gemini models.
Identical to GeminiProvider but explicitly uses beta endpoint.
"""

from typing import Any, AsyncIterator, Iterator, Optional

from ..utils.types import (
    Attachment,
    FunctionDeclaration,
    GenerationConfig,
    OrcaEmbedding,
    OrcaModel,
    OrcaResponse,
    OrcaStreamChunk,
    SafetySetting,
)

from .gemini import GeminiProvider


class GoogleBetaProvider(GeminiProvider):
    """
    Google Beta API provider.
    
    Uses the v1beta endpoint for accessing preview and beta features
    of Gemini models (e.g., gemini-3-pro-preview).
    
    Inherits all functionality from GeminiProvider since the API
    is identical, just uses a different endpoint version.
    """
    
    # All methods inherited from GeminiProvider
    # The only difference is the base_url which is set in config.py
    pass
