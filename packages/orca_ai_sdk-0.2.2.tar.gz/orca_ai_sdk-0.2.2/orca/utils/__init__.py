"""Orca Utilities Package."""

from .format import (
    normalize_anthropic_response,
    normalize_gemini_response,
    normalize_openai_response,
    normalize_openrouter_response,
    translate_to_anthropic,
    translate_to_gemini,
    translate_to_openai,
    translate_to_openrouter,
)
from .threads import FetchResult, ThreadedModelFetcher, run_parallel
from .types import (
    FinishReason,
    MessageRole,
    OrcaChoice,
    OrcaEmbedding,
    OrcaImage,
    OrcaMessage,
    OrcaModel,
    OrcaResponse,
    OrcaStreamChunk,
    TokenUsage,
)

__all__ = [
    # Types
    "MessageRole",
    "OrcaMessage",
    "TokenUsage",
    "FinishReason",
    "OrcaChoice",
    "OrcaResponse",
    "OrcaStreamChunk",
    "OrcaModel",
    "OrcaEmbedding",
    "OrcaImage",
    # Formatters
    "normalize_openai_response",
    "normalize_anthropic_response",
    "normalize_gemini_response",
    "normalize_openrouter_response",
    "translate_to_openai",
    "translate_to_anthropic",
    "translate_to_gemini",
    "translate_to_openrouter",
    # Threads
    "ThreadedModelFetcher",
    "FetchResult",
    "run_parallel",
]
