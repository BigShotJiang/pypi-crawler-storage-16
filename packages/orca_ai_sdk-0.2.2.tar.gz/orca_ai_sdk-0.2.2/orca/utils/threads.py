"""
Orca Threaded Utilities

Provides parallel execution utilities for fetching model lists
from multiple providers concurrently.
"""

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from typing import Any, Callable, Optional

logger = logging.getLogger(__name__)


@dataclass
class FetchResult:
    """Result of a model fetch operation."""
    
    provider: str
    success: bool
    models: list[dict[str, Any]]
    error: Optional[str] = None
    elapsed_ms: float = 0


class ThreadedModelFetcher:
    """
    Fetches model lists from multiple providers in parallel.
    
    Uses ThreadPoolExecutor to concurrently request model lists
    from all enabled providers, significantly reducing startup time.
    """
    
    def __init__(
        self,
        max_workers: int = 4,
        timeout: float = 30.0,
    ) -> None:
        """
        Initialize the fetcher.
        
        Args:
            max_workers: Maximum concurrent threads
            timeout: Timeout per provider request in seconds
        """
        self.max_workers = max_workers
        self.timeout = timeout
    
    def fetch_all(
        self,
        fetchers: dict[str, Callable[[], list[dict[str, Any]]]],
    ) -> dict[str, FetchResult]:
        """
        Fetch model lists from all providers in parallel.
        
        Args:
            fetchers: Mapping of provider name to fetch function.
                     Each function should return a list of model dicts.
        
        Returns:
            Mapping of provider name to FetchResult
        """
        results: dict[str, FetchResult] = {}
        
        if not fetchers:
            return results
        
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            # Submit all fetch tasks
            future_to_provider = {
                executor.submit(self._fetch_with_timing, provider, fetcher): provider
                for provider, fetcher in fetchers.items()
            }
            
            # Collect results as they complete
            for future in as_completed(future_to_provider, timeout=self.timeout):
                provider = future_to_provider[future]
                try:
                    results[provider] = future.result()
                except Exception as e:
                    logger.error(f"Failed to fetch models from {provider}: {e}")
                    results[provider] = FetchResult(
                        provider=provider,
                        success=False,
                        models=[],
                        error=str(e),
                    )
        
        return results
    
    def _fetch_with_timing(
        self,
        provider: str,
        fetcher: Callable[[], list[dict[str, Any]]],
    ) -> FetchResult:
        """Execute fetch with timing and error handling."""
        import time
        
        start = time.perf_counter()
        try:
            models = fetcher()
            elapsed = (time.perf_counter() - start) * 1000
            logger.debug(f"Fetched {len(models)} models from {provider} in {elapsed:.1f}ms")
            return FetchResult(
                provider=provider,
                success=True,
                models=models,
                elapsed_ms=elapsed,
            )
        except Exception as e:
            elapsed = (time.perf_counter() - start) * 1000
            logger.error(f"Error fetching from {provider}: {e}")
            return FetchResult(
                provider=provider,
                success=False,
                models=[],
                error=str(e),
                elapsed_ms=elapsed,
            )


def run_parallel(
    tasks: dict[str, Callable[[], Any]],
    max_workers: int = 4,
    timeout: float = 30.0,
) -> dict[str, Any]:
    """
    Run arbitrary tasks in parallel.
    
    Args:
        tasks: Mapping of task name to callable
        max_workers: Maximum concurrent threads
        timeout: Overall timeout in seconds
    
    Returns:
        Mapping of task name to result (or exception)
    """
    results: dict[str, Any] = {}
    
    if not tasks:
        return results
    
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_name = {
            executor.submit(task): name
            for name, task in tasks.items()
        }
        
        for future in as_completed(future_to_name, timeout=timeout):
            name = future_to_name[future]
            try:
                results[name] = future.result()
            except Exception as e:
                results[name] = e
    
    return results
