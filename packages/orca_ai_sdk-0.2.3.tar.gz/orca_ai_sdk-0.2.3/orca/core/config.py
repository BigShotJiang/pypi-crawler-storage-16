"""
Orca Provider Configuration

Defines configuration for each supported AI provider including
base URLs, authentication patterns, and endpoint mappings.
"""

from dataclasses import dataclass, field
from typing import Any, Callable, Optional


@dataclass
class EndpointConfig:
    """Configuration for a single API endpoint."""
    
    path: str
    method: str = "POST"
    supports_streaming: bool = False


@dataclass
class ProviderConfig:
    """
    Configuration for an AI provider.
    
    Attributes:
        name: Provider identifier
        base_url: Base API URL
        auth_header: Header name for authentication (e.g., "Authorization")
        auth_prefix: Prefix for auth value (e.g., "Bearer ")
        api_key_env: Environment variable for API key
        endpoints: Mapping of endpoint names to configurations
        default_headers: Additional headers to include in all requests
        models_path: Path format for models endpoint
        requires_org: Whether organization ID is required
    """
    
    name: str
    base_url: str
    auth_header: str = "Authorization"
    auth_prefix: str = "Bearer "
    api_key_env: str = ""
    endpoints: dict[str, EndpointConfig] = field(default_factory=dict)
    default_headers: dict[str, str] = field(default_factory=dict)
    models_path: str = "/models"
    requires_org: bool = False
    api_key_in_url: bool = False  # For Gemini-style auth


# OpenAI Configuration
OPENAI_CONFIG = ProviderConfig(
    name="openai",
    base_url="https://api.openai.com/v1",
    auth_header="Authorization",
    auth_prefix="Bearer ",
    api_key_env="OPENAI_API_KEY",
    models_path="/models",
    endpoints={
        "chat": EndpointConfig(
            path="/chat/completions",
            method="POST",
            supports_streaming=True,
        ),
        "embeddings": EndpointConfig(
            path="/embeddings",
            method="POST",
            supports_streaming=False,
        ),
        "images": EndpointConfig(
            path="/images/generations",
            method="POST",
            supports_streaming=False,
        ),
        "models": EndpointConfig(
            path="/models",
            method="GET",
            supports_streaming=False,
        ),
        "audio_speech": EndpointConfig(
            path="/audio/speech",
            method="POST",
            supports_streaming=True,
        ),
        "audio_transcription": EndpointConfig(
            path="/audio/transcriptions",
            method="POST",
            supports_streaming=False,
        ),
        "moderations": EndpointConfig(
            path="/moderations",
            method="POST",
            supports_streaming=False,
        ),
    },
    default_headers={
        "Content-Type": "application/json",
    },
)


# Anthropic Configuration
ANTHROPIC_CONFIG = ProviderConfig(
    name="anthropic",
    base_url="https://api.anthropic.com/v1",
    auth_header="x-api-key",
    auth_prefix="",
    api_key_env="ANTHROPIC_API_KEY",
    models_path="/models",
    endpoints={
        "chat": EndpointConfig(
            path="/messages",
            method="POST",
            supports_streaming=True,
        ),
        "models": EndpointConfig(
            path="/models",
            method="GET",
            supports_streaming=False,
        ),
    },
    default_headers={
        "Content-Type": "application/json",
        "anthropic-version": "2023-06-01",
    },
)


# Google Gemini Configuration (v1 stable endpoint)
GEMINI_CONFIG = ProviderConfig(
    name="gemini",
    base_url="https://generativelanguage.googleapis.com/v1",
    auth_header="",  # Uses URL parameter
    auth_prefix="",
    api_key_env="GEMINI_API_KEY",
    api_key_in_url=True,
    models_path="/models",
    endpoints={
        "chat": EndpointConfig(
            path="/models/{model}:generateContent",
            method="POST",
            supports_streaming=True,
        ),
        "chat_stream": EndpointConfig(
            path="/models/{model}:streamGenerateContent?alt=sse",
            method="POST",
            supports_streaming=True,
        ),
        "embeddings": EndpointConfig(
            path="/models/{model}:embedContent",
            method="POST",
            supports_streaming=False,
        ),
        "models": EndpointConfig(
            path="/models",
            method="GET",
            supports_streaming=False,
        ),
    },
    default_headers={
        "Content-Type": "application/json",
    },
)


# Google Beta Configuration (v1beta preview endpoint)
GOOGLEBETA_CONFIG = ProviderConfig(
    name="googlebeta",
    base_url="https://generativelanguage.googleapis.com/v1beta",
    auth_header="",  # Uses URL parameter
    auth_prefix="",
    api_key_env="GEMINI_API_KEY",  # Uses same key as Gemini
    api_key_in_url=True,
    models_path="/models",
    endpoints={
        "chat": EndpointConfig(
            path="/models/{model}:generateContent",
            method="POST",
            supports_streaming=True,
        ),
        "chat_stream": EndpointConfig(
            path="/models/{model}:streamGenerateContent?alt=sse",
            method="POST",
            supports_streaming=True,
        ),
        "embeddings": EndpointConfig(
            path="/models/{model}:embedContent",
            method="POST",
            supports_streaming=False,
        ),
        "models": EndpointConfig(
            path="/models",
            method="GET",
            supports_streaming=False,
        ),
    },
    default_headers={
        "Content-Type": "application/json",
    },
)


# OpenRouter Configuration
OPENROUTER_CONFIG = ProviderConfig(
    name="openrouter",
    base_url="https://openrouter.ai/api/v1",
    auth_header="Authorization",
    auth_prefix="Bearer ",
    api_key_env="OPENROUTER_API_KEY",
    models_path="/models",
    endpoints={
        "chat": EndpointConfig(
            path="/chat/completions",
            method="POST",
            supports_streaming=True,
        ),
        "models": EndpointConfig(
            path="/models",
            method="GET",
            supports_streaming=False,
        ),
    },
    default_headers={
        "Content-Type": "application/json",
        "HTTP-Referer": "https://github.com/orca-sdk",
        "X-Title": "Orca SDK",
    },
)


# Provider registry
PROVIDER_CONFIGS: dict[str, ProviderConfig] = {
    "openai": OPENAI_CONFIG,
    "anthropic": ANTHROPIC_CONFIG,
    "gemini": GEMINI_CONFIG,
    "googlebeta": GOOGLEBETA_CONFIG,
    "openrouter": OPENROUTER_CONFIG,
}


def get_provider_config(provider: str) -> ProviderConfig:
    """
    Get configuration for a specific provider.
    
    Args:
        provider: Provider name (lowercase)
        
    Returns:
        ProviderConfig for the specified provider
        
    Raises:
        ValueError: If provider is not supported
    """
    provider = provider.lower()
    if provider not in PROVIDER_CONFIGS:
        available = ", ".join(PROVIDER_CONFIGS.keys())
        raise ValueError(f"Unknown provider '{provider}'. Available: {available}")
    return PROVIDER_CONFIGS[provider]


def list_supported_providers() -> list[str]:
    """Return list of all supported provider names."""
    return list(PROVIDER_CONFIGS.keys())


@dataclass
class OrcaConfig:
    """
    Global Orca client configuration.
    
    Attributes:
        timeout: Default request timeout in seconds
        max_retries: Maximum retry attempts for failed requests
        retry_delay: Base delay between retries (exponential backoff)
        parallel_init: Whether to fetch models in parallel during init
        lazy_init: Whether to defer model fetching until first use
        cache_models: Whether to cache model lists
        cache_ttl: Cache time-to-live in seconds
    """
    
    timeout: float = 60.0
    max_retries: int = 3
    retry_delay: float = 1.0
    parallel_init: bool = True
    lazy_init: bool = False
    cache_models: bool = True
    cache_ttl: float = 3600.0  # 1 hour
    
    # Request settings
    connect_timeout: float = 10.0
    read_timeout: float = 60.0
    
    # Streaming settings
    stream_chunk_size: int = 1024
    
    def to_dict(self) -> dict[str, Any]:
        """Convert config to dictionary."""
        return {
            "timeout": self.timeout,
            "max_retries": self.max_retries,
            "retry_delay": self.retry_delay,
            "parallel_init": self.parallel_init,
            "lazy_init": self.lazy_init,
            "cache_models": self.cache_models,
            "cache_ttl": self.cache_ttl,
        }
