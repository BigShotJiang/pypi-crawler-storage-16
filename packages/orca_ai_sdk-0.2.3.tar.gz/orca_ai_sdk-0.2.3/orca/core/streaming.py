"""
Orca Streaming Utilities

Provides stream parsing and handling for SSE (Server-Sent Events)
responses from various AI providers.
"""

import json
import logging
from dataclasses import dataclass
from typing import Any, AsyncIterator, Callable, Iterator, Optional

from ..utils.types import OrcaStreamChunk, FinishReason

logger = logging.getLogger(__name__)


@dataclass
class StreamState:
    """Tracks accumulated state during streaming."""
    
    accumulated_text: str = ""
    provider: str = ""
    model: str = ""
    chunk_count: int = 0
    is_complete: bool = False
    finish_reason: Optional[FinishReason] = None


class StreamParser:
    """
    Parses SSE streams from different providers.
    
    Each provider has slightly different SSE formats:
    - OpenAI: data: {...json...}
    - Anthropic: event: type\ndata: {...json...}
    - Gemini: {...json...} (newline-delimited JSON)
    """
    
    @staticmethod
    def parse_sse_line(line: bytes | str) -> Optional[dict[str, Any]]:
        """
        Parse a single SSE line.
        
        Args:
            line: Raw SSE line
            
        Returns:
            Parsed JSON data or None if not a data line
        """
        if isinstance(line, bytes):
            line = line.decode("utf-8")
        
        line = line.strip()
        
        if not line:
            return None
        
        # Handle "data: " prefix (OpenAI/Anthropic style)
        if line.startswith("data: "):
            data_str = line[6:]  # Remove "data: " prefix
            
            # Check for stream end marker
            if data_str == "[DONE]":
                return {"_done": True}
            
            try:
                return json.loads(data_str)
            except json.JSONDecodeError:
                logger.debug(f"Failed to parse SSE data: {data_str}")
                return None
        
        # Handle pure JSON lines (Gemini style)
        if line.startswith("{"):
            try:
                return json.loads(line)
            except json.JSONDecodeError:
                return None
        
        # Handle event: type lines (Anthropic)
        if line.startswith("event: "):
            event_type = line[7:]
            return {"_event": event_type}
        
        return None
    
    @staticmethod
    def parse_anthropic_event(
        lines: list[str],
    ) -> tuple[Optional[str], Optional[dict[str, Any]]]:
        """
        Parse Anthropic multi-line event.
        
        Anthropic sends events as:
        event: event_type
        data: {...json...}
        
        Args:
            lines: List of consecutive lines
            
        Returns:
            Tuple of (event_type, data) or (None, None)
        """
        event_type = None
        data = None
        
        for line in lines:
            if line.startswith("event: "):
                event_type = line[7:].strip()
            elif line.startswith("data: "):
                data_str = line[6:]
                try:
                    data = json.loads(data_str)
                except json.JSONDecodeError:
                    pass
        
        return event_type, data


class SyncStreamHandler:
    """
    Synchronous stream handler.
    
    Wraps raw byte iterators and provides parsed chunks
    with accumulated state tracking.
    """
    
    def __init__(
        self,
        raw_iterator: Iterator[bytes],
        provider: str,
        model: str,
        chunk_parser: Callable[[dict[str, Any], str], OrcaStreamChunk],
    ) -> None:
        """
        Initialize the stream handler.
        
        Args:
            raw_iterator: Iterator yielding raw response bytes
            provider: Provider name
            model: Model identifier
            chunk_parser: Function to parse provider-specific chunks
        """
        self.raw_iterator = raw_iterator
        self.provider = provider
        self.model = model
        self.chunk_parser = chunk_parser
        self.state = StreamState(provider=provider, model=model)
    
    def __iter__(self) -> Iterator[OrcaStreamChunk]:
        """Iterate over parsed stream chunks."""
        return self
    
    def __next__(self) -> OrcaStreamChunk:
        """Get next parsed chunk."""
        while True:
            try:
                raw_line = next(self.raw_iterator)
            except StopIteration:
                self.state.is_complete = True
                raise
            
            parsed = StreamParser.parse_sse_line(raw_line)
            
            if parsed is None:
                continue
            
            if parsed.get("_done"):
                self.state.is_complete = True
                raise StopIteration
            
            if "_event" in parsed:
                # Store event type for next data line
                continue
            
            chunk = self.chunk_parser(parsed, self.model)
            
            # Update accumulated state
            self.state.accumulated_text += chunk.delta_text
            self.state.chunk_count += 1
            chunk.accumulated_text = self.state.accumulated_text
            
            if chunk.finish_reason:
                self.state.finish_reason = chunk.finish_reason
                self.state.is_complete = True
            
            return chunk
    
    def collect(self) -> str:
        """Consume entire stream and return accumulated text."""
        for _ in self:
            pass
        return self.state.accumulated_text


class AsyncStreamHandler:
    """
    Asynchronous stream handler.
    
    Provides async iteration over parsed stream chunks.
    """
    
    def __init__(
        self,
        raw_iterator: AsyncIterator[bytes],
        provider: str,
        model: str,
        chunk_parser: Callable[[dict[str, Any], str], OrcaStreamChunk],
    ) -> None:
        """
        Initialize the async stream handler.
        
        Args:
            raw_iterator: Async iterator yielding raw response bytes
            provider: Provider name
            model: Model identifier
            chunk_parser: Function to parse provider-specific chunks
        """
        self.raw_iterator = raw_iterator
        self.provider = provider
        self.model = model
        self.chunk_parser = chunk_parser
        self.state = StreamState(provider=provider, model=model)
    
    def __aiter__(self) -> AsyncIterator[OrcaStreamChunk]:
        """Return async iterator."""
        return self
    
    async def __anext__(self) -> OrcaStreamChunk:
        """Get next parsed chunk."""
        while True:
            try:
                raw_line = await self.raw_iterator.__anext__()
            except StopAsyncIteration:
                self.state.is_complete = True
                raise
            
            parsed = StreamParser.parse_sse_line(raw_line)
            
            if parsed is None:
                continue
            
            if parsed.get("_done"):
                self.state.is_complete = True
                raise StopAsyncIteration
            
            if "_event" in parsed:
                continue
            
            chunk = self.chunk_parser(parsed, self.model)
            
            # Update accumulated state
            self.state.accumulated_text += chunk.delta_text
            self.state.chunk_count += 1
            chunk.accumulated_text = self.state.accumulated_text
            
            if chunk.finish_reason:
                self.state.finish_reason = chunk.finish_reason
                self.state.is_complete = True
            
            return chunk
    
    async def collect(self) -> str:
        """Consume entire stream and return accumulated text."""
        async for _ in self:
            pass
        return self.state.accumulated_text


def create_callback_stream(
    stream: Iterator[OrcaStreamChunk],
    callback: Callable[[OrcaStreamChunk], None],
) -> str:
    """
    Process stream with a callback function.
    
    Args:
        stream: Stream iterator
        callback: Function called for each chunk
        
    Returns:
        Final accumulated text
    """
    accumulated = ""
    for chunk in stream:
        callback(chunk)
        accumulated = chunk.accumulated_text
    return accumulated


async def create_async_callback_stream(
    stream: AsyncIterator[OrcaStreamChunk],
    callback: Callable[[OrcaStreamChunk], None],
) -> str:
    """
    Process async stream with a callback function.
    
    Args:
        stream: Async stream iterator
        callback: Function called for each chunk
        
    Returns:
        Final accumulated text
    """
    accumulated = ""
    async for chunk in stream:
        callback(chunk)
        accumulated = chunk.accumulated_text
    return accumulated
