"""
OpenAI Provider Implementation

Full implementation of the OpenAI API including:
- Chat completions (streaming and non-streaming)
- Embeddings
- Image generation
- Model listing
"""

from typing import Any, AsyncIterator, Iterator, Optional

from ..core.config import OrcaConfig, ProviderConfig
from ..core.request import AsyncRequestEngine, SyncRequestEngine
from ..core.streaming import AsyncStreamHandler, SyncStreamHandler
from ..utils.format import (
    normalize_openai_embedding,
    normalize_openai_image,
    normalize_openai_model,
    normalize_openai_response,
    normalize_openai_stream_chunk,
    translate_to_openai,
)
from ..utils.types import (
    Attachment,
    FunctionDeclaration,
    GenerationConfig,
    OrcaEmbedding,
    OrcaImage,
    OrcaModel,
    OrcaResponse,
    OrcaStreamChunk,
    SafetySetting,
)
from .base import BaseProvider


class OpenAIProvider(BaseProvider):
    """
    OpenAI API provider.
    
    Supports:
    - gpt-4, gpt-4-turbo, gpt-3.5-turbo chat models
    - text-embedding-3-small/large embedding models
    - dall-e-3, dall-e-2 image models
    """
    
    def chat(
        self,
        model: str,
        messages: list[dict[str, Any]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        system_instruction: Optional[str] = None,
        tools: Optional[list[FunctionDeclaration]] = None,
        safety_settings: Optional[list[SafetySetting]] = None,
        generation_config: Optional[GenerationConfig] = None,
        attachments: Optional[list[Attachment]] = None,
        **kwargs: Any,
    ) -> OrcaResponse | Iterator[OrcaStreamChunk]:
        """
        Send a chat completion request to OpenAI.

        Args:
            model: Model identifier (e.g., "gpt-4", "gpt-3.5-turbo")
            messages: Conversation messages
            temperature: Sampling temperature (0-2)
            max_tokens: Maximum tokens to generate
            stream: Whether to stream the response
            system_instruction: System prompt
            tools: List of function declarations (converted to tool format)
            safety_settings: Ignored for OpenAI (Gemini-specific)
            generation_config: Generation configuration with temperature/max_tokens
            attachments: Multi-modal attachments
            **kwargs: Additional OpenAI-specific parameters

        Returns:
            OrcaResponse or Iterator[OrcaStreamChunk] if streaming
        """
        # Use generation_config parameters if provided
        if generation_config:
            if temperature is None:
                temperature = generation_config.temperature
            if max_tokens is None:
                max_tokens = generation_config.max_output_tokens

        payload = translate_to_openai(
            messages=messages,
            model=model,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=stream,
            system_instruction=system_instruction,
            tools=tools,
            attachments=attachments,
            **kwargs,
        )

        if stream:
            return self._stream_chat(payload, model)

        response = self._make_request("chat", data=payload)
        latency = response.pop("_orca_latency_ms", 0)
        return normalize_openai_response(response, latency)
    
    async def chat_async(
        self,
        model: str,
        messages: list[dict[str, Any]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        system_instruction: Optional[str] = None,
        tools: Optional[list[FunctionDeclaration]] = None,
        safety_settings: Optional[list[SafetySetting]] = None,
        generation_config: Optional[GenerationConfig] = None,
        attachments: Optional[list[Attachment]] = None,
        **kwargs: Any,
    ) -> OrcaResponse | AsyncIterator[OrcaStreamChunk]:
        """Async chat completion."""
        # Use generation_config parameters if provided
        if generation_config:
            if temperature is None:
                temperature = generation_config.temperature
            if max_tokens is None:
                max_tokens = generation_config.max_output_tokens

        payload = translate_to_openai(
            messages=messages,
            model=model,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=stream,
            system_instruction=system_instruction,
            tools=tools,
            attachments=attachments,
            **kwargs,
        )

        if stream:
            return self._stream_chat_async(payload, model)

        response = await self._make_request_async("chat", data=payload)
        latency = response.pop("_orca_latency_ms", 0)
        return normalize_openai_response(response, latency)
    
    def _stream_chat(
        self,
        payload: dict[str, Any],
        model: str,
    ) -> Iterator[OrcaStreamChunk]:
        """Handle streaming chat response."""
        raw_stream = self._make_stream_request("chat", data=payload)
        return SyncStreamHandler(
            raw_iterator=raw_stream,
            provider="openai",
            model=model,
            chunk_parser=normalize_openai_stream_chunk,
        )
    
    async def _stream_chat_async(
        self,
        payload: dict[str, Any],
        model: str,
    ) -> AsyncIterator[OrcaStreamChunk]:
        """Handle async streaming chat response."""
        raw_stream = self._make_stream_request_async("chat", data=payload)
        handler = AsyncStreamHandler(
            raw_iterator=raw_stream,
            provider="openai",
            model=model,
            chunk_parser=normalize_openai_stream_chunk,
        )
        async for chunk in handler:
            yield chunk
    
    def list_models(self) -> list[OrcaModel]:
        """Fetch available models from OpenAI."""
        response = self._make_request("models", method="GET")
        models = response.get("data", [])
        return [normalize_openai_model(m) for m in models]
    
    async def list_models_async(self) -> list[OrcaModel]:
        """Async fetch available models."""
        response = await self._make_request_async("models", method="GET")
        models = response.get("data", [])
        return [normalize_openai_model(m) for m in models]
    
    def embed(
        self,
        model: str,
        input: str | list[str],
        **kwargs: Any,
    ) -> OrcaEmbedding:
        """
        Generate embeddings using OpenAI.
        
        Args:
            model: Embedding model (e.g., "text-embedding-3-small")
            input: Text or list of texts to embed
            **kwargs: Additional parameters (dimensions, encoding_format)
            
        Returns:
            OrcaEmbedding with vectors
        """
        if isinstance(input, str):
            input = [input]
        
        payload = {
            "model": model,
            "input": input,
            **kwargs,
        }
        
        response = self._make_request("embeddings", data=payload)
        latency = response.pop("_orca_latency_ms", 0)
        return normalize_openai_embedding(response, model, latency)
    
    async def embed_async(
        self,
        model: str,
        input: str | list[str],
        **kwargs: Any,
    ) -> OrcaEmbedding:
        """Async embedding generation."""
        if isinstance(input, str):
            input = [input]
        
        payload = {
            "model": model,
            "input": input,
            **kwargs,
        }
        
        response = await self._make_request_async("embeddings", data=payload)
        latency = response.pop("_orca_latency_ms", 0)
        return normalize_openai_embedding(response, model, latency)
    
    def generate_image(
        self,
        model: str,
        prompt: str,
        n: int = 1,
        size: str = "1024x1024",
        **kwargs: Any,
    ) -> OrcaImage:
        """
        Generate images using DALL-E.
        
        Args:
            model: Image model (e.g., "dall-e-3", "dall-e-2")
            prompt: Text description of the image
            n: Number of images to generate
            size: Image dimensions
            **kwargs: Additional parameters (quality, style, response_format)
            
        Returns:
            OrcaImage with URLs or base64 data
        """
        payload = {
            "model": model,
            "prompt": prompt,
            "n": n,
            "size": size,
            **kwargs,
        }
        
        response = self._make_request("images", data=payload)
        latency = response.pop("_orca_latency_ms", 0)
        return normalize_openai_image(response, model, latency)
    
    async def generate_image_async(
        self,
        model: str,
        prompt: str,
        n: int = 1,
        size: str = "1024x1024",
        **kwargs: Any,
    ) -> OrcaImage:
        """Async image generation."""
        payload = {
            "model": model,
            "prompt": prompt,
            "n": n,
            "size": size,
            **kwargs,
        }
        
        response = await self._make_request_async("images", data=payload)
        latency = response.pop("_orca_latency_ms", 0)
        return normalize_openai_image(response, model, latency)
