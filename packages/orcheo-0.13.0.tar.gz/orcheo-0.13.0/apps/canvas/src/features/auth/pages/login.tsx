import AuthPage from "@features/auth/components/auth-page";

export default function Login() {
  return <AuthPage type="login" />;
}
