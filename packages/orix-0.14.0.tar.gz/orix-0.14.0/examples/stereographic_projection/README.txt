Stereographic projection
========================
