.. This is a stub, see the top level CHANGELOG.rst file for the changelog.

:tocdepth: 2

.. include:: ../CHANGELOG.rst
