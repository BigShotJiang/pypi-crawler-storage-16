Orientations
============