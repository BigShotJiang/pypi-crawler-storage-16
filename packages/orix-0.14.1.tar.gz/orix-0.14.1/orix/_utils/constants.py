#
# Copyright 2018-2025 the orix developers
#
# This file is part of orix.
#
# orix is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# orix is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with orix. If not, see <http://www.gnu.org/licenses/>.
#

"""Constants and such useful across modules."""

from importlib.metadata import version

# NB! Update project config file if this list is updated!
optional_deps: list[str] = ["matplotlib-scalebar", "numpy-quaternion"]
installed: dict[str, bool] = {}
for pkg in optional_deps:
    try:
        _ = version(pkg)
        installed[pkg] = True
    except ImportError:  # pragma: no cover
        installed[pkg] = False


def verify_dependency_or_raise(package: str, reason: str) -> None:
    """Raise an informative import error if an optional dependency is
    not installed.

    Parameters
    ----------
    package
        The optional dependency being checked for.
    reason
        A short description of the feature that requires the dependency
        preceding the string "requires that the *package* is installed".
    """
    if not installed[package]:
        msg = f"{reason} requires that {package} is installed"
        raise ImportError(msg)


# ---------------------------- Tolerances ---------------------------- #

# Typical tolerances for comparisons in need of a precision. We
# generally use the highest precision possible (allowed by testing on
# different OS and Python versions).
eps9 = 1e-9
eps12 = 1e-12

# TODO: Remove and use numpy.exceptions.VisibleDeprecationWarning once
# NumPy 1.25 is minimal supported version
try:
    # Added in NumPy 1.25.0
    from numpy.exceptions import VisibleDeprecationWarning
except ImportError:  # pragma: no cover
    # Removed in NumPy 2.0.0
    from numpy import VisibleDeprecationWarning


del optional_deps
