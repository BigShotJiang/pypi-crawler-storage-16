Simple Docker SDK container test

builds PS1 programs and cue/bin files