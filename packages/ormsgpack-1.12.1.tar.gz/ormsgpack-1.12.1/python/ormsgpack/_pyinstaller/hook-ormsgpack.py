# SPDX-License-Identifier: (Apache-2.0 OR MIT)

hiddenimports = [
    "dataclasses",
    "enum",
    "uuid",
]
