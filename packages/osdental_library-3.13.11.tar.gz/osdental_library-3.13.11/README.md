# osdental-library

osdental-library is a versatile and easy-to-use library for handling common tasks related to *encryption, **hashing, and **JWT token management*. Ideal for projects that require a secure and efficient approach to handling sensitive data.


## Installation

You can easily install osdental-library using pip:

```bash
pip install osdental-library