import json
import os, time
from functools import wraps

# from ..Grpc.Client.CatalogClient import CatalogClient
from ..Grpc.Client.AuthClient import auth_client

from ..Grpc.Client.AuthClient import AuthClient


def _extract_headers(request):
    """Normalize headers from several request shapes into a dict with lower-case keys.

    Supported inputs:
    - Starlette/FastAPI Request object with `.headers`
    - ASGI-style dict with `scope['headers']` (list of (bytes, bytes))
    - Plain dict with a `headers` mapping
    """
    if not request:
        return {}

    # FastAPI/Starlette Request
    if hasattr(request, "headers"):
        try:
            return {k.lower(): v for k, v in request.headers.items()}
        except Exception:
            try:
                return {k.lower(): v for k, v in dict(request.headers).items()}
            except Exception:
                return {}

    # ASGI scope-like dict
    if isinstance(request, dict):
        scope = request.get("scope") or {}
        raw_hdrs = scope.get("headers") or []
        if raw_hdrs:
            try:
                return {k.decode().lower(): v.decode() for k, v in raw_hdrs}
            except Exception:
                pass

        # plain headers map in dict
        hdrs = request.get("headers") or {}
        try:
            return {k.lower(): v for k, v in hdrs.items()}
        except Exception:
            return {}

    return {}


def get_bearer(request):
    """Return bearer token or raw Authorization value from `request`.

    - If header is `Authorization: Bearer <token>` returns `<token>` (no prefix).
    - If header exists but is not Bearer, returns the header value as-is.
    - Returns `None` when missing or unreadable.
    """
    headers = _extract_headers(request)
    auth = headers.get("authorization")
    if isinstance(auth, (bytes, bytearray)):
        try:
            auth = auth.decode()
        except Exception:
            return None

    if not auth:
        return None

    auth = auth.strip()
    if auth.lower().startswith("bearer "):
        return auth.split(None, 1)[1]
    return auth


def AuditLogMobile():
    """
    Decorador que:
    - Lee el body del request (GraphQL)
    - Extrae y limpia el campo "data" si viene como string o escapado
    - Reemplaza automáticamente el argumento `data` del resolver
    - Guarda el data limpio en info.context["data_clean"]
    """

    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):

            # Obtener "info" (args[1] siempre es info en resolvers GraphQL)
            try:
                info = args[1]
            except Exception:
                # Si algo falla, ejecutar igual
                return await func(*args, **kwargs)

            operation_str = str(info.operation).lower()
            if "introspection" in operation_str or "__schema" in operation_str:
                return await func(*args, **kwargs)

                # PREVENIR DOBLE EJECUCIÓN — PARA DICT
            if info.context.get("_decorator_executed"):
                return await func(*args, **kwargs)

            info.context["_decorator_executed"] = True

            request = info.context.get("request")

            # debug: quién hizo la request
            client = None
            try:
                client = request.scope.get("client")
            except Exception:
                client = getattr(request, "client", None)

            logger.info(
                f"AuditLogMobile - op={getattr(info.operation,'name',None)} client={client} pid={os.getpid()} ts={time.time()}"
            )

            raw_data_from_request = None

            bearer_token = get_bearer(request)
            agent_mobile = request.headers.get("Agent-Mobile")

            logger.info(f"Bearer token extraído: {bearer_token}")
            logger.info(f"agent_mobile extraído: {agent_mobile}")

            print("Validando token con gRPC...")

            async with AuthClient() as client:
                res = await client.validate_auth_token(
                    bearer_token=bearer_token, agent_mobile=agent_mobile
                )

            logger.info(f"Respuesta de validación de token: {res}")

            # validar el token

            # res = await CatalogClient.get_catalog_detail_by_id(args[1])
            # if res.status != Code.PROCESS_SUCCESS_CODE:
            #    raise OSDException(error=res.message, status_code=res.status)
            # return json.loads(res.data)

            # ===============================
            # 1. Leer JSON crudo del request
            # ===============================
            if request:
                try:
                    body_bytes = await request.body()
                    body_str = body_bytes.decode("utf-8")
                    parsed_body = json.loads(body_str)

                    # Si hay variables y dentro de ellas viene "data"
                    raw_data_from_request = parsed_body.get("variables", {}).get("data")

                except Exception:
                    pass

            # ===============================
            # 2. Obtener el data enviado al resolver
            # ===============================
            original_data = kwargs.get("data")
            cleaned_data = original_data

            # ===============================
            # 3. Decidir cuál "data" procesar
            # ===============================
            candidate = (
                raw_data_from_request
                if raw_data_from_request is not None
                else original_data
            )

            # ===============================
            # 4. Limpiar/parsear JSON si viene como str
            # ===============================
            if isinstance(candidate, str):
                temp = candidate.strip()

                # Quitar comillas externas
                if (temp.startswith('"') and temp.endswith('"')) or (
                    temp.startswith("'") and temp.endswith("'")
                ):
                    temp = temp[1:-1]

                # Reemplazar escapes
                temp = temp.replace('\\"', '"')

                try:
                    cleaned_data = json.loads(temp)
                except Exception as e:
                    print("Error al parsear JSON en data:", e)
                    print("Cadena que falló:", temp)
                    raise Exception("El campo 'data' tiene un JSON inválido.")

            else:
                cleaned_data = candidate

            # ===============================
            # 5. Guardar data limpio para auditoría
            # ===============================
            info.context["data_clean"] = cleaned_data

            # ===============================
            # 6. Reemplazar argumento `data`
            # ===============================
            kwargs["data"] = cleaned_data

            # ===============================
            # 7. Ejecutar función original
            # ===============================
            return await func(*args, **kwargs)

        return wrapper

    return decorator
