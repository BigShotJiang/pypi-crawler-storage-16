import json
import os, time
from functools import wraps
import asyncio
from azure.monitor.opentelemetry import configure_azure_monitor

# from ..Grpc.Client.CatalogClient import CatalogClient
from opentelemetry import trace

from opentelemetry.trace import SpanKind
from ..Grpc.Client.AuthClient import auth_client
from ..InternalHttp.Request import CustomRequest
from ..Grpc.Client.AuthClient import AuthClient
from ..Shared.Logger import logger
from ..Shared.Config import Config

configure_azure_monitor(connection_string=Config.APPLICATIONINSIGHTS_CONNECTION_STRING)


def _extract_headers(request):

    if not request:
        return {}

    # FastAPI/Starlette Request
    if hasattr(request, "headers"):
        try:
            return {k.lower(): v for k, v in request.headers.items()}
        except Exception:
            try:
                return {k.lower(): v for k, v in dict(request.headers).items()}
            except Exception:
                return {}

    if isinstance(request, dict):
        scope = request.get("scope") or {}
        raw_hdrs = scope.get("headers") or []
        if raw_hdrs:
            try:
                return {k.decode().lower(): v.decode() for k, v in raw_hdrs}
            except Exception:
                pass

        # plain headers map in dict
        hdrs = request.get("headers") or {}
        try:
            return {k.lower(): v for k, v in hdrs.items()}
        except Exception:
            return {}

    return {}


def get_bearer(request):

    headers = _extract_headers(request)
    auth = headers.get("authorization")
    if isinstance(auth, (bytes, bytearray)):
        try:
            auth = auth.decode()
        except Exception:
            return None

    if not auth:
        return None

    auth = auth.strip()
    if auth.lower().startswith("bearer "):
        return auth.split(None, 1)[1]
    return auth


def AuditLogMobile():

    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            operation_name = "UnknownOperation"
            # Obtener "info" (args[1] siempre es info en resolvers GraphQL)
            try:
                info = args[1]
            except Exception:
                # Si algo falla, ejecutar igual
                return await func(*args, **kwargs)

            operation_str = str(info.operation).lower()
            if "introspection" in operation_str or "__schema" in operation_str:
                return await func(*args, **kwargs)

                # PREVENIR DOBLE EJECUCIÓN — PARA DICT
            if info.context.get("_decorator_executed"):
                return await func(*args, **kwargs)

            info.context["_decorator_executed"] = True

            request = info.context.get("request")

            # debug: quién hizo la request
            client = None
            try:
                client = request.scope.get("client")
            except Exception:
                client = getattr(request, "client", None)

            logger.info(
                f"AuditLogMobile - op={getattr(info.operation,'name',None)} client={client} pid={os.getpid()} ts={time.time()}"
            )

            raw_data_from_request = None

            bearer_token = get_bearer(request)
            agent_mobile = request.headers.get("Agent-Mobile")

            async with AuthClient() as client:
                res = await client.validate_auth_token(
                    bearer_token=bearer_token, agent_mobile=agent_mobile
                )

            if request:
                try:
                    body_bytes = await request.body()
                    body_str = body_bytes.decode("utf-8")
                    parsed_body = json.loads(body_str)
                    print("Parsed body for audit:", parsed_body)
                    # operation_name = body_data.get('operationName', 'UnknownOperation')
                    # Si hay variables y dentro de ellas viene "data"
                    raw_data_from_request = parsed_body.get("variables", {}).get("data")

                except Exception:
                    pass

                # Send audit of the request to Service Bus
                # $#custom_request = CustomRequest(request)
                # _ = asyncio.create_task(custom_request.send_to_service_bus())
                tracer = trace.get_tracer(__name__)

                with tracer.start_as_current_span(
                    "NombreDeLaOperacion",
                    kind=SpanKind.SERVER,
                ) as span:
                    span.set_attribute("http.method", "POST")
                    span.set_attribute("http.url", "https://tuservicio.com/graphql")
                    span.set_attribute("app.user", client)

            # ===============================
            # 2. Obtener el data enviado al resolver
            # ===============================
            original_data = kwargs.get("data")
            cleaned_data = original_data

            # ===============================
            # 3. Decidir cuál "data" procesar
            # ===============================
            candidate = (
                raw_data_from_request
                if raw_data_from_request is not None
                else original_data
            )

            # ===============================
            # 4. Limpiar/parsear JSON si viene como str
            # ===============================
            if isinstance(candidate, str):
                temp = candidate.strip()

                # Quitar comillas externas
                if (temp.startswith('"') and temp.endswith('"')) or (
                    temp.startswith("'") and temp.endswith("'")
                ):
                    temp = temp[1:-1]

                # Reemplazar escapes
                temp = temp.replace('\\"', '"')

                try:
                    cleaned_data = json.loads(temp)
                except Exception as e:
                    print("Error al parsear JSON en data:", e)
                    print("Cadena que falló:", temp)
                    raise Exception("El campo 'data' tiene un JSON inválido.")

            else:
                cleaned_data = candidate

            # ===============================
            # 5. Guardar data limpio para auditoría
            # ===============================
            info.context["data_clean"] = cleaned_data

            # ===============================
            # 6. Reemplazar argumento `data`
            # ===============================
            kwargs["data"] = cleaned_data

            # ===============================
            # 7. Ejecutar función original
            # ===============================
            return await func(*args, **kwargs)

        return wrapper

    return decorator
