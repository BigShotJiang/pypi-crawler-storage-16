# osdu_perf/locust/__init__.py
"""Locust integration for OSDU Performance Testing Framework"""

from .user_base import PerformanceUser

__all__ = [
    "PerformanceUser"
]
