# osdu_perf/operations/init_operation/__init__.py
"""Init operations for OSDU Performance Testing Framework"""

from .init_runner import InitRunner

__all__ = [
    "InitRunner"
]
