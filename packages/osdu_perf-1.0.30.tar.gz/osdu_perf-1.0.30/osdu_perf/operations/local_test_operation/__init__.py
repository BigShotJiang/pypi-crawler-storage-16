# osdu_perf/operations/local_test_operation/__init__.py
"""Local test operations for OSDU Performance Testing Framework"""

from .local_test_runner import LocalTestRunner

__all__ = [
    "LocalTestRunner"
]
