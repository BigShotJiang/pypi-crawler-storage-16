HMM Decoding
------------

These scripts predict age based on features extracted from a single HMM run.
