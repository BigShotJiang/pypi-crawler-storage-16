Static Decoding
---------------

These scripts predict age based on time-averaged (static) features that summarise networks extracted from MEG data.
