fMRI Examples
-------------

This directory contains example scripts for training a Hidden Markov Model on two resting-state fMRI datasets:

- UK Biobank.
- Human Connectome Project (HCP).

The scripts are setup to load data files hosted on the Oxford BMRC cluster.
