Example Scripts for Training Models on Simulated Data
-----------------------------------------------------

This scripts are used to make sure the models/packages are working properly and to test osl-dynamics has been installed correctly.
