TINDA Example Scripts
---------------------

Example scripts for applying Temporal Interval Network Density Analysis (TINDA) analysis to Hidden Markov Model (HMM) state time courses.
