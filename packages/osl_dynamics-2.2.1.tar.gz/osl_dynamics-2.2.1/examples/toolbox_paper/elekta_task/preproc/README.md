Elekta Task Dataset Preprocessing and Source Reconstruction
-----------------------------------------------------------

To run these scripts you need to install the [OSL](https://github.com/OHBA-analysis/osl) python package (which is not part of osl-dynamics).
