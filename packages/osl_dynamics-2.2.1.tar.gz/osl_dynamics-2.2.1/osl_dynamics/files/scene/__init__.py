from pathlib import Path

mode_scene = Path(__file__).parent / "mode_scene.scene"
