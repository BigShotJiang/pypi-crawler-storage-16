"""Other Agents MCP Server

MCP server for communicating with local AI CLI tools via file-based I/O.
"""

__version__ = "0.1.0"
__author__ = "Your Name"
__all__ = ["__version__"]
