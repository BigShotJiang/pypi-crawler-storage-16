__version__ = '6.0.0'
# don't import anything else here because setup.py imports this.
