# OutlierX 📊

A simple Python package to detect outliers using:

- IQR Method
- Z-score (custom threshold)
- Quantile-based detection

## Installation
```bash
pip install outlierx
