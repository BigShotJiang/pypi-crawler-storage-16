# Overview JPEG Tools

Tools and utilities to read embedded JSON data from OV Vision Systems.

## Installation

```bash
pip install overview-jpeg-tools
```

## Requirements

- Python 3.8+

## Quick Start

```python
from overview_jpeg_tools import JpegJsonReader

# Extract JSON data from an image
reader = JpegJsonReader("path/to/image.jpg")
data = reader.extract_json()

if data:
    print(f"Found embedded data: {data}")
else:
    print("No embedded JSON found")
```

## Usage

### Extract JSON from JPEG

```python
from overview_jpeg_tools import JpegJsonReader

# From file path
reader = JpegJsonReader("/path/to/image.jpg")
json_data = reader.extract_json()

# From bytes
with open("image.jpg", "rb") as f:
    image_bytes = f.read()
reader = JpegJsonReader(image_bytes)
json_data = reader.extract_json()
```

### Check for Embedded JSON

```python
reader = JpegJsonReader("image.jpg")
if reader.has_embedded_json():
    data = reader.extract_json()
```

### Access Raw Image Data

```python
reader = JpegJsonReader("image.jpg")
raw_bytes = reader.to_bytes()
```

## API Reference

### `JpegJsonReader`

Main class for reading JSON data from JPEG images.

#### Constructor

```python
JpegJsonReader(source: Union[str, Path, bytes, BytesIO])
```

- `source`: File path (str/Path) or binary JPEG data (bytes/BytesIO)

#### Methods

- `extract_json() -> Optional[Dict[str, Any]]`: Extract and return embedded JSON data, or `None` if not found
- `has_embedded_json() -> bool`: Check if the image contains embedded JSON data
- `to_bytes() -> bytes`: Get the raw image data as bytes

#### Properties

- `image_data: bytes`: The raw JPEG image data
- `source_path: Optional[Path]`: The original file path if loaded from disk

## Features

- **Efficient**: Uses decompression and chunk reassembly for large JSON payloads
- **Non-destructive**: Reads data from EXIF APP1 segments without modifying the image
- **Large payload support**: Automatically reassembles chunked data
- **Fast**: Uses orjson for high-performance JSON deserialization

## License

Proprietary - Copyright (c) 2024-2025 Overview Corporation. All rights reserved.

## Support

For support, contact: <support@overview.ai>

Website: <https://overview.ai>
