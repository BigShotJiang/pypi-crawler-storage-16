"""
Overview JPEG Tools - Tools and utilities to read embedded JSON data from OV Vision Systems.

Copyright (c) 2024-2025 Overview Corporation. All rights reserved.
"""

from overview_jpeg_tools.reader import (
    JPEG_APP1,
    JPEG_EOI,
    JPEG_SOI,
    JPEG_SOS,
    JSON_EXIF_HEADER,
    ChunkInfo,
    JpegJsonReader,
)

__version__ = "0.0.5"
__author__ = "Overview Corporation"
__email__ = "support@overview.ai"
__license__ = "Proprietary"

__all__ = [
    "JpegJsonReader",
    "ChunkInfo",
    "JPEG_SOI",
    "JPEG_APP1",
    "JPEG_SOS",
    "JPEG_EOI",
    "JSON_EXIF_HEADER",
    "__version__",
    "__author__",
    "__email__",
    "__license__",
]
