# Overview JPEG Tools

Tools and utilities to read embedded JSON data from OV Vision Systems.

## Installation

```bash
pip install overview-jpeg-tools
```

## Requirements

- Python 3.8+

## Quick Start

```python
from overview_jpeg_tools import JpegJsonEmbedder

# Extract JSON data from an image
embedder = JpegJsonEmbedder("path/to/image.jpg")
data = embedder.extract_json()

if data:
    print(f"Found embedded data: {data}")
else:
    print("No embedded JSON found")
```

## Usage

### Extract JSON from JPEG

```python
from overview_jpeg_tools import JpegJsonEmbedder

# From file path
embedder = JpegJsonEmbedder("/path/to/image.jpg")
json_data = embedder.extract_json()

# From bytes
with open("image.jpg", "rb") as f:
    image_bytes = f.read()
embedder = JpegJsonEmbedder(image_bytes)
json_data = embedder.extract_json()
```

### Check for Embedded JSON

```python
embedder = JpegJsonEmbedder("image.jpg")
if embedder.has_embedded_json():
    data = embedder.extract_json()
```

### Embed JSON into JPEG

```python
embedder = JpegJsonEmbedder("image.jpg")
embedder.embed_json({"key": "value", "nested": {"data": 123}})
embedder.save("output.jpg")

# Or save in-place
embedder.embed_json({"key": "value"})
embedder.save_in_place()
```

## Features

- **Efficient**: Uses compression and chunking for large JSON payloads
- **Non-destructive**: Embeds data in EXIF APP1 segments without affecting image quality
- **Large payload support**: Automatically chunks data that exceeds segment limits
- **Fast**: Uses orjson for high-performance JSON serialization

## License

Proprietary - Copyright (c) 2024-2025 Overview Corporation. All rights reserved.

## Support

For support, contact: support@overview.ai

Website: https://overview.ai
