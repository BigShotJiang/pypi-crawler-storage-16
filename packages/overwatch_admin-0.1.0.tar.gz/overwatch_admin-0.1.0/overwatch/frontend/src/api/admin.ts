import {
  Administration,
  PaginatedAdministration,
  AdminSearchRequest,
  AdminStats,
} from "@/types";
import { client } from "./client";

export const adminApi = {
  async getAdministrations(
    params: AdminSearchRequest = {}
  ): Promise<PaginatedAdministration> {
    try {
      const response = await client.get("/overwatch-admin", { params });

      return response.data;
    } catch (error) {
      console.error("Error fetching administrations:", error);
      throw error;
    }
  },

  async getAdministration(id: number): Promise<Administration> {
    try {
      const response = await client.get(`/overwatch-admin/${id}`);

      return response.data;
    } catch (error) {
      console.error(`Error fetching administration ${id}:`, error);
      throw error;
    }
  },

  async createAdmin(
    data: Omit<
      Administration,
      "id" | "created_at" | "updated_at" | "last_login"
    >
  ): Promise<Administration> {
    try {
      const response = await client.post("/overwatch-admin", data);

      return response.data;
    } catch (error) {
      console.error("Error creating admin:", error);
      throw error;
    }
  },

  async updateAdmin(
    id: number,
    data: Partial<Administration>
  ): Promise<Administration> {
    try {
      const response = await client.put(`/overwatch-admin/${id}`, data);

      return response.data;
    } catch (error) {
      console.error(`Error updating admin ${id}:`, error);
      throw error;
    }
  },

  async deleteAdmin(id: number): Promise<void> {
    try {
      await client.delete(`/overwatch-admin/${id}`);
    } catch (error) {
      console.error(`Error deleting admin ${id}:`, error);
      throw error;
    }
  },

  async getStats(): Promise<AdminStats> {
    try {
      const response = await client.get("/overwatch-admin/stats");

      return response.data;
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      throw error;
    }
  },

  async changePassword(
    id: number,
    data: { new_password: string }
  ): Promise<{ message: string }> {
    try {
      const response = await client.post(
        `/overwatch-admin/${id}/change-password`,
        data
      );

      return response.data;
    } catch (error) {
      console.error(`Error changing password for admin ${id}:`, error);
      throw error;
    }
  },
};
