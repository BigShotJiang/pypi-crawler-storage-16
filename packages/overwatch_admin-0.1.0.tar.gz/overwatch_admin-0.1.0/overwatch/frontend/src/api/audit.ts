import {
  AuditAction,
  AuditFilters,
  AuditLog,
  AuditResource,
  AuditStatistics,
  PaginatedAuditLogs,
} from "@/types";
import { client } from "./client";

export const auditApi = {
  // Get audit logs with pagination and filtering
  async getAuditLogs(
    page: number = 1,
    perPage: number = 10,
    filters: AuditFilters = {}
  ): Promise<PaginatedAuditLogs> {
    try {
      const params = {
        page,
        per_page: perPage,
        ...filters,
      };

      const response = await client.get("/overwatch-audit-logs", { params });

      return response.data;
    } catch (error) {
      console.error("Error fetching audit logs:", error);
      throw error;
    }
  },

  // Get a single audit log by ID
  async getAuditLog(id: number): Promise<AuditLog> {
    try {
      const response = await client.get(`/overwatch-audit-logs/${id}`);

      return response.data;
    } catch (error) {
      console.error(`Error fetching audit log ${id}:`, error);
      throw error;
    }
  },

  // Get available audit actions
  async getAuditActions(): Promise<{ actions: AuditAction[]; total: number }> {
    try {
      const response = await client.get("/overwatch-audit-logs/actions");

      return response.data;
    } catch (error) {
      console.error("Error fetching audit actions:", error);
      throw error;
    }
  },

  // Get available audit resources
  async getAuditResources(): Promise<{
    resources: AuditResource[];
    total: number;
  }> {
    try {
      const response = await client.get("/overwatch-audit-logs/resources");

      return response.data;
    } catch (error) {
      console.error("Error fetching audit resources:", error);
      throw error;
    }
  },

  // Get audit statistics
  async getAuditStatistics(days: number = 30): Promise<AuditStatistics> {
    try {
      const response = await client.get("/overwatch-audit-logs/statistics", {
        params: { days },
      });

      return response.data;
    } catch (error) {
      console.error("Error fetching audit statistics:", error);
      throw error;
    }
  },

  // Export audit logs
  async exportAuditLogs(
    format: "csv" | "json" = "csv",
    filters: AuditFilters = {}
  ): Promise<void> {
    try {
      const params = {
        format,
        ...filters,
      };

      const response = await client.get("/overwatch-audit-logs/export", {
        params,
        responseType: "blob",
      });

      // Create download link
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `audit_logs_export.${format}`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Error exporting audit logs:", error);
      throw error;
    }
  },

  // Clean up old audit logs (super admin only)
  async cleanupAuditLogs(
    days: number = 90
  ): Promise<{ message: string; deleted_count: number; days: number }> {
    try {
      const response = await client.delete("/overwatch-audit-logs/cleanup", {
        params: { days },
      });

      return response.data;
    } catch (error) {
      console.error("Error cleaning up audit logs:", error);
      throw error;
    }
  },
};
