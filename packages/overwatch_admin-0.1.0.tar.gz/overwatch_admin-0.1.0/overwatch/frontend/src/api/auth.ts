import { LoginCredentials, AuthResponse, User, UserSettings } from "@/types";
import { storageGet, storageRemove } from "@/lib/utils";
import { client } from "./client";

export const authApi = {
  async login(credentials: LoginCredentials): Promise<AuthResponse> {
    const formData = new FormData();
    formData.append("username", credentials.username);
    formData.append("password", credentials.password);

    const response = await client.post("/overwatch-auth/login", formData, {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
    });

    // Backend returns AdminLoginResponse with admin field
    const data = response.data;
    return {
      access_token: data.access_token,
      refresh_token: data.refresh_token,
      token_type: data.token_type,
      expires_in: data.expires_in,
      user: data.admin, // Backend uses 'admin' field
    };
  },

  async getMe(): Promise<User> {
    const response = await client.get("/overwatch-auth/me");
    return response.data;
  },

  async updateMe(data: UserSettings): Promise<User> {
    const response = await client.put("/overwatch-auth/me", data);
    return response.data;
  },

  async logout(): Promise<void> {
    try {
      await client.post("/overwatch-auth/logout");
    } finally {
      storageRemove("auth_token");
      storageRemove("refresh_token");
      storageRemove("auth_user");
    }
  },

  async refreshToken(): Promise<AuthResponse> {
    const refreshToken = storageGet("refresh_token");
    const response = await client.post("/overwatch-auth/refresh", {
      refresh_token: refreshToken,
    });

    const data = response.data;
    return {
      access_token: data.access_token,
      refresh_token: refreshToken, // Keep existing refresh token
      token_type: data.token_type,
      expires_in: data.expires_in,
      user: storageGet("auth_user"), // User stays the same during refresh
    };
  },

  async changePassword(data: {
    current_password: string;
    new_password: string;
  }): Promise<{ message: string }> {
    const response = await client.put("/overwatch-auth/change-password", data);

    return response.data;
  },
};
