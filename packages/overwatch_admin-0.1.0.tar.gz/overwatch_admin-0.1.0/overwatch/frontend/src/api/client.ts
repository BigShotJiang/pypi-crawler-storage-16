import axios from "axios";
import { storageGet, storageRemove } from "@/lib/utils";

const API_BASE_URL = import.meta.env.VITE_API_URL || "/admin/api";

const client = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

// Add auth token to requests
client.interceptors.request.use((config) => {
  // Try to get token from zustand store first (new method)
  try {
    const persistedState = localStorage.getItem("auth-store");
    if (persistedState) {
      const parsedState = JSON.parse(persistedState);
      const token = parsedState.state?.token;
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
        return config;
      }
    }
  } catch (error) {
    // Fallback to old method if zustand parsing fails
    console.warn(
      "Failed to parse zustand state, falling back to storage:",
      error
    );
  }

  // Fallback to old storage method for compatibility
  const token = storageGet("auth_token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Handle auth errors
client.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Clear both old and new storage methods
      storageRemove("auth_token");
      storageRemove("auth_user");
      try {
        localStorage.removeItem("auth-store");
      } catch (e) {
        // Ignore errors clearing localStorage
      }
      window.location.href = "/login";
    }
    return Promise.reject(error);
  }
);

export { API_BASE_URL, client };
