import { client } from "./client";

export interface PublicConfig {
  admin_title: string;
  logo_url?: string;
  favicon_url?: string;
  overwatch_theme_primary_color?: string;
  overwatch_theme_secondary_color?: string;
  overwatch_theme_mode?: string;
}

export interface Config {
  id: number;
  key: string;
  value?: string;
  description?: string;
  is_public: boolean;
  category?: string;
  data_type: string;
  created_at: string;
  updated_at: string;
  updated_by?: number;
}

export interface ConfigListResponse {
  items: Config[];
  total: number;
  page: number;
  per_page: number;
  pages: number;
  metadata: {
    fields: Record<string, { type: string; nullable: boolean }>;
    sortable_fields: string[];
    filterable_fields: string[];
    categories: string[];
  };
}

export interface ConfigCreate {
  key: string;
  value?: string;
  description?: string;
  is_public: boolean;
  category?: string;
  data_type: string;
}

export interface ConfigUpdate {
  value?: string;
  description?: string;
  is_public?: boolean;
  category?: string;
  data_type?: string;
}

export const configApi = {
  // Get public configuration (no auth required)
  getPublicConfig: async (): Promise<PublicConfig> => {
    const response = await client.get("/config/public");
    return response.data;
  },

  // Get all configs (admin only)
  getConfigs: async (params?: {
    page?: number;
    per_page?: number;
    search?: string;
    category?: string;
    is_public?: boolean;
    sort_by?: string;
    sort_direction?: "asc" | "desc";
  }): Promise<ConfigListResponse> => {
    const response = await client.get("/config", { params });
    return response.data;
  },

  // Get single config by key (admin only)
  getConfig: async (key: string): Promise<Config> => {
    const response = await client.get(`/config/${key}`);
    return response.data;
  },

  // Create new config (admin only)
  createConfig: async (data: ConfigCreate): Promise<Config> => {
    const response = await client.post("/config", data);
    return response.data;
  },

  // Update config (admin only)
  updateConfig: async (key: string, data: ConfigUpdate): Promise<Config> => {
    const response = await client.put(`/config/${key}`, data);
    return response.data;
  },

  // Delete config (admin only)
  deleteConfig: async (key: string): Promise<void> => {
    await client.delete(`/config/${key}`);
  },

  // Bulk create configs (admin only)
  bulkCreateConfigs: async (configs: ConfigCreate[]): Promise<Config[]> => {
    const response = await client.post("/config/bulk", { configs });
    return response.data;
  },

  // Bulk update configs (admin only)
  bulkUpdateConfigs: async (
    keys: string[],
    updates: ConfigUpdate
  ): Promise<Config[]> => {
    const response = await client.put("/config/bulk", { keys, updates });
    return response.data;
  },

  // Bulk delete configs (admin only)
  bulkDeleteConfigs: async (keys: string[]): Promise<void> => {
    await client.delete("/config/bulk", { data: { keys } });
  },
};
