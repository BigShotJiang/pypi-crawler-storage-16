import { DashboardStats, RecentActivity } from "@/types";
import { client } from "./client";

export const dashboardApi = {
  async getStats(): Promise<DashboardStats> {
    const response = await client.get("/overwatch-dashboard/stats");
    return response.data;
  },
  async getRecentActivity(): Promise<RecentActivity[]> {
    const response = await client.get("/overwatch-dashboard/recent-activity");
    return response.data?.activities || [];
  },
  async getAvailableModels(): Promise<
    { name: string; label: string; count: number }[]
  > {
    const response = await client.get(`/overwatch-dashboard/models`);
    return response.data;
  },
};
