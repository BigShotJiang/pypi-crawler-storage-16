import React from "react";
import { Button as MedusaButton } from "@medusajs/ui";
import { cn } from "@/lib/utils";
import { Loader2 } from "lucide-react";

interface ButtonProps extends React.ComponentProps<typeof MedusaButton> {
  isLoading?: boolean;
}

const Button: React.FC<ButtonProps> = ({
  className,
  isLoading = false,
  children,
  disabled,
  ...props
}) => {
  const isDisabled = disabled || isLoading;

  return (
    <MedusaButton className={cn(className)} disabled={isDisabled} {...props}>
      {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
      {children}
    </MedusaButton>
  );
};

export default Button;
