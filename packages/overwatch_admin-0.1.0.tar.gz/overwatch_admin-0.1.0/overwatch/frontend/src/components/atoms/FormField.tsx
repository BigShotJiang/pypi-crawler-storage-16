import React from "react";
import { cn } from "@/lib/utils";
import {
  Input,
  Select,
  Textarea,
  Label,
  DatePicker,
  Switch,
} from "@medusajs/ui";
import { ModelField } from "@/types";
import { ForeignKeyField } from "./ForeignKeyField";

interface FormFieldProps {
  field: ModelField;
  value: any;
  onChange: (name: string, value: any) => void;
  disabled?: boolean;
  error?: string;
  onKeyDown?: (e: React.KeyboardEvent) => void;
  onBlur?: () => void;
}

export const FormField: React.FC<FormFieldProps> = ({
  field,
  value,
  onChange,
  disabled = false,
  error,
  onKeyDown,
  onBlur,
}) => {
  const isReadonly = (field as any).readonly || disabled;
  const label =
    field.label ||
    field.name
      .replace(/_/g, " ")
      .replace(/\b\w/g, (char) => char.toUpperCase());

  const handleChange = (newValue: any) => {
    onChange(field.name, newValue);
  };

  let fieldType = field.type;

  if (field.choices && field.choices.length > 0) {
    fieldType = "select";
  }

  const getChoices = () => {
    if ("choices" in field) {
      return field.choices || [];
    }
    return [];
  };

  if (field.foreign_key) {
    return (
      <ForeignKeyField
        field={field}
        value={value}
        onChange={onChange}
        disabled={isReadonly}
        error={error}
        onBlur={onBlur}
      />
    );
  }

  switch (fieldType) {
    case "boolean":
      return (
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label
              htmlFor={`${field.name}-switch`}
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              {label}
              {!field.nullable && (
                <span className="text-ui-fg-error ml-1">*</span>
              )}
            </Label>
            <Switch
              id={`${field.name}-switch`}
              checked={value || false}
              onCheckedChange={(checked) => handleChange(checked)}
              disabled={isReadonly}
            />
          </div>
          {error && <p className="text-xs text-ui-fg-error">{error}</p>}
        </div>
      );

    case "datetime":
      return (
        <div className="space-y-2">
          <span
            aria-label={`${field.name}-datetime-label`}
            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
          >
            {label}
            {!field.nullable && (
              <span className="text-ui-fg-error ml-1">*</span>
            )}
          </span>
          <DatePicker
            value={value ? new Date(value) : null}
            onChange={(date) => handleChange(date?.toISOString())}
            isDisabled={isReadonly}
            isRequired={!field.nullable}
            granularity="minute"
            isInvalid={!!error}
            errorMessage={error}
            aria-label={`${field.name}-datetime-label`}
          />
        </div>
      );

    case "date":
      return (
        <div className="space-y-2">
          <span
            aria-label={`${field.name}-date-label`}
            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
          >
            {label}
            {!field.nullable && (
              <span className="text-ui-fg-error ml-1">*</span>
            )}
          </span>
          <DatePicker
            value={value ? new Date(value) : null}
            onChange={(date) => handleChange(date?.toISOString())}
            isDisabled={isReadonly}
            isRequired={!field.nullable}
            granularity="day"
            isInvalid={!!error}
            errorMessage={error}
            aria-label={`${field.name}-date-label`}
          />
        </div>
      );

    case "time":
      return (
        <div className="space-y-2">
          <span
            aria-label={`${field.name}-time`}
            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
          >
            {label}
            {!field.nullable && (
              <span className="text-ui-fg-error ml-1">*</span>
            )}
          </span>
          <Input
            id={`${field.name}-time`}
            type="time"
            value={value || ""}
            onChange={(e) => handleChange(e.target.value)}
            onKeyDown={onKeyDown}
            onBlur={onBlur}
            disabled={isReadonly}
            aria-invalid={error ? true : false}
          />
          {error && <p className="text-xs text-ui-fg-error">{error}</p>}
        </div>
      );

    case "select":
      return (
        <div className="space-y-2">
          <Label
            htmlFor={`${field.name}-select`}
            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
          >
            {label}
            {!field.nullable && (
              <span className="text-ui-fg-error ml-1">*</span>
            )}
          </Label>
          <Select
            value={value?.toUpperCase() || ""}
            onValueChange={(newValue) => handleChange(newValue)}
            disabled={isReadonly}
          >
            <Select.Trigger id={`${field.name}-select`}>
              <Select.Value
                placeholder={`Select ${label?.toLowerCase() || "option"}`}
              />
            </Select.Trigger>
            <Select.Content>
              {getChoices().map((choice: string) => (
                <Select.Item key={choice} value={choice}>
                  {choice}
                </Select.Item>
              ))}
            </Select.Content>
          </Select>
          {error && <p className="text-xs text-ui-fg-error">{error}</p>}
        </div>
      );

    case "integer":
    case "number":
      return (
        <div className="space-y-2">
          <Label
            htmlFor={`${field.name}-number`}
            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
          >
            {label}
            {!field.nullable && (
              <span className="text-ui-fg-error ml-1">*</span>
            )}
          </Label>
          <Input
            id={`${field.name}-number`}
            type="number"
            value={value !== null && value !== undefined ? String(value) : ""}
            onChange={(e) => {
              const newValue = e.target.value;
              if (newValue === "") {
                handleChange(null);
              } else {
                handleChange(
                  field.type === "integer"
                    ? parseInt(newValue) || 0
                    : parseFloat(newValue) || 0
                );
              }
            }}
            onKeyDown={onKeyDown}
            onBlur={onBlur}
            disabled={isReadonly}
            aria-invalid={error ? true : false}
          />
          {error && <p className="text-xs text-ui-fg-error">{error}</p>}
        </div>
      );

    case "email":
      return (
        <div className="space-y-2">
          <Label
            htmlFor={`${field.name}-email`}
            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
          >
            {label}
            {!field.nullable && (
              <span className="text-ui-fg-error ml-1">*</span>
            )}
          </Label>
          <Input
            id={`${field.name}-email`}
            type="email"
            value={value || ""}
            onChange={(e) => handleChange(e.target.value)}
            onKeyDown={onKeyDown}
            onBlur={onBlur}
            disabled={isReadonly}
            aria-invalid={error ? true : false}
          />
          {error && <p className="text-xs text-ui-fg-error">{error}</p>}
        </div>
      );

    case "password":
      return (
        <div className="space-y-2">
          <Label
            htmlFor={`${field.name}-password`}
            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
          >
            {label}
            {!field.nullable && (
              <span className="text-ui-fg-error ml-1">*</span>
            )}
          </Label>
          <Input
            id={`${field.name}-password`}
            type="password"
            value={value || ""}
            onChange={(e) => handleChange(e.target.value)}
            onKeyDown={onKeyDown}
            onBlur={onBlur}
            disabled={isReadonly}
            aria-invalid={error ? true : false}
          />
          {error && <p className="text-xs text-ui-fg-error">{error}</p>}
        </div>
      );

    case "textarea":
      return (
        <div className="space-y-2">
          <Label
            htmlFor={`${field.name}-textarea`}
            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
          >
            {label}
            {!field.nullable && (
              <span className="text-ui-fg-error ml-1">*</span>
            )}
          </Label>
          <Textarea
            id={`${field.name}-textarea`}
            value={value || ""}
            onChange={(e) => handleChange(e.target.value)}
            onKeyDown={onKeyDown}
            onBlur={onBlur}
            disabled={isReadonly}
            aria-invalid={error ? true : false}
            className={cn(
              error &&
                "border-ui-border-interactive focus:ring-ui-border-interactive"
            )}
          />
          {error && <p className="text-xs text-ui-fg-error">{error}</p>}
        </div>
      );

    default:
      return (
        <div className="space-y-2">
          <Label
            htmlFor={`${field.name}-input`}
            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
          >
            {label}
            {!field.nullable && (
              <span className="text-ui-fg-error ml-1">*</span>
            )}
          </Label>
          <Input
            id={`${field.name}-input`}
            type="text"
            value={value || ""}
            onChange={(e) => handleChange(e.target.value)}
            onKeyDown={onKeyDown}
            onBlur={onBlur}
            disabled={isReadonly}
            aria-invalid={error ? true : false}
          />
          {error && <p className="text-xs text-ui-fg-error">{error}</p>}
        </div>
      );
  }
};

export default FormField;
