import React from "react";
import { Copy as MedusaCopy, Tooltip } from "@medusajs/ui";

interface SecureFieldCellProps {
  value: any;
  fieldType: string;
  fieldName: string;
}

// Helper function to detect sensitive fields
const isSensitiveField = (fieldName: string, fieldType: string): boolean => {
  const sensitiveKeywords = [
    "password",
    "passwd",
    "secret",
    "token",
    "key",
    "auth",
    "credential",
    "api_key",
    "access_key",
    "private_key",
  ];

  const lowerFieldName = fieldName.toLowerCase();

  return (
    fieldType === "password" ||
    sensitiveKeywords.some((keyword) => lowerFieldName.includes(keyword))
  );
};

// Format value for display
const formatValue = (val: any, type: string): string => {
  if (val === null || val === undefined) return "—";

  switch (type) {
    case "datetime":
    case "date":
      return new Date(val).toLocaleDateString();
    case "boolean":
      return val ? "Yes" : "No";
    case "number":
    case "integer":
      return String(val);
    default:
      return String(val);
  }
};

// Generate masked display
const generateMaskedValue = (originalValue: string): string => {
  if (!originalValue || originalValue === "—") return "—";

  // Show first and last character, mask the middle
  if (originalValue.length <= 2) {
    return "*".repeat(originalValue.length);
  }

  const firstChar = originalValue[0];
  const lastChar = originalValue[originalValue.length - 1];
  const middleStars = "*".repeat(Math.min(originalValue.length - 2, 10));

  return `${firstChar}${middleStars}${lastChar}`;
};

export const SecureFieldCell: React.FC<SecureFieldCellProps> = ({
  value,
  fieldType,
  fieldName,
}) => {
  const isSensitive = isSensitiveField(fieldName, fieldType);
  const formattedValue = formatValue(value, fieldType);
  const displayValue = isSensitive
    ? generateMaskedValue(formattedValue)
    : formattedValue;

  if (!isSensitive) {
    // For non-sensitive fields, just display the value normally
    return <div className="text-sm text-ui-fg-base">{displayValue}</div>;
  }

  // For sensitive fields, display with masking and copy functionality
  return (
    <div className="flex items-center gap-2">
      <div className="relative max-w-xs">
        <Tooltip
          content={
            <div className="max-w-sm font-mono text-xs break-all">
              <code>{formattedValue}</code>
            </div>
          }
          side="top"
          align="center"
        >
          <span className="text-sm text-ui-fg-base font-mono cursor-help truncate block max-w-full">
            {displayValue}
          </span>
        </Tooltip>
      </div>
      <MedusaCopy content={formattedValue} variant="mini" />
    </div>
  );
};

export default SecureFieldCell;
