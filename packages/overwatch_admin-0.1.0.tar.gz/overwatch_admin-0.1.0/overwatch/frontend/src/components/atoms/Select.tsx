import React from "react";
import { Select as MedusaSelect } from "@medusajs/ui";

interface SelectProps
  extends Omit<React.ComponentProps<typeof MedusaSelect>, "onChange"> {
  placeholder?: string;
  onChange?: (value: string) => void;
}

const Select: React.FC<SelectProps> = ({
  placeholder,
  onChange,
  children,
  onValueChange,
  ...props
}) => {
  const handleChange = (value: string) => {
    if (onChange) {
      onChange(value);
    }
    if (onValueChange) {
      onValueChange(value);
    }
  };

  return (
    <MedusaSelect onValueChange={handleChange} {...props}>
      {placeholder && (
        <option value="" disabled>
          {placeholder}
        </option>
      )}
      {children}
    </MedusaSelect>
  );
};

export default Select;
