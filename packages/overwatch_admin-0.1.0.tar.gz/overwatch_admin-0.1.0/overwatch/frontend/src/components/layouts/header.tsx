import { Heading } from "@medusajs/ui";

export type HeaderProps = {
  title: string;
  subtitle?: string;
  children?: React.ReactNode;
};

export const Header = ({ title, subtitle, children }: HeaderProps) => {
  return (
    <div className="flex justify-between items-center">
      <div className="flex flex-col gap-y-1">
        <Heading level="h1">{title}</Heading>
        {subtitle && (
          <span className="text-ui-fg-subtle txt-compact-medium">
            {subtitle}
          </span>
        )}
      </div>
      {children}
    </div>
  );
};
