import { Container, Heading, Text } from "@medusajs/ui";
import { AlertTriangle } from "lucide-react";

interface ErrorDisplayProps {
  title?: string;
  message?: string;
  icon?: React.ReactNode;
}

const ErrorDisplay: React.FC<ErrorDisplayProps> = ({
  title = "Error loading data",
  message = "Please check your connection and try again.",
  icon = <AlertTriangle className="mx-auto h-12 w-12 text-ui-fg-error" />,
}) => {
  return (
    <Container>
      <div className="text-center py-12">
        {icon}
        <Heading
          level="h2"
          className="mt-4 text-lg font-medium text-ui-fg-base"
        >
          {title}
        </Heading>
        <Text className="mt-2 text-ui-fg-muted">{message}</Text>
      </div>
    </Container>
  );
};

export default ErrorDisplay;
