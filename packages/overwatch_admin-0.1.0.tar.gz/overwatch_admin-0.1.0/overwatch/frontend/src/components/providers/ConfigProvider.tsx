import React, { useEffect, ReactNode } from "react";
import { configApi, PublicConfig } from "@/api/config";

interface ConfigProviderProps {
  children: ReactNode;
}

export const ConfigProvider: React.FC<ConfigProviderProps> = ({ children }) => {
  useEffect(() => {
    const initializeConfig = async () => {
      try {
        const config: PublicConfig = await configApi.getPublicConfig();

        // Update document title
        if (config.admin_title) {
          document.title = config.admin_title;
        }

        // Update favicon
        if (config.favicon_url) {
          let favicon = document.querySelector(
            'link[rel="icon"]'
          ) as HTMLLinkElement;
          if (!favicon) {
            favicon = document.createElement("link");
            favicon.rel = "icon";
            document.head.appendChild(favicon);
          }
          favicon.href = config.favicon_url;
        }

        // Apply theme colors
        if (config.overwatch_theme_primary_color) {
          document.documentElement.style.setProperty(
            "--overwatch-primary-color",
            config.overwatch_theme_primary_color
          );
        }

        if (config.overwatch_theme_secondary_color) {
          document.documentElement.style.setProperty(
            "--overwatch-secondary-color",
            config.overwatch_theme_secondary_color
          );
        }

        // Apply theme mode
        // if (config.overwatch_theme_mode) {
        //   document.documentElement.setAttribute(
        //     "data-theme",
        //     config.overwatch_theme_mode
        //   );
        // }
      } catch (error) {
        console.error("Failed to load public config:", error);
      }
    };

    initializeConfig();
  }, []);

  return <>{children}</>;
};
