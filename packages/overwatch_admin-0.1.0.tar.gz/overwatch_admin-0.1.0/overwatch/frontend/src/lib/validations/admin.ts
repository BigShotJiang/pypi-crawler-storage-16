import { z } from "zod";

const usernameWithDotRegex =
  /^[a-zA-Z0-9_](?:[a-zA-Z0-9_]|[.][a-zA-Z0-9_])*[a-zA-Z0-9_]?$/;

export const baseAdminSchema = z.object({
  username: z
    .string()
    .min(4, "Username must be at least 4 characters")
    .trim()
    .regex(
      usernameWithDotRegex,
      "Username can only contain letters, numbers, underscores, and dots (dots cannot be at start or end)"
    ),
  email: z.string().email("Invalid email address").optional().or(z.literal("")),
  first_name: z.string().optional(),
  last_name: z.string().optional(),
  role: z.enum(["super_admin", "admin", "read_only"]),
  status: z.enum(["active", "inactive", "suspended"]),
  is_active: z.boolean(),
  is_verified: z.boolean(),
});

// Admin form validation schema for edit mode
export const adminEditSchema = baseAdminSchema
  .extend({
    password: z
      .string()
      .min(8, "Password must be at least 8 characters")
      .optional(),
    confirm_password: z.string().optional(),
  })
  .refine(
    (data) => {
      if (data.password && data.confirm_password) {
        return data.password === data.confirm_password;
      }
      return true;
    },
    {
      message: "Passwords do not match",
      path: ["confirm_password"],
    }
  );

// Admin form validation schema for new mode
export const adminNewSchema = baseAdminSchema
  .extend({
    password: z.string().min(8, "Password must be at least 8 characters"),
    confirm_password: z.string().min(1, "Please confirm your password"),
  })
  .refine(
    (data) => {
      return data.password === data.confirm_password;
    },
    {
      message: "Passwords do not match",
      path: ["confirm_password"],
    }
  );

export const adminPasswordChangeSchema = z
  .object({
    new_password: z.string().min(8, "Password must be at least 8 characters"),
    confirm_password: z.string().min(1, "Please confirm your password"),
  })
  .refine(
    (data) => {
      return data.new_password === data.confirm_password;
    },
    {
      message: "Passwords do not match",
      path: ["confirm_password"],
    }
  );

export type AdminEditFormData = z.infer<typeof adminEditSchema>;
export type AdminNewFormData = z.infer<typeof adminNewSchema>;
export type AdminPasswordChangeFormData = z.infer<
  typeof adminPasswordChangeSchema
>;
