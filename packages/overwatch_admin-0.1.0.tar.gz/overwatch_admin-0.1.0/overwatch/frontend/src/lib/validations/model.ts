import { z } from "zod";
import { ModelField } from "@/types";

// Dynamic schema generation for model fields
export const createModelSchema = (
  fields: ModelField[],
  mode: "edit" | "new" = "edit"
) => {
  const schemaFields: Record<string, z.ZodTypeAny> = {};

  fields.forEach((field) => {
    // Skip ID field entirely for new mode (not included in form)
    if (mode === "new" && field.name === "id") return;

    let fieldSchema: z.ZodTypeAny;

    const fieldLabel =
      field.label ||
      field.name
        .replace(/_/g, " ")
        .replace(/\b\w/g, (char) => char.toUpperCase());

    // ID fields in edit mode are readonly and should not be validated
    // Just accept whatever value is provided
    if (field.name === "id" && mode === "edit") {
      // Accept any type for ID field since it's readonly
      fieldSchema = z.any();
    } else {
      // Create base schema based on field type - all start as nullable and optional
      switch (field.type) {
        case "string":
          fieldSchema = z.string().nullable().optional();
          break;
        case "integer":
          fieldSchema = z.number().int().nullable().optional();
          break;
        case "number":
          fieldSchema = z.number().nullable().optional();
          break;
        case "boolean":
          fieldSchema = z.boolean().nullable().optional();
          break;
        case "date":
          fieldSchema = z.string().datetime().nullable().optional();
          break;
        case "datetime":
          fieldSchema = z.string().datetime().nullable().optional();
          break;
        case "json":
          fieldSchema = z.record(z.any()).nullable().optional();
          break;
        default:
          fieldSchema = z.any().nullable().optional();
      }

      // Add required validation - this overrides nullable/optional for required fields
      if (!field.nullable) {
        if (field.type === "boolean") {
          // Boolean fields are always valid, but we can add custom validation if needed
          fieldSchema = z.boolean().default(false);
        } else if (field.type === "string") {
          fieldSchema = z.string().min(1, `${fieldLabel} is required`).trim();
        } else if (field.type === "integer") {
          fieldSchema = z.number().int();
        } else if (field.type === "number") {
          fieldSchema = z.number();
        } else if (field.type === "date" || field.type === "datetime") {
          fieldSchema = z
            .string()
            .datetime({
              message: `${fieldLabel} must be a valid date`,
            })
            .min(1, `${fieldLabel} is required`);
        } else if (field.type === "json") {
          fieldSchema = z
            .record(z.any())
            .refine(
              (val) =>
                val !== null &&
                val !== undefined &&
                Object.keys(val).length > 0,
              `${fieldLabel} is required`
            );
        }
      }

      // Add transformations for optional fields to normalize values
      if (!field.nullable) {
        if (field.type === "string") {
          fieldSchema = (
            fieldSchema as z.ZodOptional<z.ZodNullable<z.ZodString>>
          ).transform((val) => val?.trim() || "");
        } else if (field.type === "boolean") {
          fieldSchema = (
            fieldSchema as z.ZodOptional<z.ZodNullable<z.ZodBoolean>>
          ).transform((val) => Boolean(val));
        } else if (field.type === "integer") {
          fieldSchema = (
            fieldSchema as z.ZodOptional<z.ZodNullable<z.ZodNumber>>
          ).transform((val) => val ?? null);
        } else if (field.type === "number") {
          fieldSchema = (
            fieldSchema as z.ZodOptional<z.ZodNullable<z.ZodNumber>>
          ).transform((val) => val ?? null);
        }
        // For date/datetime, keep null values as is since DatePicker handles them
        // For json, keep null values as is
      }
    }

    schemaFields[field.name] = fieldSchema;
  });

  const finalSchema = z.object(schemaFields);
  return finalSchema;
};

// Type inference for model forms
export type ModelFormData = z.infer<ReturnType<typeof createModelSchema>>;
