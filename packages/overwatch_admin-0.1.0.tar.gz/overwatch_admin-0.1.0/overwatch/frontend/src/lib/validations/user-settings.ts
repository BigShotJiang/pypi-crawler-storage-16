import { z } from "zod";

export const profileSettingsSchema = z.object({
  username: z.string().min(1, "Username is required"),
  email: z.string().email("Invalid email address"),
  first_name: z.string().min(1, "First name is required"),
  last_name: z.string().min(1, "Last name is required"),
  avatar: z.string().optional(),
});

export const securitySettingsSchema = z
  .object({
    current_password: z
      .string()
      .min(1, "Current password is required")
      .min(1, "Please enter your current password"),
    new_password: z
      .string()
      .min(1, "New password is required")
      .min(8, "New password must be at least 8 characters"),
    confirm_password: z.string().min(1, "Please confirm your new password"),
    two_factor_enabled: z.boolean(),
  })
  .refine(
    (data) => {
      return data.new_password === data.confirm_password;
    },
    {
      message: "Passwords do not match",
      path: ["confirm_password"],
    }
  );

export type ProfileSettingsFormData = z.infer<typeof profileSettingsSchema>;
export type SecuritySettingsFormData = z.infer<typeof securitySettingsSchema>;
