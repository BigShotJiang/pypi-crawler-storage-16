import React from "react";
import {
  Drawer,
  Text,
  Heading as HeadingComponent,
  Container,
  StatusBadge,
  Button,
  Prompt,
  Badge,
} from "@medusajs/ui";
import { Administration } from "@/types";
import {
  Calendar,
  Check,
  Key,
  Pencil,
  Trash,
  User,
  XMarkMini,
} from "@medusajs/icons";

interface AdminDetailDrawerProps {
  admin: Administration | null;
  isOpen: boolean;
  onClose: () => void;
  onEdit?: (admin: Administration) => void;
  onDelete?: (admin: Administration) => void;
}

export const AdminDetailDrawer: React.FC<AdminDetailDrawerProps> = React.memo(
  ({ admin, isOpen, onClose, onEdit, onDelete }) => {
    if (!admin) return null;

    const formatDate = (dateString: string | null) => {
      if (!dateString) return "Never";
      return new Date(dateString).toLocaleString();
    };

    const getRoleColor = (role: string) => {
      switch (role) {
        case "super_admin":
          return "red";
        case "admin":
          return "blue";
        case "read_only":
          return "grey";
        default:
          return "grey";
      }
    };

    const getStatusColor = (status: string) => {
      switch (status) {
        case "active":
          return "green";
        case "inactive":
          return "grey";
        case "suspended":
          return "red";
        default:
          return "grey";
      }
    };

    const formatRole = (role: string) => {
      return role
        .replace(/_/g, " ")
        .replace(/\b\w/g, (char) => char.toUpperCase());
    };

    const formatStatus = (status: string) => {
      return status
        .replace(/_/g, " ")
        .replace(/\b\w/g, (char) => char.toUpperCase());
    };

    return (
      <Drawer open={isOpen} onOpenChange={onClose}>
        <Drawer.Content>
          <Drawer.Header>
            <Drawer.Title>Administrator Details</Drawer.Title>
            <Drawer.Description className="text-ui-fg-muted">
              Detailed information about the selected administrator.
            </Drawer.Description>
          </Drawer.Header>
          <Drawer.Body className="flex flex-col gap-6 overflow-auto">
            <Container className="divide-y">
              {/* Basic Information */}
              <div className="py-4">
                <HeadingComponent
                  level="h3"
                  className="mb-4 flex items-center gap-2"
                >
                  <User />
                  Basic Information
                </HeadingComponent>
                <div className="grid gap-3 text-sm">
                  <div className="flex justify-between">
                    <Text className="text-ui-fg-muted">ID:</Text>
                    <Text className="font-mono">{admin.id}</Text>
                  </div>
                  <div className="flex justify-between">
                    <Text className="text-ui-fg-muted">Username:</Text>
                    <Text className="font-medium">{admin.username}</Text>
                  </div>
                  <div className="flex justify-between">
                    <Text className="text-ui-fg-muted">Email:</Text>
                    <Text>{admin.email || "N/A"}</Text>
                  </div>
                  <div className="flex justify-between">
                    <Text className="text-ui-fg-muted">First Name:</Text>
                    <Text>{admin.first_name || "N/A"}</Text>
                  </div>
                  <div className="flex justify-between">
                    <Text className="text-ui-fg-muted">Last Name:</Text>
                    <Text>{admin.last_name || "N/A"}</Text>
                  </div>
                </div>
              </div>

              {/* Role and Status */}
              <div className="py-4">
                <HeadingComponent
                  level="h3"
                  className="mb-4 flex items-center gap-2"
                >
                  <Key />
                  Role and Status
                </HeadingComponent>
                <div className="grid gap-3 text-sm">
                  <div className="flex justify-between items-center">
                    <Text className="text-ui-fg-muted">Role:</Text>
                    <StatusBadge color={getRoleColor(admin.role)}>
                      {formatRole(admin.role)}
                    </StatusBadge>
                  </div>
                  <div className="flex justify-between items-center">
                    <Text className="text-ui-fg-muted">Status:</Text>
                    <StatusBadge color={getStatusColor(admin.status)}>
                      {formatStatus(admin.status)}
                    </StatusBadge>
                  </div>
                  <div className="flex justify-between items-center">
                    <Badge
                      size="xsmall"
                      color={admin.is_active ? "green" : "red"}
                    >
                      <Check className="mr-2" />
                      {admin.is_active ? "Active" : "Inactive"}
                    </Badge>
                    <Badge
                      size="xsmall"
                      color={admin.is_verified ? "green" : "red"}
                    >
                      <XMarkMini className="mr-2" />

                      {admin.is_verified ? "Active" : "Inactive"}
                    </Badge>
                  </div>
                </div>
              </div>

              {/* Timestamp Information */}
              <div className="py-4">
                <HeadingComponent
                  level="h3"
                  className="mb-4 flex items-center gap-2"
                >
                  <Calendar />
                  Timestamp Information
                </HeadingComponent>
                <div className="grid gap-3 text-sm">
                  <div className="flex justify-between">
                    <Text className="text-ui-fg-muted">Last Login:</Text>
                    <Text>{formatDate(admin.last_login)}</Text>
                  </div>
                  <div className="flex justify-between">
                    <Text className="text-ui-fg-muted">Created At:</Text>
                    <Text>{formatDate(admin.created_at)}</Text>
                  </div>
                  <div className="flex justify-between">
                    <Text className="text-ui-fg-muted">Updated At:</Text>
                    <Text>{formatDate(admin.updated_at)}</Text>
                  </div>
                </div>
              </div>
            </Container>
          </Drawer.Body>
          <Drawer.Footer>
            {onEdit && (
              <Button variant="secondary" onClick={() => onEdit(admin)}>
                <Pencil />
                Edit
              </Button>
            )}
            {onDelete && (
              <Prompt variant="confirmation">
                <Prompt.Trigger asChild>
                  <Button variant="danger">
                    <Trash />
                    Delete
                  </Button>
                </Prompt.Trigger>
                <Prompt.Content>
                  <Prompt.Header>
                    <Prompt.Title>Delete Confirmation</Prompt.Title>
                    <Prompt.Description>
                      Are you sure you want to delete this administrator? This
                      action cannot be undone.
                    </Prompt.Description>
                  </Prompt.Header>
                  <Prompt.Footer>
                    <Prompt.Cancel>Cancel</Prompt.Cancel>
                    <Prompt.Action onClick={() => onDelete(admin)}>
                      Delete
                    </Prompt.Action>
                  </Prompt.Footer>
                </Prompt.Content>
              </Prompt>
            )}
          </Drawer.Footer>
        </Drawer.Content>
      </Drawer>
    );
  }
);

export default AdminDetailDrawer;
