import React from "react";
import { Container, Heading, Button, Text, Input } from "@medusajs/ui";
import { Download, Filter } from "lucide-react";
import Select from "@/components/atoms/Select";
import { AdminRole, AdminStatus } from "@/types";

interface AdminFiltersProps {
  search: string;
  onSearchChange: (value: string) => void;
  selectedRole: string;
  onRoleChange: (value: string) => void;
  selectedStatus: string;
  onStatusChange: (value: string) => void;
  selectedActive: string;
  onActiveChange: (value: string) => void;
  dateFrom: string;
  onDateFromChange: (value: string) => void;
  dateTo: string;
  onDateToChange: (value: string) => void;
  onClearFilters: () => void;
  onExport: () => void;
}

const AdminFilters: React.FC<AdminFiltersProps> = ({
  search,
  onSearchChange,
  selectedRole,
  onRoleChange,
  selectedStatus,
  onStatusChange,
  selectedActive,
  onActiveChange,
  dateFrom,
  onDateFromChange,
  dateTo,
  onDateToChange,
  onClearFilters,
  onExport,
}) => (
  <Container className="rounded-lg border bg-ui-bg-component text-ui-fg-base shadow-sm">
    <div className="p-6">
      <Heading
        level="h3"
        className="text-lg font-medium text-ui-fg-base mb-4 flex items-center"
      >
        <Filter className="mr-2 h-5 w-5" />
        Filters
      </Heading>
      <div className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Search */}
          <div className="md:col-span-2 lg:col-span-1">
            <Text className="text-sm font-medium text-ui-fg-base mb-2 block">
              Search
            </Text>
            <Input
              id="admin-filter"
              placeholder="Search administrators..."
              value={search}
              onChange={(e) => onSearchChange(e.target.value)}
              type="search"
            />
          </div>

          {/* Role Filter */}
          <div>
            <Text className="text-sm font-medium text-ui-fg-base mb-2 block">
              Role
            </Text>
            <Select
              value={selectedRole}
              onChange={(value) => onRoleChange(value)}
              placeholder="All Roles"
            >
              <option value="">All Roles</option>
              <option value={AdminRole.SUPER_ADMIN}>Super Admin</option>
              <option value={AdminRole.ADMIN}>Admin</option>
              <option value={AdminRole.READ_ONLY}>Read Only</option>
            </Select>
          </div>

          {/* Status Filter */}
          <div>
            <Text className="text-sm font-medium text-ui-fg-base mb-2 block">
              Status
            </Text>
            <Select
              value={selectedStatus}
              onChange={(value) => onStatusChange(value)}
              placeholder="All Statuses"
            >
              <option value="">All Statuses</option>
              <option value={AdminStatus.ACTIVE}>Active</option>
              <option value={AdminStatus.INACTIVE}>Inactive</option>
              <option value={AdminStatus.SUSPENDED}>Suspended</option>
            </Select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Active Filter */}
          <div>
            <Text className="text-sm font-medium text-ui-fg-base mb-2 block">
              Active Status
            </Text>
            <Select
              value={selectedActive}
              onChange={(value) => onActiveChange(value)}
              placeholder="All"
            >
              <option value="">All</option>
              <option value="true">Active</option>
              <option value="false">Inactive</option>
            </Select>
          </div>

          {/* Date From */}
          <div>
            <Text className="text-sm font-medium text-ui-fg-base mb-2 block">
              From Date
            </Text>
            <Input
              type="datetime-local"
              value={dateFrom}
              onChange={(e) => onDateFromChange(e.target.value)}
            />
          </div>

          {/* Date To */}
          <div>
            <Text className="text-sm font-medium text-ui-fg-base mb-2 block">
              To Date
            </Text>
            <Input
              type="datetime-local"
              value={dateTo}
              onChange={(e) => onDateToChange(e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center justify-between mt-6">
        <div className="flex gap-2">
          <Button variant="secondary" onClick={onClearFilters}>
            Clear Filters
          </Button>
          <Button onClick={onExport} className="flex items-center">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>
    </div>
  </Container>
);

export default AdminFilters;
