import React, { useEffect } from "react";
import { Drawer, Button, Text, Select, Switch, Label } from "@medusajs/ui";
import { Administration, AdminRole, AdminStatus } from "@/types";
import { Input } from "@medusajs/ui";
import { Check, Spinner, XMarkMini } from "@medusajs/icons";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { adminEditSchema, adminNewSchema } from "@/lib/validations";

type Mode = "edit" | "new";

interface AdminNewEditDrawerProps {
  item: Administration | null;
  mode: Mode;
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Record<string, any>) => void;
  isLoading?: boolean;
}

type AdminFormData =
  | (z.infer<typeof adminEditSchema> & { mode: "edit" })
  | (z.infer<typeof adminNewSchema> & { mode: "new" });

export const AdminNewEditDrawer: React.FC<AdminNewEditDrawerProps> = React.memo(
  ({ item, mode, isOpen, onClose, onSave, isLoading = false }) => {
    const {
      control,
      handleSubmit,
      formState: { errors, isValid },
      reset,
      watch,
    } = useForm<AdminFormData>({
      resolver: zodResolver(mode === "new" ? adminNewSchema : adminEditSchema),
      mode: "onChange",
      defaultValues: {
        username: "",
        email: "",
        first_name: "",
        last_name: "",
        role: AdminRole.READ_ONLY,
        status: AdminStatus.ACTIVE,
        is_active: true,
        is_verified: false,
        password: "",
        confirm_password: "",
      },
    });

    const currentRole = watch("role");

    // Initialize form data when item or mode changes
    useEffect(() => {
      if (mode === "new") {
        reset({
          username: "",
          email: "",
          first_name: "",
          last_name: "",
          role: AdminRole.READ_ONLY,
          status: AdminStatus.ACTIVE,
          is_active: true,
          is_verified: false,
          password: "",
          confirm_password: "",
        });
      } else if (item) {
        reset({
          username: item.username,
          email: item.email || "",
          first_name: item.first_name || "",
          last_name: item.last_name || "",
          role: item.role,
          status: item.status,
          is_active: item.is_active,
          is_verified: item.is_verified,
          password: "",
          confirm_password: "",
        });
      }
    }, [item, mode, reset]);

    const handleSave = (data: AdminFormData) => {
      onSave(data);
    };

    const handleClose = () => {
      if (!isLoading) {
        onClose();
      }
    };

    const isEditMode = mode === "edit";
    const title = isEditMode ? "Edit Administrator" : "New Administrator";
    const description = isEditMode
      ? "Modify the information for this administrator below."
      : "Create a new administrator by filling out the information below.";
    const actionText = isEditMode ? "Save Changes" : "Create";
    return (
      <Drawer open={isOpen} onOpenChange={handleClose}>
        <Drawer.Content className="w-full md:max-w-screen-md">
          <Drawer.Header>
            <Drawer.Title>{title}</Drawer.Title>
            <Drawer.Description className="text-ui-fg-muted">
              {description}
            </Drawer.Description>
          </Drawer.Header>
          <Drawer.Body className="flex flex-col gap-6 overflow-auto">
            <form onSubmit={handleSubmit(handleSave)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Username */}
                <div className="space-y-2">
                  <Text className="text-sm font-medium text-ui-fg-base">
                    Username <span className="text-ui-fg-error ml-1">*</span>
                  </Text>
                  <Controller
                    name="username"
                    control={control}
                    render={({ field }) => (
                      <Input
                        {...field}
                        disabled={isLoading}
                        placeholder="Enter username"
                      />
                    )}
                  />
                  {errors.username && (
                    <Text className="text-xs text-ui-fg-error">
                      {errors.username.message}
                    </Text>
                  )}
                </div>

                {/* Email */}
                <div className="space-y-2">
                  <Text className="text-sm font-medium text-ui-fg-base">
                    Email
                  </Text>
                  <Controller
                    name="email"
                    control={control}
                    render={({ field }) => (
                      <Input
                        {...field}
                        disabled={isLoading}
                        placeholder="Enter email"
                        type="email"
                      />
                    )}
                  />
                  {errors.email && (
                    <Text className="text-xs text-ui-fg-error">
                      {errors.email.message}
                    </Text>
                  )}
                </div>

                {/* First Name */}
                <div className="space-y-2">
                  <Text className="text-sm font-medium text-ui-fg-base">
                    First Name
                  </Text>
                  <Controller
                    name="first_name"
                    control={control}
                    render={({ field }) => (
                      <Input
                        {...field}
                        disabled={isLoading}
                        placeholder="Enter first name"
                      />
                    )}
                  />
                  {errors.first_name && (
                    <Text className="text-xs text-ui-fg-error">
                      {errors.first_name.message}
                    </Text>
                  )}
                </div>

                {/* Last Name */}
                <div className="space-y-2">
                  <Text className="text-sm font-medium text-ui-fg-base">
                    Last Name
                  </Text>
                  <Controller
                    name="last_name"
                    control={control}
                    render={({ field }) => (
                      <Input
                        {...field}
                        disabled={isLoading}
                        placeholder="Enter last name"
                      />
                    )}
                  />
                  {errors.last_name && (
                    <Text className="text-xs text-ui-fg-error">
                      {errors.last_name.message}
                    </Text>
                  )}
                </div>

                {/* Role */}
                <div className="space-y-2">
                  <Text className="text-sm font-medium text-ui-fg-base">
                    Role <span className="text-ui-fg-error ml-1">*</span>
                  </Text>
                  <Controller
                    name="role"
                    control={control}
                    render={({ field }) => (
                      <Select
                        value={field.value}
                        onValueChange={field.onChange}
                        disabled={
                          isLoading ||
                          (isEditMode && currentRole === AdminRole.SUPER_ADMIN)
                        }
                      >
                        <Select.Trigger>
                          <Select.Value placeholder="Select role" />
                        </Select.Trigger>
                        <Select.Content>
                          <Select.Item value={AdminRole.SUPER_ADMIN}>
                            Super Admin
                          </Select.Item>
                          <Select.Item value={AdminRole.ADMIN}>
                            Admin
                          </Select.Item>
                          <Select.Item value={AdminRole.READ_ONLY}>
                            Read Only
                          </Select.Item>
                        </Select.Content>
                      </Select>
                    )}
                  />
                  {errors.role && (
                    <Text className="text-xs text-ui-fg-error">
                      {errors.role.message}
                    </Text>
                  )}
                </div>

                {/* Status */}
                <div className="space-y-2">
                  <Text className="text-sm font-medium text-ui-fg-base">
                    Status <span className="text-ui-fg-error ml-1">*</span>
                  </Text>
                  <Controller
                    name="status"
                    control={control}
                    render={({ field }) => (
                      <Select
                        value={field.value}
                        onValueChange={field.onChange}
                        disabled={isLoading}
                      >
                        <Select.Trigger>
                          <Select.Value placeholder="Select status" />
                        </Select.Trigger>
                        <Select.Content>
                          <Select.Item value={AdminStatus.ACTIVE}>
                            Active
                          </Select.Item>
                          <Select.Item value={AdminStatus.INACTIVE}>
                            Inactive
                          </Select.Item>
                          <Select.Item value={AdminStatus.SUSPENDED}>
                            Suspended
                          </Select.Item>
                        </Select.Content>
                      </Select>
                    )}
                  />
                  {errors.status && (
                    <Text className="text-xs text-ui-fg-error">
                      {errors.status.message}
                    </Text>
                  )}
                </div>

                {/* Active */}
                <div className="flex items-center justify-between">
                  <Label
                    htmlFor="is-active-switch"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Active
                  </Label>
                  <Controller
                    name="is_active"
                    control={control}
                    render={({ field }) => (
                      <Switch
                        id="is-active-switch"
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        disabled={isLoading}
                      />
                    )}
                  />
                </div>
                {errors.is_active && (
                  <Text className="text-xs text-ui-fg-error">
                    {errors.is_active.message}
                  </Text>
                )}

                {/* Verified */}
                <div className="flex items-center justify-between">
                  <Label
                    htmlFor="is-verified-switch"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Verified
                  </Label>
                  <Controller
                    name="is_verified"
                    control={control}
                    render={({ field }) => (
                      <Switch
                        id="is-verified-switch"
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        disabled={isLoading}
                      />
                    )}
                  />
                </div>
                {errors.is_verified && (
                  <Text className="text-xs text-ui-fg-error">
                    {errors.is_verified.message}
                  </Text>
                )}

                {/* Password fields for new mode */}
                {mode === "new" && (
                  <>
                    <div className="space-y-2">
                      <Text className="text-sm font-medium text-ui-fg-base">
                        Password{" "}
                        <span className="text-ui-fg-error ml-1">*</span>
                      </Text>
                      <Controller
                        name="password"
                        control={control}
                        render={({ field }) => (
                          <Input
                            {...field}
                            disabled={isLoading}
                            placeholder="Enter password"
                            type="password"
                          />
                        )}
                      />
                      {errors.password && (
                        <Text className="text-xs text-ui-fg-error">
                          {errors.password.message}
                        </Text>
                      )}
                    </div>
                    <div className="space-y-2">
                      <Text className="text-sm font-medium text-ui-fg-base">
                        Confirm Password{" "}
                        <span className="text-ui-fg-error ml-1">*</span>
                      </Text>
                      <Controller
                        name="confirm_password"
                        control={control}
                        render={({ field }) => (
                          <Input
                            {...field}
                            disabled={isLoading}
                            placeholder="Confirm password"
                            type="password"
                          />
                        )}
                      />
                      {errors.confirm_password && (
                        <Text className="text-xs text-ui-fg-error">
                          {errors.confirm_password.message}
                        </Text>
                      )}
                    </div>
                  </>
                )}
              </div>
            </form>
          </Drawer.Body>
          <Drawer.Footer>
            <Button variant="danger" onClick={handleClose} disabled={isLoading}>
              <XMarkMini />
              Cancel
            </Button>
            <Button
              onClick={handleSubmit(handleSave)}
              disabled={isLoading || !isValid}
            >
              {isLoading ? <Spinner className="animate-spin" /> : <Check />}
              {actionText}
            </Button>
          </Drawer.Footer>
        </Drawer.Content>
      </Drawer>
    );
  }
);

export default AdminNewEditDrawer;
