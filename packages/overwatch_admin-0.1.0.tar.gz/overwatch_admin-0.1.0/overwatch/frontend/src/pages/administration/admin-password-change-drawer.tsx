import React, { useEffect } from "react";
import { Drawer, Button, Text, Input, Label } from "@medusajs/ui";
import { Administration, AdminPasswordChange } from "@/types";
import { Check, Spinner, XMarkMini } from "@medusajs/icons";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { adminPasswordChangeSchema } from "@/lib/validations";

interface AdminPasswordChangeDrawerProps {
  admin: Administration | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: AdminPasswordChange) => void;
  isLoading?: boolean;
}

type AdminPasswordChangeFormData = z.infer<typeof adminPasswordChangeSchema>;

const AdminPasswordChangeDrawer: React.FC<AdminPasswordChangeDrawerProps> = ({
  admin,
  isOpen,
  onClose,
  onSave,
  isLoading = false,
}) => {
  const {
    control,
    handleSubmit,
    formState: { errors, isValid },
    reset,
  } = useForm<AdminPasswordChangeFormData>({
    resolver: zodResolver(adminPasswordChangeSchema),
    mode: "onChange",
    defaultValues: {
      new_password: "",
      confirm_password: "",
    },
  });

  // Initialize form data when drawer opens
  useEffect(() => {
    if (isOpen) {
      reset({
        new_password: "",
        confirm_password: "",
      });
    }
  }, [isOpen, reset]);

  const handleSave = (data: AdminPasswordChangeFormData) => {
    onSave(data);
  };

  const handleClose = () => {
    if (!isLoading) {
      onClose();
    }
  };

  return (
    <Drawer open={isOpen} onOpenChange={handleClose}>
      <Drawer.Content className="w-full md:max-w-screen-md">
        <Drawer.Header>
          <Drawer.Title>Change Password</Drawer.Title>
          <Drawer.Description className="text-ui-fg-muted">
            Force change password for {admin?.username || "Administrator"}
          </Drawer.Description>
        </Drawer.Header>
        <Drawer.Body className="flex flex-col gap-6">
          <form onSubmit={handleSubmit(handleSave)} className="space-y-6">
            <div className="space-y-6">
              {/* New Password */}
              <div className="space-y-2">
                <Label
                  htmlFor="new-password"
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  New Password
                  <span className="text-ui-fg-error ml-1">*</span>
                </Label>
                <Controller
                  name="new_password"
                  control={control}
                  render={({ field }) => (
                    <Input
                      {...field}
                      id="new-password"
                      type="password"
                      placeholder="Enter new password (min 8 characters)"
                      disabled={isLoading}
                      aria-invalid={!!errors.new_password}
                      autoComplete="new-password"
                    />
                  )}
                />
                {errors.new_password && (
                  <Text className="text-xs text-ui-fg-error">
                    {errors.new_password.message}
                  </Text>
                )}
                <Text className="text-xs text-ui-fg-muted">
                  Password must be at least 8 characters long
                </Text>
              </div>

              {/* Confirm New Password */}
              <div className="space-y-2">
                <Label
                  htmlFor="confirm-password"
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  Confirm New Password
                  <span className="text-ui-fg-error ml-1">*</span>
                </Label>
                <Controller
                  name="confirm_password"
                  control={control}
                  render={({ field }) => (
                    <Input
                      {...field}
                      id="confirm-password"
                      type="password"
                      placeholder="Confirm new password"
                      disabled={isLoading}
                      aria-invalid={!!errors.confirm_password}
                      autoComplete="new-password"
                    />
                  )}
                />
                {errors.confirm_password && (
                  <Text className="text-xs text-ui-fg-error">
                    {errors.confirm_password.message}
                  </Text>
                )}
              </div>
            </div>
          </form>
        </Drawer.Body>
        <Drawer.Footer>
          <Button variant="danger" onClick={handleClose} disabled={isLoading}>
            <XMarkMini />
            Cancel
          </Button>
          <Button
            onClick={handleSubmit(handleSave)}
            disabled={isLoading || !isValid}
          >
            {isLoading ? <Spinner className="animate-spin" /> : <Check />}
            Change Password
          </Button>
        </Drawer.Footer>
      </Drawer.Content>
    </Drawer>
  );
};

export default AdminPasswordChangeDrawer;
