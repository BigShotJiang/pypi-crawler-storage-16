import React, { useState, useMemo, useEffect } from "react";
import {
  Button,
  DataTable,
  createDataTableColumnHelper,
  createDataTableFilterHelper,
  DataTablePaginationState,
  DataTableFilteringState,
  DataTableSortingState,
  useDataTable,
  DatePicker,
  DropdownMenu,
  IconButton,
  Prompt,
  StatusBadge,
  Badge,
} from "@medusajs/ui";
import {
  XMarkMini,
  Eye,
  Pencil,
  EllipsisHorizontal,
  Trash,
  Plus,
  InformationCircle,
  SquareGreenSolid,
  SquareRedSolid,
  QueueList,
} from "@medusajs/icons";
import { EmptyData } from "@/components/molecules";
import { AdminDetailDrawer } from "./admin-detail-drawer";
import { Administration, AdminRole, AdminStatus } from "@/types";

interface AdminFilters {
  search?: string;
  role?: AdminRole;
  is_active?: boolean;
  date_from?: string;
  date_to?: string;
  sort_by?: string;
  sort_direction?: "asc" | "desc";
}

interface PaginationProps {
  currentPage: number;
  pageSize: number;
  totalItems: number;
  totalPages: number;
}

interface AdministrationTableProps {
  data: Administration[];
  isLoading?: boolean;
  pagination: PaginationProps;
  onPageChange: (page: number) => void;
  onPageSizeChange: (pageSize: number) => void;
  onFiltersChange: (filters: AdminFilters) => void;
  filters: AdminFilters;
  onNew?: () => void;
  onInfo?: () => void;
  onEdit?: (admin: Administration) => void;
  onDelete?: (admin: Administration) => void;
  onChangePassword?: (admin: Administration) => void;
}

// Date Range Filter Component
const DateRangeFilter: React.FC<{
  dateFrom: string | undefined;
  dateTo: string | undefined;
  onDateFromChange: (date: Date | null) => void;
  onDateToChange: (date: Date | null) => void;
}> = ({ dateFrom, dateTo, onDateFromChange, onDateToChange }) => {
  return (
    <div className="flex items-center gap-2">
      <div className="flex items-center gap-2">
        <span className="text-sm font-medium text-ui-fg-base">From:</span>
        <DatePicker
          value={dateFrom ? new Date(dateFrom) : null}
          onChange={onDateFromChange}
          size="small"
          className="w-40"
          aria-label="Start Date"
        />
      </div>
      <div className="flex items-center gap-2">
        <span className="text-sm font-medium text-ui-fg-base">To:</span>
        <DatePicker
          value={dateTo ? new Date(dateTo) : null}
          onChange={onDateToChange}
          size="small"
          className="w-40"
          aria-label="End Date"
        />
      </div>
    </div>
  );
};

const columnHelper = createDataTableColumnHelper<Administration>();

// Memoize cell components for better performance
const DateCell = React.memo(({ value }: { value: string | null }) => (
  <div className="text-ui-fg-base">
    {value ? new Date(value).toLocaleString() : "Never"}
  </div>
));

const UsernameCell = React.memo(({ value }: { value: string }) => (
  <div className="font-medium text-ui-fg-base">{value}</div>
));

const EmailCell = React.memo(({ value }: { value: string | null }) => (
  <div className="text-ui-fg-base">{value || "N/A"}</div>
));

const NameCell = React.memo(
  ({
    firstName,
    lastName,
  }: {
    firstName: string | null;
    lastName: string | null;
  }) => (
    <div className="text-ui-fg-base">
      {firstName || lastName
        ? `${firstName || ""} ${lastName || ""}`.trim()
        : "N/A"}
    </div>
  )
);

const RoleCell = React.memo(({ value }: { value: AdminRole }) => {
  const formatRole = (role: string) => {
    return role
      .replace(/_/g, " ")
      .replace(/\b\w/g, (char) => char.toUpperCase());
  };

  const getColor = (value: string) => {
    switch (value) {
      case AdminRole.ADMIN:
        return "purple";
      case AdminRole.READ_ONLY:
        return "orange";
      default:
        return "green";
    }
  };

  return (
    <Badge color={getColor(value)} size="xsmall">
      {formatRole(value)}
    </Badge>
  );
});

const StatusCell = React.memo(({ value }: { value: AdminStatus }) => {
  const getColor = (value: string) => {
    switch (value) {
      case AdminStatus.ACTIVE:
        return "green";
      case AdminStatus.INACTIVE:
        return "red";
      default:
        return "orange";
    }
  };

  return (
    <div className="flex justify-center">
      <StatusBadge color={getColor(value)}>{value.toUpperCase()}</StatusBadge>
    </div>
  );
});

const ActiveCell = React.memo(({ value }: { value: boolean }) => (
  <div className="flex justify-start pl-4">
    {value ? <SquareGreenSolid /> : <SquareRedSolid />}
  </div>
));

const ActionsCell = React.memo(
  ({
    row,
    onViewDetails,
    onEdit,
    onDelete,
    onChangePassword,
  }: {
    row: any;
    onViewDetails: (admin: Administration) => void;
    onEdit?: (admin: Administration) => void;
    onDelete?: (admin: Administration) => void;
    onChangePassword?: (admin: Administration) => void;
  }) => (
    <div className="flex justify-end">
      <DropdownMenu>
        <DropdownMenu.Trigger asChild>
          <IconButton>
            <EllipsisHorizontal />
          </IconButton>
        </DropdownMenu.Trigger>
        <DropdownMenu.Content align="end">
          <DropdownMenu.Item onClick={() => onViewDetails(row.original)}>
            <Eye className="mr-2 h-4 w-4" />
            View
          </DropdownMenu.Item>
          {onEdit && (
            <DropdownMenu.Item onClick={() => onEdit(row.original)}>
              <Pencil className="mr-2 h-4 w-4" />
              Edit
            </DropdownMenu.Item>
          )}
          {onChangePassword && (
            <DropdownMenu.Item onClick={() => onChangePassword(row.original)}>
              <Pencil className="mr-2 h-4 w-4" />
              Change Password
            </DropdownMenu.Item>
          )}
          {onDelete && (
            <Prompt variant="confirmation">
              <Prompt.Trigger asChild>
                <DropdownMenu.Item
                  className="text-red-600 focus:text-red-600"
                  onSelect={(e) => e.preventDefault()}
                >
                  <Trash className="mr-2 h-4 w-4" />
                  Delete
                </DropdownMenu.Item>
              </Prompt.Trigger>
              <Prompt.Content>
                <Prompt.Header>
                  <Prompt.Title>Delete Administrator</Prompt.Title>
                  <Prompt.Description>
                    Are you sure you want to delete this administrator? This
                    action cannot be undone.
                  </Prompt.Description>
                </Prompt.Header>
                <Prompt.Footer>
                  <Prompt.Cancel>Cancel</Prompt.Cancel>
                  <Prompt.Action onClick={() => onDelete(row.original)}>
                    Delete
                  </Prompt.Action>
                </Prompt.Footer>
              </Prompt.Content>
            </Prompt>
          )}
        </DropdownMenu.Content>
      </DropdownMenu>
    </div>
  )
);

const useColumns = (
  onViewDetails: (admin: Administration) => void,
  onEdit?: (admin: Administration) => void,
  onDelete?: (admin: Administration) => void,
  onChangePassword?: (admin: Administration) => void
) => {
  return useMemo(
    () => [
      columnHelper.accessor("id", {
        header: () => <QueueList className="mr-2" />,
        enableSorting: true,
        sortLabel: "ID",
        size: 20,
        cell: ({ getValue }) => (
          <div className="font-mono text-sm">{getValue()}</div>
        ),
      }),
      columnHelper.accessor("username", {
        header: "Username",
        enableSorting: true,
        sortLabel: "Username",
        cell: ({ getValue }) => <UsernameCell value={getValue()} />,
      }),
      columnHelper.accessor("email", {
        header: "Email",
        enableSorting: true,
        sortLabel: "Email",
        cell: ({ getValue }) => <EmailCell value={getValue()} />,
      }),
      columnHelper.accessor("first_name", {
        header: "Name",
        enableSorting: false,
        cell: ({ row }) => (
          <NameCell
            firstName={row.original.first_name}
            lastName={row.original.last_name}
          />
        ),
      }),
      columnHelper.accessor("role", {
        header: "Role",
        enableSorting: true,
        sortLabel: "Role",
        cell: ({ getValue }) => <RoleCell value={getValue()} />,
      }),
      columnHelper.accessor("status", {
        header: "Status",
        enableSorting: true,
        sortLabel: "Status",
        headerAlign: "center",
        maxSize: 100,
        cell: ({ getValue }) => <StatusCell value={getValue()} />,
      }),
      columnHelper.accessor("is_active", {
        header: "Active",
        enableSorting: true,
        sortLabel: "Active",
        headerAlign: "center",
        maxSize: 70,
        cell: ({ getValue }) => <ActiveCell value={getValue()} />,
      }),
      columnHelper.accessor("last_login", {
        header: "Last Login",
        enableSorting: true,
        sortLabel: "Last Login",
        cell: ({ getValue }) => <DateCell value={getValue()} />,
      }),
      columnHelper.display({
        id: "actions",
        header: "",
        maxSize: 50,
        cell: ({ row }) => (
          <ActionsCell
            row={row}
            onViewDetails={onViewDetails}
            onEdit={onEdit}
            onDelete={onDelete}
            onChangePassword={onChangePassword}
          />
        ),
      }),
    ],
    [onViewDetails, onEdit, onDelete, onChangePassword]
  );
};

// Static filter options
const getStaticFilters = () => {
  const filterHelper = createDataTableFilterHelper<Administration>();

  return [
    filterHelper.accessor("role", {
      type: "select" as const,
      label: "Role",
      options: [
        { label: "Super Admin", value: AdminRole.SUPER_ADMIN },
        { label: "Admin", value: AdminRole.ADMIN },
        { label: "Read Only", value: AdminRole.READ_ONLY },
      ],
    }),
    filterHelper.accessor("is_active", {
      type: "radio" as const,
      label: "Active",
      options: [
        { label: "Active", value: "true" },
        { label: "Inactive", value: "false" },
      ],
    }),
  ];
};

// AdministrationTable component
export const AdministrationTable: React.FC<AdministrationTableProps> = ({
  data,
  isLoading = false,
  pagination,
  onPageChange,
  onPageSizeChange,
  onFiltersChange,
  filters,
  onNew,
  onInfo,
  onEdit,
  onDelete,
  onChangePassword,
}) => {
  // Local state for UI interactions
  const [search, setSearch] = useState(filters.search || "");
  const [filtering, setFiltering] = useState<DataTableFilteringState>({});
  const [sorting, setSorting] = useState<DataTableSortingState | null>(null);
  const [selectedAdmin, setSelectedAdmin] = useState<Administration | null>(
    null
  );
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  // Handle view details
  const handleViewDetails = (admin: Administration) => {
    setSelectedAdmin(admin);
    setIsDrawerOpen(true);
  };

  // Handle drawer close
  const handleDrawerClose = () => {
    setIsDrawerOpen(false);
    setSelectedAdmin(null);
  };

  // Handle password change
  const handleChangePassword = (admin: Administration) => {
    onChangePassword?.(admin);
  };

  // Get columns and static filters
  const columns = useColumns(
    handleViewDetails,
    onEdit,
    onDelete,
    handleChangePassword
  );
  const staticFilters = getStaticFilters();

  // Sync search with parent filters
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      onFiltersChange({ ...filters, search });
    }, 500); // Debounce search

    return () => clearTimeout(timeoutId);
  }, [search]);

  // Handle date range changes
  const handleDateFromChange = (date: Date | null) => {
    const isoString = date ? date.toISOString().split("T")[0] : undefined;
    onFiltersChange({ ...filters, date_from: isoString });
  };

  const handleDateToChange = (date: Date | null) => {
    const isoString = date ? date.toISOString().split("T")[0] : undefined;
    onFiltersChange({ ...filters, date_to: isoString });
  };

  // Sync filters with parent
  useEffect(() => {
    const newFilters: AdminFilters = { ...filters };

    // Convert DataTable filters to API filters
    Object.entries(filtering).forEach(([key, value]) => {
      if (value && typeof value === "string") {
        if (key === "role") {
          newFilters.role = value as AdminRole;
        } else if (key === "is_active") {
          newFilters.is_active = value === "true";
        }
      }
    });

    // Handle sorting
    if (sorting) {
      newFilters.sort_by = sorting.id;
      newFilters.sort_direction = sorting.desc ? "desc" : "asc";
    }

    onFiltersChange(newFilters);
  }, [filtering, sorting]);

  // Handle pagination changes
  const handlePaginationChange = (newPagination: DataTablePaginationState) => {
    onPageChange(newPagination.pageIndex + 1); // Convert 0-based to 1-based
    onPageSizeChange(newPagination.pageSize);
  };

  // Clear all filters
  const clearFilters = () => {
    setSearch("");
    setFiltering({});
    setSorting(null);
    onPageChange(1);
    onFiltersChange({});
  };

  // Convert server pagination to DataTable format
  const paginationState: DataTablePaginationState = {
    pageSize: pagination.pageSize,
    pageIndex: pagination.currentPage - 1,
  };

  // Use DataTable hook
  const table = useDataTable({
    columns,
    data: data,
    getRowId: (row: Administration) => String(row.id),
    rowCount: pagination.totalItems,
    isLoading,
    search: {
      state: search,
      onSearchChange: setSearch,
    },
    pagination: {
      state: paginationState,
      onPaginationChange: handlePaginationChange,
    },
    filtering: {
      state: filtering,
      onFilteringChange: setFiltering,
    },
    sorting: {
      state: sorting,
      onSortingChange: setSorting,
    },
    filters: staticFilters,
  });

  return (
    <>
      <DataTable instance={table}>
        <DataTable.Toolbar className="flex flex-col px-0 items-start justify-between gap-2 md:flex-row md:items-center">
          <div className="flex flex-col gap-2 md:flex-row md:items-center">
            <DateRangeFilter
              dateFrom={filters.date_from}
              dateTo={filters.date_to}
              onDateFromChange={handleDateFromChange}
              onDateToChange={handleDateToChange}
            />
            <div className="flex gap-2">
              <DataTable.Search placeholder="Search administrators..." />
              <DataTable.FilterMenu tooltip="Filter by" />
              <DataTable.SortingMenu tooltip="Sort by" />
              {search ||
              Object.keys(filtering).length > 0 ||
              sorting ||
              Object.keys(filters).some(
                (key) => key !== "search" && filters[key as keyof AdminFilters]
              ) ? (
                <Button variant="danger" size="small" onClick={clearFilters}>
                  <XMarkMini />
                </Button>
              ) : null}
            </div>
          </div>
          <div className="flex gap-2">
            {onNew && (
              <IconButton
                variant="primary"
                onClick={onNew}
                title="New Administrator"
              >
                <Plus />
              </IconButton>
            )}
            {onInfo && (
              <IconButton variant="transparent" onClick={onInfo} title="Info">
                <InformationCircle />
              </IconButton>
            )}
          </div>
        </DataTable.Toolbar>

        <DataTable.Table
          emptyState={{
            empty: {
              custom: isLoading ? null : (
                <EmptyData title="No administrators found." />
              ),
            },
          }}
        />

        <DataTable.Pagination />
      </DataTable>

      {/* Admin Detail Drawer */}
      <AdminDetailDrawer
        admin={selectedAdmin}
        isOpen={isDrawerOpen}
        onClose={handleDrawerClose}
        onEdit={onEdit}
        onDelete={onDelete}
      />
    </>
  );
};

export default AdministrationTable;
