import React, { useState } from "react";
import {
  AdminSearchRequest,
  Administration,
  AdminPasswordChange,
} from "@/types";
import { SingleColumnLayout } from "@/components/layouts/single-column";
import { ErrorDisplay } from "@/components/molecules";
import { useHydratedHeader } from "@/stores";
import {
  useAdminStore,
  useHydratedAdmin,
  useHydratedAdminStats,
} from "@/stores/administration";
import { AdministrationTable } from "./administration-table";
import { AdminNewEditDrawer } from "./admin-new-edit-drawer";
import AdminStatsContainer from "./admin-stats-container";
import AdminPasswordChangeDrawer from "./admin-password-change-drawer";
import {
  useCreateAdmin,
  useUpdateAdmin,
  useDeleteAdmin,
  useChangeAdminPassword,
} from "@/services/administration";

const AdministrationPage: React.FC = () => {
  useHydratedHeader(
    "Administrations",
    "Manage and monitor system administrators"
  );

  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [filters, setFilters] = useState<AdminSearchRequest>({});
  const [drawerItem, setDrawerItem] = useState<Administration | null>(null);
  const [drawerMode, setDrawerMode] = useState<"edit" | "new">("edit");
  const [drawerOpen, isDrawerOpen] = useState(false);
  const [passwordChangeDrawerOpen, setPasswordChangeDrawerOpen] =
    useState(false);

  const { isLoading: isAdminLoading, error: adminError } = useHydratedAdmin({
    page: currentPage,
    per_page: pageSize,
    ...filters,
  });

  const { error: statsError } = useHydratedAdminStats();

  const { admin } = useAdminStore();

  const createMutation = useCreateAdmin(() => {
    handleCloseDrawer();
  });

  const updateMutation = useUpdateAdmin(drawerItem?.id ?? 0, () => {
    handleCloseDrawer();
  });

  const deleteMutation = useDeleteAdmin(() => {
    // Handle delete success if needed
  });

  const [selectedAdminId, setSelectedAdminId] = useState<number | null>(null);
  const changePasswordMutation = useChangeAdminPassword(
    selectedAdminId || 0,
    () => {
      // Handle password change success
      handleClosePasswordChangeDrawer();
    }
  );

  const handleCloseDrawer = () => {
    isDrawerOpen(false);
    setDrawerItem(null);
  };

  const handleNewItem = () => {
    setDrawerItem(null);
    setDrawerMode("new");
    isDrawerOpen(true);
  };

  const handleEdit = (item: Administration) => {
    setDrawerItem(item);
    setDrawerMode("edit");
    isDrawerOpen(true);
  };

  const handleDelete = (item: Administration) => {
    deleteMutation.mutate(item.id);
  };

  const handleChangePassword = (item: Administration) => {
    setSelectedAdminId(item.id);
    setDrawerItem(item);
    setPasswordChangeDrawerOpen(true);
  };

  const handlePasswordChangeSave = (data: AdminPasswordChange) => {
    changePasswordMutation.mutate({
      new_password: data.new_password,
    });
  };

  const handleClosePasswordChangeDrawer = () => {
    setPasswordChangeDrawerOpen(false);
    setDrawerItem(null);
    setSelectedAdminId(null);
  };

  const handleSave = (data: Record<string, any>) => {
    if (drawerMode === "new") {
      createMutation.mutate(data as any);
    } else {
      updateMutation.mutate(data);
    }
  };

  // Handle page change
  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  // Handle page size change
  const handlePageSizeChange = (size: number) => {
    setPageSize(size);
    setCurrentPage(1);
  };

  // Handle filters change
  const handleFiltersChange = (newFilters: AdminSearchRequest) => {
    setFilters(newFilters);
    setCurrentPage(1);
  };

  if (adminError || statsError) {
    return <ErrorDisplay title="Error loading administrations data" />;
  }

  const totalRecords = admin?.total || 0;

  return (
    <SingleColumnLayout>
      <AdminStatsContainer />
      <AdministrationTable
        data={admin?.items || []}
        isLoading={isAdminLoading}
        pagination={{
          currentPage,
          pageSize,
          totalItems: totalRecords,
          totalPages: admin?.pages || 0,
        }}
        onPageChange={handlePageChange}
        onPageSizeChange={handlePageSizeChange}
        onFiltersChange={handleFiltersChange}
        filters={filters}
        onNew={handleNewItem}
        onEdit={handleEdit}
        onDelete={handleDelete}
        onChangePassword={handleChangePassword}
      />

      {/* Edit/New Drawer */}
      <AdminNewEditDrawer
        item={drawerItem}
        mode={drawerMode}
        isOpen={drawerOpen}
        onClose={handleCloseDrawer}
        onSave={handleSave}
        isLoading={
          drawerMode === "new"
            ? createMutation.isPending
            : updateMutation.isPending
        }
      />

      {/* Password Change Drawer */}
      <AdminPasswordChangeDrawer
        admin={drawerItem}
        isOpen={passwordChangeDrawerOpen}
        onClose={handleClosePasswordChangeDrawer}
        onSave={handlePasswordChangeSave}
        isLoading={changePasswordMutation.isPending}
      />
    </SingleColumnLayout>
  );
};

export default AdministrationPage;
