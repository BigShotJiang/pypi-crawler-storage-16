import React from "react";
import { Container, Heading, Button, Text, Input } from "@medusajs/ui";
import { Download, Filter } from "lucide-react";
import Select from "@/components/atoms/Select";

interface AuditFiltersProps {
  search: string;
  onSearchChange: (value: string) => void;
  selectedAction: string;
  onActionChange: (value: string) => void;
  selectedResource: string;
  onResourceChange: (value: string) => void;
  selectedAdmin: string;
  onAdminChange: (value: string) => void;
  dateFrom: string;
  onDateFromChange: (value: string) => void;
  dateTo: string;
  onDateToChange: (value: string) => void;
  onClearFilters: () => void;
  onExport: () => void;
  adminOptions?: { label: string; value: string }[];
}

const AuditFilters: React.FC<AuditFiltersProps> = ({
  search,
  onSearchChange,
  selectedAction,
  onActionChange,
  selectedResource,
  onResourceChange,
  selectedAdmin,
  onAdminChange,
  dateFrom,
  onDateFromChange,
  dateTo,
  onDateToChange,
  onClearFilters,
  onExport,
  adminOptions = [],
}) => (
  <Container className="rounded-lg border bg-ui-bg-component text-ui-fg-base shadow-sm">
    <div className="p-6">
      <Heading
        level="h3"
        className="text-lg font-medium text-ui-fg-base mb-4 flex items-center"
      >
        <Filter className="mr-2 h-5 w-5" />
        Filters
      </Heading>
      <div className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Search */}
          <div className="md:col-span-2 lg:col-span-1">
            <Text className="text-sm font-medium text-ui-fg-base mb-2 block">
              Search
            </Text>
            <Input
              id="audit-filter"
              placeholder="Search logs..."
              value={search}
              onChange={(e) => onSearchChange(e.target.value)}
              type="search"
            />
          </div>

          {/* Action Filter */}
          <div>
            <Text className="text-sm font-medium text-ui-fg-base mb-2 block">
              Action
            </Text>
            <Select
              value={selectedAction}
              onChange={(value) => onActionChange(value)}
              placeholder="All Actions"
            >
              <option value="">All Actions</option>
              <option value="create">Create</option>
              <option value="update">Update</option>
              <option value="delete">Delete</option>
            </Select>
          </div>

          {/* Resource Type Filter */}
          <div>
            <Text className="text-sm font-medium text-ui-fg-base mb-2 block">
              Resource Type
            </Text>
            <Select
              value={selectedResource}
              onChange={(value) => onResourceChange(value)}
              placeholder="All Resources"
            >
              <option value="">All Resources</option>
              <option value="user">User</option>
              <option value="model">Model</option>
            </Select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Admin Filter */}
          <div>
            <Text className="text-sm font-medium text-ui-fg-base mb-2 block">
              Admin
            </Text>
            <Select
              value={selectedAdmin}
              onChange={(value) => onAdminChange(value)}
              placeholder="All Admins"
            >
              <option value="">All Admins</option>
              {adminOptions.map((admin) => (
                <option key={admin.value} value={admin.value}>
                  {admin.label}
                </option>
              ))}
            </Select>
          </div>

          {/* Date From */}
          <div>
            <Text className="text-sm font-medium text-ui-fg-base mb-2 block">
              From Date
            </Text>
            <Input
              type="datetime-local"
              value={dateFrom}
              onChange={(e) => onDateFromChange(e.target.value)}
            />
          </div>

          {/* Date To */}
          <div>
            <Text className="text-sm font-medium text-ui-fg-base mb-2 block">
              To Date
            </Text>
            <Input
              type="datetime-local"
              value={dateTo}
              onChange={(e) => onDateToChange(e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center justify-between">
        <div className="flex gap-2">
          <Button variant="secondary" onClick={onClearFilters}>
            Clear Filters
          </Button>
          <Button onClick={onExport} className="flex items-center">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>
    </div>
  </Container>
);

export default AuditFilters;
