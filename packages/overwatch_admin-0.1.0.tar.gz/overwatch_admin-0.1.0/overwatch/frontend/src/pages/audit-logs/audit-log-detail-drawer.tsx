import React from "react";
import {
  Drawer,
  Text,
  Heading as HeadingComponent,
  Container,
  CodeBlock,
  Label,
  StatusBadge,
} from "@medusajs/ui";
import {
  Clock,
  CheckCircle,
  Edit,
  Trash2,
  Globe,
  Shield,
  AlertCircle,
} from "lucide-react";
import { AuditLog } from "@/types";
import { InformationCircle } from "@medusajs/icons";
import { formatJson } from "@/lib/utils";

interface AuditLogDetailDrawerProps {
  log: AuditLog | null;
  isOpen: boolean;
  onClose: () => void;
}

export const AuditLogDetailDrawer: React.FC<AuditLogDetailDrawerProps> =
  React.memo(({ log, isOpen, onClose }) => {
    if (!log) return null;

    const snippets = [
      {
        label: "Old Values",
        language: "json",
        code: log.old_values ?? formatJson("{}"),
      },
      {
        label: "New Values",
        language: "json",
        code: log.new_values ?? formatJson("{}"),
      },
      {
        label: "Changes Summary",
        language: "json",
        code: log.changes_summary ?? formatJson("{}"),
      },
    ];

    return (
      <Drawer open={isOpen} onOpenChange={onClose}>
        <Drawer.Content>
          <Drawer.Header>
            <Drawer.Title>Audit Log Details</Drawer.Title>
            <Drawer.Description className="text-ui-fg-muted">
              Detailed information about the selected audit log entry.
            </Drawer.Description>
          </Drawer.Header>
          <Drawer.Body className="flex flex-col gap-6 overflow-auto">
            <Container className="divide-y">
              {/* Basic Information */}
              <div className="py-4">
                <HeadingComponent
                  level="h3"
                  className="mb-4 flex items-center gap-2"
                >
                  <Shield className="h-5 w-5" />
                  Basic Information
                </HeadingComponent>
                <div className="grid gap-3 text-sm">
                  <div className="flex justify-between">
                    <Text className="text-ui-fg-muted">ID:</Text>
                    <Text className="font-mono">{log.id}</Text>
                  </div>
                  <div className="flex justify-between">
                    <Text className="text-ui-fg-muted">Date & Time:</Text>
                    <Text>{new Date(log.created_at).toLocaleString()}</Text>
                  </div>
                  <div className="flex justify-between">
                    <Text className="text-ui-fg-muted">Admin:</Text>
                    <Text>{log.admin_username}</Text>
                  </div>
                  <div className="flex justify-between">
                    <Text className="text-ui-fg-muted">Action:</Text>
                    <div className="flex items-center gap-2">
                      {(() => {
                        switch (log.action.toLowerCase()) {
                          case "create":
                            return (
                              <CheckCircle className="h-4 w-4 text-ui-fg-success" />
                            );
                          case "update":
                            return (
                              <Edit className="h-4 w-4 text-ui-fg-interactive" />
                            );
                          case "delete":
                            return (
                              <Trash2 className="h-4 w-4 text-ui-fg-error" />
                            );
                          default:
                            return (
                              <Clock className="h-4 w-4 text-ui-fg-muted" />
                            );
                        }
                      })()}
                      <Text className="capitalize">
                        {log.action_display || log.action}
                      </Text>
                    </div>
                  </div>
                  <div className="flex justify-between">
                    <Text className="text-ui-fg-muted">Status:</Text>
                    <StatusBadge color={log.success ? "green" : "red"}>
                      {log.success ? "Success" : "Failed"}
                    </StatusBadge>
                  </div>
                </div>
              </div>

              {/* Resource Information */}
              <div className="py-4">
                <HeadingComponent
                  level="h3"
                  className="mb-4 flex items-center gap-2"
                >
                  <Clock className="h-5 w-5" />
                  Resource Information
                </HeadingComponent>
                <div className="grid gap-3 text-sm">
                  <div className="flex justify-between">
                    <Text className="text-ui-fg-muted">Resource Type:</Text>
                    <Text className="capitalize">{log.resource_type}</Text>
                  </div>
                  <div className="flex justify-between">
                    <Text className="text-ui-fg-muted">Resource ID:</Text>
                    <Text className="font-mono">{log.resource_id}</Text>
                  </div>
                  <div className="flex justify-between">
                    <Text className="text-ui-fg-muted">Resource Display:</Text>
                    <Text>{log.resource_display || "N/A"}</Text>
                  </div>
                </div>
              </div>

              {/* Network Information */}
              <div className="py-4">
                <HeadingComponent
                  level="h3"
                  className="mb-4 flex items-center gap-2"
                >
                  <Globe className="h-5 w-5" />
                  Network Information
                </HeadingComponent>
                <div className="grid gap-3 text-sm">
                  <div className="flex justify-between">
                    <Text className="text-ui-fg-muted">IP Address:</Text>
                    <Text className="font-mono">{log.ip_address}</Text>
                  </div>
                  <div className="flex justify-between items-start">
                    <Text className="text-ui-fg-muted">User Agent:</Text>
                    <Text className="text-right max-w-xs break-words text-xs">
                      {log.user_agent || "N/A"}
                    </Text>
                  </div>
                </div>
              </div>

              {/* Error Information */}
              {!log.success && log.error_message && (
                <div className="py-4">
                  <HeadingComponent
                    level="h3"
                    className="mb-4 flex items-center gap-2"
                  >
                    <AlertCircle className="h-5 w-5 text-ui-fg-error" />
                    Error Information
                  </HeadingComponent>
                  <div className="grid gap-3 text-sm">
                    <div>
                      <Text className="text-ui-fg-muted mb-2">
                        Error Message:
                      </Text>
                      <Text className="text-ui-fg-error bg-ui-bg-component-hover p-3 rounded">
                        {log.error_message}
                      </Text>
                    </div>
                  </div>
                </div>
              )}

              {/* Changes Information */}
              {(log.old_values || log.new_values || log.changes_summary) && (
                <div className="py-4">
                  <HeadingComponent
                    level="h3"
                    className="mb-4 flex items-center gap-2"
                  >
                    <Edit className="h-5 w-5" />
                    Changes Information
                  </HeadingComponent>
                  <div className="space-y-4">
                    <CodeBlock snippets={snippets}>
                      <CodeBlock.Header>
                        <CodeBlock.Header.Meta>
                          <Label weight={"plus"}>
                            <InformationCircle />
                          </Label>
                        </CodeBlock.Header.Meta>
                      </CodeBlock.Header>
                      <CodeBlock.Body />
                    </CodeBlock>
                  </div>
                </div>
              )}
            </Container>
          </Drawer.Body>
        </Drawer.Content>
      </Drawer>
    );
  });

export default AuditLogDetailDrawer;
