import React, { useState } from "react";
import { Clock } from "lucide-react";
import { AuditFilters } from "@/types";
import { SingleColumnLayout } from "@/components/layouts/single-column";
import AuditStatsCard from "./audit-stats-card";
import { AuditLogsTable } from "./audit-logs-table";
import { ErrorDisplay } from "@/components/molecules";
import {
  useAuditStore,
  useHydratedStatistic,
  useStatisticStore,
  useHydratedAudit,
} from "@/stores/audit";
import { useHydratedHeader } from "@/stores";

const AuditLogsPage: React.FC = () => {
  useHydratedHeader("Audit Logs", "View and track all administrative actions");

  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [filters, setFilters] = useState<AuditFilters>({});

  const { error: statisticError } = useHydratedStatistic();

  const { isLoading: isAuditLoading, error: auditError } = useHydratedAudit({
    page: currentPage,
    per_page: pageSize,
    ...filters,
  });

  const { statistic } = useStatisticStore();
  const { audit } = useAuditStore();

  if (statisticError && auditError) {
    return <ErrorDisplay title="Error loading audit logs data" />;
  }

  return (
    <SingleColumnLayout>
      {statistic && (
        <div className="my-4 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          <AuditStatsCard
            title="Total Actions"
            value={statistic.total_logs ?? 0}
            icon={<Clock className="h-6 w-6" />}
          />
          <AuditStatsCard
            title="Success Rate"
            value={`${statistic.success_rate.toFixed(0) ?? 0}%`}
            icon={<Clock className="h-6 w-6" />}
          />
          <AuditStatsCard
            title="Successful Actions"
            value={statistic.successful_actions ?? 0}
            icon={<Clock className="h-6 w-6" />}
          />
          <AuditStatsCard
            title="Failed Actions"
            value={statistic.failed_actions ?? 0}
            icon={<Clock className="h-6 w-6" />}
          />
        </div>
      )}

      <AuditLogsTable
        data={audit?.items || []}
        isLoading={isAuditLoading}
        pagination={{
          currentPage,
          pageSize,
          totalItems: audit?.total || 0,
          totalPages: audit?.pages || 0,
        }}
        onPageChange={setCurrentPage}
        onPageSizeChange={setPageSize}
        onFiltersChange={setFilters}
        filters={filters}
      />
    </SingleColumnLayout>
  );
};

export default AuditLogsPage;
