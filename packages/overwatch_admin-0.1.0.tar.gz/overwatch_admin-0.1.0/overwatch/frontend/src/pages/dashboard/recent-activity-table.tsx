import React, { useState, useMemo } from "react";
import {
  Heading,
  Button,
  DataTable,
  createDataTableColumnHelper,
  createDataTableFilterHelper,
  DataTablePaginationState,
  DataTableFilteringState,
  DataTableSortingState,
  useDataTable,
  StatusBadge,
} from "@medusajs/ui";
import { XMarkMini } from "@medusajs/icons";
import { RecentActivity } from "@/types";
import { EmptyData } from "@/components/molecules";

interface RecentActivityTableProps {
  data: RecentActivity[];
  isLoading?: boolean;
}

const columnHelper = createDataTableColumnHelper<RecentActivity>();

const useColumns = () => {
  return useMemo(
    () => [
      columnHelper.accessor("action_display", {
        header: "Action",
        enableSorting: true,
        cell: ({ getValue, row }) => {
          const value = getValue() || row.original.action;
          return <div className="font-medium text-ui-fg-base">{value}</div>;
        },
      }),
      columnHelper.accessor("resource_display", {
        header: "Resource",
        enableSorting: true,
        cell: ({ getValue, row }) => {
          const value =
            getValue() ||
            `${row.original.resource_type}:${row.original.resource_id}`;
          return <div className="text-ui-fg-subtle">{value}</div>;
        },
      }),
      columnHelper.accessor("admin_username", {
        header: "Admin",
        enableSorting: true,
        cell: ({ getValue }) => (
          <div className="text-ui-fg-subtle">{getValue()}</div>
        ),
      }),
      columnHelper.accessor("created_at", {
        header: "Time",
        enableSorting: true,
        cell: ({ getValue }) => (
          <div className="text-ui-fg-subtle">
            {new Date(getValue()).toLocaleString()}
          </div>
        ),
      }),
      columnHelper.accessor("success", {
        header: "Status",
        enableSorting: true,
        cell: ({ getValue }) => (
          <StatusBadge color={getValue() ? "green" : "red"}>
            {getValue() ? "Success" : "Failed"}
          </StatusBadge>
        ),
      }),
    ],
    []
  );
};

const useFilters = (data: RecentActivity[]) => {
  const filterHelper = createDataTableFilterHelper<RecentActivity>();

  return useMemo(() => {
    // Get unique values for filters
    const uniqueActions = [...new Set(data.map((a) => a.action))];
    const uniqueAdmins = [...new Set(data.map((a) => a.admin_username))];

    return [
      filterHelper.accessor("action", {
        type: "select" as const,
        label: "Action",
        options: uniqueActions.map((action) => ({
          label: action
            .replace("_", " ")
            .replace(/\b\w/g, (l) => l.toUpperCase()),
          value: action,
        })),
      }),
      filterHelper.accessor("success", {
        type: "radio" as const,
        label: "Status",
        options: [
          { label: "Success", value: "true" },
          { label: "Failed", value: "false" },
        ],
      }),
      filterHelper.accessor("admin_username", {
        type: "select" as const,
        label: "Admin",
        options: uniqueAdmins.map((admin) => ({
          label: admin,
          value: admin.toLowerCase(),
        })),
      }),
    ];
  }, [data]);
};

// Custom hook to process data with filtering, sorting, and searching
const useProcessedData = (
  data: RecentActivity[],
  search: string,
  filtering: DataTableFilteringState,
  sorting: DataTableSortingState | null
) => {
  return useMemo(() => {
    if (!data.length) return [];

    let filtered = [...data];

    // Apply search
    if (search) {
      const searchLower = search.toLowerCase();
      filtered = filtered.filter((activity) => {
        const action = (
          activity.action_display ||
          activity.action ||
          ""
        ).toLowerCase();
        const resource = (
          activity.resource_display ||
          `${activity.resource_type}:${activity.resource_id}` ||
          ""
        ).toLowerCase();
        const admin = (activity.admin_username || "").toLowerCase();

        return (
          action.includes(searchLower) ||
          resource.includes(searchLower) ||
          admin.includes(searchLower)
        );
      });
    }

    // Apply filters
    Object.entries(filtering).forEach(([key, value]) => {
      if (!value) return;

      if (key === "action" && typeof value === "string") {
        filtered = filtered.filter((activity) => activity.action === value);
      } else if (key === "success" && typeof value === "string") {
        filtered = filtered.filter(
          (activity) => activity.success === (value === "true")
        );
      } else if (key === "admin_username" && typeof value === "string") {
        filtered = filtered.filter(
          (activity) => activity.admin_username.toLowerCase() === value
        );
      } else if (Array.isArray(value)) {
        filtered = filtered.filter((activity) => {
          const activityValue = activity[key as keyof RecentActivity];
          return value.includes(String(activityValue).toLowerCase());
        });
      }
    });

    // Apply sorting
    if (sorting) {
      filtered.sort((a, b) => {
        const aValue = a[sorting.id as keyof RecentActivity];
        const bValue = b[sorting.id as keyof RecentActivity];

        if (aValue === undefined || bValue === undefined) return 0;

        let comparison = 0;
        if (aValue < bValue) comparison = -1;
        if (aValue > bValue) comparison = 1;

        return sorting.desc ? -comparison : comparison;
      });
    }

    return filtered;
  }, [data, search, filtering, sorting]);
};

// RecentActivityTable component
export const RecentActivityTable: React.FC<RecentActivityTableProps> = ({
  data,
  isLoading = false,
}) => {
  // Table state
  const [search, setSearch] = useState("");
  const [pagination, setPagination] = useState<DataTablePaginationState>({
    pageSize: 5,
    pageIndex: 0,
  });
  const [filtering, setFiltering] = useState<DataTableFilteringState>({});
  const [sorting, setSorting] = useState<DataTableSortingState | null>(null);

  // Get columns and filters - memoized to prevent unnecessary re-renders
  const columns = useColumns();
  const filters = useFilters(data);

  // Process data with filtering, sorting, and searching - memoized
  const processedData = useProcessedData(data, search, filtering, sorting);

  // Apply pagination - memoized for performance
  const paginatedData = useMemo(() => {
    const startIndex = pagination.pageIndex * pagination.pageSize;
    return processedData.slice(startIndex, startIndex + pagination.pageSize);
  }, [processedData, pagination]);

  // Memoize clearFilters function to prevent unnecessary re-renders
  const clearFilters = useMemo(
    () => () => {
      setFiltering({});
      setSearch("");
      setSorting(null);
      setPagination({ pageSize: 5, pageIndex: 0 });
    },
    []
  );

  // Use DataTable hook
  const table = useDataTable({
    columns,
    data: paginatedData,
    getRowId: (row: RecentActivity) => String(row.id),
    rowCount: processedData.length,
    isLoading,
    search: {
      state: search,
      onSearchChange: setSearch,
    },
    pagination: {
      state: pagination,
      onPaginationChange: setPagination,
    },
    filtering: {
      state: filtering,
      onFilteringChange: setFiltering,
    },
    sorting: {
      state: sorting,
      onSortingChange: setSorting,
    },
    filters,
  });

  return (
    <DataTable instance={table}>
      <DataTable.Toolbar className="flex flex-col items-start justify-between gap-2 md:flex-row md:items-center">
        <Heading level="h3">Recent Activity</Heading>
        <div className="flex gap-2">
          <DataTable.Search placeholder="Search..." />
          <DataTable.FilterMenu />
          <DataTable.SortingMenu />
          {search || Object.keys(filtering).length > 0 || sorting ? (
            <Button variant="danger" size="small" onClick={clearFilters}>
              <XMarkMini />
            </Button>
          ) : null}
        </div>
      </DataTable.Toolbar>
      {!isLoading && data.length === 0 ? (
        <EmptyData title="No recent activity found." />
      ) : (
        <>
          <DataTable.Table />
          <DataTable.Pagination />
        </>
      )}
    </DataTable>
  );
};

export default RecentActivityTable;
