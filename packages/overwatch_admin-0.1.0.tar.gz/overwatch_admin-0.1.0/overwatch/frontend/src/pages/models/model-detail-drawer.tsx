import React from "react";
import { Drawer, Text, Button, Prompt, StatusBadge } from "@medusajs/ui";
import { Pencil, Trash } from "@medusajs/icons";
import { SecureFieldCell } from "@/components/atoms/SecureFieldCell";
import { ModelField, ModelItem } from "@/types";

interface ModelDetailDrawerProps {
  item: ModelItem | null;
  modelName: string;
  modelFields: ModelField[];
  isOpen: boolean;
  onClose: () => void;
  onEdit?: (item: ModelItem) => void;
  onDelete?: (item: ModelItem) => void;
}

export const ModelDetailDrawer: React.FC<ModelDetailDrawerProps> = React.memo(
  ({ item, modelName, modelFields, isOpen, onClose, onEdit, onDelete }) => {
    if (!item) return null;

    const formatFieldValue = (value: any, fieldType: string): string => {
      if (value === null || value === undefined) return "N/A";

      switch (fieldType) {
        case "datetime":
        case "date":
          return new Date(value).toLocaleString();
        case "boolean":
          return value ? "Yes" : "No";
        case "object":
        case "json":
          try {
            return JSON.stringify(value, null, 2);
          } catch {
            return String(value);
          }
        default:
          return String(value);
      }
    };

    const getFieldLabel = (fieldName: string, field?: ModelField) => {
      if (field?.label) fieldName = field.label;

      if (
        fieldName.toLowerCase() === "ip" ||
        fieldName.toLowerCase() === "id"
      ) {
        return fieldName.toUpperCase();
      }

      return (
        fieldName
          .replace(/_/g, " ")
          // First letter uppercase
          .replace(/^\w/, (char) => char.toUpperCase())
          // Handle IP and ID within compound words
          .replace(/\b(ip|id)\b/gi, (match) => match.toUpperCase())
          // First letter of each word uppercase
          .replace(/\s\w/g, (match) => match.toUpperCase())
      );
    };

    // Helper function to detect sensitive fields (same logic as SecureFieldCell)
    const isSensitiveField = (
      fieldName: string,
      fieldType: string
    ): boolean => {
      const sensitiveKeywords = [
        "password",
        "passwd",
        "secret",
        "token",
        "key",
        "auth",
        "credential",
        "api_key",
        "access_key",
        "private_key",
      ];

      const lowerFieldName = fieldName.toLowerCase();

      return (
        fieldType === "password" ||
        sensitiveKeywords.some((keyword) => lowerFieldName.includes(keyword))
      );
    };

    return (
      <Drawer open={isOpen} onOpenChange={onClose}>
        <Drawer.Content className="w-full md:max-w-screen-md">
          <Drawer.Header>
            <Drawer.Title>{modelName}</Drawer.Title>
            <Drawer.Description className="text-ui-fg-muted">
              Detailed information about {modelName.toLowerCase()}.
            </Drawer.Description>
          </Drawer.Header>
          <Drawer.Body className="flex flex-col gap-6 overflow-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {modelFields.map((field) => (
                <div key={field.name} className="grid gap-2">
                  <div className="flex items-center gap-2">
                    <Text className="text-sm font-medium text-ui-fg-muted">
                      {getFieldLabel(field.name, field)}
                    </Text>
                    <StatusBadge color="blue">{field.type}</StatusBadge>
                    {!field.nullable && (
                      <StatusBadge color="red">required</StatusBadge>
                    )}
                  </div>
                  <div className="ml-4">
                    {field.type === "json" || field.type === "object" ? (
                      <pre className="bg-ui-bg-component-hover p-3 rounded text-xs overflow-auto max-h-40">
                        {formatFieldValue(item[field.name], field.type)}
                      </pre>
                    ) : isSensitiveField(field.name, field.type) ? (
                      <div className="flex items-center gap-2">
                        <SecureFieldCell
                          value={item[field.name]}
                          fieldType={field.type}
                          fieldName={field.name}
                        />
                      </div>
                    ) : (
                      <Text className="text-sm text-ui-fg-base font-mono">
                        {formatFieldValue(item[field.name], field.type)}
                      </Text>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </Drawer.Body>
          <Drawer.Footer>
            {onEdit && (
              <Button
                variant="secondary"
                onClick={() => onEdit(item)}
                className="flex items-center"
              >
                <Pencil />
                Edit
              </Button>
            )}
            {onDelete && (
              <Prompt variant="confirmation">
                <Prompt.Trigger asChild>
                  <Button variant="danger" className="flex items-center">
                    <Trash />
                    Delete
                  </Button>
                </Prompt.Trigger>
                <Prompt.Content>
                  <Prompt.Header>
                    <Prompt.Title>Delete Confirmation</Prompt.Title>
                    <Prompt.Description>
                      Are you sure you want to delete this row?
                    </Prompt.Description>
                  </Prompt.Header>
                  <Prompt.Footer>
                    <Prompt.Cancel>Cancel</Prompt.Cancel>
                    <Prompt.Action onClick={() => onDelete(item)}>
                      Delete
                    </Prompt.Action>
                  </Prompt.Footer>
                </Prompt.Content>
              </Prompt>
            )}
          </Drawer.Footer>
        </Drawer.Content>
      </Drawer>
    );
  }
);

export default ModelDetailDrawer;
