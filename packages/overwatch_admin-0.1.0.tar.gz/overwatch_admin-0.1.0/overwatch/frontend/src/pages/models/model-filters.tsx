import React from "react";
import { Container, Heading, Button, Text, Input } from "@medusajs/ui";
import { Download, Filter } from "lucide-react";
import Select from "@/components/atoms/Select";
import { ModelField } from "@/types";

interface ModelFiltersProps {
  search: string;
  onSearchChange: (value: string) => void;
  selectedField: string;
  onFieldChange: (value: string) => void;
  fieldType: string;
  onFieldTypeChange: (value: string) => void;
  dateFrom: string;
  onDateFromChange: (value: string) => void;
  dateTo: string;
  onDateToChange: (value: string) => void;
  onClearFilters: () => void;
  onExport: () => void;
  modelFields?: ModelField[];
}

const ModelFilters: React.FC<ModelFiltersProps> = ({
  search,
  onSearchChange,
  selectedField,
  onFieldChange,
  fieldType,
  onFieldTypeChange,
  dateFrom,
  onDateFromChange,
  dateTo,
  onDateToChange,
  onClearFilters,
  onExport,
  modelFields = [],
}) => {
  const dateFields = modelFields.filter(
    (field) => field.type === "datetime" || field.type === "date"
  );
  const searchableFields = modelFields.filter(
    (field) => field.type === "string" || field.type === "text"
  );

  return (
    <Container className="rounded-lg border bg-ui-bg-component text-ui-fg-base shadow-sm">
      <div className="p-6">
        <Heading
          level="h3"
          className="text-lg font-medium text-ui-fg-base mb-4 flex items-center"
        >
          <Filter className="mr-2 h-5 w-5" />
          Filters
        </Heading>
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* Search */}
            <div className="md:col-span-2 lg:col-span-1">
              <Text className="text-sm font-medium text-ui-fg-base mb-2 block">
                Search
              </Text>
              <Input
                id="model-filter"
                placeholder="Search records..."
                value={search}
                onChange={(e) => onSearchChange(e.target.value)}
                type="search"
              />
            </div>

            {/* Field Filter */}
            <div>
              <Text className="text-sm font-medium text-ui-fg-base mb-2 block">
                Field
              </Text>
              <Select
                value={selectedField}
                onChange={(value) => onFieldChange(value)}
                placeholder="All Fields"
              >
                <option value="">All Fields</option>
                {searchableFields.map((field) => (
                  <option key={field.name} value={field.name}>
                    {field.label ||
                      field.name
                        .replace(/_/g, " ")
                        .replace(/\b\w/g, (char) => char.toUpperCase())}
                  </option>
                ))}
              </Select>
            </div>

            {/* Field Type Filter */}
            <div>
              <Text className="text-sm font-medium text-ui-fg-base mb-2 block">
                Field Type
              </Text>
              <Select
                value={fieldType}
                onChange={(value) => onFieldTypeChange(value)}
                placeholder="All Types"
              >
                <option value="">All Types</option>
                <option value="string">String</option>
                <option value="number">Number</option>
                <option value="boolean">Boolean</option>
                <option value="date">Date</option>
                <option value="datetime">DateTime</option>
              </Select>
            </div>
          </div>

          {dateFields.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {/* Date From */}
              <div>
                <Text className="text-sm font-medium text-ui-fg-base mb-2 block">
                  From Date
                </Text>
                <Input
                  type="datetime-local"
                  value={dateFrom}
                  onChange={(e) => onDateFromChange(e.target.value)}
                />
              </div>

              {/* Date To */}
              <div>
                <Text className="text-sm font-medium text-ui-fg-base mb-2 block">
                  To Date
                </Text>
                <Input
                  type="datetime-local"
                  value={dateTo}
                  onChange={(e) => onDateToChange(e.target.value)}
                />
              </div>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="flex items-center justify-between mt-6">
          <div className="flex gap-2">
            <Button variant="secondary" onClick={onClearFilters}>
              Clear Filters
            </Button>
            <Button onClick={onExport} className="flex items-center">
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
          </div>
        </div>
      </div>
    </Container>
  );
};

export default ModelFilters;
