import React, { useEffect } from "react";
import { Drawer, Button } from "@medusajs/ui";
import { Save, X } from "lucide-react";
import { FormField } from "@/components/atoms/FormField";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { createModelSchema } from "@/lib/validations";
import { ModelField, ModelItem } from "@/types";

type Mode = "edit" | "new";

interface ModelNewEditDrawerProps {
  item: ModelItem | null;
  mode: Mode;
  modelName: string;
  modelFields: ModelField[];
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Record<string, any>) => void;
  isLoading?: boolean;
}

export const ModelNewEditDrawer: React.FC<ModelNewEditDrawerProps> = React.memo(
  ({
    item,
    mode,
    modelName,
    modelFields,
    isOpen,
    onClose,
    onSave,
    isLoading = false,
  }) => {
    const {
      control,
      handleSubmit,
      formState: { errors, isValid },
      reset,
    } = useForm<Record<string, any>>({
      resolver: zodResolver(createModelSchema(modelFields, mode)),
      mode: "onChange",
    });

    // Initialize form data when item or mode changes
    useEffect(() => {
      if (mode === "new") {
        // Initialize with appropriate defaults for new mode
        const initialData: Record<string, any> = {};
        modelFields.forEach((field) => {
          if (field.type === "boolean") {
            initialData[field.name] = false;
          } else if (field.type === "integer" || field.type === "number") {
            // For nullable/optional number fields, start with null
            initialData[field.name] = !field.nullable ? 0 : null;
          } else if (field.type === "date" || field.type === "datetime") {
            // Date fields start as null (will be handled by DatePicker)
            initialData[field.name] = null;
          } else {
            // String fields: empty string for required, null for optional
            initialData[field.name] = !field.nullable ? "" : null;
          }
        });
        reset(initialData);
      } else if (item) {
        // Initialize with item data for edit mode
        const sanitizedItem: Record<string, any> = {};
        modelFields.forEach((field) => {
          const value = item[field.name as keyof ModelItem];
          if (value === null || value === undefined) {
            // Handle null/undefined values based on field type and requirement
            if (field.type === "boolean") {
              sanitizedItem[field.name] = false;
            } else if (field.type === "integer" || field.type === "number") {
              sanitizedItem[field.name] = !field.nullable ? 0 : null;
            } else if (field.type === "date" || field.type === "datetime") {
              sanitizedItem[field.name] = null;
            } else {
              // String fields: empty string for required, null for optional
              sanitizedItem[field.name] = !field.nullable ? "" : null;
            }
          } else {
            sanitizedItem[field.name] = value;
          }
        });
        reset(sanitizedItem);
      }
    }, [item, mode, modelFields, reset]);

    const handleSave = (data: Record<string, any>) => {
      onSave(data);
    };

    const handleClose = () => {
      if (!isLoading) {
        onClose();
      }
    };

    const isEditMode = mode === "edit";
    const title = isEditMode
      ? `Edit ${modelName.slice(0, -1)}`
      : `New ${modelName.slice(0, -1)}`;
    const description = isEditMode
      ? `Modify the information for this ${modelName.slice(0, -1)} below.`
      : `Create a new ${modelName.slice(
          0,
          -1
        )} by filling out the information below.`;
    const actionText = isEditMode ? "Save Changes" : "Create";

    return (
      <Drawer open={isOpen} onOpenChange={handleClose}>
        <Drawer.Content className="w-full md:max-w-screen-xl">
          <Drawer.Header>
            <Drawer.Title>{title}</Drawer.Title>
            <Drawer.Description className="text-ui-fg-muted">
              {description}
            </Drawer.Description>
          </Drawer.Header>
          <Drawer.Body className="flex flex-col gap-6 overflow-auto">
            <form onSubmit={handleSubmit(handleSave)}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {modelFields.map((field) => {
                  // Skip ID field for new mode, make readonly for edit mode
                  if (mode === "new" && field.name === "id") return null;

                  const isReadonly =
                    isEditMode &&
                    (field.name === "id" || field.name.includes("password"));

                  return (
                    <div key={field.name} className="space-y-2">
                      <Controller
                        name={field.name}
                        control={control}
                        render={({ field: controllerField }) => (
                          <FormField
                            field={{
                              ...field,
                              readonly: isReadonly,
                            }}
                            value={controllerField.value}
                            onChange={(name, value) => {
                              if (name === field.name) {
                                controllerField.onChange(value);
                              }
                            }}
                            disabled={isLoading}
                            error={
                              errors[field.name]
                                ? (errors[field.name] as any)?.message ||
                                  String(errors[field.name])
                                : undefined
                            }
                            onBlur={() => {
                              controllerField.onBlur();
                            }}
                          />
                        )}
                      />
                    </div>
                  );
                })}
              </div>
              <div className="mt-6 flex justify-end gap-2">
                <Button
                  variant="danger"
                  onClick={handleClose}
                  disabled={isLoading}
                  className="flex items-center"
                  type="button"
                >
                  <X className="mr-2 h-4 w-4" />
                  Cancel
                </Button>
                <Button
                  variant="primary"
                  type="submit"
                  disabled={isLoading || !isValid}
                  className="flex items-center"
                >
                  <Save className="mr-2 h-4 w-4" />
                  {actionText}
                </Button>
              </div>
            </form>
          </Drawer.Body>
        </Drawer.Content>
      </Drawer>
    );
  }
);

export default ModelNewEditDrawer;
