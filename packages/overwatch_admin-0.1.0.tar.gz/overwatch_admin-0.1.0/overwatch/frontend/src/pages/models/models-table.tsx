import React, { useState, useMemo, useEffect } from "react";
import {
  Button,
  DataTable,
  createDataTableColumnHelper,
  createDataTableFilterHelper,
  createDataTableCommandHelper,
  DataTablePaginationState,
  DataTableFilteringState,
  DataTableSortingState,
  DataTableRowSelectionState,
  useDataTable,
  DatePicker,
  DropdownMenu,
  IconButton,
  Prompt,
} from "@medusajs/ui";
import {
  XMarkMini,
  Eye,
  Pencil,
  EllipsisHorizontal,
  Trash,
  QueueList,
  Loader,
  Plus,
  InformationCircle,
} from "@medusajs/icons";
import { EmptyData } from "@/components/molecules";
import { ModelDetailDrawer } from "./model-detail-drawer";
import { SecureFieldCell } from "@/components/atoms/SecureFieldCell";
import { ModelField, ModelItem } from "@/types";

interface ModelFilters {
  search?: string;
  field?: string;
  field_type?: string;
  date_from?: string;
  date_to?: string;
  sort_by?: string;
  sort_direction?: "asc" | "desc";
}

interface PaginationProps {
  currentPage: number;
  pageSize: number;
  totalItems: number;
  totalPages: number;
}

interface ModelsTableProps {
  data: ModelItem[];
  modelName: string;
  modelFields: ModelField[];
  isLoading?: boolean;
  pagination: PaginationProps;
  onPageChange: (page: number) => void;
  onPageSizeChange: (pageSize: number) => void;
  onFiltersChange: (filters: ModelFilters) => void;
  filters: ModelFilters;
  onNew?: () => void;
  onInfo?: () => void;
  onEdit?: (item: ModelItem) => void;
  onDelete?: (item: ModelItem) => void;
  onBulkDelete?: (ids: number[]) => void;
}

// Date Range Filter Component
const DateRangeFilter: React.FC<{
  dateFrom: string | undefined;
  dateTo: string | undefined;
  onDateFromChange: (date: Date | null) => void;
  onDateToChange: (date: Date | null) => void;
}> = ({ dateFrom, dateTo, onDateFromChange, onDateToChange }) => {
  return (
    <div className="flex items-center gap-2">
      <div className="flex items-center gap-2">
        <span className="text-sm font-medium text-ui-fg-base">From:</span>
        <DatePicker
          value={dateFrom ? new Date(dateFrom) : null}
          onChange={onDateFromChange}
          size="small"
          className="w-40"
          aria-label="Start Date"
        />
      </div>
      <div className="flex items-center gap-2">
        <span className="text-sm font-medium text-ui-fg-base">To:</span>
        <DatePicker
          value={dateTo ? new Date(dateTo) : null}
          onChange={onDateToChange}
          size="small"
          className="w-40"
          aria-label="End Date"
        />
      </div>
    </div>
  );
};

const columnHelper = createDataTableColumnHelper<ModelItem>();

const IdCell = React.memo(({ value }: { value: string }) => (
  <div className="font-mono text-sm text-ui-fg-base">{value}</div>
));

const ActionsCell = React.memo(
  ({
    row,
    onViewDetails,
    onEdit,
    onDelete,
  }: {
    row: any;
    onViewDetails: (item: ModelItem) => void;
    onEdit?: (item: ModelItem) => void;
    onDelete?: (item: ModelItem) => void;
  }) => {
    const handleViewDetails = () => {
      onViewDetails(row.original);
    };

    const handleEdit = () => {
      if (onEdit) {
        onEdit(row.original);
      }
    };

    return (
      <div className="flex justify-end">
        <DropdownMenu>
          <DropdownMenu.Trigger asChild>
            <IconButton>
              <EllipsisHorizontal />
            </IconButton>
          </DropdownMenu.Trigger>
          <DropdownMenu.Content align="end">
            <DropdownMenu.Item onClick={handleViewDetails}>
              <Eye className="mr-2 h-4 w-4" />
              View
            </DropdownMenu.Item>
            {onEdit && (
              <DropdownMenu.Item onClick={handleEdit}>
                <Pencil className="mr-2 h-4 w-4" />
                Edit
              </DropdownMenu.Item>
            )}
            {onDelete && (
              <Prompt variant="confirmation">
                <Prompt.Trigger asChild>
                  <DropdownMenu.Item
                    className="text-red-600 focus:text-red-600"
                    onSelect={(e) => e.preventDefault()}
                  >
                    <Trash className="mr-2 h-4 w-4" />
                    Delete
                  </DropdownMenu.Item>
                </Prompt.Trigger>
                <Prompt.Content>
                  <Prompt.Header>
                    <Prompt.Title>Delete Item</Prompt.Title>
                    <Prompt.Description>
                      This item will be permanently deleted. Are you sure you
                      want to continue?
                    </Prompt.Description>
                  </Prompt.Header>
                  <Prompt.Footer>
                    <Prompt.Cancel>Cancel</Prompt.Cancel>
                    <Prompt.Action onClick={() => onDelete(row.original)}>
                      Delete Item
                    </Prompt.Action>
                  </Prompt.Footer>
                </Prompt.Content>
              </Prompt>
            )}
          </DropdownMenu.Content>
        </DropdownMenu>
      </div>
    );
  }
);

// Create commands for bulk actions
const useCommands = (
  onBulkDelete?: (ids: number[]) => void,
  setShowBulkDeletePrompt?: (show: boolean) => void,
  setPendingBulkDelete?: (ids: number[]) => void
) => {
  return useMemo(() => {
    if (!onBulkDelete) return [];

    const commandHelper = createDataTableCommandHelper();

    return [
      commandHelper.command({
        label: "Delete",
        shortcut: "D",
        action: async (selection) => {
          const idsToDelete = Object.keys(selection).map((id) =>
            parseInt(id, 10)
          );

          if (idsToDelete.length === 0) return;

          // Set pending delete and show prompt
          setPendingBulkDelete?.(idsToDelete);
          setShowBulkDeletePrompt?.(true);
        },
      }),
    ];
  }, [onBulkDelete, setShowBulkDeletePrompt, setPendingBulkDelete]);
};

const useColumns = (
  modelFields: ModelField[],
  onViewDetails: (item: ModelItem) => void,
  onEdit?: (item: ModelItem) => void,
  onDelete?: (item: ModelItem) => void,
  hasBulkActions?: boolean
) => {
  return useMemo(() => {
    const columns = [];

    // Add select column for bulk actions
    if (hasBulkActions) {
      columns.push(columnHelper.select());
    }

    // ID column
    columns.push(
      columnHelper.accessor("id", {
        header: () => <QueueList className="mr-2" />,
        enableSorting: true,
        sortLabel: "ID",
        size: 20,
        cell: ({ getValue }) => <IdCell value={getValue()} />,
      })
    );

    // Dynamic columns based on model fields (excluding id)
    modelFields
      .filter((field) => field.name !== "id")
      .slice(0, 5) // Limit to first 5 fields for performance
      .forEach((field) => {
        columns.push(
          columnHelper.accessor(field.name, {
            header: () => (
              <span>
                {field.label ||
                  field.name
                    .replace(/_/g, " ")
                    .replace(/\b\w/g, (char) => char.toUpperCase())}
              </span>
            ),
            enableSorting: true,
            sortLabel: field.name,
            cell: ({ getValue }) => (
              <SecureFieldCell
                value={getValue()}
                fieldType={field.type}
                fieldName={field.name}
              />
            ),
          })
        );
      });

    // Actions column
    columns.push(
      columnHelper.display({
        id: "actions",
        header: "",
        size: 80,
        cell: ({ row }) => (
          <ActionsCell
            row={row}
            onViewDetails={onViewDetails}
            onEdit={onEdit}
            onDelete={onDelete}
          />
        ),
      }) as any
    );

    return columns;
  }, [modelFields, onViewDetails, onEdit, onDelete, hasBulkActions]);
};

// Static filter options
const getStaticFilters = (modelFields: ModelField[]) => {
  const filterHelper = createDataTableFilterHelper<ModelItem>();

  const fieldOptions = modelFields
    .filter((field) => field.name !== "id")
    .slice(0, 10) // Limit options
    .map((field) => ({
      label:
        field.label ||
        field.name
          .replace(/_/g, " ")
          .replace(/\b\w/g, (char) => char.toUpperCase()),
      value: field.name,
    }));

  const typeOptions = [
    { label: "String", value: "string" },
    { label: "Number", value: "number" },
    { label: "Boolean", value: "boolean" },
    { label: "Date", value: "date" },
    { label: "DateTime", value: "datetime" },
  ];

  return [
    filterHelper.accessor("field", {
      type: "select" as const,
      label: "Field",
      options: fieldOptions,
    }),
    filterHelper.accessor("field_type", {
      type: "select" as const,
      label: "Field Type",
      options: typeOptions,
    }),
  ];
};

// ModelsTable component
export const ModelsTable: React.FC<ModelsTableProps> = ({
  data,
  modelName,
  modelFields,
  isLoading = false,
  pagination,
  onPageChange,
  onPageSizeChange,
  onFiltersChange,
  filters,
  onNew,
  onInfo,
  onEdit,
  onDelete,
  onBulkDelete,
}) => {
  // Local state for UI interactions
  const [search, setSearch] = useState(filters.search || "");
  const [filtering, setFiltering] = useState<DataTableFilteringState>({});
  const [sorting, setSorting] = useState<DataTableSortingState | null>(null);
  const [rowSelection, setRowSelection] = useState<DataTableRowSelectionState>(
    {}
  );
  const [selectedItem, setSelectedItem] = useState<ModelItem | null>(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [showBulkDeletePrompt, setShowBulkDeletePrompt] = useState(false);
  const [pendingBulkDelete, setPendingBulkDelete] = useState<number[]>([]);

  // Handle view details
  const handleViewDetails = (item: ModelItem) => {
    setSelectedItem(item);
    setIsDrawerOpen(true);
  };

  // Handle drawer close
  const handleDrawerClose = () => {
    setIsDrawerOpen(false);
    setSelectedItem(null);
  };

  // Handle edit
  const handleEdit = (item: ModelItem) => {
    if (onEdit) {
      onEdit(item);
    }
  };

  // Get columns, static filters, and commands
  const hasBulkActions = !!onBulkDelete;
  const columns = useColumns(
    modelFields,
    handleViewDetails,
    handleEdit,
    onDelete,
    hasBulkActions
  );
  const staticFilters = getStaticFilters(modelFields);
  const commands = useCommands(
    onBulkDelete,
    setShowBulkDeletePrompt,
    setPendingBulkDelete
  );

  // Sync search with parent filters
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      onFiltersChange({ ...filters, search });
    }, 500); // Debounce search

    return () => clearTimeout(timeoutId);
  }, [search]);

  // Handle date range changes
  const handleDateFromChange = (date: Date | null) => {
    const isoString = date ? date.toISOString().split("T")[0] : undefined;
    onFiltersChange({ ...filters, date_from: isoString });
  };

  const handleDateToChange = (date: Date | null) => {
    const isoString = date ? date.toISOString().split("T")[0] : undefined;
    onFiltersChange({ ...filters, date_to: isoString });
  };

  // Sync filters with parent
  useEffect(() => {
    const newFilters: ModelFilters = { ...filters };

    // Convert DataTable filters to API filters
    Object.entries(filtering).forEach(([key, value]) => {
      if (value && typeof value === "string") {
        if (key === "field") {
          newFilters.field = value;
        } else if (key === "field_type") {
          newFilters.field_type = value;
        }
      }
    });

    // Handle sorting
    if (sorting) {
      newFilters.sort_by = sorting.id;
      newFilters.sort_direction = sorting.desc ? "desc" : "asc";
    }

    onFiltersChange(newFilters);
  }, [filtering, sorting]);

  // Handle pagination changes
  const handlePaginationChange = (newPagination: DataTablePaginationState) => {
    onPageChange(newPagination.pageIndex + 1); // Convert 0-based to 1-based
    onPageSizeChange(newPagination.pageSize);
  };

  // Clear all filters
  const clearFilters = () => {
    setSearch("");
    setFiltering({});
    setSorting(null);
    setRowSelection({});
    onPageChange(1);
    onFiltersChange({});
  };

  // Convert server pagination to DataTable format
  const paginationState: DataTablePaginationState = {
    pageSize: pagination.pageSize,
    pageIndex: pagination.currentPage - 1,
  };

  // Use DataTable hook
  const table = useDataTable({
    columns,
    data: data,
    getRowId: (row: ModelItem) => String(row.id),
    rowCount: pagination.totalItems,
    isLoading,
    search: {
      state: search,
      onSearchChange: setSearch,
    },
    pagination: {
      state: paginationState,
      onPaginationChange: handlePaginationChange,
    },
    filtering: {
      state: filtering,
      onFilteringChange: setFiltering,
    },
    sorting: {
      state: sorting,
      onSortingChange: setSorting,
    },
    ...(hasBulkActions && {
      commands,
      rowSelection: {
        state: rowSelection,
        onRowSelectionChange: setRowSelection,
      },
    }),
    filters: staticFilters,
  });

  return (
    <>
      <DataTable instance={table}>
        <DataTable.Toolbar className="flex flex-col px-0 items-start justify-between gap-2 md:flex-row md:items-center">
          <div className="flex flex-col gap-2 md:flex-row md:items-center">
            <DateRangeFilter
              dateFrom={filters.date_from}
              dateTo={filters.date_to}
              onDateFromChange={handleDateFromChange}
              onDateToChange={handleDateToChange}
            />
            <div className="flex gap-2">
              <DataTable.Search placeholder="Search..." />
              <DataTable.FilterMenu tooltip="Filter by" />
              <DataTable.SortingMenu tooltip="Sort by" />
              {search ||
              Object.keys(filtering).length > 0 ||
              sorting ||
              Object.keys(filters).some(
                (key) => key !== "search" && filters[key as keyof ModelFilters]
              ) ? (
                <Button variant="danger" size="small" onClick={clearFilters}>
                  <XMarkMini />
                </Button>
              ) : null}
            </div>
          </div>
          <div className="flex gap-2">
            <IconButton variant="primary" onClick={onNew} title="New Item">
              <Plus />
            </IconButton>
            <IconButton
              variant="transparent"
              onClick={onInfo}
              title="Item Info"
            >
              <InformationCircle />
            </IconButton>
          </div>
        </DataTable.Toolbar>

        <DataTable.Table
          emptyState={{
            empty: {
              custom: isLoading ? (
                <Loader className="animate-spin" />
              ) : (
                <EmptyData title={`No ${modelName.toLowerCase()} found.`} />
              ),
            },
          }}
        />

        {hasBulkActions && (
          <DataTable.CommandBar
            selectedLabel={(count) =>
              `${count} item${count > 1 ? "s" : ""} selected`
            }
          />
        )}

        <DataTable.Pagination />
      </DataTable>

      {/* Model Detail Drawer */}
      <ModelDetailDrawer
        item={selectedItem}
        modelName={modelName}
        modelFields={modelFields}
        isOpen={isDrawerOpen}
        onClose={handleDrawerClose}
        onEdit={onEdit}
        onDelete={onDelete}
      />

      {/* Bulk Delete Confirmation Prompt */}
      {showBulkDeletePrompt && (
        <Prompt variant="danger" open>
          <Prompt.Content>
            <Prompt.Header>
              <Prompt.Title>Delete Multiple Items</Prompt.Title>
              <Prompt.Description>
                You're about to delete {pendingBulkDelete.length} item
                {pendingBulkDelete.length > 1 ? "s" : ""}. This action cannot be
                undone.
              </Prompt.Description>
            </Prompt.Header>
            <Prompt.Footer>
              <Prompt.Cancel onClick={() => setShowBulkDeletePrompt(false)}>
                Cancel
              </Prompt.Cancel>
              <Prompt.Action
                onClick={() => {
                  onBulkDelete?.(pendingBulkDelete);
                  setShowBulkDeletePrompt(false);
                  setPendingBulkDelete([]);
                  setRowSelection({});
                }}
              >
                Delete {pendingBulkDelete.length} Item
                {pendingBulkDelete.length > 1 ? "s" : ""}
              </Prompt.Action>
            </Prompt.Footer>
          </Prompt.Content>
        </Prompt>
      )}
    </>
  );
};

export default ModelsTable;
