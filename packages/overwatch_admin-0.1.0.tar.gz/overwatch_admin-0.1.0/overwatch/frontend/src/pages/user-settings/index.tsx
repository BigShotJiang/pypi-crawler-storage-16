import React, { useState } from "react";
import { Tabs } from "@medusajs/ui";
import { SingleColumnLayout } from "@/components/layouts/single-column";
import ProfileSettings from "./profile-settings";
import SecuritySettings from "./security-settings";
import { Key, User } from "@medusajs/icons";

const UserSettingsPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<"profile" | "security">("profile");

  return (
    <SingleColumnLayout>
      <Tabs
        value={activeTab}
        onValueChange={(value) => setActiveTab(value as "profile" | "security")}
      >
        <Tabs.List>
          <Tabs.Trigger
            value="profile"
            className="flex items-center space-x-2 hover:bg-ui-bg-subtle"
          >
            <User />
            <span>Profile</span>
          </Tabs.Trigger>
          <Tabs.Trigger
            value="security"
            className="flex items-center space-x-2 hover:bg-ui-bg-subtle"
          >
            <Key />
            <span>Security</span>
          </Tabs.Trigger>
        </Tabs.List>

        <Tabs.Content value="profile" className="mt-6">
          <ProfileSettings />
        </Tabs.Content>

        <Tabs.Content value="security" className="mt-6">
          <SecuritySettings />
        </Tabs.Content>
      </Tabs>
    </SingleColumnLayout>
  );
};

export default UserSettingsPage;
