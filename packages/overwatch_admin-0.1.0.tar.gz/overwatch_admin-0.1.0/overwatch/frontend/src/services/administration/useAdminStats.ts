import { adminApi } from "@/api";
import { useQuery } from "@tanstack/react-query";

export function useAdminStats(enabled: boolean) {
  return useQuery({
    queryKey: ["admin-stats"],
    queryFn: () => adminApi.getStats(),
    enabled,
  });
}
