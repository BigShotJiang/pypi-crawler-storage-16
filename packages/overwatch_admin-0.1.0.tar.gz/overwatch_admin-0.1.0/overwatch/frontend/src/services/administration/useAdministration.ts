import { adminApi } from "@/api";
import { AdminSearchRequest } from "@/types";
import { useQuery } from "@tanstack/react-query";

export function useAdministration(
  enabled: boolean,
  params?: AdminSearchRequest
) {
  return useQuery({
    queryKey: ["administrations", params],
    queryFn: () => adminApi.getAdministrations(params),
    enabled,
  });
}
