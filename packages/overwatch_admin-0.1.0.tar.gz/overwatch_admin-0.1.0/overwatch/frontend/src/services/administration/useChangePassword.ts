import { useMutation, useQueryClient } from "@tanstack/react-query";
import { adminApi } from "@/api";
import { toast } from "@medusajs/ui";

export function useChangeAdminPassword(id: number, onSuccess?: () => void) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: { new_password: string }) =>
      adminApi.changePassword(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["administrations"] });
      queryClient.invalidateQueries({ queryKey: ["administration", id] });

      toast.success("Success", {
        description: "Password for this admin has been changed successfully!",
        position: "top-center",
        duration: 2000,
      });

      onSuccess?.();
    },
    onError: (error: any) => {
      const errorMessage =
        error.response?.data?.detail ||
        error.response?.data?.message ||
        error.message ||
        "Failed to change password. Please try again.";

      toast.error("Error", {
        description: errorMessage,
        position: "top-center",
      });
    },
  });
}
