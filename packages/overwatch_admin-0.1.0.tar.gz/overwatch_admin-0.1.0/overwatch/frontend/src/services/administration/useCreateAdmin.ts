import { useMutation, useQueryClient } from "@tanstack/react-query";
import { adminApi } from "@/api";
import { toast } from "@medusajs/ui";

export function useCreateAdmin(onSuccess?: () => void) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: adminApi.createAdmin,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["administrations"] });

      toast.success("Success", {
        description: "Item created successfully!",
      });

      onSuccess?.();
    },
    onError: (error: any) => {
      const errorMessage =
        error.response?.data?.detail ||
        error.response?.data?.message ||
        error.message ||
        "Unknown error. Please try again.";

      toast.error("Error", {
        description: errorMessage,
      });
    },
  });
}
