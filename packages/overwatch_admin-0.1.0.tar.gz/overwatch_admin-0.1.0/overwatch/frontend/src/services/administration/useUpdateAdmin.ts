import { useMutation, useQueryClient } from "@tanstack/react-query";
import { adminApi } from "@/api";
import { Administration } from "@/types";
import { toast } from "@medusajs/ui";

export function useUpdateAdmin(id: number, onSuccess?: () => void) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: Partial<Administration>) =>
      adminApi.updateAdmin(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["administrations"] });
      queryClient.invalidateQueries({ queryKey: ["administration", id] });

      toast.success("Success", {
        description: "Item updated successfully!",
      });

      onSuccess?.();
    },
    onError: (error: any) => {
      const errorMessage =
        error.response?.data?.detail ||
        error.response?.data?.message ||
        error.message ||
        "Unknown error. Please try again.";

      toast.error("Error", {
        description: errorMessage,
      });
    },
  });
}
