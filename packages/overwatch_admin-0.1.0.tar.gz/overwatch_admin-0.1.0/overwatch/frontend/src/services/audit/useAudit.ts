import { auditApi } from "@/api";
import { AuditFilters, ListParams } from "@/types";
import { useQuery } from "@tanstack/react-query";

export function useAudit(enabled: boolean, params?: ListParams) {
  const filter: AuditFilters = {
    search: params?.search,
    sort_by: params?.sort_by,
    sort_direction: params?.sort_direction,
  };

  return useQuery({
    queryKey: ["audit-logs", params],
    queryFn: () =>
      auditApi.getAuditLogs(params?.page, params?.per_page, filter),
    enabled,
  });
}
