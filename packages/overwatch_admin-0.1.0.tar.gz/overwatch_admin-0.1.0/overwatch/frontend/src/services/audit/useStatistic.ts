import { auditApi } from "@/api";
import { useQuery } from "@tanstack/react-query";

export function useStatistic(enabled: boolean) {
  return useQuery({
    queryKey: ["audit-statistics"],
    queryFn: () => auditApi.getAuditStatistics(),
    enabled,
  });
}
