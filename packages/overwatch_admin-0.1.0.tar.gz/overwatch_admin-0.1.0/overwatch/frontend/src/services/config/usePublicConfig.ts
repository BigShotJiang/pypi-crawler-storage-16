import { useQuery } from "@tanstack/react-query";
import { configApi, PublicConfig } from "@/api/config";

export const usePublicConfig = () => {
  return useQuery<PublicConfig>({
    queryKey: ["public-config"],
    queryFn: configApi.getPublicConfig,
    staleTime: 5 * 60 * 1000, // 5 minutes
    refetchOnWindowFocus: false,
  });
};
