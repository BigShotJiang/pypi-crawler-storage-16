import { dashboardApi } from "@/api";
import { useQuery } from "@tanstack/react-query";

export function useAvailableModels(enabled: boolean) {
  return useQuery({
    queryKey: ["available-models"],
    queryFn: () => dashboardApi.getAvailableModels(),
    enabled,
    staleTime: Infinity,
    gcTime: Infinity,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
  });
}
