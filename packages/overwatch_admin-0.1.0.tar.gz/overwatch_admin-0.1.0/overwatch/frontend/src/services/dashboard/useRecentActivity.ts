import { dashboardApi } from "@/api";
import { useQuery } from "@tanstack/react-query";

export function useRecentActivity(enabled: boolean) {
  return useQuery({
    queryKey: ["recent-activity"],
    queryFn: () => dashboardApi.getRecentActivity(),
    enabled,
  });
}
