import { dashboardApi } from "@/api";
import { useQuery } from "@tanstack/react-query";

export function useStats(enabled: boolean) {
  return useQuery({
    queryKey: ["dashboard-stats"],
    queryFn: () => dashboardApi.getStats(),
    enabled,
  });
}
