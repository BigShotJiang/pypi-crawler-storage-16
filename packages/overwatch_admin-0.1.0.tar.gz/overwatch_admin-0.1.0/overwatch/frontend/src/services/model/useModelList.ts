import { modelApi } from "@/api";
import { ListParams } from "@/types";
import { useQuery } from "@tanstack/react-query";

export function useModelList(
  enabled: boolean,
  name: string,
  params?: ListParams
) {
  return useQuery({
    queryKey: ["model-list", name, params],
    queryFn: () => modelApi.getModelList(name, params),
    enabled,
  });
}
