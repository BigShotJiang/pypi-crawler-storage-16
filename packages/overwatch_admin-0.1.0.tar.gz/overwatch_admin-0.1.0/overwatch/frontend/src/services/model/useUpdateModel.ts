import { modelApi } from "@/api";
import { toast } from "@medusajs/ui";
import { useMutation, useQueryClient } from "@tanstack/react-query";

export function useUpdateModel(
  name: string,
  id: string,
  successCallback: () => void
) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: Record<string, any>) =>
      modelApi.updateModelItem(name, id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["model-list", name] });
      successCallback();

      toast.success("Success", {
        description: "Item updated successfully!",
      });
    },
    onError: (error: any) => {
      toast.error("Error", {
        description: `${error.message || "Unknown error"}`,
      });
    },
  });
}
