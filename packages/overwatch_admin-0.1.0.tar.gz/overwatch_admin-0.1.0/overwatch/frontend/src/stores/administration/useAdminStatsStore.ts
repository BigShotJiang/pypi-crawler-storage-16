import { useAdminStats } from "@/services";
import { AdminStats } from "@/types";
import { useEffect } from "react";
import { create } from "zustand";

interface AdminStatsState {
  adminStats?: AdminStats;
  setAdminStats: (stats: AdminStats) => void;
}

export const useAdminStatsStore = create<AdminStatsState>((set) => ({
  adminStats: undefined,
  setAdminStats: (stats) => {
    set({
      adminStats: stats,
    });
  },
}));

export function useHydratedAdminStats() {
  const adminStats = useAdminStatsStore((s) => s.adminStats);
  const setAdminStats = useAdminStatsStore((s) => s.setAdminStats);

  const enabled = !adminStats;
  const { data, isLoading, error } = useAdminStats(enabled);

  useEffect(() => {
    if (data) {
      setAdminStats(data);
    }
  }, [data, setAdminStats]);

  return { isLoading, error };
}
