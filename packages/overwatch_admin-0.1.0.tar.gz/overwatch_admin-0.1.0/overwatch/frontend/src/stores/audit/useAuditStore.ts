import { useAudit } from "@/services";
import { ListParams, PaginatedAuditLogs } from "@/types";
import { useEffect } from "react";
import { create } from "zustand";

interface AuditState {
  audit: PaginatedAuditLogs | null;
  setAudit: (audit: PaginatedAuditLogs) => void;
}

export const useAuditStore = create<AuditState>((set) => ({
  audit: null,
  setAudit: (audit) => {
    set({
      audit,
    });
  },
}));

export function useHydratedAudit(params?: ListParams) {
  const setAudit = useAuditStore((s) => s.setAudit);

  const { data, isLoading, error } = useAudit(true, params);

  useEffect(() => {
    if (data) {
      setAudit(data);
    }
  }, [data, setAudit]);

  return { isLoading, error };
}
