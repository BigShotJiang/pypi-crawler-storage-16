import { useStatistic } from "@/services";
import { AuditStatistics } from "@/types";
import { useEffect } from "react";
import { create } from "zustand";

interface StatisticState {
  statistic: AuditStatistics | null;
  setStatistic: (statistic: AuditStatistics) => void;
}

export const useStatisticStore = create<StatisticState>((set) => ({
  statistic: null,
  setStatistic: (statistic) => {
    set({
      statistic,
    });
  },
}));

export function useHydratedStatistic() {
  const statistic = useStatisticStore((d) => d.statistic);
  const setStatistic = useStatisticStore((s) => s.setStatistic);

  const enabled = !statistic;
  const { data, isLoading, error } = useStatistic(enabled);

  useEffect(() => {
    if (data) {
      setStatistic(data);
    }
  }, [data, setStatistic]);

  return { isLoading, error };
}
