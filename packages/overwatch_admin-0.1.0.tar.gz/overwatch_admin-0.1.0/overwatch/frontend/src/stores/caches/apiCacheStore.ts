import { create } from "zustand";
import { devtools } from "zustand/middleware";

// Cache entry with TTL
interface CacheEntry<T> {
  data: T;
  timestamp: number;
  ttl: number;
}

// Request tracking for deduplication
interface RequestTracker<T = any> {
  promise: Promise<T>;
  timestamp: number;
}

interface ApiCacheState {
  cache: Map<string, CacheEntry<any>>;
  pendingRequests: Map<string, RequestTracker<any>>;
  get: (key: string) => any;
  set: (key: string, data: any, ttl?: number) => void;
  invalidate: (key: string) => void;
  invalidatePattern: (pattern: string) => void;
  clear: () => void;
  trackRequest: (
    key: string,
    promise: Promise<any>
  ) => Promise<any> | undefined;
  removeRequest: (key: string) => void;
  cleanup: () => void;
}

const DEFAULT_TTL = 5 * 60 * 1000;

export const useApiCacheStore = create<ApiCacheState>()(
  devtools(
    (set, get) => ({
      cache: new Map(),
      pendingRequests: new Map(),

      get: (key: string) => {
        const entry = get().cache.get(key);
        if (!entry) return null;

        const now = Date.now();
        if (now - entry.timestamp > entry.ttl) {
          get().invalidate(key);
          return null;
        }

        return entry.data;
      },

      set: (key: string, data: any, ttl: number = DEFAULT_TTL) => {
        const newCache = new Map(get().cache);
        newCache.set(key, {
          data,
          timestamp: Date.now(),
          ttl,
        });
        set({ cache: newCache });
      },

      invalidate: (key: string) => {
        const newCache = new Map(get().cache);
        newCache.delete(key);
        set({ cache: newCache });
      },

      invalidatePattern: (pattern: string) => {
        const newCache = new Map(get().cache);
        const regex = new RegExp(pattern);
        for (const [key] of newCache) {
          if (regex.test(key)) {
            newCache.delete(key);
          }
        }
        set({ cache: newCache });
      },

      clear: () => {
        set({ cache: new Map(), pendingRequests: new Map() });
      },

      trackRequest: (key: string, promise: Promise<any>) => {
        const existing = get().pendingRequests.get(key);
        if (existing && Date.now() - existing.timestamp < 30000) {
          return existing.promise;
        }

        const newPending = new Map(get().pendingRequests);
        newPending.set(key, {
          promise,
          timestamp: Date.now(),
        });
        set({ pendingRequests: newPending });
        return undefined;
      },

      removeRequest: (key: string) => {
        const newPending = new Map(get().pendingRequests);
        newPending.delete(key);
        set({ pendingRequests: newPending });
      },

      cleanup: () => {
        const now = Date.now();
        const newCache = new Map(get().cache);
        const newPending = new Map(get().pendingRequests);

        for (const [key, entry] of newCache) {
          if (now - entry.timestamp > entry.ttl) {
            newCache.delete(key);
          }
        }

        for (const [key, tracker] of newPending) {
          if (now - tracker.timestamp > 30000) {
            newPending.delete(key);
          }
        }

        set({ cache: newCache, pendingRequests: newPending });
      },
    }),
    {
      name: "api-cache-store",
    }
  )
);

export const useCacheActions = () => {
  const store = useApiCacheStore.getState();
  return {
    get: (key: string) => store.get(key),
    set: (key: string, data: any, ttl?: number) =>
      store.set(key, data, ttl || DEFAULT_TTL),
    invalidate: (key: string) => store.invalidate(key),
    invalidatePattern: (pattern: string) => store.invalidatePattern(pattern),
    clear: () => store.clear(),
    trackRequest: (key: string, promise: Promise<any>) =>
      store.trackRequest(key, promise),
    removeRequest: (key: string) => store.removeRequest(key),
    cleanup: () => store.cleanup(),
  };
};

if (typeof window !== "undefined") {
  setInterval(() => {
    const cacheStore = useApiCacheStore.getState();
    if (cacheStore && typeof cacheStore.cleanup === "function") {
      cacheStore.cleanup();
    }
  }, 5 * 60 * 1000);
}

export const createCacheKey = (endpoint: string, params?: any): string => {
  const paramsStr = params ? JSON.stringify(params) : "";
  return `${endpoint}:${paramsStr}`;
};

export const createPatternKey = (prefix: string): string => {
  return `^${prefix}:`;
};
