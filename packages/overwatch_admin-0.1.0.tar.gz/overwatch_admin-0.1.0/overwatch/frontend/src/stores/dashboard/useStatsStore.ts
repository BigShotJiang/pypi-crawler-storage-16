import { useStats } from "@/services";
import { DashboardStats } from "@/types";
import { useEffect } from "react";
import { create } from "zustand";

interface StatsState {
  stats?: DashboardStats;
  setStats: (stats: DashboardStats) => void;
}

export const useStatsStore = create<StatsState>((set) => ({
  stats: undefined,
  setStats: (stats) => {
    set({
      stats: stats,
    });
  },
}));

export function useHydratedStats() {
  const stats = useStatsStore((s) => s.stats);
  const setStats = useStatsStore((s) => s.setStats);

  const enabled = !stats;
  const { data, isLoading, error } = useStats(enabled);

  useEffect(() => {
    if (data) {
      setStats(data);
    }
  }, [data, setStats]);

  return { isLoading, error };
}
