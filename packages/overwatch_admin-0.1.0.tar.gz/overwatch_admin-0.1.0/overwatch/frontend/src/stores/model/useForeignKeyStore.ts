import { create } from "zustand";
import { ModelItem } from "@/types";

interface ForeignKeyState {
  foreignKeyData: Record<string, ModelItem>;
  setForeignKeyData: (data: Record<string, ModelItem>) => void;
}

export const useForeignKeyStore = create<ForeignKeyState>((set) => ({
  foreignKeyData: {},
  setForeignKeyData: (data) => {
    set({
      foreignKeyData: data,
    });
  },
}));

export function useHydratedForeignKey(
  model: string,
  id: string | number
): ModelItem | null {
  const foreignKeyData = useForeignKeyStore((s) => s.foreignKeyData);
  return foreignKeyData[`${model}_${id}`] || null;
}

export function useHydratedForeignKeyList(
  model: string,
  params: Record<string, any> = {}
): { items: ModelItem[]; isLoading: boolean; error: string | null } {
  const foreignKeyData = useForeignKeyStore((s) => s.foreignKeyData);

  // Filter foreign key data for this model and params
  const items = Object.values(foreignKeyData).filter(
    (item) =>
      item?._model === model &&
      Object.keys(params).every((key) => item[key] === params[key])
  );

  return {
    items,
    isLoading: false,
    error: null,
  };
}
