import { useModelList } from "@/services";
import { ListParams, ModelListResponse } from "@/types";
import { useEffect } from "react";
import { create } from "zustand";

interface ModelListState {
  modelList?: ModelListResponse;
  setModelList: (modelList: ModelListResponse) => void;
}

export const useModelListStore = create<ModelListState>((set) => ({
  modelList: undefined,
  setModelList: (modelList) => {
    set({
      modelList,
    });
  },
}));

export function useHydratedModelList(name: string, params?: ListParams) {
  const setModelList = useModelListStore((s) => s.setModelList);

  const { data, isLoading, error, refetch } = useModelList(true, name, params);

  useEffect(() => {
    if (data) {
      setModelList(data);
    }
  }, [data, setModelList]);

  return { isLoading, error, refetch };
}
