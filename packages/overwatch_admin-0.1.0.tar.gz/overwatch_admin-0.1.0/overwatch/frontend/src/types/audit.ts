export interface AuditLog {
  id: number;
  admin_id: number;
  admin_username: string;
  action: string;
  action_display: string;
  resource_type: string;
  resource_id: number;
  resource_display: string;
  ip_address: string;
  user_agent: string;
  success: boolean;
  error_message?: string;
  old_values?: any;
  new_values?: any;
  changes_summary?: any;
  created_at: string;
  updated_at: string;
}

export interface PaginatedAuditLogs {
  items: AuditLog[];
  total: number;
  page: number;
  per_page: number;
  pages: number;
}

export interface AuditFilters {
  search?: string;
  action?: string;
  resource_type?: string;
  admin_id?: number;
  success?: boolean;
  date_from?: string;
  date_to?: string;
  sort_by?: string;
  sort_direction?: "asc" | "desc";
}

export interface AuditAction {
  action: string;
  count: number;
}

export interface AuditResource {
  resource_type: string;
  count: number;
}

export interface AuditStatistics {
  total_logs: number;
  successful_actions: number;
  failed_actions: number;
  success_rate: number;
  top_actions: AuditAction[];
  top_resources: AuditResource[];
  daily_trends: Array<{
    date: string;
    count: number;
  }>;
  period_days: number;
}
