export interface DashboardStats {
  totalUsers: number;
  totalModels: number;
  totalAuditLogs: number;
  recentActivity: number;
  userGrowth: number;
  modelGrowth: number;
  system_stats: {
    total_admins: number;
    active_admins: number;
    recent_logins: number;
    total_actions: number;
  };
  total_models: number;
  total_records: number;
}

export interface RecentActivity {
  id: string;
  admin_id: string;
  admin_username: string;
  action: string;
  action_display?: string;
  resource_type: string;
  resource_id?: string;
  resource_display?: string;
  ip_address?: string;
  user_agent?: string;
  success: boolean;
  error_message?: string;
  changes_summary?: string;
  created_at: string;
}
