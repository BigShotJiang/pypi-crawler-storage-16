"""
Setup configuration for Overwatch admin panel package.
"""

from pathlib import Path

from setuptools import find_packages, setup

# Read the contents of README file
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")


# Read the contents of pyproject.toml for version
def get_version():
    """Get version from pyproject.toml."""
    pyproject_path = this_directory / "pyproject.toml"
    if pyproject_path.exists():
        import tomllib

        with open(pyproject_path, "rb") as f:
            data = tomllib.load(f)
            return data.get("project", {}).get("version", "0.1.0")
    return "0.1.0"


setup(
    name="overwatch-admin",
    version=get_version(),
    author="Overwatch Contributors",
    author_email="contributors@overwatch.dev",
    description="Agnostic admin panel for FastAPI applications",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/overwatch-dev/overwatch",
    project_urls={
        "Bug Tracker": "https://github.com/overwatch-dev/overwatch/issues",
        "Documentation": "https://overwatch.readthedocs.io/",
        "Source Code": "https://github.com/overwatch-dev/overwatch",
    },
    packages=find_packages(exclude=["tests*", "examples*"]),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Framework :: FastAPI",
        "Topic :: Internet :: WWW/HTTP :: HTTP Servers",
        "Topic :: Software Development :: Libraries :: Application Frameworks",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.11",
    install_requires=[
        "fastapi>=0.104.0",
        "sqlalchemy>=2.0.0",
        "pydantic>=2.5.0",
        "pydantic-settings>=2.1.0",
        "python-jose[cryptography]>=3.3.0",
        "passlib[bcrypt]>=1.7.4",
        "python-multipart>=0.0.6",
        "aiofiles>=23.0.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.4.0",
            "pytest-asyncio>=0.21.0",
            "pytest-cov>=4.1.0",
            "ruff>=0.1.0",
            "pyright>=1.1.0",
            "mypy>=1.7.0",
            "black>=23.0.0",
            "isort>=5.12.0",
        ],
        "postgres": ["asyncpg>=0.29.0"],
        "mysql": ["aiomysql>=0.2.0"],
        "sqlite": ["aiosqlite>=0.19.0"],
        "frontend": [
            "jinja2>=3.1.0",
            "websockets>=12.0",
        ],
    },
    include_package_data=True,
    package_data={
        "overwatch": [
            "frontend/dist/**/*",
            "static/**/*",
            "templates/**/*",
        ],
    },
    entry_points={
        "console_scripts": [
            "overwatch=overwatch.cli:main",
        ],
    },
    keywords=[
        "fastapi",
        "admin",
        "crud",
        "sqlalchemy",
        "dashboard",
        "management",
        "panel",
        "interface",
    ],
)
