import { Routes, Route, Navigate, useLocation } from "react-router-dom";
import AdminLayout from "@/components/organisms/AdminLayout";
import LoginPage from "@/pages/login";
import DashboardPage from "@/pages/dashboard";
import AuditLogsPage from "@/pages/audit-logs";
import AdministrationPage from "@/pages/administration";
import ModelsPage from "./pages/models";
import { Toaster } from "@medusajs/ui";
import { useAuthStore } from "./stores";

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const location = useLocation();

  if (!isAuthenticated) {
    return (
      <Navigate
        to="/login"
        state={{ from: location.pathname + location.search }}
        replace
      />
    );
  }

  return <>{children}</>;
}

function PublicRoute({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);

  if (isAuthenticated) {
    const from = location.state?.from || "/dashboard";
    return <Navigate to={from} replace />;
  }

  return (
    <>
      {children}
      <Toaster />
    </>
  );
}

function AppRoutes() {
  return (
    <AdminLayout>
      <Routes>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/models/:modelName" element={<ModelsPage />} />
        <Route path="/audit-logs" element={<AuditLogsPage />} />
        <Route path="/administrations" element={<AdministrationPage />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </AdminLayout>
  );
}

function App() {
  return (
    <Routes>
      <Route
        path="/login"
        element={
          <PublicRoute>
            <LoginPage />
          </PublicRoute>
        }
      />
      <Route
        path="/*"
        element={
          <ProtectedRoute>
            <AppRoutes />
          </ProtectedRoute>
        }
      />
    </Routes>
  );
}

export default App;
