import {
  BulkOperationResponse,
  ModelConfig,
  ModelItem,
  ListParams,
  ModelListResponse,
} from "@/types";
import { client } from "./client";

export const modelApi = {
  async getModelFields(modelName: string): Promise<ModelConfig> {
    const response = await client.get(`/${modelName}/fields`);

    return response.data;
  },

  async getModelList(
    modelName: string,
    params: ListParams = {}
  ): Promise<ModelListResponse> {
    const response = await client.get(`/${modelName}`, { params });

    return response.data;
  },

  async getModelItem(modelName: string, id: string): Promise<ModelItem> {
    const response = await client.get(`/${modelName}/${id}`);

    return response.data;
  },

  async createModelItem(
    modelName: string,
    data: Record<string, any>
  ): Promise<ModelItem> {
    const response = await client.post(`/${modelName}`, data);

    return response.data;
  },

  async updateModelItem(
    modelName: string,
    id: string,
    data: Record<string, any>
  ): Promise<ModelItem> {
    const response = await client.put(`/${modelName}/${id}`, data);

    return response.data;
  },

  async deleteModelItem(modelName: string, id: string): Promise<void> {
    await client.delete(`/${modelName}/${id}`);
  },

  async bulkDelete(
    modelName: string,
    ids: number[]
  ): Promise<BulkOperationResponse> {
    const response = await client.delete(`/${modelName}/bulk`, {
      data: { item_ids: ids },
    });

    return response.data;
  },

  async bulkUpdate(
    modelName: string,
    ids: string[],
    updates: Record<string, any>
  ): Promise<BulkOperationResponse> {
    const response = await client.put(`/${modelName}/bulk`, {
      item_ids: ids,
      updates,
    });

    return response.data;
  },

  async bulkCreate(
    modelName: string,
    items: Record<string, any>[]
  ): Promise<BulkOperationResponse> {
    const response = await client.post(`/${modelName}/bulk`, { items });

    return response.data;
  },

  async exportModelData(
    modelName: string,
    format: "csv" | "json" | "excel" = "csv",
    params: ListParams = {}
  ): Promise<Blob> {
    const response = await client.get(`/${modelName}/export`, {
      params: { format, ...params },
      responseType: "blob",
    });

    return response.data;
  },
};
