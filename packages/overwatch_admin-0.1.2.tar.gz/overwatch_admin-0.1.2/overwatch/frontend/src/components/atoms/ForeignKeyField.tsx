import React, { useState, useEffect, useCallback, useMemo } from "react";
import {
  Input,
  Drawer,
  DataTable,
  createDataTableColumnHelper,
  useDataTable,
  IconButton,
  DataTablePaginationState,
  Label,
} from "@medusajs/ui";
import { ModelField, ModelItem, ModelListResponse } from "@/types";
import { modelApi } from "@/api/model";
import { useHydratedForeignKey } from "@/stores";
import { ArrowUpRightOnBox, QueueList, XMarkMini } from "@medusajs/icons";

interface ForeignKeyFieldProps {
  field: ModelField;
  value: any;
  onChange: (name: string, value: any) => void;
  disabled?: boolean;
  error?: string;
  onBlur?: () => void;
}

const columnHelper = createDataTableColumnHelper<ModelItem>();

const getDisplayField = (item: ModelItem): { field: string; value: any } => {
  const displayField = Object.keys(item).find((key) =>
    ["name", "title", "label", "username", "email"].includes(key.toLowerCase())
  );
  return {
    field: displayField || "id",
    value: displayField ? item[displayField] : item.id,
  };
};

// Memoized display cell component
const DisplayCell: React.FC<{ item: ModelItem }> = React.memo(({ item }) => {
  const { field, value } = getDisplayField(item);
  return (
    <div className="text-sm">
      {value}
      {field !== "id" && (
        <div className="text-xs text-ui-fg-muted">
          {field}: {value}
        </div>
      )}
    </div>
  );
});

DisplayCell.displayName = "DisplayCell";

// Simple table component for foreign key selection
const ForeignKeySelectionTable: React.FC<{
  targetModel: string;
  onSelect: (item: ModelItem) => void;
  onClose: () => void;
  isOpen: boolean;
}> = ({ targetModel, onSelect, onClose, isOpen }) => {
  const [data, setData] = useState<ModelItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [pagination, setPagination] = useState<DataTablePaginationState>({
    pageSize: 20,
    pageIndex: 0,
  });
  const [totalCount, setTotalCount] = useState(0);

  // Memoize load data function
  const loadData = useCallback(async () => {
    if (!targetModel) return;

    setIsLoading(true);
    try {
      // Use modelApi for consistency with rest of app
      const response: ModelListResponse = await modelApi.getModelList(
        targetModel,
        {
          page: pagination.pageIndex + 1, // Convert 0-based to 1-based
          per_page: pagination.pageSize,
          search: search || undefined,
        }
      );
      setData(response?.items || []);
      setTotalCount(response?.total || 0);
    } catch (error) {
      console.error("Failed to load foreign key data:", error);
      setData([]);
      setTotalCount(0);
    } finally {
      setIsLoading(false);
    }
  }, [targetModel, search, pagination.pageIndex, pagination.pageSize]);

  useEffect(() => {
    if (isOpen && targetModel) {
      loadData();
    }
  }, [isOpen, targetModel, loadData]);

  // Memoize columns
  const columns = useMemo(
    () => [
      columnHelper.accessor("id", {
        header: () => <QueueList className="mr-2" />,
        size: 20,
        cell: ({ getValue }) => (
          <div className="font-mono text-sm">{getValue()}</div>
        ),
      }),
      columnHelper.display({
        id: "display",
        header: "Name",
        cell: ({ row }) => <DisplayCell item={row.original} />,
      }),
    ],
    []
  );

  const handleClearSearch = useCallback(() => {
    setSearch("");
    setPagination((prev) => ({ ...prev, pageIndex: 0 }));
  }, []);

  const handlePaginationChange = useCallback(
    (newPagination: DataTablePaginationState) => {
      setPagination(newPagination);
    },
    []
  );

  const table = useDataTable({
    columns,
    data,
    getRowId: useCallback((row: ModelItem) => String(row.id), []),
    isLoading,
    rowCount: totalCount,
    search: {
      state: search,
      onSearchChange: setSearch,
    },
    pagination: {
      state: pagination,
      onPaginationChange: handlePaginationChange,
    },
    onRowClick: async (event, row) => {
      event.preventDefault();
      onSelect(row);
    },
  });

  return (
    <Drawer open={isOpen} onOpenChange={onClose}>
      <Drawer.Content className="w-full md:max-w-4xl">
        <Drawer.Header>
          <Drawer.Title>Select {targetModel}</Drawer.Title>
          <Drawer.Description>
            Choose a {targetModel.toLowerCase()} to associate with this record.
          </Drawer.Description>
        </Drawer.Header>
        <Drawer.Body className="overflow-auto">
          <DataTable instance={table}>
            <DataTable.Toolbar className="gap-2">
              <DataTable.Search placeholder="Search..." />
              {search && (
                <IconButton
                  variant="transparent"
                  onClick={handleClearSearch}
                  title="Clear search"
                  aria-label="Clear search"
                >
                  <XMarkMini />
                </IconButton>
              )}
            </DataTable.Toolbar>
            <DataTable.Table
              emptyState={{
                empty: {
                  custom: isLoading ? (
                    <div>Loading...</div>
                  ) : (
                    <div>No {targetModel.toLowerCase()} found.</div>
                  ),
                },
              }}
            />
            <DataTable.Pagination />
          </DataTable>
        </Drawer.Body>
      </Drawer.Content>
    </Drawer>
  );
};

export const ForeignKeyField: React.FC<ForeignKeyFieldProps> = React.memo(
  ({ field, value, onChange, disabled = false, error, onBlur }) => {
    const [isSelectionOpen, setIsSelectionOpen] = useState(false);

    // Memoize computed values
    const targetModel = useMemo(
      () => field.model_name ?? "",
      [field.model_name]
    );

    const label = useMemo(
      () =>
        field.label ||
        field.name
          .replace(/_/g, " ")
          .replace(/\b\w/g, (char) => char.toUpperCase()),
      [field.label, field.name]
    );

    // Use store for hydrated foreign key data
    const relatedItem = useHydratedForeignKey(targetModel, value);

    // Memoize display text calculation
    const getDisplayText = useCallback((): string => {
      if (relatedItem) {
        // Use the helper function for consistency
        const { field: displayField, value: displayValue } =
          getDisplayField(relatedItem);
        return displayField !== "id" ? displayValue : `ID: ${relatedItem.id}`;
      }
      return value ? `ID: ${value}` : "";
    }, [relatedItem, value]);

    // Memoize event handlers
    const handleSelect = useCallback(
      (item: ModelItem) => {
        onChange(field.name, item.id);
        setIsSelectionOpen(false);
      },
      [onChange, field.name]
    );

    const handleClear = useCallback(() => {
      onChange(field.name, null);
    }, [onChange, field.name]);

    const handleOpenSelection = useCallback(() => {
      setIsSelectionOpen(true);
    }, []);

    const handleCloseSelection = useCallback(() => {
      setIsSelectionOpen(false);
    }, []);

    // Memoize input props
    const inputProps = useMemo(
      () => ({
        id: `${field.name}-fk`,
        value: getDisplayText(),
        readOnly: true,
        placeholder: `Select ${targetModel.toLowerCase()}`,
        disabled,
        className: error ? "border-ui-border-interactive" : "",
        "aria-invalid": error ? true : false,
        "aria-describedby": error ? `${field.name}-error` : undefined,
        onBlur,
      }),
      [field.name, getDisplayText, targetModel, disabled, error, onBlur]
    );

    return (
      <>
        <div className="space-y-2">
          <Label
            htmlFor={`${field.name}-fk`}
            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
          >
            {label}
            {!field.nullable && (
              <span className="text-ui-fg-error ml-1">*</span>
            )}
          </Label>
          <div className="flex gap-2">
            <div className="flex-1">
              <Input {...inputProps} />
              {error && (
                <p
                  id={`${field.name}-error`}
                  className="text-xs text-ui-fg-error mt-1"
                  role="alert"
                >
                  {error}
                </p>
              )}
            </div>
            <div className="flex gap-1">
              <IconButton
                onClick={handleOpenSelection}
                disabled={disabled}
                title={`Browse ${targetModel}`}
                aria-label={`Browse ${targetModel} options`}
              >
                <ArrowUpRightOnBox />
              </IconButton>
              {value !== 0 && value !== null && value !== undefined && (
                <IconButton
                  variant="transparent"
                  onClick={handleClear}
                  disabled={disabled}
                  title="Clear selection"
                  aria-label="Clear selection"
                >
                  <XMarkMini />
                </IconButton>
              )}
            </div>
          </div>
        </div>

        {/* Foreign Key Selection Drawer */}
        <ForeignKeySelectionTable
          targetModel={targetModel}
          onSelect={handleSelect}
          onClose={handleCloseSelection}
          isOpen={isSelectionOpen}
        />
      </>
    );
  }
);

ForeignKeyField.displayName = "ForeignKeyField";

export default ForeignKeyField;
