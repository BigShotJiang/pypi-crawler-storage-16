import { Heading, Text } from "@medusajs/ui";
import { Inbox } from "lucide-react";

interface EmptyDataProps {
  title?: string;
  message?: string;
  icon?: React.ReactNode;
}

const EmptyData: React.FC<EmptyDataProps> = ({
  title = "Empty Data",
  message = "Please check back later.",
}) => {
  return (
    <div className="text-center py-12">
      <Inbox className="h-12 w-12 text-ui-fg-muted mx-auto mb-4" />
      <Heading level="h3" className="text-lg font-medium text-ui-fg-base mb-2">
        {title}
      </Heading>
      <Text className="text-ui-fg-muted">{message}</Text>
    </div>
  );
};

export default EmptyData;
