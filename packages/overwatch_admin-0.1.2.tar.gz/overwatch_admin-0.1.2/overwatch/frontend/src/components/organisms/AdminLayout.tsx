import React, { useEffect, useState } from "react";
import { Outlet, Link, useLocation } from "react-router-dom";
import {
  Button,
  Avatar,
  Heading,
  Tooltip,
  TooltipProvider,
  Toaster,
  Container,
  IconButton,
  Badge,
} from "@medusajs/ui";
import {
  BarsThree,
  ChartBar,
  Glasses,
  Loader,
  StackPerspective,
  UserGroup,
  XMarkMini,
} from "@medusajs/icons";
import { cn } from "@/lib/utils";
import { useAuthStore, useHeaderStore } from "@/stores";
import { useRightAside } from "@/stores";
import { NavItem } from "@/types";
import {
  useAvailableModelsModelStore,
  useHydratedAvailableModels,
} from "@/stores";
import { useLogout } from "@/services";
import { usePublicConfig } from "@/services/config";
import { Header } from "../layouts/header";
import UserSettingsPage from "@/pages/user-settings";

interface AdminLayoutProps {
  children?: React.ReactNode;
}

const AdminLayout: React.FC<AdminLayoutProps> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isScrolling, setIsScrolling] = useState(false);
  const location = useLocation();

  const user = useAuthStore((s) => s.user);
  const setLogout = useAuthStore((s) => s.setLogout);
  const { mutateAsync: loggingOut } = useLogout(setLogout);

  const { header } = useHeaderStore();
  const { data: config } = usePublicConfig();

  const {
    isOpen: rightSidebarOpen,
    title: rightSidebarTitle,
    content: rightSidebarContent,
    contentClassName: rightSidebarContentClassName,
    openRightAside,
    closeRightAside,
  } = useRightAside();

  const navRef = React.useRef<HTMLDivElement>(null);

  const { isLoading } = useHydratedAvailableModels();
  const availableModels = useAvailableModelsModelStore(
    (s) => s.availableModels
  );
  const setSelectedModel = useAvailableModelsModelStore(
    (s) => s.setSelectedModel
  );

  useEffect(() => {
    const navElement = navRef.current;
    if (!navElement) return;

    let scrollTimeout: ReturnType<typeof setTimeout>;

    const handleScroll = () => {
      setIsScrolling(true);

      // Clear existing timeout
      if (scrollTimeout) {
        clearTimeout(scrollTimeout);
      }

      // Hide scrollbar after scrolling stops
      scrollTimeout = setTimeout(() => {
        setIsScrolling(false);
      }, 150);
    };

    navElement.addEventListener("scroll", handleScroll);

    return () => {
      navElement.removeEventListener("scroll", handleScroll);
      if (scrollTimeout) {
        clearTimeout(scrollTimeout);
      }
    };
  }, []);

  // Ensure we always have an array, even if API returns unexpected format
  const availableModelsArray = Array.isArray(availableModels)
    ? availableModels
    : [];

  // Top navigation items
  const topNavigation: NavItem[] = [
    {
      key: "/dashboard",
      name: "dashboard",
      label: "Dashboard",
      count: -1,
      icon: <ChartBar />,
      path: "/dashboard",
    },
    {
      key: "/audit-logs",
      name: "audit-logs",
      label: "Audit Logs",
      count: -1,
      icon: <Glasses />,
      path: "/audit-logs",
    },
    {
      key: "/administrations",
      name: "administrations",
      label: "Administrations",
      count: -1,
      icon: <UserGroup />,
      path: "/administrations",
    },
    {
      key: "/user-settings",
      name: "user-settings",
      label: "󠁯•••",
      count: -1,
      icon: <StackPerspective />,
      path: "/user-settings",
    },
  ];

  // Create dynamic navigation items from available models
  const modelNavigation: NavItem[] = availableModelsArray.map((model) => ({
    key: `/models/${model.name}`,
    label: model.label,
    name: model.name,
    path: `/models/${model.name}`,
    count: model.count,
  }));

  const isActive = (path: string) => location.pathname === path;

  const onModelClick = (item: NavItem) => {
    setSelectedModel({
      name: item.name,
      label: item.label,
      count: item.count,
    });
  };

  const openUserSettings = () => {
    if (rightSidebarOpen) {
      closeRightAside();
    } else {
      openRightAside("User Settings", <UserSettingsPage />);
    }
  };

  return (
    <TooltipProvider>
      <div className="flex h-screen bg-ui-bg-subtle">
        {/* Mobile sidebar backdrop */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 z-40 lg:hidden bg-ui-bg-overlay"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Sidebar */}
        <aside
          className={cn(
            "fixed inset-y-0 left-0 z-50 transform transition-all duration-300 ease-in-out lg:static lg:inset-0",
            "block -left-full top-0 h-[calc(100%-16px)] transition-[left] lg:relative lg:h-auto max-w-sidebar-xs sm:max-w-sidebar-sm md:max-w-sidebar-md lg:max-w-sidebar-lg xl:max-w-sidebar-xl xxl:max-w-sidebar-xxl xxxl:max-w-sidebar-xxxl w-sidebar-xs sm:w-auto lg:left-0",
            sidebarOpen
              ? "translate-x-0"
              : "-translate-x-full lg:translate-x-0",
            "lg:w-64"
          )}
        >
          <div className="flex flex-col h-full">
            {/* Fixed Header */}
            <div className="flex items-center justify-between p-4">
              <Heading level="h3" className="font-medium text-ui-fg-muted">
                Content Manager
              </Heading>
              <Badge size="xsmall">{availableModels.length}</Badge>
            </div>

            {/* Scrollable Content */}
            <nav
              ref={navRef}
              className={cn(
                "flex-1 overflow-y-scroll overflow-x-hidden scrollbar-hide p-4",
                isScrolling && "scrolling"
              )}
            >
              {isLoading ? (
                <div className="flex items-center justify-center py-4">
                  <Loader className="animate-spin" />
                </div>
              ) : (
                modelNavigation.map((item: NavItem) => (
                  <Link
                    key={item.key}
                    to={item.path}
                    className={cn(
                      "w-full txt-compact-small-plus transition-fg text-ui-fg-subtle inline-flex items-center rounded-md border border-transparent bg-transparent px-2.5 py-1 outline-none hover:bg-ui-bg-base focus-visible:border-ui-border-interactive focus-visible:!shadow-borders-focus focus-visible:bg-ui-bg-base mb-2 group",
                      isActive(item.path)
                        ? "text-ui-fg-base bg-ui-bg-base shadow-elevation-card-rest"
                        : ""
                    )}
                    title={item.label}
                    onClick={() => onModelClick(item)}
                  >
                    <span className="transition-all duration-300">
                      {item.label}
                    </span>
                  </Link>
                ))
              )}
            </nav>

            {/* Fixed Footer */}
            <footer className="flex-shrink-0 p-4">
              <p className="txt-compact-small-plus text-ui-fg-muted text-center">
                © 2024 {config?.admin_title || "Overwatch Admin"}
              </p>
            </footer>
          </div>
        </aside>

        {/* Main content */}
        <div
          className={cn(
            "flex-1 flex flex-col transition-all duration-300 m-2",
            "shadow-elevation-card-rest bg-ui-bg-base w-full rounded-lg",
            rightSidebarOpen && "mr-[20%]"
          )}
        >
          {/* Top bar */}
          <header className="top-bar backdrop-blur-md rounded-t-lg">
            <div className="flex items-start justify-between p-4">
              <div className="flex items-center">
                <Button
                  variant="secondary"
                  size="small"
                  className="lg:hidden"
                  onClick={() => setSidebarOpen(!sidebarOpen)}
                >
                  <BarsThree className="h-5 w-5" />
                </Button>

                <Header title={header.title} subtitle={header.subtitle} />
              </div>

              {/* User avatar dropdown on right */}
              <div className="flex items-center space-x-4">
                <nav className="hidden lg:flex items-center space-x-2">
                  {topNavigation.map((item: NavItem) =>
                    item.name === "user-settings" ? (
                      <Button
                        key={item.key}
                        variant="transparent"
                        className={cn(
                          "txt-compact-small-plus transition-fg text-ui-fg-subtle inline-flex items-center justify-center rounded-full border border-transparent bg-transparent px-2.5 py-1 outline-none hover:bg-ui-bg-subtle focus-visible:border-ui-border-interactive focus-visible:!shadow-borders-focus focus-visible:bg-ui-bg-base",
                          isActive(item.path)
                            ? "text-ui-fg-base bg-ui-bg-base shadow-elevation-card-rest"
                            : ""
                        )}
                        onClick={() => openUserSettings()}
                      >
                        {item.icon}
                        <span className="ml-2">{item.label}</span>
                      </Button>
                    ) : (
                      <Link
                        key={item.key}
                        to={item.path}
                        className={cn(
                          "txt-compact-small-plus transition-fg text-ui-fg-subtle inline-flex items-center justify-center rounded-full border border-transparent bg-transparent px-2.5 py-1 outline-none hover:bg-ui-bg-subtle focus-visible:border-ui-border-interactive focus-visible:!shadow-borders-focus focus-visible:bg-ui-bg-base",
                          isActive(item.path)
                            ? "text-ui-fg-base bg-ui-bg-base shadow-elevation-card-rest"
                            : ""
                        )}
                      >
                        {item.icon}
                        <span className="ml-2">{item.label}</span>
                      </Link>
                    )
                  )}

                  <div className="w-px h-6 bg-ui-border-base mx-2" />

                  <Tooltip
                    content={user?.email}
                    side="bottom"
                    align="end"
                    avoidCollisions
                  >
                    <Button
                      variant="danger"
                      size="small"
                      className="rounded-full"
                      onClick={async () => await loggingOut()}
                    >
                      <Avatar
                        fallback={
                          user?.username?.charAt(0)?.toUpperCase() || "U"
                        }
                        size="2xsmall"
                      />
                      Logout
                    </Button>
                  </Tooltip>
                </nav>
              </div>
            </div>
          </header>

          {/* Page content */}
          <main className="flex-1 overflow-y-scroll overflow-x-hidden bg-ui-bg-base p-4 rounded-lg">
            {children || <Outlet />}
          </main>
        </div>

        {/* Right Sidebar */}
        <aside
          className={cn(
            "p-2 fixed inset-y-0 right-0 transform transition-all duration-300 ease-in-out",
            "w-1/5",
            rightSidebarOpen ? "translate-x-0" : "translate-x-full"
          )}
        >
          <Container className="flex flex-col h-full pt-4 py-0 px-0">
            <div className="flex-shrink-0 p-4 pb-4 border-b border-ui-border-base">
              <div className="flex items-center justify-between">
                <Heading level="h3" className="font-medium text-ui-fg-base">
                  {rightSidebarTitle}
                </Heading>
                <IconButton
                  variant="transparent"
                  onClick={closeRightAside}
                  title="Close Aside"
                >
                  <XMarkMini />
                </IconButton>
              </div>
            </div>

            {/* Scrollable Content */}
            <div
              className={cn(
                "flex-1 overflow-y-scroll overflow-x-hidden p-4 rounded-b-lg",
                rightSidebarContentClassName
              )}
            >
              {rightSidebarContent}
            </div>
          </Container>
        </aside>
      </div>

      <Toaster />
    </TooltipProvider>
  );
};

export default AdminLayout;
