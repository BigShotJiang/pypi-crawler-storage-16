import { z } from "zod";

export const loginSchema = z.object({
  username: z
    .string()
    .min(1, "Username or email is required")
    .trim()
    .refine(
      (value) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const usernameRegex = /^[a-zA-Z0-9_.-]+$/;
        return emailRegex.test(value) || usernameRegex.test(value);
      },
      {
        message: "Please enter a valid username or email address",
      }
    ),
  password: z
    .string()
    .min(1, "Password is required")
    .refine(
      (value) => {
        return value.trim().length > 0;
      },
      {
        message: "Please enter your password",
      }
    ),
});
