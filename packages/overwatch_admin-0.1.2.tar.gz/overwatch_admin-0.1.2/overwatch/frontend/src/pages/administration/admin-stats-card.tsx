import { cn } from "@/lib/utils";
import { Container, Text } from "@medusajs/ui";
import { TrendingDown, TrendingUp } from "lucide-react";

interface AdminStatsCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  trend?: number;
  trendLabel?: string;
}

const AdminStatsCard: React.FC<AdminStatsCardProps> = ({
  title,
  value,
  icon,
  trend,
  trendLabel,
}) => (
  <Container>
    <div className="flex items-center">
      <div className="flex-shrink-0 bg-ui-bg-component hover:bg-ui-bg-component-hover rounded-lg p-3 transition-colors">
        {icon}
      </div>
      <div className="ml-5 w-0 flex-1">
        <dl>
          <dt className="text-sm font-medium text-ui-fg-muted truncate">
            {title}
          </dt>
          <dd>
            <div className="text-lg font-medium text-ui-fg-base">{value}</div>
            {trend !== undefined && (
              <div className="flex items-center">
                {trend >= 0 ? (
                  <TrendingUp className="h-4 w-4 text-ui-fg-success mr-1" />
                ) : (
                  <TrendingDown className="h-4 w-4 text-ui-fg-error mr-1" />
                )}
                <Text
                  className={cn(
                    "text-sm",
                    trend >= 0 ? "text-ui-fg-success" : "text-ui-fg-error"
                  )}
                >
                  {Math.abs(trend)}% {trendLabel}
                </Text>
              </div>
            )}
          </dd>
        </dl>
      </div>
    </div>
  </Container>
);

export default AdminStatsCard;
