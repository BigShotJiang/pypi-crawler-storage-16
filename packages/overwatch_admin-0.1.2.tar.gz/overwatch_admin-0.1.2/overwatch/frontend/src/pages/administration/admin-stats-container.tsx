import React from "react";
import { Users2, UserCheck, UserX, UserMinus } from "lucide-react";
import AdminStatsCard from "./admin-stats-card";
import { useAdminStatsStore } from "@/stores/administration";
import { Loader } from "@medusajs/icons";

const AdminStatsContainer: React.FC = () => {
  const adminStats = useAdminStatsStore((s) => s.adminStats);

  if (!adminStats) {
    return (
      <div className="flex items-center justify-center h-32">
        <Loader className="animate-spin" />
      </div>
    );
  }

  return (
    <div className="my-4 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
      <AdminStatsCard
        title="Active"
        value={adminStats.active_admins}
        icon={<UserCheck className="h-6 w-6" />}
      />
      <AdminStatsCard
        title="Super Admin"
        value={adminStats.super_admins}
        icon={<Users2 className="h-6 w-6" />}
      />
      <AdminStatsCard
        title="Read Only"
        value={adminStats.read_only_admins}
        icon={<UserX className="h-6 w-6" />}
      />
      <AdminStatsCard
        title="Suspended"
        value={adminStats.suspended_admins}
        icon={<UserMinus className="h-6 w-6" />}
      />
    </div>
  );
};

export default AdminStatsContainer;
