import React, { useState, useMemo, useEffect } from "react";
import {
  Heading,
  Button,
  DataTable,
  createDataTableColumnHelper,
  createDataTableFilterHelper,
  DataTablePaginationState,
  DataTableFilteringState,
  DataTableSortingState,
  useDataTable,
  DatePicker,
  StatusBadge,
  IconButton,
} from "@medusajs/ui";
import { XMarkMini, Eye } from "@medusajs/icons";
import { Calendar } from "lucide-react";
import { AuditLog, AuditFilters } from "@/types";
import { EmptyData } from "@/components/molecules";
import { AuditLogDetailDrawer } from "./audit-log-detail-drawer";

// Date Range Filter Component
const DateRangeFilter: React.FC<{
  dateFrom: string | undefined;
  dateTo: string | undefined;
  onDateFromChange: (date: Date | null) => void;
  onDateToChange: (date: Date | null) => void;
}> = ({ dateFrom, dateTo, onDateFromChange, onDateToChange }) => {
  return (
    <div className="flex items-center gap-2">
      <div className="flex items-center gap-2">
        <Calendar className="h-4 w-4 text-ui-fg-muted" />
        <span className="text-sm font-medium text-ui-fg-base">From:</span>
        <DatePicker
          value={dateFrom ? new Date(dateFrom) : null}
          onChange={onDateFromChange}
          size="small"
          className="w-40"
          aria-label="Start Date"
        />
      </div>
      <div className="flex items-center gap-2">
        <span className="text-sm font-medium text-ui-fg-base">To:</span>
        <DatePicker
          value={dateTo ? new Date(dateTo) : null}
          onChange={onDateToChange}
          size="small"
          className="w-40"
          aria-label="End Date"
        />
      </div>
    </div>
  );
};

interface PaginationProps {
  currentPage: number;
  pageSize: number;
  totalItems: number;
  totalPages: number;
}

interface AuditLogsTableProps {
  data: AuditLog[];
  isLoading?: boolean;
  pagination: PaginationProps;
  onPageChange: (page: number) => void;
  onPageSizeChange: (pageSize: number) => void;
  onFiltersChange: (filters: AuditFilters) => void;
  filters: AuditFilters;
}

const columnHelper = createDataTableColumnHelper<AuditLog>();

// Memoize cell components for better performance
const DateCell = React.memo(({ value }: { value: string }) => (
  <div className="text-ui-fg-base">{new Date(value).toLocaleString()}</div>
));

const AdminCell = React.memo(({ value }: { value: string }) => (
  <div className="font-medium text-ui-fg-base">{value}</div>
));

const ActionCell = React.memo(({ value }: { value: string }) => (
  <div className="flex items-center">
    <span className="capitalize text-ui-fg-base">{value.toUpperCase()}</span>
  </div>
));

const ResourceCell = React.memo(({ value }: { value: string }) => (
  <div className="capitalize text-ui-fg-base">{value}</div>
));

const IPAddressCell = React.memo(({ value }: { value: string }) => (
  <div className="text-ui-fg-base">{value}</div>
));

const StatusCell = React.memo(({ value }: { value: boolean }) => (
  <StatusBadge color={value ? "green" : "red"}>
    {value ? "Success" : "Failed"}
  </StatusBadge>
));

const ActionsCell = React.memo(
  ({
    row,
    onViewDetails,
  }: {
    row: any;
    onViewDetails: (log: AuditLog) => void;
  }) => (
    <div className="flex justify-end">
      <IconButton onClick={() => onViewDetails(row.original)} title="View">
        <Eye className="h-4 w-4" />
      </IconButton>
    </div>
  )
);

const useColumns = (onViewDetails: (log: AuditLog) => void) => {
  return useMemo(
    () => [
      columnHelper.accessor("created_at", {
        header: () => <div className="flex items-center">Date & Time</div>,
        enableSorting: true,
        sortLabel: "Created At",
        cell: ({ getValue }) => <DateCell value={getValue()} />,
      }),
      columnHelper.accessor("admin_username", {
        header: () => <div className="flex items-center">Admin</div>,
        enableSorting: true,
        sortLabel: "Admin",
        cell: ({ getValue }) => <AdminCell value={getValue()} />,
      }),
      columnHelper.accessor("resource_type", {
        header: "Resource",
        enableSorting: true,
        sortLabel: "Resource Type",
        cell: ({ getValue }) => <ResourceCell value={getValue()} />,
      }),
      columnHelper.accessor("ip_address", {
        header: "IP Address",
        enableSorting: false,
        cell: ({ getValue }) => <IPAddressCell value={getValue()} />,
      }),
      columnHelper.accessor("success", {
        header: "Status",
        enableSorting: true,
        sortLabel: "Status",
        cell: ({ getValue }) => <StatusCell value={getValue()} />,
      }),
      columnHelper.accessor("action", {
        header: "Action",
        enableSorting: true,
        sortLabel: "Action",
        cell: ({ getValue }) => <ActionCell value={getValue()} />,
      }),
      columnHelper.display({
        id: "actions",
        header: "",
        size: 40,
        cell: ({ row }) => (
          <ActionsCell row={row} onViewDetails={onViewDetails} />
        ),
      }),
    ],
    [onViewDetails]
  );
};

// Static filter options since we're using server-side filtering
const getStaticFilters = () => {
  const filterHelper = createDataTableFilterHelper<AuditLog>();

  return [
    filterHelper.accessor("action", {
      type: "select" as const,
      label: "Action",
      options: [
        { label: "Create", value: "create" },
        { label: "Update", value: "update" },
        { label: "Delete", value: "delete" },
        { label: "Login", value: "login" },
        { label: "Logout", value: "logout" },
        { label: "Export", value: "export" },
      ],
    }),
    filterHelper.accessor("success", {
      type: "radio" as const,
      label: "Status",
      options: [
        { label: "Success", value: "true" },
        { label: "Failed", value: "false" },
      ],
    }),
    filterHelper.accessor("resource_type", {
      type: "select" as const,
      label: "Resource Type",
      options: [
        { label: "Admin", value: "admin" },
        { label: "User", value: "user" },
        { label: "Product", value: "product" },
        { label: "Order", value: "order" },
        { label: "AuditLog", value: "audit_log" },
      ],
    }),
  ];
};

// AuditLogsTable component
export const AuditLogsTable: React.FC<AuditLogsTableProps> = ({
  data,
  isLoading = false,
  pagination,
  onPageChange,
  onPageSizeChange,
  onFiltersChange,
  filters,
}) => {
  // Local state for UI interactions
  const [search, setSearch] = useState(filters.search || "");
  const [filtering, setFiltering] = useState<DataTableFilteringState>({});
  const [sorting, setSorting] = useState<DataTableSortingState | null>(null);
  const [selectedLog, setSelectedLog] = useState<AuditLog | null>(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  // Date range state
  const [, setDateFrom] = useState<Date | null>(
    filters.date_from ? new Date(filters.date_from) : null
  );
  const [, setDateTo] = useState<Date | null>(
    filters.date_to ? new Date(filters.date_to) : null
  );

  // Handle view details
  const handleViewDetails = (log: AuditLog) => {
    setSelectedLog(log);
    setIsDrawerOpen(true);
  };

  // Handle drawer close
  const handleDrawerClose = () => {
    setIsDrawerOpen(false);
    setSelectedLog(null);
  };

  // Get columns and static filters
  const columns = useColumns(handleViewDetails);
  const staticFilters = getStaticFilters();

  // Sync search with parent filters
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      onFiltersChange({ ...filters, search });
    }, 500); // Debounce search

    return () => clearTimeout(timeoutId);
  }, [search]);

  // Handle date range changes
  const handleDateFromChange = (date: Date | null) => {
    setDateFrom(date);
    const isoString = date ? date.toISOString().split("T")[0] : undefined;
    onFiltersChange({ ...filters, date_from: isoString });
  };

  const handleDateToChange = (date: Date | null) => {
    setDateTo(date);
    const isoString = date ? date.toISOString().split("T")[0] : undefined;
    onFiltersChange({ ...filters, date_to: isoString });
  };

  // Sync filters with parent
  useEffect(() => {
    const newFilters: AuditFilters = { ...filters };

    // Convert DataTable filters to API filters
    Object.entries(filtering).forEach(([key, value]) => {
      if (value) {
        if (key === "success" && typeof value === "string") {
          newFilters.success = value === "true";
        } else if (key === "action" && typeof value === "string") {
          newFilters.action = value;
        } else if (key === "resource_type" && typeof value === "string") {
          newFilters.resource_type = value;
        }
      }
    });

    // Handle sorting
    if (sorting) {
      newFilters.sort_by = sorting.id;
      newFilters.sort_direction = sorting.desc ? "desc" : "asc";
    }

    onFiltersChange(newFilters);
  }, [filtering, sorting]);

  // Handle pagination changes
  const handlePaginationChange = (newPagination: DataTablePaginationState) => {
    onPageChange(newPagination.pageIndex + 1); // Convert 0-based to 1-based
    onPageSizeChange(newPagination.pageSize);
  };

  // Clear all filters
  const clearFilters = () => {
    setSearch("");
    setFiltering({});
    setSorting(null);
    setDateFrom(null);
    setDateTo(null);
    onPageChange(1);
    onFiltersChange({});
  };

  // Convert server pagination to DataTable format
  const paginationState: DataTablePaginationState = {
    pageSize: pagination.pageSize,
    pageIndex: pagination.currentPage - 1,
  };

  // Use DataTable hook
  const table = useDataTable({
    columns,
    data: data,
    getRowId: (row: AuditLog) => String(row.id),
    rowCount: pagination.totalItems,
    isLoading,
    search: {
      state: search,
      onSearchChange: setSearch,
    },
    pagination: {
      state: paginationState,
      onPaginationChange: handlePaginationChange,
    },
    filtering: {
      state: filtering,
      onFilteringChange: setFiltering,
    },
    sorting: {
      state: sorting,
      onSortingChange: setSorting,
    },
    filters: staticFilters,
  });

  return (
    <>
      <DataTable instance={table}>
        <DataTable.Toolbar className="flex flex-col items-start justify-between gap-2 md:flex-row md:items-center">
          <Heading level="h3">Audit Logs</Heading>
          <div className="flex flex-col gap-2 md:flex-row md:items-center">
            <DateRangeFilter
              dateFrom={filters.date_from}
              dateTo={filters.date_to}
              onDateFromChange={handleDateFromChange}
              onDateToChange={handleDateToChange}
            />
            <div className="flex gap-2">
              <DataTable.Search placeholder="Search..." />
              <DataTable.FilterMenu />
              <DataTable.SortingMenu />
              {search ||
              Object.keys(filtering).length > 0 ||
              sorting ||
              Object.keys(filters).some(
                (key) => key !== "search" && filters[key as keyof AuditFilters]
              ) ? (
                <Button variant="danger" size="small" onClick={clearFilters}>
                  <XMarkMini />
                </Button>
              ) : null}
            </div>
          </div>
        </DataTable.Toolbar>
        {!isLoading && data.length === 0 ? (
          <EmptyData title="No audit logs found." />
        ) : (
          <>
            <DataTable.Table />
            <DataTable.Pagination />
          </>
        )}
      </DataTable>

      {/* Audit Log Detail Drawer */}
      <AuditLogDetailDrawer
        log={selectedLog}
        isOpen={isDrawerOpen}
        onClose={handleDrawerClose}
      />
    </>
  );
};

export default AuditLogsTable;
