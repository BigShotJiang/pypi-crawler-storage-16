import React from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { Container, Heading } from "@medusajs/ui";
import { AuditStatistics } from "@/types/audit";

interface DailyTrendsChartProps {
  data: AuditStatistics["daily_trends"];
}

const DailyTrendsChart: React.FC<DailyTrendsChartProps> = ({ data }) => {
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
  };

  return (
    <Container>
      <Heading level="h3" className="text-ui-fg-base mb-4">
        Daily Trends
      </Heading>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={data}>
          <CartesianGrid
            strokeDasharray="3 3"
            stroke="rgba(120, 120, 125, 0.3)"
            className="opacity-30"
          />
          <XAxis
            dataKey="date"
            tickFormatter={formatDate}
            stroke="rgba(160, 160, 165, 0.8)"
            fontSize={12}
            tick={{ fill: "rgba(160, 160, 165, 0.8)" }}
          />
          <YAxis
            stroke="rgba(160, 160, 165, 0.8)"
            fontSize={12}
            tick={{ fill: "rgba(160, 160, 165, 0.8)" }}
          />
          <Tooltip
            labelFormatter={(value) => formatDate(value as string)}
            formatter={(value: number) => [value, "Actions"]}
            contentStyle={{
              backgroundColor: "rgba(33, 33, 36, 0.95)",
              border: "1px solid rgba(80, 80, 85, 0.5)",
              borderRadius: "8px",
              fontSize: "12px",
              color: "rgba(220, 220, 225, 0.9)",
            }}
            labelStyle={{ color: "rgba(180, 180, 185, 0.9)", fontWeight: 500 }}
          />
          <Line
            type="monotone"
            dataKey="count"
            stroke="rgba(140, 140, 145, 0.9)"
            strokeWidth={2}
            dot={{
              fill: "rgba(140, 140, 145, 0.9)",
              r: 4,
              strokeWidth: 0,
            }}
            activeDot={{
              r: 6,
              fill: "rgba(180, 180, 185, 0.9)",
            }}
          />
        </LineChart>
      </ResponsiveContainer>
    </Container>
  );
};

export default DailyTrendsChart;
