import React from "react";
import { Users, Database, AlertTriangle, Users2 } from "lucide-react";
import { SingleColumnLayout } from "@/components/layouts/single-column";
import StatCard from "./stat-card";
import DailyTrendsChart from "./daily-trends-chart";
import TopActionsChart from "./top-actions-chart";
import TopResourcesChart from "./top-resources-chart";
import {
  useHydratedHeader,
  useHydratedStatistic,
  useHydratedStats,
  useStatisticStore,
  useStatsStore,
} from "@/stores";
import { Loader } from "@medusajs/icons";
import { ErrorDisplay } from "@/components/molecules";

const DashboardPage: React.FC = () => {
  useHydratedHeader("Dashboard", "Here's what's happening today.");

  const { isLoading: isStatsLoading } = useHydratedStats();
  const stats = useStatsStore((s) => s.stats);

  const { isLoading: statisticLoading, error: statisticError } =
    useHydratedStatistic();
  const { statistic } = useStatisticStore();

  const isLoading = isStatsLoading || statisticLoading;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader className="animate-spin" />
      </div>
    );
  }

  if (statisticError) {
    return <ErrorDisplay title="Error loading dashboard." />;
  }

  return (
    <SingleColumnLayout>
      <div className="my-4 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Active Admins"
          value={stats?.system_stats.active_admins || 0}
          icon={<Users className="h-6 w-6" />}
          trend={stats?.userGrowth}
          trendLabel="from last month"
        />
        <StatCard
          title="Total Admins"
          value={stats?.system_stats.total_admins || 0}
          icon={<Users2 className="h-6 w-6" />}
        />
        <StatCard
          title="Recent Logins"
          value={stats?.system_stats.recent_logins || 0}
          icon={<Database className="h-6 w-6" />}
          trend={stats?.modelGrowth}
          trendLabel="from last month"
        />
        <StatCard
          title="Recent Activity"
          value={stats?.system_stats.total_actions || 0}
          icon={<AlertTriangle className="h-6 w-6" />}
        />
      </div>

      <div className="space-y-6">
        <div className="grid grid-cols-1 gap-6">
          <DailyTrendsChart data={statistic?.daily_trends || []} />
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <TopActionsChart data={statistic?.top_actions || []} />
          <TopResourcesChart data={statistic?.top_resources || []} />
        </div>
      </div>
    </SingleColumnLayout>
  );
};

export default DashboardPage;
