import React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";
import { Container, Heading } from "@medusajs/ui";
import { AuditAction } from "@/types/audit";

interface TopActionsChartProps {
  data: AuditAction[];
}

const TopActionsChart: React.FC<TopActionsChartProps> = ({ data }) => {
  const colors = [
    "rgba(140, 140, 145, 0.9)",
    "rgba(125, 125, 130, 0.9)",
    "rgba(155, 155, 160, 0.9)",
    "rgba(170, 170, 175, 0.9)",
    "rgba(110, 110, 115, 0.9)",
    "rgba(185, 185, 190, 0.9)",
  ];

  const formatActionName = (action: string) => {
    return action.charAt(0).toUpperCase() + action.slice(1).replace(/_/g, " ");
  };

  return (
    <Container>
      <Heading level="h3" className="text-ui-fg-base mb-4">
        Top Actions
      </Heading>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart
          data={data}
          margin={{ top: 20, right: 30, left: 20, bottom: 60 }}
        >
          <CartesianGrid
            strokeDasharray="3 3"
            stroke="rgba(120, 120, 125, 0.3)"
            className="opacity-30"
          />
          <XAxis
            dataKey="action"
            tickFormatter={formatActionName}
            stroke="rgba(160, 160, 165, 0.8)"
            fontSize={12}
            angle={-45}
            textAnchor="end"
            height={80}
            tick={{ fill: "rgba(160, 160, 165, 0.8)" }}
          />
          <YAxis
            stroke="rgba(160, 160, 165, 0.8)"
            fontSize={12}
            tick={{ fill: "rgba(160, 160, 165, 0.8)" }}
          />
          <Tooltip
            labelFormatter={(value) => formatActionName(value as string)}
            formatter={(value: number) => [value, "Count"]}
            contentStyle={{
              backgroundColor: "rgba(33, 33, 36, 0.95)",
              border: "1px solid rgba(80, 80, 85, 0.5)",
              borderRadius: "8px",
              fontSize: "12px",
              color: "rgba(220, 220, 225, 0.9)",
            }}
            labelStyle={{
              color: "rgba(180, 180, 185, 0.9)",
              fontWeight: 500,
            }}
          />
          <Bar dataKey="count" radius={[4, 4, 0, 0]}>
            {data.map((_, index) => (
              <Cell
                key={`cell-${index}`}
                fill={colors[index % colors.length]}
              />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </Container>
  );
};

export default TopActionsChart;
