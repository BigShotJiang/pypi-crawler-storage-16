import React, { useEffect } from "react";
import { Container, Heading, Text, Button, Label, Input } from "@medusajs/ui";
import { ShieldCheck } from "lucide-react";
import { ArrowRightOnRectangle, Spinner } from "@medusajs/icons";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAuthStore } from "@/stores/auth/useAuthStore";
import { useLogin } from "@/services/auth";
import { usePublicConfig } from "@/services/config";
import { loginSchema } from "@/lib/validations";

type LoginFormData = z.infer<typeof loginSchema>;

const LoginPage: React.FC = () => {
  const { setLogin } = useAuthStore();
  const { isPending, mutateAsync } = useLogin(setLogin);
  const { data: config } = usePublicConfig();

  useEffect(() => {
    // Update document title
    if (config?.admin_title) {
      document.title = config.admin_title;
    }

    // Update favicon
    if (config?.favicon_url) {
      const favicon = document.querySelector(
        'link[rel="icon"]'
      ) as HTMLLinkElement;
      if (favicon) {
        favicon.href = config.favicon_url;
      }
    }
  }, [config]);

  const {
    control,
    handleSubmit,
    formState: { errors, isValid },
  } = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    mode: "onChange",
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const onSubmit = async (data: LoginFormData) => {
    await mutateAsync(data);
  };

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation();
      handleSubmit(onSubmit)();
    }
  };

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        e.stopPropagation();
        handleSubmit(onSubmit)();
      }}
      className="min-h-screen flex items-center justify-center bg-ui-bg-subtle py-12 px-4 sm:px-2 lg:px-4"
    >
      <Container className="max-w-md w-full space-y-6">
        <div className="text-center">
          <div className="flex justify-center mb-1">
            <div className="flex items-center flex-col space-y-2">
              {config?.logo_url ? (
                <img
                  src={config.logo_url}
                  alt="Logo"
                  className="h-16 w-16 object-contain filter-white"
                />
              ) : (
                <ShieldCheck className="h-16 w-16" />
              )}
              <Heading
                level="h2"
                className="text-2xl font-bold text-ui-fg-base"
              >
                {config?.admin_title || "Overwatch Admin"}
              </Heading>
            </div>
          </div>
          <Text className="text-ui-fg-muted">Log in to your admin panel</Text>
        </div>

        {/* Username Field */}
        <div className="space-y-2">
          <Label
            htmlFor="username-input"
            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
          >
            Username or Email
          </Label>
          <Controller
            name="username"
            control={control}
            render={({ field }) => (
              <Input
                {...field}
                id="username-input"
                type="text"
                placeholder="Enter your username or email"
                aria-invalid={!!errors.username}
                onKeyDown={onKeyDown}
              />
            )}
          />
          {errors.username && (
            <p className="text-xs text-ui-fg-error">
              {errors.username.message}
            </p>
          )}
        </div>

        {/* Password Field */}
        <div className="space-y-2">
          <Label
            htmlFor="password-input"
            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
          >
            Password
          </Label>
          <Controller
            name="password"
            control={control}
            render={({ field }) => (
              <Input
                {...field}
                id="password-input"
                type="password"
                placeholder="Enter your password"
                aria-invalid={!!errors.password}
                onKeyDown={onKeyDown}
              />
            )}
          />
          {errors.password && (
            <p className="text-xs text-ui-fg-error">
              {errors.password.message}
            </p>
          )}
        </div>

        <Button
          type="submit"
          className="w-full"
          disabled={isPending || !isValid}
        >
          {isPending ? (
            <Spinner className="animate-spin" />
          ) : (
            <ArrowRightOnRectangle />
          )}
          Login
        </Button>
      </Container>
    </form>
  );
};

export default LoginPage;
