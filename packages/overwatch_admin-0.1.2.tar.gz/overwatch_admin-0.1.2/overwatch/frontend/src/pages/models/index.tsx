import React, { useState } from "react";
import { useParams } from "react-router-dom";
import { SingleColumnLayout } from "@/components/layouts/single-column";
import { ErrorDisplay } from "@/components/molecules";
import { ModelsTable } from "./models-table";
import { ModelNewEditDrawer } from "./model-new-edit-drawer";
import { ModelFilters, ModelItem } from "@/types";
import {
  useAvailableModelsModelStore,
  useHydratedHeader,
  useHydratedModelList,
  useModelListStore,
  useRightAside,
} from "@/stores";
import {
  useBulkDeleteModel,
  useCreateModel,
  useDeleteModel,
  useUpdateModel,
} from "@/services";
import { CodeBlock } from "@medusajs/ui";
import { formatJson } from "@/lib/utils";

const ModelsPage: React.FC = () => {
  const { openRightAside, closeRightAside, isOpen } = useRightAside();
  const { modelName } = useParams<{ modelName: string }>();

  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [filters, setFilters] = useState<ModelFilters>({ search: "" });
  const [drawerItem, setDrawerItem] = useState<ModelItem | null>(null);
  const [drawerMode, setDrawerMode] = useState<"edit" | "new">("edit");
  const [drawerOpen, isDrawerOpen] = useState(false);

  const selectedModel = useAvailableModelsModelStore((s) => s.selectedModel);

  useHydratedHeader(
    `${selectedModel?.label}`,
    `Manage and view all ${selectedModel?.label.toLowerCase()}`
  );

  const { isLoading, error } = useHydratedModelList(modelName!, {
    page: currentPage,
    per_page: pageSize,
    ...filters,
  });
  const modelData = useModelListStore((d) => d.modelList);

  const deleteMutation = useDeleteModel(modelName!);

  const bulkDeleteMutation = useBulkDeleteModel(modelName!);

  const handleCloseDrawer = () => {
    isDrawerOpen(false);
    setDrawerItem(null);
  };

  const createMutation = useCreateModel(modelName!, handleCloseDrawer);

  const updateMutation = useUpdateModel(
    modelName!,
    drawerItem?.id ?? "",
    handleCloseDrawer
  );

  const handleNewItem = () => {
    setDrawerItem(null);
    setDrawerMode("new");
    isDrawerOpen(true);
  };

  const handleEdit = (item: ModelItem) => {
    setDrawerItem(item);
    setDrawerMode("edit");
    isDrawerOpen(true);
  };

  const handleSave = (data: Record<string, any>) => {
    if (drawerMode === "new") {
      createMutation.mutate(data);
    } else {
      updateMutation.mutate(data);
    }
  };

  const handleDelete = (item: ModelItem) => {
    deleteMutation.mutate(item.id);
  };

  const handleBulkDelete = (ids: number[]) => {
    bulkDeleteMutation.mutate(ids);
  };

  // Handle page change
  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  // Handle page size change
  const handlePageSizeChange = (size: number) => {
    setPageSize(size);
    setCurrentPage(1);
  };

  // Handle filters change
  const handleFiltersChange = (newFilters: ModelFilters) => {
    setFilters(newFilters);
    setCurrentPage(1);
  };

  if (error) {
    return (
      <ErrorDisplay
        title="Error loading model data"
        message={error?.message || "An unexpected error occurred"}
      />
    );
  }

  if (!modelName) {
    return (
      <ErrorDisplay
        title="Model not found"
        message="Please specify a valid model name in the URL"
      />
    );
  }

  // Calculate stats
  const totalRecords = modelData?.total || 0;
  const totalPages = modelData?.pages || 0;

  const handleInfo = () => {
    if (isOpen) {
      closeRightAside();
    } else {
      const snippets = [
        {
          label: "Metadata",
          language: "json",
          code: formatJson(modelData?.metadata) ?? formatJson("{}"),
          hideCopy: true,
        },
      ];
      const content = (
        <CodeBlock
          snippets={snippets}
          className="aside-code-block rounded-none"
        >
          <CodeBlock.Body className="aside-code-body rounded-none border-none" />
        </CodeBlock>
      );

      openRightAside("Metadata", content, "p-0");
    }
  };

  return (
    <SingleColumnLayout>
      <ModelsTable
        data={modelData?.items || []}
        modelName={selectedModel?.label ?? ""}
        modelFields={modelData ? Object.values(modelData.metadata.fields) : []}
        isLoading={isLoading}
        pagination={{
          currentPage,
          pageSize,
          totalItems: totalRecords,
          totalPages,
        }}
        onPageChange={handlePageChange}
        onPageSizeChange={handlePageSizeChange}
        onFiltersChange={handleFiltersChange}
        filters={filters}
        onInfo={handleInfo}
        onNew={handleNewItem}
        onEdit={handleEdit}
        onDelete={handleDelete}
        onBulkDelete={handleBulkDelete}
      />

      {/* Edit/New Drawer */}
      <ModelNewEditDrawer
        item={drawerItem}
        mode={drawerMode}
        modelName={selectedModel?.label ?? ""}
        modelFields={Object.values(modelData?.metadata.fields || {})}
        isOpen={drawerOpen}
        onClose={handleCloseDrawer}
        onSave={handleSave}
        isLoading={
          drawerMode === "new"
            ? createMutation.isPending
            : updateMutation.isPending
        }
      />
    </SingleColumnLayout>
  );
};

export default ModelsPage;
