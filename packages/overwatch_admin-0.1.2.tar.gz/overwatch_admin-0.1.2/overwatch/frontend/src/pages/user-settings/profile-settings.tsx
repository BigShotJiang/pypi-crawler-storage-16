import React from "react";
import { Button, Label, Input, Heading } from "@medusajs/ui";
import { Check, Spinner } from "@medusajs/icons";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { profileSettingsSchema } from "@/lib/validations";
import { useUpdateMe } from "@/services";
import { useAuthStore } from "@/stores";

type ProfileSettingsFormData = z.infer<typeof profileSettingsSchema>;

interface ProfileSettingsProps {}

const ProfileSettings: React.FC<ProfileSettingsProps> = () => {
  const user = useAuthStore((s) => s.user);
  const { isPending, mutate: updateProfile } = useUpdateMe();

  const {
    control,
    handleSubmit,
    formState: { errors, isValid },
  } = useForm<ProfileSettingsFormData>({
    resolver: zodResolver(profileSettingsSchema),
    mode: "onChange",
    defaultValues: {
      username: user?.username ?? "",
      email: user?.email ?? "",
      first_name: user?.first_name ?? "",
      last_name: user?.last_name ?? "",
    },
  });

  const handleSave = (data: ProfileSettingsFormData) => {
    updateProfile(data);
  };

  return (
    <div className="flex flex-col">
      <Heading level="h3" className="text-lg font-medium text-ui-fg-base mb-4">
        Profile Settings
      </Heading>
      <div className="space-y-2">
        {/* Username Field */}
        <div className="col-span-1">
          <div className="space-y-2">
            <Label
              htmlFor="username-input"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              Username
              <span className="text-ui-fg-error ml-1">*</span>
            </Label>
            <Controller
              name="username"
              control={control}
              render={({ field }) => (
                <Input
                  {...field}
                  id="username-input"
                  type="text"
                  readOnly={true}
                  disabled={isPending || true}
                />
              )}
            />
            {errors.username && (
              <p className="text-xs text-ui-fg-error">
                {errors.username.message}
              </p>
            )}
          </div>
        </div>

        {/* Email Field */}
        <div className="col-span-1">
          <div className="space-y-2">
            <Label
              htmlFor="email-input"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              Email
              <span className="text-ui-fg-error ml-1">*</span>
            </Label>
            <Controller
              name="email"
              control={control}
              render={({ field }) => (
                <Input
                  {...field}
                  id="email-input"
                  type="email"
                  disabled={isPending}
                />
              )}
            />
            {errors.email && (
              <p className="text-xs text-ui-fg-error">{errors.email.message}</p>
            )}
          </div>
        </div>

        {/* First Name Field */}
        <div className="col-span-1">
          <div className="space-y-2">
            <Label
              htmlFor="first_name-input"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              First Name
              <span className="text-ui-fg-error ml-1">*</span>
            </Label>
            <Controller
              name="first_name"
              control={control}
              render={({ field }) => (
                <Input
                  {...field}
                  id="first_name-input"
                  type="text"
                  disabled={isPending}
                />
              )}
            />
            {errors.first_name && (
              <p className="text-xs text-ui-fg-error">
                {errors.first_name.message}
              </p>
            )}
          </div>
        </div>

        {/* Last Name Field */}
        <div className="col-span-1">
          <div className="space-y-2">
            <Label
              htmlFor="last_name-input"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              Last Name
              <span className="text-ui-fg-error ml-1">*</span>
            </Label>
            <Controller
              name="last_name"
              control={control}
              render={({ field }) => (
                <Input
                  {...field}
                  id="last_name-input"
                  type="text"
                  disabled={isPending}
                />
              )}
            />
            {errors.last_name && (
              <p className="text-xs text-ui-fg-error">
                {errors.last_name.message}
              </p>
            )}
          </div>
        </div>
      </div>

      <div className="mt-8 flex justify-end">
        <Button
          onClick={handleSubmit(handleSave)}
          disabled={isPending || !isValid}
        >
          {isPending ? <Spinner className="animate-spin" /> : <Check />}
          Save Profile
        </Button>
      </div>
    </div>
  );
};

export default ProfileSettings;
