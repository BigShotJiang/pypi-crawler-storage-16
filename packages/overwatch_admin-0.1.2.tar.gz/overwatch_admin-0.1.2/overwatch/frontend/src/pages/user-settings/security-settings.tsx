import React from "react";
import { Button, Label, Input, Heading, Text, Switch } from "@medusajs/ui";
import { Check, Spinner } from "@medusajs/icons";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { securitySettingsSchema } from "@/lib/validations";
import { useChangePassword } from "@/services";

type SecuritySettingsFormData = z.infer<typeof securitySettingsSchema>;

const defaultSecuritySettings = {
  current_password: "",
  new_password: "",
  confirm_password: "",
  two_factor_enabled: false,
};

const SecuritySettings: React.FC = () => {
  const { isPending, mutate: changePassword } = useChangePassword(() => {
    reset(defaultSecuritySettings);
  });

  const {
    control,
    handleSubmit,
    formState: { errors, isValid },
    reset,
  } = useForm<SecuritySettingsFormData>({
    resolver: zodResolver(securitySettingsSchema),
    mode: "onChange",
    defaultValues: defaultSecuritySettings,
  });

  const handleSave = (data: SecuritySettingsFormData) => {
    changePassword({
      current_password: data.current_password,
      new_password: data.new_password,
    });
  };

  return (
    <div className="flex flex-col">
      <Heading level="h3" className="text-lg font-medium text-ui-fg-base mb-4">
        Security Settings
      </Heading>
      <div className="space-y-6">
        <div className="space-y-2">
          <Label
            htmlFor="current-password"
            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
          >
            Current Password
            <span className="text-ui-fg-error ml-1">*</span>
          </Label>
          <Controller
            name="current_password"
            control={control}
            render={({ field }) => (
              <Input
                {...field}
                id="current-password"
                type="password"
                placeholder="Input your current password"
                disabled={isPending}
                aria-invalid={!!errors.current_password}
              />
            )}
          />
          {errors.current_password && (
            <p className="text-xs text-ui-fg-error">
              {typeof errors.current_password.message === "string"
                ? errors.current_password.message
                : "Current password is required"}
            </p>
          )}
        </div>

        <div>
          <Text className="font-medium mb-4">Change Password</Text>
          <div className="space-y-2">
            <div className="space-y-2">
              <Label
                htmlFor="new-password"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                New Password
                <span className="text-ui-fg-error ml-1">*</span>
              </Label>
              <Controller
                name="new_password"
                control={control}
                render={({ field }) => (
                  <Input
                    {...field}
                    id="new-password"
                    type="password"
                    placeholder="Input your new password"
                    disabled={isPending}
                    aria-invalid={!!errors.new_password}
                  />
                )}
              />
              {errors.new_password && (
                <p className="text-xs text-ui-fg-error">
                  {typeof errors.new_password.message === "string"
                    ? errors.new_password.message
                    : "New password is required"}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label
                htmlFor="confirm-password"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                Confirm New Password
                <span className="text-ui-fg-error ml-1">*</span>
              </Label>
              <Controller
                name="confirm_password"
                control={control}
                render={({ field }) => (
                  <Input
                    {...field}
                    id="confirm-password"
                    type="password"
                    placeholder="Confirm your new password"
                    disabled={isPending}
                    aria-invalid={!!errors.confirm_password}
                  />
                )}
              />
              {errors.confirm_password && (
                <p className="text-xs text-ui-fg-error">
                  {typeof errors.confirm_password.message === "string"
                    ? errors.confirm_password.message
                    : "Please confirm your new password"}
                </p>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div>
            <Text className="font-medium">Two-Factor Authentication</Text>
            <Text className="text-sm text-ui-fg-muted">
              Add an extra layer of security to your account
            </Text>
          </div>
          <Controller
            name="two_factor_enabled"
            control={control}
            render={({ field }) => (
              <Switch checked={field.value} onCheckedChange={field.onChange} />
            )}
          />
        </div>
      </div>

      <div className="mt-6 flex justify-end">
        <Button
          onClick={handleSubmit(handleSave)}
          disabled={isPending || !isValid}
        >
          {isPending ? <Spinner className="animate-spin" /> : <Check />}
          Save
        </Button>
      </div>
    </div>
  );
};

export default SecuritySettings;
