import { useMutation, useQueryClient } from "@tanstack/react-query";
import { adminApi } from "@/api";
import { toast } from "@medusajs/ui";

export function useDeleteAdmin(onSuccess?: () => void) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (id: number) => adminApi.deleteAdmin(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["administrations"] });

      toast.success("Success", {
        description: "Item deleted successfully!",
      });

      onSuccess?.();
    },
    onError: (error: any) => {
      const errorMessage =
        error.response?.data?.detail ||
        error.response?.data?.message ||
        error.message ||
        "Unknown error. Please try again.";

      toast.error("Error", {
        description: errorMessage,
      });
    },
  });
}
