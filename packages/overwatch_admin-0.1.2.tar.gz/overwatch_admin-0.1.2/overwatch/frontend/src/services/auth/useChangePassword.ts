import { authApi } from "@/api";
import { toast } from "@medusajs/ui";
import { useMutation } from "@tanstack/react-query";

export function useChangePassword(onSuccess?: () => void) {
  return useMutation({
    mutationFn: (data: { current_password: string; new_password: string }) =>
      authApi.changePassword(data),
    onSuccess: () => {
      toast.success("Success", {
        description: "Your password has been changed successfully!",
        position: "top-center",
        duration: 2000,
      });

      onSuccess?.();
    },
    onError: (error: any) => {
      const errorMessage =
        error.response?.data?.detail ||
        error.response?.data?.message ||
        error.message ||
        "Failed to change password. Please try again.";

      toast.error("Error", {
        description: errorMessage,
        position: "top-center",
      });
    },
  });
}
