import { authApi } from "@/api";
import { AuthResponse, LoginCredentials } from "@/types";
import { toast } from "@medusajs/ui";
import { useMutation } from "@tanstack/react-query";

export function useLogin(setLogin: (res: AuthResponse) => void) {
  return useMutation({
    mutationFn: (credentials: LoginCredentials) => authApi.login(credentials),
    onSuccess: (data) => {
      setLogin(data);
      toast.success("Success", {
        description: "Welcome back! Redirecting to dashboard...",
        position: "top-center",
        duration: 1000,
      });
    },
    onError: (error: any) => {
      toast.error("Error", {
        description: `${error.message || "Login failed. Please try again."}`,
        position: "top-center",
      });
    },
  });
}
