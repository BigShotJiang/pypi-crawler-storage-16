import { authApi } from "@/api";
import { toast } from "@medusajs/ui";
import { useMutation } from "@tanstack/react-query";

export function useLogout(setLogout: () => void) {
  return useMutation({
    mutationFn: () => authApi.logout(),
    onSuccess: () => {
      setLogout();
      toast.success("Success", {
        description: "Logging out! Redirecting to login page...",
        position: "top-center",
        duration: 1000,
      });
    },
    onError: (error: any) => {
      toast.error("Error", {
        description: `${error.message || "Login failed. Please try again."}`,
        position: "top-center",
      });
    },
  });
}
