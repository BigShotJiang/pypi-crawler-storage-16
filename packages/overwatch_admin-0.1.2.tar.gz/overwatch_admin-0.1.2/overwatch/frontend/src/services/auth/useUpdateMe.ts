import { authApi } from "@/api";
import { UserSettings } from "@/types";
import { toast } from "@medusajs/ui";
import { useMutation, useQueryClient } from "@tanstack/react-query";

export function useUpdateMe() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (user: UserSettings) => authApi.updateMe(user),
    onSuccess: () => {
      toast.success("Success", {
        description: "Your profile is successfully updated!",
        position: "top-center",
        duration: 1000,
      });

      queryClient.invalidateQueries({ queryKey: ["current-user"] });
    },
    onError: (error: any) => {
      toast.error("Error", {
        description: `${error.message || "Unknown error. Please try again."}`,
        position: "top-center",
      });
    },
  });
}
