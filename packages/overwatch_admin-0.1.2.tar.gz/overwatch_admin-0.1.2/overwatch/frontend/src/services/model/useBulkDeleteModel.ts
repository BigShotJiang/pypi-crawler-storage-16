import { modelApi } from "@/api";
import { toast } from "@medusajs/ui";
import { useMutation, useQueryClient } from "@tanstack/react-query";

export function useBulkDeleteModel(name: string) {
  const queryClient = useQueryClient();

  const deleted = useMutation({
    mutationFn: (ids: number[]) => modelApi.bulkDelete(name, ids),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["model-list", name] });

      toast.success("Success", {
        description: `Successfully deleted ${
          deleted.variables?.length || 0
        } item(s)!`,
      });
    },
    onError: (error: any) => {
      toast.error("Error", {
        description: `${error.message || "Unknown error"}`,
      });
    },
  });

  return deleted;
}
