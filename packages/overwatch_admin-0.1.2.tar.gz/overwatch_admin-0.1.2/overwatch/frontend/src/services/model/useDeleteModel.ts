import { modelApi } from "@/api";
import { toast } from "@medusajs/ui";
import { useMutation, useQueryClient } from "@tanstack/react-query";

export function useDeleteModel(name: string) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (id: string) => modelApi.deleteModelItem(name, id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["model-list", name] });

      toast.success("Success", {
        description: "Item successfully deleted!",
      });
    },
    onError: (error: any) => {
      toast.error("Error", {
        description: `${error.message || "Unknown error"}`,
      });
    },
  });
}
