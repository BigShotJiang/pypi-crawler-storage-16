import { modelApi } from "@/api";
import { useQuery } from "@tanstack/react-query";

export function useModelField(enabled: boolean, name: string) {
  return useQuery({
    queryKey: ["model-field", name],
    queryFn: () => modelApi.getModelFields(name),
    enabled,
  });
}
