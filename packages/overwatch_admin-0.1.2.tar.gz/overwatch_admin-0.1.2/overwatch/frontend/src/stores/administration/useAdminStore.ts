import { useAdministration } from "@/services";
import { AdminSearchRequest, PaginatedAdministration } from "@/types";
import { useEffect } from "react";
import { create } from "zustand";

interface AdminState {
  admin: PaginatedAdministration | null;
  setAdmin: (admin: PaginatedAdministration) => void;
}

export const useAdminStore = create<AdminState>((set) => ({
  admin: null,
  setAdmin: (admin) => {
    set({
      admin,
    });
  },
}));

export function useHydratedAdmin(params?: AdminSearchRequest) {
  const setAdmin = useAdminStore((s) => s.setAdmin);

  const enabled = true;
  const { data, isLoading, error } = useAdministration(enabled, params);

  useEffect(() => {
    if (data) {
      setAdmin(data);
    }
  }, [data, setAdmin]);

  return { isLoading, error };
}
