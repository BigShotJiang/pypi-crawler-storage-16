import { AuthResponse, User } from "@/types";
import { create } from "zustand";
import { persist } from "zustand/middleware";

interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  error: string | null;
  lastActivity: number;
  setLogin: (res: AuthResponse) => void;
  setLogout: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      token: null,
      shouldRedirect: false,
      isAuthenticating: false,
      isAuthenticated: false,
      error: null,
      lastActivity: Date.now(),
      setLogin: (response: AuthResponse) => {
        set({
          user: response.user,
          token: response.access_token,
          isAuthenticated: true,
          error: null,
          lastActivity: Date.now(),
        });
      },
      setLogout: () => {
        set({
          user: null,
          token: null,
          isAuthenticated: false,
          error: null,
          lastActivity: Date.now(),
        });
      },
    }),
    {
      name: "auth-store",
      partialize: (state) => ({
        user: state.user,
        token: state.token,
        isAuthenticated: state.isAuthenticated,
        lastActivity: state.lastActivity,
      }),
    }
  )
);
