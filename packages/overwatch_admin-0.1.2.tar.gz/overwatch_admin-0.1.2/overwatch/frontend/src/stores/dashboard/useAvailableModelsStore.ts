import { useAvailableModels } from "@/services";
import { useEffect } from "react";
import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";

export type Model = { name: string; label: string; count: number };

interface ModelState {
  availableModels: Model[];
  selectedModel: Model | null;
  setAvailableModels: (models: Model[]) => void;
  setSelectedModel: (model: Model | null) => void;
}

export const useAvailableModelsModelStore = create<ModelState>()(
  persist(
    (set) => ({
      availableModels: [],
      selectedModel: null,
      setAvailableModels: (models) => {
        set({
          availableModels: models,
        });
      },
      setSelectedModel: (model) => {
        set({
          selectedModel: model,
        });
      },
    }),
    {
      name: "model-store",
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({ selectedModel: state.selectedModel }),
    }
  )
);

export function useHydratedAvailableModels() {
  const models = useAvailableModelsModelStore((s) => s.availableModels);
  const setAvailableModels = useAvailableModelsModelStore(
    (s) => s.setAvailableModels
  );

  const enabled = models.length == 0;
  const { data, isLoading, error } = useAvailableModels(enabled);

  useEffect(() => {
    if (data) {
      setAvailableModels(data);
    }
  }, [data, setAvailableModels]);

  return { isLoading, error };
}
