import { useRecentActivity } from "@/services";
import { RecentActivity } from "@/types";
import { useEffect } from "react";
import { create } from "zustand";

interface RecentActivityState {
  recentActivities: RecentActivity[];
  setRecentActivity: (recentActivities: RecentActivity[]) => void;
}

export const useRecentActivityStore = create<RecentActivityState>((set) => ({
  recentActivities: [],
  setRecentActivity: (recentActivities) => {
    set({
      recentActivities,
    });
  },
}));

export function useHydratedRecentActivity() {
  const recentActivities = useRecentActivityStore((d) => d.recentActivities);
  const setRecentActivity = useRecentActivityStore((s) => s.setRecentActivity);

  const enabled = recentActivities.length == 0;
  const { data, isLoading, error } = useRecentActivity(enabled);

  useEffect(() => {
    if (data) {
      setRecentActivity(data);
    }
  }, [data, setRecentActivity]);

  return { isLoading, error };
}
