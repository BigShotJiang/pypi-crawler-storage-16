import { useModelField } from "@/services";
import { ModelConfig } from "@/types";
import { useEffect } from "react";
import { create } from "zustand";

interface ModelFieldState {
  modelField?: ModelConfig;
  setModelField: (modelField: ModelConfig) => void;
}

export const useModelFieldStore = create<ModelFieldState>((set) => ({
  modelField: undefined,
  setModelField: (modelField) => {
    set({
      modelField: modelField,
    });
  },
}));

export function useHydratedModelField(name: string) {
  const setModelField = useModelFieldStore((s) => s.setModelField);

  const { data, isLoading, error, refetch } = useModelField(true, name);

  useEffect(() => {
    if (data) {
      setModelField(data);
    }
  }, [data, setModelField]);

  return { isLoading, error, refetch };
}
