import { useEffect } from "react";
import { create } from "zustand";

interface Header {
  title: string;
  subtitle: string;
}

interface HeaderState {
  header: Header;
  setHeader: (header: Header) => void;
}

export const useHeaderStore = create<HeaderState>((set) => ({
  header: {
    title: "Overwatch Admin",
    subtitle: "Overwatch Admin Panel",
  },
  setHeader: (header) => {
    set({
      header,
    });
  },
}));

export function useHydratedHeader(title: string, subtitle: string) {
  const setHeader = useHeaderStore((s) => s.setHeader);

  useEffect(() => {
    setHeader({
      title,
      subtitle,
    });
  }, [title, subtitle]);

  return { title, subtitle };
}
