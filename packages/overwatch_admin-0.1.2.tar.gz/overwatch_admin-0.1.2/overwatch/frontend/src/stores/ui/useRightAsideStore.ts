import { create } from "zustand";
import { devtools } from "zustand/middleware";
import React from "react";

export interface RightAsideConfig {
  isOpen: boolean;
  title: string;
  content: React.ReactNode | null;
  contentClassName?: string;
}

interface RightAsideState {
  config: RightAsideConfig;

  // Actions
  openRightAside: (
    title: string,
    content: React.ReactNode,
    contentClassName?: string
  ) => void;
  closeRightAside: () => void;
  setRightAsideContent: (
    title: string,
    content: React.ReactNode,
    contentClassName?: string
  ) => void;
  toggleRightAside: () => void;
}

export const useRightAsideStore = create<RightAsideState>()(
  devtools(
    (set, get) => ({
      config: {
        isOpen: false,
        title: "Settings & Tools",
        content: null,
      },

      openRightAside: (
        title: string,
        content: React.ReactNode,
        contentClassName?: string
      ) => {
        set({
          config: {
            isOpen: true,
            title,
            content,
            contentClassName,
          },
        });
      },

      closeRightAside: () => {
        set({
          config: {
            ...get().config,
            isOpen: false,
          },
        });
      },

      setRightAsideContent: (
        title: string,
        content: React.ReactNode,
        contentClassName?: string
      ) => {
        set({
          config: {
            ...get().config,
            title,
            content,
            contentClassName,
          },
        });
      },

      toggleRightAside: () => {
        set((state) => ({
          config: {
            ...state.config,
            isOpen: !state.config.isOpen,
          },
        }));
      },
    }),
    {
      name: "right-aside-store",
    }
  )
);

export const useRightAside = () => {
  const store = useRightAsideStore();

  return {
    isOpen: store.config.isOpen,
    title: store.config.title,
    content: store.config.content,
    contentClassName: store.config.contentClassName,
    openRightAside: store.openRightAside,
    closeRightAside: store.closeRightAside,
    setRightAsideContent: store.setRightAsideContent,
    toggleRightAside: store.toggleRightAside,
  };
};
