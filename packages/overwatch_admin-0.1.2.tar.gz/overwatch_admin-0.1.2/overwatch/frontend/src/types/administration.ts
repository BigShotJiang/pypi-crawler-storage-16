export interface UserSettings {
  username: string;
  email: string;
  first_name: string;
  last_name: string;
}

export interface NotificationSettingsType {
  email_notifications: boolean;
  push_notifications: boolean;
  audit_notifications: boolean;
}

export interface SecuritySettingsType {
  current_password: string;
  new_password: string;
  confirm_password: string;
  two_factor_enabled: boolean;
}

export enum AdminRole {
  SUPER_ADMIN = "super_admin",
  ADMIN = "admin",
  READ_ONLY = "read_only",
}

export enum AdminStatus {
  ACTIVE = "active",
  INACTIVE = "inactive",
  SUSPENDED = "suspended",
}

export interface Administration {
  id: number;
  username: string;
  email: string | null;
  first_name: string | null;
  last_name: string | null;
  role: AdminRole;
  status: AdminStatus;
  is_active: boolean;
  is_verified: boolean;
  last_login: string | null;
  created_at: string;
  updated_at: string;
}

export interface AdminSearchRequest {
  search?: string;
  role?: AdminRole;
  is_active?: boolean;
  page?: number;
  per_page?: number;
}

export interface PaginatedAdministration {
  items: Administration[];
  total: number;
  page: number;
  per_page: number;
  pages: number;
}

export interface AdminStats {
  total_admins: number;
  active_admins: number;
  inactive_admins: number;
  suspended_admins: number;
  super_admins: number;
  admins: number;
  read_only_admins: number;
}

export interface AdminPasswordChange {
  new_password: string;
  confirm_password?: string;
}
