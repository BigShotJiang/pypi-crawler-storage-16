export * from "./dashboard";
export * from "./audit";
export * from "./administration";

export interface ModelFilters {
  search?: string;
  field?: string;
  field_type?: string;
  date_from?: string;
  date_to?: string;
  sort_by?: string;
  sort_direction?: "asc" | "desc";
}

// Authentication Types
export interface User {
  id: string;
  username: string;
  email: string;
  role: "super_admin" | "admin" | "read_only";
  first_name: string;
  last_name: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

export interface LoginCredentials {
  username: string;
  password: string;
}

export interface AuthResponse {
  access_token: string;
  refresh_token: string;
  token_type: string;
  expires_in: number;
  user: User;
}

// API Response Types
export interface ApiResponse<T = any> {
  data: T;
  message?: string;
  success: boolean;
}

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  per_page: number;
  pages: number;
}

// Model Types
export interface ModelItem {
  id: string;
  [key: string]: any;
}

export interface ModelListResponse {
  items: ModelItem[];
  total: number;
  page: number;
  per_page: number;
  pages: number;
  metadata: ModelMetadata;
}

export interface ListParams {
  page?: number;
  per_page?: number;
  search?: string;
  sort_by?: string;
  sort_direction?: "asc" | "desc";
  [key: string]: any; // For custom filters
}

export interface BulkOperationResponse {
  success: boolean;
  message: string;
  processed: number;
  failed?: number;
  errors?: string[];
}

export interface ModelField {
  name: string;
  type:
    | "integer"
    | "number"
    | "date"
    | "string"
    | "boolean"
    | "datetime"
    | "time"
    | "select"
    | "float"
    | "text"
    | "email"
    | "password"
    | "textarea"
    | "object"
    | "json";
  label: string;
  choices?: Array<string>;
  python_type: "int" | "str" | "bool";
  readonly?: boolean;
  nullable: boolean;
  primary_key: boolean;
  foreign_key: boolean;
  unique: boolean | null;
  default: string | boolean | null;
  max_length: number | null;
  model_name?: string;
}

export interface ModelRelationship {
  name: string;
  direction: "MANYTOONE" | "ONETOMANY" | "MANYTOMANY";
  is_collection: boolean;
  target_model: string;
  back_populates?: string;
  foreign_keys: string[];
}

export interface ModelMetadata {
  name: string;
  table_name: string;
  fields: Record<string, ModelField>;
  relationships: Record<string, ModelRelationship>;
  primary_key_fields: string[];
  foreign_key_fields: string[];
  listable_fields: string[];
  searchable_fields: string[];
}

export interface ModelConfig {
  name: string;
  table_name: string;
  label: string;
  plural_label: string;
  fields: Record<string, ModelField>;
  relationships?: Record<string, ModelRelationship>;
  primary_key_fields: string[];
  foreign_key_fields: string[];
  list_fields: string[];
  listable_fields?: string[];
  search_fields: string[];
  searchable_fields?: string[];
  exclude_fields?: string[];
  readonly_fields?: string[];
  per_page?: number;
  order_by?: string;
  permissions?: {
    read?: string;
    write?: string;
    delete?: string;
  };
  custom_actions?: CustomAction[];
}

export interface CustomAction {
  name: string;
  label: string;
  action: "POST" | "PUT" | "DELETE";
  url: string;
  icon?: string;
  confirm_message?: string;
}

// CRUD Types
export interface CrudItem {
  [key: string]: any;
}

export interface CreateUpdateData {
  [key: string]: any;
}

export interface BulkOperation {
  item_ids: string[];
  updates?: Partial<CrudItem>;
}

export interface FilterConfig {
  field: string;
  operator:
    | "eq"
    | "ne"
    | "gt"
    | "gte"
    | "lt"
    | "lte"
    | "in"
    | "contains"
    | "icontains";
  value: any;
}

export interface SortConfig {
  field: string;
  direction: "asc" | "desc";
}

export interface ModelStats {
  name: string;
  count: number;
  recent_changes: number;
}

// UI Component Types
export interface TableColumn {
  key: string;
  title: string;
  dataIndex: string;
  sortable?: boolean;
  filterable?: boolean;
  render?: (value: any, record: any) => React.ReactNode;
  width?: string | number;
}

export interface TableAction {
  key: string;
  label: string;
  icon?: React.ReactNode;
  onClick: (record: any) => void;
  danger?: boolean;
}

export interface SearchState {
  query: string;
  filters: FilterConfig[];
  sort: SortConfig | null;
  page: number;
  per_page: number;
}

// Config Types
export interface OverwatchConfig {
  admin_title: string;
  per_page: number;
  enable_audit_log: boolean;
  enable_dashboard: boolean;
  cors_origins: string[];
}

export interface PublicConfig {
  admin_title: string;
  logo_url?: string;
  favicon_url?: string;
  overwatch_theme_primary_color?: string;
  overwatch_theme_secondary_color?: string;
  overwatch_theme_mode?: string;
}

// Export Types
export type ExportFormat = "csv" | "json" | "xlsx";

export interface ExportOptions {
  format: ExportFormat;
  fields?: string[];
  filters?: FilterConfig[];
}

// Form Types
export interface FormField {
  name: string;
  label: string;
  type:
    | "text"
    | "email"
    | "password"
    | "number"
    | "select"
    | "textarea"
    | "checkbox"
    | "date"
    | "datetime";
  required?: boolean;
  placeholder?: string;
  options?: Array<{ value: any; label: string }>;
  validation?: {
    min?: number;
    max?: number;
    pattern?: string;
    custom?: (value: any) => string | undefined;
  };
}

export interface FormData {
  [key: string]: any;
}

export interface FormErrors {
  [key: string]: string | undefined;
}

// User Settings Types
export interface UserSettings {
  username: string;
  email: string;
  first_name: string;
  last_name: string;
}

export interface SecuritySettingsType {
  current_password: string;
  new_password: string;
  confirm_password: string;
  two_factor_enabled: boolean;
}

// Navigation Types
export interface NavItem {
  key: string;
  label: string;
  name: string;
  count: number;
  path: string;
  icon?: React.ReactNode;
  children?: NavItem[];
  badge?: string | number;
}

// Utility Types
export type Optional<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;
export type RequiredBy<T, K extends keyof T> = T & Required<Pick<T, K>>;
