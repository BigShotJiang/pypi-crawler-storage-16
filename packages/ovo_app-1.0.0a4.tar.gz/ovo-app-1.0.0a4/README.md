# ⚠️⚠️⚠️ Summary ⚠️⚠️⚠️

⚠️⚠️⚠️ The **`ovo-app` PyPI package is now released directly under `ovo`** ⚠️⚠️⚠️

Please use `pip install ovo` rather than `pip install ovo-app`

https://pypi.org/project/ovo