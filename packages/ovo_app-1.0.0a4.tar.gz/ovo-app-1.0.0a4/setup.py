import os
import sys

from setuptools import setup


with open("README.md", encoding="utf-8") as f:
    LONG_DESCRIPTION = f.read()


def likely_error():
    error_message = "\n".join(
        [
            "================================================",
            "The OVO de novo protein design ecosystem ",
            "is now released directly under 'ovo' on PyPI.",
            "",
            "Please uninstall 'ovo-app' and install 'ovo' instead.",
            "",
            "When using pip, first run 'pip uninstall ovo-app',",
            "then run 'pip install ovo'.",
            "",
            "For more information, visit https://pypi.org/project/ovo/",
            "================================================",
        ]
    )

    raise SystemExit(error_message)


if __name__ == "__main__":
    # Allow 'python setup.py sdist' to work for distribution purposes
    sdist_mode = len(sys.argv) == 2 and sys.argv[1] == "sdist"

    if not sdist_mode:
        likely_error()

    setup(
        description="Deprecated ovo-app package, use ovo instead",
        long_description=LONG_DESCRIPTION,
        long_description_content_type="text/markdown",
        name="ovo-app",
        version="1.0.0-alpha.4",
    )

