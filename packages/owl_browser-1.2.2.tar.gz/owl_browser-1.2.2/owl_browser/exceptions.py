"""
Owl Browser SDK Exceptions.

Custom exception classes for better error handling and reporting.
"""

from typing import Optional


class OwlBrowserError(Exception):
    """Base exception for all Owl Browser SDK errors."""
    pass


class LicenseError(OwlBrowserError):
    """
    Raised when the browser fails due to license issues.

    This can happen when:
    - No license file is installed
    - The license has expired
    - The license signature is invalid
    - Hardware mismatch for hardware-bound licenses
    - Maximum seats exceeded
    - Subscription validation failed

    Attributes:
        status: The license status code (e.g., 'not_found', 'expired', 'invalid_signature')
        message: Human-readable error message
        fingerprint: Hardware fingerprint (if available) for requesting a new license
    """

    # License status codes
    NOT_FOUND = "not_found"
    EXPIRED = "expired"
    INVALID_SIGNATURE = "invalid_signature"
    CORRUPTED = "corrupted"
    HARDWARE_MISMATCH = "hardware_mismatch"
    TAMPERED = "tampered"
    DEBUG_DETECTED = "debug_detected"
    CLOCK_MANIPULATED = "clock_manipulated"
    SUBSCRIPTION_INACTIVE = "subscription_inactive"
    SUBSCRIPTION_CHECK_FAILED = "subscription_check_failed"
    SEAT_EXCEEDED = "seat_exceeded"

    def __init__(
        self,
        message: str,
        status: Optional[str] = None,
        fingerprint: Optional[str] = None
    ):
        self.status = status
        self.message = message
        self.fingerprint = fingerprint
        super().__init__(self._format_message())

    def _format_message(self) -> str:
        """Format the exception message with helpful information."""
        lines = [f"License Error: {self.message}"]

        if self.status:
            lines.append(f"Status: {self.status}")

        if self.fingerprint:
            lines.append(f"Hardware Fingerprint: {self.fingerprint}")

        # Add helpful instructions based on status
        if self.status == self.NOT_FOUND:
            lines.append("")
            lines.append("To activate a license, run:")
            lines.append("  owl_browser --license add /path/to/license.olic")
            lines.append("")
            lines.append("Contact support@owlbrowser.net for licensing inquiries.")
        elif self.status == self.EXPIRED:
            lines.append("")
            lines.append("Please renew your license at https://owlbrowser.net")
            lines.append("Contact support@owlbrowser.net for assistance.")
        elif self.status == self.SEAT_EXCEEDED:
            lines.append("")
            lines.append("Maximum number of devices reached for this license.")
            lines.append("Deactivate unused devices or upgrade your license.")
            lines.append("Contact support@owlbrowser.net for assistance.")
        elif self.status == self.SUBSCRIPTION_CHECK_FAILED:
            lines.append("")
            lines.append("Could not validate subscription with license server.")
            lines.append("Check your internet connection or contact support@owlbrowser.net")

        return "\n".join(lines)


class BrowserInitializationError(OwlBrowserError):
    """Raised when the browser process fails to initialize."""
    pass


class BrowserNotRunningError(OwlBrowserError):
    """Raised when trying to use a browser that is not running."""
    pass


class CommandTimeoutError(OwlBrowserError):
    """Raised when a browser command times out."""
    pass


class ContextError(OwlBrowserError):
    """Raised when there's an error with browser context operations."""
    pass


class NavigationError(OwlBrowserError):
    """Raised when page navigation fails."""
    pass


class ElementNotFoundError(OwlBrowserError):
    """Raised when an element cannot be found on the page."""
    pass


class AuthenticationError(OwlBrowserError):
    """
    Raised when authentication fails (401 Unauthorized).

    This can happen when:
    - The bearer token is invalid or missing
    - The JWT token has expired
    - The JWT token signature is invalid
    - The JWT token was issued for a different audience

    Attributes:
        message: Human-readable error message
        reason: Optional specific reason for the failure
        status_code: HTTP status code (always 401)
    """

    def __init__(self, message: str, reason: Optional[str] = None):
        self.message = message
        self.reason = reason
        self.status_code = 401
        super().__init__(self._format_message())

    def _format_message(self) -> str:
        """Format the exception message with helpful information."""
        lines = [f"Authentication Error: {self.message}"]

        if self.reason:
            lines.append(f"Reason: {self.reason}")

        lines.append("")
        lines.append("Possible causes:")
        lines.append("  - Invalid or expired bearer token")
        lines.append("  - JWT token has expired (check exp claim)")
        lines.append("  - JWT signature verification failed")
        lines.append("  - Token issued for different audience (aud claim mismatch)")
        lines.append("")
        lines.append("For JWT authentication, ensure your token:")
        lines.append("  - Has not expired (exp > current time)")
        lines.append("  - Is signed with the correct private key")
        lines.append("  - Has matching issuer (iss) and audience (aud) claims")

        return "\n".join(lines)


class RateLimitError(OwlBrowserError):
    """
    Raised when the client is rate limited (429 Too Many Requests).

    The server implements rate limiting to prevent abuse. When this error
    is raised, the client should wait before retrying.

    Attributes:
        message: Human-readable error message
        retry_after: Number of seconds to wait before retrying
        limit: Maximum requests allowed per window
        remaining: Remaining requests in current window
        status_code: HTTP status code (always 429)
    """

    def __init__(
        self,
        message: str,
        retry_after: int,
        limit: Optional[int] = None,
        remaining: Optional[int] = None
    ):
        self.message = message
        self.retry_after = retry_after
        self.limit = limit
        self.remaining = remaining
        self.status_code = 429
        super().__init__(self._format_message())

    def _format_message(self) -> str:
        """Format the exception message with helpful information."""
        lines = [f"Rate Limit Error: {self.message}"]

        lines.append(f"Retry After: {self.retry_after} seconds")

        if self.limit is not None:
            lines.append(f"Rate Limit: {self.limit} requests per window")

        if self.remaining is not None:
            lines.append(f"Remaining: {self.remaining}")

        lines.append("")
        lines.append("To avoid rate limiting:")
        lines.append("  - Reduce request frequency")
        lines.append("  - Implement exponential backoff")
        lines.append("  - Contact support for higher limits")

        return "\n".join(lines)


class IPBlockedError(OwlBrowserError):
    """
    Raised when the client IP is blacklisted/not whitelisted (403 Forbidden).

    The server may implement IP-based access control. When this error
    is raised, the client's IP is not allowed to access the server.

    Attributes:
        message: Human-readable error message
        ip_address: The blocked IP address (if known)
        status_code: HTTP status code (always 403)
    """

    def __init__(self, message: str, ip_address: Optional[str] = None):
        self.message = message
        self.ip_address = ip_address
        self.status_code = 403
        super().__init__(self._format_message())

    def _format_message(self) -> str:
        """Format the exception message with helpful information."""
        lines = [f"IP Blocked Error: {self.message}"]

        if self.ip_address:
            lines.append(f"Your IP: {self.ip_address}")

        lines.append("")
        lines.append("Your IP address is not allowed to access this server.")
        lines.append("")
        lines.append("Possible causes:")
        lines.append("  - IP whitelist is enabled and your IP is not whitelisted")
        lines.append("  - Your IP has been blocked due to suspicious activity")
        lines.append("")
        lines.append("To resolve:")
        lines.append("  - Contact the server administrator")
        lines.append("  - Request your IP to be added to the whitelist")

        return "\n".join(lines)
