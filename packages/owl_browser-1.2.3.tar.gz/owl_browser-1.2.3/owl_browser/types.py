"""
Type definitions for Owl Browser SDK.

This module contains all type definitions, dataclasses, and enums
used throughout the SDK.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, List, Dict, Any, Union, Literal


# ==================== ENUMS ====================

class CleanLevel(str, Enum):
    """HTML cleaning levels for getHTML()"""
    MINIMAL = "minimal"
    BASIC = "basic"
    AGGRESSIVE = "aggressive"


class CookieSameSite(str, Enum):
    """SameSite cookie attribute"""
    UNSPECIFIED = "unspecified"
    NONE = "none"
    LAX = "lax"
    STRICT = "strict"


class ProxyType(str, Enum):
    """Proxy protocol types"""
    HTTP = "http"
    HTTPS = "https"
    SOCKS4 = "socks4"
    SOCKS5 = "socks5"
    SOCKS5H = "socks5h"  # SOCKS5 with remote DNS resolution (recommended for stealth)


class LLMStatus(str, Enum):
    """LLM availability status"""
    READY = "ready"
    LOADING = "loading"
    UNAVAILABLE = "unavailable"


class KeyName(str, Enum):
    """Special key names for press_key()"""
    ENTER = "Enter"
    RETURN = "Return"
    TAB = "Tab"
    ESCAPE = "Escape"
    ESC = "Esc"
    BACKSPACE = "Backspace"
    DELETE = "Delete"
    DEL = "Del"
    ARROW_UP = "ArrowUp"
    UP = "Up"
    ARROW_DOWN = "ArrowDown"
    DOWN = "Down"
    ARROW_LEFT = "ArrowLeft"
    LEFT = "Left"
    ARROW_RIGHT = "ArrowRight"
    RIGHT = "Right"
    SPACE = "Space"
    HOME = "Home"
    END = "End"
    PAGE_UP = "PageUp"
    PAGE_DOWN = "PageDown"


class ExtractionTemplate(str, Enum):
    """JSON extraction templates"""
    GOOGLE_SEARCH = "google_search"
    WIKIPEDIA = "wikipedia"
    AMAZON_PRODUCT = "amazon_product"
    GITHUB_REPO = "github_repo"
    TWITTER_FEED = "twitter_feed"
    REDDIT_THREAD = "reddit_thread"
    AUTO = ""  # Auto-detect


class CaptchaProvider(str, Enum):
    """CAPTCHA provider types for image CAPTCHA solving"""
    AUTO = "auto"  # Auto-detect provider based on page analysis
    OWL = "owl"  # Owl Browser's internal test CAPTCHA
    RECAPTCHA = "recaptcha"  # Google reCAPTCHA v2 image challenges
    CLOUDFLARE = "cloudflare"  # Cloudflare Turnstile/hCaptcha
    HCAPTCHA = "hcaptcha"  # hCaptcha standalone


# ==================== DATA CLASSES ====================

@dataclass
class Viewport:
    """Viewport size configuration"""
    width: int
    height: int


@dataclass
class PageInfo:
    """Page information"""
    url: str
    title: str
    can_go_back: bool = False
    can_go_forward: bool = False


@dataclass
class ElementMatch:
    """Element match result from semantic matching"""
    selector: str
    confidence: float
    tag: str
    text: Optional[str] = None
    x: int = 0
    y: int = 0
    width: int = 0
    height: int = 0


@dataclass
class Cookie:
    """Cookie object"""
    name: str
    value: str
    domain: str
    path: str
    secure: bool = False
    http_only: bool = False
    same_site: CookieSameSite = CookieSameSite.LAX
    expires: int = -1  # Unix epoch or -1 for session cookie


@dataclass
class VideoStats:
    """Video recording statistics"""
    frames: int
    duration: float
    is_recording: bool
    is_paused: bool


@dataclass
class DateTimeInfo:
    """Date and time information"""
    current: str  # ISO 8601 format
    date: str  # YYYY-MM-DD
    time: str  # HH:MM:SS
    day_of_week: str
    timezone: str
    timezone_offset: str
    unix_timestamp: int


@dataclass
class LocationInfo:
    """Geographic location information"""
    success: bool
    ip: Optional[str] = None
    city: Optional[str] = None
    region: Optional[str] = None
    country: Optional[str] = None
    country_code: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    timezone: Optional[str] = None
    error: Optional[str] = None


@dataclass
class WeatherInfo:
    """Weather information"""
    success: bool
    condition: Optional[str] = None
    description: Optional[str] = None
    temperature_c: Optional[float] = None
    temperature_f: Optional[float] = None
    humidity: Optional[int] = None
    wind_speed_kmh: Optional[float] = None
    wind_speed_mph: Optional[float] = None
    error: Optional[str] = None


@dataclass
class DemographicsInfo:
    """Complete demographics information"""
    datetime: DateTimeInfo
    location: Optional[LocationInfo] = None
    weather: Optional[WeatherInfo] = None


@dataclass
class CaptchaDetectionResult:
    """CAPTCHA detection result"""
    detected: bool
    confidence: float
    type: Optional[str] = None
    selectors: Optional[Dict[str, str]] = None


@dataclass
class CaptchaSolveResult:
    """CAPTCHA solve result"""
    success: bool
    attempts: int
    message: Optional[str] = None
    extracted_text: Optional[str] = None
    provider: Optional[str] = None  # Provider that was used (for image CAPTCHAs)


# ==================== CONFIGURATION CLASSES ====================

@dataclass
class ProxyConfig:
    """Proxy configuration"""
    type: ProxyType
    host: str
    port: int
    username: Optional[str] = None
    password: Optional[str] = None
    stealth: bool = True  # Block WebRTC leaks and other detection vectors
    block_webrtc: bool = True
    spoof_timezone: bool = False
    spoof_language: bool = False
    timezone_override: Optional[str] = None  # e.g., "America/New_York"
    language_override: Optional[str] = None  # e.g., "en-US"
    ca_cert_path: Optional[str] = None  # For SSL interception proxies
    trust_custom_ca: bool = False


@dataclass
class ProxyStatus:
    """Proxy status response"""
    enabled: bool
    connected: bool
    type: Optional[ProxyType] = None
    host: Optional[str] = None
    port: Optional[int] = None
    stealth: Optional[bool] = None
    block_webrtc: Optional[bool] = None


@dataclass
class LLMConfig:
    """LLM configuration"""
    enabled: bool = True
    use_builtin: bool = True
    endpoint: Optional[str] = None  # External LLM API endpoint
    model: Optional[str] = None  # External LLM model name
    api_key: Optional[str] = None


@dataclass
class ContextOptions:
    """Context creation options"""
    llm: Optional[LLMConfig] = None
    proxy: Optional[ProxyConfig] = None
    profile_path: Optional[str] = None  # Path to browser profile JSON file


@dataclass
class BrowserConfig:
    """Browser configuration"""
    browser_path: Optional[str] = None  # Auto-detected if not provided
    headless: bool = True
    verbose: bool = False
    init_timeout: int = 30000  # milliseconds


@dataclass
class MarkdownOptions:
    """Markdown extraction options"""
    include_links: bool = True
    include_images: bool = True
    max_length: int = -1  # -1 for no limit


@dataclass
class VideoRecordingOptions:
    """Video recording options"""
    fps: int = 30
    codec: str = "libx264"


@dataclass
class SetCookieOptions:
    """Options for setting a cookie"""
    domain: Optional[str] = None
    path: str = "/"
    secure: bool = False
    http_only: bool = False
    same_site: CookieSameSite = CookieSameSite.LAX
    expires: int = -1  # Unix epoch or -1 for session cookie


@dataclass
class ScreenshotOptions:
    """Screenshot options"""
    path: Optional[str] = None  # If provided, save to file
    format: str = "png"
    quality: int = 80  # For JPEG


@dataclass
class WaitOptions:
    """Wait options"""
    timeout: int = 5000  # milliseconds
    visible: bool = False


# ==================== TEST TYPES ====================

@dataclass
class TestStep:
    """Test step from Developer Playground JSON export"""
    type: str  # navigate, click, type, pick, wait, screenshot, etc.
    selected: bool = True
    url: Optional[str] = None
    selector: Optional[str] = None
    text: Optional[str] = None
    value: Optional[str] = None
    duration: Optional[int] = None
    filename: Optional[str] = None
    query: Optional[str] = None
    command: Optional[str] = None
    fps: Optional[int] = None


@dataclass
class TestTemplate:
    """Test template from Developer Playground JSON export"""
    name: str
    steps: List[TestStep]
    description: Optional[str] = None


@dataclass
class TestExecutionOptions:
    """Test execution options"""
    continue_on_error: bool = False
    screenshot_on_error: bool = True
    verbose: bool = False


@dataclass
class TestError:
    """Test step error"""
    step: int
    type: str
    message: str


@dataclass
class TestExecutionResult:
    """Test execution result"""
    test_name: str
    total_steps: int
    executed_steps: int
    successful_steps: int
    failed_steps: int
    execution_time: float  # milliseconds
    success: bool
    errors: List[TestError] = field(default_factory=list)


# ==================== BROWSER PROFILE TYPES ====================

@dataclass
class BrowserFingerprint:
    """Browser fingerprint configuration for consistent identity across sessions."""
    # User Agent and Navigator
    user_agent: str = ""
    platform: str = "Win32"
    vendor: str = "Google Inc."
    languages: List[str] = field(default_factory=lambda: ["en-US", "en"])
    hardware_concurrency: int = 8
    device_memory: int = 8
    max_touch_points: int = 0

    # Canvas fingerprinting
    canvas_noise_seed: float = 0.0

    # WebGL fingerprinting
    gpu_profile_index: int = 0
    webgl_vendor: str = ""
    webgl_renderer: str = ""

    # Screen/Display
    screen_width: int = 1920
    screen_height: int = 1080
    color_depth: int = 24
    pixel_ratio: int = 1

    # Timezone and locale
    timezone: str = ""
    locale: str = "en-US"

    # Audio context
    audio_noise_seed: float = 0.0

    # Font fingerprinting
    installed_fonts: List[str] = field(default_factory=list)

    # Plugin info
    has_pdf_plugin: bool = True
    has_chrome_pdf: bool = True


@dataclass
class BrowserProfile:
    """
    Complete browser profile containing identity fingerprint, cookies, and settings.

    Profiles enable persistent browser identities across sessions, useful for:
    - Maintaining login sessions
    - Consistent fingerprinting for anti-detection
    - Saving/loading browser state
    """
    # Profile metadata
    profile_id: str = ""
    profile_name: str = ""
    created_at: str = ""
    modified_at: str = ""
    version: int = 1

    # Browser fingerprint
    fingerprint: Optional[BrowserFingerprint] = None

    # Cookies
    cookies: List[Cookie] = field(default_factory=list)

    # LLM configuration
    has_llm_config: bool = False
    llm_config: Optional[LLMConfig] = None

    # Proxy configuration
    has_proxy_config: bool = False
    proxy_config: Optional[ProxyConfig] = None

    # Profile settings
    auto_save_cookies: bool = True
    persist_local_storage: bool = True


@dataclass
class ProfileOptions:
    """Options for creating a new profile."""
    name: str = ""
    fingerprint: Optional[BrowserFingerprint] = None


# ==================== CONNECTION MODE ====================

class ConnectionMode(str, Enum):
    """Browser connection mode - local binary or remote HTTP server."""
    LOCAL = "local"   # Connect to local browser binary via stdin/stdout
    REMOTE = "remote"  # Connect to remote HTTP server


class AuthMode(str, Enum):
    """Authentication mode for remote HTTP server."""
    TOKEN = "token"  # Simple bearer token authentication
    JWT = "jwt"      # JWT (JSON Web Token) authentication with RSA signing


class TransportMode(str, Enum):
    """Transport mode for remote connections."""
    HTTP = "http"      # REST API over HTTP (default)
    WEBSOCKET = "websocket"  # WebSocket for real-time communication
    WS = "websocket"   # Alias for WEBSOCKET


@dataclass
class JWTConfig:
    """
    Configuration for JWT authentication with automatic token generation.

    Example:
        ```python
        from owl_browser import Browser, RemoteConfig, JWTConfig, AuthMode

        # Connect with JWT authentication using private key
        browser = Browser(remote=RemoteConfig(
            url="http://192.168.1.100:8080",
            auth_mode=AuthMode.JWT,
            jwt=JWTConfig(
                private_key="/path/to/private.pem",
                expires_in=3600,  # 1 hour
                issuer="my-app"
            )
        ))
        browser.launch()
        ```
    """
    # Path to RSA private key file (PEM format) or the key string itself
    private_key: str

    # Token validity duration in seconds (default: 3600 = 1 hour)
    expires_in: int = 3600

    # Seconds before expiry to auto-refresh token (default: 300 = 5 minutes)
    refresh_threshold: int = 300

    # Issuer claim (iss)
    issuer: Optional[str] = None

    # Subject claim (sub)
    subject: Optional[str] = None

    # Audience claim (aud)
    audience: Optional[str] = None

    # Additional custom claims
    claims: Optional[Dict[str, Any]] = None


@dataclass
class RetryConfig:
    """
    Configuration for retry behavior with exponential backoff.

    Used by HTTP transport for automatic retries on transient failures.

    Example:
        ```python
        from owl_browser import Browser, RemoteConfig, RetryConfig

        browser = Browser(remote=RemoteConfig(
            url="http://192.168.1.100:8080",
            token="your-secret-token",
            retry=RetryConfig(
                max_retries=5,
                initial_delay_ms=200,
                max_delay_ms=15000,
                backoff_multiplier=2.0,
                jitter_factor=0.1
            )
        ))
        ```
    """
    max_retries: int = 3  # Maximum number of retry attempts
    initial_delay_ms: int = 100  # Initial delay in milliseconds
    max_delay_ms: int = 10000  # Maximum delay cap in milliseconds
    backoff_multiplier: float = 2.0  # Multiplier for exponential backoff
    jitter_factor: float = 0.1  # Random jitter factor (0-1)


@dataclass
class ReconnectConfig:
    """
    Configuration for automatic WebSocket reconnection.

    Used by WebSocket transport for auto-reconnection on connection loss.

    Example:
        ```python
        from owl_browser import Browser, RemoteConfig, TransportMode, ReconnectConfig

        browser = Browser(remote=RemoteConfig(
            url="http://192.168.1.100:8080",
            token="your-secret-token",
            transport=TransportMode.WEBSOCKET,
            reconnect=ReconnectConfig(
                enabled=True,
                max_attempts=10,
                initial_delay_ms=500,
                max_delay_ms=60000
            )
        ))
        ```
    """
    enabled: bool = True  # Whether auto-reconnection is enabled
    max_attempts: int = 5  # Maximum reconnection attempts (0 = infinite)
    initial_delay_ms: int = 1000  # Initial delay in milliseconds
    max_delay_ms: int = 30000  # Maximum delay cap in milliseconds
    backoff_multiplier: float = 2.0  # Multiplier for exponential backoff
    jitter_factor: float = 0.1  # Random jitter factor (0-1)


@dataclass
class ConcurrencyConfig:
    """
    Configuration for concurrency limiting.

    Limits the number of concurrent requests to prevent overwhelming the server.

    Example:
        ```python
        from owl_browser import Browser, RemoteConfig, ConcurrencyConfig

        browser = Browser(remote=RemoteConfig(
            url="http://192.168.1.100:8080",
            token="your-secret-token",
            concurrency=ConcurrencyConfig(max_concurrent=20)
        ))
        ```
    """
    max_concurrent: int = 10  # Maximum concurrent requests


@dataclass
class RemoteConfig:
    """
    Configuration for connecting to a remote Owl Browser HTTP server.

    Supports two authentication modes:
    - TOKEN (default): Simple bearer token authentication
    - JWT: JSON Web Token authentication with RSA signing (auto-generated)

    Supports two transport modes:
    - HTTP (default): REST API over HTTP
    - WEBSOCKET: WebSocket for real-time, low-latency communication

    Example (Token mode with HTTP):
        ```python
        from owl_browser import Browser, RemoteConfig

        # Connect with simple token authentication (HTTP REST API)
        browser = Browser(remote=RemoteConfig(
            url="http://192.168.1.100:8080",
            token="your-secret-token"
        ))
        browser.launch()
        ```

    Example (Token mode with WebSocket):
        ```python
        from owl_browser import Browser, RemoteConfig, TransportMode

        # Connect with WebSocket for real-time communication
        browser = Browser(remote=RemoteConfig(
            url="http://192.168.1.100:8080",
            token="your-secret-token",
            transport=TransportMode.WEBSOCKET
        ))
        browser.launch()
        ```

    Example (JWT mode with private key):
        ```python
        from owl_browser import Browser, RemoteConfig, JWTConfig, AuthMode

        # Connect with JWT authentication - SDK generates tokens automatically
        browser = Browser(remote=RemoteConfig(
            url="http://192.168.1.100:8080",
            auth_mode=AuthMode.JWT,
            jwt=JWTConfig(
                private_key="/path/to/private.pem",
                expires_in=3600,
                issuer="my-app"
            )
        ))
        browser.launch()
        ```

    Example (High-performance configuration):
        ```python
        from owl_browser import Browser, RemoteConfig, RetryConfig, ConcurrencyConfig

        # Configure for high-performance concurrent usage
        browser = Browser(remote=RemoteConfig(
            url="http://192.168.1.100:8080",
            token="your-secret-token",
            retry=RetryConfig(max_retries=5, initial_delay_ms=50),
            concurrency=ConcurrencyConfig(max_concurrent=50)
        ))
        browser.launch()
        ```
    """
    url: str  # Base URL of the HTTP server (e.g., "http://localhost:8080")
    token: Optional[str] = None  # Bearer token (required for TOKEN mode)
    auth_mode: AuthMode = AuthMode.TOKEN  # Authentication mode (token or jwt)
    jwt: Optional[JWTConfig] = None  # JWT configuration (required for JWT mode)
    transport: TransportMode = TransportMode.HTTP  # Transport mode (http or websocket)
    timeout: int = 30000  # Request timeout in milliseconds
    verify_ssl: bool = True  # Verify SSL certificates
    retry: Optional[RetryConfig] = None  # Retry configuration for HTTP transport
    reconnect: Optional[ReconnectConfig] = None  # Reconnection config for WebSocket
    concurrency: Optional[ConcurrencyConfig] = None  # Concurrency limiting config

    def __post_init__(self):
        # Normalize URL - remove trailing slash
        self.url = self.url.rstrip('/')

        # Validate configuration
        if self.auth_mode == AuthMode.TOKEN and not self.token:
            raise ValueError("Token is required for TOKEN authentication mode")
        if self.auth_mode == AuthMode.JWT and not self.jwt:
            raise ValueError("JWTConfig is required for JWT authentication mode")


# ==================== NETWORK INTERCEPTION TYPES ====================

class NetworkAction(str, Enum):
    """Network interception action"""
    ALLOW = "allow"
    BLOCK = "block"
    MOCK = "mock"
    REDIRECT = "redirect"


@dataclass
class NetworkRule:
    """Network interception rule configuration."""
    url_pattern: str  # URL pattern to match (glob or regex)
    action: NetworkAction  # Action to take when URL matches
    is_regex: bool = False  # Whether url_pattern is a regex (default: false for glob)
    redirect_url: Optional[str] = None  # URL to redirect to (for redirect action)
    mock_body: Optional[str] = None  # Response body to return (for mock action)
    mock_status: int = 200  # HTTP status code for mock response
    mock_content_type: Optional[str] = None  # Content-Type header for mock response


@dataclass
class NetworkLogEntry:
    """Network log entry."""
    url: str  # Request URL
    method: str  # HTTP method
    status: int  # HTTP status code
    timestamp: int  # Request timestamp
    intercepted: bool  # Whether request was intercepted


# ==================== FILE DOWNLOAD TYPES ====================

class DownloadStatus(str, Enum):
    """Download status"""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    FAILED = "failed"


@dataclass
class DownloadInfo:
    """Download information."""
    id: str  # Download ID
    url: str  # Source URL
    filename: str  # File name
    path: str  # Full path to downloaded file
    status: DownloadStatus  # Download status
    bytes_received: int  # Bytes received so far
    total_bytes: int  # Total bytes (may be -1 if unknown)


# ==================== DIALOG HANDLING TYPES ====================

class DialogType(str, Enum):
    """Dialog type"""
    ALERT = "alert"
    CONFIRM = "confirm"
    PROMPT = "prompt"
    BEFOREUNLOAD = "beforeunload"


class DialogAction(str, Enum):
    """Dialog action"""
    ACCEPT = "accept"
    DISMISS = "dismiss"
    ACCEPT_WITH_TEXT = "accept_with_text"


@dataclass
class DialogInfo:
    """Dialog information."""
    id: str  # Dialog ID
    type: DialogType  # Dialog type
    message: str  # Dialog message
    default_value: Optional[str] = None  # Default value for prompt dialogs


# ==================== TAB/WINDOW MANAGEMENT TYPES ====================

class PopupPolicy(str, Enum):
    """Popup handling policy"""
    ALLOW = "allow"
    BLOCK = "block"
    NEW_TAB = "new_tab"
    BACKGROUND = "background"


@dataclass
class TabInfo:
    """Tab information."""
    tab_id: str  # Tab ID
    url: str  # Current URL
    title: str  # Page title
    active: bool  # Whether this tab is active


# ==================== ELEMENT STATE TYPES ====================

@dataclass
class BoundingBox:
    """Element bounding box (position and size)."""
    x: float  # X coordinate relative to viewport
    y: float  # Y coordinate relative to viewport
    width: float  # Element width in pixels
    height: float  # Element height in pixels


# ==================== FRAME TYPES ====================

@dataclass
class FrameInfo:
    """Frame information."""
    id: str  # Frame identifier
    url: str  # Frame URL
    is_main: bool  # Whether this is the main frame
    name: Optional[str] = None  # Frame name (if set)


# ==================== KEYBOARD TYPES ====================

class ModifierKey(str, Enum):
    """Modifier key for keyboard combinations"""
    CTRL = "ctrl"
    ALT = "alt"
    SHIFT = "shift"
    META = "meta"


# Type aliases for convenience
ContextId = str
SelectorType = Union[str, None]
