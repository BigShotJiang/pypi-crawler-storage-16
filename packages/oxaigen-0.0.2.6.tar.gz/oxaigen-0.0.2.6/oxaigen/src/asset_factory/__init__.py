# -*- coding: utf-8 -*-
from .notebook_asset import define_notebook_as_asset
