```sh
wget -i list.txt
```
