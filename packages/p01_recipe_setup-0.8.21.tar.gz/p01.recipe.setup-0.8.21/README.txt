The p01.recipe.setup recipe provides helper methods for download, install
and configure applications including windows, minsys support. The module
provides the following recipes: cmd, cmmi, copy, copyscript, ctags, download,
fetch, i18n, importchecker, make, mkdir, mkfile, paste, script, scripts,
supervisor, template.
