from .main import start

start()
