from pathlib import Path


package_root = Path(__file__).parent.parent
