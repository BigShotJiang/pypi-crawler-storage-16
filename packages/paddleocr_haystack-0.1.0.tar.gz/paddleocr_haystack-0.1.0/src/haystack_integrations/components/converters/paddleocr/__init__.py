# SPDX-FileCopyrightText: 2025-present deepset GmbH <info@deepset.ai>
#
# SPDX-License-Identifier: Apache-2.0
from .paddleocr_vl_document_converter import PaddleOCRVLDocumentConverter

__all__ = ["PaddleOCRVLDocumentConverter"]
