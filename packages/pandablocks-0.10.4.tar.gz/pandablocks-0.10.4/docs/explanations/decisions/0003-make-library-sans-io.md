# 3. Sans-IO pandABlocks-client

Date: 2021-08-02 (ADR created retroactively)

## Status

Accepted

## Context

Ensure PandABlocks-client works sans-io.

## Decision

We will ensure pandablocks works sans-io `sans-io <sans-io>`.

## Consequences

We have the option to use an asyncio client or a blocking client.
