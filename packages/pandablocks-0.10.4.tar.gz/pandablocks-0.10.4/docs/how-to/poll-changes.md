# How to efficiently poll for changes

Write something about using `*CHANGES` like Malcolm does.
