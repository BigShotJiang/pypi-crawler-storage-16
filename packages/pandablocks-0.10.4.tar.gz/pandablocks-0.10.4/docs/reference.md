# Reference

```{toctree}
:maxdepth: 1
:glob:

reference/*
```

```{toctree}
:maxdepth: 1
:glob:

API <_api/pandablocks>
genindex
Release Notes <https://github.com/PandABlocks/PandABlocks-client/releases>
```
