Code Examples
=============

These examples are included in the docs to illustrate various usages
