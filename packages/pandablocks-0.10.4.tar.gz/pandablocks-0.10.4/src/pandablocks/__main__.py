from pandablocks.cli import cli

# test with:
#     pipenv run python -m pandablocks
if __name__ == "__main__":
    cli()
