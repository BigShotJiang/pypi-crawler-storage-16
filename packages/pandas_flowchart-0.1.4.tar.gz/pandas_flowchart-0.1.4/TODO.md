* [X] Merge trazendo mostrando ambos os box de df previos com seta merging
* [X] Drop/Filter que removem dados criando box dos dados removidos com seta pra fora
* [X] Opcao sem cores no template (temas: minimal, monochrome, grayscale)
* [X] ~~Tentar um mini histograma com seaborn~~ (Mermaid não suporta imagens embutidas - usando ASCII sparklines)
* [X] Tentar o histo/scatter no seaborn so pra versao html do plot
* [X] Criar justfile e checks com pytest/mypy/ruff/black
* [X] Checar se todas operacoes do pandas estao contempladas (adicionado: reset_index, set_index, sample, replace, stack, unstack, explode, clip, nlargest, nsmallest)
