# ``panelini`` Examples <!-- omit in toc -->

## Table of Contents <!-- omit in toc -->

- [Commands](#commands)

## Commands

Run simple editable template example of panel library:

```bash
panel serve examples/editable_template.py --dev --port 5006
```
