"""Configuration package for Sci-Hub CLI."""
