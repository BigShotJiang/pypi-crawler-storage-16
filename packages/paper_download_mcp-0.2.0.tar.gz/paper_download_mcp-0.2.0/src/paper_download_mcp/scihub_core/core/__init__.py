"""Core business logic package for Sci-Hub CLI."""
