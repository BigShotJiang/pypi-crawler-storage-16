APP_NAME = "paper-inbox"
CLI_ENTRY_POINT = "paper-inbox"