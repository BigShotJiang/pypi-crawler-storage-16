# Developer Readme

1. [CLI](./cli.md)

1. [Dependencies](./dependencies.md)
1. [Github Actions](./github.md)
1. [PyPI](./pypi.md)
