parameterizable package
=================

.. automodule:: parameterizable
   :members:
   :undoc-members:
   :show-inheritance:
   :imported-members:
