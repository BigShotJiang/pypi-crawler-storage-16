__version__ = "9.0.2"
USER_AGENT = f"parsedmarc/{__version__}"
