# sage_setup: distribution = sagemath-brial

from sage.all__sagemath_brial import *
