# sage_setup: distribution = sagemath-database-symbolic-data

from sage.all__sagemath_database_symbolic_data import *
