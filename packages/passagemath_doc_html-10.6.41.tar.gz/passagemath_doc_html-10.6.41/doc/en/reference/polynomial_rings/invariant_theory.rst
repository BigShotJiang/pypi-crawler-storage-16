
Classical Invariant Theory
==========================

.. toctree::
   :maxdepth: 1

   sage/rings/invariants/invariant_theory
   sage/rings/invariants/reconstruction

