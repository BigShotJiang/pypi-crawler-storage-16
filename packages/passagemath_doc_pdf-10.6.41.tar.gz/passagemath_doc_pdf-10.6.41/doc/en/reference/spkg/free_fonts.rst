.. _spkg_free_fonts:

free_fonts: a free family of scalable outline fonts
===================================================

Description
-----------

This dummy package represents the GNU free fonts: a free family of scalable
outline fonts, suitable for general use on computers and for desktop
publishing. It is Unicode-encoded for compatibility with all modern operating
systems.

We do not have an SPKG for it. The purpose of this dummy package is to
associate system package lists with it.

License
-------

GNU General Public License GPLv3+

Upstream Contact
----------------

https://www.gnu.org/software/freefont/


Type
----

optional


Dependencies
------------



Version Information
-------------------

See https://repology.org/project/font-freefont/versions, https://repology.org/project/fonts:gnu-freefont/versions, https://repology.org/project/texlive:gnu-freefont/versions

Installation commands
---------------------

.. tab:: Sage distribution:

   This is a dummy package and cannot be installed using the Sage distribution.

.. tab:: Alpine:

   .. CODE-BLOCK:: bash

       $ apk add ttf-freefont

.. tab:: Arch Linux:

   .. CODE-BLOCK:: bash

       $ sudo pacman -S gnu-free-fonts

.. tab:: conda-forge:

   .. CODE-BLOCK:: bash

       $ conda install open-fonts

.. tab:: Debian/Ubuntu:

   .. CODE-BLOCK:: bash

       $ sudo apt-get install fonts-freefont-otf

.. tab:: Fedora/Redhat/CentOS:

   .. CODE-BLOCK:: bash

       $ sudo dnf install gnu-free-mono-fonts gnu-free-sans-fonts \
             gnu-free-serif-fonts texlive-gnu-freefont

.. tab:: FreeBSD:

   .. CODE-BLOCK:: bash

       $ sudo pkg install x11-fonts/freefont-ttf

.. tab:: Gentoo Linux:

   .. CODE-BLOCK:: bash

       $ sudo emerge media-fonts/freefont

.. tab:: MacPorts:

   .. CODE-BLOCK:: bash

       $ sudo port install freefont-ttf

.. tab:: Nixpkgs:

   .. CODE-BLOCK:: bash

       $ nix-env -f \'\<nixpkgs\>\' --install --attr freefont-ttf

.. tab:: OpenBSD:

   install the following packages: fonts/freefont-ttf

.. tab:: openSUSE:

   .. CODE-BLOCK:: bash

       $ sudo zypper install gnu-free-fonts

.. tab:: Void Linux:

   .. CODE-BLOCK:: bash

       $ sudo xbps-install freefont-ttf


If the system package is installed, ``./configure`` will check if it can be used.
