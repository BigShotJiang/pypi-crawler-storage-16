Cellular Automata
=================

.. toctree::
   :maxdepth: 1

   ../sage/dynamics/cellular_automata/catalog

   ../sage/dynamics/cellular_automata/elementary
   ../sage/dynamics/cellular_automata/glca
   ../sage/dynamics/cellular_automata/solitons
