# sage_setup: distribution = sagemath-groups

from sage.all__sagemath_groups import *
