# sage_setup: distribution = sagemath-homfly

from sage.all__sagemath_homfly import *
