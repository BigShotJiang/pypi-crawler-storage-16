# sage_setup: distribution = sagemath-homfly
