# sage_setup: distribution = sagemath-kissat

from sage.all__sagemath_kissat import *
