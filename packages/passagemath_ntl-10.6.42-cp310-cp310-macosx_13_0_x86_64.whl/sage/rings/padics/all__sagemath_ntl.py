# sage_setup: distribution = sagemath-ntl

from sage.rings.padics.all__sagemath_categories import *

from sage.rings.padics.pow_computer_ext import PowComputer_ext_maker
