# sage_setup: distribution = sagemath-plantri

from sage.all__sagemath_plantri import *
