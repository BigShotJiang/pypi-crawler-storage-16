# sage_setup: distribution = sagemath-plot

from sage.all__sagemath_plot import *
