# sage_setup: distribution = sagemath-qepcad
# delvewheel: patch

from sage.all__sagemath_symbolics import *
