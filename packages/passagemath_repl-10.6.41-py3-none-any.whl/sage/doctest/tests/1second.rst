A test taking one second::

    sage: import time
    sage: time.sleep(1)
