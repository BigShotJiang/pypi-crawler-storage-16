We test that random tests are reproducible::

    sage: randint(5, 10)
    9
