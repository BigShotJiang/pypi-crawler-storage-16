Test a simple doctest failure::

    sage: a = 3
    sage: b = 5
    sage: a + b
    8
    sage: a * b
    20
