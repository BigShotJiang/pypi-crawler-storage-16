# sage_setup: distribution = sagemath-sympow

from sage.all__sagemath_sympow import *
