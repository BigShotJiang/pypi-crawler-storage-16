# sage_setup: distribution = sagemath-tachyon

from sage.all__sagemath_tachyon import *
