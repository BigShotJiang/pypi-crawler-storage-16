# Passwordtools

A password creator

### Installation

```bash
pip install passwordtools
```

### Usage

```python
from passwordtools import *
```

### Functions
```python
password("CULLLLLNNNNN")
```

### Key

The function password() has one argument. The key for it is as follows:

C → Special character. Eg: ,.?
L → Lowercase letter. Eg: abc
N → Integer. Eg: 123
U → Uppercase letter. Eg: ABC

Your password will be created according to the rules given. But, you do not *NEED* to give instructions as there are ready ones which it will use otherwise
