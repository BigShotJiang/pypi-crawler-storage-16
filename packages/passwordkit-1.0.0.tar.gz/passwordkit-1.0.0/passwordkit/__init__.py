from random import *
def password(format = "NULLCULNLCLL"):
    """Type the format in the brackets:
    N -> number
    U -> uppercase letter
    L -> lowercase letter
    C -> special character"""
    letters = "abcdefghijklmnopqrstuvwxyz"
    upperletters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    special = "!@#$%^&*()-_+={}[]|\:;\"',.?"
    letters = list(letters)
    upperletters = list(upperletters)
    special = list(special)
    returnpass = ""
    format = list(format.upper())
    for i in format:
        if i == "N":
            returnpass += str(randint(0,9))
        elif i == "U":
            returnpass += choice(upperletters)
        elif i == "L":
            returnpass += choice(letters)
        elif i == "C":
            returnpass += choice(special)
    return returnpass
