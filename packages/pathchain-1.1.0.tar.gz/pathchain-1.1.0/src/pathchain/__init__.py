# -*- coding: utf-8 -*-
__version__ = "1.1.0"

from .path import Path