

# 1.1.0

Fixes:
  - print settings to stdout when `log_conf_on_startup` is `True`

Improvements:
  - added an optional `logger` to `PABaseSettings.load()`
  
# 1.0.1
	
Fixes:
  - set settings logger level to INFO
