####
__title__ = 'pawnlib'
__description__ = 'pawnlib is a collection of libraries for IaC.'
__url__ = 'https://github.com/jinwoo-j/pawnlib'
__version__ = '2.1.41'
__author__ = 'Jinwoo Jeong'
__author_email__ = 'jinwoo@parametacorp.com'
__license__ = 'MIT'
__copyright__ = 'Copyright 2022 JINWOO'
