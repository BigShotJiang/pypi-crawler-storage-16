"""PawnStack 패키지 메인 엔트리포인트"""

from pawnstack.cli.main import main

if __name__ == "__main__":
    main()