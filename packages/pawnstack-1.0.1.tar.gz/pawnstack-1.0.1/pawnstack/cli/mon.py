"""
Mon CLI - 통합 모니터링 도구

시스템 리소스, SSH 로그, 블록체인 wallet 모니터링을 통합한 CLI
"""

import asyncio
import time
from argparse import ArgumentParser
from pathlib import Path

from pawnstack.cli.base import AsyncBaseCLI
from pawnstack.config.global_config import pawn
from pawnstack.monitoring.blockchain_monitor import BlockchainMonitor
from pawnstack.monitoring.ssh_monitor import SSHMonitor
from pawnstack.monitoring.system_monitor import SystemMonitor
from pawnstack.http.utils import append_http

# 모듈 메타데이터
__description__ = "통합 모니터링 도구 (시스템, SSH, Wallet)"
__epilog__ = """
사용 예제:
  
  시스템 모니터링:
    pawns mon system --cpu-threshold 80 --memory-threshold 90
    pawns mon system --interval 5 --duration 300
    
  SSH 로그 모니터링:
    pawns mon ssh -f /var/log/secure /var/log/auth.log
    pawns mon ssh --follow --alert-webhook https://hooks.slack.com/...
    
  Wallet 모니터링:
    pawns mon wallet --url https://api.icon.network --address-filter hx1234...
    pawns mon wallet --blockheight 1000000 --bps-interval 10
"""


def str2bool(v) -> bool:
    """문자열을 불린값으로 변환"""
    if isinstance(v, bool):
        return v
    if v is None:
        return False
    if isinstance(v, str):
        return v.lower() in ("yes", "true", "t", "1")
    return bool(v)


class SSHLogPathResolver:
    """SSH 로그 파일 경로 자동 탐지"""
    
    COMMON_LOG_PATHS = [
        "/var/log/auth.log",
        "/var/log/secure",
        "/var/log/syslog",
        "/var/log/messages",
        "/var/log/sshd.log",
        "/var/log/system.log",
    ]
    
    def get_path(self) -> str:
        """시스템에 맞는 SSH 로그 파일 경로 반환"""
        for path in self.COMMON_LOG_PATHS:
            if Path(path).exists():
                return path
        return "/var/log/auth.log"


class MonCLI(AsyncBaseCLI):
    """통합 모니터링 CLI"""
    
    def __init__(self, args=None):
        super().__init__(args)
    
    def get_arguments(self, parser: ArgumentParser):
        """명령어 인수 정의"""
        subparsers = parser.add_subparsers(
            dest='subcommand',
            help='모니터링 종류',
            required=False
        )
        
        parser.set_defaults(subcommand='system')
        
        # System 모니터링
        system_parser = subparsers.add_parser('system', help='시스템 리소스 모니터링')
        self._add_system_arguments(system_parser)
        
        # SSH 로그 모니터링
        ssh_parser = subparsers.add_parser('ssh', help='SSH 로그 모니터링')
        self._add_ssh_arguments(ssh_parser)
        
        # Wallet 모니터링
        wallet_parser = subparsers.add_parser('wallet', help='블록체인 wallet 모니터링')
        self._add_wallet_arguments(wallet_parser)
    
    def _add_system_arguments(self, parser: ArgumentParser):
        """시스템 모니터링 인수"""
        parser.add_argument('--interval', type=int, default=5, help='모니터링 간격 (초)')
        parser.add_argument('--duration', type=int, help='모니터링 지속 시간 (초)')
        parser.add_argument('--cpu-threshold', type=float, default=80.0, help='CPU 임계값 (%)')
        parser.add_argument('--memory-threshold', type=float, default=85.0, help='메모리 임계값 (%)')
        parser.add_argument('--disk-threshold', type=float, default=90.0, help='디스크 임계값 (%)')
        parser.add_argument('--network-threshold', type=float, default=1000.0, help='네트워크 임계값 (MB/s)')
        parser.add_argument('--load-threshold', type=float, help='시스템 로드 임계값')
        self._add_common_alert_arguments(parser)
    
    def _add_ssh_arguments(self, parser: ArgumentParser):
        """SSH 모니터링 인수"""
        parser.add_argument('-f', '--file', metavar='ssh_log_file', nargs='+',
                          default=[SSHLogPathResolver().get_path()], help='SSH 로그 파일')
        parser.add_argument('--follow', action='store_true', help='실시간 추적')
        parser.add_argument('--alert-on-failure', action='store_true', help='로그인 실패 시 알림')
        parser.add_argument('--alert-on-success', action='store_true', help='로그인 성공 시 알림')
        parser.add_argument('--max-failures', type=int, default=5, help='최대 실패 횟수')
        parser.add_argument('--time-window', type=int, default=300, help='시간 창 (초)')
        self._add_common_alert_arguments(parser)
    
    def _add_wallet_arguments(self, parser: ArgumentParser):
        """Wallet 모니터링 인수"""
        parser.add_argument('--url', '--endpoint-url', metavar="endpoint_url", dest='endpoint_url',
                          help='블록체인 RPC 엔드포인트 URL')
        parser.add_argument('--address-filter', help='모니터링할 주소 목록 (쉼표 구분)',
                          type=lambda s: [addr.strip() for addr in s.split(',')], default=None)
        parser.add_argument('--blockheight', type=int, default=None, help='시작 블록 높이')
        parser.add_argument('--resume', action='store_true', help='이전 저장된 blockheight부터 재개')
        parser.add_argument('--ignore-data-types', help='무시할 데이터 타입 (쉼표 구분)', default='base')
        parser.add_argument('--check-tx-result', type=str2bool, help='트랜잭션 결과 확인', default=True)
        parser.add_argument('--bps-interval', '-i', type=int, help='BPS/TPS 계산 간격 (초)', default=0)
        parser.add_argument('--skip-until', '-su', type=int, help='이 블록 높이까지 스킵', default=0)
        parser.add_argument('--show-full', action='store_true', help='전체 해시와 주소 표시', default=False)
        self._add_common_alert_arguments(parser)
    
    def _add_common_alert_arguments(self, parser: ArgumentParser):
        """공통 알림 인수"""
        parser.add_argument('--alert-webhook', type=str, help='알림 웹훅 URL')
        parser.add_argument('--slack-webhook-url', help='Slack webhook URL', default=None)
    
    async def run_async(self) -> int:
        """비동기 명령어 실행"""
        try:
            subcommand = getattr(self.args, 'subcommand', 'system')
            
            self.log_info(f"🚀 {subcommand.upper()} 모니터링 시작")
            
            if subcommand == 'system':
                return await self.run_system_monitoring()
            elif subcommand == 'ssh':
                return await self.run_ssh_monitoring()
            elif subcommand == 'wallet':
                return await self.run_wallet_monitoring()
            else:
                self.log_error(f"알 수 없는 서브커맨드: {subcommand}")
                return 1
        
        except KeyboardInterrupt:
            self.log_info("⏹️  모니터링 중지됨")
            return 0
        except Exception as e:
            self.log_error(f"모니터링 오류: {e}")
            if pawn.get('PAWN_DEBUG'):
                pawn.console.print_exception(show_locals=True)
            return 1
    
    async def run_system_monitoring(self) -> int:
        """시스템 리소스 모니터링"""
        monitor = SystemMonitor(
            interval=getattr(self.args, 'interval', 5),
            duration=getattr(self.args, 'duration', None),
            cpu_threshold=getattr(self.args, 'cpu_threshold', 80.0),
            memory_threshold=getattr(self.args, 'memory_threshold', 85.0),
            disk_threshold=getattr(self.args, 'disk_threshold', 90.0),
            network_threshold=getattr(self.args, 'network_threshold', 1000.0),
            load_threshold=getattr(self.args, 'load_threshold', None),
            logger=self
        )
        
        # 알림 콜백 설정
        monitor.on_alert_callback = self.send_alerts
        
        await monitor.start()
        return 0
    
    async def run_ssh_monitoring(self) -> int:
        """SSH 로그 모니터링"""
        log_files = getattr(self.args, 'file', [SSHLogPathResolver().get_path()])
        
        self.log_info(f"📁 모니터링 로그 파일: {', '.join(log_files)}")
        
        monitor = SSHMonitor(
            log_files=log_files,
            follow=getattr(self.args, 'follow', False),
            max_failures=getattr(self.args, 'max_failures', 5),
            time_window=getattr(self.args, 'time_window', 300),
            alert_on_failure=getattr(self.args, 'alert_on_failure', False),
            alert_on_success=getattr(self.args, 'alert_on_success', False),
            logger=self
        )
        
        # 알림 콜백 설정
        monitor.on_alert_callback = lambda alert, *args: self.send_alerts([alert])
        
        await monitor.start()
        return 0
    
    async def run_wallet_monitoring(self) -> int:
        """Wallet 모니터링"""
        endpoint_url = append_http(getattr(self.args, 'endpoint_url', None))
        
        
        
        if not endpoint_url:
            self.log_error("엔드포인트 URL이 필요합니다 (--url 또는 --endpoint-url)")
            return 1
        
        self.log_info(f"🔗 엔드포인트: {endpoint_url}")
        
        address_filter = getattr(self.args, 'address_filter', None)
        if address_filter:
            self.log_info(f"📍 모니터링 주소: {', '.join(address_filter)}")
        
        ignore_data_types = getattr(self.args, 'ignore_data_types', 'base').split(',')
        
        monitor = BlockchainMonitor(
            endpoint_url=endpoint_url,
            blockheight=getattr(self.args, 'blockheight', None),
            resume=getattr(self.args, 'resume', False),
            address_filter=address_filter,
            skip_until=getattr(self.args, 'skip_until', 0),
            check_tx_result=getattr(self.args, 'check_tx_result', True),
            ignore_data_types=ignore_data_types,
            bps_interval=getattr(self.args, 'bps_interval', 0),
            show_full=getattr(self.args, 'show_full', False),
            logger=self
        )
        
        await monitor.start()
        return 0
    
    async def send_alerts(self, alerts):
        """알림 전송"""
        if not alerts:
            return
        
        # 콘솔 출력
        for alert in alerts:
            self.log_warning(alert)
        
        # Webhook 알림
        webhook_url = getattr(self.args, 'alert_webhook', None) or \
                     getattr(self.args, 'slack_webhook_url', None)
        
        if webhook_url:
            await self.send_webhook_alert(webhook_url, alerts)
    
    async def send_webhook_alert(self, webhook_url: str, alerts):
        """Webhook 알림 전송"""
        import aiohttp
        
        try:
            async with aiohttp.ClientSession() as session:
                payload = {
                    'text': '🚨 PawnStack Monitor Alert',
                    'attachments': [{
                        'color': 'warning',
                        'fields': [{
                            'title': '알림',
                            'value': '\n'.join(alerts) if isinstance(alerts, list) else str(alerts),
                            'short': False
                        }],
                        'footer': 'PawnStack Monitor',
                        'ts': int(time.time())
                    }]
                }
                
                async with session.post(webhook_url, json=payload) as response:
                    if response.status == 200:
                        self.log_debug("Webhook 알림 전송 성공")
                    else:
                        self.log_warning(f"Webhook 알림 전송 실패: HTTP {response.status}")
        
        except Exception as e:
            self.log_error(f"Webhook 알림 전송 오류: {e}")


def main():
    """CLI 진입점"""
    parser = ArgumentParser(
        description='통합 모니터링 도구 (시스템, SSH, Wallet)',
        epilog=__epilog__
    )
    
    temp_cli = MonCLI()
    temp_cli.get_arguments(parser)
    
    args = parser.parse_args()
    
    cli = MonCLI(args)
    return cli.main()


if __name__ == "__main__":
    exit(main())
