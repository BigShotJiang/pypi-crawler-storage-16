import re

def append_http(url):
    """

    Add http:// if it doesn't exist in the URL

    :param url:
    :return:
    """
    if not url:
        return url

    if not (url.startswith("http://") or url.startswith("https://")):
        url = f"http://{url}"
    return url


def append_s3(url):
    """

    Add http:// if it doesn't exist in the URL

    :param url:
    :return:
    """
    if not url:
        return url

    if not url.startswith("s3://"):
        url = f"s3://{url}"
    return url


def append_ws(url):
    """

    Add ws:// if it doesn't exist in the URL

    :param url:
    :return:
    """
    if not url:
        return url  # 또는 오류 처리, 예: raise ValueError("URL cannot be empty")

    if url.startswith("https://"):
        url = url.replace("https://", "wss://", 1)
    elif url.startswith("http://"):
        url = url.replace("http://", "ws://", 1)
    elif not (url.startswith("ws://") or url.startswith("wss://")):
        url = f"ws://{url}"

    return url


def append_api_v3(url):
    if "/api/v3" not in url:
        url = f"{url.rstrip('/')}/api/v3"
    return append_http(url)


def remove_http(url):
    """
    Remove the r'https?://' string

    :param url:
    :return:

    """
    return re.sub(r"https?://", '', url)
