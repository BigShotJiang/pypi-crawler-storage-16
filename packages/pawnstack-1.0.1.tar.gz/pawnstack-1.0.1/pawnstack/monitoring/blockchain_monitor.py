"""
블록체인 모니터링 모듈

블록체인 RPC를 통한 블록/트랜잭션 모니터링 기능 제공
"""

import asyncio
import json
from re import error
import time
import os
from datetime import datetime
from typing import Dict, List, Optional, Any, Callable
from pathlib import Path

import aiohttp


class BlockchainMonitor:
    """블록체인 모니터링 클래스"""
    
    BLOCKHEIGHT_FILE = ".last_blockheight"
    
    def __init__(
        self,
        endpoint_url: str,
        blockheight: Optional[int] = None,
        resume: bool = False,
        address_filter: Optional[List[str]] = None,
        skip_until: int = 0,
        check_tx_result: bool = True,
        ignore_data_types: List[str] = None,
        bps_interval: int = 0,
        show_full: bool = False,
        logger: Optional[Any] = None
    ):
        """
        Args:
            endpoint_url: RPC 엔드포인트 URL
            blockheight: 시작 블록 높이
            resume: resume 모드 활성화
            address_filter: 모니터링할 주소 목록
            skip_until: 이 블록까지 스킵
            check_tx_result: 트랜잭션 결과 확인 여부
            ignore_data_types: 무시할 데이터 타입 목록
            bps_interval: BPS/TPS 계산 간격 (초)
            show_full: 전체 해시와 주소 표시 여부
            logger: 로거 객체
        """
        self.endpoint_url = self._normalize_endpoint(endpoint_url)
        self.blockheight = blockheight
        self.resume = resume
        self.address_filter = address_filter
        self.skip_until = skip_until
        self.check_tx_result = check_tx_result
        self.ignore_data_types = ignore_data_types or ['base']
        self.bps_interval = bps_interval
        self.show_full = show_full
        self.logger = logger
        
        # BPS/TPS 추적
        self.block_times = []
        self.tx_counts = []
        self.last_bps_calc_time = time.time()
        
        # 콜백
        self.on_block_callback: Optional[Callable] = None
        self.on_transaction_callback: Optional[Callable] = None
        self.on_bps_tps_callback: Optional[Callable] = None
    
    def _normalize_endpoint(self, url: str) -> str:
        """엔드포인트 URL 정규화"""
        if not url.endswith('/api/v3'):
            if url.endswith('/'):
                return f"{url}api/v3"
            else:
                return f"{url}/api/v3"
        return url
    
    def _log(self, level: str, message: str):
        """로그 출력"""
        if self.logger:
            method_name = f"log_{level}"
            if hasattr(self.logger, method_name):
                getattr(self.logger, method_name)(message)
            else:
                print(f"[{level.upper()}] {message}")
        else:
            print(f"[{level.upper()}] {message}")
    
    async def rpc_call(self, session, method: str, params: dict = None) -> Optional[dict]:
        """RPC 호출"""
        payload = {
            "jsonrpc": "2.0",
            "method": method,
            "id": 1
        }
        if params:
            payload["params"] = params
        
        try:
            async with session.post(self.endpoint_url, json=payload) as response:
                
                # data = await response.json()
                data = await response.json()
                if response.status == 200:                    
                    return data.get("result")
                else:
                    error_text = await response.text()
                    return {"error": response.status, "message": error_text, "data": data}
                    # return {"error": response.status, "message": data }

        except Exception as e:
            self._log("warning", f"RPC 호출 실패 ({method}): {e}")
            return None
    
    async def get_last_block_height(self, session) -> Optional[int]:
        """최신 블록 높이 조회"""
        result = await self.rpc_call(session, "icx_getLastBlock")
        if result and isinstance(result, dict):
            return result.get("height", 0)
        return None
    
    async def resolve_start_blockheight(self, session) -> int:
        """시작 블록 높이 결정"""
        if self.blockheight is not None:
            self._log("info", f"📍 지정된 블록부터 시작: #{self.blockheight}")
            return self.blockheight
        
        if self.resume:
            saved_blockheight = self.load_blockheight()
            if saved_blockheight is not None:
                self._log("info", "📋 Resume 모드: 이전 위치에서 재개")
                return saved_blockheight
            else:
                self._log("info", "⚠️  저장된 blockheight가 없습니다. 최신 블록부터 시작합니다.")
        else:
            self._log("info", "🆕 새로운 모니터링: 최신 블록부터 시작")
        
        return await self.get_last_block_height(session)
    
    async def start(self):
        """모니터링 시작"""
        async with aiohttp.ClientSession() as session:
            try:
                # 시작 블록 높이 결정
                current_height = await self.resolve_start_blockheight(session)
                self._log("info", f"✅ 모니터링 시작: 블록 #{current_height}")
                
                while True:
                    try:                        
                        result = await self.rpc_call(
                            session,
                            "icx_getBlockByHeight",
                            {"height": hex(current_height)}
                        )                        
                                                
                        if result and not result.get("error"):
                        
                            # 블록 데이터 처리
                            await self.process_block(result, session)
                            
                            # blockheight 저장
                            self.save_blockheight(current_height)
                            
                            # 다음 블록으로
                            current_height += 1
                            
                            # BPS/TPS 계산
                            if self.bps_interval > 0:
                                current_time = time.time()
                                if current_time - self.last_bps_calc_time >= self.bps_interval:
                                    await self.calculate_bps_tps()
                                    self.last_bps_calc_time = current_time
                        else:
                            # 블록 조회 실패 (아직 생성되지 않음)

                            if result and result.get("error"):
                                error_msg = result.get("message", "")
                                if "NotFound" not in error_msg and "no block" not in error_msg:
                                    self._log("warning", f"블록 조회 실패: {error_msg}")
                            
                            await asyncio.sleep(1)

                    
                    except Exception as e:
                        self._log("error", f"블록 처리 오류: {e}")
                        await asyncio.sleep(2)
            
            except Exception as e:
                self._log("error", f"모니터링 오류: {e}")
                raise
    
    async def process_block(self, block_data: Dict[str, Any], session):
        """블록 데이터 처리"""
        # 블록 높이 추출
        height = self._extract_height(block_data)
        
        # 스킵 체크
        if self.skip_until and height <= self.skip_until:
            return
        
        # 블록 정보
        timestamp = self._extract_timestamp(block_data)
        tx_count = len(block_data.get('confirmed_transaction_list', []))
        
        # 로그 출력
        if timestamp > 0:
            time_str = datetime.fromtimestamp(timestamp/1000000).strftime('%Y-%m-%d %H:%M:%S')
            self._log("info", f"📦 블록 #{height} | 트랜잭션: {tx_count}개 | 시간: {time_str}")
        else:
            self._log("info", f"📦 블록 #{height} | 트랜잭션: {tx_count}개")
        
        # BPS/TPS 추적
        self.block_times.append(time.time())
        self.tx_counts.append(tx_count)
        if len(self.block_times) > 100:
            self.block_times.pop(0)
            self.tx_counts.pop(0)
        
        # 콜백 호출
        if self.on_block_callback:
            await self.on_block_callback(block_data, height, timestamp, tx_count)
        
        # 트랜잭션 처리
        transactions = block_data.get('confirmed_transaction_list', [])
        for tx in transactions:
            await self.process_transaction(tx, height, session)
    
    async def process_transaction(self, tx: Dict[str, Any], height: int, session):
        """트랜잭션 처리"""
        # 데이터 타입 필터링
        data_type = tx.get('dataType', 'call')
        if data_type in self.ignore_data_types:
            return
        
        # 주소 필터링
        tx_from = tx.get('from', '')
        tx_to = tx.get('to', '')
        
        if self.address_filter:
            if tx_from not in self.address_filter and tx_to not in self.address_filter:
                return
        
        # 트랜잭션 정보 추출
        tx_hash = tx.get('txHash', 'unknown')
        value = self._extract_value(tx)
        method = self._extract_method(tx)
        
        # 로그 출력
        self._log_transaction(method, tx, tx_hash, tx_from, tx_to, value, height)
        
        # 콜백 호출
        if self.on_transaction_callback:
            await self.on_transaction_callback(tx, height, method, value)
        
        # 트랜잭션 결과 확인
        if self.check_tx_result:
            await self.check_transaction_result(tx_hash, session)
    
    def _extract_height(self, block_data: Dict[str, Any]) -> int:
        """블록 높이 추출"""
        height_value = block_data.get('height', '0x0')
        if isinstance(height_value, str):
            return int(height_value, 16)
        return height_value
    
    def _extract_timestamp(self, block_data: Dict[str, Any]) -> int:
        """타임스탬프 추출"""
        timestamp_value = block_data.get('time_stamp', '0x0')
        if isinstance(timestamp_value, str):
            return int(timestamp_value, 16)
        return timestamp_value
    
    def _extract_value(self, tx: Dict[str, Any]) -> float:
        """트랜잭션 value 추출 (ICX)"""
        value_hex = tx.get('value', '0x0')
        if isinstance(value_hex, str):
            return int(value_hex, 16) / 10**18
        return value_hex / 10**18
    
    def _extract_method(self, tx: Dict[str, Any]) -> str:
        """트랜잭션 method 추출"""
        data_type = tx.get('dataType', 'send')
        
        if data_type == 'call':
            data = tx.get('data', {})
            if isinstance(data, dict):
                return data.get('method', 'unknown')
            elif isinstance(data, str):
                try:
                    data_dict = json.loads(data)
                    return data_dict.get('method', 'unknown')
                except:
                    return 'unknown'
        
        return 'Send'
    
    def _extract_stake_value(self, tx: Dict[str, Any]) -> str:
        """스테이킹 값 추출"""
        data = tx.get('data', {})
        
        if isinstance(data, dict):
            value = data.get('value', '0x0')
        elif isinstance(data, str):
            try:
                data_dict = json.loads(data)
                value = data_dict.get('value', '0x0')
            except:
                value = '0x0'
        else:
            value = '0x0'
        
        try:
            if isinstance(value, str):
                stake_icx = int(value, 16) / 10**18
            else:
                stake_icx = value / 10**18
            return f"{stake_icx:.4f}"
        except:
            return "0.0000"
    
    def _log_transaction(
        self,
        method: str,
        tx: Dict[str, Any],
        tx_hash: str,
        tx_from: str,
        tx_to: str,
        value: float,
        height: int
    ):
        """트랜잭션 로그 출력"""
        # show_full에 따라 해시와 주소 표시 방식 결정
        if self.show_full:
            display_hash = tx_hash
            display_from = tx_from
            display_to = tx_to
        else:
            display_hash = tx_hash[:10] if len(tx_hash) > 10 else tx_hash
            display_from = f"{tx_from[:12]}..." if len(tx_from) > 12 else tx_from
            display_to = f"{tx_to[:12]}..." if len(tx_to) > 12 else tx_to
        
        if method == "setStake":
            stake_value = self._extract_stake_value(tx)
            self._log("info", f"🔵 <Staking> 블록 #{height} {display_from} has staked 💰 {stake_value} ICX")
        
        elif method == "unStake":
            stake_value = self._extract_stake_value(tx)
            self._log("info", f"� <U nstaking> 블록 #{height} {display_from} has unstaked 💰 {stake_value} ICX")
        
        elif method == "Send":
            data_type = tx.get('dataType', 'send')
            data_type_text = "" if data_type == "send" else f" {data_type}"
            self._log("info", f"💸 블록 #{height} {display_hash}<Send{data_type_text}> {display_from} → {display_to} 💰 {value:.4f} ICX")
        
        else:
            self._log("info", f"🔶 블록 #{height} <{method}> {display_from} → {display_to} 💰 {value:.4f} ICX")
    
    async def check_transaction_result(self, tx_hash: str, session, max_attempts: int = 5):
        """트랜잭션 결과 확인 (재시도 포함)"""
        display_hash = tx_hash if self.show_full else tx_hash[:10]
        
        for attempt in range(max_attempts):
            try:
                result = await self.rpc_call(
                    session,
                    "icx_getTransactionResult",
                    {"txHash": tx_hash}
                )               
                # 결과가 있고 딕셔너리인 경우
                failure_msg = ""
                error_msg = ""
                if result and isinstance(result, dict):
                    # 에러가 없으면 결과 확인
                    if result.get('failure') and isinstance(result, dict):
                        failure_msg = result['failure'].get('message')

                    if result.get('data') and result['data'].get('error'):
                        error_msg = result['data']['error'].get('message')
                        
                    if not result.get('error'):
                        status = result.get('status', '0x0')
                        
                        if status == '0x1':
                            self._log("info", f"✅ 트랜잭션 성공: {display_hash} (시도: {attempt + 1}/{max_attempts})")
                        else:
                            self._log("error", f"트랜잭션 실패: {display_hash} (시도: {attempt + 1}/{max_attempts}), failure_msg={failure_msg}")
                        return
                    else:
                        self._log("warning", f"트랜잭션 결과 조회 실패: {display_hash} (시도: {attempt + 1}/{max_attempts}), error_msg={error_msg}")                   
                
                # 결과가 없거나 에러가 있으면 재시도
                if attempt < max_attempts - 1:
                    await asyncio.sleep(1)
                else:
                    # 최대 시도 횟수 도달
                    self._log("warning", f"⏱️  트랜잭션 결과 대기 시간 초과: {display_hash} (시도: {max_attempts}/{max_attempts})")
            
            except Exception as e:
                if attempt < max_attempts - 1:
                    await asyncio.sleep(1)
                else:
                    self._log("warning", f"트랜잭션 결과 조회 실패: {display_hash} - {e}")
    
    async def calculate_bps_tps(self):
        """BPS/TPS 계산"""
        if len(self.block_times) < 2:
            return
        
        time_range = self.block_times[-1] - self.block_times[0]
        
        if time_range > 0:
            bps = len(self.block_times) / time_range
            total_txs = sum(self.tx_counts)
            tps = total_txs / time_range
            
            self._log("info", f"📊 성능 지표 | BPS: {bps:.2f} | TPS: {tps:.2f} | 총 블록: {len(self.block_times)} | 총 TX: {total_txs}")
            
            if self.on_bps_tps_callback:
                await self.on_bps_tps_callback(bps, tps, len(self.block_times), total_txs)
    
    def save_blockheight(self, blockheight: int):
        """blockheight 저장"""
        try:
            with open(self.BLOCKHEIGHT_FILE, 'w') as f:
                f.write(str(blockheight))
        except Exception as e:
            self._log("warning", f"Blockheight 저장 실패: {e}")
    
    def load_blockheight(self) -> Optional[int]:
        """blockheight 로드"""
        try:
            if os.path.exists(self.BLOCKHEIGHT_FILE):
                with open(self.BLOCKHEIGHT_FILE, 'r') as f:
                    blockheight = int(f.read().strip())
                    self._log("info", f"📦 저장된 blockheight 로드: {blockheight}")
                    return blockheight
        except Exception as e:
            self._log("warning", f"Blockheight 로드 실패: {e}")
        return None
