"""
SSH 로그 모니터링 모듈

SSH 로그 파일 모니터링 및 보안 이벤트 감지
"""

import asyncio
import re
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable
from pathlib import Path


class SSHMonitor:
    """SSH 로그 모니터링 클래스"""
    
    def __init__(
        self,
        log_files: List[str],
        follow: bool = False,
        max_failures: int = 5,
        time_window: int = 300,
        alert_on_failure: bool = False,
        alert_on_success: bool = False,
        logger: Optional[Any] = None
    ):
        """
        Args:
            log_files: 모니터링할 로그 파일 목록
            follow: 실시간 추적 여부
            max_failures: 알림 임계값
            time_window: 실패 횟수 계산 시간 창 (초)
            alert_on_failure: 로그인 실패 시 알림
            alert_on_success: 로그인 성공 시 알림
            logger: 로거 객체
        """
        self.log_files = log_files
        self.follow = follow
        self.max_failures = max_failures
        self.time_window = time_window
        self.alert_on_failure = alert_on_failure
        self.alert_on_success = alert_on_success
        self.logger = logger
        
        # 실패 시도 추적
        self.failure_attempts: Dict[str, List[datetime]] = {}
        
        # 패턴 설정
        self.patterns = {
            'auth_success': re.compile(r'Accepted \w+ for (\w+) from ([\d.]+)'),
            'auth_failure': re.compile(r'Failed password for (?:invalid user )?(\w+) from ([\d.]+)'),
            'connection_closed': re.compile(r'Connection closed by ([\d.]+)'),
            'invalid_user': re.compile(r'Invalid user (\w+) from ([\d.]+)'),
            'break_in_attempt': re.compile(r'POSSIBLE BREAK-IN ATTEMPT'),
            'too_many_auth': re.compile(r'Too many authentication failures'),
        }
        
        # 콜백
        self.on_event_callback: Optional[Callable] = None
        self.on_alert_callback: Optional[Callable] = None
    
    def _log(self, level: str, message: str):
        """로그 출력"""
        if self.logger:
            method_name = f"log_{level}"
            if hasattr(self.logger, method_name):
                getattr(self.logger, method_name)(message)
            else:
                print(f"[{level.upper()}] {message}")
        else:
            print(f"[{level.upper()}] {message}")
    
    async def start(self):
        """모니터링 시작"""
        if self.follow:
            await self.follow_logs()
        else:
            await self.analyze_logs()
    
    async def follow_logs(self):
        """로그 실시간 추적"""
        try:
            import aiofiles
        except ImportError:
            self._log("error", "aiofiles 모듈이 필요합니다: pip install aiofiles")
            return
        
        async def tail_file(filepath):
            """파일 tail -f 구현"""
            async with aiofiles.open(filepath, 'r') as f:
                await f.seek(0, 2)  # 파일 끝으로
                
                while True:
                    line = await f.readline()
                    if line:
                        await self.process_log_line(line, filepath)
                    else:
                        await asyncio.sleep(0.1)
        
        tasks = [tail_file(log_file) for log_file in self.log_files]
        await asyncio.gather(*tasks)
    
    async def analyze_logs(self):
        """로그 분석"""
        for log_file in self.log_files:
            if not Path(log_file).exists():
                self._log("warning", f"로그 파일이 존재하지 않습니다: {log_file}")
                continue
            
            self._log("info", f"📖 분석 중: {log_file}")
            
            with open(log_file, 'r') as f:
                for line in f:
                    await self.process_log_line(line, log_file)
    
    async def process_log_line(self, line: str, source_file: str):
        """로그 라인 처리"""
        line = line.strip()
        if not line:
            return
        
        for pattern_name, pattern in self.patterns.items():
            match = pattern.search(line)
            if match:
                await self.handle_event(pattern_name, match, line, source_file)
    
    async def handle_event(self, event_type: str, match, line: str, source_file: str):
        """이벤트 처리"""
        timestamp = datetime.now()
        
        if event_type == 'auth_failure':
            user = match.group(1)
            ip = match.group(2)
            
            # 실패 횟수 추적
            key = f"{user}@{ip}"
            if key not in self.failure_attempts:
                self.failure_attempts[key] = []
            
            self.failure_attempts[key].append(timestamp)
            
            # 시간 창 내의 실패 횟수 계산
            recent_failures = [
                t for t in self.failure_attempts[key]
                if (timestamp - t).seconds <= self.time_window
            ]
            self.failure_attempts[key] = recent_failures
            
            # 임계값 체크
            if len(recent_failures) >= self.max_failures:
                alert = f"🚨 SSH 로그인 실패 임계값 초과: {user}@{ip} ({len(recent_failures)}회/{self.time_window}초)"
                self._log("error", alert)
                
                if self.on_alert_callback:
                    await self.on_alert_callback(alert, event_type, user, ip)
                
                self.failure_attempts[key] = []  # 리셋
            
            if self.alert_on_failure:
                self._log("warning", f"❌ 로그인 실패: {user}@{ip}")
        
        elif event_type == 'auth_success':
            user = match.group(1)
            ip = match.group(2)
            
            if self.alert_on_success:
                self._log("info", f"✅ 로그인 성공: {user}@{ip}")
                
                if self.on_alert_callback:
                    await self.on_alert_callback(f"SSH 로그인 성공: {user}@{ip}", event_type, user, ip)
        
        elif event_type in ['break_in_attempt', 'too_many_auth']:
            self._log("error", f"🚨 보안 경고: {event_type}")
            
            if self.on_alert_callback:
                await self.on_alert_callback(f"보안 경고: {line}", event_type, None, None)
        
        # 콜백 호출
        if self.on_event_callback:
            await self.on_event_callback(event_type, match, line, source_file)
