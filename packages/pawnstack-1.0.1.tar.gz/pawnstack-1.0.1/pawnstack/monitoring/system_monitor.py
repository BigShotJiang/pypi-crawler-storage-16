"""
시스템 리소스 모니터링 모듈

CPU, 메모리, 디스크, 네트워크 등 시스템 리소스 모니터링
"""

import asyncio
import os
import time
from datetime import datetime
from typing import Dict, List, Optional, Any, Callable

import psutil


class SystemMonitor:
    """시스템 리소스 모니터링 클래스"""
    
    def __init__(
        self,
        interval: int = 5,
        duration: Optional[int] = None,
        cpu_threshold: float = 80.0,
        memory_threshold: float = 85.0,
        disk_threshold: float = 90.0,
        network_threshold: float = 1000.0,
        load_threshold: Optional[float] = None,
        logger: Optional[Any] = None
    ):
        """
        Args:
            interval: 모니터링 간격 (초)
            duration: 모니터링 지속 시간 (초, None=무제한)
            cpu_threshold: CPU 사용률 임계값 (%)
            memory_threshold: 메모리 사용률 임계값 (%)
            disk_threshold: 디스크 사용률 임계값 (%)
            network_threshold: 네트워크 사용량 임계값 (MB/s)
            load_threshold: 시스템 로드 평균 임계값
            logger: 로거 객체
        """
        self.interval = interval
        self.duration = duration
        self.cpu_threshold = cpu_threshold
        self.memory_threshold = memory_threshold
        self.disk_threshold = disk_threshold
        self.network_threshold = network_threshold
        self.load_threshold = load_threshold
        self.logger = logger
        
        # 콜백
        self.on_metrics_callback: Optional[Callable] = None
        self.on_alert_callback: Optional[Callable] = None
    
    def _log(self, level: str, message: str):
        """로그 출력"""
        if self.logger:
            method_name = f"log_{level}"
            if hasattr(self.logger, method_name):
                getattr(self.logger, method_name)(message)
            else:
                print(f"[{level.upper()}] {message}")
        else:
            print(f"[{level.upper()}] {message}")
    
    async def start(self):
        """모니터링 시작"""
        start_time = time.time()
        
        try:
            while True:
                # 메트릭 수집
                metrics = await self.collect_metrics()
                
                # 메트릭 출력
                self.display_metrics(metrics)
                
                # 임계값 체크
                alerts = await self.check_thresholds(metrics)
                
                # 콜백 호출
                if self.on_metrics_callback:
                    await self.on_metrics_callback(metrics)
                
                if alerts and self.on_alert_callback:
                    await self.on_alert_callback(alerts)
                
                # 종료 조건 체크
                if self.duration and (time.time() - start_time) >= self.duration:
                    self._log("info", "⏱️  모니터링 시간 종료")
                    break
                
                await asyncio.sleep(self.interval)
        
        except KeyboardInterrupt:
            self._log("info", "⏹️  모니터링 중지됨")
    
    async def collect_metrics(self) -> Dict[str, Any]:
        """시스템 메트릭 수집"""
        metrics = {
            'timestamp': datetime.now().isoformat(),
            'cpu': {
                'percent': psutil.cpu_percent(interval=1),
                'count': psutil.cpu_count(),
                'freq': psutil.cpu_freq()._asdict() if psutil.cpu_freq() else None
            },
            'memory': {
                'percent': psutil.virtual_memory().percent,
                'total': psutil.virtual_memory().total,
                'available': psutil.virtual_memory().available,
                'used': psutil.virtual_memory().used
            },
            'disk': {},
            'network': {},
            'load': os.getloadavg() if hasattr(os, 'getloadavg') else None
        }
        
        # 디스크 사용량
        for partition in psutil.disk_partitions():
            if partition.mountpoint:
                try:
                    usage = psutil.disk_usage(partition.mountpoint)
                    metrics['disk'][partition.mountpoint] = {
                        'percent': usage.percent,
                        'total': usage.total,
                        'used': usage.used,
                        'free': usage.free
                    }
                except:
                    pass
        
        # 네트워크 통계
        net_io = psutil.net_io_counters()
        metrics['network'] = {
            'bytes_sent': net_io.bytes_sent,
            'bytes_recv': net_io.bytes_recv,
            'packets_sent': net_io.packets_sent,
            'packets_recv': net_io.packets_recv
        }
        
        return metrics
    
    def display_metrics(self, metrics: Dict[str, Any]):
        """메트릭 출력"""
        self._log("info", f"===== System Metrics @ {metrics['timestamp']} =====")
        self._log("info", f"📊 CPU: {metrics['cpu']['percent']}% ({metrics['cpu']['count']} cores)")
        self._log("info", f"💾 Memory: {metrics['memory']['percent']}% "
                         f"({metrics['memory']['used'] / (1024**3):.1f}GB / "
                         f"{metrics['memory']['total'] / (1024**3):.1f}GB)")
        
        for mount, disk in metrics['disk'].items():
            self._log("info", f"💿 Disk {mount}: {disk['percent']}% "
                             f"({disk['used'] / (1024**3):.1f}GB / "
                             f"{disk['total'] / (1024**3):.1f}GB)")
        
        if metrics['load']:
            self._log("info", f"⚡ Load Average: {metrics['load']}")
    
    async def check_thresholds(self, metrics: Dict[str, Any]) -> List[str]:
        """임계값 체크"""
        alerts = []
        
        # CPU 임계값
        if metrics['cpu']['percent'] > self.cpu_threshold:
            alerts.append(f"⚠️ CPU 사용률이 {self.cpu_threshold}%를 초과했습니다: {metrics['cpu']['percent']}%")
        
        # 메모리 임계값
        if metrics['memory']['percent'] > self.memory_threshold:
            alerts.append(f"⚠️ 메모리 사용률이 {self.memory_threshold}%를 초과했습니다: {metrics['memory']['percent']}%")
        
        # 디스크 임계값
        for mount, disk in metrics['disk'].items():
            if disk['percent'] > self.disk_threshold:
                alerts.append(f"⚠️ 디스크 {mount} 사용률이 {self.disk_threshold}%를 초과했습니다: {disk['percent']}%")
        
        # 로드 평균 임계값
        if self.load_threshold and metrics['load']:
            if metrics['load'][0] > self.load_threshold:
                alerts.append(f"⚠️ 시스템 로드가 {self.load_threshold}를 초과했습니다: {metrics['load'][0]}")
        
        # 알림 출력
        for alert in alerts:
            self._log("warning", alert)
        
        return alerts
