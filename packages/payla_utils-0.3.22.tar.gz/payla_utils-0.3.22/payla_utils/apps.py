from django.apps import AppConfig


class PaylaUtilsConfig(AppConfig):
    name = 'payla_utils'
    verbose_name = 'Payla Utils'
    default = True
