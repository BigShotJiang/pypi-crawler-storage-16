"""Version information for paymentus-core."""

__version__ = "1.0.2"
LIB_VERSION = __version__