### Updated
- **Clear Filters**
  - Added `--summary` option for concise count-based output
  - Improved slicer detection to match all slicer types
