GOOGLE_BUCKET_API_URL = "https://storage.googleapis.com"
