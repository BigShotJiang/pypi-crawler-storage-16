Explanations on docstrings and code comments goes here.
