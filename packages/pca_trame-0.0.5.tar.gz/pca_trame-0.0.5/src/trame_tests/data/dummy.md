# Title 1

## Title 2

### Title 3

Paragraph

- list element 1
- list element 2
- list element 3

lalal

- [ ] task 1
- [ ] task 2
- [ ] task 3

```bash
ls
```

```python
lambda x: x
```

```
idk
```

```yaml
ping: pong
```




| Month    | Savings |
| -------- | ------- |
| January  | $250    |
| February | $80     |
| March    | $420    |



some paragrpah

followed by this one



$$latex=equation$$

Some in line latex $x+1=y+1$ 