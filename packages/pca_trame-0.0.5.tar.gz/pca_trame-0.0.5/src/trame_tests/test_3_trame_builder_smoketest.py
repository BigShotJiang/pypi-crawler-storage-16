from pathlib import Path
import unittest


from trame import TrameBuilder


class SmokeTest(unittest.TestCase):
    """Just try to build any markdown on tests/data"""

    files = [
        ("src/trame_tests/data/dummy.md", 16),
        ("src/trame_tests/data/rgpd_maths.pm.md", 52),
        ("src/trame_tests/data/sujet_0_spe_sujet_1.md", 1),
        ("src/trame_tests/data/sujet_0_spe_sujet_2.md", 1),
    ]

    def test(self):
        for file, n_pieces in self.files:
            # print(file)
            with self.subTest(file=file):
                trame = TrameBuilder.from_file(Path(file))
                self.assertEqual(len(trame.pieces), n_pieces)


if __name__ == "__main__":
    unittest.main()
