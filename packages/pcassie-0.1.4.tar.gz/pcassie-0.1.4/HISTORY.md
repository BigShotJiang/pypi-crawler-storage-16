# HISTORY of ``pcassie``

## Version 0.1.0 (2025/12/10)

First release with PCA subtraction, cross-correlation, an integrated pipeline and helper functions. 
