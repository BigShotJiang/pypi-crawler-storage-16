CCF Test Functions
==================

.. autofunction:: pcassie.ccf_tests.inject_simulated_signal

.. autofunction:: pcassie.ccf_tests.sn_map

.. autofunction:: pcassie.ccf_tests.welch_t_test

.. autofunction:: pcassie.ccf_tests.find_max_sn_in_expected_range
