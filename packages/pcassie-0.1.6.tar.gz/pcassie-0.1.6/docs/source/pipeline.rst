Pipeline
========

.. autofunction:: pcassie.pipeline.pipeline

.. autofunction:: pcassie.pipeline.sample_full_pca_components

.. autofunction:: pcassie.pipeline.sample_components