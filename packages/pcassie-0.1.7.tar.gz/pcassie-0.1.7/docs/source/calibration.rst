Calibration
===========

.. autofunction:: pcassie.calibration.gaussian

.. autofunction:: pcassie.calibration.fit_gaussian_to_peaks

.. autofunction:: pcassie.calibration.fit_segments_to_wavelengths

.. autofunction:: pcassie.calibration.precision

.. autofunction:: pcassie.calibration.split_and_stack

.. autofunction:: pcassie.calibration.calibrate_cr2res


