Cross-Correlation Function
==========================

.. autofunction:: pcassie.ccf.doppler_shift

.. autofunction:: pcassie.ccf.ccf

.. autofunction:: pcassie.ccf.orbital_phase

.. autofunction:: pcassie.ccf.orbit_velocity

.. autofunction:: pcassie.ccf.rv_amplitude

.. autofunction:: pcassie.ccf.doppler_correction

.. autofunction:: pcassie.ccf.compute_vbary_timeseries

.. autofunction:: pcassie.ccf.doppler_correct_ccf

.. autofunction:: pcassie.ccf.remove_out_of_transit

.. autofunction:: pcassie.ccf.run_ccf_on_detector_segments
