Plot Functions
==============

.. autofunction:: pcassie.plot_functions.plot_spectral_square

.. autofunction:: pcassie.plot_functions.plot_preprocess

.. autofunction:: pcassie.plot_functions.plot_covariance

.. autofunction:: pcassie.plot_functions.plot_eigenvectors

.. autofunction:: pcassie.plot_functions.plot_explained_variance

.. autofunction:: pcassie.plot_functions.plot_reconstructed_spectra

.. autofunction:: pcassie.plot_functions.plot_pca_subtraction

.. autofunction:: pcassie.plot_functions.plot_intransit_ccfs

.. autofunction:: pcassie.plot_functions.plot_welch_t_test