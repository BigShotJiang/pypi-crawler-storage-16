"""Helper scripts exposed as a Python package for internal tooling."""
