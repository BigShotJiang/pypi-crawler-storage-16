#!/usr/bin/env python3
"""
PCILeech Firmware Generator Scripts

This package contains utility scripts for driver analysis and state machine extraction.
"""

__version__ = "0.5.0"
__author__ = "Ramsey McGrath"
