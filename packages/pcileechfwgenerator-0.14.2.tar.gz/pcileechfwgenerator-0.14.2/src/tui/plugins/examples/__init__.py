"""
Example plugins for the PCILeech TUI application.
"""
