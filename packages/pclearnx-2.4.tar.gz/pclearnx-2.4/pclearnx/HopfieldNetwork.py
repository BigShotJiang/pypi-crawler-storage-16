import numpy as np
np.int = int
from neurodynex.hopfield_network import network, pattern_tools, plot_tools
def build(size):
    net = network.HopfieldNetwork(size*size)
    fac = pattern_tools.PatternFactory(size, size)
    return net, fac

def patterns(fac):
    base = fac.create_checkerboard()
    pats = [base] + fac.create_random_pattern_list(3, 0.5)
    return base, pats

def show(pats):
    plot_tools.plot_pattern_list(pats)
    m = pattern_tools.compute_overlap_matrix(pats)
    plot_tools.plot_overlap_matrix(m)

def simulate(net, base, flips=4):
    noisy = pattern_tools.flip_n(base, flips)
    net.set_state_from_pattern(noisy)
    return noisy, net.run_with_monitoring(4)

def dyn(fac, states, pats, ref=0):
    s = fac.reshape_patterns(states)
    plot_tools.plot_state_sequence_and_overlap(s, pats, ref, suptitle="Network Dynamics")

if __name__ == "__main__":
    n = 5
    net, fac = build(n)
    base, pats = patterns(fac)
    net.store_patterns(pats)
    show(pats)
    noisy, st = simulate(net, base, 4)
    dyn(fac, st, pats, 0)
