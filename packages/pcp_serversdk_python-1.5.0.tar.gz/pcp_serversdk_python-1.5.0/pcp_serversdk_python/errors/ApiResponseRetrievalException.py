from .ApiException import ApiException


class ApiResponseRetrievalException(ApiException):
    pass
