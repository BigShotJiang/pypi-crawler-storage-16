from enum import Enum


class ReturnType(str, Enum):
    Full = "FULL"
    Partial = "PARTIAL"
