"""pdf2md-ocr: Simple CLI tool to convert PDFs to Markdown using Marker AI."""

__version__ = "0.0.5"
