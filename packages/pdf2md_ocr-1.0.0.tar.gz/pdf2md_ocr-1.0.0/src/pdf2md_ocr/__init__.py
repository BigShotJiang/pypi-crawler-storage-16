"""pdf2md-ocr: Simple CLI tool to convert PDFs to Markdown using Marker AI."""

__version__ = "1.0.0"
