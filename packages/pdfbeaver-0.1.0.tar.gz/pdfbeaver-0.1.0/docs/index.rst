pdfbeaver documentation
=======================

.. toctree::
   :maxdepth: 2
   :caption: Tutorials

   tutorials/01_quickstart
   tutorials/02_text_redaction
   tutorials/03_vector_graphics

.. toctree::
   :maxdepth: 2
   :caption: API Reference

   api
