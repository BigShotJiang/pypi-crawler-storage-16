# pdftl Notices

This software is distributed under the Mozilla Public License 2.0.

## Third-Party Components

### OCRmyPDF

Portions of the `optimize_images` command are adapted from [OCRmyPDF](https://github.com/ocrmypdf/OCRmyPDF).

* **Original Author:** James R. Barlow
* **License:** Mozilla Public License 2.0
* **Copyright:** © 2022 James R. Barlow

The original source code can be found at <https://github.com/ocrmypdf/OCRmyPDF>.
