from typing import Dict
from typing import List
from typing import Union

SerializableAncestryRecordTypeDef = Dict[str, Union[str, List[str]]]
