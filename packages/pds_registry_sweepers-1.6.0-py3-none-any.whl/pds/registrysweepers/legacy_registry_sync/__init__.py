from .legacy_registry_sync import run  # noqa
