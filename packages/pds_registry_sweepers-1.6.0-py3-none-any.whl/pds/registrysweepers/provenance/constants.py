METADATA_SUCCESSOR_KEY = "ops:Provenance/ops:superseded_by"
