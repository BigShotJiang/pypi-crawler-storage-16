from pds.registrysweepers.utils.majorminorversion import MajorMinorVersion


class PdsVid(MajorMinorVersion):
    major_version_minimum = 0
    minor_version_minimum = 0
