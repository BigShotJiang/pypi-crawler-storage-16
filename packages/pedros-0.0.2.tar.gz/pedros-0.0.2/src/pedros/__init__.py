import logging
from pedros.logger import setup_logging

setup_logging(logging.INFO)