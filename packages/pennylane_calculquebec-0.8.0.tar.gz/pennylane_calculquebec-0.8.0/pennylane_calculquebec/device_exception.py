from pennylane_calculquebec.exceptions import DeviceError


class DeviceException(DeviceError):
    """Exception for device-related errors (legacy alias)."""

    pass
