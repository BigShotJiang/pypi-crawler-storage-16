ENV_NS = 'http://www.w3.org/2003/05/soap-envelope'

WSS_BASE = 'http://docs.oasis-open.org/wss/2004/01/'
WSSE_NS = WSS_BASE + 'oasis-200401-wss-wssecurity-secext-1.0.xsd'
WSU_NS = WSS_BASE + 'oasis-200401-wss-wssecurity-utility-1.0.xsd'
