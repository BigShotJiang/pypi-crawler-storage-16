# Test for valid AS4 xml

```
xmllint --schema xsd/multiple.xsd output.xml --noout
```
