"""Legacy setup.py shim that defers to pyproject.toml."""

from setuptools import setup

setup()
