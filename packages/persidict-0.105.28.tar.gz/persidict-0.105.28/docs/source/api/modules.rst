persidict
=========

.. toctree::
   :maxdepth: 4

   persidict
