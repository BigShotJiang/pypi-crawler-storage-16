# Preprocessing

```{eval-rst}
.. nbgallery::

   notebooks/guide_rna_assignment
```
