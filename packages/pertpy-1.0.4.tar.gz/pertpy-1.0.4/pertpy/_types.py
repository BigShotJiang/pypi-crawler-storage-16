from scipy import sparse

CSBase = sparse.csr_matrix | sparse.csc_matrix
CSRBase = sparse.csr_matrix
CSCBase = sparse.csc_matrix
SpBase = sparse.spmatrix
