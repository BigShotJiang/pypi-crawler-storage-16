# Generated from PetabMathExprParser.g4 by ANTLR 4.13.1
import sys

from antlr4 import *

if sys.version_info[1] > 5:
    from typing import TextIO
else:
    from typing.io import TextIO


def serializedATN():
    return [
        4,
        1,
        27,
        77,
        2,
        0,
        7,
        0,
        2,
        1,
        7,
        1,
        2,
        2,
        7,
        2,
        2,
        3,
        7,
        3,
        2,
        4,
        7,
        4,
        2,
        5,
        7,
        5,
        2,
        6,
        7,
        6,
        2,
        7,
        7,
        7,
        1,
        0,
        1,
        0,
        1,
        0,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        3,
        1,
        33,
        8,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        5,
        1,
        51,
        8,
        1,
        10,
        1,
        12,
        1,
        54,
        9,
        1,
        1,
        2,
        1,
        2,
        1,
        3,
        1,
        3,
        1,
        3,
        5,
        3,
        61,
        8,
        3,
        10,
        3,
        12,
        3,
        64,
        9,
        3,
        1,
        4,
        1,
        4,
        1,
        4,
        1,
        4,
        1,
        4,
        1,
        5,
        1,
        5,
        1,
        6,
        1,
        6,
        1,
        7,
        1,
        7,
        1,
        7,
        0,
        1,
        2,
        8,
        0,
        2,
        4,
        6,
        8,
        10,
        12,
        14,
        0,
        5,
        1,
        0,
        21,
        22,
        1,
        0,
        23,
        24,
        1,
        0,
        13,
        14,
        1,
        0,
        15,
        20,
        1,
        0,
        7,
        8,
        80,
        0,
        16,
        1,
        0,
        0,
        0,
        2,
        32,
        1,
        0,
        0,
        0,
        4,
        55,
        1,
        0,
        0,
        0,
        6,
        57,
        1,
        0,
        0,
        0,
        8,
        65,
        1,
        0,
        0,
        0,
        10,
        70,
        1,
        0,
        0,
        0,
        12,
        72,
        1,
        0,
        0,
        0,
        14,
        74,
        1,
        0,
        0,
        0,
        16,
        17,
        3,
        2,
        1,
        0,
        17,
        18,
        5,
        0,
        0,
        1,
        18,
        1,
        1,
        0,
        0,
        0,
        19,
        20,
        6,
        1,
        -1,
        0,
        20,
        21,
        7,
        0,
        0,
        0,
        21,
        33,
        3,
        2,
        1,
        11,
        22,
        23,
        5,
        26,
        0,
        0,
        23,
        33,
        3,
        2,
        1,
        10,
        24,
        25,
        5,
        11,
        0,
        0,
        25,
        26,
        3,
        2,
        1,
        0,
        26,
        27,
        5,
        12,
        0,
        0,
        27,
        33,
        1,
        0,
        0,
        0,
        28,
        33,
        3,
        12,
        6,
        0,
        29,
        33,
        3,
        10,
        5,
        0,
        30,
        33,
        3,
        8,
        4,
        0,
        31,
        33,
        3,
        14,
        7,
        0,
        32,
        19,
        1,
        0,
        0,
        0,
        32,
        22,
        1,
        0,
        0,
        0,
        32,
        24,
        1,
        0,
        0,
        0,
        32,
        28,
        1,
        0,
        0,
        0,
        32,
        29,
        1,
        0,
        0,
        0,
        32,
        30,
        1,
        0,
        0,
        0,
        32,
        31,
        1,
        0,
        0,
        0,
        33,
        52,
        1,
        0,
        0,
        0,
        34,
        35,
        10,
        12,
        0,
        0,
        35,
        36,
        5,
        25,
        0,
        0,
        36,
        51,
        3,
        2,
        1,
        12,
        37,
        38,
        10,
        9,
        0,
        0,
        38,
        39,
        7,
        1,
        0,
        0,
        39,
        51,
        3,
        2,
        1,
        10,
        40,
        41,
        10,
        8,
        0,
        0,
        41,
        42,
        7,
        0,
        0,
        0,
        42,
        51,
        3,
        2,
        1,
        9,
        43,
        44,
        10,
        6,
        0,
        0,
        44,
        45,
        3,
        4,
        2,
        0,
        45,
        46,
        3,
        2,
        1,
        7,
        46,
        51,
        1,
        0,
        0,
        0,
        47,
        48,
        10,
        5,
        0,
        0,
        48,
        49,
        7,
        2,
        0,
        0,
        49,
        51,
        3,
        2,
        1,
        6,
        50,
        34,
        1,
        0,
        0,
        0,
        50,
        37,
        1,
        0,
        0,
        0,
        50,
        40,
        1,
        0,
        0,
        0,
        50,
        43,
        1,
        0,
        0,
        0,
        50,
        47,
        1,
        0,
        0,
        0,
        51,
        54,
        1,
        0,
        0,
        0,
        52,
        50,
        1,
        0,
        0,
        0,
        52,
        53,
        1,
        0,
        0,
        0,
        53,
        3,
        1,
        0,
        0,
        0,
        54,
        52,
        1,
        0,
        0,
        0,
        55,
        56,
        7,
        3,
        0,
        0,
        56,
        5,
        1,
        0,
        0,
        0,
        57,
        62,
        3,
        2,
        1,
        0,
        58,
        59,
        5,
        27,
        0,
        0,
        59,
        61,
        3,
        2,
        1,
        0,
        60,
        58,
        1,
        0,
        0,
        0,
        61,
        64,
        1,
        0,
        0,
        0,
        62,
        60,
        1,
        0,
        0,
        0,
        62,
        63,
        1,
        0,
        0,
        0,
        63,
        7,
        1,
        0,
        0,
        0,
        64,
        62,
        1,
        0,
        0,
        0,
        65,
        66,
        5,
        10,
        0,
        0,
        66,
        67,
        5,
        11,
        0,
        0,
        67,
        68,
        3,
        6,
        3,
        0,
        68,
        69,
        5,
        12,
        0,
        0,
        69,
        9,
        1,
        0,
        0,
        0,
        70,
        71,
        7,
        4,
        0,
        0,
        71,
        11,
        1,
        0,
        0,
        0,
        72,
        73,
        5,
        1,
        0,
        0,
        73,
        13,
        1,
        0,
        0,
        0,
        74,
        75,
        5,
        10,
        0,
        0,
        75,
        15,
        1,
        0,
        0,
        0,
        4,
        32,
        50,
        52,
        62,
    ]


class PetabMathExprParser(Parser):
    grammarFileName = "PetabMathExprParser.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [DFA(ds, i) for i, ds in enumerate(atn.decisionToState)]

    sharedContextCache = PredictionContextCache()

    literalNames = [
        "<INVALID>",
        "<INVALID>",
        "<INVALID>",
        "<INVALID>",
        "<INVALID>",
        "<INVALID>",
        "<INVALID>",
        "'true'",
        "'false'",
        "'inf'",
        "<INVALID>",
        "'('",
        "')'",
        "'||'",
        "'&&'",
        "'>'",
        "'<'",
        "'>='",
        "'<='",
        "'=='",
        "'!='",
        "'+'",
        "'-'",
        "'*'",
        "'/'",
        "'^'",
        "'!'",
        "','",
    ]

    symbolicNames = [
        "<INVALID>",
        "NUMBER",
        "INTEGER",
        "EXPONENT_FLOAT",
        "POINT_FLOAT",
        "FLOAT_NUMBER",
        "WS",
        "TRUE",
        "FALSE",
        "INF",
        "NAME",
        "OPEN_PAREN",
        "CLOSE_PAREN",
        "BOOLEAN_OR",
        "BOOLEAN_AND",
        "GT",
        "LT",
        "GTE",
        "LTE",
        "EQ",
        "NEQ",
        "PLUS",
        "MINUS",
        "ASTERISK",
        "SLASH",
        "CARET",
        "EXCLAMATION_MARK",
        "COMMA",
    ]

    RULE_petabExpression = 0
    RULE_expr = 1
    RULE_comp_op = 2
    RULE_argumentList = 3
    RULE_functionCall = 4
    RULE_booleanLiteral = 5
    RULE_number = 6
    RULE_var = 7

    ruleNames = [
        "petabExpression",
        "expr",
        "comp_op",
        "argumentList",
        "functionCall",
        "booleanLiteral",
        "number",
        "var",
    ]

    EOF = Token.EOF
    NUMBER = 1
    INTEGER = 2
    EXPONENT_FLOAT = 3
    POINT_FLOAT = 4
    FLOAT_NUMBER = 5
    WS = 6
    TRUE = 7
    FALSE = 8
    INF = 9
    NAME = 10
    OPEN_PAREN = 11
    CLOSE_PAREN = 12
    BOOLEAN_OR = 13
    BOOLEAN_AND = 14
    GT = 15
    LT = 16
    GTE = 17
    LTE = 18
    EQ = 19
    NEQ = 20
    PLUS = 21
    MINUS = 22
    ASTERISK = 23
    SLASH = 24
    CARET = 25
    EXCLAMATION_MARK = 26
    COMMA = 27

    def __init__(self, input: TokenStream, output: TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.1")
        self._interp = ParserATNSimulator(
            self, self.atn, self.decisionsToDFA, self.sharedContextCache
        )
        self._predicates = None

    class PetabExpressionContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self,
            parser,
            parent: ParserRuleContext = None,
            invokingState: int = -1,
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expr(self):
            return self.getTypedRuleContext(PetabMathExprParser.ExprContext, 0)

        def EOF(self):
            return self.getToken(PetabMathExprParser.EOF, 0)

        def getRuleIndex(self):
            return PetabMathExprParser.RULE_petabExpression

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitPetabExpression"):
                return visitor.visitPetabExpression(self)
            else:
                return visitor.visitChildren(self)

    def petabExpression(self):
        localctx = PetabMathExprParser.PetabExpressionContext(
            self, self._ctx, self.state
        )
        self.enterRule(localctx, 0, self.RULE_petabExpression)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 16
            self.expr(0)
            self.state = 17
            self.match(PetabMathExprParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ExprContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self,
            parser,
            parent: ParserRuleContext = None,
            invokingState: int = -1,
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def getRuleIndex(self):
            return PetabMathExprParser.RULE_expr

        def copyFrom(self, ctx: ParserRuleContext):
            super().copyFrom(ctx)

    class PowerExprContext(ExprContext):
        def __init__(
            self, parser, ctx: ParserRuleContext
        ):  # actually a PetabMathExprParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i: int = None):
            if i is None:
                return self.getTypedRuleContexts(
                    PetabMathExprParser.ExprContext
                )
            else:
                return self.getTypedRuleContext(
                    PetabMathExprParser.ExprContext, i
                )

        def CARET(self):
            return self.getToken(PetabMathExprParser.CARET, 0)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitPowerExpr"):
                return visitor.visitPowerExpr(self)
            else:
                return visitor.visitChildren(self)

    class BooleanAndOrExprContext(ExprContext):
        def __init__(
            self, parser, ctx: ParserRuleContext
        ):  # actually a PetabMathExprParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i: int = None):
            if i is None:
                return self.getTypedRuleContexts(
                    PetabMathExprParser.ExprContext
                )
            else:
                return self.getTypedRuleContext(
                    PetabMathExprParser.ExprContext, i
                )

        def BOOLEAN_AND(self):
            return self.getToken(PetabMathExprParser.BOOLEAN_AND, 0)

        def BOOLEAN_OR(self):
            return self.getToken(PetabMathExprParser.BOOLEAN_OR, 0)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitBooleanAndOrExpr"):
                return visitor.visitBooleanAndOrExpr(self)
            else:
                return visitor.visitChildren(self)

    class ComparisonExprContext(ExprContext):
        def __init__(
            self, parser, ctx: ParserRuleContext
        ):  # actually a PetabMathExprParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i: int = None):
            if i is None:
                return self.getTypedRuleContexts(
                    PetabMathExprParser.ExprContext
                )
            else:
                return self.getTypedRuleContext(
                    PetabMathExprParser.ExprContext, i
                )

        def comp_op(self):
            return self.getTypedRuleContext(
                PetabMathExprParser.Comp_opContext, 0
            )

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitComparisonExpr"):
                return visitor.visitComparisonExpr(self)
            else:
                return visitor.visitChildren(self)

    class MultExprContext(ExprContext):
        def __init__(
            self, parser, ctx: ParserRuleContext
        ):  # actually a PetabMathExprParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i: int = None):
            if i is None:
                return self.getTypedRuleContexts(
                    PetabMathExprParser.ExprContext
                )
            else:
                return self.getTypedRuleContext(
                    PetabMathExprParser.ExprContext, i
                )

        def ASTERISK(self):
            return self.getToken(PetabMathExprParser.ASTERISK, 0)

        def SLASH(self):
            return self.getToken(PetabMathExprParser.SLASH, 0)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitMultExpr"):
                return visitor.visitMultExpr(self)
            else:
                return visitor.visitChildren(self)

    class BooleanLiteral_Context(ExprContext):
        def __init__(
            self, parser, ctx: ParserRuleContext
        ):  # actually a PetabMathExprParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def booleanLiteral(self):
            return self.getTypedRuleContext(
                PetabMathExprParser.BooleanLiteralContext, 0
            )

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitBooleanLiteral_"):
                return visitor.visitBooleanLiteral_(self)
            else:
                return visitor.visitChildren(self)

    class AddExprContext(ExprContext):
        def __init__(
            self, parser, ctx: ParserRuleContext
        ):  # actually a PetabMathExprParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i: int = None):
            if i is None:
                return self.getTypedRuleContexts(
                    PetabMathExprParser.ExprContext
                )
            else:
                return self.getTypedRuleContext(
                    PetabMathExprParser.ExprContext, i
                )

        def PLUS(self):
            return self.getToken(PetabMathExprParser.PLUS, 0)

        def MINUS(self):
            return self.getToken(PetabMathExprParser.MINUS, 0)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitAddExpr"):
                return visitor.visitAddExpr(self)
            else:
                return visitor.visitChildren(self)

    class BooleanNotExprContext(ExprContext):
        def __init__(
            self, parser, ctx: ParserRuleContext
        ):  # actually a PetabMathExprParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def EXCLAMATION_MARK(self):
            return self.getToken(PetabMathExprParser.EXCLAMATION_MARK, 0)

        def expr(self):
            return self.getTypedRuleContext(PetabMathExprParser.ExprContext, 0)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitBooleanNotExpr"):
                return visitor.visitBooleanNotExpr(self)
            else:
                return visitor.visitChildren(self)

    class ParenExprContext(ExprContext):
        def __init__(
            self, parser, ctx: ParserRuleContext
        ):  # actually a PetabMathExprParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def OPEN_PAREN(self):
            return self.getToken(PetabMathExprParser.OPEN_PAREN, 0)

        def expr(self):
            return self.getTypedRuleContext(PetabMathExprParser.ExprContext, 0)

        def CLOSE_PAREN(self):
            return self.getToken(PetabMathExprParser.CLOSE_PAREN, 0)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitParenExpr"):
                return visitor.visitParenExpr(self)
            else:
                return visitor.visitChildren(self)

    class FunctionCall_Context(ExprContext):
        def __init__(
            self, parser, ctx: ParserRuleContext
        ):  # actually a PetabMathExprParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def functionCall(self):
            return self.getTypedRuleContext(
                PetabMathExprParser.FunctionCallContext, 0
            )

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitFunctionCall_"):
                return visitor.visitFunctionCall_(self)
            else:
                return visitor.visitChildren(self)

    class UnaryExprContext(ExprContext):
        def __init__(
            self, parser, ctx: ParserRuleContext
        ):  # actually a PetabMathExprParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(PetabMathExprParser.ExprContext, 0)

        def PLUS(self):
            return self.getToken(PetabMathExprParser.PLUS, 0)

        def MINUS(self):
            return self.getToken(PetabMathExprParser.MINUS, 0)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitUnaryExpr"):
                return visitor.visitUnaryExpr(self)
            else:
                return visitor.visitChildren(self)

    class Number_Context(ExprContext):
        def __init__(
            self, parser, ctx: ParserRuleContext
        ):  # actually a PetabMathExprParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def number(self):
            return self.getTypedRuleContext(
                PetabMathExprParser.NumberContext, 0
            )

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitNumber_"):
                return visitor.visitNumber_(self)
            else:
                return visitor.visitChildren(self)

    class VarExpr_Context(ExprContext):
        def __init__(
            self, parser, ctx: ParserRuleContext
        ):  # actually a PetabMathExprParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def var(self):
            return self.getTypedRuleContext(PetabMathExprParser.VarContext, 0)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitVarExpr_"):
                return visitor.visitVarExpr_(self)
            else:
                return visitor.visitChildren(self)

    def expr(self, _p: int = 0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = PetabMathExprParser.ExprContext(
            self, self._ctx, _parentState
        )
        _prevctx = localctx
        _startState = 2
        self.enterRecursionRule(localctx, 2, self.RULE_expr, _p)
        self._la = 0  # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 32
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input, 0, self._ctx)
            if la_ == 1:
                localctx = PetabMathExprParser.UnaryExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 20
                _la = self._input.LA(1)
                if not (_la == 21 or _la == 22):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 21
                self.expr(11)
                pass

            elif la_ == 2:
                localctx = PetabMathExprParser.BooleanNotExprContext(
                    self, localctx
                )
                self._ctx = localctx
                _prevctx = localctx
                self.state = 22
                self.match(PetabMathExprParser.EXCLAMATION_MARK)
                self.state = 23
                self.expr(10)
                pass

            elif la_ == 3:
                localctx = PetabMathExprParser.ParenExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 24
                self.match(PetabMathExprParser.OPEN_PAREN)
                self.state = 25
                self.expr(0)
                self.state = 26
                self.match(PetabMathExprParser.CLOSE_PAREN)
                pass

            elif la_ == 4:
                localctx = PetabMathExprParser.Number_Context(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 28
                self.number()
                pass

            elif la_ == 5:
                localctx = PetabMathExprParser.BooleanLiteral_Context(
                    self, localctx
                )
                self._ctx = localctx
                _prevctx = localctx
                self.state = 29
                self.booleanLiteral()
                pass

            elif la_ == 6:
                localctx = PetabMathExprParser.FunctionCall_Context(
                    self, localctx
                )
                self._ctx = localctx
                _prevctx = localctx
                self.state = 30
                self.functionCall()
                pass

            elif la_ == 7:
                localctx = PetabMathExprParser.VarExpr_Context(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 31
                self.var()
                pass

            self._ctx.stop = self._input.LT(-1)
            self.state = 52
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input, 2, self._ctx)
            while _alt != 2 and _alt != ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 50
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(
                        self._input, 1, self._ctx
                    )
                    if la_ == 1:
                        localctx = PetabMathExprParser.PowerExprContext(
                            self,
                            PetabMathExprParser.ExprContext(
                                self, _parentctx, _parentState
                            ),
                        )
                        self.pushNewRecursionContext(
                            localctx, _startState, self.RULE_expr
                        )
                        self.state = 34
                        if not self.precpred(self._ctx, 12):
                            from antlr4.error.Errors import (
                                FailedPredicateException,
                            )

                            raise FailedPredicateException(
                                self, "self.precpred(self._ctx, 12)"
                            )
                        self.state = 35
                        self.match(PetabMathExprParser.CARET)
                        self.state = 36
                        self.expr(12)
                        pass

                    elif la_ == 2:
                        localctx = PetabMathExprParser.MultExprContext(
                            self,
                            PetabMathExprParser.ExprContext(
                                self, _parentctx, _parentState
                            ),
                        )
                        self.pushNewRecursionContext(
                            localctx, _startState, self.RULE_expr
                        )
                        self.state = 37
                        if not self.precpred(self._ctx, 9):
                            from antlr4.error.Errors import (
                                FailedPredicateException,
                            )

                            raise FailedPredicateException(
                                self, "self.precpred(self._ctx, 9)"
                            )
                        self.state = 38
                        _la = self._input.LA(1)
                        if not (_la == 23 or _la == 24):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 39
                        self.expr(10)
                        pass

                    elif la_ == 3:
                        localctx = PetabMathExprParser.AddExprContext(
                            self,
                            PetabMathExprParser.ExprContext(
                                self, _parentctx, _parentState
                            ),
                        )
                        self.pushNewRecursionContext(
                            localctx, _startState, self.RULE_expr
                        )
                        self.state = 40
                        if not self.precpred(self._ctx, 8):
                            from antlr4.error.Errors import (
                                FailedPredicateException,
                            )

                            raise FailedPredicateException(
                                self, "self.precpred(self._ctx, 8)"
                            )
                        self.state = 41
                        _la = self._input.LA(1)
                        if not (_la == 21 or _la == 22):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 42
                        self.expr(9)
                        pass

                    elif la_ == 4:
                        localctx = PetabMathExprParser.ComparisonExprContext(
                            self,
                            PetabMathExprParser.ExprContext(
                                self, _parentctx, _parentState
                            ),
                        )
                        self.pushNewRecursionContext(
                            localctx, _startState, self.RULE_expr
                        )
                        self.state = 43
                        if not self.precpred(self._ctx, 6):
                            from antlr4.error.Errors import (
                                FailedPredicateException,
                            )

                            raise FailedPredicateException(
                                self, "self.precpred(self._ctx, 6)"
                            )
                        self.state = 44
                        self.comp_op()
                        self.state = 45
                        self.expr(7)
                        pass

                    elif la_ == 5:
                        localctx = PetabMathExprParser.BooleanAndOrExprContext(
                            self,
                            PetabMathExprParser.ExprContext(
                                self, _parentctx, _parentState
                            ),
                        )
                        self.pushNewRecursionContext(
                            localctx, _startState, self.RULE_expr
                        )
                        self.state = 47
                        if not self.precpred(self._ctx, 5):
                            from antlr4.error.Errors import (
                                FailedPredicateException,
                            )

                            raise FailedPredicateException(
                                self, "self.precpred(self._ctx, 5)"
                            )
                        self.state = 48
                        _la = self._input.LA(1)
                        if not (_la == 13 or _la == 14):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 49
                        self.expr(6)
                        pass

                self.state = 54
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input, 2, self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class Comp_opContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self,
            parser,
            parent: ParserRuleContext = None,
            invokingState: int = -1,
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def GT(self):
            return self.getToken(PetabMathExprParser.GT, 0)

        def LT(self):
            return self.getToken(PetabMathExprParser.LT, 0)

        def GTE(self):
            return self.getToken(PetabMathExprParser.GTE, 0)

        def LTE(self):
            return self.getToken(PetabMathExprParser.LTE, 0)

        def EQ(self):
            return self.getToken(PetabMathExprParser.EQ, 0)

        def NEQ(self):
            return self.getToken(PetabMathExprParser.NEQ, 0)

        def getRuleIndex(self):
            return PetabMathExprParser.RULE_comp_op

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitComp_op"):
                return visitor.visitComp_op(self)
            else:
                return visitor.visitChildren(self)

    def comp_op(self):
        localctx = PetabMathExprParser.Comp_opContext(
            self, self._ctx, self.state
        )
        self.enterRule(localctx, 4, self.RULE_comp_op)
        self._la = 0  # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 55
            _la = self._input.LA(1)
            if not (((_la) & ~0x3F) == 0 and ((1 << _la) & 2064384) != 0):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ArgumentListContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self,
            parser,
            parent: ParserRuleContext = None,
            invokingState: int = -1,
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expr(self, i: int = None):
            if i is None:
                return self.getTypedRuleContexts(
                    PetabMathExprParser.ExprContext
                )
            else:
                return self.getTypedRuleContext(
                    PetabMathExprParser.ExprContext, i
                )

        def COMMA(self, i: int = None):
            if i is None:
                return self.getTokens(PetabMathExprParser.COMMA)
            else:
                return self.getToken(PetabMathExprParser.COMMA, i)

        def getRuleIndex(self):
            return PetabMathExprParser.RULE_argumentList

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitArgumentList"):
                return visitor.visitArgumentList(self)
            else:
                return visitor.visitChildren(self)

    def argumentList(self):
        localctx = PetabMathExprParser.ArgumentListContext(
            self, self._ctx, self.state
        )
        self.enterRule(localctx, 6, self.RULE_argumentList)
        self._la = 0  # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 57
            self.expr(0)
            self.state = 62
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la == 27:
                self.state = 58
                self.match(PetabMathExprParser.COMMA)
                self.state = 59
                self.expr(0)
                self.state = 64
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class FunctionCallContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self,
            parser,
            parent: ParserRuleContext = None,
            invokingState: int = -1,
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NAME(self):
            return self.getToken(PetabMathExprParser.NAME, 0)

        def OPEN_PAREN(self):
            return self.getToken(PetabMathExprParser.OPEN_PAREN, 0)

        def argumentList(self):
            return self.getTypedRuleContext(
                PetabMathExprParser.ArgumentListContext, 0
            )

        def CLOSE_PAREN(self):
            return self.getToken(PetabMathExprParser.CLOSE_PAREN, 0)

        def getRuleIndex(self):
            return PetabMathExprParser.RULE_functionCall

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitFunctionCall"):
                return visitor.visitFunctionCall(self)
            else:
                return visitor.visitChildren(self)

    def functionCall(self):
        localctx = PetabMathExprParser.FunctionCallContext(
            self, self._ctx, self.state
        )
        self.enterRule(localctx, 8, self.RULE_functionCall)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 65
            self.match(PetabMathExprParser.NAME)
            self.state = 66
            self.match(PetabMathExprParser.OPEN_PAREN)
            self.state = 67
            self.argumentList()
            self.state = 68
            self.match(PetabMathExprParser.CLOSE_PAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class BooleanLiteralContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self,
            parser,
            parent: ParserRuleContext = None,
            invokingState: int = -1,
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TRUE(self):
            return self.getToken(PetabMathExprParser.TRUE, 0)

        def FALSE(self):
            return self.getToken(PetabMathExprParser.FALSE, 0)

        def getRuleIndex(self):
            return PetabMathExprParser.RULE_booleanLiteral

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitBooleanLiteral"):
                return visitor.visitBooleanLiteral(self)
            else:
                return visitor.visitChildren(self)

    def booleanLiteral(self):
        localctx = PetabMathExprParser.BooleanLiteralContext(
            self, self._ctx, self.state
        )
        self.enterRule(localctx, 10, self.RULE_booleanLiteral)
        self._la = 0  # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 70
            _la = self._input.LA(1)
            if not (_la == 7 or _la == 8):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class NumberContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self,
            parser,
            parent: ParserRuleContext = None,
            invokingState: int = -1,
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NUMBER(self):
            return self.getToken(PetabMathExprParser.NUMBER, 0)

        def getRuleIndex(self):
            return PetabMathExprParser.RULE_number

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitNumber"):
                return visitor.visitNumber(self)
            else:
                return visitor.visitChildren(self)

    def number(self):
        localctx = PetabMathExprParser.NumberContext(
            self, self._ctx, self.state
        )
        self.enterRule(localctx, 12, self.RULE_number)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 72
            self.match(PetabMathExprParser.NUMBER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class VarContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self,
            parser,
            parent: ParserRuleContext = None,
            invokingState: int = -1,
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NAME(self):
            return self.getToken(PetabMathExprParser.NAME, 0)

        def getRuleIndex(self):
            return PetabMathExprParser.RULE_var

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitVar"):
                return visitor.visitVar(self)
            else:
                return visitor.visitChildren(self)

    def var(self):
        localctx = PetabMathExprParser.VarContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_var)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 74
            self.match(PetabMathExprParser.NAME)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    def sempred(self, localctx: RuleContext, ruleIndex: int, predIndex: int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[1] = self.expr_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expr_sempred(self, localctx: ExprContext, predIndex: int):
        if predIndex == 0:
            return self.precpred(self._ctx, 12)

        if predIndex == 1:
            return self.precpred(self._ctx, 9)

        if predIndex == 2:
            return self.precpred(self._ctx, 8)

        if predIndex == 3:
            return self.precpred(self._ctx, 6)

        if predIndex == 4:
            return self.precpred(self._ctx, 5)
