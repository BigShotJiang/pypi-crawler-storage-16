"""Handling of different model types supported by PEtab."""

from ...v1.models import *  # noqa: F401, F403
