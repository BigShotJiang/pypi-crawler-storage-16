"""PEtab model abstraction"""

from ...v1.models.model import *  # noqa: F401, F403
