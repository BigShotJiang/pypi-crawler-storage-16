# acme-demo-widget

A tiny demo package for testing the internal PyPI registry.

## Usage

```python
from acme_demo_widget import hello

print(hello("world"))
```

CLI:

```bash
acme-demo-hello world
```
