"""PetName and Distributed Directory Name resolver

Copyright 2025-2025 Kevin Steen <code at kevinsteen.net>
"""
#SPDX-License-Identifier: AGPL-3.0-or-later

from .petnames import *
from .version import version
