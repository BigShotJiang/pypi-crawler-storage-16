"""PetName and Distributed Directory Name resolver
SPDX-FileCopyrightText: Copyright 2025 Kevin Steen
SPDX-License-Identifier: AGPL-3.0-or-later
"""

version = "0.2.20251202"

