# petsc4py-stubs

Type stubs for [petsc4py](https://petsc.org/release/petsc4py/).

## Installation

```bash
pip install petsc4py-stubs
```

## Usage

After installation, type checkers like Pylance/Pyright and mypy will automatically use these stubs for `petsc4py`.