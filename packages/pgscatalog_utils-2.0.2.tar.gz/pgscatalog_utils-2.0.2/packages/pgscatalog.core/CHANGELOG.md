## v0.1.1 (2024-04-09)

* Add NCBI35 to GenomeBuild
* Disable concurrency in pgscatalog-combine to prevent memory usage explosion (will be fixed and re-enabled later)
* Fix handling scoring file cases when only one optional effect type column is present
* Fix reading pvar files with complex headers (like ones made from a VCF)

## v0.1.0 (2024-03-22)

Initial release.
