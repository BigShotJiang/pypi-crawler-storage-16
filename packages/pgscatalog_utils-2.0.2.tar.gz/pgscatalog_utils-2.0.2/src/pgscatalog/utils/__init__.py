import importlib.metadata

__version__ = importlib.metadata.version("pgscatalog.utils")

# intentionally empty :)
#     |\__/,|   (`\
#   _.|o o  |_   ) )
# -(((---(((--------
