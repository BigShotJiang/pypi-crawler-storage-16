__version__ = "2.1.1"
__author__ = "RedLight Team"
__description__ = "RedLight DL - Professional adult content downloader with CLI & API"

