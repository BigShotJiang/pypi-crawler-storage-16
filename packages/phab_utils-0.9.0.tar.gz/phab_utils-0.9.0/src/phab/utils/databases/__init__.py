"""
.. include:: ../../../../documentation/utils/databases/index.md
"""

# from . import tap
# from .tap import *

# don't forget to fill the __all__ list in the tap.py
# __all__ = tap.__all__

# if the stuff above is done, then in consuming scripts one can use,
# for example:
# import phab.utils.databases as phud
