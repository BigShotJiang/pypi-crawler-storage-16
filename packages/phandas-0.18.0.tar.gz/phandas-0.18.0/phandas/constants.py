"""Module-level constants for phandas."""

EPSILON = 1e-10
TOLERANCE_FLOAT = 1e-6

SIGNAL_LONG_SUM = 0.5
SIGNAL_SHORT_SUM = -0.5
SIGNAL_TOLERANCE = 1e-2

MIN_NOTIONAL_USD = 0.01
MIN_TRADE_VALUE = 1.0

MATRIX_COND_THRESHOLD = 1e10

SYMBOL_RENAMES = {
    'POL': {
        'old_symbol': 'MATIC',
        'new_symbol': 'POL',
        'cutoff_date': '2024-09-01',
    }
}

GROUP_DEFINITIONS = {
    'SECTOR_L1_L2': {
        'ETH': 1, 'SOL': 1, 'SUI': 1,  # Group 1: L1
        'ARB': 2, 'OP': 2,  'POL': 2   # Group 2: L2

    },
    'DAPP_ACTIVITY': {
        'POL': 1, 'ETH': 1, 'ARB': 1, 'OP': 1, # Group 1: High TVL/Dapps
        'SUI': 2, 'SOL': 2                     # Group 2: Growth/Alt
    }
}
