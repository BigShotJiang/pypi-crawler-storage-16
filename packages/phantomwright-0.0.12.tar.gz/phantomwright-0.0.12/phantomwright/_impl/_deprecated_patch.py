"""Wrapper classes to mark add_init_script as deprecated with full IDE support.

This module wraps the entire Playwright class hierarchy so that IDE type inference
works correctly through the entire call chain:
async_playwright() -> Playwright -> BrowserType -> Browser -> BrowserContext -> Page
"""

import pathlib
from typing import TYPE_CHECKING, Callable, Optional, Union

if TYPE_CHECKING:
    from typing_extensions import deprecated
else:
    # No-op decorator at runtime (no warning, just for IDE support)
    def deprecated(message: str) -> Callable:
        def decorator(func: Callable) -> Callable:
            return func
        return decorator

from phantomwright_driver.async_api import (
    Playwright as AsyncPlaywrightBase,
    BrowserType as AsyncBrowserTypeBase,
    Browser as AsyncBrowserBase,
    BrowserContext as AsyncBrowserContextBase,
    Page as AsyncPageBase,
)
from phantomwright_driver.async_api._context_manager import (
    PlaywrightContextManager as AsyncPlaywrightContextManagerBase,
)
from phantomwright_driver.sync_api import (
    Playwright as SyncPlaywrightBase,
    BrowserType as SyncBrowserTypeBase,
    Browser as SyncBrowserBase,
    BrowserContext as SyncBrowserContextBase,
    Page as SyncPageBase,
)
from phantomwright_driver.sync_api._context_manager import (
    PlaywrightContextManager as SyncPlaywrightContextManagerBase,
)

_DEPRECATION_MESSAGE = "phantomwright.add_init_script doesn't fully align with playwright.add_init_script, please ensure you understand the differences before using it."


# =============================================================================
# Async API Wrappers
# =============================================================================

class AsyncPage(AsyncPageBase):
    """Async Page with deprecated add_init_script."""

    @deprecated(_DEPRECATION_MESSAGE)
    async def add_init_script(
        self,
        script: Optional[str] = None,
        *,
        path: Optional[Union[pathlib.Path, str]] = None,
    ) -> None:
        """Add a script to be evaluated before other scripts.

        .. warning::
            phantomwright.add_init_script differs from playwright.add_init_script:

            1\. **Cannot call exposed bindings**: Init scripts execute before bindings
               from expose_function/expose_binding are available.

               .. code-block:: python

                   # Won't work:
                   await context.expose_function("woof", lambda arg: print(arg))
                   await context.add_init_script("woof('hello')")  # Error: woof is not defined

            2\. **Does not affect special URLs**: Scripts won't run on about:blank,
               data: URIs, or file:// URLs because patchright uses routing-based
               injection which these URLs don't trigger.
        """
        return await super().add_init_script(script, path=path)


class AsyncBrowserContext(AsyncBrowserContextBase):
    """Async BrowserContext with deprecated add_init_script."""

    @deprecated(_DEPRECATION_MESSAGE)
    async def add_init_script(
        self,
        script: Optional[str] = None,
        *,
        path: Optional[Union[pathlib.Path, str]] = None,
    ) -> None:
        """Add a script to be evaluated before other scripts.

        .. warning::
            phantomwright.add_init_script differs from playwright.add_init_script:

            1\. **Cannot call exposed bindings**: Init scripts execute before bindings
               from expose_function/expose_binding are available.

               .. code-block:: python

                   # Won't work:
                   await context.expose_function("woof", lambda arg: print(arg))
                   await context.add_init_script("woof('hello')")  # Error: woof is not defined

            2\. **Does not affect special URLs**: Scripts won't run on about:blank,
               data: URIs, or file:// URLs because patchright uses routing-based
               injection which these URLs don't trigger.
        """
        return await super().add_init_script(script, path=path)


    async def new_page(self) -> "AsyncPage":
        """Creates a new page in the browser context."""
        page = await super().new_page()
        # Change the class of the returned page to our wrapper
        page.__class__ = AsyncPage
        return page  # type: ignore


class AsyncBrowser(AsyncBrowserBase):
    """Async Browser that returns wrapped BrowserContext."""

    async def new_context(self, **kwargs) -> "AsyncBrowserContext":
        """Creates a new browser context."""
        context = await super().new_context(**kwargs)
        context.__class__ = AsyncBrowserContext
        return context  # type: ignore

    async def new_page(self, **kwargs) -> "AsyncPage":
        """Creates a new page in a new browser context."""
        page = await super().new_page(**kwargs)
        page.__class__ = AsyncPage
        return page  # type: ignore


class AsyncBrowserType(AsyncBrowserTypeBase):
    """Async BrowserType that returns wrapped Browser."""

    async def launch(self, **kwargs) -> "AsyncBrowser":
        """Returns the browser instance."""
        browser = await super().launch(**kwargs)
        browser.__class__ = AsyncBrowser
        return browser  # type: ignore

    async def launch_persistent_context(
        self, user_data_dir: Union[str, pathlib.Path], **kwargs
    ) -> "AsyncBrowserContext":
        """Returns the persistent browser context instance."""
        context = await super().launch_persistent_context(user_data_dir, **kwargs)
        context.__class__ = AsyncBrowserContext
        return context  # type: ignore

    async def connect(self, ws_endpoint: str, **kwargs) -> "AsyncBrowser":
        """Connects to an existing browser instance."""
        browser = await super().connect(ws_endpoint, **kwargs)
        browser.__class__ = AsyncBrowser
        return browser  # type: ignore

    async def connect_over_cdp(self, endpoint_url: str, **kwargs) -> "AsyncBrowser":
        """Connects to an existing browser instance over CDP."""
        browser = await super().connect_over_cdp(endpoint_url, **kwargs)
        browser.__class__ = AsyncBrowser
        return browser  # type: ignore


class AsyncPlaywright(AsyncPlaywrightBase):
    """Async Playwright that returns wrapped BrowserTypes."""

    @property
    def chromium(self) -> "AsyncBrowserType":
        """Returns Chromium browser type."""
        browser_type = super().chromium
        browser_type.__class__ = AsyncBrowserType
        return browser_type  # type: ignore


class AsyncPlaywrightContextManager(AsyncPlaywrightContextManagerBase):
    """Async context manager that returns wrapped Playwright."""

    async def __aenter__(self) -> "AsyncPlaywright":
        playwright = await super().__aenter__()
        playwright.__class__ = AsyncPlaywright
        return playwright  # type: ignore


def async_playwright() -> AsyncPlaywrightContextManager:
    """Returns an async context manager for Playwright."""
    return AsyncPlaywrightContextManager()


# =============================================================================
# Sync API Wrappers
# =============================================================================

class SyncPage(SyncPageBase):
    """Sync Page with deprecated add_init_script."""

    @deprecated(_DEPRECATION_MESSAGE)
    def add_init_script(
        self,
        script: Optional[str] = None,
        *,
        path: Optional[Union[pathlib.Path, str]] = None,
    ) -> None:
        """Add a script to be evaluated before other scripts.

        .. warning::
            phantomwright.add_init_script differs from playwright.add_init_script:

            1\. **Cannot call exposed bindings**: Init scripts execute before bindings
               from expose_function/expose_binding are available.

               .. code-block:: python

                   # Won't work:
                   context.expose_function("woof", lambda arg: print(arg))
                   context.add_init_script("woof('hello')")  # Error: woof is not defined

            2\. **Does not affect special URLs**: Scripts won't run on about:blank,
               data: URIs, or file:// URLs because patchright uses routing-based
               injection which these URLs don't trigger.
        """
        return super().add_init_script(script, path=path)


class SyncBrowserContext(SyncBrowserContextBase):
    """Sync BrowserContext with deprecated add_init_script."""

    @deprecated(_DEPRECATION_MESSAGE)
    def add_init_script(
        self,
        script: Optional[str] = None,
        *,
        path: Optional[Union[pathlib.Path, str]] = None,
    ) -> None:
        """Add a script to be evaluated before other scripts.

        .. warning::
            phantomwright.add_init_script differs from playwright.add_init_script:

            1\. **Cannot call exposed bindings**: Init scripts execute before bindings
               from expose_function/expose_binding are available.

               .. code-block:: python

                   # Won't work:
                   context.expose_function("woof", lambda arg: print(arg))
                   context.add_init_script("woof('hello')")  # Error: woof is not defined

            2\. **Does not affect special URLs**: Scripts won't run on about:blank,
               data: URIs, or file:// URLs because patchright uses routing-based
               injection which these URLs don't trigger.
        """
        return super().add_init_script(script, path=path)


    def new_page(self) -> "SyncPage":
        """Creates a new page in the browser context."""
        page = super().new_page()
        page.__class__ = SyncPage
        return page  # type: ignore


class SyncBrowser(SyncBrowserBase):
    """Sync Browser that returns wrapped BrowserContext."""

    def new_context(self, **kwargs) -> "SyncBrowserContext":
        """Creates a new browser context."""
        context = super().new_context(**kwargs)
        context.__class__ = SyncBrowserContext
        return context  # type: ignore

    def new_page(self, **kwargs) -> "SyncPage":
        """Creates a new page in a new browser context."""
        page = super().new_page(**kwargs)
        page.__class__ = SyncPage
        return page  # type: ignore


class SyncBrowserType(SyncBrowserTypeBase):
    """Sync BrowserType that returns wrapped Browser."""

    def launch(self, **kwargs) -> "SyncBrowser":
        """Returns the browser instance."""
        browser = super().launch(**kwargs)
        browser.__class__ = SyncBrowser
        return browser  # type: ignore

    def launch_persistent_context(
        self, user_data_dir: Union[str, pathlib.Path], **kwargs
    ) -> "SyncBrowserContext":
        """Returns the persistent browser context instance."""
        context = super().launch_persistent_context(user_data_dir, **kwargs)
        context.__class__ = SyncBrowserContext
        return context  # type: ignore

    def connect(self, ws_endpoint: str, **kwargs) -> "SyncBrowser":
        """Connects to an existing browser instance."""
        browser = super().connect(ws_endpoint, **kwargs)
        browser.__class__ = SyncBrowser
        return browser  # type: ignore

    def connect_over_cdp(self, endpoint_url: str, **kwargs) -> "SyncBrowser":
        """Connects to an existing browser instance over CDP."""
        browser = super().connect_over_cdp(endpoint_url, **kwargs)
        browser.__class__ = SyncBrowser
        return browser  # type: ignore


class SyncPlaywright(SyncPlaywrightBase):
    """Sync Playwright that returns wrapped BrowserTypes."""

    @property
    def chromium(self) -> "SyncBrowserType":
        """Returns Chromium browser type."""
        browser_type = super().chromium
        browser_type.__class__ = SyncBrowserType
        return browser_type  # type: ignore


class SyncPlaywrightContextManager(SyncPlaywrightContextManagerBase):
    """Sync context manager that returns wrapped Playwright."""

    def __enter__(self) -> "SyncPlaywright":
        playwright = super().__enter__()
        playwright.__class__ = SyncPlaywright
        return playwright  # type: ignore


def sync_playwright() -> SyncPlaywrightContextManager:
    """Returns a sync context manager for Playwright."""
    return SyncPlaywrightContextManager()


__all__ = [
    # Async
    "AsyncPage",
    "AsyncBrowserContext",
    "AsyncBrowser",
    "AsyncBrowserType",
    "AsyncPlaywright",
    "AsyncPlaywrightContextManager",
    "async_playwright",
    # Sync
    "SyncPage",
    "SyncBrowserContext",
    "SyncBrowser",
    "SyncBrowserType",
    "SyncPlaywright",
    "SyncPlaywrightContextManager",
    "sync_playwright",
]
