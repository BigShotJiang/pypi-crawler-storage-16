"""
Patchright + Stealth Plugin + User Behavior Simulation = PhantomWright
"""

from ._impl import _core_debug_patch, _evaluate_patch

_evaluate_patch.do_patch()
_core_debug_patch.do_patch()