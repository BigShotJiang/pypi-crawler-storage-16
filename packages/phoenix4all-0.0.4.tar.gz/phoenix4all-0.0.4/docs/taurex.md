# TauREx-Plugin

This plugin integrates the [TauREx 3](https://taurex3.readthedocs.io) atmospheric retrieval framework with the Phoenix stellar atmosphere models, allowing users to incorporate detailed stellar spectra into their exoplanet atmosphere simulations and analyses.
