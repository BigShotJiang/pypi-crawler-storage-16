from .cli.phonon_to_json_main import main

main()