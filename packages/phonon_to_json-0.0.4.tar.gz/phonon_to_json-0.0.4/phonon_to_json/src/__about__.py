# SPDX-FileCopyrightText: 2023-present Peter Byrne <peter.byrne@york.ac.uk>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.4"
