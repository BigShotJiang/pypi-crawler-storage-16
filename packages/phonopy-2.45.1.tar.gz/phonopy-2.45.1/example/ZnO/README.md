# Phonon calculation of ZnO with 2x2x2 supercell

Forces were calculated using VASP with 500 eV cutoff energy and 6x6x4 k-point
mesh for the unit cell.

Character table is shown by

```bash
% phonopy-load --irreps 0 0 0
```
