# -*- coding: utf-8 -*-
# flake8: noqa

"""Statistics functions."""

from .ccg import correlograms, firing_rate
