import unittest


class BaseTest(unittest.TestCase):
    def test_base(self):
        self.assertEqual(1, 1)
