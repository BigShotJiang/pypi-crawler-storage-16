from phylogenie.io.fasta import load_fasta

__all__ = ["load_fasta"]
