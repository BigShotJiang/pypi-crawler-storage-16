from setuptools import setup, find_packages

setup(
    name="physics_x_optics_cbse",
    version="1.0.0",
    packages=find_packages(),
    description="Class 10 CBSE Optics Helper Library",
    author="Dinesh_Pandiyan_B",
    author_email="rajadineshp@gmail.com"
)
