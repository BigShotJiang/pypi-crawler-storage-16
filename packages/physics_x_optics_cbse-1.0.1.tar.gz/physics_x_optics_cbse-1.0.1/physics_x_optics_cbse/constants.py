C = 3.0 * 10**8  # Speed of light in vacuum
N_AIR = 1.0  # Refractive index of air
