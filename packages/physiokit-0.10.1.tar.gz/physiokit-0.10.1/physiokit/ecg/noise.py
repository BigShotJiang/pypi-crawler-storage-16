"""ECG noise source algorithms."""
