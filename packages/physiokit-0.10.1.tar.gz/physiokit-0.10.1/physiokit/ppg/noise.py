"""PPG noise source algorithms."""
