"""RSP noise source algorithms."""
