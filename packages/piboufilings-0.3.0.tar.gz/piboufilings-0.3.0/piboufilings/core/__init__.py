"""
Core package for piboufilings.
"""

from .downloader import SECDownloader

__all__ = ['SECDownloader']
