# 1.0.0 (2025-12-11)


### Features

* add SharePoint download module ([f5fdb98](https://github.com/opencitations/piccione/commit/f5fdb98f236897cd21996c6e4a73f5da744261dc))
* add upload and download modules for external services ([c81f36c](https://github.com/opencitations/piccione/commit/c81f36cf349c088a71b4ee250ccae05a2bc5bdf5))
* initial project setup ([5915b8d](https://github.com/opencitations/piccione/commit/5915b8d6599aa8d32ca54f43c2f2fa1dd12eb68d))

# Changelog

All notable changes to this project will be documented in this file.
