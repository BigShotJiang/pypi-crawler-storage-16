import abc
from collections.abc import Iterable, Mapping
from typing import IO, Any

DATA_TYPE = str | bytes | Mapping[str, Any] | Iterable[tuple[str, str, None]] | IO


class AbstractServiceConnexion(abc.ABC):
    @abc.abstractmethod
    def get(self, path: str, params: dict | None = None, stream: bool = False):
        pass

    @abc.abstractmethod
    def xget(
        self,
        path: str,
        data: DATA_TYPE | None = None,
        params: dict | None = None,
        stream=False,
    ):
        pass

    @abc.abstractmethod
    def post(
        self,
        path: str,
        data: DATA_TYPE | None = None,
        params: dict | None = None,
        files: Any = None,
    ):
        pass

    @abc.abstractmethod
    def patch(
        self,
        path: str,
        data: DATA_TYPE | None = None,
        params: dict | None = None,
    ):
        pass

    @abc.abstractmethod
    def put(
        self,
        path: str,
        data: DATA_TYPE | None = None,
        params: dict | None = None,
    ):
        pass

    @abc.abstractmethod
    def delete(
        self,
        path: str,
        data: DATA_TYPE | None = None,
        params: dict | None = None,
    ):
        pass
