from requests.models import Response

from picsellia_connexion_services.abstract_cached_connexions import (
    AbstractCachedConnexions,
)
from picsellia_connexion_services.mock_service_connexion import MockServiceConnexion


class MockCachedConnexions(AbstractCachedConnexions):
    def __init__(self) -> None:
        self.connexions: dict[str, MockServiceConnexion] = {}
        self.default_host = "localhost"
        self.default_api_token = "random_token"

    def get(self, host: str, api_token: str | None = None) -> MockServiceConnexion:
        if host in self.connexions:
            return self.connexions[host]

        self.connexions[host] = self._new_connexion()
        return self.connexions[host]

    def get_default(self) -> MockServiceConnexion:
        return self.get(self.default_host)

    @staticmethod
    def _new_connexion() -> MockServiceConnexion:
        mock_client = MockServiceConnexion()
        fake_resp = Response()
        fake_resp._content = {"success": "ok"}
        fake_resp.status_code = 200
        mock_client.set_default_response("get", fake_resp)
        mock_client.set_default_response("post", fake_resp)
        mock_client.set_default_response("put", fake_resp)
        mock_client.set_default_response("delete", fake_resp)
        mock_client.set_default_response("patch", fake_resp)
        return mock_client

    def reset(self, host: str) -> None:
        if host not in self.connexions:
            return

        del self.connexions[host]
