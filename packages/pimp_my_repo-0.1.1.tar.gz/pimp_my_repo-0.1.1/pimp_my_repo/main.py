def main() -> None:
    print("Right now, there is no pimping going on.")  # noqa: T201


if __name__ == "__main__":
    main()
