# CHANGELOG

<!-- version list -->

## v0.1.2 (2025-12-10)

### 🏗️

- 🏗️ Add CI jobs
  ([`df82209`](https://github.com/asaf-kali/pimp-my-repo/commit/df82209977ca400760dc2ff1442470e08c4137db))

### 🛠️

- 🛠️ Add build and release commands
  ([`5a8cb36`](https://github.com/asaf-kali/pimp-my-repo/commit/5a8cb36457de25a8421e8fcc3bbafea5c633c9e5))


## v0.1.1 (2025-12-09)

### ✨

- ✨ Migrate to UV
  ([`ba15840`](https://github.com/asaf-kali/pimp-my-repo/commit/ba158400a9f7e373f2723d12cd60f796ead8bcf6))

### 📜

- 📜 Adjust README
  ([`bb8231b`](https://github.com/asaf-kali/pimp-my-repo/commit/bb8231b90df3840bc2fb12ddbf248597a22de7e2))


## v0.1.0 (2025-12-10)

- Initial Release
