def test_import_is_working() -> None:
    import pimp_my_repo.main  # noqa: F401, PLC0415
