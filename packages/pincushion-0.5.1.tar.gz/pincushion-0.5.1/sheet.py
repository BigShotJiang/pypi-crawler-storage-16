#!/usr/bin/env python3

import csv
import json
import re
import sys
import pandas
import html

data = json.load(open('2025-summer-institute/data.json'))

pin_cids = {}
for line in open('2025-summer-institute.log'):
    if m := re.match(r'^added (.+) 2025-summer-institute/pins/(\d+)\/.*(jpg|mp3|mp4)$', line):
        cid, pin_id, file_type = m.groups()
        pin_cids[int(pin_id)] = {"cid": cid, "file_type": file_type}

df = pandas.read_csv('sheet.csv', index_col="Collection ID")

output = csv.writer(sys.stdout)

coll_pin_ids = {}
collections = {}
output.writerow(['collection_title', 'pin_title', 'pin_id', 'file_type', 'cid', 'url'])
for collection in data['collections']:
    coll_slug = collection['slug']
    collections[coll_slug] = collection

    if coll_slug not in coll_pin_ids:
        coll_pin_ids[coll_slug] = set()

    for pin in collection['pins']:
        pin_id = pin['id']
        coll_pin_ids[coll_slug].add(pin_id)

def strip(text):
    if text:
        text = html.unescape(re.sub('<[^<]+?>', '', text)).strip()
        text = re.sub(r' +', ' ', text)
    return text

for coll_slug, pin_ids in coll_pin_ids.items():
    if coll_slug not in df.index:
        print(f"missing {coll_slug}")
        continue

    coll = collections[coll_slug]

    cids = []
    for pin_id in pin_ids:
        if pin_id not in pin_cids:
            print(f"{pin_id} seems to be missing from pin_cids?")
            continue
        cid = pin_cids[pin_id]['cid']
        cids.append(cid)

    df.at[coll_slug, 'Title'] = coll['title']
    df.at[coll_slug, 'CIDs'] = ', '.join(map(str, cids))
    df.at[coll_slug, 'Description'] = strip(coll['description']) or strip(coll['short_description'])
    df.at[coll_slug, 'IPFS Gateway URL'] = f'https://shifted-edsu.tail1f6477.ts.net/ipfs/QmSNC77puVAreonpj1pZpWTr9Yj2HKCag6UVaEBgBdgUh8/collections/{coll_slug}/index.html'

df.to_csv('sheet2.csv')
