
"""
Main module entry point for python -m pingera_cli execution
"""

if __name__ == "__main__":
    from .main import cli_entry_point
    cli_entry_point()
