# -*- coding: utf-8 -*-
from __future__ import annotations

from pioreactor.version import __version__  # noqa: F401
