from enum import Enum


class SequenceDocumentKind(Enum):
    DNA = 'DNA'
    RNA = 'RNA'
    AA = 'AA'
