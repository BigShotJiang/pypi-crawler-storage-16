## `pipefunc.map.adaptive_scheduler` module

```{eval-rst}
.. automodule:: pipefunc.map.adaptive_scheduler
    :members:
    :undoc-members:
    :show-inheritance:
```
