## `pipefunc` module

```{eval-rst}
.. automodule:: pipefunc
    :members:
    :undoc-members:
    :show-inheritance:
```
