## `pipefunc.resources` module

```{eval-rst}
.. automodule:: pipefunc.resources
    :members:
    :undoc-members:
    :show-inheritance:
```
