## `pipefunc.sweep` module

```{eval-rst}
.. automodule:: pipefunc.sweep
    :members:
    :undoc-members:
    :show-inheritance:
```
