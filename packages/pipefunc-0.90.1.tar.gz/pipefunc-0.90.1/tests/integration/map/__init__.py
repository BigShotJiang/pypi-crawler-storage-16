"""Integration tests for map-related behavior."""
