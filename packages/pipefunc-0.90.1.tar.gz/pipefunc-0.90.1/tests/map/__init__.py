"""Tests for pipefunc.map."""
