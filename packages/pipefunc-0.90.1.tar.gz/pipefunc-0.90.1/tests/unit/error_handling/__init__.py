"""Unit tests for error_handling."""
