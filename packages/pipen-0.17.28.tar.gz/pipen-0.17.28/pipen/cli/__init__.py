"""Provide CLI for pipen"""

from ._hooks import CLIPlugin
from ._main import main
