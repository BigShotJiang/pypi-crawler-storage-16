# Releasing Pipenv

To create a new release:

```
pipenv run invoke release.release
```
