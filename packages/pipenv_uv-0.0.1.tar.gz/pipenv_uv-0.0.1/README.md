# pipenv-uv

[![PyPI - Version](https://img.shields.io/pypi/v/pipenv-uv.svg)](https://pypi.org/project/pipenv-uv)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pipenv-uv.svg)](https://pypi.org/project/pipenv-uv)
[![pre-commit.ci status](https://results.pre-commit.ci/badge/github/FlavioAmurrioCS/pipenv-uv/main.svg)](https://results.pre-commit.ci/latest/github/FlavioAmurrioCS/pipenv-uv/main)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install pipenv-uv
```

## License

`pipenv-uv` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
