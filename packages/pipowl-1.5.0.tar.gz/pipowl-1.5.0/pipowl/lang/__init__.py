from .lang import LangOwl

__all__ = ["LangOwl"]