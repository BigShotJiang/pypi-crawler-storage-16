#!/usr/bin/env python3
import lib

input()
print(max(lib.read_ints()))
