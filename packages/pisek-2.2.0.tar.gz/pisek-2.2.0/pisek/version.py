__version__ = "2.2.0"


def print_version() -> None:
    print(f"Pisek {__version__}")
