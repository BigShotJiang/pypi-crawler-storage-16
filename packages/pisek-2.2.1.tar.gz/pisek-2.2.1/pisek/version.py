__version__ = "2.2.1"


def print_version() -> None:
    print(f"Pisek {__version__}")
