#!/usr/bin/env python3
a, b = [int(x) for x in input().split()]
print(a + b, end="")
