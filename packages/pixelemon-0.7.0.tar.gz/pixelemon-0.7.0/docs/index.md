# PixeLemon

[Citra Space Corporation's](https://www.citra.space) basic image processing for satellite detection in starfields.

## Installation

PixeLemon is hosted on PyPI and can be installed using `pip install pixelemon`.

!!! warning
    Your python version must be 3.9 to 3.12

## Quick Start Example

```python

from keplemon.bodies import Constellation
from keplemon.catalogs import TLECatalog
from pixelemon.sensors import BaseSensor
from pixelemon.optics import BaseOpticalAssembly
from pixelemon import Telescope, TelescopeImage
from pathlib import Path

tles = TLECatalog.from_file("tles-near-img-epoch.txt")
sats = Constellation.from_tle_catalog(tles)

optics = BaseOpticalAssembly(
    image_circle_diameter=35.0, # This is the image plane diameter in mm (NOT aperture)
    focal_length=200.0,         # Focal length in mm
    focal_ratio=2.0,            # Focal ratio (f/number)
)

sensor = BaseSensor(
    pixel_height=3.76,          # Pixel height in micrometers
    pixel_width=3.76,           # Pixel width in micrometers
    x_pixel_count=4000,         # Number of pixels in the x direction
    y_pixel_count=3000,         # Number of pixels in the y direction
)

telescope = Telescope(
    sensor=sensor,
    optics=optics,
)

img = TelescopeImage.from_fits_file(Path("example_image.fits"), telescope=telescope)
obs = img.get_observations(sats)
```
