# Package Contents

::: pixelemon

## Submodules

- [correlation](correlation.md)
- [optics](optics.md)
- [processing](processing.md)
- [sensors](sensors.md)
