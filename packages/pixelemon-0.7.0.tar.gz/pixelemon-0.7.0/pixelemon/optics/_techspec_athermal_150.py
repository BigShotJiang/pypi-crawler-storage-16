from pixelemon.constants import INCHES_TO_MILLIMETERS
from pixelemon.optics._base_optical_assembly import BaseOpticalAssembly


class TechSpecAthermal150(BaseOpticalAssembly):
    focal_length: float = 150.0
    focal_ratio: float = 4.0
    image_circle_diameter: float = 1.2 * INCHES_TO_MILLIMETERS
