from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, RootModel


class PixeLemonObservation(BaseModel):

    satellite_id: UUID
    epoch: datetime
    right_ascension: float
    declination: float
    sensor_latitude: float
    sensor_longitude: float
    sensor_altitude: float
    angular_noise: float
    visual_magnitude: float


class PixeLemonObservations(RootModel[list[PixeLemonObservation]]):

    def __len__(self) -> int:
        return len(self.root)

    def __getitem__(self, index: int) -> PixeLemonObservation:
        return self.root[index]

    def __iter__(self):
        return iter(self.root)
