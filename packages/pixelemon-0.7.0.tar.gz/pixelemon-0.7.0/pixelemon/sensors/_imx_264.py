from pixelemon.sensors._base_sensor import BaseSensor


class IMX264(BaseSensor):
    x_pixel_count: int = 2448
    y_pixel_count: int = 2048
    pixel_width: float = 3.45
    pixel_height: float = 3.45
