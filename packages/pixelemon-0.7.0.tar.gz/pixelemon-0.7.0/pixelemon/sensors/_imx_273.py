from pixelemon.sensors._base_sensor import BaseSensor


class IMX273(BaseSensor):
    x_pixel_count: int = 1440
    y_pixel_count: int = 1080
    pixel_width: float = 3.45
    pixel_height: float = 3.45
