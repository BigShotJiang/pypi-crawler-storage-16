from __future__ import annotations

import sqlalchemy as sql

import pixeltable.type_system as ts

from .column_ref import ColumnRef
from .data_row import DataRow
from .expr import Expr
from .row_builder import RowBuilder
from .sql_element_cache import SqlElementCache


class IsNull(Expr):
    def __init__(self, e: Expr):
        super().__init__(ts.BoolType())
        self.components = [e]
        self.id = self._create_id()

    def __repr__(self) -> str:
        return f'{self.components[0]} == None'

    def _equals(self, other: IsNull) -> bool:
        return True

    def sql_expr(self, sql_elements: SqlElementCache) -> sql.ColumnElement | None:
        c = self.components[0]
        if isinstance(c, ColumnRef) and c.col.stores_external_array():
            # we also need to check CellMd.file_urls for null
            e = sql.and_(c.col.sa_cellmd_col['file_urls'] == None, c.col.sa_col == None)
            return e
        e = sql_elements.get(self.components[0])
        if e is None:
            return None
        return e == None

    def eval(self, data_row: DataRow, row_builder: RowBuilder) -> None:
        data_row[self.slot_idx] = data_row[self.components[0].slot_idx] is None

    @classmethod
    def _from_dict(cls, d: dict, components: list[Expr]) -> IsNull:
        assert len(components) == 1
        return cls(components[0])
