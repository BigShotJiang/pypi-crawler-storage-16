import sqlalchemy as sql

from pixeltable.metadata import register_converter


@register_converter(version=42)
def _(engine: sql.engine.Engine) -> None:
    with engine.begin() as conn:
        conn.execute(sql.text('ALTER TABLE tables ALTER COLUMN dir_id DROP NOT NULL'))
