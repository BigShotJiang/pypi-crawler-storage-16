import pkg_19544


print(pkg_19544.__version__)
