===================================
Welcome to pkgcheck's documentation!
===================================

Contents:

.. toctree::
   :maxdepth: 2

   readme
   install/index.rst
   user/index.rst
   contributor/index.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
