============
Installation
============

At the command line::

    $ pip install pkgcheck

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv pkgcheck
    $ pip install pkgcheck
