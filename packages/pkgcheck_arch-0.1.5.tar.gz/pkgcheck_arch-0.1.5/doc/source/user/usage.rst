========
Usage
========

To use pkgcheck in a project::

	import pkgcheck
