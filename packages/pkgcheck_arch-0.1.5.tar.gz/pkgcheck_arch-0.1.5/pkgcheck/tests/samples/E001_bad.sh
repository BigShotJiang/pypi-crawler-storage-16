#!/bin/bash

# E001
somefunction args  
