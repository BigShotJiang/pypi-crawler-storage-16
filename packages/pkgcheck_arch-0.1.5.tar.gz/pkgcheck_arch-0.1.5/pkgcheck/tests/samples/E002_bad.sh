#!/bin/bash

	echo "E002: Has a tab"
