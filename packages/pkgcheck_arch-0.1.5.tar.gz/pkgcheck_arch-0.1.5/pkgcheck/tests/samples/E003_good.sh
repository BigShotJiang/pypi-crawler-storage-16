#!/bin/bash

this is \
     a continuation \
     where the continued lines \
     align with the first argument

a \
    is a continuation where there is no \
    argument so we line-up to the default \
    4 spaces

if foo; then

    testing a \
            continuation indented
fi
