#!/bin/bash

while [ 0 ]
do
    zero
done

# for do done in one line
for [ 0 ]; do run_morethings; done
