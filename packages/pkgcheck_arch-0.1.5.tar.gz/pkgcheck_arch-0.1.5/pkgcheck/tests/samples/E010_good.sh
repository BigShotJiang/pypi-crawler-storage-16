#!/bin/bash

# E010 good
while [ 0 ]; do
    run_things
done

# E010 with comment
while [ 0 ]; do # comment
    run_things
done
