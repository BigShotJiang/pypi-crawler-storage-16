#!/bin/bash

if [ 0 ]
then
    zero
elif [ 1 ]
then
    one
else
    default
fi

# if else fi in one line
if [ 0 ]; then run_morethings; else run_otherthings; fi
