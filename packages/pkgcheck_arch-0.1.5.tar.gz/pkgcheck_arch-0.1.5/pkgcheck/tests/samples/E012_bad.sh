#unexpected end-of-file on this
if foo; then

FOO=<<EOF
blah foo moo


# heredoc not ending

