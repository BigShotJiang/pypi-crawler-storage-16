#!/bin/bash

function myfn {
    if [ '' == '' ]; then
        echo 'Things'
    fii
}
