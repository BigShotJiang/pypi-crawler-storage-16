#!/bin/bash

# E021
foo=$[ 1 + 1 ]
