

makedepends=('pacman' 'python-setuptools' 'git' 'make' 'base-devel')
