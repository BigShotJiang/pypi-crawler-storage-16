#pragma once

void exposeTools();
void exposeDynamics();
void exposeEigen();
void exposeFootsteps();
void exposeProblem();
void exposeRobotWrapper();
void exposeParameters();
void exposeKinematics();
void exposeWalkPatternGenerator();