#!/bin/bash

python -m unittest discover tests/ "*_test.py"