#include "placo/humanoid/foot_trajectory.h"

namespace placo::humanoid
{
FootTrajectory::~FootTrajectory()
{
}
}  // namespace placo::trajectory