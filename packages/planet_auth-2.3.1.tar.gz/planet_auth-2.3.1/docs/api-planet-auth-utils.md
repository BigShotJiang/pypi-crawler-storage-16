# ::: planet_auth_utils
    options:
      show_root_full_path: true
      inherited_members: true
      show_submodules: true
      show_if_no_docstring: false
