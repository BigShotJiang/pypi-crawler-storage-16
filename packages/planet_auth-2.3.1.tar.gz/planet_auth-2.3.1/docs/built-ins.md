# Built-in Auth Client Profile Injection

TODO: Document how applications may inject built-in auth client profiles for
a smoother application user and developer experience.
