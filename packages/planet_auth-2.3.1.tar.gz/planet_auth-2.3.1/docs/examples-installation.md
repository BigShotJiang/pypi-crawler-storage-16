# Installation

## Install from _PyPI.org_ using `pip`
Install the required modules:
```shell
pip install planet-auth
```
