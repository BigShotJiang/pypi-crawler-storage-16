# setup.py is currently required for installing in editable mode ("pip install -e .").
# Otherwise, most of this project has had its config moved to the more declarative
# pyproject.toml

from setuptools import setup

setup()
