These keys have no power anywhere.  It's just test data we can parse
and use like keys.

The password for keypair1 private key is 'password'
