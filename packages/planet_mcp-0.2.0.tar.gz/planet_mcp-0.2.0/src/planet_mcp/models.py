from typing import Any
from typing_extensions import TypedDict


class Geometry(TypedDict):
    type: str
    coordinates: Any
    content: str | None
