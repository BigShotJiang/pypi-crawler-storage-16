# PLANQK API SDK

## Installation

The package is published on PyPI and can be installed via `pip`:

```bash
pip install --upgrade planqk-api-sdk
```

## Usage

The usage docs are available at <https://docs.hub.kipu-quantum.com/sdk-api-reference.html>.
