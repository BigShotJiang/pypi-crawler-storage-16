# A simple test.


def foo(x):
    return x + 1


# %%

y = 3

# %%

foo(1)

# %%

foo(y)

"""I don't know what else to do."""
