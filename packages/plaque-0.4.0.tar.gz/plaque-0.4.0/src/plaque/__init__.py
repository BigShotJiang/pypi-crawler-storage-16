from .cli import main as cli_main


def main() -> None:
    cli_main()
