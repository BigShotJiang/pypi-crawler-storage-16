# Mixed cell types test file


def hello():
    return "world"


# %% [markdown]
# This is a markdown cell
# With multiple lines

x = 1

"""This is triple quoted markdown"""

y = 2

"""
This is multiline
triple quoted markdown
"""

# %% Final Code Cell

result = hello()
print(result)
