# Basic test file with simple cells

x = 1
y = 2

# %%

z = x + y
print(z)

# %% Final Cell

result = z * 2
