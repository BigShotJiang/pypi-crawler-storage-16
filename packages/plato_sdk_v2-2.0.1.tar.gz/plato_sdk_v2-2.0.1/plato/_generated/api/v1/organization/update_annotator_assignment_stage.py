"""Update Annotator Assignment Stage"""

from __future__ import annotations

from typing import Any

import httpx

from plato._generated.errors import raise_for_status
from plato._generated.models.update_annotator_assignment_stage_request import UpdateAnnotatorAssignmentStageRequest
from plato._generated.models.update_annotator_assignment_stage_response import UpdateAnnotatorAssignmentStageResponse


def _build_request_args(
    assignment_id: int,
    body: UpdateAnnotatorAssignmentStageRequest,
    authorization: str | None = None,
    x_api_key: str | None = None,
) -> dict[str, Any]:
    """Build request arguments."""
    url = f"/api/v1/organization/annotator-assignments/{assignment_id}/stage"

    headers: dict[str, str] = {}
    if authorization is not None:
        headers["authorization"] = authorization
    if x_api_key is not None:
        headers["X-API-Key"] = x_api_key

    return {
        "method": "POST",
        "url": url,
        "json": body.to_dict(),
        "headers": headers,
    }


def sync(
    client: httpx.Client,
    assignment_id: int,
    body: UpdateAnnotatorAssignmentStageRequest,
    authorization: str | None = None,
    x_api_key: str | None = None,
) -> UpdateAnnotatorAssignmentStageResponse:
    """Update the stage (status) of an annotator assignment.

    Allows members of the assignment's organization to update the stage.
    Admins may also update stages across organizations."""

    request_args = _build_request_args(
        assignment_id=assignment_id,
        body=body,
        authorization=authorization,
        x_api_key=x_api_key,
    )

    response = client.request(**request_args)
    raise_for_status(response)
    return UpdateAnnotatorAssignmentStageResponse.from_dict(response.json())


async def asyncio(
    client: httpx.AsyncClient,
    assignment_id: int,
    body: UpdateAnnotatorAssignmentStageRequest,
    authorization: str | None = None,
    x_api_key: str | None = None,
) -> UpdateAnnotatorAssignmentStageResponse:
    """Update the stage (status) of an annotator assignment.

    Allows members of the assignment's organization to update the stage.
    Admins may also update stages across organizations."""

    request_args = _build_request_args(
        assignment_id=assignment_id,
        body=body,
        authorization=authorization,
        x_api_key=x_api_key,
    )

    response = await client.request(**request_args)
    raise_for_status(response)
    return UpdateAnnotatorAssignmentStageResponse.from_dict(response.json())
