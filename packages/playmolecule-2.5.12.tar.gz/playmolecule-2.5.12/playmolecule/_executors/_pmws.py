# (c) 2015-2023 Acellera Ltd http://www.acellera.com
# All Rights Reserved
# Distributed under HTMD Software License Agreement
# No redistribution in whole or part
#
from playmolecule.apps import JobStatus
from playmolecule import PM_APP_ROOT
import requests
import tempfile
import tarfile
import logging
import json
import os

logger = logging.getLogger(__name__)

# --- Global State ---
# This persists as long as the python script is running.
# We initialize it immediately so it's ready to use.
_internal_session = requests.Session()
_base_url = "http://localhost:8000"
_headers = {}


def login(username, password):
    """
    Authenticates and stores cookies in the global module session.
    """

    # Get the unauthenticated CSRF token
    response = _internal_session.get(f"{_base_url}/auth/csrf", headers=_headers)
    response.raise_for_status()
    csrf_token = response.json()["csrf_token"]

    headers = _headers.copy()
    headers["X-CSRF-Token"] = csrf_token

    # This updates _internal_session.cookies automatically
    response = _internal_session.post(
        f"{_base_url}/auth/login",
        data={"username": username, "password": password},
        headers={"X-CSRF-Token": csrf_token},
    )
    response.raise_for_status()

    print(f"Logged in as {username}")


def logout():
    """
    Clears the cookies from the global session.
    """
    _internal_session.cookies.clear()
    print("Logged out.")


def _get_apps(server_endpoint):
    print("Querying", f"{server_endpoint}/apps/manifests")
    rsp = requests.get(f"{server_endpoint}/apps/manifests")
    if rsp.status_code != 200:
        raise RuntimeError(f"Failed to get apps from {server_endpoint}: {rsp.text}")

    apps = {}
    for app_module, manifest in rsp.json().items():
        app_name = app_module.split(".")[0]
        if app_name not in apps:
            apps[app_name] = {}

        version = manifest.get("version")
        if version is None:
            version = manifest["container_config"]["version"]
        apps[app_name][f"v{version}"] = {
            "manifest": manifest,
            "appdir": None,
            "run.sh": None,
        }

    return apps


def _set_root_pmws(server_endpoint):
    from playmolecule.apps import _manifest_to_func, _link_latest_version
    from natsort import natsorted

    app_manifests = _get_apps(server_endpoint)

    for appname in app_manifests:
        func_names = _manifest_to_func(appname, app_manifests[appname])
        _link_latest_version(
            appname, natsorted(app_manifests[appname].keys())[-1], func_names
        )


def _pmws_status(dirname):
    pmws_file = os.path.join(dirname, ".pmws.json")
    if not os.path.exists(pmws_file):
        raise RuntimeError("Execution not submitted yet")

    with open(pmws_file, "r") as f:
        execid = json.load(f)["execid"]

    endpoint = PM_APP_ROOT
    token = os.environ["PMWS_TOKEN"]

    rsp = requests.get(
        f"{endpoint}/jobs/{execid}",
        headers={
            "Content-type": "application/json",
            "Accept": "text/plain",
            "token": token,
        },
    )
    rsp.close()
    if rsp is None:
        return None
    results = json.loads(rsp.text)

    status_mapping = {
        0: JobStatus.WAITING_INFO,
        1: JobStatus.WAITING_INFO,
        2: JobStatus.WAITING_INFO,
        3: JobStatus.RUNNING,
        4: JobStatus.COMPLETED,
        5: JobStatus.ERROR,
        6: JobStatus.RUNNING,
        7: JobStatus.RUNNING,
    }
    status = status_mapping[results["status"]]

    if status == JobStatus.ERROR:
        error_info = results.get("error_info", "")
        logger.error(f"Job errored with message: {error_info}")

    if status == JobStatus.COMPLETED:
        # Retrieve the execution data from the backend

        # Get the dataset ID
        logger.info(
            f"Job reached status {status}. Retrieving execution data from the backend"
        )
        rsp = requests.get(
            f"{endpoint}/datacenter",
            headers={
                "Content-type": "application/json",
                "Accept": "text/plain",
                "token": token,
                "filePath": f"{execid}/output",
            },
        )
        rsp.close()
        if rsp is None:
            return None

        datasets = json.loads(rsp.text)
        assert len(datasets) == 1
        dataset_id = datasets[0]["id"]

        # Download the dataset
        rsp = requests.get(
            f"{endpoint}/datacenter/{dataset_id}",
            headers={
                "Content-type": "application/json",
                "Accept": "text/plain",
                "token": token,
            },
        )
        rsp.close()
        if rsp is None:
            return None

        with tempfile.TemporaryDirectory() as tmpdir:
            tarf = os.path.join(tmpdir, "data.tar.gz")
            with open(tarf, "wb") as f:
                f.write(rsp.content)

            try:
                with tarfile.open(tarf) as tar:
                    tar.extractall(path=dirname)
            except Exception as e:
                if os.path.exists(tarf):
                    os.remove(tarf)
                logger.error(
                    f"Error untaring results for dataset {dirname} with error {e}",
                )
                return

    return status


def pmws(
    dirname,
    sentinel_dir,
    name=None,
    group=None,
    child_of=None,
    queue_config=None,
    pm_options=None,
    description=None,
    _logger=True,
):
    raise RuntimeError("Backend support still to be implemented")


def _get_app_files_pmws(manifest):
    from playmolecule._appfiles import _File

    files = manifest.get("files", {})
    for name, description in files.items():
        while name.endswith("/"):
            name = name[:-1]
        path = f"app://files/{name}"
        files[name] = _File(name, path, description)

    return files
