def crypticscout():
    """These are my docs of the app"""
    print("my protocol")
