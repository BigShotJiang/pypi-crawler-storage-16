from enum import Enum


class LibraryName(Enum):
    MUSIC = "Music"
    TV = "TV Shows"
    MOVIE = "Movies"
