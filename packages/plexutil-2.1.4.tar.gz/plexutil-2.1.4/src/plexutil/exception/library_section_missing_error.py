class LibrarySectionMissingError(Exception):
    pass
