Changelog
=========


1.5 (2025-12-09)
----------------

- Theming for login page, publication timeline, publication related items.
  [aduchene]

1.4 (2025-09-08)
----------------

- Re-release.
  [aduchene]


1.3 (2025-09-08)
----------------

- Floating buttons in forms.
  [aduchene]
- Theming about timestamping form.
  [aduchene]

1.2 (2025-04-30)
----------------

- Manage institution theming.
  [aduchene]

1.1 (2025-03-04)
----------------

- Misc. fixes and tweaks.
  [aduchene]

1.0 (2024-09-23)
----------------

- Misc. fixes and tweaks.
  [aduchene]

1.0b1 (2024-09-17)
------------------

- Plone 6 ready.
  [aduchene]
- publications theming.
  [aduchene]

0.1a6 (2024-07-29)
------------------

- Work in progress on the homepage.
  [aduchene]

0.1a5 (2024-07-01)
------------------

- Work in progress.
  [aduchene]

0.1a4 (2024-04-17)
------------------

- Fix bad release.
  [aduchene]

0.1a3 (2024-04-17)
------------------

-Work in progress.
 [aduchene]

0.1a2 (2024-04-16)
------------------

- Change setup.py.
  [aduchene]

0.1a1 (2024-04-16)
------------------

- Initial release.
  [aduchene]
