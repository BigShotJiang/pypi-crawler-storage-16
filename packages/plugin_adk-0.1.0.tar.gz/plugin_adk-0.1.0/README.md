# plugin-adk

This is a simple package named plugin-adk that says Hello, World.
