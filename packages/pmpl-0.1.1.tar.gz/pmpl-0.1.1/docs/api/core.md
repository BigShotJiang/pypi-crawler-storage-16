# pmpl.core

Core style definitions and registries.

```{eval-rst}
.. automodule:: pmpl.core
   :members:
   :undoc-members:
   :show-inheritance:
```
