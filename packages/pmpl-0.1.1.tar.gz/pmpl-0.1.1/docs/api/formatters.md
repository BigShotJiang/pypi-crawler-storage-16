# pmpl.formatters

Axis-level formatting functions for matplotlib.

```{eval-rst}
.. automodule:: pmpl.formatters
   :members:
   :undoc-members:
   :show-inheritance:
```
