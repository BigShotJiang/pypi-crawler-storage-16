# pmpl.styles

Style application utilities for matplotlib.

```{eval-rst}
.. automodule:: pmpl.styles
   :members:
   :undoc-members:
   :show-inheritance:
```
