"""Configuration for pytest."""

import matplotlib

# Use non-interactive backend for tests
matplotlib.use("Agg")
