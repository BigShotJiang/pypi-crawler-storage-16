import numpy as np


# ---------------------------
# 5) Harmonize (guide mean/std 매칭)
# ---------------------------


def _mean_std_rgb01(x_hwc_f01: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    v = x_hwc_f01.reshape(-1, 3)
    m = v.mean(axis=0)
    s = v.std(axis=0) + 1e-6
    return m, s


def harmonize_tiles_meanstd(
    coords: list[tuple[int, int]],
    tiles_out_nhwc_f01: np.ndarray,
    guide_hwc_f01: np.ndarray,
    tile: int,
):
    """
    각 타일을 guide의 동일 위치 패치와 mean/std 매칭
    입력/출력: NHWC float32 [0,1]
    """
    gH, gW = guide_hwc_f01.shape[:2]
    g_tiles = []
    for y, x in coords:
        gy1 = max(0, y)
        gx1 = max(0, x)
        gy2 = min(y + tile, gH)
        gx2 = min(x + tile, gW)
        gp = guide_hwc_f01[gy1:gy2, gx1:gx2, :]
        g_tiles.append(gp.astype(np.float32))
    for i in range(len(tiles_out_nhwc_f01)):
        t = tiles_out_nhwc_f01[i]
        gp = g_tiles[i]
        mo, so = _mean_std_rgb01(t)
        mg, sg = _mean_std_rgb01(gp)
        # print(f"mo:{mo} so:{so} | mg:{mg} sg:{sg}")
        np.clip((t - mo) * (sg / so) + mg, 0.0, 1.0, out=tiles_out_nhwc_f01[i])
