from .config import *
from ..base.dependency import *
from ..base.processor import *
from ...utility import patcher, normalizer


class TCCF1Context:

    def __init__(
        self,
        input_vector: np.ndarray,
        input_patcher: patcher.Patcher,
    ) -> None:
        config = TCCF1Config

        self.input_vector = input_vector
        self.input_pathcer = input_patcher
        self.padded_input_image = patcher.pad_vector(
            vector=self.input_vector,
            overlap_length=config.PATCHER_CONFIG.input_overlab_length,
            mode="reflect",
        )
        self.input_patches: list[np.ndarray] = self.input_pathcer.slice(
            self.padded_input_image
        )
        self.fi_ratio = config.FI_SIZE / max(self.input_vector.shape)
        self.fi_size = tuple(
            [
                int(x * self.fi_ratio)
                for x in [self.input_vector.shape[1], self.input_vector.shape[0]]
            ]
        )  # W x H
        self.fi_vector: np.ndarray = cv2.resize(
            self.input_vector, self.fi_size, interpolation=cv2.INTER_AREA
        )
        self.padded_fi_vector = np.pad(
            self.fi_vector,
            pad_width=(
                (0, config.FI_SIZE - self.fi_size[1]),
                (0, config.FI_SIZE - self.fi_size[0]),
                (0, 0),
            ),
            mode="reflect",
        )
        self.output_patches: np.ndarray = np.zeros(
            (
                len(self.input_patches),
                config.PATCH_SIZE * config.UPSCALE_RATIO,
                config.PATCH_SIZE * config.UPSCALE_RATIO,
                3,
            ),
            np.float32,
        )
        self.output_vector: np.ndarray = np.zeros_like(self.input_vector, np.float32)
