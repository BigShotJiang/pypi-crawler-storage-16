# PnsPy

PnsPy is a lightweight Python package for principal nested spheres (PNS) analysis.
