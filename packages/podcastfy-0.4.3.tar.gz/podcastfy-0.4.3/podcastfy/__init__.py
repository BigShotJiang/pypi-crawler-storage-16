# This file can be left empty for now
__version__ = "0.4.2"  # or whatever version you're on
