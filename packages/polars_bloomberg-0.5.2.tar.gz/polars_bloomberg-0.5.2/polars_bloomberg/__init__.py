"""polars_bloomberg package."""

from .plbbg import BqlResult, BQuery

__all__ = ["BQuery", "BqlResult"]

__version__ = "0.5.2"
