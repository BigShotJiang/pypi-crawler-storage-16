# Benchmark

# Requirements
The additional requirements are defined in requirements.txt. The `polars-sim` package is by default the locally installed packaged. 