__version__ = "0.3.6"

from polars_sim.dataframe.join import join_sim

__all__ = [
    "join_sim",
]
