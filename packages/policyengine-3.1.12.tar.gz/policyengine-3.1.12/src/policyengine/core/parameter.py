from typing import TYPE_CHECKING
from uuid import uuid4

from pydantic import BaseModel, Field

from .parameter_value import ParameterValue
from .tax_benefit_model_version import TaxBenefitModelVersion

if TYPE_CHECKING:
    from .parameter_value import ParameterValue


class Parameter(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid4()))
    name: str
    label: str | None = None
    description: str | None = None
    data_type: type | None = None
    tax_benefit_model_version: TaxBenefitModelVersion
    unit: str | None = None
    parameter_values: list["ParameterValue"] = Field(default_factory=list)
