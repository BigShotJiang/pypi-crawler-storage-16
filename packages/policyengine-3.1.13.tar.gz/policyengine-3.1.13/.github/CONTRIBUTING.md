## Updating the versioning

Please add to `changelog_entry.yaml` an entry in the format:

```yaml
- bump: minor
  changes:
    added:
    - New feature.
    fixed:
    - Bug fix.
    changed:
    - Change.
```
