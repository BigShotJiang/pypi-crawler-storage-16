# Delaware

PolicyEngine US has not yet implemented the Delaware income tax code, but some programs like the Delaware EITC are in the model.
