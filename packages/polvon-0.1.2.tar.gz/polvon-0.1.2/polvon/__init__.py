"""Polvon - CLI tool for managing Linux systemd services."""

__version__ = "0.1.2"
