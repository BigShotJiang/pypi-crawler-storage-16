from polyaxon._k8s.custom_resources.kubeflow.mpi_job import get_mpi_job_custom_resource
from polyaxon._k8s.custom_resources.kubeflow.pytorch_job import (
    get_pytorch_job_custom_resource,
)
from polyaxon._k8s.custom_resources.kubeflow.tf_job import get_tf_job_custom_resource
