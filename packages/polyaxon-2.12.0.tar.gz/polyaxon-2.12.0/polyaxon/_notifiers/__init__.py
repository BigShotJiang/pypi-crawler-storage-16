from vents.notifiers import NOTIFIERS

from polyaxon._notifiers.spec import NotificationSpec
