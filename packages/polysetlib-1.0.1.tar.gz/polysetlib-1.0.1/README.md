## PolySet – Python Library for Polymer Embeddings
PolySet provides a clean Python interface for generating **distribution-aware polymer embeddings** from simple polymer specifications (Mn, dispersity Đ, monomer mass M0).  
These embeddings are designed for machine-learning models and reflect the statistical nature of real polymer ensembles.


## Installation
pip install polyset


## What PolySet Does
Converts polymer specifications into physically informed embeddings
Provides a reproducible, stable interface for ML workflows
Hides internal details of the representation for clarity and portability
Ensures consistency across users, environments, and models


## Documentation & Examples
Extended explanations, distribution modes, and visual examples will be available on the official PolySet website: .


## Citation

If you use PolySet in scientific work, please cite:
Ferji, K. "PolySet: Polymers as Statistical Ensembles for Machine Learning" (2025) 
(will be added upon acceptance).

A Zenodo: ferji, . khalid . (2025). PolySet: Statistical Ensemble Polymer Embeddings Dataset for Machine Learning [Data set]. Zenodo. https://doi.org/10.5281/zenodo.17861022.
