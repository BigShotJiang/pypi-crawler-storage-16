from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="polysetlib",
    version="1.0.1",
    packages=find_packages(),
    install_requires=["requests"],
    author="Khalid Ferji",
    author_email="polysetsmiles@gmail.com",
    description="PolySet – Python library for generating distribution-aware polymer embeddings",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/kFERJI/PolySet",
    python_requires=">=3.8",
    license="PolySet Academic License (PAL)",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: Other/Proprietary License",
        "Operating System :: OS Independent",
    ],
)
