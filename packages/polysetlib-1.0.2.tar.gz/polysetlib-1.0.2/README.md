# PolySet – Python Library for Polymer Embeddings
A framework for representing polymers as ensembles rather than single objects.


## Why PolySet?
In polymer science, one principle is foundational:
A polymer is never a single molecule, it is a population.

Every real polymer sample consists of a diversity of chains, each with its own length, each contributing differently to the material’s behavior. This diversity is not noise — it is the polymer.

Yet, in most machine-learning workflows, polymers are still treated as if they were:
    * single, well-defined objects,
    * perfectly uniform entities,
    * without internal statistical structure.
    
This simplification acts like a conceptual compression. It removes exactly what makes polymers distinct from small molecules: their inherent stochastic nature.

PolySet is created to restore this missing dimension.


## What PolySet Does?
Converts polymer specifications into physically informed embeddings
Provides a reproducible, stable interface for ML workflows
Hides internal details of the representation for clarity and portability
Ensures consistency across users, environments, and models

## Installation
pip install polysetlib


## Documentation & Examples
Extended explanations, distribution modes, and visual examples are available on: https://khalidferji.academicwebsite.com/pages/8805.


## Citation
If you use PolySet in scientific work, please cite:
Ferji, K. "PolySet: Polymers as Statistical Ensembles for Machine Learning" (2025) 
(will be added upon acceptance).

ferji, khalid . (2025). PolySet: Statistical Ensemble Polymer Embeddings Dataset for Machine Learning [Data set]. Zenodo. https://doi.org/10.5281/zenodo.17861022.
