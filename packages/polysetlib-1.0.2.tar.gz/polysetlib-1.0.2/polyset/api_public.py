
import requests

DEFAULT_PUBLIC_KEY = "polyset_free"
DEFAULT_ENDPOINT = "https://polyset-api.onrender.com/polyset"


class PolySet:
    """
    PolySet - Compute distribution-aware polymer embeddings.

    Users provide (Mn, D, M0, mode).
    The function returns a dictionary containing the embedding.
    """

    def __init__(self, api_key=None, endpoint=None):
        self.api_key = api_key or DEFAULT_PUBLIC_KEY
        self.url = endpoint or DEFAULT_ENDPOINT

    
    def _warmup(self):
        ping_url = self.url.replace("/polyset", "/ping")
        try:
            requests.get(ping_url, timeout=3)
        except Exception:
            # We ignore ALL errors here
            pass

    # -------------------------------------------------------------
    # Main compute
    # -------------------------------------------------------------
    def compute(self, Mn, D, M0, mode="basic"):
        self._warmup()

        payload = {
            "Mn": Mn,
            "D": D,
            "M0": M0,
            "mode": mode
        }

        headers = {"X-API-Key": self.api_key}


        response = requests.post(self.url, json=payload, headers=headers, timeout=120)

        try:
            response.raise_for_status()
            return response.json()

        except requests.HTTPError:
            try:
                err = response.json()
                raise RuntimeError(f"PolySet backend error: {err}")
            except Exception:
                raise RuntimeError(f"PolySet backend error: {response.text}")

        except Exception as e:
            raise RuntimeError(f"Unexpected client error: {str(e)}")

# -------------------------------------------------------------
# homopolymer embeddings
# -------------------------------------------------------------
def PolySet_homo(Mn, D, M0, mode="basic", api_key=None, endpoint=None):
    """
    Example:
        from polyset import PolySet_homo
        res = PolySet_homo(Mn=100000, D=2.5, M0=100.0, mode="short")
    """
    client = PolySet(api_key=api_key, endpoint=endpoint)
    return client.compute(Mn=Mn, D=D, M0=M0, mode=mode)
