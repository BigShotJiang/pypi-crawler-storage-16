"""Tools for creating and training simple multi-layer perceptron neural networks.
"""