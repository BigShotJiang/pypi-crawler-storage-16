"""Compatibility wrapper to expose the API as `popoto`."""

from popoto_api.popoto import *  # noqa: F401,F403

__all__ = ["popoto"]
