conf module
===========

.. automodule:: conf
    :members:
    :undoc-members:
    :show-inheritance:
