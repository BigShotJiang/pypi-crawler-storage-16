
![PostgreSQL Workload Analyzer](https://github.com/powa-team/powa/blob/master/img/powa_logo.410x161.png)

PoWA Web
=========

This project is a User Interface to the
[PoWA](http://powa.readthedocs.io/) project.

For more information, please read the [PoWA-web
documentation](https://powa.readthedocs.io/en/latest/components/powa-web/index.html):

https://powa.readthedocs.io/en/latest/components/powa-web/index.html
