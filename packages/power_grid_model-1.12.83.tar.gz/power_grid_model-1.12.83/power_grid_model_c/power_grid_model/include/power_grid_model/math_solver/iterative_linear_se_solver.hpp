// SPDX-FileCopyrightText: Contributors to the Power Grid Model project <powergridmodel@lfenergy.org>
//
// SPDX-License-Identifier: MPL-2.0

#pragma once

// iterative linear state estimation solver

#include "block_matrix.hpp"
#include "common_solver_functions.hpp"
#include "measured_values.hpp"
#include "observability.hpp"
#include "sparse_lu_solver.hpp"
#include "y_bus.hpp"

#include "../calculation_parameters.hpp"
#include "../common/common.hpp"
#include "../common/exception.hpp"
#include "../common/three_phase_tensor.hpp"
#include "../common/timer.hpp"

namespace power_grid_model::math_solver {

// hide implementation in inside namespace
namespace iterative_linear_se {

// block class for the unknown vector and/or right-hand side in state estimation equation
template <symmetry_tag sym> struct ILSEUnknown : public Block<DoubleComplex, sym, false, 2> {
    template <int r, int c> using GetterType = typename Block<DoubleComplex, sym, false, 2>::template GetterType<r, c>;

    // eigen expression
    using Block<DoubleComplex, sym, false, 2>::Block;
    using Block<DoubleComplex, sym, false, 2>::operator=;

    GetterType<0, 0> u() { return this->template get_val<0, 0>(); }
    GetterType<1, 0> phi() { return this->template get_val<1, 0>(); }

    GetterType<0, 0> eta() { return this->template get_val<0, 0>(); }
    GetterType<1, 0> tau() { return this->template get_val<1, 0>(); }
};

// block class for the right hand side in state estimation equation
template <symmetry_tag sym> using ILSERhs = ILSEUnknown<sym>;

// class of 2*2 (6*6) se gain block
// [
//    [G, QH]
//    [Q, R ]
// ]
template <symmetry_tag sym> class ILSEGainBlock : public Block<DoubleComplex, sym, true, 2> {
  public:
    template <int r, int c> using GetterType = typename Block<DoubleComplex, sym, true, 2>::template GetterType<r, c>;

    // eigen expression
    using Block<DoubleComplex, sym, true, 2>::Block;
    using Block<DoubleComplex, sym, true, 2>::operator=;

    GetterType<0, 0> g() { return this->template get_val<0, 0>(); }
    GetterType<0, 1> qh() { return this->template get_val<0, 1>(); }
    GetterType<1, 0> q() { return this->template get_val<1, 0>(); }
    GetterType<1, 1> r() { return this->template get_val<1, 1>(); }
};

template <symmetry_tag sym_type> class IterativeLinearSESolver {
  public:
    using sym = sym_type;

    static constexpr auto is_iterative = true;
    static constexpr auto has_global_current_sensor_implemented =
        true; // TODO(figueroa1395): for testing purposes; remove after NRSE has global current sensor implemented
    static constexpr auto is_NRSE_solver = false; // for testing purposes only

  private:
    // block size 2 for symmetric, 6 for asym
    static constexpr Idx bsr_block_size_ = is_symmetric_v<sym> ? 2 : 6;

  public:
    IterativeLinearSESolver(YBus<sym> const& y_bus, std::shared_ptr<MathModelTopology const> topo_ptr)
        : n_bus_{y_bus.size()},
          math_topo_{std::move(topo_ptr)},
          data_gain_(y_bus.nnz_lu()),
          x_rhs_(y_bus.size()),
          sparse_solver_{y_bus.shared_indptr_lu(), y_bus.shared_indices_lu(), y_bus.shared_diag_lu()},
          perm_(y_bus.size()) {}

    SolverOutput<sym> run_state_estimation(YBus<sym> const& y_bus, StateEstimationInput<sym> const& input,
                                           double err_tol, Idx max_iter, Logger& log) {
        // prepare
        Timer main_timer;
        Timer sub_timer;
        SolverOutput<sym> output;
        output.u.resize(n_bus_);
        output.bus_injection.resize(n_bus_);
        double max_dev = std::numeric_limits<double>::max();

        main_timer = Timer{log, LogEvent::math_solver};

        // preprocess measured value
        sub_timer = Timer{log, LogEvent::preprocess_measured_value};
        MeasuredValues<sym> const measured_values{y_bus.shared_topology(), input};
        auto const observability_result =
            observability::observability_check(measured_values, y_bus.math_topology(), y_bus.y_bus_structure());

        // prepare matrix
        sub_timer = Timer{log, LogEvent::prepare_matrix_including_prefactorization};
        prepare_matrix(y_bus, measured_values);
        // prefactorize
        sparse_solver_.prefactorize(data_gain_, perm_, observability_result.use_perturbation());

        // initialize voltage with initial angle
        sub_timer = Timer{log, LogEvent::initialize_voltages}; // TODO(mgovers): make scoped subtimers
        RealValue<sym> const mean_angle_shift = measured_values.mean_angle_shift();
        for (Idx bus = 0; bus != n_bus_; ++bus) {
            output.u[bus] = exp(1.0i * (mean_angle_shift + math_topo_->phase_shift[bus]));
        }

        // loop to iterate
        Idx num_iter = 0;
        while (max_dev > err_tol || num_iter == 0) {
            if (num_iter++ == max_iter) {
                throw IterationDiverge{max_iter, max_dev, err_tol};
            }
            sub_timer = Timer{log, LogEvent::calculate_rhs};
            prepare_rhs(y_bus, measured_values, output.u);
            // solve with prefactorization
            sub_timer = Timer{log, LogEvent::solve_sparse_linear_equation_prefactorized};
            sparse_solver_.solve_with_prefactorized_matrix(data_gain_, perm_, x_rhs_, x_rhs_);
            sub_timer = Timer{log, LogEvent::iterate_unknown};
            max_dev = iterate_unknown(output.u, measured_values.has_angle());
        }

        // calculate math result
        sub_timer = Timer{log, LogEvent::calculate_math_result};
        detail::calculate_se_result<sym>(y_bus, measured_values, output);

        // Manually stop timers to avoid "Max number of iterations" to be included in the timing.
        sub_timer.stop();
        main_timer.stop();

        log.log(LogEvent::max_num_iter, num_iter);

        return output;
    }

  private:
    // array selection function pointer
    static constexpr std::array has_branch_power_{&MeasuredValues<sym>::has_branch_from_power,
                                                  &MeasuredValues<sym>::has_branch_to_power};
    static constexpr std::array branch_power_{&MeasuredValues<sym>::branch_from_power,
                                              &MeasuredValues<sym>::branch_to_power};
    static constexpr std::array has_branch_current_{&MeasuredValues<sym>::has_branch_from_current,
                                                    &MeasuredValues<sym>::has_branch_to_current};
    static constexpr std::array branch_current_{&MeasuredValues<sym>::branch_from_current,
                                                &MeasuredValues<sym>::branch_to_current};

    Idx n_bus_;
    // shared topo data
    std::shared_ptr<MathModelTopology const> math_topo_;

    // data for gain matrix
    std::vector<ILSEGainBlock<sym>> data_gain_;
    // unknown and rhs
    std::vector<ILSERhs<sym>> x_rhs_;
    // solver
    SparseLUSolver<ILSEGainBlock<sym>, ILSERhs<sym>, ILSEUnknown<sym>> sparse_solver_;
    typename SparseLUSolver<ILSEGainBlock<sym>, ILSERhs<sym>, ILSEUnknown<sym>>::BlockPermArray perm_;

    static auto diagonal_inverse(RealValue<sym> const& value) {
        return ComplexDiagonalTensor<sym>{static_cast<ComplexValue<sym>>(RealValue<sym>{1.0} / value)};
    }

    void prepare_matrix(YBus<sym> const& y_bus, MeasuredValues<sym> const& measured_value) {
        MathModelParam<sym> const& param = y_bus.math_model_param();
        IdxVector const& row_indptr = y_bus.row_indptr_lu();
        IdxVector const& col_indices = y_bus.col_indices_lu();

        // loop data index, all rows and columns
        for (Idx row = 0; row != n_bus_; ++row) {
            for (Idx data_idx_lu = row_indptr[row]; data_idx_lu != row_indptr[row + 1]; ++data_idx_lu) {
                Idx const col = col_indices[data_idx_lu];
                // get a reference and reset block to zero
                ILSEGainBlock<sym>& block = data_gain_[data_idx_lu];
                block.clear();
                // get data idx of y bus,
                // skip for a fill-in
                Idx const data_idx = y_bus.map_lu_y_bus()[data_idx_lu];
                if (data_idx == -1) {
                    continue;
                }
                // fill block with voltage measurement, only diagonal
                if ((row == col) && measured_value.has_voltage(row)) {
                    // G += 1.0 / variance
                    // for 3x3 tensor, fill diagonal
                    block.g() += ComplexTensor<sym>{1.0 / measured_value.voltage_var(row)};
                }
                // fill block with branch, shunt measurement
                for (Idx element_idx = y_bus.y_bus_entry_indptr()[data_idx];
                     element_idx != y_bus.y_bus_entry_indptr()[data_idx + 1]; ++element_idx) {
                    Idx const obj = y_bus.y_bus_element()[element_idx].idx;
                    YBusElementType const type = y_bus.y_bus_element()[element_idx].element_type;
                    // shunt
                    if (type == YBusElementType::shunt) {
                        if (measured_value.has_shunt(obj)) {
                            // G += (-Ys)^H * (variance^-1) * (-Ys) // NOSONAR(S125)
                            auto const& shunt_power = measured_value.shunt_power(obj);
                            auto const current = power_to_global_current_measurement(shunt_power);
                            block.g() += dot(hermitian_transpose(param.shunt_param[obj]),
                                             diagonal_inverse(current.variance), param.shunt_param[obj]);
                        }
                    }
                    // branch
                    else {
                        auto const add_branch_measurement = [&block, &param, obj, type](
                                                                IntS measured_side,
                                                                IndependentComplexRandVar<sym> const& branch_current) {
                            // branch from- and to-side index at 0, and 1 position
                            IntS const b0 = std::to_underlying(type) / 2;
                            IntS const b1 = std::to_underlying(type) % 2;

                            // G += Y{side, b0}^H * (variance^-1) * Y{side, b1} // NOSONAR(S125)
                            block.g() += dot(hermitian_transpose(param.branch_param[obj].value[measured_side * 2 + b0]),
                                             diagonal_inverse(branch_current.variance),
                                             param.branch_param[obj].value[measured_side * 2 + b1]);
                        };
                        // measured at from-side: 0, to-side: 1
                        for (IntS const measured_side : std::array<IntS, 2>{0, 1}) {
                            // has measurement
                            if (std::invoke(has_branch_power_[measured_side], measured_value, obj)) {
                                auto const& branch_power =
                                    std::invoke(branch_power_[measured_side], measured_value, obj);
                                add_branch_measurement(measured_side,
                                                       power_to_global_current_measurement(branch_power));
                            }
                            if (std::invoke(has_branch_current_[measured_side], measured_value, obj)) {
                                auto const& branch_current =
                                    std::invoke(branch_current_[measured_side], measured_value, obj);
                                add_branch_measurement(measured_side,
                                                       current_to_global_current_measurement(branch_current));
                            }
                        }
                    }
                }
                // fill block with injection measurement
                // injection measurement exist
                if (measured_value.has_bus_injection(row)) {
                    // Q_ij = Y_bus_ij // NOSONAR(S125)
                    block.q() = y_bus.admittance()[data_idx];
                    // R_ii = -variance, only diagonal
                    if (row == col) {
                        // assign variance to diagonal of 3x3 tensor, for asym
                        auto const& injection = measured_value.bus_injection(row);
                        block.r() = ComplexTensor<sym>{
                            static_cast<ComplexValue<sym>>(-power_to_global_current_measurement(injection).variance)};
                    }
                }
                // injection measurement not exist
                else {
                    // Q_ij = 0
                    // R_ii = -1.0, only diagonal
                    // assign -1.0 to diagonal of 3x3 tensor, for asym
                    if (row == col) {
                        block.r() = ComplexTensor<sym>{-1.0};
                    }
                }
            }
        }

        // loop all transpose entry for QH
        // assign the hermitian transpose of the transpose entry of Q
        for (Idx data_idx_lu = 0; data_idx_lu != y_bus.nnz_lu(); ++data_idx_lu) {
            // skip for fill-in
            if (y_bus.map_lu_y_bus()[data_idx_lu] == -1) {
                continue;
            }
            Idx const data_idx_tranpose = y_bus.lu_transpose_entry()[data_idx_lu];
            data_gain_[data_idx_lu].qh() = hermitian_transpose(data_gain_[data_idx_tranpose].q());
        }
    }

    void prepare_rhs(YBus<sym> const& y_bus, MeasuredValues<sym> const& measured_value,
                     ComplexValueVector<sym> const& current_u) {
        MathModelParam<sym> const& param = y_bus.math_model_param();
        std::vector<BranchIdx> const branch_bus_idx = y_bus.math_topology().branch_bus_idx;
        // get generated (measured/estimated) voltage phasor
        // with current result voltage angle
        ComplexValueVector<sym> u = linearize_measurements(current_u, measured_value);

        // loop all bus to fill rhs
        for (Idx bus = 0; bus != n_bus_; ++bus) {
            Idx const data_idx = y_bus.bus_entry()[bus];
            // reset rhs block to fill values
            ILSERhs<sym>& rhs_block = x_rhs_[bus];
            rhs_block.clear();
            // fill block with voltage measurement
            if (measured_value.has_voltage(bus)) {
                // eta += u / variance
                rhs_block.eta() += u[bus] / measured_value.voltage_var(bus);
            }
            // fill block with branch, shunt measurement, need to convert to current
            for (Idx element_idx = y_bus.y_bus_entry_indptr()[data_idx];
                 element_idx != y_bus.y_bus_entry_indptr()[data_idx + 1]; ++element_idx) {
                Idx const obj = y_bus.y_bus_element()[element_idx].idx;
                YBusElementType const type = y_bus.y_bus_element()[element_idx].element_type;
                // shunt
                if (type == YBusElementType::shunt) {
                    if (measured_value.has_shunt(obj)) {
                        PowerSensorCalcParam<sym> const& shunt_power = measured_value.shunt_power(obj);
                        auto const current = power_to_global_current_measurement(shunt_power, u[bus]);
                        // eta += (-Ys)^H * (variance^-1) * i_shunt
                        rhs_block.eta() -= dot(hermitian_transpose(param.shunt_param[obj]),
                                               diagonal_inverse(current.variance), current.value);
                    }
                }
                // branch
                else {
                    auto const add_branch_measurement = [&rhs_block, &param, obj,
                                                         type](IntS measured_side,
                                                               IndependentComplexRandVar<sym> const& branch_current) {
                        // branch is either ff or tt
                        IntS const b = std::to_underlying(type) / 2;
                        // eta += Y{side, b}^H * (variance^-1) * i_branch_{f, t}
                        rhs_block.eta() +=
                            dot(hermitian_transpose(param.branch_param[obj].value[measured_side * 2 + b]),
                                diagonal_inverse(branch_current.variance), branch_current.value);
                    };
                    // measured at from-side: 0, to-side: 1
                    for (IntS const measured_side : std::array<IntS, 2>{0, 1}) {
                        // the current needs to be calculated with the voltage of the measured bus side
                        // NOTE: not the bus that is currently being processed!
                        Idx const measured_bus = branch_bus_idx[obj][measured_side];

                        // has measurement
                        if (std::invoke(has_branch_power_[measured_side], measured_value, obj)) {
                            auto const& branch_power = std::invoke(branch_power_[measured_side], measured_value, obj);
                            add_branch_measurement(measured_side,
                                                   power_to_global_current_measurement(branch_power, u[measured_bus]));
                        }
                        if (std::invoke(has_branch_current_[measured_side], measured_value, obj)) {
                            auto const& branch_current =
                                std::invoke(branch_current_[measured_side], measured_value, obj);
                            add_branch_measurement(
                                measured_side, current_to_global_current_measurement(branch_current, u[measured_bus]));
                        }
                    }
                }
            }
            // fill block with injection measurement, need to convert to current
            if (measured_value.has_bus_injection(bus)) {
                rhs_block.tau() = power_to_global_current_measurement(measured_value.bus_injection(bus), u[bus]).value;
            }
        }
    }

    double iterate_unknown(ComplexValueVector<sym>& u, bool has_angle) {
        double max_dev = 0.0;
        // phase shift anti offset of slack bus, phase a
        // if no angle measurement is present
        DoubleComplex const angle_offset = [&]() -> DoubleComplex {
            if (has_angle) {
                return 1.0;
            }
            auto const& voltage = x_rhs_[math_topo_->slack_bus].u();
            auto const& voltage_a = [&voltage]() -> auto const& {
                if constexpr (is_symmetric_v<sym>) {
                    return voltage;
                } else {
                    return voltage(0);
                }
            }();
            return cabs(voltage_a) / voltage_a;
        }();

        for (Idx bus = 0; bus != n_bus_; ++bus) {
            // phase offset to calculated voltage as normalized
            ComplexValue<sym> const u_normalized = x_rhs_[bus].u() * angle_offset;
            // get dev of last iteration, get max
            double const dev = max_val(cabs(u_normalized - u[bus]));
            max_dev = std::max(dev, max_dev);
            // assign
            u[bus] = u_normalized;
        }
        return max_dev;
    }

    auto linearize_measurements(ComplexValueVector<sym> const& current_u,
                                MeasuredValues<sym> const& measured_values) const {
        return measured_values.combine_voltage_iteration_with_measurements(current_u);
    }

    // The variance is not scaled as an approximation under the assumptions of:
    // - linearization of obtaining the current from power measurements
    // - voltages are ~1pu
    // - power sensor variances are often an approximation dominated by heuristics in the first place
    // See also https://github.com/PowerGridModel/power-grid-model/pull/951#issuecomment-2805154436
    IndependentComplexRandVar<sym>
    power_to_global_current_measurement(PowerSensorCalcParam<sym> const& power_measurement,
                                        ComplexValue<sym> const& voltage) const {
        auto measurement = static_cast<IndependentComplexRandVar<sym>>(power_measurement);
        measurement.value = conj(measurement.value / voltage);
        return measurement;
    }

    // Overload when the voltage is not present: the value can't be determined, but the variance assumption still holds.
    // The variance is not scaled as an approximation under the assumptions of:
    // - linearization of obtaining the current from power measurements
    // - voltages are ~1pu
    // - power sensor variances are often an approximation dominated by heuristics in the first place
    // See also https://github.com/PowerGridModel/power-grid-model/pull/951#issuecomment-2805154436
    IndependentComplexRandVar<sym>
    power_to_global_current_measurement(PowerSensorCalcParam<sym> const& power_measurement) const {
        auto measurement = static_cast<IndependentComplexRandVar<sym>>(power_measurement);
        measurement.value = ComplexValue<sym>{nan};
        return measurement;
    }

    IndependentComplexRandVar<sym>
    current_to_global_current_measurement(CurrentSensorCalcParam<sym> const& current_measurement,
                                          ComplexValue<sym> const& voltage) const {
        using statistics::scale;

        auto measurement = static_cast<IndependentComplexRandVar<sym>>(current_measurement.measurement);

        switch (current_measurement.angle_measurement_type) {
        case AngleMeasurementType::global_angle:
            return measurement; // no offset
        case AngleMeasurementType::local_angle:
            return scale(conj(measurement),
                         phase_shift(voltage)); // offset with the phase shift
        default:
            throw MissingCaseForEnumError{"AngleMeasurementType", current_measurement.angle_measurement_type};
        }
    }

    // Overload when the voltage is not present: the value can't be determined, but the variance assumption still holds.
    IndependentComplexRandVar<sym>
    current_to_global_current_measurement(CurrentSensorCalcParam<sym> const& current_measurement) const {
        auto measurement = static_cast<IndependentComplexRandVar<sym>>(current_measurement.measurement);
        measurement.value = ComplexValue<sym>{nan};
        return measurement;
    }
};

} // namespace iterative_linear_se

using iterative_linear_se::IterativeLinearSESolver;

} // namespace power_grid_model::math_solver
