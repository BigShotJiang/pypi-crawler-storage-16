PowerBot client for async operations
