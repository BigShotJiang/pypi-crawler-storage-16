PowerBot client for sync operations
