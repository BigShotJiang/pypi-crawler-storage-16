from typing import NamedTuple


class CachedEntity(NamedTuple):
    key: str
    val: str
