from enum import Enum


class CopilotScenarioEnum(Enum):
    """
    Copilot scenario
    """

    officeweb = "officeweb"
    teamshub = "teamshub"
