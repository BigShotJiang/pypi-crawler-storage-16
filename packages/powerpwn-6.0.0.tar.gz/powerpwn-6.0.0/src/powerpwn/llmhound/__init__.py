"""
LLM Hound - Discover and probe AI integration surfaces
Discovers Claude/OpenAI APIs, Model Context Protocol (MCP) servers, LLM proxies, and API endpoints
"""

__version__ = "1.0.0"
