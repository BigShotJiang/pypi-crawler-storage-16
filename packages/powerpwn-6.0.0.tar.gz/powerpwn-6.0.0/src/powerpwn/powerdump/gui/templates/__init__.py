"""
Borrowing from https://github.com/miguelgrinberg/flask-tables
"""
