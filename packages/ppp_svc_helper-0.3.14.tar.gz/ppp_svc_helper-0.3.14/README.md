# What is this
Contains various utilities for common SVC (singing voice conversion) data
 tasks
based on popular singing voice conversion libraries--interfaces for
pitch extraction, speech feature extraction, singing voice conversion, data augmentation.

# Credits
* [RVC](https://github.com/RVC-Project/Retrieval-based-Voice-Conversion-WebUI)
* Black, Dawn A. A., Li, Ma and Tian, Mi. "Automatic Identification of Emotional Cues in Chinese Opera Singing", in Proc. of 13th Int. Conf. on Music Perception and Cognition and the 5th Conference for the Asian-Pacific Society for Cognitive Sciences of Music (ICMPC 13-APSC0M 5 2014), Seoul, South Korea, August 2014.
