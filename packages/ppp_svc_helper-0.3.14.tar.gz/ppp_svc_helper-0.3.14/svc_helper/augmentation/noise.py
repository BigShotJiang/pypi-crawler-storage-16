import random
import numpy as np
from datasets import load_dataset

def _randp(prob):
    return (random.random() < prob)

class NoiseRandomAugmentor:
    def __init__(self, dataset='bilguun/musan-noise'):
        dataset = load_dataset(dataset)