"""PowerPoint to HTML5 conversion tools."""

from pptx_to_html5.converter import PowerPointToHTML5Converter

__version__ = "0.1.0"
__all__ = ["PowerPointToHTML5Converter"]
