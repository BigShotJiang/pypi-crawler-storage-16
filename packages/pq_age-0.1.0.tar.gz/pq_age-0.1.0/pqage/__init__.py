"""
pq-age - age-compatible Post-Quantum File Encryption.

Hybrid ML-KEM-1024 + X25519 + ChaCha20-Poly1305, fully interoperable with age.

This module provides post-quantum secure file encryption using a hybrid
approach combining classical (X25519) and post-quantum (ML-KEM-1024) KEMs.
It is fully compatible with the age v1 format specification.

Features:
    - age v1 format compatibility (interoperable with age, rage)
    - Hybrid KEM for quantum resistance + classical security
    - SSH Ed25519 key support
    - scrypt password-based encryption (age-compatible)
    - Streaming encryption (age STREAM cipher)
    - ASCII armor output option

Recipient Types:
    - X25519: Classical age recipients
    - ssh-ed25519: SSH Ed25519 keys
    - scrypt: Password-based encryption
    - mlkem-x25519: Hybrid post-quantum (pq-age extension)

Example:
    >>> from pqage import encrypt, decrypt, X25519Recipient, X25519Identity
    >>> from os import urandom
    >>> from nacl.bindings import crypto_scalarmult_base
    >>>
    >>> # Generate keypair
    >>> sk = urandom(32)
    >>> pk = crypto_scalarmult_base(sk)
    >>>
    >>> # Encrypt
    >>> ciphertext = encrypt(b"Hello!", [X25519Recipient(pk)])
    >>>
    >>> # Decrypt
    >>> plaintext = decrypt(ciphertext, [X25519Identity(sk, pk)])
"""

from pqage.crypto.keys import generate_keys  # noqa: I001

from pqage.age_file_ops import (
    MlkemX25519Identity,
    MlkemX25519Recipient,
    ScryptIdentity,
    ScryptRecipient,
    SshEd25519Identity,
    SshEd25519Recipient,
    X25519Identity,
    X25519Recipient,
    decrypt,
    decrypt_file,
    encrypt,
    encrypt_file,
)

__version__ = "0.1.0"
__all__ = [
    # Version
    "__version__",
    # Key generation
    "generate_keys",
    # File operations
    "encrypt",
    "decrypt",
    "encrypt_file",
    "decrypt_file",
    # Recipient types
    "X25519Recipient",
    "SshEd25519Recipient",
    "MlkemX25519Recipient",
    "ScryptRecipient",
    # Identity types
    "X25519Identity",
    "SshEd25519Identity",
    "MlkemX25519Identity",
    "ScryptIdentity",
]
