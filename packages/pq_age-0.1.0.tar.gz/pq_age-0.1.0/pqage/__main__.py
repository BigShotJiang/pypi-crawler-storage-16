"""
Entry point for running pq-age as a module.

Allows: python -m pqage [args]
"""

from pqage.age_cli import main

if __name__ == "__main__":
    raise SystemExit(main())
