#!/usr/bin/env python3
"""
pq-age CLI - age-compatible Post-Quantum File Encryption.

This CLI is fully interoperable with age, rage, and other age-compatible tools.
It adds hybrid ML-KEM-1024 + X25519 recipients for post-quantum security.

Commands:
    keygen    - Generate hybrid keypair (X25519 + ML-KEM-1024)
    pubkey    - Display public key from identity file
    encrypt   - Encrypt a file for recipients
    decrypt   - Decrypt a file with identities

Examples:
    # Generate keys
    pqage-keygen -o ~/.pqage/identity.txt

    # Encrypt with hybrid post-quantum key
    pqage -r age1pq1... -o secret.age plaintext.txt

    # Encrypt with password
    pqage -p -o secret.age plaintext.txt

    # Decrypt
    pqage -d -i ~/.pqage/identity.txt -o plaintext.txt secret.age

    # Encrypt to SSH key (age-compatible)
    pqage -R ~/.ssh/id_ed25519.pub -o secret.age plaintext.txt
"""

import argparse
import base64
import getpass
import logging
import sys
from pathlib import Path

import bech32

from pqage import __version__
from pqage.age_file_ops import (
    MlkemX25519Identity,
    MlkemX25519Recipient,
    ScryptIdentity,
    ScryptRecipient,
    SshEd25519Identity,
    SshEd25519Recipient,
    X25519Identity,
    X25519Recipient,
    decrypt_file,
    encrypt_file,
)
from pqage.crypto.keys import SecureKeyBundle, generate_keys
from pqage.crypto.ssh import (
    parse_ssh_private_key_file,
    parse_ssh_public_key_file,
)
from pqage.exceptions import PqageError

# Configure logging
logging.basicConfig(
    level=logging.WARNING,
    format="%(levelname)s: %(message)s",
)
logger = logging.getLogger(__name__)

# =============================================================================
# Constants
# =============================================================================

# Key file prefixes for pq-age hybrid keys
PQAGE_PUBLIC_KEY_PREFIX: str = "age1pq"  # Hybrid public key (bech32-like)
PQAGE_SECRET_KEY_PREFIX: str = "AGE-SECRET-KEY-PQ-"  # Hybrid secret key

# Standard age key prefixes (for compatibility)
AGE_PUBLIC_KEY_PREFIX: str = "age1"
AGE_SECRET_KEY_PREFIX: str = "AGE-SECRET-KEY-"

# Bech32 HRP for standard age keys
AGE_BECH32_HRP: str = "age"


# =============================================================================
# Bech32 Utilities
# =============================================================================


def decode_age_bech32(key_str: str) -> bytes:
    """
    Decode a standard age public key (bech32 encoded).

    age uses bech32 encoding with HRP "age" for X25519 public keys.
    Format: age1<bech32-encoded-32-bytes>

    Args:
        key_str: age public key string starting with "age1".

    Returns:
        32-byte X25519 public key.

    Raises:
        ValueError: If decoding fails or key has wrong length.
    """
    # Decode bech32
    hrp, data = bech32.bech32_decode(key_str)

    if hrp is None or data is None:
        raise ValueError(f"Invalid bech32 encoding: {key_str}")

    if hrp != AGE_BECH32_HRP:
        raise ValueError(f"Invalid HRP: expected '{AGE_BECH32_HRP}', got '{hrp}'")

    # Convert from 5-bit to 8-bit
    decoded = bech32.convertbits(data, 5, 8, False)
    if decoded is None:
        raise ValueError("Failed to convert bech32 data")

    pk = bytes(decoded)
    if len(pk) != 32:
        raise ValueError(f"Invalid key length: expected 32, got {len(pk)}")

    return pk


def encode_age_bech32(pk: bytes) -> str:
    """
    Encode an X25519 public key as standard age format (bech32).

    Args:
        pk: 32-byte X25519 public key.

    Returns:
        age public key string (age1...).

    Raises:
        ValueError: If public key has wrong length.
    """
    if len(pk) != 32:
        raise ValueError(f"Invalid key length: expected 32, got {len(pk)}")

    # Convert from 8-bit to 5-bit
    data = bech32.convertbits(list(pk), 8, 5, True)
    if data is None:
        raise ValueError("Failed to convert to bech32")

    return bech32.bech32_encode(AGE_BECH32_HRP, data)


# =============================================================================
# Key Serialization
# =============================================================================


def serialize_hybrid_public_key(keys: SecureKeyBundle) -> str:
    """
    Serialize hybrid public key for sharing.

    Format: Base64(x25519_pk || mlkem_pk)
    Prefixed with "age1pq" for identification.

    Args:
        keys: SecureKeyBundle with public keys.

    Returns:
        Base64-encoded hybrid public key string.
    """
    combined = keys["x25519_pk"] + keys["kyber_pk"]
    b64 = base64.b64encode(combined).decode("ascii")
    return f"{PQAGE_PUBLIC_KEY_PREFIX}{b64}"


def serialize_hybrid_secret_key(keys: SecureKeyBundle) -> str:
    """
    Serialize hybrid secret key for storage.

    Format: Base64(master_seed)
    Prefixed with "AGE-SECRET-KEY-PQ-" for identification.

    Args:
        keys: SecureKeyBundle with master seed.

    Returns:
        Serialized secret key string.
    """
    b64 = base64.b64encode(keys["master_seed"]).decode("ascii")
    return f"{PQAGE_SECRET_KEY_PREFIX}{b64}"


def parse_hybrid_public_key(key_str: str) -> tuple[bytes, bytes]:
    """
    Parse hybrid public key from string.

    Args:
        key_str: Serialized hybrid public key.

    Returns:
        Tuple of (x25519_pk, mlkem_pk).

    Raises:
        ValueError: If format is invalid.
    """
    key_str = key_str.strip()

    if key_str.startswith(PQAGE_PUBLIC_KEY_PREFIX):
        b64 = key_str[len(PQAGE_PUBLIC_KEY_PREFIX) :]
    else:
        # Try raw base64
        b64 = key_str

    try:
        data = base64.b64decode(b64)
    except Exception as e:
        raise ValueError(f"Invalid base64 in public key: {e}") from e

    # Check length: 32 (X25519) + 1568 (ML-KEM) = 1600
    if len(data) != 1600:
        raise ValueError(f"Invalid hybrid public key length: {len(data)} (expected 1600)")

    x25519_pk = data[:32]
    mlkem_pk = data[32:]

    return x25519_pk, mlkem_pk


def parse_hybrid_secret_key(key_str: str) -> SecureKeyBundle:
    """
    Parse hybrid secret key and regenerate full key bundle.

    Args:
        key_str: Serialized hybrid secret key.

    Returns:
        SecureKeyBundle regenerated from master seed.
        Caller should use with context manager or call .wipe() after use.

    Raises:
        ValueError: If format is invalid.
    """
    key_str = key_str.strip()

    if not key_str.startswith(PQAGE_SECRET_KEY_PREFIX):
        raise ValueError("Invalid secret key format - missing prefix")

    b64 = key_str[len(PQAGE_SECRET_KEY_PREFIX) :]

    try:
        master_seed = base64.b64decode(b64)
    except Exception as e:
        raise ValueError(f"Invalid base64 in secret key: {e}") from e

    if len(master_seed) != 32:
        raise ValueError(f"Invalid master seed length: {len(master_seed)}")

    return generate_keys(master_seed)


def decode_age_secret_key(key_str: str) -> bytes:
    """
    Decode a standard age secret key (bech32 encoded with uppercase).

    age secret keys are formatted as: AGE-SECRET-KEY-1<bech32-uppercase>
    The "1" after the prefix is the bech32 separator.

    Args:
        key_str: age secret key string starting with "AGE-SECRET-KEY-1".

    Returns:
        32-byte X25519 scalar.

    Raises:
        ValueError: If decoding fails or key has wrong length.
    """
    if not key_str.startswith(AGE_SECRET_KEY_PREFIX):
        raise ValueError(f"Invalid age secret key prefix: {key_str[:20]}...")

    # Remove the prefix to get the bech32 part (e.g., "1ABC...")
    # age uses uppercase bech32 with HRP "age-secret-key-"
    # The full key is bech32 with hrp="age-secret-key"

    # Convert to lowercase for bech32 decoding
    bech32_str = key_str.lower()

    # bech32 decode expects the full string including HRP
    hrp, data = bech32.bech32_decode(bech32_str)

    if hrp is None or data is None:
        raise ValueError("Invalid bech32 encoding in secret key")

    if hrp != "age-secret-key-":
        raise ValueError(f"Invalid HRP: expected 'age-secret-key-', got '{hrp}'")

    # Convert from 5-bit to 8-bit
    decoded = bech32.convertbits(data, 5, 8, False)
    if decoded is None:
        raise ValueError("Failed to convert bech32 data")

    scalar = bytes(decoded)
    if len(scalar) != 32:
        raise ValueError(f"Invalid scalar length: expected 32, got {len(scalar)}")

    return scalar


def load_identity_file(path: str) -> list[SecureKeyBundle | X25519Identity | None]:
    """
    Load identities from file.

    Supports:
    - pq-age hybrid identity files (AGE-SECRET-KEY-PQ-...)
    - Standard age X25519 identity files (AGE-SECRET-KEY-1...)
    - SSH private keys (~/.ssh/id_ed25519)

    Args:
        path: Path to identity file.

    Returns:
        List of identities (SecureKeyBundle, X25519Identity, or None for SSH).
        SecureKeyBundle entries should be wiped after use.

    Raises:
        FileNotFoundError: If file doesn't exist.
        ValueError: If format is invalid.
    """
    from nacl.bindings import crypto_scalarmult_base

    from pqage.age_file_ops import X25519Identity

    with open(path, encoding="utf-8") as f:
        content = f.read()

    identities: list[SecureKeyBundle | X25519Identity | None] = []

    for line in content.strip().split("\n"):
        line = line.strip()

        # Skip comments and empty lines
        if not line or line.startswith("#"):
            continue

        if line.startswith(PQAGE_SECRET_KEY_PREFIX):
            # pq-age hybrid key
            keys = parse_hybrid_secret_key(line)
            identities.append(keys)
        elif line.startswith(AGE_SECRET_KEY_PREFIX):
            # Standard age X25519 key
            try:
                scalar = decode_age_secret_key(line)
                pk = crypto_scalarmult_base(scalar)
                identities.append(X25519Identity(scalar, pk))
                logger.debug("Loaded standard age X25519 identity")
            except ValueError as e:
                logger.warning(f"Failed to parse age secret key: {e}")
        elif "-----BEGIN" in content:
            # SSH key file - handle separately
            return [None]  # Signal to use SSH key parsing

    return identities


# =============================================================================
# CLI Commands
# =============================================================================


def cmd_keygen(args: argparse.Namespace) -> int:
    """Generate hybrid keypair."""
    output = args.output

    # Check if output exists
    if output:
        out_path = Path(output)
        if out_path.exists() and not args.force:
            print(f"ERROR: {output} already exists. Use -f to overwrite.")
            return 1

    # Generate keys
    keys = generate_keys()

    # Serialize
    secret_key = serialize_hybrid_secret_key(keys)
    public_key = serialize_hybrid_public_key(keys)

    # Write to file or stdout
    if output:
        out_path = Path(output)
        out_path.parent.mkdir(parents=True, exist_ok=True)

        with open(out_path, "w", encoding="utf-8") as f:
            f.write(f"# created: pq-age v{__version__}\n")
            f.write(f"# public key: {public_key}\n")
            f.write(secret_key + "\n")

        # Secure permissions
        out_path.chmod(0o600)

        print(f"Public key: {public_key}")
        print(f"Identity saved to: {output}")
    else:
        # Print to stdout
        print(f"# public key: {public_key}")
        print(secret_key)

    return 0


def cmd_encrypt(args: argparse.Namespace) -> int:
    """Encrypt a file."""
    if not args.input:
        print("ERROR: Input file required")
        return 1

    recipients: list = []

    # Parse recipients from -r flags
    for r in args.recipient or []:
        r = r.strip()

        if r.startswith(PQAGE_PUBLIC_KEY_PREFIX):
            # Hybrid pq-age key
            try:
                x25519_pk, mlkem_pk = parse_hybrid_public_key(r)
                recipients.append(MlkemX25519Recipient(mlkem_pk, x25519_pk))
            except ValueError as e:
                print(f"ERROR: Invalid recipient key: {e}")
                return 1

        elif r.startswith(AGE_PUBLIC_KEY_PREFIX):
            # Standard age X25519 key (bech32 encoded)
            try:
                pk = decode_age_bech32(r)
                recipients.append(X25519Recipient(pk))
            except ValueError as e:
                print(f"ERROR: Invalid age recipient: {e}")
                return 1

        else:
            # Try as raw base64 (hybrid key format: 1600 bytes = X25519 PK + ML-KEM PK)
            try:
                data = base64.b64decode(r)
                if len(data) == 1600:
                    # Hybrid key
                    x25519_pk = data[:32]
                    mlkem_pk = data[32:]
                    recipients.append(MlkemX25519Recipient(mlkem_pk, x25519_pk))
                elif len(data) == 32:
                    # X25519 key
                    recipients.append(X25519Recipient(data))
                else:
                    print(f"ERROR: Unknown key format (length {len(data)})")
                    return 1
            except Exception as e:
                print(f"ERROR: Invalid recipient: {e}")
                return 1

    # Parse SSH recipients from -R flags
    for r_file in args.ssh_recipient or []:
        try:
            ssh_key = parse_ssh_public_key_file(r_file)
            recipients.append(SshEd25519Recipient(ssh_key))
        except FileNotFoundError:
            print(f"ERROR: SSH public key not found: {r_file}")
            return 1
        except Exception as e:
            print(f"ERROR: Invalid SSH public key: {e}")
            return 1

    # Password recipient
    if args.passphrase:
        password = getpass.getpass("Enter passphrase: ")
        password_confirm = getpass.getpass("Confirm passphrase: ")

        if password != password_confirm:
            print("ERROR: Passphrases do not match")
            return 1

        recipients.append(ScryptRecipient(password))

    if not recipients:
        print("ERROR: No recipients specified. Use -r, -R, or -p")
        return 1

    # Encrypt
    try:
        out_path = encrypt_file(
            args.input,
            recipients,
            args.output,
            armor=args.armor,
        )
        print(f"Encrypted: {out_path}")
        return 0

    except FileNotFoundError as e:
        print(f"ERROR: {e}")
        return 1
    except PqageError as e:
        print(f"ERROR: {e}")
        return 1


def cmd_decrypt(args: argparse.Namespace) -> int:
    """Decrypt a file."""
    if not args.input:
        print("ERROR: Input file required")
        return 1

    identities: list = []

    # Load identities from files
    for i_file in args.identity or []:
        try:
            # Try as SSH private key first
            if Path(i_file).name.startswith("id_"):
                try:
                    password = None
                    try:
                        ssh_key = parse_ssh_private_key_file(i_file)
                    except Exception:
                        password = getpass.getpass(f"Passphrase for {i_file}: ")
                        ssh_key = parse_ssh_private_key_file(i_file, password)
                    identities.append(SshEd25519Identity(ssh_key))
                    continue
                except Exception:
                    pass  # Not an SSH key, try pq-age format

            # Try pq-age identity file
            key_bundles = load_identity_file(i_file)
            for kb in key_bundles:
                if kb is not None:
                    # Check if it's a pq-age SecureKeyBundle or a standard X25519Identity
                    if isinstance(kb, X25519Identity):
                        # Standard age X25519 identity
                        identities.append(kb)
                        logger.debug("Added X25519Identity from identity file")
                    elif isinstance(kb, SecureKeyBundle):
                        # pq-age SecureKeyBundle
                        identities.append(
                            MlkemX25519Identity(
                                kb["kyber_sk"],
                                kb["x25519_sk"],
                                kb["kyber_pk"],
                                kb["x25519_pk"],
                            )
                        )
                        logger.debug("Added MlkemX25519Identity from identity file")

        except FileNotFoundError:
            print(f"ERROR: Identity file not found: {i_file}")
            return 1
        except Exception as e:
            print(f"ERROR: Invalid identity file: {e}")
            return 1

    # Password identity
    if args.passphrase or not identities:
        # If no identities provided, try password
        password = getpass.getpass("Enter passphrase: ")
        identities.append(ScryptIdentity(password))

    # Decrypt
    try:
        out_path = decrypt_file(
            args.input,
            identities,
            args.output,
        )
        print(f"Decrypted: {out_path}")
        return 0

    except FileNotFoundError as e:
        print(f"ERROR: {e}")
        return 1
    except PqageError as e:
        print(f"ERROR: {e}")
        return 1


# =============================================================================
# Main Entry Point
# =============================================================================


def main() -> int:
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="pqage",
        description=f"pq-age v{__version__} - age-compatible Post-Quantum Encryption",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  pqage-keygen -o ~/.pqage/identity.txt
  pqage -r age1pq... -o secret.age plaintext.txt
  pqage -d -i ~/.pqage/identity.txt secret.age
  pqage -R ~/.ssh/id_ed25519.pub -o secret.age plaintext.txt
  pqage -p -o secret.age plaintext.txt
""",
    )

    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Enable verbose output",
    )

    parser.add_argument(
        "--version",
        action="version",
        version=f"pq-age v{__version__}",
    )

    # Mode flags
    parser.add_argument(
        "-d",
        "--decrypt",
        action="store_true",
        help="Decrypt mode",
    )

    parser.add_argument(
        "-e",
        "--encrypt",
        action="store_true",
        help="Encrypt mode (default)",
    )

    # Recipient options
    parser.add_argument(
        "-r",
        "--recipient",
        action="append",
        metavar="RECIPIENT",
        help="Recipient public key (can be repeated)",
    )

    parser.add_argument(
        "-R",
        action="append",
        dest="ssh_recipient",
        metavar="PATH",
        help="Recipient SSH public key file (can be repeated)",
    )

    parser.add_argument(
        "-p",
        "--passphrase",
        action="store_true",
        help="Encrypt/decrypt with passphrase",
    )

    # Identity options
    parser.add_argument(
        "-i",
        "--identity",
        action="append",
        metavar="PATH",
        help="Identity file for decryption (can be repeated)",
    )

    # Output options
    parser.add_argument(
        "-o",
        "--output",
        metavar="PATH",
        help="Output file path",
    )

    parser.add_argument(
        "-a",
        "--armor",
        action="store_true",
        help="ASCII-armored output",
    )

    # Keygen options
    parser.add_argument(
        "-f",
        "--force",
        action="store_true",
        help="Overwrite existing files",
    )

    # Input file
    parser.add_argument(
        "input",
        nargs="?",
        help="Input file",
    )

    args = parser.parse_args()

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    # Determine mode
    if args.decrypt:
        return cmd_decrypt(args)
    else:
        return cmd_encrypt(args)


def keygen_main() -> int:
    """Keygen CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="pqage-keygen",
        description=f"pq-age v{__version__} - Generate hybrid post-quantum keypair",
    )

    parser.add_argument(
        "-o",
        "--output",
        metavar="PATH",
        help="Output file for identity (default: stdout)",
    )

    parser.add_argument(
        "-f",
        "--force",
        action="store_true",
        help="Overwrite existing file",
    )

    args = parser.parse_args()
    return cmd_keygen(args)


if __name__ == "__main__":
    sys.exit(main())
