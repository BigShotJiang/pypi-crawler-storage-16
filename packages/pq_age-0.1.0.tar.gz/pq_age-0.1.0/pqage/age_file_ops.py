"""
age-compatible file encryption and decryption operations for pq-age.

Provides high-level functions to encrypt/decrypt files using the
age v1 format with support for multiple recipient types:
- X25519 (classical age)
- scrypt (password-based)
- ssh-ed25519 (SSH keys)
- mlkem1024-x25519-v1 (hybrid post-quantum, pq-age extension)

This module is fully interoperable with age, rage, and other
age-compatible tools for non-PQ recipients.

Features:
- Multi-recipient: Encrypt once for any combination of recipient types
- Streaming: Uses age STREAM cipher for payload encryption
- ASCII armor: Optional PEM-style output for text transport
"""

import logging
import pathlib
from os import urandom

from pqage.age_format import (
    AgeHeader,
    MlkemX25519Stanza,
    ScryptStanza,
    SshEd25519Stanza,
    Stanza,
    X25519Stanza,
    is_age_file,
)
from pqage.crypto.age_recipients import (
    FILE_KEY_LEN,
    mlkem_x25519_decapsulate,
    mlkem_x25519_encapsulate,
    scrypt_decapsulate,
    scrypt_encapsulate,
    ssh_ed25519_decapsulate,
    ssh_ed25519_encapsulate,
    x25519_decapsulate,
    x25519_encapsulate,
)
from pqage.crypto.age_stream import stream_decrypt, stream_encrypt
from pqage.crypto.ssh import SshEd25519PrivateKey, SshEd25519PublicKey
from pqage.crypto.utils import secure_wipe
from pqage.exceptions import DecryptionError, EncryptionError, InvalidFileError

logger = logging.getLogger(__name__)

# =============================================================================
# Constants
# =============================================================================

# File extensions
AGE_FILE_EXTENSION: str = ".age"
ARMOR_FILE_EXTENSION: str = ".asc"

# Armor headers (age-compatible)
ARMOR_BEGIN: str = "-----BEGIN AGE ENCRYPTED FILE-----"
ARMOR_END: str = "-----END AGE ENCRYPTED FILE-----"
ARMOR_LINE_LENGTH: int = 64


# =============================================================================
# Recipient Type Definitions
# =============================================================================


class X25519Recipient:
    """X25519 recipient for classical age encryption."""

    def __init__(self, public_key: bytes):
        """
        Create X25519 recipient.

        Args:
            public_key: 32-byte X25519 public key.
        """
        if len(public_key) != 32:
            raise ValueError("X25519 public key must be 32 bytes")
        self.public_key = public_key


class SshEd25519Recipient:
    """SSH Ed25519 recipient."""

    def __init__(self, ssh_key: SshEd25519PublicKey):
        """
        Create SSH Ed25519 recipient.

        Args:
            ssh_key: Parsed SSH Ed25519 public key.
        """
        self.ssh_key = ssh_key


class MlkemX25519Recipient:
    """Hybrid ML-KEM-1024 + X25519 recipient (post-quantum)."""

    def __init__(self, mlkem_pk: bytes, x25519_pk: bytes):
        """
        Create hybrid recipient.

        Args:
            mlkem_pk: 1568-byte ML-KEM-1024 public key.
            x25519_pk: 32-byte X25519 public key.
        """
        if len(mlkem_pk) != 1568:
            raise ValueError("ML-KEM public key must be 1568 bytes")
        if len(x25519_pk) != 32:
            raise ValueError("X25519 public key must be 32 bytes")
        self.mlkem_pk = mlkem_pk
        self.x25519_pk = x25519_pk


class ScryptRecipient:
    """Password-based recipient using scrypt."""

    def __init__(self, password: str, work_factor: int = 18):
        """
        Create scrypt recipient.

        Args:
            password: Encryption password.
            work_factor: scrypt work factor as log2(N). Default 18.
        """
        self.password = password
        self.work_factor = work_factor


# Type alias for any recipient
Recipient = X25519Recipient | SshEd25519Recipient | MlkemX25519Recipient | ScryptRecipient


# =============================================================================
# Identity Type Definitions (for decryption)
# =============================================================================


class X25519Identity:
    """X25519 identity for decryption."""

    def __init__(self, secret_key: bytes, public_key: bytes):
        """
        Create X25519 identity.

        Args:
            secret_key: 32-byte X25519 secret key.
            public_key: 32-byte X25519 public key.
        """
        self.secret_key = secret_key
        self.public_key = public_key


class SshEd25519Identity:
    """SSH Ed25519 identity for decryption."""

    def __init__(self, ssh_key: SshEd25519PrivateKey):
        """
        Create SSH Ed25519 identity.

        Args:
            ssh_key: Parsed SSH Ed25519 private key.
        """
        self.ssh_key = ssh_key


class MlkemX25519Identity:
    """Hybrid ML-KEM + X25519 identity for decryption."""

    def __init__(
        self,
        mlkem_sk: bytes,
        x25519_sk: bytes,
        mlkem_pk: bytes,
        x25519_pk: bytes,
    ):
        """
        Create hybrid identity.

        Args:
            mlkem_sk: ML-KEM-1024 secret key.
            x25519_sk: X25519 secret key.
            mlkem_pk: ML-KEM-1024 public key.
            x25519_pk: X25519 public key.
        """
        self.mlkem_sk = mlkem_sk
        self.x25519_sk = x25519_sk
        self.mlkem_pk = mlkem_pk
        self.x25519_pk = x25519_pk


class ScryptIdentity:
    """Password identity for scrypt decryption."""

    def __init__(self, password: str):
        """
        Create scrypt identity.

        Args:
            password: Decryption password.
        """
        self.password = password


# Type alias for any identity
Identity = X25519Identity | SshEd25519Identity | MlkemX25519Identity | ScryptIdentity


# =============================================================================
# Encryption
# =============================================================================


def encrypt(
    plaintext: bytes,
    recipients: list[Recipient],
) -> bytes:
    """
    Encrypt data for multiple recipients.

    Args:
        plaintext: Data to encrypt.
        recipients: List of recipients.

    Returns:
        Encrypted age file as bytes.

    Raises:
        EncryptionError: If encryption fails.
    """
    logger.debug(
        "encrypt: Starting encryption (plaintext_len=%d, recipients=%d)",
        len(plaintext),
        len(recipients),
    )

    if not recipients:
        raise EncryptionError("At least one recipient required")

    file_key_buf: bytearray | None = None

    try:
        # Generate random file key
        file_key = urandom(FILE_KEY_LEN)
        file_key_buf = bytearray(file_key)
        logger.debug("encrypt: File key generated")

        # Create stanzas for each recipient
        stanzas: list[Stanza] = []

        for recipient in recipients:
            if isinstance(recipient, X25519Recipient):
                stanza = x25519_encapsulate(recipient.public_key, file_key)
                stanzas.append(stanza)

            elif isinstance(recipient, SshEd25519Recipient):
                stanza = ssh_ed25519_encapsulate(
                    recipient.ssh_key.x25519_pk,
                    recipient.ssh_key.key_hash,
                    recipient.ssh_key.ssh_key_blob,
                    file_key,
                )
                stanzas.append(stanza)

            elif isinstance(recipient, MlkemX25519Recipient):
                stanza = mlkem_x25519_encapsulate(
                    recipient.mlkem_pk,
                    recipient.x25519_pk,
                    file_key,
                )
                stanzas.append(stanza)

            elif isinstance(recipient, ScryptRecipient):
                stanza = scrypt_encapsulate(
                    recipient.password,
                    file_key,
                    recipient.work_factor,
                )
                stanzas.append(stanza)

            else:
                raise EncryptionError(f"Unknown recipient type: {type(recipient)}")

        # Create header
        header = AgeHeader(stanzas=stanzas)
        header_bytes = header.serialize(file_key)

        # Generate random 16-byte nonce (age writes this to file)
        # This nonce is used ONLY for HKDF, NOT as a nonce prefix for STREAM
        nonce_full = urandom(16)

        # Derive payload key from file key (age spec)
        # age: payload_key = HKDF(ikm=file_key, salt=nonce, info="payload", len=32)
        from pqage.crypto.kdf import hkdf_sha256

        payload_key_buf = hkdf_sha256(file_key_buf, nonce_full, b"payload", 32)

        try:
            # Encrypt payload
            import io

            input_stream = io.BytesIO(plaintext)
            output_stream = io.BytesIO()

            # age writes 16-byte nonce to file first
            output_stream.write(nonce_full)

            # Encrypt with STREAM
            stream_encrypt(input_stream, output_stream, bytes(payload_key_buf))

            payload = output_stream.getvalue()
            result = header_bytes + payload

            logger.debug(
                "encrypt: Encryption complete (ciphertext_len=%d)",
                len(result),
            )

            return result

        finally:
            secure_wipe(payload_key_buf)

    finally:
        if file_key_buf is not None:
            secure_wipe(file_key_buf)


def encrypt_file(
    input_path: str,
    recipients: list[Recipient],
    output_path: str | None = None,
    armor: bool = False,
) -> str:
    """
    Encrypt a file for multiple recipients.

    Args:
        input_path: Path to plaintext file.
        recipients: List of recipients.
        output_path: Optional output path. Defaults to input + .age or .age.asc.
        armor: If True, output ASCII-armored.

    Returns:
        Path to encrypted file.

    Raises:
        FileNotFoundError: If input file doesn't exist.
        EncryptionError: If encryption fails.
    """
    in_path = pathlib.Path(input_path)

    if not in_path.exists():
        raise FileNotFoundError(f"Input file not found: {input_path}")

    if not in_path.is_file():
        raise EncryptionError(f"Not a file: {input_path}")

    # Read plaintext
    with open(in_path, "rb") as f:
        plaintext = f.read()

    # Encrypt
    encrypted = encrypt(plaintext, recipients)

    # Determine output path
    if output_path:
        out_path = pathlib.Path(output_path)
    else:
        ext = AGE_FILE_EXTENSION + (ARMOR_FILE_EXTENSION if armor else "")
        out_path = in_path.with_suffix(in_path.suffix + ext)

    # Write output
    if armor:
        armored = _armor_encode(encrypted)
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(armored)
    else:
        with open(out_path, "wb") as f:
            f.write(encrypted)

    return str(out_path)


# =============================================================================
# Decryption
# =============================================================================


def decrypt(
    ciphertext: bytes,
    identities: list[Identity],
) -> bytes:
    """
    Decrypt age-encrypted data.

    Args:
        ciphertext: Encrypted age file bytes.
        identities: List of identities to try.

    Returns:
        Decrypted plaintext.

    Raises:
        InvalidFileError: If file format is invalid.
        DecryptionError: If decryption fails.
    """
    logger.debug(
        "decrypt: Starting decryption (ciphertext_len=%d, identities=%d)",
        len(ciphertext),
        len(identities),
    )

    if not identities:
        raise DecryptionError("At least one identity required")

    # Check for armor
    if _is_armored(ciphertext):
        ciphertext = _armor_decode(ciphertext.decode("utf-8"))
        logger.debug("decrypt: Decoded ASCII armor")

    # Check for age header
    if not is_age_file(ciphertext):
        raise InvalidFileError("Not an age-encrypted file")

    # Parse header
    header, payload_offset = AgeHeader.parse(ciphertext)
    payload = ciphertext[payload_offset:]
    logger.debug(
        "decrypt: Header parsed (stanzas=%d, payload_len=%d)",
        len(header.stanzas),
        len(payload),
    )

    # Try to decrypt with each identity
    file_key: bytes | None = None
    file_key_buf: bytearray | None = None

    for identity in identities:
        for stanza in header.stanzas:
            try:
                if isinstance(identity, X25519Identity):
                    if stanza.stanza_type == "X25519":
                        typed_stanza = X25519Stanza.from_stanza(stanza)
                        file_key = x25519_decapsulate(
                            typed_stanza,
                            identity.secret_key,
                            identity.public_key,
                        )
                        break

                elif isinstance(identity, SshEd25519Identity):
                    if stanza.stanza_type == "ssh-ed25519":
                        typed_stanza = SshEd25519Stanza.from_stanza(stanza)
                        # Check key hash
                        from pqage.crypto.utils import secure_compare

                        if secure_compare(typed_stanza.key_hash, identity.ssh_key.key_hash):
                            file_key = ssh_ed25519_decapsulate(
                                typed_stanza,
                                identity.ssh_key.x25519_sk,
                                identity.ssh_key.x25519_pk,
                                identity.ssh_key.key_hash,
                                identity.ssh_key.ssh_key_blob,
                            )
                            break

                elif isinstance(identity, MlkemX25519Identity):
                    if stanza.stanza_type == "mlkem1024-x25519-v1":
                        typed_stanza = MlkemX25519Stanza.from_stanza(stanza)
                        file_key = mlkem_x25519_decapsulate(
                            typed_stanza,
                            identity.mlkem_sk,
                            identity.x25519_sk,
                            identity.mlkem_pk,
                            identity.x25519_pk,
                        )
                        break

                elif isinstance(identity, ScryptIdentity) and stanza.stanza_type == "scrypt":
                    typed_stanza = ScryptStanza.from_stanza(stanza)
                    file_key = scrypt_decapsulate(
                        typed_stanza,
                        identity.password,
                    )
                    break

            except Exception as e:
                logger.debug("Stanza decryption failed: %s", e)
                continue

        if file_key is not None:
            break

    if file_key is None:
        raise DecryptionError("No matching identity found - wrong key or corrupted file")

    file_key_buf = bytearray(file_key)

    try:
        # Verify header MAC
        if not header.verify_mac(bytes(file_key_buf)):
            raise DecryptionError("Header MAC verification failed")

        # Extract 16-byte nonce from payload (age writes it first)
        nonce_full_len = 16
        if len(payload) < nonce_full_len:
            raise InvalidFileError("Payload too short - missing nonce")

        nonce_full = payload[:nonce_full_len]
        stream_payload = payload[nonce_full_len:]

        # Derive payload key from file key (age spec)
        # age: payload_key = HKDF(ikm=file_key, salt=nonce, info="payload", len=32)
        from pqage.crypto.kdf import hkdf_sha256

        payload_key_buf = hkdf_sha256(file_key_buf, nonce_full, b"payload", 32)

        try:
            # Decrypt payload
            import io

            input_stream = io.BytesIO(stream_payload)
            output_stream = io.BytesIO()

            stream_decrypt(input_stream, output_stream, bytes(payload_key_buf))

            plaintext = output_stream.getvalue()
            logger.debug(
                "decrypt: Decryption complete (plaintext_len=%d)",
                len(plaintext),
            )

            return plaintext

        finally:
            secure_wipe(payload_key_buf)

    finally:
        if file_key_buf is not None:
            secure_wipe(file_key_buf)


def decrypt_file(
    input_path: str,
    identities: list[Identity],
    output_path: str | None = None,
) -> str:
    """
    Decrypt an age-encrypted file.

    Args:
        input_path: Path to encrypted file.
        identities: List of identities to try.
        output_path: Optional output path. Defaults to input without .age extension.

    Returns:
        Path to decrypted file.

    Raises:
        FileNotFoundError: If input file doesn't exist.
        DecryptionError: If decryption fails.
    """
    in_path = pathlib.Path(input_path)

    if not in_path.exists():
        raise FileNotFoundError(f"Input file not found: {input_path}")

    if not in_path.is_file():
        raise DecryptionError(f"Not a file: {input_path}")

    # Read ciphertext
    with open(in_path, "rb") as f:
        ciphertext = f.read()

    # Decrypt
    plaintext = decrypt(ciphertext, identities)

    # Determine output path
    if output_path:
        out_path = pathlib.Path(output_path)
    else:
        name = in_path.name
        # Strip .asc and .age extensions
        if name.endswith(ARMOR_FILE_EXTENSION):
            name = name[: -len(ARMOR_FILE_EXTENSION)]
        if name.endswith(AGE_FILE_EXTENSION):
            name = name[: -len(AGE_FILE_EXTENSION)]
        if name == in_path.name:
            # No extension stripped, add .decrypted
            name = name + ".decrypted"
        out_path = in_path.parent / name

    # Write output
    with open(out_path, "wb") as f:
        f.write(plaintext)

    return str(out_path)


# =============================================================================
# Armor Encoding/Decoding
# =============================================================================


def _armor_encode(data: bytes) -> str:
    """
    Encode data as ASCII-armored age file.

    Args:
        data: Binary data to encode.

    Returns:
        ASCII-armored string.
    """
    import base64

    b64 = base64.b64encode(data).decode("ascii")

    # Wrap at 64 characters
    lines = [b64[i : i + ARMOR_LINE_LENGTH] for i in range(0, len(b64), ARMOR_LINE_LENGTH)]

    return ARMOR_BEGIN + "\n" + "\n".join(lines) + "\n" + ARMOR_END + "\n"


def _armor_decode(armored: str) -> bytes:
    """
    Decode ASCII-armored age file.

    Args:
        armored: ASCII-armored string.

    Returns:
        Decoded binary data.

    Raises:
        InvalidFileError: If armor format is invalid.
    """
    import base64
    import re

    pattern = re.compile(
        r"-----BEGIN AGE ENCRYPTED FILE-----\s*\n"
        r"([\s\S]*?)"
        r"\n-----END AGE ENCRYPTED FILE-----"
    )

    match = pattern.search(armored)
    if not match:
        raise InvalidFileError("Invalid armor format")

    b64_content = "".join(match.group(1).split())

    try:
        return base64.b64decode(b64_content)
    except Exception as e:
        raise InvalidFileError(f"Invalid base64 in armor: {e}") from e


def _is_armored(data: bytes) -> bool:
    """Check if data is ASCII-armored."""
    try:
        text = data[:100].decode("utf-8", errors="ignore")
        return ARMOR_BEGIN in text
    except Exception:
        return False


# =============================================================================
# Helper Functions
# =============================================================================


def create_mlkem_x25519_recipient_from_keys(
    x25519_pk: bytes, mlkem_pk: bytes
) -> MlkemX25519Recipient:
    """
    Create hybrid recipient from separate keys.

    Args:
        x25519_pk: 32-byte X25519 public key.
        mlkem_pk: 1568-byte ML-KEM-1024 public key.

    Returns:
        MlkemX25519Recipient instance.
    """
    return MlkemX25519Recipient(mlkem_pk, x25519_pk)


def create_mlkem_x25519_identity_from_keys(
    x25519_sk: bytes,
    x25519_pk: bytes,
    mlkem_sk: bytes,
    mlkem_pk: bytes,
) -> MlkemX25519Identity:
    """
    Create hybrid identity from separate keys.

    Args:
        x25519_sk: 32-byte X25519 secret key.
        x25519_pk: 32-byte X25519 public key.
        mlkem_sk: ML-KEM-1024 secret key.
        mlkem_pk: ML-KEM-1024 public key.

    Returns:
        MlkemX25519Identity instance.
    """
    return MlkemX25519Identity(mlkem_sk, x25519_sk, mlkem_pk, x25519_pk)
