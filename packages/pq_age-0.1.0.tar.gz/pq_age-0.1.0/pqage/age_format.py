"""
age v1 file format parser and writer for pq-age.

Implements the age-encryption.org/v1 format specification with support for:
- X25519 recipients (classical age)
- scrypt recipients (password-based)
- ssh-ed25519 recipients (SSH keys)
- mlkem-x25519 recipients (hybrid post-quantum, pq-age extension)

Format specification: https://age-encryption.org/v1

Header format:
    age-encryption.org/v1
    -> recipient-type arg1 arg2 ...
    base64-wrapped-file-key
    -> another-recipient-type ...
    base64-wrapped-file-key
    --- base64-header-MAC
    <binary-STREAM-encrypted-payload>

Security:
    - Header MAC prevents tampering with recipient stanzas
    - HKDF used for key derivation (not BLAKE3 for age compat)
    - All comparisons are constant-time
"""

import base64
import hashlib
import hmac
import logging
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Self

from pqage.crypto.kdf import hkdf_sha256
from pqage.crypto.utils import secure_compare, secure_wipe
from pqage.exceptions import InvalidFileError

logger = logging.getLogger(__name__)

# =============================================================================
# Constants
# =============================================================================

AGE_HEADER_LINE: bytes = b"age-encryption.org/v1"
AGE_HEADER_LINE_STR: str = "age-encryption.org/v1"

STANZA_PREFIX: str = "->"
MAC_PREFIX: str = "---"

# Maximum lengths for DoS protection
MAX_STANZA_ARGS: int = 10
MAX_STANZA_BODY_LINES: int = 100
MAX_BODY_LINE_LEN: int = 64
MAX_RECIPIENTS: int = 1000

# Regex patterns
# age spec: stanza-type = 1*VCHAR, where VCHAR = %x21-7E (printable ASCII excl. space)
# This allows grease stanzas like ";f-grease" from rage
STANZA_LINE_PATTERN = re.compile(r"^-> ([\x21-\x7E]+)(?: (.+))?$")
MAC_LINE_PATTERN = re.compile(r"^--- ([A-Za-z0-9+/]+)$")  # No = in pattern (age uses no padding)


# =============================================================================
# age-format Base64 helpers (NO PADDING)
# =============================================================================


def age_b64encode(data: bytes) -> str:
    """
    Encode bytes to base64 string WITHOUT padding (age format).

    Args:
        data: Bytes to encode.

    Returns:
        Base64 string without '=' padding.
    """
    return base64.b64encode(data).decode("ascii").rstrip("=")


def age_b64decode(s: str) -> bytes:
    """
    Decode base64 string to bytes, adding padding if needed (age format).

    Args:
        s: Base64 string (with or without padding).

    Returns:
        Decoded bytes.
    """
    # Add padding if necessary
    padding_needed = (4 - len(s) % 4) % 4
    return base64.b64decode(s + "=" * padding_needed)


# =============================================================================
# Stanza Types
# =============================================================================


class StanzaType(Enum):
    """Supported recipient stanza types."""

    X25519 = "X25519"
    SCRYPT = "scrypt"
    SSH_ED25519 = "ssh-ed25519"
    SSH_RSA = "ssh-rsa"
    MLKEM_X25519 = "mlkem1024-x25519-v1"  # pq-age hybrid extension (v1)


# =============================================================================
# Stanza Data Classes
# =============================================================================


@dataclass
class Stanza:
    """
    Base class for age recipient stanzas.

    A stanza consists of:
    - Type identifier (e.g., "X25519", "scrypt")
    - Arguments (space-separated on the type line)
    - Body (base64-encoded wrapped file key, 64-char lines)
    """

    stanza_type: str
    args: list[str] = field(default_factory=list)
    body: bytes = b""

    def serialize(self) -> str:
        """
        Serialize stanza to age format string.

        age format rules:
        - Base64 without padding (no '=' chars)
        - 64-char line wrapping
        - Last line MUST be shorter than 64 chars (or empty if divisible)

        Returns:
            Multi-line string in age stanza format.
        """
        # Header line: -> type arg1 arg2 ...
        if self.args:
            header = f"{STANZA_PREFIX} {self.stanza_type} {' '.join(self.args)}"
        else:
            header = f"{STANZA_PREFIX} {self.stanza_type}"

        # Body: base64 WITHOUT padding, 64-char line wrapping
        b64_body = age_b64encode(self.body)
        body_lines = [
            b64_body[i : i + MAX_BODY_LINE_LEN] for i in range(0, len(b64_body), MAX_BODY_LINE_LEN)
        ]

        # age format: stanza must end with a line shorter than 64 chars
        # If body is empty or last line is exactly 64 chars, add empty line
        if not body_lines or len(body_lines[-1]) == MAX_BODY_LINE_LEN:
            body_lines.append("")

        return header + "\n" + "\n".join(body_lines)

    @classmethod
    def parse(cls, lines: list[str]) -> tuple[Self, int]:
        """
        Parse a stanza from lines.

        Args:
            lines: List of lines starting with stanza header.

        Returns:
            Tuple of (Stanza, lines_consumed).

        Raises:
            InvalidFileError: If stanza format is invalid.
        """
        if not lines:
            raise InvalidFileError("Empty stanza")

        # Parse header line
        header = lines[0]
        match = STANZA_LINE_PATTERN.match(header)
        if not match:
            raise InvalidFileError(f"Invalid stanza header: {header}")

        stanza_type = match.group(1)
        args_str = match.group(2)
        args = args_str.split() if args_str else []

        if len(args) > MAX_STANZA_ARGS:
            raise InvalidFileError(f"Too many stanza arguments: {len(args)}")

        # Parse body lines (base64, until next stanza or MAC)
        body_lines: list[str] = []
        line_idx = 1

        while line_idx < len(lines):
            line = lines[line_idx]

            # Stop at next stanza or MAC
            if line.startswith(STANZA_PREFIX) or line.startswith(MAC_PREFIX):
                break

            # Validate body line (must be base64)
            if len(line) > MAX_BODY_LINE_LEN:
                raise InvalidFileError(f"Body line too long: {len(line)}")

            body_lines.append(line)
            line_idx += 1

            if len(body_lines) > MAX_STANZA_BODY_LINES:
                raise InvalidFileError("Stanza body too long")

        # Decode body (age uses base64 WITHOUT padding)
        b64_body = "".join(body_lines)
        try:
            body = age_b64decode(b64_body) if b64_body else b""
        except Exception as e:
            raise InvalidFileError(f"Invalid base64 in stanza body: {e}") from e

        return cls(stanza_type=stanza_type, args=args, body=body), line_idx


# =============================================================================
# Specialized Stanza Classes
# =============================================================================


@dataclass
class X25519Stanza(Stanza):
    """
    X25519 recipient stanza.

    Format: -> X25519 <ephemeral-share-base64>
            <wrapped-file-key-base64>

    The ephemeral share is the sender's ephemeral X25519 public key.
    The body contains the file key encrypted with the shared secret.

    Construction:
        Use X25519Stanza.create() to create new stanzas.
        Use X25519Stanza.from_stanza() to parse from generic Stanza.
    """

    ephemeral_share: bytes = b""

    @classmethod
    def create(cls, ephemeral_share: bytes, body: bytes) -> Self:
        """
        Create new X25519 stanza with typed fields.

        Args:
            ephemeral_share: 32-byte ephemeral X25519 public key.
            body: Wrapped file key (32 bytes: ciphertext + tag).

        Returns:
            New X25519Stanza with args populated from typed fields.
        """
        return cls(
            stanza_type=StanzaType.X25519.value,
            args=[age_b64encode(ephemeral_share)],
            body=body,
            ephemeral_share=ephemeral_share,
        )

    @classmethod
    def from_stanza(cls, stanza: Stanza) -> Self:
        """
        Parse X25519Stanza from generic Stanza.

        Args:
            stanza: Generic Stanza with X25519 type.

        Returns:
            X25519Stanza with typed fields populated from args.

        Raises:
            InvalidFileError: If stanza is not valid X25519.
        """
        if stanza.stanza_type != StanzaType.X25519.value:
            raise InvalidFileError(f"Not an X25519 stanza: {stanza.stanza_type}")
        if len(stanza.args) != 1:
            raise InvalidFileError(f"X25519 stanza requires 1 argument, got {len(stanza.args)}")

        try:
            ephemeral_share = age_b64decode(stanza.args[0])
        except Exception as e:
            raise InvalidFileError(f"Invalid X25519 ephemeral share: {e}") from e

        return cls(
            stanza_type=stanza.stanza_type,
            args=stanza.args,
            body=stanza.body,
            ephemeral_share=ephemeral_share,
        )


@dataclass
class ScryptStanza(Stanza):
    """
    scrypt recipient stanza (password-based).

    Format: -> scrypt <salt-base64> <log2-work-factor>
            <wrapped-file-key-base64>

    The salt is 16 bytes, work factor is typically 18-22.

    Construction:
        Use ScryptStanza.create() to create new stanzas.
        Use ScryptStanza.from_stanza() to parse from generic Stanza.
    """

    salt: bytes = b""
    log_n: int = 0

    @classmethod
    def create(cls, salt: bytes, log_n: int, body: bytes) -> Self:
        """
        Create new scrypt stanza with typed fields.

        Args:
            salt: 16-byte random salt.
            log_n: scrypt work factor (log2 N, typically 18-22).
            body: Wrapped file key (32 bytes: ciphertext + tag).

        Returns:
            New ScryptStanza with args populated from typed fields.
        """
        return cls(
            stanza_type=StanzaType.SCRYPT.value,
            args=[age_b64encode(salt), str(log_n)],
            body=body,
            salt=salt,
            log_n=log_n,
        )

    @classmethod
    def from_stanza(cls, stanza: Stanza) -> Self:
        """
        Parse ScryptStanza from generic Stanza.

        Args:
            stanza: Generic Stanza with scrypt type.

        Returns:
            ScryptStanza with typed fields populated from args.

        Raises:
            InvalidFileError: If stanza is not valid scrypt.
        """
        if stanza.stanza_type != StanzaType.SCRYPT.value:
            raise InvalidFileError(f"Not a scrypt stanza: {stanza.stanza_type}")
        if len(stanza.args) != 2:
            raise InvalidFileError(f"scrypt stanza requires 2 arguments, got {len(stanza.args)}")

        try:
            salt = age_b64decode(stanza.args[0])
            log_n = int(stanza.args[1])
        except Exception as e:
            raise InvalidFileError(f"Invalid scrypt parameters: {e}") from e

        return cls(
            stanza_type=stanza.stanza_type,
            args=stanza.args,
            body=stanza.body,
            salt=salt,
            log_n=log_n,
        )


@dataclass
class SshEd25519Stanza(Stanza):
    """
    ssh-ed25519 recipient stanza.

    Format: -> ssh-ed25519 <key-fingerprint-base64> <ephemeral-share-base64>
            <wrapped-file-key-base64>

    The key fingerprint is SHA256(public_key), truncated to 4 bytes.

    Construction:
        Use SshEd25519Stanza.create() to create new stanzas.
        Use SshEd25519Stanza.from_stanza() to parse from generic Stanza.
    """

    key_hash: bytes = b""
    ephemeral_share: bytes = b""

    @classmethod
    def create(cls, key_hash: bytes, ephemeral_share: bytes, body: bytes) -> Self:
        """
        Create new ssh-ed25519 stanza with typed fields.

        Args:
            key_hash: 4-byte key fingerprint (SHA256(pubkey)[:4]).
            ephemeral_share: 32-byte ephemeral X25519 public key.
            body: Wrapped file key (32 bytes: ciphertext + tag).

        Returns:
            New SshEd25519Stanza with args populated from typed fields.
        """
        return cls(
            stanza_type=StanzaType.SSH_ED25519.value,
            args=[age_b64encode(key_hash), age_b64encode(ephemeral_share)],
            body=body,
            key_hash=key_hash,
            ephemeral_share=ephemeral_share,
        )

    @classmethod
    def from_stanza(cls, stanza: Stanza) -> Self:
        """
        Parse SshEd25519Stanza from generic Stanza.

        Args:
            stanza: Generic Stanza with ssh-ed25519 type.

        Returns:
            SshEd25519Stanza with typed fields populated from args.

        Raises:
            InvalidFileError: If stanza is not valid ssh-ed25519.
        """
        if stanza.stanza_type != StanzaType.SSH_ED25519.value:
            raise InvalidFileError(f"Not an ssh-ed25519 stanza: {stanza.stanza_type}")
        if len(stanza.args) != 2:
            raise InvalidFileError(
                f"ssh-ed25519 stanza requires 2 arguments, got {len(stanza.args)}"
            )

        try:
            key_hash = age_b64decode(stanza.args[0])
            ephemeral_share = age_b64decode(stanza.args[1])
        except Exception as e:
            raise InvalidFileError(f"Invalid ssh-ed25519 parameters: {e}") from e

        return cls(
            stanza_type=stanza.stanza_type,
            args=stanza.args,
            body=stanza.body,
            key_hash=key_hash,
            ephemeral_share=ephemeral_share,
        )


@dataclass
class MlkemX25519Stanza(Stanza):
    """
    Hybrid ML-KEM-1024 + X25519 recipient stanza (pq-age extension v1).

    Format: -> mlkem1024-x25519-v1 <fingerprint-b64> <mlkem-ct-b64> <x25519-eph-b64>
            <wrapped-file-key-base64>

    This stanza provides post-quantum security through hybrid encryption:
    - Key fingerprint (4 bytes): SHA256(mlkem_pk || x25519_pk)[:4]
    - ML-KEM-1024 ciphertext (1568 bytes)
    - X25519 ephemeral public key (32 bytes)
    - Both shared secrets combined via HKDF with structured transcript

    Construction:
        Use MlkemX25519Stanza.create() to create new stanzas.
        Use MlkemX25519Stanza.from_stanza() to parse from generic Stanza.
    """

    key_fingerprint: bytes = b""
    mlkem_ciphertext: bytes = b""
    x25519_ephemeral: bytes = b""

    @classmethod
    def create(
        cls,
        key_fingerprint: bytes,
        mlkem_ciphertext: bytes,
        x25519_ephemeral: bytes,
        body: bytes,
    ) -> Self:
        """
        Create new ML-KEM + X25519 hybrid stanza with typed fields.

        Args:
            key_fingerprint: 4-byte fingerprint SHA256(mlkem_pk || x25519_pk)[:4].
            mlkem_ciphertext: 1568-byte ML-KEM-1024 ciphertext.
            x25519_ephemeral: 32-byte ephemeral X25519 public key.
            body: Wrapped file key (32 bytes: ciphertext + tag).

        Returns:
            New MlkemX25519Stanza with args populated from typed fields.
        """
        return cls(
            stanza_type=StanzaType.MLKEM_X25519.value,
            args=[
                age_b64encode(key_fingerprint),
                age_b64encode(mlkem_ciphertext),
                age_b64encode(x25519_ephemeral),
            ],
            body=body,
            key_fingerprint=key_fingerprint,
            mlkem_ciphertext=mlkem_ciphertext,
            x25519_ephemeral=x25519_ephemeral,
        )

    @classmethod
    def from_stanza(cls, stanza: Stanza) -> Self:
        """
        Parse MlkemX25519Stanza from generic Stanza.

        Args:
            stanza: Generic Stanza with mlkem1024-x25519-v1 type.

        Returns:
            MlkemX25519Stanza with typed fields populated from args.

        Raises:
            InvalidFileError: If stanza is not valid mlkem1024-x25519-v1.
        """
        if stanza.stanza_type != StanzaType.MLKEM_X25519.value:
            raise InvalidFileError(f"Not an mlkem1024-x25519-v1 stanza: {stanza.stanza_type}")
        if len(stanza.args) != 3:
            raise InvalidFileError(
                f"mlkem1024-x25519-v1 stanza requires 3 arguments, got {len(stanza.args)}"
            )

        try:
            key_fingerprint = age_b64decode(stanza.args[0])
            mlkem_ciphertext = age_b64decode(stanza.args[1])
            x25519_ephemeral = age_b64decode(stanza.args[2])
        except Exception as e:
            raise InvalidFileError(f"Invalid mlkem1024-x25519-v1 parameters: {e}") from e

        return cls(
            stanza_type=stanza.stanza_type,
            args=stanza.args,
            body=stanza.body,
            key_fingerprint=key_fingerprint,
            mlkem_ciphertext=mlkem_ciphertext,
            x25519_ephemeral=x25519_ephemeral,
        )


# =============================================================================
# age Header
# =============================================================================


@dataclass
class AgeHeader:
    """
    age file header containing recipient stanzas and MAC.

    The header is authenticated with HMAC-SHA256 using a key derived
    from the file key via HKDF.
    """

    stanzas: list[Stanza] = field(default_factory=list)
    mac: bytes = b""

    def serialize(self, file_key: bytes | None = None) -> bytes:
        """
        Serialize header to bytes (including MAC if file_key provided).

        Args:
            file_key: 16-byte file key for MAC computation.
                     If None, uses existing MAC or empty.

        Returns:
            Header bytes (UTF-8 encoded, ends with newline after MAC).
        """
        lines: list[str] = [AGE_HEADER_LINE_STR]

        # Add all stanzas
        for stanza in self.stanzas:
            lines.append(stanza.serialize())

        # Compute MAC if file_key provided
        # age MACs the header INCLUDING the "---" marker but NOT the MAC value
        # Format: "age-encryption.org/v1\n-> ...\n...\n---"
        if file_key is not None:
            header_bytes = ("\n".join(lines) + "\n" + MAC_PREFIX).encode("utf-8")
            self.mac = _compute_header_mac(header_bytes, file_key)

        # Add MAC line (age uses base64 without padding)
        mac_b64 = age_b64encode(self.mac)
        lines.append(f"{MAC_PREFIX} {mac_b64}")

        # Join with newlines, add final newline
        return ("\n".join(lines) + "\n").encode("utf-8")

    @classmethod
    def parse(cls, data: bytes) -> tuple[Self, int]:
        """
        Parse age header from bytes.

        Args:
            data: Raw file data starting with header.

        Returns:
            Tuple of (AgeHeader, payload_offset).

        Raises:
            InvalidFileError: If header format is invalid.
        """
        # Decode to text (header is always UTF-8/ASCII)
        try:
            # Find the end of header (first occurrence of "---" line + newline)
            # We need to find where the binary payload starts
            header_end = data.find(b"\n---")
            if header_end == -1:
                raise InvalidFileError("Missing header MAC line")

            # Find the newline after the MAC line
            mac_line_end = data.find(b"\n", header_end + 1)
            if mac_line_end == -1:
                raise InvalidFileError("Truncated header MAC line")

            header_text = data[: mac_line_end + 1].decode("utf-8")
            payload_offset = mac_line_end + 1

        except UnicodeDecodeError as e:
            raise InvalidFileError(f"Invalid header encoding: {e}") from e

        # Split into lines
        lines = header_text.rstrip("\n").split("\n")
        if not lines:
            raise InvalidFileError("Empty header")

        # Validate version line
        if lines[0] != AGE_HEADER_LINE_STR:
            raise InvalidFileError(f"Invalid age header: expected '{AGE_HEADER_LINE_STR}'")

        # Parse stanzas and MAC
        stanzas: list[Stanza] = []
        mac = b""
        line_idx = 1

        while line_idx < len(lines):
            line = lines[line_idx]

            if line.startswith(STANZA_PREFIX):
                # Parse stanza
                stanza, consumed = Stanza.parse(lines[line_idx:])
                stanzas.append(stanza)
                line_idx += consumed

            elif line.startswith(MAC_PREFIX):
                # Parse MAC (last line) - age uses base64 without padding
                mac_match = MAC_LINE_PATTERN.match(line)
                if not mac_match:
                    raise InvalidFileError(f"Invalid MAC line: {line}")

                try:
                    mac = age_b64decode(mac_match.group(1))
                except Exception as e:
                    raise InvalidFileError(f"Invalid MAC base64: {e}") from e

                line_idx += 1
                break

            else:
                raise InvalidFileError(f"Unexpected line in header: {line}")

        if not stanzas:
            raise InvalidFileError("No recipient stanzas in header")

        if len(stanzas) > MAX_RECIPIENTS:
            raise InvalidFileError(f"Too many recipients: {len(stanzas)}")

        if not mac:
            raise InvalidFileError("Missing header MAC")

        return cls(stanzas=stanzas, mac=mac), payload_offset

    def verify_mac(self, file_key: bytes) -> bool:
        """
        Verify the header MAC.

        Args:
            file_key: 16-byte file key.

        Returns:
            True if MAC is valid.
        """
        # Reconstruct header without MAC value
        lines: list[str] = [AGE_HEADER_LINE_STR]
        for stanza in self.stanzas:
            lines.append(stanza.serialize())

        # age MACs the header INCLUDING "---" marker but NOT the MAC value
        header_bytes = ("\n".join(lines) + "\n" + MAC_PREFIX).encode("utf-8")
        expected_mac = _compute_header_mac(header_bytes, file_key)

        return secure_compare(self.mac, expected_mac)

    def get_typed_stanza(self, stanza: Stanza) -> Stanza:
        """
        Convert generic stanza to typed stanza based on type.

        Args:
            stanza: Generic Stanza object.

        Returns:
            Typed stanza (X25519Stanza, ScryptStanza, etc.).
        """
        type_map = {
            StanzaType.X25519.value: X25519Stanza.from_stanza,
            StanzaType.SCRYPT.value: ScryptStanza.from_stanza,
            StanzaType.SSH_ED25519.value: SshEd25519Stanza.from_stanza,
            StanzaType.MLKEM_X25519.value: MlkemX25519Stanza.from_stanza,
        }

        converter = type_map.get(stanza.stanza_type)
        if converter:
            return converter(stanza)
        return stanza


# =============================================================================
# Helper Functions
# =============================================================================


def _compute_header_mac(header_bytes: bytes, file_key: bytes) -> bytes:
    """
    Compute header MAC using HKDF + HMAC-SHA256.

    age uses HKDF to derive a MAC key from the file key,
    then HMAC-SHA256 over the header (excluding MAC line).

    Args:
        header_bytes: Header bytes (version + stanzas, no MAC line).
        file_key: 16-byte file key.

    Returns:
        32-byte MAC.
    """
    mac_key_buf: bytearray | None = None
    try:
        # age uses HKDF-SHA256 with info="header" (empty salt)
        mac_key_buf = hkdf_sha256(file_key, b"", b"header", 32)

        # HMAC-SHA256 over header
        return hmac.new(bytes(mac_key_buf), header_bytes, hashlib.sha256).digest()
    finally:
        # Wipe MAC key
        if mac_key_buf is not None:
            secure_wipe(mac_key_buf)


def derive_file_key_wrapping_key(shared_secret: bytes, ephemeral_pk: bytes) -> bytearray:
    """
    Derive file key wrapping key from shared secret (age-compatible).

    Args:
        shared_secret: Shared secret from X25519/KEM.
        ephemeral_pk: Ephemeral public key (for domain separation).

    Returns:
        32-byte wrapping key as bytearray (caller must wipe after use).

    Security:
        The returned bytearray MUST be wiped by the caller after use.
    """
    # age uses HKDF with info containing the ephemeral public key
    return hkdf_sha256(shared_secret, b"", ephemeral_pk, 32)


def wrap_file_key(file_key: bytes, wrapping_key: bytes) -> bytes:
    """
    Wrap file key with ChaCha20-Poly1305 (age-compatible).

    Args:
        file_key: 16-byte file key to wrap.
        wrapping_key: 32-byte wrapping key.

    Returns:
        Wrapped file key (ciphertext + tag, 32 bytes).
    """
    from nacl.bindings import crypto_aead_chacha20poly1305_ietf_encrypt

    # age uses all-zero nonce for key wrapping
    nonce = b"\x00" * 12
    return crypto_aead_chacha20poly1305_ietf_encrypt(file_key, b"", nonce, wrapping_key)


def unwrap_file_key(wrapped_key: bytes, wrapping_key: bytes) -> bytes:
    """
    Unwrap file key with ChaCha20-Poly1305 (age-compatible).

    Args:
        wrapped_key: Wrapped file key (ciphertext + tag, 32 bytes).
        wrapping_key: 32-byte wrapping key.

    Returns:
        16-byte file key.

    Raises:
        DecryptionError: If unwrapping fails.
    """
    from nacl.bindings import crypto_aead_chacha20poly1305_ietf_decrypt

    from pqage.exceptions import DecryptionError

    # age uses all-zero nonce
    nonce = b"\x00" * 12

    try:
        result = crypto_aead_chacha20poly1305_ietf_decrypt(wrapped_key, b"", nonce, wrapping_key)
        if result is None:
            raise DecryptionError("File key unwrap failed: MAC verification failed")
        return result
    except Exception as e:
        raise DecryptionError(f"File key unwrap failed: {e}") from e


# =============================================================================
# Convenience Functions
# =============================================================================


def is_age_file(data: bytes) -> bool:
    """
    Check if data starts with age header.

    Args:
        data: File data to check.

    Returns:
        True if data appears to be an age file.
    """
    return data.startswith(AGE_HEADER_LINE + b"\n")


def parse_age_file(data: bytes) -> tuple[AgeHeader, bytes]:
    """
    Parse complete age file into header and payload.

    Args:
        data: Complete file data.

    Returns:
        Tuple of (header, payload_bytes).

    Raises:
        InvalidFileError: If file format is invalid.
    """
    header, offset = AgeHeader.parse(data)
    payload = data[offset:]
    return header, payload
