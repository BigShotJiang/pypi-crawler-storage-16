"""
Constants for pq-age encryption system.

All magic numbers are defined here as named constants for security auditability.
"""

# ==============================================================================
# Header Format Constants
# ==============================================================================

# Magic identifier
HEADER_MAGIC: bytes = b"PQAGE"
HEADER_MAGIC_LEN: int = 5

# Format version
FORMAT_VERSION_MAJOR: int = 0
FORMAT_VERSION_MINOR: int = 1

# Header flags
HEADER_FLAG_HAS_AAD: int = 0x01
HEADER_FLAG_MULTI_RECIPIENT: int = 0x02  # Reserved
HEADER_FLAG_STREAMING: int = 0x04  # Reserved

# Fixed header size (without variable parts)
FIXED_HEADER_LEN: int = 16

# Limits
MAX_RECIPIENTS: int = 65535
MAX_AAD_LEN: int = 65535

# ==============================================================================
# Key Exchange Constants
# ==============================================================================

X25519_SCALAR_LEN: int = 32
X25519_PUBLIC_KEY_LEN: int = 32

# X25519 Scalar Clamping (RFC 7748 Section 5)
# These constants define the bit manipulation for proper X25519 scalar clamping:
# - Clear bits 0-2 of first byte (ensures scalar is divisible by 8)
# - Clear bit 7 of last byte (ensures scalar < 2^255)
# - Set bit 6 of last byte (ensures scalar >= 2^254)
X25519_CLAMP_FIRST_BYTE: int = 0xF8  # AND mask: clears bits 0-2 (248 = 11111000)
X25519_CLAMP_LAST_BYTE_AND: int = 0x7F  # AND mask: clears bit 7 (127 = 01111111)
X25519_CLAMP_LAST_BYTE_OR: int = 0x40  # OR mask: sets bit 6 (64 = 01000000)

KYBER_NAME: str = "ML-KEM-1024"
KYBER_CIPHERTEXT_LEN: int = 1568
KYBER_PUBLIC_KEY_LEN: int = 1568
KYBER_SECRET_KEY_LEN: int = 3168
KYBER_SEED_LEN: int = 64

# Combined public key: X25519 PK + Kyber PK
COMBINED_PUBLIC_KEY_LEN: int = X25519_PUBLIC_KEY_LEN + KYBER_PUBLIC_KEY_LEN  # 1600

# ==============================================================================
# Symmetric Encryption Constants
# ==============================================================================

XCHACHA20_NONCE_LEN: int = 24
XCHACHA20_KEY_LEN: int = 32
POLY1305_TAG_LEN: int = 16

# ==============================================================================
# Password Wrapping Constants (Argon2id)
# ==============================================================================

ARGON2_SALT_LEN: int = 16
# SENSITIVE level for 2025+ security requirements
# Higher values provide better resistance against GPU/ASIC attacks
ARGON2_OPSLIMIT: int = 4  # SENSITIVE
ARGON2_MEMLIMIT: int = 256 * 1024 * 1024  # 256 MiB SENSITIVE

WRAPPED_KEY_PREFIX: bytes = b"PQAGEKEYv1"
WRAPPED_KEY_PREFIX_LEN: int = 10

# Raw (unprotected) key file prefix
RAW_KEY_PREFIX: bytes = b"PQAGERAWv1"
RAW_KEY_PREFIX_LEN: int = 10

# ==============================================================================
# Key Derivation Context Strings
# ==============================================================================

KDF_CONTEXT_MASTER: bytes = b"pq-age master v0.1.0"
KDF_CONTEXT_X25519: bytes = b"X25519 scalar"
KDF_CONTEXT_KYBER: bytes = b"ML-KEM-1024 seed"
KDF_CONTEXT_SYMKEY: bytes = b"symmetric file key"
KDF_CONTEXT_PREFIX: bytes = b"pq-age v0.1.0 "

# ==============================================================================
# File Extension
# ==============================================================================

ENCRYPTED_FILE_EXTENSION: str = ".pqage"

# ==============================================================================
# Hybrid ML-KEM-X25519 Protocol Constants (v1)
# ==============================================================================

# Protocol identification for transcript binding
PQAGE_PROTOCOL_ID: bytes = b"pqage"
PQAGE_PROTOCOL_VERSION: int = 1

# Stanza type identifier (versioniert fuer zukuenftige Upgrades)
MLKEM_X25519_STANZA_TYPE: str = "mlkem1024-x25519-v1"
MLKEM_X25519_STANZA_LABEL: bytes = b"mlkem1024-x25519"

# Key fingerprint: SHA256(mlkem_pk || x25519_pk)[:4]
HYBRID_FINGERPRINT_LEN: int = 4
