"""
Cryptographic primitives for pq-age.

This module exposes the core cryptographic functions:
- Key generation (X25519 + ML-KEM-1024)
- Hybrid KEM (encapsulation/decapsulation)
- age-compatible recipients (X25519, ssh-ed25519, scrypt, mlkem-x25519)
- age STREAM cipher for payload encryption
- SSH key parsing and Ed25519->X25519 conversion
- Security utilities (constant-time compare, secure wipe)
"""

# Key generation - must come first to avoid circular imports
from pqage.crypto.keys import SecureKeyBundle, derive_key, generate_keys  # noqa: I001

# KDF
from pqage.crypto.kdf import hkdf_sha256

# age-compatible recipients
from pqage.crypto.age_recipients import (
    mlkem_x25519_decapsulate,
    mlkem_x25519_encapsulate,
    scrypt_decapsulate,
    scrypt_encapsulate,
    ssh_ed25519_decapsulate,
    ssh_ed25519_encapsulate,
    x25519_decapsulate,
    x25519_encapsulate,
)

# age STREAM cipher
from pqage.crypto.age_stream import (
    stream_decrypt,
    stream_decrypt_bytes,
    stream_encrypt,
    stream_encrypt_bytes,
)

# Password wrapping (Argon2id)
from pqage.crypto.password import unwrap_keys, wrap_keys

# SSH key support
from pqage.crypto.ssh import (
    SshEd25519PrivateKey,
    SshEd25519PublicKey,
    ed25519_to_x25519_public,
    ed25519_to_x25519_secret,
    parse_ssh_private_key,
    parse_ssh_private_key_file,
    parse_ssh_public_key,
    parse_ssh_public_key_file,
)

# Symmetric encryption (XChaCha20-Poly1305)
from pqage.crypto.symmetric import decrypt, encrypt

# Security utilities
from pqage.crypto.utils import (
    SecureBytes,
    secure_compare,
    secure_starts_with,
    secure_wipe,
    secure_wipe_multiple,
)

# X25519 helpers
from pqage.crypto.x25519 import clamp_scalar, generate_ephemeral

__all__ = [
    # Key generation
    "generate_keys",
    "derive_key",
    "SecureKeyBundle",
    # KDF
    "hkdf_sha256",
    # X25519 helpers
    "clamp_scalar",
    "generate_ephemeral",
    # age-compatible recipients
    "x25519_encapsulate",
    "x25519_decapsulate",
    "ssh_ed25519_encapsulate",
    "ssh_ed25519_decapsulate",
    "scrypt_encapsulate",
    "scrypt_decapsulate",
    "mlkem_x25519_encapsulate",
    "mlkem_x25519_decapsulate",
    # age STREAM cipher
    "stream_encrypt",
    "stream_decrypt",
    "stream_encrypt_bytes",
    "stream_decrypt_bytes",
    # SSH key support
    "SshEd25519PublicKey",
    "SshEd25519PrivateKey",
    "parse_ssh_public_key",
    "parse_ssh_public_key_file",
    "parse_ssh_private_key",
    "parse_ssh_private_key_file",
    "ed25519_to_x25519_public",
    "ed25519_to_x25519_secret",
    # Symmetric encryption
    "encrypt",
    "decrypt",
    # Password wrapping
    "wrap_keys",
    "unwrap_keys",
    # Security utilities
    "secure_compare",
    "secure_starts_with",
    "secure_wipe",
    "secure_wipe_multiple",
    "SecureBytes",
]
