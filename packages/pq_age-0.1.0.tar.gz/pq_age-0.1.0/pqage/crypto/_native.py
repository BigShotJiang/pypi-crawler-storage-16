"""
Native extension wrapper with fallback to pure Python.

Provides a unified interface for secure memory operations, using the
Rust native extension when available, falling back to Python implementations
when the native extension is not installed.

Security Note:
    The native extension provides stronger guarantees:
    - mlock() prevents memory from being swapped to disk
    - zeroize provides compiler-resistant memory wiping

    The Python fallback is best-effort and cannot guarantee these properties.
"""

import logging
from typing import Protocol, runtime_checkable

logger = logging.getLogger(__name__)

# =============================================================================
# Try to import native extension
# =============================================================================

NATIVE_AVAILABLE: bool = False
MLOCK_AVAILABLE: bool = False

try:
    from pqage_native import (
        SecureBuffer as NativeSecureBuffer,
    )
    from pqage_native import (
        check_mlock_available,
        is_available,
        secure_wipe_native,
    )
    from pqage_native import (
        constant_time_compare as native_constant_time_compare,
    )

    NATIVE_AVAILABLE = is_available()

    if NATIVE_AVAILABLE:
        MLOCK_AVAILABLE = check_mlock_available()
        if not MLOCK_AVAILABLE:
            logger.warning(
                "mlock() not available - secrets may be swapped to disk. "
                "Consider running with elevated privileges or increasing RLIMIT_MEMLOCK."
            )

except ImportError:
    logger.warning(
        "⚠️  SECURITY WARNING: Native extension not available. "
        "Secure memory wiping and mlock() protection disabled. "
        "For production use, install: pip install pqage[native]"
    )


# =============================================================================
# Protocol for SecureBuffer interface
# =============================================================================


@runtime_checkable
class SecureBufferProtocol(Protocol):
    """Protocol defining the SecureBuffer interface."""

    @property
    def size(self) -> int:
        """Size of the buffer in bytes."""
        ...

    @property
    def is_memory_locked(self) -> bool:
        """Whether memory is locked (mlock succeeded)."""
        ...

    @property
    def is_wiped(self) -> bool:
        """Whether the buffer has been wiped."""
        ...

    def to_bytes(self) -> bytes:
        """Get buffer contents as bytes."""
        ...

    def wipe_now(self) -> None:
        """Manually wipe the buffer."""
        ...

    def write_at(self, offset: int, data: bytes) -> None:
        """Write data at offset."""
        ...

    def read_at(self, offset: int, length: int) -> bytes:
        """Read data from offset."""
        ...


# =============================================================================
# Python Fallback SecureBuffer
# =============================================================================


class PythonSecureBuffer:
    """
    Pure Python fallback SecureBuffer.

    WARNING: This implementation cannot guarantee:
    - Memory will not be swapped to disk
    - Memory is actually zeroed (Python GC may keep copies)

    Use native extension for production security requirements.
    """

    def __init__(self, size: int) -> None:
        """
        Initialize a secure buffer.

        Args:
            size: Size in bytes.
        """
        if size <= 0:
            raise MemoryError("Cannot allocate zero or negative size buffer")

        self._data = bytearray(size)
        self._wiped = False

    @classmethod
    def from_bytes(cls, data: bytes) -> "PythonSecureBuffer":
        """Create buffer from existing bytes."""
        buf = cls(len(data))
        buf._data[:] = data
        return buf

    @property
    def size(self) -> int:
        """Size of the buffer in bytes."""
        return len(self._data)

    @property
    def is_memory_locked(self) -> bool:
        """Memory is never locked in Python fallback."""
        return False

    @property
    def is_wiped(self) -> bool:
        """Whether the buffer has been wiped."""
        return self._wiped

    def to_bytes(self) -> bytes:
        """Get buffer contents as bytes."""
        if self._wiped:
            raise MemoryError("Buffer has been wiped")
        return bytes(self._data)

    def wipe_now(self) -> None:
        """Wipe the buffer contents."""
        if not self._wiped:
            for i in range(len(self._data)):
                self._data[i] = 0
            for i in range(len(self._data)):
                self._data[i] = 0xFF
            for i in range(len(self._data)):
                self._data[i] = 0
            self._wiped = True

    def write_at(self, offset: int, data: bytes) -> None:
        """Write data at offset."""
        if self._wiped:
            raise MemoryError("Buffer has been wiped")
        if offset + len(data) > len(self._data):
            raise MemoryError("Write would overflow buffer")
        self._data[offset : offset + len(data)] = data

    def read_at(self, offset: int, length: int) -> bytes:
        """Read data from offset."""
        if self._wiped:
            raise MemoryError("Buffer has been wiped")
        if offset + length > len(self._data):
            raise MemoryError("Read would overflow buffer")
        return bytes(self._data[offset : offset + length])

    def __len__(self) -> int:
        return len(self._data)

    def __repr__(self) -> str:
        return f"PythonSecureBuffer(size={len(self._data)}, locked=False, wiped={self._wiped})"

    def __del__(self) -> None:
        """Wipe on garbage collection."""
        if hasattr(self, "_wiped"):
            self.wipe_now()


# =============================================================================
# Unified API
# =============================================================================


# Select the best available implementation
if NATIVE_AVAILABLE:
    SecureBuffer = NativeSecureBuffer
else:
    SecureBuffer = PythonSecureBuffer  # type: ignore[misc, assignment]


def get_secure_buffer(size: int) -> SecureBufferProtocol | bytearray:
    """
    Get a secure buffer of the specified size.

    Returns native SecureBuffer if available, otherwise Python fallback.

    Args:
        size: Size in bytes.

    Returns:
        SecureBuffer instance.
    """
    if NATIVE_AVAILABLE:
        return NativeSecureBuffer(size)
    return PythonSecureBuffer(size)


def secure_wipe_buffer(data: bytearray | memoryview) -> None:
    """
    Securely wipe a buffer.

    Uses native extension if available for guaranteed wiping.

    Args:
        data: Mutable buffer to wipe.
    """
    if NATIVE_AVAILABLE and isinstance(data, bytearray):
        secure_wipe_native(data)
    else:
        for i in range(len(data)):
            data[i] = 0
        for i in range(len(data)):
            data[i] = 0xFF
        for i in range(len(data)):
            data[i] = 0


def constant_time_compare(a: bytes, b: bytes) -> bool:
    """
    Constant-time comparison of two byte sequences.

    Uses native extension if available.

    Args:
        a: First byte sequence.
        b: Second byte sequence.

    Returns:
        True if equal, False otherwise.
    """
    if NATIVE_AVAILABLE:
        return native_constant_time_compare(a, b)

    import hmac

    return hmac.compare_digest(a, b)


def is_native_available() -> bool:
    """Check if native extension is available."""
    return NATIVE_AVAILABLE


def is_mlock_available() -> bool:
    """Check if mlock() is available and working."""
    return MLOCK_AVAILABLE


__all__ = [
    "SecureBuffer",
    "PythonSecureBuffer",
    "SecureBufferProtocol",
    "get_secure_buffer",
    "secure_wipe_buffer",
    "constant_time_compare",
    "is_native_available",
    "is_mlock_available",
    "NATIVE_AVAILABLE",
    "MLOCK_AVAILABLE",
]
