"""
age recipient implementations for pq-age.

Implements all supported recipient types for encryption/decryption:
- X25519: Classical age recipient (ECDH key agreement)
- scrypt: Password-based recipient
- ssh-ed25519: SSH Ed25519 key recipient
- mlkem1024-x25519-v1: Hybrid post-quantum recipient (pq-age extension v1)

Each recipient type handles:
- Encapsulation: Wrap file key for recipient
- Decapsulation: Unwrap file key from stanza

Security:
- All shared secrets wiped after use
- HKDF for key derivation (age-compatible)
- ChaCha20-Poly1305 for key wrapping
- Structured transcript binding for domain separation
- Key fingerprint for efficient recipient matching
"""

import hashlib
import logging
from os import urandom

import oqs
from nacl.bindings import (
    crypto_aead_chacha20poly1305_ietf_decrypt,
    crypto_aead_chacha20poly1305_ietf_encrypt,
    crypto_scalarmult,
)

from pqage.age_format import (
    MlkemX25519Stanza,
    ScryptStanza,
    SshEd25519Stanza,
    Stanza,
    X25519Stanza,
)
from pqage.constants import (
    HYBRID_FINGERPRINT_LEN,
    MLKEM_X25519_STANZA_LABEL,
    PQAGE_PROTOCOL_ID,
    PQAGE_PROTOCOL_VERSION,
)
from pqage.crypto.kdf import hkdf_sha256
from pqage.crypto.utils import secure_compare, secure_wipe
from pqage.crypto.x25519 import generate_ephemeral
from pqage.exceptions import DecryptionError, EncapsulationError, InvalidKeyError

logger = logging.getLogger(__name__)

# =============================================================================
# Constants
# =============================================================================

# X25519 constants
X25519_PUBLIC_KEY_LEN: int = 32
X25519_SECRET_KEY_LEN: int = 32

# ML-KEM-1024 constants
MLKEM_NAME: str = "ML-KEM-1024"
MLKEM_PUBLIC_KEY_LEN: int = 1568
MLKEM_SECRET_KEY_LEN: int = 3168
MLKEM_CIPHERTEXT_LEN: int = 1568
MLKEM_SHARED_SECRET_LEN: int = 32

# File key length (age spec: 16 random bytes)
FILE_KEY_LEN: int = 16

# X25519 constants (age-compatible)
X25519_LABEL: bytes = b"age-encryption.org/v1/X25519"

# SSH Ed25519 constants
SSH_ED25519_LABEL: bytes = b"age-encryption.org/v1/ssh-ed25519"
SSH_KEY_HASH_LEN: int = 4
# Minimum SSH key blob length: 4 (type len) + 11 (ssh-ed25519) + 4 (pk len) + 32 (pk)
SSH_KEY_BLOB_MIN_LEN: int = 51

# ChaCha20-Poly1305 zero nonce for key wrapping (age spec)
CHACHA_ZERO_NONCE: bytes = b"\x00" * 12

# Wrapped file key length (ciphertext + 16-byte poly1305 tag)
WRAPPED_FILE_KEY_LEN: int = FILE_KEY_LEN + 16  # 32 bytes


# =============================================================================
# Hybrid ML-KEM-X25519 Helper Functions
# =============================================================================


def compute_hybrid_fingerprint(mlkem_pk: bytes, x25519_pk: bytes) -> bytes:
    """
    Compute key fingerprint for hybrid ML-KEM-X25519 recipient.

    The fingerprint binds both public keys and is used for efficient
    recipient matching during decryption.

    Args:
        mlkem_pk: ML-KEM-1024 public key (1568 bytes).
        x25519_pk: X25519 public key (32 bytes).

    Returns:
        4-byte fingerprint: SHA256(mlkem_pk || x25519_pk)[:4]

    Raises:
        InvalidKeyError: If key lengths are invalid.
    """
    if len(mlkem_pk) != MLKEM_PUBLIC_KEY_LEN:
        raise InvalidKeyError(
            f"ML-KEM public key must be {MLKEM_PUBLIC_KEY_LEN} bytes, got {len(mlkem_pk)}"
        )
    if len(x25519_pk) != X25519_PUBLIC_KEY_LEN:
        raise InvalidKeyError(
            f"X25519 public key must be {X25519_PUBLIC_KEY_LEN} bytes, got {len(x25519_pk)}"
        )

    fingerprint = hashlib.sha256(mlkem_pk + x25519_pk).digest()[:HYBRID_FINGERPRINT_LEN]
    logger.debug(
        "compute_hybrid_fingerprint: fingerprint=%s",
        fingerprint.hex(),
    )
    return fingerprint


def build_transcript(
    mlkem_ct: bytes,
    x25519_eph: bytes,
    mlkem_pk: bytes,
    x25519_pk: bytes,
) -> bytes:
    """
    Build structured transcript for HKDF info parameter.

    The transcript provides domain separation and binds all public values
    to the derived key, preventing cross-protocol attacks.

    Format:
        protocol_id (5 bytes): b"pqage"
        version (1 byte): 0x01
        stanza_label (16 bytes): b"mlkem1024-x25519"
        len(mlkem_ct) (2 bytes big-endian) + mlkem_ct
        len(x25519_eph) (2 bytes big-endian) + x25519_eph
        len(mlkem_pk) (2 bytes big-endian) + mlkem_pk
        len(x25519_pk) (2 bytes big-endian) + x25519_pk

    Args:
        mlkem_ct: ML-KEM ciphertext (1568 bytes).
        x25519_eph: X25519 ephemeral public key (32 bytes).
        mlkem_pk: Recipient's ML-KEM public key (1568 bytes).
        x25519_pk: Recipient's X25519 public key (32 bytes).

    Returns:
        Structured transcript bytes for HKDF info.
    """
    transcript = (
        PQAGE_PROTOCOL_ID
        + bytes([PQAGE_PROTOCOL_VERSION])
        + MLKEM_X25519_STANZA_LABEL
        + len(mlkem_ct).to_bytes(2, "big")
        + mlkem_ct
        + len(x25519_eph).to_bytes(2, "big")
        + x25519_eph
        + len(mlkem_pk).to_bytes(2, "big")
        + mlkem_pk
        + len(x25519_pk).to_bytes(2, "big")
        + x25519_pk
    )
    logger.debug(
        "build_transcript: total_len=%d, protocol=%s, version=%d",
        len(transcript),
        PQAGE_PROTOCOL_ID.decode(),
        PQAGE_PROTOCOL_VERSION,
    )
    return transcript


# =============================================================================
# X25519 Recipient
# =============================================================================


def x25519_encapsulate(
    recipient_pk: bytes,
    file_key: bytes,
) -> X25519Stanza:
    """
    Create X25519 stanza to wrap file key for recipient.

    Args:
        recipient_pk: Recipient's X25519 public key (32 bytes).
        file_key: File key to wrap (16 bytes).

    Returns:
        X25519Stanza with wrapped file key.

    Raises:
        InvalidKeyError: If key lengths are invalid.
        EncapsulationError: If encapsulation fails.
    """
    logger.debug("x25519_encapsulate: Starting encapsulation")

    if len(recipient_pk) != X25519_PUBLIC_KEY_LEN:
        raise InvalidKeyError(f"X25519 public key must be {X25519_PUBLIC_KEY_LEN} bytes")
    if len(file_key) != FILE_KEY_LEN:
        raise InvalidKeyError(f"File key must be {FILE_KEY_LEN} bytes")

    eph_sk_buf: bytearray | None = None
    shared_secret_buf: bytearray | None = None
    wrapping_key_buf: bytearray | None = None

    try:
        # Generate ephemeral keypair with RFC 7748 clamping
        eph_pk, eph_sk_buf = generate_ephemeral()
        logger.debug("x25519_encapsulate: Ephemeral keypair generated")

        # Compute shared secret
        shared_secret = crypto_scalarmult(bytes(eph_sk_buf), recipient_pk)
        shared_secret_buf = bytearray(shared_secret)

        # Derive wrapping key using HKDF
        # age spec: salt=eph_pk||recipient_pk, label=X25519_LABEL
        salt = eph_pk + recipient_pk
        wrapping_key_buf = hkdf_sha256(shared_secret_buf, salt, X25519_LABEL, 32)

        # Wrap file key with ChaCha20-Poly1305 (zero nonce per age spec)
        wrapped_key = crypto_aead_chacha20poly1305_ietf_encrypt(
            file_key, b"", CHACHA_ZERO_NONCE, bytes(wrapping_key_buf)
        )

        logger.debug("x25519_encapsulate: Encapsulation complete")

        return X25519Stanza.create(
            ephemeral_share=eph_pk,
            body=wrapped_key,
        )

    except InvalidKeyError:
        raise
    except Exception as e:
        logger.error("x25519_encapsulate: Failed - %s", e)
        raise EncapsulationError(f"X25519 encapsulation failed: {e}") from e
    finally:
        if eph_sk_buf is not None:
            secure_wipe(eph_sk_buf)
        if shared_secret_buf is not None:
            secure_wipe(shared_secret_buf)
        if wrapping_key_buf is not None:
            secure_wipe(wrapping_key_buf)


def x25519_decapsulate(
    stanza: X25519Stanza,
    recipient_sk: bytes,
    recipient_pk: bytes,
) -> bytes:
    """
    Unwrap file key from X25519 stanza.

    Args:
        stanza: X25519Stanza containing wrapped file key.
        recipient_sk: Recipient's X25519 secret key (32 bytes).
        recipient_pk: Recipient's X25519 public key (32 bytes).

    Returns:
        Unwrapped file key (16 bytes).

    Raises:
        InvalidKeyError: If key lengths are invalid.
        DecryptionError: If decapsulation fails.
    """
    logger.debug("x25519_decapsulate: Starting decapsulation")

    if len(recipient_sk) != X25519_SECRET_KEY_LEN:
        raise InvalidKeyError(f"X25519 secret key must be {X25519_SECRET_KEY_LEN} bytes")
    if len(recipient_pk) != X25519_PUBLIC_KEY_LEN:
        raise InvalidKeyError(f"X25519 public key must be {X25519_PUBLIC_KEY_LEN} bytes")

    shared_secret_buf: bytearray | None = None
    wrapping_key_buf: bytearray | None = None

    try:
        eph_pk = stanza.ephemeral_share

        # Compute shared secret
        shared_secret = crypto_scalarmult(recipient_sk, eph_pk)
        shared_secret_buf = bytearray(shared_secret)

        # Derive wrapping key
        # age spec: salt=eph_pk||recipient_pk, label=X25519_LABEL
        salt = eph_pk + recipient_pk
        wrapping_key_buf = hkdf_sha256(shared_secret_buf, salt, X25519_LABEL, 32)

        # Unwrap file key with ChaCha20-Poly1305 (zero nonce per age spec)
        file_key = crypto_aead_chacha20poly1305_ietf_decrypt(
            stanza.body, b"", CHACHA_ZERO_NONCE, bytes(wrapping_key_buf)
        )

        if file_key is None:
            raise DecryptionError("File key unwrap failed: authentication failed")

        logger.debug("x25519_decapsulate: Decapsulation complete")
        return file_key

    except (InvalidKeyError, DecryptionError):
        raise
    except Exception as e:
        logger.error("x25519_decapsulate: Failed - %s", e)
        raise DecryptionError(f"X25519 decapsulation failed: {e}") from e
    finally:
        if shared_secret_buf is not None:
            secure_wipe(shared_secret_buf)
        if wrapping_key_buf is not None:
            secure_wipe(wrapping_key_buf)


# =============================================================================
# SSH Ed25519 Recipient
# =============================================================================


def _compute_ssh_ed25519_tweaked_secret(
    initial_shared_secret: bytes,
    ssh_key_blob: bytes,
) -> tuple[bytearray, bytearray]:
    """
    Compute tweaked shared secret for SSH Ed25519 (age compatibility).

    age uses a "tweak" derived from the SSH public key blob to modify
    the shared secret. This provides domain separation and prevents
    certain key-reuse attacks.

    Args:
        initial_shared_secret: X25519 shared secret (32 bytes).
        ssh_key_blob: SSH wire format of public key.

    Returns:
        Tuple of (tweaked_shared_secret, tweak) as bytearrays for secure wiping.

    Raises:
        InvalidKeyError: If inputs are invalid.
    """
    if len(initial_shared_secret) != X25519_PUBLIC_KEY_LEN:
        raise InvalidKeyError("Invalid shared secret length")
    if len(ssh_key_blob) < SSH_KEY_BLOB_MIN_LEN:
        raise InvalidKeyError(f"SSH key blob must be at least {SSH_KEY_BLOB_MIN_LEN} bytes")

    # Compute tweak: HKDF(ikm=empty, salt=ssh_key_blob, info=label)
    # This matches age's Go implementation exactly
    tweak_buf = hkdf_sha256(b"", ssh_key_blob, SSH_ED25519_LABEL, 32)

    # Apply tweak: tweaked_ss = X25519(tweak, shared_secret)
    # This is scalar multiplication on the shared secret point
    tweaked_ss = crypto_scalarmult(bytes(tweak_buf), initial_shared_secret)
    tweaked_ss_buf = bytearray(tweaked_ss)

    logger.debug("SSH Ed25519 tweak computed (blob_len=%d)", len(ssh_key_blob))

    return tweaked_ss_buf, tweak_buf


def ssh_ed25519_encapsulate(
    recipient_x25519_pk: bytes,
    recipient_key_hash: bytes,
    ssh_key_blob: bytes,
    file_key: bytes,
) -> SshEd25519Stanza:
    """
    Create ssh-ed25519 stanza to wrap file key.

    The recipient's Ed25519 public key must be converted to X25519 first.
    This implementation uses the age tweak method for compatibility with
    age/rage CLI tools.

    Args:
        recipient_x25519_pk: Recipient's X25519 public key (converted from Ed25519).
        recipient_key_hash: SSH key hash (4 bytes, for matching).
        ssh_key_blob: SSH wire format of recipient's public key (for tweak).
        file_key: File key to wrap (16 bytes).

    Returns:
        SshEd25519Stanza with wrapped file key.

    Raises:
        InvalidKeyError: If key lengths are invalid.
        EncapsulationError: If encapsulation fails.
    """
    logger.debug("ssh_ed25519_encapsulate: Starting encapsulation")

    # Input validation
    if len(recipient_x25519_pk) != X25519_PUBLIC_KEY_LEN:
        raise InvalidKeyError(f"X25519 public key must be {X25519_PUBLIC_KEY_LEN} bytes")
    if len(recipient_key_hash) != SSH_KEY_HASH_LEN:
        raise InvalidKeyError(f"SSH key hash must be {SSH_KEY_HASH_LEN} bytes")
    if len(ssh_key_blob) < SSH_KEY_BLOB_MIN_LEN:
        raise InvalidKeyError(f"SSH key blob must be at least {SSH_KEY_BLOB_MIN_LEN} bytes")
    if len(file_key) != FILE_KEY_LEN:
        raise InvalidKeyError(f"File key must be {FILE_KEY_LEN} bytes")

    eph_sk_buf: bytearray | None = None
    shared_secret_buf: bytearray | None = None
    tweak_buf: bytearray | None = None
    tweaked_ss_buf: bytearray | None = None
    wrapping_key_buf: bytearray | None = None

    try:
        # Generate ephemeral X25519 keypair with RFC 7748 clamping
        eph_pk, eph_sk_buf = generate_ephemeral()
        logger.debug("ssh_ed25519_encapsulate: Ephemeral keypair generated")

        # Compute initial shared secret
        initial_shared_secret = crypto_scalarmult(bytes(eph_sk_buf), recipient_x25519_pk)
        shared_secret_buf = bytearray(initial_shared_secret)

        # Apply age-compatible SSH tweak
        tweaked_ss_buf, tweak_buf = _compute_ssh_ed25519_tweaked_secret(
            initial_shared_secret, ssh_key_blob
        )

        # Derive wrapping key: HKDF(ikm=tweaked_ss, salt=eph_pk||pk, info=label)
        salt = eph_pk + recipient_x25519_pk
        wrapping_key_buf = hkdf_sha256(tweaked_ss_buf, salt, SSH_ED25519_LABEL, 32)

        # Wrap file key with ChaCha20-Poly1305
        nonce = CHACHA_ZERO_NONCE
        wrapped_key = crypto_aead_chacha20poly1305_ietf_encrypt(
            file_key, b"", nonce, bytes(wrapping_key_buf)
        )

        logger.debug("ssh_ed25519_encapsulate: Encapsulation complete")

        return SshEd25519Stanza.create(
            key_hash=recipient_key_hash,
            ephemeral_share=eph_pk,
            body=wrapped_key,
        )

    except InvalidKeyError:
        raise
    except Exception as e:
        logger.error("ssh_ed25519_encapsulate: Failed - %s", e)
        raise EncapsulationError(f"ssh-ed25519 encapsulation failed: {e}") from e
    finally:
        if eph_sk_buf is not None:
            secure_wipe(eph_sk_buf)
        if shared_secret_buf is not None:
            secure_wipe(shared_secret_buf)
        if tweak_buf is not None:
            secure_wipe(tweak_buf)
        if tweaked_ss_buf is not None:
            secure_wipe(tweaked_ss_buf)
        if wrapping_key_buf is not None:
            secure_wipe(wrapping_key_buf)


def ssh_ed25519_decapsulate(
    stanza: SshEd25519Stanza,
    recipient_x25519_sk: bytes,
    recipient_x25519_pk: bytes,
    recipient_key_hash: bytes,
    ssh_key_blob: bytes,
) -> bytes:
    """
    Unwrap file key from ssh-ed25519 stanza.

    This implementation uses the age tweak method for compatibility with
    age/rage CLI tools.

    Args:
        stanza: SshEd25519Stanza containing wrapped file key.
        recipient_x25519_sk: Recipient's X25519 secret key (from Ed25519).
        recipient_x25519_pk: Recipient's X25519 public key (from Ed25519).
        recipient_key_hash: Expected key hash for matching.
        ssh_key_blob: SSH wire format of recipient's public key (for tweak).

    Returns:
        Unwrapped file key (16 bytes).

    Raises:
        InvalidKeyError: If key hash doesn't match or inputs invalid.
        DecryptionError: If decapsulation fails.
    """
    from pqage.crypto.utils import secure_compare

    logger.debug("ssh_ed25519_decapsulate: Starting decapsulation")

    # Input validation
    if len(recipient_x25519_sk) != X25519_SECRET_KEY_LEN:
        raise InvalidKeyError(f"X25519 secret key must be {X25519_SECRET_KEY_LEN} bytes")
    if len(recipient_x25519_pk) != X25519_PUBLIC_KEY_LEN:
        raise InvalidKeyError(f"X25519 public key must be {X25519_PUBLIC_KEY_LEN} bytes")
    if len(ssh_key_blob) < SSH_KEY_BLOB_MIN_LEN:
        raise InvalidKeyError(f"SSH key blob must be at least {SSH_KEY_BLOB_MIN_LEN} bytes")

    # Check key hash matches (constant-time comparison)
    if not secure_compare(stanza.key_hash, recipient_key_hash):
        logger.debug("ssh_ed25519_decapsulate: Key hash mismatch")
        raise InvalidKeyError("SSH key hash does not match")

    shared_secret_buf: bytearray | None = None
    tweak_buf: bytearray | None = None
    tweaked_ss_buf: bytearray | None = None
    wrapping_key_buf: bytearray | None = None

    try:
        eph_pk = stanza.ephemeral_share

        # Compute initial shared secret
        initial_shared_secret = crypto_scalarmult(recipient_x25519_sk, eph_pk)
        shared_secret_buf = bytearray(initial_shared_secret)

        # Apply age-compatible SSH tweak
        tweaked_ss_buf, tweak_buf = _compute_ssh_ed25519_tweaked_secret(
            initial_shared_secret, ssh_key_blob
        )

        # Derive wrapping key: HKDF(ikm=tweaked_ss, salt=eph_pk||pk, info=label)
        salt = eph_pk + recipient_x25519_pk
        wrapping_key_buf = hkdf_sha256(tweaked_ss_buf, salt, SSH_ED25519_LABEL, 32)

        # Unwrap file key with ChaCha20-Poly1305
        nonce = CHACHA_ZERO_NONCE
        file_key = crypto_aead_chacha20poly1305_ietf_decrypt(
            stanza.body, b"", nonce, bytes(wrapping_key_buf)
        )

        if file_key is None:
            raise DecryptionError("File key unwrap failed: authentication failed")

        logger.debug("ssh_ed25519_decapsulate: Decapsulation complete")
        return file_key

    except (InvalidKeyError, DecryptionError):
        raise
    except Exception as e:
        logger.error("ssh_ed25519_decapsulate: Failed - %s", e)
        raise DecryptionError(f"ssh-ed25519 decapsulation failed: {e}") from e
    finally:
        if shared_secret_buf is not None:
            secure_wipe(shared_secret_buf)
        if tweak_buf is not None:
            secure_wipe(tweak_buf)
        if tweaked_ss_buf is not None:
            secure_wipe(tweaked_ss_buf)
        if wrapping_key_buf is not None:
            secure_wipe(wrapping_key_buf)


# =============================================================================
# Hybrid ML-KEM-1024 + X25519 Recipient (pq-age extension)
# =============================================================================


def mlkem_x25519_encapsulate(
    recipient_mlkem_pk: bytes,
    recipient_x25519_pk: bytes,
    file_key: bytes,
) -> MlkemX25519Stanza:
    """
    Create hybrid mlkem1024-x25519-v1 stanza to wrap file key.

    This provides post-quantum security through hybrid encryption:
    - ML-KEM-1024 provides quantum resistance
    - X25519 provides classical security (defense in depth)
    - Both shared secrets combined via HKDF with structured transcript
    - Key fingerprint for efficient recipient matching

    Args:
        recipient_mlkem_pk: Recipient's ML-KEM-1024 public key (1568 bytes).
        recipient_x25519_pk: Recipient's X25519 public key (32 bytes).
        file_key: File key to wrap (16 bytes).

    Returns:
        MlkemX25519Stanza with wrapped file key and fingerprint.

    Raises:
        InvalidKeyError: If key lengths are invalid.
        EncapsulationError: If encapsulation fails.
    """
    if len(recipient_mlkem_pk) != MLKEM_PUBLIC_KEY_LEN:
        raise InvalidKeyError(f"ML-KEM public key must be {MLKEM_PUBLIC_KEY_LEN} bytes")
    if len(recipient_x25519_pk) != X25519_PUBLIC_KEY_LEN:
        raise InvalidKeyError(f"X25519 public key must be {X25519_PUBLIC_KEY_LEN} bytes")
    if len(file_key) != FILE_KEY_LEN:
        raise InvalidKeyError(f"File key must be {FILE_KEY_LEN} bytes")

    logger.debug("mlkem_x25519_encapsulate: Starting encapsulation")

    # Compute key fingerprint for recipient matching
    fingerprint = compute_hybrid_fingerprint(recipient_mlkem_pk, recipient_x25519_pk)

    # Buffers for secure cleanup
    mlkem_ss_buf: bytearray | None = None
    x25519_ss_buf: bytearray | None = None
    eph_sk_buf: bytearray | None = None
    combined_secret_buf: bytearray | None = None
    wrapping_key_buf: bytearray | None = None

    kem = oqs.KeyEncapsulation(MLKEM_NAME)

    try:
        # ML-KEM encapsulation
        mlkem_ct, mlkem_ss = kem.encap_secret(recipient_mlkem_pk)
        mlkem_ss_buf = bytearray(mlkem_ss)

        # X25519 ephemeral key generation with RFC 7748 clamping
        x25519_eph_pk, eph_sk_buf = generate_ephemeral()

        # X25519 shared secret
        x25519_ss = crypto_scalarmult(bytes(eph_sk_buf), recipient_x25519_pk)
        x25519_ss_buf = bytearray(x25519_ss)

        # Build structured transcript for domain separation
        transcript = build_transcript(
            mlkem_ct, x25519_eph_pk, recipient_mlkem_pk, recipient_x25519_pk
        )

        # Combine shared secrets: HKDF(mlkem_ss || x25519_ss, info=transcript)
        ss_len = len(mlkem_ss_buf)  # 32 bytes
        combined_secret_buf = bytearray(ss_len * 2)
        combined_secret_buf[0:ss_len] = mlkem_ss_buf
        combined_secret_buf[ss_len : ss_len * 2] = x25519_ss_buf

        # Derive wrapping key
        wrapping_key_buf = hkdf_sha256(
            combined_secret_buf,
            b"",  # No salt
            transcript,  # Structured info with protocol binding
            32,
        )

        # Wrap file key
        nonce = CHACHA_ZERO_NONCE
        wrapped_key = crypto_aead_chacha20poly1305_ietf_encrypt(
            file_key, b"", nonce, bytes(wrapping_key_buf)
        )

        logger.debug("mlkem_x25519_encapsulate: Encapsulation complete")

        return MlkemX25519Stanza.create(
            key_fingerprint=fingerprint,
            mlkem_ciphertext=mlkem_ct,
            x25519_ephemeral=x25519_eph_pk,
            body=wrapped_key,
        )

    except InvalidKeyError:
        raise
    except Exception as e:
        logger.error("mlkem_x25519_encapsulate: Failed - %s", e)
        raise EncapsulationError(f"mlkem1024-x25519-v1 encapsulation failed: {e}") from e
    finally:
        # Secure cleanup
        if mlkem_ss_buf is not None:
            secure_wipe(mlkem_ss_buf)
        if x25519_ss_buf is not None:
            secure_wipe(x25519_ss_buf)
        if eph_sk_buf is not None:
            secure_wipe(eph_sk_buf)
        if combined_secret_buf is not None:
            secure_wipe(combined_secret_buf)
        if wrapping_key_buf is not None:
            secure_wipe(wrapping_key_buf)
        kem.free()


def mlkem_x25519_decapsulate(
    stanza: MlkemX25519Stanza,
    recipient_mlkem_sk: bytes,
    recipient_x25519_sk: bytes,
    recipient_mlkem_pk: bytes,
    recipient_x25519_pk: bytes,
) -> bytes:
    """
    Unwrap file key from hybrid mlkem1024-x25519-v1 stanza.

    Args:
        stanza: MlkemX25519Stanza containing wrapped file key.
        recipient_mlkem_sk: Recipient's ML-KEM-1024 secret key.
        recipient_x25519_sk: Recipient's X25519 secret key.
        recipient_mlkem_pk: Recipient's ML-KEM-1024 public key.
        recipient_x25519_pk: Recipient's X25519 public key.

    Returns:
        Unwrapped file key (16 bytes).

    Raises:
        InvalidKeyError: If key lengths are invalid or fingerprint mismatch.
        DecryptionError: If decapsulation fails.
    """
    if len(recipient_mlkem_sk) != MLKEM_SECRET_KEY_LEN:
        raise InvalidKeyError(f"ML-KEM secret key must be {MLKEM_SECRET_KEY_LEN} bytes")
    if len(recipient_x25519_sk) != X25519_SECRET_KEY_LEN:
        raise InvalidKeyError(f"X25519 secret key must be {X25519_SECRET_KEY_LEN} bytes")

    logger.debug("mlkem_x25519_decapsulate: Starting decapsulation")

    # Verify key fingerprint (constant-time comparison)
    expected_fingerprint = compute_hybrid_fingerprint(recipient_mlkem_pk, recipient_x25519_pk)
    if not secure_compare(stanza.key_fingerprint, expected_fingerprint):
        logger.debug("mlkem_x25519_decapsulate: Key fingerprint mismatch")
        raise InvalidKeyError("Key fingerprint does not match")

    # Buffers for secure cleanup
    mlkem_ss_buf: bytearray | None = None
    x25519_ss_buf: bytearray | None = None
    combined_secret_buf: bytearray | None = None
    wrapping_key_buf: bytearray | None = None

    kem = oqs.KeyEncapsulation(MLKEM_NAME, secret_key=recipient_mlkem_sk)

    try:
        mlkem_ct = stanza.mlkem_ciphertext
        x25519_eph_pk = stanza.x25519_ephemeral

        # ML-KEM decapsulation
        mlkem_ss = kem.decap_secret(mlkem_ct)
        mlkem_ss_buf = bytearray(mlkem_ss)

        # X25519 shared secret
        x25519_ss = crypto_scalarmult(recipient_x25519_sk, x25519_eph_pk)
        x25519_ss_buf = bytearray(x25519_ss)

        # Build structured transcript (must match encapsulation)
        transcript = build_transcript(
            mlkem_ct, x25519_eph_pk, recipient_mlkem_pk, recipient_x25519_pk
        )

        # Combine shared secrets
        ss_len = len(mlkem_ss_buf)  # 32 bytes
        combined_secret_buf = bytearray(ss_len * 2)
        combined_secret_buf[0:ss_len] = mlkem_ss_buf
        combined_secret_buf[ss_len : ss_len * 2] = x25519_ss_buf

        # Derive wrapping key
        wrapping_key_buf = hkdf_sha256(
            combined_secret_buf,
            b"",
            transcript,
            32,
        )

        # Unwrap file key
        nonce = CHACHA_ZERO_NONCE
        file_key = crypto_aead_chacha20poly1305_ietf_decrypt(
            stanza.body, b"", nonce, bytes(wrapping_key_buf)
        )

        if file_key is None:
            raise DecryptionError("File key unwrap failed: authentication failed")

        logger.debug("mlkem_x25519_decapsulate: Decapsulation complete")
        return file_key

    except (InvalidKeyError, DecryptionError):
        raise
    except Exception as e:
        logger.error("mlkem_x25519_decapsulate: Failed - %s", e)
        raise DecryptionError(f"mlkem1024-x25519-v1 decapsulation failed: {e}") from e
    finally:
        # Secure cleanup
        if mlkem_ss_buf is not None:
            secure_wipe(mlkem_ss_buf)
        if x25519_ss_buf is not None:
            secure_wipe(x25519_ss_buf)
        if combined_secret_buf is not None:
            secure_wipe(combined_secret_buf)
        if wrapping_key_buf is not None:
            secure_wipe(wrapping_key_buf)
        kem.free()


# =============================================================================
# scrypt Password Recipient
# =============================================================================

# scrypt parameters (age defaults)
SCRYPT_SALT_LEN: int = 16
SCRYPT_DEFAULT_LOG_N: int = 18  # N = 2^18 = 262144
SCRYPT_R: int = 8
SCRYPT_P: int = 1


def scrypt_encapsulate(
    password: str,
    file_key: bytes,
    log_n: int = SCRYPT_DEFAULT_LOG_N,
) -> ScryptStanza:
    """
    Create scrypt stanza to wrap file key with password.

    Uses scrypt key derivation with ChaCha20-Poly1305 wrapping.

    Args:
        password: Password string.
        file_key: File key to wrap (16 bytes).
        log_n: Work factor as log2(N). Default 18 (N=262144).

    Returns:
        ScryptStanza with wrapped file key.

    Raises:
        InvalidKeyError: If file key length is invalid.
        EncapsulationError: If encapsulation fails.
    """
    if len(file_key) != FILE_KEY_LEN:
        raise InvalidKeyError(f"File key must be {FILE_KEY_LEN} bytes")

    if log_n < 1 or log_n > 30:
        raise InvalidKeyError(f"Invalid scrypt log_n: {log_n} (must be 1-30)")

    wrapping_key_buf: bytearray | None = None

    try:
        # Generate random salt
        salt = urandom(SCRYPT_SALT_LEN)

        # Derive wrapping key using scrypt
        n = 1 << log_n  # N = 2^log_n

        try:
            import hashlib

            # Python 3.6+ has scrypt in hashlib
            wrapping_key = hashlib.scrypt(
                password.encode("utf-8"),
                salt=salt,
                n=n,
                r=SCRYPT_R,
                p=SCRYPT_P,
                dklen=32,
            )
        except (ImportError, AttributeError):
            # Fallback to cryptography library
            from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

            kdf = Scrypt(salt=salt, length=32, n=n, r=SCRYPT_R, p=SCRYPT_P)
            wrapping_key = kdf.derive(password.encode("utf-8"))

        wrapping_key_buf = bytearray(wrapping_key)

        # Wrap file key with ChaCha20-Poly1305 (zero nonce)
        nonce = CHACHA_ZERO_NONCE
        wrapped_key = crypto_aead_chacha20poly1305_ietf_encrypt(
            file_key, b"", nonce, bytes(wrapping_key_buf)
        )

        return ScryptStanza.create(
            salt=salt,
            log_n=log_n,
            body=wrapped_key,
        )

    except InvalidKeyError:
        raise
    except Exception as e:
        raise EncapsulationError(f"scrypt encapsulation failed: {e}") from e
    finally:
        if wrapping_key_buf is not None:
            secure_wipe(wrapping_key_buf)


def scrypt_decapsulate(
    stanza: ScryptStanza,
    password: str,
) -> bytes:
    """
    Unwrap file key from scrypt stanza using password.

    Args:
        stanza: ScryptStanza containing wrapped file key.
        password: Password string.

    Returns:
        Unwrapped file key (32 bytes).

    Raises:
        DecryptionError: If decapsulation fails (wrong password).
    """
    wrapping_key_buf: bytearray | None = None

    try:
        salt = stanza.salt
        log_n = stanza.log_n
        n = 1 << log_n

        # Derive wrapping key using scrypt
        try:
            import hashlib

            wrapping_key = hashlib.scrypt(
                password.encode("utf-8"),
                salt=salt,
                n=n,
                r=SCRYPT_R,
                p=SCRYPT_P,
                dklen=32,
            )
        except (ImportError, AttributeError):
            from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

            kdf = Scrypt(salt=salt, length=32, n=n, r=SCRYPT_R, p=SCRYPT_P)
            wrapping_key = kdf.derive(password.encode("utf-8"))

        wrapping_key_buf = bytearray(wrapping_key)

        # Unwrap file key
        nonce = CHACHA_ZERO_NONCE
        file_key = crypto_aead_chacha20poly1305_ietf_decrypt(
            stanza.body, b"", nonce, bytes(wrapping_key_buf)
        )

        if file_key is None:
            raise DecryptionError("Wrong password or corrupted data")

        return file_key

    except DecryptionError:
        raise
    except Exception as e:
        raise DecryptionError(f"scrypt decapsulation failed: {e}") from e
    finally:
        if wrapping_key_buf is not None:
            secure_wipe(wrapping_key_buf)


# =============================================================================
# Generic Stanza Handling
# =============================================================================


def try_decrypt_stanza(
    stanza: Stanza,
    x25519_sk: bytes | None = None,
    x25519_pk: bytes | None = None,
    mlkem_sk: bytes | None = None,
    mlkem_pk: bytes | None = None,
    ssh_key_hash: bytes | None = None,
    ssh_key_blob: bytes | None = None,
    password: str | None = None,
) -> bytes | None:
    """
    Try to decrypt file key from a stanza.

    Attempts decryption based on stanza type and provided keys.

    Args:
        stanza: Stanza to decrypt.
        x25519_sk: X25519 secret key (for X25519, ssh-ed25519, mlkem-x25519).
        x25519_pk: X25519 public key.
        mlkem_sk: ML-KEM-1024 secret key (for mlkem-x25519).
        mlkem_pk: ML-KEM-1024 public key.
        ssh_key_hash: SSH key hash (for ssh-ed25519).
        ssh_key_blob: SSH wire format of public key (for ssh-ed25519 tweak).
        password: Password (for scrypt).

    Returns:
        File key if decryption succeeds, None otherwise.
    """
    try:
        if stanza.stanza_type == "X25519":
            if x25519_sk is None or x25519_pk is None:
                return None
            typed_stanza = X25519Stanza.from_stanza(stanza)
            return x25519_decapsulate(typed_stanza, x25519_sk, x25519_pk)

        elif stanza.stanza_type == "ssh-ed25519":
            if (
                x25519_sk is None
                or x25519_pk is None
                or ssh_key_hash is None
                or ssh_key_blob is None
            ):
                return None
            typed_stanza = SshEd25519Stanza.from_stanza(stanza)
            # Check key hash first
            from pqage.crypto.utils import secure_compare

            if not secure_compare(typed_stanza.key_hash, ssh_key_hash):
                return None
            return ssh_ed25519_decapsulate(
                typed_stanza, x25519_sk, x25519_pk, ssh_key_hash, ssh_key_blob
            )

        elif stanza.stanza_type == "mlkem1024-x25519-v1":
            if x25519_sk is None or x25519_pk is None or mlkem_sk is None or mlkem_pk is None:
                return None
            typed_stanza = MlkemX25519Stanza.from_stanza(stanza)
            return mlkem_x25519_decapsulate(typed_stanza, mlkem_sk, x25519_sk, mlkem_pk, x25519_pk)

        elif stanza.stanza_type == "scrypt":
            if password is None:
                return None
            typed_stanza = ScryptStanza.from_stanza(stanza)
            return scrypt_decapsulate(typed_stanza, password)

        else:
            logger.debug("Unknown stanza type: %s", stanza.stanza_type)
            return None

    except Exception as e:
        logger.debug("Stanza decryption failed: %s", e)
        return None
