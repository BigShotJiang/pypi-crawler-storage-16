"""
age STREAM cipher implementation for pq-age.

Implements the STREAM construction used by age for payload encryption:
- ChaCha20-Poly1305 AEAD (IETF variant, 12-byte nonce)
- 64 KB chunks (65536 bytes plaintext per chunk)
- Counter-based nonce derivation with final chunk flag
- Authenticated encryption prevents truncation attacks

STREAM Nonce Construction (per age spec):
    nonce = counter (11 bytes, big-endian) || final_flag (1 byte)

    Where:
    - counter: 0, 1, 2, ... (11 bytes big-endian, increments per chunk)
    - final_flag: 0x00 for intermediate chunks, 0x01 for the last chunk

Note: The 16-byte nonce at the start of the payload is used ONLY for HKDF
to derive the payload_key, NOT as a nonce prefix for STREAM encryption.

This is age-compatible and interoperable with rage, age-go, etc.

Security:
    - Each chunk independently authenticated
    - Final chunk flag prevents truncation
    - Counter prevents reordering
    - Different nonce for each chunk prevents nonce reuse
"""

import logging
from collections.abc import Iterator
from typing import BinaryIO

from nacl.bindings import (
    crypto_aead_chacha20poly1305_ietf_decrypt,
    crypto_aead_chacha20poly1305_ietf_encrypt,
)

from pqage.exceptions import DecryptionError, EncryptionError

logger = logging.getLogger(__name__)

# =============================================================================
# Constants
# =============================================================================

# age STREAM chunk size: 64 KB plaintext per chunk
STREAM_CHUNK_SIZE: int = 64 * 1024  # 65536 bytes

# ChaCha20-Poly1305 constants
CHACHA20_KEY_LEN: int = 32
CHACHA20_NONCE_LEN: int = 12
POLY1305_TAG_LEN: int = 16

# STREAM nonce prefix length (11 bytes, last byte is counter+final)
STREAM_NONCE_PREFIX_LEN: int = 11

# Maximum chunks (counter is effectively 7 bits * many bytes)
# In practice limited to ~4 TB files (64KB * 2^26 chunks)
MAX_CHUNK_COUNTER: int = (1 << 26) - 1


# =============================================================================
# STREAM Encryption
# =============================================================================


def stream_encrypt(
    input_stream: BinaryIO,
    output_stream: BinaryIO,
    key: bytes,
) -> int:
    """
    Encrypt a stream using age STREAM construction.

    Args:
        input_stream: Input stream to read plaintext from.
        output_stream: Output stream to write ciphertext to.
        key: 32-byte encryption key (payload_key derived via HKDF).

    Returns:
        Total bytes written to output.

    Raises:
        EncryptionError: If encryption fails.
    """
    if len(key) != CHACHA20_KEY_LEN:
        raise EncryptionError(f"Key must be {CHACHA20_KEY_LEN} bytes, got {len(key)}")

    counter = 0
    total_written = 0

    while True:
        # Read chunk
        chunk = input_stream.read(STREAM_CHUNK_SIZE)

        # Peek ahead to check if this is the last chunk
        next_byte = input_stream.read(1)
        is_final = len(next_byte) == 0

        if next_byte:
            # Put the byte back by seeking
            input_stream.seek(-1, 1)

        # Handle empty input file
        if not chunk and counter == 0:
            # Empty file - write single final chunk with empty plaintext
            nonce = _derive_stream_nonce(0, is_final=True)
            try:
                ciphertext = crypto_aead_chacha20poly1305_ietf_encrypt(b"", b"", nonce, key)
            except Exception as e:
                raise EncryptionError(f"Failed to encrypt final chunk: {e}") from e

            output_stream.write(ciphertext)
            total_written += len(ciphertext)
            break

        if not chunk:
            # No more data after previous final chunk
            break

        # Check counter overflow
        if counter > MAX_CHUNK_COUNTER:
            raise EncryptionError("File too large: chunk counter overflow")

        # Derive nonce for this chunk (counter-based, no prefix)
        nonce = _derive_stream_nonce(counter, is_final)

        # Encrypt chunk
        try:
            ciphertext = crypto_aead_chacha20poly1305_ietf_encrypt(chunk, b"", nonce, key)
        except Exception as e:
            raise EncryptionError(f"Failed to encrypt chunk {counter}: {e}") from e

        # Write ciphertext (includes Poly1305 tag)
        output_stream.write(ciphertext)
        total_written += len(ciphertext)

        counter += 1

        if is_final:
            break

    return total_written


def stream_decrypt(
    input_stream: BinaryIO,
    output_stream: BinaryIO,
    key: bytes,
) -> int:
    """
    Decrypt a stream using age STREAM construction.

    Args:
        input_stream: Input stream to read ciphertext from.
        output_stream: Output stream to write plaintext to.
        key: 32-byte decryption key (payload_key derived via HKDF).

    Returns:
        Total bytes written to output.

    Raises:
        DecryptionError: If decryption fails or stream is invalid.
    """
    if len(key) != CHACHA20_KEY_LEN:
        raise DecryptionError(f"Key must be {CHACHA20_KEY_LEN} bytes, got {len(key)}")

    counter = 0
    total_written = 0
    found_final = False

    # Expected ciphertext chunk size (plaintext + tag)
    ct_chunk_size = STREAM_CHUNK_SIZE + POLY1305_TAG_LEN

    while True:
        # Read ciphertext chunk
        ciphertext = input_stream.read(ct_chunk_size)

        if not ciphertext:
            if not found_final:
                raise DecryptionError("Unexpected end of stream: missing final chunk")
            break

        # Check if this might be the final chunk (smaller or we're at EOF)
        remaining = input_stream.read(1)
        is_last_read = len(remaining) == 0

        if remaining:
            input_stream.seek(-1, 1)

        # Determine if this is a final chunk
        # Final chunk can be any size from POLY1305_TAG_LEN to ct_chunk_size
        is_short_chunk = len(ciphertext) < ct_chunk_size
        is_final = is_short_chunk or is_last_read

        # For full-size chunks that aren't the last read, try non-final first
        if not is_short_chunk and not is_last_read:
            is_final = False

        # Check counter overflow
        if counter > MAX_CHUNK_COUNTER:
            raise DecryptionError("File too large: chunk counter overflow")

        # Try to decrypt (counter-based nonce, no prefix)
        nonce = _derive_stream_nonce(counter, is_final)

        try:
            plaintext = crypto_aead_chacha20poly1305_ietf_decrypt(ciphertext, b"", nonce, key)
        except Exception:
            # If we assumed non-final, try final
            if not is_final:
                nonce = _derive_stream_nonce(counter, is_final=True)
                try:
                    plaintext = crypto_aead_chacha20poly1305_ietf_decrypt(
                        ciphertext, b"", nonce, key
                    )
                    is_final = True
                except Exception as e:
                    raise DecryptionError(
                        f"Failed to decrypt chunk {counter}: authentication failed"
                    ) from e
            else:
                raise DecryptionError(
                    f"Failed to decrypt chunk {counter}: authentication failed"
                ) from None

        if plaintext is None:
            raise DecryptionError(f"Chunk {counter} decryption returned None")

        # Write plaintext
        output_stream.write(plaintext)
        total_written += len(plaintext)

        if is_final:
            found_final = True
            # Verify no more data after final chunk
            extra = input_stream.read(1)
            if extra:
                raise DecryptionError("Data found after final chunk")
            break

        counter += 1

    return total_written


# =============================================================================
# Bytes Interface (convenience)
# =============================================================================


def stream_encrypt_bytes(plaintext: bytes, key: bytes) -> bytes:
    """
    Encrypt bytes using age STREAM.

    Args:
        plaintext: Data to encrypt.
        key: 32-byte encryption key.

    Returns:
        Encrypted bytes.
    """
    import io

    input_stream = io.BytesIO(plaintext)
    output_stream = io.BytesIO()

    stream_encrypt(input_stream, output_stream, key)

    return output_stream.getvalue()


def stream_decrypt_bytes(ciphertext: bytes, key: bytes) -> bytes:
    """
    Decrypt bytes using age STREAM.

    Args:
        ciphertext: Data to decrypt.
        key: 32-byte decryption key.

    Returns:
        Decrypted bytes.
    """
    import io

    input_stream = io.BytesIO(ciphertext)
    output_stream = io.BytesIO()

    stream_decrypt(input_stream, output_stream, key)

    return output_stream.getvalue()


# =============================================================================
# Internal Helpers
# =============================================================================


def _derive_stream_nonce(counter: int, is_final: bool) -> bytes:
    """
    Derive STREAM nonce for a chunk (age-compatible).

    Nonce construction (per age spec from c2sp.org/age):
        - First 11 bytes: big-endian chunk counter (0, 1, 2, ...)
        - Last byte: 0x01 for final chunk, 0x00 for all others

    Args:
        counter: Chunk counter (0, 1, 2, ...).
        is_final: True if this is the final chunk.

    Returns:
        12-byte nonce.
    """
    # First 11 bytes: big-endian counter
    counter_bytes = counter.to_bytes(11, "big")
    # Last byte: final flag
    final_byte = bytes([0x01 if is_final else 0x00])
    return counter_bytes + final_byte


# =============================================================================
# Chunked Iterator Interface
# =============================================================================


def iter_encrypt_chunks(data: bytes, key: bytes) -> Iterator[bytes]:
    """
    Iterate over encrypted chunks.

    Yields individual encrypted chunks for streaming writes.

    Args:
        data: Plaintext data.
        key: 32-byte encryption key.

    Yields:
        Encrypted chunk bytes.
    """
    if len(key) != CHACHA20_KEY_LEN:
        raise EncryptionError(f"Key must be {CHACHA20_KEY_LEN} bytes")

    offset = 0
    counter = 0

    while True:
        chunk = data[offset : offset + STREAM_CHUNK_SIZE]
        offset += len(chunk)

        is_final = offset >= len(data)

        # Handle empty input
        if not chunk and counter == 0:
            nonce = _derive_stream_nonce(0, is_final=True)
            yield crypto_aead_chacha20poly1305_ietf_encrypt(b"", b"", nonce, key)
            break

        if not chunk:
            break

        nonce = _derive_stream_nonce(counter, is_final)
        yield crypto_aead_chacha20poly1305_ietf_encrypt(chunk, b"", nonce, key)

        if is_final:
            break

        counter += 1
