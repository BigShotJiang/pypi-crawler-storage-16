"""
HKDF-SHA256 key derivation for pq-age.

Central implementation of RFC 5869 HKDF with secure memory handling.
All intermediate secrets are wiped after use.

Security:
    - Returns bytearray so caller can securely wipe after use
    - All intermediate values (PRK, T) are wiped in finally block
    - Uses native secure_wipe when available
"""

import hashlib
import hmac
import logging

from pqage.crypto.utils import secure_wipe

logger = logging.getLogger(__name__)


def hkdf_sha256(
    ikm: bytes | bytearray | memoryview,
    salt: bytes,
    info: bytes,
    length: int,
) -> bytearray:
    """
    HKDF-SHA256 key derivation (RFC 5869).

    All intermediate secrets (PRK, T values) are securely wiped after use.
    Returns a bytearray so the caller can securely wipe it after use.

    Args:
        ikm: Input keying material (accepts bytes, bytearray, or memoryview).
        salt: Optional salt (use empty bytes for none).
        info: Context/application info.
        length: Output length in bytes.

    Returns:
        Derived key material as bytearray (caller must wipe after use).

    Security:
        The returned bytearray MUST be wiped by the caller using secure_wipe()
        after use to prevent secrets from lingering in memory.
    """
    prk_buf: bytearray | None = None
    t_buf: bytearray | None = None
    output_buf: bytearray | None = None

    try:
        # Extract phase (RFC 5869 Section 2.2)
        if not salt:
            salt = b"\x00" * 32  # Default salt per RFC 5869

        # Convert memoryview to bytes for hmac (required by hashlib)
        ikm_bytes = bytes(ikm) if isinstance(ikm, memoryview) else ikm
        prk = hmac.new(salt, ikm_bytes, hashlib.sha256).digest()
        prk_buf = bytearray(prk)

        # Expand phase (RFC 5869 Section 2.3)
        output_buf = bytearray()
        t_buf = bytearray()
        counter = 1

        while len(output_buf) < length:
            # T(i) = HMAC-Hash(PRK, T(i-1) || info || counter)
            t_input = bytes(t_buf) + info + bytes([counter])
            t_new = hmac.new(bytes(prk_buf), t_input, hashlib.sha256).digest()

            # Wipe previous T value before replacing
            secure_wipe(t_buf)
            t_buf = bytearray(t_new)

            output_buf.extend(t_buf)
            counter += 1

        # Return bytearray so caller can wipe - truncate to requested length
        result = bytearray(output_buf[:length])
        return result

    finally:
        # Securely wipe all intermediate secrets
        if prk_buf is not None:
            secure_wipe(prk_buf)
        if t_buf is not None:
            secure_wipe(t_buf)
        # Wipe output_buf since we returned a copy
        if output_buf is not None:
            secure_wipe(output_buf)
