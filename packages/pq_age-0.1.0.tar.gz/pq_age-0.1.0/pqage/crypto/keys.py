"""
Key generation and derivation for pq-age.

Provides deterministic key generation from a master seed using HKDF-SHA256
key derivation. Generates both X25519 (classical) and ML-KEM-1024 (PQ) keys.

Security Note:
    HKDF-SHA256 is used for FIPS-compliance and consistency with age format.
"""

import logging
from os import urandom

import oqs
from nacl.bindings import crypto_scalarmult_base

from pqage.constants import (
    KDF_CONTEXT_KYBER,
    KDF_CONTEXT_MASTER,
    KDF_CONTEXT_PREFIX,
    KDF_CONTEXT_X25519,
    KYBER_NAME,
    KYBER_SEED_LEN,
    X25519_SCALAR_LEN,
)
from pqage.crypto.kdf import hkdf_sha256
from pqage.crypto.utils import secure_wipe
from pqage.crypto.x25519 import clamp_scalar
from pqage.exceptions import KeyGenerationError

logger = logging.getLogger(__name__)


class SecureKeyBundle:
    """
    Secure key bundle with automatic memory wiping.

    Stores private keys in mutable bytearrays that can be securely wiped.
    Implements context manager protocol for automatic cleanup.

    Example:
        with SecureKeyBundle.generate() as keys:
            # Use keys for encryption via age format
            from pqage.age_file_ops import MlkemX25519Recipient, encrypt
            recipient = MlkemX25519Recipient(keys.kyber_pk, keys.x25519_pk)
            ciphertext = encrypt(b"secret", [recipient])
        # Keys are automatically wiped here

        # Or manual management:
        keys = SecureKeyBundle.generate()
        try:
            # Use keys...
        finally:
            keys.wipe()

    Security:
        - Private keys stored as bytearray (wipeable)
        - Public keys stored as bytes (not secret)
        - Automatic wipe on context exit or garbage collection
        - Manual wipe() available for explicit cleanup
    """

    __slots__ = (
        "_master_seed",
        "_x25519_pk",
        "_x25519_sk",
        "_kyber_pk",
        "_kyber_sk",
        "_wiped",
    )

    def __init__(
        self,
        master_seed: bytes,
        x25519_pk: bytes,
        x25519_sk: bytes,
        kyber_pk: bytes,
        kyber_sk: bytes,
    ) -> None:
        """
        Initialize SecureKeyBundle with key material.

        Args:
            master_seed: 32-byte master seed.
            x25519_pk: 32-byte X25519 public key.
            x25519_sk: 32-byte X25519 secret key.
            kyber_pk: 1568-byte ML-KEM-1024 public key.
            kyber_sk: 3168-byte ML-KEM-1024 secret key.
        """
        # Store master seed as bytearray (secret)
        self._master_seed = bytearray(master_seed)
        # Public keys as bytes (not secret)
        self._x25519_pk = x25519_pk
        self._kyber_pk = kyber_pk
        # Secret keys as bytearray (wipeable)
        self._x25519_sk = bytearray(x25519_sk)
        self._kyber_sk = bytearray(kyber_sk)
        self._wiped = False

    @classmethod
    def generate(cls, master_seed: bytes | None = None) -> "SecureKeyBundle":
        """
        Generate a new SecureKeyBundle with fresh keys.

        Generates deterministic X25519 and ML-KEM-1024 keypairs from a master seed.
        If no seed is provided, generates a cryptographically secure random seed.

        Args:
            master_seed: Optional 32-byte seed. If None, random seed is generated.

        Returns:
            SecureKeyBundle with generated keys.

        Raises:
            KeyGenerationError: If key generation fails.
        """
        master_buf: bytearray | None = None

        # Generate or validate master seed
        if master_seed is None:
            master_seed = urandom(32)
        elif len(master_seed) != 32:
            raise KeyGenerationError(f"Master seed must be 32 bytes, got {len(master_seed)}")

        try:
            # Derive master key using HKDF-SHA256
            master_buf = hkdf_sha256(master_seed, b"", KDF_CONTEXT_MASTER, 32)

            # Generate keypairs
            x_pk, x_sk = _derive_x25519_scalar(master_buf)
            kyber_pk, kyber_sk = _derive_kyber_keypair(master_buf)

            return cls(
                master_seed=master_seed,
                x25519_pk=x_pk,
                x25519_sk=x_sk,
                kyber_pk=kyber_pk,
                kyber_sk=kyber_sk,
            )

        finally:
            # Wipe master key from memory (not master_seed - that's stored in bundle)
            if master_buf is not None:
                secure_wipe(master_buf)

    def _check_wiped(self) -> None:
        """Raise ValueError if bundle has been wiped."""
        if self._wiped:
            raise ValueError("SecureKeyBundle has been wiped")

    @property
    def master_seed(self) -> bytes:
        """Get master seed as bytes (creates copy)."""
        self._check_wiped()
        return bytes(self._master_seed)

    @property
    def x25519_pk(self) -> bytes:
        """Get X25519 public key."""
        self._check_wiped()
        return self._x25519_pk

    @property
    def x25519_sk(self) -> bytes:
        """Get X25519 secret key as bytes (creates copy)."""
        self._check_wiped()
        return bytes(self._x25519_sk)

    @property
    def kyber_pk(self) -> bytes:
        """Get ML-KEM-1024 public key."""
        self._check_wiped()
        return self._kyber_pk

    @property
    def kyber_sk(self) -> bytes:
        """Get ML-KEM-1024 secret key as bytes (creates copy)."""
        self._check_wiped()
        return bytes(self._kyber_sk)

    @property
    def is_wiped(self) -> bool:
        """Check if bundle has been wiped."""
        return self._wiped

    def wipe(self) -> None:
        """
        Securely wipe all secret key material from memory.

        After calling wipe(), the bundle cannot be used and all
        property access will raise ValueError.

        Uses secure_wipe for compiler-resistant zeroing when native
        extension is available.
        """
        if self._wiped:
            return

        # Use secure_wipe for guaranteed compiler-resistant zeroing
        secure_wipe(self._master_seed)
        secure_wipe(self._x25519_sk)
        secure_wipe(self._kyber_sk)

        self._wiped = True
        logger.debug("SecureKeyBundle wiped")

    def __enter__(self) -> "SecureKeyBundle":
        """Enter context manager."""
        return self

    def __exit__(
        self,
        exc_type: type | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> None:
        """Exit context manager, wiping keys."""
        self.wipe()

    def __del__(self) -> None:
        """Destructor - wipe on garbage collection."""
        self.wipe()

    def __repr__(self) -> str:
        """String representation."""
        if self._wiped:
            return "SecureKeyBundle(wiped=True)"
        return f"SecureKeyBundle(x25519_pk={self._x25519_pk[:8].hex()}..., wiped=False)"

    # Dict-like access for convenience
    def __getitem__(self, key: str) -> bytes:
        """Dict-like access for convenience."""
        self._check_wiped()
        if key == "master_seed":
            return bytes(self._master_seed)
        elif key == "x25519_pk":
            return self._x25519_pk
        elif key == "x25519_sk":
            return bytes(self._x25519_sk)
        elif key == "kyber_pk":
            return self._kyber_pk
        elif key == "kyber_sk":
            return bytes(self._kyber_sk)
        else:
            raise KeyError(f"Unknown key: {key}")

    def keys(self) -> list[str]:
        """Return list of keys for dict-like iteration."""
        return ["master_seed", "x25519_pk", "x25519_sk", "kyber_pk", "kyber_sk"]

    def __contains__(self, key: object) -> bool:
        """Check if key exists (for 'in' operator)."""
        return key in self.keys()


def derive_key(
    material: bytes | bytearray | memoryview,
    context: bytes,
) -> bytearray:
    """
    Derive a cryptographic key using HKDF-SHA256 key derivation.

    Returns a bytearray so the caller can securely wipe it after use.

    Args:
        material: Input keying material (accepts bytes, bytearray, or memoryview).
        context: Domain separation context string.

    Returns:
        32-byte derived key as bytearray (caller must wipe after use).

    Raises:
        KeyGenerationError: If derivation fails.

    Security:
        The returned bytearray MUST be wiped by the caller using secure_wipe()
        after use to prevent secrets from lingering in memory.
    """
    if not material:
        raise KeyGenerationError("Key material cannot be empty")
    if not context:
        raise KeyGenerationError("Context cannot be empty")

    full_context = KDF_CONTEXT_PREFIX + context
    return hkdf_sha256(material, b"", full_context, 32)


def _derive_x25519_scalar(master: bytes | bytearray) -> tuple[bytes, bytes]:
    """
    Derive X25519 keypair from master key.

    Args:
        master: 32-byte master key material.

    Returns:
        Tuple of (public_key, secret_key).
    """
    raw_scalar: bytearray | None = None
    try:
        # Derive raw scalar using HKDF-SHA256 (returns bytearray)
        raw_scalar = hkdf_sha256(master, b"", KDF_CONTEXT_X25519, X25519_SCALAR_LEN)

        # Apply X25519 clamping for security (RFC 7748 Section 5)
        clamp_scalar(raw_scalar)

        sk = bytes(raw_scalar)
        pk = crypto_scalarmult_base(sk)

        return pk, sk
    finally:
        # Wipe the raw scalar
        if raw_scalar is not None:
            secure_wipe(raw_scalar)


def _derive_kyber_keypair(master: bytes | bytearray) -> tuple[bytes, bytes]:
    """
    Derive ML-KEM-1024 keypair from master key.

    Args:
        master: 32-byte master key material.

    Returns:
        Tuple of (public_key, secret_key).

    Raises:
        KeyGenerationError: If key generation fails.
    """
    kyber_seed_buf: bytearray | None = None
    kem = oqs.KeyEncapsulation(KYBER_NAME)
    try:
        # Derive seed using HKDF-SHA256 (returns bytearray directly)
        kyber_seed_buf = hkdf_sha256(master, b"", KDF_CONTEXT_KYBER, KYBER_SEED_LEN)

        pk = kem.generate_keypair_seed(seed=bytes(kyber_seed_buf))
        sk = kem.export_secret_key()
        return pk, sk
    except Exception as e:
        logger.error("ML-KEM key generation failed: %s", e)
        raise KeyGenerationError(f"ML-KEM-1024 key generation failed: {e}") from e
    finally:
        # Wipe seed from memory
        if kyber_seed_buf is not None:
            secure_wipe(kyber_seed_buf)
        kem.free()


def generate_keys(master_seed: bytes | None = None) -> SecureKeyBundle:
    """
    Generate a complete key bundle for pq-age encryption.

    Generates deterministic X25519 and ML-KEM-1024 keypairs from a master seed.
    If no seed is provided, generates a cryptographically secure random seed.

    Args:
        master_seed: Optional 32-byte seed. If None, random seed is generated.

    Returns:
        SecureKeyBundle containing all keys and the master seed.
        Use with context manager or call .wipe() after use.

    Raises:
        KeyGenerationError: If key generation fails.

    Example:
        with generate_keys() as keys:
            # Use keys for encryption
            ...
        # Keys automatically wiped
    """
    return SecureKeyBundle.generate(master_seed)
