"""
Password-based key wrapping for pq-age.

Uses Argon2id for key derivation and XChaCha20-Poly1305 for encryption.
Only the master seed is stored, keys are regenerated on unwrap.
"""

import logging
import struct
from os import urandom

from nacl.pwhash.argon2id import kdf as argon2id_kdf

from pqage.constants import (
    ARGON2_MEMLIMIT,
    ARGON2_OPSLIMIT,
    ARGON2_SALT_LEN,
    WRAPPED_KEY_PREFIX,
    WRAPPED_KEY_PREFIX_LEN,
    XCHACHA20_KEY_LEN,
)
from pqage.crypto.keys import SecureKeyBundle, generate_keys
from pqage.crypto.symmetric import decrypt, encrypt
from pqage.crypto.utils import secure_starts_with, secure_wipe
from pqage.exceptions import KeyWrappingError, PasswordError

logger = logging.getLogger(__name__)

# Master seed length for validation
MASTER_SEED_LEN: int = 32


def _serialize_master_seed(master_seed: bytes) -> bytes:
    """
    Serialize master seed with length prefix for safe deserialization.

    Format: <4-byte length><seed bytes>
    """
    if len(master_seed) != MASTER_SEED_LEN:
        raise KeyWrappingError(
            f"Master seed must be {MASTER_SEED_LEN} bytes, got {len(master_seed)}"
        )
    return struct.pack("<I", len(master_seed)) + master_seed


def _deserialize_master_seed(data: bytes) -> bytes:
    """
    Deserialize master seed with validation.

    Raises:
        KeyWrappingError: If data format is invalid.
    """
    if len(data) < 4:
        raise KeyWrappingError("Serialized data too short")

    length = struct.unpack("<I", data[:4])[0]

    if length != MASTER_SEED_LEN:
        raise KeyWrappingError(
            f"Invalid master seed length in data: {length} (expected {MASTER_SEED_LEN})"
        )

    if len(data) != 4 + length:
        raise KeyWrappingError(f"Data length mismatch: got {len(data)}, expected {4 + length}")

    return data[4:]


def wrap_keys(keys: SecureKeyBundle, password: str) -> bytes:
    """
    Wrap key bundle with password protection.

    Uses Argon2id for password-based key derivation, then encrypts
    only the master seed. Full keys can be regenerated from seed.

    Args:
        keys: SecureKeyBundle containing master_seed.
        password: Password to protect the key bundle.

    Returns:
        Wrapped key blob: prefix + salt + encrypted_seed.

    Raises:
        KeyWrappingError: If wrapping fails.
        PasswordError: If password is empty.
    """
    if not password:
        raise PasswordError("Password cannot be empty")

    wrap_key_buf: bytearray | None = None

    try:
        # Generate salt
        salt = urandom(ARGON2_SALT_LEN)

        # Derive wrapping key from password
        wrap_key = argon2id_kdf(
            XCHACHA20_KEY_LEN,
            password.encode("utf-8"),
            salt,
            opslimit=ARGON2_OPSLIMIT,
            memlimit=ARGON2_MEMLIMIT,
        )

        # Store in wipeable buffer
        wrap_key_buf = bytearray(wrap_key)

        # Serialize and encrypt master seed (NOT using pickle!)
        seed_data = _serialize_master_seed(keys["master_seed"])
        encrypted_seed = encrypt(seed_data, bytes(wrap_key_buf))

        return WRAPPED_KEY_PREFIX + salt + encrypted_seed

    except (KeyWrappingError, PasswordError):
        raise
    except Exception as e:
        logger.error("Key wrapping failed: %s", e)
        raise KeyWrappingError(f"Key wrapping failed: {e}") from e
    finally:
        # Wipe wrapping key from memory
        if wrap_key_buf is not None:
            secure_wipe(wrap_key_buf)


def unwrap_keys(wrapped: bytes, password: str) -> SecureKeyBundle:
    """
    Unwrap password-protected key bundle.

    Derives the wrapping key from password, decrypts the master seed,
    and regenerates all keys deterministically.

    Args:
        wrapped: Wrapped key blob from wrap_keys().
        password: Password used during wrapping.

    Returns:
        SecureKeyBundle with all regenerated keys.
        Use with context manager or call .wipe() after use.

    Raises:
        KeyWrappingError: If blob format is invalid.
        PasswordError: If password is incorrect or empty.

    Example:
        with unwrap_keys(wrapped, password) as keys:
            # Use keys for decryption
            ...
        # Keys automatically wiped
    """
    if not password:
        raise PasswordError("Password cannot be empty")

    wrap_key_buf: bytearray | None = None

    # Validate prefix (constant-time comparison)
    if not secure_starts_with(wrapped, WRAPPED_KEY_PREFIX):
        raise KeyWrappingError("Invalid wrapped key format - wrong prefix")

    # Minimum length check
    min_len = WRAPPED_KEY_PREFIX_LEN + ARGON2_SALT_LEN + 40  # prefix + salt + min ct
    if len(wrapped) < min_len:
        raise KeyWrappingError(f"Wrapped data too short: {len(wrapped)} bytes")

    try:
        # Extract components
        salt_start = WRAPPED_KEY_PREFIX_LEN
        salt_end = salt_start + ARGON2_SALT_LEN
        salt = wrapped[salt_start:salt_end]
        encrypted_seed = wrapped[salt_end:]

        # Derive wrapping key
        wrap_key = argon2id_kdf(
            XCHACHA20_KEY_LEN,
            password.encode("utf-8"),
            salt,
            opslimit=ARGON2_OPSLIMIT,
            memlimit=ARGON2_MEMLIMIT,
        )

        # Store in wipeable buffer
        wrap_key_buf = bytearray(wrap_key)

        # Decrypt and deserialize
        seed_data = decrypt(encrypted_seed, bytes(wrap_key_buf))
        master_seed = _deserialize_master_seed(seed_data)

        # Regenerate all keys
        return generate_keys(master_seed)

    except KeyWrappingError:
        raise
    except Exception as e:
        logger.error("Key unwrapping failed: %s", e)
        # Don't leak whether password was wrong vs data corrupted
        raise PasswordError("Incorrect password or corrupted data") from e
    finally:
        # Wipe wrapping key from memory
        if wrap_key_buf is not None:
            secure_wipe(wrap_key_buf)
