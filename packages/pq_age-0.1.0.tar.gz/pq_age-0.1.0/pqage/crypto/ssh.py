"""
SSH key parsing and Ed25519 to X25519 conversion for pq-age.

Supports parsing OpenSSH format keys:
- Ed25519 public keys (authorized_keys format and PEM)
- Ed25519 private keys (OpenSSH format)

The Ed25519 keys are converted to X25519 for use with age encryption.
Both use Curve25519 but with different coordinate representations:
- Ed25519: Edwards curve representation (for signatures)
- X25519: Montgomery curve representation (for key exchange)

Security:
- Ed25519 -> X25519 conversion is mathematically sound
- Key hash uses SHA256 (truncated) for recipient matching
- Private key parsing handles encrypted keys via password prompt
"""

import base64
import hashlib
import logging
import re
import struct
from dataclasses import dataclass

from nacl.bindings import (
    crypto_sign_ed25519_pk_to_curve25519,
    crypto_sign_ed25519_sk_to_curve25519,
)

from pqage.exceptions import InvalidKeyError

logger = logging.getLogger(__name__)

# =============================================================================
# Constants
# =============================================================================

# OpenSSH key type identifiers
SSH_ED25519_TYPE: str = "ssh-ed25519"
SSH_ED25519_TYPE_BYTES: bytes = b"ssh-ed25519"

# OpenSSH PEM markers
OPENSSH_PRIVATE_KEY_BEGIN: str = "-----BEGIN OPENSSH PRIVATE KEY-----"
OPENSSH_PRIVATE_KEY_END: str = "-----END OPENSSH PRIVATE KEY-----"

# OpenSSH private key magic
OPENSSH_AUTH_MAGIC: bytes = b"openssh-key-v1\x00"

# Key lengths
ED25519_PUBLIC_KEY_LEN: int = 32
ED25519_SECRET_KEY_LEN: int = 64  # seed + public key
ED25519_SEED_LEN: int = 32
X25519_PUBLIC_KEY_LEN: int = 32
X25519_SECRET_KEY_LEN: int = 32

# Key hash length (age uses first 4 bytes of SHA256)
SSH_KEY_HASH_LEN: int = 4

# Regex patterns
AUTHORIZED_KEYS_PATTERN = re.compile(r"^(ssh-ed25519)\s+([A-Za-z0-9+/=]+)(?:\s+(.*))?$")


# =============================================================================
# Data Classes
# =============================================================================


@dataclass
class SshEd25519PublicKey:
    """
    Parsed SSH Ed25519 public key.

    Attributes:
        ed25519_pk: Raw Ed25519 public key (32 bytes).
        x25519_pk: Converted X25519 public key (32 bytes).
        key_hash: SHA256 hash truncated to 4 bytes (for stanza matching).
        ssh_key_blob: SSH wire format of the public key (for age tweak).
        comment: Optional key comment.
    """

    ed25519_pk: bytes
    x25519_pk: bytes
    key_hash: bytes
    ssh_key_blob: bytes
    comment: str = ""

    @classmethod
    def from_ed25519(cls, ed25519_pk: bytes, comment: str = "") -> "SshEd25519PublicKey":
        """
        Create from raw Ed25519 public key.

        Args:
            ed25519_pk: 32-byte Ed25519 public key.
            comment: Optional comment.

        Returns:
            SshEd25519PublicKey instance.

        Raises:
            InvalidKeyError: If key conversion fails.
        """
        if len(ed25519_pk) != ED25519_PUBLIC_KEY_LEN:
            raise InvalidKeyError(
                f"Ed25519 public key must be {ED25519_PUBLIC_KEY_LEN} bytes, got {len(ed25519_pk)}"
            )

        try:
            x25519_pk = crypto_sign_ed25519_pk_to_curve25519(ed25519_pk)
        except Exception as e:
            raise InvalidKeyError(f"Failed to convert Ed25519 to X25519: {e}") from e

        # Compute SSH wire format (used for key hash and age tweak)
        ssh_key_blob = _encode_ssh_public_key(ed25519_pk)
        key_hash = hashlib.sha256(ssh_key_blob).digest()[:SSH_KEY_HASH_LEN]

        return cls(
            ed25519_pk=ed25519_pk,
            x25519_pk=x25519_pk,
            key_hash=key_hash,
            ssh_key_blob=ssh_key_blob,
            comment=comment,
        )


@dataclass
class SshEd25519PrivateKey:
    """
    Parsed SSH Ed25519 private key.

    Attributes:
        ed25519_pk: Raw Ed25519 public key (32 bytes).
        ed25519_sk: Raw Ed25519 secret key (64 bytes = seed + pk).
        x25519_pk: Converted X25519 public key (32 bytes).
        x25519_sk: Converted X25519 secret key (32 bytes).
        key_hash: SHA256 hash for stanza matching.
        ssh_key_blob: SSH wire format of the public key (for age tweak).
        comment: Optional key comment.
    """

    ed25519_pk: bytes
    ed25519_sk: bytes
    x25519_pk: bytes
    x25519_sk: bytes
    key_hash: bytes
    ssh_key_blob: bytes
    comment: str = ""

    def wipe(self) -> None:
        """
        Securely wipe private key material from memory.

        Note: Python bytes are immutable, so we replace the attributes
        with zeroed bytearrays. This provides limited security but is
        better than leaving secrets in memory.
        """
        # Create zeroed replacements for secret keys
        if self.ed25519_sk:
            zeroed_ed = bytearray(len(self.ed25519_sk))
            object.__setattr__(self, "ed25519_sk", bytes(zeroed_ed))

        if self.x25519_sk:
            zeroed_x = bytearray(len(self.x25519_sk))
            object.__setattr__(self, "x25519_sk", bytes(zeroed_x))

    @classmethod
    def from_ed25519(
        cls, ed25519_sk: bytes, ed25519_pk: bytes | None = None, comment: str = ""
    ) -> "SshEd25519PrivateKey":
        """
        Create from raw Ed25519 secret key.

        Args:
            ed25519_sk: 64-byte Ed25519 secret key (seed + pk) or 32-byte seed.
            ed25519_pk: Optional 32-byte public key (derived if not provided).
            comment: Optional comment.

        Returns:
            SshEd25519PrivateKey instance.

        Raises:
            InvalidKeyError: If key conversion fails.
        """
        # Handle 32-byte seed vs 64-byte full secret key
        if len(ed25519_sk) == ED25519_SEED_LEN:
            # Need to derive full key from seed
            from nacl.signing import SigningKey

            signing_key = SigningKey(ed25519_sk)
            ed25519_pk = bytes(signing_key.verify_key)
            # Full Ed25519 secret key is seed + public key (64 bytes)
            # bytes(signing_key) only returns seed (32 bytes)
            full_sk = ed25519_sk + ed25519_pk
        elif len(ed25519_sk) == ED25519_SECRET_KEY_LEN:
            full_sk = ed25519_sk
            if ed25519_pk is None:
                # Extract public key from last 32 bytes
                ed25519_pk = ed25519_sk[ED25519_SEED_LEN:]
        else:
            raise InvalidKeyError(
                f"Ed25519 secret key must be {ED25519_SEED_LEN} or "
                f"{ED25519_SECRET_KEY_LEN} bytes, got {len(ed25519_sk)}"
            )

        if len(ed25519_pk) != ED25519_PUBLIC_KEY_LEN:
            raise InvalidKeyError(
                f"Ed25519 public key must be {ED25519_PUBLIC_KEY_LEN} bytes, got {len(ed25519_pk)}"
            )

        try:
            x25519_pk = crypto_sign_ed25519_pk_to_curve25519(ed25519_pk)
            x25519_sk = crypto_sign_ed25519_sk_to_curve25519(full_sk)
        except Exception as e:
            raise InvalidKeyError(f"Failed to convert Ed25519 to X25519: {e}") from e

        # Compute SSH wire format (used for key hash and age tweak)
        ssh_key_blob = _encode_ssh_public_key(ed25519_pk)
        key_hash = hashlib.sha256(ssh_key_blob).digest()[:SSH_KEY_HASH_LEN]

        return cls(
            ed25519_pk=ed25519_pk,
            ed25519_sk=full_sk,
            x25519_pk=x25519_pk,
            x25519_sk=x25519_sk,
            key_hash=key_hash,
            ssh_key_blob=ssh_key_blob,
            comment=comment,
        )


# =============================================================================
# Parsing Functions
# =============================================================================


def parse_ssh_public_key(data: str | bytes) -> SshEd25519PublicKey:
    """
    Parse SSH Ed25519 public key from various formats.

    Supports:
    - authorized_keys format: "ssh-ed25519 AAAA... comment"
    - Raw base64: "AAAAC3NzaC1lZDI1NTE5..."
    - Wire format bytes

    Args:
        data: Key data as string or bytes.

    Returns:
        SshEd25519PublicKey instance.

    Raises:
        InvalidKeyError: If key format is invalid or not Ed25519.
    """
    if isinstance(data, bytes):
        data = data.decode("utf-8", errors="strict")

    data = data.strip()

    # Try authorized_keys format
    match = AUTHORIZED_KEYS_PATTERN.match(data)
    if match:
        key_type = match.group(1)
        b64_data = match.group(2)
        comment = match.group(3) or ""

        if key_type != SSH_ED25519_TYPE:
            raise InvalidKeyError(f"Unsupported SSH key type: {key_type}")

        wire_format = base64.b64decode(b64_data)
        ed25519_pk = _decode_ssh_public_key(wire_format)
        return SshEd25519PublicKey.from_ed25519(ed25519_pk, comment)

    # Try raw base64
    try:
        wire_format = base64.b64decode(data)
        ed25519_pk = _decode_ssh_public_key(wire_format)
        return SshEd25519PublicKey.from_ed25519(ed25519_pk)
    except Exception:
        pass

    raise InvalidKeyError("Invalid SSH public key format")


def parse_ssh_private_key(data: str | bytes, password: str | None = None) -> SshEd25519PrivateKey:
    """
    Parse SSH Ed25519 private key from OpenSSH format.

    Args:
        data: Private key data (PEM format).
        password: Optional password for encrypted keys.

    Returns:
        SshEd25519PrivateKey instance.

    Raises:
        InvalidKeyError: If key format is invalid or decryption fails.
    """
    if isinstance(data, bytes):
        data = data.decode("utf-8", errors="strict")

    data = data.strip()

    # Check for OpenSSH format markers
    if OPENSSH_PRIVATE_KEY_BEGIN not in data:
        raise InvalidKeyError("Not an OpenSSH private key format")

    # Extract base64 content
    lines = data.split("\n")
    b64_lines: list[str] = []
    in_key = False

    for line in lines:
        line = line.strip()
        if line == OPENSSH_PRIVATE_KEY_BEGIN:
            in_key = True
            continue
        if line == OPENSSH_PRIVATE_KEY_END:
            break
        if in_key:
            b64_lines.append(line)

    if not b64_lines:
        raise InvalidKeyError("Empty private key")

    try:
        key_data = base64.b64decode("".join(b64_lines))
    except Exception as e:
        raise InvalidKeyError(f"Invalid base64 in private key: {e}") from e

    return _parse_openssh_private_key(key_data, password)


def parse_ssh_public_key_file(path: str) -> SshEd25519PublicKey:
    """
    Parse SSH Ed25519 public key from file.

    Args:
        path: Path to public key file (e.g., ~/.ssh/id_ed25519.pub).

    Returns:
        SshEd25519PublicKey instance.

    Raises:
        FileNotFoundError: If file doesn't exist.
        InvalidKeyError: If key format is invalid.
    """
    with open(path, encoding="utf-8") as f:
        return parse_ssh_public_key(f.read())


def parse_ssh_private_key_file(path: str, password: str | None = None) -> SshEd25519PrivateKey:
    """
    Parse SSH Ed25519 private key from file.

    Args:
        path: Path to private key file (e.g., ~/.ssh/id_ed25519).
        password: Optional password for encrypted keys.

    Returns:
        SshEd25519PrivateKey instance.

    Raises:
        FileNotFoundError: If file doesn't exist.
        InvalidKeyError: If key format is invalid.
    """
    with open(path, encoding="utf-8") as f:
        return parse_ssh_private_key(f.read(), password)


# =============================================================================
# Internal Helpers
# =============================================================================


def _encode_ssh_public_key(ed25519_pk: bytes) -> bytes:
    """
    Encode Ed25519 public key to SSH wire format.

    Wire format:
    - 4 bytes: length of key type
    - N bytes: key type ("ssh-ed25519")
    - 4 bytes: length of public key
    - 32 bytes: public key

    Args:
        ed25519_pk: Raw 32-byte Ed25519 public key.

    Returns:
        SSH wire format bytes.
    """
    key_type = SSH_ED25519_TYPE_BYTES

    result = struct.pack(">I", len(key_type)) + key_type
    result += struct.pack(">I", len(ed25519_pk)) + ed25519_pk

    return result


def _decode_ssh_public_key(wire_format: bytes) -> bytes:
    """
    Decode Ed25519 public key from SSH wire format.

    Args:
        wire_format: SSH wire format bytes.

    Returns:
        Raw 32-byte Ed25519 public key.

    Raises:
        InvalidKeyError: If format is invalid.
    """
    if len(wire_format) < 4:
        raise InvalidKeyError("SSH public key too short")

    offset = 0

    # Read key type length
    type_len = struct.unpack(">I", wire_format[offset : offset + 4])[0]
    offset += 4

    if offset + type_len > len(wire_format):
        raise InvalidKeyError("Truncated SSH public key")

    # Read key type
    key_type = wire_format[offset : offset + type_len]
    offset += type_len

    if key_type != SSH_ED25519_TYPE_BYTES:
        raise InvalidKeyError(f"Unsupported SSH key type: {key_type.decode()}")

    # Read public key length
    if offset + 4 > len(wire_format):
        raise InvalidKeyError("Truncated SSH public key")

    pk_len = struct.unpack(">I", wire_format[offset : offset + 4])[0]
    offset += 4

    if pk_len != ED25519_PUBLIC_KEY_LEN:
        raise InvalidKeyError(f"Invalid Ed25519 public key length: {pk_len}")

    if offset + pk_len > len(wire_format):
        raise InvalidKeyError("Truncated SSH public key")

    return wire_format[offset : offset + pk_len]


def _parse_openssh_private_key(data: bytes, password: str | None = None) -> SshEd25519PrivateKey:
    """
    Parse OpenSSH private key format (internal).

    OpenSSH format (simplified):
    - Magic: "openssh-key-v1\0"
    - Cipher name (string)
    - KDF name (string)
    - KDF options (string)
    - Number of keys (uint32)
    - Public key(s) (string)
    - Encrypted private key(s) (string)

    Args:
        data: Raw OpenSSH private key bytes.
        password: Optional password for decryption.

    Returns:
        SshEd25519PrivateKey instance.

    Raises:
        InvalidKeyError: If format is invalid or decryption fails.
    """
    if not data.startswith(OPENSSH_AUTH_MAGIC):
        raise InvalidKeyError("Invalid OpenSSH private key magic")

    offset = len(OPENSSH_AUTH_MAGIC)

    # Read cipher name
    cipher_name, offset = _read_ssh_string(data, offset)

    # Read KDF name
    kdf_name, offset = _read_ssh_string(data, offset)

    # Read KDF options
    kdf_options, offset = _read_ssh_string(data, offset)

    # Read number of keys
    if offset + 4 > len(data):
        raise InvalidKeyError("Truncated private key")
    num_keys = struct.unpack(">I", data[offset : offset + 4])[0]
    offset += 4

    if num_keys != 1:
        raise InvalidKeyError(f"Expected 1 key, got {num_keys}")

    # Read public key
    public_key_blob, offset = _read_ssh_string(data, offset)

    # Read private section
    private_section, offset = _read_ssh_string(data, offset)

    # Handle encryption
    if cipher_name != b"none":
        if password is None:
            raise InvalidKeyError("Private key is encrypted, password required")

        private_section = _decrypt_private_section(
            private_section, cipher_name, kdf_name, kdf_options, password
        )

    # Parse private section
    return _parse_private_section(private_section, public_key_blob)


def _read_ssh_string(data: bytes, offset: int) -> tuple[bytes, int]:
    """
    Read SSH string (length-prefixed).

    Args:
        data: Raw bytes.
        offset: Current offset.

    Returns:
        Tuple of (string_bytes, new_offset).

    Raises:
        InvalidKeyError: If data is truncated.
    """
    if offset + 4 > len(data):
        raise InvalidKeyError("Truncated SSH string")

    length = struct.unpack(">I", data[offset : offset + 4])[0]
    offset += 4

    if offset + length > len(data):
        raise InvalidKeyError("Truncated SSH string content")

    return data[offset : offset + length], offset + length


def _decrypt_private_section(
    encrypted: bytes,
    cipher_name: bytes,
    kdf_name: bytes,
    kdf_options: bytes,
    password: str,
) -> bytes:
    """
    Decrypt private key section.

    Supports:
    - aes256-ctr with bcrypt KDF

    Args:
        encrypted: Encrypted private section.
        cipher_name: Cipher name (e.g., "aes256-ctr").
        kdf_name: KDF name (e.g., "bcrypt").
        kdf_options: KDF options (salt + rounds for bcrypt).
        password: Decryption password.

    Returns:
        Decrypted private section.

    Raises:
        InvalidKeyError: If decryption fails or cipher not supported.
    """
    if kdf_name == b"none":
        return encrypted

    if kdf_name != b"bcrypt":
        raise InvalidKeyError(f"Unsupported KDF: {kdf_name.decode()}")

    if cipher_name not in (b"aes256-ctr", b"aes256-cbc"):
        raise InvalidKeyError(f"Unsupported cipher: {cipher_name.decode()}")

    # Parse bcrypt options
    offset = 0
    salt, offset = _read_ssh_string(kdf_options, offset)

    if offset + 4 > len(kdf_options):
        raise InvalidKeyError("Truncated bcrypt options")
    rounds = struct.unpack(">I", kdf_options[offset : offset + 4])[0]

    # Derive key using bcrypt-pbkdf
    try:
        import bcrypt

        key_iv = bcrypt.kdf(
            password.encode("utf-8"),
            salt,
            48,  # 32 bytes key + 16 bytes IV
            rounds,
        )
    except ImportError:
        raise InvalidKeyError(
            "bcrypt package required for encrypted SSH keys: pip install bcrypt"
        ) from None
    except Exception as e:
        raise InvalidKeyError(f"Key derivation failed: {e}") from e

    key = key_iv[:32]
    iv = key_iv[32:48]

    # Decrypt
    try:
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

        if cipher_name == b"aes256-ctr":
            cipher = Cipher(algorithms.AES(key), modes.CTR(iv))
        else:  # aes256-cbc
            cipher = Cipher(algorithms.AES(key), modes.CBC(iv))

        decryptor = cipher.decryptor()
        decrypted = decryptor.update(encrypted) + decryptor.finalize()

    except ImportError:
        raise InvalidKeyError(
            "cryptography package required for encrypted SSH keys: pip install cryptography"
        ) from None
    except Exception as e:
        raise InvalidKeyError(f"Decryption failed: {e}") from e

    return decrypted


def _parse_private_section(private_section: bytes, public_key_blob: bytes) -> SshEd25519PrivateKey:
    """
    Parse decrypted private section.

    Private section format:
    - checkint1 (uint32)
    - checkint2 (uint32) - must match checkint1
    - key type (string)
    - public key (string)
    - private key (string) - for Ed25519: 64 bytes
    - comment (string)
    - padding

    Args:
        private_section: Decrypted private section bytes.
        public_key_blob: Public key blob (for verification).

    Returns:
        SshEd25519PrivateKey instance.

    Raises:
        InvalidKeyError: If format is invalid or checkints don't match.
    """
    if len(private_section) < 8:
        raise InvalidKeyError("Private section too short")

    # Check verification ints
    check1 = struct.unpack(">I", private_section[0:4])[0]
    check2 = struct.unpack(">I", private_section[4:8])[0]

    if check1 != check2:
        raise InvalidKeyError("Private key decryption failed (checkint mismatch)")

    offset = 8

    # Read key type
    key_type, offset = _read_ssh_string(private_section, offset)
    if key_type != SSH_ED25519_TYPE_BYTES:
        raise InvalidKeyError(f"Unsupported private key type: {key_type.decode()}")

    # Read public key
    pub_key, offset = _read_ssh_string(private_section, offset)
    if len(pub_key) != ED25519_PUBLIC_KEY_LEN:
        raise InvalidKeyError(f"Invalid public key length: {len(pub_key)}")

    # Read private key (Ed25519 stores seed + public = 64 bytes)
    priv_key, offset = _read_ssh_string(private_section, offset)
    if len(priv_key) != ED25519_SECRET_KEY_LEN:
        raise InvalidKeyError(f"Invalid private key length: {len(priv_key)}")

    # Read comment
    comment, offset = _read_ssh_string(private_section, offset)

    return SshEd25519PrivateKey.from_ed25519(
        ed25519_sk=priv_key,
        ed25519_pk=pub_key,
        comment=comment.decode("utf-8", errors="replace"),
    )


# =============================================================================
# Utility Functions
# =============================================================================


def compute_ssh_key_hash(ed25519_pk: bytes) -> bytes:
    """
    Compute SSH key hash for stanza matching.

    This is the first 4 bytes of SHA256(wire_format).

    Args:
        ed25519_pk: Raw 32-byte Ed25519 public key.

    Returns:
        4-byte key hash.
    """
    wire_format = _encode_ssh_public_key(ed25519_pk)
    return hashlib.sha256(wire_format).digest()[:SSH_KEY_HASH_LEN]


def ed25519_to_x25519_public(ed25519_pk: bytes) -> bytes:
    """
    Convert Ed25519 public key to X25519 public key.

    Args:
        ed25519_pk: 32-byte Ed25519 public key.

    Returns:
        32-byte X25519 public key.

    Raises:
        InvalidKeyError: If conversion fails.
    """
    if len(ed25519_pk) != ED25519_PUBLIC_KEY_LEN:
        raise InvalidKeyError(f"Invalid Ed25519 public key length: {len(ed25519_pk)}")

    try:
        return crypto_sign_ed25519_pk_to_curve25519(ed25519_pk)
    except Exception as e:
        raise InvalidKeyError(f"Ed25519 to X25519 conversion failed: {e}") from e


def ed25519_to_x25519_secret(ed25519_sk: bytes) -> bytes:
    """
    Convert Ed25519 secret key to X25519 secret key.

    Args:
        ed25519_sk: 64-byte Ed25519 secret key.

    Returns:
        32-byte X25519 secret key.

    Raises:
        InvalidKeyError: If conversion fails.
    """
    if len(ed25519_sk) != ED25519_SECRET_KEY_LEN:
        raise InvalidKeyError(f"Invalid Ed25519 secret key length: {len(ed25519_sk)}")

    try:
        return crypto_sign_ed25519_sk_to_curve25519(ed25519_sk)
    except Exception as e:
        raise InvalidKeyError(f"Ed25519 to X25519 conversion failed: {e}") from e
