"""
Symmetric encryption for pq-age using XChaCha20-Poly1305.

XChaCha20-Poly1305 provides:
- 256-bit key security
- 192-bit nonce (safe for random generation)
- Authentication via Poly1305 MAC
"""

import logging
from os import urandom

from nacl.bindings import (
    crypto_aead_xchacha20poly1305_ietf_decrypt,
    crypto_aead_xchacha20poly1305_ietf_encrypt,
)

from pqage.constants import (
    XCHACHA20_KEY_LEN,
    XCHACHA20_NONCE_LEN,
)
from pqage.exceptions import (
    DecryptionError,
    EncryptionError,
    InvalidCiphertextError,
)

logger = logging.getLogger(__name__)


def encrypt(data: bytes, key: bytes, aad: bytes = b"") -> bytes:
    """
    Encrypt data using XChaCha20-Poly1305 AEAD.

    Args:
        data: Plaintext data to encrypt.
        key: 32-byte encryption key.
        aad: Additional authenticated data (not encrypted, but authenticated).

    Returns:
        Encrypted blob: nonce (24 bytes) + ciphertext + tag (16 bytes).

    Raises:
        EncryptionError: If encryption fails or key is invalid.
    """
    if len(key) != XCHACHA20_KEY_LEN:
        raise EncryptionError(f"Key must be {XCHACHA20_KEY_LEN} bytes, got {len(key)}")

    try:
        nonce = urandom(XCHACHA20_NONCE_LEN)
        ciphertext = crypto_aead_xchacha20poly1305_ietf_encrypt(data, aad, nonce, key)
        return nonce + ciphertext

    except Exception as e:
        logger.error("Encryption failed: %s", e)
        raise EncryptionError(f"Encryption failed: {e}") from e


def decrypt(blob: bytes, key: bytes, aad: bytes = b"") -> bytes:
    """
    Decrypt data using XChaCha20-Poly1305 AEAD.

    Args:
        blob: Encrypted blob (nonce + ciphertext + tag).
        key: 32-byte decryption key.
        aad: Additional authenticated data (must match encryption AAD).

    Returns:
        Decrypted plaintext.

    Raises:
        InvalidCiphertextError: If blob is too short.
        DecryptionError: If decryption or MAC verification fails.
    """
    if len(key) != XCHACHA20_KEY_LEN:
        raise DecryptionError(f"Key must be {XCHACHA20_KEY_LEN} bytes, got {len(key)}")

    # Minimum: nonce (24) + tag (16) = 40 bytes
    min_len = XCHACHA20_NONCE_LEN + 16
    if len(blob) < min_len:
        raise InvalidCiphertextError(f"Ciphertext too short: {len(blob)} bytes (minimum {min_len})")

    nonce = blob[:XCHACHA20_NONCE_LEN]
    ciphertext = blob[XCHACHA20_NONCE_LEN:]

    try:
        plaintext = crypto_aead_xchacha20poly1305_ietf_decrypt(ciphertext, aad, nonce, key)

        if plaintext is None:
            raise DecryptionError("MAC verification failed - data corrupted or tampered")

        return plaintext

    except DecryptionError:
        raise
    except Exception as e:
        logger.error("Decryption failed: %s", e)
        raise DecryptionError(f"Decryption failed: {e}") from e
