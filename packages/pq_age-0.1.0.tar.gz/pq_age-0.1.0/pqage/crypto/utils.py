"""
Cryptographic utility functions for pq-age.

Provides constant-time operations and secure memory handling
to prevent timing attacks and memory disclosure.

Security Notes:
    1. Uses native Rust extension (zeroize) when available for guaranteed
       compiler-resistant memory wiping. Falls back to Python implementation.

    2. PRODUCTION WARNING: The Python fallback implementation CANNOT guarantee
       that secrets are actually wiped from memory. CPython may:
       - Optimize away repeated assignments
       - Keep copies in internal buffers
       - Not immediately release memory to the OS

       For production security requirements (banking, healthcare, government),
       the native Rust extension MUST be installed:
           pip install pqage[native]

    3. Even with the native extension, Python's immutable `bytes` objects
       cannot be securely wiped. Always use `bytearray` for secrets and
       convert to `bytes` only at the point of use.
"""

import hmac
import logging

logger = logging.getLogger(__name__)

# Try to import native secure wipe function
_native_wipe = None
try:
    from pqage.crypto._native import secure_wipe_buffer as _native_wipe
except ImportError:
    logger.debug("Native extension not available, using Python fallback for secure_wipe")


def secure_compare(a: bytes, b: bytes) -> bool:
    """
    Constant-time comparison of two byte strings.

    Prevents timing attacks by always comparing all bytes,
    regardless of where the first difference occurs.

    Args:
        a: First byte string to compare.
        b: Second byte string to compare.

    Returns:
        True if both byte strings are identical, False otherwise.
    """
    if not isinstance(a, bytes) or not isinstance(b, bytes):
        logger.warning("secure_compare called with non-bytes types")
        return False

    return hmac.compare_digest(a, b)


def secure_starts_with(data: bytes, prefix: bytes) -> bool:
    """
    Constant-time prefix check for byte strings.

    Prevents timing attacks by always performing the same operations
    regardless of data length. Length information is not leaked through
    early branching.

    Args:
        data: Data to check prefix of.
        prefix: Expected prefix.

    Returns:
        True if data starts with prefix, False otherwise.
    """
    # Empty prefix always matches
    if len(prefix) == 0:
        return True

    check_len = len(prefix)

    # Always pad data to at least prefix length to avoid length-dependent branching
    # This prevents timing attacks that could leak length information
    padded = (data + bytes(check_len))[:check_len]

    # Perform constant-time comparison
    result = hmac.compare_digest(padded, prefix)

    # Only return True if original data was long enough AND content matches
    # The length check is performed after the comparison to maintain constant time
    return result and len(data) >= check_len


def secure_wipe(data: bytearray | memoryview | list) -> None:
    """
    Securely wipe sensitive data from memory.

    Uses native Rust extension (zeroize) when available for guaranteed
    compiler-resistant wiping. Falls back to Python implementation.

    Args:
        data: Mutable container to wipe. Must be bytearray, memoryview,
              or list of integers.

    Warning:
        Does NOT work with immutable bytes objects - they cannot be
        modified in place. Convert to bytearray first if needed.
    """
    if data is None:
        return

    if isinstance(data, bytes):
        logger.warning(
            "secure_wipe called with immutable bytes - cannot wipe! "
            "Convert to bytearray before use."
        )
        return

    # Use native extension if available (guaranteed compiler-resistant wiping)
    if _native_wipe is not None and isinstance(data, bytearray):
        try:
            _native_wipe(data)
            return
        except Exception as e:
            logger.warning("Native secure_wipe failed, using fallback: %s", e)

    # Python fallback implementation
    try:
        length = len(data)

        # Overwrite with zeros
        for i in range(length):
            data[i] = 0

        # Additional overwrite pass with different pattern (defense in depth)
        for i in range(length):
            data[i] = 0xFF

        # Final zero pass
        for i in range(length):
            data[i] = 0

    except (TypeError, IndexError) as e:
        logger.warning("secure_wipe failed: %s", e)


def secure_wipe_multiple(*args: bytearray | memoryview | list | None) -> None:
    """
    Securely wipe multiple data containers.

    Args:
        *args: Variable number of mutable containers to wipe.
               None values are safely skipped.
    """
    for data in args:
        if data is not None:
            secure_wipe(data)


class SecureBytes:
    """
    Context manager for secure handling of sensitive byte data.

    Automatically wipes the data when exiting the context,
    even if an exception occurs.

    Example:
        with SecureBytes(bytearray(32)) as secret:
            # Use secret...
            pass
        # secret is automatically wiped here
    """

    def __init__(self, data: bytes | bytearray) -> None:
        """
        Initialize with sensitive data.

        Args:
            data: Sensitive data to protect. Converted to bytearray internally.
        """
        self._data = bytearray(data) if isinstance(data, bytes) else data
        self._wiped = False

    def __enter__(self) -> bytearray:
        """Return the protected data for use within context."""
        return self._data

    def __exit__(self, exc_type: type, exc_val: Exception, exc_tb: object) -> None:
        """Wipe data on context exit."""
        self.wipe()

    def wipe(self) -> None:
        """Manually wipe the data."""
        if not self._wiped:
            secure_wipe(self._data)
            self._wiped = True

    @property
    def data(self) -> bytearray:
        """Access the protected data."""
        if self._wiped:
            raise ValueError("Data has been wiped")
        return self._data

    def __bytes__(self) -> bytes:
        """Convert to immutable bytes (use with caution)."""
        if self._wiped:
            raise ValueError("Data has been wiped")
        return bytes(self._data)
