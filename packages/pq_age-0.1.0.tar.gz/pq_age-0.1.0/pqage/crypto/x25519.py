"""
X25519 key operations for pq-age.

Provides centralized X25519 scalar clamping and ephemeral key generation
per RFC 7748 Section 5.

Security:
    - Clamping ensures scalars are in the correct form for X25519
    - Ephemeral keys use OS urandom for cryptographic randomness
    - Secret keys returned as bytearray for secure wiping
"""

import logging
from os import urandom

from nacl.bindings import crypto_scalarmult_base

from pqage.constants import (
    X25519_CLAMP_FIRST_BYTE,
    X25519_CLAMP_LAST_BYTE_AND,
    X25519_CLAMP_LAST_BYTE_OR,
    X25519_SCALAR_LEN,
)

logger = logging.getLogger(__name__)


def clamp_scalar(sk: bytearray) -> None:
    """
    Apply X25519 scalar clamping in-place (RFC 7748 Section 5).

    Clamping ensures the scalar is in the correct form:
    - Clear bits 0-2 of first byte (scalar divisible by 8)
    - Clear bit 7 of last byte (scalar < 2^255)
    - Set bit 6 of last byte (scalar >= 2^254)

    Args:
        sk: 32-byte scalar as mutable bytearray (modified in-place).

    Raises:
        ValueError: If scalar is not 32 bytes.
    """
    if len(sk) != X25519_SCALAR_LEN:
        raise ValueError(f"X25519 scalar must be {X25519_SCALAR_LEN} bytes, got {len(sk)}")

    sk[0] &= X25519_CLAMP_FIRST_BYTE
    sk[31] &= X25519_CLAMP_LAST_BYTE_AND
    sk[31] |= X25519_CLAMP_LAST_BYTE_OR


def generate_ephemeral() -> tuple[bytes, bytearray]:
    """
    Generate ephemeral X25519 keypair with proper clamping.

    Returns:
        Tuple of (public_key, secret_key):
        - public_key: 32-byte X25519 public key (bytes, not secret)
        - secret_key: 32-byte clamped scalar (bytearray, caller must wipe)

    Security:
        The returned secret_key is a bytearray that MUST be wiped
        by the caller after use using secure_wipe().
    """
    # Generate random scalar as mutable bytearray
    eph_sk = bytearray(urandom(X25519_SCALAR_LEN))

    # Apply RFC 7748 clamping
    clamp_scalar(eph_sk)

    # Compute public key
    eph_pk = crypto_scalarmult_base(bytes(eph_sk))

    return eph_pk, eph_sk
