"""
Custom exceptions for pq-age encryption system.

All exceptions inherit from PqageError for easy catching.
Each exception provides detailed error messages for debugging.
"""


class PqageError(Exception):
    """Base exception for all pq-age errors."""

    pass


class KeyGenerationError(PqageError):
    """Raised when key generation fails."""

    pass


class InvalidKeyError(PqageError):
    """Raised when a key has invalid format or length."""

    pass


class EncapsulationError(PqageError):
    """Raised when KEM encapsulation fails."""

    pass


class DecapsulationError(PqageError):
    """Raised when KEM decapsulation fails."""

    pass


class EncryptionError(PqageError):
    """Raised when symmetric encryption fails."""

    pass


class DecryptionError(PqageError):
    """Raised when symmetric decryption fails (e.g., MAC verification)."""

    pass


class InvalidCapsuleError(PqageError):
    """Raised when capsule has invalid format or length."""

    pass


class InvalidCiphertextError(PqageError):
    """Raised when ciphertext is malformed or too short."""

    pass


class InvalidFileError(PqageError):
    """Raised when file format is invalid or not a pq-age file."""

    pass


class PasswordError(PqageError):
    """Raised when password operations fail (wrong password, etc.)."""

    pass


class KeyWrappingError(PqageError):
    """Raised when key wrapping/unwrapping fails."""

    pass
