"""
Tests for age-compatible CLI.

Tests age_cli.py: keygen, encrypt, decrypt commands with age compatibility.
"""

import base64
import subprocess
import sys
from pathlib import Path

import pytest

from pqage.age_cli import (
    PQAGE_PUBLIC_KEY_PREFIX,
    PQAGE_SECRET_KEY_PREFIX,
    parse_hybrid_public_key,
    parse_hybrid_secret_key,
    serialize_hybrid_public_key,
    serialize_hybrid_secret_key,
)
from pqage.crypto.keys import generate_keys


class TestHybridKeySerialization:
    """Test hybrid key serialization/deserialization."""

    def test_serialize_hybrid_public_key(self) -> None:
        """Test hybrid public key serialization."""
        # Use real keys from generate_keys (TypedDict format)
        keys = generate_keys()

        serialized = serialize_hybrid_public_key(keys)

        assert serialized.startswith(PQAGE_PUBLIC_KEY_PREFIX)
        assert len(serialized) > len(PQAGE_PUBLIC_KEY_PREFIX)

        # Should be parseable
        x25519_pk, mlkem_pk = parse_hybrid_public_key(serialized)
        assert x25519_pk == keys["x25519_pk"]
        assert mlkem_pk == keys["kyber_pk"]

    def test_serialize_hybrid_secret_key(self) -> None:
        """Test hybrid secret key serialization."""
        # Use real keys from generate_keys (TypedDict format)
        keys = generate_keys()

        serialized = serialize_hybrid_secret_key(keys)

        assert serialized.startswith(PQAGE_SECRET_KEY_PREFIX)
        assert len(serialized) > len(PQAGE_SECRET_KEY_PREFIX)

        # Should be parseable back to key bundle
        parsed_keys = parse_hybrid_secret_key(serialized)
        assert parsed_keys["master_seed"] == keys["master_seed"]

    def test_parse_hybrid_public_key_invalid(self) -> None:
        """Test parsing invalid hybrid public key."""
        with pytest.raises(ValueError, match="Invalid base64"):
            parse_hybrid_public_key("age1pq-invalid!!!")

        with pytest.raises(ValueError, match="Invalid hybrid public key length"):
            # Valid base64, but too short
            valid_b64 = base64.b64encode(b"A" * 10).decode()
            parse_hybrid_public_key(f"age1pq{valid_b64}")

    def test_parse_hybrid_secret_key_invalid(self) -> None:
        """Test parsing invalid hybrid secret key."""
        with pytest.raises(ValueError, match="Invalid secret key format"):
            parse_hybrid_secret_key("invalid-format")

        with pytest.raises(ValueError, match="Invalid base64"):
            parse_hybrid_secret_key("AGE-SECRET-KEY-PQ-invalid!!!")


class TestKeygenCommand:
    """Test pqage-keygen command (using keygen_main)."""

    def test_keygen_basic(self, tmp_path) -> None:
        """Test basic keygen command via keygen_main."""
        output_file = tmp_path / "identity.txt"

        # keygen_main is called via running it as a script
        result = subprocess.run(
            [
                sys.executable,
                "-c",
                f"import sys; sys.argv = ['pqage-keygen', '-o', '{output_file}']; "
                f"from pqage.age_cli import keygen_main; exit(keygen_main())",
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )

        assert result.returncode == 0, f"stdout: {result.stdout}, stderr: {result.stderr}"
        assert output_file.exists()

        content = output_file.read_text()
        assert PQAGE_SECRET_KEY_PREFIX in content
        assert "public key:" in content

    def test_keygen_stdout_only(self) -> None:
        """Test keygen without output file."""
        result = subprocess.run(
            [
                sys.executable,
                "-c",
                "import sys; sys.argv = ['pqage-keygen']; "
                "from pqage.age_cli import keygen_main; exit(keygen_main())",
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )

        assert result.returncode == 0, f"stdout: {result.stdout}, stderr: {result.stderr}"
        assert PQAGE_SECRET_KEY_PREFIX in result.stdout
        assert "public key:" in result.stdout

    def test_keygen_overwrite_protection(self, tmp_path) -> None:
        """Test keygen refuses to overwrite existing file."""
        output_file = tmp_path / "existing.txt"
        output_file.write_text("existing content")

        result = subprocess.run(
            [
                sys.executable,
                "-c",
                f"import sys; sys.argv = ['pqage-keygen', '-o', '{output_file}']; "
                f"from pqage.age_cli import keygen_main; exit(keygen_main())",
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )

        assert result.returncode == 1
        assert "already exists" in result.stdout

    def test_keygen_force_overwrite(self, tmp_path) -> None:
        """Test keygen with force overwrite."""
        output_file = tmp_path / "existing.txt"
        output_file.write_text("existing content")

        result = subprocess.run(
            [
                sys.executable,
                "-c",
                f"import sys; sys.argv = ['pqage-keygen', '-o', '{output_file}', '-f']; "
                f"from pqage.age_cli import keygen_main; exit(keygen_main())",
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )

        assert result.returncode == 0, f"stdout: {result.stdout}, stderr: {result.stderr}"
        assert output_file.exists()

        content = output_file.read_text()
        assert content != "existing content"  # Should be overwritten


class TestEncryptDecryptCommands:
    """Test encrypt/decrypt commands."""

    def test_encrypt_decrypt_roundtrip(self, tmp_path) -> None:
        """Test full encrypt/decrypt roundtrip via CLI."""
        input_file = tmp_path / "input.txt"
        input_file.write_bytes(b"Test content for roundtrip")
        identity_file = tmp_path / "identity.txt"

        # Generate keys via keygen_main
        keygen_result = subprocess.run(
            [
                sys.executable,
                "-c",
                f"import sys; sys.argv = ['pqage-keygen', '-o', '{identity_file}']; "
                f"from pqage.age_cli import keygen_main; exit(keygen_main())",
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        assert keygen_result.returncode == 0, f"keygen failed: {keygen_result.stdout}"

        # Extract public key from keygen output
        pubkey_line = [line for line in keygen_result.stdout.split("\n") if "Public key:" in line][
            0
        ]
        pubkey = pubkey_line.split(":", 1)[1].strip()

        # Encrypt
        encrypt_result = subprocess.run(
            [
                sys.executable,
                "-m",
                "pqage.age_cli",
                "-e",
                "-r",
                pubkey,
                "-o",
                str(tmp_path / "encrypted.age"),
                str(input_file),
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        assert encrypt_result.returncode == 0, f"encrypt failed: {encrypt_result.stdout}"

        # Decrypt
        decrypt_result = subprocess.run(
            [
                sys.executable,
                "-m",
                "pqage.age_cli",
                "-d",
                "-i",
                str(identity_file),
                "-o",
                str(tmp_path / "decrypted.txt"),
                str(tmp_path / "encrypted.age"),
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        assert decrypt_result.returncode == 0, f"decrypt failed: {decrypt_result.stdout}"

        # Verify content
        decrypted = (tmp_path / "decrypted.txt").read_bytes()
        assert decrypted == b"Test content for roundtrip"

    def test_encrypt_with_ssh_key(self, tmp_path) -> None:
        """Test encrypt with nonexistent SSH key recipient."""
        input_file = tmp_path / "input.txt"
        input_file.write_bytes(b"test")

        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "pqage.age_cli",
                "-e",
                "-R",
                "/nonexistent/ssh/key.pub",
                str(input_file),
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )

        # Should fail because SSH key doesn't exist
        assert result.returncode == 1
        assert "not found" in result.stdout

    @pytest.mark.skip(reason="Interactive password input not suitable for automated tests")
    def test_encrypt_with_password(self, tmp_path) -> None:
        """Test encrypt with password - skipped in CI."""
        pass

    def test_encrypt_no_recipients(self, tmp_path) -> None:
        """Test encrypt command with no recipients."""
        input_file = tmp_path / "input.txt"
        input_file.write_bytes(b"test")

        result = subprocess.run(
            [sys.executable, "-m", "pqage.age_cli", "-e", str(input_file)],
            capture_output=True,
            text=True,
            timeout=10,
        )

        assert result.returncode == 1
        assert "No recipients specified" in result.stdout

    def test_decrypt_no_file(self) -> None:
        """Test decrypt command with no input file."""
        result = subprocess.run(
            [sys.executable, "-m", "pqage.age_cli", "-d"],
            capture_output=True,
            text=True,
            timeout=10,
        )

        assert result.returncode == 1
        assert "Input file required" in result.stdout

    def test_encrypt_invalid_recipient_key(self, tmp_path) -> None:
        """Test encrypt with invalid recipient key."""
        input_file = tmp_path / "input.txt"
        input_file.write_bytes(b"test")

        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "pqage.age_cli",
                "-e",
                "-r",
                "invalid-key-format",
                str(input_file),
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )

        assert result.returncode == 1
        assert "Unknown key format" in result.stdout or "Invalid recipient" in result.stdout

    def test_encrypt_armor_output(self, tmp_path) -> None:
        """Test encrypt with ASCII armor output."""
        input_file = tmp_path / "input.txt"
        input_file.write_bytes(b"Test armor output")
        identity_file = tmp_path / "identity.txt"

        # Generate keys via keygen_main
        keygen_result = subprocess.run(
            [
                sys.executable,
                "-c",
                f"import sys; sys.argv = ['pqage-keygen', '-o', '{identity_file}']; "
                f"from pqage.age_cli import keygen_main; exit(keygen_main())",
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        assert keygen_result.returncode == 0, f"keygen failed: {keygen_result.stdout}"

        # Extract public key
        pubkey_line = [line for line in keygen_result.stdout.split("\n") if "Public key:" in line][
            0
        ]
        pubkey = pubkey_line.split(":", 1)[1].strip()

        # Encrypt with armor
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "pqage.age_cli",
                "-e",
                "-r",
                pubkey,
                "-a",
                "-o",
                str(tmp_path / "encrypted.age"),
                str(input_file),
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )

        assert result.returncode == 0, f"encrypt failed: {result.stdout}"
        # Should create .age file with armor content
        encrypted_file = tmp_path / "encrypted.age"
        assert encrypted_file.exists()

        # Check armor format
        content = encrypted_file.read_text()
        assert "-----BEGIN AGE ENCRYPTED FILE-----" in content
        assert "-----END AGE ENCRYPTED FILE-----" in content


class TestIdentityFileParsing:
    """Test identity file parsing."""

    def test_load_identity_file_hybrid(self, tmp_path) -> None:
        """Test loading hybrid identity file."""
        identity_file = tmp_path / "identity.txt"

        # Create valid base64 for 32 bytes (44 chars including padding)
        mock_secret_data = b"A" * 32
        mock_secret_b64 = base64.b64encode(mock_secret_data).decode("ascii")
        mock_secret = f"AGE-SECRET-KEY-PQ-{mock_secret_b64}"
        identity_file.write_text(f"# comment\n{mock_secret}\n")

        from pqage.age_cli import load_identity_file

        identities = load_identity_file(str(identity_file))

        assert len(identities) == 1
        assert identities[0] is not None  # Should be SecureKeyBundle
        assert identities[0]["master_seed"] == mock_secret_data

    def test_load_identity_file_ssh(self) -> None:
        """Test loading SSH identity file (placeholder)."""
        # This would require actual SSH keys, just test the parsing logic exists
        pass


class TestCommandLineInterface:
    """Test CLI interface and argument parsing."""

    def test_main_encrypt_mode(self) -> None:
        """Test main function in encrypt mode."""
        result = subprocess.run(
            [sys.executable, "-m", "pqage.age_cli", "-e", "--help"],
            capture_output=True,
            text=True,
            timeout=10,
        )

        # Should show help or error about missing file
        assert result.returncode != 0 or "usage:" in result.stdout

    def test_main_decrypt_mode(self) -> None:
        """Test main function in decrypt mode."""
        result = subprocess.run(
            [sys.executable, "-m", "pqage.age_cli", "-d", "--help"],
            capture_output=True,
            text=True,
            timeout=10,
        )

        # Should show help or error
        assert result.returncode != 0 or "usage:" in result.stdout

    def test_main_keygen_mode(self) -> None:
        """Test main function in keygen mode."""
        result = subprocess.run(
            [sys.executable, "-m", "pqage.age_cli", "keygen", "--help"],
            capture_output=True,
            text=True,
            timeout=10,
        )

        # Should show help
        assert "usage:" in result.stdout or result.returncode == 0

    def test_verbose_flag(self) -> None:
        """Test verbose flag sets up logging."""
        result = subprocess.run(
            [sys.executable, "-m", "pqage.age_cli", "-v", "-e", "/nonexistent"],
            capture_output=True,
            text=True,
            timeout=10,
        )

        # Should fail but verbose logging should be enabled
        assert result.returncode != 0


class TestKeygenMain:
    """Test keygen_main function."""

    def test_keygen_main_basic(self, tmp_path) -> None:
        """Test keygen_main function."""
        output_file = tmp_path / "keygen_output.txt"

        result = subprocess.run(
            [
                sys.executable,
                "-c",
                f"import sys; sys.argv = ['pqage-keygen', '-o', '{output_file}']; "
                f"from pqage.age_cli import keygen_main; exit(keygen_main())",
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )

        assert result.returncode == 0, f"stdout: {result.stdout}, stderr: {result.stderr}"
        assert output_file.exists()
