"""
Tests for age-compatible file operations.

Tests age_file_ops.py: encrypt/decrypt functions, recipient classes, armor.
"""

import os
import tempfile

import pytest

from pqage.age_file_ops import (
    AGE_FILE_EXTENSION,
    ARMOR_BEGIN,
    ARMOR_END,
    ARMOR_FILE_EXTENSION,
    MlkemX25519Identity,
    MlkemX25519Recipient,
    ScryptIdentity,
    ScryptRecipient,
    SshEd25519Identity,
    SshEd25519Recipient,
    X25519Identity,
    X25519Recipient,
    _armor_decode,
    _armor_encode,
    _is_armored,
    create_mlkem_x25519_identity_from_keys,
    create_mlkem_x25519_recipient_from_keys,
    decrypt,
    decrypt_file,
    encrypt,
    encrypt_file,
)
from pqage.exceptions import DecryptionError, EncryptionError, InvalidFileError


class TestRecipientClasses:
    """Test recipient class creation and validation."""

    def test_x25519_recipient_creation(self) -> None:
        """Test X25519Recipient creation."""
        pk = os.urandom(32)
        recipient = X25519Recipient(pk)

        assert recipient.public_key == pk

    def test_x25519_recipient_invalid_key(self) -> None:
        """Test X25519Recipient with invalid key."""
        with pytest.raises(ValueError, match="X25519 public key must be 32 bytes"):
            X25519Recipient(b"wrong_length")

    def test_ssh_ed25519_recipient_creation(self) -> None:
        """Test SshEd25519Recipient creation."""
        from nacl.signing import SigningKey

        from pqage.crypto.ssh import SshEd25519PublicKey

        # Generate a valid Ed25519 keypair
        seed = bytes.fromhex("9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60")
        signing_key = SigningKey(seed)
        ed25519_pk = bytes(signing_key.verify_key)
        ssh_key = SshEd25519PublicKey.from_ed25519(ed25519_pk)

        recipient = SshEd25519Recipient(ssh_key)
        assert recipient.ssh_key == ssh_key

    def test_mlkem_x25519_recipient_creation(self) -> None:
        """Test MlkemX25519Recipient creation."""
        mlkem_pk = b"M" * 1568
        x25519_pk = os.urandom(32)

        recipient = MlkemX25519Recipient(mlkem_pk, x25519_pk)
        assert recipient.mlkem_pk == mlkem_pk
        assert recipient.x25519_pk == x25519_pk

    def test_mlkem_x25519_recipient_invalid_keys(self) -> None:
        """Test MlkemX25519Recipient with invalid keys."""
        with pytest.raises(ValueError, match="ML-KEM public key must be 1568 bytes"):
            MlkemX25519Recipient(b"wrong", os.urandom(32))

        with pytest.raises(ValueError, match="X25519 public key must be 32 bytes"):
            MlkemX25519Recipient(b"M" * 1568, b"wrong")

    def test_scrypt_recipient_creation(self) -> None:
        """Test ScryptRecipient creation."""
        password = "test_password"
        recipient = ScryptRecipient(password)

        assert recipient.password == password
        assert recipient.work_factor == 18  # Default

    def test_scrypt_recipient_custom_work_factor(self) -> None:
        """Test ScryptRecipient with custom work factor."""
        password = "test_password"
        work_factor = 15
        recipient = ScryptRecipient(password, work_factor)

        assert recipient.password == password
        assert recipient.work_factor == work_factor


class TestIdentityClasses:
    """Test identity class creation and validation."""

    def test_x25519_identity_creation(self) -> None:
        """Test X25519Identity creation."""
        sk = os.urandom(32)
        pk = os.urandom(32)

        identity = X25519Identity(sk, pk)
        assert identity.secret_key == sk
        assert identity.public_key == pk

    def test_ssh_ed25519_identity_creation(self) -> None:
        """Test SshEd25519Identity creation."""
        from nacl.signing import SigningKey

        from pqage.crypto.ssh import SshEd25519PrivateKey

        # Generate a valid Ed25519 keypair
        seed = bytes.fromhex("9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60")
        signing_key = SigningKey(seed)
        ed25519_pk = bytes(signing_key.verify_key)
        # Full Ed25519 secret key is seed + public key (64 bytes)
        ed25519_sk = seed + ed25519_pk

        ssh_key = SshEd25519PrivateKey.from_ed25519(ed25519_sk, ed25519_pk)

        identity = SshEd25519Identity(ssh_key)
        assert identity.ssh_key == ssh_key

    def test_mlkem_x25519_identity_creation(self) -> None:
        """Test MlkemX25519Identity creation."""
        mlkem_sk = b"S" * 3168
        x25519_sk = os.urandom(32)
        mlkem_pk = b"M" * 1568
        x25519_pk = os.urandom(32)

        identity = MlkemX25519Identity(mlkem_sk, x25519_sk, mlkem_pk, x25519_pk)
        assert identity.mlkem_sk == mlkem_sk
        assert identity.x25519_sk == x25519_sk
        assert identity.mlkem_pk == mlkem_pk
        assert identity.x25519_pk == x25519_pk

    def test_scrypt_identity_creation(self) -> None:
        """Test ScryptIdentity creation."""
        password = "test_password"
        identity = ScryptIdentity(password)

        assert identity.password == password


class TestEncryptDecryptBytes:
    """Test bytes-based encrypt/decrypt operations."""

    def test_encrypt_decrypt_single_recipient(self) -> None:
        """Test encrypt/decrypt with single X25519 recipient."""
        from nacl.bindings import crypto_scalarmult_base

        # Create recipient keys
        sk = os.urandom(32)
        sk_clamped = bytearray(sk)
        sk_clamped[0] &= 248
        sk_clamped[31] &= 127
        sk_clamped[31] |= 64
        sk = bytes(sk_clamped)
        pk = crypto_scalarmult_base(sk)

        # Create identity
        identity = X25519Identity(sk, pk)
        recipient = X25519Recipient(pk)

        plaintext = b"Hello, world! This is a test message."

        # Encrypt
        ciphertext = encrypt(plaintext, [recipient])

        # Decrypt
        decrypted = decrypt(ciphertext, [identity])

        assert decrypted == plaintext

    def test_encrypt_decrypt_multiple_recipients(self) -> None:
        """Test encrypt/decrypt with multiple recipients."""
        from nacl.bindings import crypto_scalarmult_base

        # Create two recipients
        recipients = []
        identities = []

        for _ in range(2):
            sk = os.urandom(32)
            sk_clamped = bytearray(sk)
            sk_clamped[0] &= 248
            sk_clamped[31] &= 127
            sk_clamped[31] |= 64
            sk = bytes(sk_clamped)
            pk = crypto_scalarmult_base(sk)

            recipients.append(X25519Recipient(pk))
            identities.append(X25519Identity(sk, pk))

        plaintext = b"Message for multiple recipients"

        # Encrypt (can be decrypted by any recipient)
        ciphertext = encrypt(plaintext, recipients)

        # Try decrypting with first identity
        decrypted1 = decrypt(ciphertext, [identities[0]])
        assert decrypted1 == plaintext

        # Try decrypting with second identity
        decrypted2 = decrypt(ciphertext, [identities[1]])
        assert decrypted2 == plaintext

    def test_encrypt_decrypt_scrypt_password(self) -> None:
        """Test encrypt/decrypt with scrypt password."""
        password = "test_password_123"
        # Use work_factor=12 for testing (default 18 exceeds memory limits in CI)
        recipient = ScryptRecipient(password, work_factor=12)
        identity = ScryptIdentity(password)

        plaintext = b"Password-protected message"

        # Encrypt
        ciphertext = encrypt(plaintext, [recipient])

        # Decrypt
        decrypted = decrypt(ciphertext, [identity])

        assert decrypted == plaintext

    def test_encrypt_no_recipients_error(self) -> None:
        """Test encrypt with no recipients fails."""
        plaintext = b"test"

        with pytest.raises(EncryptionError, match="At least one recipient required"):
            encrypt(plaintext, [])

    def test_decrypt_no_identities_error(self) -> None:
        """Test decrypt with no identities fails."""
        ciphertext = b"invalid"

        with pytest.raises(DecryptionError, match="At least one identity required"):
            decrypt(ciphertext, [])

    def test_decrypt_invalid_data(self) -> None:
        """Test decrypt with invalid data."""
        identity = ScryptIdentity("password")

        with pytest.raises(InvalidFileError, match="Not an age-encrypted file"):
            decrypt(b"not age data", [identity])

    def test_decrypt_wrong_key(self) -> None:
        """Test decrypt with wrong key fails."""
        # Encrypt with one password (use work_factor=12 for testing)
        recipient = ScryptRecipient("correct_password", work_factor=12)
        plaintext = b"secret"
        ciphertext = encrypt(plaintext, [recipient])

        # Try to decrypt with wrong password
        wrong_identity = ScryptIdentity("wrong_password")

        with pytest.raises(DecryptionError, match="No matching identity found"):
            decrypt(ciphertext, [wrong_identity])


class TestEncryptDecryptFiles:
    """Test file-based encrypt/decrypt operations."""

    def test_encrypt_decrypt_file_roundtrip(self, tmp_path) -> None:
        """Test file encrypt/decrypt roundtrip."""
        from nacl.bindings import crypto_scalarmult_base

        # Create test files
        input_file = tmp_path / "input.txt"
        output_file = tmp_path / "output.txt"
        input_file.write_bytes(b"Test file content for encryption")

        # Create keys
        sk = os.urandom(32)
        sk_clamped = bytearray(sk)
        sk_clamped[0] &= 248
        sk_clamped[31] &= 127
        sk_clamped[31] |= 64
        sk = bytes(sk_clamped)
        pk = crypto_scalarmult_base(sk)

        recipient = X25519Recipient(pk)
        identity = X25519Identity(sk, pk)

        # Encrypt
        encrypted_path = encrypt_file(str(input_file), [recipient])
        assert encrypted_path.endswith(AGE_FILE_EXTENSION)

        # Decrypt
        decrypted_path = decrypt_file(encrypted_path, [identity], str(output_file))

        # Verify content
        assert output_file.read_bytes() == input_file.read_bytes()

    def test_encrypt_decrypt_file_with_armor(self, tmp_path) -> None:
        """Test file encrypt/decrypt with ASCII armor."""
        input_file = tmp_path / "input.txt"
        input_file.write_bytes(b"Test armored file content")

        # Create keys
        from nacl.bindings import crypto_scalarmult_base

        sk = os.urandom(32)
        sk_clamped = bytearray(sk)
        sk_clamped[0] &= 248
        sk_clamped[31] &= 127
        sk_clamped[31] |= 64
        sk = bytes(sk_clamped)
        pk = crypto_scalarmult_base(sk)

        recipient = X25519Recipient(pk)
        identity = X25519Identity(sk, pk)

        # Encrypt with armor
        encrypted_path = encrypt_file(str(input_file), [recipient], armor=True)
        assert encrypted_path.endswith(ARMOR_FILE_EXTENSION)

        # Verify it's armored
        with open(encrypted_path) as f:
            content = f.read()
            assert ARMOR_BEGIN in content
            assert ARMOR_END in content

        # Decrypt armored file
        output_file = tmp_path / "output.txt"
        decrypted_path = decrypt_file(encrypted_path, [identity], str(output_file))

        assert output_file.read_bytes() == input_file.read_bytes()

    def test_encrypt_file_nonexistent_input(self, tmp_path) -> None:
        """Test encrypt with nonexistent input file."""
        recipient = ScryptRecipient("password")

        with pytest.raises(FileNotFoundError):
            encrypt_file("/nonexistent/file", [recipient])

    def test_decrypt_file_nonexistent_input(self, tmp_path) -> None:
        """Test decrypt with nonexistent input file."""
        identity = ScryptIdentity("password")

        with pytest.raises(FileNotFoundError):
            decrypt_file("/nonexistent/file.age", [identity])


class TestArmorFunctions:
    """Test ASCII armor encoding/decoding."""

    def test_armor_encode_decode_roundtrip(self) -> None:
        """Test armor encode/decode roundtrip."""
        data = b"Hello, world! This is test data for armor encoding.\x00\x01\x02"

        armored = _armor_encode(data)
        decoded = _armor_decode(armored)

        assert decoded == data

    def test_armor_encode_format(self) -> None:
        """Test armor encoding format."""
        data = b"test"

        armored = _armor_encode(data)

        assert armored.startswith(ARMOR_BEGIN + "\n")
        assert armored.endswith("\n" + ARMOR_END + "\n")
        assert "-----" in armored

    def test_armor_decode_invalid_format(self) -> None:
        """Test armor decode with invalid format."""
        with pytest.raises(InvalidFileError, match="Invalid armor format"):
            _armor_decode("invalid armor")

    def test_is_armored_detection(self) -> None:
        """Test armor detection."""
        valid_armor = ARMOR_BEGIN + "\ndata\n" + ARMOR_END
        invalid_armor = "not armored data"

        assert _is_armored(valid_armor.encode())
        assert not _is_armored(invalid_armor.encode())


class TestHelperFunctions:
    """Test helper functions."""

    def test_create_mlkem_x25519_recipient_from_keys(self) -> None:
        """Test creating ML-KEM+X25519 recipient from keys."""
        mlkem_pk = b"M" * 1568
        x25519_pk = os.urandom(32)

        recipient = create_mlkem_x25519_recipient_from_keys(x25519_pk, mlkem_pk)

        assert isinstance(recipient, MlkemX25519Recipient)
        assert recipient.x25519_pk == x25519_pk
        assert recipient.mlkem_pk == mlkem_pk

    def test_create_mlkem_x25519_identity_from_keys(self) -> None:
        """Test creating ML-KEM+X25519 identity from keys."""
        mlkem_sk = b"S" * 3168
        x25519_sk = os.urandom(32)
        mlkem_pk = b"M" * 1568
        x25519_pk = os.urandom(32)

        identity = create_mlkem_x25519_identity_from_keys(x25519_sk, x25519_pk, mlkem_sk, mlkem_pk)

        assert isinstance(identity, MlkemX25519Identity)
        assert identity.x25519_sk == x25519_sk
        assert identity.x25519_pk == x25519_pk
        assert identity.mlkem_sk == mlkem_sk
        assert identity.mlkem_pk == mlkem_pk


class TestFileExtensions:
    """Test file extension constants."""

    def test_file_extensions(self) -> None:
        """Test file extension constants."""
        assert AGE_FILE_EXTENSION == ".age"
        assert ARMOR_FILE_EXTENSION == ".asc"
