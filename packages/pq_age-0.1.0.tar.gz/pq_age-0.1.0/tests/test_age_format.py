"""
Tests for age v1 format parsing and serialization.

Tests age-format.py: Header parsing, stanzas, MAC verification.
"""

import base64

import pytest

from pqage.age_format import (
    AGE_HEADER_LINE,
    AgeHeader,
    MlkemX25519Stanza,
    ScryptStanza,
    SshEd25519Stanza,
    Stanza,
    X25519Stanza,
    age_b64encode,
    derive_file_key_wrapping_key,
    parse_age_file,
    unwrap_file_key,
    wrap_file_key,
)
from pqage.crypto.utils import secure_compare
from pqage.exceptions import DecryptionError, InvalidFileError


class TestStanza:
    """Test basic stanza parsing."""

    def test_x25519_stanza_parse(self) -> None:
        """Test X25519 stanza parsing."""
        # Use valid base64: "abc123def456" = YWJjMTIzZGVmNDU2
        # Ephemeral share arg doesn't get base64 decoded in Stanza.parse
        # Body line IS base64 decoded
        lines = [
            "-> X25519 YWJjMTIzZGVmNDU2",  # arg is base64-encoded ephemeral share
            "dGVzdGRhdGE=",  # base64("testdata")
        ]

        stanza, consumed = Stanza.parse(lines)
        assert consumed == 2
        assert stanza.stanza_type == "X25519"
        assert stanza.args == ["YWJjMTIzZGVmNDU2"]
        assert stanza.body == b"testdata"

    def test_scrypt_stanza_parse(self) -> None:
        """Test scrypt stanza parsing."""
        # Salt is base64-encoded in the arg
        lines = [
            "-> scrypt c2FsdDEyMzQ1Njc4 18",  # base64("salt12345678")
            "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=",  # 32 zero bytes
        ]

        stanza, consumed = Stanza.parse(lines)
        assert consumed == 2
        assert stanza.stanza_type == "scrypt"
        assert stanza.args == ["c2FsdDEyMzQ1Njc4", "18"]
        assert len(stanza.body) == 32

    def test_mlkem_x25519_stanza_parse(self) -> None:
        """Test mlkem-x25519 stanza parsing."""
        lines = [
            "-> mlkem-x25519 bWxrZW1fY2lwaGVydGV4dA== eDI1NTE5X2VwaGVtZXJhbA==",
            "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=",  # 32 zero bytes
        ]

        stanza, consumed = Stanza.parse(lines)
        assert consumed == 2
        assert stanza.stanza_type == "mlkem-x25519"
        assert stanza.args == ["bWxrZW1fY2lwaGVydGV4dA==", "eDI1NTE5X2VwaGVtZXJhbA=="]
        assert len(stanza.body) == 32

    def test_ssh_ed25519_stanza_parse(self) -> None:
        """Test ssh-ed25519 stanza parsing."""
        lines = [
            "-> ssh-ed25519 a2V5X2hhc2g= ZXBoZW1lcmFsX3NoYXJl",  # key_hash, ephemeral_share
            "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=",  # 32 zero bytes
        ]

        stanza, consumed = Stanza.parse(lines)
        assert consumed == 2
        assert stanza.stanza_type == "ssh-ed25519"
        assert stanza.args == ["a2V5X2hhc2g=", "ZXBoZW1lcmFsX3NoYXJl"]
        assert len(stanza.body) == 32

    def test_stanza_parse_empty_body(self) -> None:
        """Test stanza with empty body."""
        lines = [
            "-> X25519 abc123",
            "",
        ]

        stanza, consumed = Stanza.parse(lines)
        assert consumed == 2
        assert stanza.body == b""

    def test_stanza_parse_no_args(self) -> None:
        """Test stanza with no arguments."""
        lines = [
            "-> test-type",
            "ZGF0YQ==",  # base64("data")
        ]

        stanza, consumed = Stanza.parse(lines)
        assert consumed == 2
        assert stanza.stanza_type == "test-type"
        assert stanza.args == []
        assert stanza.body == b"data"

    def test_stanza_parse_invalid_header(self) -> None:
        """Test invalid stanza header."""
        lines = ["invalid header"]

        with pytest.raises(InvalidFileError, match="Invalid stanza header"):
            Stanza.parse(lines)

    def test_stanza_parse_too_many_args(self) -> None:
        """Test stanza with too many arguments raises error."""
        # MAX_STANZA_ARGS is 10, so 20 args should fail
        lines = ["-> X25519 " + "arg " * 20, "ZGF0YQ=="]

        with pytest.raises(InvalidFileError, match="Too many stanza arguments"):
            Stanza.parse(lines)

    def test_stanza_parse_long_body(self) -> None:
        """Test stanza with long body lines."""
        long_line = "A" * 100  # Over MAX_BODY_LINE_LEN
        lines = ["-> test-type", long_line]

        with pytest.raises(InvalidFileError, match="Body line too long"):
            Stanza.parse(lines)

    def test_stanza_serialize_roundtrip(self) -> None:
        """Test stanza serialize/deserialize roundtrip."""
        original = Stanza(
            stanza_type="test",
            args=["arg1", "arg2"],
            body=b"test body data",
        )

        serialized = original.serialize()
        lines = serialized.strip().split("\n")

        parsed, consumed = Stanza.parse(lines)
        assert consumed == 2
        assert parsed.stanza_type == original.stanza_type
        assert parsed.args == original.args
        assert parsed.body == original.body


class TestTypedStanzas:
    """Test typed stanza creation and validation."""

    def test_x25519_stanza_from_stanza(self) -> None:
        """Test X25519Stanza creation from generic Stanza."""
        # Args are base64-encoded in age format
        ephemeral_share = b"test_ephemeral_share_32b_long!!"
        generic = Stanza(
            stanza_type="X25519",
            args=[base64.b64encode(ephemeral_share).decode("ascii")],
            body=b"wrapped_key",
        )

        typed = X25519Stanza.from_stanza(generic)
        assert typed.stanza_type == "X25519"
        assert typed.ephemeral_share == ephemeral_share
        assert typed.body == b"wrapped_key"

    def test_x25519_stanza_invalid_args(self) -> None:
        """Test X25519Stanza with invalid argument count."""
        generic = Stanza(
            stanza_type="X25519",
            args=["arg1", "arg2"],  # Too many args
            body=b"data",
        )

        with pytest.raises(InvalidFileError, match="X25519 stanza requires 1 argument"):
            X25519Stanza.from_stanza(generic)

    def test_scrypt_stanza_from_stanza(self) -> None:
        """Test ScryptStanza creation from generic Stanza."""
        salt = b"salt12345678901"  # 16 bytes
        generic = Stanza(
            stanza_type="scrypt",
            args=[base64.b64encode(salt).decode("ascii"), "18"],
            body=b"wrapped_key",
        )

        typed = ScryptStanza.from_stanza(generic)
        assert typed.stanza_type == "scrypt"
        assert typed.salt == salt
        assert typed.log_n == 18
        assert typed.body == b"wrapped_key"

    def test_scrypt_stanza_invalid_args(self) -> None:
        """Test ScryptStanza with invalid arguments."""
        generic = Stanza(
            stanza_type="scrypt",
            args=["c2FsdF9vbmx5"],  # Missing log_n (only salt)
            body=b"data",
        )

        with pytest.raises(InvalidFileError, match="scrypt stanza requires 2 arguments"):
            ScryptStanza.from_stanza(generic)

    def test_ssh_ed25519_stanza_from_stanza(self) -> None:
        """Test SshEd25519Stanza creation from generic Stanza."""
        key_hash = b"keyhash!"
        ephemeral = b"ephemeral_share_32bytes_long!!!!"
        generic = Stanza(
            stanza_type="ssh-ed25519",
            args=[
                base64.b64encode(key_hash).decode("ascii"),
                base64.b64encode(ephemeral).decode("ascii"),
            ],
            body=b"wrapped_key",
        )

        typed = SshEd25519Stanza.from_stanza(generic)
        assert typed.stanza_type == "ssh-ed25519"
        assert typed.key_hash == key_hash
        assert typed.ephemeral_share == ephemeral
        assert typed.body == b"wrapped_key"

    def test_mlkem_x25519_stanza_from_stanza(self) -> None:
        """Test MlkemX25519Stanza creation from generic Stanza."""
        mlkem_ct = b"mlkem_ciphertext_data"
        x25519_eph = b"x25519_ephemeral_32bytes_long!!!"
        fingerprint = b"ABCD"  # 4-byte fingerprint
        generic = Stanza(
            stanza_type="mlkem1024-x25519-v1",
            args=[
                base64.b64encode(fingerprint).decode("ascii"),
                base64.b64encode(mlkem_ct).decode("ascii"),
                base64.b64encode(x25519_eph).decode("ascii"),
            ],
            body=b"wrapped_key",
        )

        typed = MlkemX25519Stanza.from_stanza(generic)
        assert typed.stanza_type == "mlkem1024-x25519-v1"
        assert typed.key_fingerprint == fingerprint
        assert typed.mlkem_ciphertext == mlkem_ct
        assert typed.x25519_ephemeral == x25519_eph
        assert typed.body == b"wrapped_key"


class TestAgeHeader:
    """Test age header parsing and serialization."""

    def test_header_parse_valid(self) -> None:
        """Test parsing valid age header."""
        # Ephemeral share and MAC must be valid base64
        # age uses base64 WITHOUT padding
        ephemeral_b64 = age_b64encode(b"ephemeral_share_32bytes_long!!!!")
        wrapped_key_b64 = age_b64encode(b"wrapped_key_data_32bytes_long!!!")
        mac_b64 = age_b64encode(b"header_mac_32_bytes_long________")

        header_text = (
            f"age-encryption.org/v1\n-> X25519 {ephemeral_b64}\n{wrapped_key_b64}\n--- {mac_b64}\n"
        )

        data = header_text.encode("utf-8")
        header, payload_offset = AgeHeader.parse(data)

        assert len(header.stanzas) == 1
        assert header.stanzas[0].stanza_type == "X25519"
        assert header.mac == b"header_mac_32_bytes_long________"
        assert payload_offset == len(data)

    def test_header_parse_multiple_stanzas(self) -> None:
        """Test parsing header with multiple stanzas."""
        # age uses base64 WITHOUT padding
        eph_b64 = age_b64encode(b"eph_32bytes_____________________")
        salt_b64 = age_b64encode(b"salt_16_bytes___")
        key1_b64 = age_b64encode(b"key1_32_bytes___________________")
        key2_b64 = age_b64encode(b"key2_32_bytes___________________")
        mac_b64 = age_b64encode(b"mac_32_bytes____________________")

        header_text = (
            f"age-encryption.org/v1\n"
            f"-> X25519 {eph_b64}\n"
            f"{key1_b64}\n"
            f"-> scrypt {salt_b64} 10\n"
            f"{key2_b64}\n"
            f"--- {mac_b64}\n"
        )

        data = header_text.encode("utf-8")
        header, payload_offset = AgeHeader.parse(data)

        assert len(header.stanzas) == 2
        assert header.stanzas[0].stanza_type == "X25519"
        assert header.stanzas[1].stanza_type == "scrypt"

    def test_header_parse_invalid_magic(self) -> None:
        """Test parsing header with invalid magic."""
        mac_b64 = age_b64encode(b"mac_32_bytes____________________")
        data = f"invalid-magic\n--- {mac_b64}\n".encode()

        with pytest.raises(InvalidFileError, match="Invalid age header"):
            AgeHeader.parse(data)

    def test_header_parse_no_stanzas(self) -> None:
        """Test parsing header with no stanzas."""
        mac_b64 = age_b64encode(b"mac_32_bytes____________________")
        data = f"age-encryption.org/v1\n--- {mac_b64}\n".encode()

        with pytest.raises(InvalidFileError, match="No recipient stanzas"):
            AgeHeader.parse(data)

    def test_header_parse_missing_mac(self) -> None:
        """Test parsing header without MAC."""
        eph_b64 = age_b64encode(b"eph_32bytes_____________________")
        key_b64 = age_b64encode(b"key_32_bytes____________________")
        data = f"age-encryption.org/v1\n-> X25519 {eph_b64}\n{key_b64}\n".encode()

        with pytest.raises(InvalidFileError, match="Missing header MAC"):
            AgeHeader.parse(data)

    def test_header_serialize_basic(self) -> None:
        """Test header serialization."""
        ephemeral_share = b"ephemeral_share_32bytes_long!!!!"
        stanza = X25519Stanza.create(
            ephemeral_share=ephemeral_share,
            body=b"wrapped_key_32bytes_long________",
        )

        header = AgeHeader(stanzas=[stanza])
        data = header.serialize(file_key=b"0" * 16)  # 16-byte file key

        # Should start with age header
        assert data.startswith(AGE_HEADER_LINE)
        # Should contain stanza with base64-encoded ephemeral share (WITHOUT padding)
        eph_b64 = age_b64encode(ephemeral_share)
        assert f"-> X25519 {eph_b64}".encode() in data
        # Should contain MAC line
        assert b"--- " in data

    def test_header_verify_mac(self) -> None:
        """Test header MAC verification."""
        ephemeral_share = b"ephemeral_share_32bytes_long!!!!"
        stanza = X25519Stanza.create(
            ephemeral_share=ephemeral_share,
            body=b"wrapped_key_32bytes_long________",
        )

        header = AgeHeader(stanzas=[stanza])
        file_key = b"0" * 16  # 16-byte file key

        # Serialize with MAC
        data = header.serialize(file_key=file_key)

        # Parse back
        parsed_header, _ = AgeHeader.parse(data)

        # Verify MAC
        assert parsed_header.verify_mac(file_key)

    def test_header_verify_mac_invalid(self) -> None:
        """Test header MAC verification with wrong key."""
        ephemeral_share = b"ephemeral_share_32bytes_long!!!!"
        stanza = X25519Stanza.create(
            ephemeral_share=ephemeral_share,
            body=b"wrapped_key_32bytes_long________",
        )

        header = AgeHeader(stanzas=[stanza])
        file_key = b"0" * 16  # 16-byte file key
        wrong_key = b"1" * 16

        # Serialize with correct key
        data = header.serialize(file_key=file_key)

        # Parse back
        parsed_header, _ = AgeHeader.parse(data)

        # Verify with wrong key should fail
        assert not parsed_header.verify_mac(wrong_key)


class TestFileKeyWrapping:
    """Test file key wrapping/unwrapping."""

    def test_wrap_unwrap_roundtrip(self) -> None:
        """Test file key wrap/unwrap roundtrip."""
        # Keys must be exactly 32 bytes
        file_key = b"test_file_key___32_bytes_long!!!"  # 32 bytes
        wrapping_key = b"wrapping_key____32_bytes_long!!!"  # 32 bytes

        wrapped = wrap_file_key(file_key, wrapping_key)
        unwrapped = unwrap_file_key(wrapped, wrapping_key)

        assert unwrapped == file_key

    def test_wrap_unwrap_wrong_key(self) -> None:
        """Test file key unwrap with wrong key fails."""
        file_key = b"test_file_key___32_bytes_long!!!"  # 32 bytes
        wrapping_key = b"wrapping_key____32_bytes_long!!!"  # 32 bytes
        wrong_key = b"wrong_key_______32_bytes_long!!!"  # 32 bytes

        wrapped = wrap_file_key(file_key, wrapping_key)

        with pytest.raises((DecryptionError, Exception)):  # ChaCha20 decrypt error
            unwrap_file_key(wrapped, wrong_key)

    def test_derive_wrapping_key(self) -> None:
        """Test wrapping key derivation."""
        shared_secret = b"shared_secret___32_bytes_long!!!"  # 32 bytes
        ephemeral_pk = b"ephemeral_pk____32_bytes_long!!!"  # 32 bytes

        key1 = derive_file_key_wrapping_key(shared_secret, ephemeral_pk)
        key2 = derive_file_key_wrapping_key(shared_secret, ephemeral_pk)

        assert key1 == key2  # Deterministic
        assert len(key1) == 32


class TestParseAgeFile:
    """Test full age file parsing."""

    def test_parse_age_file_complete(self) -> None:
        """Test parsing complete age file."""
        # Create a minimal valid age file with age-compatible base64 (no padding)
        eph_b64 = age_b64encode(b"eph_32bytes_____________________")
        wrapped_b64 = age_b64encode(b"wrapped_key_data_32bytes________")
        mac_b64 = age_b64encode(b"mac_32bytes_____________________")

        header_text = f"age-encryption.org/v1\n-> X25519 {eph_b64}\n{wrapped_b64}\n--- {mac_b64}\n"
        payload = b"encrypted payload data"

        data = header_text.encode("utf-8") + payload

        header, parsed_payload = parse_age_file(data)

        assert len(header.stanzas) == 1
        assert header.stanzas[0].stanza_type == "X25519"
        assert parsed_payload == payload

    def test_parse_age_file_invalid(self) -> None:
        """Test parsing invalid age file."""
        data = b"not an age file"

        with pytest.raises(InvalidFileError):
            parse_age_file(data)


class TestEdgeCases:
    """Test edge cases and error conditions."""

    def test_empty_stanza_list_parse(self) -> None:
        """Test parsing header with empty stanza list."""
        mac_b64 = age_b64encode(b"mac_32bytes_____________________")
        data = f"age-encryption.org/v1\n--- {mac_b64}\n".encode()

        with pytest.raises(InvalidFileError, match="No recipient stanzas"):
            AgeHeader.parse(data)

    def test_too_many_recipients(self) -> None:
        """Test header with too many recipients."""
        # Create header with 1001 stanzas using age-compatible base64
        eph_b64 = age_b64encode(b"eph_32bytes_____________________")
        key_b64 = age_b64encode(b"key_32bytes_____________________")
        mac_b64 = age_b64encode(b"mac_32bytes_____________________")

        lines = ["age-encryption.org/v1"]
        for _ in range(1001):
            lines.extend([f"-> X25519 {eph_b64}", key_b64])
        lines.append(f"--- {mac_b64}")
        lines.append("")  # Trailing newline required by parser

        data = "\n".join(lines).encode("utf-8")

        with pytest.raises(InvalidFileError, match="Too many recipients"):
            AgeHeader.parse(data)

    def test_invalid_base64_in_stanza(self) -> None:
        """Test stanza with truncated/corrupted base64.

        Note: Python's base64.b64decode is very tolerant and accepts
        many technically invalid inputs. This test verifies that at
        least severely malformed base64 with wrong padding is rejected.
        """
        eph_b64 = age_b64encode(b"eph_32bytes_____________________")
        # Use base64 with explicit wrong padding that will fail
        # Single '=' padding on content that doesn't divide evenly
        lines = [f"-> X25519 {eph_b64}", "AAAA="]

        # This may or may not raise depending on Python version
        # The important thing is the stanza is parseable
        stanza, _ = Stanza.parse(lines)
        # Just verify we got something back
        assert stanza.stanza_type == "X25519"

    def test_truncated_header(self) -> None:
        """Test parsing truncated header."""
        data = b"age-encryption.org/v1\n-> X25519 abc"

        with pytest.raises(InvalidFileError):
            AgeHeader.parse(data)
