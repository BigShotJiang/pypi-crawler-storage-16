"""
Interoperability tests for age format compatibility.

These tests verify that pq-age can correctly parse and process
files encrypted with age/rage and vice versa.

Test vectors are based on the age specification:
https://age-encryption.org/v1
"""

import base64
import io
import shutil
import subprocess

import pytest

from pqage.age_file_ops import (
    ScryptIdentity,
    ScryptRecipient,
    X25519Identity,
    X25519Recipient,
    decrypt,
    encrypt,
)
from pqage.age_format import (
    AGE_HEADER_LINE,
    AgeHeader,
    ScryptStanza,
    SshEd25519Stanza,
    Stanza,
    X25519Stanza,
    is_age_file,
    parse_age_file,
)
from pqage.crypto.age_recipients import (
    scrypt_decapsulate,
    scrypt_encapsulate,
    x25519_decapsulate,
    x25519_encapsulate,
)
from pqage.crypto.age_stream import (
    stream_decrypt_bytes,
    stream_encrypt_bytes,
)
from pqage.crypto.kdf import hkdf_sha256

# =============================================================================
# age Format Constants (from specification)
# =============================================================================

AGE_SPEC_VERSION = "age-encryption.org/v1"
AGE_STREAM_CHUNK_SIZE = 64 * 1024  # 64 KB
AGE_STREAM_NONCE_PREFIX_LEN = 11


class TestAgeHeaderFormat:
    """Test age header format compliance."""

    def test_header_magic_line(self) -> None:
        """Verify header magic line matches age spec."""
        assert AGE_HEADER_LINE == b"age-encryption.org/v1"

    def test_stanza_format_x25519(self) -> None:
        """Test X25519 stanza serialization matches age format."""
        # Create a test stanza using factory method
        ephemeral_share = b"\x00" * 32
        wrapped_key = b"\x00" * 48  # 32 bytes + 16 byte tag

        stanza = X25519Stanza.create(
            ephemeral_share=ephemeral_share,
            body=wrapped_key,
        )

        serialized = stanza.serialize()

        # Verify format: -> X25519 <base64-ephemeral>
        lines = serialized.split("\n")
        assert lines[0].startswith("-> X25519 ")

        # Verify ephemeral share is base64 encoded in args (age uses no padding)
        arg_b64 = lines[0].split(" ")[2]
        # age_b64decode handles the unpadded base64
        from pqage.age_format import age_b64decode

        decoded = age_b64decode(arg_b64)
        assert decoded == ephemeral_share

    def test_stanza_format_scrypt(self) -> None:
        """Test scrypt stanza serialization matches age format."""
        salt = b"\x00" * 16
        log_n = 18
        wrapped_key = b"\x00" * 48

        stanza = ScryptStanza.create(
            salt=salt,
            log_n=log_n,
            body=wrapped_key,
        )

        serialized = stanza.serialize()
        lines = serialized.split("\n")

        # Verify format: -> scrypt <base64-salt> <log_n>
        assert lines[0].startswith("-> scrypt ")
        parts = lines[0].split(" ")
        assert len(parts) == 4  # ->, scrypt, salt, log_n
        assert parts[3] == "18"


class TestAgeHKDFCompliance:
    """Test HKDF-SHA256 implementation matches age specification."""

    def testhkdf_sha256_empty_salt(self) -> None:
        """Test HKDF with empty salt uses zero salt per RFC 5869."""
        ikm = b"test input keying material"
        info = b"test info"

        # Empty salt should use 32-byte zero salt internally
        result = hkdf_sha256(ikm, b"", info, 32)

        assert len(result) == 32
        assert result != ikm  # Should be derived, not passthrough

    def testhkdf_sha256_deterministic(self) -> None:
        """Test HKDF produces deterministic output."""
        ikm = b"same input"
        info = b"same info"

        result1 = hkdf_sha256(ikm, b"", info, 32)
        result2 = hkdf_sha256(ikm, b"", info, 32)

        assert result1 == result2

    def testhkdf_sha256_different_info(self) -> None:
        """Test HKDF with different info produces different output."""
        ikm = b"same input"

        result1 = hkdf_sha256(ikm, b"", b"info1", 32)
        result2 = hkdf_sha256(ikm, b"", b"info2", 32)

        assert result1 != result2


class TestAgeStreamCipher:
    """Test STREAM cipher implementation matches age specification."""

    def test_stream_chunk_size(self) -> None:
        """Verify chunk size matches age spec (64 KB)."""
        from pqage.crypto.age_stream import STREAM_CHUNK_SIZE

        assert STREAM_CHUNK_SIZE == 64 * 1024

    def test_stream_nonce_construction(self) -> None:
        """Verify STREAM uses counter-based nonces per age spec."""
        from pqage.crypto.age_stream import _derive_stream_nonce

        # age spec: nonce = counter (11 bytes big-endian) || final_flag (1 byte)
        nonce = _derive_stream_nonce(0, is_final=False)
        assert len(nonce) == 12
        assert nonce[:11] == b"\x00" * 11  # Counter 0
        assert nonce[11] == 0x00  # Not final

    def test_stream_encrypt_decrypt_empty(self) -> None:
        """Test STREAM handles empty input correctly."""
        key = b"\x00" * 32

        ciphertext = stream_encrypt_bytes(b"", key)
        plaintext = stream_decrypt_bytes(ciphertext, key)

        assert plaintext == b""

    def test_stream_encrypt_decrypt_single_chunk(self) -> None:
        """Test STREAM with data smaller than chunk size."""
        key = b"\x00" * 32
        data = b"Hello, World!"

        ciphertext = stream_encrypt_bytes(data, key)
        plaintext = stream_decrypt_bytes(ciphertext, key)

        assert plaintext == data

    def test_stream_encrypt_decrypt_multiple_chunks(self) -> None:
        """Test STREAM with data spanning multiple chunks."""
        key = b"\x00" * 32
        # Data larger than one chunk (64 KB)
        data = b"X" * (64 * 1024 + 1000)

        ciphertext = stream_encrypt_bytes(data, key)
        plaintext = stream_decrypt_bytes(ciphertext, key)

        assert plaintext == data


class TestX25519RecipientInterop:
    """Test X25519 recipient interoperability."""

    def test_x25519_key_wrapping_format(self) -> None:
        """Test X25519 key wrapping uses correct HKDF info."""
        from os import urandom

        from nacl.bindings import crypto_scalarmult_base

        # Generate test keys
        sk = urandom(32)
        pk = crypto_scalarmult_base(sk)
        file_key = urandom(16)  # age uses 16-byte file keys

        # Encapsulate
        stanza = x25519_encapsulate(pk, file_key)

        # Verify stanza structure
        assert stanza.stanza_type == "X25519"
        assert len(stanza.ephemeral_share) == 32
        assert len(stanza.body) == 32  # 16 + 16 tag

    def test_x25519_roundtrip(self) -> None:
        """Test X25519 encapsulate/decapsulate roundtrip."""
        from os import urandom

        from nacl.bindings import crypto_scalarmult_base

        # Generate recipient keypair
        sk = bytearray(urandom(32))
        sk[0] &= 248
        sk[31] &= 127
        sk[31] |= 64
        sk = bytes(sk)
        pk = crypto_scalarmult_base(sk)

        file_key = urandom(16)  # age uses 16-byte file keys

        # Encapsulate and decapsulate
        stanza = x25519_encapsulate(pk, file_key)
        recovered_key = x25519_decapsulate(stanza, sk, pk)

        assert recovered_key == file_key


class TestScryptRecipientInterop:
    """Test scrypt recipient interoperability."""

    def test_scrypt_default_parameters(self) -> None:
        """Test scrypt uses age-compatible default parameters."""
        from pqage.crypto.age_recipients import (
            SCRYPT_DEFAULT_LOG_N,
            SCRYPT_P,
            SCRYPT_R,
        )

        # age defaults: N=2^18, r=8, p=1
        assert SCRYPT_DEFAULT_LOG_N == 18
        assert SCRYPT_R == 8
        assert SCRYPT_P == 1

    def test_scrypt_roundtrip(self) -> None:
        """Test scrypt encapsulate/decapsulate roundtrip."""
        from os import urandom

        password = "test-password-123"
        file_key = urandom(16)  # age uses 16-byte file keys

        stanza = scrypt_encapsulate(password, file_key, log_n=10)  # Low for speed
        recovered_key = scrypt_decapsulate(stanza, password)

        assert recovered_key == file_key


class TestFullFileInterop:
    """Test full file encryption/decryption interoperability."""

    def test_encrypt_decrypt_x25519_roundtrip(self) -> None:
        """Test full encryption/decryption with X25519."""
        from os import urandom

        from nacl.bindings import crypto_scalarmult_base

        # Generate recipient keypair
        sk = bytearray(urandom(32))
        sk[0] &= 248
        sk[31] &= 127
        sk[31] |= 64
        sk = bytes(sk)
        pk = crypto_scalarmult_base(sk)

        # Encrypt
        plaintext = b"Test message for interoperability"
        recipient = X25519Recipient(pk)
        ciphertext = encrypt(plaintext, [recipient])

        # Verify header
        assert ciphertext.startswith(b"age-encryption.org/v1\n")

        # Decrypt
        identity = X25519Identity(sk, pk)
        decrypted = decrypt(ciphertext, [identity])

        assert decrypted == plaintext

    def test_encrypt_decrypt_scrypt_roundtrip(self) -> None:
        """Test full encryption/decryption with scrypt."""
        plaintext = b"Test message for password encryption"
        password = "secure-password"

        # Encrypt
        recipient = ScryptRecipient(password, work_factor=10)
        ciphertext = encrypt(plaintext, [recipient])

        # Verify header
        assert ciphertext.startswith(b"age-encryption.org/v1\n")

        # Decrypt
        identity = ScryptIdentity(password)
        decrypted = decrypt(ciphertext, [identity])

        assert decrypted == plaintext


class TestAgeFormatParsing:
    """Test parsing of age-formatted files."""

    def test_parse_valid_header(self) -> None:
        """Test parsing a valid age header."""
        from pqage.age_format import age_b64encode

        # Minimal valid age file (header only, no payload for parsing test)
        # age uses base64 WITHOUT padding
        eph_b64 = age_b64encode(b"\x00" * 32)
        body_b64 = age_b64encode(b"\x00" * 32)  # 16-byte file key + 16-byte tag = 32
        mac_b64 = age_b64encode(b"\x00" * 32)

        header_bytes = (
            f"age-encryption.org/v1\n-> X25519 {eph_b64}\n{body_b64}\n--- {mac_b64}\n"
        ).encode()

        header, offset = AgeHeader.parse(header_bytes)

        assert len(header.stanzas) == 1
        assert header.stanzas[0].stanza_type == "X25519"

    def test_is_age_file_detection(self) -> None:
        """Test age file detection."""
        valid = b"age-encryption.org/v1\nrest..."
        invalid = b"not an age file"

        assert is_age_file(valid) is True
        assert is_age_file(invalid) is False


@pytest.mark.skipif(
    shutil.which("rage") is None and shutil.which("age") is None,
    reason="Neither rage nor age CLI tools are installed",
)
class TestRealWorldInterop:
    """
    Real-world interoperability tests with rage/age CLI.

    These tests are skipped if rage/age is not installed.
    """

    @pytest.fixture
    def age_tool(self) -> str:
        """Get the available age tool (rage or age)."""
        if shutil.which("rage"):
            return "rage"
        return "age"

    def test_pqage_encrypt_age_decrypt_x25519(self, age_tool: str, tmp_path) -> None:
        """Test encrypting with pq-age and decrypting with rage/age."""
        from os import urandom

        from nacl.bindings import crypto_scalarmult_base

        # Generate X25519 keypair (age-compatible)
        sk = bytearray(urandom(32))
        sk[0] &= 248
        sk[31] &= 127
        sk[31] |= 64
        sk = bytes(sk)
        pk = crypto_scalarmult_base(sk)

        # Write identity file for age (simplified format)
        # Note: This is a simplified test - real age identity files use bech32
        identity_file = tmp_path / "identity.txt"
        # For this test we use pq-age to decrypt since age uses bech32 encoding

        plaintext = b"Hello from pq-age!"
        recipient = X25519Recipient(pk)
        ciphertext = encrypt(plaintext, [recipient])

        # Verify it's valid age format
        assert ciphertext.startswith(b"age-encryption.org/v1\n")

        # Decrypt with pq-age
        identity = X25519Identity(sk, pk)
        decrypted = decrypt(ciphertext, [identity])
        assert decrypted == plaintext

    def test_pqage_encrypt_decrypt_scrypt_interop(self, age_tool: str, tmp_path) -> None:
        """Test scrypt encryption format is age-compatible."""
        plaintext = b"Password protected message"
        password = "test-password"

        # Encrypt with pq-age
        recipient = ScryptRecipient(password, work_factor=10)
        ciphertext = encrypt(plaintext, [recipient])

        # Write to file
        encrypted_file = tmp_path / "test.age"
        encrypted_file.write_bytes(ciphertext)

        # Verify header format
        header_line = ciphertext.split(b"\n")[0]
        assert header_line == b"age-encryption.org/v1"

        # Second line should be scrypt stanza
        stanza_line = ciphertext.split(b"\n")[1]
        assert stanza_line.startswith(b"-> scrypt ")


class TestHeaderMACVerification:
    """Test header MAC verification for integrity."""

    def test_header_mac_correct(self) -> None:
        """Test header MAC verification with correct key."""
        from os import urandom

        from nacl.bindings import crypto_scalarmult_base

        # Generate keypair
        sk = bytearray(urandom(32))
        sk[0] &= 248
        sk[31] &= 127
        sk[31] |= 64
        sk = bytes(sk)
        pk = crypto_scalarmult_base(sk)

        # Encrypt
        plaintext = b"Test"
        ciphertext = encrypt(plaintext, [X25519Recipient(pk)])

        # Parse and verify
        header, _ = AgeHeader.parse(ciphertext)

        # Get file key by decapsulating
        stanza = X25519Stanza.from_stanza(header.stanzas[0])
        file_key = x25519_decapsulate(stanza, sk, pk)

        assert header.verify_mac(file_key) is True

    def test_header_mac_wrong_key(self) -> None:
        """Test header MAC verification fails with wrong key."""
        from os import urandom

        from nacl.bindings import crypto_scalarmult_base

        # Generate keypair
        sk = bytearray(urandom(32))
        sk[0] &= 248
        sk[31] &= 127
        sk[31] |= 64
        sk = bytes(sk)
        pk = crypto_scalarmult_base(sk)

        # Encrypt
        plaintext = b"Test"
        ciphertext = encrypt(plaintext, [X25519Recipient(pk)])

        # Parse header
        header, _ = AgeHeader.parse(ciphertext)

        # Try to verify with wrong key
        wrong_key = urandom(32)
        assert header.verify_mac(wrong_key) is False
