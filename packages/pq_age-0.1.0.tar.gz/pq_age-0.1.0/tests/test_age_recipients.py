"""
Tests for age recipient implementations.

Tests age_recipients.py: X25519, scrypt, ssh-ed25519, mlkem1024-x25519-v1 recipients.
"""

import hashlib
import os

import pytest

from pqage.age_format import MlkemX25519Stanza, ScryptStanza, SshEd25519Stanza, X25519Stanza
from pqage.constants import (
    HYBRID_FINGERPRINT_LEN,
    MLKEM_X25519_STANZA_LABEL,
    PQAGE_PROTOCOL_ID,
    PQAGE_PROTOCOL_VERSION,
)
from pqage.crypto.age_recipients import (
    FILE_KEY_LEN,
    MLKEM_PUBLIC_KEY_LEN,
    X25519_PUBLIC_KEY_LEN,
    build_transcript,
    compute_hybrid_fingerprint,
    mlkem_x25519_decapsulate,
    mlkem_x25519_encapsulate,
    scrypt_decapsulate,
    scrypt_encapsulate,
    ssh_ed25519_decapsulate,
    ssh_ed25519_encapsulate,
    try_decrypt_stanza,
    x25519_decapsulate,
    x25519_encapsulate,
)
from pqage.crypto.ssh import SshEd25519PublicKey
from pqage.exceptions import DecryptionError, EncapsulationError, InvalidKeyError


class TestX25519Recipient:
    """Test X25519 recipient operations."""

    @pytest.fixture
    def x25519_keypair(self) -> tuple[bytes, bytes]:
        """Generate X25519 keypair for testing."""
        from nacl.bindings import crypto_scalarmult_base

        sk = os.urandom(32)
        # Clamp scalar (RFC 7748)
        sk = bytearray(sk)
        sk[0] &= 248
        sk[31] &= 127
        sk[31] |= 64
        sk = bytes(sk)

        pk = crypto_scalarmult_base(sk)
        return sk, pk

    def test_x25519_encapsulate_decapsulate_roundtrip(self, x25519_keypair: tuple) -> None:
        """Test X25519 encapsulate/decapsulate roundtrip."""
        sk, pk = x25519_keypair
        file_key = os.urandom(FILE_KEY_LEN)

        stanza = x25519_encapsulate(pk, file_key)

        # Verify stanza structure
        assert isinstance(stanza, X25519Stanza)
        assert stanza.stanza_type == "X25519"
        assert len(stanza.ephemeral_share) == 32
        assert len(stanza.body) == 32  # 16-byte file key + 16-byte poly1305 tag

        # Decapsulate
        recovered_key = x25519_decapsulate(stanza, sk, pk)

        assert recovered_key == file_key

    def test_x25519_encapsulate_invalid_key_lengths(self) -> None:
        """Test X25519 encapsulation with invalid key lengths."""
        invalid_pk = b"wrong_length"
        file_key = os.urandom(FILE_KEY_LEN)

        with pytest.raises(InvalidKeyError, match="X25519 public key must be 32 bytes"):
            x25519_encapsulate(invalid_pk, file_key)

        valid_pk = os.urandom(32)
        invalid_file_key = b"wrong"

        with pytest.raises(InvalidKeyError, match="File key must be 16 bytes"):
            x25519_encapsulate(valid_pk, invalid_file_key)

    def test_x25519_decapsulate_invalid_keys(self, x25519_keypair: tuple) -> None:
        """Test X25519 decapsulation with invalid keys."""
        sk, pk = x25519_keypair
        file_key = os.urandom(FILE_KEY_LEN)

        stanza = x25519_encapsulate(pk, file_key)

        # Wrong secret key
        wrong_sk = os.urandom(32)
        with pytest.raises(DecryptionError):
            x25519_decapsulate(stanza, wrong_sk, pk)

        # Wrong public key
        wrong_pk = os.urandom(32)
        with pytest.raises(DecryptionError):
            x25519_decapsulate(stanza, sk, wrong_pk)


class TestScryptRecipient:
    """Test scrypt recipient operations."""

    def test_scrypt_encapsulate_decapsulate_roundtrip(self) -> None:
        """Test scrypt encapsulate/decapsulate roundtrip."""
        password = "test_password_123"
        file_key = os.urandom(FILE_KEY_LEN)
        log_n = 12  # Fast for testing

        stanza = scrypt_encapsulate(password, file_key, log_n)

        # Verify stanza structure
        assert isinstance(stanza, ScryptStanza)
        assert stanza.stanza_type == "scrypt"
        assert len(stanza.salt) == 16
        assert stanza.log_n == log_n
        assert len(stanza.body) == 32  # 16-byte file key + 16-byte poly1305 tag

        # Decapsulate
        recovered_key = scrypt_decapsulate(stanza, password)

        assert recovered_key == file_key

    def test_scrypt_encapsulate_invalid_params(self) -> None:
        """Test scrypt encapsulation with invalid parameters."""
        password = "test"
        file_key = os.urandom(FILE_KEY_LEN)

        # Invalid log_n
        with pytest.raises(InvalidKeyError, match="Invalid scrypt log_n"):
            scrypt_encapsulate(password, file_key, log_n=-1)

        with pytest.raises(InvalidKeyError, match="Invalid scrypt log_n"):
            scrypt_encapsulate(password, file_key, log_n=50)

        # Invalid file key length
        with pytest.raises(InvalidKeyError, match="File key must be 16 bytes"):
            scrypt_encapsulate(password, b"wrong", log_n=10)

    def test_scrypt_decapsulate_wrong_password(self) -> None:
        """Test scrypt decapsulation with wrong password."""
        password = "correct_password"
        wrong_password = "wrong_password"
        file_key = os.urandom(FILE_KEY_LEN)

        stanza = scrypt_encapsulate(password, file_key, log_n=10)

        with pytest.raises(DecryptionError, match="(Wrong password|Decryption failed)"):
            scrypt_decapsulate(stanza, wrong_password)

    @pytest.mark.parametrize("log_n", [10, 12, 14])
    def test_scrypt_different_work_factors(self, log_n: int) -> None:
        """Test scrypt with different work factors.

        Note: log_n > 14 may exceed memory limits in test environments.
        age default is 18, but for testing we use lower values.
        """
        password = "test_password"
        file_key = os.urandom(FILE_KEY_LEN)

        stanza = scrypt_encapsulate(password, file_key, log_n)
        recovered_key = scrypt_decapsulate(stanza, password)

        assert recovered_key == file_key
        assert stanza.log_n == log_n


class TestSshEd25519Recipient:
    """Test SSH Ed25519 recipient operations."""

    @pytest.fixture
    def ssh_keypair(self) -> tuple[SshEd25519PublicKey, bytes, bytes]:
        """Create SSH Ed25519 keypair for testing."""
        # Use a known good seed for consistent testing
        from nacl.signing import SigningKey

        from pqage.crypto.ssh import SshEd25519PrivateKey

        seed = bytes.fromhex("9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60")
        signing_key = SigningKey(seed)
        ed25519_pk = bytes(signing_key.verify_key)

        # Full Ed25519 secret key is seed + public_key (64 bytes)
        full_ed25519_sk = seed + ed25519_pk

        # Create SSH keys
        ssh_private = SshEd25519PrivateKey.from_ed25519(full_ed25519_sk, ed25519_pk)
        ssh_public = SshEd25519PublicKey.from_ed25519(ed25519_pk)

        return ssh_public, ssh_private.x25519_sk, ssh_private.x25519_pk

    def test_ssh_ed25519_encapsulate_decapsulate_roundtrip(self, ssh_keypair: tuple) -> None:
        """Test SSH Ed25519 encapsulate/decapsulate roundtrip."""
        ssh_public, x25519_sk, x25519_pk = ssh_keypair
        file_key = os.urandom(FILE_KEY_LEN)

        stanza = ssh_ed25519_encapsulate(
            ssh_public.x25519_pk, ssh_public.key_hash, ssh_public.ssh_key_blob, file_key
        )

        # Verify stanza structure
        assert isinstance(stanza, SshEd25519Stanza)
        assert stanza.stanza_type == "ssh-ed25519"
        assert len(stanza.ephemeral_share) == 32
        assert len(stanza.body) == 32  # 16-byte file key + 16-byte poly1305 tag

        # Decapsulate
        recovered_key = ssh_ed25519_decapsulate(
            stanza, x25519_sk, x25519_pk, ssh_public.key_hash, ssh_public.ssh_key_blob
        )

        assert recovered_key == file_key

    def test_ssh_ed25519_wrong_key_hash(self, ssh_keypair: tuple) -> None:
        """Test SSH Ed25519 with wrong key hash."""
        ssh_public, x25519_sk, x25519_pk = ssh_keypair
        file_key = os.urandom(FILE_KEY_LEN)
        wrong_hash = b"wrong"

        stanza = ssh_ed25519_encapsulate(
            ssh_public.x25519_pk, ssh_public.key_hash, ssh_public.ssh_key_blob, file_key
        )

        with pytest.raises(InvalidKeyError, match="SSH key hash does not match"):
            ssh_ed25519_decapsulate(
                stanza, x25519_sk, x25519_pk, wrong_hash, ssh_public.ssh_key_blob
            )

    def test_ssh_ed25519_invalid_key_lengths(self) -> None:
        """Test SSH Ed25519 with invalid key lengths."""
        file_key = os.urandom(FILE_KEY_LEN)
        invalid_pk = b"wrong_length"
        valid_hash = b"hash"
        valid_blob = b"dummy_blob"  # Not validated before pk length check

        with pytest.raises(InvalidKeyError, match="X25519 public key must be 32 bytes"):
            ssh_ed25519_encapsulate(invalid_pk, valid_hash, valid_blob, file_key)


class TestHybridHelperFunctions:
    """Test helper functions for hybrid ML-KEM-X25519 recipient."""

    def test_compute_hybrid_fingerprint_basic(self) -> None:
        """Test fingerprint computation with known values."""
        mlkem_pk = b"M" * MLKEM_PUBLIC_KEY_LEN
        x25519_pk = b"X" * X25519_PUBLIC_KEY_LEN

        fingerprint = compute_hybrid_fingerprint(mlkem_pk, x25519_pk)

        # Verify length
        assert len(fingerprint) == HYBRID_FINGERPRINT_LEN

        # Verify it matches SHA256 truncation
        expected = hashlib.sha256(mlkem_pk + x25519_pk).digest()[:HYBRID_FINGERPRINT_LEN]
        assert fingerprint == expected

    def test_compute_hybrid_fingerprint_deterministic(self) -> None:
        """Test fingerprint is deterministic."""
        mlkem_pk = os.urandom(MLKEM_PUBLIC_KEY_LEN)
        x25519_pk = os.urandom(X25519_PUBLIC_KEY_LEN)

        fp1 = compute_hybrid_fingerprint(mlkem_pk, x25519_pk)
        fp2 = compute_hybrid_fingerprint(mlkem_pk, x25519_pk)

        assert fp1 == fp2

    def test_compute_hybrid_fingerprint_different_keys(self) -> None:
        """Test different keys produce different fingerprints."""
        mlkem_pk1 = os.urandom(MLKEM_PUBLIC_KEY_LEN)
        mlkem_pk2 = os.urandom(MLKEM_PUBLIC_KEY_LEN)
        x25519_pk = os.urandom(X25519_PUBLIC_KEY_LEN)

        fp1 = compute_hybrid_fingerprint(mlkem_pk1, x25519_pk)
        fp2 = compute_hybrid_fingerprint(mlkem_pk2, x25519_pk)

        assert fp1 != fp2

    def test_compute_hybrid_fingerprint_invalid_lengths(self) -> None:
        """Test fingerprint rejects invalid key lengths."""
        valid_mlkem_pk = b"M" * MLKEM_PUBLIC_KEY_LEN
        valid_x25519_pk = b"X" * X25519_PUBLIC_KEY_LEN

        # Invalid ML-KEM PK
        with pytest.raises(InvalidKeyError, match="ML-KEM public key must be"):
            compute_hybrid_fingerprint(b"short", valid_x25519_pk)

        # Invalid X25519 PK
        with pytest.raises(InvalidKeyError, match="X25519 public key must be"):
            compute_hybrid_fingerprint(valid_mlkem_pk, b"short")

    def test_build_transcript_structure(self) -> None:
        """Test transcript has correct structure."""
        mlkem_ct = b"C" * 1568
        x25519_eph = b"E" * 32
        mlkem_pk = b"M" * 1568
        x25519_pk = b"X" * 32

        transcript = build_transcript(mlkem_ct, x25519_eph, mlkem_pk, x25519_pk)

        # Verify prefix
        assert transcript.startswith(PQAGE_PROTOCOL_ID)
        assert transcript[len(PQAGE_PROTOCOL_ID)] == PQAGE_PROTOCOL_VERSION
        assert MLKEM_X25519_STANZA_LABEL in transcript

        # Verify length encoding (each field has 2-byte length prefix)
        # Total = 5 (pqage) + 1 (version) + 16 (label) + 4*2 (lengths) + data
        expected_overhead = 5 + 1 + 16 + 8
        expected_len = (
            expected_overhead + len(mlkem_ct) + len(x25519_eph) + len(mlkem_pk) + len(x25519_pk)
        )
        assert len(transcript) == expected_len

    def test_build_transcript_deterministic(self) -> None:
        """Test transcript is deterministic."""
        mlkem_ct = os.urandom(1568)
        x25519_eph = os.urandom(32)
        mlkem_pk = os.urandom(1568)
        x25519_pk = os.urandom(32)

        t1 = build_transcript(mlkem_ct, x25519_eph, mlkem_pk, x25519_pk)
        t2 = build_transcript(mlkem_ct, x25519_eph, mlkem_pk, x25519_pk)

        assert t1 == t2

    def test_build_transcript_different_inputs(self) -> None:
        """Test different inputs produce different transcripts."""
        mlkem_ct1 = os.urandom(1568)
        mlkem_ct2 = os.urandom(1568)
        x25519_eph = os.urandom(32)
        mlkem_pk = os.urandom(1568)
        x25519_pk = os.urandom(32)

        t1 = build_transcript(mlkem_ct1, x25519_eph, mlkem_pk, x25519_pk)
        t2 = build_transcript(mlkem_ct2, x25519_eph, mlkem_pk, x25519_pk)

        assert t1 != t2


class TestMlkemX25519Recipient:
    """Test hybrid ML-KEM-1024 + X25519 recipient operations (v1)."""

    @pytest.fixture
    def mlkem_keypair(self) -> tuple[bytes, bytes]:
        """Generate ML-KEM keypair for testing."""
        # Skip ML-KEM tests if liboqs not available
        pytest.importorskip("oqs")

        import oqs

        kem = oqs.KeyEncapsulation("ML-KEM-1024")
        pk = kem.generate_keypair()
        sk = kem.export_secret_key()
        kem.free()
        return pk, sk

    @pytest.fixture
    def x25519_keypair(self) -> tuple[bytes, bytes]:
        """Generate X25519 keypair for testing."""
        from nacl.bindings import crypto_scalarmult_base

        sk = os.urandom(32)
        # Clamp scalar
        sk = bytearray(sk)
        sk[0] &= 248
        sk[31] &= 127
        sk[31] |= 64
        sk = bytes(sk)

        pk = crypto_scalarmult_base(sk)
        return sk, pk

    @pytest.mark.skipif(
        not pytest.importorskip("oqs", reason="liboqs not available"),
        reason="ML-KEM tests require liboqs",
    )
    def test_mlkem_x25519_encapsulate_decapsulate_roundtrip(
        self, mlkem_keypair: tuple, x25519_keypair: tuple
    ) -> None:
        """Test ML-KEM+X25519 encapsulate/decapsulate roundtrip."""
        mlkem_pk, mlkem_sk = mlkem_keypair
        x25519_sk, x25519_pk = x25519_keypair
        file_key = os.urandom(FILE_KEY_LEN)

        stanza = mlkem_x25519_encapsulate(mlkem_pk, x25519_pk, file_key)

        # Verify stanza structure (v1 format with fingerprint)
        assert isinstance(stanza, MlkemX25519Stanza)
        assert stanza.stanza_type == "mlkem1024-x25519-v1"
        assert len(stanza.key_fingerprint) == HYBRID_FINGERPRINT_LEN  # 4 bytes
        assert len(stanza.mlkem_ciphertext) == 1568  # ML-KEM-1024 ciphertext
        assert len(stanza.x25519_ephemeral) == 32
        assert len(stanza.body) == 32  # 16-byte file key + 16-byte poly1305 tag

        # Verify fingerprint is correct
        expected_fingerprint = compute_hybrid_fingerprint(mlkem_pk, x25519_pk)
        assert stanza.key_fingerprint == expected_fingerprint

        # Decapsulate
        recovered_key = mlkem_x25519_decapsulate(stanza, mlkem_sk, x25519_sk, mlkem_pk, x25519_pk)

        assert recovered_key == file_key

    def test_mlkem_x25519_invalid_key_lengths(self) -> None:
        """Test ML-KEM+X25519 with invalid key lengths."""
        """Test ML-KEM+X25519 with invalid key lengths."""
        file_key = os.urandom(FILE_KEY_LEN)

        # Invalid ML-KEM public key
        invalid_mlkem_pk = b"wrong"
        valid_x25519_pk = os.urandom(32)

        with pytest.raises(InvalidKeyError, match="ML-KEM public key must be 1568 bytes"):
            mlkem_x25519_encapsulate(invalid_mlkem_pk, valid_x25519_pk, file_key)

        # Invalid X25519 public key
        valid_mlkem_pk = b"M" * 1568
        invalid_x25519_pk = b"wrong"

        with pytest.raises(InvalidKeyError, match="X25519 public key must be 32 bytes"):
            mlkem_x25519_encapsulate(valid_mlkem_pk, invalid_x25519_pk, file_key)

    @pytest.mark.skipif(
        not pytest.importorskip("oqs", reason="liboqs not available"),
        reason="ML-KEM tests require liboqs",
    )
    def test_mlkem_x25519_decapsulate_invalid_keys(
        self, mlkem_keypair: tuple, x25519_keypair: tuple
    ) -> None:
        """Test ML-KEM+X25519 decapsulation with invalid keys."""
        mlkem_pk, mlkem_sk = mlkem_keypair
        x25519_sk, x25519_pk = x25519_keypair
        file_key = os.urandom(FILE_KEY_LEN)

        stanza = mlkem_x25519_encapsulate(mlkem_pk, x25519_pk, file_key)

        # Wrong ML-KEM secret key
        wrong_mlkem_sk = b"W" * 3168
        with pytest.raises(DecryptionError):
            mlkem_x25519_decapsulate(stanza, wrong_mlkem_sk, x25519_sk, mlkem_pk, x25519_pk)

        # Wrong X25519 secret key
        wrong_x25519_sk = os.urandom(32)
        with pytest.raises(DecryptionError):
            mlkem_x25519_decapsulate(stanza, mlkem_sk, wrong_x25519_sk, mlkem_pk, x25519_pk)

    @pytest.mark.skipif(
        not pytest.importorskip("oqs", reason="liboqs not available"),
        reason="ML-KEM tests require liboqs",
    )
    def test_mlkem_x25519_fingerprint_mismatch_rejected(
        self, mlkem_keypair: tuple, x25519_keypair: tuple
    ) -> None:
        """Test that fingerprint mismatch is rejected early."""
        mlkem_pk, mlkem_sk = mlkem_keypair
        x25519_sk, x25519_pk = x25519_keypair
        file_key = os.urandom(FILE_KEY_LEN)

        stanza = mlkem_x25519_encapsulate(mlkem_pk, x25519_pk, file_key)

        # Generate different recipient keys
        import oqs

        other_kem = oqs.KeyEncapsulation("ML-KEM-1024")
        other_mlkem_pk = other_kem.generate_keypair()
        other_mlkem_sk = other_kem.export_secret_key()
        other_kem.free()

        from nacl.bindings import crypto_scalarmult_base

        other_x25519_sk = os.urandom(32)
        other_x25519_sk = bytearray(other_x25519_sk)
        other_x25519_sk[0] &= 248
        other_x25519_sk[31] &= 127
        other_x25519_sk[31] |= 64
        other_x25519_sk = bytes(other_x25519_sk)
        other_x25519_pk = crypto_scalarmult_base(other_x25519_sk)

        # Decapsulation with different keys should fail with fingerprint mismatch
        with pytest.raises(InvalidKeyError, match="fingerprint does not match"):
            mlkem_x25519_decapsulate(
                stanza, other_mlkem_sk, other_x25519_sk, other_mlkem_pk, other_x25519_pk
            )

    @pytest.mark.skipif(
        not pytest.importorskip("oqs", reason="liboqs not available"),
        reason="ML-KEM tests require liboqs",
    )
    def test_mlkem_x25519_stanza_has_3_args(
        self, mlkem_keypair: tuple, x25519_keypair: tuple
    ) -> None:
        """Test that v1 stanza has 3 arguments (fingerprint, ct, eph)."""
        mlkem_pk, mlkem_sk = mlkem_keypair
        x25519_sk, x25519_pk = x25519_keypair
        file_key = os.urandom(FILE_KEY_LEN)

        stanza = mlkem_x25519_encapsulate(mlkem_pk, x25519_pk, file_key)

        # Stanza should have 3 args
        assert len(stanza.args) == 3

        # First arg should be fingerprint (base64)
        from pqage.age_format import age_b64decode

        decoded_fp = age_b64decode(stanza.args[0])
        assert len(decoded_fp) == HYBRID_FINGERPRINT_LEN
        assert decoded_fp == stanza.key_fingerprint


class TestTryDecryptStanza:
    """Test the try_decrypt_stanza function."""

    @pytest.fixture
    def ssh_keypair(self) -> tuple[SshEd25519PublicKey, bytes, bytes]:
        """Create SSH Ed25519 keypair for testing."""
        from nacl.signing import SigningKey

        from pqage.crypto.ssh import SshEd25519PrivateKey

        seed = bytes.fromhex("9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60")
        signing_key = SigningKey(seed)
        ed25519_pk = bytes(signing_key.verify_key)
        full_ed25519_sk = seed + ed25519_pk

        ssh_private = SshEd25519PrivateKey.from_ed25519(full_ed25519_sk, ed25519_pk)
        ssh_public = SshEd25519PublicKey.from_ed25519(ed25519_pk)

        return ssh_public, ssh_private.x25519_sk, ssh_private.x25519_pk

    def test_try_decrypt_x25519_success(self) -> None:
        """Test successful X25519 stanza decryption."""
        from nacl.bindings import crypto_scalarmult_base

        # Create keys
        sk = os.urandom(32)
        sk = bytearray(sk)
        sk[0] &= 248
        sk[31] &= 127
        sk[31] |= 64
        sk = bytes(sk)
        pk = crypto_scalarmult_base(sk)

        file_key = os.urandom(FILE_KEY_LEN)
        stanza = x25519_encapsulate(pk, file_key)

        # Try decrypt
        recovered = try_decrypt_stanza(stanza, x25519_sk=sk, x25519_pk=pk)

        assert recovered == file_key

    def test_try_decrypt_ssh_ed25519_success(self, ssh_keypair: tuple) -> None:
        """Test successful SSH Ed25519 stanza decryption."""
        from pqage.crypto.utils import secure_compare

        ssh_public, x25519_sk, x25519_pk = ssh_keypair
        file_key = os.urandom(FILE_KEY_LEN)

        stanza = ssh_ed25519_encapsulate(
            ssh_public.x25519_pk, ssh_public.key_hash, ssh_public.ssh_key_blob, file_key
        )

        # Try decrypt
        recovered = try_decrypt_stanza(
            stanza,
            x25519_sk=x25519_sk,
            x25519_pk=x25519_pk,
            ssh_key_hash=ssh_public.key_hash,
            ssh_key_blob=ssh_public.ssh_key_blob,
        )

        assert recovered == file_key

        # Wrong hash should fail
        wrong_hash = b"wrong"
        assert not secure_compare(ssh_public.key_hash, wrong_hash)
        recovered_fail = try_decrypt_stanza(
            stanza, x25519_sk=x25519_sk, x25519_pk=x25519_pk, ssh_key_hash=wrong_hash
        )
        assert recovered_fail is None

    @pytest.mark.skipif(
        not pytest.importorskip("oqs", reason="liboqs not available"),
        reason="ML-KEM tests require liboqs",
    )
    def test_try_decrypt_mlkem_x25519_success(self) -> None:
        """Test successful ML-KEM+X25519 stanza decryption."""

        # Generate keys
        import oqs

        kem = oqs.KeyEncapsulation("ML-KEM-1024")
        mlkem_pk = kem.generate_keypair()
        mlkem_sk = kem.export_secret_key()

        from nacl.bindings import crypto_scalarmult_base

        x25519_sk_raw = os.urandom(32)
        sk_clamped = bytearray(x25519_sk_raw)
        sk_clamped[0] &= 248
        sk_clamped[31] &= 127
        sk_clamped[31] |= 64
        x25519_sk = bytes(sk_clamped)
        x25519_pk = crypto_scalarmult_base(x25519_sk)

        file_key = os.urandom(FILE_KEY_LEN)

        stanza = mlkem_x25519_encapsulate(mlkem_pk, x25519_pk, file_key)

        # Try decrypt
        recovered = try_decrypt_stanza(
            stanza, x25519_sk=x25519_sk, x25519_pk=x25519_pk, mlkem_sk=mlkem_sk, mlkem_pk=mlkem_pk
        )

        assert recovered == file_key
        kem.free()

    def test_try_decrypt_scrypt_success(self) -> None:
        """Test successful scrypt stanza decryption."""
        password = "test_password"
        file_key = os.urandom(FILE_KEY_LEN)

        stanza = scrypt_encapsulate(password, file_key, log_n=10)

        # Try decrypt
        recovered = try_decrypt_stanza(stanza, password=password)

        assert recovered == file_key

        # Wrong password should fail
        recovered_fail = try_decrypt_stanza(stanza, password="wrong")
        assert recovered_fail is None

    def test_try_decrypt_unknown_stanza_type(self) -> None:
        """Test unknown stanza type."""
        from pqage.age_format import Stanza

        stanza = Stanza(stanza_type="unknown-type", args=["arg"], body=b"data")

        recovered = try_decrypt_stanza(stanza)
        assert recovered is None

    def test_try_decrypt_missing_keys(self) -> None:
        """Test decryption with missing keys."""
        # X25519 stanza without keys
        from nacl.bindings import crypto_scalarmult_base

        sk = os.urandom(32)
        sk = bytearray(sk)
        sk[0] &= 248
        sk[31] &= 127
        sk[31] |= 64
        sk = bytes(sk)
        pk = crypto_scalarmult_base(sk)

        file_key = os.urandom(FILE_KEY_LEN)
        stanza = x25519_encapsulate(pk, file_key)

        # Without keys
        recovered = try_decrypt_stanza(stanza)
        assert recovered is None


class TestRecipientConstants:
    """Test recipient constants."""

    def test_file_key_length(self) -> None:
        """Test file key length constant (age spec: 128-bit file key)."""
        assert FILE_KEY_LEN == 16  # age uses 128-bit (16 byte) file key

    def test_recipient_key_lengths(self) -> None:
        """Test recipient key length constants."""
        # age spec: 16-byte file key
        assert FILE_KEY_LEN == 16


class TestMlkemX25519ImplicitRejection:
    """
    Test ML-KEM implicit rejection behavior in mlkem-x25519 recipient.

    ML-KEM uses "implicit rejection" - wrong ciphertext produces
    wrong (but deterministic) shared secret instead of an error.
    We must verify this produces different file keys.
    """

    @pytest.fixture
    def mlkem_keypair(self) -> tuple[bytes, bytes]:
        """Generate ML-KEM keypair for testing."""
        pytest.importorskip("oqs")
        import oqs

        kem = oqs.KeyEncapsulation("ML-KEM-1024")
        pk = kem.generate_keypair()
        sk = kem.export_secret_key()
        kem.free()
        return pk, sk

    @pytest.fixture
    def x25519_keypair(self) -> tuple[bytes, bytes]:
        """Generate X25519 keypair for testing."""
        from nacl.bindings import crypto_scalarmult_base

        sk = os.urandom(32)
        sk = bytearray(sk)
        sk[0] &= 248
        sk[31] &= 127
        sk[31] |= 64
        sk = bytes(sk)
        pk = crypto_scalarmult_base(sk)
        return sk, pk

    @pytest.mark.skipif(
        not pytest.importorskip("oqs", reason="liboqs not available"),
        reason="ML-KEM tests require liboqs",
    )
    def test_corrupted_mlkem_ciphertext_produces_different_key(
        self, mlkem_keypair: tuple, x25519_keypair: tuple
    ) -> None:
        """Test that corrupted ML-KEM CT leads to different file key."""
        mlkem_pk, mlkem_sk = mlkem_keypair
        x25519_sk, x25519_pk = x25519_keypair
        file_key = os.urandom(FILE_KEY_LEN)

        # Encapsulate
        stanza = mlkem_x25519_encapsulate(mlkem_pk, x25519_pk, file_key)

        # Verify normal decapsulation works
        recovered_key = mlkem_x25519_decapsulate(stanza, mlkem_sk, x25519_sk, mlkem_pk, x25519_pk)
        assert recovered_key == file_key, "Normal decapsulation failed!"

        # Corrupt the ML-KEM ciphertext
        corrupted_ct = bytearray(stanza.mlkem_ciphertext)
        corrupted_ct[100] ^= 0xFF
        corrupted_ct = bytes(corrupted_ct)

        # Create corrupted stanza using factory method
        corrupted_stanza = MlkemX25519Stanza.create(
            key_fingerprint=stanza.key_fingerprint,
            mlkem_ciphertext=corrupted_ct,
            x25519_ephemeral=stanza.x25519_ephemeral,
            body=stanza.body,
        )

        # Decapsulation with corrupted CT should produce DIFFERENT key
        # (implicit rejection behavior)
        try:
            wrong_key = mlkem_x25519_decapsulate(
                corrupted_stanza, mlkem_sk, x25519_sk, mlkem_pk, x25519_pk
            )
            # If we got here, key MUST be different
            assert wrong_key != file_key, (
                "CRITICAL: Corrupted ML-KEM CT produced same file key! "
                "Implicit rejection is not working correctly."
            )
        except DecryptionError:
            # Also acceptable - decryption failure
            pass

    @pytest.mark.skipif(
        not pytest.importorskip("oqs", reason="liboqs not available"),
        reason="ML-KEM tests require liboqs",
    )
    def test_wrong_mlkem_sk_produces_different_key(
        self, mlkem_keypair: tuple, x25519_keypair: tuple
    ) -> None:
        """Test that wrong ML-KEM secret key produces different file key."""
        mlkem_pk, mlkem_sk = mlkem_keypair
        x25519_sk, x25519_pk = x25519_keypair
        file_key = os.urandom(FILE_KEY_LEN)

        # Encapsulate for correct keys
        stanza = mlkem_x25519_encapsulate(mlkem_pk, x25519_pk, file_key)

        # Generate different ML-KEM keypair (attacker's keys)
        import oqs

        attacker_kem = oqs.KeyEncapsulation("ML-KEM-1024")
        attacker_kem.generate_keypair()
        attacker_mlkem_sk = attacker_kem.export_secret_key()
        attacker_kem.free()

        # Try to decapsulate with attacker's ML-KEM SK (but correct X25519)
        try:
            wrong_key = mlkem_x25519_decapsulate(
                stanza, attacker_mlkem_sk, x25519_sk, mlkem_pk, x25519_pk
            )
            # Implicit rejection: should get wrong key
            assert wrong_key != file_key, (
                "CRITICAL: Wrong ML-KEM SK produced correct file key! "
                "This breaks the hybrid security model."
            )
        except DecryptionError:
            # Also acceptable
            pass

    @pytest.mark.skipif(
        not pytest.importorskip("oqs", reason="liboqs not available"),
        reason="ML-KEM tests require liboqs",
    )
    def test_wrong_x25519_sk_fails_decapsulation(
        self, mlkem_keypair: tuple, x25519_keypair: tuple
    ) -> None:
        """Test that wrong X25519 secret key fails decapsulation."""
        mlkem_pk, mlkem_sk = mlkem_keypair
        x25519_sk, x25519_pk = x25519_keypair
        file_key = os.urandom(FILE_KEY_LEN)

        stanza = mlkem_x25519_encapsulate(mlkem_pk, x25519_pk, file_key)

        # Generate different X25519 keypair
        wrong_x25519_sk = os.urandom(32)

        # Decapsulation should fail (wrong shared secret → wrong wrapping key)
        with pytest.raises(DecryptionError):
            mlkem_x25519_decapsulate(stanza, mlkem_sk, wrong_x25519_sk, mlkem_pk, x25519_pk)

    @pytest.mark.skipif(
        not pytest.importorskip("oqs", reason="liboqs not available"),
        reason="ML-KEM tests require liboqs",
    )
    def test_hybrid_security_requires_both_keys_correct(
        self, mlkem_keypair: tuple, x25519_keypair: tuple
    ) -> None:
        """
        Test that BOTH ML-KEM and X25519 must be correct for successful decapsulation.

        This is the core security property of hybrid encryption:
        - If ML-KEM is broken, X25519 still protects
        - If X25519 is broken, ML-KEM still protects
        """
        mlkem_pk, mlkem_sk = mlkem_keypair
        x25519_sk, x25519_pk = x25519_keypair
        file_key = os.urandom(FILE_KEY_LEN)

        stanza = mlkem_x25519_encapsulate(mlkem_pk, x25519_pk, file_key)

        # Correct decapsulation
        recovered = mlkem_x25519_decapsulate(stanza, mlkem_sk, x25519_sk, mlkem_pk, x25519_pk)
        assert recovered == file_key

        # Generate attacker keys
        import oqs

        attacker_kem = oqs.KeyEncapsulation("ML-KEM-1024")
        attacker_kem.generate_keypair()
        attacker_mlkem_sk = attacker_kem.export_secret_key()
        attacker_kem.free()

        attacker_x25519_sk = os.urandom(32)

        # Test all combinations of wrong keys
        wrong_combinations = [
            (attacker_mlkem_sk, x25519_sk, "wrong ML-KEM SK"),
            (mlkem_sk, attacker_x25519_sk, "wrong X25519 SK"),
            (attacker_mlkem_sk, attacker_x25519_sk, "both wrong"),
        ]

        for wrong_mlkem_sk, wrong_x25519_sk, desc in wrong_combinations:
            try:
                wrong_key = mlkem_x25519_decapsulate(
                    stanza, wrong_mlkem_sk, wrong_x25519_sk, mlkem_pk, x25519_pk
                )
                # If we got here, must be wrong key
                assert wrong_key != file_key, (
                    f"CRITICAL: {desc} produced correct file key! Hybrid security is broken."
                )
            except DecryptionError:
                # Expected - wrong key causes authentication failure
                pass
