"""
Tests for age STREAM cipher implementation.

Tests age_stream.py: ChaCha20-Poly1305 STREAM encryption/decryption.
"""

import pytest

from pqage.crypto.age_stream import (
    STREAM_CHUNK_SIZE,
    STREAM_NONCE_PREFIX_LEN,
    _derive_stream_nonce,
    stream_decrypt,
    stream_decrypt_bytes,
    stream_encrypt,
    stream_encrypt_bytes,
)
from pqage.exceptions import DecryptionError, EncryptionError


class TestStreamNonceDerivation:
    """Test STREAM nonce derivation (age-compatible counter-based)."""

    def test_derive_stream_nonce_basic(self) -> None:
        """Test basic nonce derivation - counter 0, not final."""
        counter = 0
        is_final = False

        nonce = _derive_stream_nonce(counter, is_final)

        assert len(nonce) == 12
        # First 11 bytes: big-endian counter (0)
        assert nonce[:11] == b"\x00" * 11
        # Last byte: 0x00 (not final)
        assert nonce[11] == 0x00

    def test_derive_stream_nonce_with_counter(self) -> None:
        """Test nonce derivation with non-zero counter."""
        counter = 1
        is_final = False

        nonce = _derive_stream_nonce(counter, is_final)

        assert len(nonce) == 12
        # First 11 bytes: big-endian counter (1)
        assert nonce[:11] == b"\x00" * 10 + b"\x01"
        # Last byte: 0x00 (not final)
        assert nonce[11] == 0x00

    def test_derive_stream_nonce_final(self) -> None:
        """Test nonce derivation for final chunk."""
        counter = 0
        is_final = True

        nonce = _derive_stream_nonce(counter, is_final)

        assert len(nonce) == 12
        # First 11 bytes: big-endian counter (0)
        assert nonce[:11] == b"\x00" * 11
        # Last byte: 0x01 (final)
        assert nonce[11] == 0x01

    def test_derive_stream_nonce_large_counter(self) -> None:
        """Test nonce derivation with large counter."""
        counter = 0x0102030405  # Large counter
        is_final = False

        nonce = _derive_stream_nonce(counter, is_final)

        assert len(nonce) == 12
        # First 11 bytes: big-endian counter
        expected_counter = counter.to_bytes(11, "big")
        assert nonce[:11] == expected_counter
        # Last byte: 0x00 (not final)
        assert nonce[11] == 0x00

    def test_derive_stream_nonce_deterministic(self) -> None:
        """Test that nonce derivation is deterministic."""
        counter = 42
        is_final = True

        nonce1 = _derive_stream_nonce(counter, is_final)
        nonce2 = _derive_stream_nonce(counter, is_final)

        assert nonce1 == nonce2


class TestStreamEncryptDecryptBytes:
    """Test bytes-based STREAM operations."""

    def test_stream_encrypt_decrypt_roundtrip(self) -> None:
        """Test basic encrypt/decrypt roundtrip."""
        key = b"k" * 32
        plaintext = b"Hello, world! This is a test message."

        ciphertext = stream_encrypt_bytes(plaintext, key)
        decrypted = stream_decrypt_bytes(ciphertext, key)

        assert decrypted == plaintext

    def test_stream_encrypt_decrypt_empty_data(self) -> None:
        """Test encrypting empty data."""
        key = b"k" * 32
        plaintext = b""

        ciphertext = stream_encrypt_bytes(plaintext, key)
        decrypted = stream_decrypt_bytes(ciphertext, key)

        assert decrypted == plaintext
        # Empty file should produce minimal ciphertext (empty encrypted chunk + tag)
        assert len(ciphertext) >= 16  # At least the Poly1305 tag

    def test_stream_encrypt_decrypt_large_data(self) -> None:
        """Test encrypting large data (> STREAM_CHUNK_SIZE)."""
        key = b"k" * 32
        plaintext = b"A" * (STREAM_CHUNK_SIZE * 3 + 100)  # Multiple chunks

        ciphertext = stream_encrypt_bytes(plaintext, key)
        decrypted = stream_decrypt_bytes(ciphertext, key)

        assert decrypted == plaintext

    def test_stream_encrypt_decrypt_exact_chunk_size(self) -> None:
        """Test data exactly matching chunk size."""
        key = b"k" * 32
        plaintext = b"B" * STREAM_CHUNK_SIZE

        ciphertext = stream_encrypt_bytes(plaintext, key)
        decrypted = stream_decrypt_bytes(ciphertext, key)

        assert decrypted == plaintext

    def test_stream_encrypt_wrong_key(self) -> None:
        """Test decryption with wrong key fails."""
        key = b"k" * 32
        wrong_key = b"w" * 32
        plaintext = b"Secret message"

        ciphertext = stream_encrypt_bytes(plaintext, key)

        with pytest.raises((DecryptionError, Exception)):
            stream_decrypt_bytes(ciphertext, wrong_key)

    def test_stream_encrypt_invalid_key_length(self) -> None:
        """Test encryption with invalid key length."""
        key = b"short_key"
        plaintext = b"data"

        with pytest.raises(EncryptionError, match="Key must be 32 bytes"):
            stream_encrypt_bytes(plaintext, key)

    def test_stream_decrypt_invalid_key_length(self) -> None:
        """Test decryption with invalid key length."""
        key = b"short_key"
        ciphertext = b"dummy"

        with pytest.raises(DecryptionError, match="Key must be 32 bytes"):
            stream_decrypt_bytes(ciphertext, key)


class TestStreamEncryptDecryptStreams:
    """Test stream-based STREAM operations."""

    def test_stream_encrypt_decrypt_streams(self) -> None:
        """Test stream-based encrypt/decrypt."""
        import io

        key = b"k" * 32
        plaintext = b"Hello, world! This is a test message for streams."

        input_stream = io.BytesIO(plaintext)
        output_stream = io.BytesIO()

        # Encrypt
        bytes_written = stream_encrypt(input_stream, output_stream, key)
        ciphertext = output_stream.getvalue()

        # Decrypt
        input_stream = io.BytesIO(ciphertext)
        output_stream = io.BytesIO()

        stream_decrypt(input_stream, output_stream, key)
        decrypted = output_stream.getvalue()

        assert decrypted == plaintext
        assert bytes_written == len(ciphertext)

    def test_stream_encrypt_large_file_simulation(self) -> None:
        """Test simulating large file encryption."""
        import io

        key = b"k" * 32

        # Create large data (simulate file larger than memory)
        large_data = b"X" * (STREAM_CHUNK_SIZE * 2 + 500)

        input_stream = io.BytesIO(large_data)
        output_stream = io.BytesIO()

        bytes_written = stream_encrypt(input_stream, output_stream, key)
        ciphertext = output_stream.getvalue()

        # Verify ciphertext is larger than plaintext (tag overhead)
        assert len(ciphertext) > len(large_data)

        # Decrypt
        input_stream = io.BytesIO(ciphertext)
        output_stream = io.BytesIO()

        bytes_read = stream_decrypt(input_stream, output_stream, key)
        decrypted = output_stream.getvalue()

        assert decrypted == large_data
        assert bytes_read == len(large_data)


class TestStreamChunking:
    """Test STREAM chunking behavior."""

    def test_stream_chunking_single_chunk(self) -> None:
        """Test single chunk encryption."""
        key = b"k" * 32
        small_data = b"small"

        ciphertext = stream_encrypt_bytes(small_data, key)

        # Ciphertext contains: encrypted_chunk + tag
        min_expected = len(small_data) + 16  # ChaCha20 Poly1305 tag
        assert len(ciphertext) >= min_expected

        decrypted = stream_decrypt_bytes(ciphertext, key)
        assert decrypted == small_data

    def test_stream_chunking_multiple_chunks(self) -> None:
        """Test multiple chunk encryption."""
        key = b"k" * 32
        # Create data that spans exactly 3 chunks
        data = b"A" * (STREAM_CHUNK_SIZE * 3)

        ciphertext = stream_encrypt_bytes(data, key)
        decrypted = stream_decrypt_bytes(ciphertext, key)

        assert decrypted == data

    def test_stream_chunking_final_chunk_partial(self) -> None:
        """Test final chunk that is partial."""
        key = b"k" * 32
        # Create data that doesn't align with chunk boundaries
        data = b"B" * (STREAM_CHUNK_SIZE + 100)

        ciphertext = stream_encrypt_bytes(data, key)
        decrypted = stream_decrypt_bytes(ciphertext, key)

        assert decrypted == data


class TestStreamCorruptionDetection:
    """Test that STREAM detects corruption."""

    def test_stream_detect_ciphertext_corruption(self) -> None:
        """Test detection of ciphertext corruption."""
        key = b"k" * 32
        plaintext = b"Test message for corruption detection"

        ciphertext = stream_encrypt_bytes(plaintext, key)

        # Corrupt a byte in the ciphertext
        corrupted = bytearray(ciphertext)
        corrupted[10] ^= 0xFF
        corrupted = bytes(corrupted)

        with pytest.raises((DecryptionError, Exception)):
            stream_decrypt_bytes(corrupted, key)

    def test_stream_detect_truncated_ciphertext(self) -> None:
        """Test detection of truncated ciphertext."""
        key = b"k" * 32
        plaintext = b"Test message"

        ciphertext = stream_encrypt_bytes(plaintext, key)

        # Truncate ciphertext
        truncated = ciphertext[:-10]

        with pytest.raises(DecryptionError):
            stream_decrypt_bytes(truncated, key)


class TestStreamConstants:
    """Test STREAM constants and limits."""

    def test_chunk_size_reasonable(self) -> None:
        """Test that chunk size is reasonable."""
        assert STREAM_CHUNK_SIZE == 64 * 1024  # 64 KB
        assert STREAM_CHUNK_SIZE > 0
        assert STREAM_CHUNK_SIZE % 1024 == 0  # Multiple of 1KB

    def test_nonce_prefix_length_constant(self) -> None:
        """Test nonce prefix length constant exists for documentation."""
        # This constant is kept for documentation purposes
        # It represents the 11-byte counter portion of the 12-byte nonce
        assert STREAM_NONCE_PREFIX_LEN == 11
