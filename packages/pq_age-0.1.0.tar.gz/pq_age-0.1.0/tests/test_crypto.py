"""
🧪 Tests for pq-age cryptographic primitives.

Tests cover:
- Key generation
- Symmetric encryption/decryption
- Password-based key wrapping
"""

import pytest

from pqage.constants import (
    COMBINED_PUBLIC_KEY_LEN,
    XCHACHA20_KEY_LEN,
    XCHACHA20_NONCE_LEN,
)
from pqage.crypto.keys import SecureKeyBundle, derive_key, generate_keys
from pqage.crypto.password import unwrap_keys, wrap_keys
from pqage.crypto.symmetric import decrypt, encrypt
from pqage.crypto.utils import secure_wipe
from pqage.exceptions import (
    DecryptionError,
    EncryptionError,
    InvalidCiphertextError,
    InvalidKeyError,
    KeyGenerationError,
    KeyWrappingError,
    PasswordError,
)


class TestKeyGeneration:
    """🧪 Tests for key generation."""

    def test_generate_keys_produces_valid_bundle(self) -> None:
        """Test that generate_keys produces all required key components."""
        keys = generate_keys()

        assert "master_seed" in keys
        assert "x25519_pk" in keys
        assert "x25519_sk" in keys
        assert "kyber_pk" in keys
        assert "kyber_sk" in keys

        assert len(keys["master_seed"]) == 32
        assert len(keys["x25519_pk"]) == 32
        assert len(keys["x25519_sk"]) == 32
        assert len(keys["kyber_pk"]) == 1568
        assert len(keys["kyber_sk"]) == 3168

    def test_generate_keys_deterministic_with_seed(self) -> None:
        """Test that same seed produces same keys."""
        seed = b"A" * 32
        keys1 = generate_keys(seed)
        keys2 = generate_keys(seed)

        assert keys1["x25519_pk"] == keys2["x25519_pk"]
        assert keys1["x25519_sk"] == keys2["x25519_sk"]
        assert keys1["kyber_pk"] == keys2["kyber_pk"]
        assert keys1["kyber_sk"] == keys2["kyber_sk"]

    def test_generate_keys_different_seeds_different_keys(self) -> None:
        """Test that different seeds produce different keys."""
        keys1 = generate_keys(b"A" * 32)
        keys2 = generate_keys(b"B" * 32)

        assert keys1["x25519_pk"] != keys2["x25519_pk"]
        assert keys1["kyber_pk"] != keys2["kyber_pk"]

    def test_generate_keys_invalid_seed_length(self) -> None:
        """Test that invalid seed length raises error."""
        with pytest.raises(KeyGenerationError, match="32 bytes"):
            generate_keys(b"short")

    def test_derive_key_empty_material_raises(self) -> None:
        """Test that empty key material raises error."""
        with pytest.raises(KeyGenerationError, match="cannot be empty"):
            derive_key(b"", b"context")

    def test_derive_key_empty_context_raises(self) -> None:
        """Test that empty context raises error."""
        with pytest.raises(KeyGenerationError, match="cannot be empty"):
            derive_key(b"material", b"")

    def test_derive_key_returns_bytearray(self) -> None:
        """Test that derive_key returns a wipeable bytearray."""
        result = derive_key(b"material", b"context")
        assert isinstance(result, bytearray)
        assert len(result) == 32

    def test_derive_key_accepts_bytearray(self) -> None:
        """Test that derive_key accepts bytearray input."""
        material = bytearray(b"A" * 32)
        result = derive_key(material, b"context")
        assert isinstance(result, bytearray)
        assert len(result) == 32

    def test_derive_key_accepts_memoryview(self) -> None:
        """Test that derive_key accepts memoryview input."""
        material = memoryview(b"B" * 32)
        result = derive_key(material, b"context")
        assert isinstance(result, bytearray)
        assert len(result) == 32


class TestSecureKeyBundle:
    """🧪 Tests for SecureKeyBundle with secure memory handling."""

    def test_generate_produces_valid_bundle(self) -> None:
        """Test that SecureKeyBundle.generate() produces all required keys."""
        with SecureKeyBundle.generate() as keys:
            assert len(keys.master_seed) == 32
            assert len(keys.x25519_pk) == 32
            assert len(keys.x25519_sk) == 32
            assert len(keys.kyber_pk) == 1568
            assert len(keys.kyber_sk) == 3168

    def test_generate_deterministic_with_seed(self) -> None:
        """Test that same seed produces same keys."""
        seed = b"C" * 32
        with SecureKeyBundle.generate(seed) as keys1:
            x25519_pk1 = keys1.x25519_pk
            kyber_pk1 = keys1.kyber_pk

        with SecureKeyBundle.generate(seed) as keys2:
            assert keys2.x25519_pk == x25519_pk1
            assert keys2.kyber_pk == kyber_pk1

    def test_context_manager_wipes_on_exit(self) -> None:
        """Test that context manager wipes keys on exit."""
        keys = SecureKeyBundle.generate()
        assert not keys.is_wiped

        with keys:
            assert not keys.is_wiped

        assert keys.is_wiped

    def test_access_after_wipe_raises(self) -> None:
        """Test that accessing wiped keys raises ValueError."""
        keys = SecureKeyBundle.generate()
        keys.wipe()

        with pytest.raises(ValueError, match="wiped"):
            _ = keys.master_seed

        with pytest.raises(ValueError, match="wiped"):
            _ = keys.x25519_sk

    def test_dict_like_access(self) -> None:
        """Test dict-like access for convenience."""
        with SecureKeyBundle.generate() as keys:
            assert keys["x25519_pk"] == keys.x25519_pk
            assert keys["kyber_pk"] == keys.kyber_pk
            assert "x25519_pk" in keys

    def test_multiple_wipe_safe(self) -> None:
        """Test that calling wipe multiple times is safe."""
        keys = SecureKeyBundle.generate()
        keys.wipe()
        keys.wipe()  # Should not raise
        assert keys.is_wiped

    def test_context_manager_on_exception(self) -> None:
        """Test that context manager wipes even on exception."""
        keys = SecureKeyBundle.generate()

        try:
            with keys:
                raise RuntimeError("Test exception")
        except RuntimeError:
            pass

        assert keys.is_wiped


class TestSecureWipe:
    """🧪 Tests for secure_wipe function."""

    def test_secure_wipe_zeroes_bytearray(self) -> None:
        """Test that secure_wipe zeroes a bytearray."""
        data = bytearray(b"sensitive data here!")
        secure_wipe(data)
        assert all(b == 0 for b in data)

    def test_secure_wipe_handles_empty_bytearray(self) -> None:
        """Test that secure_wipe handles empty bytearray."""
        data = bytearray()
        secure_wipe(data)
        assert len(data) == 0

    def test_secure_wipe_warns_on_bytes(self) -> None:
        """Test that secure_wipe handles bytes gracefully (no crash)."""
        # Should not raise, just warn
        data = b"immutable"
        secure_wipe(data)  # type: ignore


class TestSymmetricEncryption:
    """🧪 Tests for symmetric encryption/decryption."""

    def test_encrypt_decrypt_roundtrip(self) -> None:
        """Test basic encrypt/decrypt roundtrip."""
        key = b"A" * XCHACHA20_KEY_LEN
        plaintext = b"Hello, World!"

        ciphertext = encrypt(plaintext, key)
        decrypted = decrypt(ciphertext, key)

        assert decrypted == plaintext

    def test_encrypt_decrypt_with_aad(self) -> None:
        """Test encrypt/decrypt with additional authenticated data."""
        key = b"B" * XCHACHA20_KEY_LEN
        plaintext = b"Secret message"
        aad = b"file.txt"

        ciphertext = encrypt(plaintext, key, aad)
        decrypted = decrypt(ciphertext, key, aad)

        assert decrypted == plaintext

    def test_decrypt_wrong_aad_fails(self) -> None:
        """Test that wrong AAD causes decryption failure."""
        key = b"C" * XCHACHA20_KEY_LEN
        plaintext = b"Secret"

        ciphertext = encrypt(plaintext, key, b"correct_aad")

        with pytest.raises(DecryptionError):
            decrypt(ciphertext, key, b"wrong_aad")

    def test_decrypt_wrong_key_fails(self) -> None:
        """Test that wrong key causes decryption failure."""
        key1 = b"D" * XCHACHA20_KEY_LEN
        key2 = b"E" * XCHACHA20_KEY_LEN
        plaintext = b"Secret"

        ciphertext = encrypt(plaintext, key1)

        with pytest.raises(DecryptionError):
            decrypt(ciphertext, key2)

    def test_encrypt_invalid_key_length(self) -> None:
        """Test that invalid key length raises error."""
        with pytest.raises(EncryptionError, match="32 bytes"):
            encrypt(b"data", b"short")

    def test_decrypt_invalid_key_length(self) -> None:
        """Test that invalid key length raises error."""
        with pytest.raises(DecryptionError, match="32 bytes"):
            decrypt(b"X" * 50, b"short")

    def test_decrypt_too_short_ciphertext(self) -> None:
        """Test that too short ciphertext raises error."""
        key = b"F" * XCHACHA20_KEY_LEN

        with pytest.raises(InvalidCiphertextError, match="too short"):
            decrypt(b"short", key)

    def test_encrypt_empty_plaintext(self) -> None:
        """Test encrypting empty plaintext."""
        key = b"G" * XCHACHA20_KEY_LEN
        ciphertext = encrypt(b"", key)
        decrypted = decrypt(ciphertext, key)

        assert decrypted == b""

    def test_encrypt_large_data(self) -> None:
        """Test encrypting larger data (1 MB)."""
        key = b"H" * XCHACHA20_KEY_LEN
        plaintext = b"X" * (1024 * 1024)

        ciphertext = encrypt(plaintext, key)
        decrypted = decrypt(ciphertext, key)

        assert decrypted == plaintext

    def test_ciphertext_includes_nonce(self) -> None:
        """Test that ciphertext includes nonce prefix."""
        key = b"I" * XCHACHA20_KEY_LEN
        ciphertext = encrypt(b"data", key)

        # Ciphertext = nonce (24) + encrypted + tag (16)
        assert len(ciphertext) >= XCHACHA20_NONCE_LEN + 16


class TestPasswordWrapping:
    """🧪 Tests for password-based key wrapping."""

    @pytest.fixture
    def keys(self) -> SecureKeyBundle:
        """Generate test keys."""
        return generate_keys()

    def test_wrap_unwrap_roundtrip(self, keys: SecureKeyBundle) -> None:
        """Test that wrapped keys can be unwrapped."""
        password = "secure_password_123"

        wrapped = wrap_keys(keys, password)
        unwrapped = unwrap_keys(wrapped, password)

        # Keys should be regenerated identically from master seed
        assert unwrapped["master_seed"] == keys["master_seed"]
        assert unwrapped["x25519_pk"] == keys["x25519_pk"]
        assert unwrapped["kyber_pk"] == keys["kyber_pk"]

    def test_wrap_produces_correct_prefix(self, keys: SecureKeyBundle) -> None:
        """Test that wrapped data has correct prefix."""
        wrapped = wrap_keys(keys, "password")
        assert wrapped.startswith(b"PQAGEKEYv1")

    def test_unwrap_wrong_password_fails(self, keys: SecureKeyBundle) -> None:
        """Test that wrong password fails."""
        wrapped = wrap_keys(keys, "correct_password")

        with pytest.raises(PasswordError, match="Incorrect password"):
            unwrap_keys(wrapped, "wrong_password")

    def test_wrap_empty_password_fails(self, keys: SecureKeyBundle) -> None:
        """Test that empty password fails."""
        with pytest.raises(PasswordError, match="cannot be empty"):
            wrap_keys(keys, "")

    def test_unwrap_empty_password_fails(self, keys: SecureKeyBundle) -> None:
        """Test that empty password fails on unwrap."""
        wrapped = wrap_keys(keys, "password")

        with pytest.raises(PasswordError, match="cannot be empty"):
            unwrap_keys(wrapped, "")

    def test_unwrap_invalid_prefix_fails(self) -> None:
        """Test that invalid prefix fails."""
        with pytest.raises(KeyWrappingError, match="wrong prefix"):
            unwrap_keys(b"INVALID_DATA_HERE", "password")

    def test_unwrap_truncated_data_fails(self) -> None:
        """Test that truncated data fails."""
        with pytest.raises(KeyWrappingError, match="too short"):
            unwrap_keys(b"PQAGEKEYv1" + b"X" * 10, "password")

    def test_wrap_unicode_password(self, keys: SecureKeyBundle) -> None:
        """Test wrapping with unicode password."""
        password = "пароль_密码_🔐"

        wrapped = wrap_keys(keys, password)
        unwrapped = unwrap_keys(wrapped, password)

        assert unwrapped["master_seed"] == keys["master_seed"]


class TestEndToEnd:
    """🧪 End-to-end tests combining all cryptographic operations."""

    def test_full_encryption_workflow_with_age_format(self) -> None:
        """Test complete encryption workflow using age file format."""
        from pqage.age_file_ops import (
            MlkemX25519Identity,
            MlkemX25519Recipient,
        )
        from pqage.age_file_ops import (
            decrypt as age_decrypt,
        )
        from pqage.age_file_ops import (
            encrypt as age_encrypt,
        )

        # Bob generates keys and protects them with password
        bob_keys = generate_keys()
        bob_wrapped = wrap_keys(bob_keys, "bob_secret_password")

        # Create recipient from Bob's public keys
        bob_recipient = MlkemX25519Recipient(
            mlkem_pk=bob_keys["kyber_pk"],
            x25519_pk=bob_keys["x25519_pk"],
        )

        # Alice encrypts for Bob using age format
        plaintext = b"Top secret message from Alice to Bob"
        ciphertext = age_encrypt(plaintext, [bob_recipient])

        # Bob unwraps his keys and decrypts
        bob_unwrapped = unwrap_keys(bob_wrapped, "bob_secret_password")
        bob_identity = MlkemX25519Identity(
            mlkem_sk=bob_unwrapped["kyber_sk"],
            mlkem_pk=bob_unwrapped["kyber_pk"],
            x25519_sk=bob_unwrapped["x25519_sk"],
            x25519_pk=bob_unwrapped["x25519_pk"],
        )

        decrypted = age_decrypt(ciphertext, [bob_identity])

        assert decrypted == plaintext

    def test_combined_public_key_length(self) -> None:
        """Test that combined public key has correct length."""
        keys = generate_keys()
        combined = keys["x25519_pk"] + keys["kyber_pk"]

        assert len(combined) == COMBINED_PUBLIC_KEY_LEN
