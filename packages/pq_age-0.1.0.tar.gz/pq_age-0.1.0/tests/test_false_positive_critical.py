"""
CRITICAL FALSE POSITIVE TESTS for pq-age.

These tests are designed to FAIL if critical security features are removed
or broken. Each test validates that a specific security mechanism cannot
be bypassed without detection.

Security Principle: Tests that always pass regardless of implementation
bugs are FALSE POSITIVES and provide a dangerous illusion of security.

These tests go beyond simple code inspection - they verify actual behavior
that would change if security features were removed.
"""

import inspect
import os

import pytest
from hypothesis import assume, given, settings
from hypothesis import strategies as st

from pqage.constants import (
    KYBER_CIPHERTEXT_LEN,
    XCHACHA20_KEY_LEN,
)
from pqage.crypto.keys import generate_keys
from pqage.crypto.utils import secure_compare, secure_wipe
from pqage.exceptions import DecryptionError

# =============================================================================
# TEST 1: Clamping Removal Detection
# =============================================================================


class TestClampingRemovalDetection:
    """
    Test that UNCLAMPED scalars produce DIFFERENT keys.

    This test MUST FAIL if clamping is removed from _generate_ephemeral_x25519
    or _derive_x25519_scalar. X25519 RFC 7748 requires clamping to prevent
    small-subgroup attacks.

    Clamping rules:
        - scalar[0] &= 248  (clear 3 low bits)
        - scalar[31] &= 127 (clear high bit)
        - scalar[31] |= 64  (set second-highest bit)
    """

    def test_clamping_is_applied_in_generated_keys(self) -> None:
        """
        Verify generated keys have clamping applied.

        Note: PyNaCl's crypto_scalarmult_base automatically applies clamping,
        so we cannot test raw vs clamped scalars at that level. Instead,
        we verify that our key generation code produces properly clamped
        secret keys.
        """
        # Use a seed where clamping would make a difference if not applied
        # Setting bits that clamping should clear
        test_seed = b"\xff" + b"\x00" * 30 + b"\xff"

        keys = generate_keys(test_seed)
        sk = keys["x25519_sk"]

        # The secret key MUST be properly clamped per RFC 7748
        assert sk[0] & 0b111 == 0, (
            f"CRITICAL: Generated key not clamped - low bits set! Got first byte: 0x{sk[0]:02x}"
        )
        assert sk[31] & 0b10000000 == 0, (
            f"CRITICAL: Generated key not clamped - high bit set! Got last byte: 0x{sk[31]:02x}"
        )
        assert sk[31] & 0b01000000 != 0, (
            "CRITICAL: Generated key not clamped - second-high bit not set! "
            f"Got last byte: 0x{sk[31]:02x}"
        )

    def test_clamping_code_exists_in_key_generation(self) -> None:
        """
        Verify clamping code exists in key generation (code inspection).

        This ensures someone doesn't accidentally remove clamping code.
        """
        from pqage.crypto import keys

        source = inspect.getsource(keys._derive_x25519_scalar)

        # Must use clamp_scalar from x25519 module
        # (clamping logic is centralized in pqage/crypto/x25519.py)
        has_clamp_scalar = "clamp_scalar" in source
        assert has_clamp_scalar, (
            "CRITICAL: clamp_scalar not found in _derive_x25519_scalar! "
            "X25519 scalar clamping may not be applied."
        )

    @given(seed=st.binary(min_size=32, max_size=32))
    @settings(max_examples=20)
    def test_clamping_changes_keys_with_bad_bits(self, seed: bytes) -> None:
        """
        Property: Seeds with bad bits MUST produce clamped results.
        """
        # Set bits that clamping would clear
        bad_seed = bytearray(seed)
        bad_seed[0] |= 0b111  # Set low bits
        bad_seed[31] |= 0b10000000  # Set high bit

        keys = generate_keys(bytes(bad_seed))
        sk = keys["x25519_sk"]

        # After clamping, these bits MUST be correct
        assert sk[0] & 0b111 == 0, "Low bits not cleared - CLAMPING BROKEN!"
        assert sk[31] & 0b10000000 == 0, "High bit not cleared - CLAMPING BROKEN!"

    def test_ephemeral_keys_are_clamped(self) -> None:
        """
        Verify ephemeral keys generated during encapsulation are clamped.

        Tests the generate_ephemeral function directly.
        """
        from pqage.crypto.x25519 import generate_ephemeral

        # Generate multiple ephemeral keys
        for _ in range(10):
            eph_pk, eph_sk = generate_ephemeral()

            # Ephemeral PK should be on the curve (non-zero, not low-order)
            assert eph_pk != b"\x00" * 32, "Ephemeral PK is all zeros - invalid!"
            assert len(eph_pk) == 32, f"Ephemeral PK wrong length: {len(eph_pk)}"

            # Secret key must be properly clamped
            assert eph_sk[0] & 0b111 == 0, "Ephemeral SK low bits not cleared!"
            assert eph_sk[31] & 0b10000000 == 0, "Ephemeral SK high bit set!"
            assert eph_sk[31] & 0b01000000 != 0, "Ephemeral SK second-high bit not set!"


# =============================================================================
# TEST 2: KDF Transcript Binding (age-compatible format)
# =============================================================================


class TestKDFTranscriptBinding:
    """
    Test that KDF transcript binding produces unique keys.

    Per IETF hybrid KEM requirements, all public values must be bound
    into the key derivation to prevent cross-protocol attacks.
    """

    def test_different_encapsulations_produce_different_keys(self) -> None:
        """
        Verify different encapsulations produce different keys.

        Each encapsulation uses fresh ephemeral keys, so derived keys must differ.
        """
        from pqage.age_file_ops import MlkemX25519Recipient, encrypt

        keys = generate_keys()
        recipient = MlkemX25519Recipient(
            mlkem_pk=keys["kyber_pk"],
            x25519_pk=keys["x25519_pk"],
        )

        # Encrypt twice with same plaintext
        plaintext = b"test"
        ct1 = encrypt(plaintext, [recipient])
        ct2 = encrypt(plaintext, [recipient])

        # Ciphertexts MUST be different (fresh ephemeral keys each time)
        assert ct1 != ct2, (
            "CRITICAL: Two encryptions produced identical ciphertext! "
            "Ephemeral keys are NOT being regenerated."
        )

    def test_transcript_binding_includes_public_keys(self) -> None:
        """
        Verify public keys are bound into KDF (IETF compliance).

        Code inspection to ensure build_transcript includes all required values.
        """
        from pqage.crypto import age_recipients

        source = inspect.getsource(age_recipients.build_transcript)

        # The transcript MUST include all public values
        assert "mlkem_ct" in source, "mlkem_ct not in transcript!"
        assert "x25519_eph" in source, "x25519_eph not in transcript!"
        assert "mlkem_pk" in source, "mlkem_pk not in transcript!"
        assert "x25519_pk" in source, "x25519_pk not in transcript!"

        # Must have protocol ID for domain separation
        assert "PQAGE_PROTOCOL_ID" in source or "protocol" in source.lower(), (
            "Protocol ID not in transcript - domain separation missing!"
        )

    def test_transcript_modification_breaks_decryption(self) -> None:
        """
        Verify that stanza modification breaks decryption.
        """
        from pqage.age_file_ops import (
            MlkemX25519Identity,
            MlkemX25519Recipient,
            decrypt,
            encrypt,
        )

        keys = generate_keys()
        recipient = MlkemX25519Recipient(
            mlkem_pk=keys["kyber_pk"],
            x25519_pk=keys["x25519_pk"],
        )
        identity = MlkemX25519Identity(
            mlkem_sk=keys["kyber_sk"],
            mlkem_pk=keys["kyber_pk"],
            x25519_sk=keys["x25519_sk"],
            x25519_pk=keys["x25519_pk"],
        )

        plaintext = b"Test message for transcript binding"
        ciphertext = encrypt(plaintext, [recipient])

        # Verify original works
        decrypted = decrypt(ciphertext, [identity])
        assert decrypted == plaintext, "Original decryption failed!"

        # Corrupt payload (not header to avoid parsing errors)
        corrupted = bytearray(ciphertext)
        corrupted[-10] ^= 0xFF
        corrupted = bytes(corrupted)

        # Corrupted ciphertext MUST fail
        with pytest.raises(DecryptionError):
            decrypt(corrupted, [identity])


# =============================================================================
# TEST 3: ML-KEM Decapsulation Failure Detection
# =============================================================================


class TestMLKEMDecapsulationFailure:
    """
    Test ML-KEM implicit rejection behavior via age format.

    ML-KEM uses "implicit rejection" - wrong ciphertext produces
    wrong (but deterministic) shared secret instead of error.
    We must verify this leads to downstream decryption failure.
    """

    def test_corrupted_ciphertext_fails_decryption(self) -> None:
        """
        Verify corrupted ciphertext fails decryption.
        """
        from pqage.age_file_ops import (
            MlkemX25519Identity,
            MlkemX25519Recipient,
        )
        from pqage.age_file_ops import (
            decrypt as age_decrypt,
        )
        from pqage.age_file_ops import (
            encrypt as age_encrypt,
        )

        keys = generate_keys()
        recipient = MlkemX25519Recipient(
            mlkem_pk=keys["kyber_pk"],
            x25519_pk=keys["x25519_pk"],
        )
        identity = MlkemX25519Identity(
            mlkem_sk=keys["kyber_sk"],
            mlkem_pk=keys["kyber_pk"],
            x25519_sk=keys["x25519_sk"],
            x25519_pk=keys["x25519_pk"],
        )

        plaintext = b"Test data for ML-KEM implicit rejection"
        ciphertext = age_encrypt(plaintext, [recipient])

        # Corrupt payload (implicit rejection will produce wrong key)
        corrupted = bytearray(ciphertext)
        corrupted[-50] ^= 0xFF  # Flip bits in payload
        corrupted = bytes(corrupted)

        # Decryption MUST fail
        with pytest.raises(DecryptionError):
            age_decrypt(corrupted, [identity])

    def test_wrong_recipient_keys_fail_decryption(self) -> None:
        """
        Verify using wrong recipient keys fails decryption.
        """
        from pqage.age_file_ops import (
            MlkemX25519Identity,
            MlkemX25519Recipient,
        )
        from pqage.age_file_ops import (
            decrypt as age_decrypt,
        )
        from pqage.age_file_ops import (
            encrypt as age_encrypt,
        )

        alice = generate_keys()
        bob = generate_keys()

        # Encrypt for Alice
        alice_recipient = MlkemX25519Recipient(
            mlkem_pk=alice["kyber_pk"],
            x25519_pk=alice["x25519_pk"],
        )
        plaintext = b"Message for Alice only"
        ciphertext = age_encrypt(plaintext, [alice_recipient])

        # Bob tries to decrypt (should fail - wrong keys)
        bob_identity = MlkemX25519Identity(
            mlkem_sk=bob["kyber_sk"],
            mlkem_pk=bob["kyber_pk"],
            x25519_sk=bob["x25519_sk"],
            x25519_pk=bob["x25519_pk"],
        )

        # Bob cannot decrypt Alice's message
        with pytest.raises(DecryptionError):
            age_decrypt(ciphertext, [bob_identity])


# =============================================================================
# TEST 4: Secure Wipe Effectiveness
# =============================================================================


class TestSecureWipeEffectiveness:
    """
    Tests that secure_wipe ACTUALLY zeros memory.

    These tests MUST FAIL if secure_wipe is replaced with pass or noop.
    """

    def test_wipe_zeroes_memory_with_pattern_verification(self) -> None:
        """
        Verify secure_wipe zeroes memory (not just final state).
        """
        # Create buffer with non-zero pattern
        secret = bytearray(b"\xde\xad\xbe\xef" * 100)
        original_len = len(secret)

        # Wipe it
        secure_wipe(secret)

        # Length must be preserved
        assert len(secret) == original_len, "Wipe changed buffer length!"

        # ALL bytes must be zero
        non_zero_positions = [i for i, b in enumerate(secret) if b != 0]
        assert len(non_zero_positions) == 0, (
            f"secure_wipe left {len(non_zero_positions)} non-zero bytes! "
            f"Positions: {non_zero_positions[:10]}... "
            "secure_wipe may be broken or optimized away!"
        )

    def test_wipe_in_age_recipients_clears_shared_secrets(self) -> None:
        """
        Verify age recipient operations wipe shared secrets.

        Code inspection to ensure secure_wipe is called for all secrets.
        """
        from pqage.crypto import age_recipients

        encap_source = inspect.getsource(age_recipients.mlkem_x25519_encapsulate)
        decap_source = inspect.getsource(age_recipients.mlkem_x25519_decapsulate)

        # Both functions MUST have secure_wipe calls in finally block
        encap_wipe_count = encap_source.count("secure_wipe")
        decap_wipe_count = decap_source.count("secure_wipe")

        assert encap_wipe_count >= 4, (
            f"mlkem_x25519_encapsulate has only {encap_wipe_count} "
            "secure_wipe calls (expected >= 4)"
        )

        assert decap_wipe_count >= 4, (
            f"mlkem_x25519_decapsulate has only {decap_wipe_count} "
            "secure_wipe calls (expected >= 4)"
        )

        # Verify finally block exists
        assert "finally:" in encap_source, "No finally block in encapsulate for cleanup!"
        assert "finally:" in decap_source, "No finally block in decapsulate for cleanup!"

    def test_wipe_multiple_patterns(self) -> None:
        """
        Verify secure_wipe uses multiple overwrite patterns (defense in depth).
        """
        from pqage.crypto import utils

        source = inspect.getsource(utils.secure_wipe)

        # Should have multiple for loops for different patterns
        loop_count = source.count("for i in range")
        assert loop_count >= 2, (
            f"secure_wipe only has {loop_count} overwrite pass(es). "
            "Multiple patterns provide defense against memory recovery."
        )

        # Should use 0xFF pattern at some point
        assert "0xFF" in source or "255" in source, (
            "secure_wipe doesn't use 0xFF pattern - single zero-pass may be optimized away!"
        )

    @given(size=st.integers(min_value=1, max_value=10000))
    @settings(max_examples=20)
    def test_wipe_arbitrary_sizes(self, size: int) -> None:
        """
        Property: Wipe works correctly for any buffer size.
        """
        data = bytearray(os.urandom(size))
        secure_wipe(data)

        assert all(b == 0 for b in data), f"Wipe failed for size {size}!"


# =============================================================================
# TEST 5: Compare Digest Usage
# =============================================================================


class TestCompareDigestUsage:
    """
    Test that hmac.compare_digest is actually used (not ==).

    Using == for secret comparison leaks timing information.
    """

    def test_secure_compare_uses_hmac_compare_digest(self) -> None:
        """
        Verify secure_compare uses hmac.compare_digest internally.
        """
        from pqage.crypto import utils

        source = inspect.getsource(utils.secure_compare)

        assert "compare_digest" in source, (
            "secure_compare does not use hmac.compare_digest! Timing attack vulnerability detected."
        )

        # Should NOT use == for the actual comparison
        # (== before compare_digest is OK for type checking)
        lines = source.split("\n")
        for line in lines:
            # This is suspicious - return with == without compare_digest
            if "return" in line and "==" in line and "compare_digest" not in line:
                pytest.fail(
                    f"Suspicious line in secure_compare: {line.strip()} "
                    "May be using == instead of compare_digest for return!"
                )

    def test_secure_compare_returns_correct_results(self) -> None:
        """
        Verify secure_compare produces correct results.
        """
        # Equal values
        assert secure_compare(b"hello", b"hello") is True
        assert secure_compare(b"", b"") is True
        assert secure_compare(b"\x00" * 100, b"\x00" * 100) is True

        # Different values
        assert secure_compare(b"hello", b"world") is False
        assert secure_compare(b"hello", b"hello!") is False
        assert secure_compare(b"\x00", b"\x01") is False

        # Different lengths
        assert secure_compare(b"short", b"much longer") is False

    def test_secure_starts_with_is_constant_time(self) -> None:
        """
        Verify secure_starts_with uses constant-time comparison.
        """
        from pqage.crypto import utils

        source = inspect.getsource(utils.secure_starts_with)

        assert "compare_digest" in source, (
            "secure_starts_with does not use hmac.compare_digest! "
            "Timing attack on prefix check detected."
        )


# =============================================================================
# TEST 6: Age STREAM Nonce Safety
# =============================================================================


class TestAgeStreamNonceSafety:
    """
    Tests for age STREAM nonce construction safety.

    Nonce reuse or predictable nonces completely break ChaCha20 security.
    """

    def test_stream_nonce_derivation_is_deterministic(self) -> None:
        """
        Verify nonce derivation is deterministic (same inputs = same nonce).
        """
        from pqage.crypto.age_stream import _derive_stream_nonce

        counter = 42
        is_final = False

        nonce1 = _derive_stream_nonce(counter, is_final)
        nonce2 = _derive_stream_nonce(counter, is_final)

        assert nonce1 == nonce2, "Nonce derivation is not deterministic!"
        assert len(nonce1) == 12, f"Nonce wrong length: {len(nonce1)}"

    def test_stream_nonce_different_counters(self) -> None:
        """
        Verify different counters produce different nonces.
        """
        from pqage.crypto.age_stream import _derive_stream_nonce

        nonces = set()
        for counter in range(100):
            nonce = _derive_stream_nonce(counter, False)
            assert nonce not in nonces, (
                f"NONCE COLLISION at counter {counter}! This breaks security."
            )
            nonces.add(nonce)

    def test_final_bit_changes_nonce(self) -> None:
        """
        Verify final bit creates different nonce (prevents truncation attacks).
        """
        from pqage.crypto.age_stream import _derive_stream_nonce

        counter = 5

        nonce_intermediate = _derive_stream_nonce(counter, is_final=False)
        nonce_final = _derive_stream_nonce(counter, is_final=True)

        assert nonce_intermediate != nonce_final, (
            "Final bit doesn't change nonce! Truncation attack possible."
        )

        # The difference should be in the last byte (LSB)
        assert nonce_intermediate[:11] == nonce_final[:11], (
            "Final bit affected more than last byte - unexpected!"
        )

    def test_stream_nonce_overflow_handling(self) -> None:
        """
        Verify counter overflow is handled (prevents nonce reuse).
        """
        from pqage.crypto.age_stream import MAX_CHUNK_COUNTER, _derive_stream_nonce

        # Normal counter
        nonce1 = _derive_stream_nonce(0, False)
        nonce2 = _derive_stream_nonce(1, False)
        assert nonce1 != nonce2, "Consecutive counters produced same nonce!"

        # Large counter (near max)
        large_nonce = _derive_stream_nonce(MAX_CHUNK_COUNTER, False)
        assert len(large_nonce) == 12, "Large counter produced wrong nonce size!"

        # All generated nonces should be unique
        test_counters = [0, 1, 100, 1000, MAX_CHUNK_COUNTER // 2, MAX_CHUNK_COUNTER]
        test_nonces = [_derive_stream_nonce(c, False) for c in test_counters]
        assert len(set(test_nonces)) == len(test_nonces), "Nonce collision detected!"

    @given(
        counter=st.integers(min_value=0, max_value=2**20),
        is_final=st.booleans(),
    )
    @settings(max_examples=50)
    def test_nonce_derivation_properties(self, counter: int, is_final: bool) -> None:
        """
        Property: Nonce derivation is consistent and produces valid output.
        """
        from pqage.crypto.age_stream import _derive_stream_nonce

        nonce = _derive_stream_nonce(counter, is_final)

        # Must be correct length
        assert len(nonce) == 12, f"Wrong nonce length: {len(nonce)}"

        # Must be deterministic
        nonce2 = _derive_stream_nonce(counter, is_final)
        assert nonce == nonce2, "Nonce derivation not deterministic!"

        # Different final flag must produce different nonce
        nonce_other = _derive_stream_nonce(counter, not is_final)
        assert nonce != nonce_other, "Final flag doesn't affect nonce!"


# =============================================================================
# TEST 7: Nonce Reuse Detection (CRITICAL)
# =============================================================================


class TestNonceReuseDetection:
    """
    Test that nonce reuse is detected and breaks decryption.

    Nonce reuse in ChaCha20 completely breaks confidentiality.
    These tests MUST FAIL if the system allows nonce reuse.
    """

    def test_same_key_different_data_produces_different_ciphertext(self) -> None:
        """
        Verify same key with different data produces different ciphertexts.

        age STREAM uses counter-based nonces, so each chunk has a unique nonce.
        """
        from pqage.crypto.age_stream import stream_encrypt_bytes

        key = b"K" * 32

        plaintext1 = b"Message one"
        plaintext2 = b"Message two"

        ct1 = stream_encrypt_bytes(plaintext1, key)
        ct2 = stream_encrypt_bytes(plaintext2, key)

        # Different plaintexts MUST produce different ciphertexts
        assert ct1 != ct2, "Different plaintexts should produce different ciphertexts"

    def test_payload_nonce_randomness_in_age_format(self) -> None:
        """
        Verify that age format uses random 16-byte nonce for payload key derivation.

        The 16-byte nonce is written to the start of the payload and used
        with HKDF to derive the payload encryption key.
        """
        from nacl.bindings import crypto_scalarmult_base

        from pqage.age_file_ops import X25519Recipient, encrypt

        sk = b"\x42" * 32
        pk = crypto_scalarmult_base(sk)
        recipient = X25519Recipient(pk)

        plaintext = b"Test message"

        # Encrypt same message twice
        ct1 = encrypt(plaintext, [recipient])
        ct2 = encrypt(plaintext, [recipient])

        # Ciphertexts must differ (random nonce in payload)
        assert ct1 != ct2, "Same plaintext should produce different ciphertexts (random nonce)"

    def test_reused_nonce_xor_attack_detectable(self) -> None:
        """
        Verify that if nonce is reused, the XOR attack becomes possible.

        This test demonstrates WHY nonce reuse is catastrophic:
        C1 XOR C2 = P1 XOR P2 (keystream cancels out).
        """
        from nacl.bindings import crypto_aead_chacha20poly1305_ietf_encrypt

        key = b"K" * 32
        nonce = b"N" * 12  # Fixed nonce - DANGEROUS!

        plaintext1 = b"Attack at dawn!"
        plaintext2 = b"Attack at dusk!"

        ct1 = crypto_aead_chacha20poly1305_ietf_encrypt(plaintext1, b"", nonce, key)
        ct2 = crypto_aead_chacha20poly1305_ietf_encrypt(plaintext2, b"", nonce, key)

        # XOR the ciphertexts (excluding tags)
        ct1_body = ct1[:-16]
        ct2_body = ct2[:-16]
        xored = bytes(a ^ b for a, b in zip(ct1_body, ct2_body))

        # XOR of plaintexts
        pt_xor = bytes(a ^ b for a, b in zip(plaintext1, plaintext2))

        # With nonce reuse, XOR of ciphertexts = XOR of plaintexts!
        assert xored == pt_xor, "Test setup error: XOR property should hold for same nonce"

        # This demonstrates the attack - the test passes, proving nonce reuse is dangerous
        # In production, the random 16-byte HKDF salt prevents key reuse

    def test_stream_encryption_uses_different_nonces_per_chunk(self) -> None:
        """
        Verify that multi-chunk encryption uses different nonces per chunk.
        """
        from pqage.crypto.age_stream import (
            STREAM_CHUNK_SIZE,
            _derive_stream_nonce,
        )

        # Collect nonces for multiple chunks
        nonces = set()
        for counter in range(10):
            for is_final in [False, True]:
                nonce = _derive_stream_nonce(counter, is_final)
                if nonce in nonces:
                    pytest.fail(
                        f"NONCE COLLISION at counter={counter}, final={is_final}! "
                        "Multi-chunk encryption is broken!"
                    )
                nonces.add(nonce)

        # All 20 nonces must be unique
        assert len(nonces) == 20, "Not all nonces are unique!"


# =============================================================================
# TEST 8: Weak KDF Parameters Detection (CRITICAL)
# =============================================================================


class TestWeakKDFParametersDetection:
    """
    Test that weak KDF parameters are rejected.

    Weak scrypt/Argon2 parameters make brute-force attacks trivial.
    """

    def test_scrypt_rejects_very_low_work_factor(self) -> None:
        """
        Verify that scrypt with dangerously low work factor is handled.

        Note: Current implementation accepts log_n 1-30. This test documents
        the minimum accepted value and warns about security implications.
        """
        from pqage.crypto.age_recipients import scrypt_encapsulate
        from pqage.exceptions import InvalidKeyError

        file_key = os.urandom(16)  # age uses 16-byte file keys

        # log_n=0 should be rejected (N=1 is useless)
        with pytest.raises(InvalidKeyError, match="Invalid scrypt log_n"):
            scrypt_encapsulate("password", file_key, log_n=0)

        # log_n=-1 should be rejected
        with pytest.raises(InvalidKeyError, match="Invalid scrypt log_n"):
            scrypt_encapsulate("password", file_key, log_n=-1)

        # log_n=31 should be rejected (would overflow)
        with pytest.raises(InvalidKeyError, match="Invalid scrypt log_n"):
            scrypt_encapsulate("password", file_key, log_n=31)

    def test_scrypt_log_n_range_is_enforced(self) -> None:
        """
        Code inspection to verify log_n validation exists.
        """
        from pqage.crypto import age_recipients

        source = inspect.getsource(age_recipients.scrypt_encapsulate)

        # Must have range check for log_n
        assert "log_n < 1" in source or "log_n >= 1" in source or ("1-30" in source), (
            "scrypt_encapsulate does not validate log_n lower bound! "
            "An attacker could use log_n=0 to create weak-encrypted files."
        )

    def test_argon2_constants_are_secure(self) -> None:
        """
        Verify Argon2 constants meet security requirements.
        """
        from pqage.constants import ARGON2_MEMLIMIT, ARGON2_OPSLIMIT

        # OWASP recommends minimum 19 MiB for Argon2id
        # We use 256 MiB which is SENSITIVE level
        assert ARGON2_MEMLIMIT >= 64 * 1024 * 1024, (
            f"ARGON2_MEMLIMIT too low: {ARGON2_MEMLIMIT / (1024 * 1024):.0f} MiB. "
            "Minimum 64 MiB required for moderate security."
        )

        # OWASP recommends minimum 2 iterations
        assert ARGON2_OPSLIMIT >= 2, (
            f"ARGON2_OPSLIMIT too low: {ARGON2_OPSLIMIT}. Minimum 2 iterations required."
        )

        # Log current settings for audit trail
        print(
            f"Argon2 settings: opslimit={ARGON2_OPSLIMIT}, "
            f"memlimit={ARGON2_MEMLIMIT / (1024 * 1024):.0f} MiB"
        )

    def test_scrypt_minimum_recommended_work_factor(self) -> None:
        """
        Document and test minimum recommended scrypt work factor.

        age default is log_n=18 (N=262144). Anything below 14 is concerning.
        """
        from pqage.crypto.age_recipients import SCRYPT_DEFAULT_LOG_N

        # Default should be at least 14 for any security
        assert SCRYPT_DEFAULT_LOG_N >= 14, (
            f"SCRYPT_DEFAULT_LOG_N={SCRYPT_DEFAULT_LOG_N} is too low! "
            "Minimum 14 (N=16384) required for basic security, "
            "18+ recommended for password protection."
        )


# =============================================================================
# TEST 9: Invalid Stanza Fuzzing (HIGH)
# =============================================================================


class TestInvalidStanzaFuzzing:
    """
    Fuzz tests for invalid stanza data in age format.

    Invalid stanzas must be rejected gracefully, not crash.
    """

    @given(garbage=st.binary(min_size=1, max_size=100))
    @settings(max_examples=30)
    def test_invalid_stanza_body_rejected(self, garbage: bytes) -> None:
        """
        Property: Invalid stanza body must be handled gracefully.
        """
        from pqage.age_file_ops import MlkemX25519Identity, decrypt
        from pqage.exceptions import InvalidFileError

        keys = generate_keys()
        identity = MlkemX25519Identity(
            mlkem_sk=keys["kyber_sk"],
            mlkem_pk=keys["kyber_pk"],
            x25519_sk=keys["x25519_sk"],
            x25519_pk=keys["x25519_pk"],
        )

        # Garbage data should be rejected
        try:
            decrypt(garbage, [identity])
            # If we got here, garbage somehow decrypted - suspicious
            pytest.fail("Garbage data decrypted successfully!")
        except (InvalidFileError, DecryptionError, ValueError):
            pass  # Expected - invalid data rejected


# =============================================================================
# TEST 10: Corrupt age File Detection (HIGH)
# =============================================================================


class TestCorruptAgeFileDetection:
    """
    Test detection of corrupted age files.

    Corrupted files must be detected and rejected, not silently decrypted.
    """

    @pytest.fixture
    def valid_age_data(self) -> tuple[bytes, bytes, bytes]:
        """Create valid age-encrypted data for corruption tests."""
        from nacl.bindings import crypto_scalarmult_base

        from pqage import X25519Recipient, encrypt

        # Generate key
        sk = os.urandom(32)
        sk = bytearray(sk)
        sk[0] &= 248
        sk[31] &= 127
        sk[31] |= 64
        sk = bytes(sk)
        pk = crypto_scalarmult_base(sk)

        plaintext = b"Test message for corruption detection"
        ciphertext = encrypt(plaintext, [X25519Recipient(pk)])

        return ciphertext, sk, pk

    def test_corrupted_header_magic_detected(self, valid_age_data: tuple) -> None:
        """
        Verify corrupted header magic is detected.
        """
        from pqage import X25519Identity, decrypt
        from pqage.exceptions import InvalidFileError

        ciphertext, sk, pk = valid_age_data

        # Corrupt first byte of header
        corrupted = b"X" + ciphertext[1:]

        with pytest.raises(InvalidFileError, match="(Invalid age header|Not an age)"):
            decrypt(corrupted, [X25519Identity(sk, pk)])

    def test_corrupted_mac_detected(self, valid_age_data: tuple) -> None:
        """
        Verify corrupted header MAC is detected.
        """
        from pqage import X25519Identity, decrypt
        from pqage.exceptions import InvalidFileError

        ciphertext, sk, pk = valid_age_data

        # Find MAC line (starts with "--- ")
        mac_start = ciphertext.find(b"--- ")
        assert mac_start > 0, "MAC line not found in test data"

        # Corrupt a byte in the MAC (use a safe position after "--- ")
        # Make sure we stay within valid ASCII range to avoid UTF-8 errors
        corrupted = bytearray(ciphertext)
        # XOR with a value that keeps it in printable ASCII range
        original_byte = corrupted[mac_start + 5]
        # Flip to a different valid base64 character
        corrupted[mac_start + 5] = ord("X") if chr(original_byte) != "X" else ord("Y")
        corrupted = bytes(corrupted)

        # Corrupted MAC should cause decryption failure (MAC verify fails)
        # or InvalidFileError if the corruption breaks base64 decoding
        with pytest.raises((DecryptionError, InvalidFileError)):
            decrypt(corrupted, [X25519Identity(sk, pk)])

    def test_corrupted_payload_detected(self, valid_age_data: tuple) -> None:
        """
        Verify corrupted payload is detected via ChaCha20-Poly1305 MAC.
        """
        from pqage import X25519Identity, decrypt

        ciphertext, sk, pk = valid_age_data

        # Corrupt last byte (in payload)
        corrupted = ciphertext[:-1] + bytes([ciphertext[-1] ^ 0xFF])

        with pytest.raises(DecryptionError):
            decrypt(corrupted, [X25519Identity(sk, pk)])

    def test_truncated_file_detected(self, valid_age_data: tuple) -> None:
        """
        Verify truncated file is detected.
        """
        from pqage import X25519Identity, decrypt
        from pqage.exceptions import InvalidFileError

        ciphertext, sk, pk = valid_age_data

        # Truncate file (remove last 100 bytes)
        truncated = ciphertext[:-100]

        with pytest.raises((DecryptionError, InvalidFileError)):
            decrypt(truncated, [X25519Identity(sk, pk)])

    def test_header_payload_boundary_corruption(self, valid_age_data: tuple) -> None:
        """
        Verify corruption at header/payload boundary is detected.
        """
        from pqage import X25519Identity, decrypt
        from pqage.exceptions import InvalidFileError

        ciphertext, sk, pk = valid_age_data

        # Find end of header (newline after MAC line)
        mac_end = ciphertext.find(b"---")
        newline_after_mac = ciphertext.find(b"\n", mac_end)
        assert newline_after_mac > 0, "Header end not found"

        # Corrupt byte right at boundary
        corrupted = bytearray(ciphertext)
        corrupted[newline_after_mac + 1] ^= 0xFF
        corrupted = bytes(corrupted)

        with pytest.raises((DecryptionError, InvalidFileError)):
            decrypt(corrupted, [X25519Identity(sk, pk)])


# =============================================================================
# TEST 11: Native Extension Fallback (MEDIUM)
# =============================================================================


class TestNativeExtensionFallback:
    """
    Test that Python fallback works when native extension is unavailable.
    """

    def test_python_fallback_wipe_works(self) -> None:
        """
        Verify Python fallback wipe zeroes memory correctly.
        """
        from pqage.crypto._native import PythonSecureBuffer

        buf = PythonSecureBuffer(64)
        buf.write_at(0, b"sensitive_secret_key_material!!!")

        # Wipe
        buf.wipe_now()

        # Verify wiped
        assert buf.is_wiped, "Buffer not marked as wiped"
        assert all(b == 0 for b in buf._data), "CRITICAL: Python fallback wipe did not zero memory!"

    def test_secure_wipe_uses_multiple_passes(self) -> None:
        """
        Verify secure_wipe uses multiple overwrite passes.
        """
        from pqage.crypto import utils

        source = inspect.getsource(utils.secure_wipe)

        # Count overwrite loops
        loop_count = source.count("for i in range")

        assert loop_count >= 3, (
            f"secure_wipe only has {loop_count} overwrite pass(es). "
            "At least 3 passes recommended (zero, 0xFF, zero)."
        )

    def test_native_availability_check_exists(self) -> None:
        """
        Verify native availability check exists and works.
        """
        from pqage.crypto._native import NATIVE_AVAILABLE, is_native_available

        result = is_native_available()
        assert isinstance(result, bool), "is_native_available must return bool"
        assert NATIVE_AVAILABLE == result, "Constant doesn't match function"


# =============================================================================
# TEST 12: File Permission Errors (MEDIUM)
# =============================================================================


class TestFilePermissionErrors:
    """
    Test handling of file permission errors.
    """

    def test_encrypt_to_readonly_directory_fails(self, tmp_path) -> None:
        """
        Test encryption to read-only directory fails gracefully.
        """
        import stat

        from pqage import ScryptRecipient, encrypt_file

        # Create test file
        input_file = tmp_path / "input.txt"
        input_file.write_bytes(b"test data")

        # Create read-only directory
        readonly_dir = tmp_path / "readonly"
        readonly_dir.mkdir()
        readonly_dir.chmod(stat.S_IRUSR | stat.S_IXUSR)

        try:
            # Try to encrypt to read-only directory
            output_path = str(readonly_dir / "output.age")

            with pytest.raises((PermissionError, OSError)):
                encrypt_file(
                    str(input_file),
                    [ScryptRecipient("password", work_factor=10)],
                    output_path=output_path,
                )
        finally:
            # Restore permissions for cleanup
            readonly_dir.chmod(stat.S_IRWXU)

    def test_decrypt_from_unreadable_file_fails(self, tmp_path) -> None:
        """
        Test decryption from unreadable file fails gracefully.
        """
        import stat

        from pqage import ScryptIdentity, decrypt_file

        # Create encrypted file
        encrypted_file = tmp_path / "encrypted.age"
        encrypted_file.write_bytes(b"dummy encrypted data")

        # Make it unreadable
        encrypted_file.chmod(0o000)

        try:
            with pytest.raises((PermissionError, OSError)):
                decrypt_file(
                    str(encrypted_file),
                    [ScryptIdentity("password")],
                )
        finally:
            # Restore permissions for cleanup
            encrypted_file.chmod(stat.S_IRWXU)


# =============================================================================
# TEST 13: Large Counter Overflow (LOW)
# =============================================================================


class TestLargeCounterOverflow:
    """
    Test handling of large chunk counters near overflow.
    """

    def test_max_counter_produces_valid_nonce(self) -> None:
        """
        Verify maximum counter value produces valid nonce.
        """
        from pqage.crypto.age_stream import MAX_CHUNK_COUNTER, _derive_stream_nonce

        # Test at max counter
        nonce = _derive_stream_nonce(MAX_CHUNK_COUNTER, False)

        assert len(nonce) == 12, f"Wrong nonce length at max counter: {len(nonce)}"

    def test_counter_overflow_check_exists(self) -> None:
        """
        Verify counter overflow check exists in stream encryption.
        """
        from pqage.crypto import age_stream

        source = inspect.getsource(age_stream.stream_encrypt)

        assert "MAX_CHUNK_COUNTER" in source or "counter overflow" in source.lower(), (
            "stream_encrypt does not check for counter overflow! "
            "Files > 4 TB could have nonce collision."
        )

    def test_consecutive_max_counters_unique_nonces(self) -> None:
        """
        Verify nonces near max counter are still unique.
        """
        from pqage.crypto.age_stream import MAX_CHUNK_COUNTER, _derive_stream_nonce

        nonces = set()
        for counter in range(MAX_CHUNK_COUNTER - 10, MAX_CHUNK_COUNTER + 1):
            nonce = _derive_stream_nonce(counter, False)
            if nonce in nonces:
                pytest.fail(f"NONCE COLLISION at counter {counter}!")
            nonces.add(nonce)

        assert len(nonces) == 11, "Not all nonces unique near max counter!"


# =============================================================================
# TEST 14: Invalid Base64 Public Key Fuzzing (HIGH)
# =============================================================================


class TestInvalidBase64PublicKeyFuzzing:
    """
    Fuzz tests for invalid base64 in public keys.
    """

    @given(garbage=st.binary(min_size=1, max_size=100))
    @settings(max_examples=50)
    def test_invalid_base64_in_x25519_stanza_rejected(self, garbage: bytes) -> None:
        """
        Property: Invalid base64 in stanza arguments must be rejected.
        """
        from pqage.age_format import Stanza, X25519Stanza
        from pqage.exceptions import InvalidFileError

        # Create stanza with garbage base64
        try:
            garbage_str = garbage.decode("ascii", errors="replace")
        except Exception:
            garbage_str = "invalid!!!"

        generic = Stanza(
            stanza_type="X25519",
            args=[garbage_str],
            body=b"data",
        )

        # Should either raise InvalidFileError or produce invalid key
        try:
            typed = X25519Stanza.from_stanza(generic)
            # If we got here, ephemeral_share should be bytes
            # but might be garbage - that's OK, decapsulation will fail
            assert isinstance(typed.ephemeral_share, bytes)
        except InvalidFileError:
            pass  # Expected for invalid base64
        except Exception:
            pass  # Any other error is also acceptable

    def test_truncated_base64_in_stanza_rejected(self) -> None:
        """
        Verify truncated base64 is rejected.
        """
        from pqage.age_format import Stanza
        from pqage.exceptions import InvalidFileError

        # Truncated base64 (missing padding)
        truncated_b64 = "YWJjZGVm"  # Valid: "abcdef"
        truncated_b64_bad = "YWJjZGV"  # Invalid: truncated

        lines = [f"-> X25519 {truncated_b64_bad}", "AAAA"]

        # Should raise due to invalid base64 in body or args
        try:
            Stanza.parse(lines)
        except InvalidFileError:
            pass  # Expected


# =============================================================================
# TEST 15: Timing Side-Channel Statistical Test (MEDIUM)
# =============================================================================


class TestTimingSideChannelStatistical:
    """
    Statistical tests for timing side-channels.

    Note: These tests are probabilistic and may have false positives/negatives.
    They provide evidence of constant-time behavior, not proof.
    """

    def test_secure_compare_timing_variance(self) -> None:
        """
        Test that secure_compare has low timing variance.

        We compare equal vs different strings and measure timing variance.
        True constant-time implementation should have similar variance.
        """
        import time

        iterations = 1000

        # Test data: equal strings
        equal_a = b"A" * 32
        equal_b = b"A" * 32

        # Test data: different at first byte
        diff_first_a = b"A" * 32
        diff_first_b = b"B" + b"A" * 31

        # Test data: different at last byte
        diff_last_a = b"A" * 32
        diff_last_b = b"A" * 31 + b"B"

        def measure_time(func, a, b, n):
            times = []
            for _ in range(n):
                start = time.perf_counter_ns()
                func(a, b)
                elapsed = time.perf_counter_ns() - start
                times.append(elapsed)
            return times

        # Measure timings
        equal_times = measure_time(secure_compare, equal_a, equal_b, iterations)
        diff_first_times = measure_time(secure_compare, diff_first_a, diff_first_b, iterations)
        diff_last_times = measure_time(secure_compare, diff_last_a, diff_last_b, iterations)

        # Calculate medians (more robust than mean)
        def median(lst):
            sorted_lst = sorted(lst)
            n = len(sorted_lst)
            mid = n // 2
            return sorted_lst[mid] if n % 2 else (sorted_lst[mid - 1] + sorted_lst[mid]) / 2

        equal_median = median(equal_times)
        diff_first_median = median(diff_first_times)
        diff_last_median = median(diff_last_times)

        # The medians should be within 50% of each other for constant-time
        # (This is a loose bound due to system noise)
        max_median = max(equal_median, diff_first_median, diff_last_median)
        min_median = min(equal_median, diff_first_median, diff_last_median)

        if max_median > 0:
            ratio = max_median / min_median
            assert ratio < 2.0, (
                f"TIMING VARIANCE DETECTED! "
                f"Equal: {equal_median}ns, DiffFirst: {diff_first_median}ns, "
                f"DiffLast: {diff_last_median}ns. Ratio: {ratio:.2f}x. "
                "This MAY indicate timing side-channel vulnerability."
            )

    def test_hmac_compare_digest_is_used(self) -> None:
        """
        Verify hmac.compare_digest is used (the most important check).
        """
        from pqage.crypto import utils

        source = inspect.getsource(utils.secure_compare)

        assert "compare_digest" in source, (
            "CRITICAL: secure_compare does not use hmac.compare_digest! "
            "This WILL leak timing information."
        )

        # Verify it's not just mentioned but actually called
        assert "hmac.compare_digest(" in source or "compare_digest(a, b)" in source, (
            "compare_digest is mentioned but may not be called correctly!"
        )
