"""
Property-based fuzzing tests for pq-age using Hypothesis.

Tests for:
- Symmetric encryption with edge cases
- Password wrapping with corrupted data
- Key generation properties
- Full encryption roundtrip
"""

import pytest
from hypothesis import assume, given, settings
from hypothesis import strategies as st

from pqage.constants import (
    XCHACHA20_KEY_LEN,
    XCHACHA20_NONCE_LEN,
)
from pqage.crypto.keys import generate_keys
from pqage.crypto.password import unwrap_keys, wrap_keys
from pqage.crypto.symmetric import decrypt, encrypt
from pqage.exceptions import (
    DecryptionError,
    InvalidCiphertextError,
    KeyWrappingError,
    PasswordError,
)

# =============================================================================
# Strategies
# =============================================================================

# Valid key material
valid_key = st.binary(min_size=XCHACHA20_KEY_LEN, max_size=XCHACHA20_KEY_LEN)
valid_nonce = st.binary(min_size=XCHACHA20_NONCE_LEN, max_size=XCHACHA20_NONCE_LEN)
valid_master_seed = st.binary(min_size=32, max_size=32)

# Arbitrary binary data
arbitrary_bytes = st.binary(min_size=0, max_size=10000)
small_bytes = st.binary(min_size=0, max_size=1000)


# =============================================================================
# Symmetric Encryption Fuzzing
# =============================================================================


class TestSymmetricFuzz:
    """Fuzzing tests for symmetric encryption."""

    @given(plaintext=arbitrary_bytes, key=valid_key)
    @settings(max_examples=100)
    def test_encrypt_decrypt_roundtrip(self, plaintext: bytes, key: bytes) -> None:
        """Property: encrypt(decrypt(x)) == x for any valid input."""
        ciphertext = encrypt(plaintext, key)
        decrypted = decrypt(ciphertext, key)
        assert decrypted == plaintext

    @given(plaintext=arbitrary_bytes, key=valid_key, aad=small_bytes)
    @settings(max_examples=100)
    def test_encrypt_decrypt_with_aad_roundtrip(
        self, plaintext: bytes, key: bytes, aad: bytes
    ) -> None:
        """Property: roundtrip works with any AAD."""
        ciphertext = encrypt(plaintext, key, aad)
        decrypted = decrypt(ciphertext, key, aad)
        assert decrypted == plaintext

    @given(ciphertext=arbitrary_bytes, key=valid_key)
    @settings(max_examples=100)
    def test_decrypt_random_data_doesnt_crash(self, ciphertext: bytes, key: bytes) -> None:
        """Property: random data should raise exception, not crash."""
        try:
            decrypt(ciphertext, key)
        except (DecryptionError, InvalidCiphertextError):
            pass  # Expected

    @given(key=st.binary(min_size=0, max_size=100))
    @settings(max_examples=50)
    def test_invalid_key_length_handled(self, key: bytes) -> None:
        """Property: invalid key lengths are rejected gracefully."""
        assume(len(key) != XCHACHA20_KEY_LEN)
        try:
            encrypt(b"test", key)
            assert False, "Should have raised"
        except Exception:
            pass  # Any exception is fine


# =============================================================================
# Password Wrapping Fuzzing
# =============================================================================


class TestPasswordFuzz:
    """Fuzzing tests for password-based key wrapping."""

    @given(
        seed=valid_master_seed,
        password=st.text(min_size=1, max_size=50),
    )
    @settings(max_examples=20, deadline=30000)  # Argon2 is slow
    def test_wrap_unwrap_roundtrip(self, seed: bytes, password: str) -> None:
        """Property: unwrap(wrap(keys, pw), pw) recovers keys."""
        keys = generate_keys(seed)
        wrapped = wrap_keys(keys, password)
        unwrapped = unwrap_keys(wrapped, password)

        assert unwrapped["master_seed"] == keys["master_seed"]
        assert unwrapped["x25519_pk"] == keys["x25519_pk"]

    @given(data=arbitrary_bytes, password=st.text(min_size=1, max_size=20))
    @settings(max_examples=50, deadline=30000)
    def test_unwrap_random_data_doesnt_crash(self, data: bytes, password: str) -> None:
        """Property: random data should raise exception, not crash."""
        try:
            unwrap_keys(data, password)
        except (KeyWrappingError, PasswordError):
            pass  # Expected

    @given(
        seed=valid_master_seed,
        correct_pw=st.text(min_size=1, max_size=20),
        wrong_pw=st.text(min_size=1, max_size=20),
    )
    @settings(max_examples=10, deadline=60000)  # Very slow due to Argon2
    def test_wrong_password_fails(self, seed: bytes, correct_pw: str, wrong_pw: str) -> None:
        """Property: wrong password fails to unwrap."""
        assume(correct_pw != wrong_pw)

        keys = generate_keys(seed)
        wrapped = wrap_keys(keys, correct_pw)

        try:
            unwrap_keys(wrapped, wrong_pw)
            assert False, "Should have raised PasswordError"
        except PasswordError:
            pass  # Expected


# =============================================================================
# Key Generation Fuzzing
# =============================================================================


class TestKeyGenFuzz:
    """Fuzzing tests for key generation."""

    @given(seed=valid_master_seed)
    @settings(max_examples=50)
    def test_deterministic_generation(self, seed: bytes) -> None:
        """Property: same seed always produces same keys."""
        keys1 = generate_keys(seed)
        keys2 = generate_keys(seed)

        assert keys1["x25519_pk"] == keys2["x25519_pk"]
        assert keys1["x25519_sk"] == keys2["x25519_sk"]
        assert keys1["kyber_pk"] == keys2["kyber_pk"]
        assert keys1["kyber_sk"] == keys2["kyber_sk"]

    @given(seed1=valid_master_seed, seed2=valid_master_seed)
    @settings(max_examples=50)
    def test_different_seeds_different_keys(self, seed1: bytes, seed2: bytes) -> None:
        """Property: different seeds produce different keys."""
        assume(seed1 != seed2)

        keys1 = generate_keys(seed1)
        keys2 = generate_keys(seed2)

        # At least the X25519 keys should differ
        assert keys1["x25519_pk"] != keys2["x25519_pk"]


# =============================================================================
# Integration Fuzzing
# =============================================================================


class TestIntegrationFuzz:
    """End-to-end fuzzing tests using age-compatible format."""

    @given(
        plaintext=st.binary(min_size=0, max_size=5000),
        seed=valid_master_seed,
    )
    @settings(max_examples=30)
    def test_full_encryption_roundtrip(self, plaintext: bytes, seed: bytes) -> None:
        """Property: full encrypt/decrypt roundtrip preserves data (age format)."""
        from pqage.age_file_ops import (
            MlkemX25519Identity,
            MlkemX25519Recipient,
        )
        from pqage.age_file_ops import (
            decrypt as age_decrypt,
        )
        from pqage.age_file_ops import (
            encrypt as age_encrypt,
        )

        # Generate keys
        keys = generate_keys(seed)

        # Create recipient and identity
        recipient = MlkemX25519Recipient(
            mlkem_pk=keys["kyber_pk"],
            x25519_pk=keys["x25519_pk"],
        )
        identity = MlkemX25519Identity(
            mlkem_sk=keys["kyber_sk"],
            mlkem_pk=keys["kyber_pk"],
            x25519_sk=keys["x25519_sk"],
            x25519_pk=keys["x25519_pk"],
        )

        # Encrypt using age format
        ciphertext = age_encrypt(plaintext, [recipient])

        # Decrypt
        decrypted = age_decrypt(ciphertext, [identity])

        assert decrypted == plaintext


# =============================================================================
# age-compatible Fuzzing
# =============================================================================


class TestAgeFormatFuzz:
    """Fuzzing tests for age-compatible encryption."""

    @given(
        plaintext=st.binary(min_size=0, max_size=10000),
        seed=valid_master_seed,
    )
    @settings(max_examples=30)
    def test_age_encrypt_decrypt_x25519(self, plaintext: bytes, seed: bytes) -> None:
        """Property: age-compatible X25519 roundtrip works."""
        from nacl.bindings import crypto_scalarmult_base

        from pqage import X25519Identity, X25519Recipient, decrypt, encrypt

        # Generate X25519 keypair
        sk = bytearray(seed)
        sk[0] &= 248
        sk[31] &= 127
        sk[31] |= 64
        sk = bytes(sk)
        pk = crypto_scalarmult_base(sk)

        # Encrypt
        ciphertext = encrypt(plaintext, [X25519Recipient(pk)])

        # Decrypt
        decrypted = decrypt(ciphertext, [X25519Identity(sk, pk)])

        assert decrypted == plaintext

    @given(
        plaintext=st.binary(min_size=0, max_size=5000),
        seed=valid_master_seed,
    )
    @settings(max_examples=20)
    def test_age_encrypt_decrypt_mlkem_x25519(self, plaintext: bytes, seed: bytes) -> None:
        """Property: hybrid ML-KEM + X25519 roundtrip works."""
        from pqage import (
            MlkemX25519Identity,
            MlkemX25519Recipient,
            decrypt,
            encrypt,
            generate_keys,
        )

        # Generate hybrid keypair
        keys = generate_keys(seed)

        recipient = MlkemX25519Recipient(keys["kyber_pk"], keys["x25519_pk"])
        identity = MlkemX25519Identity(
            keys["kyber_sk"],
            keys["x25519_sk"],
            keys["kyber_pk"],
            keys["x25519_pk"],
        )

        # Encrypt
        ciphertext = encrypt(plaintext, [recipient])

        # Decrypt
        decrypted = decrypt(ciphertext, [identity])

        assert decrypted == plaintext
