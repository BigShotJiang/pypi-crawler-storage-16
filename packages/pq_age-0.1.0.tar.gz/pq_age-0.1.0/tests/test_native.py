"""
Tests for native extension and Python fallback.

Tests cover:
- SecureBuffer allocation and operations
- Secure wiping functionality
- Constant-time comparison
- Fallback behavior when native extension is unavailable
"""

import pytest

from pqage.crypto._native import (
    MLOCK_AVAILABLE,
    NATIVE_AVAILABLE,
    PythonSecureBuffer,
    constant_time_compare,
    get_secure_buffer,
    is_mlock_available,
    is_native_available,
    secure_wipe_buffer,
)


class TestNativeAvailability:
    """Tests for native extension availability checks."""

    def test_is_native_available_returns_bool(self) -> None:
        """Test that is_native_available returns a boolean."""
        result = is_native_available()
        assert isinstance(result, bool)

    def test_is_mlock_available_returns_bool(self) -> None:
        """Test that is_mlock_available returns a boolean."""
        result = is_mlock_available()
        assert isinstance(result, bool)

    def test_module_constants_match_functions(self) -> None:
        """Test that module constants match function results."""
        assert NATIVE_AVAILABLE == is_native_available()
        assert MLOCK_AVAILABLE == is_mlock_available()


class TestPythonSecureBuffer:
    """Tests for Python fallback SecureBuffer."""

    def test_allocate_buffer(self) -> None:
        """Test basic buffer allocation."""
        buf = PythonSecureBuffer(32)
        assert buf.size == 32
        assert not buf.is_memory_locked  # Python fallback never locks
        assert not buf.is_wiped

    def test_from_bytes(self) -> None:
        """Test creating buffer from bytes."""
        data = b"secret_key_material!"
        buf = PythonSecureBuffer.from_bytes(data)
        assert buf.size == len(data)
        assert buf.to_bytes() == data

    def test_write_and_read(self) -> None:
        """Test writing and reading data."""
        buf = PythonSecureBuffer(32)
        data = b"test_data"
        buf.write_at(0, data)

        result = buf.read_at(0, len(data))
        assert result == data

    def test_write_at_offset(self) -> None:
        """Test writing at specific offset."""
        buf = PythonSecureBuffer(32)
        data = b"middle"
        buf.write_at(10, data)

        result = buf.read_at(10, len(data))
        assert result == data

    def test_write_overflow_raises(self) -> None:
        """Test that writing beyond buffer raises error."""
        buf = PythonSecureBuffer(10)
        with pytest.raises(MemoryError, match="overflow"):
            buf.write_at(5, b"123456")  # Would overflow

    def test_read_overflow_raises(self) -> None:
        """Test that reading beyond buffer raises error."""
        buf = PythonSecureBuffer(10)
        with pytest.raises(MemoryError, match="overflow"):
            buf.read_at(5, 10)  # Would overflow

    def test_wipe_zeroes_data(self) -> None:
        """Test that wipe zeroes the buffer."""
        buf = PythonSecureBuffer(32)
        buf.write_at(0, b"X" * 32)

        buf.wipe_now()

        assert buf.is_wiped
        # Internal data should be zeroed
        assert all(b == 0 for b in buf._data)

    def test_operations_after_wipe_raise(self) -> None:
        """Test that operations after wipe raise error."""
        buf = PythonSecureBuffer(32)
        buf.wipe_now()

        with pytest.raises(MemoryError, match="wiped"):
            buf.to_bytes()

        with pytest.raises(MemoryError, match="wiped"):
            buf.write_at(0, b"test")

        with pytest.raises(MemoryError, match="wiped"):
            buf.read_at(0, 4)

    def test_double_wipe_safe(self) -> None:
        """Test that double wipe is safe."""
        buf = PythonSecureBuffer(32)
        buf.wipe_now()
        buf.wipe_now()  # Should not raise

    def test_zero_size_raises(self) -> None:
        """Test that zero-size allocation raises error."""
        with pytest.raises(MemoryError, match="zero"):
            PythonSecureBuffer(0)

    def test_negative_size_raises(self) -> None:
        """Test that negative size raises error."""
        with pytest.raises(MemoryError, match="zero"):
            PythonSecureBuffer(-1)

    def test_len_returns_size(self) -> None:
        """Test that len() returns buffer size."""
        buf = PythonSecureBuffer(64)
        assert len(buf) == 64

    def test_repr(self) -> None:
        """Test string representation."""
        buf = PythonSecureBuffer(32)
        repr_str = repr(buf)
        assert "32" in repr_str
        assert "False" in repr_str  # locked=False


class TestGetSecureBuffer:
    """Tests for get_secure_buffer factory function."""

    def test_returns_buffer(self) -> None:
        """Test that factory returns a buffer."""
        buf = get_secure_buffer(32)
        assert hasattr(buf, "size") or len(buf) == 32

    def test_buffer_is_correct_size(self) -> None:
        """Test that returned buffer has correct size."""
        buf = get_secure_buffer(64)
        if hasattr(buf, "size"):
            assert buf.size == 64
        else:
            assert len(buf) == 64


class TestSecureWipeBuffer:
    """Tests for secure_wipe_buffer function."""

    def test_wipes_bytearray(self) -> None:
        """Test that bytearray is wiped."""
        data = bytearray(b"sensitive_secret_data!")
        secure_wipe_buffer(data)
        assert all(b == 0 for b in data)

    def test_wipes_empty_bytearray(self) -> None:
        """Test wiping empty bytearray."""
        data = bytearray()
        secure_wipe_buffer(data)  # Should not raise
        assert len(data) == 0

    def test_wipes_large_buffer(self) -> None:
        """Test wiping large buffer."""
        data = bytearray(b"X" * 10000)
        secure_wipe_buffer(data)
        assert all(b == 0 for b in data)


class TestConstantTimeCompare:
    """Tests for constant_time_compare function."""

    def test_equal_bytes_returns_true(self) -> None:
        """Test that equal bytes return True."""
        a = b"hello world"
        b = b"hello world"
        assert constant_time_compare(a, b) is True

    def test_unequal_bytes_returns_false(self) -> None:
        """Test that unequal bytes return False."""
        a = b"hello world"
        b = b"hello earth"
        assert constant_time_compare(a, b) is False

    def test_different_lengths_returns_false(self) -> None:
        """Test that different lengths return False."""
        a = b"short"
        b = b"much longer string"
        assert constant_time_compare(a, b) is False

    def test_empty_bytes_equal(self) -> None:
        """Test that empty bytes are equal."""
        assert constant_time_compare(b"", b"") is True

    def test_single_bit_difference(self) -> None:
        """Test detection of single bit difference."""
        a = bytes([0] * 32)
        b = bytes([0] * 31 + [1])
        assert constant_time_compare(a, b) is False


class TestIntegration:
    """Integration tests combining multiple features."""

    def test_secure_buffer_workflow(self) -> None:
        """Test complete secure buffer workflow."""
        # Allocate
        buf = get_secure_buffer(64)

        # Write secret
        secret = b"my_super_secret_key_1234567890!"
        if hasattr(buf, "write_at"):
            buf.write_at(0, secret)
            result = buf.read_at(0, len(secret))
            assert result == secret

            # Wipe
            buf.wipe_now()
            assert buf.is_wiped
        else:
            # bytearray fallback
            buf[: len(secret)] = secret
            assert bytes(buf[: len(secret)]) == secret

    def test_compare_then_wipe(self) -> None:
        """Test comparing secrets then wiping."""
        secret1 = bytearray(b"password123")
        secret2 = bytearray(b"password123")

        # Compare
        assert constant_time_compare(bytes(secret1), bytes(secret2))

        # Wipe both
        secure_wipe_buffer(secret1)
        secure_wipe_buffer(secret2)

        assert all(b == 0 for b in secret1)
        assert all(b == 0 for b in secret2)
