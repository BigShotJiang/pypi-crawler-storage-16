"""
Tests for SSH key parsing and Ed25519 conversion.

Tests ssh.py: SSH public/private key parsing, Ed25519->X25519 conversion.
"""

import base64
import hashlib

import pytest

from pqage.crypto.ssh import (
    SshEd25519PrivateKey,
    SshEd25519PublicKey,
    compute_ssh_key_hash,
    ed25519_to_x25519_public,
    ed25519_to_x25519_secret,
    parse_ssh_private_key,
    parse_ssh_private_key_file,
    parse_ssh_public_key,
    parse_ssh_public_key_file,
)
from pqage.exceptions import InvalidFileError, InvalidKeyError


class TestSshEd25519PublicKey:
    """Test SSH Ed25519 public key handling."""

    @pytest.fixture
    def sample_ed25519_pk(self) -> bytes:
        """Sample Ed25519 public key."""
        # Valid Ed25519 public key (32 bytes)
        return bytes.fromhex("d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a")

    @pytest.fixture
    def sample_x25519_pk(self) -> bytes:
        """Corresponding X25519 public key."""
        # This is the X25519 conversion of the above Ed25519 key
        return bytes.fromhex("2fe57da347cd62431528daac5fbb290730fff684afc4cfcdaa9c7538bfe3ba0")

    def test_from_ed25519_basic(self, sample_ed25519_pk: bytes) -> None:
        """Test creating SshEd25519PublicKey from Ed25519 key."""
        key = SshEd25519PublicKey.from_ed25519(sample_ed25519_pk)

        assert key.ed25519_pk == sample_ed25519_pk
        assert len(key.x25519_pk) == 32
        assert len(key.key_hash) == 4
        assert key.comment == ""

    def test_from_ed25519_with_comment(self, sample_ed25519_pk: bytes) -> None:
        """Test creating with comment."""
        key = SshEd25519PublicKey.from_ed25519(sample_ed25519_pk, "test@example.com")

        assert key.comment == "test@example.com"

    def test_invalid_ed25519_length(self) -> None:
        """Test invalid Ed25519 key length."""
        with pytest.raises(InvalidKeyError, match="Ed25519 public key must be 32 bytes"):
            SshEd25519PublicKey.from_ed25519(b"too_short")

        with pytest.raises(InvalidKeyError, match="Ed25519 public key must be 32 bytes"):
            SshEd25519PublicKey.from_ed25519(b"too_long" * 10)


class TestSshEd25519PrivateKey:
    """Test SSH Ed25519 private key handling."""

    @pytest.fixture
    def sample_ed25519_seed(self) -> bytes:
        """Sample Ed25519 seed (32 bytes)."""
        return bytes.fromhex("9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60")

    @pytest.fixture
    def sample_ed25519_sk(self, sample_ed25519_seed: bytes) -> bytes:
        """Sample Ed25519 private key (64 bytes: seed + pubkey)."""
        from nacl.signing import SigningKey

        signing_key = SigningKey(sample_ed25519_seed)
        # bytes(signing_key) returns only 32-byte seed
        # Full Ed25519 secret key is seed + public_key = 64 bytes
        return sample_ed25519_seed + bytes(signing_key.verify_key)

    def test_from_ed25519_full_key(self, sample_ed25519_sk: bytes) -> None:
        """Test creating from full 64-byte Ed25519 secret key."""
        key = SshEd25519PrivateKey.from_ed25519(sample_ed25519_sk)

        assert len(key.ed25519_sk) == 64
        assert len(key.ed25519_pk) == 32
        assert len(key.x25519_pk) == 32
        assert len(key.x25519_sk) == 32
        assert len(key.key_hash) == 4
        assert key.comment == ""

    def test_from_ed25519_seed_only(self, sample_ed25519_seed: bytes) -> None:
        """Test creating from 32-byte seed."""
        key = SshEd25519PrivateKey.from_ed25519(sample_ed25519_seed)

        assert len(key.ed25519_sk) == 64  # Expanded to full key
        assert len(key.ed25519_pk) == 32
        assert len(key.x25519_pk) == 32
        assert len(key.x25519_sk) == 32

    def test_invalid_secret_key_length(self) -> None:
        """Test invalid secret key lengths."""
        with pytest.raises(InvalidKeyError, match="Ed25519 secret key must be 32 or 64 bytes"):
            SshEd25519PrivateKey.from_ed25519(b"invalid_length")

    def test_wipe_functionality(self, sample_ed25519_sk: bytes) -> None:
        """Test that wipe function clears sensitive data."""
        key = SshEd25519PrivateKey.from_ed25519(sample_ed25519_sk)

        # Data should be present initially
        assert key.ed25519_sk is not None
        assert key.x25519_sk is not None

        # Wipe
        key.wipe()

        # Should be wiped (zeroed)
        assert all(b == 0 for b in key.ed25519_sk)
        assert all(b == 0 for b in key.x25519_sk)


class TestSshKeyParsing:
    """Test SSH key string parsing."""

    def test_parse_ssh_public_key_authorized_keys(self) -> None:
        """Test parsing authorized_keys format."""
        # Generate a valid key for testing
        ed25519_pk = bytes.fromhex(
            "d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a"
        )
        wire_format = _encode_ssh_public_key_test(ed25519_pk)
        b64_key = base64.b64encode(wire_format).decode("ascii")

        line = f"ssh-ed25519 {b64_key} user@host"

        key = parse_ssh_public_key(line)

        assert key.ed25519_pk == ed25519_pk
        assert key.comment == "user@host"

    def test_parse_ssh_public_key_raw_base64(self) -> None:
        """Test parsing raw base64 format."""
        ed25519_pk = bytes.fromhex(
            "d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a"
        )
        wire_format = _encode_ssh_public_key_test(ed25519_pk)
        b64_key = base64.b64encode(wire_format).decode("ascii")

        key = parse_ssh_public_key(b64_key)

        assert key.ed25519_pk == ed25519_pk
        assert key.comment == ""

    def test_parse_ssh_public_key_invalid_type(self) -> None:
        """Test parsing invalid key type (ssh-rsa is not supported)."""
        # ssh-rsa doesn't match the AUTHORIZED_KEYS_PATTERN (only ssh-ed25519 does)
        # So we get "Invalid SSH public key format" instead of "Unsupported SSH key type"
        line = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQ user@host"

        with pytest.raises(InvalidKeyError, match="Invalid SSH public key format"):
            parse_ssh_public_key(line)

    def test_parse_ssh_public_key_invalid_format(self) -> None:
        """Test parsing invalid format."""
        with pytest.raises(InvalidKeyError, match="Invalid SSH public key format"):
            parse_ssh_public_key("invalid format")

    def test_parse_ssh_private_key_invalid_format(self) -> None:
        """Test parsing invalid private key."""
        with pytest.raises(InvalidKeyError):
            parse_ssh_private_key("not an openssh key")


class TestEd25519X25519Conversion:
    """Test Ed25519 to X25519 conversion functions."""

    @pytest.fixture
    def test_vectors(self) -> list[tuple[bytes, bytes, bytes]]:
        """Test vectors for Ed25519/X25519 conversion."""
        from nacl.bindings import crypto_sign_ed25519_pk_to_curve25519
        from nacl.signing import SigningKey

        # Generate valid test vectors
        seed = bytes.fromhex("9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60")
        signing_key = SigningKey(seed)
        ed25519_pk = bytes(signing_key.verify_key)
        x25519_pk = crypto_sign_ed25519_pk_to_curve25519(ed25519_pk)

        return [
            (
                seed,
                ed25519_pk,
                x25519_pk,
            )
        ]

    def test_ed25519_to_x25519_public_conversion(self, test_vectors: list) -> None:
        """Test Ed25519 to X25519 public key conversion."""
        for _, ed25519_pk, expected_x25519_pk in test_vectors:
            result = ed25519_to_x25519_public(ed25519_pk)
            assert result == expected_x25519_pk

    def test_ed25519_to_x25519_secret_conversion(self, test_vectors: list) -> None:
        """Test Ed25519 to X25519 secret key conversion."""
        for seed, ed25519_pk, expected_x25519_pk in test_vectors:
            # Create full Ed25519 secret key (seed + pubkey = 64 bytes)
            # Note: bytes(SigningKey) only returns seed, we need full 64-byte key
            full_sk = seed + ed25519_pk  # 32 + 32 = 64 bytes

            x25519_sk = ed25519_to_x25519_secret(full_sk)

            # Verify the conversion by computing public key
            from nacl.bindings import crypto_scalarmult_base

            computed_pk = crypto_scalarmult_base(x25519_sk)
            assert computed_pk == expected_x25519_pk

    def test_conversion_invalid_lengths(self) -> None:
        """Test conversion with invalid key lengths."""
        with pytest.raises(InvalidKeyError, match="Invalid Ed25519 public key length"):
            ed25519_to_x25519_public(b"wrong_length")

        with pytest.raises(InvalidKeyError, match="Invalid Ed25519 secret key length"):
            ed25519_to_x25519_secret(b"wrong_length")


class TestSshKeyHash:
    """Test SSH key hash computation."""

    def test_compute_ssh_key_hash(self) -> None:
        """Test SSH key hash computation."""
        ed25519_pk = bytes.fromhex(
            "d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a"
        )

        # Hash should be first 4 bytes of SHA256(wire_format)
        wire_format = _encode_ssh_public_key_test(ed25519_pk)
        expected_hash = hashlib.sha256(wire_format).digest()[:4]

        result = compute_ssh_key_hash(ed25519_pk)
        assert result == expected_hash
        assert len(result) == 4

    def test_key_hash_deterministic(self) -> None:
        """Test that key hash is deterministic."""
        ed25519_pk = bytes.fromhex(
            "d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a"
        )

        hash1 = compute_ssh_key_hash(ed25519_pk)
        hash2 = compute_ssh_key_hash(ed25519_pk)

        assert hash1 == hash2


class TestSshKeyFileOperations:
    """Test file-based SSH key operations."""

    def test_parse_ssh_public_key_file_nonexistent(self) -> None:
        """Test parsing nonexistent public key file."""
        with pytest.raises(FileNotFoundError):
            parse_ssh_public_key_file("/nonexistent/file")

    def test_parse_ssh_private_key_file_nonexistent(self) -> None:
        """Test parsing nonexistent private key file."""
        with pytest.raises(FileNotFoundError):
            parse_ssh_private_key_file("/nonexistent/file")


class TestSshKeyEdgeCases:
    """Test edge cases and error conditions."""

    def test_parse_ssh_public_key_empty(self) -> None:
        """Test parsing empty key."""
        with pytest.raises(InvalidKeyError):
            parse_ssh_public_key("")

    def test_parse_ssh_private_key_empty(self) -> None:
        """Test parsing empty private key."""
        # Empty string is not an OpenSSH private key format
        with pytest.raises(InvalidKeyError, match="Not an OpenSSH private key format"):
            parse_ssh_private_key("")

    def test_ssh_key_with_special_characters(self) -> None:
        """Test key with special characters in comment."""
        # This would require a more complex test with actual key data
        # For now, just ensure the parsing doesn't crash
        pass


# Helper function for tests (duplicate of internal _encode_ssh_public_key)
def _encode_ssh_public_key_test(ed25519_pk: bytes) -> bytes:
    """Test helper to encode SSH public key."""
    import struct

    key_type = b"ssh-ed25519"
    result = struct.pack(">I", len(key_type)) + key_type
    result += struct.pack(">I", len(ed25519_pk)) + ed25519_pk
    return result
