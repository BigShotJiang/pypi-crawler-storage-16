"""
🧪 Tests for pq-age security utilities.

Tests cover:
- Constant-time comparison
- Secure memory wiping
- SecureBytes context manager
"""

import pytest

from pqage.crypto.utils import (
    SecureBytes,
    secure_compare,
    secure_starts_with,
    secure_wipe,
    secure_wipe_multiple,
)


class TestSecureCompare:
    """🧪 Tests for constant-time comparison."""

    def test_equal_bytes_returns_true(self) -> None:
        """Test that equal byte strings return True."""
        a = b"hello world"
        b = b"hello world"
        assert secure_compare(a, b) is True

    def test_unequal_bytes_returns_false(self) -> None:
        """Test that unequal byte strings return False."""
        a = b"hello world"
        b = b"hello earth"
        assert secure_compare(a, b) is False

    def test_different_lengths_returns_false(self) -> None:
        """Test that different length strings return False."""
        a = b"short"
        b = b"much longer string"
        assert secure_compare(a, b) is False

    def test_empty_bytes_equal(self) -> None:
        """Test that empty byte strings are equal."""
        assert secure_compare(b"", b"") is True

    def test_non_bytes_returns_false(self) -> None:
        """Test that non-bytes types return False."""
        assert secure_compare("string", b"bytes") is False  # type: ignore
        assert secure_compare(b"bytes", 123) is False  # type: ignore

    def test_single_byte_difference(self) -> None:
        """Test detection of single byte difference."""
        a = b"0" * 1000
        b = b"0" * 999 + b"1"
        assert secure_compare(a, b) is False


class TestSecureStartsWith:
    """🧪 Tests for constant-time prefix check."""

    def test_valid_prefix(self) -> None:
        """Test that valid prefix returns True."""
        data = b"PQAGEv0.1.0_rest_of_data"
        prefix = b"PQAGEv0.1.0"
        assert secure_starts_with(data, prefix) is True

    def test_invalid_prefix(self) -> None:
        """Test that invalid prefix returns False."""
        data = b"INVALID_data"
        prefix = b"PQAGE"
        assert secure_starts_with(data, prefix) is False

    def test_data_shorter_than_prefix(self) -> None:
        """Test that short data returns False."""
        data = b"PQ"
        prefix = b"PQAGEv0.1.0"
        assert secure_starts_with(data, prefix) is False

    def test_exact_match(self) -> None:
        """Test exact match (data == prefix)."""
        data = b"PQAGE"
        prefix = b"PQAGE"
        assert secure_starts_with(data, prefix) is True

    def test_empty_prefix(self) -> None:
        """Test that empty prefix always matches."""
        assert secure_starts_with(b"anything", b"") is True
        assert secure_starts_with(b"", b"") is True


class TestSecureWipe:
    """🧪 Tests for secure memory wiping."""

    def test_wipe_bytearray(self) -> None:
        """Test that bytearray is zeroed."""
        data = bytearray(b"sensitive secret data!")
        secure_wipe(data)
        assert all(b == 0 for b in data)

    def test_wipe_empty_bytearray(self) -> None:
        """Test wiping empty bytearray."""
        data = bytearray()
        secure_wipe(data)  # Should not raise
        assert len(data) == 0

    def test_wipe_large_data(self) -> None:
        """Test wiping large data."""
        data = bytearray(b"X" * 10000)
        secure_wipe(data)
        assert all(b == 0 for b in data)

    def test_wipe_bytes_logs_warning(self) -> None:
        """Test that wiping bytes logs warning but doesn't crash."""
        data = b"immutable bytes"
        # Should not raise, just warn
        secure_wipe(data)  # type: ignore

    def test_wipe_none_safe(self) -> None:
        """Test that None is handled safely."""
        secure_wipe(None)  # type: ignore

    def test_wipe_memoryview(self) -> None:
        """Test wiping via memoryview."""
        data = bytearray(b"secret")
        mv = memoryview(data)
        secure_wipe(mv)
        assert all(b == 0 for b in data)


class TestSecureWipeMultiple:
    """🧪 Tests for wiping multiple buffers."""

    def test_wipe_multiple_buffers(self) -> None:
        """Test wiping multiple buffers at once."""
        buf1 = bytearray(b"secret1")
        buf2 = bytearray(b"secret2")
        buf3 = bytearray(b"secret3")

        secure_wipe_multiple(buf1, buf2, buf3)

        assert all(b == 0 for b in buf1)
        assert all(b == 0 for b in buf2)
        assert all(b == 0 for b in buf3)

    def test_wipe_with_none_values(self) -> None:
        """Test that None values are skipped."""
        buf1 = bytearray(b"secret")
        secure_wipe_multiple(buf1, None, None)
        assert all(b == 0 for b in buf1)


class TestSecureBytes:
    """🧪 Tests for SecureBytes context manager."""

    def test_context_manager_wipes_on_exit(self) -> None:
        """Test that data is wiped when exiting context."""
        data = bytearray(b"top secret")

        with SecureBytes(data) as secret:
            assert secret == bytearray(b"top secret")

        # After context, should be wiped
        assert all(b == 0 for b in data)

    def test_context_manager_with_bytes_input(self) -> None:
        """Test that bytes input is converted to bytearray."""
        with SecureBytes(b"secret") as secret:
            assert isinstance(secret, bytearray)
            assert secret == bytearray(b"secret")

    def test_context_manager_wipes_on_exception(self) -> None:
        """Test that data is wiped even if exception occurs."""
        data = bytearray(b"secret")

        try:
            with SecureBytes(data):
                raise ValueError("test error")
        except ValueError:
            pass

        # Should still be wiped
        assert all(b == 0 for b in data)

    def test_manual_wipe(self) -> None:
        """Test manual wipe method."""
        sb = SecureBytes(b"secret")
        sb.wipe()

        with pytest.raises(ValueError, match="wiped"):
            _ = sb.data

    def test_data_property_before_wipe(self) -> None:
        """Test data property access before wipe."""
        sb = SecureBytes(b"test")
        assert sb.data == bytearray(b"test")

    def test_bytes_conversion(self) -> None:
        """Test conversion to bytes."""
        sb = SecureBytes(b"test")
        assert bytes(sb) == b"test"

    def test_bytes_conversion_after_wipe_raises(self) -> None:
        """Test that bytes conversion after wipe raises."""
        sb = SecureBytes(b"test")
        sb.wipe()

        with pytest.raises(ValueError, match="wiped"):
            bytes(sb)

    def test_double_wipe_safe(self) -> None:
        """Test that double wipe is safe."""
        sb = SecureBytes(b"test")
        sb.wipe()
        sb.wipe()  # Should not raise
