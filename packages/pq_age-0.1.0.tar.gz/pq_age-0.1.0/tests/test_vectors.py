"""
Tests that validate against documented test vectors.

These tests ensure compatibility and prevent regressions
in the cryptographic implementation.
"""

import json
from pathlib import Path

import pytest

from pqage.crypto.keys import generate_keys
from pqage.crypto.symmetric import decrypt, encrypt


class TestKeyDerivationVectors:
    """Tests for key derivation against known vectors."""

    @pytest.fixture
    def vectors(self) -> dict:
        """Load test vectors."""
        vectors_path = Path(__file__).parent.parent / "test_vectors" / "vectors.json"
        with open(vectors_path) as f:
            return json.load(f)

    def test_zero_seed_key_derivation(self, vectors: dict) -> None:
        """Test key derivation from all-zero seed."""
        vec = next(v for v in vectors["key_derivation_vectors"] if v["name"] == "zero_seed")

        seed = bytes.fromhex(vec["master_seed"])
        keys = generate_keys(seed)

        # Verify X25519 public key matches expected
        expected_prefix = vec["expected"]["x25519_pk_hex_prefix"]
        actual = keys["x25519_pk"].hex()

        assert actual == expected_prefix, f"X25519 PK mismatch: {actual} != {expected_prefix}"

    def test_deterministic_key_generation(self) -> None:
        """Test that same seed always produces same keys."""
        seed = bytes.fromhex("0102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f20")

        keys1 = generate_keys(seed)
        keys2 = generate_keys(seed)

        assert keys1["x25519_pk"] == keys2["x25519_pk"]
        assert keys1["x25519_sk"] == keys2["x25519_sk"]
        assert keys1["kyber_pk"] == keys2["kyber_pk"]
        assert keys1["kyber_sk"] == keys2["kyber_sk"]

    def test_different_seeds_different_keys(self) -> None:
        """Test that different seeds produce different keys."""
        seed1 = bytes.fromhex("0000000000000000000000000000000000000000000000000000000000000000")
        seed2 = bytes.fromhex("0000000000000000000000000000000000000000000000000000000000000001")

        keys1 = generate_keys(seed1)
        keys2 = generate_keys(seed2)

        assert keys1["x25519_pk"] != keys2["x25519_pk"]
        assert keys1["kyber_pk"] != keys2["kyber_pk"]


class TestSymmetricVectors:
    """Tests for symmetric encryption primitives."""

    def test_xchacha20_poly1305_roundtrip(self) -> None:
        """Test XChaCha20-Poly1305 encryption roundtrip."""
        from pqage.constants import XCHACHA20_KEY_LEN

        key = bytes.fromhex("0000000000000000000000000000000000000000000000000000000000000001")
        assert len(key) == XCHACHA20_KEY_LEN

        plaintext = bytes.fromhex("48656c6c6f")  # "Hello"

        # Encrypt
        ciphertext = encrypt(plaintext, key)

        # Decrypt
        decrypted = decrypt(ciphertext, key)

        assert decrypted == plaintext

    def test_xchacha20_poly1305_with_aad(self) -> None:
        """Test XChaCha20-Poly1305 with AAD."""
        from pqage.constants import XCHACHA20_KEY_LEN

        key = bytes([0x42] * XCHACHA20_KEY_LEN)
        plaintext = b"Secret message"
        aad = b"metadata"

        # Encrypt
        ciphertext = encrypt(plaintext, key, aad)

        # Decrypt
        decrypted = decrypt(ciphertext, key, aad)

        assert decrypted == plaintext

    def test_xchacha20_wrong_aad_fails(self) -> None:
        """Test that wrong AAD fails decryption."""
        from pqage.constants import XCHACHA20_KEY_LEN
        from pqage.exceptions import DecryptionError

        key = bytes([0x42] * XCHACHA20_KEY_LEN)
        plaintext = b"Secret"

        ciphertext = encrypt(plaintext, key, aad=b"correct")

        with pytest.raises(DecryptionError):
            decrypt(ciphertext, key, aad=b"wrong")
