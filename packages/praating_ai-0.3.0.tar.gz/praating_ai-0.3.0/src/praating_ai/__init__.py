"""Praating-AI: Push-to-talk voice dictation for Linux using Whisper AI."""

__version__ = "0.3.0"
