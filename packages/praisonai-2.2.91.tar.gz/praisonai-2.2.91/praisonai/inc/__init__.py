# praisonai/inc/__init__.py
from .models import PraisonAIModel