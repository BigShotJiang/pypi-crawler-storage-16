"""Version information for PraisonAI Bench."""

__version__ = "0.1.0"
