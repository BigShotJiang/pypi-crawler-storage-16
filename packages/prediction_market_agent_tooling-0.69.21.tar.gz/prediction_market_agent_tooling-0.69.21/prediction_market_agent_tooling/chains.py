from prediction_market_agent_tooling.gtypes import ChainID

ETHEREUM_ID = ChainID(1)
GNOSIS_CHAIN_ID = ChainID(100)
POLYGON_CHAIN_ID = ChainID(137)
