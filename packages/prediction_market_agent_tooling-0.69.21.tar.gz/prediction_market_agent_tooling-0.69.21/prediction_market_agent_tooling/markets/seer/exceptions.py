class PriceCalculationError(Exception):
    """Raised when there's an error discovering prices for a market."""
