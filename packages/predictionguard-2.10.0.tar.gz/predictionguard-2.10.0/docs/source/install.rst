Installation
=================

PredictionGuard is available on PyPI.

.. code-block:: shell

   pip install predictionguard
