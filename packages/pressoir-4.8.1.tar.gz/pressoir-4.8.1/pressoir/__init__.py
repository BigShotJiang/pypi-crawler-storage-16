from pathlib import Path

VERSION = "4.8.1"
ROOT_DIR = Path(__file__).parent
