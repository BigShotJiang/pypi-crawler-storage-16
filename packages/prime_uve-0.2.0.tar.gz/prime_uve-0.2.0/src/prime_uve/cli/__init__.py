"""CLI package for prime-uve."""
