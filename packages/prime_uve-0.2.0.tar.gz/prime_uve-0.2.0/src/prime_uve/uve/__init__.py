"""uve wrapper - transparent uv command wrapper with .env.uve injection."""

from .wrapper import main

__all__ = ["main"]
