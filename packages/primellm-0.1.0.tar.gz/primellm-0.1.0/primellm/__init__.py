"""
PrimeLLM Python SDK

Simple Python client for the PrimeLLM unified AI API.

Example:
    from primellm import PrimeLLM

    client = PrimeLLM(api_key="primellm_live_XXX")

    resp = client.chat(
        model="gpt-5.1",
        messages=[{"role": "user", "content": "Hello!"}],
    )

    print(resp["choices"][0]["message"]["content"])
"""

from .client import PrimeLLM

__all__ = ["PrimeLLM"]
__version__ = "0.1.0"
