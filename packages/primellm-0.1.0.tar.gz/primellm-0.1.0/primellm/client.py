"""
PrimeLLM Python SDK Client

This module provides the main PrimeLLM class for interacting with the
PrimeLLM unified AI API.
"""

from __future__ import annotations

import os
from typing import Any, Dict, List, Optional

import httpx


class PrimeLLM:
    """
    Simple Python client for the PrimeLLM API.

    The PrimeLLM API provides a unified interface to multiple AI models
    including GPT-5.1, Claude Sonnet 4.5, and Gemini 3.0.

    Example:
        from primellm import PrimeLLM

        client = PrimeLLM(api_key="primellm_live_XXX")

        resp = client.chat(
            model="gpt-5.1",
            messages=[{"role": "user", "content": "Hello!"}],
        )

        print(resp["choices"][0]["message"]["content"])
        print(resp["usage"]["total_tokens"])
        print(resp["credits"]["remaining"])

    Attributes:
        api_key: Your PrimeLLM API key (starts with "primellm_live_").
        base_url: API base URL (default: https://api.primellm.in).
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = "https://api.primellm.in",
    ) -> None:
        """
        Initialize the PrimeLLM client.

        Args:
            api_key: Your PrimeLLM API key. If not provided, reads from
                     PRIMELLM_API_KEY environment variable.
            base_url: API base URL. Default: https://api.primellm.in

        Raises:
            ValueError: If no API key is provided or found in environment.
        """
        self.api_key = api_key or os.getenv("PRIMELLM_API_KEY")
        if not self.api_key:
            raise ValueError(
                "PrimeLLM API key is required. "
                "Pass api_key=... or set PRIMELLM_API_KEY env var."
            )
        self.base_url = base_url.rstrip("/")

    def _headers(self) -> Dict[str, str]:
        """Build request headers with authentication."""
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def chat(
        self,
        model: str,
        messages: List[Dict[str, Any]],
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """
        Call the /v1/chat endpoint to generate a chat completion.

        This endpoint is compatible with the OpenAI chat completions format.

        Args:
            model: Model name to use. Available models:
                   - "gpt-5.1" (default GPT model)
                   - "claude-sonnet-4.5" (Claude model)
                   - "gemini-3.0" (Gemini model)
            messages: List of message dicts with "role" and "content" keys.
                      Roles can be "system", "user", or "assistant".
            **kwargs: Extra parameters like temperature, max_tokens, etc.

        Returns:
            Parsed JSON response dict with fields:
            - id: str - Unique completion ID
            - model: str - Model used
            - choices: list - List of completion choices
                - message: dict with "role" and "content"
                - finish_reason: str
            - usage: dict
                - prompt_tokens: int
                - completion_tokens: int
                - total_tokens: int
            - credits: dict
                - remaining: float - Credits remaining in account
                - cost: float - Cost of this request

        Raises:
            RuntimeError: If the request fails or returns a non-2xx status.

        Example:
            resp = client.chat(
                model="gpt-5.1",
                messages=[
                    {"role": "system", "content": "You are helpful."},
                    {"role": "user", "content": "Hello!"},
                ],
                temperature=0.7,
            )
            print(resp["choices"][0]["message"]["content"])
        """
        payload: Dict[str, Any] = {"model": model, "messages": messages}
        payload.update(kwargs)

        url = f"{self.base_url}/v1/chat"
        
        try:
            with httpx.Client(timeout=60.0) as client:
                res = client.post(url, json=payload, headers=self._headers())
        except httpx.RequestError as exc:
            raise RuntimeError(f"PrimeLLM request failed: {exc}") from exc

        if res.status_code // 100 != 2:
            # Try to include server-provided error JSON if present
            try:
                err = res.json()
            except Exception:
                err = res.text
            raise RuntimeError(f"PrimeLLM API error {res.status_code}: {err}")

        return res.json()

    def generate(
        self,
        model: str,
        messages: List[Dict[str, Any]],
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """
        Call the legacy /generate endpoint.

        This is provided for backwards compatibility. For new code,
        prefer using the chat() method.

        Args:
            model: Model name (e.g., "gpt-5.1").
            messages: List of message dicts.
            **kwargs: Extra parameters.

        Returns:
            Parsed JSON response with:
            - reply: str - The generated response
            - model: str - Model used
            - tokens_used: int - Total tokens
            - cost: float - Request cost
            - credits_remaining: float - Remaining credits
        """
        payload: Dict[str, Any] = {"model": model, "messages": messages}
        payload.update(kwargs)

        url = f"{self.base_url}/generate"

        try:
            with httpx.Client(timeout=60.0) as client:
                res = client.post(url, json=payload, headers=self._headers())
        except httpx.RequestError as exc:
            raise RuntimeError(f"PrimeLLM request failed: {exc}") from exc

        if res.status_code // 100 != 2:
            try:
                err = res.json()
            except Exception:
                err = res.text
            raise RuntimeError(f"PrimeLLM API error {res.status_code}: {err}")

        return res.json()
