# SPDX-FileCopyrightText: 2025-present Dylan Stein <dylan@primitive.tech>
#
# SPDX-License-Identifier: MIT
__version__ = "0.2.113"
