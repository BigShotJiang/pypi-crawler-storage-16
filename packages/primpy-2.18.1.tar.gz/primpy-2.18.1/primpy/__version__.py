"""Version file for primpy."""

__version__ = '2.18.1'
