"""Calculations for the primordial Universe w.r.t. e-folds `N`."""
