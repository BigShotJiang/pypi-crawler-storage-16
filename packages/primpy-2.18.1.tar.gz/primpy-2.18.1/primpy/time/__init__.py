"""Calculations for the primordial Universe w.r.t. time `t`."""
