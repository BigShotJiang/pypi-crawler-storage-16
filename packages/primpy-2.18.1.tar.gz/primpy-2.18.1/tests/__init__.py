#!/usr/bin/env python
"""Tests for `primpy`."""
