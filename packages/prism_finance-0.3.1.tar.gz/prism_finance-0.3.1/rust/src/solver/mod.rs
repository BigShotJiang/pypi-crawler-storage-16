pub mod problem;
pub mod optimizer;
mod ipopt_adapter;
pub mod ipopt_ffi; // Wrapper for raw C bindings (unchanged from original project)