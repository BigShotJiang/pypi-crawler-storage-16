"""
Test scripts for prisma-web3-py models and repositories.
"""
