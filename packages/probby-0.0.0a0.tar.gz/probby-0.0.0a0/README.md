# Probby

A Python library for working with probability distributions.

> **Note**
> This is an initial placeholder release to reserve the package name.
> The implementation and public API are not yet finalized.
