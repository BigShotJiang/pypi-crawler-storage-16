"""Version information for proctap package."""

# バージョンを更新する場合は、この1行だけを変更してください
__version__ = "1.0.3"
