# prod_assert
Prod safe python assert library
