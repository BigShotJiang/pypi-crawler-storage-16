# project-dumper
A python project flattener that exports small projects to a single txt file.
