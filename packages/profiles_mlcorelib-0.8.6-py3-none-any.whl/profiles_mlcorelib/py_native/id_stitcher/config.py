BASE_URL = "https://api.rudderstack.com/v2/"
LLM_ID_DEBUG_URL = BASE_URL + "profiles/idStitcher/debug"
LLM_INVOKE_URL = BASE_URL + "llm/invoke"
