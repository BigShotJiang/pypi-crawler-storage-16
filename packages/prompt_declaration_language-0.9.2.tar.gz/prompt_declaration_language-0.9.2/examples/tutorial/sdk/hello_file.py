from pdl.pdl import exec_file


def main():
    result = exec_file("./hello.pdl")
    print(result)


if __name__ == "__main__":
    main()
