pub const BEEAI_FRAMEWORK: &str = "-e git+https://github.com/starpit/bee-agent-framework.git@nick-meta-combo#egg=beeai_framework&subdirectory=python";
//pub const BEEAI_FRAMEWORK: &str = "beeai_framework==0.1";
