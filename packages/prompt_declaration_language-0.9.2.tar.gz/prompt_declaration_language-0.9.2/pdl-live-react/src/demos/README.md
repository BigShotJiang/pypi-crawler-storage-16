# Demo Traces

These demo traces were sourced as follows:

- demo1: From the top-level README
- demo2: [model_chaining.pdl](../../../examples/tutorial/model_chaining.pdl)
- demo3: [fib.pdl](../../../examples/fibonacci/fib.pdl)
- demo4: [chatbot.pdl](../../../examples/chatbot/chatbot.pdl)
- demo5: [6-code-json.pdl](../../../examples/talk/6-code-json.pdl)
- demo6: [error.pdl](../../demos/error.pdl)
- demo7: [4-talk.pdl](../../../examples/talk/4-function.pdl)
- demo8: [demo-hallucination](../../../examples/intrinsics/demo-hallucination.pdl). To run this currently requires... work. https://github.com/ibm-granite-community/granite-snack-cookbook/blob/main/recipes/Intrinsics/Granite_RAG_LoRA.ipynb
- demo9: [gsm8.pdl](../../../examples/gsm8k/gsm8.pdl)
