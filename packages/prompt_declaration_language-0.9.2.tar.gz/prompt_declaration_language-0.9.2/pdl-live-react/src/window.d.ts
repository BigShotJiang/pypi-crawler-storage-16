interface Window {
  __TAURI_INTERNALS__: Record<string, unknown>
}
