"""
promptv - A CLI tool for managing prompts locally with versioning
"""

__version__ = '1.0.0'
