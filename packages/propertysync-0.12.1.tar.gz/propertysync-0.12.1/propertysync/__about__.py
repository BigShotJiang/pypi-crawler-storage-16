# SPDX-FileCopyrightText: 2023-present Rob Martinson <rob@limelyte.com>
#
# SPDX-License-Identifier: MIT
__version__ = '0.12.1'
