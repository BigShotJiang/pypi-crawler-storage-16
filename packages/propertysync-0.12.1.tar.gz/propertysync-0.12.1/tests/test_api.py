import pytest
from unittest.mock import Mock, patch
from propertysync.api import ApiClient


@patch('propertysync.api.requests')
def test_save_batch_to_search_with_settings(mock_requests):
    """Test save_batch_to_search with multiple settings in dictionary"""
    # Mock the login response
    mock_login = Mock()
    mock_login.status_code = 200
    mock_login.json.return_value = {"token": "test-token"}

    # Mock the save_batch_to_search response
    mock_save = Mock()
    mock_save.status_code = 200
    mock_save.json.return_value = {"success": True}
    mock_save.headers = {"Content-Type": "application/json"}

    mock_requests.post.return_value = mock_login
    mock_requests.get.return_value = mock_save

    # Create API client
    api = ApiClient(
        email="test@example.com",
        password="password",
        document_group_id="test-group-id"
    )

    # Test with settings dictionary containing multiple parameters
    settings = {
        "triggerFallout": 0,
        "additionalParam": "test-value",
        "anotherSetting": 42
    }

    result = api.save_batch_to_search("test-batch-id", settings=settings)

    # Verify the API was called with correct parameters
    call_args = mock_requests.get.call_args
    params = call_args[1]['params']

    # Check base parameters
    assert params['exportTo'] == 'propertySync'
    assert params['batchId'] == 'test-batch-id'

    # Check settings were merged into params
    assert params['triggerFallout'] == 0
    assert params['additionalParam'] == 'test-value'
    assert params['anotherSetting'] == 42

    assert result == {"success": True}


@patch('propertysync.api.requests')
def test_save_batch_to_search_without_settings(mock_requests):
    """Test save_batch_to_search without settings parameter (None)"""
    # Mock responses
    mock_login = Mock()
    mock_login.status_code = 200
    mock_login.json.return_value = {"token": "test-token"}

    mock_save = Mock()
    mock_save.status_code = 200
    mock_save.json.return_value = {"success": True}
    mock_save.headers = {"Content-Type": "application/json"}

    mock_requests.post.return_value = mock_login
    mock_requests.get.return_value = mock_save

    # Create API client
    api = ApiClient(
        email="test@example.com",
        password="password",
        document_group_id="test-group-id"
    )

    # Test without settings (should only have exportTo and batchId)
    result = api.save_batch_to_search("test-batch-id")

    # Verify the API was called with correct parameters
    call_args = mock_requests.get.call_args
    params = call_args[1]['params']

    assert params['exportTo'] == 'propertySync'
    assert params['batchId'] == 'test-batch-id'

    # Ensure no additional settings were added
    assert len(params) == 2
    assert 'triggerFallout' not in params

    assert result == {"success": True}


@patch('propertysync.api.requests')
def test_save_batch_to_search_with_empty_settings(mock_requests):
    """Test save_batch_to_search with empty settings dictionary"""
    # Mock responses
    mock_login = Mock()
    mock_login.status_code = 200
    mock_login.json.return_value = {"token": "test-token"}

    mock_save = Mock()
    mock_save.status_code = 200
    mock_save.json.return_value = {"success": True}
    mock_save.headers = {"Content-Type": "application/json"}

    mock_requests.post.return_value = mock_login
    mock_requests.get.return_value = mock_save

    # Create API client
    api = ApiClient(
        email="test@example.com",
        password="password",
        document_group_id="test-group-id"
    )

    # Test with empty settings dictionary
    result = api.save_batch_to_search("test-batch-id", settings={})

    # Verify the API was called with correct parameters
    call_args = mock_requests.get.call_args
    params = call_args[1]['params']

    assert params['exportTo'] == 'propertySync'
    assert params['batchId'] == 'test-batch-id'

    # Should only have base parameters
    assert len(params) == 2

    assert result == {"success": True}

