"""Core module for Protolink framework."""

from .context_manager import ContextManager

__all__ = ["ContextManager"]
