"""Core utilities and abstractions"""

