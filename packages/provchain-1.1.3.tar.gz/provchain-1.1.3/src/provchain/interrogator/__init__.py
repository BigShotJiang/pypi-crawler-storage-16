"""Interrogator: Pre-install analysis engine"""

