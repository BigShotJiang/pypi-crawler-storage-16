"""Provenance verification methods"""

