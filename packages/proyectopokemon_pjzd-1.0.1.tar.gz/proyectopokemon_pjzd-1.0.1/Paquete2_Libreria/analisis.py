import os, asyncio, aiohttp
import pandas as pd
from functools import lru_cache

BASE_URL = "https://pokeapi.co/api/v2/pokemon"

class PokemonAnalyst:
    """ Clase para analizar estadísticas de Pokémon desde un CSV. """

    def __init__(self, csv_path='pokemon_stats.csv'):
        # Verificamos si existe el fichero antes de cargar
        if not os.path.exists(csv_path):
            raise FileNotFoundError(f"No se encuentra el fichero: {csv_path}")

        self.df = pd.read_csv(csv_path)
        # Normalizamos nombres de columnas por si acaso
        self.df.columns = [c.strip() for c in self.df.columns]

    def get_grupos_pokemon(self):
        """Devuelve una lista con los nombres de todos los grupos disponibles."""
        # Convertimos a lista simple
        return self.df['Nombre Grupo'].unique().tolist()

    @lru_cache(maxsize=32)
    def get_altura_media_grupo(self, grupo):
        """Devuelve la altura media de un grupo específico (usando caché)."""
        # Filtramos por grupo
        fila = self.df[self.df['Nombre Grupo'] == grupo]
        if fila.empty:
            return None
        return float(fila['Altura Media'].iloc[0])

    @lru_cache(maxsize=32)
    def get_peso_medio_grupo(self, grupo):
        """Devuelve el peso medio de un grupo específico (usando caché)."""
        fila = self.df[self.df['Nombre Grupo'] == grupo]
        if fila.empty:
            return None
        return float(fila['Peso Medio'].iloc[0])

# ---------------------------------------------------------
#  EXTRA - Funciones para que el usuario pueda generar CSV
# ---------------------------------------------------------

async def _get_full_pokemon_details(session: aiohttp.ClientSession, pokemon_url: str):
    """  Recupera datos de un Pokémon y sus egg_groups desde la PokeAPI usando su URL. """
    try:
        async with session.get(pokemon_url) as resp:
            resp.raise_for_status()
            data = await resp.json()

        species_url = data["species"]["url"]
        async with session.get(species_url) as resp_spec:
            resp_spec.raise_for_status()
            spec_data = await resp_spec.json()

        egg_groups = [g["name"] for g in spec_data.get("egg_groups", [])]

        return {
            "id": data["id"],
            "name": data["name"],
            "height": data.get("height", 0),
            "weight": data.get("weight", 0),
            "egg_groups": egg_groups,
        }
    except Exception as e:
        print(f"Error recuperando {pokemon_url}: {e}")
        return None


async def _download_pokemons(limit: int):
    """
    Descarga los datos de Pokémon, ajustando el límite al máximo disponible
    y usando las URLs devueltas por la API (evitando IDs inexistentes).
    """
    if limit <= 0:
        raise ValueError("El parámetro 'limit' debe ser mayor que 0.")

    async with aiohttp.ClientSession() as session:
        # Primero obtenemos el total real de pokémon
        async with session.get(BASE_URL, params={"limit": 1}) as resp:
            resp.raise_for_status()
            data = await resp.json()
            max_count = data.get("count", limit)

        if limit > max_count:
            print(
                f"Límite solicitado ({limit}) mayor que el máximo disponible ({max_count}). "
                f"Se usará {max_count}."
            )
            limit = max_count

        # Ahora pedimos la lista de 'limit' pokémon y usamos sus URLs
        async with session.get(BASE_URL, params={"limit": limit, "offset": 0}) as resp_list:
            resp_list.raise_for_status()
            list_data = await resp_list.json()
            results = list_data.get("results", [])

        tasks = [
            _get_full_pokemon_details(session, p["url"])
            for p in results
        ]
        return await asyncio.gather(*tasks)

def generar_csv_pokemon_stats(
    csv_path: str = "pokemon_stats.csv",
    limit: int = 100,
    ) -> str:
    """
    Genera un CSV con las estadísticas de altura y peso medios por grupo de Pokémon.

    - Descarga los `limit` primeros Pokémon desde PokeAPI.
    - Calcula la media de altura y peso por grupo.
    - Guarda el resultado en `csv_path`.
    - Devuelve la ruta del CSV generado.
    """
    raw_data = asyncio.run(_download_pokemons(limit))

    filas = []
    for p in raw_data:
        if not p:
            continue
        for grupo in p["egg_groups"]:
            filas.append(
                {
                    "Nombre Grupo": grupo,
                    "Altura Media": p["height"],
                    "Peso Medio": p["weight"],
                }
            )

    if not filas:
        raise RuntimeError("No se han podido obtener datos de PokeAPI.")

    df = pd.DataFrame(filas)
    stats_df = (
        df.groupby("Nombre Grupo")[["Altura Media", "Peso Medio"]]
        .mean()
        .reset_index()
    )

    stats_df.to_csv(csv_path, index=False)
    print(f"CSV generado en: {csv_path}")
    return csv_path

