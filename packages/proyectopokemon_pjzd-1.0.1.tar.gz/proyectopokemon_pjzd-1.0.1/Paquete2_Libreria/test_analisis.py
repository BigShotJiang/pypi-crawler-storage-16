import unittest
from unittest.mock import patch, MagicMock
import pandas as pd
import sys
import os

# Añadimos la carpeta actual a las rutas donde Python busca ficheros
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(current_dir)
# ------------------------------------------------------------------

from analisis import PokemonAnalyst

class TestPokemonAnalyst(unittest.TestCase):

    @patch('analisis.pd.read_csv')
    @patch('analisis.os.path.exists')
    def setUp(self, mock_exists, mock_read_csv):
        # Simulamos que el fichero existe
        mock_exists.return_value = True

        # Simulamos un DataFrame de prueba
        data = {
            'Nombre Grupo': ['monster', 'bug'],
            'Altura Media': [15.5, 5.2],
            'Peso Medio': [500.0, 20.0]
        }
        mock_read_csv.return_value = pd.DataFrame(data)

        # Instanciamos la clase pasando un nombre cualquiera
        self.analyst = PokemonAnalyst('falso.csv')

    def test_get_grupos_pokemon(self):
        grupos = self.analyst.get_grupos_pokemon()
        self.assertEqual(len(grupos), 2)
        self.assertIn('monster', grupos)

    def test_get_altura_media_grupo(self):
        # Caso existente
        altura = self.analyst.get_altura_media_grupo('monster')
        self.assertEqual(altura, 15.5)

        # Caso no existente
        altura_fake = self.analyst.get_altura_media_grupo('dragon')
        self.assertIsNone(altura_fake)

    def test_get_peso_medio_grupo(self):
        peso = self.analyst.get_peso_medio_grupo('bug')
        self.assertEqual(peso, 20.0)


if __name__ == '__main__':
    unittest.main()