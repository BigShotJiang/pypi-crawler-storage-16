# Librería Pokemon Stats

## Funcionalidades básicas

### 1. Método get_grupos_pokemon()
Devuelve una lista con todos los grupos de Pokémon disponibles en el fichero CSV.

### 2. Método get_altura_media_grupo(grupo)
Devuelve la altura media del grupo indicado.  
Si el grupo no existe, devuelve None.

### 3. Método get_peso_medio_grupo(grupo)
Devuelve el peso medio del grupo indicado.  
Si el grupo no existe, devuelve None.

### 4. Método generar_csv_pokemon_stats(limit=100)
Genera automáticamente un archivo `pokemon_stats.csv` descargando los datos de la PokeAPI.  
El parámetro `limit` permite indicar cuántos Pokémon se quieren considerar.  
Si se pasa un número mayor que el total disponible en la API, el método ajusta el valor automáticamente al máximo permitido.  
Devuelve la ruta del CSV generado.

### La forma de instalarlo es con:
pip install ProyectoPokemon-PJZD==1.0.1

# Ejemplos de importación en proyecto cliente:
from Paquete2_Libreria.analisis import PokemonAnalyst, generar_csv_pokemon_stats

## Ejemplo de uso :
### 1) Generar el CSV automáticamente (ajustará el límite si es necesario)
generar_csv_pokemon_stats(limit=100)

### 2) Analizar el archivo generado
pa = PokemonAnalyst("pokemon_stats.csv")

print(pa.get_grupos_pokemon())
['monster', 'bug', 'water1', 'fairy', ...]

print(pa.get_altura_media_grupo("monster"))
15.5

print(pa.get_peso_medio_grupo("bug"))
20.0

