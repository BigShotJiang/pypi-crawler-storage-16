from setuptools import setup

with open("README.md", encoding="utf-8") as f:
    long_description = f.read()

setup(
    # Nombre de la librería en PyPI
    name="ProyectoPokemon_PJZD",
    # Versión del paquete
    version="1.0.1",
    # Paquete(s) que se instalan
    packages=["Paquete2_Libreria"],
    # Licencia
    license="MIT",
    # Descripción corta
    description="Librería para consultar estadísticas de Pokémon por grupo a partir de un CSV.",
    # Descripción larga (README)
    long_description=long_description,
    long_description_content_type="text/markdown",
    # Autor
    author="Pedro Javier Zambudio Decillis",
    author_email="pjzambudio@gmail.com",
    # Palabras clave
    keywords=["curso", "pokemon", "consultas", "stats"],
    # Dependencias necesarias en tiempo de ejecución
    install_requires=[
        "pandas",
        "aiohttp",
    ],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Build Tools",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
    ],
)
