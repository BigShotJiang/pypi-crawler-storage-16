"""
SQL utilities for PRSedm — includes helper functions for locating/downloading the
variants.db file used for diabetes PRS scoring.
"""
from .get_dm_sql import get_dm_sql