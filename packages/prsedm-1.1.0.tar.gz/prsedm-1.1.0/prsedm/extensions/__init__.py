# scoreprs/__init__.py
from .score_dm import gen_dm

__all__ = ['gen_dm']
