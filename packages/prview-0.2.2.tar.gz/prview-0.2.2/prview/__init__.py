"""prview - Beautiful TUI and web dashboard for GitHub PRs and CI status."""

__version__ = "0.2.2"
