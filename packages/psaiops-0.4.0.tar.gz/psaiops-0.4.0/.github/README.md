# psAI ops <img src="images/logo.png" alt="apehex logo" width="32" height="32">

[![License][shield-license]][github-license]
[![Latest][shield-release]][github-release]

Collection of web apps to inspect & engineer activations.

## License

Licensed under the [aGPLv3][github-license].

[github-license]: LICENSE.md
[github-release]: https://github.com/apehex/psai-ops/releases/latest

[shield-license]: https://img.shields.io/badge/license-aGPLv3-green?style=flat-square
[shield-release]: https://img.shields.io/github/release/apehex/psai-ops.svg?style=flat-square
