"""Auto-generated PSDL types and metadata. DO NOT EDIT."""
