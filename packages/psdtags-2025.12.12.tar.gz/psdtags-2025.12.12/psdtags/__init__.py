# psdtags/__init__.py

from .psdtags import *
from .psdtags import __all__, __doc__, __version__

# constants are repeated for documentation

__version__ = __version__
"""Psdtags version string."""
