# psdtags/__main__.py

"""Psdtags package command line script."""

import sys

from .psdtags import main

sys.exit(main())
