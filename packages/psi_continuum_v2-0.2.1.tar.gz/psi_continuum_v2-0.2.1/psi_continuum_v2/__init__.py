"""
Psi-Continuum v2 — cosmology package.
Core models: LCDM, PsiCDM, likelihoods, loaders.
"""

from importlib.metadata import version

__all__ = ["cosmology"]
__version__ = version("psi-continuum-v2")
