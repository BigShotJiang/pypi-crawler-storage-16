"""
psychos: A Python library for creating and managing psychology experiments.

This software is licensed under the MIT License. See the LICENSE file in the root 
directory for full license terms.

(C) 2024 DMF Research Lab. All rights reserved.
"""

__version__ = "0.0.5"
__all__ = ["__version__"]
