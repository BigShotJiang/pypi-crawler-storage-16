# ptrepl
---
ptrepl is a Python REPL build on top of the [prompt_toolkit](https://github.com/jonathanslenders/python-prompt-toolkit) library. For now it's still still shipped with `prompt_toolkit` itself. Maybe, later on (when APIs are sure to be stable) we will pull it out and put it here instead.

To install `ptrepl-aero`, run:
```
pip install ptrepl-aero
```