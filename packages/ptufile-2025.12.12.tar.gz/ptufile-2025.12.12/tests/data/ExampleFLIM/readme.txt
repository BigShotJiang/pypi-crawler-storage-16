Obtained from https://zenodo.org/records/10148789

+---ExampleFLIM
|       Example2_6.ptu
|       Example_image.sc.ptu
