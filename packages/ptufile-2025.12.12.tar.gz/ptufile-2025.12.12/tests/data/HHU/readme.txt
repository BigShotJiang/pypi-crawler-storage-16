Obtained by email on Aug 27, 2025

+---HHU
|       PQSpcm_2021-12-13_17-53-45.ptu
