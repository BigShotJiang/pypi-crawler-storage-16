Obtained from PicoQuant on Jan 31, 2025

+---Luminosa
|   |   GattaQUant_Cells_FLIM.ptu
|   |
|   +---dsDNA Acceptor only  A655 , 134 uW , small volume
|   |       RawData.ptu
|   |
|   +---FRET_20230606-185222
|   |       RawData.ptu
|   |
|   \---mixture_dsDNA A655_Cy5_20221116-155706
|           RawData.ptu
