Obtained from Robert Molenaar on Nov 26, 2024

+---fastFLIM
|   |   A2_Shep2_26.ptu
|   |   B2_Shep2_2.ptu
|   |   B2_Shep2_3.ptu
