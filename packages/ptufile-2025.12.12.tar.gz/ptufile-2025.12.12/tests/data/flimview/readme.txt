Obtained from https://github.com/Biophotonics-COMI/flimview

+---flimview
|       macrophages.ptu
