Obtained by email on Oct 27, 2025

+---i3S
|        AlessandroSlide_10x_488nm.ptu
|        Coumarin6_10x_488nm.ptu
