Obtained from https://github.com/PicoQuant/image_from_ptu

+---image_from_ptu
|        RawImage.ptu
