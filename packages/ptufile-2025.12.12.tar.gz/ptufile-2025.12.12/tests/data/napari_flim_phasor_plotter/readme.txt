Obtained from https://github.com/zoccoler/napari-flim-phasor-plotter/tree/main/src/napari_flim_phasor_plotter/data

+---napari_flim_phasor_plotter
|       hazelnut_FLIM_single_image.ptu
|       hazelnut_FLIM_z_stack.zip
|       lifetime_cat.tif
|       lifetime_cat_labels.tif
|       lifetime_cat_metadata.yml
|       seminal_receptacle_FLIM_single_image.sdt
