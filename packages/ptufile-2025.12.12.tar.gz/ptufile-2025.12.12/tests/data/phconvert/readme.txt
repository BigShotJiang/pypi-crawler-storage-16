Obtained from https://github.com/Photon-HDF5/phconvert/issues/12

+---phconvert
|       161128_DM1_50pM_pH71.ptu
|       161128_DM1_50pM_pH73.ptu
|       161128_DM1_50pM_pH74.ptu
|       Cy3+Cy5_diff_PIE-FRET.ptu
