Obtained from https://github.com/SumeetRohilla/readPTU_FLIM, https://drive.google.com/file/d/1XtGL2yh_hJhaXIJhEDD5BpHNQXYQZX_p/view?usp=sharing

+---readPTU_FLIM
|       Test_FLIM_image_daisyPollen_PicoHarp_2.ptu
