"""
A standalone Python class for controlling G-code devices
via serial communication.

Provides methods for connection management, basic movement commands, and port discovery.
"""

import re
from typing import Optional, Dict, Tuple
import logging
from puda_drivers.core.serialcontroller import SerialController


class GCodeController(SerialController):
    DEFAULT_FEEDRATE = 3000  # mm/min
    MAX_FEEDRATE = 3000  # mm/min
    TOLERANCE = 0.01  # tolerance for position sync in mm

    PROTOCOL_TERMINATOR = "\r"

    def __init__(
        self,
        port_name: Optional[str] = None,
        baudrate: int = SerialController.DEFAULT_BAUDRATE,
        timeout: int = SerialController.DEFAULT_TIMEOUT,
        feed: int = DEFAULT_FEEDRATE,
    ):
        """
        Initializes the GCodeController.

        Args:
            port (Optional[str]): The serial port (e.g., 'COM5'). Defaults to None.
            baudrate (int): The baud rate for serial communication. Defaults to 9600.
            timeout (int): The read/write timeout in seconds. Defaults to 5.
        """
        super().__init__(port_name, baudrate, timeout)

        # Initialize instance-specific logger
        self._logger = logging.getLogger(__name__)
        self._logger.info(
            f"GCodeController initialized with port='{port_name}', baudrate={baudrate}, timeout={timeout}"
        )

        # Tracks internal position state
        self.current_position: Dict[str, float] = {
            "X": 0.0,
            "Y": 0.0,
            "Z": 0.0,
            "A": 0.0,
        }
        self._feed: int = feed
        self._is_absolute_mode: bool = True  # absolute mode by default

    @property
    def feed(self):
        """The current feed rate."""
        return self._feed

    @feed.setter
    def feed(self, new_feed: int):
        """Set the movement feed rate, enforcing the maximum limit."""

        # 1. Ensure the value is positive
        if new_feed <= 0:
            error_msg = f"Attempted to set invalid feed rate: {new_feed}. Must be > 0."
            self._logger.error(error_msg)
            raise ValueError(error_msg)

        # 2. Check and enforce the maximum rate
        if new_feed > self.MAX_FEEDRATE:
            # Log the change and cap the value
            self._logger.warning(
                f"Requested feed rate ({new_feed}) exceeds maximum ({self.MAX_FEEDRATE}). "
                f"Setting feed rate to maximum: {self.MAX_FEEDRATE}."
            )
            self._feed = self.MAX_FEEDRATE
        else:
            # Set the value normally
            self._feed = new_feed
            self._logger.debug(f"Feed rate set to: {self._feed} mm/min.")

    def _build_command(self, command: str) -> str:
        """Helper function to build a G-code command with terminator."""
        return f"{command}{self.PROTOCOL_TERMINATOR}"

    def home(self, axis: Optional[str] = None) -> None:
        """
        Homes one or all axes (G28 command).

        Args:
            axis (str, optional): The axis to home ('X', 'Y', 'Z', 'A', etc.).
                                  If None, homes all axes (G28).

        Raises:
            ValueError: If an invalid axis character is provided.
        """
        valid_axes = "XYZA"

        # 1. Axis Validation and Normalization, Command Construction
        if axis:
            axis = axis.upper()
            if axis not in valid_axes:
                self._logger.error(
                    f"Invalid axis '{axis}' provided for homing. Must be one of: {', '.join(valid_axes)}."
                )
                raise ValueError(
                    f"Invalid axis. Must be one of: {', '.join(valid_axes)}."
                )

            cmd = f"G28 {axis}"
            home_target = axis
        else:
            cmd = "G28"
            home_target = "All"

        # 2. Command Execution
        self._logger.info(f"[{cmd}] homing axis/axes: {home_target} **")
        # self._send_command(self._build_command(cmd))
        self._send_command("G28\r")
        self._logger.info(f"Homing of {home_target} completed.")

        # Verify position after homing
        # self.sync_position()

        # 3. Internal Position Update (Optimistic Zeroing)
        # If the homing was for a specific axis, zero only that axis.
        if axis:
            self.current_position[axis] = 0.0
        else:
            for key in self.current_position:
                self.current_position[key] = 0.0

        self._logger.debug(
            f"Internal position updated (optimistically zeroed) to {self.current_position}"
        )

    def move_absolute(
        self,
        x: Optional[float] = None,
        y: Optional[float] = None,
        z: Optional[float] = None,
        a: Optional[float] = None,
        feed: Optional[int] = None,
    ) -> None:
        """
        Moves the device to an absolute position (G90 + G1 command).
        """
        self._logger.info(
            f"Preparing absolute move to X:{x}, Y:{y}, Z:{z}, A:{a} at F:{feed if feed is not None else self._feed}"
        )

        # Ensure absolute mode is active
        if not self._is_absolute_mode:
            self._logger.debug("Switching to absolute positioning mode (G90).")
            self._send_command(self._build_command("G90"))
            self._is_absolute_mode = True

        self._execute_move(x=x, y=y, z=z, a=a, feed=feed)

    def move_relative(
        self,
        x: Optional[float] = None,
        y: Optional[float] = None,
        z: Optional[float] = None,
        a: Optional[float] = None,
        feed: Optional[int] = None,
    ) -> None:
        """
        Moves the device relative to the current position (G91 + G1 command).
        """
        self._logger.info(
            f"Preparing relative move by dX:{x}, dY:{y}, dZ:{z}, dA:{a} at F:{feed if feed is not None else self._feed}"
        )

        # Ensure relative mode is active
        if self._is_absolute_mode:
            self._logger.debug("Switching to relative positioning mode (G91).")
            self._send_command(self._build_command("G91"))
            self._is_absolute_mode = False

        self._execute_move(x=x, y=y, z=z, a=a, feed=feed)

    def _execute_move(
        self,
        x: Optional[float] = None,
        y: Optional[float] = None,
        z: Optional[float] = None,
        a: Optional[float] = None,
        feed: Optional[int] = None,
    ) -> None:
        """Internal helper for executing G1 move commands."""

        # 1. Map axis names to their input values
        move_deltas = {"X": x, "Y": y, "Z": z, "A": a}

        move_cmd = "G1"
        target_pos = self.current_position.copy()
        movement_occurred = False

        # 2. Build the G-code command and calculate target position
        for axis, value in move_deltas.items():
            if value is not None:
                move_cmd += f" {axis}{value}"

                # Calculate the target position
                if self._is_absolute_mode:
                    target_pos[axis] = value
                else:
                    target_pos[axis] = self.current_position[axis] + value

                movement_occurred = True

        # 3. Add on Feed Rate to command
        feed_rate = feed if feed is not None else self._feed
        # Final safety check on the rate used in the command
        if feed_rate > self.MAX_FEEDRATE:
            feed_rate = self.MAX_FEEDRATE
        move_cmd += f" F{feed_rate}"

        # 4. Check for movement and return if none
        if not movement_occurred:
            self._logger.warning(
                "Move command issued without any axis movement. Skipping transmission."
            )
            return

        # 5. Execute command and update position (Optimistic update)
        self._logger.info(f"Executing move command: {move_cmd}")
        self._send_command(self._build_command(move_cmd))

        self._logger.info(
            f"Move complete. Updating internal position from {self.current_position} to {target_pos}"
        )

        self.current_position = target_pos
        self._logger.debug(f"New internal position: {self.current_position}")

        # 6. Post-Move Position Synchronization Check
        self.sync_position()

    def query_position(self) -> Dict[str, float]:
        """
        Queries the Qubot for its current machine position (M114 command).

        Returns:
            Dict[str, float]: A dictionary containing the updated X, Y, Z, and A positions.
        """
        self._logger.info("Querying current machine position (M114).")
        self._send_command(self._build_command("M114"))
        res: str = self._read_response()

        # Extract position values using regex
        pattern = re.compile(r"([XYZAE]):(\-?\d+\.\d+)")
        # Find all matches (e.g., [('X', '0.000'), ('Y', '0.000'), ...])
        matches = pattern.findall(res)

        position_data: Dict[str, float] = {}

        for axis, value_str in matches:
            try:
                position_data[axis] = float(value_str)
            except ValueError:
                self._logger.error(
                    f"Failed to convert position value '{value_str}' for axis {axis} to float."
                )
                continue

        return position_data

    def sync_position(self) -> Tuple[bool, Dict[str, float]]:
        """
        Queries the Qubot for its current machine position (M114) and
        automatically adjusts the controller's internal 'current_position'
        if a discrepancy is found.

        Returns:
            Tuple[bool, Dict[str, float]]: A tuple where the first element
            is True if a synchronization/adjustment occurred, and the second
            is the final, synchronized position dictionary.
        """
        self._logger.info("Starting position synchronization check (M114).")

        # 1. Query the actual machine position
        queried_position = self.query_position()

        # Check if the query was unsuccessful (only returns empty dict)
        if not queried_position:
            self._logger.warning("Query position failed. Cannot synchronize.")
            return False, self.current_position

        # 2. Compare internal vs. queried position
        axis_keys = ["X", "Y", "Z", "A"]
        adjustment_needed = False

        for axis in axis_keys:
            # Check if axis exists in both dictionaries and if they differ significantly
            if (
                axis in self.current_position
                and axis in queried_position
                and abs(self.current_position[axis] - queried_position[axis])
                > self.TOLERANCE
            ):
                self._logger.warning(
                    f"Position mismatch found on {axis} axis: "
                    f"Internal={self.current_position[axis]:.3f}, "
                    f"Queried={queried_position[axis]:.3f}"
                )

                adjustment_needed = True

            elif axis in queried_position:
                # Update internal position with actual queried position if it differs very slightly
                self.current_position[axis] = queried_position[axis]

        # 3. Perform Re-Synchronization Move if needed
        if adjustment_needed:
            self._logger.info(
                f"** DISCREPANCY DETECTED. Moving robot back to internal position: {self.current_position} **"
            )

            try:
                # Extract the X, Y, Z, A coordinates from the internal position for the move
                target_x = self.current_position.get("X")
                target_y = self.current_position.get("Y")
                target_z = self.current_position.get("Z")
                target_a = self.current_position.get("A")

                self.move_absolute(x=target_x, y=target_y, z=target_z, a=target_a)
                self._logger.info("Synchronization move successfully completed.")

                # recursive call to verify position after move
                self.sync_position()
            except Exception as e:
                self._logger.error(f"Synchronization move failed: {e}")
                adjustment_needed = False  # Indicate failure in adjustment, though original discrepancy remains.

        final_position = self.current_position.copy()

        if adjustment_needed:
            self._logger.info(
                f"Position check complete. Internal position is synchronized with machine."
            )
        else:
            self._logger.info("No adjustment was made.")

        # Note: If adjustment_needed was True, it means a move was attempted.
        # We return the initial state of adjustment_needed (i.e., if a move was triggered).
        return adjustment_needed, final_position

    def get_info(self) -> str:
        """
        Queries the Qubot for machine information (M115 command).

        Returns:
            str: The machine information string.
        """
        self._logger.info("Querying machine information (M115).")
        self._send_command(self._build_command("M115"))
        res: str = self._read_response()
        return res

    def get_internal_position(self) -> Dict[str, float]:
        """
        Returns the internally tracked position.
        """
        self._logger.debug(f"Returning internal position: {self.current_position}")
        return self.current_position
