import time
import logging
from typing import Optional
from puda_drivers.core.serialcontroller import SerialController
from .constants import STATUS_CODES


class SartoriusDeviceError(Exception):
    """Custom exception raised when the Sartorius device reports an error."""

    pass


class SartoriusController(SerialController):
    """
    A standalone Python class for controlling a Sartorius pipette or robotic
    dispenser via serial communication, using a custom, byte-based command protocol.
    """

    # --- Protocol Constants (Hypothetical) ---
    DEFAULT_BAUDRATE = 9600
    DEFAULT_TIMEOUT = 10

    PROTOCOL_SOH = "\x01"
    SLAVE_ADDRESS = "1"
    PROTOCOL_TERMINATOR = "º\r"  # Assuming 'º' is part of the terminator sequence

    # --- Sartorius rLine Settings ---
    STEPS_PER_MICROLITER = 2
    SUCCESS_RESPONSE = "ok"
    ERROR_RESPONSE = "err"

    def __init__(
        self,
        port_name: Optional[str] = None,
        baudrate: int = DEFAULT_BAUDRATE,
        timeout: int = DEFAULT_TIMEOUT,
    ):
        super().__init__(port_name, baudrate, timeout)
        self._logger = logging.getLogger(__name__)
        self._logger.info(
            f"Sartorius Controller initialized with port='{port_name}', baudrate={baudrate}, timeout={timeout}"
        )

    def _build_command(self, command_code: str, value: str = "") -> str:
        """Helper to assemble the custom command string."""
        cmd = (
            self.PROTOCOL_SOH
            + self.SLAVE_ADDRESS
            + "R"
            + command_code
            + value
            + self.PROTOCOL_TERMINATOR
        )
        return cmd

    def initialize(self) -> None:
        """
        Initializes the pipette unit (RZ command).
        """
        command = self._build_command(command_code="Z")
        self._logger.info("** Initializing Pipette Head (RZ) **")

        self._send_command(command)
        res: str = self._read_response()

        if "err" in res:
            raise SartoriusDeviceError(
                f"Pipette initialization failed with error: {res}"
            )
        self._logger.info("** Pipette Initialization Complete **")

    # different from docs
    def get_inward_speed(self) -> int:
        """
        Queries the current aspirating speed (SI command). Speed is 1-6.
        """
        command = self._build_command(command_code="DI")
        self._logger.info("** Querying Inward Speed (DI) **")

        self._send_command(command)
        res: str = self._read_response()
        if "err" in res:
            raise SartoriusDeviceError(f"Inward speed query failed with error: {res}")

        self._logger.info(f"** Current Inward Speed: {res[1]} **")
        return int(res[1])

    def set_inward_speed(self, speed: int) -> None:
        """
        Sets the aspirating speed (SI command). Speed is 1-6.
        """
        if not 1 <= speed <= 6:
            raise ValueError("Inward speed must be between 1 and 6.")

        command = self._build_command(command_code="I", value=str(speed))
        self._logger.info(f"** Setting Inward Speed (SI, Speed: {speed}) **")

        self._send_command(command)
        res: str = self._read_response()
        if "err" in res:
            raise SartoriusDeviceError(f"Setting inward speed failed with error: {res}")
        self._logger.info(f"** Inward Speed Set to {speed} Successfully **")

    def get_outward_speed(self) -> int:
        """
        Queries the current dispensing speed (DO command). Speed is 1-6.
        """
        command = self._build_command(command_code="DO")
        self._logger.info("** Querying Outward Speed (DO) **")

        self._send_command(command)
        res: str = self._read_response()
        if "err" in res:
            raise SartoriusDeviceError(f"Outward speed query failed with error: {res}")

        self._logger.info(f"** Current Outward Speed: {res[1]} **")
        return int(res[1])

    def set_outward_speed(self, speed: int) -> None:
        """
        Sets the dispensing speed (SO command). Speed is 1-6.
        """
        if not 1 <= speed <= 6:
            raise ValueError("Outward speed must be between 1 and 6.")

        self._logger.info(f"** Setting Outward Speed (SO, Speed: {speed}) **")

        command = self._build_command(command_code="O", value=str(speed))
        self._send_command(command)
        res: str = self._read_response()
        if "err" in res:
            raise SartoriusDeviceError(
                f"Setting outward speed failed with error: {res}"
            )
        self._logger.info(f"** Outward Speed Set to {speed} Successfully **")

    def run_to_position(self, position: int) -> None:
        """
        Drives the piston to the absolute step position nnn (RP command).
        Steps must be given without leading zeros.
        """
        position_str = str(position)
        # Check if position has leading zeros (RP030 is incorrect)
        if len(position_str) > 1 and position_str.startswith("0"):
            raise ValueError("Position value for RP must not have leading zeros.")

        command = self._build_command(command_code="P", value=position_str)
        self._logger.info(f"** Run to absolute Position (RP, Position: {position}) **")

        self._send_command(command)
        res: str = self._read_response()
        if "err" in res:
            raise SartoriusDeviceError(f"Run to position failed with error: {res}")

        self._logger.info(f"** Reached Position {position} Successfully **")

    def aspirate(self, amount: int) -> None:
        """
        Aspirates fluid, amount in microliters.
        """
        steps = amount * self.STEPS_PER_MICROLITER
        command = self._build_command(command_code="I", value=str(steps))
        self._logger.info(f"** Aspirating {amount} uL (RI{steps}) **")

        self._send_command(command)
        res: str = self._read_response()
        if "err" in res:
            raise SartoriusDeviceError(f"Aspirate failed with error: {res}")
        self._logger.info(f"** Aspirated {amount} uL Successfully **")

    def dispense(self, amount: int) -> None:
        """
        Dispenses fluid, moving the plunger outwards by nnn steps (RO command).
        Steps must be given without leading zeros.
        """
        steps = amount * self.STEPS_PER_MICROLITER

        command = self._build_command(command_code="O", value=str(steps))
        self._logger.info(f"** Dispensing {amount} uL (RO{steps}) **")

        self._send_command(command)
        res: str = self._read_response()
        if "err" in res:
            raise SartoriusDeviceError(f"Dispense failed with error: {res}")
        self._logger.info(f"** Dispensed {amount} uL Successfully **")

    def eject_tip(self, return_position: Optional[int] = None) -> None:
        """
        Runs the tip eject cycle (RE command).
        If return_position is None (RE), returns to position 0.
        If return_position is specified (RE nnn), returns to that position.
        """
        if return_position is not None:
            position_str = str(return_position)
            if len(position_str) > 1 and position_str.startswith("0"):
                raise ValueError(
                    "Return position value for RE must not have leading zeros."
                )
            command = self._build_command(command_code="E", value=position_str)
            self._logger.info(
                f"** Ejecting Tip and returning to position {return_position} (RE {return_position}) **"
            )
        else:
            command = self._build_command(command_code="E")
            self._logger.info("** Ejecting Tip and returning to position 0 (RE) **")

        self._send_command(command)
        res: str = self._read_response()
        if "err" in res:
            raise SartoriusDeviceError(f"Tip ejection failed with error: {res}")
        self._logger.info("** Tip Ejection Complete **")

    def run_blowout(self, return_position: Optional[int] = None) -> None:
        """
        Runs the blowout cycle (RB command).
        If return_position is None (RB), completes the blowout.
        If return_position is specified (RB nnn), returns to that position.
        """
        if return_position is not None:
            position_str = str(return_position)
            if len(position_str) > 1 and position_str.startswith("0"):
                raise ValueError(
                    "Return position value for RB must not have leading zeros."
                )
            command = self._build_command(command_code="B", value=position_str)
            self._logger.info(
                f"** Running Blowout and returning to position {return_position} (RB {return_position}) **"
            )
        else:
            command = self._build_command(command_code="B")
            self._logger.info("** Running Blowout (RB) **")

        self._send_command(command)
        res: str = self._read_response()
        if "err" in res:
            raise SartoriusDeviceError(f"Blowout failed with error: {res}")
        self._logger.info("** Blowout Complete **")

    def get_status(self) -> str:
        """
        Queries the current status of the pipette (DS command).
        Returns a status code string.
        """
        command = self._build_command(command_code="DS")
        self._logger.info("** Querying Pipette Status (DS) **")

        self._send_command(command)
        res: str = self._read_response()
        if "err" in res:
            raise SartoriusDeviceError(f"Status query failed with error: {res}")

        if len(res) > 1 and res[1] in STATUS_CODES:
            status_message = STATUS_CODES[res[1]]
            self._logger.info(f"Pipette Status Code [{res[1]}]: {status_message}")
        else:
            self._logger.info(f"Pipette Status Code [{res[1]}]: Unknown Status Code")
        return res[1]
