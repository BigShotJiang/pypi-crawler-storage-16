import logging
from puda_drivers.move import GCodeController

# Optinal: finding ports
# import serial.tools.list_ports
# for port, desc, hwid in serial.tools.list_ports.comports():
#     print(f"{port}: {desc} [{hwid}]")

# 1. Configure the root logger
# All loggers in imported modules (SerialController, GCodeController) will inherit this setup.
logging.basicConfig(
    # Use logging.DEBUG to see all (DEBUG, INFO, WARNING, ERROR, CRITICAL) logs
    level=logging.DEBUG,
    # Recommended format: includes time, logger name, level, and message
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)

# 2. OPTIONAL: If you only want GCodeController's logs at specific level, you can specifically set it here
# logging.getLogger('drivers.gcodecontroller').setLevel(logging.INFO)

PORT_NAME = "/dev/ttyACM1"


def main():
    print("--- Starting GCode Controller Application ---")

    try:
        # Instantiate the qubot controller
        qubot = GCodeController(port_name=PORT_NAME)

        qubot.query_position()
        # Always start with homing
        qubot.home()

        # qubot.query_position()
        # qubot.sync_position()

        # Should generate WARNING due to exceeding MAX_FEEDRATE (3000)
        # qubot.feed = 5000

        # qubot.move_relative(x=20.0, y=-10.0)
        #
        # qubot.move_absolute(x=50.0, y=-100.0, z=-10.0)

        # Example of an ERROR
        # try:
        #     qubot.home(axis="B")  # Generates ERROR
        # except ValueError:
        #     pass

    except Exception as e:
        logging.getLogger(__name__).error(f"An unrecoverable error occurred: {e}")


if __name__ == "__main__":
    main()
