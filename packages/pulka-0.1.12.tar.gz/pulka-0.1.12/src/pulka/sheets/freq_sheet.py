"""Compatibility wrapper for legacy frequency sheet imports."""

from pulka_builtin_plugins.freq.plugin import FreqSheet, register_frequency_ui_handle

__all__ = ["FreqSheet", "register_frequency_ui_handle"]
