"""Compatibility wrapper for legacy summary sheet imports."""

from pulka_builtin_plugins.summary.plugin import SummarySheet

__all__ = ["SummarySheet"]
