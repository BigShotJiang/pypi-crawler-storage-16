"""Frequency table plugin for Pulka."""

from .plugin import FreqSheet, register

__all__ = ["FreqSheet", "register"]
