default_app_config = "pulp_python.app.PulpPythonPluginAppConfig"
