import logging

deprecation_logger = logging.getLogger("pulpcore.deprecation")
