"""Errors raised by Pulser.

Note: As of this writing, the specific error strings for these classes are
maintained for backwards compatibility. However, they may change in a future
version, so if you need to catch a specific error, you should rather rely
upon its class and fields.
"""
