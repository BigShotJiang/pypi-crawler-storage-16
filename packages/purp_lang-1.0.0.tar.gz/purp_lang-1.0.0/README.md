# Purp 🟣

**A programming language designed for humans.**

Purp combines the best of Python, Java, and C into one beautifully simple language that anyone can learn in a day but use for a lifetime.

## File Extension

All Purp source files use the `.purp` extension.

## Installation

### Method 1: Install from PyPI (Recommended)

```bash
pip install purp-lang
```

After installation, you can use the `purp` command directly:

```bash
# Run a Purp program
purp hello.purp

# Start interactive REPL
purp

# Show version
purp --version
```

### Method 2: Install from Source

```bash
# Clone the repository
git clone https://github.com/PurpleTrex/purp-lang.git
cd purp-lang

# Install in development mode
pip install -e .

# Now you can use 'purp' command
purp examples/hello.purp
```

### Method 3: Run Directly with Python (No Installation)

```bash
# Download purp.py and run directly
python purp.py examples/hello.purp

# Start interactive REPL
python purp.py
```

## Quick Start

Create a file called `hello.purp`:

```purp
say "Hello, World!"
```

Run it:

```bash
purp hello.purp
```

## Hello World

```purp
say "Hello, World!"
```

## Features at a Glance

```purp
-- Variables (no type declarations needed)
name is "Alice"
age is 25
is_active is true

-- Constants
PI always is 3.14159

-- Functions
define greet(person)
    say "Hello, " + person + "!"
end

define add(a, b)
    return a + b
end

-- Classes
class Dog
    has name
    has breed
    
    does bark()
        say this.name + " says Woof!"
    end
end

my_dog is new Dog()
my_dog.name is "Rex"
my_dog.bark()

-- Control flow
if age >= 18
    say "Adult"
else
    say "Minor"
end

-- Loops
for i in range(1, 6)
    say i
end

for item in items
    say item
end

while running
    process()
end

-- Lists
numbers is [1, 2, 3, 4, 5]
push(numbers, 6)
first is numbers[0]

-- Maps/Dictionaries
person is {name: "Alice", age: 25}
say person.name
```

## Built-in Functions

| Function | Description |
|----------|-------------|
| `say(...)` | Print values with newline |
| `write(...)` | Print values without newline |
| `ask(prompt)` | Read input from user |
| `type(value)` | Get type name as string |
| `length(value)` | Get length of string/list/map |
| `number(value)` | Convert to number |
| `text(value)` | Convert to string |
| `range(start, end)` | Create list of numbers |
| `push(list, item)` | Add item to list |
| `pop(list)` | Remove and return last item |
| `abs(n)` | Absolute value |
| `round(n)` | Round to nearest integer |
| `floor(n)` | Round down |
| `sqrt(n)` | Square root |

## Examples

Check out the [examples/](examples/) directory:

- `hello.purp` - Hello World
- `variables.purp` - Variables and types
- `functions.purp` - Function definitions
- `control_flow.purp` - If/else and loops
- `classes.purp` - Object-oriented programming
- `fizzbuzz.purp` - Classic FizzBuzz
- `calculator.purp` - Simple calculator

## Documentation

See [docs/SPECIFICATION.md](docs/SPECIFICATION.md) for the complete language specification.

## Project Structure

```
purp/
├── purp.py              # Python-based interpreter (main entry point)
├── build.ps1            # Windows build script
├── src/
│   ├── purp.h           # C header file
│   ├── lexer.c          # Tokenizer
│   ├── parser.c         # Parser
│   ├── interpreter.c    # Tree-walking interpreter
│   ├── builtins.c       # Built-in functions
│   ├── values.c         # Value operations
│   ├── compiler.c       # Bytecode compiler
│   ├── vm.c             # Virtual machine
│   └── main.c           # CLI entry point
├── examples/            # Example .purp programs
└── docs/                # Documentation
    └── SPECIFICATION.md # Complete language spec
```

## Requirements

**For Python interpreter:**
- Python 3.8 or higher

**For native compiler (optional):**
- GCC, Clang, or MSVC C compiler

## License

MIT License
