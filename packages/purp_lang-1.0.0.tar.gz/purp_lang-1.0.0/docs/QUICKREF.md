# Purp Quick Reference Card 🟣

## Installation

```bash
pip install purp-lang
```

## Running Programs

```bash
purp myprogram.purp    # Run a file
purp                   # Interactive REPL
```

## Basic Syntax

### Variables & Constants
```purp
name is "Alice"           -- Variable
PI always is 3.14159      -- Constant
```

### Data Types
```purp
number is 42              -- Number
text is "Hello"           -- String  
flag is true              -- Boolean (true/false)
empty is nothing          -- Null/None
items is [1, 2, 3]        -- List
data is {name: "Bob"}     -- Map/Dictionary
```

### Operators
```purp
-- Arithmetic
a + b    a - b    a * b    a / b    a % b    a ^ b (power)

-- Comparison
a == b   a != b   a < b    a > b    a <= b   a >= b

-- Logical
a and b    a or b    not a

-- Compound Assignment
x += 1    x -= 1    x *= 2    x /= 2
```

### Output
```purp
say "Hello, World!"       -- Print with newline
say "Name:", name         -- Multiple values
write "No newline"        -- Print without newline
```

### Input
```purp
name is ask "Enter name: "
```

### Conditionals
```purp
if score >= 90
    say "A"
elif score >= 80
    say "B"
else
    say "C"
end
```

### Loops
```purp
-- For-in loop
for item in [1, 2, 3]
    say item
end

-- For range loop
for i from 1 to 10
    say i
end

-- For with step
for i from 0 to 100 by 10
    say i
end

-- While loop
while count > 0
    say count
    count -= 1
end
```

### Functions
```purp
define greet(name)
    return "Hello, " + name
end

result is greet("World")
```

### Lambdas
```purp
double is lambda (x) -> x * 2
say double(5)    -- 10

-- With higher-order functions
squares is map([1,2,3], lambda (x) -> x * x)
```

### Classes
```purp
class Animal
    has name
    has species
    
    does speak()
        say this.name + " makes a sound"
    end
end

dog is new Animal()
dog.name is "Buddy"
dog.speak()
```

### Inheritance
```purp
class Dog extends Animal
    does speak()
        say this.name + " barks!"
    end
end
```

### Error Handling
```purp
try
    result is risky_operation()
catch error
    say "Error: " + error
finally
    cleanup()
end

raise "Something went wrong!"
```

### Pattern Matching
```purp
match day
    when 1
        say "Monday"
    when 6, 7
        say "Weekend"
    else
        say "Weekday"
end
```

## Built-in Functions

### I/O
- `say(...)` - Print with newline
- `write(...)` - Print without newline
- `ask(prompt)` - Read input

### Type Conversion
- `text(value)` - To string
- `int(value)` - To integer
- `float(value)` - To float
- `bool(value)` - To boolean
- `type(value)` - Get type name

### Math
- `abs(n)` `round(n)` `floor(n)` `ceil(n)`
- `sqrt(n)` `pow(a, b)` `min(...)` `max(...)`
- `sum(list)` `random(min, max)`

### Strings
- `length(s)` `upper(s)` `lower(s)` `trim(s)`
- `split(s, delim)` `join(list, delim)`
- `replace(s, old, new)`
- `starts_with(s, prefix)` `ends_with(s, suffix)`

### Collections
- `length(list)` `push(list, item)` `pop(list)`
- `first(list)` `last(list)` `reverse(list)` `sort(list)`
- `contains(list, item)` `index_of(list, item)`
- `keys(map)` `values(map)`

### Functional
- `map(list, func)` - Transform each item
- `filter(list, func)` - Keep matching items
- `reduce(list, func, init)` - Accumulate
- `foreach(list, func)` - Execute for each

### Files
- `read_file(path)` - Read file contents
- `write_file(path, content)` - Write to file
- `file_exists(path)` - Check if file exists

### GUI (Tkinter)
- `gui_window(title, w, h)` - Create window
- `gui_button(parent, text, callback)` - Button
- `gui_label(parent, text)` - Label
- `gui_entry(parent)` - Text input
- `gui_pack(widget, ...)` - Layout
- `gui_run(window)` - Start GUI
- `gui_messagebox(title, msg, type)` - Popup

## Comments
```purp
-- This is a comment
// This also works
```

---
*Purp Programming Language v1.0.0*
