#!/usr/bin/env python3
"""
Setup script for the Purp Programming Language.
This allows users to install Purp using pip.
"""

from setuptools import setup, find_packages
import os

# Read the README for the long description
def read_readme():
    readme_path = os.path.join(os.path.dirname(__file__), 'README.md')
    if os.path.exists(readme_path):
        with open(readme_path, 'r', encoding='utf-8') as f:
            return f.read()
    return "Purp Programming Language"

setup(
    name='purp-lang',
    version='1.0.0',
    author='Purple',
    author_email='your.email@example.com',
    description='The Purp Programming Language - A clean, readable programming language',
    long_description=read_readme(),
    long_description_content_type='text/markdown',
    url='https://github.com/PurpleTrex/purp-lang',
    
    # Include the main purp.py as a module
    py_modules=['purp'],
    
    # Python version requirement
    python_requires='>=3.8',
    
    # No external dependencies required (uses only standard library)
    install_requires=[],
    
    # Create command-line entry point
    entry_points={
        'console_scripts': [
            'purp=purp:main',
        ],
    },
    
    # Package metadata
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Intended Audience :: Education',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Topic :: Software Development :: Interpreters',
        'Topic :: Software Development :: Compilers',
    ],
    
    # Keywords for PyPI search
    keywords='programming language interpreter purp educational',
    
    # Include example files
    package_data={
        '': ['examples/*.purp', 'docs/*.md'],
    },
    
    # Project URLs
    project_urls={
        'Documentation': 'https://github.com/PurpleTrex/purp-lang#readme',
        'Source': 'https://github.com/PurpleTrex/purp-lang',
        'Bug Tracker': 'https://github.com/PurpleTrex/purp-lang/issues',
    },
)
