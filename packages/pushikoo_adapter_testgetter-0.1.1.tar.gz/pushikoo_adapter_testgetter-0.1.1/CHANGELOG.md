# Changelog

## [0.1.1](https://github.com/Pushikoo/pushikoo-adapter-testgetter/compare/v0.1.0...v0.1.1) (2025-12-13)


### Miscellaneous Chores

* release trigger ([69a84f4](https://github.com/Pushikoo/pushikoo-adapter-testgetter/commit/69a84f410fe84c0bee2e916d6bef360aad240d0e))

## [0.1.0](https://github.com/Pushikoo/pushikoo-adapter-testgetter/compare/v0.0.1...v0.1.0) (2025-11-17)


### Features

* add loguru dependency and logging support ([e8f995d](https://github.com/Pushikoo/pushikoo-adapter-testgetter/commit/e8f995d04d51f6cb460be14bb50eda8033d0e6d5))
* rename GetterClassConfig to GetterConfig and update references ([66b07df](https://github.com/Pushikoo/pushikoo-adapter-testgetter/commit/66b07df2f9d4a3d773bae3871d34c89963bd4b9d))
* rename id parameters to identifier for clarity ([79661e9](https://github.com/Pushikoo/pushikoo-adapter-testgetter/commit/79661e990c018830ce00528e199cdb8e9173a7d8))
