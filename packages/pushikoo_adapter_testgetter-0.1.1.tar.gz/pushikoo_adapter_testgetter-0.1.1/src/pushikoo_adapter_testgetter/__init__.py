from pushikoo_adapter_testgetter.main import TestGetter

__all__ = ["TestGetter"]
