<div align="center">

# pushikoo-adapter-testpusher

TestPusher for pushikoo-adapter development as a template.

[![uv](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/uv/main/assets/badge/v0.json)](https://github.com/astral-sh/uv)
[![GitHub Actions Workflow Status](https://img.shields.io/github/actions/workflow/status/Pushikoo/pushikoo-adapter-testpusher/package.yml)](https://github.com/Pushikoo/pushikoo-adapter-testpusher/actions)
[![Python](https://img.shields.io/pypi/pyversions/pushikoo-adapter-testpusher)](https://pypi.org/project/pushikoo-adapter-testpusher)
[![PyPI version](https://badge.fury.io/py/pushikoo-adapter-testpusher.svg)](https://pypi.org/project/pushikoo-adapter-testpusher)
[![License](https://img.shields.io/github/license/Pushikoo/pushikoo-adapter-testpusher.svg)](https://pypi.org/project/pushikoo-adapter-testpusher/)

</div>
