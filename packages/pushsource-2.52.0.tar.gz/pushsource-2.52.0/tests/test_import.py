"""Placeholder test until real tests are implemented"""


def test_can_import():
    import pushsource
