"""Base classes for puzzle games."""

from .puzzle_game import PuzzleGame

__all__ = ["PuzzleGame"]
