"""Utility functions for puzzle games."""

# Utilities can be added here as needed
# For example: ASCII art generators, difficulty calculators, etc.
