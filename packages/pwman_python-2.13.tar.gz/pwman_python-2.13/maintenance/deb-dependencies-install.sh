#!/bin/sh

exec apt install \
	git \
	python3 \
	python3-argon2 \
	python3-cffi \
	python3-pyaes \
	python3-pycryptodome
