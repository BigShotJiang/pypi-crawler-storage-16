class PairingError(Exception):
    """Error preventing successful pairing of rounds."""

    pass
