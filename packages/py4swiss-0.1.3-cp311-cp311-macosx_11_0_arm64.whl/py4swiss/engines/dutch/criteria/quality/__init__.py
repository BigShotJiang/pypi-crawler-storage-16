from py4swiss.engines.dutch.criteria.quality.c5 import C5
from py4swiss.engines.dutch.criteria.quality.c6 import C6
from py4swiss.engines.dutch.criteria.quality.c7 import C7
from py4swiss.engines.dutch.criteria.quality.c8 import C8
from py4swiss.engines.dutch.criteria.quality.c9 import C9
from py4swiss.engines.dutch.criteria.quality.c10 import C10
from py4swiss.engines.dutch.criteria.quality.c11 import C11
from py4swiss.engines.dutch.criteria.quality.c12 import C12
from py4swiss.engines.dutch.criteria.quality.c13 import C13
from py4swiss.engines.dutch.criteria.quality.c14 import C14
from py4swiss.engines.dutch.criteria.quality.c15 import C15
from py4swiss.engines.dutch.criteria.quality.c16 import C16
from py4swiss.engines.dutch.criteria.quality.c17 import C17
from py4swiss.engines.dutch.criteria.quality.c18 import C18
from py4swiss.engines.dutch.criteria.quality.c19 import C19

__all__ = ["C5", "C6", "C7", "C8", "C9", "C10", "C11", "C12", "C13", "C14", "C15", "C16", "C17", "C18", "C19"]
