::: py_ballisticcalc.conditions.Wind
    options:
        group_by_category: false
        members: