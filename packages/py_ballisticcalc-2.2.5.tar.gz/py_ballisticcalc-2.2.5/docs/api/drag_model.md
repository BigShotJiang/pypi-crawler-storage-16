::: py_ballisticcalc.drag_model
    options:
        group_by_category: false
        members:
