::: py_ballisticcalc.exceptions
    options:
        group_by_category: false
        members:
