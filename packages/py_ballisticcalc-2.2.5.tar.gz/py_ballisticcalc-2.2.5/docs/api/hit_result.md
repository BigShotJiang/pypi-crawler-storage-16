::: py_ballisticcalc.trajectory_data.HitResult
    options:
        group_by_category: false
        members:

::: py_ballisticcalc.trajectory_data.DangerSpace
    options:
        group_by_category: false
        members: