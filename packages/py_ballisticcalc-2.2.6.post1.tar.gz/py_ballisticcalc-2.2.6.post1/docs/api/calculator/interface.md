::: py_ballisticcalc.interface.Calculator
    options:
        filters: ["!^_a-z", "!^cdm"]

::: py_ballisticcalc.interface._EngineLoader
    options:
        group_by_category: false
        members:
