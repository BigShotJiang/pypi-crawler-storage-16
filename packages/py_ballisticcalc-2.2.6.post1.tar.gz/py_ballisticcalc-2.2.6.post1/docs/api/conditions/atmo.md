::: py_ballisticcalc.conditions.Atmo
    options:
        group_by_category: false
        members:

::: py_ballisticcalc.conditions.Vacuum
    options:
        group_by_category: false
        members: