::: py_ballisticcalc.munition.Ammo
    options:
        group_by_category: false
        members:
