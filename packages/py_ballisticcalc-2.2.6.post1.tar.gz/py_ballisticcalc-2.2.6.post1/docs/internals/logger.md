::: py_ballisticcalc.logger
    options:
        members: true
