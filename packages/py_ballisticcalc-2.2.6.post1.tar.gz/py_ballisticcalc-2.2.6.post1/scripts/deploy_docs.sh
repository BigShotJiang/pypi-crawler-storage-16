# https://github.com/mkdocs-material/example-versioning
mike deploy --push --update-aliases 0.1 latest
mike set-default --push latest