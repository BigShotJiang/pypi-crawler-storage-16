::: py_ballisticcalc.engines.base_engine.BaseIntegrationEngine
    options:
        group_by_category: false
        members:

::: py_ballisticcalc.engines.base_engine.BaseEngineConfigDict

::: py_ballisticcalc.engines.RK4IntegrationEngine
    options:
        group_by_category: false
        members:

::: py_ballisticcalc.engines.EulerIntegrationEngine
    options:
        group_by_category: false
        members:

::: py_ballisticcalc.engines.VelocityVerletIntegrationEngine
    options:
        group_by_category: false
        members:

::: py_ballisticcalc.engines.SciPyIntegrationEngine
    options:
        group_by_category: false
        members:

::: py_ballisticcalc.engines.scipy_engine.SciPyEngineConfigDict

::: py_ballisticcalc_exts.CythonizedBaseIntegrationEngine
    options:
        group_by_category: false
        members:

::: py_ballisticcalc_exts.CythonizedRK4IntegrationEngine
    options:
        group_by_category: false
        members:

::: py_ballisticcalc_exts.CythonizedEulerIntegrationEngine
    options:
        group_by_category: false
        members: