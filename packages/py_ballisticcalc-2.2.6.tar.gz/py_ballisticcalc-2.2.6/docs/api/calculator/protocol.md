::: py_ballisticcalc.generics.engine.EngineProtocol
    options:
        group_by_category: false
        members:

::: py_ballisticcalc.generics.engine.EngineFactoryProtocol
    options:
        group_by_category: false
        members: true
