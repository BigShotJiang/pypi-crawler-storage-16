::: py_ballisticcalc.shot.Shot
    options:
        group_by_category: false
        members:

::: py_ballisticcalc.conditions.Coriolis
    options:
        group_by_category: false
        members:
