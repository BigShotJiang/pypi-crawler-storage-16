::: py_ballisticcalc.shot.ShotProps
    options:
      show_root_heading: true
      show_source: true
      separate_signature: true
      members_order: source
