::: py_ballisticcalc.drag_tables
    options:
        show_root_toc_entry: false
        show_source: false

::: py_ballisticcalc.drag_tables.DragTablePointDictType

---- 

::: py_ballisticcalc.drag_tables.TableG1
    options:
        show_attribute_values: false

::: py_ballisticcalc.drag_tables.TableG2
    options:
        show_attribute_values: false

::: py_ballisticcalc.drag_tables.TableG5
    options:
        show_attribute_values: false

::: py_ballisticcalc.drag_tables.TableG6
    options:
        show_attribute_values: false

::: py_ballisticcalc.drag_tables.TableG7
    options:
        show_attribute_values: false

::: py_ballisticcalc.drag_tables.TableG8
    options:
        show_attribute_values: false

::: py_ballisticcalc.drag_tables.TableGI
    options:
        show_attribute_values: false

::: py_ballisticcalc.drag_tables.TableGS
    options:
        show_attribute_values: false

::: py_ballisticcalc.drag_tables.TableRA4
    options:
        show_attribute_values: false
