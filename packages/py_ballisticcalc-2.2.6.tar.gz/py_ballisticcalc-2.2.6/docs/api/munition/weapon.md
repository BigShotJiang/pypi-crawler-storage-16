::: py_ballisticcalc.munition.Weapon
    options:
      group_by_category: false
      members:
        - sight_height
        - twist
        - zero_elevation
        - sight
