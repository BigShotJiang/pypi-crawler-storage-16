::: py_ballisticcalc.vector.Vector
