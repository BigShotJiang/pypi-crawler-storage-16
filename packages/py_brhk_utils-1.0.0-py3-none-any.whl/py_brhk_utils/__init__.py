#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
=================================================
作者：[郭磊]
手机：[15210720528]
Email：[174000902@qq.com]
Gitee：https://gitee.com/guolei19850528/py_brhk_utils.git
=================================================
"""
from typing import Union

import httpx
import requests
from jsonschema.validators import Draft202012Validator


class Speaker(object):
    def __init__(
            self,
            token: str = "",
            id: str = "",
            version: Union[int, str] = "1"
    ):
        self.token = token
        self.id = id
        self.version = version
        self.notify_url_formatter = "https://speaker.17laimai.cn/notify.php"
        self.notify_validate_json_schema = {
            "type": "object",
            "properties": {
                "errcode": {
                    "oneOf": [
                        {"type": "integer", "const": 0},
                        {"type": "string", "const": "0"},
                    ]
                }
            },
            "required": ["errcode"]
        }

    def notify(
            self,
            message: str = None,
            **kwargs
    ):
        """
        notify

        @see https://www.yuque.com/lingdutuandui/ugcpag/umbzsd#teXR7
        :param message:
        :param kwargs: py3_requests.request kwargs
        :return:
        """
        kwargs = kwargs if isinstance(kwargs, dict) else kwargs
        kwargs.setdefault("method", "POST")
        kwargs.setdefault("url", self.notify_url_formatter)
        kwargs.setdefault("data", dict())
        data = kwargs.get("data", dict())
        data.setdefault("token", self.token)
        data.setdefault("id", self.id)
        data.setdefault("version", self.version)
        data.setdefault("message", message)
        response = httpx.request(**kwargs)
        response_json = response.json() if response.is_success else dict()
        if Draft202012Validator(self.notify_validate_json_schema).is_valid(response_json):
            return True, response_json, response
        return None, response_json, response
