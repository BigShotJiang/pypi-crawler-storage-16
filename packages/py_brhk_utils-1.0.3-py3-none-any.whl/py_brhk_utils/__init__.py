#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
=================================================
作者：[郭磊]
手机：[15210720528]
Email：[174000902@qq.com]
Gitee：https://gitee.com/guolei19850528/py_brhk_utils.git
=================================================
"""
from typing import Union

import httpx
import requests
from jsonschema.validators import Draft202012Validator


class Speaker(object):
    def __init__(
            self,
            token: str = "",
            id: str = "",
            version: Union[int, str] = "1"
    ):
        """
        云音箱类

        @see https://www.yuque.com/lingdutuandui/ugcpag/umbzsd
        :param token: TOKEN (接口凭证)： 必须(申请TOKEN请加微信：359409698 备注申请TOKEN)
        :param id: 云音箱 ID (SPEAKERID、sn)： 喇叭标签上的SN码
        :param version: version（接口版本）：(非常重要)
        """
        self.token = token
        self.id = id
        self.version = version
        self.notify_url_formatter = "https://speaker.17laimai.cn/notify.php"
        self.notify_validate_json_schema = {
            "type": "object",
            "properties": {
                "errcode": {
                    "oneOf": [
                        {"type": "integer", "const": 0},
                        {"type": "string", "const": "0"},
                    ]
                }
            },
            "required": ["errcode"]
        }

    def notify(
            self,
            message: str = None,
            **kwargs
    ):
        """
        通知语音播报

        @see https://www.yuque.com/lingdutuandui/ugcpag/umbzsd#teXR7
        :param message: 通知消息内容， 可推送任意中文（多音字可能有误差）、阿拉伯数字、英文字母，限制64个字符以内
        :param kwargs: httpx.request(**kwargs)
        :return: state,response.json(),response
        """
        kwargs = kwargs if isinstance(kwargs, dict) else kwargs
        kwargs.setdefault("method", "POST")
        kwargs.setdefault("url", self.notify_url_formatter)
        data = kwargs.get("data", dict())
        data.setdefault("token", self.token)
        data.setdefault("id", self.id)
        data.setdefault("version", self.version)
        data.setdefault("message", message)
        kwargs["data"] = data
        response = httpx.request(**kwargs)
        response_json = response.json() if response.is_success else dict()
        if Draft202012Validator(self.notify_validate_json_schema).is_valid(response_json):
            return True, response_json, response
        return None, response_json, response
