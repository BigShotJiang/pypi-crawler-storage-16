from typing import Literal


OperationPostfix = Literal['once', 'cached', 'lock']
