class CachifyInitError(Exception):
    pass


class CachifyLockError(Exception):
    pass
