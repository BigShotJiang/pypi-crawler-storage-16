#!/usr/bin/env python3
"""
ConCon (cnc) - Advanced Netcat Implementation
A comprehensive networking utility for TCP/UDP communication with TLS, 
file transfer, and multiple client support.
"""

import sys
import os
import socket
import ssl
import argparse
import threading
import selectors
import time
import hashlib
import logging
import json
import ipaddress
import subprocess
import shlex
import random
import string
import base64
import gzip
import io
from datetime import datetime
from typing import Optional, Tuple, List, Dict, Any, BinaryIO, Union, Callable
from dataclasses import dataclass
from enum import Enum, auto
from collections import defaultdict, deque
import queue
import signal
import struct
import hashlib
import hmac
import secrets
import tempfile

__version__ = "2.0.0"

# ============================================================================
# Constants and Configuration
# ============================================================================

BUFFER_SIZE = 65536
DEFAULT_TIMEOUT = 30
MAX_CONNECTIONS = 100
RATE_LIMIT_WINDOW = 60  # seconds
MAX_REQUESTS_PER_WINDOW = 1000
DEFAULT_PORT = 9999
MAX_COMMAND_HISTORY = 100
SESSION_TIMEOUT = 3600  # 1 hour
HEARTBEAT_INTERVAL = 30  # seconds

# ============================================================================
# Data Structures
# ============================================================================

class Protocol(Enum):
    TCP = "tcp"
    UDP = "udp"

class OperationMode(Enum):
    LISTEN = auto()
    CONNECT = auto()
    RELAY = auto()
    PROXY = auto()
    TUNNEL = auto()

class CommandType(Enum):
    EXECUTE = "execute"
    SHELL = "shell"
    FILE_TRANSFER = "file_transfer"
    INFO = "info"
    CONTROL = "control"
    CUSTOM = "custom"

@dataclass
class ConnectionStats:
    """Statistics for a single connection"""
    start_time: float
    bytes_sent: int = 0
    bytes_received: int = 0
    packets_sent: int = 0
    packets_received: int = 0
    errors: int = 0
    commands_executed: int = 0
    files_transferred: int = 0

@dataclass
class FileTransfer:
    """File transfer information"""
    filename: str
    size: int
    checksum: str
    start_time: float
    progress: int = 0
    terminate_after: bool = False

@dataclass 
class Command:
    """Command execution information"""
    command_id: str
    command: str
    type: CommandType
    start_time: float
    timeout: int = 30
    terminate_after: bool = False
    require_ack: bool = True

# ============================================================================
# Security & Authentication
# ============================================================================

class AuthenticationManager:
    """Handles authentication and authorization"""
    
    def __init__(self):
        self.users = {}
        self.sessions = {}
        self.api_keys = {}
        
    def add_user(self, username: str, password: str, permissions: List[str] = None):
        """Add a user with password"""
        salt = secrets.token_bytes(16)
        hashed = self._hash_password(password, salt)
        self.users[username] = {
            'hash': hashed,
            'salt': salt,
            'permissions': permissions or ['connect', 'execute']
        }
    
    def add_api_key(self, key: str, permissions: List[str] = None):
        """Add API key authentication"""
        self.api_keys[key] = {
            'permissions': permissions or ['connect', 'execute'],
            'created': time.time()
        }
    
    def authenticate(self, username: str, password: str) -> bool:
        """Authenticate username/password"""
        if username not in self.users:
            return False
        stored = self.users[username]
        hashed = self._hash_password(password, stored['salt'])
        return hmac.compare_digest(hashed, stored['hash'])
    
    def authenticate_api_key(self, key: str) -> Optional[Dict]:
        """Authenticate API key"""
        return self.api_keys.get(key)
    
    def create_session(self, username: str, client_ip: str) -> str:
        """Create a new session"""
        session_id = secrets.token_urlsafe(32)
        self.sessions[session_id] = {
            'username': username,
            'client_ip': client_ip,
            'created': time.time(),
            'last_active': time.time(),
            'permissions': self.users[username]['permissions']
        }
        return session_id
    
    def validate_session(self, session_id: str, client_ip: str) -> Optional[Dict]:
        """Validate session"""
        if session_id not in self.sessions:
            return None
        
        session = self.sessions[session_id]
        
        # Check IP
        if session['client_ip'] != client_ip:
            return None
        
        # Check timeout
        if time.time() - session['last_active'] > SESSION_TIMEOUT:
            del self.sessions[session_id]
            return None
        
        session['last_active'] = time.time()
        return session
    
    def _hash_password(self, password: str, salt: bytes) -> bytes:
        """Hash password with salt"""
        return hashlib.pbkdf2_hmac(
            'sha256',
            password.encode(),
            salt,
            100000
        )

class EncryptionManager:
    """Handles encryption and decryption"""
    
    def __init__(self, key: Optional[bytes] = None):
        self.key = key or secrets.token_bytes(32)
    
    def encrypt(self, data: bytes) -> bytes:
        """Encrypt data"""
        if not self.key:
            return data
        
        # Simple XOR encryption for demonstration
        # In production, use proper encryption like AES-GCM
        encrypted = bytearray(data)
        key_length = len(self.key)
        for i in range(len(encrypted)):
            encrypted[i] ^= self.key[i % key_length]
        return bytes(encrypted)
    
    def decrypt(self, data: bytes) -> bytes:
        """Decrypt data"""
        if not self.key:
            return data
        
        # XOR decryption (same as encryption)
        return self.encrypt(data)

# ============================================================================
# Rate Limiter
# ============================================================================

class RateLimiter:
    """Advanced DoS protection with rate limiting"""
    
    def __init__(self, window: int = RATE_LIMIT_WINDOW, 
                 max_requests: int = MAX_REQUESTS_PER_WINDOW,
                 max_connections: int = MAX_CONNECTIONS):
        self.window = window
        self.max_requests = max_requests
        self.max_connections = max_connections
        self.requests = defaultdict(list)
        self.connections = defaultdict(int)
        self.blacklist = {}
        self.lock = threading.RLock()
        
    def is_allowed(self, client_ip: str, connection: bool = False) -> bool:
        """Check if client is allowed based on rate limits"""
        with self.lock:
            now = time.time()
            
            # Check blacklist
            if client_ip in self.blacklist:
                if now < self.blacklist[client_ip]:
                    return False
                else:
                    del self.blacklist[client_ip]
            
            # Check connection limit
            if connection:
                if self.connections[client_ip] >= self.max_connections:
                    logger.warning(f"Connection limit exceeded for {client_ip}")
                    self.blacklist[client_ip] = now + 300  # 5 minute blacklist
                    return False
                self.connections[client_ip] += 1
            
            # Check request rate
            client_requests = self.requests[client_ip]
            
            # Remove old requests
            client_requests = [req_time for req_time in client_requests 
                              if now - req_time < self.window]
            self.requests[client_ip] = client_requests
            
            if len(client_requests) >= self.max_requests:
                logger.warning(f"Rate limit exceeded for {client_ip}")
                self.blacklist[client_ip] = now + 300  # 5 minute blacklist
                return False
                
            client_requests.append(now)
            return True
    
    def connection_closed(self, client_ip: str):
        """Notify that a connection has closed"""
        with self.lock:
            if client_ip in self.connections:
                self.connections[client_ip] = max(0, self.connections[client_ip] - 1)
    
    def cleanup(self):
        """Clean up old entries"""
        now = time.time()
        with self.lock:
            # Clean up requests
            for ip in list(self.requests.keys()):
                self.requests[ip] = [t for t in self.requests[ip] 
                                    if now - t < self.window * 2]
                if not self.requests[ip]:
                    del self.requests[ip]
            
            # Clean up blacklist
            for ip in list(self.blacklist.keys()):
                if now >= self.blacklist[ip]:
                    del self.blacklist[ip]

# ============================================================================
# Logger Configuration
# ============================================================================

class ColoredFormatter(logging.Formatter):
    """Custom formatter with colors"""
    
    COLORS = {
        'DEBUG': '\033[36m',      # Cyan
        'INFO': '\033[32m',       # Green
        'WARNING': '\033[33m',    # Yellow
        'ERROR': '\033[31m',      # Red
        'CRITICAL': '\033[41m',   # Red background
        'RESET': '\033[0m'
    }
    
    def format(self, record):
        log_color = self.COLORS.get(record.levelname, self.COLORS['RESET'])
        message = super().format(record)
        return f"{log_color}{message}{self.COLORS['RESET']}"

def setup_logging(verbose: bool = False, log_file: Optional[str] = None,
                 log_format: str = 'text'):
    """Configure logging system"""
    level = logging.DEBUG if verbose else logging.INFO
    
    # Create logger
    logger = logging.getLogger('concon')
    logger.setLevel(level)
    logger.handlers.clear()
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(level)
    
    if log_format == 'json':
        console_formatter = logging.Formatter(
            json.dumps({
                'timestamp': '%(asctime)s',
                'level': '%(levelname)s',
                'message': '%(message)s',
                'module': '%(name)s'
            })
        )
    else:
        console_formatter = ColoredFormatter(
            '%(asctime)s - %(levelname)8s - %(message)s',
            datefmt='%H:%M:%S'
        )
    
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)
    
    # File handler (if specified)
    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.DEBUG)
        file_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        file_handler.setFormatter(file_formatter)
        logger.addHandler(file_handler)
    
    return logger

logger = setup_logging()

# ============================================================================
# Network Utilities
# ============================================================================

def get_address_family(host: str) -> int:
    """Determine address family from host string"""
    try:
        ip = ipaddress.ip_address(host)
        return socket.AF_INET6 if ip.version == 6 else socket.AF_INET
    except ValueError:
        # Hostname, try both
        return socket.AF_UNSPEC

def create_socket(protocol: Protocol, family: int = socket.AF_INET, 
                 options: Dict[str, Any] = None) -> socket.socket:
    """Create appropriate socket for protocol"""
    if protocol == Protocol.TCP:
        sock = socket.socket(family, socket.SOCK_STREAM)
    else:  # UDP
        sock = socket.socket(family, socket.SOCK_DGRAM)
    
    # Apply socket options
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    
    if family == socket.AF_INET6:
        sock.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
    
    # Custom options
    if options:
        if options.get('keepalive'):
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
            if hasattr(socket, 'TCP_KEEPIDLE'):
                sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPIDLE, 30)
                sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPINTVL, 5)
                sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPCNT, 3)
        
        if options.get('nodelay'):
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    
    return sock

def wrap_tls_socket(sock: socket.socket, certfile: Optional[str] = None,
                   keyfile: Optional[str] = None, server_side: bool = False,
                   ca_cert: Optional[str] = None) -> ssl.SSLSocket:
    """Wrap socket with TLS"""
    if server_side:
        context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
        if certfile and keyfile:
            context.load_cert_chain(certfile=certfile, keyfile=keyfile)
        if ca_cert:
            context.load_verify_locations(ca_cert)
            context.verify_mode = ssl.CERT_REQUIRED
        else:
            context.verify_mode = ssl.CERT_NONE
    else:
        context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
        if ca_cert:
            context.load_verify_locations(ca_cert)
            context.verify_mode = ssl.CERT_REQUIRED
        else:
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
    
    return context.wrap_socket(sock, server_side=server_side)

def calculate_checksum(data: bytes, algorithm: str = 'sha256') -> str:
    """Calculate checksum of data"""
    if algorithm == 'md5':
        return hashlib.md5(data).hexdigest()
    elif algorithm == 'sha1':
        return hashlib.sha1(data).hexdigest()
    elif algorithm == 'sha256':
        return hashlib.sha256(data).hexdigest()
    else:
        raise ValueError(f"Unsupported algorithm: {algorithm}")

def hex_dump(data: bytes, offset: int = 0, width: int = 16) -> str:
    """Create hex dump of data"""
    result = []
    for i in range(0, len(data), width):
        chunk = data[i:i + width]
        hex_str = ' '.join(f'{b:02x}' for b in chunk)
        ascii_str = ''.join(chr(b) if 32 <= b < 127 else '.' for b in chunk)
        result.append(f'{offset + i:08x}  {hex_str:<{width*3}}  {ascii_str}')
    return '\n'.join(result)

# ============================================================================
# Compression
# ============================================================================

class CompressionHandler:
    """Handle data compression"""
    
    @staticmethod
    def compress(data: bytes, level: int = 6) -> bytes:
        """Compress data using gzip"""
        if len(data) < 1024:  # Don't compress small data
            return data
        return gzip.compress(data, compresslevel=level)
    
    @staticmethod
    def decompress(data: bytes) -> bytes:
        """Decompress gzip data"""
        try:
            return gzip.decompress(data)
        except:
            return data  # Not compressed

# ============================================================================
# Command History Manager
# ============================================================================

class CommandHistory:
    """Manage command history"""
    
    def __init__(self, max_size: int = MAX_COMMAND_HISTORY):
        self.history = deque(maxlen=max_size)
        self.lock = threading.RLock()
    
    def add(self, command: str, client_ip: str, success: bool = True):
        """Add command to history"""
        with self.lock:
            self.history.append({
                'timestamp': time.time(),
                'command': command,
                'client_ip': client_ip,
                'success': success
            })
    
    def get_recent(self, limit: int = 10) -> List[Dict]:
        """Get recent commands"""
        with self.lock:
            return list(self.history)[-limit:]
    
    def search(self, keyword: str) -> List[Dict]:
        """Search commands by keyword"""
        with self.lock:
            return [cmd for cmd in self.history if keyword in cmd['command']]

# ============================================================================
# Connection Handler Base Classes
# ============================================================================

class BaseConnection:
    """Base class for connection handlers"""
    
    def __init__(self, sock: socket.socket, addr: Tuple, protocol: Protocol,
                 options: Dict[str, Any] = None):
        self.sock = sock
        self.addr = addr
        self.protocol = protocol
        self.options = options or {}
        self.running = True
        self.stats = ConnectionStats(start_time=time.time())
        self.file_transfer: Optional[FileTransfer] = None
        self.current_command: Optional[Command] = None
        self.encryption = EncryptionManager(
            self.options.get('encryption_key')
        ) if 'encryption_key' in self.options else None
        self.compression = self.options.get('compression', False)
        self.hex_dump = self.options.get('hex_dump', False)
        self.heartbeat_thread = None
        self.last_heartbeat = time.time()
        
        # Set socket timeout
        if 'timeout' in self.options:
            self.sock.settimeout(self.options['timeout'])
    
    def send(self, data: bytes, encrypt: bool = True) -> bool:
        """Send data through connection"""
        try:
            # Apply compression
            if self.compression:
                data = CompressionHandler.compress(data)
            
            # Apply encryption
            if encrypt and self.encryption:
                data = self.encryption.encrypt(data)
            
            # Hex dump if enabled
            if self.hex_dump and self.options.get('verbose', False):
                logger.debug(f"Sent data:\n{hex_dump(data)}")
            
            if self.protocol == Protocol.TCP:
                sent = self.sock.send(data)
            else:
                sent = self.sock.sendto(data, self.addr)
            
            self.stats.bytes_sent += sent
            self.stats.packets_sent += 1
            return sent == len(data)
        except (socket.error, OSError) as e:
            logger.error(f"Send error: {e}")
            self.stats.errors += 1
            return False
    
    def receive(self, size: int = BUFFER_SIZE, decrypt: bool = True) -> Optional[bytes]:
        """Receive data from connection"""
        try:
            if self.protocol == Protocol.TCP:
                data = self.sock.recv(size)
            else:
                data, self.addr = self.sock.recvfrom(size)
            
            if data:
                # Hex dump if enabled
                if self.hex_dump and self.options.get('verbose', False):
                    logger.debug(f"Received data:\n{hex_dump(data)}")
                
                # Apply decryption
                if decrypt and self.encryption:
                    data = self.encryption.decrypt(data)
                
                # Apply decompression
                if self.compression:
                    data = CompressionHandler.decompress(data)
                
                self.stats.bytes_received += len(data)
                self.stats.packets_received += 1
                self.last_heartbeat = time.time()
            return data
        except socket.timeout:
            return None
        except (socket.error, OSError) as e:
            logger.error(f"Receive error: {e}")
            self.stats.errors += 1
            return None
    
    def start_heartbeat(self):
        """Start heartbeat thread"""
        def heartbeat():
            while self.running:
                try:
                    if time.time() - self.last_heartbeat > HEARTBEAT_INTERVAL * 3:
                        logger.warning(f"Heartbeat timeout for {self.addr}")
                        self.close()
                        break
                    
                    if time.time() - self.last_heartbeat > HEARTBEAT_INTERVAL:
                        self.send(b'HEARTBEAT_PING', encrypt=False)
                    
                    time.sleep(HEARTBEAT_INTERVAL)
                except:
                    break
        
        self.heartbeat_thread = threading.Thread(target=heartbeat, daemon=True)
        self.heartbeat_thread.start()
    
    def execute_command(self, command: str, timeout: int = 30) -> Tuple[bool, str]:
        """Execute a shell command"""
        self.current_command = Command(
            command_id=secrets.token_urlsafe(8),
            command=command,
            type=CommandType.EXECUTE,
            start_time=time.time(),
            timeout=timeout
        )
        
        try:
            # Execute command
            if self.options.get('shell', False):
                # Interactive shell
                process = subprocess.Popen(
                    command,
                    shell=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    stdin=subprocess.PIPE,
                    text=True
                )
                
                try:
                    stdout, stderr = process.communicate(timeout=timeout)
                    returncode = process.returncode
                except subprocess.TimeoutExpired:
                    process.kill()
                    stdout, stderr = process.communicate()
                    returncode = -1
                
                output = stdout + stderr
                success = returncode == 0
            else:
                # Simple command execution
                result = subprocess.run(
                    command,
                    shell=True,
                    capture_output=True,
                    text=True,
                    timeout=timeout
                )
                output = result.stdout + result.stderr
                success = result.returncode == 0
            
            self.stats.commands_executed += 1
            return success, output
        except Exception as e:
            return False, str(e)
    
    def close(self):
        """Close connection"""
        self.running = False
        if self.sock:
            try:
                self.sock.close()
            except:
                pass
        
        if self.heartbeat_thread:
            self.heartbeat_thread.join(timeout=1)
        
        logger.info(f"Connection closed: {self.addr[0]}:{self.addr[1]}")
        logger.info(f"Session stats: {self.stats}")
        
    def get_metadata(self) -> Dict[str, Any]:
        """Get connection metadata"""
        duration = time.time() - self.stats.start_time
        return {
            "remote_address": self.addr[0],
            "remote_port": self.addr[1],
            "protocol": self.protocol.value,
            "duration_seconds": round(duration, 2),
            "bytes_sent": self.stats.bytes_sent,
            "bytes_received": self.stats.bytes_received,
            "packets_sent": self.stats.packets_sent,
            "packets_received": self.stats.packets_received,
            "errors": self.stats.errors,
            "commands_executed": self.stats.commands_executed,
            "files_transferred": self.stats.files_transferred,
            "throughput_sent": round(self.stats.bytes_sent / max(duration, 0.001), 2),
            "throughput_received": round(self.stats.bytes_received / max(duration, 0.001), 2)
        }

class InteractiveConnection(BaseConnection):
    """Handles interactive bidirectional communication"""
    
    def __init__(self, sock: socket.socket, addr: Tuple, protocol: Protocol,
                 options: Dict[str, Any] = None):
        super().__init__(sock, addr, protocol, options)
        self.sel = selectors.DefaultSelector()
        self.input_queue = queue.Queue()
        self.command_history = CommandHistory()
        self.terminate_after = options.get('terminate_after', False)
        self.shell_mode = options.get('shell', False)
        
        # Start heartbeat
        if options.get('keepalive', False):
            self.start_heartbeat()
    
    def run_interactive(self):
        """Run interactive mode with bidirectional I/O"""
        # Register socket for reading
        self.sel.register(self.sock, selectors.EVENT_READ)
        if not self.options.get('no_stdin', False):
            self.sel.register(sys.stdin, selectors.EVENT_READ)
        
        logger.info(f"Interactive session started with {self.addr}")
        logger.info("Commands: !meta, !exit, !send <file>, !exec <command>, !shell, !help")
        
        try:
            while self.running:
                events = self.sel.select(timeout=1)
                
                for key, mask in events:
                    if key.fileobj == self.sock:
                        # Data from network
                        data = self.receive()
                        if data:
                            # Check for special commands from remote
                            if data.startswith(b'!') and data[1:2].isalpha():
                                self.handle_remote_command(data.decode().strip())
                            else:
                                sys.stdout.buffer.write(data)
                                sys.stdout.buffer.flush()
                        else:
                            logger.info("Connection closed by remote")
                            self.running = False
                            
                    elif key.fileobj == sys.stdin:
                        # Data from stdin
                        line = sys.stdin.readline()
                        if not line:
                            continue
                            
                        line = line.rstrip('\n')
                        self.command_history.add(line, self.addr[0])
                        
                        # Handle local commands
                        if line.startswith('!'):
                            self.handle_local_command(line)
                            if self.terminate_after and line != '!exit':
                                self.running = False
                                break
                        else:
                            # Send text to remote
                            if self.shell_mode:
                                # In shell mode, send raw input
                                self.send(line.encode())
                            else:
                                # In chat mode, add newline
                                self.send(line.encode() + b'\n')
                        
        except KeyboardInterrupt:
            logger.info("Interrupted by user")
        except Exception as e:
            logger.error(f"Interactive error: {e}")
        finally:
            try:
                self.sel.unregister(self.sock)
            except:
                pass
            try:
                self.sel.unregister(sys.stdin)
            except:
                pass
            self.close()
    
    def handle_local_command(self, command: str):
        """Handle local commands"""
        parts = command.split()
        cmd = parts[0]
        
        if cmd == '!exit':
            logger.info("Exiting interactive mode")
            self.running = False
        elif cmd == '!meta':
            self.display_metadata()
        elif cmd == '!help':
            self.display_help()
        elif cmd == '!send' and len(parts) > 1:
            filename = parts[1]
            terminate = '--terminate' in parts
            self.send_file(filename, terminate_after=terminate)
        elif cmd == '!exec' and len(parts) > 1:
            cmd_to_exec = ' '.join(parts[1:])
            terminate = '--terminate' in parts
            success, output = self.execute_command(cmd_to_exec)
            logger.info(f"Command {'succeeded' if success else 'failed'}: {output}")
            if terminate:
                self.running = False
        elif cmd == '!shell':
            self.shell_mode = not self.shell_mode
            logger.info(f"Shell mode {'enabled' if self.shell_mode else 'disabled'}")
        elif cmd == '!history':
            recent = self.command_history.get_recent(10)
            for i, cmd_data in enumerate(recent, 1):
                logger.info(f"{i}. {cmd_data['command']}")
        elif cmd == '!clear':
            os.system('clear' if os.name == 'posix' else 'cls')
        elif cmd == '!ping':
            start = time.time()
            self.send(b'PING', encrypt=False)
            response = self.receive()
            if response == b'PONG':
                elapsed = (time.time() - start) * 1000
                logger.info(f"Ping: {elapsed:.2f}ms")
            else:
                logger.info("No response")
        else:
            logger.info(f"Unknown command: {cmd}")
    
    def handle_remote_command(self, command: str):
        """Handle commands from remote"""
        parts = command.split()
        cmd = parts[0]
        
        if cmd == '!exec' and len(parts) > 1:
            # Execute command remotely
            cmd_to_exec = ' '.join(parts[1:])
            terminate = '--terminate' in parts
            
            success, output = self.execute_command(cmd_to_exec)
            response = json.dumps({
                'command': cmd_to_exec,
                'success': success,
                'output': output
            })
            self.send(response.encode())
            
            if terminate:
                self.send(b'TERMINATING')
                self.running = False
        elif cmd == '!info':
            # Send connection info
            info = self.get_metadata()
            self.send(json.dumps(info).encode())
        elif cmd == '!ping':
            # Respond to ping
            self.send(b'PONG', encrypt=False)
        elif cmd == '!heartbeat':
            # Heartbeat response
            self.last_heartbeat = time.time()
            self.send(b'HEARTBEAT_PONG', encrypt=False)
        elif cmd == '!terminate':
            # Terminate connection
            self.send(b'TERMINATING')
            self.running = False
    
    def display_metadata(self):
        """Display connection metadata"""
        meta = self.get_metadata()
        logger.info("=== Connection Metadata ===")
        for key, value in meta.items():
            logger.info(f"{key.replace('_', ' ').title()}: {value}")
        logger.info("===========================")
    
    def display_help(self):
        """Display help information"""
        help_text = """
Available Commands:
  !help                 - Show this help
  !meta                 - Show connection metadata
  !exit                 - Exit interactive mode
  !send <file> [--terminate] - Send file (terminate after if --terminate)
  !exec <command> [--terminate] - Execute command (terminate after if --terminate)
  !shell                - Toggle shell mode
  !history              - Show command history
  !clear                - Clear screen
  !ping                 - Test connection latency
  
Remote Commands:
  !exec <command>       - Execute command on remote
  !info                 - Get remote connection info
  !terminate            - Request remote termination
        """
        logger.info(help_text)
    
    def send_file(self, filename: str, terminate_after: bool = False):
        """Send file to remote"""
        try:
            if not os.path.exists(filename):
                logger.error(f"File not found: {filename}")
                return
                
            with open(filename, 'rb') as f:
                file_data = f.read()
                
            checksum = calculate_checksum(file_data)
            header = json.dumps({
                'action': 'file_transfer',
                'filename': os.path.basename(filename),
                'size': len(file_data),
                'checksum': checksum,
                'algorithm': 'sha256',
                'terminate_after': terminate_after
            }).encode() + b'\n\n'
            
            # Send header
            if not self.send(header):
                logger.error("Failed to send file header")
                return
                
            # Wait for acknowledgment
            if self.protocol == Protocol.TCP:
                ack = self.receive(1024)
                if not ack or ack.decode().strip() != 'READY':
                    logger.error("Remote not ready for file transfer")
                    return
            
            # Send file data in chunks
            total_sent = 0
            chunk_size = 65536
            
            logger.info(f"Sending file: {filename} ({len(file_data)} bytes)")
            
            while total_sent < len(file_data):
                chunk = file_data[total_sent:total_sent + chunk_size]
                if not self.send(chunk):
                    logger.error("File transfer interrupted")
                    return
                total_sent += len(chunk)
                
                # Progress update
                progress = (total_sent * 100) // len(file_data)
                if progress % 25 == 0 or total_sent == len(file_data):
                    logger.info(f"Progress: {progress}% ({total_sent}/{len(file_data)} bytes)")
            
            logger.info(f"File sent successfully. Checksum: {checksum[:16]}...")
            self.stats.files_transferred += 1
            
            if terminate_after:
                logger.info("Terminating connection as requested")
                self.running = False
            
        except Exception as e:
            logger.error(f"File send error: {e}")

# ============================================================================
# Server Classes
# ============================================================================

class Server:
    """Advanced server class with multiple features"""
    
    def __init__(self, host: str, port: int, protocol: Protocol,
                 tls: bool = False, certfile: Optional[str] = None,
                 keyfile: Optional[str] = None, max_clients: int = MAX_CONNECTIONS,
                 options: Dict[str, Any] = None):
        self.host = host
        self.port = port
        self.protocol = protocol
        self.tls = tls
        self.certfile = certfile
        self.keyfile = keyfile
        self.max_clients = max_clients
        self.options = options or {}
        self.running = False
        self.connections: List[threading.Thread] = []
        self.rate_limiter = RateLimiter()
        self.sock: Optional[socket.socket] = None
        self.auth_manager = AuthenticationManager()
        self.command_history = CommandHistory()
        
        # Setup authentication if enabled
        if self.options.get('auth_file'):
            self.load_auth_file(self.options['auth_file'])
    
    def load_auth_file(self, auth_file: str):
        """Load authentication from file"""
        try:
            with open(auth_file, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        if ':' in line:
                            username, password = line.split(':', 1)
                            self.auth_manager.add_user(username, password)
                        else:
                            self.auth_manager.add_api_key(line)
            logger.info(f"Loaded authentication from {auth_file}")
        except Exception as e:
            logger.error(f"Failed to load auth file: {e}")
    
    def start(self):
        """Start the server"""
        family = get_address_family(self.host)
        socket_options = {
            'keepalive': self.options.get('keepalive', False),
            'nodelay': self.options.get('nodelay', True)
        }
        self.sock = create_socket(self.protocol, family, socket_options)
        
        try:
            self.sock.bind((self.host, self.port))
            if self.protocol == Protocol.TCP:
                self.sock.listen(self.max_clients)
        except socket.error as e:
            logger.error(f"Failed to bind to {self.host}:{self.port}: {e}")
            return False
            
        self.running = True
        logger.info(f"Server listening on {self.host}:{self.port} ({self.protocol.value})")
        
        if self.tls:
            logger.info("TLS encryption enabled")
        
        # Start cleanup thread
        threading.Thread(target=self._cleanup_thread, daemon=True).start()
        
        # Start connection handler
        if self.protocol == Protocol.TCP:
            threading.Thread(target=self._accept_tcp_connections, daemon=True).start()
        else:
            threading.Thread(target=self._handle_udp_connections, daemon=True).start()
            
        return True
    
    def _cleanup_thread(self):
        """Background cleanup thread"""
        while self.running:
            time.sleep(60)
            self.rate_limiter.cleanup()
            
            # Clean up finished connections
            self.connections = [conn for conn in self.connections if conn.is_alive()]
    
    def _accept_tcp_connections(self):
        """Accept TCP connections"""
        while self.running:
            try:
                client_sock, addr = self.sock.accept()
                
                # Rate limiting
                if not self.rate_limiter.is_allowed(addr[0], connection=True):
                    logger.warning(f"Rate limit exceeded for {addr[0]}")
                    client_sock.close()
                    continue
                
                logger.info(f"New connection from {addr[0]}:{addr[1]}")
                
                # Handle TLS if enabled
                if self.tls:
                    try:
                        client_sock = wrap_tls_socket(
                            client_sock, self.certfile, self.keyfile, 
                            server_side=True,
                            ca_cert=self.options.get('ca_cert')
                        )
                    except ssl.SSLError as e:
                        logger.error(f"TLS handshake failed: {e}")
                        client_sock.close()
                        continue
                
                # Handle authentication
                if self.options.get('require_auth'):
                    if not self._authenticate_client(client_sock, addr):
                        client_sock.close()
                        continue
                
                # Set socket options
                if self.options.get('timeout'):
                    client_sock.settimeout(self.options['timeout'])
                
                # Start client handler in new thread
                client_thread = threading.Thread(
                    target=self._handle_tcp_client,
                    args=(client_sock, addr),
                    daemon=True
                )
                client_thread.start()
                self.connections.append(client_thread)
                
            except socket.error as e:
                if self.running:
                    logger.error(f"Accept error: {e}")
    
    def _authenticate_client(self, sock: socket.socket, addr: Tuple) -> bool:
        """Authenticate client"""
        try:
            # Send auth request
            sock.send(b'AUTH_REQUIRED\n')
            
            # Receive auth data
            auth_data = sock.recv(1024).decode().strip()
            
            if ':' in auth_data:
                # Username:password
                username, password = auth_data.split(':', 1)
                if self.auth_manager.authenticate(username, password):
                    sock.send(b'AUTH_SUCCESS\n')
                    return True
            else:
                # API key
                if self.auth_manager.authenticate_api_key(auth_data):
                    sock.send(b'AUTH_SUCCESS\n')
                    return True
            
            sock.send(b'AUTH_FAILED\n')
            return False
        except:
            return False
    
    def _handle_tcp_client(self, sock: socket.socket, addr: Tuple):
        """Handle individual TCP client"""
        try:
            options = {
                **self.options,
                'keepalive': self.options.get('keepalive', True),
                'hex_dump': self.options.get('hex_dump', False),
                'compression': self.options.get('compression', False),
                'shell': self.options.get('shell', False),
                'verbose': self.options.get('verbose', False)
            }
            
            conn = InteractiveConnection(sock, addr, Protocol.TCP, options)
            conn.run_interactive()
        except Exception as e:
            logger.error(f"Client handler error: {e}")
        finally:
            sock.close()
            self.rate_limiter.connection_closed(addr[0])
    
    def _handle_udp_connections(self):
        """Handle UDP connections"""
        logger.info("UDP server ready for datagrams")
        
        while self.running:
            try:
                data, addr = self.sock.recvfrom(BUFFER_SIZE)
                
                # Rate limiting
                if not self.rate_limiter.is_allowed(addr[0]):
                    continue
                
                # Log received data
                if self.options.get('verbose'):
                    logger.debug(f"UDP from {addr[0]}:{addr[1]}: {data[:100]}{'...' if len(data) > 100 else ''}")
                
                # Handle special commands
                try:
                    # Check for JSON commands
                    if data.startswith(b'{'):
                        self._handle_json_command(data, addr)
                        continue
                    
                    # Handle file transfer
                    if data.startswith(b'{"action": "file_transfer"'):
                        self._handle_udp_file_transfer(data, addr)
                        continue
                    
                    # Handle echo mode
                    if self.options.get('echo', True):
                        self.sock.sendto(b"Echo: " + data, addr)
                        
                except Exception as e:
                    logger.error(f"Command handling error: {e}")
                    self.sock.sendto(b"ERROR: " + str(e).encode(), addr)
                    
            except socket.error as e:
                if self.running:
                    logger.error(f"UDP error: {e}")
    
    def _handle_json_command(self, data: bytes, addr: Tuple):
        """Handle JSON-based commands"""
        try:
            command = json.loads(data.decode())
            cmd_type = command.get('type', 'echo')
            
            if cmd_type == 'execute':
                cmd = command.get('command', '')
                timeout = command.get('timeout', 30)
                terminate = command.get('terminate_after', False)
                
                # Execute command
                result = subprocess.run(
                    cmd,
                    shell=True,
                    capture_output=True,
                    text=True,
                    timeout=timeout
                )
                
                response = {
                    'success': result.returncode == 0,
                    'output': result.stdout + result.stderr,
                    'return_code': result.returncode,
                    'terminated': terminate
                }
                
                self.sock.sendto(json.dumps(response).encode(), addr)
                
                if terminate:
                    logger.info(f"Terminating after command execution for {addr[0]}")
            
            elif cmd_type == 'info':
                response = {
                    'server': 'ConCon Server',
                    'version': __version__,
                    'protocol': 'UDP',
                    'clients': len(self.connections)
                }
                self.sock.sendto(json.dumps(response).encode(), addr)
            
            elif cmd_type == 'file_info':
                filename = command.get('filename', '')
                if os.path.exists(filename):
                    stats = os.stat(filename)
                    response = {
                        'exists': True,
                        'size': stats.st_size,
                        'modified': stats.st_mtime,
                        'checksum': calculate_checksum(open(filename, 'rb').read())
                    }
                else:
                    response = {'exists': False}
                self.sock.sendto(json.dumps(response).encode(), addr)
            
            else:
                # Echo back
                self.sock.sendto(json.dumps({'echo': command}).encode(), addr)
                
        except Exception as e:
            error_response = {'error': str(e)}
            self.sock.sendto(json.dumps(error_response).encode(), addr)
    
    def _handle_udp_file_transfer(self, data: bytes, addr: Tuple):
        """Handle UDP file transfer"""
        try:
            # This is simplified - UDP file transfer would need proper sequencing
            header_end = data.find(b'\n\n')
            if header_end == -1:
                return
                
            header = json.loads(data[:header_end].decode())
            file_data = data[header_end + 2:]
            
            # Save file
            timestamp = int(time.time())
            safe_addr = addr[0].replace(':', '_').replace('.', '_')
            filename = f"received_{safe_addr}_{timestamp}_{header['filename']}"
            
            with open(filename, 'wb') as f:
                f.write(file_data)
                
            # Verify checksum
            checksum = calculate_checksum(file_data, header.get('algorithm', 'sha256'))
            if checksum == header['checksum']:
                logger.info(f"File received: {filename} ({len(file_data)} bytes)")
                
                response = {
                    'status': 'success',
                    'filename': filename,
                    'size': len(file_data),
                    'message': 'File received successfully'
                }
                self.sock.sendto(json.dumps(response).encode(), addr)
                
                # Execute post-transfer command if specified
                if header.get('execute_after'):
                    cmd = header['execute_after']
                    subprocess.run(cmd, shell=True)
            else:
                logger.error(f"Checksum mismatch for {filename}")
                self.sock.sendto(json.dumps({'status': 'error', 'message': 'Checksum mismatch'}).encode(), addr)
                
            # Terminate if requested
            if header.get('terminate_after'):
                logger.info(f"Terminating connection to {addr[0]} after file transfer")
                
        except Exception as e:
            logger.error(f"UDP file transfer error: {e}")
            self.sock.sendto(json.dumps({'status': 'error', 'message': str(e)}).encode(), addr)
    
    def stop(self):
        """Stop the server"""
        self.running = False
        if self.sock:
            self.sock.close()
        
        # Wait for connections
        for conn in self.connections:
            if conn.is_alive():
                conn.join(timeout=2)
        
        logger.info("Server stopped")

# ============================================================================
# Client Classes
# ============================================================================

class Client:
    """Advanced client class with multiple features"""
    
    def __init__(self, host: str, port: int, protocol: Protocol,
                 tls: bool = False, timeout: int = DEFAULT_TIMEOUT,
                 options: Dict[str, Any] = None):
        self.host = host
        self.port = port
        self.protocol = protocol
        self.tls = tls
        self.timeout = timeout
        self.options = options or {}
        self.sock: Optional[socket.socket] = None
        self.session_id = secrets.token_urlsafe(8)
        self.encryption = None
        
        # Setup encryption if key provided
        if self.options.get('encryption_key'):
            self.encryption = EncryptionManager(self.options['encryption_key'])
    
    def connect(self) -> bool:
        """Connect to server"""
        family = get_address_family(self.host)
        socket_options = {
            'keepalive': self.options.get('keepalive', False),
            'nodelay': self.options.get('nodelay', True)
        }
        
        try:
            self.sock = create_socket(self.protocol, family, socket_options)
            self.sock.settimeout(self.timeout)
            
            if self.protocol == Protocol.TCP:
                self.sock.connect((self.host, self.port))
                logger.info(f"Connected to {self.host}:{self.port}")
                
                # Authenticate if required
                if self.options.get('username') and self.options.get('password'):
                    if not self._authenticate():
                        return False
                
                # Wrap with TLS if enabled
                if self.tls:
                    self.sock = wrap_tls_socket(self.sock, server_side=False,
                                               ca_cert=self.options.get('ca_cert'))
                    logger.info("TLS handshake completed")
            else:
                # UDP doesn't actually connect, but we store the address
                logger.info(f"UDP client ready to send to {self.host}:{self.port}")
                
            return True
            
        except (socket.error, ssl.SSLError) as e:
            logger.error(f"Connection failed: {e}")
            return False
    
    def _authenticate(self) -> bool:
        """Authenticate with server"""
        try:
            # Wait for auth request
            data = self.sock.recv(1024)
            if data != b'AUTH_REQUIRED\n':
                return True  # No auth required
            
            # Send credentials
            auth_str = f"{self.options['username']}:{self.options['password']}"
            self.sock.send(auth_str.encode() + b'\n')
            
            # Check response
            response = self.sock.recv(1024)
            if response == b'AUTH_SUCCESS\n':
                logger.info("Authentication successful")
                return True
            else:
                logger.error("Authentication failed")
                return False
        except:
            return False
    
    def send_file(self, filename: str, terminate_after: bool = False, 
                 execute_after: Optional[str] = None) -> bool:
        """Send file to server"""
        try:
            if not os.path.exists(filename):
                logger.error(f"File not found: {filename}")
                return False
                
            with open(filename, 'rb') as f:
                file_data = f.read()
                
            checksum = calculate_checksum(file_data)
            
            if self.protocol == Protocol.TCP:
                # TCP file transfer
                header = json.dumps({
                    'action': 'file_transfer',
                    'filename': os.path.basename(filename),
                    'size': len(file_data),
                    'checksum': checksum,
                    'algorithm': 'sha256',
                    'terminate_after': terminate_after,
                    'execute_after': execute_after
                }).encode() + b'\n\n'
                
                # Send header
                self.sock.send(header)
                
                # Wait for READY acknowledgment
                ready = self.sock.recv(1024)
                if ready.decode().strip() != 'READY':
                    logger.error("Server not ready for file transfer")
                    return False
                
                # Send file data
                total_sent = 0
                chunk_size = 65536
                
                logger.info(f"Sending file: {filename} ({len(file_data)} bytes)")
                
                while total_sent < len(file_data):
                    chunk = file_data[total_sent:total_sent + chunk_size]
                    sent = self.sock.send(chunk)
                    if sent == 0:
                        logger.error("Connection broken during file transfer")
                        return False
                    total_sent += sent
                    
                    # Progress update
                    progress = (total_sent * 100) // len(file_data)
                    if progress % 25 == 0 or total_sent == len(file_data):
                        logger.info(f"Progress: {progress}% ({total_sent}/{len(file_data)} bytes)")
                
                logger.info(f"File sent successfully. Checksum: {checksum[:16]}...")
                
                if terminate_after:
                    logger.info("Closing connection as requested")
                    self.close()
                
                return True
            else:
                # UDP file transfer
                header = json.dumps({
                    'action': 'file_transfer',
                    'filename': os.path.basename(filename),
                    'size': len(file_data),
                    'checksum': checksum,
                    'algorithm': 'sha256',
                    'terminate_after': terminate_after,
                    'execute_after': execute_after
                }).encode() + b'\n\n' + file_data
                
                if len(header) > 65507:  # UDP practical limit
                    logger.error("File too large for UDP transfer")
                    return False
                    
                self.sock.sendto(header, (self.host, self.port))
                
                # Wait for response
                try:
                    self.sock.settimeout(10)
                    response, _ = self.sock.recvfrom(1024)
                    response_data = json.loads(response.decode())
                    
                    if response_data.get('status') == 'success':
                        logger.info(f"File sent successfully: {filename}")
                        
                        if terminate_after:
                            logger.info("Closing connection as requested")
                            self.close()
                        
                        return True
                    else:
                        logger.error(f"File transfer failed: {response_data.get('message')}")
                        return False
                except socket.timeout:
                    logger.error("No response from server")
                    return False
                    
        except Exception as e:
            logger.error(f"File send error: {e}")
            return False
    
    def execute_remote_command(self, command: str, timeout: int = 30, 
                              terminate_after: bool = False) -> bool:
        """Execute command on remote server"""
        try:
            cmd_data = {
                'type': 'execute',
                'command': command,
                'timeout': timeout,
                'terminate_after': terminate_after,
                'session_id': self.session_id
            }
            
            if self.protocol == Protocol.TCP:
                self.sock.send(json.dumps(cmd_data).encode() + b'\n')
                response = self.sock.recv(BUFFER_SIZE)
            else:
                self.sock.sendto(json.dumps(cmd_data).encode(), (self.host, self.port))
                self.sock.settimeout(timeout + 5)
                response, _ = self.sock.recvfrom(BUFFER_SIZE)
            
            result = json.loads(response.decode())
            
            if result.get('success'):
                logger.info(f"Command executed successfully:\n{result.get('output')}")
            else:
                logger.error(f"Command failed:\n{result.get('output')}")
            
            if terminate_after:
                logger.info("Closing connection as requested")
                self.close()
            
            return result.get('success', False)
            
        except Exception as e:
            logger.error(f"Command execution error: {e}")
            return False
    
    def get_server_info(self) -> Optional[Dict]:
        """Get server information"""
        try:
            cmd_data = {'type': 'info', 'session_id': self.session_id}
            
            if self.protocol == Protocol.TCP:
                self.sock.send(json.dumps(cmd_data).encode() + b'\n')
                response = self.sock.recv(BUFFER_SIZE)
            else:
                self.sock.sendto(json.dumps(cmd_data).encode(), (self.host, self.port))
                self.sock.settimeout(5)
                response, _ = self.sock.recvfrom(BUFFER_SIZE)
            
            return json.loads(response.decode())
        except:
            return None
    
    def interactive(self):
        """Start interactive mode"""
        if not self.sock:
            logger.error("Not connected")
            return
            
        if self.protocol == Protocol.UDP:
            logger.warning("Interactive mode is limited for UDP")
            logger.info("Enter text to send (Ctrl+C to exit):")
            
            try:
                while True:
                    try:
                        line = sys.stdin.readline()
                        if not line:
                            break
                        line = line.rstrip('\n')
                        
                        if line.startswith('!'):
                            if line == '!exit':
                                break
                            elif line.startswith('!send '):
                                parts = line.split()
                                if len(parts) > 1:
                                    filename = parts[1]
                                    terminate = '--terminate' in parts
                                    self.send_file(filename, terminate_after=terminate)
                                continue
                            elif line.startswith('!exec '):
                                cmd = line[6:]
                                terminate = '--terminate' in line
                                self.execute_remote_command(cmd, terminate_after=terminate)
                                continue
                            elif line == '!info':
                                info = self.get_server_info()
                                if info:
                                    logger.info(f"Server info: {info}")
                                continue
                            
                        # Send raw text
                        self.sock.sendto(line.encode(), (self.host, self.port))
                        
                        # Try to receive response
                        self.sock.settimeout(2)
                        try:
                            data, _ = self.sock.recvfrom(BUFFER_SIZE)
                            print(f"Received: {data.decode()}")
                        except socket.timeout:
                            print("No response")
                            
                    except KeyboardInterrupt:
                        break
            except Exception as e:
                logger.error(f"UDP interactive error: {e}")
        else:
            options = {
                **self.options,
                'keepalive': self.options.get('keepalive', True),
                'hex_dump': self.options.get('hex_dump', False),
                'compression': self.options.get('compression', False),
                'shell': self.options.get('shell', False),
                'verbose': self.options.get('verbose', False),
                'no_stdin': self.options.get('no_stdin', False)
            }
            
            conn = InteractiveConnection(self.sock, (self.host, self.port), 
                                        self.protocol, options)
            conn.run_interactive()
    
    def close(self):
        """Close connection"""
        if self.sock:
            self.sock.close()
            logger.info("Connection closed")

# ============================================================================
# Proxy Server (Advanced Feature)
# ============================================================================

class ProxyServer:
    """HTTP/S and SOCKS-like proxy server"""
    
    def __init__(self, listen_host: str, listen_port: int, 
                 protocol: Protocol = Protocol.TCP, 
                 options: Dict[str, Any] = None):
        self.listen_host = listen_host
        self.listen_port = listen_port
        self.protocol = protocol
        self.options = options or {}
        self.running = False
        self.sock = None
        
    def start(self):
        """Start proxy server"""
        family = get_address_family(self.listen_host)
        self.sock = create_socket(self.protocol, family)
        
        try:
            self.sock.bind((self.listen_host, self.listen_port))
            self.sock.listen(self.options.get('max_clients', MAX_CONNECTIONS))
            self.running = True
            
            logger.info(f"Proxy server listening on {self.listen_host}:{self.listen_port}")
            
            while self.running:
                client_sock, addr = self.sock.accept()
                threading.Thread(
                    target=self._handle_proxy_connection,
                    args=(client_sock, addr),
                    daemon=True
                ).start()
                
        except Exception as e:
            logger.error(f"Proxy server error: {e}")
    
    def _handle_proxy_connection(self, client_sock: socket.socket, addr: Tuple):
        """Handle proxy connection"""
        try:
            # Read client request
            data = client_sock.recv(4096)
            
            # Parse request to get destination
            dest_host, dest_port = self._parse_proxy_request(data)
            
            if not dest_host or not dest_port:
                client_sock.close()
                return
            
            # Connect to destination
            dest_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            dest_sock.connect((dest_host, dest_port))
            
            # Send success response
            client_sock.send(b'HTTP/1.1 200 Connection Established\r\n\r\n')
            
            # Start bidirectional relay
            self._start_relay(client_sock, dest_sock)
            
        except Exception as e:
            logger.error(f"Proxy handling error: {e}")
            client_sock.close()
    
    def _parse_proxy_request(self, data: bytes) -> Tuple[Optional[str], Optional[int]]:
        """Parse proxy request to extract destination"""
        try:
            # Try to parse as HTTP CONNECT
            lines = data.decode().split('\r\n')
            first_line = lines[0].split()
            
            if len(first_line) >= 3 and first_line[0] == 'CONNECT':
                # HTTP CONNECT request
                host_port = first_line[1].split(':')
                if len(host_port) == 2:
                    return host_port[0], int(host_port[1])
            
            # Try to parse as SOCKS or plain connection
            # This is a simplified parser
            return 'example.com', 80  # Default for demo
            
        except:
            return None, None
    
    def _start_relay(self, sock1: socket.socket, sock2: socket.socket):
        """Start bidirectional relay between two sockets"""
        def relay(source: socket.socket, dest: socket.socket):
            try:
                while True:
                    data = source.recv(BUFFER_SIZE)
                    if not data:
                        break
                    dest.send(data)
            except:
                pass
            finally:
                source.close()
                dest.close()
        
        # Start relays in both directions
        threading.Thread(target=relay, args=(sock1, sock2), daemon=True).start()
        threading.Thread(target=relay, args=(sock2, sock1), daemon=True).start()

# ============================================================================
# Main Application
# ============================================================================

def parse_arguments():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(
        description=f"ConCon (cnc) v{__version__} - Advanced Netcat Implementation",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Listen on TCP port 9999 with verbose logging
  %(prog)s -l -p 9999 -vv
  
  # Connect to TCP server
  %(prog)s example.com 9999
  
  # Connect with TLS
  %(prog)s example.com 443 -t
  
  # UDP server on port 9999
  %(prog)s -l -p 9999 -u
  
  # Send file and terminate
  %(prog)s server.com 9999 --send file.txt --terminate
  
  # Execute command and terminate
  %(prog)s server.com 9999 --exec "ls -la" --terminate
  
  # IPv6 server with authentication
  %(prog)s -l -p 9999 -6 --auth-file users.txt
  
  # With compression and hex dump
  %(prog)s -l -p 9999 --compress --hex-dump
  
  # Start a shell server
  %(prog)s -l -p 9999 --shell
  
  # Proxy mode
  %(prog)s --proxy 8080
  
  # Tunnel mode (relay between ports)
  %(prog)s --tunnel 9999:localhost:8080
  
Advanced Features:
  * File transfer with checksum verification
  * Remote command execution
  * Shell access
  * Authentication (username/password or API keys)
  * Encryption (TLS and custom)
  * Compression
  * Hex dump of traffic
  * Connection termination after specific operations
  * Rate limiting and DoS protection
  * Connection statistics and metadata
  * Heartbeat and keepalive
  * Proxy and tunnel modes
        """
    )
    
    # Connection mode
    mode_group = parser.add_mutually_exclusive_group()
    mode_group.add_argument("-l", "--listen", action="store_true",
                       help="Listen mode (server)")
    mode_group.add_argument("--proxy", type=int, metavar="PORT",
                       help="Start proxy server on PORT")
    mode_group.add_argument("--tunnel", type=str, metavar="LOCAL:REMOTE",
                       help="Create tunnel LOCAL_PORT:REMOTE_HOST:REMOTE_PORT")
    
    # Host and port (conditional)
    parser.add_argument("host", nargs="?", 
                       help="Target host (required for client mode)")
    parser.add_argument("port", nargs="?", type=int,
                       help=f"Port number (default: {DEFAULT_PORT})")
    
    # Protocol options
    parser.add_argument("-u", "--udp", action="store_true",
                       help="Use UDP (default: TCP)")
    parser.add_argument("-6", "--ipv6", action="store_true",
                       help="Use IPv6 (default: auto)")
    
    # TLS/SSL options
    parser.add_argument("-t", "--tls", action="store_true",
                       help="Enable TLS/SSL encryption")
    parser.add_argument("--cert", help="TLS certificate file")
    parser.add_argument("--key", help="TLS private key file")
    parser.add_argument("--ca-cert", help="CA certificate file")
    
    # Authentication
    parser.add_argument("--auth-file", help="Authentication file (username:password per line)")
    parser.add_argument("--username", help="Username for authentication")
    parser.add_argument("--password", help="Password for authentication")
    parser.add_argument("--api-key", help="API key for authentication")
    
    # File transfer
    parser.add_argument("-s", "--send", metavar="FILE",
                       help="Send file to server")
    parser.add_argument("-r", "--receive", metavar="FILE",
                       help="Receive file from server")
    parser.add_argument("--terminate", action="store_true",
                       help="Terminate connection after operation")
    parser.add_argument("--execute-after", metavar="CMD",
                       help="Execute command after file transfer")
    
    # Command execution
    parser.add_argument("--exec", metavar="COMMAND",
                       help="Execute command on remote server")
    parser.add_argument("--shell", action="store_true",
                       help="Enable shell mode (server side)")
    
    # Server options
    parser.add_argument("--max-clients", type=int, default=MAX_CONNECTIONS,
                       help=f"Maximum concurrent clients (default: {MAX_CONNECTIONS})")
    parser.add_argument("--require-auth", action="store_true",
                       help="Require authentication for connections")
    
    # Client options
    parser.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT,
                       help=f"Connection timeout in seconds (default: {DEFAULT_TIMEOUT})")
    
    # Port option (alternative to positional)
    parser.add_argument("-p", "--port-opt", type=int,
                       help=f"Port number (alternative to positional)")
    
    # Performance options
    parser.add_argument("--keepalive", action="store_true",
                       help="Enable TCP keepalive")
    parser.add_argument("--nodelay", action="store_true", default=True,
                       help="Enable TCP_NODELAY (default: True)")
    parser.add_argument("--compress", action="store_true",
                       help="Enable compression")
    parser.add_argument("--encryption-key", help="Custom encryption key (base64)")
    
    # Debugging options
    parser.add_argument("--hex-dump", action="store_true",
                       help="Enable hex dump of traffic")
    parser.add_argument("--no-stdin", action="store_true",
                       help="Disable stdin reading (for scripts)")
    
    # General options
    parser.add_argument("-v", "--verbose", action="count", default=0,
                       help="Verbose output (use -vv for debug)")
    parser.add_argument("--log", help="Log file")
    parser.add_argument("--log-format", choices=['text', 'json'], default='text',
                       help="Log format (default: text)")
    parser.add_argument("--version", action="version",
                       version=f"%(prog)s {__version__}")
    
    return parser.parse_args()

def validate_arguments(args):
    """Validate and normalize arguments"""
    # Determine port
    port = args.port_opt or args.port or DEFAULT_PORT
    
    # Validate modes
    if args.proxy:
        # Proxy mode
        return None, args.proxy, True, OperationMode.PROXY
    
    if args.tunnel:
        # Tunnel mode
        return args.tunnel, None, True, OperationMode.TUNNEL
    
    if args.listen:
        # Server mode
        host = "::" if args.ipv6 else "0.0.0.0"
        return host, port, True, OperationMode.LISTEN
    else:
        # Client mode
        if not args.host:
            logger.error("Host is required in client mode")
            return None, None, False, OperationMode.CONNECT
        host = args.host
    
    return host, port, True, OperationMode.CONNECT

def run_tunnel(tunnel_spec: str):
    """Run tunnel mode"""
    try:
        # Parse tunnel specification: LOCAL_PORT:REMOTE_HOST:REMOTE_PORT
        parts = tunnel_spec.split(':')
        if len(parts) != 3:
            logger.error("Invalid tunnel specification. Use LOCAL_PORT:REMOTE_HOST:REMOTE_PORT")
            return 1
        
        local_port = int(parts[0])
        remote_host = parts[1]
        remote_port = int(parts[2])
        
        logger.info(f"Starting tunnel: localhost:{local_port} -> {remote_host}:{remote_port}")
        
        # Create local server
        server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server_sock.bind(('0.0.0.0', local_port))
        server_sock.listen(5)
        
        while True:
            client_sock, addr = server_sock.accept()
            logger.info(f"Tunnel connection from {addr[0]}:{addr[1]}")
            
            # Connect to remote
            remote_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                remote_sock.connect((remote_host, remote_port))
                
                # Start bidirectional relay
                def relay(source: socket.socket, dest: socket.socket, direction: str):
                    try:
                        while True:
                            data = source.recv(BUFFER_SIZE)
                            if not data:
                                break
                            dest.send(data)
                    except:
                        pass
                    finally:
                        source.close()
                        dest.close()
                
                threading.Thread(target=relay, args=(client_sock, remote_sock, "->"), daemon=True).start()
                threading.Thread(target=relay, args=(remote_sock, client_sock, "<-"), daemon=True).start()
                
            except Exception as e:
                logger.error(f"Tunnel connection failed: {e}")
                client_sock.close()
                
    except KeyboardInterrupt:
        logger.info("\nTunnel stopped")
    except Exception as e:
        logger.error(f"Tunnel error: {e}")
        return 1
    
    return 0

def main():
    """Main entry point"""
    args = parse_arguments()
    
    # Setup logging
    global logger
    logger = setup_logging(args.verbose > 0, args.log, args.log_format)
    
    # Validate arguments
    host, port, valid, mode = validate_arguments(args)
    if not valid:
        return 1
    
    # Handle special modes
    if mode == OperationMode.TUNNEL:
        return run_tunnel(args.tunnel)
    
    elif mode == OperationMode.PROXY:
        proxy = ProxyServer('0.0.0.0', args.proxy, Protocol.TCP)
        try:
            proxy.start()
        except KeyboardInterrupt:
            logger.info("\nProxy stopped")
        return 0
    
    # Determine protocol
    protocol = Protocol.UDP if args.udp else Protocol.TCP
    
    # Prepare options
    options = {
        'keepalive': args.keepalive,
        'nodelay': args.nodelay,
        'compress': args.compress,
        'hex_dump': args.hex_dump,
        'shell': args.shell,
        'verbose': args.verbose > 0,
        'timeout': args.timeout,
        'no_stdin': args.no_stdin,
        'require_auth': args.require_auth,
        'auth_file': args.auth_file
    }
    
    if args.encryption_key:
        options['encryption_key'] = base64.b64decode(args.encryption_key)
    
    try:
        if mode == OperationMode.LISTEN:
            # Server mode
            server = Server(
                host=host,
                port=port,
                protocol=protocol,
                tls=args.tls,
                certfile=args.cert,
                keyfile=args.key,
                max_clients=args.max_clients,
                options=options
            )
            
            if not server.start():
                return 1
                
            try:
                # Keep server running
                while server.running:
                    time.sleep(0.1)
            except KeyboardInterrupt:
                logger.info("\nShutting down server...")
                server.stop()
                
        else:
            # Client mode
            client = Client(
                host=host,
                port=port,
                protocol=protocol,
                tls=args.tls,
                timeout=args.timeout,
                options={
                    **options,
                    'username': args.username,
                    'password': args.password,
                    'api_key': args.api_key,
                    'ca_cert': args.ca_cert
                }
            )
            
            if not client.connect():
                return 1
            
            try:
                # Execute command if specified
                if args.exec:
                    client.execute_remote_command(args.exec, terminate_after=args.terminate)
                
                # Send file if specified
                elif args.send:
                    client.send_file(args.send, terminate_after=args.terminate,
                                   execute_after=args.execute_after)
                
                # Receive file if specified
                elif args.receive:
                    logger.error("File receive not implemented in this version")
                    # TODO: Implement file receive
                
                # Interactive mode (default)
                else:
                    client.interactive()
                    
            except KeyboardInterrupt:
                logger.info("\nInterrupted by user")
            finally:
                client.close()
                
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        if args.verbose > 1:
            import traceback
            traceback.print_exc()
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main())