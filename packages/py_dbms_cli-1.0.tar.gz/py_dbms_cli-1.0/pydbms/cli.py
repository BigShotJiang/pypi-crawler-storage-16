from .core import main

def run():
    main()