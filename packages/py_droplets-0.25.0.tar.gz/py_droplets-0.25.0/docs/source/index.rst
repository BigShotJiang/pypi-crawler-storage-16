'py-droplets' python package
============================

The `py-droplets` python package provides methods and classes useful for 
studying phase separation phenomena using phase field methods.



Contents
--------

.. toctree::
    :maxdepth: 4

    installation
    quickstart/quickstart
    packages/droplets
 


Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
