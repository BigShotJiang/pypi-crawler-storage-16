Getting started
===============


.. toctree::
   :maxdepth: 3


   examples
   contributing