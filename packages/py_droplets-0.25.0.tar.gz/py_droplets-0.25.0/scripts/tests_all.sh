echo "Test codestyle"
echo "--------------"
./tests_codestyle.sh

echo ""
echo "Test types"
echo "----------"
./tests_types.sh

echo ""
echo "Run unittests"
echo "-------------"
./tests_parallel.sh