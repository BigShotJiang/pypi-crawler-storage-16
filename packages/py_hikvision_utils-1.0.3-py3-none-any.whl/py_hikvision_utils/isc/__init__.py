#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
=================================================
作者：[郭磊]
手机：[15210720528]
Email：[174000902@qq.com]
Gitee：https://gitee.com/guolei19850528/py_hikvision_utils.git
=================================================
"""
import base64
import hashlib
import hmac
import uuid
from datetime import datetime

import httpx
from jsonschema.validators import Draft202012Validator


class ISecureCenter(object):
    def __init__(
            self,
            host: str = "",
            ak: str = "",
            sk: str = ""
    ):
        """
        Hikvsion iSecure Center Class

        @see https://open.hikvision.com/docs/docId?productId=5c67f1e2f05948198c909700&version=%2F29c78ef52ca842c7933bd2b8e051e9d0&tagPath=%E6%96%87%E6%A1%A3%E8%AF%B4%E6%98%8E
        :param host: host
        :param ak: ak
        :param sk: sk
        """
        self.host = host[:-1] if host.endswith("/") else host
        self.ak = ak
        self.sk = sk
        self.general_validate_json_schema = {
            "type": "object",
            "properties": {
                "code": {
                    "oneOf": [
                        {"type": "string", "const": "0"},
                        {"type": "integer", "const": 0},
                    ]
                },
            },
            "required": ["code", "data"]
        }

    def timestamp(self):
        return int(datetime.now().timestamp() * 1000)

    def nonce(self):
        return uuid.uuid4().hex

    def signature(self, string: str = ""):
        return base64.b64encode(
            hmac.new(
                self.sk.encode(),
                string.encode(),
                digestmod=hashlib.sha256
            ).digest()
        ).decode()

    def headers(
            self,
            method: str = "POST",
            path: str = "",
            headers: dict = {}
    ):
        """
        request headers
        :param method:
        :param path:
        :param headers:
        :return:
        """
        method = method if isinstance(method, str) else "POST"
        path = path if isinstance(path, str) else ""
        headers = headers if isinstance(headers, dict) else dict()
        headers = {
            "accept": "*/*",
            "content-type": "application/json",
            "x-ca-signature-headers": "x-ca-key,x-ca-nonce,x-ca-timestamp",
            "x-ca-key": self.ak,
            "x-ca-nonce": self.nonce(),
            "x-ca-timestamp": str(self.timestamp()),
            **headers
        }
        string = "\n".join([
            method,
            headers["accept"],
            headers["content-type"],
            f"x-ca-key:{headers['x-ca-key']}",
            f"x-ca-nonce:{headers['x-ca-nonce']}",
            f"x-ca-timestamp:{headers['x-ca-timestamp']}",
            path,
        ])
        headers["x-ca-signature"] = self.signature(string=string)
        return headers

    def request(self, path: str = "", **kwargs):
        """
        执行请求
        :param path: 请求URL path
        :param kwargs: httpx.request(**kwargs)
        :return: state,response.json(),response
        """
        kwargs = kwargs if isinstance(kwargs, dict) else dict()
        kwargs.setdefault("method", "POST")
        kwargs.setdefault("url", self.host + path)
        kwargs.setdefault("verify", False)
        kwargs.setdefault("headers", dict())
        headers = self.headers(
            method=kwargs.get("method", "POST"),
            path=path,
            headers=kwargs.get("headers", dict())
        )
        kwargs["headers"] = headers
        response = httpx.request(**kwargs)
        response_json = response.json() if response.is_success else dict()
        if Draft202012Validator(self.general_validate_json_schema).is_valid(response_json):
            return True, response_json, response
        return None, response_json, response
