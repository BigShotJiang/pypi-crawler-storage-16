# Python Improv via BLE Client

Python package to provision devices which implement Improv via BLE
