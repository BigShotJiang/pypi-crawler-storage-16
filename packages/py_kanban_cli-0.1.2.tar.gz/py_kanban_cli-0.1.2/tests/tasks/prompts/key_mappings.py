KEY_MAPPINGS = {
    "<Enter>": "\r",
    "<Down>": "\x1b[B",
    "<Up>": "\x1b[A",
    "<Esc>": "\x1b",
    "<Tab>": "\t",
    "<Backspace>": "\b",
}
