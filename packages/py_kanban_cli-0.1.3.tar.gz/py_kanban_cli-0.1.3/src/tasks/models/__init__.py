from src.categories.models.category import Category
from src.tasks.models.task import Task

MODELS = [Category, Task]
