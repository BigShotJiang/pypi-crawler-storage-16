from kanban_cli.categories.models.category import Category
from kanban_cli.tasks.models.task import Task

MODELS = [Category, Task]
