#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
=================================================
作者：[郭磊]
手机：[15210720528]
Email：[174000902@qq.com]
Gitee：https://gitee.com/guolei19850528/py_lmobile_utils.git
=================================================
"""
import hashlib
import random
import string
from datetime import datetime
from typing import Union

import httpx
from jsonschema.validators import Draft202012Validator


class SmsPusher(object):
    def __init__(
            self,
            account_id: str = "",
            password: str = "",
            product_id: Union[int, str] = 0,
            smms_encrypt_key: str = "SMmsEncryptKey"
    ):
        self.account_id = account_id
        self.password = password
        self.product_id = product_id
        self.smms_encrypt_key = smms_encrypt_key
        self.send_sms_url_formatter = "https://api.51welink.com/EncryptionSubmit/SendSms.ashx"
        self.send_sms_validate_json_schema = {
            "type": "object",
            "properties": {
                "Result": {"type": "string", "const": "succ"},
            },
            "required": ["Result"]
        }

    def timestamp(self):
        return int(datetime.now().timestamp())

    def random_digits(self, length=10):
        return int("".join(random.sample(string.digits, length)))

    def password_md5(self):
        return hashlib.md5(f"{self.password}{self.smms_encrypt_key}".encode('utf-8')).hexdigest()

    def sha256_signature(self, data: dict = dict()):
        data = data if isinstance(data, dict) else data
        data.setdefault("AccountId", self.account_id)
        data.setdefault("Timestamp", self.timestamp())
        data.setdefault("Random", self.random_digits())
        data.setdefault("ProductId", self.product_id)
        data.setdefault("PhoneNos", "")
        data.setdefault("Content", "")
        temp_string = "&".join([
            f"AccountId={data.get("AccountId", "")}",
            f"PhoneNos={str(data.get("PhoneNos", "")).split(",")[0]}",
            f"Password={self.password_md5().upper()}",
            f"Random={data.get('Random', "")}",
            f"Timestamp={data.get('Timestamp', "")}",
        ])
        return hashlib.sha256(temp_string.encode("utf-8")).hexdigest()

    def send_sms(
            self,
            phone_nos: str = None,
            content: str = None,
            **kwargs
    ):
        """
        @see https://www.lmobile.cn/ApiPages/index.html
        :param phone_nos:
        :param content:
        :param kwargs:
        :return:
        """
        kwargs = kwargs if isinstance(kwargs, dict) else kwargs

        kwargs.setdefault("method", "POST")
        kwargs.setdefault("url", self.send_sms_url_formatter)
        kwargs.setdefault("data", dict())
        data = kwargs.get("data", dict())
        data.setdefault("AccountId", self.account_id)
        data.setdefault("Timestamp", self.timestamp())
        data.setdefault("Random", self.random_digits())
        data.setdefault("ProductId", self.product_id)
        data.setdefault("PhoneNos", phone_nos)
        data.setdefault("Content", content)
        data.setdefault("AccessKey", self.sha256_signature(data))
        kwargs["data"] = data
        response = httpx.request(**kwargs)
        response_json = response.json() if response.is_success else dict()
        if Draft202012Validator(self.send_sms_validate_json_schema).is_valid(instance=response_json):
            return True, response_json, response
        return None, response_json, response
