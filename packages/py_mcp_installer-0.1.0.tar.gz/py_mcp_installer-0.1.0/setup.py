"""Setup configuration for py-mcp-installer-service."""
from setuptools import setup

# Configuration is in pyproject.toml
setup()
