User manual
===========


.. toctree::
   :maxdepth: 3


   mathematical_basics
   basic_usage
   advanced_usage
   performance
   contributing
   citing
   code_of_conduct