Examples
========

These are example scripts using the `py-pde` package, which illustrates some of the most
important features of the package.