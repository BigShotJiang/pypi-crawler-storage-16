Grids and fields
----------------

These examples show how to define and manipulate discretized fields.