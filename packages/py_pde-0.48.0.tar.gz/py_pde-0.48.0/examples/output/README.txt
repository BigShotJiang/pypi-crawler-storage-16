Output and analysis
-------------------

These examples demonstrate how to store and analyze output.