from py_pnet._core import hello_from_bin


def main() -> None:
    print(hello_from_bin())
