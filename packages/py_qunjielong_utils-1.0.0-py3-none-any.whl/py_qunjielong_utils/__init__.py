#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
=================================================
作者：[郭磊]
手机：[15210720528]
Email：[174000902@qq.com]
Gitee：https://gitee.com/guolei19850528/py_qunjielong_utils.git
=================================================
"""
from typing import Union
import diskcache
import httpx
import redis
from jsonschema.validators import Draft202012Validator
from datetime import timedelta


class OpenApi(object):
    def __init__(
            self,
            base_url: str = "https://openapi.qunjielong.com",
            secret: str = "",
            cache_inst: Union[diskcache.Cache, redis.Redis, redis.StrictRedis] = None
    ):
        """
        第三方开放Api

        @see https://console-docs.apipost.cn/preview/b4e4577f34cac87a/1b45a97352d07e60/
        :param base_url: 基础url
        :param secret: 秘钥
        :param cache_inst: 缓存实例
        """
        self.base_url = base_url[:-1] if base_url.endswith("/") else base_url
        self.secret = secret
        self.cache_inst = cache_inst
        self.access_token = ""
        self.general_validate_json_schema = {
            "type": "object",
            "properties": {
                "code": {
                    "oneOf": [
                        {"type": "integer", "const": 200},
                        {"type": "string", "const": 200},
                    ],
                }
            },
            "required": ["code"],
        }

        self.getGhomeInfo_validate_json_schema = {
            "type": "object",
            "properties": {
                "code": {
                    "oneOf": [
                        {"type": "integer", "const": 200},
                        {"type": "string", "const": 200},
                    ],
                },
                "data": {
                    "type": "object",
                    "properties": {
                        "ghId": {
                            "oneOf": [
                                {"type": "integer", "minimum": 1},
                                {"type": "string", "minLength": 1},
                            ],
                        }
                    },
                    "required": ["ghId"],
                }
            },
            "required": ["code"],
        }

    def getGhomeInfo(self, **kwargs):
        kwargs = kwargs if isinstance(kwargs, dict) else dict()
        kwargs.setdefault("method", "GET")
        kwargs.setdefault("url", f"{self.base_url}/open/api/ghome/getGhomeInfo?accessToken={self.access_token}")
        response = httpx.request(**kwargs)
        response_json = response.json() if response.is_success else dict()
        if Draft202012Validator(self.getGhomeInfo_validate_json_schema).is_valid(response_json):
            return True, response_json.get("data", ""), response
        return None, response_json, response

    def token(self, **kwargs):
        """
        获取访问凭证

        @see https://console-docs.apipost.cn/preview/b4e4577f34cac87a/1b45a97352d07e60/?target_id=71e7934a-afce-4fd3-a897-e2248502cc94
        :param kwargs: httpx.request(**kwargs)
        :return: state,access token or response.json(),respone
        """
        kwargs = kwargs if isinstance(kwargs, dict) else dict()
        kwargs.setdefault("method", "GET")
        kwargs.setdefault("url", f"{self.base_url}/open/auth/token?secret={self.secret}")
        response = httpx.request(**kwargs)
        response_json = response.json() if response.is_success else dict()
        if Draft202012Validator(self.general_validate_json_schema).is_valid(response_json):
            self.access_token = response_json.get("data", "")
            return True, response_json.get("data", ""), response
        return False, response_json, response

    def refresh_access_token(
            self,
            cache_key_formatter="qunjielong_access_token_{secret}",
            cache_expire: Union[float, int, timedelta] = 7100,
            token_kwargs: dict = dict(),
            getGhomeInfo_kwargs: dict = dict(),
    ):
        """
        如果传递了cache_inst 则先取缓存中的 access_token 否则直接获取 access_token
        :param cache_key_formatter: 缓存key格式化
        :param cache_expire: 缓存过期时间
        :param token_kwargs: self.token(**token_kwargs)
        :param getGhomeInfo_kwargs: self.getGhomeInfo(**getGhomeInfo_kwargs)
        :return: self
        """
        cache_key = cache_key_formatter.format(
            secret=self.secret) if "{secret}" in cache_key_formatter else cache_key_formatter
        token_kwargs = token_kwargs if isinstance(token_kwargs, dict) else dict()
        getGhomeInfo_kwargs = getGhomeInfo_kwargs if isinstance(getGhomeInfo_kwargs, dict) else dict()
        if not isinstance(self.cache_inst, (diskcache.Cache, redis.Redis, redis.StrictRedis)):
            state, access_token, _ = self.token(**token_kwargs)
            if state and isinstance(access_token, str) and len(access_token):
                self.access_token = access_token
        else:
            if isinstance(self.cache_inst, diskcache.Cache):
                self.access_token = self.cache_inst.get(cache_key, "")
            if isinstance(self.cache_inst, (redis.Redis, redis.StrictRedis)):
                self.access_token = self.cache_inst.get(cache_key)
            self.access_token = self.access_token if isinstance(self.access_token, str) else ""
            state, _, _ = self.getGhomeInfo(**getGhomeInfo_kwargs)
            if not state:
                state, access_token, _ = self.token(**token_kwargs)
                if state and isinstance(access_token, str) and len(access_token):
                    self.access_token = access_token
                    if isinstance(self.cache_inst, diskcache.Cache):
                        self.cache_inst.set(
                            key=cache_key,
                            value=self.access_token,
                            expire=cache_expire.total_seconds() if isinstance(cache_expire, timedelta) else cache_expire
                        )
                    if isinstance(self.cache_inst, (redis.Redis, redis.StrictRedis)):
                        self.cache_inst.set(
                            name=cache_key,
                            value=self.access_token,
                            ex=cache_expire
                        )
        return self
