// Integration test modules
mod basic_indexing;
mod cache_tests;
mod concurrent_indexing;
pub mod etag_memory_backend;
