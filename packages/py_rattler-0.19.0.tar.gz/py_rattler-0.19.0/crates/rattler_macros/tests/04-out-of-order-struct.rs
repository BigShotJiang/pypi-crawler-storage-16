use rattler_macros::sorted;

#[sorted]
pub struct Alphabet {
    b: i64,
    a: String,
    haha: String,
    hihi: String,
    x: String,
}

fn main() {}
