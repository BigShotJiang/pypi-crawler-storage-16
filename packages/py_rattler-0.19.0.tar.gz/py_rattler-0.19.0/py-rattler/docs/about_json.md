# AboutJson

::: rattler.package.about_json
