# GenericVirtualPackage

::: rattler.virtual_package.generic
