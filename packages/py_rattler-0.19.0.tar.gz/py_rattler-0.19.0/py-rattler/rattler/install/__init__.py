from rattler.install.installer import install

__all__ = ["install"]
