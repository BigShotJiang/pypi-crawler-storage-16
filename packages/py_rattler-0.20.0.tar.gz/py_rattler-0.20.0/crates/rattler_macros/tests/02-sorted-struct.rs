use rattler_macros::sorted;

#[sorted]
pub struct Alphabet {
    a: String,
    b: i64,
    haha: String,
    hihi: String,
    x: String,
}

fn main() {}
