use rattler_macros::sorted;

#[sorted]
pub enum Alphabet {
    BBB,
    A,
    C,
    XYZ,
    Z
}

fn main() {}
