# activate

::: rattler.shell.shell.activate
