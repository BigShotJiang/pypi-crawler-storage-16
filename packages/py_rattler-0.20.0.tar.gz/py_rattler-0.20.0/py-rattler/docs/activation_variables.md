# ActivationVariables

::: rattler.shell.shell.ActivationVariables
