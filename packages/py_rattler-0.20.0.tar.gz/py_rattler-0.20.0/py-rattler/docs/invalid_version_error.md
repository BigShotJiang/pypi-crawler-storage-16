# InvalidVersionError

::: rattler.exceptions.InvalidVersionError
