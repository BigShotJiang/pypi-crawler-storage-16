# PathModificationBehavior

::: rattler.shell.shell.PathModificationBehavior
