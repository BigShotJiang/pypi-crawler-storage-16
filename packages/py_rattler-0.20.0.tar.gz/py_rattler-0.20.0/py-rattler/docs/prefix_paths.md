# PrefixPaths

::: rattler.prefix.prefix_paths
