# TransactionError

::: rattler.exceptions.TransactionError
