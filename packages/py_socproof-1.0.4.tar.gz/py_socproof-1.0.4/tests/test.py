import asyncio

from soc_proof import SocProofAPI

api = SocProofAPI(
    token="dd25aaf1327ecc04c20ab5ecba1ab139"
)


async def main():

    order_id = await api.get_status(
        orders="140802962"
    )

    print(order_id)


asyncio.run(main())