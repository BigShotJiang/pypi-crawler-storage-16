# Exceptions

```{eval-rst}
.. automodule:: solcx.exceptions
    :members:
    :show-inheritance:
```
