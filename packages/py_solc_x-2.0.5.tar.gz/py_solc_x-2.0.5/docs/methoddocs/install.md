# Install

```{eval-rst}
.. automodule:: solcx.install
    :members:
    :show-inheritance:
```
