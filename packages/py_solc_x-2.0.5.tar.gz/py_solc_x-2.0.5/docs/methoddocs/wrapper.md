# Wrapper

```{eval-rst}
.. automodule:: solcx.wrapper
    :members:
    :show-inheritance:
```
