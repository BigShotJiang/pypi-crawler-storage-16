stopwatch package
=================

Submodules
----------

stopwatch.stopwatch module
--------------------------

.. automodule:: stopwatch.stopwatch
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: stopwatch
   :members:
   :undoc-members:
   :show-inheritance:
