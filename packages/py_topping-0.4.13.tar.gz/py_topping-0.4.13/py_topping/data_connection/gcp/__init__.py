from .gcs import lazy_GCS
from .gbq import lazy_GBQ
