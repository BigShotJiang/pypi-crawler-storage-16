"""
Clean Utils Module
清理工具模块
"""

from py_wlcommands.commands.clean.utils import (
    clean_rust_artifacts as _clean_rust_artifacts,
)
from py_wlcommands.commands.clean.utils import (
    remove_auto_activation_scripts,
    remove_directories,
    remove_egg_info_dirs,
    remove_files,
    remove_log_files,
    remove_pycache_dirs,
    remove_rust_analyzer_dirs,
    remove_uv_lock,
    remove_virtual_environments,
)
from py_wlcommands.utils.logging import log_info

# Keep backward compatibility with tests that import private functions
# 保持与导入私有函数的测试的向后兼容性
_remove_directories = remove_directories
_remove_files = remove_files
_remove_log_files = remove_log_files
_remove_pycache_dirs = remove_pycache_dirs
_remove_egg_info_dirs = remove_egg_info_dirs
_remove_virtual_environments = remove_virtual_environments
_remove_auto_activation_scripts = remove_auto_activation_scripts
_remove_uv_lock = remove_uv_lock


# Public functions
# 公共函数


def clean_build_artifacts() -> None:
    """
    Clean build artifacts and temporary files
    清理构建产物和临时文件
    """
    log_info("Cleaning build artifacts and temporary files...", lang="en")
    log_info("正在清理构建产物和临时文件...", lang="zh")

    # Remove build directories
    build_dirs = [
        "build",
        "dist",
        "results",
        ".mypy_cache",
        ".pytest_cache",
        ".ruff_cache",
        "logs",
        "todos",
    ]
    remove_directories(build_dirs)

    # Remove specific files
    files_to_remove = [".coverage"]
    remove_files(files_to_remove)

    # Remove log files
    remove_log_files()

    # Remove pycache directories only in project directory
    remove_pycache_dirs()

    # Remove egg-info directories
    remove_egg_info_dirs()

    # Remove rust-analyzer directories
    remove_rust_analyzer_dirs()

    log_info("Build artifacts and temporary files cleaning completed.", lang="en")
    log_info("构建产物和临时文件清理完成。", lang="zh")


def clean_rust_artifacts() -> None:
    """
    Clean Rust build artifacts
    清理Rust构建产物
    """
    _clean_rust_artifacts()


def clean_all_artifacts() -> None:
    """
    Clean all artifacts including virtual environment
    清理所有产物，包括虚拟环境
    """
    log_info("Cleaning all artifacts...", lang="en")
    log_info("正在清理所有产物...", lang="zh")

    # Clean build artifacts
    clean_build_artifacts()

    # Clean Rust artifacts
    clean_rust_artifacts()

    # Remove virtual environment
    remove_virtual_environments()

    # Remove auto-activation scripts
    remove_auto_activation_scripts()

    # Remove rust-analyzer directories
    remove_rust_analyzer_dirs()

    # Remove uv.lock file
    remove_uv_lock()

    log_info("All artifacts cleaning completed.", lang="en")
    log_info("所有产物清理完成。", lang="zh")
