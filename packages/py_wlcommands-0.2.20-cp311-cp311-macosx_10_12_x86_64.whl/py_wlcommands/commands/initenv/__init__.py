# Import the init command to register it
from .initenv import InitCommand  # noqa: F401
