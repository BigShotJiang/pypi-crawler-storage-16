"""
Test commands package initialization.
"""

# Import the test command to register it
from .test_commands import TestCommand

__all__ = ["TestCommand"]
