"""
WL Commands - Command line interface for project management
"""

__version__ = "0.2.22"

from .commands import Command, register_command
