"""
Self commands module.
"""

from .self_command import SelfCommand

__all__ = ["SelfCommand"]
