"""
Clean command module.
"""

# Import the clean command to register it
from .clean import CleanCommand  # noqa: F401
