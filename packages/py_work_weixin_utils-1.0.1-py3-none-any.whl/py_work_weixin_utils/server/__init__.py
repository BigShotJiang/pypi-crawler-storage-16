#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
from datetime import timedelta
from typing import Union

import diskcache
import httpx
import redis
from jsonschema.validators import Draft202012Validator


class Api(object):
    def __init__(
            self,
            agentid: Union[str, int] = "",
            corpid: str = "",
            corpsecret: str = "",
            cache_inst: Union[diskcache.Cache, redis.Redis, redis.StrictRedis] = None
    ):
        self.agentid = agentid
        self.corpid = corpid
        self.corpsecret = corpsecret
        self.cache_inst = cache_inst
        self.access_token: str = ""
        self.gettoken_url_formatter = "https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid={corpid}&corpsecret={corpsecret}"
        self.gettoken_validate_json_schema = {
            "type": "object",
            "properties": {
                "access_token": {"type": "string", "minLength": 1},
            },
            "required": ["access_token"],
        }
        self.get_api_domain_ip_url_formatter = "https://qyapi.weixin.qq.com/cgi-bin/get_api_domain_ip?access_token={access_token}"
        self.get_api_domain_ip_validate_json_schema = {
            "type": "object",
            "properties": {
                "ip_list": {"type": "array", "minItems": 1},
            },
            "required": ["ip_list"],
        }
        self.message_send_url_formatter = "https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token={access_token}"
        self.message_send_validate_json_schema = {
            "type": "object",
            "properties": {
                "errcode": {
                    "oneOf": [
                        {"type": "integer", "const": 0},
                        {"type": "string", "const": "0"},
                    ]
                }
            },
            "required": ["errcode"],
        }
        self.media_upload_url_formatter = "https://qyapi.weixin.qq.com/cgi-bin/media/upload?access_token={access_token}&type={f_type}"
        self.media_upload_validate_json_schema = {
            "type": "object",
            "properties": {
                "media_id": {"type": "string", "minLength": 1},
            },
            "required": ["media_id"],
        }
        self.media_uploadimg_url_formatter = "https://qyapi.weixin.qq.com/cgi-bin/media/uploadimg?access_token={access_token}"
        self.media_uploadimg_validate_json_schema = {
            "type": "object",
            "properties": {
                "url": {"type": "string", "minLength": 1},
            },
            "required": ["url"],
        }

    def gettoken(self, **kwargs):
        """
        获取 access token

        @see https://developer.work.weixin.qq.com/document/path/91039
        :param kwargs: httpx.request(**kwargs)
        :return: state,access_token
        """
        kwargs = kwargs if isinstance(kwargs, dict) else dict()
        kwargs.setdefault("method", "GET")
        kwargs.setdefault("url", self.gettoken_url_formatter.format(corpid=self.corpid, corpsecret=self.corpsecret))
        response = httpx.request(**kwargs)
        response_json = response.json() if response.is_success else dict()
        if Draft202012Validator(self.gettoken_validate_json_schema).is_valid(response_json):
            self.access_token = response_json.get("access_token", None)
            return True, response_json.get("access_token", None), response
        return None, response_json, response

    def get_api_domain_ip(self, **kwargs):
        """
        获取企业微信接口IP段

        @see https://developer.work.weixin.qq.com/document/path/92520
        :param kwargs: httpx.request(**kwargs)
        :return: state,ip_list or json
        """
        kwargs = kwargs if isinstance(kwargs, dict) else dict()
        kwargs.setdefault("method", "GET")
        kwargs.setdefault("url", self.get_api_domain_ip_url_formatter.format(access_token=self.access_token))
        response = httpx.request(**kwargs)
        response_json = response.json() if response.is_success else dict()
        if Draft202012Validator(self.get_api_domain_ip_validate_json_schema).is_valid(response_json):
            return True, response_json.get("ip_list", []), response
        return None, response_json, response

    def message_send(self, **kwargs):
        """
        发送应用消息

        @see https://developer.work.weixin.qq.com/document/path/90236
        :param kwargs: httpx.request(**kwargs)
        :return: state,json
        """
        kwargs = kwargs if isinstance(kwargs, dict) else dict()
        kwargs.setdefault("method", "POST")
        kwargs.setdefault("url", self.message_send_url_formatter.format(access_token=self.access_token))
        response = httpx.request(**kwargs)
        response_json = response.json() if response.is_success else dict()
        if Draft202012Validator(self.message_send_validate_json_schema).is_valid(response_json):
            return True, response_json, response
        return None, response_json, response

    def media_upload(self, f_type="file", **kwargs):
        """
        上传临时素材

        @see https://developer.work.weixin.qq.com/document/path/90253
        :param f_type:
        :param kwargs: httpx.request(**kwargs)
        :return: state,media_id or json
        """
        f_type = f_type if isinstance(f_type, str) and f_type in ["image", "voice", "video", "file"] else "file"
        kwargs = kwargs if isinstance(kwargs, dict) else dict()
        kwargs.setdefault("method", "POST")
        kwargs.setdefault("url", self.media_upload_url_formatter.format(access_token=self.access_token, f_type=f_type))
        response = httpx.request(**kwargs)
        response_json = response.json() if response.is_success else dict()
        if Draft202012Validator(self.media_upload_validate_json_schema).is_valid(response_json):
            return True, response_json.get("media_id", None), response
        return None, response_json, response

    def media_uploadimg(self, **kwargs):
        """
        上传图片

        @see https://developer.work.weixin.qq.com/document/path/90256
        :param kwargs: httpx.request(**kwargs)
        :return: state,url or json
        """
        kwargs = kwargs if isinstance(kwargs, dict) else dict()
        kwargs.setdefault("method", "POST")
        kwargs.setdefault("url", self.media_uploadimg_url_formatter.format(access_token=self.access_token))
        response = httpx.request(**kwargs)
        response_json = response.json() if response.is_success else dict()
        if Draft202012Validator(self.media_uploadimg_validate_json_schema).is_valid(response_json):
            return True, response_json.get("url", None), response
        return None, response_json, response

    def refresh_access_token(
            self,
            cache_key_formatter="work_weixin_server_access_token_{agentid}",
            cache_expire: Union[float, int, timedelta] = 7100,
            gettoken_kwargs: dict = {},
            get_api_domain_ip_kwargs: dict = {}
    ):
        """
        刷新 access_token

        如果传递了cache_inst 则先取缓存中的 access_token 否则直接获取 access_token
        :param cache_key_formatter: 缓存key格式
        :param cache_expire: 缓存过期时间
        :param gettoken_kwargs: self.gettoken(**gettoken_kwargs) 获取token方法
        :param get_api_domain_ip_kwargs: self.get_api_domain_ip(**get_api_domain_ip_kwargs) 获取企业微信IP地址段方法验证access token是否有效
        :return: self
        """
        cache_key = cache_key_formatter.format(
            agentid=self.agentid) if "{agentid}" in cache_key_formatter else cache_key_formatter
        gettoken_kwargs = gettoken_kwargs if isinstance(gettoken_kwargs, dict) else dict()
        get_api_domain_ip_kwargs = get_api_domain_ip_kwargs if isinstance(get_api_domain_ip_kwargs,
                                                                          dict) else dict()
        if not isinstance(self.cache_inst, (diskcache.Cache, redis.Redis, redis.StrictRedis)):
            state, access_token, _ = self.gettoken(**gettoken_kwargs)
            if state and isinstance(access_token, str) and len(access_token):
                self.access_token = access_token
        else:
            if isinstance(self.cache_inst, diskcache.Cache):
                self.access_token = self.cache_inst.get(cache_key, "")
            if isinstance(self.cache_inst, (redis.Redis, redis.StrictRedis)):
                self.access_token = self.cache_inst.get(cache_key)
            state, _, _ = self.get_api_domain_ip(**get_api_domain_ip_kwargs)
            if not state:
                state, access_token, _ = self.gettoken(**gettoken_kwargs)
                self.access_token = access_token if state and isinstance(access_token, str) and len(
                    access_token) else None
                if isinstance(self.cache_inst, diskcache.Cache):
                    self.cache_inst.set(
                        key=cache_key,
                        value=self.access_token,
                        expire=cache_expire.total_seconds() if isinstance(cache_expire, timedelta) else cache_expire
                    )
                if isinstance(self.cache_inst, (redis.Redis, redis.StrictRedis)):
                    self.cache_inst.set(
                        name=cache_key,
                        value=self.access_token,
                        ex=cache_expire
                    )

        return self
