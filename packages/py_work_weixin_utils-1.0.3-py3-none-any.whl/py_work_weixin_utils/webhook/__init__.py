#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

"""
=================================================
作者：[郭磊]
手机：[15210720528]
Email：[174000902@qq.com]
Gitee：https://gitee.com/guolei19850528/work_weixin_pkgs
=================================================
"""

from typing import Union

import httpx
from jsonschema.validators import Draft202012Validator


class MessagePusher(object):
    def __init__(self, key: str = "", mentioned_list: Union[tuple, list] = [],
                 mentioned_mobile_list: Union[tuple, list] = []):
        """
        消息推送器

        @see https://developer.work.weixin.qq.com/document/path/91770#markdown%E7%B1%BB%E5%9E%8B
        :param key: 你的webhook key
        :param mentioned_list: userid的列表，提醒群中的指定成员(@某个成员)，@all表示提醒所有人，如果开发者获取不到userid，可以使用mentioned_mobile_list
        :param mentioned_mobile_list: 手机号列表，提醒手机号对应的群成员(@某个成员)，@all表示提醒所有人
        """
        self.key = key
        self.mentioned_list = mentioned_list
        self.mentioned_mobile_list = mentioned_mobile_list
        self.send_url_formatter = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key={key}"
        self.send_validate_json_schema = {
            "type": "object",
            "properties": {
                "errcode": {
                    "oneOf": [
                        {"type": "integer", "const": 0},
                        {"type": "string", "const": "0"},
                    ]
                }
            },
            "required": ["errcode"],
        }
        self.upload_media_url_formatter = "https://qyapi.weixin.qq.com/cgi-bin/webhook/upload_media?key={key}&type={f_type}"
        self.upload_media_validate_json_schema = {
            "type": "object",
            "properties": {
                "errcode": {
                    "oneOf": [
                        {"type": "integer", "const": 0},
                        {"type": "string", "const": "0"},
                    ]
                },
                "media_id": {
                    "type": "string",
                    "minLength": 1,
                }
            },
            "required": ["errcode"],
        }

    def msgtype_text_formatter(
            self,
            content: str = "",
            mentioned_list: Union[tuple, list] = [],
            mentioned_mobile_list: Union[tuple, list] = []
    ):
        """
        文本消息 格式化

        @see https://developer.work.weixin.qq.com/document/path/91770#%E6%96%87%E6%9C%AC%E7%B1%BB%E5%9E%8B
        :param content:
        :param mentioned_list:
        :param mentioned_mobile_list:
        :return: dict
        """
        return {
            "msgtype": "text",
            "text": {
                "content": f"{content}",
                "mentioned_list": self.mentioned_list + mentioned_list,
                "mentioned_mobile_list": self.mentioned_mobile_list + mentioned_mobile_list
            }
        }

    def msgtype_markdown_formatter(self, content: str = ""):
        """
        markdown消息 格式化

        @see https://developer.work.weixin.qq.com/document/path/91770#markdown%E7%B1%BB%E5%9E%8B
        :param content:
        :return: dict
        """
        return {
            "msgtype": "markdown",
            "markdown": {
                "content": f"{content}"
            }
        }

    def msgtype_image_formatter(self, image_base64: str = ""):
        """
        图片消息 格式化

        @see https://developer.work.weixin.qq.com/document/path/91770#%E5%9B%BE%E7%89%87%E7%B1%BB%E5%9E%8B
        :param image_base64:
        :return:
        """
        return {
            "msgtype": "image",
            "image": {
                "base64": f"{image_base64}",
                "md5": "MD5"
            }
        }

    def msgtype_news_formatter(self, articles: Union[tuple, list] = []):
        """
        新闻消息 格式化

        @see https://developer.work.weixin.qq.com/document/path/91770#%E5%9B%BE%E6%96%87%E7%B1%BB%E5%9E%8B
        :param articles:
        :return: dict
        """
        return {
            "msgtype": "news",
            "news": {
                "articles": articles
            }
        }

    def msgtype_template_card_formatter(self, template_card: dict = {}):
        """
        模版卡片消息 格式化

        @see https://developer.work.weixin.qq.com/document/path/91770#%E6%A8%A1%E7%89%88%E5%8D%A1%E7%89%87%E7%B1%BB%E5%9E%8B
        :param template_card:
        :return: dict
        """
        return {
            "msgtype": "template_card",
            "template_card": template_card
        }

    def msgtype_file_formatter(self, media_id: str = ""):
        """
        文件消息 格式化

        @see https://developer.work.weixin.qq.com/document/path/91770#%E6%96%87%E4%BB%B6%E7%B1%BB%E5%9E%8B
        :param media_id:
        :return: dict
        """
        return {
            "msgtype": "file",
            "file": {
                "media_id": media_id
            }
        }

    def msgtype_voice_formatter(self, media_id: str = ""):
        """
        音频消息 格式化

        @see https://developer.work.weixin.qq.com/document/path/91770#%E8%AF%AD%E9%9F%B3%E7%B1%BB%E5%9E%8B
        :param media_id:
        :return: dict
        """
        return {
            "msgtype": "voice",
            "voice": {
                "media_id": media_id
            }
        }

    def send(self, **kwargs):
        """
        发送消息

        @see https://developer.work.weixin.qq.com/document/path/91770#%E5%A6%82%E4%BD%95%E4%BD%BF%E7%94%A8%E6%B6%88%E6%81%AF%E6%8E%A8%E9%80%81
        :param kwargs: httpx.request(**kwargs)
        :return: state,response.json(),response
        """

        kwargs = kwargs if isinstance(kwargs, dict) else dict()
        kwargs.setdefault("method", "POST")
        kwargs.setdefault("url", self.send_url_formatter.format(key=self.key))
        response = httpx.request(**kwargs)
        response_json = response.json() if response.is_success else dict
        if Draft202012Validator(self.send_validate_json_schema).is_valid(response_json):
            return True, response_json, response
        return None, response_json, response

    def upload_media(self, f_type: str = "file", **kwargs):
        """
        上传文件

        @see https://developer.work.weixin.qq.com/document/path/91770#%E6%96%87%E4%BB%B6%E4%B8%8A%E4%BC%A0%E6%8E%A5%E5%8F%A3
        :param f_type: file type one of ["voice", "file"]
        :param kwargs: httpx.request(**kwargs)
        :return: state, media_id or response.json(), response
        """
        f_type = "file" if isinstance(f_type, str) and f_type.lower() not in ["voice", "file"] else f_type
        kwargs = kwargs if isinstance(kwargs, dict) else dict()
        kwargs.setdefault("method", "POST")
        kwargs.setdefault("url", self.upload_media_url_formatter.format(key=self.key, f_type=f_type))
        response = httpx.request(**kwargs)
        response_json = response.json() if response.is_success else dict()
        if Draft202012Validator(self.upload_media_validate_json_schema).is_valid(response_json):
            return True, response_json.get("media_id", None), response
        return None, response_json, response
