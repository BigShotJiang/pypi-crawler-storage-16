xlsindy.base\_catalog package
=============================

Module contents
---------------

.. automodule:: xlsindy.catalog_base
   :members:
   :undoc-members:
   :show-inheritance:
