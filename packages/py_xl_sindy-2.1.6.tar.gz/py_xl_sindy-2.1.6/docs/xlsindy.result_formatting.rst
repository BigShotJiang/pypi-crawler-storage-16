xlsindy.result_formatting module
================================

.. automodule:: xlsindy.result_formatting
   :members:
   :undoc-members:
   :show-inheritance:
