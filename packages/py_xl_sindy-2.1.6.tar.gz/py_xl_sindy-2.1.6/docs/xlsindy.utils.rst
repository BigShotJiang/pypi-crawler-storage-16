xlsindy.utils module
====================

.. automodule:: xlsindy.utils
   :members:
   :undoc-members:
   :show-inheritance:
