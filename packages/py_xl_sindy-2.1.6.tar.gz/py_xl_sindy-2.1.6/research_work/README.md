 ## Research Work

 This repository is the one that contain the majority of the work on XLsindy and mixed sindy by Eymeric CHAUCHAT. In this sense, I display here all the article / research work made until know.

 ### Poster

 A research has been made for the Tohoku University internal research seminar of second semester of 2024.

 ![research poster](/research_work/poster_ressources/poster.svg)

 All the ressources in order to reproduce the poster can be found in [util](/util/), laucnhing the batch file [batch_command_poster.sh](/research_work/poster_ressources/batch_command_poster.sh) and using the V2.0.2 of the library