from .ipycanvas_frontend import IpycanvasFrontend  # noqa: F401
