About the Documentation
=======================

What is worse than no documentation? Wrong / outdated documentation!
This is why I prefer to have a lot of examples which are automatically run
on each commit to ensure that they are still valid -- hopefully.


If something is unclear or missing in this documentation, its always a
good idea to check the `documentation <https://box2d.org/documentation.html>`_ of the original `Box2D C library <https://box2d.org/documentation.html>`_.
