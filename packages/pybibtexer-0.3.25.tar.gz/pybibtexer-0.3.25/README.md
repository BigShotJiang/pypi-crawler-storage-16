# pybibtexer

![Visitors](https://visitor-badge.laobi.icu/badge?page_id=Easy-PhD.pybibtexer)
[![License](https://img.shields.io/badge/license-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0.en.html)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pybibtexer)
[![PyPI](https://img.shields.io/pypi/v/pybibtexer)](https://pypi.org/project/pybibtexer/)
[![Commitizen friendly](https://img.shields.io/badge/commitizen-friendly-brightgreen.svg)](http://commitizen.github.io/cz-cli/)
