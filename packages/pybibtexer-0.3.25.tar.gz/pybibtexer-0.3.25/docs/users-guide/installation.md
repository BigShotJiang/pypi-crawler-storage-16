# Installation

- uv

```bash
uv add pybibtexer
```

- pip

```bash
pip install pybibtexer
```
