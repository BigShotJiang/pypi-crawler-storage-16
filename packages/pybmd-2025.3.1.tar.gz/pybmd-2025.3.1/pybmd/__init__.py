from .resolve import Resolve
from .ui_dispather import UI_Dispather

__name__ = 'pybmd'

__all__ = [
    'Resolve',
    'UI_Dispather',
]

# __major_version__ = "2025"
# __minor_version__ = "2"
# __change_version__ = "0"
# __version__ = ".".join(
#     (__major_version__, __minor_version__, __change_version__)
# )
# __version__="2025.2.0"