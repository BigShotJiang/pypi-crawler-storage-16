![Buy Me A Coffee](https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png)

## pybraendstofpriser

This is a PyPI module for fetching/scraping fuel prices from Danish suppliers, primarily developed for use with [Home Assistant](https://home-assistant.io), but I try to keep it as widely usable as possible.

### These companies are currently available:

*   [Go'On](https://goon.nu)
*   [OIL! tank & go](https://www.oil-tankstationer.dk)
*   [OK](https://www.ok.dk)
*   [Q8](https://www.q8.dk)
*   [Shell](https://shellservice.dk)