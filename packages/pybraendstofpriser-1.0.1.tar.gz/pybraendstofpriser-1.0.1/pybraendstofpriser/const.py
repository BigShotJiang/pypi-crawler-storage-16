"""Constants for pybraendstofpriser."""

DIESEL = "diesel"
DIESEL_PLUS = "diesel_plus"
OCTANE_92 = "octane_92"
OCTANE_95 = "octane_95"
OCTANE_100 = "octane_100"

DOWNLOAD_PATH = "/tmp/"
