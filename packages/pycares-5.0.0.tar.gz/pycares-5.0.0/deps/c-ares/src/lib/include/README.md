# Semi-public headers
The headers listed here all export symbols into the ares namespace as public
symbols, but these headers are NOT included in the distribution.  They are
meant to be used by other tools such as `adig` and `ahost`.

These are most likely going to be general purpose library functions such
as data structures and algorithms.

