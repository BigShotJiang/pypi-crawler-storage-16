class PiiFilteringFailModeType:
    OPEN = "OPEN"
    CLOSE = "CLOSE"
