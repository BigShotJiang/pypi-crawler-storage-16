#------------------------------------------------------------------------------------------#
# This file is part of Pyccel which is released under MIT License. See the LICENSE file or #
# go to https://github.com/pyccel/pyccel/blob/devel/LICENSE for full license details.      #
#------------------------------------------------------------------------------------------#
""" Module containing scripts to handle the pyccel compile sub-command.
"""

import argparse
import pathlib
import sys

from .argparse_helpers import add_compiler_selection, add_accelerator_selection
    # TODO: Uncomment for v2.3 to check for existence and file type
#from .argparse_helpers import path_with_suffix, add_common_settings
from .argparse_helpers import add_common_settings
from .pyccel_config import pyccel_config

__all__ = ('pyccel_compile',
           'setup_pyccel_compile_parser',
           'PYCCEL_COMPILE_DESCR')

PYCCEL_COMPILE_DESCR = 'Translate and compile a single Python file.'

def setup_pyccel_compile_parser(parser):
    """
    Add the `pyccel compile` arguments to the parser.

    Add the `pyccel compile` arguments to the parser for command line arguments.

    Parameters
    ----------
    parser : argparse.ArgumentParser
        The parser to be modified.
    """
    # ... Positional arguments
    group = parser.add_argument_group('Positional arguments')

    # TODO: Uncomment for v2.3 to check for existence and file type
    #group.add_argument('filename', metavar='FILE', path_with_suffix(('.py',)),
    group.add_argument('filename', metavar='FILE', type=pathlib.Path,
                        help='Path (relative or absolute) to the Python file to be translated.')
    # ...

    # ... backend compiler options
    group = parser.add_argument_group('Backend selection')

    group.add_argument('--language', choices=('Fortran', 'C', 'Python'), default='Fortran',
                       help='Target language for translation, i.e. the main language of the generated code (default: Fortran).',
                       type=str.title)

    # ... Compiler options
    add_compiler_selection(parser)

    # ... compiler syntax, semantic and codegen
    group = parser.add_argument_group('Pyccel compiling stages')
    group.add_argument('-x', '--syntax-only', action='store_true',
                       help='Stop Pyccel after syntactic parsing, before semantic analysis or code generation.')
    group.add_argument('-e', '--semantic-only', action='store_true',
                       help='Stop Pyccel after semantic analysis, before code generation.')
    group.add_argument('-t', '--convert-only', action='store_true',
                       help='Stop Pyccel after translation to the target language, before build.')
    # ...

    # ... Additional compiler options
    group = parser.add_argument_group('Additional compiler options')
    group.add_argument('--flags', type=str, \
                       help='Additional compiler flags.')
    group.add_argument('--wrapper-flags', type=str, \
                       help='Additional compiler flags for the wrapper.')
    group.add_argument('--debug', action=argparse.BooleanOptionalAction, default=None,
                        help='Compile the code with debug flags, or not.\n' \
                        ' Overrides the environment variable PYCCEL_DEBUG_MODE, if it exists. Otherwise default is False.')
    group.add_argument('--include',
                        type=str,
                        nargs='*',
                        dest='include',
                        default=(),
                        help='Additional include directories.')
    group.add_argument('--libdir',
                        type=str,
                        nargs='*',
                        dest='libdir',
                        default=(),
                        help='Additional library directories.')
    group.add_argument('--libs',
                        type=str,
                        nargs='*',
                        dest='libs',
                        default=(),
                        help='Additional libraries to link with.')
    group.add_argument('--output', type=pathlib.Path, default = None,\
                       help="Folder in which the output is stored (default: FILE's folder).")
    # ...

    # ... Accelerators
    add_accelerator_selection(parser)
    # ...

    # ... Other options
    group = parser.add_argument_group('Other options')
    add_common_settings(group)
    group.add_argument('--export-compiler-config', action='store_true',
                        help='Export all compiler information to a JSON file with the given path (relative or absolute). '
                       'This flag is deprecated and will be removed in v2.3. Please use `pyccel config` instead.')
    # ...


def pyccel_compile(*, filename, language, output, export_compiler_config, **kwargs):
    """
    Call the pyccel pipeline.

    Handle the deprecated --export-compiler-config command and call the pyccel pipeline.

    Parameters
    ----------
    filename : Path
        Name of the Python file to be translated.
    language : str
        The target language Pyccel is translating to.
    output : str
        Path to the working directory.
    export_compiler_config : bool
        Indicates if compiler information should be exported.
    **kwargs : dict
        See execute_pyccel.
    """
    # Imports
    from pyccel.errors.errors     import Errors
    from pyccel.codegen.pipeline  import execute_pyccel

    errors = Errors()
    # ...
    # To be removed with v2.3
    # ...
    cext = filename.suffix
    if export_compiler_config:
        print("Warning: The flag --export-compiler-config is deprecated and will be removed in v2.3. Please use `pyccel config` instead.", file=sys.stderr)
        if cext == '':
            filename = filename.with_suffix('.json')
            cext = '.json'
        if cext != '.json':
            # severity is error to avoid needing to catch exception
            errors.report('Wrong file extension. Expecting `json`, but found',
                          symbol=cext,
                          severity='error')
        else:
            pyccel_config(filename)
            execute_pyccel('',
                           compiler_family = kwargs['compiler_family'],
                           compiler_export_file = filename)
            sys.exit(0)
    elif cext != '.py':
        # severity is error to avoid needing to catch exception
        errors.report('Wrong file extension. Expecting `py`, but found',
                      symbol=cext,
                      severity='error')
    # ...
    if not filename.is_file():
        errors.report(f"File not found: {filename}", severity='error')

    if language == 'Python' and output == '':
        errors.report("Cannot output Python file to same folder as this would overwrite the original file. Please specify --output",
                      severity='error')

    if errors.has_errors():
        print(errors, end='')
        sys.exit(1)

    execute_pyccel(str(filename),
                   language        = language.lower(),
                   folder          = output or filename.parent,
                   **kwargs)
