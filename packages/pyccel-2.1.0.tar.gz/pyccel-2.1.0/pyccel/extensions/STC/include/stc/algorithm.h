#ifndef STC_ALGORITHM_H_INCLUDED
#define STC_ALGORITHM_H_INCLUDED

// IWYU pragma: begin_exports
#include "sys/crange.h"
#include "sys/filter.h"
#include "sys/utility.h"
#include "sys/sumtype.h"
// IWYU pragma: end_exports

#endif // STC_ALGORITHM_H_INCLUDED
