#define STC_IMPLEMENT
#include "../include/stc/coroutine.h"
