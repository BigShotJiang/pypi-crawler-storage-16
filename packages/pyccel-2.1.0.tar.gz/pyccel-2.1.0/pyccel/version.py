"""
Module specifying the current version string for pyccel
"""
__version__ = "2.1.0"
