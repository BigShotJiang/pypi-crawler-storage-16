"""
Test configuration and fixtures for pycensuskr tests.
"""
