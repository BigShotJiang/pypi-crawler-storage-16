"""
Entry point for running pystruct as a module: python -m pystruct
"""

from pyclassstruct.cli import main

if __name__ == "__main__":
    main()
