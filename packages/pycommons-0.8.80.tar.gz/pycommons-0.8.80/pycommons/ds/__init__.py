"""Some common and shared data structures."""
