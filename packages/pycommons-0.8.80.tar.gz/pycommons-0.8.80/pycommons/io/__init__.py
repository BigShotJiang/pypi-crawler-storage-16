"""Common utilities for input and output."""
