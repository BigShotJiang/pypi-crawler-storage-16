.. mdinclude:: ../README.md

.. toctree::
   :maxdepth: 2
   :hidden:
   :caption: Contents:

   CHANGELOG
   reference/pyconverters_mistralocr
