# Copyright (c) Paillat-dev
# SPDX-License-Identifier: MIT
from .app import App, ApplicationAuthorizedEvent

Bot = App

__all__ = ["App", "ApplicationAuthorizedEvent", "Bot"]
