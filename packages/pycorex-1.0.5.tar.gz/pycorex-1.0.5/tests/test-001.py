import libcore_hng.testmodule as tm

def libcore_test():
    msg = tm.test_function()
    print(msg)

libcore_test()
