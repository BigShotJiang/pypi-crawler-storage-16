from .setting import __version__, __author__, __email__, __description__

__all__ = ['__version__', '__author__', '__email__', '__description__']
