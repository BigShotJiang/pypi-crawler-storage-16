# version
__version__ = '2.2.0'
# author
__author__ = 'Sina Gilassi'
# email
__email__ = 'sina.gilassi@gmail.com'
# description
__description__ = 'PyCUC: A lightweight Python package for creating custom unit conversions.'
