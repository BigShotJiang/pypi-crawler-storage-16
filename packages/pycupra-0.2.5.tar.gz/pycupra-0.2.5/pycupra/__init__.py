"""
pycupra - A Python 3 library for interacting with the Cupra/Seat Connect portal.

For more details and documentation, visit the github page at https://github.com/WulfgarW/pycupra
"""

from pycupra.connection import Connection

