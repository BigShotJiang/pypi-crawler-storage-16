pycvcam.distort_image
==================================

.. autofunction:: pycvcam.distort_image