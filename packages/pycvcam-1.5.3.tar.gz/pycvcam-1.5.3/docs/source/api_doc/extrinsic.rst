pycvcam.core.Extrinsic
=============================

.. autoclass:: pycvcam.core.Extrinsic
    :members:
    :undoc-members:
    :private-members:
    :show-inheritance:


