pycvcam.optimize.optimize_input_points
=============================================

.. autofunction:: pycvcam.optimize.optimize_input_points.optimize_input_points