pycvcam.OrthographicExtrinsic
=============================

.. autoclass:: pycvcam.OrthographicExtrinsic
    :members:
    :undoc-members:
    :private-members:
    :show-inheritance: