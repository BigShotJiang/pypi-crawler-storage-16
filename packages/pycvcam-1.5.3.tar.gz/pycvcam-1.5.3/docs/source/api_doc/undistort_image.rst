pycvcam.undistort_image
==================================

.. autofunction:: pycvcam.undistort_image