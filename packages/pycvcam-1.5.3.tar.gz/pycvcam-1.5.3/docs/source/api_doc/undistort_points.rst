pycvcam.undistort_points
==================================

.. autofunction:: pycvcam.undistort_points