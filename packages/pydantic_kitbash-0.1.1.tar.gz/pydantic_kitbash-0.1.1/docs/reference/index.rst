.. _reference:

Reference
=========

.. toctree::
   :maxdepth: 1

Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
