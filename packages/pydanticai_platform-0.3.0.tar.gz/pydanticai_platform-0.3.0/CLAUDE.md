# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Build & Development Commands

```bash
# Install dependencies (use uv - recommended)
uv sync

# Or with pip
pip install -e ".[dev]"

# Run tests
pytest
pytest --cov=my_app                    # with coverage
pytest tests/agents/test_research.py -v  # single file

# Linting and type checking
ruff check src tests
ruff format src tests
mypy src

# Run the API server
my-app serve
my-app serve --reload                  # with hot reload
uvicorn my_app.api.app:app --reload    # direct uvicorn

# CLI commands
my-app chat                            # interactive mode
my-app query "your question"           # single query
```

## Architecture

### Multi-Agent System

Router-based delegation pattern where `router_agent` analyzes requests and delegates to specialized agents:

- **Router** (`agents/router.py`): Lightweight gpt-4o-mini model for routing decisions
- **Specialists**: Research, Analyst, Code, Writer, Support - each with domain-specific tools and output models

Agents are module-level singletons with typed deps and outputs:
```python
research_agent: Agent[SearchDeps, ResearchResult] = Agent(...)
```

### Tool Composition with Toolsets

Tools are organized into `FunctionToolset`s and combined using `CombinedToolset` with prefixes:

```python
# In toolsets/research.py
research_toolset = CombinedToolset([
    web_search_toolset.prefixed("web"),    # tools become web_search, web_fetch_webpage
    vector_search_toolset.prefixed("kb"),  # tools become kb_search_documents
    common_toolset,                        # no prefix
])
```

Tools receive typed context via `RunContext[DepsType]` to access dependencies.

### Dependency Injection

Dataclass-based DI with protocol abstractions (`dependencies/base.py`):

- `BaseDeps`: Core infrastructure (http_client, db, cache, user_id)
- `SearchDeps(BaseDeps)`: Adds vector_store, search_api_key
- `AuthDeps(BaseDeps)`: Adds user_roles, permissions

When delegating between agents, convert deps to match target agent's requirements.

### Structured Outputs

All agents return Pydantic models (`models/`):
- `ResearchResult`: answer, sources, confidence, follow_up_questions
- `AnalysisResult`: summary, confidence, data_points, recommendations
- Models have helper methods like `format_with_sources()`

## Testing Patterns

Use `TestModel` for deterministic agent testing without API calls:

```python
from pydantic_ai.models.test import TestModel

async def test_agent():
    with research_agent.override(model=test_model):
        result = await research_agent.run("query", deps=deps)
```

Fixtures in `tests/conftest.py` provide mocked dependencies (`base_deps`, `search_deps`, `auth_deps`).

## Key Conventions

- Tools access deps via `ctx.deps.property`, never global state
- Pass `usage=ctx.usage` when delegating to sub-agents for cost tracking
- Use `Agent.override()` context manager for testing/model swapping
- pytest runs with `asyncio_mode = "auto"` - async tests work without decorators
