"""John Pye auction tracking example."""
