"""Toolset for John Pye agent."""

from pydantic_ai.toolsets import CombinedToolset

from pydanticai_multiagent.tools.common import common_toolset
from pydanticai_multiagent.tools.johnpye import johnpye_toolset

# Combine John Pye invoice tools with common utilities (datetime, formatting)
johnpye_combined_toolset = CombinedToolset(
    [
        johnpye_toolset,
        common_toolset,
    ]
)
