"""Output models for multi-agent example."""

from .outputs import (
    AnalysisResult,
    CodeResponse,
    DataPoint,
    ResearchResult,
    SupportResponse,
)

__all__ = [
    "AnalysisResult",
    "CodeResponse",
    "DataPoint",
    "ResearchResult",
    "SupportResponse",
]
