"""Structured output models for multi-agent example."""

from pydantic import BaseModel, Field


class DataPoint(BaseModel):
    """A single data point for analysis."""

    label: str
    value: float
    metadata: dict[str, str] = {}


class ResearchResult(BaseModel):
    """Output from the research agent."""

    answer: str = Field(description="The researched answer")
    sources: list[str] = Field(description="URLs or references used")
    confidence: float = Field(ge=0, le=1, default=0.8)
    follow_up_questions: list[str] = Field(
        default_factory=list, description="Suggested follow-up questions"
    )

    def format_with_sources(self) -> str:
        """Format the answer with source citations."""
        sources_text = "\n".join(f"- {s}" for s in self.sources)
        return f"{self.answer}\n\nSources:\n{sources_text}"


class AnalysisResult(BaseModel):
    """Output from the analyst agent."""

    summary: str = Field(description="Brief summary of the analysis")
    confidence: float = Field(ge=0, le=1, description="Confidence score 0-1")
    data_points: list[DataPoint] = Field(default_factory=list)
    recommendations: list[str] = Field(default_factory=list)
    methodology: str | None = Field(default=None, description="How the analysis was performed")


class CodeResponse(BaseModel):
    """Structured response from code agent."""

    explanation: str = Field(description="Explanation of the solution or answer")
    code: str | None = Field(default=None, description="Code snippet if applicable")
    language: str | None = Field(default=None, description="Programming language of the code")
    suggestions: list[str] = Field(
        default_factory=list, description="Additional suggestions or improvements"
    )


class SupportResponse(BaseModel):
    """Structured response from support agent."""

    answer: str = Field(description="The response to the customer")
    category: str = Field(description="Issue category (billing, technical, general, etc.)")
    sentiment: str = Field(description="Customer sentiment (positive, neutral, frustrated)")
    escalate: bool = Field(default=False, description="Whether to escalate to human support")
    escalation_reason: str | None = Field(
        default=None, description="Reason for escalation if applicable"
    )
    follow_up_actions: list[str] = Field(
        default_factory=list, description="Suggested follow-up actions"
    )
