"""Composed toolsets for multi-agent example."""

from .compositions import analyst_toolset, research_toolset, support_toolset

__all__ = [
    "analyst_toolset",
    "research_toolset",
    "support_toolset",
]
