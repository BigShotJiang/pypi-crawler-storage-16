"""Tool compositions for each specialist agent.

These toolsets demonstrate how to combine tools with prefixes
to create agent-specific tool collections.
"""

from pydantic_ai.toolsets import CombinedToolset

# Import tools from the main package infrastructure
from pydanticai_multiagent.tools.common import common_toolset
from pydanticai_multiagent.tools.data.analysis import analysis_toolset
from pydanticai_multiagent.tools.data.export import export_toolset
from pydanticai_multiagent.tools.data.visualization import visualization_toolset
from pydanticai_multiagent.tools.external.email import email_toolset
from pydanticai_multiagent.tools.external.slack import slack_toolset
from pydanticai_multiagent.tools.search.database import db_search_toolset
from pydanticai_multiagent.tools.search.vector import vector_search_toolset
from pydanticai_multiagent.tools.search.web import web_search_toolset

# Research toolset: web search + knowledge base + common utilities
research_toolset = CombinedToolset(
    [
        web_search_toolset.prefixed("web"),
        vector_search_toolset.prefixed("kb"),
        common_toolset,
    ]
)

# Analyst toolset: database + analysis + visualization + export
analyst_toolset = CombinedToolset(
    [
        db_search_toolset.prefixed("db"),
        analysis_toolset.prefixed("stats"),
        visualization_toolset.prefixed("viz"),
        export_toolset.prefixed("export"),
        common_toolset,
    ]
)

# Support toolset: database + communication channels
# Note: Uses AuthDeps, so vector_search is not available
support_toolset = CombinedToolset(
    [
        db_search_toolset.prefixed("db"),
        slack_toolset.prefixed("slack"),
        email_toolset.prefixed("email"),
        common_toolset,
    ]
)
