# Starter Examples

Minimal examples showing how to use pydanticai-multiagent.

## Quick Start

```bash
pip install pydanticai-multiagent
```

## Examples

### 1. Basic Usage (`basic_usage.py`)

Use the built-in router agent with mock dependencies:

```python
import asyncio
from pydanticai_multiagent import router_agent, create_mock_search_deps

async def main():
    deps = create_mock_search_deps()
    result = await router_agent.run("What is Python?", deps=deps)
    print(result.output)

asyncio.run(main())
```

### 2. Custom Agent (`custom_agent.py`)

Create your own agent with typed dependencies, tools, and structured outputs.

### 3. Dynamic Tools (`dynamic_tools.py`)

Extend the router with domain-specific tools at runtime using `deps.domain_toolset`:

```python
from pydantic_ai.toolsets import FunctionToolset
from pydanticai_multiagent import router_agent, create_mock_search_deps, SearchDeps

# Create domain-specific tools
my_toolset: FunctionToolset[SearchDeps] = FunctionToolset()

@my_toolset.tool
async def my_custom_tool(ctx, query: str) -> str:
    """Your custom tool."""
    return f"Result for {query}"

# Inject into router
deps = create_mock_search_deps()
deps.domain_toolset = my_toolset

result = await router_agent.run("Use my custom tool", deps=deps)
```

This is the recommended pattern for adding custom functionality without modifying framework code.
