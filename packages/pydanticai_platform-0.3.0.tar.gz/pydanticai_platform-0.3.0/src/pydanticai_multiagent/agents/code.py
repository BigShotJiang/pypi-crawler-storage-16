"""Code assistant agent for programming help."""

from pydantic import BaseModel, Field
from pydantic_ai import Agent

from pydanticai_multiagent.dependencies import BaseDeps
from pydanticai_multiagent.tools.common import common_toolset
from pydanticai_multiagent.tools.external.github import github_toolset


class CodeResponse(BaseModel):
    """Structured response from code agent."""

    explanation: str = Field(description="Explanation of the solution or answer")
    code: str | None = Field(default=None, description="Code snippet if applicable")
    language: str | None = Field(default=None, description="Programming language of the code")
    suggestions: list[str] = Field(
        default_factory=list, description="Additional suggestions or improvements"
    )


code_agent: Agent[BaseDeps, CodeResponse] = Agent(
    "openai:gpt-4o",
    deps_type=BaseDeps,
    output_type=CodeResponse,
    toolsets=[github_toolset, common_toolset],
    instructions="""You are an expert programming assistant.

Your responsibilities:
1. Answer programming questions with clear explanations
2. Write clean, efficient, and well-documented code
3. Debug and fix code issues
4. Review code and suggest improvements
5. Explain complex concepts in accessible terms

Languages you specialize in:
- Python, JavaScript/TypeScript, Go, Rust
- SQL, Shell scripting
- HTML/CSS

Guidelines:
- Always explain your reasoning, not just provide code
- Follow best practices and coding standards
- Consider edge cases and error handling
- Suggest tests when appropriate
- Use type hints and documentation
- Prioritize readability and maintainability
- Reference official documentation when relevant
""",
)
