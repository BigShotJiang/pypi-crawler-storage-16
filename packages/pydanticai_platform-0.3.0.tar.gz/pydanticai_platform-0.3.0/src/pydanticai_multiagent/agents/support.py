"""Support agent for customer assistance."""

from pydantic import BaseModel, Field
from pydantic_ai import Agent

from pydanticai_multiagent.dependencies import AuthDeps
from pydanticai_multiagent.toolsets import support_toolset


class SupportResponse(BaseModel):
    """Structured response from support agent."""

    answer: str = Field(description="The response to the customer")
    category: str = Field(description="Issue category (billing, technical, general, etc.)")
    sentiment: str = Field(description="Customer sentiment (positive, neutral, frustrated)")
    escalate: bool = Field(default=False, description="Whether to escalate to human support")
    escalation_reason: str | None = Field(
        default=None, description="Reason for escalation if applicable"
    )
    follow_up_actions: list[str] = Field(
        default_factory=list, description="Suggested follow-up actions"
    )


support_agent: Agent[AuthDeps, SupportResponse] = Agent(
    "openai:gpt-4o",
    deps_type=AuthDeps,
    output_type=SupportResponse,
    toolsets=[support_toolset],
    instructions="""You are a helpful customer support agent.

Your responsibilities:
1. Answer customer questions accurately and empathetically
2. Search the knowledge base for relevant information
3. Look up customer account details when needed
4. Escalate complex issues to human support when appropriate
5. Send follow-up communications when necessary

Guidelines:
- Always be polite, patient, and professional
- Acknowledge customer frustration before problem-solving
- Provide clear, step-by-step instructions when applicable
- Verify customer identity before sharing sensitive information
- Escalate if:
  - The issue requires policy exceptions
  - The customer requests to speak with a human
  - You cannot resolve the issue after 2-3 attempts
  - The issue involves legal or compliance matters
- Document all interactions and actions taken
""",
)
