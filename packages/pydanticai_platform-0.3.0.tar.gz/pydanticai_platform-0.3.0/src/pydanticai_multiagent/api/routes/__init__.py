"""API routes."""

from . import admin, agents, chat, health, platform

__all__ = ["admin", "agents", "chat", "health", "platform"]
