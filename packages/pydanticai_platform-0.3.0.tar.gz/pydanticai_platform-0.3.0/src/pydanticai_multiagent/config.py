"""Application configuration."""

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    # API Keys
    openai_api_key: str = ""
    anthropic_api_key: str = ""

    # Database
    database_url: str = "postgresql://localhost:5432/myapp"

    # Supabase
    supabase_url: str = ""
    supabase_anon_key: str = ""
    supabase_service_key: str = ""

    # Redis
    redis_url: str = "redis://localhost:6379"
    redis_enabled: bool = False  # Enable Redis for distributed rate limiting

    # Search
    search_api_key: str = ""

    # Application
    debug: bool = False
    log_level: str = "INFO"

    # Security
    secret_key: str = "change-me-in-production"  # For JWT/auth token validation

    # Rate Limiting
    rate_limit_requests_per_minute: int = 60
    rate_limit_burst_size: int = 10

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}


settings = Settings()
