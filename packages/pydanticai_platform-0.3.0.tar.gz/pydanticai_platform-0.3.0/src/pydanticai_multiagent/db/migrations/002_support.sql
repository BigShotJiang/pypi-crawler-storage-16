-- Support Agent - Email Drafts
-- Migration: 002_support.sql

CREATE TABLE email_drafts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT NOT NULL,
    recipient TEXT NOT NULL,
    subject TEXT NOT NULL,
    body TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    sent_at TIMESTAMPTZ  -- NULL until sent
);

CREATE INDEX idx_drafts_user ON email_drafts(user_id, created_at DESC);
