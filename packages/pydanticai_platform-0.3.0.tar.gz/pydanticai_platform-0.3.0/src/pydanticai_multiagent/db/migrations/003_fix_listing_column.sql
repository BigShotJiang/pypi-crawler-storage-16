-- Fix column name mismatch: listing_url -> listing_id
-- Migration: 003_fix_listing_column.sql
-- Note: This is a no-op for fresh installs where 001 already uses listing_id

DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'johnpye_lot_items' AND column_name = 'listing_url'
    ) THEN
        ALTER TABLE johnpye_lot_items RENAME COLUMN listing_url TO listing_id;
    END IF;
END $$;
