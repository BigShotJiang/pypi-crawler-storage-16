"""Base dependencies shared across all agents."""

from dataclasses import dataclass
from typing import Any, Protocol


class DatabasePool(Protocol):
    """Protocol for database connections."""

    async def fetch_one(self, query: str, *args: Any) -> dict[str, Any] | None: ...
    async def fetch_all(self, query: str, *args: Any) -> list[dict[str, Any]]: ...
    async def execute(self, query: str, *args: Any) -> None: ...


class CacheClient(Protocol):
    """Protocol for cache operations."""

    async def get(self, key: str) -> str | None: ...
    async def set(self, key: str, value: str, ttl: int | None = None) -> None: ...
    async def delete(self, key: str) -> None: ...


class HttpClient(Protocol):
    """Protocol for HTTP client."""

    async def get(self, url: str, **kwargs: Any) -> Any: ...
    async def post(self, url: str, **kwargs: Any) -> Any: ...


@dataclass
class BaseDeps:
    """Base dependencies available to all agents.

    This dataclass provides the core infrastructure dependencies
    that most agents will need access to.

    Example:
        ```python
        async with AsyncClient() as client:
            deps = BaseDeps(
                http_client=client,
                db=database_pool,
                cache=redis_client,
                user_id="user-123"
            )
            result = await agent.run("query", deps=deps)
        ```
    """

    http_client: HttpClient
    db: DatabasePool
    cache: CacheClient
    user_id: str | None = None

    def with_user(self, user_id: str) -> "BaseDeps":
        """Create a copy with a specific user context."""
        return BaseDeps(
            http_client=self.http_client,
            db=self.db,
            cache=self.cache,
            user_id=user_id,
        )
