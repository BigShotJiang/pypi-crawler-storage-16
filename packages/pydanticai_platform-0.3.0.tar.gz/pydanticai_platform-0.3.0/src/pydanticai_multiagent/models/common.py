"""Common shared models."""

from datetime import datetime

from pydantic import BaseModel, Field


class Pagination(BaseModel):
    """Pagination parameters."""

    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=20, ge=1, le=100)
    total: int | None = None


class TimeRange(BaseModel):
    """Time range filter."""

    start: datetime
    end: datetime

    def contains(self, dt: datetime) -> bool:
        """Check if a datetime falls within this range."""
        return self.start <= dt <= self.end
