"""Common utility tools."""

from pydantic_ai.toolsets import CombinedToolset

from .datetime_tools import datetime_toolset
from .formatting import formatting_toolset

# Combined common toolset
common_toolset = CombinedToolset(
    [
        datetime_toolset,
        formatting_toolset,
    ]
)

__all__ = [
    "common_toolset",
    "datetime_toolset",
    "formatting_toolset",
]
