"""Toolset for analyst agent."""

from pydantic_ai.toolsets import CombinedToolset

from pydanticai_multiagent.tools.common import common_toolset
from pydanticai_multiagent.tools.data.analysis import analysis_toolset
from pydanticai_multiagent.tools.data.export import export_toolset
from pydanticai_multiagent.tools.data.visualization import visualization_toolset
from pydanticai_multiagent.tools.search.database import db_search_toolset

# Analyst toolset combines database, analysis, visualization, and export tools
analyst_toolset = CombinedToolset(
    [
        db_search_toolset.prefixed("db"),
        analysis_toolset.prefixed("stats"),
        visualization_toolset.prefixed("viz"),
        export_toolset.prefixed("export"),
        common_toolset,
    ]
)
