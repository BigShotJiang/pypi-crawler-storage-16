"""Toolset for research agent."""

from pydantic_ai.toolsets import CombinedToolset

from pydanticai_multiagent.tools.common import common_toolset
from pydanticai_multiagent.tools.search.vector import vector_search_toolset
from pydanticai_multiagent.tools.search.web import web_search_toolset

# Research toolset combines web search, knowledge base, and common tools
research_toolset = CombinedToolset(
    [
        web_search_toolset.prefixed("web"),
        vector_search_toolset.prefixed("kb"),
        common_toolset,
    ]
)
