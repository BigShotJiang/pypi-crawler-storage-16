"""Toolset for support agent."""

from pydantic_ai.toolsets import CombinedToolset

from pydanticai_multiagent.tools.common import common_toolset
from pydanticai_multiagent.tools.external.email import email_toolset
from pydanticai_multiagent.tools.external.slack import slack_toolset
from pydanticai_multiagent.tools.search.database import db_search_toolset

# Support toolset combines database and communication tools.
# Note: Uses AuthDeps (not SearchDeps), so vector_search is not available.
# The database search provides knowledge base functionality.
support_toolset = CombinedToolset(
    [
        db_search_toolset.prefixed("db"),
        slack_toolset.prefixed("slack"),
        email_toolset.prefixed("email"),
        common_toolset,
    ]
)
