"""Tests for the analyst agent."""

import pytest
from pydantic_ai.models.test import TestModel

from pydanticai_multiagent.agents.analyst import analyst_agent
from pydanticai_multiagent.dependencies import BaseDeps
from pydanticai_multiagent.models import AnalysisResult, DataPoint


@pytest.fixture
def test_model() -> TestModel:
    """Create a test model for deterministic testing."""
    return TestModel()


class TestAnalystAgent:
    """Tests for the analyst agent."""

    async def test_analyst_agent_returns_structured_output(
        self,
        base_deps: BaseDeps,
    ) -> None:
        """Test that analyst agent returns AnalysisResult."""
        test_model = TestModel()

        with analyst_agent.override(model=test_model):
            result = await analyst_agent.run(
                "Analyze sales data for Q1",
                deps=base_deps,
            )

            assert isinstance(result.output, AnalysisResult)
            assert result.output.summary is not None
            assert 0 <= result.output.confidence <= 1

    async def test_analyst_agent_has_tools(
        self,
        base_deps: BaseDeps,
    ) -> None:
        """Test that analyst agent has expected tools."""
        test_model = TestModel()

        with analyst_agent.override(model=test_model):
            await analyst_agent.run(
                "Query the database",
                deps=base_deps,
            )

            tools = test_model.last_model_request_parameters
            assert tools is not None
            assert len(tools.function_tools) > 0


class TestAnalysisModels:
    """Tests for analysis-related models."""

    def test_data_point_creation(self) -> None:
        """Test DataPoint model."""
        point = DataPoint(
            label="Revenue",
            value=1000000.0,
            metadata={"quarter": "Q1", "year": "2024"},
        )

        assert point.label == "Revenue"
        assert point.value == 1000000.0
        assert point.metadata["quarter"] == "Q1"

    def test_analysis_result_with_recommendations(self) -> None:
        """Test AnalysisResult with all fields."""
        result = AnalysisResult(
            summary="Sales increased by 15% in Q1",
            confidence=0.85,
            data_points=[
                DataPoint(label="Q1 Sales", value=1500000),
                DataPoint(label="Q4 Sales", value=1300000),
            ],
            recommendations=[
                "Continue marketing campaign",
                "Expand to new markets",
            ],
            methodology="Year-over-year comparison",
        )

        assert len(result.data_points) == 2
        assert len(result.recommendations) == 2
        assert result.methodology is not None

    def test_analysis_result_validation(self) -> None:
        """Test AnalysisResult validation."""
        # Confidence must be between 0 and 1
        with pytest.raises(ValueError):
            AnalysisResult(
                summary="Test",
                confidence=1.5,  # Invalid
            )
