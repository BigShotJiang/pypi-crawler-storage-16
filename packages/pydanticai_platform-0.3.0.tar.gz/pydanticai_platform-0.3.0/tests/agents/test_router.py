"""Tests for the router agent."""

import pytest
from pydantic_ai.models.test import TestModel

from pydanticai_multiagent.agents.router import router_agent
from pydanticai_multiagent.dependencies import SearchDeps


@pytest.fixture
def test_model() -> TestModel:
    """Create a test model for deterministic testing."""
    return TestModel()


class TestRouterAgent:
    """Tests for the router agent."""

    async def test_router_agent_has_delegation_tools(
        self,
        search_deps: SearchDeps,
    ) -> None:
        """Test that router agent has delegation tools."""
        test_model = TestModel()

        with router_agent.override(model=test_model):
            await router_agent.run(
                "Help me with a task",
                deps=search_deps,
            )

            tools = test_model.last_model_request_parameters
            assert tools is not None

            # Get tool names
            tool_names = [t.name for t in tools.function_tools]

            # Router should have delegation tools
            assert "delegate_to_research" in tool_names
            assert "delegate_to_analyst" in tool_names
            assert "delegate_to_code" in tool_names
            assert "delegate_to_writer" in tool_names
            assert "delegate_to_support" in tool_names

    async def test_router_returns_string_output(
        self,
        search_deps: SearchDeps,
    ) -> None:
        """Test that router agent returns string output."""
        test_model = TestModel()

        with router_agent.override(model=test_model):
            result = await router_agent.run(
                "What is the weather?",
                deps=search_deps,
            )

            # Router returns string (summarized from delegates)
            assert isinstance(result.output, str)
