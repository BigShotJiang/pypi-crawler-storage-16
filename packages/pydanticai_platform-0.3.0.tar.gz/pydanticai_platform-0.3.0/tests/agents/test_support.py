"""Tests for the support agent."""

from pydantic_ai.models.test import TestModel

from pydanticai_multiagent.agents.support import SupportResponse, support_agent
from pydanticai_multiagent.dependencies import AuthDeps


class TestSupportAgent:
    """Tests for the support agent."""

    async def test_support_agent_returns_structured_output(
        self,
        auth_deps: AuthDeps,
    ) -> None:
        """Test that support agent returns SupportResponse."""
        test_model = TestModel()

        with support_agent.override(model=test_model):
            result = await support_agent.run(
                "I can't login to my account",
                deps=auth_deps,
            )

            assert isinstance(result.output, SupportResponse)
            assert result.output.answer is not None
            assert result.output.category is not None
            assert result.output.sentiment is not None

    async def test_support_agent_has_tools(
        self,
        auth_deps: AuthDeps,
    ) -> None:
        """Test that support agent has access to expected tools."""
        test_model = TestModel()

        with support_agent.override(model=test_model):
            await support_agent.run(
                "What is my account balance?",
                deps=auth_deps,
            )

            tools = test_model.last_model_request_parameters
            assert tools is not None
            assert len(tools.function_tools) > 0


class TestSupportResponse:
    """Tests for SupportResponse model."""

    def test_support_response_minimal(self) -> None:
        """Test SupportResponse with required fields only."""
        response = SupportResponse(
            answer="I can help you with that.",
            category="general",
            sentiment="neutral",
        )

        assert response.answer == "I can help you with that."
        assert response.category == "general"
        assert response.sentiment == "neutral"
        assert response.escalate is False
        assert response.escalation_reason is None
        assert response.follow_up_actions == []

    def test_support_response_with_escalation(self) -> None:
        """Test SupportResponse with escalation."""
        response = SupportResponse(
            answer="I understand your concern. Let me connect you with a specialist.",
            category="billing",
            sentiment="frustrated",
            escalate=True,
            escalation_reason="Customer requests refund exception",
            follow_up_actions=["Review account history", "Prepare refund documentation"],
        )

        assert response.escalate is True
        assert response.escalation_reason == "Customer requests refund exception"
        assert len(response.follow_up_actions) == 2

    def test_support_response_categories(self) -> None:
        """Test various category values."""
        categories = ["billing", "technical", "general", "account", "security"]

        for category in categories:
            response = SupportResponse(
                answer="Test",
                category=category,
                sentiment="neutral",
            )
            assert response.category == category

    def test_support_response_sentiments(self) -> None:
        """Test various sentiment values."""
        sentiments = ["positive", "neutral", "frustrated"]

        for sentiment in sentiments:
            response = SupportResponse(
                answer="Test",
                category="general",
                sentiment=sentiment,
            )
            assert response.sentiment == sentiment
