"""Tests for the writer agent."""

from pydantic_ai.models.test import TestModel

from pydanticai_multiagent.agents.writer import writer_agent
from pydanticai_multiagent.dependencies import BaseDeps


class TestWriterAgent:
    """Tests for the writer agent."""

    async def test_writer_agent_returns_string(
        self,
        base_deps: BaseDeps,
    ) -> None:
        """Test that writer agent returns string output."""
        test_model = TestModel()

        with writer_agent.override(model=test_model):
            result = await writer_agent.run(
                "Write a blog post about AI",
                deps=base_deps,
            )

            assert isinstance(result.output, str)
            assert len(result.output) > 0

    async def test_writer_agent_has_tools(
        self,
        base_deps: BaseDeps,
    ) -> None:
        """Test that writer agent has access to expected tools."""
        test_model = TestModel()

        with writer_agent.override(model=test_model):
            await writer_agent.run(
                "Create marketing copy for a product",
                deps=base_deps,
            )

            tools = test_model.last_model_request_parameters
            assert tools is not None
            # Writer has common toolset
            assert len(tools.function_tools) > 0

    async def test_writer_agent_with_context(
        self,
        base_deps: BaseDeps,
    ) -> None:
        """Test writer agent handles context in prompts."""
        test_model = TestModel()

        with writer_agent.override(model=test_model):
            prompt = """Write an email announcement

Context: We are launching a new AI product next week.
Target audience: Technical developers."""

            result = await writer_agent.run(prompt, deps=base_deps)

            assert isinstance(result.output, str)
