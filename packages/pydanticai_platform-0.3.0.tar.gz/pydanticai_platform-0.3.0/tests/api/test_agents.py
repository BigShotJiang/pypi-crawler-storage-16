"""Tests for agent API endpoints."""

import pytest
from fastapi.testclient import TestClient

from pydanticai_multiagent.api.app import create_app


@pytest.fixture
def client() -> TestClient:
    """Create test client."""
    app = create_app()
    return TestClient(app)


class TestAgentEndpoints:
    """Tests for agent API endpoints."""

    def test_list_agents(self, client: TestClient) -> None:
        """Test listing available agents."""
        response = client.get("/api/v1/agents/")

        assert response.status_code == 200
        data = response.json()
        assert "agents" in data
        agent_names = [a["name"] for a in data["agents"]]
        assert "research" in agent_names
        assert "analyze" in agent_names
        assert "code" in agent_names
        assert "write" in agent_names
        assert "support" in agent_names

    def test_list_agents_has_endpoints(self, client: TestClient) -> None:
        """Test that all listed agents have endpoint info."""
        response = client.get("/api/v1/agents/")

        data = response.json()
        for agent in data["agents"]:
            assert "name" in agent
            assert "description" in agent
            assert "endpoint" in agent
            assert agent["endpoint"].startswith("/api/v1/agents/")
