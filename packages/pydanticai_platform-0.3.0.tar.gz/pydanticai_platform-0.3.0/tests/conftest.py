"""Shared test fixtures."""


import pytest

from pydanticai_multiagent.dependencies import AuthDeps, BaseDeps, SearchDeps
from pydanticai_multiagent.dependencies.mocks import (
    MockCache,
    MockDatabase,
    MockHttpClient,
    MockVectorStore,
)


@pytest.fixture
def mock_http_client() -> MockHttpClient:
    """Mock HTTP client for testing.

    Uses the production MockHttpClient which has realistic API responses
    for GitHub, Slack, and other external services.
    """
    return MockHttpClient()


@pytest.fixture
def mock_db() -> MockDatabase:
    """Mock database pool for testing.

    Uses the production MockDatabase which has sample users, orders,
    and supports common query patterns.
    """
    return MockDatabase()


@pytest.fixture
def mock_cache() -> MockCache:
    """Mock cache client for testing."""
    return MockCache()


@pytest.fixture
def mock_vector_store() -> MockVectorStore:
    """Mock vector store for testing.

    Uses the production MockVectorStore which has sample documents
    and supports semantic search simulation.
    """
    return MockVectorStore()


@pytest.fixture
def base_deps(
    mock_http_client: MockHttpClient,
    mock_db: MockDatabase,
    mock_cache: MockCache,
) -> BaseDeps:
    """Create BaseDeps with mocked dependencies."""
    return BaseDeps(
        http_client=mock_http_client,
        db=mock_db,
        cache=mock_cache,
        user_id="test-user-123",
    )


@pytest.fixture
def search_deps(
    mock_http_client: MockHttpClient,
    mock_db: MockDatabase,
    mock_cache: MockCache,
    mock_vector_store: MockVectorStore,
) -> SearchDeps:
    """Create SearchDeps with mocked dependencies."""
    return SearchDeps(
        http_client=mock_http_client,
        db=mock_db,
        cache=mock_cache,
        vector_store=mock_vector_store,
        search_api_key="test-api-key",
        user_id="test-user-123",
    )


@pytest.fixture
def auth_deps(
    mock_http_client: MockHttpClient,
    mock_db: MockDatabase,
    mock_cache: MockCache,
) -> AuthDeps:
    """Create AuthDeps with mocked dependencies."""
    return AuthDeps(
        http_client=mock_http_client,
        db=mock_db,
        cache=mock_cache,
        user_id="test-user-123",
        user_roles=["user", "analyst"],
        permissions=["read:data", "write:reports"],
    )
