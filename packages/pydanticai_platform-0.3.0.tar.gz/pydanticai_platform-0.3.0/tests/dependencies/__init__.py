"""Tests for dependencies module."""
