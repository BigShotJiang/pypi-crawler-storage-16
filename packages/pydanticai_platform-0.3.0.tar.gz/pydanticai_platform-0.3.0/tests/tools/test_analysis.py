"""Tests for data analysis tools."""


from pydanticai_multiagent.tools.data.analysis import (
    analyze_trend,
    calculate_percentiles,
    calculate_statistics,
    detect_outliers,
)


class TestCalculateStatistics:
    """Tests for calculate_statistics tool."""

    def test_basic_statistics(self) -> None:
        """Test basic statistical calculations."""
        data = [1.0, 2.0, 3.0, 4.0, 5.0]
        result = calculate_statistics(data)

        assert "Count: 5" in result
        assert "Mean: 3.00" in result
        assert "Median: 3.00" in result
        assert "Min: 1.00" in result
        assert "Max: 5.00" in result

    def test_empty_data(self) -> None:
        """Test with empty dataset."""
        result = calculate_statistics([])
        assert "Error" in result

    def test_single_value(self) -> None:
        """Test with single value."""
        result = calculate_statistics([42.0])
        assert "Single value: 42.0" in result


class TestCalculatePercentiles:
    """Tests for calculate_percentiles tool."""

    def test_default_percentiles(self) -> None:
        """Test default percentile calculations."""
        data = list(range(1, 101))  # 1 to 100
        result = calculate_percentiles([float(x) for x in data])

        assert "P25:" in result
        assert "P50:" in result
        assert "P75:" in result
        assert "P90:" in result
        assert "P95:" in result

    def test_custom_percentiles(self) -> None:
        """Test custom percentiles."""
        data = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0]
        result = calculate_percentiles(data, percentiles=[10, 50, 90])

        assert "P10:" in result
        assert "P50:" in result
        assert "P90:" in result

    def test_empty_data(self) -> None:
        """Test with empty dataset."""
        result = calculate_percentiles([])
        assert "Error" in result


class TestDetectOutliers:
    """Tests for detect_outliers tool."""

    def test_iqr_method_with_outliers(self) -> None:
        """Test IQR method detects outliers."""
        # Data with obvious outliers
        data = [1.0, 2.0, 3.0, 4.0, 5.0, 100.0]
        result = detect_outliers(data, method="iqr")

        assert "100" in result or "outlier" in result.lower()

    def test_iqr_method_no_outliers(self) -> None:
        """Test IQR method with clean data."""
        data = [1.0, 2.0, 3.0, 4.0, 5.0]
        result = detect_outliers(data, method="iqr")

        assert "No outliers" in result

    def test_zscore_method(self) -> None:
        """Test Z-score method."""
        data = [1.0, 2.0, 3.0, 4.0, 5.0, 100.0]
        result = detect_outliers(data, method="zscore")

        assert "zscore" in result.lower()

    def test_insufficient_data(self) -> None:
        """Test with insufficient data points."""
        result = detect_outliers([1.0, 2.0, 3.0])
        assert "Error" in result

    def test_invalid_method(self) -> None:
        """Test with invalid method."""
        result = detect_outliers([1.0, 2.0, 3.0, 4.0, 5.0], method="invalid")
        assert "Error" in result or "Unknown" in result


class TestAnalyzeTrend:
    """Tests for analyze_trend tool."""

    def test_increasing_trend(self) -> None:
        """Test detection of increasing trend."""
        values = [1.0, 2.0, 3.0, 4.0, 5.0]
        result = analyze_trend(values)

        assert "increasing" in result.lower()

    def test_decreasing_trend(self) -> None:
        """Test detection of decreasing trend."""
        values = [5.0, 4.0, 3.0, 2.0, 1.0]
        result = analyze_trend(values)

        assert "decreasing" in result.lower()

    def test_stable_trend(self) -> None:
        """Test detection of stable trend."""
        values = [5.0, 5.0, 5.0, 5.0, 5.0]
        result = analyze_trend(values)

        assert "stable" in result.lower()

    def test_percent_change(self) -> None:
        """Test percent change calculation."""
        values = [100.0, 150.0]  # 50% increase
        result = analyze_trend(values)

        assert "50" in result  # Should show ~50% change

    def test_insufficient_data(self) -> None:
        """Test with single value."""
        result = analyze_trend([1.0])
        assert "Error" in result
