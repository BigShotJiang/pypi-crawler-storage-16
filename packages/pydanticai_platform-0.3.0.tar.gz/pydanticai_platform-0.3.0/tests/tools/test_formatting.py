"""Tests for formatting tools."""


from pydanticai_multiagent.tools.common.formatting import (
    clean_text,
    extract_keywords,
    format_as_bullet_list,
    format_number,
    truncate_text,
)


class TestFormatAsBulletList:
    """Tests for format_as_bullet_list tool."""

    def test_dash_style(self) -> None:
        """Test dash bullet style."""
        items = ["Item 1", "Item 2", "Item 3"]
        result = format_as_bullet_list(items, style="dash")

        assert "- Item 1" in result
        assert "- Item 2" in result
        assert "- Item 3" in result

    def test_asterisk_style(self) -> None:
        """Test asterisk bullet style."""
        items = ["A", "B"]
        result = format_as_bullet_list(items, style="asterisk")

        assert "* A" in result
        assert "* B" in result

    def test_numbered_style(self) -> None:
        """Test numbered list style."""
        items = ["First", "Second", "Third"]
        result = format_as_bullet_list(items, style="number")

        assert "1. First" in result
        assert "2. Second" in result
        assert "3. Third" in result

    def test_empty_list(self) -> None:
        """Test with empty list."""
        result = format_as_bullet_list([])
        assert "No items" in result

    def test_invalid_style(self) -> None:
        """Test with invalid style."""
        result = format_as_bullet_list(["item"], style="invalid")
        assert "Unknown style" in result


class TestTruncateText:
    """Tests for truncate_text tool."""

    def test_truncate_long_text(self) -> None:
        """Test truncating text longer than max."""
        text = "A" * 300
        result = truncate_text(text, max_length=100)

        assert len(result) == 100
        assert result.endswith("...")

    def test_no_truncate_short_text(self) -> None:
        """Test that short text is not truncated."""
        text = "Short text"
        result = truncate_text(text, max_length=100)

        assert result == text

    def test_custom_suffix(self) -> None:
        """Test custom truncation suffix."""
        text = "A" * 100
        result = truncate_text(text, max_length=50, suffix="[more]")

        assert result.endswith("[more]")


class TestExtractKeywords:
    """Tests for extract_keywords tool."""

    def test_extract_keywords(self) -> None:
        """Test keyword extraction."""
        text = "Python programming is great for data science and machine learning"
        result = extract_keywords(text)

        assert "Keywords:" in result
        assert "python" in result.lower()

    def test_max_keywords_limit(self) -> None:
        """Test keyword limit."""
        text = "one two three four five six seven eight nine ten eleven twelve"
        result = extract_keywords(text, max_keywords=5)

        # Should have at most 5 keywords
        keywords_part = result.split(":")[1].strip()
        keywords = [k.strip() for k in keywords_part.split(",")]
        assert len(keywords) <= 5


class TestFormatNumber:
    """Tests for format_number tool."""

    def test_standard_format(self) -> None:
        """Test standard number formatting."""
        result = format_number(1234567.89, style="standard")
        assert "1,234,567.89" in result

    def test_currency_format(self) -> None:
        """Test currency formatting."""
        result = format_number(1000.50, style="currency")
        assert "$1,000.50" in result

    def test_percentage_format(self) -> None:
        """Test percentage formatting."""
        result = format_number(75.5, style="percentage")
        assert "75.50%" in result

    def test_compact_millions(self) -> None:
        """Test compact format for millions."""
        result = format_number(5500000, style="compact")
        assert "5.50M" in result

    def test_compact_billions(self) -> None:
        """Test compact format for billions."""
        result = format_number(2500000000, style="compact")
        assert "2.50B" in result

    def test_compact_thousands(self) -> None:
        """Test compact format for thousands."""
        result = format_number(7500, style="compact")
        assert "7.50K" in result


class TestCleanText:
    """Tests for clean_text tool."""

    def test_remove_extra_whitespace(self) -> None:
        """Test whitespace normalization."""
        text = "Hello    world   with   spaces"
        result = clean_text(text, remove_extra_whitespace=True)

        assert result == "Hello world with spaces"

    def test_remove_urls(self) -> None:
        """Test URL removal."""
        text = "Check out https://example.com for more info"
        result = clean_text(text, remove_urls=True)

        assert "https://example.com" not in result
        assert "Check out" in result

    def test_lowercase(self) -> None:
        """Test lowercase conversion."""
        text = "HELLO World"
        result = clean_text(text, lowercase=True)

        assert result == "hello world"

    def test_combined_operations(self) -> None:
        """Test multiple cleaning operations."""
        text = "Visit   HTTPS://TEST.COM   for INFO"
        result = clean_text(
            text,
            remove_extra_whitespace=True,
            remove_urls=True,
            lowercase=True,
        )

        assert "https" not in result
        assert result == "visit for info"
