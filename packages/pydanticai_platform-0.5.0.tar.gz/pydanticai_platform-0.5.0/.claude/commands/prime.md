---
allowed-tools: Read, Bash, Glob, Grep
argument-hint: [focus-area]
description: Get up to speed on codebase - review docs, git history, recent changes, and current status
model: sonnet
---

# Prime - Codebase Context Loading

**Focus**: ${1:-general overview}

Load context about the codebase to get Claude and user on the same page quickly.

---

## 1. Find & Read Key Documentation

```bash
# Find README files
find . -maxdepth 3 -type f -iname "README*" -not -path "*/node_modules/*" -not -path "*/.git/*" 2>/dev/null | head -10
```

**Read**:
- Main README.md (project root)
- CLAUDE.md (if exists - business context)
- ARCHITECTURE.md or similar (if exists)
- docs/*.md files (if docs/ directory exists)
- CHANGELOG.md

```bash
# Check for docs directory
ls -la docs/ 2>/dev/null || echo "No docs/ directory"
```

---

## 2. Git History & Recent Changes

```bash
# Last 15 commits with stats
git log --oneline --stat -15 2>/dev/null || echo "Not a git repo"

# Current branch and status
git branch --show-current 2>/dev/null
git status --short 2>/dev/null

# Recent changes (last 5 commits)
git diff --stat HEAD~5..HEAD 2>/dev/null

# Most changed files recently
git log --pretty=format: --name-only -30 2>/dev/null | sort | uniq -c | sort -rg | head -10
```

---

## 3. Project Structure

```bash
# Top-level structure
ls -lah

# Count files by type
echo "File types:"
find . -type f -not -path "*/node_modules/*" -not -path "*/.git/*" 2>/dev/null | \
  sed 's/.*\.//' | sort | uniq -c | sort -rg | head -10

# Major directories
find . -maxdepth 2 -type d -not -path "*/node_modules/*" -not -path "*/.git/*" 2>/dev/null
```

---

## 4. Tech Stack Detection

```bash
# Detect tech stack from config files
[ -f package.json ] && echo "📦 JavaScript/TypeScript project"
[ -f requirements.txt ] || [ -f setup.py ] && echo "🐍 Python project"
[ -f Cargo.toml ] && echo "🦀 Rust project"
[ -f go.mod ] && echo "🔵 Go project"

# Show package.json scripts if exists
[ -f package.json ] && cat package.json | grep -A 20 '"scripts"' || true
```

---

## 5. Focus Area Analysis

**If focus specified (${1})**: Search for relevant files and docs
```bash
grep -r "${1}" --include="*.md" --include="*.txt" -l . 2>/dev/null | head -10 || true
find . -type d -iname "*${1}*" -not -path "*/node_modules/*" 2>/dev/null | head -5 || true
```

---

## 6. Current State

```bash
# TODOs and FIXMEs
echo "Recent TODOs:"
grep -rn "TODO\|FIXME" --include="*.js" --include="*.ts" --include="*.py" --include="*.md" \
  --exclude-dir=node_modules --exclude-dir=.git . 2>/dev/null | head -10 || echo "None found"

# Environment
echo -e "\nEnvironment:"
node -v 2>/dev/null && echo "Node installed" || true
python --version 2>/dev/null && echo "Python installed" || true
echo "Working directory: $(pwd)"
```

---

## Output

Generate summary:

```
🎯 PRIME COMPLETE - ${1:-General Overview}

📚 Documentation Found:
- [List README files found and read]
- [List docs/ files read]

📊 Recent Activity:
- Last commit: [date and message]
- Active branch: [branch name]
- Changes: [X files changed in last week]
- Hotspots: [Most frequently changed files]

🏗️ Project Structure:
- Type: [JS/Python/etc detected]
- Main dirs: [Key directories]
- Entry points: [index.js, main.py, etc]

⚡ Current State:
- Uncommitted changes: [Y/N and what]
- Open TODOs: [Count]
- Environment: [Versions detected]

🎯 Focus: ${1:-Ready for general development}

---

I'm now up to speed on the codebase. What would you like to work on?
```

---

**Prime completed for: ${1:-general overview}**
