# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.5.0] - 2025-12-09

### Added

- **MCP Server**: Expose platform as Model Context Protocol server for Claude Desktop, Cursor, and other MCP clients
  - `chat` tool - Send messages to agents with conversation support
  - `list_agents` tool - List available agents for tenant
  - `get_usage` tool - Get usage statistics
  - `list_conversations` tool - List recent conversations
  - `get_conversation` tool - Get full conversation history
  - `clear_conversation` tool - Clear a conversation
  - HTTP transport at `/mcp` when running API server
  - Stdio transport via `pydanticai-platform mcp-serve` for local integrations
  - API key authentication per tool call
- **Platform-wide MCP Servers**: Connect external MCP servers as toolsets available to all agents
  - Configure via `MCP_SERVERS` environment variable (JSON array)
  - Supports stdio, SSE, and HTTP transports
  - Tool prefixes to avoid naming conflicts
  - Agents automatically have access to all configured MCP server tools
  - Example: `mcp-server-time`, `mcp-server-fetch`, custom MCP servers
- **Real HTTP Client**: `HttpxHttpClient` wrapper for production HTTP calls with connection pooling
- **Real Cache Client**: `RedisCacheClient` wrapper for Redis-based caching
- **Graceful Fallback**: Platform routes use real clients from `app.state` with automatic fallback to mocks

### Changed

- `get_deps_for_tenant()` now uses real `HttpxHttpClient` and `RedisCacheClient` when available
- HTTP client initialized once in app lifespan (shared for connection pooling)
- Cache uses Redis when `REDIS_ENABLED=true`, otherwise falls back to `MockCache`
- `ConversationService.chat()` and `chat_sync()` now accept optional `toolsets` parameter
- Settings now ignores extra environment variables (allows MCP server-specific env vars)

### Dependencies

- Added `fastmcp>=2.0.0` for MCP server support

## [0.4.0] - 2025-12-09

### Added

- **Multi-Tenant Platform**: Complete tenant isolation with API keys
  - Tenant CRUD via Admin API (`/api/v1/admin/tenants`)
  - Per-tenant agent access control (`tenant_agents` table)
  - SHA256-hashed API keys with secure storage
  - API key rotation endpoint
- **Platform API**: Tenant-facing endpoints (`/api/v1/platform`)
  - Chat with agents (sync and streaming)
  - Conversation history and management
  - Usage statistics per tenant
- **Platform Client SDK**: `pydanticai-platform-client` package for consuming the API
  - Async client with streaming support
  - Bearer token authentication
  - Type-safe request/response models
- **Usage Tracking & Limits**
  - Token usage recorded per conversation
  - Monthly token limits per tenant (returns 429 when exceeded)
  - Cost monitoring via `/platform/usage` endpoint
- **Redis Rate Limiting**: `RedisRateLimitMiddleware` for distributed deployments
  - Token bucket algorithm with Lua script for atomicity
  - Per-tenant rate limits (reads `tenant.rate_limit_per_minute`)
  - Automatic fallback to in-memory when Redis unavailable
- **Deployment**: Fly.io configuration with Dockerfile

### Changed

- **Package renamed** from `pydanticai-multiagent` to `pydanticai-platform`
- Streaming now returns deltas (text chunks) instead of full accumulated response
- SDK uses Bearer token auth instead of X-API-Key header
- Restructured as template - example agents moved to `examples/`

### Fixed

- Database connectivity check accepts any PostgreSQL URL format
- Tenant agents lookup returns correct agent list
- Dockerfile works with Debian trixie

## [0.3.0] - 2025-12-08

### Added

- **Authentication Middleware**: `AuthMiddleware` now wired in `create_app()` - extracts Bearer tokens, sets `request.state.user_id` and `request.state.user_roles`
- **Rate Limiting Middleware**: `RateLimitMiddleware` now wired - token bucket algorithm with configurable requests/minute and burst size
- **Real Readiness Check**: `/ready` endpoint now verifies database connectivity, returns 503 if unavailable
- **New Config Settings**:
  - `SECRET_KEY` - for JWT/auth token validation
  - `RATE_LIMIT_REQUESTS_PER_MINUTE` - default 60
  - `RATE_LIMIT_BURST_SIZE` - default 10

### Changed

- `/ready` endpoint now returns `{"status": "ready", "checks": {"database": "ok"}}` with actual dependency status

## [0.2.0] - 2025-12-08

### Added

- **GitHub Actions CI/CD**: Automated testing on Python 3.10, 3.11, 3.12 with linting and type checking
- **Version Bumping**: `.bumpversion.toml` configuration for consistent version management
- **Support API Endpoint**: `/api/v1/agents/support` for customer assistance queries
- **Comprehensive Test Suite**: 103 tests covering all agents, dependencies, mocks, and API endpoints
  - Tests for code, writer, and support agents
  - Tests for `BaseDeps`, `SearchDeps`, `AuthDeps` and factory functions
  - Tests for `MockHttpClient`, `MockDatabase`, `MockCache`, `MockVectorStore`
  - API endpoint tests

### Changed

- **Test fixtures**: Now use production `Mock*` classes instead of simple `MagicMock` for realistic responses
- **API version sync**: FastAPI app now uses `__version__` from package instead of hardcoded value

### Fixed

- **Support toolset**: Removed `vector_search_toolset` which was incompatible with `AuthDeps` (no `vector_store`)

## [0.1.0] - 2025-12-07

### Added

- **Router Agent**: Lightweight routing agent that delegates to specialists
- **Specialist Agents**: Research, Analyst, Code, Writer, and Support agents
- **Dynamic Toolset Selection**: Extend router with domain-specific tools via `deps.domain_toolset`
- **Dependency Injection**: Type-safe `BaseDeps` → `SearchDeps` → `AuthDeps` hierarchy
- **Composable Toolsets**: Combine tools with prefixes using `CombinedToolset`
- **Mock Dependencies**: Test without real databases or APIs
- **CLI**: Commands for `serve`, `chat`, `query`, and `db-migrate`
- **FastAPI Integration**: REST API with health checks and agent endpoints
- **Usage Tracking**: Monitor costs across agent delegation chains

### Examples

- `examples/starter/`: Basic usage, custom agents, dynamic tools
- `examples/johnpye/`: Real-world auction tracking agent with web scraping

[Unreleased]: https://github.com/pydanticai-multiagent/pydanticai-multiagent/compare/v0.5.0...HEAD
[0.5.0]: https://github.com/pydanticai-multiagent/pydanticai-multiagent/compare/v0.4.0...v0.5.0
[0.4.0]: https://github.com/pydanticai-multiagent/pydanticai-multiagent/compare/v0.3.0...v0.4.0
[0.3.0]: https://github.com/pydanticai-multiagent/pydanticai-multiagent/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/pydanticai-multiagent/pydanticai-multiagent/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/pydanticai-multiagent/pydanticai-multiagent/releases/tag/v0.1.0
