# Contributing to pydanticai-multiagent

Thank you for your interest in contributing! This guide will help you get started.

## Development Setup

1. **Clone the repository**
   ```bash
   git clone https://github.com/pydanticai-multiagent/pydanticai-multiagent.git
   cd pydanticai-multiagent
   ```

2. **Install dependencies with uv (recommended)**
   ```bash
   uv sync
   ```

   Or with pip:
   ```bash
   pip install -e ".[dev]"
   ```

3. **Set up environment variables**
   ```bash
   cp .env.example .env
   # Edit .env with your API keys
   ```

## Running Tests

```bash
# Run all tests
uv run pytest

# Run with coverage
uv run pytest --cov=pydanticai_multiagent

# Run specific test file
uv run pytest tests/agents/test_router.py -v
```

## Code Quality

Before submitting a PR, ensure your code passes all checks:

```bash
# Format code
uv run ruff format src tests

# Lint code
uv run ruff check src tests

# Type checking
uv run mypy src
```

## Pull Request Process

1. **Fork the repository** and create your branch from `main`
2. **Make your changes** with clear, descriptive commits
3. **Add tests** for any new functionality
4. **Update documentation** if needed (README, docstrings)
5. **Run the test suite** to ensure everything passes
6. **Submit a PR** with a clear description of changes

### PR Title Format

Use conventional commit style:
- `feat: Add new feature`
- `fix: Fix bug in router`
- `docs: Update README`
- `refactor: Simplify dependency injection`
- `test: Add tests for analyst agent`

## Code Style

- Follow PEP 8 with 100 character line length
- Use type hints for all function signatures
- Write docstrings for public functions and classes
- Keep functions focused and small

## Architecture Guidelines

### Adding New Agents

1. Create agent in `src/pydanticai_multiagent/agents/`
2. Define output model in `src/pydanticai_multiagent/models/`
3. Create toolset in `src/pydanticai_multiagent/toolsets/`
4. Export from `__init__.py` files
5. Add tests in `tests/agents/`

### Adding New Tools

1. Add tool function to appropriate toolset in `src/pydanticai_multiagent/tools/`
2. Use `RunContext[DepsType]` for dependency access
3. Write clear docstrings (they become tool descriptions for the LLM)
4. Add unit tests

## Questions?

- Open an issue for bugs or feature requests
- Start a discussion for questions or ideas

## License

By contributing, you agree that your contributions will be licensed under the MIT License.
