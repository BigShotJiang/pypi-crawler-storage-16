# Demo UI

A simple Gradio web interface for the PydanticAI multi-agent system.

## Quick Start

```bash
# From the project root directory

# 1. Install demo dependencies
pip install -r demo/requirements.txt

# 2. Make sure main app is installed
pip install -e .

# 3. Ensure you have API keys in .env
cat .env  # Should have OPENAI_API_KEY and ANTHROPIC_API_KEY

# 4. Run the demo
python demo/app.py
```

Then open http://localhost:7860 in your browser.

## Features

- **Agent Selection**: Switch between Router, Research, Analyst, Code, Writer, and Support agents
- **Chat Interface**: Clean conversation UI with history
- **Example Prompts**: Click-to-try example queries
- **Markdown Rendering**: Formatted responses with code blocks

## Sharing with Others

To create a temporary public URL (great for demos):

```python
# In demo/app.py, change the last line to:
demo.launch(share=True)
```

This will give you a `*.gradio.live` URL that works for 72 hours.

## Screenshot

```
┌─────────────────────────────────────────────────────┐
│  PydanticAI Multi-Agent Demo                        │
├─────────────────────────────────────────────────────┤
│  Select Agent: [Router (Auto-delegates)    ▼]      │
│  *Analyzes your request and delegates...*          │
├─────────────────────────────────────────────────────┤
│                                                     │
│  User: What are the key features of Python 3.12?   │
│                                                     │
│  Assistant: Python 3.12 introduces several...      │
│                                                     │
├─────────────────────────────────────────────────────┤
│  [Type your message here...           ] [Send]     │
│                                                     │
│  [Clear Conversation]                               │
└─────────────────────────────────────────────────────┘
```

## Troubleshooting

**"No module named 'my_app'"**
```bash
# Make sure you're in the project root and install the package
pip install -e .
```

**"Invalid API key"**
```bash
# Check your .env file has valid keys
echo $OPENAI_API_KEY
echo $ANTHROPIC_API_KEY
```

**Port already in use**
```bash
# Use a different port
python -c "import demo.app as d; d.create_demo().launch(server_port=7861)"
```
