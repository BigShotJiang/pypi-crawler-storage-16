# John Pye Auction Tracking Example

A real-world example of a domain-specific agent built with pydanticai-multiagent.

## What This Demonstrates

- **Custom Agent**: Domain-specific agent with business logic
- **Web Scraping**: Playwright-based invoice extraction from johnpye.co.uk
- **Database Integration**: Supabase/PostgreSQL for persistence
- **Custom Models**: Invoice, LotItem with status enums
- **Tool Composition**: Combining domain tools with common utilities

## Structure

```
examples/johnpye/
├── agents/
│   └── johnpye.py      # John Pye tracking agent
├── tools/
│   └── invoices.py     # Invoice CRUD, sync, reporting tools
├── services/
│   ├── johnpye_auth.py    # Authentication helper
│   └── johnpye_scraper.py # Web scraper for invoices
├── models/
│   └── johnpye.py      # Invoice, LotItem, status enums
└── johnpye.py          # Toolset composition
```

## Usage

This example is NOT installed with the main package. To use it:

1. Copy the example files to your project
2. Install additional dependencies:
   ```bash
   pip install playwright beautifulsoup4 pdfplumber
   playwright install chromium
   ```
3. Configure your `.env`:
   ```
   DATABASE_URL=postgresql://...your-supabase-url...
   JOHNPYE_EMAIL=your-email
   JOHNPYE_PASSWORD=your-password
   ```
4. Run migrations for the johnpye tables
5. Import and use with the router:
   ```python
   import asyncio
   from pydanticai_multiagent import router_agent, create_mock_search_deps
   from examples.johnpye import johnpye_toolset

   async def main():
       # Add johnpye tools to the router
       deps = create_mock_search_deps()
       deps.domain_toolset = johnpye_toolset

       # Router can now use johnpye tools
       result = await router_agent.run(
           "Get my recent John Pye invoices",
           deps=deps
       )
       print(result.output)

   asyncio.run(main())
   ```

   Or use the standalone agent directly:
   ```python
   from examples.johnpye.agents.johnpye import johnpye_agent

   result = await johnpye_agent.run("Sync my invoices", deps=deps)
   ```

## Features

- **Invoice Sync**: Scrape and sync invoices from John Pye website
- **Spending Tracking**: Get spending summaries by period
- **Delivery Tracking**: Track payment and delivery status
- **Export**: CSV export for accounting
