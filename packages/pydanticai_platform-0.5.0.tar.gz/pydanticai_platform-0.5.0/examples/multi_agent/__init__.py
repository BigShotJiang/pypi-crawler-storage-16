"""Multi-agent example with router-based delegation.

This example demonstrates how to build a multi-agent system using
the pydanticai-template infrastructure.

Usage:
    from examples.multi_agent import router_agent
    from pydanticai_multiagent import create_mock_search_deps

    deps = create_mock_search_deps()
    result = await router_agent.run("What is Python?", deps=deps)
"""

from .agents import (
    analyst_agent,
    code_agent,
    research_agent,
    router_agent,
    support_agent,
    writer_agent,
)
from .models import (
    AnalysisResult,
    CodeResponse,
    DataPoint,
    ResearchResult,
    SupportResponse,
)

__all__ = [
    # Agents
    "router_agent",
    "research_agent",
    "analyst_agent",
    "code_agent",
    "writer_agent",
    "support_agent",
    # Models
    "ResearchResult",
    "AnalysisResult",
    "DataPoint",
    "CodeResponse",
    "SupportResponse",
]
