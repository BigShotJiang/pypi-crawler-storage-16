"""Basic usage example - Create your first agent.

This example shows how to create a simple agent using the template infrastructure.
"""

import asyncio

from pydantic_ai import Agent

from pydanticai_multiagent import BaseDeps, create_mock_base_deps

# Define a simple agent - this is all you need!
my_agent: Agent[BaseDeps, str] = Agent(
    "openai:gpt-4o",
    deps_type=BaseDeps,
    instructions="""You are a helpful assistant that answers questions clearly and concisely.""",
)


async def main():
    # Create mock dependencies (no real database or API needed for testing)
    deps = create_mock_base_deps()

    # Run the agent
    result = await my_agent.run(
        "What are three benefits of using Python for data science?",
        deps=deps,
    )

    print("Response:")
    print(result.output)


if __name__ == "__main__":
    asyncio.run(main())
