"""PydanticAI Agent Template.

A production-ready template for building AI agents with PydanticAI.

This package provides infrastructure for building agents:
- Dependency injection (BaseDeps, SearchDeps, AuthDeps)
- Mock implementations for testing
- Database persistence
- FastAPI integration with middleware
- Conversation management
- Usage tracking

Example:
    ```python
    from pydantic_ai import Agent
    from pydanticai_multiagent import BaseDeps, create_mock_base_deps

    # Define your agent
    my_agent: Agent[BaseDeps, str] = Agent(
        "openai:gpt-4o",
        deps_type=BaseDeps,
        instructions="You are a helpful assistant.",
    )

    # Use mock deps for development
    deps = create_mock_base_deps()
    result = await my_agent.run("Hello!", deps=deps)
    print(result.output)
    ```

For complete examples, see examples/multi_agent/ which demonstrates
router-based delegation with multiple specialist agents.
"""

__version__ = "0.5.0"

# Core infrastructure - always exported
from .dependencies import (
    AuthDeps,
    BaseDeps,
    SearchDeps,
    create_mock_auth_deps,
    create_mock_base_deps,
    create_mock_search_deps,
)

# Example agents - kept for backwards compatibility but deprecated
# New projects should define their own agents (see examples/multi_agent/)
from .agents import (
    CodeResponse,
    SupportResponse,
    analyst_agent,
    code_agent,
    research_agent,
    router_agent,
    support_agent,
    writer_agent,
)

# Example output models - kept for backwards compatibility
# New projects should define their own models
from .models import (
    AnalysisResult,
    ResearchResult,
)

__all__ = [
    # Version
    "__version__",
    # Infrastructure (the main value)
    "BaseDeps",
    "SearchDeps",
    "AuthDeps",
    "create_mock_base_deps",
    "create_mock_search_deps",
    "create_mock_auth_deps",
    # Example agents (backwards compatibility - see examples/multi_agent/ for patterns)
    "router_agent",
    "research_agent",
    "analyst_agent",
    "code_agent",
    "writer_agent",
    "support_agent",
    # Example output models (backwards compatibility)
    "ResearchResult",
    "AnalysisResult",
    "CodeResponse",
    "SupportResponse",
]
