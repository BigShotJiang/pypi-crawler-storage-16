"""Authentication-related dependencies."""

from dataclasses import dataclass, field

from .base import BaseDeps


@dataclass
class AuthDeps(BaseDeps):
    """Dependencies for authentication-aware agents.

    Extends BaseDeps with user role and permission information
    for agents that need to make authorization decisions.

    Example:
        ```python
        deps = AuthDeps(
            http_client=client,
            db=database_pool,
            cache=redis_client,
            user_id="user-123",
            user_roles=["admin", "analyst"],
            permissions=["read:data", "write:reports"]
        )
        result = await support_agent.run("query", deps=deps)
        ```
    """

    user_roles: list[str] = field(default_factory=list)
    permissions: list[str] = field(default_factory=list)

    def has_role(self, role: str) -> bool:
        """Check if user has a specific role."""
        return role in self.user_roles

    def has_permission(self, permission: str) -> bool:
        """Check if user has a specific permission."""
        return permission in self.permissions

    def is_admin(self) -> bool:
        """Check if user is an admin."""
        return "admin" in self.user_roles
