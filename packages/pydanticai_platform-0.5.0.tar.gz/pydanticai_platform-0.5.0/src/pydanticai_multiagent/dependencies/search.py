"""Search-specific dependencies."""

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Protocol

from .base import BaseDeps

if TYPE_CHECKING:
    from pydantic_ai.toolsets import AbstractToolset


class VectorStore(Protocol):
    """Protocol for vector database operations."""

    async def search(
        self, query: str, top_k: int = 10, filters: dict[str, Any] | None = None
    ) -> list[dict[str, Any]]: ...

    async def get(self, doc_id: str) -> dict[str, Any] | None: ...

    async def upsert(self, doc_id: str, content: str, metadata: dict[str, Any]) -> None: ...


@dataclass(kw_only=True)
class SearchDeps(BaseDeps):
    """Dependencies for search-related agents.

    Extends BaseDeps with search-specific capabilities like
    vector store access, search API credentials, and dynamic toolsets.

    Example:
        ```python
        deps = SearchDeps(
            http_client=client,
            db=database_pool,
            cache=redis_client,
            vector_store=pinecone_client,
            search_api_key="sk-...",
            domain_toolset=my_custom_toolset,  # Optional: add domain tools
        )
        result = await router_agent.run("query", deps=deps)
        ```
    """

    vector_store: VectorStore
    search_api_key: str = ""
    domain_toolset: "AbstractToolset | None" = None  # Dynamic domain-specific tools

    def to_base_deps(self) -> BaseDeps:
        """Convert to BaseDeps, dropping search-specific fields."""
        return BaseDeps(
            http_client=self.http_client,
            db=self.db,
            cache=self.cache,
            user_id=self.user_id,
        )

    def to_auth_deps(
        self,
        user_roles: list[str] | None = None,
        permissions: list[str] | None = None,
    ) -> "AuthDeps":
        """Convert to AuthDeps with role/permission info."""
        from .auth import AuthDeps

        return AuthDeps(
            http_client=self.http_client,
            db=self.db,
            cache=self.cache,
            user_id=self.user_id,
            user_roles=user_roles or [],
            permissions=permissions or [],
        )

    @classmethod
    def from_base(
        cls,
        base: BaseDeps,
        vector_store: VectorStore,
        search_api_key: str = "",
    ) -> "SearchDeps":
        """Create SearchDeps from existing BaseDeps."""
        return cls(
            http_client=base.http_client,
            db=base.db,
            cache=base.cache,
            user_id=base.user_id,
            vector_store=vector_store,
            search_api_key=search_api_key,
        )
