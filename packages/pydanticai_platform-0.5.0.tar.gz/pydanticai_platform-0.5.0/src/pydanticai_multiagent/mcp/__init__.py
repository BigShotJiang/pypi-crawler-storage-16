"""MCP module for Model Context Protocol integration.

This module provides both:
1. MCP Server - Exposes the platform as an MCP server for external clients
2. MCP Client - Connects to external MCP servers for agent tools
"""

from .auth import MCPAuthError, validate_api_key
from .client import (
    MCPClientManager,
    MCPServerConfig,
    cleanup_mcp_clients,
    get_mcp_toolsets,
    initialize_mcp_clients,
)
from .server import get_mcp_state, mcp_server, set_mcp_state

__all__ = [
    # MCP Server (expose platform)
    "mcp_server",
    "set_mcp_state",
    "get_mcp_state",
    "validate_api_key",
    "MCPAuthError",
    # MCP Client (use external servers)
    "initialize_mcp_clients",
    "get_mcp_toolsets",
    "cleanup_mcp_clients",
    "MCPClientManager",
    "MCPServerConfig",
]
