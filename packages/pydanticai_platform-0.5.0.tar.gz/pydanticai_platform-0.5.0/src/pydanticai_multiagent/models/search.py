"""Search-related models."""

from pydantic import BaseModel, Field


class SearchQuery(BaseModel):
    """Search query parameters."""

    query: str = Field(min_length=1, description="Search query string")
    filters: dict[str, str] = Field(default_factory=dict)
    top_k: int = Field(default=10, ge=1, le=100)


class SearchResult(BaseModel):
    """A single search result."""

    id: str
    title: str
    content: str
    score: float = Field(ge=0, le=1)
    url: str | None = None
    metadata: dict[str, str] = {}

    def as_context(self) -> str:
        """Format for inclusion in agent context."""
        return f"[{self.title}]\n{self.content}"


class SearchResponse(BaseModel):
    """Collection of search results."""

    results: list[SearchResult]
    total_count: int
    query: str

    def format_for_agent(self) -> str:
        """Format all results for agent consumption."""
        if not self.results:
            return f"No results found for: {self.query}"
        formatted = [f"{i+1}. {r.as_context()}" for i, r in enumerate(self.results)]
        return f"Search results for '{self.query}':\n\n" + "\n\n".join(formatted)
