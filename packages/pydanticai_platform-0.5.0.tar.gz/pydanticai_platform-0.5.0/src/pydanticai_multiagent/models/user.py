"""User-related models."""

from datetime import datetime

from pydantic import BaseModel, EmailStr, Field


class User(BaseModel):
    """User model."""

    id: str
    email: EmailStr
    name: str
    created_at: datetime = Field(default_factory=datetime.now)
    is_active: bool = True


class UserProfile(BaseModel):
    """Extended user profile."""

    user: User
    preferences: dict[str, str] = {}
    roles: list[str] = []

    def has_role(self, role: str) -> bool:
        """Check if user has a specific role."""
        return role in self.roles

    def as_prompt_context(self) -> str:
        """Format user info for agent context."""
        return f"User: {self.user.name} (roles: {', '.join(self.roles)})"
