"""Data analysis and manipulation tools."""

from pydantic_ai.toolsets import CombinedToolset

from .analysis import analysis_toolset
from .export import export_toolset
from .visualization import visualization_toolset

# Combined data toolset
data_toolset = CombinedToolset(
    [
        analysis_toolset.prefixed("stats"),
        visualization_toolset.prefixed("viz"),
        export_toolset.prefixed("export"),
    ]
)

__all__ = [
    "analysis_toolset",
    "data_toolset",
    "export_toolset",
    "visualization_toolset",
]
