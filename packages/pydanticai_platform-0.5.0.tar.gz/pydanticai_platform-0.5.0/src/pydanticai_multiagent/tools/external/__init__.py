"""External API integration tools."""

from pydantic_ai.toolsets import CombinedToolset

from .email import email_toolset
from .github import github_toolset
from .slack import slack_toolset

# Combined external toolset
external_toolset = CombinedToolset(
    [
        github_toolset.prefixed("github"),
        slack_toolset.prefixed("slack"),
        email_toolset.prefixed("email"),
    ]
)

__all__ = [
    "email_toolset",
    "external_toolset",
    "github_toolset",
    "slack_toolset",
]
