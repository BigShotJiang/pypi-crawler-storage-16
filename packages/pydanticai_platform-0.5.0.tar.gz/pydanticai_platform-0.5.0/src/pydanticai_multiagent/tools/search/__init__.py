"""Search tools."""

from pydantic_ai.toolsets import CombinedToolset

from .database import db_search_toolset
from .vector import vector_search_toolset
from .web import web_search_toolset

# Combined search toolset with prefixes
search_toolset = CombinedToolset(
    [
        web_search_toolset.prefixed("web"),
        vector_search_toolset.prefixed("kb"),
        db_search_toolset.prefixed("db"),
    ]
)

__all__ = [
    "db_search_toolset",
    "search_toolset",
    "vector_search_toolset",
    "web_search_toolset",
]
