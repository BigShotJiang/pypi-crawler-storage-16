"""Tests for pydanticai_multiagent."""
