"""Tests for the code agent."""

from pydantic_ai.models.test import TestModel

from pydanticai_multiagent.agents.code import CodeResponse, code_agent
from pydanticai_multiagent.dependencies import BaseDeps


class TestCodeAgent:
    """Tests for the code agent."""

    async def test_code_agent_returns_structured_output(
        self,
        base_deps: BaseDeps,
    ) -> None:
        """Test that code agent returns CodeResponse."""
        test_model = TestModel()

        with code_agent.override(model=test_model):
            result = await code_agent.run(
                "Write a function to calculate factorial",
                deps=base_deps,
            )

            assert isinstance(result.output, CodeResponse)
            assert result.output.explanation is not None

    async def test_code_agent_has_tools(
        self,
        base_deps: BaseDeps,
    ) -> None:
        """Test that code agent has access to expected tools."""
        test_model = TestModel()

        with code_agent.override(model=test_model):
            await code_agent.run(
                "Help me debug this code",
                deps=base_deps,
            )

            tools = test_model.last_model_request_parameters
            assert tools is not None
            assert len(tools.function_tools) > 0


class TestCodeResponse:
    """Tests for CodeResponse model."""

    def test_code_response_minimal(self) -> None:
        """Test CodeResponse with minimal fields."""
        response = CodeResponse(explanation="Use a for loop")

        assert response.explanation == "Use a for loop"
        assert response.code is None
        assert response.language is None
        assert response.suggestions == []

    def test_code_response_full(self) -> None:
        """Test CodeResponse with all fields."""
        response = CodeResponse(
            explanation="Here's a factorial function",
            code="def factorial(n):\n    return 1 if n <= 1 else n * factorial(n-1)",
            language="python",
            suggestions=["Add input validation", "Consider iterative approach"],
        )

        assert response.explanation == "Here's a factorial function"
        assert "factorial" in response.code
        assert response.language == "python"
        assert len(response.suggestions) == 2
