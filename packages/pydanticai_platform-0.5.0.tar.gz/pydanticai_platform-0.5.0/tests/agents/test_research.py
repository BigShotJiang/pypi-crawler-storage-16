"""Tests for the research agent."""

import pytest
from pydantic_ai.models.test import TestModel

from pydanticai_multiagent.agents.research import research_agent
from pydanticai_multiagent.dependencies import SearchDeps
from pydanticai_multiagent.models import ResearchResult


@pytest.fixture
def test_model() -> TestModel:
    """Create a test model for deterministic testing."""
    return TestModel()


class TestResearchAgent:
    """Tests for the research agent."""

    async def test_research_agent_returns_structured_output(
        self,
        search_deps: SearchDeps,
    ) -> None:
        """Test that research agent returns ResearchResult."""
        # Use TestModel for deterministic testing
        test_model = TestModel()

        # Override the agent's model for testing
        with research_agent.override(model=test_model):
            result = await research_agent.run(
                "What is PydanticAI?",
                deps=search_deps,
            )

            # Verify structured output
            assert isinstance(result.output, ResearchResult)
            assert result.output.answer is not None
            assert isinstance(result.output.sources, list)

    async def test_research_agent_uses_tools(
        self,
        search_deps: SearchDeps,
    ) -> None:
        """Test that research agent has access to expected tools."""
        test_model = TestModel()

        with research_agent.override(model=test_model):
            await research_agent.run(
                "Search for information about AI",
                deps=search_deps,
            )

            # Check that tools were available
            tools = test_model.last_model_request_parameters
            assert tools is not None
            # The agent should have tools registered
            assert len(tools.function_tools) > 0

    async def test_research_result_format_with_sources(self) -> None:
        """Test ResearchResult formatting."""
        result = ResearchResult(
            answer="PydanticAI is a framework for building AI agents.",
            sources=["https://docs.pydantic.dev", "https://github.com/pydantic/pydantic-ai"],
            confidence=0.9,
            follow_up_questions=["How do I install it?"],
        )

        formatted = result.format_with_sources()

        assert "PydanticAI is a framework" in formatted
        assert "https://docs.pydantic.dev" in formatted
        assert "Sources:" in formatted
