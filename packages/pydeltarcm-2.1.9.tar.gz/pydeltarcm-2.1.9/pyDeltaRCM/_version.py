def __version__() -> str:
    """
    Private version declaration, gets assigned to pyDeltaRCM.__version__
    during import
    """
    return "2.1.9"
