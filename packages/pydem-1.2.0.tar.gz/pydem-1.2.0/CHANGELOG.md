# 1.2.0

## Features
* Fixed geotiff saving functionality
* Upgraded to .toml

# 1.1.0

## Features
* Added a Dockerfile with some additional documentation
* Improved/updated the installation instructions