.. PyDesignFlow documentation master file, created by
   sphinx-quickstart on Wed Jul 13 13:52:14 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to PyDesignFlow's documentation!
========================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   introduction
   reference
   design_decisions
   sphinx_ext
   filemgmt
   tests/index
   todo

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
