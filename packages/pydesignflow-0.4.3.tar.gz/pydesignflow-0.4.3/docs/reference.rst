Reference
=========

@task decorator
---------------

.. autodecorator:: pydesignflow.task

Block
-----

.. autoclass:: pydesignflow.Block
    :members:

Flow
----

.. autoclass:: pydesignflow.Flow
    :members:

Result
------

.. autoclass:: pydesignflow.Result
    :members:
