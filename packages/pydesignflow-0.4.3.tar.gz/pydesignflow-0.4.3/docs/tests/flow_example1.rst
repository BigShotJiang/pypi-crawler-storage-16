.. _flow_example1:

flow_example1
=============


.. figure:: figs/example_block.svg
   :class: with-border

   ExampleBlock dependency graph


.. _flow_example1_autodoc:

Auto-generated doc 
------------------

.. designflow:: tests.flow_example1