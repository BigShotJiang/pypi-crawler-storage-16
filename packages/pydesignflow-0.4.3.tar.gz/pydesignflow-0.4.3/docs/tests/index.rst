.. _tests:

Tests
=====

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   flow_example1


What is tested?

- Dependency resolution
- Passing results
  
Todo:

- CLI
- Test Result object behavior