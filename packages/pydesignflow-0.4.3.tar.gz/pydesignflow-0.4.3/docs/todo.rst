Todo
====

Non-Critical Bugs:

- Document: :ref:`tests`
- Document: :ref:`design_decisions`

Feature requests:

- :ref:`sphinx_ext`: add domain for pydesignflow + support cross-references\
- Result / json format: Add pickle support + document security implications.
