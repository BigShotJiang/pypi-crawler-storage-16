"""Exceptions"""

# pylint: disable=unused-import
# Importing exceptions this way makes them accessible through this module.
# Therefore, obscuring azure packages from the end user
from azure.core.exceptions import HttpResponseError
