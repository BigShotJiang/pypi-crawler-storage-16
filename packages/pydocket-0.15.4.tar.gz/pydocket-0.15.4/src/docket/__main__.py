from .cli import app

app()
