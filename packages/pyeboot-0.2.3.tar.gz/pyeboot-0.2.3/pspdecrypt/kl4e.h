#pragma once

int decompress_kle(u8 *outBuf, int outSize, u8 *inBuf, void **end, int isKl4e);
