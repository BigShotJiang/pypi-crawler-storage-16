# API documentation

::: pyecotrend_ista.PyEcotrendIsta
    :docstring:
    :members:
<!--
::: pyecotrend_ista.openid
    :docstring:
    :members:

::: pyecotrend_ista.types
    :docstring:
    :members:

::: pyecotrend_ista.login_helper
    :docstring:
    :members:

::: pyecotrend_ista.exception_classes
    :docstring:
    :members: -->
