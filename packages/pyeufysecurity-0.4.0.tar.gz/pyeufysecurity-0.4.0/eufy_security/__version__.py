"""Define the package version."""
__version__: str = "0.4.0"
