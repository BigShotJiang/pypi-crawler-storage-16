"""Define examples."""
