"""Define test fixtures."""
