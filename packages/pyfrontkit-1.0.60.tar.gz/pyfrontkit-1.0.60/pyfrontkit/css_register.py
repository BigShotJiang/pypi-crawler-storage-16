# pyfrontkit/css_register.py 
# Copyright (C) [2025] Eduardo Antonio Ferrera Rodríguez
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation, either version 3 of the License, or any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; see the COPYING file for more details.


from pathlib import Path
from typing import Any 

class CSSRegistry:
    """
    Simplified CSS selector registry for PyFrontKit.
    Manages unique registration of tags, IDs, classes, and parent > child cascade selectors.
    The registration occurs **only in memory** for efficiency (Pure Memory).
    """

    _tags = set()
    _ids = set()
    _classes = set()
    _cascades = set() 

    @classmethod
    def _get_child_tag(cls, child: Any) -> str | None:
        """
        Helper to get the tag. Works for Block, ContentItem, and now VoidElement.
        """
        if hasattr(child, "tag"):
            return getattr(child, "tag")
        return None

    @classmethod
    def _register_cascades_by_tag(cls, block):
        """
        Generates and registers tag-based cascades up to 2 levels deep:
        - tag > tag/content_tag (1st level)
        - tag > tag > tag/content_tag (2nd level)
        """
        parent_tag = block.tag
        
        # ---------------------------------------------
        # 1. Analyze Children (1st Level) - Includes VoidElement now
        # ---------------------------------------------
        for child in block.children:
            child_tag = cls._get_child_tag(child)
            if not child_tag:
                continue
            
            # 1.1 Cascade of 1 Level: tag > tag (e.g., div > img)
            selector_1 = f"{parent_tag} > {child_tag}"
            cls._cascades.add(selector_1)
            
            # ---------------------------------------------
            # 2. Analyze Grandchildren (2nd Level)
            # ---------------------------------------------
            # Checks if the child is a Block capable of having further children/content
            # NOTE: VoidElement does NOT have 'children', por lo que esto solo se aplica a Block.
            if hasattr(child, "tag") and hasattr(child, "children"): 
                
                # Grandchildren of type Block or VoidElement
                for grandchild in child.children:
                    grandchild_tag = cls._get_child_tag(grandchild)
                    if grandchild_tag:
                        # Cascade of 2 Levels: tag > tag > tag 
                        selector_2 = f"{parent_tag} > {child_tag} > {grandchild_tag}"
                        cls._cascades.add(selector_2)
                
                # Grandchildren of type ContentItem
                for ctn_item in getattr(child, "content_items", []):
                    grandchild_tag = cls._get_child_tag(ctn_item)
                    if grandchild_tag:
                        # Cascade of 2 Levels: tag > tag > content_tag 
                        selector_2 = f"{parent_tag} > {child_tag} > {grandchild_tag}"
                        cls._cascades.add(selector_2)


        # ---------------------------------------------
        # 3. Analyze Block Content (1st Level)
        # ---------------------------------------------
        # Children of type ContentItem
        for ctn_item in getattr(block, "content_items", []):
            ctn_tag = cls._get_child_tag(ctn_item)
            if ctn_tag:
                # 3.1 Cascade of 1 Level: tag > content_tag
                selector_1 = f"{parent_tag} > {ctn_tag}"
                cls._cascades.add(selector_1)


    @classmethod
    def register_single_selectors(cls, element):
        """
        Registers only the single selectors (Tag, ID, Class) of a single element.
        Useful for non-Block elements like VoidElement and ContentItem.
        """
        attrs = getattr(element, "attrs", {})
        element_id = attrs.get("id")

        # --- TAG REGISTRATION
        if hasattr(element, "tag") and element.tag and element.tag not in cls._tags:
            cls._tags.add(element.tag)

        # --- ID REGISTRATION
        if element_id and element_id not in cls._ids:
            # Añadimos el ID sin el prefijo '#'
            cls._ids.add(element_id)
        
        # --- CLASS REGISTRATION
        classes = attrs.get("class")
        if classes:
            for cls_name in str(classes).split():
                if cls_name not in cls._classes:
                   
                    cls._classes.add(cls_name)

    @classmethod
    def register_block(cls, block):
        """
        Registers selectors of the block and its children ONLY IN MEMORY (Recursive).
        Reads the Block structure and fills the sets.
        """
        
        
        cls.register_single_selectors(block) 
        
        block_id = getattr(block, "attrs", {}).get("id")
        children = list(getattr(block, "children", []))

        
        # --- ID > TAG CASCADE (Direct Child)
        if block_id:
            for child in children:
                child_tag = getattr(child, "tag", None)
                if child_tag:
                    selector = f"#{block_id} > {child_tag}"

                    if selector not in cls._cascades:
                        cls._cascades.add(selector)
                                
        # --- NEW CASCADES: TAG > TAG AND TAG > TAG > TAG
        cls._register_cascades_by_tag(block)


        # --- RECURSION THROUGH CHILD BLOCKS (solo si el hijo es un Block)
        for child in children:
            if hasattr(child, "tag") and getattr(child, "tag") and hasattr(child, "children"):
                cls.register_block(child)

        # --- CONTENT-ITEM SELECTOR REGISTRATION
        
        for ctn_item in getattr(block, "content_items", []):
            cls.register_single_selectors(ctn_item)


    @classmethod
    def generate_css(cls):
        """
        Returns all generated selectors in memory as a CSS text string.
        """
        lines = ["/* Selectors generated by PyFrontKit */\n"]

        # TAGS
        for tag in sorted(cls._tags):
            lines.append(f"{tag} {{\n \t/* styles here */\n}}\n")

        # IDS
        for id_name in sorted(cls._ids):
            lines.append(f"#{id_name} {{\n \t/* styles here */\n}}\n")

        # CLASSES
        for cls_name in sorted(cls._classes):
            lines.append(f".{cls_name} {{\n \t/* styles here */\n}}\n")

        # CASCADES parent > child and grandparent > parent > child
        for selector in sorted(cls._cascades):
            lines.append(f"{selector} {{\n \t/* styles here */\n}}\n")

        return "\n".join(lines)