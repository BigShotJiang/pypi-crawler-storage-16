# pyfrontkit/void_element.py

# Copyright (C) [2025] Eduardo Antonio Ferrera Rodríguez
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation, either version 3 of the License, or any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; see the COPYING file for more details.

from .block import Block # Importamos Block para acceder a _registry

# =============================================================
# CONSTANTES DE ATRIBUTOS VÁLIDOS PARA ELEMENTOS VOID
# =============================================================

# Atributos base que casi todos los VoidElements pueden tener
BASE_VOID_ATTRS = {"id", "class", "class_", "style", "title", "data-", "aria-"}

# Atributos específicos por etiqueta Void
VOID_TAG_SPECIFIC_ATTRS = {
    "img": BASE_VOID_ATTRS | {"src", "alt", "width", "height", "loading", "srcset", "sizes"},
    "input": BASE_VOID_ATTRS | {"type", "name", "value", "placeholder", "checked", "disabled", "readonly", "size", "maxlength", "min", "max", "step"},
    "link": BASE_VOID_ATTRS | {"href", "rel", "type", "media", "crossorigin"},
    "meta": BASE_VOID_ATTRS | {"name", "content", "charset", "http-equiv"},
    "br": set(),  # <br> no lleva atributos
    "hr": BASE_VOID_ATTRS,
    "area": BASE_VOID_ATTRS | {"alt", "coords", "href", "shape", "target"},
    "base": BASE_VOID_ATTRS | {"href", "target"},
    "col": BASE_VOID_ATTRS | {"span"},
    # Añadir el resto de atributos específicos según sea necesario
}


class VoidElement:
    """
    Base class for void/self-closing HTML elements.
    - Generates <tag attr1="..." />.
    - Strictly validates attributes against HTML standards.
    - Registers itself globally to allow printing in the <body>.
    """

    def __init__(self, tag: str, **attrs):
        self.tag = tag
        # 1. Validación estricta de atributos
        self.attrs = self._validate_attributes(tag, attrs)
        
        # 2. Inicialización de Parent y Registro Global
        self._parent = None 
        # Esto permite que HtmlDoc.render_body() lo encuentre e imprima como raíz.
        Block._registry.append(self)


    def _validate_attributes(self, tag: str, kwargs: dict) -> dict:
        """Processes and validates attributes, notifying the user of errors."""
        
        # Obtenemos el conjunto de atributos permitidos para esta etiqueta.
        # Cualquier atributo que comience con 'data-' o 'aria-' es válido.
        allowed_attrs = VOID_TAG_SPECIFIC_ATTRS.get(tag, BASE_VOID_ATTRS)
        validated_attrs = {}

        for key, value in kwargs.items():
            normalized_key = "class" if key == "class_" else key
            
            # Chequeo rápido de data-* y aria-*
            if normalized_key.startswith("data-") or normalized_key.startswith("aria-"):
                # Permitir data-* y aria-* (accesibilidad)
                pass 
            # Chequeo contra lista de permitidos
            elif normalized_key not in allowed_attrs:
                # Notificación estricta de error
                print(f"⚠️ Warning: '{key}' is not a valid attribute for <{tag}>. Allowed: {allowed_attrs}")
                continue

            # Lógica para atributos booleanos
            if value is True:
                validated_attrs[normalized_key] = None
            elif value not in (None, False):
                validated_attrs[normalized_key] = value
                
        return validated_attrs


    def render(self, indent: int = 0) -> str:
        """Generates the self-closing HTML tag."""
        space = " " * indent
        attr_text = ""
        for key, value in self.attrs.items():
            if value is None:
                attr_text += f" {key}"
            else:
                attr_text += f' {key}="{value}"'
        return f"{space}<{self.tag}{attr_text} />\n"

    # Estos elementos no admiten hijos.
    def add_child(self, *children):
        raise RuntimeError(f"The <{self.tag}> element is a void element and cannot contain children.")

    def __str__(self):
        return self.render(0)


# =============================================================
# Concrete void elements
# =============================================================

class Img(VoidElement):
    def __init__(self, **attrs):
        super().__init__("img", **attrs)

class Input(VoidElement):
    def __init__(self, **attrs):
        super().__init__("input", **attrs)

class Hr(VoidElement):
    def __init__(self, **attrs):
        super().__init__("hr", **attrs)

class Br(VoidElement):
    def __init__(self, **attrs):
        super().__init__("br", **attrs)
        
class Meta(VoidElement):
    def __init__(self, **attrs):
        super().__init__("meta", **attrs)

class Link(VoidElement):
    def __init__(self, **attrs):
        super().__init__("link", **attrs)
class Source(VoidElement):
    def __init__(self, **attrs):
        super().__init__("source", **attrs)

class Embed(VoidElement):
    def __init__(self, **attrs):
        super().__init__("embed", **attrs)

class Param(VoidElement):
    def __init__(self, **attrs):
        super().__init__("param", **attrs)

class Track(VoidElement):
    def __init__(self, **attrs):
        super().__init__("track", **attrs)

class Wbr(VoidElement):
    def __init__(self, **attrs):
        super().__init__("wbr", **attrs)

class Area(VoidElement):
    def __init__(self, **attrs):
        super().__init__("area", **attrs)

class Base(VoidElement):
    def __init__(self, **attrs):
        super().__init__("base", **attrs)

class Col(VoidElement):
    def __init__(self, **attrs):
        super().__init__("col", **attrs)


# =============================================================
# Aliases for simple lowercase calls
# =============================================================

img = Img
Input = Input
hr = Hr
meta = Meta
link = Link
source = Source
embed = Embed
param = Param
track = Track
wbr = Wbr
area = Area
base = Base
col = Col
