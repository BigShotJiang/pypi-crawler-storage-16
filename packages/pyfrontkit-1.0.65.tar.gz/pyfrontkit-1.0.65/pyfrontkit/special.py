# Copyright (C) [2025] Eduardo Antonio Ferrera Rodríguez
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; see the COPYING file for more details.

# pyfrontkit/special.py

from .void_element import Source, Track, Img, Param
from .css_register import CSSRegistry
from .content import ContentFactory, ContentItem


class SpecialElement:
    """
    Base class for HTML special elements that can have:
      - Allowed children (other tags)
      - Content items (ctn_*)
    """
    ALLOWED_CHILDREN = {}  # To be defined in subclass

    def __init__(self, *, id=None, class_=None, style=None, **kwargs):
        self.tag = getattr(self, "tag", None)
        if not self.tag:
            raise ValueError("SpecialElement must have a tag defined in subclass")
        
        self.attrs = {}
        if id:
            self.attrs["id"] = id
        if class_:
            self.attrs["class"] = class_
        if style:
            self.attrs["style"] = style

        self.children = []
        self.content_items = []

        # -------------------------------
        #  Process allowed children
        # -------------------------------
        for key, cls in self.ALLOWED_CHILDREN.items():
            value = kwargs.get(key)
            if value is not None:
                if isinstance(value, str):
                    child = cls(src=value)
                elif isinstance(value, dict):
                    child = cls(**value)
                elif hasattr(value, "render"):
                    child = value
                else:
                    raise TypeError(f"Error: '{key}' attribute must be str, dict, or renderable")
                self.children.append(child)
                CSSRegistry.register_block(child)

        # -------------------------------
        #  Process content items (ctn_*)
        # -------------------------------
        content_items = ContentFactory.create_from_kwargs(**kwargs)
        self.content_items.extend(content_items)

        # -------------------------------
        #  Register self if has id/class/style
        # -------------------------------
        if self.attrs or self.content_items or self.children:
            CSSRegistry.register_block(self)

    # -------------------------------
    #  Render
    # -------------------------------
    def render(self, indent=0):
        space = " " * indent
        attr_text = "".join(f' {k}="{v}"' if v is not True else f' {k}' for k, v in self.attrs.items())
        html = f"{space}<{self.tag}{attr_text}>\n"

        # Render content items first
        for item in self.content_items:
            html += item.render(indent + 2)

        # Then allowed children
        for child in self.children:
            html += child.render(indent + 2)

        html += f"{space}</{self.tag}>\n"
        return html


# ===============================
#      Concrete Specials
# ===============================

class Video(SpecialElement):
    tag = "video"
    ALLOWED_CHILDREN = {"source": Source, "track": Track}

    def __init__(self, *, source=None, track=None, **attrs):
        super().__init__(id=attrs.pop("id", None),
                         class_=attrs.pop("class_", None),
                         style=attrs.pop("style", None),
                         source=source,
                         track=track,
                         **attrs)


class Audio(SpecialElement):
    tag = "audio"
    ALLOWED_CHILDREN = {"source": Source, "track": Track}

    def __init__(self, *, source=None, track=None, **attrs):
        super().__init__(id=attrs.pop("id", None),
                         class_=attrs.pop("class_", None),
                         style=attrs.pop("style", None),
                         source=source,
                         track=track,
                         **attrs)


class Picture(SpecialElement):
    tag = "picture"
    ALLOWED_CHILDREN = {"source": Source, "img": Img}

    def __init__(self, *, source=None, img=None, **attrs):
        super().__init__(id=attrs.pop("id", None),
                         class_=attrs.pop("class_", None),
                         style=attrs.pop("style", None),
                         source=source,
                         img=img,
                         **attrs)


class ObjectElement(SpecialElement):
    tag = "object"
    ALLOWED_CHILDREN = {"param": Param}

    def __init__(self, *, param=None, **attrs):
        super().__init__(id=attrs.pop("id", None),
                         class_=attrs.pop("class_", None),
                         style=attrs.pop("style", None),
                         param=param,
                         **attrs)


# ===============================
#      Lowercase aliases
# ===============================

def video(*args, **kwargs):
    return Video(*args, **kwargs)

def audio(*args, **kwargs):
    return Audio(*args, **kwargs)

def picture(*args, **kwargs):
    return Picture(*args, **kwargs)

def Object(*args, **kwargs):
    return ObjectElement(*args, **kwargs)
