# pygame Extension core modules

Common core modules to simplify Pygame development.
