### COMMON

DEFAULT_FRAMERATE = 60

### TEXT

# number of seconds to keep typewriter text
# on the screen after typing is complete
DEFAULT_TYPEWRITER_KEEPALIVE = 3

# typewriter typing speed. from 0 -> MAX_TEXT_SPEED,
# with 0 displaying the entire text at once
DEFAULT_TEXT_SPEED = 3
MAX_TEXT_SPEED = 5
