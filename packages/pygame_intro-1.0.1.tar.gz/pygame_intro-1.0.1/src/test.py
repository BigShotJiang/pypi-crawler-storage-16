# This is a practical test script for the pygame-intro library.
# It runs the intro to verify basic functionality and to check that it does not throw an error.

import sys,os
import pygame
from intro import init, settings, change_image, change_sound, change_background, start


os.environ["SDL_AUDIODRIVER"] = "dummy"
os.environ["SDL_VIDEODRIVER"] = "dummy"

try:
    print("[1] Initializing Pygame...")
    pygame.init()

    print("[2] Creating hidden window...")
    pygame.display.set_mode((400, 300))

    print("[3] Initializing intro system...")
    init()

    print("[4] Applying intro settings...")
    settings(duration=1, fade_in=0.5, fade_out=0.5, scale=0.7, progress_bar=True, skippable=True)

    print("[5] Changing intro image...")
    change_image("data/pygame.png")

    print("[6] Changing intro sound...")
    change_sound("data/intro.mp3",1)

    print("[6] Changing background color...")
    change_background((60, 40, 80))

    print("[7] Starting intro sequence...")
    start()  # ~1 second

    print("[8] Quitting pygame...")
    pygame.quit()

    print("[PASS] Test complete. No errors detected.")
    sys.exit(0)

except Exception as e:
    print("[FAIL] Test failed with exception:")
    print(f"        {type(e).__name__}: {e}")
    sys.exit(1)
