# pygame-intro

A minimal Python library to create intros for `[pygame community edition](https://github.com/pygame-community/pygame-ce)`.

## Features

- Load and display custom images/frames
- Load and play custom sounds
- Progress bar and skippable intro options
- Customizable: duration, fade-in/fade-oud and scaling
- Async support for pygbag compatibility
- Set background (color or image/surface)

## Getting Started

Install:
```bash
pip install pygame_intro
```

Example usage:
```python
import pygame
import pygame_intro

pygame.init()
pygame_intro.init()

# custom settings (optional)
pygame_intro.settings(duration=2, fade_in=0.25, fade_out=1, scale=0.7, progress_bar=True, skippable=True)

# change intro data (optional)
pygame_intro.change_image("data/pygame.png")
pygame_intro.change_sound("data/intro.ogg", 0.7)
pygame_intro.change_background((30, 30, 30))

pygame_intro.start()
```

## License

This project is licensed under the MIT License.  
See the [`LICENSE`](LICENSE.txt) file for the full license text.

**Note:** Some files (such as images or audio) may be subject to different licenses or third-party terms.  
See [`data/license.txt`](src/data/LICENSES.txt) for more information.
