<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="medieval_tilesheet" tilewidth="64" tileheight="64" spacing="32" margin="32" tilecount="126" columns="18">
 <image source="medieval_tilesheet.png" width="1760" height="704"/>
</tileset>
