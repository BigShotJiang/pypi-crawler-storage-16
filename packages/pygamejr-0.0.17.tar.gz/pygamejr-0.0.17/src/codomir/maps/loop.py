from ..resources.resolve_path import resolve_path

map1 =  resolve_path('kenney_sokoban/map_loop1.tmx')
map2 = resolve_path('kenney_sokoban/map_loop2.tmx')
map3 = resolve_path('kenney_sokoban/map_loop3.tmx')
map4 = resolve_path('kenney_sokoban/map_loop4.tmx')
map5 = resolve_path('kenney_sokoban/map_loop5.tmx')
map6 = resolve_path('kenney_sokoban/map_loop6.tmx')