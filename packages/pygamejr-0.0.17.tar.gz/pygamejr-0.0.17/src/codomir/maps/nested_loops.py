from ..resources.resolve_path import resolve_path

map1 = resolve_path('kenney_sokoban/map_loop_nested1.tmx')
map2 = resolve_path('kenney_sokoban/map_loop_nested2.tmx')