<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="sokoban_tilesheet" tilewidth="64" tileheight="64" tilecount="104" columns="13">
 <image source="Tilesheet/sokoban_tilesheet.png" width="832" height="512"/>
 <tile id="13" type="Spawn"/>
 <tile id="26" type="Spawn"/>
 <tile id="39" type="Spawn"/>
 <tile id="74" type="Win"/>
 <tile id="75" type="Win"/>
</tileset>
