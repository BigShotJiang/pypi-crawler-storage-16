from .resolve_path import resolve_path

tank_blue = resolve_path('images/topdown_tanks/tank_blue.png')
tank_dark = resolve_path('images/topdown_tanks/tank_dark.png')
tank_green = resolve_path('images/topdown_tanks/tank_green.png')
tank_red = resolve_path('images/topdown_tanks/tank_red.png')

tree_green = resolve_path('images/topdown_tanks/treeGreen_large.png')
tree_green_small = resolve_path('images/topdown_tanks/treeGreen_small.png')
tree_brown = resolve_path('images/topdown_tanks/treeBrown_large.png')
tree_brown_small = resolve_path('images/topdown_tanks/treeBrown_small.png')
