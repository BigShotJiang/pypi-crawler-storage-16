from os.path import dirname, join

static: str = join(dirname(__file__), "static")
