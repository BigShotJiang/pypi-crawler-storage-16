"""Configuration module for pygitzen."""

from .keybindings import KeybindingConfig

__all__ = ["KeybindingConfig"]

