"""Styles directory for pygitzen CSS files."""

