pyglet.customtypes
==================

.. automodule:: pyglet.customtypes
  :members:
  :undoc-members:

.. autodata:: Buffer

.. autodata:: HorizontalAlign

.. autodata:: AnchorX

.. autodata:: AnchorY

.. autodata:: ContentVAlign
