pyglet.event
============

.. automodule:: pyglet.event
  :members:
  :undoc-members:
