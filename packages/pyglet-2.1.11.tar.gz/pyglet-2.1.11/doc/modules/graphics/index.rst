pyglet.graphics
===============

.. rubric:: Submodules

.. toctree::
   :maxdepth: 1

   allocation
   shader
   vertexbuffer
   vertexdomain

.. rubric:: Details

.. automodule:: pyglet.graphics
  :members:
  :undoc-members:
