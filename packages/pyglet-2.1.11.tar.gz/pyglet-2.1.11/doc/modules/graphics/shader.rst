pyglet.graphics.shader
======================

.. automodule:: pyglet.graphics.shader
  :members:
  :undoc-members: