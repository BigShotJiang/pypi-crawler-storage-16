pyglet.graphics.vertexdomain
============================

.. automodule:: pyglet.graphics.vertexdomain
  :members:
  :undoc-members:
