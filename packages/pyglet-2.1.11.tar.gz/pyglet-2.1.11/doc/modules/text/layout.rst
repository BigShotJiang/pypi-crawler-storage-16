pyglet.text.layout
==================

.. automodule:: pyglet.text.layout
  :members:
  :undoc-members:
  :exclude-members: group_class, decoration_class
