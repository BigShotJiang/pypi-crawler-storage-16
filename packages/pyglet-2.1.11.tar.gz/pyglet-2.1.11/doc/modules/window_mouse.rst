pyglet.window.mouse
===================

.. automodule:: pyglet.window.mouse
    :members:
