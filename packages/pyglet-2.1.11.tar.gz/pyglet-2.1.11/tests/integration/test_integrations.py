# Don't delete.
# This file allows some IDE's to run integration as a single test if needed.