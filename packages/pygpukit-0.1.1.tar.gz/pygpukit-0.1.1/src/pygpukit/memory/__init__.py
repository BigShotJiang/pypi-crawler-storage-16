"""Memory management module for PyGPUkit."""
