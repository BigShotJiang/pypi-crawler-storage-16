
A python library for reading EdgeTech JSF sonar files (Rev. P)