# -*- coding: utf-8 -*-
"""
Created on Tue Dec  9 08:33:08 2025

@author: Simon_V
"""

import enum
import ctypes
import numpy as np

class JSFEnums:
    class Variables:
        message_header_length = 16
        trace_header_length = 240
        date_format = '%Y-%m-%d %H:%M:%S.%f'
        byte_order = 'little'
    
    @enum.unique
    class Subsystems(enum.Enum):
        subbottom = 0
        lf_sss = 20
        hf_sss = 21
        vhf_sss = 22
        lf_mbes = 40
        hf_mbes = 41
        vhf_mbes = 42
        lf_mt_mbes = 70
        hf_mt_mbes = 71
        vhf_mt_mbes = 72
        raw_serial = 100
        parsed_serial = 101
        gap_filler = 120
    
    @enum.unique
    class MessageTypes(enum.Enum):
        # Acoustic messages
        sonar_data_message = 80
        # Other messages
        sonar_message_status = 40
        navigation_offsets = 181
        system_information = 182
        target_file_data = 1260
        # Auxiliary messages
        nmea_string = 2002
        pitch_roll_data = 2020
        misc_analogue = 2040 #docs say ignore
        pressure_sensor_reading = 2060
        reflection_coefficient = 2071
        doppler_velocity_log = 2080
        situation_comprehensive = 2091
        cable_counter = 2100
        km_pipe = 2101
        container_timestamp = 2111
        # Bathymetric messages
        bathymetric_data = 3000
        altitude_message1 = 3001
        pressure_message = 3002
        altitude_message2 = 3003
        position_message = 3004
        status_message = 3005
        bathymetric_parameter_message = 3041
        # Beamformed messages
        boss_beamformed_volume_data = 4000
        edpmsg_nav = 4034
        
        
class JSFMessages:
    class Base(ctypes.Structure):
        def __init__(self):
            super().__init__()
        
        def _to_bytes(self):
            return bytes(self)
        
        def _size(self):
            return len(bytes(self))
        
        def _values(self):
            fields = [self._fields_[i][0] for i in range(len(self._fields_))]
            string = ''
            for field_name in fields:
                if not field_name.startswith('_') and not field_name.endswith('_'):
                    field_value = getattr(self, field_name)
                    string += f"{field_name}: {field_value} \n"
            return string
        
        def __str__(self):
            return self._values()
        
        def int_to_bytes(self, b, start, end, signed):
            return int.from_bytes(b[start:end], byteorder=JSFEnums.Variables.byte_order, signed=signed)

        
    class UnknownHeader(Base):
        _pack_ = 1
        _fields_ = []
    
    class MessageHeader(Base):
        _pack_ = 1
        _fields_ = [
            ('header_start', ctypes.c_uint16),
            ('protocol_version', ctypes.c_uint8),
            ('session_id', ctypes.c_uint8),
            ('message_type', ctypes.c_uint16),
            ('command_type', ctypes.c_uint8),
            ('subsystem_number', ctypes.c_uint8),
            ('channel_number', ctypes.c_uint8),
            ('sequence_number', ctypes.c_uint8),
            ('reserved', ctypes.c_uint16),
            ('message_size', ctypes.c_int32),
        ]

    class TraceHeader(Base):
        _pack_ = 1
        _fields_ = [
            ## data format block
            ('ping_time', ctypes.c_int32),
            ('starting_depth', ctypes.c_uint32),
            ('ping_number', ctypes.c_uint32),
            ('reserved1', ctypes.c_int16),
            ('reserved2', ctypes.c_int16),
            ('msb', ctypes.c_uint16),
            ('lsb', ctypes.c_uint16),
            ('lsb2', ctypes.c_uint16),
            ('reserved3', ctypes.c_int16),
            ('reserved4', ctypes.c_int16),
            ('reserved5', ctypes.c_int16),
            ('id_code', ctypes.c_int16),
            ('validity_flag', ctypes.c_uint16),
            ('reserved6', ctypes.c_uint16),
            ('data_format', ctypes.c_int16),
            ('antenna_tow_distance1', ctypes.c_int16),
            ('antenna_tow_distance2', ctypes.c_int16),
            ('reserved7', ctypes.c_int16),
            ('reserved8', ctypes.c_int16),
            ## nav data block
            ('km_pipe', ctypes.c_float),
            ('heave_metres', ctypes.c_float),
            ('reserved9', ctypes.c_int16),
            ('reserved10', ctypes.c_int16),
            ('reserved11', ctypes.c_int16),
            ('reserved12', ctypes.c_int16),
            ('reserved13', ctypes.c_int16),
            ('reserved14', ctypes.c_int16),
            ('reserved15', ctypes.c_int16),
            ('reserved16', ctypes.c_int16),
            ('reserved17', ctypes.c_int16),
            ('reserved18', ctypes.c_int16),
            ('reserved19', ctypes.c_int16),
            ('reserved20', ctypes.c_int16),
            ('reserved21', ctypes.c_int16),
            ('reserved22', ctypes.c_int16),
            ('longitude', ctypes.c_int32),
            ('latitude', ctypes.c_int32),
            ('coordinate_units', ctypes.c_int16),
            ## pulse info block
            ('annotation_string', ctypes.c_char*24),
            ('number_samples', ctypes.c_uint16),
            ('sampling_interval', ctypes.c_uint32),
            ('adc_gain_factor', ctypes.c_uint16),
            ('user_transmit_level', ctypes.c_int16),
            ('reserved23', ctypes.c_int16),
            ('pulse_start_freq', ctypes.c_uint16),
            ('pulse_end_freq', ctypes.c_uint16),
            ('sweep_length', ctypes.c_uint16),
            ('pressure', ctypes.c_int32),
            ('depth', ctypes.c_int32),
            ('sample_frequency', ctypes.c_uint16),
            ('outgoing_pulse', ctypes.c_uint16),
            ('altitude', ctypes.c_int32),
            ('sound_speed', ctypes.c_float),
            ('mixer_freq', ctypes.c_float),
            # CPU time block
            ('year', ctypes.c_int16),
            ('day', ctypes.c_int16),
            ('hour', ctypes.c_int16),
            ('minute', ctypes.c_int16),
            ('second', ctypes.c_int16),
            ('time_basis', ctypes.c_int16),
            # Weighting factor block
            ('weighting_factor', ctypes.c_int16),
            ('number_pulses', ctypes.c_int16),
            # Orientation data block
            ('compass_heading', ctypes.c_uint16),
            ('pitch', ctypes.c_int16),
            ('roll', ctypes.c_int16),
            ('reserved24', ctypes.c_int16),
            # Trigger information block
            ('reserved25', ctypes.c_int16),
            ('trigger_source', ctypes.c_int16),
            ('mark_number', ctypes.c_uint16),
            # NMEA navigation block
            ('position_fix_hour', ctypes.c_int16),
            ('position_fix_min', ctypes.c_int16),
            ('position_fix_sec', ctypes.c_int16),
            ('heading', ctypes.c_int16),
            ('speed', ctypes.c_int16),
            ('position_fix_day', ctypes.c_int16),
            ('position_fix_year', ctypes.c_int16),
            # Misc data block
            ('milliseconds', ctypes.c_uint32),
            ('adc_max_value', ctypes.c_uint16),
            ('reserved26', ctypes.c_int16),
            ('reserved27', ctypes.c_int16),
            ('sonar_software_version_string', ctypes.c_char*6),
            ('init_sph_corr_factor', ctypes.c_int32),
            ('packet_number', ctypes.c_uint16),
            ('adc_decimation', ctypes.c_int16),
            ('reserved28', ctypes.c_int16),
            ('water_temp', ctypes.c_int16),
            ('layback', ctypes.c_float),
            ('reserved29', ctypes.c_int32),
            ('cable_out', ctypes.c_uint16),
            ('reserved30', ctypes.c_uint16),
        ]

    class TraceData:
        def __init__(self, data: np.ndarray):
            self.data = data
            
        def _to_bytes(self):
            return self.data.astype(np.int16).tobytes()
            
        def _size(self):
            return len(self.data.astype(np.int16).tobytes())
    
        def apply_weighting(self, weight: int):
            return self.data * (2 ** -weight)

    
    class PressureSensorReading(Base):
        _pack_ = 1
        _fields_ = [
            ('ping_time', ctypes.c_int32),
            ('milliseconds', ctypes.c_int32),
            ('reserved1', ctypes.c_uint8),
            ('reserved2', ctypes.c_uint8),
            ('reserved3', ctypes.c_uint8),
            ('reserved4', ctypes.c_uint8),
            ('pressure', ctypes.c_int32), # in 1/1000th of a PSI
            ('temperature', ctypes.c_int32), # in 1/1000th of a degree celcius
            ('salinity', ctypes.c_int32), # in ppm
            ('validity_flag', ctypes.c_int32),
            ('conductivity', ctypes.c_int32), # in micro-siemens per centimetre
            ('sound_velocity', ctypes.c_int32), # in mm/s
            ('depth', ctypes.c_int32), # in metres
            ('reserved5', ctypes.c_int32),
            ('reserved6', ctypes.c_int32),
            ('reserved7', ctypes.c_int32),
            ('reserved8', ctypes.c_int32),
            ('reserved9', ctypes.c_int32),
            ('reserved10', ctypes.c_int32),
            ('reserved11', ctypes.c_int32),
            ('reserved12', ctypes.c_int32),
            ('reserved13', ctypes.c_int32),
        ]
    
    class NMEAString(Base):
        def __init__(self, raw_bytes: bytes):
            self.ping_time = self.int_to_bytes(raw_bytes, 0, 4, True)
            self.milliseconds = self.int_to_bytes(raw_bytes, 4, 8, True)
            self.source = self.int_to_bytes(raw_bytes, 8, 9, False)
            self.reserved1 = self.int_to_bytes(raw_bytes, 9, 10, False)
            self.reserved2 = self.int_to_bytes(raw_bytes, 10, 11, False)
            self.reserved3 = self.int_to_bytes(raw_bytes, 11, 12, False)
            self.nmea_string = self.int_to_bytes(raw_bytes, 12, len(raw_bytes), True)
            self.nmea_string = np.array([int(x) for x in str(self.nmea_string)])
    
    class PitchRollData(Base):
        _pack_ = 1
        _fields_ = [
            ('ping_time', ctypes.c_int32),
            ('milliseconds', ctypes.c_int32),
            ('reserved1', ctypes.c_uint8),
            ('reserved2', ctypes.c_uint8),
            ('reserved3', ctypes.c_uint8),
            ('reserved4', ctypes.c_uint8),
            ('acceleration_x', ctypes.c_int16), # Multiply by (20 * 1.5) / (32768) to get Gs
            ('acceleration_y', ctypes.c_int16), # Multiply by (20 * 1.5) / (32768) to get Gs
            ('acceleration_z', ctypes.c_int16), # Multiply by (20 * 1.5) / (32768) to get Gs
            ('rate_gyro_x', ctypes.c_int16), # Multiply by (500 * 1.5) / (32768) to get Degrees/Sec
            ('rate_gyro_y', ctypes.c_int16), # Multiply by (500 * 1.5) / (32768) to get Degrees/Sec
            ('rate_gyro_z', ctypes.c_int16), # Multiply by (500 * 1.5) / (32768) to get Degrees/Sec
            ('pitch', ctypes.c_int16), # Multiply by (180.0 / 32768.0) to get Degrees, Bow up is positive
            ('roll', ctypes.c_int16), # : Multiply by (180.0 / 32768.0) to get Degrees. Port up is positive
            ('temperature', ctypes.c_int16), #  1/10 of a Degree Celsius
            ('device_specific_info', ctypes.c_uint16), 
            ('estimated_heave', ctypes.c_int16), # mm, positive is down
            ('heading', ctypes.c_uint16), # 0.01 Degrees (0...360)
            ('validity_flag', ctypes.c_int32),
            ('yaw', ctypes.c_int16), # 0.01 Degrees (0...360)
            ('reserved5', ctypes.c_int16),
        ]
