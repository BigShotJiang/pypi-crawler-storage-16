# -*- coding: utf-8 -*-
"""
Created on Tue Dec  9 08:34:28 2025

@author: Simon_V
"""


from typing import List
from pathlib import Path
from time import time
import warnings

import numpy as np

from pyjsf.jsf_ctypes import JSFMessages, JSFEnums

def jsf_read(path: str | Path,
             subsystems: List[str] = None,
             message_types: List[str] = None,
             verbose: bool = False,
             ) -> List[tuple]:
    """
    Reads the file, extracts the subsystem number and message type from each message header and reads
    into the corresponding message type class.
    Mandatory weighting is applied to each sonar data message
    :param subsystems: select which subsystems to read (e.g. hf_sss), defaults to all
    :param message_types: select which message types to read (e.g. sonar data message),
    defaults to all
    :return: List of tuples, each with the header message and associated data messages 
    """
    messages = []
    message_number = 0
    with open(path, "rb") as f:
        if verbose:
            time_start = time()
            print(f'Reading file {path}...')
        while True:
            # iterate through the file, starting with thw first MessageHeader
            message_header = JSFMessages.MessageHeader()
            f.readinto(message_header)
            if message_header.message_size == 0:
                # signifies EOF
                if verbose:
                    duration = round(time() - time_start, 4)
                    print(f' Read {message_number} messages in {duration} s')
                break
            
            if message_header.header_start != 5633:
                # check for correct MessageHeader identifier
                raise RuntimeError(
                    'Message header does not start with the correct identifier (0x1601)')

            if message_header.subsystem_number in [n.value for n in JSFEnums.Subsystems]:
                # check if known subsystem
                subsystem = JSFEnums.Subsystems(
                    message_header.subsystem_number).name
            else:
                subsystem = 'unknown'
            if message_header.message_type in [n.value for n in JSFEnums.MessageTypes]:
                # check if known message type
                message_type = JSFEnums.MessageTypes(
                    message_header.message_type).name
            else:
                message_type = 'unknown'
            if ((subsystems is not None and subsystem not in subsystems) or
                    (message_types is not None and message_type not in message_types)):
                # skip read if not explicitly selected
                f.seek(message_header.message_size, 1)
                continue

            if verbose:
                print(f'Reading {subsystem} - {message_type}', end='')

            if subsystem == 'unknown' or message_type == 'unknown':
                # skip read if unknown
                if verbose:
                    print(' - not supported')
                f.seek(message_header.message_size, 1)
                message_number += 1
                continue
            if message_header.message_type == JSFEnums.MessageTypes['sonar_data_message'].value:
                # read sonar data
                if verbose:
                    print(' - reading data...', end='')
                try:
                    # read trace data
                    trace_header = JSFMessages.TraceHeader()
                    f.readinto(trace_header)
                    # read trace data
                    trace_data_bytes = f.read(
                        message_header.message_size - JSFEnums.Variables.trace_header_length)
                    trace_data = JSFMessages.TraceData(
                        np.frombuffer(trace_data_bytes, dtype=np.int16))
                    # applymandatory  weighting factor to trace data
                    trace_data = trace_data.apply_weighting(
                        trace_header.weighting_factor)
                    # append as tuple to message output list
                    messages += [(message_header, trace_header, trace_data)]
                    if verbose:
                        print(' success')
                except Exception as e:
                    # show exception if failed to read message correctly and skip to next
                    f.seek(message_header.message_size, 1)
                    if verbose:
                        print(f' failed, {e}')

            elif message_header.message_type == JSFEnums.MessageTypes['pressure_sensor_reading'].value:
                if verbose:
                    print(' - reading data...', end='')
                try:
                    pressure_sensor_reading = JSFMessages.PressureSensorReading()
                    f.readinto(pressure_sensor_reading)
                    messages += [(message_header, pressure_sensor_reading)]
                    if verbose:
                        print(' success')
                except Exception as e:
                    f.seek(message_header.message_size, 1)
                    if verbose:
                        print(f' failed, {e}')

            elif message_header.message_type == JSFEnums.MessageTypes['nmea_string'].value:
                if verbose:
                    print(' - reading data...', end='')
                try:
                    nmea_string = JSFMessages.NMEAString(
                        f.read(message_header.message_size))
                    messages += [(message_header, nmea_string)]
                    if verbose:
                        print(' success')
                except Exception as e:
                    f.seek(message_header.message_size, 1)
                    if verbose:
                        print(f' failed, {e}')
                        
            elif message_header.message_type == JSFEnums.MessageTypes['pitch_roll_data'].value:
                if verbose:
                    print(' - reading data...', end='')
                try:
                    pitch_roll_data = JSFMessages.PitchRollData()
                    f.readinto(pitch_roll_data)
                    messages += [(message_header, pitch_roll_data)]
                    if verbose:
                        print(' success')
                except Exception as e:
                    f.seek(message_header.message_size, 1)
                    if verbose:
                        print(f' failed, {e}')
            else:
                if verbose:
                    print(' - not supported')
                f.seek(message_header.message_size, 1)
            message_number += 1
    
    if len(messages) == 0:
        # warn if no messages returned i.e. file is empty
        warnings.warn('File contains no data', RuntimeWarning)
    
    return messages


if __name__ == '__main__':
    import matplotlib.pyplot as plt
    file_path = Path(
        r"D:\Working_data\sonar_testing\test_data\dpaa_dodgy_jsf\20250907113441.jsf")

    messages = jsf_read(file_path,
                        # subsystems=['hf_mbes'],
                        verbose=True,
    )

    # plt.plot(messages[0][2].data)

    # for m in messages:
    # print(m.message_type)
