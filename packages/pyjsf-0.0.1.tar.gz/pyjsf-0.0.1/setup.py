# -*- coding: utf-8 -*-
"""
Created on Tue Dec  9 15:28:02 2025

@author: Simon_V
"""

import setuptools

with open("README.md", "r") as fh:
    description = fh.read()

setuptools.setup(
    name="pyjsf",
    version="0.0.1",
    author="Simon Varley",
    author_email="actingthegroat@proton.me",
    packages=setuptools.find_packages(),
    description="A python library for reading EdgeTech JSF sonar files",
    long_description=description,
    long_description_content_type="text/markdown",
    url="https://codeberg.org/actingthegroat/pyjsf",
    license='MIT',
    python_requires='>=3.8',
    install_requires=['numpy']
)