def hello():
    print("Hello Kal!")