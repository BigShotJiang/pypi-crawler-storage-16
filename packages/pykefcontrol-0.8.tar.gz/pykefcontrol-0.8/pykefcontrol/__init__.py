from pykefcontrol.kef_connector import KefConnector, KefAsyncConnector

__version__ = "0.8"
