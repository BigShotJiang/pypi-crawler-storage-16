# pylegendmeta

[![PyPI](https://img.shields.io/pypi/v/pylegendmeta?logo=pypi)](https://pypi.org/project/pylegendmeta/)
![GitHub tag (latest by date)](https://img.shields.io/github/v/tag/legend-exp/pylegendmeta?logo=git)
[![GitHub Workflow Status](https://img.shields.io/github/checks-status/legend-exp/pylegendmeta/main?label=main%20branch&logo=github)](https://github.com/legend-exp/pylegendmeta/actions)
[![pre-commit](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit&logoColor=white)](https://github.com/pre-commit/pre-commit)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)
[![Codecov](https://img.shields.io/codecov/c/github/legend-exp/pylegendmeta?logo=codecov)](https://app.codecov.io/gh/legend-exp/pylegendmeta)
![GitHub issues](https://img.shields.io/github/issues/legend-exp/pylegendmeta?logo=github)
![GitHub pull requests](https://img.shields.io/github/issues-pr/legend-exp/pylegendmeta?logo=github)
![License](https://img.shields.io/github/license/legend-exp/pylegendmeta)
[![Read the Docs](https://img.shields.io/readthedocs/pylegendmeta?logo=readthedocs)](https://pylegendmeta.readthedocs.io)

Access [legend-metadata](https://github.com/legend-exp/legend-metadata) through
[dbetto](https://dbetto.readthedocs.io).
