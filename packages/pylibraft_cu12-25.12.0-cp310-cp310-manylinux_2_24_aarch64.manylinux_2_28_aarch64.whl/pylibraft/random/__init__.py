# SPDX-FileCopyrightText: Copyright (c) 2022, NVIDIA CORPORATION.
# SPDX-License-Identifier: Apache-2.0
#

from .rmat_rectangular_generator import rmat

__all__ = ["rmat"]
