# SPDX-FileCopyrightText: Copyright (c) 2024, NVIDIA CORPORATION.
# SPDX-License-Identifier: Apache-2.0
#

from .lanczos import eigsh

__all__ = ["eigsh"]
