import time
import functools
from typing import Optional, Dict, Callable
from contextlib import ContextDecorator
from .aggregator import LockFreeMetricsAggregator, MetricType

class ZeroContentionTimer(ContextDecorator):
    """
    Timer that sends metrics to the lock-free aggregator.
    Each timing operation uses thread-local storage to avoid contention.
    """
    
    def __init__(
        self,
        name: str,
        aggregator: Optional[LockFreeMetricsAggregator] = None,
        tags: Optional[Dict[str, str]] = None,
        enabled: bool = True
    ) -> None:
        self.name = name
        self.aggregator = aggregator or LockFreeMetricsAggregator()
        self.tags = tags or {}
        self.enabled = enabled
        self._start_time: Optional[float] = None
    
    def __enter__(self) -> 'ZeroContentionTimer':
        if self.enabled:
            self._start_time = time.perf_counter()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        if self.enabled and self._start_time is not None:
            elapsed = time.perf_counter() - self._start_time
            final_tags = {**self.tags, 'error': 'true' if exc_type else 'false'}
            
            self.aggregator.add_metric(
                name=self.name,
                value=elapsed,
                metric_type=MetricType.TIMER,
                tags=final_tags
            )
        return False

def fast_timer(name: str, **kwargs) -> ZeroContentionTimer:
    """Factory function for creating zero-contention timers."""
    return ZeroContentionTimer(name, **kwargs)