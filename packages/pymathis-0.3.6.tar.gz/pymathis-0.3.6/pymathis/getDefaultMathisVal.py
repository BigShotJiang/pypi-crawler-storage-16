import pymathis as pm
pm.LoadDll(pm.__file__, 'default')