********************
Statespace Core
********************

.. automodule:: pymc_extras.statespace.core
.. autosummary::
   :toctree: generated

    PytensorRepresentation
    PyMCStateSpace
