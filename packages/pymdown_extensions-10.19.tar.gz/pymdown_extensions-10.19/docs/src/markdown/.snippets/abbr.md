*[Toc]: Table of Contents
*[GFM]: GitHub Flavored Markdown
*[FAQ]: Frequent Asked Questions
