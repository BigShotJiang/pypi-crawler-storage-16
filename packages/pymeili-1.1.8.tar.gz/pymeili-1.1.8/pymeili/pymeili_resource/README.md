# pymeili_resource
online resources files' location for python package "pymeili"
