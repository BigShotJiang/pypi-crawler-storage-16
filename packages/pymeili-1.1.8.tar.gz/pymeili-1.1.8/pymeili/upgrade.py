import os

os.system('pip install --upgrade pymeili')