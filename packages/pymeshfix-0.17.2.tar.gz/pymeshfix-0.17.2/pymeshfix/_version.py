"""pymeshfix version.

On the ``master`` branch, use 'dev0' to denote a development version.
For example:

version_info = 0, 18, "dev0"

"""

version_info = 0, 17, 2
__version__ = ".".join(map(str, version_info))
