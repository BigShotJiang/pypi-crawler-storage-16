# data533_group6_step3

A cocktail inventory and recommendation package.

## Installation

You can install `pymixology` from PyPI:

```bash
pip install pymixology
```

View the project on PyPI: [https://pypi.org/project/pymixology/](https://pypi.org/project/pymixology/)
