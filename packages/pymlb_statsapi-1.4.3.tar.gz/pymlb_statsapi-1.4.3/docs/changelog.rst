Changelog
=========

Version 0.2.0 (Upcoming)
------------------------

- Clean API refactor: Direct parameter passing
- Schema introspection methods
- Parameter name preservation
- Comprehensive documentation
- GitHub Actions CI/CD
- ReadTheDocs integration

Version 0.1.x
-------------

Initial releases with basic functionality.
