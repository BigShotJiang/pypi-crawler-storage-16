License
=======

MIT License - See LICENSE file in repository.
