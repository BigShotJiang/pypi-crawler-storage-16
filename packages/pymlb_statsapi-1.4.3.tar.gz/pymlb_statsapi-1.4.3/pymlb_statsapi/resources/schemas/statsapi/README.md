# pymlb_statsapi/resources/schemas/statsapi

If ever we get a new version of the api from 1.0,
make a new and bumped version from `stats-api-1.0`

To create a valid name for the package and imports, replace all hyphens and periods with underscore.
- `stats-api-1.0` -> `stats_api_1_0`
