def hello():
    """
    print message to indicate that pymlt package is imported
    """
    print("hello from pymlt/__init__.py")
