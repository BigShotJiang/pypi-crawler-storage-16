import logging
from packaging import version as version_mod
import sys
import subprocess

from enum import Enum
import numpy as np
from qtpy import QtWidgets, QtCore
from qtpy.QtCore import Qt, Slot, Signal
from qtpy.QtGui import QTextCursor
from readme_renderer.rst import render

from pymodaq_plugin_manager.validate import get_plugins
from pymodaq_plugin_manager.validate import get_pypi_pymodaq, get_package_metadata
from pymodaq_plugin_manager import __version__ as version
from pymodaq_plugin_manager.utils import QVariant, TableModel, TableView, SpinBoxDelegate, get_pymodaq_version

logger = logging.getLogger(__name__)
logger.addHandler(logging.StreamHandler())


class TableModel(TableModel):
    """Specific Model to display plugins info in a TableView"""
    def __init__(self, *args, plugins=[], **kwargs):
        super().__init__(*args, **kwargs)
        self._selected = [False for ind in range(len(self._data))]
        self.plugins = plugins

    @property
    def selected(self):
        return self._selected

    def flags(self, index):
        f = super().flags(index)
        if index.column() == 0:
            f |= Qt.ItemFlag.ItemIsUserCheckable            
        return f

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if index.isValid():
            if role == Qt.ItemDataRole.DisplayRole or role == Qt.ItemDataRole.EditRole:
                if index.column() == 0:
                    dat = self._data[index.row()][0]
                else:
                    dat = self._data[index.row()][index.column()]
                return dat
            elif role == Qt.ItemDataRole.CheckStateRole:
                if index.column() == 0:
                    if self._selected[index.row()]:
                        return Qt.CheckState.Checked
                    else:
                        return Qt.CheckState.Unchecked
        return QVariant()

    def setData(self, index, value, role):
        if index.isValid():
            if role == Qt.ItemDataRole.EditRole:
                if self.validate_data(index.row(), index.column(), value):
                    self._data[index.row()][index.column()] = value
                    self.dataChanged.emit(index, index, [role])
                    return True

                else:
                    return False
            if role == Qt.ItemDataRole.CheckStateRole:
                if index.column() == 0:
                    # Qt.Checked is an enum in qt6 but an int in qt5
                    # it can be directly compared in qt5 but getting
                    # the value attribute is needed with qt6
                    qt_checked =  Qt.CheckState.Checked.value
                    self._selected[index.row()] = value == qt_checked
                    self.dataChanged.emit(index, index, [role])
                    return True
        return False


class FilterProxy(QtCore.QSortFilterProxyModel):
    """Utility to filter the View"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.text = ''

    def filterAcceptsRow(self, sourcerow, parent_index):
        plugin_index = self.sourceModel().index(sourcerow, 0, parent_index)
        parent = self.parent()
        try:
            plugin = self.sourceModel().plugins[plugin_index.row()]
            match = self.text == ''
            if not (match or not plugin):
                if hasattr(parent, "filter_name_cb") and parent.filter_name_cb.isChecked():
                    match = match or self.text in plugin['plugin-name'].lower()
                    match = match or self.text in plugin['display-name'].lower()
                if hasattr(parent, "filter_description_cb") and parent.filter_description_cb.isChecked():
                    match = match or self.text in plugin['description'].lower()
                if hasattr(parent, "filter_instrument_cb") and parent.filter_instrument_cb.isChecked():                        
                    for plug in plugin['instruments']:
                        match = match | any(self.text in p.lower() for p in plugin['instruments'][plug])
            return match

        except Exception as e:
            print(e)
            return True

    def setTextFilter(self, regexp: str):
        self.text = regexp.lower()
        self.invalidateFilter()


class PluginFetcher(QtCore.QObject):

    plugins_signal = QtCore.Signal(tuple)
    print_signal = QtCore.Signal(str)

    def __init__(self):
        super().__init__()

    def fetch_plugins(self):
        plugins = get_plugins(False, pymodaq_version=get_pymodaq_version(),
                              print_method=self.print_signal.emit)
        self.plugins_signal.emit(plugins)


class PluginManager(QtCore.QObject):
    """Main UI to display a list of plugins and install/uninstall them

    Attempts to display plugins only compatible with the currently installed version of pymodaq
    """
    quit_signal = Signal()
    restart_signal = Signal()

    def __init__(self, parent, standalone=False):
        super().__init__()

        self.model_available: TableModel = None
        self.model_update: TableModel = None
        self.model_installed: TableModel = None

        self.plugins_available: list = None
        self.plugins_installed: list = None
        self.plugins_update: list = None

        self.parent = parent
        self.parent.setLayout(QtWidgets.QVBoxLayout())
        self.standalone = standalone

        self.setup_UI()
        self.enable_ui(False)

        self.plugin_thread = QtCore.QThread()
        plugin_fetcher = PluginFetcher()
        plugin_fetcher.plugins_signal.connect(self.setup_models)
        plugin_fetcher.print_signal.connect(self.print_info)
        plugin_fetcher.moveToThread(self.plugin_thread)
        self.plugin_thread.plugin_fetcher = plugin_fetcher
        self.plugin_thread.started.connect(plugin_fetcher.fetch_plugins)

        self.plugin_thread.start()

    def check_version(self, show=True):
        try:
            current_version = version_mod.parse(version)

            latest = get_package_metadata('pymodaq_plugin_manager')
            available_versions = list(latest['releases'].keys())[::-1]

            msgBox = QtWidgets.QMessageBox()
            if version_mod.parse(max(available_versions)) > current_version:
                msgBox.setText(f"A new version of PyMoDAQ Plugin Manager is available, {str(max(available_versions))}!")
                msgBox.setInformativeText("Do you want to install it?")
                msgBox.setStandardButtons(QtWidgets.QMessageBox.StandardButton.Ok |
                                          QtWidgets.QMessageBox.StandardButton.Cancel)
                msgBox.setDefaultButton(QtWidgets.QMessageBox.StandardButton.Ok)

                ret = msgBox.exec()

                if ret == QtWidgets.QMessageBox.StandardButton.Ok:
                    command = [sys.executable, '-m', 'pip', 'install', f'pymodaq-plugin-manager=={str(max(available_versions))}']
                    subprocess.Popen(command)

                    self.restart()
            else:
                if show:
                    msgBox.setText(f"Your version of PyMoDAQ Plugin Manager, {str(current_version)}, is up to date!")
                    ret = msgBox.exec()
        except Exception as e:
            logger.exception("Error while checking the available PyMoDAQ version")

    def quit(self):
        self.parent.parent().close()
        self.quit_signal.emit()

    def restart(self):
        self.parent.parent().close()
        if self.standalone:
            subprocess.call([sys.executable, __file__])
        else:
            self.restart_signal.emit()

    def enable_ui(self, enable=True):
        self.check_updates_pb.setEnabled(enable)
        self.plugin_choice.setEnabled(enable)
        self.search_edit.setEnabled(enable)

    def setup_UI(self):

        settings_widget = QtWidgets.QWidget()
        settings_widget.setLayout(QtWidgets.QHBoxLayout())
        self.plugin_choice = QtWidgets.QComboBox()
        self.plugin_choice.addItems(['Available', 'Update', 'Installed'])
        self.plugin_choice.currentTextChanged.connect(self.update_model)

        self.check_updates_pb = QtWidgets.QPushButton('Check Updates')
        self.check_updates_pb.clicked.connect(lambda: self.check_version(True))

        self.search_edit = QtWidgets.QLineEdit()
        self.search_edit.setPlaceholderText("Plugin name")

        settings_widget.layout().addWidget(self.plugin_choice)
        settings_widget.layout().addStretch()
        settings_widget.layout().addWidget(self.check_updates_pb)
        settings_widget.layout().addStretch()
        settings_widget.layout().addWidget(QtWidgets.QLabel('Search:'))
        settings_widget.layout().addWidget(self.search_edit)
        settings_widget.layout().addStretch()

        pymodaq_version = QtWidgets.QLabel(f'PyMoDAQ Version: {get_pymodaq_version()}')
        settings_widget.layout().addWidget(pymodaq_version)

        settings_widget.layout().addStretch()
        self.action_button = QtWidgets.QPushButton('Install')
        self.action_button.setEnabled(False)
        self.action_button.clicked.connect(self.do_action)
        settings_widget.layout().addWidget(self.action_button)

        self.parent.layout().addWidget(settings_widget)

        search_widget = QtWidgets.QWidget()
        search_widget.setLayout(QtWidgets.QHBoxLayout())
        search_widget.setSizePolicy(
            QtWidgets.QSizePolicy.Maximum, QtWidgets.QSizePolicy.Fixed
        )
        self.filter_options_cb = QtWidgets.QCheckBox("Search filter settings:")
        self.filter_options_cb.stateChanged.connect(self.show_filter_settings)
        search_widget.layout().addWidget(self.filter_options_cb)

        self.filter_name_cb = QtWidgets.QCheckBox('Name')
        self.filter_name_cb.setCheckState(Qt.CheckState.Checked)
        search_widget.layout().addWidget(self.filter_name_cb)

        self.filter_description_cb = QtWidgets.QCheckBox('Description')
        self.filter_description_cb.setCheckState(Qt.CheckState.Unchecked)
        search_widget.layout().addWidget(self.filter_description_cb)

        self.filter_instrument_cb = QtWidgets.QCheckBox('Instruments')
        self.filter_instrument_cb.setCheckState(Qt.CheckState.Unchecked)
        search_widget.layout().addWidget(self.filter_instrument_cb)

        self.parent.layout().addWidget(search_widget)

        splitter = QtWidgets.QSplitter(Qt.Vertical)

        self.table_view = TableView()

        styledItemDelegate = QtWidgets.QStyledItemDelegate()
        styledItemDelegate.setItemEditorFactory(SpinBoxDelegate())
        self.table_view.setItemDelegate(styledItemDelegate)
        self.table_view.horizontalHeader().show()
        self.table_view.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.ResizeToContents)

        self.info_widget = QtWidgets.QTextEdit()
        self.info_widget.setReadOnly(True)

        splitter.addWidget(self.table_view)
        splitter.addWidget(self.info_widget)

        self.parent.layout().addWidget(splitter)

        self.show_filter_settings(False)
        QtWidgets.QApplication.processEvents()

    def show_filter_settings(self,status):
        self.filter_instrument_cb.setVisible(status)
        self.filter_description_cb.setVisible(status)
        self.filter_name_cb.setVisible(status)

    def setup_models(self, plugins: tuple):
        self.plugins_available, self.plugins_installed, self.plugins_update = plugins

        self.model_available = TableModel([[plugin['display-name'],
                                            plugin['version']] for plugin in self.plugins_available],
                                          header=['Plugin', 'Version'],
                                          editable=[False, False],
                                          plugins=self.plugins_available)
        self.model_update = TableModel([[plugin['display-name'],
                                         plugin['version']] for plugin in self.plugins_update],
                                       header=['Plugin', 'Version'],
                                       editable=[False, False],
                                       plugins=self.plugins_update)
        self.model_installed = TableModel([[plugin['display-name'],
                                            plugin['version']] for plugin in self.plugins_installed],
                                          header=['Plugin', 'Version'],
                                          editable=[False, False],
                                          plugins=self.plugins_installed)

        model_available_proxy = FilterProxy(self)
        model_available_proxy.setSourceModel(self.model_available)
        self.search_edit.textChanged.connect(model_available_proxy.setTextFilter)
        self.filter_name_cb.stateChanged.connect(model_available_proxy.invalidateFilter)
        self.filter_description_cb.stateChanged.connect(model_available_proxy.invalidateFilter)
        self.filter_instrument_cb.stateChanged.connect(model_available_proxy.invalidateFilter)
        self.table_view.setModel(model_available_proxy)
        self.table_view.setSortingEnabled(True)
        self.table_view.clicked.connect(self.item_clicked)
        self.enable_ui(True)

    def do_action(self):
        indexes_plugin = []
        plugins = []
        if self.plugin_choice.currentText() == 'Available':
            action = 'install'
            for ind, plug in enumerate(self.model_available.get_data_all()):
                if self.model_available.selected[ind]:
                    plugins.append(plug[0])
                    indexes_plugin.append(ind)
        elif self.plugin_choice.currentText() == 'Update':
            action = 'update'
            for ind, plug in enumerate(self.model_update.get_data_all()):
                if self.model_update.selected[ind]:
                    plugins.append(plug[0])
                    indexes_plugin.append(ind)
        elif self.plugin_choice.currentText() == 'Installed':
            action = 'remove'
            for ind, plug in enumerate(self.model_installed.get_data_all()):
                if self.model_installed.selected[ind]:
                    plugins.append(plug[0])
                    indexes_plugin.append(ind)

        msgBox = QtWidgets.QMessageBox()
        msgBox.setText(f"You will {action} this list of plugins: {plugins}")
        msgBox.setInformativeText("Do you want to proceed?")
        msgBox.setStandardButtons(QtWidgets.QMessageBox.StandardButton.Ok |
                                  QtWidgets.QMessageBox.StandardButton.Cancel)
        msgBox.setDefaultButton(QtWidgets.QMessageBox.StandardButton.Ok)

        ret = msgBox.exec()
        self.info_widget.clear()
        if ret == QtWidgets.QMessageBox.StandardButton.Ok:
            for index in indexes_plugin:
                # plugin_dict = get_plugin(plug)
                if self.plugin_choice.currentText() == 'Available' or self.plugin_choice.currentText() == 'Update':
                    if self.plugin_choice.currentText() == 'Available':
                        plugin_dict = self.plugins_available[index]
                    else:
                        plugin_dict = self.plugins_update[index]
                    if plugin_dict is not None:
                        command = [sys.executable, '-m', 'pip', 'install',
                                   f'{plugin_dict["plugin-name"]}=={plugin_dict["version"]}']
                        self.do_subprocess(command)
                    else:
                        self.info_widget.insertPlainText(f'Plugin {plugin_dict["plugin-name"]} not found!')

                elif self.plugin_choice.currentText() == 'Installed':
                    plugin_dict = self.plugins_installed[index]
                    command = [sys.executable, '-m', 'pip', 'uninstall', '--yes', plugin_dict['plugin-name']]
                    self.do_subprocess(command)

        msgBox = QtWidgets.QMessageBox()
        msgBox.setText(f"All actions were performed!")
        msgBox.setInformativeText(f"Do you want to quit and restart the application to take into account the modifications?")
        msgBox.setStandardButtons(QtWidgets.QMessageBox.StandardButton.Close |
                                  QtWidgets.QMessageBox.StandardButton.Cancel)
        restart_button = msgBox.addButton('Restart', QtWidgets.QMessageBox.ButtonRole.ApplyRole)
        msgBox.setDefaultButton(QtWidgets.QMessageBox.StandardButton.Close)
        ret = msgBox.exec()
        if ret == QtWidgets.QMessageBox.StandardButton.Close:
            self.quit()
        elif msgBox.clickedButton() is restart_button:
            self.restart()

    def print_info(self, message: str):
        self.info_widget.moveCursor(QTextCursor.End)
        self.info_widget.insertPlainText(f'{message}\n')
        self.info_widget.moveCursor(QTextCursor.End)
        QtCore.QThread.msleep(100)
        QtWidgets.QApplication.processEvents()

    def do_subprocess(self, command):
        try:
            self.print_info(' '.join(command))

            with subprocess.Popen(command, stdout=subprocess.PIPE, universal_newlines=True) as sp:
                while True:
                    self.print_info(sp.stdout.readline())
                    return_code = sp.poll()
                    if return_code is not None:
                        self.info_widget.insertPlainText(str(return_code))
                        for output in sp.stdout.readlines():
                            print(output.strip())
                        break
        except Exception as e:
            logger.info(str(e))
            subprocess.Popen(command)

    def update_model(self, plugin_choice):
        self.search_edit.textChanged.disconnect()
        self.model_proxy = FilterProxy(self)
        if plugin_choice == 'Available':
            self.model_proxy.setSourceModel(self.model_available)
            self.action_button.setText('Install')
        elif plugin_choice == 'Update':
            self.model_proxy.setSourceModel(self.model_update)
            self.action_button.setText('Update')
        elif plugin_choice == 'Installed':
            self.model_proxy.setSourceModel(self.model_installed)
            self.action_button.setText('Remove')
        self.search_edit.textChanged.connect(self.model_proxy.setTextFilter)
        self.table_view.setModel(self.model_proxy)
        self.item_clicked(self.model_proxy.index(0, 0))

    def item_clicked(self, index):
        if index.isValid():
            self.display_info(index)
            self.action_button.setEnabled(bool(np.any(index.model().sourceModel().selected)))

    def display_info(self, index):
        self.info_widget.clear()
        if index.isValid():
            if self.plugin_choice.currentText() == 'Available':
                plugin = self.plugins_available[index.model().mapToSource(index).row()]
            elif self.plugin_choice.currentText() == 'Update':
                plugin = self.plugins_update[index.model().mapToSource(index).row()]
            elif self.plugin_choice.currentText() == 'Installed':
                plugin = self.plugins_installed[index.model().mapToSource(index).row()]
            # doc, tag, text = Doc().tagtext()
            #
            # with tag('p'):
            #     text(plugin['description'])
            #
            # if not not plugin['authors']:
            #     text('Authors:')
            #     with tag('ul'):
            #         for inst in plugin['authors']:
            #             with tag('li'):
            #                 text(inst)
            #
            # if not not plugin['instruments']:
            #     with tag('p'):
            #         text('This package include plugins for the instruments listed below:')
            #     for inst in plugin['instruments']:
            #         with tag('p'):
            #             text(f'{inst}:')
            #         with tag('ul'):
            #             for instt in plugin['instruments'][inst]:
            #                 with tag('li'):
            #                     text(instt)
            # self.info_widget.insertHtml(doc.getvalue())
            self.info_widget.insertHtml(render(plugin['description']))


def main_without_qt():
    win = QtWidgets.QMainWindow()
    win.setWindowTitle('PyMoDAQ Plugin Manager')
    widget = QtWidgets.QWidget()
    win.setCentralWidget(widget)
    prog = PluginManager(widget, standalone=True)
    win.show()


def main():
    app = QtWidgets.QApplication(sys.argv)
    win = QtWidgets.QMainWindow()
    win.setWindowTitle('PyMoDAQ Plugin Manager')
    widget = QtWidgets.QWidget()
    win.setCentralWidget(widget)
    win.show()
    prog = PluginManager(widget, standalone=True)
    app.exec()


if __name__ == '__main__':
    main()
