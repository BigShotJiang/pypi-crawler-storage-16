:mod:`codec_options` -- Tools for specifying BSON codec options
===============================================================

.. automodule:: bson.codec_options
   :synopsis: Tools for specifying BSON codec options.
   :members:
