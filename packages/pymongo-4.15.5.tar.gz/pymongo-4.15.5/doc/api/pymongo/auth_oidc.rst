:mod:`auth_oidc` -- MONGODB-OIDC Authentication
===========================================================================

.. automodule:: pymongo.auth_oidc
   :members:
