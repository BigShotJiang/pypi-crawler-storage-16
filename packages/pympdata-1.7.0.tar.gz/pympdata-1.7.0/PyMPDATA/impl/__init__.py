"""package internals, if anything from within is needed to be referenced
from user code, please report implementation leak into public API as an issue"""
