"""
PyMPDATA 1D Burgers' equation example

burgers-equation.ipynb:
.. include:: ./burgers_equation.ipynb.badges.md
"""

from .burgers_equation import run_numerical_simulation
