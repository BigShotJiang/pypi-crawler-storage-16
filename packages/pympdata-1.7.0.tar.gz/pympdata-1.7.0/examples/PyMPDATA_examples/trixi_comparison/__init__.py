"""
This example uses a basic 2D advection test case to compare PyMPDATA
solution against Trixi.jl (Julia DG code)

advection_comparison.ipynb:
.. include:: ./advection_comparison.ipynb.badges.md
"""
