#define NO_IMPORT_ARRAY


// All functionality moved into templates => headers
