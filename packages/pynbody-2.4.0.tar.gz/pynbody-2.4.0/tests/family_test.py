import numpy as np
import pytest

import pynbody
import pynbody.test_utils


@pytest.fixture(scope='module', autouse=True)
def get_data():
    pynbody.test_utils.ensure_test_data_available("gasoline_ahf")


def test_pickle():
    # Regression test for issue 80
    import pickle
    assert pickle.loads(pickle.dumps(pynbody.family.gas)) is pynbody.family.gas

def test_family_array_dtype() :
    # test for issue #186
    f = pynbody.load('testdata/gasoline_ahf/g15784.lr.01024.gz')
    f.g['rho'] = np.zeros(len(f.g), dtype=np.float32)
    f.s['rho']

def test_family_array_null_slice():
    """Regression test for issue where getting a family array for an IndexedSubSnap containing no members of that family
    - would erroneously return the entire family array"""

    test = pynbody.new(dm=10, star=10, order='dm,star')
    test.star['TestFamilyArray'] = 1.0
    assert len(test[[1,3,5,7]].star)==0 # this always succeeded
    assert len(test[[1,3,5,7]].star['mass'])==0 # this always succeeded
    assert len(test[1:9:2].star['TestFamilyArray'])==0 # this always succeeded
    assert len(test[[1, 3, 5, 11,13]].star['TestFamilyArray']) == 2  # this always succeeded
    assert len(test[[1,3,5,7]].star['TestFamilyArray'])==0 # this would fail

def test_family_array_sim():
    """Test that the simulation of a family array is a family slice"""

    test = pynbody.new(dm=10, star=10)
    test.dm._create_array('mass')
    assert test.dm['mass'].sim == test.dm
