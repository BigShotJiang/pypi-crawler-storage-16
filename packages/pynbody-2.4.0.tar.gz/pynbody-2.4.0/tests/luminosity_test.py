import pathlib
import warnings

import numpy as np
import numpy.testing as npt
import pytest

import pynbody

results = {'v1':
               {'v': [ -8.43178697,  -7.52725782,  -8.55752215,  -7.30200918,
           -8.41615014,  -8.59016223,  -7.31026967,  -8.1256321 ,
           -7.31516899,  -8.27378519,  -7.45442157,  -7.33061063,
           -7.4942621 ,  -7.54730868,  -8.48061056,  -7.55129644,
           -7.46884028,  -7.35173391,  -7.30810187,  -7.32947897,
           -7.31247126,  -7.35614452,  -7.35172309,  -7.3533164 ,
           -7.8009754 ,  -8.4337253 ,  -8.10181208,  -7.3685942 ,
           -7.2933098 ,  -7.60059819,  -8.4031203 ,  -7.32781769,
           -7.33494296,  -7.43742738,  -7.32184521,  -7.39947923,
           -7.38404256,  -7.67424209,  -7.45982387,  -7.5136939 ,
           -7.49644269,  -7.52047616,  -7.70640667,  -7.59836592,
           -7.95288744,  -7.79976219,  -7.81981626,  -8.10893248,
           -8.18090237,  -8.4380801 ,  -8.75106584,  -8.87724816,
           -9.80700709, -12.22561856],
                'i': [ -9.37233826,  -8.61519208,  -9.51947541,  -8.48016789,
           -9.41243494,  -9.55874499,  -8.47511158,  -9.17034386,
           -8.4853951 ,  -9.30907734,  -8.57183966,  -8.49043676,
           -8.61796731,  -8.65118256,  -9.47015331,  -8.65573819,
           -8.59918215,  -8.5086945 ,  -8.49203518,  -8.49641026,
           -8.49737579,  -8.51395843,  -8.51060436,  -8.51132477,
           -8.8634597 ,  -9.4545572 ,  -9.14829166,  -8.52420703,
           -8.48937097,  -8.69775958,  -9.43458026,  -8.514854  ,
           -8.52237925,  -8.58471778,  -8.51437698,  -8.55251175,
           -8.56633484,  -8.75171474,  -8.61464502,  -8.65941899,
           -8.65130102,  -8.66956763,  -8.81019823,  -8.74420953,
           -9.00395439,  -8.92880219,  -8.94940702,  -9.18155744,
           -9.2745998 ,  -9.48781841,  -9.7605341 ,  -9.9243671 ,
          -10.58894828, -12.69115796],
                'I': [ -9.37233826,  -8.61519208,  -9.51947541,  -8.48016789,
           -9.41243494,  -9.55874499,  -8.47511158,  -9.17034386,
           -8.4853951 ,  -9.30907734,  -8.57183966,  -8.49043676,
           -8.61796731,  -8.65118256,  -9.47015331,  -8.65573819,
           -8.59918215,  -8.5086945 ,  -8.49203518,  -8.49641026,
           -8.49737579,  -8.51395843,  -8.51060436,  -8.51132477,
           -8.8634597 ,  -9.4545572 ,  -9.14829166,  -8.52420703,
           -8.48937097,  -8.69775958,  -9.43458026,  -8.514854  ,
           -8.52237925,  -8.58471778,  -8.51437698,  -8.55251175,
           -8.56633484,  -8.75171474,  -8.61464502,  -8.65941899,
           -8.65130102,  -8.66956763,  -8.81019823,  -8.74420953,
           -9.00395439,  -8.92880219,  -8.94940702,  -9.18155744,
           -9.2745998 ,  -9.48781841,  -9.7605341 ,  -9.9243671 ,
          -10.58894828, -12.69115796]
                },
           'default':
               {'V': [-8.07044055, -7.6684716, -8.11050623, -7.43036633,
                      -7.98558086, -8.12423676, -7.48891951, -7.82376719,
                      -7.4640934, -7.85963566, -7.54598952, -7.52076613,
                      -7.60114124, -7.65311891, -8.04710357, -7.65567522,
                      -7.59460436, -7.5412884, -7.42537524, -7.46917349,
                      -7.42764587, -7.53253068, -7.51636797, -7.51673231,
                      -7.81325786, -7.97850874, -7.88096198, -7.5336551,
                      -7.42924344, -7.72160449, -7.970906, -7.46681441,
                      -7.47444665, -7.63403888, -7.48756181, -7.56878366,
                      -7.53123368, -7.84128388, -7.63290055, -7.71007244,
                      -7.67678585, -7.71653685, -7.94830949, -7.80630891,
                      -8.15887015, -8.01573481, -8.06250937, -8.33939463,
                      -8.43180135, -8.70001321, -9.02997435, -9.20667608,
                      -10.05955829, -12.43626795],
                'i': [
                    -8.53842232, -8.29436497, -8.53842232, -8.13442232,  # <-- SDSS i-band (AB-calibrated)
                    -8.45912228, -8.54547781, -8.17561435, -8.38269271,
                    -8.16617511, -8.40224103, -8.1880548, -8.20541502,
                    -8.25116274, -8.28462338, -8.52311999, -8.28818846,
                    -8.25405965, -8.22849056, -8.20219366, -8.20620194,
                    -8.21115431, -8.23412176, -8.23026229, -8.23521501,
                    -8.40386869, -8.49747786, -8.44806814, -8.26550475,
                    -8.27482598, -8.35335944, -8.50586758, -8.30843885,
                    -8.32178871, -8.34264223, -8.35098734, -8.36378443,
                    -8.38188033, -8.46537776, -8.42734233, -8.45215822,
                    -8.48062601, -8.51218138, -8.59112634, -8.58806429,
                    -8.74969508, -8.69431225, -8.78952554, -8.9488792,
                    -9.05295059, -9.26942307, -9.50410826, -9.78108974,
                    -10.26182162, -12.73000575],
                'I': [-8.92671817, -8.77598268, -8.96539026, -8.65203951,  # <-- Vega-calibrated
                      -8.91344608, -8.97864322, -8.68837508, -8.85991075,
                      -8.6762603, -8.87751396, -8.69698988, -8.71168924,
                      -8.75873397, -8.78691322, -8.96511813, -8.79045389,
                      -8.7585043, -8.72856189, -8.65401488, -8.68560753,
                      -8.65613441, -8.72716479, -8.71898895, -8.72065071,
                      -8.88291062, -8.9554383, -8.92133141, -8.7368417,
                      -8.66236188, -8.85230259, -8.97663062, -8.69341899,
                      -8.70055413, -8.81333585, -8.71390741, -8.77301384,
                      -8.74976204, -8.95069591, -8.82794887, -8.88493295,
                      -8.86764611, -8.90054536, -9.05370243, -8.98209003,
                      -9.20401939, -9.13786686, -9.19498955, -9.38920772,
                      -9.50019643, -9.7336607, -10.02028179, -10.16524934,
                      -10.7032577, -13.14923625]
                }
           }


@pytest.fixture
def testfile():
    f = pynbody.load("testdata/gasoline_ahf/g15784.lr.01024.gz")

    with warnings.catch_warnings(record=True) as w:
        warnings.filterwarnings('ignore')
        f.st['massform']  # noqa - trigger starlog load and ignore any warnings

    return f


def test_luminosity(testfile):
    for ssp_name, tests in results.items():
        with pynbody.analysis.luminosity.use_custom_ssp_table(ssp_name):
            for band, result in tests.items():
                mag = pynbody.analysis.luminosity.calc_mags(testfile.st, band=band)
                print(repr(mag[::5000]))
                npt.assert_allclose(mag[::5000], result, rtol=1e-5)


@pytest.mark.filterwarnings('ignore::RuntimeWarning')
def test_halo_magnitude(testfile):
    expected_results = {'V': -21.89507, 'U': -21.413841, 'u': -20.937146}
    h = testfile.halos()
    for band, expected in expected_results.items():
        print(h[0].st[band + "_mag"])
        npt.assert_allclose(pynbody.analysis.luminosity.halo_mag(h[0], band), expected)


@pytest.mark.filterwarnings('ignore::RuntimeWarning')
def test_halo_half_light(testfile):
    expected_results = {('V', False): 3.830666, ('i', False): 3.414289,
                        ('i', True): 3.123489}
    testfile.physical_units()
    h = testfile.halos()
    pynbody.analysis.faceon(h[0])
    for (band, cylindrical), expected in expected_results.items():
        npt.assert_allclose(pynbody.analysis.luminosity.half_light_r(h[0], band, cylindrical=cylindrical), expected,
                            rtol=1e-5)


def test_ssp_table_recovers_input_from_file():
    # Define a controlled snapshot and fill it up with first numbers from default_ssp file
    ssp_tester = pynbody.new(stars=1)
    default_ssp_file = np.loadtxt(str(pathlib.Path(pynbody.__path__[0]) / "analysis" / "default_ssp.txt"))

    ssp_tester.st['age'] = pynbody.array.SimArray(default_ssp_file[0, 0], units="yr")
    ssp_tester.st['metals'] = pynbody.array.SimArray(default_ssp_file[0, 1], units="1")
    ssp_tester.st['mass'] = pynbody.array.SimArray(1.0, units="Msol")

    # Check that the pynbody-defined table actually recovers the magnitude number from the same row
    # See Issue #900
    table = pynbody.analysis.luminosity.get_current_ssp_table()
    npt.assert_allclose(default_ssp_file[0, 5], table(ssp_tester, 'V'))
    npt.assert_allclose(default_ssp_file[0, 6], table(ssp_tester, 'R'))


def test_float32_dtype_magnitudes():
    """Test that magnitude calculation works correctly with float32 dtype arrays.

    This is a regression test for issue #953, where float32 dtype for ages and metals
    could cause NaN values in magnitude calculations due to dtype mismatch in the
    clamping mechanism.
    """
    np.random.seed(42)

    N = 1000

    age_arr = np.random.uniform(0.0, 13.7, N)
    log_metal_arr = np.random.uniform(-5, 0.5, N)
    mass_arr = np.random.uniform(1e2, 1e3, N)

    # Store results from float64 calculation for comparison
    Vmags_float64 = None

    # Process float64 first to establish reference values
    for dtype in ['float64', 'float32']:
        ages = pynbody.array.SimArray(
            age_arr,
            units="Gyr",
            dtype=dtype
        )

        metals = pynbody.array.SimArray(
            10**log_metal_arr,
            units="",
            dtype=dtype
        )

        masses = pynbody.array.SimArray(
            mass_arr,
            units="Msol",
            dtype=dtype
        )

        sim = pynbody.new(dm=0, gas=0, star=N)

        sim.stars['age'] = ages
        sim.stars['metals'] = metals
        sim.stars['mass'] = masses

        Vmags = sim.stars['V_mag']

        # Check that there are no NaN values (the bug in issue #953)
        num_nans = len(Vmags[np.isnan(Vmags)])
        assert num_nans == 0, f"Found {num_nans} NaN values in V_mag using dtype {dtype}"

        if dtype == 'float64':
            Vmags_float64 = Vmags.copy()
        else:
            # Check that float32 results match float64 results (within reasonable tolerance
            # accounting for float32 precision and log operations on float32 values)
            npt.assert_allclose(Vmags, Vmags_float64, rtol=1e-3,
                                err_msg="float32 and float64 magnitudes should match")
