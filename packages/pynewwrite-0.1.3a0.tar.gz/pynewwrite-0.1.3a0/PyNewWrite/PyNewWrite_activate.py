from PyNewWrite.main import PyNewWrite
write = PyNewWrite.write
__all__ = ["PyNewWrite"]