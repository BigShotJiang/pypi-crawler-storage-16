from PyNewWrite.PyNewWrite_activate import write
__all__ = ["PyNewWrite.write"]