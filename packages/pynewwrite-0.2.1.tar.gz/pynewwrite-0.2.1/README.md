# PyNewWrite

📝 Простая и удобная библиотека для вывода текста в консоль.

## Установка

Установите библиотеку через pip:

```bash
pip install PyNewWrite
```
Пример кода:

```python
USER_INPUT = input()
PyNewWrite.write(
    USER_INPUT, 
    color = {
    "color_mode": 1, #0 - Выключено, 1 - включено
    "color": "31" #Значение из таблицы ASCII
    }, 
    efects = {
    "efect_mode": 1, #0 - Выключено, 1 - включено
    "efect": "reverse_work" #Один из эффектов из бибилиотеки
    }
    )
```