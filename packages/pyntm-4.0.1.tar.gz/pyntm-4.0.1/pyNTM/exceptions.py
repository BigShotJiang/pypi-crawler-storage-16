"""Exceptions"""


class ModelException(Exception):
    pass
