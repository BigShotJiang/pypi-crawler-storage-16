*******
Credits
*******

Authors
=======

NWB: Version 2.0.0 and later
------------------------------

Documentation for storage of Version 2 of the NWB format and later have been created by
Oliver Ruebel and Andrew Tritt et al. in collaboration with the NWB community.

Acknowledgments
===============

For details on the partners, funders, and supporters of NWB please the https://www.nwb.org/ project website.
For specific contributions to the format specification and this document see the change logs of
the Git repository at https://github.com/NeurodataWithoutBorders/nwb-schema .

*****
Legal
*****

.. contents::

Copyright
=========

.. include:: ../../../Legal.txt

Licence
=======

.. include:: ../../../license.txt

