class RaDecOffsets:
    def __init__(self, dra: float = 0, ddec: float = 0):
        self.dra = dra
        self.ddec = ddec


__all__ = ["RaDecOffsets"]
