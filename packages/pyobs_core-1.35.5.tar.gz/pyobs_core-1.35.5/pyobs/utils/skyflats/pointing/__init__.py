"""
TODO: write docs
"""

__title__ = "Sky flat pointings"

from .base import SkyFlatsBasePointing
from .static import SkyFlatsStaticPointing


__all__ = ["SkyFlatsStaticPointing", "SkyFlatsBasePointing"]
