"""Tests for mssql-mcp-server."""
