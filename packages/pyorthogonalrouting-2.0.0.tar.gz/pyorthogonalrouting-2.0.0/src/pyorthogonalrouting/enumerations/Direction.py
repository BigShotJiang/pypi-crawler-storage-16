
from enum import Enum


class Direction(Enum):

    VERTICAL   = 'Vertical'
    HORIZONTAL = 'Horizontal'
    UNKNOWN    = 'Unknown'
