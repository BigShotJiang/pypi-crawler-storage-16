import nonexistent_module_xyz  # noqa: F401
