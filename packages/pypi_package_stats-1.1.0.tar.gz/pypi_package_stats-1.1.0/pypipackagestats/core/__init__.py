"""Core functionality for PyPI package stats"""

