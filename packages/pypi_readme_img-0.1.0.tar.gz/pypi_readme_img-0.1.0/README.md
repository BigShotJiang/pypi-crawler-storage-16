# pypi-readme-img

Some text.

<pre>
Project_1 <span style="color:green">0.1.1</span>
  proj1/.env:
    .VERSION = <span style="color:yellow">0.1.0</span>
  proj1/conf.json:
    .project.version = <span style="color:green">0.1.1</span>
  proj1/conf.toml:
    .project.version = <span style="color:yellow">0.1.0</span>

Project_2 <span style="color:green">0.1.3</span>
  proj2/conf.xml:
    .Project.version = <span style="color:red">[Value not found]</span>
  proj2/conf.yaml:
    .project.version = <span style="color:yellow">0.1.2</span>
</pre>

<img src="https://github.com/alexisbg/vqu/raw/main/.github/images/vqu_example.webp" alt="vqu example output" width="382" style="width: 382px; height: auto">
