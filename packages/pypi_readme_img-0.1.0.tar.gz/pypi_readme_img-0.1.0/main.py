def main():
    print("Hello from pypi-readme-img!")


if __name__ == "__main__":
    main()
