import setuptools

setuptools.setup(
    package_data={
        "pypipedrive": ["py.typed"],
    },
)