#! /usr/local/bin/python3
# PYTHON_ARGCOMPLETE_OK
"""Get dependencies of a python package."""

# Copyright (c) 2025 Tom Björkholm
# MIT License
