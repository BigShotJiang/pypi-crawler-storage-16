# us ofdma pre eq 
Content forthcoming. This page documents the parser/decoder, expected inputs, and outputs for: us-ofdma-pre-eq.
