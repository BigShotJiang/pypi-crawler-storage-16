from pyproject_toml_format.cli import main


if __name__ == '__main__':
    main()
