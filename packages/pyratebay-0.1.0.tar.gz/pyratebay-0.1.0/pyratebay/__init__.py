from pyratebay.data_fetcher import media_search as search
from pyratebay.data_fetcher import media_info as info 
from pyratebay.data_fetcher import hot_media as hot
from pyratebay.models import Media

__all__ = ["search", "info", "hot", "Media"]
