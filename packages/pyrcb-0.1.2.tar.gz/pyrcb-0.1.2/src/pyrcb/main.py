"""Main module for pyrcb library."""


def main():
    """Main entry point for pyrcb."""
    print("Hello from pyrcb!")


if __name__ == "__main__":
    main()

