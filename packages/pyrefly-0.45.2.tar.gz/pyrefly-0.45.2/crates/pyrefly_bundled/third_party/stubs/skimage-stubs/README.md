These stubs were created with https://github.com/gramster/docs2stubs. 


