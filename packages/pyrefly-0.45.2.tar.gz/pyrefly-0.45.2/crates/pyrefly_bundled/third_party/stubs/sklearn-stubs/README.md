These stubs were created with https://github.com/gramster/docs2stubs. A small number of missing stubs for 
.pxd files were created by hand; they may be missing other things needed from .pxd files.


