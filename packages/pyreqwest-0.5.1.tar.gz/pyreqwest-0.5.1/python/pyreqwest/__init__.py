""".. include:: ../../README.md"""

from ._pyreqwest import __version__  # noqa: F401
