"""Middleware classes."""

from pyreqwest._pyreqwest.middleware import Next, SyncNext

__all__ = ["Next", "SyncNext"]
