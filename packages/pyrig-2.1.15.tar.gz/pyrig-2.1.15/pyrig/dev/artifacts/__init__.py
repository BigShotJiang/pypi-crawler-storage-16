"""Artifact building and packaging infrastructure.

This package provides utilities for building distributable artifacts
from pyrig projects, including PyInstaller executables and other
packaging formats.
"""
