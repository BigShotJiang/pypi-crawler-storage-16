"""Testing utilities and decorators.

This package provides helper functions and decorators for
writing and organizing pytest tests.
"""
