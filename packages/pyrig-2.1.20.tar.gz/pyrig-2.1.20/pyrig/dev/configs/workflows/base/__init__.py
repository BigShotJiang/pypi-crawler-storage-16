"""Base workflow configuration utilities.

This package provides the Workflow base class for creating
GitHub Actions workflow configuration files.
"""
