"""Git-related configuration file management.

This package provides ConfigFile subclasses for managing .gitignore
and .pre-commit-config.yaml files.
"""
