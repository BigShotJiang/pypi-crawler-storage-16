# nvim

```{autofile} ../../src/*/nvim/*.py
---
module:
---
```
