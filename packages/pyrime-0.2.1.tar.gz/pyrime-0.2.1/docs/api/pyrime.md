# pyrime

```{autofile} ../../src/*/*.py
---
module:
---
```
