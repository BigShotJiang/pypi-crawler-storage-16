pub mod kurtosis;
pub mod max_min_by;
pub mod mode;
pub mod skewness;
pub mod try_avg;
pub mod try_sum;
