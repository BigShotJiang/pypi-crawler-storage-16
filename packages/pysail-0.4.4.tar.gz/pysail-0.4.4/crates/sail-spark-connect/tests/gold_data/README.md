# Gold Data for Spark Tests

This directory contains the gold data for the Spark tests.
All the files in this directory, including this README file, are auto-generated.
Please do not modify them manually.
