"""
pyscn-mcp: MCP (Model Context Protocol) server for pyscn Python code analyzer.

This package provides an MCP server interface to pyscn's code analysis capabilities.
"""

__version__ = "0.0.0"  # Will be set by setuptools_scm
