# Authors

Contributors to pysegmenters_syntok include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
