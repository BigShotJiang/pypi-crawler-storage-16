"""syntok segmenter"""
__version__ = "0.5.5"
