# Summary

- [Introduction](introduction.md)
- [Getting Started](getting-started.md)
- [Data Formats](data-formats.md)
- [Types](types.md)
- [Decorators](decorators.md)
- [Class Attributes](class-attributes.md)
- [Field Attributes](field-attributes.md)
- [Union](union.md)
- [Type Checking](type-check.md)
- [Extension](extension.md)
- [FAQ](faq.md)
