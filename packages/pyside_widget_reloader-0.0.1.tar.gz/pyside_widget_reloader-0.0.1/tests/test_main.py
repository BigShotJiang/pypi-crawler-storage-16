import logging
import multiprocessing
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from widgets import TestWidget

from pwreloader import ReloaderWindow, start_reloaders


@pytest.fixture
def project(tmp_path: Path) -> Path:
    project_dir = tmp_path.joinpath("project")
    # project_init = project_dir.joinpath("__init__.py")
    # project_init.touch()
    # _ = project_init.write_text("from module import TestClass")
    # module_file = project_dir.joinpath("module.py")
    # module_file.touch()
    # _ = module_file.write_text("class TestClass")
    return project_dir


def test_pipe():
    op, ip = multiprocessing.Pipe()
    op.send("hello")
    assert ip.poll()
    assert ip.recv() == "hello"


def test_start_reloaders(project: Path):
    outer_pipe, inner_pipe = multiprocessing.Pipe()
    start_reloaders([ReloaderWindow(TestWidget, 1000, size=(0, 0), args=(inner_pipe,))])
    outer_pipe.send({"action": "read"})
    assert outer_pipe.poll(5)
    test_data = outer_pipe.recv()
    assert test_data == ""
    outer_pipe.send({"action": "close"})
    assert outer_pipe.poll(5)
    assert outer_pipe.recv()


class TestMain(unittest.TestCase):
    @patch("pyside_widget_reloader.src.main.multiprocessing.Process")
    def test_start_reloaders(self, mock_process):
        window1 = MagicMock()
        window1.name = "Window1"
        window2 = MagicMock()
        window2.name = "Window2"
        windows = [window1, window2]

        start_reloaders(windows, logging.INFO, False)

        self.assertEqual(mock_process.call_count, 2)
        mock_process.assert_any_call(target=window1.start_application, name="Window1")
        mock_process.assert_any_call(target=window2.start_application, name="Window2")

    @patch("pyside_widget_reloader.src.main.multiprocessing.Process")
    def test_start_reloaders_debug_mode(self, mock_process):
        window1 = MagicMock()
        window1.name = "Window1"
        windows = [window1]

        start_reloaders(windows, logging.DEBUG, True)

        mock_process.assert_not_called()
        window1.start_application.assert_called_once()


if __name__ == "__main__":
    unittest.main()
