
import unittest
from unittest.mock import MagicMock, patch
from types import ModuleType
from pwreloader.src.module import ModuleReloader

class TestModuleReloader(unittest.TestCase):

    @patch('pyside_widget_reloader.src.module.importlib')
    def test_reload(self, mock_importlib):
        mock_module = ModuleType('test_module')
        mock_module.__file__ = 'test_module.py'
        reloader = ModuleReloader(mock_module)
        reloader._reload()
        mock_importlib.reload.assert_called_once_with(mock_module)

if __name__ == '__main__':
    unittest.main()
