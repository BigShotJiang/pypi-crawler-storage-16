
import unittest
from unittest.mock import MagicMock, patch
from PySide6.QtWidgets import QWidget
from pwreloader.src.window import ReloaderWindow

class TestWindow(unittest.TestCase):

    @patch('pyside_widget_reloader.src.window.QApplication')
    @patch('pyside_widget_reloader.src.window.QTimer')
    @patch('pyside_widget_reloader.src.window.ModuleReloader')
    def test_start_application(self, mock_module_reloader, mock_qtimer, mock_qapplication):
        mock_widget = QWidget
        window = ReloaderWindow(mock_widget, 1000)
        window.start_application()
        mock_qapplication.assert_called_once()
        mock_qtimer.assert_called_once()

if __name__ == '__main__':
    unittest.main()
