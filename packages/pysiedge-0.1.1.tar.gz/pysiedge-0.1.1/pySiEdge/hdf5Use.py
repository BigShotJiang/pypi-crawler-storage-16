# SPDX-FileCopyrightText: Copyright © 2024-2025 Damian Anders <damian.anders@tu-dresden.de>
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""Funktionen zur Verwendung der Daten aus 'Analyze MyWorkpiece /Capture4Analysis', nachdem sie in HDF5-Dateien abgelegt wurden."""

import h5py
import numpy as np

__all__ = ["dsToNp"]

def dsToNp(fileHandle: h5py.File,
		   path: str,
		   source_sel: slice | tuple | None = None,
		   dtype: type = np.float64,
) -> np.ndarray:
	"""
	Eine effiziente Methode zum Kopieren eines Datasets in ein neues ndarray.

	Parameters
	----------
	fileHandle : h5py.File
		File handle der geöffneten Datei.
	path : str
		Pfad des Datasets in `fileHandle`.
	source_sel : slice | None, default=None
		Slice zur Auswahl von Datenpunkten des Datasets.
		Standardwert ist ``None``
	dtype : type
		Numpy dtype des zurückgegebenen Arrays.
	Returns
	-------
	np.ndarray
		Dataset als ndarray.
	"""
	arr = _arrFromSlice(source_sel, fileHandle[path].shape, dtype=dtype)
	fileHandle[path].read_direct(arr, source_sel=source_sel)  # alle Datenpunkte aus Dataset in Array kopieren

	return arr


def _arrFromSlice(slc: slice | tuple,
				  shape: tuple,
				  dtype: type = np.float64,
) -> np.ndarray:
	"""
	Erstellt ein Array in Zielgröße für ein slice eines Arrays in bekannter Größe.

	Parameters
	----------
	slc : slice | tuple
		Slice eines Arrays der Größe `shape`.
	shape : tuple
		Shape des Arrays, aus dem mittels `slc` Datenpunkte entnommen werden sollen.
	dtype : type, default=np.float64
		Datentyp des Arrays.
		Standardwert ist ``np.float64``

	Returns
	-------
	np.ndarray
		Leeres Array mit ``order="C"`` in Zielgröße für das Slicing.
	"""
	newShape = np.asarray(shape, dtype=int)	# Achsen, die nicht im slice sind, bleiben unverändert
	if slc is not None:
		if isinstance(slc, slice):
			slc = (slc,)	# `slc` muss iterable werden, sonst keine Schleife möglich
		for s in range(len(slc)):
			if isinstance(slc[s], int):	# einzelner Datenpunkt entlang der Achse s bedeutet shape[s]==1
				newShape[s] = 1
			elif isinstance(slc[s], list):	# mehrere einzelne Datenpunkte entlang Achse s
				newShape[s] = len(slc[s])
			elif isinstance(slc[s], slice):	# Slice in Achse s
				if slc[s].start is None:	# Startpunkt ist standardmäßig 0, also der erste Datenpunkt
					slcStart = 0
				else:
					slcStart = slc[s].start

				if slc[s].stop is None:	# Endpunkt ist standardmäßig shape[s], also der letzte Datenpunkt
					slcStop = shape[s]
				else:
					slcStop = slc[s].stop

				if slc[s].step is None:	# Schrittweite ist standardmäßig 1
					slcStep = 1
				else:
					slcStep = slc[s].step

				newShape[s] = np.ceil((slcStop - slcStart) / slcStep)	# Anzahl der Datenpunkte

	return np.zeros(tuple(newShape), order="C", dtype=dtype)
