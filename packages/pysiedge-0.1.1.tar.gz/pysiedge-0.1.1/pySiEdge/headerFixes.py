# SPDX-FileCopyrightText: Copyright © 2024-2025 Damian Anders <damian.anders@tu-dresden.de>
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""Funktionen zur Behebung von Defekten im Header von Dateien, die von 'Analyze MyWorkpiece /Capture4Analysis' erstellt wurden."""

import os

from ast import literal_eval

__all__ = ["fixHeaderByMapping", "fixHeaderByCopying", "writeHeaderFix"]

def _getChannelInfo(singleJsonFilePath: str,
					LF: bool = False,
					) -> list[dict[str, str]]:
	"""
	Liest die ersten drei Zeilen einer AMW4Capture-JSON ein, ermittelt daraus die Informationen der geloggten Kanäle und gibt sie zurück.

	Parameters
	----------
	singleJsonFilePath : str
		Pfad zur Datei
	LF : bool, default=False
		Wenn ``LF=True`` werden die Namen der LF-Parameter ermittelt, statt standardmäßig die der HF-Parameter

	Returns
	-------
	list[dict[str, str]]
		ermittelte Kanäle in der Datei
	"""

	with open(singleJsonFilePath, mode='rt') as f_in:  # Datei öffnen
		for a in range(3):	# die dritte Zeile muss eingelesen werden
			headerStr = f_in.readline()

		if LF:
			offset = headerStr.find("\"SignalListLFData")  # in der dritten Zeile den Abschnitt mit LF-Kanalnamen finden
		else:
			offset = headerStr.find("\"SignalListHFData")  # in der dritten Zeile den Abschnitt mit HF-Kanalnamen finden
		idxStart = headerStr[offset:].find("[") + offset  # Index des Starts des Kanalnamen-dicts
		idxStop = headerStr[idxStart:].find("]") + idxStart + 1  # Index des ersten Zeichens nach dict
		channelDict = literal_eval(headerStr[idxStart:idxStop])  # str als list[dict] parsen

	return channelDict


def fixHeaderByMapping(singleJsonFilePath: str,
					   chMap: dict[int, str],
) -> list[dict[str, str]]:
	"""
	Erstelle die Achsenbezeichnungen im Header mittels bekannter Zuordnung aus den Hardwareadressen.

	Parameters
	----------
	singleJsonFilePath : str
		Pfad zur Datei
	chMap : dict[int, str]
		Zuordnung der Achsenbezeichnungen zu ihren Kanalnummern in der Form {1: "Name1", ...}

	Returns
	-------
	list[dict[str, str]]
		Dictionary mit korrigierten Kanalbezeichnungen für neuen Header
	"""

	headerAxis = _getChannelInfo(singleJsonFilePath)	# existierende Kanalinformationen aus Header auslesen

	for c in range(len(headerAxis)):	# alle Kanäle abarbeiten
		if not headerAxis[c]['Axis']:
			if headerAxis[c]['Address'] == 'CYCLE':	# Spezialfall abfangen
				headerAxis[c]['Axis'] = 'CYCLE'
			else:
				try:
					axisSplit = headerAxis[c]['Address'].rsplit("|", 1)	# Kanalnummer extrahieren
					numAxis = int(axisSplit[1])							#	dtype umwandeln
					headerAxis[c]['Axis'] = chMap[numAxis]				#	Zuordnung auflösen und Kanalnamen in Kanalinformationen-Dictionary schreiben
				except:
					raise ValueError(f"Achse des Kanals {headerAxis[c]['Name']}, Adresse {headerAxis[c]['Address']} konnte nicht ermittelt werden.")
	return headerAxis


def fixHeaderByCopying(jsonFilePaths: list[str],
					   runSequence: list[list[int]],
) -> (list[dict[str, str]],
	  int):
	"""
	Erstelle die Achsenbezeichnungen im Header mittels korrektem Header aus Datei eines weiteren Runs desselben Jobs.
	.. note:: Es wird explizit die Möglichkeit berücksichtigt, dass sich zwischen zwei Runs die Reihenfolge der Kanäle ändern kann. Die Kanäle selbst dürfen sich aber nicht ändern!

	Parameters
	----------
	jsonFilePaths : list[str]
		Liste mit Dateipfaden der Messdaten-Dateien, i. d. R. erzeugt mit Funktion ``compilePaths``
	runSequence : list[list[int]]
		Liste, die pro Run in ``jsonFilePaths`` eine Liste mit den Indizes auf ``jsonFilePaths`` der zum jeweiligen Run gehörigen Dateien enthält

	Returns
	-------
	list[dict[str, str]]
		Dictionary mit korrigierten Kanalbezeichnungen für neuen Header
	int
		Index der Datei, deren Header korrigiert wurde, auf ``jsonFilePaths``
	"""

	headerAxis = list()	# leere Listen erstellen
	reference = list()
	idxFix = None

	for run in runSequence:	# für jeden Run
		header = _getChannelInfo(jsonFilePaths[run[0]])	# Header der ersten Datei des Runs einlesen

		noAxis = list()
		for ch in header: 						# für jeden Kanal der Messung
			if not ch['Axis']:					# wenn keine Achsenbezeichnung vorhanden
				noAxis.append(f"{ch['Name']}")	#	Messgröße der Liste hinzufügen

		if len(set(noAxis)) < len(noAxis):	# wenn selbe Messgröße mehrfach ohne Achsenbezeichnung vorhanden
			headerAxis = header				#	aktuellen Header als fehlerhaften Header übernehmen
			idxFix = run					#	Indizes aller Dateien des defekten Runs auf `jsonFilePaths` übernehmen
		else:
			reference = header				# sonst intakten Header als Referenz übernehmen

		if headerAxis and reference:	# nur suchen, bis ein defekter Header und eine Referenz gefunden wurden
			break

	if not (headerAxis and reference):	# alle Runs analysiert und nicht beide Arten von Header gefunden
		raise ValueError("Es konnte kein intakter oder/und kein defekter Header ermittelt werden.")

	found = list()
	for c in range(len(headerAxis)):						#	für alle Kanäle im defekten Header
		found.append(False)										# Zuordnung noch nicht gefunden
		for ref in reference:
			if headerAxis[c]['Name'] == ref['Name']:			# im Referenz-Header nach Namen des aktuellen Kanals suchen
				if headerAxis[c]['Address'] == ref['Address']:	# wenn auch Adresse übereinstimmt
					headerAxis[c]['Axis'] = ref['Axis']			#	Achsenbezeichnung übernehmen
					found[-1] = True							#	Zuordnung als gefunden kennzeichnen

	if not all(found):	# nicht alle Zuordungen gefunden
		raise ValueError("Der Header konnte nicht erfolgreich durch Kopie repariert werden.")

	return headerAxis, idxFix


def writeHeaderFix(jsonFilePath: str | list[str],
				   headerAxis: list[dict[str, str]],
				   idxFilePath: list[int] | None = None,
				   keepOriginal: bool = True,
				   chunkSize: int = 4096,
) -> None:
	"""
	Schreibe eine neue Datei mit korrigiertem Header und benenne die Originaldatei um.

	Parameters
	----------
	jsonFilePath : str | list[str]
		Entweder einzelner Pfad zur Datei, deren Header korrigiert werden soll oder Liste mit Pfaden.
	headerAxis : list[dict[str, str]]
		Dictionary mit korrigierten Kanalbezeichnungen für neuen Header, erzeugt mit Funktion ``fixHeaderByMapping`` oder ``fixHeaderByCopying``.
	idxFilePath : list[int] | None, default=None
		Nur, wenn mehrere Pfade in ``jsonFilePath`` übergeben: Liste mit Indizes der Dateien in ``jsonFilePath``, deren Header korrigiert werden soll. Falls ``None`` werden alle Dateien in ``jsonFilePath`` verarbeitet.
		Standardwert ist ``None``
	keepOriginal : bool, default=True
		Gibt an, ob die Originaldatei behalten werden soll. Falls ``False`` wird die Datei gelöscht.
		Standardwert ist ``True``
	chunkSize : int, default=4096
		Anzahl Bytes, die pro Iteration aus der Originaldatei in den Speicher geladen wird, um sie anschließend in korrigierte Datei zu schreiben.
		Standardwert ist 4096

	Returns
	-------
	None
	"""

	if isinstance(jsonFilePath, str):
		if idxFilePath is not None:
			raise ValueError("Wenn nur ein Pfad übergeben wird muss `idxFilePath=None` sein.")
		else:
			jsonFilePath = [jsonFilePath]
			idxFilePath = [0]

	elif isinstance(jsonFilePath, list):
		if idxFilePath is None:
			idxFilePath = list(range(len(jsonFilePath)))
		elif (min(idxFilePath) < 0) or (max(idxFilePath) >= len(jsonFilePath)):
			raise ValueError("Ungültige Indizes in `idxFilePath`")

	for idx in idxFilePath:
		tempName = os.path.splitext(jsonFilePath[idx])[0] + '.FIX'	# temporärer Name der neuen Datei

		with open(jsonFilePath[idx], 'rt', encoding='utf8') as f_in:	# Original- und neue Datei im TEXTmodus öffnen
			with open(tempName, 'wt') as f_out:
				buffer = ''	# Puffer initialisieren
				for l in range(3):
					buffer = buffer + f_in.readline()	# erste drei Zeilen in Puffer einlesen

				channelString = str(headerAxis)[1:-1]	# Dictionary mit Achsbezeichnungen zu str konvertieren und umgebende Klammern abschneiden
				channelString = channelString.replace("\'", "\"")	# einfaches Hochkomma zu Anführungszeichen ändern

				startString = "SignalListHFData\":["	# Strings kennzeichnen Start und Ende des zu ersetzenden Bereichs des Headers
				endString = "]"

				idxStart = buffer.find(startString) + len(startString)	# Index des ersten Zeichens nach Auftreten von `startString` in `buffer`
				idxEnd = buffer[idxStart:].find(endString) + idxStart	# Index des ersten Zeichens nach Auftreten von `endString` hinter `startString` in `buffer`
				header = buffer[:idxStart] + channelString + buffer[idxEnd:]	# korrigierten Header zusammenstellen

				pos = f_in.tell()	# Byte-Position des file pointers auf Original-Datei zwischenspeichern; steht auf erstem Zeichen hinter Header

				f_out.write(header)	# korrigierten Header in neue Datei schreiben

		with open(jsonFilePath[idx], 'rb') as f_in:	# Original- und neue Datei im BINÄRmodus öffnen; umgeht das Problem, dass alle Messdaten in der fünften
			with open(tempName, 'ab') as f_out:			#	Zeile stehen und im Textmodus somit eine 100MB-Zeile geladen und geschrieben werden müsste
				f_in.seek(pos)	# file pointer auf gleiche Position hinter Header setzen
				while True:
					buffer = f_in.read(chunkSize)	# Rest der Originaldatei (hinter Header) in Chunks lesen und in neue Datei speichern
					if not buffer:
						break
					f_out.write(buffer)

		os.rename(jsonFilePath[idx], jsonFilePath[idx] + '.ORIG')	# Dateiendung der Originaldatei ändern
		os.rename(tempName, jsonFilePath[idx])	# neue Datei so umbenennen, dass sie den Platz der Originaldatei einnimmt

		if not keepOriginal:
			os.remove(jsonFilePath[idx] + '.ORIG')
