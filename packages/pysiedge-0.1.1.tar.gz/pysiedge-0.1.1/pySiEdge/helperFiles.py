# SPDX-FileCopyrightText: Copyright © 2024-2025 Damian Anders <damian.anders@tu-dresden.de>
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""Funktionen zur Vorverarbeitung von Dateien, die von 'Analyze MyWorkpiece /Capture4Analysis' erstellt wurden."""

import os
import time
import warnings
from datetime import datetime
from glob import glob
from zipfile import ZipFile

__all__ = ["compilePaths", "prepareC4AFiles", "fixC4AFileTime"]

def compilePaths(folderPath: str,
				 fileExtension: str,
) -> list[str]:
	"""
	Erstelle eine Liste mit den Pfaden aller Dateien des angegebenen Datentyps im angegebenen Ordner.

	Parameters
	----------
	folderPath : str
		Pfad zum Ordner
	fileExtension : str
		Dateityp, ohne führenden Punkt

	Returns
	-------
	list[str]
		Liste mit Dateipfaden
	"""

	if not os.path.isdir(folderPath):				# testen, ob Ordnerpfad übergeben
		folderPath = os.path.split(folderPath)[0]	#	sonst Dateiteil abtrennen

	pathFilter = os.path.join(folderPath, ('*.' + fileExtension))	# Filter für Dateityp hinzufügen

	filesGlob = glob(pathFilter)	# Dateipfade aus Ordnerpfad ermitteln
	filePathList = [os.path.normpath(s) for s in filesGlob]	# Pfade normalisieren

	return filePathList


def prepareC4AFiles(folderPath: str,
) -> list[str]:
	"""
	Erstelle eine Liste mit allen JSON-Dateien im angegebenen Ordner und wenn nötig, entpacke die JSON-Dateien vorher aus ihren ZIP-Archiven.

	Parameters
	----------
	folderPath : str
		Pfad zum Ordner

	Returns
	-------
	list[str]
		Liste mit Dateipfaden
	"""

	filePaths = compilePaths(folderPath, 'zip')	# alle ZIP-Dateien im Ordner

	if len(filePaths)==0:	# falls keine ZIP-Dateien im Ordner
		warnings.warn_explicit(("Keine verwertbaren ZIP-Dateien im Pfad \"%s\". Suche stattdessen nach bereits vorhandenen JSON-Dateien." % folderPath), Warning, 'formatiere_pfade', 0)
		filePaths = compilePaths(folderPath, 'json')
		if len(filePaths)==0:	# falls auch keine JSON-Dateien im Ordner
			raise Exception("Keine ZIP- oder JSON-Dateien gefunden.")
		else:
			return filePaths
	else:
		for singlePath in filePaths:		# vorliegende (äußere) ZIP-Datei
			with ZipFile(singlePath, mode='r') as f_zip0:
				zip0_names = f_zip0.namelist()	# Dateien in der äußeren ZIP-Datei

				if '.json' in zip0_names[0].casefold():								# wenn nur eine ZIP-Ebene, dann
					f_zip0.extractall(path=os.path.split(singlePath)[0])			#	alle JSON daraus entpacken
				elif '.zip' in zip0_names[0].casefold():							# wenn zweite (innere) ZIP-Datei vorhanden
					with f_zip0.open(zip0_names[0]) as f_zip1_zip:					#	diese als "file-like object" zur Verfügung stellen,
						with ZipFile(f_zip1_zip, mode='r') as f_zip1:				#	diese wiederum als ZIP-File öffnen und
							f_zip1.extractall(path=os.path.split(singlePath)[0])	#	alle JSON daraus entpacken
				else:
					raise Exception(f"ZIP-Datei \"{singlePath}\" hat ungültiges Format.")

	return compilePaths(folderPath, 'json')	# Pfade der JSON-Dateien zurückgeben


def fixC4AFileTime(path: str,
) -> None:
	"""
	Korrigiert die Änderungs- und Zugriffszeiten einer von 'Analyze MyWorkpiece /Capture4Analysis' erstellten
	.zip-Datei anhand des Zeitstempels,	der in den Dateinamen eingebettet ist.

	Parameters
	----------
	path : str
	    Der vollständige Dateipfad der Datei, deren Zeitstempel aktualisiert werden soll.
	"""
	_, file = os.path.split(path)	# Dateinamen abtrennen
	filename, _ = os.path.splitext(file)	# Dateierweiterung abtrennen

	datestring = filename.rsplit('_', 1)[-1]					# Datums-String entnehmen,
	dt = datetime.strptime(datestring, "%Y%m%d-%H%M%S")	#	parsen,
	timestamp = time.mktime(dt.timetuple())						#	und in Timestamp umwandeln

	os.utime(path, (timestamp, timestamp))	# neuen Timestamp in Datei speichern
