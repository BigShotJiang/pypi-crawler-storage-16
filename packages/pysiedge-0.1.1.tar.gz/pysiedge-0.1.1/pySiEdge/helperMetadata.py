# SPDX-FileCopyrightText: Copyright © 2024-2025 Damian Anders <damian.anders@tu-dresden.de>
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""Funktionen zur Vorverarbeitung von Dateien, die von 'Analyze MyWorkpiece /Capture4Analysis' erstellt wurden, anhand ihrer Metadaten"""

from ast import literal_eval
from os import SEEK_END

__all__ = ["parseFilePathChain", "sortByRun"]

def parseFilePathChain(jsonFilePaths: list[str],
) -> list[dict[str, str]]:
	"""
	Footer aller übergebenen AMW4Capture-JSON-Dateien parsen und enthaltenen Parameter ``FilePathChain`` als dict zurückgeben.

	Parameters
	----------
	jsonFilePaths : list[str]
		Liste mit Dateipfaden

	Returns
	-------
	list[dict[str, str]]
		Liste mit dicts des Footer-Parameters ``FilePathChain``
	"""

	allFPC = list()
	for filePath in jsonFilePaths:
		with open(filePath, 'rb') as f_in:	# MUSS Binärmodus sein
			f_in.seek(-1024, SEEK_END)  				# Pointer an 1024 Bytes vor Ende der JSON setzen,
			jsonTail = str(f_in.read())					#	Bytes bis EOF einlesen und in str konvertieren und
			jsonTail = jsonTail.replace('null', 'None')	#	Wert "null" durch Python-gerechtes "None" ersetzen
			idx = jsonTail.find("\"Previous")						# Position des Substrings ermitteln
			allFPC.append(literal_eval('{' + jsonTail[idx:-3]))	#	geschweifte Klammer vorne ergänzen, überflüssige Zeichen "}}'" am Ende abschneiden und str als dict parsen

	return allFPC


def sortByRun(allFilePathChains: list[dict[str, str]],
) -> list[list[int]]:
	"""
	JSON-Dateien eines Jobs ihren Runs zuordnen und korrekte Reihenfolge innerhalb der Runs ermitteln.
	Durch die Verwendung der Datei-Footer ist die Funktion robust gegenüber Dateinamenänderungen.

	Parameters
	----------
	allFilePathChains : list[dict[str, str]]
		Liste mit dicts des Footer-Parameters ``FilePathChain``, erstellt durch die Funktion ``parseFilePathChain``

	Returns
	-------
	list[list[int]]
		Liste, die für jeden Run des Jobs eine Liste enthält, die wiederum jeweils die Indizes der Reihenfolge der
		Dateien des Runs bezogen auf die Reihenfolge in ``allFilePathChains`` enthält

	Notes
	-----
	Die Implementierung des Such-Algorithmus als for-Schleife über alle Dateien innerhalb einer while-Schleife ist potentiell extrem langsam.
	In der Praxis dürfte dies jedoch keine Rolle spielen, da bei nicht umbenannten Dateien die Reihenfolge der Dateien in "allFilePathChains"
	der Reihenfolge innerhalb der Runs entspricht und die for-Schleife über "b" somit nur einmal pro Run ausgeführt wird.
	"""

	idxRunFirst = list()
	for a in range(len(allFilePathChains)):				# alle Footer überprüfen:
		if allFilePathChains[a]['Previous'] is None:	#	Dateien, bei denen keine Datei im Parameter "Previous" steht,
			idxRunFirst.append(a)						#		sind die jeweils erste Datei eines Runs

	order = list()
	for a in range(len(idxRunFirst)):							# für alle Runs:
		sessionOrder = list()									#	leere Liste für Reihenfolge der Dateien dieses Runs
		nextRun = False											#	Steuervariable rücksetzen
		fileName = allFilePathChains[idxRunFirst[a]]['Actual']	#	(Original-)Dateiname der ersten Datei dieses Runs

		while not nextRun:
			for b in range(len(allFilePathChains)):				# für alle Dateien des Jobs:
				if allFilePathChains[b]['Actual'] in fileName:	#	wenn gesuchter Dateiname als Dateiname der aktuellen Datei im Footer angegeben
					sessionOrder.append(b)						#		Index der aktuellen Datei der Reihenfolge dieses Runs hinzufügen
					if allFilePathChains[b]['Next'] is None:	#		wenn die aktuelle Datei keinen Nachfolger hat, also letzte Datei des Runs ist
						order.append(sessionOrder)				#			Reihenfolge-Liste des Runs der Liste aller Reihenfolgen des Jobs hinzufügen
						nextRun = True							#			Steuervariable zum Verlassen der for-Schleife setzen
						break									#			und while-Schleife verlassen
					else:
						fileName = allFilePathChains[b]['Next']	#		anderenfalls Dateinamen der nächsten Datei des Runs als nächsten zu suchenden Dateinamen übernehmen

	return order
