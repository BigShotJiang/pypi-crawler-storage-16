# SPDX-FileCopyrightText: Copyright © 2024-2025 Damian Anders <damian.anders@tu-dresden.de>
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""Funktion zur Ablage von Daten, die von 'Analyze MyWorkpiece /Capture4Analysis' erstellt wurden, im HDF5-Dateiformat."""

import h5py
import numpy as np
import os

from .hdf5Meta import getPathsAll, getPathsLowest
from .hdf5Use import dsToNp
from .helperFiles import fixC4AFileTime
from .parseJson import _parseEdgeJson

__all__ = ["jsonToHdf5"]

def jsonToHdf5(jsonFilePaths: list[str],
			   runSequence: list[int],
			   allFPC: list[dict[str, str]],
			   fixModifyDate: bool = True,
			   verbose: bool = False,
			   dropUnchangedLF: bool = False,
			   deleteJson: bool = False,
) -> None:
	"""
	Lädt nacheinander alle Dateien eines Runs und speichert die Daten komprimiert in einer HDF5-Datei.

	Der Dateiname der resultierenden Datei setzt sich aus dem Job-Namen und der Erstellzeit der ersten Datei des Runs zusammen. Die Datei wird im selben Ordner
	gespeichert wie diese erste Datei des Runs.

	Parameters
	----------
	jsonFilePaths : list[str]
		Liste mit Dateipfaden
	runSequence : list[int]
		Liste mit Indizes, die die Dateien des aktuellen Runs bezogen auf ihre Position in ``jsonFilePaths`` sortieren
	allFPC : list[dict[str, str]]
		Liste mit dicts des Footer-Parameters ``FilePathChain``
	fixModifyDate : bool, default=True
		Setzt das Änderungsdatum der abgerufenen Datei auf den im Dateinamen angegebenen Zeitpunkt (Edge-Zeit).
		Falls ``False`` entspricht das Änderungsdatum dem Zeitpunkt des Abrufs (Zeit des abrufenden Rechners).
		Das Erstelldatum entspricht in jedem Fall dem Zeitpunkt des Abrufs.
		Standardwert ist ``True``
	verbose : bool, default=False
		Gibt Informationen zum Fortschritt aus.
		Standardwert ist ``False``
	dropUnchangedLF : bool, default=False
		Entfernt Einträge in LF-Kanälen, die keine Veränderung enthalten.
		Standardwert ist ``False``
	deleteJson : bool, default=False
		JSON-Dateien nach Ablage in HDF5-Datei löschen.
		Standardwert ist ``False``

	Returns
	-------
	None

	Notes
	-----
	- Die Kompression ist auf maximal gesetzt.
	"""

	originalFileName = allFPC[runSequence[0]]['Actual']	# ursprünglicher Dateiname der ersten Datei des Runs
	[jobName, _, startingTime] = os.path.splitext(originalFileName)[0].rsplit('_', 2)	# Dateiendung entfernen und Rest aufteilen: [jobName, runID, startingTime]
	h5Name = f"{jobName}_{startingTime}.hdf5"
	folderPath = os.path.dirname(jsonFilePaths[runSequence[0]])
	filePath = os.path.join(folderPath, h5Name)

	with h5py.File(filePath, mode="w") as f_hdf5:	# HDF5-Datei erstellen
		z = 1
		for r in runSequence:
			jsonData = _parseEdgeJson(jsonFilePaths[r])	# JSON-Datei parsen
			if r == runSequence[0]:						#	bei der ersten Datei jedes Runs die Dateistruktur initialisieren, dazu
				for p in range(len(jsonData['pathsHF'])):				# für jeden HF-Kanal
					fullPath = ('HFData/' + jsonData['pathsHF'][p])		#	den Kanal unter die Obergruppe "HFData" setzen
					f_hdf5.create_dataset(fullPath, (0,),  		#	einen Datensatz erstellen, mit:
										  dtype=jsonData['dtypeHF'][p],	#		-entsprechendem dtype
										  chunks=(10000,),  			#		-10k Werten pro Speicherblock
										  maxshape=(None,),  			#		-variabler Größe
										  compression="gzip",  			#		-verlustfreier Kompression
										  shuffle=True,  				#		-optimierter Byte-Anordnung
										  compression_opts=9)			#		-maximaler Kompression

				for p in range(len(jsonData['pathsLF'])):				# für jeden LF-Kanal analog vorgehen,
					fullPath = ('LFData' + jsonData['pathsLF'][p])
					f_hdf5.create_dataset(fullPath, (0,),
										  dtype=jsonData['dtypeLF'][p],
										  chunks=(10,),  				#	geringere Speicherblockgröße, da erheblich weniger zu erwartende Werte
										  maxshape=(None,),
										  compression="gzip",
										  shuffle=False,  				#	Byte-Optimierung nicht aktivieren, da der Overhead die Optimierung zunichte macht
										  compression_opts=9)

			for typeF in ['HF', 'LF']:
				for p in range(len(jsonData[f'paths{typeF}'])):  				# HF- und LF-Kanäle in Datei schreiben, dazu
					fullPath = (f'{typeF}Data/' + jsonData[f'paths{typeF}'][p])	# Kanal unter die Obergruppe "HFData" oder "LFData" setzen
					fullPath = fullPath.replace("//", "/")			# `jsonData[f'paths{typeF}'][p]` beginnt für "LFData" mit "/", für "HFData" nicht
					idxNextRow = f_hdf5[fullPath].shape[0]						# Startindex der hinzuzufügenden Werte ermitteln
					f_hdf5[fullPath].resize(idxNextRow + len(jsonData[f'data{typeF}'][p]), axis=0)	# Ziel-Array um Anzahl der hinzuzufügenden Werte vergrößern
					# `jsonData[f'data{typeF}'][p]` ist für "LFData" eine Liste; für "HFData" aber ein 2D-Array, bei dem die Zeilenanzahl relevant ist.
					#	Für beide Varianten kann `len()` verwendet werden, da `len(x) == x.shape[0]`
					f_hdf5[fullPath][idxNextRow:] = jsonData[f'data{typeF}'][p]	# Werte hinzufügen

			if verbose:
				print(f"Datei {z} von {len(runSequence)} in Run \"{startingTime}\" des Jobs \"{jobName}\" verarbeitet.")
			z = z+1

			if deleteJson:
				os.remove(jsonFilePaths[r])

		if dropUnchangedLF:
			_dropUnchangedLF(f_hdf5)

	if fixModifyDate:
		fixC4AFileTime(filePath)  # Änderungsdatum der Datei auf Erstellzeit in der Edge setzen


def _dropUnchangedLF(fileHandle: h5py.File,
) -> None:
	"""
	Entfernt Datenpunkte in der Group "LFData", an denen keine Änderung zum vorherigen Zustand erfolgt.

	Warnings
	--------
	Die Funktion arbeitet destruktiv, Änderungen werden direkt in die Datei geschrieben.

	Parameters
	----------
	fileHandle : h5py.File
		File handle der geöffneten Datei.

	Returns
	-------
	None
	"""
	pathGroupsLowest = getPathsLowest(getPathsAll(fileHandle, filterPath="LFData", groups=True))	# Pfade aller Groups der untersten Ebene in Datei finden

	for pathGroup in pathGroupsLowest:	# für jede Group
		pathsDS = getPathsAll(fileHandle, filterPath=pathGroup, datasets=True)	# in der Group enthaltene Datasets

		pathValue = pathGroup + "/value"	# Pfad des `value`-Datasets
		old = dsToNp(fileHandle, pathValue, dtype=fileHandle[pathValue].dtype) # Daten aus `value` übernehmen

		boolDiff = np.asarray(np.diff(old), dtype=np.bool_)	# bool-Vektor kennzeichnet Änderungen in den Daten
		boolKeep = np.concatenate(([np.True_], boolDiff))	# erster Datenpunkt muss immer erhalten bleiben
		numKeep = boolKeep.sum()	# Anzahl der unterschiedlichen Datenpunkte in `value`

		for pDS in pathsDS:	# für jedes Dataset in der aktuellen Group
			old = dsToNp(fileHandle, pDS, dtype=fileHandle[pDS].dtype)  # alle Datenpunkte aus Dataset in temporäres Array kopieren
			fileHandle[pDS].resize(numKeep, axis=0)									# Dataset auf Zielgröße verkleinern
			fileHandle[pDS].write_direct(old, source_sel=np.s_[boolKeep])			# nur Datenpunkte mit Unterschieden zurück in Dataset schreiben
