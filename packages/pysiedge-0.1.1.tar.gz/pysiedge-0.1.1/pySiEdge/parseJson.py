# SPDX-FileCopyrightText: Copyright © 2024-2025 Damian Anders <damian.anders@tu-dresden.de>
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""Funktionen zum Parsen von Dateien, die von 'Analyze MyWorkpiece /Capture4Analysis' erstellt wurden."""

import logging
import numpy as np
import json

logging.basicConfig(format='%(levelname)s:%(message)s', level=logging.WARNING)

__all__ = ["_parseEdgeJson"]

class JSONError(ValueError):
	pass

def _toNumpyDtype(dtypeC4AString: str,
				  ) -> np.dtype:
	"""
	Übersetzt die Datentyp-Strings der AMW4Capture-JSON in den entsprechenden numpy-dtype.

	Parameters
	----------
	dtypeC4AString : {'INTEGER', 'DOUBLE', 'STRING', 'Int', 'Double', 'Str'}
		String mit Datentyp des Parameters

	Returns
	-------
	numpy.dtype
		äquivalenter NumPy- bzw. h5py-dtype

	Notes
	-----
	- Der Parameter HFData/Power hat wohl den falschen Datentyp, mit variable-length string wird der resultierende Fehler umgangen.
	- Die umständliche Suche ist notwendig, da bei HF- und LF-Signalen unterschiedliche Bezeichnungen für den gleichen Datentyp verwendet werden.
	"""

	dtypeMap = {'uinteger': np.uint64,	# Zuordnung aller auftretenden Datentypen
				 'double': np.float64,
				 'string': np.dtypes.StringDType()}
	isDtype = [value for key, value in dtypeMap.items() if dtypeC4AString.casefold() in key]
	return isDtype[0]


def _parseEdgeJson(singleJsonFilePath: str,
) -> dict[str, list]:
	"""
	Öffnet eine mit "Analyze MyWorkpiece /Capture4Analysis" erstellte JSON-Datei und gibt ihren Inhalt geordnet zurück.

	Parameters
	----------
	singleJsonFilePath : str
		Pfad zur zu importierenden Datei

	Returns
	-------
	dict[str, list]
		Dictionary mit Inhalten der importierten JSON-Datei, jeweils umgewandelt in passende Datenformate
	"""

	logging.warning("Die korrekte Behandlung von Strings ist in der aktuellen Implementierung nicht getestet!")

	with open(singleJsonFilePath, mode='rt', encoding='utf8') as f_json:
		currentJSON = json.load(f_json)  # JSON parsen

		numChHF = len(currentJSON['Header']['SignalListHFData'])  # Anzahl der geloggten HF-Kanäle
		numTicksHF = 0  # Anzahl der Zeitlinien der HF-Kanäle
		dtypeHF = list()
		pathsHF = list()
		for ch in currentJSON['Header']['SignalListHFData']:  # für jeden HF-Kanal:
			dtypeHF.append(_toNumpyDtype(ch['Type']))  # passenden numpy-dtype in Liste übernehmen

			if not ch['Axis']:
				pathsHF.append(f"{ch['Name']}")
			else:
				pathsHF.append(f"{ch['Name']}/{ch['Axis']}")  # Pfadnamen zusammenstellen und in Liste übernehmen

			if len(set(pathsHF)) < len(pathsHF):
				runName = singleJsonFilePath.rsplit('/', maxsplit=1)	# Dateiname, falls Separator "/"
				runName = runName[-1].rsplit('\\', maxsplit=1)			# Dateiname, falls Separator "\"
				runName = runName[-1].rsplit('_', maxsplit=1)			# Jobname und Run-ID von Startdatum trennen
				raise JSONError(f"Die Beschreibung der Kanäle in den Dateiheadern des Runs \"{runName[0]}\" ist beschädigt. Mögliche Workarounds siehe 'README.md'.")

		numChLF = len(currentJSON['Header']['SignalListLFData'])  # Anzahl der geloggten LF-Kanäle
		if numChLF > 0:
			dataLFDictList = [[]] * numChLF	# leere Listen mit Länge `numChLF` initialisieren
			dtypeLFvalue: list[np.dtype | None]	# für Type Checker
			dtypeLFvalue = [None] * numChLF
			shortPathsLF = [ch['path'] for ch in currentJSON['Header']['SignalListLFData']]  # Pfadnamen der LF-Kanäle in Liste schreiben
		else:
			dataLFDictList = list()  # leere Listen erstellen, falls kein LF-Logging erfolgt ist
			shortPathsLF = list()
		skipSets = list()  # Liste mit Indizes der Elemente, die entweder LF- oder keine Messdaten enthalten
		for a in range(len(currentJSON['Payload'])):  # jedes Element in 'Payload' durchgehen
			if 'HFData' in currentJSON['Payload'][a].keys():  # überprüfen, ob es HF-Daten enthält
				numTicksHF = numTicksHF + len(currentJSON['Payload'][a]['HFData'])  # falls ja: Anzahl der Zeitlinien im Element der Gesamtanzahl hinzufügen
			else:  # wenn keine HF-Daten im aktuellen Element:
				skipSets.append(a)  # Index des Elements der Liste hinzufügen
				if (numChLF > 0) and ('LFData' in currentJSON['Payload'][a].keys()):  # prüfen, ob das Element LF-Daten enthält
					for dp in currentJSON['Payload'][a]['LFData']:					# falls ja: für jeden geloggten Kanal im aktuellen Element
						idxLF = shortPathsLF.index(dp['address'])					# den Index ermitteln, der der Adresse des Kanals entspricht
						if not dtypeLFvalue[idxLF]:									# prüfen, ob der dtype schon in der dazugehörigen Liste steht
							dtypeLFvalue[idxLF] = _toNumpyDtype(dp['value_type'])	# falls nicht: passenden numpy-dtype in Liste übernehmen
						pruneDict = dp 										# Kopie des aktuellen Elements (dict) erstellen
						_ = pruneDict.pop('address')  						# und aus diesem dict die pro Kanal unveränderlichen Elemente 'address' (steht bereits in `shortPathsLF`)
						_ = pruneDict.pop('value_type')  					# und 'value_type' (steht bereits in `dtypeLFvalue`) entfernen,
						dataLFDictList[idxLF].append(pruneDict)  			# schließlich die Daten des aktuellen Kanals im aktuellen Element der Liste mit Daten des Kanals hinzufügen

		pathsLF = list()
		dataLF = list()
		dtypeLF = list()

		for c in range(len(dataLFDictList)):					# für jeden LF-Kanal
			# ! "shortPathsLF" und "dataLFDictList" sind einander SICHER zugeordnet (über "idxLF")
			for key in dataLFDictList[c][0].keys():			#	für jeden Key
				pathsLF.append(f"{shortPathsLF[c]}/{key}")	#	diesen der Pfad-Liste hinzufügen

				temp_list = list()
				for row in range(len(dataLFDictList[c])):	# alle Datenpunkte des aktuellen Keys des aktuellen Kanals zu temporärer Liste zusammenstellen
					temp_list.append(dataLFDictList[c][row][key])

				if key == 'HFProbeCounter':					# temporäre Liste je nach dtype der Liste `dataLF` hinzufügen
					dataLF.append(np.array(temp_list, dtype=np.uint64))
					dtypeLF.append(np.uint64)
				elif key == 'timestamp':
					dataLF.append(temp_list)
					dtypeLF.append('S24')	# dtype folgt Empfehlung in h5py für numpy>=2.0; Zeitstring ist hier maximal 24 Zeichen lang
				elif key == 'value':
					try:
						dataLF.append(np.array(temp_list, dtype=dtypeLFvalue[c]))
					except ValueError as exc:
						if "to float" not in exc.__str__():
							raise ValueError(f"Der Kanal \"{shortPathsLF[c]}\" in der Datei {singleJsonFilePath} enthält ungültige Werte. Dieser Fehler kann nicht automatisch behandelt werden.")
						else:
							logging.warning(f"Der Kanal \"{shortPathsLF[c]}\" enthält den ungültigen Wert {exc.__str__().rsplit(" ", 2) [-1]}. Dieser Datenpunkt wird als `np.nan` in die Datei geschrieben.\n"
											"Diese automatische Fehlerverarbeitung ist experimentell. Das Ergebnis sollte manuell überprüft werden.")
							temp_arr = np.zeros(len(temp_list), dtype=dtypeLFvalue[c])
							for a in range(len(temp_list)):
								try:
									# noinspection PyArgumentList
									temp_arr[a] = np.fromstring(temp_list[a], dtype=dtypeLFvalue[c], count=1)[0]
								except ValueError:
									temp_arr[a] = np.nan
							dataLF.append(temp_arr)

					dtypeLF.append(dtypeLFvalue[c])
				else:
					raise Exception(f'Unbekannter key {key}')

		dataHF = list()
		for isDtype in dtypeHF:  # Liste erstellen, die für jeden HF-Kanal ein numpy-Array (Nullen) mit passender Länge und passendem dtype enthält
			dataHF.append(np.zeros(numTicksHF, dtype=isDtype))

		z = 0
		ignoreWarnCh = list()
		for a in range(len(currentJSON['Payload'])):				# für jedes Element in 'Payload',
			if a in skipSets:
				continue
			else:  													#	das HF-Daten enthält
				numRows = len(currentJSON['Payload'][a]['HFData'])	# Anzahl der Zyklusticks im aktuellen Element
				for row in range(numRows):		# für jeden Zyklustick
					for ch in range(numChHF):	#	und jeden Messkanal den jeweiligen Wert mit passendem dtype in das dazugehörige numpy-Array übernehmen
						try:
							dataHF[ch][z + row] = np.array(currentJSON['Payload'][a]['HFData'][row][ch], dtype=dtypeHF[ch])
						except TypeError:				# Fehler abfangen, die durch fehlerhafte Messkanäle auftreten
							if ch not in ignoreWarnCh:	#	und Warnung pro Kanal nur einmal ausgeben
								logging.warning(f"Der Kanal \"{pathsHF[ch]}\" kann nicht importiert werden. Die Daten in der entsprechenden Variable werden ungültig sein.")
								ignoreWarnCh.append(ch)
							else:
								pass
				z = z + numRows

	return {"dataHF": dataHF,
			"dtypeHF": dtypeHF,
			"pathsHF": pathsHF,
			"dataLF": dataLF,
			"dtypeLF": dtypeLF,
			"pathsLF": pathsLF,
			}
