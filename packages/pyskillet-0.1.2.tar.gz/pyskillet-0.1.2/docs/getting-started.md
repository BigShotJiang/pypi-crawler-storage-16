# Getting Started

## Installation

```bash
pip install skillet
```

## Basic Usage

Skillet provides tools for capturing gaps in Claude Code skills and running evaluations to improve them.
