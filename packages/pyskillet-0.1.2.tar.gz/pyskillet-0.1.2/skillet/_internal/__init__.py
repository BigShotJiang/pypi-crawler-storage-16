"""Internal utilities - not part of public API."""
