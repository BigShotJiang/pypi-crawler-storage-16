"""Integration tests with mocked LLM calls."""
