"""Compare baseline vs skill results."""

from .run import compare

__all__ = ["compare"]
