"""Gap loading and management."""

from .load import load_gaps

__all__ = ["load_gaps"]
