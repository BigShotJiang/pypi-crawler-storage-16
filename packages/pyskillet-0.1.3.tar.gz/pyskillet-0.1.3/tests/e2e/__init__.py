"""End-to-end tests for the skillet CLI."""
