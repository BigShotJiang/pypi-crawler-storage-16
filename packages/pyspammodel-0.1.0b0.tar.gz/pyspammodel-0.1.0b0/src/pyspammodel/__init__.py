from pyspammodel._solar_spam import SolarSpam
from pyspammodel._aero_spam import AeroSpam
