# Installation

```bash
uv add pytablut
# Or
python3 -m pip install pytablut
```
