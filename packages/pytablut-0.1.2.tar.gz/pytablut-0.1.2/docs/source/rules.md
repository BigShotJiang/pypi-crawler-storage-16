# Rules

There are multiple variants of Tablut; this implementation follows the Ashton rules.

## Ashton rules

![ashton_rules_1](/images/ashton_rule_1.png)
![ashton_rules_2](/images/ashton_rule_2.png)
![ashton_rules_3](/images/ashton_rule_3.png)
![ashton_rules_4](/images/ashton_rule_4.png)
![ashton_rules_5](/images/ashton_rule_5.png)
