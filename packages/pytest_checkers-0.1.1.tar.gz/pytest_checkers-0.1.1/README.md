# pytest-checkers

<table>
  <tr><td>1</td><td>2</td><td>4</td><td>8</td><td>16</td><td>◻</td><td>◼</td><td>◻</td></tr>
  <tr><td>◻</td><td>◼</td><td>◻</td><td>◼</td><td>◻</td><td>◼</td><td>◻</td><td>◼</td></tr>
  <tr><td>◼</td><td>◻</td><td>◼</td><td>◻</td><td>◼</td><td>◻</td><td>◼</td><td>◻</td></tr>
  <tr><td>◻</td><td>◼</td><td>◻</td><td>◼</td><td>◻</td><td>◼</td><td>◻</td><td>◼</td></tr>
  <tr><td>◼</td><td>◻</td><td>◼</td><td>◻</td><td>◼</td><td>◻</td><td>◼</td><td>◻</td></tr>
  <tr><td>◻</td><td>◼</td><td>◻</td><td>◼</td><td>◻</td><td>◼</td><td>◻</td><td>◼</td></tr>
  <tr><td>◼</td><td>◻</td><td>◼</td><td>◻</td><td>◼</td><td>◻</td><td>◼</td><td>◻</td></tr>
  <tr><td>◻</td><td>◼</td><td>◻</td><td>◼</td><td>◻</td><td>◼</td><td>◻</td><td>◼</td></tr>
</table>
