from .toolbox import configure_djangoapp_plugin

VERSION = '1.7.0'
"""Application version number tuple."""


__all__ = ['VERSION', 'configure_djangoapp_plugin']