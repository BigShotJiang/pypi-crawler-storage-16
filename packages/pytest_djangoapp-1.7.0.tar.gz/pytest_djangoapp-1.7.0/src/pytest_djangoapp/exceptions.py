
class DjangoappException(Exception):
    """Base Djangoapp exception."""
