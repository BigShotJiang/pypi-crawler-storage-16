def hello() -> str:
    return "Hello from pytest-flakiness!"
