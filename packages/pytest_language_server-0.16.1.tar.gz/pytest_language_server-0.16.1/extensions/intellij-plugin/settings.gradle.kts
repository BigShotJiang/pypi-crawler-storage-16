rootProject.name = "pytest-language-server"

// Enable automatic toolchain provisioning for Java 21
plugins {
    id("org.gradle.toolchains.foojay-resolver-convention") version "1.0.0"
}
