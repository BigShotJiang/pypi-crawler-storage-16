def main():
    print("Hello from pytest-llm-agent!")


if __name__ == "__main__":
    main()
