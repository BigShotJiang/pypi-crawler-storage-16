"""
Fixtures to simplify and improve the performance of repo health checks.
"""
