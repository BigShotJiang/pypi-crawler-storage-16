from .core import TestCase
from .utils.logs.core import log

__author__ = "luyh"

__version__ = "0.10.0"

__description__ = "pytestifyx is a pytest-based automation testing framework for api, ui, app testing"
