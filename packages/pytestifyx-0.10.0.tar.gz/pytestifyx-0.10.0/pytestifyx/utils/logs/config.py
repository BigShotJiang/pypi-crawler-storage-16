AUTO_PATCH_PRINT = True  # 是否自动打print的猴子补丁
