# from pythagoras._020_ordinary_code_portals import OrdinaryCodePortal
# from pythagoras._010_basic_portals import _PortalTester
# from parameterizable import smoketest_parameterizable_class
#
#
# def test_basic_portal_get_params(tmpdir):
#     with _PortalTester(OrdinaryCodePortal, root_dict = tmpdir) as t:
#         smoketest_parameterizable_class(OrdinaryCodePortal)
#
