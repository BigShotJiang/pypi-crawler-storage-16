# CONSTANTS

# SECTION: default rules
DEFAULT_RULES_KEY = "ALL"

# NOTE: data/equations key
DATA_KEY = "DATA"
EQUATIONS_KEY = "EQUATIONS"

# SECTION: PyThermoDBLink/PyThermoDB
DATASOURCE = "datasource"
EQUATIONSOURCE = "equationsource"
