class AppError(Exception):
    pass
