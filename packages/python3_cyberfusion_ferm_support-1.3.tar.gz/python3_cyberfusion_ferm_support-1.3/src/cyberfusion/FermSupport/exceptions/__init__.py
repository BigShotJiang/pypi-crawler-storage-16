"""Exceptions."""


class ConfigInvalidError(Exception):
    """Config is invalid."""

    pass
