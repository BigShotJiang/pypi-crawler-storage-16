"""Exceptions."""


class MissingHostError(Exception):
    """Host is missing."""

    pass
