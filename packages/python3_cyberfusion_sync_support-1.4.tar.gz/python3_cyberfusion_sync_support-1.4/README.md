# python3-cyberfusion-sync-support

Library for syncing objects (e.g. directories).

# Install

## PyPI

Run the following command to install the package from PyPI:

    pip3 install python3-cyberfusion-sync-support

## Debian

Run the following commands to build a Debian package:

    mk-build-deps -i -t 'apt -o Debug::pkgProblemResolver=yes --no-install-recommends -y'
    dpkg-buildpackage -us -uc

# Configure

No configuration is supported.

# Usage

See code.
