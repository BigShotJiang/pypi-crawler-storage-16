"""Constants."""

import os

PATH_ARCHIVE = os.path.join(os.path.sep, "tmp", "sync-support-archives")
