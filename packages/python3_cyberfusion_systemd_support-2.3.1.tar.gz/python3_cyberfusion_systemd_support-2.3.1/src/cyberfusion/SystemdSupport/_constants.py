"""Constants."""

import os

SYSTEMCTL_BIN = os.path.join(os.path.sep, "bin", "systemctl")
