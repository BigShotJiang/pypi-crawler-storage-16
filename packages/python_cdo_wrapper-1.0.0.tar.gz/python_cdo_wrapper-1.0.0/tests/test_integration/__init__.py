"""Test __init__ files for new structure."""
