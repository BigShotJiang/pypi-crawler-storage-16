from cqrs.compressors.protocol import Compressor
from cqrs.compressors.zlib import ZlibCompressor

__all__ = ("ZlibCompressor", "Compressor")
