.. automodule:: gdsii.exceptions
    :members:
    :show-inheritance:
