import pyjsx.auto_setup

from props import App

print(App())
