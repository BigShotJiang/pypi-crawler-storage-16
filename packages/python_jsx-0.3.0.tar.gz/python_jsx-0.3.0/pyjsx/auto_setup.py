from pyjsx.codec_hook import register_jsx
from pyjsx.import_hook import register_import_hook


register_jsx()
register_import_hook()
