import pyjsx.auto_setup

from custom import App


print(App())
