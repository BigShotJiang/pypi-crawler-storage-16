import pyjsx.auto_setup

from custom_elements import App

print(App())
