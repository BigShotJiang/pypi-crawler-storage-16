import pyjsx.auto_setup

from table import make_table


print(make_table())
