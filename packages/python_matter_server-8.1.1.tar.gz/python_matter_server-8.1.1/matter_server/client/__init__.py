"""Client for the MatterServer."""

from .client import MatterClient

__all__ = ["MatterClient"]
