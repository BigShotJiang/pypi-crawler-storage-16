"""Helpers/utils for the Matter Server."""

DCL_PRODUCTION_URL = "https://on.dcl.csa-iot.org"
DCL_TEST_URL = "https://on.test-net.dcl.csa-iot.org"
