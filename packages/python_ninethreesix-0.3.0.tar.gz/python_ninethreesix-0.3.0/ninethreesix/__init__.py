__version__ = "0.3.0"
VERSION = __version__

from .password import Password, unreadable_password
