"""Traits for B01 devices."""

from .q7 import Q7PropertiesApi

__all__ = ["Q7PropertiesApi", "q7", "q10"]
