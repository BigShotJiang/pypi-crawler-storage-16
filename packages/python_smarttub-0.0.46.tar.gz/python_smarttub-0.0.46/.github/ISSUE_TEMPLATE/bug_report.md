---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**Debug info**
If this module is not working with your device, please run the following
command and include the output with your bug report:

```bash
python3 -m smarttub -u YOUR_SMARTTUB_EMAIL -p YOUR_SMARTTUB_PASSWORD -vv info -a
```
