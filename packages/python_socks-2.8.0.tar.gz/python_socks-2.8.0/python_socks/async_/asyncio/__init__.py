from ._proxy import AsyncioProxy as Proxy


__all__ = ('Proxy',)
