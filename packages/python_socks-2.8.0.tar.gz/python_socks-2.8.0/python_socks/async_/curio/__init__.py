from ._proxy import CurioProxy as Proxy


__all__ = ('Proxy',)
