from ._proxy import TrioProxy as Proxy
from ._chain import ProxyChain

__all__ = (
    'Proxy',
    'ProxyChain',
)
