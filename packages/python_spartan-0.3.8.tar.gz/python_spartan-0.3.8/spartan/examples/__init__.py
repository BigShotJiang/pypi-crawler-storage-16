"""Examples and documentation for Spartan CLI utilities."""
