SR_URL_TEST: str = 'https://smartroute-test.payone.io/SmartRoutePaymentWeb/SRPayMsgHandler'
SR_URL_LIVE: str = 'https://smartroute.payone.io/SmartRoutePaymentWeb/SRPayMsgHandler'


"""SR URL for Inquiry, Refund, Recurring"""
SR_URL_SUPPORT_TEST: str = 'https://smartroute-test.payone.io/SmartRoutePaymentWeb/SRMsgHandler'
SR_URL_SUPPORT_LIVE: str = 'https://smartroute.payone.io/SmartRoutePaymentWeb/SRMsgHandler'

REDIRECT_MESSAGE_ID: str = '1'
REDIRECT_VERIFY_MESSAGE_ID: str = '14'
INQUIRY_MESSAGE_ID: str = '2'