"""Tests for PatternAPI module."""
