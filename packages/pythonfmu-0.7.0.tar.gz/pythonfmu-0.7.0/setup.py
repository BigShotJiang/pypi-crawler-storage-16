from setuptools import setup

# See setup.cfg for Python package parameters
setup()
