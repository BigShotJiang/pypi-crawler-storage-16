# Lisp-Py
Lisp programming language - Implemented purely in Python 3.14

Lisp is intended as an toy interpreter for a very simple Lisp dialect.

Lisp is implemented entirely in python 3.14.

Uses
==========
Educational Only.

HOW TO USE
==========
Just needs Python 3.14.

Download.

execute:  python Lisp.py

