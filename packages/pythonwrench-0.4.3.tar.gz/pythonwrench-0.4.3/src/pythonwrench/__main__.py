#!/usr/bin/env python
# -*- coding: utf-8 -*-

from .entries import print_install_info

if __name__ == "__main__":
    print_install_info()
