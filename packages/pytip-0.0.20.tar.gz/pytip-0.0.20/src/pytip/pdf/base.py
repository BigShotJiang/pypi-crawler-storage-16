import re
from pathlib import Path
from typing import List, Optional, Tuple
from pikepdf import Pdf, OutlineItem
