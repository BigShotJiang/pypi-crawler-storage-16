__extension_version__ = "0.45.0"
__extension_name__ = "pytket-braket"
