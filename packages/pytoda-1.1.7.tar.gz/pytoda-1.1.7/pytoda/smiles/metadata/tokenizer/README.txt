This SMILES Language has seen the following Databases:

- ZINC (1.8B)
- GDSC (~250)
- CCLE (~500)
- ChEMBL (~2M)
- Tox21 (~10k)
- OrganDB (~1k)
- BindingDB (~500k)
- VDJ (~100)
- ImmuneRACE/ImmunoCode (~150)