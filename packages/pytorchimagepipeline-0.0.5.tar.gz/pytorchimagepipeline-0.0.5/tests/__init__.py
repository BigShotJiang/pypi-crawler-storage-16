"""Test package for TensorImgPipeline."""
