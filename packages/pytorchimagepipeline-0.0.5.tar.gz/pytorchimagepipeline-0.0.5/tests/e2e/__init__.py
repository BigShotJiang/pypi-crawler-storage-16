"""End-to-end tests for TensorImgPipeline.

Tests the complete system with fake filesystem and realistic scenarios.
"""
