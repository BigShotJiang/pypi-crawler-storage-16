"""Integration tests for TensorImgPipeline.

Tests multiple components working together.
"""
