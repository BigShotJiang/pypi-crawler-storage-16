"""
Examples package for pytrickle.

This package contains example implementations and utilities for working with pytrickle.
"""
