# Trilogy CLI

## Local Testing

```bash
python -m trilogy.scripts.trilogy unit C:\Users\ethan\coding_projects\pypreql\tests\scripts\validation_failure.preql
```