=======
Credits
=======

Development Lead
----------------

* Leszek Grzanka <leszek.grzanka@ifj.edu.pl>

Contributors
------------

* Jakob Toftegaard
* Niels Bassler
* Toke Printz
* Leszek Grzanka
* Łukasz Jeleń
* Arkadiusz Ćwikła
* Joanna Fortuna
* Michał Krawczyk
* Mateusz Łaszczyk
