from enum import Enum


class AnglesStandard(Enum):
    TRIP = 1
    IEC = 2
