Clients
=======

.. automodule:: pyUSPTO.clients.bulk_data
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: pyUSPTO.clients.patent_data
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: pyUSPTO.clients.petition_decisions
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: pyUSPTO.clients.ptab_appeals
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: pyUSPTO.clients.ptab_interferences
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: pyUSPTO.clients.ptab_trials
   :members:
   :undoc-members:
   :show-inheritance: