# Small utilities for path, strings, fs, dict, .etc manipulation. mark1

### Usage

```
```