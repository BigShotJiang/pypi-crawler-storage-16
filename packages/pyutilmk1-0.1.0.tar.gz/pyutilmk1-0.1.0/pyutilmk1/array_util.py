from typing import Any, Callable


ArrayOrSing = Any | list[Any]


def arrayify(value: ArrayOrSing) -> list[Any]:
    if (not value):
        return []

    if (not isinstance(value, list)):
        return [value]

    return value


def arrayify_filter(value: ArrayOrSing) -> list[Any]:
    value_as_array = arrayify(value)

    return list(filter(lambda item: item, value_as_array))


def filter_by(items: list[Any], fn: Callable, *args, **kw_args) -> list[Any]:
    if not items:
        return []

    filtered_items = []

    for item in items:
        is_included = fn(item, *args, **kw_args)
        if is_included:
            filtered_items.append(item)

    return filtered_items
