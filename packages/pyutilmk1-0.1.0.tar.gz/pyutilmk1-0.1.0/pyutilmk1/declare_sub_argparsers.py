
import argparse
from argparse import ArgumentParser
from typing import Any, Callable, Iterable, TypedDict
from pyutilmk1 import functional
from pyutilmk1.array_util import arrayify, arrayify_filter


def wrap_fn_extract_vars(inner_fn: Callable[[dict], Any]) -> Callable:
    def wrapped_fn(config: object):

        if (hasattr(config, '__dict__')):
            parsed_config_dict: dict = vars(config)
        else:
            parsed_config_dict: dict = config

        return inner_fn(parsed_config_dict)
    return wrapped_fn


ParsedConfigType = Any
OptionFns = list[Callable] | Callable | None


class ParserOptionsDef(TypedDict):
    help: str | None
    aliases: list[str] | str | None
    options: list[Callable] | Callable | None
    add_opts_sub: bool
    fn: Callable[[ParsedConfigType], None] | None
    sub_parsers: dict[str, 'ParserOptionsDef'] | None


# SubParsersAddDict = argparse._SubParsersAction[ArgumentParser] | None
SubParsersAddDict = Any

"""
Example for a subparsers_factory declaration (global is the main/master parser from which the
subparsers_factory are forked)

declare_subparsers_dict = {
    'options': add_global_bookmark_options,
    'help': "Manage bookmarks in database and .md"
    'sub_parsers': {
        'url': {
            'options': [add_url_bookmarks_store_options, add_groupable_store_options],
            'fn': store_url_bookmarks_fn
            'help': "Store target urls in database",
        },
        'clip': {
            'options': [add_groupable_store_options],
            'fn': store_url_bookmarks_fn
            'help': "Store target urls in database",
            'aliases': ['c']
        }
    }
}
"""


def get_parser(
    parser_factory: SubParsersAddDict | None = None,
    override_parser_base: ArgumentParser | None = None,
    init_options: dict | None = None,
    parser_key: str | None = None
) -> ArgumentParser:
    if not init_options:
        init_options = {}

    if (override_parser_base):
        return override_parser_base

    if (parser_factory):
        return parser_factory.add_parser(parser_key, **init_options)

    if ('help' in init_options):
        init_options['description'] = init_options['help']
        del init_options['help']

    target_parser = ArgumentParser(
        **init_options  # Maybe reroute help to description
    )

    return target_parser


def init_declared_sub_parsers(
    sub_parsers: dict[str, ParserOptionsDef] | None,
    parent_parser: ArgumentParser,
    override_sub_parsers_factory: SubParsersAddDict | None = None,
    run_fn_wrapper_fn: Callable = wrap_fn_extract_vars,
    initial_option_fns: OptionFns = None,
    ancestor_run_fns: list[Callable] = []
) -> list[ArgumentParser]:

    if (not sub_parsers):
        return None

    subparsers_factory: SubParsersAddDict | None = override_sub_parsers_factory
    if (not subparsers_factory):
        subparsers_factory = parent_parser.add_subparsers()

    initialized_sub_parsers: list[ArgumentParser] = []
    for sub_parser_key in sub_parsers:
        sub_parser_options_def: ParserOptionsDef = sub_parsers[sub_parser_key]

        parser: ArgumentParser = init_declared_parser(
            sub_parser_options_def,
            parser_factory=subparsers_factory,
            parser_key=sub_parser_key,
            run_fn_wrapper_fn=run_fn_wrapper_fn,
            initial_option_fns=initial_option_fns,
            ancestor_run_fns=ancestor_run_fns
        )

        initialized_sub_parsers.append(parser)

    return initialized_sub_parsers


def get_dict_whiteout_keys(orig_dict: dict, whiteout_keys: list[str] | None = []) -> dict:
    dict_copy: dict = orig_dict.copy()
    if (not whiteout_keys):
        return dict_copy

    for key in whiteout_keys:
        if key in dict_copy:
            del dict_copy[key]

    return dict_copy


def init_declared_parser(
    parser_options_def: ParserOptionsDef,
    override_parser_base: ArgumentParser | None = None,
    parser_factory: SubParsersAddDict | None = None,
    parser_key: str | None = None,
    run_fn_wrapper_fn: Callable = wrap_fn_extract_vars,
    initial_option_fns: OptionFns = None,
    ancestor_run_fns: list[Callable] = []
) -> dict:

    parser_help = parser_options_def.get('help')
    if not parser_help:
        parser_help = ""

    # White out non argparse specific options
    init_options: dict = get_dict_whiteout_keys(
        parser_options_def,
        [
            'fn',
            'options',
            'sub_parsers',
            'add_opts_sub'
        ]
    )

    # Initialize/Create new parser
    target_parser: ArgumentParser = get_parser(
        parser_factory,
        override_parser_base,
        init_options=init_options,
        parser_key=parser_key
    )

    # Add options to the parser
    add_opts_sub: bool = parser_options_def.get('add_opts_sub', False)
    # If there are no sub parsers, we can not add option to them
    if not init_options.get('sub_parsers', None):
        add_opts_sub = False

    parser_option_fns = arrayify_filter(parser_options_def.get('options'))
    initial_option_fns = arrayify_filter(initial_option_fns)
    parser_option_fns += initial_option_fns

    if (not add_opts_sub):
        functional.multi_call_if_list(parser_option_fns, target_parser)

    # Set the main run fn of the parser
    subparser_fn = parser_options_def.get('fn')

    ancestor_run_fns: list[Callable] = arrayify_filter(ancestor_run_fns)
    current_run_fns: list[Callable] = []
    if (subparser_fn):
        current_run_fns = [run_fn_wrapper_fn(subparser_fn)]
    run_fn_chain: list[Callable] = ancestor_run_fns + current_run_fns

    if (subparser_fn):
        # target_parser.set_defaults(subparser_run_fn=run_fn_wrapper_fn(subparser_fn))
        target_parser.set_defaults(run_fns=run_fn_chain)

    # Recursively init sub parsers
    sub_initial_opt_fns = None
    if (add_opts_sub):
        sub_initial_opt_fns = arrayify_filter(initial_option_fns) + parser_option_fns

    sub_parsers: dict[str, ParserOptionsDef] | None = parser_options_def.get('sub_parsers')
    sub_parsers: list[ArgumentParser] = init_declared_sub_parsers(
        sub_parsers,
        parent_parser=target_parser,
        run_fn_wrapper_fn=run_fn_wrapper_fn,
        initial_option_fns=sub_initial_opt_fns,
        ancestor_run_fns=run_fn_chain
    )

    """return {
        'self': target_parser,
        'sub': sub_parsers
    }"""

    return target_parser


def init_parsers_parse(
    parser_declaration: ParserOptionsDef,
    # main_description: str = "",
    parser: ArgumentParser | None = None,
    # global_options_on_subparsers: bool = False
):
    if (not parser):
        parser = init_declared_parser(
            parser_declaration,
            override_parser_base=parser
        )

    args: argparse.Namespace = parser.parse_args()

    run_fn_chain: list[Callable] = args.run_fns
    if (run_fn_chain):
        run_result = args
        for run_fn in run_fn_chain:
            # run_result = run_fn(run_result)
            run_fn(args)


class ArgEnvOptions(TypedDict):
    env: str | list[str]
    arg: str | list[str]
    opts: dict[str, Any]


ArgEnvMap = dict[str, ArgEnvOptions]


def add_args_from_arg_env_map(arg_env_map: ArgEnvMap, parser: ArgumentParser) -> None:
    for option_target_key in arg_env_map:
        argy_env_options: ArgEnvOptions = arg_env_map[option_target_key]

        args_opts: str | list[str] = argy_env_options.get('arg')
        parser_opts: dict[str, Any] = argy_env_options.get('opts')
        if (args_opts):
            args: list[str] = arrayify_filter(args_opts)

            if (len(args) > 0):
                major_arg: str = '--' + args[0].lstrip('-')
                minor_args: list[str] = arrayify_filter(args[1:])
                minor_args = list(map(lambda arg: '-' + arg.lstrip('-'), minor_args))

                parser.add_argument(*minor_args, major_arg, **parser_opts)


def inflate_arg_env_defaults(arg_env_map: ArgEnvMap, config: dict[str, Any] = {}) -> dict:
    for option_target_key in arg_env_map:
        if (option_target_key not in config):
            argy_env_options: ArgEnvOptions = arg_env_map[option_target_key]

            # args_opts: str | list[str] = argy_env_options.get('args')
            parser_opts: dict[str, Any] = argy_env_options.get('opts')
            if (parser_opts):
                default_value: Any = parser_opts.get('default')
                config[option_target_key] = default_value

    return config
