from copy import deepcopy
from typing import Any


def get_non_transient_dict_prop(
    src_dict: dict,
    # prop that holds actual data of the node and not tree refs or structure
    transient_key: str = None
) -> dict:
    if not transient_key or not src_dict:
        return src_dict

    currentLevelDict: dict = src_dict
    while transient_key in currentLevelDict:
        currentLevelDict = currentLevelDict[transient_key]

    return currentLevelDict

# Migrated from ~/repos/ts-node-util-mk1


def get_key_from_dict(
    src_dict: dict,
    key: str = None,
    key_seperation_token: str = '.',
    # If the key is detected it is considered transient
    jump_into_key: str = None
) -> Any | None:

    if not key:
        return src_dict

    key_parts = key.split(key_seperation_token)
    # reversedParts = key_parts.reverse()

    currentLevelDict: dict = get_non_transient_dict_prop(
        src_dict,
        transient_key=jump_into_key
    )
    for key in key_parts:

        if key not in currentLevelDict:
            return None

        currentLevelDict = currentLevelDict[key]
        currentLevelDict = get_non_transient_dict_prop(
            currentLevelDict,
            transient_key=jump_into_key
        )

        if currentLevelDict is None:
            return None

    return currentLevelDict


def get_key_from_obj(
    src_obj: object,
    key: str = None,
    key_seperation_token: str = '.',
) -> Any | None:

    if not key:
        return src_obj

    key_parts = key.split(key_seperation_token)
    currentLevelObj: object = src_obj
    for key in key_parts:

        if not hasattr(currentLevelObj, key):
            return None

        currentLevelObj = getattr(currentLevelObj, key)

        if currentLevelObj is None:
            return None

    return currentLevelObj

# Migrated from ~/repos/ts-node-util-mk1


def set_key_in_dict(
    target_dict: dict,
    key: str,
    targetValue: Any,
    init_dict_value: dict = {},
    key_seperation_token: str = '.'
) -> None:

    if (not key):
        return

    keyParts = key.split(key_seperation_token)

    lastLevelDict: dict = target_dict

    for i in range(0, len(keyParts)):
        key = keyParts[i]
        if (not key in lastLevelDict):
            lastLevelDict[key] = deepcopy(init_dict_value)

        if (i < len(keyParts) - 1):
            lastLevelDict = lastLevelDict[key]

    lastKeyPart = keyParts[-1]
    if (type(lastLevelDict) == dict and lastKeyPart):
        lastLevelDict[lastKeyPart] = targetValue


def ensure_key_at_dict(
    dict_obj: dict,
    key: str,
    setValue: Any,
    init_dict_value: dict = {},
) -> Any | None:

    if (not key):
        return dict_obj

    current_key_value = get_key_from_dict(dict_obj, key)
    if current_key_value:
        return dict_obj

    set_key_in_dict(
        dict_obj,
        key,
        setValue,
        init_dict_value=init_dict_value
    )

    return dict_obj


def unpack_keys_to(
    src: dict,
    target: dict,
    src_to_target_keys_map: dict[str, str]
) -> dict:

    if not target:
        target = {}

    for unpack_key in src_to_target_keys_map:
        target_key = src_to_target_keys_map[unpack_key]
        unpacked_item_value = src.get(unpack_key)
        if (unpacked_item_value is not None):
            target[target_key] = unpacked_item_value

    return target
