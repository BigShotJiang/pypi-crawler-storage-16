from typing import Any, Callable


def multi_call_if_list(fn_or_fns: Callable | list[Callable], *args, **kw_args):
    if (not fn_or_fns):
        return

    if (isinstance(fn_or_fns, list)):
        for single_fn in fn_or_fns:
            single_fn(*args, **kw_args)
    else:
        fn_or_fns(*args, **kw_args)


def multiply_if_array(fn, target_args: Any | list[Any], *args, **kw_args):
    if not fn:
        return []

    if (not isinstance(target_args, list)):
        target_args = [target_args]

    results = []

    for item in target_args:
        result = fn(item, *args, **kw_args)
        results.append(result)

    return results


def get_chained_array_fn(fn):

    def chained_fn(target_args: Any | list[Any], *args, **kw_args):
        return multiply_if_array(fn, target_args, *args, **kw_args)

    return chained_fn
