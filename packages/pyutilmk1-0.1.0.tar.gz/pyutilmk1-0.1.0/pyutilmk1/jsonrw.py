import json
import pathlib
import os
from typing import Any, Callable, Literal
# pip3 install zstd


def write_file(
        py_var: Any,
        target_path: str,
        data_tranform_fn: Callable[[Any], str] | None = None,
        compress=False,
        algorithm: Literal["zlib", "zstd"] | None = "zlib",
        level=3
) -> str:

    string_to_write = None
    if (data_tranform_fn):
        string_to_write = data_tranform_fn(py_var)
    else:
        string_to_write = str(py_var)

    if (not compress):
        # json_buffer = bytes(json_string, 'utf-8')
        with open(target_path, 'w+') as file:
            file.write(string_to_write)

        return target_path

    if (compress and not algorithm):
        raise Exception(f"Invalid write file options -> when 'compress' is enabled a valid 'algorithm' must be defined was: {algorithm}")

    encoded_string = string_to_write.encode()
    if (algorithm == "zlib"):
        # Dynamic import on usage (or loaded from cache if already loaded before)
        import zlib
        bytes_to_write = zlib.compress(encoded_string, level)
        target_path += '.zlib'

    elif (algorithm == "zstd"):
        import zstd
        bytes_to_write: bytes = zstd.compress(encoded_string, level)
        target_path += '.zstd'

    with open(target_path, 'wb+') as file:
        file.write(bytes_to_write)

    return target_path


def write_as_json(
    py_var: Any,
    target_path: str,
    format=False,
    compress=False,
    algorithm: Literal["zlib", "zstd"] = "zlib",
    level=3
):
    if not target_path:
        return target_path

    indent = 0
    if (format):
        indent = 4

    json_string = json.dumps(py_var, indent=indent)

    string_to_write = json_string

    return write_file(
        string_to_write,
        target_path,
        compress=compress,
        algorithm=algorithm,
        level=level,
    )


def read_text_file(target_path):
    # if (not os.path.exists(target_path)):
    #    return None

    if (os.path.exists(target_path + '.zlib')):
        target_path = target_path + '.zlib'
    elif (os.path.exists(target_path + '.zstd')):
        target_path = target_path + '.zstd'
    elif (not os.path.exists(target_path)):
        return None

    with open(target_path, 'rb') as file:
        file_contents = file.read()

    if (len(file_contents) == 0):
        return ""

    path_suffix = pathlib.Path(target_path).suffix
    if (path_suffix == '.zlib'):
        import zlib
        file_contents = zlib.decompress(file_contents)
    elif (path_suffix == '.zstd'):
        import zstd
        file_contents = zstd.decompress(file_contents)

    file_string = file_contents.decode('utf-8')
    if not file_string:
        return ""

    return file_string


def read_json(target_path):
    decompressed_read_file: str | None = read_text_file(target_path)
    if (decompressed_read_file is None):
        return {}

    return json.loads(decompressed_read_file)
