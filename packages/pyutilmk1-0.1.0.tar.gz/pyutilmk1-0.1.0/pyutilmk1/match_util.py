import re
from pyutilmk1 import array_util


def is_filters_included(
    target: str,
    contain_filters: list[str | None] | str = [],
    regex_filters: list[str | None] | str = []
):
    if not target:
        return False

    contain_filters = array_util.arrayify_filter(contain_filters)
    regex_filters = array_util.arrayify_filter(regex_filters)

    for filter in contain_filters:
        if (filter not in target):
            return False

    for regex_filter in regex_filters:
        regex_match = re.match(regex_filter, target)

        if (not regex_match):
            return False
        if (not regex_match.group(0)):
            return False

    return True
