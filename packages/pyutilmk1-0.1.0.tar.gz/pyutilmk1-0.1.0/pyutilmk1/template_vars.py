import re
from typing import Any, Callable

from pyutilmk1.array_util import filter_by
from pyutilmk1.dict_util import get_key_from_dict


defaultVarStartToken = "\\$"
defaultVarEndToken = ""
defaultVarNameChars = "a-zA-Z-_\."
defaultTemplateVarRegex: re.Pattern = "$([a-zA-Z-_\.]+)"


def get_template_vars_regex(
    varStartToken: str = defaultVarStartToken,
    varNameCharacters: str = defaultVarNameChars,
    varEndToken: str = defaultVarEndToken
):
    return re.compile(f"{varStartToken}([{varNameCharacters}]+){varEndToken}")


def inflate_template_vars(
    content: str,
    variableValues: dict[str, Any],
    varStartToken: str = defaultVarStartToken,
    varNameCharacters: str = defaultVarNameChars,
    varEndToken: str = defaultVarEndToken,
    templateVarRegex: re.Pattern | None = None,
) -> str:

    if not templateVarRegex:
        templateVarRegex = get_template_vars_regex(varStartToken, varNameCharacters, varEndToken)

    variableMatches = re.finditer(templateVarRegex, content)

    for variableMatch in variableMatches:
        fullVar: str = variableMatch.group(0)
        varName: str = variableMatch.group(1)

        resolvedVarValue = ''

        variableReplaceValue: str | Callable = get_key_from_dict(variableValues, varName)

        if (variableReplaceValue):

            if (callable(variableReplaceValue)):
                resolvedVarValue = variableReplaceValue()
            else:
                resolvedVarValue = variableReplaceValue

        content = content.replace(fullVar, resolvedVarValue)

    return content


match_param_template_regex: re.Pattern = re.compile("\{\s*\}")  # noqa


def has_param_pattern(string: str) -> bool:
    if match_param_template_regex.search(string):
        return True
    return False


def filter_param_patterned(items: list[str]) -> list[str]:
    return filter_by(items, has_param_pattern)


def is_param_patterned_dict(item: dict) -> bool:
    for key in item:
        if has_param_pattern(item[key]):
            return True

    return False


def filter_dicts_have_param_patterned(items: list[dict]) -> list[dict]:
    return filter_by(items, is_param_patterned_dict)


def inflate_curly_in_dicts(items: list[dict], replace_value: str) -> list[dict]:
    for item in items:
        for key in item:
            if has_param_pattern(item[key]):
                item[key] = re.sub(
                    match_param_template_regex,
                    replace_value,
                    item[key]
                )
    return items
