import re
import requests


def is_url(path):
    if (path is None):
        return False

    if (path.startswith("https://") or path.startswith("http://")):
        return True
    return False


def page_exists(url):
    if (url is None):
        return False

    request = requests.get(url)
    if request.status_code == 200:
        return True
    return False


def get_url_contents_utf8(url):
    if (not is_url(url)):
        return None

    request = requests.get(url)
    return request.text


find_title_regex: re.Pattern = re.compile(r'<\s*title\s*>\s*(.+)</\s*title\s*>')


def fetch_url_title(url: str) -> str:
    headers = {'headers': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:51.0) Gecko/20100101 Firefox/128.0'}
    response = requests.get(url, headers=headers)
    response_text = response.text
    title_match = re.search(find_title_regex, response_text)
    if not title_match:
        return ''

    title_value_group = title_match.group(1)
    if title_value_group:
        return str(title_value_group)

    return ""
