# this is used in pyproject.toml and imported into __init__.py
__version__ = '3.1.1'

__all__ = ['__version__']
