# -*- coding: utf-8 -*-
"""
Project : PyvoA
Date :    april 2020 - december 2025
Authors : Olivier Dadoun, Julien Browaeys, Tristan Beau
Copyright ©pyvoa_fr
License: See joint LICENSE file
https://pyvoa.org/

Module : pyvoa.geopd_builder

About :
-------

Main class definitions for geopd_builder dataset access. Currently, we are only using the JHU CSSE data.
The parser class gives a simplier access through an already filled dict of data

"""

import pandas
import numpy as np
import pandas as pd
pd.options.mode.chained_assignment = None  # default='warn'
import datetime as dt

from pyvoa.tools import (
    kwargs_valuestesting,
    extract_dates,
    debug,
    verb,
    flat_list,
    getnonnegfunc,
    return_nonan_dates_pandas,
    dumppkl,
)
import pyvoa.geo as coge

import pyvoa.jsondb_parser as parser

import geopandas as gpd
from pyvoa.error import *
import os, time
import re
import pyvoa.geo as coge
from pyvoa.kwarg_options import InputOption
class GPDBuilder(object):
   """
   GPDBuilder class
   """
   def __init__(self, db_name):
        """
            Main pycoa.class:
            - call the get_parser
            - call the geo
            - call the display
        """
        verb("Init of geopd_builder.GPDBuilder()")
        self.db = db_name
        self.currentmetadata = parser.MetaInfo().getcurrentmetadata(db_name)
        self.currentdata = parser.DataParser(db_name)

        self.slocation = self.currentdata.get_locations()
        #self.geo = self.currentdata.get_geo()
        self.db_world = self.currentdata.get_world_boolean()
        self.codisp  = None
        self.code = self.currentmetadata['geoinfo']['iso3']
        self.granularity = self.currentmetadata['geoinfo']['granularity']
        self.namecountry = self.currentmetadata['geoinfo']['iso3']
        self._gi = coge.GeoInfo()
        try:
            if self.granularity == 'country':
                   self.geo = coge.GeoManager('name')
                   geopan = gpd.GeoDataFrame()#crs="EPSG:4326")
                   info = coge.GeoInfo()
                   alllocationsgeo = self.geo.get_GeoRegion().get_countries_from_region('world')
                   geopan['where'] = [self.geo.to_standard(c)[0] for c in alllocationsgeo]
                   geopan = info.add_field(field=['geometry'],input=geopan ,geofield='where')
                   geopan = gpd.GeoDataFrame(geopan, geometry=geopan.geometry, crs="EPSG:4326")
                   geopan = geopan[geopan['where'] != 'Antarctica']
                   where_kindgeo = geopan.dropna().reset_index(drop=True)
            else:
                   self.geo = coge.GeoCountry(self.code)
                   if self.granularity == 'region':
                        where_kindgeo = self.geo.get_region_list()[['code_region', 'name_region', 'geometry']]
                        where_kindgeo = where_kindgeo.rename(columns={'name_region': 'where'})
                        if self.code == 'PRT':
                             tmp = where_kindgeo.rename(columns={'name_region': 'where'})
                             tmp = tmp.loc[tmp.code_region=='PT.99']
                             self.boundary_metropole =tmp['geometry'].total_bounds
                        if self.code == 'FRA':
                             tmp = where_kindgeo.rename(columns={'name_region': 'where'})
                             tmp = tmp.loc[tmp.code_region=='999']
                             self.boundary_metropole =tmp['geometry'].total_bounds
                   elif self.granularity == 'subregion':
                        list_dep_metro = None
                        where_kindgeo = self.geo.get_subregion_list()[['code_subregion', 'name_subregion', 'geometry']]
                        where_kindgeo = where_kindgeo.rename(columns={'name_subregion': 'where'})
                   else:
                       raise PyvoaTypeError('What is the granularity of your  database ?')
        except:
            raise PyvoaTypeError('What data base are you looking for ?')
        self.where_geodescription = where_kindgeo

   def getwheregeometrydescription(self):
        return self.where_geodescription

   def gettypeofgeometry(self):
        return self.geo

   def get_available_keywords(self):
       '''
        return available from the jsondb_parser
       '''
       return self.currentdata.get_available_keywords()

   @staticmethod
   def factory(**kwargs):
       '''
        Return an instance to GPDBuilder and to Display methods
        This is recommended to avoid mismatch in labeled figures
       '''
       db_name = kwargs.get('db_name')
       reload = kwargs.get('reload', True)
       vis = kwargs.get('vis', None)

       f = db_name+'.pkl'
       if reload:
           datab = GPDBuilder(db_name)
           dumppkl(f,datab)

       datab.setvisu(db_name,datab.getwheregeometrydescription())
       return datab, datab.getvisu()

   def setvisu(self,db_name,wheregeometrydescription):
       ''' Set the Display '''
       import pyvoa.visualizer as output
       self.codisp = output.AllVisu(db_name, wheregeometrydescription)

   def getvisu(self):
       ''' Return the instance of Display initialized by factory'''
       return self.codisp

   def setgeo(self,geo):
       self.geo = geo

   def getgeo(self):
       return self.geo

   def get_parserdb(self):
       return self.currentdata

   def get_fulldb(self):
      return self.currentdata.get_maingeopandas()

   def get_available_GPDBuilder(self):
        '''
        Return all the available Covid19 GPDBuilder
        '''
        return self.GPDBuilder_name

   def subregions_deployed(self,listloc,typeloc='subregion'):
        exploded = []
        for i in listloc:
            if typeloc == 'subregion':
                if self.geo.is_region(i):
                    i = [self.geo.is_region(i)]
                    tmp = self.geo.get_subregions_from_list_of_region_names(i,output='name')
                elif self.geo.is_subregion(i):
                   tmp = i
                else:
                    raise PyvoaTypeError(i + ': not subregion nor region ... what is it ?')
            elif typeloc == 'region':
                tmp = self.geo.get_region_list()
                if i.isdigit():
                    tmp = list(tmp.loc[tmp.code_region==i]['name_region'])
                elif self.geo.is_region(i):
                    tmp = self.geo.get_regions_from_macroregion(name=i,output='name')
                    if self.currentmetadata['geoinfo']['iso3'] in ['USA, FRA, ESP, PRT']:
                        tmp = tmp[:-1]
                else:
                    if self.geo.is_subregion(i):
                        raise PyvoaTypeError(i+ ' is a subregion ... not compatible with a region DB granularity?')
                    else:
                        raise PyvoaTypeError(i + ': not subregion nor region ... what is it ?')
            else:
                raise PyvoaTypeError('Not subregion nor region requested, don\'t know what to do ?')
            if exploded:
                exploded.append(tmp)
            else:
                exploded=[tmp]
        return flat_list(exploded)

   def whereclustered(self,**kwargs):
        '''
        Handles the name and geometric behavior of the object
        Return a pandas after whereclustered
            - sum of the name location
            - sum all value or return mean value (depends on the variable considered)
            - sum all the geometry
        upper str comparision to be insensitive case
        '''
        input = kwargs.get('input')
        if 'geometry' not in list(input.columns):
            return input

        which = kwargs['which']
        where = kwargs['where']
        option=kwargs.get('option')
        dpop = InputOption().dictpop

        has_normalize = any(o.startswith("normalize:") for o in option)
        has_sumall = "sumall" in option

        if has_sumall and kwargs['typeofmap']=='dense':
            raise PyvoaError("dense + sumall not compatible ...")

        which = kwargs.get('which')
        newpd = pd.DataFrame()
        if not isinstance(where[0],list):
            where = [where]

        if has_sumall:
            for w in where:
                temp = pd.DataFrame()
                if not isinstance(w,list):
                    w=[w]

                if self.db_world:
                    self.geo.set_standard('name')
                    w_s = self.geo.to_standard(w,output='list',interpret_region=True)
                else:
                    w_s = self.subregions_deployed(w,self.granularity)

                temp = input.loc[input['where'].str.upper().isin([x.upper() for x in w_s])].reset_index(drop=True)
                if has_normalize:
                    for idx,i in enumerate(dpop.keys()):
                        if idx==0:
                            temptemp = self.normbypop(temp,which[0],i)
                        else:
                            temptemp = pd.merge(temptemp,self.normbypop(temp,which[0],i),how="outer")
                    temp = temptemp

                temp = gpd.GeoDataFrame(temp, geometry=temp.geometry, crs="EPSG:4326").reset_index(drop=True)
                wherejoined  = ',' .join(flat_list(w))
                code = temp.loc[temp.date==temp.date.max()]['code']
                codejoined  = ',' .join(code)
                if has_normalize:
                    if 'population_subregion' in list(temp.columns):
                        temp=temp.rename(columns={"population_subregion": "population"})
                    population = temp.loc[temp.date==temp.date.max()]['population']
                    populationsum = np.nansum(population)

                geometryjoined = temp.loc[temp.date == temp.date.max()]["geometry"].unary_union
                temp = temp.groupby(['date'])[which].sum().reset_index()

                temp['where'] = len(temp)*[wherejoined]
                temp['code'] = len(temp)*[codejoined]
                temp['geometry'] = len(temp)*[geometryjoined]
                if has_normalize:
                    temp['population'] = len(temp)*[populationsum]
                if newpd.empty:
                    newpd = temp
                else:
                    newpd = pd.concat([newpd,temp])

        else:
            where = flat_list(where)
            if self.db_world:
                where = self.geo.to_standard(where,output='list',interpret_region=True)
            else:
                where = self.subregions_deployed(where,self.granularity)

            newpd = input.loc[input['where'].str.upper().isin([x.upper() for x in where])]

        newpd = gpd.GeoDataFrame(newpd, geometry=newpd.geometry, crs='EPSG:4326').reset_index(drop=True)
        where_geometry_none = newpd[newpd['geometry'].isna()]['where'].unique()
        if where_geometry_none.size>0:
            PyvoaWarning('Those localisation have None geometry, remove them ...:'+str(where_geometry_none))
        newpd = newpd.dropna(subset=['geometry'])
        return newpd

   def get_stats(self,**kwargs):
       '''
            Return a fill kwargs after input arguments applied
            options:
             - test all arguments an their values
             - nonneg redistribute value in order to remove negative value
       '''
       defaultargs = InputOption().d_batchinput_args
       option = kwargs.get('option',defaultargs['option'][0])
       kwargs_valuestesting(option,defaultargs['option'],'option error ... ')
       output = kwargs['output']
       kwargs_valuestesting(output,defaultargs['output'],'output error ...')
       which = kwargs.get('which',[self.currentdata.get_available_keywords()[0]])
       if which == ['']:
          which = [self.currentdata.get_available_keywords()[0]]
          kwargs['which'] = which

       input = kwargs.get('input')
       what  = kwargs.get('what')
       when  = kwargs.get('when')
       where = kwargs.get('where')

       if input.empty:
            kwargs_valuestesting(which,self.currentdata.get_available_keywords(),'which error ...')
            input = self.currentdata.get_maingeopandas()
            anticolumns = [x for x in self.currentdata.get_available_keywords() if x not in which]
            input = input.loc[:,~input.columns.isin(anticolumns)]
       else:
           input = input.loc[input['where'].isin(where)]

       date_max_by_where = input.groupby('where')['date'].max()
       needs_reindex = date_max_by_where.nunique() > 1
       if needs_reindex:
            PyvoaWarning("Your data is irregular, date will be reindexed ! ")
            all_dates = input['date'].unique()
            input = (
                input.set_index('date')
                        .groupby('where')
                        .apply(lambda g: g.reindex(all_dates).ffill().bfill())
                    .reset_index('date').reset_index(drop=True)
            )

       if not pd.api.types.is_datetime64_any_dtype(input['date']):
           input['date'] = pd.to_datetime(input['date'], errors='coerce')

       when_beg_data, when_end_data = input.date.min(), input.date.max()
       when_beg_data, when_end_data = when_beg_data.date(), when_end_data.date()

       when_beg, when_end = dt.date(1,1,1), dt.date.today()

       if when:
           when_beg, when_end = extract_dates(when)
           if when_beg < when_beg_data:
                when_beg = when_beg_data
                PyvoaWarning("No available data before "+str(when_beg_data) + ' - ' + str(when_beg) + ' is considered')
           if when_end > when_end_data:
                when_end = when_end_data
                PyvoaWarning("No available data after "+str(when_end_data) + ' - ' + str(when_end) + ' is considered')
           if when_beg != when_end:
               input = input[(input.date >= pd.to_datetime(when_beg)) & (input.date <= pd.to_datetime(when_end))]
           kwargs['input'] = input
           when_beg_data,when_end_data = when_beg, when_end
       else:
            when_beg, when_end = input.date.min(), input.date.max()

       #kwargs['when'] = [str(when_beg_data)+':'+str(when_end_data)]
       kwargs['when']=[when_beg_data.strftime("%d/%m/%Y")+':'+when_end_data.strftime("%d/%m/%Y")]
       flatwhere = flat_list(where)

       bypopvalue = None
       datesunique = list(input.date.unique())
       ndates = len(datesunique)

       prefix = ['date', 'where']
       suffix = ['code','geometry']

       for w in which:
           option = kwargs.get('option',defaultargs['option'][0])

           input[w] = (
           input.groupby('where')[w]
                 .apply(lambda s: s.bfill().ffill())
                 .reset_index(level=0, drop=True)
                 .fillna(0)
                 )

           kwargs['input'] = input
           if kwargs['kwargsuser']['input'].empty:
               input = self.whereclustered(**kwargs)
           has_normalize = any(o.startswith("normalize:") for o in option)
           has_sumall = "sumall" in option

           if has_sumall and has_normalize:
                option.remove('sumall')
                normalize = [x for x in option if x.startswith('normalize:')]
                option = [x for x in option if not x.startswith('normalize:')]
                normalize = re.sub(r'normalize:', '', normalize[0])
                option.append('sumallandnormalize:'+normalize)

           concatpd = pd.DataFrame()
           basecolumns=list(input.columns)
           for o in option:
               temppd = input
               if o == 'nonneg':
                   if w.startswith('cur_idx_') or w.startswith('cur_tx_'):
                        print('The default option nonneg cannot be used with instantaneous data, such as : ' + w)
                   temppd = getnonnegfunc(temppd, w)
               elif o == 'smooth7':
                    temppd.loc[:,w] = temppd.groupby(['where'])[w].rolling(7,min_periods=7).mean().reset_index(level=0,drop=True)
                    inx7 = temppd.groupby('where').head(7).index
                    temppd.loc[inx7, w] = temppd[w].bfill()
               elif o == 'sumall':
                    if 'geometry' in list(temppd.columns):
                        if w.startswith('cur_idx_') or w.startswith('cur_tx_'):
                            temppd = temppd.groupby(prefix+suffix).mean().reset_index()
                        else:
                            temppd = temppd.groupby(prefix+suffix).sum(numeric_only=True).reset_index()
                    else:
                        temppd = temppd.groupby('date').agg(
                            where=('where', lambda x: ','.join(x)), **{w: (w, 'sum')}).reset_index()
               elif o.startswith('normalize:'):
                     temppd = self.normbypop(temppd , w ,o)
                     kwargs['input'] = temppd
                     temppd = self.whereclustered(**kwargs)
                     bypopvalue=o
               elif o.startswith('sumallandnormalize:'):
                    bypop = re.sub(r'sumalland', '', o)
                    dpop = InputOption().dictpop
                    temppd.loc[:,w+' '+bypop]=temppd[w]/temppd['population']*dpop[re.sub(r'normalize:', '', bypop)]
               if concatpd.empty:
                    concatpd = temppd
               else:
                    concatpd = pd.merge(concatpd, temppd,  how="right", on=basecolumns)

           if not concatpd.empty:
               input = concatpd

           windows = InputOption().windows
           for k,v in windows.items():
               input.loc[:,w+k]  = input.groupby('where')[w].diff(v)
               input.loc[:,w+k]  = input[w + k].bfill()
               if bypopvalue is not None:
                  input = self.normbypop(input, w+k ,bypopvalue)

       if when_beg == when_end:
          input = input[(input.date >= pd.to_datetime(when_beg)) & (input.date <= pd.to_datetime(when_end))]

       if 'geometry' in input.columns:
         input = gpd.GeoDataFrame(input, geometry=input.geometry, crs='EPSG:4326').reset_index(drop=True)
       if not isinstance(kwargs['which'],list):
           kwargs['which'] = [kwargs['which']]


       #input = input.sort_values(by=["date",which[0]],ascending=[True,False]).reset_index(drop=True)
       #input = input.sort_values(by=['where','date'])
       #input = input.reset_index(drop=True)
       if input.empty:
           raise PyvoaError('Data seems to be empty for :'+str(where))
       others = sorted([c for c in input.columns if c not in prefix + suffix])
       new_order = prefix + others + suffix
       if 'geometry' not in input.columns:
            new_order.remove('geometry')
       if 'code' not in input.columns:
           new_order.remove('code')
       kwargs['input'] = input[new_order].reset_index(drop=True)
       return kwargs

   def normbypop(self, pandy , val2norm ,bypop):
    """
        Return a pandas with a normalisation column add by population
        * can normalize by '100', '1k', '10k', '100k' or '1M' and the new which
    """
    dpop = InputOption().dictpop
    if pandy.empty:
        raise PyvoaError('normbypop problem, your pandas seems to be empty ....')
    value = re.sub(r'normalize:', '', bypop)
    clust = list(pandy['where'].unique())

    pop_field='population'

    uniquepandy = pandy.groupby('where').first().reset_index()
    if self.db_world == True:
        try:
            uniquepandy = self._gi.add_field(input = uniquepandy,field = 'population',overload=True)
        except:
            PyvoaError(self.db + ' has no information for what concern: '+pop_field)
    else:
        if not isinstance(self._gi,coge.GeoCountry):
            self._gi = None
        else:
            if self._gi.get_country() != self.geo.get_country():
                self._gi=None

        if self._gi == None :
            self._gi = self.geo
        pop_field='population_subregion'
        if self.granularity == 'region':
            regsubreg={i:self.geo.get_subregions_from_region(name=i) for i in clust}
            try:
                uniquepandy = self._gi.add_field(input=uniquepandy, field=pop_field, input_key='code',overload=True)
            except:
                PyvoaError(self.db + ' has no information for what concern: '+pop_field)
        elif self.granularity == 'subregion':
            try:
                uniquepandy = self._gi.add_field(input=uniquepandy, field=pop_field, input_key='code',overload=True)
            except:
                PyvoaError(self.db + ' has no information for what concern: '+pop_field)
        else:
            raise PyvoaKeyError('This is not region nor subregion what is it ?!')
    uniquepandy = uniquepandy[['where',pop_field]]
    if pop_field not in pandy.columns:
        pandy = pd.merge(pandy,uniquepandy,on='where',how='outer')
    if not isinstance(val2norm, list):
        val2norm=[val2norm]

    for i in val2norm:
        var = i+' '+bypop
        pandy.loc[:,i+' '+bypop]=pandy[i]/pandy[pop_field]*dpop[value]
    return pandy

   def saveoutput(self,**kwargs):
       '''
       saveoutput pycoa. pandas as an  output file selected by output argument
       'pandas': pycoa.pandas
       'saveformat': excel or csv (default excel)
       'savename': pycoa.ut (default)
       '''
       possibleformat=['excel','csv']
       saveformat = 'excel'
       savename = 'pycoa.ut'
       pandyori = ''
       if 'saveformat' in kwargs:
            saveformat = kwargs['saveformat']
       if saveformat not in possibleformat:
           raise PyvoaKeyError('Output option '+saveformat+' is not recognized.')
       if 'savename' in kwargs and kwargs['savename'] != '':
          savename = kwargs['savename']

       if not 'pandas' in kwargs:
          raise PyvoaKeyError('Absolute needed variable : the pandas desired ')
       else:
          pandyori = kwargs['pandas']
       pandy = pandyori
       pandy['date']=pandy['date'].apply(lambda x: x.strftime('%d/%m/%Y'))
       if saveformat == 'excel':
           pandy.to_excel(savename+'.xlsx',index=False, na_rep='NAN')
       elif saveformat == 'csv':
           pandy.to_csv(savename+'.csv', encoding='utf-8', index=False, float_format='%.4f',na_rep='NAN')

   ## https://www.kaggle.com/freealf/estimation-of-rt-from-cases
   def smooth_cases(self,cases):
        new_cases = cases

        smoothed = new_cases.rolling(7,
            win_type='gaussian',
            min_periods=1,
            center=True).mean(std=2).round()
            #center=False).mean(std=2).round()

        zeros = smoothed.index[smoothed.eq(0)]
        if len(zeros) == 0:
            idx_start = 0
        else:
            last_zero = zeros.max()
            idx_start = smoothed.index.get_loc(last_zero) + 1
        smoothed = smoothed.iloc[idx_start:]
        original = new_cases.loc[smoothed.index]

        return smoothed
   def get_posteriors(self,sr, window=7, min_periods=1):
        from scipy import stats as sps
        # We create an array for every possible value of Rt
        R_T_MAX = 12
        r_t_range = np.linspace(0, R_T_MAX, R_T_MAX*100+1)

        # Gamma is 1/serial interval
        # https://wwwnc.cdc.gov/eid/article/26/6/20-0357_article
        GAMMA = 1/7

        lam = sr[:-1].values * np.exp(GAMMA * (r_t_range[:, None] - 1))

        # Note: if you want to have a Uniform prior you can use the following line instead.
        # I chose the gamma distribution because of our prior knowledge of the likely value
        # of R_t.

        # prior0 = np.full(len(r_t_range), np.log(1/len(r_t_range)))
        prior0 = np.log(sps.gamma(a=3).pdf(r_t_range) + 1e-14)

        likelihoods = pd.DataFrame(
            # Short-hand way of concatenating the prior and likelihoods
            data = np.c_[prior0, sps.poisson.logpmf(sr[1:].values, lam)],
            index = r_t_range,
            columns = sr.index)

        # Perform a rolling sum of log likelihoods. This is the equivalent
        # of multiplying the original distributions. Exponentiate to move
        # out of log.
        posteriors = likelihoods.rolling(window,
                                     axis=1,
                                     min_periods=min_periods).sum()
        posteriors = np.exp(posteriors)

        # Normalize to 1.0
        posteriors = posteriors.div(posteriors.sum(axis=0), axis=1)

        return posteriors
