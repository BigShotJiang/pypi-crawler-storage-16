#include "volgrid.hpp"
#include <nanobind/nanobind.h>
#include <nanobind/ndarray.h>
#include <string>
#include <type_traits>

namespace nb = nanobind;

// Templated volume calculation function
template <typename T>
double calc_vol(nb::ndarray<T, nb::c_contig, nb::device::cpu> coords,
                nb::ndarray<T, nb::c_contig, nb::device::cpu> radii,
                T grid_spacing) {
  size_t n_spheres = static_cast<size_t>(coords.shape(0));
  const T *ptr_coords = coords.data();
  const T *ptr_radii = radii.data();

  T volume;
  {
    nb::gil_scoped_release release;
    volume =
        volume_of_spheres<T>(ptr_coords, ptr_radii, n_spheres, grid_spacing);
  }
  return static_cast<double>(volume);
}

// Helper to bind the calc_vol function with dynamic docstrings
template <typename T>
void bind_calc_vol(nb::module_ &m, const char *name, const char *type_str) {
  std::string doc =
      "Calculate the volume occupied by spheres using a grid-based approach (" +
      std::string(type_str) +
      " backend).\n\n"
      "Args:\n"
      "    coords: N x 3 array of sphere center coordinates (" +
      std::string(type_str) +
      ", C-contiguous)\n"
      "    radii: 1D array of sphere radii (" +
      std::string(type_str) +
      ", length N, C-contiguous)\n"
      "    grid_spacing: Grid spacing for the volume calculation (" +
      std::string(type_str) +
      ")\n\n"
      "Returns:\n"
      "    float: Estimated volume occupied by the spheres\n\n"
      "Notes:\n"
      "    Arrays must be C-contiguous and " +
      std::string(type_str) + ". GIL is released during computation.";

  T default_spacing = 0.1;
  if constexpr (std::is_same<T, float>::value) {
    default_spacing = 0.1f;
  }

  m.def(name, &calc_vol<T>, doc.c_str(), nb::arg("coords").noconvert(),
        nb::arg("radii").noconvert(),
        nb::arg("grid_spacing") = default_spacing);
}

NB_MODULE(_core, m) {
  m.doc() = "C++ extension for volume calculation using a grid-based approach";

  bind_calc_vol<double>(m, "_volume_from_spheres_float64", "float64");
  bind_calc_vol<float>(m, "_volume_from_spheres_float32", "float32");
}
