from __future__ import annotations

from typing import cast

from pywa.types.others import InteractiveType
from pywa.types.sent_update import *  # noqa MUST BE IMPORTED FIRST
from pywa.types.sent_update import (
    SentMessage as _SentMessage,
    SentTemplate as _SentTemplate,
    SentMediaMessage as _SentMediaMessage,
    SentVoiceMessage as _SentVoiceMessage,
    SentLocationRequest as _SentLocationRequest,
    SentReaction as _SentReaction,
    InitiatedCall as _InitiatedCall,
    ignore_updates_canceler,
    failed_canceler,
    new_update_canceler,
)
from pywa_async.types import (
    Message,
    CallbackButton,
    CallbackSelection,
    MessageStatus,
    FlowCompletion,
    CallConnect,
    CallPermissionUpdate,
)
from .calls import _CallShortcutsAsync
from .media import Media

from .. import filters as pywa_filters

__all__ = [
    "SentMessage",
    "SentMediaMessage",
    "SentVoiceMessage",
    "SentLocationRequest",
    "SentReaction",
    "SentTemplate",
    "SentTemplateStatus",
    "InitiatedCall",
]

from pywa_async.types.base_update import _ClientShortcutsAsync


class SentMessage(_ClientShortcutsAsync, _SentMessage):
    """
    Represents a message that was sent to WhatsApp user.

    Attributes:
        id: The ID of the message.
        to_user: The user the message was sent to.
        from_phone_id: The WhatsApp ID of the sender who sent the message.
        input: The input (phone number) of the recipient.
    """

    async def wait_for_reply(
        self,
        *,
        force_quote: bool = False,
        filters: pywa_filters.Filter = None,
        cancelers: pywa_filters.Filter = None,
        ignore_updates: bool = True,
        timeout: float | None = None,
    ) -> Message:
        """
        Wait for a message reply to the sent message.

        - Shortcut for :meth:`~pywa.client.WhatsApp.listen` with ``filters=filters.message``.

        Example:

            .. code-block:: python

                @wa.on_message(filters.command("start"))
                def start(w: WhatsApp, m: Message):
                    user_id: str = m.reply(
                        text=f"Hi {m.from_user.name}! Please enter your ID",
                        buttons=[Button(title="Cancel", callback_data="cancel")],
                    ).wait_for_reply(
                        filters=filters.text & filters.new(lambda _, m: m.text.isdigit()),
                        cancelers=filters.callback_button & filters.matches("cancel"),
                    ).text
                    ...
        Args:
            force_quote: Whether to force the reply to quote the sent message.
            filters: The filters to apply to the reply.
            cancelers: The filters to cancel the listening.
            ignore_updates: Whether to ignore user updates that do not pass the filters.
            timeout: The time to wait for a reply.

        Returns:
            The reply message.

        Raises:
            ListenerTimeout: If the listener timed out.
            ListenerCanceled: If the listener was canceled by a filter.
            ListenerStopped: If the listener was stopped manually.
        """
        if force_quote:
            reply_filter = pywa_filters.replays_to(self.id)
            filters = (reply_filter & filters) if filters else reply_filter
        filters = (pywa_filters.message & filters) if filters else pywa_filters.message
        if ignore_updates:
            cancelers = (
                (cancelers | ignore_updates_canceler)
                if cancelers
                else ignore_updates_canceler
            )

        return cast(
            Message,
            await self._client.listen(
                to=self.listener_identifier,
                filters=filters,
                cancelers=cancelers,
                timeout=timeout,
            ),
        )

    async def wait_until_read(
        self,
        *,
        cancel_on_new_update: bool = False,
        cancel_if_failed: bool = True,
        cancelers: pywa_filters.Filter = None,
        timeout: float | None = None,
    ) -> MessageStatus:
        """
        Wait for the message to be read by the recipient.

        - Shortcut for :meth:`~pywa.client.WhatsApp.listen` with ``filters=filters.message_status & filters.read``.

        **Note:** This method will not work if the recipient has disabled read receipts.
        make sure to use ``cancel_on_new_update=True`` to cancel the listening if the message is probably read, or use a timeout / cancelers.

        Example:

            .. code-block:: python

                @wa.on_message(filters.command("start"))
                def start(w: WhatsApp, m: Message):
                    r = m.reply("This message waits for you to read it")
                    try:
                        r.wait_until_read(cancel_on_new_update=True)
                    except ListenerCanceled as e:
                        print(e.update) # The update that canceled the listener
                        r.reply("You turned off read receipts")
                    r.reply("You read this message", quote=True)

        Args:
            cancel_on_new_update: Whether to cancel when another message/button click arrives (which may indicate the previous message was read).
            cancel_if_failed: Whether to cancel the listener if the message failed to send.
            cancelers: The filters to cancel the listening.
            timeout: The time to wait for the message to be read.

        Returns:
            The message status.

        Raises:
            ListenerTimeout: If the listener timed out.
            ListenerCanceled: If the listener was canceled by a filter.
            ListenerStopped: If the listener was stopped manually.
        """
        if cancel_if_failed:
            cancelers = (cancelers | failed_canceler) if cancelers else failed_canceler
        if cancel_on_new_update:
            cancelers = (
                (cancelers | new_update_canceler) if cancelers else new_update_canceler
            )
        return cast(
            MessageStatus,
            await self._client.listen(
                to=self.listener_identifier,
                filters=pywa_filters.update_id(self.id) & pywa_filters.read,
                cancelers=cancelers,
                timeout=timeout,
            ),
        )

    async def wait_until_delivered(
        self,
        *,
        cancel_if_failed: bool = True,
        cancelers: pywa_filters.Filter = None,
        timeout: float | None = None,
    ) -> MessageStatus:
        """
        Wait for the message to be delivered to the recipient.

        Example:

            .. code-block:: python

                @wa.on_message(filters.command("start"))
                def start(w: WhatsApp, m: Message):
                    r = m.reply("This message waits for you to receive it")
                    r.wait_until_delivered()
                    r.reply("You received the message", quote=True)

        Args:
            cancel_if_failed: Whether to cancel the listener if the message failed to send.
            cancelers: The filters to cancel the listening.
            timeout: The time to wait for the message to be delivered.

        Returns:
            The message status.

        Raises:
            ListenerTimeout: If the listener timed out.
            ListenerCanceled: If the listener was canceled by a filter.
            ListenerStopped: If the listener was stopped manually.
        """
        if cancel_if_failed:
            cancelers = (cancelers | failed_canceler) if cancelers else failed_canceler
        return cast(
            MessageStatus,
            await self._client.listen(
                to=self.listener_identifier,
                filters=pywa_filters.update_id(self.id)
                & (pywa_filters.read | pywa_filters.delivered),
                cancelers=cancelers,
                timeout=timeout,
            ),
        )

    async def wait_until_failed(
        self,
        *,
        cancel_if_delivered: bool = True,
        filters: pywa_filters.Filter = None,
        cancelers: pywa_filters.Filter = None,
        timeout: float | None = None,
    ) -> MessageStatus:
        """
        Wait for the message to fail.

        Example:

            .. code-block:: python

                m = wa.send_message(
                    to="123456",
                    text="This message will fail",
                )
                try:
                    failed = m.wait_for_failed(
                        filters=filters.failed_with(errors.ReEngagementMessage),  # message was send after 24 hours
                        cancel_if_delivered=True, # defaults to True, so the listener will be canceled if the message was delivered
                        timeout=5,
                    )
                    failed.reply_template(...)
                except ListenerCanceled:
                    print("The message was delivered successfully, so the listener was canceled.")
                except ListenerTimeout:
                    pass

        Args:
            filters: The filters to apply to the failed message.
            cancel_if_delivered: Whether to cancel the listener if the message was delivered.
            cancelers: The filters to cancel the listening.
            timeout: The time to wait for the message to fail.

        Returns:
            The message status indicating the failure.

        Raises:
            ListenerTimeout: If the listener timed out.
            ListenerCanceled: If the listener was canceled by a filter.
            ListenerStopped: If the listener was stopped manually.
        """
        if cancel_if_delivered:
            cancelers = (
                (cancelers | pywa_filters.delivered)
                if cancelers
                else pywa_filters.delivered
            )
        return cast(
            MessageStatus,
            await self._client.listen(
                to=self.listener_identifier,
                filters=pywa_filters.message_status
                & pywa_filters.failed
                & (filters or pywa_filters.true),
                cancelers=cancelers,
                timeout=timeout,
            ),
        )

    async def wait_for_click(
        self,
        *,
        filters: pywa_filters.Filter = None,
        cancelers: pywa_filters.Filter = None,
        ignore_updates: bool = True,
        timeout: float | None = None,
    ) -> CallbackButton:
        """
        Wait for a button click.

        Example:

            .. code-block:: python

                @wa.on_message(filters.command("start"))
                def start(w: WhatsApp, m: Message):
                    r = m.reply(
                        text="Click a button",
                        buttons=[
                            Button(title="Option 1", callback_data="option1"),
                            Button(title="Option 2", callback_data="option2"),
                        ],
                    )
                    option = r.wait_for_click()
                    r.reply(f"You clicked: {option.title}", quote=True)

        Args:
            filters: The filters to apply to the button click.
            cancelers: The filters to cancel the listening.
            ignore_updates: Whether to ignore user updates that do not pass the filters.
            timeout: The time to wait for the button click.

        Returns:
            The clicked button.

        Raises:
            ListenerTimeout: If the listener timed out.
            ListenerCanceled: If the listener was canceled by a filter.
            ListenerStopped: If the listener was stopped manually.
        """
        if self._interactive_type != InteractiveType.BUTTON:
            raise ValueError(
                "`wait_for_click` can only be used with messages that have button interactions."
            )
        if ignore_updates:
            cancelers = (
                (cancelers | ignore_updates_canceler)
                if cancelers
                else ignore_updates_canceler
            )
        return cast(
            CallbackButton,
            await self._client.listen(
                to=self.listener_identifier,
                filters=pywa_filters.callback_button
                & (pywa_filters.replays_to(self.id) & (filters or pywa_filters.true)),
                cancelers=cancelers,
                timeout=timeout,
            ),
        )

    async def wait_for_selection(
        self,
        *,
        filters: pywa_filters.Filter = None,
        cancelers: pywa_filters.Filter = None,
        ignore_updates: bool = True,
        timeout: float | None = None,
    ) -> CallbackSelection:
        """
        Wait for a callback selection.

        Args:
            filters: The filters to apply to the selection.
            cancelers: The filters to cancel the listening.
            ignore_updates: Whether to ignore user updates that do not pass the filters.
            timeout: The time to wait for the selection.

        Returns:
            The callback selection.

        Raises:
            ListenerTimeout: If the listener timed out.
            ListenerCanceled: If the listener was canceled by a filter.
            ListenerStopped: If the listener was stopped manually.
        """
        if self._interactive_type != InteractiveType.LIST:
            raise ValueError(
                "`wait_for_selection` can only be used with messages that have selection list interactions."
            )
        if ignore_updates:
            cancelers = (
                (cancelers | ignore_updates_canceler)
                if cancelers
                else ignore_updates_canceler
            )
        return cast(
            CallbackSelection,
            await self._client.listen(
                to=self.listener_identifier,
                filters=pywa_filters.callback_selection
                & (pywa_filters.replays_to(self.id) & (filters or pywa_filters.true)),
                cancelers=cancelers,
                timeout=timeout,
            ),
        )

    async def wait_for_completion(
        self,
        *,
        filters: pywa_filters.Filter = None,
        cancelers: pywa_filters.Filter = None,
        ignore_updates: bool = True,
        timeout: float | None = None,
    ) -> FlowCompletion:
        """
        Wait for a flow completion.

        Example:

            .. code-block:: python

                @wa.on_message(filters.command("start"))
                def start(w: WhatsApp, m: Message):
                    flow_completion = m.reply(
                        text="Answer the questions",
                        buttons=FlowButton(flow_token=..., ...),
                    ).wait_for_completion()

        Args:
            filters: The filters to apply to the completion.
            cancelers: The filters to cancel the listening.
            ignore_updates: Whether to ignore user updates that do not pass the filters.
            timeout: The time to wait for the completion.

        Returns:
            The flow completion.

        Raises:
            ListenerTimeout: If the listener timed out.
            ListenerCanceled: If the listener was canceled by a filter.
            ListenerStopped: If the listener was stopped manually.
        """
        if self._interactive_type != InteractiveType.FLOW:
            raise ValueError(
                "`wait_for_completion` can only be used with messages that have flow interactions."
            )
        if ignore_updates:
            cancelers = (
                (cancelers | ignore_updates_canceler)
                if cancelers
                else ignore_updates_canceler
            )
        return cast(
            FlowCompletion,
            await self._client.listen(
                to=self.listener_identifier,
                filters=pywa_filters.flow_completion
                & (pywa_filters.replays_to(self.id) & (filters or pywa_filters.true)),
                cancelers=cancelers,
                timeout=timeout,
            ),
        )

    async def wait_for_call_permission(
        self,
        *,
        filters: pywa_filters.Filter = None,
        cancelers: pywa_filters.Filter = None,
        ignore_updates: bool = True,
        timeout: float | None = None,
    ) -> CallPermissionUpdate:
        """
        Wait for a call permission update.


        Example:

            .. code-block:: python

                @wa.on_message(filters.command("start"))
                def start(w: WhatsApp, m: Message):
                    r = m.reply(
                        text="Do you allow calls?",
                        buttons=types.CallPermissionRequestButton(),
                    )
                    call_permission = r.wait_for_call_permission()
                    if call_permission:
                        r.reply("You allowed calls", quote=True)
                    else:
                        r.reply("You denied calls", quote=True)

        Args:
            filters: The filters to apply to the call permission update.
            cancelers: The filters to cancel the listening.
            ignore_updates: Whether to ignore user updates that do not pass the filters.
            timeout: The time to wait for the call permission update.

        Returns:
            The call permission update.

        Raises:
            ListenerTimeout: If the listener timed out.
            ListenerCanceled: If the listener was canceled by a filter.
            ListenerStopped: If the listener was stopped manually.
        """
        if self._interactive_type != InteractiveType.CALL_PERMISSION_REQUEST:
            raise ValueError(
                "`wait_for_call_permission` can only be used with messages that have call permission request interactions."
            )
        if ignore_updates:
            cancelers = (
                (cancelers | ignore_updates_canceler)
                if cancelers
                else ignore_updates_canceler
            )
        return cast(
            CallPermissionUpdate,
            await self._client.listen(
                to=self.listener_identifier,
                filters=pywa_filters.call_permission_update
                & (pywa_filters.replays_to(self.id) & (filters or pywa_filters.true)),
                cancelers=cancelers,
                timeout=timeout,
            ),
        )

    async def wait_for_incoming_voice_call(
        self,
        *,
        filters: pywa_filters.Filter = None,
        cancelers: pywa_filters.Filter = None,
        ignore_updates: bool = True,
        timeout: float | None = None,
    ) -> CallConnect:
        """
        Wait for an incoming call in response to a voice call button.

        Example:

            .. code-block:: python

                @wa.on_message(filters.command("start"))
                def start(w: WhatsApp, m: Message):
                    r = m.reply(
                        text="Click the button to call me",
                        buttons=types.VoiceCallButton(),
                    )
                    call_connect = r.wait_for_incoming_voice_call()
                    r.reply("You called me!", quote=True)

        Args:
            filters: The filters to apply to the incoming call.
            cancelers: The filters to cancel the listening.
            ignore_updates: Whether to ignore user updates that do not pass the filters.
            timeout: The time to wait for the incoming call.

        Returns:
            The call connect update.

        Raises:
            ListenerTimeout: If the listener timed out.
            ListenerCanceled: If the listener was canceled by a filter.
            ListenerStopped: If the listener was stopped manually.
        """
        if self._interactive_type != InteractiveType.VOICE_CALL:
            raise ValueError(
                "`wait_for_incoming_call` can only be used with messages that have voice call button interactions."
            )
        if ignore_updates:
            cancelers = (
                (cancelers | ignore_updates_canceler)
                if cancelers
                else ignore_updates_canceler
            )
        return cast(
            CallConnect,
            await self._client.listen(
                to=self.listener_identifier,
                filters=pywa_filters.call_connect
                & pywa_filters.incoming_call
                & (filters or pywa_filters.true),
                cancelers=cancelers,
                timeout=timeout,
            ),
        )


class SentMediaMessage(SentMessage, _SentMediaMessage):
    """
    Represents a media message that was sent to WhatsApp user.

    Attributes:
        id: The ID of the message.
        to_user: The user the message was sent to.
        from_phone_id: The WhatsApp ID of the sender who sent the message.
        input: The input (phone number) of the recipient.
        uploaded_media: The media that was uploaded and sent in the message (only available if the media was not Media ID or URL).
    """

    uploaded_media: Media | None = None


class SentVoiceMessage(SentMediaMessage, _SentVoiceMessage):
    """
    Represents a voice message that was sent to WhatsApp user.

    Attributes:
        id: The ID of the message.
        to_user: The user the message was sent to.
        from_phone_id: The WhatsApp ID of the sender who sent the message.
        input: The input (phone number) of the recipient.
    """

    async def wait_until_played(
        self,
        *,
        filters: pywa_filters.Filter = None,
        cancelers: pywa_filters.Filter = None,
        timeout: float | None = None,
    ) -> MessageStatus:
        """
        Wait for the voice message to be played by the recipient.

        Example:

            .. code-block:: python

                @wa.on_message(filters.command("start"))
                def start(w: WhatsApp, m: Message):
                    r = m.reply_voice(
                        voice_url="https://example.com/voice.mp3",
                    )
                    r.wait_until_played()
                    r.reply("You played the voice message", quote=True)

        Args:
            filters: The filters to apply to the played status.
            cancelers: The filters to cancel the listening.
            timeout: The time to wait for the voice message to be played.

        Returns:
            The message status.

        Raises:
            ListenerTimeout: If the listener timed out.
            ListenerCanceled: If the listener was canceled by a filter.
            ListenerStopped: If the listener was stopped manually.
        """
        return cast(
            MessageStatus,
            await self._client.listen(
                to=self.listener_identifier,
                filters=pywa_filters.update_id(self.id)
                & pywa_filters.played
                & (filters or pywa_filters.true),
                cancelers=cancelers,
                timeout=timeout,
            ),
        )


class SentLocationRequest(SentMessage, _SentLocationRequest):
    """
    Represents a location request message that was sent to WhatsApp user.

    Attributes:
        id: The ID of the message.
        to_user: The user the message was sent to.
        from_phone_id: The WhatsApp ID of the sender who sent the message.
        input: The input (phone number) of the recipient.
    """

    async def wait_for_location(
        self,
        *,
        force_current_location: bool = True,
        filters: pywa_filters.Filter = None,
        cancelers: pywa_filters.Filter = None,
        ignore_updates: bool = True,
        timeout: float | None = None,
    ) -> Message:
        """
        Wait for a location message in response to the location request.

        Args:
            force_current_location: Whether to only accept current location messages.
            filters: The filters to apply to the location message.
            cancelers: The filters to cancel the listening.
            ignore_updates: Whether to ignore user updates that do not pass the filters.
            timeout: The time to wait for the location message.

        Returns:
            The location message.

        Raises:
            ListenerTimeout: If the listener timed out.
            ListenerCanceled: If the listener was canceled by a filter.
            ListenerStopped: If the listener was stopped manually.
        """
        return await self.wait_for_reply(
            filters=(
                (
                    pywa_filters.current_location
                    if force_current_location
                    else pywa_filters.location
                )
                & (filters or pywa_filters.true)
            ),
            cancelers=cancelers,
            ignore_updates=ignore_updates,
            timeout=timeout,
        )


class SentReaction(SentMessage, _SentReaction):
    """
    Represents a reaction message that was sent to WhatsApp user.

    Attributes:
        id: The ID of the reaction.
        message_id: The ID of the message that was reacted/unreacted to.
        to_user: The user the message was sent to.
        from_phone_id: The WhatsApp ID of the sender who sent the message.
        input: The input (phone number) of the recipient.
    """


class SentTemplate(SentMessage, _SentTemplate):
    """
    Represents a template message that was sent to WhatsApp user.

    Attributes:
        id: The ID of the message.
        to_user: The user the message was sent to.
        from_phone_id: The WhatsApp ID of the sender who sent the message.
        status: The status of the sent template.
        input: The input (phone number) of the recipient.
    """


class InitiatedCall(_CallShortcutsAsync, _ClientShortcutsAsync, _InitiatedCall):
    """
    Represents an outgoing call initiated by the business.

    Attributes:
        id: The call ID.
        to_user: The user to whom the call was made.
        from_phone_id: The WhatsApp ID of the business phone number that initiated the call.
        success: Whether the call was successfully initiated.
    """
