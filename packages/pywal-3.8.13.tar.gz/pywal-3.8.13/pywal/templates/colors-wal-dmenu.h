static const char *colors[SchemeLast][2] = {{
	/*     fg         bg       */
	[SchemeNorm] = {{ "{color15}", "{color0}" }},
	[SchemeSel] = {{ "{color15}", "{color1}" }},
	[SchemeOut] = {{ "{color15}", "{color14}" }},
}};
