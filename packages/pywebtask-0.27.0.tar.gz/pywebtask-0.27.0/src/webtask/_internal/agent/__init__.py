"""Internal agent module - task execution, roles, and tools."""

# No public exports - everything here is internal implementation
