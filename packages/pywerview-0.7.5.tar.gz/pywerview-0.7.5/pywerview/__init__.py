import logging
logging.getLogger().setLevel(100)

