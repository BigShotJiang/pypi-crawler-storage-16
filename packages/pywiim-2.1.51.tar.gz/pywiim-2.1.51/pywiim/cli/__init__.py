"""Command-line tools for pywiim.

This package contains CLI tools for discovering, monitoring, testing, and
diagnosing WiiM/LinkPlay devices.
"""
