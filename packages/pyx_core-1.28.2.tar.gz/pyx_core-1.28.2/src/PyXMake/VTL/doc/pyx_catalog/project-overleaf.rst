------------------------------------------
Build a LateX documentation using Overleaf
------------------------------------------

.. literalinclude:: ../../../templates/project-overleaf/template.yml
   :language: yaml