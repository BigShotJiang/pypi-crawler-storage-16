---------------------------
Publish a project to ZENODO
---------------------------

.. literalinclude:: ../../../templates/project-zenodo/template.yml
   :language: yaml