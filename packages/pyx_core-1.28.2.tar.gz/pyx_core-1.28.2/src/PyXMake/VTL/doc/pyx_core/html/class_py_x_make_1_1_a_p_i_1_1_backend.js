var class_py_x_make_1_1_a_p_i_1_1_backend =
[
    [ "__init__", "class_py_x_make_1_1_a_p_i_1_1_backend.html#a8e31829940658432ea7d06aba6c9e9da", null ]
];