var class_py_x_make_1_1_a_p_i_1_1_frontend =
[
    [ "__init__", "class_py_x_make_1_1_a_p_i_1_1_frontend.html#a8e984d8d53b087596419d3251e729a28", null ]
];