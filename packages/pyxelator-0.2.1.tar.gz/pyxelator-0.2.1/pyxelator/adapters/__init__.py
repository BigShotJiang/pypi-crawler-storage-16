"""
Adapters for different automation frameworks.

This package contains adapters for:
- Selenium WebDriver (web automation)
- Playwright (web automation)
- Appium (mobile/desktop automation) - Coming soon!
"""

from .selenium import find, locate, click, fill, exists
from .playwright import find_pw, locate_pw, click_pw, fill_pw, exists_pw

__all__ = [
    # Selenium adapter
    'find', 'locate', 'click', 'fill', 'exists',
    # Playwright adapter
    'find_pw', 'locate_pw', 'click_pw', 'fill_pw', 'exists_pw',
]
