"""
Setup configuration for pyxelator
"""
from setuptools import setup, find_packages
from pathlib import Path

# Read the contents of README file
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding='utf-8')

setup(
    name='pyxelator',
    version='0.2.1',
    author='Aria Uno Suseno',
    author_email='contact@idejongkok.com',
    description='Image-based web automation for Selenium & Playwright - locate elements by screenshots',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/idejongkok/pyxelator',
    packages=find_packages(),
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Testing',
        'Topic :: Software Development :: Quality Assurance',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.10',
    install_requires=[
        'opencv-python>=4.5.0',
        'numpy>=1.19.0',
    ],
    extras_require={
        'selenium': ['selenium>=4.0.0'],
        'playwright': ['playwright>=1.20.0'],
        'dev': [
            'pytest>=7.0.0',
            'selenium>=4.0.0',
            'playwright>=1.20.0',
        ],
    },
    keywords='selenium playwright automation testing image-recognition opencv visual-testing',
    project_urls={
        'Bug Reports': 'https://github.com/idejongkok/pyxelator/issues',
        'Source': 'https://github.com/idejongkok/pyxelator',
        'Instagram': 'https://instagram.com/idejongkok',
    },
)
