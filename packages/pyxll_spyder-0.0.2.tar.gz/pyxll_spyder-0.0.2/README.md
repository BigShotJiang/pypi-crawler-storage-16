# PyXLL-Jupyter

Integration for Spyder IDE and Microsoft Excel.

## Requirements

- PyXLL >= 5.1.0
- spyder-kernels >= 3.0.0

## Installation

To install this package use:

    pip install pyxll-spyder

Once installed a "Start Spyder Kernel" button will be added to the PyXLL ribbon tab in Excel, so
long as you have PyXLL 5 or above already installed.

Click the button to start the Spyder kernel in Excel. A message box will be shown with the file
name of the Spyder kernel, which is copied to the clipboard ready to paste in the next step.

The Spyder kernel runs inside the Excel process using PyXLL and can be connected to from Spyder
using the menu item "Consoles -> Connect to Existing Kernel...". Paste the kernel file name
copied in the previous step here.

Once connected, the Spyder can execute code in Excel. The usual PyXLL functions and decorators
can be used which can be used to add new Excel functions and macros, as well as use the Excel
Object Model API to interact with Excel.
