import webbrowser

def online(*args, **kwargs):
    webbrowser.open("https://pyxora.github.io/pyxora-website/docs")
