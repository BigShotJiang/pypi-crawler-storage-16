"""
Pyxora Editor Module
Provides an integrated development environment for Pyxora projects. 
"""
from .app import run_editor

__all__ = ['run_editor']