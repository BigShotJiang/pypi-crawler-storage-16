__author__    = "Arthur Vigan, Mamadou N'Diaye"
__copyright__ = "Copyright (C) 2017-2025 Arthur Vigan, Mamadou N'Diaye"
__license__   = 'MIT'
__version__   = '1.4'

# direct access to sensor object
from .zelda import Sensor
