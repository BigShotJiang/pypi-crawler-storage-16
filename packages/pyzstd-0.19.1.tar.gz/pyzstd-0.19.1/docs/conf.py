project = "pyzstd module"
author = "Ma Lin and contributors"
copyright = "2020-present, Ma Lin and contributors"
language = "en"

master_doc = "index"
pygments_style = "sphinx"
extensions = ["myst_parser", "sphinx_rtd_theme"]
html_theme = "sphinx_rtd_theme"
