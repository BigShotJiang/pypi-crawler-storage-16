grabbed the DECam_[grizy].res filter data from
https://noirlab.edu/science/sites/default/files/media/archives/documents/scidoc0434.txt

parent page:
https://noirlab.edu/science/programs/ctio/filters/Dark-Energy-Camera
