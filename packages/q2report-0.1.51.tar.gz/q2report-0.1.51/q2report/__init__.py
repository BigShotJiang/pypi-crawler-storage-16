from q2report.version import __version__
from q2report.q2report import Q2Report
