class WwEngineCore:
    def __init__(self):
        print("core_engine")

    def render(self):
        pass
