# Qase Python Commons

## Description

This package contains reporters for Qase TestOps and Qase Report that are used in following projects:

- [qase-pytest](https://github.com/qase-tms/qase-python/tree/main/qase-pytest)
- [qase-robotframework](https://github.com/qase-tms/qase-python/tree/main/qase-robotframework)
- [qase-behave](https://github.com/qase-tms/qase-python/tree/main/qase-behave)
- [qase-tavern](https://github.com/qase-tms/qase-python/tree/main/qase-tavern)

## How to install

`pip install qase-python-commons`
