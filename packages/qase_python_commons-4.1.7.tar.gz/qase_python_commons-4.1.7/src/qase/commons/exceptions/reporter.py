class ReporterException(Exception):
    pass
