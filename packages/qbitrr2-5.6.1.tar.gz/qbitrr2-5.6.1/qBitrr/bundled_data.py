version = "5.6.1"
git_hash = "db497bc6"
license_text = (
    "Licence can be found on:\n\nhttps://github.com/Feramance/qBitrr/blob/master/LICENSE"
)
patched_version = f"{version}-{git_hash}"
tagged_version = f"{version}"
