version = "5.6.2"
git_hash = "e39e0d1e"
license_text = (
    "Licence can be found on:\n\nhttps://github.com/Feramance/qBitrr/blob/master/LICENSE"
)
patched_version = f"{version}-{git_hash}"
tagged_version = f"{version}"
