"""Version information for qbt-rules"""

__version__ = "0.3.2"
__author__ = "qbt-rules"
__description__ = "A powerful Python-based rules engine for qBittorrent automation"
