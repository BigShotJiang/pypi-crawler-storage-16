"""
Deprecated Module for backwards compatibility
"""

from ._AimTTi_PL_P import AimTTi, AimTTiChannel, NotKnownModel
