from ._AimTTi_PL_P import AimTTi


class AimTTiPL303QMDP(AimTTi):
    """
    This is the QCoDeS driver for the Aim TTi PL303QMD-P series power supply.
    """

    pass
