from ._AimTTi_PL_P import AimTTi


class AimTTiPL303QMTP(AimTTi):
    """
    This is the QCoDeS driver for the Aim TTi PL303QMT-P series power supply.
    """

    pass
