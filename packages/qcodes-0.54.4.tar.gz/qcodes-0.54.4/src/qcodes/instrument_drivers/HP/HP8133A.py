"""
Module left for backwards compatibility. Will be deprecated and removed eventually.
"""

from .HP_8133A import HP8133A
