from ._Keithley_2600 import Keithley2600


class Keithley2611B(Keithley2600):
    """
    QCoDeS driver for the Keithley 2611B Source-Meter
    """

    pass
