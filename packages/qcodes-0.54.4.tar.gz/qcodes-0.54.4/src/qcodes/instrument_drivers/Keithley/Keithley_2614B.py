from ._Keithley_2600 import Keithley2600


class Keithley2614B(Keithley2600):
    """
    QCoDeS driver for the Keithley 2614B Source-Meter
    """

    pass
