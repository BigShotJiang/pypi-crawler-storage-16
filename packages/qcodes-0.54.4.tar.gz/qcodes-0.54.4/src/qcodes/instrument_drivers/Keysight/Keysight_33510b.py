from .KeysightAgilent_33XXX import Keysight33xxxDualChannels


class Keysight33510B(Keysight33xxxDualChannels):
    """
    QCoDeS driver for the Keysight 33510B waveform generator.
    """
