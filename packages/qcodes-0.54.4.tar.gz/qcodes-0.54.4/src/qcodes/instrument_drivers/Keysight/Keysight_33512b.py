from .KeysightAgilent_33XXX import Keysight33xxxDualChannels


class Keysight33512B(Keysight33xxxDualChannels):
    """
    QCoDeS driver for the Keysight 33512B waveform generator.
    """
