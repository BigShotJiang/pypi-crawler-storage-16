from .KeysightAgilent_33XXX import Keysight33xxxDualChannels


class Keysight33622A(Keysight33xxxDualChannels):
    """
    QCoDeS driver for the Keysight 33622A waveform generator.
    """
