from ._minicircuits_rc_sp4t import MiniCircuitsRCSP4T, MiniCircuitsRCSP4TChannel

MC_channel = MiniCircuitsRCSP4TChannel
"""
Alias for backwards compatibility
"""

RC_SP4T = MiniCircuitsRCSP4T
"""
Alias for backwards compatibility
"""
