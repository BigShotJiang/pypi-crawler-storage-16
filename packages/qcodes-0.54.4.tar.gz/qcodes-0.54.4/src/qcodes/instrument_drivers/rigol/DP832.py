"""
Old alias for RigolDP832 for backwards compatibility.
Will eventually be deprecated and removed.
"""

from .Rigol_DP832 import RigolDP832
