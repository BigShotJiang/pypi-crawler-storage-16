from .ZNB import RohdeSchwarzZNBBase


class RohdeSchwarzZNB20(RohdeSchwarzZNBBase):
    """
    QCoDeS driver for Rohde & Schwarz ZNB20

    """

    pass
