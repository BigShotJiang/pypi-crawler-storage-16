Acknowledgements
================

This project is built on top of
`Qiskit <https://github.com/Qiskit/qiskit>`__ which is licensed under
the Apache 2.0 license.