Examples on using QCut
======================

.. toctree::
   :maxdepth: 3
   :caption: Contents:

   WireCuts
   GateCuts
   AutomaticCuts
   Multiple_cuts
   OtherObservables