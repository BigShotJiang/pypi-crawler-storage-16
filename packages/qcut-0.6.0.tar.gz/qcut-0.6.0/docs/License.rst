License
============

`Apache 2.0
license <https://github.com/JooNiv/QCut/blob/main/LICENSE>`__