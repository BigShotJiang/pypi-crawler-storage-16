"""Parser helpers for code document parsing (AST and tree-sitter)."""
