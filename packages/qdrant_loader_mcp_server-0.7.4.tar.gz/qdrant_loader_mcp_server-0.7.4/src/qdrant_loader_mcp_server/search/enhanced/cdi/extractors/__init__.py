"""Extractor and analysis components for CDI."""
