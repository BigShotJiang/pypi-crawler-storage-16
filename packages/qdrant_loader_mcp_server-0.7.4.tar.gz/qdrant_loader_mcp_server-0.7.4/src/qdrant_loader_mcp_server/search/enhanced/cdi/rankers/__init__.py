"""Ranking components for CDI search results."""
