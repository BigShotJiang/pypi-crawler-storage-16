# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.8.2
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x01\xf8\
P\
rogressBarBase {\
\x0d\x0a\x09text-align: c\
enter;\x0d\x0a    colo\
r: black;\x0d\x0a\x09back\
ground-color: rg\
ba(24, 24, 24, 6\
);\x0d\x0a    border: \
1.2px solid rgba\
(54, 45, 33, 12)\
;\x0d\x0a    border-ra\
dius: 3px;\x0d\x0a}\x0d\x0aP\
rogressBarBase[i\
sBorderless=true\
] {\x0d\x0a    padding\
: 1.2px;\x0d\x0a\x09borde\
r: none;\x0d\x0a}\x0d\x0aPro\
gressBarBase[isT\
ransparent=true]\
 {\x0d\x0a\x09background-\
color: transpare\
nt;\x0d\x0a}\x0d\x0a\x0d\x0aProgre\
ssBarBase::chunk\
 {\x0d\x0a\x09background-\
color: qlineargr\
adient(spread: p\
ad, x1:0, y1:0, \
x2:1, y2:0, stop\
:0 transparent, \
stop:1 rgba(120,\
 180, 240, 123))\
;\x0d\x0a    border: n\
one;\x0d\x0a}\
\x00\x00\x02\x11\
\x00\
\x00\x07px\xda\x95UMo\xe20\x10\xbdW\xea\x7f\
\xf0\x11\xa4P\xe5\x03\x10\xeb\xd5^8\xf5\xd2\x95V\xea\
\xad\xda\x83\x89\xbd\x89U\xd7Nm\xa7@+\xfe\xfb\xda\
q>\x1dR\x80\x08+\xd83\xcfof\xde\x0c\xdbR\
k\xc1\xb7H\x11\xf0u\x7f\x07\xcc'\x15LH\x08d\
\xb6\x9b-W\x01H\x92\x00\xc4\xd1\xfc\xa7;\xdc\xa1\xf4\
5\x93\xa2\xe4x\xd1\xd9\xa1Y\xbc4F\xf5w\xdd\xd8\
\x16\x08c\xca3\x08\x96\x0f\x9b\xe2\x00\xa2\xd8,\xeb\xfa\
\xa5\x81\x13\x12\x13\x03\x12=\xd8C%\x18\xc5\x0epe\
\x80\x9a\xdb\xa3x>0_\xec\x84\xe1\xfc6 \xd0\xb7\
_n<{\x890-\x15\x04I{\xaf(5\xa3\x9c\
@\xc0\x05'f\xeft\x7f\xb7m\x13\xf1B\xd5\xb6r\
dD\xa9_Z\x96\xe4o\x93\x9b6\xa4\x8a\xb0\x17\xc4\
\x04\xd6\xb3D\x5c\x15H\x12\xae\x87`\xe3\x5c\xea\xce\xd4\
\x07\x82\xb9\xf8 r\xdauT\x06\x97\xb5!F!M\
D\x04\x07\xa0\xb7\x97\xe6$}%x\x5c}\xd4+\xbf\
\x85K.W!\x8aCc\xb9\x09-\x83jY\x8f9\
`\xaa\xd0\x8e]\xbe\xf0GX\xfb\xda\xe7\x89\xf0\xd2a\
\x04\xe0Q0&\xf6\xee\xd7\xb5\xa9\xec\xd1\xdeS\xac\xf3\
s\x05\x5c(}dF\x12\x95\x0a\x87'SJ\xab\x93\
r\xea\x13t\x85\x1a\xd2\xf4\x8a\xf7=h\x1cu\x91w\
\xb0\xe0\x8f}\x9f\x8ew\x9fSM|.\xce\x09Bs\
\xf4vA:\x83\xb0V^\x0b/\xb4(\xfa\xed\xd3l\
3\xf2OC\xdb\xd3\xde\xbe\x93\xc69\x0fI\xb3|\xe0\
2n\x9e\xf3\xf4\xaf\xd2\xbf\xd3_\x7f\x99\x7f\x8b\xa9\x08\
#\xa9\xee\xb4x+\xac}~\xa3\x0f\x9a!M\x8d\xbc\
o\x96d;N\xc2Q>\xc2v\x1eN*\xb9\x19k\
\xce\xf94\xa6r)g\xefv\x06\x22\x99Y \x83>\
Sf> \x0c-\xad\x00\x1c\x22hb=V\xeb!\
\x86\xa6#\x8f\xb1}WV\x0b\xe1\xd9~\xb7\xedP\x1b\
D}\xda\xf3\x09z\xde\xe8\xb9\xa1\x89\x9d\xf0\x92\xe1\x7f\
\xc6\xe4\xf4\xf1/6C\xf9QH\xfa)\xb8F\xcc\xcd\
\xe4\x11\x97\xeb\xcb\xd0\x13\xfb\x15l\xfe\x03]\x9b9@\
\
\x00\x00\x00\x9b\
Q\
Widget {\x0d\x0a    ba\
ckground-color: \
qlineargradient(\
spread: pad, x1:\
0, y1:0, x2:1, y\
2:0, stop:0 rgba\
(246, 246, 246, \
246), stop:1 rgb\
a(234, 234, 234,\
 246));\x0d\x0a}\
\x00\x00\x01%\
C\
heckBoxBase {\x0d\x0a \
   background-co\
lor: transparent\
;\x0d\x0a}\x0d\x0aCheckBoxBa\
se::indicator {\x0d\
\x0a    background-\
color: transpare\
nt;\x0d\x0a    border:\
 none;\x0d\x0a}\x0d\x0a\x0d\x0aChe\
ckBoxBase QLabel\
 {\x0d\x0a    color: b\
lack;\x0d\x0a    backg\
round-color: tra\
nsparent;\x0d\x0a    b\
order: none;\x0d\x0a}\x0d\
\x0aCheckBoxBase QL\
abel:disabled {\x0d\
\x0a    color: grey\
;\x0d\x0a}\
\x00\x00\x01R\
T\
extBrowserBase {\
\x0d\x0a    color: rgb\
(45, 33, 21);\x0d\x0a\x09\
text-align: left\
;\x0d\x0a\x09selection-ba\
ckground-color: \
darkgrey;\x0d\x0a\x09back\
ground-color: tr\
ansparent;\x0d\x0a    \
padding: 1.2px;\x0d\
\x0a\x09border: none;\x0d\
\x0a\x09border-radius:\
 3px;\x0d\x0a}\x0d\x0aTextBr\
owserBase[isBord\
erless=false] {\x0d\
\x0a    padding: 0p\
x;\x0d\x0a    border: \
1.2px solid rgba\
(54, 45, 33, 123\
);\x0d\x0a}\x0d\x0aTextBrows\
erBase:hover {\x0d\x0a\
}\
\x00\x00\x01\xcf\
T\
oolBoxBase {\x0d\x0a  \
  background-col\
or: transparent;\
\x0d\x0a    padding: 0\
px;\x0d\x0a    border:\
 none;\x0d\x0a\x09border-\
radius: 3px;\x0d\x0a}\x0d\
\x0a\x0d\x0aToolPage {\x0d\x0a\x09\
background-color\
: transparent;\x0d\x0a\
    border: none\
;\x0d\x0a}\x0d\x0a\x0d\x0aToolPage\
 Folder {\x0d\x0a    c\
olor: rgb(45, 33\
, 21);\x0d\x0a\x09text-al\
ign: left;\x0d\x0a\x09bac\
kground-color: t\
ransparent;\x0d\x0a\x09pa\
dding-top: 3px;\x0d\
\x0a\x09padding-left: \
12px;\x0d\x0a\x09padding-\
bottom: 3px;\x0d\x0a\x09p\
adding-right: 6p\
x;\x0d\x0a    border: \
none;\x0d\x0a}\x0d\x0aToolPa\
ge Folder:hover \
{\x0d\x0a\x09background-c\
olor: rgba(54, 4\
5, 33, 12);\x0d\x0a}\
\x00\x00\x01|\
C\
hatWidgetBase {\x0d\
\x0a    background-\
color: transpare\
nt;\x0d\x0a    border:\
 none;\x0d\x0a\x09border-\
radius: 3px;\x0d\x0a}\x0d\
\x0aChatWidgetBase:\
hover {\x0d\x0a}\x0d\x0a\x0d\x0aCh\
atWidgetBase QWi\
dget {\x0d\x0a    back\
ground-color: tr\
ansparent;\x0d\x0a    \
border: none;\x0d\x0a}\
\x0d\x0aChatWidgetBase\
 QWidget:hover {\
\x0d\x0a}\x0d\x0a\x0d\x0aChatWidge\
tBase MessageDis\
play {\x0d\x0a    back\
ground-color: tr\
ansparent;\x0d\x0a    \
padding: 12px;\x0d\x0a\
}\x0d\x0aChatWidgetBas\
e MessageDisplay\
:hover {\x0d\x0a}\
\x00\x00\x02\x5c\
L\
istBase {\x0d\x0a\x09back\
ground-color: tr\
ansparent;\x0d\x0a    \
padding: 1.2px;\x0d\
\x0a\x09border: none;\x0d\
\x0a\x09border-radius:\
 3px;\x0d\x0a    outli\
ne: none;\x0d\x0a}\x0d\x0aLi\
stBase[isBorderl\
ess=false] {\x0d\x0a  \
  padding: 0px;\x0d\
\x0a    border: 1.2\
px solid rgba(54\
, 45, 33, 123);\x0d\
\x0a}\x0d\x0aListBase:hov\
er {\x0d\x0a    border\
-color: rgba(54,\
 45, 33, 210);\x0d\x0a\
}\x0d\x0a\x0d\x0aListBase::i\
tem {\x0d\x0a    color\
: rgb(45, 33, 21\
);\x0d\x0a\x09background-\
color: transpare\
nt;\x0d\x0a    border:\
 2.4px solid tra\
nsparent;\x0d\x0a\x09padd\
ing: 2.4px;\x0d\x0a}\x0d\x0a\
ListBase::item:h\
over {\x0d\x0a\x09backgro\
und-color: rgba(\
54, 45, 33, 12);\
\x0d\x0a}\x0d\x0aListBase::i\
tem:selected {\x0d\x0a\
\x09background-colo\
r: transparent;\x0d\
\x0a\x09border-left-co\
lor: rgb(120, 18\
0, 240);\x0d\x0a}\
\x00\x00\x033\
L\
ineEditBase, Tex\
tEditBase {\x0d\x0a   \
 color: rgb(45, \
33, 21);\x0d\x0a\x09text-\
align: left;\x0d\x0a\x09s\
election-backgro\
und-color: darkg\
rey;\x0d\x0a\x09backgroun\
d-color: rgba(24\
, 24, 24, 6);\x0d\x0a \
   padding: 4.8p\
x 12px 6px 12px;\
\x0d\x0a    border: 1.\
2px solid rgba(5\
4, 45, 33, 12);\x0d\
\x0a    border-bott\
om: 1.2px solid \
rgba(54, 45, 33,\
 48);\x0d\x0a\x09border-r\
adius: 3px;\x0d\x0a   \
 outline: none;\x0d\
\x0a}\x0d\x0aLineEditBase\
[isBorderless=tr\
ue], TextEditBas\
e[isBorderless=t\
rue] {\x0d\x0a    padd\
ing: 1.2px;\x0d\x0a\x09bo\
rder: none;\x0d\x0a}\x0d\x0a\
LineEditBase[isT\
ransparent=true]\
, TextEditBase[i\
sTransparent=tru\
e] {\x0d\x0a\x09backgroun\
d-color: transpa\
rent;\x0d\x0a}\x0d\x0aLineEd\
itBase:hover, Te\
xtEditBase:hover\
 {\x0d\x0a\x09background-\
color: rgba(24, \
24, 24, 12);\x0d\x0a}\x0d\
\x0aLineEditBase:fo\
cus, TextEditBas\
e:focus {\x0d\x0a    b\
order-bottom-col\
or: rgba(120, 18\
0, 240, 246);\x0d\x0a}\
\x0d\x0aLineEditBase:d\
isabled, TextEdi\
tBase:disabled {\
\x0d\x0a\x09color: rgba(4\
5, 33, 21, 90);\x0d\
\x0a}\
\x00\x00\x01I\
\x00\
\x00\x06\x01x\xda\xc5S[n\x830\x10\xfc.\x12w\
\xf0g\x22\x85\x8aW>\xea\x9c\x22\xea\x09\x0c\xb6\x8cU\
\x17#\x1b\xd2\xb4U\xee\xde-\xad\xa1\x09\xd8\xa5\x0f\xb5\
H \xb0vg\x98\xdd\x99\xfd\xad\x14\x94i\x5c)-\
\x9eT\xdd\x12\x89\x9e\xc3\x00\xc1U1\xc1\xab\x16\xa34\
o\x8e\xbb08\x85A\x18\xec\xdf\xab1\xd7J\x1d\x98\
\xa7+\xeb\x9b^O\x0aR\xdeAyW\xd3\xa8TR\
i\x8c4/\xc8*I\xb3\x0d\x1a\x1fi\x12\xafm\x83\
\xd2\xc0\x11iBEg,\xd2\xc9G\x8e\xa90\xa4\x90\
\x8c\xda\xbfX\xc6\x09\x8f\xf5D\x99\xe9\x8a\xa8!|N\
\xdb\x88\x8aQ!\xe1c\xe7\xd4\xec\x90\xf0\x81\xa7\x225\
\x95s,\x0f\x82\xb6\x15\x8c=\x1e\xd0.6q5\xab\
n\x95\xe60\xc5\xfe>\x1f$F\xc9u\xda\x1c\x91Q\
\xc0\xdcWn\xa1*\xdfnP\x969F\x9e\x8c\xdc\xf7\
DsQc\x14\xdd\x00D<Y\xc5D\x05\xbc\x1e\x98\
v\xef\xc1\xce\xcd\x0f\xd2hf\x8co\x9d\xcb`>\xb7\
\x05\xd7\xec\xd1\xaef\x84\x02\x05\xad(\xa7+\xf1$\xc1\
\xd1\xf2\x071\xb0\xcc\xbf\x19\x02B\xe9[\x08.e\xb9\
\x220\x95\xbb8\x01\xfea\x9f\xf9?\xfe?\xff\xc3I\
\x9f\x81y\xcf\x0d;\xf8\xbe\xfb\x07\x88\x9fx\xff\x0b^\
\xb0\xce\x7f\x01\xd5\xb4\xd1\xa5\
\x00\x00\x06m\
C\
omboBoxBase {\x0d\x0a \
   color: rgb(45\
, 33, 21);\x0d\x0a\x09tex\
t-align: left;\x0d\x0a\
\x09selection-backg\
round-color: dar\
kgrey;\x0d\x0a\x09backgro\
und-color: rgba(\
24, 24, 24, 6);\x0d\
\x0a    padding: 4.\
8px 12px 6px 12p\
x;\x0d\x0a    border: \
1.2px solid rgba\
(54, 45, 33, 12)\
;\x0d\x0a    border-bo\
ttom: 1.2px soli\
d rgba(54, 45, 3\
3, 48);\x0d\x0a\x09border\
-radius: 3px;\x0d\x0a \
   outline: none\
;\x0d\x0a}\x0d\x0aComboBoxBa\
se[isBorderless=\
true] {\x0d\x0a    pad\
ding: 1.2px;\x0d\x0a\x09b\
order: none;\x0d\x0a}\x0d\
\x0aComboBoxBase[is\
Transparent=true\
] {\x0d\x0a\x09background\
-color: transpar\
ent;\x0d\x0a}\x0d\x0aComboBo\
xBase:hover {\x0d\x0a\x09\
background-color\
: rgba(24, 24, 2\
4, 12);\x0d\x0a}\x0d\x0aComb\
oBoxBase:focus {\
\x0d\x0a    border-bot\
tom-color: rgba(\
120, 180, 240, 2\
46);\x0d\x0a}\x0d\x0aComboBo\
xBase:disabled {\
\x0d\x0a\x09color: rgba(4\
5, 33, 21, 90);\x0d\
\x0a}\x0d\x0a\x0d\x0aComboBoxBa\
se::drop-down {\x0d\
\x0a\x09subcontrol-ori\
gin: padding;\x0d\x0a\x09\
subcontrol-posit\
ion: right;\x0d\x0a\x09ma\
rgin-right: 6px;\
\x0d\x0a\x09border: none;\
\x0d\x0a}\x0d\x0a\x0d\x0aComboBoxB\
ase::down-arrow \
{\x0d\x0a\x09border-image\
: url(:/Icons/ic\
ons/light/Chevro\
n-Down.svg);\x0d\x0a}\x0d\
\x0aComboBoxBase::d\
own-arrow:on {\x0d\x0a\
\x09border-image: u\
rl(:/Icons/icons\
/light/Chevron-U\
p.svg);\x0d\x0a}\x0d\x0a\x0d\x0a\x0d\x0a\
ComboBoxBase QAb\
stractItemView {\
\x0d\x0a\x09background-co\
lor: white;\x0d\x0a\x09bo\
rder: 1.2px soli\
d rgba(54, 45, 3\
3, 123);\x0d\x0a\x09outli\
ne: none;\x0d\x0a}\x0d\x0aCo\
mboBoxBase QAbst\
ractItemView[isB\
orderless=true] \
{\x0d\x0a    padding: \
1.2px;\x0d\x0a\x09border:\
 none;\x0d\x0a}\x0d\x0aCombo\
BoxBase QAbstrac\
tItemView[isTran\
sparent=true] {\x0d\
\x0a\x09background-col\
or: transparent;\
\x0d\x0a}\x0d\x0a\x0d\x0aComboBoxB\
ase QAbstractIte\
mView::item {\x0d\x0a \
   color: rgb(45\
, 33, 21);\x0d\x0a\x09bac\
kground-color: r\
gba(54, 45, 33, \
15);\x0d\x0a\x09padding: \
3px 6px;\x0d\x0a\x09borde\
r: none;\x0d\x0a}\x0d\x0aCom\
boBoxBase QAbstr\
actItemView::ite\
m:hover {\x0d\x0a\x09back\
ground-color: rg\
ba(123, 123, 123\
, 123);\x0d\x0a}\x0d\x0aComb\
oBoxBase QAbstra\
ctItemView::item\
:selected {\x0d\x0a\x09ba\
ckground-color: \
rgba(123, 123, 1\
23, 123);\x0d\x0a}\
\x00\x00\x01\xcb\
G\
roupBoxBase {\x0d\x0a \
   color: rgb(45\
, 33, 21);\x0d\x0a\x09mar\
gin-top: 1.5ex;\x0d\
\x0a\x09background-col\
or: transparent;\
\x0d\x0a\x09border: 1.2px\
 solid transpare\
nt;\x0d\x0a\x09border-rad\
ius: 3px;\x0d\x0a}\x0d\x0a\x0d\x0a\
GroupBoxBase::ti\
tle {\x0d\x0a\x09subcontr\
ol-origin: margi\
n;\x0d\x0a\x09subcontrol-\
position: top le\
ft;\x0d\x0a\x09padding: 3\
px;\x0d\x0a}\x0d\x0a\x0d\x0aGroupB\
oxBase::indicato\
r:checked {\x0d\x0a\x09bo\
rder-image: url(\
:/Icons/icons/li\
ght/Chevron-Down\
.svg);\x0d\x0a}\x0d\x0aGroup\
BoxBase::indicat\
or:unchecked {\x0d\x0a\
\x09border-image: u\
rl(:/Icons/icons\
/light/Chevron-U\
p.svg);\x0d\x0a}\
\x00\x00\x00\xf0\
S\
crollAreaBase {\x0d\
\x0a\x09border: 0px so\
lid;\x0d\x0a\x09border-ra\
dius: 3px;\x0d\x0a}\x0d\x0aS\
crollAreaBase[is\
Borderless=true]\
 {\x0d\x0a    padding:\
 1.2px;\x0d\x0a\x09border\
: none;\x0d\x0a}\x0d\x0aScro\
llAreaBase[isTra\
nsparent=true] {\
\x0d\x0a\x09background-co\
lor: transparent\
;\x0d\x0a}\x0d\x0aScrollArea\
Base:hover {\x0d\x0a}\
\x00\x00\x00\xa1\
L\
abelBase {\x0d\x0a    \
color: rgb(45, 3\
3, 21);\x0d\x0a    bac\
kground-color: t\
ransparent;\x0d\x0a   \
 padding: 0px;\x0d\x0a\
    border: none\
;\x0d\x0a\x09border-radiu\
s: 3px;\x0d\x0a}\x0d\x0aLabe\
lBase:hover {\x0d\x0a}\
\
\x00\x00\x02\x14\
Q\
TabWidget::tab-b\
ar {\x0d\x0a    alignm\
ent: left;\x0d\x0a}\x0d\x0a\x0d\
\x0a\x0d\x0aQTabBar::tab \
{\x0d\x0a    color: rg\
b(45, 33, 21);\x0d\x0a\
\x09background-colo\
r: rgba(24, 24, \
24, 6);\x0d\x0a    pad\
ding: 2.4px 4.8p\
x;\x0d\x0a    border: \
1.2px solid rgba\
(54, 45, 33, 12)\
;\x0d\x0a}\x0d\x0aQTabBar::t\
ab[isBorderless=\
true] {\x0d\x0a    pad\
ding: 3.6px 6.0p\
x;\x0d\x0a\x09border: non\
e;\x0d\x0a}\x0d\x0aQTabBar::\
tab:hover {\x0d\x0a\x09ba\
ckground-color: \
rgba(24, 24, 24,\
 12);\x0d\x0a}\x0d\x0aQTabBa\
r::tab:selected \
{\x0d\x0a\x09background-c\
olor: rgba(24, 2\
4, 24, 18);\x0d\x0a}\x0d\x0a\
\x0d\x0a\x0d\x0aQTabWidget::\
pane {\x0d\x0a\x09backgro\
und: transparent\
;\x0d\x0a    border: 1\
.2px solid rgba(\
54, 45, 33, 12);\
\x0d\x0a}\
\x00\x00\x02\x87\
Q\
TreeView {\x0d\x0a\x09bac\
kground-color: t\
ransparent;\x0d\x0a   \
 outline: none;\x0d\
\x0a\x09border: none;\x0d\
\x0a\x09border-radius:\
 3px;\x0d\x0a}\x0d\x0a\x0d\x0aQTre\
eView::item {\x0d\x0a \
   color: rgb(45\
, 33, 21);\x0d\x0a\x09bac\
kground-color: t\
ransparent;\x0d\x0a\x09pa\
dding: 3px;\x0d\x0a\x09bo\
rder: none;\x0d\x0a\x09bo\
rder-radius: 3px\
;\x0d\x0a}\x0d\x0aQTreeView:\
:item:hover {\x0d\x0a\x09\
background-color\
: rgba(54, 45, 3\
3, 12);\x0d\x0a}\x0d\x0aQTre\
eView::item:sele\
cted {\x0d\x0a}\x0d\x0a\x0d\x0aQTr\
eeView::branch {\
\x0d\x0a    background\
-color: transpar\
ent;\x0d\x0a\x09border: n\
one;\x0d\x0a}\x0d\x0aQTreeVi\
ew::branch:open:\
has-children {\x0d\x0a\
\x09image: url(:/Ic\
ons/icons/light/\
Chevron-Down.svg\
);\x0d\x0a\x09padding: 3p\
x;\x0d\x0a}\x0d\x0aQTreeView\
::branch:closed:\
has-children {\x0d\x0a\
\x09image: url(:/Ic\
ons/icons/light/\
Chevron-Right.sv\
g);\x0d\x0a\x09padding: 3\
px;\x0d\x0a}\
\x00\x00\x04Y\
M\
ediaPlayerBase {\
\x0d\x0a    padding: 4\
.8px 12px 6px 12\
px;\x0d\x0a}\x0d\x0aMediaPla\
yerBase[isBorder\
less=true] {\x0d\x0a  \
  padding: 1.2px\
;\x0d\x0a\x09border: none\
;\x0d\x0a}\x0d\x0aMediaPlaye\
rBase[isTranspar\
ent=true] {\x0d\x0a\x09ba\
ckground-color: \
transparent;\x0d\x0a}\x0d\
\x0a\x0d\x0aMediaPlayerBa\
se ButtonBase {\x0d\
\x0a    background-\
color: transpare\
nt;\x0d\x0a    border:\
 none;\x0d\x0a    bord\
er-radius: 12px;\
\x0d\x0a}\x0d\x0aMediaPlayer\
Base ButtonBase:\
hover {\x0d\x0a    bac\
kground-color: r\
gba(54, 45, 33, \
33);\x0d\x0a}\x0d\x0a\x0d\x0a\x0d\x0aMed\
iaPlayerBase QSl\
ider::groove:hor\
izontal {\x0d\x0a\x09heig\
ht: 1.2px;\x0d\x0a\x09bac\
kground-color: r\
gba(54, 45, 33, \
123);\x0d\x0a\x09border: \
none;\x0d\x0a\x09border-r\
adius: 6px;\x0d\x0a}\x0d\x0a\
MediaPlayerBase \
QSlider::groove:\
horizontal:hover\
 {\x0d\x0a\x09background-\
color: rgba(54, \
45, 33, 210);\x0d\x0a}\
\x0d\x0a\x0d\x0aMediaPlayerB\
ase QSlider::han\
dle:horizontal {\
\x0d\x0a\x09width: 12px;\x0d\
\x0a\x09height: 12px;\x0d\
\x0a\x09background-col\
or: rgba(54, 45,\
 33, 210);\x0d\x0a\x09mar\
gin-top: -6px;\x0d\x0a\
\x09margin-bottom: \
-6px;\x0d\x0a\x09border: \
1.2px solid tran\
sparent;\x0d\x0a\x09borde\
r-radius: 6px;\x0d\x0a\
}\x0d\x0aMediaPlayerBa\
se QSlider::hand\
le:horizontal:ho\
ver {\x0d\x0a\x09backgrou\
nd-color: rgba(4\
5, 33, 21, 234);\
\x0d\x0a}\x0d\x0a\x0d\x0a\x0d\x0aEmbedde\
dMediaPlayer {\x0d\x0a\
\x09background-colo\
r: transparent;\x0d\
\x0a    padding: 1.\
2px;\x0d\x0a\x09border: n\
one;\x0d\x0a}\x0d\x0aEmbedde\
dMediaPlayer: ho\
ver {\x0d\x0a}\
\x00\x00\x013\
T\
oolTipBase {\x0d\x0a  \
  background-col\
or: rgba(24, 24,\
 24, 6);\x0d\x0a    bo\
rder: 1.2px soli\
d rgba(54, 45, 3\
3, 12);\x0d\x0a    bor\
der-radius: 3px;\
\x0d\x0a}\x0d\x0aToolTipBase\
[isTransparent=t\
rue] {\x0d\x0a    back\
ground-color: tr\
ansparent;\x0d\x0a}\x0d\x0a\x0d\
\x0a\x0d\x0aQLabel {\x0d\x0a   \
 color: rgb(45, \
33, 21);\x0d\x0a    ba\
ckground-color: \
transparent;\x0d\x0a  \
  border: none;\x0d\
\x0a}\
\x00\x00\x03\xa1\
M\
enuBase {\x0d\x0a    b\
ackground-color:\
 transparent;\x0d\x0a \
   border: none;\
\x0d\x0a}\x0d\x0a\x0d\x0aMenuActio\
nListWidget {\x0d\x0a \
   font: 12px --\
FontFamilies;\x0d\x0a \
   background-co\
lor: rgba(24, 24\
, 24, 6);\x0d\x0a    b\
order: 1.2px sol\
id rgba(54, 45, \
33, 12);\x0d\x0a    bo\
rder-radius: 3px\
;\x0d\x0a    outline: \
none;\x0d\x0a}\x0d\x0aMenuAc\
tionListWidget[t\
ransparent=true]\
 {\x0d\x0a    backgrou\
nd-color: transp\
arent;\x0d\x0a}\x0d\x0a\x0d\x0aMen\
uActionListWidge\
t::item {\x0d\x0a    p\
adding-left: 9px\
;\x0d\x0a    padding-r\
ight: 9px;\x0d\x0a    \
border-radius: 3\
px;\x0d\x0a    margin-\
left: 6px;\x0d\x0a    \
margin-right: 6p\
x;\x0d\x0a    color: r\
gb(45, 33, 21);\x0d\
\x0a    border: non\
e;\x0d\x0a}\x0d\x0aMenuActio\
nListWidget::ite\
m:hover {\x0d\x0a    b\
ackground-color:\
 rgba(24, 24, 24\
, 12);\x0d\x0a}\x0d\x0aMenuA\
ctionListWidget:\
:item:selected {\
\x0d\x0a    color: rgb\
a(45, 33, 21, 12\
3);\x0d\x0a    backgro\
und-color: rgba(\
120, 180, 240, 2\
46);\x0d\x0a}\x0d\x0aMenuAct\
ionListWidget::i\
tem:disabled {\x0d\x0a\
    padding-left\
: 9px;\x0d\x0a    padd\
ing-right: 9px;\x0d\
\x0a    border-radi\
us: 3px;\x0d\x0a    co\
lor: rgba(45, 33\
, 21, 90);\x0d\x0a    \
border: none;\x0d\x0a}\
\
\x00\x00\x01\x05\
Q\
DockWidget {\x0d\x0a  \
  border: none;\x0d\
\x0a}\x0d\x0aQDockWidget[\
isBorderless=fal\
se] {\x0d\x0a    paddi\
ng: 0px;\x0d\x0a    bo\
rder: 1.2px soli\
d rgba(54, 45, 3\
3, 123);\x0d\x0a}\x0d\x0aQDo\
ckWidget[isTrans\
parent=true] {\x0d\x0a\
\x09background-colo\
r: transparent;\x0d\
\x0a}\x0d\x0a\x0d\x0aQDockWidge\
t::title {\x0d\x0a    \
text-align: left\
;\x0d\x0a}\
\x00\x00\x03\xad\
Q\
HeaderView {\x0d\x0a  \
  background-col\
or: transparent;\
\x0d\x0a}\x0d\x0a\x0d\x0aQHeaderVi\
ew::section {\x0d\x0a \
   color: rgb(45\
, 33, 21);\x0d\x0a\x09bac\
kground-color: t\
ransparent;\x0d\x0a   \
 padding: 2.4px \
4.8px;\x0d\x0a    bord\
er: 1.2px solid \
rgba(54, 45, 33,\
 123);\x0d\x0a}\x0d\x0aQHead\
erView::section:\
horizontal {\x0d\x0a  \
  border-top: no\
ne;\x0d\x0a    border-\
left: none;\x0d\x0a}\x0d\x0a\
QHeaderView::sec\
tion:vertical {\x0d\
\x0a    border-top:\
 none;\x0d\x0a}\x0d\x0a\x0d\x0a\x0d\x0aQ\
TableView {\x0d\x0a\x09ba\
ckground-color: \
transparent;\x0d\x0a  \
  selection-back\
ground-color: tr\
ansparent;\x0d\x0a    \
gridline-color: \
rgba(54, 45, 33,\
 123);\x0d\x0a\x09border:\
 1.2px solid rgb\
a(54, 45, 33, 12\
3);\x0d\x0a\x09border-rad\
ius: 3px;\x0d\x0a    o\
utline: none;\x0d\x0a}\
\x0d\x0aQTableView[isB\
orderless=true] \
{\x0d\x0a    padding: \
1.2px;\x0d\x0a\x09border:\
 none;\x0d\x0a}\x0d\x0a\x0d\x0aQTa\
bleView::item {\x0d\
\x0a    color: rgb(\
45, 33, 21);\x0d\x0a  \
  padding: 3px 6\
px;\x0d\x0a    border:\
 0px solid rgba(\
54, 45, 33, 123)\
;\x0d\x0a\x09border-botto\
m-width: 1.2px;\x0d\
\x0a}\x0d\x0aQTableView::\
item::selected {\
\x0d\x0a\x09border-color:\
 rgba(54, 45, 33\
, 210);\x0d\x0a}\x0d\x0aQTab\
leView::item:!al\
ternate:!selecte\
d {\x0d\x0a    \x0d\x0a}\
\x00\x00\x05\x8b\
S\
pinBoxBase, Doub\
leSpinBoxBase {\x0d\
\x0a    color: rgb(\
45, 33, 21);\x0d\x0a\x09t\
ext-align: left;\
\x0d\x0a\x09selection-bac\
kground-color: d\
arkgrey;\x0d\x0a\x09backg\
round-color: rgb\
a(24, 24, 24, 6)\
;\x0d\x0a    padding: \
4.8px 12px 6px 1\
2px;\x0d\x0a    border\
: 1.2px solid rg\
ba(54, 45, 33, 1\
2);\x0d\x0a    border-\
bottom: 1.2px so\
lid rgba(54, 45,\
 33, 48);\x0d\x0a\x09bord\
er-radius: 3px;\x0d\
\x0a    outline: no\
ne;\x0d\x0a}\x0d\x0aSpinBoxB\
ase[isBorderless\
=true] DoubleSpi\
nBoxBase[isBorde\
rless=true] {\x0d\x0a \
   padding: 1.2p\
x;\x0d\x0a\x09border: non\
e;\x0d\x0a}\x0d\x0aSpinBoxBa\
se[isTransparent\
=true] DoubleSpi\
nBoxBase[isBorde\
rless=true] {\x0d\x0a\x09\
background-color\
: transparent;\x0d\x0a\
}\x0d\x0aSpinBoxBase:h\
over, DoubleSpin\
BoxBase:hover {\x0d\
\x0a\x09background-col\
or: rgba(24, 24,\
 24, 12);\x0d\x0a}\x0d\x0aSp\
inBoxBase:focus,\
 DoubleSpinBoxBa\
se:focus {\x0d\x0a    \
border-bottom-co\
lor: rgba(120, 1\
80, 240, 246);\x0d\x0a\
}\x0d\x0aSpinBoxBase:d\
isabled, DoubleS\
pinBoxBase:disab\
led {\x0d\x0a\x09color: r\
gba(45, 33, 21, \
90);\x0d\x0a}\x0d\x0a\x0d\x0aSpinB\
oxBase::up-butto\
n, DoubleSpinBox\
Base::up-button \
{\x0d\x0a\x09subcontrol-o\
rigin: padding;\x0d\
\x0a\x09subcontrol-pos\
ition: top right\
;\x0d\x0a\x09margin-right\
: 4.5px;\x0d\x0a\x09borde\
r-width: 0px;\x0d\x0a}\
\x0d\x0aSpinBoxBase::u\
p-arrow, DoubleS\
pinBoxBase::up-a\
rrow {\x0d\x0a\x09border-\
image: url(:/Ico\
ns/icons/light/C\
hevron-Up.svg);\x0d\
\x0a}\x0d\x0a\x0d\x0aSpinBoxBas\
e::down-button, \
DoubleSpinBoxBas\
e::down-button {\
\x0d\x0a\x09subcontrol-or\
igin: padding;\x0d\x0a\
\x09subcontrol-posi\
tion: bottom rig\
ht;\x0d\x0a\x09margin-rig\
ht: 4.5px;\x0d\x0a\x09bor\
der-width: 0px;\x0d\
\x0a}\x0d\x0aSpinBoxBase:\
:down-arrow, Dou\
bleSpinBoxBase::\
down-arrow {\x0d\x0a\x09b\
order-image: url\
(:/Icons/icons/l\
ight/Chevron-Dow\
n.svg);\x0d\x0a}\
\x00\x00\x01\xff\
P\
rogressBarBase {\
\x0d\x0a\x09text-align: c\
enter;\x0d\x0a    colo\
r: black;\x0d\x0a\x09back\
ground-color: rg\
ba(246, 246, 246\
, 18);\x0d\x0a    bord\
er: 1.2px solid \
rgba(210, 222, 2\
34, 12);\x0d\x0a    bo\
rder-radius: 3px\
;\x0d\x0a}\x0d\x0aProgressBa\
rBase[isBorderle\
ss=true] {\x0d\x0a    \
padding: 1.2px;\x0d\
\x0a\x09border: none;\x0d\
\x0a}\x0d\x0aProgressBarB\
ase[isTransparen\
t=true] {\x0d\x0a\x09back\
ground-color: tr\
ansparent;\x0d\x0a}\x0d\x0a\x0d\
\x0aProgressBarBase\
::chunk {\x0d\x0a\x09back\
ground-color: ql\
ineargradient(sp\
read: pad, x1:0,\
 y1:0, x2:1, y2:\
0, stop:0 transp\
arent, stop:1 rg\
ba(120, 180, 240\
, 123));\x0d\x0a    bo\
rder: none;\x0d\x0a}\
\x00\x00\x02\x15\
\x00\
\x00\x07\x8fx\xda\x95U\xc1\x8e\xdb \x10\xbd\xaf\xb4\xff\
\xc01\x91\x92\x95M\xdc(\xa5\xea%\xa7\xbd\xb4R\xa5\
\xde\xaa\x1ep\xa0\x0eZ\x16\x5c\xc0\xbbI\xab\xfc{\xc1\
\xd8\x8e\xc1v\xe3\xc4\xd2\x88`\xe6\xf1f\xe6\xcdx_\
\x19#\xc5\x1ek\x0a\xfe>>\x00\xfb;H.\x15\x02\
\xaa\xc8\x170MV\x00Bh\xcd&[~\xf2\xefs\
|x)\x94\xac\x04Y_\x8f\xe2\x05\xcc\xb6\xf6Xg\
\xd2]{\xbe\xc4\x840Q \x90=\xed\xca\x13H\xa1\
5\xdbf\xd1BJE\xa8\x05J\x9f\xdcK-9#\
\x0dh\x9f\x80\x05\x85\xcb\xc0c\x9dK\xcb\xfe5\xe4\x11\
\xbad\xbb\xc8Ea\xc2*\x8d\xc0\xa6\xbb]V\x863\
A\x11\x10RP\xbbwy|\xd8wY\xf9\xc1\xf4\xbe\
v\xe4T\xeb\xcfFU\xf4g\x9b\xa8.\xb0\x9av\x14\
\xca\x04\xd6w\x85\x85.\xb1\xa2\xc2\x84`\xc3\xac\x9a\xeb\
\xd1\x18\x08\x1d\xe5\x1bU\xd3\xaec\x05\x81u\x01C\x98\
R\xd9\xa0(Y\x81\xde\xde\xe1H\x0f/\x94\x0c\xd50\
R\x8d\xcd\xedr\xa40qbp\x8eYm\xb6C\x1a\
\x84i\x9c\xf3Yw~L\x1aw\xf7|\xa1\xa2\xf20\
+\xf0,9\x97\xef\xfe\xdf\xdc\x9c\xf6\x98\xbf3b\x8e\
c\x95\x5cks\xe6V\x1b\xb5(\xc37\x01\xcd$\xb5\
\x0c;\xaeMj.}\x8e\xbeh!\xd3\xa8\x907q\
\xed\xaa\x8b\xff\x8a\x0c\xbe\xb9\xf5t\xd49\xb7[1\x1d\
\xef\x84\x103\xf4\xf5\x96\x92\xa2\xba\x7f\x88Z{md\
\xd9o\xa8v\x9b\xd3_\x06\xb9^\x8f\xf6\xbdL\xc6<\
\x14+\x8e\x81\xcb\xb0\x9d\xc6#\x98\xd5\x11^\x8b}\xb3\
\xfc/\xa6\xa6\x9c\x1e\xccU\x97\xf7\xc2\xba\xe7+~c\
\x056\xccJ\xfdnmv\x03&\x19\xe4#\xe9\xe6\xe4\
\xa4\xa4\xdbA\xe7\x9d/C*\xb7r\xf6\xdbME\xac\
\x0a\x07d\xd1\x17\xda\x8e\x0bL\x90\xa3\xb5\x02\xa7\x14\xd9\
X\xcf\xb5=AdUz\x86n\xad\x9d\x16\x92\xd1\xde\
wM\xd1\x1cH\xfb\xb4\x97\x13\xf4\xa2ItG7{\
\xe1m\xc2o\xc9\xe4$\x8a/\xb6c\xfaY*\xf6G\
\x0a\x83\xb9\x9f\xd2\x03.\xf3\xcb\xd0\x13\xfb\x0c6\xff\x00\
\xc9\xb1>\xec\
\x00\x00\x00\x95\
Q\
Widget {\x0d\x0a    ba\
ckground-color: \
qlineargradient(\
spread: pad, x1:\
0, y1:0, x2:1, y\
2:0, stop:0 rgba\
(36, 36, 36, 246\
), stop:1 rgba(2\
4, 24, 24, 246))\
;\x0d\x0a}\
\x00\x00\x01%\
C\
heckBoxBase {\x0d\x0a \
   background-co\
lor: transparent\
;\x0d\x0a}\x0d\x0aCheckBoxBa\
se::indicator {\x0d\
\x0a    background-\
color: transpare\
nt;\x0d\x0a    border:\
 none;\x0d\x0a}\x0d\x0a\x0d\x0aChe\
ckBoxBase QLabel\
 {\x0d\x0a    color: w\
hite;\x0d\x0a    backg\
round-color: tra\
nsparent;\x0d\x0a    b\
order: none;\x0d\x0a}\x0d\
\x0aCheckBoxBase QL\
abel:disabled {\x0d\
\x0a    color: grey\
;\x0d\x0a}\
\x00\x00\x01X\
T\
extBrowserBase {\
\x0d\x0a    color: rgb\
(210, 222, 234);\
\x0d\x0a\x09text-align: l\
eft;\x0d\x0a\x09selection\
-background-colo\
r: darkgrey;\x0d\x0a\x09b\
ackground-color:\
 transparent;\x0d\x0a \
   padding: 1.2p\
x;\x0d\x0a\x09border: non\
e;\x0d\x0a\x09border-radi\
us: 3px;\x0d\x0a}\x0d\x0aTex\
tBrowserBase[isB\
orderless=false]\
 {\x0d\x0a    padding:\
 0px;\x0d\x0a    borde\
r: 1.2px solid r\
gba(201, 210, 22\
2, 123);\x0d\x0a}\x0d\x0aTex\
tBrowserBase:hov\
er {\x0d\x0a}\
\x00\x00\x01\xd5\
T\
oolBoxBase {\x0d\x0a  \
  background-col\
or: transparent;\
\x0d\x0a    padding: 0\
px;\x0d\x0a    border:\
 none;\x0d\x0a\x09border-\
radius: 3px;\x0d\x0a}\x0d\
\x0a\x0d\x0aToolPage {\x0d\x0a\x09\
background-color\
: transparent;\x0d\x0a\
    border: none\
;\x0d\x0a}\x0d\x0a\x0d\x0aToolPage\
 Folder {\x0d\x0a    c\
olor: rgb(210, 2\
22, 234);\x0d\x0a\x09text\
-align: left;\x0d\x0a\x09\
background-color\
: transparent;\x0d\x0a\
\x09padding-top: 3p\
x;\x0d\x0a\x09padding-lef\
t: 12px;\x0d\x0a\x09paddi\
ng-bottom: 3px;\x0d\
\x0a\x09padding-right:\
 6px;\x0d\x0a    borde\
r: none;\x0d\x0a}\x0d\x0aToo\
lPage Folder:hov\
er {\x0d\x0a\x09backgroun\
d-color: rgba(20\
1, 210, 222, 12)\
;\x0d\x0a}\
\x00\x00\x01|\
C\
hatWidgetBase {\x0d\
\x0a    background-\
color: transpare\
nt;\x0d\x0a    border:\
 none;\x0d\x0a\x09border-\
radius: 3px;\x0d\x0a}\x0d\
\x0aChatWidgetBase:\
hover {\x0d\x0a}\x0d\x0a\x0d\x0aCh\
atWidgetBase QWi\
dget {\x0d\x0a    back\
ground-color: tr\
ansparent;\x0d\x0a    \
border: none;\x0d\x0a}\
\x0d\x0aChatWidgetBase\
 QWidget:hover {\
\x0d\x0a}\x0d\x0a\x0d\x0aChatWidge\
tBase MessageDis\
play {\x0d\x0a    back\
ground-color: tr\
ansparent;\x0d\x0a    \
padding: 12px;\x0d\x0a\
}\x0d\x0aChatWidgetBas\
e MessageDisplay\
:hover {\x0d\x0a}\
\x00\x00\x02h\
L\
istBase {\x0d\x0a\x09back\
ground-color: tr\
ansparent;\x0d\x0a    \
padding: 1.2px;\x0d\
\x0a\x09border: none;\x0d\
\x0a\x09border-radius:\
 3px;\x0d\x0a    outli\
ne: none;\x0d\x0a}\x0d\x0aLi\
stBase[isBorderl\
ess=false] {\x0d\x0a  \
  padding: 0px;\x0d\
\x0a    border: 1.2\
px solid rgba(20\
1, 210, 222, 123\
);\x0d\x0a}\x0d\x0aListBase:\
hover {\x0d\x0a    bor\
der-color: rgba(\
201, 210, 222, 2\
10);\x0d\x0a}\x0d\x0a\x0d\x0aListB\
ase::item {\x0d\x0a   \
 color: rgb(210,\
 222, 234);\x0d\x0a\x09ba\
ckground-color: \
transparent;\x0d\x0a  \
  border: 2.4px \
solid transparen\
t;\x0d\x0a\x09padding: 2.\
4px;\x0d\x0a}\x0d\x0aListBas\
e::item:hover {\x0d\
\x0a\x09background-col\
or: rgba(201, 21\
0, 222, 33);\x0d\x0a}\x0d\
\x0aListBase::item:\
selected {\x0d\x0a\x09bac\
kground-color: t\
ransparent;\x0d\x0a\x09bo\
rder-left-color:\
 rgb(120, 180, 2\
40);\x0d\x0a}\
\x00\x00\x03I\
L\
ineEditBase, Tex\
tEditBase {\x0d\x0a   \
 color: rgb(210,\
 222, 234);\x0d\x0a\x09te\
xt-align: left;\x0d\
\x0a\x09selection-back\
ground-color: da\
rkgrey;\x0d\x0a    bac\
kground-color: r\
gba(246, 246, 24\
6, 18);\x0d\x0a    pad\
ding: 4.8px 12px\
 6px 12px;\x0d\x0a    \
border: 1.2px so\
lid rgba(210, 22\
2, 234, 12);\x0d\x0a  \
  border-bottom:\
 1.2px solid rgb\
a(210, 222, 234,\
 48);\x0d\x0a\x09border-r\
adius: 3px;\x0d\x0a   \
 outline: none;\x0d\
\x0a}\x0d\x0aLineEditBase\
[isBorderless=tr\
ue], TextEditBas\
e[isBorderless=t\
rue] {\x0d\x0a    padd\
ing: 1.2px;\x0d\x0a\x09bo\
rder: none;\x0d\x0a}\x0d\x0a\
LineEditBase[isT\
ransparent=true]\
, TextEditBase[i\
sTransparent=tru\
e] {\x0d\x0a\x09backgroun\
d-color: transpa\
rent;\x0d\x0a}\x0d\x0aLineEd\
itBase:hover, Te\
xtEditBase:hover\
 {\x0d\x0a\x09background-\
color: rgba(246,\
 246, 246, 24);\x0d\
\x0a}\x0d\x0aLineEditBase\
:focus, TextEdit\
Base:focus {\x0d\x0a  \
  border-bottom-\
color: rgba(120,\
 180, 240, 246);\
\x0d\x0a}\x0d\x0aLineEditBas\
e:disabled, Text\
EditBase:disable\
d {\x0d\x0a\x09color: rgb\
a(201, 210, 222,\
 90);\x0d\x0a}\
\x00\x00\x01K\
\x00\
\x00\x06\x0dx\xda\xc5S\xd1N\x830\x14}\x96\x84\x7f\
\xe8\xe3\x96\x88\x81BL\xec\xbeb\xf1\x0b\x0amJ#\
R\xd2\xc265\xfbw\xaf\xdb\x0an\xd0\x8a\xd3(\x0f\
7\xa4\xb9=\xa7\xe7\x9e{\xd6\x8f\x95d\x5c\x93Ri\
\xf9\xaa\xea\x96V\xe8-\x0c\x10|%\x97\xa2l\x09\xc2\
Y\xb3[\x85\xc1>\x0c\xc2`}\xea&B+\xb5\xe1\
\x9e[\xe9\xe1\xd2\xc7IN\x8b'h\xefj\x16\x15\xaa\
R\x9a -r\xbaHpz\x8b\x86\x82\x93xi/\
(\x0d\x1c\x91\xa6Lv\xc6\x22\xed}\xe4\x84IC\xf3\
\x8a3\xfb\x8ay\x9cP\x96#e\xa6\xcb\xa3\x86\x8a)\
m\x03*A\xdbR\xb6|\xe5\xd4\xec\x90\xf0\x89\xa7\xa4\
5\xab\xa6X\xb6\x92\xb5%\x8c=\xee\xd1.\x9c\xb8\x99\
T\xb7\xc0\xd9=\x8c\xf1T\xcegIPr\x87\x9b\x1d\
2\x0a\xc8\x8f\xcdI\x0c}\x18CI3\xc7\xe0\x93\xe1\
\x05\xcfT\x0bY\x13\x14=\x00J<2d\xa4\x05~\
7\x5c\xbb\xdd\xb0\xd3\xf3\x834\x9a\x1b\xe33u\x1e\xcc\
\xd7\xcb!4\x7f\xb1\x06\x0dP\xa0\xa0\x95\xc5\xd8\x18O\
\x1e\x1cW\xfe \x0c\x96\xf97\xa3@\x19;F\xe1R\
\x96+\x08c\xb9\xb3s\xe0\x1f\xf6Y\x0a\xe2\xffN\x01\
\x9c\x1c\x920\xbdy\xbd\x13\xd7g\xa0\x87\xf8I\x02\xbe\
\xb1\x11v\xff\xdf\x01?\x9f\xd4\xd5\
\x00\x00\x06\x86\
C\
omboBoxBase {\x0d\x0a \
   color: rgb(21\
0, 222, 234);\x0d\x0a\x09\
text-align: left\
;\x0d\x0a\x09selection-ba\
ckground-color: \
darkgrey;\x0d\x0a\x09back\
ground-color: rg\
ba(246, 246, 246\
, 18);\x0d\x0a    padd\
ing: 4.8px 12px \
6px 12px;\x0d\x0a    b\
order: 1.2px sol\
id rgba(210, 222\
, 234, 12);\x0d\x0a   \
 border-bottom: \
1.2px solid rgba\
(210, 222, 234, \
48);\x0d\x0a\x09border-ra\
dius: 3px;\x0d\x0a    \
outline: none;\x0d\x0a\
}\x0d\x0aComboBoxBase[\
isBorderless=tru\
e] {\x0d\x0a    paddin\
g: 1.2px;\x0d\x0a\x09bord\
er: none;\x0d\x0a}\x0d\x0aCo\
mboBoxBase[isTra\
nsparent=true] {\
\x0d\x0a\x09background-co\
lor: transparent\
;\x0d\x0a}\x0d\x0aComboBoxBa\
se:hover {\x0d\x0a\x09bac\
kground-color: r\
gba(246, 246, 24\
6, 24);\x0d\x0a}\x0d\x0aComb\
oBoxBase:focus {\
\x0d\x0a    border-bot\
tom-color: rgba(\
120, 180, 240, 2\
46);\x0d\x0a}\x0d\x0aComboBo\
xBase:disabled {\
\x0d\x0a\x09color: rgba(2\
10, 222, 234, 90\
);\x0d\x0a}\x0d\x0a\x0d\x0aComboBo\
xBase::drop-down\
 {\x0d\x0a\x09subcontrol-\
origin: padding;\
\x0d\x0a\x09subcontrol-po\
sition: right;\x0d\x0a\
\x09margin-right: 6\
px;\x0d\x0a\x09border: no\
ne;\x0d\x0a}\x0d\x0a\x0d\x0aComboB\
oxBase::down-arr\
ow {\x0d\x0a\x09border-im\
age: url(:/Icons\
/icons/dark/Chev\
ron-Down.svg);\x0d\x0a\
}\x0d\x0aComboBoxBase:\
:down-arrow:on {\
\x0d\x0a\x09border-image:\
 url(:Icons/icon\
s/dark/Chevron-U\
p.svg);\x0d\x0a}\x0d\x0a\x0d\x0a\x0d\x0a\
ComboBoxBase QAb\
stractItemView {\
\x0d\x0a\x09background-co\
lor: black;\x0d\x0a\x09bo\
rder: 1.2px soli\
d rgba(201, 210,\
 222, 123);\x0d\x0a\x09ou\
tline: none;\x0d\x0a}\x0d\
\x0aComboBoxBase QA\
bstractItemView[\
isBorderless=tru\
e] {\x0d\x0a    paddin\
g: 1.2px;\x0d\x0a\x09bord\
er: none;\x0d\x0a}\x0d\x0aCo\
mboBoxBase QAbst\
ractItemView[isT\
ransparent=true]\
 {\x0d\x0a\x09background-\
color: transpare\
nt;\x0d\x0a}\x0d\x0a\x0d\x0aComboB\
oxBase QAbstract\
ItemView::item {\
\x0d\x0a    color: rgb\
(210, 222, 234);\
\x0d\x0a\x09background-co\
lor: rgba(210, 2\
22, 234, 15);\x0d\x0a\x09\
padding: 3px 6px\
;\x0d\x0a\x09border: none\
;\x0d\x0a}\x0d\x0aComboBoxBa\
se QAbstractItem\
View::item:hover\
 {\x0d\x0a\x09background-\
color: rgba(123,\
 123, 123, 123);\
\x0d\x0a}\x0d\x0aComboBoxBas\
e QAbstractItemV\
iew::item:select\
ed {\x0d\x0a\x09backgroun\
d-color: rgba(12\
3, 123, 123, 123\
);\x0d\x0a}\
\x00\x00\x01\xcc\
G\
roupBoxBase {\x0d\x0a \
   color: rgb(21\
0, 222, 234);\x0d\x0a\x09\
margin-top: 1.5e\
x;\x0d\x0a\x09background-\
color: transpare\
nt;\x0d\x0a\x09border: 1.\
2px solid transp\
arent;\x0d\x0a\x09border-\
radius: 3px;\x0d\x0a}\x0d\
\x0a\x0d\x0aGroupBoxBase:\
:title {\x0d\x0a\x09subco\
ntrol-origin: ma\
rgin;\x0d\x0a\x09subcontr\
ol-position: top\
 left;\x0d\x0a\x09padding\
: 3px;\x0d\x0a}\x0d\x0a\x0d\x0aGro\
upBoxBase::indic\
ator:checked {\x0d\x0a\
\x09border-image: u\
rl(:/Icons/icons\
/dark/Chevron-Do\
wn.svg);\x0d\x0a}\x0d\x0aGro\
upBoxBase::indic\
ator:unchecked {\
\x0d\x0a\x09border-image:\
 url(:/Icons/ico\
ns/dark/Chevron-\
Up.svg);\x0d\x0a}\
\x00\x00\x00\xf0\
S\
crollAreaBase {\x0d\
\x0a\x09border: 0px so\
lid;\x0d\x0a\x09border-ra\
dius: 3px;\x0d\x0a}\x0d\x0aS\
crollAreaBase[is\
Borderless=true]\
 {\x0d\x0a    padding:\
 1.2px;\x0d\x0a\x09border\
: none;\x0d\x0a}\x0d\x0aScro\
llAreaBase[isTra\
nsparent=true] {\
\x0d\x0a\x09background-co\
lor: transparent\
;\x0d\x0a}\x0d\x0aScrollArea\
Base:hover {\x0d\x0a}\
\x00\x00\x00\xa4\
L\
abelBase {\x0d\x0a    \
color: rgb(210, \
222, 234);\x0d\x0a    \
background-color\
: transparent;\x0d\x0a\
    padding: 0px\
;\x0d\x0a    border: n\
one;\x0d\x0a\x09border-ra\
dius: 3px;\x0d\x0a}\x0d\x0aL\
abelBase:hover {\
\x0d\x0a}\
\x00\x00\x02'\
Q\
TabWidget::tab-b\
ar {\x0d\x0a    alignm\
ent: left;\x0d\x0a}\x0d\x0a\x0d\
\x0a\x0d\x0aQTabBar::tab \
{\x0d\x0a    color: rg\
b(210, 222, 234)\
;\x0d\x0a\x09background-c\
olor: rgba(246, \
246, 246, 18);\x0d\x0a\
    padding: 2.4\
px 4.8px;\x0d\x0a    b\
order: 1.2px sol\
id rgba(210, 222\
, 234, 12);\x0d\x0a}\x0d\x0a\
QTabBar::tab[isB\
orderless=true] \
{\x0d\x0a    padding: \
3.6px 6.0px;\x0d\x0a\x09b\
order: none;\x0d\x0a}\x0d\
\x0aQTabBar::tab:ho\
ver {\x0d\x0a\x09backgrou\
nd-color: rgba(2\
46, 246, 246, 24\
);\x0d\x0a}\x0d\x0aQTabBar::\
tab:selected {\x0d\x0a\
\x09background-colo\
r: rgba(246, 246\
, 246, 30);\x0d\x0a}\x0d\x0a\
\x0d\x0a\x0d\x0aQTabWidget::\
pane {\x0d\x0a\x09backgro\
und: transparent\
;\x0d\x0a    border: 1\
.2px solid rgba(\
210, 222, 234, 1\
2);\x0d\x0a}\
\x00\x00\x02\x8b\
Q\
TreeView {\x0d\x0a\x09bac\
kground-color: t\
ransparent;\x0d\x0a   \
 outline: none;\x0d\
\x0a\x09border: none;\x0d\
\x0a\x09border-radius:\
 3px;\x0d\x0a}\x0d\x0a\x0d\x0aQTre\
eView::item {\x0d\x0a \
   color: rgb(21\
0, 222, 234);\x0d\x0a\x09\
background-color\
: transparent;\x0d\x0a\
\x09padding: 3px;\x0d\x0a\
\x09border: none;\x0d\x0a\
\x09border-radius: \
3px;\x0d\x0a}\x0d\x0aQTreeVi\
ew::item:hover {\
\x0d\x0a\x09background-co\
lor: rgba(201, 2\
10, 222, 33);\x0d\x0a}\
\x0d\x0aQTreeView::ite\
m:selected {\x0d\x0a}\x0d\
\x0a\x0d\x0aQTreeView::br\
anch {\x0d\x0a    back\
ground-color: tr\
ansparent;\x0d\x0a\x09bor\
der: none;\x0d\x0a}\x0d\x0aQ\
TreeView::branch\
:open:has-childr\
en {\x0d\x0a\x09image: ur\
l(:/Icons/icons/\
dark/Chevron-Dow\
n.svg);\x0d\x0a\x09paddin\
g: 3px;\x0d\x0a}\x0d\x0aQTre\
eView::branch:cl\
osed:has-childre\
n {\x0d\x0a\x09image: url\
(:/Icons/icons/d\
ark/Chevron-Righ\
t.svg);\x0d\x0a\x09paddin\
g: 3px;\x0d\x0a}\
\x00\x00\x01R\
\x00\
\x00\x04hx\xda\x95SMk\xc3 \x18>'\x90\xff\
\xe0q\x85\xa64\xa6\x94\xe1\xd8%\xb0cac\xbb\x8d\
\x1dL\x95Df4\xa8\xd9'\xfd\xefs\xa6\xa9i\xb2\
\xb0\xd4\x83\xc8\xcb\xeb\xf3\xf5\xea\x8e\x12\x86\xef9\xfe\xa4\
*\xc3\x9a\x82\xef(\x04v\xd5\x98\x10&\x0a\x046\xab\
\xeb\xfa\x03$\xd0n\xdb\xe3\xe1&\x0a\x0fQ\xb8;\xbf\
\xf8\xcct&\x15\xa1\x8aS\xado\x8dj\xe8\xcb\x08+\
Y\xb5\xb7\x83\xdcu\x22 \xa4\xa0ShO\x0a\x0b]\
cE\x85\xf1pA\x8e\xf7\xaf\x85\x92\x8d \xf1^r\
i1\x8c\xefk\xa1F` k\x8c\x91\xa2o\xef?\
\x18\xd7s.\xd2\x97b\x85\x09k4\x9a\x0e\xa3\xc7\x88\
J\xf9F\xd54\xaf*r|\x05\xd7\xc9\x12\xc0dm\
7\x08\x97 M\x17\x9d\x951\xf4\xc3#g\xbf\xba\x90\
\xc5\xb1\xd0\x16_\xb1/)\x0c\xe6.\xa0\x92\xb2\xa24\
\xfd\xacgQ&\xd0q\x0e'\x13\x0c\x1co\xa7\x0cO\
\xab\xf2\x01\xcc\x94bO\x8b\xa9I\x9ehJ,\x08\x1f\
\x99\x7fg\xc4\x94\xa7\xb9\xf8,.\x8a\xe2\xc8\x1fTX\
\x15L\xc4F\xd6\x08\xc4\xad\xf1\xae\x96K;\xde\xca\x97\
\xbb\xd4\x5c\xe8@K+r\xf0\xa0.\x0fr\xe4pF\
\x90\xdeC\xbaq[\xef\x1d\xddU9%\x84\x92\x1e\xe1\
\xac\x1f5\xf7\x07\xff\x81\x8f\xc0I\xf2\xe1\x07o\x10b\
\x05\
\x00\x00\x01=\
T\
oolTipBase {\x0d\x0a  \
  background-col\
or: rgba(246, 24\
6, 246, 18);\x0d\x0a  \
  border: 1.2px \
solid rgba(210, \
222, 234, 12);\x0d\x0a\
    border-radiu\
s: 3px;\x0d\x0a}\x0d\x0aTool\
TipBase[isTransp\
arent=true] {\x0d\x0a \
   background-co\
lor: transparent\
;\x0d\x0a}\x0d\x0a\x0d\x0a\x0d\x0aQLabel\
 {\x0d\x0a    color: r\
gb(210, 222, 234\
);\x0d\x0a    backgrou\
nd-color: transp\
arent;\x0d\x0a    bord\
er: none;\x0d\x0a}\
\x00\x00\x03\xb4\
M\
enuBase {\x0d\x0a    b\
ackground-color:\
 transparent;\x0d\x0a \
   border: none;\
\x0d\x0a}\x0d\x0a\x0d\x0aMenuActio\
nListWidget {\x0d\x0a \
   font: 12px --\
FontFamilies;\x0d\x0a \
   background-co\
lor: rgba(246, 2\
46, 246, 18);\x0d\x0a \
   border: 1.2px\
 solid rgba(210,\
 222, 234, 12);\x0d\
\x0a    border-radi\
us: 3px;\x0d\x0a    ou\
tline: none;\x0d\x0a}\x0d\
\x0aMenuActionListW\
idget[transparen\
t=true] {\x0d\x0a    b\
ackground-color:\
 transparent;\x0d\x0a}\
\x0d\x0a\x0d\x0aMenuActionLi\
stWidget::item {\
\x0d\x0a    padding-le\
ft: 9px;\x0d\x0a    pa\
dding-right: 9px\
;\x0d\x0a    border-ra\
dius: 3px;\x0d\x0a    \
margin-left: 6px\
;\x0d\x0a    margin-ri\
ght: 6px;\x0d\x0a    c\
olor: rgb(210, 2\
22, 234);\x0d\x0a    b\
order: none;\x0d\x0a}\x0d\
\x0aMenuActionListW\
idget::item:hove\
r {\x0d\x0a    backgro\
und-color: rgba(\
246, 246, 246, 2\
4);\x0d\x0a}\x0d\x0aMenuActi\
onListWidget::it\
em:selected {\x0d\x0a \
   color: rgba(2\
10, 222, 234, 12\
3);\x0d\x0a    backgro\
und-color: rgba(\
120, 180, 240, 2\
46);\x0d\x0a}\x0d\x0aMenuAct\
ionListWidget::i\
tem:disabled {\x0d\x0a\
    padding-left\
: 9px;\x0d\x0a    padd\
ing-right: 9px;\x0d\
\x0a    border-radi\
us: 3px;\x0d\x0a    co\
lor: rgba(210, 2\
22, 234, 90);\x0d\x0a \
   border: none;\
\x0d\x0a}\
\x00\x00\x01\x08\
Q\
DockWidget {\x0d\x0a  \
  border: none;\x0d\
\x0a}\x0d\x0aQDockWidget[\
isBorderless=fal\
se] {\x0d\x0a    paddi\
ng: 0px;\x0d\x0a    bo\
rder: 1.2px soli\
d rgba(201, 210,\
 222, 123);\x0d\x0a}\x0d\x0a\
QDockWidget[isTr\
ansparent=true] \
{\x0d\x0a\x09background-c\
olor: transparen\
t;\x0d\x0a}\x0d\x0a\x0d\x0aQDockWi\
dget::title {\x0d\x0a \
   text-align: l\
eft;\x0d\x0a}\
\x00\x00\x03\xbc\
Q\
HeaderView {\x0d\x0a  \
  background-col\
or: transparent;\
\x0d\x0a}\x0d\x0a\x0d\x0aQHeaderVi\
ew::section {\x0d\x0a \
   color: rgb(21\
0, 222, 234);\x0d\x0a\x09\
background-color\
: transparent;\x0d\x0a\
    padding: 2.4\
px 4.8px;\x0d\x0a    b\
order: 1.2px sol\
id rgba(201, 210\
, 222, 123);\x0d\x0a}\x0d\
\x0aQHeaderView::se\
ction:horizontal\
 {\x0d\x0a    border-t\
op: none;\x0d\x0a    b\
order-left: none\
;\x0d\x0a}\x0d\x0aQHeaderVie\
w::section:verti\
cal {\x0d\x0a    borde\
r-top: none;\x0d\x0a}\x0d\
\x0a\x0d\x0a\x0d\x0aQTableView \
{\x0d\x0a\x09background-c\
olor: transparen\
t;\x0d\x0a    selectio\
n-background-col\
or: transparent;\
\x0d\x0a    gridline-c\
olor: rgba(201, \
210, 222, 123);\x0d\
\x0a\x09border: 1.2px \
solid rgba(201, \
210, 222, 123);\x0d\
\x0a\x09border-radius:\
 3px;\x0d\x0a    outli\
ne: none;\x0d\x0a}\x0d\x0aQT\
ableView[isBorde\
rless=true] {\x0d\x0a \
   padding: 1.2p\
x;\x0d\x0a\x09border: non\
e;\x0d\x0a}\x0d\x0a\x0d\x0aQTableV\
iew::item {\x0d\x0a   \
 color: rgb(210,\
 222, 234);\x0d\x0a   \
 padding: 3px 6p\
x;\x0d\x0a    border: \
0px solid rgba(2\
01, 210, 222, 12\
3);\x0d\x0a\x09border-bot\
tom-width: 1.2px\
;\x0d\x0a}\x0d\x0aQTableView\
::item::selected\
 {\x0d\x0a\x09border-colo\
r: rgba(201, 210\
, 222, 210);\x0d\x0a}\x0d\
\x0aQTableView::ite\
m:!alternate:!se\
lected {\x0d\x0a}\
\x00\x00\x05\x9c\
S\
pinBoxBase, Doub\
leSpinBoxBase {\x0d\
\x0a    color: rgb(\
210, 222, 234);\x0d\
\x0a\x09text-align: le\
ft;\x0d\x0a\x09selection-\
background-color\
: darkgrey;\x0d\x0a\x09ba\
ckground-color: \
rgba(246, 246, 2\
46, 18);\x0d\x0a    pa\
dding: 4.8px 12p\
x 6px 12px;\x0d\x0a   \
 border: 1.2px s\
olid rgba(201, 2\
10, 222, 12);\x0d\x0a \
   border-bottom\
: 1.2px solid rg\
ba(201, 210, 222\
, 48);\x0d\x0a\x09border-\
radius: 3px;\x0d\x0a  \
  outline: none;\
\x0d\x0a}\x0d\x0aSpinBoxBase\
[isBorderless=tr\
ue] DoubleSpinBo\
xBase[isBorderle\
ss=true] {\x0d\x0a    \
padding: 1.2px;\x0d\
\x0a\x09border: none;\x0d\
\x0a}\x0d\x0aSpinBoxBase[\
isTransparent=tr\
ue] DoubleSpinBo\
xBase[isBorderle\
ss=true] {\x0d\x0a\x09bac\
kground-color: t\
ransparent;\x0d\x0a}\x0d\x0a\
SpinBoxBase:hove\
r, DoubleSpinBox\
Base:hover {\x0d\x0a\x09b\
ackground-color:\
 rgba(246, 246, \
246, 24);\x0d\x0a}\x0d\x0aSp\
inBoxBase:focus,\
 DoubleSpinBoxBa\
se:focus {\x0d\x0a    \
border-bottom-co\
lor: rgba(120, 1\
80, 240, 246);\x0d\x0a\
}\x0d\x0aSpinBoxBase:d\
isabled, DoubleS\
pinBoxBase:disab\
led {\x0d\x0a\x09color: r\
gba(201, 210, 22\
2, 90);\x0d\x0a}\x0d\x0a\x0d\x0aSp\
inBoxBase::up-bu\
tton, DoubleSpin\
BoxBase::up-butt\
on {\x0d\x0a\x09subcontro\
l-origin: paddin\
g;\x0d\x0a\x09subcontrol-\
position: top ri\
ght;\x0d\x0a\x09margin-ri\
ght: 4.5px;\x0d\x0a\x09bo\
rder-width: 0px;\
\x0d\x0a}\x0d\x0aSpinBoxBase\
::up-arrow, Doub\
leSpinBoxBase::u\
p-arrow {\x0d\x0a\x09bord\
er-image: url(:/\
Icons/icons/dark\
/Chevron-Up.svg)\
;\x0d\x0a}\x0d\x0a\x0d\x0aSpinBoxB\
ase::down-button\
, DoubleSpinBoxB\
ase::down-button\
 {\x0d\x0a\x09subcontrol-\
origin: padding;\
\x0d\x0a\x09subcontrol-po\
sition: bottom r\
ight;\x0d\x0a\x09margin-r\
ight: 4.5px;\x0d\x0a\x09b\
order-width: 0px\
;\x0d\x0a}\x0d\x0aSpinBoxBas\
e::down-arrow, D\
oubleSpinBoxBase\
::down-arrow {\x0d\x0a\
\x09border-image: u\
rl(:/Icons/icons\
/dark/Chevron-Do\
wn.svg);\x0d\x0a}\
\x00\x00\x02!\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-fullscreen-exi\
t\x22 viewBox=\x220 0 \
16 16\x22>\x0d\x0a  <path\
 d=\x22M5.5 0a.5.5 \
0 0 1 .5.5v4A1.5\
 1.5 0 0 1 4.5 6\
h-4a.5.5 0 0 1 0\
-1h4a.5.5 0 0 0 \
.5-.5v-4a.5.5 0 \
0 1 .5-.5m5 0a.5\
.5 0 0 1 .5.5v4a\
.5.5 0 0 0 .5.5h\
4a.5.5 0 0 1 0 1\
h-4A1.5 1.5 0 0 \
1 10 4.5v-4a.5.5\
 0 0 1 .5-.5M0 1\
0.5a.5.5 0 0 1 .\
5-.5h4A1.5 1.5 0\
 0 1 6 11.5v4a.5\
.5 0 0 1-1 0v-4a\
.5.5 0 0 0-.5-.5\
h-4a.5.5 0 0 1-.\
5-.5m10 1a1.5 1.\
5 0 0 1 1.5-1.5h\
4a.5.5 0 0 1 0 1\
h-4a.5.5 0 0 0-.\
5.5v4a.5.5 0 0 1\
-1 0z\x22/>\x0d\x0a</svg>\
\
\x00\x00\x01m\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-send\x22 viewBox=\
\x220 0 16 16\x22>\x0d\x0a  \
<path d=\x22M15.854\
.146a.5.5 0 0 1 \
.11.54l-5.819 14\
.547a.75.75 0 0 \
1-1.329.124l-3.1\
78-4.995L.643 7.\
184a.75.75 0 0 1\
 .124-1.33L15.31\
4.037a.5.5 0 0 1\
 .54.11ZM6.636 1\
0.07l2.761 4.338\
L14.13 2.576zm6.\
787-8.201L1.591 \
6.602l4.339 2.76\
z\x22/>\x0d\x0a</svg>\
\x00\x00\x012\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-chevron-compac\
t-right\x22 viewBox\
=\x220 0 16 16\x22>\x0d\x0a \
 <path fill-rule\
=\x22evenodd\x22 d=\x22M6\
.776 1.553a.5.5 \
0 0 1 .671.223l3\
 6a.5.5 0 0 1 0 \
.448l-3 6a.5.5 0\
 1 1-.894-.448L9\
.44 8 6.553 2.22\
4a.5.5 0 0 1 .22\
3-.671\x22/>\x0d\x0a</svg\
>\
\x00\x00\x01\x10\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-chevron-up\x22 vi\
ewBox=\x220 0 16 16\
\x22>\x0d\x0a  <path fill\
-rule=\x22evenodd\x22 \
d=\x22M7.646 4.646a\
.5.5 0 0 1 .708 \
0l6 6a.5.5 0 0 1\
-.708.708L8 5.70\
7l-5.646 5.647a.\
5.5 0 0 1-.708-.\
708z\x22/>\x0d\x0a</svg>\
\x00\x00\x01[\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-play-circle\x22 v\
iewBox=\x220 0 16 1\
6\x22>\x0d\x0a  <path d=\x22\
M8 15A7 7 0 1 1 \
8 1a7 7 0 0 1 0 \
14m0 1A8 8 0 1 0\
 8 0a8 8 0 0 0 0\
 16\x22/>\x0d\x0a  <path \
d=\x22M6.271 5.055a\
.5.5 0 0 1 .52.0\
38l3.5 2.5a.5.5 \
0 0 1 0 .814l-3.\
5 2.5A.5.5 0 0 1\
 6 10.5v-5a.5.5 \
0 0 1 .271-.445\x22\
/>\x0d\x0a</svg>\
\x00\x00\x01\xa2\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-scissors\x22 view\
Box=\x220 0 16 16\x22>\
\x0a  <path d=\x22M3.5\
 3.5c-.614-.884-\
.074-1.962.858-2\
.5L8 7.226 11.64\
2 1c.932.538 1.4\
72 1.616.858 2.5\
L8.81 8.61l1.556\
 2.661a2.5 2.5 0\
 1 1-.794.637L8 \
9.73l-1.572 2.17\
7a2.5 2.5 0 1 1-\
.794-.637L7.19 8\
.61zm2.5 10a1.5 \
1.5 0 1 0-3 0 1.\
5 1.5 0 0 0 3 0m\
7 0a1.5 1.5 0 1 \
0-3 0 1.5 1.5 0 \
0 0 3 0\x22/>\x0a</svg\
>\
\x00\x00\x02=\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-arrow-repeat\x22 \
viewBox=\x220 0 16 \
16\x22>\x0d\x0a  <path d=\
\x22M11.534 7h3.932\
a.25.25 0 0 1 .1\
92.41l-1.966 2.3\
6a.25.25 0 0 1-.\
384 0l-1.966-2.3\
6a.25.25 0 0 1 .\
192-.41m-11 2h3.\
932a.25.25 0 0 0\
 .192-.41L2.692 \
6.23a.25.25 0 0 \
0-.384 0L.342 8.\
59A.25.25 0 0 0 \
.534 9\x22/>\x0d\x0a  <pa\
th fill-rule=\x22ev\
enodd\x22 d=\x22M8 3c-\
1.552 0-2.94.707\
-3.857 1.818a.5.\
5 0 1 1-.771-.63\
6A6.002 6.002 0 \
0 1 13.917 7H12.\
9A5 5 0 0 0 8 3M\
3.1 9a5.002 5.00\
2 0 0 0 8.757 2.\
182.5.5 0 1 1 .7\
71.636A6.002 6.0\
02 0 0 1 2.083 9\
z\x22/>\x0d\x0a</svg>\
\x00\x00\x01%\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-chevron-left\x22 \
viewBox=\x220 0 16 \
16\x22>\x0d\x0a  <path fi\
ll-rule=\x22evenodd\
\x22 d=\x22M11.354 1.6\
46a.5.5 0 0 1 0 \
.708L5.707 8l5.6\
47 5.646a.5.5 0 \
0 1-.708.708l-6-\
6a.5.5 0 0 1 0-.\
708l6-6a.5.5 0 0\
 1 .708 0\x22/>\x0d\x0a</\
svg>\
\x00\x00\x019\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-x-lg\x22 viewBox=\
\x220 0 16 16\x22>\x0d\x0a  \
<path d=\x22M2.146 \
2.854a.5.5 0 1 1\
 .708-.708L8 7.2\
93l5.146-5.147a.\
5.5 0 0 1 .708.7\
08L8.707 8l5.147\
 5.146a.5.5 0 0 \
1-.708.708L8 8.7\
07l-5.146 5.147a\
.5.5 0 0 1-.708-\
.708L7.293 8z\x22/>\
\x0d\x0a</svg>\
\x00\x00\x03\x08\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-cloud-download\
\x22 viewBox=\x220 0 1\
6 16\x22>\x0d\x0a  <path \
d=\x22M4.406 1.342A\
5.53 5.53 0 0 1 \
8 0c2.69 0 4.923\
 2 5.166 4.579C1\
4.758 4.804 16 6\
.137 16 7.773 16\
 9.569 14.502 11\
 12.687 11H10a.5\
.5 0 0 1 0-1h2.6\
88C13.979 10 15 \
8.988 15 7.773c0\
-1.216-1.02-2.22\
8-2.313-2.228h-.\
5v-.5C12.188 2.8\
25 10.328 1 8 1a\
4.53 4.53 0 0 0-\
2.941 1.1c-.757.\
652-1.153 1.438-\
1.153 2.055v.448\
l-.445.049C2.064\
 4.805 1 5.952 1\
 7.318 1 8.785 2\
.23 10 3.781 10H\
6a.5.5 0 0 1 0 1\
H3.781C1.708 11 \
0 9.366 0 7.318c\
0-1.763 1.266-3.\
223 2.942-3.593.\
143-.863.698-1.7\
23 1.464-2.383\x22/\
>\x0d\x0a  <path d=\x22M7\
.646 15.854a.5.5\
 0 0 0 .708 0l3-\
3a.5.5 0 0 0-.70\
8-.708L8.5 14.29\
3V5.5a.5.5 0 0 0\
-1 0v8.793l-2.14\
6-2.147a.5.5 0 0\
 0-.708.708z\x22/>\x0d\
\x0a</svg>\
\x00\x00\x01\xee\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-clipboard\x22 vie\
wBox=\x220 0 16 16\x22\
>\x0d\x0a  <path d=\x22M4\
 1.5H3a2 2 0 0 0\
-2 2V14a2 2 0 0 \
0 2 2h10a2 2 0 0\
 0 2-2V3.5a2 2 0\
 0 0-2-2h-1v1h1a\
1 1 0 0 1 1 1V14\
a1 1 0 0 1-1 1H3\
a1 1 0 0 1-1-1V3\
.5a1 1 0 0 1 1-1\
h1z\x22/>\x0d\x0a  <path \
d=\x22M9.5 1a.5.5 0\
 0 1 .5.5v1a.5.5\
 0 0 1-.5.5h-3a.\
5.5 0 0 1-.5-.5v\
-1a.5.5 0 0 1 .5\
-.5zm-3-1A1.5 1.\
5 0 0 0 5 1.5v1A\
1.5 1.5 0 0 0 6.\
5 4h3A1.5 1.5 0 \
0 0 11 2.5v-1A1.\
5 1.5 0 0 0 9.5 \
0z\x22/>\x0d\x0a</svg>\
\x00\x00\x01&\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-chevron-down\x22 \
viewBox=\x220 0 16 \
16\x22>\x0d\x0a  <path fi\
ll-rule=\x22evenodd\
\x22 d=\x22M1.646 4.64\
6a.5.5 0 0 1 .70\
8 0L8 10.293l5.6\
46-5.647a.5.5 0 \
0 1 .708.708l-6 \
6a.5.5 0 0 1-.70\
8 0l-6-6a.5.5 0 \
0 1 0-.708\x22/>\x0d\x0a<\
/svg>\
\x00\x00\x01\x99\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-copy\x22 viewBox=\
\x220 0 16 16\x22>\x0a  <\
path fill-rule=\x22\
evenodd\x22 d=\x22M4 2\
a2 2 0 0 1 2-2h8\
a2 2 0 0 1 2 2v8\
a2 2 0 0 1-2 2H6\
a2 2 0 0 1-2-2zm\
2-1a1 1 0 0 0-1 \
1v8a1 1 0 0 0 1 \
1h8a1 1 0 0 0 1-\
1V2a1 1 0 0 0-1-\
1zM2 5a1 1 0 0 0\
-1 1v8a1 1 0 0 0\
 1 1h8a1 1 0 0 0\
 1-1v-1h1v1a2 2 \
0 0 1-2 2H2a2 2 \
0 0 1-2-2V6a2 2 \
0 0 1 2-2h1v1z\x22/\
>\x0a</svg>\
\x00\x00\x01'\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-chevron-right\x22\
 viewBox=\x220 0 16\
 16\x22>\x0d\x0a  <path f\
ill-rule=\x22evenod\
d\x22 d=\x22M4.646 1.6\
46a.5.5 0 0 1 .7\
08 0l6 6a.5.5 0 \
0 1 0 .708l-6 6a\
.5.5 0 0 1-.708-\
.708L10.293 8 4.\
646 2.354a.5.5 0\
 0 1 0-.708\x22/>\x0d\x0a\
</svg>\
\x00\x00\x01O\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-stop-circle\x22 v\
iewBox=\x220 0 16 1\
6\x22>\x0d\x0a  <path d=\x22\
M8 15A7 7 0 1 1 \
8 1a7 7 0 0 1 0 \
14m0 1A8 8 0 1 0\
 8 0a8 8 0 0 0 0\
 16\x22/>\x0d\x0a  <path \
d=\x22M5 6.5A1.5 1.\
5 0 0 1 6.5 5h3A\
1.5 1.5 0 0 1 11\
 6.5v3A1.5 1.5 0\
 0 1 9.5 11h-3A1\
.5 1.5 0 0 1 5 9\
.5z\x22/>\x0d\x0a</svg>\
\x00\x00\x02p\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-folder2-open\x22 \
viewBox=\x220 0 16 \
16\x22>\x0d\x0a  <path d=\
\x22M1 3.5A1.5 1.5 \
0 0 1 2.5 2h2.76\
4c.958 0 1.76.56\
 2.311 1.184C7.9\
85 3.648 8.48 4 \
9 4h4.5A1.5 1.5 \
0 0 1 15 5.5v.64\
c.57.265.94.876.\
856 1.546l-.64 5\
.124A2.5 2.5 0 0\
 1 12.733 15H3.2\
66a2.5 2.5 0 0 1\
-2.481-2.19l-.64\
-5.124A1.5 1.5 0\
 0 1 1 6.14zM2 6\
h12v-.5a.5.5 0 0\
 0-.5-.5H9c-.964\
 0-1.71-.629-2.1\
74-1.154C6.374 3\
.334 5.82 3 5.26\
4 3H2.5a.5.5 0 0\
 0-.5.5zm-.367 1\
a.5.5 0 0 0-.496\
.562l.64 5.124A1\
.5 1.5 0 0 0 3.2\
66 14h9.468a1.5 \
1.5 0 0 0 1.489-\
1.314l.64-5.124A\
.5.5 0 0 0 14.36\
7 7z\x22/>\x0d\x0a</svg>\
\x00\x00\x01_\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-pause-circle\x22 \
viewBox=\x220 0 16 \
16\x22>\x0d\x0a  <path d=\
\x22M8 15A7 7 0 1 1\
 8 1a7 7 0 0 1 0\
 14m0 1A8 8 0 1 \
0 8 0a8 8 0 0 0 \
0 16\x22/>\x0d\x0a  <path\
 d=\x22M5 6.25a1.25\
 1.25 0 1 1 2.5 \
0v3.5a1.25 1.25 \
0 1 1-2.5 0zm3.5\
 0a1.25 1.25 0 1\
 1 2.5 0v3.5a1.2\
5 1.25 0 1 1-2.5\
 0z\x22/>\x0d\x0a</svg>\
\x00\x00\x01.\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-chevron-compac\
t-left\x22 viewBox=\
\x220 0 16 16\x22>\x0d\x0a  \
<path fill-rule=\
\x22evenodd\x22 d=\x22M9.\
224 1.553a.5.5 0\
 0 1 .223.67L6.5\
6 8l2.888 5.776a\
.5.5 0 1 1-.894.\
448l-3-6a.5.5 0 \
0 1 0-.448l3-6a.\
5.5 0 0 1 .67-.2\
23\x22/>\x0d\x0a</svg>\
\x00\x00\x00\xe6\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-dash-lg\x22 viewB\
ox=\x220 0 16 16\x22>\x0d\
\x0a  <path fill-ru\
le=\x22evenodd\x22 d=\x22\
M2 8a.5.5 0 0 1 \
.5-.5h11a.5.5 0 \
0 1 0 1h-11A.5.5\
 0 0 1 2 8\x22/>\x0d\x0a<\
/svg>\
\x00\x00\x01\x15\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-three-dots\x22 vi\
ewBox=\x220 0 16 16\
\x22>\x0d\x0a  <path d=\x22M\
3 9.5a1.5 1.5 0 \
1 1 0-3 1.5 1.5 \
0 0 1 0 3m5 0a1.\
5 1.5 0 1 1 0-3 \
1.5 1.5 0 0 1 0 \
3m5 0a1.5 1.5 0 \
1 1 0-3 1.5 1.5 \
0 0 1 0 3\x22/>\x0d\x0a</\
svg>\
\x00\x00\x02\x1d\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-fullscreen\x22 vi\
ewBox=\x220 0 16 16\
\x22>\x0d\x0a  <path d=\x22M\
1.5 1a.5.5 0 0 0\
-.5.5v4a.5.5 0 0\
 1-1 0v-4A1.5 1.\
5 0 0 1 1.5 0h4a\
.5.5 0 0 1 0 1zM\
10 .5a.5.5 0 0 1\
 .5-.5h4A1.5 1.5\
 0 0 1 16 1.5v4a\
.5.5 0 0 1-1 0v-\
4a.5.5 0 0 0-.5-\
.5h-4a.5.5 0 0 1\
-.5-.5M.5 10a.5.\
5 0 0 1 .5.5v4a.\
5.5 0 0 0 .5.5h4\
a.5.5 0 0 1 0 1h\
-4A1.5 1.5 0 0 1\
 0 14.5v-4a.5.5 \
0 0 1 .5-.5m15 0\
a.5.5 0 0 1 .5.5\
v4a1.5 1.5 0 0 1\
-1.5 1.5h-4a.5.5\
 0 0 1 0-1h4a.5.\
5 0 0 0 .5-.5v-4\
a.5.5 0 0 1 .5-.\
5\x22/>\x0d\x0a</svg>\
\x00\x00\x01c\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(54, 45, \
33)\x22 class=\x22bi b\
i-arrow-clockwis\
e\x22 viewBox=\x220 0 \
16 16\x22>\x0d\x0a  <path\
 fill-rule=\x22even\
odd\x22 d=\x22M8 3a5 5\
 0 1 0 4.546 2.9\
14.5.5 0 0 1 .90\
8-.417A6 6 0 1 1\
 8 2z\x22/>\x0d\x0a  <pat\
h d=\x22M8 4.466V.5\
34a.25.25 0 0 1 \
.41-.192l2.36 1.\
966c.12.1.12.284\
 0 .384L8.41 4.6\
58A.25.25 0 0 1 \
8 4.466\x22/>\x0d\x0a</sv\
g>\
\x00\x00\x02$\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-fullscreen-\
exit\x22 viewBox=\x220\
 0 16 16\x22>\x0d\x0a  <p\
ath d=\x22M5.5 0a.5\
.5 0 0 1 .5.5v4A\
1.5 1.5 0 0 1 4.\
5 6h-4a.5.5 0 0 \
1 0-1h4a.5.5 0 0\
 0 .5-.5v-4a.5.5\
 0 0 1 .5-.5m5 0\
a.5.5 0 0 1 .5.5\
v4a.5.5 0 0 0 .5\
.5h4a.5.5 0 0 1 \
0 1h-4A1.5 1.5 0\
 0 1 10 4.5v-4a.\
5.5 0 0 1 .5-.5M\
0 10.5a.5.5 0 0 \
1 .5-.5h4A1.5 1.\
5 0 0 1 6 11.5v4\
a.5.5 0 0 1-1 0v\
-4a.5.5 0 0 0-.5\
-.5h-4a.5.5 0 0 \
1-.5-.5m10 1a1.5\
 1.5 0 0 1 1.5-1\
.5h4a.5.5 0 0 1 \
0 1h-4a.5.5 0 0 \
0-.5.5v4a.5.5 0 \
0 1-1 0z\x22/>\x0d\x0a</s\
vg>\
\x00\x00\x01p\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-send\x22 viewB\
ox=\x220 0 16 16\x22>\x0d\
\x0a  <path d=\x22M15.\
854.146a.5.5 0 0\
 1 .11.54l-5.819\
 14.547a.75.75 0\
 0 1-1.329.124l-\
3.178-4.995L.643\
 7.184a.75.75 0 \
0 1 .124-1.33L15\
.314.037a.5.5 0 \
0 1 .54.11ZM6.63\
6 10.07l2.761 4.\
338L14.13 2.576z\
m6.787-8.201L1.5\
91 6.602l4.339 2\
.76z\x22/>\x0d\x0a</svg>\
\x00\x00\x015\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-chevron-com\
pact-right\x22 view\
Box=\x220 0 16 16\x22>\
\x0d\x0a  <path fill-r\
ule=\x22evenodd\x22 d=\
\x22M6.776 1.553a.5\
.5 0 0 1 .671.22\
3l3 6a.5.5 0 0 1\
 0 .448l-3 6a.5.\
5 0 1 1-.894-.44\
8L9.44 8 6.553 2\
.224a.5.5 0 0 1 \
.223-.671\x22/>\x0d\x0a</\
svg>\
\x00\x00\x01\x13\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-chevron-up\x22\
 viewBox=\x220 0 16\
 16\x22>\x0d\x0a  <path f\
ill-rule=\x22evenod\
d\x22 d=\x22M7.646 4.6\
46a.5.5 0 0 1 .7\
08 0l6 6a.5.5 0 \
0 1-.708.708L8 5\
.707l-5.646 5.64\
7a.5.5 0 0 1-.70\
8-.708z\x22/>\x0d\x0a</sv\
g>\
\x00\x00\x01^\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-play-circle\
\x22 viewBox=\x220 0 1\
6 16\x22>\x0d\x0a  <path \
d=\x22M8 15A7 7 0 1\
 1 8 1a7 7 0 0 1\
 0 14m0 1A8 8 0 \
1 0 8 0a8 8 0 0 \
0 0 16\x22/>\x0d\x0a  <pa\
th d=\x22M6.271 5.0\
55a.5.5 0 0 1 .5\
2.038l3.5 2.5a.5\
.5 0 0 1 0 .814l\
-3.5 2.5A.5.5 0 \
0 1 6 10.5v-5a.5\
.5 0 0 1 .271-.4\
45\x22/>\x0d\x0a</svg>\
\x00\x00\x01\xa5\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-scissors\x22 v\
iewBox=\x220 0 16 1\
6\x22>\x0a  <path d=\x22M\
3.5 3.5c-.614-.8\
84-.074-1.962.85\
8-2.5L8 7.226 11\
.642 1c.932.538 \
1.472 1.616.858 \
2.5L8.81 8.61l1.\
556 2.661a2.5 2.\
5 0 1 1-.794.637\
L8 9.73l-1.572 2\
.177a2.5 2.5 0 1\
 1-.794-.637L7.1\
9 8.61zm2.5 10a1\
.5 1.5 0 1 0-3 0\
 1.5 1.5 0 0 0 3\
 0m7 0a1.5 1.5 0\
 1 0-3 0 1.5 1.5\
 0 0 0 3 0\x22/>\x0a</\
svg>\
\x00\x00\x02@\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-arrow-repea\
t\x22 viewBox=\x220 0 \
16 16\x22>\x0d\x0a  <path\
 d=\x22M11.534 7h3.\
932a.25.25 0 0 1\
 .192.41l-1.966 \
2.36a.25.25 0 0 \
1-.384 0l-1.966-\
2.36a.25.25 0 0 \
1 .192-.41m-11 2\
h3.932a.25.25 0 \
0 0 .192-.41L2.6\
92 6.23a.25.25 0\
 0 0-.384 0L.342\
 8.59A.25.25 0 0\
 0 .534 9\x22/>\x0d\x0a  \
<path fill-rule=\
\x22evenodd\x22 d=\x22M8 \
3c-1.552 0-2.94.\
707-3.857 1.818a\
.5.5 0 1 1-.771-\
.636A6.002 6.002\
 0 0 1 13.917 7H\
12.9A5 5 0 0 0 8\
 3M3.1 9a5.002 5\
.002 0 0 0 8.757\
 2.182.5.5 0 1 1\
 .771.636A6.002 \
6.002 0 0 1 2.08\
3 9z\x22/>\x0d\x0a</svg>\
\x00\x00\x01(\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-chevron-lef\
t\x22 viewBox=\x220 0 \
16 16\x22>\x0d\x0a  <path\
 fill-rule=\x22even\
odd\x22 d=\x22M11.354 \
1.646a.5.5 0 0 1\
 0 .708L5.707 8l\
5.647 5.646a.5.5\
 0 0 1-.708.708l\
-6-6a.5.5 0 0 1 \
0-.708l6-6a.5.5 \
0 0 1 .708 0\x22/>\x0d\
\x0a</svg>\
\x00\x00\x01<\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-x-lg\x22 viewB\
ox=\x220 0 16 16\x22>\x0d\
\x0a  <path d=\x22M2.1\
46 2.854a.5.5 0 \
1 1 .708-.708L8 \
7.293l5.146-5.14\
7a.5.5 0 0 1 .70\
8.708L8.707 8l5.\
147 5.146a.5.5 0\
 0 1-.708.708L8 \
8.707l-5.146 5.1\
47a.5.5 0 0 1-.7\
08-.708L7.293 8z\
\x22/>\x0d\x0a</svg>\
\x00\x00\x03\x0b\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-cloud-downl\
oad\x22 viewBox=\x220 \
0 16 16\x22>\x0d\x0a  <pa\
th d=\x22M4.406 1.3\
42A5.53 5.53 0 0\
 1 8 0c2.69 0 4.\
923 2 5.166 4.57\
9C14.758 4.804 1\
6 6.137 16 7.773\
 16 9.569 14.502\
 11 12.687 11H10\
a.5.5 0 0 1 0-1h\
2.688C13.979 10 \
15 8.988 15 7.77\
3c0-1.216-1.02-2\
.228-2.313-2.228\
h-.5v-.5C12.188 \
2.825 10.328 1 8\
 1a4.53 4.53 0 0\
 0-2.941 1.1c-.7\
57.652-1.153 1.4\
38-1.153 2.055v.\
448l-.445.049C2.\
064 4.805 1 5.95\
2 1 7.318 1 8.78\
5 2.23 10 3.781 \
10H6a.5.5 0 0 1 \
0 1H3.781C1.708 \
11 0 9.366 0 7.3\
18c0-1.763 1.266\
-3.223 2.942-3.5\
93.143-.863.698-\
1.723 1.464-2.38\
3\x22/>\x0d\x0a  <path d=\
\x22M7.646 15.854a.\
5.5 0 0 0 .708 0\
l3-3a.5.5 0 0 0-\
.708-.708L8.5 14\
.293V5.5a.5.5 0 \
0 0-1 0v8.793l-2\
.146-2.147a.5.5 \
0 0 0-.708.708z\x22\
/>\x0d\x0a</svg>\
\x00\x00\x01\xf1\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-clipboard\x22 \
viewBox=\x220 0 16 \
16\x22>\x0d\x0a  <path d=\
\x22M4 1.5H3a2 2 0 \
0 0-2 2V14a2 2 0\
 0 0 2 2h10a2 2 \
0 0 0 2-2V3.5a2 \
2 0 0 0-2-2h-1v1\
h1a1 1 0 0 1 1 1\
V14a1 1 0 0 1-1 \
1H3a1 1 0 0 1-1-\
1V3.5a1 1 0 0 1 \
1-1h1z\x22/>\x0d\x0a  <pa\
th d=\x22M9.5 1a.5.\
5 0 0 1 .5.5v1a.\
5.5 0 0 1-.5.5h-\
3a.5.5 0 0 1-.5-\
.5v-1a.5.5 0 0 1\
 .5-.5zm-3-1A1.5\
 1.5 0 0 0 5 1.5\
v1A1.5 1.5 0 0 0\
 6.5 4h3A1.5 1.5\
 0 0 0 11 2.5v-1\
A1.5 1.5 0 0 0 9\
.5 0z\x22/>\x0d\x0a</svg>\
\
\x00\x00\x01)\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-chevron-dow\
n\x22 viewBox=\x220 0 \
16 16\x22>\x0d\x0a  <path\
 fill-rule=\x22even\
odd\x22 d=\x22M1.646 4\
.646a.5.5 0 0 1 \
.708 0L8 10.293l\
5.646-5.647a.5.5\
 0 0 1 .708.708l\
-6 6a.5.5 0 0 1-\
.708 0l-6-6a.5.5\
 0 0 1 0-.708\x22/>\
\x0d\x0a</svg>\
\x00\x00\x01\x9c\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-copy\x22 viewB\
ox=\x220 0 16 16\x22>\x0a\
  <path fill-rul\
e=\x22evenodd\x22 d=\x22M\
4 2a2 2 0 0 1 2-\
2h8a2 2 0 0 1 2 \
2v8a2 2 0 0 1-2 \
2H6a2 2 0 0 1-2-\
2zm2-1a1 1 0 0 0\
-1 1v8a1 1 0 0 0\
 1 1h8a1 1 0 0 0\
 1-1V2a1 1 0 0 0\
-1-1zM2 5a1 1 0 \
0 0-1 1v8a1 1 0 \
0 0 1 1h8a1 1 0 \
0 0 1-1v-1h1v1a2\
 2 0 0 1-2 2H2a2\
 2 0 0 1-2-2V6a2\
 2 0 0 1 2-2h1v1\
z\x22/>\x0a</svg>\
\x00\x00\x01*\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-chevron-rig\
ht\x22 viewBox=\x220 0\
 16 16\x22>\x0d\x0a  <pat\
h fill-rule=\x22eve\
nodd\x22 d=\x22M4.646 \
1.646a.5.5 0 0 1\
 .708 0l6 6a.5.5\
 0 0 1 0 .708l-6\
 6a.5.5 0 0 1-.7\
08-.708L10.293 8\
 4.646 2.354a.5.\
5 0 0 1 0-.708\x22/\
>\x0d\x0a</svg>\
\x00\x00\x01R\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-stop-circle\
\x22 viewBox=\x220 0 1\
6 16\x22>\x0d\x0a  <path \
d=\x22M8 15A7 7 0 1\
 1 8 1a7 7 0 0 1\
 0 14m0 1A8 8 0 \
1 0 8 0a8 8 0 0 \
0 0 16\x22/>\x0d\x0a  <pa\
th d=\x22M5 6.5A1.5\
 1.5 0 0 1 6.5 5\
h3A1.5 1.5 0 0 1\
 11 6.5v3A1.5 1.\
5 0 0 1 9.5 11h-\
3A1.5 1.5 0 0 1 \
5 9.5z\x22/>\x0d\x0a</svg\
>\
\x00\x00\x02s\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-folder2-ope\
n\x22 viewBox=\x220 0 \
16 16\x22>\x0d\x0a  <path\
 d=\x22M1 3.5A1.5 1\
.5 0 0 1 2.5 2h2\
.764c.958 0 1.76\
.56 2.311 1.184C\
7.985 3.648 8.48\
 4 9 4h4.5A1.5 1\
.5 0 0 1 15 5.5v\
.64c.57.265.94.8\
76.856 1.546l-.6\
4 5.124A2.5 2.5 \
0 0 1 12.733 15H\
3.266a2.5 2.5 0 \
0 1-2.481-2.19l-\
.64-5.124A1.5 1.\
5 0 0 1 1 6.14zM\
2 6h12v-.5a.5.5 \
0 0 0-.5-.5H9c-.\
964 0-1.71-.629-\
2.174-1.154C6.37\
4 3.334 5.82 3 5\
.264 3H2.5a.5.5 \
0 0 0-.5.5zm-.36\
7 1a.5.5 0 0 0-.\
496.562l.64 5.12\
4A1.5 1.5 0 0 0 \
3.266 14h9.468a1\
.5 1.5 0 0 0 1.4\
89-1.314l.64-5.1\
24A.5.5 0 0 0 14\
.367 7z\x22/>\x0d\x0a</sv\
g>\
\x00\x00\x01b\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-pause-circl\
e\x22 viewBox=\x220 0 \
16 16\x22>\x0d\x0a  <path\
 d=\x22M8 15A7 7 0 \
1 1 8 1a7 7 0 0 \
1 0 14m0 1A8 8 0\
 1 0 8 0a8 8 0 0\
 0 0 16\x22/>\x0d\x0a  <p\
ath d=\x22M5 6.25a1\
.25 1.25 0 1 1 2\
.5 0v3.5a1.25 1.\
25 0 1 1-2.5 0zm\
3.5 0a1.25 1.25 \
0 1 1 2.5 0v3.5a\
1.25 1.25 0 1 1-\
2.5 0z\x22/>\x0d\x0a</svg\
>\
\x00\x00\x011\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-chevron-com\
pact-left\x22 viewB\
ox=\x220 0 16 16\x22>\x0d\
\x0a  <path fill-ru\
le=\x22evenodd\x22 d=\x22\
M9.224 1.553a.5.\
5 0 0 1 .223.67L\
6.56 8l2.888 5.7\
76a.5.5 0 1 1-.8\
94.448l-3-6a.5.5\
 0 0 1 0-.448l3-\
6a.5.5 0 0 1 .67\
-.223\x22/>\x0d\x0a</svg>\
\
\x00\x00\x00\xe9\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-dash-lg\x22 vi\
ewBox=\x220 0 16 16\
\x22>\x0d\x0a  <path fill\
-rule=\x22evenodd\x22 \
d=\x22M2 8a.5.5 0 0\
 1 .5-.5h11a.5.5\
 0 0 1 0 1h-11A.\
5.5 0 0 1 2 8\x22/>\
\x0d\x0a</svg>\
\x00\x00\x01\x18\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-three-dots\x22\
 viewBox=\x220 0 16\
 16\x22>\x0d\x0a  <path d\
=\x22M3 9.5a1.5 1.5\
 0 1 1 0-3 1.5 1\
.5 0 0 1 0 3m5 0\
a1.5 1.5 0 1 1 0\
-3 1.5 1.5 0 0 1\
 0 3m5 0a1.5 1.5\
 0 1 1 0-3 1.5 1\
.5 0 0 1 0 3\x22/>\x0d\
\x0a</svg>\
\x00\x00\x02 \
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-fullscreen\x22\
 viewBox=\x220 0 16\
 16\x22>\x0d\x0a  <path d\
=\x22M1.5 1a.5.5 0 \
0 0-.5.5v4a.5.5 \
0 0 1-1 0v-4A1.5\
 1.5 0 0 1 1.5 0\
h4a.5.5 0 0 1 0 \
1zM10 .5a.5.5 0 \
0 1 .5-.5h4A1.5 \
1.5 0 0 1 16 1.5\
v4a.5.5 0 0 1-1 \
0v-4a.5.5 0 0 0-\
.5-.5h-4a.5.5 0 \
0 1-.5-.5M.5 10a\
.5.5 0 0 1 .5.5v\
4a.5.5 0 0 0 .5.\
5h4a.5.5 0 0 1 0\
 1h-4A1.5 1.5 0 \
0 1 0 14.5v-4a.5\
.5 0 0 1 .5-.5m1\
5 0a.5.5 0 0 1 .\
5.5v4a1.5 1.5 0 \
0 1-1.5 1.5h-4a.\
5.5 0 0 1 0-1h4a\
.5.5 0 0 0 .5-.5\
v-4a.5.5 0 0 1 .\
5-.5\x22/>\x0d\x0a</svg>\
\x00\x00\x01f\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2216\
\x22 height=\x2216\x22 fi\
ll=\x22rgb(201, 210\
, 222)\x22 class=\x22b\
i bi-arrow-clock\
wise\x22 viewBox=\x220\
 0 16 16\x22>\x0d\x0a  <p\
ath fill-rule=\x22e\
venodd\x22 d=\x22M8 3a\
5 5 0 1 0 4.546 \
2.914.5.5 0 0 1 \
.908-.417A6 6 0 \
1 1 8 2z\x22/>\x0d\x0a  <\
path d=\x22M8 4.466\
V.534a.25.25 0 0\
 1 .41-.192l2.36\
 1.966c.12.1.12.\
284 0 .384L8.41 \
4.658A.25.25 0 0\
 1 8 4.466\x22/>\x0d\x0a<\
/svg>\
"

qt_resource_name = b"\
\x00\x05\
\x00O\xa6S\
\x00I\
\x00c\x00o\x00n\x00s\
\x00\x03\
\x00\x00V\x83\
\x00Q\
\x00S\x00S\
\x00\x03\
\x00\x00x\xa3\
\x00q\
\x00s\x00s\
\x00\x04\
\x00\x06\xa8\x8b\
\x00d\
\x00a\x00r\x00k\
\x00\x05\
\x00r\xfd\xf4\
\x00l\
\x00i\x00g\x00h\x00t\
\x00\x0f\
\x03U\x92\x03\
\x00P\
\x00r\x00o\x00g\x00r\x00e\x00s\x00s\x00B\x00a\x00r\x00.\x00q\x00s\x00s\
\x00\x0a\
\x0bha\xc3\
\x00B\
\x00u\x00t\x00t\x00o\x00n\x00.\x00q\x00s\x00s\
\x00\x07\
\x08\x85X#\
\x00B\
\x00a\x00r\x00.\x00q\x00s\x00s\
\x00\x0c\
\x00V+C\
\x00C\
\x00h\x00e\x00c\x00k\x00B\x00o\x00x\x00.\x00q\x00s\x00s\
\x00\x0b\
\x09Vuc\
\x00B\
\x00r\x00o\x00w\x00s\x00e\x00r\x00.\x00q\x00s\x00s\
\x00\x0b\
\x09\xdd\x94\xa3\
\x00T\
\x00o\x00o\x00l\x00B\x00o\x00x\x00.\x00q\x00s\x00s\
\x00\x0e\
\x00\xd4\xf5\x83\
\x00C\
\x00h\x00a\x00t\x00W\x00i\x00d\x00g\x00e\x00t\x00.\x00q\x00s\x00s\
\x00\x08\
\x00\xa7R\xc3\
\x00L\
\x00i\x00s\x00t\x00.\x00q\x00s\x00s\
\x00\x08\
\x0b\x07Q\xc3\
\x00E\
\x00d\x00i\x00t\x00.\x00q\x00s\x00s\
\x00\x0a\
\x0a\xce\x1dC\
\x00S\
\x00l\x00i\x00d\x00e\x00r\x00.\x00q\x00s\x00s\
\x00\x0c\
\x00'*\xc3\
\x00C\
\x00o\x00m\x00b\x00o\x00B\x00o\x00x\x00.\x00q\x00s\x00s\
\x00\x0c\
\x00\xb9\x80#\
\x00G\
\x00r\x00o\x00u\x00p\x00B\x00o\x00x\x00.\x00q\x00s\x00s\
\x00\x0e\
\x0d\xa0/\xc3\
\x00S\
\x00c\x00r\x00o\x00l\x00l\x00A\x00r\x00e\x00a\x00.\x00q\x00s\x00s\
\x00\x09\
\x08\xbf\xfcC\
\x00L\
\x00a\x00b\x00e\x00l\x00.\x00q\x00s\x00s\
\x00\x07\
\x0auX\x03\
\x00T\
\x00a\x00b\x00.\x00q\x00s\x00s\
\x00\x08\
\x08\xb8S\xc3\
\x00T\
\x00r\x00e\x00e\x00.\x00q\x00s\x00s\
\x00\x0a\
\x0f\xcf\xbd\xa3\
\x00P\
\x00l\x00a\x00y\x00e\x00r\x00.\x00q\x00s\x00s\
\x00\x0b\
\x0b\xb5\x94\x83\
\x00T\
\x00o\x00o\x00l\x00T\x00i\x00p\x00.\x00q\x00s\x00s\
\x00\x08\
\x0cXR\xc3\
\x00M\
\x00e\x00n\x00u\x00.\x00q\x00s\x00s\
\x00\x0e\
\x06\x86\xf5#\
\x00D\
\x00o\x00c\x00k\x00W\x00i\x00d\x00g\x00e\x00t\x00.\x00q\x00s\x00s\
\x00\x09\
\x09(\xecC\
\x00T\
\x00a\x00b\x00l\x00e\x00.\x00q\x00s\x00s\
\x00\x0b\
\x09\xdf\xb8\xe3\
\x00S\
\x00p\x00i\x00n\x00B\x00o\x00x\x00.\x00q\x00s\x00s\
\x00\x05\
\x00o\xa6S\
\x00i\
\x00c\x00o\x00n\x00s\
\x00\x13\
\x09{\x1d\x87\
\x00F\
\x00u\x00l\x00l\x00S\x00c\x00r\x00e\x00e\x00n\x00-\x00E\x00x\x00i\x00t\x00.\x00s\
\x00v\x00g\
\x00\x08\
\x0cGQ\xe7\
\x00S\
\x00e\x00n\x00d\x00.\x00s\x00v\x00g\
\x00\x18\
\x00 \x8b\xc7\
\x00C\
\x00o\x00m\x00p\x00a\x00c\x00t\x00C\x00h\x00e\x00v\x00r\x00o\x00n\x00-\x00R\x00i\
\x00g\x00h\x00t\x00.\x00s\x00v\x00g\
\x00\x0e\
\x0fXd\x87\
\x00C\
\x00h\x00e\x00v\x00r\x00o\x00n\x00-\x00U\x00p\x00.\x00s\x00v\x00g\
\x00\x08\
\x02\x8cP'\
\x00P\
\x00l\x00a\x00y\x00.\x00s\x00v\x00g\
\x00\x0c\
\x0d\xa2O\x87\
\x00S\
\x00c\x00i\x00s\x00s\x00o\x00r\x00s\x00.\x00s\x00v\x00g\
\x00\x10\
\x06\xd0dG\
\x00A\
\x00r\x00r\x00o\x00w\x00-\x00R\x00e\x00p\x00e\x00a\x00t\x00.\x00s\x00v\x00g\
\x00\x10\
\x00\xe9\x05\xa7\
\x00C\
\x00h\x00e\x00v\x00r\x00o\x00n\x00-\x00L\x00e\x00f\x00t\x00.\x00s\x00v\x00g\
\x00\x05\
\x00[Z\xc7\
\x00X\
\x00.\x00s\x00v\x00g\
\x00\x0c\
\x0c\x1a\x90\xa7\
\x00D\
\x00o\x00w\x00n\x00l\x00o\x00a\x00d\x00.\x00s\x00v\x00g\
\x00\x0d\
\x0c\xe7\x89G\
\x00C\
\x00l\x00i\x00p\x00b\x00o\x00a\x00r\x00d\x00.\x00s\x00v\x00g\
\x00\x10\
\x0e\x1f\x02\x87\
\x00C\
\x00h\x00e\x00v\x00r\x00o\x00n\x00-\x00D\x00o\x00w\x00n\x00.\x00s\x00v\x00g\
\x00\x08\
\x06|S\x87\
\x00C\
\x00o\x00p\x00y\x00.\x00s\x00v\x00g\
\x00\x11\
\x0e\x12\xb8G\
\x00C\
\x00h\x00e\x00v\x00r\x00o\x00n\x00-\x00R\x00i\x00g\x00h\x00t\x00.\x00s\x00v\x00g\
\
\x00\x08\
\x0bcQ\x87\
\x00S\
\x00t\x00o\x00p\x00.\x00s\x00v\x00g\
\x00\x10\
\x03\xa1m\x87\
\x00O\
\x00p\x00e\x00n\x00e\x00d\x00F\x00o\x00l\x00d\x00e\x00r\x00.\x00s\x00v\x00g\
\x00\x09\
\x0c\x98\xf7\xc7\
\x00P\
\x00a\x00u\x00s\x00e\x00.\x00s\x00v\x00g\
\x00\x17\
\x0c\x0a&\x87\
\x00C\
\x00o\x00m\x00p\x00a\x00c\x00t\x00C\x00h\x00e\x00v\x00r\x00o\x00n\x00-\x00L\x00e\
\x00f\x00t\x00.\x00s\x00v\x00g\
\x00\x08\
\x08\x9bS\x87\
\x00D\
\x00a\x00s\x00h\x00.\x00s\x00v\x00g\
\x00\x0c\
\x03\x84:'\
\x00E\
\x00l\x00l\x00i\x00p\x00s\x00i\x00s\x00.\x00s\x00v\x00g\
\x00\x0e\
\x03\xe2|\xa7\
\x00F\
\x00u\x00l\x00l\x00S\x00c\x00r\x00e\x00e\x00n\x00.\x00s\x00v\x00g\
\x00\x13\
\x06\x9a\xb5'\
\x00A\
\x00r\x00r\x00o\x00w\x00-\x00C\x00l\x00o\x00c\x00k\x00w\x00i\x00s\x00e\x00.\x00s\
\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x02\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x10\x00\x02\x00\x00\x00\x01\x00\x00\x002\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x03\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x02\x98\x00\x02\x00\x00\x00\x02\x00\x00\x00\x04\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00(\x00\x02\x00\x00\x00\x16\x00\x00\x00\x1c\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x006\x00\x02\x00\x00\x00\x16\x00\x00\x00\x06\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x02\xea\x00\x00\x00\x00\x00\x01\x00\x00h\x00\
\x00\x00\x01\x9a\x80f\xda-\
\x00\x00\x03\xc2\x00\x00\x00\x00\x00\x01\x00\x00p\xb9\
\x00\x00\x01\x9a\x80f\xda1\
\x00\x00\x03\x9c\x00\x00\x00\x00\x00\x01\x00\x00o\x90\
\x00\x00\x01\x9a\x80f\xda+\
\x00\x00\x03B\x00\x00\x00\x00\x00\x01\x00\x00jJ\
\x00\x00\x01\x9a\x80f\xda0\
\x00\x00\x05\x12\x00\x00\x00\x00\x00\x01\x00\x00\x82,\
\x00\x00\x01\x9a\x80f\xda-\
\x00\x00\x04\x8a\x00\x00\x00\x00\x00\x01\x00\x00|9\
\x00\x00\x01\x9a\x80f\xda/\
\x00\x00\x050\x00\x00\x00\x00\x00\x01\x00\x00\x83E\
\x00\x00\x01\x9a\x80f\xda.\
\x00\x00\x046\x00\x00\x00\x00\x00\x01\x00\x00x\x1e\
\x00\x00\x01\x9a\xf3f\xe3\xde\
\x00\x00\x05R\x00\x00\x00\x00\x00\x01\x00\x00\x85f\
\x00\x00\x01\x9a\x80f\xda)\
\x00\x00\x03v\x00\x00\x00\x00\x00\x01\x00\x00mO\
\x00\x00\x01\x9a\x80f\xda*\
\x00\x00\x04\xfc\x00\x00\x00\x00\x00\x01\x00\x00\x81B\
\x00\x00\x01\x9a\x80f\xda-\
\x00\x00\x02\xa8\x00\x00\x00\x00\x00\x01\x00\x00dj\
\x00\x00\x01\x9a\x80f\xda.\
\x00\x00\x04t\x00\x00\x00\x00\x00\x01\x00\x00z\xe6\
\x00\x00\x01\x9a\x80f\xda0\
\x00\x00\x04\xc8\x00\x00\x00\x00\x00\x01\x00\x00\x80\x10\
\x00\x00\x01\x9a\x80f\xda,\
\x00\x00\x03\xd2\x00\x00\x00\x00\x00\x01\x00\x00q\xf6\
\x00\x00\x01\x9a\x80f\xda-\
\x00\x00\x02\xd4\x00\x00\x00\x00\x00\x01\x00\x00f\x8f\
\x00\x00\x01\x9a\x80f\xda0\
\x00\x00\x04\xb0\x00\x00\x00\x00\x00\x01\x00\x00~\xad\
\x00\x00\x01\x9a\x80f\xda/\
\x00\x00\x03\xf0\x00\x00\x00\x00\x00\x01\x00\x00u\x02\
\x00\x00\x01\x9a\x80f\xda,\
\x00\x00\x03X\x00\x00\x00\x00\x00\x01\x00\x00k\xa9\
\x00\x00\x01\x9a\xf3he\xb6\
\x00\x00\x04L\x00\x00\x00\x00\x00\x01\x00\x00y\xbb\
\x00\x00\x01\x9a\x80f\xda+\
\x00\x00\x04\x10\x00\x00\x00\x00\x00\x01\x00\x00v\xf4\
\x00\x00\x01\x9a\x80f\xda*\
\x00\x00\x03 \x00\x00\x00\x00\x00\x01\x00\x00i6\
\x00\x00\x01\x9a\x80f\xda,\
\x00\x00\x02\xea\x00\x00\x00\x00\x00\x01\x00\x00\x8ai\
\x00\x00\x01\x9a\x80f\xda%\
\x00\x00\x03\xc2\x00\x00\x00\x00\x00\x01\x00\x00\x934\
\x00\x00\x01\x9a\x80f\xda)\
\x00\x00\x03\x9c\x00\x00\x00\x00\x00\x01\x00\x00\x92\x08\
\x00\x00\x01\x9a\x80f\xda#\
\x00\x00\x03B\x00\x00\x00\x00\x00\x01\x00\x00\x8c\xb9\
\x00\x00\x01\x9a\x80f\xda(\
\x00\x00\x05\x12\x00\x00\x00\x00\x00\x01\x00\x00\xa4\xc8\
\x00\x00\x01\x9a\x80f\xda&\
\x00\x00\x04\x8a\x00\x00\x00\x00\x00\x01\x00\x00\x9e\xc9\
\x00\x00\x01\x9a\x80f\xda'\
\x00\x00\x050\x00\x00\x00\x00\x00\x01\x00\x00\xa5\xe4\
\x00\x00\x01\x9a\xf3y%\xe2\
\x00\x00\x046\x00\x00\x00\x00\x00\x01\x00\x00\x9a\xa5\
\x00\x00\x01\x9a\xf3w+\xbd\
\x00\x00\x05R\x00\x00\x00\x00\x00\x01\x00\x00\xa8\x08\
\x00\x00\x01\x9a\x80f\xda\x22\
\x00\x00\x03v\x00\x00\x00\x00\x00\x01\x00\x00\x8f\xc4\
\x00\x00\x01\x9a\x80f\xda\x22\
\x00\x00\x04\xfc\x00\x00\x00\x00\x00\x01\x00\x00\xa3\xdb\
\x00\x00\x01\x9a\x80f\xda%\
\x00\x00\x02\xa8\x00\x00\x00\x00\x00\x01\x00\x00\x86\xcd\
\x00\x00\x01\x9a\x80f\xda&\
\x00\x00\x04t\x00\x00\x00\x00\x00\x01\x00\x00\x9ds\
\x00\x00\x01\x9a\x80f\xda(\
\x00\x00\x04\xc8\x00\x00\x00\x00\x00\x01\x00\x00\xa2\xa6\
\x00\x00\x01\x9a\x80f\xda%\
\x00\x00\x03\xd2\x00\x00\x00\x00\x00\x01\x00\x00\x94t\
\x00\x00\x01\x9a\x80f\xda&\
\x00\x00\x02\xd4\x00\x00\x00\x00\x00\x01\x00\x00\x88\xf5\
\x00\x00\x01\x9a\x80f\xda(\
\x00\x00\x04\xb0\x00\x00\x00\x00\x00\x01\x00\x00\xa1@\
\x00\x00\x01\x9a\x80f\xda'\
\x00\x00\x03\xf0\x00\x00\x00\x00\x00\x01\x00\x00\x97\x83\
\x00\x00\x01\x9a\x80f\xda$\
\x00\x00\x03X\x00\x00\x00\x00\x00\x01\x00\x00\x8e\x1b\
\x00\x00\x01\x9a\xf3w\xa4\x94\
\x00\x00\x04L\x00\x00\x00\x00\x00\x01\x00\x00\x9cE\
\x00\x00\x01\x9a\x80f\xda#\
\x00\x00\x04\x10\x00\x00\x00\x00\x00\x01\x00\x00\x99x\
\x00\x00\x01\x9a\x80f\xda#\
\x00\x00\x03 \x00\x00\x00\x00\x00\x01\x00\x00\x8b\xa2\
\x00\x00\x01\x9a\x80f\xda#\
\x00\x00\x00\x1c\x00\x02\x00\x00\x00\x02\x00\x00\x003\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00(\x00\x02\x00\x00\x00\x16\x00\x00\x00K\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x006\x00\x02\x00\x00\x00\x16\x00\x00\x005\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x01V\x00\x00\x00\x00\x00\x01\x00\x00\x11f\
\x00\x00\x01\x9a}Y\xe37\
\x00\x00\x00\x98\x00\x00\x00\x00\x00\x01\x00\x00\x04\xb0\
\x00\x00\x01\x9a\x045\x09\xc6\
\x00\x00\x01\x10\x00\x00\x00\x00\x00\x01\x00\x00\x0a\x82\
\x00\x00\x01\x9aW\x90 T\
\x00\x00\x01t\x00\x00\x00\x00\x00\x01\x00\x00\x17\xd7\
\x00\x00\x01\x9a}Y\xcc\x95\
\x00\x00\x00\xee\x00\x00\x00\x00\x00\x01\x00\x00\x09\x02\
\x00\x00\x01\x9b\x00\xcfs:\
\x00\x00\x00F\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x9a\x045\x09\xc7\
\x00\x00\x02B\x00\x00\x00\x00\x00\x01\x00\x00)\x1b\
\x00\x00\x01\x9a\x045\x09\xc6\
\x00\x00\x00\x84\x00\x00\x00\x00\x00\x01\x00\x00\x04\x11\
\x00\x00\x01\x9aW\x90 T\
\x00\x00\x01\xe0\x00\x00\x00\x00\x00\x01\x00\x00\x1dW\
\x00\x00\x01\x9a}YzZ\
\x00\x00\x01\xb4\x00\x00\x00\x00\x00\x01\x00\x00\x1a\x9a\
\x00\x00\x01\x9aW\x90 T\
\x00\x00\x02d\x00\x00\x00\x00\x00\x01\x00\x00*$\
\x00\x00\x01\x9aW\x90 d\
\x00\x00\x00\xb6\x00\x00\x00\x00\x00\x01\x00\x00\x05\xd9\
\x00\x00\x01\x9aW\x90 T\
\x00\x00\x00\xd2\x00\x00\x00\x00\x00\x01\x00\x00\x07/\
\x00\x00\x01\x9a\xf4KI\x08\
\x00\x00\x02|\x00\x00\x00\x00\x00\x01\x00\x00-\xd5\
\x00\x00\x01\x9a\xf4K\x8dr\
\x00\x00\x01\xcc\x00\x00\x00\x00\x00\x01\x00\x00\x1b?\
\x00\x00\x01\x9aW\x90 d\
\x00\x00\x01<\x00\x01\x00\x00\x00\x01\x00\x00\x10\x19\
\x00\x00\x01\x9a\x045\x09\xc8\
\x00\x00\x01&\x00\x00\x00\x00\x00\x01\x00\x00\x0c\xe2\
\x00\x00\x01\x9aW\x90 T\
\x00\x00\x00j\x00\x01\x00\x00\x00\x01\x00\x00\x01\xfc\
\x00\x00\x01\x9b\x00\xe6]\x1e\
\x00\x00\x02\x10\x00\x00\x00\x00\x00\x01\x00\x00$?\
\x00\x00\x01\x9a\xf4I\x9a\x01\
\x00\x00\x02,\x00\x00\x00\x00\x00\x01\x00\x00%v\
\x00\x00\x01\x9b\x00\xe6\x9b{\
\x00\x00\x01\x92\x00\x00\x00\x00\x00\x01\x00\x00\x19\xa6\
\x00\x00\x01\x9a\x045\x09\xc8\
\x00\x00\x01\xf6\x00\x00\x00\x00\x00\x01\x00\x00\x1f\xe2\
\x00\x00\x01\x9aW\x90 T\
\x00\x00\x01V\x00\x00\x00\x00\x00\x01\x00\x00D\xff\
\x00\x00\x01\x9a}Z\x99J\
\x00\x00\x00\x98\x00\x00\x00\x00\x00\x01\x00\x008\x19\
\x00\x00\x01\x9a\x045\x09\xc0\
\x00\x00\x01\x10\x00\x00\x00\x00\x00\x01\x00\x00=\xf7\
\x00\x00\x01\x9aW\x90 T\
\x00\x00\x01t\x00\x00\x00\x00\x00\x01\x00\x00K\x89\
\x00\x00\x01\x9a}Z\xac\xd5\
\x00\x00\x00\xee\x00\x00\x00\x00\x00\x01\x00\x00<w\
\x00\x00\x01\x9b\x00\xcfJa\
\x00\x00\x00F\x00\x00\x00\x00\x00\x01\x00\x003d\
\x00\x00\x01\x9a\x045\x09\xc2\
\x00\x00\x02B\x00\x00\x00\x00\x00\x01\x00\x00Y\xfe\
\x00\x00\x01\x9a\x045\x09\xc0\
\x00\x00\x00\x84\x00\x00\x00\x00\x00\x01\x00\x007\x80\
\x00\x00\x01\x9aW\x90 T\
\x00\x00\x01\xe0\x00\x00\x00\x00\x00\x01\x00\x00Q \
\x00\x00\x01\x9a}Z\xe3\xa0\
\x00\x00\x01\xb4\x00\x00\x00\x00\x00\x01\x00\x00NM\
\x00\x00\x01\x9aW\x90 T\
\x00\x00\x02d\x00\x00\x00\x00\x00\x01\x00\x00[\x0a\
\x00\x00\x01\x9aW\x90 T\
\x00\x00\x00\xb6\x00\x00\x00\x00\x00\x01\x00\x009B\
\x00\x00\x01\x9aW\x90 T\
\x00\x00\x00\xd2\x00\x00\x00\x00\x00\x01\x00\x00:\x9e\
\x00\x00\x01\x9a\xf4K+\x00\
\x00\x00\x02|\x00\x00\x00\x00\x00\x01\x00\x00^\xca\
\x00\x00\x01\x9a}Z\xcdW\
\x00\x00\x01\xcc\x00\x00\x00\x00\x00\x01\x00\x00N\xf5\
\x00\x00\x01\x9aW\x90 T\
\x00\x00\x01<\x00\x01\x00\x00\x00\x01\x00\x00C\xb0\
\x00\x00\x01\x9a\x045\x09\xc2\
\x00\x00\x01&\x00\x00\x00\x00\x00\x01\x00\x00@c\
\x00\x00\x01\x9aW\x90 T\
\x00\x00\x00j\x00\x01\x00\x00\x00\x01\x00\x005g\
\x00\x00\x01\x9b\x00\xe6\x7fq\
\x00\x00\x02\x10\x00\x00\x00\x00\x00\x01\x00\x00U\x05\
\x00\x00\x01\x9a\xf4I\xa4\xd6\
\x00\x00\x02,\x00\x00\x00\x00\x00\x01\x00\x00VF\
\x00\x00\x01\x9b\x00\xe6\xc5\x04\
\x00\x00\x01\x92\x00\x00\x00\x00\x00\x01\x00\x00MY\
\x00\x00\x01\x9a\x045\x09\xc2\
\x00\x00\x01\xf6\x00\x01\x00\x00\x00\x01\x00\x00S\xaf\
\x00\x00\x01\x9aW\x90 T\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
