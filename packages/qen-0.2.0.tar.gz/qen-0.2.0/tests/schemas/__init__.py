"""GitHub API schema definitions for type-safe testing."""
