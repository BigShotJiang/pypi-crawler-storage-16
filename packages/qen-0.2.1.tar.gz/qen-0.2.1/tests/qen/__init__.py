"""Tests for qen CLI tool."""
