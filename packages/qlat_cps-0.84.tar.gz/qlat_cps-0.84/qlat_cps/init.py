from .c import begin_with_cps, end_with_cps
