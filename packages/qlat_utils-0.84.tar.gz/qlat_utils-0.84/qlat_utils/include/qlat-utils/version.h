#include <string>

std::string get_qlat_version();
