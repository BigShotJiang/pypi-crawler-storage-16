#include <qlat-utils/version.h>

std::string get_qlat_version() { return "VERSION"; }
