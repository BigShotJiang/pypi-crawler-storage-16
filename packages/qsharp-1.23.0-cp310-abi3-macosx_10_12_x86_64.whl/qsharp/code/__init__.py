# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

"""
Code module that receives any user-defined Q# callables as Python functions.
"""
