# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

from .default import DetaultExecutor
