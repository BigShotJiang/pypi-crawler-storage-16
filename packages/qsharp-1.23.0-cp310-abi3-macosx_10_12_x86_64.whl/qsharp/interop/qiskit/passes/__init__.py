# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

from .remove_delay import RemoveDelays
