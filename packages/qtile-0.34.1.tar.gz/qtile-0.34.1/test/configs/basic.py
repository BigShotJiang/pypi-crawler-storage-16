from libqtile import config

keys = [config.Key(["control"], "k", "focusnext")]

screens = []
layouts = []
groups = []
