# elParaguayo's Qtile Extras

![CI Action](https://github.com/elParaguayo/qtile-extras/workflows/ci/badge.svg?branch=main)
[![Documentation Status](https://readthedocs.org/projects/qtile-extras/badge/?version=latest)](https://qtile-extras.readthedocs.io/en/latest/?badge=latest)
[![Code style](https://img.shields.io/badge/code%20style-ruff-000000.svg)](https://github.com/astral-sh/ruff)

This is a separate repo where I share things that I made for qtile that (probably) won't ever end up in the main repo.

This things were really just made for use by me so your mileage may vary.

Documentation can be found [here](https://qtile-extras.readthedocs.io/).

