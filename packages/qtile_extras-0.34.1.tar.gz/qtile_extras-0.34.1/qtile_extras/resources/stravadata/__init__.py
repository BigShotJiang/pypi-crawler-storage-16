from qtile_extras.resources.stravadata.sync import update

get_strava_data = update
