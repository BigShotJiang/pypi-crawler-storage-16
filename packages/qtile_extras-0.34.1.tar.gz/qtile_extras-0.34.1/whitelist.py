menuObjectPath  # unused variable (qtile_extras/resources/global_menu/registrar.py:125)  # noqa: F821
