"""Command line interface for quacc."""
