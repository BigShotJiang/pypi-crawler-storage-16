"""Recipes for NewtonNet."""
