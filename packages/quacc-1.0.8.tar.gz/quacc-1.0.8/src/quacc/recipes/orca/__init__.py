"""Recipes for ORCA."""
