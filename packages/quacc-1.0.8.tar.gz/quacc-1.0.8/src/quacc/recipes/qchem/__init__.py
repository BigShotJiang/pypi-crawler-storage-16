"""
Recipes for Q-Chem.

These recipes will ultimately replace the existing ones in `qchem`.
"""
