# Sub-sections example

A sample chapter, there's no content here, just a placeholder to demo the navbar.

```{toctree}
demo
markdown_limits
subchapter1a/index
subchapter1b/index
chapterpage1
chapterpage2
chapterpage3
notebookpage1
```
