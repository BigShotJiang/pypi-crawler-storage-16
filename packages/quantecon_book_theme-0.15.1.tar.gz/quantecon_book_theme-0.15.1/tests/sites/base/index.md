# Index `with code` in title

```{toctree}
:caption: My caption
:numbered:
page1
page2
section1/index
https://google.com
```
