# RTL Theme Test - Index `with code` in title

This site tests the RTL (Right-to-Left) support in the QuantEcon Book Theme.

```{toctree}
:caption: RTL Test Pages
:numbered:
rtl_test
```
