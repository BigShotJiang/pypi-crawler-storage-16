# main.py
def hello():
    print("Welcome to the world of Quant!")
