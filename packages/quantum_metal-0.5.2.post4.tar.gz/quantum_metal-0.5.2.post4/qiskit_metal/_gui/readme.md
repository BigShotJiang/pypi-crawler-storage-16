# QT Designer UI Notes

 For tree/table views:
  -  Make sure to turn off autoscroll (https://stackoverflow.com/questions/8100343/how-do-i-stop-the-qtreewidget-from-moving-the-scroll-position)
  - verticalScrollMode and horizontalScrollMode set to per pixel

