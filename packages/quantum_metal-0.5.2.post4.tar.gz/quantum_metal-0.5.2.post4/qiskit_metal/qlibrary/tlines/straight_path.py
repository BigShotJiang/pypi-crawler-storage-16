# -*- coding: utf-8 -*-

# This code is part of Qiskit.
#
# (C) Copyright IBM 2017, 2021.
#
# This code is licensed under the Apache License, Version 2.0. You may
# obtain a copy of this license in the LICENSE.txt file in the root directory
# of this source tree or at http://www.apache.org/licenses/LICENSE-2.0.
#
# Any modifications or derivative works of this code must retain this
# copyright notice, and modified files need to carry a notice indicating
# that they have been altered from the originals.

from qiskit_metal import Dict
from qiskit_metal.qlibrary import QRoute


class RouteStraight(QRoute):
    """
    Draw a straight Route connecting two pins.
    
    .. meta::
        :description: Route Straight
    """

    component_metadata = Dict(short_name='cpw')
    """Component metadata"""

    TOOLTIP = """Draw a straight Route connecting two pins."""

    def make(self):
        """The make function implements the logic that creates the geometry
        (poly, path, etc.) from the qcomponent.options dictionary of
        parameters, and the adds them to the design, using
        qcomponent.add_qgeometry(...), adding in extra needed information, such
        as layer, subtract, etc."""
        # Set the CPW pins and add the points/directions to the lead-in/out arrays
        self.set_pin("start")
        self.set_pin("end")

        # Align the lead-in/out to the input options set from the user
        self.set_lead("start")
        self.set_lead("end")

        # Make points into elements
        self.make_elements(self.get_points())
