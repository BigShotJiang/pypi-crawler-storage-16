FEW_SHOT_EXAMPLES = """
### EXAMPLES (FEW-SHOT LEARNING)
To help you understand the task, here are some examples of the expected input and output.

{{ examples }}

Please follow the style and format of these examples closely when processing the new input.
"""