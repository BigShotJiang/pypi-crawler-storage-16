THOUGHT_PROCESS = """
### THOUGHT PROCESS
Before generating the final answer, please think step-by-step:
1. Analyze the user's request constraints.
2. Identify necessary tools or data sources.
3. Validate assumptions.
"""