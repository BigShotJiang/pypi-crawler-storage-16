# graft-templates

This folder contains templates that can be used when creating new grafts.
e.g., 

```bash
uv run graft-new --template python calculus
```

This will create a new graft called `calculus` under the git branch `graft/calculus`.