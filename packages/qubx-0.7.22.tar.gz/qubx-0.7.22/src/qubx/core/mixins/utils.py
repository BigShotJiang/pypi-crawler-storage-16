# - this is used to check for the mapped exchange if the current exchange is not supported
EXCHANGE_MAPPINGS = {
    "BINANCE.UM": "BINANCE.PM",
}
