def test_smoke():
    import query_patterns

    assert hasattr(query_patterns, "__version__")
