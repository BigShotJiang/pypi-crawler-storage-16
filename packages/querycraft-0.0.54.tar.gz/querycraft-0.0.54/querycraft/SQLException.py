import os
import sys
from querycraft.LLM import *
import json
from pathlib import Path
from querycraft.tools import existFile

class SQLException(Exception):

    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def __str__(self):
        return self.message

    def __repr__(self):
        return self.message

    def __unicode__(self):
        return self.message

class SQLQueryException(SQLException):
    model = "gemma3:1b"
    llm = "ollama"
    api_key = None
    url = None
    ia_on = False

    cache = dict()
    cache_file = ""

    @classmethod
    def set_model(cls, llm, model, api_key=None, url=None, ia_on=True):
        cls.model = model
        cls.api_key = api_key
        cls.llm = llm
        cls.url = url
        cls.ia_on = ia_on
        cls.cache_file = (cls.llm+"_"+cls.model).replace(':','_')+'.json'
        with importlib.resources.path("querycraft.cache", cls.cache_file) as file:
            if existFile(file) :
                with file.open("r", encoding="utf-8") as fichier:
                    cls.cache = json.load(fichier)

    @classmethod
    def get_model(cls):
        return cls.model

    def __init__(self,verbose, message, sqlhs, sqlok, sgbd, bd = ""):
        super().__init__(message)
        self.sqlhs = sqlhs
        if sqlok is None : self.sqlok = ""
        else: self.sqlok = sqlok
        self.sgbd = sgbd
        self.hints = ""
        print(
            f"Erreur doSBS = {RED}Erreur sur la requête SQL avec {self.sgbd} :\n -> Requête proposée : {self.sqlhs}\n -> Message {self.sgbd} :\n{self.message}{RESET}")  # Affichage de l'erreur de base
        if SQLQueryException.ia_on :
            input("Appuyez sur Entrée pour avoir une explication de l'erreur par IA ou Ctrl + Z pour quitter.")
            self.clear_line()
            new = False
            if self.sqlhs+self.sqlok in SQLQueryException.cache:
                (self.hints, date) = SQLQueryException.cache[self.sqlhs + self.sqlok]
                self.hints = "(cache) " + self.hints
            else:
                new = True
                if SQLQueryException.llm == "ollama" :
                    self.hints = OllamaLLM(verbose,self.sgbd,SQLQueryException.get_model(),bd).run(str(self.message), self.sqlok, self.sqlhs)
                elif SQLQueryException.llm == "poe" :
                    self.hints = PoeLLM(verbose, self.sgbd, SQLQueryException.model,
                                        SQLQueryException.api_key, SQLQueryException.url,
                                        bd).run(str(self.message), self.sqlok, self.sqlhs)
                else :
                    self.hints = ""

                maintenant = datetime.now().date().isoformat()

                if self.hints:
                    self.clear_line()
                    if new:
                        SQLQueryException.cache[self.sqlhs+self.sqlok] = (self.hints,maintenant)
                        with importlib.resources.path("querycraft.cache", SQLQueryException.cache_file) as file:
                            with file.open("w", encoding="utf-8") as fichier:
                                json.dump(SQLQueryException.cache, fichier, ensure_ascii=False, indent=2)
                else:
                    print("Modèle pas accessible, utilisation du modèle par défaut")
                    with importlib.resources.path("querycraft.cache", "default.json") as file:
                        if existFile(file):
                            with file.open("r", encoding="utf-8") as fichier:
                                cache = json.load(fichier)
                        else: cache=dict()

                    if self.sqlhs + self.sqlok in cache:
                        (self.hints, date) = cache[self.sqlhs+ self.sqlok]
                        self.hints = "(cache) " + self.hints
                        new = False
                    else :
                        # gpt-4.1-nano ; gpt-5-nano ; gpt-5.1-codex
                        self.hints = PoeLLM(verbose,self.sgbd,
                                        "gpt-4.1-nano", "umnm9e2VrXsAX6FDurYa8ThkRTcYSHuQMzb22xjnh0A","https://api.poe.com/v1",
                                        bd).run(str(self.message), self.sqlok, self.sqlhs)

                    self.clear_line()
                    cache[self.sqlhs+self.sqlok] = (self.hints,maintenant)
                    with importlib.resources.path("querycraft.cache", "default.json") as file:
                        with file.open("w", encoding="utf-8") as fichier:
                            json.dump(cache, fichier, ensure_ascii=False, indent=2)

    def __str__(self):
        #mssg = f"{RED}Erreur sur la requête SQL avec {self.sgbd} :\n -> Requête proposée : {self.sqlhs}\n -> Message {self.sgbd} :\n{self.message}{RESET}"
        mssg = ""
        if self.hints != "":
            mssg += f"\n{GREEN} -> Aide :{RESET} {self.hints}"
        return mssg

    def __repr__(self):
        return self.__str__()
    def __unicode__(self):
        return self.__str__()

    def clear_line(self):
        # Windows
        if os.name == 'nt':
            os.system('cls')
        # Unix/Linux/MacOS
        else:
            sys.stdout.write("\033[F")
            sys.stdout.write("\033[K")