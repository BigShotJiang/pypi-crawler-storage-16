# CLI

- `run` — produce reformulated TSV.
- `data-to-tsv` — convert any backend to `qid<TAB>query`.
- `prompts-list` / `prompts-show` — inspect prompt bank.
- `script-gen` — create a Pyserini + trec_eval bash script.
