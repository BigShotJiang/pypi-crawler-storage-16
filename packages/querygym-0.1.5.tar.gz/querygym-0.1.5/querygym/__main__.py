"""Entry point for running queryGym as a module: python -m queryGym"""
from .cli import app

if __name__ == "__main__":
    app()

