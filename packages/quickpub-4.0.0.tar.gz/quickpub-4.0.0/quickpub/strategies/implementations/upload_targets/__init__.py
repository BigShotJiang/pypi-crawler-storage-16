from .github_upload_target import *
from .pypirc_upload_target import *
