"""QuickScale Core Package - Foundation for Django project scaffolding and generation."""

from quickscale_core.version import VERSION, __version__

__all__ = ["__version__", "VERSION"]
