from quicrpc.__meta__ import __package_name__, __version__, __module_path__

__all__: list[str] = [
    '__package_name__',
    '__version__',
    '__module_path__',
]
