===
### Quik Python project [QUIK&nbsp;&nbsp;Python](https://github.com/Alex-Shur/quik_python)
LEX  &mdash; https://github.com/Alex-Shur

===
### Authohr of QUIKSharp project [QUIKSharp](https://github.com/finsight/QUIKSharp)
* Oleg Andrushko &mdash; [@nubick](https://github.com/nubick)
* Victor Baybekov &mdash; [@buybackoff](https://github.com/buybackoff)
* [@Pr0phet1c](https://github.com/Pr0phet1c)
* [@SkyN](https://github.com/SkyN)
* [@sm00vik](https://github.com/sm00vik)
* [@spvik](https://github.com/spvik)
* [@stanislav-111](https://github.com/stanislav-111)

