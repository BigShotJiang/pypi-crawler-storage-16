"""
__init__.py для пакета models
"""
