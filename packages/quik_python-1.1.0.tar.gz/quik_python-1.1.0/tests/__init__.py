"""
Тесты для quik-python проекта
Интеграция с UV package manager
"""

__version__ = "0.1.0"
