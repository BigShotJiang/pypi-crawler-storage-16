---
QUILL: usaf_memo
letterhead_title: DEPARTMENT OF THE AIR FORCE
letterhead_caption: YOUR SQUADRON HERE
memo_for:
  - ORG/SYM
  # - 2nd ORG/SYM
memo_from:
  - ORG/SYMBOL
subject: Comply without pain — markdown to official memo
signature_block:
  - FIRST M. LAST, Rank, USAF
tag_line: Aim High
---

Click "Wizard" to edit header, signature block, and more.

Write your paragraphs here. Separate them with two new lines.

- Use bullets to nest paragraphs.
  - Indent to go deeper.

You can also **bold**, _italicize_, __underline__, `code`, and ~~strikethrough~~ your text.

Less formatting. More lethality.
