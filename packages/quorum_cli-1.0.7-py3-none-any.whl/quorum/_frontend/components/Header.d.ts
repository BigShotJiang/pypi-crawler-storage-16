/**
 * Header component with app info, settings overview, and tips.
 */
export declare function Header(): import("react/jsx-runtime").JSX.Element;
