/**
 * Help display component.
 */
export declare function Help(): import("react/jsx-runtime").JSX.Element;
