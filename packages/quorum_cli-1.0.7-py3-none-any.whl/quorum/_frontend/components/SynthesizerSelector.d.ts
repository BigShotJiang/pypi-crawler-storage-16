/**
 * Synthesizer mode selection component.
 */
interface SynthesizerSelectorProps {
    onSelect: () => void;
}
export declare function SynthesizerSelector({ onSelect }: SynthesizerSelectorProps): import("react/jsx-runtime").JSX.Element;
export {};
