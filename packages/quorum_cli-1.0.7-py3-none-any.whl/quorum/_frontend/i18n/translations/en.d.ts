/**
 * English translations (base language).
 */
import type { Translations } from "../types.js";
export declare const en: Translations;
