/**
 * Devil's Advocate method JSON export schema
 * 3 phases: Initial Positions -> Cross-Examination -> Verdict
 */
export {};
