/**
 * Oxford debate method JSON export schema
 * 4 phases: Opening Statements -> Rebuttals -> Closing Arguments -> Judgement
 */
export {};
