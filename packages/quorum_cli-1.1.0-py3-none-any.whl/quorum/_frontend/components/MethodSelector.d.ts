/**
 * Method selection component.
 */
interface MethodSelectorProps {
    onSelect: () => void;
}
export declare function MethodSelector({ onSelect }: MethodSelectorProps): import("react/jsx-runtime").JSX.Element;
export {};
