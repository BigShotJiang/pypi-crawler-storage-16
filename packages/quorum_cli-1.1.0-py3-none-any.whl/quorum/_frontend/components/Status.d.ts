/**
 * Status display component.
 */
export declare function Status(): import("react/jsx-runtime").JSX.Element;
