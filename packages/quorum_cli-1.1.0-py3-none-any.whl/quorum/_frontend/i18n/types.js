/**
 * Type definitions for i18n translations.
 */
export {};
