#!/usr/bin/env node
/**
 * Quorum Frontend - Terminal UI for multi-agent consensus.
 */
export {};
