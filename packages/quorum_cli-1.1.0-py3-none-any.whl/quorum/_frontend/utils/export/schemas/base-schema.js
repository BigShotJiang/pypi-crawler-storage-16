/**
 * Base schema types for method-aware JSON export
 * All method-specific schemas extend these base interfaces
 */
/** Schema version for forwards compatibility */
export const SCHEMA_VERSION = "2.0";
