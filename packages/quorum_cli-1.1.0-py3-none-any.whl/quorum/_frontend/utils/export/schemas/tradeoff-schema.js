/**
 * Tradeoff analysis method JSON export schema
 * 4 phases: Frame (Define Alternatives) -> Criteria -> Evaluate -> Decision
 */
export {};
