/**
 * Discussion view showing all messages.
 */
export declare function Discussion(): import("react/jsx-runtime").JSX.Element;
