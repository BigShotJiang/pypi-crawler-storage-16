/**
 * French translations.
 */
import type { Translations } from "../types.js";
export declare const fr: Translations;
