# Qwak Core

Qwak is an end-to-end production ML platform designed to allow data scientists to build, deploy, and monitor their models in production with minimal engineering friction.
Qwak Core contains all the objects and tools necessary to use the Qwak Platform
