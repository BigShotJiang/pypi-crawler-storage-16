class QwakModelInitializationException(RuntimeError):
    """
    Signals an error occurred when trying to initialize a qwak model at build time
    """
