"""r2x-reeds plugins package."""

from .break_gens import break_generators

__all__ = ["break_generators"]
