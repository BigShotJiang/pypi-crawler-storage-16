from typing import Protocol, Callable, Any


class CastClass(Protocol):

    def __init__(self, x: str, *args: Any, **kwargs: Any) -> None: ...

type Path = str
type Cast[T] = type[CastClass] | Callable[[str], T]
