class {{ class_name }}Service:
    async def list(self):
        return []

    async def create(self, payload):
        return payload
