class AppInfo:
    def __init__(self):
        self.name = "MyApp"
        self.version = "0.0.3"
