import typer


def ai_create():
    """Build project (e.g., compile assets, prepare dist)."""
    typer.echo("[build] Build command not implemented yet.")
    pass
