import typer


def ai_test_generate():
    """Build project (e.g., compile assets, prepare dist)."""
    typer.echo("[build] Build command not implemented yet.")
    pass
