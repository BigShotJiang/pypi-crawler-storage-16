import typer

def controller():
    """Build project (e.g., compile assets, prepare dist)."""
    typer.echo("[build] Build command not implemented yet.")
    pass
