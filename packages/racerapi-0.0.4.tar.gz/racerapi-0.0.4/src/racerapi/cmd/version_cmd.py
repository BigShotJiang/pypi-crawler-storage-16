import typer


def version_cmd():
    """Show RacerAPI version information."""
    typer.echo("RacerAPI v0.1.0")
