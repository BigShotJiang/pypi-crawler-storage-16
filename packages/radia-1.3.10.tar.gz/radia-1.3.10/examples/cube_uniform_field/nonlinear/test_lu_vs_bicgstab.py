"""
Compare LU vs BiCGSTAB solvers on same tetrahedral mesh.
The results should match if both converged correctly.
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../../../build/Release'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../../../src/radia'))
import radia as rad
import numpy as np

from ngsolve import Mesh
from netgen.csg import CSGeometry, OrthoBrick, Pnt
from netgen_mesh_import import netgen_mesh_to_radia

MU_0 = 4 * np.pi * 1e-7
H_EXT = 50000.0

# B-H curve
BH_DATA = [
    [0.0, 0.0], [100.0, 0.1], [200.0, 0.3], [500.0, 0.8], [1000.0, 1.2],
    [2000.0, 1.5], [5000.0, 1.7], [10000.0, 1.8], [50000.0, 2.0], [100000.0, 2.1],
]
HM_DATA = [[h, b/MU_0 - h] for h, b in BH_DATA]

def run_comparison(maxh):
    print(f'\n{"="*60}')
    print(f'maxh = {maxh}m')
    print("="*60)

    # Create mesh ONCE
    geo = CSGeometry()
    box = OrthoBrick(Pnt(-0.5, -0.5, -0.5), Pnt(0.5, 0.5, 0.5))
    geo.Add(box)
    ngmesh = geo.GenerateMesh(maxh=maxh)
    mesh = Mesh(ngmesh)

    n_elem = mesh.ne
    print(f'Elements: {n_elem}')

    results = {}
    for method, name in [(0, 'LU'), (1, 'BiCGSTAB')]:
        rad.FldUnits('m')
        rad.UtiDelAll()

        # Import SAME mesh
        mag_obj = netgen_mesh_to_radia(mesh, material={'magnetization': [0, 0, 0]}, units='m')

        # Apply material
        mat = rad.MatSatIsoTab(HM_DATA)
        rad.MatApl(mag_obj, mat)

        # External field
        B_ext = MU_0 * H_EXT
        ext = rad.ObjBckg([0, 0, B_ext])
        grp = rad.ObjCnt([mag_obj, ext])

        # Solve
        result = rad.Solve(grp, 0.001, 1000, method)

        # Get magnetization
        all_M = rad.ObjM(mag_obj)
        M_avg_z = np.mean([m[1][2] for m in all_M])
        n_iter = int(result[3]) if result[3] else 0
        residual = result[0] if result[0] else 0.0

        print(f'{name:10s}: iter={n_iter:4d}, residual={residual:10.2f}, M_avg_z={M_avg_z:12.0f} A/m')
        results[name] = {'M_avg_z': M_avg_z, 'iter': n_iter, 'residual': residual}

    diff = abs(results['LU']['M_avg_z'] - results['BiCGSTAB']['M_avg_z'])
    pct = 100 * diff / max(results['LU']['M_avg_z'], results['BiCGSTAB']['M_avg_z'])
    print(f'Difference: {diff:.0f} A/m ({pct:.1f}%)')

    return results

# Run for multiple mesh sizes
if __name__ == '__main__':
    print('\nComparison of LU vs BiCGSTAB solvers on tetrahedral meshes')
    print('(Same mesh, same problem - results should be identical)')

    for maxh in [0.4, 0.35, 0.3]:
        run_comparison(maxh)
