"""Radicle MCP Server - Version-aware MCP server for Radicle CLI."""

__version__ = "0.1.0"
__author__ = "Empiria Ltd"
__description__ = "MCP server for Radicle decentralized code forge"
