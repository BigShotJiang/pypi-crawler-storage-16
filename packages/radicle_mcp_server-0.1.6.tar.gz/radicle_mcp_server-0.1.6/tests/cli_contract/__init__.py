"""CLI contract tests for validating YAML definitions against actual rad CLI."""
