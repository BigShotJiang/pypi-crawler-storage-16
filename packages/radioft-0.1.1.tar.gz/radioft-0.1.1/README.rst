======================
radioft |ci| |codecov|
======================

.. |ci| image:: https://github.com/radionets-project/radioft/actions/workflows/ci.yml/badge.svg?branch=main
    :target: https://github.com/radionets-project/radioft/actions/workflows/ci.yml?branch=main
    :alt: Test Status

.. |codecov| image:: https://codecov.io/github/radionets-project/radioft/badge.svg
    :target: https://codecov.io/github/radionets-project/radioft
    :alt: Code coverage

Fourier transform implementations for radio interferometry applications.
