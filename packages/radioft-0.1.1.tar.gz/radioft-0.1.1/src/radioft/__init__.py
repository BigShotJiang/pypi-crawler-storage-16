"""
radioft - Fourier transform implementations for radio interferometry applications.
"""

from .version import __version__

__all__ = ["__version__"]
