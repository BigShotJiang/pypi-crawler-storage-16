"""ESL Jupyter Kernel

Elephant Specification Language Kernel for Jupyter.
"""
