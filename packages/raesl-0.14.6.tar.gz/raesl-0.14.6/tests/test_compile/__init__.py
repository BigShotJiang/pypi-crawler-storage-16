"""Tests for compile module."""
