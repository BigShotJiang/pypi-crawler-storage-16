"""Tests for plot module."""
