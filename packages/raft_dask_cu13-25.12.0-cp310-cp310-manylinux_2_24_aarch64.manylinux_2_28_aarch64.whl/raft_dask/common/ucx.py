# SPDX-FileCopyrightText: Copyright (c) 2020-2025, NVIDIA CORPORATION.
# SPDX-License-Identifier: Apache-2.0
#

import ucxx


async def _connection_func(ep):
    UCX.get().add_server_endpoint(ep)


class UCX:
    """
    Singleton UCX context to encapsulate all interactions with the
    UCXX API and guarantee only a single listener & endpoints are
    created by RAFT Comms on a single process.
    """

    __instance = None

    def __init__(self, listener_callback):
        self.listener_callback = listener_callback

        self._create_listener()
        self._endpoints = {}
        self._server_endpoints = []

        assert UCX.__instance is None

        UCX.__instance = self

    @staticmethod
    def get(listener_callback=_connection_func):
        if UCX.__instance is None:
            UCX(listener_callback)
        return UCX.__instance

    def get_worker(self):
        return ucxx.get_ucxx_worker()

    def _create_listener(self):
        self._listener = ucxx.create_listener(self.listener_callback)

    def listener_port(self):
        return self._listener.port

    async def _create_endpoint(self, ip, port):
        ep = await ucxx.create_endpoint(ip, port)
        self._endpoints[(ip, port)] = ep
        return ep

    def add_server_endpoint(self, ep):
        self._server_endpoints.append(ep)

    async def get_endpoint(self, ip, port):
        if (ip, port) not in self._endpoints:
            ep = await self._create_endpoint(ip, port)
        else:
            ep = self._endpoints[(ip, port)]

        return ep

    async def close_endpoints(self):
        for k, ep in self._endpoints.items():
            await ep.close()

        for ep in self._server_endpoints:
            ep.close()

    def __del__(self):
        for ip_port, ep in self._endpoints.items():
            if not ep.closed():
                ep.abort()
            del ep

        for ep in self._server_endpoints:
            if not ep.closed():
                ep.abort()
            del ep

        self._listener.close()
