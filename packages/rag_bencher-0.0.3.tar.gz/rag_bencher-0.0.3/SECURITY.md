
# Security Policy

- Report vulnerabilities by opening a **PRIVATE** security advisory in GitHub (Security > Advisories).
- We aim to respond within 7 days.
