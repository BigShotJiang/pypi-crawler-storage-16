
# Code of Conduct

This project follows the [Contributor Covenant](https://www.contributor-covenant.org/).
Be kind, assume good intent, and help create a welcoming environment.
