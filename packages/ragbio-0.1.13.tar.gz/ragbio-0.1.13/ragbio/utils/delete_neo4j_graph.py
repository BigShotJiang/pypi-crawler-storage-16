from py2neo import Graph

graph = Graph("bolt://localhost:7687", auth=("neo4j", "@#DataScientist007"))

# Test query
try:
    result = graph.run("RETURN 1 AS test").data()
    print("Connected successfully:", result)
except Exception as e:
    print("Connection failed:", e)

