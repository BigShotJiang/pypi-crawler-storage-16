#!/usr/bin/env python3

"""
rag_pipeline.py

RAG (Retrieval-Augmented Generation) Pipeline for Biomedical Literature Case Studies.

This module allows users to perform retrieval-augmented generation over PubMed abstracts
using FAISS embeddings and Ollama LLMs. It also optionally extracts structured drug-target-disease
information and integrates the results into a Neo4j knowledge graph.

Usage example:
python -m ragbio.pipeline.rag_pipeline \
    --query "Alzheimer Disease AND therapy" \
    --top_k 10 \
    --structured \
    --query_name "Alzheimer_CaseStudy"
"""

import os
import re
import json
import argparse
import faiss
import numpy as np
from operator import itemgetter
from typing import List
from pydantic import Field

# LangChain imports
from langchain_community.llms import Ollama
from langchain_community.embeddings import OllamaEmbeddings
from langchain_core.documents import Document
from langchain_core.runnables import RunnablePassthrough, RunnableLambda
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.retrievers import BaseRetriever

# Local imports
from ragbio.config import ABSTRACT_FOLDER, INDEX_FILE, ID_MAP_FILE, MODEL_NAME, CHAT_MODEL, TOP_K
from ragbio.knowledge_graph.structured_drug_kg import add_structured_data_to_kg


class FAISSPMIDRetriever(BaseRetriever):
    """Custom LangChain retriever using FAISS index for PubMed abstracts."""

    embeddings: OllamaEmbeddings = Field(...)
    index: faiss.Index = Field(...)
    pmid_map: List[str] = Field(...)
    abstract_folder: str = Field(...)
    k: int = Field(default=TOP_K)

    class Config:
        arbitrary_types_allowed = True

    def _get_abstract_text(self, pmid: str) -> str:
        """Return the abstract text for a given PMID."""
        file_path = os.path.join(self.abstract_folder, f"{pmid}.json")
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return data.get("abstract", "")
        except FileNotFoundError:
            return ""

    def _get_relevant_documents(self, query: str, **kwargs) -> List[Document]:
        """Retrieve top-K relevant documents for a query."""
        query_emb = np.array(self.embeddings.embed_query(query), dtype=np.float32).reshape(1, -1)
        faiss.normalize_L2(query_emb)
        distances, indices = self.index.search(query_emb, self.k)

        documents = []
        for i, score in zip(indices[0], distances[0]):
            pmid = self.pmid_map[i]
            abstract_text = self._get_abstract_text(pmid)
            documents.append(Document(page_content=abstract_text, metadata={"source": pmid, "score": float(score)}))
        return documents


class RAGAssistant:
    """RAG assistant for biomedical literature with case-study output support."""

    def __init__(self, abstract_folder=ABSTRACT_FOLDER, embed_model=MODEL_NAME,
                 chat_model=CHAT_MODEL, query_name="default"):
        self.abstract_folder = abstract_folder
        self.query_name = query_name
        self.output_dir = os.path.join("output", query_name)
        os.makedirs(self.output_dir, exist_ok=True)

        self.embed_model = OllamaEmbeddings(model=embed_model)
        self.chat_model = Ollama(model=chat_model, temperature=0)
        self.index, self.pmid_map = self.load_faiss_index(query_name=query_name)

        self.retriever = FAISSPMIDRetriever(
            embeddings=self.embed_model,
            index=self.index,
            pmid_map=self.pmid_map,
            abstract_folder=self.abstract_folder
        )
        self.rag_chain = self._build_rag_chain()

    def _build_rag_chain(self):
        """Build the LangChain RAG chain for question answering."""
        rag_prompt = ChatPromptTemplate.from_messages([
            ("system", "You are a biomedical research assistant. Answer using the context below."),
            ("user", "Context:\n{context}\n\nQuestion: {question}"),
        ])

        def format_docs(docs: List[Document]):
            return "\n\n".join([doc.page_content for doc in docs])

        chain = {"context": itemgetter("question") | self.retriever | format_docs,
                 "question": itemgetter("question")} | rag_prompt | self.chat_model
        return chain

    def load_faiss_index(self, query_name="default"):
        """Load FAISS index and PMID map for the case study."""
        index_file = os.path.join(ID_MAP_FILE.replace("pmid_map.json", ""), query_name, "pubmed_index.faiss")
        id_map_file = os.path.join(ID_MAP_FILE.replace("pmid_map.json", ""), query_name, "pmid_map.json")
        os.makedirs(os.path.dirname(index_file), exist_ok=True)

        if not os.path.exists(index_file):
            raise FileNotFoundError(f"FAISS index not found: {index_file}")
        if not os.path.exists(id_map_file):
            raise FileNotFoundError(f"PMID map not found: {id_map_file}")

        index = faiss.read_index(index_file)
        with open(id_map_file, "r", encoding="utf-8") as f:
            pmid_map = json.load(f)
        return index, pmid_map

    def get_abstract_text(self, pmid: str) -> str:
        """Return abstract text from retriever."""
        return self.retriever._get_abstract_text(pmid)

    def extract_structured_info(self, drug_name, abstract):
        """Extract structured JSON info using Ollama."""
        prompt = f"""
        Extract structured drug-target-disease information for '{drug_name}':
        {abstract}
        Output only JSON list.
        """
        text = self.chat_model.invoke(prompt)
        try:
            start_index = text.find('[')
            end_index = text.rfind(']')
            if start_index != -1 and end_index != -1 and end_index > start_index:
                json_text = text[start_index:end_index+1]
                parsed = json.loads(json_text)
                return parsed if isinstance(parsed, list) else [parsed]
            else:
                return []
        except Exception as e:
            print(f"Warning: Failed to parse structured JSON: {e}\n{text}")
            return []

    def save_output(self, query, summary, top_pmids, structured_results=None):
        """Save summary, PMIDs, and structured results to case-study folder."""
        summary_file = os.path.join(self.output_dir, f"{self.query_name}_summary.txt")
        with open(summary_file, "a", encoding="utf-8") as f:
            f.write(f"Query: {query}\n")
            f.write(f"PMIDs: {', '.join(top_pmids)}\n")
            f.write(f"Summary: {summary}\n\n")

        if structured_results:
            json_file = os.path.join(self.output_dir, f"{self.query_name}_output.json")
            with open(json_file, "w", encoding="utf-8") as f:
                json.dump(structured_results, f, indent=2)
            print(f"Structured results saved to: {json_file}")

    def run_pipeline(self, query: str, top_k: int = TOP_K, structured: bool = False):
        """Run full RAG pipeline for the query."""
        self.retriever.k = top_k
        chain_result = self.rag_chain.invoke({"question": query})
        retrieved_docs = self.retriever._get_relevant_documents(query, k=top_k)
        top_pmids = [doc.metadata.get("source") for doc in retrieved_docs]

        structured_results = []
        if structured:
            for pmid in top_pmids:
                abstract = self.get_abstract_text(pmid)
                entries = self.extract_structured_info(query, abstract)
                for e in entries:
                    e["pmid"] = pmid
                structured_results.extend(entries)
            if structured_results:
                add_structured_data_to_kg(structured_results)

        self.save_output(query, chain_result, top_pmids, structured_results)
        return chain_result, top_pmids, structured_results


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="RAG Pipeline for Gene Discovery + Structured KG")
    parser.add_argument("--query", type=str, required=True, help="Query to search PubMed abstracts")
    parser.add_argument("--top_k", type=int, default=TOP_K, help="Number of top abstracts to retrieve")
    parser.add_argument("--structured", action="store_true", help="Extract structured info and populate Neo4j KG")
    parser.add_argument("--query_name", type=str, default="default", help="Name for case study / output folder")
    args = parser.parse_args()

    assistant = RAGAssistant(query_name=args.query_name)
    assistant.run_pipeline(args.query, top_k=args.top_k, structured=args.structured)
