# ragged-stubs

[![GitHub Actions Workflow Status](https://img.shields.io/github/actions/workflow/status/hingebase/ragged-stubs/publish-pypi.yml?label=ci&logo=github)](https://github.com/hingebase/ragged-stubs/actions)
[![PyPI - Version](https://img.shields.io/pypi/v/ragged-stubs)](https://pypi.org/project/ragged-stubs)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/ragged-stubs)
![PyPI - License](https://img.shields.io/pypi/l/ragged-stubs)
![PyPI - Types](https://img.shields.io/pypi/types/ragged-stubs)  
![basedpyright](https://img.shields.io/badge/basedpyright-checked-42b983)
![pyrefly](https://img.shields.io/endpoint?url=https://pyrefly.org/badge.json)
![ty](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ty/main/assets/badge/v0.json)
![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)
![uv](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/uv/main/assets/badge/v0.json)

Typing stubs for [ragged](https://pypi.org/project/ragged/).
