Architecture
============

.. thumbnail:: images/packages_generated_ragger_architecture.svg
  :align: center
  :title: Package relations
  :show_caption: true

.. thumbnail:: images/classes_generated_ragger_architecture.svg
  :align: center
  :title: Class relations
  :show_caption: true
