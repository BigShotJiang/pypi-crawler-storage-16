"""Multi-WaterWerk project waterway lock 'Eefde'"""

edge_weights = [
    "energy",
    "information",
    "location",
    "spatial",
]
