"""# Toy example with overlapping clusters"""

edge_weights = ["adjacency"]
