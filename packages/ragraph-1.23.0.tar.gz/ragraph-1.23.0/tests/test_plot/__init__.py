"""RaGraph plot module tests."""
