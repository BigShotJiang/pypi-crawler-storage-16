::: ragraph.utils
