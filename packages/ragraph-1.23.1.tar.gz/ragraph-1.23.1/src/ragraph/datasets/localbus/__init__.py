"""# Example graph containing a local bus"""

edge_weights = ["adjacency"]
