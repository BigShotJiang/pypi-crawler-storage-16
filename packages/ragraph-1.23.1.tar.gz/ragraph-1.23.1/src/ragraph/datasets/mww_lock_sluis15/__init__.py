"""Multi-WaterWerk project waterway lock 'Sluis 15'"""

edge_weights = [
    "energy",
    "information",
    "location",
    "spatial",
]
