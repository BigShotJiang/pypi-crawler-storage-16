"""Tests for sequencing by name."""

from ragraph.analysis import sequence


def test_name_sequencing_cases(case):
    sequence.name(case)
