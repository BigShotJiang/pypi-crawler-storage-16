# randstadenterprise_edao_libraries/logs.py
import threading
from typing import List, Any
# Add objects import (though not used directly here, useful for type hints in other files)

from . import objects 
from . import helpers # Provides get_http_headers, array_to_csv


def log (inst_url: str, msg: str, logs_array: List[List[Any]], lock: threading.Lock, print_to_console: bool = False):
    # =======================================================================
    # LOGS A MESSAGE TO A SHARED ARRAY IN A THREAD-SAFE MANNER
    # =======================================================================
        
    if print_to_console:

        inst_url_length = len(inst_url)

        if inst_url_length <= 10:
            tabs = "\t\t\t\t\t"
        elif inst_url_length <= 15:
            tabs = "\t\t\t\t\t"
        elif inst_url_length <= 22:
            tabs = "\t\t\t\t"
        elif inst_url_length <= 26:
            tabs = "\t\t\t"
        elif inst_url_length <= 30:
            tabs = "\t\t\t"
        elif inst_url_length <= 35:
            tabs = "\t\t"
        elif inst_url_length < 39:
            tabs = "\t\t"
        else:
            tabs = "\t"

        print(f"#{inst_url}{tabs}{msg}")

    # END if self.PRINT_TO_CONSOLE:

    with lock: # <--- Must be 'lock' (or whatever name is used in the lambda)
        # START with lock
        logs_array.append([inst_url, msg, helpers.get_current_time()]) 
    # END with lock
# END def log

############################
# PRINT RESPONSE
############################
def print_response(inst_url: str, msg: str, resp):

    reason = resp.reason if "reason" in resp else "RESPONSE DOES NOT HAVE A REASON"

    print(f"{inst_url}: {msg}: {str(resp)} : {str(reason)}")

# END def print_response(inst_url, msg, resp): 