# objects.py
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
import datetime

# =======================================================================
# ABSTRACT OWNER BASE CLASS (FIXED: All core fields are now mandatory)
# =======================================================================

@dataclass
class Owner:
    """Abstract base class representing an entity (User or Group) that can own an object."""
    # These fields are REQUIRED for initialization and have NO defaults.
    id: str
    name: Optional[str] 
    type: Optional[str] 
# END class Owner

# =======================================================================
# INSTANCE CONFIGURATION OBJECTS
# =======================================================================

@dataclass
class Instance:
    """Represents a single Domo instance configuration record loaded from a control dataset."""
    
    # Core Identification
    Instance_Name: str
    Instance_URL: str
    Developer_Token: str
    
    # Secondary Identification and Attributes
    Developer_Token_User: Optional[str] = field(default=None)
    Instance_Abbreviation: Optional[str] = field(default=None)
    Client_Name: Optional[str] = field(default=None)
    Client_ID: Optional[str] = field(default=None)
    Client_Secret: Optional[str] = field(default=None)
    Environment: Optional[str] = field(default=None)
    Region: Optional[str] = field(default=None)
    Type: Optional[str] = field(default=None)
    Level: Optional[str] = field(default=None)
    Description: Optional[str] = field(default=None)
    Instance_Color: Optional[str] = field(default=None)
    Old_Instance: Optional[str] = field(default=None)

    # Sync and Status Flags
    Sync_Datasets_Owners: Optional[str] = field(default=None)
    Sync_User_Landing_Page: Optional[str] = field(default=None)
    Include_in_User_Activity: Optional[str] = field(default=None)
    Show_In_SSO_Portal: Optional[str] = field(default=None)
    Sync_Default_Roles: Optional[str] = field(default=None)
    Sync_Users: Optional[str] = field(default=None)
    Sync_Default_Groups: Optional[str] = field(default=None)
    
    # Dates and Ordering
    Load_Data_Date: Optional[str] = field(default=None)
    Build_Cards_Date: Optional[str] = field(default=None)
    Go_Live_Date: Optional[str] = field(default=None)
    Order: Optional[int] = field(default=None)
    
    # Login Configuration
    Randstad_Login: Optional[str] = field(default=None)
    Login_Type: Optional[str] = field(default=None)
    Client_Login: Optional[str] = field(default=None)
# END class Instance

# =======================================================================
# DOMO OBJECTS
# =======================================================================

@dataclass
class RoleGrant:
    """Represents a single authority (permission) granted to a role."""
    authority: str
    role_ids: List[str] = field(default_factory=list)
    description: Optional[str] = field(default=None)
# END class RoleGrant

@dataclass
class Role:
    """Represents a Domo Role, including its ID, name, and associated grants."""
    id: str
    name: str
    description: Optional[str] = field(default=None)
    is_default: Optional[bool] = field(default=None)
    # grants should be mapped by authority name for easy lookup
    grants: Dict[str, RoleGrant] = field(default_factory=dict)
# END class Role

@dataclass
class Account(Owner):
    """Represents a Domo Integration Account (Data Source Credentials)."""
    # Inherits: id, name, type (all mandatory)
    display_name: Optional[str] = field(default=None)
    entity_type: Optional[str] = field(default=None)
    data_provider_type: Optional[str] = field(default=None)
    valid: Optional[bool] = field(default=None)
    last_modified: Optional[str] = field(default=None)
    owners: List[Owner] = field(default_factory=list) # List of Owner objects
    dataset_count: Optional[int] = field(default=None)
# END class Account

@dataclass
class Group(Owner):
    """Represents a Domo Group."""
    # Inherits: id, name, type (all mandatory)
    group_type: Optional[str] = field(default=None) # e.g., 'open', 'closed', 'dynamic'
    description: Optional[str] = field(default=None)
    owners: List[Owner] = field(default_factory=list) # List of Owner objects
    member_ids: List[str] = field(default_factory=list)
# END class Group

@dataclass
class Dataset:
    """Represents a Domo DataSet."""
    id: str
    name: str
    
    description: Optional[str] = field(default=None)

    data_provider_name: Optional[str] = field(default=None)
    row_count: Optional[int] = field(default=None)
    column_count: Optional[int] = field(default=None)
    owners: List[Owner] = field(default_factory=list) # List of Owner objects
# END class Dataset

@dataclass
class DataDictionary:
    """Represents a Domo DataDictionary."""
    id: str
#     name: str
    
#     description: Optional[str] = field(default=None)

#     data_provider_name: Optional[str] = field(default=None)
#     row_count: Optional[int] = field(default=None)
#     column_count: Optional[int] = field(default=None)
#     owners: List[Owner] = field(default_factory=list) # List of Owner objects
# END class DataDictionary

@dataclass
class User(Owner):
    """Represents a Domo User."""
    # Inherits: id, name, type (all mandatory)
    
    # New mandatory field comes after all inherited mandatory fields.
    email_address: str
    
    # Now fields with defaults
    user_name: Optional[str] = field(default=None)
    role_id: Optional[str] = field(default=None)
    last_activity: Optional[str] = field(default=None)
    groups: List[str] = field(default_factory=list) # List of group IDs
    attributes: Dict[str, List[str]] = field(default_factory=dict) # Key -> List of values
# END class User

@dataclass
class SandboxRepository:
    """Represents a Domo SandboxRepository."""
    
    # New mandatory field comes after all inherited mandatory fields.
    id: str
    name: str
    domain:str
    repo_type:str
    
    # Now fields with defaults
    repositoryContent: Any = field(default=None)
    user_id: Optional[str] = field(default=None)
    access_count: Optional[str] = field(default=None)
    permission: Optional[str] = field(default=None)
    created: Optional[str] = field(default=None)
    updated: Optional[str] = field(default=None)
    seeded: Optional[str] = field(default=None)
    last_commit: Optional[Any] = field(default=None)
    
    deployments: Optional[List['SandboxDeployment']] = field(default=None)
    
    
    def __init__(self, id, name, domain, repo_type, user_id, access_count, repository_content, created, updated, seeded, last_commit, permission, deployments: Any):
        
        self.id = id
        self.name = name
        self.domain = domain
        self.repo_type = repo_type
        self.user_id = user_id,
        self.access_count = access_count

        # Now fields with defaults
        self.repository_content = repository_content,
        self.created = created,
        self.updated = updated,
        self.seeded = seeded,
        self.last_commit = last_commit,
        self.permission = permission,
        
        if deployments is not None and len(deployments) > 0:
            self.deployments = []
            for d in deployments:
                d_obj = SandboxDeployment (
                        repo=self,
                        id=d.get('id', ''),
                        repo_id=d.get('repositoryId', ''),
                        domain=d.get('domain', ''),
                        name=d.get('name', ''),

                        # Now fields with defaults
                        is_source=d.get('isSource', ''),
                        user_id=d.get('userId', ''),
                        created=d.get('created', ''),
                        updated=d.get('updated', ''),

                        last_promotion=d.get('lastPromotion', {}),

                        permission=d.get('permission', '')
                    )     
                
                self.deployments.append(d_obj)
                
            # END for d in deployments:
        # END if deployments is not None and len(deployments) > 0:
        
    # END def __init__(self, repo_id, name, domain, repo_type, userId, accessCount, repositoryContent, created, updated, seeded, lastCommit, permission):
    
    # 1. Equality check based on the unique ID
    def __eq__(self, other):
        if not isinstance(other, SandboxRepository):
            return NotImplemented
        return self.id == other.id
    # END def __eq__(self, other):
    
    # 2. Hash value based on the unique ID
    def __hash__(self):
        # We hash the unique, immutable ID (or a tuple of immutable unique fields)
        return hash(self.id)
    # END def __hash__(self):
        
# END class SandboxRepository

@dataclass
class SandboxDeployment:
    """Represents a Domo SandboxDeployment."""
    
    SandboxRepository: SandboxRepository

    # New mandatory field comes after all inherited mandatory fields.
    id: str
    repository_id: str
    name: str
    domain:str
    
    # Now fields with defaults
    user_id: Optional[str] = field(default=None)
    is_source: bool = field(default=None)
    permission: Optional[str] = field(default=None)
    created: Optional[str] = field(default=None)
    updated: Optional[str] = field(default=None)
    last_promotion: Optional['SandboxLastPromotion'] = field(default=None)
    
    def __init__(self, repo: SandboxRepository, id, repo_id, name, domain, user_id, is_source, created, updated, last_promotion, permission):
        
        self.SandboxRepository = repo
        
        self.id = id
        self.repository_id = repo_id
        self.name = name
        self.domain = domain
        
        # Now fields with defaults
        self.user_id = user_id
        self.is_source = is_source
        self.created = created
        self.updated = updated
        self.permission = permission
        
        self.last_promotion = SandboxLastPromotion (
                        deployment=self,
                        id=last_promotion.get('id', ''),
                        deployment_id=last_promotion.get('deploymentId', ''),
                        commit_id=last_promotion.get('commitId', ''),
                        repository_id=last_promotion.get('repositoryId', ''),
                        user_id=last_promotion.get('userId', ''),
                        commit_name=last_promotion.get('commitName', ''),
                        repository_name=last_promotion.get('repositoryName', ''),
                        started=last_promotion.get('started', ''),
                        completed=last_promotion.get('completed', ''),
                        status=last_promotion.get('status', ''),
                        pusher_event_id=last_promotion.get('pusherEventId', ''),
                        approval_id=last_promotion.get('approvalId', ''),
            
                        promotion_request=last_promotion.get('promotionRequest', {}),
                        promotion_result=last_promotion.get('promotionResult', {})
                    ) 
            
        
    # END def __init__(self, id, repo_id, name, domain, user_id, is_source, repositoryContent, created, updated, seeded, last_promotion, permission):
    
    # 1. Equality check based on the unique ID
    def __eq__(self, other):
        if not isinstance(other, SandboxDeployment):
            return NotImplemented
        return self.id == other.id
    # END def __eq__(self, other):
    
    # 2. Hash value based on the unique ID
    def __hash__(self):
        # We hash the unique, immutable ID (or a tuple of immutable unique fields)
        return hash(self.id)
    # END def __hash__(self):
        
# END class SandboxDeployment

@dataclass
class SandboxLastPromotion:
    """Represents a Domo SandboxLastPromotion."""
    
    SandboxDeployment: SandboxDeployment
    
    # New mandatory field comes after all inherited mandatory fields.
    id: str
    deployment_id: str
    commit_id: str
    repository_id: str
    user_id: str
    commit_name: str
    repository_name: str
    
    # Now fields with defaults
    started: Optional[str] = field(default=None)
    completed: Optional[str] = field(default=None)
    status: Optional[str] = field(default=None)
    pusher_event_id: Optional[str] = field(default=None)
    approval_id: Optional[str] = field(default=None)

    promotion_request: Optional[Any] = field(default=None)
    promotion_result: Optional[Any] = field(default=None)
    
    def __init__(self, deployment: SandboxDeployment, id, deployment_id, commit_id, repository_id, user_id, commit_name, repository_name, started, completed, status, pusher_event_id, approval_id, promotion_request, promotion_result):
        
        self.SandboxDeployment = deployment
        self.id = id
        self.deployment_id = deployment_id
        self.commit_id = commit_id
        self.repository_id = repository_id
        self.user_id = user_id
        self.commit_name = commit_name
        self.repository_name = repository_name
        
        # Now fields with defaults
        self.started = started
        self.completed = completed
        self.status = status
        self.pusher_event_id = pusher_event_id
        self.approval_id = approval_id
        self.promotion_result = promotion_result

        self.promotion_request = SandboxPromotionRequest (
                        last_promotion=self,
                        commit_id=promotion_request.get('commitId', ''),
                        pusher_event_id=promotion_request.get('pusherEventId', ''),
                        approval_id=promotion_request.get('approvalId', ''),
            
                        mapping=promotion_request.get('mapping', '')
                    )
        
    # END def __init__(self, id, deployment_id, commit_id, repository_id, commit_name, repository_name, started, completed, status, pusher_event_id, approval_id, promotion_request, promotion_result):
    
    # 1. Equality check based on the unique ID
    def __eq__(self, other):
        if not isinstance(other, SandboxLastPromotion):
            return NotImplemented
        return self.id == other.id
    # END def __eq__(self, other):
    
    # 2. Hash value based on the unique ID
    def __hash__(self):
        # We hash the unique, immutable ID (or a tuple of immutable unique fields)
        return hash(self.id)
    # END def __hash__(self):
        
# END class SandboxLastPromotion


@dataclass
class SandboxPromotionRequest:
    """Represents a Domo SandboxPromotionRequest."""
    
    SandboxLastPromotion: SandboxLastPromotion

    # New mandatory field comes after all inherited mandatory fields.
    commit_id: str
    mapping: Optional[Any] = field(default=None)
    pusher_event_id: Optional[str] = field(default=None)
    approval_id: Optional[str] = field(default=None)
    
    def __init__(self, last_promotion:SandboxLastPromotion, commit_id, mapping, pusher_event_id, approval_id):

        self.SandboxLastPromotion = last_promotion
        self.commit_id = commit_id
        self.mapping = mapping
        self.pusher_event_id = pusher_event_id
        self.approval_id = approval_id
        
    # END def __init__(self, commit_id, mapping, pusher_event_id, approval_id):
    
    # 1. Equality check based on the unique ID
    def __eq__(self, other):
        if not isinstance(other, SandboxPromotionRequest):
            return NotImplemented
        return self.id == other.id
    # END def __eq__(self, other):
    
    # 2. Hash value based on the unique ID
    def __hash__(self):
        # We hash the unique, immutable ID (or a tuple of immutable unique fields)
        return hash(self.id)
    # END def __hash__(self):
        
# END class SandboxPromotionRequest


