# rap-utils

A collection of helpers for reproducible analytical pipelines.

These mostly work with the [PETL](https://petl.readthedocs.io/en/stable/) package.