---
name: Feature request
about: Suggest an idea for rapids-singlecell
title: "[FEA]"
labels: enhancement
assignees: ''

---

**Is your feature request related to a problem? Please describe.**
A clear and concise description of what the problem is. Ex. I wish I could use rapids-singlecell to do [...]

**Describe the solution you'd like**
A clear and concise description of what you want to happen.

**Is there a CPU based implementation**
A link to an implementation or paper with the suggested functionality
