from __future__ import annotations

from ._method_aucell import aucell
from ._method_mlm import mlm
from ._method_ulm import ulm
from ._method_waggr import waggr
from ._method_zscore import zscore
