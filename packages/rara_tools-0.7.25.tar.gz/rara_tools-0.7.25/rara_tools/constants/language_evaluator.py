COMPONENT_KEY = "language_evaluator"


class Tasks:
    SINGLE = "text_evaluator"


class Queue:
    MAIN = "text_evaluator"