

class SkipRecordException(Exception):
    """Exception to indicate that a record should be skipped during normalization."""
    pass