"""
RareLink Package.

This package contains all submodules and utilities for the RareLink project,
including the CLI and Common Data Model (CDM) implementations.
"""

# This file is intentionally left mostly empty.
# It's needed for Python to recognize the 'src' directory as a package.