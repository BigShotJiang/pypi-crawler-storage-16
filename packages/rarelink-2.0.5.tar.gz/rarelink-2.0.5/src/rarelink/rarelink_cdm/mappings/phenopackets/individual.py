INDIVIDUAL_BLOCK = {
    "id_field": "formal_criteria.snomedct_422549004",
    "date_of_birth_field": "personal_information.snomedct_184099003",
    "time_at_last_encounter_field": "formal_criteria.snomedct_399423000",
    "sex_field": "personal_information.snomedct_281053000",
    "karyotypic_sex_field": "personal_information.snomedct_1296886006",
    "gender_field": "personal_information.snomedct_263495000",
}