MEASUREMENT_BLOCK = {
    "redcap_repeat_instrument" : "rarelink_6_3_measurements",
    "assay_field": "ncit_c60819",
    "value_field": "ncit_c25712",
    "value_unit_field": "ncit_c92571",
    "time_observed_field": "ncit_c82577"
}