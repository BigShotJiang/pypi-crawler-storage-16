MEDICAL_ACTION_BLOCK = {
    "procedure_field_1": "measurements.snomedct_122869004",
    "procedure_field_2": "measurements.snomedct_122869004_maxo",
    "procedure_field_1_date": "measurements.ncit_c82577",
    "procedure_field_2_date": "measurements.ncit_c82577",
}