# Execute the following command from the project.root.directory (../../)

docker build -f docker/fluentd/Dockerfile -t srdc/tofhir-fluentd:latest .