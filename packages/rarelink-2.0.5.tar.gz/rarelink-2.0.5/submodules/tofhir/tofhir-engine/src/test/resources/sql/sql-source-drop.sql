DROP TABLE patients;

DROP TABLE otherobservations;

DROP TABLE care_site;

DROP TABLE location;

DROP TABLE procedure_occurrence;

DROP TABLE concept;