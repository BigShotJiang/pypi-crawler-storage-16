"""Bundled presets for rassumfrassum."""
