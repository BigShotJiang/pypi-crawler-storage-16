from setuptools import setup


use_scm = {"write_to": "raster_loader/_version.py"}
setup(use_scm_version=use_scm)
