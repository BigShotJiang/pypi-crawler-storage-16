---
name: Enhancement Request
about: A high-level description of a feature or other enhancement you'd like
title: ''
labels: ''
---

**Motivation**
A clear and concise description of what benefit you would get from this enhancement.

**Summary**
A clear and concise description of what you want to happen, at a high level.
