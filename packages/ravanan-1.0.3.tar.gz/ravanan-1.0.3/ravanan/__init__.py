"""
Ravanan - The 10-Headed Scholar King
A powerful terminal-based web browser

Created by: Krishna D
License: MIT
"""

__version__ = '1.0.1'
__author__ = 'Krishna D'
__email__ = 'your.email@example.com'

from .main import main

__all__ = ['main']
