# Ravanan - The 10-Headed Web Browser
# Named after the mythological character with 10 heads, symbolizing
# the ability to view web content from multiple perspectives
__version__ = "1.0.0"
__author__ = "Krishna D"
__description__ = "A powerful text-based web browser for the terminal"
