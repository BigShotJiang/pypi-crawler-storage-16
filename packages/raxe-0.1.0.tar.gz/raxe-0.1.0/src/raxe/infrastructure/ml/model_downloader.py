"""Model downloader for fetching L2 models post-installation.

Downloads ML models from RAXE CDN or HuggingFace Hub after pip install.
Models are too large for PyPI (317MB vs 100MB limit), so we download on-demand.
"""
from __future__ import annotations

import hashlib
import logging
import shutil
import tarfile
import tempfile
from pathlib import Path
from typing import Callable
from urllib.request import urlopen
from urllib.error import HTTPError, URLError

logger = logging.getLogger(__name__)

# Model hosting configuration
# Models are hosted on GitHub Releases for the raxe-ai/raxe-models repo
# Override with RAXE_MODEL_URL env var for testing/mirrors
import os
MODEL_BASE_URL = os.environ.get(
    "RAXE_MODEL_URL",
    "https://github.com/raxe-ai/raxe-models/releases/download/v0.0.1"
)

# Model registry - maps model names to download URLs and metadata
# Only INT8 model is available for Community Edition (FP16 is internal dev only)
MODEL_REGISTRY = {
    "threat_classifier_int8": {
        "name": "Threat Classifier INT8",
        "description": "Fast INT8 quantized model (~107MB). Optimized for CPU inference.",
        "size_mb": 107,
        "url": f"{MODEL_BASE_URL}/threat_classifier_int8_deploy.tar.gz",
        "sha256": None,  # Will be set when models are published
        "folder_name": "threat_classifier_int8_deploy",
    },
}

# Default model for automatic download
DEFAULT_MODEL = "threat_classifier_int8"


def get_models_directory() -> Path:
    """Get the models directory path.

    Models are stored in ~/.raxe/models/ for:
    - User-writable location (pip packages are often read-only)
    - Persistence across package upgrades
    - Single source of truth for downloaded models

    Returns:
        Path to models directory
    """
    models_dir = Path.home() / ".raxe" / "models"
    models_dir.mkdir(parents=True, exist_ok=True)
    return models_dir


def get_package_models_directory() -> Path:
    """Get the package's bundled models directory.

    This is where models live if bundled with the package (dev mode).
    For pip install, this directory will be empty (models too large).

    Returns:
        Path to package models directory
    """
    return Path(__file__).parent.parent.parent / "domain" / "ml" / "models"


def should_use_bundled_models() -> bool:
    """Check if bundled (package) models should be searched.

    By default, bundled models in the package directory are included
    in the search path. This is useful for development where models
    are pre-bundled.

    For production pip installs, the package directory is empty anyway
    (models too large for PyPI), so this has no effect.

    Set RAXE_SKIP_BUNDLED_MODELS=1 to skip bundled models, which is
    useful for testing the fresh install download UX in dev environments.

    Returns:
        True if bundled models should be searched, False to skip them.

    Environment Variables:
        RAXE_SKIP_BUNDLED_MODELS: If set to any non-empty value, skip
            the package models directory. Useful for testing fresh
            install UX in development environments.

    Example:
        # Test fresh install behavior in dev
        RAXE_SKIP_BUNDLED_MODELS=1 raxe scan "test"
    """
    return not os.environ.get("RAXE_SKIP_BUNDLED_MODELS")


def is_model_installed(model_name: str) -> bool:
    """Check if a model is already installed.

    Checks ~/.raxe/models/ (primary) and package directory (dev mode).

    Args:
        model_name: Model identifier (e.g., "threat_classifier_int8")

    Returns:
        True if model is installed and ready to use
    """
    if model_name not in MODEL_REGISTRY:
        return False

    folder_name = MODEL_REGISTRY[model_name]["folder_name"]

    # Check user models directory (primary location for downloads)
    user_models = get_models_directory()
    user_model_path = user_models / folder_name
    if user_model_path.exists() and (user_model_path / "manifest.yaml").exists():
        return True

    # Check package models directory (dev mode only)
    if should_use_bundled_models():
        package_models = get_package_models_directory()
        package_model_path = package_models / folder_name
        if package_model_path.exists() and (package_model_path / "manifest.yaml").exists():
            return True

    return False


def get_installed_models() -> list[str]:
    """Get list of installed model names.

    Returns:
        List of installed model identifiers
    """
    installed = []
    for model_name in MODEL_REGISTRY:
        if is_model_installed(model_name):
            installed.append(model_name)
    return installed


def get_available_models() -> list[dict]:
    """Get list of all available models with metadata.

    Returns:
        List of model metadata dicts
    """
    models = []
    for model_name, metadata in MODEL_REGISTRY.items():
        model_info = {
            "id": model_name,
            "name": metadata["name"],
            "description": metadata["description"],
            "size_mb": metadata["size_mb"],
            "installed": is_model_installed(model_name),
            "is_default": model_name == DEFAULT_MODEL,
        }
        models.append(model_info)
    return models


def download_model(
    model_name: str,
    progress_callback: Callable[[int, int], None] | None = None,
    force: bool = False,
) -> Path:
    """Download and install a model.

    Args:
        model_name: Model identifier (e.g., "threat_classifier_int8")
        progress_callback: Optional callback(downloaded_bytes, total_bytes)
        force: Force re-download even if model exists

    Returns:
        Path to installed model directory

    Raises:
        ValueError: If model_name is not recognized
        RuntimeError: If download or installation fails
    """
    if model_name not in MODEL_REGISTRY:
        available = ", ".join(MODEL_REGISTRY.keys())
        raise ValueError(f"Unknown model: {model_name}. Available: {available}")

    metadata = MODEL_REGISTRY[model_name]
    folder_name = metadata["folder_name"]
    target_dir = get_models_directory() / folder_name

    # Check if already installed
    if not force and is_model_installed(model_name):
        logger.info(f"Model {model_name} already installed at {target_dir}")
        return target_dir

    # Remove existing if force
    if force and target_dir.exists():
        logger.info(f"Removing existing model at {target_dir}")
        shutil.rmtree(target_dir)

    url = metadata["url"]
    expected_sha256 = metadata.get("sha256")

    logger.info(f"Downloading {model_name} from {url}")

    # Download to temp file
    with tempfile.NamedTemporaryFile(suffix=".tar.gz", delete=False) as tmp_file:
        tmp_path = Path(tmp_file.name)

        try:
            # Download with progress
            _download_file(url, tmp_path, progress_callback)

            # Verify checksum if provided
            if expected_sha256:
                actual_sha256 = _calculate_sha256(tmp_path)
                if actual_sha256 != expected_sha256:
                    raise RuntimeError(
                        f"Checksum mismatch for {model_name}. "
                        f"Expected: {expected_sha256}, Got: {actual_sha256}"
                    )

            # Extract archive
            logger.info(f"Extracting to {target_dir}")
            _extract_tarball(tmp_path, target_dir.parent)

            # Verify installation
            if not (target_dir / "manifest.yaml").exists():
                raise RuntimeError(
                    f"Model extraction failed: manifest.yaml not found in {target_dir}"
                )

            logger.info(f"Model {model_name} installed successfully at {target_dir}")
            return target_dir

        finally:
            # Cleanup temp file
            if tmp_path.exists():
                tmp_path.unlink()


def _download_file(
    url: str,
    dest_path: Path,
    progress_callback: Callable[[int, int], None] | None = None,
) -> None:
    """Download a file with optional progress callback.

    Args:
        url: URL to download from
        dest_path: Destination file path
        progress_callback: Optional callback(downloaded_bytes, total_bytes)

    Raises:
        RuntimeError: If download fails
    """
    try:
        with urlopen(url, timeout=60) as response:
            total_size = int(response.headers.get("Content-Length", 0))
            downloaded = 0
            chunk_size = 8192

            with open(dest_path, "wb") as f:
                while True:
                    chunk = response.read(chunk_size)
                    if not chunk:
                        break

                    f.write(chunk)
                    downloaded += len(chunk)

                    if progress_callback:
                        progress_callback(downloaded, total_size)

    except HTTPError as e:
        raise RuntimeError(f"HTTP error downloading model: {e.code} {e.reason}") from e
    except URLError as e:
        raise RuntimeError(f"Failed to download model: {e.reason}") from e
    except Exception as e:
        raise RuntimeError(f"Download failed: {e}") from e


def _calculate_sha256(file_path: Path) -> str:
    """Calculate SHA-256 checksum of a file.

    Args:
        file_path: Path to file

    Returns:
        Hex-encoded SHA-256 hash
    """
    sha256 = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            sha256.update(chunk)
    return sha256.hexdigest()


def _extract_tarball(archive_path: Path, dest_dir: Path) -> None:
    """Extract a tarball to destination directory.

    Args:
        archive_path: Path to .tar.gz file
        dest_dir: Directory to extract into

    Raises:
        RuntimeError: If extraction fails
    """
    try:
        with tarfile.open(archive_path, "r:gz") as tar:
            # Security: check for path traversal attacks
            for member in tar.getmembers():
                member_path = dest_dir / member.name
                if not str(member_path.resolve()).startswith(str(dest_dir.resolve())):
                    raise RuntimeError(
                        f"Tarball contains unsafe path: {member.name}"
                    )

            tar.extractall(dest_dir)

    except tarfile.TarError as e:
        raise RuntimeError(f"Failed to extract model archive: {e}") from e


def download_default_model(
    progress_callback: Callable[[int, int], None] | None = None,
    force: bool = False,
) -> Path:
    """Download the default model (INT8 for best performance/size ratio).

    Args:
        progress_callback: Optional callback(downloaded_bytes, total_bytes)
        force: Force re-download even if model exists

    Returns:
        Path to installed model directory
    """
    return download_model(DEFAULT_MODEL, progress_callback, force)


def ensure_model_available(
    model_name: str | None = None,
    auto_download: bool = True,
    progress_callback: Callable[[int, int], None] | None = None,
) -> Path | None:
    """Ensure a model is available, downloading if necessary.

    Args:
        model_name: Model to ensure (default: DEFAULT_MODEL)
        auto_download: Whether to automatically download if missing
        progress_callback: Optional progress callback for download

    Returns:
        Path to model directory, or None if not available and auto_download=False
    """
    model_name = model_name or DEFAULT_MODEL

    if is_model_installed(model_name):
        # Return the path where it's installed
        folder_name = MODEL_REGISTRY[model_name]["folder_name"]

        # Check user directory first
        user_path = get_models_directory() / folder_name
        if user_path.exists():
            return user_path

        # Check package directory
        package_path = get_package_models_directory() / folder_name
        if package_path.exists():
            return package_path

    if auto_download:
        return download_model(model_name, progress_callback)

    return None
