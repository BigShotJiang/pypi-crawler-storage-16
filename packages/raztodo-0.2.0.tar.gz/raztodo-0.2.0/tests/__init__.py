"""Test suite for raztodo application."""
