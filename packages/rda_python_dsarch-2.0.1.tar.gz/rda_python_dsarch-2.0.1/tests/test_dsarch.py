# test_dsarch.py

import pytest

def test_something():
   import rda_python_dsarch.PgArch
   import rda_python_dsarch.PgMeta
   import rda_python_dsarch.pg_arch
   import rda_python_dsarch.pg_meta
   import rda_python_dsarch.dsarch
