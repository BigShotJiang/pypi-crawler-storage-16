# test

import pytest

def test_dsquasar():
    import rda_python_dsquasar.dsquasar
