# test_dsrqst.py

import pytest

def test_something():
   import rda_python_dsrqst.PgRqst
   import rda_python_dsrqst.PgRDARqst
   import rda_python_dsrqst.PgSubset
   import rda_python_dsrqst.pg_rqst
   import rda_python_dsrqst.pg_rdarqst
   import rda_python_dsrqst.pg_subset
   import rda_python_dsrqst.dsrqst
