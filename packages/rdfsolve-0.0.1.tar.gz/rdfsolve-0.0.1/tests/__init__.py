"""Tests for :mod:`rdfsolve`."""
