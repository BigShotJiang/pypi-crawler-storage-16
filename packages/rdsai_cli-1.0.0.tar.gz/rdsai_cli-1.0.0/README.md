# RDSAI CLI
![img.png](docs/img.png)

RDSAI CLI is a next‑generation, AI‑powered RDS CLI that transforms how you interact with the database. You describe your intent in natural language or SQL, and the AI agent performs hybrid processing of both: orchestrating diagnostic tools, analyzing execution plans, and executing queries — all without leaving your terminal. From performance troubleshooting to schema exploration, it handles the complexity so you can focus on what truly matters.
## ✨ Features

- **AI Assistant for MySQL** — Ask in natural language (English / 中文均可), get optimized SQL, diagnostics, and explanations
- **Rich Diagnostic Toolset** — 14+ built-in tools for performance, locks, replication, configuration, and more
- **Multi‑Model LLM Support** — Work with multiple providers and models (Qwen, OpenAI, DeepSeek, Anthropic, Gemini, OpenAI‑compatible) and switch via `/model`, with thinking mode support for transparent reasoning and decision-making processes
- **Memory** — Learns your schema and business context into Markdown files under `~/.rdsai-cli/memories`
- **Interactive TUI Shell** — Prompt-toolkit + Rich-based shell with colors, panels, and status display
- **Smart SQL Handling** — Auto-detects SQL vs natural language, supports vertical output (`\G`), query history, and context injection
- **Safety First** — Read-only by default; DDL/DML requires confirmation (unless YOLO mode)
- **YOLO Mode** — One toggle to auto-approve all actions when you know what you’re doing
- **SSL/TLS Support** — Full SSL configuration (CA, client cert, key, mode)
- **Context Compaction** — Automatic conversation compaction to save LLM tokens

## 📦 Installation

### Requirements

- Python **3.13+**
- MySQL **5.7+** or **8.0+**
- Network access to your MySQL instance
- API access to at least one LLM provider (Qwen / OpenAI / DeepSeek / Anthropic / Gemini / OpenAI-compatible)

### Install from PyPI

```bash
# using uv (recommended)
uv pip install rdsai-cli

# Or Using pip
pip install rdsai-cli
```

After installation, the `rdsai` command will be available globally.

### Install from source (for development)

```bash
git clone <repository-url>
cd rdsai-cli

# Using uv
uv sync
uv sync --extra dev  # with dev dependencies

# Or using pip
pip install -e .
```

For development installations, use `uv run rdsai` or activate the virtual environment first.

## 🚀 Quick Start

### 1. Launch the CLI

```bash
# Start without connection (interactive mode)
rdsai

# Connect via command line arguments
rdsai --host localhost -u root -p secret -D mydb

# With SSL
rdsai --host db.example.com -u admin -p secret \
  --ssl-mode REQUIRED --ssl-ca /path/to/ca.pem

# Custom port
rdsai --host localhost -P 3307 -u root -p secret
```

You can start the CLI **without any connection parameters** and connect later using the interactive `/connect` command:

```text
$ rdsai
> /connect
# Interactive form will prompt for Host, Port, Username, Password, Database
```

Connection options:

| Option       | Short | Description                          | Default |
| ------------ | ----- | ------------------------------------ | ------- |
| `--host`     | `-h`  | Database host                        |         |
| `--user`     | `-u`  | Username                             |         |
| `--password` | `-p`  | Password                             |         |
| `--port`     | `-P`  | Port                                 | `3306`  |
| `--database` | `-D`  | Default database                     |         |
| `--yolo`     | `-y`  | Auto-approve all actions             | off     |
| `--ssl-mode` |       | SSL mode¹                            |         |
| `--ssl-ca`   |       | CA certificate path                  |         |
| `--ssl-cert` |       | Client certificate path              |         |
| `--ssl-key`  |       | Client key path                      |         |

¹ SSL modes: `DISABLED`, `PREFERRED`, `REQUIRED`, `VERIFY_CA`, `VERIFY_IDENTITY`

### 2. Configure LLM

Use the interactive wizard to configure your LLM provider:

```text
mysql> /setup
```

The wizard will walk you through:

1. **Select Platform** — Qwen, OpenAI, DeepSeek, Anthropic, Gemini, or a generic OpenAI-compatible endpoint
2. **Configure API** — Base URL (if needed), API Key, Model Name
3. **Auto-detect Context Size** — Attempts to fetch model `max_context_size` (or falls back to known defaults)
4. **Save & Apply** — Configuration is persisted and the shell is reloaded automatically

Configuration file:

- Path: `~/.rdsai-cli/config.json`
- Contains: providers, models, default model, and loop-control settings

You can edit this JSON manually for advanced setups.

## 📖 Usage

### Natural Language

Just type what you need; the agent will call tools, run SQL (with confirmation), and explain results:

```text
mysql> analyze index usage on users table
mysql> show me slow queries from the last hour
mysql> check for lock waits
mysql> design an orders table for e-commerce
mysql> explain why this query is slow: SELECT * FROM users WHERE name LIKE '%john%'
mysql> find tables without primary keys
mysql> show me the replication status
```

### SQL Execution

Plain SQL is executed directly against MySQL, with results formatted via Rich:

```text
mysql> SELECT COUNT(*) FROM users;
mysql> SHOW CREATE TABLE orders;
mysql> EXPLAIN SELECT * FROM users WHERE email = 'test@example.com';
mysql> SELECT * FROM users LIMIT 10\G   -- vertical format
```

The shell automatically:

- Detects whether input is **SQL** or **natural language**
- Records query execution history
- Injects the last query result into the AI context when helpful

### Shell & Meta Commands

Meta commands start with `/` and never hit MySQL directly.

| Command       | Alias          | Description                                      |
| ------------- | -------------- | ------------------------------------------------ |
| `/connect`    | `/conn`        | Connect to MySQL database interactively          |
| `/disconnect` | `/disconn`     | Disconnect from current database                 |
| `/help`       | `/h`, `/?`     | Show help and current status                     |
| `/exit`       | `/quit`        | Exit CLI                                         |
| `/version`    |                | Show CLI version                                 |
| `/setup`      |                | Interactive LLM configuration wizard             |
| `/reload`     |                | Reload configuration                             |
| `/clear`      | `/reset`       | Clear AI context (start fresh)                   |
| `/compact`    |                | Compact AI context to save tokens                |
| `/yolo`       |                | Toggle YOLO mode (auto-approve actions)          |
| `/history`    | `/hist`        | Show SQL query execution history                 |
| `/init`       |                | Initialize Memory Bank for current database      |
| `/memory`     | `/mem`         | Show / locate / clear Memory Bank                |
| `/model`      | `/models`      | Manage LLM models (list/use/delete/info)         |

You can still run shell commands via the built-in shell mode when prefixed appropriately (see in-shell help).

## 🛠️ Diagnostic Tools

The AI agent can call the following tools to analyze your database:

| Tool                  | Description                                           |
| --------------------- | ----------------------------------------------------- |
| **TableStructure**    | View table schemas, columns, types, and constraints  |
| **TableIndex**        | Analyze index definitions and potential issues       |
| **TableStatus**       | Inspect table size, row count, engine info           |
| **MySQLExplain**      | Analyze query execution plans                        |
| **ShowProcess**       | View running processes and current queries           |
| **SlowLog**           | Read and summarize slow query logs                   |
| **InnodbStatus**      | Inspect InnoDB engine status and internal metrics    |
| **Transaction**       | Monitor active transactions and lock state           |
| **InformationSchema** | Query `INFORMATION_SCHEMA` for metadata              |
| **PerformanceSchema** | Query `performance_schema` for low-level metrics     |
| **PerfStatistics**    | Aggregated performance statistics and hotspots       |
| **KernelParameter**   | View and explain MySQL server variables              |
| **ReplicaStatus**     | Check replication status and lag                     |
| **DDLExecutor**       | Safely execute DDL/DML with explicit confirmation    |

You can ask for high-level tasks (e.g. “find missing indexes on hot tables”) and the agent will combine these tools for you.

## 🧠 Memory

The Memory learns your schema and stores a Markdown knowledge file per database under `~/.rdsai-cli/memories`:

- **Schema Overview** — What this database is for
- **Table Grouping** — Tables grouped by business domain
- **Relationships** — Key foreign-key relationships and graph
- **Design Patterns** — Naming conventions, soft delete patterns, timestamps
- **Custom Notes** — Editable section for your own business context

Typical workflow:

```text
mysql> /init            # Explore schema and generate memory
mysql> /memory          # Show formatted memory content
mysql> /memory location # Show the Markdown file path
mysql> /memory clear    # Delete memory for current database
```

Memory files are plain Markdown, so you can version-control and manually edit them if needed.

## ⚡ YOLO Mode

YOLO mode skips confirmation prompts for potentially destructive actions (DDL/DML).

```bash
# Enable at startup
rdsai --host localhost -u root -p secret --yolo
```

```text
# Toggle at runtime
mysql> /yolo on
mysql> /yolo off
```

Use this **only** in non-production or   when you fully trust the actions being taken.

## 🔒 Security Notes

1. **Read-Only by Default** — The AI runs in a conservative mode; DDL/DML require explicit confirmation unless YOLO is on.
2. **Confirmation Required** — Every write operation surfaces the exact SQL for review before execution.
3. **Credential Storage** — API keys and model settings are stored in `~/.rdsai-cli/config.json`; protect that file with proper OS permissions.
4. **Transaction Safety** — The shell warns you about uncommitted transactions when you attempt to exit.


Enjoy building and debugging RDS systems with an AI agent in your terminal 😁.
