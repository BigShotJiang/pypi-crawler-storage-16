"""Main application module for RDS AI CLI."""

from __future__ import annotations

import contextlib
import warnings
from collections.abc import Generator
from pathlib import Path
from typing import Any, TYPE_CHECKING

from pydantic import SecretStr
from loop.agentspec import DEFAULT_AGENT_FILE
from config import LLMModel, LLMProvider, load_config
from llm.llm import create_llm
from config import Session, get_share_dir
from loop.agent import load_agent
from loop.neoloop import NeoLoop
from loop.runtime import Runtime
from utils.logging import StreamToLogger, logger

if TYPE_CHECKING:
    from database import ConnectionContext
else:
    # Avoid circular import at runtime  
    ConnectionContext = Any

# Backward compatibility alias
DatabaseConnectionContext = ConnectionContext


def enable_logging(debug: bool = False) -> None:
    logger.add(
        get_share_dir() / "logs" / "rdsai-cli.log",
        level="TRACE" if debug else "INFO",
        rotation="20 MB",
        retention="5 days",
    )


class MySQLCLI:
    @staticmethod
    async def create(
            session: Session,
            *,
            yolo: bool = False,
            config_file: Path | None = None,
    ) -> MySQLCLI:
        """Create a MySQLCLI instance.

        Args:
            session: A session created by `Session.create`.
            yolo: Approve all actions without confirmation. Defaults to False.
            config_file: Path to the configuration file. Defaults to None.

        Raises:
            FileNotFoundError: When the agent file is not found.
            ConfigError(CLIException): When the configuration is invalid.
            AgentSpecError(CLIException): When the agent specification is invalid.
        """
        config = load_config(config_file)
        logger.info("Loaded config: {config}", config=config)

        model: LLMModel | None = None
        provider: LLMProvider | None = None

        # use config file
        if config.default_model:
            # no --model specified && default model is set in config
            model = config.models[config.default_model]
            provider = config.providers[model.provider]

        if not model:
            model = LLMModel(provider="", model="", max_context_size=0)
            provider = LLMProvider(type="qwen", base_url="", api_key=SecretStr(""))

        assert provider is not None
        assert model is not None

        if not provider.api_key or not model.model:
            llm = None
        else:
            logger.info("Using LLM provider: {provider}", provider=provider)
            logger.info("Using LLM model: {model}", model=model)
            llm = create_llm(provider, model)

        runtime = await Runtime.create(config, llm, session)
        agent = await load_agent(DEFAULT_AGENT_FILE, runtime)

        # Create NeoLoop with LangGraph (no Context needed - uses checkpointer)
        loop = NeoLoop(
            agent,
            runtime,
            yolo=yolo,
        )

        return MySQLCLI(loop, runtime)

    def __init__(
            self,
            _loop: NeoLoop,
            _runtime: Runtime,
    ) -> None:
        self._loop = _loop
        self._runtime = _runtime

    @property
    def loop(self) -> NeoLoop:
        """Get the NeoLoop instance."""
        return self._loop

    @property
    def session(self) -> Session:
        """Get the Session instance."""
        return self._runtime.session

    @property
    def _db_connection(self) -> "DatabaseConnectionContext | None":
        """Get the database connection from session."""
        return self._runtime.session.db_connection

    def _build_welcome_info(self) -> list:
        """Build welcome information for the shell."""
        from config import VERSION
        from ui.shell import WelcomeInfoItem

        welcome_info = [
            WelcomeInfoItem(name="Version", value=VERSION),
            WelcomeInfoItem(name="Session", value=self._runtime.session.id),
        ]
        # Add model information
        if not self._runtime.llm:
            welcome_info.append(WelcomeInfoItem(
                name="Model",
                value="not set, send /setup to configure",
                level=WelcomeInfoItem.Level.WARN,
            ))
        else:
            welcome_info.append(WelcomeInfoItem(
                name="Model",
                value=self._loop.model_name,
                level=WelcomeInfoItem.Level.INFO,
            ))
        # Add database connection info
        if self._db_connection:
            level = WelcomeInfoItem.Level.WARN if not self._db_connection.is_connected else WelcomeInfoItem.Level.INFO
            welcome_info.append(WelcomeInfoItem(
                name="Database",
                value=self._db_connection.display_name,
                level=level
            ))
        else:
            # Not connected - guide user to connect
            welcome_info.append(WelcomeInfoItem(
                name="Database",
                value="Not connected. Use /connect to connect.",
                level=WelcomeInfoItem.Level.WARN,
            ))

        return welcome_info

    @contextlib.contextmanager
    def _app_env(self) -> Generator[None]:
        # to ignore possible warnings from dateparser
        warnings.filterwarnings("ignore", category=DeprecationWarning)
        with contextlib.redirect_stderr(StreamToLogger()):
            yield

    async def run_shell_mode(self) -> bool:
        from ui.shell import ShellApp

        welcome_info = self._build_welcome_info()

        with self._app_env():
            db_service = self._db_connection.db_service if self._db_connection else None
            query_history = self._db_connection.query_history if self._db_connection else None

            app = ShellApp(self._loop, welcome_info=welcome_info, db_service=db_service, query_history=query_history)
            try:
                return await app.run()
            finally:
                # Clean up database connection
                if db_service:
                    db_service.disconnect()
