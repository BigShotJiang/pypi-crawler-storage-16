"""Agent runtime configuration and initialization."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from config import Config
from llm.llm import LLM
from config import Session


@dataclass(frozen=True, slots=True, kw_only=True)
class BuiltinSystemPromptArgs:
    """Builtin system prompt arguments."""

    CLI_NOW: str



@dataclass(slots=True, kw_only=True)
class Runtime:
    """Agent runtime configuration.
    
    This is a simplified runtime that only contains configuration and LLM.
    State management is handled by LangGraph's checkpointer.
    """

    config: Config
    llm: LLM | None
    session: Session
    builtin_args: BuiltinSystemPromptArgs

    def set_llm(self, llm: LLM | None) -> None:
        """Switch to a different LLM at runtime.
        
        Args:
            llm: The new LLM instance to use.
        """
        self.llm = llm

    @staticmethod
    async def create(
        config: Config,
        llm: LLM | None,
        session: Session,
    ) -> Runtime:
        """Create a new runtime instance.
        
        Args:
            config: Application configuration.
            llm: Language model instance (optional).
            session: Current session.
            
        Returns:
            Initialized Runtime instance.
        """
        return Runtime(
            config=config,
            llm=llm,
            session=session,
            builtin_args=BuiltinSystemPromptArgs(
                CLI_NOW=datetime.now().astimezone().isoformat(),
            ),
        )
