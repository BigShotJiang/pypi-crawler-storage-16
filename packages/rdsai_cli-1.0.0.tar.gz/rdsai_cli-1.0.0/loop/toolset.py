"""Tool system types and execution logic."""

from __future__ import annotations
import json
from typing import override
from contextvars import ContextVar
from typing import Generic, Any
from pydantic import BaseModel
from loop.types import T
from loop.types import ContentPart, ToolCall, FunctionBody


# --- Tool Results ---
class ToolError(BaseModel):
    """Tool execution error result."""
    message: str
    output: str | list[ContentPart] | ContentPart | None = None
    brief: str | None = None


class ToolRuntimeError(ToolError):
    """Runtime error during tool execution."""
    pass


class ToolOk(BaseModel):
    """Successful tool execution result."""
    message: str | None = None
    output: str | list[ContentPart] | ContentPart = ""
    brief: str | None = None


class ToolResult(BaseModel):
    """Result of a tool call execution."""
    tool_call_id: str
    name: str | None = None 
    result: ToolOk | ToolError


# Type aliases
ToolReturnType = ToolOk | ToolError
HandleResult = ToolResult


# --- Tool Definitions ---
class BaseTool(Generic[T]):
    """Base class for all tools with typed parameters.
    
    Usage:
        class MyTool(BaseTool[MyParams]):
            name = "MyTool"
            params = MyParams
            ...
    
    For tools without strict type checking:
        class MyTool(BaseTool):  # Equivalent to BaseTool[Any]
            ...
    """
    
    name: str
    description: str
    params: type[T]

    def __init__(self, **kwargs):
        pass

    async def __call__(self, params: T) -> ToolReturnType:
        """Execute the tool with given parameters."""
        raise NotImplementedError
    
    @property
    def parameters(self) -> dict[str, Any]:
        """Get tool parameter schema."""
        if hasattr(self, "params") and issubclass(self.params, BaseModel):
            return self.params.model_json_schema()
        return {}
    
    def __eq__(self, other: Any) -> bool:
        if not isinstance(other, BaseTool):
            return False
        return (
            self.name == other.name and
            self.description == other.description and
            self.parameters == other.parameters
        )
    
    def __repr__(self) -> str:
        return f"BaseTool(name={self.name!r}, description={self.description!r}, parameters={self.parameters!r})"



# --- Toolsets ---
class Toolset:
    """Collection of tools."""
    
    tools: list[BaseTool]
    
    def __init__(self, tools=None):
        self.tools = tools or []
    
    def __add__(self, other):
        """Add tools to create new toolset."""
        new_tools = list(self.tools)
        if isinstance(other, Toolset):
            new_tools.extend(other.tools)
        elif isinstance(other, list):
            new_tools.extend(other)
        else:
            new_tools.append(other)
        return Toolset(new_tools)
    
    def __iadd__(self, other):
        """In-place addition to modify self.tools directly."""
        if isinstance(other, Toolset):
            self.tools.extend(other.tools)
        elif isinstance(other, list):
            self.tools.extend(other)
        else:
            self.tools.append(other)
        return self
    
    def __iter__(self):
        return iter(self.tools)


class SimpleToolset(Toolset):
    """Toolset with built-in tool execution handling."""
    
    async def handle(self, tool_call: ToolCall) -> HandleResult:
        """Execute a tool call and return the result."""
        fname = tool_call.function.name if isinstance(tool_call.function, FunctionBody) else tool_call.function["name"]
        fargs_str = tool_call.function.arguments if isinstance(tool_call.function, FunctionBody) else tool_call.function["arguments"]

        try:
            tool_args = json.loads(fargs_str)
        except (json.JSONDecodeError, TypeError):
            return ToolResult(
                    tool_call_id=tool_call.id,
                    name=fname,
                    result=ToolRuntimeError(message=f"Invalid JSON arguments: {fargs_str}")
            )

        tool_map = {t.name: t for t in self.tools}
        if fname in tool_map:
            tool = tool_map[fname]
            try:
                params_obj = tool.params(**tool_args)
                tool_ret = await tool(params_obj)
                return ToolResult(
                    tool_call_id=tool_call.id,
                    name=fname,
                    result=tool_ret
                )
            except Exception as e:
                return ToolResult(
                        tool_call_id=tool_call.id,
                        name=fname,
                        result=ToolRuntimeError(message=str(e))
                )
        else:
            return ToolResult(
                tool_call_id=tool_call.id,
                name=fname,
                result=ToolRuntimeError(message=f"Tool {fname} not found")
            )

current_tool_call = ContextVar[ToolCall | None]("current_tool_call", default=None)


def get_current_tool_call_or_none() -> ToolCall | None:
    """
    Get the current tool call or None.
    Expect to be not None when called from a `__call__` method of a tool.
    """
    return current_tool_call.get()


class CustomToolset(SimpleToolset):

    @override
    def handle(self, tool_call: ToolCall) -> HandleResult:
        token = current_tool_call.set(tool_call)
        try:
            return super().handle(tool_call)
        finally:
            current_tool_call.reset(token)
