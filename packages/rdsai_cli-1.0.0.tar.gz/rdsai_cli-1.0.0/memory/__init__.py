"""Memory module for database context management.

This module provides:
- Database schema exploration
- Memory document generation (with LLM analysis)
- Pluggable storage backends (file, vector database, etc.)
- Context loading for AI conversations
"""

from .types import (
    DatabaseMemory,
    ColumnInfo,
    IndexInfo,
    ForeignKeyInfo,
    TableInfo,
    DatabaseStatistics,
    DatabaseSchemaSnapshot,
)
from .explorer import DatabaseExplorer, TableExploreProgress
from .generator import MemoryDocumentGenerator
from .loader import load_database_memory
from .storage import (
    MemoryStorage,
    FileMemoryStorage,
    get_default_storage,
)

__all__ = [
    # Types
    "DatabaseMemory",
    "ColumnInfo",
    "IndexInfo",
    "ForeignKeyInfo",
    "TableInfo",
    "DatabaseStatistics",
    "DatabaseSchemaSnapshot",
    # Core classes
    "DatabaseExplorer",
    "TableExploreProgress",
    "MemoryDocumentGenerator",
    # Storage
    "MemoryStorage",
    "FileMemoryStorage",
    "get_default_storage",
    # Utilities
    "load_database_memory",
]

