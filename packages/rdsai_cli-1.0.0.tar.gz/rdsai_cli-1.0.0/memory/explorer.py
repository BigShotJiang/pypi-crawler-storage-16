"""Database schema explorer for collecting comprehensive metadata."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Dict, Generator, List, Optional, TYPE_CHECKING

from .types import (
    ColumnInfo,
    IndexInfo,
    ForeignKeyInfo,
    TableInfo,
    DatabaseStatistics,
    DatabaseSchemaSnapshot,
)
from utils.logging import logger

if TYPE_CHECKING:
    from database.database_service import DatabaseService


@dataclass
class TableExploreProgress:
    """Progress information for table exploration."""
    current: int
    total: int
    table_name: str
    table_info: Optional[TableInfo] = None
    error: Optional[str] = None
    
    @property
    def is_done(self) -> bool:
        return self.table_info is not None or self.error is not None


class DatabaseExplorer:
    """Explore database schema and collect comprehensive metadata.
    
    This class provides methods to explore a MySQL database and collect
    information about tables, columns, indexes, and foreign keys.
    
    Usage:
        explorer = DatabaseExplorer(db_service)
        snapshot = explorer.explore()
    """

    def __init__(self, db_service: "DatabaseService"):
        """Initialize explorer with a database service.
        
        Args:
            db_service: Connected database service instance
        """
        self._db_service = db_service

    def _execute_query(self, sql: str) -> tuple[List[str], List[tuple]]:
        """Execute a query and return (columns, rows).
        
        Returns:
            Tuple of (column_names, rows)
        """
        result = self._db_service.execute_query(sql)
        if not result.success:
            logger.warning(f"Query failed: {result.error}")
            return [], []
        return result.columns or [], result.rows

    def explore(self) -> DatabaseSchemaSnapshot:
        """Explore the current database and return a complete schema snapshot.
        
        Returns:
            DatabaseSchemaSnapshot with all collected metadata
            
        Raises:
            ValueError: If not connected to a database
        """
        # Use the generator version but consume it immediately
        tables = []
        snapshot = None
        for progress in self.explore_iter():
            if progress.table_info:
                tables.append(progress.table_info)
            if isinstance(progress, DatabaseSchemaSnapshot):
                snapshot = progress
        
        # The last yield should be the snapshot
        if snapshot is None:
            raise ValueError("Failed to explore database")
        return snapshot

    def explore_iter(self) -> Generator[TableExploreProgress | DatabaseSchemaSnapshot, None, None]:
        """Explore the database with progress updates.
        
        Yields TableExploreProgress for each table, then the final DatabaseSchemaSnapshot.
        
        Usage:
            for progress in explorer.explore_iter():
                if isinstance(progress, TableExploreProgress):
                    print(f"[{progress.current}/{progress.total}] {progress.table_name}")
                else:
                    # Final snapshot
                    snapshot = progress
        
        Yields:
            TableExploreProgress for each table being explored
            DatabaseSchemaSnapshot as the final yield
        """
        conn_info = self._db_service.get_connection_info()
        if not conn_info.get('connected'):
            raise ValueError("Not connected to a database")
        
        database_name = conn_info.get('database')
        if not database_name:
            raise ValueError("No database selected")

        host = conn_info.get('host', 'localhost')
        port = conn_info.get('port', 3306)

        # First, get table list and foreign keys
        tables = self._collect_tables(database_name)
        foreign_keys = self._collect_foreign_keys(database_name)
        
        total = len(tables)
        completed_tables: List[TableInfo] = []
        
        # Explore each table with progress updates
        for i, table in enumerate(tables, 1):
            # Yield progress before starting
            yield TableExploreProgress(
                current=i,
                total=total,
                table_name=table.name,
            )
            
            try:
                # Collect detailed info for this table
                table.columns = self._collect_columns(database_name, table.name)
                table.indexes = self._collect_indexes(table.name)
                table.primary_key_columns = [
                    col.name for col in table.columns if col.column_key == 'PRI'
                ]
                completed_tables.append(table)
                
            except Exception as e:
                logger.warning(f"Failed to explore table {table.name}: {e}")
                # Still add the table but with minimal info
                completed_tables.append(table)

        # Calculate statistics
        statistics = DatabaseStatistics(
            total_tables=len(completed_tables),
            total_rows_estimate=sum(t.row_count_estimate for t in completed_tables),
            total_data_size_bytes=sum(t.data_size_bytes for t in completed_tables),
            total_index_size_bytes=sum(t.index_size_bytes for t in completed_tables),
        )

        # Generate schema hash for change detection
        schema_hash = DatabaseSchemaSnapshot.compute_schema_hash(completed_tables)

        # Yield the final snapshot
        yield DatabaseSchemaSnapshot(
            database_name=database_name,
            host=host,
            port=port,
            tables=completed_tables,
            foreign_keys=foreign_keys,
            statistics=statistics,
            collected_at=datetime.now(),
            schema_hash=schema_hash,
        )

    def _collect_tables(self, database_name: str) -> List[TableInfo]:
        """Collect basic table information from information_schema."""
        sql = f"""
            SELECT 
                TABLE_NAME,
                TABLE_COMMENT,
                ENGINE,
                TABLE_ROWS,
                DATA_LENGTH,
                INDEX_LENGTH
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = '{database_name}'
              AND TABLE_TYPE = 'BASE TABLE'
            ORDER BY TABLE_NAME
        """
        columns, rows = self._execute_query(sql)
        
        tables = []
        for row in rows:
            tables.append(TableInfo(
                name=row[0],
                comment=row[1] if row[1] else None,
                engine=row[2] or 'InnoDB',
                row_count_estimate=row[3] or 0,
                data_size_bytes=row[4] or 0,
                index_size_bytes=row[5] or 0,
            ))
        
        return tables

    def _collect_columns(self, database_name: str, table_name: str) -> List[ColumnInfo]:
        """Collect column information for a specific table."""
        sql = f"""
            SELECT 
                COLUMN_NAME,
                COLUMN_TYPE,
                IS_NULLABLE,
                COLUMN_KEY,
                COLUMN_DEFAULT,
                EXTRA,
                COLUMN_COMMENT
            FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = '{database_name}'
              AND TABLE_NAME = '{table_name}'
            ORDER BY ORDINAL_POSITION
        """
        columns, rows = self._execute_query(sql)
        
        result = []
        for row in rows:
            result.append(ColumnInfo(
                name=row[0],
                data_type=row[1],
                is_nullable=(row[2] == 'YES'),
                column_key=row[3] or '',
                default=row[4],
                extra=row[5] or '',
                comment=row[6] if row[6] else None,
            ))
        
        return result

    def _collect_indexes(self, table_name: str) -> List[IndexInfo]:
        """Collect index information for a specific table."""
        sql = f"SHOW INDEX FROM `{table_name}`"
        columns, rows = self._execute_query(sql)
        
        # Group by index name
        index_map: Dict[str, IndexInfo] = {}
        for row in rows:
            # SHOW INDEX columns: Table, Non_unique, Key_name, Seq_in_index, 
            # Column_name, Collation, Cardinality, Sub_part, Packed, Null, 
            # Index_type, Comment, Index_comment
            key_name = row[2]
            non_unique = row[1]
            column_name = row[4]
            index_type = row[10] if len(row) > 10 else 'BTREE'
            
            if key_name not in index_map:
                index_map[key_name] = IndexInfo(
                    name=key_name,
                    columns=[],
                    is_unique=(non_unique == 0),
                    index_type=index_type,
                )
            # Only append non-None column names
            if column_name:
                index_map[key_name].columns.append(column_name)
        
        return list(index_map.values())

    def _collect_foreign_keys(self, database_name: str) -> List[ForeignKeyInfo]:
        """Collect foreign key relationships."""
        sql = f"""
            SELECT 
                kcu.CONSTRAINT_NAME,
                kcu.TABLE_NAME,
                kcu.COLUMN_NAME,
                kcu.REFERENCED_TABLE_NAME,
                kcu.REFERENCED_COLUMN_NAME
            FROM information_schema.KEY_COLUMN_USAGE kcu
            WHERE kcu.TABLE_SCHEMA = '{database_name}'
              AND kcu.REFERENCED_TABLE_NAME IS NOT NULL
            ORDER BY kcu.TABLE_NAME, kcu.CONSTRAINT_NAME
        """
        columns, rows = self._execute_query(sql)
        
        fks = []
        for row in rows:
            fks.append(ForeignKeyInfo(
                constraint_name=row[0],
                table_name=row[1],
                column_name=row[2],
                referenced_table=row[3],
                referenced_column=row[4],
            ))
        
        return fks

