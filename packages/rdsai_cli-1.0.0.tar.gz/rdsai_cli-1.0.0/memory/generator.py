"""Generate database memory documents from schema snapshots."""

from __future__ import annotations

from string import Template
from typing import TYPE_CHECKING, Optional

from langchain_core.messages import HumanMessage, SystemMessage

from .types import (
    DatabaseMemory,
    DatabaseSchemaSnapshot,
    TableInfo,
    ForeignKeyInfo,
)
from utils.logging import logger

if TYPE_CHECKING:
    from llm.llm import LLM

# Marker for custom notes section - content below this will be preserved
CUSTOM_NOTES_MARKER = "<!-- Custom notes below this line"


# System prompt for memory generation
MEMORY_SYSTEM_PROMPT = """You are a database documentation expert. Your task is to analyze database schema information and generate a clear, well-organized documentation in Markdown format.

The documentation should:
1. Provide a brief overview of what this database appears to be used for (infer from table/column names)
2. Group related tables logically (e.g., user tables, product tables, order tables)
3. Highlight important relationships between tables
4. Note any interesting design patterns or conventions used
5. Be concise but informative - focus on what would help someone understand this database quickly

Output in the SAME LANGUAGE as the table/column comments if they exist, otherwise use English."""


MEMORY_USER_PROMPT_TEMPLATE = """Please analyze the following database schema and generate documentation.

# Database: $database_name
Host: $host:$port
Tables: $table_count
Total Rows (estimate): $total_rows
Total Data Size: $data_size

## Tables Overview

$tables_overview

## Foreign Key Relationships

$foreign_keys

## Detailed Table Structures

$table_details

---

Please generate a well-organized documentation for this database. Include:
1. A brief "Overview" section describing what this database appears to be for
2. A "Table Groups" section organizing tables by their apparent purpose
3. A "Key Relationships" section summarizing important table connections
4. A "Design Patterns" section noting any conventions (naming, soft delete, timestamps, etc.)
5. A "Notes" section for any other observations

Keep the documentation concise and practical. Use tables where appropriate for readability."""


class MemoryDocumentGenerator:
    """Generate database memory documents using LLM analysis.
    
    This generator creates LLM-analyzed documents with intelligent grouping
    and insights. It supports preserving user's custom notes on regeneration.
    """

    def __init__(self):
        pass

    async def generate(
        self,
        snapshot: DatabaseSchemaSnapshot,
        llm: "LLM",
        existing_content: Optional[str] = None,
    ) -> DatabaseMemory:
        """Generate a memory document from a database schema snapshot.
        
        Args:
            snapshot: Complete database schema snapshot
            llm: LLM instance for generating the analysis
            existing_content: Previous memory content (to preserve custom notes)
            
        Returns:
            DatabaseMemory object with generated content
        """
        # Extract custom notes from existing content
        custom_notes = self._extract_custom_notes(existing_content) if existing_content else None
        
        # Build the prompt with schema information
        prompt = self._build_prompt(snapshot)
        
        # Call LLM to generate the analysis
        analysis = await self._call_llm(prompt, llm)
        
        # Wrap the analysis in our memory document format
        content = self._format_memory_document(snapshot, analysis, custom_notes)
        
        return DatabaseMemory(
            database_name=snapshot.database_name,
            host=snapshot.host,
            port=snapshot.port,
            content=content,
            schema_hash=snapshot.schema_hash,
            created_at=snapshot.collected_at,
        )

    def _extract_custom_notes(self, content: str) -> Optional[str]:
        """Extract custom notes section from existing memory content.
        
        Custom notes are everything after the CUSTOM_NOTES_MARKER line.
        
        Args:
            content: Existing memory document content
            
        Returns:
            Custom notes content if found, None otherwise
        """
        if not content:
            return None
        
        # Find the custom notes marker
        marker_pos = content.find(CUSTOM_NOTES_MARKER)
        if marker_pos == -1:
            return None
        
        # Find the end of the marker line (the --> part)
        marker_end = content.find("-->", marker_pos)
        if marker_end == -1:
            return None
        
        # Get everything after the marker line
        notes_start = marker_end + 3  # len("-->")
        custom_notes = content[notes_start:].strip()
        
        # Return None if notes are empty
        if not custom_notes:
            return None
        
        logger.debug("Extracted custom notes: {len} chars", len=len(custom_notes))
        return custom_notes

    def _build_prompt(self, snapshot: DatabaseSchemaSnapshot) -> str:
        """Build the user prompt with schema information."""
        # Tables overview
        tables_overview = self._format_tables_overview(snapshot.tables)
        
        # Foreign keys
        foreign_keys = self._format_foreign_keys(snapshot.foreign_keys)
        
        # Detailed table structures
        table_details = self._format_table_details(snapshot.tables)
        
        # Format data size
        data_size = self._format_bytes(snapshot.statistics.total_data_size_bytes)
        
        template = Template(MEMORY_USER_PROMPT_TEMPLATE)
        return template.substitute(
            database_name=snapshot.database_name,
            host=snapshot.host,
            port=snapshot.port,
            table_count=snapshot.statistics.total_tables,
            total_rows=f"{snapshot.statistics.total_rows_estimate:,}",
            data_size=data_size,
            tables_overview=tables_overview,
            foreign_keys=foreign_keys,
            table_details=table_details,
        )

    def _format_tables_overview(self, tables: list[TableInfo]) -> str:
        """Format tables overview as a markdown table."""
        if not tables:
            return "No tables found."
        
        lines = ["| Table | Rows | Size | Engine | Comment |",
                 "|-------|------|------|--------|---------|"]
        
        for table in tables:
            size = self._format_bytes(table.data_size_bytes)
            comment = table.comment or "-"
            # Truncate long comments
            if len(comment) > 40:
                comment = comment[:37] + "..."
            lines.append(
                f"| {table.name} | {table.row_count_estimate:,} | {size} | {table.engine} | {comment} |"
            )
        
        return "\n".join(lines)

    def _format_foreign_keys(self, fks: list[ForeignKeyInfo]) -> str:
        """Format foreign key relationships."""
        if not fks:
            return "No foreign key relationships found."
        
        lines = []
        for fk in fks:
            lines.append(
                f"- `{fk.table_name}.{fk.column_name}` → `{fk.referenced_table}.{fk.referenced_column}`"
            )
        
        return "\n".join(lines)

    def _format_table_details(self, tables: list[TableInfo]) -> str:
        """Format detailed table structures."""
        sections = []
        
        for table in tables:
            lines = [f"### {table.name}"]
            
            if table.comment:
                lines.append(f"> {table.comment}")
            
            lines.append("")
            lines.append("**Columns:**")
            lines.append("| Column | Type | Key | Nullable | Comment |")
            lines.append("|--------|------|-----|----------|---------|")
            
            for col in table.columns:
                key = col.column_key or "-"
                nullable = "YES" if col.is_nullable else "NO"
                comment = col.comment or "-"
                if len(comment) > 30:
                    comment = comment[:27] + "..."
                lines.append(
                    f"| {col.name} | {col.data_type} | {key} | {nullable} | {comment} |"
                )
            
            # Add indexes
            if table.indexes:
                lines.append("")
                lines.append("**Indexes:**")
                for idx in table.indexes:
                    unique = "UNIQUE " if idx.is_unique else ""
                    # Filter out None values defensively
                    cols = ", ".join(c for c in idx.columns if c)
                    if cols:
                        lines.append(f"- `{idx.name}`: {unique}{idx.index_type} ({cols})")
            
            sections.append("\n".join(lines))
        
        return "\n\n".join(sections)

    async def _call_llm(self, prompt: str, llm: "LLM") -> str:
        """Call the LLM to generate analysis."""
        messages = [
            SystemMessage(content=MEMORY_SYSTEM_PROMPT),
            HumanMessage(content=prompt),
        ]
        
        # Stream the response
        final_chunk = None
        async for chunk in llm.chat_provider.astream(messages):
            if final_chunk is None:
                final_chunk = chunk
            else:
                final_chunk += chunk
        
        if final_chunk is None:
            return ""
        
        content = final_chunk.content
        if isinstance(content, str):
            return content
        return ""

    def _format_memory_document(
        self,
        snapshot: DatabaseSchemaSnapshot,
        analysis: str,
        custom_notes: Optional[str] = None,
    ) -> str:
        """Format the final memory document with metadata header.
        
        Args:
            snapshot: Database schema snapshot
            analysis: LLM-generated analysis content
            custom_notes: User's custom notes to preserve (optional)
        """
        header = f"""# Database Memory: {snapshot.database_name}

> Generated at: {snapshot.collected_at.strftime("%Y-%m-%d %H:%M:%S")}
> Host: {snapshot.host}:{snapshot.port}
> Schema Hash: `{snapshot.schema_hash}`
> Tables: {snapshot.statistics.total_tables} | Rows: ~{snapshot.statistics.total_rows_estimate:,} | Size: {self._format_bytes(snapshot.statistics.total_data_size_bytes)}

---

"""
        footer = """

---
<!-- Custom notes below this line - they will be preserved on regeneration -->

"""
        # Append preserved custom notes if any
        if custom_notes:
            footer += custom_notes + "\n"
        
        return header + analysis + footer

    def _format_bytes(self, size_bytes: int) -> str:
        """Format byte size to human readable string."""
        if size_bytes < 1024:
            return f"{size_bytes} B"
        elif size_bytes < 1024 * 1024:
            return f"{size_bytes / 1024:.1f} KB"
        elif size_bytes < 1024 * 1024 * 1024:
            return f"{size_bytes / (1024 * 1024):.1f} MB"
        else:
            return f"{size_bytes / (1024 * 1024 * 1024):.1f} GB"

