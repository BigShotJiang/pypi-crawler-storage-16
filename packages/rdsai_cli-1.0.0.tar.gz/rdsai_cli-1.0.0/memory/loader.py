"""Memory loading utilities for AI context injection."""

from __future__ import annotations

from typing import Optional

from utils.logging import logger


def load_database_memory() -> Optional[str]:
    """Load database memory content if available.
    
    This function is used to inject database context into the AI's
    system prompt. It loads the memory for the currently connected
    database from the default storage backend.
    
    Returns:
        Memory content string if available, None otherwise
    """
    try:
        from database import get_database_service
        from memory.storage import get_default_storage
        
        db_service = get_database_service()
        if not db_service or not db_service.is_connected():
            return None
        
        conn_info = db_service.get_connection_info()
        if not conn_info.get('database'):
            return None
        
        storage = get_default_storage()
        memory = storage.load(
            conn_info['host'],
            conn_info['port'],
            conn_info['database'],
        )
        
        if memory:
            logger.debug(
                "Loaded database memory for {db} (hash: {hash})",
                db=conn_info['database'],
                hash=memory.schema_hash,
            )
            return memory.content
        
        return None
    except Exception as e:
        logger.warning("Failed to load database memory: {e}", e)
        return None

