"""Storage backends for database memory.

This module provides pluggable storage backends:
- FileMemoryStorage: Local filesystem storage (default)
- VectorMemoryStorage: Vector database storage (future)

Usage:
    from memory.storage import get_default_storage, FileMemoryStorage
    
    # Use default storage
    storage = get_default_storage()
    
    # Or create specific storage
    storage = FileMemoryStorage(base_dir=Path("/custom/path"))
"""

from .base import MemoryStorage
from .file import FileMemoryStorage

# Default storage instance (lazy initialization)
_default_storage: MemoryStorage | None = None


def get_default_storage() -> MemoryStorage:
    """Get the default memory storage instance.
    
    Currently returns FileMemoryStorage. In the future, this could
    be configured via settings to use vector database storage.
    
    Returns:
        Default MemoryStorage instance
    """
    global _default_storage
    if _default_storage is None:
        _default_storage = FileMemoryStorage()
    return _default_storage


def set_default_storage(storage: MemoryStorage) -> None:
    """Set the default memory storage instance.
    
    Useful for testing or switching storage backends.
    
    Args:
        storage: MemoryStorage instance to use as default
    """
    global _default_storage
    _default_storage = storage


__all__ = [
    "MemoryStorage",
    "FileMemoryStorage",
    "get_default_storage",
    "set_default_storage",
]

