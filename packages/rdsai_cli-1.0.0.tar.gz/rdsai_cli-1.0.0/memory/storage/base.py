"""Abstract base class for memory storage backends."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from memory.types import DatabaseMemory


class MemoryStorage(ABC):
    """Abstract base class for memory storage backends.
    
    All storage implementations should inherit from this class
    and implement the required methods.
    
    Supported backends:
    - FileMemoryStorage: Local filesystem (.md files)
    - VectorMemoryStorage: Vector database (future)
    """

    @abstractmethod
    def save(self, memory: "DatabaseMemory") -> str:
        """Save memory content.
        
        Args:
            memory: DatabaseMemory object to save
            
        Returns:
            Storage location identifier (path, ID, etc.)
        """
        pass

    @abstractmethod
    def load(
        self,
        host: str,
        port: int,
        database: str,
    ) -> Optional["DatabaseMemory"]:
        """Load memory content.
        
        Args:
            host: Database host
            port: Database port
            database: Database name
            
        Returns:
            DatabaseMemory if found, None otherwise
        """
        pass

    @abstractmethod
    def exists(self, host: str, port: int, database: str) -> bool:
        """Check if memory exists.
        
        Args:
            host: Database host
            port: Database port
            database: Database name
            
        Returns:
            True if memory exists
        """
        pass

    @abstractmethod
    def delete(self, host: str, port: int, database: str) -> bool:
        """Delete memory.
        
        Args:
            host: Database host
            port: Database port
            database: Database name
            
        Returns:
            True if deleted, False if not found
        """
        pass

    @abstractmethod
    def list_all(self) -> list[tuple[str, str, int, str]]:
        """List all stored memories.
        
        Returns:
            List of (identifier, host, port, database) tuples
        """
        pass

    @abstractmethod
    def get_location(self, host: str, port: int, database: str) -> str:
        """Get the storage location identifier for a memory.
        
        Different backends return different location formats:
        - FileMemoryStorage: file path (e.g., ~/.rdsai-cli/memories/localhost_3306_db.md)
        - VectorMemoryStorage: collection/namespace (e.g., mysql://collection/db_memory)
        
        Args:
            host: Database host
            port: Database port
            database: Database name
            
        Returns:
            Storage location identifier (path, URL, collection name, etc.)
        """
        pass

