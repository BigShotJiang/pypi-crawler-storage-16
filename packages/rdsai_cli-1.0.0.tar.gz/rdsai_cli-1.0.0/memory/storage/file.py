"""File-based storage backend for database memory."""

from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path
from typing import Optional

from .base import MemoryStorage
from memory.types import DatabaseMemory
from config import get_share_dir
from utils.logging import logger


class FileMemoryStorage(MemoryStorage):
    """Store database memory as local .md files.
    
    Memory files are stored in ~/.rdsai-cli/memories/ directory with naming pattern:
    {host}_{port}_{database}.md
    
    Example: localhost_3306_ecommerce.md
    
    Features:
    - Human-readable Markdown format
    - Easy to edit manually
    - Can be version controlled
    - Supports custom notes preservation
    """

    DEFAULT_BASE_DIR = get_share_dir() / "memories"

    def __init__(self, base_dir: Optional[Path] = None):
        """Initialize storage with optional custom base directory.
        
        Args:
            base_dir: Custom directory for storing memory files.
                     Defaults to ~/.rdsai-cli/memories/
        """
        self.base_dir = base_dir or self.DEFAULT_BASE_DIR
        self._ensure_dir_exists()

    def _ensure_dir_exists(self) -> None:
        """Ensure the storage directory exists."""
        self.base_dir.mkdir(parents=True, exist_ok=True)

    def _get_memory_path(self, host: str, port: int, database: str) -> Path:
        """Get the file path for a database memory.
        
        Args:
            host: Database host
            port: Database port
            database: Database name
            
        Returns:
            Path to the memory file
        """
        # Sanitize host for use in filename
        safe_host = host.replace(".", "_").replace("/", "_").replace(":", "_")
        filename = f"{safe_host}_{port}_{database}.md"
        return self.base_dir / filename

    def save(self, memory: DatabaseMemory) -> str:
        """Save memory content to file.
        
        Args:
            memory: DatabaseMemory object to save
            
        Returns:
            Path to the saved file as string
        """
        path = self._get_memory_path(memory.host, memory.port, memory.database_name)
        path.write_text(memory.content, encoding="utf-8")
        logger.info(f"Saved database memory to {path}")
        return str(path)

    def load(
        self,
        host: str,
        port: int,
        database: str,
    ) -> Optional[DatabaseMemory]:
        """Load memory content from file.
        
        Args:
            host: Database host
            port: Database port
            database: Database name
            
        Returns:
            DatabaseMemory if file exists, None otherwise
        """
        path = self._get_memory_path(host, port, database)
        if not path.exists():
            return None
        
        content = path.read_text(encoding="utf-8")
        
        # Try to extract schema hash from content
        schema_hash = self._extract_schema_hash(content)
        
        # Try to extract timestamp
        created_at = self._extract_timestamp(content)
        
        return DatabaseMemory(
            database_name=database,
            host=host,
            port=port,
            content=content,
            schema_hash=schema_hash,
            created_at=created_at,
        )

    def exists(self, host: str, port: int, database: str) -> bool:
        """Check if memory file exists.
        
        Args:
            host: Database host
            port: Database port
            database: Database name
            
        Returns:
            True if memory file exists
        """
        return self._get_memory_path(host, port, database).exists()

    def delete(self, host: str, port: int, database: str) -> bool:
        """Delete a memory file.
        
        Args:
            host: Database host
            port: Database port
            database: Database name
            
        Returns:
            True if file was deleted, False if it didn't exist
        """
        path = self._get_memory_path(host, port, database)
        if path.exists():
            path.unlink()
            logger.info(f"Deleted database memory at {path}")
            return True
        return False

    def list_all(self) -> list[tuple[str, str, int, str]]:
        """List all stored memory files.
        
        Returns:
            List of (filename, host, port, database) tuples
        """
        result = []
        for path in self.base_dir.glob("*.md"):
            # Parse filename: {host}_{port}_{database}.md
            parts = path.stem.rsplit("_", 2)
            if len(parts) >= 3:
                # Last part is database, second to last is port, rest is host
                database = parts[-1]
                try:
                    port = int(parts[-2])
                    host = "_".join(parts[:-2]).replace("_", ".")
                    result.append((path.name, host, port, database))
                except ValueError:
                    # Invalid port, skip this file
                    continue
        return result

    def get_location(self, host: str, port: int, database: str) -> str:
        """Get the file path for a memory.
        
        Args:
            host: Database host
            port: Database port
            database: Database name
            
        Returns:
            Full path to the memory file
        """
        return str(self._get_memory_path(host, port, database))

    def get_path(self, host: str, port: int, database: str) -> Path:
        """Get the Path object for a memory file.
        
        Convenience method for file-specific operations.
        
        Args:
            host: Database host
            port: Database port
            database: Database name
            
        Returns:
            Path object (may not exist)
        """
        return self._get_memory_path(host, port, database)

    def _extract_schema_hash(self, content: str) -> Optional[str]:
        """Extract schema hash from memory content if present."""
        # Look for pattern: Schema Hash: `abc123...`
        match = re.search(r'Schema Hash:\s*`?([a-f0-9]+)`?', content, re.IGNORECASE)
        if match:
            return match.group(1)
        return None

    def _extract_timestamp(self, content: str) -> Optional[datetime]:
        """Extract generation timestamp from memory content if present."""
        # Look for pattern: Generated at: 2024-01-15 10:30:00
        match = re.search(
            r'Generated at:\s*(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})',
            content
        )
        if match:
            try:
                return datetime.strptime(match.group(1), "%Y-%m-%d %H:%M:%S")
            except ValueError:
                pass
        return None

