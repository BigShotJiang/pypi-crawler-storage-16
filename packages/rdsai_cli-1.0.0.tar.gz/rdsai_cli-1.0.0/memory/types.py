"""Data types for the memory module."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional


@dataclass
class DatabaseMemory:
    """A database memory document.
    
    Represents the stored knowledge about a database schema,
    including LLM-generated analysis and user's custom notes.
    """
    database_name: str
    host: str
    port: int
    content: str
    schema_hash: Optional[str] = None
    created_at: Optional[datetime] = None
    
    @property
    def connection_key(self) -> str:
        """Generate a unique key for this database connection."""
        safe_host = self.host.replace(".", "_").replace("/", "_").replace(":", "_")
        return f"{safe_host}_{self.port}_{self.database_name}"


@dataclass
class ColumnInfo:
    """Information about a table column."""
    name: str
    data_type: str
    is_nullable: bool
    column_key: str  # PRI, UNI, MUL, or empty
    default: Optional[str]
    extra: str  # auto_increment, etc.
    comment: Optional[str]


@dataclass
class IndexInfo:
    """Information about a table index."""
    name: str
    columns: List[str]
    is_unique: bool
    index_type: str  # BTREE, HASH, FULLTEXT, etc.


@dataclass
class ForeignKeyInfo:
    """Information about a foreign key relationship."""
    constraint_name: str
    table_name: str
    column_name: str
    referenced_table: str
    referenced_column: str


@dataclass
class TableInfo:
    """Comprehensive information about a single table."""
    name: str
    comment: Optional[str]
    engine: str
    row_count_estimate: int
    data_size_bytes: int
    index_size_bytes: int
    columns: List[ColumnInfo] = field(default_factory=list)
    indexes: List[IndexInfo] = field(default_factory=list)
    primary_key_columns: List[str] = field(default_factory=list)


@dataclass
class DatabaseStatistics:
    """Overall database statistics."""
    total_tables: int
    total_rows_estimate: int
    total_data_size_bytes: int
    total_index_size_bytes: int


@dataclass
class DatabaseSchemaSnapshot:
    """Complete snapshot of database schema.
    
    Contains all metadata collected from exploring a database.
    """
    database_name: str
    host: str
    port: int
    tables: List[TableInfo]
    foreign_keys: List[ForeignKeyInfo]
    statistics: DatabaseStatistics
    collected_at: datetime
    schema_hash: str

    def get_tables_by_row_count(self, descending: bool = True) -> List[TableInfo]:
        """Get tables sorted by estimated row count."""
        return sorted(
            self.tables,
            key=lambda t: t.row_count_estimate,
            reverse=descending
        )

    @staticmethod
    def compute_schema_hash(tables: List[TableInfo]) -> str:
        """Compute a hash of the schema for change detection.
        
        The hash is based on table names and column definitions.
        """
        schema_str_parts = []
        for table in sorted(tables, key=lambda t: t.name):
            cols_str = ",".join(
                f"{c.name}:{c.data_type}:{c.column_key}"
                for c in table.columns
            )
            schema_str_parts.append(f"{table.name}({cols_str})")
        
        schema_str = "|".join(schema_str_parts)
        return hashlib.sha256(schema_str.encode()).hexdigest()[:16]

