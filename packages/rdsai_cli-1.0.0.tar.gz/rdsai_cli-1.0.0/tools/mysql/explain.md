Analyze SQL query execution plan using MySQL EXPLAIN. **Only supports SELECT, INSERT, UPDATE, DELETE statements.**

**When to use:**
- Analyze slow SELECT queries to understand index usage and join order
- Check execution plan before running INSERT/UPDATE/DELETE on large tables
- Performance tuning and query optimization

**DO NOT use for:**
- SHOW commands (use MySQLParameter, MySQLProcess, MySQLTableStatus, etc.)
- SET commands
- DDL statements (CREATE, ALTER, DROP)
- Any non-DML statements

**Parameters:**
- **sql**: The SQL statement to analyze (must be SELECT, INSERT, UPDATE, or DELETE)

Returns execution plan showing tables accessed, indexes used, join order, and estimated row counts.
