Query MySQL general log from the mysql.general_log table for SQL audit and analysis.

**Parameters:**
- **start_time** (optional): Filter queries from this time onwards (format: 'YYYY-MM-DD HH:MM:SS')
- **end_time** (optional): Filter queries up to this time (format: 'YYYY-MM-DD HH:MM:SS')
- **user_host** (optional): Filter by user and host pattern (supports % wildcard, e.g., 'root@%')
- **command_type** (optional): Filter by command type (e.g., 'Query', 'Connect', 'Quit', 'Init DB')
- **sql_pattern** (optional): Filter SQL text by pattern (supports % wildcard)
- **limit** (optional): Maximum number of rows to return (default: 100, max: 10000)

Shows all SQL statements executed on the server, useful for:
- Security auditing and compliance
- Tracking user activity
- Debugging application behavior
- Identifying unauthorized access attempts
