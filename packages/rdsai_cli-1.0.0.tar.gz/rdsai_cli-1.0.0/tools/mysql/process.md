Get current database connections using SHOW PROCESSLIST.

Shows information about all active connections including connection ID, user, host, database, command type, execution time, and current statement. No parameters required.
