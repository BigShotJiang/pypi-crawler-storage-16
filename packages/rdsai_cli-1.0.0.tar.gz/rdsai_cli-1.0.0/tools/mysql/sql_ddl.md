# MySQL DDL Executor

Execute DDL (Data Definition Language) operations on MySQL databases with user approval.

**Parameters:**
- **sql_statement**: The DDL SQL statement to execute
- **description**: A human-readable description of what the modification will do

**Supported Operations:**
- CREATE/DROP INDEX, TABLE, VIEW, PROCEDURE, FUNCTION, TRIGGER
- ALTER TABLE (add/drop columns, constraints, etc.)

**Safety Features:**
- User approval required for all modifications
- DDL operations only (no INSERT/UPDATE/DELETE)
- Blocks dangerous operations like DROP DATABASE

**IMPORTANT: Execute ONE DDL operation at a time.** If you need to perform multiple DDL changes, call this tool once, wait for the result, then decide whether to proceed with the next operation. Do NOT batch multiple DDL calls in a single response.
