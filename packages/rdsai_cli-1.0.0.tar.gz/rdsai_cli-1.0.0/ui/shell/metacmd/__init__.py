"""Meta commands for the shell interface."""

from ui.shell.metacmd.registry import (
    MetaCommand,
    MetaCmdFunc,
    get_meta_command,
    get_meta_commands,
    meta_command,
)

# Import command modules to trigger registration
from ui.shell.metacmd import basic  # noqa: F401
from ui.shell.metacmd import connect  # noqa: F401
from ui.shell.metacmd import init  # noqa: F401
from ui.shell.metacmd import memory  # noqa: F401
from ui.shell.metacmd import model  # noqa: F401
from ui.shell.metacmd import setup  # noqa: F401

__all__ = [
    "MetaCommand",
    "MetaCmdFunc",
    "get_meta_command",
    "get_meta_commands",
    "meta_command",
]
