"""Basic meta commands: exit, help, version, clear, compact, yolo, history."""

from __future__ import annotations

from typing import TYPE_CHECKING

from rich.live import Live
from rich.panel import Panel
from rich.spinner import Spinner

from loop import NeoLoop
from ui.formatters.database_formatter import HistoryFormatter
from ui.shell.console import console
from ui.shell.metacmd.registry import get_meta_commands, meta_command

if TYPE_CHECKING:
    from ui.shell import ShellApp


@meta_command(aliases=["quit"])
def exit(app: ShellApp, args: list[str]):
    """Exit the application"""
    # should be handled by `ShellApp`
    raise NotImplementedError


@meta_command(aliases=["h", "?"])
def help(app: ShellApp, args: list[str]):
    """Show help information"""
    from rich.table import Table
    from rich.text import Text
    
    # Categorize commands
    general_cmds = []
    ai_cmds = []
    db_cmds = []
    
    for cmd in get_meta_commands():
        if cmd.name in ("exit", "help", "version"):
            general_cmds.append(cmd)
        elif cmd.name in ("clear", "compact", "yolo"):
            ai_cmds.append(cmd)
        else:  # history, init, memory
            db_cmds.append(cmd)
    
    def format_cmd(cmd) -> str:
        aliases = f" [dim]({', '.join(cmd.aliases)})[/dim]" if cmd.aliases else ""
        return f"[cyan]/{cmd.name}[/cyan]{aliases}"
    
    # Build help content
    lines: list[str] = []
    
    # Header
    lines.append("[bold]RDSAI CLI[/bold] - Your intelligent database assistant\n")
    lines.append("Send messages to get AI-powered help with your database tasks.\n")
    
    # Commands table
    lines.append("[bold wheat4]Commands[/bold wheat4]\n")
    
    # General
    lines.append("  [dim]General[/dim]")
    for cmd in general_cmds:
        lines.append(f"    {format_cmd(cmd):40} {cmd.description}")
    
    # AI / Context
    lines.append("\n  [dim]AI Context[/dim]")
    for cmd in ai_cmds:
        lines.append(f"    {format_cmd(cmd):40} {cmd.description}")
    
    # Database
    lines.append("\n  [dim]Database[/dim]")
    for cmd in db_cmds:
        lines.append(f"    {format_cmd(cmd):40} {cmd.description}")
    
    # Current status
    lines.append("\n[bold wheat4]Current Status[/bold wheat4]\n")
    
    # YOLO mode
    if isinstance(app.loop, NeoLoop):
        yolo_status = "[green]ON[/green]" if app.loop.status.yolo else "[dim]off[/dim]"
        lines.append(f"  YOLO Mode:  {yolo_status}")
        
        # Context usage
        usage = app.loop.status.context_usage
        if usage >= 0:
            usage_pct = f"{usage:.1%}"
            if usage > 0.8:
                usage_text = f"[red]{usage_pct}[/red]"
            elif usage > 0.6:
                usage_text = f"[yellow]{usage_pct}[/yellow]"
            else:
                usage_text = f"[green]{usage_pct}[/green]"
            lines.append(f"  Context:    {usage_text}")
    
    # Database connection
    if app.db_service and app.db_service.is_connected():
        db_info = app.db_service.get_connection_info()
        db_name = db_info.get('database', '-')
        host = db_info.get('host', '')
        port = db_info.get('port', '')
        lines.append(f"  Database:   [cyan]{db_name}[/cyan] [dim]({host}:{port})[/dim]")
    else:
        lines.append(f"  Database:   [dim]not connected[/dim]")
    
    console.print(
        Panel(
            "\n".join(lines),
            title="Help",
            border_style="wheat4",
            expand=False,
            padding=(1, 2),
        )
    )


@meta_command
def version(app: ShellApp, args: list[str]):
    """Show version information"""
    from config import VERSION

    console.print(f"version {VERSION}")


@meta_command(aliases=["reset"], loop_only=True)
async def clear(app: ShellApp, args: list[str]):
    """Clear the context (start fresh)"""
    assert isinstance(app.loop, NeoLoop)

    # Reset context by generating a new thread_id
    app.loop.reset_context()
    console.print("[green]✓[/green] Context cleared.")


@meta_command(loop_only=True)
async def compact(app: ShellApp, args: list[str]):
    """Compact the context to save tokens"""
    assert isinstance(app.loop, NeoLoop)

    spinner = Spinner("dots", text="Compacting context...", style="cyan")
    
    with Live(spinner, console=console, refresh_per_second=10, transient=True):
        success = await app.loop.compact()
    
    if success:
        usage = app.loop.status.context_usage
        if usage >= 0:
            console.print(f"[green]✓[/green] Context compacted. Current usage: {usage:.1%}")
        else:
            console.print("[green]✓[/green] Context compacted.")
    else:
        console.print("[yellow]No context to compact or compaction not needed.[/yellow]")


@meta_command(loop_only=True)
async def yolo(app: ShellApp, args: list[str]):
    """Toggle YOLO mode (auto approve all actions). Usage: \\yolo [on|off]"""
    assert isinstance(app.loop, NeoLoop)

    if args:
        arg = args[0].lower()
        if arg in ("on", "1", "true", "yes"):
            app.loop.set_yolo(True)
        elif arg in ("off", "0", "false", "no"):
            app.loop.set_yolo(False)
        else:
            console.print(f"[yellow]Unknown argument: {args[0]}. Use 'on' or 'off'.[/yellow]")
            return
    else:
        # Toggle mode
        current = app.loop.status.yolo
        app.loop.set_yolo(not current)

    if app.loop.status.yolo:
        console.print("[green]✓[/green] YOLO mode enabled! Living on the edge...")
    else:
        console.print("[green]✓[/green] YOLO mode disabled. Back to safe mode.")


@meta_command(aliases=["hist"])
def history(app: ShellApp, args: list[str]):
    """Show SQL query execution history"""
    if not app.query_history:
        console.print("[yellow]No query history available.[/yellow]")
        return

    # Parse limit from args if provided
    limit = 10
    if args:
        try:
            limit = int(args[0])
            if limit <= 0:
                console.print("[red]Limit must be a positive number.[/red]")
                return
        except ValueError:
            console.print("[red]Invalid limit. Usage: /history [limit][/red]")
            return

    # Get recent queries and convert to dict format
    entries = app.query_history.get_recent_queries(limit)
    history_data = [entry.to_dict() for entry in entries]

    HistoryFormatter.format_history(history_data, limit)

