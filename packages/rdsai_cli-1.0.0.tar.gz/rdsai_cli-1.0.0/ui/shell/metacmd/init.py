"""Database memory initialization command."""

from __future__ import annotations

from typing import TYPE_CHECKING

from rich.console import Group
from rich.live import Live
from rich.spinner import Spinner
from rich.text import Text

from memory import (
    DatabaseExplorer,
    DatabaseSchemaSnapshot,
    MemoryDocumentGenerator,
    TableExploreProgress,
)
from memory.storage import get_default_storage
from loop.neoloop import NeoLoop
from ui.shell.console import console
from ui.shell.metacmd.registry import meta_command

if TYPE_CHECKING:
    from ui.shell import ShellApp


@meta_command(loop_only=True)
async def init(app: ShellApp, args: list[str]):
    """Initialize database memory by exploring schema (--force to regenerate)"""
    # Check database connection
    if not app.db_service or not app.db_service.is_connected():
        console.print("[red]✗[/red] Not connected to a database.")
        return

    conn_info = app.db_service.get_connection_info()
    if not conn_info.get("database"):
        console.print("[red]✗[/red] No database selected. Use 'USE database_name' first.")
        return

    # Parse args
    force = "--force" in args or "-f" in args

    # Get storage and connection info
    storage = get_default_storage()
    host = conn_info["host"]
    port = conn_info["port"]
    database = conn_info["database"]

    existing_memory = storage.load(host, port, database)

    console.print(f"Exploring database: [cyan]{database}[/cyan]")

    # Explore database with progress display
    snapshot, total_columns = await _explore_database(app, database)
    if snapshot is None:
        return

    # Print exploration summary
    console.print(
        f"[green]✓[/green] Explored {len(snapshot.tables)} tables "
        f"({total_columns} columns, {len(snapshot.foreign_keys)} relationships)"
    )

    # Check if schema changed (skip regeneration if unchanged and not forced)
    if existing_memory and not force:
        if existing_memory.schema_hash == snapshot.schema_hash:
            console.print(
                f"\n[green]✓[/green] Database memory is up to date. "
                f"(hash: [dim]{snapshot.schema_hash}[/dim])"
            )
            console.print(f"[dim]  Location: {storage.get_location(host, port, database)}[/dim]")
            console.print("[dim]  Use --force to regenerate.[/dim]")
            return
        else:
            console.print(
                f"[yellow]![/yellow] Schema changed "
                f"([dim]{existing_memory.schema_hash}[/dim] → [dim]{snapshot.schema_hash}[/dim])"
            )

    # Generate memory document
    memory = await _generate_memory(app, snapshot, existing_memory)
    if memory is None:
        return

    console.print("[green]✓[/green] Generated memory document")

    # Save memory
    try:
        location = storage.save(memory)
    except Exception as e:
        console.print(f"[red]✗[/red] Failed to save memory: {e}")
        return

    # Print success message
    console.print(f"\n[bold green]Database memory initialized![/bold green]")
    console.print(f"  [dim]Location: {location}[/dim]")


async def _explore_database(
    app: ShellApp, database: str
) -> tuple[DatabaseSchemaSnapshot | None, int]:
    """Explore database schema with progress display.

    Returns:
        Tuple of (snapshot, total_columns) or (None, 0) on failure.
    """
    explorer = DatabaseExplorer(app.db_service)
    snapshot: DatabaseSchemaSnapshot | None = None
    total_columns = 0

    # Progress display state
    progress_lines: list[Text] = []
    max_display_lines = 10
    current_total = 0
    spinner = Spinner("dots", style="cyan")

    def render_progress(current_table: str | None = None, current_idx: int = 0) -> Group:
        """Render current exploration progress."""
        renderables = []

        # Show recent completed tables (with scrolling effect)
        start_idx = max(0, len(progress_lines) - max_display_lines + 1)
        for line in progress_lines[start_idx:]:
            renderables.append(line)

        # Show current table with spinner
        if current_table and current_total > 0:
            current_line = Text()
            current_line.append(f"  [{current_idx}/{current_total}] ", style="dim")
            current_line.append(current_table)
            current_line.append(" ")
            renderables.append(Group(current_line, spinner))

        return Group(*renderables)

    try:
        with Live(render_progress(), console=console, refresh_per_second=10, transient=True) as live:
            for item in explorer.explore_iter():
                if isinstance(item, TableExploreProgress):
                    # Update total on first iteration
                    current_total = item.total

                    # Update display with current table
                    live.update(render_progress(item.table_name, item.current))

                    # Add completed line for this table (will show after next iteration)
                    done_line = Text()
                    done_line.append(f"  [{item.current}/{item.total}] ", style="dim")
                    done_line.append(item.table_name)
                    done_line.append(" ✓", style="green")
                    progress_lines.append(done_line)

                elif isinstance(item, DatabaseSchemaSnapshot):
                    snapshot = item
                    total_columns = sum(len(t.columns) for t in snapshot.tables)

    except Exception as e:
        console.print(f"[red]✗[/red] Failed to explore database: {e}")
        return None, 0

    if snapshot is None:
        console.print("[red]✗[/red] Failed to explore database")
        return None, 0

    return snapshot, total_columns


async def _generate_memory(
    app: ShellApp,
    snapshot: DatabaseSchemaSnapshot,
    existing_memory,
):
    """Generate memory document with progress display.

    Returns:
        Memory document or None on failure.
    """
    # Check LLM availability
    if not isinstance(app.loop, NeoLoop) or not app.loop._runtime.llm:
        console.print("[red]✗[/red] LLM not available. Cannot generate memory.")
        return None

    generator = MemoryDocumentGenerator()
    existing_content = existing_memory.content if existing_memory else None

    def render_generating() -> Group:
        """Render generating status with spinner."""
        text = Text("Generating memory document... ")
        return Group(text, Spinner("dots", style="cyan"))

    with Live(render_generating(), console=console, refresh_per_second=10, transient=True):
        try:
            memory = await generator.generate(snapshot, app.loop._runtime.llm, existing_content)
        except Exception as e:
            console.print(f"[red]✗[/red] Failed to generate document: {e}")
            return None

    return memory

