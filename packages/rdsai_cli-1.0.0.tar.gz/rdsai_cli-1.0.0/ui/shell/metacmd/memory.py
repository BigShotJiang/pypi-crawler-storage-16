"""Database memory management command."""

from __future__ import annotations

from typing import TYPE_CHECKING

from rich.markdown import Markdown
from rich.panel import Panel

from memory.storage import get_default_storage
from ui.shell.console import console
from ui.shell.metacmd.registry import meta_command

if TYPE_CHECKING:
    from ui.shell import ShellApp


_MEMORY_HELP = """[cyan]Usage:[/cyan] /memory [subcommand]

[cyan]Subcommands:[/cyan]
  [green](none)[/green]    Show formatted memory content
  [green]location[/green]  Show memory storage location
  [green]clear[/green]     Delete memory for current database
  [green]help[/green]      Show this help message

[cyan]Examples:[/cyan]
  /memory           Show current database memory
  /memory location  Show where memory is stored
  /memory clear     Delete current database memory
"""


@meta_command(aliases=["mem"])
def memory(app: ShellApp, args: list[str]):
    """Show or manage database memory"""
    # Parse subcommand first to handle help without db connection
    subcommand = args[0] if args else "show"

    if subcommand in ("help", "-h", "--help"):
        console.print(_MEMORY_HELP)
        return

    # Check database connection
    if not app.db_service or not app.db_service.is_connected():
        console.print("[red]✗[/red] Not connected to a database.")
        return

    conn_info = app.db_service.get_connection_info()
    if not conn_info.get("database"):
        console.print("[red]✗[/red] No database selected.")
        return

    storage = get_default_storage()
    host = conn_info["host"]
    port = conn_info["port"]
    database = conn_info["database"]

    if subcommand == "location":
        _show_location(storage, host, port, database)
    elif subcommand in ("clear", "delete"):
        _clear_memory(storage, host, port, database)
    elif subcommand == "show":
        _show_memory(storage, host, port, database)
    else:
        console.print(f"[red]Unknown subcommand: {subcommand}[/red]")
        console.print("[dim]Use /memory help to see available commands.[/dim]")


def _show_location(storage, host: str, port: int, database: str):
    """Show storage location."""
    location = storage.get_location(host, port, database)
    exists = storage.exists(host, port, database)
    status = "[green]exists[/green]" if exists else "[dim]not created[/dim]"
    console.print(f"Memory location ({status}): {location}")


def _clear_memory(storage, host: str, port: int, database: str):
    """Delete memory."""
    if storage.delete(host, port, database):
        console.print("[green]✓[/green] Memory deleted.")
    else:
        console.print("[yellow]Memory doesn't exist.[/yellow]")


def _show_memory(storage, host: str, port: int, database: str):
    """Show formatted content."""
    mem = storage.load(host, port, database)
    if not mem:
        console.print("[yellow]No memory found for this database.[/yellow]")
        console.print("[dim]Run /init to generate database memory.[/dim]")
        return

    console.print(
        Panel(
            Markdown(mem.content),
            title=f"Database Memory: {database}",
            border_style="blue",
            padding=(1, 2),
        )
    )
    console.print(f"[dim]Location: {storage.get_location(host, port, database)}[/dim]")

