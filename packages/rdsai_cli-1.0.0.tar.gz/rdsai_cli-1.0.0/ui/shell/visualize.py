from __future__ import annotations

import asyncio
import random
from collections import deque
from collections.abc import Callable
from contextlib import asynccontextmanager, suppress
from typing import NamedTuple

import streamingjson  # pyright: ignore[reportMissingTypeStubs]
from loop.types import (
    AudioURLPart,
    ContentPart,
    ImageURLPart,
    TextPart,
    ThinkPart,
    ToolCall,
    ToolCallPart,
)
from loop.toolset import ToolError, ToolOk, ToolResult, ToolReturnType
from rich.console import Group, RenderableType
from rich.live import Live
from rich.markup import escape
from rich.panel import Panel
from rich.spinner import Spinner
from rich.syntax import Syntax
from rich.text import Text

from loop import StatusSnapshot
from tools import extract_key_argument
from ui.shell.console import console
from ui.shell.keyboard import KeyEvent, listen_for_keyboard
from utils.rich.columns import BulletColumns
from utils.rich.markdown import Markdown
from events import StreamMessage, StreamUISide
from events.message import (
    ApprovalRequest,
    ApprovalResponse,
    CompactionBegin,
    CompactionEnd,
    StatusUpdate,
    StepBegin,
    StepInterrupted,
)

MAX_SUBAGENT_TOOL_CALLS_TO_SHOW = 4

# Spinner text variants for content blocks (without trailing dots)
THINKING_TEXTS = [
    "Thinking...",
    "Contemplating...",
    "Reasoning...",
    "Analyzing...",
    "Reflecting...",
    "Considering...",
    "Deliberating...",
]

COMPOSING_TEXTS = [
    "Composing...",
    "Writing...",
    "Crafting...",
    "Generating...",
    "Creating...",
    "Formulating...",
    "Drafting...",
    "Preparing...",
]


async def visualize(
    stream: StreamUISide,
    *,
    initial_status: StatusSnapshot,
    cancel_event: asyncio.Event | None = None,
):
    """
    A loop to consume agent events and visualize the agent behavior.

    Args:
        stream: Communication channel with the agent
        initial_status: Initial status snapshot
        cancel_event: Event that can be set (e.g., by ESC key) to cancel the run
    """
    view = _LiveView(initial_status, cancel_event)
    await view.visualize_loop(stream)


class _ContentBlock:
    def __init__(self, is_think: bool):
        self.is_think = is_think
        text = random.choice(THINKING_TEXTS if is_think else COMPOSING_TEXTS)
        self._spinner = Spinner("dots2", text)
        self.raw_text = ""

    def compose(self) -> RenderableType:
        return self._spinner

    def compose_final(self) -> RenderableType:
        return BulletColumns(
            Markdown(
                self.raw_text,
                style="grey50 italic" if self.is_think else "",
            ),
            bullet_style="grey50",
        )

    def append(self, content: str) -> None:
        self.raw_text += content


class _ToolCallBlock:
    class FinishedSubCall(NamedTuple):
        call: ToolCall
        result: ToolReturnType

    def __init__(self, tool_call: ToolCall, intent_text: str | None = None, intent_is_think: bool = False):
        self._tool_name = tool_call.function.name
        self._lexer = streamingjson.Lexer()
        if tool_call.function.arguments is not None:
            self._lexer.append_string(tool_call.function.arguments)

        self._argument = extract_key_argument(self._lexer, self._tool_name)
        self._result: ToolReturnType | None = None
        self._intent_text = intent_text  # The agent's reasoning/intent before tool call
        self._intent_is_think = intent_is_think  # Whether the intent is from ThinkPart

        self._ongoing_subagent_tool_calls: dict[str, ToolCall] = {}
        self._last_subagent_tool_call: ToolCall | None = None
        self._n_finished_subagent_tool_calls = 0
        self._finished_subagent_tool_calls = deque[_ToolCallBlock.FinishedSubCall](
            maxlen=MAX_SUBAGENT_TOOL_CALLS_TO_SHOW
        )

        self._spinning_dots = Spinner("dots", text="")
        self._renderable: RenderableType = self._compose()

    def compose(self) -> RenderableType:
        return self._renderable

    @property
    def finished(self) -> bool:
        return self._result is not None

    def append_args_part(self, args_part: str):
        if self.finished:
            return
        self._lexer.append_string(args_part)
        argument = extract_key_argument(self._lexer, self._tool_name)
        if argument and argument != self._argument:
            self._argument = argument
            self._renderable: RenderableType = BulletColumns(
                Text.from_markup(self._get_headline_markup()),
                bullet=self._spinning_dots,
            )

    def finish(self, result: ToolReturnType):
        self._result = result
        self._renderable = self._compose()

    def append_sub_tool_call(self, tool_call: ToolCall):
        self._ongoing_subagent_tool_calls[tool_call.id] = tool_call
        self._last_subagent_tool_call = tool_call

    def append_sub_tool_call_part(self, tool_call_part: ToolCallPart):
        if self._last_subagent_tool_call is None:
            return
        if not tool_call_part.arguments_part:
            return
        if self._last_subagent_tool_call.function.arguments is None:
            self._last_subagent_tool_call.function.arguments = tool_call_part.arguments_part
        else:
            self._last_subagent_tool_call.function.arguments += tool_call_part.arguments_part

    def finish_sub_tool_call(self, tool_result: ToolResult):
        self._last_subagent_tool_call = None
        sub_tool_call = self._ongoing_subagent_tool_calls.pop(tool_result.tool_call_id, None)
        if sub_tool_call is None:
            return

        self._finished_subagent_tool_calls.append(
            _ToolCallBlock.FinishedSubCall(
                call=sub_tool_call,
                result=tool_result.result,
            )
        )
        self._n_finished_subagent_tool_calls += 1
        self._renderable = self._compose()

    def _compose(self) -> RenderableType:
        blocks: list[RenderableType] = []
        
        # Render intent text if present (agent's reasoning before tool call)
        if self._intent_text:
            blocks.append(
                BulletColumns(
                    Markdown(
                        self._intent_text.strip(),
                        style="grey50 italic" if self._intent_is_think else "",
                    ),
                    bullet=Text("⏺", style="grey50" if self._intent_is_think else "cyan"),
                )
            )
            # Add empty line between intent and tool call
            blocks.append(Text(""))
        
        # Tool call headline and details
        tool_lines: list[RenderableType] = [
            Text.from_markup(self._get_headline_markup()),
        ]

        if self._n_finished_subagent_tool_calls > MAX_SUBAGENT_TOOL_CALLS_TO_SHOW:
            n_hidden = self._n_finished_subagent_tool_calls - MAX_SUBAGENT_TOOL_CALLS_TO_SHOW
            tool_lines.append(
                BulletColumns(
                    Text(
                        f"{n_hidden} more tool call{'s' if n_hidden > 1 else ''} ...",
                        style="grey50 italic",
                    ),
                    bullet_style="grey50",
                )
            )
        for sub_call, sub_result in self._finished_subagent_tool_calls:
            argument = extract_key_argument(
                sub_call.function.arguments or "", sub_call.function.name
            )
            tool_lines.append(
                BulletColumns(
                    Text.from_markup(
                        f"Used [bold white]{sub_call.function.name}[/bold white]"
                        + (f" [grey50]({argument})[/grey50]" if argument else "")
                    ),
                    bullet_style="green" if isinstance(sub_result, ToolOk) else "red",
                )
            )

        if self._result is not None and self._result.brief:
            tool_lines.append(
                BulletColumns(
                    Markdown(
                        self._result.brief,
                        style="grey50" if isinstance(self._result, ToolOk) else "red",
                    ),
                    bullet=Text("⎿", style="grey50"),
                )
            )

        # Determine bullet style based on status
        if self.finished:
            bullet_style = "green" if isinstance(self._result, ToolOk) else "red"
            blocks.append(
                BulletColumns(
                    Group(*tool_lines),
                    bullet=Text("⏺", style=bullet_style),
                )
            )
        else:
            blocks.append(
                BulletColumns(
                    Group(*tool_lines),
                    bullet=self._spinning_dots,
                )
            )
        
        return Group(*blocks)

    def _get_headline_markup(self) -> str:
        return f"{'Used' if self.finished else 'Using'} [bold white]{self._tool_name}[/bold white]" + (
            f" [grey50]({escape(self._argument)})[/grey50]" if self._argument else ""
        )


class _ApprovalPanelRenderer:
    """Base class for approval panel renderers."""
    
    title: str = "[yellow]⚠ Approval Requested[/yellow]"
    
    def __init__(self, request: ApprovalRequest):
        self.request = request
    
    def render_preamble(self) -> RenderableType | None:
        """Render content that should be printed BEFORE the panel (e.g., SQL statements).
        
        This content is printed separately using console.print() and won't be 
        included in the Live view, avoiding truncation issues with long content.
        
        Returns:
            Renderable content to print before the panel, or None if nothing to print.
        """
        return None
    
    def render_header(self) -> list[RenderableType]:
        """Render the header section."""
        return [
            Text.assemble(
                Text.from_markup(f"[blue]{self.request.sender}[/blue]"),
                Text(f' is requesting approval to "{self.request.description}".'),
            ),
            Text(""),
        ]
    
    def render_body(self) -> list[RenderableType]:
        """Render the body section. Override in subclasses for custom content."""
        return []
    
    def render(self, options: list[RenderableType]) -> RenderableType:
        """Render the complete panel."""
        lines: list[RenderableType] = []
        lines.extend(self.render_header())
        lines.extend(self.render_body())
        lines.extend(options)
        
        return Panel(
            Group(*lines),
            title=self.title,
            border_style="yellow",
            padding=(1, 2),
            expand=True,
        )


class _DDLApprovalRenderer(_ApprovalPanelRenderer):
    """Renderer for DDL approval requests with SQL code block and risk indicator."""
    
    title = "[yellow]⚠ DDL Approval Required[/yellow]"
    
    # Risk level configuration: (prefix, style, label)
    RISK_LEVELS: list[tuple[str, str, str]] = [
        ("DROP", "red bold", "⚠ HIGH RISK"),
        ("TRUNCATE", "red bold", "⚠ HIGH RISK"),
        ("ALTER", "yellow", "⚡ MEDIUM RISK"),
    ]
    DEFAULT_RISK = ("green", "✓ LOW RISK")
    
    def render_preamble(self) -> RenderableType | None:
        """Render SQL statement separately before the panel to avoid truncation."""
        tool_args = self.request.tool_args or {}
        sql_statement = tool_args.get("sql_statement", "")
        
        if not sql_statement:
            return None
        
        # Render SQL with syntax highlighting in a separate panel
        sql_syntax = Syntax(
            sql_statement.strip(),
            "sql",
            theme="monokai",
            line_numbers=True,
            word_wrap=True,
            padding=(0, 1),
        )
        return Panel(
            sql_syntax,
            title="[bold]SQL Statement[/bold]",
            border_style="blue",
            padding=(0, 0),
            expand=True,
        )
    
    def render_header(self) -> list[RenderableType]:
        return [
            Text.assemble(
                Text.from_markup(f"[blue]{self.request.sender}[/blue]"),
                Text(" is requesting approval to execute DDL."),
            ),
            Text(""),
        ]
    
    def render_body(self) -> list[RenderableType]:
        lines: list[RenderableType] = []
        tool_args = self.request.tool_args or {}
        
        sql_statement = tool_args.get("sql_statement", "")
        description = tool_args.get("description", self.request.description)
        
        # Risk indicator
        risk_style, risk_label = self._get_risk_level(sql_statement)
        lines.append(Text(risk_label, style=risk_style))
        lines.append(Text(""))
        
        # Description
        if description:
            lines.append(Text.from_markup(f"[bold]Description:[/bold] {description}"))
            lines.append(Text(""))
        
        return lines
    
    def _get_risk_level(self, sql: str) -> tuple[str, str]:
        """Determine risk level based on SQL statement."""
        sql_upper = sql.strip().upper()
        for prefix, style, label in self.RISK_LEVELS:
            if sql_upper.startswith(prefix):
                return style, label
        return self.DEFAULT_RISK


# Registry of custom renderers by action name
_APPROVAL_RENDERERS: dict[str, type[_ApprovalPanelRenderer]] = {
    "DDLExecutor": _DDLApprovalRenderer,
}


def _get_approval_renderer(request: ApprovalRequest) -> _ApprovalPanelRenderer:
    """Get the appropriate renderer for an approval request."""
    renderer_cls = _APPROVAL_RENDERERS.get(request.action, _ApprovalPanelRenderer)
    # Only use custom renderer if tool_args is provided
    if renderer_cls != _ApprovalPanelRenderer and not request.tool_args:
        renderer_cls = _ApprovalPanelRenderer
    return renderer_cls(request)


class _ApprovalRequestPanel:
    def __init__(self, request: ApprovalRequest):
        self.request = request
        self.options = [
            ("Approve", ApprovalResponse.APPROVE),
            ("Approve for this session", ApprovalResponse.APPROVE_FOR_SESSION),
            ("Reject, tell MySQL CLI what to run instead.", ApprovalResponse.REJECT),
        ]
        self.selected_index = 0
        self._renderer = _get_approval_renderer(request)

    def render(self) -> RenderableType:
        """Render the approval menu as a panel."""
        return self._renderer.render(self._render_options())

    def _render_options(self) -> list[RenderableType]:
        """Render the menu options."""
        options: list[RenderableType] = []
        for i, (option_text, _) in enumerate(self.options):
            if i == self.selected_index:
                options.append(Text(f"→ {option_text}", style="cyan"))
            else:
                options.append(Text(f"  {option_text}", style="grey50"))
        return options

    def move_up(self):
        """Move selection up."""
        self.selected_index = (self.selected_index - 1) % len(self.options)

    def move_down(self):
        """Move selection down."""
        self.selected_index = (self.selected_index + 1) % len(self.options)

    def get_selected_response(self) -> ApprovalResponse:
        """Get the approval response based on selected option."""
        return self.options[self.selected_index][1]


class _StatusBlock:
    def __init__(self, initial: StatusSnapshot) -> None:
        self.text = Text("", justify="right", style="grey50")
        self.update(initial)

    def render(self) -> RenderableType:
        return self.text

    def update(self, status: StatusSnapshot) -> None:
        if status.context_usage < 0:
            self.text.plain = ""
        else:
            self.text.plain = f"context: {status.context_usage:.1%}"


@asynccontextmanager
async def _keyboard_listener(handler: Callable[[KeyEvent], None]):
    async def _keyboard():
        async for event in listen_for_keyboard():
            handler(event)

    task = asyncio.create_task(_keyboard())
    try:
        yield
    finally:
        task.cancel()
        with suppress(asyncio.CancelledError):
            await task


class _LiveView:
    def __init__(self, initial_status: StatusSnapshot, cancel_event: asyncio.Event | None = None):
        self._cancel_event = cancel_event

        self._mooning_spinner: Spinner | None = None
        self._compacting_spinner: Spinner | None = None

        self._current_content_block: _ContentBlock | None = None
        self._tool_call_blocks: dict[str, _ToolCallBlock] = {}
        self._last_tool_call_block: _ToolCallBlock | None = None
        self._approval_request_queue = deque[ApprovalRequest]()
        self._current_approval_request_panel: _ApprovalRequestPanel | None = None
        self._reject_all_following = False
        self._status_block = _StatusBlock(initial_status)

        self._need_recompose = False
        self._need_trailing_newline = False  # Track if we need an empty line after tool calls

    async def visualize_loop(self, stream: StreamUISide):
        with Live(
            self.compose(),
            console=console,
            refresh_per_second=10,
            transient=True,
            vertical_overflow="visible",
        ) as live:

            def keyboard_handler(event: KeyEvent) -> None:
                self.dispatch_keyboard_event(event)
                if self._need_recompose:
                    live.update(self.compose())
                    self._need_recompose = False

            async with _keyboard_listener(keyboard_handler):
                while True:
                    try:
                        msg = await stream.receive()
                    except asyncio.QueueShutDown:
                        self.cleanup(is_interrupt=False)
                        live.update(self.compose())
                        break

                    if isinstance(msg, StepInterrupted):
                        self.cleanup(is_interrupt=True)
                        live.update(self.compose())
                        break

                    self.dispatch_stream_message(msg)
                    if self._need_recompose:
                        live.update(self.compose())
                        self._need_recompose = False

    def refresh_soon(self) -> None:
        self._need_recompose = True

    def compose(self) -> RenderableType:
        """Compose the live view display content."""
        blocks: list[RenderableType] = []
        if self._mooning_spinner is not None:
            blocks.append(self._mooning_spinner)
        elif self._compacting_spinner is not None:
            blocks.append(self._compacting_spinner)
            if self._current_approval_request_panel is not None:
                blocks.append(self._current_approval_request_panel.render())
        elif self._current_approval_request_panel is not None:
            blocks.append(self._current_approval_request_panel.render())
        else:
            if self._current_content_block is not None:
                blocks.append(self._current_content_block.compose())
            for tool_call in self._tool_call_blocks.values():
                blocks.append(tool_call.compose())
        blocks.append(self._status_block.render())
        return Group(*blocks)

    def dispatch_stream_message(self, msg: StreamMessage) -> None:
        """Dispatch the stream message to UI components."""
        assert not isinstance(msg, StepInterrupted)  # handled in visualize_loop

        if isinstance(msg, StepBegin):
            self.cleanup(is_interrupt=False)
            self._mooning_spinner = Spinner("moon", "")
            self.refresh_soon()
            return

        if self._mooning_spinner is not None:
            self._mooning_spinner = None
            self.refresh_soon()

        match msg:
            case CompactionBegin():
                self._compacting_spinner = Spinner("balloon2", "Compacting...")
                self.refresh_soon()
            case CompactionEnd():
                self._compacting_spinner = None
                self.refresh_soon()
            case StatusUpdate(status=status):
                self._status_block.update(status)
            case TextPart() | ImageURLPart() | AudioURLPart() | ThinkPart() | ToolCallPart():
                self.append_content(msg)
            case ToolCall():
                self.append_tool_call(msg)
            case ToolCallPart():
                self.append_tool_call_part(msg)
            case ToolResult():
                self.append_tool_result(msg)
            case ApprovalRequest():
                self.request_approval(msg)


    def dispatch_keyboard_event(self, event: KeyEvent) -> None:
        # handle ESC key to cancel the run
        if event == KeyEvent.ESCAPE and self._cancel_event is not None:
            self._cancel_event.set()
            return

        if not self._current_approval_request_panel:
            # just ignore any keyboard event when there's no approval request
            return

        match event:
            case KeyEvent.UP:
                self._current_approval_request_panel.move_up()
                self.refresh_soon()
            case KeyEvent.DOWN:
                self._current_approval_request_panel.move_down()
                self.refresh_soon()
            case KeyEvent.ENTER:
                resp = self._current_approval_request_panel.get_selected_response()
                self._current_approval_request_panel.request.resolve(resp)
                if resp == ApprovalResponse.APPROVE_FOR_SESSION:
                    to_remove_from_queue: list[ApprovalRequest] = []
                    for request in self._approval_request_queue:
                        # approve all queued requests with the same action
                        if request.action == self._current_approval_request_panel.request.action:
                            request.resolve(ApprovalResponse.APPROVE_FOR_SESSION)
                            to_remove_from_queue.append(request)
                    for request in to_remove_from_queue:
                        self._approval_request_queue.remove(request)
                elif resp == ApprovalResponse.REJECT:
                    # one rejection should stop the step immediately
                    while self._approval_request_queue:
                        self._approval_request_queue.popleft().resolve(ApprovalResponse.REJECT)
                    self._reject_all_following = True
                self.show_next_approval_request()
            case _:
                # just ignore any other keyboard event
                return

    def cleanup(self, is_interrupt: bool) -> None:
        """Cleanup the live view on step end or interruption."""
        self.flush_content()

        for block in self._tool_call_blocks.values():
            if not block.finished:
                # this should not happen, but just in case
                block.finish(
                    ToolError(message="", brief="Interrupted")
                    if is_interrupt
                    else ToolOk(output="")
                )
        self._last_tool_call_block = None
        self.flush_finished_tool_calls()
        self._flush_trailing_newline()  # Print deferred empty line at cleanup

        while self._approval_request_queue:
            # should not happen, but just in case
            self._approval_request_queue.popleft().resolve(ApprovalResponse.REJECT)
        self._current_approval_request_panel = None
        self._reject_all_following = False

    def flush_content(self) -> None:
        """Flush the current content block."""
        if self._current_content_block is not None:
            console.print(self._current_content_block.compose_final())
            console.print()  # Add empty line after content block
            self._current_content_block = None
            self.refresh_soon()

    def flush_finished_tool_calls(self) -> None:
        """Flush all leading finished tool call blocks.
        
        Tool calls are printed without empty lines between them.
        Empty line is deferred until next content block or cleanup.
        """
        tool_call_ids = list(self._tool_call_blocks.keys())
        
        for tool_call_id in tool_call_ids:
            block = self._tool_call_blocks[tool_call_id]
            if not block.finished:
                break

            self._tool_call_blocks.pop(tool_call_id)
            console.print(block.compose())
            self._need_trailing_newline = True  # Defer empty line
            if self._last_tool_call_block == block:
                self._last_tool_call_block = None
        
        self.refresh_soon()

    def _flush_trailing_newline(self) -> None:
        """Print deferred empty line after tool calls if needed."""
        if self._need_trailing_newline:
            console.print()
            self._need_trailing_newline = False

    def append_content(self, part: ContentPart) -> None:
        match part:
            case ThinkPart(think=text) | TextPart(text=text):
                if not text:
                    return
                is_think = isinstance(part, ThinkPart)
                if self._current_content_block is None:
                    self._flush_trailing_newline()
                    self._current_content_block = _ContentBlock(is_think)
                    self.refresh_soon()
                elif self._current_content_block.is_think != is_think:
                    self.flush_content()
                    self._current_content_block = _ContentBlock(is_think)
                    self.refresh_soon()
                self._current_content_block.append(text)
            case _:
                pass

    def append_tool_call(self, tool_call: ToolCall) -> None:
        # Capture current content as intent text before flushing
        intent_text: str | None = None
        intent_is_think: bool = False
        if self._current_content_block is not None:
            intent_text = self._current_content_block.raw_text.strip() or None
            intent_is_think = self._current_content_block.is_think
            self._current_content_block = None
        
        self._tool_call_blocks[tool_call.id] = _ToolCallBlock(tool_call, intent_text, intent_is_think)
        self._last_tool_call_block = self._tool_call_blocks[tool_call.id]
        self.refresh_soon()

    def append_tool_call_part(self, part: ToolCallPart) -> None:
        if not part.arguments_part:
            return
        if self._last_tool_call_block is None:
            return
        self._last_tool_call_block.append_args_part(part.arguments_part)
        self.refresh_soon()

    def append_tool_result(self, result: ToolResult) -> None:
        if block := self._tool_call_blocks.get(result.tool_call_id):
            block.finish(result.result)
            self.flush_finished_tool_calls()
            self.refresh_soon()

    def request_approval(self, request: ApprovalRequest) -> None:
        # If we're rejecting all following requests, reject immediately
        if self._reject_all_following:
            request.resolve(ApprovalResponse.REJECT)
            return

        self._approval_request_queue.append(request)

        if self._current_approval_request_panel is None:
            console.bell()
            self.show_next_approval_request()

    def show_next_approval_request(self) -> None:
        """
        Show the next approval request from the queue.
        If there are no pending requests, clear the current approval panel.
        """
        if not self._approval_request_queue:
            if self._current_approval_request_panel is not None:
                self._current_approval_request_panel = None
                self.refresh_soon()
            return

        while self._approval_request_queue:
            request = self._approval_request_queue.popleft()
            if request.resolved:
                # skip resolved requests
                continue
            
            # Print trailing newline to separate from previous output
            self._flush_trailing_newline()
            
            # Print preamble (e.g., SQL statement) separately before the panel
            # This ensures long content is fully displayed without truncation
            renderer = _get_approval_renderer(request)
            preamble = renderer.render_preamble()
            if preamble is not None:
                console.print(preamble)
            
            self._current_approval_request_panel = _ApprovalRequestPanel(request)
            self.refresh_soon()
            break

