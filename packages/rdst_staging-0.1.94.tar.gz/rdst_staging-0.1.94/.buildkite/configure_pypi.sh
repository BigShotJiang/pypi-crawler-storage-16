#!/usr/bin/env bash
set -euo pipefail

# Configure and verify PyPI credentials for RDST publishing
# This script helps set up the PYPI_TOKEN for Buildkite or local testing

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "PyPI Credentials Configuration for RDST"
echo "========================================"
echo ""

# Check if twine is installed
if ! python -m pip show twine &> /dev/null; then
    echo "Installing twine..."
    python -m pip install --upgrade twine
fi

# Function to test PyPI token
test_pypi_token() {
    local token=$1
    local test_pypi=${2:-false}

    if [[ "$test_pypi" == "true" ]]; then
        local repo_url="https://test.pypi.org/legacy/"
        echo "Testing token with TestPyPI..."
    else
        local repo_url="https://upload.pypi.org/legacy/"
        echo "Testing token with PyPI..."
    fi

    # Try to list package info (doesn't require upload)
    if curl -s -f -H "Authorization: Bearer $token" "$repo_url" > /dev/null 2>&1; then
        echo "✓ Token is valid"
        return 0
    else
        echo "✗ Token validation failed"
        return 1
    fi
}

# Check if PYPI_TOKEN is already set
if [[ -n "${PYPI_TOKEN:-}" ]]; then
    echo "✓ PYPI_TOKEN is already set in environment"
    echo ""

    read -p "Test the token? (y/N) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        test_pypi_token "$PYPI_TOKEN"
    fi

    echo ""
    echo "Ready to publish to PyPI!"
    exit 0
fi

# Check AWS Secrets Manager
echo "Checking AWS Secrets Manager..."
if command -v aws &> /dev/null; then
    if SECRET_VALUE=$(aws secretsmanager get-secret-value \
        --secret-id buildkite/rdst/pypi-token \
        --region us-east-2 \
        --query SecretString \
        --output text 2>/dev/null); then

        echo "✓ Found PyPI token in AWS Secrets Manager"
        export PYPI_TOKEN="$SECRET_VALUE"

        echo ""
        read -p "Test the token? (y/N) " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            test_pypi_token "$PYPI_TOKEN"
        fi

        echo ""
        echo "✓ PYPI_TOKEN loaded from AWS Secrets Manager"
        echo "Ready to publish to PyPI!"
        exit 0
    else
        echo "ℹ️  No token found in AWS Secrets Manager"
    fi
else
    echo "ℹ️  AWS CLI not available"
fi

# Interactive setup
echo ""
echo "PyPI token not found. Let's set it up!"
echo ""
echo "Options:"
echo "  1. Enter PyPI token manually (for testing)"
echo "  2. Store token in AWS Secrets Manager (recommended for production)"
echo "  3. Exit and configure in Buildkite environment"
echo ""
read -p "Choose option (1-3): " -n 1 -r
echo
echo ""

case $REPLY in
    1)
        echo "Enter your PyPI token (starts with pypi-...):"
        read -s PYPI_TOKEN
        echo ""

        if [[ ! "$PYPI_TOKEN" =~ ^pypi- ]]; then
            echo "⚠️  Warning: Token should start with 'pypi-'"
            read -p "Continue anyway? (y/N) " -n 1 -r
            echo
            if [[ ! $REPLY =~ ^[Yy]$ ]]; then
                exit 1
            fi
        fi

        # Test the token
        test_pypi_token "$PYPI_TOKEN" || {
            echo "Token test failed. Please check your token and try again."
            exit 1
        }

        export PYPI_TOKEN

        echo ""
        echo "✓ Token configured for this session"
        echo ""
        echo "To make this permanent, either:"
        echo "  1. Add to Buildkite environment variables"
        echo "  2. Store in AWS Secrets Manager (option 2)"
        echo "  3. Add to your shell profile: export PYPI_TOKEN='pypi-...'"
        ;;

    2)
        if ! command -v aws &> /dev/null; then
            echo "Error: AWS CLI is not installed"
            exit 1
        fi

        echo "Enter your PyPI token (starts with pypi-...):"
        read -s PYPI_TOKEN
        echo ""

        if [[ ! "$PYPI_TOKEN" =~ ^pypi- ]]; then
            echo "⚠️  Warning: Token should start with 'pypi-'"
            read -p "Continue anyway? (y/N) " -n 1 -r
            echo
            if [[ ! $REPLY =~ ^[Yy]$ ]]; then
                exit 1
            fi
        fi

        echo "Storing token in AWS Secrets Manager..."
        aws secretsmanager create-secret \
            --name buildkite/rdst/pypi-token \
            --description "PyPI API token for RDST publishing" \
            --secret-string "$PYPI_TOKEN" \
            --region us-east-2 2>/dev/null || {

            # If secret already exists, update it
            echo "Secret already exists, updating..."
            aws secretsmanager put-secret-value \
                --secret-id buildkite/rdst/pypi-token \
                --secret-string "$PYPI_TOKEN" \
                --region us-east-2
        }

        export PYPI_TOKEN

        echo ""
        echo "✓ Token stored in AWS Secrets Manager: buildkite/rdst/pypi-token"
        echo ""
        echo "Make sure your Buildkite IAM role has permission to read it:"
        echo "  aws secretsmanager get-secret-value \\"
        echo "    --secret-id buildkite/rdst/pypi-token \\"
        echo "    --region us-east-2"
        ;;

    3)
        echo "To configure in Buildkite:"
        echo "  1. Go to your Buildkite pipeline settings"
        echo "  2. Add environment variable: PYPI_TOKEN"
        echo "  3. Paste your PyPI token value"
        echo "  4. Mark as 'Secret' to hide from logs"
        echo ""
        exit 0
        ;;

    *)
        echo "Invalid option"
        exit 1
        ;;
esac

echo ""
echo "========================================="
echo "✓ PyPI credentials configured!"
echo "========================================="
echo ""
echo "Next steps:"
echo "  1. Test upload to TestPyPI (optional):"
echo "     cd rdst"
echo "     ./rdst/.buildkite/build_package.sh"
echo "     python -m twine upload --repository testpypi dist/*"
echo ""
echo "  2. Or test production workflow:"
echo "     ./rdst/.buildkite/deploy_release.sh"
echo ""
