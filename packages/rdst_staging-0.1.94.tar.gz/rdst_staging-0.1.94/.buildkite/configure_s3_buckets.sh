#!/usr/bin/env bash
set -euo pipefail

# Script to configure S3 bucket permissions for RDST
# Run this with AWS credentials that have S3 admin access

BUCKET_TEST="readyset-rdst-test"
BUCKET_RELEASE="readyset-rdst"

echo "Configuring S3 buckets for RDST..."
echo ""

# 1. Ensure test bucket is PRIVATE (default behavior)
echo "1. Configuring $BUCKET_TEST as PRIVATE..."
aws s3api put-public-access-block \
  --bucket "$BUCKET_TEST" \
  --public-access-block-configuration \
    "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"
echo "   ✓ $BUCKET_TEST is now private (blocks all public access)"
echo ""

# 2. Configure release bucket to allow public access for release/latest path only
echo "2. Configuring $BUCKET_RELEASE for public release/latest path..."

# Allow bucket policies but keep ACLs blocked (modern best practice)
aws s3api put-public-access-block \
  --bucket "$BUCKET_RELEASE" \
  --public-access-block-configuration \
    "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=false,RestrictPublicBuckets=false"
echo "   ✓ $BUCKET_RELEASE now allows public bucket policies (ACLs remain disabled)"

# Create bucket policy to make release/latest/* public
echo "   Applying bucket policy to make release/latest/* public..."
POLICY=$(cat <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "PublicReadReleaseLatest",
      "Effect": "Allow",
      "Principal": "*",
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::${BUCKET_RELEASE}/release/latest/*"
    }
  ]
}
EOF
)

aws s3api put-bucket-policy --bucket "$BUCKET_RELEASE" --policy "$POLICY"
echo "   ✓ Bucket policy applied - release/latest/* is now public"
echo ""

echo "3. Testing bucket configurations..."

# Test private bucket
echo "   Testing $BUCKET_TEST (should be private)..."
PRIVATE_TEST=$(aws s3api get-public-access-block --bucket "$BUCKET_TEST" | grep -c "true" || true)
if [[ "$PRIVATE_TEST" -eq 4 ]]; then
  echo "   ✓ $BUCKET_TEST is properly configured as PRIVATE"
else
  echo "   ⚠️  $BUCKET_TEST may not be fully private"
fi

# Test release bucket policy
echo "   Testing $BUCKET_RELEASE policy..."
if aws s3api get-bucket-policy --bucket "$BUCKET_RELEASE" --query Policy --output text | grep -q "release/latest"; then
  echo "   ✓ $BUCKET_RELEASE has the correct bucket policy"
else
  echo "   ⚠️  $BUCKET_RELEASE policy may not be configured correctly"
fi

echo ""
echo "Configuration complete!"
echo ""
echo "Summary:"
echo "  • $BUCKET_TEST: PRIVATE (requires AWS credentials)"
echo "  • $BUCKET_RELEASE: release/latest/* is PUBLIC (via bucket policy)"
echo "  • All other paths in $BUCKET_RELEASE remain private"
echo ""
echo "Test public access:"
echo "  curl https://${BUCKET_RELEASE}.s3.amazonaws.com/release/latest/<filename>"
echo ""
