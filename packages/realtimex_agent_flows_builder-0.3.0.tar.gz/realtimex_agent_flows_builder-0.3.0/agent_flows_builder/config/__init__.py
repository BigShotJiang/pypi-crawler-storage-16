"""Configuration module for Agent Flows Builder Agent."""
