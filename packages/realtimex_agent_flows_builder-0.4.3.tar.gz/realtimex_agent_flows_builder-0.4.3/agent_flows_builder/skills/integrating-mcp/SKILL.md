---
name: integrating-mcp
description: External service integration via MCP servers (Gmail, Slack, GitHub, Notion, databases). Covers server discovery with list_mcp_servers, action schema retrieval, and mcpServerAction executor configuration. Essential when user mentions third-party services or external integrations.
---

# MCP Integration Guide

## When to Use

User mentions external services: Gmail, Slack, GitHub, Notion, databases, file storage, etc.

## Discovery Workflow

### Step 1: Discover Available Servers

```
list_mcp_servers()
```

Returns available servers with action counts:
```json
[
  {"id": "GMAIL", "name": "Gmail", "actionCount": 5},
  {"id": "SLACK", "name": "Slack", "actionCount": 8}
]
```

### Step 2: Get Action Schema

```
get_mcp_action_schema(server_id="GMAIL", action_id="GMAIL__SEND_EMAIL")
```

Returns parameter schema for the specific action:
```json
{
  "name": "GMAIL__SEND_EMAIL",
  "parameters": {
    "to": {"type": "string", "required": true},
    "subject": {"type": "string", "required": true},
    "body": {"type": "string", "required": true}
  }
}
```

### Step 3: Configure mcpServerAction

Use the schema to configure the executor:

```json
{
  "type": "mcpServerAction",
  "id": "send_notification_email",
  "config": {
    "provider": "remote",
    "serverId": "GMAIL",
    "action": "GMAIL__SEND_EMAIL",
    "params": {
      "to": "{{ $recipient_email }}",
      "subject": "{{ $email_subject }}",
      "body": "{{ $email_body }}"
    }
  },
  "resultVariable": "email_result"
}
```

## Key Configuration Fields

| Field | Description |
|-------|-------------|
| `provider` | `"remote"` for cloud MCP, `"local"` for local servers |
| `serverId` | From discovery (e.g., `"GMAIL"`, `"SLACK"`) |
| `action` | Full action ID (e.g., `"GMAIL__SEND_EMAIL"`) |
| `params` | Map schema parameters to flow variables |
| `resultVariable` | Variable to store action response |

## Common MCP Actions

| Service | Common Actions |
|---------|---------------|
| Gmail | `GMAIL__SEND_EMAIL`, `GMAIL__READ_EMAILS` |
| Slack | `SLACK__POST_MESSAGE`, `SLACK__CREATE_CHANNEL` |
| GitHub | `GITHUB__CREATE_ISSUE`, `GITHUB__CREATE_PR` |
| Notion | `NOTION__CREATE_PAGE`, `NOTION__UPDATE_PAGE` |

**Note**: Available servers and actions depend on the user's MCP configuration.
