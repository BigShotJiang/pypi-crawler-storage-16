---
name: syntax-guide
description: Reference for {{ $variable }} interpolation syntax and expression patterns. Covers direct variable access, nested property access, array indexing, loop item variables, and conditional expressions. Essential when configuring parameters that require dynamic values.
---

# Syntax Guide

## Variable Interpolation

| Syntax | Example | Use Case |
|--------|---------|----------|
| Direct reference | `{{ $user_id }}` | Access top-level variable |
| Property access | `{{ $response.data.id }}` | Access nested property |
| Array index | `{{ $items[0].name }}` | Access array element |
| Multiple in string | `https://api.com/{{ $endpoint }}/{{ $id }}` | String concatenation |

## Inside Loops

When inside a `loop` executor:
- `itemVariable` defines the current item name (e.g., `"current_article"`)
- `indexVariable` optionally defines the current index (0-based)

Access patterns:
```
{{ $current_article }}           → full item object
{{ $current_article.title }}     → item property
{{ $current_article.tags[0] }}   → nested array
```

## Conditional Expressions

Used in `conditional` executor's `conditions` array:

| Operator | Example | Description |
|----------|---------|-------------|
| `equals` | `{{ $status }} equals "active"` | String equality |
| `notEquals` | `{{ $count }} notEquals 0` | Inequality |
| `contains` | `{{ $text }} contains "error"` | Substring check |
| `greaterThan` | `{{ $score }} greaterThan 50` | Numeric comparison |
| `lessThan` | `{{ $age }} lessThan 18` | Numeric comparison |
| `isEmpty` | `{{ $list }} isEmpty` | Null/empty check |
| `isNotEmpty` | `{{ $data }} isNotEmpty` | Has value check |

## Type Coercion

Variables are coerced based on context:
- **String context**: All values become strings
- **Numeric context**: Strings parsed as numbers, booleans become 0/1
- **Boolean context**: `""`, `0`, `null`, `[]`, `{}` are falsy

## Edge Cases

| Scenario | Behavior |
|----------|----------|
| Undefined variable | Returns empty string, logs warning |
| Null property access | Returns null without error |
| Array out of bounds | Returns undefined |
| Circular reference | Detection prevents infinite loops |

## Common Mistakes

❌ **Wrong**: `$variable` (missing braces)
✅ **Correct**: `{{ $variable }}`

❌ **Wrong**: `{{ variable }}` (missing dollar sign)
✅ **Correct**: `{{ $variable }}`

❌ **Wrong**: `{{$variable}}` (missing spaces)
✅ **Correct**: `{{ $variable }}`
