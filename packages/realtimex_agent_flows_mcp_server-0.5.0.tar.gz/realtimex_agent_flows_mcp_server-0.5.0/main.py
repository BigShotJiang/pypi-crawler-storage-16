def main():
    print("Hello from realtimex-ai-agent-flows!")


if __name__ == "__main__":
    main()
