Changes Implemented

  1. Removed Redundant Fields from FlowResult

  - ✅ Removed steps_executed
  - ✅ Removed started_at and completed_at
  - ✅ Removed state.final_variables (FlowState class entirely removed)

  2. Excluded Empty Fields from Serialization (agent_flows/models/execution.py:140-181)

  - Added errors field for internal use, but excluded from JSON serialization
  - Added model_serializer to exclude trace when None (unless in test mode)
  - Result: Clean output with no empty arrays or null trace fields

  3. Simplified Error Response Structure (agent_flows/core/execution/executor.py:507-518)

  - Error responses now use structured format with step_id and message
  - Example error output:
  "result": {
    "type": "ERROR",
    "data": {
      "step_id": "step_name",
      "message": "Error description..."
    }
  }

  4. Updated Both Build Methods (agent_flows/core/execution/executor.py)

  - _build_final_result: Uses _format_execution_error() for structured error data (line 378)
  - _build_error_result: Stores errors internally while exposing simplified structure (lines 467-490)



 Changes Made

  1. Updated _build_final_result in executor.py (line 381)

  - Before: result_data = None when target step result exists
  - After: result_data = execution_result.target_step_result.data
  - Now the actual data returned from the target step is included in the main result

  2. Updated Test Assertion in test_executor.py (line 185)

  - Before: assert result.result.data is None
  - After: assert result.result.data == "result_from_step_2"
  - Verifies the correct data is now present in the result

  Behavior

  When running a test with a target step:
  - result.data now contains the actual data returned from the target step
  - test_context.target_step_result still contains the full step result details (unchanged)
  - trace remains unchanged and continues to work as before

  This provides a cleaner frontend integration experience, as the data is directly accessible in result.data without needing to dig into the test context.

  Test Results

  ✅ All 9 executor tests pass successfully with no regressions 