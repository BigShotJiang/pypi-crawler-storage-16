"""Telemetry helpers for RealTimeX services."""

from .tracing import initialize_tracing

__all__ = ["initialize_tracing"]
