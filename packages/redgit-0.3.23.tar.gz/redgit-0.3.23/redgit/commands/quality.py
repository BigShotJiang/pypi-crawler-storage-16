"""
Code Quality command for RedGit.

Analyzes code changes for quality issues using AI or code quality integrations.

Usage:
    rg quality              : Analyze staged changes
    rg quality <file>       : Analyze specific file
    rg quality --commit sha : Analyze specific commit
    rg quality --branch     : Compare branch with main
"""

import json
import subprocess
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from ..core.config import ConfigManager, RETGIT_DIR
from ..core.gitops import GitOps
from ..core.llm import LLMClient
from ..integrations.registry import get_code_quality, get_integrations_by_type, IntegrationType

console = Console()
quality_app = typer.Typer(help="Code quality analysis")


# Default prompt template path
DEFAULT_PROMPT_PATH = Path(__file__).parent.parent / "templates" / "quality_prompt.md"
USER_PROMPT_PATH = RETGIT_DIR / "templates" / "quality_prompt.md"


def _get_code_quality():
    """Get the active code quality integration."""
    config = ConfigManager().load()
    return get_code_quality(config)


def _load_prompt_template() -> str:
    """Load the quality prompt template."""
    # Check user's custom template first
    if USER_PROMPT_PATH.exists():
        return USER_PROMPT_PATH.read_text()

    # Fall back to default template
    if DEFAULT_PROMPT_PATH.exists():
        return DEFAULT_PROMPT_PATH.read_text()

    # Fallback inline prompt
    return """Analyze the following git diff for code quality issues.
Output JSON only:
{
  "score": 0-100,
  "decision": "approve" or "reject",
  "summary": "Brief assessment",
  "issues": [
    {
      "severity": "critical|high|medium|low",
      "type": "security|bug|performance|maintainability|style",
      "file": "path/to/file",
      "line": 123,
      "description": "Issue description",
      "suggestion": "How to fix"
    }
  ]
}

{{DIFF}}
"""


def _get_diff(commit: Optional[str] = None, branch: Optional[str] = None, file: Optional[str] = None) -> str:
    """Get git diff for analysis."""
    try:
        if commit:
            # Diff for specific commit
            cmd = ["git", "diff", f"{commit}~1..{commit}"]
        elif branch:
            # Diff between branch and main
            main_branch = _get_main_branch()
            cmd = ["git", "diff", f"{main_branch}...{branch}"]
        elif file:
            # Diff for specific file (staged or unstaged)
            cmd = ["git", "diff", "HEAD", "--", file]
        else:
            # Staged changes
            cmd = ["git", "diff", "--staged"]

        result = subprocess.run(cmd, capture_output=True, text=True)
        diff = result.stdout.strip()

        # If no staged changes, try unstaged
        if not diff and not commit and not branch:
            result = subprocess.run(["git", "diff"], capture_output=True, text=True)
            diff = result.stdout.strip()

        return diff
    except Exception:
        return ""


def _get_main_branch() -> str:
    """Get the main branch name."""
    for name in ["main", "master"]:
        result = subprocess.run(
            ["git", "rev-parse", "--verify", name],
            capture_output=True,
            text=True
        )
        if result.returncode == 0:
            return name
    return "main"


def _analyze_with_ai(diff: str, config: dict) -> dict:
    """Analyze code quality using AI."""
    if not diff:
        return {
            "score": 100,
            "decision": "approve",
            "summary": "No changes to analyze",
            "issues": []
        }

    # Load prompt template
    prompt_template = _load_prompt_template()
    prompt = prompt_template.replace("{{DIFF}}", diff)

    # Get LLM config
    llm_config = config.get("llm", {})
    if not llm_config:
        raise ValueError("No LLM configured. Run: rg init")

    # Call LLM
    client = LLMClient(llm_config)
    response = client.chat(prompt)

    # Parse JSON response
    return _parse_quality_response(response)


def _parse_quality_response(response: str) -> dict:
    """Parse JSON response from LLM."""
    # Find JSON block
    json_text = response
    if "```json" in response:
        start = response.find("```json") + 7
        end = response.find("```", start)
        json_text = response[start:end].strip()
    elif "```" in response:
        start = response.find("```") + 3
        end = response.find("```", start)
        json_text = response[start:end].strip()

    try:
        data = json.loads(json_text)
        return {
            "score": data.get("score", 0),
            "decision": data.get("decision", "reject"),
            "summary": data.get("summary", ""),
            "issues": data.get("issues", [])
        }
    except json.JSONDecodeError:
        return {
            "score": 0,
            "decision": "reject",
            "summary": "Failed to parse quality analysis response",
            "issues": []
        }


def _severity_color(severity: str) -> str:
    """Get color for severity level."""
    colors = {
        "critical": "red bold",
        "high": "red",
        "medium": "yellow",
        "low": "blue",
    }
    return colors.get(severity.lower(), "dim")


def _display_result(result: dict, threshold: int):
    """Display quality analysis result."""
    score = result.get("score", 0)
    decision = result.get("decision", "reject")
    summary = result.get("summary", "")
    issues = result.get("issues", [])

    # Score panel
    score_color = "green" if score >= threshold else "red"
    decision_icon = "[green]APPROVE[/green]" if decision == "approve" else "[red]REJECT[/red]"

    panel_content = f"""Score: [{score_color}]{score}/100[/{score_color}]
Decision: {decision_icon}
Threshold: {threshold}"""

    console.print()
    console.print(Panel(panel_content, title="Code Quality Report", border_style="cyan"))

    if summary:
        console.print(f"\n[dim]{summary}[/dim]")

    # Issues table
    if issues:
        console.print("\n[bold]Issues Found:[/bold]\n")

        table = Table(show_header=True)
        table.add_column("Severity", width=10)
        table.add_column("File", style="dim")
        table.add_column("Line", width=6)
        table.add_column("Description")

        for issue in issues:
            severity = issue.get("severity", "medium")
            color = _severity_color(severity)
            table.add_row(
                f"[{color}]{severity.upper()}[/{color}]",
                issue.get("file", "-"),
                str(issue.get("line", "-")),
                issue.get("description", "")
            )

        console.print(table)

        # Show suggestions for critical/high issues
        critical_issues = [i for i in issues if i.get("severity", "").lower() in ("critical", "high")]
        if critical_issues:
            console.print("\n[bold]Suggestions:[/bold]")
            for issue in critical_issues:
                if issue.get("suggestion"):
                    file_info = f"{issue.get('file', '')}:{issue.get('line', '')}"
                    console.print(f"  [dim]{file_info}[/dim]")
                    console.print(f"    {issue.get('suggestion')}")
                    console.print()
    else:
        console.print("\n[green]No issues found.[/green]")


def analyze_quality(
    commit: Optional[str] = None,
    branch: Optional[str] = None,
    file: Optional[str] = None,
    verbose: bool = False
) -> dict:
    """
    Analyze code quality.

    Returns:
        dict with score, decision, summary, issues
    """
    config = ConfigManager()
    full_config = config.load()

    # Check if we have a code quality integration
    quality_integration = _get_code_quality()

    if quality_integration:
        # Use integration
        if verbose:
            console.print(f"[dim]Using {quality_integration.name} integration[/dim]")

        if commit:
            status = quality_integration.get_quality_status(commit_sha=commit)
        elif branch:
            status = quality_integration.get_quality_status(branch=branch)
        else:
            # Get current branch
            try:
                gitops = GitOps()
                status = quality_integration.get_quality_status(branch=gitops.original_branch)
            except Exception:
                status = quality_integration.get_quality_status()

        if status:
            return {
                "score": int(status.coverage or 70) if hasattr(status, 'coverage') else 70,
                "decision": "approve" if status.status in ("passed", "success") else "reject",
                "summary": f"Quality gate: {status.quality_gate_status}" if status.quality_gate_status else "",
                "issues": []
            }

    # Use AI analysis
    if verbose:
        console.print("[dim]Using AI analysis[/dim]")

    diff = _get_diff(commit=commit, branch=branch, file=file)

    if not diff:
        return {
            "score": 100,
            "decision": "approve",
            "summary": "No changes to analyze",
            "issues": []
        }

    return _analyze_with_ai(diff, full_config)


@quality_app.callback(invoke_without_command=True)
def quality_main(
    ctx: typer.Context,
    file: Optional[str] = typer.Argument(None, help="File to analyze"),
    commit: Optional[str] = typer.Option(None, "--commit", "-c", help="Analyze specific commit"),
    branch: Optional[str] = typer.Option(None, "--branch", "-b", help="Compare branch with main"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show verbose output")
):
    """Analyze code quality of changes."""
    if ctx.invoked_subcommand is not None:
        return

    config = ConfigManager()

    # Check if quality is configured
    if not config.is_quality_enabled():
        console.print("[yellow]Code quality checks are not enabled.[/yellow]")
        console.print()
        console.print("Enable with: [cyan]rg config quality --enable[/cyan]")
        console.print("Or run with: [cyan]rg quality check[/cyan] to analyze without enabling")
        return

    threshold = config.get_quality_threshold()

    console.print("[bold cyan]Analyzing code quality...[/bold cyan]")

    try:
        result = analyze_quality(
            commit=commit,
            branch=branch,
            file=file,
            verbose=verbose
        )

        _display_result(result, threshold)

        # Exit with error if rejected
        if result.get("decision") != "approve":
            console.print(f"\n[red]Quality score {result.get('score')} is below threshold {threshold}[/red]")
            raise typer.Exit(1)

    except FileNotFoundError as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]Analysis failed: {e}[/red]")
        raise typer.Exit(1)


@quality_app.command("check")
def check_cmd(
    file: Optional[str] = typer.Argument(None, help="File to analyze"),
    commit: Optional[str] = typer.Option(None, "--commit", "-c", help="Analyze specific commit"),
    branch: Optional[str] = typer.Option(None, "--branch", "-b", help="Compare branch with main"),
    threshold: int = typer.Option(70, "--threshold", "-t", help="Quality threshold (0-100)"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show verbose output")
):
    """
    Run quality check (works even if quality checks are disabled).

    This command always runs analysis regardless of the quality.enabled setting.
    """
    console.print("[bold cyan]Analyzing code quality...[/bold cyan]")

    try:
        result = analyze_quality(
            commit=commit,
            branch=branch,
            file=file,
            verbose=verbose
        )

        _display_result(result, threshold)

        # Exit with error if below threshold
        if result.get("score", 0) < threshold:
            console.print(f"\n[red]Quality score {result.get('score')} is below threshold {threshold}[/red]")
            raise typer.Exit(1)

    except FileNotFoundError as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]Analysis failed: {e}[/red]")
        raise typer.Exit(1)


@quality_app.command("status")
def status_cmd():
    """Show quality settings and integration status."""
    config = ConfigManager()
    quality_config = config.get_quality_config()

    console.print("\n[bold cyan]Code Quality Settings[/bold cyan]\n")

    enabled = quality_config.get("enabled", False)
    enabled_str = "[green]Enabled[/green]" if enabled else "[dim]Disabled[/dim]"
    console.print(f"   Status: {enabled_str}")
    console.print(f"   Threshold: {quality_config.get('threshold', 70)}")
    console.print(f"   Fail on security: {quality_config.get('fail_on_security', True)}")
    console.print(f"   Prompt file: {quality_config.get('prompt_file', 'quality_prompt.md')}")

    # Check for custom prompt
    if USER_PROMPT_PATH.exists():
        console.print(f"   [green]Custom prompt: {USER_PROMPT_PATH}[/green]")
    else:
        console.print(f"   [dim]Using default prompt[/dim]")

    # Check for integration
    quality_integration = _get_code_quality()
    console.print()
    if quality_integration:
        console.print(f"   Integration: [green]{quality_integration.name}[/green]")
    else:
        console.print("   Integration: [dim]None (using AI analysis)[/dim]")
        available = get_integrations_by_type(IntegrationType.CODE_QUALITY)
        if available:
            console.print()
            console.print("   Available integrations:")
            for name in available[:5]:
                console.print(f"     [dim]- {name}[/dim]")
            console.print()
            console.print(f"   Install: [cyan]rg install {available[0]}[/cyan]")


@quality_app.command("report")
def report_cmd(
    commit: Optional[str] = typer.Option(None, "--commit", "-c", help="Analyze specific commit"),
    branch: Optional[str] = typer.Option(None, "--branch", "-b", help="Branch to analyze"),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Save report to file"),
    format: str = typer.Option("text", "--format", "-f", help="Output format: text, json")
):
    """Generate a detailed quality report."""
    console.print("[bold cyan]Generating quality report...[/bold cyan]")

    try:
        result = analyze_quality(commit=commit, branch=branch, verbose=True)

        if format == "json":
            json_output = json.dumps(result, indent=2)
            if output:
                Path(output).write_text(json_output)
                console.print(f"\n[green]Report saved to {output}[/green]")
            else:
                console.print(json_output)
        else:
            if output:
                # Generate text report
                lines = [
                    "Code Quality Report",
                    "=" * 40,
                    f"Score: {result.get('score', 0)}/100",
                    f"Decision: {result.get('decision', 'reject').upper()}",
                    f"Summary: {result.get('summary', '')}",
                    "",
                    "Issues:",
                    "-" * 40,
                ]
                for issue in result.get("issues", []):
                    lines.append(
                        f"[{issue.get('severity', '').upper()}] "
                        f"{issue.get('file', '')}:{issue.get('line', '')} - "
                        f"{issue.get('description', '')}"
                    )
                    if issue.get("suggestion"):
                        lines.append(f"  Suggestion: {issue.get('suggestion')}")

                Path(output).write_text("\n".join(lines))
                console.print(f"\n[green]Report saved to {output}[/green]")
            else:
                config = ConfigManager()
                _display_result(result, config.get_quality_threshold())

    except Exception as e:
        console.print(f"[red]Report generation failed: {e}[/red]")
        raise typer.Exit(1)
