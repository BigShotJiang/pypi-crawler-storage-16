# Minimal Prompt

Group these files into logical commits:

{{FILES}}