# redis-ext

[![PyPI - Version](https://img.shields.io/pypi/v/redis-ext.svg)](https://pypi.org/project/redis-ext)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/redis-ext.svg)](https://pypi.org/project/redis-ext)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install redis-ext
```

## License

`redis-ext` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
