#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Xiang Wang <ramwin@qq.com>


from .debounce_task import DebounceInfoTask


__all__ = ["DebounceInfoTask"]
