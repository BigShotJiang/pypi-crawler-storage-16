const t={run:"text-blue-900",model:"text-green-900",dataset:"text-orange-900",data_digest:"text-orange-900",metric:"text-orange-900"};export{t};
