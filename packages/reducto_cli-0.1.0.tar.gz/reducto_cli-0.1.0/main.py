from .cli import app, main


if __name__ == "__main__":
    main()
