from __future__ import annotations

import os
import platform
import time
import webbrowser
import asyncio

import httpx
import typer
from .config import _write_api_key, _read_saved_api_key


class AuthSpinner:
    """Simple loading spinner for authentication polling."""

    def __init__(self):
        self._spinner_chars = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
        self._running = False
        self._task = None

    async def start(self, message: str = "Waiting for authentication"):
        """Start the spinner."""
        self._running = True
        self._task = asyncio.create_task(self._spin(message))

    async def stop(self):
        """Stop the spinner."""
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass

    async def _spin(self, message: str):
        """Spinner animation loop."""
        i = 0
        while self._running:
            char = self._spinner_chars[i % len(self._spinner_chars)]
            print(f"\r{char} {message}...", end="", flush=True)
            i += 1
            await asyncio.sleep(0.1)
        print("\r" + " " * (len(message) + 10), end="", flush=True)  # Clear line


async def authenticate_with_device_code() -> None:
    """Authenticate with Reducto via device code flow."""

    # Check if API key already exists
    existing_key = _read_saved_api_key()
    if existing_key:
        if not typer.confirm("An API key is already set. Do you want to replace it?"):
            typer.echo("Authentication cancelled.")
            return

    client_info = {
        "hostname": platform.node(),
        "os": f"{platform.system()} {platform.release()}",
        "cli_version": "1.0.0",
    }

    async with httpx.AsyncClient() as client:
        studio_api_url = os.getenv(
            "REDUCTO_STUDIO_API_URL",
            "https://mild-moose-423.convex.site",
        )

        try:
            # Request device code
            response = await client.post(
                f"{studio_api_url}/deviceAuth/deviceCode",
                json={"clientInfo": client_info},
                timeout=10.0,
            )
            response.raise_for_status()
            auth_data = response.json()

            device_code = auth_data["device_code"]
            user_code = auth_data["user_code"]
            verification_uri = auth_data["verification_uri_complete"]
            interval = auth_data["interval"]
            expires_in = auth_data["expires_in"]

            # Show instructions to user
            typer.echo("\nReducto CLI Authentication")
            typer.echo(f"Your code: {typer.style(user_code, fg='cyan', bold=True)}")
            typer.echo(f"Visit: {typer.style(verification_uri, fg='blue')}")
            typer.echo(f"Code expires in {expires_in} seconds")

            # Try to open browser automatically
            try:
                webbrowser.open(verification_uri)
                typer.echo("Browser opened automatically.", err=True)
            except Exception:
                typer.echo("Could not open browser automatically.", err=True)

            # Start spinner and poll for approval
            spinner = AuthSpinner()
            await spinner.start()

            start_time = time.time()
            try:
                while time.time() - start_time < expires_in:
                    await asyncio.sleep(interval)

                    try:
                        poll_response = await client.post(
                            f"{studio_api_url}/deviceAuth/poll",
                            json={"device_code": device_code},
                            timeout=10.0,
                        )
                        poll_response.raise_for_status()
                        poll_data = poll_response.json()

                        if poll_data["status"] == "approved":
                            api_key = poll_data["api_key"]
                            _write_api_key(api_key)
                            await spinner.stop()
                            typer.echo(
                                f"{typer.style('✓ Authentication successful!', fg='green', bold=True)}"
                            )
                            typer.echo("API key saved to ~/.reducto/config.yaml")
                            return

                        elif poll_data["status"] == "denied":
                            await spinner.stop()
                            typer.echo(
                                f"{typer.style('✗ Authentication denied.', fg='red', bold=True)}"
                            )
                            raise typer.Exit(1)

                        elif poll_data["status"] == "expired":
                            await spinner.stop()
                            typer.echo(
                                f"{typer.style('✗ Authentication expired.', fg='red', bold=True)}"
                            )
                            typer.echo("Please try again.")
                            raise typer.Exit(1)

                        # Still pending, continue polling

                    except httpx.HTTPStatusError as e:
                        if e.response.status_code == 400:
                            error_data = e.response.json()
                            if error_data.get("error") == "slow_down":
                                await asyncio.sleep(interval)
                                continue
                        await spinner.stop()
                        typer.echo(f"{typer.style('✗ Polling failed:', fg='red')} {e}")
                        raise typer.Exit(1)

                # If we get here, the session expired
                await spinner.stop()
                typer.echo(
                    f"{typer.style('✗ Authentication timed out.', fg='red', bold=True)}"
                )
                typer.echo("Please try again.")
                raise typer.Exit(1)

            except Exception:
                await spinner.stop()
                raise

        except httpx.HTTPStatusError as e:
            typer.echo(f"{typer.style('✗ Authentication failed:', fg='red')} {e}")
            if e.response.status_code == 500:
                typer.echo("Server error. Please try again later.")
            raise typer.Exit(1)
        except Exception as e:
            typer.echo(f"{typer.style('✗ Authentication failed:', fg='red')} {e}")
            raise typer.Exit(1)
