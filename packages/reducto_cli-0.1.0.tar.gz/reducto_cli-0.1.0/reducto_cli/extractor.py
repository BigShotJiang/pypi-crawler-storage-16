from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any, Iterable

import typer
from reducto import AsyncReducto, ReductoError

from .files import extract_output_path, parse_output_path
from .parser import ParseInfo, parse_file, read_parse_metadata


async def extract_files(client: AsyncReducto, files: Iterable[Path], schema: object) -> None:
    tasks = [asyncio.create_task(_extract_file(client, file_path, schema)) for file_path in files]
    for task in asyncio.as_completed(tasks):
        destination = await task
        if destination is not None:
            typer.echo(f"Saved {destination}")


async def _extract_file(client: AsyncReducto, file_path: Path, schema: object) -> Path | None:
    job_id = _existing_job_id(file_path)
    parse_info: ParseInfo | None = None

    if job_id is None:
        parse_info = await parse_file(client, file_path)
        if parse_info is None:
            return None
        job_id = parse_info.job_id

    input_payload: object
    if job_id and job_id != "unknown":
        input_payload = f"jobid://{job_id}"
    else:
        try:
            upload = await client.upload(file=file_path)
        except ReductoError as exc:
            typer.echo(f"Failed to upload {file_path}: {exc}", err=True)
            return None
        input_payload = {"file_id": upload.file_id}

    try:
        response = await client.extract.run(
            input=input_payload,
            instructions={"schema": schema},
        )
    except ReductoError as exc:
        typer.echo(f"Failed to extract {file_path}: {exc}", err=True)
        return None

    content = _response_to_text(response)

    destination = extract_output_path(file_path)
    destination.write_text(json.dumps(content, indent=2, ensure_ascii=False), encoding="utf-8")
    return destination


def _existing_job_id(source: Path) -> str | None:
    metadata = read_parse_metadata(source)
    job_id = metadata.get("job_id")
    return job_id if job_id else None
def _response_to_text(response: object) -> Any:
    if hasattr(response, "model_dump"):
        data = response.model_dump()
        cleaned = _strip_metadata(data)
        return _unwrap_single_result(cleaned)
    return response


def _strip_metadata(data: Any) -> Any:
    if isinstance(data, dict):
        return {
            key: _strip_metadata(value)
            for key, value in data.items()
            if key not in {"usage", "job_id", "studio_link", "citations"}
        }
    if isinstance(data, list):
        return [_strip_metadata(item) for item in data]
    return data


def _unwrap_single_result(data: Any) -> Any:
    if isinstance(data, dict) and "result" in data and len(data) == 1:
        return _unwrap_single_result(data["result"])
    if isinstance(data, list) and len(data) == 1:
        return _unwrap_single_result(data[0])
    return data
