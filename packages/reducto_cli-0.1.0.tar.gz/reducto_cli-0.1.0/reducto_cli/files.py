from __future__ import annotations

from pathlib import Path
from typing import Iterable

import typer


PARSE_SUFFIX = ".parse.md"
EXTRACT_SUFFIX = ".extract.json"
EDIT_SUFFIX = ".edited"
GENERATED_SUFFIXES = (PARSE_SUFFIX, EXTRACT_SUFFIX)
SUPPORTED_EXTENSIONS = {".pdf", ".png", ".jpg", ".jpeg", ".doc", ".docx", ".ppt", ".pptx", ".xls", ".xlsx"}


def collect_files(target: Path) -> list[Path]:
    path = target.expanduser()
    if not path.exists():
        raise typer.BadParameter(f"{path} does not exist")

    if path.is_file():
        return [path] if _should_process(path) else []

    return sorted(p for p in _iter_files(path) if _should_process(p))


def _iter_files(directory: Path) -> Iterable[Path]:
    for item in directory.rglob("*"):
        if item.is_file():
            yield item


def is_generated(path: Path) -> bool:
    return any(path.name.endswith(suffix) for suffix in GENERATED_SUFFIXES)


def _should_process(path: Path) -> bool:
    if is_generated(path):
        return False
    return path.suffix.lower() in SUPPORTED_EXTENSIONS


def parse_output_path(source: Path) -> Path:
    return source.with_name(f"{source.name}{PARSE_SUFFIX}")


def extract_output_path(source: Path) -> Path:
    return source.with_name(f"{source.name}{EXTRACT_SUFFIX}")


def edit_output_path(source: Path) -> Path:
    return source.with_name(f"{source.stem}{EDIT_SUFFIX}{source.suffix}")
