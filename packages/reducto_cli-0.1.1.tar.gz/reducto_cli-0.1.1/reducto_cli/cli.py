from __future__ import annotations

from pathlib import Path

import typer
from async_typer import AsyncTyper, Option
from reducto import AsyncReducto

from .config import get_api_key
from .extractor import extract_files
from .editor import edit_files
from .files import collect_files
from .help_text import load_help_text
from .parser import parse_files
from .schema import load_schema
from .auth import authenticate_with_device_code


app = AsyncTyper(help=load_help_text())


@app.async_command()
async def login() -> None:
    """Authenticate with Reducto via device code flow."""
    await authenticate_with_device_code()


@app.async_command()
async def parse(
    path: Path,
    agentic: bool = Option(False, "--agentic", help="Enables all agentic options. Increases latency and accuracy"),
    change_tracking: bool = Option(False, "--change-tracking", help="Enables change tracking during parsing. Returns <s> tags around strikethrough text, <u> tags around underlined text, and <change> tags around colored adjacent strikethough and underlined text"),
    highlights: bool = Option(False, "--highlights", help="Highlight text in the parsed document"),
    hyperlinks: bool = Option(False, "--hyperlinks", help="Include embedded hyperlinks"),
    comments: bool = Option(False, "--comments", help="Include comments"),
) -> None:
    files = collect_files(path)
    if not files:
        typer.echo("No files found to parse.", err=True)
        raise typer.Exit(1)

    include = [
        option for flag, option in [
            (change_tracking, "change_tracking"),
            (highlights, "highlight"),
            (hyperlinks, "hyperlinks"),
            (comments, "comments"),
        ] if flag
    ]

    api_key = get_api_key()
    async with AsyncReducto(api_key=api_key) as client:
        await parse_files(client, files, agentic, include)


@app.async_command()
async def extract(path: Path, schema: str = Option(..., "--schema", "-s")) -> None:
    files = collect_files(path)
    if not files:
        typer.echo("No files found to extract.", err=True)
        raise typer.Exit(1)

    schema_value = load_schema(schema)
    api_key = get_api_key()
    async with AsyncReducto(api_key=api_key) as client:
        await extract_files(client, files, schema_value)


@app.async_command()
async def edit(path: Path, instructions: str = Option(..., "--instructions", "-i")) -> None:
    files = collect_files(path)
    if not files:
        typer.echo("No files found to edit.", err=True)
        raise typer.Exit(1)

    api_key = get_api_key()
    async with AsyncReducto(api_key=api_key) as client:
        await edit_files(client, files, instructions)

def main() -> None:
    app()
