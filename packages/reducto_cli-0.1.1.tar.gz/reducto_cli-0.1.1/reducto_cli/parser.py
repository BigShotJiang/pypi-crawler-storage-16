from __future__ import annotations

import asyncio
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional

import typer
from reducto import AsyncReducto, ReductoError
from reducto.types.shared.parse_response import ResultFullResult

from .files import parse_output_path


@dataclass
class ParseInfo:
    job_id: str
    duration: Optional[float]
    output_path: Path


async def parse_files(client: AsyncReducto, files: Iterable[Path], agentic: bool, formatting_include: list[str]) -> None:
    tasks = [asyncio.create_task(parse_file(client, file_path, agentic, formatting_include)) for file_path in files]
    for task in asyncio.as_completed(tasks):
        info = await task
        if info is not None:
            typer.echo(f"Saved {info.output_path}")


async def parse_file(client: AsyncReducto, file_path: Path, agentic: bool, formatting_include: list[str]) -> ParseInfo | None:
    try:
        upload = await client.upload(file=file_path)
        kwargs = {"input": {"file_id": upload.file_id}, "formatting": {"include": formatting_include}}
        if agentic:
            kwargs["enhance"] = {"agentic": [{"scope": "table"}, {"scope": "text"}, {"scope": "figure"}]}
        response = await client.parse.run(**kwargs)
    except ReductoError as exc:
        typer.echo(f"Failed to parse {file_path}: {exc}", err=True)
        return None

    text = _extract_text(response.result) if hasattr(response, "result") else None
    if text is None:
        typer.echo(f"No textual content available for {file_path}", err=True)
        return None

    job_id = getattr(response, "job_id", "unknown") or "unknown"
    duration = getattr(response, "duration", None)
    front_matter = [
        "---",
        f"job_id: {job_id}",
        f"duration: {duration if duration is not None else 'null'}",
        "---",
        "",
    ]

    destination = parse_output_path(file_path)
    destination.write_text("\n".join(front_matter + [text]), encoding="utf-8")
    return ParseInfo(job_id=job_id, duration=duration, output_path=destination)


def _extract_text(result: object) -> Optional[str]:
    if isinstance(result, ResultFullResult) and result.chunks:
        return result.chunks[0].content
    return None


def read_parse_metadata(source: Path) -> dict[str, str]:
    path = parse_output_path(source)
    if not path.exists():
        return {}
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return {}

    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return {}

    data: dict[str, str] = {}
    for line in lines[1:]:
        stripped = line.strip()
        if stripped == "---":
            break
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        data[key.strip()] = value.strip()
    return data
