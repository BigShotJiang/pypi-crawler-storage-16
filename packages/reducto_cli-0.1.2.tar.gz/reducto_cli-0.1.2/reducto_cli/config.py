from __future__ import annotations

import os
from pathlib import Path

import typer


CONFIG_PATH = Path.home() / ".reducto" / "config.yaml"


def _read_saved_api_key() -> str | None:
    try:
        content = CONFIG_PATH.read_text(encoding="utf-8")
    except FileNotFoundError:
        return None
    except OSError:
        return None

    for line in content.splitlines():
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        if key.strip().lower() == "api_key":
            return value.strip().strip("\"'")
    return None


def _write_api_key(value: str) -> None:
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(f"api_key: {value.strip()}\n", encoding="utf-8")
    try:
        os.chmod(CONFIG_PATH, 0o600)
    except OSError:
        pass


def get_api_key() -> str:
    env_value = os.getenv("REDUCTO_API_KEY")
    if env_value:
        return env_value.strip()

    saved_value = _read_saved_api_key()
    if saved_value:
        os.environ["REDUCTO_API_KEY"] = saved_value
        return saved_value

    # Suggest running login command first
    typer.echo("\nNo API key found. You can authenticate by running:")
    typer.echo("  " + typer.style("reducto login", fg="cyan", bold=True))
    typer.echo("\nThis will open a browser to authenticate your CLI.")

    # Still allow manual entry as fallback
    if typer.confirm("\nOr enter an API key manually?"):
        entered_value = typer.prompt(
            "Enter your Reducto API key", hide_input=True
        ).strip()
        if not entered_value:
            typer.echo("An API key is required to continue.", err=True)
            raise typer.Exit(1)

        _write_api_key(entered_value)
        os.environ["REDUCTO_API_KEY"] = entered_value
        return entered_value
    else:
        typer.echo("\nPlease run 'reducto login' to authenticate.", err=True)
        raise typer.Exit(1)
