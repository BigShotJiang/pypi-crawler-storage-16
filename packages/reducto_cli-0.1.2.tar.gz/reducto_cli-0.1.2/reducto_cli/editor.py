from __future__ import annotations

import asyncio
from collections.abc import Iterable
from pathlib import Path

import httpx
import typer
from reducto import AsyncReducto, ReductoError

from .files import edit_output_path


async def edit_files(client: AsyncReducto, files: Iterable[Path], instructions: str) -> None:
    tasks = [asyncio.create_task(edit_file(client, file_path, instructions)) for file_path in files]
    for task in asyncio.as_completed(tasks):
        destination = await task
        if destination is not None:
            typer.echo(f"Saved {destination}")


async def edit_file(client: AsyncReducto, file_path: Path, instructions: str) -> Path | None:
    try:
        upload = await client.upload(file=file_path)
    except ReductoError as exc:
        typer.echo(f"Failed to upload {file_path}: {exc}", err=True)
        return None

    try:
        response = await client.edit.run(
            document_url=upload.file_id,
            edit_instructions=instructions,
            edit_options={"color": "#000000"},
        )
    except ReductoError as exc:
        typer.echo(f"Failed to edit {file_path}: {exc}", err=True)
        return None

    document_url = getattr(response, "document_url", None)
    if not document_url:
        typer.echo(f"No document URL in response for {file_path}", err=True)
        return None

    destination = edit_output_path(file_path)
    try:
        await _download_file(document_url, destination)
    except Exception as exc:
        typer.echo(f"Failed to download edited document for {file_path}: {exc}", err=True)
        return None

    return destination


async def _download_file(url: str, destination: Path) -> None:
    async with httpx.AsyncClient() as http_client:
        async with http_client.stream("GET", url) as response:
            response.raise_for_status()
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open("wb") as f:
                async for chunk in response.aiter_bytes():
                    f.write(chunk)
