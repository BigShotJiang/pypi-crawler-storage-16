from __future__ import annotations

from importlib import resources
from pathlib import Path


def load_help_text() -> str:
    try:
        package_path = resources.files("reducto_cli").joinpath("INSTRUCTIONS.md")
        content = package_path.read_text(encoding="utf-8").strip()
        if content:
            return content
    except (FileNotFoundError, OSError, AttributeError):
        pass

    fallback_path = Path(__file__).resolve().parent / "INSTRUCTIONS.md"
    try:
        content = fallback_path.read_text(encoding="utf-8").strip()
        if content:
            return content
    except OSError:
        pass

    return "Reducto CLI"
