# Changelog

## 0.15.0 (2025-12-12)

Full Changelog: [v0.14.0...v0.15.0](https://github.com/reductoai/reducto-python-sdk/compare/v0.14.0...v0.15.0)

### Features

* **api:** api update ([c99f850](https://github.com/reductoai/reducto-python-sdk/commit/c99f8501e2e4ae3c710fca3230f3df176267456a))
* **api:** api update ([85466bb](https://github.com/reductoai/reducto-python-sdk/commit/85466bb652b052bf54d4411a71325ba556a375b4))


### Bug Fixes

* **types:** allow pyright to infer TypedDict types within SequenceNotStr ([e10c534](https://github.com/reductoai/reducto-python-sdk/commit/e10c534ad4efb0d898f9c49e040fd6e933afb202))


### Chores

* add missing docstrings ([6854ebb](https://github.com/reductoai/reducto-python-sdk/commit/6854ebb6dbf5b4e6e4e93d19d0b9990ab77bcf14))

## 0.14.0 (2025-12-08)

Full Changelog: [v0.13.0...v0.14.0](https://github.com/reductoai/reducto-python-sdk/compare/v0.13.0...v0.14.0)

### Features

* **api:** api update ([78f4769](https://github.com/reductoai/reducto-python-sdk/commit/78f4769e963357e1c362d1c7425625cf000ba17c))
* **api:** api update ([4cd6b63](https://github.com/reductoai/reducto-python-sdk/commit/4cd6b635bc5803154048c91456315db483f3af81))
* **api:** api update ([f36e5e0](https://github.com/reductoai/reducto-python-sdk/commit/f36e5e053055de97f542ae9e2b022c9ca8c920cf))
* **api:** api update ([2c50e1a](https://github.com/reductoai/reducto-python-sdk/commit/2c50e1a80321a2e237963c83917aa616ae77bb76))
* **api:** api update ([49c771a](https://github.com/reductoai/reducto-python-sdk/commit/49c771adeb1a07904c9dca15cfc746de7bc7e334))
* **api:** api update ([dc475fb](https://github.com/reductoai/reducto-python-sdk/commit/dc475fb06aa96b0d454b55d526d709b89b5cb001))
* **api:** api update ([e96fa5b](https://github.com/reductoai/reducto-python-sdk/commit/e96fa5b7f70a09be6ba1ab7231b14a8030778ab9))
* **api:** api update ([682b327](https://github.com/reductoai/reducto-python-sdk/commit/682b3270923a4eb32d67dc7f4a5a7368fc4c9cb6))
* **api:** api update ([9d0d4f5](https://github.com/reductoai/reducto-python-sdk/commit/9d0d4f521eb7daead080896470993dc619569d99))
* **api:** api update ([0e936cb](https://github.com/reductoai/reducto-python-sdk/commit/0e936cba020a083448487ed2e8179e2eb81de04c))
* **api:** api update ([5671da0](https://github.com/reductoai/reducto-python-sdk/commit/5671da0642017147d0edc1ce7a7f448bb54a12ac))
* **api:** api update ([0749080](https://github.com/reductoai/reducto-python-sdk/commit/0749080e34753f12cefdf2f38457e643c7d9f967))
* **api:** api update ([8dc2fd5](https://github.com/reductoai/reducto-python-sdk/commit/8dc2fd52a6e1a1d4b68d3476290c5f56ba124add))
* **api:** api update ([5c701e6](https://github.com/reductoai/reducto-python-sdk/commit/5c701e65305e530c15f185ff9db35ec3752e98d3))
* **api:** api update ([ba42709](https://github.com/reductoai/reducto-python-sdk/commit/ba42709757cdc623b4476b92430a4d2c63d99612))
* **api:** api update ([3b30030](https://github.com/reductoai/reducto-python-sdk/commit/3b30030ca464c29975cd5eaf66fa7eee21c3fb0b))
* **api:** manual updates ([30596c1](https://github.com/reductoai/reducto-python-sdk/commit/30596c1249df44175545274c7cbebeb8b9738c3e))
* granular citations in the sdk ([#75](https://github.com/reductoai/reducto-python-sdk/issues/75)) ([789b8d8](https://github.com/reductoai/reducto-python-sdk/commit/789b8d8ba00769d5e21c3b503a3109694f10c2e2))


### Bug Fixes

* **client:** close streams without requiring full consumption ([7905627](https://github.com/reductoai/reducto-python-sdk/commit/79056274d02d4bd5ba1a3016338e9e7b69eee89e))
* compat with Python 3.14 ([b9bb4bc](https://github.com/reductoai/reducto-python-sdk/commit/b9bb4bcbd1e228c9a49978f000b29c77ad0aceb9))
* **compat:** update signatures of `model_dump` and `model_dump_json` for Pydantic v1 ([e4615bd](https://github.com/reductoai/reducto-python-sdk/commit/e4615bd11324cfc629a52bea325f50f4a2f33f4e))
* ensure streams are always closed ([f2ac426](https://github.com/reductoai/reducto-python-sdk/commit/f2ac4261d6f7114d62dcc9394fd831eae9586902))


### Chores

* add numpy to pyproject.toml ([26726ae](https://github.com/reductoai/reducto-python-sdk/commit/26726ae8a2e3ea2d8fe49bd1315b20da5d01c368))
* add Python 3.14 classifier and testing ([dc7b10a](https://github.com/reductoai/reducto-python-sdk/commit/dc7b10a343af4e821c5cf042df2b0ea082ea05c8))
* bump `httpx-aiohttp` version to 0.1.9 ([3d8b61d](https://github.com/reductoai/reducto-python-sdk/commit/3d8b61d04cc513559a1c865236ad422830b71282))
* **deps:** mypy 1.18.1 has a regression, pin to 1.17 ([ec108e1](https://github.com/reductoai/reducto-python-sdk/commit/ec108e18a31ea0b78afccdbc4401804962f9ea20))
* **docs:** use environment variables for authentication in code snippets ([7af7f19](https://github.com/reductoai/reducto-python-sdk/commit/7af7f197bf5e65dddc205723660f4875655abfcd))
* **internal/tests:** avoid race condition with implicit client cleanup ([610aac7](https://github.com/reductoai/reducto-python-sdk/commit/610aac7e96ecfe59cf7d513934d1952e68d6760e))
* **internal:** grammar fix (it's -&gt; its) ([5105442](https://github.com/reductoai/reducto-python-sdk/commit/510544279d431985d0a6abb2e12d751d1e7914ba))
* **package:** drop Python 3.8 support ([96a97e4](https://github.com/reductoai/reducto-python-sdk/commit/96a97e46e7d919112a4dad543ecd41aabfa850fb))
* update lockfile ([c192719](https://github.com/reductoai/reducto-python-sdk/commit/c192719f4998b74e577ab4414ac1cdec71fc5d5e))

## 0.13.0 (2025-10-14)

Full Changelog: [v0.12.0...v0.13.0](https://github.com/reductoai/reducto-python-sdk/compare/v0.12.0...v0.13.0)

### Features

* **api:** api update ([77ac327](https://github.com/reductoai/reducto-python-sdk/commit/77ac3270379f3843a2d70ba8ef1e9114085dc398))
* **api:** api update ([7b59e43](https://github.com/reductoai/reducto-python-sdk/commit/7b59e43987c50ee5384479c5b0eb4141f30c916b))
* **api:** api update ([9e8ede6](https://github.com/reductoai/reducto-python-sdk/commit/9e8ede61b6314efbaa80d610aa0a8bdbf06a1abe))
* **api:** manual updates ([a2d0097](https://github.com/reductoai/reducto-python-sdk/commit/a2d0097385caf1ac05052bc8003e136136eb71c1))


### Chores

* **internal:** detect missing future annotations with ruff ([ac56806](https://github.com/reductoai/reducto-python-sdk/commit/ac5680631abd7d90454ad11b4615c33c50ee15cc))

## 0.12.0 (2025-10-08)

Full Changelog: [v0.11.0...v0.12.0](https://github.com/reductoai/reducto-python-sdk/compare/v0.11.0...v0.12.0)

### Features

- **api:** api update ([2856096](https://github.com/reductoai/reducto-python-sdk/commit/28560963da16f3408425e341212501e32d67a81f))
- **api:** api update ([4fa2c91](https://github.com/reductoai/reducto-python-sdk/commit/4fa2c91c94a8c357e735cce8dbd072a4fcb54c55))
- **api:** change sdk to factor in /job/[id] and /jobs ([f3fd9a7](https://github.com/reductoai/reducto-python-sdk/commit/f3fd9a729e6ceda4bbb29f07ca5169c8806d42e1))

### Bug Fixes

- **compat:** compat with `pydantic&lt;2.8.0` when using additional fields ([084221e](https://github.com/reductoai/reducto-python-sdk/commit/084221ec45061a583622799722c8c12a7165560d))

### Chores

- do not install brew dependencies in ./scripts/bootstrap by default ([9be6843](https://github.com/reductoai/reducto-python-sdk/commit/9be68437f02f0e4adb4dd1382d0ce8d2f02f9206))
- **internal:** update pydantic dependency ([222a534](https://github.com/reductoai/reducto-python-sdk/commit/222a53475a8b1f13207145321d99c7b77c8f63a2))
- **types:** change optional parameter type from NotGiven to Omit ([3cedda8](https://github.com/reductoai/reducto-python-sdk/commit/3cedda8f1d906488f8573110deac92274756b39d))

## 0.11.0 (2025-09-16)

Full Changelog: [v0.10.1...v0.11.0](https://github.com/reductoai/reducto-python-sdk/compare/v0.10.1...v0.11.0)

### Features

- **api:** api update ([2b1fbeb](https://github.com/reductoai/reducto-python-sdk/commit/2b1fbeb9c02b2715a4fb9c86fbc38f9f5cc5995d))
- **api:** api update ([3d211d1](https://github.com/reductoai/reducto-python-sdk/commit/3d211d18bffab5d93c4f5d2d8b0de6faa1b7663a))
- **api:** api update ([137e563](https://github.com/reductoai/reducto-python-sdk/commit/137e5634b5d9d6b58232bb07df38d6f3e9fb2c64))
- **api:** api update ([69eab3e](https://github.com/reductoai/reducto-python-sdk/commit/69eab3ed4122a46174ac1cc99eb1a4524d320a1c))
- **api:** api update ([f181769](https://github.com/reductoai/reducto-python-sdk/commit/f1817691b85afbd37eda8d0dd62412954866c1ce))
- **api:** api update ([8864810](https://github.com/reductoai/reducto-python-sdk/commit/8864810c154cf0f343cf6707ef1db1c81d836e52))
- **api:** api update ([1427a05](https://github.com/reductoai/reducto-python-sdk/commit/1427a0505cd27f1358b0ece63b23ac8210d1672c))
- **api:** api update ([50fa804](https://github.com/reductoai/reducto-python-sdk/commit/50fa80448b3ed69d009af650d7f399dbe04dd9bf))
- **api:** api update ([be15201](https://github.com/reductoai/reducto-python-sdk/commit/be152018ea8a18e8c5702d46bcd97bfb1338f4cb))
- **api:** api update ([7a86d02](https://github.com/reductoai/reducto-python-sdk/commit/7a86d0246a61eae003759541e0a0faa58534cd74))
- **api:** api update ([4d33b3f](https://github.com/reductoai/reducto-python-sdk/commit/4d33b3f315ec19884d490fef57dbcdae9aaabea7))
- **api:** api update ([db7535d](https://github.com/reductoai/reducto-python-sdk/commit/db7535d982dd88f53384b7fea1151fba4e9431c2))
- **api:** api update ([42fc590](https://github.com/reductoai/reducto-python-sdk/commit/42fc590389ea54aa77f54fef7a1d212f26ca9fc3))
- **api:** api update ([7f54cac](https://github.com/reductoai/reducto-python-sdk/commit/7f54cac00cfc8610efe8740837f34ce3b6fed358))
- **api:** api update ([9c8c3ce](https://github.com/reductoai/reducto-python-sdk/commit/9c8c3ce5b0a0758aab08644119305b5c99c64805))
- **api:** api update ([d7bc25b](https://github.com/reductoai/reducto-python-sdk/commit/d7bc25b4c3d3b85671f2d643a2cecd9909e94b36))
- **api:** api update ([3e9a5c8](https://github.com/reductoai/reducto-python-sdk/commit/3e9a5c83a38641f207a0714264a55d7bff2e0c40))
- **api:** manual updates ([9b31994](https://github.com/reductoai/reducto-python-sdk/commit/9b31994b941b47ca1cd13ea861ab0d850bf58540))
- **api:** manual updates ([2f4e621](https://github.com/reductoai/reducto-python-sdk/commit/2f4e62153065ee3499c8b82d8dae407c665352d5))
- **api:** manual updates ([3794a83](https://github.com/reductoai/reducto-python-sdk/commit/3794a83f2898b49384332764d99feea57ab469c9))
- improve future compat with pydantic v3 ([0fd503a](https://github.com/reductoai/reducto-python-sdk/commit/0fd503af41fd9406e83f26e0dd052fe74571c7e5))
- **types:** replace List[str] with SequenceNotStr in params ([d19ddce](https://github.com/reductoai/reducto-python-sdk/commit/d19ddce2f90f04041f2e427ee05c38aa91a4853c))

### Bug Fixes

- avoid newer type syntax ([1a2080a](https://github.com/reductoai/reducto-python-sdk/commit/1a2080ae5dc4805225fdccbb3a52626c69b797cc))

### Chores

- **internal:** add Sequence related utils ([7d39034](https://github.com/reductoai/reducto-python-sdk/commit/7d390346723d53f7abbe336a7f2a69c85d31836b))
- **internal:** change ci workflow machines ([c9c08f4](https://github.com/reductoai/reducto-python-sdk/commit/c9c08f400cd47fdc24fd224e86ac8056cee5c7e9))
- **internal:** codegen related update ([583a974](https://github.com/reductoai/reducto-python-sdk/commit/583a9744a82ee968a845a4d10297dc62038a7ff7))
- **internal:** move mypy configurations to `pyproject.toml` file ([1e33d5c](https://github.com/reductoai/reducto-python-sdk/commit/1e33d5cfae15c923178520cdebc5d7bde68fb5a2))
- **internal:** update comment in script ([c4f1dea](https://github.com/reductoai/reducto-python-sdk/commit/c4f1deae57366235a5e5db9311433571a59e0350))
- **internal:** update pyright exclude list ([38e4e30](https://github.com/reductoai/reducto-python-sdk/commit/38e4e3031117c02836d54b5c17e0c6f73a0a915e))
- **tests:** simplify `get_platform` test ([5ef6803](https://github.com/reductoai/reducto-python-sdk/commit/5ef6803f71e52467ede98f2b770358e8b3e2a7af))
- update @stainless-api/prism-cli to v5.15.0 ([b8ce369](https://github.com/reductoai/reducto-python-sdk/commit/b8ce369f84bffab34ca474817c36c9961434d8f8))
- update github action ([68e4f3c](https://github.com/reductoai/reducto-python-sdk/commit/68e4f3c99fa08bc61508408d7e14691152ccd5a8))

## 0.10.1 (2025-08-06)

Full Changelog: [v0.10.0...v0.10.1](https://github.com/reductoai/reducto-python-sdk/compare/v0.10.0...v0.10.1)

### Features

- **api:** manual updates ([84d712f](https://github.com/reductoai/reducto-python-sdk/commit/84d712f7c41de48efafc43bbb8cd86bac77c600f))

### Chores

- **internal:** fix ruff target version ([8a8565c](https://github.com/reductoai/reducto-python-sdk/commit/8a8565c625035fcee31727b38d09131912fa5fb3))

## 0.10.0 (2025-08-05)

Full Changelog: [v0.9.0...v0.10.0](https://github.com/reductoai/reducto-python-sdk/compare/v0.9.0...v0.10.0)

### Features

- **api:** api update ([f4729e7](https://github.com/reductoai/reducto-python-sdk/commit/f4729e75b14a183d5d1b149462b57d60f3422664))
- **api:** api update ([1aecd8c](https://github.com/reductoai/reducto-python-sdk/commit/1aecd8c14e04ce303d89f9836c53535a846a0ac3))
- **api:** api update ([0b681c6](https://github.com/reductoai/reducto-python-sdk/commit/0b681c62d2af13122278997f6e69cb26d924b8f1))
- **api:** api update ([49b78e3](https://github.com/reductoai/reducto-python-sdk/commit/49b78e3676539613da763948501c0440d43464f0))
- **api:** api update ([5dca002](https://github.com/reductoai/reducto-python-sdk/commit/5dca00234d23889a2651d4ba548b45a244a8685f))
- **api:** manual updates ([0bc45db](https://github.com/reductoai/reducto-python-sdk/commit/0bc45dbaab3fe20f07bd939cfa54bb9025ebc24c))
- **client:** support file upload requests ([591d2a9](https://github.com/reductoai/reducto-python-sdk/commit/591d2a98324d60089ec452dcb1bad295aefdf103))

### Bug Fixes

- make file parameter optional in upload method for presigned URL support ([#66](https://github.com/reductoai/reducto-python-sdk/issues/66)) ([5f7060d](https://github.com/reductoai/reducto-python-sdk/commit/5f7060da2af427a1567be05789a5b776b0300dff))
- **parsing:** ignore empty metadata ([b572c21](https://github.com/reductoai/reducto-python-sdk/commit/b572c216b11ad81db6ef82ca7bb0da4725d11423))
- **parsing:** parse extra field types ([45461eb](https://github.com/reductoai/reducto-python-sdk/commit/45461eb0465b9933c828d8ad138952ca2222f539))

### Chores

- **project:** add settings file for vscode ([6bd9d30](https://github.com/reductoai/reducto-python-sdk/commit/6bd9d30367714341c832834ebcecb1471dd9fff1))

## 0.9.0 (2025-07-21)

Full Changelog: [v0.8.0...v0.9.0](https://github.com/reductoai/reducto-python-sdk/compare/v0.8.0...v0.9.0)

### Features

- **api:** add edit endpoint ([f67cbea](https://github.com/reductoai/reducto-python-sdk/commit/f67cbea23345d32bb52c5c67bee8cc5a194955ed))
- **api:** api update ([6e28e0a](https://github.com/reductoai/reducto-python-sdk/commit/6e28e0a812c7ac04fb43e21656f70fa23f6a190c))
- **api:** api update ([954b9b1](https://github.com/reductoai/reducto-python-sdk/commit/954b9b14a929c87388791706939f76355e0c7801))
- **api:** api update ([596e69e](https://github.com/reductoai/reducto-python-sdk/commit/596e69e246229b37c45f8b64abead8df2b5a068e))
- **api:** api update ([aff4c7f](https://github.com/reductoai/reducto-python-sdk/commit/aff4c7f2ccc033b3a3d7938a877218eac34dd5ab))
- clean up environment call outs ([946c953](https://github.com/reductoai/reducto-python-sdk/commit/946c95358285041c8d39c653b001dd08c05748b9))

### Bug Fixes

- **client:** don't send Content-Type header on GET requests ([a5c03a1](https://github.com/reductoai/reducto-python-sdk/commit/a5c03a1ad030080e028cba3bc3170af5e1b70d9b))
- **parsing:** correctly handle nested discriminated unions ([85fcdd1](https://github.com/reductoai/reducto-python-sdk/commit/85fcdd17a4f77c61397f0e9499bf5c75ea43246c))

### Chores

- **internal:** bump pinned h11 dep ([503a1b2](https://github.com/reductoai/reducto-python-sdk/commit/503a1b296449bf03cddac09b4e97823ede459004))
- **internal:** codegen related update ([818940e](https://github.com/reductoai/reducto-python-sdk/commit/818940ecfa3c9f7a38dc91b1439acccb48ed0ce2))
- **internal:** version bump ([f41e580](https://github.com/reductoai/reducto-python-sdk/commit/f41e5809ec89958f645316fbf74737b3c3221bdc))
- **package:** mark python 3.13 as supported ([4bd0a2f](https://github.com/reductoai/reducto-python-sdk/commit/4bd0a2f13f70b25aa3739e59cc11b4034a12f74d))
- **readme:** fix version rendering on pypi ([988277f](https://github.com/reductoai/reducto-python-sdk/commit/988277fda78944d4141677340874e73d58f0cc15))

## 0.8.0 (2025-07-04)

Full Changelog: [v0.7.0...v0.8.0](https://github.com/reductoai/reducto-python-sdk/compare/v0.7.0...v0.8.0)

### Features

- **api:** api update ([e88fd6c](https://github.com/reductoai/reducto-python-sdk/commit/e88fd6c4458cc467f960864bd5f3c740ffadfd4c))
- **api:** api update ([35d8b38](https://github.com/reductoai/reducto-python-sdk/commit/35d8b38925535216d21a9e8d369a25688a2cdfe4))
- **api:** api update ([d4053b0](https://github.com/reductoai/reducto-python-sdk/commit/d4053b06801657b95320244489a545509c3491ff))
- **api:** api update ([ce291e6](https://github.com/reductoai/reducto-python-sdk/commit/ce291e684276b5f1c983c33d0a6386e79ac1eab0))
- **client:** add support for aiohttp ([ea80a4c](https://github.com/reductoai/reducto-python-sdk/commit/ea80a4c4c3492f496701bca9f5ce375be4ea5d99))

### Bug Fixes

- **ci:** correct conditional ([d078380](https://github.com/reductoai/reducto-python-sdk/commit/d078380d37c120a78ddc469727ba25c18ddd4d5d))
- **ci:** release-doctor — report correct token name ([5e7895b](https://github.com/reductoai/reducto-python-sdk/commit/5e7895b5f7bb93d03559e8e09bffe039a817b998))

### Chores

- **ci:** change upload type ([6e4b30f](https://github.com/reductoai/reducto-python-sdk/commit/6e4b30fd85dcf769dd112cfde31ec370a78db6b6))
- **ci:** only run for pushes and fork pull requests ([571567c](https://github.com/reductoai/reducto-python-sdk/commit/571567c2bab3a0e8f243eb89674c681e61255fd5))
- **tests:** skip some failing tests on the latest python versions ([f938fd6](https://github.com/reductoai/reducto-python-sdk/commit/f938fd615b2790a9b78393e03c57608705ddfc31))

## 0.7.0 (2025-06-20)

Full Changelog: [v0.6.0...v0.7.0](https://github.com/reductoai/reducto-python-sdk/compare/v0.6.0...v0.7.0)

### Features

- **api:** api update ([4257bb6](https://github.com/reductoai/reducto-python-sdk/commit/4257bb6713210d7d8a96d6a63911c797ea492a08))
- **api:** api update ([23a3949](https://github.com/reductoai/reducto-python-sdk/commit/23a39497dd71e64a6c22e3df9dadfebe515f47bc))
- **api:** api update ([f276b5b](https://github.com/reductoai/reducto-python-sdk/commit/f276b5b6b799d0079d48df2764ac05021eb27f8f))
- **api:** api update ([b39bfbe](https://github.com/reductoai/reducto-python-sdk/commit/b39bfbe0fca02dab6006d019e4bf200ff2c7351c))
- **api:** api update ([8bd4e68](https://github.com/reductoai/reducto-python-sdk/commit/8bd4e68ade7e6f10c25db139c3c19aedb474ace2))
- **api:** api update ([6ad03c9](https://github.com/reductoai/reducto-python-sdk/commit/6ad03c95a0f9a4d331f99fb1f08a0a376e97b666))
- **api:** api update ([ee26a65](https://github.com/reductoai/reducto-python-sdk/commit/ee26a65b0d987cce86d94ecb7f9573aeebb23f87))
- **client:** add follow_redirects request option ([70eb648](https://github.com/reductoai/reducto-python-sdk/commit/70eb648ef218265d22a3f734c197c10241bc1a2a))

### Bug Fixes

- **client:** correctly parse binary response | stream ([41f71fc](https://github.com/reductoai/reducto-python-sdk/commit/41f71fca201a14738c6d0c5db784c72debe6bc7f))
- **docs/api:** remove references to nonexistent types ([08eb2d8](https://github.com/reductoai/reducto-python-sdk/commit/08eb2d879d5fb0861dd7d85e85d4892c61004165))
- **package:** support direct resource imports ([b5332fb](https://github.com/reductoai/reducto-python-sdk/commit/b5332fb31ace673a46c21e9cb2fdfa534db864fb))
- **tests:** fix: tests which call HTTP endpoints directly with the example parameters ([293fa24](https://github.com/reductoai/reducto-python-sdk/commit/293fa241595928273b1e16f80e3c2755c65edbfe))

### Chores

- **ci:** enable for pull requests ([646d80d](https://github.com/reductoai/reducto-python-sdk/commit/646d80d6724626613c8175ac6079678f61579672))
- **ci:** fix installation instructions ([c0bddc5](https://github.com/reductoai/reducto-python-sdk/commit/c0bddc5bb564585ff1b8e714edc973add7f56eca))
- **ci:** upload sdks to package manager ([e6ec13a](https://github.com/reductoai/reducto-python-sdk/commit/e6ec13a8db2d3915eb99ebaf2c67bb17060e42a9))
- **docs:** grammar improvements ([ee6ab9a](https://github.com/reductoai/reducto-python-sdk/commit/ee6ab9a44f79be945fd72edf509f65977b73b2bc))
- **docs:** remove reference to rye shell ([0e9b32d](https://github.com/reductoai/reducto-python-sdk/commit/0e9b32d24ccd62e0612a64f3f7ca6b7e07153026))
- **docs:** remove unnecessary param examples ([6f1562f](https://github.com/reductoai/reducto-python-sdk/commit/6f1562f7cfbe1e027fe7b803f2486f843645cd26))
- **internal:** avoid errors for isinstance checks on proxies ([97974a0](https://github.com/reductoai/reducto-python-sdk/commit/97974a09f801f0975b23457465d9a125c7e1426a))
- **internal:** update conftest.py ([71942fc](https://github.com/reductoai/reducto-python-sdk/commit/71942fc29a6ad2face05c8f4cc1a165b6eba7224))
- **readme:** update badges ([c66cb07](https://github.com/reductoai/reducto-python-sdk/commit/c66cb07fd878b23236cc736eee7f1cec0657208a))
- **tests:** add tests for httpx client instantiation & proxies ([fd4a62b](https://github.com/reductoai/reducto-python-sdk/commit/fd4a62b1602e73e1974289673403ee26549bfeb8))
- **tests:** run tests in parallel ([e7e0a6b](https://github.com/reductoai/reducto-python-sdk/commit/e7e0a6b3bc23c08a0e40b355e9d4564ab28dfaed))

### Documentation

- **client:** fix httpx.Timeout documentation reference ([81851b8](https://github.com/reductoai/reducto-python-sdk/commit/81851b84b39a187c0cbe131452a4521dcd1969e5))

## 0.6.0 (2025-05-06)

Full Changelog: [v0.5.0...v0.6.0](https://github.com/reductoai/reducto-python-sdk/compare/v0.5.0...v0.6.0)

### Features

- **api:** api update ([393a0bb](https://github.com/reductoai/reducto-python-sdk/commit/393a0bb685ce6644fe5c0998985b428976be20fa))
- **api:** api update ([97def07](https://github.com/reductoai/reducto-python-sdk/commit/97def072e6ed18644bafb8e4e835a8d502604538))
- **api:** api update ([ad2aa04](https://github.com/reductoai/reducto-python-sdk/commit/ad2aa042d1175c8c77e0ac758463b871d3b226bb))
- **api:** api update ([920a298](https://github.com/reductoai/reducto-python-sdk/commit/920a2986e655fce0ebd353c3098fc1d091db4918))
- **api:** api update ([f045a44](https://github.com/reductoai/reducto-python-sdk/commit/f045a4457364c6d9c69b1229249f2fa2b7af1f31))
- **api:** api update ([a4108e7](https://github.com/reductoai/reducto-python-sdk/commit/a4108e798bf7b23c42b43640b00704b4de03d63f))
- **api:** api update ([80e5d94](https://github.com/reductoai/reducto-python-sdk/commit/80e5d94caa24cdd549c4d787870cd07db399ab5a))
- **api:** api update ([db00c6e](https://github.com/reductoai/reducto-python-sdk/commit/db00c6ef10ad38452b1c9bb3b027e5e5d371d5ee))
- **api:** api update ([c9c0032](https://github.com/reductoai/reducto-python-sdk/commit/c9c003278e8cf57880ca8afe231eb83d4fe94133))
- **api:** api update ([c981e26](https://github.com/reductoai/reducto-python-sdk/commit/c981e2666c68f8e8daf6bbdb7b19720a6e327d0c))
- **api:** api update ([4bf09ad](https://github.com/reductoai/reducto-python-sdk/commit/4bf09adfbb65a3679c5b8ab8de624419ddfd89d7))
- **api:** api update ([3561bd2](https://github.com/reductoai/reducto-python-sdk/commit/3561bd221de039422238dd32732450711d2f7039))
- **api:** api update ([acbb386](https://github.com/reductoai/reducto-python-sdk/commit/acbb38680b19c4c807e6a81b02209885ba176c5c))
- **api:** api update ([b31b2e5](https://github.com/reductoai/reducto-python-sdk/commit/b31b2e54b0e1f34f723e6e758828faa5e7b40312))
- **api:** manual updates ([cf61d61](https://github.com/reductoai/reducto-python-sdk/commit/cf61d611adc6cb572a34c1efa456d61a6ada8699))
- **api:** manual updates ([eb32a54](https://github.com/reductoai/reducto-python-sdk/commit/eb32a54fff84f2d848af6cdf13a69770e6fab2e0))

### Bug Fixes

- **pydantic v1:** more robust ModelField.annotation check ([78bbb5b](https://github.com/reductoai/reducto-python-sdk/commit/78bbb5b752df4e470c1e6e6b4cd3e8dc9533acff))

### Chores

- broadly detect json family of content-type headers ([2c68629](https://github.com/reductoai/reducto-python-sdk/commit/2c68629b57adffa3dbee6ac2fda930243bddb374))
- **ci:** add timeout thresholds for CI jobs ([36d959d](https://github.com/reductoai/reducto-python-sdk/commit/36d959dde92f6ccffabe2609def239bb185892dd))
- **ci:** only use depot for staging repos ([4ff125a](https://github.com/reductoai/reducto-python-sdk/commit/4ff125abee4c7511146fe60ad66e698189eac659))
- **client:** minor internal fixes ([3d98dcc](https://github.com/reductoai/reducto-python-sdk/commit/3d98dccdf87f3c75fe0587365c9a418ba8d88fd6))
- **internal:** base client updates ([fe10b0a](https://github.com/reductoai/reducto-python-sdk/commit/fe10b0a7a05ea403c650c81c21e30229fba94f53))
- **internal:** bump pyright version ([8b4d450](https://github.com/reductoai/reducto-python-sdk/commit/8b4d450ac23c8601c0586ea2466c2c2caac74fe5))
- **internal:** codegen related update ([974a427](https://github.com/reductoai/reducto-python-sdk/commit/974a427c97583f4d07dd9c945a680a653e517ec0))
- **internal:** fix list file params ([0487d01](https://github.com/reductoai/reducto-python-sdk/commit/0487d01c1c91fc5c43daa5a04269f1188b483a28))
- **internal:** import reformatting ([07d0490](https://github.com/reductoai/reducto-python-sdk/commit/07d04909ed19ecfc19c0e3e46b878da0a0808396))
- **internal:** minor formatting changes ([c2b1fb2](https://github.com/reductoai/reducto-python-sdk/commit/c2b1fb26d95ccd000f0b5f80a68c9a51d3b2778c))
- **internal:** refactor retries to not use recursion ([7c61471](https://github.com/reductoai/reducto-python-sdk/commit/7c6147119922949298f7478c502afa9a4311348d))
- **internal:** update models test ([caa1b89](https://github.com/reductoai/reducto-python-sdk/commit/caa1b895953425775262b1d960b279e142afc067))
- **internal:** update pyright settings ([6e31b6f](https://github.com/reductoai/reducto-python-sdk/commit/6e31b6f4ef9734b3eb61a54351526efa53a54565))

## 0.5.0 (2025-04-12)

Full Changelog: [v0.4.0...v0.5.0](https://github.com/reductoai/reducto-python-sdk/compare/v0.4.0...v0.5.0)

### Features

- **api:** api update ([adae7c2](https://github.com/reductoai/reducto-python-sdk/commit/adae7c2424b8778f38dc3212028cc1c7cb7e9c8e))
- **api:** api update ([#41](https://github.com/reductoai/reducto-python-sdk/issues/41)) ([df33790](https://github.com/reductoai/reducto-python-sdk/commit/df33790ff9b1333bb139a40422c0c20a22bfd901))
- **api:** api update ([#43](https://github.com/reductoai/reducto-python-sdk/issues/43)) ([f0f90e6](https://github.com/reductoai/reducto-python-sdk/commit/f0f90e65e45f5548931cca774876711e2c5521a5))
- **api:** api update ([#44](https://github.com/reductoai/reducto-python-sdk/issues/44)) ([0a348fa](https://github.com/reductoai/reducto-python-sdk/commit/0a348fa355a8e325f41831569cc15ecd10c66ed5))
- **api:** api update ([#45](https://github.com/reductoai/reducto-python-sdk/issues/45)) ([0850b23](https://github.com/reductoai/reducto-python-sdk/commit/0850b232d26b551fbd700e76f1e481a4c5309fe3))
- **api:** api update ([#46](https://github.com/reductoai/reducto-python-sdk/issues/46)) ([60602de](https://github.com/reductoai/reducto-python-sdk/commit/60602de79f3d3082a3c0dac99b67439682b8c7c6))
- **api:** api update ([#48](https://github.com/reductoai/reducto-python-sdk/issues/48)) ([baa9c6f](https://github.com/reductoai/reducto-python-sdk/commit/baa9c6faccaf2caff6afadf6b80f8104d92870ae))
- **api:** api update ([#49](https://github.com/reductoai/reducto-python-sdk/issues/49)) ([77d2761](https://github.com/reductoai/reducto-python-sdk/commit/77d27619acb08196e5b82acfc55641349f69f5e5))
- **api:** api update ([#53](https://github.com/reductoai/reducto-python-sdk/issues/53)) ([5a16d95](https://github.com/reductoai/reducto-python-sdk/commit/5a16d95fb5e7297c5032cae242e1ea52586ad2af))
- **api:** api update ([#54](https://github.com/reductoai/reducto-python-sdk/issues/54)) ([269ea31](https://github.com/reductoai/reducto-python-sdk/commit/269ea314ddba6b6a77cb058f8b27fc46b95d039c))
- **api:** api update ([#55](https://github.com/reductoai/reducto-python-sdk/issues/55)) ([16ac56b](https://github.com/reductoai/reducto-python-sdk/commit/16ac56b7f38ecf6fcb50a0e2f39f04f11fac92ef))
- **api:** api update ([#58](https://github.com/reductoai/reducto-python-sdk/issues/58)) ([162b618](https://github.com/reductoai/reducto-python-sdk/commit/162b618b7c321bb6aacdc2a13e220bbf983085ca))
- **api:** manual updates ([#52](https://github.com/reductoai/reducto-python-sdk/issues/52)) ([72cd53f](https://github.com/reductoai/reducto-python-sdk/commit/72cd53fc742869e54e7446ff8e8a9bf14d614690))

### Bug Fixes

- **perf:** optimize some hot paths ([a93ff5a](https://github.com/reductoai/reducto-python-sdk/commit/a93ff5a30d53081d2671cdeca6bc1432b173ccd9))
- **perf:** skip traversing types for NotGiven values ([9f69d12](https://github.com/reductoai/reducto-python-sdk/commit/9f69d1210b236d3c060d486b11d8cee3539554dd))

### Chores

- fix typos ([#47](https://github.com/reductoai/reducto-python-sdk/issues/47)) ([65c7bd8](https://github.com/reductoai/reducto-python-sdk/commit/65c7bd8940c9ed42ab136e6028021aeb542e4eb7))
- **internal:** expand CI branch coverage ([d2a9180](https://github.com/reductoai/reducto-python-sdk/commit/d2a918085c73a6d8ad7f84fa5c63233419630332))
- **internal:** reduce CI branch coverage ([1b82a03](https://github.com/reductoai/reducto-python-sdk/commit/1b82a0311f3337156ba0e0f4d1c4d184d70c2b88))
- **internal:** remove trailing character ([#50](https://github.com/reductoai/reducto-python-sdk/issues/50)) ([be91d1e](https://github.com/reductoai/reducto-python-sdk/commit/be91d1e959a453ef5f3b576024c5871ebad82973))
- **internal:** slight transform perf improvement ([#56](https://github.com/reductoai/reducto-python-sdk/issues/56)) ([234f8ff](https://github.com/reductoai/reducto-python-sdk/commit/234f8ff2eebc1ee2af3d95faa794173cea607c47))
- slight wording improvement in README ([#57](https://github.com/reductoai/reducto-python-sdk/issues/57)) ([fae1793](https://github.com/reductoai/reducto-python-sdk/commit/fae17937a1d02a4a06d21a8403219cbf4e2952d4))

### Documentation

- swap examples used in readme ([#51](https://github.com/reductoai/reducto-python-sdk/issues/51)) ([63c59d7](https://github.com/reductoai/reducto-python-sdk/commit/63c59d75106af0595a21ddfef6020d06bdbe5955))

## 0.4.0 (2025-03-22)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/reductoai/reducto-python-sdk/compare/v0.3.0...v0.4.0)

### Features

- **api:** api update ([#39](https://github.com/reductoai/reducto-python-sdk/issues/39)) ([ac2917d](https://github.com/reductoai/reducto-python-sdk/commit/ac2917dcb930ff607b6a0e2a8c8d240c733be453))
- Improve URL response handling ([906737e](https://github.com/reductoai/reducto-python-sdk/commit/906737e752ac9137e5132453a71457b8956d5d78))
- trigger mintlify update on release ([#23](https://github.com/reductoai/reducto-python-sdk/issues/23)) ([ba8bfbd](https://github.com/reductoai/reducto-python-sdk/commit/ba8bfbd31d871c6d0a3f77dfbc9123b60b6dadf5))

## 0.3.0 (2025-03-21)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/reductoai/reducto-python-sdk/compare/v0.2.0...v0.3.0)

### Features

- **api:** api update ([#31](https://github.com/reductoai/reducto-python-sdk/issues/31)) ([91ee117](https://github.com/reductoai/reducto-python-sdk/commit/91ee117c0314ec71ed649d82e434b0244a54b0de))
- **api:** api update ([#32](https://github.com/reductoai/reducto-python-sdk/issues/32)) ([ed0f6dc](https://github.com/reductoai/reducto-python-sdk/commit/ed0f6dc391d0f465db4122f9f901fbb6bed2e7ef))
- **api:** api update ([#34](https://github.com/reductoai/reducto-python-sdk/issues/34)) ([86d0cee](https://github.com/reductoai/reducto-python-sdk/commit/86d0cee0fa5bd6083508b2a08c587cd2e71e571b))
- feat: Add FullParseResponse model and handle_url_response function ([#35](https://github.com/reductoai/reducto-python-sdk/issues/35)) ([1c74524](https://github.com/reductoai/reducto-python-sdk/commit/1c74524671155a9ac5f67e71a89cf1e5ec5c965b))

### Bug Fixes

- **ci:** remove publishing patch ([#28](https://github.com/reductoai/reducto-python-sdk/issues/28)) ([2c0d190](https://github.com/reductoai/reducto-python-sdk/commit/2c0d190dc312d642569a2c37ca7ad8a7d155197e))

### Chores

- remove custom code ([8ffb7d5](https://github.com/reductoai/reducto-python-sdk/commit/8ffb7d5e018c97431736cac3cef2ac1e93c10d79))
- remove custom code ([c3b7169](https://github.com/reductoai/reducto-python-sdk/commit/c3b7169fe26a419501fad83304954fc7707ecd9a))

## 0.2.0 (2025-03-17)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/reductoai/reducto-python-sdk/compare/v0.1.0...v0.2.0)

### Features

- **api:** api update ([#21](https://github.com/reductoai/reducto-python-sdk/issues/21)) ([1b3fbf3](https://github.com/reductoai/reducto-python-sdk/commit/1b3fbf334a8eee76392490894fee8a6e6e6bd0ec))

### Bug Fixes

- **ci:** ensure pip is always available ([#27](https://github.com/reductoai/reducto-python-sdk/issues/27)) ([b2a96d3](https://github.com/reductoai/reducto-python-sdk/commit/b2a96d370497f91e4a9d4a0084d549b7c4966c81))
- **types:** handle more discriminated union shapes ([#26](https://github.com/reductoai/reducto-python-sdk/issues/26)) ([0d77b6f](https://github.com/reductoai/reducto-python-sdk/commit/0d77b6fd402eb2d2b2c8b17a964e2e60c16d1a36))

### Chores

- **internal:** bump rye to 0.44.0 ([#25](https://github.com/reductoai/reducto-python-sdk/issues/25)) ([a96cad7](https://github.com/reductoai/reducto-python-sdk/commit/a96cad796adb321bc7c4afc5772469fa4d0299f5))
- **internal:** codegen related update ([#24](https://github.com/reductoai/reducto-python-sdk/issues/24)) ([c9f88f0](https://github.com/reductoai/reducto-python-sdk/commit/c9f88f052dd7625e6451f20871472ca0d03b744c))
- **internal:** remove extra empty newlines ([#22](https://github.com/reductoai/reducto-python-sdk/issues/22)) ([1745284](https://github.com/reductoai/reducto-python-sdk/commit/1745284a18ec944b4b697b4d35a69de741eeb920))

### Documentation

- revise readme docs about nested params ([#18](https://github.com/reductoai/reducto-python-sdk/issues/18)) ([90919f6](https://github.com/reductoai/reducto-python-sdk/commit/90919f65fc300e912b3bdceadc5c9fd488583438))

## 0.1.0 (2025-03-10)

Full Changelog: [v0.1.0-alpha.2...v0.1.0](https://github.com/reductoai/reducto-python-sdk/compare/v0.1.0-alpha.2...v0.1.0)

### Features

- **api:** api update ([#10](https://github.com/reductoai/reducto-python-sdk/issues/10)) ([28ab6ce](https://github.com/reductoai/reducto-python-sdk/commit/28ab6cec5a1483f7bf4dbd56114f4e94d53c2224))
- **api:** api update ([#16](https://github.com/reductoai/reducto-python-sdk/issues/16)) ([902285c](https://github.com/reductoai/reducto-python-sdk/commit/902285ca3f6db52efe163020aef1c352ac32f52f))

### Chores

- **docs:** update client docstring ([#13](https://github.com/reductoai/reducto-python-sdk/issues/13)) ([d649e20](https://github.com/reductoai/reducto-python-sdk/commit/d649e204040395334f3fc0add66d7eaa2f28bc15))
- **internal:** remove unused http client options forwarding ([#14](https://github.com/reductoai/reducto-python-sdk/issues/14)) ([53cb68e](https://github.com/reductoai/reducto-python-sdk/commit/53cb68ecccda85d788bc27d6bee186c2b7fca75a))

### Documentation

- update URLs from stainlessapi.com to stainless.com ([#12](https://github.com/reductoai/reducto-python-sdk/issues/12)) ([ef54876](https://github.com/reductoai/reducto-python-sdk/commit/ef5487656b269f670bc5f119ebe87461dadf73f6))

## 0.1.0-alpha.2 (2025-02-27)

Full Changelog: [v0.1.0-alpha.1...v0.1.0-alpha.2](https://github.com/reductoai/reducto-python-sdk/compare/v0.1.0-alpha.1...v0.1.0-alpha.2)

### Features

- **api:** manual updates ([#7](https://github.com/reductoai/reducto-python-sdk/issues/7)) ([f0a3ac7](https://github.com/reductoai/reducto-python-sdk/commit/f0a3ac7feffd5ce250ca33795bf95fa4fb6a3481))
- **api:** update via SDK Studio ([#5](https://github.com/reductoai/reducto-python-sdk/issues/5)) ([5effb16](https://github.com/reductoai/reducto-python-sdk/commit/5effb162cbd6a44036fa87a612a0b66cb5314eab))

### Chores

- **internal:** properly set **pydantic_private** ([#8](https://github.com/reductoai/reducto-python-sdk/issues/8)) ([38b3b62](https://github.com/reductoai/reducto-python-sdk/commit/38b3b62107a57a71f8299d164bc88199308198ed))

## 0.1.0-alpha.1 (2025-02-25)

Full Changelog: [v0.0.1-alpha.0...v0.1.0-alpha.1](https://github.com/reductoai/reducto-python-sdk/compare/v0.0.1-alpha.0...v0.1.0-alpha.1)

### Features

- **api:** update via SDK Studio ([db353a1](https://github.com/reductoai/reducto-python-sdk/commit/db353a1695d45a898a02b1ed30e60085dfa921f3))
- **api:** update via SDK Studio ([e891982](https://github.com/reductoai/reducto-python-sdk/commit/e891982d817ac48212fe76448809efdd23cf01c6))
- **api:** update via SDK Studio ([6429973](https://github.com/reductoai/reducto-python-sdk/commit/64299735c580254243b76094945ffa303817e66a))
- **api:** update via SDK Studio ([743f99b](https://github.com/reductoai/reducto-python-sdk/commit/743f99be8e673c3bb88ade34786eb648b1085b6a))
- **api:** update via SDK Studio ([40466be](https://github.com/reductoai/reducto-python-sdk/commit/40466be82533260118d825c022f7a02eb17c195b))
- **api:** update via SDK Studio ([ed0e969](https://github.com/reductoai/reducto-python-sdk/commit/ed0e969f59b734b3110c60c89a4a88cad816b735))
- **api:** update via SDK Studio ([a007184](https://github.com/reductoai/reducto-python-sdk/commit/a00718484793be2cf8be39970f4e0657ee512223))
- **api:** update via SDK Studio ([c444656](https://github.com/reductoai/reducto-python-sdk/commit/c444656862f8ba5e5a7fd9a5433b569e0903c095))

### Chores

- go live ([#1](https://github.com/reductoai/reducto-python-sdk/issues/1)) ([93f16d9](https://github.com/reductoai/reducto-python-sdk/commit/93f16d9397992fb0550baa288cec89d8d46b592d))
- update SDK settings ([#3](https://github.com/reductoai/reducto-python-sdk/issues/3)) ([9cc2125](https://github.com/reductoai/reducto-python-sdk/commit/9cc21254fdf5430aca69bcd987cc1653a0cee527))
