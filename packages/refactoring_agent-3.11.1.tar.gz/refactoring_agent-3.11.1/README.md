# Refactoring Agent 🛡️

[![PyPI version](https://img.shields.io/pypi/v/refactoring-agent.svg)](https://pypi.org/project/refactoring-agent/)
[![Security](https://img.shields.io/badge/Security-Active-red)]()
[![Build Status](https://img.shields.io/github/actions/workflow/status/StasLee1982/refactoring-agent/ci.yml?branch=main)](https://github.com/StasLee1982/refactoring-agent/actions)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**Autonomous Technical Debt & Security Remediation Agent.**

Refactoring Agent goes beyond simple linting. It is an infrastructure layer for **Continuous Modernization** that:
1.  **Scans** legacy code for technical debt and **Critical Security Vulnerabilities**.
2.  **Fixes** issues automatically using a deterministic Rule Engine and LLMs (OpenAI/Ollama).
3.  **Protects** your codebase with strict CI/CD gates.

> *"Snyk finds the vulnerability. Refactoring Agent fixes it."*

---

## 🚀 Key Features

### 🛡️ Security Scanning (New in v3.11)
Proactively hunts for critical vulnerabilities that static linters often miss:
- 🚫 **Arbitrary Code Execution:** Detects and blocks `eval()` and `exec()`.
- 🚫 **Shell Injection:** Flags dangerous `os.system()` calls.
- 🚫 **Safe I/O:** Enforces modern `input()` over insecure legacy alternatives.

**Example Output:**
```text
[ERROR] src/payment_gateway.py:12 Security Risk: usage of eval() detected. This allows arbitrary code execution.
[ERROR] src/utils.py:45 Security Risk: usage of os.system() detected. Vulnerable to shell injection.
