import sys
from unittest.mock import patch
from refactoring_agent.cli import main

def test_cli_invokes_ai_when_flag_is_set(tmp_path):
    """
    Проверяем, что при наличии флага --ai-fix и ошибок CLI пытается вызвать функцию get_ai_fix.
    """
    (tmp_path / "bad.py").write_text("x = raw_input()\n", encoding="utf-8")
    test_args = ["refactor-agent", "check", str(tmp_path), "--ai-fix"]

    # Мокаем успешный ответ
    with patch("refactoring_agent.cli.get_ai_fix") as mock_ai:
        mock_ai.return_value = "# Fixed by AI"
        with patch.object(sys, 'argv', test_args):
            try:
                main()
            except SystemExit:
                pass 
        assert mock_ai.call_count == 1

def test_cli_ai_invalid_api_key_message(tmp_path, capsys):
    """
    Проверяем, что при проблеме с API-ключом (401) в CLI появляется вменяемое сообщение.
    """
    (tmp_path / "bad.py").write_text("x = raw_input()\n", encoding="utf-8")
    test_args = ["refactor-agent", "check", str(tmp_path), "--ai-fix"]

    # Патчим get_ai_fix так, будто внутри произошла ошибка (возвращает None и принтит ошибку)
    # Мы симулируем поведение ai_handler.py
    def fake_get_ai_fix_error(snippet, issues=None):
        print("❌ AI error: invalid OpenAI API key (401 Unauthorized).")
        return None

    with patch("refactoring_agent.cli.get_ai_fix", side_effect=fake_get_ai_fix_error):
        with patch.object(sys, "argv", test_args):
            try:
                main()
            except SystemExit:
                pass

    out, _ = capsys.readouterr()
    # Проверяем, что в выводе есть ключевые слова
    assert "invalid OpenAI API key" in out
    assert "401 Unauthorized" in out
