import pytest
from refactoring_agent.config import parse_rule_mode, _normalize_rule, migrate_legacy_config

# 1. Проверка хелперов
def test_parse_rule_mode_valid():
    assert parse_rule_mode("off") == "off"
    assert parse_rule_mode("WARN") == "warn"
    assert parse_rule_mode(" typo ") == "error" # Fail safe

def test_normalize_rule_defaults():
    # Если данных нет, должны вернуться дефолты из константы
    # Для print дефолт: warn, minor
    cfg = _normalize_rule("print", {})
    assert cfg["mode"] == "warn"
    assert cfg["severity"] == "minor"

def test_normalize_rule_deep_merge():
    # ГЛАВНЫЙ ТЕСТ: Пользователь меняет mode, severity остается дефолтным
    user_input = {"mode": "error"}
    # Для print дефолт severity="minor"
    cfg = _normalize_rule("print", user_input)
    
    assert cfg["mode"] == "error"   # Изменилось
    assert cfg["severity"] == "minor" # Сохранилось из дефолтов!

# 2. Проверка Legacy миграции
def test_migrate_legacy_config():
    """
    Проверяем миграцию старых флагов no_*.
    """
    old_config = {
        "rules": {
            "no_print": True,       # Legacy: active (должен взять дефолт = warn)
            "no_raw_input": False   # Legacy: disabled
        }
    }
    
    processed_config = migrate_legacy_config(old_config)
    new_rules = processed_config["rules"]
    
    # no_print=True -> print: {mode: warn (default), severity: minor (default)}
    assert "print" in new_rules
    assert new_rules["print"]["mode"] == "warn"  # ИСПРАВЛЕНО: ждем warn, а не error
    
    # no_raw_input=False -> raw_input: {mode: off}
    assert "raw_input" in new_rules
    assert new_rules["raw_input"]["mode"] == "off"

# 3. Проверка нового формата
def test_new_format_config_structure():
    modern_input = {
        "rules": {
            "print": {"mode": "warn", "severity": "minor"}, 
            "raw_input": {"mode": "error"} # severity должен подтянуться
        }
    }
    
    # migrate_legacy_config умеет обрабатывать и новые конфиги (просто прокидывает их через normalize)
    processed = migrate_legacy_config(modern_input)["rules"]
    
    assert processed["print"]["mode"] == "warn"
    
    assert processed["raw_input"]["mode"] == "error"
    assert processed["raw_input"]["severity"] == "critical" # Дефолт для raw_input
