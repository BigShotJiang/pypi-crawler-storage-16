import os
import sys
from typing import Optional
from .config import load_llm_config, LLMConfig

try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False


def to_safe_utf8(text: str) -> str:
    """
    Принудительно делает строку безопасной для UTF-8.
    Заменяет суррогаты и битые символы.
    """
    if not isinstance(text, str):
        text = str(text)
    # encode -> decode с заменой ошибок
    return text.encode("utf-8", errors="replace").decode("utf-8")


class LLMClient:
    def __init__(self, config: Optional[LLMConfig] = None):
        self.config = config or load_llm_config()
        
        if self.config.provider == "mock":
            return

        if not OPENAI_AVAILABLE:
            raise ImportError("Package 'openai' is required. Install it via pip.")
            
        client_kwargs = {}
        if self.config.base_url:
            client_kwargs["base_url"] = self.config.base_url
            
        client_kwargs["api_key"] = self.config.api_key or "dummy-key"
        self._client = OpenAI(**client_kwargs)

    def chat(self, system_prompt: str, user_prompt: str) -> Optional[str]:
        # 1. Санитизация входа (чтобы не сломать запрос)
        safe_system = to_safe_utf8(system_prompt)
        safe_user = to_safe_utf8(user_prompt)

        # --- MOCK LOGIC ---
        if self.config.provider == "mock":
            return self._mock_fix(safe_user)
        # ------------------

        # 2. Вызов LLM
        try:
            response = self._client.chat.completions.create(
                model=self.config.model,
                messages=[
                    {"role": "system", "content": safe_system},
                    {"role": "user", "content": safe_user}
                ],
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
            )
            content = response.choices[0].message.content
            # 3. Санитизация выхода (чтобы не сломать консоль)
            return to_safe_utf8(content) if content else None
            
        except Exception:
            raise

    def _mock_fix(self, prompt: str) -> str:
        return (
            "# [MOCK AI FIX]\n"
            "# This code was 'fixed' by the Mock provider for demonstration.\n"
            "user_val = input('Enter value: ')\n"
            "print(f'You entered: {user_val}')"
        )


def get_ai_fix(code_snippet: str, issues: list = None, config: Optional[LLMConfig] = None) -> Optional[str]:
    """
    Основная функция для вызова AI.
    """
    if config is None:
        config = load_llm_config()
    
    if config.provider == "openai":
        if not OPENAI_AVAILABLE:
            return None
        if not config.api_key:
            return None

    try:
        client = LLMClient(config)
        
        system_prompt = "You are a Python refactoring expert. Return ONLY the fixed code."
        user_prompt = f"Fix this code:\n\n{code_snippet}"
        
        if issues:
            issues_text = "\n".join([str(i) for i in issues])
            user_prompt += f"\nIssues detected:\n{issues_text}"

        return client.chat(system_prompt, user_prompt)

    except Exception:
        raise
