import argparse
import sys
import os
import io
import difflib
from pathlib import Path
from tqdm import tqdm

from refactoring_agent.utils import collect_python_files, analyze_file_content
from refactoring_agent.config import load_config, LLMConfig

# --- NUCLEAR FIX FOR ENCODING (STDOUT/STDERR) ---
# Принудительно переключаем вывод в UTF-8 с заменой ошибок
if sys.stdout.encoding.lower() != 'utf-8':
    try:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    except AttributeError:
        pass
if sys.stderr.encoding.lower() != 'utf-8':
    try:
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    except AttributeError:
        pass
# --------------------------------

try:
    from refactoring_agent.report_html import generate_html_report
except ImportError:
    generate_html_report = None

try:
    from refactoring_agent.ai_handler import get_ai_fix
except ImportError:
    get_ai_fix = None


def safe_str(obj) -> str:
    """Гарантирует безопасный вывод в консоль (убирает суррогаты)."""
    try:
        return str(obj).encode('utf-8', 'replace').decode('utf-8')
    except Exception:
        return "<Unprintable Error>"


def print_diff(original: str, fixed: str, filename: str):
    diff = difflib.unified_diff(
        original.splitlines(),
        fixed.splitlines(),
        fromfile=f"a/{filename}",
        tofile=f"b/{filename}",
        lineterm=""
    )
    
    print(f"\n[DIFF] Proposed changes for {filename}:")
    for line in diff:
        safe_line = safe_str(line)
        if safe_line.startswith('+') and not safe_line.startswith('+++'):
            print(f"\033[92m{safe_line}\033[0m")
        elif safe_line.startswith('-') and not safe_line.startswith('---'):
            print(f"\033[91m{safe_line}\033[0m")
        elif safe_line.startswith('^'):
            print(f"\033[94m{safe_line}\033[0m")
        else:
            print(safe_line)
    print("-" * 40)


def main():
    parser = argparse.ArgumentParser(description="Refactoring Agent")
    parser.add_argument("command", choices=["check"])
    parser.add_argument("path")
    parser.add_argument("--exclude", action="append")
    parser.add_argument("--no-default-excludes", action="store_true")
    parser.add_argument("--html-report")
    parser.add_argument("--ai-fix", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    
    parser.add_argument("--provider", choices=["openai", "ollama", "mock"], help="LLM provider")
    parser.add_argument("--model", help="LLM model name")
    parser.add_argument("--base-url", help="Custom LLM API URL")
    parser.add_argument("--api-key", help="LLM API Key")

    args = parser.parse_args()
    
    config = load_config("pyproject.toml")
    llm_config = LLMConfig.from_args(args)
    rules_cfg = config.get("rules", {})

    base_excludes = [] if args.no_default_excludes else config.get("exclude", [])
    custom_excludes = args.exclude if args.exclude else []
    final_excludes = list(set(base_excludes + custom_excludes))

    target_path = args.path
    python_files = collect_python_files(target_path, exclude_dirs=final_excludes)
    
    print(f"Found {len(python_files)} python files. Starting analysis...")

    all_issues = {}
    found_critical_error = False 

    for file_path in tqdm(python_files, desc="Processing", unit="file"):
        try:
            # --- SAFE FILE READING ---
            # errors='replace' спасет, если в файле есть бинарный мусор
            with open(file_path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
            # -------------------------
            
            raw_issues = analyze_file_content(content)
            active_issues = []
            
            for issue in raw_issues:
                r_id = issue["rule_id"]
                rule_settings = rules_cfg.get(r_id, {"mode": "error", "severity": "major"})
                mode = rule_settings.get("mode", "error")
                
                if mode == "off": continue
                
                issue["mode"] = mode
                issue["severity"] = rule_settings.get("severity", "major")
                active_issues.append(issue)
                
                if mode == "error": found_critical_error = True

            if active_issues:
                all_issues[file_path] = active_issues

        except Exception as e:
            print(f"[ERROR] Failed to read {file_path}: {safe_str(e)}")

    print("\n--- SUMMARY REPORT ---")
    if not all_issues:
        print("[OK] Clean! No issues found.")
        sys.exit(0)

    for fpath, issues in all_issues.items():
        for issue in issues:
            mode = issue.get("mode", "error")
            prefix = "[ERROR]" if mode == "error" else "[WARNING]"
            print(f"{prefix} {fpath}:{issue.get('line','?')} {issue.get('message','')}")

    if args.html_report and generate_html_report:
        simple = {}
        for fp, iss in all_issues.items():
            simple[fp] = [f"[{i['mode']}] {i['message']}" for i in iss]
        generate_html_report(simple, args.html_report)
        print(f"\n[REPORT] Saved: {args.html_report}")

    if args.ai_fix and get_ai_fix:
        print(f"\n[AI] AI Suggestion feature is active (Provider: {llm_config.provider})...")
        
        if found_critical_error:
            for fpath, issues in all_issues.items():
                if any(i.get("mode") == "error" for i in issues):
                    print(f"   Analyzing {fpath} with AI...")
                    try:
                        # Читаем файл снова безопасно перед отправкой в AI
                        with open(fpath, "r", encoding="utf-8", errors="replace") as f:
                            original_code = f.read()
                        
                        suggestion = get_ai_fix(original_code, issues, config=llm_config)
                        
                        if suggestion:
                            if args.dry_run:
                                print_diff(original_code, suggestion, fpath)
                                print("   [DRY RUN] Changes NOT applied.")
                            else:
                                print(f"   [SUGGESTION]:\n{safe_str(suggestion)}\n")
                                print("   (Use --dry-run for diff)")
                            break # Чиним один файл за раз
                        else:
                            print("   [AI] No suggestion. Moving to next...")
                            
                    except Exception as e:
                        print(f"   [AI ERROR] Skipping {fpath}: {safe_str(e)}")

    sys.exit(1 if found_critical_error else 0)
