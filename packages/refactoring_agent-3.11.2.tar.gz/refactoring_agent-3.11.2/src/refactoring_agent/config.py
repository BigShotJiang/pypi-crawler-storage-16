import os
import argparse
from dataclasses import dataclass
from typing import Optional, Dict, Any

try:
    import tomllib
except ImportError:
    import tomli as tomllib

# --- 1. LLM Configuration ---

@dataclass
class LLMConfig:
    provider: str
    base_url: Optional[str]
    model: str
    api_key: Optional[str]
    temperature: float = 0.0
    max_tokens: Optional[int] = None

    @classmethod
    def from_args(cls, args: argparse.Namespace) -> "LLMConfig":
        provider = args.provider or os.getenv("RA_LLM_PROVIDER", "openai")
        default_model = "llama3" if provider == "ollama" else "gpt-4o-mini"
        model = args.model or os.getenv("RA_LLM_MODEL", default_model)

        base_url = args.base_url or os.getenv("RA_LLM_BASE_URL")
        if not base_url:
            if provider == "openai":
                base_url = "https://api.openai.com/v1"
            elif provider == "ollama":
                base_url = "http://localhost:11434/v1"
            else:
                base_url = None

        cli_key = getattr(args, "api_key", None)
        api_key = cli_key or os.getenv("RA_LLM_API_KEY") or os.getenv("OPENAI_API_KEY")
        if not api_key and provider in ("ollama", "mock"):
            api_key = "dummy-key"

        temp = float(os.getenv("RA_LLM_TEMPERATURE", "0.0"))
        max_tok = os.getenv("RA_LLM_MAX_TOKENS")
        max_tokens = int(max_tok) if max_tok else None

        return cls(
            provider=provider,
            base_url=base_url,
            model=model,
            api_key=api_key,
            temperature=temp,
            max_tokens=max_tokens,
        )

def load_llm_config() -> LLMConfig:
    dummy_args = argparse.Namespace(
        provider=None, model=None, base_url=None, api_key=None
    )
    return LLMConfig.from_args(dummy_args)

# --- 2. Rule Engine Configuration ---

DEFAULT_RULES = {
    # Legacy Rules
    "print": {"mode": "warn", "severity": "minor"},
    "raw_input": {"mode": "error", "severity": "critical"},
    
    # --- SECURITY PACK (NEW) ---
    "security_eval": {"mode": "error", "severity": "critical"},
    "security_exec": {"mode": "error", "severity": "critical"},
    "security_os_system": {"mode": "error", "severity": "major"},
}

LEGACY_RULE_MAP = {
    "no_print": "print",
    "no_raw_input": "raw_input",
}

DEFAULT_CONFIG = {
    "exclude": ["venv", ".git", "__pycache__", "build", "dist"],
    "rules": {} 
}

def parse_rule_mode(mode_input) -> str:
    if not isinstance(mode_input, str):
        return "error"
    mode = mode_input.lower().strip()
    return mode if mode in ("off", "warn", "error") else "error"

def _normalize_rule(rule_id: str, user_data) -> dict:
    base_config = DEFAULT_RULES.get(rule_id, {"mode": "error", "severity": "major"}).copy()
    
    if isinstance(user_data, bool):
        if not user_data:
            base_config["mode"] = "off"
        return base_config

    if isinstance(user_data, dict):
        if "mode" in user_data:
            base_config["mode"] = parse_rule_mode(user_data["mode"])
        if "severity" in user_data:
            base_config["severity"] = user_data["severity"]
        return base_config
        
    return base_config

def migrate_legacy_config(config: dict) -> dict:
    raw_rules = config.get("rules", {})
    migrated_rules = {}
    
    for key, value in raw_rules.items():
        rule_id = LEGACY_RULE_MAP.get(key, key)
        migrated_rules[rule_id] = _normalize_rule(rule_id, value)
        
    return {
        "rules": migrated_rules,
        "exclude": config.get("exclude", [])
    }

def load_config(path: str = "pyproject.toml") -> dict:
    if not os.path.exists(path):
        raw_config = DEFAULT_CONFIG.copy()
    else:
        try:
            with open(path, "rb") as f:
                data = tomllib.load(f)
            tool_section = data.get("tool", {})
            raw_config = tool_section.get("refactoring-agent", DEFAULT_CONFIG.copy())
        except Exception as e:
            print(f"[WARNING] Failed to load config: {e}")
            raw_config = DEFAULT_CONFIG.copy()

    final_config = {
        "exclude": raw_config.get("exclude", DEFAULT_CONFIG["exclude"]),
        "rules": {}
    }
    
    for rule_id in DEFAULT_RULES:
        final_config["rules"][rule_id] = _normalize_rule(rule_id, {})

    migrated_config = migrate_legacy_config(raw_config)
    final_config["rules"].update(migrated_config["rules"])

    return final_config

def is_rule_enabled(config: dict, rule_name: str) -> bool:
    rules = config.get("rules", {})
    rule_cfg = rules.get(rule_name)
    if not rule_cfg:
        return True 
    return rule_cfg.get("mode") != "off"
