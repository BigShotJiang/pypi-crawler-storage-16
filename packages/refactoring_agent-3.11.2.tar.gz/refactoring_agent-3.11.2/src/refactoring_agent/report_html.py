import os

def save_html_report(issues, filename="report.html"):
    """Генерирует HTML отчет."""
    css = """
    body { font-family: sans-serif; padding: 20px; background: #f4f4f9; }
    .card { background: white; padding: 15px; margin-bottom: 10px; border-radius: 8px; border-left: 5px solid #ccc; }
    .error { border-left-color: #ff4d4f; }
    .warning { border-left-color: #faad14; }
    .info { border-left-color: #1890ff; }
    .badge { font-weight: bold; font-size: 0.8em; padding: 2px 6px; border-radius: 4px; color: white; }
    .bg-error { background: #ff4d4f; } .bg-warning { background: #faad14; } .bg-info { background: #1890ff; }
    """
    
    rows = ""
    for issue in issues:
        sev = issue.get("severity", "warning")
        rows += f"""
        <div class="card {sev}">
            <div><span class="badge bg-{sev}">{sev.upper()}</span> <b>{issue['file']}:{issue.get('line','?')}</b></div>
            <div style="margin-top:5px;">{issue['message']}</div>
        </div>"""

    html = f"<!DOCTYPE html><html><head><meta charset='utf-8'><style>{css}</style></head><body><h1>Refactoring Report</h1>{rows}</body></html>"
    
    try:
        with open(filename, "w", encoding="utf-8") as f:
            f.write(html)
        return os.path.abspath(filename)
    except Exception as e:
        print(f"Error saving HTML: {e}")
        return None
