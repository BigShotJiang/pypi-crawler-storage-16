import os
import ast
from typing import List, Dict

def collect_python_files(start_path: str, exclude_dirs: list = None) -> List[str]:
    if exclude_dirs is None:
        exclude_dirs = []
    
    # Нормализуем пути исключений
    exclude_dirs = [os.path.abspath(d) for d in exclude_dirs]
    
    python_files = []
    start_abs = os.path.abspath(start_path)

    # Если передан файл, а не папка
    if os.path.isfile(start_abs):
        if start_abs.endswith(".py"):
            return [start_abs]
        return []

    for root, dirs, files in os.walk(start_abs):
        # Удаляем исключенные директории из обхода
        dirs[:] = [d for d in dirs if os.path.join(root, d) not in exclude_dirs]
        
        # Дополнительная проверка: иногда путь может быть относительным в exclude
        # поэтому проверяем имена папок тоже
        dirs[:] = [d for d in dirs if d not in ["venv", ".git", "__pycache__", "build", "dist"]]

        for file in files:
            if file.endswith(".py"):
                full_path = os.path.join(root, file)
                # Финальная проверка на всякий случай
                if any(ex in full_path for ex in exclude_dirs):
                    continue
                python_files.append(full_path)
    
    return python_files


class ASTValidator(ast.NodeVisitor):
    def __init__(self):
        self.issues = []

    def visit_Print(self, node):
        # Python 2 print statement
        self.issues.append({
            "rule_id": "print",
            "line": node.lineno,
            "message": "Legacy print statement detected. Use logger."
        })
        self.generic_visit(node)

    def visit_Call(self, node):
        # Проверяем вызовы функций
        if isinstance(node.func, ast.Name):
            func_name = node.func.id
            
            # Rule: raw_input
            if func_name == "raw_input":
                self.issues.append({
                    "rule_id": "raw_input",
                    "line": node.lineno,
                    "message": "Legacy raw_input detected. Use input() instead."
                })
            
            # Rule: security_eval
            elif func_name == "eval":
                self.issues.append({
                    "rule_id": "security_eval",
                    "line": node.lineno,
                    "message": "Security Risk: usage of eval() detected. This allows arbitrary code execution."
                })

            # Rule: security_exec (Python 3 style func)
            elif func_name == "exec":
                self.issues.append({
                    "rule_id": "security_exec",
                    "line": node.lineno,
                    "message": "Security Risk: usage of exec() detected. Avoid dynamic code execution."
                })

        # Rule: os.system
        elif isinstance(node.func, ast.Attribute):
            # Проверяем вызовы вида module.attribute()
            if isinstance(node.func.value, ast.Name):
                module_name = node.func.value.id
                method_name = node.func.attr
                
                if module_name == "os" and method_name == "system":
                    self.issues.append({
                        "rule_id": "security_os_system",
                        "line": node.lineno,
                        "message": "Security Risk: usage of os.system() detected. Vulnerable to shell injection. Use subprocess."
                    })

        self.generic_visit(node)

    # Для Python 2 exec может быть Statement, а не Call
    def visit_Exec(self, node):
        self.issues.append({
            "rule_id": "security_exec",
            "line": node.lineno,
            "message": "Security Risk: usage of exec statement detected."
        })
        self.generic_visit(node)


def analyze_file_content(content: str) -> List[Dict[str, str]]:
    """
    Анализирует код через AST и возвращает список проблем.
    """
    try:
        tree = ast.parse(content)
    except SyntaxError:
        # Если это Python 2 код, который совсем не парсится в Python 3
        # (например print "text"), ast.parse упадет.
        # В таком случае мы можем попробовать regex fallback или вернуть ошибку.
        return [{"rule_id": "parsing_error", "line": 0, "message": "Syntax Error: Cannot parse file content."}]
    
    validator = ASTValidator()
    validator.visit(tree)
    return validator.issues
