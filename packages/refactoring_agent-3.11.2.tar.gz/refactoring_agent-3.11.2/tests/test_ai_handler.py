import sys
import os
from unittest.mock import patch, MagicMock
from refactoring_agent.ai_handler import get_ai_fix, _is_invalid_api_key_error

# --- Старые тесты (проверка окружения) ---

def test_ai_suggestion_when_openai_library_missing():
    with patch("refactoring_agent.ai_handler.OPENAI_AVAILABLE", False):
        result = get_ai_fix("print 'hello'")
        assert result is None

def test_ai_suggestion_without_api_key():
    with patch("refactoring_agent.ai_handler.OPENAI_AVAILABLE", True):
        with patch.dict(os.environ, {}, clear=True):
            result = get_ai_fix("print 'hello'")
            assert result is None

# --- Новые тесты (проверка детектора ошибок) ---

def test_is_invalid_api_key_error_by_status_code():
    class DummyExc(Exception):
        def __init__(self):
            self.status_code = 401
    assert _is_invalid_api_key_error(DummyExc())

def test_is_invalid_api_key_error_by_response_code():
    class DummyExc(Exception):
        def __init__(self):
            self.response = {"error": {"code": "invalid_api_key"}}
    assert _is_invalid_api_key_error(DummyExc())

def test_is_invalid_api_key_error_by_message_text():
    msg = "Error code: 401 - {'error': {'message': 'Incorrect API key provided: sk-***', 'code': 'invalid_api_key'}}"
    exc = Exception(msg)
    assert _is_invalid_api_key_error(exc)

def test_is_invalid_api_key_error_negative():
    class DummyExc(Exception):
        def __init__(self):
            self.status_code = 500
    assert not _is_invalid_api_key_error(DummyExc())
