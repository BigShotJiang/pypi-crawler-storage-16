from refactoring_agent.utils import analyze_file_content

def test_ast_ignores_comments_and_strings():
    """Анализатор не должен реагировать на слова в кавычках или комментариях."""
    # Вот это - безопасный код. Слово print спрятано внутри строки.
    safe_code = """
def my_function():
    # raw_input("comment")
    x = "print('string')" 
"""
    issues = analyze_file_content(safe_code)
    assert len(issues) == 0

def test_ast_detects_real_issues():
    """Анализатор должен возвращать словари с rule_id."""
    bad_code = """
def my_function():
    print("Bad!")
    x = raw_input("Enter:")
"""
    issues = analyze_file_content(bad_code)
    
    assert len(issues) == 2
    
    # Теперь мы проверяем поля словаря, а не просто текст
    rule_ids = [i["rule_id"] for i in issues]
    assert "print" in rule_ids
    assert "raw_input" in rule_ids
