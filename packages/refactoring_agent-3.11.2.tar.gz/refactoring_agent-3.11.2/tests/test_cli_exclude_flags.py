import sys
from io import StringIO
from contextlib import redirect_stdout, redirect_stderr
from unittest.mock import patch
from pathlib import Path
from refactoring_agent.cli import main

def run_cli(tmp_path: Path, extra_args: list[str]) -> str:
    """
    Запускает функцию main() внутри процесса, подменяя sys.argv.
    Перехватывает print() и возвращает весь текст вывода.
    """
    fake_argv = ["refactoring_agent", "check", str(tmp_path)] + extra_args

    out_buffer = StringIO()
    err_buffer = StringIO()

    with patch.object(sys, 'argv', fake_argv):
        with redirect_stdout(out_buffer), redirect_stderr(err_buffer):
            try:
                main()
            except SystemExit:
                pass

    return out_buffer.getvalue() + err_buffer.getvalue()

def test_cli_exclude_flag_excludes_custom_directory(tmp_path):
    """Проверяем, что --exclude <dir> реально исключает эту папку."""
    # 1. Подготовка
    (tmp_path / "app.py").write_text("print('ok')\n", encoding="utf-8")
    
    legacy_dir = tmp_path / "demo_legacy"
    legacy_dir.mkdir()
    (legacy_dir / "legacy.py").write_text("value = raw_input('enter: ')\n", encoding="utf-8")

    # 2. Без флагов
    out_default = run_cli(tmp_path, [])
    assert "demo_legacy/legacy.py" in out_default

    # 3. С флагом --exclude
    out_excluded = run_cli(tmp_path, ["--exclude", "demo_legacy"])
    
    assert "Ignoring paths:" in out_excluded
    assert "demo_legacy" in out_excluded
    assert "demo_legacy/legacy.py" not in out_excluded

def test_cli_no_default_excludes_includes_tests_directory(tmp_path):
    """Проверяем работу --no-default-excludes."""
    # 1. Подготовка
    (tmp_path / "main.py").write_text("print('main')\n", encoding="utf-8")

    tests_dir = tmp_path / "tests"
    tests_dir.mkdir()
    (tests_dir / "test_legacy.py").write_text("value = raw_input('legacy')\n", encoding="utf-8")

    # 2. Без флага (tests игнорируется)
    out_default = run_cli(tmp_path, [])
    assert "Ignoring paths:" in out_default
    
    # 3. С флагом --no-default-excludes
    out_no_default = run_cli(tmp_path, ["--no-default-excludes"])
    
    # ТЕПЕРЬ МЫ ЖДЕМ ЭТУ ФРАЗУ:
    assert "Scanning EVERYTHING" in out_no_default
    assert "Ignoring paths:" not in out_no_default
    
    # Файл tests/test_legacy.py должен быть найден
    assert "tests/test_legacy.py" in out_no_default
