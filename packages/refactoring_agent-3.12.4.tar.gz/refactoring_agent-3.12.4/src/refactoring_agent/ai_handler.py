import os
from openai import OpenAI, OpenAIError

def get_ai_fix(code, issues, provider="openai", model=None, api_key=None, base_url=None):
    """
    Orchestrates the AI fix generation based on the selected provider.
    """
    # 1. MOCK PROVIDER (For testing/demos without API keys)
    if provider == "mock":
        # Return a deterministic fix for demonstration
        fixed = code
        if "subprocess.Popen" in fixed and "shell=True" in fixed:
            fixed = fixed.replace("shell=True", "shell=False # FIXED by Refactoring Agent")
        if "pickle.loads" in fixed:
            fixed = fixed.replace("pickle.loads", "json.loads # FIXED by Refactoring Agent")
        return fixed

    # 2. SETUP CLIENT (OpenAI / Ollama)
    # Determine API Key
    final_api_key = api_key or os.getenv("OPENAI_API_KEY")
    
    # Determine Base URL and Model defaults
    if provider == "ollama":
        final_base_url = base_url or os.getenv("RA_LLM_BASE_URL", "http://localhost:11434/v1")
        final_api_key = "ollama" # Ollama often ignores key, but client requires one
        final_model = model or os.getenv("RA_LLM_MODEL", "llama3")
    else:
        # Default OpenAI
        final_base_url = base_url # None by default (uses official endpoint)
        final_model = model or "gpt-4o-mini"

    if not final_api_key and provider != "ollama":
        print(f"[ERROR] API Key not found for provider '{provider}'. Set OPENAI_API_KEY or use --api-key.")
        return None

    try:
        client = OpenAI(api_key=final_api_key, base_url=final_base_url)
    except Exception as e:
        print(f"[ERROR] Failed to initialize AI client: {e}")
        return None

    # 3. CONSTRUCT PROMPT
    issues_text = "\n".join([f"- Line {i['line']}: {i['message']}" for i in issues])
    prompt = f"""
You are an expert Secure Python Code Refactoring Agent.
Your task is to fix the following SECURITY ISSUES in the provided code.

ISSUES TO FIX:
{issues_text}

INSTRUCTIONS:
1. Return ONLY the fixed python code.
2. Do NOT add markdown backticks (```).
3. Do NOT add explanations.
4. Keep comments if they are not related to the fix.
5. If using 'subprocess', prefer 'shell=False' and list arguments.
6. If using 'pickle', replace with a safe alternative or add a warning comment if architectural change is too big.

ORIGINAL CODE:
{code}
    """

    # 4. CALL LLM
    try:
        response = client.chat.completions.create(
            model=final_model,
            messages=[
                {"role": "system", "content": "You are a senior python security engineer. Output only code."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.2
        )
        fixed_code = response.choices[0].message.content.strip()
        
        # Cleanup potential markdown formatting from LLM
        if fixed_code.startswith("```python"):
            fixed_code = fixed_code[9:]
        if fixed_code.startswith("```"):
            fixed_code = fixed_code[3:]
        if fixed_code.endswith("```"):
            fixed_code = fixed_code[:-3]
            
        return fixed_code.strip()

    except OpenAIError as e:
        print(f"[ERROR] AI Provider error: {e}")
        return None
    except Exception as e:
        print(f"[ERROR] Unexpected error: {e}")
        return None
