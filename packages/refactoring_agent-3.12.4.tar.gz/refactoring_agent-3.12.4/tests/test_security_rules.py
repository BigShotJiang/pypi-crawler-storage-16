import pytest
import ast
# Импортируем наши модули. Если тут будет ошибка, значит шаг 2 не выполнен.
from refactoring_agent.wizard import LegacyCodeVisitor
from refactoring_agent.config import DEFAULT_RULES

def scan_code(code_str):
    """Helper to simulate running the wizard on a string of code."""
    tree = ast.parse(code_str)
    # Используем реальные правила из конфига
    visitor = LegacyCodeVisitor(DEFAULT_RULES)
    visitor.visit(tree)
    return visitor.issues

def test_subprocess_shell_true_detected():
    code = """
import subprocess
# Bad: shell=True
subprocess.Popen('ls -la', shell=True)
subprocess.run('rm -rf /', shell=True)
    """
    issues = scan_code(code)
    # Должно быть 2 находки
    assert len(issues) == 2
    assert issues[0]["rule_id"] == "security_subprocess_shell"

def test_subprocess_shell_false_ignored():
    code = """
import subprocess
# Good: shell=False (or omitted)
subprocess.Popen(['ls', '-la'], shell=False)
subprocess.run(['ls'])
    """
    issues = scan_code(code)
    assert len(issues) == 0

def test_pickle_load_detected():
    code = """
import pickle
# Bad: unpickling
data = pickle.load(file)
obj = pickle.loads(b'payload')
    """
    issues = scan_code(code)
    assert len(issues) == 2
    assert issues[0]["rule_id"] == "security_pickle_untrusted"

def test_insecure_random_detected():
    code = """
import random
# Bad: random for secrets
api_key = random.choice('abcdef')
user_password = random.randint(1000, 9999)
    """
    issues = scan_code(code)
    assert len(issues) == 2
    assert issues[0]["rule_id"] == "security_insecure_random"

def test_safe_random_ignored():
    code = """
import random
# Good: random for non-secrets
dice_roll = random.randint(1, 6)
random_color = random.choice(['red', 'blue'])
    """
    issues = scan_code(code)
    assert len(issues) == 0
