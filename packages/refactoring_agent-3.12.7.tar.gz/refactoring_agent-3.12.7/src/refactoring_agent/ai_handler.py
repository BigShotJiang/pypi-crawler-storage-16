import os
import httpx
from typing import List, Dict, Optional, Protocol, Any

# Try importing openai, but don't fail if it's missing (we might be in air-gapped mode)
try:
    import openai
except ImportError:
    openai = None

# --- 1. Abstract Interface ---
class BaseLLMClient(Protocol):
    """Protocol that all LLM providers must implement."""
    def chat_completion(self, messages: List[Dict[str, str]], temperature: float = 0.2) -> Optional[str]:
        ...

# --- 2. OpenAI Implementation ---
class OpenAILLMClient:
    def __init__(self, model: str, api_key: str, base_url: Optional[str] = None):
        if not openai:
            raise ImportError("OpenAI library is not installed. Please install 'refactoring-agent[openai]' or 'openai'.")
        self.client = openai.OpenAI(api_key=api_key, base_url=base_url)
        self.model = model or "gpt-4o-mini"

    def chat_completion(self, messages: List[Dict[str, str]], temperature: float = 0.2) -> Optional[str]:
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages, # type: ignore
                temperature=temperature
            )
            return response.choices[0].message.content
        except Exception as e:
            print(f"[ERROR] OpenAI Provider error: {e}")
            return None

# --- 3. Ollama Implementation (Air-Gapped) ---
class OllamaLLMClient:
    """
    Native Ollama client using HTTPX.
    GUARANTEE: This client does NOT use the 'openai' library, ensuring full isolation.
    """
    def __init__(self, model: str, base_url: str):
        self.model = model or "llama3"
        # Ensure clean URL
        self.base_url = base_url.rstrip("/")
        if not self.base_url.startswith("http"):
             self.base_url = f"http://{self.base_url}"

    def chat_completion(self, messages: List[Dict[str, str]], temperature: float = 0.2) -> Optional[str]:
        # Using Ollama's native /api/chat endpoint
        url = f"{self.base_url}/api/chat"
        
        payload = {
            "model": self.model,
            "messages": messages,
            "stream": False,
            "options": {
                "temperature": temperature
            }
        }

        try:
            # We use a short timeout for connection but longer for generation
            response = httpx.post(url, json=payload, timeout=120.0)
            response.raise_for_status()
            
            data = response.json()
            # Ollama returns content in 'message' -> 'content'
            return data.get("message", {}).get("content")
            
        except httpx.ConnectError:
            print(f"[ERROR] Could not connect to Ollama at {self.base_url}. Is it running?")
            return None
        except Exception as e:
            print(f"[ERROR] Ollama Provider error: {e}")
            return None

# --- 4. Mock Implementation ---
class MockLLMClient:
    def chat_completion(self, messages: List[Dict[str, str]], temperature: float = 0.2) -> Optional[str]:
        # Extract code from the last user message to simulate a fix
        last_msg = messages[-1]["content"]
        
        # Simple deterministic replacements for demo purposes
        fixed = last_msg
        if "subprocess.Popen" in fixed and "shell=True" in fixed:
            fixed = fixed.replace("shell=True", "shell=False # FIXED by Refactoring Agent")
        if "pickle.loads" in fixed:
            fixed = fixed.replace("pickle.loads", "json.loads # FIXED by Refactoring Agent")
        
        # If we just got the prompt text without code block in a real scenario, this is fuzzy,
        # but for the mock provider's specific use case (demo_dryrun), this works.
        return fixed

# --- 5. Factory & Main Logic ---

def create_llm_client(provider: str, model: str, api_key: Optional[str], base_url: Optional[str]) -> BaseLLMClient:
    """Factory to create the appropriate LLM client."""
    provider = provider.lower()
    
    # Defaults handled here
    if provider == "openai":
        final_api_key = api_key or os.getenv("OPENAI_API_KEY")
        if not final_api_key:
            raise ValueError("OpenAI API Key is missing. Set OPENAI_API_KEY or pass --api-key.")
        return OpenAILLMClient(model=model, api_key=final_api_key, base_url=base_url)
        
    elif provider == "ollama":
        # Default to localhost if not specified
        final_base_url = base_url or os.getenv("RA_LLM_BASE_URL", "http://localhost:11434")
        final_model = model or os.getenv("RA_LLM_MODEL", "llama3")
        
        # Log for Enterprise/Security audit
        if "localhost" in final_base_url or "127.0.0.1" in final_base_url:
             print(f"[INFO] 🔒 Running in AIR-GAPPED mode. Provider: Ollama ({final_base_url})")
        else:
             print(f"[INFO] Running in Local LLM mode. Provider: Ollama ({final_base_url})")
             
        return OllamaLLMClient(model=final_model, base_url=final_base_url)
        
    elif provider == "mock":
        return MockLLMClient()
        
    else:
        raise ValueError(f"Unknown provider: {provider}")

def get_ai_fix(code, issues, provider="openai", model=None, api_key=None, base_url=None):
    """
    Main entry point for AI refactoring.
    """
    # Construct the Prompt
    issues_text = "\n".join([f"- Line {i['line']}: {i['message']}" for i in issues])
    prompt = f"""
You are an expert Secure Python Code Refactoring Agent.
Your task is to fix the following SECURITY ISSUES in the provided code.

ISSUES TO FIX:
{issues_text}

INSTRUCTIONS:
1. Return ONLY the fixed python code.
2. Do NOT add markdown backticks (```).
3. Do NOT add explanations.
4. Keep comments if they are not related to the fix.
5. If using 'subprocess', prefer 'shell=False' and list arguments.
6. If using 'pickle', replace with a safe alternative or add a warning comment.

ORIGINAL CODE:
{code}
    """
    
    messages = [
        {"role": "system", "content": "You are a senior python security engineer. Output only code."},
        {"role": "user", "content": prompt}
    ]

    try:
        client = create_llm_client(provider, model or "", api_key, base_url)
        fixed_code = client.chat_completion(messages)
        
        if not fixed_code:
            return None

        # Cleanup potential markdown formatting from LLM
        cleaned_code = fixed_code.strip()
        if cleaned_code.startswith("```python"):
            cleaned_code = cleaned_code[9:]
        elif cleaned_code.startswith("```"):
            cleaned_code = cleaned_code[3:]
        if cleaned_code.endswith("```"):
            cleaned_code = cleaned_code[:-3]
            
        return cleaned_code.strip()

    except ValueError as e:
        print(f"[ERROR] Configuration error: {e}")
        return None
    except Exception as e:
        print(f"[ERROR] Unexpected error in AI handler: {e}")
        return None
