import argparse
import sys
import os
from rich.console import Console
from rich.progress import track
from rich.prompt import Confirm

from refactoring_agent.wizard import RefactoringWizard
from refactoring_agent.config import load_config
from refactoring_agent.utils import collect_python_files, print_diff
from refactoring_agent.report_html import generate_html_report

# Optional imports
try:
    from refactoring_agent.ai_handler import get_ai_fix
except ImportError:
    get_ai_fix = None

try:
    from refactoring_agent.github_handler import post_github_comment, print_github_annotation
except ImportError:
    post_github_comment = None

console = Console()

def determine_exit_code(issues, soft_fail=False):
    if soft_fail:
        return 0
    blocking_issues = [
        i for i in issues 
        if i.get('mode') == 'error' and i.get('severity') in ['critical', 'major']
    ]
    if blocking_issues:
        console.print(f"\n[bold red]FAILURE: Found {len(blocking_issues)} blocking issues (Critical/Major).[/]")
        return 1
    return 0

def run_init(args):
    config_path = "pyproject.toml"
    if os.path.exists(config_path):
        console.print(f"[yellow]'{config_path}' already exists.[/]")
        return
    template = """[tool.refactoring-agent]
security_level = "strict"
legacy_print = "warn"
[tool.refactoring-agent.rules]
# security_insecure_random = "ignore"
"""
    with open(config_path, "w", encoding="utf-8") as f:
        f.write(template)
    console.print(f"[green]✔ Created default configuration in {config_path}[/]")

def run_check(args):
    # 0. CI Validation
    interactive_mode = False
    if args.ai_fix and not args.dry_run:
        if args.assume_yes:
            interactive_mode = False
        else:
            if sys.stdin.isatty():
                interactive_mode = True
            else:
                console.print("[bold red]Error:[/] --ai-fix requires interactive terminal or --yes flag.")
                sys.exit(2)

    config = load_config()
    wizard = RefactoringWizard(config)
    exclude_list = args.exclude.split(",")
    files = collect_python_files(args.path, exclude_list)
    
    if not files:
        console.print(f"[bold red]No Python files found in '{args.path}'![/]")
        sys.exit(0)

    console.print(f"[bold blue]Found {len(files)} python files. Starting analysis...[/]")
    
    all_issues = []
    
    # 1. Scanning
    for file_path in track(files, description="Scanning..."):
        issues = wizard.scan_file(file_path)
        if issues:
            all_issues.extend(issues)

    # Report & Annotations
    if not all_issues:
        console.print("\n[bold green]--- SUMMARY REPORT ---[/]")
        console.print("[bold green][OK] Clean! No issues found.[/]")
    else:
        console.print("\n[bold red]--- SUMMARY REPORT ---[/]")
        for issue in all_issues:
            loc = f"{issue['file']}:{issue['line']}"
            severity = issue.get('severity', 'minor').upper()
            rule = issue.get('rule_id', 'unknown')
            msg = issue['message']
            color = "red" if severity == "CRITICAL" else "yellow" if severity == "MAJOR" else "white"
            console.print(f"[{color}][{severity}] {loc} ({rule}): {msg}[/]")
            
            # Emit GitHub Annotation if in CI mode
            if args.github_actions and post_github_comment:
                print_github_annotation(issue)

    if args.html_report:
        generate_html_report(all_issues, args.html_report)
        console.print(f"\n[bold cyan]HTML report generated: {args.html_report}[/]")

    # 2. AI Fixing Phase
    ai_fixes_content = {} # Store fixed code for PR comment

    if args.ai_fix and all_issues:
        if not get_ai_fix:
            console.print("\n[bold red]AI module not installed.[/]")
            sys.exit(2)

        console.print("\n[bold purple][AUTO-FIX] Starting Remediation...[/]")
        
        issues_by_file = {}
        for issue in all_issues:
            if issue['file'] not in issues_by_file:
                issues_by_file[issue['file']] = []
            issues_by_file[issue['file']].append(issue)

        for file_path, file_issues in issues_by_file.items():
            console.print(f"\n👉 Processing [bold]{file_path}[/]...")
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    original_code = f.read()

                fixed_code = get_ai_fix(
                    original_code, 
                    file_issues, 
                    provider=args.provider,
                    model=args.model,
                    api_key=args.api_key,
                    base_url=args.base_url
                )

                if fixed_code and fixed_code != original_code:
                    ai_fixes_content[file_path] = fixed_code # Save for PR comment
                    
                    print_diff(original_code, fixed_code, file_path)

                    if args.dry_run:
                        console.print("   [dim]--dry-run enabled, changes NOT written.[/]")
                        continue

                    should_apply = False
                    if args.assume_yes:
                        should_apply = True
                    elif interactive_mode:
                        should_apply = Confirm.ask(f"[bold yellow]Apply this fix to {file_path}?[/]")
                    
                    if should_apply:
                        with open(file_path, "w", encoding="utf-8") as f:
                            f.write(fixed_code)
                        console.print(f"   [bold green]✔ Fixed applied![/]")
                    else:
                        console.print("   [dim]Skipped.[/]")
                else:
                    console.print("   [yellow]No changes proposed by AI.[/]")
            except Exception as e:
                console.print(f"   [red]Error processing file: {e}[/]")

    # 3. Post GitHub Comment (if enabled)
    if args.github_actions and post_github_comment:
        if all_issues:
            console.print("\n[bold blue]Posting summary to GitHub Pull Request...[/]")
            post_github_comment(all_issues, ai_fixes_content, args.html_report)

    sys.exit(determine_exit_code(all_issues, args.soft_fail))

def main():
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", required=True)

    check_parser = subparsers.add_parser("check")
    check_parser.add_argument("path", nargs="?", default=".")
    check_parser.add_argument("--exclude", default="venv,.venv,dist,build,node_modules")
    check_parser.add_argument("--html-report")
    check_parser.add_argument("--soft-fail", action="store_true")
    check_parser.add_argument("--github-actions", action="store_true", help="Enable GitHub Actions mode (annotations + comments)")
    
    check_parser.add_argument("--ai-fix", action="store_true")
    check_parser.add_argument("--dry-run", action="store_true")
    check_parser.add_argument("-y", "--yes", "--no-input", dest="assume_yes", action="store_true")
    
    check_parser.add_argument("--provider", choices=["openai", "ollama", "mock"], default="openai")
    check_parser.add_argument("--model")
    check_parser.add_argument("--api-key")
    check_parser.add_argument("--base-url")

    init_parser = subparsers.add_parser("init")

    args = parser.parse_args()

    if args.command == "check":
        run_check(args)
    elif args.command == "init":
        run_init(args)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
