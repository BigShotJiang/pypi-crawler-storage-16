import os
import difflib
from rich.console import Console
from rich.syntax import Syntax
from rich.panel import Panel

console = Console()

def collect_python_files(start_path, exclude_dirs=None):
    """Recursively collects .py files, ignoring excluded directories."""
    if exclude_dirs is None:
        exclude_dirs = []
    
    python_files = []
    for root, dirs, files in os.walk(start_path):
        # Modify dirs in-place to skip excluded directories
        dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith('.')]
        
        for file in files:
            if file.endswith(".py"):
                python_files.append(os.path.join(root, file))
    return python_files

def print_diff(original_code, fixed_code, filename):
    """
    Displays a unified diff between original and fixed code using Rich.
    """
    diff_lines = list(difflib.unified_diff(
        original_code.splitlines(),
        fixed_code.splitlines(),
        fromfile=f"a/{filename}",
        tofile=f"b/{filename}",
        lineterm=""
    ))

    if not diff_lines:
        return False

    diff_text = "\n".join(diff_lines)
    
    # Create a syntax-highlighted diff object
    syntax = Syntax(diff_text, "diff", theme="monokai", line_numbers=False)
    
    console.print(Panel(
        syntax,
        title=f"[bold yellow]DRY RUN: Proposed changes for {filename}[/]",
        border_style="yellow",
        expand=False
    ))
    return True
