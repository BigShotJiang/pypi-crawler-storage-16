import pytest
import logging
from refactoring_agent.ai_handler import create_llm_client, get_ai_fix

# 1. Тест на изоляцию классов (Architecture Test)
def test_ollama_client_does_not_init_openai(monkeypatch):
    """
    Verify that creating an Ollama client NEVER triggers OpenAI initialization.
    """
    # "Отравляем" OpenAI клиент. Если код попытается его создать - тест упадет.
    def poisonous_init(*args, **kwargs):
        raise RuntimeError("SECURITY BREACH: OpenAI Client was initialized in Ollama mode!")

    monkeypatch.setattr("refactoring_agent.ai_handler.OpenAILLMClient.__init__", poisonous_init)

    # Пытаемся создать Ollama клиента
    try:
        client = create_llm_client(provider="ollama", model="llama3", api_key=None, base_url=None)
        assert client.__class__.__name__ == "OllamaLLMClient"
    except RuntimeError as e:
        pytest.fail(f"Test failed: {e}")

# 2. Тест на сетевую изоляцию (Network Test)
def test_ollama_requests_are_local_only(monkeypatch):
    """
    Verify that Ollama client only sends requests to localhost.
    """
    # Перехватчик HTTP запросов
    def strict_local_post(url, *args, **kwargs):
        # Разрешаем только локальные адреса
        is_local = url.startswith("http://localhost") or url.startswith("http://127.0.0.1")
        if not is_local:
            raise RuntimeError(f"SECURITY BREACH: Request sent to non-local URL: {url}")
        
        # Возвращаем фейковый ответ, чтобы код работал дальше
        class MockResponse:
            def json(self): return {"message": {"content": "fixed_code"}}
            def raise_for_status(self): pass
        return MockResponse()

    # Подменяем httpx.post на нашего строгого охранника
    monkeypatch.setattr("httpx.post", strict_local_post)

    # Запускаем полный цикл фикса
    issues = [{"line": 1, "message": "Test issue"}]
    code = "import pickle"
    
    # Это должно пройти успешно (URL = localhost)
    get_ai_fix(code, issues, provider="ollama")

    # А теперь провокация: пытаемся подсунуть внешний URL
    # Тест должен упасть, если клиент послушается и пойдет наружу (но наш код принудительно ставит http, если схемы нет)
    # В данном случае мы проверяем, что httpx.post вызовет наш strict_local_post
    
# 3. Тест на аудит логов (Audit Test)
def test_air_gapped_logging(capsys):
    """
    Verify that the tool explicitly logs AIR-GAPPED status to stdout.
    """
    # Запускаем создание клиента
    create_llm_client(provider="ollama", model="llama3", api_key=None, base_url="http://localhost:11434")
    
    # Читаем то, что попало в консоль
    captured = capsys.readouterr()
    
    # Ищем заветную фразу
    assert "🔒 Running in AIR-GAPPED mode" in captured.out
    assert "Provider: Ollama" in captured.out

def test_non_air_gapped_logging(capsys):
    """
    Verify distinctive logging for non-local custom URLs.
    """
    # Допустим, банк использует внутренний сервер (не localhost)
    create_llm_client(provider="ollama", model="llama3", api_key=None, base_url="http://private-ai-server.corp")
    
    captured = capsys.readouterr()
    
    # Должно быть написано "Local LLM", но БЕЗ замка "🔒" и слов "AIR-GAPPED"
    assert "Running in Local LLM mode" in captured.out
    assert "AIR-GAPPED" not in captured.out
