import os
from pathlib import Path
from refactoring_agent.config import load_config

def test_load_default_without_file(tmp_path, monkeypatch):
    """Если файла нет, конфиг загружается, но rules пустые (используются дефолты из кода)."""
    monkeypatch.chdir(tmp_path)
    cfg = load_config()
    # В новой логике rules пустые, если файл не найден, но конфиг валиден
    assert isinstance(cfg["rules"], dict)
    assert "exclude" in cfg

def test_read_pyproject_toml_overrides_defaults(tmp_path, monkeypatch):
    """Проверяем чтение нового формата конфига."""
    monkeypatch.chdir(tmp_path)
    
    # Пишем конфиг в НОВОМ формате (как мы и планировали)
    toml_content = """
[tool.refactoring-agent]
exclude = ["custom_folder"]

[tool.refactoring-agent.rules.raw_input]
mode = "off"
    """
    (tmp_path / "pyproject.toml").write_text(toml_content, encoding="utf-8")
    
    cfg = load_config()
    
    assert "custom_folder" in cfg["exclude"]
    # Проверяем новую структуру
    assert "raw_input" in cfg["rules"]
    assert cfg["rules"]["raw_input"]["mode"] == "off"
