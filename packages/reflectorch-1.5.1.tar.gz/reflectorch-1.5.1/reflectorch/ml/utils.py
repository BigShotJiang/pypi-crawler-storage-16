def is_divisor(num: int, div: int):
    return num and not num % div
