from reflectorch.runs import run_test_config

if __name__ == '__main__':
    run_test_config()
