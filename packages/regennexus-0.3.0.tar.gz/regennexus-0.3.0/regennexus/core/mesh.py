"""
RegenNexus UAP - Mesh Network Discovery

Automatic plug-and-play mesh networking. Devices find each other
on LAN via UDP multicast, across networks via WebSocket, and
communicate using the best available transport.

Now with PeerManager for persistent connections and auto-reconnect.

Copyright (c) 2024-2025 ReGen Designs LLC
"""

import asyncio
import json
import logging
import socket
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set

from regennexus.core.message import Message
from regennexus.core.peer_manager import PeerManager, ConnectionState
from regennexus.transport.base import TransportConfig, TransportType
from regennexus.transport.auto import AutoTransport

logger = logging.getLogger(__name__)


class NodeState(Enum):
    """Node state in the mesh."""
    OFFLINE = "offline"
    DISCOVERING = "discovering"
    ONLINE = "online"
    ERROR = "error"


@dataclass
class MeshNode:
    """A node in the mesh network."""
    node_id: str
    entity_type: str
    capabilities: List[str] = field(default_factory=list)
    address: Optional[str] = None
    port: int = 0
    ws_url: Optional[str] = None  # WebSocket URL for persistent connection
    transport: TransportType = TransportType.UDP
    last_seen: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)
    # Connection health (managed by PeerManager)
    connection_state: str = "unknown"  # connected, reconnecting, disconnected
    last_rtt: float = 0.0  # Last ping round-trip time in ms

    @property
    def is_stale(self) -> bool:
        """Check if node hasn't been seen recently."""
        return time.time() - self.last_seen > 60.0  # 60 second timeout

    @property
    def is_connected(self) -> bool:
        """Check if peer has active connection."""
        return self.connection_state == "connected"


@dataclass
class MeshConfig:
    """Mesh network configuration."""
    node_id: Optional[str] = None  # Auto-generated if None
    entity_type: str = "device"
    capabilities: List[str] = field(default_factory=list)

    # Discovery settings
    discovery_enabled: bool = True
    discovery_interval: float = 5.0  # seconds
    node_timeout: float = 60.0  # seconds before node considered offline

    # Transport settings
    auto_select_transport: bool = True
    udp_enabled: bool = True
    udp_port: int = 5454  # Changed from 5353 to avoid mDNS conflicts
    udp_multicast_group: str = "239.255.255.250"

    websocket_enabled: bool = True
    websocket_port: int = 8765

    ipc_enabled: bool = True

    # PeerManager settings (persistent connections)
    # No keepalive pings - WebSocket protocol handles that automatically
    reconnect_delays: List[float] = field(default_factory=lambda: [1, 2, 5, 10, 30])

    # Hub settings (for internet connectivity)
    hub_url: Optional[str] = None  # Central hub for cross-network discovery


class MeshNetwork:
    """
    Automatic mesh network for RegenNexus UAP.

    Provides plug-and-play device discovery and communication:
    - UDP multicast for LAN discovery
    - WebSocket for remote/internet connections
    - Auto-selection of best transport per peer
    - Message routing between nodes

    Example:
        mesh = MeshNetwork(MeshConfig(
            node_id="raspi-001",
            entity_type="device",
            capabilities=["gpio", "camera"]
        ))

        await mesh.start()

        # Nodes auto-discover each other
        peers = mesh.get_peers()

        # Send message (transport auto-selected)
        await mesh.send("jetson-001", {"command": "capture"})

        # Broadcast to all
        await mesh.broadcast({"event": "sensor_update", "value": 23.5})
    """

    def __init__(self, config: Optional[MeshConfig] = None):
        """
        Initialize mesh network.

        Args:
            config: Mesh configuration (uses defaults if None)
        """
        self.config = config or MeshConfig()

        # Generate node ID if not provided
        if not self.config.node_id:
            self.config.node_id = f"node-{uuid.uuid4().hex[:8]}"

        self.node_id = self.config.node_id
        self.state = NodeState.OFFLINE

        # Known peers
        self._peers: Dict[str, MeshNode] = {}
        self._peer_lock = asyncio.Lock()

        # Transport (for discovery and local WebSocket server)
        self._transport: Optional[AutoTransport] = None

        # PeerManager for persistent connections to peers
        self._peer_manager: Optional[PeerManager] = None

        # Pending ping futures (for CLI ping commands)
        self._pending_pings: Dict[str, asyncio.Future] = {}

        # Tasks
        self._discovery_task: Optional[asyncio.Task] = None
        self._cleanup_task: Optional[asyncio.Task] = None

        # Message handlers
        self._message_handlers: List[Callable] = []
        self._peer_handlers: List[Callable] = []

    async def start(self) -> bool:
        """
        Start mesh network.

        Initializes transport, starts discovery, starts PeerManager
        for persistent connections, and begins listening for peer announcements.

        Returns:
            True if started successfully
        """
        if self.state == NodeState.ONLINE:
            return True

        self.state = NodeState.DISCOVERING
        logger.info(f"Starting mesh network as {self.node_id}")

        try:
            # Create transport config
            transport_config = TransportConfig(
                udp_enabled=self.config.udp_enabled,
                udp_port=self.config.udp_port,
                udp_multicast_group=self.config.udp_multicast_group,
                udp_broadcast_interval=self.config.discovery_interval,
                websocket_enabled=self.config.websocket_enabled,
                ws_port=self.config.websocket_port,
                ipc_enabled=self.config.ipc_enabled,
            )

            # Create and connect transport
            self._transport = AutoTransport(transport_config)
            self._transport.set_local_id(self.node_id)
            self._transport.set_local_info({
                "entity_type": self.config.entity_type,
                "capabilities": self.config.capabilities,
            })
            self._transport.add_handler(self._handle_message)

            # Set up peer lookup callback for mesh.peers requests
            self._transport.set_peer_lookup(self._get_peer_list_for_lookup)

            if not await self._transport.connect():
                logger.error("Failed to connect transport")
                self.state = NodeState.ERROR
                return False

            # Initialize PeerManager for persistent connections
            # No continuous keepalive pings - WebSocket protocol handles connection health
            self._peer_manager = PeerManager(
                local_id=self.node_id,
                local_info={
                    "entity_type": self.config.entity_type,
                    "capabilities": self.config.capabilities,
                    "ws_url": f"ws://0.0.0.0:{self.config.websocket_port}",
                },
                reconnect_delays=self.config.reconnect_delays,
                on_peer_connected=self._on_peer_manager_connected,
                on_peer_disconnected=self._on_peer_manager_disconnected,
                on_message=self._on_peer_manager_message,
            )
            await self._peer_manager.start()
            logger.info("PeerManager started (presence-based, no ping flooding)")

            # Start discovery loop
            if self.config.discovery_enabled:
                self._discovery_task = asyncio.create_task(self._discovery_loop())

            # Start cleanup loop
            self._cleanup_task = asyncio.create_task(self._cleanup_loop())

            self.state = NodeState.ONLINE
            logger.info(f"Mesh network online: {self.node_id}")

            # Announce ourselves
            await self._announce()

            return True

        except Exception as e:
            logger.error(f"Mesh start error: {e}")
            self.state = NodeState.ERROR
            return False

    async def _on_peer_manager_connected(self, peer_id: str) -> None:
        """Called when PeerManager establishes connection to a peer."""
        async with self._peer_lock:
            if peer_id in self._peers:
                self._peers[peer_id].connection_state = "connected"
                logger.info(f"Peer connection established: {peer_id}")

    async def _on_peer_manager_disconnected(self, peer_id: str) -> None:
        """Called when PeerManager loses connection to a peer."""
        async with self._peer_lock:
            if peer_id in self._peers:
                self._peers[peer_id].connection_state = "reconnecting"
                logger.info(f"Peer connection lost, reconnecting: {peer_id}")

    async def _on_peer_manager_message(self, message: Message, peer_id: str) -> None:
        """Called when PeerManager receives a message from a peer."""
        # Update last_seen
        async with self._peer_lock:
            if peer_id in self._peers:
                self._peers[peer_id].last_seen = time.time()

        # Handle pong for pending pings
        if message.intent == "mesh.pong":
            content = message.content or {}
            ping_id = content.get("ping_id")
            if ping_id and ping_id in self._pending_pings:
                try:
                    self._pending_pings[ping_id].set_result(message)
                except asyncio.InvalidStateError:
                    pass  # Future already done

        # Forward to transport for local clients (CLI)
        if self._transport:
            await self._transport.broadcast_to_local_clients(message)

        # Call registered message handlers
        for handler in self._message_handlers:
            try:
                result = handler(message)
                if asyncio.iscoroutine(result):
                    await result
            except Exception as e:
                logger.error(f"Message handler error: {e}")

    async def stop(self) -> None:
        """Stop mesh network."""
        if self.state == NodeState.OFFLINE:
            return

        logger.info(f"Stopping mesh network: {self.node_id}")

        # Cancel tasks
        if self._discovery_task:
            self._discovery_task.cancel()
            try:
                await self._discovery_task
            except asyncio.CancelledError:
                pass

        if self._cleanup_task:
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass

        # Stop PeerManager (closes all persistent connections)
        if self._peer_manager:
            await self._peer_manager.stop()
            self._peer_manager = None
            logger.info("PeerManager stopped")

        # Send goodbye
        await self._announce(leaving=True)

        # Disconnect transport
        if self._transport:
            await self._transport.disconnect()
            self._transport = None

        self._peers.clear()
        self.state = NodeState.OFFLINE

        logger.info("Mesh network stopped")

    async def _discovery_loop(self) -> None:
        """Periodically announce presence."""
        try:
            while self.state == NodeState.ONLINE:
                await self._announce()
                await asyncio.sleep(self.config.discovery_interval)
        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.error(f"Discovery loop error: {e}")

    async def _cleanup_loop(self) -> None:
        """Periodically clean up stale peers."""
        try:
            while self.state == NodeState.ONLINE:
                await asyncio.sleep(30)
                await self._cleanup_stale_peers()
        except asyncio.CancelledError:
            pass

    def _get_local_ip(self) -> Optional[str]:
        """Get local LAN IP address for announcements."""
        try:
            # Connect to external address to find default route IP
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(0.1)
            try:
                s.connect(("8.8.8.8", 80))
                local_ip = s.getsockname()[0]
            finally:
                s.close()
            return local_ip
        except Exception:
            return None

    async def _announce(self, leaving: bool = False) -> None:
        """
        Announce presence to the network.

        Args:
            leaving: If True, announce that we're leaving
        """
        if not self._transport:
            return

        # Build announcement content with ws_url for peer connections
        content = {
            "node_id": self.node_id,
            "entity_type": self.config.entity_type,
            "capabilities": self.config.capabilities,
            "timestamp": time.time(),
        }

        # Include ws_url so peers can connect back to us
        local_ip = self._get_local_ip()
        if local_ip:
            content["ws_url"] = f"ws://{local_ip}:{self.config.websocket_port}"

        announcement = Message(
            sender_id=self.node_id,
            recipient_id="*",
            intent="mesh.announce" if not leaving else "mesh.goodbye",
            content=content,
        )

        await self._transport.broadcast(announcement)

    async def _handle_message(self, message: Message) -> None:
        """
        Handle incoming message.

        Args:
            message: Received message
        """
        try:
            # NEVER forward mesh protocol messages - they should be handled
            # directly by the recipient, not routed through intermediate nodes
            # This prevents echo/amplification loops in the mesh network
            mesh_protocol_intents = (
                "mesh.ping", "mesh.pong", "mesh.announce", "mesh.goodbye",
                "peer_announce", "peer_announce_ack"
            )
            if message.intent in mesh_protocol_intents:
                # Only process if addressed to us or broadcast
                recipient = message.recipient_id
                if recipient and recipient != "*" and recipient != self.node_id:
                    # Mesh protocol message for another peer - drop it, don't forward
                    logger.debug(f"Dropping {message.intent} not addressed to us (for {recipient})")
                    return
                # Fall through to handle locally
            else:
                # Check if message should be routed to another peer
                recipient = message.recipient_id
                if recipient and recipient != "*" and recipient != self.node_id:
                    # Message is for another peer - forward it via PeerManager
                    logger.debug(f"Routing message to {recipient}: intent={message.intent}")

                    sent = False
                    if self._peer_manager:
                        sent = await self._peer_manager.send_to_peer(recipient, message)

                    if not sent and self._transport:
                        # Fallback to transport if PeerManager doesn't have connection
                        await self._transport.send(message, recipient)
                    return

            # Handle mesh protocol messages (for us or broadcast)
            if message.intent == "mesh.announce":
                await self._handle_announcement(message)
            elif message.intent == "mesh.goodbye":
                await self._handle_goodbye(message)
            elif message.intent == "mesh.ping":
                await self._handle_ping(message)
            elif message.intent == "mesh.pong":
                await self._handle_pong(message)
            else:
                # Regular message - dispatch to handlers
                for handler in self._message_handlers:
                    try:
                        result = handler(message)
                        if asyncio.iscoroutine(result):
                            await result
                    except Exception as e:
                        logger.error(f"Message handler error: {e}")

        except Exception as e:
            logger.error(f"Message handling error: {e}")

    async def _handle_announcement(self, message: Message) -> None:
        """Handle peer announcement."""
        content = message.content
        if not isinstance(content, dict):
            return

        node_id = content.get("node_id")
        if not node_id or node_id == self.node_id:
            return

        ws_url = content.get("ws_url")

        async with self._peer_lock:
            is_new = node_id not in self._peers

            # Create or update peer
            peer = MeshNode(
                node_id=node_id,
                entity_type=content.get("entity_type", "unknown"),
                capabilities=content.get("capabilities", []),
                ws_url=ws_url,
                last_seen=time.time(),
                metadata=content.get("metadata", {}),
            )

            # Get transport info if available
            if self._transport:
                transport_type = TransportType.UDP  # Default
                for ttype, t in self._transport._transports.items():
                    if node_id in t.peers:
                        transport_type = ttype
                        break
                peer.transport = transport_type

            self._peers[node_id] = peer

            if is_new:
                logger.info(f"Discovered peer: {node_id} ({peer.entity_type})")

                # Register with PeerManager for persistent connection
                if ws_url and self._peer_manager:
                    await self._peer_manager.add_peer(
                        peer_id=node_id,
                        ws_url=ws_url,
                        entity_type=peer.entity_type,
                        capabilities=peer.capabilities,
                    )
                    logger.info(f"Registered {node_id} with PeerManager: {ws_url}")

                # Notify handlers
                for handler in self._peer_handlers:
                    try:
                        result = handler(peer, "connected")
                        if asyncio.iscoroutine(result):
                            await result
                    except Exception as e:
                        logger.error(f"Peer handler error: {e}")


    async def _handle_goodbye(self, message: Message) -> None:
        """Handle peer leaving."""
        content = message.content
        if not isinstance(content, dict):
            return

        node_id = content.get("node_id")
        if not node_id:
            return

        # Remove from PeerManager
        if self._peer_manager:
            await self._peer_manager.remove_peer(node_id)

        async with self._peer_lock:
            if node_id in self._peers:
                peer = self._peers.pop(node_id)
                logger.info(f"Peer left: {node_id}")

                for handler in self._peer_handlers:
                    try:
                        result = handler(peer, "disconnected")
                        if asyncio.iscoroutine(result):
                            await result
                    except Exception as e:
                        logger.error(f"Peer handler error: {e}")

    async def _handle_ping(self, message: Message) -> None:
        """Handle ping request - send pong back."""
        content = message.content or {}
        ping_id = content.get("ping_id", str(time.time()))

        pong = Message(
            sender_id=self.node_id,
            recipient_id=message.sender_id,
            intent="mesh.pong",
            content={"timestamp": time.time(), "ping_id": ping_id},
        )

        # Try PeerManager first (persistent connection), fall back to transport
        sent = False
        if self._peer_manager:
            sent = await self._peer_manager.send_to_peer(message.sender_id, pong)

        if not sent and self._transport:
            await self._transport.send(pong, message.sender_id)

    async def _handle_pong(self, message: Message) -> None:
        """Handle pong response."""
        # Update peer last_seen
        async with self._peer_lock:
            if message.sender_id in self._peers:
                self._peers[message.sender_id].last_seen = time.time()

        # Complete any pending ping futures
        content = message.content or {}
        ping_id = content.get("ping_id")
        if ping_id and ping_id in self._pending_pings:
            try:
                self._pending_pings[ping_id].set_result(message)
            except asyncio.InvalidStateError:
                pass  # Future already done

        # Forward pong ONLY to local WebSocket clients (so CLI can receive it)
        # Do NOT use broadcast() - that would send to ALL peers causing echo loops
        if self._transport:
            await self._transport.broadcast_to_local_clients(message)

    async def _cleanup_stale_peers(self) -> None:
        """Remove stale peers."""
        async with self._peer_lock:
            stale = [
                node_id for node_id, peer in self._peers.items()
                if time.time() - peer.last_seen > self.config.node_timeout
            ]

            for node_id in stale:
                peer = self._peers.pop(node_id)
                logger.info(f"Peer timed out: {node_id}")

                for handler in self._peer_handlers:
                    try:
                        result = handler(peer, "timeout")
                        if asyncio.iscoroutine(result):
                            await result
                    except Exception as e:
                        logger.error(f"Peer handler error: {e}")

    # =========================================================================
    # Public API
    # =========================================================================

    async def send(
        self,
        recipient_id: str,
        content: Any,
        intent: str = "message",
    ) -> bool:
        """
        Send message to a peer via PeerManager persistent connection.

        Args:
            recipient_id: Target node ID
            content: Message content
            intent: Message intent

        Returns:
            True if sent successfully
        """
        if self.state != NodeState.ONLINE:
            return False

        message = Message(
            sender_id=self.node_id,
            recipient_id=recipient_id,
            intent=intent,
            content=content,
        )

        # Try PeerManager first (persistent connection)
        if self._peer_manager:
            sent = await self._peer_manager.send_to_peer(recipient_id, message)
            if sent:
                return True

        # Fallback to transport
        if self._transport:
            return await self._transport.send(message, recipient_id)

        return False

    async def broadcast(
        self,
        content: Any,
        intent: str = "broadcast",
    ) -> int:
        """
        Broadcast message to all peers.

        Args:
            content: Message content
            intent: Message intent

        Returns:
            Number of peers reached
        """
        if not self._transport or self.state != NodeState.ONLINE:
            return 0

        message = Message(
            sender_id=self.node_id,
            recipient_id="*",
            intent=intent,
            content=content,
        )

        return await self._transport.broadcast(message)

    async def ping(self, node_id: str, timeout: float = 5.0) -> Optional[float]:
        """
        Ping a peer and measure latency using PeerManager.

        Args:
            node_id: Target node ID
            timeout: Timeout in seconds

        Returns:
            Round-trip time in ms, or None if failed
        """
        if node_id not in self._peers:
            return None

        # Use PeerManager for reliable ping (uses persistent connection)
        if self._peer_manager:
            rtt = await self._peer_manager.ping_peer(node_id, timeout=timeout)
            if rtt is not None:
                # Update peer stats
                async with self._peer_lock:
                    if node_id in self._peers:
                        self._peers[node_id].last_rtt = rtt
                        self._peers[node_id].last_seen = time.time()
                return rtt

        # Fallback to transport-based ping with future
        if not self._transport:
            return None

        ping_id = f"{time.time()}-{node_id}"
        start = time.time()

        ping_msg = Message(
            sender_id=self.node_id,
            recipient_id=node_id,
            intent="mesh.ping",
            content={"timestamp": start, "ping_id": ping_id},
        )

        # Create future for pong response
        future = asyncio.get_event_loop().create_future()
        self._pending_pings[ping_id] = future

        try:
            if not await self._transport.send(ping_msg, node_id):
                return None

            # Wait for pong with timeout
            await asyncio.wait_for(future, timeout=timeout)
            rtt = (time.time() - start) * 1000

            # Update peer stats
            async with self._peer_lock:
                if node_id in self._peers:
                    self._peers[node_id].last_rtt = rtt
                    self._peers[node_id].last_seen = time.time()

            return rtt

        except asyncio.TimeoutError:
            return None
        finally:
            self._pending_pings.pop(ping_id, None)

    def get_peers(self) -> List[MeshNode]:
        """Get list of known peers."""
        return list(self._peers.values())

    def _get_peer_list_for_lookup(self) -> List[Dict]:
        """
        Get peer list as dicts for mesh.peers lookup.

        Returns:
            List of peer info dicts with node_id, entity_type, capabilities
        """
        return [
            {
                "node_id": peer.node_id,
                "entity_type": peer.entity_type,
                "capabilities": peer.capabilities,
            }
            for peer in self._peers.values()
        ]

    def get_peer(self, node_id: str) -> Optional[MeshNode]:
        """Get a specific peer."""
        return self._peers.get(node_id)

    def find_by_capability(self, capability: str) -> List[MeshNode]:
        """Find peers with a specific capability."""
        return [
            peer for peer in self._peers.values()
            if capability in peer.capabilities
        ]

    def find_by_type(self, entity_type: str) -> List[MeshNode]:
        """Find peers of a specific type."""
        return [
            peer for peer in self._peers.values()
            if peer.entity_type == entity_type
        ]

    def on_message(self, handler: Callable) -> None:
        """
        Register message handler.

        Args:
            handler: async def handler(message: Message)
        """
        self._message_handlers.append(handler)

    def on_peer(self, handler: Callable) -> None:
        """
        Register peer event handler.

        Args:
            handler: async def handler(peer: MeshNode, event: str)
                     event is "connected", "disconnected", or "timeout"
        """
        self._peer_handlers.append(handler)

    @property
    def peer_count(self) -> int:
        """Number of known peers."""
        return len(self._peers)

    @property
    def is_online(self) -> bool:
        """Check if mesh is online."""
        return self.state == NodeState.ONLINE

    def get_stats(self) -> Dict[str, Any]:
        """Get mesh network statistics."""
        stats = {
            "node_id": self.node_id,
            "state": self.state.value,
            "peer_count": len(self._peers),
            "peers": [
                {
                    "id": p.node_id,
                    "type": p.entity_type,
                    "capabilities": p.capabilities,
                    "transport": p.transport.value,
                    "last_seen": p.last_seen,
                }
                for p in self._peers.values()
            ],
        }

        if self._transport:
            stats["transport_stats"] = self._transport.get_transport_stats()

        return stats
