
from regexapp.main import Cli

console = Cli()
console.run()
