# regigen/__init__.py

from .geometry import RectangleGenerator

__all__ = ["RectangleGenerator"]

# 定义包的版本
__version__ = "0.1.0"