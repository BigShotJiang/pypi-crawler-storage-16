"""File system monitoring for session directories.

Development-mode utility to detect and log all file operations on the sessions
directory. This helps diagnose data loss incidents by providing real-time
visibility into what's happening to session files.

Enable via environment variable: REGISTRY_REVIEW_MONITOR_SESSIONS=true
"""

import logging
import threading
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# Global monitor instance
_monitor: Optional["SessionMonitor"] = None
_monitor_lock = threading.Lock()


class SessionMonitor:
    """Monitors session directory for file system events.

    Uses watchdog library to observe file creates, deletes, and modifications.
    All events are logged with timestamps for forensic analysis.
    """

    def __init__(self, sessions_dir: Path):
        self.sessions_dir = sessions_dir
        self.observer = None
        self._started = False

    def start(self) -> bool:
        """Start monitoring the sessions directory.

        Returns:
            True if monitoring started successfully, False otherwise
        """
        if self._started:
            logger.warning("SESSION MONITOR: Already running")
            return True

        try:
            from watchdog.observers import Observer
            from watchdog.events import FileSystemEventHandler, FileSystemEvent

            class SessionEventHandler(FileSystemEventHandler):
                """Handler that logs all session directory events."""

                def on_created(self, event: FileSystemEvent):
                    event_type = "DIR" if event.is_directory else "FILE"
                    logger.info(
                        f"SESSION MONITOR: CREATED {event_type} - {event.src_path}"
                    )

                def on_deleted(self, event: FileSystemEvent):
                    event_type = "DIR" if event.is_directory else "FILE"
                    logger.warning(
                        f"SESSION MONITOR: DELETED {event_type} - {event.src_path}"
                    )

                def on_modified(self, event: FileSystemEvent):
                    # Only log directory modifications (file modifications are noisy)
                    if event.is_directory:
                        logger.debug(
                            f"SESSION MONITOR: MODIFIED DIR - {event.src_path}"
                        )

                def on_moved(self, event: FileSystemEvent):
                    event_type = "DIR" if event.is_directory else "FILE"
                    logger.warning(
                        f"SESSION MONITOR: MOVED {event_type} - {event.src_path} -> {event.dest_path}"
                    )

            # Ensure directory exists
            self.sessions_dir.mkdir(parents=True, exist_ok=True)

            self.observer = Observer()
            self.observer.schedule(
                SessionEventHandler(),
                str(self.sessions_dir),
                recursive=True
            )
            self.observer.start()
            self._started = True

            logger.info(
                f"SESSION MONITOR: Started watching {self.sessions_dir}"
            )
            return True

        except ImportError:
            logger.warning(
                "SESSION MONITOR: watchdog not installed, monitoring disabled"
            )
            return False
        except Exception as e:
            logger.error(f"SESSION MONITOR: Failed to start - {e}")
            return False

    def stop(self):
        """Stop monitoring."""
        if self.observer and self._started:
            self.observer.stop()
            self.observer.join(timeout=5)
            self._started = False
            logger.info("SESSION MONITOR: Stopped")

    @property
    def is_running(self) -> bool:
        """Check if monitor is currently running."""
        return self._started


def start_session_monitor(sessions_dir: Path) -> bool:
    """Start the global session monitor.

    Args:
        sessions_dir: Path to the sessions directory to monitor

    Returns:
        True if monitoring started, False otherwise
    """
    global _monitor

    with _monitor_lock:
        if _monitor is not None and _monitor.is_running:
            logger.debug("SESSION MONITOR: Already running globally")
            return True

        _monitor = SessionMonitor(sessions_dir)
        return _monitor.start()


def stop_session_monitor():
    """Stop the global session monitor."""
    global _monitor

    with _monitor_lock:
        if _monitor is not None:
            _monitor.stop()
            _monitor = None


def is_monitoring() -> bool:
    """Check if session monitoring is active."""
    with _monitor_lock:
        return _monitor is not None and _monitor.is_running
