"""QRadar integration models for RegScale."""
