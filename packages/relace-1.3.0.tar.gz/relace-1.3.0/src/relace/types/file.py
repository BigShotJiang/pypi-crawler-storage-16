# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["File"]


class File(BaseModel):
    """Text file payload used in create/update requests.

    Attributes:
        filename: Repository-relative path (POSIX). Directories are created as
            needed. Treated as UTF-8 text; binary content should be avoided.
        content: Full in-memory textual content to write.
    """

    content: str

    filename: str
