# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["FileParam"]


class FileParam(TypedDict, total=False):
    """Text file payload used in create/update requests.

    Attributes:
        filename: Repository-relative path (POSIX). Directories are created as
            needed. Treated as UTF-8 text; binary content should be avoided.
        content: Full in-memory textual content to write.
    """

    content: Required[str]

    filename: Required[str]
