# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
from __future__ import annotations

from typing import Any, Optional
from typing_extensions import TypedDict, NotRequired

__all__ = ["RepoAgentResponse"]


class RepoAgentResponse(TypedDict):
    """Response from the repo agent stream."""

    event: NotRequired[Optional[str]]
    data: dict[str, Any]
