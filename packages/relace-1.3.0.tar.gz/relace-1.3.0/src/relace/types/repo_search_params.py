# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Optional
from typing_extensions import Required, Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["RepoSearchParams", "Overrides"]


class RepoSearchParams(TypedDict, total=False):
    agent_inputs: Required[Dict[str, str]]
    """Input parameters for the agent"""

    agent_name: Required[str]
    """Name of the agent to run"""

    continue_: Annotated[bool, PropertyInfo(alias="continue")]
    """Whether to continue from previous chat history"""

    overrides: Optional[Overrides]
    """Optional configuration overrides for agent execution"""


class Overrides(TypedDict, total=False):
    max_tokens: Optional[int]
    """Maximum tokens for model output"""

    max_turns: Optional[int]
    """Maximum number of turns in the conversation"""

    model_name: Optional[str]
    """Model name to use for agent execution"""

    prompt_retries: Optional[int]
    """Number of retries for failed prompts"""

    prompt_timeout: Optional[int]
    """Timeout in seconds for prompt execution"""

    system: Optional[str]
    """System prompt override"""

    tools: Optional[SequenceNotStr[str]]
    """List of tools to enable"""

    user: Optional[str]
    """User prompt override"""
