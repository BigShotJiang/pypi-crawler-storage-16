# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from .._models import BaseModel

__all__ = ["RepoTokenCreateResponse"]


class RepoTokenCreateResponse(BaseModel):
    """Response after successfully creating a repo token."""

    token: str
    """The generated repo token (starts with 'rlcr-')"""

    name: str

    repo_ids: List[str]

    expires_at: Optional[datetime] = None
