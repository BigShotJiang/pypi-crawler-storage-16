# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from .._models import BaseModel

__all__ = ["RepoTokenGetResponse"]


class RepoTokenGetResponse(BaseModel):
    """Response containing repo token metadata."""

    name: str

    repo_ids: List[str]

    expires_at: Optional[datetime] = None
