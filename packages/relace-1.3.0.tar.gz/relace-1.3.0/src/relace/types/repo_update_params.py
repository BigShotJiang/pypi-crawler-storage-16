# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Iterable, Optional
from typing_extensions import Literal, Required, TypeAlias, TypedDict

from .file_param import FileParam

__all__ = [
    "RepoUpdateParams",
    "Source",
    "SourceRepoUpdateFiles",
    "SourceRepoUpdateDiff",
    "SourceRepoUpdateDiffOperation",
    "SourceRepoUpdateDiffOperationFileWriteOperation",
    "SourceRepoUpdateDiffOperationFileDeleteOperation",
    "SourceRepoUpdateDiffOperationFileRenameOperation",
    "SourceRepoUpdateGit",
]


class RepoUpdateParams(TypedDict, total=False):
    metadata: Optional[Dict[str, str]]

    source: Optional[Source]
    """Snapshot-style repository update.

    Treat the provided `files` list as the complete authoritative set of tracked
    text files. Any previously tracked file that is not present in the list will be
    deleted. Each listed file is created or overwritten.

    This mirrors the semantics of replacing the working tree with exactly the
    supplied set (excluding ignored/untracked items). Binary files are skipped
    downstream during embedding.

    Attributes: type: Discriminator literal `"files"`. files: List of files that
    should exist after the operation.
    """


class SourceRepoUpdateFiles(TypedDict, total=False):
    """Snapshot-style repository update.

    Treat the provided ``files`` list as the complete authoritative set of
    tracked text files. Any previously tracked file that is not present in the
    list will be deleted. Each listed file is created or overwritten.

    This mirrors the semantics of replacing the working tree with exactly the
    supplied set (excluding ignored/untracked items). Binary files are skipped
    downstream during embedding.

    Attributes:
        type: Discriminator literal ``"files"``.
        files: List of files that should exist after the operation.
    """

    files: Required[Iterable[FileParam]]

    type: Required[Literal["files"]]


class SourceRepoUpdateDiffOperationFileWriteOperation(TypedDict, total=False):
    """Create or overwrite a file with textual content.

    Used inside a :class:`RepoUpdateDiff`. The final content for a path is the
    value from the last write operation targeting that path within the request
    (operations are aggregated; order is not otherwise significant).

    Attributes:
        type: Discriminator literal ``"write"``.
        filename: Target file path (created if missing; parent dirs auto-created).
        content: UTF-8 text content.
    """

    content: Required[str]

    filename: Required[str]

    type: Required[Literal["write"]]


class SourceRepoUpdateDiffOperationFileDeleteOperation(TypedDict, total=False):
    """Delete a file or (recursively) a directory.

    If the referenced path does not exist the update request fails with 404.

    Attributes:
        type: Discriminator literal ``"delete"``.
        filename: File or directory path to remove.
    """

    filename: Required[str]

    type: Required[Literal["delete"]]


class SourceRepoUpdateDiffOperationFileRenameOperation(TypedDict, total=False):
    """Rename (move) a file.

    Renames are applied after all writes and deletes have been processed to
    avoid transient conflicts. The source path must exist at execution time or
    the request fails with 404. Directory renames are not currently supported
    explicitly (only existing paths that resolve to files are expected).

    Attributes:
        type: Discriminator literal ``"rename"``.
        old_filename: Existing file path.
        new_filename: Destination file path (created parent dirs as needed).
    """

    new_filename: Required[str]

    old_filename: Required[str]

    type: Required[Literal["rename"]]


SourceRepoUpdateDiffOperation: TypeAlias = Union[
    SourceRepoUpdateDiffOperationFileWriteOperation,
    SourceRepoUpdateDiffOperationFileDeleteOperation,
    SourceRepoUpdateDiffOperationFileRenameOperation,
]


class SourceRepoUpdateDiff(TypedDict, total=False):
    """Explicit patch consisting of write/delete/rename operations.

    Operations are collected and then applied in three phases: deletes, writes,
    renames. Within a single request duplicate operations targeting the same
    path are not currently validated; the *last* write wins for a file, and the
    final mapping for each rename source path is used. Future improvements may
    add canonicalisation/validation.

    Attributes:
        type: Discriminator literal ``"diff"``.
        operations: Heterogeneous list of file operations (see individual
            operation model docstrings for semantics).
    """

    operations: Required[Iterable[SourceRepoUpdateDiffOperation]]

    type: Required[Literal["diff"]]


class SourceRepoUpdateGit(TypedDict, total=False):
    type: Required[Literal["git"]]

    url: Required[str]

    branch: Optional[str]


Source: TypeAlias = Union[SourceRepoUpdateFiles, SourceRepoUpdateDiff, SourceRepoUpdateGit]
