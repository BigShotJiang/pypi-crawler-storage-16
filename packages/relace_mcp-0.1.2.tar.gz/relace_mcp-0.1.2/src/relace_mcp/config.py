import logging
import os
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)

RELACE_ENDPOINT = "https://instantapply.endpoint.relace.run/v1/code/apply"
RELACE_MODEL = "relace-apply-3"
TIMEOUT_SECONDS = 60.0
MAX_RETRIES = 3
RETRY_BASE_DELAY = 1.0

LOG_DIR = Path(os.environ.get("XDG_STATE_HOME", os.path.expanduser("~/.local/state"))) / "relace"
LOG_PATH = LOG_DIR / "relace_apply.log"
MAX_LOG_SIZE_BYTES = 10 * 1024 * 1024


@dataclass(frozen=True)
class RelaceConfig:
    api_key: str
    base_dir: str

    @classmethod
    def from_env(cls) -> "RelaceConfig":
        api_key = os.getenv("RELACE_API_KEY")
        if not api_key:
            raise RuntimeError("RELACE_API_KEY is not set. Please export it in your environment.")

        base_dir = os.getenv("RELACE_BASE_DIR")
        if base_dir:
            base_dir = os.path.abspath(base_dir)
        else:
            base_dir = os.getcwd()
            logger.warning(
                "RELACE_BASE_DIR not set. Defaulting to current directory: %s. "
                "For production, explicitly set RELACE_BASE_DIR to restrict file access.",
                base_dir,
            )

        if not os.path.isdir(base_dir):
            raise RuntimeError(f"RELACE_BASE_DIR does not exist or is not a directory: {base_dir}")

        return cls(api_key=api_key, base_dir=base_dir)
