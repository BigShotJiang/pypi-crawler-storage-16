# relace-mcp-server

Official Relace MCP server.

Currently supports [Fast Agentic Search](https://www.relace.ai/blog/fast-agentic-search) via the `relace_search` tool.
