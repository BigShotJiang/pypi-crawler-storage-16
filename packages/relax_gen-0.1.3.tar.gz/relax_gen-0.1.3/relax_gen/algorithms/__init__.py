# __init__.py dentro de algoritmos/
from .alg_bin import cl_alg_stn_bin
from .alg_quantum import cl_alg_quantum

__all__ = ["cl_alg_stn_bin", "cl_alg_quantum"]
