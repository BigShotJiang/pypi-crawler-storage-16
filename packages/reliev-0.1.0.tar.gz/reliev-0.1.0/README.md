# Reliev 

Complementary store library for [observ](https://github.com/fork-tongue/observ). Provides undo/redo functionality.

Leverages [patchdiff](https://github.com/fork-tongue/patchdiff) for constructing patches to apply to state for undo/redo.
