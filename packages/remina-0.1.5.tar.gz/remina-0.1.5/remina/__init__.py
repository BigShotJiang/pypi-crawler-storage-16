"""
Remina - A pluggable memory framework for AI applications.
"""

import importlib.metadata

__version__ = "0.1.0"

from remina.memory.main import Memory, AsyncMemory
from remina.exceptions import (
    ReminaError,
    StorageError,
    VectorStoreError,
    EmbeddingError,
    LLMError,
    CacheError,
    ConfigurationError,
)

__all__ = [
    "Memory",
    "AsyncMemory",
    "ReminaError",
    "StorageError",
    "VectorStoreError",
    "EmbeddingError",
    "LLMError",
    "CacheError",
    "ConfigurationError",
]
