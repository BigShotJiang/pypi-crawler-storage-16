"""Storage providers for Remina."""

from remina.storage.base import StorageBase

__all__ = ["StorageBase"]
