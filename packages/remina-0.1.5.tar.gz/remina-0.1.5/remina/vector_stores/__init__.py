"""Vector store providers for Remina."""

from remina.vector_stores.base import VectorStoreBase

__all__ = ["VectorStoreBase"]
