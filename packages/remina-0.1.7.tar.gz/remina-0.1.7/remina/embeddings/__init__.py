"""Embedding providers for Remina."""

from remina.embeddings.base import EmbeddingBase

__all__ = ["EmbeddingBase"]
