.. render-python documentation master file, created by
   sphinx-quickstart on Sat Jul 22 11:57:57 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to render-python's documentation!
=========================================
    


.. toctree::
   :maxdepth: 2
   :caption: Contents:

API
---

.. toctree::
   :maxdepth: 3

   guide/index
   guide/pointmatchassumptions
   api/renderapi
 

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
