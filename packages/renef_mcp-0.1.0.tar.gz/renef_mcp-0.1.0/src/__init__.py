# MCP Server Package

__version__ = "0.1.0"
__author__ = "Byteria"
__description__ = "MCP server for Renef - Dynamic Instrumentation Toolkit for Android ARM64"
