# -------------------------------------------------------------------------------
# |
# |  Copyright (c) 2024 Scientific Software Engineering Center at Georgia Tech
# |  Distributed under the MIT License.
# |
# -------------------------------------------------------------------------------
"""Unit tests for Plugin.py"""

from RepoAuditor.Plugin import *


# ----------------------------------------------------------------------
def test_Placeholder():
    # There isn't really anything to test here, but create a placeholder test so that pytest doesn't complain
    assert True
