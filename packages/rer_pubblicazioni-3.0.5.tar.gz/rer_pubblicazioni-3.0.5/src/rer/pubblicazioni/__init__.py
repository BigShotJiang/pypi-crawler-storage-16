# -*- coding: utf-8 -*-
"""Init and utils."""
from zope.i18nmessageid import MessageFactory
import logging


_ = MessageFactory('rer.pubblicazioni')

logger = logging.getLogger("rer.pubblicazioni")
