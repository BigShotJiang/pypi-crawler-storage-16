"""
This module implements the read and write
functionality for formatted res files (see
        :ref:`formatted-format`) and is
not part of the resfo public API.
"""
