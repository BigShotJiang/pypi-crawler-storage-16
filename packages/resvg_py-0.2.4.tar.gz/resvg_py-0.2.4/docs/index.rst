.. resvg_py documentation master file, created by
   sphinx-quickstart on Sat Feb 24 21:13:02 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to resvg_py's documentation!
========================================

Safe bindings for `resvg`_

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installation
   usage
   resvg
   debugging
   contributing

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`


.. _resvg: https://docs.rs/resvg/latest/resvg/