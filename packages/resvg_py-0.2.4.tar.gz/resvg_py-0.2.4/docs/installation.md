# Installation

## Requirements

Python 3.8 to 3.12 supported.

<sub>Currently it builds the non-EOL python versions with `maturin`\_ github-actions.</sub>

## Installation

1. Install with **pip**:

    ```python
    python -m pip install resvg_py
    ```
