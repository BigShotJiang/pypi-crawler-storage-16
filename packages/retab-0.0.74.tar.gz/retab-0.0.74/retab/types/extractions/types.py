from typing import Literal

type HumanReviewStatus = Literal["success", "review_required", "reviewed"]