"""Tests for retrocast schema representations."""
