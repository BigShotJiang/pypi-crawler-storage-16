"""
Canonicalization version constant.
"""

CANONICALIZATION_VERSION = "v1"
