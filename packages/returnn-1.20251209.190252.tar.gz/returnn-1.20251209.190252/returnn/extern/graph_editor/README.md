# TensorFlow Graph Editor

The TensorFlow Graph Editor library allows for modification of an existing
tf.Graph instance in-place.

The author's github username is [purpledog](https://github.com/purpledog).

Copied to RETURNN since this was removed in TF 2.
