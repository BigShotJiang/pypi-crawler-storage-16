"""
Everything dataset related, such as:

* the whole pipeline
* batching/chunking logic
* wrappers for RETURNN datasets
* etc.
"""
