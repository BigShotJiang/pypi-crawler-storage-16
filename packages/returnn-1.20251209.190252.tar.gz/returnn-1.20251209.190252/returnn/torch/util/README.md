Common functions for PyTorch on tensors,
which either extend PyTorch,
or replicate existing or similar PyTorch functions
but extending them by dimension tag logic.

This is still experimental.
