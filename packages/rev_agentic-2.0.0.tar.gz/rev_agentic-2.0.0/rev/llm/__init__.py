#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""LLM (Language Model) client for rev."""

from .client import ollama_chat

__all__ = [
    "ollama_chat",
]
