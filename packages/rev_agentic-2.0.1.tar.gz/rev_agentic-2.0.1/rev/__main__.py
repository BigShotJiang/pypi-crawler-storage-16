#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Entry point for rev package when run as python -m rev."""

from .main import main

if __name__ == "__main__":
    main()
