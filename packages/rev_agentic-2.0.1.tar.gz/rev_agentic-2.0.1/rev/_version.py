"""Centralized version constant for rev."""

REV_VERSION = "2.0.1"

__all__ = ["REV_VERSION"]
