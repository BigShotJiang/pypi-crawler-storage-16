# FunctionSourceType


## Enum

* `SYSTEM` (value: `'SYSTEM'`)

* `USER` (value: `'USER'`)

* `EXTERNAL` (value: `'EXTERNAL'`)

* `AUTO_UNSTRIP` (value: `'AUTO_UNSTRIP'`)

* `AI_UNSTRIP` (value: `'AI_UNSTRIP'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


