# FunctionTaskStatus


## Enum

* `UNINITIALISED` (value: `'UNINITIALISED'`)

* `PENDING` (value: `'PENDING'`)

* `RUNNING` (value: `'RUNNING'`)

* `COMPLETED` (value: `'COMPLETED'`)

* `FAILED` (value: `'FAILED'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


