#!/bin/bash
python -m nuitka --module defaultPDK --include-package=defaultPDK --output-dir=$HOME/dist/defaultPDK
