import numpy as np
import matplotlib.pyplot as plt
from scipy.spatial import ConvexHull
from scipy.ndimage import gaussian_filter
from numba import jit, prange
import time

# ============================================================================
# 1. Fast Analytic Collision Math (Ray-Circle Intersection)
# ============================================================================

@jit(nopython=True, cache=True)
def find_contact_distance(start_x, start_y, dir_x, dir_y, 
                          existing_data, n_existing, 
                          radius_new, gap_min):
    """
    Calculates the exact distance 't' a stone travels from (start_x, start_y)
    along vector (dir_x, dir_y) before hitting any existing stone.
    
    existing_data: Array of [x, y, radius] for placed stones.
    """
    min_t = 1e20  # Infinity
    hit_found = False

    # Check against every existing stone
    for i in range(n_existing):
        ex, ey, e_rad = existing_data[i, 0], existing_data[i, 1], existing_data[i, 2]
        
        # Vector from Existing center to Start position
        dx = start_x - ex
        dy = start_y - ey
        
        # Quadratic Equation: t^2 + 2*t*(D . V) + (|D|^2 - (R_sum)^2) = 0
        # where D is difference vector, V is direction vector
        
        # We are solving for when distance between centers == sum of radii
        target_dist = radius_new + e_rad + gap_min
        
        # Coefficients
        # a = 1 (since direction vector is normalized)
        b = 2.0 * (dx * dir_x + dy * dir_y)
        c = (dx*dx + dy*dy) - (target_dist * target_dist)
        
        delta = b*b - 4.0*c
        
        if delta >= 0:
            # We have a potential intersection
            sqrt_delta = np.sqrt(delta)
            
            # We want the smallest positive t (first contact)
            # The solutions are (-b ± sqrt(delta)) / 2
            
            t1 = (-b - sqrt_delta) / 2.0
            t2 = (-b + sqrt_delta) / 2.0
            
            # Since we start "far away" and move IN, we expect to hit the "outside" of the circle first.
            # Usually t1 is the entry point, t2 is the exit point.
            
            if t1 >= 0:
                if t1 < min_t:
                    min_t = t1
                    hit_found = True
            elif t2 >= 0:
                if t2 < min_t:
                    min_t = t2
                    hit_found = True
                    
    return min_t, hit_found

# ============================================================================
# 2. Mesh Generation (Fixed Orientation: Flat side up)
# ============================================================================

def generate_aggregate_mesh(center, size, axis_ratio, irregularity, n_control_points, rng):
    # 1. Enforce Orientation (Smallest Axis = Z)
    sorted_axes = np.sort(np.array(axis_ratio, dtype=float))
    # Forces Z (index 2 in output) to be the smallest dimension
    # axis_ratio input mapped to -> [Large, Large, Small]
    ar = np.array([sorted_axes[2], sorted_axes[1], sorted_axes[0]])
    ar = ar / np.max(ar) * (size / 2.0)
    
    # 2. Generate Control Points
    u = rng.uniform(0, 1, n_control_points)
    v = rng.uniform(0, 1, n_control_points)
    theta = 2 * np.pi * u
    phi = np.arccos(2 * v - 1)
    
    x = np.sin(phi) * np.cos(theta)
    y = np.sin(phi) * np.sin(theta)
    z = np.cos(phi)
    
    points = np.stack([x, y, z], axis=1)
    
    # 3. Scale
    points[:, 0] *= ar[0]
    points[:, 1] *= ar[1]
    points[:, 2] *= ar[2]
    
    # 4. Irregularity
    noise = rng.uniform(1.0 - irregularity, 1.0 + irregularity, (n_control_points, 1))
    points *= noise
    
    # 5. Rotate Z (Yaw only)
    angle = rng.uniform(0, 2*np.pi)
    c, s = np.cos(angle), np.sin(angle)
    # Manual rotation to keep Z coordinate EXACTLY as generated (flat)
    px = points[:, 0] * c - points[:, 1] * s
    py = points[:, 0] * s + points[:, 1] * c
    points[:, 0] = px
    points[:, 1] = py
    
    # 6. Hull
    hull = ConvexHull(points)
    vertices = points + center
    faces = hull.simplices
    
    return vertices, faces

# ============================================================================
# 3. Ballistic Aggregation Logic
# ============================================================================

def ballistic_aggregation(Lx, Ly, n_aggregates, mean_size, size_std, 
                          axis_ratio, irregularity, gap_min, n_control_points, seed):
    
    rng = np.random.default_rng(seed)
    
    # Pre-allocate array for fast numba access: [x, y, radius]
    existing_data = np.zeros((n_aggregates, 3), dtype=np.float64)
    placed_count = 0
    aggregates = []
    
    print(f"Starting Ballistic Aggregation for {n_aggregates} stones...")
    
    # 1. Place First Stone in Center
    c_size = rng.normal(mean_size, size_std)
    # Z-axis is smallest, so radius is determined by the larger axes (index 0 or 1 of sorted)
    # axis_ratio approx (2, 2, 1) -> Radius ~ size/2
    radius = (c_size / 2.0)
    
    # Place at center of domain
    cx, cy = Lx / 2.0, Ly / 2.0
    cz = rng.uniform(-c_size*0.1, c_size*0.1) # Slight Z variation
    
    verts, faces = generate_aggregate_mesh(np.array([cx, cy, cz]), c_size, 
                                          axis_ratio, irregularity, n_control_points, rng)
    
    aggregates.append({'vertices': verts, 'faces': faces})
    existing_data[0] = [cx, cy, radius]
    placed_count = 1
    
    # Track the "bounding radius" of the entire cluster to spawn new stones efficiently
    current_cluster_radius = radius
    
    # 2. Loop for remaining stones
    for i in range(1, n_aggregates):
        size = max(mean_size * 0.2, rng.normal(mean_size, size_std))
        r_new = size / 2.0
        
        # Spawn "far away"
        # We spawn on a circle slightly larger than the current cluster
        spawn_dist = current_cluster_radius + r_new + mean_size * 2.0
        angle = rng.uniform(0, 2 * np.pi)
        
        start_x = Lx/2.0 + np.cos(angle) * spawn_dist
        start_y = Ly/2.0 + np.sin(angle) * spawn_dist
        
        # Direction: Towards Center
        # Normalized vector pointing to (Lx/2, Ly/2)
        dir_x = (Lx/2.0) - start_x
        dir_y = (Ly/2.0) - start_y
        dist_to_center = np.sqrt(dir_x**2 + dir_y**2)
        dir_x /= dist_to_center
        dir_y /= dist_to_center
        
        # Analytically find collision
        t, hit = find_contact_distance(start_x, start_y, dir_x, dir_y, 
                                       existing_data, placed_count, 
                                       r_new, gap_min)
        
        final_x, final_y = 0.0, 0.0
        
        if hit:
            # Move exactly to contact point
            final_x = start_x + t * dir_x
            final_y = start_y + t * dir_y
        else:
            # If it somehow missed everything (rare with center aiming), 
            # place it right next to center or skip
            final_x = Lx/2.0 + dir_x * (r_new + gap_min)
            final_y = Ly/2.0 + dir_y * (r_new + gap_min)

        # Generate Mesh
        z_pos = rng.uniform(-size*0.1, size*0.1)
        verts, faces = generate_aggregate_mesh(np.array([final_x, final_y, z_pos]), size, 
                                              axis_ratio, irregularity, n_control_points, rng)
        
        aggregates.append({'vertices': verts, 'faces': faces})
        existing_data[placed_count] = [final_x, final_y, r_new]
        placed_count += 1
        
        # Update cluster size tracking
        dist_from_origin = np.sqrt((final_x - Lx/2)**2 + (final_y - Ly/2)**2)
        if dist_from_origin + r_new > current_cluster_radius:
            current_cluster_radius = dist_from_origin + r_new
            
        if i % 100 == 0:
            print(f"  Placed {i}/{n_aggregates}")

    return aggregates

# ============================================================================
# 4. Rendering (Z-Buffer)
# ============================================================================

@jit(nopython=True, cache=True)
def barycentric(px, py, v0, v1, v2):
    denom = (v1[1] - v2[1]) * (v0[0] - v2[0]) + (v2[0] - v1[0]) * (v0[1] - v2[1])
    if abs(denom) < 1e-10: return -1, -1, -1
    w0 = ((v1[1] - v2[1]) * (px - v2[0]) + (v2[0] - v1[0]) * (py - v2[1])) / denom
    w1 = ((v2[1] - v0[1]) * (px - v2[0]) + (v0[0] - v2[0]) * (py - v2[1])) / denom
    return w0, w1, 1.0 - w0 - w1

@jit(nopython=True, parallel=True, cache=True)
def render(vertices, faces, Lx, Ly, Nx, Ny):
    Z = np.full((Ny, Nx), -10.0)
    dx, dy = Lx/Nx, Ly/Ny
    
    for i in prange(len(faces)):
        f = faces[i]
        v0, v1, v2 = vertices[f[0]], vertices[f[1]], vertices[f[2]]
        
        min_x = max(0, int(min(v0[0], v1[0], v2[0]) / dx))
        max_x = min(Nx-1, int(max(v0[0], v1[0], v2[0]) / dx) + 1)
        min_y = max(0, int(min(v0[1], v1[1], v2[1]) / dy))
        max_y = min(Ny-1, int(max(v0[1], v1[1], v2[1]) / dy) + 1)
        
        for iy in range(min_y, max_y + 1):
            py = (iy + 0.5) * dy
            for ix in range(min_x, max_x + 1):
                px = (ix + 0.5) * dx
                w0, w1, w2 = barycentric(px, py, v0, v1, v2)
                if w0 >= 0 and w1 >= 0 and w2 >= 0:
                    z = w0*v0[2] + w1*v1[2] + w2*v2[2]
                    if z > Z[iy, ix]: Z[iy, ix] = z
    return Z

def main():
    # Parameters
    Lx, Ly = 20.0, 20.0
    Nx, Ny = 1024, 1024
    
    # Asphalt Config
    n_aggregates = 600
    mean_size = 0.9
    size_std = 0.3
    # 1:2:2 ratio means Flat stones. 
    # Logic forces smallest axis to Z.
    axis_ratio = (1, 2, 2) 
    irregularity = 0.2
    n_control_points = 20
    gap_min = 0.00
    
    # Run
    t0 = time.time()
    aggregates = ballistic_aggregation(Lx, Ly, n_aggregates, mean_size, size_std, 
                                       axis_ratio, irregularity, gap_min, n_control_points, seed=42)
    
    # Prepare Render
    all_verts = []
    all_faces = []
    offset = 0
    for agg in aggregates:
        all_verts.append(agg['vertices'])
        all_faces.append(agg['faces'] + offset)
        offset += len(agg['vertices'])
        
    V = np.vstack(all_verts)
    F = np.vstack(all_faces)
    
    t1 = time.time()
    print(f"Aggregation done in {t1-t0:.2f}s")
    
    Z = render(V, F, Lx, Ly, Nx, Ny)
    Z = np.maximum(Z, -mean_size*0.5) # Binder floor
    Z = gaussian_filter(Z, sigma=2.0) # Smoothing
    
    print(f"Render done in {time.time()-t1:.2f}s")
    
    plt.figure(figsize=(10, 10))
    plt.imshow(Z, cmap='gray', origin='lower', extent=[0, Lx, 0, Ly])
    plt.title("Asphalt Surface (Ballistic Aggregation)")
    plt.show()

if __name__ == "__main__":
    main()