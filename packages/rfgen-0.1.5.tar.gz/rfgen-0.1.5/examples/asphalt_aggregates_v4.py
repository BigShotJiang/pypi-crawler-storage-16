import numpy as np
import matplotlib.pyplot as plt
from scipy.spatial import ConvexHull
from scipy.ndimage import gaussian_filter
from numba import jit, prange
import time
from rfgen import selfaffine_field

# ============================================================================
# 1. Spatial Grid for O(1) Collision
# ============================================================================

class SpatialGrid:
    def __init__(self, width, height, cell_size):
        self.cell_size = cell_size
        self.cols = int(np.ceil(width / cell_size))
        self.rows = int(np.ceil(height / cell_size))
        # grid stores: list of (x, y, radius)
        self.grid = [[] for _ in range(self.cols * self.rows)]
        self.width = width
        self.height = height

    def _get_idx(self, r, c):
        return (r % self.rows) * self.cols + (c % self.cols)

    def insert(self, x, y, radius):
        c = int(x // self.cell_size)
        r = int(y // self.cell_size)
        idx = self._get_idx(r, c)
        self.grid[idx].append((x, y, radius))

    def check_collision(self, x, y, radius, min_gap):
        # Check 3x3 neighbor cells
        search_r = radius + min_gap
        
        c0 = int((x - search_r) // self.cell_size)
        c1 = int((x + search_r) // self.cell_size)
        r0 = int((y - search_r) // self.cell_size)
        r1 = int((y + search_r) // self.cell_size)

        for r in range(r0, r1 + 1):
            for c in range(c0, c1 + 1):
                idx = self._get_idx(r, c)
                for (ox, oy, orad) in self.grid[idx]:
                    dx = abs(x - ox)
                    dy = abs(y - oy)
                    
                    # Periodic wrap for distance check
                    if dx > self.width * 0.5: dx = self.width - dx
                    if dy > self.height * 0.5: dy = self.height - dy
                    
                    if dx*dx + dy*dy < (radius + orad + min_gap)**2:
                        return True
        return False

# ============================================================================
# 2. Mesh Generator (1:2:2 Flattened, Vertical Z)
# ============================================================================

def generate_aggregate_mesh(center, size, axis_ratio, irregularity, n_points, rng):
    # Enforce Smallest Axis = Z
    # Sort axes: [Small, Medium, Large]
    sorted_ax = np.sort(np.array(axis_ratio, dtype=float))
    # Map to: X=Large, Y=Large, Z=Small (Flat pancake)
    # Note: axis_ratio input e.g. (1,2,2) -> sorted (1,2,2). 
    # We want Z to be 1. X,Y to be 2.
    scale_x = sorted_ax[2]
    scale_y = sorted_ax[1]
    scale_z = sorted_ax[0]
    
    # Normalize so the largest dimension matches 'size'
    max_s = max(scale_x, scale_y, scale_z)
    sx, sy, sz = (scale_x/max_s)*size, (scale_y/max_s)*size, (scale_z/max_s)*size

    # Generate points
    u = rng.uniform(0, 1, n_points)
    v = rng.uniform(0, 1, n_points)
    theta = 2 * np.pi * u
    phi = np.arccos(2 * v - 1)
    
    pts = np.stack([
        np.sin(phi) * np.cos(theta) * sx/2,
        np.sin(phi) * np.sin(theta) * sy/2,
        np.cos(phi) * sz/2
    ], axis=1)

    # Irregularity
    noise = rng.uniform(1.0 - irregularity, 1.0 + irregularity, (n_points, 1))
    pts *= noise

    # Rotate around Z only (Yaw)
    ang = rng.uniform(0, 2*np.pi)
    c, s = np.cos(ang), np.sin(ang)
    x_new = pts[:, 0] * c - pts[:, 1] * s
    y_new = pts[:, 0] * s + pts[:, 1] * c
    pts[:, 0] = x_new
    pts[:, 1] = y_new

    # Hull
    hull = ConvexHull(pts)
    return pts + center, hull.simplices

# ============================================================================
# 3. Dense Packing Logic (Sorted RSA)
# ============================================================================

def pack_dense(Lx, Ly, n_coarse, n_fine, 
               size_coarse, size_fine, 
               axis_ratio, irregularity, gap_min, seed):
    
    rng = np.random.default_rng(seed)
    
    # Create size distribution: Big stones first!
    # We mix two populations: Coarse aggregate and Fine aggregate
    sizes_c = rng.normal(size_coarse, size_coarse*0.2, n_coarse)
    sizes_f = rng.normal(size_fine, size_fine*0.2, n_fine)
    
    # Concatenate and SORT DESCENDING
    all_sizes = np.concatenate([sizes_c, sizes_f])
    all_sizes = np.sort(all_sizes)[::-1]
    
    grid = SpatialGrid(Lx, Ly, cell_size=size_coarse)
    aggregates = []
    
    print(f"Packing {len(all_sizes)} stones (Sorted Large -> Small)...")
    
    for i, size in enumerate(all_sizes):
        # Radius for collision (XY plane)
        # Since Z is smallest, radius is approx size/2
        rad = size / 2.0
        
        placed = False
        # Try harder for smaller stones to find cracks
        attempts = 100 if i < n_coarse else 500 
        
        for _ in range(attempts):
            rx = rng.uniform(0, Lx)
            ry = rng.uniform(0, Ly)
            
            if not grid.check_collision(rx, ry, rad, gap_min):
                # Success
                rz = rng.uniform(-size*0.05, size*0.05) # Embed slightly
                
                # Use fewer points for tiny stones to save render time
                n_pts = 20 if size > size_coarse*0.8 else 12
                
                v, f = generate_aggregate_mesh(
                    np.array([rx, ry, rz]), size, axis_ratio, irregularity, n_pts, rng
                )
                
                aggregates.append({'vertices': v, 'faces': f})
                grid.insert(rx, ry, rad)
                placed = True
                break
                
    print(f"Placed {len(aggregates)} / {len(all_sizes)} stones.")
    return aggregates

# ============================================================================
# 4. Renderer
# ============================================================================

@jit(nopython=True, cache=True)
def barycentric(px, py, v0, v1, v2):
    denom = (v1[1] - v2[1]) * (v0[0] - v2[0]) + (v2[0] - v1[0]) * (v0[1] - v2[1])
    if abs(denom) < 1e-10: return -1, -1, -1
    w0 = ((v1[1] - v2[1]) * (px - v2[0]) + (v2[0] - v1[0]) * (py - v2[1])) / denom
    w1 = ((v2[1] - v0[1]) * (px - v2[0]) + (v0[0] - v2[0]) * (py - v2[1])) / denom
    return w0, w1, 1.0 - w0 - w1

@jit(nopython=True, parallel=True, cache=True)
def render(vertices, faces, Lx, Ly, Nx, Ny, floor_height):
    # Initialize with binder floor height
    Z = np.full((Ny, Nx), floor_height)
    dx, dy = Lx/Nx, Ly/Ny
    
    for i in prange(len(faces)):
        f = faces[i]
        v0, v1, v2 = vertices[f[0]], vertices[f[1]], vertices[f[2]]
        
        min_x = max(0, int(min(v0[0], v1[0], v2[0]) / dx))
        max_x = min(Nx-1, int(max(v0[0], v1[0], v2[0]) / dx) + 1)
        min_y = max(0, int(min(v0[1], v1[1], v2[1]) / dy))
        max_y = min(Ny-1, int(max(v0[1], v1[1], v2[1]) / dy) + 1)
        
        for iy in range(min_y, max_y + 1):
            py = (iy + 0.5) * dy
            for ix in range(min_x, max_x + 1):
                px = (ix + 0.5) * dx
                w0, w1, w2 = barycentric(px, py, v0, v1, v2)
                if w0 >= 0 and w1 >= 0 and w2 >= 0:
                    z = w0*v0[2] + w1*v1[2] + w2*v2[2]
                    if z > Z[iy, ix]: Z[iy, ix] = z
    return Z

def main():
    Lx, Ly = 20.0, 20.0
    Nx, Ny = 1024, 1024
    
    # Asphalt Mix Design (Fuller's Curve approximation)
    # Lots of small stones to fill gaps between big ones
    n_coarse = 250
    size_coarse = 1.2
    
    n_fine = 200
    size_fine = 0.8
    
    gap_min = 0.02 # Tight packing
    axis_ratio = (1, 2, 2)
    
    t0 = time.time()
    
    aggregates = pack_dense(
        Lx, Ly, n_coarse, n_fine, size_coarse, size_fine, 
        axis_ratio, 0.25, gap_min, seed=42
    )
    
    # Flatten buffers
    all_v = []
    all_f = []
    offset = 0
    for agg in aggregates:
        all_v.append(agg['vertices'])
        all_f.append(agg['faces'] + offset)
        offset += len(agg['vertices'])
        
    V = np.vstack(all_v)
    F = np.vstack(all_f)
    
    print("Rendering...")
    # floor_height: The height of the "binder" (tar). 
    # Set slightly below the average stone center (0.0)
    Z = render(V, F, Lx, Ly, Nx, Ny, floor_height=-0.15)

    # Add self-affine roughness
    rng = np.random.default_rng(42)
    rms_roughness = 0.05
    roughness = selfaffine_field(
        dim=2, N=max(Nx, Ny), Hurst=0.8, k_low=0.03, k_high=0.3, rng=rng
    )
    roughness *= rms_roughness / np.std(roughness)
    Z += roughness
    
    # Smooth slightly to simulate bitumen meniscus
    Z = gaussian_filter(Z, sigma=1.0)
    
    print(f"Done in {time.time()-t0:.2f}s")
    
    plt.figure(figsize=(10, 10))
    # Use 'gray' but clip the range to visualize surface texture better
    plt.imshow(Z, cmap='gray', origin='lower', extent=[0, Lx, 0, Ly], vmin=-0.5, vmax=0.5)
    plt.title(f"Dense Asphalt Surface ({len(aggregates)} stones)")
    plt.show()

if __name__ == "__main__":
    main()