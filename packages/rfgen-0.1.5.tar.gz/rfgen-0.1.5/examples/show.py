import numpy as np
import matplotlib.pyplot as plt

# Generate a random field
npz_file = np.load('asphalt_heightmap_raw.npz')
#     np.savez(npz_path_raw, X=X, Y=Y, Z=Z, Lx=Lx, Ly=Ly, Nx=Nx, Ny=Ny)
X = npz_file['X']
Y = npz_file['Y']
Z = npz_file['Z']
Lx = npz_file['Lx']
Ly = npz_file['Ly']
Nx = npz_file['Nx']
Ny = npz_file['Ny']

# Plot the field in 3D with high resolution
fig = plt.figure(figsize=(12, 10))
ax = fig.add_subplot(111, projection='3d')

# Use stride to control resolution (smaller = finer, 1 = full resolution)
# For 1024x1024 grid, stride=2-4 gives good balance of quality and speed
stride = max(1, int(Nx) // 256)  # Aim for ~256 points per axis
print(f"Grid: {Nx}x{Ny}, using stride={stride}")

ax.plot_surface(X[::stride, ::stride], Y[::stride, ::stride], Z[::stride, ::stride], 
                cmap='terrain', linewidth=0, antialiased=True, 
                rstride=1, cstride=1)  # rstride/cstride=1 for no additional skipping
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')
ax.set_title('Asphalt Heightmap')
plt.tight_layout()
plt.show()