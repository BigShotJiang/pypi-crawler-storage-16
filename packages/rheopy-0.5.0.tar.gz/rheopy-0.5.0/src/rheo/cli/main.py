from .app import create_cli_app

app = create_cli_app()


if __name__ == "__main__":
    app()
