"""CLI utility functions."""

# Currently empty - utilities will be added as needed
