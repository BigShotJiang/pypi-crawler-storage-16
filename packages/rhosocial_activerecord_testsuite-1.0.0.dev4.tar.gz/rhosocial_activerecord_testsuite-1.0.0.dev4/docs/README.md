# rhosocial ActiveRecord Test Suite Documentation / rhosocial ActiveRecord 测试套件文档

Welcome to the rhosocial ActiveRecord Test Suite documentation! / 欢迎使用 rhosocial ActiveRecord 测试套件文档！

## Available Languages / 可用语言

- [English](en_US/README.md)
- [中文](zh_CN/README.md)