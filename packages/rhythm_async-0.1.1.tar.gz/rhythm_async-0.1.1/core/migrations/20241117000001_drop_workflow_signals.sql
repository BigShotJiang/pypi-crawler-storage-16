-- Drop workflow_signals table (feature removed, will be reimplemented in v2)

DROP TABLE IF EXISTS workflow_signals;
