-- Drop worker_heartbeats table (feature removed for simplicity)

DROP TABLE IF EXISTS worker_heartbeats;
