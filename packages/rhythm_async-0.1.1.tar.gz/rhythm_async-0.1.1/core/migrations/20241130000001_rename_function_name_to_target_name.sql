-- Rename function_name column to target_name in executions table
ALTER TABLE executions RENAME COLUMN function_name TO target_name;
