"""Top-level package for RiboMetric."""

__author__ = """Jack Tierney"""
__email__ = "jackcurragh@gmail.com"
__version__ = "0.1.0"
