from ..core.style import style

_TEMPLATE = "\033[3m{}\033[23m"
italic = style(_TEMPLATE)