from ..core.style import style

_TEMPLATE = "\033[4m{}\033[24m"
underline = style(_TEMPLATE)