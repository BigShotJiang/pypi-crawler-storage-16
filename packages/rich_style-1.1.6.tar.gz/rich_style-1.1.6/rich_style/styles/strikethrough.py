from ..core.style import style

_TEMPLATE = "\033[9m{}\033[29m"
strikethrough = style(_TEMPLATE)