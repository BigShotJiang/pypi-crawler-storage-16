
def greet_user():
    user_name = input("Please enter your name: ")
    print(f"Hello {user_name} how is your day going?")