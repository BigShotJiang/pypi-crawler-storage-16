all = [ '__version__', 'config.py', 'rkauth_client.py', 'rkauth_flask.py', 'rkauth_webpy.py', 'rkwebutil.py' ]

from rkwebutil._version import __version__ as __version__
