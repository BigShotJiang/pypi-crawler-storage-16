"""Tests for command modules."""
