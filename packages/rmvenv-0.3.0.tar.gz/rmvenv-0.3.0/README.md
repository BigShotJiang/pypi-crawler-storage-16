# rmvenv

Command line app to list and delete build environments. This only leaves
your source code and files to rebuild the environment, so they can be
easily backed up.

This software can identify build environments of multiple languages
directory, as well as Java's `.class` files. If deleted, this
can save gigabytes of space, and they can be easily recreated and the
packages re-downloaded and compiled when the code needs to run again. This
software can also show and delete files and folders over a given size.

The identification of build directories is done via regular expressions in a
`rmvenv_config.toml` file in your `.config` directory. This config looks like
this:

```toml
# The default size items are 'marked' when using the '--size' or '-s' flag
default_max_size = "100m"

# if a base filename matches one of these regexes, it'll be marked`
marked_files = [
  '\*.class' # Java
]

# Ignore any files in a directory matching these regexes
ignored = [
  '\.git'
]

[project.Python]
# If a directory contains a file who's able that matches this regex...
marker = '^((requirements\.txt)|(pyproject.toml))$'

# then mark any items who's name matches this expression, either for printing
# or deleting
marked = '.*venv'
```

Comes out-of-the-box with C++, C#, Java, Python, and Rust. Add new build
environments with as needed!

## Installation

### Requirements

- Python >= 3.10
- pip
- Linux

### Steps

Open the command line and run

```
pip install rmvenv
```

On some Linux distributions [pipx](https://pipx.pypa.io/latest/)
may have to be used:

```
pipx install rmvenv
```

## Example uses

On the command line, to list build environments in the currently
directory, simply use:

```
rmvenv
```

To delete (interactively) build environments, as well as large files and
folders over 1 gigabytes in the folder `my_code`:

```
rmvenv -s 1G --delete my_code
```
