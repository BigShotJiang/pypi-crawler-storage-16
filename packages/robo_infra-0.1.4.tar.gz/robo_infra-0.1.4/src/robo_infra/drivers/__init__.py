"""Hardware driver implementations."""
