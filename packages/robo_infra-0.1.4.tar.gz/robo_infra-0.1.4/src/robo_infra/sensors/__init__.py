"""Sensor implementations."""
