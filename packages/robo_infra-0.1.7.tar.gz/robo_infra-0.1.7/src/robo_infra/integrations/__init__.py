"""Integration bridges for svc-infra and ai-infra."""
