# AI Integration

Robocop can be used directly in the Python code [Python API Reference](../user_guide/python_api.md), and it is possible
to automate workflows using AI.

## MCP

Read how to configure and use the Robocop MCP server at [robocop-mcp](https://github.com/aaltat/robocop-mcp).
