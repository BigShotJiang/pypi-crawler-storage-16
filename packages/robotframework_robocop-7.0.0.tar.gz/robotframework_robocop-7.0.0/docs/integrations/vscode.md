# VS Code

[Robotcode](https://robotcode.io/) provides full support for Robot Framework and also includes Robocop support.
Robocop is run as a separate process, and results are displayed in the IDE.

See plugin documentation for more details.
