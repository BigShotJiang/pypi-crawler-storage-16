"""Collection of classes for detecting checker disablers (like # robocop: off) in robot files"""

from __future__ import annotations

import re
from collections import defaultdict
from typing import TYPE_CHECKING

from robot.api import Token
from robot.parsing.model.blocks import CommentSection

try:
    from robot.api.parsing import ModelVisitor
except ImportError:
    from robot.parsing.model.visitor import ModelVisitor


if TYPE_CHECKING:
    from collections.abc import Generator

    from robot.parsing import File
    from robot.parsing.model import KeywordSection, Statement, TestCaseSection
    from robot.parsing.model.statements import Comment, KeywordName, Node, TestCaseName

    from robocop.linter.diagnostics import Diagnostic


DISABLER_PATTERN = re.compile(r"robocop: ?(?P<disabler>off|on)(?:\s?=\s?(?P<rules>[\w\-]+(?:,\s?[\w\-]+)*))?")


class Disabler:
    def __init__(self, start_line: int, end_line: int | None, directive_col_start: int, directive_col_end: int) -> None:
        self.start_line = start_line
        self.end_line = end_line
        self.directive_col_start = directive_col_start
        self.directive_col_end = directive_col_end
        self.used = False

    def __contains__(self, line: int) -> bool:
        return self.start_line <= line <= self.end_line


class RuleDisablers:
    """Container for file disablers"""

    def __init__(self, blocks: list | None = None) -> None:
        self.current_block = None
        self.lines: dict[int, Disabler] = {}
        self.blocks: list[Disabler] = blocks if blocks else []

    def start_block(self, start_line: int, directive_col_start: int, directive_col_end: int) -> None:
        if self.current_block is not None:
            return
        self.current_block = Disabler(
            start_line=start_line,
            end_line=None,
            directive_col_start=directive_col_start,
            directive_col_end=directive_col_end,
        )

    def end_block(self, end_line: int) -> None:
        if self.current_block is None:
            return
        self.current_block.end_line = end_line
        self.blocks.append(self.current_block)
        self.current_block = None

    def disable_block(self, start_line: int, end_line: int, directive_col_start: int, directive_col_end: int) -> None:
        disabler = Disabler(
            start_line=start_line,
            end_line=end_line,
            directive_col_start=directive_col_start,
            directive_col_end=directive_col_end,
        )
        for line in range(start_line, end_line + 1):
            self.lines[line] = disabler

    @property
    def not_used_disablers(self) -> Generator[Disabler, None, None]:
        for disabler in self.lines.values():
            if not disabler.used:
                yield disabler
        for disabler in self.blocks:
            if not disabler.used:
                yield disabler

    def __contains__(self, line: int) -> bool:
        if disabled_line := self.lines.get(line):
            disabled_line.used = True
            return True
        for block in self.blocks:
            if line in block:
                block.used = True
                return True
        return False


class DisablersVisitor(ModelVisitor):
    def __init__(self, model: File):
        self.file_disabled = False
        self.file_end = 1
        self.is_first_comment_section = True
        self.keyword_or_test_section = False
        self.header_line_numer = 0
        self.header_last_line = 0
        self.disablers_in_scope = []
        self.rules = defaultdict(lambda: RuleDisablers())
        self.visit(model)

    def visit_File(self, node: File) -> None:  # noqa: N802
        self.file_end = node.end_lineno
        self.generic_visit(node)

    def parse_disablers_in_node(self, node: type[Node], last_line: int | None = None) -> None:
        self.header_line_numer = node.lineno
        self.header_last_line = node.end_lineno
        self.disablers_in_scope.append(defaultdict(lambda: RuleDisablers()))
        self.generic_visit(node)
        for rule_name, rule_disabler in self.disablers_in_scope[-1].items():
            if self.is_first_comment_section:
                if rule_name == "all":
                    self.file_disabled = True
                rule_disabler.end_block(end_line=self.file_end)
                self.rules[rule_name] = rule_disabler
            else:
                last_line = node.end_lineno if last_line is None else last_line
                self.disablers_in_scope[-1][rule_name].end_block(last_line)
                self.rules[rule_name].blocks.extend(rule_disabler.blocks)
                self.rules[rule_name].lines.update(rule_disabler.lines)
        self.disablers_in_scope.pop()

    def visit_KeywordSection(self, node: KeywordSection | TestCaseSection) -> None:  # noqa: N802
        self.is_first_comment_section = False
        self.keyword_or_test_section = True
        self.parse_disablers_in_node(node)
        self.keyword_or_test_section = False

    visit_TestCaseSection = visit_KeywordSection  # noqa: N815

    def visit_Section(self, node: type[Node]) -> None:  # noqa: N802
        self.is_first_comment_section = self.is_first_comment_section and isinstance(node, CommentSection)
        self.parse_disablers_in_node(node)
        self.is_first_comment_section = False

    def visit_TestCase(self, node: type[Node]) -> None:  # noqa: N802
        self.parse_disablers_in_node(node)

    visit_Keyword = visit_Try = visit_For = visit_ForLoop = visit_While = visit_Group = visit_TestCase  # noqa: N815

    def visit_If(self, node: type[Node]) -> None:  # noqa: N802
        last_line = node.body[-1].end_lineno if node.body else None
        self.parse_disablers_in_node(node, last_line)

    def visit_Statement(self, node: Statement) -> None:  # noqa: N802
        for comment in node.get_tokens(Token.COMMENT):
            self.parse_comment_token(comment, parent_node=node, is_inline=False)

    def visit_TestCaseName(self, node: KeywordName | TestCaseName) -> None:  # noqa: N802
        """Save the last test case / keyword header line number to check if the comment is standalone."""
        self.header_line_numer = node.lineno
        self.visit_Statement(node)

    visit_KeywordName = visit_TestCaseName  # noqa: N815

    def visit_Comment(self, node: Comment) -> None:  # noqa: N802
        for comment in node.get_tokens(Token.COMMENT):
            self.parse_comment_token(comment, is_inline=True)

    def parse_comment_token(self, token: Token, is_inline: bool, parent_node=None) -> None:
        if "#" not in token.value:
            return
        disablers = []

        if "# noqa" in token.value:
            col_start = token.col_offset + token.value.index("# noqa") + 1
            col_end = col_start + 6
            disablers.append(("all", col_start, col_end))

        for disabler in DISABLER_PATTERN.finditer(token.value):
            col_start = token.col_offset + disabler.lastindex + 1
            col_end = token.col_offset + disabler.endpos + 1
            col_end = min(col_end, token.end_col_offset + 1)

            if not disabler.group("rules") or "noqa" in disabler.group("rules"):
                rules = ["all"]
            else:
                rules = [rule.strip() for rule in disabler.group("rules").split(",") if rule.strip()]
            if disabler.group("disabler") == "off":
                disablers.extend([(rule, col_start, col_end) for rule in rules])
            elif disabler.group("disabler") == "on" and is_inline:
                scope = self.get_scope_for_disabler(token)
                self.end_blocks(scope, rules, end_line=token.lineno)
        for rule, col_start, col_end in disablers:
            if is_inline or self.is_first_comment_section:
                scope = self.get_scope_for_disabler(token)
                scope[rule].start_block(
                    start_line=token.lineno, directive_col_start=col_start, directive_col_end=col_end
                )
            else:
                if token.lineno == self.header_line_numer:
                    start_line, end_line = self.header_line_numer, self.header_last_line
                elif parent_node:
                    start_line, end_line = parent_node.lineno, parent_node.end_lineno
                else:
                    start_line, end_line = token.lineno, token.lineno
                self.rules[rule].disable_block(
                    start_line=start_line, end_line=end_line, directive_col_start=col_start, directive_col_end=col_end
                )

    def get_scope_for_disabler(self, token: Token) -> defaultdict[str, RuleDisablers]:
        if token.col_offset == 0 and self.keyword_or_test_section:
            return self.disablers_in_scope[0]
        return self.disablers_in_scope[-1]

    @staticmethod
    def end_blocks(scope: defaultdict[str, RuleDisablers], rules: list[str], end_line: int) -> None:
        if "all" in rules:
            rules = list(scope.keys())
        for rule in rules:
            scope[rule].end_block(end_line)


class DisablersFinder:
    """Visit and find robocop disablers in Robot Framework file."""

    def __init__(self, model: File):
        self.visitor = DisablersVisitor(model)

    @property
    def any_disabler(self) -> bool:
        return len(self.visitor.rules) != 0

    @property
    def file_disabled(self) -> bool:
        return self.visitor.file_disabled

    def is_rule_disabled(self, diagnostic: Diagnostic) -> bool:
        """
        Check if the given ` rule_msg ` is disabled.

        'All' takes precedence, then line disablers, then block disablers.
        We're checking for both message id and name.
        """
        # special case for unused-disabler to not disable it with `# robocop: off` etc
        if not self.any_disabler or diagnostic.rule.name == "unused-disabler":
            return False
        return any(
            self.is_line_disabled(line, rule)
            for line in (diagnostic.range.start.line, *diagnostic.extended_disablers)
            for rule in ("all", diagnostic.rule.rule_id, diagnostic.rule.name)
        )

    def is_line_disabled(self, line: int, rule: str) -> bool:
        """Check if a given line is in range of any disabled block"""
        if rule not in self.visitor.rules:
            return False
        return line in self.visitor.rules[rule]

    @property
    def not_used_disablers(self) -> Generator[tuple[str, Disabler], None, None]:
        for rule, rule_disabler in self.visitor.rules.items():
            for disabler in rule_disabler.not_used_disablers:
                yield rule, disabler
                disabler.used = True  # for disablers spanning multiple lines
